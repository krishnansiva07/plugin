package com.astra.mcp.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.WebClient;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicLong;

@Service
public class McpClientService {
    private final WebClient web;
    private final ObjectMapper om = new ObjectMapper();
    private final AtomicLong id = new AtomicLong(1);

    @Value("${playwright.mcp.url}")
    String url;

    private String sessionId;

    public McpClientService(WebClient.Builder b) {
        this.web = b.build();
    }

    public synchronized void reset() {
        sessionId = null;
    }

    public synchronized String getSessionId() {
        return sessionId;
    }

    public synchronized Map<String, Object> call(String method, Object params) {
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("jsonrpc", "2.0");
        body.put("id", id.getAndIncrement());
        body.put("method", method);
        body.put("params", params == null ? Map.of() : params);
        return post(body, true);
    }

    public synchronized Map<String, Object> notify(String method, Object params) {
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("jsonrpc", "2.0");
        body.put("method", method);
        body.put("params", params == null ? Map.of() : params);
        return post(body, false);
    }

    private Map<String, Object> post(Map<String, Object> body, boolean expectResponse) {
        McpHttpResult result = web.post()
                .uri(url)
                .contentType(MediaType.APPLICATION_JSON)
                .header(HttpHeaders.ACCEPT, "application/json, text/event-stream")
                .headers(headers -> {
                    if (sessionId != null && !sessionId.isBlank()) {
                        headers.add("mcp-session-id", sessionId);
                    }
                })
                .bodyValue(body)
                .exchangeToMono(this::toResult)
                .block();

        if (result == null) {
            return Map.of("error", "MCP_NO_RESPONSE");
        }

        String sid = result.headers.getFirst("mcp-session-id");
        if (sid != null && !sid.isBlank()) {
            sessionId = sid;
        }

        if (result.status >= 400) {
            return Map.of(
                    "error", "MCP_HTTP_ERROR",
                    "status", result.status,
                    "body", result.body == null ? "" : result.body,
                    "sessionId", sessionId == null ? "" : sessionId
            );
        }

        if (!expectResponse) {
            return Map.of("ok", true, "sessionId", sessionId == null ? "" : sessionId);
        }

        try {
            return om.readValue(extractJson(result.body), Map.class);
        } catch (Exception e) {
            return Map.of(
                    "error", "MCP_PARSE_ERROR",
                    "raw", result.body == null ? "" : result.body,
                    "sessionId", sessionId == null ? "" : sessionId
            );
        }
    }

    private reactor.core.publisher.Mono<McpHttpResult> toResult(ClientResponse response) {
        int status = response.statusCode().value();
        HttpHeaders headers = response.headers().asHttpHeaders();
        return response.bodyToMono(String.class)
                .defaultIfEmpty("")
                .map(body -> new McpHttpResult(status, headers, body));
    }

    private String extractJson(String raw) {
        if (raw == null || raw.isBlank()) return "{}";
        // Streamable HTTP can return SSE-style content: event: message\ndata: {...}
        for (String line : raw.split("\\R")) {
            String trimmed = line.trim();
            if (trimmed.startsWith("data:")) {
                String data = trimmed.substring(5).trim();
                if (data.startsWith("{")) return data;
            }
        }
        int i = raw.indexOf('{');
        int j = raw.lastIndexOf('}');
        return i >= 0 && j > i ? raw.substring(i, j + 1) : "{}";
    }

    public synchronized void initialize() {
        Map<String, Object> res = call("initialize", Map.of(
                "protocolVersion", "2025-06-18",
                "capabilities", Map.of(),
                "clientInfo", Map.of("name", "astra-java-client", "version", "1.0")
        ));

        if (res.containsKey("error")) {
            throw new RuntimeException("MCP initialize failed: " + res);
        }
        if (sessionId == null || sessionId.isBlank()) {
            throw new RuntimeException("MCP initialize succeeded but no mcp-session-id header was returned. Response: " + res);
        }

        Map<String, Object> initNotify = notify("notifications/initialized", Map.of());
        if (initNotify.containsKey("error")) {
            throw new RuntimeException("MCP initialized notification failed: " + initNotify);
        }
    }

    public Map<String, Object> tools() {
        return call("tools/list", Map.of());
    }

    public Map<String, Object> tool(String name, Map<String, Object> args) {
        Map<String, Object> safeArgs = normalizeToolArgs(args);
        return call("tools/call", Map.of("name", name, "arguments", safeArgs));
    }

    private Map<String, Object> normalizeToolArgs(Map<String, Object> args) {
        Map<String, Object> normalized = new LinkedHashMap<>();
        if (args != null) normalized.putAll(args);
        // Latest Playwright MCP uses ref, not target. Keep this bridge for old LLM outputs.
        if (!normalized.containsKey("ref") && normalized.containsKey("target")) {
            normalized.put("ref", normalized.get("target"));
            normalized.remove("target");
        }
        return normalized;
    }

    public String snapshot() {
        return String.valueOf(tool("browser_snapshot", Map.of()));
    }

    private record McpHttpResult(int status, HttpHeaders headers, String body) {}
}
