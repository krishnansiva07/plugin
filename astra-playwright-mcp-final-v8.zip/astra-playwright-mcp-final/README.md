# Astra Playwright MCP Final V8

## What V8 fixes

V8 fixes the HTTP MCP session handling issue that caused:

`400 Bad Request from POST http://localhost:8931/mcp`

Root cause: the Java client was not reading the `mcp-session-id` response header from the MCP `initialize` response. Latest streamable HTTP MCP requires the same `mcp-session-id` header on follow-up calls such as `notifications/initialized`, `tools/list`, and `tools/call`.

V8 also normalizes old LLM output from `target` to the latest Playwright MCP `ref` argument.

## Run

```bash
mvn clean spring-boot:run
```

Open:

```text
http://localhost:8090/index.html
```

## Important Windows note

Do not manually run multiple MCP servers on the same port while testing. If port 8931 is already used, kill the old process:

```powershell
netstat -ano | findstr :8931
taskkill /PID <PID> /F
```

Then start Spring Boot and let the app start MCP.

## Latest Playwright MCP

The backend starts MCP with:

```bash
npx.cmd -y @playwright/mcp@latest --port 8931
```

When Ignore HTTPS Errors is selected, it adds:

```bash
--ignore-https-errors
```

When User Data Dir is provided, it adds:

```bash
--user-data-dir <path>
```
