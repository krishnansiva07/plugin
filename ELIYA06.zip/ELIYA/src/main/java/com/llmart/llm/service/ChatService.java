package com.llmart.llm.service;

import com.llmart.llm.dto.ChatMode;
import com.llmart.llm.dto.ChatRequest;
import com.llmart.llm.dto.MessageDto;
import com.llmart.llm.entity.ConversationEntity;
import com.llmart.llm.entity.MessageEntity;
import jakarta.annotation.PreDestroy;
import org.springframework.stereotype.Service;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;

@Service
public class ChatService {
    private final ConversationService conversations;
    private final FileService files;
    private final ContextService contextService;
    private final ProjectService projects;
    private final OpenAiCompatibleClient llm;
    private final AgentService agentService;
    private final AgentRunService agentRuns;
    private final PromptResourceResolver resourceResolver;
    private final Map<String, AtomicBoolean> chatCancellations = new ConcurrentHashMap<>();
    private final ExecutorService runExecutor = Executors.newFixedThreadPool(
            Math.max(2, Math.min(8, Runtime.getRuntime().availableProcessors())), r -> {
        Thread t = new Thread(r, "agent-run-executor"); t.setDaemon(true); return t;
    });

    public ChatService(ConversationService conversations, FileService files,
                       ContextService contextService, ProjectService projects,
                       OpenAiCompatibleClient llm, AgentService agentService, AgentRunService agentRuns,
                       PromptResourceResolver resourceResolver) {
        this.conversations = conversations;
        this.files = files;
        this.contextService = contextService;
        this.projects = projects;
        this.llm = llm;
        this.agentService = agentService;
        this.agentRuns = agentRuns;
        this.resourceResolver = resourceResolver;
    }

    public SseEmitter stream(String apiKey, ChatRequest request) {
        if (apiKey == null || apiKey.isBlank()) throw new IllegalArgumentException("API key is required");
        SseEmitter emitter = new SseEmitter(0L);
        AtomicBoolean transportOpen = new AtomicBoolean(true);
        // A browser/proxy SSE disconnect is a transport event, not an execution cancellation. Agent and Chat work
        // continue server-side and persist their result. Only the explicit Stop endpoint cancels execution.
        Runnable closeTransport = () -> transportOpen.set(false);
        emitter.onTimeout(closeTransport);
        emitter.onError(error -> closeTransport.run());
        emitter.onCompletion(closeTransport);

        CompletableFuture.runAsync(() -> {
            try {
                ConversationEntity conversation = conversations.getOrCreate(request.conversationId());
                MessageEntity userMessage;

                if (request.isRegenerate()) {
                    userMessage = conversations.lastUserMessage(conversation.getId());
                    conversations.removeMessagesAfter(conversation.getId(), userMessage.getId());
                } else {
                    List<String> attachmentIds = request.attachmentIds() == null ? List.of() : request.attachmentIds();
                    files.requireForConversation(conversation.getId(), attachmentIds);
                    String userText = request.message();
                    if ((userText == null || userText.isBlank()) && attachmentIds.isEmpty()) {
                        throw new IllegalArgumentException("Message or attachment is required");
                    }
                    if (userText == null || userText.isBlank()) {
                        userText = "Please analyze the attached file(s).";
                    }
                    userMessage = conversations.addMessage(conversation.getId(), "user", userText.strip(), attachmentIds);
                }

                ChatMode mode = request.chatMode();
                String effectiveProjectId = request.projectId();
                boolean autoResolvedWorkspace = false;

                // Prompt paths are authoritative in Agent mode. This lets the user switch projects simply by
                // supplying a different existing project/file path, even when an older workspace is still active in
                // the browser. When no path is supplied, the existing project id remains available for follow-up turns.
                if (mode == ChatMode.AGENT) {
                    var inferred = resourceResolver.primaryProjectPath(userMessage.getContent());
                    if (inferred.isPresent()) {
                        var mapped = projects.createLocal(conversation.getId(), inferred.get().toString(), inferred.get().getFileName() == null ? "Prompt workspace" : inferred.get().getFileName().toString());
                        effectiveProjectId = mapped.id();
                        autoResolvedWorkspace = true;
                    } else if (effectiveProjectId != null && !effectiveProjectId.isBlank()) {
                        projects.requireConversation(effectiveProjectId, conversation.getId());
                    }
                } else if (effectiveProjectId != null && !effectiveProjectId.isBlank()) {
                    projects.requireConversation(effectiveProjectId, conversation.getId());
                }

                if (mode == ChatMode.AGENT) {
                    if (effectiveProjectId == null || effectiveProjectId.isBlank()) {
                        throw new IllegalArgumentException("Agent mode requires either an active local workspace or an explicit existing project/file path in the prompt.");
                    }
                    var activeWorkspace = projects.require(effectiveProjectId);
                    if (!activeWorkspace.hasLocalPath()) {
                        throw new IllegalArgumentException("Agent mode requires a local-path workspace because tools operate directly on that path.");
                    }
                }

                ChatRequest effectiveRequest = Objects.equals(effectiveProjectId, request.projectId()) ? request : new ChatRequest(
                        request.conversationId(), request.message(), request.attachmentIds(), effectiveProjectId, request.mode(), request.regenerate(), request.settings());

                List<Map<String, Object>> context = contextService.build(
                        conversation.getId(), userMessage, request.settings(), effectiveProjectId, apiKey, mode);

                AgentRunService.AgentRun agentRun = mode == ChatMode.AGENT
                        ? agentRuns.start(conversation.getId(), effectiveProjectId)
                        : null;
                Map<String,Object> meta = new LinkedHashMap<>();
                meta.put("conversationId", conversation.getId());
                meta.put("userMessageId", userMessage.getId());
                meta.put("mode", mode.wireName());
                if (agentRun != null) meta.put("agentRunId", agentRun.id());
                if (effectiveProjectId != null && !effectiveProjectId.isBlank()) meta.put("projectId", effectiveProjectId);
                if (autoResolvedWorkspace) meta.put("autoResolvedWorkspace", true);
                safeSend(emitter, transportOpen, "meta", meta);

                String answer;
                if (mode == ChatMode.AGENT) {
                    AgentService.AgentResult result = agentService.run(agentRun.id(), apiKey, effectiveRequest, context, event -> {
                        safeSend(emitter, transportOpen, "agent_step", event);
                    });
                    answer = result.answer();

                    // Persist the terminal result BEFORE relying on the SSE transport. If a proxy/browser keeps the
                    // stream open or drops the final event, the UI watchdog can recover this durable answer by run id.
                    MessageEntity assistant = conversations.addMessage(conversation.getId(), "assistant", answer, List.of());
                    MessageDto dto = conversations.messageDto(assistant);
                    agentRun.markResponsePersisted(String.valueOf(dto.id()), answer);
                    safeSend(emitter, transportOpen, "token", Map.of("text", visibleAgentAnswer(answer)));
                    if (!result.changes().isEmpty()) {
                        safeSend(emitter, transportOpen, "agent_changes", Map.of(
                                "count", result.changes().size(), "mode", "direct"));
                    }
                    safeSend(emitter, transportOpen, "done", dto);
                    safeComplete(emitter, transportOpen);
                    return;
                }

                AtomicBoolean chatCancelled = new AtomicBoolean(false);
                AtomicBoolean previous = chatCancellations.put(conversation.getId(), chatCancelled);
                if (previous != null) previous.set(true);
                StringBuilder generated = new StringBuilder();
                BufferedTokenTransport tokenTransport = new BufferedTokenTransport(emitter, transportOpen);
                try {
                    answer = llm.stream(apiKey, request.settings(), context, token -> {
                        generated.append(token);
                        tokenTransport.accept(token);
                    }, chatCancelled::get);
                    tokenTransport.flush();

                    MessageEntity assistant = conversations.addMessage(conversation.getId(), "assistant", answer, List.of());
                    MessageDto dto = conversations.messageDto(assistant);
                    safeSend(emitter, transportOpen, "done", dto);
                    safeComplete(emitter, transportOpen);
                } catch (AgentCancelledException stopped) {
                    tokenTransport.flush();
                    String partial = generated.toString().stripTrailing();
                    if (!partial.isBlank()) {
                        partial += "\n\n*Generation stopped.*";
                        MessageEntity assistant = conversations.addMessage(conversation.getId(), "assistant", partial, List.of());
                        safeSend(emitter, transportOpen, "done", conversations.messageDto(assistant));
                    } else {
                        safeSend(emitter, transportOpen, "stopped", Map.of("message", "Generation stopped"));
                    }
                    safeComplete(emitter, transportOpen);
                } finally {
                    chatCancellations.remove(conversation.getId(), chatCancelled);
                }
            } catch (Exception e) {
                safeSend(emitter, transportOpen, "error", Map.of("message", safeMessage(e)));
                if (transportOpen.get()) {
                    try { emitter.completeWithError(e); } catch (Exception ignored) { transportOpen.set(false); }
                }
            }
        }, runExecutor);
        return emitter;
    }

    /** Explicit user cancellation for Chat mode. Network/SSE disconnects never call this. */
    public boolean cancelChat(String conversationId) {
        if (conversationId == null || conversationId.isBlank()) return false;
        AtomicBoolean flag = chatCancellations.get(conversationId);
        if (flag == null) return false;
        flag.set(true);
        return true;
    }

    private void safeSend(SseEmitter emitter, AtomicBoolean transportOpen, String event, Object data) {
        if (!transportOpen.get()) return;
        try { emitter.send(SseEmitter.event().name(event).data(data)); }
        catch (Exception ignored) { transportOpen.set(false); }
    }

    private void safeComplete(SseEmitter emitter, AtomicBoolean transportOpen) {
        if (!transportOpen.getAndSet(false)) return;
        try { emitter.complete(); } catch (Exception ignored) {}
    }

    /** Coalesces tiny provider deltas into fewer browser/SSE updates without delaying normal streaming. */
    private final class BufferedTokenTransport {
        private static final int FLUSH_CHARS = 96;
        private static final long FLUSH_NANOS = 35_000_000L;
        private final SseEmitter emitter;
        private final AtomicBoolean transportOpen;
        private final StringBuilder pending = new StringBuilder();
        private long lastFlush = System.nanoTime();

        private BufferedTokenTransport(SseEmitter emitter, AtomicBoolean transportOpen) {
            this.emitter = emitter;
            this.transportOpen = transportOpen;
        }

        private void accept(String token) {
            if (token == null || token.isEmpty()) return;
            pending.append(token);
            long now = System.nanoTime();
            if (pending.length() >= FLUSH_CHARS || now - lastFlush >= FLUSH_NANOS) flush();
        }

        private void flush() {
            if (pending.isEmpty()) return;
            String chunk = pending.toString();
            pending.setLength(0);
            lastFlush = System.nanoTime();
            safeSend(emitter, transportOpen, "token", Map.of("text", chunk));
        }
    }

    @PreDestroy
    public void shutdownExecutor() { runExecutor.shutdownNow(); }

    private String visibleAgentAnswer(String value) {
        if (value == null) return "";
        return value.replaceAll("(?is)<!--\\s*PROJECT_FILE_START:[^>]+-->.*?<!--\\s*PROJECT_FILE_END\\s*-->", "").strip();
    }

    private String safeMessage(Exception e) {
        String m = e.getMessage();
        if (m == null || m.isBlank()) return e.getClass().getSimpleName();
        return m.length() > 1500 ? m.substring(0, 1500) : m;
    }
}
