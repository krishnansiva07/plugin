'use strict';

const state = {
  conversationId: null,
  conversations: [],
  messages: [],
  attachments: [],
  filesById: new Map(),
  streaming: false,
  abortController: null,
  renderTimer: null,
  editingIndex: null,
  historyMenuId: null,
  renameId: null,
  userScrolledUp: false,
  config: {
    apiKey: sessionStorage.getItem('llm.apiKey') || localStorage.getItem('llm.apiKey') || '',
    baseUrl: localStorage.getItem('llm.baseUrl') || '',
    model: localStorage.getItem('llm.model') || '',
    temperature: Number(localStorage.getItem('llm.temperature') || 0.7),
    maxTokens: Number(localStorage.getItem('llm.maxTokens') || 4096),
    contextChars: Number(localStorage.getItem('llm.contextChars') || 64000),
    systemPrompt: localStorage.getItem('llm.systemPrompt') || '',
    useFileContext: localStorage.getItem('llm.useFileContext') !== 'false',
    rememberKey: Boolean(localStorage.getItem('llm.apiKey'))
  }
};

const $ = id => document.getElementById(id);
const esc = value => MarkdownRenderer.escapeHtml(value);

function isConfigured() {
  return Boolean(state.config.apiKey && state.config.baseUrl && state.config.model);
}

async function api(url, options = {}) {
  const response = await fetch(url, options);
  if (!response.ok) {
    let message = `HTTP ${response.status}`;
    try {
      const contentType = response.headers.get('content-type') || '';
      if (contentType.includes('application/json')) {
        const body = await response.json();
        message = body.message || body.error || message;
      } else {
        const body = await response.text();
        if (body.trim()) message = body.trim().slice(0, 1200);
      }
    } catch (_) { /* ignore parse failure */ }
    throw new Error(message);
  }
  if (response.status === 204) return null;
  const contentType = response.headers.get('content-type') || '';
  return contentType.includes('application/json') ? response.json() : response;
}

function toast(text, duration = 2300) {
  const node = $('toast');
  node.textContent = text;
  node.classList.remove('hidden');
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => node.classList.add('hidden'), duration);
}

function saveConfig() {
  localStorage.setItem('llm.baseUrl', state.config.baseUrl);
  localStorage.setItem('llm.model', state.config.model);
  localStorage.setItem('llm.temperature', String(state.config.temperature));
  localStorage.setItem('llm.maxTokens', String(state.config.maxTokens));
  localStorage.setItem('llm.contextChars', String(state.config.contextChars));
  localStorage.setItem('llm.systemPrompt', state.config.systemPrompt);
  localStorage.setItem('llm.useFileContext', String(state.config.useFileContext));

  if (state.config.rememberKey) {
    localStorage.setItem('llm.apiKey', state.config.apiKey);
    sessionStorage.removeItem('llm.apiKey');
  } else {
    localStorage.removeItem('llm.apiKey');
    if (state.config.apiKey) sessionStorage.setItem('llm.apiKey', state.config.apiKey);
    else sessionStorage.removeItem('llm.apiKey');
  }

  updateModelBadge();
  updateWelcomeMode();
}

function syncSettingsUi() {
  $('apiKey').value = state.config.apiKey;
  $('baseUrl').value = state.config.baseUrl;
  $('modelName').value = state.config.model;
  $('temperature').value = state.config.temperature;
  $('maxTokens').value = state.config.maxTokens;
  $('contextChars').value = state.config.contextChars;
  $('systemPrompt').value = state.config.systemPrompt;
  $('useFileContext').checked = state.config.useFileContext;
  $('rememberKey').checked = state.config.rememberKey;

  $('homeApiKey').value = state.config.apiKey;
  $('homeBaseUrl').value = state.config.baseUrl;
  $('homeModel').value = state.config.model;
  $('homeRemember').checked = state.config.rememberKey;
}

function updateModelBadge() {
  $('modelBadge').textContent = state.config.model || 'Model not configured';
}

function updateWelcomeMode() {
  const setup = document.querySelector('.setup-card');
  const configured = isConfigured();
  setup.classList.toggle('hidden', configured);
  $('welcomeText').textContent = configured
    ? `Connected to ${state.config.model}. Start a conversation, attach a file, or paste code.`
    : 'Connect your OpenAI-compatible model, then chat with files, images and code.';
}

function updateContextBadge() {
  const used = state.messages.reduce((sum, item) => sum + String(item.content || '').length, 0);
  const limit = state.config.contextChars || 0;
  $('contextBadge').textContent = `${formatCompact(used)} / ${formatCompact(limit)} context chars`;
}

function formatCompact(n) {
  const value = Number(n || 0);
  if (value >= 1_000_000) return `${(value / 1_000_000).toFixed(value >= 10_000_000 ? 0 : 1)}m`;
  if (value >= 1_000) return `${(value / 1_000).toFixed(value >= 10_000 ? 0 : 1)}k`;
  return String(value);
}

function formatBytes(bytes) {
  const value = Number(bytes || 0);
  if (value < 1024) return `${value} B`;
  if (value < 1024 * 1024) return `${(value / 1024).toFixed(1)} KB`;
  return `${(value / 1024 / 1024).toFixed(1)} MB`;
}

async function loadConversations() {
  state.conversations = await api('/api/conversations');
  renderHistory($('historySearch').value || '');
}

function renderHistory(filter = '') {
  const q = filter.trim().toLowerCase();
  const list = state.conversations.filter(c => !q || String(c.title || '').toLowerCase().includes(q));
  if (!list.length) {
    $('historyList').innerHTML = `<div class="history-empty">${q ? 'No matching chats' : 'Your chats will appear here'}</div>`;
    return;
  }
  $('historyList').innerHTML = list.map(c => `
    <div class="history-item ${c.id === state.conversationId ? 'active' : ''}" data-id="${esc(c.id)}" title="${esc(c.title)}">
      <span class="history-title">${esc(c.title || 'New chat')}</span>
      <button class="history-menu" type="button" data-menu="${esc(c.id)}" aria-label="Chat options">⋯</button>
    </div>`).join('');
}

function newChat() {
  if (state.streaming) state.abortController?.abort();
  state.conversationId = null;
  state.messages = [];
  state.attachments = [];
  state.filesById = new Map();
  state.editingIndex = null;
  state.userScrolledUp = false;
  $('conversationTitle').textContent = 'New chat';
  $('historySearch').value = '';
  closeHistoryMenu();
  renderHistory();
  renderAttachmentTray();
  renderMessages();
  updateWelcomeMode();
  $('messageInput').value = '';
  autoGrow();
  $('messageInput').focus();
}

async function ensureConversation() {
  if (state.conversationId) return state.conversationId;
  const created = await api('/api/conversations', { method: 'POST' });
  state.conversationId = created.id;
  $('conversationTitle').textContent = created.title || 'New chat';
  await loadConversations();
  return created.id;
}

async function openConversation(id) {
  if (state.streaming) return toast('Stop the current response before switching chats');
  closeHistoryMenu();
  state.conversationId = id;
  state.editingIndex = null;
  const [messages, files] = await Promise.all([
    api(`/api/conversations/${encodeURIComponent(id)}/messages`),
    api(`/api/files?conversationId=${encodeURIComponent(id)}`)
  ]);
  state.messages = messages || [];
  state.filesById = new Map((files || []).map(file => [file.id, file]));
  state.attachments = [];
  const conversation = state.conversations.find(c => c.id === id);
  $('conversationTitle').textContent = conversation?.title || 'Chat';
  renderMessages();
  renderAttachmentTray();
  renderHistory($('historySearch').value || '');
  $('sidebar').classList.remove('open');
  state.userScrolledUp = false;
  scrollBottom(true);
}

function attachmentHtml(ids) {
  if (!Array.isArray(ids) || !ids.length) return '';
  const cards = ids.map(id => {
    const file = state.filesById.get(id);
    if (!file) return `<span class="message-file"><span class="file-icon">📎</span><span class="file-text"><span class="file-name">Attachment</span></span></span>`;
    return `<a class="message-file" href="/api/files/${encodeURIComponent(id)}/download" title="Download ${esc(file.name)}">
      <span class="file-icon">${fileIcon(file.mimeType, file.name)}</span>
      <span class="file-text"><span class="file-name">${esc(file.name)}</span><span class="file-meta">${esc(formatBytes(file.size))}</span></span>
    </a>`;
  }).join('');
  return `<div class="attachment-list">${cards}</div>`;
}

function fileIcon(mime, name) {
  const m = String(mime || '').toLowerCase();
  const n = String(name || '').toLowerCase();
  if (m.startsWith('image/')) return '🖼';
  if (m.includes('pdf') || n.endsWith('.pdf')) return 'PDF';
  if (m.includes('spreadsheet') || m.includes('excel') || /\.(xlsx?|csv)$/.test(n)) return 'XLS';
  if (m.includes('word') || /\.docx?$/.test(n)) return 'DOC';
  if (m.includes('presentation') || /\.pptx?$/.test(n)) return 'PPT';
  if (/\.(java|js|ts|py|json|xml|html|css|sql|yml|yaml|sh)$/.test(n)) return '&lt;/&gt;';
  return '📎';
}

function messageHtml(message, index) {
  const assistant = message.role === 'assistant';
  const isLastAssistant = assistant && index === state.messages.length - 1;

  if (!assistant && state.editingIndex === index) {
    return `<article class="message user" data-message-index="${index}">
      <div class="avatar">You</div>
      <div class="message-body">
        ${attachmentHtml(message.attachmentIds)}
        <div class="edit-panel">
          <textarea id="editMessageInput" class="edit-textarea" rows="4">${esc(message.content || '')}</textarea>
          <div class="edit-actions"><button class="secondary-btn" type="button" data-edit-cancel="${index}">Cancel</button><button class="primary-btn" type="button" data-edit-save="${index}">Save & submit</button></div>
        </div>
      </div>
    </article>`;
  }

  const rendered = MarkdownRenderer.render(message.content || '', { streaming: Boolean(message.streaming) });
  const contentClass = assistant && message.streaming ? 'message-content typing-cursor' : 'message-content';
  const actions = assistant
    ? `<button class="mini-btn" type="button" data-copy-msg="${index}">Copy</button><button class="mini-btn" type="button" data-download-msg="${index}">Download</button>${isLastAssistant && !message.streaming ? `<button class="mini-btn" type="button" data-regenerate="${index}">Regenerate</button>` : ''}`
    : `<button class="mini-btn" type="button" data-edit-msg="${index}">Edit</button><button class="mini-btn" type="button" data-copy-msg="${index}">Copy</button>`;

  return `<article class="message ${assistant ? 'assistant' : 'user'}" data-message-index="${index}">
    <div class="avatar">${assistant ? 'AI' : 'You'}</div>
    <div class="message-body">
      ${attachmentHtml(message.attachmentIds)}
      <div class="${contentClass}">${rendered}</div>
      <div class="message-actions">${actions}</div>
    </div>
  </article>`;
}

function renderMessages() {
  $('messages').innerHTML = state.messages.map(messageHtml).join('');
  $('welcome').classList.toggle('hidden', state.messages.length > 0);
  updateContextBadge();
  if (state.editingIndex != null) {
    requestAnimationFrame(() => {
      const input = $('editMessageInput');
      if (input) { input.focus(); input.setSelectionRange(input.value.length, input.value.length); }
    });
  }
}

function updateStreamingMessage(index) {
  const article = $('messages').querySelector(`[data-message-index="${index}"]`);
  const message = state.messages[index];
  if (!article || !message) return renderMessages();
  const content = article.querySelector('.message-content');
  if (!content) return;
  content.innerHTML = MarkdownRenderer.render(message.content || '', { streaming: true });
  content.classList.add('typing-cursor');
  updateContextBadge();
}

function scheduleStreamingRender(index) {
  if (state.renderTimer) return;
  state.renderTimer = setTimeout(() => {
    state.renderTimer = null;
    updateStreamingMessage(index);
    if (!state.userScrolledUp) scrollBottom(false);
  }, 45);
}

function nearBottom() {
  const view = $('chatView');
  return view.scrollHeight - view.scrollTop - view.clientHeight < 180;
}

function scrollBottom(force = false) {
  if (!force && state.userScrolledUp) return;
  const view = $('chatView');
  requestAnimationFrame(() => {
    view.scrollTop = view.scrollHeight;
    if (force) state.userScrolledUp = false;
    updateScrollButton();
  });
}

function updateScrollButton() {
  $('scrollBottomBtn').classList.toggle('hidden', nearBottom());
}

function setStreaming(value) {
  state.streaming = value;
  $('sendBtn').classList.toggle('hidden', value);
  $('stopBtn').classList.toggle('hidden', !value);
  $('attachBtn').disabled = value;
}

async function sendMessage({ regenerate = false, overrideMessage = null } = {}) {
  if (state.streaming) return;
  if (!isConfigured()) {
    openSettings();
    return toast('Configure API key, base URL and model first');
  }

  await ensureConversation();
  const pendingAttachments = regenerate ? [] : [...state.attachments];
  let text = overrideMessage != null ? String(overrideMessage).trim() : $('messageInput').value.trim();
  if (!regenerate && !text && pendingAttachments.length) text = 'Please analyze the attached file(s).';
  if (!regenerate && !text) return;

  if (!regenerate) {
    state.messages.push({
      role: 'user',
      content: text,
      attachmentIds: pendingAttachments.map(file => file.id),
      createdAt: new Date().toISOString()
    });
    $('messageInput').value = '';
    state.attachments = [];
    autoGrow();
    renderAttachmentTray();
  }

  const assistantIndex = state.messages.length;
  const assistant = { role: 'assistant', content: '', streaming: true, attachmentIds: [] };
  state.messages.push(assistant);
  state.editingIndex = null;
  state.userScrolledUp = false;
  renderMessages();
  scrollBottom(true);
  setStreaming(true);

  const payload = {
    conversationId: state.conversationId,
    message: regenerate ? null : text,
    attachmentIds: pendingAttachments.map(file => file.id),
    regenerate,
    settings: {
      baseUrl: state.config.baseUrl,
      model: state.config.model,
      temperature: state.config.temperature,
      maxTokens: state.config.maxTokens,
      contextChars: state.config.contextChars,
      systemPrompt: state.config.systemPrompt,
      useFileContext: state.config.useFileContext
    }
  };

  state.abortController = new AbortController();
  try {
    const response = await fetch('/api/chat/stream', {
      method: 'POST',
      signal: state.abortController.signal,
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${state.config.apiKey}`
      },
      body: JSON.stringify(payload)
    });

    if (!response.ok) throw new Error(await readHttpError(response));

    await consumeSse(response, (event, rawData) => {
      if (event === 'meta') {
        try {
          const meta = JSON.parse(rawData);
          state.conversationId = meta.conversationId || state.conversationId;
          for (let i = state.messages.length - 1; i >= 0; i--) {
            if (state.messages[i].role === 'user' && !state.messages[i].id) {
              state.messages[i].id = meta.userMessageId;
              break;
            }
          }
        } catch (_) { /* ignore */ }
        return;
      }

      if (event === 'token') {
        let token = rawData;
        try {
          const parsed = JSON.parse(rawData);
          if (parsed && typeof parsed.text === 'string') token = parsed.text;
        } catch (_) { /* backward compatibility with raw token SSE */ }
        assistant.content += token;
        scheduleStreamingRender(assistantIndex);
        return;
      }

      if (event === 'done') {
        try {
          const saved = JSON.parse(rawData);
          Object.assign(assistant, saved, { streaming: false });
        } catch (_) {
          assistant.streaming = false;
        }
        return;
      }

      if (event === 'error') {
        let message = rawData;
        try { message = JSON.parse(rawData).message || message; } catch (_) { /* ignore */ }
        throw new Error(message);
      }
    });

    assistant.streaming = false;
    renderMessages();
    await loadConversations();
    const conversation = state.conversations.find(c => c.id === state.conversationId);
    if (conversation) $('conversationTitle').textContent = conversation.title;
  } catch (error) {
    assistant.streaming = false;
    if (error.name === 'AbortError') {
      if (!assistant.content.trim()) assistant.content = 'Generation stopped.';
      else assistant.content += '\n\n*Generation stopped.*';
    } else {
      assistant.content += `${assistant.content ? '\n\n' : ''}**Error:** ${error.message}`;
    }
    renderMessages();
  } finally {
    setStreaming(false);
    state.abortController = null;
    if (state.renderTimer) { clearTimeout(state.renderTimer); state.renderTimer = null; }
    scrollBottom(true);
  }
}

async function readHttpError(response) {
  let message = `HTTP ${response.status}`;
  try {
    const contentType = response.headers.get('content-type') || '';
    if (contentType.includes('application/json')) {
      const body = await response.json();
      return body.message || body.error || message;
    }
    const text = await response.text();
    if (text.trim()) return text.trim().slice(0, 1200);
  } catch (_) { /* ignore */ }
  return message;
}

async function consumeSse(response, onEvent) {
  if (!response.body) throw new Error('Streaming response body is unavailable');
  const reader = response.body.getReader();
  const decoder = new TextDecoder('utf-8');
  let buffer = '';
  let eventName = 'message';
  let dataLines = [];

  const dispatch = () => {
    if (!dataLines.length) {
      eventName = 'message';
      return;
    }
    const data = dataLines.join('\n');
    dataLines = [];
    const currentEvent = eventName;
    eventName = 'message';
    onEvent(currentEvent, data);
  };

  while (true) {
    const { value, done } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });

    let newline;
    while ((newline = buffer.indexOf('\n')) >= 0) {
      let line = buffer.slice(0, newline);
      buffer = buffer.slice(newline + 1);
      if (line.endsWith('\r')) line = line.slice(0, -1);

      if (line === '') {
        dispatch();
        continue;
      }
      if (line.startsWith(':')) continue;
      if (line.startsWith('event:')) {
        eventName = line.slice(6).trim();
        continue;
      }
      if (line.startsWith('data:')) {
        let valuePart = line.slice(5);
        // SSE allows one optional transport separator space. Remove only that one space,
        // never trimStart(), because model tokens may intentionally start with whitespace.
        if (valuePart.startsWith(' ')) valuePart = valuePart.slice(1);
        dataLines.push(valuePart);
      }
    }
  }

  buffer += decoder.decode();
  if (buffer) {
    let line = buffer.endsWith('\r') ? buffer.slice(0, -1) : buffer;
    if (line.startsWith('data:')) {
      line = line.slice(5);
      if (line.startsWith(' ')) line = line.slice(1);
      dataLines.push(line);
    }
  }
  dispatch();
}

async function uploadFiles(fileList) {
  const files = Array.from(fileList || []).filter(Boolean);
  if (!files.length) return;
  await ensureConversation();

  for (const file of files) {
    if (file.size > 25 * 1024 * 1024) {
      toast(`${file.name} is larger than 25 MB`);
      continue;
    }
    const tempId = `upload-${crypto.randomUUID ? crypto.randomUUID() : Date.now()}`;
    state.attachments.push({ id: tempId, name: file.name, size: file.size, mimeType: file.type, uploading: true });
    renderAttachmentTray();

    const form = new FormData();
    form.append('conversationId', state.conversationId);
    form.append('file', file);

    try {
      const uploaded = await api('/api/files', { method: 'POST', body: form });
      const index = state.attachments.findIndex(item => item.id === tempId);
      if (index >= 0) state.attachments[index] = uploaded;
      state.filesById.set(uploaded.id, uploaded);
      renderAttachmentTray();
    } catch (error) {
      state.attachments = state.attachments.filter(item => item.id !== tempId);
      renderAttachmentTray();
      toast(`Upload failed: ${error.message}`, 4000);
    }
  }
}

function renderAttachmentTray() {
  $('attachmentTray').innerHTML = state.attachments.map(file => `
    <div class="attachment-chip" title="${esc(file.name)}">
      <span>${fileIcon(file.mimeType, file.name)}</span>
      <span class="chip-name">${esc(file.name)}</span>
      ${file.uploading ? '<span class="chip-status">Uploading…</span>' : ''}
      <button class="chip-remove" type="button" data-remove-file="${esc(file.id)}" ${file.uploading ? 'disabled' : ''} aria-label="Remove attachment">×</button>
    </div>`).join('');
}

function openSettings() {
  syncSettingsUi();
  $('modalBackdrop').classList.remove('hidden');
  setTimeout(() => $('apiKey').focus(), 0);
}

function closeSettings() { $('modalBackdrop').classList.add('hidden'); }

function togglePassword(inputId, buttonId) {
  const input = $(inputId);
  const button = $(buttonId);
  const show = input.type === 'password';
  input.type = show ? 'text' : 'password';
  button.textContent = show ? 'Hide' : 'Show';
}

function autoGrow() {
  const input = $('messageInput');
  input.style.height = 'auto';
  input.style.height = `${Math.min(input.scrollHeight, 180)}px`;
}

async function copyText(text) {
  try {
    await navigator.clipboard.writeText(String(text || ''));
  } catch (_) {
    const area = document.createElement('textarea');
    area.value = String(text || '');
    area.style.position = 'fixed';
    area.style.opacity = '0';
    document.body.appendChild(area);
    area.select();
    document.execCommand('copy');
    area.remove();
  }
}

function downloadText(name, text, type = 'text/plain;charset=utf-8') {
  const blob = new Blob([String(text || '')], { type });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = name;
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1500);
}

function beginEditMessage(index) {
  if (state.streaming) return;
  state.editingIndex = index;
  renderMessages();
}

async function saveEditedMessage(index) {
  const input = $('editMessageInput');
  const edited = String(input?.value || '').trim();
  if (!edited) return toast('Message cannot be empty');
  const original = state.messages[index];
  if (!original?.id) return toast('This message is not saved yet');

  const attachments = (original.attachmentIds || []).map(id => state.filesById.get(id)).filter(Boolean);
  await api(`/api/conversations/${encodeURIComponent(state.conversationId)}/rewind/${original.id}`, { method: 'POST' });
  state.messages = state.messages.slice(0, index);
  state.attachments = attachments;
  state.editingIndex = null;
  await sendMessage({ overrideMessage: edited });
}

function openHistoryMenu(id, anchor) {
  state.historyMenuId = id;
  const menu = $('historyMenu');
  const rect = anchor.getBoundingClientRect();
  menu.style.left = `${Math.min(rect.left, window.innerWidth - 145)}px`;
  menu.style.top = `${Math.min(rect.bottom + 4, window.innerHeight - 100)}px`;
  menu.classList.remove('hidden');
}

function closeHistoryMenu() {
  state.historyMenuId = null;
  $('historyMenu').classList.add('hidden');
}

function openRename(id) {
  const conversation = state.conversations.find(c => c.id === id);
  if (!conversation) return;
  state.renameId = id;
  $('renameInput').value = conversation.title || '';
  $('renameBackdrop').classList.remove('hidden');
  setTimeout(() => { $('renameInput').focus(); $('renameInput').select(); }, 0);
}

function closeRename() {
  state.renameId = null;
  $('renameBackdrop').classList.add('hidden');
}

async function saveRename() {
  if (!state.renameId) return;
  const title = $('renameInput').value.trim();
  if (!title) return toast('Enter a title');
  const id = state.renameId;
  await api(`/api/conversations/${encodeURIComponent(id)}`, {
    method: 'PATCH',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ title })
  });
  closeRename();
  await loadConversations();
  if (state.conversationId === id) $('conversationTitle').textContent = title;
}

async function deleteConversation(id) {
  const conversation = state.conversations.find(c => c.id === id);
  if (!confirm(`Delete “${conversation?.title || 'this chat'}”?`)) return;
  await api(`/api/conversations/${encodeURIComponent(id)}`, { method: 'DELETE' });
  if (state.conversationId === id) newChat();
  await loadConversations();
}

function closeMenus() {
  closeHistoryMenu();
  $('exportMenu').classList.add('hidden');
}

// ---- Event wiring ----
$('brandBtn').onclick = newChat;
$('newChatBtn').onclick = newChat;
$('sendBtn').onclick = () => sendMessage();
$('stopBtn').onclick = () => state.abortController?.abort();
$('attachBtn').onclick = () => $('fileInput').click();
$('fileInput').onchange = event => { uploadFiles(event.target.files); event.target.value = ''; };
$('messageInput').addEventListener('input', autoGrow);
$('messageInput').addEventListener('keydown', event => {
  if (event.key === 'Enter' && !event.shiftKey && !event.isComposing) {
    event.preventDefault();
    sendMessage();
  }
});
$('messageInput').addEventListener('paste', event => {
  const files = Array.from(event.clipboardData?.files || []);
  if (files.length) uploadFiles(files);
});
$('historySearch').addEventListener('input', event => renderHistory(event.target.value));
$('settingsBtn').onclick = openSettings;
$('topSettingsBtn').onclick = openSettings;
$('closeSettings').onclick = closeSettings;
$('cancelSettings').onclick = closeSettings;
$('modalBackdrop').addEventListener('click', event => { if (event.target === $('modalBackdrop')) closeSettings(); });
$('toggleKey').onclick = () => togglePassword('apiKey', 'toggleKey');
$('homeToggleKey').onclick = () => togglePassword('homeApiKey', 'homeToggleKey');
$('openSidebar').onclick = () => $('sidebar').classList.add('open');
$('closeSidebar').onclick = () => $('sidebar').classList.remove('open');
$('scrollBottomBtn').onclick = () => scrollBottom(true);

$('themeBtn').onclick = () => {
  const current = document.documentElement.dataset.theme || 'light';
  const next = current === 'dark' ? 'light' : 'dark';
  document.documentElement.dataset.theme = next;
  localStorage.setItem('theme', next);
};

$('exportBtn').onclick = event => {
  event.stopPropagation();
  if (!state.conversationId) return toast('No chat to export');
  $('exportMenu').classList.toggle('hidden');
};
$('exportMenu').addEventListener('click', event => {
  const button = event.target.closest('[data-export-format]');
  if (!button || !state.conversationId) return;
  const format = button.dataset.exportFormat;
  $('exportMenu').classList.add('hidden');
  window.location.href = `/api/conversations/${encodeURIComponent(state.conversationId)}/export?format=${encodeURIComponent(format)}`;
});

$('homeSave').onclick = () => {
  state.config.apiKey = $('homeApiKey').value.trim();
  state.config.baseUrl = $('homeBaseUrl').value.trim();
  state.config.model = $('homeModel').value.trim();
  state.config.rememberKey = $('homeRemember').checked;
  if (!state.config.apiKey || !state.config.baseUrl || !state.config.model) return toast('Enter API key, base URL and model');
  saveConfig();
  syncSettingsUi();
  $('messageInput').focus();
  toast('Model configuration saved');
};

$('saveSettings').onclick = () => {
  state.config.apiKey = $('apiKey').value.trim();
  state.config.baseUrl = $('baseUrl').value.trim();
  state.config.model = $('modelName').value.trim();
  state.config.temperature = Math.max(0, Math.min(2, Number($('temperature').value || 0.7)));
  state.config.maxTokens = Math.max(64, Math.min(32768, Number($('maxTokens').value || 4096)));
  state.config.contextChars = Math.max(4000, Math.min(500000, Number($('contextChars').value || 64000)));
  state.config.systemPrompt = $('systemPrompt').value;
  state.config.useFileContext = $('useFileContext').checked;
  state.config.rememberKey = $('rememberKey').checked;
  if (!state.config.apiKey || !state.config.baseUrl || !state.config.model) return toast('API key, base URL and model are required');
  saveConfig();
  syncSettingsUi();
  closeSettings();
  updateContextBadge();
  toast('Settings saved');
};

$('clearKey').onclick = () => {
  state.config.apiKey = '';
  state.config.rememberKey = false;
  sessionStorage.removeItem('llm.apiKey');
  localStorage.removeItem('llm.apiKey');
  $('apiKey').value = '';
  $('homeApiKey').value = '';
  $('rememberKey').checked = false;
  $('homeRemember').checked = false;
  updateWelcomeMode();
  toast('API key cleared');
};

$('historyList').addEventListener('click', event => {
  const menuButton = event.target.closest('[data-menu]');
  if (menuButton) {
    event.stopPropagation();
    openHistoryMenu(menuButton.dataset.menu, menuButton);
    return;
  }
  const item = event.target.closest('.history-item');
  if (item) openConversation(item.dataset.id).catch(error => toast(error.message, 4000));
});

$('historyMenu').addEventListener('click', event => {
  const button = event.target.closest('[data-history-action]');
  if (!button || !state.historyMenuId) return;
  const id = state.historyMenuId;
  const action = button.dataset.historyAction;
  closeHistoryMenu();
  if (action === 'rename') openRename(id);
  if (action === 'delete') deleteConversation(id).catch(error => toast(error.message, 4000));
});

$('closeRename').onclick = closeRename;
$('cancelRename').onclick = closeRename;
$('saveRename').onclick = () => saveRename().catch(error => toast(error.message, 4000));
$('renameBackdrop').addEventListener('click', event => { if (event.target === $('renameBackdrop')) closeRename(); });
$('renameInput').addEventListener('keydown', event => { if (event.key === 'Enter') saveRename().catch(error => toast(error.message, 4000)); });

$('attachmentTray').addEventListener('click', event => {
  const button = event.target.closest('[data-remove-file]');
  if (!button || button.disabled) return;
  state.attachments = state.attachments.filter(file => file.id !== button.dataset.removeFile);
  renderAttachmentTray();
});

$('messages').addEventListener('click', async event => {
  let button = event.target.closest('[data-code-action]');
  if (button) {
    const block = button.closest('.code-block');
    const code = block?.querySelector('code')?.textContent || '';
    const action = button.dataset.codeAction;
    if (action === 'copy') {
      await copyText(code);
      const label = button.querySelector('span');
      const old = label?.textContent;
      if (label) label.textContent = 'Copied';
      setTimeout(() => { if (label) label.textContent = old || 'Copy'; }, 1200);
      return;
    }
    if (action === 'download') {
      const ext = block?.dataset.ext || 'txt';
      const fileName = ext === 'Dockerfile' ? 'Dockerfile' : `code.${ext}`;
      downloadText(fileName, code);
      return;
    }
    if (action === 'wrap') {
      block?.classList.toggle('wrap-code');
      return;
    }
  }

  button = event.target.closest('[data-copy-msg]');
  if (button) {
    await copyText(state.messages[Number(button.dataset.copyMsg)]?.content || '');
    toast('Copied');
    return;
  }

  button = event.target.closest('[data-download-msg]');
  if (button) {
    const index = Number(button.dataset.downloadMsg);
    downloadText(`assistant-${index + 1}.md`, state.messages[index]?.content || '', 'text/markdown;charset=utf-8');
    return;
  }

  button = event.target.closest('[data-regenerate]');
  if (button) {
    if (state.messages[state.messages.length - 1]?.role === 'assistant') state.messages.pop();
    await sendMessage({ regenerate: true });
    return;
  }

  button = event.target.closest('[data-edit-msg]');
  if (button) {
    beginEditMessage(Number(button.dataset.editMsg));
    return;
  }

  button = event.target.closest('[data-edit-cancel]');
  if (button) {
    state.editingIndex = null;
    renderMessages();
    return;
  }

  button = event.target.closest('[data-edit-save]');
  if (button) {
    await saveEditedMessage(Number(button.dataset.editSave));
  }
});

$('chatView').addEventListener('scroll', () => {
  state.userScrolledUp = !nearBottom();
  updateScrollButton();
});

document.addEventListener('click', event => {
  if (!event.target.closest('#historyMenu') && !event.target.closest('[data-menu]')) closeHistoryMenu();
  if (!event.target.closest('#exportMenu') && !event.target.closest('#exportBtn')) $('exportMenu').classList.add('hidden');
});

document.addEventListener('keydown', event => {
  const modifier = event.ctrlKey || event.metaKey;
  if (modifier && event.key.toLowerCase() === 'k') {
    event.preventDefault();
    $('historySearch').focus();
  }
  if (modifier && event.shiftKey && event.key.toLowerCase() === 'o') {
    event.preventDefault();
    newChat();
  }
  if (event.key === 'Escape') {
    closeMenus();
    if (!$('modalBackdrop').classList.contains('hidden')) closeSettings();
    if (!$('renameBackdrop').classList.contains('hidden')) closeRename();
  }
});

let dragDepth = 0;
document.addEventListener('dragenter', event => {
  if (!event.dataTransfer?.types?.includes('Files')) return;
  dragDepth++;
  $('dropOverlay').classList.remove('hidden');
});
document.addEventListener('dragleave', event => {
  if (!event.dataTransfer?.types?.includes('Files')) return;
  dragDepth = Math.max(0, dragDepth - 1);
  if (dragDepth === 0) $('dropOverlay').classList.add('hidden');
});
document.addEventListener('dragover', event => {
  if (event.dataTransfer?.types?.includes('Files')) event.preventDefault();
});
document.addEventListener('drop', event => {
  if (!event.dataTransfer?.files?.length) return;
  event.preventDefault();
  dragDepth = 0;
  $('dropOverlay').classList.add('hidden');
  uploadFiles(event.dataTransfer.files).catch(error => toast(error.message, 4000));
});

(function init() {
  const storedTheme = localStorage.getItem('theme');
  if (storedTheme === 'dark' || storedTheme === 'light') {
    document.documentElement.dataset.theme = storedTheme;
  } else if (window.matchMedia?.('(prefers-color-scheme: dark)').matches) {
    document.documentElement.dataset.theme = 'dark';
  } else {
    document.documentElement.dataset.theme = 'light';
  }

  syncSettingsUi();
  updateModelBadge();
  updateWelcomeMode();
  renderMessages();
  renderAttachmentTray();
  autoGrow();
  loadConversations().catch(error => toast(error.message, 4000));
})();
