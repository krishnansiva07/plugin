# Advanced AI Chat — Java 17 / Spring Boot

A local ChatGPT-style application built from the supplied Spring Boot + LangChain4j project structure and designed for OpenAI-compatible internal or public model endpoints.

## What this version fixes

The first build had two important rendering problems:

1. The browser SSE parser used `trimStart()` on every streamed `data:` line. That can delete model-generated leading spaces, including Java/Python indentation and spaces between streamed words.
2. The Markdown renderer only recognized a completed triple-backtick block. While a response was still streaming, an unfinished code fence was rendered as normal text and then jumped into a code block only after the closing fence arrived.

This version fixes both. Every streamed model token is wrapped in JSON before it crosses SSE, so whitespace and newlines survive exactly, and incomplete fenced code is rendered as a code block immediately while streaming.

## Included

### Chat experience

- Home-page API key, base URL and model configuration
- API key is not persisted by the backend
- OpenAI-compatible `/chat/completions` streaming
- Stop generation
- Persistent H2 chat history
- New chat without creating empty database conversations
- Search, open, rename and delete history
- Edit an earlier user message and rewind later messages
- Regenerate the latest response
- Copy complete user/assistant messages
- Download individual assistant responses as Markdown
- Export complete conversations as Markdown or JSON
- Light/dark theme
- Mobile/responsive layout

### Code and Markdown rendering

- Exact whitespace-preserving streaming
- Triple-backtick code fences recognized during streaming, even before the closing fence arrives
- Language labels such as Java, JavaScript, TypeScript, Python, JSON, XML, SQL, Bash and YAML
- Language auto-detection when a model forgets the code-fence language
- Copy code
- Download code with a suitable extension
- Toggle code line wrapping
- Correct headings H1–H6
- Bold, italic, strike-through and inline code
- Ordered/unordered/task lists
- Blockquotes
- Horizontal rules
- Markdown links
- Markdown tables with horizontal scrolling
- Raw HTML is escaped rather than executed

### Context and files

- Full visible history remains in H2 while only a bounded context is sent to the model
- Configurable context-character budget
- Built-in system prompt that explicitly requires valid fenced code and keeps filenames outside code blocks
- Custom system prompt override
- Temperature and maximum-output-token controls
- Drag-and-drop files
- Clipboard image/file paste
- Multi-file attachments
- Attachment-only prompts
- Uploaded files shown again when reopening chat history
- Download original uploaded files from the message
- Apache Tika extraction for PDF, Word, PowerPoint, Excel, text, HTML and many other document formats
- Relevant text-chunk selection from large documents
- Images sent as OpenAI-compatible multimodal `image_url` data when the selected model supports vision
- Text-only documents remain compatible with text-only model endpoints; multimodal array content is used only when an image is actually attached

## Architecture

```text
Browser UI
   |
   v
ChatController
   |
   v
ChatService
   |
   +--> ConversationService --> H2 history
   |
   +--> ContextService
   |       |
   |       +--> FileContextSelector --> relevant document excerpts
   |       +--> image attachments --> multimodal content when required
   |
   v
OpenAiCompatibleClient
   |
   v
{baseUrl}/chat/completions
   |
   v
JSON-wrapped token SSE
   |
   v
Whitespace-safe Markdown/code renderer
```

The LangChain4j dependencies from the supplied base are retained so agent/tool/RAG orchestration can be added without changing the UI, history and file layers. The active streaming transport deliberately uses the provider-neutral OpenAI-compatible HTTP contract so custom internal endpoints and streaming are not tied to one older LangChain4j API surface.

## Build and run

Requirements:

- Java 17+
- Maven 3.8+

Build:

```bash
mvn clean package
```

Run:

```bash
java -jar target/advanced-ai-chat-1.0.0-SNAPSHOT.jar
```

Or on Windows:

```bat
run.bat
```

Then open:

```text
http://localhost:8090
```

## Model configuration

Enter these on the home page:

- **API key** — your model token
- **Base URL** — for example `https://host/api/v1`
- **Model** — the exact deployed model name

The application calls:

```text
{baseUrl}/chat/completions
```

If the supplied Base URL already ends in `/chat/completions`, it is used as-is.

## API-key behavior

By default the key is stored only in browser `sessionStorage`. If **Remember API key on this device** is checked, the browser uses `localStorage`. The backend receives the key in the current chat request's `Authorization: Bearer ...` header and does not write it to H2 or `application.properties`.

Do not commit real API keys to source control.

## Runtime data

```text
./data/chatdb.*
./data/uploads/<conversation-id>/
```

Deleting the local `data` directory resets local conversations and upload metadata.

## Provider notes

The selected endpoint needs to implement the OpenAI-compatible chat-completions contract. Image attachments additionally require a vision-capable model/provider. Features such as provider-native web search, voice, image generation, remote code execution, proprietary connectors and scheduled tasks require explicit tool endpoints and are not assumed to exist on every OpenAI-compatible model server.

## V3 UI formatting

The UI renderer has been upgraded for polished ChatGPT-style output: improved paragraph flow, nested lists, readable tables, callouts, inline code and links, and code blocks with syntax coloring, line numbers, Copy, Download and Wrap controls. See `FORMATTING.md`.

Package label: Advanced AI Chat V3 (UI formatting build).
