# Architecture

## Request lifecycle

1. The browser keeps the API key in session storage by default.
2. The UI creates a conversation only when the first message/file actually needs one, avoiding empty history rows.
3. `ChatController` receives the request plus the API key in the Authorization header.
4. `ChatService` persists the user message and validates that attachment IDs belong to the current conversation.
5. `ContextService` builds the bounded model context while the full conversation remains persisted in H2.
6. `FileContextSelector` ranks extracted document chunks against the current question and adds only what fits the configured budget.
7. For normal documents, content remains a plain text chat message for maximum provider compatibility. Multimodal message arrays are created only when images are attached.
8. `OpenAiCompatibleClient` streams `/chat/completions` from the selected model endpoint.
9. `ChatService` wraps each streamed token as JSON `{ "text": "..." }` before emitting it as SSE. This prevents transport parsing from corrupting leading spaces, indentation or newlines.
10. The browser renders the active assistant message without re-creating the complete conversation DOM on every token.
11. The Markdown renderer recognizes both completed and currently-open fenced code blocks, so code stays code throughout streaming.
12. The final assistant response is persisted in H2 and can be reopened, copied, downloaded, regenerated or exported.

## Rendering pipeline

```text
raw model text
    |
    +--> fenced-block scanner
    |       +--> completed code fence
    |       +--> open/streaming code fence
    |
    +--> Markdown block parser
    |       +--> headings
    |       +--> lists/tasks
    |       +--> blockquotes
    |       +--> tables
    |       +--> paragraphs
    |
    +--> safe inline formatter
            +--> inline code
            +--> bold/italic/strike
            +--> safe links
            +--> HTML escaping
```

## Context management

The application intentionally separates **stored chat history** from **model context**.

- H2 keeps the entire conversation.
- The model receives the system prompt, a bounded set of recent messages and the current user message.
- Relevant document excerpts use a separate sub-budget.
- The current user message is never silently dropped merely because older history filled the configured budget.
- Large document excerpts are ranked and clipped to fit.

## Agent / graph extension point

The clean insertion point is between `ContextService` and `OpenAiCompatibleClient`.

Possible nodes:

```text
Intent Router
   |-- Normal Chat
   |-- Document RAG
   |-- Web/Search Tool
   |-- REST/API Tool
   |-- SQL Tool
   |-- Code Sandbox
   |-- Approval Node
   `-- Response Synthesizer
```

That lets you add LangChain4j AI Services, a Java graph/orchestrator, or an external LangGraph service later while keeping history, rendering, settings, uploads and downloads unchanged.
