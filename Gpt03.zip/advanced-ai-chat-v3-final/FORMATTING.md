# UI Formatting Improvements — V3

This version focuses on the quality of the rendered assistant response, not only the chat shell.

## Fixed

- Markdown soft line breaks now render as normal paragraph wrapping instead of forcing a `<br>` after every streamed/model line.
- Nested bullet and numbered lists are rendered with proper indentation.
- Tables have sticky headers, row spacing, zebra treatment, hover state and horizontal scrolling.
- GitHub-style callouts are supported: NOTE, TIP, IMPORTANT, WARNING and CAUTION.
- Headings have stronger typography and spacing while avoiding oversized presentation-style text.
- Inline code, links, quotes and task lists have dedicated formatting.
- Code blocks now include syntax-aware coloring, line numbers, language label, copy, download and wrap controls.
- Streaming code continues to preserve exact whitespace.
- Mobile layout keeps code controls compact and tables scrollable.

## Model formatting guidance

The built-in system prompt now asks the model to produce UI-friendly Markdown: short paragraphs, meaningful headings, lists for grouped information, numbered steps for procedures, tables only for comparisons, and fenced language-tagged code blocks.
