#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../.."
TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT
javac --release 17 -d "$TMP" \
  $(find qa/eliya87-opencode/stubs -name '*.java') \
  src/main/java/com/llmart/llm/service/OpenCodeLocalRuntime.java \
  src/main/java/com/llmart/llm/service/OpenCodeProxyConfig.java \
  src/main/java/com/llmart/llm/service/OpenCodeTokenLedger.java \
  src/main/java/com/llmart/llm/service/OpenCodeExecutionService.java \
  qa/eliya92-engine-selection/EngineSelectionSmoke.java \
  qa/eliya92-engine-selection/NoModelPreflightSmoke.java \
  qa/eliya92-engine-selection/RemoteCompletionSmoke.java
java -cp "$TMP" EngineSelectionSmoke
java -cp "$TMP" NoModelPreflightSmoke
java -cp "$TMP" RemoteCompletionSmoke
node qa/eliya92-engine-selection/verify.cjs
node --check src/main/resources/static/app.js
