import com.fasterxml.jackson.databind.ObjectMapper;
import com.llmart.llm.service.OpenCodeExecutionService;
import java.lang.reflect.*;
import java.nio.file.*;
import java.util.*;

/** Check actual OpenCode v2 tool-event shapes without consuming model tokens. */
public class OpenCodeLiveActionSmoke {
  private static void verify(boolean condition, String message) {
    if (!condition) throw new AssertionError(message);
  }
  @SuppressWarnings("unchecked")
  public static void main(String[] args) throws Exception {
    Path journal = Files.createTempDirectory("eliya108-actions-");
    System.setProperty("eliya.opencode.sessionStore", journal.toString());
    var service = new OpenCodeExecutionService(new ObjectMapper(), null,
        "legacy", "http://127.0.0.1:4096", "", "opencode", false);
    Class<?> sessionType=Class.forName("com.llmart.llm.service.OpenCodeExecutionService$Session");
    Constructor<?> constructor=sessionType.getDeclaredConstructor(String.class,String.class,String.class,String.class,String.class,String.class);
    constructor.setAccessible(true);
    String id="oc-12345678-1234-1234-1234-123456789123";
    Object session=constructor.newInstance(id,"ses-abc","conv","project","qwen3.8-27b","Make a file");
    Field status=sessionType.getDeclaredField("status");status.setAccessible(true);status.set(session,"running");
    Field sessions=OpenCodeExecutionService.class.getDeclaredField("sessions");sessions.setAccessible(true);
    ((Map<String,Object>)sessions.get(service)).put(id,session);
    Method read=OpenCodeExecutionService.class.getDeclaredMethod("readEvent",sessionType,String.class,String.class,String.class);
    read.setAccessible(true);
    String[] records={
      "{\"id\":\"ev1\",\"type\":\"session.tool.input.started\",\"data\":{\"id\":\"call-7\",\"name\":\"bash\"}}",
      "{\"id\":\"ev2\",\"type\":\"session.tool.input.ended\",\"data\":{\"id\":\"call-7\",\"text\":\"{\\\"command\\\":\\\"echo HELLO\\\",\\\"description\\\":\\\"Write sample\\\"}\"}}",
      "{\"id\":\"ev3\",\"type\":\"session.tool.called\",\"data\":{\"id\":\"call-7\",\"input\":{\"command\":\"echo HELLO\"},\"executed\":true}}",
      "{\"id\":\"ev4\",\"type\":\"session.tool.success\",\"data\":{\"id\":\"call-7\",\"content\":[{\"type\":\"text\",\"text\":\"HELLO\\n\"}]}}"
    };
    for(String record:records) read.invoke(service,session,"","",record);
    Map<String,Object> snapshot=service.get(id);
    List<Map<String,Object>> events=(List<Map<String,Object>>)snapshot.get("events");
    List<Map<String,Object>> toolEvents=new ArrayList<>();
    for(Map<String,Object> event:events) {
      if(!"agent_step".equals(event.get("type"))) continue;
      Map<String,Object> data=(Map<String,Object>)event.get("data");
      if("call-7".equals(data.get("actionId"))) toolEvents.add(data);
    }
    verify(toolEvents.size()>=3,"Input, running and success must all be available");
    Map<String,Object> last=toolEvents.get(toolEvents.size()-1);
    verify("bash".equals(last.get("tool")), "Tool name must survive execution lifecycle");
    verify("success".equals(last.get("status")), "Tool must transition to success");
    verify(String.valueOf(last.get("args")).contains("echo HELLO"),"Command must be present");
    verify(String.valueOf(last.get("output")).contains("HELLO"),"Output must be present");
    verify(Files.exists(journal.resolve(id+".json")),"Activity must persist when UI is closed");
    verify(Files.readString(journal.resolve(id+".json")).contains("call-7"),"Activity journal must include tool actions");
    read.invoke(service,session,"","",record( "ev5", "session.tool.called", "call-8",
       "{\"command\":\"echo token=SECRET123\"}"));
    String log=String.valueOf(service.get(id).get("events"));
    verify(!log.contains("SECRET123"), "Sensitive command arguments must be redacted");
    service.shutdown();
    System.out.println("PASS: live commands, lifecycle updates, output, redaction, and durable activity journal");
  }
  static String record(String eventId,String type,String id,String input) {
    return "{\"id\":\""+eventId+"\",\"type\":\""+type+"\",\"data\":{\"id\":\""+id+"\",\"input\":"+input+"}}";
  }
}
