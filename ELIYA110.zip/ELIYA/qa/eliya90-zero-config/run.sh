#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../.."
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
javac --release 17 -d "$TMP" \
  $(find qa/eliya87-opencode/stubs -name '*.java') \
  src/main/java/com/llmart/llm/service/OpenCodeLocalRuntime.java \
  src/main/java/com/llmart/llm/service/OpenCodeProxyConfig.java \
  src/main/java/com/llmart/llm/service/OpenCodeTokenLedger.java \
  src/main/java/com/llmart/llm/service/OpenCodeExecutionService.java \
  qa/eliya90-zero-config/ZeroConfigSmoke.java
java -cp "$TMP" ZeroConfigSmoke
