import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.llmart.llm.service.OpenCodeExecutionService;
import com.llmart.llm.service.OpenCodeTokenLedger;
import com.llmart.llm.service.TokenActivityLedger;
import java.lang.reflect.*;
import java.nio.file.*;
import java.util.*;

/** No provider requests. Tests usage semantics, dedupe, task boundary and ELIYA event wiring. */
public class TokenConsumptionSmoke {
 static void ok(boolean pass, String detail) { if (!pass) throw new AssertionError(detail); }
 static long amount(Map<String,Object> result, String key) {return ((Number)result.get(key)).longValue();}
 static JsonNode usage(long in,long out,long read,long write,long reasoning) {
   return new JsonNode(Map.of("input",in,"output",out,"reasoning",reasoning,"cache",Map.of("read",read,"write",write)));
 }
 @SuppressWarnings("unchecked") public static void main(String[] args) throws Exception {
   OpenCodeTokenLedger ledger=new OpenCodeTokenLedger();
   OpenCodeTokenLedger missing=new OpenCodeTokenLedger();
   ok(missing.record("id0","qwen","Code",new JsonNode(Map.of())), "Observed model call without usage should be tracked");
   Map<String,Object> none=missing.taskSnapshot(1000,"opencode","qwen");
   ok("not_reported".equals(none.get("usageStatus")) && !Boolean.TRUE.equals(none.get("providerReported"))
           && amount(none,"unreportedCalls")==1, "Absent is not zero");
   missing.record("id1","qwen","Code",usage(2,2,1,0,0));
   ok("partial".equals(missing.taskSnapshot(1000,"opencode","qwen").get("usageStatus")), "Mixed reported/unreported is partial");
   missing.record("id0","qwen","Code",usage(3,1,0,0,0));
   ok("reported".equals(missing.taskSnapshot(1000,"opencode","qwen").get("usageStatus")), "Late usage reconciles previous unknown call");
   missing.restoreCalls(new JsonNode(missing.exportCalls()));
   ok(amount(missing.taskSnapshot(1000,"opencode","qwen"),"modelCalls")==2, "Restored reported calls");
   OpenCodeTokenLedger unknownRestored=new OpenCodeTokenLedger();
   unknownRestored.record("id2","qwen","Code",new JsonNode(Map.of()));
   unknownRestored.restoreCalls(new JsonNode(unknownRestored.exportCalls()));
   ok(amount(unknownRestored.taskSnapshot(1000,"opencode","qwen"),"unreportedCalls")==1, "Persist unreported calls");
   ok(ledger.record("msg-a","qwen","OpenCode model call",usage(120,30,80,5,10)),"First response");
   ledger.record("msg-a","qwen","OpenCode model call",usage(120,30,80,5,10)); // durable replay
   ledger.reconcileHistory("msg-a","qwen",usage(120,30,80,5,10));
   ledger.record("msg-b","qwen","OpenCode model call",usage(40,20,20,0,4));
   Map<String,Object> first=ledger.taskSnapshot(4000,"opencode","qwen");
   ok(amount(first,"modelCalls")==2,"Deduplicate by assistant message ID");
   ok(amount(first,"providerTotalTokens")==315,"Actual tokens include cache once, but reasoning is inside output");
   ok(amount(first,"providerInputTokens")==160 && amount(first,"providerOutputTokens")==50,"Input/output");
   ok(amount(first,"cachedInputTokens")==100 && amount(first,"cacheWriteTokens")==5,"Cache buckets");
   ok(amount(first,"reasoningTokens")==14,"Reasoning is a subset of output");
   ledger.acceptSessionAggregate(usage(500,100,200,10,30));
   ok(amount(ledger.taskSnapshot(4000,"opencode","qwen"),"providerTotalTokens")==315,"Aggregate update is not added to step totals");
   ledger.nextTask();
   ok(!Boolean.TRUE.equals(ledger.taskSnapshot(0,"opencode","qwen").get("providerReported")),"Task boundary resets task counts");
   ledger.record("msg-c","qwen","OpenCode model call",usage(10,3,2,1,0));
   ok(amount(ledger.taskSnapshot(2000,"opencode","qwen"),"providerTotalTokens")==16,"Second task independent");
   ok(amount(ledger.sessionSnapshot(6000,"opencode","qwen"),"providerTotalTokens")==331,"Session tracks both tasks");
   OpenCodeTokenLedger restored=new OpenCodeTokenLedger();
   List<Map<String,Object>> exported=ledger.exportCalls();
   restored.restoreCalls(new JsonNode(exported));
   ok(amount(restored.sessionSnapshot(6000,"opencode","qwen"),"modelCalls")==3,"Session reload retains calls");
   ok(amount(restored.taskSnapshot(2000,"opencode","qwen"),"modelCalls")==1,"Task reload boundary retained");
   TokenActivityLedger legacy=new TokenActivityLedger();
   legacy.record("Planning",0,0,0,0,0,0,0,true);
   legacy.record("Execute",1,1200,0,0,0,0,0,false);
   List<Map<String,Object>> rows=legacy.snapshot();
   ok(amount(rows.get(0),"reportedCalls")==1,"Reported all-zero counts accepted as real usage");
   ok(amount(rows.get(1),"unreportedCalls")==1,"Missing Legacy usage identified");
   Path dir=Files.createTempDirectory("eliya109-tokens-");
   System.setProperty("eliya.opencode.sessionStore",dir.toString());
   OpenCodeExecutionService service=new OpenCodeExecutionService(new ObjectMapper(), null,"legacy","http://127.0.0.1:4096","","opencode",false);
   Class<?> type=Class.forName("com.llmart.llm.service.OpenCodeExecutionService$Session");
   Constructor<?> ctor=type.getDeclaredConstructor(String.class,String.class,String.class,String.class,String.class,String.class);
   ctor.setAccessible(true);
   String id="oc-12345678-1234-1234-1234-123456789123";
   Object session=ctor.newInstance(id,"ses-a","conversation","project","qwen","Build things");
   Field sessions=OpenCodeExecutionService.class.getDeclaredField("sessions"); sessions.setAccessible(true);
   ((Map<String,Object>)sessions.get(service)).put(id,session);
   Method read=OpenCodeExecutionService.class.getDeclaredMethod("readEvent",type,String.class,String.class,String.class);read.setAccessible(true);
   String event="{\"id\":\"step-1\",\"type\":\"session.step.ended\",\"data\":{\"assistantMessageID\":\"assistant-1\",\"tokens\":{\"input\":13,\"output\":7,\"reasoning\":2,\"cache\":{\"read\":10,\"write\":0}}}}";
   read.invoke(service,session,"","",event);
   Map<String,Object> from=(Map<String,Object>)service.get(id).get("usage");
   ok(amount(from,"providerTotalTokens")==30,"Real ELIYA OpenCode event wire");
   read.invoke(service,session,"","",event); // repeated event
   ok(amount((Map<String,Object>)service.get(id).get("usage"),"providerTotalTokens")==30,"Repeated SSE event not doubled");
   read.invoke(service,session,"","","{\"id\":\"session-usage\",\"type\":\"session.usage.updated\",\"data\":{\"sessionID\":\"ses-a\",\"tokens\":{\"input\":200,\"output\":20,\"reasoning\":0,\"cache\":{\"read\":40,\"write\":0}}}}");
   ok(amount((Map<String,Object>)service.get(id).get("usage"),"providerTotalTokens")==30,"Cumulative not added to a prompt");
   ok(Files.exists(dir.resolve(id+".json")),"Usage retained in durable session");
   service.shutdown();
   System.out.println("PASS: source events, replay, cache, reasoning, missing, zero, task/session, restore, Legacy usage");
 }
}
