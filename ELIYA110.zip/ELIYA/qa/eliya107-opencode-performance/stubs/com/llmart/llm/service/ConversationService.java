package com.llmart.llm.service;
import java.util.List;
import java.util.Map;
public class ConversationService {
  public void require(String id){}
  public Message addMessage(String id, String role, String text, List<?> attachments){return new Message();}
  public Object messageDto(Message message){return Map.of();}
  public static class Message {public String getId(){return "msg-1";}}
}
