import java.lang.reflect.*;
import java.util.*;
/** Static privacy-safe diagnostics contract, without a live company model. */
public class OpenCodePerformanceSmoke {
  static void ok(boolean v,String s){if(!v)throw new AssertionError(s);}
  @SuppressWarnings("unchecked")
  public static void main(String[] args) throws Exception {
    Class<?> type = Class.forName("com.llmart.llm.service.OpenCodeExecutionService$Session");
    Constructor<?> ctor = type.getDeclaredConstructor(String.class,String.class,String.class,String.class,String.class,String.class);
    ctor.setAccessible(true);
    Object session = ctor.newInstance("oc-1","remote-1","conv-1","workspace-1","qwen3.8-27b","task");
    for(var item:Map.of("startupMs",1200L,"modelCheckMs",340L,
            "sessionCreationMs",85L,"promptAdmissionMs",140L,"firstModelEventMs",3150L,
            "verificationMs",480L).entrySet()) {
      Field f=type.getDeclaredField(item.getKey()); f.setAccessible(true); f.setLong(session,item.getValue());
    }
    Method snapshot = type.getDeclaredMethod("snapshot");snapshot.setAccessible(true);
    Map<String,Object> state=(Map<String,Object>)snapshot.invoke(session);
    Map<String,Long> t=(Map<String,Long>)state.get("timingsMs");
    ok(t.size()==6,"Expected all six timing stages");
    ok(t.get("firstModelOrToolEvent")==3150L,"First event timing missing");
    Class<?> bridge=Class.forName("com.llmart.llm.service.UnifiedOpenCodeChatBridge");
    Method format=bridge.getDeclaredMethod("formatTimings",Object.class); format.setAccessible(true);
    String report=(String)format.invoke(null,t);
    ok(report.contains("Time to first model/tool activity: 3.15s"),"Timing report missing critical stage: "+report);
    ok(!report.contains("qwen")&&!report.contains("apiKey"),"Timing report leaked provider detail");
    ok(((String)format.invoke(null, Map.of())).isBlank(),"Empty timing report should be suppressed");
    System.out.println("PASS: six measured stages, safe UI report, no model/credential information");
  }
}
