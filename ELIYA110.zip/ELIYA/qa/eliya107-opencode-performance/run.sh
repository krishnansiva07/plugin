#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../.."
TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT
javac --release 17 -d "$TMP" $(find qa/eliya87-opencode/stubs -name '*.java') \
  qa/eliya107-opencode-performance/stubs/com/llmart/llm/service/ConversationService.java \
  src/main/java/com/llmart/llm/service/OpenCodeUiProviderConfig.java \
  src/main/java/com/llmart/llm/service/OpenCodeNetworkDiagnostics.java \
  src/main/java/com/llmart/llm/service/OpenCodeLocalRuntime.java \
  src/main/java/com/llmart/llm/service/OpenCodeProxyConfig.java \
  src/main/java/com/llmart/llm/service/OpenCodeTokenLedger.java \
  src/main/java/com/llmart/llm/service/OpenCodeExecutionService.java \
  src/main/java/com/llmart/llm/service/UnifiedOpenCodeChatBridge.java \
  qa/eliya107-opencode-performance/OpenCodePerformanceSmoke.java
java -cp "$TMP" OpenCodePerformanceSmoke
node --check src/main/resources/static/app.js
