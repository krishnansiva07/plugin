#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../.."
TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT
javac --release 17 -d "$TMP" \
  src/main/java/com/llmart/llm/service/OpenCodeUiProviderConfig.java \
  src/main/java/com/llmart/llm/service/OpenCodeProxyConfig.java \
  qa/eliya105-provider-compat/OpenCode105CompatibilitySmoke.java
java -cp "$TMP" com.llmart.llm.service.OpenCode105CompatibilitySmoke
