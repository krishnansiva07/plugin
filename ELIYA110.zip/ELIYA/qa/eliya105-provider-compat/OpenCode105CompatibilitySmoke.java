package com.llmart.llm.service;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;

public class OpenCode105CompatibilitySmoke {
    static void check(boolean value, String message) {
        if (!value) throw new AssertionError(message);
    }
    @SuppressWarnings("unchecked")
    public static void main(String[] args) throws Exception {
        OpenCodeUiProviderConfig configured = new OpenCodeUiProviderConfig(
                "https://company.example/v1/chat/completions", "qwen3.8-27b", "private-key-for-test");
        Map<String,Object> root = configured.config();
        check("eliya-ui/qwen3.8-27b".equals(root.get("model")), "Should use UI-selected model");
        Map<String,Object> provider = (Map<String,Object>) ((Map<?,?>) root.get("providers")).get("eliya-ui");
        Map<String,Object> settings = (Map<String,Object>) provider.get("settings");
        Map<String,Object> compat = (Map<String,Object>) provider.get("compatibility");
        check("https://company.example/v1".equals(settings.get("baseURL")), "Endpoint root wrong");
        check("{env:ELIYA_OPENCODE_MODEL_API_KEY}".equals(settings.get("apiKey")), "Credential must be env reference");
        check("max_tokens".equals(compat.get("maxTokensField")), "Internal gateway needs conservative max_tokens");
        check(Boolean.FALSE.equals(compat.get("streamUsage")), "Usage streaming should be disabled for compatibility");
        check(Boolean.FALSE.equals(compat.get("requireFinishReason")), "Finish reason should be optional");
        Map<?,?> model = (Map<?,?>)((Map<?,?>)provider.get("models")).get("qwen3.8-27b");
        Map<?,?> limit=(Map<?,?>)model.get("limit");
        check(Integer.valueOf(4096).equals(limit.get("output")), "Conservative output limit missing");
        check(!root.toString().contains("private-key-for-test"), "Credential leaked into config");
        check("private-key-for-test".equals(configured.processEnvironment().get(OpenCodeUiProviderConfig.KEY_ENV)), "Credential not forwarded securely");

        Path temp = Files.createTempFile("eliya105-npmrc-", ".txt");
        Files.writeString(temp, "# Existing corporate configuration\n" +
                "registry=https://registry.example/\n" +
                "proxy=http://proxy.example:8080\n" +
                "https-proxy=http://proxy.example:8080\n" +
                "noproxy=internal.example,localhost\n");
        try {
            Map<String,String> environment = new HashMap<>();
            OpenCodeProxyConfig.apply(environment, temp);
            check("http://proxy.example:8080".equals(environment.get("HTTPS_PROXY")), "npm HTTPS proxy not inherited");
            check("http://proxy.example:8080".equals(environment.get("HTTP_PROXY")), "npm HTTP proxy not inherited");
            check("internal.example,localhost".equals(environment.get("NO_PROXY")), "npm no-proxy list not inherited");
            Map<String,String> explicit = new HashMap<>();
            explicit.put("HTTPS_PROXY", "http://approved-proxy.example:8443");
            explicit.put("NO_PROXY", "corp.example");
            OpenCodeProxyConfig.apply(explicit, temp);
            check("http://approved-proxy.example:8443".equals(explicit.get("HTTPS_PROXY")), "Explicit proxy was overwritten");
            check("corp.example".equals(explicit.get("NO_PROXY")), "Explicit bypass was overwritten");
            Files.writeString(temp,"proxy=file:///tmp/malicious\nhttps-proxy=not-a-url\n");
            environment.clear();
            OpenCodeProxyConfig.apply(environment, temp);
            check(!environment.containsKey("HTTP_PROXY") && !environment.containsKey("HTTPS_PROXY"),"Invalid proxy accepted");
        } finally { Files.deleteIfExists(temp); }
        System.out.println("PASS: saved ELIYA model/key, OpenAI Chat compatibility and npmrc proxy precedence");
    }
}
