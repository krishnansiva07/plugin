'use strict';
const test=require('node:test');const assert=require('node:assert/strict');
const fs=require('node:fs'),vm=require('node:vm');
const source=fs.readFileSync('src/main/resources/static/app.js','utf8');
const html=fs.readFileSync('src/main/resources/static/index.html','utf8');
const start=source.indexOf('function executionUsageNumbers(');
const end=source.indexOf('/** End-of-activity provider accounting',start);
assert.ok(start>0 && end>start);
const esc=v=>String(v).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
const ctx=vm.createContext({Number,Math,String,Array,esc});
vm.runInContext(source.slice(start,end)+'\nthis.fns={executionUsageNumbers,executionTokenStripHtml};',ctx);
const {executionUsageNumbers,executionTokenStripHtml}=ctx.fns;
test('OpenCode totals include cache exactly once and exclude duplicate reasoning',()=>{
 const item=executionUsageNumbers({engine:'opencode',providerReported:true,modelCalls:2,reportedCalls:2,providerInputTokens:120,providerOutputTokens:30,cachedInputTokens:80,cacheWriteTokens:5,reasoningTokens:12,providerTotalTokens:235,inputExcludesCache:true});
 assert.equal(item.total,235);assert.equal(item.read,80);assert.equal(item.output,30);assert.equal(item.reasoning,12);
 assert.match(executionTokenStripHtml({engine:'opencode',providerReported:true,providerTotalTokens:235,modelCalls:2,inputExcludesCache:true}),/235/);
});
test('Legacy total does not add cached input again',()=>{
 const item=executionUsageNumbers({engine:'legacy',providerReported:true,providerInputTokens:200,providerOutputTokens:50,cachedInputTokens:80,providerTotalTokens:250,inputExcludesCache:false});
 assert.equal(item.total,250);assert.equal(item.read,80);
});
test('Missing provider usage is explicitly unknown, not zero',()=>{
 const item=executionUsageNumbers({engine:'opencode',modelCalls:1,providerTotalTokens:0});
 assert.equal(item.status,'Not reported');
 assert.match(executionTokenStripHtml({engine:'opencode',modelCalls:1}),/Not reported/);
});
test('Partially reported model calls explicitly marked',()=>{
 const item=executionUsageNumbers({engine:'legacy',modelCalls:2,reportedCalls:1,unreportedCalls:1,providerReported:true});
 assert.equal(item.status,'Partial');
});
test('Compare UI has two selectable runs and warnings for mismatched task and model',()=>{
 for(const id of ['usageCompareLegacy','usageCompareOpenCode','usageCompareRun','usageCompareResult'])
   assert.match(html,new RegExp('id="'+id+'"'));
 assert.match(source,/Different instructions:/);assert.match(source,/Different models:/);
 assert.match(source,/usageCompareRun.*addEventListener/);
});
test('Both execution surfaces display token strip, with session progress reconciliation',()=>{
 assert.match(source,/executionTokenStripHtml\(usage,!message\.streaming\)/);
 assert.match(source,/const terminalUsage = detail\.engine==='opencode' \? detail\.usage : progress\.tokenUsage;/);
 assert.match(source,/tokenUsage: raw\.usage \|\| \{\}/);
 assert.match(source,/message\.agentCompletionReport\.tokenUsage = message\.agentProgress/);
 assert.match(source,/Provider token usage/);
});
