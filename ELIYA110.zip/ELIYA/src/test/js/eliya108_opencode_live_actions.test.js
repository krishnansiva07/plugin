'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const source=fs.readFileSync('src/main/resources/static/app.js','utf8');
const start=source.indexOf('const TERMINAL_ACTION_TYPES =');
const end=source.indexOf('function terminalToolCategory(',start);
assert.ok(start>=0 && end>start);
function environment() {
  const context=vm.createContext({terminalUi:{actionHistory:new Map()}, Set, Map, Number, String, Array});
  vm.runInContext(source.slice(start,end)+'\nthis.testFns={terminalVisibleActions,terminalActionState};',context);
  return context.testFns;
}
test('OpenCode tool lifecycle updates one durable Terminal row with command and output',()=>{
  const {terminalVisibleActions}=environment();
  const detail={id:'oc-demo',events:[
    {seq:1,type:'agent_step',data:{tool:'bash',actionId:'call-1',status:'running',detail:'echo hello',args:'echo hello'}},
    {seq:2,type:'agent_step',data:{tool:'bash',actionId:'call-1',status:'success',detail:'echo hello',output:'hello'}},
    {seq:3,type:'agent_step',data:{tool:'read',actionId:'call-2',status:'running',detail:'Read file'}}
  ]};
  const timeline=terminalVisibleActions(detail);
  assert.equal(timeline.length,2);
  assert.equal(timeline[0].seq,1);
  assert.equal(timeline[0].data.status,'success');
  assert.equal(timeline[0].data.output,'hello');
  assert.equal(timeline[1].data.tool,'read');
});
test('Tab switching preserves each session history without cross-tab tool leakage',()=>{
  const {terminalVisibleActions,terminalActionState}=environment();
  terminalVisibleActions({id:'tab-a',events:[{seq:1,type:'agent_step',data:{tool:'bash',actionId:'a',status:'running'}}]});
  terminalVisibleActions({id:'tab-b',events:[{seq:1,type:'agent_step',data:{tool:'edit',actionId:'b',status:'success'}}]});
  const restored=terminalVisibleActions({id:'tab-a',events:[]});
  assert.equal(restored.length,1);
  assert.equal(restored[0].data.actionId,'a');
  assert.equal(terminalActionState('tab-b').events.size,1);
});
test('UI has a dedicated list that re-renders changed tool status and output',()=>{
  assert.match(source,/class="terminal-action-list"/);
  assert.match(source,/const nextMarkup=activities\.length \? activities\.map\(terminalActionHtml\)/);
  assert.match(source,/list\.innerHTML=nextMarkup/);
  assert.match(source,/session\.progress\?\.observedActions/);
});
test('Unified Execute chat renders live OpenCode actions outside collapsed details',()=>{
  assert.match(source,/const openCodeLive = message\.executionEngine==='opencode' && message\.streaming/);
  assert.match(source,/class="opencode-live-console"/);
  assert.match(source,/\$\{openCodeLive\}<details class="agent-run-disclosure"/);
  assert.match(source,/opencode-console-output/);
  assert.match(source,/activityEvents:\(session\.events\|\|\[\]\)\.filter/);
});
test('Background execution monitor reconnects to unified conversation and shows observed actions',()=>{
  assert.match(source,/eliyaTabState\.executionIndicators=indicators/);
  assert.match(source,/session\?\.engine==='opencode' && session\.conversationId/);
  assert.match(source,/await openEliyaChatTab\(String\(session\.conversationId\)\)/);
  assert.match(source,/real actions/);
});
