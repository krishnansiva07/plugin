package com.llmart.llm.service;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.net.URI;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/** Applies existing user npm proxy settings to the isolated OpenCode child process.
 * Never modifies proxy settings on the host or sends proxy values into UI reports.
 * Explicit HTTP(S)_PROXY / NO_PROXY values always take precedence over .npmrc.
 */
public final class OpenCodeProxyConfig {
    private OpenCodeProxyConfig() {}

    static void apply(Map<String,String> env, Path npmrc) {
        if (npmrc == null || !Files.isRegularFile(npmrc)) return;
        Map<String,String> npm = new HashMap<>();
        try {
            for (String line : Files.readAllLines(npmrc, StandardCharsets.UTF_8)) {
                String text = line.trim();
                if (text.isBlank() || text.startsWith("#") || text.startsWith(";")) continue;
                int equal = text.indexOf('=');
                if (equal < 1) continue;
                String k = text.substring(0, equal).trim().toLowerCase(Locale.ROOT);
                if (!k.equals("proxy") && !k.equals("https-proxy") && !k.equals("noproxy")) continue;
                String val = text.substring(equal + 1).trim();
                if ((val.startsWith("\"") && val.endsWith("\"")) ||
                    (val.startsWith("'") && val.endsWith("'"))) val = val.substring(1,val.length()-1);
                npm.put(k, val);
            }
        } catch (IOException | SecurityException ignored) { return; }
        installProxy(env, "HTTP_PROXY", "http_proxy", npm.get("proxy"));
        installProxy(env, "HTTPS_PROXY", "https_proxy", npm.getOrDefault("https-proxy", npm.get("proxy")));
        String bypass = npm.get("noproxy");
        if (!has(env,"NO_PROXY") && !has(env,"no_proxy") && bypass != null && !bypass.isBlank()) {
            env.put("NO_PROXY", bypass);
        }
    }
    private static void installProxy(Map<String,String> env, String upper, String lower, String value) {
        if (has(env,upper) || has(env,lower) || value == null || value.isBlank()) return;
        // Accept an explicit HTTP(S) proxy URL only. No PAC URL evaluation and no
        // disabled TLS verification. The optional userinfo stays in child env only.
        try {
            URI parsed = URI.create(value);
            if (parsed.getHost() != null &&
                ("http".equalsIgnoreCase(parsed.getScheme()) || "https".equalsIgnoreCase(parsed.getScheme()))) {
                env.put(upper, value);
                env.put(lower, value);
            }
        } catch (IllegalArgumentException ignored) { /* ignore malformed npm entries */ }
    }
    private static boolean has(Map<String,String> env, String k) {
        return env.get(k) != null && !env.get(k).isBlank();
    }
}
