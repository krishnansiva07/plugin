package com.llmart.llm.service;

import com.fasterxml.jackson.databind.JsonNode;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * OpenCode v2 model-usage ledger. Step events, message history and replay are different
 * views of the SAME assistant response: key by assistant message ID, never add each event.
 * session.usage.updated is an aggregate snapshot, NOT a delta or model call.
 * Reasoning tokens are a subset of output; cache reads/writes are distinct from input.
 */
public final class OpenCodeTokenLedger {
    private static final int MAX_CALLS = 10000;
    private final LinkedHashMap<String, Call> sessionCalls = new LinkedHashMap<>();
    private final LinkedHashMap<String, Call> taskCalls = new LinkedHashMap<>();
    private Counts sessionReported;

    public synchronized void nextTask() {
        taskCalls.clear();
    }

    public synchronized void acceptSessionAggregate(JsonNode tokens) {
        Counts parsed = parse(tokens);
        if (parsed != null) sessionReported = parsed;
    }

    public synchronized boolean record(String messageId, String model, String activity, JsonNode tokens) {
        Counts amount = parse(tokens);
        if (messageId == null || messageId.isBlank()) return false;
        String key = messageId.strip();
        // Without a token object this is an OBSERVED call with UNREPORTED usage, not zero.
        // A later event/history record may supply the authoritative counters.
        Call previous = sessionCalls.get(key);
        if (previous == null && sessionCalls.size() >= MAX_CALLS) return false;
        if (previous != null && (amount == null || amount.equals(previous.counts))) return false;
        Call call = new Call(key,
                previous == null ? (model == null ? "" : model) : previous.model,
                previous == null ? (activity == null ? "Agent execution" : activity) : previous.activity,
                amount);
        sessionCalls.put(key, call);
        taskCalls.put(key, call);
        return true;
    }

    /** Assistant history can reconcile repeated step events using the same message ID. */
    public synchronized void reconcileHistory(String messageId, String model, JsonNode tokens) {
        record(messageId, model, "Agent execution", tokens);
    }

    public synchronized Map<String,Object> taskSnapshot(long elapsedMs, String engine, String model) {
        return snapshot(taskCalls, elapsedMs, engine, model, false);
    }

    public synchronized Map<String,Object> sessionSnapshot(long elapsedMs, String engine, String model) {
        return snapshot(sessionCalls, elapsedMs, engine, model, true);
    }

    private Map<String,Object> snapshot(Map<String,Call> calls, long elapsedMs, String engine, String model, boolean lifetime) {
        long input=0,output=0,reasoning=0,read=0,write=0,reported=0,unreported=0;
        Map<String,MutableGroup> activities = new LinkedHashMap<>();
        for (Call call : calls.values()) {
            Counts c=call.counts;
            MutableGroup group=activities.computeIfAbsent(call.activity, name->new MutableGroup());
            group.calls++;
            if (c == null) { unreported++; group.unreported++; continue; }
            reported++; group.reported++;
            input+=c.input; output+=c.output; reasoning+=c.reasoning; read+=c.read; write+=c.write;
            group.input+=c.input; group.output+=c.output;
            group.read+=c.read; group.write+=c.write; group.reasoning+=c.reasoning;
        }
        // On OpenCode v2, input excludes cache reads/writes. Never add reasoning on top of output.
        long total=input+output+read+write;
        List<Map<String,Object>> groups=new ArrayList<>();
        for (var row : activities.entrySet()) {
            MutableGroup g=row.getValue();
            Map<String,Object> activity=new LinkedHashMap<>();
            activity.put("activity",row.getKey());activity.put("calls",g.calls);activity.put("reportedCalls",g.reported);
            activity.put("unreportedCalls",g.unreported); activity.put("inputTokens",g.input);
            activity.put("outputTokens",g.output);activity.put("cachedInputTokens",g.read);
            activity.put("cacheWriteTokens",g.write);activity.put("reasoningTokens",g.reasoning);
            activity.put("totalTokens",g.input+g.output+g.read+g.write);
            groups.add(activity);
        }
        List<Map<String,Object>> details=new ArrayList<>();
        for (Call call : calls.values()) {
            Counts c=call.counts;
            Map<String,Object> row=new LinkedHashMap<>();
            row.put("call",details.size()+1);row.put("activity",call.activity);row.put("model",call.model);
            row.put("reported",c != null);row.put("inputTokens",c == null ? 0 : c.input);
            row.put("outputTokens",c == null ? 0 : c.output);
            row.put("cachedInputTokens",c == null ? 0 : c.read);
            row.put("cacheWriteTokens",c == null ? 0 : c.write);
            row.put("reasoningTokens",c == null ? 0 : c.reasoning);
            row.put("totalTokens",c == null ? 0 : c.input+c.output+c.read+c.write);
            details.add(row);
        }
        Map<String,Object> result=new LinkedHashMap<>();
        result.put("modelCallBreakdown",details);
        result.put("engine",engine);result.put("model",model);result.put("scope",lifetime?"session":"task");
        result.put("modelCalls",calls.size());result.put("reportedCalls",reported);
        result.put("unreportedCalls",unreported);result.put("activities",groups);
        result.put("providerInputTokens",input);result.put("providerOutputTokens",output);
        result.put("providerTotalTokens",total);result.put("cachedInputTokens",read);
        result.put("cacheWriteTokens",write);result.put("reasoningTokens",reasoning);
        result.put("providerReported",reported>0);
        result.put("usageStatus",reported==0 ? "not_reported" : unreported>0 ? "partial" : "reported");
        result.put("inputExcludesCache",true);
        result.put("elapsedMs",Math.max(0,elapsedMs));
        result.put("tokensPerSecond",elapsedMs>0 && reported>0
                ? Math.round(total*1000.0/elapsedMs*100.0)/100.0 : null);
        result.put("note","Provider-reported OpenCode v2 assistant steps; input excludes cache, reasoning is included in output. "
                + "Shell commands do not independently consume model tokens. "
                + (unreported>0 ? "Some model calls lack provider-reported usage; totals are incomplete." : ""));
        if (lifetime && sessionReported != null) {
            Map<String,Object> cumulative=new LinkedHashMap<>();
            cumulative.put("inputTokens",sessionReported.input);cumulative.put("outputTokens",sessionReported.output);
            cumulative.put("cachedInputTokens",sessionReported.read);cumulative.put("cacheWriteTokens",sessionReported.write);
            cumulative.put("reasoningTokens",sessionReported.reasoning);
            cumulative.put("totalTokens",sessionReported.input+sessionReported.output+sessionReported.read+sessionReported.write);
            result.put("remoteSessionCumulative",cumulative);
            result.put("note",result.get("note")+" OpenCode session.usage.updated is shown separately, never added to step totals.");
        }
        return result;
    }

    public synchronized List<Map<String,Object>> exportCalls() {
        List<Map<String,Object>> rows = new ArrayList<>();
        for (Call call : sessionCalls.values()) {
            Counts c=call.counts;
            Map<String,Object> item=new LinkedHashMap<>();
            item.put("id",call.id);item.put("model",call.model);item.put("activity",call.activity);
            item.put("task",taskCalls.containsKey(call.id));
            item.put("reported",c != null);
            item.put("input",c == null ? 0 : c.input);
            item.put("output",c == null ? 0 : c.output);
            item.put("reasoning",c == null ? 0 : c.reasoning);
            item.put("read",c == null ? 0 : c.read);
            item.put("write",c == null ? 0 : c.write);
            rows.add(item);
        }
        return rows;
    }

    public synchronized void restoreCalls(JsonNode rows) {
        if (rows == null || !rows.isArray()) return;
        sessionCalls.clear();taskCalls.clear();
        for (JsonNode row : rows) {
            String id=row.path("id").asText("");
            if (id.isBlank() || sessionCalls.size()>=MAX_CALLS) continue;
            boolean recorded= !row.has("reported") || "true".equals(row.path("reported").asText("false"));
            Counts c=recorded ? new Counts(number(row,"input"),number(row,"output"),number(row,"reasoning"),
                    number(row,"read"),number(row,"write")) : null;
            Call call=new Call(id,row.path("model").asText(""),row.path("activity").asText("Agent execution"),c);
            sessionCalls.put(id,call);
            if ("true".equals(row.path("task").asText("false"))) taskCalls.put(id,call);
        }
    }

    private static Counts parse(JsonNode node) {
        if (node == null || !node.isObject() || !node.has("input") || !node.has("output")) return null;
        JsonNode cache=node.path("cache");
        return new Counts(number(node,"input"),number(node,"output"),number(node,"reasoning"),
                number(cache,"read"),number(cache,"write"));
    }
    private static long number(JsonNode obj,String field) {
        try {return Math.max(0,new java.math.BigDecimal(obj.path(field).asText("0")).longValueExact());}
        catch(Exception ignored) {return 0;}
    }
    private record Counts(long input,long output,long reasoning,long read,long write) {}
    private record Call(String id,String model,String activity,Counts counts) {}
    private static final class MutableGroup {long calls,reported,unreported,input,output,reasoning,read,write;}
}
