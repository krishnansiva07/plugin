package com.llmart.llm.controller;

import com.llmart.llm.service.AgentApprovalService;
import com.llmart.llm.service.AgentRunService;
import com.llmart.llm.service.AgentTaskRollbackService;
import java.io.IOException;
import org.springframework.web.bind.annotation.*;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/agent")
public class AgentController {
    private final AgentApprovalService approvals;
    private final AgentRunService runs;
    private final AgentTaskRollbackService rollback;
    @org.springframework.beans.factory.annotation.Autowired(required = false)
    private com.llmart.llm.service.AgentQuestionService questions;
    @org.springframework.beans.factory.annotation.Autowired(required = false)
    private com.llmart.llm.service.ConversationService conversations;

    public AgentController(AgentApprovalService approvals, AgentRunService runs, AgentTaskRollbackService rollback) {
        this.approvals = approvals;
        this.runs = runs;
        this.rollback = rollback;
    }

    @GetMapping("/conversations/{conversationId}/rollback/latest")
    public Map<String,Object> latestRollback(@PathVariable String conversationId, @RequestParam String projectId) throws IOException {
        var target = rollback.latestAvailable(conversationId, projectId, "");
        return target.isPresent() ? rollback.preview(target.get()) : Map.of("available", false);
    }

    @PostMapping("/conversations/{conversationId}/rollback/latest")
    public Map<String,Object> rollbackLatest(@PathVariable String conversationId, @RequestBody Map<String,Object> body) throws IOException {
        String projectId = String.valueOf(body.getOrDefault("projectId", ""));
        String target = rollback.latestAvailable(conversationId, projectId, "")
                .orElseThrow(() -> new IllegalArgumentException("No completed operation available for rollback"));
        return rollback.rollback(target, conversationId, projectId);
    }

    @PostMapping("/approvals/{id}")
    public Map<String, Object> resolve(@PathVariable String id, @RequestBody Map<String, Object> body) {
        String action = String.valueOf(body.getOrDefault("action", "")).trim().toLowerCase();
        AgentApprovalService.Decision decision;
        if ("run".equals(action) || "always".equals(action)) decision = AgentApprovalService.Decision.RUN;
        else if ("once".equals(action) || Boolean.TRUE.equals(body.get("approved"))) decision = AgentApprovalService.Decision.ONCE;
        else decision = AgentApprovalService.Decision.DENY;
        boolean resolved = approvals.resolve(id, decision);
        return Map.of("resolved", resolved, "decision", decision.name().toLowerCase());
    }


    @PutMapping("/runs/{id}/plan")
    public Map<String, Object> updatePlan(@PathVariable String id, @RequestBody Map<String, Object> body) {
        Object raw = body.get("items");
        java.util.List<String> items = new java.util.ArrayList<>();
        if (raw instanceof java.util.Collection<?> values) {
            for (Object value : values) {
                String text = value == null ? "" : String.valueOf(value).trim();
                if (!text.isBlank()) items.add(text);
            }
        }
        AgentRunService.AgentRun run = runs.require(id);
        run.replaceDraftPlan(items);
        return run.snapshot();
    }

    @PostMapping("/runs/{id}/cancel")
    public Map<String, Object> cancel(@PathVariable String id) {
        boolean cancelled = runs.cancel(id);
        int approvalsReleased = approvals.cancelRun(id);
        Map<String,Object> result = new LinkedHashMap<>();
        result.put("cancelled", cancelled);
        result.put("approvalsReleased", approvalsReleased);
        return result;
    }

    @GetMapping("/runs/{id}/artifacts/{index}")
    public Map<String,Object> artifact(@PathVariable String id, @PathVariable int index) throws IOException {
        return rollback.artifactFile(id, index);
    }

    @GetMapping("/runs/{id}/markdown/{index}")
    public Map<String,Object> markdown(@PathVariable String id, @PathVariable int index) throws IOException {
        return rollback.markdownFile(id, index);
    }

    @GetMapping("/runs/{id}/completion-report")
    public Map<String,Object> completionReport(@PathVariable String id) {
        return rollback.completionReport(id);
    }

    @PostMapping("/runs/{id}/answer")
    public Map<String,Object> answerQuestion(@PathVariable String id, @RequestBody Map<String,Object> response) {
        runs.require(id); // prevent writing responses for nonexistent run IDs
        if (questions == null) throw new IllegalStateException("Agent clarification service unavailable");
        String qId = String.valueOf(response.getOrDefault("questionId", ""));
        String choice = String.valueOf(response.getOrDefault("choice", ""));
        String detail = String.valueOf(response.getOrDefault("detail", ""));
        boolean answered = questions.answer(id, qId, choice, detail);
        if (answered && conversations != null) {
            // Preserve the natural-language reply when the conversation is reopened.
            var run = runs.require(id);
            String userAnswer = detail.isBlank() ? choice : detail;
            if (!userAnswer.isBlank()) conversations.addMessage(run.conversationId(), "user", userAnswer, List.of());
        }
        if (answered && "Cancel".equalsIgnoreCase(choice)) runs.cancel(id);
        return Map.of("answered", answered);
    }

    @GetMapping("/runs/recent")
    public List<Map<String,Object>> recentRunUsage() {
        return runs.recentExecutionUsage(60);
    }

    @GetMapping("/runs/{id}")
    public Map<String, Object> status(@PathVariable String id) {
        Map<String,Object> result = new LinkedHashMap<>(runs.status(id));
        if (questions != null) {
            Map<String,Object> question = questions.pending(id);
            if (!question.isEmpty()) { result.put("question", question); result.put("needsInput", true); }
        }
        return result;
    }

    @GetMapping("/conversations/{conversationId}/latest-run")
    public Map<String, Object> latestRun(@PathVariable String conversationId) {
        return runs.latestForConversation(conversationId).orElseGet(Map::of);
    }

    @GetMapping("/conversations/{conversationId}/runs")
    public List<Map<String, Object>> conversationRuns(@PathVariable String conversationId) {
        return runs.forConversation(conversationId);
    }
}
