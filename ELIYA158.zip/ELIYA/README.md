# ELIYA

ELIYA is a local Java/Spring Boot AI development assistant with browser Chat/Analyse/Agent,
terminal sessions, mapped workspaces, reference projects, lexical and semantic retrieval,
change verification, cancellation, and durable run history.

## Release/certification status

**This is a source stabilization package, not a production-certified executable.** Do not
replace a running installation until the full Maven verification and live-model end-to-end
acceptance succeed on the intended host. A passing source-level test is not proof that a
live provider/tool/browser workflow is correct.

## What changed in this checkpoint

- **Human-readable task outcomes:** completed, blocked and failed Agent tasks now include a grounded account of finished steps, tracked changes, unfinished work, verification, improvement opportunities and the next action. Operational exceptions are saved as assistant turns instead of only emitting a transient stream error.
- **Correct failure-stage display:** the durable backend preserves the stage where a run stopped, including across restarts. The UI uses that stage instead of falsely coloring Plan red; if no stage is known, it avoids inventing one. Blocked/failed progress is clearly labeled as *not complete* even if activity reached a high percentage.
- **Recovered conversation outcomes:** saved runs with empty/generic responses reconstruct a cautious summary from their recorded evidence, and detailed reports load automatically after the run ends.
- **Autonomous run recovery:** every unfinished queued/running/cancelling/waiting state is
  marked interrupted after service restart; terminal states are finalized. Retains durable
  original task contract across resumed large tasks, together with work items and verification
  history. Does not silently resume an interrupted command.
- **Execution monitor:** terminal and browser runs are aggregated by run ID. An active browser
  SSE stream awaiting backend confirmation is shown as `connecting`, not falsely as `0 running`
  or asserted as a verified backend execution.
- **Index recovery:** a restored project index-status request can initiate the single bounded
  background index worker even if no earlier project GET occurred. Failed scans do not cause
  an infinite auto-retry on subsequent status polls.
- **Incomplete indexes:** scans hitting filesystem/file-count limits are explicitly marked
  failed, not falsely advertised as a complete index. Previous results stay fenced.
- **Semantic retrieval:** credential-free embedding requests are allowed only to HTTP
  loopback endpoints; external endpoints still require credentials. Semantic failures keep
  lexical search available and are not treated as verified semantic success.
- **Large repositories:** graph enrichment is bounded to the top-scoring 1,600 nearby files
  above 10,000 indexed files; large-workspace overviews avoid an unbounded series of fresh
  filesystem-stat calls and clearly mark the cached file manifest as not fully rechecked.
- **Build discipline:** build scripts now run `clean verify` with the Maven full-test profile;
  compilation/test failure and missing/non-executable JAR fail the build instead of claiming
  release success.
- **Regression:** updated outdated source and UI assertions, preserving complete long-prompt
  handoffs and testing honest active-run reporting.

## Offline validation evidence

For these completion-reporting changes, Java 17 syntax parsing of the modified Java files and an executable narrator harness passed. Offline checks of verification, stage restoration, rollback gating, browser rendering, and source safety passed. **The new JUnit tests have been added but have not been run using Maven** because the dependency repository is unavailable here.

See `validation/acceptance-results.txt` for the repeatable verification commands and results.
The executed checks included:

- JavaScript tests, including QA test files: **200 passed, 0 failed**.
- Chromium browser tests for 5,000-line Markdown/HTML exports, mobile rendering, UI progress,
  approvals, chat history and client-side recovery: **passed**.
- Agent policies, protected snapshot checks, cancellation/deadline, strict completion,
  autonomous artifact verification and token comparison policy: **passed**.
- An executable offline Java test compiling the real indexing, retrieval, checkpoint,
  token-ledger and agent-run persistence classes with isolated annotation/provider stubs:
  **12,051 synthetic TypeScript files indexed**; recent isolated replay approximately 922 ms indexing and 99 ms retrieval
  in one recorded run at a 768 MB heap limit. Incremental deletion, persisted-index refresh,
  live source filtering, restart recovery and large-task contract preservation passed.
  Synthetic throughput must not be extrapolated to a production workspace.

## Read-only test inventory in Analyse

- Plain questions such as "How many test cases are present?" automatically use the currently
  mapped workspace; the user does not need to say "workspace". A named reference alias
  selects that reference instead.
- The system reads **actual test source files**, selected from the already loaded workspace
  index, without running tests or changing code. It counts Playwright/Jest-style
  `test()`/`it()` declarations, Java JUnit/TestNG annotations, Cucumber scenario
  declarations, and Python `test_` functions, and supplies file-path evidence. README
  descriptions and the number of spec files are not used to invent a count.
- This is a **static declaration count**, not the full runner-expanded number of cases.
  `test.each`, Java data providers, Cucumber Example rows, loops, configuration projects,
  skips, and other dynamic expansion may change the runtime count. Use
  `npx playwright test --list` on a suitable host for Playwright's actual discovery.
- A missing/incomplete index, unreadable/oversized tests or inventory safety limit
  produces an **explicit incomplete/lower-bound** result, not a false confirmed count.
  The operation is read-only, bounded and cancellation-aware; it does not start a full
  workspace filesystem rescan. This fixes this count workflow, not every possible
  Analyse source-retrieval question.
- The UI treats a test-count inventory question as an inventory, not as an assertion
  about test execution or migration success; a true verification question retains
  the evidence warning.

**Validation for this additional change:** 202/202 JavaScript and QA tests passed;
Java source inventory compiled and a 5-assertion standalone Java harness passed.
The new JUnit test source is included, but JUnit/Maven execution and a full JAR build
remain unverified on this offline host (Maven is not installed).

## Still required for full release certification

1. **Maven and JAR:** the build could not run here because Maven is not installed and the
   environment cannot resolve `repo.maven.apache.org`. A full Spring Boot compile, test,
   packaged `target/eliya.jar` and start-up check remain unverified. Build on a network-enabled
   host with Java 17+ and Maven, using `./build-jar.sh` or `build-jar-windows.cmd`.
2. **Live Agent and Analyse:** verify successful and failed tasks through both terminal and
   browser, including cancellation, retries, file changes and final evidence after completion.
3. **Model and MCP:** test real LLM, embedding and explicitly requested MCP endpoints with
   valid credentials; source-policy tests do not substitute for live integrations.
4. **Performance:** benchmark actual same-prompt, same-model, same-provider tasks against
   OpenCode using provider-reported tokens and verified output equivalence. Existing
   token-comparison QA runs contain synthetic fixture records.
5. **Actual JVM restart:** verify session recovery by stopping and starting the production JAR
   mid-task, restoring the browser conversation and checking that interrupted work is not
   misrepresented as completed.
6. **Large real repository:** run 10k-100k files on the target OS with its symlinks, document
   formats, ignore rules, memory profile and embedding model. The synthetic test isolates the
   indexing implementation, not real-world variability.

**No claim of complete implementation or production readiness is made for these unverified items.**

## Reproduce

```bash
bash qa/stabilization/run.sh
node --test src/test/js/*.test.js qa/*.test.js
bash qa/agent-reliability/run.sh
bash qa/eliya145-validate.sh
bash qa/eliya68-autonomous-verification.sh
bash qa/eliya65-verification-smoke.sh
bash qa/eliya83-token-economy/run.sh
./build-jar.sh
```

On Windows use `build-jar-windows.cmd` to invoke a full Maven verification. Starting the
resulting Spring Boot application is done with `java -jar target/eliya.jar`, normally served
at `http://localhost:8090` unless port settings are changed. Keep model keys out of logs
and packages. Workspace configuration and agent permissions belong to the running instance.
