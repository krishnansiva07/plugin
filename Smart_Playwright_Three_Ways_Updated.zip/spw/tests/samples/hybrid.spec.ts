import { test, expect } from '@playwright/test';
import { AI } from '../../src/framework/AI';
import { shouldRunTest } from '../../src/core/execution/ExecutionFilter';

const meta = { testId: 'TC_HYBRID_001', testName: 'Login combining all three styles', suite: 'Execution Styles', tags: ['smoke', 'hybrid'] };

if (shouldRunTest(meta)) {
  test.describe(meta.suite, () => {
    test(`[${meta.testId}] ${meta.testName} @smoke @hybrid`, async ({ page }) => {
      const ai = AI.on(page);
      await ai.step('Open the application');                         // natural language
      await ai.fill('Username', 'standard_user');                    // framework DSL
      await ai.native('Fill password', async p => {                  // native Playwright, still logged
        await p.getByTestId('password').fill('secret_sauce');
      });
      await ai.step('Click Login');                                  // natural language
      await expect(page.getByTestId('title')).toHaveText('Products');
    });
  });
}
