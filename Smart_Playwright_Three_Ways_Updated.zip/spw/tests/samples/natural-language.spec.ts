import { test, expect } from '@playwright/test';
import { AI } from '../../src/framework/AI';
import { shouldRunTest } from '../../src/core/execution/ExecutionFilter';

const meta = { testId: 'TC_NL_001', testName: 'Login using natural language', suite: 'Execution Styles', tags: ['smoke', 'natural-language'] };

if (shouldRunTest(meta)) {
  test.describe(meta.suite, () => {
    test(`[${meta.testId}] ${meta.testName} @smoke @natural-language`, async ({ page }) => {
      await AI.on(page).run([
        'Open the application',
        'Enter standard_user into Username',
        'Enter secret_sauce into Password',
        'Click Login'
      ]);
      await expect(page.getByTestId('title')).toHaveText('Products');
    });
  });
}
