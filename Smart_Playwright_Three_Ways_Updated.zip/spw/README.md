# Smart Playwright LangChain Framework v3.0

A complete TypeScript Playwright framework using installed Chrome/Edge, headed UI mode, JSON test data, colourful HTML reporting, and LangChain-based LLM self-healing.

## 1. Prerequisites
- Node.js 20 LTS or 22 LTS
- npm
- Installed Chrome or Edge
- Corporate CA bundle when required by your office LLM/npm gateway

## 2. Put the CA file
Copy your CA bundle to:

`certificates/cacert`

The extension is optional. The file must be PEM text containing `-----BEGIN CERTIFICATE-----`.

## 3. First-time setup
Open PowerShell in the project root:

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\scripts\setup.ps1
Copy-Item .env.example .env -Force
```

The setup script uses the certificate for npm and runs `npm ci`.

## 4. Configure `.env`
For Chrome first, Edge fallback:

```env
BROWSER=auto
BROWSER_PRIORITY=chrome,edge
```

For LangChain healing:

```env
LLM_ENABLED=true
LLM_API_KEY=your-token
LLM_BASE_URL=https://your-company-llm-endpoint/v1
LLM_MODEL_NAME=your-model
```

Use the same API key, base URL and model name concept as the shared Java LangChain4j client. Do not append `/chat/completions` because LangChain adds it.

## 5. Run

```powershell
npm test
```

`npm test` automatically finds `certificates/cacert`, sets `NODE_EXTRA_CA_CERTS` in a fresh Node process, then starts Playwright.

## 6. Test data
Edit `test-data/login-tests.json`. Set `run` to `false` to skip a row.

## 7. Report
After execution open `reports/index.html`. It includes percentage summary and Serial No., Test ID, Test Name, Status.

## 8. Verify self-healing
In `src/pages/LoginPage.ts`, temporarily make username primary and both fallbacks invalid. Enable LLM. Run `npm test`. Expected terminal output contains `[LLM HEALING] SUCCESS`, and the HTML status becomes `PASSED – HEALED`.

## Troubleshooting
- `self-signed certificate in certificate chain`: confirm `certificates/cacert` is PEM text, then use `npm test` (not direct `npx playwright test`).
- Certificate ignored: Node reads `NODE_EXTRA_CA_CERTS` only at process start; the provided runner starts a fresh process.
- Binary certificate: convert to PEM using `certutil -encode input.cer certificates\cacert.pem`.

## 9. Command-line execution filters

All tests:

```powershell
npm test
```

By Test ID:

```powershell
npm test -- --testid=TC_LOGIN_001
```

By multiple Test IDs:

```powershell
npm test -- --testid=TC_LOGIN_001,TC_LOGIN_003
```

By tag:

```powershell
npm test -- --tag=smoke
npm test -- --tag=@regression
```

By test name:

```powershell
npm test -- --testname="Login with valid credentials"
```

By suite:

```powershell
npm test -- --suite="SauceDemo Login"
```

Combined filters use AND logic between filter types and OR logic for comma-separated values:

```powershell
npm test -- --suite="SauceDemo Login" --tag=regression --testid=TC_LOGIN_003,TC_LOGIN_004
```

Native Playwright arguments are passed through:

```powershell
npm test -- --testid=TC_LOGIN_001 --headed --workers=1
```

The standard npm separator is two normal hyphens: `npm test -- --testid=...`.
The runner also reads npm config-style input such as `npm test --testid=TC_LOGIN_001` where supported by the installed npm version.

Add optional `suite` and `tags` fields to each JSON test row:

```json
{
  "run": true,
  "testId": "TC_ORDER_001",
  "testName": "Create a new order",
  "suite": "Order Management",
  "tags": ["smoke", "order"]
}
```

## 10. Certificate folder

Copy your PEM certificate into `certificates/`. The file may have any name ending in `.pem`, `.crt`, or `.cer`. The runner validates that it contains a PEM certificate block and automatically sets `NODE_EXTRA_CA_CERTS` before Playwright starts.

## 11. Three supported authoring styles

The framework supports natural language, the framework DSL, and native Playwright. They may also be combined in one test.

### Natural language

```ts
const ai = AI.on(page);
await ai.run([
  'Open the application',
  'Enter standard_user into Username',
  'Enter secret_sauce into Password',
  'Click Login'
]);
```

### Framework DSL

```ts
const ai = AI.on(page);
await page.goto('/');
await ai.fill('Username', 'standard_user');
await ai.fill('Password', 'secret_sauce');
await ai.click('Login');
```

### Native Playwright

```ts
await page.goto('/');
await page.getByTestId('username').fill('standard_user');
await page.getByTestId('password').fill('secret_sauce');
await page.getByTestId('login-button').click();
```

### Hybrid test

See `tests/samples/hybrid.spec.ts`. It combines all three styles in one test.

## 12. Reliable comma-separated execution

Filters are now applied before test registration rather than only through Playwright grep. Therefore unmatched tests are not registered and do not create empty browser sessions.

```powershell
npm test -- --testid=TC_NL_001,TC_DSL_001,TC_HYBRID_001
npm test -- --tag=smoke,regression
npm test -- --testname="natural language,framework DSL"
npm test -- --suite="Execution Styles,SauceDemo Login"
```

Within one filter type comma-separated values use OR logic. Different filter types use AND logic.
