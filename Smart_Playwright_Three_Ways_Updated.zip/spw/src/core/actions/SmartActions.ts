import { test, type Locator, type Page } from '@playwright/test';
import { envNumber } from '../../utils/Environment';
import { LlmClient } from '../../llm/LlmClient';

export interface SmartElement { description: string; primary: () => Locator; fallbacks?: Array<() => Locator>; }
export class SmartActions {
  private readonly llm = new LlmClient();
  private readonly minimumConfidence = envNumber('LLM_MIN_CONFIDENCE', 0.85);
  constructor(private readonly page: Page) {}
  async fill(element: SmartElement, value: string): Promise<boolean> { const r = await this.resolve(element, 'fill'); await r.locator.fill(value); return r.healed; }
  async click(element: SmartElement): Promise<boolean> { const r = await this.resolve(element, 'click'); await r.locator.click(); return r.healed; }
  private async isUsable(locator: Locator): Promise<boolean> { try { return (await locator.count()) === 1 && await locator.isVisible(); } catch { return false; } }
  private async resolve(element: SmartElement, action: string): Promise<{ locator: Locator; healed: boolean }> {
    const candidates = [element.primary, ...(element.fallbacks ?? [])];
    for (let i = 0; i < candidates.length; i++) {
      const locator = candidates[i]();
      if (await this.isUsable(locator)) {
        if (i > 0) console.log(`[DETERMINISTIC HEALING] ${element.description} recovered using fallback ${i}`);
        return { locator, healed: i > 0 };
      }
    }
    const maxLength = envNumber('LLM_DOM_MAX_LENGTH', 20000);
    const error = `Unable to find a unique visible element for ${element.description}`;
    const suggestion = await this.llm.suggestLocator({
      elementDescription: element.description,
      failedLocator: element.primary().toString(), action, error,
      pageTitle: await this.page.title(), pageUrl: this.page.url(),
      relevantDom: (await this.page.locator('body').innerHTML()).slice(0, maxLength)
    });
    if (suggestion && suggestion.confidence >= this.minimumConfidence) {
      const healed = this.page.locator(suggestion.selector);
      if (await this.isUsable(healed)) {
        console.log(`[LLM HEALING] SUCCESS selector=${suggestion.selector} confidence=${suggestion.confidence} reason=${suggestion.reason}`);
        try { test.info().annotations.push({ type: 'healed', description: `${element.description} -> ${suggestion.selector}` }); } catch {}
        return { locator: healed, healed: true };
      }
    }
    throw new Error(error);
  }
}
