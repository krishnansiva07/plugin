import { expect, type Locator, type Page } from '@playwright/test';
import { SmartActions, type SmartElement } from '../core/actions/SmartActions';

export type NativeStep = (page: Page) => Promise<void>;

export class AI {
  private readonly actions: SmartActions;

  private constructor(private readonly page: Page) {
    this.actions = new SmartActions(page);
  }

  static on(page: Page): AI { return new AI(page); }

  async step(description: string): Promise<AI> {
    const text = description.trim();
    let match: RegExpMatchArray | null;

    if (/^open (the )?application$/i.test(text)) {
      await this.page.goto('/');
      return this;
    }
    if (/^login using valid credentials$/i.test(text)) {
      await this.fill('Username', process.env.APP_USERNAME ?? 'standard_user');
      await this.fill('Password', process.env.APP_PASSWORD ?? 'secret_sauce');
      await this.click('Login');
      return this;
    }
    if ((match = text.match(/^click\s+(.+)$/i))) {
      await this.click(match[1]); return this;
    }
    if ((match = text.match(/^(?:enter|type|fill)\s+["']?(.+?)["']?\s+(?:in|into)\s+(.+)$/i))) {
      await this.fill(match[2], match[1]); return this;
    }
    if ((match = text.match(/^select\s+["']?(.+?)["']?\s+from\s+(.+)$/i))) {
      await this.select(match[2], match[1]); return this;
    }
    if ((match = text.match(/^verify\s+(.+?)\s+(?:equals|is)\s+["']?(.+?)["']?$/i))) {
      await this.verifyEquals(match[1], match[2]); return this;
    }
    if ((match = text.match(/^verify\s+["']?(.+?)["']?\s+(?:is displayed|is visible)$/i))) {
      await this.verifyText(match[1]); return this;
    }
    throw new Error(`Unsupported natural-language step: ${description}`);
  }

  async run(steps: string[]): Promise<AI> {
    for (const description of steps) await this.step(description);
    return this;
  }

  async native(name: string, operation: NativeStep): Promise<AI> {
    console.log(`[NATIVE PLAYWRIGHT] ${name}`);
    await operation(this.page);
    return this;
  }

  async click(target: string): Promise<AI> {
    await this.actions.click(this.element(target, 'click'));
    return this;
  }

  async fill(target: string, value: string): Promise<AI> {
    await this.actions.fill(this.element(target, 'fill'), value);
    return this;
  }

  async select(target: string, value: string): Promise<AI> {
    const field = this.semantic(target);
    if (await this.isNativeSelect(field)) {
      await field.selectOption({ label: value }).catch(async () => field.selectOption(value));
      return this;
    }
    await this.actions.click(this.element(target, 'click'));
    await this.actions.click(this.element(value, 'click', 'option'));
    return this;
  }

  async verifyText(text: string): Promise<AI> {
    await expect(this.page.getByText(text, { exact: false }).first()).toBeVisible();
    return this;
  }

  async verifyEquals(target: string, expected: string): Promise<AI> {
    const locator = this.semantic(target).first();
    await expect(locator).toContainText(expected, { ignoreCase: true });
    return this;
  }

  private element(target: string, action: 'click' | 'fill', preferredRole?: 'option'): SmartElement {
    const exact = target.trim();
    return {
      description: `${action} target '${exact}'`,
      primary: () => preferredRole
        ? this.page.getByRole(preferredRole, { name: exact, exact: true })
        : this.page.getByTestId(this.toTestId(exact)),
      fallbacks: [
        () => this.page.getByRole(action === 'fill' ? 'textbox' : 'button', { name: exact, exact: true }),
        () => this.page.getByLabel(exact, { exact: true }),
        () => this.page.getByPlaceholder(exact, { exact: false }),
        () => this.page.getByText(exact, { exact: true }),
        () => this.page.locator(`[name="${this.cssEscape(exact)}"]`),
        () => this.page.locator(`[aria-label="${this.cssEscape(exact)}"]`)
      ]
    };
  }

  private semantic(target: string): Locator {
    return this.page.getByLabel(target, { exact: true })
      .or(this.page.getByRole('textbox', { name: target, exact: true }))
      .or(this.page.getByText(target, { exact: true }));
  }

  private async isNativeSelect(locator: Locator): Promise<boolean> {
    try { return await locator.first().evaluate(el => el.tagName.toLowerCase() === 'select'); }
    catch { return false; }
  }

  private toTestId(target: string): string {
    const normalized = target.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
    const known: Record<string, string> = { username: 'username', password: 'password', login: 'login-button' };
    return known[normalized] ?? normalized;
  }

  private cssEscape(value: string): string { return value.replace(/["\\]/g, '\\$&'); }
}
