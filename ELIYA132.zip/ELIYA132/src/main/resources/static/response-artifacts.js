/* ELIYA132: A single, framework-free contract for prompts and user-downloadable artifacts.
 * Source content is never clipped or silently merged; a file is downloadable only
 * when its representation is complete enough to constitute a standalone file.
 */
(function(root,factory){
  const api=factory();
  if(typeof module==='object' && module.exports) module.exports=api;
  if(root) root.EliyaResponseArtifacts=api;
})(typeof window!=='undefined'?window:null,function(){
  'use strict';
  const clean = value=>String(value==null?'':value).replace(/\r\n/g,'\n').trim();
  const safeName = (name,fallback='artifact')=>clean(name).replace(/[^\w .-]+/g,'-').replace(/^\.+/,'').slice(0,80).trim()||fallback;
  const codeBlocks = text => {
    const result=[];
    const regex=/^(`{3,}|~{3,})([^\n]*)\n([\s\S]*?)\n\1\s*$/gm;
    let match;
    while((match=regex.exec(String(text||'')))!==null) result.push({language:clean(match[2]).toLowerCase(),text:match[3],start:match.index,end:regex.lastIndex});
    return result;
  };
  function fullHtml(src){
    const text=clean(src);
    // A fragment, an unfinished tag, or a placeholder is not a downloadable HTML document.
    return /^<!doctype\s+html\b/i.test(text) || /^<html\b/i.test(text)
      ? /<html\b[^>]*>[\s\S]*<\/html\s*>\s*$/i.test(text) && /<body\b[^>]*>/i.test(text) && /<\/body\s*>/i.test(text)
      : false;
  }
  function fullJson(src){try{JSON.parse(clean(src));return true;}catch(_){return false;}}
  function requestedFormat(question){
    const q=String(question||'');
    const artifactIntent=/\b(?:download(?:able)?|file|artifact|export|save\s+as|standalone|self.contained|webpage|website|config(?:uration)?|document|source\s+code|output\s+file|send)\b/i.test(q);
    if (!artifactIntent) return '';
    if(/\b(?:html?|hyml|web\s*page|single.page\s+(?:site|website))\b/i.test(q))return 'html';
    if(/\b(?:yaml|yml)\b/i.test(q))return 'yaml';
    if(/\bjson\b/i.test(q))return 'json';
    if(/\b(?:markdown|\.md\b)\b/i.test(q))return 'md';
    return '';
  }
  function detect(question,answer){
    const format=requestedFormat(question);
    const src=clean(answer);
    if(!src || !format)return {requested:format,ready:false,reason:'Empty response'};
    if(/\[ELIYA:\s*response incomplete\]|Generation stopped/i.test(src))
      return {requested:format,ready:false,reason:'The response was interrupted. Generate a complete file before downloading.'};
    const fences=codeBlocks(src);
    let text='',ext=format;
    if(format==='html'){
      const candidates=[src,...fences.filter(b=>/^(?:html?|xml|)$/.test(b.language)).map(b=>b.text)];
      text=candidates.find(fullHtml)||'';
    }else if(format==='json'){
      const candidates=[src,...fences.filter(b=>/^(?:json|)$/.test(b.language)).map(b=>b.text)];
      text=candidates.find(fullJson)||'';
    }else if(format==='yaml'){
      // Multiple code blocks are separate snippets, never silently concatenated.
      const candidates=fences.filter(b=>/^(?:yaml|yml)$/.test(b.language));
      if(candidates.length===1 && !/\b(?:TODO|\.\.\.|PLACEHOLDER)\b/i.test(candidates[0].text))text=candidates[0].text;
      else if(fences.length===0 && !/^\s*```/m.test(src) && /^\s*[\w"'/-][^\n]*:\s*\S/m.test(src))text=src;
      ext='yml';
    }else if(format==='md'){
      text=src;
      if(fences.length===1 && fences[0].start===0 && fences[0].end===src.length && /^(?:md|markdown)$/.test(fences[0].language))text=fences[0].text;
    }
    const requestedName=String(question||'').match(/(?:^|[\s`'"(])([a-z0-9][a-z0-9_.-]{0,78}\.(?:html?|json|ya?ml|md))\b/i)?.[1];
    const fallback= format==='html'?'generated-page.html':format==='json'?'generated-data.json':format==='yaml'?'generated-config.yml':'generated-document.md';
    const filename=requestedName && (requestedName.toLowerCase().endsWith('.'+ext) || (ext==='yml' && requestedName.toLowerCase().endsWith('.yaml'))) ? safeName(requestedName) : fallback;
    return {requested:format,ready:!!text,extension:ext,content:text,filename,
      reason:text?'':'The response does not contain one complete '+format.toUpperCase()+' artifact.'};
  }
  function isPromptRequest(question){return /\bprompts?\b|\bprompt\s+factory\b/i.test(String(question||''));}
  function promptSections(question,answer){
    if(!isPromptRequest(question))return [];
    const src=clean(answer);
    if(!src || /\[ELIYA:\s*response incomplete\]|Generation stopped/i.test(src))return [];
    // Prompt headings create independent scopes. Heading-less answers are one scope.
    const header=/^#{1,4}\s+((?:(?:prompt|step)\s*\d+|prompt\s*(?:for|to|:)\b|\d+[.:) ]+prompt)[^\n]*)\s*$/gim;
    const fenceSpans=codeBlocks(src);
    const marks=[...src.matchAll(header)].filter(match=>!fenceSpans.some(f=>match.index>=f.start && match.index<f.end));
    if(marks.length<2)return [{title:'Complete prompt',content:src}];
    const before=src.slice(0,marks[0].index).trim();
    const sections=[];
    for(let i=0;i<marks.length;i++){
      const start=marks[i].index, end=i+1<marks.length?marks[i+1].index:src.length;
      const body=src.slice(start,end).trim();
      if(body)sections.push({title:clean(marks[i][1]).slice(0,100),content:body});
    }
    // Shared preamble is context for EVERY independently implementable prompt.
    if(before) for(const section of sections)section.content=before+'\n\n'+section.content;
    return sections;
  }
  function handoffMessage(id,scope,title){
    if(!Number.isSafeInteger(Number(id))||Number(id)<=0)throw new Error('Saved Analyse response required');
    const selected=clean(scope);
    if(!selected)throw new Error('The selected prompt is empty');
    if(selected.length>32000)throw new Error('Selected prompt exceeds the safe handoff size. Divide it into numbered prompts first.');
    return `Implement ONLY the selected prompt from conversation message #${Number(id)} in the currently selected workspace.\n`+
      `Selected scope: ${clean(title||'Prompt')}\n`+
      'This is an explicit scoped handoff. Do not execute unrelated sections, other prompts, or optional enhancements from the source response. ' +
      'Use the selected instructions below as the authoritative task, inspect relevant live files, and verify changes before declaring completion. '+
      'Ask only if a critical requirement prevents safe execution.\n\n'+
      '--- BEGIN SELECTED PROMPT ---\n'+selected+'\n--- END SELECTED PROMPT ---';
  }
  return Object.freeze({codeBlocks,fullHtml,requestedFormat,detect,isPromptRequest,promptSections,handoffMessage,safeName});
});
