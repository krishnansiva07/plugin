# Astra Playwright MCP Final V9

## Main fixes in V9

1. Fixed latest Playwright MCP element argument from `ref` to `target`.
2. Fixed `LinkedHashMap cannot be cast to java.util.List` in `AstraAgentService`.
3. Added safe parsing for LLM decisions.
4. Added MCP session recovery when HTTP returns `404 Session not found`.
5. Fixed Playwright validation command so empty arguments are not passed.

## Run

```bash
mvn clean spring-boot:run
```

Open:

```text
http://localhost:8090/index.html
```

## Important before testing

Kill existing MCP process on port 8931:

```powershell
netstat -ano | findstr :8931
taskkill /PID <PID> /F
```

Then start only Spring Boot. Let the app start MCP.

## Recommended first test

Use Swag Labs or TodoMVC with:

```json
{
  "username": "standard_user",
  "password": "secret_sauce"
}
```

For Swag Labs, scenario:

```text
Login using the provided username and password and verify Products page is displayed.
```
