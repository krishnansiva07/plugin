package com.astra.mcp.service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.WebClient;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicLong;

@Service
public class McpClientService {

    private final WebClient webClient;
    private final ObjectMapper objectMapper = new ObjectMapper();
    private final AtomicLong requestId = new AtomicLong(1);

    @Value("${playwright.mcp.url}")
    private String mcpUrl;

    private String sessionId;

    public McpClientService(WebClient.Builder webClientBuilder) {
        this.webClient = webClientBuilder.build();
    }

    public synchronized void reset() {
        this.sessionId = null;
    }

    public synchronized String getSessionId() {
        return sessionId;
    }

    public synchronized void initialize() {
        Map<String, Object> response = call("initialize", Map.of(
                "protocolVersion", "2025-06-18",
                "capabilities", Map.of(),
                "clientInfo", Map.of(
                        "name", "astra-java-playwright-mcp-client",
                        "version", "1.0.0"
                )
        ));

        if (isError(response)) {
            throw new RuntimeException("MCP initialize failed: " + response);
        }

        if (sessionId == null || sessionId.isBlank()) {
            throw new RuntimeException("MCP initialize succeeded but mcp-session-id header was not returned. Response: " + response);
        }

        Map<String, Object> initializedNotification = notify("notifications/initialized", Map.of());
        if (isError(initializedNotification)) {
            throw new RuntimeException("MCP notifications/initialized failed: " + initializedNotification);
        }
    }

    public synchronized Map<String, Object> call(String method, Object params) {
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("jsonrpc", "2.0");
        body.put("id", requestId.getAndIncrement());
        body.put("method", method);
        body.put("params", params == null ? Map.of() : params);
        return post(body, true);
    }

    public synchronized Map<String, Object> notify(String method, Object params) {
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("jsonrpc", "2.0");
        body.put("method", method);
        body.put("params", params == null ? Map.of() : params);
        return post(body, false);
    }

    public synchronized Map<String, Object> tools() {
        return call("tools/list", Map.of());
    }

    public synchronized Map<String, Object> tool(String toolName, Map<String, Object> arguments) {
        Map<String, Object> safeArguments = normalizeToolArguments(arguments);
        return call("tools/call", Map.of(
                "name", toolName,
                "arguments", safeArguments
        ));
    }

    /**
     * Latest Playwright MCP tool schema uses "target" for element references.
     * Some earlier generated prompts used "ref". This method converts ref -> target.
     */
    private Map<String, Object> normalizeToolArguments(Map<String, Object> arguments) {
        Map<String, Object> normalized = new LinkedHashMap<>();
        if (arguments != null) {
            normalized.putAll(arguments);
        }

        if (!normalized.containsKey("target") && normalized.containsKey("ref")) {
            normalized.put("target", normalized.get("ref"));
            normalized.remove("ref");
        }

        // browser_select_option expects values array. If LLM returns value, convert to values.
        if (normalized.containsKey("value") && !normalized.containsKey("values")) {
            normalized.put("values", java.util.List.of(String.valueOf(normalized.get("value"))));
            normalized.remove("value");
        }

        return normalized;
    }

    public synchronized String snapshot() {
        Map<String, Object> result = tool("browser_snapshot", Map.of());
        return String.valueOf(result);
    }

    public boolean isSessionNotFound(Map<String, Object> result) {
        if (result == null) {
            return false;
        }
        Object status = result.get("status");
        Object body = result.get("body");
        return "404".equals(String.valueOf(status))
                && body != null
                && String.valueOf(body).toLowerCase().contains("session not found");
    }

    public boolean isError(Map<String, Object> result) {
        return result != null && result.containsKey("error");
    }

    private Map<String, Object> post(Map<String, Object> body, boolean expectResponse) {
        McpHttpResult result = webClient.post()
                .uri(mcpUrl)
                .contentType(MediaType.APPLICATION_JSON)
                .header(HttpHeaders.ACCEPT, "application/json, text/event-stream")
                .headers(headers -> {
                    if (sessionId != null && !sessionId.isBlank()) {
                        headers.add("mcp-session-id", sessionId);
                    }
                })
                .bodyValue(body)
                .exchangeToMono(this::toResult)
                .block();

        if (result == null) {
            return Map.of("error", "MCP_NO_RESPONSE");
        }

        String returnedSessionId = result.headers.getFirst("mcp-session-id");
        if (returnedSessionId != null && !returnedSessionId.isBlank()) {
            sessionId = returnedSessionId;
        }

        if (result.status >= 400) {
            return Map.of(
                    "error", "MCP_HTTP_ERROR",
                    "status", result.status,
                    "body", result.body == null ? "" : result.body,
                    "sessionId", sessionId == null ? "" : sessionId
            );
        }

        if (!expectResponse) {
            return Map.of("ok", true, "sessionId", sessionId == null ? "" : sessionId);
        }

        try {
            String json = extractJson(result.body);
            return objectMapper.readValue(json, new TypeReference<Map<String, Object>>() {});
        } catch (Exception e) {
            return Map.of(
                    "error", "MCP_PARSE_ERROR",
                    "message", e.getMessage(),
                    "raw", result.body == null ? "" : result.body,
                    "sessionId", sessionId == null ? "" : sessionId
            );
        }
    }

    private reactor.core.publisher.Mono<McpHttpResult> toResult(ClientResponse response) {
        int status = response.statusCode().value();
        HttpHeaders headers = new HttpHeaders();
        headers.addAll(response.headers().asHttpHeaders());
        return response.bodyToMono(String.class)
                .defaultIfEmpty("")
                .map(body -> new McpHttpResult(status, headers, body));
    }

    private String extractJson(String raw) {
        if (raw == null || raw.isBlank()) {
            return "{}";
        }

        for (String line : raw.split("\\R")) {
            String trimmed = line.trim();
            if (trimmed.startsWith("data:")) {
                String data = trimmed.substring(5).trim();
                if (data.startsWith("{")) {
                    return data;
                }
            }
        }

        int start = raw.indexOf('{');
        int end = raw.lastIndexOf('}');
        if (start >= 0 && end > start) {
            return raw.substring(start, end + 1);
        }
        return "{}";
    }

    private record McpHttpResult(int status, HttpHeaders headers, String body) {}
}
