package com.llmart.llm.service;

import com.llmart.llm.dto.ProjectDto;
import jakarta.annotation.PreDestroy;
import org.springframework.stereotype.Service;

import java.nio.file.Path;
import java.time.Instant;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * One bounded background worker for project/reference indexing. Registering a folder never
 * performs a full filesystem traversal or bulk H2 writes on a servlet/chat thread.
 */
@Service
public class LocalProjectIndexService {
    private final WorkspaceRetrievalIndexService retrieval;
    private final Map<String, Job> jobs = new ConcurrentHashMap<>();
    private final ExecutorService worker = Executors.newSingleThreadExecutor(r -> {
        Thread thread = new Thread(r, "eliya-project-index");
        thread.setDaemon(true);
        return thread;
    });

    public LocalProjectIndexService(WorkspaceRetrievalIndexService retrieval) { this.retrieval = retrieval; }

    public synchronized Map<String, Object> request(ProjectDto project, boolean force) {
        if (project == null || !project.localWorkspace()) throw new IllegalArgumentException("A local project is required");
        Job previous = jobs.get(project.id());
        if (previous != null && previous.path.equals(project.localPath())
                && "queued".equals(previous.phase)) return result(previous);
        if (!force && previous != null && previous.path.equals(project.localPath())
                && "indexing".equals(previous.phase)) return result(previous);
        // A force request while a scan is RUNNING must queue another pass. The
        // currently running scan may have visited the directory before it was deleted.
        if (!force) {
            WorkspaceRetrievalIndexService.IndexStats cached = retrieval.cachedStats(project.id(), Path.of(project.localPath()));
            // Light-touch refresh after a configurable age; never scan on the servlet/Chat thread.
            // The index builder reuses the unchanged file fingerprints, so this is incremental.
            // Set -Deliya.index.autoRefreshMinutes=0 to retain v46's manual-rescan-only behaviour.
            if (cached != null && !refreshDue(cached.generatedAt())) return status(project);
        }
        Job job = new Job(project.id(), project.localPath());
        jobs.put(project.id(), job);
        // Do not serve pre-rescan evidence while the worker is queued or running.
        retrieval.markRescanPending(job.id, Path.of(job.path));
        worker.execute(() -> {
            job.phase = "indexing";
            job.detail = "Scanning source files in the background";
            boolean succeeded = false;
            try {
                // The retrieval index already has bounded file/size/count limits and skips build folders.
                // Do not do the old second walk to copy every source file into the H2 database.
                WorkspaceRetrievalIndexService.IndexStats stats = retrieval.warmRoot(job.id, Path.of(job.path));
                job.files = stats.indexedFiles();
                job.scanned = stats.visitedFiles();
                job.detail = detail(stats);
                succeeded = true;
            } catch (Exception exception) {
                job.detail = exception.getMessage() == null ? exception.getClass().getSimpleName() : exception.getMessage();
                job.phase = "failed";
            } finally {
                job.finishedAt = Instant.now().toString();
                // A newer rescan may already be queued. Only that newest job
                // can release the freshness fence.
                // A failed scan must not re-enable a stale previous index.
                if (jobs.get(job.id) == job && succeeded)
                    retrieval.finishRescan(job.id, Path.of(job.path));
                // Publish completed only after the fresh index is visible to readers.
                job.phase = succeeded ? "completed" : "failed";
            }
        });
        return result(job);
    }

    private static boolean refreshDue(String indexedAt) {
        long minutes;
        try { minutes = Long.parseLong(System.getProperty("eliya.index.autoRefreshMinutes", "0")); }
        catch (NumberFormatException invalid) { minutes = 0; }
        if (minutes <= 0) return false;
        minutes = Math.max(10, Math.min(minutes, 24 * 60));
        try { return Instant.parse(indexedAt).isBefore(Instant.now().minusSeconds(minutes * 60)); }
        catch (Exception invalidTimestamp) { return false; }
    }

    public Map<String, Object> status(ProjectDto project) {
        Job job = jobs.get(project.id());
        if (job != null && job.path.equals(project.localPath())) return result(job);
        WorkspaceRetrievalIndexService.IndexStats cached = retrieval.cachedStats(project.id(), Path.of(project.localPath()));
        if (cached == null) return Map.of("phase", "not_started", "fileCount", 0, "detail", "Index not started");
        Map<String, Object> data = new LinkedHashMap<>();
        data.put("phase", "completed");
        data.put("fileCount", cached.indexedFiles());
        data.put("scannedCount", cached.visitedFiles());
        data.put("indexedCharacters", cached.indexedCharacters());
        data.put("skippedTooLarge", cached.skippedTooLarge());
        data.put("skippedUnsupported", cached.skippedUnsupported());
        data.put("skippedUnreadable", cached.skippedUnreadable());
        data.put("skippedDirectories", cached.skippedDirectories());
        data.put("scanIncomplete", cached.scanIncomplete());
        data.put("detail", detail(cached));
        data.put("finishedAt", cached.generatedAt());
        return data;
    }

    private Map<String, Object> result(Job job) {
        Map<String, Object> data = new LinkedHashMap<>();
        data.put("phase", job.phase);
        data.put("fileCount", job.files);
        data.put("scannedCount", job.scanned);
        var cached = retrieval.cachedStats(job.id, Path.of(job.path));
        data.put("indexedCharacters", cached == null ? 0L : cached.indexedCharacters());
        data.put("skippedTooLarge", cached == null ? 0 : cached.skippedTooLarge());
        data.put("skippedUnsupported", cached == null ? 0 : cached.skippedUnsupported());
        data.put("skippedUnreadable", cached == null ? 0 : cached.skippedUnreadable());
        data.put("skippedDirectories", cached == null ? 0 : cached.skippedDirectories());
        data.put("scanIncomplete", cached != null && cached.scanIncomplete());
        data.put("detail", cached != null && "completed".equals(job.phase) ? detail(cached) : job.detail);
        data.put("fresh", "completed".equals(job.phase) && !retrieval.isRescanPending(job.id, Path.of(job.path)));
        data.put("rescanPending", retrieval.isRescanPending(job.id, Path.of(job.path)));
        if (job.finishedAt != null) data.put("finishedAt", job.finishedAt);
        return data;
    }

    private String detail(WorkspaceRetrievalIndexService.IndexStats stats) {
        String base = stats.indexedFiles() == 0
                ? "No supported files indexed; scanned " + stats.visitedFiles() + " visible files"
                : stats.indexedCharacters() == 0 ? "Files indexed, but no readable text extracted"
                : "Ready for Chat and Agent";
        String skips = " (" + stats.skippedTooLarge() + " oversized, " + stats.skippedUnsupported()
                + " unsupported/secret, " + stats.skippedUnreadable() + " unreadable, "
                + stats.skippedDirectories() + " excluded folders)";
        return base + skips + (stats.scanIncomplete() ? " — incomplete scan: file/depth limit or filesystem error" : "");
    }

    private static final class Job {
        final String id;
        final String path;
        volatile String phase = "queued";
        volatile String detail = "Waiting for background index worker";
        volatile int files;
        volatile int scanned;
        volatile String finishedAt;
        Job(String id, String path) { this.id = id; this.path = path; }
    }

    @PreDestroy public void shutdown() { worker.shutdownNow(); }
}
