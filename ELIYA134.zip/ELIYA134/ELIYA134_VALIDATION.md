# ELIYA134 Validation Record

Date: 2026-11-11. Tested offline against a copy of ELIYA133 source and synthetic temporary migration ledgers.

## Results

| Validation | Outcome | What it proves |
|---|---|---|
| Java 17 compatibility (`javac --release 17`) | PASS | New dependency-free Java policies compile under Java 17 |
| ELIYA134 Java reliability policy suite | PASS | 34 focused assertions: approval routing, workspace/ledger guards, package scoping, duplicate detection, statuses, exact batch IDs, digest change, single-use persistence, failed test handling |
| ELIYA134 source integration contracts | PASS | Source contains required preflight → approved-plan → completion gates and UI actions |
| Java 17 source AST parse | PASS | All 164 production Java source files parse; this is not a dependency-linked compilation |
| Retained ELIYA133 JavaScript tests | PASS | 117/117 regressions |
| ELIYA132/133 artifact/handoff/JVM policy tests | PASS | Existing chosen prompt, artifact and response policy smoke checks |
| Chromium ELIYA133 UI regression | PASS | Existing desktop/mobile prompt and HTML workflows |
| Chromium ELIYA134 plan approval smoke | PASS | Last-plan-only approval, explicit user action, clarification suppression, mobile layout |
| Maven/Spring Boot compile/package | NOT RUN | Maven and required resolved dependencies not available in this runtime |
| Live provider and real Windows workspace Prompt 4 | NOT RUN | No access to private project checkout/LLM endpoint |

## Regression commands

```bash
bash qa/run-eliya134-validation.sh
```

This script does **not** download Chrome/Edge; set `ELIYA_BROWSER_BIN` if it cannot locate an installed browser.

## Manual acceptance run required on your Windows environment

- Confirm the selected Playwright root contains `migration/MIGRATION.md`, `migration/migration-ledger.csv`, `migration/PACKAGE_RUNBOOK.md`, and `migration/shared-component-registry.md`.
- Run **original complete Prompt 4** in Agent. Check that ELIYA emits `migration_preflight`, shows a read-only plan, and does **not** modify any code or ledger before approval.
- Restart ELIYA, reopen the same conversation and approve within two hours. It must consume the same plan once and not ask for an additional generic approval.
- Change a required migration document after plan review; an approval must now be blocked as stale, preserving changed files.
- Confirm next batch selects only genuinely incomplete methods, and an already migrated but unverified method is verified/reconciled rather than duplicated.
- Execute actual focused Playwright/Cucumber tests with installed browser. Simulate failed final tests and missing output; check run is Blocked/Failed and does not report Completed.
- Confirm terminal execution, cancellation, MCP gating, legacy-reference permissions and actual source-to-target test parity with your real framework.
