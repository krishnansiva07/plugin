package com.llmart.llm.service;

import java.util.Locale;
import java.util.regex.Pattern;

/**
 * User-visible answers are deliverables, not a side effect of execution bookkeeping.
 * Keep this policy deterministic: no model or filesystem access is needed to decide
 * whether a verified run still owes the user its requested analysis.
 */
final class AgentResultPresentation {
    private static final Pattern DEEP_ANALYSIS = Pattern.compile(
            "\\b(?:architecture|architectural|e2e|end.to.end|deep.search|deep.analysis|" +
            "data.flow|request.flow|execution.flow|working.principle|sequence.diagram|" +
            "component.diagram|dependency.flow|technical.flow|code.flow|system.design|" +
            "trace.the.flow|explain.the.flow)\\b", Pattern.CASE_INSENSITIVE);
    private static final Pattern VERIFICATION = Pattern.compile(
            "(?i)\\b(?:check|verify|validation|validate|confirm|audit|assess)\\b.{0,125}" +
            "\\b(?:migrat(?:ion|ed|e)|framework|coverage|test|release|deployment|complete|success|correct)\\b");
    private static final Pattern VERDICT = Pattern.compile(
            "(?im)^\\s*(?:\\*\\*)?(?:verdict|verification status|result|outcome)(?:\\*\\*)?\\s*[:\\-]\\s*(?:\\*\\*)?\\s*" +
            "(?:verified|partially verified|not verified|inconclusive|complete|incomplete|passed|failed|blocked)\\b");
    private static final Pattern GENERIC = Pattern.compile(
            "(?i)^(?:agent run (?:completed|finished)|all approved plan steps completed|" +
            "the requested workspace changes completed|the approved task is complete|" +
            "verified task completed|external analysis completed|task completed|" +
            "execution completed|completed successfully|done\\.?|" +
            "i completed the requested workspace changes|i created \\d+ files? in the workspace)\\b");

    private AgentResultPresentation() { }

    static boolean isDeepAnalysis(String request) {
        return request != null && DEEP_ANALYSIS.matcher(request).find();
    }

    static boolean isVerificationRequest(String request) {
        return request != null && VERIFICATION.matcher(request).find();
    }

    static boolean needsVerificationResult(String request, String answer) {
        if (!isVerificationRequest(request)) return false;
        String value = answer == null ? "" : answer.strip();
        // A model's intention to inspect is not a completed validation result.
        return !VERDICT.matcher(value).find() || value.length() < 130 ||
                !Pattern.compile("(?i)\\b(?:evidence|inspected|source|file|tested|unverified|limitations?)\\b").matcher(value).find();
    }

    /** The final answer must be descriptive for an investigative prompt, irrespective of plan success. */
    static boolean needsAnalysisAnswer(String request, String answer) {
        if (!isDeepAnalysis(request)) return false;
        String text = answer == null ? "" : answer.strip();
        return text.isBlank() || GENERIC.matcher(text).find() ||
                (text.length() < 240 && !text.contains("\n") && !text.contains("`"));
    }

    /** Any inspected workspace question deserves a real answer, not a successful-run label.
     * Short factual results (including verified zero matches) are valid; only recover
     * empty, generic or obvious bookkeeping-only responses. Deep analysis requires depth.
     */
    static boolean needsInvestigationAnswer(String request, String answer, boolean readOnly) {
        if (needsAnalysisAnswer(request, answer) || needsVerificationResult(request, answer)) return true;
        if (!readOnly) return false;
        String text = answer == null ? "" : answer.strip();
        return text.isBlank() || GENERIC.matcher(text).find() ||
                (text.length() < 60 && !text.contains("`") && !text.contains("/"));
    }

    /** A missing-evidence fallback is not proof of a successfully delivered analysis. */
    static boolean isUnfulfilledAnalysis(String answer) {
        if (answer == null) return true;
        String text = answer.strip();
        return text.isBlank() ||
                text.startsWith("The investigation finished without a substantive") ||
                text.startsWith("## Investigation result\n\nThe investigation completed, but Eliya could not");
    }

    /** Don't replace a useful model-produced explanation with a generated success template. */
    static boolean hasSubstantiveAnswer(String answer) {
        if (answer == null) return false;
        String text = answer.strip();
        if (text.length() < 100 || GENERIC.matcher(text).find()) return false;
        return text.contains("\n") || text.contains("`") || text.contains("**");
    }

    static String addFileReport(String answer, String fileSummary) {
        if (fileSummary == null || fileSummary.isBlank()) return answer == null ? "" : answer;
        if (!hasSubstantiveAnswer(answer)) return fileSummary;
        String summary = fileSummary.strip();
        // A follow-up question belongs at the very bottom of the user's conversation.
        String question = "Do you want to add anything?";
        if (summary.endsWith(question)) summary = summary.substring(0, summary.length() - question.length()).stripTrailing();
        return answer.strip() + "\n\n---\n\n### Files and verification\n\n" + summary +
                "\n\n" + question;
    }

    static String analysisSynthesisFallback(String previous, String evidence) {
        if (hasSubstantiveAnswer(previous)) return previous.strip();
        String trace = evidence == null ? "" : evidence.strip();
        if (!trace.isBlank()) {
            return "## Investigation result\n\nThe investigation completed, but Eliya could not " +
                    "produce a fully grounded architecture explanation from the recorded evidence. " +
                    "These are the available observations (not a verified end-to-end flow):\n\n" + trace;
        }
        return "The investigation finished without a substantive architecture answer or " +
                "accessible source evidence. I can't confirm the end-to-end flow from this run. " +
                "No implementation changes were inferred from that result.";
    }
}
