import asyncio, re
from pathlib import Path
from playwright.async_api import async_playwright
root=Path(__file__).resolve().parent.parent / 'src/main/resources/static'
async def main():
  async with async_playwright() as pw:
    browser=await pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
    page=await browser.new_page(viewport={'width':1400,'height':850})
    page.set_default_timeout(6000)
    exceptions=[]
    page.on('pageerror', lambda e: exceptions.append(str(e)))
    html=(root/'index.html').read_text()
    html=re.sub(r'<script src="[^"]+"></script>','',html)
    html=re.sub(r'<link rel="stylesheet"[^>]+>','',html)
    await page.set_content(html)
    await page.add_style_tag(content=(root/'app.css').read_text())
    await page.evaluate('''() => {
      window.__requests=[]; window.__mockSessions=[];
      window.fetch=async (url,opts={})=>{
        const path=String(url).split('?')[0];const method=opts.method||'GET';
        let data={};try{data=JSON.parse(opts.body||'{}')}catch(e){}
        window.__requests.push({path,method,data});
        let value={};
        if(path==='/api/terminal/workspaces')value=[{id:'wk1',name:'Selenium',localPath:'C:/Projects/Selenium'},{id:'wk2',name:'Playwright',localPath:'D:/Projects/Playwright'}];
        else if(path==='/api/terminal/capabilities')value={count:1,items:[{path:'AGENTS.md'}],repositories:[{path:'.',branch:'main',dirty:false}]};
        else if(path==='/api/terminal/repositories')value=[{path:'.',branch:'main',dirty:false}];
        else if(path==='/api/terminal/definitions'&&method==='POST')value={kind:data.kind,format:data.format,name:data.name,path:'.agents/skills/'+data.name+'/SKILL.md'};
        else if(path==='/api/terminal/git/review')value={repository:'.',branch:'main',status:' M README.md',workingDiffStat:'README.md | 1 +',stagedDiffStat:'',truncated:false};
        else if(path==='/api/artifacts/saved')value=[{id:'00000000-0000-0000-0000-000000000009',path:'report.html',operation:'write',bytes:17}];
        else if(path.startsWith('/api/artifacts/saved/')) return new Response('<h1>Archived</h1>',{status:200,headers:{'Content-Type':'text/plain'}});
        else if(path==='/api/terminal/sessions'&&method==='GET')value=window.__mockSessions.map(({id,prompt,status,projectId,model,progressPercent,stepCount,completedSteps,progressPhase})=>({id,prompt,status,projectId,model,progressPercent,stepCount,completedSteps,progressPhase}));
        else if(path==='/api/terminal/sessions'&&method==='POST'){
          value={id:`session-${window.__mockSessions.length+1}`};
          window.__mockSessions.unshift({id:value.id,prompt:data.message,status:'running',projectId:data.projectId,model:data.settings.model,progressPercent:33,stepCount:3,completedSteps:1,progressPhase:'executing',fullPrompt:data.message,referenceProjectIds:data.referenceProjectIds,referenceProjectNames:data.referenceProjectNames,answer:'Previous task summary',question:{},events:[],runId:'new-run',progress:{progressPercent:33,progressPhase:'executing',plan:[]}});
        }
        else if(path==='/api/terminal/transfer'&&method==='POST'){
          value={id:'session-transfer'};
          window.__mockSessions.unshift({id:value.id,prompt:data.request.message,status:'running',projectId:data.request.projectId,model:data.request.settings.model,progressPercent:5,stepCount:2,completedSteps:0,progressPhase:'planning',fullPrompt:data.request.message,referenceProjectIds:data.request.referenceProjectIds,referenceProjectNames:data.request.referenceProjectNames,answer:'',question:{},events:[],runId:'transferred-run',progress:{progressPercent:5,progressPhase:'planning',plan:[]}});
        }
        else if(path==='/api/agent/runs/run-old'&&method==='GET')value={id:'run-old',objective:'Create review skill',projectId:'wk2',planLocked:false,mutationRevision:0};
        else if(path==='/api/agent/runs/run-old/plan'&&method==='PUT')value={plan:data.items.map((text,i)=>({index:i+1,text,status:'pending'})),planValidationStatus:'needs_review'};
        else if(path.startsWith('/api/terminal/sessions/'))value=window.__mockSessions.find(s=>path==='/api/terminal/sessions/'+s.id)||{};
        else if(path==='/api/conversations')value=[];
        return new Response(JSON.stringify(value),{status:200,headers:{'Content-Type':'application/json'}});
      };
    }''')
    for file in ['markdown.js','prompt-catalog.js','app.js','confluence-composer.js']:
      await page.add_script_tag(content=(root/file).read_text())
    assert not exceptions,exceptions
    await page.evaluate("state.config.apiKey='test-key';state.config.model='qwen-latest';state.config.baseUrl='http://mock.invalid';")
    await page.click('#launchTerminalBtn')
    await page.wait_for_function("() => document.querySelector('#terminalWorkspaceSelect').options.length===3")
    await page.select_option('#terminalWorkspaceSelect','wk2')
    await page.select_option('#terminalReferences',['wk1'])
    await page.click('#terminalSkillPanel summary')
    await page.fill('#terminalSkillName','code-reviewer')
    await page.fill('#terminalSkillDescription','Review application code')
    await page.fill('#terminalSkillInstructions','Check Java and Selenium classes and tests.')
    await page.click('#terminalSkillCreate')
    await page.wait_for_function("() => window.__requests.some(r => r.path==='/api/terminal/definitions')")
    await page.wait_for_function("() => document.querySelector('#terminalSkillStatus').textContent.includes('Created')")
    await page.click('#terminalGitPanel summary')
    await page.select_option('#terminalRepo','.')
    await page.click('#terminalGitReview')
    await page.wait_for_function("() => document.querySelector('#terminalGitReviewOutput').textContent.includes('README.md')")
    await page.fill('#terminalTask','Create reviewer agent')
    await page.click('#terminalForm button[type="submit"]')
    await page.wait_for_selector('[data-terminal-tab="session-1"]')
    request=await page.evaluate("window.__requests.filter(r=>r.path==='/api/terminal/sessions'&&r.method==='POST')[0].data")
    assert request['projectId']=='wk2' and request['referenceProjectIds']==['wk1'] and request['settings']['agentPlanApproval']==False,request
    await page.click('#terminalDuplicateTab')
    assert await page.input_value('#terminalWorkspaceSelect')=='wk2'
    assert await page.input_value('#terminalTask')==''
    await page.click('[data-terminal-tab="session-1"]')
    await page.click('#terminalForkTab')
    assert 'Previous task summary' in await page.input_value('#terminalTask')
    await page.click('#terminalClose')
    await page.click('#executionMonitorBtn')
    await page.wait_for_selector('[data-monitor-session="session-1"]')
    assert '1/3 verified steps' in await page.locator('#executionMonitorItems').inner_text()
    await page.click('[data-monitor-session="session-1"]')
    assert await page.locator('#terminalDock').is_visible()
    await page.click('#terminalClose')
    await page.evaluate('''() => {
      state.project={id:'wk2',name:'Playwright',localPath:'D:/Playwright'};
      state.referenceProjects=[{id:'wk1',name:'Selenium'}];
      state.messages=[{role:'assistant',mode:'agent',content:'Execution plan ready',streaming:true,agentRunId:'run-old',agentSteps:[{tool:'plan_approval',status:'approval',approvalId:'approval-old',output:'1. Create review skill'}],agentProgress:{plan:[{index:1,text:'Create review skill',status:'pending'}],planValidationStatus:'approved',planValidationSummary:'Valid',status:'running'}}];
      renderMessages();
    }''')
    await page.wait_for_selector('[data-agent-to-terminal="approval-old"]')
    await page.click('[data-agent-to-terminal="approval-old"]')
    await page.wait_for_selector('[data-terminal-tab="session-transfer"]')
    transfer=await page.evaluate("window.__requests.find(r=>r.path==='/api/terminal/transfer').data")
    assert transfer['runId']=='run-old' and transfer['approvalId']=='approval-old' and transfer['request']['projectId']=='wk2'
    assert transfer['request']['referenceProjectIds']==['wk1']
    await page.click('#terminalClose')
    await page.evaluate('''() => {
      state.conversationId='00000000-0000-0000-0000-000000000001';
      state.messages=[{role:'assistant',mode:'chat',content:'',id:42,streaming:false}];
      renderMessages();
    }''')
    await page.click('[data-saved-artifacts="0"]')
    await page.wait_for_selector('[data-saved-preview="0"]')
    await page.click('[data-saved-preview="0"]')
    await page.wait_for_function("() => document.querySelector('#runMarkdownTitle').textContent==='report.html'")
    assert await page.locator('#runMarkdownBackdrop').is_visible()
    print('PASS: Chromium UI — independent sessions, Studio, Git review, artifact restoration, monitor and Agent->Terminal')
    assert exceptions == [], 'Uncaught browser errors: '+repr(exceptions)
    await browser.close()
asyncio.run(main())
