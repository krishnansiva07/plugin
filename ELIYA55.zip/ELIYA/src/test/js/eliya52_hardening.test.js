const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const main=path.resolve(__dirname,'../../main');
const read=(p)=>fs.readFileSync(path.join(main,p),'utf8');
const service=read('java/com/llmart/llm/service/TerminalSessionService.java');
const vault=read('java/com/llmart/llm/service/ArtifactVaultService.java');
const studio=read('java/com/llmart/llm/service/TerminalSkillStudioService.java');
const ui=read('resources/static/app.js');
const html=read('resources/static/index.html');
test('Terminal scheduling is nonblocking and detects overlapping parent/child roots',()=>{
 assert.match(service,/private final LinkedHashMap<String,Runnable> pendingJobs/);
 assert.match(service,/a\.startsWith\(b\) \|\| b\.startsWith\(a\)/);
 assert.match(service,/activeWorkspaces\.put/);
 assert.match(service,/activeWorkspaces\.remove/);
 assert.match(service,/dispatchPending\(\)/);
 assert.doesNotMatch(service,/workspaceLanes\.computeIfAbsent/);
});
test('Terminal preserves file evidence across conversation separation',()=>{
 const files=read('java/com/llmart/llm/service/FileService.java');
 assert.match(files,/copyForTerminal/);
 assert.match(files,/conversations\.require\(sourceConversation\)/);
 assert.match(files,/Files\.copy\(source/);
 assert.match(service,/attachedFiles\.copyForTerminal/);
 assert.match(service,/source\.conversationId\(\)/);
 assert.match(service,/conversationArchive\.create\(\)\.getId\(\)/);
});
test('Chat file proposals have a durable artifact store and UI retrieval',()=>{
 assert.match(vault,/Files\.move\(temp, manifest/);
 assert.match(vault,/MAX_TOTAL_BYTES/);
 assert.match(vault,/UUID\.randomUUID/);
 const conversations=read('java/com/llmart/llm/service/ConversationService.java');
 assert.match(conversations,/artifactVault\.archive/);
 assert.match(ui,/data-saved-artifacts/);
 assert.match(ui,/data-saved-preview/);
 assert.match(ui,/\/api\/artifacts\/saved/);
});
test('Skill Studio uses compatible paths, safe names and explicit creation',()=>{
 assert.match(studio,/\.opencode/);
 assert.match(studio,/\.claude/);
 assert.match(studio,/StandardOpenOption\.CREATE_NEW/);
 assert.match(studio,/Files\.isSymbolicLink/);
 assert.match(html,/id="terminalSkillPanel"/);
 assert.match(ui,/\/api\/terminal\/definitions/);
});
