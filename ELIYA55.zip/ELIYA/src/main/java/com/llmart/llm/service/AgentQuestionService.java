package com.llmart.llm.service;

import org.springframework.stereotype.Service;
import java.util.*;
import java.util.concurrent.*;

/** Session-specific clarification bridge. Questions are NOT plan approvals or permission grants. */
@Service
public class AgentQuestionService {
    private final ConcurrentMap<String, Pending> questions = new ConcurrentHashMap<>();
    private final Set<String> enabledRuns = ConcurrentHashMap.newKeySet();
    public void enable(String runId) { if (runId != null && !runId.isBlank()) enabledRuns.add(runId); }
    public void disable(String runId) { enabledRuns.remove(runId); cancel(runId); }
    public boolean enabled(String runId) { return enabledRuns.contains(runId); }
    private record Pending(String id, String question, List<String> choices, CompletableFuture<String> response) {}

    public String ask(String runId, String question, List<String> choices, AgentRunService.AgentRun run) throws Exception {
        if (question == null || question.isBlank()) throw new IllegalArgumentException("Question cannot be blank");
        if (question.length() > 2000) throw new IllegalArgumentException("Question is too long");
        List<String> options = choices == null || choices.isEmpty() ? List.of("OK", "Continue", "Cancel")
            : choices.stream().filter(Objects::nonNull).map(String::trim).filter(x -> !x.isBlank()).distinct().limit(8).toList();
        if (options.isEmpty()) throw new IllegalArgumentException("Provide at least one response option");
        if (options.stream().noneMatch(x -> x.equalsIgnoreCase("Cancel"))) {
            List<String> withCancel = new ArrayList<>(options);
            withCancel.add("Cancel"); options = List.copyOf(withCancel);
        }
        Pending pending = new Pending(UUID.randomUUID().toString(), question, options, new CompletableFuture<>());
        if (questions.putIfAbsent(runId, pending) != null) throw new IllegalStateException("Another clarification is already pending");
        try {
            while (true) {
                run.checkCancelled();
                try { return pending.response().get(250, TimeUnit.MILLISECONDS); }
                catch (TimeoutException ignored) { /* nonblocking check of run cancellation */ }
            }
        } finally { questions.remove(runId, pending); }
    }
    public Map<String,Object> pending(String runId) {
        Pending q = questions.get(runId);
        if (q == null) return Map.of();
        return Map.of("kind", "clarification", "id", q.id(), "reason", q.question(), "choices", q.choices());
    }
    public boolean answer(String runId, String questionId, String choice, String detail) {
        Pending q = questions.get(runId);
        if (q == null || !q.id().equals(questionId) || !q.choices().contains(choice)) return false;
        if (detail != null && detail.length() > 8000) throw new IllegalArgumentException("Clarification text is too long");
        return q.response().complete("User selected: " + choice + (detail == null || detail.isBlank() ? "" : "\nDetails: " + detail));
    }
    public void cancel(String runId) {
        Pending q = questions.remove(runId);
        if (q != null) q.response().complete("User cancelled the clarification; stop the affected task safely.");
    }
}
