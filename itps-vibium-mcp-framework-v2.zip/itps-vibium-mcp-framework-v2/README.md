# ITPS VIBIUM Framework - MCP Edition V2

Professional Java Spring Boot UI test runner using **Vibium MCP** as the browser action engine.

## What is fixed in V2

- Browser is started **once per run**, not again for every step.
- LLM is no longer allowed to return only `browser_start`, `browser_map`, or wait tools for real action steps.
- A step is marked PASSED only after a real MCP action is executed for click/fill/select/navigate/assert instructions.
- Headless is now OFF by default so you can watch the browser while stabilising tests.
- The report now shows the full MCP call chain for each step.

## Required local Vibium MCP setup

Your machine already showed this working:

```powershell
C:\tools\vibium-portable\node_modules\.bin\vibium.cmd --version
C:\tools\vibium-portable\node_modules\.bin\vibium.cmd paths
C:\tools\vibium-portable\node_modules\.bin\vibium.cmd is-installed
```

Configured path:

```properties
itps.vibium.mcp.command=C:\tools\vibium-portable\node_modules\.bin\vibium.cmd
itps.vibium.mcp.args=mcp
itps.vibium.skip-browser-download=true
```

## Run

```cmd
mvn clean spring-boot:run
```

Open:

```text
http://localhost:8090
```

Do not manually keep `vibium.cmd mcp` open. The Java application starts and stops MCP itself.

## Excel format

Columns:

```text
id | name | url | steps | expected | data.searchText | data.username | data.password
```

Use one step per line in the `steps` cell. Example:

```text
Click Search icon
Enter {{searchText}} in Search field
Select {{searchText}} from search results
Click Search button
Verify {{searchText}}
```

## Reports

Generated under:

```text
target/itps-vibium-runs/<run-id>/
  report.html
  report.json
  report.xlsx
  screenshots.zip
  mcp-tools.json
```
