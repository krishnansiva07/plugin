package com.itps.vibium.service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.itps.vibium.model.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.time.Instant;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Service
public class ItpsMcpRunner {
    private final LlmClient llmClient;
    private final ReportService reportService;
    private final RunStore runStore;
    private final ObjectMapper mapper = new ObjectMapper();
    private final Path outputRoot;
    private final int requestTimeoutSeconds;
    private final boolean skipBrowserDownload;

    public ItpsMcpRunner(LlmClient llmClient,
                         ReportService reportService,
                         RunStore runStore,
                         @Value("${runner.output-dir:target/itps-vibium-runs}") String outputDir,
                         @Value("${itps.vibium.mcp.request-timeout-seconds:60}") int requestTimeoutSeconds,
                         @Value("${itps.vibium.skip-browser-download:true}") boolean skipBrowserDownload) {
        this.llmClient = llmClient;
        this.reportService = reportService;
        this.runStore = runStore;
        this.outputRoot = Path.of(outputDir);
        this.requestTimeoutSeconds = requestTimeoutSeconds;
        this.skipBrowserDownload = skipBrowserDownload;
    }

    public void execute(List<TestScenario> scenarios, RunConfig config, RunStatus status) {
        Instant runStart = Instant.now();
        status.setStatus("RUNNING");
        status.setStartedAt(runStart);
        Path runDir = outputRoot.resolve(config.getRunId());
        Path screenshotDir = runDir.resolve("screenshots");
        try {
            Files.createDirectories(screenshotDir);
        } catch (Exception e) {
            status.setStatus("FAILED");
            status.setMessage("Unable to create output directory: " + e.getMessage());
            return;
        }

        try (McpClient mcp = new McpClient(config.getMcpCommand(), splitArgs(config.getMcpArgs()), Duration.ofSeconds(requestTimeoutSeconds), skipBrowserDownload)) {
            mcp.start();
            List<McpTool> tools = mcp.initializeAndListTools();
            McpToolCatalog catalog = new McpToolCatalog(tools);
            writeToolsManifest(runDir, tools);

            // Important production fix:
            // Browser is started once for the run. The LLM is not allowed to restart it for every step.
            startBrowserOnce(mcp, catalog, config);

            List<ScenarioResult> scenarioResults = new ArrayList<>();
            for (TestScenario scenario : scenarios) {
                ScenarioResult result = executeScenario(mcp, catalog, scenario, config, screenshotDir);
                scenarioResults.add(result);
            }
            status.setScenarios(scenarioResults);
            status.setTotal(scenarioResults.size());
            long passed = scenarioResults.stream().filter(s -> "PASSED".equals(s.getStatus())).count();
            status.setPassed((int) passed);
            status.setFailed(scenarioResults.size() - (int) passed);
            status.setStatus(status.getFailed() == 0 ? "PASSED" : "COMPLETED_WITH_FAILURES");
            status.setMessage("Vibium MCP execution completed. Browser was started once and each step required a real MCP action, not just map/start.");
        } catch (Exception e) {
            status.setStatus("FAILED");
            status.setMessage("Vibium MCP execution failed: " + e.getMessage());
        } finally {
            status.setFinishedAt(Instant.now());
            try {
                reportService.writeReports(status, runDir);
            } catch (Exception reportError) {
                status.setMessage((status.getMessage() == null ? "" : status.getMessage() + " | ") + "Report generation failed: " + reportError.getMessage());
            }
        }
    }

    private void startBrowserOnce(McpClient mcp, McpToolCatalog catalog, RunConfig config) throws Exception {
        Optional<McpTool> startTool = catalog.startTool();
        if (startTool.isEmpty()) return;
        Map<String, Object> args = new LinkedHashMap<>();
        if (schemaContains(startTool.get(), "headless")) args.put("headless", config.isHeadless());
        mcp.callTool(startTool.get().getName(), args);
    }

    private ScenarioResult executeScenario(McpClient mcp, McpToolCatalog catalog, TestScenario scenario, RunConfig config, Path screenshotDir) {
        long scenarioStart = System.currentTimeMillis();
        ScenarioResult scenarioResult = new ScenarioResult();
        scenarioResult.setId(scenario.getId());
        scenarioResult.setName(scenario.getName());
        scenarioResult.setUrl(resolveUrl(scenario.getUrl(), config.getAppBaseUrl()));
        scenarioResult.setStatus("RUNNING");

        List<String> executableSteps = new ArrayList<>();
        if (notBlank(scenarioResult.getUrl())) executableSteps.add("Navigate to " + scenarioResult.getUrl());
        executableSteps.addAll(scenario.getSteps());
        if (notBlank(scenario.getExpected())) executableSteps.add("Verify " + scenario.getExpected());

        int stepNo = 1;
        boolean failed = false;
        for (String rawStep : executableSteps) {
            StepResult sr = executeStep(mcp, catalog, scenario, config, rawStep, stepNo, screenshotDir);
            scenarioResult.getSteps().add(sr);
            if (!"PASSED".equals(sr.getStatus())) {
                failed = true;
                scenarioResult.setErrorMessage(sr.getErrorMessage());
                if (!config.isContinueOnFailure()) break;
            }
            stepNo++;
        }
        scenarioResult.setStatus(failed ? "FAILED" : "PASSED");
        scenarioResult.setDurationMs(System.currentTimeMillis() - scenarioStart);
        return scenarioResult;
    }

    private StepResult executeStep(McpClient mcp, McpToolCatalog catalog, TestScenario scenario, RunConfig config, String rawStep, int stepNo, Path screenshotDir) {
        StepResult sr = new StepResult();
        long start = System.currentTimeMillis();
        String step = applyData(rawStep, scenario.getData());
        sr.setStepNo(stepNo);
        sr.setInstruction(step);
        try {
            JsonNode plan = planOrDirectStep(mcp, catalog, step, scenario, config, null);
            sr.setActionJson(plan.toString());
            executeValidatedPlan(mcp, catalog, plan, sr, step);
            sr.setStatus("PASSED");
            if (shouldScreenshot(config, true)) {
                sr.setScreenshot(captureScreenshot(mcp, catalog, screenshotDir, scenario.getId(), stepNo));
            }
        } catch (Exception firstError) {
            Exception finalError = firstError;
            for (int retry = 0; retry < config.getRetryCount(); retry++) {
                try {
                    Thread.sleep(config.getRetryDelayMs());
                    JsonNode replan = planOrDirectStep(mcp, catalog, step, scenario, config, finalError.getMessage());
                    sr.setActionJson(replan.toString());
                    executeValidatedPlan(mcp, catalog, replan, sr, step);
                    sr.setStatus("PASSED");
                    finalError = null;
                    break;
                } catch (Exception retryError) {
                    finalError = retryError;
                }
            }
            if (finalError != null) {
                sr.setStatus("FAILED");
                sr.setErrorMessage(finalError.getMessage());
                if (shouldScreenshot(config, false)) {
                    sr.setScreenshot(captureScreenshotQuietly(mcp, catalog, screenshotDir, scenario.getId(), stepNo));
                }
            }
        } finally {
            sr.setDurationMs(System.currentTimeMillis() - start);
        }
        return sr;
    }

    private JsonNode planOrDirectStep(McpClient mcp, McpToolCatalog catalog, String step, TestScenario scenario, RunConfig config, String failure) throws Exception {
        JsonNode direct = parseDirectJson(step, catalog);
        if (direct != null) return normalizePlan(direct, catalog);

        // Deterministic navigation avoids unnecessary LLM calls and prevents repeated browser_start calls.
        if (isNavigate(step)) return directNavigatePlan(catalog, step);
        if (isWait(step)) return directWaitPlan(catalog, step);

        // Try simple direct MCP plans first. This keeps execution fast and reduces LLM drift.
        JsonNode heuristic = heuristicPlan(catalog, step, scenario);
        if (heuristic != null) return heuristic;

        if (!config.isUseLlm()) throw new IllegalArgumentException("Step is natural language and no deterministic MCP mapping was found. Enable LLM or use explicit MCP JSON step.");
        JsonNode map = safeMap(mcp, catalog);
        String prompt = basePrompt(step, scenario, catalog, map, failure, config);
        return normalizePlan(mapper.readTree(llmClient.planMcpCall(prompt, config)), catalog);
    }

    private void executeValidatedPlan(McpClient mcp, McpToolCatalog catalog, JsonNode originalPlan, StepResult sr, String instruction) throws Exception {
        JsonNode plan = removeBrowserStartCalls(originalPlan);
        if (plan == null || (plan.has("calls") && plan.path("calls").isArray() && plan.path("calls").isEmpty())) {
            throw new IllegalStateException("Planner returned only browser_start/no-op. Browser is already started once by the framework.");
        }
        String expectedIntent = expectedIntent(instruction);
        if (requiresRealAction(expectedIntent) && !containsRealAction(plan, expectedIntent)) {
            throw new IllegalStateException("Planner returned only observation/wait tools for a real action step. Instruction='" + instruction + "', plan=" + originalPlan);
        }

        JsonNode last = null;
        List<String> toolNames = new ArrayList<>();
        List<Map<String, Object>> argList = new ArrayList<>();
        List<String> resultList = new ArrayList<>();

        for (JsonNode call : flattenCalls(plan)) {
            String toolName = firstText(call, "tool", "name", "mcpTool", "toolName");
            if (isBrowserStart(toolName)) continue;
            McpTool tool = catalog.findByName(toolName).orElseThrow(() -> new IllegalArgumentException("MCP tool not found: " + toolName));
            JsonNode argNode = call.path("arguments");
            Map<String, Object> args = argNode.isMissingNode() || argNode.isNull()
                    ? Map.of()
                    : mapper.convertValue(argNode, new TypeReference<Map<String, Object>>() {});
            last = mcp.callTool(tool.getName(), args);
            toolNames.add(tool.getName());
            argList.add(args);
            resultList.add(compact(last == null ? "{}" : last.toString(), 2500));
        }
        sr.setToolName(String.join(" → ", toolNames));
        sr.setToolArguments(mapper.writeValueAsString(argList));
        sr.setMcpResult(String.join("\n---\n", resultList));

        if (isAssert(expectedIntent)) {
            JsonNode postMap = safeMap(mcp, catalog);
            assertInstruction(instruction, sr.getMcpResult(), postMap);
        }
    }

    private JsonNode removeBrowserStartCalls(JsonNode plan) {
        if (plan == null || plan.isMissingNode() || plan.isNull()) return plan;
        ArrayNode calls = mapper.createArrayNode();
        for (JsonNode call : flattenCalls(plan)) {
            String tool = firstText(call, "tool", "name", "mcpTool", "toolName");
            if (!isBrowserStart(tool)) calls.add(call);
        }
        ObjectNode out = mapper.createObjectNode();
        out.set("calls", calls);
        if (plan.has("assert")) out.set("assert", plan.path("assert"));
        return out;
    }

    private List<JsonNode> flattenCalls(JsonNode plan) {
        List<JsonNode> calls = new ArrayList<>();
        if (plan == null) return calls;
        if (plan.has("calls") && plan.path("calls").isArray()) {
            for (JsonNode c : plan.path("calls")) calls.add(c);
        } else {
            calls.add(plan);
        }
        return calls;
    }

    private boolean containsRealAction(JsonNode plan, String intent) {
        for (JsonNode call : flattenCalls(plan)) {
            String tool = firstText(call, "tool", "name", "mcpTool", "toolName");
            if (tool == null) continue;
            String t = tool.toLowerCase(Locale.ROOT);
            if (isNoOpTool(t)) continue;
            if ("NAVIGATE".equals(intent) && containsAny(t, "navigate", "goto", "go")) return true;
            if ("CLICK".equals(intent) && containsAny(t, "click", "press", "tap")) return true;
            if ("FILL".equals(intent) && containsAny(t, "fill", "type", "input", "write", "press")) return true;
            if ("SELECT".equals(intent) && containsAny(t, "select", "click", "press", "fill", "type")) return true;
            if ("ASSERT".equals(intent) && containsAny(t, "map", "snapshot", "text", "assert", "evaluate")) return true;
            if ("OTHER".equals(intent)) return true;
        }
        return false;
    }

    private boolean requiresRealAction(String intent) {
        return Set.of("NAVIGATE", "CLICK", "FILL", "SELECT", "ASSERT", "OTHER").contains(intent);
    }

    private boolean isNoOpTool(String tool) {
        return containsAny(tool, "start", "map", "snapshot", "screenshot", "wait") && !containsAny(tool, "click", "fill", "type", "navigate", "select", "press");
    }

    private boolean isBrowserStart(String toolName) {
        return toolName != null && toolName.toLowerCase(Locale.ROOT).contains("start");
    }

    private JsonNode directNavigatePlan(McpToolCatalog catalog, String step) throws Exception {
        McpTool navigate = catalog.navigateTool().orElseThrow(() -> new IllegalArgumentException("No navigate/go/open MCP tool found"));
        String url = step.replaceFirst("(?i)^navigate\s+to\s+", "").trim();
        ObjectNode call = mapper.createObjectNode();
        call.put("tool", navigate.getName());
        ObjectNode args = call.putObject("arguments");
        if (schemaContains(navigate, "url")) args.put("url", url); else args.put("href", url);

        ArrayNode calls = mapper.createArrayNode();
        calls.add(call);
        catalog.waitTool().ifPresent(wait -> calls.add(simpleCall(wait.getName(), Map.of())));
        ObjectNode plan = mapper.createObjectNode();
        plan.set("calls", calls);
        return plan;
    }

    private JsonNode directWaitPlan(McpToolCatalog catalog, String step) {
        Optional<McpTool> wait = catalog.waitTool();
        if (wait.isEmpty()) return null;
        ObjectNode plan = mapper.createObjectNode();
        ArrayNode calls = plan.putArray("calls");
        calls.add(simpleCall(wait.get().getName(), Map.of()));
        return plan;
    }

    private JsonNode heuristicPlan(McpToolCatalog catalog, String step, TestScenario scenario) {
        String lower = step.toLowerCase(Locale.ROOT).trim();
        try {
            if (lower.startsWith("click ") || lower.startsWith("open ") || lower.startsWith("tap ")) {
                Optional<McpTool> click = catalog.clickTool();
                if (click.isPresent()) {
                    String target = cleanTarget(step.replaceFirst("(?i)^(click|open|tap)\\s+", ""));
                    return singleCall(click.get().getName(), clickArgs(click.get(), target));
                }
            }
            if (lower.startsWith("select ") || lower.contains(" from drop down") || lower.contains(" from dropdown")) {
                Optional<McpTool> click = catalog.clickTool();
                if (click.isPresent()) {
                    String target = cleanTarget(step.replaceFirst("(?i)^select\\s+", ""));
                    return singleCall(click.get().getName(), clickArgs(click.get(), target));
                }
            }
            if (lower.startsWith("enter ") || lower.startsWith("type ") || lower.startsWith("fill ")) {
                Optional<McpTool> fill = catalog.fillTool();
                if (fill.isPresent()) {
                    FillSpec spec = parseFill(step, scenario.getData());
                    if (notBlank(spec.value)) return singleCall(fill.get().getName(), fillArgs(fill.get(), spec.target, spec.value));
                }
            }
        } catch (Exception ignored) {
            return null;
        }
        return null;
    }

    private Map<String, Object> clickArgs(McpTool tool, String target) {
        Map<String, Object> args = new LinkedHashMap<>();
        // Prefer selector because Vibium MCP screenshot shows browser_click accepts {selector:...}.
        String selector = targetToSelector(target);
        if (schemaContains(tool, "selector")) args.put("selector", selector);
        else if (schemaContains(tool, "text")) args.put("text", target);
        else args.put("selector", selector);
        return args;
    }

    private Map<String, Object> fillArgs(McpTool tool, String target, String value) {
        Map<String, Object> args = new LinkedHashMap<>();
        String selector = targetToInputSelector(target);
        if (schemaContains(tool, "selector")) args.put("selector", selector);
        else args.put("target", target);
        if (schemaContains(tool, "value")) args.put("value", value);
        else if (schemaContains(tool, "text")) args.put("text", value);
        else args.put("value", value);
        return args;
    }

    private String targetToInputSelector(String target) {
        String t = cleanTarget(target);
        String escaped = cssEscape(t);
        if (t.toLowerCase(Locale.ROOT).contains("search") || t.equalsIgnoreCase("search")) {
            return "input[placeholder*='Search'], input[aria-label*='Search'], [role='searchbox'], input[type='search'], textarea[placeholder*='Search']";
        }
        if (t.matches("^[A-Za-z_][A-Za-z0-9_-]*$")) {
            return "#" + escaped + ", [name='" + escaped + "'], input[placeholder*='" + escaped + "'], input[aria-label*='" + escaped + "'], textarea[placeholder*='" + escaped + "']";
        }
        return "text=" + t;
    }

    private String targetToSelector(String target) {
        String t = cleanTarget(target);
        String escaped = cssEscape(t);
        if (t.toLowerCase(Locale.ROOT).contains("search") && (t.toLowerCase(Locale.ROOT).contains("icon") || t.equalsIgnoreCase("search"))) {
            return "button[aria-label*='Search'], [aria-label*='Search'], [title*='Search'], [data-testid*='search'], [data-test*='search'], input[placeholder*='Search']";
        }
        if (t.toLowerCase(Locale.ROOT).contains("button")) {
            t = t.replaceAll("(?i)\\bbutton\\b", "").trim();
            escaped = cssEscape(t);
        }
        if (t.matches("^[A-Za-z_][A-Za-z0-9_-]*$")) {
            return "#" + escaped + ", [name='" + escaped + "'], [data-test='" + escaped + "'], [data-testid='" + escaped + "'], [aria-label='" + escaped + "'], button[value='" + escaped + "']";
        }
        return "text=" + t;
    }

    private FillSpec parseFill(String step, Map<String, Object> data) {
        String s = step.trim();
        Matcher m = Pattern.compile("(?i)^(enter|type|fill)\\s+(.+?)\\s+(in|into|on)\\s+(.+?)(\\s+field)?$").matcher(s);
        if (m.find()) {
            String rawVal = m.group(2).trim();
            String target = m.group(4).trim();
            String val = rawVal;
            if (data != null && data.containsKey(rawVal)) val = String.valueOf(data.get(rawVal));
            return new FillSpec(target, val);
        }
        return new FillSpec("input", "");
    }

    private JsonNode singleCall(String tool, Map<String, Object> args) {
        ObjectNode plan = mapper.createObjectNode();
        ArrayNode calls = plan.putArray("calls");
        calls.add(simpleCall(tool, args));
        return plan;
    }

    private ObjectNode simpleCall(String tool, Map<String, Object> args) {
        ObjectNode call = mapper.createObjectNode();
        call.put("tool", tool);
        call.set("arguments", mapper.valueToTree(args == null ? Map.of() : args));
        return call;
    }

    private JsonNode normalizePlan(JsonNode plan, McpToolCatalog catalog) {
        if (plan.has("tool") || plan.has("calls") || plan.has("mcpTool") || plan.has("name")) return plan;
        return plan;
    }

    private JsonNode parseDirectJson(String step, McpToolCatalog catalog) throws Exception {
        String trimmed = step == null ? "" : step.trim();
        if (!trimmed.startsWith("{")) return null;
        JsonNode node = mapper.readTree(trimmed);
        if (node.has("tool") || node.has("calls") || node.has("mcpTool") || node.has("name")) return node;
        return null;
    }

    private JsonNode safeMap(McpClient mcp, McpToolCatalog catalog) {
        try {
            Optional<McpTool> mapTool = catalog.mapTool();
            if (mapTool.isEmpty()) return mapper.createObjectNode().put("note", "No map/snapshot MCP tool was found");
            Map<String, Object> args = new LinkedHashMap<>();
            if (schemaContains(mapTool.get(), "selector")) args.put("selector", "body");
            return mcp.callTool(mapTool.get().getName(), args);
        } catch (Exception e) {
            return mapper.createObjectNode().put("mapError", e.getMessage());
        }
    }

    private String basePrompt(String step, TestScenario scenario, McpToolCatalog catalog, JsonNode map, String failure, RunConfig config) throws Exception {
        Map<String, Object> safeData = new LinkedHashMap<>(scenario.getData());
        StringBuilder sb = new StringBuilder();
        sb.append("You are controlling browser through Vibium MCP tools. The framework already started the browser once.\n");
        sb.append("Hard rules:\n");
        sb.append("1. Do NOT call browser_start.\n");
        sb.append("2. Do NOT return only browser_map/browser_wait_for_load for a click/fill/select/assert instruction.\n");
        sb.append("3. For icon actions such as search icon, prefer aria-label/title/data-testid/role/element ref from the map, not text=search.\n");
        sb.append("4. Return only valid JSON. Format: {\"calls\":[{\"tool\":\"browser_click\",\"arguments\":{...}}],\"why\":\"...\"}.\n");
        sb.append("5. If selecting a capsule/result from search, include every needed action in calls: click search icon, fill search input, click result, wait if needed.\n");
        sb.append("Scenario: ").append(scenario.getId()).append(" - ").append(scenario.getName()).append("\n");
        sb.append("Instruction: ").append(step).append("\n");
        sb.append("Headless requested: ").append(config.isHeadless()).append("\n");
        sb.append("Test data JSON: ").append(mapper.writeValueAsString(safeData)).append("\n");
        sb.append("Available MCP tools:\n").append(catalog.toPromptText()).append("\n");
        sb.append("Current page map / observation:\n").append(compact(map == null ? "" : map.toString(), 18000)).append("\n");
        if (failure != null) sb.append("Previous attempt failed or was rejected because: ").append(failure).append("\n");
        return sb.toString();
    }

    private void assertInstruction(String instruction, String mcpResult, JsonNode map) {
        String lower = instruction.toLowerCase(Locale.ROOT);
        String expected = instruction.replaceFirst("(?i)^(verify|assert|check)\\s+", "").trim();
        expected = expected.replaceFirst("(?i)\\s+(is|should be)\\s+(displayed|visible|present).*$", "").trim();
        if (expected.isBlank()) return;
        String haystack = ((mcpResult == null ? "" : mcpResult) + "\n" + (map == null ? "" : map.toString())).toLowerCase(Locale.ROOT);
        if (!haystack.contains(expected.toLowerCase(Locale.ROOT))) {
            throw new IllegalStateException("Assertion failed. Expected page/map to contain: " + expected);
        }
    }

    private String expectedIntent(String step) {
        String l = step == null ? "" : step.toLowerCase(Locale.ROOT);
        if (isNavigate(step)) return "NAVIGATE";
        if (l.startsWith("click") || l.startsWith("tap") || l.startsWith("open")) return "CLICK";
        if (l.startsWith("enter") || l.startsWith("type") || l.startsWith("fill")) return "FILL";
        if (l.startsWith("select") || l.contains("from drop down") || l.contains("from dropdown")) return "SELECT";
        if (l.startsWith("verify") || l.startsWith("assert") || l.startsWith("check")) return "ASSERT";
        if (l.startsWith("wait")) return "WAIT";
        return "OTHER";
    }

    private boolean isAssert(String intent) { return "ASSERT".equals(intent); }
    private boolean isNavigate(String step) { return step != null && step.trim().toLowerCase(Locale.ROOT).startsWith("navigate to "); }
    private boolean isWait(String step) { return step != null && step.trim().toLowerCase(Locale.ROOT).startsWith("wait"); }

    private String captureScreenshot(McpClient mcp, McpToolCatalog catalog, Path screenshotDir, String scenarioId, int stepNo) throws Exception {
        Optional<McpTool> screenshotTool = catalog.screenshotTool();
        if (screenshotTool.isEmpty()) return "";
        JsonNode result = mcp.callTool(screenshotTool.get().getName(), Map.of());
        Optional<byte[]> png = findImageBytes(result);
        if (png.isEmpty()) return "";
        String safeScenario = scenarioId.replaceAll("[^a-zA-Z0-9._-]", "_");
        String fileName = safeScenario + "_step_" + stepNo + ".png";
        Files.createDirectories(screenshotDir);
        Files.write(screenshotDir.resolve(fileName), png.get());
        return fileName;
    }

    private String captureScreenshotQuietly(McpClient mcp, McpToolCatalog catalog, Path screenshotDir, String scenarioId, int stepNo) {
        try { return captureScreenshot(mcp, catalog, screenshotDir, scenarioId, stepNo); }
        catch (Exception ignored) { return ""; }
    }

    private Optional<byte[]> findImageBytes(JsonNode node) {
        if (node == null || node.isMissingNode() || node.isNull()) return Optional.empty();
        if (node.isObject()) {
            String type = node.path("type").asText("");
            String mime = node.path("mimeType").asText("");
            String data = node.path("data").asText("");
            if ((("image".equalsIgnoreCase(type)) || mime.toLowerCase(Locale.ROOT).contains("png")) && notBlank(data)) {
                try { return Optional.of(Base64.getDecoder().decode(data)); } catch (Exception ignored) {}
            }
            Iterator<Map.Entry<String, JsonNode>> fields = node.fields();
            while (fields.hasNext()) {
                Optional<byte[]> found = findImageBytes(fields.next().getValue());
                if (found.isPresent()) return found;
            }
        } else if (node.isArray()) {
            for (JsonNode child : node) {
                Optional<byte[]> found = findImageBytes(child);
                if (found.isPresent()) return found;
            }
        } else if (node.isTextual()) {
            String text = node.asText();
            if (text.startsWith("data:image/png;base64,")) text = text.substring("data:image/png;base64,".length());
            if (text.length() > 1000 && text.matches("^[A-Za-z0-9+/=\\r\\n]+$")) {
                try { return Optional.of(Base64.getDecoder().decode(text.replaceAll("\\s+", ""))); } catch (Exception ignored) {}
            }
        }
        return Optional.empty();
    }

    private String applyData(String input, Map<String, Object> data) {
        if (input == null || data == null) return input;
        String output = input;
        for (Map.Entry<String, Object> e : data.entrySet()) {
            String value = e.getValue() == null ? "" : String.valueOf(e.getValue());
            output = output.replace("{{" + e.getKey() + "}}", value);
            output = output.replace("${" + e.getKey() + "}", value);
        }
        return output;
    }

    private List<String> splitArgs(String args) {
        if (args == null || args.isBlank()) return List.of();
        List<String> out = new ArrayList<>();
        Matcher m = Pattern.compile("([^\\s\"]+)|\"([^\"]*)\"").matcher(args);
        while (m.find()) out.add(m.group(1) != null ? m.group(1) : m.group(2));
        return out;
    }

    private String resolveUrl(String url, String base) {
        if (!notBlank(url)) return "";
        String trimmed = url.trim();
        if (trimmed.startsWith("http://") || trimmed.startsWith("https://")) return trimmed;
        if (!notBlank(base)) return trimmed;
        if (base.endsWith("/") && trimmed.startsWith("/")) return base.substring(0, base.length() - 1) + trimmed;
        if (!base.endsWith("/") && !trimmed.startsWith("/")) return base + "/" + trimmed;
        return base + trimmed;
    }

    private boolean shouldScreenshot(RunConfig config, boolean pass) {
        String mode = config.getScreenshotMode() == null ? "FAILURE_ONLY" : config.getScreenshotMode();
        if ("NONE".equalsIgnoreCase(mode)) return false;
        if ("ALL".equalsIgnoreCase(mode)) return true;
        return !pass;
    }

    private String firstText(JsonNode node, String... fields) {
        if (node == null) return null;
        for (String f : fields) {
            JsonNode v = node.path(f);
            if (v.isTextual() && !v.asText().isBlank()) return v.asText();
        }
        return null;
    }

    private boolean schemaContains(McpTool tool, String term) {
        return tool != null && tool.getInputSchema() != null && tool.getInputSchema().toString().toLowerCase(Locale.ROOT).contains(term.toLowerCase(Locale.ROOT));
    }

    private boolean containsAny(String text, String... terms) {
        if (text == null) return false;
        String l = text.toLowerCase(Locale.ROOT);
        for (String t : terms) if (l.contains(t.toLowerCase(Locale.ROOT))) return true;
        return false;
    }

    private boolean notBlank(String value) { return value != null && !value.trim().isEmpty(); }

    private String compact(String text, int max) {
        if (text == null) return "";
        String s = text.replaceAll("\\s+", " ").trim();
        return s.length() <= max ? s : s.substring(0, max) + "...";
    }

    private String cleanTarget(String raw) {
        if (raw == null) return "";
        return raw
                .replaceAll("(?i)\\s+from\\s+(search\\s+results?|drop\\s*down|dropdown|list|results?).*$", "")
                .replaceAll("(?i)\\b(icon|field|button|link|menu)$", "")
                .replaceAll("(?i)^the\\s+", "")
                .trim();
    }

    private String cssEscape(String input) { return input == null ? "" : input.replace("'", "\\'").trim(); }

    private void writeToolsManifest(Path runDir, List<McpTool> tools) {
        try {
            Files.createDirectories(runDir);
            Files.writeString(runDir.resolve("mcp-tools.json"), mapper.writerWithDefaultPrettyPrinter().writeValueAsString(tools), StandardCharsets.UTF_8);
        } catch (Exception ignored) {}
    }

    private record FillSpec(String target, String value) {}
}
