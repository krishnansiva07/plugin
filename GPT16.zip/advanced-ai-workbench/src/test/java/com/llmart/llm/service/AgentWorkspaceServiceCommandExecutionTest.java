package com.llmart.llm.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.llmart.llm.entity.ProjectWorkspaceEntity;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class AgentWorkspaceServiceCommandExecutionTest {

    @TempDir
    Path temp;

    @Test
    void foregroundCommandCapturesMergedOutputThroughPipe() throws Exception {
        Path workspace = temp.resolve("workspace");
        Files.createDirectories(workspace);
        Files.writeString(workspace.resolve("README.md"), "test\n");

        ProjectService projects = mock(ProjectService.class);
        ProjectWorkspaceEntity entity = mock(ProjectWorkspaceEntity.class);
        when(projects.require("p1")).thenReturn(entity);
        when(entity.hasLocalPath()).thenReturn(true);
        when(entity.getLocalPath()).thenReturn(workspace.toString());

        AgentWorkspaceService service = new AgentWorkspaceService(projects, new ObjectMapper(), new PromptResourceResolver());
        AgentWorkspaceService.Workspace ws = service.prepare("p1");
        AgentRunService.AgentRun run = new AgentRunService().start("c1", "p1");

        AgentWorkspaceService.CommandResult result = service.runCommand(
                ws,
                isWindows() ? "echo hello-from-agent" : "printf 'hello-from-agent'; printf ' stderr-ok' >&2",
                "",
                true,
                Set.of(),
                10,
                run);

        assertEquals(0, result.exitCode());
        assertTrue(result.output().contains("hello-from-agent"));
        if (!isWindows()) assertTrue(result.output().contains("stderr-ok"));
    }

    @Test
    void failedCommandIsReturnedAsResultInsteadOfThrowingTempFileCleanupError() throws Exception {
        Path workspace = temp.resolve("workspace-fail");
        Files.createDirectories(workspace);

        ProjectService projects = mock(ProjectService.class);
        ProjectWorkspaceEntity entity = mock(ProjectWorkspaceEntity.class);
        when(projects.require("p2")).thenReturn(entity);
        when(entity.hasLocalPath()).thenReturn(true);
        when(entity.getLocalPath()).thenReturn(workspace.toString());

        AgentWorkspaceService service = new AgentWorkspaceService(projects, new ObjectMapper(), new PromptResourceResolver());
        AgentWorkspaceService.Workspace ws = service.prepare("p2");
        AgentRunService.AgentRun run = new AgentRunService().start("c2", "p2");

        AgentWorkspaceService.CommandResult result = service.runCommand(
                ws,
                "definitely-not-a-real-command-advanced-ai",
                "",
                true,
                Set.of(),
                10,
                run);

        assertNotEquals(0, result.exitCode());
        assertFalse(result.output().isBlank());
    }


    @Test
    void identicalDirectWriteIsReportedAsNoChange() throws Exception {
        Path workspace = temp.resolve("workspace-noop");
        Files.createDirectories(workspace);
        Files.writeString(workspace.resolve("sample.txt"), "same-content");

        ProjectService projects = mock(ProjectService.class);
        ProjectWorkspaceEntity entity = mock(ProjectWorkspaceEntity.class);
        when(projects.require("p3")).thenReturn(entity);
        when(entity.hasLocalPath()).thenReturn(true);
        when(entity.getLocalPath()).thenReturn(workspace.toString());

        AgentWorkspaceService service = new AgentWorkspaceService(projects, new ObjectMapper(), new PromptResourceResolver());
        AgentWorkspaceService.Workspace ws = service.prepare("p3");

        String result = service.writeFile(ws, "sample.txt", "same-content");

        assertTrue(result.startsWith("workspaceChanged=false;"));
        assertTrue(service.changes(ws).isEmpty(), "a no-op write must not create a synthetic workspace revision");
    }

    private static boolean isWindows() {
        return System.getProperty("os.name", "").toLowerCase().contains("win");
    }
}
