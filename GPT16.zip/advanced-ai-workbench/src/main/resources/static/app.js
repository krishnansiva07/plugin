'use strict';

const state = {
  conversationId: null,
  conversations: [],
  messages: [],
  attachments: [],
  filesById: new Map(),
  uploadingCount: 0,
  project: null,
  projectRootHandle: null,
  projectFallbackFiles: null,
  pendingProjectChanges: null,
  mode: ['chat','agent'].includes(localStorage.getItem('llm.mode')) ? localStorage.getItem('llm.mode') : 'chat',
  streaming: false,
  abortController: null,
  activeAgentRunId: null,
  agentWatchTimer: null,
  agentWatchdogCompleted: false,
  renderTimer: null,
  editingIndex: null,
  historyMenuId: null,
  renameId: null,
  userScrolledUp: false,
  config: {
    apiKey: sessionStorage.getItem('llm.apiKey') || localStorage.getItem('llm.apiKey') || '',
    baseUrl: localStorage.getItem('llm.baseUrl') || '',
    model: localStorage.getItem('llm.model') || '',
    visionModel: localStorage.getItem('llm.visionModel') || '',
    temperature: Number(localStorage.getItem('llm.temperature') || 0.7),
    maxTokens: Number(localStorage.getItem('llm.maxTokens') || 0),
    contextChars: 0,
    contextWindowTokens: Number(localStorage.getItem('llm.contextWindowTokens') || (Number(localStorage.getItem('llm.contextChars') || 0) > 0 ? Math.floor(Number(localStorage.getItem('llm.contextChars')) / 4) : 0)),
    autoCompact: localStorage.getItem('llm.autoCompact') !== 'false',
    compactionKeepTokens: Number(localStorage.getItem('llm.compactionKeepTokens') || 8000),
    compactionBufferTokens: Number(localStorage.getItem('llm.compactionBufferTokens') || 20000),
    oldToolOutputChars: Number(localStorage.getItem('llm.oldToolOutputChars') || 2000),
    systemPrompt: localStorage.getItem('llm.systemPrompt') || '',
    useFileContext: localStorage.getItem('llm.useFileContext') !== 'false',
    agentAllowCommands: localStorage.getItem('llm.agentAllowCommands') !== 'false',
    agentEditPermission: localStorage.getItem('llm.agentEditPermission') || 'allow',
    agentShellPermission: localStorage.getItem('llm.agentShellPermission') || 'allow',
    agentReviewPermission: localStorage.getItem('llm.agentReviewPermission') || localStorage.getItem('llm.agentGitPermission') || 'allow',
    agentMcpPermission: localStorage.getItem('llm.agentMcpPermission') || 'allow',
    agentTaskPermission: localStorage.getItem('llm.agentTaskPermission') || 'allow',
    agentLspPermission: localStorage.getItem('llm.agentLspPermission') || 'allow',
    agentParallelReadTools: localStorage.getItem('llm.agentParallelReadTools') !== 'false',
    agentAutoApprove: localStorage.getItem('llm.agentAutoApprove') === 'true',
    agentExtraCommands: localStorage.getItem('llm.agentExtraCommands') || '',
    rememberKey: Boolean(localStorage.getItem('llm.apiKey'))
  }
};

const $ = id => document.getElementById(id);
const esc = value => MarkdownRenderer.escapeHtml(value);

function isConfigured() {
  return Boolean(state.config.apiKey && state.config.baseUrl && state.config.model);
}

async function api(url, options = {}) {
  const response = await fetch(url, options);
  if (!response.ok) {
    let message = `HTTP ${response.status}`;
    try {
      const contentType = response.headers.get('content-type') || '';
      if (contentType.includes('application/json')) {
        const body = await response.json();
        message = body.message || body.error || message;
      } else {
        const body = await response.text();
        if (body.trim()) message = body.trim().slice(0, 1200);
      }
    } catch (_) { /* ignore parse failure */ }
    throw new Error(message);
  }
  if (response.status === 204) return null;
  const contentType = response.headers.get('content-type') || '';
  return contentType.includes('application/json') ? response.json() : response;
}

function toast(text, duration = 2300) {
  const node = $('toast');
  node.textContent = text;
  node.classList.remove('hidden');
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => node.classList.add('hidden'), duration);
}

function saveConfig() {
  localStorage.setItem('llm.baseUrl', state.config.baseUrl);
  localStorage.setItem('llm.model', state.config.model);
  localStorage.setItem('llm.visionModel', state.config.visionModel || '');
  localStorage.setItem('llm.temperature', String(state.config.temperature));
  localStorage.setItem('llm.maxTokens', String(state.config.maxTokens));
  localStorage.removeItem('llm.contextChars');
  localStorage.setItem('llm.contextWindowTokens', String(state.config.contextWindowTokens));
  localStorage.setItem('llm.autoCompact', String(state.config.autoCompact));
  localStorage.setItem('llm.compactionKeepTokens', String(state.config.compactionKeepTokens));
  localStorage.setItem('llm.compactionBufferTokens', String(state.config.compactionBufferTokens));
  localStorage.setItem('llm.oldToolOutputChars', String(state.config.oldToolOutputChars));
  localStorage.setItem('llm.systemPrompt', state.config.systemPrompt);
  localStorage.setItem('llm.useFileContext', String(state.config.useFileContext));
  localStorage.setItem('llm.agentAllowCommands', String(state.config.agentAllowCommands));
  localStorage.setItem('llm.agentEditPermission', state.config.agentEditPermission);
  localStorage.setItem('llm.agentShellPermission', state.config.agentShellPermission);
  localStorage.setItem('llm.agentReviewPermission', state.config.agentReviewPermission);
  localStorage.setItem('llm.agentMcpPermission', state.config.agentMcpPermission);
  localStorage.setItem('llm.agentTaskPermission', state.config.agentTaskPermission);
  localStorage.setItem('llm.agentLspPermission', state.config.agentLspPermission);
  localStorage.setItem('llm.agentParallelReadTools', String(state.config.agentParallelReadTools));
  localStorage.setItem('llm.agentAutoApprove', String(state.config.agentAutoApprove));
  localStorage.setItem('llm.agentExtraCommands', state.config.agentExtraCommands || '');
  localStorage.setItem('llm.mode', state.mode);

  if (state.config.rememberKey) {
    localStorage.setItem('llm.apiKey', state.config.apiKey);
    sessionStorage.removeItem('llm.apiKey');
  } else {
    localStorage.removeItem('llm.apiKey');
    if (state.config.apiKey) sessionStorage.setItem('llm.apiKey', state.config.apiKey);
    else sessionStorage.removeItem('llm.apiKey');
  }

  updateModelBadge();
  updateWelcomeMode();
  if (document.getElementById('attachmentTray')) renderAttachmentTray();
}

function syncSettingsUi() {
  $('apiKey').value = state.config.apiKey;
  $('baseUrl').value = state.config.baseUrl;
  $('modelName').value = state.config.model;
  $('visionModel').value = state.config.visionModel || '';
  $('temperature').value = state.config.temperature;
  $('maxTokens').value = state.config.maxTokens;
  $('contextWindowTokens').value = state.config.contextWindowTokens;
  $('autoCompact').checked = state.config.autoCompact;
  $('compactionKeepTokens').value = state.config.compactionKeepTokens;
  $('compactionBufferTokens').value = state.config.compactionBufferTokens;
  $('oldToolOutputChars').value = state.config.oldToolOutputChars;
  $('systemPrompt').value = state.config.systemPrompt;
  $('useFileContext').checked = state.config.useFileContext;
  $('agentAllowCommands').checked = state.config.agentAllowCommands;
  $('agentEditPermission').value = state.config.agentEditPermission;
  $('agentShellPermission').value = state.config.agentShellPermission;
  $('agentReviewPermission').value = state.config.agentReviewPermission;
  $('agentMcpPermission').value = state.config.agentMcpPermission;
  $('agentTaskPermission').value = state.config.agentTaskPermission;
  $('agentLspPermission').value = state.config.agentLspPermission;
  $('agentParallelReadTools').checked = state.config.agentParallelReadTools;
  $('agentAutoApprove').checked = state.config.agentAutoApprove;
  $('agentExtraCommands').value = state.config.agentExtraCommands || '';
  $('rememberKey').checked = state.config.rememberKey;

  $('homeApiKey').value = state.config.apiKey;
  $('homeBaseUrl').value = state.config.baseUrl;
  $('homeModel').value = state.config.model;
  $('homeVisionModel').value = state.config.visionModel || '';
  $('homeRemember').checked = state.config.rememberKey;
}

function updateModelBadge() {
  $('modelBadge').textContent = state.config.model || 'Model not configured';
}

function setMode(mode, persist = true) {
  const next = ['chat', 'agent'].includes(String(mode)) ? String(mode) : 'chat';
  if (state.streaming) return toast('Stop the current response before changing mode');
  state.mode = next;
  if (persist) localStorage.setItem('llm.mode', next);
  updateModeUi();
}

function updateModeUi() {
  document.querySelectorAll('[data-mode]').forEach(button => {
    const active = button.dataset.mode === state.mode;
    button.classList.toggle('active', active);
    button.setAttribute('aria-selected', String(active));
  });
  const hints = {
    chat: 'Normal conversation. It can use attachments and mapped workspace context, but it does not execute tools.',
    agent: state.project
      ? 'Autonomous work directly in the mapped local path: inspect → edit → run/verify → finish.'
      : 'Agent mode can use the active workspace or automatically resolve an existing project/file path written in your prompt.'
  };
  if ($('modeHint')) $('modeHint').textContent = hints[state.mode] || hints.chat;
  if ($('messageInput')) {
    const placeholders = {
      chat: 'Message Advanced AI Workbench',
      agent: 'Give the agent a task and include the project/file path(s) it should work with…'
    };
    $('messageInput').placeholder = placeholders[state.mode] || placeholders.chat;
  }
  document.body.dataset.chatMode = state.mode;
}

function updateWelcomeMode() {
  const setup = document.querySelector('.setup-card');
  const configured = isConfigured();
  setup.classList.toggle('hidden', configured);
  const textOnlyHint = configured && /^gpt-oss(?:-|$)/i.test(state.config.model || '') && !state.config.visionModel;
  const modeLabel = state.mode === 'agent' ? 'Agent' : 'Chat';
  $('welcomeText').textContent = configured
    ? (textOnlyHint
        ? `Connected to ${state.config.model} · ${modeLabel} mode. Text is ready; configure a Vision model for screenshot/image analysis.`
        : `Connected to ${state.config.model} · ${modeLabel} mode. Attach files or start typing.`)
    : 'Connect your OpenAI-compatible model, then choose Chat or Agent mode.';
}

function updateContextBadge() {
  const chars = state.messages.reduce((sum, item) => sum + String(item.content || '').length, 0);
  const estimatedTokens = Math.ceil(chars / 4);
  const limit = state.config.contextWindowTokens || 0;
  $('contextBadge').textContent = limit > 0
    ? `~${formatCompact(estimatedTokens)} / ${formatCompact(limit)} tokens`
    : `~${formatCompact(estimatedTokens)} tokens · agent auto-detect`;
}

function formatCompact(n) {
  const value = Number(n || 0);
  if (value >= 1_000_000) return `${(value / 1_000_000).toFixed(value >= 10_000_000 ? 0 : 1)}m`;
  if (value >= 1_000) return `${(value / 1_000).toFixed(value >= 10_000 ? 0 : 1)}k`;
  return String(value);
}

function formatBytes(bytes) {
  const value = Number(bytes || 0);
  if (value < 1024) return `${value} B`;
  if (value < 1024 * 1024) return `${(value / 1024).toFixed(1)} KB`;
  return `${(value / 1024 / 1024).toFixed(1)} MB`;
}

async function loadConversations() {
  state.conversations = await api('/api/conversations');
  renderHistory($('historySearch').value || '');
}

function renderHistory(filter = '') {
  const q = filter.trim().toLowerCase();
  const list = state.conversations.filter(c => !q || String(c.title || '').toLowerCase().includes(q));
  if (!list.length) {
    $('historyList').innerHTML = `<div class="history-empty">${q ? 'No matching chats' : 'Your chats will appear here'}</div>`;
    return;
  }
  $('historyList').innerHTML = list.map(c => `
    <div class="history-item ${c.id === state.conversationId ? 'active' : ''}" data-id="${esc(c.id)}" title="${esc(c.title)}">
      <span class="history-title">${esc(c.title || 'New chat')}</span>
      <button class="history-menu" type="button" data-menu="${esc(c.id)}" aria-label="Chat options">⋯</button>
    </div>`).join('');
}

function newChat() {
  const persistentLocalWorkspace = state.project?.localWorkspace ? state.project : null;
  if (state.streaming) {
    const runId = state.activeAgentRunId;
    if (runId) fetch(`/api/agent/runs/${encodeURIComponent(runId)}/cancel`, { method: 'POST' }).catch(() => {});
    state.abortController?.abort();
  }
  state.activeAgentRunId = null;
  state.conversationId = null;
  state.messages = [];
  state.attachments = [];
  state.filesById = new Map();
  state.project = persistentLocalWorkspace;
  state.projectRootHandle = null;
  state.projectFallbackFiles = null;
  state.pendingProjectChanges = null;
  state.editingIndex = null;
  state.userScrolledUp = false;
  $('conversationTitle').textContent = 'New chat';
  $('historySearch').value = '';
  closeHistoryMenu();
  renderHistory();
  renderAttachmentTray();
  renderProjectBar();
  renderMessages();
  updateModeUi();
  updateWelcomeMode();
  $('messageInput').value = '';
  autoGrow();
  $('messageInput').focus();
}

async function ensureConversation() {
  if (state.conversationId) return state.conversationId;
  const created = await api('/api/conversations', { method: 'POST' });
  state.conversationId = created.id;
  $('conversationTitle').textContent = created.title || 'New chat';
  await loadConversations();
  return created.id;
}

async function openConversation(id) {
  if (state.streaming) return toast('Stop the current response before switching chats');
  closeHistoryMenu();
  state.conversationId = id;
  state.editingIndex = null;
  const [messages, files, projects] = await Promise.all([
    api(`/api/conversations/${encodeURIComponent(id)}/messages`),
    api(`/api/files?conversationId=${encodeURIComponent(id)}`),
    api(`/api/projects?conversationId=${encodeURIComponent(id)}`)
  ]);
  state.messages = messages || [];
  state.filesById = new Map((files || []).map(file => [file.id, file]));
  state.attachments = [];
  const conversationProject = Array.isArray(projects) && projects.length ? projects[0] : null;
  // A local path is a persistent application workspace. Opening a different chat must not silently
  // replace it with that chat's old browser-indexed snapshot. Only another local workspace can replace it.
  if (conversationProject?.localWorkspace) {
    state.project = conversationProject;
    rememberActiveLocalWorkspace(conversationProject);
  } else if (!state.project?.localWorkspace) {
    await restoreActiveLocalWorkspace();
    if (!state.project?.localWorkspace && conversationProject) state.project = conversationProject;
  }
  state.projectRootHandle = null;
  state.projectFallbackFiles = null;
  const conversation = state.conversations.find(c => c.id === id);
  $('conversationTitle').textContent = conversation?.title || 'Chat';
  renderMessages();
  renderAttachmentTray();
  renderProjectBar();
  updateModeUi();
  renderHistory($('historySearch').value || '');
  $('sidebar').classList.remove('open');
  state.userScrolledUp = false;
  scrollBottom(true);
}

function attachmentHtml(ids) {
  if (!Array.isArray(ids) || !ids.length) return '';
  const cards = ids.map(id => {
    const file = state.filesById.get(id);
    if (!file) return `<span class="message-file"><span class="file-icon">📎</span><span class="file-text"><span class="file-name">Attachment</span></span></span>`;
    const image = String(file.mimeType || '').toLowerCase().startsWith('image/');
    const visual = image
      ? `<img class="attachment-thumb" src="/api/files/${encodeURIComponent(id)}/view" alt="${esc(file.name)}" />`
      : `<span class="file-icon">${fileIcon(file.mimeType, file.name)}</span>`;
    return `<a class="message-file" href="/api/files/${encodeURIComponent(id)}/download" title="Download ${esc(file.name)}">
      ${visual}
      <span class="file-text"><span class="file-name">${esc(file.name)}</span><span class="file-meta">${esc(formatBytes(file.size))}${Number(file.extractedCharacters || 0) > 0 ? ` · ${esc(formatCompact(file.extractedCharacters))} text chars` : ''}</span></span>
    </a>`;
  }).join('');
  return `<div class="attachment-list">${cards}</div>`;
}

function fileIcon(mime, name) {
  const m = String(mime || '').toLowerCase();
  const n = String(name || '').toLowerCase();
  if (m.startsWith('image/')) return '🖼';
  if (m.includes('pdf') || n.endsWith('.pdf')) return 'PDF';
  if (m.includes('spreadsheet') || m.includes('excel') || /\.(xlsx?|csv)$/.test(n)) return 'XLS';
  if (m.includes('word') || /\.docx?$/.test(n)) return 'DOC';
  if (m.includes('presentation') || /\.pptx?$/.test(n)) return 'PPT';
  if (/\.(java|js|ts|py|json|xml|html|css|sql|yml|yaml|sh)$/.test(n)) return '&lt;/&gt;';
  return '📎';
}

function agentStepsHtml(message) {
  const steps = Array.isArray(message.agentSteps) ? message.agentSteps : [];
  const progress = message.agentProgress || null;
  if (!steps.length && !progress) return '';
  const rows = steps.map(step => {
    const status = ['success', 'error', 'running', 'approval', 'done'].includes(step.status) ? step.status : 'running';
    const icon = status === 'success' || status === 'done' ? '✓' : status === 'error' ? '!' : status === 'approval' ? '?' : '↻';
    const args = step.args ? JSON.stringify(step.args, null, 2) : '';
    const details = (args || step.output) ? `<details class="agent-step-details"><summary>Details</summary>${args ? `<div class="agent-detail-label">Input</div><pre>${esc(args)}</pre>` : ''}${step.output ? `<div class="agent-detail-label">Output</div><pre>${esc(step.output)}</pre>` : ''}</details>` : '';
    const approval = status === 'approval' && step.approvalId
      ? `<div class="agent-approval-actions"><button type="button" class="secondary-btn" data-agent-approval="${esc(step.approvalId)}" data-approval-action="deny">Deny</button><button type="button" class="secondary-btn" data-agent-approval="${esc(step.approvalId)}" data-approval-action="once">Approve once</button><button type="button" class="primary-btn" data-agent-approval="${esc(step.approvalId)}" data-approval-action="run">Allow this run</button></div>` : '';
    return `<div class="agent-step ${status}"><div class="agent-step-line"><span class="agent-step-icon">${icon}</span><span class="agent-step-tool">${esc(step.tool || 'agent')}</span><span class="agent-step-detail">${esc(step.detail || '')}</span></div>${approval}${details}</div>`;
  }).join('');
  const waiting = steps.some(step => step.status === 'approval');
  const changed = Number(message.agentDirectChangeCount || 0);
  const summary = changed > 0 ? `${changed} file${changed === 1 ? '' : 's'} changed directly` : `${steps.length} event${steps.length === 1 ? '' : 's'}`;
  const pct = Math.max(0, Math.min(100, Number(progress?.percent ?? (message.streaming ? 2 : 100))));
  const phase = progress?.phase || (message.streaming ? 'starting' : 'completed');
  const detail = progress?.detail || (message.streaming ? 'Preparing agent run' : 'Task completed');
  const usage = progress?.tokenUsage || {};
  const providerTotal = Number(usage.providerTotalTokens || 0);
  const contextNow = Number(usage.currentContextTokens || 0);
  const contextWindow = Number(usage.contextWindowTokens || 0);
  const tokenLine = (providerTotal || contextNow)
    ? `<div class="agent-token-line">${contextNow ? `Context ~${esc(formatCompact(contextNow))}${contextWindow ? ` / ${esc(formatCompact(contextWindow))}` : ''}` : ''}${providerTotal ? `${contextNow ? ' · ' : ''}Run tokens ${esc(formatCompact(providerTotal))}` : ''}${Number(usage.compactions || 0) ? ` · ${esc(String(usage.compactions))} compaction${Number(usage.compactions) === 1 ? '' : 's'}` : ''}</div>`
    : '';
  const progressHtml = `<div class="agent-progress"><div class="agent-progress-top"><strong>${esc(String(phase).replaceAll('_',' '))}</strong><span class="agent-progress-percent">${esc(String(Math.round(pct)))}%</span></div><div class="agent-progress-track" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${esc(String(Math.round(pct)))}"><div class="agent-progress-fill" style="width:${esc(String(pct))}%"></div></div><div class="agent-progress-detail">${esc(detail)}</div>${tokenLine}</div>`;
  return `<div class="agent-run-card ${waiting ? 'waiting-approval' : ''}"><div class="agent-run-head"><span>⚡ Agent console</span><span>${summary}</span></div>${progressHtml}${rows}</div>`;
}

function messageHtml(message, index) {
  const assistant = message.role === 'assistant';
  const isLastAssistant = assistant && index === state.messages.length - 1;

  if (!assistant && state.editingIndex === index) {
    return `<article class="message user" data-message-index="${index}">
      <div class="avatar">You</div>
      <div class="message-body">
        ${attachmentHtml(message.attachmentIds)}
        <div class="edit-panel">
          <textarea id="editMessageInput" class="edit-textarea" rows="4">${esc(message.content || '')}</textarea>
          <div class="edit-actions"><button class="secondary-btn" type="button" data-edit-cancel="${index}">Cancel</button><button class="primary-btn" type="button" data-edit-save="${index}">Save & submit</button></div>
        </div>
      </div>
    </article>`;
  }

  const displayContent = assistant ? stripProjectMarkers(message.content || '') : (message.content || '');
  const rendered = MarkdownRenderer.render(displayContent, { streaming: Boolean(message.streaming) });
  const contentClass = assistant && message.streaming ? 'message-content typing-cursor' : 'message-content';
  const excelAction = assistant && !message.streaming && (hasMarkdownTable(message.content || '') || isExcelRequestedForAssistant(index))
    ? `<button class="mini-btn artifact-btn" type="button" data-excel-msg="${index}">▦ Excel</button>` : '';
  const projectChanges = assistant && !message.streaming ? extractProjectFileChanges(message.content || '') : [];
  const projectAction = projectChanges.length
    ? `<button class="mini-btn artifact-btn" type="button" data-project-changes="${index}">⌘ Review ${projectChanges.length} file${projectChanges.length === 1 ? '' : 's'}</button>` : '';
  const actions = assistant
    ? `<button class="mini-btn" type="button" data-copy-msg="${index}">Copy</button><button class="mini-btn" type="button" data-download-msg="${index}">Download</button>${excelAction}${projectAction}${isLastAssistant && !message.streaming ? `<button class="mini-btn" type="button" data-regenerate="${index}">Regenerate</button>` : ''}`
    : `<button class="mini-btn" type="button" data-edit-msg="${index}">Edit</button><button class="mini-btn" type="button" data-copy-msg="${index}">Copy</button>`;

  return `<article class="message ${assistant ? 'assistant' : 'user'}" data-message-index="${index}">
    <div class="avatar">${assistant ? 'AI' : 'You'}</div>
    <div class="message-body">
      ${attachmentHtml(message.attachmentIds)}
      ${assistant ? agentStepsHtml(message) : ''}
      <div class="${contentClass}">${rendered}</div>
      <div class="message-actions">${actions}</div>
    </div>
  </article>`;
}

function renderMessages() {
  $('messages').innerHTML = state.messages.map(messageHtml).join('');
  $('welcome').classList.toggle('hidden', state.messages.length > 0);
  updateContextBadge();
  if (state.editingIndex != null) {
    requestAnimationFrame(() => {
      const input = $('editMessageInput');
      if (input) { input.focus(); input.setSelectionRange(input.value.length, input.value.length); }
    });
  }
}

function updateStreamingMessage(index) {
  const article = $('messages').querySelector(`[data-message-index="${index}"]`);
  const message = state.messages[index];
  if (!article || !message) return renderMessages();
  const content = article.querySelector('.message-content');
  if (!content) return;
  content.innerHTML = MarkdownRenderer.render(stripProjectMarkers(message.content || ''), { streaming: true });
  content.classList.add('typing-cursor');
  updateContextBadge();
}


function updateAgentProgressUi(index) {
  const article = $('messages')?.querySelector(`[data-message-index="${index}"]`);
  const message = state.messages[index];
  if (!article || !message) return;
  const card = article.querySelector('.agent-run-card');
  if (!card) { renderMessages(); return; }
  const progress = message.agentProgress || {};
  const pct = Math.max(0, Math.min(100, Number(progress.percent ?? (message.streaming ? 2 : 100))));
  const phase = String(progress.phase || (message.streaming ? 'working' : 'completed')).replaceAll('_', ' ');
  const detail = progress.detail || (message.streaming ? 'Agent is working' : 'Task completed');
  const phaseEl = card.querySelector('.agent-progress-top strong');
  const pctEl = card.querySelector('.agent-progress-percent');
  const fillEl = card.querySelector('.agent-progress-fill');
  const detailEl = card.querySelector('.agent-progress-detail');
  if (phaseEl) phaseEl.textContent = phase;
  if (pctEl) pctEl.textContent = `${Math.round(pct)}%`;
  if (fillEl) fillEl.style.width = `${pct}%`;
  if (detailEl) detailEl.textContent = detail;
  const track = card.querySelector('.agent-progress-track');
  if (track) track.setAttribute('aria-valuenow', String(Math.round(pct)));
  const usage = progress.tokenUsage || {};
  const providerTotal = Number(usage.providerTotalTokens || 0);
  const contextNow = Number(usage.currentContextTokens || 0);
  const contextWindow = Number(usage.contextWindowTokens || 0);
  const compactions = Number(usage.compactions || 0);
  let tokenText = '';
  if (contextNow) tokenText += `Context ~${formatCompact(contextNow)}${contextWindow ? ` / ${formatCompact(contextWindow)}` : ''}`;
  if (providerTotal) tokenText += `${tokenText ? ' · ' : ''}Run tokens ${formatCompact(providerTotal)}`;
  if (compactions) tokenText += `${tokenText ? ' · ' : ''}${compactions} compaction${compactions === 1 ? '' : 's'}`;
  let tokenEl = card.querySelector('.agent-token-line');
  if (tokenText && !tokenEl) {
    tokenEl = document.createElement('div');
    tokenEl.className = 'agent-token-line';
    card.querySelector('.agent-progress')?.appendChild(tokenEl);
  }
  if (tokenEl) { tokenEl.textContent = tokenText; tokenEl.classList.toggle('hidden', !tokenText); }
}

function scheduleStreamingRender(index) {
  if (state.renderTimer) return;
  state.renderTimer = setTimeout(() => {
    state.renderTimer = null;
    updateStreamingMessage(index);
    if (!state.userScrolledUp) scrollBottom(false);
  }, 45);
}

function nearBottom() {
  const view = $('chatView');
  return view.scrollHeight - view.scrollTop - view.clientHeight < 180;
}

function scrollBottom(force = false) {
  if (!force && state.userScrolledUp) return;
  const view = $('chatView');
  requestAnimationFrame(() => {
    view.scrollTop = view.scrollHeight;
    if (force) state.userScrolledUp = false;
    updateScrollButton();
  });
}

function updateScrollButton() {
  $('scrollBottomBtn').classList.toggle('hidden', nearBottom());
}

function setStreaming(value) {
  state.streaming = value;
  $('sendBtn').classList.toggle('hidden', value);
  $('stopBtn').classList.toggle('hidden', !value);
  $('attachBtn').disabled = value;
}

async function stopCurrentRun() {
  const runId = state.activeAgentRunId;
  if (runId) {
    try { await api(`/api/agent/runs/${encodeURIComponent(runId)}/cancel`, { method: 'POST' }); }
    catch (_) { /* the HTTP stream may already be closing */ }
  }
  state.abortController?.abort();
}

function stopAgentWatch() {
  if (state.agentWatchTimer) clearInterval(state.agentWatchTimer);
  state.agentWatchTimer = null;
}

function startAgentWatch(runId, assistant, assistantIndex) {
  stopAgentWatch();
  state.agentWatchdogCompleted = false;
  let polling = false;
  const tick = async () => {
    if (polling || !runId) return;
    polling = true;
    try {
      const snapshot = await api(`/api/agent/runs/${encodeURIComponent(runId)}`);
      assistant.agentProgress = {
        percent: Number(snapshot.progressPercent || 0),
        phase: snapshot.progressPhase || snapshot.status || 'working',
        detail: snapshot.progressDetail || '',
        status: snapshot.status || 'running',
        responsePersisted: Boolean(snapshot.responsePersisted),
        tokenUsage: snapshot.tokenUsage || {}
      };
      updateAgentProgressUi(assistantIndex);

      if (snapshot.responsePersisted && snapshot.finishedAt) {
        if (typeof snapshot.finalAnswer === 'string' && snapshot.finalAnswer.trim()) assistant.content = snapshot.finalAnswer;
        assistant.streaming = false;
        state.agentWatchdogCompleted = true;
        renderMessages();
        stopAgentWatch();
        // The durable run state is authoritative. If the HTTP/SSE stream fails to close after the terminal
        // response was persisted, end only the stale transport; do not ask the user to press Stop.
        setTimeout(() => {
          if (state.streaming && !assistant.serverDone && state.activeAgentRunId === runId) state.abortController?.abort();
        }, 900);
      }
    } catch (_) { /* SSE remains the primary path; transient status polling failures are harmless */ }
    finally { polling = false; }
  };
  tick();
  state.agentWatchTimer = setInterval(tick, 850);
}

async function sendMessage({ regenerate = false, overrideMessage = null } = {}) {
  if (state.streaming) return;
  if (state.uploadingCount > 0) return toast('Wait for the file upload to finish');
  if (!isConfigured()) {
    openSettings();
    return toast('Configure API key, base URL and model first');
  }
  await ensureConversation();
  const pendingAttachments = regenerate ? [] : [...state.attachments];
  let text = overrideMessage != null ? String(overrideMessage).trim() : $('messageInput').value.trim();
  if (!regenerate && !text && pendingAttachments.length) text = 'Please analyze the attached file(s).';
  if (!regenerate && !text) return;

  const hasPendingImage = pendingAttachments.some(file => String(file.mimeType || '').startsWith('image/'));
  if (!regenerate && hasPendingImage && isKnownTextOnlyMainModel(state.config.model) && !state.config.visionModel) {
    openSettings();
    return toast(`${state.config.model} is text-only. Configure a Vision model to analyze screenshots/images.`, 7000);
  }

  if (!regenerate) {
    state.messages.push({
      role: 'user',
      content: text,
      attachmentIds: pendingAttachments.map(file => file.id),
      createdAt: new Date().toISOString()
    });
    $('messageInput').value = '';
    state.attachments = [];
    autoGrow();
    renderAttachmentTray();
  }

  const assistantIndex = state.messages.length;
  const assistant = { role: 'assistant', content: '', streaming: true, attachmentIds: [], mode: state.mode, agentSteps: state.mode === 'agent' ? [] : undefined };
  state.messages.push(assistant);
  state.editingIndex = null;
  state.userScrolledUp = false;
  renderMessages();
  scrollBottom(true);
  setStreaming(true);
  state.agentWatchdogCompleted = false;

  const payload = {
    conversationId: state.conversationId,
    message: regenerate ? null : text,
    attachmentIds: pendingAttachments.map(file => file.id),
    projectId: state.project?.id || null,
    mode: state.mode,
    regenerate,
    settings: {
      baseUrl: state.config.baseUrl,
      model: state.config.model,
      visionModel: state.config.visionModel || null,
      temperature: state.config.temperature,
      maxTokens: state.config.maxTokens,
      contextChars: 0,
      contextWindowTokens: state.config.contextWindowTokens,
      autoCompact: state.config.autoCompact,
      compactionKeepTokens: state.config.compactionKeepTokens,
      compactionBufferTokens: state.config.compactionBufferTokens,
      oldToolOutputChars: state.config.oldToolOutputChars,
      systemPrompt: state.config.systemPrompt,
      useFileContext: state.config.useFileContext,
      agentMaxSteps: 0,
      agentAllowCommands: state.config.agentAllowCommands,
      agentEditPermission: state.config.agentEditPermission,
      agentShellPermission: state.config.agentShellPermission,
      agentReviewPermission: state.config.agentReviewPermission,
      agentMcpPermission: state.config.agentMcpPermission,
      agentTaskPermission: state.config.agentTaskPermission,
      agentLspPermission: state.config.agentLspPermission,
      agentParallelReadTools: state.config.agentParallelReadTools,
      agentAutoApprove: state.config.agentAutoApprove,
      agentExtraCommands: state.config.agentExtraCommands || ''
    }
  };

  state.abortController = new AbortController();
  state.activeAgentRunId = null;
  try {
    const response = await fetch('/api/chat/stream', {
      method: 'POST',
      signal: state.abortController.signal,
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${state.config.apiKey}`
      },
      body: JSON.stringify(payload)
    });

    if (!response.ok) throw new Error(await readHttpError(response));

    await consumeSse(response, (event, rawData) => {
      if (event === 'meta') {
        try {
          const meta = JSON.parse(rawData);
          state.conversationId = meta.conversationId || state.conversationId;
          if (meta.agentRunId) {
            state.activeAgentRunId = meta.agentRunId;
            assistant.agentRunId = meta.agentRunId;
            assistant.agentProgress = { percent: 2, phase: 'starting', detail: 'Preparing agent run', tokenUsage: {} };
            startAgentWatch(meta.agentRunId, assistant, assistantIndex);
            renderMessages();
          }
          if (meta.projectId && (!state.project || state.project.id !== meta.projectId)) {
            api(`/api/projects/${encodeURIComponent(meta.projectId)}`).then(project => {
              state.project = project;
              state.projectRootHandle = null;
              state.projectFallbackFiles = null;
              renderProjectBar();
              updateModeUi();
              if (meta.autoResolvedWorkspace) toast(`Workspace resolved from prompt: ${project.localPath || project.name}`, 4500);
            }).catch(() => {});
          }
          for (let i = state.messages.length - 1; i >= 0; i--) {
            if (state.messages[i].role === 'user' && !state.messages[i].id) {
              state.messages[i].id = meta.userMessageId;
              break;
            }
          }
        } catch (_) { /* ignore */ }
        return;
      }

      if (event === 'agent_step') {
        try {
          const step = JSON.parse(rawData);
          if (step.runId) { state.activeAgentRunId = step.runId; assistant.agentRunId = step.runId; }
          if (!Array.isArray(assistant.agentSteps)) assistant.agentSteps = [];
          const previous = assistant.agentSteps[assistant.agentSteps.length - 1];
          if (previous && previous.step === step.step && previous.tool === step.tool && previous.status === 'running') {
            assistant.agentSteps[assistant.agentSteps.length - 1] = step;
          } else {
            assistant.agentSteps.push(step);
          }
          renderMessages();
          if (!state.userScrolledUp) scrollBottom(false);
        } catch (_) { /* ignore malformed agent progress */ }
        return;
      }

      if (event === 'agent_changes' || event === 'agent_patch') {
        try {
          const patch = JSON.parse(rawData);
          assistant.agentDirectChangeCount = Number(patch.count || 0);
        } catch (_) { /* ignore */ }
        return;
      }

      if (event === 'token') {
        let token = rawData;
        try {
          const parsed = JSON.parse(rawData);
          if (parsed && typeof parsed.text === 'string') token = parsed.text;
        } catch (_) { /* backward compatibility with raw token SSE */ }
        assistant.content += token;
        scheduleStreamingRender(assistantIndex);
        return;
      }

      if (event === 'done') {
        assistant.serverDone = true;
        stopAgentWatch();
        try {
          const saved = JSON.parse(rawData);
          const steps = assistant.agentSteps;
          const directChangeCount = assistant.agentDirectChangeCount;
          Object.assign(assistant, saved, { streaming: false, agentSteps: steps, agentDirectChangeCount: directChangeCount, mode: assistant.mode });
        } catch (_) {
          assistant.streaming = false;
        }
        return;
      }

      if (event === 'error') {
        let message = rawData;
        try { message = JSON.parse(rawData).message || message; } catch (_) { /* ignore */ }
        throw new Error(message);
      }
    });

    assistant.streaming = false;
    renderMessages();
    await loadConversations();
    const conversation = state.conversations.find(c => c.id === state.conversationId);
    if (conversation) $('conversationTitle').textContent = conversation.title;
    if (!regenerate && wantsExcel(text) && assistant.content && !assistant.content.includes('**Error:**')) {
      try { await downloadAssistantExcel(assistantIndex, true); }
      catch (artifactError) { toast(`Excel export failed: ${artifactError.message}`, 5000); }
    }
    const sentImage = pendingAttachments.some(file => String(file.mimeType || '').startsWith('image/'));
    if (!regenerate && sentImage && !state.config.visionModel && /(?:not (?:seeing|see)|no (?:image|file).{0,30}(?:attached|provided)|cannot (?:see|view))/i.test(assistant.content || '')) {
      toast('The main model did not process the image. Set a vision-capable model in Settings → Vision model.', 6500);
    }
  } catch (error) {
    assistant.streaming = false;
    if (error.name === 'AbortError') {
      if (state.agentWatchdogCompleted) {
        try { await loadConversations(); } catch (_) { /* durable answer is already shown */ }
      } else {
        if (!assistant.content.trim()) assistant.content = 'Generation stopped.';
        else assistant.content += '\n\n*Generation stopped.*';
      }
    } else {
      assistant.content += `${assistant.content ? '\n\n' : ''}**Error:** ${error.message}`;
    }
    renderMessages();
  } finally {
    stopAgentWatch();
    setStreaming(false);
    state.abortController = null;
    state.activeAgentRunId = null;
    if (state.renderTimer) { clearTimeout(state.renderTimer); state.renderTimer = null; }
    scrollBottom(true);
  }
}

async function readHttpError(response) {
  let message = `HTTP ${response.status}`;
  try {
    const contentType = response.headers.get('content-type') || '';
    if (contentType.includes('application/json')) {
      const body = await response.json();
      return body.message || body.error || message;
    }
    const text = await response.text();
    if (text.trim()) return text.trim().slice(0, 1200);
  } catch (_) { /* ignore */ }
  return message;
}

async function consumeSse(response, onEvent) {
  if (!response.body) throw new Error('Streaming response body is unavailable');
  const reader = response.body.getReader();
  const decoder = new TextDecoder('utf-8');
  let buffer = '';
  let eventName = 'message';
  let dataLines = [];

  const dispatch = () => {
    if (!dataLines.length) {
      eventName = 'message';
      return;
    }
    const data = dataLines.join('\n');
    dataLines = [];
    const currentEvent = eventName;
    eventName = 'message';
    onEvent(currentEvent, data);
  };

  while (true) {
    const { value, done } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });

    let newline;
    while ((newline = buffer.indexOf('\n')) >= 0) {
      let line = buffer.slice(0, newline);
      buffer = buffer.slice(newline + 1);
      if (line.endsWith('\r')) line = line.slice(0, -1);

      if (line === '') {
        dispatch();
        continue;
      }
      if (line.startsWith(':')) continue;
      if (line.startsWith('event:')) {
        eventName = line.slice(6).trim();
        continue;
      }
      if (line.startsWith('data:')) {
        let valuePart = line.slice(5);
        // SSE allows one optional transport separator space. Remove only that one space,
        // never trimStart(), because model tokens may intentionally start with whitespace.
        if (valuePart.startsWith(' ')) valuePart = valuePart.slice(1);
        dataLines.push(valuePart);
      }
    }
  }

  buffer += decoder.decode();
  if (buffer) {
    let line = buffer.endsWith('\r') ? buffer.slice(0, -1) : buffer;
    if (line.startsWith('data:')) {
      line = line.slice(5);
      if (line.startsWith(' ')) line = line.slice(1);
      dataLines.push(line);
    }
  }
  dispatch();
}

async function uploadFiles(fileList) {
  const files = Array.from(fileList || []).filter(Boolean);
  if (!files.length) return;
  await ensureConversation();

  for (const file of files) {
    const tempId = `upload-${crypto.randomUUID ? crypto.randomUUID() : Date.now()}`;
    const previewUrl = String(file.type || '').startsWith('image/') ? URL.createObjectURL(file) : null;
    state.attachments.push({ id: tempId, name: file.name, size: file.size, mimeType: file.type, uploading: true, previewUrl });
    state.uploadingCount++;
    renderAttachmentTray();

    const form = new FormData();
    form.append('conversationId', state.conversationId);
    form.append('file', file);

    try {
      const uploaded = await api('/api/files', { method: 'POST', body: form });
      const index = state.attachments.findIndex(item => item.id === tempId);
      if (index >= 0) state.attachments[index] = { ...uploaded, previewUrl };
      state.filesById.set(uploaded.id, uploaded);
      if (String(uploaded.mimeType || '').startsWith('image/') && !state.config.visionModel) {
        toast('Image uploaded. If your main model is text-only, configure a Vision model in Settings.', 5000);
      } else if (!String(uploaded.mimeType || '').startsWith('image/')) {
        const chars = Number(uploaded.extractedCharacters || 0);
        const status = String(uploaded.extractionStatus || 'unknown');
        const extractionMessage = String(uploaded.extractionMessage || 'No readable text was extracted');
        if (chars > 0) toast(`${uploaded.name} ready · ${formatCompact(chars)} text chars extracted`, 4200);
        else toast(`${uploaded.name} uploaded, but document reading is ${status}: ${extractionMessage}`, 8000);
      }
      renderAttachmentTray();
    } catch (error) {
      state.attachments = state.attachments.filter(item => item.id !== tempId);
      if (previewUrl) URL.revokeObjectURL(previewUrl);
      renderAttachmentTray();
      toast(`Upload failed: ${error.message}`, 4000);
    } finally {
      state.uploadingCount = Math.max(0, state.uploadingCount - 1);
    }
  }
}

function renderAttachmentTray() {
  const hasImage = state.attachments.some(file => String(file.mimeType || '').startsWith('image/'));
  const chips = state.attachments.map(file => {
    const image = String(file.mimeType || '').startsWith('image/');
    const preview = image ? (file.previewUrl || (!file.uploading ? `/api/files/${encodeURIComponent(file.id)}/view` : '')) : '';
    const visual = preview ? `<img class="attachment-thumb" src="${preview}" alt="${esc(file.name)}" />` : `<span>${fileIcon(file.mimeType, file.name)}</span>`;
    return `<div class="attachment-chip ${image ? 'image-chip' : ''}" title="${esc(file.name)}">
      ${visual}
      <span class="chip-name">${esc(file.name)}</span>
      ${file.uploading ? '<span class="chip-status">Uploading…</span>' : ''}
      <button class="chip-remove" type="button" data-remove-file="${esc(file.id)}" ${file.uploading ? 'disabled' : ''} aria-label="Remove attachment">×</button>
    </div>`;
  }).join('');
  const note = hasImage && !state.config.visionModel
    ? '<div class="image-capability-note">Images are uploaded correctly. They require either a vision-capable main model or an optional Vision model in Settings.</div>'
    : '';
  $('attachmentTray').innerHTML = chips + note;
}

function openSettings() {
  syncSettingsUi();
  $('modalBackdrop').classList.remove('hidden');
  setTimeout(() => $('apiKey').focus(), 0);
}

function closeSettings() { $('modalBackdrop').classList.add('hidden'); }

function togglePassword(inputId, buttonId) {
  const input = $(inputId);
  const button = $(buttonId);
  const show = input.type === 'password';
  input.type = show ? 'text' : 'password';
  button.textContent = show ? 'Hide' : 'Show';
}

function autoGrow() {
  const input = $('messageInput');
  input.style.height = 'auto';
  input.style.height = `${Math.min(input.scrollHeight, 180)}px`;
}

async function copyText(text) {
  try {
    await navigator.clipboard.writeText(String(text || ''));
  } catch (_) {
    const area = document.createElement('textarea');
    area.value = String(text || '');
    area.style.position = 'fixed';
    area.style.opacity = '0';
    document.body.appendChild(area);
    area.select();
    document.execCommand('copy');
    area.remove();
  }
}

function downloadText(name, text, type = 'text/plain;charset=utf-8') {
  const blob = new Blob([String(text || '')], { type });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = name;
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1500);
}


function wantsExcel(text) {
  return /\b(excel|xlsx|spreadsheet)\b/i.test(String(text || ''));
}

function isKnownTextOnlyMainModel(model) {
  return /^gpt-oss(?:-|$)/i.test(String(model || '').trim());
}

function previousUserMessage(index) {
  for (let i = Number(index) - 1; i >= 0; i--) {
    if (state.messages[i]?.role === 'user') return state.messages[i];
  }
  return null;
}

function isExcelRequestedForAssistant(index) {
  return wantsExcel(previousUserMessage(index)?.content || '');
}

function hasMarkdownTable(text) {
  return /^\s*\|?.+\|.+\s*\n\s*\|?\s*:?-{3,}:?\s*(\|\s*:?-{3,}:?\s*)+/m.test(String(text || ''));
}

function filenameFromDisposition(response, fallback) {
  const value = response.headers.get('content-disposition') || '';
  const match = value.match(/filename="?([^";]+)"?/i);
  return match?.[1] || fallback;
}

async function downloadAssistantExcel(index, automatic = false) {
  const message = state.messages[Number(index)];
  if (!message?.content) return;
  const title = `${$('conversationTitle').textContent || 'assistant-export'}-export`;
  const response = await fetch('/api/artifacts/excel', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ title, markdown: message.content })
  });
  if (!response.ok) throw new Error(await readHttpError(response));
  const blob = await response.blob();
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = filenameFromDisposition(response, 'assistant-export.xlsx');
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1800);
  toast(automatic ? 'Excel file downloaded' : 'Excel downloaded');
}

function stripProjectMarkers(text) {
  return String(text || '')
    .replace(/<!--\s*PROJECT_FILE_START:[^>]+-->[\s\S]*?<!--\s*PROJECT_FILE_END\s*-->/gi, '')
    .trim();
}

function extractProjectFileChanges(text) {
  const source = String(text || '');
  const changes = [];
  const marker = /<!--\s*PROJECT_FILE_START:([^\n>]+?)\s*-->([\s\S]*?)<!--\s*PROJECT_FILE_END\s*-->/gi;
  let match;
  while ((match = marker.exec(source)) !== null) {
    const rawMeta = match[1].trim();
    let path = '';
    let baselineHash = '';
    let operation = 'write';

    // Newer structured start-marker format, retained for compatibility.
    if (rawMeta.startsWith('{')) {
      try {
        const meta = JSON.parse(rawMeta);
        path = String(meta.path || '').trim().replace(/\\/g, '/');
        baselineHash = String(meta.baselineHash || '');
        operation = String(meta.operation || 'write').toLowerCase() === 'delete' ? 'delete' : 'write';
      } catch (_) { /* fall back to legacy path marker */ }
    }
    if (!path) path = rawMeta.replace(/^['"]|['"]$/g, '').replace(/\\/g, '/');

    let body = match[2].trim();
    // Agent metadata is a separate hidden comment so legacy Chat-mode patches still work.
    const metaMatch = body.match(/<!--\s*PROJECT_FILE_META:([^>]+?)\s*-->/i);
    if (metaMatch) {
      for (const token of metaMatch[1].split(';')) {
        const eq = token.indexOf('=');
        if (eq < 0) continue;
        const key = token.slice(0, eq).trim();
        const value = token.slice(eq + 1).trim();
        if (key === 'baselineHash') baselineHash = value;
        if (key === 'operation') operation = value.toLowerCase() === 'delete' ? 'delete' : 'write';
      }
      body = body.replace(metaMatch[0], '').trim();
    }

    const fence = body.match(/^```[^\n]*\n([\s\S]*?)\n```\s*$/);
    const content = operation === 'delete' ? null : (fence ? fence[1] : body);
    if (path) changes.push({ path, content, baselineHash, operation });
  }
  return changes;
}

const ACTIVE_LOCAL_WORKSPACE_KEY = 'llm.activeLocalWorkspaceId';

function rememberActiveLocalWorkspace(project) {
  if (!project?.localWorkspace || !project.id) return;
  localStorage.setItem(ACTIVE_LOCAL_WORKSPACE_KEY, project.id);
  if (project.localPath) localStorage.setItem('llm.activeLocalWorkspacePath', project.localPath);
  if (project.name) localStorage.setItem('llm.activeLocalWorkspaceName', project.name);
}

function forgetActiveLocalWorkspace() {
  localStorage.removeItem(ACTIVE_LOCAL_WORKSPACE_KEY);
  localStorage.removeItem('llm.activeLocalWorkspacePath');
  localStorage.removeItem('llm.activeLocalWorkspaceName');
}

async function restoreActiveLocalWorkspace() {
  const id = localStorage.getItem(ACTIVE_LOCAL_WORKSPACE_KEY);
  if (!id) return null;
  try {
    const project = await api(`/api/projects/${encodeURIComponent(id)}`);
    if (!project?.localWorkspace) {
      forgetActiveLocalWorkspace();
      return null;
    }
    state.project = project;
    state.projectRootHandle = null;
    state.projectFallbackFiles = null;
    renderProjectBar();
    return project;
  } catch (_) {
    forgetActiveLocalWorkspace();
    return null;
  }
}

function renderProjectBar() {
  const bar = $('projectBar');
  if (!state.project) {
    bar.classList.add('hidden');
    updateModeUi();
    return;
  }
  bar.classList.remove('hidden');
  $('projectName').textContent = state.project.name || 'Project';
  const files = Number(state.project.fileCount || 0);
  const chars = Number(state.project.indexedCharacters || 0);
  const access = state.project.localWorkspace ? ' · local workspace · writable' : ' · indexed reference';
  $('projectStats').textContent = `${files} files · ${formatCompact(chars)} indexed chars${access}`;
  updateModeUi();
}

async function rescanProject() {
  if (!state.project?.localWorkspace) {
    return toast('Supply the workspace path in an Agent prompt to activate a live local workspace.', 4500);
  }
  state.project = await api(`/api/projects/${encodeURIComponent(state.project.id)}/rescan-local`, { method: 'POST' });
  renderProjectBar();
  return toast(`Workspace rescanned: ${state.project.fileCount} files`, 3500);
}

function closeProjectWorkspace() {
  if (state.project?.localWorkspace) forgetActiveLocalWorkspace();
  state.project = null;
  state.projectRootHandle = null;
  state.projectFallbackFiles = null;
  renderProjectBar();
  toast('Workspace disconnected. It will no longer be reused automatically.');
}

function openProjectChanges(index) {
  const message = state.messages[Number(index)];
  const changes = extractProjectFileChanges(message?.content || '');
  if (!changes.length) return toast('No structured project file changes found');
  state.pendingProjectChanges = { index: Number(index), changes };
  $('projectChangesSummary').textContent = `${changes.length} file${changes.length === 1 ? '' : 's'} proposed${state.project ? ` for ${state.project.name}` : ''}.`;
  $('projectChangesList').innerHTML = changes.map(change => `<div class="project-change-row"><span class="project-change-path">${change.operation === 'delete' ? '− ' : '+ '}${esc(change.path)}</span><span class="project-change-size">${change.operation === 'delete' ? 'delete' : `${formatCompact((change.content || '').length)} chars`}</span></div>`).join('');
  const canApply = Boolean(state.project?.localWorkspace);
  $('applyProjectChanges').disabled = !canApply;
  $('applyProjectChanges').textContent = canApply ? 'Apply to local workspace' : 'Use an Agent prompt path to activate workspace';
  $('projectChangesBackdrop').classList.remove('hidden');
}

function closeProjectChanges() {
  $('projectChangesBackdrop').classList.add('hidden');
}

async function downloadPendingProjectPatch() {
  const pending = state.pendingProjectChanges;
  if (!pending?.changes?.length) return;
  const response = await fetch('/api/artifacts/project-patch', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ projectName: state.project?.name || 'project', files: pending.changes })
  });
  if (!response.ok) throw new Error(await readHttpError(response));
  const blob = await response.blob();
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filenameFromDisposition(response, 'project-fixes.zip');
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1800);
}

async function applyPendingProjectChanges() {
  const pending = state.pendingProjectChanges;
  if (!pending?.changes?.length) return;
  if (!state.project?.localWorkspace) {
    return toast('No live local workspace is active. Supply its path in an Agent prompt or download the patch.', 5000);
  }
  const result = await api(`/api/projects/${encodeURIComponent(state.project.id)}/apply`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ projectName: state.project.name || 'project', files: pending.changes })
  });
  state.project = await api(`/api/projects/${encodeURIComponent(state.project.id)}`);
  renderProjectBar(); closeProjectChanges();
  const totalApplied = Number(result.applied || 0) + Number(result.deleted || 0);
  toast(`Applied ${totalApplied} change(s); originals backed up`, 5000);
}

function beginEditMessage(index) {
  if (state.streaming) return;
  state.editingIndex = index;
  renderMessages();
}

async function saveEditedMessage(index) {
  const input = $('editMessageInput');
  const edited = String(input?.value || '').trim();
  if (!edited) return toast('Message cannot be empty');
  const original = state.messages[index];
  if (!original?.id) return toast('This message is not saved yet');

  const attachments = (original.attachmentIds || []).map(id => state.filesById.get(id)).filter(Boolean);
  await api(`/api/conversations/${encodeURIComponent(state.conversationId)}/rewind/${original.id}`, { method: 'POST' });
  state.messages = state.messages.slice(0, index);
  state.attachments = attachments;
  state.editingIndex = null;
  await sendMessage({ overrideMessage: edited });
}

function openHistoryMenu(id, anchor) {
  state.historyMenuId = id;
  const menu = $('historyMenu');
  const rect = anchor.getBoundingClientRect();
  menu.style.left = `${Math.min(rect.left, window.innerWidth - 145)}px`;
  menu.style.top = `${Math.min(rect.bottom + 4, window.innerHeight - 100)}px`;
  menu.classList.remove('hidden');
}

function closeHistoryMenu() {
  state.historyMenuId = null;
  $('historyMenu').classList.add('hidden');
}

function openRename(id) {
  const conversation = state.conversations.find(c => c.id === id);
  if (!conversation) return;
  state.renameId = id;
  $('renameInput').value = conversation.title || '';
  $('renameBackdrop').classList.remove('hidden');
  setTimeout(() => { $('renameInput').focus(); $('renameInput').select(); }, 0);
}

function closeRename() {
  state.renameId = null;
  $('renameBackdrop').classList.add('hidden');
}

async function saveRename() {
  if (!state.renameId) return;
  const title = $('renameInput').value.trim();
  if (!title) return toast('Enter a title');
  const id = state.renameId;
  await api(`/api/conversations/${encodeURIComponent(id)}`, {
    method: 'PATCH',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ title })
  });
  closeRename();
  await loadConversations();
  if (state.conversationId === id) $('conversationTitle').textContent = title;
}

async function deleteConversation(id) {
  const conversation = state.conversations.find(c => c.id === id);
  if (!confirm(`Delete “${conversation?.title || 'this chat'}”?`)) return;
  await api(`/api/conversations/${encodeURIComponent(id)}`, { method: 'DELETE' });
  if (state.conversationId === id) newChat();
  await loadConversations();
}

function closeMenus() {
  closeHistoryMenu();
  $('exportMenu').classList.add('hidden');
}

// ---- Event wiring ----
$('brandBtn').onclick = newChat;
$('newChatBtn').onclick = newChat;
$('sendBtn').onclick = () => sendMessage();
$('stopBtn').onclick = () => stopCurrentRun();
$('attachBtn').onclick = () => $('fileInput').click();
document.querySelectorAll('[data-mode]').forEach(button => {
  button.addEventListener('click', () => { setMode(button.dataset.mode); updateWelcomeMode(); });
});
$('projectRefreshBtn').onclick = () => rescanProject().catch(error => toast(error.message, 5000));
$('projectCloseBtn').onclick = closeProjectWorkspace;
$('fileInput').onchange = event => { uploadFiles(event.target.files); event.target.value = ''; };
$('messageInput').addEventListener('input', autoGrow);
$('messageInput').addEventListener('keydown', event => {
  if (event.key === 'Enter' && !event.shiftKey && !event.isComposing) {
    event.preventDefault();
    sendMessage();
  }
});
$('messageInput').addEventListener('paste', event => {
  const files = Array.from(event.clipboardData?.files || []);
  if (files.length) uploadFiles(files);
});
$('historySearch').addEventListener('input', event => renderHistory(event.target.value));
$('settingsBtn').onclick = openSettings;
$('topSettingsBtn').onclick = openSettings;
$('closeSettings').onclick = closeSettings;
$('cancelSettings').onclick = closeSettings;
$('modalBackdrop').addEventListener('click', event => { if (event.target === $('modalBackdrop')) closeSettings(); });
$('toggleKey').onclick = () => togglePassword('apiKey', 'toggleKey');
$('homeToggleKey').onclick = () => togglePassword('homeApiKey', 'homeToggleKey');
$('openSidebar').onclick = () => $('sidebar').classList.add('open');
$('closeSidebar').onclick = () => $('sidebar').classList.remove('open');
$('scrollBottomBtn').onclick = () => scrollBottom(true);

$('themeBtn').onclick = () => {
  const current = document.documentElement.dataset.theme || 'light';
  const next = current === 'dark' ? 'light' : 'dark';
  document.documentElement.dataset.theme = next;
  localStorage.setItem('theme', next);
};

$('exportBtn').onclick = event => {
  event.stopPropagation();
  if (!state.conversationId) return toast('No chat to export');
  $('exportMenu').classList.toggle('hidden');
};
$('exportMenu').addEventListener('click', event => {
  const button = event.target.closest('[data-export-format]');
  if (!button || !state.conversationId) return;
  const format = button.dataset.exportFormat;
  $('exportMenu').classList.add('hidden');
  window.location.href = `/api/conversations/${encodeURIComponent(state.conversationId)}/export?format=${encodeURIComponent(format)}`;
});

$('homeSave').onclick = () => {
  state.config.apiKey = $('homeApiKey').value.trim();
  state.config.baseUrl = $('homeBaseUrl').value.trim();
  state.config.model = $('homeModel').value.trim();
  state.config.visionModel = $('homeVisionModel').value.trim();
  state.config.rememberKey = $('homeRemember').checked;
  if (!state.config.apiKey || !state.config.baseUrl || !state.config.model) return toast('Enter API key, base URL and model');
  saveConfig();
  syncSettingsUi();
  $('messageInput').focus();
  toast('Model configuration saved');
};

$('saveSettings').onclick = () => {
  state.config.apiKey = $('apiKey').value.trim();
  state.config.baseUrl = $('baseUrl').value.trim();
  state.config.model = $('modelName').value.trim();
  state.config.visionModel = $('visionModel').value.trim();
  state.config.temperature = Math.max(0, Math.min(2, Number($('temperature').value || 0.7)));
  state.config.maxTokens = Math.max(0, Number($('maxTokens').value || 0));
  state.config.contextWindowTokens = Math.max(0, Number($('contextWindowTokens').value || 0));
  state.config.autoCompact = $('autoCompact').checked;
  state.config.compactionKeepTokens = Math.max(2000, Number($('compactionKeepTokens').value || 8000));
  state.config.compactionBufferTokens = Math.max(4000, Number($('compactionBufferTokens').value || 20000));
  state.config.oldToolOutputChars = Math.max(400, Number($('oldToolOutputChars').value || 2000));
  state.config.systemPrompt = $('systemPrompt').value;
  state.config.useFileContext = $('useFileContext').checked;
  state.config.agentAllowCommands = $('agentAllowCommands').checked;
  state.config.agentEditPermission = $('agentEditPermission').value;
  state.config.agentShellPermission = $('agentShellPermission').value;
  state.config.agentReviewPermission = $('agentReviewPermission').value;
  state.config.agentMcpPermission = $('agentMcpPermission').value;
  state.config.agentTaskPermission = $('agentTaskPermission').value;
  state.config.agentLspPermission = $('agentLspPermission').value;
  state.config.agentParallelReadTools = $('agentParallelReadTools').checked;
  state.config.agentAutoApprove = $('agentAutoApprove').checked;
  state.config.agentExtraCommands = $('agentExtraCommands').value.trim();
  state.config.rememberKey = $('rememberKey').checked;
  if (!state.config.apiKey || !state.config.baseUrl || !state.config.model) return toast('API key, base URL and model are required');
  saveConfig();
  syncSettingsUi();
  closeSettings();
  updateContextBadge();
  toast('Settings saved');
};

$('clearKey').onclick = () => {
  state.config.apiKey = '';
  state.config.rememberKey = false;
  sessionStorage.removeItem('llm.apiKey');
  localStorage.removeItem('llm.apiKey');
  $('apiKey').value = '';
  $('homeApiKey').value = '';
  $('rememberKey').checked = false;
  $('homeRemember').checked = false;
  updateWelcomeMode();
  toast('API key cleared');
};

$('historyList').addEventListener('click', event => {
  const menuButton = event.target.closest('[data-menu]');
  if (menuButton) {
    event.stopPropagation();
    openHistoryMenu(menuButton.dataset.menu, menuButton);
    return;
  }
  const item = event.target.closest('.history-item');
  if (item) openConversation(item.dataset.id).catch(error => toast(error.message, 4000));
});

$('historyMenu').addEventListener('click', event => {
  const button = event.target.closest('[data-history-action]');
  if (!button || !state.historyMenuId) return;
  const id = state.historyMenuId;
  const action = button.dataset.historyAction;
  closeHistoryMenu();
  if (action === 'rename') openRename(id);
  if (action === 'delete') deleteConversation(id).catch(error => toast(error.message, 4000));
});

$('closeRename').onclick = closeRename;
$('cancelRename').onclick = closeRename;
$('saveRename').onclick = () => saveRename().catch(error => toast(error.message, 4000));
$('renameBackdrop').addEventListener('click', event => { if (event.target === $('renameBackdrop')) closeRename(); });
$('renameInput').addEventListener('keydown', event => { if (event.key === 'Enter') saveRename().catch(error => toast(error.message, 4000)); });
$('closeProjectChanges').onclick = closeProjectChanges;
$('cancelProjectChanges').onclick = closeProjectChanges;
$('downloadProjectPatch').onclick = () => downloadPendingProjectPatch().catch(error => toast(error.message, 5000));
$('applyProjectChanges').onclick = () => applyPendingProjectChanges().catch(error => toast(error.message, 5000));
$('projectChangesBackdrop').addEventListener('click', event => { if (event.target === $('projectChangesBackdrop')) closeProjectChanges(); });

$('attachmentTray').addEventListener('click', event => {
  const button = event.target.closest('[data-remove-file]');
  if (!button || button.disabled) return;
  state.attachments = state.attachments.filter(file => file.id !== button.dataset.removeFile);
  renderAttachmentTray();
});

$('messages').addEventListener('click', async event => {
  let button = event.target.closest('[data-agent-approval]');
  if (button) {
    const approvalId = button.dataset.agentApproval;
    const action = String(button.dataset.approvalAction || 'deny').toLowerCase();
    button.closest('.agent-approval-actions')?.querySelectorAll('button').forEach(b => b.disabled = true);
    try {
      await api(`/api/agent/approvals/${encodeURIComponent(approvalId)}`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action })
      });
      for (const message of state.messages) {
        for (const step of (message.agentSteps || [])) {
          if (step.approvalId === approvalId && step.status === 'approval') {
            step.status = action === 'deny' ? 'error' : 'running';
            step.detail = action === 'run' ? 'Allowed for this run — executing tool' : action === 'once' ? 'Approved once — executing tool' : 'Denied';
          }
        }
      }
      renderMessages();
    } catch (error) { toast(`Approval failed: ${error.message}`, 4500); }
    return;
  }

  button = event.target.closest('[data-code-action]');
  if (button) {
    const block = button.closest('.code-block');
    const code = block?.querySelector('code')?.textContent || '';
    const action = button.dataset.codeAction;
    if (action === 'copy') {
      await copyText(code);
      const label = button.querySelector('span');
      const old = label?.textContent;
      if (label) label.textContent = 'Copied';
      setTimeout(() => { if (label) label.textContent = old || 'Copy'; }, 1200);
      return;
    }
    if (action === 'download') {
      const ext = block?.dataset.ext || 'txt';
      const fileName = ext === 'Dockerfile' ? 'Dockerfile' : `code.${ext}`;
      downloadText(fileName, code);
      return;
    }
    if (action === 'wrap') {
      block?.classList.toggle('wrap-code');
      return;
    }
  }

  button = event.target.closest('[data-copy-msg]');
  if (button) {
    await copyText(stripProjectMarkers(state.messages[Number(button.dataset.copyMsg)]?.content || ''));
    toast('Copied');
    return;
  }

  button = event.target.closest('[data-download-msg]');
  if (button) {
    const index = Number(button.dataset.downloadMsg);
    downloadText(`assistant-${index + 1}.md`, stripProjectMarkers(state.messages[index]?.content || ''), 'text/markdown;charset=utf-8');
    return;
  }

  button = event.target.closest('[data-excel-msg]');
  if (button) {
    await downloadAssistantExcel(Number(button.dataset.excelMsg));
    return;
  }

  button = event.target.closest('[data-project-changes]');
  if (button) {
    openProjectChanges(Number(button.dataset.projectChanges));
    return;
  }

  button = event.target.closest('[data-regenerate]');
  if (button) {
    if (state.messages[state.messages.length - 1]?.role === 'assistant') state.messages.pop();
    await sendMessage({ regenerate: true });
    return;
  }

  button = event.target.closest('[data-edit-msg]');
  if (button) {
    beginEditMessage(Number(button.dataset.editMsg));
    return;
  }

  button = event.target.closest('[data-edit-cancel]');
  if (button) {
    state.editingIndex = null;
    renderMessages();
    return;
  }

  button = event.target.closest('[data-edit-save]');
  if (button) {
    await saveEditedMessage(Number(button.dataset.editSave));
  }
});

$('chatView').addEventListener('scroll', () => {
  state.userScrolledUp = !nearBottom();
  updateScrollButton();
});

document.addEventListener('click', event => {
  const starter = event.target.closest('[data-starter-prompt]');
  if (starter) {
    const mode = starter.dataset.starterMode || 'chat';
    setMode(mode);
    $('messageInput').value = starter.dataset.starterPrompt || '';
    autoGrow();
    $('messageInput').focus();
    return;
  }
  if (!event.target.closest('#historyMenu') && !event.target.closest('[data-menu]')) closeHistoryMenu();
  if (!event.target.closest('#exportMenu') && !event.target.closest('#exportBtn')) $('exportMenu').classList.add('hidden');
});

document.addEventListener('keydown', event => {
  const modifier = event.ctrlKey || event.metaKey;
  if (modifier && event.key.toLowerCase() === 'k') {
    event.preventDefault();
    $('historySearch').focus();
  }
  if (modifier && event.shiftKey && event.key.toLowerCase() === 'o') {
    event.preventDefault();
    newChat();
  }
  if (event.key === 'Escape') {
    closeMenus();
    if (!$('modalBackdrop').classList.contains('hidden')) closeSettings();
    if (!$('renameBackdrop').classList.contains('hidden')) closeRename();
    if (!$('projectChangesBackdrop').classList.contains('hidden')) closeProjectChanges();
  }
});

let dragDepth = 0;
document.addEventListener('dragenter', event => {
  if (!event.dataTransfer?.types?.includes('Files')) return;
  dragDepth++;
  $('dropOverlay').classList.remove('hidden');
});
document.addEventListener('dragleave', event => {
  if (!event.dataTransfer?.types?.includes('Files')) return;
  dragDepth = Math.max(0, dragDepth - 1);
  if (dragDepth === 0) $('dropOverlay').classList.add('hidden');
});
document.addEventListener('dragover', event => {
  if (event.dataTransfer?.types?.includes('Files')) event.preventDefault();
});
document.addEventListener('drop', event => {
  if (!event.dataTransfer?.files?.length) return;
  event.preventDefault();
  dragDepth = 0;
  $('dropOverlay').classList.add('hidden');
  uploadFiles(event.dataTransfer.files).catch(error => toast(error.message, 4000));
});

(function init() {
  const storedTheme = localStorage.getItem('theme');
  if (storedTheme === 'dark' || storedTheme === 'light') {
    document.documentElement.dataset.theme = storedTheme;
  } else if (window.matchMedia?.('(prefers-color-scheme: dark)').matches) {
    document.documentElement.dataset.theme = 'dark';
  } else {
    document.documentElement.dataset.theme = 'light';
  }

  syncSettingsUi();
  updateModelBadge();
  updateModeUi();
  updateWelcomeMode();
  renderMessages();
  renderAttachmentTray();
  renderProjectBar();
  autoGrow();
  restoreActiveLocalWorkspace().catch(() => {});
  loadConversations().catch(error => toast(error.message, 4000));
})();
