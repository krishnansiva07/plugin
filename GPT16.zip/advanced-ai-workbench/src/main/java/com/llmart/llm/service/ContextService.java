package com.llmart.llm.service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.llmart.llm.dto.ChatMode;
import com.llmart.llm.dto.ChatSettings;
import com.llmart.llm.entity.FileEntity;
import com.llmart.llm.entity.MessageEntity;
import org.springframework.stereotype.Service;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;

@Service
public class ContextService {

    private static final String DEFAULT_SYSTEM_PROMPT = """
            You are a high-quality general-purpose AI assistant inside a ChatGPT-style application.
            Answer the user's request directly and use clean GitHub-flavored Markdown when formatting helps.

            Formatting rules:
            - Format for a polished chat UI: use short readable paragraphs, clear headings only when they add structure, bullets for grouped points, numbered steps for procedures, and Markdown tables only for real comparisons.
            - Keep one blank line between sections. Avoid walls of text, excessive headings, decorative separators, and repeated conclusions.
            - For notes, tips, important information or warnings, you may use GitHub-style callouts such as > [!NOTE], > [!TIP], > [!IMPORTANT] or > [!WARNING].
            - When you output code, ALWAYS put it in a fenced code block using triple backticks and a language identifier such as java, javascript, python, json, xml, html, css, sql, bash or yaml.
            - Preserve code indentation and line breaks exactly.
            - Code inside a fenced block must contain only the code/content itself. Do not insert a filename, explanation or decorative text inside the code block unless the user explicitly asks for it.
            - If a filename is useful, write it as normal prose immediately above the code block.
            - For multiple files, use a short heading or filename before each separate fenced code block.
            - Do not escape normal code characters into HTML entities in the answer.
            - If the user asks for a complete file, provide a complete internally consistent file rather than disconnected fragments.
            - If uploaded file excerpts are supplied, use them only when relevant and do not invent unseen file content.

            Downloadable table / Excel rules:
            - When the user asks for Excel, XLSX, or spreadsheet output, make the visible answer a clean Markdown table because the application can convert Markdown tables to a real .xlsx file automatically.
            - Use the user's requested columns or infer concise, useful columns from the task.
            - Use <br> inside a table cell when multi-line content is required. Do not claim that a downloadable file exists unless the application actually creates it.

            Project context rules:
            - Project context may contain a file tree and source/configuration files from an active local project workspace.
            - Use exact project paths when referring to files.
            - Never invent an unseen project file or unseen implementation detail.
            """;

    private final ConversationService conversations;
    private final FileService files;
    private final FileContextSelector fileContextSelector;
    private final ProjectContextService projectContextSelector;
    private final ImageUnderstandingService imageUnderstanding;
    private final ObjectMapper objectMapper;

    public ContextService(ConversationService conversations, FileService files,
                          FileContextSelector fileContextSelector, ProjectContextService projectContextSelector,
                          ImageUnderstandingService imageUnderstanding, ObjectMapper objectMapper) {
        this.conversations = conversations;
        this.files = files;
        this.fileContextSelector = fileContextSelector;
        this.projectContextSelector = projectContextSelector;
        this.imageUnderstanding = imageUnderstanding;
        this.objectMapper = objectMapper;
    }

    public List<Map<String, Object>> build(String conversationId, MessageEntity currentUser, ChatSettings settings,
                                           String projectId, String apiKey, ChatMode mode) throws Exception {
        List<MessageEntity> history = conversations.messageEntities(conversationId);
        List<Map<String, Object>> result = new ArrayList<>();

        String customSystem = settings.systemPrompt();
        String system = DEFAULT_SYSTEM_PROMPT + "\n\n" + modeInstructions(mode);
        if (customSystem != null && !customSystem.isBlank()) {
            system = system + "\n\nAdditional user-configured instructions:\n" + customSystem.strip();
        }
        result.add(Map.of("role", "system", "content", system));

        int configuredBudget = settings.safeContextChars();
        int outputReserveTokens = settings.safeMaxTokens() > 0 ? settings.safeMaxTokens() : 16_000;
        int reserveTokens = Math.max(outputReserveTokens, settings.safeCompactionBufferTokens());
        long tokenManagedChars = (long) Math.max(8_000, settings.safeContextWindowTokens() - reserveTokens) * 4L;
        int inferredBudget = (int) Math.min(Integer.MAX_VALUE / 4L, tokenManagedChars);
        int budget = configuredBudget > 0 ? Math.min(configuredBudget, inferredBudget) : inferredBudget;
        int usable = Math.max(4_000, budget - Math.min(system.length(), budget / 3));
        String currentText = currentUser.getContent() == null ? "" : currentUser.getContent();
        // The current prompt is irreplaceable context, so retain substantially more than ordinary history while
        // still preventing a single pasted payload from consuming the entire provider window.
        currentText = clip(currentText, Math.max(8_000, Math.min(usable / 2, 160_000)));

        // In Agent mode uploaded documents are available through attachment_list/search/read. Inject only a bounded
        // excerpt instead of resending a potentially huge document on every model turn. Chat can preload more.
        int directAttachmentBudget = mode == ChatMode.AGENT
                ? Math.max(8_000, Math.min(24_000, usable / 6))
                : Math.max(8_000, Math.min(180_000, usable * 3 / 5));
        int olderFileBudget = settings.fileContextEnabled() && mode != ChatMode.AGENT
                ? Math.max(0, Math.min(60_000, usable / 5)) : 0;

        // Agent mode reads live project files with tools. Chat can preload mapped project context.
        int projectBudget = (mode == ChatMode.AGENT || projectId == null || projectId.isBlank())
                ? 0
                : Math.max(0, Math.min(100_000, usable / 3));
        String projectContext = projectBudget > 0 ? projectContextSelector.select(projectId, currentText, projectBudget) : "";

        Map<String, Object> currentPayload = currentUserPayload(currentUser, currentText, settings,
                directAttachmentBudget, olderFileBudget, projectContext, apiKey);
        long used = Math.min((long) budget, (long) system.length() + estimatePayloadCharacters(currentPayload));

        // Conversation history is lower priority than the current message and its direct attachments.
        LinkedList<Map<String, Object>> recent = new LinkedList<>();
        for (int i = history.size() - 1; i >= 0; i--) {
            MessageEntity message = history.get(i);
            if (Objects.equals(message.getId(), currentUser.getId())) continue;
            String content = message.getContent() == null ? "" : message.getContent();
            if ("assistant".equalsIgnoreCase(message.getRole())) content = stripProjectPatchPayloads(content);
            long cost = content.length();
            if (used + cost > budget) break;
            recent.addFirst(Map.of("role", message.getRole(), "content", content));
            used += cost;
        }

        result.addAll(recent);
        result.add(currentPayload);
        return result;
    }

    private String modeInstructions(ChatMode mode) {
        return switch (mode == null ? ChatMode.CHAT : mode) {
            case CHAT -> """
                    CURRENT MODE: CHAT
                    - Behave like a normal high-quality ChatGPT-style assistant.
                    - You may use uploaded files and mapped project context as reference material.
                    - Do not claim to have executed commands or changed the user's local project.
                    - If the user asks for project modifications in Chat mode, provide proposed full-file changes using these exact markers so the UI can offer them for review:
                      <!-- PROJECT_FILE_START:relative/path/to/file.ext -->
                      ```language
                      full final file content
                      ```
                      <!-- PROJECT_FILE_END -->
                    """;
            case AGENT -> """
                    CURRENT MODE: AGENT
                    - A separate agent execution protocol will be supplied after this context.
                    - Use the conversation and current-message attachments as evidence, then use live workspace tools instead of pretending to edit or execute.
                    - The selected local project path is the live workspace; Agent mode writes there directly after permission checks.
                    - Do not output PROJECT_FILE markers yourself.
                    """;
        };
    }

    private Map<String, Object> currentUserPayload(MessageEntity message, String currentText,
                                                    ChatSettings settings, int directAttachmentBudget,
                                                    int olderFileBudget, String projectContext,
                                                    String apiKey) throws Exception {
        List<String> attachmentIds = parseIds(message.getAttachmentIdsJson());
        List<FileEntity> attached = files.requireForConversation(message.getConversationId(), attachmentIds);
        List<FileEntity> conversationFiles = files.entitiesForConversation(message.getConversationId());

        StringBuilder text = new StringBuilder(currentText);

        // ALWAYS include non-image files attached to this exact user message. Do not relevance-rank
        // them away: the fact that the user attached the file on this turn is the relevance signal.
        List<FileEntity> directDocuments = attached.stream()
                .filter(f -> f.getMimeType() == null || !f.getMimeType().startsWith("image/"))
                .toList();
        appendDirectDocuments(text, directDocuments, directAttachmentBudget);

        // Older uploads remain optional context controlled by the setting.
        if (settings.fileContextEnabled() && olderFileBudget > 200 && !conversationFiles.isEmpty()) {
            Set<String> currentIds = new HashSet<>();
            attached.forEach(f -> currentIds.add(f.getId()));
            List<FileEntity> older = conversationFiles.stream().filter(f -> !currentIds.contains(f.getId())).toList();
            String selected = fileContextSelector.select(currentText, older, olderFileBudget);
            if (!selected.isBlank()) {
                text.append("\n\nOTHER RELEVANT FILE EXCERPTS FROM EARLIER TURNS:").append(selected);
            }
        }

        if (projectContext != null && !projectContext.isBlank()) text.append(projectContext);

        List<FileEntity> imageFiles = attached.stream()
                .filter(f -> f.getMimeType() != null && f.getMimeType().startsWith("image/"))
                .toList();

        if (!imageFiles.isEmpty() && settings.hasDedicatedVisionModel()) {
            String visionText = imageUnderstanding.describe(apiKey, settings, attached, currentText);
            for (FileEntity image : imageFiles) {
                files.cacheExtractedText(image.getId(), "VISION ANALYSIS FOR " + image.getOriginalName() + ":\n" + visionText);
            }
            text.append("\n\nIMAGE ANALYSIS FROM THE CONFIGURED VISION MODEL:\n").append(visionText);
            return Map.of("role", "user", "content", text.toString());
        }

        List<Map<String, Object>> images = new ArrayList<>();
        for (FileEntity file : imageFiles) {
            if (file.getSizeBytes() > 8_000_000) continue;
            if (images.size() >= 4) break;
            byte[] bytes = Files.readAllBytes(Path.of(file.getStoredPath()));
            String dataUrl = "data:" + file.getMimeType() + ";base64," + Base64.getEncoder().encodeToString(bytes);
            images.add(Map.of("type", "image_url", "image_url", Map.of("url", dataUrl)));
        }

        if (images.isEmpty()) return Map.of("role", "user", "content", text.toString());

        text.append("\n\nThe image attachments in this message are included as multimodal image content. Inspect them directly.");
        List<Map<String, Object>> multi = new ArrayList<>();
        multi.add(Map.of("type", "text", "text", text.toString()));
        multi.addAll(images);
        return Map.of("role", "user", "content", multi);
    }

    private void appendDirectDocuments(StringBuilder text, List<FileEntity> documents, int totalBudget) {
        if (documents == null || documents.isEmpty()) return;
        text.append("\n\nCURRENT-MESSAGE ATTACHMENTS (these files were directly attached by the user and must be considered):");
        int budget = Math.max(2_000, totalBudget);
        int perFile = Math.max(2_000, budget / Math.max(1, documents.size()));
        int used = 0;
        for (FileEntity file : documents) {
            if (used >= budget) break;
            String extracted = file.getExtractedText() == null ? "" : file.getExtractedText();
            String mime = file.getMimeType() == null ? "application/octet-stream" : file.getMimeType();
            text.append("\n\n--- ATTACHED FILE: ").append(file.getOriginalName())
                    .append(" | mime=").append(mime)
                    .append(" | extractedChars=").append(extracted.length()).append(" ---\n");
            if (extracted.isBlank()) {
                text.append("[No textual content could be extracted from this attachment. Do not pretend that its unseen contents were read.]");
                continue;
            }
            int room = Math.min(perFile, budget - used);
            String selected = clipDocument(extracted, room);
            text.append(selected);
            used += selected.length();
        }
    }

    private String clipDocument(String value, int maxChars) {
        if (value == null || value.isBlank()) return "";
        if (value.length() <= maxChars) return value;
        if (maxChars < 1_000) return value.substring(0, Math.max(0, maxChars));
        int head = maxChars * 3 / 4;
        int tail = Math.max(0, maxChars - head - 90);
        return value.substring(0, head) + "\n\n[... middle of attachment omitted to fit context ...]\n\n" +
                value.substring(Math.max(head, value.length() - tail));
    }

    private int estimatePayloadCharacters(Map<String, Object> payload) {
        Object content = payload.get("content");
        if (content instanceof String value) return value.length();
        if (content instanceof List<?> list) {
            int total = 0;
            for (Object item : list) {
                if (item instanceof Map<?, ?> map && "text".equals(map.get("type"))) {
                    Object text = map.get("text");
                    if (text != null) total += String.valueOf(text).length();
                }
            }
            return total;
        }
        return 0;
    }

    private String clip(String value, int maxChars) {
        if (value == null || value.length() <= maxChars) return value == null ? "" : value;
        int keep = Math.max(0, maxChars - 80);
        return value.substring(0, keep) + "\n\n[Current message truncated to fit the configured context budget.]";
    }

    private String stripProjectPatchPayloads(String value) {
        if (value == null || value.isBlank()) return value == null ? "" : value;
        return value.replaceAll("(?is)<!--\\s*PROJECT_FILE_START:[^>]+-->.*?<!--\\s*PROJECT_FILE_END\\s*-->", "")
                .replaceAll("\n{3,}", "\n\n")
                .strip();
    }

    private List<String> parseIds(String json) {
        if (json == null || json.isBlank()) return List.of();
        try {
            return objectMapper.readValue(json, new TypeReference<List<String>>() {});
        } catch (Exception e) {
            return List.of();
        }
    }
}
