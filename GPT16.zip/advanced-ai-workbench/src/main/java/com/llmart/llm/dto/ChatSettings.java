package com.llmart.llm.dto;

import com.fasterxml.jackson.annotation.JsonAlias;

import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.Locale;
import java.util.Set;
import java.util.stream.Collectors;

public record ChatSettings(
        String baseUrl,
        String model,
        String visionModel,
        Double temperature,
        Integer maxTokens,
        Integer contextChars,
        Integer contextWindowTokens,
        Boolean autoCompact,
        Integer compactionKeepTokens,
        Integer compactionBufferTokens,
        Integer oldToolOutputChars,
        String systemPrompt,
        Boolean useFileContext,
        Integer agentMaxSteps,
        Boolean agentAllowCommands,
        String agentEditPermission,
        String agentShellPermission,
        @JsonAlias("agentGitPermission") String agentReviewPermission,
        Boolean agentAutoApprove,
        String agentExtraCommands,
        String agentMcpPermission,
        String agentTaskPermission,
        String agentLspPermission,
        Boolean agentParallelReadTools
) {
    public double safeTemperature() { return temperature == null ? 0.7 : Math.max(0.0, Math.min(2.0, temperature)); }
    /**
     * 0 means provider-managed maximum. Positive values are passed through without an application-side cap.
     */
    public int safeMaxTokens() { return maxTokens == null || maxTokens <= 0 ? 0 : maxTokens; }
    /**
     * Legacy character budget kept for settings compatibility only. Agent context management is token based.
     */
    public int safeContextChars() { return contextChars == null || contextChars <= 0 ? 0 : contextChars; }

    /**
     * Provider/model context-window size in tokens. A positive explicit setting always wins. When it is left at 0,
     * the runtime uses conservative model-name hints and otherwise falls back to 128k rather than waiting for an overflow.
     */
    public int safeContextWindowTokens() {
        if (contextWindowTokens != null && contextWindowTokens > 0) return Math.max(16_000, contextWindowTokens);
        if (contextChars != null && contextChars > 0) return Math.max(16_000, contextChars / 4);
        String m = model == null ? "" : model.toLowerCase(Locale.ROOT);
        if (m.contains("gpt-oss")) return 131_072;
        if (m.contains("claude")) return 200_000;
        return 128_000;
    }

    public boolean autoCompactEnabled() { return autoCompact == null || Boolean.TRUE.equals(autoCompact); }
    public int safeCompactionKeepTokens() {
        int configured = compactionKeepTokens == null ? 8_000 : compactionKeepTokens;
        return Math.max(2_000, Math.min(configured, Math.max(2_000, safeContextWindowTokens() / 2)));
    }
    public int safeCompactionBufferTokens() {
        int configured = compactionBufferTokens == null ? 20_000 : compactionBufferTokens;
        return Math.max(4_000, Math.min(configured, Math.max(4_000, safeContextWindowTokens() / 2)));
    }
    public int safeOldToolOutputChars() {
        int configured = oldToolOutputChars == null ? 2_000 : oldToolOutputChars;
        return Math.max(400, Math.min(configured, 20_000));
    }
    public boolean fileContextEnabled() { return useFileContext == null || useFileContext; }
    public boolean hasDedicatedVisionModel() { return visionModel != null && !visionModel.isBlank(); }
    /**
     * Kept only for backward-compatible JSON/settings loading. Agent runs no longer use a fixed step ceiling.
     */
    public int safeAgentMaxSteps() { return 0; }
    public boolean agentCommandsAllowed() { return agentAllowCommands == null || Boolean.TRUE.equals(agentAllowCommands); }
    public String editPermission() { return normalizePermission(agentEditPermission, "allow"); }
    public String shellPermission() {
        if (!agentCommandsAllowed()) return "deny";
        return normalizePermission(agentShellPermission, "allow");
    }
    public String reviewPermission() { return normalizePermission(agentReviewPermission, "allow"); }
    public String mcpPermission() { return normalizePermission(agentMcpPermission, "allow"); }
    public String taskPermission() { return normalizePermission(agentTaskPermission, "allow"); }
    public String lspPermission() { return normalizePermission(agentLspPermission, "allow"); }
    public boolean parallelReadTools() { return agentParallelReadTools == null || Boolean.TRUE.equals(agentParallelReadTools); }
    public boolean autoApproveAgent() { return Boolean.TRUE.equals(agentAutoApprove); }

    public Set<String> extraAgentCommands() {
        if (agentExtraCommands == null || agentExtraCommands.isBlank()) return Set.of();
        LinkedHashSet<String> result = Arrays.stream(agentExtraCommands.split("[,\\n]"))
                .map(String::trim)
                .filter(s -> s.matches("[A-Za-z0-9._+-]{1,80}"))
                .map(s -> s.toLowerCase(Locale.ROOT))
                .collect(Collectors.toCollection(LinkedHashSet::new));
        return Set.copyOf(result);
    }

    private String normalizePermission(String value, String fallback) {
        if (value == null) return fallback;
        String p = value.trim().toLowerCase(Locale.ROOT);
        return (p.equals("allow") || p.equals("ask") || p.equals("deny")) ? p : fallback;
    }
}
