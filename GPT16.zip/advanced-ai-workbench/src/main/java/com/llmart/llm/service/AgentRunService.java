package com.llmart.llm.service;

import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicReference;

@Service
public class AgentRunService {
    private static final int MAX_RETAINED_RUNS = 100;
    private final Map<String, AgentRun> runs = new ConcurrentHashMap<>();

    public AgentRun start(String conversationId, String projectId) {
        prune();
        AgentRun run = new AgentRun(UUID.randomUUID().toString(), conversationId, projectId, Instant.now());
        runs.put(run.id(), run);
        return run;
    }

    public AgentRun require(String id) {
        AgentRun run = runs.get(id);
        if (run == null) throw new NoSuchElementException("Agent run not found");
        return run;
    }

    public boolean cancel(String id) {
        AgentRun run = runs.get(id);
        return run != null && run.cancel();
    }

    public Map<String, Object> status(String id) {
        return require(id).snapshot();
    }

    private void prune() {
        if (runs.size() < MAX_RETAINED_RUNS) return;
        runs.values().stream()
                .filter(AgentRun::finished)
                .sorted(Comparator.comparing(AgentRun::createdAt))
                .limit(Math.max(1, runs.size() - MAX_RETAINED_RUNS + 20L))
                .map(AgentRun::id)
                .toList()
                .forEach(runs::remove);
    }

    public static final class AgentRun {
        private final String id;
        private final String conversationId;
        private final String projectId;
        private final Instant createdAt;
        private final AtomicBoolean cancelled = new AtomicBoolean(false);
        private final AtomicReference<Process> activeProcess = new AtomicReference<>();
        private final AtomicLong mutationRevision = new AtomicLong(0);
        private final AtomicLong lastVerificationAttemptRevision = new AtomicLong(-1);
        private final AtomicLong verificationRequiredRevision = new AtomicLong(-1);
        private final AtomicLong lastSuccessfulVerificationRevision = new AtomicLong(-1);
        private final AtomicLong lastDiffRevision = new AtomicLong(-1);
        private final AtomicBoolean lastVerificationSuccessful = new AtomicBoolean(false);
        private final AtomicLong modelCalls = new AtomicLong(0);
        private final AtomicLong providerInputTokens = new AtomicLong(0);
        private final AtomicLong providerOutputTokens = new AtomicLong(0);
        private final AtomicLong providerTotalTokens = new AtomicLong(0);
        private final AtomicLong cachedInputTokens = new AtomicLong(0);
        private final AtomicLong cacheWriteTokens = new AtomicLong(0);
        private final AtomicLong estimatedInputTokens = new AtomicLong(0);
        private final AtomicLong currentContextTokens = new AtomicLong(0);
        private final AtomicLong contextWindowTokens = new AtomicLong(0);
        private final AtomicLong compactions = new AtomicLong(0);
        private final AtomicLong estimatedTokensSavedByCompaction = new AtomicLong(0);
        private final AtomicLong repeatedCallsPrevented = new AtomicLong(0);
        private final AtomicLong progressPercent = new AtomicLong(2);
        private final AtomicBoolean responsePersisted = new AtomicBoolean(false);
        private volatile String progressPhase = "starting";
        private volatile String progressDetail = "Preparing agent run";
        private volatile String finalAnswer = "";
        private volatile String assistantMessageId = "";
        private volatile String lastCheckpointReason = "";
        private volatile String loopBlockReason = "";
        private final List<PlanItem> plan = new ArrayList<>();
        private final Set<String> approvedToolsForRun = ConcurrentHashMap.newKeySet();
        private volatile String status = "running";
        private volatile String lastVerification = "";
        private volatile Instant finishedAt;

        private AgentRun(String id, String conversationId, String projectId, Instant createdAt) {
            this.id = id;
            this.conversationId = conversationId;
            this.projectId = projectId;
            this.createdAt = createdAt;
        }

        public String id() { return id; }
        public String conversationId() { return conversationId; }
        public String projectId() { return projectId; }
        public Instant createdAt() { return createdAt; }
        public boolean cancelled() { return cancelled.get(); }
        public boolean finished() { return finishedAt != null; }
        public long mutationRevision() { return mutationRevision.get(); }
        public long lastVerificationAttemptRevision() { return lastVerificationAttemptRevision.get(); }
        public long verificationRequiredRevision() { return verificationRequiredRevision.get(); }
        public long lastSuccessfulVerificationRevision() { return lastSuccessfulVerificationRevision.get(); }
        public long lastDiffRevision() { return lastDiffRevision.get(); }
        public String lastVerification() { return lastVerification; }
        public boolean lastVerificationSuccessful() { return lastVerificationSuccessful.get(); }
        public long modelCalls() { return modelCalls.get(); }
        public long providerInputTokens() { return providerInputTokens.get(); }
        public long providerOutputTokens() { return providerOutputTokens.get(); }
        public long providerTotalTokens() { return providerTotalTokens.get(); }
        public long cachedInputTokens() { return cachedInputTokens.get(); }
        public long compactions() { return compactions.get(); }
        public long currentContextTokens() { return currentContextTokens.get(); }
        public long contextWindowTokens() { return contextWindowTokens.get(); }
        public int progressPercent() { return (int) progressPercent.get(); }
        public String progressPhase() { return progressPhase == null ? "" : progressPhase; }
        public String progressDetail() { return progressDetail == null ? "" : progressDetail; }
        public boolean responsePersisted() { return responsePersisted.get(); }
        public String finalAnswer() { return finalAnswer == null ? "" : finalAnswer; }
        public String assistantMessageId() { return assistantMessageId == null ? "" : assistantMessageId; }
        public boolean loopBlocked() { return loopBlockReason != null && !loopBlockReason.isBlank(); }
        public String loopBlockReason() { return loopBlockReason == null ? "" : loopBlockReason; }
        public void markLoopBlocked(String reason) { loopBlockReason = reason == null ? "Repeated no-progress loop" : reason; }
        public boolean isToolApprovedForRun(String tool) { return tool != null && approvedToolsForRun.contains(tool); }
        public void approveToolForRun(String tool) { if (tool != null && !tool.isBlank()) approvedToolsForRun.add(tool); }

        public void checkCancelled() {
            if (cancelled()) throw new AgentCancelledException("Agent run was cancelled");
        }

        public boolean cancel() {
            if (finished()) return false;
            if (!cancelled.compareAndSet(false, true)) return false;
            status = "cancelled";
            terminate(activeProcess.get());
            return true;
        }

        public void registerProcess(Process process) {
            checkCancelled();
            activeProcess.set(process);
            if (cancelled()) terminate(process);
        }

        public void unregisterProcess(Process process) {
            activeProcess.compareAndSet(process, null);
        }

        public long markMutation() {
            return markMutation(true);
        }

        public long markMutation(boolean verificationRequired) {
            long revision = mutationRevision.incrementAndGet();
            if (verificationRequired) verificationRequiredRevision.set(revision);
            return revision;
        }

        public void recordContextEstimate(long currentTokens, long windowTokens) {
            currentContextTokens.set(Math.max(0, currentTokens));
            contextWindowTokens.set(Math.max(0, windowTokens));
        }

        public void recordModelUsage(OpenAiCompatibleClient.Usage usage, long estimatedInputForCall) {
            modelCalls.incrementAndGet();
            estimatedInputTokens.addAndGet(Math.max(0, estimatedInputForCall));
            if (usage == null) return;
            providerInputTokens.addAndGet(Math.max(0, usage.inputTokens()));
            providerOutputTokens.addAndGet(Math.max(0, usage.outputTokens()));
            providerTotalTokens.addAndGet(Math.max(0, usage.totalTokens()));
            cachedInputTokens.addAndGet(Math.max(0, usage.cachedInputTokens()));
            cacheWriteTokens.addAndGet(Math.max(0, usage.cacheWriteTokens()));
        }

        public void recordCompaction(long estimatedTokensSaved, String reason) {
            compactions.incrementAndGet();
            estimatedTokensSavedByCompaction.addAndGet(Math.max(0, estimatedTokensSaved));
            lastCheckpointReason = reason == null ? "" : reason;
        }

        public void markRepeatedCallPrevented() { repeatedCallsPrevented.incrementAndGet(); }

        /** Monotonic best-effort task progress. This is phase progress, not a fake ETA. */
        public void updateProgress(int percent, String phase, String detail) {
            int bounded = Math.max(0, Math.min(99, percent));
            long before = progressPercent.getAndAccumulate(bounded, Math::max);
            // Ignore stale lower-phase updates so the percentage and phase never appear to move backwards.
            if (bounded >= before) {
                if (phase != null && !phase.isBlank()) progressPhase = phase.strip();
                if (detail != null && !detail.isBlank()) progressDetail = detail.strip();
            }
        }

        public void markFinalAnswer(String answer) {
            finalAnswer = answer == null ? "" : answer;
            updateProgress(97, "finalizing", "Preparing final response");
        }

        public void markResponsePersisted(String messageId, String answer) {
            if (answer != null && !answer.isBlank()) finalAnswer = answer;
            assistantMessageId = messageId == null ? "" : messageId;
            responsePersisted.set(true);
            progressPercent.set(100);
            if ("completed".equals(status)) {
                progressPhase = "completed";
                progressDetail = "Task completed";
            } else {
                progressPhase = status;
                if (progressDetail == null || progressDetail.isBlank() || "Persisting final response".equals(progressDetail)) {
                    progressDetail = "blocked".equals(status) ? "Task blocked" : "Task " + status;
                }
            }
        }

        public void markVerificationAttempt(boolean successful, String summary) {
            long rev = mutationRevision.get();
            lastVerificationAttemptRevision.set(rev);
            if (successful) lastSuccessfulVerificationRevision.set(rev);
            lastVerificationSuccessful.set(successful);
            lastVerification = summary == null ? "" : summary;
        }

        public boolean verifiedCurrentRevision() {
            long required = verificationRequiredRevision.get();
            if (required < 0) return true;
            if (lastVerificationAttemptRevision.get() >= required && !lastVerificationSuccessful.get()) return false;
            return lastSuccessfulVerificationRevision.get() >= required;
        }

        public boolean verificationRequired() {
            return !verifiedCurrentRevision();
        }

        public void markDiffReview() {
            lastDiffRevision.set(mutationRevision.get());
        }

        public boolean diffReviewedCurrentRevision() {
            return lastDiffRevision.get() >= mutationRevision.get();
        }

        public synchronized void setPlan(List<String> items) {
            plan.clear();
            int i = 1;
            for (String item : items == null ? List.<String>of() : items) {
                if (item == null || item.isBlank()) continue;
                plan.add(new PlanItem(i++, item.strip(), "pending", ""));
            }
        }

        public synchronized void updatePlan(int index, String newStatus, String note) {
            if (index < 1 || index > plan.size()) throw new IllegalArgumentException("Plan index is out of range");
            String status = normalizePlanStatus(newStatus);
            PlanItem old = plan.get(index - 1);
            plan.set(index - 1, new PlanItem(old.index(), old.text(), status, note == null ? "" : note.strip()));
        }

        public synchronized String planText() {
            if (plan.isEmpty()) return "[No plan set]";
            StringBuilder out = new StringBuilder();
            for (PlanItem item : plan) {
                out.append(item.index()).append(". [").append(item.status()).append("] ").append(item.text());
                if (!item.note().isBlank()) out.append(" — ").append(item.note());
                out.append('\n');
            }
            return out.toString().stripTrailing();
        }

        public synchronized boolean hasPlan() { return !plan.isEmpty(); }

        public synchronized boolean hasOpenPlanItems() {
            return plan.stream().anyMatch(item -> "pending".equals(item.status()) || "in_progress".equals(item.status()));
        }

        public void finish(String finalStatus) {
            if (!"cancelled".equals(status)) status = finalStatus == null || finalStatus.isBlank() ? "completed" : finalStatus;
            if ("completed".equals(status)) {
                progressPercent.accumulateAndGet(98, Math::max);
                progressPhase = "finalizing";
                progressDetail = "Persisting final response";
            } else if ("blocked".equals(status)) {
                progressPercent.set(100);
                progressPhase = "blocked";
                progressDetail = loopBlocked() ? loopBlockReason() : "Task blocked";
            } else if ("cancelled".equals(status)) {
                progressPercent.set(100);
                progressPhase = "cancelled";
                progressDetail = "Task cancelled";
            } else if ("failed".equals(status)) {
                progressPercent.set(100);
                progressPhase = "failed";
                progressDetail = "Task failed";
            }
            finishedAt = Instant.now();
            terminate(activeProcess.getAndSet(null));
        }

        public Map<String, Object> snapshot() {
            Map<String, Object> map = new LinkedHashMap<>();
            map.put("id", id);
            map.put("conversationId", conversationId == null ? "" : conversationId);
            map.put("projectId", projectId == null ? "" : projectId);
            map.put("status", status);
            map.put("cancelled", cancelled());
            map.put("createdAt", createdAt.toString());
            if (finishedAt != null) map.put("finishedAt", finishedAt.toString());
            map.put("mutationRevision", mutationRevision());
            map.put("lastVerificationAttemptRevision", lastVerificationAttemptRevision());
            map.put("verificationRequiredRevision", verificationRequiredRevision());
            map.put("lastSuccessfulVerificationRevision", lastSuccessfulVerificationRevision());
            map.put("lastDiffRevision", lastDiffRevision());
            map.put("lastVerification", lastVerification);
            map.put("lastVerificationSuccessful", lastVerificationSuccessful());
            map.put("progressPercent", progressPercent());
            map.put("progressPhase", progressPhase());
            map.put("progressDetail", progressDetail());
            map.put("responsePersisted", responsePersisted());
            if (finished() && !finalAnswer().isBlank()) map.put("finalAnswer", finalAnswer());
            if (!assistantMessageId().isBlank()) map.put("assistantMessageId", assistantMessageId());
            Map<String,Object> usage = new LinkedHashMap<>();
            usage.put("modelCalls", modelCalls.get());
            usage.put("providerInputTokens", providerInputTokens.get());
            usage.put("providerOutputTokens", providerOutputTokens.get());
            usage.put("providerTotalTokens", providerTotalTokens.get());
            usage.put("cachedInputTokens", cachedInputTokens.get());
            usage.put("cacheWriteTokens", cacheWriteTokens.get());
            usage.put("estimatedInputTokens", estimatedInputTokens.get());
            usage.put("currentContextTokens", currentContextTokens.get());
            usage.put("contextWindowTokens", contextWindowTokens.get());
            usage.put("compactions", compactions.get());
            usage.put("estimatedTokensSavedByCompaction", estimatedTokensSavedByCompaction.get());
            usage.put("repeatedCallsPrevented", repeatedCallsPrevented.get());
            usage.put("lastCheckpointReason", lastCheckpointReason);
            usage.put("loopBlockReason", loopBlockReason);
            map.put("tokenUsage", usage);
            map.put("approvedToolsForRun", List.copyOf(approvedToolsForRun));
            synchronized (this) {
                map.put("plan", List.copyOf(plan));
            }
            return map;
        }

        private static String normalizePlanStatus(String value) {
            String status = value == null ? "pending" : value.trim().toLowerCase(Locale.ROOT);
            return switch (status) {
                case "pending", "in_progress", "completed", "blocked", "skipped" -> status;
                default -> throw new IllegalArgumentException("Unsupported plan status: " + value);
            };
        }

        private static void terminate(Process process) {
            if (process == null || !process.isAlive()) return;
            try {
                process.descendants().forEach(handle -> {
                    try { handle.destroy(); } catch (Exception ignored) { }
                });
                process.destroy();
                if (process.isAlive()) {
                    process.descendants().forEach(handle -> {
                        try { handle.destroyForcibly(); } catch (Exception ignored) { }
                    });
                    process.destroyForcibly();
                }
            } catch (Exception ignored) { }
        }
    }

    public record PlanItem(int index, String text, String status, String note) {}
}
