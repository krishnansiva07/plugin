package com.llmart.llm.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.llmart.llm.dto.ChatRequest;
import com.llmart.llm.dto.ChatSettings;
import com.llmart.llm.dto.ProjectPatchRequest;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.util.*;
import java.util.concurrent.*;
import java.util.function.Consumer;

/**
 * OpenCode-style model-step agent loop.
 *
 * Important runtime properties:
 * - the user-selected local directory is the live workspace (no mirror/staging/apply phase);
 * - native provider tool calls are the primary protocol;
 * - one model step may request multiple tools and all calls are executed before the next model turn;
 * - todos are optional helpers, never completion gates;
 * - there is no application-imposed model-step or tool-action ceiling; the run continues until verified completion,
 *   cancellation, permission denial/blocker, provider refusal, or a non-recoverable environment failure;
 * - JSON tool envelopes are only a compatibility fallback for providers without native function calling.
 */
@Service
public class AgentService {

    private static final int MAX_CONSECUTIVE_NON_ACTIONABLE_TURNS = 2;
    private static final int MAX_CONSECUTIVE_EMPTY_SUBAGENT_TURNS = 2;
    private static final int MAX_TRANSIENT_MODEL_RETRIES = 4;

    private static final String AGENT_PROTOCOL = """
            You are a general-purpose LOCAL WORKSPACE AGENT running inside a Java 17 application.
            Work like a capable coding/workspace agent: inspect evidence, use tools, make the requested changes directly in the active
            user-selected directory, observe real outputs, recover from failures, verify when useful, and then answer concisely.

            WORKSPACE MODEL
            - The selected local directory is the LIVE workspace. There is no temporary mirror, staging directory, Git index or later apply step.
            - File mutation tools write directly to the user's selected path after the configured permission check.
            - Git operations are intentionally out of product scope. Do not run git commands.
            - Stay inside the selected workspace unless the user explicitly supplied additional filesystem paths in the prompt.
            - Prompt-resolved resources are exposed by alias through resource_catalog with generic roles: primary_workspace, secondary_workspace, reference, input, or diagnostic.
            - User intent labels take priority over project inference. Input/diagnostic resources remain read-only even when they live inside another project; reference resources are also read-only.
            - Never invent an external path or bypass resource aliases. Use resource_read/resource_grep/resource_list/resource_info/resource_index/resource_chunk for secondary evidence and resource_edit/resource_write/resource_build/resource_test/resource_check/resource_bash only for writable workspace resources.
            - Multiple project paths may be handled in one run. Keep the primary workspace as the default and use resource aliases for additional projects/resources.

            TOOL BEHAVIOR
            - Prefer provider-native tools/functions. Never print fake native tool calls as prose.
            - A single model turn may call several independent tools (for example several reads). ALWAYS batch independent reads/searches in the same turn; do not serialize work that has no dependency.
            - Prefer targeted grep/index/read_many over broad recursive reads. Reuse evidence already present in the current context instead of re-reading unchanged files.
            - Delegate independent exploratory work to fresh-context explore subagents when that reduces parent-context size or latency.
            - Use read/list/glob/grep to inspect before editing when project state is unknown.
            - Large text files are context-guarded. Use file_index/resource_index first, then targeted grep/line reads; use read_chunk/resource_chunk for minified or very long-line data instead of forcing a full read.
            - Use edit for small exact changes, write for complete new/replacement files, and apply_patch for a small batch of complete writes/deletes.
            - Use build/test/check for conventional project verification and bash for custom commands, execution, formatters, diagnostics and app/runtime checks. Pipes/redirection/chaining are supported.
            - bash has no application timeout unless you explicitly set timeoutSeconds. Mark custom verification commands with verification=true.
            - For long-running apps/servers, use process_start, then process_status/process_output and http_request or bash to inspect the running application; stop with process_stop when finished.
            - todowrite/todoread are optional for genuinely long work. A todo list is NOT required before edits and is NOT a completion gate.
            - workspace_status/workspace_diff are run-local review helpers for direct agent changes; they are not Git.
            - Attachments are resources: use attachment_list/attachment_search/attachment_read instead of assuming a document was injected completely.
            - AGENTS.md/CLAUDE.md instructions and SKILL.md workflows are discovered from the live workspace; load nested instructions/skills only when relevant.
            - task delegates focused work to a fresh-context subagent. Use explore for read-only investigation and general for broad delegated work.
            - MCP servers are generic external tool providers discovered from .agents/mcp.json; their tools appear as mcp__<server>__<tool>. Use mcp_status if an expected MCP tool is missing.
            - LSP servers are configured generically in .agents/lsp.json. Use lsp_status and lsp for diagnostics, definitions, references, hover and symbols when semantic code intelligence is useful.
            - workspace_profile is durable application-side project metadata so repeated tasks do not rediscover basic toolchains/languages each time.

            CONTEXT / TOKEN BEHAVIOR
            - The runtime proactively manages the active model context. Older history may be replaced by a structured historical checkpoint while recent context is retained.
            - Compaction does NOT mean the task is ending. Continue autonomously from the checkpoint and recent tail until the task is complete.
            - The live workspace, attachments and real tool outputs are authoritative. Re-read exact details when a compacted checkpoint is insufficient.
            - Do not repeat large file contents or command logs in prose merely to preserve them; keep durable state in the workspace and use targeted reads.
            - Fresh-context subagents are useful for isolated investigations because they avoid duplicating the parent session's full token history.

            EXECUTION RULES
            1. Never invent file contents, command results, test results or project state.
            2. Keep edits as small as reasonably possible and preserve the project's existing conventions.
            3. When a command fails, use its actual output to diagnose, change the implementation or strategy, and rerun the verifier.
            4. For code/config fixes, do not stop after editing. Run the smallest high-signal verification that proves the requested change, inspect real output, and keep fixing until it succeeds or a genuine external blocker is proven. Avoid redundant full-suite reruns when a targeted verifier already proves the changed area.
            5. Uploaded files/documents/images in the conversation are reference evidence. Use them together with live workspace tools when relevant.
            6. The workspace can contain any technology or mixed content. Do not assume test automation unless the user's task is about testing.
            7. There is no artificial step/action budget. Continue working as long as useful progress is possible. Stop only when the task is verified complete, genuinely blocked, denied by permissions, cancelled, or further action would be unsafe.
            8. As soon as the requested result is satisfied and the current workspace revision has a successful verifier, FINISH. Do not keep searching, polling, re-reading, or running extra checks merely to appear thorough.
            9. In the final answer state what was changed and any verification/blocker. Do not claim an action that a tool did not actually perform.
            10. If a genuine external/environment/permission blocker prevents required verification in native-tool mode, start the final response with `Blocked:` so the runtime can terminate safely instead of forcing another identical verifier cycle.

            COMPATIBILITY FALLBACK
            If native tools are unavailable and the provider is placed in JSON compatibility mode, return exactly one JSON object per model turn:
              {"type":"tool","tool":"tool_name","reason":"short reason","args":{...}}
            or, after real work is complete:
              {"type":"final","status":"completed|blocked","message":"concise Markdown summary"}
            Canonical built-in tool names include: inspect_workspace, workspace_profile, workspace_profile_refresh, list, glob, grep, file_info, file_index, read, read_chunk, read_many,
            instruction_catalog, instructions_for, resource_catalog, resource_list, resource_info, resource_index, resource_read, resource_chunk, resource_grep, resource_edit, resource_write,
            resource_delete, resource_copy, resource_move, resource_build, resource_test, resource_check, resource_bash, attachment_list, attachment_read, attachment_search, skill_catalog, skill, agent_catalog, task, mcp_status, lsp_status, lsp,
            edit, write, copy, move, delete, apply_patch, build, test, check, bash, process_start, process_status, process_output, process_stop, http_request,
            workspace_status, workspace_diff, todowrite, todoread. Dynamic MCP tools use mcp__<server>__<tool>.
            """;

    private final OpenAiCompatibleClient llm;
    private final AgentWorkspaceService workspaces;
    private final AgentApprovalService approvals;
    private final AgentRunService runs;
    private final AgentToolRegistry toolRegistry;
    private final FileService files;
    private final McpManager mcp;
    private final WorkspaceProfileService workspaceProfiles;
    private final AgentProfileService agentProfiles;
    private final LspManager lsp;
    private final ContextWindowManager contextWindows;
    private final ObjectMapper objectMapper;

    public AgentService(OpenAiCompatibleClient llm, AgentWorkspaceService workspaces,
                        AgentApprovalService approvals, AgentRunService runs,
                        AgentToolRegistry toolRegistry, FileService files, McpManager mcp,
                        WorkspaceProfileService workspaceProfiles, AgentProfileService agentProfiles, LspManager lsp,
                        ContextWindowManager contextWindows, ObjectMapper objectMapper) {
        this.llm = llm;
        this.workspaces = workspaces;
        this.approvals = approvals;
        this.runs = runs;
        this.toolRegistry = toolRegistry;
        this.files = files;
        this.mcp = mcp;
        this.workspaceProfiles = workspaceProfiles;
        this.agentProfiles = agentProfiles;
        this.lsp = lsp;
        this.contextWindows = contextWindows;
        this.objectMapper = objectMapper;
    }

    public AgentResult run(String runId, String apiKey, ChatRequest request, List<Map<String, Object>> baseContext,
                           Consumer<Map<String, Object>> onStep) throws Exception {
        AgentRunService.AgentRun run = runs.require(runId);
        AgentWorkspaceService.Workspace ws = null;
        String completionStatus = "running";
        try {
            run.updateProgress(4, "starting", "Resolving workspace and task context");
            ws = workspaces.prepare(request.projectId(), request.message());
            run.updateProgress(8, "planning", "Discovering workspace capabilities");
            McpManager.Catalog mcpCatalog = mcp.catalog(ws.root());
            List<Map<String,Object>> availableTools = toolRegistry.mergedDefinitions(mcpCatalog.definitions());
            List<Map<String, Object>> messages = prepareMessages(baseContext, ws);
            String projectInstructions = workspaces.projectInstructions(ws);
            if (!projectInstructions.isBlank()) messages.add(1, Map.of("role", "system", "content", projectInstructions));
            String runtimeCatalog = workspaceProfiles.profileText(ws) + "\n\nPROMPT RESOURCES\n" + workspaces.resourceCatalog(ws) +
                    "\n\nAVAILABLE SKILLS\n" + workspaces.availableSkills(ws) +
                    "\n\nAVAILABLE SUBAGENTS\n" + agentProfiles.catalogText(ws) +
                    "\n\nMCP STATUS\n" + (mcpCatalog.diagnostics().isEmpty() ? "[No MCP servers configured]" : String.join("\n", mcpCatalog.diagnostics())) +
                    "\n\nLSP STATUS\n" + lsp.status(ws.root());
            messages.add(Math.min(2, messages.size()), Map.of("role", "system", "content", runtimeCatalog));
            run.updateProgress(12, "planning", "Agent context ready");

            long toolActivity = 0;
            Map<String,Integer> repeatedCalls = new HashMap<>();
            Map<String,Integer> repeatedNoProgress = new HashMap<>();
            Map<String,Integer> verificationSteering = new HashMap<>();
            long recoveryTurns = 0;
            boolean transportReported = false;
            boolean requireToolNextTurn = false;
            String finalMessage = null;
            int step = 0;

            while (true) {
                step++;
                run.checkCancelled();
                if (run.mutationRevision() == 0) run.updateProgress(14, "working", "Inspecting task and workspace");
                OpenAiCompatibleClient.AgentCompletion turn = completeAgentTurn(
                        apiKey, request, messages, run, requireToolNextTurn, availableTools, step, onStep);
                requireToolNextTurn = false;
                run.checkCancelled();

                if (!transportReported) {
                    transportReported = true;
                    String transport = turn.nativeToolsUsed()
                            ? "Native model tool calling active"
                            : turn.jsonModeUsed()
                            ? "Native tools unavailable; JSON compatibility mode active"
                            : "Provider exposes neither native tools nor JSON response mode; best-effort compatibility mode active";
                    onStep.accept(stepEvent(step, "agent_transport", transport, "success", null, null, null));
                }

                String raw = turn.content() == null ? "" : turn.content().trim();

                // Native tools: one assistant model step can contain multiple tool calls. Execute all of them
                // before asking the model to reason again, matching modern agent runtimes and dramatically
                // reducing the old 40/80-step one-tool-at-a-time behavior.
                if (turn.hasToolCall()) {
                    List<OpenAiCompatibleClient.AgentToolCall> calls = turn.toolCalls();
                    appendNativeAssistantTurn(messages, calls, raw);

                    long successfulVerificationBefore = run.lastSuccessfulVerificationRevision();
                    toolActivity += executeNativeCalls(calls, messages, ws, run, request, apiKey, mcpCatalog,
                            availableTools, step, onStep, repeatedCalls);
                    recoveryTurns = 0;
                    if (run.loopBlocked()) {
                        completionStatus = "blocked";
                        finalMessage = "Blocked: " + run.loopBlockReason();
                        onStep.accept(stepEvent(step, "loop_guard", run.loopBlockReason(), "error", null, null, null));
                        break;
                    }
                    if (run.mutationRevision() > 0 && run.verifiedCurrentRevision() &&
                            run.lastSuccessfulVerificationRevision() > successfulVerificationBefore && !run.hasOpenPlanItems()) {
                        run.updateProgress(90, "completion_check", "Verification passed; checking whether the requested task is complete");
                        String completionGate = completionGate(apiKey, request, messages, run, step, onStep);
                        if (completionGate != null && !completionGate.isBlank() && !"CONTINUE".equalsIgnoreCase(completionGate.strip())) {
                            completionStatus = completionGate.startsWith("Blocked:") ? "blocked" : "completed";
                            finalMessage = completionGate.strip();
                            onStep.accept(stepEvent(step, "finish", "Verified task completed", "done", null, null, null));
                            break;
                        }
                        if ("CONTINUE".equalsIgnoreCase(String.valueOf(completionGate).strip())) {
                            messages.add(Map.of("role", "assistant", "content", "Completion check: additional requested work remains; continue with tools."));
                        }
                    }
                    continue;
                }

                JsonNode envelope = parseEnvelope(raw);
                if (envelope != null && envelope.isObject()) {
                    String type = envelope.path("type").asText("").trim().toLowerCase(Locale.ROOT);
                    if ("final".equals(type) && toolActivity > 0) {
                        String requestedStatus = normalizeFinalStatus(envelope.path("status").asText("completed"));
                        String requestedMessage = envelope.path("message").asText("").trim();
                        if ("completed".equals(requestedStatus) && requiresCurrentRevisionVerification(run)) {
                            if (verificationSteeringBlocked(verificationSteering, run)) {
                                completionStatus = "blocked";
                                finalMessage = "Blocked: the model repeatedly attempted to finish the same unverified workspace revision without producing a new verifier result or fix. The runtime stopped the no-progress verification loop to protect the token budget.";
                                onStep.accept(stepEvent(step, "loop_guard", "Stopped repeated finish-without-verification loop", "error", null, clipUi(raw), null));
                                break;
                            }
                            if (!raw.isBlank()) messages.add(Map.of("role", "assistant", "content", raw));
                            messages.add(Map.of("role", "user", "content", verificationRequiredPrompt(run)));
                            onStep.accept(stepEvent(step, "verification_required",
                                    "Workspace changed after the last successful verifier; continuing until the current revision is verified",
                                    "running", null, null, null));
                            requireToolNextTurn = turn.nativeToolsUsed();
                            continue;
                        }
                        completionStatus = requestedStatus;
                        finalMessage = requestedMessage.isBlank() ? "Agent run completed." : requestedMessage;
                        onStep.accept(stepEvent(step, "finish", "Agent prepared the final response", "done", null, null, null));
                        break;
                    }
                    if ("tool".equals(type)) {
                        String requestedTool = envelope.path("tool").asText("").trim();
                        String tool = toolRegistry.canonical(requestedTool);
                        JsonNode args = normalizeLegacyArgs(requestedTool, tool, envelope.path("args"));
                        String detail = envelope.path("reason").asText("").trim();
                        if (detail.isBlank()) detail = describeTool(tool, args);
                        String result;
                        String status;

                        onStep.accept(stepEvent(step, tool, detail, "running", args, null, null));
                        if (!isKnownTool(requestedTool, tool, mcpCatalog)) {
                            result = unknownToolMessage(requestedTool, mcpCatalog);
                            status = "error";
                        } else {
                            PreparedCall compatibilityCall = new PreparedCall(
                                    new OpenAiCompatibleClient.AgentToolCall("compat_" + step, requestedTool, args),
                                    requestedTool, tool, args, detail);
                            ToolExecution execution = preflightCall(compatibilityCall, mcpCatalog);
                            if (execution == null) {
                                execution = executeWithPermission(ws, run, tool, args, request.settings(), detail, step, onStep,
                                        mcpCatalog, availableTools, apiKey, request);
                            }
                            execution = applyRepeatOutcomeGuard(compatibilityCall, execution, run, repeatedCalls, mcpCatalog);
                            result = execution.result();
                            status = execution.status();
                            if (execution.executed()) {
                                observeRun(run, tool, args, result);
                                toolActivity++;
                            }
                        }
                        onStep.accept(stepEvent(step, tool, summarizeResult(tool, result), status, args, clipUi(result), null));
                        appendFallbackToolTranscript(messages, raw, tool, result);
                        recoveryTurns = 0;
                        if (run.loopBlocked()) {
                            completionStatus = "blocked";
                            finalMessage = "Blocked: " + run.loopBlockReason();
                            onStep.accept(stepEvent(step, "loop_guard", run.loopBlockReason(), "error", null, null, null));
                            break;
                        }
                        continue;
                    }
                }

                // A prose response after real work can finish only when the current mutated revision is verified.
                if (!raw.isBlank() && toolActivity > 0) {
                    if (requiresCurrentRevisionVerification(run)) {
                        if (looksLikeBlockedFinal(raw) && externalVerificationBlocker(run.lastVerification())) {
                            completionStatus = "blocked";
                            finalMessage = raw;
                            onStep.accept(stepEvent(step, "finish",
                                    "Agent stopped because the execution environment prevented required verification",
                                    "blocked", null, clipUi(raw), null));
                            break;
                        }
                        if (verificationSteeringBlocked(verificationSteering, run)) {
                            completionStatus = "blocked";
                            finalMessage = "Blocked: the model repeatedly tried to finish an unverified workspace revision without a new fix or verifier result. The duplicate verification loop was stopped to protect the token budget.";
                            onStep.accept(stepEvent(step, "loop_guard", "Stopped repeated finish-without-verification loop", "error", null, clipUi(raw), null));
                            break;
                        }
                        messages.add(Map.of("role", "assistant", "content", raw));
                        messages.add(Map.of("role", "user", "content", verificationRequiredPrompt(run)));
                        onStep.accept(stepEvent(step, "verification_required",
                                "The current workspace revision is not successfully verified; continuing the build/run/fix loop",
                                "running", null, clipUi(raw), null));
                        requireToolNextTurn = turn.nativeToolsUsed();
                        continue;
                    }
                    completionStatus = "completed";
                    finalMessage = raw;
                    onStep.accept(stepEvent(step, "finish", "Agent completed after verified tool activity", "done", null, null, null));
                    break;
                }

                // No fixed useful-work ceiling, but identical no-progress model turns are not allowed to burn tokens forever.
                // The guard is revision-aware: any real workspace mutation resets the fingerprint naturally.
                String noProgressFingerprint = run.mutationRevision() + "|" + normalizeNoProgress(raw);
                int noProgressCount = repeatedNoProgress.merge(noProgressFingerprint, 1, Integer::sum);
                if (noProgressCount > 3) {
                    run.markRepeatedCallPrevented();
                    completionStatus = "blocked";
                    finalMessage = "Blocked: the model returned the same non-actionable response repeatedly without any workspace progress. " +
                            "The runtime stopped the duplicate loop to protect the token budget. Retry with a different model/prompt or inspect the last agent events.";
                    onStep.accept(stepEvent(step, "loop_guard",
                            "Stopped repeated non-actionable model output with no workspace progress",
                            "error", null, clipUi(raw), null));
                    break;
                }
                recoveryTurns++;
                if (recoveryTurns >= MAX_CONSECUTIVE_NON_ACTIONABLE_TURNS) {
                    run.markRepeatedCallPrevented();
                    completionStatus = "blocked";
                    finalMessage = "Blocked: the model produced " + recoveryTurns +
                            " consecutive non-actionable Agent turns without any tool/workspace progress. " +
                            "The runtime stopped the no-progress streak to protect the token budget; this does not limit productive tool actions.";
                    onStep.accept(stepEvent(step, "loop_guard",
                            "Stopped consecutive non-actionable model turns with no tool/workspace progress",
                            "error", null, clipUi(raw), null));
                    break;
                }
                if (!raw.isBlank()) messages.add(Map.of("role", "assistant", "content", raw));
                messages.add(Map.of("role", "user", "content",
                        "You are still in Agent mode. Continue the task with real workspace tools now; do not only describe a proposed change. " +
                                "Inspect/read when needed, edit directly, then build/test/check/execute and verify the result. " +
                                "If a verifier fails, diagnose the actual output, fix the cause, and rerun it."));
                requireToolNextTurn = turn.nativeToolsUsed();
                onStep.accept(stepEvent(step, "agent_recovery",
                        "Model returned without an actionable tool call; continuing the same run (recovery turn " + recoveryTurns + ")",
                        "running", null, clipUi(raw), null));
            }

            List<ProjectPatchRequest.ProjectPatchFile> changes = workspaces.changes(ws);
            finalMessage = decorateFinalMessage(finalMessage, ws, changes, run, completionStatus);
            run.markFinalAnswer(finalMessage);
            run.finish(completionStatus);
            return new AgentResult(finalMessage, changes);
        } catch (AgentCancelledException cancelled) {
            run.finish("cancelled");
            throw cancelled;
        } catch (Exception e) {
            run.finish("failed");
            throw e;
        } finally {
            approvals.cancelRun(run.id());
            workspaces.stopRunProcesses(run.id());
            workspaces.cleanup(ws); // direct workspace cleanup is intentionally a no-op
        }
    }

    private List<Map<String, Object>> prepareMessages(List<Map<String, Object>> baseContext,
                                                       AgentWorkspaceService.Workspace ws) {
        List<Map<String, Object>> messages = new ArrayList<>();
        boolean merged = false;
        if (baseContext != null) {
            for (Map<String, Object> message : baseContext) {
                if (!merged && "system".equals(String.valueOf(message.get("role")))) {
                    Map<String, Object> copy = new LinkedHashMap<>(message);
                    copy.put("content", String.valueOf(message.getOrDefault("content", "")) + "\n\n" + AGENT_PROTOCOL +
                            "\n\nACTIVE LIVE WORKSPACE ROOT: " + ws.root());
                    messages.add(copy);
                    merged = true;
                } else {
                    messages.add(new LinkedHashMap<>(message));
                }
            }
        }
        if (!merged) {
            messages.add(0, Map.of("role", "system", "content", AGENT_PROTOCOL +
                    "\n\nACTIVE LIVE WORKSPACE ROOT: " + ws.root()));
        }
        return messages;
    }

    private long executeNativeCalls(List<OpenAiCompatibleClient.AgentToolCall> calls,
                                    List<Map<String,Object>> messages,
                                    AgentWorkspaceService.Workspace ws,
                                    AgentRunService.AgentRun run,
                                    ChatRequest request,
                                    String apiKey,
                                    McpManager.Catalog mcpCatalog,
                                    List<Map<String,Object>> availableTools,
                                    int step,
                                    Consumer<Map<String,Object>> onStep,
                                    Map<String,Integer> repeatedCalls) {
        List<PreparedCall> prepared = new ArrayList<>();
        for (OpenAiCompatibleClient.AgentToolCall call : calls) {
            String requested = call.name() == null ? "" : call.name().trim();
            String tool = toolRegistry.canonical(requested);
            JsonNode args = normalizeLegacyArgs(requested, tool, call.arguments());
            prepared.add(new PreparedCall(call, requested, tool, args, describeTool(tool,args)));
        }
        long activity = 0;
        int i = 0;
        while (i < prepared.size()) {
            PreparedCall first = prepared.get(i);
            boolean parallel = request.settings().parallelReadTools() && canParallel(first, request.settings(), mcpCatalog);
            int end = i + 1;
            if (parallel) while (end < prepared.size() && canParallel(prepared.get(end), request.settings(), mcpCatalog)) end++;
            if (parallel && end - i > 1) {
                List<PreparedCall> group = prepared.subList(i,end);
                for (PreparedCall c : group) onStep.accept(stepEvent(step,c.tool(),c.detail(),"running",c.args(),null,null));
                ExecutorService executor = Executors.newCachedThreadPool(r -> {
                    Thread t = new Thread(r, "agent-parallel-read"); t.setDaemon(true); return t;
                });
                List<Future<ToolExecution>> futures = new ArrayList<>();
                try {
                    for (PreparedCall c : group) {
                        ToolExecution pre = preflightCall(c, mcpCatalog);
                        if (pre != null) futures.add(CompletableFuture.completedFuture(pre));
                        else futures.add(executor.submit(() -> executeWithPermission(ws, run, c.tool(), c.args(), request.settings(), c.detail(), step,
                                onStep, mcpCatalog, availableTools, apiKey, request)));
                    }
                    for (int k=0;k<group.size();k++) {
                        PreparedCall c=group.get(k); ToolExecution e;
                        try { e=futures.get(k).get(); } catch (Exception ex) { e=new ToolExecution("TOOL ERROR: "+safe(ex.getMessage()),"error",false); }
                        e = applyRepeatOutcomeGuard(c, e, run, repeatedCalls, mcpCatalog);
                        if (e.executed()) { observeRun(run,c.tool(),c.args(),e.result()); activity++; }
                        onStep.accept(stepEvent(step,c.tool(),summarizeResult(c.tool(),e.result()),e.status(),c.args(),clipUi(e.result()),null));
                        appendNativeToolResult(messages,c.call().id(),c.requestedTool(),e.result());
                    }
                } finally { executor.shutdownNow(); }
            } else {
                PreparedCall c=first;
                onStep.accept(stepEvent(step,c.tool(),c.detail(),"running",c.args(),null,null));
                ToolExecution e=preflightCall(c,mcpCatalog);
                if (e==null) e=executeWithPermission(ws,run,c.tool(),c.args(),request.settings(),c.detail(),step,onStep,
                        mcpCatalog,availableTools,apiKey,request);
                e=applyRepeatOutcomeGuard(c,e,run,repeatedCalls,mcpCatalog);
                if (e.executed()) { observeRun(run,c.tool(),c.args(),e.result()); activity++; }
                onStep.accept(stepEvent(step,c.tool(),summarizeResult(c.tool(),e.result()),e.status(),c.args(),clipUi(e.result()),null));
                appendNativeToolResult(messages,c.call().id(),c.requestedTool(),e.result());
            }
            i=end;
        }
        return activity;
    }

    private ToolExecution preflightCall(PreparedCall c, McpManager.Catalog mcpCatalog) {
        if (!isKnownTool(c.requestedTool(), c.tool(), mcpCatalog)) {
            return new ToolExecution(unknownToolMessage(c.requestedTool(), mcpCatalog), "error", false);
        }
        return null;
    }

    /**
     * Result-aware loop protection. Repeating a command is allowed when it produces new evidence; only the same
     * call producing the same normalized outcome on the same workspace revision is considered a no-progress loop.
     * This preserves unlimited useful build/test/diagnostic work while stopping token-burning duplicates.
     */
    private ToolExecution applyRepeatOutcomeGuard(PreparedCall c, ToolExecution execution,
                                                  AgentRunService.AgentRun run,
                                                  Map<String,Integer> repeatedOutcomes,
                                                  McpManager.Catalog mcpCatalog) {
        if (execution == null) return new ToolExecution("TOOL ERROR: empty execution result", "error", false);
        boolean eligible = !execution.executed() || isRepeatGuardEligible(c.tool(), c.args(), mcpCatalog) ||
                (isMutationTool(c.tool()) && explicitlyNoWorkspaceChange(execution.result()));
        if (!eligible) return execution;

        String outcome = normalizeToolOutcome(execution.result());
        String fingerprint = c.tool() + "|args=" + Integer.toHexString(canonicalArgs(c.args()).hashCode()) +
                "|revision=" + run.mutationRevision() + "|status=" + execution.status() +
                "|outcome=" + Integer.toHexString(outcome.hashCode());
        if (repeatedOutcomes.size() > 8_000) repeatedOutcomes.clear();
        int count = repeatedOutcomes.merge(fingerprint, 1, Integer::sum);
        int limit = Set.of("process_status", "process_output").contains(c.tool()) ? 4 : 3;
        if (count == limit - 1) {
            return new ToolExecution(execution.result() +
                    "\n\nDOOM LOOP WARNING: this exact tool call is producing the same outcome repeatedly on the same workspace revision. " +
                    "Do not repeat it unchanged again; inspect different evidence, wait only when the process genuinely needs time, modify the workspace, or change strategy.",
                    execution.status(), execution.executed());
        }
        if (count >= limit) {
            run.markRepeatedCallPrevented();
            run.markLoopBlocked("the same tool call produced the same outcome repeatedly on workspace revision " +
                    run.mutationRevision() + ". The runtime stopped the no-progress loop; useful calls with changed output remain unrestricted.");
            return new ToolExecution("DOOM LOOP BLOCKED: the same tool call produced the same result repeatedly without workspace progress. " +
                    "The last real result was:\n" + execution.result(), "error", execution.executed());
        }
        return execution;
    }

    private String normalizeToolOutcome(String result) {
        if (result == null || result.isBlank()) return "<blank>";
        String normalized = result.toLowerCase(Locale.ROOT).replaceAll("\\s+", " ").trim();
        if (normalized.length() <= 6_000) return normalized;
        return normalized.substring(0, 4_000) + "|tail|" + normalized.substring(normalized.length() - 2_000);
    }

    private ToolExecution applyChildRepeatOutcomeGuard(PreparedCall c, ToolExecution execution,
                                                       AgentRunService.AgentRun parentRun,
                                                       Map<String,Integer> repeatedOutcomes,
                                                       McpManager.Catalog mcpCatalog) {
        if (execution == null) return new ToolExecution("TOOL ERROR: empty execution result", "error", false);
        boolean eligible = !execution.executed() || isRepeatGuardEligible(c.tool(), c.args(), mcpCatalog) ||
                (isMutationTool(c.tool()) && explicitlyNoWorkspaceChange(execution.result()));
        if (!eligible) return execution;
        String outcome = normalizeToolOutcome(execution.result());
        String fingerprint = c.tool() + "|args=" + Integer.toHexString(canonicalArgs(c.args()).hashCode()) +
                "|revision=" + parentRun.mutationRevision() + "|status=" + execution.status() +
                "|outcome=" + Integer.toHexString(outcome.hashCode());
        if (repeatedOutcomes.size() > 2_000) repeatedOutcomes.clear();
        int count = repeatedOutcomes.merge(fingerprint, 1, Integer::sum);
        int limit = Set.of("process_status", "process_output").contains(c.tool()) ? 4 : 3;
        if (count == limit - 1) {
            return new ToolExecution(execution.result() +
                    "\n\nSUBAGENT LOOP WARNING: this exact call is producing the same outcome repeatedly. Change strategy instead of repeating it.",
                    execution.status(), execution.executed());
        }
        if (count >= limit) {
            parentRun.markRepeatedCallPrevented();
            return new ToolExecution("SUBAGENT LOOP BLOCKED: the same tool call produced the same result repeatedly without workspace progress. " +
                    "The parent agent can choose a different investigation strategy. Last result:\n" + execution.result(),
                    "error", execution.executed());
        }
        return execution;
    }

    private boolean isRepeatGuardEligible(String tool, JsonNode args, McpManager.Catalog catalog) {
        if ("todoread".equals(tool)) return false;
        if (Set.of("process_status","process_output","workspace_status","workspace_diff").contains(tool)) return true;
        if (Set.of("build","test","check","resource_build","resource_test","resource_check").contains(tool)) return true;
        if (Set.of("bash","resource_bash","http_request").contains(tool) && args != null && args.path("verification").asBoolean(false)) return true;
        return toolRegistry.isParallelReadOnly(tool) || mcp.isReadOnly(catalog,tool);
    }

    private boolean isMutationTool(String tool) {
        return Set.of("edit", "write", "copy", "move", "delete", "apply_patch",
                "resource_edit", "resource_write", "resource_delete", "resource_copy", "resource_move").contains(tool);
    }

    private boolean explicitlyNoWorkspaceChange(String result) {
        return result != null && (result.startsWith("workspaceChanged=false;") || result.startsWith("resourceChanged=false;"));
    }

    private boolean directMutationChanged(String result) {
        // New mutation tools report the marker explicitly. Keep the fallback true for compatibility with custom/older tools.
        return result == null || !explicitlyNoWorkspaceChange(result);
    }

    private boolean canParallel(PreparedCall c, ChatSettings settings, McpManager.Catalog catalog) {
        if (!isKnownTool(c.requestedTool(),c.tool(),catalog)) return false;
        boolean readOnly=toolRegistry.isParallelReadOnly(c.tool()) || mcp.isReadOnly(catalog,c.tool());
        if (!readOnly) return false;
        String p=permissionFor(c.tool(),settings);
        return "allow".equals(p) || ("ask".equals(p) && settings.autoApproveAgent());
    }

    private boolean isKnownTool(String requested, String canonical, McpManager.Catalog catalog) {
        return toolRegistry.isKnownBuiltIn(requested) || toolRegistry.isKnownBuiltIn(canonical) || mcp.isMcpTool(catalog,canonical) || mcp.isMcpTool(catalog,requested);
    }

    private String unknownToolMessage(String requested, McpManager.Catalog catalog) {
        LinkedHashSet<String> names=new LinkedHashSet<>(toolRegistry.names());
        if (catalog!=null) names.addAll(catalog.byFunction().keySet());
        return "TOOL ERROR: unknown tool '"+requested+"'. Available tools: "+String.join(", ",names);
    }

    private String runSubagent(AgentWorkspaceService.Workspace ws, AgentRunService.AgentRun parentRun,
                               ChatRequest request, String apiKey, McpManager.Catalog mcpCatalog,
                               List<Map<String,Object>> availableTools, String agentId, String prompt,
                               int parentStep, Consumer<Map<String,Object>> onStep) throws Exception {
        AgentProfileService.AgentProfile profile=agentProfiles.require(ws,agentId);
        List<Map<String,Object>> childTools=toolRegistry.filterDefinitions(availableTools,profile.allowedTools(),true);
        Set<String> childNames=new HashSet<>(); for(Map<String,Object>d:childTools) childNames.add(toolRegistry.functionName(d));
        String model=profile.model()==null||profile.model().isBlank()?request.settings().model():profile.model();
        List<Map<String,Object>> child=new ArrayList<>();
        child.add(Map.of("role","system","content",profile.systemPrompt()+"\n\nACTIVE LIVE WORKSPACE ROOT: "+ws.root()+
                "\n\n"+workspaceProfiles.profileText(ws)+"\n\n"+workspaces.projectInstructions(ws)+
                "\n\nPrompt-resolved resources:\n"+workspaces.resourceCatalog(ws)+
                "\n\nAvailable skills:\n"+workspaces.availableSkills(ws)+
                "\n\nYou are a child session. Do not invoke another subagent. Use real tools and return a concise evidence-based report to the parent."));
        child.add(Map.of("role","user","content",prompt));
        long toolActivity=0; int childTurn=0;
        boolean childOverflowRecovered = false;
        int emptyChildTurns = 0;
        int childTransientFailures = 0;
        Map<String,Integer> childRepeatedOutcomes = new HashMap<>();
        while(true){
            childTurn++; parentRun.checkCancelled();
            prepareActiveContext(apiKey, request, model, child, childTools, request.settings(), parentRun, parentStep, onStep, false);
            ContextWindowManager.ContextEstimate childEstimate = contextWindows.estimate(child, childTools, request.settings());
            parentRun.recordContextEstimate(childEstimate.estimatedInputTokens(), childEstimate.contextWindowTokens());
            OpenAiCompatibleClient.AgentCompletion turn;
            try {
                turn=llm.completeAgent(apiKey,request.settings().baseUrl(),model,request.settings().safeMaxTokens(),child,childTools,false,parentRun::cancelled);
                parentRun.recordModelUsage(turn.usage(), childEstimate.estimatedInputTokens());
            } catch(Exception e){
                if(isContextWindowFailure(e) && !childOverflowRecovered){
                    ContextWindowManager.CompactionResult compacted = contextWindows.compact(child, childTools, request.settings(), parentRun, true,
                            compactionSummarizer(apiKey, request, model, parentRun));
                    childOverflowRecovered = true;
                    if(compacted.compacted()){
                        parentRun.recordCompaction(compacted.estimatedTokensSaved(), "subagent:"+agentId+" "+compacted.reason());
                        onStep.accept(stepEvent(parentStep,"context_compaction","Subagent "+agentId+": provider overflow recovered: "+formatCompaction(compacted),"success",null,null,null));
                        continue;
                    }
                }
                if(!isTransientModelFailure(e)) throw e;
                childTransientFailures++;
                if (childTransientFailures > MAX_TRANSIENT_MODEL_RETRIES) {
                    return "SUBAGENT " + agentId + " BLOCKED\nModel request failed repeatedly after " + MAX_TRANSIENT_MODEL_RETRIES + " retries: " + safe(e.getMessage()) + "\n\nchildToolActions=" + toolActivity;
                }
                sleepCancellable(parentRun,Math.min(8_000L,500L << Math.min(4, childTransientFailures - 1)));
                continue;
            }
            childOverflowRecovered = false;
            childTransientFailures = 0;
            String raw=turn.content()==null?"":turn.content().trim();
            if(turn.hasToolCall()){
                emptyChildTurns = 0;
                appendNativeAssistantTurn(child,turn.toolCalls(),raw);
                for(OpenAiCompatibleClient.AgentToolCall call:turn.toolCalls()){
                    String requested=call.name()==null?"":call.name().trim(); String tool=toolRegistry.canonical(requested);
                    JsonNode args=normalizeLegacyArgs(requested,tool,call.arguments());
                    if(!childNames.contains(requested)&&!childNames.contains(tool)){
                        appendNativeToolResult(child,call.id(),requested,"SUBAGENT TOOL DENIED: tool is not available to subagent '"+agentId+"'.");
                        continue;
                    }
                    onStep.accept(stepEvent(parentStep,"subagent:"+agentId+"→"+tool,describeTool(tool,args),"running",args,null,null));
                    PreparedCall childCall = new PreparedCall(call, requested, tool, args, describeTool(tool,args));
                    ToolExecution execution = preflightCall(childCall, mcpCatalog);
                    if (execution == null) {
                        execution=executeWithPermission(ws,parentRun,tool,args,request.settings(),"Subagent "+agentId+": "+describeTool(tool,args),parentStep,onStep,
                                mcpCatalog,childTools,apiKey,request);
                    }
                    execution = applyChildRepeatOutcomeGuard(childCall, execution, parentRun, childRepeatedOutcomes, mcpCatalog);
                    if(execution.executed()){ observeRun(parentRun,tool,args,execution.result()); toolActivity++; }
                    onStep.accept(stepEvent(parentStep,"subagent:"+agentId+"→"+tool,summarizeResult(tool,execution.result()),execution.status(),args,clipUi(execution.result()),null));
                    appendNativeToolResult(child,call.id(),requested,execution.result());
                    if (execution.result().startsWith("SUBAGENT LOOP BLOCKED:")) {
                        return "SUBAGENT " + agentId + " BLOCKED\n" + execution.result() + "\n\nchildToolActions=" + toolActivity;
                    }
                }
                continue;
            }
            JsonNode env=parseEnvelope(raw);
            if(env!=null&&env.isObject()&&"tool".equals(env.path("type").asText(""))){
                emptyChildTurns = 0;
                String requested=env.path("tool").asText(""); String tool=toolRegistry.canonical(requested);
                JsonNode args=normalizeLegacyArgs(requested,tool,env.path("args"));
                if(!childNames.contains(requested)&&!childNames.contains(tool)){ child.add(Map.of("role","user","content","That tool is unavailable to this subagent. Use one of: "+String.join(", ",childNames))); continue; }
                PreparedCall childCall = new PreparedCall(
                        new OpenAiCompatibleClient.AgentToolCall("subagent_compat_" + childTurn, requested, args),
                        requested, tool, args, describeTool(tool,args));
                ToolExecution execution = preflightCall(childCall, mcpCatalog);
                if (execution == null) {
                    execution=executeWithPermission(ws,parentRun,tool,args,request.settings(),"Subagent "+agentId+": "+describeTool(tool,args),parentStep,onStep,
                            mcpCatalog,childTools,apiKey,request);
                }
                execution = applyChildRepeatOutcomeGuard(childCall, execution, parentRun, childRepeatedOutcomes, mcpCatalog);
                if(execution.executed()){ observeRun(parentRun,tool,args,execution.result()); toolActivity++; }
                appendFallbackToolTranscript(child,raw,tool,execution.result());
                if (execution.result().startsWith("SUBAGENT LOOP BLOCKED:")) {
                    return "SUBAGENT " + agentId + " BLOCKED\n" + execution.result() + "\n\nchildToolActions=" + toolActivity;
                }
                continue;
            }
            if(!raw.isBlank()) return "SUBAGENT "+agentId+" REPORT\n"+raw+"\n\nchildToolActions="+toolActivity;
            emptyChildTurns++;
            if (emptyChildTurns >= MAX_CONSECUTIVE_EMPTY_SUBAGENT_TURNS) {
                parentRun.markRepeatedCallPrevented();
                return "SUBAGENT " + agentId + " BLOCKED\nThe subagent returned empty/non-actionable turns repeatedly; the child session was stopped to protect the token budget.\n\nchildToolActions=" + toolActivity;
            }
            child.add(Map.of("role","user","content","Continue the delegated task using the available tools, then return your findings."));
        }
    }

    /**
     * After a new workspace revision has passed a verifier, ask the model once — with no tools exposed — whether
     * the original request is actually satisfied. This prevents the common "tests are green but agent keeps
     * searching/polling" tail without blindly assuming that every intermediate green build means the whole task is done.
     * Return CONTINUE when more requested work remains; otherwise return the final user-facing answer.
     */
    private String completionGate(String apiKey, ChatRequest request, List<Map<String,Object>> messages,
                                  AgentRunService.AgentRun run, int step, Consumer<Map<String,Object>> onStep) {
        try {
            List<Map<String,Object>> gate = new ArrayList<>(messages);
            gate.add(Map.of("role", "user", "content", """
                    RUNTIME COMPLETION CHECK. The current workspace revision has just passed its required verifier.
                    Decide whether the user's ORIGINAL request is fully satisfied based only on the conversation, workspace evidence and verifier result already present.
                    - If any requested implementation/fix/migration/test/documentation work is still incomplete, output exactly: CONTINUE
                    - If the request is complete, return the concise final answer to the user now: what changed and the verification performed.
                    - Do not propose extra optional work. Do not request or simulate tools. Do not repeat investigation that is already complete.
                    """));
            ContextWindowManager.ContextEstimate estimate = contextWindows.estimate(gate, List.of(), request.settings());
            run.recordContextEstimate(estimate.estimatedInputTokens(), estimate.contextWindowTokens());
            int maxOut = request.settings().safeMaxTokens() > 0 ? Math.min(2_500, request.settings().safeMaxTokens()) : 2_500;
            OpenAiCompatibleClient.AgentCompletion completion = llm.completeTextWithUsage(
                    apiKey, request.settings().baseUrl(), request.settings().model(), maxOut, gate, run::cancelled);
            run.recordModelUsage(completion.usage(), estimate.estimatedInputTokens());
            String value = completion.content() == null ? "" : completion.content().trim();
            onStep.accept(stepEvent(step, "completion_check",
                    "Verified revision completion check: " + ("CONTINUE".equalsIgnoreCase(value) ? "more requested work remains" : "task satisfied"),
                    "CONTINUE".equalsIgnoreCase(value) ? "running" : "success", null, null, null));
            return value;
        } catch (Exception e) {
            // Completion acceleration is an optimization, not a correctness dependency. Resume the ordinary agent loop.
            onStep.accept(stepEvent(step, "completion_check", "Completion check unavailable; continuing normal agent flow", "running", null, clipUi(safe(e.getMessage())), null));
            return "CONTINUE";
        }
    }

    private OpenAiCompatibleClient.AgentCompletion completeAgentTurn(String apiKey, ChatRequest request,
                                                                      List<Map<String, Object>> messages,
                                                                      AgentRunService.AgentRun run,
                                                                      boolean requireTool,
                                                                      List<Map<String,Object>> availableTools,
                                                                      int step,
                                                                      Consumer<Map<String,Object>> onStep) throws Exception {
        long transientAttempt = 0;
        boolean overflowRecovered = false;
        while (true) {
            run.checkCancelled();
            prepareActiveContext(apiKey, request, request.settings().model(), messages, availableTools, request.settings(), run, step, onStep, false);
            ContextWindowManager.ContextEstimate estimate = contextWindows.estimate(messages, availableTools, request.settings());
            run.recordContextEstimate(estimate.estimatedInputTokens(), estimate.contextWindowTokens());
            try {
                OpenAiCompatibleClient.AgentCompletion turn = llm.completeAgent(apiKey, request.settings().baseUrl(), request.settings().model(),
                        request.settings().safeMaxTokens(), messages,
                        availableTools, requireTool, run::cancelled);
                run.recordModelUsage(turn.usage(), estimate.estimatedInputTokens());
                if (run.modelCalls() == 1 || run.modelCalls() % 10 == 0) {
                    onStep.accept(stepEvent(step, "token_usage", tokenUsageDetail(run), "success", null, null, null));
                }
                return turn;
            } catch (AgentCancelledException cancelled) {
                throw cancelled;
            } catch (Exception e) {
                if (isContextWindowFailure(e) && !overflowRecovered) {
                    ContextWindowManager.CompactionResult compacted = contextWindows.compact(messages, availableTools,
                            request.settings(), run, true, compactionSummarizer(apiKey, request, request.settings().model(), run));
                    overflowRecovered = true;
                    if (compacted.compacted()) {
                        run.recordCompaction(compacted.estimatedTokensSaved(), compacted.reason());
                        onStep.accept(stepEvent(step, "context_compaction",
                                "Provider context overflow recovered: " + formatCompaction(compacted),
                                "success", null, null, null));
                        continue;
                    }
                }
                if (!isTransientModelFailure(e)) throw e;
                transientAttempt++;
                if (transientAttempt > MAX_TRANSIENT_MODEL_RETRIES) {
                    throw new IllegalStateException("Model request failed repeatedly after " + MAX_TRANSIENT_MODEL_RETRIES + " retries: " + safe(e.getMessage()), e);
                }
                long waitMs = Math.min(8_000L, 500L << Math.min(4, Math.max(0, (int) transientAttempt - 1)));
                onStep.accept(stepEvent(step, "agent_recovery", "Transient model error; retrying " + transientAttempt + "/" + MAX_TRANSIENT_MODEL_RETRIES, "running", null, clipUi(safe(e.getMessage())), null));
                sleepCancellable(run, waitMs);
            }
        }
    }

    private void prepareActiveContext(String apiKey, ChatRequest request, String model,
                                      List<Map<String,Object>> messages, List<Map<String,Object>> availableTools,
                                      ChatSettings settings, AgentRunService.AgentRun run, int step,
                                      Consumer<Map<String,Object>> onStep, boolean forced) {
        int pruned = contextWindows.pruneOldToolOutputs(messages, settings);
        ContextWindowManager.ContextEstimate before = contextWindows.estimate(messages, availableTools, settings);
        run.recordContextEstimate(before.estimatedInputTokens(), before.contextWindowTokens());
        boolean should = forced || (settings.autoCompactEnabled() && before.estimatedInputTokens() > before.inputLimitTokens());
        if (!should) return;
        ContextWindowManager.CompactionResult result = contextWindows.compact(messages, availableTools, settings, run, forced,
                compactionSummarizer(apiKey, request, model, run));
        if (!result.compacted()) return;
        run.recordCompaction(result.estimatedTokensSaved(), result.reason());
        String extra = pruned > 0 ? "; pruned " + pruned + " older tool output(s)" : "";
        onStep.accept(stepEvent(step, "context_compaction", formatCompaction(result) + extra,
                "success", null, null, null));
    }

    private ContextWindowManager.CompactionSummarizer compactionSummarizer(String apiKey, ChatRequest request,
                                                                              String model,
                                                                              AgentRunService.AgentRun run) {
        String summaryModel = model == null || model.isBlank() ? request.settings().model() : model;
        return (prompt, maxOutputTokens) -> {
            run.checkCancelled();
            int estimatedInput = Math.max(1, (prompt.length() + 3) / 4) + 256;
            OpenAiCompatibleClient.AgentCompletion summary = llm.completeTextWithUsage(
                    apiKey, request.settings().baseUrl(), summaryModel, maxOutputTokens,
                    List.of(Map.of("role", "user", "content", prompt)), run::cancelled);
            run.recordModelUsage(summary.usage(), estimatedInput);
            return summary.content();
        };
    }

    private String formatCompaction(ContextWindowManager.CompactionResult result) {
        ContextWindowManager.ContextEstimate after = result.after();
        return result.reason() + ": saved ~" + result.estimatedTokensSaved() + " active tokens; context now ~" +
                after.estimatedInputTokens() + "/" + after.contextWindowTokens() + " tokens";
    }

    private String tokenUsageDetail(AgentRunService.AgentRun run) {
        long total = run.providerTotalTokens();
        String provider = total > 0
                ? "provider run total " + total + " tokens (input " + run.providerInputTokens() +
                ", output " + run.providerOutputTokens() + ", cached input " + run.cachedInputTokens() + ")"
                : "provider did not report usage; runtime estimates are active";
        return "Context ~" + run.currentContextTokens() + "/" + run.contextWindowTokens() + " tokens; " +
                provider + "; compactions " + run.compactions();
    }

    private ToolExecution executeWithPermission(AgentWorkspaceService.Workspace ws, AgentRunService.AgentRun run,
                                                String tool, JsonNode args, ChatSettings settings, String detail,
                                                int step, Consumer<Map<String, Object>> onStep,
                                                McpManager.Catalog mcpCatalog, List<Map<String,Object>> availableTools,
                                                String apiKey, ChatRequest request) {
        String permission = permissionFor(tool, settings);
        if ("deny".equals(permission)) {
            return new ToolExecution("TOOL DENIED BY PERMISSION: " + tool, "error", false);
        }
        try {
            run.updateProgress(progressForTool(tool, run), phaseForTool(tool), detail);
            if ("ask".equals(permission) && !settings.autoApproveAgent() && !run.isToolApprovedForRun(tool)) {
                AgentApprovalService.Approval approval = approvals.create(run.id(), tool, detail);
                onStep.accept(stepEvent(step, tool, detail, "approval", args, null, approval.id()));
                AgentApprovalService.Decision decision = approvals.await(approval.id(), Duration.ZERO, run);
                if (decision == AgentApprovalService.Decision.DENY) {
                    return new ToolExecution("TOOL DENIED BY USER: " + tool, "error", false);
                }
                if (decision == AgentApprovalService.Decision.RUN) run.approveToolForRun(tool);
                onStep.accept(stepEvent(step, tool, decision == AgentApprovalService.Decision.RUN
                        ? "Allowed for this run — executing tool" : "Approved once — executing tool",
                        "running", args, null, null));
            }
            String result = execute(ws, run, tool, args, settings, mcpCatalog, availableTools, apiKey, request, step, onStep);
            String status = isFailedCommandResult(tool, result) || (tool != null && tool.startsWith("mcp__") && result != null && result.contains("isError=true")) ? "error" : "success";
            return new ToolExecution(result, status, true);
        } catch (AgentCancelledException cancelled) {
            throw cancelled;
        } catch (Exception e) {
            String error = "TOOL ERROR: " + safe(e.getMessage());
            // A verifier that could not even start is still a real verification attempt. Recording it lets the
            // agent distinguish an external execution blocker from an ordinary unverified edit, rather than
            // repeatedly forcing the model back into the same command forever.
            if (isVerifier(tool, args)) run.markVerificationAttempt(false, summarizeResult(tool, error));
            return new ToolExecution(error, "error", false);
        }
    }

    private String execute(AgentWorkspaceService.Workspace ws, AgentRunService.AgentRun run, String tool,
                           JsonNode args, ChatSettings settings, McpManager.Catalog mcpCatalog,
                           List<Map<String,Object>> availableTools, String apiKey, ChatRequest request,
                           int parentStep, Consumer<Map<String,Object>> onStep) throws Exception {
        if (mcp.isMcpTool(mcpCatalog, tool)) return mcp.call(ws.root(), mcpCatalog, tool, args);
        return switch (tool) {
            case "inspect_workspace" -> workspaces.inspectWorkspace(ws);
            case "workspace_profile" -> workspaceProfiles.profileText(ws);
            case "workspace_profile_refresh" -> workspaceProfiles.refresh(ws);
            case "list" -> workspaces.listFiles(ws, firstNonBlank(text(args, "path"), text(args, "prefix")));
            case "glob" -> workspaces.glob(ws, requiredText(args, "pattern"), args.path("maxMatches").asInt(0));
            case "grep" -> args.path("regex").asBoolean(false)
                    ? workspaces.regexSearch(ws, requiredText(args, "pattern"), args.path("maxMatches").asInt(0))
                    : workspaces.search(ws, requiredText(args, "pattern"), args.path("maxMatches").asInt(0));
            case "file_info" -> workspaces.fileInfo(ws, requiredText(args, "path"));
            case "file_index" -> workspaces.fileIndex(ws, requiredText(args, "path"));
            case "read" -> {
                int start = args.path("startLine").asInt(1);
                int end = args.has("endLine") ? args.path("endLine").asInt(Integer.MAX_VALUE) : Integer.MAX_VALUE;
                yield workspaces.readFileRange(ws, requiredText(args, "path"), start, end);
            }
            case "read_chunk" -> workspaces.readFileChunk(ws, requiredText(args, "path"), Math.max(0L, args.path("offsetChars").asLong(0L)), args.path("maxChars").asInt(0));
            case "read_many" -> workspaces.readFiles(ws, stringList(args, "paths"));
            case "instruction_catalog" -> workspaces.instructionCatalog(ws);
            case "instructions_for" -> workspaces.instructionsFor(ws, requiredText(args, "path"));
            case "resource_catalog" -> workspaces.resourceCatalog(ws);
            case "resource_list" -> workspaces.resourceList(ws, requiredText(args, "alias"), text(args, "path"));
            case "resource_info" -> workspaces.resourceFileInfo(ws, requiredText(args, "alias"), text(args, "path"));
            case "resource_index" -> workspaces.resourceIndex(ws, requiredText(args, "alias"), text(args, "path"));
            case "resource_read" -> workspaces.resourceRead(ws, requiredText(args, "alias"), text(args, "path"),
                    args.path("startLine").asInt(1), args.has("endLine") ? args.path("endLine").asInt(Integer.MAX_VALUE) : Integer.MAX_VALUE);
            case "resource_chunk" -> workspaces.resourceReadChunk(ws, requiredText(args, "alias"), text(args, "path"),
                    Math.max(0L, args.path("offsetChars").asLong(0L)), args.path("maxChars").asInt(0));
            case "resource_grep" -> workspaces.resourceGrep(ws, requiredText(args, "alias"), requiredText(args, "pattern"),
                    args.path("regex").asBoolean(false), args.path("maxMatches").asInt(0));
            case "resource_edit" -> workspaces.resourceEdit(ws, requiredText(args, "alias"), requiredText(args, "path"),
                    requiredText(args, "oldText"), text(args, "newText"), args.path("replaceAll").asBoolean(false));
            case "resource_write" -> workspaces.resourceWrite(ws, requiredText(args, "alias"), requiredText(args, "path"), text(args, "content"));
            case "resource_delete" -> workspaces.resourceDelete(ws, requiredText(args, "alias"), requiredText(args, "path"));
            case "resource_copy" -> workspaces.resourceCopy(ws, requiredText(args, "fromAlias"), text(args, "fromPath"), requiredText(args, "toAlias"), requiredText(args, "toPath"), args.path("overwrite").asBoolean(false));
            case "resource_move" -> workspaces.resourceMove(ws, requiredText(args, "fromAlias"), requiredText(args, "fromPath"), requiredText(args, "toAlias"), requiredText(args, "toPath"), args.path("overwrite").asBoolean(false));
            case "resource_build" -> workspaces.resourceBuild(ws, requiredText(args, "alias"), settings.agentCommandsAllowed(), run).asToolText();
            case "resource_test" -> workspaces.resourceTests(ws, requiredText(args, "alias"), settings.agentCommandsAllowed(), run).asToolText();
            case "resource_check" -> workspaces.resourceCheck(ws, requiredText(args, "alias"), settings.agentCommandsAllowed(), run).asToolText();
            case "resource_bash" -> workspaces.resourceCommand(ws, requiredText(args, "alias"), requiredText(args, "command"),
                    Math.max(0L, args.path("timeoutSeconds").asLong(0L)), settings.agentCommandsAllowed(), settings.extraAgentCommands(), run).asToolText();
            case "attachment_list" -> files.attachmentListForAgent(run.conversationId());
            case "attachment_read" -> files.attachmentTextForAgent(run.conversationId(), requiredText(args, "fileId"),
                    Math.max(0, args.path("offset").asInt(0)), args.path("maxChars").asInt(0));
            case "attachment_search" -> files.attachmentSearchForAgent(run.conversationId(), requiredText(args, "query"),
                    text(args, "fileId"), args.path("maxMatches").asInt(0));
            case "skill_catalog" -> workspaces.availableSkills(ws);
            case "skill" -> workspaces.loadSkill(ws, requiredText(args, "name"));
            case "agent_catalog" -> agentProfiles.catalogText(ws);
            case "task" -> runSubagent(ws, run, request, apiKey, mcpCatalog, availableTools,
                    requiredText(args, "agent"), requiredText(args, "prompt"), parentStep, onStep);
            case "mcp_status" -> mcp.status(ws.root());
            case "lsp_status" -> lsp.status(ws.root());
            case "lsp" -> lsp.call(ws.root(), requiredText(args, "operation"), text(args, "path"),
                    Math.max(0, args.path("line").asInt(0)), Math.max(0, args.path("character").asInt(0)),
                    text(args, "query"), text(args, "server"));
            case "edit" -> workspaces.editFile(ws, requiredText(args, "path"), requiredText(args, "oldText"), text(args, "newText"), args.path("replaceAll").asBoolean(false));
            case "write" -> workspaces.writeFile(ws, requiredText(args, "path"), text(args, "content"));
            case "copy" -> workspaces.copyFile(ws, requiredText(args, "from"), requiredText(args, "to"), args.path("overwrite").asBoolean(false));
            case "move" -> workspaces.moveFile(ws, requiredText(args, "from"), requiredText(args, "to"), args.path("overwrite").asBoolean(false));
            case "delete" -> workspaces.deleteFile(ws, requiredText(args, "path"));
            case "apply_patch" -> workspaces.applyPatch(ws, args.path("changes"));
            case "build" -> workspaces.runBuild(ws, text(args, "cwd"), settings.agentCommandsAllowed(), run).asToolText();
            case "test" -> workspaces.runTests(ws, text(args, "cwd"), settings.agentCommandsAllowed(), run).asToolText();
            case "check" -> workspaces.runCheck(ws, text(args, "cwd"), settings.agentCommandsAllowed(), run).asToolText();
            case "bash" -> workspaces.runCommand(ws, requiredText(args, "command"), text(args, "cwd"),
                    settings.agentCommandsAllowed(), settings.extraAgentCommands(),
                    Math.max(0L, args.path("timeoutSeconds").asLong(0L)), run).asToolText();
            case "process_start" -> workspaces.startProcess(ws, requiredText(args, "command"), text(args, "cwd"), settings.agentCommandsAllowed(), run);
            case "process_status" -> workspaces.processStatus(ws, requiredText(args, "processId"));
            case "process_output" -> workspaces.processOutput(ws, requiredText(args, "processId"),
                    Math.max(0L, args.path("offset").asLong(0L)), args.path("maxChars").asInt(0));
            case "process_stop" -> workspaces.stopProcess(ws, requiredText(args, "processId"));
            case "http_request" -> workspaces.httpRequest(firstNonBlank(text(args, "method"), "GET"), requiredText(args, "url"),
                    stringList(args, "headers"), text(args, "body"), args.path("timeoutSeconds").asLong(0), run);
            case "workspace_status" -> workspaces.workspaceStatus(ws);
            case "workspace_diff" -> workspaces.workspaceDiff(ws, text(args, "path"));
            case "todowrite" -> setTodos(run, stringList(args, "items"));
            case "todoread" -> run.planText();
            // Compatibility-only convenience actions from earlier builds.
            case "update_plan" -> updateTodo(run, args);
            default -> throw new IllegalArgumentException("Unknown agent tool: " + tool);
        };
    }

    private JsonNode normalizeLegacyArgs(String requestedTool, String canonicalTool, JsonNode rawArgs) {
        JsonNode args = rawArgs == null || !rawArgs.isObject() ? objectMapper.createObjectNode() : rawArgs.deepCopy();
        if (!(args instanceof com.fasterxml.jackson.databind.node.ObjectNode obj)) return args;
        if ("search_project".equals(requestedTool) && !obj.has("pattern")) obj.set("pattern", obj.path("query"));
        if ("regex_search".equals(requestedTool)) {
            if (!obj.has("pattern")) obj.set("pattern", obj.path("regex"));
            obj.put("regex", true);
        }
        if (("list_project".equals(requestedTool)) && !obj.has("path")) obj.set("path", obj.path("prefix"));
        if ("read_file_range".equals(requestedTool) && !obj.has("endLine")) obj.put("endLine", 200);
        if ("set_plan".equals(requestedTool) && !obj.has("items")) obj.set("items", obj.path("items"));
        return obj;
    }

    private String setTodos(AgentRunService.AgentRun run, List<String> items) {
        run.setPlan(items);
        return "Todos updated:\n" + run.planText();
    }

    private String updateTodo(AgentRunService.AgentRun run, JsonNode args) {
        int index = args == null ? 0 : args.path("index").asInt(0);
        if (index < 1) throw new IllegalArgumentException("Todo index must be >= 1");
        run.updatePlan(index, requiredText(args, "status"), text(args, "note"));
        return "Todos updated:\n" + run.planText();
    }

    private int progressForTool(String tool, AgentRunService.AgentRun run) {
        if (tool == null) return 18;
        if (Set.of("edit", "write", "copy", "move", "delete", "apply_patch", "resource_edit", "resource_write", "resource_delete", "resource_copy", "resource_move").contains(tool)) return 48;
        if (Set.of("build", "test", "check", "resource_build", "resource_test", "resource_check").contains(tool)) return 72;
        if (Set.of("bash", "resource_bash", "process_start", "process_status", "process_output", "process_stop", "http_request").contains(tool)) return run.mutationRevision() > 0 ? 68 : 36;
        if (Set.of("workspace_status", "workspace_diff").contains(tool)) return 84;
        if ("task".equals(tool)) return 30;
        if (tool.startsWith("mcp__") || "lsp".equals(tool) || "lsp_status".equals(tool)) return run.mutationRevision() > 0 ? 64 : 32;
        return run.mutationRevision() > 0 ? 62 : 24;
    }

    private String phaseForTool(String tool) {
        if (tool == null) return "working";
        if (Set.of("edit", "write", "copy", "move", "delete", "apply_patch", "resource_edit", "resource_write", "resource_delete", "resource_copy", "resource_move").contains(tool)) return "editing";
        if (Set.of("build", "test", "check", "resource_build", "resource_test", "resource_check").contains(tool)) return "verifying";
        if (Set.of("bash", "resource_bash", "process_start", "process_status", "process_output", "process_stop", "http_request").contains(tool)) return "executing";
        if (Set.of("workspace_status", "workspace_diff").contains(tool)) return "reviewing";
        if ("task".equals(tool)) return "delegating";
        return "inspecting";
    }

    private void observeRun(AgentRunService.AgentRun run, String tool, JsonNode args, String result) {
        if (isMutationTool(tool)) {
            if (directMutationChanged(result)) {
                run.markMutation(mutationNeedsVerification(tool, args));
                run.updateProgress(56, "editing", "Workspace changes applied");
            } else {
                run.updateProgress(48, "editing", "Requested edit already matched the workspace; no new revision created");
            }
        } else if ("resource_bash".equals(tool) && result != null && result.contains("resourceChanged=true")) {
            run.markMutation(true);
        } else if ("bash".equals(tool) && result != null && result.contains("workspaceChanged=true")) {
            // Shell commands are intentionally unrestricted within the selected workspace and may edit files.
            // Any detected shell mutation creates a new revision that must be verified before completion.
            run.markMutation(true);
        }
        if ("workspace_diff".equals(tool)) run.markDiffReview();
        if (isVerifier(tool, args)) {
            boolean success = result != null && (result.startsWith("exitCode=0;") || httpVerificationSuccess(result));
            run.markVerificationAttempt(success, summarizeResult(tool, result));
            run.updateProgress(success ? 88 : 76, success ? "verified" : "fixing",
                    success ? "Verification passed" : "Verification failed; diagnosing and fixing");
        }
    }

    private boolean isVerifier(String tool, JsonNode args) {
        return Set.of("build", "test", "check", "resource_build", "resource_test", "resource_check").contains(tool)
                || (("bash".equals(tool) || "resource_bash".equals(tool) || "http_request".equals(tool))
                && args != null && args.path("verification").asBoolean(false));
    }

    private boolean looksLikeBlockedFinal(String raw) {
        if (raw == null || raw.isBlank()) return false;
        String low = raw.stripLeading().toLowerCase(Locale.ROOT);
        while (low.startsWith(">")) low = low.substring(1).stripLeading();
        return low.startsWith("blocked:") || low.startsWith("**blocked:**") || low.startsWith("**status: blocked**")
                || low.startsWith("status: blocked");
    }

    private boolean externalVerificationBlocker(String lastVerification) {
        if (lastVerification == null || lastVerification.isBlank()) return false;
        String low = lastVerification.toLowerCase(Locale.ROOT);
        return low.contains("unable to start command")
                || low.contains("cannot run program")
                || low.contains("createprocess error")
                || low.contains("being used by another process")
                || low.contains("sharing violation")
                || low.contains("access is denied")
                || low.contains("permission denied")
                || low.contains("operation not permitted")
                || low.contains("no space left on device")
                || low.contains("not enough storage");
    }

    private boolean httpVerificationSuccess(String result) {
        if (result == null || !result.startsWith("statusCode=")) return false;
        int semi = result.indexOf(';');
        String value = semi < 0 ? result.substring("statusCode=".length()) : result.substring("statusCode=".length(), semi);
        try {
            int code = Integer.parseInt(value.trim());
            return code >= 200 && code < 400;
        } catch (Exception ignored) { return false; }
    }

    private boolean requiresCurrentRevisionVerification(AgentRunService.AgentRun run) {
        return run.verificationRequired();
    }

    private boolean mutationNeedsVerification(String tool, JsonNode args) {
        List<String> paths = new ArrayList<>();
        if (Set.of("edit", "write", "delete", "resource_edit", "resource_write", "resource_delete").contains(tool)) paths.add(text(args, "path"));
        else if (Set.of("resource_copy", "resource_move").contains(tool)) { paths.add(text(args, "fromPath")); paths.add(text(args, "toPath")); }
        else if (Set.of("copy", "move").contains(tool)) { paths.add(text(args, "from")); paths.add(text(args, "to")); }
        else if ("apply_patch".equals(tool) && args != null && args.path("changes").isArray()) {
            for (JsonNode change : args.path("changes")) paths.add(change.path("path").asText(""));
        }
        for (String path : paths) {
            String p = path == null ? "" : path.replace('\\','/').toLowerCase(Locale.ROOT);
            String name = p.substring(p.lastIndexOf('/') + 1);
            if (Set.of("pom.xml", "package.json", "build.gradle", "build.gradle.kts", "settings.gradle", "settings.gradle.kts",
                    "pyproject.toml", "setup.py", "requirements.txt", "go.mod", "cargo.toml", "makefile", "cmakelists.txt",
                    "dockerfile", "compose.yml", "compose.yaml", "application.properties", "application.yml", "application.yaml").contains(name)) return true;
            int dot = name.lastIndexOf('.');
            String ext = dot < 0 ? "" : name.substring(dot + 1);
            if (Set.of("java","kt","kts","groovy","scala","js","jsx","ts","tsx","mjs","cjs","py","rb","php","go","rs",
                    "c","cc","cpp","cxx","h","hpp","cs","fs","swift","dart","vue","svelte","jsp","html","css","scss","less",
                    "xml","json","yaml","yml","toml","properties","gradle","sql","graphql","proto","sh","bash","zsh","ps1","bat","cmd",
                    "tf","hcl","bzl","sbt","ex","exs","clj","cljs","zig","hs","erl").contains(ext)) return true;
        }
        return false;
    }

    private String verificationRequiredPrompt(AgentRunService.AgentRun run) {
        String last = run.lastVerification().isBlank() ? "No verifier has successfully run for this revision yet." :
                "Last verifier: " + run.lastVerification();
        return "The live workspace has changed and the current revision is not successfully verified. " + last + " " +
                "Do not finish as completed yet. Use build/test/check for the primary workspace, resource_build/resource_test/resource_check for an additional project, bash/resource_bash with verification=true, or http_request with verification=true as appropriate. " +
                "If verification fails, inspect the real error, fix the cause, and rerun. Continue until the current revision passes. " +
                "Only return blocked if a genuine external/environment/permission blocker prevents verification.";
    }

    private String permissionFor(String tool, ChatSettings settings) {
        if (tool != null && tool.startsWith("mcp__")) return settings.mcpPermission();
        if ("task".equals(tool)) return settings.taskPermission();
        if ("lsp".equals(tool) || "lsp_status".equals(tool)) return settings.lspPermission();
        if (Set.of("edit", "write", "copy", "move", "delete", "apply_patch", "resource_edit", "resource_write", "resource_delete", "resource_copy", "resource_move").contains(tool)) return settings.editPermission();
        if (Set.of("bash", "build", "test", "check", "resource_bash", "resource_build", "resource_test", "resource_check", "process_start", "process_stop", "http_request").contains(tool)) return settings.shellPermission();
        if (Set.of("workspace_status", "workspace_diff").contains(tool)) return settings.reviewPermission();
        return "allow";
    }

    private String decorateFinalMessage(String message, AgentWorkspaceService.Workspace ws,
                                        List<ProjectPatchRequest.ProjectPatchFile> changes,
                                        AgentRunService.AgentRun run, String status) {
        String result = message == null || message.isBlank() ? "Agent run completed." : message.strip();
        if (!changes.isEmpty()) {
            boolean multiResourceChanges = changes.stream().anyMatch(file -> file.path() != null && file.path().startsWith("@"));
            if (multiResourceChanges) {
                result += "\n\n> Direct resources: " + changes.size() + " file(s) were changed across the primary workspace and explicitly supplied writable resources.";
            } else {
                result += "\n\n> Direct workspace: " + changes.size() + " file(s) were changed directly under `" + ws.root() + "`.";
            }
        }
        if (run.lastVerificationAttemptRevision() >= 0 && !run.lastVerification().isBlank()) {
            result += "\n\n> Last recorded verifier: " + run.lastVerification();
        }
        if (run.modelCalls() > 0) {
            String usage = run.providerTotalTokens() > 0
                    ? run.providerTotalTokens() + " provider-reported tokens"
                    : "provider usage unavailable; runtime context estimates were used";
            result += "\n\n> Agent token management: " + usage + "; " + run.modelCalls() + " model call(s); " +
                    run.compactions() + " context compaction(s); current active context ~" + run.currentContextTokens() +
                    "/" + run.contextWindowTokens() + " tokens.";
        }
        if ("blocked".equals(status) && !result.toLowerCase(Locale.ROOT).contains("blocked")) {
            result = "**Status: Blocked**\n\n" + result;
        }
        return result;
    }

    private void appendNativeAssistantTurn(List<Map<String, Object>> messages,
                                           List<OpenAiCompatibleClient.AgentToolCall> calls,
                                           String assistantContent) {
        List<Map<String, Object>> toolCalls = new ArrayList<>();
        for (OpenAiCompatibleClient.AgentToolCall call : calls) {
            Map<String, Object> function = new LinkedHashMap<>();
            function.put("name", call.name());
            try { function.put("arguments", objectMapper.writeValueAsString(sanitizeHistoricalToolArgs(call.arguments()))); }
            catch (Exception ignored) { function.put("arguments", "{}"); }
            Map<String, Object> item = new LinkedHashMap<>();
            item.put("id", call.id());
            item.put("type", "function");
            item.put("function", function);
            toolCalls.add(item);
        }
        Map<String, Object> assistant = new LinkedHashMap<>();
        assistant.put("role", "assistant");
        if (assistantContent != null && !assistantContent.isBlank()) assistant.put("content", assistantContent);
        assistant.put("tool_calls", toolCalls);
        messages.add(assistant);
    }

    private void appendNativeToolResult(List<Map<String, Object>> messages, String callId, String tool, String result) {
        Map<String, Object> toolResult = new LinkedHashMap<>();
        toolResult.put("role", "tool");
        toolResult.put("tool_call_id", callId);
        toolResult.put("name", tool);
        toolResult.put("content", clip(result));
        messages.add(toolResult);
    }

    private void appendFallbackToolTranscript(List<Map<String, Object>> messages, String raw, String tool, String result) {
        if (raw != null && !raw.isBlank()) messages.add(Map.of("role", "assistant", "content", clipHistoricalAssistant(raw)));
        messages.add(Map.of("role", "user", "content", "TOOL RESULT for " + tool + ":\n" + clip(result) +
                "\n\nContinue the same task. Use another tool if needed, otherwise return the final JSON response."));
    }

    private JsonNode parseEnvelope(String raw) {
        if (raw == null || raw.isBlank()) return null;
        String text = raw.trim();
        if (text.startsWith("```")) {
            int firstNl = text.indexOf('\n'), last = text.lastIndexOf("```");
            if (firstNl >= 0 && last > firstNl) text = text.substring(firstNl + 1, last).trim();
        }
        try { return objectMapper.readTree(text); } catch (Exception ignored) { }
        int start = text.indexOf('{');
        if (start < 0) return null;
        boolean inString = false, escape = false;
        int depth = 0;
        for (int i = start; i < text.length(); i++) {
            char c = text.charAt(i);
            if (inString) {
                if (escape) escape = false;
                else if (c == '\\') escape = true;
                else if (c == '"') inString = false;
                continue;
            }
            if (c == '"') { inString = true; continue; }
            if (c == '{') depth++;
            else if (c == '}' && --depth == 0) {
                try { return objectMapper.readTree(text.substring(start, i + 1)); }
                catch (Exception ignored) { return null; }
            }
        }
        return null;
    }

    private Map<String, Object> stepEvent(int step, String tool, String detail, String status,
                                          JsonNode args, String output, String approvalId) {
        Map<String, Object> event = new LinkedHashMap<>();
        event.put("step", step);
        event.put("tool", tool == null || tool.isBlank() ? "agent" : tool);
        event.put("detail", safe(detail));
        event.put("status", status);
        if (args != null && !args.isMissingNode() && !args.isNull()) event.put("args", args);
        if (output != null && !output.isBlank()) event.put("output", output);
        if (approvalId != null) event.put("approvalId", approvalId);
        return event;
    }

    private String describeTool(String tool, JsonNode args) {
        if (Set.of("read", "read_chunk", "file_info", "file_index", "write", "edit", "delete").contains(tool)) return tool + " " + text(args, "path");
        if (Set.of("move", "copy").contains(tool)) return tool + " " + text(args, "from") + " -> " + text(args, "to");
        if ("apply_patch".equals(tool)) return "Apply direct multi-file workspace change";
        if ("grep".equals(tool)) return "Search workspace for " + text(args, "pattern");
        if ("glob".equals(tool)) return "Glob " + text(args, "pattern");
        if ("bash".equals(tool)) return "Run " + text(args, "command");
        if (tool != null && tool.startsWith("resource_")) {
            String alias = text(args, "alias");
            if (Set.of("resource_read", "resource_chunk", "resource_info", "resource_index", "resource_edit", "resource_write", "resource_delete").contains(tool)) return tool + " @" + alias + "/" + text(args, "path");
            if (Set.of("resource_copy", "resource_move").contains(tool)) return tool + " @" + text(args, "fromAlias") + "/" + text(args, "fromPath") + " -> @" + text(args, "toAlias") + "/" + text(args, "toPath");
            if ("resource_grep".equals(tool)) return "Search @" + alias + " for " + text(args, "pattern");
            if ("resource_bash".equals(tool)) return "Run in @" + alias + ": " + text(args, "command");
            return tool + (alias.isBlank() ? "" : " @" + alias);
        }
        if ("process_start".equals(tool)) return "Start background process: " + text(args, "command");
        if (Set.of("process_status", "process_output", "process_stop").contains(tool)) return tool + " " + text(args, "processId");
        if ("http_request".equals(tool)) return firstNonBlank(text(args, "method"), "GET") + " " + text(args, "url");
        if ("workspace_profile".equals(tool)) return "Read durable workspace profile";
        if ("workspace_profile_refresh".equals(tool)) return "Refresh durable workspace profile";
        if ("instruction_catalog".equals(tool)) return "List project instruction files";
        if ("instructions_for".equals(tool)) return "Load instructions for " + text(args, "path");
        if ("attachment_list".equals(tool)) return "List uploaded conversation attachments";
        if ("attachment_read".equals(tool)) return "Read uploaded attachment " + text(args, "fileId");
        if ("attachment_search".equals(tool)) return "Search attachments for " + text(args, "query");
        if ("skill_catalog".equals(tool)) return "List available skills";
        if ("skill".equals(tool)) return "Load skill " + text(args, "name");
        if ("agent_catalog".equals(tool)) return "List available subagents";
        if ("task".equals(tool)) return "Delegate to " + text(args, "agent") + ": " + text(args, "prompt");
        if ("mcp_status".equals(tool)) return "Inspect MCP server/tool status";
        if (tool != null && tool.startsWith("mcp__")) return "Call external MCP tool " + tool;
        if (Set.of("build", "test", "check").contains(tool)) return tool + " in " + (text(args, "cwd").isBlank() ? "." : text(args, "cwd"));
        return tool;
    }

    private boolean isFailedCommandResult(String tool, String result) {
        if (Set.of("bash", "build", "test", "check", "resource_bash", "resource_build", "resource_test", "resource_check").contains(tool)) {
            return result != null && !result.startsWith("exitCode=0;");
        }
        if ("http_request".equals(tool) && result != null && result.startsWith("statusCode=")) {
            return !httpVerificationSuccess(result);
        }
        return false;
    }

    private boolean isContextWindowFailure(Exception e) {
        String text = (e.getMessage() == null ? "" : e.getMessage()).toLowerCase(Locale.ROOT);
        return text.contains("context length") || text.contains("context window") || text.contains("maximum context") ||
                text.contains("too many tokens") || text.contains("token limit") || text.contains("prompt is too long") ||
                text.contains("input too long");
    }

    private boolean verificationSteeringBlocked(Map<String,Integer> counters, AgentRunService.AgentRun run) {
        String key = run.mutationRevision() + "|" + run.lastVerificationAttemptRevision() + "|" +
                run.lastSuccessfulVerificationRevision() + "|" + Integer.toHexString(run.lastVerification().hashCode());
        int count = counters.merge(key, 1, Integer::sum);
        if (count > 2) {
            run.markRepeatedCallPrevented();
            return true;
        }
        return false;
    }

    private String normalizeNoProgress(String raw) {
        if (raw == null || raw.isBlank()) return "<blank>";
        String normalized = raw.toLowerCase(Locale.ROOT).replaceAll("\\s+", " ").trim();
        if (normalized.length() > 1200) normalized = normalized.substring(0, 1200);
        return normalized;
    }

    private boolean isTransientModelFailure(Exception e) {
        String text = (e.getMessage() == null ? "" : e.getMessage()).toLowerCase(Locale.ROOT);
        return text.contains("429") || text.contains("500") || text.contains("502") || text.contains("503") ||
                text.contains("504") || text.contains("timeout") || text.contains("timed out") ||
                text.contains("connection reset") || text.contains("connection refused") || text.contains("temporarily unavailable");
    }

    private void sleepCancellable(AgentRunService.AgentRun run, long waitMs) throws InterruptedException {
        long deadline = System.nanoTime() + Duration.ofMillis(waitMs).toNanos();
        while (System.nanoTime() < deadline) {
            run.checkCancelled();
            Thread.sleep(Math.min(100L, Math.max(1L, waitMs)));
        }
    }

    private String canonicalArgs(JsonNode args) {
        try { return objectMapper.writeValueAsString(args); }
        catch (Exception ignored) { return String.valueOf(args); }
    }

    private String summarizeResult(String tool, String result) {
        if (result == null || result.isBlank()) return tool + " completed";
        String first = result.replace('\r', ' ').replace('\n', ' ').replaceAll("\\s+", " ").trim();
        return first.length() > 240 ? first.substring(0, 240) + "…" : first;
    }

    private String normalizeFinalStatus(String value) {
        return "blocked".equalsIgnoreCase(value) ? "blocked" : "completed";
    }

    private String requiredText(JsonNode node, String field) {
        String value = text(node, field);
        if (value == null || value.isBlank()) throw new IllegalArgumentException(field + " is required");
        return value;
    }

    private String text(JsonNode node, String field) {
        if (node == null || node.isMissingNode() || node.isNull()) return "";
        JsonNode value = node.path(field);
        return value.isMissingNode() || value.isNull() ? "" : value.asText("");
    }

    private String firstNonBlank(String first, String second) {
        return first != null && !first.isBlank() ? first : second == null ? "" : second;
    }

    private List<String> stringList(JsonNode node, String field) {
        JsonNode arr = node == null ? null : node.path(field);
        if (arr == null || !arr.isArray()) return List.of();
        List<String> out = new ArrayList<>();
        for (JsonNode item : arr) {
            String value = item.asText("").trim();
            if (!value.isBlank()) out.add(value);
        }
        return out;
    }

    /** Bound a single tool result placed back into the model transcript. The full result is still used by the
     * runtime for verification/events; only repeatedly-sent model context is bounded. */
    private String clip(String value) {
        return clipHeadTail(value, 50_000, "[Tool output bounded to 50k characters for active model context. Re-run with a targeted command/read for exact omitted details.]");
    }

    private String clipHistoricalAssistant(String value) {
        return clipHeadTail(value, 12_000, "[Large historical tool envelope bounded after execution; live workspace state is authoritative.]");
    }

    private String clipUi(String value) {
        return clipHeadTail(value, 30_000, "[UI output clipped; the command/tool result itself was processed in full.]");
    }

    private String clipHeadTail(String value, int maxChars, String marker) {
        if (value == null) return "";
        if (value.length() <= maxChars) return value;
        int head = Math.max(500, (int)(maxChars * 0.72));
        int tail = Math.max(250, maxChars - head);
        return value.substring(0, head) + "\n...\n" + marker + "\n...\n" + value.substring(value.length() - tail);
    }

    private JsonNode sanitizeHistoricalToolArgs(JsonNode node) {
        if (node == null || node.isNull() || node.isMissingNode()) return objectMapper.createObjectNode();
        JsonNode copy = node.deepCopy();
        sanitizeHistoricalToolArgsInPlace(copy);
        return copy;
    }

    private void sanitizeHistoricalToolArgsInPlace(JsonNode node) {
        if (node == null) return;
        if (node.isObject()) {
            List<String> names = new ArrayList<>();
            node.fieldNames().forEachRemaining(names::add);
            for (String name : names) {
                JsonNode child = node.get(name);
                if (child != null && child.isTextual() && child.asText().length() > 8_000) {
                    String text = child.asText();
                    String bounded = clipHeadTail(text, 8_000, "[Large tool argument omitted from historical context after execution; length=" + text.length() + "]");
                    ((com.fasterxml.jackson.databind.node.ObjectNode) node).put(name, bounded);
                } else {
                    sanitizeHistoricalToolArgsInPlace(child);
                }
            }
        } else if (node.isArray()) {
            for (JsonNode child : node) sanitizeHistoricalToolArgsInPlace(child);
        }
    }

    private String safe(String value) {
        if (value == null || value.isBlank()) return "Unknown error";
        String clean = value.replace('\u0000', ' ');
        return clean.length() > 1_200 ? clean.substring(0, 1_200) : clean;
    }

    private record PreparedCall(OpenAiCompatibleClient.AgentToolCall call, String requestedTool, String tool, JsonNode args, String detail) {}
    private record ToolExecution(String result, String status, boolean executed) {}
    public record AgentResult(String answer, List<ProjectPatchRequest.ProjectPatchFile> changes) {}
}
