package com.llmart.llm.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.http.HttpClient;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;

import static org.junit.jupiter.api.Assertions.*;

class McpManagerManualConfigTest {

    @TempDir
    Path temp;

    @Test
    void manualConfigPersistsSecretsButNeverReturnsTheirValues() throws Exception {
        String previousHome = System.getProperty("user.home");
        System.setProperty("user.home", temp.toString());
        try {
            McpManager manager = manager();
            manager.saveManualConfiguration("itg-devops", false, "", 100000, Map.of());
            assertFalse(Files.exists(temp.resolve(".eliya/mcp.json")), "Saving unrelated Settings must not create an empty MCP file");

            McpManager.ManualConfigView saved = manager.saveManualConfiguration(
                    "itg-devops", false, "https://devops.example.test/mcp", 100000,
                    Map.of("jira-token", "jira-secret", "user-id", "u123"));

            assertFalse(saved.enabled());
            assertEquals(100000, saved.timeoutMillis());
            assertTrue(saved.configuredHeaders().contains("jira-token"));
            assertTrue(saved.configuredHeaders().contains("user-id"));
            assertFalse(saved.toString().contains("jira-secret"));

            String raw = Files.readString(temp.resolve(".eliya/mcp.json"));
            assertTrue(raw.contains("jira-secret"));
            assertTrue(raw.contains("\"timeout\" : 100000"));

            // Blank/missing secret fields from the Settings UI preserve prior values.
            manager.saveManualConfiguration("itg-devops", false, "https://devops.example.test/mcp", 100000,
                    Map.of("confluence-token", "conf-secret"));
            String merged = Files.readString(temp.resolve(".eliya/mcp.json"));
            assertTrue(merged.contains("jira-secret"));
            assertTrue(merged.contains("conf-secret"));

            manager.clearManualConfiguration();
            assertFalse(Files.exists(temp.resolve(".eliya/mcp.json")));
        } finally {
            if (previousHome == null) System.clearProperty("user.home"); else System.setProperty("user.home", previousHome);
        }
    }

    @Test
    void manualRemoteConfigForwardsHeadersAndFeedsExistingDynamicToolCatalog() throws Exception {
        String previousHome = System.getProperty("user.home");
        System.setProperty("user.home", temp.toString());
        CopyOnWriteArrayList<String> observed = new CopyOnWriteArrayList<>();
        HttpServer server = HttpServer.create(new InetSocketAddress("127.0.0.1", 0), 0);
        ObjectMapper mapper = new ObjectMapper();
        server.createContext("/mcp", exchange -> handle(exchange, mapper, observed));
        server.start();
        try {
            String url = "http://127.0.0.1:" + server.getAddress().getPort() + "/mcp";
            McpManager manager = manager();
            manager.saveManualConfiguration("itg-devops", true, url, 5000,
                    Map.of("jira-token", "jira-secret", "confluence-token", "conf-secret", "user-id", "u123"));

            McpManager.ConnectionTest test = manager.testManualConfiguration();
            assertTrue(test.connected(), test.message());
            assertEquals(1, test.toolCount());
            assertEquals("jira_get_issue", test.tools().get(0));
            assertTrue(observed.stream().anyMatch(v -> v.contains("jira-secret|conf-secret|u123")));

            McpManager.Catalog catalog = manager.catalog(temp);
            assertEquals(1, catalog.definitions().size());
            assertTrue(catalog.byFunction().keySet().stream().anyMatch(name -> name.contains("jira_get_issue")));
            assertTrue(catalog.diagnostics().stream().anyMatch(line -> line.contains("connected; tools=1")));
            manager.shutdown();
        } finally {
            server.stop(0);
            if (previousHome == null) System.clearProperty("user.home"); else System.setProperty("user.home", previousHome);
        }
    }

    private McpManager manager() {
        return new McpManager(new ObjectMapper(), HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(2)).build());
    }

    private static void handle(HttpExchange exchange, ObjectMapper mapper, CopyOnWriteArrayList<String> observed) throws IOException {
        String jira = exchange.getRequestHeaders().getFirst("jira-token");
        String conf = exchange.getRequestHeaders().getFirst("confluence-token");
        String user = exchange.getRequestHeaders().getFirst("user-id");
        observed.add(String.valueOf(jira) + "|" + String.valueOf(conf) + "|" + String.valueOf(user));

        String body = new String(exchange.getRequestBody().readAllBytes(), StandardCharsets.UTF_8);
        JsonNode request = mapper.readTree(body);
        String method = request.path("method").asText("");
        if ("notifications/initialized".equals(method)) {
            exchange.sendResponseHeaders(202, -1);
            exchange.close();
            return;
        }

        String response;
        if ("initialize".equals(method)) {
            response = "{\"jsonrpc\":\"2.0\",\"id\":" + request.path("id").asLong() + ",\"result\":{\"protocolVersion\":\"2025-06-18\",\"capabilities\":{},\"serverInfo\":{\"name\":\"mock\",\"version\":\"1\"}}}";
        } else if ("tools/list".equals(method)) {
            response = "{\"jsonrpc\":\"2.0\",\"id\":" + request.path("id").asLong() + ",\"result\":{\"tools\":[{\"name\":\"jira_get_issue\",\"description\":\"Read a Jira issue\",\"inputSchema\":{\"type\":\"object\",\"properties\":{\"key\":{\"type\":\"string\"}},\"required\":[\"key\"]},\"annotations\":{\"readOnlyHint\":true}}]}}";
        } else {
            response = "{\"jsonrpc\":\"2.0\",\"id\":" + request.path("id").asLong() + ",\"result\":{}}";
        }
        byte[] bytes = response.getBytes(StandardCharsets.UTF_8);
        exchange.getResponseHeaders().set("Content-Type", "application/json");
        exchange.getResponseHeaders().set("Mcp-Session-Id", "test-session");
        exchange.sendResponseHeaders(200, bytes.length);
        exchange.getResponseBody().write(bytes);
        exchange.close();
    }
}
