package com.llmart.llm.controller;

import com.llmart.llm.service.McpManager;
import org.springframework.web.bind.annotation.*;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Manual user-level MCP configuration for ELIYA. The agent itself continues to consume MCP
 * exclusively through McpManager, so configuring a server here immediately feeds the existing
 * dynamic tool discovery/execution path without adding Jira/Confluence-specific code.
 */
@RestController
@RequestMapping("/api/mcp")
public class McpController {
    private final McpManager mcp;

    public McpController(McpManager mcp) {
        this.mcp = mcp;
    }

    @GetMapping("/config")
    public McpManager.ManualConfigView config() {
        return mcp.manualConfiguration();
    }

    @PostMapping("/config")
    public McpManager.ManualConfigView save(@RequestBody ManualMcpRequest request) {
        if (request == null) throw new IllegalArgumentException("MCP configuration is required");
        Map<String,String> headers = request.headers() == null ? Map.of() : new LinkedHashMap<>(request.headers());
        return mcp.saveManualConfiguration(request.name(), request.enabled(), request.url(), request.timeoutMillis(), headers);
    }

    @DeleteMapping("/config")
    public Map<String,Object> clear() {
        mcp.clearManualConfiguration();
        return Map.of("cleared", true);
    }

    @PostMapping("/test")
    public McpManager.ConnectionTest test() {
        return mcp.testManualConfiguration();
    }

    public record ManualMcpRequest(String name, boolean enabled, String url, long timeoutMillis,
                                   Map<String,String> headers) {}
}
