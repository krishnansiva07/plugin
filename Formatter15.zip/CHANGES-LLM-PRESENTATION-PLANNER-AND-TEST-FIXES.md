# LLM Presentation Planner + Regression Fixes

## Why this change

The previous PowerPoint path accepted LLM layout hints, but Java still inferred many visual decisions after the content was generated. That could produce technically valid slides with visually inappropriate cards/boxes. The browser preview could also show duplicate checklist markers when the LLM returned checkbox glyphs inside list items.

This build makes the LLM a first-class presentation planner while keeping Java as the deterministic renderer and safety validator.

## New LLM presentation-planning role

For `POWERPOINT`, the LangGraph ANALYZE node now requests a strict JSON presentation plan containing, per planned slide:

- slide purpose
- predefined BNP-green layout
- native chart type or `NONE`
- diagram type or `NONE`
- content strategy for the chosen visual
- design reason

The CREATE node receives this plan and is explicitly told to follow it. It may select a different supported layout only when the current source chunk makes the planned visual impossible. The REVIEW node validates visual suitability and structure, not only wording.

A malformed PowerPoint planner response gets one bounded semantic JSON-repair request. Network/service failures continue to use the existing LLM client retry policy (10 total network attempts) before the resilient local fallback is used.

The UI workflow activity now identifies the path as `LLM Presentation Planner` for PowerPoint generation.

## Visual-selection rules

- Charts require real source-backed numeric data.
- Diagrams require source-backed relationships/sequence/branching/hierarchy/etc.
- Cards are used only for genuine peer groups, not simply because the generated HTML contains 3 or 4 subheadings.
- Java still validates the LLM choice and can fall back safely if a chart/diagram/layout is structurally incompatible.
- No source facts are invented to make a selected visual work.

## Duplicate checklist/box marker fix

PowerPoint list items are normalized before preview/export. Leading decorative glyphs such as `□`, `☐`, `☑`, `✅`, `✓` and `•` are removed from the LLM text because Java owns the actual checklist/list marker.

This prevents output such as:

`• □ Java 17+ installed`

and preserves only one visual marker.

The PowerPoint prompt and review prompt also prohibit embedded checkbox/bullet glyphs in `<li>` text.

## Unwanted cards/boxes fix

Java no longer converts ordinary H3 subsections into `TWO_COLUMN`, `THREE_CARDS` or `FOUR_CARDS` merely from subsection count.

When no explicit LLM card design exists, subsection content is preserved as normal BNP-green bullets. Card layouts remain available when the LLM intentionally selects them.

## Confluence table regression fix

HTML parsers can auto-wrap `<tr>` elements in `<tbody>`. Previously this left a `<th>` header row inside `<tbody>`, causing a 12-row data table to be counted as 13 rows.

Canonical Confluence normalization now promotes the first `<th>` row from either direct table rows or an existing tbody into `<thead>`.

This addresses the failures in:

- `ExportServiceHtmlTest.confluenceApiExportUsesProvidedCanonicalHtmlWithoutDroppingRows`
- Confluence canonicalization tests in `FreeformDocumentRendererTest`

## Native PowerPoint chart registration fix

Charts now use:

`XMLSlideShow.createChart(XSLFSlide)`

so the chart is registered with the slideshow and appears through `XMLSlideShow#getCharts()`. The generated graphic frame is then anchored to the BNP-green chart region.

This addresses `ExportServicePowerPointTest.numericContentCanSelectNativeChartWhenLlmLayoutMetadataIsMissing`.

## New regression coverage

Added coverage for:

- PowerPoint LLM structured planner usage
- planner JSON semantic repair
- planner design metadata reaching CREATE
- duplicate checklist marker normalization
- duplicate checklist marker removal in PPTX
- ordinary subsections not automatically becoming card boxes
- existing Confluence table header/data-row preservation
- existing chart inference/registration

## Fallback behavior

When the LLM is unavailable after its configured retries, the PowerPoint fallback now emits an explicit `data-layout="BULLETS"` instead of leaving the renderer to guess a design. The activity message clearly identifies the resilient fallback.
