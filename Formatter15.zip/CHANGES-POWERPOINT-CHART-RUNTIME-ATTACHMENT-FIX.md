# PowerPoint Chart Runtime Attachment Fix

## Problem
PowerPoint export could fail at runtime with:

`PowerPoint chart frame was not attached to the slide.`

The exporter called `XMLSlideShow.createChart(slide)` and then immediately scanned
`slide.getShapes()` to rediscover an `XSLFGraphicFrame`. That immediate shape-tree
lookup is not a reliable attachment verification path.

## Fix
- Create the chart part with `XMLSlideShow.createChart()`.
- Attach it explicitly with `XSLFSlide.addChart(chart, anchor)`.
- Configure the chart only after it has been attached.
- Removed the immediate `slide.getShapes()` chart-frame rediscovery and the
  associated fatal exception.
- Added a non-fatal chart fallback: if the local native chart path throws at
  runtime, preserve the same source table on the slide in BNP-green styling
  instead of aborting the whole PPTX export.

## Behaviour
- Supported numeric content still produces native, editable PowerPoint charts.
- A chart rendering problem affects only the visual enhancement for that slide.
- The presentation export continues and preserves the supplied data.
- LLM presentation planning, BNP-green layouts, diagrams, Confluence rendering,
  and the 10-attempt LLM retry policy are unchanged.

## Validation in this build environment
- Confirmed the project targets Apache POI 5.5.1.
- Confirmed the POI API exposes `XSLFSheet.addChart(XSLFChart, Rectangle2D)`.
- Removed all runtime references to the old fatal chart-frame error message.
- ZIP integrity checked after packaging.

Full Maven execution still requires a Maven-enabled environment with dependency
access; this sandbox has Java but no Maven installation and no outbound DNS for
Maven artifact resolution.
