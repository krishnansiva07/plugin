package com.formatflow.ai.service;

import com.formatflow.ai.model.FormatModels.*;
import org.apache.poi.xslf.usermodel.XMLSlideShow;
import org.apache.poi.xslf.usermodel.XSLFTextShape;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayInputStream;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

class ExportServicePowerPointTest {

    @Test
    void powerpointExportUsesGeneratedHtmlAsSlideOutline() throws Exception {
        IconCatalog icons = new IconCatalog();
        DocumentRenderer renderer = new DocumentRenderer(icons);
        ExportService service = new ExportService(renderer, icons, new PdfFontResolver());
        FormattedDocument document = new FormattedDocument(
                "",
                List.of(),
                List.of(),
                "Overview\nCapability one\nCapability two",
                "Technical Team",
                "Knowledge Sharing",
                "POWERPOINT",
                "FORMAT",
                true,
                ""
        );
        String html = """
                <h1>Automation Formatter</h1>
                <h2>📌 Overview</h2>
                <ul><li>Converts content into presentation-ready slides</li><li>Keeps the structure concise</li></ul>
                <h2>📊 Capability Matrix</h2>
                <table><tr><th>Area</th><th>Value</th></tr><tr><td>Confluence</td><td>Rich copy</td></tr></table>
                """;

        ExportService.ExportedFile file = service.export(new ExportRequest(document, "POWERPOINT", "formatter", html));

        assertThat(file.filename()).isEqualTo("formatter.pptx");
        assertThat(file.contentType()).isEqualTo("application/vnd.openxmlformats-officedocument.presentationml.presentation");
        assertThat(file.bytes().length).isGreaterThan(2500);
        try (XMLSlideShow ppt = new XMLSlideShow(new ByteArrayInputStream(file.bytes()))) {
            assertThat(ppt.getSlides().size()).isGreaterThanOrEqualTo(3);
        }
    }

    @Test
    void powerpointExportAddsAgendaAndSplitsProfessionalLayouts() throws Exception {
        IconCatalog icons = new IconCatalog();
        DocumentRenderer renderer = new DocumentRenderer(icons);
        ExportService service = new ExportService(renderer, icons, new PdfFontResolver());
        FormattedDocument document = new FormattedDocument(
                "",
                List.of(),
                List.of(),
                "Large presentation source",
                "Technical Team",
                "Knowledge Sharing",
                "POWERPOINT",
                "FORMAT",
                true,
                ""
        );
        String html = """
                <h1>Automation Platform Overview</h1>
                <h2>📌 Executive Message</h2><blockquote>One platform improves formatting consistency across channels.</blockquote>
                <h2>📋 Capabilities</h2><h3>Confluence</h3><ul><li>Rich copy</li><li>Topic icons</li></ul><h3>Email</h3><ul><li>Outlook-ready HTML</li><li>Concise body</li></ul>
                <h2>🔄 Workflow</h2><ol><li>Analyze source</li><li>Create slide plan</li><li>Review quality</li><li>Export deck</li></ol>
                <h2>📊 Comparison</h2><table><tr><th>Output</th><th>Strength</th></tr><tr><td>PPT</td><td>Native slides</td></tr><tr><td>HTML</td><td>Rich web view</td></tr></table>
                <h2>⚠️ Quality Controls</h2><ul><li>Missing topics are flagged</li><li>Long slide text is repaired</li></ul>
                <h2>🚀 Next Steps</h2><ul><li>Validate with real content</li><li>Share feedback</li></ul>
                """;

        ExportService.ExportedFile file = service.export(new ExportRequest(document, "POWERPOINT", "platform", html));

        try (XMLSlideShow ppt = new XMLSlideShow(new ByteArrayInputStream(file.bytes()))) {
            assertThat(ppt.getSlides().size()).isGreaterThanOrEqualTo(8); // title + auto agenda + six source slides
        }
    }

    @Test
    void powerpointPaginationPreservesBulletsTableRowsAndColumns() throws Exception {
        IconCatalog icons = new IconCatalog();
        DocumentRenderer renderer = new DocumentRenderer(icons);
        ExportService service = new ExportService(renderer, icons, new PdfFontResolver());
        FormattedDocument document = new FormattedDocument(
                "", List.of(), List.of(), "Lossless presentation source",
                "Technical Team", "Knowledge Sharing", "POWERPOINT", "FORMAT", true, ""
        );

        StringBuilder html = new StringBuilder("<h1>Lossless Deck</h1><h2>📌 Detailed Coverage</h2><ul>");
        for (int i = 1; i <= 13; i++) html.append("<li>UNIQUE_BULLET_").append(i).append("</li>");
        html.append("</ul><h2>📊 Wide Data</h2><table><tr>");
        for (int c = 1; c <= 7; c++) html.append("<th>HEADER_").append(c).append("</th>");
        html.append("</tr>");
        for (int r = 1; r <= 14; r++) {
            html.append("<tr>");
            for (int c = 1; c <= 7; c++) html.append("<td>CELL_").append(r).append('_').append(c).append("</td>");
            html.append("</tr>");
        }
        html.append("</table>");

        ExportService.ExportedFile file = service.export(new ExportRequest(
                document, "POWERPOINT", "lossless", html.toString()));

        try (XMLSlideShow ppt = new XMLSlideShow(new ByteArrayInputStream(file.bytes()))) {
            String allText = ppt.getSlides().stream()
                    .flatMap(slide -> slide.getShapes().stream())
                    .filter(XSLFTextShape.class::isInstance)
                    .map(XSLFTextShape.class::cast)
                    .map(XSLFTextShape::getText)
                    .reduce("", (a, b) -> a + "\n" + b);

            for (int i = 1; i <= 13; i++) assertThat(allText).contains("UNIQUE_BULLET_" + i);
            for (int c = 1; c <= 7; c++) assertThat(allText).contains("HEADER_" + c);
            assertThat(allText).contains("CELL_14_7");
            assertThat(ppt.getSlides().size()).isGreaterThan(5);
        }
    }

    @Test
    void predefinedBnpLayoutsDriveCardsProcessChecklistAndCode() throws Exception {
        IconCatalog icons = new IconCatalog();
        DocumentRenderer renderer = new DocumentRenderer(icons);
        ExportService service = new ExportService(renderer, icons, new PdfFontResolver());
        FormattedDocument document = new FormattedDocument(
                "", List.of(), List.of(), "BNP layout catalog",
                "Technical Team", "Knowledge Sharing", "POWERPOINT", "FORMAT", true, ""
        );
        String html = """
                <h1>Automation Framework</h1>
                <h2 data-layout="THREE_CARDS">UI Guide – Key Configuration Areas</h2>
                <h3>LLM configuration</h3><ul><li>Base URL</li><li>Model</li></ul>
                <h3>Browser options</h3><ul><li>Custom zoom</li><li>Headless toggle</li></ul>
                <h3>Execution</h3><ul><li>Shared sessions</li><li>Parallel pool</li></ul>
                <h2 data-layout="PROCESS_5">Agentic Step &amp; Self-Healing</h2>
                <ol><li>Plan</li><li>Execute</li><li>Validate</li><li>Heal</li><li>Report</li></ol>
                <h2 data-layout="CHECKLIST">Quick-Start Checklist</h2>
                <ul><li>Start framework JAR</li><li>Select worksheet</li><li>Configure LLM</li><li>Select execution mode</li></ul>
                <h2 data-layout="CODE">Preparing Test Scenarios – JSON Format</h2>
                <pre><code>{
  "id": "LOGIN-001",
  "username": "test.user"
}</code></pre>
                """;

        ExportService.ExportedFile file = service.export(new ExportRequest(document, "POWERPOINT", "bnp-layouts", html));

        try (XMLSlideShow ppt = new XMLSlideShow(new ByteArrayInputStream(file.bytes()))) {
            String allText = ppt.getSlides().stream()
                    .flatMap(slide -> slide.getShapes().stream())
                    .filter(XSLFTextShape.class::isInstance)
                    .map(XSLFTextShape.class::cast)
                    .map(XSLFTextShape::getText)
                    .reduce("", (a, b) -> a + "\n" + b);
            assertThat(allText).contains("LLM configuration").contains("Browser options").contains("Execution");
            assertThat(allText).contains("Plan").contains("Heal").contains("Quick-Start Checklist");
            assertThat(allText).contains("LOGIN-001").contains("test.user");
            assertThat(ppt.getSlides().size()).isGreaterThanOrEqualTo(5);
        }
    }

    @Test
    void nativePowerPointChartsUseContentSelectedChartTypes() throws Exception {
        IconCatalog icons = new IconCatalog();
        DocumentRenderer renderer = new DocumentRenderer(icons);
        ExportService service = new ExportService(renderer, icons, new PdfFontResolver());
        FormattedDocument document = new FormattedDocument(
                "", List.of(), List.of(), "Native chart catalog",
                "Technical Team", "Knowledge Sharing", "POWERPOINT", "FORMAT", true, ""
        );
        String html = """
                <h1>Native PowerPoint Chart Catalog</h1>
                <h2 data-layout="CHART" data-chart="COLUMN">Execution results by suite</h2>
                <table><tr><th>Suite</th><th>Passed</th></tr><tr><td>Smoke</td><td>96</td></tr><tr><td>Sanity</td><td>88</td></tr><tr><td>Regression</td><td>74</td></tr></table>
                <h2 data-layout="CHART" data-chart="BAR">Defects ranked by module</h2>
                <table><tr><th>Module</th><th>Defects</th></tr><tr><td>Payments</td><td>14</td></tr><tr><td>Login</td><td>9</td></tr><tr><td>Reports</td><td>7</td></tr></table>
                <h2 data-layout="CHART" data-chart="LINE">Pass rate trend</h2>
                <table><tr><th>Month</th><th>Pass rate</th></tr><tr><td>Jan</td><td>81%</td></tr><tr><td>Feb</td><td>87%</td></tr><tr><td>Mar</td><td>92%</td></tr></table>
                <h2 data-layout="CHART" data-chart="AREA">Execution volume over time</h2>
                <table><tr><th>Quarter</th><th>Tests</th></tr><tr><td>Q1</td><td>420</td></tr><tr><td>Q2</td><td>620</td></tr><tr><td>Q3</td><td>810</td></tr></table>
                <h2 data-layout="CHART" data-chart="PIE">Defect share</h2>
                <table><tr><th>Severity</th><th>Share</th></tr><tr><td>Critical</td><td>10</td></tr><tr><td>High</td><td>25</td></tr><tr><td>Medium</td><td>40</td></tr><tr><td>Low</td><td>25</td></tr></table>
                <h2 data-layout="CHART" data-chart="DOUGHNUT">Automation mix</h2>
                <table><tr><th>Type</th><th>Cases</th></tr><tr><td>UI</td><td>45</td></tr><tr><td>API</td><td>35</td></tr><tr><td>Data</td><td>20</td></tr></table>
                <h2 data-layout="CHART" data-chart="SCATTER">Execution time vs test count</h2>
                <table><tr><th>Test count</th><th>Minutes</th></tr><tr><td>100</td><td>11</td></tr><tr><td>250</td><td>19</td></tr><tr><td>500</td><td>34</td></tr></table>
                <h2 data-layout="CHART" data-chart="RADAR">Capability maturity profile</h2>
                <table><tr><th>Dimension</th><th>Score</th></tr><tr><td>Coverage</td><td>4</td></tr><tr><td>Speed</td><td>3</td></tr><tr><td>Resilience</td><td>5</td></tr><tr><td>Maintainability</td><td>4</td></tr></table>
                """;

        ExportService.ExportedFile file = service.export(new ExportRequest(document, "POWERPOINT", "native-charts", html));

        try (XMLSlideShow ppt = new XMLSlideShow(new ByteArrayInputStream(file.bytes()))) {
            assertThat(ppt.getCharts()).hasSize(8);
            String chartXml = ppt.getCharts().stream()
                    .map(chart -> chart.getCTChartSpace().xmlText())
                    .reduce("", (a, b) -> a + "\n" + b);
            assertThat(chartXml).contains("barChart").contains("lineChart").contains("areaChart")
                    .contains("pieChart").contains("doughnutChart").contains("scatterChart").contains("radarChart");
            assertThat(chartXml).contains("barDir"); // COLUMN and BAR share OOXML barChart with different directions.
        }
    }

    @Test
    void chartPaginationPreservesAllNumericCategoriesAndUsesContinuationCharts() throws Exception {
        IconCatalog icons = new IconCatalog();
        DocumentRenderer renderer = new DocumentRenderer(icons);
        ExportService service = new ExportService(renderer, icons, new PdfFontResolver());
        FormattedDocument document = new FormattedDocument(
                "", List.of(), List.of(), "Large chart source",
                "Technical Team", "Knowledge Sharing", "POWERPOINT", "FORMAT", true, ""
        );
        StringBuilder html = new StringBuilder("<h1>Large Chart</h1><h2 data-layout=\"CHART\" data-chart=\"BAR\">Ranked execution volume</h2><table><tr><th>Suite</th><th>Runs</th></tr>");
        for (int i = 1; i <= 15; i++) {
            html.append("<tr><td>CATEGORY_").append(i).append("</td><td>").append(i * 10).append("</td></tr>");
        }
        html.append("</table>");

        ExportService.ExportedFile file = service.export(new ExportRequest(document, "POWERPOINT", "chart-pagination", html.toString()));

        try (XMLSlideShow ppt = new XMLSlideShow(new ByteArrayInputStream(file.bytes()))) {
            assertThat(ppt.getCharts().size()).isGreaterThanOrEqualTo(2);
            String chartXml = ppt.getCharts().stream()
                    .map(chart -> chart.getCTChartSpace().xmlText())
                    .reduce("", (a, b) -> a + "\n" + b);
            assertThat(chartXml).contains("CATEGORY_1").contains("CATEGORY_15");
            String allText = ppt.getSlides().stream()
                    .flatMap(slide -> slide.getShapes().stream())
                    .filter(XSLFTextShape.class::isInstance)
                    .map(XSLFTextShape.class::cast)
                    .map(XSLFTextShape::getText)
                    .reduce("", (a, b) -> a + "\n" + b);
            assertThat(allText).contains("Ranked execution volume (continued)");
        }
    }

    @Test
    void invalidChartRequestFallsBackWithoutDroppingSubsectionContent() throws Exception {
        IconCatalog icons = new IconCatalog();
        DocumentRenderer renderer = new DocumentRenderer(icons);
        ExportService service = new ExportService(renderer, icons, new PdfFontResolver());
        FormattedDocument document = new FormattedDocument(
                "", List.of(), List.of(), "Invalid chart fallback",
                "Technical Team", "Knowledge Sharing", "POWERPOINT", "FORMAT", true, ""
        );
        String html = """
                <h1>Fallback</h1>
                <h2 data-layout="CHART" data-chart="COLUMN">Configuration details</h2>
                <h3>Browser</h3><ul><li>Headless toggle</li><li>Zoom selection</li></ul>
                <h3>Execution</h3><ul><li>Shared session</li><li>Parallel pool</li></ul>
                """;

        ExportService.ExportedFile file = service.export(new ExportRequest(document, "POWERPOINT", "chart-fallback", html));

        try (XMLSlideShow ppt = new XMLSlideShow(new ByteArrayInputStream(file.bytes()))) {
            assertThat(ppt.getCharts()).isEmpty();
            String allText = ppt.getSlides().stream()
                    .flatMap(slide -> slide.getShapes().stream())
                    .filter(XSLFTextShape.class::isInstance)
                    .map(XSLFTextShape.class::cast)
                    .map(XSLFTextShape::getText)
                    .reduce("", (a, b) -> a + "\n" + b);
            assertThat(allText).contains("Browser").contains("Headless toggle").contains("Execution").contains("Parallel pool");
        }
    }

    @Test
    void numericContentCanSelectNativeChartWhenLlmLayoutMetadataIsMissing() throws Exception {
        IconCatalog icons = new IconCatalog();
        DocumentRenderer renderer = new DocumentRenderer(icons);
        ExportService service = new ExportService(renderer, icons, new PdfFontResolver());
        FormattedDocument document = new FormattedDocument(
                "", List.of(), List.of(), "Chart inference fallback",
                "Technical Team", "Knowledge Sharing", "POWERPOINT", "FORMAT", true, ""
        );
        String html = """
                <h1>Fallback Chart Selection</h1>
                <h2>Monthly execution trend</h2>
                <table><tr><th>Month</th><th>Executions</th></tr><tr><td>Jan</td><td>100</td></tr><tr><td>Feb</td><td>135</td></tr><tr><td>Mar</td><td>162</td></tr></table>
                """;

        ExportService.ExportedFile file = service.export(new ExportRequest(document, "POWERPOINT", "chart-inference", html));

        try (XMLSlideShow ppt = new XMLSlideShow(new ByteArrayInputStream(file.bytes()))) {
            assertThat(ppt.getCharts()).hasSize(1);
            assertThat(ppt.getCharts().get(0).getCTChartSpace().xmlText()).contains("lineChart");
        }
    }

    @Test
    void nativePowerPointDiagramCatalogRendersPhaseOneAndTwoTypes() throws Exception {
        IconCatalog icons = new IconCatalog();
        DocumentRenderer renderer = new DocumentRenderer(icons);
        ExportService service = new ExportService(renderer, icons, new PdfFontResolver());
        FormattedDocument document = new FormattedDocument(
                "", List.of(), List.of(), "Native diagram catalog",
                "Technical Team", "Knowledge Sharing", "POWERPOINT", "FORMAT", true, ""
        );
        String html = """
                <h1>BNP Green Diagram Catalog</h1>
                <h2 data-layout="DIAGRAM" data-diagram="LINEAR_PROCESS">Linear process</h2><ol><li>Capture</li><li>Analyze</li><li>Execute</li><li>Report</li></ol>
                <h2 data-layout="DIAGRAM" data-diagram="CHEVRON_PROCESS">Delivery phases</h2><ol><li>Discover</li><li>Design</li><li>Build</li><li>Validate</li></ol>
                <h2 data-layout="DIAGRAM" data-diagram="CYCLE">Continuous lifecycle</h2><ol><li>Plan</li><li>Run</li><li>Measure</li><li>Improve</li></ol>
                <h2 data-layout="DIAGRAM" data-diagram="SWIMLANE">Execution handoffs</h2><h3>Framework</h3><ul><li>Plan</li><li>Prepare</li></ul><h3>Browser</h3><ul><li>Execute</li></ul><h3>Validation</h3><ul><li>Compare</li><li>Report</li></ul>
                <h2 data-layout="DIAGRAM" data-diagram="HIERARCHY">Framework hierarchy</h2><p>Automation Platform</p><h3>UI</h3><ul><li>Web</li><li>Mobile</li></ul><h3>API</h3><ul><li>REST</li></ul><h3>Data</h3><ul><li>Kafka</li></ul>
                <h2 data-layout="DIAGRAM" data-diagram="HUB_SPOKE">Integration ecosystem</h2><p>Test Platform</p><ul><li>Jenkins</li><li>GitHub</li><li>BrowserStack</li><li>Confluence</li></ul>
                <h2 data-layout="DIAGRAM" data-diagram="PIPELINE">Data pipeline</h2><ol><li>JSON</li><li>Kafka</li><li>Flink</li><li>Elasticsearch</li><li>API</li></ol>
                <h2 data-layout="DIAGRAM" data-diagram="ARCHITECTURE_FLOW">System architecture</h2><ol><li>Client</li><li>Gateway</li><li>Service</li><li>Database</li><li>Monitoring</li></ol>
                <h2 data-layout="DIAGRAM" data-diagram="FUNNEL">Quality funnel</h2><ol><li>All tests</li><li>Eligible</li><li>Stable</li><li>Smoke pack</li></ol>
                <h2 data-layout="DIAGRAM" data-diagram="PYRAMID">Maturity levels</h2><ol><li>Foundation</li><li>Standardized</li><li>Optimized</li><li>Autonomous</li></ol>
                <h2 data-layout="DIAGRAM" data-diagram="MATRIX_2X2">Automation quadrant</h2><h3>Quick wins</h3><ul><li>High value</li></ul><h3>Strategic</h3><ul><li>High complexity</li></ul><h3>Maintain</h3><ul><li>Low effort</li></ul><h3>Avoid</h3><ul><li>Low value</li></ul>
                <h2 data-layout="DIAGRAM" data-diagram="DECISION_TREE">Execution decision tree</h2><p>Environment ready?</p><h3>Yes</h3><ul><li>Execute tests</li></ul><h3>No</h3><ul><li>Repair environment</li></ul>
                <h2 data-layout="DIAGRAM" data-diagram="FEEDBACK_LOOP">Self-healing loop</h2><ol><li>Execute</li><li>Detect failure</li><li>Heal locator</li><li>Retry</li><li>Learn</li></ol>
                <h2 data-layout="DIAGRAM" data-diagram="CONVERGING_FLOW">Evidence convergence</h2><ol><li>Logs</li><li>Screenshots</li><li>Metrics</li><li>Unified report</li></ol>
                <h2 data-layout="DIAGRAM" data-diagram="DIVERGING_FLOW">Result distribution</h2><ol><li>Execution result</li><li>Email</li><li>Confluence</li><li>Dashboard</li></ol>
                <h2 data-layout="DIAGRAM" data-diagram="BEFORE_AFTER">Framework transformation</h2><h3>Before</h3><ul><li>Manual locator updates</li><li>Static reports</li></ul><h3>After</h3><ul><li>Self-healing</li><li>Adaptive reports</li></ul>
                <h2 data-layout="DIAGRAM" data-diagram="COMPARISON_FLOW">Execution mode comparison flow</h2><h3>Sequential</h3><ul><li>Start browser</li><li>Run tests</li><li>Close</li></ul><h3>Parallel</h3><ul><li>Create pool</li><li>Distribute tests</li><li>Aggregate</li></ul>
                <h2 data-layout="DIAGRAM" data-diagram="ROADMAP">Delivery roadmap</h2><ol><li>Foundation</li><li>Layouts</li><li>Charts</li><li>Diagrams</li><li>Validation</li></ol>
                """;

        ExportService.ExportedFile file = service.export(new ExportRequest(document, "POWERPOINT", "diagram-catalog", html));

        try (XMLSlideShow ppt = new XMLSlideShow(new ByteArrayInputStream(file.bytes()))) {
            String allText = ppt.getSlides().stream()
                    .flatMap(slide -> slide.getShapes().stream())
                    .filter(XSLFTextShape.class::isInstance)
                    .map(XSLFTextShape.class::cast)
                    .map(XSLFTextShape::getText)
                    .reduce("", (a, b) -> a + "\n" + b);
            assertThat(allText).contains("Capture").contains("Framework").contains("BrowserStack")
                    .contains("Elasticsearch").contains("Quick wins").contains("Environment ready?")
                    .contains("Unified report").contains("Self-healing").contains("Delivery roadmap");
            assertThat(ppt.getSlides().size()).isGreaterThanOrEqualTo(19);
            assertThat(ppt.getSlides().stream().mapToInt(slide -> slide.getShapes().size()).sum()).isGreaterThan(120);
        }
    }

    @Test
    void diagramPaginationPreservesOverflowAndCreatesContinuationSlides() throws Exception {
        IconCatalog icons = new IconCatalog();
        DocumentRenderer renderer = new DocumentRenderer(icons);
        ExportService service = new ExportService(renderer, icons, new PdfFontResolver());
        FormattedDocument document = new FormattedDocument(
                "", List.of(), List.of(), "Large diagram source",
                "Technical Team", "Knowledge Sharing", "POWERPOINT", "FORMAT", true, ""
        );
        StringBuilder html = new StringBuilder("<h1>Large Diagram</h1><h2 data-layout=\"DIAGRAM\" data-diagram=\"LINEAR_PROCESS\">Large workflow</h2><ol>");
        for (int i = 1; i <= 11; i++) html.append("<li>DIAGRAM_STEP_").append(i).append("</li>");
        html.append("</ol>");

        ExportService.ExportedFile file = service.export(new ExportRequest(document, "POWERPOINT", "diagram-pagination", html.toString()));

        try (XMLSlideShow ppt = new XMLSlideShow(new ByteArrayInputStream(file.bytes()))) {
            String allText = ppt.getSlides().stream()
                    .flatMap(slide -> slide.getShapes().stream())
                    .filter(XSLFTextShape.class::isInstance)
                    .map(XSLFTextShape.class::cast)
                    .map(XSLFTextShape::getText)
                    .reduce("", (a, b) -> a + "\n" + b);
            assertThat(allText).contains("DIAGRAM_STEP_1").contains("DIAGRAM_STEP_11")
                    .contains("Large workflow (continued)");
            assertThat(ppt.getSlides().size()).isGreaterThanOrEqualTo(3);
        }
    }

    @Test
    void diagramCanBeInferredFromTitleWhenLlmMetadataIsMissing() throws Exception {
        IconCatalog icons = new IconCatalog();
        DocumentRenderer renderer = new DocumentRenderer(icons);
        ExportService service = new ExportService(renderer, icons, new PdfFontResolver());
        FormattedDocument document = new FormattedDocument(
                "", List.of(), List.of(), "Architecture inference",
                "Technical Team", "Knowledge Sharing", "POWERPOINT", "FORMAT", true, ""
        );
        String html = """
                <h1>Architecture</h1>
                <h2>System architecture flow</h2>
                <ol><li>Client</li><li>API Gateway</li><li>Service</li><li>Database</li></ol>
                """;

        ExportService.ExportedFile file = service.export(new ExportRequest(document, "POWERPOINT", "diagram-inference", html));
        try (XMLSlideShow ppt = new XMLSlideShow(new ByteArrayInputStream(file.bytes()))) {
            String allText = ppt.getSlides().stream()
                    .flatMap(slide -> slide.getShapes().stream())
                    .filter(XSLFTextShape.class::isInstance)
                    .map(XSLFTextShape.class::cast)
                    .map(XSLFTextShape::getText)
                    .reduce("", (a, b) -> a + "\n" + b);
            assertThat(allText).contains("Client").contains("API Gateway").contains("Database");
            assertThat(ppt.getSlides().get(1).getShapes().size()).isGreaterThan(8);
        }
    }

    @Test
    void structurallyInvalidDiagramFallsBackWithoutDroppingContent() throws Exception {
        IconCatalog icons = new IconCatalog();
        DocumentRenderer renderer = new DocumentRenderer(icons);
        ExportService service = new ExportService(renderer, icons, new PdfFontResolver());
        FormattedDocument document = new FormattedDocument(
                "", List.of(), List.of(), "Invalid diagram fallback",
                "Technical Team", "Knowledge Sharing", "POWERPOINT", "FORMAT", true, ""
        );
        String html = """
                <h1>Fallback Diagram</h1>
                <h2 data-layout="DIAGRAM" data-diagram="MATRIX_2X2">Configuration matrix</h2>
                <h3>Browser</h3><ul><li>Headless toggle</li><li>Zoom selection</li></ul>
                <h3>Execution</h3><ul><li>Shared session</li><li>Parallel pool</li></ul>
                """;

        ExportService.ExportedFile file = service.export(new ExportRequest(document, "POWERPOINT", "diagram-fallback", html));
        try (XMLSlideShow ppt = new XMLSlideShow(new ByteArrayInputStream(file.bytes()))) {
            String allText = ppt.getSlides().stream()
                    .flatMap(slide -> slide.getShapes().stream())
                    .filter(XSLFTextShape.class::isInstance)
                    .map(XSLFTextShape.class::cast)
                    .map(XSLFTextShape::getText)
                    .reduce("", (a, b) -> a + "\n" + b);
            assertThat(allText).contains("Browser").contains("Headless toggle")
                    .contains("Execution").contains("Parallel pool");
        }
    }

    @Test
    void genericSubsectionsDoNotAutomaticallyBecomeCardBoxes() throws Exception {
        IconCatalog icons = new IconCatalog();
        DocumentRenderer renderer = new DocumentRenderer(icons);
        ExportService service = new ExportService(renderer, icons, new PdfFontResolver());
        FormattedDocument document = new FormattedDocument(
                "", List.of(), List.of(), "Configuration details",
                "Technical Team", "Knowledge Sharing", "POWERPOINT", "FORMAT", true, ""
        );
        String html = """
                <h1>Configuration Guide</h1>
                <h2>Configuration details</h2>
                <h3>Browser</h3><ul><li>Headless toggle</li><li>Zoom selection</li></ul>
                <h3>Execution</h3><ul><li>Shared session</li><li>Parallel pool</li></ul>
                <h3>Reporting</h3><ul><li>HTML report</li><li>Screenshot report</li></ul>
                """;

        ExportService.ExportedFile file = service.export(new ExportRequest(document, "POWERPOINT", "no-auto-cards", html));

        try (XMLSlideShow ppt = new XMLSlideShow(new ByteArrayInputStream(file.bytes()))) {
            List<String> texts = ppt.getSlides().stream()
                    .flatMap(slide -> slide.getShapes().stream())
                    .filter(XSLFTextShape.class::isInstance)
                    .map(XSLFTextShape.class::cast)
                    .map(XSLFTextShape::getText)
                    .toList();
            String allText = String.join("\n", texts);
            assertThat(allText).contains("Browser — Headless toggle", "Execution — Shared session", "Reporting — HTML report");
            assertThat(texts).doesNotContain("Browser", "Execution", "Reporting");
        }
    }

    @Test
    void checklistRendererOwnsVisualMarkerAndRemovesEmbeddedBoxGlyphs() throws Exception {
        IconCatalog icons = new IconCatalog();
        DocumentRenderer renderer = new DocumentRenderer(icons);
        ExportService service = new ExportService(renderer, icons, new PdfFontResolver());
        FormattedDocument document = new FormattedDocument(
                "", List.of(), List.of(), "Checklist",
                "Technical Team", "Knowledge Sharing", "POWERPOINT", "FORMAT", true, ""
        );
        String html = """
                <h1>Setup</h1>
                <h2 data-layout="CHECKLIST">Quick-Start Checklist</h2>
                <ul><li>□ Java 17+ installed</li><li>☑ Node.js installed</li><li>✅ Maven available</li></ul>
                """;

        ExportService.ExportedFile file = service.export(new ExportRequest(document, "POWERPOINT", "clean-checklist", html));

        try (XMLSlideShow ppt = new XMLSlideShow(new ByteArrayInputStream(file.bytes()))) {
            String allText = ppt.getSlides().stream()
                    .flatMap(slide -> slide.getShapes().stream())
                    .filter(XSLFTextShape.class::isInstance)
                    .map(XSLFTextShape.class::cast)
                    .map(XSLFTextShape::getText)
                    .reduce("", (a, b) -> a + "\n" + b);
            assertThat(allText).contains("Java 17+ installed", "Node.js installed", "Maven available");
            assertThat(allText).doesNotContain("□", "☑", "✅");
        }
    }

}
