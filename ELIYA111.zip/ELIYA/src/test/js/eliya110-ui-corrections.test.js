'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const diff=require('../../main/resources/static/conversation-render-diff.js');
const js=fs.readFileSync('src/main/resources/static/app.js','utf8');
const html=fs.readFileSync('src/main/resources/static/index.html','utf8');

test('Chat message edit invalidates memoized old user bubble',()=>{
  const m={id:'u1',role:'user',content:'Original',mode:'analyse'};
  let renders=0;
  const render=()=>`edit-view-${++renders}`;
  assert.equal(diff.memo(m,0,render),'edit-view-1');
  assert.equal(diff.memo(m,0,render),'edit-view-1');
  m.__eliyaEditing=true;
  assert.equal(diff.memo(m,0,render),'edit-view-2');
  delete m.__eliyaEditing;
  assert.equal(diff.memo(m,0,render),'edit-view-1');
});
test('OpenCode and Eliya are the two named engine choices',()=>{
  assert.match(html,/<option value="opencode">OpenCode<\/option>/);
  assert.match(html,/<option value="legacy">Eliya<\/option>/);
  assert.doesNotMatch(html,/<option value="opencode">OpenCode 2<\/option>/);
});
test('Terminal sees event sequence updates while task remains running',()=>{
  assert.match(js,/function terminalRenderKey\(detail\)/);
  assert.match(js,/detail\.events\?\.\[detail\.events\.length-1\]\?\.seq/);
  assert.match(js,/terminal-open-actions/);
  assert.match(js,/opencode-live-console/);
});
test('Rollback is provider-side with confirmed diff, not a generated model instruction',()=>{
  assert.match(js,/api\/terminal\/sessions\/\$\{encodeURIComponent\(selectedId\)\}\/rollback\/preview/);
  assert.match(js,/promptId:preview\.promptId/);
  assert.match(js,/await performEliyaRollback\(\)/);
  assert.match(js,/data-terminal-rollback/);
});
test('OpenCode question and measured provider usage are shown in terminal and chat',()=>{
  assert.match(js,/data-answer-choice="once"/);
  assert.match(js,/data-answer-choice="reject"/);
  assert.match(js,/terminalUsage = detail\.engine==='opencode' \? detail\.usage/);
  assert.match(js,/executionTokenStripHtml\(usage,!message\.streaming\)/);
  assert.match(js,/OpenCode execution · live actions/);
});
