package com.llmart.llm.service;

import com.llmart.llm.dto.ChatMode;
import com.llmart.llm.dto.ChatRequest;
import org.springframework.stereotype.Service;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

import java.util.*;
import java.util.concurrent.*;

/**
 * The single ELIYA conversation UI is the presentation layer for OpenCode work.
 * Conversation history remains ELIYA-owned; execution stays OpenCode-owned.
 * A network disconnect does not cancel the engine or silently report success.
 */
@Service
public class UnifiedOpenCodeChatBridge {
    private final OpenCodeExecutionService engine;
    private final ConversationService conversations;
    private final ExecutorService relay = Executors.newCachedThreadPool(r -> {
        Thread t = new Thread(r, "eliya-unified-opencode"); t.setDaemon(true); return t;
    });
    private final ConcurrentMap<String,String> active = new ConcurrentHashMap<>();

    public UnifiedOpenCodeChatBridge(OpenCodeExecutionService engine, ConversationService conversations) {
        this.engine = engine; this.conversations = conversations;
    }
    public boolean accepts(ChatRequest request) {
        return engine.accepts(request) && request.chatMode() == ChatMode.AGENT
                && request.projectId() != null && !request.projectId().isBlank() && !request.isRegenerate();
    }
    public boolean availableForAuto() { return engine.availableForAuto(); }
    public boolean cancel(String conversationId) {
        String sessionId = active.get(conversationId);
        if (sessionId == null) return false;
        engine.cancel(sessionId); return true;
    }
    private static void send(SseEmitter emitter,String event,Object payload) {
        try { emitter.send(SseEmitter.event().name(event).data(payload)); }
        catch (Exception ignored) { /* engine continues when browser disconnects */ }
    }
    public SseEmitter stream(ChatRequest request, String apiKey) {
        SseEmitter emitter = new SseEmitter(0L);
        relay.execute(() -> {
            String conversationId = request.conversationId();
            String sessionId = null;
            boolean done = false;
            try {
                conversations.require(conversationId);
                var user = conversations.addMessage(conversationId,"user",request.message(),List.of());
                send(emitter,"meta",Map.of("conversationId",conversationId,"userMessageId",user.getId(),"mode","agent","engine","opencode"));
                send(emitter,"agent_progress",Map.of("percent",4,"phase","starting", "detail","Preparing OpenCode connection","status","starting"));
                send(emitter,"agent_step",Map.of("tool","OpenCode","step","startup","status","running","detail","Starting OpenCode execution"));
                Optional<String> pending = engine.pendingQuestionSession(conversationId,request.projectId());
                Optional<String> existing = pending.isPresent() ? pending : engine.latestSession(conversationId,request.projectId());
                Map<String,Object> current = pending.isPresent()
                        ? resumeQuestion(pending.get(), request.message())
                        : existing.isPresent() ? engine.message(existing.get(),request,apiKey)
                        : engine.launch(request,null,apiKey,detail -> {
                            send(emitter,"agent_step",Map.of("tool","OpenCode","step","startup","status","running","detail",detail));
                            send(emitter,"agent_progress",Map.of("percent",10,"phase","connecting","detail",detail,"status","starting"));
                        });
                sessionId = String.valueOf(current.get("id"));
                active.put(conversationId,sessionId);
                // OpenCode sessions are not legacy /api/agent/runs IDs; the UI must poll /api/terminal/sessions.
                send(emitter,"meta",Map.of("conversationId",conversationId,"engine","opencode","agentRunId",sessionId));
                send(emitter,"agent_progress",Map.of("percent",0,"phase","executing","detail","OpenCode accepted the instruction; awaiting actual model/tool activity","status","running"));
                int previousLength = 0;
                long lastSeq = 0;
                String previousProgress = "";
                long deadline = System.nanoTime() + TimeUnit.HOURS.toNanos(2);
                while (System.nanoTime() < deadline) {
                    current = engine.get(sessionId);
                    String answer = String.valueOf(current.getOrDefault("answer",""));
                    if (answer.length() < previousLength) previousLength = 0;
                    if (answer.length() > previousLength) {
                        send(emitter,"token",Map.of("text",answer.substring(previousLength)));
                        previousLength = answer.length();
                    }
                    Object rawEvents = current.get("events");
                    if (rawEvents instanceof List<?> events) {
                        for (Object raw : events) {
                            if (!(raw instanceof Map<?,?> event)) continue;
                            long seq = event.get("seq") instanceof Number n ? n.longValue() : 0;
                            if (seq <= lastSeq) continue;
                            lastSeq = seq;
                            if ("agent_step".equals(event.get("type"))) {
                                Object data = event.get("data");
                                if (data instanceof Map<?,?>) send(emitter,"agent_step",data);
                            }
                        }
                    }
                    String status = String.valueOf(current.getOrDefault("status","running"));
                    if ("running".equals(status)) {
                        Object progress = current.get("progress");
                        if (progress instanceof Map<?,?> p) {
                            String phase = String.valueOf(p.containsKey("progressPhase") ? p.get("progressPhase") : "executing");
                            String detail = String.valueOf(p.containsKey("progressDetail") ? p.get("progressDetail") : "Awaiting OpenCode model/tool activity");
                            int observedPercent = current.get("progressPercent") instanceof Number n ? n.intValue() : 0;
                            boolean estimated = Boolean.TRUE.equals(p.get("estimated"));
                            String progressSignature = phase + "\n" + detail + "\n" + observedPercent + estimated;
                            if (!progressSignature.equals(previousProgress)) {
                                Map<String,Object> update = new LinkedHashMap<>();
                                update.put("percent", observedPercent);
                                update.put("estimated", estimated);
                                update.put("indeterminate", Boolean.TRUE.equals(p.get("indeterminate")));
                                update.put("phase", phase);
                                update.put("detail", detail);
                                update.put("status", "running");
                                update.put("startedAt", current.get("startedAt"));
                                update.put("elapsedMs", current.get("elapsedMs"));
                                send(emitter,"agent_progress", update);
                                previousProgress = progressSignature;
                            }
                        }
                    }
                    if (Set.of("completed","failed","cancelled","interrupted","needs_input","stalled").contains(status)) {
                        // Allow OpenCode's post-completion diff collection to finish
                        // before issuing a final report, but never wait indefinitely.
                        if (Set.of("completed","failed").contains(status) &&
                            !(current.get("changeReport") instanceof Map<?,?> report && report.containsKey("filesVerified"))) {
                            for (int retry=0; retry<5;retry++) {
                                Thread.sleep(250);
                                current=engine.get(sessionId);
                                if (current.get("changeReport") instanceof Map<?,?> report && report.containsKey("filesVerified")) break;
                            }
                        }
                        // The browser must receive the authoritative backend state before `done`;
                        // otherwise it might render needs_input/failed as a completed task.
                        Map<String,Object> authoritativeProgress = new LinkedHashMap<>();
                        authoritativeProgress.put("percent", "completed".equals(status) ? 100 : 0);
                        authoritativeProgress.put("phase", status);
                        authoritativeProgress.put("detail", String.valueOf(current.getOrDefault("lastRemoteStatus", status)));
                        authoritativeProgress.put("status", status);
                        // The watch loop ends when the agent requests input. Send the
                        // complete question and token snapshot BEFORE 'done' so the
                        // composer can receive a reply without a page refresh.
                        authoritativeProgress.put("question", current.getOrDefault("question", Map.of()));
                        authoritativeProgress.put("tokenUsage", current.getOrDefault("usage", Map.of()));
                        send(emitter, "agent_progress", authoritativeProgress);
                        // Only completed execution is successful. Questions/errors are not silently closed.
                        String report = formatReport(current.get("changeReport"),status);
                        String timingReport = formatTimings(current.get("timingsMs"));
                        String finalAnswer = answer + (report.isBlank()?"":"\n\n"+report)
                                + (timingReport.isBlank()?"":"\n\n"+timingReport);
                        if (!"completed".equals(status)) finalAnswer += "\n\n**Execution status:** " + status
                                + ". The task is not confirmed complete. " + String.valueOf(current.getOrDefault("error",""));
                        var saved = conversations.addMessage(conversationId,"assistant",finalAnswer,List.of());
                        send(emitter,"done",conversations.messageDto(saved));
                        done=true; break;
                    }
                    Thread.sleep(900);
                }
                if (!done) send(emitter,"error",Map.of("message","OpenCode execution exceeded the bridge watch deadline; task status is unverified"));
            } catch (Exception failure) {
                String detail = String.valueOf(failure.getMessage());
                send(emitter,"agent_step",Map.of("tool","OpenCode","step","startup","status","failed", "detail",detail));
                send(emitter,"agent_progress",Map.of("percent",0,"phase","failed","detail",detail,"status","failed"));
                send(emitter,"error",Map.of("message","OpenCode execution could not complete: " + detail));
            } finally {
                if (sessionId != null) active.remove(conversationId,sessionId);
                try { emitter.complete(); } catch (Exception ignored) {}
            }
        });
        return emitter;
    }
    private Map<String,Object> resumeQuestion(String sessionId, String reply) {
        Map<String,Object> current = engine.get(sessionId);
        Object raw = current.get("question");
        if (!(raw instanceof Map<?,?> q) || q.get("id") == null)
            throw new IllegalStateException("OpenCode question is no longer pending");
        engine.answer(sessionId, String.valueOf(q.get("id")), "", reply);
        return engine.get(sessionId);
    }

    /** Local measurements identify UI/adapter overhead without exposing secrets or
     * claiming that model generation and gateway latency are independently timed. */
    private static String formatTimings(Object raw) {
        if (!(raw instanceof Map<?,?> timings) || timings.isEmpty()) return "";
        Map<String,String> labels = new LinkedHashMap<>();
        labels.put("startup", "OpenCode readiness");
        labels.put("modelValidation", "Model validation");
        labels.put("sessionCreation", "Session creation");
        labels.put("promptAdmission", "Prompt admission");
        labels.put("firstModelOrToolEvent", "Time to first model/tool activity");
        labels.put("fileVerification", "File verification");
        StringJoiner line = new StringJoiner(" · ");
        for (var entry : labels.entrySet()) {
            Object value = timings.get(entry.getKey());
            if (value instanceof Number number && number.longValue() >= 0) {
                line.add(entry.getValue() + ": " + String.format(Locale.ROOT, "%.2f", number.longValue() / 1000.0) + "s");
            }
        }
        return line.length() == 0 ? "" : "**OpenCode timing diagnostics:** " + line
                + "\n\n*These are local observations. Model processing, gateway queues and network transit are not separately timed.*";
    }

    private static String formatReport(Object raw, String status) {
        if (!(raw instanceof Map<?,?> report)) return "";
        Object rawFiles = report.get("files");
        boolean verified = Boolean.TRUE.equals(report.get("filesVerified"));
        StringBuilder result = new StringBuilder("### Execution change report\n");
        result.append("**Verification:** ").append(verified ? "OpenCode session diff retrieved" :
                "File diff unavailable; manual verification required").append("\n");
        result.append("**Why:** Changes were requested by the current instruction; file-specific intent must be confirmed against its diff.\n");
        if (rawFiles instanceof List<?> files) for (Object file : files) {
            if (file instanceof Map<?,?> item) result.append("- ")
                    .append(String.valueOf(item.containsKey("action") ? item.get("action") : "modified")).append(" `")
                    .append(String.valueOf(item.containsKey("relativePath") ? item.get("relativePath") : "unknown")).append("`: ")
                    .append(String.valueOf(item.containsKey("detail") ? item.get("detail") : "")).append("\n");
        }
        Object warning = report.get("fileReportWarning");
        if (warning != null) result.append("**Warning:** ").append(warning).append("\n");
        return result.toString();
    }
}
