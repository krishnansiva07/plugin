import com.fasterxml.jackson.databind.ObjectMapper;
import com.llmart.llm.service.OpenCodeExecutionService;
import com.sun.net.httpserver.HttpServer;
import java.lang.reflect.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;

/** Real loopback HTTP integration smoke without a model, token cost or external OpenCode server. */
public final class OpenCodeRollbackSmoke {
    static void expect(boolean yes,String description) {if(!yes)throw new AssertionError(description);}
    @SuppressWarnings("unchecked")
    public static void main(String[] args) throws Exception {
        Path root=Files.createTempDirectory("eliya110-rollback-");
        Path workspace=Files.createDirectories(root.resolve("workspace"));
        Path document=workspace.resolve("changed.txt");Files.writeString(document,"Hello from current OpenCode task\n");
        System.setProperty("eliya.qa.workspace",workspace.toString());
        System.setProperty("eliya.opencode.sessionStore",root.resolve("store").toString());
        AtomicInteger stage = new AtomicInteger(), commit = new AtomicInteger(), permissions = new AtomicInteger();
        List<String> posted = Collections.synchronizedList(new ArrayList<>());
        HttpServer mock=HttpServer.create(new InetSocketAddress("127.0.0.1",0),0);
        mock.createContext("/api", exchange -> {
            String method=exchange.getRequestMethod(), url=exchange.getRequestURI().toString();
            String body = new String(exchange.getRequestBody().readAllBytes(), StandardCharsets.UTF_8);
            String response="{\"data\":{}}";
            if(method.equals("GET") && url.equals("/api/session/active")) response="{\"data\":{}}";
            else if(method.equals("GET") && url.startsWith("/api/session/ses-test/diff?")) {
                expect(url.contains("from=usr-prompt-1"),"diff must be bound to user prompt");
                response="{\"data\":[{\"status\":\"modified\",\"file\":\"changed.txt\",\"additions\":1,\"deletions\":1,\"patch\":\"@@ sample\"}]}";
            } else if(method.equals("POST") && url.equals("/api/session/ses-test/revert/stage")) {
                stage.incrementAndGet(); posted.add(body);
                response="{\"data\":{\"staged\":true}}";
            } else if(method.equals("POST") && url.equals("/api/session/ses-test/revert/commit")) {
                commit.incrementAndGet(); posted.add("COMMIT");
                response="{\"data\":{\"committed\":true}}";
            } else if (method.equals("POST") && url.equals("/api/session/ses-test/permission/prm-delete/reply")) {
                permissions.incrementAndGet(); posted.add(body);
                response="{\"data\":{\"accepted\":true}}";
            } else {response="{\"error\":{\"message\":\"Unexpected test request\"}}";}
            byte[] payload=response.getBytes(StandardCharsets.UTF_8);
            exchange.getResponseHeaders().set("Content-Type","application/json");
            exchange.sendResponseHeaders(200,payload.length);
            try(var out=exchange.getResponseBody()){out.write(payload);}
        });
        mock.start();
        OpenCodeExecutionService service=null;
        try {
            service = new OpenCodeExecutionService(new ObjectMapper(),
                new com.llmart.llm.service.ProjectService(),"opencode", "http://127.0.0.1:"+mock.getAddress().getPort(),"", "opencode",false);
            Class<?> type=Class.forName("com.llmart.llm.service.OpenCodeExecutionService$Session");
            Constructor<?> ctor=type.getDeclaredConstructor(String.class,String.class,String.class,String.class,String.class,String.class);
            ctor.setAccessible(true);
            String id="oc-aaaaaaaa-0000-4000-8000-111111111111";
            Object session=ctor.newInstance(id,"ses-test","conv-test","project-test","test-model","Edit changed.txt");
            Field status=type.getDeclaredField("status");status.setAccessible(true);
            status.set(session,"running");
            Field lastPrompt=type.getDeclaredField("lastPromptId");lastPrompt.setAccessible(true);
            lastPrompt.set(session,"usr-prompt-1");
            Field sessions=OpenCodeExecutionService.class.getDeclaredField("sessions");sessions.setAccessible(true);
            ((Map<String,Object>)sessions.get(service)).put(id,session);
            final OpenCodeExecutionService current=service;
            expect(rejects(() -> current.rollbackPreview(id)),"Must prevent rollback while execution active");
            expect(stage.get()==0 && commit.get()==0,"No mutation during running task");
            status.set(session,"completed");
            Map<String,Object> preview=service.rollbackPreview(id);
            expect(Boolean.TRUE.equals(preview.get("available")),"Preview must be available for a verified diff");
            expect(Integer.valueOf(1).equals(preview.get("fileCount")),"Preview must show actual changed file");
            expect("usr-prompt-1".equals(preview.get("promptId")),"Preview must identify last user prompt");
            expect(rejects(() -> current.rollback(id,"usr-not-last")),"Must reject stale or unrelated prompt id");
            expect(stage.get()==0 && commit.get()==0,"Stale id must not cause any OpenCode mutation");
            Map<String,Object> result=service.rollback(id,"usr-prompt-1");
            expect("rolled_back".equals(result.get("status")),"Rollback must be acknowledged before showing success");
            expect(stage.get()==1 && commit.get()==1,"Exactly one stage then one commit");
            expect(posted.get(0).contains("usr-prompt-1") && posted.get(0).contains("\"files\":true"),
                "Stage must include last prompt and files=true");
            expect("COMMIT".equals(posted.get(1)),"Commit must run after stage");
            expect(rejects(() -> current.rollbackPreview(id)),"Already rolled-back task cannot be rolled back twice");
            expect(Files.exists(root.resolve("store").resolve(id+".json")),"Completion status must persist to journal");
            // A deletion-related permission request must become a visible, resumable
            // question, not an indefinitely spinning "executing" indicator.
            Object asking=ctor.newInstance("oc-aaaaaaaa-0000-4000-8000-222222222222",
                "ses-test","conv-question","project-test","test-model","Delete obsolete file");
            status.set(asking,"running");
            String questionSession="oc-aaaaaaaa-0000-4000-8000-222222222222";
            ((Map<String,Object>)sessions.get(service)).put(questionSession,asking);
            Method read=OpenCodeExecutionService.class.getDeclaredMethod("readEvent",type,String.class,String.class,String.class);
            read.setAccessible(true);
            read.invoke(service,asking,"","","{\"id\":\"ev-question\",\"type\":\"permission.asked\",\"data\":{\"id\":\"prm-delete\",\"title\":\"Delete obsolete module?\"}}");
            Map<String,Object> pending=service.get(questionSession);
            expect("needs_input".equals(pending.get("status")),"Question must pause OpenCode and stay visible");
            Map<?,?> question=(Map<?,?>)pending.get("question");
            expect("prm-delete".equals(question.get("id")),"Question ID must be tracked");
            expect("permission".equals(question.get("source")),"Permission type must be recorded");
            expect(Boolean.TRUE.equals(service.answer(questionSession,"prm-delete","once","").get("answered")),
                "Answer must be delivered through OpenCode HTTP API");
            expect(permissions.get()==1 && posted.get(posted.size()-1).contains("\"decision\":\"once\""),
                "One-time approval must use provider permission endpoint");
            expect("running".equals(service.get(questionSession).get("status")),"Session must resume after answer");
            // Mock records provider acceptance, not physical snapshot restoration.
            System.out.println("PASS: rollback safety and one stage+commit; permission question is visible and one-time answer resumes the same session");
        } finally {if(service!=null)service.shutdown();mock.stop(0);}
    }
    interface Action {void run() throws Exception;}
    static boolean rejects(Action action) {try{action.run();return false;}catch(IllegalStateException expected){return true;}catch(Exception unexpected){throw new RuntimeException(unexpected);}}
}
