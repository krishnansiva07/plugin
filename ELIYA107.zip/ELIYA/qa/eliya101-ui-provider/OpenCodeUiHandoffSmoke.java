import com.fasterxml.jackson.databind.ObjectMapper;
import com.llmart.llm.dto.ChatMode;
import com.llmart.llm.dto.ChatRequest;
import com.llmart.llm.service.OpenCodeExecutionService;
import com.llmart.llm.service.OpenCodeUiProviderConfig;
import com.llmart.llm.service.ProjectService;
import java.nio.file.*;
import java.util.*;

public class OpenCodeUiHandoffSmoke {
    static void check(boolean ok,String message){if(!ok)throw new AssertionError(message);}
    public static void main(String[] args) throws Exception {
        var config=new OpenCodeUiProviderConfig("https://company.example/v1/chat/completions", "agent-model-v1", "top-secret-do-not-log");
        check("company.example".equals(config.endpointHost()),"invalid endpoint host");
        check("eliya-ui/agent-model-v1".equals(config.modelReference()),"wrong model ref");
        String configText=config.config().toString();
        check(configText.contains("https://company.example/v1"),"API root not normalized");
        check(!configText.contains("top-secret-do-not-log"),"API secret leaked into config");
        check("top-secret-do-not-log".equals(config.processEnvironment().get(OpenCodeUiProviderConfig.KEY_ENV)),"missing child credential");
        try {new OpenCodeUiProviderConfig("https://u:p@company.example/v1","abc","k");throw new AssertionError("Embedded credential accepted");}
        catch(IllegalArgumentException expected){}
        check(config.fingerprint().equals(new OpenCodeUiProviderConfig("https://company.example/v1", "agent-model-v1", "top-secret-do-not-log").fingerprint()),"stable config fingerprint missing");
        Path dir=Files.createTempDirectory("eliya101-ui-handoff-");
        System.setProperty("eliya.qa.workspace",dir.toString());
        System.setProperty("eliya.opencode.sessionStore",dir.resolve("sessions").toString());
        String executable=System.getenv("ELIYA_QA_MOCK_BINARY");
        check(executable!=null && Files.isExecutable(Path.of(executable)),"Mock executable missing");
        OpenCodeExecutionService service=new OpenCodeExecutionService(new ObjectMapper(),new ProjectService(),
                "opencode","http://127.0.0.1:4096","",executable,true);
        try {
            check(!Boolean.TRUE.equals(service.engineInfo().get("connected")),"engine started before UI credentials were supplied");
            ChatRequest req=new ChatRequest("p","Create a text file",List.of(),ChatMode.AGENT,
                    new ChatRequest.Settings("https://company.example/v1","agent-model-v1"));
            var state=service.launch(req,null,"top-secret-do-not-log");
            check((""+state.get("id")).startsWith("oc-"),"session creation failed");
            check("agent-model-v1".equals(state.get("model")),"wrong displayed model");
            check(config.selectedModel().get("id").equals("eliya-ui/agent-model-v1"),
                    "OpenCode v2 Model.Ref MUST contain fully-qualified id, not the obsolete model field");
            check("eliya-ui".equals(config.selectedModel().get("providerID")), "provider ID missing");
            check(!config.selectedModel().containsKey("model"),"obsolete model key must never be sent");
            check(Boolean.TRUE.equals(service.engineInfo().get("connected")),"configured engine not connected");
            System.out.println("PASS: ELIYA UI endpoint, model, and key configured in managed OpenCode process; explicit model switch admitted prompt");
            service.cancel((String)state.get("id"));
            // Real screenshot regression: OpenCode returns upstream modelID rather
            // than a synthetic alias. This must pass model validation and admit the prompt.
            ChatRequest qwen=new ChatRequest("p","Create agents folder",List.of(),ChatMode.AGENT,
                    new ChatRequest.Settings("https://company.example/v1", "qwen3.8-27b"));
            var qwenState=service.launch(qwen,null,"top-secret-do-not-log");
            check("qwen3.8-27b".equals(qwenState.get("model")),"ELIYA Qwen model was rejected");
            check("eliya-ui/qwen3.8-27b".equals(
                  new OpenCodeUiProviderConfig("https://company.example/v1","qwen3.8-27b","key").modelReference()),
                  "ELIYA102 must not invent a separate agent alias");
            check(new OpenCodeUiProviderConfig("https://company.example/v1","qwen3.8-27b","key")
                    .selectedModel().get("id").equals("eliya-ui/qwen3.8-27b"), "exact screenshot model id missing");
            System.out.println("PASS: screenshot regression eliya-ui/qwen3.8-27b model ref accepted and prompt admitted");
            service.cancel((String)qwenState.get("id"));
            // Follow-up messages hit the same /session/{id}/model route as initial launch.
            // A strict mock will fail with HTTP 400 if the old `model` field reappears.
            ChatRequest followup=new ChatRequest("p", "Create code-reviewer.md", List.of(), ChatMode.AGENT,
                    new ChatRequest.Settings("https://company.example/v1", "qwen3.8-27b"));
            var followupState=service.message((String)qwenState.get("id"),followup,"top-secret-do-not-log");
            check("running".equals(followupState.get("status")), "Follow-up was not admitted with Model.Ref");
            System.out.println("PASS: subsequent instruction also uses valid OpenCode v2 Model.Ref");
            service.cancel((String)qwenState.get("id"));
            // Model dispatch can fail without an assistant message. It must surface the
            // durable OpenCode failure detail rather than ELIYA103's generic summary.
            ChatRequest upstreamFail=new ChatRequest("p", "FORCE_PROVIDER_FAILURE", List.of(), ChatMode.AGENT,
                    new ChatRequest.Settings("https://company.example/v1", "qwen3.8-27b"));
            var failedState=service.launch(upstreamFail,null,"top-secret-do-not-log");
            String failedId=(String)failedState.get("id");
            String observed="";
            for (int attempt=0;attempt<16;attempt++) {
                Thread.sleep(500);
                Map<String,Object> value=service.get(failedId);
                if ("failed".equals(value.get("status"))) {
                    observed=String.valueOf(value.getOrDefault("error", ""));
                    break;
                }
            }
            check(observed.contains("401"),"Provider error not surfaced from durable OpenCode log: " + observed);
            check(!observed.contains("top-secret-do-not-log"),"API key leaked through failed execution");
            System.out.println("PASS: failed session without assistant surfaces upstream HTTP 401 and redacts secret");
            service.cancel(failedId);
            ChatRequest gatewayFail = new ChatRequest("p", "FORCE_GATEWAY_BODY_FAILURE", List.of(), ChatMode.AGENT,
                    new ChatRequest.Settings("https://company.example/v1", "qwen3.8-27b"));
            var gatewayRun = service.launch(gatewayFail, null, "top-secret-do-not-log");
            String bodyProblem = "";
            for (int attempt=0;attempt<16;attempt++) {
                Thread.sleep(500);
                Map<String,Object> value=service.get((String)gatewayRun.get("id"));
                if ("failed".equals(value.get("status"))) {
                    bodyProblem=String.valueOf(value.getOrDefault("error", "")); break;
                }
            }
            check(bodyProblem.contains("Provider HTTP 400") && bodyProblem.contains("Invalid max_completion_tokens"),
                    "Gateway 400 responseBody was swallowed: " + bodyProblem);
            System.out.println("PASS: failed session surfaces upstream responseBody and HTTP status, not generic no-reply error");
            service.cancel((String)gatewayRun.get("id"));
            ChatRequest wrong=new ChatRequest("p","Create another file",List.of(),ChatMode.AGENT,
                    new ChatRequest.Settings("https://company.example/v1","force-mismatch"));
            try {service.launch(wrong,null,"top-secret-do-not-log");throw new AssertionError("Public model fallback was accepted");}
            catch(IllegalStateException expected){check(expected.getMessage().contains("expected eliya-ui/force-mismatch"),"Expected model mismatch explanation: "+expected.getMessage());}
            System.out.println("PASS: public OpenCode default rejected BEFORE prompt admission");
        }finally{service.shutdown();}
        System.out.println("PASS: API key not embedded in provider config; UI credentials not needed from user again");
    }
}
