package com.llmart.llm.service;

import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.HexFormat;
import java.util.LinkedHashMap;
import java.util.Map;

/** Translates the existing ELIYA Settings page into OpenCode v2 provider configuration.
 * The API key is supplied only through the child process environment, NEVER the config file. */
public final class OpenCodeUiProviderConfig {
    public static final String PROVIDER_ID = "eliya-ui";
    public static final String KEY_ENV = "ELIYA_OPENCODE_MODEL_API_KEY";
    private final String endpoint, model, apiKey, fingerprint;

    public OpenCodeUiProviderConfig(String rawEndpoint, String rawModel, String apiKey) {
        if (rawEndpoint == null || rawEndpoint.isBlank()) throw new IllegalArgumentException("ELIYA Base URL is missing in Settings");
        if (rawModel == null || rawModel.isBlank()) throw new IllegalArgumentException("ELIYA Agent model is missing in Settings");
        if (apiKey == null || apiKey.isBlank()) throw new IllegalArgumentException("ELIYA API key is missing in Settings");
        String url = rawEndpoint.trim().replaceAll("/+$", "");
        // ELIYA OpenAI-compatible client appends /chat/completions. OpenCode needs the API root.
        if (url.endsWith("/chat/completions")) url = url.substring(0, url.length()-"/chat/completions".length());
        URI uri;
        try { uri = URI.create(url); } catch (Exception e) { throw new IllegalArgumentException("ELIYA Base URL is not a valid URI"); }
        if (!("https".equalsIgnoreCase(uri.getScheme()) || "http".equalsIgnoreCase(uri.getScheme()))
                || uri.getHost() == null || uri.getRawUserInfo() != null || uri.getRawQuery() != null
                || uri.getRawFragment() != null)
            throw new IllegalArgumentException("ELIYA Base URL must be an HTTP(S) API root without embedded credentials, query or fragment");
        this.endpoint = url;
        this.model = rawModel.trim();
        this.apiKey = apiKey;
        try {
            byte[] digest = MessageDigest.getInstance("SHA-256").digest(
                    (endpoint + "\u0000" + model + "\u0000" + apiKey).getBytes(StandardCharsets.UTF_8));
            this.fingerprint = HexFormat.of().formatHex(digest);
        } catch (Exception e) { throw new IllegalStateException("SHA-256 is unavailable",e); }
    }

    public String fingerprint() { return fingerprint; }
    /** Redact credentials from provider exceptions before they reach browser progress. */
    public String scrub(String message) { return message == null ? "" : message.replace(apiKey, "[REDACTED]"); }
    public String model() { return model; }
    public String endpointHost() { return URI.create(endpoint).getHost(); }
    /** OpenCode model key is the exact Agent model ID from ELIYA Settings.
     * Avoid a separate `agent` alias: the OpenCode default-model API can expose
     * upstream modelID instead of the model-map key. */
    public String modelReference() { return PROVIDER_ID + "/" + model; }
    /** OpenCode v2 Model.Ref requires the fully-qualified `id` (provider/model).
     * The old {providerID, model} object caused HTTP 400: Missing key at ["model"]["id"].
     * This exact reference is used for both initial model selection and subsequent turns.
     * See https://dev.opencode.ai/v2/docs/api - Model.Ref and session.switchModel. */
    public Map<String,Object> selectedModel() {
        return Map.of("id", modelReference(), "providerID", PROVIDER_ID);
    }
    public Map<String,String> processEnvironment() {
        return Map.of(KEY_ENV,apiKey,"OPENCODE_DISABLE_FREE_MODELS","1");
    }
    public Map<String,Object> config() {
        Map<String,Object> provider = new LinkedHashMap<>();
        provider.put("name", "ELIYA Settings");
        provider.put("env", java.util.List.of(KEY_ENV));
        provider.put("package", "@opencode/ai/providers/openai-compatible");
        provider.put("settings", Map.of("baseURL",endpoint,"apiKey","{env:"+KEY_ENV+"}"));
        // Many corporate OpenAI-compatible gateways (including older Qwen frontends)
        // reject OpenCode's defaults: max_completion_tokens and stream_options.include_usage.
        // Use conservative OpenAI Chat Completions wire-format compatibility; this is
        // OpenCode v2's documented compatibility schema, not a prompt-side workaround.
        Map<String,Object> compatibility = new LinkedHashMap<>();
        compatibility.put("maxTokensField", "max_tokens");
        compatibility.put("streamUsage", false);
        // Streaming gateways frequently omit finish_reason on the final SSE frame.
        compatibility.put("requireFinishReason", false);
        provider.put("compatibility", compatibility);
        provider.put("models", Map.of(model, Map.of(
                "modelID", model, "name", model,
                "capabilities", Map.of("tools", true, "input", java.util.List.of("text"),
                        "output", java.util.List.of("text")),
                // OpenCode assumes 32k OUTPUT for uncatalogued models. That can
                // exceed a company's model-serving policy and fail before a tool call.
                "limit", Map.of("context", 32768, "output", 4096))));
        // Use the UI selection as the default but ALSO explicitly switch each session.
        return Map.of("model",modelReference(),"default_agent","build",
                "update","disable","providers",Map.of(PROVIDER_ID,provider));
    }
}
