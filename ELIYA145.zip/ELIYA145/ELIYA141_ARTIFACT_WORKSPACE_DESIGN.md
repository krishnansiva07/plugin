# Proposed architecture — Durable Artifact Workspace

This is a design proposal, **not implemented** in ELIYA141. It addresses the deeper issue: users currently rely on output format workarounds (HTML instead of Markdown) to read, save, or reuse large generated prompts.

## Contract

- `Generate a single prompt` creates **one artifact**: media type `text/markdown`, a stable artifact ID and one dark source editor, with Copy / Download / Expand controls. Text before/after the artifact is an ordinary chat explanation, not part of the source.
- `Generate four prompts` creates **four artifacts** (Prompt 1–4), each independently versioned and downloadable; only the selected version can be handed to Agent.
- HTML artifacts retain the same source editor, plus sandboxed Preview. HTML is not an escape hatch for output length.
- Display, Copy, Download and Agent handoff read identical saved artifact bytes. Never parse the chat answer a second time into a different scope.

## Server-side generation pipeline

1. **Artifact manifest**: Save artifact ID, conversation ID, requested count, filename, MIME type, creation timestamp, workspace/reference roles, `status` and expected scope. Start with `generating`.
2. **Chunked append**: Stream text via SSE with increasing chunk sequence numbers. Persist chunks and content hashes in a transactional table or append-only file, with bounded flush intervals. Avoid repeated O(n) concatenation.
3. **Reconnect**: On client reconnect, request `GET /api/artifacts/{id}?sinceSeq=...`; replay missing chunks. A tab switch must not require prompting the model again.
4. **Continuation**: Only if provider reports output exhaustion and the artifact remains incomplete, automatically continue from a bounded tail with a guard against duplicated sections. Use checkpoints and a finite continuation budget; save partial on exhaustion.
5. **Completeness gate**: Validate expected prompt count, closure/fences for Markdown, full HTML structure for HTML, absence of omitted sections, and custom acceptance criteria. Do not infer correctness merely from line count.
6. **Finalization**: Atomically mark artifact `complete`, `partial`, `failed`, or `blocked`; calculate source hash. Every UI operation must fetch or reference that exact revision.
7. **Handoff**: `Implement with Agent` takes `{artifactId, revision, selectedSection}`; verify hash server-side, prevent cross-document or stale-scope handoffs, then record user authorization and execution receipt.
8. **Server job observability**: Record queue, context retrieval, provider first-token latency, text-chunk throughput, continuation count, last meaningful-progress time, and provider finish reason. SSE heartbeats update connection health, **not** generation progress.

## Client layout

Conversation pane for intent and discussion; dedicated right/expanded source pane for generated artifacts; artifact drawer for numbered files and statuses. Large source should render in a virtualized/windowed editor when >2,000 lines while maintaining the complete byte stream for copy/download. Copy and Download never scrape only visible lines from the DOM.

## Acceptance criteria

- 2,000-line Markdown, 2,000-line HTML and four 500-line documents survive generation, tab switch, reconnect, copy, download and scoped Agent handoff with identical SHA-256 content hashes.
- At least one dropped SSE connection and one provider output limit are injected; no lines are silently lost or duplicated, no false `complete` status, and partial files remain accessible.
- 10 archived large documents do not trigger full-history re-render while streaming a new document.
- Empty reviewer response does not change a verified file state to success or fail without evidence.
