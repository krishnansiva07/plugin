# ELIYA144 — Unified chat UX, long-output reliability and durable recovery

**Baseline:** ELIYA143 source release. **Delivery:** full source ZIP; no executable JAR asserted.

## Main changes

- Added **shared Analyse/Agent lifecycle rail** in the chat header area (`#runStatusStrip`) with actual status, phase, tool/step information, truthful token availability, detail jump, cancellation and saved-response retry.
- Added `chat-experience144.js`: pure lifecycle state classifier and safe, ID-only recovery marker validation. No fabricated final verification, no billed-token guessing and no model calls from status display.
- Added **last selected conversation restoration**, pending Chat recovery polling and explicit recovery warnings. A tab refresh does **not** resubmit an already-running prompt; any saved result comes from the conversation messages API.
- Bound conversation DOM to the newest **85 messages**, with an explicit **Show earlier messages** action loading 65 more at a time; original message history remains intact in memory for code view and downloads.
- Preserved large-output compact previews, original-source copy/download, remembered expansion for the current conversation, secure HTML source handling and prior first-stream-chunk duplication fix.
- Fixed a **stale `Loading conversation…` placeholder** surviving message-diff reconciliation, which caused a visible blank area after reopening a chat.
- Improved cancellation reporting: HTTP abort is not a server-side cancellation; check `cancelled:true` on Chat/Agent cancellation routes; preserve pending results after uncertain abort; continue durable Agent status polling while completion is unknown. Handle explicit Chat SSE `stopped` message without reporting a successful completion.
- Refined responsive lifecycle, source-card, code and scrolling styles; retained compact mobile Analyse/Agent/Models controls.
- Added browser and Node acceptance tests plus `qa/eliya144-validate.ps1` for Windows. Browser tests use an **existing** Chrome/Edge, not Playwright-downloaded browsers.

## Modified UI files

- `src/main/resources/static/index.html`
- `src/main/resources/static/app.css`
- `src/main/resources/static/app.js`
- `src/main/resources/static/chat-experience144.js` (new)

## Acceptance and verification files

- `qa/eliya144-ui.test.js` (new, native Node test suite)
- `qa/eliya144_browser_ui.py` (new, installed Chromium and simulated durable backend)
- `qa/eliya144-validate.ps1` (new, Windows verification)
- `qa/screenshots-144/desktop.png`, `qa/screenshots-144/mobile.png`
- `validation/ELIYA144_NODE_TESTS.log`, `validation/ELIYA144_BROWSER_TEST.log`, `validation/ELIYA143_BROWSER_REGRESSION.log`, `validation/ELIYA144_JAVA_OPTIMIZATION_SMOKE.log`, `validation/ELIYA144_JAVA_AGENT_SMOKE.log`
- Updated inherited tests with version/markup expectations for v144, preserving coverage.

## Windows verification (from extracted root)

```powershell
# Install only the Python binding if it is missing. Do not run `playwright install`.
python -m pip install playwright
powershell -ExecutionPolicy Bypass -File qa\eliya144-validate.ps1
```

Requires Node.js 20+, Python 3, installed Chrome or Edge, and the Python Playwright binding. For a non-standard browser path set `ELIYA_BROWSER_BIN` to the installed `chrome.exe` or `msedge.exe`. This script checks the UI offline, **not** the Spring Boot runtime or connected models.

## Honest limitations

The source passed all reported local tests, but these are **not production performance benchmarks**. The complete Maven/Spring Boot application was not compiled here because Maven/dependency resolution was unavailable. Tests used scripted backend fixtures and local-installed Chromium, not a deployed provider. Further end-to-end testing is required for actual Agent cancellation, approvals, streaming reconnection, arbitrary 5,000-line real LLM generation, artifact persistence and WCAG compliance. The visual refactor does not represent a full replacement of all legacy screens.
