'use strict';
const test=require('node:test');const assert=require('node:assert/strict');
const fs=require('node:fs');const path=require('node:path');
const root=path.resolve(__dirname,'../src/main/resources/static');
const exp=require(path.join(root,'chat-experience144.js'));
const app=fs.readFileSync(path.join(root,'app.js'),'utf8');
const html=fs.readFileSync(path.join(root,'index.html'),'utf8');
const css=fs.readFileSync(path.join(root,'app.css'),'utf8');
test('agent lifecycle never infers completion from 100% or stream closure',()=>{
 const running=exp.stateFor({role:'assistant',mode:'agent',streaming:true,agentBackendStatus:'running',agentProgress:{percent:100}});
 assert.equal(running.verified,false);assert.equal(running.percent,null);assert.equal(running.terminal,false);
 const closed=exp.stateFor({role:'assistant',mode:'agent',streaming:false,agentBackendStatus:'unknown',agentProgress:{percent:100}});
 assert.equal(closed.verified,false);assert.match(closed.title,/unverified/i);
 const done=exp.stateFor({role:'assistant',mode:'agent',streaming:false,agentBackendStatus:'completed',agentProgress:{plan:[{status:'completed'}]}});
 assert.equal(done.verified,true);assert.match(done.title,/verified/i);
 const incomplete=exp.stateFor({role:'assistant',mode:'agent',streaming:false,agentBackendStatus:'completed',agentProgress:{plan:[{status:'blocked'}]}});
 assert.equal(incomplete.verified,false);
});
test('disconnected Agent and unreported tokens remain visibly unverified',()=>{
 const result=exp.stateFor({role:'assistant',mode:'agent',streaming:true,agentConnectionStatus:'disconnected',agentBackendStatus:'running',agentProgress:{tokenUsage:{providerTotalTokens:0}}});
 assert.equal(result.disconnected,true);assert.match(result.title,/connection interrupted/i);assert.match(result.tokens,/unavailable/i);
 const reporting=exp.stateFor({role:'assistant',mode:'agent',streaming:true,agentProgress:{tokenUsage:{providerReported:true,providerTotalTokens:4567}}});
 assert.match(reporting.tokens,/4,567/);
});
test('recovery pointer contains only stable IDs and expires safely',()=>{
 const now=Date.now();const marker={conversationId:'123',userMessageId:99,createdAt:now};
 assert.deepEqual(exp.recoveryRecord({...marker,prompt:'secret',apiKey:'secret'}),marker);
 const history=[{role:'user',id:99,content:'question'}];
 assert.equal(exp.shouldRecover(marker,history,now),true);
 assert.equal(exp.shouldRecover(marker,[...history,{role:'assistant',content:'saved'}],now),false);
 assert.equal(exp.shouldRecover(marker,history,now+3600001),false);
 assert.equal(exp.recoveryRecord({conversationId:'a',userMessageId:0,createdAt:now}),null);
});
test('UX144 DOM includes durable status strip, recovery & history controls',()=>{
 assert.match(html,/chat-experience144\.js\?v=144/);
 assert.match(html,/id="runStatusStrip"/);assert.match(html,/id="earlierMessagesBtn"/);
 assert.match(app,/function renderRunStatusStrip\(/);assert.match(app,/function watchRecoveringChat\(/);
 assert.match(app,/storageSet\('session','llm\.lastSelectedChat144'/);
 assert.match(app,/function showEarlierMessages\(/);assert.match(css,/\.eliya-run-strip/);
});

test('Chat stop preserves uncertain backend outcomes and accepts only confirmed server stop',()=>{
 const unconfirmed=exp.stateFor({role:'assistant',mode:'chat',chatStopRequested:true,chatStopConfirmed:false,streaming:false});
 assert.equal(unconfirmed.status,'unknown');assert.match(unconfirmed.title,/unconfirmed/);
 const accepted=exp.stateFor({role:'assistant',mode:'chat',chatStopRequested:true,chatStopConfirmed:true,streaming:false});
 assert.equal(accepted.status,'cancelled');assert.match(accepted.title,/stop accepted/);
 const stopped=exp.stateFor({role:'assistant',mode:'chat',chatStopped:true,streaming:false});
 assert.match(stopped.title,/stopped by server/);
 assert.match(app,/if \(event === 'stopped'\)/);
 assert.doesNotMatch(app,/if\(assistant\.mode==='chat'\)clearPendingChatRecovery\(state\.conversationId\);\s*if \(state\.agentWatchdogCompleted\)/);
});

test('Agent stop keeps watching durable server state after local SSE abort',()=>{
 const stopping=exp.stateFor({role:'assistant',mode:'agent',agentStopRequested:true,agentStopConfirmed:true,streaming:true,agentBackendStatus:'running',agentConnectionStatus:'recovering'});
 assert.match(stopping.title,/checking backend/);assert.equal(stopping.verified,false);
 const uncertain=exp.stateFor({role:'assistant',mode:'agent',agentStopRequested:true,agentStopConfirmed:false,streaming:true,agentBackendStatus:'running'});
 assert.match(uncertain.title,/unconfirmed/);
 assert.match(app,/keepAgentWatchAfterTransportFailure=true;\s*assistant\.streaming=true;\s*assistant\.agentConnectionStatus='recovering'/);
});
