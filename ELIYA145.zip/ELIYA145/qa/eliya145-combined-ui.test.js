'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const src=path.resolve(__dirname,'../src/main/resources/static');
const dash=require(path.join(src,'execution-dashboard145.js'));
const status=require(path.join(src,'chat-experience144.js'));
const code=fs.readFileSync(path.join(src,'app.js'),'utf8');
const html=fs.readFileSync(path.join(src,'index.html'),'utf8');
const css=fs.readFileSync(path.join(src,'app.css'),'utf8');
function agent(other={}){return {role:'assistant',mode:'agent',streaming:true,agentRunId:'run-01',agentBackendStatus:'running',
 agentProgress:{phase:'executing',status:'running',percent:53,tokenUsage:{providerReported:false,
 stageTimeMs:{planning:910,tools:4010}},plan:[{index:1,text:'Write code',status:'completed'},
 {index:2,text:'Run tests',status:'in_progress'}]},agentSteps:[{tool:'test',status:'approval',approvalId:'approval145',detail:'Should delete file?'},
 {tool:'shell',status:'running',detail:'Running tests'}],...other};}
test('one evidence view combines Agent and Analyse without hidden model work',()=>{
 const current=dash.fromMessage(agent(),status);
 assert.equal(current.view.agent,true);assert.equal(current.view.verified,false);
 assert.equal(current.plan.length,2);assert.equal(current.events.length,2);
 assert.equal(current.approvals.length,1);assert.equal(current.tokens,'Unavailable');
 assert.equal(current.stages[0].duration,'910 ms');
 const analyse=dash.fromMessage({role:'assistant',mode:'chat',streaming:true,chatLoadingStatus:'Analysing'},status);
 assert.equal(analyse.view.agent,false);assert.equal(analyse.plan.length,0);assert.equal(analyse.approvals.length,0);
});
test('never infer verification from 100% or missing provider counters',()=>{
 const result=dash.fromMessage(agent({agentProgress:{percent:100,tokenUsage:{providerTotalTokens:0}},agentBackendStatus:'running'}),status);
 assert.equal(result.view.verified,false);assert.equal(result.tokens,'Unavailable');
 assert.equal(result.view.percent,null);
});
test('the integrity label separates sealed historical report from current filesystem check',()=>{
 assert.match(dash.fromMessage(agent({agentCompletionReport:{filesVerified:true}}),status).artifacts,/not checked/i);
 assert.match(dash.fromMessage(agent({agentFileIntegrity:{status:'changed_or_missing'}}),status).artifacts,/missing|changed/i);
 assert.match(dash.fromMessage(agent({agentFileIntegrity:{intact:true,status:'intact'}}),status).artifacts,/hashes match/i);
});
test('safe bounds on adversarial tool events and plans',()=>{
 const text='<img src=x onerror=alert(1)>'.repeat(40);
 const result=dash.fromMessage(agent({agentSteps:Array.from({length:800},()=>({tool:text,detail:text,status:'running'})),
 agentProgress:{plan:Array.from({length:300},()=>({text})),tokenUsage:{}}}),status);
 assert.equal(result.events.length,20);assert.equal(result.plan.length,120);
 assert.ok(result.events.every(x=>x.tool.length<=85&&x.detail.length<=220));
});
test('single requirement supplies dashboard, robust recovery, and file-integrity endpoints',()=>{
 assert.match(html,/id="executionDashboard145"/);assert.match(html,/aria-controls="executionDashboard145"/);
 assert.match(html,/execution-dashboard145\.js\?v=145/);assert.match(code,/renderExecutionDashboard145/);
 assert.match(code,/llm\.lastSelectedChat145/);assert.match(code,/storageSet\('local',pendingKey\(conversationId\)/);
 assert.match(code,/\/api\/agent\/runs\/\$\{encodeURIComponent\(message\.agentRunId\)\}\/file-integrity/);
 assert.match(css,/forced-colors:active/);assert.match(css,/prefers-reduced-motion:reduce/);
 const vault=fs.readFileSync(path.resolve(src,'../../java/com/llmart/llm/service/ArtifactVaultService.java'),'utf8');
 assert.match(vault,/sha256\(byte\[\] bytes\)/);assert.match(vault,/"checksum_mismatch"/);
 const ctl=fs.readFileSync(path.resolve(src,'../../java/com/llmart/llm/controller/AgentController.java'),'utf8');
 assert.match(ctl,/\/runs\/\{id\}\/file-integrity/);
});
