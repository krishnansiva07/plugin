package com.fasterxml.jackson.databind;
import java.io.*;
import java.nio.file.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import com.llmart.llm.service.ArtifactVaultService.Entry;
/** Small offline shim for JDK-only checksum smoke. NOT an actual Jackson test. */
public class ObjectMapper {
    public void writeValue(File file,Object value) throws IOException {
        List<?> list=(List<?>)value;
        List<String> rows=new ArrayList<>();
        for(Object o:list){Entry e=(Entry)o;
            rows.add(String.join("\t",e.id(),e.path(),e.operation(),Integer.toString(e.bytes()),
                e.sha256()==null?"":e.sha256()));}
        Files.write(file.toPath(),rows,StandardCharsets.UTF_8);
    }
    public <T>T readValue(String source,Class<T> type) throws IOException {throw new IOException("Structured metadata not needed for offline test");}
    @SuppressWarnings("unchecked") public <T>T readValue(File file,Class<T> type) throws IOException {
        if(type==Entry[].class){
            List<Entry> out=new ArrayList<>();
            for(String row:Files.readAllLines(file.toPath(),StandardCharsets.UTF_8)){
                String[] parts=row.split("\t",-1);
                out.add(new Entry(parts[0],parts[1],parts[2],Integer.parseInt(parts[3]),
                    parts.length>4&&!parts[4].isEmpty()?parts[4]:null));}
            return (T)out.toArray(Entry[]::new);
        }
        throw new IOException("Unsupported shim read");
    }
}
