package com.llmart.llm.service;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.nio.file.*;
import java.nio.charset.StandardCharsets;
import java.io.*;
import java.util.*;
public class ArtifactIntegritySmoke145 {
    static void check(boolean okay,String message){if(!okay)throw new AssertionError(message);}
    static String content(String body){return "<!-- PROJECT_FILE_START:src/test.md -->\n"+body+"\n<!-- PROJECT_FILE_END -->";}
    public static void main(String[] args)throws Exception{
        Path root=Files.createTempDirectory("eliya145-vault-");
        System.setProperty("eliya.artifacts.store",root.toString());
        String conversation="3e94b5d4-3b0f-4e7c-a287-7c575584e2e0";
        ArtifactVaultService vault=new ArtifactVaultService(new ObjectMapper());
        var created=vault.archive(conversation,11,content("hello world"));
        check(created.size()==1,"Not archived");
        var file=created.get(0);
        check(file.sha256()!=null&&file.sha256().length()==64,"No SHA-256");
        check("verified".equals(vault.verify(conversation,11).get(0).status()),"Good file not verified");
        check("hello world".equals(vault.get(conversation,11,file.id()).content()),"Fidelity failed");
        Path body=root.resolve(conversation).resolve("11").resolve(file.id()+".txt");
        Files.writeString(body,"jello world",StandardCharsets.UTF_8);
        check("checksum_mismatch".equals(vault.verify(conversation,11).get(0).status()),"Same-size corruption not caught");
        boolean blocked=false;try{vault.get(conversation,11,file.id());}catch(IOException expected){blocked=true;}
        check(blocked,"Corrupt download not rejected");
        Files.delete(body);
        check("missing".equals(vault.verify(conversation,11).get(0).status()),"Missing file not detected");
        String other="ecbdbba3-86d1-49eb-8b1a-9901d0a7ee71";
        var older=vault.archive(other,12,content("legacy"));
        Path manifest=root.resolve(other).resolve("12").resolve("manifest.json");
        String record=Files.readString(manifest);
        Files.writeString(manifest,record.substring(0,record.lastIndexOf('\t'))+"\t\n");
        check("legacy_length_only".equals(vault.verify(other,12).get(0).status()),"Legacy was falsely verified");
        System.out.println("ELIYA145 Java artifact-integrity smoke PASS (SHA-256, missing, corruption, legacy)");
    }
}
