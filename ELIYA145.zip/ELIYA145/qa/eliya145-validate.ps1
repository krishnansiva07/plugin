# ELIYA145 combined acceptance on Windows; no browser download.
# Requires Java 17+, Node 20+, Python Playwright + installed Chrome/Edge.
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
Push-Location $root
try {
  foreach ($script in @('app.js','execution-dashboard145.js','chat-experience144.js')) {
    & node --check "src/main/resources/static/$script"
    if ($LASTEXITCODE -ne 0) { throw "Syntax failure: $script" }
  }
  $tests = @(Get-ChildItem 'src/test/js/*.test.js','qa/*.test.js' | ForEach-Object { $_.FullName })
  & node --test @tests
  if ($LASTEXITCODE -ne 0) { throw 'JavaScript regressions failed' }
  foreach ($script in @('qa/eliya143_browser_ui.py','qa/eliya144_browser_ui.py','qa/eliya145_browser_ui.py')) {
    & python $script
    if ($LASTEXITCODE -ne 0) { throw "Browser acceptance failure: $script" }
  }
  $bash = Get-Command bash -ErrorAction SilentlyContinue
  if ($bash -and (Get-Command javac -ErrorAction SilentlyContinue)) {
    & bash 'qa/eliya145-java-integrity-smoke.sh'
    if ($LASTEXITCODE -ne 0) { throw 'Java artifact integrity smoke failed' }
  } else {
    Write-Warning 'JDK-only integrity smoke requires javac and Bash/WSL: run qa/eliya145-java-integrity-smoke.sh when available.'
  }
  Write-Host 'ELIYA145 source/UI checks passed. Perform a Maven build and live Agent/LLM/MCP acceptance separately.'
}
finally { Pop-Location }
