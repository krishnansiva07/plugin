from __future__ import annotations
import json, os, shutil, sys, re
from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]/'src/main/resources/static'
REPORT=Path(__file__).resolve().parents[1]/'qa/screenshots-145'
REPORT.mkdir(parents=True,exist_ok=True)
markup=(ROOT/'index.html').read_text()
markup=re.sub(r'<link rel="stylesheet" href="/([^?"]+)[^"]*"\s*/>',
  lambda m:'<style>'+(ROOT/m.group(1)).read_text()+'</style>',markup)
markup=re.sub(r'<script src="/([^?"]+)[^"]*"></script>',
  lambda m:'<script>'+(ROOT/m.group(1)).read_text().replace('</script','<\\/script')+'</script>',markup)
backendUser={'id':100,'role':'user','content':'Analyze the mapped project','createdAt':'2026-11-14T08:00:00Z'}
def synthetic_document(session=None, local=None):
    # Local storage stub models the same session record across a new document.
    # All backend calls are stubbed and no prompts are sent to a model.
    # A real HTTP reload is not possible in this locked-down Chromium container.
    shim="""<script>
      window.__storage144 = __SESSION144__;
      const store = initial => ({
        _data: {...initial}, getItem(k){return this._data[k]??null},
        setItem(k,v){this._data[k]=String(v)}, removeItem(k){delete this._data[k]}
      });
      Object.defineProperty(window,'sessionStorage',{configurable:true,value:store(window.__storage144)});
      Object.defineProperty(window,'localStorage',{configurable:true,value:store(__LOCAL145__)});
      window.__mockBackendAnswer144 = null;
      window.__cancelAck144 = false;
      window.__agentSnapshot145 = {id:"agent145",status:"running",progressPhase:"executing",progressDetail:"Checking test execution",progressPercent:53,tokenUsage:{providerReported:true,providerTotalTokens:542}};
      window.__fileIntegrity145 = {available:true,status:"changed_or_missing",intact:false,issues:["Missing expected test file"],totalFiles:1,checked:1};
      window.__serverAgentRequests145=0;
      window.fetch = async function(url,opts={}) {
        const route=String(url).split('?')[0];
        let body={};
        if(route==='/api/agent/runs/agent145/file-integrity')body=window.__fileIntegrity145;
        else if(route==='/api/agent/runs/agent145'){window.__serverAgentRequests145++;body=window.__agentSnapshot145;}
        else if(route==='/api/chat/cancel')body={cancelled:window.__cancelAck144};
        else if(route==='/api/agent/runs/agent144/cancel')body={cancelled:true};
        else if(route==='/api/conversations')body=[{id:'c1',title:'Recovery test'}];
        else if(route==='/api/conversations/c1/messages')body=[__BACKEND_USER144__,
          ...(window.__mockBackendAnswer144?[{id:101,role:'assistant',mode:'chat',
            content:window.__mockBackendAnswer144,createdAt:'2026-11-14T08:01:00Z'}]:[])];
        else if(route.startsWith('/api/agent/conversations/') || route.startsWith('/api/files') ||
          route.startsWith('/api/projects') || route==='/api/terminal/sessions' ||
          route==='/api/agent/runs/recent')body=[];
        else if(route==='/api/cli/setup-state')body={readyInNewTerminals:true};
        return new Response(JSON.stringify(body),{status:200,headers:{'Content-Type':'application/json'}});
      };
    </script>"""
    shim=shim.replace('__SESSION144__',json.dumps(session or {})).replace('__BACKEND_USER144__',json.dumps(backendUser)).replace('__LOCAL145__',json.dumps(local or {}))
    return markup.replace('</head>',shim+'</head>',1)
with sync_playwright() as pw:
    candidates=[os.environ.get('ELIYA_BROWSER_BIN'),shutil.which('chromium'),shutil.which('google-chrome'),shutil.which('microsoft-edge')]
    if os.name=='nt':
        for base in (os.environ.get('PROGRAMFILES'),os.environ.get('PROGRAMFILES(X86)'),os.environ.get('LOCALAPPDATA')):
            if base:
                candidates.extend(str(Path(base)/relative) for relative in ('Google/Chrome/Application/chrome.exe','Microsoft/Edge/Application/msedge.exe'))
    executable=next((x for x in candidates if x and Path(x).is_file()),None)
    if not executable:
        print('SKIP: Chrome/Edge/Chromium is not installed; no automatic download');sys.exit(2)
    browser=pw.chromium.launch(executable_path=executable,headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
    context=browser.new_context(viewport={'width':1440,'height':900},accept_downloads=True)
    page=context.new_page();errors=[]
    page.on('pageerror',lambda error:errors.append(str(error)))
    page.set_content(synthetic_document(),wait_until='domcontentloaded',timeout=30000)
    page.wait_for_function('window.EliyaExecutionDashboard145 && typeof renderMessages === "function"')
    page.evaluate("""() => {
      state.conversationId='c1';state.messages=[{role:'user',id:100,content:'Implement the migration'},
        {role:'assistant',id:101,mode:'agent',content:'The Agent is running.',streaming:true,
          agentRunId:'agent145',agentBackendStatus:'running',agentConnectionStatus:'connected',
          agentSteps:[{tool:'file_write',status:'approval',approvalId:'ap145',detail:'Approve modified file'},
            {tool:'selenium_test',status:'success',detail:'Executed 2 tests'}],
          agentProgress:{status:'running',phase:'executing',percent:53,detail:'Applying fixes',
            plan:[{index:1,text:'Inspect sources',status:'completed'},{index:2,text:'Run tests',status:'in_progress'}],
            tokenUsage:{providerReported:true,providerTotalTokens:4215,stageTimeMs:{planning:1500,tools:3200}},
            question:{id:'q145',kind:'clarification',reason:'Should I use Chrome or Edge?'}}}];
      renderMessages();
    }""")
    assert page.locator('#runStatusStrip').is_visible()
    page.locator('#runStatusOpen').click()
    assert page.locator('#executionDashboard145').is_visible()
    assert page.locator('#runStatusOpen').get_attribute('aria-expanded')=='true'
    assert page.evaluate('document.activeElement.id')=='executionDashboardTitle'
    contrast=page.evaluate("""() => {
      const ratio=(a,b)=>{
        const values=x=>{let c=getComputedStyle(document.querySelector(x));return [c.color,c.backgroundColor]};
        const decode=s=>{const parts=s.match(/[0-9.]+/g)?.map(Number)||[0,0,0];return parts.slice(0,3).map(v=>{v=v/255;return v<=.04045?v/12.92:((v+.055)/1.055)**2.4});};
        const lum=x=>{let v=decode(x);return .2126*v[0]+.7152*v[1]+.0722*v[2]};
        const x=lum(a),y=lum(b);return (Math.max(x,y)+.05)/(Math.min(x,y)+.05);
      };
      const list=['.eliya-dashboard-metric strong','.eliya-dashboard-metric small'];
      return list.map(key=>{const el=document.querySelector(key),style=getComputedStyle(el);
        const parent=getComputedStyle(el.closest('.eliya-dashboard-metric'));
        return {selector:key,ratio:ratio(style.color,parent.backgroundColor)};});
    }""")
    assert all(x['ratio']>=4.5 for x in contrast),contrast
    page.keyboard.press('Escape')
    assert page.locator('#executionDashboard145').is_hidden()
    assert page.evaluate('document.activeElement.id')=='runStatusOpen'
    page.locator('#runStatusOpen').click()
    assert '4,215' in page.locator('#executionDashboard145').inner_text()
    assert 'Stage timings' in page.locator('#executionDashboard145').inner_text()
    assert '1.5 s' in page.locator('#executionDashboard145').inner_text()
    assert 'Current file integrity not checked' in page.locator('#executionDashboard145').inner_text()
    assert 'not yet verified' in page.locator('#executionDashboard145').inner_text().lower()
    assert page.locator('#executionDashboardBody [data-dashboard-approval]').count()==1
    page.screenshot(path=str(REPORT/'dashboard-desktop.png'),full_page=False)
    page.set_viewport_size({'width':390,'height':844})
    page.evaluate("document.getElementById('sidebar')?.classList.remove('open')")
    page.wait_for_timeout(260)
    assert page.evaluate('document.documentElement.scrollWidth <= window.innerWidth+2')
    page.screenshot(path=str(REPORT/'dashboard-mobile.png'),full_page=False)
    page.set_viewport_size({'width':1440,'height':900})
    page.locator('#executionDashboardBody [data-dashboard-question]').click()
    assert page.locator('#executionDashboard145').is_hidden()
    assert page.evaluate("document.activeElement.id")=='messageInput'
    page.locator('#runStatusOpen').click()
    page.locator('#executionDashboardFiles').click()
    page.wait_for_function('state.messages[1].agentFileIntegrity?.status==="changed_or_missing" && document.querySelector("#executionDashboardBody").textContent.includes("Workspace changed")')
    assert 'Workspace changed or files missing' in page.locator('#executionDashboardBody').inner_text()
    assert 'Missing expected test file' in page.locator('#executionDashboardBody').inner_text()
    page.locator('#executionDashboardRefresh').click()
    page.wait_for_function('window.__serverAgentRequests145===1')
    assert page.evaluate('state.messages[1].agentBackendStatus')=='running'
    page.locator('#executionDashboardClose').click()
    assert page.locator('#runStatusOpen').get_attribute('aria-expanded')=='false'
    assert page.evaluate('document.activeElement.id')=='runStatusOpen'
    page.evaluate("""() => {state.messages[1].agentProgress.percent=100;renderMessages();}""")
    assert 'Running' in page.locator('#runStatusTitle').inner_text()
    page.evaluate("""() => {state.messages[1].agentSteps.push({tool:'<img src=x onerror=window.__xss145=true>',status:'running',detail:'<svg onload=window.__xss145=true>'});renderMessages();}""")
    page.locator('#runStatusOpen').click()
    assert page.evaluate('window.__xss145') is None
    prompt='# Migration prompt\n\n'+'\n'.join('Step %d: migrate Selenium page and verify.'%i for i in range(1,5001))
    perf=page.evaluate('''text=>{
      state.messages=[{role:'user',content:'Generate full migration prompt'},{role:'assistant',mode:'chat',content:text,streaming:false}];
      const before=performance.now();renderMessages();
      const first=performance.now()-before;
      const count=document.querySelectorAll('#messages *').length;
      let total=0;for(let i=0;i<25;i++){const start=performance.now();renderMessages();total+=performance.now()-start;}
      return {firstMs:first,averageRerenderMs:total/25,visibleElements:count};
    }''',prompt)
    assert page.locator('.eliya-prompt-card').count()==1
    assert perf['visibleElements']<1500,perf
    with page.expect_download() as event:page.locator('[data-prompt-download]').first.click()
    assert Path(event.value.path()).read_text()==prompt
    print('ELIYA145 observed 5000-line render profile:',json.dumps(perf))
    for width,height in ((320,700),(390,844),(768,900),(1440,900)):
        page.set_viewport_size({'width':width,'height':height})
        assert page.evaluate('document.documentElement.scrollWidth <= window.innerWidth+2'),f'horizontal overflow at {width}px'
    page.emulate_media(reduced_motion='reduce',forced_colors='active')
    assert page.evaluate("matchMedia('(prefers-reduced-motion:reduce)').matches")
    assert page.evaluate("matchMedia('(forced-colors:active)').matches")
    page.evaluate("""() => {storageSet('local','llm.lastSelectedChat145','c1');}""")
    local=page.evaluate('({...window.localStorage._data})')
    assert local.get('llm.lastSelectedChat145')=='c1'
    assert 'Implement the migration' not in str(local)
    page.close();page=context.new_page();page.on('pageerror',lambda error:errors.append(str(error)))
    page.set_content(synthetic_document(local=local),wait_until='domcontentloaded')
    page.wait_for_function('state.conversationId==="c1"',timeout=12000)
    assert page.locator('.history-loading').count()==0
    page.screenshot(path=str(REPORT/'desktop.png'),full_page=False)
    page.set_viewport_size({'width':390,'height':844})
    page.evaluate("document.getElementById('sidebar')?.classList.remove('open')")
    page.wait_for_timeout(250)
    page.screenshot(path=str(REPORT/'mobile.png'),full_page=False)
    assert not errors,errors[:5]
    print('ELIYA145 Chromium PASS: dashboard, approval/question, backend status, SHA reporting, 5000-line export, 320px, reduced motion and session recovery')
    browser.close()
