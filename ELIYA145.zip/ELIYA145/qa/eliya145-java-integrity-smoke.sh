#!/usr/bin/env bash
set -euo pipefail
BASE="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
STUB="$BASE/qa/eliya145-java-stubs"
OUT="$(mktemp -d)"
trap 'rm -rf "$OUT"' EXIT
javac --release 17 -d "$OUT" \
  "$STUB/org/springframework/stereotype/Service.java" \
  "$STUB/com/fasterxml/jackson/databind/ObjectMapper.java" \
  "$BASE/src/main/java/com/llmart/llm/service/ArtifactVaultService.java" \
  "$STUB/com/llmart/llm/service/ArtifactIntegritySmoke145.java"
java -cp "$OUT" com.llmart.llm.service.ArtifactIntegritySmoke145
