# ELIYA144 offline UI acceptance checks on Windows PowerShell.
# Requires: Node.js 20+, Python 3, pip install playwright, installed Chrome/Edge.
# Does NOT install browsers, execute LLM calls or modify a project workspace.
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
Push-Location $root
try {
  Write-Host 'ELIYA144: JavaScript syntax and UI regression suite'
  & node --check 'src/main/resources/static/app.js'
  if ($LASTEXITCODE -ne 0) { throw 'app.js syntax check failed' }
  & node --check 'src/main/resources/static/chat-experience144.js'
  if ($LASTEXITCODE -ne 0) { throw 'chat-experience144.js syntax check failed' }
  $nodeTests = @(Get-ChildItem 'src/test/js/*.test.js', 'qa/*.test.js' | ForEach-Object { $_.FullName })
  & node --test @nodeTests
  if ($LASTEXITCODE -ne 0) { throw 'Node UI tests failed' }
  Write-Host 'ELIYA144: installed Chrome/Edge acceptance test (no browser downloads)'
  & python 'qa/eliya144_browser_ui.py'
  if ($LASTEXITCODE -ne 0) { throw 'Chromium UI acceptance failed. Set ELIYA_BROWSER_BIN to your chrome.exe/msedge.exe.' }
  Write-Host 'ELIYA144: previous-release browser regressions'
  & python 'qa/eliya143_browser_ui.py'
  if ($LASTEXITCODE -ne 0) { throw 'ELIYA143 browser regression failed' }
  Write-Host 'PASS: UI checks. Build the Spring Boot application separately using Maven.'
}
finally { Pop-Location }
