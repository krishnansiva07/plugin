from __future__ import annotations
import json, os, shutil, sys, re
from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]/'src/main/resources/static'
REPORT=Path(__file__).resolve().parents[1]/'qa/screenshots-144'
REPORT.mkdir(parents=True,exist_ok=True)
markup=(ROOT/'index.html').read_text()
markup=re.sub(r'<link rel="stylesheet" href="/([^?"]+)[^"]*"\s*/>',
  lambda m:'<style>'+(ROOT/m.group(1)).read_text()+'</style>',markup)
markup=re.sub(r'<script src="/([^?"]+)[^"]*"></script>',
  lambda m:'<script>'+(ROOT/m.group(1)).read_text().replace('</script','<\\/script')+'</script>',markup)
backendUser={'id':100,'role':'user','content':'Analyze the mapped project','createdAt':'2026-11-14T08:00:00Z'}
def synthetic_document(session=None):
    # Local storage stub models the same session record across a new document.
    # All backend calls are stubbed and no prompts are sent to a model.
    # A real HTTP reload is not possible in this locked-down Chromium container.
    shim="""<script>
      window.__storage144 = __SESSION144__;
      const store = initial => ({
        _data: {...initial}, getItem(k){return this._data[k]??null},
        setItem(k,v){this._data[k]=String(v)}, removeItem(k){delete this._data[k]}
      });
      Object.defineProperty(window,'sessionStorage',{configurable:true,value:store(window.__storage144)});
      Object.defineProperty(window,'localStorage',{configurable:true,value:store({})});
      window.__mockBackendAnswer144 = null;
      window.__cancelAck144 = false;
      window.fetch = async function(url,opts={}) {
        const route=String(url).split('?')[0];
        let body={};
        if(route==='/api/chat/cancel')body={cancelled:window.__cancelAck144};
        else if(route==='/api/agent/runs/agent144/cancel')body={cancelled:true};
        else if(route==='/api/conversations')body=[{id:'c1',title:'Recovery test'}];
        else if(route==='/api/conversations/c1/messages')body=[__BACKEND_USER144__,
          ...(window.__mockBackendAnswer144?[{id:101,role:'assistant',mode:'chat',
            content:window.__mockBackendAnswer144,createdAt:'2026-11-14T08:01:00Z'}]:[])];
        else if(route.startsWith('/api/agent/conversations/') || route.startsWith('/api/files') ||
          route.startsWith('/api/projects') || route==='/api/terminal/sessions' ||
          route==='/api/agent/runs/recent')body=[];
        else if(route==='/api/cli/setup-state')body={readyInNewTerminals:true};
        return new Response(JSON.stringify(body),{status:200,headers:{'Content-Type':'application/json'}});
      };
    </script>"""
    shim=shim.replace('__SESSION144__',json.dumps(session or {})).replace('__BACKEND_USER144__',json.dumps(backendUser))
    return markup.replace('</head>',shim+'</head>',1)
with sync_playwright() as pw:
    binaries=[os.environ.get('ELIYA_BROWSER_BIN'),shutil.which('chromium'),
      shutil.which('google-chrome'),shutil.which('google-chrome-stable'),
      shutil.which('microsoft-edge'),shutil.which('msedge'),shutil.which('chrome')]
    # Use the installed system browser; never invoke Playwright browser downloads.
    # Windows typically installs Chrome/Edge under Program Files rather than PATH.
    if os.name == 'nt':
        for base in (os.environ.get('PROGRAMFILES'),os.environ.get('PROGRAMFILES(X86)'),
          os.environ.get('LOCALAPPDATA')):
            if not base:continue
            binaries.extend(str(Path(base)/relative) for relative in (
              'Google/Chrome/Application/chrome.exe',
              'Google/Chrome SxS/Application/chrome.exe',
              'Microsoft/Edge/Application/msedge.exe'))
    browser_bin=next((path for path in binaries if path and Path(path).is_file()),None)
    if not browser_bin:
        print('SKIP no installed Chrome/Edge/Chromium; browser auto-download forbidden')
        sys.exit(2)
    browser=pw.chromium.launch(executable_path=browser_bin,headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
    context=browser.new_context(viewport={'width':1400,'height':850},accept_downloads=True)
    page=context.new_page();errors=[]
    page.on('pageerror',lambda error:errors.append(str(error)))
    page.set_content(synthetic_document(),wait_until='domcontentloaded',timeout=30000)
    page.wait_for_function('window.EliyaChatExperience144 && typeof renderMessages === "function"')
    # 5,000-line Markdown remains one source, downloadable byte-for-byte.
    prompt='# Full migration prompt\n\n'+'\n'.join(f'Step {n}: migrate exact Selenium behavior to Playwright TypeScript and verify' for n in range(1,5001))
    page.evaluate('''source => {
      state.conversationId='c1';
      state.visibleMessageStart=0;
      state.messages=[{role:'user',content:'Generate one complete implementation prompt'},
        {role:'assistant',mode:'chat',content:source,streaming:false}];
      renderMessages();
    }''',prompt)
    assert page.locator('.eliya-prompt-card').count()==1,'single prompt was fragmented'
    assert page.locator('.eliya-prompt-text').inner_text()!=prompt,'5k lines were dumped into initial DOM'
    page.locator('[data-inline-source]').click()
    assert page.locator('.eliya-prompt-text').inner_text()==prompt,'expanded prompt altered source bytes'
    # expansion survives refresh of the same selected conversation
    assert page.evaluate('''() => expandedSourceKeys.has(sourceExpandKey(state.messages[1],1,0))''')
    with page.expect_download() as event:page.locator('[data-prompt-download]').click()
    assert Path(event.value.path()).read_text()==prompt,'Markdown export changed 5000-line source'
    # HTML also remains inert; all content is preserved in the full view/export.
    html='<!doctype html>\n<html><head><title>ELIYA 144</title></head><body>\n'+'\n'.join(f'<div data-row="{i}">Row {i}</div>' for i in range(5000))+'\n<script>window.__XSS_144=true</script>\n</body></html>'
    page.evaluate('''source=>{ state.messages=[{role:'user',content:'Create complete downloadable HTML file'},
      {role:'assistant',content:source,mode:'chat',streaming:false}];renderMessages(); }''',html)
    assert page.locator('.eliya-source-card').count()==1
    assert page.evaluate('window.__XSS_144') is None
    with page.expect_download() as event:page.locator('[data-file-download]').first.click()
    assert Path(event.value.path()).read_text()==html,'HTML download lost bytes'
    # Single progress rail for both Analyse and Agent; never fabricate success.
    page.evaluate('''() => {state.messages=[{role:'user',content:'Fix issue'},
      {role:'assistant',mode:'agent',content:'Working',streaming:true,agentBackendStatus:'running',agentProgress:{phase:'testing',percent:100,tokenUsage:{providerTotalTokens:0}}}];renderMessages();}''')
    assert 'Running' in page.locator('#runStatusTitle').inner_text()
    assert 'Tokens unavailable' in page.locator('#runStatusMeta').inner_text()
    assert 'verified' not in page.locator('#runStatusTitle').inner_text().lower()
    page.evaluate('''() => {state.messages[1].streaming=false;state.messages[1].agentBackendStatus='completed';
      state.messages[1].agentProgress={phase:'finished',plan:[{status:'blocked'}]};renderMessages();}''')
    assert 'checks need review' in page.locator('#runStatusTitle').inner_text().lower()
    # Cancellation is a backend acknowledgement, not just a browser-side abort.
    page.evaluate('''async () => {
      state.conversationId='c1';state.activeAgentRunId=null;
      state.messages=[{role:'user',id:100,content:'Analyse'},
        {role:'assistant',mode:'chat',content:'partial',streaming:true}];
      markPendingChatRecovery('c1',100);
      state.abortController=new AbortController();
      await stopCurrentRun();
      if(!state.abortController.signal.aborted)throw Error('client stream did not stop');
      if(state.messages[1].chatStopConfirmed!==false)throw Error('stop unconfirmed but shown confirmed');
      if(!pendingChatRecovery('c1'))throw Error('uncertain outcome discarded recovery pointer');
      state.messages[1].streaming=false;renderMessages();
    }''')
    assert 'unconfirmed' in page.locator('#runStatusTitle').inner_text().lower()
    page.evaluate('''async () => {
      window.__cancelAck144=true;
      state.messages[1]={role:'assistant',mode:'chat',content:'partial',streaming:true};
      state.abortController=new AbortController();
      await stopCurrentRun();
      if(!state.messages[1].chatStopConfirmed)throw Error('confirmed stop acknowledgement lost');
      state.messages[1].streaming=false;renderMessages();
    }''')
    assert 'stop accepted' in page.locator('#runStatusTitle').inner_text().lower()
    page.evaluate('''async () => {
      state.activeAgentRunId='agent144';
      state.messages=[{role:'user',id:100,content:'Run tests'},
        {role:'assistant',mode:'agent',agentRunId:'agent144',streaming:true,
          agentBackendStatus:'running',agentConnectionStatus:'connected',agentProgress:{phase:'testing'}}];
      state.abortController=new AbortController();
      await stopCurrentRun();
      if(!state.messages[1].agentStopConfirmed)throw Error('Agent cancellation acknowledgement lost');
      if(!state.abortController.signal.aborted)throw Error('Agent client stream was not aborted');
      renderMessages();
    }''')
    assert 'stop requested' in page.locator('#runStatusTitle').inner_text().lower()
    # Older messages remain in memory, initial DOM is bounded; show earlier explicitly.
    page.evaluate('''() => {state.visibleMessageStart=165;
      state.messages=Array.from({length:250},(_,i)=>({id:i+1000,role:i%2?'assistant':'user',content:'Message '+i}));renderMessages();}''')
    assert page.locator('#messages > .message').count()==85
    assert page.locator('#earlierMessagesWrap').is_visible()
    page.locator('#earlierMessagesBtn').click()
    assert page.locator('#messages > .message').count()==150
    assert page.evaluate('state.messages.length')==250
    # A new Chromium document models refresh with actual persisted session
    # records, without navigation (blocked by container policy).
    page.evaluate("""() => {markPendingChatRecovery('c1',100);
      storageSet('session','llm.lastSelectedChat144','c1');}""")
    seed=page.evaluate("() => ({...window.sessionStorage._data})")
    page.close()
    page=context.new_page()
    page.on('pageerror',lambda error:errors.append(str(error)))
    page.set_content(synthetic_document(seed),wait_until='domcontentloaded',timeout=30000)
    page.wait_for_function('state.conversationId === "c1" && state.messages.some(m=>m.recoveringChat)',timeout=12000)
    assert page.locator('#runStatusStrip').is_visible()
    assert 'checking for saved response' in page.locator('#runStatusTitle').inner_text().lower()
    page.evaluate('(answer) => { window.__mockBackendAnswer144 = answer; }', '## Recovered backend analysis\n\nValidated persisted source with no re-execution.')
    page.wait_for_function('state.messages.some(m=>m.role==="assistant" && (m.content||"").includes("Recovered backend analysis"))',timeout=15000)
    assert not page.evaluate('state.streaming'),'recovery retained a stale busy composer'
    assert page.locator('.history-loading').count()==0,'stale loading placeholder left a visible blank gap'
    assert page.evaluate('pendingChatRecovery("c1")') is None,'recovery pointer should be cleared'
    page.screenshot(path=str(REPORT/'desktop.png'),full_page=False)
    page.set_viewport_size({'width':390,'height':844})
    page.wait_for_timeout(250)
    # No global horizontal scrolling or cut-off Stop/View controls.
    overflow=page.evaluate('document.documentElement.scrollWidth > document.documentElement.clientWidth + 2')
    assert not overflow,'mobile page has horizontal overflow'
    page.screenshot(path=str(REPORT/'mobile.png'),full_page=False)
    assert not errors,'JS browser errors: '+repr(errors)
    context.close();browser.close()
    print('ELIYA144 browser PASS: 5000-line Markdown + HTML exact exports, inert source, lifecycle, history, reload recovery, mobile')

