#!/usr/bin/env bash
# One consolidated, offline UI / agent-recovery / artifact-integrity acceptance gate.
set -euo pipefail
cd "$(dirname "$0")/.."
node --check src/main/resources/static/app.js
node --check src/main/resources/static/execution-dashboard145.js
node --check src/main/resources/static/chat-experience144.js
node --test src/test/js/*.test.js qa/*.test.js
bash qa/eliya142-policy-smoke.sh
bash qa/native-agent-policy-smoke.sh
bash qa/eliya145-java-integrity-smoke.sh
python qa/eliya143_browser_ui.py
python qa/eliya144_browser_ui.py
python qa/eliya145_browser_ui.py
echo 'ELIYA145 source/UI acceptance PASS. Maven build and live provider/MCP E2E must be checked separately.'
