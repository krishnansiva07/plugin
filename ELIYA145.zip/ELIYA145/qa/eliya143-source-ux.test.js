'use strict';
const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const base=path.join(__dirname,'../src/main/resources/static');
const viewer=require(path.join(base,'source-viewer.js'));
const artifacts=require(path.join(base,'response-artifacts.js'));
const app=fs.readFileSync(path.join(base,'app.js'),'utf8');
const html=fs.readFileSync(path.join(base,'index.html'),'utf8');
const css=fs.readFileSync(path.join(base,'app.css'),'utf8');
const longPrompt=Array.from({length:1650},(_,i)=>`Step ${i+1}: migrate scenario and verify source mapping, never omit test evidence`).join('\n');
const largeHtml='<!doctype html>\n<html><head><title>ELIYA report</title></head><body>\n'+Array.from({length:1300},(_,i)=>`<div data-row="${i}">valid source</div>`).join('\n')+'\n</body></html>';

test('batch 1: large prompt is only shortened in explicitly labelled inline preview, never in source',()=>{
 const q='Generate one complete self-contained implementation prompt';
 const full=artifacts.promptSections(q,longPrompt)[0].content;
 const result=viewer.preview(full);
 assert.equal(full,longPrompt);
 assert.equal(result.abbreviated,true);
 assert.ok(result.text.length<=viewer.PREVIEW_CHAR_LIMIT);
 assert.ok(result.text.length<full.length);
 assert.ok(viewer.label(result).includes('Open full view'));
 assert.ok(viewer.label(result).includes('complete source'));
 assert.ok(full.endsWith('never omit test evidence'));
});
test('batch 1: 1300-line HTML stays complete for download and preview is lightweight',()=>{
 const src=artifacts.sourceView('Create downloadable HTML file',largeHtml);
 assert.equal(src.content,largeHtml);
 assert.equal(src.ready,true);
 const preview=viewer.preview(src.content);
 assert.equal(preview.abbreviated,true);
 assert.ok(preview.hiddenLines>100);
 assert.equal(viewer.overview(src.content).chars,largeHtml.length);
});
test('batch 1: tiny text is unchanged and escaped source can contain malicious markup safely',()=>{
 assert.deepEqual(viewer.preview('hello'),{text:'hello',abbreviated:false,hiddenChars:0,hiddenLines:0,chars:5,lines:1});
 assert.ok(!/<script/i.test(viewer.preview('abc').text));
 const suspicious='<script>alert(1)</script>'.repeat(1000);
 assert.equal(viewer.preview(suspicious).text,suspicious.slice(0,12000));
 assert.match(app,/esc\(htmlExpanded \? sourceFile\.content : htmlPreview\.text\)/);
 assert.match(app,/esc\(sourcePreview\.text\)/);
});
test('batch 1: inline expansion recomputes from saved message, not preview DOM',()=>{
 assert.match(app,/data-inline-source/);
 assert.match(app,/pre\.textContent=expanded \? inlineSourcePreview\(full\)\.text : full/);
 assert.match(app,/data-prompt-copy/);
 assert.match(app,/downloadText\(scope\.ready\?filename/);
 assert.match(app,/downloadText\(file\.filename,file\.content/);
});
test('batch 2: independently keyed streaming renders, cancels pending final renders',()=>{
 assert.match(app,/const streamingRenderTimers = new Map\(\)/);
 assert.match(app,/streamingRenderTimers\.has\(index\)/);
 assert.match(app,/function cancelStreamingRenders\(\)/);
 assert.match(app,/cancelStreamingRenders\(\);/);
 assert.match(app,/if \(!shouldForce && state\.userScrolledUp\) return/);
 assert.match(app,/const anchorIndex = readingAnchor\?\.dataset\.messageIndex/);
});
test('batch 3: contextual follow-up only on current complete response',()=>{
 assert.match(app,/const suggestion = isLastAssistant && !message\.streaming/);
 assert.match(css,/prefers-reduced-motion:reduce/);
 assert.match(app,/let runMarkdownFocusReturn = null/);
 assert.match(app,/runMarkdownFocusReturn\?\.isConnected/);
});
test('release HTML loads the new source viewer before app and bumps cache keys',()=>{
 assert.match(html,/source-viewer\.js\?v=143/);
 assert.match(html,/app\.js\?v=145/);
 assert.ok(html.indexOf('source-viewer.js?v=143')<html.indexOf('app.js?v=145'));
 assert.match(html,/app\.css\?v=145/);
});
