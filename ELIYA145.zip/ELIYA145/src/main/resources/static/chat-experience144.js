/* ELIYA144 · Unified chat/Agent lifecycle and bounded recovery metadata.
 * Pure functions by design: no model calls, no fabricated progress and no
 * prompt/content stored in browser session metadata.
 */
(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  if (root) root.EliyaChatExperience144 = api;
})(typeof window !== 'undefined' ? window : null, function () {
  'use strict';
  const TERMINAL = new Set(['completed','failed','blocked','cancelled','interrupted','stalled']);
  const ACTIVE = new Set(['running','queued','waiting_workspace','cancelling','needs_input','starting']);
  const safe = value => String(value == null ? '' : value).replace(/\s+/g, ' ').trim();
  const clamp = (value, length=170) => safe(value).slice(0,length);
  const number = value => Number.isFinite(Number(value)) && Number(value) >= 0 ? Number(value) : 0;
  const asStatus = value => safe(value).toLowerCase().replace(/\s+/g,'_');
  const labelFor = status => ({completed:'Completed',failed:'Failed',blocked:'Blocked',cancelled:'Cancelled',
    interrupted:'Interrupted',stalled:'Stalled',needs_input:'Input required',cancelling:'Cancelling',
    waiting_workspace:'Waiting for workspace',queued:'Queued',running:'Running',starting:'Starting',
    unknown:'Outcome unverified'})[status] || 'Working';
  function stateFor(message, {connected=true}={}) {
    if (!message || message.role !== 'assistant') return null;
    const agent=message.mode==='agent';
    const p=message.agentProgress||{};
    const backend=asStatus(message.agentBackendStatus||p.status|| (message.streaming?'running':'unknown'));
    const connectedState=asStatus(message.agentConnectionStatus||'');
    const streaming=Boolean(message.streaming);
    const isTerminal=agent ? TERMINAL.has(backend) && !streaming : !streaming;
    const warning=Boolean(message.chatHealthDetail);
    const phase=clamp(agent ? (p.phase||'Working') : (message.chatLoadingStatus|| (streaming?'Generating analysis':'Analysis ready')),60);
    const detail=clamp(agent ? (p.detail||'') : (message.chatHealthDetail || message.chatContinuationDetail || 'Generating response'),190);
    const incomplete=Boolean((p.plan||[]).some(item=>item.status && item.status!=='completed')
      || number(p.workItemSummary?.failed)>0 || (p.verificationFailures||[]).length>0);
    const verified=agent && isTerminal && backend==='completed' && !incomplete;
    let status=agent ? backend : streaming ? (warning?'stalled':'running') : message.chatStopped||message.chatStopConfirmed?'cancelled' : message.chatStopRequested?'unknown':'completed';
    let title=agent ? (verified?'Completed · backend verified':backend==='completed'?'Completed · checks need review':labelFor(backend)) :
      streaming ? (warning?'Analyse · waiting for progress':'Analyse · responding') : 'Analyse · response saved';
    if (streaming && agent && (connectedState==='disconnected'||connectedState==='recovering')) title='Agent · connection interrupted';
    if (agent && streaming && message.agentStopRequested) title=message.agentStopConfirmed
      ? 'Agent · stop requested, checking backend' : 'Agent · stop unconfirmed';
    if (!agent && message.recoveringChat) title='Analyse · checking for saved response';
    if (!agent && message.chatStopped) title='Analyse · stopped by server';
    if (!agent && !streaming && message.chatStopRequested && !message.chatStopped) title=message.chatStopConfirmed?'Analyse · stop accepted':'Analyse · stop unconfirmed';
    if (agent && !isTerminal && !ACTIVE.has(backend)) title='Agent · outcome unverified';
    const usage=p.tokenUsage||{};
    const reported=usage.providerReported===true;
    const tokens=reported ? number(usage.providerTotalTokens).toLocaleString()+' reported tokens' : 'Tokens unavailable';
    const steps=Array.isArray(p.plan)?p.plan:[];
    const current=steps.find(item=>item.status==='in_progress'||item.status==='blocked');
    const stepLabel=current ? `Step ${current.index||steps.indexOf(current)+1} · ${clamp(current.title||current.description||current.note||'In progress',90)}`
      : steps.length ? `${steps.filter(s=>s.status==='completed').length}/${steps.length} plan steps complete` : '';
    const recent=Array.isArray(message.agentSteps) ? message.agentSteps.at(-1) : null;
    const tool=recent?.tool && recent.tool!=='plan_approval' ? clamp(recent.tool,42) : '';
    const pct=Number(p.percent);
    const percent=streaming && agent && !p.indeterminate && Number.isFinite(pct) && pct>=0 && pct<100
      ? Math.min(99,Math.round(pct)) : null;
    return {agent,streaming,status,title,phase,detail,verified,incomplete,terminal:isTerminal,
      needsInput:backend==='needs_input'||Boolean(p.question?.id), disconnected:agent && streaming && ['disconnected','recovering'].includes(connectedState),
      stepLabel,tool,tokens,percent,estimated:percent!=null,warning,
      show:streaming || agent || Boolean(message.recoveringChat||message.chatStopRequested||message.chatStopped),connected};
  }
  function recoveryRecord(input) {
    const value=input||{};
    const conversationId=safe(value.conversationId);
    const userMessageId=Number(value.userMessageId);
    const createdAt=Number(value.createdAt);
    if (!conversationId || conversationId.length>100 || !Number.isSafeInteger(userMessageId) || userMessageId<=0 ||
      !Number.isFinite(createdAt) || createdAt<=0 || createdAt>Date.now()+60_000) return null;
    return {conversationId,userMessageId,createdAt};
  }
  function shouldRecover(record,messages,now=Date.now()) {
    const pending=recoveryRecord(record);
    if(!pending || now-pending.createdAt>60*60_000) return false;
    const list=Array.isArray(messages)?messages:[];
    const position=list.findIndex(m=>m.role==='user' && Number(m.id)===pending.userMessageId);
    if(position<0)return false;
    return !list.slice(position+1).some(m=>m.role==='assistant' && !m.syntheticAgentRun && String(m.content||'').trim());
  }
  return Object.freeze({stateFor,recoveryRecord,shouldRecover,TERMINAL});
});
