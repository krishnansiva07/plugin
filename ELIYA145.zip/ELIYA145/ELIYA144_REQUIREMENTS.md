# ELIYA144 — Seven UI/UX Acceptance Requirements

**Input baseline:** ELIYA143 source. **Date:** 2026-11-14. **Release type:** source-only; no prebuilt JAR or measured provider tokens.

This is an incremental, behavior-focused interface redesign preserving the existing Analyse → Agent split, approval gates, workspace/reference mapping, token-reporting integrity and independently running Agent engine. The previous ELIYA142 agent optimizations and ELIYA143 prompt fixes remain intact.

## Batched delivery and acceptance

| Batch | User requirement | Implemented source behavior | Validation and limitations |
|---|---|---|---|
| **144-01** | Complete chat interface redesign | Added persistent, readable **current-task status rail** integrated into the existing chat layout; compact responsive status/actions, keyboard-readable announcer, bounded conversation history, improved compact source/Markdown styling, existing mobile Analyse/Agent/Models single row preserved | **UI source implemented, Chromium fixture checked.** This is a major interaction and layout improvement, **not a claim that every screen or entire design system has been rebuilt**. Full WCAG/device audit pending. |
| **144-02** | Smooth rendering of 1,000–5,000-line prompts | Kept ELIYA143 parser fix: `Step 1`, `Step 2` etc. stay inside one prompt, never split into many. Long sources have compact previews, explicit expansion, source details and full-content export. Only 85 latest messages initially in the DOM, with explicit 65-message incremental loading | **Passed installed Chromium** using 5,000-line Markdown and 250-message history. Production performance with real provider streaming not measured. |
| **144-03** | Fix empty space in code/Markdown | Removed a stale `.history-loading` element left behind after diff reconciliation; tightened code/pre/source card spacing and width overflow rules; preserve scroll anchor while inspecting long output | **Passed Chromium**: no leftover loading placeholder or mobile page horizontal overflow. More CSS permutations/devices pending. |
| **144-04** | Reliable long HTML/Markdown with copy/download | Existing source-viewer contracts preserved: download and copy derive from original complete content, not preview; HTML shown inert as source; full source expand state retained for selected conversation | **Passed Chromium** with 5,000-line Markdown and 5,000 HTML rows, exact exported bytes, and no inline HTML script execution. Server-generated artifact persistence/end-to-end delivery not tested. |
| **144-05** | Dynamic context-relevant follow-ups | Preserved ELIYA143’s latest-answer-only, context-derived follow-up gating, without injecting generic questions into historic replies | **Passed existing Node/Chromium regressions**. Live model relevance remains model-dependent; not claimed perfect. |
| **144-06** | Better streaming, cancellation and stuck-chat recovery | Preserved ELIYA143 first-chunk deduplication, throttled per-message rendering and scroll stability. Added ID-only session recovery for interrupted Chat (poll durable messages, do **not** replay prompt), last selected chat reopen, status of disconnected/unconfirmed response. Chat Stop distinguishes `cancelled:true` from unacknowledged request; accepts explicit `stopped` SSE and does not clear recovery on `AbortError`. Agent client Stop keeps polling durable server run instead of falsely marking it stopped; duplicate stop requests are blocked | **Passed Node and stubbed Chromium scenarios**, including pending/saved recovery and positive/negative cancel responses. **Not verified** against actual network partitions, slow LLM provider or Spring Boot deployment. |
| **144-07** | Unified Agent and Analyse progress presentation | New shared rail shows Analyse responding/recovering and Agent phase, current tool/plan step, actual provider-reported token counts (or unavailable), stop/view actions, backend failed/cancelled/unknown states. Progress = 100% alone is **not verified completion**; incomplete checks prevent verified status | **Passed Node and Chromium** backend-stub status cases. Full stage timing/approval interactions and live provider-reported usage still require deployed E2E tests. |

## Additional quality requirements

- Source and output fidelity: previews MUST NOT modify Copy/Download bytes; HTML source MUST NOT execute in the chat.
- Recovery privacy: browser `sessionStorage` recovery record contains only conversation ID, user-message ID and timestamp, NOT prompts, API keys, attachments or workspace content.
- Cancellation correctness: UI distinguishes stopping the client transport from cancelling the backend; Agent remains under durable status polling until terminal outcome is observed.
- Preserve explicit MCP gating and approvals; no hidden Agent execution from Analyse.
- Avoid automatically downloading a browser: the smoke suite finds an already installed Chrome/Edge/Chromium, including Windows Program Files paths.
- Do not claim faster elapsed time, lower billed tokens, successfully created artifacts or verified Java build without external evidence.

## Remaining acceptance checks before production sign-off

1. Build a JAR with Maven on the deployment machine; launch backend on `localhost:8090` and verify all selected workflow modes using the connected provider.
2. Test actual Agent stop while writing files, during approval, and during server disconnection; verify file changes and status on resume.
3. Test browser refresh/tab switch while Chat SSE is streaming, during partial generation, and while server is saving the final answer.
4. Run a real 5,000-line provider output under network throttling and capture DOM memory, frame rate and response-integrity metrics.
5. Perform accessibility and visual audits for additional screen sizes, virtual keyboards, dark mode, high contrast, and mobile Safari.
