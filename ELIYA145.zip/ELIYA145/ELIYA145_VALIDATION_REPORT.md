# ELIYA145 Combined Acceptance — Validation Report

**Date:** 2026-11-14. **Environment:** installed Chromium, Node.js, Java 21 JDK, Python Playwright, container without Maven or live external model/MCP server access.

## Executed checks

| Suite | Result | What it proves |
|---|---|---|
| `node --test src/test/js/*.test.js qa/*.test.js` | **PASS 181/181** | Existing model/UI contracts and ELIYA145 dashboard selectors, bounded projection, honest states and endpoint wiring/source checks |
| `qa/eliya142-policy-smoke.sh` | **PASS** | Existing token/context/tool-policy test set (130 test cases in separate fixture) |
| `qa/native-agent-policy-smoke.sh` | **PASS** | Ten native Agent profiles discovered and parser/tool policy checks |
| `qa/eliya145-java-integrity-smoke.sh` | **PASS** | JDK compilation/execution of real ArtifactVaultService against local lightweight Jackson/Spring stubs, verifying SHA archive, corruption, missing file and legacy behavior |
| `qa/eliya143_browser_ui.py` | **PASS** | Long source handling, streaming/dedup, expansion, focus, mobile |
| `qa/eliya144_browser_ui.py` | **PASS** | 5,000-line Markdown and 5,000 HTML rows, exact export bytes, source inertness, lifecycle, history and reload-like recovery |
| `qa/eliya145_browser_ui.py` | **PASS** | Real Chromium DOM: Agent dashboard, navigation to approvals/questions, backend manual refresh, current-file warning, 5,000-line export, mobile 320px, forced-colors and reduced-motion, saved-chat restoration and keyboard focus |
| ZIP integrity | **Run at packaging** | Verify every ZIP member can be read and release documents included |

## Performance and accessibility observations

- 5,000-line preview initial fixture render observed ≈35–45 ms, average repeated render ≈0.4 ms, 38 visible elements. This is one mocked-browser measurement; it is **not** a real-model streaming latency guarantee.
- The source panel and execution dashboard bound the initial on-screen DOM instead of mounting all 5,000 lines in the chat.
- Fixture checks included 320/390/768/1440 pixel layouts, contrast ratios >=4.5 for selected primary metric text, keyboard focus restoration, no source-script execution, reduced-motion and forced-colors rendering. **Not** a comprehensive WCAG 2.2 AA audit.
- New checksum checks run on explicit user actions, avoiding hashing large workspaces on each streamed token. A full scan is capped at 1,000 changed paths; partial results remain visibly partial.

## Not run — must not be reported as passing

1. Full Maven compilation and executable JAR startup (Maven unavailable).
2. Deployed Spring Boot integration with live model, real SSE, real Playwright/Jira MCP, or production data.
3. Actual server restart/kill, partial-stream network faults, Agent task cancellation midway through file writes.
4. Screen reader (NVDA, VoiceOver), full WCAG audit, Safari/iOS and every theme/locale/browser.
5. 60-minute runtime/memory profiling, 2,000+ real indexed files, and equal-workload comparison to OpenCode for tokens/time/quality.
6. A real backend authorization/security test for newly exposed integrity endpoints (requires deployment-specific configuration).

## Acceptance verdict

**PASS for source/UI/browser-fixture scope; CONDITIONAL/PENDING for live production integration, complete accessibility certification and real workload performance acceptance.** This distinction is deliberate and prevents incorrectly claiming the user's entire real-world requirement has been proven.
