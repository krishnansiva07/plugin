# ELIYA145 — Consolidated UX-ALL Source Release

**Release basis:** ELIYA144 (plus inherited ELIYA142–143 capabilities). **Release date:** 2026-11-14. **Artifact:** complete editable source ZIP; no prebuilt/executed Spring Boot JAR.

## Delivered

### 1. Execution dashboard

- New responsive execution dashboard shared by the Analyse/Agent chat screen.
- Reflects backend phase, plan progress, stage timings, recent tools, pending approvals, clarifications, provider-reported tokens, and truthful completion verification.
- Manual backend refresh and direct navigation to approval/question actions; no hidden tool invocation.
- Snapshot-driven projection lives in `src/main/resources/static/execution-dashboard145.js` with tests in `qa/eliya145-combined-ui.test.js`.

### 2. Recovery improvements

- Save last selected conversation ID and pending-response recovery pointers across browser restarts; do **not** persist prompt text/API keys.
- Retain ELIYA144 session and cancellation correctness, including separate client disconnect and server cancellation status.
- Restore content from the durable backend; do not automatically regenerate on reload.

### 3. Artifact and file integrity

- On archive, store SHA-256 of new Chat artifact bytes and validate when read; old entries without a checksum remain readable and explicitly report `legacy_length_only`.
- Add explicit GET `/api/artifacts/saved/verify/{conversationId}/{messageId}` for archival integrity.
- Add explicit read-only GET `/api/agent/runs/{runId}/file-integrity` for current workspace files against a sealed run-diff manifest. Max 1,000 files per check, report partial scan instead of claiming intact.
- UI surfaces file checks / failures without silently treating a historical completion report as proof that files still exist.

### 4. UI, accessibility, performance and regression

- Dashboard scrolls independently of fixed chat composer, including narrow mobile sizes.
- Focus on dashboard open, Esc to close and return focus, labeled controls, focus visibility, forced-colors and reduced-motion styles.
- All prior fixes for source preview, exact copy/download, Markdown/HTML spacing, large prompts, contextual follow-ups, streaming deduplication and honest cancellation are retained.
- Consolidated Windows and Linux/macOS offline source acceptance scripts, 181 JS tests and three installed-browser Chromium suites.

## Critical caveats

This release is **validated source**, not proof of completion of every production acceptance gate. The installed environment lacks Maven, so full Spring Boot compilation, JAR launch and live provider/MCP execution were not verified. Network interruption recovery, full screen-reader/WCAG evaluation, 60-minute and 2,000-file real-workspace profiling, and an apples-to-apples OpenCode benchmark remain external gates.

Read `ELIYA145_UNIFIED_REQUIREMENT.md` and `ELIYA145_VALIDATION_REPORT.md` for the complete acceptance ledger.
