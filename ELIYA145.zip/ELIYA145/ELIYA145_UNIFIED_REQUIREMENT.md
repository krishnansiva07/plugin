# ELIYA145 — Unified UI Experience, Reliable Execution and Audit (UX-ALL)

**Single master requirement:** The complete Eliya Chat / Analyse / Agent experience must present large content without corruption, stream and recover safely, show accurate real-time execution information, protect produced artifacts, and remain responsive and accessible across desktop and mobile. This consolidated requirement replaces separate planning tracks for UX-06, UX-07 and UX-08 and includes all seven UI requests discussed for ELIYA143–144.

**Baseline:** ELIYA144, with ELIYA142 efficiency and ELIYA143–144 UI behavior retained. **Delivery:** ELIYA145 source, tests, screenshots, and validation logs. **Scope restriction:** No hidden Agent work, tool approvals bypass, fake tokens, or premature verified-complete statuses.

## One requirement, 10 measurable sub-acceptance criteria

| ID | Unified acceptance criterion | Source implementation in ELIYA145 | Evidence / boundary |
|---|---|---|---|
| UX-ALL-01 | Cohesive usable Chat/Analyse/Agent layout on 320px mobile and desktop; persistent status and no composer occlusion | Prior UI redesign plus dashboard with bounded height/scroll, mobile responsive grid; focus-aware toggle/close | Chromium checks at 320, 390, 768 and 1440 px; static screenshots. Full visual design-system replacement NOT delivered. |
| UX-ALL-02 | Generate and view 1,000–5,000-line Markdown/prompt/HTML output without truncation, unwanted blank blocks, duplicated streamed chunks or parser fragmentation | Inherited source preview, source expansion, step parser, bounded DOM history, streaming dedup, spacing corrections | ELIYA143/144/145 Chromium regression; exact 5,000-line markdown and 5,000-row HTML downloads. Real model streaming under a remote provider NOT tested. |
| UX-ALL-03 | Copy/download the complete original source, never the shortened preview; HTML must remain inert | Existing full-source artifact viewer and export paths preserved | Browser byte-for-byte exports; HTML source inertness checked. |
| UX-ALL-04 | Follow-ups must derive from newest answer and not present generic hard-coded prompts after each Chat turn | Existing ELIYA143 response-aware follow-up logic retained | Node/Chromium checks; the relevance of every live model output cannot be guaranteed by source checks. |
| UX-ALL-05 | Clear execution status, plan step, stage timings, tool activity, backend availability, approvals and questions; show provider tokens only when supplied | New `execution-dashboard145.js`, dashboard DOM + CSS and handoff to existing approval/question controls; manual Refresh | Browser mock test checks running/failed/disconnected and interactions; provider data not invented. Live SSE + deployment integration not run. |
| UX-ALL-06 | Stop, reconnect, restore session, and refresh without resubmitting the user's prompt or claiming unsupported stop/completion | Preserved ELIYA144 cancel acknowledgement and Agent durable polling; ELIYA145 remembers last chat and pending recovery by IDs only in browser local storage | Chromium document-restart/stubbed backend tests. Backend crash/restart and network chaos require live integration. |
| UX-ALL-07 | Protect saved Chat artifacts and verify current state of changed Agent files | SHA-256 on new archived files; checks on load and read; `/api/artifacts/saved/verify/{conversationId}/{messageId}`; read-only `/api/agent/runs/{runId}/file-integrity` | Java 17+/21 JDK-only artifact smoke (new, tampered, missing, legacy), browser alerts for missing live files. Live Agent endpoint needs Maven integration test. |
| UX-ALL-08 | Restore saved runs, preserve Analyse → Agent handoff, never assume 100% = verified-complete, never confuse historical file list with current file integrity | Existing run journal and status logic retained; dashboard shows evidence and explicit current-file scan only on request | Automated source-unit/browser checks; recovery is NOT provider execution replay. |
| UX-ALL-09 | Accessibility: keyboard commands, visible focus, live text statuses, safe text escaping, responsiveness, reduced-motion and forced-colors modes | Semantic labeled dashboard actions; Esc closes and restores focus; focus on dashboard heading; bounded scroll, reduced-motion and forced colors styling | Playwright focus/contrast/responsiveness/reduced-motion/forced-colors checks; **not a complete WCAG 2.2 AA certification or physical screen-reader audit**. |
| UX-ALL-10 | Performance, regression, packaging and honest acceptance | Tool-free client projection; bounded panels; explicit refresh and integrity calls rather than extra streaming RPCs; consolidated test scripts | 181 Node tests, existing policy checks, 3 Chromium suites passed. Fixture 5,000-line first-render observation recorded; **not an OpenCode token comparison, 60-minute stability or full provider benchmark**. |

## Implementation principles

1. **One source of truth:** Display only statuses and provider usage from durable run state; absent stage times or usage say *not reported*.
2. **Evidence before completion:** A terminal status and successful verification evidence are required; a high progress percentage is insufficient.
3. **Durable browser recovery:** Remember identifiers only, never prompt text, keys, contents, attachment data or workspace secrets in recovery keys.
4. **Explicit operator actions:** On-demand file hash scan, manual backend refresh, approval review, and questions are not automatic background model requests.
5. **Never bypass safety gates:** Legacy permissions and MCP invocation rules remain in effect.
6. **Immutable source exports:** Preview styles do not alter source bytes in Copy/Download.
7. **Auditability:** Each known limitation is listed below, not marked complete without evidence.

## Automated source acceptance completed in this environment

- `node --test src/test/js/*.test.js qa/*.test.js`: **181/181 passed**.
- Existing JDK-only agent policy and native Agent profile smoke checks: **passed**.
- JDK-only `ArtifactIntegritySmoke145`: **passed** (corrupt/missing/legacy/new checksum paths, compiled against lightweight test stubs).
- ELIYA143, ELIYA144 and ELIYA145 browser suites: **passed** using an installed Chromium binary, including 320px view and 5,000-line exact exports.
- Browser fixture observation, 5,000-line preview: first render ≈35–45 ms, repeated render ≈0.4 ms; single environment sample, not an SLA.

## Gates still required before declaring FULL production acceptance

**These are not silently waived:**

- A real Maven/Spring Boot compile and end-to-end run on Windows at `localhost:8090`; Maven was not available in this environment.
- Live provider and configured MCP (Jira/Playwright/Confluence as applicable) behavior, including long output, approval handling, backend cancellation, session crash/restart and file regeneration.
- Full accessibility evaluation: keyboard-only journeys across every page, NVDA/VoiceOver with a person, mobile Safari/iOS, dark and high-contrast review, full WCAG 2.2 AA criteria review.
- Sustained-memory / 60-minute long-run profiling; 2,000-file indexing/migration real-workspace stress; controlled token/time comparison to OpenCode on *identical* tasks, providers, inputs and validation evidence.
- Production hardening: authenticate/authorize both new integrity endpoints under the deployment's real access model and test network interruptions.

## One-click source acceptance

On Windows in the extracted `ELIYA145` directory:

```powershell
powershell -ExecutionPolicy Bypass -File qa\eliya145-validate.ps1
```

On Linux/macOS:

```sh
bash qa/eliya145-validate.sh
```

Requires Node.js, Python Playwright, installed Chrome/Edge/Chromium. An installed JDK is needed for the Java artifact smoke; no browser auto-download. These scripts validate source/UI, not a production JAR.
