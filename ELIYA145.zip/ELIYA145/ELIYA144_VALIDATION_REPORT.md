# ELIYA144 — Verification report (2026-11-14)

## Results

| Validation | Result | Evidence |
|---|---|---|
| Full Node.js regression | **176/176 PASS**, 0 failures | `validation/ELIYA144_NODE_TESTS.log` |
| ELIYA144 real Chromium acceptance (simulated backend) | **PASS** | `validation/ELIYA144_BROWSER_TEST.log` |
| Previous ELIYA143 Chromium regression | **PASS** | `validation/ELIYA143_BROWSER_REGRESSION.log` |
| ELIYA142 Java policy/optimization smoke (JDK-only) | **PASS** | `validation/ELIYA144_JAVA_OPTIMIZATION_SMOKE.log` |
| Native Agent profile/policy smoke (JDK-only + Node) | **PASS** | `validation/ELIYA144_JAVA_AGENT_SMOKE.log` |
| JavaScript syntax | **PASS**, `node --check` on app and new helper | Release validation run |
| Full Spring Boot/Maven build | **NOT RUN** | Maven and dependency resolution unavailable in this container; **no JAR is claimed** |
| Real LLM/provider/Agent end-to-end streaming | **NOT RUN** | Backend mocked in Chromium; no actual model execution |
| Browser reload on local HTTP | **SIMULATED** | Chromium environment blocks local URL navigation. Test uses a newly constructed Chromium document with preserved ID-only `sessionStorage` and mocked persisted conversation state. |

## Browser acceptance details

- 5,000 `Step N` Markdown instructions retained as **one prompt** rather than fragmented into multiple prompt cards.
- Compact initial preview: the full document is not rendered inline until the user expands it. Downloaded `.md` file exactly matches source content.
- 5,000 HTML rows displayed as inert HTML **source**, with exact exported content; inline `<script>` never executed.
- Agent `100%` with backend `running` is **not** shown verified; backend `completed` with blocked plan still shows checks requiring review.
- Provider tokens absent: show `Tokens unavailable`, never fabricate `0` measured tokens.
- Chat Stop: both confirmed and unconfirmed backend responses are tested, the HTTP stream abort is not mistaken for server completion, and uncertain response pointers survive.
- Agent Stop: acceptance of a stop request is explicitly different from terminal execution status.
- 250-message history starts with **85 visible messages**, then **150** after user clicks Show earlier messages; full state remains 250.
- A new Chromium document restored the last selected conversation and retrieved the existing saved answer without resending the prompt. No stale `Loading conversation…` placeholder remained.
- 390 × 844 mobile viewport had no document-level horizontal overflow.
- Screenshots: `qa/screenshots-144/desktop.png` and `qa/screenshots-144/mobile.png`.

## Safety, fidelity and non-claims

- Browser-only UI tests cannot establish actual backend cancellation when the process is not reachable. A positive `cancelled:true` is an acknowledged cancellation **request**, not proof of a completed stop; the Agent UI waits for a terminal run snapshot.
- Cross-refresh recovery stores ID-only metadata, not prompts, credentials or project contents, and never automatically resubmits a possibly running prompt.
- No measured reduction versus OpenCode in actual billed token usage or latency is asserted by this UI release.
- No claim of comprehensive accessibility certification or full legacy screen replacement.

## Windows reproduction

From the extracted ELIYA144 source folder:

```powershell
python -m pip install playwright
powershell -ExecutionPolicy Bypass -File qa\eliya144-validate.ps1
```

Use the Chrome/Edge binary already installed on the machine; the script does not download browser executables. Java smoke tests run under Bash/WSL; the full application requires a separate Maven build and live deployment acceptance.
