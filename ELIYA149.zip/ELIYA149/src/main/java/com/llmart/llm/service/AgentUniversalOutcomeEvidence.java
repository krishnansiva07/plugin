package com.llmart.llm.service;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * ELIYA148: task-agnostic, model-independent receipt for completed Agent tools.
 *
 * This is not a semantic proof of correctness. It records completed operations and
 * the evidence gaps that a final response must make visible. It is independent of
 * specific prompts, agent names, workflow filenames and user-visible final prose.
 * Do not retain full stdout, tool arguments or secrets in the receipt.
 */
final class AgentUniversalOutcomeEvidence {
    private static final int MAX_EVENTS = 80;
    private static final int MAX_ITEMS = 9;
    private static final Pattern COMMAND = Pattern.compile("(?i)[\\\"']command[\\\"']\\s*[:=]\\s*[\\\"']([^\\\"'\\r\\n]{1,240})");
    private static final Pattern PATH = Pattern.compile("(?i)[\\\"'](?:path|file|outputPath|sourcePath)[\\\"']\\s*[:=]\\s*[\\\"']([^\\\"'\\r\\n]{1,240})");
    private static final Pattern EXIT = Pattern.compile("(?i)(?:^|[;\\s])exitCode\\s*=\\s*(-?\\d+)");
    private static final Set<String> MUTATIONS = Set.of("write", "edit", "apply_patch", "delete", "copy", "move",
            "resource_write", "resource_edit", "resource_delete", "resource_copy", "resource_move",
            "presentation_create", "confluence_compose", "mcp_scaffold", "rag_scaffold");
    private static final Set<String> CHECKS = Set.of("test", "build", "check", "resource_test", "resource_build",
            "resource_check", "presentation_validate", "confluence_validate", "documentation_validate");
    private static final Set<String> EXAMINATION = Set.of("read", "read_many", "read_chunk", "list", "glob", "grep",
            "file_info", "inspect_workspace", "workspace_status", "workspace_diff", "code_impact",
            "resource_read", "resource_grep", "resource_info", "knowledge_search", "knowledge_read",
            "conversation_handoff_read", "conversation_handoff_search", "attachment_read", "attachment_search",
            "documentation_inventory", "documentation_module", "documentation_knowledge");
    private static final Set<String> EXECUTION = Set.of("bash", "resource_bash", "process_start", "process_status",
            "process_output", "process_stop", "http_request");

    record Observation(String type, String tool, String target, boolean success, String proof) { }
    private final List<Observation> events = new ArrayList<>();
    private int dropped;

    void observe(Map<String,Object> event) {
        if (event == null) return;
        String status = clean(event.get("status")).toLowerCase(Locale.ROOT);
        if (!(status.equals("success") || status.equals("error"))) return;
        String name = clean(event.get("tool"));
        String tool = name.contains("→") ? name.substring(name.lastIndexOf('→') + 1) : name;
        String category = category(tool);
        // Future tools with real outputs still qualify; UI/progress events without a
        // tool result cannot fabricate provenance. No workflow-name special cases.
        if (category == null && (event.containsKey("args") || event.containsKey("output")) &&
                !tool.isBlank() && !tool.equals("agent") && !tool.equals("finish") &&
                !tool.startsWith("plan_") && !tool.startsWith("model_") &&
                !tool.startsWith("answer_") && !tool.startsWith("final_")) category = "other";
        if (category == null) return;
        if (events.size() >= MAX_EVENTS) { dropped++; return; }
        String args = clean(event.get("args"));
        String target = field(category.equals("execution") || category.equals("verification") ? COMMAND : PATH, args);
        if (target.isBlank()) target = field(PATH, args);
        if (target.isBlank() && tool.startsWith("mcp__")) target = "external operation";
        if (target.isBlank()) target = tool;
        target = compact(target, 110);
        String output = clean(event.get("output"));
        Matcher m = EXIT.matcher(output);
        boolean hasExit = m.find();
        String proof = hasExit ? "exitCode=" + m.group(1) : "tool event=" + status;
        boolean success = status.equals("success") && (!hasExit || "0".equals(m.group(1)));
        // A tool's success event proves only its reported tool outcome, not that the goal is correct.
        if (status.equals("error") && !hasExit) proof = "tool event=error";
        events.add(new Observation(category, tool, target, success, proof));
    }

    boolean observed() { return !events.isEmpty(); }
    int completedToolEvents() { return events.size(); }
    boolean hasReadEvidence() { return events.stream().anyMatch(e -> e.success && e.type.equals("inspection")); }
    boolean hasWriteEvidence() { return events.stream().anyMatch(e -> e.success && e.type.equals("change")); }
    boolean hasActionEvidence() {
        return events.stream().anyMatch(e -> !e.type.equals("inspection"));
    }
    boolean hasCheckEvidence() { return events.stream().anyMatch(e -> e.success && e.type.equals("verification")); }
    boolean hasUnresolvedToolFailures() { return !unresolvedFailures().isEmpty(); }

    private List<Observation> unresolvedFailures() {
        Map<String,Observation> latest = new LinkedHashMap<>();
        for (Observation e : events) latest.put(e.type + "|" + e.tool + "|" + e.target, e);
        return latest.values().stream().filter(e -> !e.success).toList();
    }

    String report(String status, int changedFiles, boolean verifiedLatestRevision, String verifierDetail) {
        return report(status, changedFiles, verifiedLatestRevision, verifierDetail, List.of());
    }

    String report(String status, int changedFiles, boolean verifiedLatestRevision, String verifierDetail,
                  List<Map<String,Object>> planSteps) {
        if (!observed() && changedFiles <= 0) return "";
        String runStatus = switch (status == null ? "" : status.toLowerCase(Locale.ROOT)) {
            case "completed" -> "Completed (runtime status)";
            case "failed" -> "Failed";
            case "blocked" -> "Blocked / not fully verified";
            case "cancelled" -> "Cancelled";
            default -> "Unverified (" + compact(status, 40) + ")";
        };
        int inspections = 0, mutations = 0, checks = 0, executions = 0, external = 0, other = 0;
        for (Observation e : events) {
            if (!e.success) continue;
            switch (e.type) {
                case "inspection" -> inspections++;
                case "change" -> mutations++;
                case "verification" -> checks++;
                case "execution" -> executions++;
                case "external" -> external++;
                case "other" -> other++;
                default -> { }
            }
        }
        StringBuilder result = new StringBuilder("### Independent execution evidence\n\n");
        result.append("**Runtime status:** ").append(runStatus).append(".\n\n")
                .append("**Observed activity:** ").append(inspections).append(" successful inspections, ")
                .append(mutations).append(" successful change tools, ")
                .append(checks).append(" successful validation tools, ")
                .append(executions).append(" successful command/process actions, ")
                .append(external).append(" successful external/MCP actions, ")
                .append(other).append(" additional successful tool operations. ")
                .append(changedFiles).append(" tracked workspace file change(s).\n\n");
        if (!events.isEmpty()) {
            result.append("| Recorded operation | Tool result | Evidence |\n|---|---|---|\n");
            // Select recent events, but preserve verification and failures before routine reads.
            List<Observation> ordered = new ArrayList<>();
            for (Observation e : events) if (!e.success) ordered.add(e);
            for (int i = events.size() - 1; i >= 0; i--) {
                Observation e = events.get(i);
                if (e.success && (e.type.equals("verification") || e.type.equals("change"))) ordered.add(e);
            }
            for (int i = events.size() - 1; i >= 0; i--) {
                Observation e = events.get(i);
                if (e.success && !(e.type.equals("verification") || e.type.equals("change"))) ordered.add(e);
            }
            Set<String> seen = new LinkedHashSet<>();
            int displayed = 0;
            for (Observation e : ordered) {
                String key = e.type + "|" + e.tool + "|" + e.target + "|" + e.success;
                if (!seen.add(key)) continue;
                result.append("| ").append(cell(e.type + ": " + e.tool + (e.target.equals(e.tool) ? "" : " — " + e.target)))
                        .append(" | ").append(e.success ? "Observed success" : "Observed failure")
                        .append(" | ").append(cell(e.proof)).append(" |\n");
                if (++displayed >= MAX_ITEMS) break;
            }
            if (events.size() > displayed || dropped > 0)
                result.append("\n*Showing bounded evidence; the Agent activity transcript retains further tool details.*\n");
        }
        if (planSteps != null && !planSteps.isEmpty()) {
            result.append("\n**Agent plan progress (runtime bookkeeping, not independent proof):**\n\n")
                    .append("| Step | Agent state |\n|---|---|\n");
            int shown = 0;
            for (Map<String,Object> step : planSteps) {
                if (step == null) continue;
                String stepText = compact(clean(step.getOrDefault("text", "")), 120);
                String state = compact(clean(step.getOrDefault("status", "unknown")), 35);
                if (!stepText.isBlank()) {
                    result.append("| ").append(cell(stepText)).append(" | ").append(cell(state)).append(" |\n");
                    if (++shown >= 8) break;
                }
            }
            if (planSteps.size() > shown) result.append("\n*Additional plan steps remain in the activity view.*\n");
        }
        result.append("\n**Independent verification:** ");
        if (verifiedLatestRevision) result.append("a recorded verifier passed on the current workspace revision.");
        else result.append("no passing current-revision verifier has been established by this receipt.");
        if (verifierDetail != null && !verifierDetail.isBlank())
            result.append(" Last verification: ").append(compact(verifierDetail, 210)).append(".");
        result.append("\n\n");
        List<Observation> unresolved = unresolvedFailures();
        if (!unresolved.isEmpty()) {
            result.append("**Unresolved tool errors (latest attempt per operation):** ");
            for (int i = 0; i < Math.min(4, unresolved.size()); i++) {
                if (i > 0) result.append("; ");
                Observation e = unresolved.get(i);
                result.append('`').append(compact(e.tool, 40).replace("`", "")).append('`')
                        .append(" (" ).append(compact(e.target, 50)).append(")");
            }
            result.append(". These errors must be evaluated before claiming the whole task passed.\n\n");
        } else if (events.stream().anyMatch(e -> !e.success)) {
            result.append("**Retry history:** earlier failed operation(s) were followed by successful retries " +
                    "with the same tool and target; the earlier attempts remain visible in the table.\n\n");
        }
        result.append("**Evidence limitation:** tool success does not establish requirement coverage or functional correctness. " +
                "Use runner assertions, source-to-requirement checks or an appropriate independent verifier for those claims.");
        return result.toString();
    }

    private static String category(String tool) {
        if (MUTATIONS.contains(tool)) return "change";
        if (CHECKS.contains(tool)) return "verification";
        if (EXAMINATION.contains(tool)) return "inspection";
        if (EXECUTION.contains(tool)) return "execution";
        if (tool.startsWith("mcp__")) return "external";
        return null;
    }
    private static String field(Pattern pattern, String args) {
        Matcher match = pattern.matcher(args);
        return match.find() ? match.group(1) : "";
    }
    private static String clean(Object value) { return value == null ? "" : String.valueOf(value); }
    private static String compact(String value, int max) {
        if (value == null) return "";
        String normalized = value.replaceAll("[\\r\\n\\t|]", " ").replace('`', '\'').replaceAll("\\s+", " ").strip();
        // Never print obvious credential material in command arguments or tool metadata.
        normalized = normalized.replaceAll("(?i)(?:password|passwd|token|api[_-]?key|secret|authorization)\\s*[=:]\\s*\\S+", "[redacted]");
        return normalized.length() > max ? normalized.substring(0, Math.max(0, max - 1)) + "…" : normalized;
    }
    private static String cell(String text) { return compact(text, 125); }
}
