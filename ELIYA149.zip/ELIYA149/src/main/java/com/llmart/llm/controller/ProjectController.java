package com.llmart.llm.controller;

import com.llmart.llm.dto.*;
import com.llmart.llm.service.AgentWorkspaceService;
import com.llmart.llm.service.ProjectService;
import com.llmart.llm.service.WorkspaceRetrievalIndexService;
import com.llmart.llm.service.LocalProjectIndexService;
import com.llmart.llm.service.OpenCodeExecutionService;
import java.nio.file.Path;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/projects")
public class ProjectController {
    private final ProjectService service;
    private final WorkspaceRetrievalIndexService retrieval;
    private final LocalProjectIndexService indexJobs;
    private final OpenCodeExecutionService openCode;
    public ProjectController(ProjectService service, WorkspaceRetrievalIndexService retrieval,
                             LocalProjectIndexService indexJobs, OpenCodeExecutionService openCode) {
        this.service = service; this.retrieval = retrieval; this.indexJobs = indexJobs;
        this.openCode = openCode;
        this.indexJobs.setSessionRetirer(openCode::retireWorkspaceSessions);
    }

    @PostMapping public ProjectDto create(@RequestBody Map<String, String> body) { return service.create(body.get("conversationId"), body.get("name")); }

    @PostMapping("/local")
    public ProjectDto createLocal(@RequestBody Map<String,String> body) {
        ProjectDto project = service.createLocal(body.get("conversationId"), body.get("path"), body.get("name"));
        indexJobs.request(project, false);
        return project;
    }

    @PostMapping("/{id}/rescan-local") public ProjectDto rescanLocal(@PathVariable String id) {
        ProjectDto project = service.rescanLocal(id);
        indexJobs.request(project, true);
        // The same ELIYA Chat stays visible, but the old OpenCode model session
        // must not be reused after a filesystem rescan.
        openCode.retireWorkspaceSessions(project.id());
        return project;
    }

    @GetMapping("/{id}/index-status") public Map<String,Object> indexStatus(@PathVariable String id) {
        return indexJobs.status(service.get(id));
    }

    @PostMapping("/{id}/apply")
    public Map<String,Object> apply(@PathVariable String id, @RequestBody ProjectPatchRequest request) throws IOException {
        return service.applyLocalPatch(id, request);
    }

    @GetMapping public List<ProjectDto> list(@RequestParam String conversationId) { return service.listForConversation(conversationId); }
    @GetMapping("/{id}") public ProjectDto get(@PathVariable String id) {
        ProjectDto project = service.get(id);
        if (project.localWorkspace()) indexJobs.request(project, false);
        return project;
    }
    @PostMapping("/{id}/files/batch") public ProjectDto uploadBatch(@PathVariable String id, @RequestBody ProjectUploadBatch batch) { return service.upsertFiles(id, batch); }
    @DeleteMapping("/{id}/file") public ProjectDto removeFile(@PathVariable String id, @RequestParam String path) { return service.removeIndexedFile(id, path); }
    @DeleteMapping("/{id}/files") public ProjectDto clearFiles(@PathVariable String id) { return service.clearFiles(id); }
    @DeleteMapping("/{id}") public void delete(@PathVariable String id) {
        indexJobs.untrack(id);
        service.delete(id);
    }
}
