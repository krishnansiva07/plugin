# ELIYA149 — Implicit Workspace and Reliable Reference Aliases

## User problem and observed root causes

1. In Analyse (Chat) mode, ELIYA148 `ContextService.shouldRetrieveWorkspace` invoked the mapped code index only when the user typed router-recognized terms. A selected project was described in the system prompt but frequently had **no actual code evidence** when a request like `Analyse` or `Review the solution` omitted `workspace`.
2. `ContextService.includeReferences` was gated by that same router. Consequently, the request `Review LegacySelenium` could skip an existing UI-configured alias, despite the browser sending `referenceProjectIds` and `referenceProjectNames`.
3. General primary-project analysis also searched **every selected reference**. It could contaminate source attribution and raise unnecessary retrieval cost.
4. Agent resource lookup was case-sensitive despite human-visible alias names being user-defined.
5. Browser reference mappings could refer to an old backend project ID after a restart. Previously the UI checked the index on startup but did not reliably recover an alias before sending a request. Analyse restored a remembered primary workspace less defensively than Agent.

## Implemented fixes

- **Implicit primary project:** A user-selected workspace is authoritative for Analyse and Agent. `WorkspaceIntentPolicy.implicitProjectInvestigation` recognizes read-only project investigation requests such as `Analyse`, `Review it`, `Analyse the design`, `Review the framework`, `Trace the execution flow`, and `Analyse migration gaps` without requiring the literal keyword `workspace`. Greetings and general educational questions retain the Chat fast path. Generic short investigations receive bounded source-index search terms so `Analyse` does not retrieve zero relevant files just because the request lacks code keywords.
- **Named reference routing:** `ContextService.includeReferences` supplies the active alias registry and fetches referenced indexed evidence whenever an exact configured alias is named, independently of the primary-workspace keyword router. Alias matching is case-insensitive with identifier boundaries; it does not confuse e.g. `API_Base` and `API_Base2`. A prompt explicitly naming one alias retrieves **only that alias**, while `all references` retrieves the configured set. General primary-project questions no longer automatically search every reference.
- **Correct target scope:** For an alias-only question such as `Review LegacySelenium`, retrieval is reference-scoped. For `Compare current workspace with LegacySelenium` or a migration request, Analyse retrieves both the primary project and the relevant reference. Evidence is labeled with the actual path and alias; missing/outdated reference indexes are identified rather than invented.
- **Agent alias resolution:** Agent runtime `resource_*` tools accept alias spelling independently of capitalization. The resource registry remains authoritative; no fuzzy path substitution is allowed. Reference access grants remain enforced by the existing per-reference writable flag. The backend's injected reference map now accurately describes those grants instead of claiming every selected reference is always read-only.
- **Persistent UI mapping:** Before a send, the browser verifies saved reference IDs against the previously approved path, with a short-lived verification cache. If a backend record was lost, it attempts to remap the **exact same** configured path, preserving alias and existing access choices. If the user explicitly names a reference that cannot be mapped, the request stops with an explanation instead of silently analyzing a different project. Non-requested unavailable references are not sent as broken IDs.
- **Restoration in Analyse:** A saved primary workspace is restored for either Analyse or Agent before the request is constructed, even if the browser/backend was restarted.

## Permissions and limitations

- Analyse remains read-only; it uses the indexed project evidence and cannot claim to have executed tests.
- Agent remains the only mode that executes edits and tools. References are read-only unless the user explicitly enabled per-reference write access. Remapping validates the original canonical path on the backend. The new logic does not grant edit permissions to unrelated folders.
- A selected folder with indexing pending, no eligible indexed files, unavailable path or incomplete index cannot yield verified findings about unseen content. Eliya must explicitly disclose this.
- A distinctive alias is recommended. If the user chooses a common word such as `API`, mentioning that exact word may intentionally target the reference, because the UI configured it as an alias.
- Local source smoke tests are **not** equivalent to full Spring Boot/Maven packaging or a live LLM validation.

## Expected behavior: manual acceptance scenarios

With primary workspace mapped to `C:\\Projects\\CurrentApp` and a reference mapped to `C:\\Projects\\LegacyFramework` with alias `LegacySelenium`:

| Mode | Prompt | Required behavior |
|---|---|---|
| Analyse | `Analyse` | Inspect the primary project's indexed sources; summarize architecture and evidence. No shell or edits. |
| Analyse | `Review the solution` | Read primary project evidence, not merely generic advice. |
| Analyse | `Review LegacySelenium framework` | Retrieve **LegacySelenium** evidence, not unrelated primary/ref code. |
| Analyse | `Compare the current workspace with LegacySelenium` | Retrieve both mapped projects and clearly distinguish source attributions. |
| Analyse | `Review API_Base and LegacySelenium` | Retrieve the two named references only; never automatically search all references. |
| Analyse | `What is Java?` | General answer on Chat fast path; do not force an unrelated workspace search. |
| Agent | `Implement using the LegacySelenium reference` | Resolve the registered alias in `resource_catalog`, honor edit permissions, and provide execution evidence. |
| Both | Restart backend, reopen UI, then name `LegacySelenium` | Recover its mapping using the original path or explicitly report an unavailable reference; never silently use a new path. |

## Validation commands

```bash
bash qa/eliya149-workspace-intent/run.sh
node --test qa/eliya149-workspace-alias.test.js src/test/js/*.test.js qa/*.test.js
bash qa/eliya118-reference-access/run.sh
bash qa/eliya148-universal-outcome-smoke.sh
bash qa/native-agent-policy-smoke.sh
bash qa/eliya145-java-integrity-smoke.sh
```

See `ELIYA149_VALIDATION.md` for current results. To validate the product on Windows, build with `build-jar-windows.cmd`, launch the new JAR, map the workspace and two distinct references, and repeat the scenarios above against the actual files.
