#!/usr/bin/env bash
set -euo pipefail
BASE="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUT="$(mktemp -d)"
trap 'rm -rf "$OUT"' EXIT
javac --release 17 -d "$OUT" \
  "$BASE/src/main/java/com/llmart/llm/service/AgentUniversalOutcomeEvidence.java" \
  "$BASE/src/main/java/com/llmart/llm/service/AgentResultPresentation.java" \
  "$BASE/src/main/java/com/llmart/llm/service/AgentTestOutcomeEvidence.java" \
  "$BASE/src/main/java/com/llmart/llm/service/AgentArtifactResultEvidence.java" \
  "$BASE/qa/Eliya148UniversalOutcomeSmoke.java"
java -cp "$OUT" com.llmart.llm.service.Eliya148UniversalOutcomeSmoke
bash "$BASE/qa/eliya147-test-outcome-smoke.sh"
bash "$BASE/qa/eliya146-agentic-outcome-smoke.sh"
