# ELIYA149 — Validation report

**Baseline:** ELIYA148 source package, unchanged generic Agent outcome engine.

| Test | Outcome | Scope |
|---|---|---|
| ELIYA149 Java intent smoke | **PASS — 34 checks** | Implicit project requests, general-chat exclusions, case-insensitive/whole alias matching, primary vs named reference targeting |
| Java 17 parser | **PASS — 4 affected Java sources** | `ContextService`, `ChatService`, `AgentWorkspaceService`, `WorkspaceIntentPolicy`; syntax only, not full compilation |
| ELIYA149 UI reference mapping test | **PASS — 6 cases** | Alias spelling/boundaries, cached path resolution, same-path reconnect, unavailable alias fail-closed, Windows/Unix path comparisons, Analyse restoration |
| Combined JavaScript regression | **PASS — 187 tests, 0 failed** | Existing 181 tests and 6 new ELIYA149 cases |
| ELIYA118 reference access smoke | **PASS** | Registered alias, reference read/write permissions and path boundaries |
| ELIYA148 + 147 + 146 outcome smokes | **PASS** | Universal Agent outcome, test evidence, Planner evidence |
| Native Agent policy | **PASS** | 10 profiles; tool permission and fail-closed parser checks |
| ELIYA145 artifact integrity | **PASS** | SHA-256, missing, corruption, backward compatibility |
| Full Maven/JAR build | **NOT VERIFIED** | Maven and dependency resolution unavailable here |
| Live Analyse with real mapped indexes | **NOT VERIFIED** | Requires user's mapped projects / index / LLM provider |
| Live Agent with selected alias | **NOT VERIFIED** | Requires new JAR and configured LLM/tool permissions |

**Release classification:** Source-level fix and offline regression package. The user should treat expected runtime behavior as an acceptance target, not a claim of a successful live run.
