# ELIYA147 — Autonomous test execution and evidence-backed result delivery

**Based on:** the uploaded ELIYA146 source package. **Priority:** core Agent reliability, not UI cosmetics.

## User problem

The user can ask OpenCode **"Run integration test"** and receives an evidence-led test matrix, pass/fail distinctions, remaining manual browser checks and follow-up recommendations. ELIYA146 improved Planner read-back but did not guarantee a comparable final test report for a short instruction. The goal for ELIYA147 is to require **execution → observation → analysis → result** without a separate Analyse prompt.

## Implemented source changes

1. **Task-specific execution contract (`AgentService`)**: on a request to run tests, Eliya is directed to discover the configured tests and correct runner, execute them, capture results, analyse failures and outstanding manual checks, and report without a second user message. It must not modify source when only test execution was requested. Short prompts such as `Run integration test` activate the contract.
2. **Independent runtime test-evidence ledger (`AgentTestOutcomeEvidence`)**: consumes terminal-success/error tool events for supported test tools, relevant shell test commands and test-runner MCP actions; ignores source reads, narrative claims, `running` events and browser clicks. Tracks actual commands, reported exits, numeric pass/fail/skip summaries, IDs appearing in test output and explicit manual/pending lines. The ledger does not claim that IDs in output prove acceptance-to-assertion coverage.
3. **No false-positive test pass**: `exitCode=0` without parseable executed-test counts is **UNVERIFIED**; `No tests found` is **NO_TESTS**; a failing runner is **FAILED**; a compilation/setup failure with no test-case results does not satisfy an instruction to execute tests. `RUN` requests without actual test execution end **Blocked**, not **Completed**.
4. **Autonomous user-facing analysis (`AgentResultPresentation` + `AgentService`)**: a generic or thin final Agent reply after tests triggers one bounded, tool-free analysis synthesis from existing recorded evidence; a deterministic test table is appended regardless of model output, so a model failure cannot erase the actual test results. No second Analyse invocation needed.
5. **Rerun handling**: preserve prior attempts but use the latest execution of each *identical* command for the displayed totals; do not double-count an earlier failure then a successful retry as six separate tests. Different suites may still overlap, so totals are not unique test IDs.
6. **Actionable failure output**: present short masked failure lines where captured and a relevant next action. Explicitly preserve skipped/manual/browser checks as pending, never pass.

## Example expected behavior

For a real tool observation `bash npm test → exitCode=0; 8 passed, 2 skipped; AC-202` the final reply includes:

- Runner command and observed return code
- 8 passed, 0 failed, 2 skipped **as reported by that runner**, not invented case totals
- `AC-202` mentioned in runner logs, with a warning that mapping an ID to an actual assertion requires separate traceability evidence
- Remaining skipped/browser checks and the recommended verification step

For `mvn test → exitCode=0; BUILD SUCCESS` without test count, the result is **UNVERIFIED**, not 8 PASS. A request to run integration tests may not simply return a successful build.

## Validation performed in this environment

- `bash qa/eliya147-test-outcome-smoke.sh`: **PASS** — real vs non-test tool events, zero tests, failed tests, unknown test counts, Jest and Maven summaries, multiple runs and runtime-analysis trigger.
- `bash qa/eliya146-agentic-outcome-smoke.sh`: **PASS** — Planner artifact evidence regression.
- `bash qa/eliya145-java-integrity-smoke.sh`: **PASS** — artifact SHA-256 integrity controls.
- `node --test src/test/js/*.test.js qa/*.test.js`: **181 PASS**, **0 fail**.
- `bash qa/eliya142-policy-smoke.sh`: **PASS**.
- `bash qa/native-agent-policy-smoke.sh`: **130 PASS**, **0 fail**, plus agent profile checks.
- Parser validation of changed `AgentService.java`, `AgentResultPresentation.java`, and the isolated Java evidence class: **PASS** (**syntax-only**, not a complete app compilation).

## What is not verified / next local checks

**This archive is Java source, not a validated executable JAR.** No full Maven build or live local/Windows JAR session was possible in this runtime, and no access exists to the user's configured LLM, MCP, repository or browsers. Therefore a 147 test run identical to the OpenCode screenshot is **not yet proven in production**.

On the user's Windows machine:

1. Extract the source ZIP; use Java 17+ and Maven to build with `build-jar-windows.cmd`.
2. Open the JAR and map the repository containing `TestCaseFilterService`, its tests and the required test dependencies.
3. In **Agent**, type `Run integration test` without an extra prompt. Verify that a real test command appears in Agent activity and that the final chat displays its observed output, failure analysis and remaining manual checks.
4. Repeat with a failing assertion, then fix/rerun as a separately authorized task. Verify no stale earlier failing count contaminates the latest rerun's test totals; failure history should remain visible.
5. Temporarily configure a suite with zero discovered tests or a missing runner; confirm Eliya reports **Blocked/UNVERIFIED**, never PASS. Compare results with OpenCode against the same test suite and machine.

## Limitations / risks

- The ledger interprets a bounded UI/tool event output, which may be clipped. Detailed evidence remains in the Agent activity transcript. If a provider or runner supplies a nonstandard summary, the ledger conservatively reports **UNVERIFIED** rather than guessing test totals.
- Requirement-level coverage still requires actual test-to-assertion traceability, not mere string matching in a log.
- Rerun deduplication is by identical command and tool, not unique test IDs across distinct suites.
- Large model-free reports use deterministic evidence and limitations; a full semantic analysis requires the configured completion model.
- Browser tests require the appropriate project browser automation/test runner; a screenshot or manual browser action alone is not a passing automated test.
- Existing workspace command permissions and MCP opt-in behavior are retained.
