# ELIYA148 — Universal Agentic Execution Outcome

## Objective

Ensure that **any Agent task using supported built-in, CLI, subagent, or configured MCP tools** finishes with a useful, evidence-backed user-facing result **in the same Agent request**, not just a generic Completed/Blocked message. The new outcome behavior is triggered by **observed completed tool events and workspace changes**, rather than command phrases such as `Launch Planner` or `Run integration test`.

**Honest scope:** this is a generic outcome-delivery and evidence layer on the existing Eliya agent engine. It cannot guarantee arbitrary external skills/tools work, that every workflow is correct, or that a new model never hallucinates. End-to-end execution still depends on the configured tools, permissions, workspace, LLM, and suitable domain-specific verifiers. No source-only test proves universal end-to-end behavior.

## Source implementation

1. `AgentUniversalOutcomeEvidence.java` is a compact independent per-run tool-event ledger. It consumes **completed** tool events from workspace reads/writes, tests/builds/checks, shell/process tools, configured MCP, and subagents. Unknown future tools with real event argument/output evidence are also included; unrelated UI/plan/model progress events are excluded. It never treats LLM prose as evidence.
2. The receipt reports actual observed actions, relevant tool/target, success/failure, captured exit codes where present, tracked changed-file count, per-step progress, independent verification status, unresolved errors, and limitations. No raw unbounded stdout or tool arguments are appended. Explicit secret-like key/value strings are redacted in the short target description.
3. `AgentResultPresentation.needsUniversalOutcome` now detects a thin final answer for **all** workflows that actually made changes or invoked multiple tools. It uses low-cost deterministic rules and avoids a second LLM call when the answer is already substantive. Short one-tool read-only queries need not pay for an extra completion.
4. `AgentService` feeds the generic ledger to the bounded **tool-free** final-answer synthesis when needed, and always attaches a deterministic execution receipt when tool or file evidence exists. The receipt persists even if the report model fails or a completion gate blocks the run. This works in both mapped-workspace Agent and no-workspace MCP/document mode.
5. Instructions for both Agent protocols and final-answer synthesis now demand **actual findings and interpretation** for any task, clearly separated from evidence and unverified assumptions. No user request for a second Analyse run is required.
6. Existing specialized gates remain authoritative: test runner counts (`AgentTestOutcomeEvidence` from 147), Markdown plan read-back (146), HTML reports, MCP evidence, last-revision verification, migration ledger and safe tool permissions. Generic reporting never upgrades failed/blocking status to Completed.

## Desired response structure (adaptive, not a hardcoded final answer)

- **Outcome / findings:** what work produced, why it matters, and key technical interpretation. A Planner task compares alternatives; a reviewer identifies defects; a developer explains changes; a tester analyzes real results.
- **Evidence:** paths to files, tool commands, test runner output and/or retrieved MCP observations. The generic receipt lists bounded recorded operations, not invented results.
- **Verification:** PASS/FAIL/SKIP/NOT RUN only when supported by real executed results; execution success and content read-back are not equivalent to functional acceptance.
- **Remaining work:** concrete unverified/blocked steps, risks, actionable next step. Avoid a repetitive hardcoded question.

## Workflow acceptance matrix

| Workflow | Expected ELIYA148 behavior | What counts as proof |
|---|---|---|
| `Launch Planner` | Generate plans and comparison, interpret trade-offs and recommendation automatically | Files read back, proposal text, explicit unverified design assumptions |
| `Run integration test` | Execute tests and report counts, failures, skipped/manual checks | Real test-runner command, actual stdout and exit code, parsed counts; no PASS on zero tests |
| `Implement Plan A` | Modify approved scoped files, explain implementation and verification | Workspace diff + appropriate current-revision verification |
| `Review code` | Inspect code, explain defects with concrete locations | Read/search tool evidence; recommendations explicitly separated from validated defects |
| `Migrate Java Selenium to Playwright TS` | Explain generated code, migration progress, tests and remaining areas | Tracked files, migration ledger where applicable, executed TS/build/test evidence |
| `Use Jira MCP to compare requirements` | Retrieve only when explicitly authorized, compare to workspace when requested, report gaps | Actual MCP and local tool events, citations/IDs in retrieved evidence; missing sources flagged |
| Custom skill or future tool | Report completed tool events and useful outcome when accessible | Tool result, output/effect validation appropriate to that tool; unknowns disclosed |

## What we actually validated here

- `bash qa/eliya148-universal-outcome-smoke.sh`: **PASS** — generic actions, planner/doc files, failed tests and retries, read-only flows, MCP, future tools, subagent events, output redaction, final-synthesis activation; also invokes 147 and 146 regressions.
- `bash qa/eliya145-java-integrity-smoke.sh`: **PASS**.
- `bash qa/native-agent-policy-smoke.sh`: **PASS**, profiles and permission enforcement.
- `node --test src/test/js/*.test.js qa/*.test.js`: **181 passed, 0 failed**.
- `bash qa/eliya142-policy-smoke.sh`: **130 passed, 0 failed**.
- `bash qa/eliya146-source-parser-smoke.sh`: **PASS**, Java parser syntax validation of affected existing sources; standalone Javac 17 of new component and its Java smoke tests passes.

## Not verified (environment limitations)

- Full Maven/Spring Boot compilation, packaging and JAR startup, because Maven and the user's dependencies/configuration are unavailable here. `mvnw` is a network-downloading wrapper, not an offline Maven distribution.
- A connected LLM, live MCP, user workspace, Windows terminal/browser tests, multi-agent runtime behavior and equivalent output to the OpenCode screenshot.
- Every domain-specific artifact type and every possible future external workflow. A generic receipt is **not a domain-specific test oracle**.

## Required Windows acceptance test before treating 148 as fully verified

1. Extract and build with `build-jar-windows.cmd` using Java 17+ and Maven / network-accessible dependencies. Launch the JAR and map the intended workspace.
2. Run **`Launch Planner`** in Agent. Confirm plan files are created and Eliya displays a comparison, trade-offs, grounded recommendation and exact evidence **without Analyse**.
3. Run **`Run integration test`** in Agent. Confirm actual runner commands execute and the outcome contains observed test counts, any failures, requirement IDs only when the runner emitted them, pending manual checks and next action.
4. Run **`Review the framework`** (read-only). Confirm actual file inspection, a substantive architecture/quality assessment, no unapproved edits, and source evidence.
5. Run **`Implement Plan A`** with a safe disposable test workspace; confirm source changes, real current-revision verification, affected-file list and interpretation.
6. Fail a test and rerun after fixing it. Confirm the result includes earlier failure history, counts only for the latest matching run, and no false PASS.
7. Configure a task without runnable tests, deny an essential tool, and separately test MCP unavailable. Confirm Eliya reports the explicit limitation and does not claim unsupported success.
8. Check the terminal and web UI render the same final substantive response, with no unrelated generic follow-up, and verify the saved run remains available after a restart.

**Acceptance criterion:** from a single user request, Eliya executes the authorized actions and **explains observed results and limitations autonomously**; it never equates a model assertion, a tool-success event, or a created file with proven functional success.

## Final ELIYA148 hardening

- General artifact read-back now includes bounded UTF-8 excerpts from changed Java/TypeScript/JavaScript/Python/JSON/YAML/HTML/XML/SQL/shell and other text deliverables, not just `.md`. Path traversal, symlinks, large files and common credential filenames are excluded. This improves the quality of analysis for unfamiliar developer workflows without a new code search.
- The final-answer analysis trigger recognizes material actions (including a single MCP, shell or resource write event) even when no primary-workspace text diff exists. A trivial one-tool read-only answer can avoid a redundant LLM call.
- ELIYA148 explicitly downgrades a test request with **latest failed tests** to `failed`; if any latest runner has `NO_TESTS`/`UNVERIFIED`, it downgrades `completed` to `blocked`. A separate passing suite cannot hide an unverified suite. Same-command successful reruns supersede prior attempts.
- Evidence receipt includes approved-plan progress with an explicit disclaimer: plan bookkeeping is **not** independent proof. Model failure or lack of source access never upgrades runtime completion status.
