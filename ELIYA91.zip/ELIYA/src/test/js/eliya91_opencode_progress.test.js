'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const source = fs.readFileSync('src/main/resources/static/app.js', 'utf8');
const bridge = fs.readFileSync('src/main/java/com/llmart/llm/service/UnifiedOpenCodeChatBridge.java', 'utf8');
const svc = fs.readFileSync('src/main/java/com/llmart/llm/service/OpenCodeExecutionService.java', 'utf8');
function functionSource(name, nextMarker) {
  const start = source.indexOf(`function ${name}(`);
  assert.ok(start > -1, `missing ${name}`);
  const end = source.indexOf(nextMarker, start);
  assert.ok(end > start, `missing boundary ${nextMarker}`);
  return source.slice(start, end);
}
test('OpenCode bridge publishes real session ID, startup milestones and failure', () => {
  assert.match(bridge, /"agentRunId",sessionId/);
  assert.match(bridge, /engine\.launch\(request,null,detail ->/);
  assert.match(bridge, /"agent_progress"/);
  assert.match(bridge, /"status","failed"/);
  assert.match(svc, /\.timeout\(Duration\.ofSeconds\("\/api\/info"\.equals\(path\) \? 2 : 30\)\)/);
});
test('OpenCode stop and report use OpenCode terminal session routes', () => {
  assert.match(source, /message\.executionEngine === 'opencode'/);
  assert.match(source, /\/api\/terminal\/sessions\/\$\{encodeURIComponent\(message\.agentRunId\)\}/);
  assert.match(source, /\/api\/terminal\/sessions\/\$\{encodeURIComponent\(runId\)\}\/cancel/);
  assert.match(source, /if \(meta\.engine === 'opencode'\) assistant\.executionEngine = 'opencode';/);
});
test('OpenCode watcher polls the correct session and renders real live progress', async () => {
  const code = functionSource('startAgentWatch','function activeAgentClarification()');
  const calls = []; const message = {executionEngine:'opencode', agentProgress:{plan:[]}, streaming:true,
    agentConnectionStatus:'connected', agentBackendStatus:'starting', agentSteps:[]};
  const context = {
    state: {agentWatchTimer:null,agentWatchdogCompleted:false, messages:[message]},
    api: async (uri) => {calls.push(uri);return {status:'running',progress:{progressPercent:25,progressPhase:'running',progressDetail:'Editing files'},
      events:[{type:'agent_step',seq:1,data:{tool:'Read',status:'done'}}],updatedAt:'2026-10-30T00:00:00Z'};},
    stopAgentWatch:()=>{},
    agentProgressFromSnapshot: (s, old)=>({...(old||{}),percent:s.progressPercent,phase:s.progressPhase,detail:s.progressDetail,status:s.status,plan:[]}),
    mergeDurableAgentActivity: (_,data)=>data,
    renderMessages:()=>{},updateAgentProgressUi:()=>{},
    setInterval:()=>1, setTimeout,clearInterval, Date,JSON,Number,String,Array,Map,
    fetchAgentCompletionReport:()=>{},applyCompletedChatMessage:()=>{},toast:()=>{},
    setStreaming:()=>{}, console,
  };
  vm.runInNewContext(code + '\nstartAgentWatch("oc-123",assistant,0);', {...context,assistant:message});
  await new Promise(resolve=>setImmediate(resolve));
  assert.deepEqual(calls,['/api/terminal/sessions/oc-123']);
  assert.equal(message.agentBackendReachable,true);
  assert.equal(message.agentProgress.percent,25);
  assert.equal(message.agentProgress.detail,'Editing files');
});
