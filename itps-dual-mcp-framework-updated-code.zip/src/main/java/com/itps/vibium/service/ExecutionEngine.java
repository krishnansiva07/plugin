package com.itps.vibium.service;

import com.itps.vibium.model.RunConfig;
import com.itps.vibium.model.RunStatus;
import com.itps.vibium.model.TestScenario;
import java.util.List;

public interface ExecutionEngine {
    String name();
    void execute(List<TestScenario> scenarios, RunConfig config, RunStatus status);
}
