package com.itps.vibium.service;

import com.itps.vibium.model.RunConfig;
import org.springframework.stereotype.Service;
import java.util.Locale;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

@Service
public class ExecutionEngineRouter {
    private final Map<String, ExecutionEngine> engines;
    public ExecutionEngineRouter(java.util.List<ExecutionEngine> engines) {
        this.engines = engines.stream().collect(Collectors.toMap(e -> e.name().toUpperCase(Locale.ROOT), Function.identity()));
    }
    public ExecutionEngine resolve(RunConfig config) {
        String requested = config.getExecutionEngine() == null ? "VIBIUM" : config.getExecutionEngine().trim().toUpperCase(Locale.ROOT);
        ExecutionEngine engine = engines.get(requested);
        if (engine == null) throw new IllegalArgumentException("Unsupported execution engine: " + requested);
        return engine;
    }
}
