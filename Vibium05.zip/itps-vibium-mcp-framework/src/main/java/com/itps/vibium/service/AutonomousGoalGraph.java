package com.itps.vibium.service;

import com.fasterxml.jackson.databind.JsonNode;
import org.bsc.langgraph4j.StateGraph;
import org.bsc.langgraph4j.state.AgentState;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;

import static org.bsc.langgraph4j.StateGraph.END;
import static org.bsc.langgraph4j.StateGraph.START;
import static org.bsc.langgraph4j.action.AsyncEdgeAction.edge_async;
import static org.bsc.langgraph4j.action.AsyncNodeAction.node_async;

/**
 * Supervisor LangGraph for autonomous goal execution.
 *
 * Rich browser observations and decisions are deliberately kept outside graph state because
 * LangGraph4j may serialize/clone state between nodes. Only simple serializable control data is
 * kept in {@link GoalState}.
 *
 * START -> OBSERVE -> DECIDE -> ACTION -> OBSERVE -> ...
 *                         |       
 *                         | DONE   \ BLOCKED
 *                         v         v
 *                     GOAL_CHECK  FAILURE
 *                       /   \
 *                  success  continue
 */
public final class AutonomousGoalGraph {

    public record Decision(String status,
                           String instruction,
                           String reason,
                           double confidence) {
        public String normalizedStatus() {
            String value = status == null ? "" : status.trim().toUpperCase(Locale.ROOT);
            if ("ACT".equals(value)) return "ACTION";
            if ("COMPLETE".equals(value) || "SUCCESS".equals(value)) return "DONE";
            if ("FAIL".equals(value) || "FAILED".equals(value)) return "BLOCKED";
            return value;
        }
    }

    public record ActionOutcome(boolean success, String error) { }

    public record GoalAssessment(boolean complete,
                                 String reason,
                                 String evidence,
                                 double confidence) { }

    public record Result(boolean success,
                         int turns,
                         String error,
                         GoalAssessment finalAssessment,
                         List<String> history) { }

    public interface Actions {
        JsonNode observe(int completedTurns, String lastError) throws Exception;
        Decision decide(JsonNode observation,
                        int nextTurn,
                        List<String> history,
                        String lastError) throws Exception;
        ActionOutcome execute(Decision decision, int turn) throws Exception;
        GoalAssessment validateGoal(JsonNode observation,
                                    int completedTurns,
                                    List<String> history) throws Exception;
    }

    static final class GoalState extends AgentState {
        GoalState(Map<String, Object> initData) { super(initData); }

        int turn() { return this.<Integer>value("turn").orElse(0); }
        boolean observationReady() { return this.<Boolean>value("observationReady").orElse(false); }
        boolean goalComplete() { return this.<Boolean>value("goalComplete").orElse(false); }
        String decisionStatus() { return this.<String>value("decisionStatus").orElse(""); }
        String lastInstruction() { return this.<String>value("lastInstruction").orElse(""); }
        String lastError() { return this.<String>value("lastError").orElse(""); }
        List<String> history() { return this.<List<String>>value("history").orElse(List.of()); }
    }

    public Result run(Actions actions, int maxTurns) throws Exception {
        int boundedTurns = Math.max(1, maxTurns);
        AtomicReference<JsonNode> currentObservation = new AtomicReference<>();
        AtomicReference<Decision> currentDecision = new AtomicReference<>();
        AtomicReference<GoalAssessment> finalAssessment = new AtomicReference<>();

        var workflow = new StateGraph<>(GoalState::new)
                .addNode("observe", node_async(state -> {
                    List<String> history = append(state.history(),
                            "OBSERVE: refreshing page state after " + state.turn() + " completed action(s)");
                    try {
                        JsonNode observation = actions.observe(state.turn(), state.lastError());
                        currentObservation.set(observation);
                        return updates(
                                "observationReady", true,
                                "decisionStatus", "",
                                "lastError", state.lastError(),
                                "history", history);
                    } catch (Exception error) {
                        history = append(history, "OBSERVE_FAILED: " + compact(error));
                        return updates(
                                "observationReady", false,
                                "decisionStatus", "BLOCKED",
                                "lastError", message(error),
                                "history", history);
                    }
                }))
                .addNode("decide", node_async(state -> {
                    List<String> history = state.history();
                    if (!state.observationReady() || currentObservation.get() == null) {
                        history = append(history, "DECIDE_BLOCKED: no current browser observation");
                        return updates(
                                "decisionStatus", "BLOCKED",
                                "lastError", "No current browser observation is available",
                                "history", history);
                    }
                    try {
                        int nextTurn = state.turn() + 1;
                        Decision decision = actions.decide(
                                currentObservation.get(), nextTurn, List.copyOf(history), state.lastError());
                        if (decision == null) throw new IllegalStateException("Supervisor returned no decision");
                        String status = decision.normalizedStatus();
                        if (!List.of("ACTION", "DONE", "BLOCKED").contains(status)) {
                            throw new IllegalStateException("Unsupported autonomous decision status: " + decision.status());
                        }
                        if ("ACTION".equals(status)
                                && (decision.instruction() == null || decision.instruction().isBlank())) {
                            throw new IllegalStateException("Autonomous ACTION decision has no instruction");
                        }
                        currentDecision.set(decision);
                        String summary = "DECIDE: " + status
                                + ("ACTION".equals(status) ? " -> " + compact(decision.instruction(), 500) : "")
                                + " (confidence=" + String.format(Locale.ROOT, "%.2f", decision.confidence()) + ")";
                        history = append(history, summary);
                        if (decision.reason() != null && !decision.reason().isBlank()) {
                            history = append(history, "REASON: " + compact(decision.reason(), 800));
                        }
                        return updates(
                                "decisionStatus", status,
                                "lastInstruction", "ACTION".equals(status) ? decision.instruction() : state.lastInstruction(),
                                "lastError", "BLOCKED".equals(status)
                                        ? defaultIfBlank(decision.reason(), "Autonomous supervisor reported BLOCKED")
                                        : state.lastError(),
                                "history", history);
                    } catch (Exception error) {
                        history = append(history, "DECIDE_FAILED: " + compact(error));
                        return updates(
                                "decisionStatus", "BLOCKED",
                                "lastError", message(error),
                                "history", history);
                    }
                }))
                .addNode("execute", node_async(state -> {
                    List<String> history = state.history();
                    Decision decision = currentDecision.get();
                    int turn = state.turn() + 1;
                    if (decision == null || !"ACTION".equals(decision.normalizedStatus())) {
                        history = append(history, "ACTION_SKIPPED: no executable supervisor decision");
                        return updates(
                                "turn", turn,
                                "lastError", "No executable supervisor decision",
                                "history", history);
                    }
                    try {
                        history = append(history, "ACTION_" + turn + ": " + compact(decision.instruction(), 700));
                        ActionOutcome outcome = actions.execute(decision, turn);
                        boolean success = outcome != null && outcome.success();
                        String error = success ? "" : (outcome == null
                                ? "Autonomous action returned no outcome"
                                : defaultIfBlank(outcome.error(), "Autonomous action failed"));
                        history = append(history, success
                                ? "ACTION_" + turn + "_OK"
                                : "ACTION_" + turn + "_FAILED: " + compact(error, 900));
                        return updates(
                                "turn", turn,
                                "observationReady", false,
                                "decisionStatus", "",
                                "lastError", error,
                                "history", history);
                    } catch (Exception error) {
                        history = append(history, "ACTION_" + turn + "_FAILED: " + compact(error));
                        return updates(
                                "turn", turn,
                                "observationReady", false,
                                "decisionStatus", "",
                                "lastError", message(error),
                                "history", history);
                    }
                }))
                .addNode("goal_check", node_async(state -> {
                    List<String> history = append(state.history(), "GOAL_CHECK: independently validating requested outcome");
                    try {
                        GoalAssessment assessment = actions.validateGoal(
                                currentObservation.get(), state.turn(), List.copyOf(history));
                        if (assessment == null) {
                            throw new IllegalStateException("Goal validator returned no assessment");
                        }
                        finalAssessment.set(assessment);
                        history = append(history,
                                (assessment.complete() ? "GOAL_CONFIRMED" : "GOAL_NOT_CONFIRMED")
                                        + " (confidence=" + String.format(Locale.ROOT, "%.2f", assessment.confidence()) + ")"
                                        + (assessment.reason() == null || assessment.reason().isBlank()
                                        ? "" : ": " + compact(assessment.reason(), 900)));
                        return updates(
                                "goalComplete", assessment.complete(),
                                "lastError", assessment.complete() ? ""
                                        : "Goal validation rejected completion: " + defaultIfBlank(assessment.reason(), "insufficient evidence"),
                                "history", history);
                    } catch (Exception error) {
                        history = append(history, "GOAL_CHECK_FAILED: " + compact(error));
                        return updates(
                                "goalComplete", false,
                                "lastError", message(error),
                                "history", history);
                    }
                }))
                .addNode("success", node_async(state ->
                        updates("history", append(state.history(), "END: autonomous goal completed"))))
                .addNode("failure", node_async(state ->
                        updates("history", append(state.history(),
                                "END_FAILED: autonomous goal stopped after " + state.turn() + " action turn(s)"))))
                .addEdge(START, "observe")
                .addConditionalEdges("observe",
                        edge_async(state -> state.observationReady() ? "decide" : "failure"),
                        Map.of("decide", "decide", "failure", "failure"))
                .addConditionalEdges("decide",
                        edge_async(state -> {
                            if ("DONE".equals(state.decisionStatus())) return "goal_check";
                            if ("ACTION".equals(state.decisionStatus()) && state.turn() < boundedTurns) return "execute";
                            return "failure";
                        }),
                        Map.of("goal_check", "goal_check", "execute", "execute", "failure", "failure"))
                // Always observe after an action, including the final permitted action. The
                // supervisor gets one last chance to return DONE from the resulting page; it
                // simply cannot schedule another ACTION once the action-turn budget is exhausted.
                .addEdge("execute", "observe")
                .addConditionalEdges("goal_check",
                        edge_async(state -> {
                            if (state.goalComplete()) return "success";
                            if (state.turn() < boundedTurns) return "decide";
                            return "failure";
                        }),
                        Map.of("success", "success", "decide", "decide", "failure", "failure"))
                .addEdge("success", END)
                .addEdge("failure", END)
                .compile();

        Map<String, Object> input = updates(
                "turn", 0,
                "observationReady", false,
                "goalComplete", false,
                "decisionStatus", "",
                "lastInstruction", "",
                "lastError", "",
                "history", new ArrayList<String>());

        GoalState state = workflow.invoke(input)
                .orElseThrow(() -> new IllegalStateException("LangGraph4j returned no autonomous terminal state"));
        return new Result(
                state.goalComplete(),
                state.turn(),
                state.lastError(),
                finalAssessment.get(),
                List.copyOf(state.history()));
    }

    private static List<String> append(List<String> existing, String value) {
        List<String> out = new ArrayList<>(existing == null ? List.of() : existing);
        out.add(value);
        return out;
    }

    private static String message(Exception error) {
        if (error == null) return "Unknown autonomous execution failure";
        return error.getMessage() == null || error.getMessage().isBlank()
                ? error.getClass().getSimpleName()
                : error.getMessage();
    }

    private static String compact(Exception error) { return compact(message(error), 800); }

    private static String compact(String value, int limit) {
        String text = value == null ? "" : value.replaceAll("\\s+", " ").trim();
        return text.length() <= limit ? text : text.substring(0, limit) + "...";
    }

    private static String defaultIfBlank(String value, String fallback) {
        return value == null || value.isBlank() ? fallback : value;
    }

    private static Map<String, Object> updates(Object... pairs) {
        Map<String, Object> values = new LinkedHashMap<>();
        for (int i = 0; i + 1 < pairs.length; i += 2) {
            values.put(String.valueOf(pairs[i]), pairs[i + 1]);
        }
        return values;
    }
}
