package com.itps.vibium.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import static org.junit.jupiter.api.Assertions.*;

class AutonomousGoalGraphTest {
    private final ObjectMapper mapper = new ObjectMapper();

    @Test
    void observesActsAndFinishesOnlyAfterIndependentGoalCheck() throws Exception {
        AutonomousGoalGraph graph = new AutonomousGoalGraph();
        AtomicInteger decisions = new AtomicInteger();
        AtomicInteger actions = new AtomicInteger();

        AutonomousGoalGraph.Result result = graph.run(new AutonomousGoalGraph.Actions() {
            @Override
            public com.fasterxml.jackson.databind.JsonNode observe(int completedTurns, String lastError) {
                return mapper.createObjectNode().put("page", completedTurns == 0 ? "home" : "confirmation");
            }

            @Override
            public AutonomousGoalGraph.Decision decide(com.fasterxml.jackson.databind.JsonNode observation,
                                                       int nextTurn, List<String> history, String lastError) {
                if (decisions.incrementAndGet() == 1) {
                    return new AutonomousGoalGraph.Decision("ACTION", "Click Create Payment", "next required action", 0.93);
                }
                return new AutonomousGoalGraph.Decision("DONE", "", "confirmation page is visible", 0.96);
            }

            @Override
            public AutonomousGoalGraph.ActionOutcome execute(AutonomousGoalGraph.Decision decision, int turn) {
                actions.incrementAndGet();
                return new AutonomousGoalGraph.ActionOutcome(true, "");
            }

            @Override
            public AutonomousGoalGraph.GoalAssessment validateGoal(com.fasterxml.jackson.databind.JsonNode observation,
                                                                    int completedTurns, List<String> history) {
                return new AutonomousGoalGraph.GoalAssessment(true, "goal proven", "confirmation", 0.98);
            }
        }, 5);

        assertTrue(result.success());
        assertEquals(1, result.turns());
        assertEquals(1, actions.get());
        assertNotNull(result.finalAssessment());
        assertTrue(result.history().stream().anyMatch(line -> line.startsWith("GOAL_CONFIRMED")));
    }

    @Test
    void letsSupervisorReplanAfterFailedAction() throws Exception {
        AutonomousGoalGraph graph = new AutonomousGoalGraph();
        AtomicInteger actionCalls = new AtomicInteger();

        AutonomousGoalGraph.Result result = graph.run(new AutonomousGoalGraph.Actions() {
            @Override
            public com.fasterxml.jackson.databind.JsonNode observe(int completedTurns, String lastError) {
                return mapper.createObjectNode().put("turn", completedTurns).put("lastError", lastError == null ? "" : lastError);
            }

            @Override
            public AutonomousGoalGraph.Decision decide(com.fasterxml.jackson.databind.JsonNode observation,
                                                       int nextTurn, List<String> history, String lastError) {
                if (nextTurn == 1) {
                    return new AutonomousGoalGraph.Decision("ACTION", "Click old menu", "first idea", 0.8);
                }
                if (nextTurn == 2) {
                    assertTrue(lastError.contains("not found"));
                    return new AutonomousGoalGraph.Decision("ACTION", "Click Payments and Transfers", "replanned", 0.9);
                }
                return new AutonomousGoalGraph.Decision("DONE", "", "target reached", 0.95);
            }

            @Override
            public AutonomousGoalGraph.ActionOutcome execute(AutonomousGoalGraph.Decision decision, int turn) {
                if (actionCalls.incrementAndGet() == 1) {
                    return new AutonomousGoalGraph.ActionOutcome(false, "old menu not found");
                }
                return new AutonomousGoalGraph.ActionOutcome(true, "");
            }

            @Override
            public AutonomousGoalGraph.GoalAssessment validateGoal(com.fasterxml.jackson.databind.JsonNode observation,
                                                                    int completedTurns, List<String> history) {
                return new AutonomousGoalGraph.GoalAssessment(true, "target reached", "page evidence", 0.97);
            }
        }, 5);

        assertTrue(result.success());
        assertEquals(2, result.turns());
        assertEquals(2, actionCalls.get());
        assertTrue(result.history().stream().anyMatch(line -> line.contains("ACTION_1_FAILED")));
        assertTrue(result.history().stream().anyMatch(line -> line.contains("ACTION_2_OK")));
    }

    @Test
    void stopsAtTurnLimit() throws Exception {
        AutonomousGoalGraph graph = new AutonomousGoalGraph();

        AutonomousGoalGraph.Result result = graph.run(new AutonomousGoalGraph.Actions() {
            @Override
            public com.fasterxml.jackson.databind.JsonNode observe(int completedTurns, String lastError) {
                return mapper.createObjectNode();
            }

            @Override
            public AutonomousGoalGraph.Decision decide(com.fasterxml.jackson.databind.JsonNode observation,
                                                       int nextTurn, List<String> history, String lastError) {
                return new AutonomousGoalGraph.Decision("ACTION", "Click Next", "continue", 0.8);
            }

            @Override
            public AutonomousGoalGraph.ActionOutcome execute(AutonomousGoalGraph.Decision decision, int turn) {
                return new AutonomousGoalGraph.ActionOutcome(true, "");
            }

            @Override
            public AutonomousGoalGraph.GoalAssessment validateGoal(com.fasterxml.jackson.databind.JsonNode observation,
                                                                    int completedTurns, List<String> history) {
                return new AutonomousGoalGraph.GoalAssessment(false, "not done", "", 0.8);
            }
        }, 2);

        assertFalse(result.success());
        assertEquals(2, result.turns());
        assertTrue(result.history().stream().anyMatch(line -> line.startsWith("END_FAILED")));
    }
}
