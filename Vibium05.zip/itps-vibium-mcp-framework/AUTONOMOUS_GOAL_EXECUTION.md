# Autonomous Goal Execution

The framework now supports three execution modes without removing the existing behavior:

1. `SCRIPTED` - executes uploaded steps using the existing deterministic/LLM planner.
2. `AGENTIC_STEP` - wraps each uploaded step in LangGraph plan -> execute -> validate -> heal/re-plan.
3. `AUTONOMOUS_GOAL` - a LangGraph supervisor chooses the next UI action from the current page until the goal is independently validated.

## Scenario input

JSON scenarios can add:

```json
{
  "goal": "Create an international payment draft for {{beneficiary}} and stop before final submission.",
  "constraints": "Use account {{account}}. Verify fees are visible."
}
```

For Excel, add optional columns named `Goal` and `Constraints`. Existing `Steps` are still accepted in Autonomous Goal mode, but they are supplied to the supervisor only as non-binding hints rather than executed in order.

If `Goal` is blank, the framework falls back to `Expected`, and finally to the scenario name plus legacy step hints. Providing an explicit Goal is recommended.

## Autonomous supervisor loop

```text
START
  -> OBSERVE current browser
  -> DECIDE one atomic next instruction
      -> ACTION: execute through the existing Vibium action engine
          -> per-step LangGraph healing remains available
          -> OBSERVE again
      -> DONE: run an independent goal-evidence validator
          -> confirmed -> PASS
          -> not confirmed -> DECIDE again
      -> BLOCKED -> FAIL safely
  -> maximum autonomous turns -> FAIL safely
```

The outer supervisor does not generate raw Selenium, Playwright, selectors, or MCP calls. It generates one natural-language instruction at a time. The existing framework remains responsible for deterministic XPath/CSS priority, Vibium MCP planning, action evidence, self-healing, screenshots and reports.

## Safety controls

`Allow final submit / destructive test actions` is OFF by default. When OFF, the autonomous supervisor is instructed and deterministically guarded against final submit/confirm, approval, deletion, irreversible payment/transfer/send and similar actions.

Autonomous URL navigation is restricted to the configured application origin when the supervisor emits an absolute URL.

`Autonomous max action turns` bounds the loop (1-30 on the server; UI presets are provided).

## Reporting

Every discovered autonomous action becomes a normal `StepResult`, so existing HTML/Excel reporting continues to work. The final synthetic step is `Autonomous goal validation` and includes the LangGraph supervisor history, completed turns, final evidence, confidence and safety settings.

## Runtime requirements

No Python LangGraph service, LangChain4j, vector database, LangGraph Studio or OpenCode runtime is required. The application continues to use Java 17+, the existing LLM endpoint, Vibium MCP and `langgraph4j-core`.
