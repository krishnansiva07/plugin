# Autonomous Agentic UI Execution - Implementation Notes

## Added

- `AutonomousGoalGraph.java` - LangGraph4j supervisor state machine.
- Execution modes: `SCRIPTED`, `AGENTIC_STEP`, `AUTONOMOUS_GOAL`.
- Scenario `goal` and `constraints` fields.
- Excel `Goal` and `Constraints` column parsing.
- Autonomous max-turn setting (default 12, server max 30).
- Destructive/final-submit autonomous action guard, OFF by default.
- Same-origin guard for absolute URLs selected by the supervisor.
- Independent LLM goal validation before an autonomous scenario can pass.
- Every discovered autonomous action is stored as an ordinary `StepResult`.
- Existing Steps become non-binding hints in Autonomous Goal mode.
- `samples/autonomous-goal-example.json`.
- `AUTONOMOUS_GOAL_EXECUTION.md`.
- `AutonomousGoalGraphTest.java`.

## Preserved

- User XPath absolute first priority.
- User CSS absolute first priority.
- Exact visible text path.
- Focused-input executor.
- Enterprise dropdown executor.
- Existing `AgenticActionGraph` self-healing.
- Cookie replacement/additional cookies.
- Shared-browser and separate-browser execution.
- Parallel execution.
- Existing reports/screenshots/MCP diagnostics.

## Validation performed in the packaging environment

- Model classes compile with `javac`.
- All Java source files were parsed by `javac`; no Java syntax errors were found.
- Test source files were parsed; no Java syntax errors were found.
- `app.js` passes `node --check`.
- Autonomous sample JSON validates successfully.
- HTML parses successfully.
- No JAR is included in the package.

A full Maven dependency build was not executable in this sandbox because Maven/dependency resolution is unavailable here. Run `build-windows.cmd` or your normal Maven build locally; it will resolve the already configured `langgraph4j-core` dependency.
