# ASTRA Visual Guardian — intelligent exploration validation

## Build and provenance

Updated from `ASTRA_Visual_Guardian_Coverage.zip`. Eliya remains a read-only architectural reference. No changes were made to Eliya and no running Eliya instance is required. The independent Java HTTP server and Chromium CDP architecture are retained. Compilation used JDK 21 with `javac --release 17`; class major version 61. The shipped JAR is identical to the rebuilt JAR tested by the final integration fixtures. JavaScript syntax, JAR archive integrity and SHA-256 were verified. Complete Java/frontend source, scripts, documentation and tests are included.

## Changes and qualification

| Area | Implemented behavior |
|---|---|
| Model preflight | Explicit UI AI/DOM strategy. Required Agent readiness and consent checked before browser launch. Configured Vision is probed; Reviewer optional. Synthetic readiness calls separated from actual exploration calls. Legacy API AUTO mode retained. |
| Contextual locators | Live candidate ranking uses exact semantic label, role, element type, form, link destination, stable IDs/test IDs, container label/ID, row identity, control associations and ancestor scope. Conflicting row identity is rejected. Browser rechecks live identity before action. |
| AI ambiguity assistance | User-selected Agent or Vision endpoint can suggest only a bounded eligible candidate index. Automatic acceptance requires a uniquely corroborating recorded navigation-container objective; otherwise user confirmation or an inconclusive result. Vision fallback receives masked screenshot. No arbitrary model-generated script/selector is executed. |
| Human intervention | Candidate list, recommendation, choose/skip controls and safe reinspection before executing; unresolved and skipped paths remain visible. |
| Navigation | Persistent verified directed graph; shortest observed route to a known prerequisite; current branch prioritized; stale graph transitions invalidated; safe home replay fallback. |
| Loop prevention | Semantic action ledger and exploration identity retain exact labels/context/scroll state, ignore unstructured volatile text. Known captured state IDs preserved when resuming legacy evidence. No claim of exactly-once browser actions. |
| Identity memory | Verified resolved actions saved at path checkpoints and included in new replay paths. Older baselines without enriched actions fall back to the original path. |
| Execution reliability | Start/resume return a detached response snapshot, preventing a reproduced concurrent modification during JSON serialization. Manual intervention invalidates live path assumptions. |
| Diagnostics | Dashboard and HTML report show home resets, graph shortcuts/steps, duplicate actions avoided, recovered identities reused, AI/user resolutions and model preflight results. |
| Coverage | Prior pending/unresolved/expected-route/exclusion review gate and screenshot integrity checks retained. Not a proof of complete business-flow coverage. |

## Final-artifact checks

- `intelligence-unit-final.log` — 55 checks passed: new context and graph tests plus existing locator, browser-script fixture, nested-scroll, coverage and checkpoint tests. Java tests use synthetic DOM metadata; JavaScript tests execute actual action scripts against small DOM fixtures, not Chromium.
- `intelligence-flow-final.log` — 7 checks passed: AI readiness gate; explicit DOM fallback; verified graph reuse; cyclic navigation termination; AI advice for genuine ambiguity; user choice; skipped-path review.
- `intelligence-coverage-final.log` — 6 checks passed: partial capture, legacy skip recovery with original screenshot preserved, approval gate, exclusion review, report and replay configuration.
- `intelligence-resume-final.log` — 3 checks passed: partial capture, legacy queue deduplication, unchanged previously captured evidence and journal continuity.
- `intelligence-regression.log` — 34/34 checks passed on an earlier build of this update, after fixing concurrent modification. This is not counted as a final-artifact test.

71 targeted final-artifact checks passed. The full final-artifact regression (`intelligence-regression-final.log`) also passed 34/34 checks with exit code 0. Total: 105 passed checks on the final artifact across the five suites. All browser integration fixtures are **mock CDP browser protocol** and a local simulated model endpoint. They exercise the actual Java orchestration, API, model request format, persistence, replay, image comparison and reports, but do not demonstrate real corporate browser navigation or model accuracy.

## Real-browser qualification

The environment has an administrator-managed Chromium `URLBlocklist: ["*"]`. A previous real-browser integration attempt failed with `net::ERR_BLOCKED_BY_ADMINISTRATOR` (`real-browser-blocked.log`, historical release). The current final real-browser smoke was stopped at its 25-second test limit after successful JAR startup/model fixture checks and before capture completed (`real-browser-final.log`); it is not a pass. The administrator restriction was not changed. Real Chrome/Edge, Windows display scaling, client certificate/PIN/MFA, corporate proxy, SSO and your actual Agent/Vision endpoint must be verified in your authorized desktop environment. Synthetic Vision testing verifies the image request contract, not image understanding accuracy.

## Known limits

- The graph is capture-scoped; replay restores recorded prerequisites for isolation. Necessary prerequisite actions can repeat after navigation, authentication, manual intervention or restart. No verified alternative path means a home reset may still occur.
- AI does not autonomously approve security exceptions, submit unapproved operations or guess between indistinguishable controls. The interactive choice flow covers ambiguous elements; there is no general-purpose AI business-data/approval workflow. AI-assisted readiness does not guarantee availability throughout a run; runtime model errors can trigger an explicitly logged deterministic fallback.
- Some DOM patterns lack reliable parent or row identity, particularly custom graphical controls, virtualized lists, cross-origin frames, closed shadow roots, canvas and new tabs. These remain restricted or require manual coverage review. No unrestricted XPath/AI scripts or full browser computer-use engine is implemented.
- A navigation fingerprint approximates equivalent interactive structure, not complete application state. Distinct underlying business data, permissions and dynamic labels may require separate journeys. The existing coverage gate checks the provided expected routes, eligible discovered paths, exceptions and evidence; a separate independent AI coverage-verification agent is not implemented. No autonomous guarantee of all business flows.
- Existing captures retain their original evidence, viewport and legacy metadata. Resume can enrich newly executed steps but cannot retrofit context into every old screenshot. A fresh scoped baseline is recommended for comprehensive rediscovery. Large archives and exploration retain the documented resource ceilings; enterprise-scale performance has not been benchmarked.
- Local package is launchable and tested against fixtures, **not production-certified**.

## Upgrade and reproduce

Stop the old application, close editors holding run files, back up `guardian-data`, extract to a separate folder, and copy the saved data directory (or pass `--data`). Launch `launch.cmd`. Configure exact model endpoints and IDs in Model settings and test connections. Select AI mode only if authorized to submit the masked/sanitized evidence. Resume an unfinished capture with the new model settings; previously approved baselines cannot be changed. For a fully context-enriched capture, create a new baseline. Build and test commands are in README.md. Use the final JAR SHA in `validation/jar.sha256` to check the executable.
