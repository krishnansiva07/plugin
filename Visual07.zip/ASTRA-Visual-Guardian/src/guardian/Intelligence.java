package guardian;

import java.util.*;
import static guardian.Json.*;
import static guardian.Util.*;

/** Conservative contextual matching and a persistent graph of verified transitions. */
final class Intelligence {
 static String identity(String value){return clean(value).toLowerCase(Locale.ROOT).replaceAll("\\s+"," ");}
 static final List<String> CONTEXT=List.of("containerId","containerLabel","formId","rowKey","nearLabel","ariaControls","scopeTrail");
 static List<Map<String,Object>> eligible(Map<String,Object> wanted,Map<String,Object> dom,Map<String,Object> cfg){
  var out=new ArrayList<Map<String,Object>>();String label=identity(s(wanted,"label"));
  for(Object o:Engine.candidates(dom,cfg,null)){var a=map(o);if(!s(a,"action").equals(s(wanted,"action"))||!s(a,"option").equals(s(wanted,"option")))continue;
   boolean sameRole=s(a,"role").equals(s(wanted,"role")),sameLabel=!label.isBlank()&&label.equals(identity(s(a,"label"))),sameHref=!s(wanted,"href").isBlank()&&s(wanted,"href").equals(s(a,"href"));
   if(sameRole&&s(a,"tag").equals(s(wanted,"tag"))&&s(a,"type").equals(s(wanted,"type"))&&b(a,"form")==b(wanted,"form")&&(sameLabel||sameHref)&&(!label.matches(".*\\d.*")||sameLabel)&&(!s(wanted,"href").isBlank()?sameHref:true))out.add(a);
  }return out;
 }
 static int contextScore(Map<String,Object> w,Map<String,Object> a){int score=0;for(String k:CONTEXT){String x=identity(s(w,k)),y=identity(s(a,k));if(!x.isBlank()&&!y.isBlank()){if(x.equals(y))score+=k.equals("containerId")||k.equals("rowKey")||k.equals("ariaControls")?8:4;else if(k.equals("rowKey"))return -100;else score-=4;}}return score;}
 static int stableScore(Map<String,Object> w,Map<String,Object> a){int score=0;for(String k:List.of("id","testId","name"))if(!s(w,k).isBlank()&&s(w,k).equals(s(a,k)))score+=k.equals("name")?5:15;return score;}
 static boolean compatible(Map<String,Object> w,Map<String,Object> a){return s(w,"rowKey").isBlank()||s(w,"rowKey").equals(s(a,"rowKey"));}
 static Map<String,Object> resolve(Map<String,Object> w,List<Map<String,Object>> hits)throws Engine.Missing{
  var allowed=hits.stream().filter(a->compatible(w,a)).toList();String label=s(w,"label");if(allowed.isEmpty())throw new Engine.Missing("Element missing: "+label);
  if(allowed.size()==1){var a=allowed.get(0);if(contextScore(w,a)<0&&stableScore(w,a)==0)throw new Engine.Missing("Element context changed: "+label,true);return a;}
  int best=Integer.MIN_VALUE,second=Integer.MIN_VALUE;Map<String,Object> winner=null;
  for(var a:allowed){int score=stableScore(w,a)+contextScore(w,a);if(score>best){second=best;best=score;winner=a;}else if(score>second)second=score;}
  if(best>=4&&best-second>=4&&contextScore(w,winner)>=0)return winner;
  throw new Engine.Missing("Ambiguous element: "+label+" ("+allowed.size()+" eligible candidates; contextual evidence insufficient)",true);
 }
 // CSS is intentionally not a semantic identity: a changed sibling order must not create a new action.
 static String semanticKey(Map<String,Object> a){var m=obj("action",s(a,"action"),"role",s(a,"role"),"label",identity(s(a,"label")),"href",s(a,"href"),"option",s(a,"option"));for(String k:CONTEXT)if(!s(a,k).isBlank())m.put(k,s(a,k));String identity=!s(a,"testId").isBlank()?s(a,"testId"):s(a,"id");if(!identity.isBlank())m.put("identity",identity);else if(s(a,"href").isBlank()&&s(a,"ariaControls").isBlank()&&s(a,"rowKey").isBlank())m.put("selector",s(a,"css"));return hash(m);}
 // Exploration identity excludes volatile body text but retains controls, headings, selected state and scroll position.
 static String discoveryKey(String route,Map<String,Object> dom){var rows=new ArrayList<String>();for(Object o:list(dom.get("elements"))){var a=map(o);rows.add(hash(obj("role",s(a,"role"),"label",identity(s(a,"label")),"href",s(a,"href"),"selected",s(a,"selected"),"expanded",s(a,"expanded"),"disabled",b(a,"disabled"),"container",s(a,"containerLabel"),"scope",s(a,"scopeTrail"),"row",s(a,"rowKey"),"controls",s(a,"ariaControls"),"form",s(a,"formId"),"stableId",s(a,"testId"),"options",a.get("options"),"option",s(a,"option"))));}Collections.sort(rows);return hash(obj("route",route,"title",s(dom,"title"),"headings",dom.get("headings"),"dialogs",dom.get("dialogs"),"controls",rows,"scrolls",dom.get("scrolls")));}
 static Map<String,Object> graph(Map<String,Object> r){if(!(r.get("navigationGraph") instanceof Map))r.put("navigationGraph",obj("paths",obj(),"edges",obj()));return map(r.get("navigationGraph"));}
 static Map<String,Object> paths(Map<String,Object> r){return map(graph(r).get("paths"));}
 static Map<String,Object> edges(Map<String,Object> r){return map(graph(r).get("edges"));}
 static void remember(Map<String,Object> r,List<Object> path,String state){paths(r).put(Engine.pathKey(path),state);}
 static void transition(Map<String,Object> r,String from,String to,Map<String,Object> action){if(from.isBlank()||to.isBlank()||from.equals(to))return;var e=edges(r);String key=hash(List.of(from,semanticKey(action)));var prior=map(e.get(key));if(!prior.isEmpty()&&!s(prior,"to").equals(to)){prior.put("unstable",true);return;}if(e.size()<30000)e.putIfAbsent(key,obj("from",from,"to",to,"action",new LinkedHashMap<>(action)));}
 static void invalidate(Map<String,Object> r,Map<String,Object> edge){edge.put("unstable",true);r.put("graphInvalidations",num(r.get("graphInvalidations"),0)+1);}
 static List<Map<String,Object>> shortest(Map<String,Object> r,String from,String to){if(from.isBlank()||to.isBlank())return null;if(from.equals(to))return List.of();var adjacency=new HashMap<String,List<Map<String,Object>>>();for(Object o:edges(r).values()){var e=map(o);if(!b(e,"unstable"))adjacency.computeIfAbsent(s(e,"from"),k->new ArrayList<>()).add(e);}var seen=new HashSet<String>();var q=new ArrayDeque<String>();var prev=new HashMap<String,Map<String,Object>>();q.add(from);seen.add(from);while(!q.isEmpty()&&seen.size()<30000){String x=q.remove();for(var e:adjacency.getOrDefault(x,List.of())){String y=s(e,"to");if(!seen.add(y))continue;prev.put(y,e);if(y.equals(to)){var result=new ArrayList<Map<String,Object>>();while(!y.equals(from)){var edge=prev.get(y);result.add(edge);y=s(edge,"from");}Collections.reverse(result);return result.size()<=30?result:null;}q.add(y);}}return null;}
 static Map<String,Integer> distances(Map<String,Object> r,String from){var adj=new HashMap<String,List<String>>();for(Object o:edges(r).values()){var e=map(o);if(!b(e,"unstable"))adj.computeIfAbsent(s(e,"from"),k->new ArrayList<>()).add(s(e,"to"));}var d=new HashMap<String,Integer>();var q=new ArrayDeque<String>();d.put(from,0);q.add(from);while(!q.isEmpty()&&d.size()<30000){String x=q.remove();int next=d.get(x)+1;if(next>30)continue;for(String y:adj.getOrDefault(x,List.of()))if(!d.containsKey(y)){d.put(y,next);q.add(y);}}return d;}
 static int bestPath(Map<String,Object> r,List<Object> queue,List<Object> live,String state){int best=0,bestTier=Integer.MAX_VALUE,cost=Integer.MAX_VALUE;var distance=distances(r,state);var paths=paths(r);for(int i=0;i<queue.size();i++){var p=list(map(queue.get(i)).get("path"));int tier=2,c=p.size()+2;if(Engine.prefix(live,p)){tier=0;c=p.size()-live.size();}else if(!p.isEmpty()){String source=str(paths.get(Engine.pathKey(p.subList(0,p.size()-1))));Integer n=distance.get(source);if(n!=null){tier=1;c=n+1;}}if(tier<bestTier||tier==bestTier&&c<cost){best=i;bestTier=tier;cost=c;if(tier==0&&c==0)break;}}return best;}
 static Map<String,Object> brief(Map<String,Object> a){var m=obj("label",clip(norm(s(a,"label")),120),"role",s(a,"role"),"href",clip(norm(s(a,"href")),160));for(String k:CONTEXT)if(!k.equals("rowKey")&&!s(a,k).isBlank())m.put(k,clip(norm(s(a,k)),120));if(a.get("box") instanceof Map)m.put("box",a.get("box"));return m;}
 static int objectiveMatch(List<Object> path,int step,List<Map<String,Object>> hits){if(step<1||step>path.size())return -1;var prior=map(path.get(step-1));if(s(prior,"href").isBlank()&&!Set.of("tab","menuitem").contains(s(prior,"role")))return -1;String label=identity(s(prior,"label"));if(label.isBlank())return -1;int found=-1;for(int i=0;i<hits.size();i++)if(label.equals(identity(s(hits.get(i),"containerLabel")))){if(found>=0)return -1;found=i;}return found;}
 static Map<String,Object> resolutions(Map<String,Object> r){if(!(r.get("resolvedSteps") instanceof Map))r.put("resolvedSteps",obj());return map(r.get("resolvedSteps"));}
 static void rememberResolved(Map<String,Object> r,List<Object> path,String source,Map<String,Object> chosen){var action=new LinkedHashMap<>(chosen);action.remove("strictLive");resolutions(r).put(Engine.pathKey(path),obj("source",source,"action",action));}
 static List<Object> resolvedPath(Map<String,Object> r,List<Object> path){var result=new ArrayList<Object>();for(int i=0;i<path.size();i++){var remembered=map(resolutions(r).get(Engine.pathKey(path.subList(0,i+1))));var a=map(remembered.get("action"));result.add(a.isEmpty()?path.get(i):a);}return result;}
 static int modelChoice(String text,int count){try{var m=read(text.substring(text.indexOf('{'),text.lastIndexOf('}')+1));Object raw=m.get("candidate");if(!(raw instanceof Number)||dbl(raw,-1)!=num(raw,-1))return -1;int i=num(raw,-1);return i>=0&&i<count?i:-1;}catch(Exception e){return -1;}}
}
