package guardian;
import java.util.*;
import java.nio.file.*;
import static guardian.Json.*;
import static guardian.Util.*;
final class IntelligenceChecks {
 static void check(String n,boolean pass){if(!pass)throw new AssertionError(n);System.out.println("PASS "+n);}
 static Map<String,Object> a(String label,String css,String container,String row){return obj("tag","button","role","button","type","button","target","","action","CLICK","label",label,"css",css,"form",false,"containerLabel",container,"rowKey",row);}
 @SafeVarargs static Map<String,Object> dom(Map<String,Object>... a){return obj("elements",List.of(a),"headings",List.of("Dashboard"));}
 public static void main(String[] args)throws Exception{
  var cfg=Store.config(obj());var old=a("Search","#old","Alerts","");var wrong=a("Search","#old","Transactions","");var right=a("Search","#new","Alerts","");
  check("same label in different containers resolved by context, not old CSS",s(Engine.match(old,dom(wrong,right),cfg),"css").equals("#new"));
  var row=a("View","#old","Alerts","record-123");var other=a("View","#old","Alerts","record-456");var moved=a("View","#new","Alerts","record-123");check("row identity survives changed sibling order",s(Engine.match(row,dom(other,moved),cfg),"css").equals("#new"));
  try{Engine.match(row,dom(other),cfg);throw new AssertionError("different row accepted");}catch(Engine.Missing e){check("different record rejected even with identical label and CSS",true);}
  try{Engine.match(old,dom(right,a("Search","#other","Alerts","")),cfg);throw new AssertionError("unproven choice accepted");}catch(Engine.Missing e){check("genuinely identical controls remain ambiguous",e.ambiguous);}
  check("model response can select only a bounded integer candidate",Intelligence.modelChoice("{\"candidate\":1}",2)==1&&Intelligence.modelChoice("{\"candidate\":9}",2)==-1&&Intelligence.modelChoice("{\"candidate\":0.5}",2)==-1&&Intelligence.modelChoice("{\"candidate\":\"1\"}",2)==-1);
  check("semantic identity preserves numeric record labels",!Intelligence.semanticKey(a("View 123","#x","Alerts","")).equals(Intelligence.semanticKey(a("View 456","#x","Alerts",""))));
  var d1=dom(right);var d2=dom(right);d1.put("visibleText","Updated at 10:01");d2.put("visibleText","Updated at 10:02");check("volatile text does not generate a new exploration frontier",Intelligence.discoveryKey("/",d1).equals(Intelligence.discoveryKey("/",d2)));
  check("distinct row states are not merged",!Intelligence.discoveryKey("/",dom(row)).equals(Intelligence.discoveryKey("/",dom(other))));
  var r=obj();var ab=a("View","#ab","A","");var bc=a("Details","#bc","B","");var ca=a("Home","#ca","C","");var ac=a("Report","#ac","A","");Intelligence.transition(r,"A","B",ab);Intelligence.transition(r,"B","C",bc);Intelligence.transition(r,"C","A",ca);Intelligence.transition(r,"A","C",ac);
  check("shortest known transition chosen in cyclic graph",Intelligence.shortest(r,"A","C").size()==1&&Intelligence.shortest(r,"B","A").size()==2);
  check("unreachable graph target terminates",Intelligence.shortest(r,"A","Z")==null);
  Intelligence.transition(r,"A","D",ac);check("unstable transition excluded, alternate graph path used",Intelligence.shortest(r,"A","C").size()==2);
  Intelligence.remember(r,List.of(ab),"B");var restored=read(write(r));check("navigation graph survives checkpoint serialization",Intelligence.shortest(restored,"B","A").size()==2&&str(Intelligence.paths(restored).get(Engine.pathKey(List.of(ab)))).equals("B"));
  var q=new ArrayList<Object>(List.of(obj("path",List.of(ac)),obj("path",List.of(ab,bc))));check("scheduler prefers current module child rather than home restart",Intelligence.bestPath(restored,q,List.of(ab),"B")==1);
  check("legacy API auto mode and explicit DOM strategy preserved",s(cfg,"strategy").equals("AUTO")&&s(Store.config(obj("strategy","DOM")),"strategy").equals("DOM"));
  var goal=obj("action","CLICK","label","Alerts","role","a","href","/alerts");check("AI candidate requires unique recorded navigation objective",Intelligence.objectiveMatch(List.of(goal,old),1,List.of(wrong,right))==1&&Intelligence.objectiveMatch(List.of(goal,old),1,List.of(right,right))==-1);
  Intelligence.rememberResolved(r,List.of(old),"source",right);check("resolved identity retained for exported replay path",s(map(Intelligence.resolvedPath(read(write(r)),List.of(old)).get(0)),"css").equals("#new"));
  // Write actual JS for contextual browser revalidation.
  Files.writeString(Path.of(args[0]),Browser.actionScript(new LinkedHashMap<>(right){{put("strictLive",true);}}));
 }
}
