#!/usr/bin/env python3
"""New agentic paths: graph reuse, model gate, candidate confirmation; mock CDP + local HTTP model."""
import json, os, re, socket, subprocess, tempfile, threading, time, urllib.request, urllib.error, sys
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]; JAR=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else ROOT/'build/visual-guardian.jar'
requests=[]; model_requests=[]
class Site(BaseHTTPRequestHandler):
    def log_message(self,*a):pass
    def reply(self,body,code=200,kind='text/html'):
        b=body.encode();self.send_response(code);self.send_header('Content-Type',kind);self.send_header('Content-Length',str(len(b)));self.end_headers();self.wfile.write(b)
    def do_GET(self):
        requests.append(self.path)
        pages={'/':'<a href="/a">Module A</a><a href="/b">Module B</a>','/a':'<a href="/a/alerts">Alerts</a><a href="/a/transactions">Transactions</a>','/a/alerts':'<a href="/a">Module A</a>','/a/transactions':'<a href="/a">Module A</a>','/b':'<a href="/">Home</a>','/ambiguous':'<button id="one">Search</button><button id="two">Search</button>'}
        self.reply(f'<html><title>{self.path}</title><main><h1>{self.path}</h1>{pages.get(self.path,"")}</main></html>')
    def do_POST(self):
        q=json.loads(self.rfile.read(int(self.headers['Content-Length'])));model_requests.append(q)
        system=q['messages'][0]['content'];answer='{"candidate":1}' if 'ambiguous UI element' in system else '{"order":[0,1]}' if 'Rank only' in system else 'OK'
        self.reply(json.dumps({'choices':[{'message':{'content':answer}}],'usage':{'total_tokens':10}}),kind='application/json')
site=ThreadingHTTPServer(('127.0.0.1',0),Site);threading.Thread(target=site.serve_forever,daemon=True).start();url='http://127.0.0.1:'+str(site.server_port)
with tempfile.TemporaryDirectory() as td:
    data=Path(td)/'data';sock=socket.socket();sock.bind(('127.0.0.1',0));port=sock.getsockname()[1];sock.close();base=f'http://127.0.0.1:{port}';p=subprocess.Popen(['java','-jar',str(JAR),'--port',str(port),'--data',str(data)],stdout=subprocess.DEVNULL)
    try:
        for _ in range(80):
            try:html=urllib.request.urlopen(base,timeout=1).read().decode();break
            except Exception:time.sleep(.2)
        token=re.search('name="guardian-token" content="([^"]+)"',html).group(1)
        def api(path,body=None,expected=200):
            req=urllib.request.Request(base+'/api/'+path,data=json.dumps(body).encode() if body is not None else None,headers={'X-Guardian-Token':token,'Content-Type':'application/json'})
            try:res=urllib.request.urlopen(req,timeout=30);code=res.status;out=res.read()
            except urllib.error.HTTPError as ex:code=ex.code;out=ex.read()
            assert code==expected,(path,code,out[:300]);return json.loads(out)
        def wait(rid,predicate=lambda r:not r['active'],timeout=90):
            for _ in range(int(timeout/.25)):
                r=api('runs/'+rid)
                if predicate(r):return r
                time.sleep(.25)
            raise AssertionError('timeout '+str(r)[:1000])
        def check(name,cond):
            assert cond,name;print('PASS '+name,flush=True)
        cfg=dict(browser=str(ROOT/'tests/mock_browser.py'),headless=True,captureConsent=True,autoAuth=True,maxStates=50,maxActions=50,maxDepth=5,settleMs=100,locatorSeconds=1,pageSeconds=10,interactiveResolution=True)
        suite=api('suites',dict(name='Intelligence fixture',url=url,config=cfg));sid=suite['id']
        def start(target,**overrides):return api('runs',dict(suiteId=sid,mode='CAPTURE',target=target,config=dict(cfg,**overrides)))['id']
        rid=start(url,strategy='AI',allowModelData=False);r=wait(rid)
        check('AI readiness refuses unauthorized or unconfigured model before browser launches',r['status']=='ERROR' and 'preflight' in r['message'].lower() and not requests)
        api('runs/resume',dict(id=rid,config=dict(strategy='DOM',allowModelData=False)));r=wait(rid)
        check('explicit deterministic fallback resumes and captures all fixture routes',r['status']=='COMPLETED' and set(x['route'] for x in r['states'])=={'/','/a','/a/alerts','/a/transactions','/b'})
        check('verified graph edges persisted and graph shortcut used',len(r['navigationGraph']['edges'])>=4 and r.get('graphShortcuts',0)>0)
        check('cycle terminates with no unresolved paths',not r['queue'] and not r['issues'] and r['duplicates']>0 and r['actions']<15)
        api('models',{'agent':{'endpoint':url+'/v1','model':'fixture-agent','timeout':5}})
        rid=start(url+'/ambiguous',strategy='AI',allowModelData=True);r=wait(rid,lambda r:bool(r.get('elementQuestion')) or not r['active'])
        check('AI model preflight completes before ambiguous candidate advice',r['preflight']['agent']=='Responded' and r['elementQuestion']['suggested']==1 and len(r['elementQuestion']['candidates'])==2)
        api('runs/command',{'id':rid,'command':'choose:1'});r=wait(rid,lambda r:r.get('userResolvedElements',0)>0 and bool(r.get('elementQuestion')) or not r['active'])
        check('user-confirmed candidate executes without guessing',r.get('userResolvedElements',0)==1 and r.get('browserActions',0)>=1)
        if r.get('elementQuestion'):api('runs/command',{'id':rid,'command':'skip'});r=wait(rid)
        check('user skip retained as reviewed-scope exception, not pass',r['status']=='REVIEW_REQUIRED' and any('User skipped' in x.get('reason','') for x in r['skipped']))
    finally:p.terminate();p.wait(timeout=15);site.shutdown()
