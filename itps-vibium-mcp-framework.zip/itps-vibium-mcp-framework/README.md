# ITPS VIBIUM Framework - MCP Edition

A Java Spring Boot test runner that executes Excel/JSON UI scenarios through **Vibium MCP**.

This project is intentionally **MCP-first**:

- No Selenium dependency
- No Selenium fallback
- No browser/chromedriver fields in the UI
- Java backend starts a local Vibium MCP server process
- LLM agent selects the right Vibium MCP tool using the live page map and MCP tool schemas
- Post-run evidence is generated as HTML, JSON, Excel, screenshots ZIP, and MCP tools manifest

## Architecture

```text
Excel / JSON scenarios
        ↓
ITPS VIBIUM Java Spring Boot UI
        ↓
LLM agent planner
        ↓
Vibium MCP stdio JSON-RPC client
        ↓
Vibium MCP server
        ↓
Chrome for Testing managed by Vibium
        ↓
HTML / JSON / Excel evidence report
```

## Prerequisites

1. Java 17+
2. Maven 3.8+
3. Vibium portable MCP setup already available, for example:

```text
C:\tools\vibium-portable\node_modules\.bin\vibium.cmd
```

Your machine already passed MCP startup when this command showed:

```text
Waiting for client connection on stdin
```

## Configure Vibium MCP command

Default file:

```text
src/main/resources/application.properties
```

Default value:

```properties
itps.vibium.mcp.command=C:\\tools\\vibium-portable\\node_modules\\.bin\\vibium.cmd
itps.vibium.mcp.args=mcp
itps.vibium.skip-browser-download=true
```

Change the command path only if your portable Vibium folder is different.

## Run

```cmd
mvn clean spring-boot:run
```

Open:

```text
http://localhost:8090
```

## Scenario Excel format

Use the sample file under `samples/itps-vibium-mcp-scenarios.xlsx`.

Supported columns:

```text
id
name
url
steps
expected
data.username
data.password
data.searchText
```

Steps can be plain English, one step per line:

```text
Enter {{username}} in Username field
Enter {{password}} in Password field
Click Login button
Verify Products is visible
```

The framework replaces placeholders from data columns before sending the instruction to the LLM agent.

## Direct MCP JSON step format

For maximum stability, a step can directly call a discovered MCP tool:

```json
{"tool":"<tool-name-from-mcp-tools-json>","arguments":{"ref":"@e1"}}
```

The actual tool names are written after every run to:

```text
target/itps-vibium-runs/<run-id>/mcp-tools.json
```

## Reports

After execution:

```text
target/itps-vibium-runs/<run-id>/
  report.html
  report.json
  report.xlsx
  mcp-tools.json
  screenshots.zip
  screenshots/
```

The UI also gives buttons for:

- Open HTML report
- Download JSON
- Download Excel
- Download screenshots ZIP
- MCP tools manifest

## Important security note

Do not commit LLM tokens into source code or `application.properties`. Paste the token only in the UI for each run.

## Troubleshooting

### MCP process starts and waits forever

That is normal when you run Vibium MCP manually. It communicates over stdin/stdout and waits for a client.

### App says MCP setup failed

Check:

```cmd
C:\tools\vibium-portable\node_modules\.bin\vibium.cmd --version
C:\tools\vibium-portable\node_modules\.bin\vibium.cmd paths
C:\tools\vibium-portable\node_modules\.bin\vibium.cmd is-installed
```

### Browser download fails on office network

Keep this property as true after copying Vibium cache:

```properties
itps.vibium.skip-browser-download=true
```

### Natural-language step selects wrong element

Download `mcp-tools.json` and review the HTML report. The report shows the MCP tool and arguments chosen by the LLM. For critical business flows, use direct MCP JSON steps after confirming the stable tool/ref pattern.
