package com.itps.vibium.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.itps.vibium.model.RunConfig;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.*;

@Service
public class LlmClient {
    private final ObjectMapper mapper = new ObjectMapper();
    private final RestTemplate restTemplate = new RestTemplate();

    public boolean isConfigured(RunConfig config) {
        return config != null && config.getLlmBaseUrl() != null && !config.getLlmBaseUrl().isBlank();
    }

    public String complete(String systemPrompt, String userPrompt, RunConfig config, int maxTokens) throws Exception {
        if (!isConfigured(config)) {
            throw new IllegalArgumentException("LLM base URL is required when Use LLM is ON");
        }
        String endpoint = normalizeEndpoint(config.getLlmBaseUrl());
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("model", defaultIfBlank(config.getLlmModel(), "gpt-oss-120b"));
        body.put("temperature", 0.05);
        body.put("max_tokens", Math.max(300, maxTokens));
        body.put("messages", List.of(
                Map.of("role", "system", "content", systemPrompt),
                Map.of("role", "user", "content", userPrompt)
        ));

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        if (config.getLlmApiKey() != null && !config.getLlmApiKey().isBlank()) {
            headers.setBearerAuth(config.getLlmApiKey().trim());
        }
        String raw = restTemplate.postForObject(endpoint, new HttpEntity<>(body, headers), String.class);
        JsonNode root = mapper.readTree(raw == null ? "{}" : raw);
        String content = root.path("choices").path(0).path("message").path("content").asText();
        return extractJson(content);
    }

    public String planMcpCall(String userPrompt, RunConfig config) throws Exception {
        return complete(agentSystemPrompt(), userPrompt, config, 1300);
    }

    private String agentSystemPrompt() {
        return "You are an MCP browser automation agent for ITPS VIBIUM Framework. " +
                "You must return only valid minified JSON, no markdown. " +
                "You are controlling Vibium through MCP tools. Do not invent Selenium or Playwright code. " +
                "Use the MCP tool list and schemas exactly as provided. " +
                "For icon steps like 'click search icon', do NOT use visible text unless the map says visible text exists. Prefer element reference, aria-label, title, role, data-testid, placeholder, or an accessible name from the page map. " +
                "For dynamic elements, use the page map/reference when available. " +
                "Return one of these shapes: " +
                "{\"tool\":\"toolName\",\"arguments\":{...},\"why\":\"short reason\"} " +
                "or {\"calls\":[{\"tool\":\"toolName\",\"arguments\":{...}}],\"why\":\"short reason\"} " +
                "or for assertion only {\"assert\":{\"type\":\"TEXT_CONTAINS\",\"value\":\"expected text\"},\"tool\":\"map tool name\",\"arguments\":{}}. " +
                "Use provided test data values exactly when filling fields.";
    }

    private String normalizeEndpoint(String base) {
        String trimmed = base.trim();
        if (trimmed.endsWith("/chat/completions")) return trimmed;
        if (trimmed.endsWith("/")) return trimmed + "chat/completions";
        return trimmed + "/chat/completions";
    }

    private String extractJson(String content) {
        if (content == null) return "{}";
        String trimmed = content.trim();
        if (trimmed.startsWith("```")) {
            trimmed = trimmed.replaceFirst("^```(?:json)?", "").replaceFirst("```$", "").trim();
        }
        int objectStart = trimmed.indexOf('{');
        int objectEnd = trimmed.lastIndexOf('}');
        int arrayStart = trimmed.indexOf('[');
        int arrayEnd = trimmed.lastIndexOf(']');
        if (objectStart >= 0 && objectEnd >= objectStart && (arrayStart < 0 || objectStart < arrayStart)) {
            return trimmed.substring(objectStart, objectEnd + 1);
        }
        if (arrayStart >= 0 && arrayEnd >= arrayStart) {
            return trimmed.substring(arrayStart, arrayEnd + 1);
        }
        return trimmed;
    }

    private String defaultIfBlank(String value, String fallback) {
        return value == null || value.isBlank() ? fallback : value;
    }
}
