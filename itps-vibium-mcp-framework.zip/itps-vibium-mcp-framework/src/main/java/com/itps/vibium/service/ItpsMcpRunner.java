package com.itps.vibium.service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.itps.vibium.model.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.time.Instant;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Service
public class ItpsMcpRunner {
    private final LlmClient llmClient;
    private final ReportService reportService;
    private final RunStore runStore;
    private final ObjectMapper mapper = new ObjectMapper();
    private final Path outputRoot;
    private final int requestTimeoutSeconds;
    private final boolean skipBrowserDownload;

    public ItpsMcpRunner(LlmClient llmClient,
                         ReportService reportService,
                         RunStore runStore,
                         @Value("${runner.output-dir:target/itps-vibium-runs}") String outputDir,
                         @Value("${itps.vibium.mcp.request-timeout-seconds:60}") int requestTimeoutSeconds,
                         @Value("${itps.vibium.skip-browser-download:true}") boolean skipBrowserDownload) {
        this.llmClient = llmClient;
        this.reportService = reportService;
        this.runStore = runStore;
        this.outputRoot = Path.of(outputDir);
        this.requestTimeoutSeconds = requestTimeoutSeconds;
        this.skipBrowserDownload = skipBrowserDownload;
    }

    public void execute(List<TestScenario> scenarios, RunConfig config, RunStatus status) {
        Instant runStart = Instant.now();
        status.setStatus("RUNNING");
        status.setStartedAt(runStart);
        Path runDir = outputRoot.resolve(config.getRunId());
        Path screenshotDir = runDir.resolve("screenshots");
        try {
            Files.createDirectories(screenshotDir);
        } catch (Exception e) {
            status.setStatus("FAILED");
            status.setMessage("Unable to create output directory: " + e.getMessage());
            return;
        }

        try (McpClient mcp = new McpClient(config.getMcpCommand(), splitArgs(config.getMcpArgs()), Duration.ofSeconds(requestTimeoutSeconds), skipBrowserDownload)) {
            mcp.start();
            List<McpTool> tools = mcp.initializeAndListTools();
            McpToolCatalog catalog = new McpToolCatalog(tools);
            writeToolsManifest(runDir, tools);

            List<ScenarioResult> scenarioResults = new ArrayList<>();
            for (TestScenario scenario : scenarios) {
                ScenarioResult result = executeScenario(mcp, catalog, scenario, config, screenshotDir);
                scenarioResults.add(result);
                status.setScenarios(new ArrayList<>(scenarioResults));
                status.setPassed((int) scenarioResults.stream().filter(r -> "PASSED".equals(r.getStatus())).count());
                status.setFailed((int) scenarioResults.stream().filter(r -> !"PASSED".equals(r.getStatus())).count());
                status.setStatus(status.getFailed() > 0 ? "COMPLETED_WITH_FAILURES" : "RUNNING");
                runStore.put(status);
                if (!"PASSED".equals(result.getStatus()) && !config.isContinueOnFailure()) break;
            }
            status.setScenarios(scenarioResults);
            status.setPassed((int) scenarioResults.stream().filter(r -> "PASSED".equals(r.getStatus())).count());
            status.setFailed((int) scenarioResults.stream().filter(r -> !"PASSED".equals(r.getStatus())).count());
            status.setStatus(status.getFailed() == 0 ? "PASSED" : "COMPLETED_WITH_FAILURES");
            status.setMessage("MCP-first execution completed. Tools discovered: " + tools.size());
        } catch (Exception e) {
            status.setStatus("FAILED");
            status.setMessage("MCP setup/execution failed: " + e.getMessage());
        } finally {
            status.setFinishedAt(Instant.now());
            try {
                reportService.writeReports(status, runDir);
            } catch (Exception reportError) {
                status.setMessage((status.getMessage() == null ? "" : status.getMessage() + " | ") + "Report generation failed: " + reportError.getMessage());
            }
        }
    }

    private ScenarioResult executeScenario(McpClient mcp, McpToolCatalog catalog, TestScenario scenario, RunConfig config, Path screenshotDir) {
        long scenarioStart = System.currentTimeMillis();
        ScenarioResult scenarioResult = new ScenarioResult();
        scenarioResult.setId(scenario.getId());
        scenarioResult.setName(scenario.getName());
        scenarioResult.setUrl(resolveUrl(scenario.getUrl(), config.getAppBaseUrl()));
        scenarioResult.setStatus("RUNNING");

        List<String> executableSteps = new ArrayList<>();
        if (notBlank(scenarioResult.getUrl())) executableSteps.add("Navigate to " + scenarioResult.getUrl());
        executableSteps.addAll(scenario.getSteps());
        if (notBlank(scenario.getExpected())) executableSteps.add("Verify " + scenario.getExpected());

        int stepNo = 1;
        boolean failed = false;
        for (String rawStep : executableSteps) {
            StepResult sr = executeStep(mcp, catalog, scenario, config, rawStep, stepNo, screenshotDir);
            scenarioResult.getSteps().add(sr);
            if (!"PASSED".equals(sr.getStatus())) {
                failed = true;
                scenarioResult.setErrorMessage(sr.getErrorMessage());
                if (!config.isContinueOnFailure()) break;
            }
            stepNo++;
        }
        scenarioResult.setStatus(failed ? "FAILED" : "PASSED");
        scenarioResult.setDurationMs(System.currentTimeMillis() - scenarioStart);
        return scenarioResult;
    }

    private StepResult executeStep(McpClient mcp, McpToolCatalog catalog, TestScenario scenario, RunConfig config, String rawStep, int stepNo, Path screenshotDir) {
        StepResult sr = new StepResult();
        long start = System.currentTimeMillis();
        String step = applyData(rawStep, scenario.getData());
        sr.setStepNo(stepNo);
        sr.setInstruction(step);
        try {
            JsonNode map = safeMap(mcp, catalog);
            JsonNode plan = planStep(step, scenario, config, catalog, map);
            sr.setActionJson(plan.toString());
            executePlan(mcp, catalog, plan, sr);

            JsonNode assertNode = plan.path("assert");
            if (!assertNode.isMissingNode() && assertNode.has("type")) {
                assertResult(assertNode, sr.getMcpResult(), map);
            }
            sr.setStatus("PASSED");
            if (shouldScreenshot(config, true)) {
                sr.setScreenshot(captureScreenshot(mcp, catalog, screenshotDir, scenario.getId(), stepNo));
            }
        } catch (Exception firstError) {
            Exception finalError = firstError;
            for (int retry = 0; retry < config.getRetryCount(); retry++) {
                try {
                    Thread.sleep(config.getRetryDelayMs());
                    JsonNode remap = safeMap(mcp, catalog);
                    JsonNode replan = replanAfterFailure(step, scenario, config, catalog, remap, finalError.getMessage());
                    sr.setActionJson(replan.toString());
                    executePlan(mcp, catalog, replan, sr);
                    JsonNode assertNode = replan.path("assert");
                    if (!assertNode.isMissingNode() && assertNode.has("type")) {
                        assertResult(assertNode, sr.getMcpResult(), remap);
                    }
                    sr.setStatus("PASSED");
                    finalError = null;
                    break;
                } catch (Exception retryError) {
                    finalError = retryError;
                }
            }
            if (finalError != null) {
                sr.setStatus("FAILED");
                sr.setErrorMessage(finalError.getMessage());
                if (shouldScreenshot(config, false)) {
                    sr.setScreenshot(captureScreenshotQuietly(mcp, catalog, screenshotDir, scenario.getId(), stepNo));
                }
            }
        } finally {
            sr.setDurationMs(System.currentTimeMillis() - start);
        }
        return sr;
    }

    private JsonNode planStep(String step, TestScenario scenario, RunConfig config, McpToolCatalog catalog, JsonNode map) throws Exception {
        JsonNode direct = parseDirectJson(step, catalog);
        if (direct != null) return direct;
        if (!config.isUseLlm()) throw new IllegalArgumentException("Step is natural language, but Use LLM is OFF. Use explicit MCP JSON step or enable LLM.");
        String prompt = basePrompt(step, scenario, catalog, map, null, config);
        return mapper.readTree(llmClient.planMcpCall(prompt, config));
    }

    private JsonNode replanAfterFailure(String step, TestScenario scenario, RunConfig config, McpToolCatalog catalog, JsonNode map, String failure) throws Exception {
        if (!config.isUseLlm()) throw new IllegalArgumentException(failure);
        String prompt = basePrompt(step, scenario, catalog, map, failure, config);
        return mapper.readTree(llmClient.planMcpCall(prompt, config));
    }

    private String basePrompt(String step, TestScenario scenario, McpToolCatalog catalog, JsonNode map, String failure, RunConfig config) throws Exception {
        Map<String, Object> safeData = new LinkedHashMap<>(scenario.getData());
        StringBuilder sb = new StringBuilder();
        sb.append("Scenario: ").append(scenario.getId()).append(" - ").append(scenario.getName()).append("\n");
        sb.append("Instruction: ").append(step).append("\n");
        sb.append("Headless requested: ").append(config.isHeadless()).append("\n");
        sb.append("Test data JSON: ").append(mapper.writeValueAsString(safeData)).append("\n");
        sb.append("Available MCP tools:\n").append(catalog.toPromptText()).append("\n");
        sb.append("Current page map / observation:\n").append(compact(map == null ? "" : map.toString(), 12000)).append("\n");
        if (failure != null) sb.append("Previous attempt failed with: ").append(failure).append("\n");
        sb.append("Return the next MCP tool call JSON. If this is a verification/assertion, use the map/snapshot tool and include assert object. ");
        sb.append("For search icon/menu/calendar icon/dynamic icon, choose an element ref or accessible-name based selector from the map instead of text=search. ");
        return sb.toString();
    }

    private void executePlan(McpClient mcp, McpToolCatalog catalog, JsonNode plan, StepResult sr) throws Exception {
        if (plan.has("calls") && plan.path("calls").isArray()) {
            JsonNode last = null;
            for (JsonNode call : plan.path("calls")) last = executeOneCall(mcp, catalog, call, sr);
            sr.setMcpResult(last == null ? "{}" : compact(last.toString(), 8000));
            return;
        }
        JsonNode result = executeOneCall(mcp, catalog, plan, sr);
        sr.setMcpResult(result == null ? "{}" : compact(result.toString(), 8000));
    }

    private JsonNode executeOneCall(McpClient mcp, McpToolCatalog catalog, JsonNode call, StepResult sr) throws Exception {
        String toolName = firstText(call, "tool", "name", "mcpTool", "toolName");
        if (toolName == null || toolName.isBlank()) throw new IllegalArgumentException("LLM did not return MCP tool name: " + call);
        McpTool tool = catalog.findByName(toolName).orElseThrow(() -> new IllegalArgumentException("MCP tool not found: " + toolName));
        JsonNode argNode = call.path("arguments");
        Map<String, Object> args = argNode.isMissingNode() || argNode.isNull()
                ? Map.of()
                : mapper.convertValue(argNode, new TypeReference<Map<String, Object>>() {});
        sr.setToolName(tool.getName());
        sr.setToolArguments(mapper.writeValueAsString(args));
        return mcp.callTool(tool.getName(), args);
    }

    private JsonNode parseDirectJson(String step, McpToolCatalog catalog) throws Exception {
        String trimmed = step == null ? "" : step.trim();
        if (!trimmed.startsWith("{")) return null;
        JsonNode node = mapper.readTree(trimmed);
        if (node.has("tool") || node.has("calls") || node.has("mcpTool")) return node;
        // Legacy explicit action JSON can still be converted to an MCP instruction through LLM; do not execute here.
        return null;
    }

    private JsonNode safeMap(McpClient mcp, McpToolCatalog catalog) {
        try {
            Optional<McpTool> mapTool = catalog.mapTool();
            if (mapTool.isEmpty()) return mapper.createObjectNode().put("note", "No map/snapshot MCP tool was found");
            return mcp.callTool(mapTool.get().getName(), Map.of());
        } catch (Exception e) {
            return mapper.createObjectNode().put("mapError", e.getMessage());
        }
    }

    private String captureScreenshot(McpClient mcp, McpToolCatalog catalog, Path screenshotDir, String scenarioId, int stepNo) throws Exception {
        Optional<McpTool> screenshotTool = catalog.screenshotTool();
        if (screenshotTool.isEmpty()) return "";
        JsonNode result = mcp.callTool(screenshotTool.get().getName(), Map.of());
        Optional<byte[]> png = findImageBytes(result);
        if (png.isEmpty()) return "";
        String safeScenario = scenarioId.replaceAll("[^a-zA-Z0-9._-]", "_");
        String fileName = safeScenario + "_step_" + stepNo + ".png";
        Files.createDirectories(screenshotDir);
        Files.write(screenshotDir.resolve(fileName), png.get());
        return fileName;
    }

    private String captureScreenshotQuietly(McpClient mcp, McpToolCatalog catalog, Path screenshotDir, String scenarioId, int stepNo) {
        try { return captureScreenshot(mcp, catalog, screenshotDir, scenarioId, stepNo); }
        catch (Exception ignored) { return ""; }
    }

    private Optional<byte[]> findImageBytes(JsonNode node) {
        if (node == null || node.isMissingNode() || node.isNull()) return Optional.empty();
        if (node.isObject()) {
            String type = node.path("type").asText("");
            String mime = node.path("mimeType").asText("");
            String data = node.path("data").asText("");
            if (("image".equalsIgnoreCase(type) || mime.toLowerCase(Locale.ROOT).contains("png")) && notBlank(data)) {
                try { return Optional.of(Base64.getDecoder().decode(data)); } catch (Exception ignored) {}
            }
            Iterator<Map.Entry<String, JsonNode>> fields = node.fields();
            while (fields.hasNext()) {
                Optional<byte[]> found = findImageBytes(fields.next().getValue());
                if (found.isPresent()) return found;
            }
        } else if (node.isArray()) {
            for (JsonNode child : node) {
                Optional<byte[]> found = findImageBytes(child);
                if (found.isPresent()) return found;
            }
        } else if (node.isTextual()) {
            String text = node.asText();
            if (text.startsWith("data:image/png;base64,")) text = text.substring("data:image/png;base64,".length());
            if (text.length() > 1000 && text.matches("^[A-Za-z0-9+/=\\r\\n]+$")) {
                try { return Optional.of(Base64.getDecoder().decode(text.replaceAll("\\s+", ""))); } catch (Exception ignored) {}
            }
        }
        return Optional.empty();
    }

    private void assertResult(JsonNode assertNode, String mcpResult, JsonNode map) {
        String type = assertNode.path("type").asText("");
        String value = assertNode.path("value").asText("");
        String haystack = ((mcpResult == null ? "" : mcpResult) + "\n" + (map == null ? "" : map.toString())).toLowerCase(Locale.ROOT);
        if ("TEXT_CONTAINS".equalsIgnoreCase(type) && !haystack.contains(value.toLowerCase(Locale.ROOT))) {
            throw new IllegalStateException("Assertion failed. Text not found: " + value);
        }
        if ("TEXT_NOT_CONTAINS".equalsIgnoreCase(type) && haystack.contains(value.toLowerCase(Locale.ROOT))) {
            throw new IllegalStateException("Assertion failed. Unexpected text found: " + value);
        }
    }

    private String applyData(String input, Map<String, Object> data) {
        if (input == null || data == null) return input;
        String output = input;
        for (Map.Entry<String, Object> e : data.entrySet()) {
            String value = e.getValue() == null ? "" : String.valueOf(e.getValue());
            output = output.replace("{{" + e.getKey() + "}}", value);
            output = output.replace("${" + e.getKey() + "}", value);
        }
        return output;
    }

    private List<String> splitArgs(String args) {
        if (args == null || args.isBlank()) return List.of();
        List<String> out = new ArrayList<>();
        Matcher m = Pattern.compile("([^\\s\"]+)|\"([^\"]*)\"").matcher(args);
        while (m.find()) out.add(m.group(1) != null ? m.group(1) : m.group(2));
        return out;
    }

    private String resolveUrl(String url, String base) {
        if (!notBlank(url)) return "";
        String trimmed = url.trim();
        if (trimmed.startsWith("http://") || trimmed.startsWith("https://")) return trimmed;
        if (!notBlank(base)) return trimmed;
        if (base.endsWith("/") && trimmed.startsWith("/")) return base.substring(0, base.length() - 1) + trimmed;
        if (!base.endsWith("/") && !trimmed.startsWith("/")) return base + "/" + trimmed;
        return base + trimmed;
    }

    private boolean shouldScreenshot(RunConfig config, boolean pass) {
        String mode = config.getScreenshotMode() == null ? "FAILURE_ONLY" : config.getScreenshotMode();
        if ("NONE".equalsIgnoreCase(mode)) return false;
        if ("ALL".equalsIgnoreCase(mode)) return true;
        return !pass;
    }

    private String firstText(JsonNode node, String... fields) {
        for (String f : fields) {
            JsonNode v = node.path(f);
            if (v.isTextual() && !v.asText().isBlank()) return v.asText();
        }
        return null;
    }

    private boolean notBlank(String value) { return value != null && !value.trim().isEmpty(); }

    private String compact(String text, int max) {
        if (text == null) return "";
        String s = text.replaceAll("\\s+", " ").trim();
        return s.length() <= max ? s : s.substring(0, max) + "...";
    }

    private void writeToolsManifest(Path runDir, List<McpTool> tools) {
        try {
            Files.createDirectories(runDir);
            Files.writeString(runDir.resolve("mcp-tools.json"), mapper.writerWithDefaultPrettyPrinter().writeValueAsString(tools), StandardCharsets.UTF_8);
        } catch (Exception ignored) {}
    }
}
