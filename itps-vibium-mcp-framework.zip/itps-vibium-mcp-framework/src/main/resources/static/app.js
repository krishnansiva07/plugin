const $ = (id) => document.getElementById(id);
let pollHandle = null;

$('scenarioFile').addEventListener('change', () => {
  const file = $('scenarioFile').files[0];
  $('fileName').textContent = file ? `${file.name} (${Math.round(file.size/1024)} KB)` : 'No file selected';
});

$('runBtn').addEventListener('click', async () => {
  const file = $('scenarioFile').files[0];
  if (!file) { setStatus('Please choose an Excel or JSON file.'); return; }
  const form = new FormData();
  form.append('scenarioFile', file);
  for (const id of ['llmBaseUrl','llmApiKey','llmModel','appBaseUrl','screenshotMode','stepTimeoutSeconds','retryCount']) {
    form.append(id, $(id).value || '');
  }
  for (const id of ['useLlm','headless','continueOnFailure']) form.append(id, $(id).checked);
  $('runBtn').disabled = true;
  setStatus('Starting Vibium MCP execution...');
  try {
    const res = await fetch('/api/runs', { method: 'POST', body: form });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Unable to start run');
    renderRun(data);
    poll(data.runId);
  } catch (e) {
    setStatus(e.message);
    $('runBtn').disabled = false;
  }
});

function poll(runId){
  clearInterval(pollHandle);
  pollHandle = setInterval(async () => {
    const res = await fetch(`/api/runs/${runId}`);
    const data = await res.json();
    renderRun(data);
    if (!['QUEUED','RUNNING'].includes(data.status)) {
      clearInterval(pollHandle);
      $('runBtn').disabled = false;
      setStatus('Run completed. Review the report and evidence below.');
    }
  }, 1800);
}

function renderRun(run){
  $('resultPanel').classList.remove('hidden');
  $('runTitle').textContent = `${run.runId} - ${run.status}`;
  $('runMessage').textContent = run.message || '';
  $('total').textContent = run.total ?? 0;
  $('passed').textContent = run.passed ?? 0;
  $('failed').textContent = run.failed ?? 0;
  $('status').textContent = run.status || '-';
  const base = `/api/runs/${run.runId}`;
  $('htmlReport').href = `${base}/report.html`;
  $('jsonReport').href = `${base}/report.json`;
  $('excelReport').href = `${base}/report.xlsx`;
  $('screenshotsZip').href = `${base}/screenshots.zip`;
  $('mcpTools').href = `${base}/mcp-tools.json`;
  $('scenarioResults').innerHTML = (run.scenarios || []).map(renderScenario).join('');
}

function renderScenario(s){
  const pass = s.status === 'PASSED';
  return `<section class="scenario">
    <div class="scenario-head"><div><div class="scenario-title">${esc(s.id)} - ${esc(s.name)}</div><div class="url">${esc(s.url || '')}</div></div><span class="pill ${pass?'pass':'fail'}">${esc(s.status || '')}</span></div>
    <table><thead><tr><th>#</th><th>Instruction</th><th>MCP Tool</th><th>Arguments</th><th>Status</th><th>ms</th><th>Error</th></tr></thead><tbody>
    ${(s.steps || []).map(st => `<tr><td>${st.stepNo}</td><td>${esc(st.instruction)}</td><td><b>${esc(st.toolName || '')}</b><div class="code">${esc(st.actionJson || '')}</div></td><td><div class="code">${esc(st.toolArguments || '')}</div></td><td><span class="pill ${st.status==='PASSED'?'pass':'fail'}">${esc(st.status || '')}</span></td><td>${st.durationMs || 0}</td><td class="err">${esc(st.errorMessage || '')}</td></tr>`).join('')}
    </tbody></table></section>`;
}
function esc(v){return String(v ?? '').replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));}
function setStatus(t){$('statusLine').textContent = t;}
