# Eliya 35 — Single optimized Agent context engine

## Release change

`AgentService.activeContextBundle(...)` now always selects `ContextBudgetPolicy` and `WorkspaceEvidenceAssembler`. The obsolete `-Deliya.context.v35.enabled=false` runtime switch and the v34 `collectActiveStepFileEvidence(...)` implementation have been **removed**, not merely disabled. No entry is required in `application.properties` to turn on the improved Agent engine.

The context **profile** selection remains independent of the removed switch: `eliya.context.v35.profile=auto` defaults to Balanced for ordinary tasks, and Deep for large tasks. The profile is optional tuning of the **same** modern engine; it does not reactivate Eliya 34.

## Changed components

- `src/main/java/com/llmart/llm/service/AgentService.java`: remove toggle and legacy branch, always use adaptive evidence retrieval; keep cache stamp validation, model-aware allocation, source provenance, usage statistics.
- `qa/context-v35-smoke/single-engine.sh`: regression contract rejects legacy context paths and requires adaptive budgeting, exact evidence assembly, caching and metrics.
- `.github/workflows/verify-eliya.yml`: execute the new regression contract in CI before the full Maven build.
- Implementation plan and status documents updated to reflect the final single-engine decision.

## Validation performed in the build container

PASS: one-engine source contract; Java 17 `--release 17` targeted compile and symbol/budget tests; state persistence/restart; deletion approval/timeout/rollback; vision; MCP explicit-token gating; Jira JQL; Agent image routing; completion reports; Confluence; code intelligence; Spring constructor and UI contracts; JavaScript syntax; **18/18 JavaScript tests**.

**Limit:** no full Maven / JUnit / Spring Boot executable packaging was possible in this container. Maven is not installed and Maven Central DNS resolution fails (`Could not resolve host: repo.maven.apache.org`). The included ZIP is a **source release candidate**, not a verified executable JAR. Offline tests cannot prove full application integration.

## Required final release gate on a Java 17 build host with Maven access

```bash
bash qa/context-v35-smoke/single-engine.sh
bash qa/context-v35-smoke/run.sh
bash qa/context-v35-smoke/run-state.sh
bash qa/offline-smoke/run.sh
bash qa/offline-smoke/vision.sh
bash qa/offline-smoke/chat-mcp-routing.sh
node --test src/test/js/*.test.js
mvn -B -Pfull-tests -Dmaven.test.skip=false clean verify
java -jar target/eliya.jar
```

Run targeted end-to-end acceptance covering: Agent coding/completion, Chat including attachments, enabled/disabled and explicitly named MCP cases, prompt-first documentation and explicit UI templates, plan approval, deletion decline and timeout, protected rollback, reference workspaces, and compaction after restart. Do not certify a production build until these pass.

## Safety and compatibility

The update has **not altered** Chat, MCP routing, documentation template behavior, permission gates, protected rollback, deletion approvals, frontend, or repository persistence. It only removes the v34 **Agent context-building** branch and retains the existing Eliya 35 improvements. Keep the earlier ZIP externally as a source backup if needed; it is no longer selectable at runtime.
