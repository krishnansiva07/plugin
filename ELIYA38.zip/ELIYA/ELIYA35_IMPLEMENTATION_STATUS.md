# ELIYA 35 — Adaptive Context Delivery (source release candidate)

## Delivered from ELIYA34(3)

- **Adaptive context budgets:** `ContextBudgetPolicy` selects Balanced by default (4 files, up to 24,000 live-source characters, up to 12,000 retrieval characters), with Fast/Deep overrides and bounded Deep on large tasks. Actual evidence shrinks according to active/failover model capacity, earlier prompt/tool size and the original compaction/output reserves. Unknown model limits are treated conservatively.
- **Symbol-based source reads:** `WorkspaceSymbolIndexService` uses the Java 17 JDK compiler syntax tree for precise method/type line ranges; TS/JS uses conservative delimiter scanning with ambiguity fallbacks. `WorkspaceEvidenceAssembler` selects matching methods *anywhere* in a file, with focused line ranges if no symbol matches; no more mandatory lines 1–180 in v35 Agent evidence.
- **Honest partial-source handling:** Oversized bodies are explicitly marked `PARTIAL_SOURCE`. Source evidence contains file path, exact loaded lines and SHA-256 hash. Unauthorized paths, secrets, binary and oversized files are excluded. No workspace modifications are made by retrieval.
- **Reuse/revalidation:** Existing active-step bundle caching is retained, segmented by profile/model/budget. Selected live file size and modification timestamps are checked before reusing a cached bundle. Agent mutations already invalidate the cache.
- **Persistent task-state preservation:** Agent run state stores the first original user task in full (`originalTaskContract`), independently of later working objectives, plus source-evidence references. Rehydrate durable instructions immediately after proactive compaction. Existing approved plans, safety state, rollback and verification remain authoritative.
- **Non-sensitive diagnostics:** Run snapshots include context profile, cumulative evidence assembly milliseconds, evidence bytes/characters, file and symbol counts, cache-hit counts and Agent provider response milliseconds (for timed Agent calls). Original prompts/source are NOT written to telemetry.
- **Single-engine release:** The obsolete v34 context builder and `eliya.context.v35.enabled` runtime toggle were removed. Adaptive symbol-grounded context is the only Agent context path. MCP routing, UI documentation template selection, Chat behavior, tool permission gates, protected rollback and deletion approvals are unchanged.

## Optional context tuning (the optimized engine is always active)

| JVM property | Default | Meaning |
|---|---|---|
| `eliya.context.v35.profile` | `auto` | `auto` (Balanced unless large task), `balanced`, `fast`, `deep` |

## Tests run in this build environment

- `qa/context-v35-smoke/single-engine.sh` — required single-engine source regression guard (run in this release).
- `qa/context-v35-smoke/run.sh` — PASS; compiled v35 context classes with `javac --release 17` and exercised method at line 650+, budgets/failover, TS ranges, partial evidence, traversal/secret protection.
- `qa/context-v35-smoke/run-state.sh` — PASS; compiled actual `AgentRunService` with minimal stubs and checked immutable task persistence, restart and telemetry persistence.
- `qa/offline-smoke/run.sh` — PASS; deletion approval, TTL, rollback, command guards.
- `qa/offline-smoke/vision.sh` — PASS; vision document handling.
- `qa/offline-smoke/chat-mcp-routing.sh` — PASS; explicit-MCP gating.
- `qa/offline-smoke/jira-jql.sh` — PASS.
- `qa/offline-smoke/agent-image-routing.sh` — PASS.
- `qa/offline-smoke/spring-constructor-contract.py` — PASS.
- `qa/offline-smoke/ui-contract.py` — PASS; 11 source-contract checks.
- `node --check` for app.js, prompt-catalog.js and markdown.js — PASS.
- `node --test src/test/js/*.test.js` — PASS; 18/18 tests.

## IMPORTANT: validation not yet possible here

This runtime has **no Maven installation or cached Spring/Maven dependencies**, and the Maven wrapper bootstrap cannot resolve `repo.maven.apache.org`. Consequently, **the full Maven/JUnit compile and integration suite, executable Java 17 JAR assembly and real-model performance benchmarks were NOT run**. This ZIP is source code with passing targeted/offline checks, **NOT a fully validated runnable JAR or production-certified release**. The CI workflow is updated to run v35 smokes and Maven full-tests on GitHub Actions.

To complete the release gate on a Java 17 machine with Maven/dependency access:

```bash
bash qa/context-v35-smoke/run.sh
bash qa/context-v35-smoke/run-state.sh
bash qa/offline-smoke/run.sh
bash qa/offline-smoke/vision.sh
bash qa/offline-smoke/chat-mcp-routing.sh
node --test src/test/js/*.test.js
mvn -B -Pfull-tests -Dmaven.test.skip=false clean verify
java -jar target/eliya.jar
```

**No numerical task-speed improvement is claimed** without paired external provider benchmarks. Compare equivalent tasks against the archived Eliya34 baseline under the same model/provider/workspace conditions.

## Remaining architectural improvements after initial rollout

- Persist a full scalable symbol/index graph (current source-range extraction occurs on selected live candidate files; the existing file-level search index is unchanged).
- Add richer TypeScript language-server/AST support and cross-file caller/callee ranking.
- Extend read-only symbol evidence delivery to Chat behind its own bounded, explicitly tested feature flag (Chat was deliberately left unchanged here).
- Add p50/p95 metrics dashboards, provider streaming time-to-first-token timing and real task A/B benchmarks.
- Execute all Maven and end-to-end UI/provider/workspace regression gates on a fully provisioned Java 17 build host.
