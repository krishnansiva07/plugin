package com.llmart.llm.service;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Evidence-only Jira -> workspace bridge. Uses the already-warmed lexical index; never walks,
 * edits, invokes an LLM, or calls MCP. The original MCP opt-in is enforced by ChatMcpService.
 */
final class ChatWorkspaceEvidence {
    private static final Pattern ISSUE = Pattern.compile("(?i)\\b[A-Z][A-Z0-9]{1,15}-\\d+\\b");
    private static final Pattern DETAIL = Pattern.compile("(?i)\\b(?:acceptance criteria|acceptancecriterion|description|summary|scenario|given|when|then|shall|must|expected|requirement)\\b");
    private static final Pattern INTENT = Pattern.compile("(?i)\\b(?:compare|implemented|implementation|missing|gap|trace|codebase|workspace|source code|validate|verify|coverage|check)\\b");
    private static final int MAX_EVIDENCE_CHARS = 12_000;

    static boolean shouldGround(String originalPrompt, String result) {
        if (originalPrompt == null || result == null || result.length() < 120) return false;
        if (!ISSUE.matcher(originalPrompt).find() || !INTENT.matcher(originalPrompt).find()) return false;
        // A tool-discovery response is not a Jira issue body. Require either matching issue key
        // or explicit requirement material before grounding anything.
        Matcher issue = ISSUE.matcher(originalPrompt);
        String key = issue.find() ? issue.group().toLowerCase(Locale.ROOT) : "";
        return result.toLowerCase(Locale.ROOT).contains(key) && DETAIL.matcher(result).find();
    }

    static String augment(WorkspaceRetrievalIndexService index, String projectId, Path root,
                          String originalPrompt, String jiraResult) {
        if (index == null || projectId == null || projectId.isBlank() || root == null
                || !shouldGround(originalPrompt, jiraResult) || index.cachedStats(projectId, root) == null) return "";
        List<String> probes = probes(originalPrompt, jiraResult);
        StringBuilder result = new StringBuilder("\n\nLOCAL WORKSPACE EVIDENCE (cached index; candidate references, NOT proof of completeness):\n");
        int included = 0;
        for (String probe : probes) {
            if (included >= 3 || result.length() >= MAX_EVIDENCE_CHARS - 1000) break;
            String hits = index.retrieveCachedRoot(projectId, root, probe, 6,
                    Math.min(4_200, MAX_EVIDENCE_CHARS - result.length() - 400));
            if (hits.isBlank()) continue;
            result.append("\nQuery: ").append(probe, 0, Math.min(probe.length(), 240)).append("\n")
                    .append(hits).append("\n");
            included++;
        }
        if (included == 0) return "";
        result.append("\nIMPORTANT: These are bounded candidate excerpts, not an exhaustive audit. "
                + "Classify Jira criteria with actual source evidence; label missing/unverified distinctly. "
                + "Do not claim every file or criterion was checked unless supported by evidence.");
        return result.toString();
    }

    static List<String> probes(String prompt, String jiraResult) {
        Set<String> queries = new LinkedHashSet<>();
        String clean = jiraResult.replace("\\n", "\n").replace("\\r", " ")
                .replace("\\\"", "\"").replaceAll("[{}\\[\\]]", " ");
        for (String line : clean.split("[\\n;]")) {
            String trimmed = line.strip();
            if (trimmed.length() < 16 || !DETAIL.matcher(trimmed).find()) continue;
            if (trimmed.length() > 900) trimmed = trimmed.substring(0, 900);
            queries.add(trimmed);
            if (queries.size() >= 3) break;
        }
        if (queries.isEmpty()) queries.add(clean.substring(0, Math.min(clean.length(), 1600)));
        // Keep user-intent keywords, but do not let 'Jira MCP' dominate every code search.
        String user = prompt.replaceAll("(?i)\\b(?:jira|mcp)\\b", " ").strip();
        if (!user.isBlank() && queries.size() < 3) queries.add(user.substring(0, Math.min(user.length(), 400)));
        return new ArrayList<>(queries);
    }

    private ChatWorkspaceEvidence() {}
}
