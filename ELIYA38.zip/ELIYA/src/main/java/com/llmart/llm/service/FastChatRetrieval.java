package com.llmart.llm.service;

import com.llmart.llm.dto.ChatSettings;
import java.nio.file.Path;
import java.util.concurrent.*;
import java.util.function.BooleanSupplier;

/**
 * Chat retrieval is lexical-first and never waits indefinitely for a remote embedding provider.
 * The existing index is the authority: this class neither walks folders nor modifies workspace files.
 * A small bounded pool prevents cancelled/slow provider calls from exhausting request threads.
 */
final class FastChatRetrieval implements AutoCloseable {
    private static final long SEMANTIC_BUDGET_MS = 650;
    private final WorkspaceRetrievalIndexService retrieval;
    private final ThreadPoolExecutor semanticPool = new ThreadPoolExecutor(1, 2, 15,
            TimeUnit.SECONDS, new ArrayBlockingQueue<>(4), r -> {
        Thread thread = new Thread(r, "eliya-chat-semantic");
        thread.setDaemon(true);
        return thread;
    }, new ThreadPoolExecutor.AbortPolicy());

    FastChatRetrieval(WorkspaceRetrievalIndexService retrieval) { this.retrieval = retrieval; }

    String retrieve(String id, Path root, String query, int limit, int maxChars,
                    String apiKey, ChatSettings settings, BooleanSupplier cancelled) {
        return retrieve(id, root, query, limit, maxChars, apiKey, settings, cancelled, SEMANTIC_BUDGET_MS);
    }

    String retrieve(String id, Path root, String query, int limit, int maxChars,
                    String apiKey, ChatSettings settings, BooleanSupplier cancelled, long semanticBudgetMillis) {
        checkCancelled(cancelled);
        String lexical = retrieval.retrieveCachedRoot(id, root, query, limit, maxChars);
        if (settings == null || !settings.semanticRetrievalEnabled() || settings.embeddingModelName().isBlank()
                || apiKey == null || apiKey.isBlank() || lexical.isBlank()) return lexical;
        final long deadline = System.nanoTime() + TimeUnit.MILLISECONDS.toNanos(
                Math.max(0, Math.min(SEMANTIC_BUDGET_MS, semanticBudgetMillis)));
        if (semanticBudgetMillis <= 0) return lexical;
        Future<String> pending;
        try {
            pending = semanticPool.submit(() -> retrieval.retrieveHybrid(
                    AgentWorkspaceService.Workspace.forIndex(id, root), query, limit, maxChars,
                    apiKey, settings, () -> (cancelled != null && cancelled.getAsBoolean())
                            || Thread.currentThread().isInterrupted() || System.nanoTime() >= deadline));
        } catch (RejectedExecutionException busy) { return lexical; }
        try {
            while (true) {
                checkCancelled(cancelled);
                long left = deadline - System.nanoTime();
                if (left <= 0) return lexical;
                try {
                    String semantic = pending.get(Math.min(left, TimeUnit.MILLISECONDS.toNanos(75)), TimeUnit.NANOSECONDS);
                    return semantic == null || semantic.isBlank() ? lexical : semantic;
                } catch (TimeoutException stillRunning) {
                    // Keep the request cancellable even while waiting for a provider.
                }
            }
        } catch (InterruptedException interrupted) {
            Thread.currentThread().interrupt();
            throw new AgentCancelledException("Chat context preparation interrupted");
        } catch (ExecutionException failed) {
            return lexical;
        } finally {
            if (!pending.isDone()) pending.cancel(true);
        }
    }

    static void checkCancelled(BooleanSupplier cancelled) {
        if (cancelled != null && cancelled.getAsBoolean())
            throw new AgentCancelledException("Chat request cancelled during context preparation");
    }

    @Override public void close() { semanticPool.shutdownNow(); }
}
