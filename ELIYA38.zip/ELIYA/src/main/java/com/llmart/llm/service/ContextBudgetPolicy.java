package com.llmart.llm.service;

import com.llmart.llm.dto.ChatSettings;

/**
 * ELIYA 35. Bounded, model-aware context allocations. Limits describe OPTIONAL evidence, never required
 * instructions, approved plan content, or tool schemas. A small model gets a smaller bundle.
 */
public final class ContextBudgetPolicy {
    public enum Profile { FAST, BALANCED, DEEP }
    public record Budget(Profile profile, int files, int retrievalChars, int evidenceChars,
                         int estimatedAvailableTokens, boolean capacityEstimated) { }

    private ContextBudgetPolicy() { }

    public static Budget select(ChatSettings settings, String model, boolean largeTask,
                                int existingRequestTokens) {
        String configured = System.getProperty("eliya.context.v35.profile", "auto").trim().toLowerCase(java.util.Locale.ROOT);
        Profile profile = switch (configured) {
            case "fast" -> Profile.FAST;
            case "deep" -> Profile.DEEP;
            case "balanced" -> Profile.BALANCED;
            default -> largeTask ? Profile.DEEP : Profile.BALANCED;
        };
        int capacity = settings == null ? 16_000 : settings.safeContextWindowTokens(model);
        // Unknown models are configured by name hints; do not assume their full advertised limit is usable.
        boolean estimated = settings == null || (!hasConfiguredWindow(settings, model));
        if (estimated) capacity = Math.min(capacity, 32_000);
        int requestedOutput = settings == null ? 0 : settings.safeMaxTokens();
        // Match ContextWindowManager's physical request envelope. Optional evidence must never consume
        // the larger of its output allowance and its configured compaction buffer.
        int outputReserve = requestedOutput > 0 ? requestedOutput : 16_000;
        int compactionReserve = settings == null ? 20_000 : settings.safeCompactionBufferTokens(model);
        int safetyReserve = Math.max(1_024, Math.min(4_096, capacity / 12));
        int available = Math.max(0, capacity - Math.max(0, existingRequestTokens) -
                Math.max(outputReserve, compactionReserve) - safetyReserve);
        int evidenceCap = switch (profile) {
            case FAST -> 12_000; case BALANCED -> 24_000; case DEEP -> 40_000;
        };
        int hintsCap = switch (profile) {
            case FAST -> 7_000; case BALANCED -> 12_000; case DEEP -> 16_000;
        };
        // Conservative 3 chars/token (including provenance overhead). Retrieval and evidence share the spare window.
        int optionalChars = Math.max(0, available * 3 / 2);
        int hints = Math.min(hintsCap, optionalChars / 3);
        int evidence = Math.min(evidenceCap, Math.max(0, optionalChars - hints));
        int files = switch (profile) { case FAST -> 3; case BALANCED -> 4; case DEEP -> 8; };
        if (evidence < 1_000) files = 0;
        return new Budget(profile, files, hints, evidence, available, estimated);
    }

    private static boolean hasConfiguredWindow(ChatSettings settings, String model) {
        if (settings.contextWindowTokens() != null && settings.contextWindowTokens() > 0) return true;
        String entries = settings.modelContextWindows();
        if (entries == null || model == null || model.isBlank()) return false;
        for (String line : entries.split("[\\r\\n,]+")) {
            int equals = line.lastIndexOf('=');
            if (equals > 0 && model.equalsIgnoreCase(line.substring(0, equals).trim())) {
                try { return Integer.parseInt(line.substring(equals + 1).trim()) > 0; }
                catch (NumberFormatException ignored) { return false; }
            }
        }
        return false;
    }
}
