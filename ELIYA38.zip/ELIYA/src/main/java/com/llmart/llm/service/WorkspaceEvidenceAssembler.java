package com.llmart.llm.service;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.*;
import java.util.regex.*;

/** ELIYA 35: bounded LIVE, source-grounded method evidence; only caller-authorized local workspace paths. */
final class WorkspaceEvidenceAssembler {
    record Result(String text, int files, int symbols, int chars, long elapsedMillis, List<String> references) { }
    private static final Pattern HIT = Pattern.compile("(?m)^- (.+?) \\(score=[^\\r\\n]+\\)");
    private static final Pattern TERMS = Pattern.compile("[A-Za-z_$][A-Za-z0-9_$]{2,}");
    private static final Set<String> STOP = Set.of("this","that","with","from","when","where","what","user",
            "need","file","files","code","class","method","please","fix","implement","the","and","for",
            "agent","using","should","would","into","then","java","task","step","project","workspace");
    private final AgentWorkspaceService workspaces;
    WorkspaceEvidenceAssembler(AgentWorkspaceService workspaces) { this.workspaces = workspaces; }

    Result assemble(AgentWorkspaceService.Workspace ws, String retrievalHints, String query,
                    ContextBudgetPolicy.Budget budget) {
        long started = System.nanoTime();
        if (ws == null || retrievalHints == null || budget == null || budget.files() <= 0 || budget.evidenceChars() < 600)
            return new Result("", 0, 0, 0, millis(started), List.of());
        StringBuilder out = new StringBuilder("ACTIVE STEP LIVE SOURCE EVIDENCE — source paths/line ranges are authoritative; PARTIAL means more reading is required.\n");
        int files = 0, symbols = 0;
        List<String> references = new ArrayList<>();
        Set<String> queryTerms = terms(query);
        Matcher hits = HIT.matcher(retrievalHints);
        Set<String> seen = new LinkedHashSet<>();
        while (hits.find() && files < budget.files() && out.length() < budget.evidenceChars() - 500) {
            String path = hits.group(1).trim();
            if (!seen.add(path) || !allowedPath(ws, path)) continue;
            try {
                Path file = ws.root().resolve(path).normalize();
                if (Files.size(file) > 600_000 || Files.size(file) == 0) continue;
                String source = Files.readString(file, StandardCharsets.UTF_8);
                if (source.indexOf('\0') >= 0) continue;
                String[] lines = source.split("\\R", -1);
                List<WorkspaceSymbolIndexService.Symbol> candidates = WorkspaceSymbolIndexService.extract(path, source);
                WorkspaceSymbolIndexService.Symbol matched = chooseSymbol(candidates, queryTerms);
                int start, end;
                String reason;
                if (matched != null) {
                    start = Math.max(1, matched.startLine() - 3);
                    end = matched.endLine();
                    reason = "symbol=" + matched.kind() + ":" + matched.name();
                    symbols++;
                } else {
                    int position = bestLine(lines, queryTerms);
                    start = Math.max(1, position - 24);
                    end = Math.min(lines.length, position + 55);
                    reason = "focused-line-range (no confident complete symbol)";
                }
                int room = budget.evidenceChars() - out.length() - 160;
                if (room < 350) break;
                int perFileCap = Math.min(budget.profile() == ContextBudgetPolicy.Profile.DEEP ? 9_000 : 8_000, room);
                // Request bounded ranges, not the first N lines. Preserve method signature and mark clipping.
                int fittingEnd = fittingEnd(lines, start, end, perFileCap);
                if (fittingEnd < start) continue;
                String body = workspaces.readFileRange(ws, path, start, fittingEnd);
                if (body == null || body.isBlank()) continue;
                String suffix = fittingEnd < end ? "\n[PARTIAL_SOURCE: " + path + ":L" + (fittingEnd + 1) + "-L" + end + " not loaded; use read_chunk to inspect before editing]" : "";
                String fileHash = sha256(source);
                String provenance = path + ":L" + start + "-L" + fittingEnd + " sha256=" + fileHash;
                String block = "\n### " + provenance + " [" + reason + "]\n" + body + suffix + "\n";
                if (out.length() + block.length() > budget.evidenceChars()) continue;
                out.append(block);
                references.add(provenance);
                files++;
            } catch (IOException | IllegalArgumentException ignored) {
                // Retrieval hints are untrusted hints, not access permissions. Existing safe read tools remain available.
            }
        }
        return files == 0 ? new Result("", 0, 0, 0, millis(started), List.of()) :
                new Result(out.toString(), files, symbols, out.length(), millis(started), List.copyOf(references));
    }

    private static boolean allowedPath(AgentWorkspaceService.Workspace ws, String path) {
        try {
            if (path.isBlank() || path.indexOf('\0') >= 0 || path.startsWith("/") || path.contains("\\") ||
                    path.contains(":") || path.startsWith(".") && !path.startsWith("./")) return false;
            String low = "/" + path.toLowerCase(Locale.ROOT);
            if (low.contains("/secrets/") || low.endsWith("/.env") || low.endsWith(".pem") ||
                    low.endsWith(".key") || low.endsWith(".jks") || low.endsWith(".p12") || low.endsWith(".pfx")) return false;
            Path root = ws.root().toRealPath();
            Path file = root.resolve(path).normalize();
            return file.startsWith(root) && Files.isRegularFile(file, LinkOption.NOFOLLOW_LINKS) &&
                    file.toRealPath().startsWith(root) && !Files.isSymbolicLink(file);
        } catch (Exception ignored) { return false; }
    }

    private static WorkspaceSymbolIndexService.Symbol chooseSymbol(List<WorkspaceSymbolIndexService.Symbol> symbols, Set<String> terms) {
        WorkspaceSymbolIndexService.Symbol winner = null; double best = 0;
        for (var symbol : symbols) {
            String name = symbol.name().toLowerCase(Locale.ROOT);
            double score = terms.contains(name) ? 20 : 0;
            // Camel-case matching for references such as alertSeverity vs "alert severity".
            int hits = 0;
            for (String word : terms) if (word.length() > 3 && name.contains(word)) hits++;
            score += hits * 4.0;
            if ("method".equals(symbol.kind())) score += 1.0;
            if (symbol.endLine() - symbol.startLine() > 450) score -= 5.0;
            if (score > best) { best = score; winner = symbol; }
        }
        return best >= 4 ? winner : null;
    }

    private static int bestLine(String[] lines, Set<String> terms) {
        int best = 1, value = 0;
        for (int i = 0; i < lines.length; i++) {
            String low = lines[i].toLowerCase(Locale.ROOT);
            int count = 0;
            for (String word : terms) if (low.contains(word)) count++;
            if (count > value) { best = i + 1; value = count; }
        }
        return best;
    }

    private static int fittingEnd(String[] lines, int start, int end, int cap) {
        int length = 100, finalLine = start - 1;
        for (int i = start; i <= end && i <= lines.length; i++) {
            length += Math.min(700, lines[i - 1].length()) + Integer.toString(i).length() + 5;
            if (length > cap) break;
            finalLine = i;
        }
        return finalLine;
    }

    private static Set<String> terms(String query) {
        LinkedHashSet<String> result = new LinkedHashSet<>();
        if (query == null) return result;
        Matcher m = TERMS.matcher(query);
        while (m.find() && result.size() < 70) {
            String lower = m.group().toLowerCase(Locale.ROOT);
            if (!STOP.contains(lower)) result.add(lower);
        }
        return result;
    }
    private static String sha256(String text) {
        try {
            return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(text.getBytes(StandardCharsets.UTF_8)));
        } catch (NoSuchAlgorithmException e) { throw new IllegalStateException("SHA-256 unavailable", e); }
    }
    private static long millis(long started) { return (System.nanoTime() - started) / 1_000_000; }
}
