package com.llmart.llm.service;

import com.sun.source.tree.*;
import com.sun.source.util.JavacTask;
import com.sun.source.util.TreePathScanner;
import com.sun.source.util.Trees;
import javax.tools.*;
import java.net.URI;
import java.util.*;
import java.util.regex.*;

/**
 * Read-only, bounded source ranges. Java positions come from JDK AST (never regex brace guessing).
 * JS/TS ranges are conservative: uncertain balanced delimiters are rejected, not claimed complete.
 */
final class WorkspaceSymbolIndexService {
    record Symbol(String name, String kind, int startLine, int endLine, boolean exact) { }
    private static final int MAX_SOURCE_CHARS = 600_000;
    private static final int MAX_SYMBOLS = 350;
    private static final Pattern JS_DECL = Pattern.compile(
            "(?m)^\\s*(?:(?:export|default|declare|async|public|private|protected|static|readonly|override)\\s+)*" +
            "(?:(class|function|interface|enum|type)\\s+([\\w$]+)|([\\w$]+)\\s*\\([^\\n)]{0,240}\\)\\s*(?::[^\\n{=]+)?\\s*\\{)");
    private WorkspaceSymbolIndexService() { }

    static List<Symbol> extract(String path, String source) {
        if (path == null || source == null || source.isBlank() || source.length() > MAX_SOURCE_CHARS) return List.of();
        String low = path.toLowerCase(Locale.ROOT);
        if (low.endsWith(".java")) {
            try { return javaSymbols(path, source); } catch (Exception ignored) { return List.of(); }
        }
        if (low.matches(".*\\.(ts|tsx|js|jsx|mjs|cjs)$")) return jsSymbols(source);
        return List.of();
    }

    private static List<Symbol> javaSymbols(String path, String source) throws Exception {
        JavaCompiler compiler = ToolProvider.getSystemJavaCompiler();
        if (compiler == null) return List.of();
        String safe = path.replaceAll("[^A-Za-z0-9_$]", "_");
        JavaFileObject unit = new SimpleJavaFileObject(URI.create("string:///" + safe + ".java"), JavaFileObject.Kind.SOURCE) {
            @Override public CharSequence getCharContent(boolean ignoreEncodingErrors) { return source; }
        };
        List<Symbol> found = new ArrayList<>();
        try (StandardJavaFileManager fileManager = compiler.getStandardFileManager(null, Locale.ROOT, null)) {
            JavacTask task = (JavacTask) compiler.getTask(null, fileManager, d -> { },
                    List.of("-proc:none"), null, List.of(unit));
            for (CompilationUnitTree cu : task.parse()) {
                Trees trees = Trees.instance(task);
                new TreePathScanner<Void, Void>() {
                    private void record(String name, String kind, Tree node) {
                        if (name == null || name.isBlank() || found.size() >= MAX_SYMBOLS) return;
                        long from = trees.getSourcePositions().getStartPosition(cu, node);
                        long to = trees.getSourcePositions().getEndPosition(cu, node);
                        if (from < 0 || to <= from || to > source.length() || cu.getLineMap() == null) return;
                        int start = (int) cu.getLineMap().getLineNumber(from);
                        int end = (int) cu.getLineMap().getLineNumber(to - 1);
                        if (start > 0 && end >= start) found.add(new Symbol(name, kind, start, end, true));
                    }
                    @Override public Void visitClass(ClassTree n, Void v) {
                        record(n.getSimpleName().toString(), "type", n); return super.visitClass(n, v);
                    }
                    @Override public Void visitMethod(MethodTree n, Void v) {
                        record(n.getName().toString(), "method", n); return super.visitMethod(n, v);
                    }
                }.scan(cu, null);
            }
        }
        return List.copyOf(found);
    }

    private static List<Symbol> jsSymbols(String source) {
        List<Symbol> out = new ArrayList<>();
        Matcher matcher = JS_DECL.matcher(source);
        while (matcher.find() && out.size() < MAX_SYMBOLS) {
            String name = matcher.group(2) == null ? matcher.group(3) : matcher.group(2);
            String kind = matcher.group(1) == null ? "method" : matcher.group(1);
            if (name == null || Set.of("if","for","while","catch","switch","return").contains(name)) continue;
            int open = source.indexOf('{', matcher.start());
            if (open < 0 || open - matcher.start() > 450) continue;
            int close = findBalancedClose(source, open);
            if (close < 0) continue;
            out.add(new Symbol(name, kind, line(source, matcher.start()), line(source, close), true));
        }
        return List.copyOf(out);
    }

    /** Reject uncertain template literals/unterminated strings rather than returning a misleading range. */
    private static int findBalancedClose(String text, int opening) {
        int depth = 0; char quote = 0; boolean escaped = false, lineComment = false, blockComment = false;
        for (int i = opening; i < text.length(); i++) {
            char c = text.charAt(i), next = i + 1 < text.length() ? text.charAt(i + 1) : '\0';
            if (lineComment) { if (c == '\n') lineComment = false; continue; }
            if (blockComment) { if (c == '*' && next == '/') { blockComment = false; i++; } continue; }
            if (quote != 0) {
                if (escaped) { escaped = false; continue; }
                if (c == '\\') { escaped = true; continue; }
                if (c == quote) quote = 0;
                continue;
            }
            if (c == '/' && next == '/') { lineComment = true; i++; continue; }
            if (c == '/' && next == '*') { blockComment = true; i++; continue; }
            if (c == '\'' || c == '"') { quote = c; continue; }
            if (c == '`') return -1; // interpolation requires a full parser
            if (c == '{') depth++;
            if (c == '}' && --depth == 0) return i;
        }
        return -1;
    }

    private static int line(String source, int offset) {
        int line = 1;
        for (int i = 0; i < offset; i++) if (source.charAt(i) == '\n') line++;
        return line;
    }
}
