package com.llmart.llm.service;

import com.llmart.llm.dto.ChatSettings;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import java.nio.file.*;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

/** Regression coverage for the ELIYA35 context feature, independently of a remote LLM. */
class AdaptiveContextV35Test {
    @TempDir Path temp;

    @Test void balancedDefaultAndModelFailoverShrinkOptionalEvidence() {
        ChatSettings settings = settings(128_000, null);
        var balanced = ContextBudgetPolicy.select(settings, "model-128k", false, 1_000);
        assertEquals(ContextBudgetPolicy.Profile.BALANCED, balanced.profile());
        assertEquals(4, balanced.files());
        assertEquals(24_000, balanced.evidenceChars());
        assertTrue(balanced.retrievalChars() <= 12_000);
        var small = ContextBudgetPolicy.select(settings(128_000, "small=16000"), "small", false, 11_500);
        assertEquals(0, small.files());
        assertEquals(0, small.evidenceChars());
    }

    @Test void ASTReadsEntireMethodFarAfterFirst180Lines() throws Exception {
        StringBuilder source = new StringBuilder("class Alerts {\n");
        for (int i = 0; i < 680; i++) source.append("// ignored header line ").append(i).append('\n');
        source.append("int calculateAlertSeverity(int incidents) {\nreturn incidents * 3;\n}\n}\n");
        Files.writeString(temp.resolve("Alerts.java"), source);
        var symbols = WorkspaceSymbolIndexService.extract("Alerts.java", source.toString());
        assertTrue(symbols.stream().anyMatch(s -> s.name().equals("calculateAlertSeverity") && s.startLine() > 650));
        var ws = AgentWorkspaceService.Workspace.forIndex("project", temp);
        var mockWorkspace = mock(AgentWorkspaceService.class);
        when(mockWorkspace.readFileRange(eq(ws), eq("Alerts.java"), anyInt(), anyInt())).thenAnswer(inv -> {
            int from = inv.getArgument(2), to = inv.getArgument(3);
            var lines = Files.readAllLines(temp.resolve("Alerts.java"));
            return String.join("\n", lines.subList(from - 1, Math.min(to, lines.size())));
        });
        var assembler = new WorkspaceEvidenceAssembler(mockWorkspace);
        var result = assembler.assemble(ws, "- Alerts.java (score=93.0)", "fix calculateAlertSeverity",
                ContextBudgetPolicy.select(settings(128_000, null), "known", false, 2_000));
        assertEquals(1, result.files());
        assertEquals(1, result.symbols());
        assertTrue(result.text().contains("return incidents * 3"));
        assertFalse(result.text().contains("ignored header line 100"));
    }

    @Test void partialMethodsNeverClaimToBeComplete() throws Exception {
        var source = "class LongService { void calculateAlertSeverity(){\n" + "System.out.println(123);\n".repeat(800) + "}\n}";
        Files.writeString(temp.resolve("LongService.java"), source);
        var ws = AgentWorkspaceService.Workspace.forIndex("project", temp);
        var mockWorkspace = mock(AgentWorkspaceService.class);
        when(mockWorkspace.readFileRange(eq(ws), eq("LongService.java"), anyInt(), anyInt())).thenAnswer(inv -> {
            var lines = Files.readAllLines(temp.resolve("LongService.java"));
            int start = inv.getArgument(2), end = inv.getArgument(3);
            return String.join("\n", lines.subList(start - 1, Math.min(end, lines.size())));
        });
        var result = new WorkspaceEvidenceAssembler(mockWorkspace).assemble(ws,
                "- LongService.java (score=99.0)", "calculateAlertSeverity",
                ContextBudgetPolicy.select(settings(128_000, null), "known", false, 1_000));
        assertTrue(result.text().contains("PARTIAL_SOURCE"));
    }

    @Test void taskContractAndMetricsSurviveRestart() {
        var original = "Must not use MCP without the original user request. Do not delete without approval.";
        var service = new AgentRunService(temp);
        var run = service.start("conversation", "project");
        run.setObjective(original);
        run.setObjective("Next active step");
        run.recordContextEvidence("BALANCED", 3, 2, 5_200, 51);
        run.recordProviderLatency(215);
        run.finish("completed");
        var restored = new AgentRunService(temp).require(run.id());
        assertEquals(original, restored.originalTaskContract());
        assertEquals("Next active step", restored.objective());
        assertTrue(restored.durableContextText().contains(original));
        var usage = (Map<?, ?>) restored.snapshot().get("tokenUsage");
        assertEquals(3L, usage.get("evidenceFiles"));
        assertEquals(215L, usage.get("providerLatencyMs"));
    }

    private static ChatSettings settings(int contextWindow, String windows) {
        return new ChatSettings(
                "http://localhost/v1", "model-128k", null, null, null, null, null, null, null, true, true, 0.1, 4_000, 0,
                contextWindow, windows, null, true, 8_000, 20_000, 1_200,
                null, true, 0, true,
                "allow", "allow", "allow", true, "",
                "allow", "allow", "allow", true, true, null, 10, true, null, null);
    }
}
