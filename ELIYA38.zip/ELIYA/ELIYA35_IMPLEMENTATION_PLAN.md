# ELIYA 35 — Adaptive LLM Context Delivery, Durable State & Performance Plan

**Status:** Implementation specification (not implemented)
**Baseline:** `ELIYA34(3).zip` (Java 17 / Spring Boot)
**Default:** Balanced; automatic, bounded escalation to Deep for genuinely complex work
**Nonnegotiable:** Preserve all existing Chat, Agent, MCP opt-in, documentation-template rules, plan approvals, deletion permissions, rollback, read-only references and offline deployment behavior.

## 1. Outcome and definition of success

The objective is to lower **end-to-end development-task completion time** and improve code-grounded correctness, not to maximize prompt size. Eliya should locate and send *complete relevant methods and their direct dependencies* as a bounded, verifiable evidence bundle, avoid repeated reads of unchanged code, and retain user requirements and execution facts outside the active LLM context. All optimizations must be measurable and reversible.

Measured acceptance targets (initial hypotheses, **not promised results**):
- At least 20% improvement in median end-to-end completion time on an agreed representative multi-file task suite, without loss of completion quality. If the result does not clear the bar, report the measured improvement and investigate bottlenecks rather than asserting success.
- Fewer duplicate file reads/model turns for representative bug-fix and cross-layer analysis tasks; report p50 and p95.
- Equal or better source-grounded correctness and retrieval precision@5 versus version 34; no invented file paths or line references.
- Zero new MCP-policy, approval, rollback or documentation-prompt-priority violations in regression tests.
- No lost mandatory requirements across forced compactions, simulated crashes or model failovers.
- JAR boots and operates on the existing Java 17 target environment with offline-safe fallbacks.

## 2. Verified version-34 integration points

| Existing code | Current mechanism | Eliya 35 change |
|---|---|---|
| `AgentService.activeContextBundle()` | Calls `workspaceRetrieval.retrieve(ws, query, 8, 7_000)` and `impactReport(...)`, caches by run/step/mutation/query | Ask one shared evidence assembler for scored symbol ranges and cached fingerprints |
| `AgentService.collectActiveStepFileEvidence()` | Uses 3 normal / 6 large files, reads lines `1..180`, clips each at 3,500 chars and total at 11,000 / 18,000 | Load exact declaration bodies and bounded neighboring evidence; Balanced default: 4 files, up to 24,000 chars total |
| `WorkspaceCodeIntelligence` | Java compiler AST has symbol starting lines; JS/TS use conservative extractors | Store start/end offsets and lines, qualified names, imports, method calls, enclosing type and confidence |
| `WorkspaceRetrievalIndexService` | File-scored retrieval, snippets and optional hybrid embeddings | Structured symbol hits with evidence provenance and dependency-aware re-ranking; keep old retrieval API intact |
| `ContextWindowManager` | Token estimate based on conservative ~3 chars/token, pruning, deterministic compaction and 8K-token tail | Allocate budgets dynamically per model/task; keep deterministic fallback; validate checkpoints against immutable task contract |
| `AgentRunService` | Persists plan, revisions, verification, touched files and usage; `durableContextText()` is bounded | Persist loss-resistant task contract/evidence ledger outside context; render compact authoritative suffix |
| `ContextService` / `ChatService` | Separate Chat context construction; reference projects are read-only | Reuse retrieval engine for Chat via feature flag; preserve Chat history/attachments and no unwanted Agent routing |
| `OpenAiCompatibleClient` | Uses OpenAI-compatible endpoints, parses token/cache usage when provided | Instrument input/request/first token/total latency, estimated/actual tokens and cache hits without logging sensitive payloads |
| `ChatMcpService` / `McpPromptGate` | Only original **current** user prompt containing standalone `MCP` can route to MCP; global enable also required | Strictly preserve; retrieved/context/summary text must **never** opt in to MCP |
| `DocumentationIntelligenceService` / Agent docs flow | Built-in template only when explicitly chosen in UI; user's output contract wins | Preserve selected-template flag and prompt authority through compaction, restart and failover |
| `ProtectedRunSnapshotService`, `AgentApprovalService`, `AgentTaskRollbackService` | Protected baseline, deletion approval/timeout and rollback | Keep as independent synchronous safety gates; context optimization must not bypass them |

## 3. Context profiles and precise budget semantics

**Units:** evidence and retrieval values below are *characters*, except the history-tail column, which is *tokens*. These are **hard maximums per active context bundle**, not minimums. Never pad prompts to a quota.

| Profile | When selected | Max preloaded files | Live code evidence | Retrieval hints | Historical recent tail |
|---|---|---:|---:|---:|---:|
| Fast | Explanation, simple review, one-class task | 2–3 | 8K–12K chars | 4K–7K chars | 6K tokens |
| **Balanced (default)** | Normal development, multi-file fixes, most Agent tasks | **4** | **24K chars** | **12K chars** | **8K tokens** |
| Deep | Cross-module investigation, migration, repository-scale architecture | Up to 8 | 40K chars | 16K chars | 12K–16K tokens |

**Important:** `modelContextWindows` / `safeContextWindowTokens(activeModel)` must govern the actual physical model turn, including role-routing or failover. Do not assume that an OpenAI-compatible model has 128K tokens merely because its model ID is unknown. Reserve tool schemas, immutable instructions, the actual user task, model output, a compaction buffer and a safety margin first. Shrink optional retrieval and evidence budgets in that order when capacity is low. Small-context models must not attempt a 24K-character Balanced bundle if it cannot safely fit.

**Allocation algorithm:**
1. Determine selected model and *configured/known* context capacity, respecting user per-model override and any reliable provider metadata; mark unverified fallback limits as estimated.
2. Calculate conservative available input tokens after output reserve, tool definitions, system instructions, current user request, approved plan and protected contract excerpt.
3. Reserve user requirements and one current error/verification result before retrieval.
4. Fill from highest-confidence code symbols, then immediate caller/callee dependencies, then optional background snippets; deduplicate repeated lines, unchanged blocks and overlapping ranges.
5. Stop at both the per-section character cap and the whole-request token cap; never truncate in the middle of a Unicode character or silently omit an essential user requirement.
6. If a context error occurs, shrink the optional evidence and prune history once, preserving invariants; only then use the existing recovery/failover behavior.
7. Default to Balanced automatically. Escalate to Deep if actual task indicators or repeated missing-evidence signals justify it; de-escalate after the complex step. User settings should allow explicit profile override eventually.

## 4. Symbol-based evidence: design and algorithm

### New data model

`CodeSymbol` fields: `projectId`, `rootAlias`, `relativePath`, `language`, `qualifiedName`, `kind`, `startLine`, `endLine`, `startByte`, `endByte`, `declarationLine`, `parentSymbol`, `imports`, `references`, `fileFingerprint`, `parserConfidence`.

`EvidenceFragment` fields: `evidenceId`, `projectId`, `path`, `symbolId`, `lineStart`, `lineEnd`, `fingerprint`, `confidence`, `selectionReason`, `text`, `truncationReason?`.

`EvidenceBundle` fields: `profile`, `model`, `indexRevision`, `workspaceMutationRevision`, `query`, `fragments[]`, `dependencyEdges[]`, `estimatedTokens`, `omittedCandidates[]`, `buildDurationMs`.

### New services

- `WorkspaceSymbolIndexService`: builds and updates symbol ranges using Java JDK compiler AST for `.java`; for `.ts/.tsx/.js/.jsx` use conservative extractors with balanced brace/string/comment tracking where safe, and explicit low-confidence fallback when parsing is ambiguous. Do not silently claim full TypeScript AST fidelity.
- `WorkspaceEvidenceAssembler`: retrieves structured hits, selects exact symbol ranges, appends limited context and one hop of relevant dependencies; ranks by exact method/path, query match, current plan step and recent failing stack traces. Always validate live path, symlink policy, workspace permissions and fingerprint before reading.
- `ContextBudgetPolicy`: resolves profile, model context limit, mandatory overhead and per-section budget; is pure/testable and does not access the LLM or filesystem.
- `EvidenceLedgerStore`: stores provenance and hashes for previously verified observations, referencing source rather than replaying full code. Changes invalidate stale entries.

### Selection order

1. Exact path+symbol from stack trace or active plan; 2. matching qualified Java/TS symbol; 3. direct caller/callee, interface/implementation, page object/test relationship; 4. dependency/impact graph; 5. lexical/semantic fallback. Prefer 1 complete relevant method over 4 unrelated file headers. Avoid loading binary files, secrets, huge generated code or reference-only material that the task did not require.

### Live read rules

- Verify file is still within authorized workspace/root; prevent traversal and unsafe symlinks.
- Read actual method body from verified start to end (bounded by budget); add nearby annotations/imports only when material to comprehension.
- If the function exceeds the remaining budget, include declaration, high-value code regions and an explicit `PARTIAL_SOURCE` marker with path/range and a subsequent read handle. **Never label a partial method as complete.**
- Show `workspace:src/.../Example.java:L650-L742` style provenance to the model. Distinguish current content from cached index metadata.
- For overloaded methods and duplicate names, require qualified signature/disambiguation.
- Invalidate evidence on edits, renames, deletes, workspace switch, explicit file watch events and stale file fingerprint; use reconciliation where watcher events may be lost.
- Maintain read-only behavior for all reference workspaces and their aliases.

### Example output to the LLM

```text
ACTIVE STEP EVIDENCE — live, source grounded
Task: Fix severity calculation used by dashboard KPI
Source: workspace:src/main/java/.../AlertService.java:L640-L715
Symbol: AlertService.calculateSeverity(Event) [complete]
Fingerprint: <sha256>
Relevance: exact method + downstream API reference
Code: <verified excerpt>
Next dependency: workspace:.../AlertMapper.java:L81-L130
Confidence: Java AST + live-file verified
```

## 5. Loss-resistant execution memory

Do **not** rely on a free-form LLM summary as the only memory of a long-running task.

### Immutable Task Contract (authoritative)

Persist the complete original user prompt and a structured `TaskContract` with: `runId`, `contractVersion`, `originalPromptHash`, original requirements, requested deliverables, exclusions, instructions and preference constraints, selected documentation-template flag, explicit original MCP-request flag, scope/allowed roots, user approvals reference, and plan revision links. Original prompt is the ultimate authority: the parsed contract assists, but never overrides user wording. Store outside the active messages, using bounded injections plus on-demand source recovery.

### Durable Work Ledger (mutable, append-only events)

Record step started/completed/failed, file fingerprint before and after change, touched files, verification commands/results, error signatures, reasons for retry, pending dependencies and the next action. Use versioned JSON sidecars under `app.data-dir` (outside workspace), atomic writes, checksums and corruption-safe fallback. Reuse existing `AgentRunService` persistence and work-item ledger; do not duplicate rollback truth. Scrub secrets and avoid persisting credential-bearing tool outputs.

### Evidence Ledger (rebuildable)

Store paths, symbol ranges, revision/fingerprints and verification timestamps. Full text is retrieved from authorized live files when required; never assume a remembered excerpt is still current.

### Compaction rules

- Keep the current system constraints, newest real user instruction, approved plan step, pending tool-call pairs, most recent error/verification and the relevant evidence pointers.
- Before compaction, write checkpoint metadata; after rebuilding context, assert that mandatory requirement identifiers remain addressable. Keep deterministic compaction as guaranteed fallback.
- Optional semantic summary is permitted only if available, cheap and nonblocking; validate it against the authoritative contract, never use it to change permissions or create new requirements.
- After crash/restart/model failover, hydrate task contract and ledger, verify current workspace revision and resume from next approved step. Do not replay a mutation blindly.
- Bounded `durableContextText()` is a *view* of durable state; do not treat its clipped fields as the only saved copy.

## 6. Agent/Chat integration and compatibility

### Agent path

`AgentService.prepareActiveContext()` → `ContextBudgetPolicy` → `WorkspaceEvidenceAssembler` → `ContextWindowManager.upsertRetrievalHints()` → model completion. The final implementation replaces the old `collectActiveStepFileEvidence` implementation directly with one `WorkspaceEvidenceAssembler` code path; it retains the `activeContextBundle` entry point and contains no runtime version flag. Share the active run/step/revision cache but key entries by **root, index revision and file fingerprints**, not only run and mutation revision. Clear after edits/rollback and after workspace/reference changes.

### Chat path

The Chat path remains independent. Let `ContextService.build()` opt into the same evidence assembler *only when there is a relevant selected workspace or reference*. Preserve normal Chat conversation history, uploaded file/vision support, model choice and interaction latency. Use Fast/Balanced retrieval for question answering, not an Agent plan or mutation capabilities. Do not introduce MCP discovery from indexed text.

### Settings/UI

- Default to internal `BALANCED`, with no new required user action.
- Add optional **Context profile: Auto (Balanced) / Fast / Balanced / Deep** to Advanced Settings after backend tests pass. `Auto` selects Balanced unless task complexity justifies another profile.
- Show an unobtrusive `Context diagnostics` view with last request details and why information was excluded.
- Maintain backward compatibility for existing saved browser settings, JSON API requests and Java record constructors/tests. Adding a new positional component to `ChatSettings` requires an explicit backward-compatible constructor or a separate optional settings DTO; do not break older clients.
- Never change model lists or silently enable fallback models.

## 7. Context metrics and task telemetry

Add `ContextMetricsService` with timing spans and aggregate snapshots, linked to run ID and step ID. Measurements:

| Stage | Measurements |
|---|---|
| Workspace / index | indexed files, changed files, symbol extraction ms, retrieval ms, cache hit/miss, stale-evidence refreshes |
| Evidence assembly | candidate count, selected symbol count, files, characters, estimated tokens, skipped/truncated evidence, reasons |
| LLM transport | provider/model, request bytes, request-start→first-token ms (streaming), total provider ms, provider input/output/cache tokens, estimates, retries, failures |
| Agent execution | planning ms, tool execution ms, repeated reads prevented, edit ms, verification/build ms, compaction count/ms, recovery ms |
| Completion | end-to-end time, p50/p95 by task class, validation passed, task completed, user approval waiting time separately |

Keep actual provider token usage as authoritative when present and label estimated values clearly. No sensitive prompts/source-code/keys in diagnostics, telemetry logs or reports. Cap metrics memory, persist lightweight aggregates with retention, and avoid expensive timing/logging on hot paths. Enrich existing `AgentRunService.tokenUsage` response rather than replacing it.

**Diagnostic report sample:** profile=Balanced; model context capacity=verified/estimated; input estimate=23,400 tokens; actual=22,800; live code=17,900 chars; relevant symbols=3; avoided rereads=4; provider=21.5s; retrieval=0.12s; edit/validation=8.7s; compactions=0. All example values are illustrative, not measured.

## 8. Mandatory non-regression invariants

1. **MCP:** Only a standalone `MCP` in the **current original user prompt** + enabled MCP configuration may trigger MCP; no keyword, retrieved content, summary, previous turn, reference path or tool output can bypass the gate. If disabled, do not discover or invoke MCP.
2. **Documentation:** When the user has not explicitly selected a UI template, obey the user's requested documentation structure exactly; Prompt Factory is where users get prompt assistance. No injected default template. If a UI template is selected, explicit user instructions take priority.
3. **Approvals:** Existing plan-edit/approval, tool approvals and file-delete confirmation must remain authoritative. A pending 60-second deletion approval timeout must stop the task and invoke the existing protected rollback path as defined by current behavior. Context cannot imply approval.
4. **Rollback:** Exact last-operation restoration of affected files, including created/deleted files; protected snapshots and rollback ledger must not be replaced by inferred model history.
5. **References:** Up to 5 aliases, all read-only; preserve primary workspace distinction and file-path safety.
6. **Chat:** Attachments, vision handling, history and Chat-only behavior remain intact. Agent-side optimizations must not force extra Agent or MCP calls into Chat.
7. **Provider and runtime:** Support existing selected models, editable model library, OpenAI-compatible gateways, Java 17 and restricted office hosts. Missing embedding service must fall back to lexical/structural retrieval with bounded latency.
8. **No silent loss:** Requirements must survive compaction, restart, provider failure and failover. Missing evidence is explicitly stated as missing, not inferred.

## 9. Implementation work packages (merge order)

| Work package | Principal files/new classes | Deliverable | Exit gate |
|---|---|---|---|
| **WP0 Baseline & instrumentation** | Existing `AgentRunService`, `OpenAiCompatibleClient`; new `ContextMetricsService` | Measured v34 benchmark, timers/usage, safe logs | Baseline report and zero functionality change |
| **WP1 Context budget policy** | New `ContextBudgetPolicy`, `ContextProfile`, existing `ContextWindowManager`, `ChatSettings` adapter | Auto Balanced with model-aware capacity and degradation | 16K/32K/128K/provider-unknown/failover tests pass |
| **WP2 Symbol extraction** | Extend `WorkspaceCodeIntelligence`; new `WorkspaceSymbolIndexService` | Java AST start/end ranges; conservative TS/JS ranges | Overloads, nested, generics, comments, shifted lines, parser failure tests |
| **WP3 Evidence assembly** | New `WorkspaceEvidenceAssembler`, extend retrieval service, adapter in `AgentService` | Correct methods/dependencies rather than file headers | Source line/fingerprint test, path security tests, evidence quality benchmark |
| **WP4 Durable contract/ledger** | New `TaskContractStore`, `EvidenceLedgerStore`; extend `AgentRunService` | Requirements survive compact/restart/failover | Crash, forced compaction, changed-file and resume tests |
| **WP5 Chat and diagnostics** | `ContextService`, `ChatService`, optional static UI | Shared bounded retrieval, read-only diagnostics; no Agent side effects | Chat/MCP/template/vision/history regression suite |
| **WP6 Validation & release** | New JUnit fixtures, JS checks, offline smokes, CI workflow | Benchmarked, validated Java 17 JAR; release notes and separate archived baseline | Full tests, comparative benchmarks, clean JAR boot, ZIP/package inspection |

**Final single-engine release decision:** The legacy context builder and the `eliya.context.v35.enabled` switch were removed. Adaptive context is the sole Agent implementation. Keep the entire previous source archive for disaster recovery, not a second runtime path. CI checks that the obsolete method and switch cannot return.

## 10. Concrete test matrix

**Symbol correctness:** overloaded/nested Java methods; annotations; CRLF; comments with braces; generics; very long methods; TSX/JS import aliases; empty/binary/minified/generated files; method at line 650; unicode; stale index after edit; same method names in two roots.

**Budget and compaction:** Fast/Balanced/Deep in verified 16K, 32K, 128K models; unverified context limit; large tool schema; huge error log; repeated tool results; first-run prompt >40K chars; output reserve; failover to smaller model; provider missing token usage; forced context overflow; multi-step recovery.

**State preservation:** long user instruction; exclusions and read-only constraints; approved plan changes; two app restarts; partial sidecar write/corruption; hash mismatch; completed step not repeated; unsuccessful tests retained; previous error not reintroduced.

**Safety:** current prompt `Jira MCP` vs `Jira` alone vs `MCP` only in source/history; disabled MCP; selected/unselected documentation template; rejection/timeout of deletion approval; create/update/delete rollback; symlink/traversal; reference alias isolation; cancellation during indexing and compaction.

**Workflows:** plain Chat, Chat+workspace, Chat+attachments/vision, Agent bug fix, multi-file refactor, Java Selenium→Playwright migration, Kafka→Flink→Elasticsearch→API→UI analytical query, documentation generation, recovery after API timeout; Windows and Linux path handling.

**Commands (once code exists):**

```bash
mvn -B -Pfull-tests -Dmaven.test.skip=false clean verify
node --check src/main/resources/static/app.js
node --test src/test/js/*.test.js
bash qa/offline-smoke/run.sh
```

Also run the existing `verify-eliya.yml` checks and any additional smoke scripts required by that workflow. Confirm the resulting `target/eliya.jar` exists, builds under Java 17 and starts; dependency classpath inspection should cover known POI/commons failures. The standard Maven `pom.xml` defaults to skipped tests, so **`-Pfull-tests` is mandatory for acceptance**.

## 11. Benchmark method and release decision

Build a fixed set of realistic tasks (e.g., 5 single-file, 5 multi-file fixes, 5 code-flow questions, 3 migrations, 3 docs tasks) against immutable copies of the same repositories with the same model, model settings and relevant network conditions. Run each scenario repeatedly and compare v34 vs v35. Exclude user waiting/approval time from *agent compute latency* but report it in user-visible elapsed duration. Measure p50/p95, success rate, source-grounded accuracy, redundant reads, tool calls, model calls, actual and estimated tokens, cache hit percentage, compaction/retry rate and memory consumption. Use paired comparisons, flag provider variability, and do not describe synthetic targets as achieved measurements.

**Go** only if: all safety/functional tests pass, no task-quality regression, requirements survive compaction/restart, offline fallback works and performance measurements are transparent. **No-go** if: any approval/MCP regression, silent loss of requirements, unsafe path traversal, rollback mismatch or systematic quality regression. Roll back to the v34 evidence builder using the feature flag if needed.

## 12. Recommended sequencing and final architecture

**Implement WP0 → WP1 → WP2 → WP3 first.** This attacks needless file rereads and context overflow with the lowest change risk. Then implement WP4 for durable correctness and WP5 for Chat/UI parity. Complete WP6 before packaging. Avoid unrelated rewriting of MCP, Agent tools, approval engines, rollback snapshots and document generation. Keep extensions additive, testable and togglable.

**Desired context path:**

```text
Current user request + approved plan + immutable task contract
                         |
            ContextBudgetPolicy (Auto→Balanced)
                         |
    WorkspaceSymbolIndex + hybrid retrieval/impact graph
                         |
 EvidenceAssembler (live methods, provenance, cache validation)
                         |
 Current step context + recent history + durable state pointers
                         |
   ContextWindowManager (token-cap, pruning, safe compaction)
                         |
      Existing OpenAiCompatibleClient / configured model
                         |
   Existing tool/approval/rollback/verification workflows
                         |
        Work ledger + Context Metrics + next step
```

**Implementation boundary:** This file is a plan based on source inspection, **not** an implemented or validated Eliya 35 package.
