package com.llmart.llm.service;
import java.nio.file.*;
import java.util.*;
import com.llmart.llm.dto.ChatSettings;

/** Actual local index + slow embedding stub; no network or Maven dependencies. */
class FastChatSmoke {
 static void check(boolean condition, String message) { if (!condition) throw new AssertionError(message); }
 public static void main(String[] args) throws Exception {
  Path root = Files.createTempDirectory("eliya-fast-chat-");
  Path data = Files.createTempDirectory("eliya-fast-chat-data-");
  try {
   System.setProperty("app.data-dir", data.toString());
   for (int i=0;i<1200;i++) Files.writeString(root.resolve("Service"+i+".java"),
           "class Service"+i+" { int calculateAlertSeverity() {return 8;} }\n");
   OpenAiCompatibleClient provider = new OpenAiCompatibleClient();
   WorkspaceRetrievalIndexService index = new WorkspaceRetrievalIndexService(provider);
   check(index.warmRoot("project-1",root).indexedFiles()==1200,"1200 file indexing failed");
   var settings = new ChatSettings("http://example.invalid", "stub-embedding", true);
   try (FastChatRetrieval fast = new FastChatRetrieval(index)) {
    long now=System.nanoTime();
    String lexical=fast.retrieve("project-1",root,"calculateAlertSeverity",6,6000,"key",null,()->false);
    check(lexical.contains("Service"),"cached lexical retrieval lost");
    check((System.nanoTime()-now)<2_000_000_000L,"cached index unexpectedly slow");
    provider.slowMillis=3000;
    now=System.nanoTime();
    String fallback=fast.retrieve("project-1",root,"calculateAlertSeverity",6,6000,"key",settings,()->false);
    check(fallback.contains("Service"),"slow semantic fallback did not return lexical evidence");
    check((System.nanoTime()-now)<2_000_000_000L,"semantic deadline not enforced");
    try {fast.retrieve("project-1",root,"calculateAlertSeverity",6,6000,"key",settings,()->true);
      throw new AssertionError("cancelled retrieval not stopped");
    } catch(AgentCancelledException expected) {}
    String jira="BMSA-5389 description: Calculate alert severity from events. Acceptance criteria: " +
            "the histogram must reflect alert severity and KPI counts. ".repeat(9);
    String grounding=ChatWorkspaceEvidence.augment(index,"project-1",root,
            "Using Jira MCP, compare BMSA-5389 against my workspace and check implementation gaps", jira);
    check(grounding.contains("LOCAL WORKSPACE EVIDENCE"),"Jira requirements were not grounded");
    check(grounding.length()<=14_000,"grounding exceeded bounded context");
   }
   System.out.println("PASS: 1200-file cached retrieval, semantic slow-provider deadline, cancellation, bounded Jira-to-code grounding");
  } finally {
   try(var walk=Files.walk(root)) {for(var p:walk.sorted(Comparator.reverseOrder()).toList()) Files.deleteIfExists(p);}
   try(var walk=Files.walk(data)) {for(var p:walk.sorted(Comparator.reverseOrder()).toList()) Files.deleteIfExists(p);}
  }
 }
}
