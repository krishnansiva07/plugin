package com.llmart.llm.service;
import java.util.*;
import java.util.function.BooleanSupplier;
public class OpenAiCompatibleClient {
 int calls; int embeddedInputs; boolean fail; long slowMillis; List<String> mostRecentInputs = List.of();
 public List<double[]> embed(String key, String baseUrl, String model, List<String> inputs, BooleanSupplier cancelled) {
  if (slowMillis > 0) {
   try { Thread.sleep(slowMillis); } catch (InterruptedException e) { Thread.currentThread().interrupt(); throw new IllegalStateException("Cancelled"); }
  }
  if (fail) throw new IllegalStateException("Provider offline");
  calls++; embeddedInputs += inputs.size(); mostRecentInputs = List.copyOf(inputs);
  List<double[]> result = new ArrayList<>();
  for (String input : inputs) {
   String text = input.toLowerCase(java.util.Locale.ROOT);
   result.add(new double[] {(text.contains("login") || text.contains("auth")) ? 1.0 : 0.0,
      text.contains("api") ? 1.0 : 0.0, text.contains("test") ? 1.0 : 0.0, 0.1});
  }
  return result;
 }
}
