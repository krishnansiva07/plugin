#!/usr/bin/env bash
set -euo pipefail
BASE="$(cd "$(dirname "$0")/../.." && pwd)"
TEMP="$(mktemp -d)"
trap 'rm -rf "$TEMP"' EXIT
find "$BASE/qa/intelligence-smoke/src" -name '*.java' > "$TEMP/source-list"
cat >> "$TEMP/source-list" <<SOURCES
$BASE/src/main/java/com/llmart/llm/service/WorkspaceCodeIntelligence.java
$BASE/src/main/java/com/llmart/llm/service/WorkspaceEmbeddingStore.java
$BASE/src/main/java/com/llmart/llm/service/WorkspaceRetrievalIndexService.java
$BASE/src/main/java/com/llmart/llm/service/FastChatRetrieval.java
$BASE/src/main/java/com/llmart/llm/service/ChatWorkspaceEvidence.java
$BASE/src/main/java/com/llmart/llm/service/AgentCancelledException.java
$BASE/qa/intelligence-smoke/src/com/llmart/llm/service/FastChatSmoke.java
SOURCES
javac -encoding UTF-8 -d "$TEMP/classes" @"$TEMP/source-list"
java -cp "$TEMP/classes" com.llmart.llm.service.IntelligenceSmoke
java -cp "$TEMP/classes" com.llmart.llm.service.FastChatSmoke
java -cp "$TEMP/classes" com.llmart.llm.service.SyntaxScan "$BASE/src/main/java"
mkdir -p "$TEMP/contracts"
javac -encoding UTF-8 -d "$TEMP/contracts" \
    "$BASE/qa/intelligence-smoke/src/org/springframework/stereotype/Service.java" \
    "$BASE/qa/intelligence-smoke/contracts/com/fasterxml/jackson/annotation/JsonAlias.java" \
    "$BASE/src/main/java/com/llmart/llm/service/ModelCapabilityRegistry.java" \
    "$BASE/src/main/java/com/llmart/llm/dto/ChatSettings.java" \
    "$BASE/src/main/java/com/llmart/llm/service/AgentToolRegistry.java" \
    "$BASE/qa/intelligence-smoke/contracts/com/llmart/llm/service/IntegrationContracts.java"
java -cp "$TEMP/contracts" com.llmart.llm.service.IntegrationContracts
