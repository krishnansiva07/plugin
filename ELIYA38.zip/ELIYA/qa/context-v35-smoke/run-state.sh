#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../.."
DIR="$(mktemp -d)"; trap 'rm -rf "$DIR"' EXIT
PKG="$DIR/src/com/llmart/llm/service"; mkdir -p "$PKG" "$DIR/src/org/springframework/stereotype" "$DIR/classes"
echo 'package org.springframework.stereotype; public @interface Service {}' > "$DIR/src/org/springframework/stereotype/Service.java"
cat > "$PKG/OpenAiCompatibleClient.java" <<'JAVA'
package com.llmart.llm.service;
class OpenAiCompatibleClient {
 record Usage(long inputTokens, long outputTokens, long totalTokens, long cachedInputTokens, long cacheWriteTokens) { }
}
JAVA
cat > "$PKG/ProtectedRunSnapshotService.java" <<'JAVA'
package com.llmart.llm.service;
class ProtectedRunSnapshotService { void discard(String id) {} }
JAVA
cat > "$PKG/AgentCancelledException.java" <<'JAVA'
package com.llmart.llm.service;
class AgentCancelledException extends RuntimeException { AgentCancelledException(String s) { super(s); } }
JAVA
cat > "$PKG/StateSmoke.java" <<'JAVA'
package com.llmart.llm.service;
import java.nio.file.*;
import java.util.Comparator;
public class StateSmoke {
 static void ok(boolean b, String msg) {if(!b)throw new AssertionError(msg);}
 public static void main(String[] args) throws Exception {
  Path dir=Files.createTempDirectory("eliya35-state");
  try {
   var store=new AgentRunService(dir);
   var run=store.start("conversation","project");
   String original="Requirements: never use MCP unless requested; never delete without approval. "+"Retain every constraint. ".repeat(150);
   run.setObjective(original);
   run.setObjective("Later execution step");
   run.recordContextEvidence("BALANCED",3,2,4500,43);
   run.recordProviderLatency(222);
   run.recordEvidenceCacheHit();
   run.finish("completed");
   String id=run.id();
   var loaded=new AgentRunService(dir).require(id);
   ok(loaded.originalTaskContract().equals(original.strip()),"original user task lost after restart");
   ok(loaded.objective().equals("Later execution step"),"latest objective lost after restart");
   var usage=(java.util.Map<?,?>)loaded.snapshot().get("tokenUsage");
   ok(((Number)usage.get("evidenceFiles")).longValue()==3,"evidence file metrics not persistent");
   ok(((Number)usage.get("providerLatencyMs")).longValue()==222,"provider metrics not persistent");
   ok(loaded.durableContextText().contains("never use MCP unless requested"),"task lost from model continuation");
   System.out.println("PASS: original task persisted through restart, current objective, evidence/provider metrics, compact state");
  } finally {try(var walk=Files.walk(dir)){for(var p:walk.sorted(Comparator.reverseOrder()).toList())Files.deleteIfExists(p);}}
 }
}
JAVA
javac --release 17 -d "$DIR/classes" $(find "$DIR/src" -name '*.java') \
 src/main/java/com/llmart/llm/service/AgentRunService.java
java -cp "$DIR/classes" com.llmart.llm.service.StateSmoke
