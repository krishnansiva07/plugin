#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../.."
DIR="$(mktemp -d)"; trap 'rm -rf "$DIR"' EXIT
PKG="$DIR/src/com/llmart/llm"; mkdir -p "$PKG/service" "$PKG/dto" "$DIR/classes"
cat > "$PKG/dto/ChatSettings.java" <<'JAVA'
package com.llmart.llm.dto;
public record ChatSettings(Integer contextWindowTokens, String modelContextWindows, Integer maxTokens) {
 public int safeContextWindowTokens(String model) {
  if (modelContextWindows!=null) for (String item:modelContextWindows.split("[\\n,]+")) {
   var parts=item.split("="); if (parts.length==2 && parts[0].equalsIgnoreCase(model)) return Integer.parseInt(parts[1]);
  }
  return contextWindowTokens==null ? 128000 : contextWindowTokens;
 }
 public int safeMaxTokens(){return maxTokens==null?0:maxTokens;}
 public int safeCompactionBufferTokens(String model){return Math.max(4000,Math.min(20000,safeContextWindowTokens(model)/2));}
}
JAVA
cat > "$PKG/service/AgentWorkspaceService.java" <<'JAVA'
package com.llmart.llm.service;
import java.nio.file.*; import java.nio.charset.StandardCharsets;
import java.io.IOException;
class AgentWorkspaceService {
 record Workspace(Path root) { }
 String readFileRange(Workspace w, String path, int start, int end) throws IOException {
  var root=w.root().toRealPath(); var file=root.resolve(path).normalize().toRealPath();
  if (!file.startsWith(root)) throw new IOException("outside root");
  var lines=Files.readAllLines(file, StandardCharsets.UTF_8);
  StringBuilder b=new StringBuilder("FILE: "+path+"\n");
  for(int i=start;i<=Math.min(end,lines.size());i++) b.append(i).append(" | ").append(lines.get(i-1)).append("\n");
  return b.toString();
 }
}
JAVA
cat > "$PKG/service/V35Smoke.java" <<'JAVA'
package com.llmart.llm.service;
import com.llmart.llm.dto.ChatSettings;
import java.nio.file.*; import java.util.*;
class V35Smoke {
 static void ok(boolean condition,String label) { if(!condition) throw new AssertionError(label); }
 public static void main(String[] args) throws Exception {
  Path tmp=Files.createTempDirectory("eliya-v35");
  try {
   Path src=tmp.resolve("src"); Files.createDirectories(src);
   StringBuilder source=new StringBuilder("class Alerts {\n");
   for(int i=0;i<680;i++) source.append(" // padding line ").append(i).append("\n");
   source.append("int calculateAlertSeverity(int incidents) {\n return incidents * 3;\n}\n}\n");
   String name="Alerts.java"; Files.writeString(src.resolve(name),source.toString());
   var symbols=WorkspaceSymbolIndexService.extract(name, source.toString());
   var method=symbols.stream().filter(s->s.name().equals("calculateAlertSeverity")).findFirst().orElseThrow();
   ok(method.startLine()>650,"Java AST method position");
   ok(method.endLine()>=method.startLine()+2,"Java AST method end");
   var settings=new ChatSettings(128000,null,4000);
   var budget=ContextBudgetPolicy.select(settings,"gpt-oss-120b",false,1000);
   ok(budget.profile()==ContextBudgetPolicy.Profile.BALANCED,"Balanced default");
   ok(budget.files()==4 && budget.evidenceChars()==24000,"Balanced bundle caps");
   var small=ContextBudgetPolicy.select(new ChatSettings(16000,"small=16000",4000),"small",false,11500);
   ok(small.evidenceChars()==0,"low-capacity must shrink optional data");
   var reduced=ContextBudgetPolicy.select(new ChatSettings(128000,"small=16000",4000),"small",true,11500);
   ok(reduced.evidenceChars()==0,"failover context-aware budget");
   var assembler=new WorkspaceEvidenceAssembler(new AgentWorkspaceService());
   var ws=new AgentWorkspaceService.Workspace(src);
   var evidence=assembler.assemble(ws,"WORKSPACE RETRIEVAL HINTS\n- Alerts.java (score=91.0)\n", "fix calculateAlertSeverity",budget);
   ok(evidence.files()==1 && evidence.symbols()==1,"method evidence selected");
   ok(evidence.text().contains("return incidents * 3"),"method body loaded after 650 lines");
   ok(!evidence.text().contains("padding line 100"),"no irrelevant file header");
   var longSource="class Huge {\n void processAlerts(){\n"+" String a=\"large\";\n".repeat(900)+"}\n}\n";
   Files.writeString(src.resolve("Huge.java"),longSource);
   var huge=assembler.assemble(ws,"- Huge.java (score=99.0)","processAlerts",budget);
   ok(huge.text().contains("PARTIAL_SOURCE"),"partial symbol clearly labelled");
   ok(huge.text().length()<=budget.evidenceChars(),"overall evidence char ceiling");
   Files.writeString(src.resolve(".env"),"PASSWORD=secret");
   ok(assembler.assemble(ws,"- .env (score=99.0)","PASSWORD",budget).text().isEmpty(),"secrets denied");
   ok(assembler.assemble(ws,"- ../outside.java (score=99.0)","escape",budget).text().isEmpty(),"path traversal denied");
   String js="export function scoreAlerts(x) { // } in comment\n return {x: 'yes}'};\n}\n";
   var ts=WorkspaceSymbolIndexService.extract("alerts.ts", js);
   ok(ts.stream().anyMatch(s->s.name().equals("scoreAlerts")&&s.endLine()==3),"TS balanced method range");
   System.out.println("PASS: ELIYA35 Balanced model budgets, Java/TS symbol ranges, method at line 650, partial markers, path/secrets safety");
  } finally { try(var walk=Files.walk(tmp)) {for(var p:walk.sorted(Comparator.reverseOrder()).toList()) Files.deleteIfExists(p);} }
 }
}
JAVA
javac --release 17 -d "$DIR/classes" \
  "$PKG/dto/ChatSettings.java" "$PKG/service/AgentWorkspaceService.java" "$PKG/service/V35Smoke.java" \
  src/main/java/com/llmart/llm/service/ContextBudgetPolicy.java \
  src/main/java/com/llmart/llm/service/WorkspaceSymbolIndexService.java \
  src/main/java/com/llmart/llm/service/WorkspaceEvidenceAssembler.java
java -cp "$DIR/classes" com.llmart.llm.service.V35Smoke
