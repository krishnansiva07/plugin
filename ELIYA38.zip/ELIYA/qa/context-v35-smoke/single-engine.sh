#!/usr/bin/env bash
# Contract regression: there must be ONE active Agent context engine, without a runtime fallback switch.
set -euo pipefail
cd "$(dirname "$0")/../.."
python3 - <<'PYTEST'
from pathlib import Path
source = Path('src/main/java/com/llmart/llm/service/AgentService.java').read_text()
assert 'eliya.context.v35.enabled' not in source, 'obsolete v34/v35 flag must not control Agent context'
assert 'collectActiveStepFileEvidence' not in source, 'obsolete v34 file-header preload must be removed'
assert 'Original v34 context builder' not in source, 'obsolete fallback must be removed'
start = source.index('    private String activeContextBundle(')
end = source.index('    private void clearActiveContextCache(', start)
bundle = source[start:end]
assert bundle.count('evidenceAssembler.assemble(') == 1, 'must build live evidence with a single assembler'
assert 'ContextBudgetPolicy.select(' in bundle, 'must use model-aware budgets unconditionally'
assert 'currentFileStamps(ws' in bundle, 'must invalidate stale cached evidence'
assert 'run.recordEvidenceReferences(provenance)' in bundle, 'must retain evidence references'
assert 'run.recordContextEvidence(budget.profile().name()' in bundle, 'must persist context metrics'
assert 'legacy' not in bundle.lower(), 'must not retain alternate legacy path'
print('PASS: single optimized Agent context engine; no obsolete switch/preload; budgets, evidence, cache and metrics preserved')
PYTEST
