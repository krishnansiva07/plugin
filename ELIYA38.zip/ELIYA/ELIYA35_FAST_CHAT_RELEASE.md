# Eliya 35 – Fast Chat + Jira/workspace evidence optimization

Baseline: `ELIYA35_Single_Engine_Source.zip`. This is an updated **source release candidate**, not a certified executable JAR.

## Functional changes

1. `ContextService` now uses `FastChatRetrieval`, returning already-cached lexical evidence immediately and giving optional semantic reranking a **650 ms maximum wait** before falling back to cached source. Read-only reference projects have a separate **150 ms semantic wait per reference**. Concurrent semantic work is strictly bounded (2 workers, 4 queued), and work is cancelled on timeout. The real embedding provider may ignore interruption; bounded queues protect request threads.
2. Chat cancellation is registered before project/ref context building, not after. Context checks the Stop flag. The SSE transport sends an early `meta` and explicit context preparation/completion statuses. Chat sends an SSE comment heartbeat every 10 seconds to reduce idle-proxy disconnections. Disconnect remains distinct from explicit Stop, as before.
3. The existing Chat MCP path gains **one local code-grounding expansion** when a Jira issue comparison explicitly requests MCP, contains an issue key, has a selected indexed workspace, and the retrieved Jira result includes that issue's requirements. It derives up to 3 probes from returned requirement content, searches only the cached local index, and adds up to ~12K characters of clearly labeled *candidate* code evidence. This does not claim exhaustive acceptance-criteria coverage, add MCP requests, edit code, or trigger remote embedding.
4. Long prior assistant analysis responses are now retained as a bounded head/tail excerpt (clearly marked partial) rather than automatically losing all conversation history when one earlier response is oversized. Previous assistant answers remain stored as conversation messages; this change does **not** create a durable requirement/coverage ledger.
5. Existing Chat/Agent separation, documentation template opt-in, explicit MCP token gate, master MCP disable switch, rollback and approval controls are untouched. No v34/v35 context toggle was reintroduced.

## Offline validation completed

- Java code-index real fixture: 1,200 local files, cached lexical retrieval, intentionally slow 3-second embedding provider with bounded fallback, cancellation, Jira evidence caps.
- Full intelligence smoke: 1,099 files, AST Java/TS, dependency impact, incremental index updates and secret exclusions.
- Strict MCP Chat routing, evidence retention/cache, non-MCP and disabled-MCP protections, grounding eligibility smoke.
- Java 17 `javac --release 17` scoped offline tests; syntax parsing of all 91 Java production files.
- Rollback/deletion approval offline tests, Agent context/single-engine tests, persistence/restart, Vision and Confluence smoke tests, UI/API source contract checks, and 18 Node.js tests.

## Build limitation

Full Maven/JUnit compilation, Spring Boot startup, live Jira MCP and authenticated corporate model/provider latency tests were not run. This environment could not resolve Maven Central (`repo.maven.apache.org`), and the Maven executable is not installed. The package should be built and integration-tested where project dependencies and configured providers are available.

## Recommended acceptance checks on office/CI machine

1. Run `./mvnw -Pfull-tests clean package` and verify the fat JAR starts on Java 17.
2. In **Chat** with a 1,200-file project, test an ordinary question: it must not request MCP or rerun the workspace index.
3. Use "Using Jira MCP, retrieve BMSA-5389 and compare it with my workspace". Observe status, inspect Jira criteria and verify cited source symbols. If an issue has no matching code evidence, output **unverified** rather than **missing** by assumption.
4. Request "Generate an implementation prompt for the gaps" and verify the prompt retains requirements and is *not* executed in Chat. Paste it into Agent, approve and check rollback works.
5. Enable semantic retrieval but simulate slow/broken embedding endpoint: cached lexical evidence should still load quickly. Test `Stop` during preparation and MCP tools.
6. Disable MCP, then ask with explicit `MCP`; ensure no tool calls occur. Enable MCP but remove the word `MCP`; ensure no tool calls occur. Verify Confluence/Jira/GitLab/SonarQube permissions unchanged.
7. With up to five reference folders, confirm no noticeable waiting on each embedding request and ensure references are never mutated.
8. Test long gateway/provider delays to verify SSE heartbeat and explicit status. Stop must cancel in-flight work when the provider supports cancellation.

No claim is made that 100% Jira acceptance-criteria coverage is guaranteed, or that end-to-end latency has been measured against a live provider.
