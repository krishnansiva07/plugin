# Agent architecture

## Runtime path

```text
User prompt
   |
   +-- Chat ------------------------------------------------> selected Chat model
   |                                                         +-- images allowed only when that Chat model is vision-capable
   |
   +-- Agent
        |
        +-- resolve live workspace + instructions/resources
        +-- local lexical index + focused live-file evidence bundle
        +-- SAME selected Agent model analyses evidence and creates structured plan
        +-- deterministic plan structure/verification checks
        +-- user edits/reorders/approves plan
        +-- SAME Agent model executes one approved step at a time
        |      +-- authoritative file reads/evidence injected for active step
        |      +-- edit/run/build/test/check
        |      +-- context overflow -> checkpoint/compact -> retry same model
        |      +-- repeated/no-progress failure -> configured fallback takeover
        |      +-- fallback inherits same step, diff, evidence and failure memory
        |      +-- all fallbacks exhausted -> bounded recovery replan of unfinished work
        +-- verification + completion gate
        +-- durable final result/history/progress
```

The Agent model contract is intentionally simple: one selected **Chat / Agent** model owns the whole Agent workflow. The Settings model library still allows adding, testing, renaming, editing context/type and removing models. Ordered fallbacks are takeover models only. Image analysis is user-selected in Chat mode and is intentionally kept outside the autonomous Agent loop.

## Executor-pool exhaustion recovery

Executor fallbacks are not simple task restarts. Each fallback inherits the approved objective, completed plan steps, active step, live workspace, current diff, verifier state, retrieval hints and prior failure evidence. If every configured executor is exhausted, the harness invokes a bounded second-order recovery path instead of immediately giving up:

1. the Analysis role diagnoses whether the failure is recoverable or a genuine external/environment/credential blocker;
2. for recoverable failures, the Planning role rewrites only the unfinished portion of the approved plan;
3. the independent Plan Validator rejects repeated/ungrounded recovery strategies;
4. completed steps and valid current edits remain intact;
5. after validation, the executor model cycle restarts from the configured primary model on the new active recovery step.

Recovery replanning is deliberately bounded (two accepted replans per run, with bounded validator revisions) so the agent changes strategy without entering an endless planner/executor loop. Authentication failures are surfaced directly rather than wasting the fallback chain. Recovery state and diagnosis are durable and are restored with conversation history.

## Context lifecycle

Durable session history is retained separately from the active prompt sent to the model. Before a model request, the runtime estimates messages plus tool definitions. When the input is approaching the usable context limit, older history is replaced with a structured checkpoint and a recent tail is retained.

The checkpoint preserves objective, important details, binding user constraints, completed work, active work, blockers, next actions, relevant files, exact paths, verifier state, and key decisions. If semantic summarization fails, a deterministic fallback checkpoint is created so context maintenance cannot strand the run.

## Progress, live status and completion

Run state is independent of the HTTP streaming transport. The backend persists a bounded activity timeline together with the plan, validation result, active model, failover count, verification state and progress. The UI shows stage-level progress (Index → Analyse → Plan → Validate → Review → Execute → Verify → Complete), live activity text, current model and per-step evidence. During an active plan step, real tool activity advances a bounded portion of that step instead of leaving the bar visually frozen or pretending the step is already complete.

The backend persists the final assistant message first and then marks the run response as durable. The browser polls run state while streaming is active. If the durable terminal response exists but the HTTP/SSE stream remains open, the browser closes only the stale transport and immediately returns the composer to Send state.

Conversation reopening treats messages as authoritative and loads attachments, projects and Agent-run metadata independently. Optional old metadata failure therefore cannot prevent an older chat from opening. Persisted Agent activity/plan state is reattached to the corresponding assistant message when available, with an ordered fallback for older records that predate message identifiers/timestamps.

## No-progress protection

Productive work is not restricted by a fixed step ceiling. Instead, guards are tied to actual progress:

- same tool + same args + same normalized result + same workspace revision -> warning, then block
- repeated verifier outcome without a new revision -> change strategy or stop as blocked
- repeated non-actionable model output without tool/workspace progress -> stop
- no-op edits do not create a new workspace revision
- process polling is allowed a small extra repeat window because process output can legitimately remain unchanged briefly

## Workspace authority

An explicit primary path in the current Agent prompt overrides an older active workspace. If the current prompt contains no path, the active workspace may be reused for follow-up work. Additional paths remain separate resources so reference inputs are not accidentally treated as writable primary projects.


## Evidence-first editable planning

Planning is single-model and evidence-first. The runtime gathers bounded read-only repository evidence, including key descriptors/search hits, and the selected Agent model analyses that evidence while producing structured JSON plan steps in one call. The harness checks step count/structure and requires explicit validation evidence on every step; one corrective retry is allowed if the returned structure is incomplete. Exact unproven filenames/methods should be inspected during execution instead of invented during planning.

The draft remains human-editable while approval is pending. The UI formats it as a plan board and can edit, reorder, add, remove and deselect steps through `/api/agent/runs/{id}/plan`. Approval locks the retained plan and starts only step 1.

## Token budget strategy

Active model context is treated as a cache, not durable state. Durable plan/model/workspace/verification state lives in `AgentRunService`. Agent history injection is capped, old tool observations are pruned, generated steering messages are tagged and superseded copies are removed, and compaction uses an adaptive high-water mark derived from the provider-safe input limit minus dynamic headroom rather than a fixed utilization percentage. Cheap deterministic pruning happens first. Most compactions use deterministic checkpoints; semantic compaction is periodic or used for forced overflow recovery. A local lexical workspace index is always available and is the Agent retrieval baseline. The strongest active-step hits are supplemented with bounded current file contents before model calls, so implementation is grounded in the live filesystem without depending on a secondary embedding model.
