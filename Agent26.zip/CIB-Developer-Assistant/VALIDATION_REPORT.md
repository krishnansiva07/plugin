# Validation Report — CIB Developer Assistant

Validation date: 2026-09-15

## Package status

**READY FOR USER VALIDATION.**

This build intentionally simplifies Agent orchestration to **one user-selected Agent model for the complete task**, with ordered fallback takeover only. Chat keeps an independent model and is the only mode that accepts image input.

A complete Spring Boot/Maven dependency-backed build could not be run in this sandbox because Maven bootstrap cannot resolve `repo.maven.apache.org`. Run `validate-local.bat` / `validate-local.sh` on a machine with dependency access before production use.

## Passed checks

- Frontend JavaScript syntax: **PASS**
  - `node --check src/main/resources/static/app.js`
  - `node --check src/main/resources/static/markdown.js`
- Frontend runtime smoke: **PASS**
  - application initialization completes in a DOM smoke harness
  - Settings modal opens
  - Chat model picker is populated
  - Settings Agent-model selector is populated
- HTML/UI contract: **PASS**
  - required settings/model controls exist
  - no duplicate element IDs
  - model datalist is parsed before `app.js` executes (fixes the Settings/model-picker initialization failure)
  - old per-role Agent routing controls are not exposed
- Shell syntax: **PASS** (`run.sh`, `validate-local.sh`)
- `pom.xml` XML parse: **PASS**
- Java 17 language/syntax scan: **PASS**
  - all main/test Java sources were parsed with `javac --release 17 -proc:none -XDshouldStopPolicy=PARSE`
  - no parser/language-level diagnostics were detected; unresolved external-dependency diagnostics are expected in this sandbox
- Single-model configuration harness: **`SINGLE_MODEL_HARNESS_PASS`**
  - Analysis → selected Agent model
  - Planning → selected Agent model
  - Plan review/validation → selected Agent model
  - Completion review → selected Agent model
  - semantic/embedding role routing disabled for Agent
  - ordered fallback pool remains available
- Visible product-version label scan: **PASS**
  - no application version label is shown in the UI

## Important flow changes verified

- **One Agent model for the whole task.** There are no hidden Analysis/Planner/Validator/Critic model assignments in the UI or effective backend routing.
- **Fallbacks are takeover only.** They preserve the approved plan, active step, current workspace, verifier state and failure memory; they do not split normal work across roles.
- **Faster planning path.** Initial Agent planning now uses one evidence-backed model call instead of separate Analysis → Planning → Validator LLM calls. The harness performs deterministic plan structure/range/per-step verification checks and allows one corrective planning retry only when required.
- **Authoritative active-step context.** Local retrieval identifies relevant files, then the runtime preloads bounded **current file contents** for the strongest matches into the active model context. This reduces failures caused by planning/execution against filenames or stale snippets without the exact method/signature/data.
- **Retrieval remains local and deterministic.** Agent no longer depends on a separate embedding model. Retrieval caches are invalidated after mutations.
- **Chat/image separation.** Image attachments are accepted only in Chat mode. The selected Chat model must be vision-capable. Agent rejects image attachments rather than making hidden vision-model calls.
- **Model-library safety.** Agent selectors expose Chat / Agent entries only; dedicated Vision/OCR/Embedding entries are not offered as the primary Agent model.
- **Settings/model picker fix.** The model datalist previously appeared after `app.js`, so `syncSettingsUi()` could fail before opening Settings and before model-picker initialization. The DOM ordering and null-safe selector population are corrected.
- **Context recovery remains active.** Context overflow first checkpoints/compacts and retries the same Agent model. A larger-context fallback can take over only when necessary.
- **No-progress/repeated-failure guards remain active.** A failing strategy is redirected/fails over rather than consuming the full recovery budget with identical work.

## Maven build limitation in this environment

Attempted:

```text
./mvnw -DskipTests package
```

Result:

```text
Maven was not found. Bootstrapping Apache Maven 3.9.11...
curl: (6) Could not resolve host: repo.maven.apache.org
```

Therefore this report does **not** claim a complete Spring Boot `clean install` or the full JUnit suite in this sandbox.

## Required validation on your machine

Windows:

```bat
validate-local.bat
mvnw.cmd -Pfull-tests test
```

Linux/macOS:

```bash
./validate-local.sh
./mvnw -Pfull-tests test
```

A successful normal build should produce:

```text
target/advanced-ai-workbench.jar
```
