# User Test Checklist

Use this checklist while testing the packaged build. It focuses on the issues reported for long Agent runs, synchronized plans, history, UI and reusable prompts.

## 1. Plan parsing and progress synchronization

Give the Agent a plan containing numbered steps plus decorative bullets/icons. Approve it.

Expected:
- only real textual steps appear in the approved plan
- decorative symbols do not increase total step count
- progress percentage advances primarily by approved-plan completion, with bounded within-step movement after real tool activity
- live status/phase can change frequently, but the bar never jumps beyond the active approved step

## 2. Strict plan execution

Use a task with at least 5 meaningful plan steps and allow it to edit code.

Expected:
- one active plan step at a time
- retained approved steps are not silently skipped
- code-changing steps require verification before completion
- success is not reported until every approved step completes
- a genuine blocker is shown as blocked rather than false success

## 3. Completed-step details during execution

While later steps are still running, expand earlier completed steps.

Expected:
- `Completed details` remains visible
- evidence from completed steps remains readable while newer activity continues
- live activity is separate from the plan board

## 4. Long-run responsiveness

Run a substantial build/test/migration task with many Agent/tool events and at least one command that runs for more than 15 seconds.

Expected:
- UI continues to move/update
- long foreground command shows periodic `Command still running (...)` activity
- heartbeat/model waiting does not fake completion; real tool activity can make bounded within-step progress
- old activity events are bounded/collapsed rather than growing the DOM indefinitely
- large command output does not cause runaway memory growth; output may contain an explicit truncation marker while preserving beginning/latest tail

## 5. History persistence

Create multiple Agent runs in one conversation, close the application, replace/extract the application folder, then restart.

Expected:
- conversation history remains available
- earlier Agent-run plan/progress/evidence is restored to the corresponding assistant response
- data is stored under `%USERPROFILE%\.advanced-ai-workbench\` on Windows or `~/.advanced-ai-workbench/` on Linux/macOS by default


## Single Agent model and model library

Open Settings and inspect the model library.

Expected:
- Settings opens every time
- Chat model is a working dropdown and can be changed independently
- Agent model is a single working dropdown containing Chat / Agent model entries only
- the Agent screen shows the selected model plus fallback count; there are no separate Analysis/Planning/Validator/Critic selectors
- any model ID can be added, renamed, assigned a type/context window, tested and removed
- execution fallbacks can be added, removed and reordered
- removing the active Agent model is prevented until a replacement is selected
- Chat accepts images only when the selected Chat model is vision-capable
- Agent rejects image input and does not make hidden vision-model calls

## Evidence-first planning with one model

Run the same substantial coding prompt against this Agent and your OpenCode setup using the same model where possible.

Expected:
- UI stages move through Index → Analyse → Plan → Review → Execute → Verify → Complete
- the selected Agent model handles the whole Agent task
- planning is created from live workspace evidence in one primary planning call (one corrective retry only if structured validation is missing)
- the plan is displayed in the formatted plan editor rather than raw model prose
- each plan step has a concrete objective and validation evidence
- before editing an active step, the model receives bounded current contents of the strongest relevant live files; exact unproven methods/signatures are inspected instead of guessed
- the user can edit/reorder/add/remove steps before approval
- compare total duration, model calls, tokens, repeated read/search turns, fallback count and actual task completion with OpenCode

## Older-history recovery

Select several older Chat and Agent conversations, including conversations created before durable Agent activity was available.

Expected:
- selecting an old conversation immediately shows a loading state
- message loading is authoritative; a missing/old project, attachment or run metadata endpoint does not blank the conversation
- older Agent snapshots are attached by assistant-message ID when available and by ordered/timestamp fallback otherwise
- if an old chat truly fails to load, the currently open chat is restored instead of leaving an empty page

## Executor-pool exhaustion and recovery replan

Configure at least two execution models, then use a controlled test endpoint/model setup that makes every executor fail or repeatedly return no actionable progress for the active approved step.

Expected:
- each fallback takes over the same active step; completed steps do not run again
- the UI shows failover count/model changes rather than resetting the plan
- after the executor pool is exhausted, live status enters a recovery-analysis/replan phase
- a recoverable diagnosis creates a new validated plan for **unfinished work only** and restarts execution from the primary executor
- completed-step notes/evidence and valid workspace edits remain present
- recovery replan count is visible and survives history reopen/restart
- a genuine credential/permission/infrastructure blocker stops as `blocked` without futile replanning
- after the bounded recovery-replan limit is reached, the run stops cleanly and does not remain forever in a working state

## 6. Prompt library

Open `Prompt library`.

Expected:
- Java Selenium + TestNG + Cucumber with Playwright MCP prompt
- Playwright framework prompt
- Selenium-to-Playwright migration prompt
- development, bug-fix, testing, CI/CD and framework-analysis prompts
- prompts instruct the Agent to use/create `AGENTS.md` and focused skills when reusable knowledge is discovered

## 7. Agent-resource templates

Inspect `examples/agent-resources/`.

Expected:
- `AGENTS.md`
- `.agents/skills/playwright-mcp-testing/SKILL.md`
- `.agents/skills/selenium-to-playwright/SKILL.md`
- `.agents/skills/framework-quality/SKILL.md`

## 8. Full local validation

Before release use, run:

```bat
validate-local.bat
mvnw.cmd -Pfull-tests test
```

Share any failing console output, screenshot, or unexpected behavior and the exact test scenario used.
