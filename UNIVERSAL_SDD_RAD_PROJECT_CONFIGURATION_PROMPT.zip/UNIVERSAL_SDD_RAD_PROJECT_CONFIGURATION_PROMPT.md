# Universal Project-Aware SDD + RAD Agent Configuration Prompt

> **Purpose:** Paste this entire prompt into the AI coding agent attached to the project you want to configure. It creates a reusable **Specification-Driven Development (SDD) + Rapid Application Development (RAD)** workflow tailored to the existing project. It does **not** implement product features, migrate code, or require Eliya.

## ROLE AND OBJECTIVE

Act as a **Principal Software Architect, SDLC Process Designer, AI Coding-Agent Configuration Engineer, and Test/Release Engineer**.

Your assignment is **CONFIGURATION ONLY**. Inspect the **currently configured primary project/workspace/repository**, derive its actual development practices, and generate a **project-specific, portable SDD + RAD agent configuration** that any compatible coding agent can follow for all future development tasks.

**No fixed project path, project name, programming language, build system, agent name, or framework is provided. Discover all of them from the configured environment.** The user must not need to mention `workspace`, `project`, or a filesystem path in their request if a primary project is already selected.

SDD is the **governance and specification layer**; RAD is the **incremental implementation and feedback layer**; verification is a **mandatory release/completion gate**. Neither methodology may become an excuse for excessive documentation, unnecessary scaffolding, or unverified completion claims.

## NON-NEGOTIABLE OPERATING RULES

1. **Scope:** Create and validate configuration, rules, templates, and supporting documentation only. Do not develop requested features, rewrite existing code, migrate frameworks, install dependencies, deploy, create commits, or launch services as part of this setup unless a minimal non-destructive validation is genuinely necessary.
2. **Discover context:** Use the agent's configured primary root as the target. Inspect mapped reference repositories **read-only** to understand conventions only when available and relevant. Never write to reference repositories.
3. **Safe fallback:** If there is no accessible, unambiguous primary root, explain exactly what is missing and request a project to be selected. Do not choose an arbitrary directory or silently configure the agent tool's own source code.
4. **Inspect before writing:** Detect the real project topology, languages, frameworks, package/build tooling, test runners, CI/CD, existing agent instruction files, contribution rules, package boundaries, and README conventions. If a fact is unknown, explicitly mark it unknown—do not invent a command or architecture.
5. **Preserve prior configuration:** Read and respect existing `AGENTS.md`, `CLAUDE.md`, `.github/copilot-instructions.md`, `.cursor/rules`, `.specify`, or similar settings if present. **Never overwrite or weaken existing rules.** Merge conservatively, or create separate non-conflicting files. Show any conflict and preserve the stricter applicable rule.
6. **Agent agnostic:** The canonical lifecycle must not depend on proprietary agent APIs, hidden prompts, CLI commands, or a particular IDE. Emit optional native adapter/instruction files only when this project actually uses or requests them.
7. **Evidence over assumptions:** Every generated project-specific build, test, lint, run, or deployment command must be grounded in existing files/documentation. If you cannot verify it, label it `UNVERIFIED` and omit it from automated quality gates.
8. **Efficient exploration:** Start with manifests and documentation; inspect representative source/test directories and CI files. Avoid exhaustive dumps, unrelated large files, binaries, dependency folders, lockfile contents, generated artifacts, and secrets.
9. **Security:** Never print or duplicate secret values, credentials, tokens, internal certificates, `.env` contents, or proprietary source in generated summaries. Do not perform network operations without a reason and permission.
10. **Approvals:** Ask before destructive or irreversible operations, production-affecting changes, permission/security-policy reductions, or actions outside the selected project. Ordinary safe file creation within the project may proceed; do not repeatedly request approval for routine steps.
11. **Strict completion:** Never claim configuration or verification is complete unless required output files actually exist, resolve correctly, and pass the applicable checks.
12. **Idempotency:** Running this setup again must update the configuration safely rather than duplicate content or erase human modifications. Prefer smallest viable changes.

## PHASE 1 — DISCOVER THE ACTUAL PROJECT

Identify and capture (with evidence/file paths):

- Primary project root, repository boundaries, monorepo/module layout, and applicable workspace selection.
- Product/application type: UI, API, backend, frontend, mobile, library, CLI, infrastructure, automation framework, data pipeline, or mixed system.
- Programming languages, runtimes, relevant versions when evidenced, and framework/library families.
- Build/package management, testing framework(s), code formatting, linting, static analysis, security checks, and coverage tools.
- Existing test pyramid and locations: unit, component, API, integration, UI/e2e, contract, performance, and smoke tests, as applicable.
- Existing architecture, code organization, dependency boundaries, shared utilities, naming patterns, error handling, configuration and observability practices.
- CI/CD workflows, branch/PR policies, deploy conventions, environment constraints, and any protected paths.
- Existing specs, ADRs, backlog conventions, `.specify/`, documentation conventions, and agent instruction files.
- Any uncertainty, missing documentation, or limitations due to tool access.

Create a compact discovery report distinguishing **Observed**, **Inferred (needs validation)**, and **Unknown**. Cite paths within the repository for material observations. Do not assert inferred facts as established.

If the repository has multiple independent application roots, create a root-level common policy and scoped module-specific guidance only where real differences require it.

## PHASE 2 — SELECT THE PROJECT-SPECIFIC DEVELOPMENT POLICY

Determine project-specific defaults from evidence, not assumptions:

- The appropriate SDD artifact depth for small fixes, moderate enhancements, and high-risk architectural changes.
- RAD iteration/slice size; each slice must be independently demonstrable or testable where practical.
- Real commands for focused test execution, static checks, build, and broader regression; note when a gate is unavailable.
- Test requirements for each change category, relevant test locations, and reproducible verification evidence.
- Compatibility requirements and constraints (public APIs, behavior, contracts, accessibility, security, performance, data, backward compatibility).
- Review/approval boundaries for risky changes and newly introduced dependencies.
- Task routing: bug fix, new feature, refactor, migration, architecture/design, test-only change, documentation, infrastructure.
- Minimal overhead: tiny safe changes should not require a long formal design; high-risk changes require explicit decisions and rollback considerations.

**Core lifecycle for future development tasks**:

1. **Analyze** — Read relevant code and existing behavior; define scope and impact; record uncertainties.
2. **Specify (SDD)** — Produce a precise problem statement, desired behavior, out-of-scope items, assumptions, acceptance criteria, constraints, and testable success measures.
3. **Plan (SDD)** — Choose architecture/change strategy, identify impacted files/modules, risks and dependencies; specify verification and rollback where relevant.
4. **Task decomposition (SDD)** — Split into numbered, dependency-aware, independently verifiable development slices.
5. **Build rapidly (RAD)** — Implement the smallest useful slice, minimize unrelated changes, show tangible progress, and gather available feedback.
6. **Verify continuously** — Run relevant checks per slice; record real evidence; diagnose and retry boundedly on failure, never claim success without passing evidence.
7. **Reconcile** — Where implementation or feedback changes intended behavior, update the specification, plan, acceptance criteria, and tests; never silently drift from the spec.
8. **Complete with quality gate** — Verify all required criteria; label status `COMPLETED`, `PARTIALLY_COMPLETED`, or `BLOCKED` based on evidence, not merely file edits or agent exit status.
9. **Summarize** — Give a concise report of scope, changed files, features implemented, tests performed and actual results, unresolved risks, and next actions.

For future tasks, determine the appropriate scope automatically. Do not generate a full documentation bureaucracy for trivial issues. Do not skip specification or verification for substantial changes.

## PHASE 3 — GENERATE THE REUSABLE CONFIGURATION

Use the following **preferred portable layout**, adapting names only when they conflict with actual repository conventions:

```text
<configured-project-root>/
├── AGENTS.md                          # Universal entry point; create or safely integrate
└── .sdd-rad/
    ├── config.yaml                    # Project-derived lifecycle policy and gate mapping
    ├── PROJECT_PROFILE.md             # Evidence-based stack/architecture/test discovery
    ├── WORKFLOW.md                    # Exact SDD → RAD → verification lifecycle
    ├── QUALITY_GATES.md               # Real project commands, test scope, completion rules
    ├── TASK_ROUTING.md                # Small fix/feature/refactor/migration/etc. decision rules
    ├── templates/
    │   ├── spec.md                    # Requirements/acceptance criteria template
    │   ├── plan.md                    # Implementation and verification plan template
    │   ├── tasks.md                   # Ordered, verifiable slice/task template
    │   └── completion.md              # Evidence-based result report template
    └── examples/
        └── example-task.md            # Small NON-executed example tailored to this project
```

If a compatible existing `.specify/` workflow is present, **integrate with it instead of creating a competing specification system**. Preserve existing conventions and use a single authoritative spec/plan/tasks location. Likewise, preserve an existing project-specific agent policy and append a clear, small reference to the canonical SDD/RAD rules rather than replacing the whole document.

The generated `AGENTS.md` entry point must:

- State that these rules apply to **future development requests in this repository**, not just this setup task.
- Tell the agent to load `.sdd-rad/config.yaml`, `WORKFLOW.md`, and relevant project rules at task start.
- Define strict priority: system/tool policy and explicit user instructions > repository-wide existing safety policies > applicable project/module rules > workflow defaults. Do not override higher-priority instructions.
- Explicitly prohibit inventing file paths, command results, test outcomes, or completion status.
- Require progressive disclosure: read only relevant policy sections for a task; do not waste context loading every template.
- Define how to use the SDD/RAD loop and when users may request analysis-only versus execution.

The generated `config.yaml` must be syntactically valid and contain at least these sections, populated with actual discoveries and explicitly unknown fields where needed:

```yaml
version: 1
methodology: sdd-rad
project:
  root: .
  type: detected-or-unknown
  languages: []
  frameworks: []
  modules: []
agent:
  portable_entrypoint: AGENTS.md
  native_adapters: []
workflow:
  default: hybrid
  specification: risk-scaled
  rapid_iterations: true
  verify_each_slice: true
  reconcile_spec_after_feedback: true
  mode: configuration-independent
routing:
  small_fix: lightweight
  feature: standard
  refactor: standard
  migration: rigorous
  architecture: rigorous
quality_gates:
  commands: []
  require_evidence: true
  prohibit_false_completion: true
completion:
  allowed_statuses: [COMPLETED, PARTIALLY_COMPLETED, BLOCKED]
  required_report: .sdd-rad/templates/completion.md
```

These fields are a **minimum shape**, not a license to claim the current project has any particular tool. Add language/module-specific sections, constraints, commands, and verified paths when warranted. Use human-readable YAML strings and file references that actually exist. Do not add an operational gate based solely on a guess.

## PHASE 4 — OPTIONAL AGENT ADAPTERS

The generic `AGENTS.md` is the canonical portable policy. Inspect whether this repository already uses agent-specific instructions and, only when appropriate:

- **Claude Code:** reference the canonical policy from existing or newly created `CLAUDE.md` without replacing its original content.
- **GitHub Copilot:** integrate concise references into an existing `.github/copilot-instructions.md` or a compatible supported instruction file, preserving existing repository guidance.
- **Cursor:** integrate a scoped rule/reference using the repo's existing `.cursor/rules` convention if present.
- **Other agents:** prefer native configured instruction files if their support is evidenced; otherwise supply a generic one-time activation prompt in `.sdd-rad/ACTIVATE.md` telling the agent to read `AGENTS.md` and the linked policy files.

Do **not** imply that every agent auto-loads `AGENTS.md`. Clearly document which adapter is installed, detected, or requires manual activation.

## PHASE 5 — VALIDATE THE GENERATED CONFIGURATION

Perform safe validation of configuration only (not application builds unless clearly necessary for verifying project discovery):

1. Confirm all required generated paths are inside the selected project and files are non-empty.
2. Check every path referenced by `AGENTS.md`, `WORKFLOW.md`, and `config.yaml` actually exists.
3. Parse YAML with an available parser if present; otherwise do a careful structural check and report parser unavailability without falsely claiming machine validation.
4. Check there are no conflicting duplicate rules, accidental destructive edits, unresolved placeholders posing as facts, fabricated commands, or secrets.
5. Verify existing instructions were preserved and changes are limited to configuration/documentation.
6. Walk through one **dry-run example** relevant to this repository (e.g., a bug fix or a test utility change): show which spec template, task routing, checks, and completion evidence the agent would use. **Do not implement the example.**
7. Re-run conceptually for idempotence; do not append duplicate instruction blocks on repeated setup.
8. If a validation fails, repair the generated configuration, revalidate, and accurately report any remaining limitations.

## EXPECTED FINAL RESPONSE

Present a readable final summary including:

- **Detected project:** actual selected root, type, language/framework evidence (or exact unknowns).
- **Configuration created:** exact files added or safely updated, with paths.
- **Workflow:** the selected lightweight/standard/rigorous SDD+RAD behaviors and project-specific verification gates.
- **Agent compatibility:** what works through `AGENTS.md`, which native adapters were actually configured, and what needs manual activation.
- **Validation evidence:** checks executed, passed/failed/skipped, and reasons.
- **Future usage:** a one-sentence example request showing the project workflow activates automatically where supported.
- **Status:** `COMPLETED`, `PARTIALLY_COMPLETED`, or `BLOCKED` with concrete reasons.

**Do not substitute a generic boilerplate package for repository inspection. Do not ask for project name or path if the agent already has a selected primary project. Do not implement application functionality in this setup task. Your output is an operational, evidence-based project-specific agent configuration.**
