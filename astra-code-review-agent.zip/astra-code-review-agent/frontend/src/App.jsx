import React, { useMemo, useRef, useState } from 'react';
import { Folder, FilePlus, Play, Pause, Square, ChevronDown, ChevronRight, Copy, Bot, ShieldAlert, FileCode2, Gauge, Moon } from 'lucide-react';

const API_BASE = 'http://localhost:8090';

function severityRank(sev) {
  return { CRITICAL: 0, MAJOR: 1, MINOR: 2, GOOD_TO_HAVE: 3, PASSED: 4 }[sev] ?? 5;
}

function severityClass(sev) {
  return String(sev || '').toLowerCase().replaceAll('_', '-');
}

function App() {
  const [files, setFiles] = useState([]);
  const [results, setResults] = useState({});
  const [statuses, setStatuses] = useState({});
  const [expanded, setExpanded] = useState(null);
  const [reviewId, setReviewId] = useState(null);
  const [currentFile, setCurrentFile] = useState('-');
  const [currentStep, setCurrentStep] = useState('Waiting for review');
  const [running, setRunning] = useState(false);
  const [completed, setCompleted] = useState(0);
  const [total, setTotal] = useState(0);
  const [activeTab, setActiveTab] = useState('FILES');
  const [source, setSource] = useState('SELECTED');
  const fileInput = useRef(null);
  const folderInput = useRef(null);

  const counts = useMemo(() => {
    const vals = Object.values(results);
    return {
      critical: vals.filter(r => r.severity === 'CRITICAL').length,
      major: vals.filter(r => r.severity === 'MAJOR').length,
      minor: vals.filter(r => r.severity === 'MINOR').length,
      good: vals.filter(r => r.severity === 'GOOD_TO_HAVE').length,
      passed: vals.filter(r => r.severity === 'PASSED').length
    };
  }, [results]);

  const queued = Math.max((total || files.length) - completed - (running ? 1 : 0), 0);
  const progress = total ? Math.round((completed / total) * 100) : 0;

  function addSelected(e) {
    const selected = Array.from(e.target.files || []);
    const mapped = selected.map(f => ({ file: f, path: f.webkitRelativePath || f.name, name: f.name }));
    setFiles(prev => dedupe([...prev, ...mapped]));
    e.target.value = '';
  }

  function dedupe(list) {
    const seen = new Set();
    return list.filter(item => {
      const key = item.path;
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    });
  }

  function removeFile(path) {
    setFiles(prev => prev.filter(f => f.path !== path));
    setResults(prev => {
      const cp = { ...prev };
      delete cp[path];
      return cp;
    });
  }

  async function startReview() {
    if (!files.length) return alert('Please select files or folder first.');
    setResults({});
    setStatuses({});
    setCompleted(0);
    setTotal(files.length);
    setRunning(true);
    setCurrentFile('-');
    setCurrentStep('Uploading files to local review agent');

    const form = new FormData();
    files.forEach(f => {
      form.append('files', f.file, f.name);
      form.append('paths', f.path);
    });

    const response = await fetch(`${API_BASE}/api/review/start`, { method: 'POST', body: form });
    const data = await response.json();
    setReviewId(data.reviewId);
    setTotal(data.totalFiles);
    openStream(data.reviewId);
  }

  function openStream(id) {
    const es = new EventSource(`${API_BASE}/api/review/stream/${id}`);
    es.addEventListener('review-event', (event) => {
      const payload = JSON.parse(event.data);
      handleEvent(payload, es);
    });
    es.onerror = () => {
      es.close();
      setRunning(false);
    };
  }

  function handleEvent(payload, es) {
    if (payload.eventType === 'FILE_STARTED') {
      setCurrentFile(payload.fileName);
      setCurrentStep(payload.message);
      setStatuses(prev => ({ ...prev, [payload.fileName]: 'RUNNING' }));
      return;
    }
    if (payload.eventType === 'RULE_CHECK_RUNNING' || payload.eventType === 'RULE_CHECK_COMPLETED' || payload.eventType === 'LLM_REVIEW_RUNNING') {
      setCurrentFile(payload.fileName || '-');
      setCurrentStep(payload.message || payload.eventType);
      return;
    }
    if (payload.eventType === 'FILE_COMPLETED') {
      setCompleted(payload.completedFiles);
      setCurrentStep(`${payload.fileName} completed. Comments available now.`);
      setResults(prev => ({ ...prev, [payload.filePath]: payload, [payload.fileName]: payload }));
      setStatuses(prev => ({ ...prev, [payload.fileName]: 'COMPLETED', [payload.filePath]: 'COMPLETED' }));
      if (!expanded) setExpanded(payload.filePath);
      return;
    }
    if (payload.eventType === 'REVIEW_COMPLETED') {
      setCompleted(payload.completedFiles || total);
      setCurrentFile('-');
      setCurrentStep('All files completed');
      setRunning(false);
      es?.close?.();
      return;
    }
  }

  function fileStatus(item) {
    return statuses[item.path] || statuses[item.name] || 'QUEUED';
  }

  function fileResult(item) {
    return results[item.path] || results[item.name];
  }

  function copy(text) {
    navigator.clipboard.writeText(text || '');
  }

  const selectedResult = expanded ? (results[expanded] || Object.values(results).find(r => r.filePath === expanded || r.fileName === expanded)) : null;

  return <div className="app">
    <aside className="sidebar">
      <div className="brand"><div className="logo">A</div><div><b>ASTRA</b><span>Code Review Agent</span></div></div>
      <nav>
        <a className="active">Dashboard</a><a>Review History</a><a>Rules & Checks</a><a>AI Profiles</a><a>Settings</a><a>Reports</a>
      </nav>
      <div className="agent-card"><Bot size={25}/><b>Astra Agent</b><p>AI-powered local pre-PR review for developers and QA.</p></div>
      <div className="theme"><Moon size={18}/> Dark <span></span></div>
      <div className="user"><div>SA</div><section><b>Siva Admin</b><p>Local Mode</p></section></div>
    </aside>

    <main>
      <header>
        <section><h1>ASTRA <span>CODE REVIEW AGENT</span></h1><small>v1.0.0</small></section>
        <div className="actions"><button className="status"><span></span>{running ? 'Review in Progress' : 'Ready'}</button><button><Pause size={16}/>Pause</button><button><Square size={15}/>Stop</button></div>
      </header>

      <div className="content">
        <section className="left-panel panel">
          <h3>START NEW REVIEW</h3>
          <label>Review Source</label>
          <div className="source-grid">
            <button className={source === 'FOLDER' ? 'selected' : ''} onClick={() => {setSource('FOLDER'); folderInput.current.click();}}><Folder/>Full Project Folder</button>
            <button className={source === 'SELECTED' ? 'selected' : ''} onClick={() => {setSource('SELECTED'); fileInput.current.click();}}><FilePlus/>Selected Files</button>
          </div>
          <input ref={fileInput} type="file" multiple hidden onChange={addSelected}/>
          <input ref={folderInput} type="file" multiple hidden webkitdirectory="true" directory="true" onChange={addSelected}/>

          <div className="selected-title"><b>Selected Files ({files.length})</b><button onClick={() => fileInput.current.click()}>+ Add File</button></div>
          <div className="selected-files">
            {files.map(f => <div className="selected-file" key={f.path}><FileCode2 size={17}/><section><b>{f.name}</b><p>{f.path}</p></section><button onClick={() => removeFile(f.path)}>×</button></div>)}
            {!files.length && <p className="empty">Select a folder or add changed files for review.</p>}
          </div>

          <h4>Review Configuration</h4>
          <div className="config-grid">
            <label>Review Role<select><option>Auto Detect</option><option>Developer</option><option>QA Automation</option></select></label>
            <label>Developer Type<select><option>Auto Detect</option><option>Frontend</option><option>Backend</option><option>Full Stack</option></select></label>
            <label>Review Depth<select><option>PR Readiness</option><option>Standard</option><option>Deep</option></select></label>
            <label>Output Style<select><option>Detailed</option><option>PR Comments</option></select></label>
          </div>
          <button className="start" disabled={running} onClick={startReview}><Play size={18}/> Start Review</button>
        </section>

        <section className="main-panel">
          <div className="panel progress-panel">
            <div className="metric-row">
              <Metric value={total || files.length} label="Total Files" tone="blue" />
              <Metric value={completed} label="Completed" tone="green" />
              <Metric value={running ? 1 : 0} label="Running" tone="blue" />
              <Metric value={queued} label="In Queue" tone="yellow" />
              <Metric value={counts.critical} label="Critical" tone="red" />
              <Metric value={counts.major} label="Major" tone="orange" />
              <Metric value={counts.minor} label="Minor" tone="yellow" />
              <Metric value={counts.good} label="Good to Have" tone="cyan" />
            </div>
            <div className="progress-text"><b>Overall Progress</b><span>{progress}%</span></div>
            <div className="bar"><div style={{width: `${progress}%`}}></div></div>
            <p>Current File: <b>{currentFile}</b></p>
            <p>Current Step: <span>{currentStep}</span></p>
          </div>

          <div className="review-grid">
            <div className="panel file-table">
              <div className="tabs"><button className={activeTab==='FILES'?'active':''} onClick={()=>setActiveTab('FILES')}>FILES ({files.length})</button><button>SUMMARY</button><button>ISSUES</button><button>COMMENTS</button><button>REPORT</button></div>
              <div className="table-head"><span>File Name</span><span>Status</span><span>Severity</span><span>Score</span></div>
              <div className="rows">
                {files.map(item => {
                  const r = fileResult(item);
                  const st = fileStatus(item);
                  const open = expanded === item.path;
                  return <div className={`row ${st.toLowerCase()} ${open ? 'open' : ''}`} key={item.path} onClick={() => r && setExpanded(item.path)}>
                    <section><FileCode2 size={22}/><div><b>{item.name}</b><p>{item.path}</p></div></section>
                    <span className={`pill ${st.toLowerCase()}`}>{st}</span>
                    <span className={`pill ${severityClass(r?.severity)}`}>{r?.severity || '-'}</span>
                    <span>{r?.score ? `${r.score}/100` : '-'}</span>
                  </div>
                })}
              </div>
            </div>

            <div className="panel details-panel">
              {selectedResult ? <ResultDetails result={selectedResult} copy={copy}/> : <div className="placeholder"><Gauge size={40}/><h3>No completed file selected</h3><p>As soon as file 1 completes, its comments appear here while the next file continues running.</p></div>}
            </div>
          </div>
        </section>
      </div>
    </main>
  </div>
}

function Metric({value, label, tone}) { return <div className={`metric ${tone}`}><b>{value}</b><span>{label}</span></div> }

function ResultDetails({result, copy}) {
  const [issueOpen, setIssueOpen] = useState(0);
  const pr = result.comments?.map(c => `- [${c.severity}] ${result.filePath}${c.lineNumber ? ':' + c.lineNumber : ''} - ${c.prComment}`).join('\n') || '';
  const sorted = [...(result.comments || [])].sort((a,b)=>severityRank(a.severity)-severityRank(b.severity));
  return <>
    <div className="details-header"><section><FileCode2 size={18}/><b>{result.fileName}</b><span className="pill completed">COMPLETED</span></section><span>{result.fileIndex} of {result.totalFiles}</span></div>
    <div className="subtabs"><button className="active">DETAILS</button><button>ISSUES ({result.comments?.length || 0})</button><button>CODE SNIPPETS</button><button>PR COMMENT</button></div>
    <h4>Summary</h4><p>{result.summary}</p>
    <div className="score-box"><div><span>Severity</span><b className={severityClass(result.severity)}>{result.severity}</b></div><div><span>Category</span><b>{result.reviewType}</b></div><div><span>Score</span><b>{result.score}/100</b></div><div><span>File</span><b>{result.filePath}</b></div></div>
    <h4>Issues</h4>
    <div className="issues">
      {sorted.map((i, idx) => <div className={`issue ${severityClass(i.severity)}`} key={idx}>
        <div className="issue-title" onClick={() => setIssueOpen(issueOpen === idx ? -1 : idx)}><span>{idx+1}</span><b>{i.whatIsWrong}</b><em>Line: {i.lineNumber || '-'}</em><label>{i.severity}</label>{issueOpen===idx?<ChevronDown/>:<ChevronRight/>}</div>
        {issueOpen === idx && <div className="issue-body"><p><b>Why it matters:</b> {i.whyItMatters}</p><p><b>What to change:</b> {i.whatNeedsToBeChanged}</p>{i.suggestedCode && <pre>{i.suggestedCode}</pre>}<p><b>PR Comment:</b> {i.prComment}</p></div>}
      </div>)}
      {!sorted.length && <div className="passed"><ShieldAlert/> No major issue found.</div>}
    </div>
    <h4>PR Comment</h4><div className="pr"><pre>{pr}</pre><button onClick={() => copy(pr)}><Copy size={14}/>Copy</button></div>
  </>
}

export default App;
