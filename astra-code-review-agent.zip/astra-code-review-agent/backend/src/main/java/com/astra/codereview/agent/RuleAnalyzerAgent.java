package com.astra.codereview.agent;

import com.astra.codereview.model.ReviewFile;
import com.astra.codereview.model.ReviewIssue;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

@Component
public class RuleAnalyzerAgent {
    private static final Pattern SECRET_PATTERN = Pattern.compile("(?i).*(api[-_.]?key|password|secret|token)\\s*=\\s*(?!\\$\\{).{8,}.*");

    public List<ReviewIssue> analyze(ReviewFile file) {
        List<ReviewIssue> issues = new ArrayList<>();
        String[] lines = file.content.split("\\R");
        for (int i = 0; i < lines.length; i++) {
            String line = lines[i];
            int lineNo = i + 1;

            if (SECRET_PATTERN.matcher(line.trim()).matches()) {
                issues.add(new ReviewIssue("CRITICAL", "Security", lineNo,
                        "A secret-like value appears to be hardcoded.",
                        "Secrets can leak through Git, screenshots, logs, or shared files.",
                        "Move this value to environment variables, Key Vault, or a local ignored secret file.",
                        "llm.api-key=${LLM_API_KEY}",
                        "Please remove the hardcoded secret and load it from a secure external source."));
            }
            if (line.contains("Thread.sleep")) {
                issues.add(new ReviewIssue("MAJOR", "Test Stability", lineNo,
                        "Hard wait is used.",
                        "Hard waits make automation slow and flaky.",
                        "Use explicit waits or condition-based wait utilities.",
                        "wait.until(ExpectedConditions.visibilityOf(element));",
                        "Please replace Thread.sleep with an explicit wait."));
            }
            if (line.contains("System.out.println")) {
                issues.add(new ReviewIssue("MINOR", "Logging", lineNo,
                        "System.out.println is used.",
                        "Console prints are not suitable for production-grade diagnostics.",
                        "Use a logger with appropriate levels and masking.",
                        "private static final Logger log = LoggerFactory.getLogger(CurrentClass.class);",
                        "Please replace System.out.println with structured logging."));
            }
            if (line.contains("@RequestBody String")) {
                issues.add(new ReviewIssue("MAJOR", "API Design", lineNo,
                        "Controller accepts raw String request body.",
                        "This weakens API contract, validation, and future extensibility.",
                        "Create request/response DTOs and add validation.",
                        "public record ChatRequest(@NotBlank String message) {}",
                        "Please replace raw String request body with a validated DTO."));
            }
            if (line.contains(".temperature(") || line.contains(".maxTokens(")) {
                issues.add(new ReviewIssue("GOOD_TO_HAVE", "Configuration", lineNo,
                        "LLM runtime parameter is hardcoded.",
                        "Different environments may need different temperature or token settings.",
                        "Move the value to application properties with defaults.",
                        "llm.max-tokens=${LLM_MAX_TOKENS:1600}",
                        "Consider externalizing LLM runtime parameters."));
            }
        }
        return issues;
    }
}
