package com.astra.codereview.controller;

import com.astra.codereview.agent.FileTypeDetectorAgent;
import com.astra.codereview.agent.ReviewOrchestratorAgent;
import com.astra.codereview.agent.ReviewProgressAgent;
import com.astra.codereview.model.ReviewFile;
import com.astra.codereview.model.ReviewStartResponse;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

import java.nio.charset.StandardCharsets;
import java.util.*;

@RestController
@RequestMapping("/api/review")
public class ReviewController {
    private final FileTypeDetectorAgent detector;
    private final ReviewOrchestratorAgent orchestrator;
    private final ReviewProgressAgent progressAgent;

    public ReviewController(FileTypeDetectorAgent detector, ReviewOrchestratorAgent orchestrator, ReviewProgressAgent progressAgent) {
        this.detector = detector;
        this.orchestrator = orchestrator;
        this.progressAgent = progressAgent;
    }

    @PostMapping(value = "/start", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ReviewStartResponse startReview(@RequestPart("files") MultipartFile[] files,
                                           @RequestParam(value = "paths", required = false) List<String> paths) throws Exception {
        String reviewId = "REV-" + System.currentTimeMillis();
        List<ReviewFile> reviewFiles = new ArrayList<>();

        for (int i = 0; i < files.length; i++) {
            MultipartFile f = files[i];
            String path = paths != null && i < paths.size() ? paths.get(i) : f.getOriginalFilename();
            if (!isEligible(path)) continue;
            String content = new String(f.getBytes(), StandardCharsets.UTF_8);
            String type = detector.detectType(path);
            String persona = detector.personaFor(type);
            reviewFiles.add(new ReviewFile(f.getOriginalFilename(), path, content, type, persona));
        }

        orchestrator.startReview(reviewId, reviewFiles);
        return new ReviewStartResponse(reviewId, reviewFiles.size(), "STARTED");
    }

    @GetMapping(value = "/stream/{reviewId}", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
    public SseEmitter stream(@PathVariable String reviewId) {
        return progressAgent.register(reviewId);
    }

    private boolean isEligible(String path) {
        if (path == null) return false;
        String p = path.toLowerCase().replace("\\", "/");
        if (p.contains("/target/") || p.contains("/node_modules/") || p.contains("/.git/") || p.contains("/.idea/")
                || p.contains("/build/") || p.contains("/dist/") || p.contains("/coverage/")) return false;
        return p.endsWith(".java") || p.endsWith(".xml") || p.endsWith(".properties") || p.endsWith(".yml") || p.endsWith(".yaml")
                || p.endsWith(".json") || p.endsWith(".feature") || p.endsWith(".ts") || p.endsWith(".tsx") || p.endsWith(".js")
                || p.endsWith(".jsx") || p.endsWith(".html") || p.endsWith(".css") || p.endsWith(".scss") || p.endsWith(".tf")
                || p.endsWith(".ps1") || p.endsWith("jenkinsfile") || p.endsWith("dockerfile");
    }
}
