package com.astra.codereview.agent;

import org.springframework.stereotype.Component;

@Component
public class FileTypeDetectorAgent {
    public String detectType(String path) {
        String p = path.toLowerCase();
        if (p.endsWith("application.properties") || p.endsWith(".yml") || p.endsWith(".yaml")) return "CONFIG_SECURITY";
        if (p.endsWith("pom.xml") || p.endsWith("build.gradle") || p.endsWith("package.json")) return "DEPENDENCY";
        if (p.endsWith(".feature")) return "BDD_FEATURE";
        if (p.endsWith(".tf")) return "TERRAFORM";
        if (p.endsWith(".ps1")) return "POWERSHELL";
        if (p.endsWith(".tsx") || p.endsWith(".jsx") || p.endsWith(".ts") || p.endsWith(".js") || p.endsWith(".html") || p.endsWith(".css")) return "FRONTEND";
        if (p.contains("/test/") || p.contains("\\test\\") || p.contains("page") || p.contains("test")) return "QA_AUTOMATION";
        if (p.contains("controller") && p.endsWith(".java")) return "BACKEND_CONTROLLER";
        if (p.contains("service") && p.endsWith(".java")) return "BACKEND_SERVICE";
        if (p.contains("repository") && p.endsWith(".java")) return "BACKEND_REPOSITORY";
        if (p.endsWith(".java")) return "BACKEND_JAVA";
        return "GENERAL";
    }

    public String personaFor(String fileType) {
        return switch (fileType) {
            case "CONFIG_SECURITY" -> "SECURITY_CONFIG_REVIEWER";
            case "DEPENDENCY" -> "DEPENDENCY_REVIEWER";
            case "BDD_FEATURE" -> "BDD_QA_REVIEWER";
            case "TERRAFORM" -> "DEVOPS_TERRAFORM_REVIEWER";
            case "POWERSHELL" -> "POWERSHELL_AUTOMATION_REVIEWER";
            case "FRONTEND" -> "FRONTEND_REVIEWER";
            case "QA_AUTOMATION" -> "QA_AUTOMATION_REVIEWER";
            case "BACKEND_CONTROLLER" -> "BACKEND_API_REVIEWER";
            case "BACKEND_SERVICE" -> "SERVICE_LAYER_REVIEWER";
            case "BACKEND_REPOSITORY", "BACKEND_JAVA" -> "BACKEND_REVIEWER";
            default -> "GENERAL_CODE_REVIEWER";
        };
    }
}
