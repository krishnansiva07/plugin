package com.astra.codereview;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableAsync;

@EnableAsync
@SpringBootApplication
public class AstraCodeReviewApplication {
    public static void main(String[] args) {
        SpringApplication.run(AstraCodeReviewApplication.class, args);
    }
}
