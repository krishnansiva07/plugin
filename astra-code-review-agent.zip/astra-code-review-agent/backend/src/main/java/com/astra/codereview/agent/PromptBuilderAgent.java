package com.astra.codereview.agent;

import com.astra.codereview.model.ReviewFile;
import com.astra.codereview.model.ReviewIssue;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class PromptBuilderAgent {
    public String buildPrompt(ReviewFile file, List<ReviewIssue> ruleIssues) {
        String clipped = file.content.length() > 16000 ? file.content.substring(0, 16000) + "\n// clipped for review" : file.content;
        StringBuilder ruleText = new StringBuilder();
        for (ReviewIssue issue : ruleIssues) {
            ruleText.append("- ").append(issue.severity).append(" | ").append(issue.category)
                    .append(" | line ").append(issue.lineNumber).append(" | ").append(issue.whatIsWrong).append("\n");
        }
        if (ruleText.isEmpty()) ruleText.append("None\n");

        return """
                You are ASTRA CODE REVIEW AGENT.

                Review Persona: %s
                File Type: %s
                File Path: %s

                Existing deterministic rule findings:
                %s

                Review instructions:
                1. Review only this file.
                2. Focus on practical pre-PR review comments for developer/QA.
                3. Do not repeat deterministic findings unless you improve them.
                4. Classify severity as CRITICAL, MAJOR, MINOR, GOOD_TO_HAVE.
                5. Return only valid JSON. No markdown.

                Required JSON format:
                {
                  "fileSummary": "short practical summary",
                  "score": 0,
                  "highestSeverity": "CRITICAL|MAJOR|MINOR|GOOD_TO_HAVE|PASSED",
                  "comments": [
                    {
                      "severity": "MAJOR",
                      "category": "API Design",
                      "lineNumber": 12,
                      "whatIsWrong": "...",
                      "whyItMatters": "...",
                      "whatNeedsToBeChanged": "...",
                      "suggestedCode": "...",
                      "prComment": "..."
                    }
                  ]
                }

                File content:
                ```
                %s
                ```
                """.formatted(file.persona, file.fileType, file.relativePath, ruleText, clipped);
    }
}
