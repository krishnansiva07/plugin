package com.astra.codereview.model;

import java.util.ArrayList;
import java.util.List;

public class FileReviewResult {
    public String eventType = "FILE_COMPLETED";
    public String fileName;
    public String filePath;
    public int fileIndex;
    public int totalFiles;
    public int completedFiles;
    public int queuedFiles;
    public String status = "COMPLETED";
    public String severity;
    public int score;
    public String summary;
    public String reviewType;
    public List<ReviewIssue> comments = new ArrayList<>();
}
