package com.astra.codereview.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

@Configuration
public class LlmProperties {
    @Value("${llm.api-key:}")
    public String apiKey;

    @Value("${llm.base-url}")
    public String baseUrl;

    @Value("${llm.model-name}")
    public String modelName;

    @Value("${llm.temperature:0.2}")
    public double temperature;

    @Value("${llm.max-tokens:1600}")
    public int maxTokens;

    @Value("${llm.mock-mode:true}")
    public boolean mockMode;
}
