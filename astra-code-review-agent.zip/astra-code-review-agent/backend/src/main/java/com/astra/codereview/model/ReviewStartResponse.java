package com.astra.codereview.model;

public class ReviewStartResponse {
    public String reviewId;
    public int totalFiles;
    public String status;

    public ReviewStartResponse(String reviewId, int totalFiles, String status) {
        this.reviewId = reviewId;
        this.totalFiles = totalFiles;
        this.status = status;
    }
}
