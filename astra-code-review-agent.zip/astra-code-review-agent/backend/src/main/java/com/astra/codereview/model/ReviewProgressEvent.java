package com.astra.codereview.model;

public class ReviewProgressEvent {
    public String eventType;
    public String reviewId;
    public String fileName;
    public int fileIndex;
    public int totalFiles;
    public int completedFiles;
    public int queuedFiles;
    public String status;
    public String message;

    public static ReviewProgressEvent of(String eventType, String reviewId, String fileName, int fileIndex,
                                         int totalFiles, int completedFiles, int queuedFiles, String status, String message) {
        ReviewProgressEvent event = new ReviewProgressEvent();
        event.eventType = eventType;
        event.reviewId = reviewId;
        event.fileName = fileName;
        event.fileIndex = fileIndex;
        event.totalFiles = totalFiles;
        event.completedFiles = completedFiles;
        event.queuedFiles = queuedFiles;
        event.status = status;
        event.message = message;
        return event;
    }
}
