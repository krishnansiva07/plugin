package com.astra.codereview.agent;

import com.astra.codereview.config.LlmProperties;
import com.astra.codereview.model.ReviewFile;
import com.astra.codereview.model.ReviewIssue;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;

import java.time.Duration;
import java.util.*;

@Component
public class LlmReviewerAgent {
    private final LlmProperties props;
    private final PromptBuilderAgent promptBuilder;
    private final ObjectMapper mapper = new ObjectMapper();
    private final WebClient webClient = WebClient.builder().build();

    public LlmReviewerAgent(LlmProperties props, PromptBuilderAgent promptBuilder) {
        this.props = props;
        this.promptBuilder = promptBuilder;
    }

    public LlmResult review(ReviewFile file, List<ReviewIssue> ruleIssues) {
        if (props.mockMode || props.apiKey == null || props.apiKey.isBlank()) {
            return mockReview(file, ruleIssues);
        }
        try {
            String prompt = promptBuilder.buildPrompt(file, ruleIssues);
            Map<String, Object> body = new LinkedHashMap<>();
            body.put("model", props.modelName);
            body.put("temperature", props.temperature);
            body.put("max_tokens", props.maxTokens);
            body.put("messages", List.of(
                    Map.of("role", "system", "content", "You are a strict code review agent. Return only valid JSON."),
                    Map.of("role", "user", "content", prompt)
            ));

            String response = webClient.post()
                    .uri(props.baseUrl.replaceAll("/$", "") + "/chat/completions")
                    .header(HttpHeaders.AUTHORIZATION, "Bearer " + props.apiKey)
                    .contentType(MediaType.APPLICATION_JSON)
                    .bodyValue(body)
                    .retrieve()
                    .bodyToMono(String.class)
                    .timeout(Duration.ofSeconds(60))
                    .block();

            JsonNode root = mapper.readTree(response);
            String content = root.at("/choices/0/message/content").asText();
            return parseLlmJson(content);
        } catch (Exception ex) {
            LlmResult fallback = mockReview(file, ruleIssues);
            fallback.comments.add(new ReviewIssue("GOOD_TO_HAVE", "LLM Fallback", null,
                    "LLM review failed or returned invalid output.",
                    "The tool can still show deterministic rule findings, but LLM enrichment was not completed.",
                    "Check LLM base URL, API key, model name, or enable mock mode for local demos.",
                    "LLM_MOCK_MODE=true", "LLM call failed. Please verify LLM configuration."));
            return fallback;
        }
    }

    private LlmResult parseLlmJson(String content) throws Exception {
        String json = content.trim();
        if (json.startsWith("```")) {
            json = json.replaceFirst("^```json", "").replaceFirst("^```", "").replaceFirst("```$", "").trim();
        }
        JsonNode node = mapper.readTree(json);
        LlmResult result = new LlmResult();
        result.fileSummary = node.path("fileSummary").asText("LLM review completed.");
        result.score = node.path("score").asInt(75);
        result.highestSeverity = node.path("highestSeverity").asText("MINOR");
        JsonNode comments = node.path("comments");
        if (comments.isArray()) {
            for (JsonNode c : comments) {
                ReviewIssue issue = new ReviewIssue();
                issue.severity = c.path("severity").asText("MINOR");
                issue.category = c.path("category").asText("Code Quality");
                issue.lineNumber = c.path("lineNumber").isMissingNode() || c.path("lineNumber").isNull() ? null : c.path("lineNumber").asInt();
                issue.whatIsWrong = c.path("whatIsWrong").asText("");
                issue.whyItMatters = c.path("whyItMatters").asText("");
                issue.whatNeedsToBeChanged = c.path("whatNeedsToBeChanged").asText("");
                issue.suggestedCode = c.path("suggestedCode").asText("");
                issue.prComment = c.path("prComment").asText("");
                result.comments.add(issue);
            }
        }
        return result;
    }

    private LlmResult mockReview(ReviewFile file, List<ReviewIssue> ruleIssues) {
        LlmResult result = new LlmResult();
        result.fileSummary = "Mock LLM review completed for " + file.fileName + ".";
        result.score = Math.max(40, 90 - ruleIssues.size() * 12);
        result.highestSeverity = ruleIssues.stream().anyMatch(i -> "CRITICAL".equals(i.severity)) ? "CRITICAL" :
                ruleIssues.stream().anyMatch(i -> "MAJOR".equals(i.severity)) ? "MAJOR" :
                        ruleIssues.isEmpty() ? "PASSED" : "MINOR";

        if (file.fileType.contains("CONTROLLER") && ruleIssues.stream().noneMatch(i -> "API Design".equals(i.category))) {
            result.comments.add(new ReviewIssue("GOOD_TO_HAVE", "API Design", null,
                    "Controller is simple but API contract can be improved.",
                    "A structured request and response improves validation and future extension.",
                    "Use DTOs and a consistent response wrapper.",
                    "public record ChatResponse(String answer, String status) {}",
                    "Consider returning a structured response DTO instead of plain text."));
        }
        if (file.fileType.contains("SERVICE")) {
            result.comments.add(new ReviewIssue("MAJOR", "Reliability", null,
                    "Service directly calls external LLM without visible error handling.",
                    "LLM/API failures can produce unclear 500 errors.",
                    "Add try/catch, timeout, logging, and meaningful failure response.",
                    "try { return chatModel.generate(userMessage); } catch (Exception ex) { ... }",
                    "Please add exception handling around the external LLM call."));
        }
        return result;
    }

    public static class LlmResult {
        public String fileSummary;
        public int score;
        public String highestSeverity;
        public List<ReviewIssue> comments = new ArrayList<>();
    }
}
