package com.astra.codereview.agent;

import com.astra.codereview.model.*;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class ReviewOrchestratorAgent {
    private final RuleAnalyzerAgent ruleAnalyzer;
    private final LlmReviewerAgent llmReviewer;
    private final ReviewProgressAgent progressAgent;

    public ReviewOrchestratorAgent(RuleAnalyzerAgent ruleAnalyzer, LlmReviewerAgent llmReviewer, ReviewProgressAgent progressAgent) {
        this.ruleAnalyzer = ruleAnalyzer;
        this.llmReviewer = llmReviewer;
        this.progressAgent = progressAgent;
    }

    @Async
    public void startReview(String reviewId, List<ReviewFile> files) {
        int total = files.size();
        progressAgent.publish(reviewId, ReviewProgressEvent.of("REVIEW_STARTED", reviewId, null, 0, total, 0, total, "STARTED", "Review started"));

        int completed = 0;
        for (int i = 0; i < files.size(); i++) {
            ReviewFile file = files.get(i);
            int index = i + 1;
            int queued = total - completed - 1;

            progressAgent.publish(reviewId, ReviewProgressEvent.of("FILE_STARTED", reviewId, file.fileName, index, total, completed, queued, "RUNNING", "Review started for " + file.fileName));
            sleepSmall();

            progressAgent.publish(reviewId, ReviewProgressEvent.of("RULE_CHECK_RUNNING", reviewId, file.fileName, index, total, completed, queued, "RUNNING", "Rule analyzer is checking deterministic issues"));
            List<ReviewIssue> ruleIssues = ruleAnalyzer.analyze(file);
            progressAgent.publish(reviewId, ReviewProgressEvent.of("RULE_CHECK_COMPLETED", reviewId, file.fileName, index, total, completed, queued, "RUNNING", "Rule check completed. Issues found: " + ruleIssues.size()));
            sleepSmall();

            progressAgent.publish(reviewId, ReviewProgressEvent.of("LLM_REVIEW_RUNNING", reviewId, file.fileName, index, total, completed, queued, "RUNNING", "LLM reviewer is checking practical pre-PR comments"));
            LlmReviewerAgent.LlmResult llm = llmReviewer.review(file, ruleIssues);

            completed++;
            FileReviewResult result = buildResult(file, index, total, completed, total - completed, ruleIssues, llm);
            progressAgent.publish(reviewId, result);
        }

        progressAgent.publish(reviewId, ReviewProgressEvent.of("REVIEW_COMPLETED", reviewId, null, total, total, total, 0, "COMPLETED", "All files completed"));
        progressAgent.complete(reviewId);
    }

    private FileReviewResult buildResult(ReviewFile file, int index, int total, int completed, int queued,
                                         List<ReviewIssue> ruleIssues, LlmReviewerAgent.LlmResult llm) {
        FileReviewResult result = new FileReviewResult();
        result.fileName = file.fileName;
        result.filePath = file.relativePath;
        result.fileIndex = index;
        result.totalFiles = total;
        result.completedFiles = completed;
        result.queuedFiles = queued;
        result.reviewType = file.persona;
        result.comments.addAll(ruleIssues);
        result.comments.addAll(llm.comments);
        result.severity = highestSeverity(result.comments, llm.highestSeverity);
        result.score = result.severity.equals("PASSED") ? 95 : Math.max(30, llm.score - ruleIssues.size() * 5);
        result.summary = llm.fileSummary == null || llm.fileSummary.isBlank()
                ? "Review completed for " + file.fileName : llm.fileSummary;
        return result;
    }

    private String highestSeverity(List<ReviewIssue> issues, String llmSeverity) {
        List<String> order = List.of("CRITICAL", "MAJOR", "MINOR", "GOOD_TO_HAVE", "PASSED");
        String best = llmSeverity == null ? "PASSED" : llmSeverity;
        for (ReviewIssue issue : issues) {
            if (order.indexOf(issue.severity) >= 0 && order.indexOf(issue.severity) < order.indexOf(best)) best = issue.severity;
        }
        return best;
    }

    private void sleepSmall() {
        try { Thread.sleep(350); } catch (InterruptedException ignored) { Thread.currentThread().interrupt(); }
    }
}
