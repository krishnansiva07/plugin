package com.astra.codereview.model;

public class ReviewFile {
    public String fileName;
    public String relativePath;
    public String content;
    public String fileType;
    public String persona;

    public ReviewFile() {}

    public ReviewFile(String fileName, String relativePath, String content, String fileType, String persona) {
        this.fileName = fileName;
        this.relativePath = relativePath;
        this.content = content;
        this.fileType = fileType;
        this.persona = persona;
    }
}
