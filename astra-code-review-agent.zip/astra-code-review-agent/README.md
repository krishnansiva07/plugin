# ASTRA Code Review Agent

Local AI-powered pre-PR code review tool for developers and QA automation engineers.

## What is included

- Spring Boot backend on port `8090`
- React/Vite UI on port `5173`
- File/folder upload from UI
- File-by-file review queue
- Real-time SSE progress
- Expandable review comments immediately after each file completes
- Rule-based review + optional LLM review
- Backend, frontend, QA automation, config, dependency, DevOps file detection

## Important security note

Do not hardcode LLM API keys in `application.properties`.
Use environment variables:

```bash
set LLM_API_KEY=your-key
set LLM_BASE_URL=https://ai4devs.group.echonet/api/v1
set LLM_MODEL_NAME=gpt-oss-120b
set LLM_MOCK_MODE=false
```

For first demo without real LLM, keep:

```bash
set LLM_MOCK_MODE=true
```

## Run backend

```bash
cd backend
mvn spring-boot:run
```

Backend starts at:

```text
http://localhost:8090
```

## Run frontend

```bash
cd frontend
npm install
npm run dev
```

UI starts at:

```text
http://localhost:5173
```

## Flow

1. Open UI.
2. Select `Full Project Folder` or `Selected Files`.
3. Add files.
4. Click `Start Review`.
5. Backend creates review session.
6. UI listens to `/api/review/stream/{reviewId}`.
7. File 1 completes and comments appear immediately.
8. File 2 continues running while File 1 comments are visible.
9. Final status appears when all files are complete.

## Current V1 limitations

- Browser folder selection uploads files instead of sending physical folder path. This avoids local file permission issues.
- LLM integration expects OpenAI-compatible `/chat/completions` endpoint.
- Auto-fix/apply changes is not included in V1.
- Git changed files auto-detect is not included in V1.

## Best next features

- Git changed files mode
- Export Word/PDF report
- Apply selected fixes
- PR comment copy grouped by severity
- Rule configuration screen
- Project architecture summary
