> **Enhancement source candidate:** This ZIP includes the optional two-model Vision/Agent architecture,
> local persistent document knowledge, native-MCP image interpretation and gated deletion approval with
> bounded rollback. It is **not a build-verified release**: the packaging environment could not access
> Maven Central. Read [ENHANCEMENT_IMPLEMENTATION_STATUS.md](ENHANCEMENT_IMPLEMENTATION_STATUS.md)
> and [ENHANCEMENT_VALIDATION_REPORT.md](ENHANCEMENT_VALIDATION_REPORT.md) before building or running.
> In particular, deletion approval is not an OS-level sandbox for arbitrary scripts or remote side effects.

# ELIYA

Java 17 local coding/workspace assistant with two modes: **Chat** and **Agent**.

## What Agent mode does

Agent works directly on the user-selected local project. There is no temporary mirror or delayed apply phase.

1. Resolve the project path from the prompt/current project.
2. Discover project instructions, build metadata, resources, MCP/LSP status and a local retrieval index.
3. Use the single selected **Agent model** to create a structured sequential plan.
4. Show the plan for review/approval unless plan approval is disabled.
5. Lock the approved plan and execute exactly one active step at a time.
6. Read/search only the evidence needed for the active step, batch independent reads, and edit the live workspace.
7. For focused/normal tasks, defer compile/test/check/run until the final verification step unless an intermediate verifier is explicitly required.
8. For genuinely large tasks, switch on durable batching: inventory work items, process a bounded batch at a time, checkpoint risky batches, run cheap structural checks at batch boundaries, and keep failed items in a targeted recovery queue.
9. Require the latest changed workspace revision to pass a real verifier before successful completion.
10. Persist durable run/progress/work-item state; after an application restart, a new run for the same conversation/project inherits the interrupted large-task ledger.

The same selected Agent model owns planning, execution and verification reasoning. **There is no model fallback chain.** Chat has its own independently selected model.



## File-deletion approvals (Agent mode)

Open **Settings → Agent execution**. The option **Confirm file removal / destructive copy or move** is enabled by default (you can disable it explicitly). It is independent of plan approval, general tool permissions and **Auto-approve actions whose permission is set to Ask**.

When enabled, ELIYA shows a dedicated approval request listing the file paths affected by an explicit `delete`, `resource_delete`, a structured or OpenAI-style `apply_patch` deletion, `move` / `resource_move`, overwriting `copy` / `resource_copy`, or a `workspace_rollback` that would remove files. Select **Keep files / deny** or **Approve these file changes once**. There is no "allow for this run" option for file deletion. The backend rejects forged run-wide approval for these requests. If affected paths change while the user is reviewing, the operation requires fresh approval. Read-only tools and ordinary non-destructive edits are not interrupted.

Known destructive shell statements (e.g., `rm`, `del`, `Remove-Item`, `git clean`, `git reset --hard`) are rejected while protection is enabled; use explicit file tools instead. MCP tools with deletion-style names require a dedicated once-only confirmation. **Scope:** this is an application-level guard on ELIYA's built-in operations, not a filesystem sandbox. Build/test scripts, arbitrary spawned programs, indirect shell operations, and unknown external MCP tools may delete files internally without ELIYA identifying each path. For absolute protection, run such tools under OS-enforced filesystem isolation with read-only mounts or scoped permissions, or disable untrusted external execution.

The optional flag is sent as `agentConfirmFileDeletion` in ChatSettings requests; older clients that omit it default to **enabled**.

## Large task manager

ELIYA uses the existing fast execution path for small and medium work. Large-task orchestration is activated only when task scale is explicit (for example dozens/hundreds of cases), the request is broad framework/migration work, or repository evidence shows a wide change surface.

Large-task mode adds:

- a master sequential plan plus a separate durable **work-item ledger**
- default bounded batches (normally 8-10 items)
- workload-based progress such as `187/220 work items completed`
- `workspace_checkpoint` / `workspace_rollback` for risky batch boundaries
- cheap compile/type/static checks between meaningful batches rather than full regression after every edit
- automatic capture and deterministic clustering of verifier failure output
- failed-only recovery using `work_items_read(status=failed)` and `verification_failures`
- successful-completion gates that prevent a run from reporting success while pending/failed items or verifier failures remain
- durable work-item recovery after application restart
- a larger but still bounded active evidence preload for large tasks
- configurable repository-index limits through `eliya.index.maxFiles`, `eliya.index.maxScannedFiles`, and `eliya.index.maxFileBytes`

The selected Agent model remains a single model. Large-task management is runtime orchestration, not a multi-model fallback chain, so normal tasks do not incur the extra batching/checkpoint overhead.


## Speed design

The current runtime keeps the existing plan-first architecture while reducing unnecessary work:

- **Incremental retrieval-index refresh for direct edits.** `edit`, `write`, `copy`, `move`, `delete`, and `apply_patch` refresh only known changed paths instead of invalidating and rebuilding the whole workspace index.
- **Safe full invalidation for unknown shell mutations.** `bash`/resource commands can change arbitrary files, so a detected unknown shell mutation still invalidates the index for correctness.
- **Active-step evidence cache.** Retrieval hints plus bounded current-file evidence are reused while the active plan step and workspace revision are unchanged.
- **Parallel reads.** Independent read/search tool calls can run together before the next model turn.
- **Bounded context.** Old/oversized tool observations are pruned; durable plan/workspace facts are re-injected separately.
- **Plan-boundary checkpoints.** Oversized completed-step transcript history is compacted before the next plan step without forcing an extra model summary call in the normal case.
- **Deterministic final verification completion.** When the final approved step is the verification step and the latest revision passes a real verifier, the runtime closes that step directly instead of calling a completion critic.
- **No extra final completion-model round trip.** When all approved steps are complete and the latest workspace revision is verified, the runtime finishes from those deterministic facts.
- **Provider/model errors stop.** Authentication, unavailable model, rate/provider failures and other model/provider errors stop the Agent run instead of switching models or starting an expensive recovery replan.
- **One context-overflow recovery.** A genuine context-window overflow may compact once and retry the same selected Agent model. If it still fails, the run stops.
- **No-op aware editing.** An edit that already matches the workspace does not create a fake mutation revision.

These optimizations reduce latency without removing plan approval, sequential execution, live-workspace editing, or revision-aware verification.

## Error and recovery behavior

There are two different failure classes:

### Model/provider failure

The run stops immediately and preserves current workspace/run state. No alternate model is selected and no recovery replan is launched.

A context-window overflow is the single exception: the runtime may compact once and retry the **same** model.

### Coding/tool failure

Normal coding failures remain recoverable inside the active plan step. Examples include:

- compile/test failure caused by the current change
- stale exact-text edit
- wrong locator/path assumption
- command/tool schema mismatch that can be corrected locally
- non-actionable/duplicate model output while the provider itself is healthy

The agent can inspect the real error, change strategy and continue the same approved step. Productive work does not have a fixed step ceiling; no-progress guards prevent endless repetition.

## Context and token management

The live workspace and durable run state are authoritative; the full project is not resent every turn.

The runtime uses:

- provider/model context-window hints or configured per-model context values
- token estimation including tool schemas
- bounded tool-output history
- superseded runtime-steering cleanup
- durable objective/plan/revision/verification state outside chat history
- deterministic context checkpoints
- periodic semantic compaction only when useful
- one forced compaction attempt for context overflow
- local lexical retrieval plus bounded current-file evidence

Default recent-context and safety-buffer settings remain configurable in Settings.

## Planning and sequential execution

The selected Agent model receives live evidence and returns a structured plan. The harness checks that:

- the plan size matches the task profile
- each step contains validation evidence
- the final step is a dedicated compile/test/check/run verification phase

If the model returns structurally unusable plan output while the provider is healthy, a deterministic evidence-safe fallback plan may be used. A genuine provider/model call error does **not** trigger that fallback; the run stops.

After approval:

- only one step is `in_progress`
- later steps remain locked
- implementation steps advance from real tool/workspace evidence
- the final verification step cannot complete until the latest required workspace revision has passed a real verifier
- successful final verification can close the final step deterministically
- successful completion becomes 100%; blocked/failed/cancelled states do not masquerade as success

## Workspace retrieval

`WorkspaceRetrievalIndexService` maintains a local lexical index for relevant source/text files while skipping common build/vendor/cache directories.

Normal direct mutations update only changed entries. This is especially important for large Java automation repositories where repeatedly walking thousands of files after every edit adds avoidable latency.

The runtime still performs a full invalidation when a shell/resource command may have changed unknown paths.

## Tool execution

The compact default Agent surface includes workspace inspection, list/glob/grep/read tools, edit/write/patch, build/test/check/bash, workspace diff/status, TODO plan progress, resource tools, MCP/LSP discovery and targeted tool loading.

Multiple independent read-only calls may execute in parallel. Mutations remain ordered and are observed by the revision/verification state machine.

## Remote MCP (Jira / Confluence / DevOps tools)

ELIYA can now be configured once from **Settings → Remote MCP** and then reuse the existing generic MCP tool path automatically. No Jira- or Confluence-specific agent logic is added, so the current planning/execution architecture is unchanged.

For the ITG DevOps MCP shown in the supplied OpenCode configuration, enter:

```text
Connection name: itg-devops
Type: remote (handled by the UI)
Server URL: https://devops-itg.mcp.cib.echonet/
Timeout: 100000 ms
Headers as applicable:
  user-id
  jira-token
  confluence-token
  gitlab-token       (optional)
  sonarqube-token    (optional)
```

Use **Test connection & discover tools** to perform a real MCP initialize + `tools/list` exchange. A successful test shows the number and names of tools returned by the server. After saving, the same configuration is available to both Chat and Agent mode.

- **Chat mode** automatically activates a lightweight MCP tool loop for Jira/Confluence/GitLab/SonarQube-style requests and exposes only discovered read/search operations. Ordinary Chat prompts keep the existing streaming path. External write/update operations stay in Agent mode.
- **Agent mode with a workspace** keeps the existing workspace architecture and combines local files/tools with MCP and uploaded requirement documents. MCP schemas stay deferred and are loaded when needed through `tool_search`.
- **Agent mode without a workspace** is now valid for Jira/Confluence/MCP analysis and uploaded requirement-document work. It exposes MCP plus attachment read/search tools and never invents local workspace operations.
- A remembered workspace is not forced onto a clearly Jira/Confluence/document-only analysis request. If the prompt asks to inspect/implement/fix/migrate/compare against the project, the workspace remains active and the Agent can combine all sources.

Example prompts after configuration:

```text
Chat: Read Jira ABC-1234 and explain the acceptance criteria.

Agent (no workspace required): Read Jira ABC-1234 and the linked Confluence pages,
then produce an analysis report with risks, dependencies and missing requirements.

Agent (workspace + MCP + requirement document): Read Jira PAY-4582, its related Confluence documentation
and the attached requirement file. Compare them with the current Playwright workspace, identify missing
automation coverage, prepare the plan, and implement it after approval.

Agent write action: Add the final automation execution summary as a comment to Jira ABC-1234.
```

The ELIYA-managed MCP file is stored outside the project at:

```text
Windows: %USERPROFILE%\.eliya\mcp.json
Linux/macOS: ~/.eliya/mcp.json
```

Secret header values are never returned by the configuration API or inserted into model prompts. The Settings UI only reports whether a header is already configured; leaving a saved token field blank preserves the existing value. On POSIX filesystems ELIYA restricts the managed file to the current user when supported. Workspace `.agents/mcp.json` and `.opencode/mcp.json` files remain supported and continue to override user-level configuration by server name.

## Verification model

A workspace mutation increments the run mutation revision when the change requires verification. The runtime records verifier attempts against that revision.

A successful completion requires the latest required revision to be verified. Small changes should use the smallest high-signal verifier that proves the requested behavior; broad builds/tests are used when the scope requires them.

## UI

The main UI contains only **Chat** and **Agent** modes.

- Chat model and Agent model are selected independently.
- Agent uses one selected Chat/Agent-capable model for the whole task.
- Image understanding belongs to Chat mode; Agent remains focused on repository/tool work.
- Chat document attachments are extracted locally before the LLM call, so the selected provider does not need a native file-upload API. Supported readable formats include DOC/DOCX/DOCM, PDF with embedded text, XLS/XLSX/XLSM, PPT/PPTX/PPTM, RTF, OpenDocument files, TXT/Markdown/CSV/JSON/XML/HTML/YAML and common source/configuration files. HTML is parsed as document content (scripts/styles/raw tags are not sent as the page text).
- Current-message documents are always treated as direct context. If an older upload has no cached extraction, Chat automatically retries extraction before sending. If extraction still fails, the request stops with a clear application error instead of allowing the model to claim it cannot access the attachment.
- The attachment chip shows extraction readiness and extracted character count before the message is sent. Image-only/scanned PDFs require OCR and are reported as unreadable rather than silently guessed.
- Chat streaming coalesces tiny provider deltas for smoother rendering, understands standard SSE event/data framing, and keeps server generation independent from browser transport disconnects. The Stop button uses explicit Chat cancellation.
- Assistant messages and complete conversations can be downloaded as PDF; Markdown tables support rendered `<br>` line breaks in the UI.
- Office Open XML files (`.docx`, `.xlsx`, `.pptx`) are classified before generic XML/text handling, preventing binary ZIP containers from being decoded as UTF-8 text (the `Input length = 4` upload failure).
- Settings and model-library state are persisted when browser storage is available and fall back to in-memory state when storage is restricted.
- The Agent card displays plan progress, live activity, active step, verification and terminal state.
- **Clear history** deletes all chat and durable Agent-run history (including orphaned run journals) after confirmation while preserving model/API settings and the remembered active local workspace. Active/stale runs are tombstoned so they cannot recreate cleared history while unwinding.
- Workspace finalization is hash-based and binary-safe: a reporting/diff problem cannot turn an already completed execution into a false FAILED result.

## Durable data

Default per-user data location:

```text
Windows: %USERPROFILE%\.advanced-ai-workbench\
Linux/macOS: ~/.advanced-ai-workbench/
  data/
    chatdb.mv.db
    uploads/
    agent-cache/
    agent-runs/
  cache/
  logs/
```

Locations can be overridden with the existing application/system properties.

## Build and run

Requirements:

- Java 17 or later
- Maven, or network access on first use so the included wrapper can bootstrap Maven

Linux/macOS:

```bash
./mvnw clean package
java -jar target/eliya.jar
```

Windows:

```bat
mvnw.cmd clean package
java -jar target\eliya.jar
```

## Validation

The included validation scripts now run the full test suite by default.

Linux/macOS:

```bash
./validate-local.sh
```

Windows:

```bat
validate-local.bat
```

Validation performs:

1. Java availability
2. JavaScript syntax checks when Node is installed
3. Maven availability/bootstrap
4. clean package
5. `-Pfull-tests test`

For an explicitly fast local smoke check only:

```bash
FAST_VALIDATION=1 ./validate-local.sh
```

or on Windows:

```bat
set FAST_VALIDATION=1
validate-local.bat
```

Do not treat `FAST_VALIDATION=1` as a release/full validation.

## Source integrity

`SOURCE_MANIFEST_SHA256.txt` contains SHA-256 hashes for the shipped source/configuration files. It is regenerated only after final packaging changes so the manifest describes the actual package contents.

## Key source areas

```text
src/main/java/com/llmart/llm/service/AgentService.java
  orchestration, plan execution, context preparation, model-error behavior,
  completion gates, tool observation

src/main/java/com/llmart/llm/service/AgentRunService.java
  durable run state, sequential plan gate, mutation/verification revisions,
  progress and persistence

src/main/java/com/llmart/llm/service/WorkspaceRetrievalIndexService.java
  local lexical retrieval, full indexing and incremental changed-path refresh

src/main/java/com/llmart/llm/service/ContextWindowManager.java
  token estimation, pruning and compaction

src/main/java/com/llmart/llm/service/OpenAiCompatibleClient.java
  OpenAI-compatible transport and tool/JSON/plain protocol compatibility

src/main/resources/static/app.js
src/main/resources/static/index.html
  Chat/Agent UI, settings, SSE progress and model selection
```

## Recommended performance comparison

When comparing this build with another coding agent on the same repository/model/task, record:

- total duration
- model-call count
- provider-reported input/output tokens
- number of retrieval/index rebuilds
- repeated read/search calls
- tool-action count
- time from final successful verifier to terminal completion
- whether the requested task actually completed correctly

The intended improvement is lower harness overhead and fewer redundant model turns **without reducing task-completion quality or verification safety**.


## Multimodal workspace knowledge and deletion approval (source preview)

This updated **source preview** provides independently editable Agentic and optional Vision
model inputs in Agent mode, plus a Workspace Knowledge panel for local DOCX, XLSX, PPTX,
PDF, text and image evidence. With the project selected, choose a compatible Agentic model,
optionally provide a Vision model/endpoint/key, then use **Analyse Workspace**. You can also
ask Agent mode to analyse relevant documents and then generate test cases from their indexed
requirements. Chat continues to use its own selected model.

When **Confirm file deletion** is enabled, ELIYA captures a bounded pre-execution source
snapshot, pauses for exact-file approval, and enforces a backend 60-second limit. Rejection
or timeout stops the run and attempts to restore tracked source files. The dialog includes
full resolved paths, file hashes and countdown. Keep `app.data-dir` outside all writable
workspaces. In protected mode, MCP tools that are not explicitly read-only are blocked.

**This is not an OS-enforced sandbox.** Arbitrary scripts/builds/test runners and external
processes may still have destructive side effects; excluded dependency/build trees and
external systems are not restored by the source snapshot. Review
`IMPLEMENTATION_STATUS.md` before enabling this on real projects.

Offline smoke checks can run with only JDK 17+ and Bash:

```bash
bash qa/offline-smoke/run.sh
bash qa/offline-smoke/vision.sh
```

With internet-enabled Maven 3.9+ and Java 17, run `validate-local.bat` on Windows or
`validate-local.sh` on macOS/Linux. The included GitHub Actions workflow runs all tests
(`-Pfull-tests`) and publishes `target/eliya.jar` **only if the complete Maven build succeeds**.
