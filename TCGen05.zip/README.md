# TCGen Service - Dynamic Excel Column Test Case Generator

## Latest OCR Fix

This build fixes the image upload error shown as `Unexpected error: Handler dispatch failed: java.lang.Error: Invalid memory access`. The root cause is usually missing or unresolved Tesseract language data, especially `eng.traineddata`.

What changed:

- Auto-detects common Windows/Linux/Mac `tessdata` locations.
- Accepts either the Tesseract install folder or the direct `tessdata` folder.
- Validates that `eng.traineddata` exists before running OCR.
- Converts native Tess4J/Tesseract failures into a clear UI error.
- Adds `GET /api/testcases/ocr/status`.
- Adds **Check OCR Setup** button in the UI.



## Dual LLM Provider Support

TCGen provides two selectable LLM providers without removing the existing AI4Dev flow:

- **AI4Dev** - existing provider, default base URL `https://ai4devs.group.echonet/api/v1`, default model `gpt-oss-120b`.
- **LLM@CIB** - shared provider using base URL `https://api.llm.cib.echonet/v1/openai`, default model `gpt-oss-120b-ITG`. TCGen automatically calls `/chat/completions`, matching the working reference Chat implementation.

LLM@CIB chat/agent model suggestions included in the UI:

```text
gpt-oss-120b-ITG
mistral-small-2506-ITG
mistral-medium-2508-ITG
mistral-small-4-ITG
mistral-ocr-2512-ITG
mistral-ocr-4-ITG
gemma-4-31b-ITG
qwen3.6-35b-a3b
qwen3.8-27b
qwen-latest
qwen3.6-27b
```

The model field remains editable, so a newly supported gateway model can be typed manually. Both providers now use the same base-URL + bearer-token + `/chat/completions` request flow. Existing API clients that do not send the `provider` field continue to use the original `LLM_API_KEY`, `LLM_MODEL_NAME`, and `LLM_BASE_URL` behavior.

Provider-specific optional environment variables are also supported:

```text
AI4DEV_API_KEY
AI4DEV_MODEL_NAME
AI4DEV_BASE_URL
LLM_CIB_API_KEY
LLM_CIB_MODEL_NAME
LLM_CIB_BASE_URL
LLM_CIB_CHAT_URL
LLM_CIB_COMPLETIONS_URL
```

TCGen generates test cases from Acceptance Criteria, requirement documents, screenshots/images, and Word documents that contain embedded images. The UI now has two upload controls: one for the main requirements / AC / design file, and one optional Excel template whose first row defines the expected test case output columns. The selected/default/custom columns or uploaded column template are used in both the dynamic LLM prompt and Excel export.

## Main Features

- Upload requirements / AC / design file from UI using **Browse AC / Image File** button.
- Existing text-based support: TXT, PDF, DOC/DOCX, XLS/XLSX, CSV, JSON, XML, HTML, MD.
- New image upload support: PNG, JPG, JPEG, BMP, TIFF, WEBP.
- New DOCX embedded image support: normal Word text + tables are extracted, then embedded images are OCR-scanned and merged into the LLM prompt.
- File Understanding Mode dropdown:
  - Auto Detect
  - Document / Excel AC
  - Image with AC Text
  - UI Design / Figma Screenshot
  - Word Document with Images
- Provider selector with **AI4Dev** and **LLM@CIB**.
- API key/user token field in UI.
- Provider-aware model suggestions with manual model override.
- Provider base URL field. AI4Dev and LLM@CIB both use the same chat request path construction.
- If UI token/model/base URL is empty, backend falls back to provider-specific configuration; legacy requests still fall back to `LLM_API_KEY`, `LLM_MODEL_NAME`, and `LLM_BASE_URL`.
- AI4Dev and LLM@CIB use one direct OpenAI-compatible Java HTTP chat client, mirroring the attached reference project.
- Dynamic column selection from UI.
- Custom column add option now supports comma/semicolon/newline separated values. Example: `Risk, Sprint, Jira ID`.
- Template buttons: Manual TC, API TC, BDD TC, Regression TC.
- Dynamic prompt preview based on selected columns, file understanding mode and Excel-column mode.
- Optional separate Excel template upload: TCGen reads the first non-empty row as the expected output columns.
- New API endpoint to detect expected columns from the separate column Excel before generation.
- LLM prompt uses only selected columns.
- Excel export uses only selected columns plus auto-generated `S.No`.
- Follow-up questions and assumptions are generated when AC/design details are incomplete.
- No hardcoded API key.
- UI preview does not show the temporary "Fix included" information box.


## Separate Expected Column Excel Upload

TCGen can now use a **separate Excel file** only for the expected output format.

Recommended flow:

```text
Browse AC / Image File       → Upload the actual requirement / AC / design file
Browse Column Excel          → Upload optional Excel where row 1 contains expected output columns
Load Column Template         → Reads row 1 and selects those columns in UI
Generate Test Cases          → LLM generates test cases only in that selected format
Download Excel               → Export uses the same columns
```

Simple expected column Excel format:

```text
Row 1:
Test ID | Module | Requirement ID | Scenario | Precondition | Test Steps | Test Data | Expected Result | Priority | Test Type | Automation Candidate | Risk | Sprint | Jira ID | Owner | Comments
```

Rules:

- The separate column Excel can have any sheet name.
- TCGen reads the **first non-empty row** as the expected output columns.
- `S.No`, `Serial No`, and `Serial Number` are ignored because TCGen auto-generates `S.No` during Excel export.
- If no separate column Excel is uploaded, TCGen uses UI selected/default/custom columns.
- For backward compatibility, if the requirements file itself is an Excel file with an `Output_Schema`, `Expected_Columns`, `Columns` or similar sheet, TCGen can still use that schema.

Sample template included:

```text
samples/expected_columns_first_row_template.xlsx
```

Custom column input still supports multiple columns in one shot:

```text
Risk, Sprint, Jira ID, Owner, Comments
```

Each value becomes a separate selectable Excel column.

## Image and Word-with-Image Flow

```text
Image / DOCX Upload
    ↓
Document text extraction using Apache Tika
    ↓
Embedded DOCX image extraction using Apache POI
    ↓
OCR extraction using Tess4J / Tesseract
    ↓
Merge normal text + OCR text + user prompt + selected columns
    ↓
Unified OpenAI-compatible chat client
    ↓
JSON test cases
    ↓
UI preview + Excel export
```

## LLM Configuration Used

Both AI4Dev and LLM@CIB use the same Java 17 `HttpClient` chat flow. The provider-specific UI selection only supplies defaults for base URL and model. The client appends `/chat/completions` when needed, sends `messages` with `stream=false`, and uses bearer authentication.

TCGen requests `response_format: {"type":"json_object"}` first because the generator requires structured JSON. If a provider explicitly reports that JSON response format is unsupported, TCGen retries the same chat request without that field. `max_tokens` defaults to `0`, meaning it is omitted so the provider can manage the output budget; this prevents the previous 512-token truncation problem for large test-case JSON responses.

The original `llm.base-url` and `llm.llm-cib.base-url` properties are retained for backward compatibility.

## OCR Configuration

This project uses Tess4J/Tesseract for OCR. Install Tesseract OCR on the machine where the Spring Boot app runs.

Typical Windows setup. Point this to the folder containing `eng.traineddata`:

```powershell
$env:TCGEN_OCR_TESSDATA_PATH="C:\Program Files\Tesseract-OCR\tessdata"
```

Typical Linux setup:

```bash
export TCGEN_OCR_TESSDATA_PATH=/usr/share/tesseract-ocr/5/tessdata
```

OCR properties. You can leave `tcgen.ocr.tessdata-path` empty if auto-detection works:

```properties
tcgen.ocr.enabled=true
tcgen.ocr.language=eng
tcgen.ocr.tessdata-path=
tcgen.ocr.docx-images.enabled=true
tcgen.ocr.docx-images.max-count=20
```

For design screenshots, OCR reads visible text from the image. Pure visual layout understanding, color comparison and spacing validation need Vision AI; OCR alone cannot fully understand those visual aspects.

## Project Structure

```text
tcgen-service-dynamic-columns
├── pom.xml
├── README.md
├── samples
│   └── place_order_acceptance_criteria_sample.xlsx
└── src
    └── main
        ├── java/com/llmart/llm
        │   ├── LlmApplication.java
        │   ├── config/ChatConfig.java
        │   ├── controller/TestCaseController.java
        │   ├── dto/TestCaseGenerationResponse.java
        │   ├── exception
        │   └── service
        │       ├── FileTextExtractor.java
        │       ├── OcrService.java
        │       ├── DocxImageOcrExtractor.java
        │       └── other services
        └── resources
            ├── application.properties
            └── static/index.html
```

## Run Locally

```bash
mvn clean package
```

```bash
java -jar target/tcgen-service-0.0.7-SNAPSHOT.jar \
  --llm.api-key=your-key \
  --llm.model-name=gpt-oss-120b \
  --llm.base-url=https://ai4devs.group.echonet/api/v1
```

Open:

```text
http://localhost:8090
```

## Environment Variable Run

```bash
export LLM_API_KEY="your-key"
export LLM_MODEL_NAME="gpt-oss-120b"
export LLM_BASE_URL="https://ai4devs.group.echonet/api/v1"
export TCGEN_OCR_TESSDATA_PATH="/usr/share/tesseract-ocr/5/tessdata"
java -jar target/tcgen-service-0.0.7-SNAPSHOT.jar
```

For Windows PowerShell:

```powershell
$env:LLM_API_KEY="your-key"
$env:LLM_MODEL_NAME="gpt-oss-120b"
$env:LLM_BASE_URL="https://ai4devs.group.echonet/api/v1"
$env:TCGEN_OCR_TESSDATA_PATH="C:\Program Files\Tesseract-OCR\tessdata"
java -jar target/tcgen-service-0.0.7-SNAPSHOT.jar
```

## Curl Example - Excel/Document AC

```bash
curl -X POST http://localhost:8090/api/testcases/generate \
  -F "requirementsFile=@samples/place_order_acceptance_criteria_sample.xlsx" \
  -F "expectedColumnsFile=@samples/expected_columns_first_row_template.xlsx" \
  -F "provider=AI4DEV" \
  -F "apiKey=your-user-token" \
  -F "modelName=gpt-oss-120b" \
  -F "baseUrl=https://ai4devs.group.echonet/api/v1" \
  -F "fileUnderstandingMode=document-ac" \
  -F "useUploadedExcelColumns=true" \
  -F "selectedColumns=Test ID,Module,Requirement ID,Scenario,Precondition,Test Steps,Test Data,Expected Result,Priority,Test Type,Automation Candidate" \
  -F "additionalPrompt=Generate positive, negative, boundary, UI, API, DB, smoke and regression cases"
```

## Curl Example - Image Screenshot

```bash
curl -X POST http://localhost:8090/api/testcases/generate \
  -F "requirementsFile=@place-order-screen.png" \
  -F "expectedColumnsFile=@samples/expected_columns_first_row_template.xlsx" \
  -F "provider=AI4DEV" \
  -F "apiKey=your-user-token" \
  -F "modelName=gpt-oss-120b" \
  -F "baseUrl=https://ai4devs.group.echonet/api/v1" \
  -F "fileUnderstandingMode=ui-design" \
  -F "selectedColumns=Test ID,Scenario,Test Steps,Test Data,Expected Result,Priority,Test Type" \
  -F "additionalPrompt=This is Place Order screen. Generate UI validation, positive, negative, boundary and regression test cases."
```

## OCR Status Endpoint

```text
GET /api/testcases/ocr/status
```

Use this from browser:

```text
http://localhost:8090/api/testcases/ocr/status
```

A valid setup should show `trainedDataFound=true`. If it is false, install Tesseract language data or set `TCGEN_OCR_TESSDATA_PATH` to the folder that contains `eng.traineddata`.

## API Endpoints

### Health

```text
GET /api/testcases/health
```

### Default Columns

```text
GET /api/testcases/columns/defaults
```

### Detect Expected Columns from Uploaded Excel

```text
POST /api/testcases/columns/from-excel
Content-Type: multipart/form-data
```

Form fields:

| Field | Required | Description |
|---|---:|---|
| file | Yes | XLS/XLSX file containing expected columns |

Response:

```json
{
  "columns": ["Test ID", "Scenario", "Test Steps", "Expected Result", "Priority"],
  "message": "Detected 5 expected output columns from the column template Excel."
}
```

### Generate Test Cases

```text
POST /api/testcases/generate
Content-Type: multipart/form-data
```

Form fields:

| Field | Required | Description |
|---|---:|---|
| requirementsFile | Yes | Main AC document, screenshot image, design image or Word file with embedded images. `file` is still accepted for backward compatibility. |
| expectedColumnsFile | No | Separate XLS/XLSX template where the first non-empty row contains expected output columns. |
| provider | No | `AI4DEV` or `LLM_CIB`. Omit it to preserve the original legacy `llm.*` behavior. |
| apiKey | No | User token/API key. Falls back to provider-specific or legacy configured key. |
| modelName | No | Model name. Falls back to configured model. |
| baseUrl | No | Provider base URL. TCGen appends `/chat/completions` automatically when needed. |
| fileUnderstandingMode | No | auto, document-ac, image-ac, ui-design, docx-with-images |
| selectedColumns | No | Comma/semicolon/newline separated selected columns. Defaults to manual TC columns. |
| useUploadedExcelColumns | No | true/false. If true and `expectedColumnsFile` is uploaded, its first row overrides UI selection. If not uploaded, TCGen falls back to requirement Excel schema detection, then UI columns. |
| additionalPrompt | No | Additional user instruction |

### Export Excel

```text
POST /api/testcases/export
Content-Type: application/json
```

Body: response JSON from `/generate`.

## Important Security Notes

- Do not hardcode real keys in `application.properties`.
- Do not commit API keys to Git.
- Do not share screenshots containing live tokens.
- If a token was exposed in screenshot/logs, rotate it immediately.
- UI token is sent only for the current request and is not exported to Excel.


## Bundled OCR Support

This version includes English OCR language data inside the project:

```text
src/main/resources/tessdata/eng.traineddata
```

So team members do not need to manually install or configure `eng.traineddata` for English OCR. The app will auto-detect this file during local development and will also extract it from the built JAR into a temporary folder when required.

OCR status endpoint:

```text
GET http://localhost:8090/api/testcases/ocr/status
```

Expected success indicators:

```text
tessdataFound=true
trainedDataFound=true
bundledTessdataAvailable=true
```

If native DLL loading fails on Windows, install Microsoft Visual C++ Redistributable. Normal text/PDF/DOCX/XLSX extraction does not require OCR.


## UI action fix note

This package includes a browser-side fix for the UI action issue where Browse, Generate, Check OCR Setup, Load Excel Columns and Download Excel did not trigger.

Root cause: the previous `index.html` had an invalid JavaScript string in the OCR status function: `lines.join('` followed by a physical newline. That stopped the entire script from loading, so all UI functions were unavailable.

Fix included:
- Corrected `lines.join('\n')` JavaScript syntax.
- Changed the Browse control to a native `<label for="file">` trigger so file browsing works even before JavaScript handlers attach.
- Added a small UI JavaScript error banner to make future script errors visible on the page.
