import subprocess, time, pathlib, json, threading, http.server, requests, websocket, glob, os, socket, traceback
ROOT=pathlib.Path(__file__).parent.parent
QA=ROOT/'qa'
class Handler(http.server.SimpleHTTPRequestHandler):
 def __init__(self,*args,**kwargs):super().__init__(*args,directory=str(QA),**kwargs)
 def log_message(self,*args):pass
s=http.server.ThreadingHTTPServer(('127.0.0.1',0),Handler)
threading.Thread(target=s.serve_forever,daemon=True).start()
port=s.server_address[1]
appPort=None
with socket.socket() as sock:
 sock.bind(('127.0.0.1',0)); appPort=sock.getsockname()[1]
log=open(QA/'test-recorder.log','w')
cmd=['java','-Drecorder.noAutoOpen=true',f'-Drecorder.port={appPort}', '-Drecorder.headless=true',
 '-Drecorder.disableSandbox=true','-Drecorder.browserNoProxy=true','-Drecorder.chromePath=/usr/bin/chromium',
 '-jar',str(ROOT/'target/eliya-ui-recorder-2.1.0.jar')]
p=subprocess.Popen(cmd,stdout=log,stderr=subprocess.STDOUT)
base=f'http://127.0.0.1:{appPort}'
ws=None
try:
 for i in range(80):
  try:
   if requests.get(base+'/api/state',timeout=1).status_code==200:break
  except Exception:pass
  time.sleep(.1)
 else:raise Exception('server unavailable')
 r=requests.post(base+'/api/launch',data={'url':f'http://127.0.0.1:{port}/fixture.html','browser':'chrome','name':'Create account','deepDom':'true'},headers={'Origin':base},timeout=8)
 print('launch',r.status_code,r.text[:350]);r.raise_for_status()
 for i in range(80):
  st=requests.get(base+'/api/state',timeout=3).json()
  if st['status'] in ('recording','error'):break
  time.sleep(.25)
 assert st['status']=='recording',st
 profile=max((pathlib.Path(x) for x in glob.glob('/tmp/eliya-recorder-profile-*') if pathlib.Path(x,'DevToolsActivePort').exists()),key=lambda p:p.stat().st_mtime)
 cdpPort=int((profile/'DevToolsActivePort').read_text().splitlines()[0])
 target=next(t for t in requests.get(f'http://127.0.0.1:{cdpPort}/json/list').json() if t['type']=='page' and not t.get('url','').startswith('devtools:'))
 ws=websocket.create_connection(target['webSocketDebuggerUrl'],timeout=8,suppress_origin=True)
 count=0
 def call(method,params):
  global count
  count+=1;index=count
  ws.send(json.dumps({'id':index,'method':method,'params':params}))
  while True:
   r=json.loads(ws.recv())
   if r.get('id')==index:
    if 'error' in r:raise Exception(r['error'])
    return r.get('result',{})
 def evaluate(code):
  value=call('Runtime.evaluate',{'expression':code,'returnByValue':True,'awaitPromise':True})
  if value.get('exceptionDetails'):raise Exception(value['exceptionDetails'])
  return value.get('result',{}).get('value')
 # Use a stable about:blank document and insert the fixtures directly. The
 # container-managed Chromium cannot access the local HTTP fixture under policy.
 call('Page.navigate',{'url':'about:blank'})
 for i in range(60):
  if evaluate('document.readyState === "complete" && typeof window.__eliyaRecorderSend === "function" && !!window.__eliyaRecorderInit'):break
  time.sleep(.2)
 assert evaluate('document.readyState === "complete" && typeof window.__eliyaRecorderSend === "function" && !!window.__eliyaRecorderInit'), 'instrumentation not ready'
 fixture=(QA/'fixture.html').read_text()
 markup=fixture.split('<body>')[1].split('<script>')[0]
 evaluate("document.body.innerHTML="+json.dumps(markup)+";document.title='Automation Sample';")
 evaluate("(() => {const host=document.getElementById('host');const root=host.attachShadow({mode:'open'});root.innerHTML='<button data-testid=\"shadow-save\">Shadow Save</button>';})();")
 assert evaluate('document.querySelector("#name") !== null')
 print('Ready:',evaluate('location.href'),evaluate('typeof window.__eliyaRecorderSend'))
 evaluate("(() => {const e=document.querySelector('#name'); e.click(); e.value='A';e.dispatchEvent(new Event('input',{bubbles:true}));e.value='Alex';e.dispatchEvent(new Event('input',{bubbles:true}));e.dispatchEvent(new Event('change',{bubbles:true}));})();")
 evaluate("(() => {const e=document.querySelector('#pass');e.value='SUPERSECRET987';e.dispatchEvent(new Event('input',{bubbles:true}));e.dispatchEvent(new Event('change',{bubbles:true}));})();")
 evaluate("document.querySelector('#status').click()")
 evaluate("(() => {const e=document.querySelector('#role');e.value='admin';e.dispatchEvent(new Event('change',{bubbles:true}));})();")
 evaluate("document.querySelector('[data-testid=save]').click()")
 evaluate("document.querySelector('#host').shadowRoot.querySelector('button').click()")
 evaluate("document.querySelector('[data-testid=save]').dispatchEvent(new KeyboardEvent('keydown',{key:'a',bubbles:true}))")
 evaluate("document.querySelector('[data-testid=save]').dispatchEvent(new KeyboardEvent('keydown',{key:'Enter',bubbles:true}))")
 time.sleep(.6)
 picker=requests.post(base+'/api/pick',data={'kind':'textContains'},headers={'Origin':base},timeout=6)
 print('picker',picker.status_code,picker.text[:300]);picker.raise_for_status()
 print('Binding after picker:',evaluate('typeof window.__eliyaRecorderSend'))
 evaluate("document.querySelector('[data-testid=save]').dispatchEvent(new MouseEvent('click',{bubbles:true,cancelable:true,composed:true}))")
 time.sleep(.25)
 wait_picker=requests.post(base+'/api/pick',data={'kind':'waitForVisible'},headers={'Origin':base},timeout=6)
 wait_picker.raise_for_status()
 evaluate("document.querySelector('[data-testid=save]').dispatchEvent(new MouseEvent('click',{bubbles:true,cancelable:true,composed:true}))")
 time.sleep(.6)
 state=requests.get(base+'/api/state').json()
 print('live',state['stepCount'],[(s['action'],s['description']) for s in state['steps']])
 assert state['stepCount']>=7
 kinds=[x['action'] for x in state['steps']]
 assert kinds.count('fill')==2,kinds
 assert kinds.count('check')==1,kinds
 assert kinds.count('select')==1,kinds
 assert 'assert' in kinds and 'waitFor' in kinds,kinds
 assert kinds.count('keyPress')==1,kinds
 assert any('Shadow Save' in x['description'] for x in state['steps'])
 assert 'SUPERSECRET987' not in json.dumps(state)
 r=requests.post(base+'/api/pause',headers={'Origin':base});r.raise_for_status()
 old=requests.get(base+'/api/state').json()['stepCount']
 evaluate("document.querySelector('[data-testid=save]').click()")
 time.sleep(.3)
 assert requests.get(base+'/api/state').json()['stepCount']==old
 requests.post(base+'/api/resume',headers={'Origin':base}).raise_for_status()
 requests.post(base+'/api/manual',data={'type':'assertUrlContains','expected':'fixture.html'},headers={'Origin':base}).raise_for_status()
 requests.post(base+'/api/edit',data={'step':1,'description':'Enter a name for the new user','strategy':'testId','locator':'user-name'},headers={'Origin':base}).raise_for_status()
 requests.post(base+'/api/stop',headers={'Origin':base}).raise_for_status()
 clean=requests.get(base+'/api/export',timeout=8);clean.raise_for_status(); data=clean.json()
 debug=requests.get(base+'/api/export?diagnostics=true').json()
 assert data['schemaVersion']=='2.0' and data['format']=='eliya-automation-test'
 assert data['summary']['stepCount']==len(data['steps'])
 assert not any('inspection' in step for step in data['steps'])
 assert any('inspection' in step for step in debug['steps'])
 assert data['steps'][0]['description']=='Enter a name for the new user'
 assert 'SUPERSECRET987' not in clean.text and 'SUPERSECRET987' not in json.dumps(debug)
 assert data['summary']['assertionCount']==2
 assert any(x['action']=='waitFor' and x['condition']=='visible' for x in data['steps'])
 assert 'pointerdown' not in kinds and 'focusin' not in kinds and 'mouseover' not in kinds
 (QA/'test-output-clean.json').write_text(json.dumps(data,indent=2))
 (QA/'test-output-debug.json').write_text(json.dumps(debug,indent=2))
 print('PASS: meaningful steps, deduplication, element assertions, edit, pause, mask, diagnostics split, export')
finally:
 if ws:ws.close()
 p.terminate()
 try:p.wait(timeout=5)
 except subprocess.TimeoutExpired:p.kill()
 s.shutdown();log.close()
 print('app log:',(QA/'test-recorder.log').read_text()[-1200:])
