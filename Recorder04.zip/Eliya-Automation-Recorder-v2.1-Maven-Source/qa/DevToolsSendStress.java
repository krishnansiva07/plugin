package com.eliya.recorder;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.*;
import java.util.concurrent.*;

/** Regression guard for JDK java.net.http.WebSocket "Send pending" failures. */
public final class DevToolsSendStress {
    @SuppressWarnings("unchecked")
    public static void main(String[] args) throws Exception {
        if (args.length != 1) throw new IllegalArgumentException("ws://... expected");
        BrowserRecorder recorder = new BrowserRecorder("", (tab, action) -> {});
        Class<?> type = Class.forName("com.eliya.recorder.BrowserRecorder$CdpSocket");
        Constructor<?> constructor = type.getDeclaredConstructor(BrowserRecorder.class, String.class, String.class);
        constructor.setAccessible(true);
        Object socket = constructor.newInstance(recorder, "send-stress", args[0]);
        Method send = type.getDeclaredMethod("send", String.class, Map.class);
        send.setAccessible(true);
        Method close = type.getDeclaredMethod("close");
        close.setAccessible(true);
        ExecutorService callers = Executors.newFixedThreadPool(24);
        try {
            int count = 1000;
            String payload = "x".repeat(2048);
            List<CompletableFuture<Map<String, Object>>> results = Collections.synchronizedList(new ArrayList<>());
            CountDownLatch begin = new CountDownLatch(1);
            List<Future<?>> tasks = new ArrayList<>();
            for (int thread = 0; thread < 24; thread++) {
                final int batch = thread;
                tasks.add(callers.submit(() -> {
                    try {
                        begin.await();
                        for (int i = batch; i < count; i += 24) {
                            results.add((CompletableFuture<Map<String,Object>>) send.invoke(socket,
                                "Runtime.evaluate", Json.map("expression", payload + i)));
                        }
                    } catch (Exception ex) { throw new RuntimeException(ex); }
                }));
            }
            begin.countDown();
            for (Future<?> task : tasks) task.get(20, TimeUnit.SECONDS);
            CompletableFuture.allOf(results.toArray(new CompletableFuture[0])).get(30, TimeUnit.SECONDS);
            if (results.size() != count) throw new AssertionError("Lost commands " + results.size() + " / " + count);
            for (var future : results) {
                if (!Boolean.TRUE.equals(Json.object(future.get().get("result")).get("ok")))
                    throw new AssertionError("Invalid CDP response");
            }
            System.out.println("PASS: " + count + " concurrent DevTools commands completed with no Send pending");
        } finally {
            close.invoke(socket);
            callers.shutdownNow();
            recorder.close();
        }
    }
}
