"""Optional regression test (requires pip package websockets, only for this QA script)."""
import asyncio
import json
import pathlib
import subprocess
import threading
from websockets.asyncio.server import serve
from websockets.exceptions import ConnectionClosed

ROOT=pathlib.Path(__file__).resolve().parents[1]
ready=threading.Event()
status={}

async def handler(ws):
    try:
        async for message in ws:
            request=json.loads(message)
            await ws.send(json.dumps({'id':request['id'], 'result':{'ok':True}}))
    except ConnectionClosed:
        pass  # The recorder deliberately aborts its test WebSocket during shutdown.

async def main():
    async with serve(handler,'127.0.0.1',0,max_size=2**20) as server:
        status['port']=server.sockets[0].getsockname()[1]
        ready.set()
        while not status.get('done'):
            await asyncio.sleep(.1)

def serve_thread():
    asyncio.run(main())

t=threading.Thread(target=serve_thread, daemon=True)
t.start()
assert ready.wait(5)
classes=ROOT/'target'/'classes'
test_classes=ROOT/'target'/'qa-classes'
test_classes.mkdir(parents=True,exist_ok=True)
try:
    subprocess.run(['javac','--release','17','-cp',str(classes),'-d',str(test_classes),str(ROOT/'qa'/'DevToolsSendStress.java')],check=True)
    subprocess.run(['java','-cp',str(classes)+':'+str(test_classes),
        'com.eliya.recorder.DevToolsSendStress',f"ws://127.0.0.1:{status['port']}/"],check=True,timeout=45)
finally:
    status['done']=True
    t.join(timeout=3)
