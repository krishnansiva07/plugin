# Changelog

## 2.1.0 — Chrome/Edge launch reliability

- Fixed `java.lang.IllegalStateException: Send pending` caused by overlapping Java 17 WebSocket text sends to Chrome/Edge DevTools.
- Serialized CDP outgoing commands per socket through an asynchronous queue that waits for each send to finish.
- Prevented a failed send from poisoning all later commands in the queue.
- Failed queued/in-flight commands cleanly when DevTools closes.
- Improved socket cleanup by aborting safely rather than trying to enqueue close frames behind stuck sends.
- Added stress regression test: 1,000 CDP commands submitted concurrently from 24 threads (mock WebSocket endpoint).
- Re-ran end-to-end browser smoke tests for test-step capture and JSON exports.
- No breaking JSON schema change; export remains `schemaVersion: 2.0`.

## 2.0.0 — Automation-first recorder

- Added meaningful, editable test steps, assertion picker, clean and diagnostic JSON exports.
