package com.eliya.recorder;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;
import java.awt.Desktop;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.nio.file.attribute.PosixFilePermission;
import java.time.Instant;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.*;

/** Local HTTP dashboard and orchestration for a dependency-free Java 17 browser recorder. */
public final class RecorderApp {
    private static final DateTimeFormatter FILE_TIME = DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss").withZone(ZoneOffset.UTC);
    private final Object lock = new Object();
    private final ActionBook book = new ActionBook();
    private final ExecutorService background = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "recorder-launch"); t.setDaemon(true); return t;
    });
    private final String scriptBody;
    private HttpServer server;
    private BrowserRecorder browserRecorder;
    private String status = "idle";
    private String statusMessage = "Enter your application URL to begin.";
    private String appUrl = "", browserName = "", sessionId = "", caseName = "New UI test";
    private Instant startedAt, stoppedAt;
    private Path autosave;
    private boolean deepDom;

    private RecorderApp() throws IOException {
        try (InputStream in = Objects.requireNonNull(RecorderApp.class.getResourceAsStream("/recorder.js"), "recorder.js missing")) {
            scriptBody = new String(in.readAllBytes(), StandardCharsets.UTF_8);
        }
    }
    public static void main(String[] args) throws Exception {
        RecorderApp app = new RecorderApp(); app.start();
        Runtime.getRuntime().addShutdownHook(new Thread(app::shutdown, "recorder-cleanup"));
    }
    private void start() throws IOException {
        server = HttpServer.create(new InetSocketAddress(InetAddress.getByName("127.0.0.1"),
            Integer.getInteger("recorder.port", 0)), 0);
        server.setExecutor(Executors.newFixedThreadPool(6, r -> {
            Thread t = new Thread(r, "recorder-http"); t.setDaemon(true); return t;
        }));
        server.createContext("/", this::router);
        server.start();
        String ui = "http://127.0.0.1:" + server.getAddress().getPort() + "/";
        System.out.println("Eliya Automation Recorder v2.1 | Java 17+ | " + ui);
        System.out.println("Ctrl+C to stop the application.");
        if (!Boolean.getBoolean("recorder.noAutoOpen")) try {
            if (Desktop.isDesktopSupported() && Desktop.getDesktop().isSupported(Desktop.Action.BROWSE))
                Desktop.getDesktop().browse(URI.create(ui));
        } catch (Exception e) { System.out.println("Open the dashboard manually: " + ui); }
    }
    private void router(HttpExchange e) throws IOException {
        try {
            String path = e.getRequestURI().getPath(), method = e.getRequestMethod();
            if (!validHost(e)) { reply(e, 403, "text/plain", "Invalid host"); return; }
            if (path.startsWith("/api/") && !"GET".equals(method) && !validOrigin(e)) {
                reply(e, 403, "application/json", Json.stringify(Json.map("error", "Invalid origin"))); return;
            }
            if (path.equals("/") && method.equals("GET")) {
                try (InputStream in = Objects.requireNonNull(RecorderApp.class.getResourceAsStream("/index.html"))) {
                    reply(e, 200, "text/html; charset=utf-8", in.readAllBytes());
                }
                return;
            }
            if (path.equals("/favicon.ico")) { reply(e, 204, "image/x-icon", new byte[0]); return; }
            if (path.equals("/api/state") && method.equals("GET")) {
                reply(e, 200, "application/json", Json.stringify(state()));return;
            }
            if (path.equals("/api/launch") && method.equals("POST")) {
                Map<String, String> params = readForm(e);
                launch(e, params); return;
            }
            if (path.equals("/api/pause") && method.equals("POST")) {pause(e);return;}
            if (path.equals("/api/resume") && method.equals("POST")) {
                synchronized (lock) {if (status.equals("paused")) {status="recording";statusMessage="Recording resumed.";}}
                replyState(e);return;
            }
            if (path.equals("/api/stop") && method.equals("POST")) {stop(e);return;}
            if (path.equals("/api/pick") && method.equals("POST")) {
                String kind=readForm(e).getOrDefault("kind", "");
                if (!Set.of("visible", "textContains", "textEquals", "valueEquals", "enabled", "checked", "waitForVisible", "waitForHidden").contains(kind)) {
                    fail(e, 400, "Unsupported assertion type");return;
                }
                BrowserRecorder current;
                synchronized (lock) {current=status.equals("recording")?browserRecorder:null;}
                if (current == null) {fail(e, 409, "Start or resume recording first");return;}
                current.pickAssertion(kind);
                synchronized (lock) {statusMessage="Go to the browser and click the element you want to assert. Press Escape to cancel.";}
                replyState(e);return;
            }
            if (path.equals("/api/manual") && method.equals("POST")) {
                Map<String, String> p=readForm(e);
                synchronized (lock) {
                    if (sessionId.isBlank()) {fail(e, 409, "Start a recording first");return;}
                    book.addManual(p.getOrDefault("type", ""), p.getOrDefault("expected", ""),
                        book.size()==0 ? "manual" : Json.str(book.all().get(book.size()-1).get("tabId")));
                    snapshot();
                }
                replyState(e);return;
            }
            if (path.equals("/api/meta") && method.equals("POST")) {
                String value=readForm(e).getOrDefault("name", "").trim();
                if(value.isBlank()||value.length()>120){fail(e,400,"Test name must be 1–120 characters");return;}
                synchronized (lock) {caseName=value;snapshot();}
                replyState(e);return;
            }
            if (Set.of("/api/edit", "/api/delete", "/api/move").contains(path) && method.equals("POST")) {
                Map<String, String> p=readForm(e);int index;
                try {index=Integer.parseInt(p.getOrDefault("step","-1"));}
                catch (NumberFormatException ex) {fail(e,400,"Invalid step number");return;}
                boolean changed;
                synchronized (lock) {
                    changed=switch (path) {
                        case "/api/edit" -> book.edit(index,p.getOrDefault("description",""),
                            p.getOrDefault("strategy", "css"),p.getOrDefault("locator", ""),p.getOrDefault("value", ""));
                        case "/api/delete" -> book.delete(index);
                        case "/api/move" -> book.move(index,"up".equals(p.get("direction"))?-1:1);
                        default -> false;
                    };
                    if (changed) snapshot();
                }
                if (!changed) {fail(e,404,"Step not found or cannot move further");return;}
                replyState(e);return;
            }
            if (path.equals("/api/action") && method.equals("GET")) {
                Map<String,String> q=parseQuery(e.getRequestURI().getRawQuery());int index;
                try {index=Integer.parseInt(q.getOrDefault("step","-1"));}
                catch (NumberFormatException ex) {index=-1;}
                Map<String,Object> selected;
                synchronized (lock) {selected=book.at(index);}
                if(selected==null){fail(e,404,"Step not found");return;}
                reply(e,200,"application/json; charset=utf-8",Json.pretty(selected));return;
            }
            if (path.equals("/api/export") && method.equals("GET")) {
                export(e,"true".equals(parseQuery(e.getRequestURI().getRawQuery()).get("diagnostics")));return;
            }
            if (path.equals("/api/close-browser") && method.equals("POST")) {
                BrowserRecorder old;
                synchronized (lock) {
                    status="stopped";if(stoppedAt==null)stoppedAt=Instant.now();
                    statusMessage="Browser closed. Steps remain available to edit and export.";
                    old=browserRecorder;browserRecorder=null;snapshot();
                }
                if(old!=null)background.execute(old::close);
                replyState(e);return;
            }
            if (path.startsWith("/api/") && !Set.of("GET","POST").contains(method)) {fail(e,405,"Method not allowed");return;}
            fail(e,404,"Not found");
        } catch (IllegalArgumentException ex) {
            fail(e,400,ex.getMessage());
        } catch (Exception ex) {
            System.err.println("Recorder API error: " + ex);
            try {fail(e,500,ex.getMessage()==null?"Unexpected error":ex.getMessage());}catch(Exception ignored){}
        } finally {e.close();}
    }
    private void pause(HttpExchange e) throws IOException {
        BrowserRecorder current;
        synchronized(lock){current=status.equals("recording")?browserRecorder:null;}
        if(current!=null)current.flushPendingInputs();
        synchronized(lock) {
            if(status.equals("recording")){status="paused";statusMessage="Recording paused. Browser interactions will not be saved.";snapshot();}
        }
        replyState(e);
    }
    private void stop(HttpExchange e) throws IOException {
        BrowserRecorder current;
        synchronized(lock){current=status.equals("recording")||status.equals("starting")?browserRecorder:null;}
        if(current!=null)current.flushPendingInputs();
        synchronized(lock) {
            if(Set.of("recording","starting","paused").contains(status)){
                status="stopped";stoppedAt=Instant.now();
                statusMessage="Recording stopped. Review your steps and export clean JSON.";snapshot();
            }
        }
        replyState(e);
    }
    private void launch(HttpExchange e, Map<String,String> data) throws IOException {
        String url=data.getOrDefault("url","").trim();URI uri;
        try {
            uri=URI.create(url);
            if (!("http".equalsIgnoreCase(uri.getScheme())||"https".equalsIgnoreCase(uri.getScheme())) ||
                uri.getHost()==null || uri.getUserInfo()!=null || url.length()>4096) throw new Exception();
        } catch(Exception ex){fail(e,400,"Enter a valid HTTP/HTTPS URL");return;}
        String browserChoice=data.getOrDefault("browser","auto");
        if(!Set.of("auto","chrome","edge").contains(browserChoice)){fail(e,400,"Invalid browser");return;}
        String name=data.getOrDefault("name","New UI test").trim();
        if(name.isBlank()||name.length()>120){fail(e,400,"Invalid test name");return;}
        boolean scroll="true".equals(data.get("scroll")),hover="true".equals(data.get("hover"));
        boolean deep="true".equals(data.get("deepDom"));
        Map<String,Object> opts=Json.map("captureScroll",scroll,"captureHover",hover,"deepDom",deep,
            "debugMaxNodes",Integer.getInteger("recorder.debugMaxNodes",400));
        String script="window.__eliyaRecorderSettings="+Json.stringify(opts)+";\n"+scriptBody;
        BrowserRecorder old,current;String id;
        synchronized(lock){
            if(Set.of("starting","recording","paused").contains(status)){fail(e,409,"Stop the existing recording first");return;}
            old=browserRecorder;book.clear();
            sessionId=UUID.randomUUID().toString();id=sessionId;
            appUrl=url;caseName=name;browserName="";deepDom=deep;
            status="starting";statusMessage="Launching installed browser...";
            startedAt=Instant.now();stoppedAt=null;autosave=createAutosave(id);
            current=new BrowserRecorder(script,(tab,action)->receiveAction(id,tab,action));
            browserRecorder=current;
        }
        background.execute(()->{
            if(old!=null)old.close();
            try{
                String detected=current.launch(url,browserChoice);
                synchronized(lock){
                    if(!sessionId.equals(id)){current.close();return;}
                    browserName=detected;
                    if(status.equals("starting")){status="recording";statusMessage="Recording clean test steps in "+detected;}
                    snapshot();
                }
            }catch(Exception ex){
                synchronized(lock){if(sessionId.equals(id)&&status.equals("starting")){
                    status="error";statusMessage=ex.getMessage();snapshot();}}
                current.close();
            }
        });
        reply(e,202,"application/json",Json.stringify(state()));
    }
    private static Path createAutosave(String id) throws IOException {
        Path dir=Path.of(System.getProperty("user.home"),".eliya-ui-recorder","sessions");
        Files.createDirectories(dir);
        try{Files.setPosixFilePermissions(dir,EnumSet.of(PosixFilePermission.OWNER_READ,
            PosixFilePermission.OWNER_WRITE,PosixFilePermission.OWNER_EXECUTE));}
        catch(UnsupportedOperationException ignored){}
        Path file=dir.resolve(id+".json");
        return file;
    }
    private void receiveAction(String id,String tab,Map<String,Object> raw){
        synchronized(lock){
            if(!id.equals(sessionId)||!Set.of("starting","recording").contains(status))return;
            if(raw.containsKey("frameId")){
                Map<String,Object> target=new LinkedHashMap<>(Json.object(raw.get("target")));
                Map<String,Object> frame=new LinkedHashMap<>(Json.object(target.get("frame")));
                frame.put("frameId",raw.get("frameId"));target.put("frame",frame);
                raw.put("target",target);
            }
            if(book.accept(tab,raw))snapshot();
        }
    }
    private void snapshot(){
        if(autosave==null||sessionId.isBlank())return;
        try{
            Map<String,Object> doc=document(false);
            Path temporary=autosave.resolveSibling(autosave.getFileName()+".tmp");
            Files.writeString(temporary,Json.pretty(doc)+"\n",StandardCharsets.UTF_8);
            try{Files.move(temporary,autosave,StandardCopyOption.REPLACE_EXISTING,StandardCopyOption.ATOMIC_MOVE);}
            catch(AtomicMoveNotSupportedException ex){Files.move(temporary,autosave,StandardCopyOption.REPLACE_EXISTING);}
            try{Files.setPosixFilePermissions(autosave,EnumSet.of(PosixFilePermission.OWNER_READ,PosixFilePermission.OWNER_WRITE));}
            catch(UnsupportedOperationException ignored){}
        }catch(IOException ex){statusMessage="Recording continues but local autosave failed: "+ex.getMessage();}
    }
    private Map<String,Object> document(boolean diagnostics){
        List<Map<String,Object>> steps=book.exportSteps(diagnostics);
        int assertions=0;for(Map<String,Object> step:steps)
            if(Json.str(step.get("action")).startsWith("assert"))assertions++;
        return Json.map("schemaVersion","2.0","format","eliya-automation-test",
            "testCase",Json.map("name",caseName,"startUrl",safeApplicationUrl(appUrl),"browser",browserName,
                "recordedAt",startedAt==null?null:startedAt.toString()),
            "summary",Json.map("stepCount",steps.size(),"assertionCount",assertions),
            "steps",steps);
    }
    private Map<String,Object> state(){
        synchronized(lock){
            List<Map<String,Object>> preview=new ArrayList<>();
            for(int i=Math.max(0,book.size()-150);i<book.size();i++){
                Map<String,Object> raw=book.all().get(i),item=new LinkedHashMap<>();
                item.put("step",i+1);
                for(String key:List.of("id","action","description","target","value","checked","key","assertion","expected","url","tab","waitMs"))
                    if(raw.containsKey(key))item.put(key,raw.get(key));
                preview.add(item);
            }
            return Json.map("status",status,"message",statusMessage,"url",appUrl,"name",caseName,
                "browser",browserName,"startedAt",startedAt==null?null:startedAt.toString(),
                "stoppedAt",stoppedAt==null?null:stoppedAt.toString(),"stepCount",book.size(),
                "steps",preview,"sessionId",sessionId,"deepDom",deepDom,
                "autosavePath",autosave==null?"":autosave.toString());
        }
    }
    /** Strip credentials and security-sensitive query parameter values from exported start URLs. */
    /** Strip secret query values while preserving benign path and query fields. */
    private static String safeApplicationUrl(String url) {
        try {
            URI u = URI.create(url);
            String query = u.getRawQuery();
            if (query == null) return url.replaceAll("(?i)([#?&](?:access_token|id_token|token|secret|password|code|session|api_key)=)[^&#]*", "$1[REDACTED]");
            List<String> parts = new ArrayList<>();
            for (String part : query.split("&", -1)) {
                String[] kv = part.split("=", 2);
                String key = URLDecoder.decode(kv[0], StandardCharsets.UTF_8).toLowerCase(Locale.ROOT);
                if (key.matches(".*(pass|secret|token|auth|api.?key|session|cookie|bearer|otp|csrf|private).*"))
                    parts.add(kv[0] + "=[REDACTED]");
                else parts.add(part);
            }
            return url.substring(0, url.indexOf('?') + 1) + String.join("&", parts) +
                (u.getRawFragment() == null ? "" : "#" + u.getRawFragment());
        } catch (Exception ex) { return url; }
    }

    private void export(HttpExchange e,boolean diagnostics) throws IOException {
        Map<String,Object> doc;Instant start;
        synchronized(lock){if(sessionId.isBlank()){fail(e,409,"No session recorded");return;}
            doc=document(diagnostics);start=startedAt;}
        String filename="eliya-"+(diagnostics?"diagnostic":"test-steps")+"-"+FILE_TIME.format(start)+".json";
        e.getResponseHeaders().set("Content-Disposition","attachment; filename=\""+filename+"\"");
        reply(e,200,"application/json; charset=utf-8",Json.pretty(doc)+"\n");
    }
    private void replyState(HttpExchange e) throws IOException{reply(e,200,"application/json",Json.stringify(state()));}
    private static void fail(HttpExchange e,int code,String message) throws IOException{
        reply(e,code,"application/json",Json.stringify(Json.map("error",message)));
    }
    private boolean validHost(HttpExchange e){
        String host=e.getRequestHeaders().getFirst("Host");if(host==null)return false;
        String h=host.split(":",2)[0].toLowerCase(Locale.ROOT);
        return h.equals("127.0.0.1")||h.equals("localhost")||h.equals("[::1]");
    }
    private boolean validOrigin(HttpExchange e){
        String origin=e.getRequestHeaders().getFirst("Origin");if(origin==null)return false;
        try{URI u=URI.create(origin);return u.getScheme().equals("http")&&
            Set.of("127.0.0.1","localhost","::1").contains(u.getHost()) &&
            u.getPort()==server.getAddress().getPort();}catch(Exception ex){return false;}
    }
    private static Map<String,String> parseQuery(String q){
        Map<String,String> data=new LinkedHashMap<>();if(q==null||q.length()>2048)return data;
        for(String item:q.split("&")){String[] kv=item.split("=",2);
            data.put(URLDecoder.decode(kv[0],StandardCharsets.UTF_8),kv.length>1?URLDecoder.decode(kv[1],StandardCharsets.UTF_8):"");}
        return data;
    }
    private static Map<String,String> readForm(HttpExchange e) throws IOException{
        byte[] bytes=e.getRequestBody().readNBytes(16385);
        if(bytes.length>16384)throw new IllegalArgumentException("Form data exceeds 16 KB");
        return parseQuery(new String(bytes,StandardCharsets.UTF_8));
    }
    private static void reply(HttpExchange e,int code,String type,String content) throws IOException{
        reply(e,code,type,content.getBytes(StandardCharsets.UTF_8));
    }
    private static void reply(HttpExchange e,int code,String type,byte[] bytes) throws IOException{
        e.getResponseHeaders().set("Content-Type",type);
        e.getResponseHeaders().set("Cache-Control","no-store");
        e.getResponseHeaders().set("X-Content-Type-Options","nosniff");
        e.getResponseHeaders().set("X-Frame-Options","DENY");
        e.getResponseHeaders().set("Content-Security-Policy","default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; connect-src 'self'; img-src 'self' data:; object-src 'none'; frame-ancestors 'none'");
        if(code==204){e.sendResponseHeaders(code,-1);return;}
        e.sendResponseHeaders(code,bytes.length);
        try(OutputStream out=e.getResponseBody()){out.write(bytes);}
    }
    private void shutdown(){
        BrowserRecorder current;
        synchronized(lock){current=browserRecorder;browserRecorder=null;}
        if(current!=null)current.close();
        if(server!=null)server.stop(0);
        background.shutdownNow();
    }
}
