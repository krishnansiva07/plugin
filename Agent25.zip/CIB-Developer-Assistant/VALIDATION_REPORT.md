# Validation Report — CIB Developer Assistant

Validation date: 2026-09-15

## Package status

**READY FOR USER VALIDATION.**

The dependency-independent checks below pass. A complete Spring Boot/Maven dependency-backed build could not be run in this sandbox because Maven bootstrap cannot resolve `repo.maven.apache.org`. Run the included local validation on a machine with dependency access before production use.

## Passed checks

- Frontend JavaScript syntax: PASS
  - `node --check src/main/resources/static/app.js`
  - `node --check src/main/resources/static/markdown.js`
- Shell syntax: PASS
  - `run.sh`
  - `validate-local.sh`
  - `mvnw`
- `pom.xml` XML parse: PASS
- `index.html` parser check: PASS
- Java 17 language/syntax scan: PASS for syntax/language-level diagnostics
  - source scanned with `javac --release 17 -proc:none -XDrawDiagnostics`
  - diagnostics were dependency-resolution errors only (Spring/Jackson/JPA/Tika/POI are not available in this sandbox)
  - no parser/language-level compiler diagnostics were detected
- Compiled-artifact hygiene: PASS
  - no `.class` files are shipped in the source tree
- Basic secret-literal scan: PASS
  - no OpenAI/GitHub/Google-style credential literals detected in production Java/static sources
- Hard-coded Windows path scan in Java production sources: PASS
- Visible product-version label scan: PASS
  - no `GPT24`, `GPT 24`, `Version:`, `App version` or `v24.` label in the application UI sources

## Dependency-independent Java 17 core harness

Executable harness result: **`CORE_HARNESS_PASS`**.

Validated:

- known model context hints (`qwen3.8-27b` 262144; `gpt-oss-120b-ITG` 131072)
- embedding-model capability recognition
- user-defined model type metadata for Vision/Embedding
- user-defined per-model context-window override
- Chat-model selection is distinct from the Agent execution model
- an approved plan cannot report successful completion while retained steps remain incomplete
- blocked runs stay below 100% progress
- mutation steps cannot complete until the current workspace revision has successful verification evidence
- genuinely completed/persisted runs become 100%
- Agent-run state/progress persists and reloads from durable run storage
- very large command output is bounded with explicit truncation evidence

## Planning/execution hardening verified

Source/syntax inspection confirms:

- Chat and Agent model selections are separate
- images are accepted in **Chat mode only**; Agent rejects image attachments and instructs the user to analyse them with a vision-capable Chat model first
- structured planning uses title/objective/files/validation/dependencies/risk fields and the UI renders structured plan cards
- task complexity controls the requested plan size instead of forcing a fixed plan length
- independent plan validation supports `NEEDS_EVIDENCE`
- recovery validation can request exact repository evidence rather than repeatedly rejecting an ungrounded plan
- output-token truncation (`finish_reason`) is treated as a continuation condition rather than immediately as executor failure
- deferred tool discovery via `tool_search` keeps the default tool surface smaller
- MCP schemas are not injected into every model turn by default
- workspace retrieval is invalidated after direct/detected mutations so later discovery does not rely on the pre-edit cache
- progress remains plan/evidence-derived and terminal blocked/failed/cancelled runs do not misleadingly jump to 100%
- ordered executor fallbacks and recovery replanning remain available when genuine execution recovery is required

## Maven build limitation in this environment

Attempted:

```text
./mvnw -version
```

Result:

```text
Maven was not found. Bootstrapping Apache Maven 3.9.11...
curl: (6) Could not resolve host: repo.maven.apache.org
```

Therefore this report does **not** claim a complete Spring Boot `clean install` or the full JUnit suite in this sandbox.

## Required validation on your machine

Windows:

```bat
validate-local.bat
mvnw.cmd -Pfull-tests test
```

Linux/macOS:

```bash
./validate-local.sh
./mvnw -Pfull-tests test
```

A successful normal build should produce:

```text
target/advanced-ai-workbench.jar
```
