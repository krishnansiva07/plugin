# Coding-agent flow alignment

The application is intentionally aligned with the practical interaction patterns users expect from modern coding agents such as OpenCode and Claude-style coding workflows, while retaining a local Java 17/Spring Boot implementation and explicit runtime safeguards.

| Area | Implemented behavior |
|---|---|
| Prompt-driven workspace | Explicit current-prompt path is authoritative; follow-up work can reuse the active local workspace |
| Role-based harness | Separate indexing/retrieval, read-only analysis, planning, independent plan validation, execution and completion review roles; image analysis stays in user-selected Chat mode |
| Editable model library | Defaults are provided, but users can add, rename, change type/context, remove and assign arbitrary OpenAI-compatible model IDs |
| Executor failover | Ordered fallbacks inherit the same active plan step, live workspace, current diff, verifier state and durable task context rather than restarting the task |
| Executor-pool recovery | After all executors fail, a separate analysis → remaining-work replan → independent validation cycle can restart the executor pool while preserving completed steps and valid edits; external blockers stop safely |
| Plan-first workflow | Evidence -> analysis -> plan -> independent validation -> formatted human review -> sequential execution |
| Editable plan | User can edit, add, remove and reorder the draft before approval; approved plan becomes a sequential runtime contract |
| Multiple resources | Primary workspace plus separately role-scoped additional paths |
| Parallelism | Independent read/search calls can run concurrently; dependent mutations remain ordered |
| Subagents | Fresh-context delegated investigation with bounded tool protocol |
| MCP / LSP | Lazy MCP tool discovery plus language-server support when configured |
| Tool context | Large observations are bounded and superseded/old outputs are pruned |
| Workspace retrieval | Local lexical index is always available; configured embeddings can semantically rerank the strongest candidates with automatic lexical fallback |
| Durable state | Objective, plan, validation, active model, failovers, verification, touched paths and activity timeline live outside active transcript |
| Conversation resume | Older conversations load messages first; optional run/project/file metadata cannot block the chat, and persisted Agent state is reattached when available |
| Live progress | Stage strip, plan-derived percentage, current activity, model/failover state and per-step evidence update while work is running |
| Compaction | Adaptive reserved-headroom estimate -> deterministic/periodic semantic checkpoint -> recent tail |
| Constraint retention | Binding user constraints are explicitly preserved in checkpoints |
| Verification | Workspace-revision-aware build/test/check evidence before mutation steps can complete |
| No-op edits | Do not create synthetic mutation revisions |
| Loop control | Result-aware repeated-call and non-actionable-turn guards; identical no-progress behavior causes strategy/model change instead of endless repetition |
| Completion | Verified revision -> independent completion critic -> durable final response |
| Transport resilience | Final result is recoverable even if the streaming connection does not close |
| Productive work budget | No fixed ceiling on productive tool actions; bounded recovery limits prevent wasteful loops |

The target is behavioral quality and reliability rather than copying another product line-for-line. Performance work is concentrated on fewer irrelevant reads, hybrid retrieval, parallel safe reads, compact durable state, bounded role prompts, executor handoff without restarting completed steps, and UI rendering that updates incrementally instead of rebuilding the full transcript for every activity event.
