package com.llmart.llm.service;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Path;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

class AgentRunServiceTest {

    @TempDir
    Path temp;

    private AgentRunService service(String name) {
        return new AgentRunService(temp.resolve(name));
    }

    @Test
    void tracksPlanMutationDiffAndVerificationRevision() {
        AgentRunService service = service("plan");
        AgentRunService.AgentRun run = service.start("conversation", "project");

        run.setPlan(List.of("Inspect", "Edit", "Verify"));
        assertTrue(run.hasPlan());
        assertTrue(run.hasOpenPlanItems());

        run.updatePlan(1, "completed", "inspected");
        run.updatePlan(2, "completed", "changed");
        run.markMutation();
        assertFalse(run.diffReviewedCurrentRevision());
        run.markDiffReview();
        assertTrue(run.diffReviewedCurrentRevision());

        run.markVerificationAttempt(true, "build passed");
        assertTrue(run.verifiedCurrentRevision());
        run.updatePlan(3, "completed", "passed");
        assertFalse(run.hasOpenPlanItems());
    }

    @Test
    void cancellationIsIdempotentAndFinishedRunCannotBeCancelled() {
        AgentRunService service = service("cancel");
        AgentRunService.AgentRun running = service.start("conversation", null);
        assertTrue(service.cancel(running.id()));
        assertFalse(service.cancel(running.id()));
        assertThrows(AgentCancelledException.class, running::checkCancelled);

        AgentRunService.AgentRun completed = service.start("conversation", null);
        completed.finish("completed");
        assertFalse(service.cancel(completed.id()));
        assertEquals("completed", completed.snapshot().get("status"));
    }
    @Test
    void tracksProviderAndCompactionTokenTelemetry() {
        AgentRunService service = service("tokens");
        AgentRunService.AgentRun run = service.start("conversation", "project");

        run.recordContextEstimate(42_000, 131_072);
        run.recordModelUsage(new OpenAiCompatibleClient.Usage(40_000, 1_500, 41_500, 20_000, 0, true), 42_000);
        run.recordCompaction(25_000, "Proactive checkpoint");
        run.recordPruning(9, 5_500);
        run.markRepeatedCallPrevented();

        assertEquals(1, run.modelCalls());
        assertEquals(41_500, run.providerTotalTokens());
        assertEquals(20_000, run.cachedInputTokens());
        assertEquals(1, run.compactions());
        var usage = (java.util.Map<?,?>) run.snapshot().get("tokenUsage");
        assertEquals(42_000L, usage.get("currentContextTokens"));
        assertEquals(25_000L, usage.get("estimatedTokensSavedByCompaction"));
        assertEquals(9L, usage.get("prunedObservations"));
        assertEquals(5_500L, usage.get("estimatedTokensSavedByPruning"));
        assertTrue(((Number) usage.get("cacheHitPercent")).doubleValue() > 0);
        assertEquals(1L, usage.get("repeatedCallsPrevented"));
    }

    @Test
    void progressIsMonotonicAndTerminalAnswerIsDurable() {
        AgentRunService service = service("progress");
        AgentRunService.AgentRun run = service.start("conversation", "project");

        run.updateProgress(35, "inspecting", "Reading files");
        run.updateProgress(10, "starting", "Older event");
        assertEquals(35, run.progressPercent(), "progress must never move backwards");
        assertEquals("inspecting", run.progressPhase(), "stale lower progress must not rewind the visible phase");

        run.markFinalAnswer("Completed requested change");
        run.finish("completed");
        assertTrue(run.finished());
        assertFalse(run.responsePersisted());
        assertEquals(98, run.progressPercent());

        run.markResponsePersisted("42", "Completed requested change");
        assertTrue(run.responsePersisted());
        assertEquals(100, run.progressPercent());
        assertEquals("completed", run.progressPhase());
        assertEquals("42", run.assistantMessageId());
        assertEquals("Completed requested change", run.snapshot().get("finalAnswer"));
    }

    @Test
    void planStatePersistsAcrossRunReload() {
        Path store = temp.resolve("plan-reload");
        AgentRunService first = new AgentRunService(store);
        AgentRunService.AgentRun run = first.start("conversation", "project");
        run.setPlan(List.of("Inspect", "Implement", "Verify"));
        run.markPlanStarted();
        run.recordPlanToolActivity("read");
        run.updatePlan(1, "completed", "inspected");
        run.updatePlan(2, "in_progress", "editing");

        AgentRunService reloaded = new AgentRunService(store);
        AgentRunService.AgentRun restored = reloaded.require(run.id());
        String plan = restored.planText();
        assertTrue(plan.contains("[completed] Inspect"));
        assertTrue(plan.contains("[in_progress] Implement"));
        assertTrue(plan.contains("[pending] Verify"));
    }

    @Test
    void reloadMarksInFlightRunInterruptedAndPreservesFinalState() {
        Path store = temp.resolve("restart");
        AgentRunService first = new AgentRunService(store);
        AgentRunService.AgentRun run = first.start("conversation", "project");
        run.updateProgress(54, "implementing", "Editing files");
        run.markMutation();

        AgentRunService reloaded = new AgentRunService(store);
        AgentRunService.AgentRun restored = reloaded.require(run.id());

        assertTrue(restored.finished());
        assertEquals("interrupted", restored.snapshot().get("status"));
        assertEquals(54, restored.progressPercent());
        assertTrue(restored.finalAnswer().toLowerCase().contains("restart"));
        assertEquals(1, restored.mutationRevision());
    }

    @Test
    void approvedPlanIsSequentialAndModelFailoverPreservesActiveStep() {
        AgentRunService service = service("sequential-failover");
        AgentRunService.AgentRun run = service.start("conversation", "project");
        run.configureModelPool(List.of("model-a", "model-b", "model-c", "model-b"));
        run.setPlan(List.of("Inspect", "Implement", "Verify"));
        run.markPlanStarted();

        assertEquals(1, run.activePlanIndex());
        assertThrows(IllegalStateException.class, () -> run.updatePlan(2, "in_progress", "jump"));
        assertThrows(IllegalStateException.class, () -> run.updatePlan(1, "completed", "no evidence"));

        run.recordPlanToolActivity("read");
        run.updatePlan(1, "completed", "inspected");
        assertEquals(2, run.activePlanIndex());

        run.recordPlanToolActivity("edit");
        run.markMutation(true);
        assertThrows(IllegalStateException.class, () -> run.updatePlan(2, "completed", "not verified"));
        run.markVerificationAttempt(true, "targeted test passed");
        run.updatePlan(2, "completed", "verified");
        assertEquals(3, run.activePlanIndex());

        assertTrue(run.switchToNextModel("primary unavailable"));
        assertEquals("model-b", run.activeModel());
        assertEquals(3, run.activePlanIndex());
        assertEquals(1, run.modelFailovers());
        assertEquals(List.of("model-a", "model-b", "model-c"), run.modelPool());
    }

    @Test
    void draftPlanCanBeEditedBeforeApprovalButNotAfterExecutionStarts() {
        AgentRunService service = service("editable-plan");
        AgentRunService.AgentRun run = service.start("conversation", "project");
        run.setPlan(List.of("Old one", "Old two"));

        run.replaceDraftPlan(List.of("Inspect actual failure", "Implement focused fix", "Verify targeted behavior"));
        assertTrue(run.planText().contains("Inspect actual failure"));
        assertFalse(run.planText().contains("Old one"));

        run.markPlanStarted();
        assertThrows(IllegalStateException.class, () -> run.replaceDraftPlan(List.of("Rewrite after approval")));
    }

    @Test
    void durableObjectiveTouchedPathsAndPlanSurviveReload() {
        Path store = temp.resolve("durable-context");
        AgentRunService first = new AgentRunService(store);
        AgentRunService.AgentRun run = first.start("conversation", "project");
        run.setObjective("Reduce token waste without losing the active task");
        run.configureModelPool(List.of("model-a", "model-b"));
        run.setPlan(List.of("Inspect", "Implement", "Verify"));
        run.markPlanStarted();
        run.recordTouchedPaths(List.of("src/main/java/A.java", "pom.xml"));
        run.recordPlanToolActivity("read");
        run.markMutation(true);

        String state = run.durableContextText();
        assertTrue(state.contains("Reduce token waste"));
        assertTrue(state.contains("src/main/java/A.java"));
        assertTrue(state.contains("activePlanIndex: 1"));

        AgentRunService restoredService = new AgentRunService(store);
        AgentRunService.AgentRun restored = restoredService.require(run.id());
        assertEquals(run.objective(), restored.objective());
        assertTrue(restored.touchedPaths().contains("pom.xml"));
        assertTrue(restored.durableContextText().contains("verificationRequired=true"));
    }

    @Test
    void approvedPlanOwnsProgressAndCannotSkipSteps() {
        AgentRunService service = service("plan-progress");
        AgentRunService.AgentRun run = service.start("conversation", "project");
        run.setPlan(List.of("✅", "→", "1. Inspect target", "Implement fix", "Verify behavior"));
        assertEquals(3, ((java.util.List<?>) run.snapshot().get("plan")).size(), "symbol-only decoration must not become plan steps");
        run.markPlanStarted();

        int starting = run.progressPercent();
        assertEquals(15, starting);
        run.updateProgress(88, "verifying", "A tool tried to jump progress");
        assertEquals(starting, run.progressPercent(), "tool activity must not outrun approved plan completion");
        assertEquals("verifying", run.progressPhase());
        assertThrows(IllegalStateException.class, () -> run.updatePlan(1, "skipped", "skip"));

        run.recordPlanToolActivity("read", "Inspected the active implementation and runner");
        assertTrue(run.progressPercent() > starting, "live progress should move within an active step after real tool activity");
        run.updatePlan(1, "completed", "");
        assertEquals(2, run.activePlanIndex());
        assertTrue(run.progressPercent() > starting);
        assertTrue(run.progressPercent() < 88);
    }

    @Test
    void successfulFinishRequiresEveryApprovedStepCompleted() {
        AgentRunService service = service("finish-contract");
        AgentRunService.AgentRun run = service.start("conversation", "project");
        run.setPlan(List.of("Inspect", "Implement"));
        run.markPlanStarted();
        run.recordPlanToolActivity("read", "Inspection complete");
        run.updatePlan(1, "completed", "Inspection complete");

        run.finish("completed");
        assertEquals("blocked", run.snapshot().get("status"));
        assertTrue(run.progressPercent() < 100, "blocked is terminal, not successful 100% completion");
        run.markResponsePersisted("blocked-message", "Blocked because the approved plan is incomplete");
        assertTrue(run.progressPercent() < 100, "persisting a blocked response must not turn failure into 100% completion");
        assertTrue(String.valueOf(run.snapshot().get("tokenUsage")).contains("Approved plan is incomplete"));
    }

    @Test
    void planEvidencePersistsAndLatestConversationRunCanBeRestored() {
        Path store = temp.resolve("evidence");
        AgentRunService first = new AgentRunService(store);
        AgentRunService.AgentRun run = first.start("conversation-1", "project");
        run.setPlan(List.of("Inspect implementation", "Verify behavior"));
        run.markPlanStarted();
        run.recordPlanToolActivity("read", "Read LoginPage.java and runner configuration");
        run.recordPlanToolActivity("grep", "Found the affected locator in one page object");
        run.updatePlan(1, "completed", "");

        AgentRunService restoredService = new AgentRunService(store);
        var latest = restoredService.latestForConversation("conversation-1").orElseThrow();
        var plan = (java.util.List<?>) latest.get("plan");
        var firstStep = (java.util.Map<?,?>) plan.get(0);
        var evidence = (java.util.List<?>) firstStep.get("evidence");
        assertEquals("completed", firstStep.get("status"));
        assertFalse(evidence.isEmpty());
        assertTrue(evidence.stream().anyMatch(line -> String.valueOf(line).contains("LoginPage.java")));
    }

    @Test
    void recoveryReplanPreservesCompletedStepsAndRestartsPrimaryModel() {
        Path store = temp.resolve("recovery-replan");
        AgentRunService service = new AgentRunService(store);
        AgentRunService.AgentRun run = service.start("conversation", "project");
        run.configureModelPool(List.of("primary", "fallback-a", "fallback-b"));
        run.setPlan(List.of("Inspect current implementation", "Implement original approach", "Verify behavior"));
        run.markPlanStarted();

        run.recordPlanToolActivity("read", "Inspected relevant classes");
        run.updatePlan(1, "completed", "Inspection complete");
        assertEquals(2, run.activePlanIndex());
        assertTrue(run.switchToNextModel("primary stalled"));
        assertTrue(run.switchToNextModel("fallback-a stalled"));
        assertEquals("fallback-b", run.activeModel());

        run.reviseRemainingPlan(List.of(
                "Implement the corrected approach using current workspace evidence and preserve valid partial edits",
                "Run targeted verification and review the final workspace diff"),
                "Original approach targeted the wrong code path");
        run.recordRecoveryReplan("Wrong code path identified from current workspace evidence");
        assertTrue(run.restartModelCycle("validated recovery plan"));

        assertEquals("primary", run.activeModel());
        assertEquals(1, run.recoveryReplans());
        assertEquals(2, run.activePlanIndex());
        var plan = run.planSnapshot();
        assertEquals(3, plan.size());
        assertEquals("completed", plan.get(0).get("status"));
        assertEquals("in_progress", plan.get(1).get("status"));
        assertTrue(String.valueOf(plan.get(1).get("note")).contains("Recovery replan"));
        assertFalse(run.durableContextText().contains("Implement original approach"));
        assertTrue(run.durableContextText().contains("recoveryReplans=1"));

        AgentRunService restoredService = new AgentRunService(store);
        AgentRunService.AgentRun restored = restoredService.require(run.id());
        assertEquals(1, restored.recoveryReplans());
        assertTrue(restored.lastRecoveryAnalysis().contains("Wrong code path"));
        assertEquals("primary", restored.activeModel());
        assertEquals(2, restored.activePlanIndex());
    }

    @Test
    void activityTimelineAndPlanValidationPersistForConversationHistory() {
        Path store = temp.resolve("activity-history");
        AgentRunService first = new AgentRunService(store);
        AgentRunService.AgentRun run = first.start("conversation-history", "project");
        run.setPlanValidation("approved", "Grounded, ordered and verifiable.");
        run.recordActivityEvent(Map.of(
                "step", 0, "tool", "analysis", "status", "success",
                "detail", "Independent workspace analysis complete", "output", "Relevant runner and page object identified"));
        run.recordActivityEvent(Map.of(
                "step", 0, "tool", "plan_validation", "status", "success",
                "detail", "Plan validator approved the execution plan"));

        AgentRunService restoredService = new AgentRunService(store);
        var snapshots = restoredService.forConversation("conversation-history");
        assertEquals(1, snapshots.size());
        var snapshot = snapshots.get(0);
        assertEquals("approved", snapshot.get("planValidationStatus"));
        assertTrue(String.valueOf(snapshot.get("planValidationSummary")).contains("Grounded"));
        var activity = (java.util.List<?>) snapshot.get("activityEvents");
        assertEquals(2, activity.size());
        assertTrue(String.valueOf(activity.get(0)).contains("workspace analysis"));
        assertTrue(String.valueOf(activity.get(1)).contains("Plan validator"));
    }

}
