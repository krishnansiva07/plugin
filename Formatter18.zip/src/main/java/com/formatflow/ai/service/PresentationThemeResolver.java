package com.formatflow.ai.service;

import java.awt.Color;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Converts a free-form presentation design request into a safe renderer theme.
 * The prompt can influence palette and typography, while slide geometry remains
 * constrained to the PowerPoint-native layouts supported by ExportService.
 */
public final class PresentationThemeResolver {

    private static final Pattern HEX = Pattern.compile("#([0-9a-fA-F]{6})");

    private PresentationThemeResolver() {}

    public static PresentationTheme resolve(String visualStyle, String designPrompt) {
        String combined = ((visualStyle == null ? "" : visualStyle) + " "
                + (designPrompt == null ? "" : designPrompt)).trim();
        String text = combined.toLowerCase(Locale.ROOT);

        Color accent = namedAccent(text);
        Matcher matcher = HEX.matcher(combined);
        if (matcher.find()) {
            accent = parseHex(matcher.group(1), accent);
        }

        Color accentDark = darken(accent, 0.66);
        Color title = darken(accent, 0.80);
        Color soft = blend(accent, Color.WHITE, text.contains("bold") || text.contains("vibrant") ? 0.86 : 0.91);
        Color surface = blend(accent, Color.WHITE, 0.965);
        Color border = blend(accent, Color.WHITE, 0.70);
        Color body = new Color(31, 41, 37);
        Color muted = new Color(83, 98, 90);
        Color canvas = Color.WHITE;

        // Keep the canvas light because several native layouts intentionally use
        // white content cards. A "dark" request therefore becomes an executive
        // dark-accent theme rather than an unreadable full-dark deck.
        if (containsAny(text, "dark", "black", "charcoal", "executive")) {
            accentDark = darken(accent, 0.42);
            title = darken(accent, 0.52);
            surface = new Color(246, 247, 248);
            soft = blend(accent, Color.WHITE, 0.88);
            border = blend(accent, Color.WHITE, 0.62);
        }
        if (containsAny(text, "minimal", "minimalist", "clean", "simple", "white space", "whitespace")) {
            soft = blend(accent, Color.WHITE, 0.95);
            surface = new Color(250, 251, 251);
            border = blend(accent, Color.WHITE, 0.80);
        }
        if (containsAny(text, "pastel", "soft", "calm")) {
            soft = blend(accent, Color.WHITE, 0.94);
            border = blend(accent, Color.WHITE, 0.78);
        }

        String font = resolveFont(text);
        return new PresentationTheme(accent, accentDark, title, soft, surface, border, body, muted, canvas, font);
    }

    private static Color namedAccent(String text) {
        if (containsAny(text, "navy", "midnight blue")) return new Color(31, 58, 104);
        if (containsAny(text, "blue", "azure", "cobalt")) return new Color(38, 104, 181);
        if (containsAny(text, "teal", "turquoise")) return new Color(0, 121, 140);
        if (containsAny(text, "purple", "violet", "plum")) return new Color(105, 72, 153);
        if (containsAny(text, "orange", "amber")) return new Color(214, 112, 24);
        if (containsAny(text, "red", "crimson", "burgundy")) return new Color(172, 52, 62);
        if (containsAny(text, "pink", "magenta")) return new Color(181, 67, 121);
        if (containsAny(text, "gold", "yellow")) return new Color(176, 125, 15);
        if (containsAny(text, "black", "monochrome", "charcoal")) return new Color(66, 73, 80);
        // Default remains the established BNP-green design.
        return new Color(0, 133, 66);
    }

    private static String resolveFont(String text) {
        if (containsAny(text, "aptos")) return "Aptos";
        if (containsAny(text, "calibri")) return "Calibri";
        if (containsAny(text, "georgia", "classic", "editorial")) return "Georgia";
        if (containsAny(text, "segoe")) return "Segoe UI";
        return "Arial";
    }

    private static boolean containsAny(String text, String... values) {
        for (String value : values) if (text.contains(value)) return true;
        return false;
    }

    private static Color parseHex(String value, Color fallback) {
        try {
            return new Color(Integer.parseInt(value, 16));
        } catch (RuntimeException ex) {
            return fallback;
        }
    }

    private static Color darken(Color color, double factor) {
        return new Color(
                clamp((int) Math.round(color.getRed() * factor)),
                clamp((int) Math.round(color.getGreen() * factor)),
                clamp((int) Math.round(color.getBlue() * factor))
        );
    }

    private static Color blend(Color a, Color b, double bWeight) {
        double aw = 1.0 - bWeight;
        return new Color(
                clamp((int) Math.round(a.getRed() * aw + b.getRed() * bWeight)),
                clamp((int) Math.round(a.getGreen() * aw + b.getGreen() * bWeight)),
                clamp((int) Math.round(a.getBlue() * aw + b.getBlue() * bWeight))
        );
    }

    private static int clamp(int value) {
        return Math.max(0, Math.min(255, value));
    }

    public record PresentationTheme(
            Color accent,
            Color accentDark,
            Color title,
            Color soft,
            Color surface,
            Color border,
            Color text,
            Color muted,
            Color canvas,
            String fontFamily
    ) {}
}
