package com.formatflow.ai.service;

import com.formatflow.ai.model.FormatModels.*;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * Primary formatting workflow.
 *
 * The previous implementation used a preserve-first metadata pipeline. That was
 * useful for strict source fidelity, but it prevented the model from producing
 * the reader-friendly Confluence output users get when prompting the model
 * directly. The active workflow now gives the model editorial freedom first and
 * then sanitizes/renders the result deterministically for the three supported
 * destinations: Confluence, Email, HTML and PowerPoint.
 */
@Service
public class FormattingService {

    private static final Set<String> SUPPORTED_FORMATS = Set.of("CONFLUENCE", "EMAIL", "HTML", "POWERPOINT");

    private final SessionKeyService sessionKeyService;
    private final ContentParser contentParser;
    private final LlmOrchestrator llmOrchestrator;
    private final AdaptiveSemanticOrchestrator adaptiveSemanticOrchestrator;
    private final SemanticPresentationPolicy semanticPresentationPolicy;
    private final DocumentAssemblyService documentAssemblyService;
    private final DocumentRenderer renderer;
    private final ContentDiffService diffService;

    public FormattingService(SessionKeyService sessionKeyService,
                             ContentParser contentParser,
                             LlmOrchestrator llmOrchestrator,
                             AdaptiveSemanticOrchestrator adaptiveSemanticOrchestrator,
                             SemanticPresentationPolicy semanticPresentationPolicy,
                             DocumentAssemblyService documentAssemblyService,
                             DocumentRenderer renderer,
                             ContentDiffService diffService) {
        this.sessionKeyService = sessionKeyService;
        this.contentParser = contentParser;
        this.llmOrchestrator = llmOrchestrator;
        // Kept as constructor dependencies for backward binary/source compatibility
        // with the existing project/tests. The new free-form path intentionally no
        // longer runs the old semantic validator after the model has edited content.
        this.adaptiveSemanticOrchestrator = adaptiveSemanticOrchestrator;
        this.semanticPresentationPolicy = semanticPresentationPolicy;
        this.documentAssemblyService = documentAssemblyService;
        this.renderer = renderer;
        this.diffService = diffService;
    }

    public FormatResult format(FormatRequest request, HttpSession session) {
        String stage = "initialization";
        try {
            stage = "LLM session validation";
            String apiKey = sessionKeyService.require(session);

            stage = "request normalization";
            String format = normalizeFormat(request.format());
            String operation = normalizeOperation(request.operation());

            stage = "LangGraph editorial generation";
            LlmOrchestrator.FreeformOutcome outcome = llmOrchestrator.freeform(
                    apiKey,
                    request.content(),
                    request.audience(),
                    request.purpose(),
                    format,
                    operation,
                    request.summaryLength(),
                    "POWERPOINT".equals(format) ? normalizeDesignPrompt(request.presentationDesignPrompt()) : ""
            );

            stage = "HTML sanitization";
            String sanitizedHtml = renderer.sanitizeFreeformHtml(outcome.html());

            stage = "destination structure normalization";
            // Confluence is normalized once into a canonical editor-safe tree.
            // Preview, clipboard HTML, plain-text projection and downloads all
            // derive from this same tree, preventing preview/copy drift.
            String destinationHtml = renderer.prepareDestinationHtml(sanitizedHtml, format);

            stage = "plain-text projection";
            String copyText = renderer.freeformCopyText(destinationHtml);
            if (copyText.isBlank()) {
                throw new IllegalStateException("The model response could not be converted into readable content.");
            }

            stage = "email subject generation";
            String subject = request.emailSubject() == null ? "" : request.emailSubject().trim();
            int llmCalls = outcome.llmCalls();
            if ("EMAIL".equals(format) && request.generateEmailSubject() && subject.isBlank()) {
                try {
                    subject = llmOrchestrator.generateEmailSubject(
                            apiKey,
                            copyText,
                            request.audience(),
                            request.purpose()
                    );
                    llmCalls++;
                } catch (RuntimeException subjectFailure) {
                    // Subject generation is optional enrichment. A model failure here
                    // must never discard an otherwise valid formatted email body.
                    subject = deterministicEmailSubject(copyText, request.purpose());
                    llmCalls++;
                }
            }

            stage = "destination rendering";
            String previewHtml = renderer.freeformPreviewHtml(destinationHtml, format, subject);
            String copyHtml = renderer.freeformCopyHtml(destinationHtml, format);

            stage = "content statistics";
            ContentStats stats = diffService.compare(request.content(), copyText);

            // The browser now downloads/copies the exact generated HTML directly.
            // A lightweight document object is still returned for API compatibility.
            FormattedDocument document = new FormattedDocument(
                    "",
                    List.of(),
                    List.of(),
                    copyText,
                    request.audience(),
                    request.purpose() == null || request.purpose().isBlank() ? "General" : request.purpose(),
                    format,
                    operation,
                    true,
                    subject,
                    "POWERPOINT".equals(format) ? normalizeDesignPrompt(request.presentationDesignPrompt()) : ""
            );

            stage = "source metrics";
            int sourceBlocks = contentParser.parse(request.content()).size();
            String activity = outcome.workflowActivity();
            if ("CONFLUENCE".equals(format)) activity += " • Canonical Confluence renderer";
            ProcessingInfo processing = new ProcessingInfo(
                    sourceBlocks,
                    llmCalls,
                    outcome.chunks(),
                    outcome.chunks() > 1,
                    activity,
                    0,
                    List.of(),
                    false
            );

            return new FormatResult(
                    copyText,
                    previewHtml,
                    copyHtml,
                    copyText,
                    stats,
                    document,
                    processing
            );
        } catch (IllegalArgumentException | IllegalStateException ex) {
            throw ex;
        } catch (RuntimeException ex) {
            throw new IllegalStateException("Formatting failed during " + stage + ": " + safeMessage(ex), ex);
        }
    }

    private String normalizeDesignPrompt(String value) {
        if (value == null) return "";
        String normalized = value.replace('\u0000', ' ').replaceAll("\\s+", " ").trim();
        // The design prompt is guidance, not an unbounded second source document.
        return normalized.length() > 1200 ? normalized.substring(0, 1200).trim() : normalized;
    }

    private String deterministicEmailSubject(String copyText, String purpose) {
        String purposeText = purpose == null ? "" : purpose.replaceAll("\\s+", " ").trim();
        String firstLine = copyText == null ? "" : copyText.lines()
                .map(String::trim)
                .filter(v -> !v.isBlank())
                .findFirst()
                .orElse("");
        String subject = !purposeText.isBlank() ? purposeText : firstLine;
        if (subject.isBlank()) subject = "Formatted Update";
        if (subject.length() > 78) {
            int cut = subject.lastIndexOf(' ', 78);
            subject = subject.substring(0, cut > 35 ? cut : 78).trim();
        }
        return subject;
    }

    private String safeMessage(Throwable ex) {
        if (ex == null) return "Unknown error";
        String value = ex.getMessage();
        if (value == null || value.isBlank()) value = ex.getClass().getSimpleName();
        value = value.replace('\n', ' ').replace('\r', ' ').trim();
        return value.length() > 260 ? value.substring(0, 260) : value;
    }

    private String normalizeFormat(String value) {
        String format = value == null ? "" : value.trim().toUpperCase(Locale.ROOT);
        if (!SUPPORTED_FORMATS.contains(format)) {
            throw new IllegalArgumentException("Supported outputs are Confluence, Email, HTML and PowerPoint.");
        }
        return format;
    }

    private String normalizeOperation(String value) {
        String operation = value == null ? "FORMAT" : value.trim().toUpperCase(Locale.ROOT);
        return "SUMMARIZE".equals(operation) ? "SUMMARIZE" : "FORMAT";
    }
}
