# CIB Developer Assistant

Java 17 local coding and workspace agent with two interaction modes: **Chat** and **Agent**.

## Primary flow

Agent mode is designed for direct prompt-driven work:

1. Put an existing project or file path in the prompt.
2. The runtime resolves that explicit path as the primary live workspace, even if a different workspace was previously active.
3. Before drafting a plan, the runtime performs a **read-only workspace analysis**: project profile, resolved resources, instructions, file index, key descriptors/build files, and focused searches derived from the task.
4. The model creates a **detailed draft plan from that evidence**, not by simply paraphrasing the prompt. Decoration-only bullets/emoji/status symbols are filtered so only executable text becomes a planned step. The plan editor lets the user edit, reorder, add, remove, or unselect steps before execution.
5. By default execution waits for **Approve plan & run step 1**. Approval locks the edited plan as an execution contract. Exactly one plan step is active at a time: the agent performs real tool work for that step, records step evidence, verifies any code/config mutation, completes the step, and only then unlocks the next step. Retained approved steps cannot be silently skipped, and a run cannot finish successfully while an approved step is incomplete.
6. The configured execution model handles coding/tool work. When smart routing is enabled, planning, completion review, vision, and semantic retrieval can use dedicated configured models while preserving the same workspace, approved plan, active step, and persisted run state. Optional execution fallbacks inherit that state when the active execution model is unavailable or exhausts its recovery budget.
- **Executor-pool recovery replan** uses separate analysis, planning and validation roles to replace only unfinished work after all execution models are exhausted, while preserving completed steps and valid edits.
7. The agent inspects targeted files, batches independent reads, edits the live workspace, executes the smallest useful build/test/check, repairs failures, and stops once the requested result is verified. Additional prompt paths are exposed as named resources with safe read/write roles.
8. A durable run record drives the progress bar and final completion state, so a stale SSE connection does not leave the UI waiting for a manual Stop click.

If a follow-up Agent prompt has no path, the current live workspace can be reused. If a new explicit path is supplied, that prompt path is authoritative and switches the active workspace.

## Long-running context management

The runtime uses a compact active context rather than resending the full historical transcript on every model call:

- proactive token estimation before each model call
- tool-schema tokens included in the estimate
- adaptive compaction based on usable input limit minus dynamic headroom; no fixed percentage trigger
- deterministic durable continuation checkpoints for most compactions
- periodic semantic checkpoint summarization (and forced-overflow summarization) instead of paying for a summary model call every time
- recent context tail retained after compaction
- only the two newest tool observations get the larger fresh-output allowance; older tool output is aggressively bounded
- superseded runtime recovery/verification/failover steering is removed instead of being resent for hundreds of turns
- Agent-mode **active model context** is deliberately bounded because the live workspace, approved plan, and run state are authoritative; persisted chat messages are not deleted by compaction
- provider input/output/cache usage captured when returned
- context-overflow recovery with one forced compaction attempt
- configurable adaptive non-actionable recovery attempts **per model** (default 10)
- configurable transient provider retries **per model** (default 10) before moving to the next configured fallback
- immediate model failover for explicit unavailable/unknown/unsupported-model errors instead of wasting the retry budget
- model failover preserves the approved plan, current step, workspace revisions, and durable run state
- repeated identical no-progress tool/model outcomes suppressed and redirected to a materially different strategy

Defaults are configurable in Settings. The default recent-context target is 8k tokens, the safety buffer is 20k tokens, and older tool observations default to a 1,200-character active-context cap. Context limits are resolved per active model, including role-routed and failover models. Workspace retrieval always has a local lexical baseline and can optionally rerank candidates with the configured embedding model; any embedding/provider failure falls back to lexical retrieval automatically. Durable objective/plan/model/verification/touched-file state is stored outside the active transcript and re-injected as a small suffix.

## Speed and quality controls

The Agent protocol emphasizes high-signal work rather than activity for its own sake:

- independent read/search calls are batched in one model turn and executed in parallel when safe
- targeted grep/index/range reads are preferred over broad recursive file dumps
- unchanged files should not be re-read without a reason
- exploratory subagents can use fresh context for independent investigation
- edits are no-op aware, avoiding synthetic revisions when content already matches
- verification is revision-aware and only a real changed revision requires a new verifier
- the smallest verifier that proves the requested change is preferred before broader suites
- successful verification triggers a dedicated completion check instead of open-ended extra investigation
- transient provider retries are bounded and cancellable
- foreground commands use process pipes rather than temporary output files, avoiding Windows log-file sharing locks
- common provider tool-name/schema drift is repaired at the runtime boundary (`search`→`grep`, noisy `read/<channel>...` names, `query`→`pattern`, OpenAI-style patch text) instead of wasting retries
- stale exact-text edits explain that the file changed and direct the model to re-read current text before retrying

## Agent progress

The Agent run view keeps the progress bar synchronized with the approved plan. During execution the percentage is derived from **completed approved plan steps**, while tool activity updates the phase/detail without jumping the percentage ahead. Completed steps retain compact tool evidence that can be expanded while later steps are still running.

Activity events are displayed separately from planned steps. The browser retains only a bounded recent activity window and throttles Agent-card rendering, preventing long runs with hundreds of tool/model events from repeatedly rebuilding the full conversation DOM. The terminal state becomes 100% only when the durable final response is available (or the run is terminally blocked/failed/cancelled).

Foreground shell/build/test output is also bounded in memory: small output is kept exactly, while very large output keeps the beginning and latest tail with an explicit truncation marker. Long-running foreground commands publish periodic activity heartbeats without advancing plan-derived progress, so Maven/Playwright/test runs do not appear frozen while they are still executing.

## UI

The main UI intentionally contains only **Chat** and **Agent** modes. Workspace selection is not a sidebar workflow; supply filesystem paths in Agent prompts.

Settings include execution and fallback models, smart planning/critic/vision/embedding routing, per-active-model context auto-detection, hybrid semantic retrieval, recovery controls, plan approval, permissions, MCP/subagent/LSP permissions, and optional additional shell commands. A one-click recommended model profile is available for the CIB model catalogue. User-message editing uses a large responsive editor for long prompts. The sidebar also includes a **Prompt library** with reusable Playwright MCP, Selenium/TestNG/Cucumber, Playwright, migration, development, testing, and agent-guidance prompts. In Agent mode the routing strip shows the execution model plus the planning, critic, vision, and retrieval routes before execution.

## Durable history and portable startup

The application JAR can still be copied and started from any folder:

```bat
java -jar advanced-ai-workbench.jar
```

Conversation history and durable Agent-run state are now stored independently from the extracted/JAR directory so replacing the application folder does not make old chats appear to disappear. The default per-user location is:

```text
Windows: %USERPROFILE%\.advanced-ai-workbench\
Linux/macOS: ~/.advanced-ai-workbench/
  data/
    chatdb.mv.db
    uploads/
    agent-cache/
    agent-runs/
  cache/
  logs/
```

On first use, if the old beside-JAR `data/` directory contains history and the new durable database does not yet exist, the runtime performs a best-effort non-overwriting migration. All locations remain overridable through the existing system properties such as `app.data-dir` and `advanced.ai.agentRunStore`.

## Build and run

Requirements:

- Java 17 or later
- Maven, or network access for the included Maven bootstrap script on first use

Windows:

```bat
validate-local.bat
run.bat
```

Linux/macOS:

```bash
./validate-local.sh
./run.sh
```

Normal `mvn install` / validation uses the release profile behavior and is **not blocked by optional environment-sensitive tests**. To run the complete test suite explicitly:

```bash
./mvnw -Pfull-tests test
```

On Windows use `mvnw.cmd -Pfull-tests test`.

The packaged JAR name is:

```text
target/advanced-ai-workbench.jar
```

## Example Agent prompts

```text
Project path: C:\work\payments-ui
Fix the failing login flow shown in the console error below. Inspect the project, implement the smallest correct fix, run the relevant tests, repair any failures, and stop as soon as the requested change is verified.
```

```text
Primary project: C:\work\new-playwright
Reference project: C:\work\old-selenium
Recorded flow: C:\work\recordings\payment.json
Use the Selenium project and recording as reference only. Implement the equivalent flow in the primary project, run it, fix failures, and verify the final result.
```

See `SAMPLE_PROMPTS.md` for more examples.
