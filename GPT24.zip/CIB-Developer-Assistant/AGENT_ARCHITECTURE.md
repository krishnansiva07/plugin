# Agent architecture

## Runtime path

```text
User prompt
   |
   +-- Chat ------------------------------------------------> normal model response
   |
   +-- Agent
        |
        +-- resolve explicit filesystem paths and durable workspace state
        +-- local lexical index + optional embedding rerank
        +-- Analysis model (read-only architecture/task synthesis)
        +-- Planning model (4-12 sequential executable steps)
        +-- Plan validator model
        |      +-- APPROVED -> formatted plan review UI
        |      +-- REVISE  -> planner receives validator feedback (bounded revisions)
        +-- user edits/adds/removes/reorders plan and approves
        +-- Execution model works only the active step
        |      +-- multiple independent read tools can run in parallel
        |      +-- mutation -> current workspace revision
        |      +-- build/test/check -> verifier evidence
        |      +-- executor failure -> ordered fallback model, same step/state/diff
        |      +-- all executors exhausted -> recovery analysis
        |             +-- genuine external blocker -> stop as blocked
        |             +-- recoverable strategy failure -> replan unfinished work only
        |                    +-- independent recovery-plan validation
        |                    +-- preserve completed steps/current valid edits
        |                    +-- restart executor chain from primary model
        +-- Completion critic model checks original request after verification
        +-- durable final result + durable activity timeline
        +-- history reopening restores messages, plan, progress, validation and activity
        +-- stale streaming transport is closed after durable completion
```

Model assignments are defaults, not hard-coded requirements. The Settings model library allows adding, renaming, editing context/type, removing models, and assigning any configured model to analysis, planning, validation, execution, completion review, vision or embeddings.

## Executor-pool exhaustion recovery

Executor fallbacks are not simple task restarts. Each fallback inherits the approved objective, completed plan steps, active step, live workspace, current diff, verifier state, retrieval hints and prior failure evidence. If every configured executor is exhausted, the harness invokes a bounded second-order recovery path instead of immediately giving up:

1. the Analysis role diagnoses whether the failure is recoverable or a genuine external/environment/credential blocker;
2. for recoverable failures, the Planning role rewrites only the unfinished portion of the approved plan;
3. the independent Plan Validator rejects repeated/ungrounded recovery strategies;
4. completed steps and valid current edits remain intact;
5. after validation, the executor model cycle restarts from the configured primary model on the new active recovery step.

Recovery replanning is deliberately bounded (two accepted replans per run, with bounded validator revisions) so the agent changes strategy without entering an endless planner/executor loop. Authentication failures are surfaced directly rather than wasting the fallback chain. Recovery state and diagnosis are durable and are restored with conversation history.

## Context lifecycle

Durable session history is retained separately from the active prompt sent to the model. Before a model request, the runtime estimates messages plus tool definitions. When the input is approaching the usable context limit, older history is replaced with a structured checkpoint and a recent tail is retained.

The checkpoint preserves objective, important details, binding user constraints, completed work, active work, blockers, next actions, relevant files, exact paths, verifier state, and key decisions. If semantic summarization fails, a deterministic fallback checkpoint is created so context maintenance cannot strand the run.

## Progress, live status and completion

Run state is independent of the HTTP streaming transport. The backend persists a bounded activity timeline together with the plan, validation result, active model, failover count, verification state and progress. The UI shows stage-level progress (Index → Analyse → Plan → Validate → Review → Execute → Verify → Complete), live activity text, current model and per-step evidence. During an active plan step, real tool activity advances a bounded portion of that step instead of leaving the bar visually frozen or pretending the step is already complete.

The backend persists the final assistant message first and then marks the run response as durable. The browser polls run state while streaming is active. If the durable terminal response exists but the HTTP/SSE stream remains open, the browser closes only the stale transport and immediately returns the composer to Send state.

Conversation reopening treats messages as authoritative and loads attachments, projects and Agent-run metadata independently. Optional old metadata failure therefore cannot prevent an older chat from opening. Persisted Agent activity/plan state is reattached to the corresponding assistant message when available, with an ordered fallback for older records that predate message identifiers/timestamps.

## No-progress protection

Productive work is not restricted by a fixed step ceiling. Instead, guards are tied to actual progress:

- same tool + same args + same normalized result + same workspace revision -> warning, then block
- repeated verifier outcome without a new revision -> change strategy or stop as blocked
- repeated non-actionable model output without tool/workspace progress -> stop
- no-op edits do not create a new workspace revision
- process polling is allowed a small extra repeat window because process output can legitimately remain unchanged briefly

## Workspace authority

An explicit primary path in the current Agent prompt overrides an older active workspace. If the current prompt contains no path, the active workspace may be reused for follow-up work. Additional paths remain separate resources so reference inputs are not accidentally treated as writable primary projects.


## Evidence-first editable planning

Planning is a role-based pipeline. The runtime gathers bounded read-only evidence, a separate analysis model summarizes architecture/constraints/risks, the planning model drafts 4-12 sequential executable steps, and an independent plan-validator model checks grounding, full request coverage, dependency order, scope and verification strategy. Validator feedback is automatically returned to the planner for bounded revision attempts.

The validated draft remains human-editable while approval is pending. The UI formats it as a plan board and can edit, reorder, add, remove and deselect steps through `/api/agent/runs/{id}/plan`. Approval locks the retained plan and starts only step 1.

## Token budget strategy

Active model context is treated as a cache, not durable state. Durable plan/model/workspace/verification state lives in `AgentRunService`. Agent history injection is capped, old tool observations are pruned, generated steering messages are tagged and superseded copies are removed, and compaction uses an adaptive high-water mark derived from the provider-safe input limit minus dynamic headroom rather than a fixed utilization percentage. Cheap deterministic pruning happens first. Most compactions use deterministic checkpoints; semantic compaction is periodic or used for forced overflow recovery. A local lexical workspace index is always available. When an embedding model is configured, the strongest lexical candidates are reranked semantically and fused with lexical scores; any embedding failure degrades automatically to local lexical retrieval instead of blocking the Agent.
