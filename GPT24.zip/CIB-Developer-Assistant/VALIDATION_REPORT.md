# Validation Report — CIB Developer Assistant

Validation date: 2026-09-14

## Release status

**Package status: READY FOR USER VALIDATION.**

The dependency-independent checks and executable core harnesses below pass. A complete Spring Boot Maven build could not be executed inside this sandbox because `repo.maven.apache.org` cannot be resolved from the environment. This limitation is external to the project. Run `validate-local.bat` (Windows) or `./validate-local.sh` (Linux/macOS) on a machine with Maven/dependency access before production use.

## Passed checks

- Frontend JavaScript syntax: PASS
  - `node --check src/main/resources/static/app.js`
  - `node --check src/main/resources/static/markdown.js`
- Shell syntax: PASS
  - `run.sh`
  - `validate-local.sh`
  - Maven wrapper shell script
- `pom.xml` XML parse: PASS
- `index.html` parser check: PASS
- Java 17 source compatibility/syntax scan: PASS for syntax/language level
  - full source was parsed with `javac --release 17 -proc:none`
  - no syntax errors or Java >17 language-feature diagnostics were found
  - unresolved external Spring/Jackson/JPA/Tika symbols are expected because dependencies are unavailable in this sandbox
- Compiled-artifact hygiene: PASS
  - no `.class` files are included in the source tree
- Basic secret-literal scan: PASS
  - no OpenAI/GitHub/Google-style credential literals detected
- Hard-coded Windows path scan in Java production sources: PASS
  - no `C:\...` production-source dependency
- Prompt resources: PASS
  - 13 titled sample-prompt sections
  - built-in UI Prompt library
  - 4 real starter files under `examples/agent-resources/`

## Executable Java 17 core harnesses

### Sequential plan + progress + history

PASS:

- symbol-only decorations such as `✅` and `→` are not accepted as planned steps
- tool/activity updates do not advance plan-derived progress
- approved planned steps cannot be skipped
- execution cannot jump over the active planned step
- mutation steps cannot complete without current-revision verification
- exactly the next planned step unlocks after successful completion
- completed-step evidence persists across Agent-run reload
- retained conversation Agent runs are restorable
- a run cannot report `completed` while approved plan items remain incomplete; it becomes `blocked`

### Durable application/history path

PASS:

- default data is resolved beneath the per-user durable home rather than the extracted/JAR directory
- conversation DB, uploads, cache metadata, and Agent-run state share the durable data root
- application-folder replacement therefore does not intentionally create a fresh history location
- legacy beside-JAR data migration remains best-effort and non-overwriting

### Long-command memory protection

PASS:

- small command output is retained exactly
- very large output is bounded in memory
- retained output preserves the beginning and latest tail
- truncation is explicit and includes an omitted-character count
- production command loop contains periodic activity heartbeats (first after ~5 seconds, then ~10-second intervals) without moving the plan-derived percentage

## UI/runtime improvements verified by source inspection

- approved plan and activity events are rendered separately
- browser Agent activity retention is bounded (`MAX_AGENT_EVENTS_RETAINED`)
- high-volume Agent rendering is throttled and updates the Agent card instead of rebuilding the full conversation per event
- completed planned steps expose expandable `Completed details`
- progress summary uses completed approved-plan count
- history reopening requests all retained Agent runs for the conversation and maps them back to their persisted assistant messages
- UI has no visible product version label and no `BNP green design` text
- Prompt library includes Playwright MCP/Selenium, Playwright, migration, development, testing, CI/CD and framework-analysis workflows

## Current harness improvements validated

- model capability registry recognises the configured CIB chat/agent and embedding models
- context-window budgeting follows the model handling the physical request, including planner, critic, vision and failover routes
- planner and completion critic can use dedicated configured models without changing executor failover state
- completion-critic prompts are bounded against the critic model's own context window
- vision analysis uses the configured/auto-selected vision-capable model and can fall back to the primary model
- workspace retrieval retains the deterministic lexical baseline and can semantically rerank candidates through an OpenAI-compatible embeddings endpoint
- semantic retrieval failures automatically fall back to lexical retrieval rather than blocking the run
- a dependency-independent Java 17 smoke harness for model routing/context detection passed
- the Agent UI exposes execution, planning, critic, vision and retrieval routes and includes a recommended CIB model profile
- the interface uses the CIB green visual system and contains no user-visible application release/version label
- model-library UI keeps recommended defaults while allowing user-defined add/edit/remove model IDs, per-model context values, role assignments and ordered execution fallbacks
- older-history loading treats messages as authoritative and restores optional files/projects/Agent-run metadata with `Promise.allSettled`, so missing optional metadata cannot blank a valid old conversation
- Agent progress snapshot includes active model, failover count, recovery-replan count, active plan step and persisted activity/plan state

Foreground command execution still uses the existing bounded output collector and periodic activity heartbeats, preserving the earlier long-running command memory protections.

## Executor-pool recovery validation

PASS (dependency-independent Java 17 executable harness):

- primary executor can fail over through the configured ordered executor pool
- once the pool is exhausted, `reviseRemainingPlan(...)` preserves completed steps/evidence and replaces only unfinished work
- failed unfinished strategy is not retained in the new runtime contract
- validated recovery can restart the model cycle at the primary executor without resetting failover telemetry
- recovery-replan count and last recovery diagnosis persist across `AgentRunService` reload/history restoration
- recovery live events are categorized under the `recovering` phase and exposed to the UI
- backend recovery path uses Analysis → Planning → independent Plan Validation and is bounded to two accepted recovery replans per run
- authentication/credential failures bypass futile fallback/replan loops and are surfaced directly

Executable harness result: `RECOVERY_HARNESS_PASS`.

## Model routing validation

PASS (dependency-independent Java 17 executable harness):

- per-model context override for `qwen3.8-27b` resolves to 262144 tokens
- per-model context override for `gpt-oss-120b-ITG` resolves to 131072 tokens
- dedicated analysis/planning/plan-validator/embedding roles resolve independently of the executor
- ordered executor pool retains primary plus user-configured fallbacks

Executable harness result: `MODEL_ROUTING_HARNESS_PASS`.

## Maven build limitation in this environment

Attempted:

```text
./mvnw -version
```

Result:

```text
Maven was not found. Bootstrapping Apache Maven 3.9.11...
curl: (6) Could not resolve host: repo.maven.apache.org
```

Therefore this report does **not** claim a dependency-backed Spring Boot `clean install` in the sandbox.

## Required full validation on your machine

Windows:

```bat
validate-local.bat
mvnw.cmd -Pfull-tests test
```

Linux/macOS:

```bash
./validate-local.sh
./mvnw -Pfull-tests test
```

A successful normal build should produce:

```text
target/advanced-ai-workbench.jar
```
