package com.llmart.llm.service;

import com.llmart.llm.dto.ChatSettings;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ModelCapabilityRegistryTest {

    @Test
    void recognisesConfiguredCibModelCapabilities() {
        var qwen = ModelCapabilityRegistry.profileFor("qwen3.8-27b");
        assertEquals(262_144, qwen.contextWindowTokens());
        assertTrue(qwen.toolCalling());
        assertTrue(qwen.preferredFor(ModelCapabilityRegistry.Role.EXECUTOR));

        var gptOss = ModelCapabilityRegistry.profileFor("gpt-oss-120b-ITG");
        assertEquals(131_072, gptOss.contextWindowTokens());
        assertTrue(gptOss.preferredFor(ModelCapabilityRegistry.Role.PLANNER));
        assertTrue(gptOss.preferredFor(ModelCapabilityRegistry.Role.CRITIC));
        assertFalse(gptOss.vision());

        var mistral = ModelCapabilityRegistry.profileFor("mistral-small-4-ITG");
        assertTrue(mistral.vision());
        assertEquals(262_144, mistral.contextWindowTokens());

        var embedding = ModelCapabilityRegistry.profileFor("qwen3-embedding-8b");
        assertTrue(embedding.embeddings());
        assertEquals(32_768, embedding.contextWindowTokens());
    }

    @Test
    void activeModelControlsAutoDetectedContextBudget() {
        ChatSettings settings = settings("qwen3.8-27b", "gpt-oss-120b-ITG", "gpt-oss-120b-ITG",
                "mistral-small-4-ITG", "qwen3-embedding-8b");

        assertEquals(262_144, settings.safeContextWindowTokens("qwen3.8-27b"));
        assertEquals(131_072, settings.safeContextWindowTokens("gpt-oss-120b-ITG"));
        assertEquals(262_144, settings.safeContextWindowTokens("mistral-small-4-ITG"));
    }

    @Test
    void explicitRoleModelsAndSemanticRetrievalAreApplied() {
        ChatSettings settings = settings("qwen3.8-27b", "gpt-oss-120b-ITG", "gpt-oss-120b-ITG",
                "mistral-small-4-ITG", "qwen3-embedding-8b");

        assertEquals("gpt-oss-120b-ITG", settings.analysisModelOrPrimary());
        assertEquals("gpt-oss-120b-ITG", settings.plannerModelOrPrimary());
        assertEquals("gpt-oss-120b-ITG", settings.planValidatorModelOrPrimary());
        assertEquals("gpt-oss-120b-ITG", settings.criticModelOrPrimary());
        assertEquals("mistral-small-4-ITG", settings.visionModelOrPrimary());
        assertEquals("qwen3-embedding-8b", settings.embeddingModelName());
        assertTrue(settings.hasDedicatedVisionModel());
        assertTrue(settings.semanticRetrievalEnabled());
    }

    private static ChatSettings settings(String model, String planner, String critic, String vision, String embedding) {
        return new ChatSettings(
                "http://localhost/v1", model, vision, critic, planner, critic, critic, embedding, true, true,
                0.1, 0, 0, 0, null, true, 8_000, 20_000, 1_200,
                null, true, 0, true,
                "allow", "allow", "allow", true, "",
                "allow", "allow", "allow", true, true,
                "mistral-small-4-ITG,qwen3.6-27b", 10
        );
    }
}
