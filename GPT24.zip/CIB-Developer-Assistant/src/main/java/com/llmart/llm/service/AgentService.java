package com.llmart.llm.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.llmart.llm.dto.ChatRequest;
import com.llmart.llm.dto.ChatSettings;
import com.llmart.llm.dto.ProjectPatchRequest;
import jakarta.annotation.PreDestroy;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.util.*;
import java.util.concurrent.*;
import java.util.function.Consumer;

/**
 * OpenCode-style model-step agent loop.
 *
 * Important runtime properties:
 * - the user-selected local directory is the live workspace (no mirror/staging/apply phase);
 * - native provider tool calls are the primary protocol;
 * - one model step may request multiple tools and all calls are executed before the next model turn;
 * - approved plans are sequential runtime gates: one active step at a time, with verification before advancing after mutations;
 * - there is no application-imposed model-step or tool-action ceiling; the run continues until verified completion,
 *   cancellation, permission denial/blocker, provider refusal, or a non-recoverable environment failure;
 * - JSON tool envelopes are only a compatibility fallback for providers without native function calling.
 */
@Service
public class AgentService {

    private static final int MAX_CONSECUTIVE_NON_ACTIONABLE_TURNS = 10;
    private static final int MAX_CONSECUTIVE_EMPTY_SUBAGENT_TURNS = 2;
    private static final int MAX_TRANSIENT_MODEL_RETRIES = 10;
    private static final int MAX_EXECUTOR_RECOVERY_REPLANS = 2;
    private final ExecutorService parallelReadExecutor = Executors.newFixedThreadPool(
            Math.max(4, Math.min(16, Runtime.getRuntime().availableProcessors() * 2)), r -> {
        Thread t = new Thread(r, "agent-parallel-read"); t.setDaemon(true); return t;
    });

    private static final String AGENT_PROTOCOL = """
            You are a capable general-purpose LOCAL WORKSPACE AGENT. Your job is to complete the user's task in the live local workspace, not merely describe how it could be done.

            OPERATING PRINCIPLES
            - The runtime creates a concise execution plan before work begins. After approval, that plan is a contract: exactly one step is active at a time and every retained step must reach completed before the run may finish successfully. Never skip an approved step. Use todo_update to complete the active step only after real tool activity; if that step changed code/config, successfully verify the current revision first. The runtime then unlocks the next step automatically.
            - The active workspace is the real user-selected filesystem directory. Work directly there after configured permission checks. Explicit additional prompt paths are exposed as resource aliases. Never invent paths.
            - Inspect only the evidence you need, prefer targeted/parallel reads, then edit/run/verify. Use subagents, MCP and LSP when they materially help.
            - Use the available tool names exactly. Built-in search is grep; tool_search discovers deferred MCP tools. If a tool call fails, read the error and change strategy instead of repeating the same call unchanged.
            - For edit failures, re-read the current target and retry with exact current text. For patch-schema/context failures, use structured apply_patch, edit, or write with current evidence.
            - Batch independent reads in one turn. Avoid re-reading unchanged files or repeating identical command/test output.
            - Keep changes focused and preserve project conventions. You have freedom to choose the best implementation path; do not ask the user for routine coding decisions once the plan is approved.
            - For code/config changes, run the smallest high-signal build/test/check/command that proves the current revision. If it fails, diagnose the actual output, fix it, and rerun. Stop when the requested result is complete and verified, or when a genuine external/permission/environment blocker is proven.
            - Never invent file contents, command results, test results, or completion. Final response: concise summary of changes plus real verification or blocker.

            WORKSPACE / RESOURCE MODEL
            - Primary workspace tools: inspect_workspace, workspace_profile, list, glob, grep, file_info, file_index, read, read_chunk, read_many, edit, write, copy, move, delete, apply_patch, build, test, check, bash, process_*, http_request, workspace_status, workspace_diff, todowrite, todoread, todo_update.
            - Explicit additional paths: use resource_catalog and resource_* tools. Reference/input/diagnostic resources are read-only; secondary workspace resources may be writable.
            - Project instructions (AGENTS.md/CLAUDE.md/etc.), skills, MCP and LSP are discovered by the runtime. Respect relevant project instructions while prioritizing the user's requested outcome.
            - The runtime manages context automatically. Compaction is a continuation checkpoint, not a signal to stop.

            COMPATIBILITY FALLBACK
            If native tools are unavailable and JSON compatibility mode is used, return exactly one object per turn:
              {"type":"tool","tool":"tool_name","reason":"short reason","args":{...}}
            or after real work is complete:
              {"type":"final","status":"completed|blocked","message":"concise Markdown summary"}
            """;

    private final OpenAiCompatibleClient llm;
    private final AgentWorkspaceService workspaces;
    private final AgentApprovalService approvals;
    private final AgentRunService runs;
    private final AgentToolRegistry toolRegistry;
    private final FileService files;
    private final McpManager mcp;
    private final WorkspaceProfileService workspaceProfiles;
    private final WorkspaceRetrievalIndexService workspaceRetrieval;
    private final AgentProfileService agentProfiles;
    private final LspManager lsp;
    private final ContextWindowManager contextWindows;
    private final ObjectMapper objectMapper;

    public AgentService(OpenAiCompatibleClient llm, AgentWorkspaceService workspaces,
                        AgentApprovalService approvals, AgentRunService runs,
                        AgentToolRegistry toolRegistry, FileService files, McpManager mcp,
                        WorkspaceProfileService workspaceProfiles, WorkspaceRetrievalIndexService workspaceRetrieval,
                        AgentProfileService agentProfiles, LspManager lsp,
                        ContextWindowManager contextWindows, ObjectMapper objectMapper) {
        this.llm = llm;
        this.workspaces = workspaces;
        this.approvals = approvals;
        this.runs = runs;
        this.toolRegistry = toolRegistry;
        this.files = files;
        this.mcp = mcp;
        this.workspaceProfiles = workspaceProfiles;
        this.workspaceRetrieval = workspaceRetrieval;
        this.agentProfiles = agentProfiles;
        this.lsp = lsp;
        this.contextWindows = contextWindows;
        this.objectMapper = objectMapper;
    }

    public AgentResult run(String runId, String apiKey, ChatRequest request, List<Map<String, Object>> baseContext,
                           Consumer<Map<String, Object>> onStep) throws Exception {
        AgentRunService.AgentRun run = runs.require(runId);
        Consumer<Map<String,Object>> downstreamSteps = onStep;
        onStep = event -> {
            run.recordActivityEvent(event);
            downstreamSteps.accept(event);
        };
        run.configureModelPool(request.settings().agentModels());
        AgentWorkspaceService.Workspace ws = null;
        String completionStatus = "running";
        try {
            run.updateProgress(4, "starting", "Resolving workspace and task context");
            ws = workspaces.prepare(request.projectId(), request.message());
            run.updateProgress(8, "planning", "Discovering workspace capabilities");
            McpManager.Catalog mcpCatalog = mcp.catalog(ws.root());
            // Keep MCP schemas out of every model turn. They are discovered lazily through tool_search.
            List<Map<String,Object>> availableTools = new CopyOnWriteArrayList<>(toolRegistry.builtInDefinitions());
            List<Map<String, Object>> messages = prepareMessages(baseContext, ws);
            run.setObjective(latestUserTask(messages));
            WorkspaceRetrievalIndexService.IndexStats indexStats = workspaceRetrieval.warm(ws);
            String embeddingModel = request.settings().embeddingModelName();
            String indexDetail = "Local retrieval index ready: " + indexStats.indexedFiles() + " relevant text/source files" +
                    (embeddingModel.isBlank() ? " · semantic reranking disabled/lexical fallback active" : " · semantic reranker: " + embeddingModel);
            onStep.accept(stepEvent(0, "workspace_index", indexDetail, "success", null, null, null));
            String projectInstructions = workspaces.projectInstructions(ws);
            if (!projectInstructions.isBlank()) messages.add(1, Map.of("role", "system", "content", projectInstructions));
            String runtimeCatalog = workspaceProfiles.profileText(ws) + "\n\nPROMPT RESOURCES\n" + workspaces.resourceCatalog(ws) +
                    "\n\nAVAILABLE SKILLS\n" + workspaces.availableSkills(ws) +
                    "\n\nAVAILABLE SUBAGENTS\n" + agentProfiles.catalogText(ws) +
                    "\n\nMCP STATUS\n" + (mcpCatalog.diagnostics().isEmpty() ? "[No MCP servers configured]" : String.join("\n", mcpCatalog.diagnostics())) +
                    "\n\nLSP STATUS\n" + lsp.status(ws.root());
            messages.add(Math.min(2, messages.size()), Map.of("role", "system", "content", runtimeCatalog));
            onStep.accept(stepEvent(0, "workspace_resolution", "Using live workspace: " + ws.root(), "success", null, workspaces.resourceCatalog(ws), null));

            run.updateProgress(9, "analysing", "Analysing the live workspace before planning");
            List<String> executionPlan = createExecutionPlan(apiKey, request, messages, ws, run, onStep);
            run.setPlan(executionPlan);
            onStep.accept(stepEvent(0, "plan", "Execution plan ready", "success", null, run.planText(), null));

            String finalMessage = null;
            if (request.settings().planApprovalRequired()) {
                run.updateProgress(13, "plan_review", "Validated plan is ready for your approval");
                AgentApprovalService.Approval planApproval = approvals.create(run.id(), "plan_approval", "Review execution plan before autonomous work starts");
                onStep.accept(stepEvent(0, "plan_approval", "Review the plan and approve execution", "approval", null, run.planText(), planApproval.id()));
                AgentApprovalService.Decision decision = approvals.await(planApproval.id(), Duration.ZERO, run);
                if (decision == AgentApprovalService.Decision.DENY) {
                    finalMessage = "Plan was not approved, so the agent did not change files or run project commands.";
                    run.markFinalAnswer(finalMessage);
                    run.finish("cancelled");
                    return new AgentResult(finalMessage, List.of());
                }
                onStep.accept(stepEvent(0, "plan_approval", "Plan approved; autonomous execution started", "success", null, null, null));
            }
            run.markPlanStarted();
            messages.add(Map.of("role", "system", "content", "APPROVED SEQUENTIAL EXECUTION PLAN:\n" + run.planText() +
                    "\n\nSEQUENTIAL GATE: Only the current in_progress step is unlocked. Do not begin later steps and never skip an approved step. Complete the active step with real tools, run required verification for any mutation, then call todo_update on that active index with status=completed. The runtime will unlock exactly one next step. Every retained approved step must complete before a successful final response. You still have freedom to choose the best evidence-driven implementation within the active step."));
            run.updateProgress(15, "executing", "Approved plan started; executing step 1");

            long toolActivity = 0;
            Map<String,Integer> repeatedCalls = new HashMap<>();
            Map<String,Integer> repeatedNoProgress = new HashMap<>();
            Map<String,Integer> verificationSteering = new HashMap<>();
            long recoveryTurns = 0;
            final int recoveryLimit = request.settings().safeAgentRecoveryAttempts();
            boolean transportReported = false;
            boolean requireToolNextTurn = false;
            int step = 0;
            int lastPlanIndex = run.activePlanIndex();

            while (true) {
                step++;
                run.checkCancelled();
                int currentPlanIndex = run.activePlanIndex();
                if (currentPlanIndex != lastPlanIndex) {
                    // A newly unlocked plan step is a fresh recovery scope. Do not let duplicate-call or
                    // recovery fingerprints from a previous step poison a long (>hundreds of turns) run.
                    repeatedCalls.clear();
                    repeatedNoProgress.clear();
                    verificationSteering.clear();
                    recoveryTurns = 0;
                    lastPlanIndex = currentPlanIndex;
                }
                run.updateActivity("executing", currentPlanIndex > 0
                        ? "Executing planned step " + currentPlanIndex + " · model turn " + step
                        : "Completing task · model turn " + step);
                OpenAiCompatibleClient.AgentCompletion turn;
                try {
                    turn = completeAgentTurn(apiKey, request, messages, ws, run, requireToolNextTurn, availableTools, step, onStep);
                } catch (ExecutorPoolExhaustedException exhausted) {
                    RecoveryReplanDecision recovery = attemptExecutorRecoveryReplan(apiKey, request, messages, ws, run, onStep, step,
                            exhausted.getMessage(), exhausted.providerDetail());
                    if (recovery.recovered()) {
                        recoveryTurns = 0;
                        repeatedNoProgress.clear();
                        repeatedCalls.clear();
                        verificationSteering.clear();
                        lastPlanIndex = run.activePlanIndex();
                        requireToolNextTurn = false;
                        transportReported = false;
                        continue;
                    }
                    completionStatus = "blocked";
                    finalMessage = recoveryExhaustedMessage(recoveryTurns, recoveryLimit, run, recovery.reason());
                    onStep.accept(stepEvent(step, "loop_guard", "Executor pool and recovery replanning were exhausted", "error", null,
                            clipUi(recovery.reason()), null));
                    break;
                }
                requireToolNextTurn = false;
                run.checkCancelled();

                if (!transportReported) {
                    transportReported = true;
                    String transport = turn.nativeToolsUsed()
                            ? "Native model tool calling active"
                            : turn.jsonModeUsed()
                            ? "Native tools unavailable; JSON compatibility mode active"
                            : "Provider exposes neither native tools nor JSON response mode; best-effort compatibility mode active";
                    onStep.accept(stepEvent(step, "agent_transport", transport, "success", null, null, null));
                }

                String raw = turn.content() == null ? "" : turn.content().trim();

                // Native tools: one assistant model step can contain multiple tool calls. Execute all of them
                // before asking the model to reason again, matching modern agent runtimes and dramatically
                // reducing the old 40/80-step one-tool-at-a-time behavior.
                if (turn.hasToolCall()) {
                    List<OpenAiCompatibleClient.AgentToolCall> calls = turn.toolCalls();
                    appendNativeAssistantTurn(messages, calls, raw);

                    long successfulVerificationBefore = run.lastSuccessfulVerificationRevision();
                    long activityThisTurn = executeNativeCalls(calls, messages, ws, run, request, apiKey, mcpCatalog,
                            availableTools, step, onStep, repeatedCalls);
                    toolActivity += activityThisTurn;
                    if (activityThisTurn > 0) {
                        recoveryTurns = 0;
                    } else {
                        recoveryTurns++;
                        if (recoveryTurns >= recoveryLimit) {
                            if (switchToNextModel(run, onStep, step, "No actionable progress after " + recoveryTurns + " recovery attempts")) {
                                recoveryTurns = 0;
                                repeatedNoProgress.clear();
                                repeatedCalls.clear();
                                verificationSteering.clear();
                                messages.add(Map.of("role", "system", "content", modelFailoverContinuation(run)));
                                requireToolNextTurn = false;
                                continue;
                            }
                            run.markRepeatedCallPrevented();
                            RecoveryReplanDecision recovery = attemptExecutorRecoveryReplan(apiKey, request, messages, ws, run, onStep, step,
                                    "No actionable progress after all executor models exhausted their recovery attempts", raw);
                            if (recovery.recovered()) {
                                recoveryTurns = 0;
                                repeatedNoProgress.clear();
                                repeatedCalls.clear();
                                verificationSteering.clear();
                                lastPlanIndex = run.activePlanIndex();
                                requireToolNextTurn = false;
                                transportReported = false;
                                continue;
                            }
                            completionStatus = "blocked";
                            finalMessage = recoveryExhaustedMessage(recoveryTurns, recoveryLimit, run, recovery.reason());
                            onStep.accept(stepEvent(step, "loop_guard",
                                    "Recovery budget exhausted for all configured models and recovery replanning",
                                    "error", null, clipUi(recovery.reason()), null));
                            break;
                        }
                        messages.add(Map.of("role", "user", "content", recoveryDirective((int) recoveryTurns, recoveryLimit, true, raw)));
                        requireToolNextTurn = turn.nativeToolsUsed();
                        onStep.accept(stepEvent(step, "agent_recovery",
                                "Tool call produced no actionable progress; switching strategy (recovery " + recoveryTurns + "/" + recoveryLimit + " on " + effectiveModel(run, request.settings()) + ")",
                                "running", null, clipUi(raw), null));
                    }
                    if (run.mutationRevision() > 0 && run.verifiedCurrentRevision() &&
                            run.lastSuccessfulVerificationRevision() > successfulVerificationBefore) {
                        if (run.hasOpenPlanItems()) {
                            run.updateProgress(86, "plan_gate", "Verification passed; finish the active plan step before advancing");
                            messages.add(Map.of("role", "user", "content", planContinuationPrompt(run, true)));
                            onStep.accept(stepEvent(step, "plan_gate", "Verification passed for active step " + run.activePlanIndex() + "; waiting for explicit step completion", "success", null, run.planText(), null));
                        } else {
                            run.updateProgress(90, "completion_check", "Verification passed; checking whether the requested task is complete");
                            String completionGate = completionGate(apiKey, request, messages, run, step, onStep);
                            if (completionGate != null && !completionGate.isBlank() && !"CONTINUE".equalsIgnoreCase(completionGate.strip())) {
                                completionStatus = completionGate.startsWith("Blocked:") ? "blocked" : "completed";
                                finalMessage = completionGate.strip();
                                onStep.accept(stepEvent(step, "finish", "Verified task completed", "done", null, null, null));
                                break;
                            }
                            if ("CONTINUE".equalsIgnoreCase(String.valueOf(completionGate).strip())) {
                                messages.add(Map.of("role", "assistant", "content", "Completion check: additional requested work remains; continue with tools."));
                            }
                        }
                    }
                    continue;
                }

                JsonNode envelope = parseEnvelope(raw);
                if (envelope != null && envelope.isObject()) {
                    String type = envelope.path("type").asText("").trim().toLowerCase(Locale.ROOT);
                    if ("final".equals(type) && toolActivity > 0) {
                        String requestedStatus = normalizeFinalStatus(envelope.path("status").asText("completed"));
                        String requestedMessage = envelope.path("message").asText("").trim();
                        if ("completed".equals(requestedStatus) && run.hasOpenPlanItems()) {
                            if (!raw.isBlank()) messages.add(Map.of("role", "assistant", "content", raw));
                            messages.add(Map.of("role", "user", "content", planContinuationPrompt(run, false)));
                            onStep.accept(stepEvent(step, "plan_gate", "Final response deferred; approved plan step " + run.activePlanIndex() + " is still active", "running", null, run.planText(), null));
                            requireToolNextTurn = turn.nativeToolsUsed();
                            continue;
                        }
                        if ("completed".equals(requestedStatus) && requiresCurrentRevisionVerification(run)) {
                            if (verificationSteeringBlocked(verificationSteering, run)) {
                                completionStatus = "blocked";
                                finalMessage = "Blocked: the model repeatedly attempted to finish the same unverified workspace revision without producing a new verifier result or fix. The runtime stopped the no-progress verification loop to protect the token budget.";
                                onStep.accept(stepEvent(step, "loop_guard", "Stopped repeated finish-without-verification loop", "error", null, clipUi(raw), null));
                                break;
                            }
                            String finishFingerprint = "unverified-final|" + run.mutationRevision() + "|" + normalizeNoProgress(raw);
                            int finishRepeat = repeatedNoProgress.merge(finishFingerprint, 1, Integer::sum);
                            if (!raw.isBlank() && finishRepeat == 1) messages.add(Map.of("role", "assistant", "content", raw));
                            else if (finishRepeat > 1) run.markRepeatedCallPrevented();
                            messages.add(Map.of("role", "user", "content", verificationRequiredPrompt(run)));
                            onStep.accept(stepEvent(step, "verification_required",
                                    "Workspace changed after the last successful verifier; continuing until the current revision is verified",
                                    "running", null, null, null));
                            requireToolNextTurn = turn.nativeToolsUsed();
                            continue;
                        }
                        completionStatus = requestedStatus;
                        finalMessage = requestedMessage.isBlank() ? "Agent run completed." : requestedMessage;
                        onStep.accept(stepEvent(step, "finish", "Agent prepared the final response", "done", null, null, null));
                        break;
                    }
                    if ("tool".equals(type)) {
                        String requestedTool = envelope.path("tool").asText("").trim();
                        String tool = toolRegistry.canonical(requestedTool);
                        JsonNode args = normalizeLegacyArgs(requestedTool, tool, envelope.path("args"));
                        String detail = envelope.path("reason").asText("").trim();
                        if (detail.isBlank()) detail = describeTool(tool, args);
                        String result;
                        String status;
                        boolean compatibilityExecuted = false;

                        onStep.accept(stepEvent(step, tool, detail, "running", args, null, null));
                        if (!isKnownTool(requestedTool, tool, mcpCatalog)) {
                            result = unknownToolMessage(requestedTool, mcpCatalog);
                            status = "error";
                        } else {
                            PreparedCall compatibilityCall = new PreparedCall(
                                    new OpenAiCompatibleClient.AgentToolCall("compat_" + step, requestedTool, args),
                                    requestedTool, tool, args, detail);
                            ToolExecution execution = preflightCall(compatibilityCall, mcpCatalog);
                            if (execution == null) {
                                execution = executeWithPermission(ws, run, tool, args, request.settings(), detail, step, onStep,
                                        mcpCatalog, availableTools, apiKey, request);
                            }
                            execution = applyRepeatOutcomeGuard(compatibilityCall, execution, run, repeatedCalls, mcpCatalog);
                            result = execution.result();
                            status = execution.status();
                            if (execution.executed()) {
                                observeRun(run, tool, args, result);
                                toolActivity++;
                                compatibilityExecuted = true;
                            }
                        }
                        onStep.accept(stepEvent(step, tool, summarizeResult(tool, result), status, args, clipUi(result), null));
                        appendFallbackToolTranscript(messages, raw, tool, result);
                        if (compatibilityExecuted) {
                            recoveryTurns = 0;
                        } else {
                            recoveryTurns++;
                            if (recoveryTurns >= recoveryLimit) {
                                if (switchToNextModel(run, onStep, step, "Compatibility tool flow made no progress after " + recoveryTurns + " attempts")) {
                                    recoveryTurns = 0;
                                    repeatedNoProgress.clear();
                                    repeatedCalls.clear();
                                    verificationSteering.clear();
                                    messages.add(Map.of("role", "system", "content", modelFailoverContinuation(run)));
                                    continue;
                                }
                                run.markRepeatedCallPrevented();
                                RecoveryReplanDecision recovery = attemptExecutorRecoveryReplan(apiKey, request, messages, ws, run, onStep, step,
                                        "Compatibility tool flow made no progress after all executor fallbacks", result);
                                if (recovery.recovered()) {
                                    recoveryTurns = 0;
                                    repeatedNoProgress.clear();
                                    repeatedCalls.clear();
                                    verificationSteering.clear();
                                    lastPlanIndex = run.activePlanIndex();
                                    requireToolNextTurn = false;
                                    transportReported = false;
                                    continue;
                                }
                                completionStatus = "blocked";
                                finalMessage = recoveryExhaustedMessage(recoveryTurns, recoveryLimit, run, recovery.reason());
                                onStep.accept(stepEvent(step, "loop_guard",
                                        "Recovery budget exhausted for all configured models and recovery replanning",
                                        "error", null, clipUi(recovery.reason()), null));
                                break;
                            }
                            messages.add(Map.of("role", "user", "content", recoveryDirective((int) recoveryTurns, recoveryLimit, true, result)));
                            onStep.accept(stepEvent(step, "agent_recovery",
                                    "Compatibility tool call made no progress; switching strategy (recovery " + recoveryTurns + "/" + recoveryLimit + " on " + effectiveModel(run, request.settings()) + ")",
                                    "running", null, clipUi(result), null));
                        }
                        continue;
                    }
                }

                // A prose response after real work can finish only when the current mutated revision is verified.
                if (!raw.isBlank() && toolActivity > 0) {
                    if (run.hasOpenPlanItems() && !looksLikeBlockedFinal(raw)) {
                        messages.add(Map.of("role", "assistant", "content", raw));
                        messages.add(Map.of("role", "user", "content", planContinuationPrompt(run, false)));
                        onStep.accept(stepEvent(step, "plan_gate", "Final response deferred; approved plan step " + run.activePlanIndex() + " is still active", "running", null, run.planText(), null));
                        requireToolNextTurn = turn.nativeToolsUsed();
                        continue;
                    }
                    if (requiresCurrentRevisionVerification(run)) {
                        if (looksLikeBlockedFinal(raw) && externalVerificationBlocker(run.lastVerification())) {
                            completionStatus = "blocked";
                            finalMessage = raw;
                            onStep.accept(stepEvent(step, "finish",
                                    "Agent stopped because the execution environment prevented required verification",
                                    "blocked", null, clipUi(raw), null));
                            break;
                        }
                        if (verificationSteeringBlocked(verificationSteering, run)) {
                            completionStatus = "blocked";
                            finalMessage = "Blocked: the model repeatedly tried to finish an unverified workspace revision without a new fix or verifier result. The duplicate verification loop was stopped to protect the token budget.";
                            onStep.accept(stepEvent(step, "loop_guard", "Stopped repeated finish-without-verification loop", "error", null, clipUi(raw), null));
                            break;
                        }
                        String finishFingerprint = "unverified-prose|" + run.mutationRevision() + "|" + normalizeNoProgress(raw);
                        int finishRepeat = repeatedNoProgress.merge(finishFingerprint, 1, Integer::sum);
                        if (finishRepeat == 1) messages.add(Map.of("role", "assistant", "content", raw));
                        else run.markRepeatedCallPrevented();
                        messages.add(Map.of("role", "user", "content", verificationRequiredPrompt(run)));
                        onStep.accept(stepEvent(step, "verification_required",
                                "The current workspace revision is not successfully verified; continuing the build/run/fix loop",
                                "running", null, clipUi(raw), null));
                        requireToolNextTurn = turn.nativeToolsUsed();
                        continue;
                    }
                    completionStatus = looksLikeBlockedFinal(raw) ? "blocked" : "completed";
                    finalMessage = raw;
                    onStep.accept(stepEvent(step, "finish", "Agent completed after verified tool activity", "done", null, null, null));
                    break;
                }

                // Recover from non-actionable turns instead of terminating early. Identical prose is not echoed back
                // repeatedly because that reinforces the same response pattern; the steering prompt changes strategy.
                String noProgressFingerprint = run.mutationRevision() + "|" + normalizeNoProgress(raw);
                int noProgressCount = repeatedNoProgress.merge(noProgressFingerprint, 1, Integer::sum);
                recoveryTurns++;
                if (recoveryTurns >= recoveryLimit) {
                    if (switchToNextModel(run, onStep, step, "Non-actionable responses after " + recoveryTurns + " recovery attempts")) {
                        recoveryTurns = 0;
                        repeatedNoProgress.clear();
                        repeatedCalls.clear();
                        verificationSteering.clear();
                        messages.add(Map.of("role", "system", "content", modelFailoverContinuation(run)));
                        requireToolNextTurn = false;
                        continue;
                    }
                    run.markRepeatedCallPrevented();
                    RecoveryReplanDecision recovery = attemptExecutorRecoveryReplan(apiKey, request, messages, ws, run, onStep, step,
                            "Non-actionable responses exhausted every executor model", raw);
                    if (recovery.recovered()) {
                        recoveryTurns = 0;
                        repeatedNoProgress.clear();
                        repeatedCalls.clear();
                        verificationSteering.clear();
                        lastPlanIndex = run.activePlanIndex();
                        requireToolNextTurn = false;
                        transportReported = false;
                        continue;
                    }
                    completionStatus = "blocked";
                    finalMessage = recoveryExhaustedMessage(recoveryTurns, recoveryLimit, run, recovery.reason());
                    onStep.accept(stepEvent(step, "loop_guard",
                            "Recovery budget exhausted for all configured models and recovery replanning",
                            "error", null, clipUi(recovery.reason()), null));
                    break;
                }
                boolean duplicate = noProgressCount > 1;
                if (duplicate) run.markRepeatedCallPrevented();
                if (!raw.isBlank() && !duplicate) messages.add(Map.of("role", "assistant", "content", raw));
                messages.add(Map.of("role", "user", "content", recoveryDirective((int) recoveryTurns, recoveryLimit, duplicate, raw)));
                requireToolNextTurn = turn.nativeToolsUsed();
                onStep.accept(stepEvent(step, "agent_recovery",
                        (duplicate ? "Duplicate non-actionable response detected; forcing a different strategy" : "Model returned without an actionable tool call") +
                                " (recovery " + recoveryTurns + "/" + recoveryLimit + " on " + effectiveModel(run, request.settings()) + ")",
                        "running", null, clipUi(raw), null));
            }

            List<ProjectPatchRequest.ProjectPatchFile> changes = workspaces.changes(ws);
            finalMessage = decorateFinalMessage(finalMessage, ws, changes, run, completionStatus);
            run.markFinalAnswer(finalMessage);
            run.finish(completionStatus);
            return new AgentResult(finalMessage, changes);
        } catch (AgentCancelledException cancelled) {
            run.finish("cancelled");
            throw cancelled;
        } catch (Exception e) {
            run.finish("failed");
            throw e;
        } finally {
            approvals.cancelRun(run.id());
            workspaces.stopRunProcesses(run.id());
            workspaces.cleanup(ws); // direct workspace cleanup is intentionally a no-op
        }
    }

    private List<String> createExecutionPlan(String apiKey, ChatRequest request,
                                                     List<Map<String,Object>> messages,
                                                     AgentWorkspaceService.Workspace ws,
                                                     AgentRunService.AgentRun run,
                                                     Consumer<Map<String,Object>> onStep) {
        String task = latestUserTask(messages);
        run.updateProgress(9, "indexing", "Collecting repository evidence and retrieval hints");
        String evidence = collectPlanningEvidence(ws, task, apiKey, request.settings(), run);
        onStep.accept(stepEvent(0, "plan_analysis", "Workspace evidence collected for independent analysis",
                "success", null, clipUi(evidence), null));

        String analysis = analysePlanningEvidence(apiKey, request, run, task, evidence, onStep);
        run.updateProgress(11, "planning", "Building a structured execution plan from analysed workspace evidence");

        List<String> fallback = List.of(
                "Inspect the relevant implementation and configuration identified during workspace analysis and confirm the concrete failure/target behavior",
                "Trace the affected code path and dependencies using focused reads/searches, recording the smallest safe change set",
                "Implement the requested change in the affected files while preserving existing public behavior outside the requested scope",
                "Run the smallest high-signal compile/check/test for the changed area and diagnose the first actionable failure if verification does not pass",
                "Fix any verification failures caused by the change, rerun the targeted verifier, and review the final workspace diff before completion"
        );

        List<String> plan = fallback;
        String validatorFeedback = "";
        boolean plannerWorked = false;
        try {
            for (int revision = 0; revision < 3; revision++) {
                plan = generateExecutionPlan(apiKey, request, run, task, evidence, analysis, validatorFeedback, onStep);
                plannerWorked = true;
                if (plan.size() < 4) throw new IllegalStateException("Planner returned fewer than four executable steps");

                PlanValidation validation = validateExecutionPlan(apiKey, request, run, task, evidence, analysis, plan, onStep);
                if (validation.approved()) {
                    run.setPlanValidation("approved", validation.summary());
                    onStep.accept(stepEvent(0, "plan_validation", "Plan validator approved the execution plan",
                            "success", null, clipUi(validation.summary()), null));
                    return plan;
                }

                validatorFeedback = validation.summary();
                run.setPlanValidation("revising", validatorFeedback);
                onStep.accept(stepEvent(0, "plan_validation", "Plan validator requested revision " + (revision + 1) + "/2",
                        "running", null, clipUi(validatorFeedback), null));
                if (revision >= 1) {
                    run.setPlanValidation("needs_review", validatorFeedback);
                    onStep.accept(stepEvent(0, "plan_validation", "Plan kept for user review after validator revision limit",
                            "success", null, clipUi(validatorFeedback), null));
                    return plan;
                }
            }
        } catch (AgentCancelledException cancelled) {
            throw cancelled;
        } catch (Exception e) {
            String reason = safe(e.getMessage());
            run.setPlanValidation(plannerWorked ? "needs_review" : "fallback", reason);
            onStep.accept(stepEvent(0, "plan_recovery", plannerWorked
                    ? "Plan validation/planning could not complete; keeping the latest evidence-based plan for user review"
                    : "Planner unavailable; using evidence-safe fallback plan",
                    "success", null, clipUi(reason), null));
        }
        return plan == null || plan.size() < 4 ? fallback : plan;
    }

    /** Separate read-only analysis role: synthesizes workspace evidence before the planning model sees it. */
    private String analysePlanningEvidence(String apiKey, ChatRequest request, AgentRunService.AgentRun run,
                                           String task, String evidence, Consumer<Map<String,Object>> onStep) {
        String model = request.settings().analysisModelOrPrimary();
        run.updateProgress(10, "analysing", "Analysing architecture, constraints and likely change surface");
        try {
            List<Map<String,Object>> prompt = new ArrayList<>();
            prompt.add(Map.of("role", "system", "content", """
                    You are the READ-ONLY analysis stage of a coding-agent harness. Do not propose edits yet and do not call tools.
                    From the supplied repository evidence, identify: the concrete request, relevant architecture/code areas, constraints,
                    likely dependencies, risks, and the smallest verification strategy. Distinguish facts from assumptions. Never invent files,
                    classes, failures or commands not supported by the evidence. Return a concise analysis that a separate planner can use.
                    """));
            prompt.add(Map.of("role", "user", "content", "USER TASK:\n" + task + "\n\nWORKSPACE EVIDENCE:\n" + evidence));
            ContextWindowManager.ContextEstimate estimate = contextWindows.estimate(prompt, List.of(), request.settings(), model);
            run.recordContextEstimate(estimate.estimatedInputTokens(), estimate.contextWindowTokens());
            int maxOut = request.settings().safeMaxTokens() > 0 ? Math.min(2_400, request.settings().safeMaxTokens()) : 2_400;
            onStep.accept(stepEvent(0, "model_route", "Analysis model: " + model, "success", null, null, null));
            OpenAiCompatibleClient.AgentCompletion completion = completeRoleText(
                    apiKey, request, run, model, ModelCapabilityRegistry.Role.ANALYSIS, maxOut, prompt, 0, onStep, "analysis");
            run.recordModelUsage(completion.usage(), estimate.estimatedInputTokens());
            String value = completion.content() == null ? "" : completion.content().strip();
            if (!value.isBlank()) {
                onStep.accept(stepEvent(0, "analysis", "Independent workspace analysis complete", "success", null, clipUi(value), null));
                return value;
            }
        } catch (AgentCancelledException cancelled) {
            throw cancelled;
        } catch (Exception e) {
            onStep.accept(stepEvent(0, "analysis", "Analysis model unavailable; planner will use raw workspace evidence", "running", null, clipUi(safe(e.getMessage())), null));
        }
        return "Use the raw workspace evidence directly. Treat unsupported assumptions as unknown and verify them during execution.";
    }

    private List<String> generateExecutionPlan(String apiKey, ChatRequest request, AgentRunService.AgentRun run,
                                                String task, String evidence, String analysis, String validatorFeedback,
                                                Consumer<Map<String,Object>> onStep) throws Exception {
        List<Map<String,Object>> planning = new ArrayList<>();
        planning.add(Map.of("role", "system", "content", """
                You are the PLANNING stage of a coding/engineering agent. A separate read-only analysis stage has already examined the workspace.
                Build a sequential execution plan grounded in the supplied evidence and analysis. Do not merely paraphrase the user's prompt.
                Every step must define a concrete outcome and its validation. Keep implementation and verification together where that makes the
                dependency order clearer. Do not invent files or failures that are not supported by evidence.
                Return only 4-12 numbered steps, one executable step per line, using plain `1. ...` numbering. No headings, bullets, checkboxes,
                emoji, code fences or approval language. The UI will format the plan separately.
                """));
        String feedbackBlock = validatorFeedback == null || validatorFeedback.isBlank() ? "" :
                "\n\nVALIDATOR FEEDBACK FROM PREVIOUS DRAFT:\n" + validatorFeedback + "\nRevise the plan to address every valid concern.";
        planning.add(Map.of("role", "user", "content", "USER TASK:\n" + task +
                "\n\nREAD-ONLY ANALYSIS:\n" + analysis +
                "\n\nWORKSPACE EVIDENCE:\n" + evidence + feedbackBlock));
        String plannerModel = request.settings().plannerModelOrPrimary();
        ContextWindowManager.ContextEstimate estimate = contextWindows.estimate(planning, List.of(), request.settings(), plannerModel);
        run.recordContextEstimate(estimate.estimatedInputTokens(), estimate.contextWindowTokens());
        int maxOut = request.settings().safeMaxTokens() > 0 ? Math.min(2_600, request.settings().safeMaxTokens()) : 2_600;
        onStep.accept(stepEvent(0, "model_route", "Planning model: " + plannerModel, "success", null, null, null));
        OpenAiCompatibleClient.AgentCompletion completion = completeRoleText(
                apiKey, request, run, plannerModel, ModelCapabilityRegistry.Role.PLANNER, maxOut, planning, 0, onStep, "planning");
        run.recordModelUsage(completion.usage(), estimate.estimatedInputTokens());
        List<String> parsed = parsePlanItems(completion.content());
        if (parsed.size() < 4) throw new IllegalStateException("Planner response was incomplete: " + clipUi(completion.content()));
        onStep.accept(stepEvent(0, "plan", "Planner produced " + parsed.size() + " executable steps", "success", null, clipUi(completion.content()), null));
        return parsed;
    }

    /** Independent validator uses a different configured role model when available and never edits the plan directly. */
    private PlanValidation validateExecutionPlan(String apiKey, ChatRequest request, AgentRunService.AgentRun run,
                                                 String task, String evidence, String analysis, List<String> plan,
                                                 Consumer<Map<String,Object>> onStep) throws Exception {
        run.updateProgress(12, "plan_validation", "Validating coverage, grounding, ordering and verification strategy");
        String validatorModel = request.settings().planValidatorModelOrPrimary();
        List<Map<String,Object>> prompt = new ArrayList<>();
        prompt.add(Map.of("role", "system", "content", """
                You are an independent PLAN VALIDATOR for a coding-agent harness. Review the proposed plan against the user's request and evidence.
                Check: evidence grounding, full request coverage, dependency/order correctness, executable steps, minimal scope, verification strategy,
                and unsupported assumptions. Do not add optional scope. Do not call tools.
                If the plan is ready, return exactly two parts: first line `APPROVED`, then a short reason.
                If it needs correction, return first line `REVISE`, then concise actionable feedback only. Do not rewrite the plan yourself.
                """));
        prompt.add(Map.of("role", "user", "content", "USER TASK:\n" + task +
                "\n\nANALYSIS:\n" + analysis +
                "\n\nPROPOSED PLAN:\n" + numberedPlan(plan) +
                "\n\nEVIDENCE EXCERPT:\n" + clipHeadTail(evidence, 12_000, "[Evidence clipped for validation]")));
        ContextWindowManager.ContextEstimate estimate = contextWindows.estimate(prompt, List.of(), request.settings(), validatorModel);
        run.recordContextEstimate(estimate.estimatedInputTokens(), estimate.contextWindowTokens());
        int maxOut = request.settings().safeMaxTokens() > 0 ? Math.min(1_600, request.settings().safeMaxTokens()) : 1_600;
        onStep.accept(stepEvent(0, "model_route", "Plan validator: " + validatorModel, "success", null, null, null));
        OpenAiCompatibleClient.AgentCompletion completion = completeRoleText(
                apiKey, request, run, validatorModel, ModelCapabilityRegistry.Role.PLAN_VALIDATOR, maxOut, prompt, 0, onStep, "plan validation");
        run.recordModelUsage(completion.usage(), estimate.estimatedInputTokens());
        String raw = completion.content() == null ? "" : completion.content().strip();
        if (raw.isBlank()) return new PlanValidation(false, "Validator returned an empty response.");
        String first = raw.lines().findFirst().orElse("").trim();
        String summary = raw.lines().skip(1).reduce("", (a,b) -> a.isBlank() ? b : a + "\n" + b).strip();
        if (first.equalsIgnoreCase("APPROVED")) return new PlanValidation(true, summary.isBlank() ? "Grounded, ordered and verifiable." : summary);
        return new PlanValidation(false, summary.isBlank() ? raw : summary);
    }

    /**
     * Last-resort recovery path after every configured executor model has exhausted its own retry/failover budget.
     * A separate analysis role diagnoses the failure, the planner rewrites only the unfinished work, an independent
     * validator checks that recovery plan, and execution restarts from the primary executor without discarding the
     * current workspace or completed plan steps.
     */
    private RecoveryReplanDecision attemptExecutorRecoveryReplan(String apiKey, ChatRequest request,
                                                                  List<Map<String,Object>> messages,
                                                                  AgentWorkspaceService.Workspace ws,
                                                                  AgentRunService.AgentRun run,
                                                                  Consumer<Map<String,Object>> onStep,
                                                                  int step, String failureSummary,
                                                                  String providerOrTurnDetail) {
        if (run.recoveryReplans() >= MAX_EXECUTOR_RECOVERY_REPLANS) {
            return new RecoveryReplanDecision(false,
                    "Recovery replanning limit reached (" + MAX_EXECUTOR_RECOVERY_REPLANS + "). Last failure: " + safe(failureSummary));
        }
        if (!run.planLocked() || run.activePlanIndex() <= 0 || !run.hasOpenPlanItems()) {
            return new RecoveryReplanDecision(false,
                    "No active approved plan step is available for recovery replanning. Last failure: " + safe(failureSummary));
        }

        try {
            run.updateActivity("recovering", "All executor models exhausted; diagnosing the active step before replanning");
            onStep.accept(stepEvent(step, "recovery_analysis",
                    "All executor models exhausted; analysing the active step and current workspace state",
                    "running", null, clipUi(failureSummary), null));

            String recoveryEvidence = collectRecoveryEvidence(ws, run, failureSummary, providerOrTurnDetail,
                    apiKey, request.settings());
            String analysis = analyseRecoveryFailure(apiKey, request, run, recoveryEvidence, step, onStep);
            String firstLine = analysis.lines().findFirst().orElse("").trim();
            String analysisBody = analysis.lines().skip(1).reduce("", (a,b) -> a.isBlank() ? b : a + "\n" + b).strip();
            if (firstLine.equalsIgnoreCase("BLOCKED_EXTERNAL")) {
                String reason = analysisBody.isBlank() ? "Recovery analyst identified a genuine external/environment blocker." : analysisBody;
                onStep.accept(stepEvent(step, "recovery_analysis", "Recovery analyst identified an external blocker",
                        "blocked", null, clipUi(reason), null));
                return new RecoveryReplanDecision(false, reason);
            }
            if (!firstLine.equalsIgnoreCase("RECOVERABLE")) {
                analysisBody = analysis;
            }
            String diagnosis = analysisBody.isBlank() ? analysis : analysisBody;

            String validatorFeedback = "";
            List<String> recoveryPlan = List.of();
            for (int revision = 0; revision < 3; revision++) {
                recoveryPlan = generateRecoveryPlan(apiKey, request, run, recoveryEvidence, diagnosis,
                        validatorFeedback, step, onStep);
                if (recoveryPlan.isEmpty()) {
                    return new RecoveryReplanDecision(false, "Recovery planner returned no executable remaining steps.");
                }
                PlanValidation validation = validateRecoveryPlan(apiKey, request, run, recoveryEvidence,
                        diagnosis, recoveryPlan, step, onStep);
                if (validation.approved()) {
                    String reason = clipHeadTail(diagnosis, 900, "[Recovery diagnosis clipped]");
                    run.reviseRemainingPlan(recoveryPlan, reason);
                    run.recordRecoveryReplan(diagnosis);
                    run.setPlanValidation("approved", "Recovery plan validated. " + validation.summary());
                    if (!run.restartModelCycle("Recovery replan accepted after executor pool exhaustion")) {
                        return new RecoveryReplanDecision(false, "Recovery plan was valid, but no execution model is configured.");
                    }
                    messages.add(Map.of("role", "system", "content", recoveryReplanContinuation(run, diagnosis)));
                    onStep.accept(stepEvent(step, "recovery_replan",
                            "Recovery plan validated; executor chain restarted from the primary model",
                            "success", null, run.planText(), null));
                    return new RecoveryReplanDecision(true, "Recovery plan validated and execution resumed.");
                }

                validatorFeedback = validation.summary();
                onStep.accept(stepEvent(step, "recovery_validation",
                        "Recovery plan validator requested revision " + (revision + 1) + "/3",
                        "running", null, clipUi(validatorFeedback), null));
            }
            return new RecoveryReplanDecision(false,
                    "Recovery planner could not produce an independently validated remaining-work plan. Last validator feedback: " + validatorFeedback);
        } catch (AgentCancelledException cancelled) {
            throw cancelled;
        } catch (Exception recoveryFailure) {
            String reason = "Recovery replanning failed: " + safe(recoveryFailure.getMessage());
            onStep.accept(stepEvent(step, "recovery_replan", "Recovery replanning could not continue",
                    "error", null, clipUi(reason), null));
            return new RecoveryReplanDecision(false, reason);
        }
    }

    private String collectRecoveryEvidence(AgentWorkspaceService.Workspace ws, AgentRunService.AgentRun run,
                                           String failureSummary, String providerOrTurnDetail,
                                           String apiKey, ChatSettings settings) {
        StringBuilder out = new StringBuilder();
        out.append("ORIGINAL OBJECTIVE:\n").append(run.objective()).append("\n\n");
        out.append("APPROVED PLAN / CURRENT STATE:\n").append(run.planText()).append("\n\n");
        out.append("ACTIVE STEP: ").append(run.activePlanIndex()).append(" — ").append(run.activePlanStepText()).append("\n");
        out.append("FAILURE SUMMARY: ").append(safe(failureSummary)).append("\n");
        if (providerOrTurnDetail != null && !providerOrTurnDetail.isBlank()) {
            out.append("LAST MODEL/TOOL DETAIL:\n")
                    .append(clipHeadTail(providerOrTurnDetail, 8_000, "[Last failure detail clipped]")).append("\n");
        }
        if (!run.lastVerification().isBlank()) {
            out.append("LAST VERIFICATION:\n")
                    .append(clipHeadTail(run.lastVerification(), 6_000, "[Verification detail clipped]")).append("\n");
        }
        appendPlanningEvidence(out, "Current workspace status", () -> workspaces.workspaceStatus(ws), 6_000);
        appendPlanningEvidence(out, "Current workspace diff", () -> workspaces.workspaceDiff(ws, ""), 16_000);
        String query = (run.objective() + " " + run.activePlanStepText() + " " + safe(failureSummary)).strip();
        String hints = workspaceRetrieval.retrieveHybrid(ws, query, 10, 12_000, apiKey, settings, run::cancelled);
        if (!hints.isBlank()) out.append("\n\n## Recovery retrieval hints\n")
                .append(clipHeadTail(hints, 12_000, "[Recovery retrieval hints clipped]"));
        return clipHeadTail(out.toString(), 46_000, "[Recovery evidence clipped; live workspace remains authoritative]");
    }

    private String analyseRecoveryFailure(String apiKey, ChatRequest request, AgentRunService.AgentRun run,
                                          String evidence, int step, Consumer<Map<String,Object>> onStep) throws Exception {
        String model = request.settings().analysisModelOrPrimary();
        List<Map<String,Object>> prompt = new ArrayList<>();
        prompt.add(Map.of("role", "system", "content", """
                You are the RECOVERY ANALYST in a coding-agent harness. Every configured executor model has already failed
                or made no actionable progress on the current approved step. Diagnose the reason from CURRENT workspace state,
                diff, verification output and failure evidence. Never invent files or results. Distinguish an implementation/
                strategy failure from a genuine external blocker such as missing permission, unavailable required infrastructure,
                invalid credentials, or a provider/service outage that no code change can solve.

                First line must be exactly one of:
                RECOVERABLE
                BLOCKED_EXTERNAL

                Then provide a concise diagnosis, what assumptions/approaches should change, what existing edits must be preserved,
                and the concrete evidence the replanner should use. Do not write the new plan yourself and do not call tools.
                """));
        prompt.add(Map.of("role", "user", "content", evidence));
        ContextWindowManager.ContextEstimate estimate = contextWindows.estimate(prompt, List.of(), request.settings(), model);
        run.recordContextEstimate(estimate.estimatedInputTokens(), estimate.contextWindowTokens());
        int maxOut = request.settings().safeMaxTokens() > 0 ? Math.min(2_200, request.settings().safeMaxTokens()) : 2_200;
        onStep.accept(stepEvent(step, "model_route", "Recovery analysis model: " + model, "success", null, null, null));
        OpenAiCompatibleClient.AgentCompletion completion = completeRoleText(
                apiKey, request, run, model, ModelCapabilityRegistry.Role.ANALYSIS, maxOut, prompt, step, onStep, "recovery analysis");
        run.recordModelUsage(completion.usage(), estimate.estimatedInputTokens());
        String value = completion.content() == null ? "" : completion.content().strip();
        if (value.isBlank()) throw new IllegalStateException("Recovery analyst returned an empty response");
        onStep.accept(stepEvent(step, "recovery_analysis", "Recovery diagnosis complete", "success", null, clipUi(value), null));
        return value;
    }

    private List<String> generateRecoveryPlan(String apiKey, ChatRequest request, AgentRunService.AgentRun run,
                                              String evidence, String diagnosis, String validatorFeedback,
                                              int step, Consumer<Map<String,Object>> onStep) throws Exception {
        String model = request.settings().plannerModelOrPrimary();
        List<Map<String,Object>> prompt = new ArrayList<>();
        prompt.add(Map.of("role", "system", "content", """
                You are the RECOVERY PLANNER for a coding-agent harness. Completed plan steps are immutable and the live workspace
                may already contain valid partial edits. Replace ONLY the unfinished work with the shortest evidence-grounded route
                that can satisfy the original objective. Preserve valid current edits; do not restart completed work. The first
                recovery step must directly address the diagnosed failure/incorrect assumption. Include targeted verification where
                code/config changes are involved. Do not invent files, commands or failures.

                Return only 1-8 numbered remaining steps, one executable step per line, plain `1. ...` format. No headings, bullets,
                code fences, status labels or approval language.
                """));
        String feedback = validatorFeedback == null || validatorFeedback.isBlank() ? "" :
                "\n\nVALIDATOR FEEDBACK FROM PREVIOUS RECOVERY DRAFT:\n" + validatorFeedback + "\nAddress every valid concern.";
        prompt.add(Map.of("role", "user", "content", "RECOVERY DIAGNOSIS:\n" + diagnosis +
                "\n\nCURRENT EVIDENCE:\n" + evidence + feedback));
        ContextWindowManager.ContextEstimate estimate = contextWindows.estimate(prompt, List.of(), request.settings(), model);
        run.recordContextEstimate(estimate.estimatedInputTokens(), estimate.contextWindowTokens());
        int maxOut = request.settings().safeMaxTokens() > 0 ? Math.min(2_200, request.settings().safeMaxTokens()) : 2_200;
        onStep.accept(stepEvent(step, "model_route", "Recovery planning model: " + model, "success", null, null, null));
        OpenAiCompatibleClient.AgentCompletion completion = completeRoleText(
                apiKey, request, run, model, ModelCapabilityRegistry.Role.PLANNER, maxOut, prompt, step, onStep, "recovery planning");
        run.recordModelUsage(completion.usage(), estimate.estimatedInputTokens());
        List<String> parsed = parsePlanItems(completion.content());
        if (parsed.isEmpty()) throw new IllegalStateException("Recovery planner response contained no executable steps");
        onStep.accept(stepEvent(step, "recovery_plan", "Recovery planner produced " + parsed.size() + " remaining step" +
                (parsed.size() == 1 ? "" : "s"), "success", null, numberedPlan(parsed), null));
        return parsed;
    }

    private PlanValidation validateRecoveryPlan(String apiKey, ChatRequest request, AgentRunService.AgentRun run,
                                                String evidence, String diagnosis, List<String> plan,
                                                int step, Consumer<Map<String,Object>> onStep) throws Exception {
        String model = request.settings().planValidatorModelOrPrimary();
        List<Map<String,Object>> prompt = new ArrayList<>();
        prompt.add(Map.of("role", "system", "content", """
                You are an independent RECOVERY PLAN VALIDATOR. The original executor pool failed, so be strict.
                Check that the proposed remaining-work plan: addresses the diagnosed cause rather than repeating the failed strategy;
                preserves completed work and valid current edits; contains no unsupported assumptions; is executable with available
                workspace/tool evidence; includes enough verification; and still covers the unfinished part of the user's objective.
                Return first line `APPROVED` or `REVISE`, followed by a short reason/actionable feedback. Do not rewrite the plan.
                """));
        prompt.add(Map.of("role", "user", "content", "RECOVERY DIAGNOSIS:\n" + diagnosis +
                "\n\nPROPOSED REMAINING PLAN:\n" + numberedPlan(plan) +
                "\n\nCURRENT EVIDENCE:\n" + clipHeadTail(evidence, 18_000, "[Recovery evidence clipped for validation]")));
        ContextWindowManager.ContextEstimate estimate = contextWindows.estimate(prompt, List.of(), request.settings(), model);
        run.recordContextEstimate(estimate.estimatedInputTokens(), estimate.contextWindowTokens());
        int maxOut = request.settings().safeMaxTokens() > 0 ? Math.min(1_500, request.settings().safeMaxTokens()) : 1_500;
        onStep.accept(stepEvent(step, "model_route", "Recovery plan validator: " + model, "success", null, null, null));
        OpenAiCompatibleClient.AgentCompletion completion = completeRoleText(
                apiKey, request, run, model, ModelCapabilityRegistry.Role.PLAN_VALIDATOR, maxOut, prompt, step, onStep, "recovery plan validation");
        run.recordModelUsage(completion.usage(), estimate.estimatedInputTokens());
        String raw = completion.content() == null ? "" : completion.content().strip();
        if (raw.isBlank()) return new PlanValidation(false, "Recovery validator returned an empty response.");
        String first = raw.lines().findFirst().orElse("").trim();
        String summary = raw.lines().skip(1).reduce("", (a,b) -> a.isBlank() ? b : a + "\n" + b).strip();
        if (first.equalsIgnoreCase("APPROVED")) return new PlanValidation(true,
                summary.isBlank() ? "Recovery route is grounded, non-repetitive and verifiable." : summary);
        return new PlanValidation(false, summary.isBlank() ? raw : summary);
    }

    private String recoveryReplanContinuation(AgentRunService.AgentRun run, String diagnosis) {
        return "[RUNTIME_STEERING:recovery-replan]\nRECOVERY REPLAN ACCEPTED. Every previous executor model exhausted the old strategy. " +
                "The runtime has preserved completed steps and the live workspace, replaced only unfinished work, and restarted the executor chain. " +
                "Do not redo completed steps or revert valid partial edits. Active step is " + run.activePlanIndex() + ": " + run.activePlanStepText() +
                "\nRecovery diagnosis: " + clipHeadTail(diagnosis, 1_200, "[diagnosis clipped]") +
                "\nCurrent sequential plan:\n" + run.planText();
    }

    private record RecoveryReplanDecision(boolean recovered, String reason) { }

    private String numberedPlan(List<String> plan) {
        StringBuilder out = new StringBuilder();
        for (int i = 0; i < (plan == null ? 0 : plan.size()); i++) out.append(i + 1).append(". ").append(plan.get(i)).append('\n');
        return out.toString().stripTrailing();
    }

    private record PlanValidation(boolean approved, String summary) { }

    private String latestUserTask(List<Map<String,Object>> messages) {
        if (messages == null) return "Complete the requested task";
        for (int i = messages.size() - 1; i >= 0; i--) {
            Map<String,Object> message = messages.get(i);
            if (!"user".equals(String.valueOf(message.getOrDefault("role", "")))) continue;
            String text = String.valueOf(message.getOrDefault("content", "")).strip();
            if (text.isBlank() || text.startsWith("TOOL RESULT for ")) continue;
            return clipHeadTail(text, 8_000, "[Older parts of the user task omitted for planning]");
        }
        return "Complete the requested task";
    }

    /** Read-only deterministic discovery performed before the planner is allowed to draft a plan. */
    private String collectPlanningEvidence(AgentWorkspaceService.Workspace ws, String task, String apiKey, ChatSettings settings, AgentRunService.AgentRun run) {
        StringBuilder out = new StringBuilder();
        appendPlanningEvidence(out, "Workspace profile", () -> workspaces.inspectWorkspace(ws), 8_000);
        appendPlanningEvidence(out, "Resolved prompt resources", () -> workspaces.resourceCatalog(ws), 5_000);
        appendPlanningEvidence(out, "Project instructions", () -> workspaces.projectInstructions(ws), 6_000);

        String files = "";
        try { files = workspaces.listFiles(ws, ""); } catch (Exception ignored) { }
        if (!files.isBlank()) {
            out.append("\n\n## File index\n").append(clipHeadTail(files, 12_000, "[File index clipped; agent can query it again during execution]"));
            Set<String> paths = new LinkedHashSet<>(Arrays.asList(files.split("\\R")));
            List<String> priority = List.of("AGENTS.md", "CLAUDE.md", "README.md", "pom.xml", "build.gradle", "build.gradle.kts",
                    "package.json", "pyproject.toml", "requirements.txt", "application.properties", "application.yml", "application.yaml");
            int read = 0;
            for (String candidate : priority) {
                String matched = paths.stream().filter(p -> p.equalsIgnoreCase(candidate) || p.toLowerCase(Locale.ROOT).endsWith("/" + candidate.toLowerCase(Locale.ROOT))).findFirst().orElse(null);
                if (matched == null) continue;
                final String path = matched;
                appendPlanningEvidence(out, "Key file: " + path, () -> workspaces.readFileRange(ws, path, 1, 220), 8_000);
                if (++read >= 5) break;
            }
        }

        String indexedHints = workspaceRetrieval.retrieveHybrid(ws, task, 10, 10_000, apiKey, settings, run::cancelled);
        if (!indexedHints.isBlank()) {
            out.append("\n\n## Local retrieval index hints\n")
                    .append(clipHeadTail(indexedHints, 10_000, "[Retrieval hints clipped]"));
        }

        LinkedHashSet<String> terms = new LinkedHashSet<>();
        Set<String> stop = Set.of("this","that","with","from","into","then","have","will","should","agent","plan","user","please","make","work","working","issue","issues","test","tests","project");
        for (String word : (task == null ? "" : task.toLowerCase(Locale.ROOT)).split("[^a-z0-9_.$/-]+")) {
            if (word.length() >= 4 && !stop.contains(word) && !word.matches("\\d+")) terms.add(word);
            if (terms.size() >= 3) break;
        }
        for (String term : terms) {
            final String query = term;
            appendPlanningEvidence(out, "Relevant matches for '" + query + "'", () -> workspaces.search(ws, query, 8), 6_000);
        }
        return clipHeadTail(out.toString(), 42_000, "[Planning evidence clipped; live workspace remains authoritative]");
    }

    private void appendPlanningEvidence(StringBuilder out, String title, PlanningEvidenceSupplier supplier, int maxChars) {
        try {
            String value = supplier.get();
            if (value == null || value.isBlank() || value.startsWith("[No ")) return;
            out.append("\n\n## ").append(title).append("\n")
                    .append(clipHeadTail(value, maxChars, "[Evidence section clipped]"));
        } catch (Exception ignored) { }
    }

    @FunctionalInterface
    private interface PlanningEvidenceSupplier { String get() throws Exception; }

    private List<String> parsePlanItems(String raw) {
        if (raw == null || raw.isBlank()) return List.of();
        LinkedHashSet<String> unique = new LinkedHashSet<>();
        try {
            JsonNode json = objectMapper.readTree(raw.trim());
            JsonNode arr = json != null && json.isArray() ? json : json == null ? null : json.path("plan");
            if (arr != null && arr.isArray()) {
                for (JsonNode item : arr) {
                    String text = item.isTextual() ? item.asText() : item.path("text").asText("");
                    addPlanItem(unique, text);
                    if (unique.size() >= 12) break;
                }
                if (!unique.isEmpty()) return List.copyOf(unique);
            }
        } catch (Exception ignored) { }
        for (String line : raw.split("\\R")) {
            addPlanItem(unique, line);
            if (unique.size() >= 12) break;
        }
        return List.copyOf(unique);
    }

    private void addPlanItem(Set<String> out, String raw) {
        String item = cleanPlanItem(raw);
        if (item.isBlank()) return;
        String low = item.toLowerCase(Locale.ROOT);
        if (Set.of("plan", "execution plan", "steps", "todo", "pending", "completed", "done", "in progress", "in_progress").contains(low)) return;
        if (low.startsWith("here is") || low.startsWith("here's") || low.startsWith("execution plan:")) return;
        // Decoration-only lines were previously being counted as planned work. Require meaningful letters/digits
        // and enough descriptive content to be executable.
        if (!item.matches(".*[\\p{L}\\p{N}].*") || item.replaceAll("[^\\p{L}\\p{N}]", "").length() < 8) return;
        out.add(item);
    }

    private String cleanPlanItem(String value) {
        if (value == null) return "";
        String item = value.strip();
        if (item.isBlank() || item.startsWith("```") || item.startsWith("~~~") || item.matches("^#{1,6}\\s+.*")) return "";
        item = item.replaceFirst("^\\d{1,2}[.)]\\s*", "");
        item = item.replaceFirst("^\\[[ xX✓✔]\\]\\s*", "");
        item = item.replaceFirst("^[\\-*•‣▪▫◦]+\\s*", "");
        // Strip common visual/status prefixes without treating the symbol itself as work.
        item = item.replaceFirst("^(?:✅|☑️?|✔️?|✓|🔲|⬜|🟩|🟢|🔹|🔸|➡️?|→|➜|➤|▶️?|⏳|🛠️?|⚙️?)\\s*", "");
        item = item.replaceFirst("^(?i:(?:step|task)\\s+\\d{1,2}\\s*[:.)-]\\s*)", "");
        item = item.replaceAll("^\\*\\*|\\*\\*$", "").strip();
        if (item.matches("^[\\p{So}\\p{Sk}\\p{Sm}\\p{Punct}\\s]+$")) return "";
        return item.length() <= 700 ? item : item.substring(0, 700);
    }

    private List<Map<String, Object>> prepareMessages(List<Map<String, Object>> baseContext,
                                                       AgentWorkspaceService.Workspace ws) {
        List<Map<String, Object>> messages = new ArrayList<>();
        boolean merged = false;
        if (baseContext != null) {
            for (Map<String, Object> message : baseContext) {
                if (!merged && "system".equals(String.valueOf(message.get("role")))) {
                    Map<String, Object> copy = new LinkedHashMap<>(message);
                    copy.put("content", String.valueOf(message.getOrDefault("content", "")) + "\n\n" + AGENT_PROTOCOL +
                            "\n\nACTIVE LIVE WORKSPACE ROOT: " + ws.root());
                    messages.add(copy);
                    merged = true;
                } else {
                    messages.add(new LinkedHashMap<>(message));
                }
            }
        }
        if (!merged) {
            messages.add(0, Map.of("role", "system", "content", AGENT_PROTOCOL +
                    "\n\nACTIVE LIVE WORKSPACE ROOT: " + ws.root()));
        }
        return messages;
    }

    private long executeNativeCalls(List<OpenAiCompatibleClient.AgentToolCall> calls,
                                    List<Map<String,Object>> messages,
                                    AgentWorkspaceService.Workspace ws,
                                    AgentRunService.AgentRun run,
                                    ChatRequest request,
                                    String apiKey,
                                    McpManager.Catalog mcpCatalog,
                                    List<Map<String,Object>> availableTools,
                                    int step,
                                    Consumer<Map<String,Object>> onStep,
                                    Map<String,Integer> repeatedCalls) {
        List<PreparedCall> prepared = new ArrayList<>();
        for (OpenAiCompatibleClient.AgentToolCall call : calls) {
            String requested = call.name() == null ? "" : call.name().trim();
            String tool = toolRegistry.canonical(requested);
            JsonNode args = normalizeLegacyArgs(requested, tool, call.arguments());
            prepared.add(new PreparedCall(call, requested, tool, args, describeTool(tool,args)));
        }
        long activity = 0;
        int i = 0;
        while (i < prepared.size()) {
            PreparedCall first = prepared.get(i);
            boolean parallel = request.settings().parallelReadTools() && canParallel(first, request.settings(), mcpCatalog);
            int end = i + 1;
            if (parallel) while (end < prepared.size() && canParallel(prepared.get(end), request.settings(), mcpCatalog)) end++;
            if (parallel && end - i > 1) {
                List<PreparedCall> group = prepared.subList(i,end);
                for (PreparedCall c : group) onStep.accept(stepEvent(step,c.tool(),c.detail(),"running",c.args(),null,null));
                List<Future<ToolExecution>> futures = new ArrayList<>();
                for (PreparedCall c : group) {
                    ToolExecution pre = preflightCall(c, mcpCatalog);
                    if (pre != null) futures.add(CompletableFuture.completedFuture(pre));
                    else futures.add(parallelReadExecutor.submit(() -> executeWithPermission(ws, run, c.tool(), c.args(), request.settings(), c.detail(), step,
                            onStep, mcpCatalog, availableTools, apiKey, request)));
                }
                for (int k=0;k<group.size();k++) {
                    PreparedCall c=group.get(k); ToolExecution e;
                    try { e=futures.get(k).get(); } catch (Exception ex) { e=new ToolExecution("TOOL ERROR: "+safe(ex.getMessage()),"error",false); }
                    e = applyRepeatOutcomeGuard(c, e, run, repeatedCalls, mcpCatalog);
                    if (e.executed()) { observeRun(run,c.tool(),c.args(),e.result()); activity++; }
                    onStep.accept(stepEvent(step,c.tool(),summarizeResult(c.tool(),e.result()),e.status(),c.args(),clipUi(e.result()),null));
                    appendNativeToolResult(messages,c.call().id(),c.requestedTool(),e.result());
                }
            } else {
                PreparedCall c=first;
                int activePlanBefore = run.activePlanIndex();
                onStep.accept(stepEvent(step,c.tool(),c.detail(),"running",c.args(),null,null));
                ToolExecution e=preflightCall(c,mcpCatalog);
                if (e==null) e=executeWithPermission(ws,run,c.tool(),c.args(),request.settings(),c.detail(),step,onStep,
                        mcpCatalog,availableTools,apiKey,request);
                e=applyRepeatOutcomeGuard(c,e,run,repeatedCalls,mcpCatalog);
                if (e.executed()) { observeRun(run,c.tool(),c.args(),e.result()); activity++; }
                onStep.accept(stepEvent(step,c.tool(),summarizeResult(c.tool(),e.result()),e.status(),c.args(),clipUi(e.result()),null));
                appendNativeToolResult(messages,c.call().id(),c.requestedTool(),e.result());
                int activePlanAfter = run.activePlanIndex();
                if (activePlanBefore > 0 && activePlanAfter != activePlanBefore && i + 1 < prepared.size()) {
                    for (int j = i + 1; j < prepared.size(); j++) {
                        PreparedCall deferred = prepared.get(j);
                        String deferredResult = "DEFERRED BY SEQUENTIAL PLAN GATE: step " + activePlanBefore +
                                " completed in this model turn. Later tool calls from the same response were not executed. " +
                                (activePlanAfter > 0 ? "Step " + activePlanAfter + " is now active; request this tool again only if it belongs to that step." : "All approved plan steps are complete.");
                        onStep.accept(stepEvent(step, "plan_gate", "Deferred " + deferred.tool() + " after plan-step boundary", "success", deferred.args(), null, null));
                        appendNativeToolResult(messages, deferred.call().id(), deferred.requestedTool(), deferredResult);
                    }
                    return activity;
                }
            }
            i=end;
        }
        return activity;
    }

    private ToolExecution preflightCall(PreparedCall c, McpManager.Catalog mcpCatalog) {
        if (!isKnownTool(c.requestedTool(), c.tool(), mcpCatalog)) {
            return new ToolExecution(unknownToolMessage(c.requestedTool(), mcpCatalog), "error", false);
        }
        return null;
    }

    /**
     * Result-aware loop protection. Repeating a command is allowed when it produces new evidence; only the same
     * call producing the same normalized outcome on the same workspace revision is considered a no-progress loop.
     * This preserves unlimited useful build/test/diagnostic work while stopping token-burning duplicates.
     */
    private ToolExecution applyRepeatOutcomeGuard(PreparedCall c, ToolExecution execution,
                                                  AgentRunService.AgentRun run,
                                                  Map<String,Integer> repeatedOutcomes,
                                                  McpManager.Catalog mcpCatalog) {
        if (execution == null) return new ToolExecution("TOOL ERROR: empty execution result", "error", false);
        boolean eligible = !execution.executed() || isRepeatGuardEligible(c.tool(), c.args(), mcpCatalog) ||
                (isMutationTool(c.tool()) && explicitlyNoWorkspaceChange(execution.result()));
        if (!eligible) return execution;

        String outcome = normalizeToolOutcome(execution.result());
        String fingerprint = c.tool() + "|args=" + Integer.toHexString(canonicalArgs(c.args()).hashCode()) +
                "|revision=" + run.mutationRevision() + "|status=" + execution.status() +
                "|outcome=" + Integer.toHexString(outcome.hashCode());
        if (repeatedOutcomes.size() > 8_000) repeatedOutcomes.clear();
        int count = repeatedOutcomes.merge(fingerprint, 1, Integer::sum);
        int limit = Set.of("process_status", "process_output").contains(c.tool()) ? 4 : 3;
        if (count == limit - 1) {
            return new ToolExecution(execution.result() +
                    "\n\nDOOM LOOP WARNING: this exact tool call is producing the same outcome repeatedly on the same workspace revision. " +
                    "Do not repeat it unchanged again; inspect different evidence, wait only when the process genuinely needs time, modify the workspace, or change strategy.",
                    execution.status(), execution.executed());
        }
        if (count >= limit) {
            run.markRepeatedCallPrevented();
            return new ToolExecution("REPEATED TOOL CALL SUPPRESSED: this exact call has already produced the same result repeatedly on workspace revision " +
                    run.mutationRevision() + ". Choose a different tool, arguments, path, command, or re-read current state before retrying. " +
                    "The last real result was:\n" + execution.result(), "error", false);
        }
        return execution;
    }

    private String normalizeToolOutcome(String result) {
        if (result == null || result.isBlank()) return "<blank>";
        String normalized = result.toLowerCase(Locale.ROOT).replaceAll("\\s+", " ").trim();
        if (normalized.length() <= 6_000) return normalized;
        return normalized.substring(0, 4_000) + "|tail|" + normalized.substring(normalized.length() - 2_000);
    }

    private ToolExecution applyChildRepeatOutcomeGuard(PreparedCall c, ToolExecution execution,
                                                       AgentRunService.AgentRun parentRun,
                                                       Map<String,Integer> repeatedOutcomes,
                                                       McpManager.Catalog mcpCatalog) {
        if (execution == null) return new ToolExecution("TOOL ERROR: empty execution result", "error", false);
        boolean eligible = !execution.executed() || isRepeatGuardEligible(c.tool(), c.args(), mcpCatalog) ||
                (isMutationTool(c.tool()) && explicitlyNoWorkspaceChange(execution.result()));
        if (!eligible) return execution;
        String outcome = normalizeToolOutcome(execution.result());
        String fingerprint = c.tool() + "|args=" + Integer.toHexString(canonicalArgs(c.args()).hashCode()) +
                "|revision=" + parentRun.mutationRevision() + "|status=" + execution.status() +
                "|outcome=" + Integer.toHexString(outcome.hashCode());
        if (repeatedOutcomes.size() > 2_000) repeatedOutcomes.clear();
        int count = repeatedOutcomes.merge(fingerprint, 1, Integer::sum);
        int limit = Set.of("process_status", "process_output").contains(c.tool()) ? 4 : 3;
        if (count == limit - 1) {
            return new ToolExecution(execution.result() +
                    "\n\nSUBAGENT LOOP WARNING: this exact call is producing the same outcome repeatedly. Change strategy instead of repeating it.",
                    execution.status(), execution.executed());
        }
        if (count >= limit) {
            parentRun.markRepeatedCallPrevented();
            return new ToolExecution("SUBAGENT REPEATED CALL SUPPRESSED: the same tool call produced the same result repeatedly without workspace progress. " +
                    "Choose a different investigation strategy. Last result:\n" + execution.result(),
                    "error", false);
        }
        return execution;
    }

    private boolean isRepeatGuardEligible(String tool, JsonNode args, McpManager.Catalog catalog) {
        if ("todoread".equals(tool)) return false;
        if (Set.of("process_status","process_output","workspace_status","workspace_diff").contains(tool)) return true;
        if (Set.of("build","test","check","resource_build","resource_test","resource_check").contains(tool)) return true;
        if (Set.of("bash","resource_bash","http_request").contains(tool) && args != null && args.path("verification").asBoolean(false)) return true;
        return toolRegistry.isParallelReadOnly(tool) || mcp.isReadOnly(catalog,tool);
    }

    private boolean isMutationTool(String tool) {
        return Set.of("edit", "write", "copy", "move", "delete", "apply_patch",
                "resource_edit", "resource_write", "resource_delete", "resource_copy", "resource_move").contains(tool);
    }

    private boolean explicitlyNoWorkspaceChange(String result) {
        return result != null && (result.startsWith("workspaceChanged=false;") || result.startsWith("resourceChanged=false;"));
    }

    private boolean directMutationChanged(String result) {
        // New mutation tools report the marker explicitly. Keep the fallback true for compatibility with custom/older tools.
        return result == null || !explicitlyNoWorkspaceChange(result);
    }

    private boolean canParallel(PreparedCall c, ChatSettings settings, McpManager.Catalog catalog) {
        if (!isKnownTool(c.requestedTool(),c.tool(),catalog)) return false;
        boolean readOnly=toolRegistry.isParallelReadOnly(c.tool()) || mcp.isReadOnly(catalog,c.tool());
        if (!readOnly) return false;
        String p=permissionFor(c.tool(),settings);
        return "allow".equals(p) || ("ask".equals(p) && settings.autoApproveAgent());
    }

    private boolean isKnownTool(String requested, String canonical, McpManager.Catalog catalog) {
        return toolRegistry.isKnownBuiltIn(requested) || toolRegistry.isKnownBuiltIn(canonical) || mcp.isMcpTool(catalog,canonical) || mcp.isMcpTool(catalog,requested);
    }

    private String unknownToolMessage(String requested, McpManager.Catalog catalog) {
        LinkedHashSet<String> names=new LinkedHashSet<>(toolRegistry.names());
        if (catalog!=null) names.addAll(catalog.byFunction().keySet());
        String repaired = toolRegistry.canonical(requested);
        String hint = repaired != null && !repaired.isBlank() && !Objects.equals(repaired, requested)
                ? " The runtime interpreted the closest canonical name as '" + repaired + "'." : "";
        return "TOOL ERROR: unknown tool '" + requested + "'." + hint +
                " Use exact built-in names (grep searches text; glob matches paths; tool_search discovers deferred MCP tools). Available tools: " +
                String.join(", ", names);
    }

    private String runSubagent(AgentWorkspaceService.Workspace ws, AgentRunService.AgentRun parentRun,
                               ChatRequest request, String apiKey, McpManager.Catalog mcpCatalog,
                               List<Map<String,Object>> availableTools, String agentId, String prompt,
                               int parentStep, Consumer<Map<String,Object>> onStep) throws Exception {
        AgentProfileService.AgentProfile profile=agentProfiles.require(ws,agentId);
        List<Map<String,Object>> childTools=new CopyOnWriteArrayList<>(toolRegistry.filterDefinitions(availableTools,profile.allowedTools(),true));
        Set<String> childNames=new HashSet<>(); for(Map<String,Object>d:childTools) childNames.add(toolRegistry.functionName(d));
        // Subagents use the same ordered model pool as the parent run and preserve parent run state across failover.
        String model=effectiveModel(parentRun, request.settings());
        List<Map<String,Object>> child=new ArrayList<>();
        child.add(Map.of("role","system","content",profile.systemPrompt()+"\n\nACTIVE LIVE WORKSPACE ROOT: "+ws.root()+
                "\n\n"+workspaceProfiles.profileText(ws)+"\n\n"+workspaces.projectInstructions(ws)+
                "\n\nPrompt-resolved resources:\n"+workspaces.resourceCatalog(ws)+
                "\n\nAvailable skills:\n"+workspaces.availableSkills(ws)+
                "\n\nYou are a child session. Do not invoke another subagent. Use real tools and return a concise evidence-based report to the parent."));
        child.add(Map.of("role","user","content",prompt));
        long toolActivity=0; int childTurn=0;
        boolean childOverflowRecovered = false;
        int emptyChildTurns = 0;
        int childTransientFailures = 0;
        Map<String,Integer> childRepeatedOutcomes = new HashMap<>();
        while(true){
            childTurn++; parentRun.checkCancelled();
            model=effectiveModel(parentRun, request.settings());
            prepareActiveContext(apiKey, request, model, child, childTools, request.settings(), ws, parentRun, parentStep, onStep, false);
            ContextWindowManager.ContextEstimate childEstimate = contextWindows.estimate(child, childTools, request.settings());
            parentRun.recordContextEstimate(childEstimate.estimatedInputTokens(), childEstimate.contextWindowTokens());
            OpenAiCompatibleClient.AgentCompletion turn;
            try {
                turn=llm.completeAgent(apiKey,request.settings().baseUrl(),model,request.settings().safeMaxTokens(),child,childTools,false,parentRun::cancelled);
                parentRun.recordModelUsage(turn.usage(), childEstimate.estimatedInputTokens());
            } catch(Exception e){
                if(isContextWindowFailure(e) && !childOverflowRecovered){
                    ContextWindowManager.CompactionResult compacted = contextWindows.compact(child, childTools, request.settings(), parentRun, true,
                            compactionSummarizer(apiKey, request, model, parentRun));
                    childOverflowRecovered = true;
                    if(compacted.compacted()){
                        parentRun.recordCompaction(compacted.estimatedTokensSaved(), "subagent:"+agentId+" "+compacted.reason());
                        onStep.accept(stepEvent(parentStep,"context_compaction","Subagent "+agentId+": provider overflow recovered: "+formatCompaction(compacted),"success",null,null,null));
                        continue;
                    }
                }
                String childError = safe(e.getMessage());
                if (isModelUnavailableFailure(e)) {
                    if (switchToNextModel(parentRun, onStep, parentStep, "Subagent " + agentId + " model unavailable: " + childError)) {
                        childTransientFailures = 0;
                        child.add(Map.of("role", "system", "content", modelFailoverContinuation(parentRun)));
                        continue;
                    }
                    return "SUBAGENT " + agentId + " BLOCKED\nNo configured model is available: " + childError + "\n\nchildToolActions=" + toolActivity;
                }
                if(!isTransientModelFailure(e)) throw e;
                childTransientFailures++;
                int childRecoveryLimit = request.settings().safeAgentRecoveryAttempts();
                if (childTransientFailures >= childRecoveryLimit) {
                    if (switchToNextModel(parentRun, onStep, parentStep, "Subagent " + agentId + " exhausted " + childRecoveryLimit + " transient retries: " + childError)) {
                        childTransientFailures = 0;
                        child.add(Map.of("role", "system", "content", modelFailoverContinuation(parentRun)));
                        continue;
                    }
                    return "SUBAGENT " + agentId + " BLOCKED\nModel request failed on every configured model after " + childRecoveryLimit + " retries per model: " + childError + "\n\nchildToolActions=" + toolActivity;
                }
                sleepCancellable(parentRun,Math.min(8_000L,500L << Math.min(4, childTransientFailures - 1)));
                continue;
            }
            childOverflowRecovered = false;
            childTransientFailures = 0;
            String raw=turn.content()==null?"":turn.content().trim();
            if(turn.hasToolCall()){
                emptyChildTurns = 0;
                appendNativeAssistantTurn(child,turn.toolCalls(),raw);
                for(OpenAiCompatibleClient.AgentToolCall call:turn.toolCalls()){
                    String requested=call.name()==null?"":call.name().trim(); String tool=toolRegistry.canonical(requested);
                    JsonNode args=normalizeLegacyArgs(requested,tool,call.arguments());
                    if (Set.of("todowrite", "todo_update").contains(tool)) {
                        appendNativeToolResult(child, call.id(), requested, "SUBAGENT TOOL DENIED: child sessions cannot advance or replace the parent approved plan.");
                        continue;
                    }
                    if(!childNames.contains(requested)&&!childNames.contains(tool)){
                        appendNativeToolResult(child,call.id(),requested,"SUBAGENT TOOL DENIED: tool is not available to subagent '"+agentId+"'.");
                        continue;
                    }
                    onStep.accept(stepEvent(parentStep,"subagent:"+agentId+"→"+tool,describeTool(tool,args),"running",args,null,null));
                    PreparedCall childCall = new PreparedCall(call, requested, tool, args, describeTool(tool,args));
                    ToolExecution execution = preflightCall(childCall, mcpCatalog);
                    if (execution == null) {
                        execution=executeWithPermission(ws,parentRun,tool,args,request.settings(),"Subagent "+agentId+": "+describeTool(tool,args),parentStep,onStep,
                                mcpCatalog,childTools,apiKey,request);
                    }
                    execution = applyChildRepeatOutcomeGuard(childCall, execution, parentRun, childRepeatedOutcomes, mcpCatalog);
                    if(execution.executed()){ observeRun(parentRun,tool,args,execution.result()); toolActivity++; }
                    onStep.accept(stepEvent(parentStep,"subagent:"+agentId+"→"+tool,summarizeResult(tool,execution.result()),execution.status(),args,clipUi(execution.result()),null));
                    appendNativeToolResult(child,call.id(),requested,execution.result());
                    if (execution.result().startsWith("SUBAGENT LOOP BLOCKED:")) {
                        return "SUBAGENT " + agentId + " BLOCKED\n" + execution.result() + "\n\nchildToolActions=" + toolActivity;
                    }
                }
                continue;
            }
            JsonNode env=parseEnvelope(raw);
            if(env!=null&&env.isObject()&&"tool".equals(env.path("type").asText(""))){
                emptyChildTurns = 0;
                String requested=env.path("tool").asText(""); String tool=toolRegistry.canonical(requested);
                JsonNode args=normalizeLegacyArgs(requested,tool,env.path("args"));
                if (Set.of("todowrite", "todo_update").contains(tool)) {
                    child.add(Map.of("role", "user", "content", "Child sessions cannot advance or replace the parent approved plan. Continue delegated work and report evidence."));
                    continue;
                }
                if(!childNames.contains(requested)&&!childNames.contains(tool)){ child.add(Map.of("role","user","content","That tool is unavailable to this subagent. Use one of: "+String.join(", ",childNames))); continue; }
                PreparedCall childCall = new PreparedCall(
                        new OpenAiCompatibleClient.AgentToolCall("subagent_compat_" + childTurn, requested, args),
                        requested, tool, args, describeTool(tool,args));
                ToolExecution execution = preflightCall(childCall, mcpCatalog);
                if (execution == null) {
                    execution=executeWithPermission(ws,parentRun,tool,args,request.settings(),"Subagent "+agentId+": "+describeTool(tool,args),parentStep,onStep,
                            mcpCatalog,childTools,apiKey,request);
                }
                execution = applyChildRepeatOutcomeGuard(childCall, execution, parentRun, childRepeatedOutcomes, mcpCatalog);
                if(execution.executed()){ observeRun(parentRun,tool,args,execution.result()); toolActivity++; }
                appendFallbackToolTranscript(child,raw,tool,execution.result());
                if (execution.result().startsWith("SUBAGENT LOOP BLOCKED:")) {
                    return "SUBAGENT " + agentId + " BLOCKED\n" + execution.result() + "\n\nchildToolActions=" + toolActivity;
                }
                continue;
            }
            if(!raw.isBlank()) return "SUBAGENT "+agentId+" REPORT\n"+raw+"\n\nchildToolActions="+toolActivity;
            emptyChildTurns++;
            if (emptyChildTurns >= MAX_CONSECUTIVE_EMPTY_SUBAGENT_TURNS) {
                parentRun.markRepeatedCallPrevented();
                return "SUBAGENT " + agentId + " BLOCKED\nThe subagent returned empty/non-actionable turns repeatedly; the child session was stopped to protect the token budget.\n\nchildToolActions=" + toolActivity;
            }
            child.add(Map.of("role","user","content","Continue the delegated task using the available tools, then return your findings."));
        }
    }

    /**
     * After a new workspace revision has passed a verifier, ask the model once — with no tools exposed — whether
     * the original request is actually satisfied. This prevents the common "tests are green but agent keeps
     * searching/polling" tail without blindly assuming that every intermediate green build means the whole task is done.
     * Return CONTINUE when more requested work remains; otherwise return the final user-facing answer.
     */
    private String completionGate(String apiKey, ChatRequest request, List<Map<String,Object>> messages,
                                  AgentRunService.AgentRun run, int step, Consumer<Map<String,Object>> onStep) {
        try {
            List<Map<String,Object>> gate = new ArrayList<>(messages);
            gate.add(Map.of("role", "user", "content", """
                    RUNTIME COMPLETION CHECK. The current workspace revision has just passed its required verifier.
                    Decide whether the user's ORIGINAL request is fully satisfied based only on the conversation, workspace evidence and verifier result already present.
                    - If any requested implementation/fix/migration/test/documentation work is still incomplete, output exactly: CONTINUE
                    - If the request is complete, return the concise final answer to the user now: what changed and the verification performed.
                    - Do not propose extra optional work. Do not request or simulate tools. Do not repeat investigation that is already complete.
                    """));
            String criticModel = request.settings().criticModelOrPrimary();
            // A critic may have a smaller context window than the active executor. Bound the copied completion
            // prompt against the critic's own window before sending it, without mutating the live executor history.
            contextWindows.pruneSupersededRuntimeSteering(gate);
            ContextWindowManager.ContextEstimate estimate = contextWindows.estimate(gate, List.of(), request.settings(), criticModel);
            if (estimate.estimatedInputTokens() > estimate.inputLimitTokens()) {
                contextWindows.pruneOldToolOutputs(gate, request.settings(), true);
                estimate = contextWindows.estimate(gate, List.of(), request.settings(), criticModel);
                if (estimate.estimatedInputTokens() > estimate.inputLimitTokens()) {
                    contextWindows.compact(gate, List.of(), request.settings(), run, true, null, criticModel);
                    estimate = contextWindows.estimate(gate, List.of(), request.settings(), criticModel);
                }
            }
            run.recordContextEstimate(estimate.estimatedInputTokens(), estimate.contextWindowTokens());
            int maxOut = request.settings().safeMaxTokens() > 0 ? Math.min(2_500, request.settings().safeMaxTokens()) : 2_500;
            if (!criticModel.equals(effectiveModel(run, request.settings()))) {
                onStep.accept(stepEvent(step, "model_route", "Completion critic: " + criticModel, "success", null, null, null));
            }
            OpenAiCompatibleClient.AgentCompletion completion = completeRoleText(
                    apiKey, request, run, criticModel, ModelCapabilityRegistry.Role.CRITIC, maxOut, gate, step, onStep, "completion check");
            run.recordModelUsage(completion.usage(), estimate.estimatedInputTokens());
            String value = completion.content() == null ? "" : completion.content().trim();
            onStep.accept(stepEvent(step, "completion_check",
                    "Verified revision completion check: " + ("CONTINUE".equalsIgnoreCase(value) ? "more requested work remains" : "task satisfied"),
                    "CONTINUE".equalsIgnoreCase(value) ? "running" : "success", null, null, null));
            return value;
        } catch (Exception e) {
            // Completion acceleration is an optimization, not a correctness dependency. Resume the ordinary agent loop.
            onStep.accept(stepEvent(step, "completion_check", "Completion check unavailable; continuing normal agent flow", "running", null, clipUi(safe(e.getMessage())), null));
            return "CONTINUE";
        }
    }

    private OpenAiCompatibleClient.AgentCompletion completeAgentTurn(String apiKey, ChatRequest request,
                                                                      List<Map<String, Object>> messages,
                                                                      AgentWorkspaceService.Workspace ws,
                                                                      AgentRunService.AgentRun run,
                                                                      boolean requireTool,
                                                                      List<Map<String,Object>> availableTools,
                                                                      int step,
                                                                      Consumer<Map<String,Object>> onStep) throws Exception {
        int transientAttempt = 0;
        boolean overflowRecovered = false;
        final int recoveryLimit = request.settings().safeAgentRecoveryAttempts();
        while (true) {
            run.checkCancelled();
            String model = effectiveModel(run, request.settings());
            prepareActiveContext(apiKey, request, model, messages, availableTools, request.settings(), ws, run, step, onStep, false);
            ContextWindowManager.ContextEstimate estimate = contextWindows.estimate(messages, availableTools, request.settings(), model);
            run.recordContextEstimate(estimate.estimatedInputTokens(), estimate.contextWindowTokens());
            try {
                OpenAiCompatibleClient.AgentCompletion turn = llm.completeAgent(apiKey, request.settings().baseUrl(), model,
                        request.settings().safeMaxTokens(), messages,
                        availableTools, requireTool, run::cancelled);
                run.recordModelUsage(turn.usage(), estimate.estimatedInputTokens());
                if (run.modelCalls() == 1 || run.modelCalls() % 10 == 0) {
                    onStep.accept(stepEvent(step, "token_usage", tokenUsageDetail(run), "success", null, null, null));
                }
                return turn;
            } catch (AgentCancelledException cancelled) {
                throw cancelled;
            } catch (Exception e) {
                if (isContextWindowFailure(e) && !overflowRecovered) {
                    ContextWindowManager.CompactionResult compacted = contextWindows.compact(messages, availableTools,
                            request.settings(), run, true, compactionSummarizer(apiKey, request, model, run), model);
                    overflowRecovered = true;
                    if (compacted.compacted()) {
                        run.recordCompaction(compacted.estimatedTokensSaved(), compacted.reason());
                        onStep.accept(stepEvent(step, "context_compaction",
                                "Provider context overflow recovered: " + formatCompaction(compacted),
                                "success", null, null, null));
                        continue;
                    }
                }
                String error = safe(e.getMessage());
                if (isModelUnavailableFailure(e)) {
                    if (switchToNextModel(run, onStep, step, "Model unavailable: " + error)) {
                        transientAttempt = 0;
                        overflowRecovered = false;
                        messages.add(Map.of("role", "system", "content", modelFailoverContinuation(run)));
                        continue;
                    }
                    throw new ExecutorPoolExhaustedException("No configured execution model is available", error, e);
                }
                if (!isTransientModelFailure(e)) {
                    if (!isAuthenticationFailure(e) && switchToNextModel(run, onStep, step, "Executor model failed: " + error)) {
                        transientAttempt = 0;
                        overflowRecovered = false;
                        messages.add(Map.of("role", "system", "content", modelFailoverContinuation(run)));
                        continue;
                    }
                    if (!isAuthenticationFailure(e)) {
                        throw new ExecutorPoolExhaustedException("Every configured execution model failed", error, e);
                    }
                    throw e;
                }
                transientAttempt++;
                if (transientAttempt >= recoveryLimit) {
                    if (switchToNextModel(run, onStep, step, "Transient model failures exhausted " + recoveryLimit + " attempts: " + error)) {
                        transientAttempt = 0;
                        overflowRecovered = false;
                        messages.add(Map.of("role", "system", "content", modelFailoverContinuation(run)));
                        continue;
                    }
                    throw new ExecutorPoolExhaustedException(
                            "Every configured execution model exhausted transient retries", error, e);
                }
                long waitMs = Math.min(8_000L, 500L << Math.min(4, Math.max(0, transientAttempt - 1)));
                onStep.accept(stepEvent(step, "agent_recovery", "Transient model error on " + model + "; retrying " + transientAttempt + "/" + recoveryLimit, "running", null, clipUi(error), null));
                sleepCancellable(run, waitMs);
            }
        }
    }

    private void prepareActiveContext(String apiKey, ChatRequest request, String model,
                                      List<Map<String,Object>> messages, List<Map<String,Object>> availableTools,
                                      ChatSettings settings, AgentWorkspaceService.Workspace ws, AgentRunService.AgentRun run, int step,
                                      Consumer<Map<String,Object>> onStep, boolean forced) {
        // Keep changing runtime state and retrieval hints at the suffix. The stable system/user prefix therefore stays
        // provider-cache friendly while the model receives the exact active plan/revision without replaying old events.
        contextWindows.upsertDurableRuntimeState(messages, run.durableContextText());
        String retrievalQuery = (run.objective() + " " + run.activePlanStepText()).strip();
        String retrievalHints = ws == null || retrievalQuery.isBlank() ? "" : workspaceRetrieval.retrieveHybrid(ws, retrievalQuery, 8, 8_000, apiKey, settings, run::cancelled);
        contextWindows.upsertRetrievalHints(messages, retrievalHints);

        ContextWindowManager.ContextEstimate beforePrune = contextWindows.estimate(messages, availableTools, settings, model);
        boolean aggressive = contextWindows.shouldAggressivelyPrune(messages, availableTools, settings, model);
        int steeringPruned = contextWindows.pruneSupersededRuntimeSteering(messages);
        int pruned = contextWindows.pruneOldToolOutputs(messages, settings, aggressive);
        ContextWindowManager.ContextEstimate before = contextWindows.estimate(messages, availableTools, settings, model);
        long pruningSaved = Math.max(0, beforePrune.estimatedInputTokens() - before.estimatedInputTokens());
        if (pruned + steeringPruned > 0 || pruningSaved > 0) run.recordPruning(pruned + steeringPruned, pruningSaved);
        run.recordContextEstimate(before.estimatedInputTokens(), before.contextWindowTokens());
        boolean should = forced || contextWindows.shouldCompact(messages, availableTools, settings, model);
        if (!should) return;
        // Deterministic checkpoints are cheap and preserve runtime facts. Use the model summarizer only periodically
        // (or for forced overflow recovery) so compaction itself does not become a major token consumer.
        ContextWindowManager.CompactionSummarizer summarizer = (forced || run.compactions() % 5 == 4)
                ? compactionSummarizer(apiKey, request, model, run) : null;
        ContextWindowManager.CompactionResult result = contextWindows.compact(messages, availableTools, settings, run, forced, summarizer, model);
        if (!result.compacted()) return;
        run.recordCompaction(result.estimatedTokensSaved(), result.reason());
        String extra = (pruned > 0 ? "; pruned " + pruned + (aggressive ? " aggressively" : "") + " old/oversized tool observation(s)" : "") +
                (steeringPruned > 0 ? "; removed " + steeringPruned + " superseded runtime steering message(s)" : "") +
                (pruningSaved > 0 ? "; saved ~" + pruningSaved + " tokens before compaction" : "");
        onStep.accept(stepEvent(step, "context_compaction", formatCompaction(result) + extra,
                "success", null, null, null));
    }

    private ContextWindowManager.CompactionSummarizer compactionSummarizer(String apiKey, ChatRequest request,
                                                                              String model,
                                                                              AgentRunService.AgentRun run) {
        String summaryModel = model == null || model.isBlank() ? request.settings().model() : model;
        return (prompt, maxOutputTokens) -> {
            run.checkCancelled();
            int estimatedInput = Math.max(1, (prompt.length() + 3) / 4) + 256;
            OpenAiCompatibleClient.AgentCompletion summary = llm.completeTextWithUsage(
                    apiKey, request.settings().baseUrl(), summaryModel, maxOutputTokens,
                    List.of(Map.of("role", "user", "content", prompt)), run::cancelled);
            run.recordModelUsage(summary.usage(), estimatedInput);
            return summary.content();
        };
    }

    private String formatCompaction(ContextWindowManager.CompactionResult result) {
        ContextWindowManager.ContextEstimate after = result.after();
        return result.reason() + ": saved ~" + result.estimatedTokensSaved() + " active tokens; context now ~" +
                after.estimatedInputTokens() + "/" + after.contextWindowTokens() + " tokens";
    }

    private String tokenUsageDetail(AgentRunService.AgentRun run) {
        long total = run.providerTotalTokens();
        String provider = total > 0
                ? "provider run total " + total + " tokens (input " + run.providerInputTokens() +
                ", output " + run.providerOutputTokens() + ", cached input " + run.cachedInputTokens() + ")"
                : "provider did not report usage; runtime estimates are active";
        return "Context ~" + run.currentContextTokens() + "/" + run.contextWindowTokens() + " tokens; " +
                provider + "; compactions " + run.compactions() +
                "; pruned observations " + run.prunedObservations() +
                "; estimated pruning savings " + run.estimatedTokensSavedByPruning() + " tokens";
    }

    private ToolExecution executeWithPermission(AgentWorkspaceService.Workspace ws, AgentRunService.AgentRun run,
                                                String tool, JsonNode args, ChatSettings settings, String detail,
                                                int step, Consumer<Map<String, Object>> onStep,
                                                McpManager.Catalog mcpCatalog, List<Map<String,Object>> availableTools,
                                                String apiKey, ChatRequest request) {
        String permission = permissionFor(tool, settings);
        if ("deny".equals(permission)) {
            return new ToolExecution("TOOL DENIED BY PERMISSION: " + tool, "error", false);
        }
        try {
            run.updateActivity(phaseForTool(tool), detail);
            if ("ask".equals(permission) && !settings.autoApproveAgent() && !run.isToolApprovedForRun(tool)) {
                AgentApprovalService.Approval approval = approvals.create(run.id(), tool, detail);
                onStep.accept(stepEvent(step, tool, detail, "approval", args, null, approval.id()));
                AgentApprovalService.Decision decision = approvals.await(approval.id(), Duration.ZERO, run);
                if (decision == AgentApprovalService.Decision.DENY) {
                    return new ToolExecution("TOOL DENIED BY USER: " + tool, "error", false);
                }
                if (decision == AgentApprovalService.Decision.RUN) run.approveToolForRun(tool);
                onStep.accept(stepEvent(step, tool, decision == AgentApprovalService.Decision.RUN
                        ? "Allowed for this run — executing tool" : "Approved once — executing tool",
                        "running", args, null, null));
            }
            String result = execute(ws, run, tool, args, settings, mcpCatalog, availableTools, apiKey, request, step, onStep);
            String status = isFailedCommandResult(tool, result) || (tool != null && tool.startsWith("mcp__") && result != null && result.contains("isError=true")) ? "error" : "success";
            return new ToolExecution(result, status, true);
        } catch (AgentCancelledException cancelled) {
            throw cancelled;
        } catch (Exception e) {
            String error = "TOOL ERROR: " + safe(e.getMessage());
            // A verifier that could not even start is still a real verification attempt. Recording it lets the
            // agent distinguish an external execution blocker from an ordinary unverified edit, rather than
            // repeatedly forcing the model back into the same command forever.
            if (isVerifier(tool, args)) run.markVerificationAttempt(false, summarizeResult(tool, error));
            return new ToolExecution(error, "error", false);
        }
    }

    private String execute(AgentWorkspaceService.Workspace ws, AgentRunService.AgentRun run, String tool,
                           JsonNode args, ChatSettings settings, McpManager.Catalog mcpCatalog,
                           List<Map<String,Object>> availableTools, String apiKey, ChatRequest request,
                           int parentStep, Consumer<Map<String,Object>> onStep) throws Exception {
        if (mcp.isMcpTool(mcpCatalog, tool)) return mcp.call(ws.root(), mcpCatalog, tool, args, run::cancelled);
        return switch (tool) {
            case "inspect_workspace" -> workspaces.inspectWorkspace(ws);
            case "workspace_profile" -> workspaceProfiles.profileText(ws);
            case "workspace_profile_refresh" -> workspaceProfiles.refresh(ws);
            case "list" -> workspaces.listFiles(ws, firstNonBlank(text(args, "path"), text(args, "prefix")));
            case "glob" -> workspaces.glob(ws, requiredText(args, "pattern"), args.path("maxMatches").asInt(0));
            case "grep" -> args.path("regex").asBoolean(false)
                    ? workspaces.regexSearch(ws, requiredText(args, "pattern"), args.path("maxMatches").asInt(0))
                    : workspaces.search(ws, requiredText(args, "pattern"), args.path("maxMatches").asInt(0));
            case "file_info" -> workspaces.fileInfo(ws, requiredText(args, "path"));
            case "file_index" -> workspaces.fileIndex(ws, requiredText(args, "path"));
            case "read" -> {
                int start = args.path("startLine").asInt(1);
                int end = args.has("endLine") ? args.path("endLine").asInt(Integer.MAX_VALUE) : Integer.MAX_VALUE;
                yield workspaces.readFileRange(ws, requiredText(args, "path"), start, end);
            }
            case "read_chunk" -> workspaces.readFileChunk(ws, requiredText(args, "path"), Math.max(0L, args.path("offsetChars").asLong(0L)), args.path("maxChars").asInt(0));
            case "read_many" -> workspaces.readFiles(ws, stringList(args, "paths"));
            case "instruction_catalog" -> workspaces.instructionCatalog(ws);
            case "instructions_for" -> workspaces.instructionsFor(ws, requiredText(args, "path"));
            case "resource_catalog" -> workspaces.resourceCatalog(ws);
            case "resource_list" -> workspaces.resourceList(ws, requiredText(args, "alias"), text(args, "path"));
            case "resource_info" -> workspaces.resourceFileInfo(ws, requiredText(args, "alias"), text(args, "path"));
            case "resource_index" -> workspaces.resourceIndex(ws, requiredText(args, "alias"), text(args, "path"));
            case "resource_read" -> workspaces.resourceRead(ws, requiredText(args, "alias"), text(args, "path"),
                    args.path("startLine").asInt(1), args.has("endLine") ? args.path("endLine").asInt(Integer.MAX_VALUE) : Integer.MAX_VALUE);
            case "resource_chunk" -> workspaces.resourceReadChunk(ws, requiredText(args, "alias"), text(args, "path"),
                    Math.max(0L, args.path("offsetChars").asLong(0L)), args.path("maxChars").asInt(0));
            case "resource_grep" -> workspaces.resourceGrep(ws, requiredText(args, "alias"), requiredText(args, "pattern"),
                    args.path("regex").asBoolean(false), args.path("maxMatches").asInt(0));
            case "resource_edit" -> workspaces.resourceEdit(ws, requiredText(args, "alias"), requiredText(args, "path"),
                    requiredText(args, "oldText"), text(args, "newText"), args.path("replaceAll").asBoolean(false));
            case "resource_write" -> workspaces.resourceWrite(ws, requiredText(args, "alias"), requiredText(args, "path"), text(args, "content"));
            case "resource_delete" -> workspaces.resourceDelete(ws, requiredText(args, "alias"), requiredText(args, "path"));
            case "resource_copy" -> workspaces.resourceCopy(ws, requiredText(args, "fromAlias"), text(args, "fromPath"), requiredText(args, "toAlias"), requiredText(args, "toPath"), args.path("overwrite").asBoolean(false));
            case "resource_move" -> workspaces.resourceMove(ws, requiredText(args, "fromAlias"), requiredText(args, "fromPath"), requiredText(args, "toAlias"), requiredText(args, "toPath"), args.path("overwrite").asBoolean(false));
            case "resource_build" -> workspaces.resourceBuild(ws, requiredText(args, "alias"), settings.agentCommandsAllowed(), run).asToolText();
            case "resource_test" -> workspaces.resourceTests(ws, requiredText(args, "alias"), settings.agentCommandsAllowed(), run).asToolText();
            case "resource_check" -> workspaces.resourceCheck(ws, requiredText(args, "alias"), settings.agentCommandsAllowed(), run).asToolText();
            case "resource_bash" -> workspaces.resourceCommand(ws, requiredText(args, "alias"), requiredText(args, "command"),
                    Math.max(0L, args.path("timeoutSeconds").asLong(0L)), settings.agentCommandsAllowed(), settings.extraAgentCommands(), run).asToolText();
            case "attachment_list" -> files.attachmentListForAgent(run.conversationId());
            case "attachment_read" -> files.attachmentTextForAgent(run.conversationId(), requiredText(args, "fileId"),
                    Math.max(0, args.path("offset").asInt(0)), args.path("maxChars").asInt(0));
            case "attachment_search" -> files.attachmentSearchForAgent(run.conversationId(), requiredText(args, "query"),
                    text(args, "fileId"), args.path("maxMatches").asInt(0));
            case "skill_catalog" -> workspaces.availableSkills(ws);
            case "skill" -> workspaces.loadSkill(ws, requiredText(args, "name"));
            case "agent_catalog" -> agentProfiles.catalogText(ws);
            case "task" -> runSubagent(ws, run, request, apiKey, mcpCatalog, availableTools,
                    requiredText(args, "agent"), requiredText(args, "prompt"), parentStep, onStep);
            case "tool_search" -> loadDeferredTools(availableTools, mcpCatalog, requiredText(args, "query"), args.path("maxResults").asInt(12));
            case "mcp_status" -> mcp.status(ws.root());
            case "lsp_status" -> lsp.status(ws.root());
            case "lsp" -> lsp.call(ws.root(), requiredText(args, "operation"), text(args, "path"),
                    Math.max(0, args.path("line").asInt(0)), Math.max(0, args.path("character").asInt(0)),
                    text(args, "query"), text(args, "server"), run::cancelled);
            case "edit" -> workspaces.editFile(ws, requiredText(args, "path"), requiredText(args, "oldText"), text(args, "newText"), args.path("replaceAll").asBoolean(false));
            case "write" -> workspaces.writeFile(ws, requiredText(args, "path"), text(args, "content"));
            case "copy" -> workspaces.copyFile(ws, requiredText(args, "from"), requiredText(args, "to"), args.path("overwrite").asBoolean(false));
            case "move" -> workspaces.moveFile(ws, requiredText(args, "from"), requiredText(args, "to"), args.path("overwrite").asBoolean(false));
            case "delete" -> workspaces.deleteFile(ws, requiredText(args, "path"));
            case "apply_patch" -> workspaces.applyPatch(ws, args.path("changes"), text(args, "patch"));
            case "build" -> workspaces.runBuild(ws, text(args, "cwd"), settings.agentCommandsAllowed(), run).asToolText();
            case "test" -> workspaces.runTests(ws, text(args, "cwd"), settings.agentCommandsAllowed(), run).asToolText();
            case "check" -> workspaces.runCheck(ws, text(args, "cwd"), settings.agentCommandsAllowed(), run).asToolText();
            case "bash" -> workspaces.runCommand(ws, requiredText(args, "command"), text(args, "cwd"),
                    settings.agentCommandsAllowed(), settings.extraAgentCommands(),
                    Math.max(0L, args.path("timeoutSeconds").asLong(0L)), run).asToolText();
            case "process_start" -> workspaces.startProcess(ws, requiredText(args, "command"), text(args, "cwd"), settings.agentCommandsAllowed(), run);
            case "process_status" -> workspaces.processStatus(ws, requiredText(args, "processId"));
            case "process_output" -> workspaces.processOutput(ws, requiredText(args, "processId"),
                    Math.max(0L, args.path("offset").asLong(0L)), args.path("maxChars").asInt(0));
            case "process_stop" -> workspaces.stopProcess(ws, requiredText(args, "processId"));
            case "http_request" -> workspaces.httpRequest(firstNonBlank(text(args, "method"), "GET"), requiredText(args, "url"),
                    stringList(args, "headers"), text(args, "body"), args.path("timeoutSeconds").asLong(0), run);
            case "workspace_status" -> workspaces.workspaceStatus(ws);
            case "workspace_diff" -> workspaces.workspaceDiff(ws, text(args, "path"));
            case "todowrite" -> setTodos(run, stringList(args, "items"));
            case "todoread" -> run.planText();
            case "todo_update" -> updateTodo(run, args);
            default -> throw new IllegalArgumentException("Unknown agent tool: " + tool);
        };
    }

    private String loadDeferredTools(List<Map<String,Object>> availableTools, McpManager.Catalog mcpCatalog, String query, int maxResults) {
        List<Map<String,Object>> matches = toolRegistry.searchDefinitions(mcpCatalog == null ? List.of() : mcpCatalog.definitions(), query, maxResults);
        if (matches.isEmpty()) return "[No deferred MCP tools matched: " + query + "]";
        Set<String> active = new HashSet<>();
        for (Map<String,Object> def : availableTools) active.add(toolRegistry.functionName(def));
        List<String> loaded = new ArrayList<>();
        for (Map<String,Object> def : matches) {
            String name = toolRegistry.functionName(def);
            if (active.add(name)) { availableTools.add(def); loaded.add(name); }
        }
        if (loaded.isEmpty()) return "[Matching MCP tools were already loaded: " + query + "]";
        return "Loaded " + loaded.size() + " deferred MCP tool definition(s):\n" + String.join("\n", loaded);
    }

    JsonNode normalizeLegacyArgs(String requestedTool, String canonicalTool, JsonNode rawArgs) {
        JsonNode args = rawArgs == null || !rawArgs.isObject() ? objectMapper.createObjectNode() : rawArgs.deepCopy();
        if (!(args instanceof com.fasterxml.jackson.databind.node.ObjectNode obj)) return args;
        String requested = requestedTool == null ? "" : toolRegistry.sanitizeToolName(requestedTool).toLowerCase(Locale.ROOT);

        // Providers frequently emit generic `search({query: ...})` even when the exposed built-in is grep(pattern).
        // Repair the schema once at the boundary instead of making the model burn recovery turns on the same error.
        if ("grep".equals(canonicalTool) && !obj.hasNonNull("pattern")) {
            for (String candidate : List.of("query", "text", "term", "search", "needle")) {
                if (obj.hasNonNull(candidate) && !obj.path(candidate).asText("").isBlank()) {
                    obj.set("pattern", obj.path(candidate));
                    break;
                }
            }
        }
        if ("regex_search".equals(requested)) {
            if (!obj.hasNonNull("pattern") && obj.hasNonNull("regex") && obj.path("regex").isTextual()) {
                obj.set("pattern", obj.path("regex"));
            }
            obj.put("regex", true);
        }
        if ("list".equals(canonicalTool) && !obj.hasNonNull("path") && obj.hasNonNull("prefix")) obj.set("path", obj.path("prefix"));
        if ("glob".equals(canonicalTool) && !obj.hasNonNull("pattern")) {
            for (String candidate : List.of("query", "glob", "pathPattern")) {
                if (obj.hasNonNull(candidate) && !obj.path(candidate).asText("").isBlank()) {
                    obj.set("pattern", obj.path(candidate));
                    break;
                }
            }
        }
        if ("read_file_range".equals(requested) && !obj.has("endLine")) obj.put("endLine", 200);
        if ("todowrite".equals(canonicalTool) && !obj.has("items") && obj.has("todos")) obj.set("items", obj.path("todos"));
        if ("todo_update".equals(canonicalTool)) {
            if (!obj.has("index") && obj.has("id")) obj.set("index", obj.path("id"));
            if (!obj.has("status") && obj.has("state")) obj.set("status", obj.path("state"));
        }
        if ("apply_patch".equals(canonicalTool) && !obj.has("patch") && obj.hasNonNull("input") && obj.path("input").isTextual()) {
            obj.set("patch", obj.path("input"));
        }
        return obj;
    }

    private String setTodos(AgentRunService.AgentRun run, List<String> items) {
        if (run.planLocked()) {
            throw new IllegalStateException("Approved sequential plan is locked. Use todo_update only on active step " + run.activePlanIndex());
        }
        run.setPlan(items);
        return "Todos updated:\n" + run.planText();
    }

    private String updateTodo(AgentRunService.AgentRun run, JsonNode args) {
        int index = args == null ? 0 : args.path("index").asInt(0);
        if (index < 1) throw new IllegalArgumentException("Todo index must be >= 1");
        run.updatePlan(index, requiredText(args, "status"), text(args, "note"));
        return "Todos updated:\n" + run.planText();
    }

    private int progressForTool(String tool, AgentRunService.AgentRun run) {
        if (tool == null) return 18;
        if (Set.of("edit", "write", "copy", "move", "delete", "apply_patch", "resource_edit", "resource_write", "resource_delete", "resource_copy", "resource_move").contains(tool)) return 48;
        if (Set.of("build", "test", "check", "resource_build", "resource_test", "resource_check").contains(tool)) return 72;
        if (Set.of("bash", "resource_bash", "process_start", "process_status", "process_output", "process_stop", "http_request").contains(tool)) return run.mutationRevision() > 0 ? 68 : 36;
        if (Set.of("workspace_status", "workspace_diff").contains(tool)) return 84;
        if ("task".equals(tool)) return 30;
        if (tool.startsWith("mcp__") || "lsp".equals(tool) || "lsp_status".equals(tool)) return run.mutationRevision() > 0 ? 64 : 32;
        return run.mutationRevision() > 0 ? 62 : 24;
    }

    private String phaseForTool(String tool) {
        if (tool == null) return "working";
        if (Set.of("edit", "write", "copy", "move", "delete", "apply_patch", "resource_edit", "resource_write", "resource_delete", "resource_copy", "resource_move").contains(tool)) return "editing";
        if (Set.of("build", "test", "check", "resource_build", "resource_test", "resource_check").contains(tool)) return "verifying";
        if (Set.of("bash", "resource_bash", "process_start", "process_status", "process_output", "process_stop", "http_request").contains(tool)) return "executing";
        if (Set.of("workspace_status", "workspace_diff").contains(tool)) return "reviewing";
        if ("task".equals(tool)) return "delegating";
        return "inspecting";
    }

    private void observeRun(AgentRunService.AgentRun run, String tool, JsonNode args, String result) {
        run.recordPlanToolActivity(tool, summarizeResult(tool, result));
        if (isMutationTool(tool)) {
            if (directMutationChanged(result)) {
                run.recordTouchedPaths(mutationPaths(tool, args));
                run.markMutation(mutationNeedsVerification(tool, args));
                run.updateActivity("editing", "Workspace changes applied");
            } else {
                run.updateActivity("editing", "Requested edit already matched the workspace; no new revision created");
            }
        } else if ("resource_bash".equals(tool) && result != null && result.contains("resourceChanged=true")) {
            run.markMutation(true);
        } else if ("bash".equals(tool) && result != null && result.contains("workspaceChanged=true")) {
            // Shell commands are intentionally unrestricted within the selected workspace and may edit files.
            // Any detected shell mutation creates a new revision that must be verified before completion.
            run.markMutation(true);
        }
        if ("workspace_diff".equals(tool)) run.markDiffReview();
        if (isVerifier(tool, args)) {
            boolean success = result != null && (result.startsWith("exitCode=0;") || httpVerificationSuccess(result));
            run.markVerificationAttempt(success, summarizeResult(tool, result));
            run.updateActivity(success ? "verified" : "fixing",
                    success ? "Verification passed" : "Verification failed; diagnosing and fixing");
        }
    }

    private boolean isVerifier(String tool, JsonNode args) {
        return Set.of("build", "test", "check", "resource_build", "resource_test", "resource_check").contains(tool)
                || (("bash".equals(tool) || "resource_bash".equals(tool) || "http_request".equals(tool))
                && args != null && args.path("verification").asBoolean(false));
    }

    private boolean looksLikeBlockedFinal(String raw) {
        if (raw == null || raw.isBlank()) return false;
        String low = raw.stripLeading().toLowerCase(Locale.ROOT);
        while (low.startsWith(">")) low = low.substring(1).stripLeading();
        return low.startsWith("blocked:") || low.startsWith("**blocked:**") || low.startsWith("**status: blocked**")
                || low.startsWith("status: blocked");
    }

    private boolean externalVerificationBlocker(String lastVerification) {
        if (lastVerification == null || lastVerification.isBlank()) return false;
        String low = lastVerification.toLowerCase(Locale.ROOT);
        return low.contains("unable to start command")
                || low.contains("cannot run program")
                || low.contains("createprocess error")
                || low.contains("being used by another process")
                || low.contains("sharing violation")
                || low.contains("access is denied")
                || low.contains("permission denied")
                || low.contains("operation not permitted")
                || low.contains("no space left on device")
                || low.contains("not enough storage");
    }

    private boolean httpVerificationSuccess(String result) {
        if (result == null || !result.startsWith("statusCode=")) return false;
        int semi = result.indexOf(';');
        String value = semi < 0 ? result.substring("statusCode=".length()) : result.substring("statusCode=".length(), semi);
        try {
            int code = Integer.parseInt(value.trim());
            return code >= 200 && code < 400;
        } catch (Exception ignored) { return false; }
    }

    private boolean requiresCurrentRevisionVerification(AgentRunService.AgentRun run) {
        return run.verificationRequired();
    }

    private List<String> mutationPaths(String tool, JsonNode args) {
        if (args == null || args.isMissingNode() || args.isNull()) return List.of();
        LinkedHashSet<String> paths = new LinkedHashSet<>();
        if (Set.of("edit", "write", "delete", "resource_edit", "resource_write", "resource_delete").contains(tool)) {
            String path = text(args, "path");
            if (!path.isBlank()) paths.add(path);
        } else if (Set.of("resource_copy", "resource_move").contains(tool)) {
            for (String key : List.of("fromPath", "toPath")) { String path = text(args, key); if (!path.isBlank()) paths.add(path); }
        } else if (Set.of("copy", "move").contains(tool)) {
            for (String key : List.of("from", "to")) { String path = text(args, key); if (!path.isBlank()) paths.add(path); }
        } else if ("apply_patch".equals(tool)) {
            if (args.path("changes").isArray()) {
                for (JsonNode change : args.path("changes")) {
                    String path = change.path("path").asText("").strip();
                    if (!path.isBlank()) paths.add(path);
                }
            }
            String patch = args.path("patch").asText("");
            if (!patch.isBlank()) {
                java.util.regex.Matcher m = java.util.regex.Pattern.compile("(?m)^(?:\\+\\+\\+|---)\\s+(?:[ab]/)?([^\\t\\r\\n]+)").matcher(patch);
                while (m.find() && paths.size() < 30) {
                    String path = m.group(1).strip();
                    if (!path.equals("/dev/null") && !path.isBlank()) paths.add(path);
                }
            }
        }
        return List.copyOf(paths);
    }

    private boolean mutationNeedsVerification(String tool, JsonNode args) {
        List<String> paths = new ArrayList<>();
        if (Set.of("edit", "write", "delete", "resource_edit", "resource_write", "resource_delete").contains(tool)) paths.add(text(args, "path"));
        else if (Set.of("resource_copy", "resource_move").contains(tool)) { paths.add(text(args, "fromPath")); paths.add(text(args, "toPath")); }
        else if (Set.of("copy", "move").contains(tool)) { paths.add(text(args, "from")); paths.add(text(args, "to")); }
        else if ("apply_patch".equals(tool) && args != null) {
            if (args.path("changes").isArray()) {
                for (JsonNode change : args.path("changes")) paths.add(change.path("path").asText(""));
            }
            if (!text(args, "patch").isBlank()) return true;
        }
        for (String path : paths) {
            String p = path == null ? "" : path.replace('\\','/').toLowerCase(Locale.ROOT);
            String name = p.substring(p.lastIndexOf('/') + 1);
            if (Set.of("pom.xml", "package.json", "build.gradle", "build.gradle.kts", "settings.gradle", "settings.gradle.kts",
                    "pyproject.toml", "setup.py", "requirements.txt", "go.mod", "cargo.toml", "makefile", "cmakelists.txt",
                    "dockerfile", "compose.yml", "compose.yaml", "application.properties", "application.yml", "application.yaml").contains(name)) return true;
            int dot = name.lastIndexOf('.');
            String ext = dot < 0 ? "" : name.substring(dot + 1);
            if (Set.of("java","kt","kts","groovy","scala","js","jsx","ts","tsx","mjs","cjs","py","rb","php","go","rs",
                    "c","cc","cpp","cxx","h","hpp","cs","fs","swift","dart","vue","svelte","jsp","html","css","scss","less",
                    "xml","json","yaml","yml","toml","properties","gradle","sql","graphql","proto","sh","bash","zsh","ps1","bat","cmd",
                    "tf","hcl","bzl","sbt","ex","exs","clj","cljs","zig","hs","erl").contains(ext)) return true;
        }
        return false;
    }

    private String verificationRequiredPrompt(AgentRunService.AgentRun run) {
        String last = run.lastVerification().isBlank() ? "No verifier has successfully run for this revision yet." :
                "Last verifier: " + run.lastVerification();
        return "[RUNTIME_STEERING:verification-required]\nThe live workspace has changed and the current revision is not successfully verified. " + last + " " +
                "Do not repeat the previous final response and do not finish as completed yet. Your next useful action must produce new verification evidence or a fix. " +
                "Use build/test/check for the primary workspace, resource_build/resource_test/resource_check for an additional project, bash/resource_bash with verification=true, or http_request with verification=true as appropriate. " +
                "If verification fails, inspect the real error, fix the cause, and rerun. Continue until the current revision passes. " +
                "Only return blocked if a genuine external/environment/permission blocker prevents verification.";
    }

    private String permissionFor(String tool, ChatSettings settings) {
        if (tool != null && tool.startsWith("mcp__")) return settings.mcpPermission();
        if ("task".equals(tool)) return settings.taskPermission();
        if ("lsp".equals(tool) || "lsp_status".equals(tool)) return settings.lspPermission();
        if (Set.of("edit", "write", "copy", "move", "delete", "apply_patch", "resource_edit", "resource_write", "resource_delete", "resource_copy", "resource_move").contains(tool)) return settings.editPermission();
        if (Set.of("bash", "build", "test", "check", "resource_bash", "resource_build", "resource_test", "resource_check", "process_start", "process_stop", "http_request").contains(tool)) return settings.shellPermission();
        if (Set.of("workspace_status", "workspace_diff").contains(tool)) return settings.reviewPermission();
        return "allow";
    }

    private String decorateFinalMessage(String message, AgentWorkspaceService.Workspace ws,
                                        List<ProjectPatchRequest.ProjectPatchFile> changes,
                                        AgentRunService.AgentRun run, String status) {
        String result = message == null || message.isBlank() ? "Agent run completed." : message.strip();
        if (!changes.isEmpty()) {
            boolean multiResourceChanges = changes.stream().anyMatch(file -> file.path() != null && file.path().startsWith("@"));
            if (multiResourceChanges) {
                result += "\n\n> Direct resources: " + changes.size() + " file(s) were changed across the primary workspace and explicitly supplied writable resources.";
            } else {
                result += "\n\n> Direct workspace: " + changes.size() + " file(s) were changed directly under `" + ws.root() + "`.";
            }
        }
        if (run.lastVerificationAttemptRevision() >= 0 && !run.lastVerification().isBlank()) {
            result += "\n\n> Last recorded verifier: " + run.lastVerification();
        }
        if (run.modelCalls() > 0) {
            String usage = run.providerTotalTokens() > 0
                    ? run.providerTotalTokens() + " provider-reported tokens"
                    : "provider usage unavailable; runtime context estimates were used";
            result += "\n\n> Agent token management: " + usage + "; " + run.modelCalls() + " model call(s); " +
                    run.compactions() + " context compaction(s); current active context ~" + run.currentContextTokens() +
                    "/" + run.contextWindowTokens() + " tokens.";
        }
        if ("blocked".equals(status) && !result.toLowerCase(Locale.ROOT).contains("blocked")) {
            result = "**Status: Blocked**\n\n" + result;
        }
        return result;
    }

    private void appendNativeAssistantTurn(List<Map<String, Object>> messages,
                                           List<OpenAiCompatibleClient.AgentToolCall> calls,
                                           String assistantContent) {
        List<Map<String, Object>> toolCalls = new ArrayList<>();
        for (OpenAiCompatibleClient.AgentToolCall call : calls) {
            Map<String, Object> function = new LinkedHashMap<>();
            function.put("name", call.name());
            try { function.put("arguments", objectMapper.writeValueAsString(sanitizeHistoricalToolArgs(call.arguments()))); }
            catch (Exception ignored) { function.put("arguments", "{}"); }
            Map<String, Object> item = new LinkedHashMap<>();
            item.put("id", call.id());
            item.put("type", "function");
            item.put("function", function);
            toolCalls.add(item);
        }
        Map<String, Object> assistant = new LinkedHashMap<>();
        assistant.put("role", "assistant");
        if (assistantContent != null && !assistantContent.isBlank()) assistant.put("content", assistantContent);
        assistant.put("tool_calls", toolCalls);
        messages.add(assistant);
    }

    private void appendNativeToolResult(List<Map<String, Object>> messages, String callId, String tool, String result) {
        Map<String, Object> toolResult = new LinkedHashMap<>();
        toolResult.put("role", "tool");
        toolResult.put("tool_call_id", callId);
        toolResult.put("name", tool);
        toolResult.put("content", clip(result));
        messages.add(toolResult);
    }

    private void appendFallbackToolTranscript(List<Map<String, Object>> messages, String raw, String tool, String result) {
        if (raw != null && !raw.isBlank()) messages.add(Map.of("role", "assistant", "content", clipHistoricalAssistant(raw)));
        messages.add(Map.of("role", "user", "content", "TOOL RESULT for " + tool + ":\n" + clip(result) +
                "\n\nContinue the same task. Use another tool if needed, otherwise return the final JSON response."));
    }

    private JsonNode parseEnvelope(String raw) {
        if (raw == null || raw.isBlank()) return null;
        String text = raw.trim();
        if (text.startsWith("```")) {
            int firstNl = text.indexOf('\n'), last = text.lastIndexOf("```");
            if (firstNl >= 0 && last > firstNl) text = text.substring(firstNl + 1, last).trim();
        }
        try { return objectMapper.readTree(text); } catch (Exception ignored) { }
        int start = text.indexOf('{');
        if (start < 0) return null;
        boolean inString = false, escape = false;
        int depth = 0;
        for (int i = start; i < text.length(); i++) {
            char c = text.charAt(i);
            if (inString) {
                if (escape) escape = false;
                else if (c == '\\') escape = true;
                else if (c == '"') inString = false;
                continue;
            }
            if (c == '"') { inString = true; continue; }
            if (c == '{') depth++;
            else if (c == '}' && --depth == 0) {
                try { return objectMapper.readTree(text.substring(start, i + 1)); }
                catch (Exception ignored) { return null; }
            }
        }
        return null;
    }

    private Map<String, Object> stepEvent(int step, String tool, String detail, String status,
                                          JsonNode args, String output, String approvalId) {
        Map<String, Object> event = new LinkedHashMap<>();
        event.put("step", step);
        event.put("tool", tool == null || tool.isBlank() ? "agent" : tool);
        event.put("detail", safe(detail));
        event.put("status", status);
        if (args != null && !args.isMissingNode() && !args.isNull()) event.put("args", args);
        if (output != null && !output.isBlank()) event.put("output", output);
        if (approvalId != null) event.put("approvalId", approvalId);
        return event;
    }

    private String describeTool(String tool, JsonNode args) {
        if (Set.of("read", "read_chunk", "file_info", "file_index", "write", "edit", "delete").contains(tool)) return tool + " " + text(args, "path");
        if (Set.of("move", "copy").contains(tool)) return tool + " " + text(args, "from") + " -> " + text(args, "to");
        if ("apply_patch".equals(tool)) return "Apply direct multi-file workspace change";
        if ("grep".equals(tool)) return "Search workspace for " + text(args, "pattern");
        if ("glob".equals(tool)) return "Glob " + text(args, "pattern");
        if ("bash".equals(tool)) return "Run " + text(args, "command");
        if (tool != null && tool.startsWith("resource_")) {
            String alias = text(args, "alias");
            if (Set.of("resource_read", "resource_chunk", "resource_info", "resource_index", "resource_edit", "resource_write", "resource_delete").contains(tool)) return tool + " @" + alias + "/" + text(args, "path");
            if (Set.of("resource_copy", "resource_move").contains(tool)) return tool + " @" + text(args, "fromAlias") + "/" + text(args, "fromPath") + " -> @" + text(args, "toAlias") + "/" + text(args, "toPath");
            if ("resource_grep".equals(tool)) return "Search @" + alias + " for " + text(args, "pattern");
            if ("resource_bash".equals(tool)) return "Run in @" + alias + ": " + text(args, "command");
            return tool + (alias.isBlank() ? "" : " @" + alias);
        }
        if ("process_start".equals(tool)) return "Start background process: " + text(args, "command");
        if (Set.of("process_status", "process_output", "process_stop").contains(tool)) return tool + " " + text(args, "processId");
        if ("http_request".equals(tool)) return firstNonBlank(text(args, "method"), "GET") + " " + text(args, "url");
        if ("workspace_profile".equals(tool)) return "Read durable workspace profile";
        if ("workspace_profile_refresh".equals(tool)) return "Refresh durable workspace profile";
        if ("instruction_catalog".equals(tool)) return "List project instruction files";
        if ("instructions_for".equals(tool)) return "Load instructions for " + text(args, "path");
        if ("attachment_list".equals(tool)) return "List uploaded conversation attachments";
        if ("attachment_read".equals(tool)) return "Read uploaded attachment " + text(args, "fileId");
        if ("attachment_search".equals(tool)) return "Search attachments for " + text(args, "query");
        if ("skill_catalog".equals(tool)) return "List available skills";
        if ("skill".equals(tool)) return "Load skill " + text(args, "name");
        if ("agent_catalog".equals(tool)) return "List available subagents";
        if ("task".equals(tool)) return "Delegate to " + text(args, "agent") + ": " + text(args, "prompt");
        if ("mcp_status".equals(tool)) return "Inspect MCP server/tool status";
        if (tool != null && tool.startsWith("mcp__")) return "Call external MCP tool " + tool;
        if (Set.of("build", "test", "check").contains(tool)) return tool + " in " + (text(args, "cwd").isBlank() ? "." : text(args, "cwd"));
        return tool;
    }

    private boolean isFailedCommandResult(String tool, String result) {
        if (Set.of("bash", "build", "test", "check", "resource_bash", "resource_build", "resource_test", "resource_check").contains(tool)) {
            return result != null && !result.startsWith("exitCode=0;");
        }
        if ("http_request".equals(tool) && result != null && result.startsWith("statusCode=")) {
            return !httpVerificationSuccess(result);
        }
        return false;
    }

    private boolean isContextWindowFailure(Exception e) {
        String text = (e.getMessage() == null ? "" : e.getMessage()).toLowerCase(Locale.ROOT);
        return text.contains("context length") || text.contains("context window") || text.contains("maximum context") ||
                text.contains("too many tokens") || text.contains("token limit") || text.contains("prompt is too long") ||
                text.contains("input too long");
    }

    private boolean verificationSteeringBlocked(Map<String,Integer> counters, AgentRunService.AgentRun run) {
        String key = run.mutationRevision() + "|" + run.lastVerificationAttemptRevision() + "|" +
                run.lastSuccessfulVerificationRevision() + "|" + Integer.toHexString(run.lastVerification().hashCode());
        int count = counters.merge(key, 1, Integer::sum);
        if (count > MAX_CONSECUTIVE_NON_ACTIONABLE_TURNS) {
            run.markRepeatedCallPrevented();
            return true;
        }
        return false;
    }

    private String normalizeNoProgress(String raw) {
        if (raw == null || raw.isBlank()) return "<blank>";
        String normalized = raw.toLowerCase(Locale.ROOT).replaceAll("\\s+", " ").trim();
        if (normalized.length() > 1200) normalized = normalized.substring(0, 1200);
        return normalized;
    }

    /**
     * Adaptive recovery prompt. It deliberately rotates strategy rather than replaying a static warning, because
     * repeated steering text can reinforce the same model failure mode. The agent still has freedom to choose the
     * actual implementation; these are recovery hints, not a second rulebook.
     */
    private String recoveryDirective(int attempt, int maxAttempts, boolean duplicate, String raw) {
        String low = raw == null ? "" : raw.toLowerCase(Locale.ROOT);
        String specific;
        if (low.contains("unknown tool") || low.contains("tool error")) {
            specific = "Use an exact built-in tool name now. For code/text search use grep; use glob for path matching; tool_search is only for discovering deferred MCP tools.";
        } else if (low.contains("oldtext") || low.contains("was not found") || low.contains("pattern is required")) {
            specific = "Re-read the exact current file region, then edit using current text. If exact replacement is brittle, use a structured apply_patch or a complete write only after reading the file.";
        } else if (low.contains("apply_patch") || low.contains("non-empty changes") || low.contains("patch")) {
            specific = "Recover the patch with current file evidence. apply_patch accepts either a structured changes array or OpenAI-style *** Begin Patch text; edit/write are valid fallbacks.";
        } else if (low.contains("not found") || low.contains("no such file") || low.contains("cannot find")) {
            specific = "Do not guess the path. Inspect the live workspace/resource catalog, then glob/list/read the resolved location before acting.";
        } else if (low.contains("compile") || low.contains("test") || low.contains("exitcode=") || low.contains("failed")) {
            specific = "Use the latest failure output as evidence: identify the first actionable root cause, change the implementation, then rerun the smallest relevant verifier.";
        } else {
            specific = switch (Math.floorMod(attempt - 1, 5)) {
                case 0 -> "Inspect a smaller, directly relevant part of the workspace and take one concrete action from that evidence.";
                case 1 -> "Change the investigation route: search by symbol/text or file pattern instead of repeating the previous prose or call.";
                case 2 -> "Choose the simplest direct implementation path that satisfies the approved plan, then verify it.";
                case 3 -> "Use a different available tool or different arguments that can produce new evidence on the current workspace revision.";
                default -> "Re-check the resolved workspace and the user's requested outcome, then continue with the shortest evidence-driven fix-and-verify loop.";
            };
        }
        return "[RUNTIME_STEERING:recovery]\nRECOVERY " + attempt + "/" + maxAttempts + ". " +
                (duplicate ? "Do not repeat the prior response or identical tool call. " : "The previous turn made no actionable progress. ") +
                specific + " Continue the approved plan autonomously. Your next turn should use real tools unless the task is already complete after verified tool activity.";
    }

    private String recoveryExhaustedMessage(long attempts, int perModelLimit, AgentRunService.AgentRun run, String finalReason) {
        String reason = finalReason == null || finalReason.isBlank() ? "No validated recovery route remained." : finalReason.strip();
        return "Blocked: every configured execution model exhausted its recovery path and the recovery-replanning layer could not safely continue. " +
                "Last per-model no-progress count: " + attempts + " (configured " + perModelLimit + " per model). Model failovers used: " +
                run.modelFailovers() + "; recovery replans used: " + run.recoveryReplans() + "/" + MAX_EXECUTOR_RECOVERY_REPLANS + ". " +
                "Completed plan steps and current workspace changes were preserved. Final recovery reason: " + reason;
    }

    private String effectiveModel(AgentRunService.AgentRun run, ChatSettings settings) {
        String active = run == null ? "" : run.activeModel();
        if (active != null && !active.isBlank()) return active;
        return settings == null || settings.model() == null ? "" : settings.model().trim();
    }

    private boolean switchToNextModel(AgentRunService.AgentRun run, Consumer<Map<String,Object>> onStep, int step, String reason) {
        String previous = run.activeModel();
        if (!run.switchToNextModel(reason)) return false;
        String next = run.activeModel();
        onStep.accept(stepEvent(step, "model_failover",
                "Switching model " + (previous == null || previous.isBlank() ? "[unknown]" : previous) + " → " + next +
                        "; preserving approved plan step " + run.activePlanIndex(),
                "success", null, clipUi(reason), null));
        return true;
    }

    private String modelFailoverContinuation(AgentRunService.AgentRun run) {
        return "[RUNTIME_STEERING:model-failover]\nMODEL FAILOVER CONTINUATION. Active model is now '" + run.activeModel() + "'. Preserve all prior workspace evidence and tool results. " +
                "Do not restart the task or recreate the plan. Continue only approved plan step " + run.activePlanIndex() +
                (run.activePlanStepText().isBlank() ? "." : ": " + run.activePlanStepText()) +
                " When the step is genuinely complete, use todo_update for that active index; the runtime will unlock the next step.";
    }

    private String planContinuationPrompt(AgentRunService.AgentRun run, boolean verificationJustPassed) {
        String prefix = verificationJustPassed
                ? "The current workspace revision has passed verification. "
                : "The approved plan is still in progress. ";
        return "[RUNTIME_STEERING:plan-continuation]\n" + prefix + "Only step " + run.activePlanIndex() + " is unlocked: " + run.activePlanStepText() +
                ". Do not start a later step. If this active step's intended outcome is satisfied, call todo_update with index=" +
                run.activePlanIndex() + " and status=completed. Otherwise continue working on this step with real tools.";
    }

    private boolean isModelUnavailableFailure(Exception e) {
        String text = (e.getMessage() == null ? "" : e.getMessage()).toLowerCase(Locale.ROOT);
        return text.contains("model not found") || text.contains("unknown model") || text.contains("unsupported model") ||
                text.contains("model does not exist") || text.contains("invalid model") || text.contains("no such model") ||
                (text.contains("404") && text.contains("model"));
    }

    /**
     * Execute a specialized harness role without changing the executor's active failover state. The explicit role model is
     * tried first, followed by configured models known to suit that role, and finally the active executor. This keeps
     * analysis/planning/validation resilient while preserving the exact executor step/state for code-edit failover.
     */
    private OpenAiCompatibleClient.AgentCompletion completeRoleText(String apiKey, ChatRequest request,
                                                                     AgentRunService.AgentRun run, String roleModel,
                                                                     ModelCapabilityRegistry.Role role, int maxOut,
                                                                     List<Map<String,Object>> prompt, int step,
                                                                     Consumer<Map<String,Object>> onStep, String purpose) throws Exception {
        String executor = effectiveModel(run, request.settings());
        String preferred = roleModel == null || roleModel.isBlank() ? executor : roleModel.trim();
        LinkedHashSet<String> candidates = new LinkedHashSet<>();
        if (!preferred.isBlank()) candidates.add(preferred);
        for (String configured : request.settings().agentModels()) {
            if (configured != null && !configured.isBlank() && ModelCapabilityRegistry.profileFor(configured).preferredFor(role)) {
                candidates.add(configured.trim());
            }
        }
        if (!executor.isBlank()) candidates.add(executor);

        Exception last = null;
        int transientRetries = Math.min(3, request.settings().safeAgentRecoveryAttempts());
        for (String candidate : candidates) {
            for (int attempt = 0; attempt < transientRetries; attempt++) {
                run.checkCancelled();
                try {
                    if (!candidate.equals(preferred) || attempt > 0) {
                        String detail = attempt > 0
                                ? purpose + " retry " + (attempt + 1) + "/" + transientRetries + " on " + candidate
                                : purpose + " fallback: " + candidate;
                        onStep.accept(stepEvent(step, "model_route", detail, "running", null, last == null ? null : clipUi(safe(last.getMessage())), null));
                    }
                    return llm.completeTextWithUsage(apiKey, request.settings().baseUrl(), candidate, maxOut, prompt, run::cancelled);
                } catch (AgentCancelledException cancelled) {
                    throw cancelled;
                } catch (Exception failure) {
                    last = failure;
                    if (!isTransientModelFailure(failure) || isModelUnavailableFailure(failure)) break;
                    if (attempt + 1 < transientRetries) sleepCancellable(run, Math.min(2_500L, 400L << attempt));
                }
            }
        }
        if (last != null) throw last;
        throw new IllegalStateException("No configured model is available for " + purpose);
    }

    private OpenAiCompatibleClient.AgentCompletion completeTextForRun(String apiKey, ChatRequest request,
                                                                       AgentRunService.AgentRun run, int maxOut,
                                                                       List<Map<String,Object>> prompt, int step,
                                                                       Consumer<Map<String,Object>> onStep, String purpose) throws Exception {
        int attempt = 0;
        int limit = request.settings().safeAgentRecoveryAttempts();
        while (true) {
            run.checkCancelled();
            String model = effectiveModel(run, request.settings());
            try {
                return llm.completeTextWithUsage(apiKey, request.settings().baseUrl(), model, maxOut, prompt, run::cancelled);
            } catch (AgentCancelledException cancelled) {
                throw cancelled;
            } catch (Exception e) {
                String error = safe(e.getMessage());
                if (isModelUnavailableFailure(e)) {
                    if (switchToNextModel(run, onStep, step, purpose + " model unavailable: " + error)) { attempt = 0; continue; }
                    throw e;
                }
                if (!isTransientModelFailure(e)) throw e;
                attempt++;
                if (attempt >= limit) {
                    if (switchToNextModel(run, onStep, step, purpose + " exhausted " + limit + " transient retries: " + error)) { attempt = 0; continue; }
                    throw e;
                }
                sleepCancellable(run, Math.min(8_000L, 500L << Math.min(4, Math.max(0, attempt - 1))));
            }
        }
    }

    private boolean isTransientModelFailure(Exception e) {
        String text = (e.getMessage() == null ? "" : e.getMessage()).toLowerCase(Locale.ROOT);
        return text.contains("429") || text.contains("500") || text.contains("502") || text.contains("503") ||
                text.contains("504") || text.contains("timeout") || text.contains("timed out") ||
                text.contains("connection reset") || text.contains("connection refused") || text.contains("temporarily unavailable");
    }

    /** Authentication/authorization failures are account/configuration blockers; cycling models only wastes tokens. */
    private boolean isAuthenticationFailure(Exception e) {
        String text = (e.getMessage() == null ? "" : e.getMessage()).toLowerCase(Locale.ROOT);
        return text.contains("401") || text.contains("403") || text.contains("unauthorized") ||
                text.contains("invalid api key") || text.contains("invalid_api_key") ||
                text.contains("authentication") || text.contains("forbidden");
    }

    private void sleepCancellable(AgentRunService.AgentRun run, long waitMs) throws InterruptedException {
        long deadline = System.nanoTime() + Duration.ofMillis(waitMs).toNanos();
        while (System.nanoTime() < deadline) {
            run.checkCancelled();
            Thread.sleep(Math.min(100L, Math.max(1L, waitMs)));
        }
    }

    private String canonicalArgs(JsonNode args) {
        try { return objectMapper.writeValueAsString(args); }
        catch (Exception ignored) { return String.valueOf(args); }
    }

    private String summarizeResult(String tool, String result) {
        if (result == null || result.isBlank()) return tool + " completed";
        String first = result.replace('\r', ' ').replace('\n', ' ').replaceAll("\\s+", " ").trim();
        return first.length() > 240 ? first.substring(0, 240) + "…" : first;
    }

    private String normalizeFinalStatus(String value) {
        return "blocked".equalsIgnoreCase(value) ? "blocked" : "completed";
    }

    private String requiredText(JsonNode node, String field) {
        String value = text(node, field);
        if (value == null || value.isBlank()) throw new IllegalArgumentException(field + " is required");
        return value;
    }

    private String text(JsonNode node, String field) {
        if (node == null || node.isMissingNode() || node.isNull()) return "";
        JsonNode value = node.path(field);
        return value.isMissingNode() || value.isNull() ? "" : value.asText("");
    }

    private String firstNonBlank(String first, String second) {
        return first != null && !first.isBlank() ? first : second == null ? "" : second;
    }

    private List<String> stringList(JsonNode node, String field) {
        JsonNode arr = node == null ? null : node.path(field);
        if (arr == null || !arr.isArray()) return List.of();
        List<String> out = new ArrayList<>();
        for (JsonNode item : arr) {
            String value = item.asText("").trim();
            if (!value.isBlank()) out.add(value);
        }
        return out;
    }

    /** Bound a single tool result placed back into the model transcript. The full result is still used by the
     * runtime for verification/events; only repeatedly-sent model context is bounded. */
    private String clip(String value) {
        return clipHeadTail(value, 50_000, "[Tool output bounded to 50k characters for active model context. Re-run with a targeted command/read for exact omitted details.]");
    }

    private String clipHistoricalAssistant(String value) {
        return clipHeadTail(value, 12_000, "[Large historical tool envelope bounded after execution; live workspace state is authoritative.]");
    }

    private String clipUi(String value) {
        return clipHeadTail(value, 30_000, "[UI output clipped; the command/tool result itself was processed in full.]");
    }

    private String clipHeadTail(String value, int maxChars, String marker) {
        if (value == null) return "";
        if (value.length() <= maxChars) return value;
        int head = Math.max(500, (int)(maxChars * 0.72));
        int tail = Math.max(250, maxChars - head);
        return value.substring(0, head) + "\n...\n" + marker + "\n...\n" + value.substring(value.length() - tail);
    }

    private JsonNode sanitizeHistoricalToolArgs(JsonNode node) {
        if (node == null || node.isNull() || node.isMissingNode()) return objectMapper.createObjectNode();
        JsonNode copy = node.deepCopy();
        sanitizeHistoricalToolArgsInPlace(copy);
        return copy;
    }

    private void sanitizeHistoricalToolArgsInPlace(JsonNode node) {
        if (node == null) return;
        if (node.isObject()) {
            List<String> names = new ArrayList<>();
            node.fieldNames().forEachRemaining(names::add);
            for (String name : names) {
                JsonNode child = node.get(name);
                if (child != null && child.isTextual() && child.asText().length() > 8_000) {
                    String text = child.asText();
                    String bounded = clipHeadTail(text, 8_000, "[Large tool argument omitted from historical context after execution; length=" + text.length() + "]");
                    ((com.fasterxml.jackson.databind.node.ObjectNode) node).put(name, bounded);
                } else {
                    sanitizeHistoricalToolArgsInPlace(child);
                }
            }
        } else if (node.isArray()) {
            for (JsonNode child : node) sanitizeHistoricalToolArgsInPlace(child);
        }
    }

    private String safe(String value) {
        if (value == null || value.isBlank()) return "Unknown error";
        String clean = value.replace('\u0000', ' ');
        return clean.length() > 1_200 ? clean.substring(0, 1_200) : clean;
    }

    private static final class ExecutorPoolExhaustedException extends Exception {
        private final String providerDetail;
        private ExecutorPoolExhaustedException(String message, String providerDetail, Throwable cause) {
            super(message, cause);
            this.providerDetail = providerDetail == null ? "" : providerDetail;
        }
        private String providerDetail() { return providerDetail; }
    }

    private record PreparedCall(OpenAiCompatibleClient.AgentToolCall call, String requestedTool, String tool, JsonNode args, String detail) {}
    private record ToolExecution(String result, String status, boolean executed) {}
    @PreDestroy
    public void shutdownExecutors() { parallelReadExecutor.shutdownNow(); }

    public record AgentResult(String answer, List<ProjectPatchRequest.ProjectPatchFile> changes) {}
}
