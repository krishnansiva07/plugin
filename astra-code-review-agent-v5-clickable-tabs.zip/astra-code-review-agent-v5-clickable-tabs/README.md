# ASTRA Code Review Agent V5 - Clickable Tabs Working Build

Single Spring Boot app. UI is served from backend.

## Run
```bash
cd backend
mvn spring-boot:run
```
Open:
```text
http://localhost:8090/index.html
```

## LLM Configuration
Edit `backend/src/main/resources/application.properties`:
```properties
llm.mock-mode=false
llm.base-url=https://ai4devs.group.echonet/api/v1
llm.model-name=gpt-oss-120b
llm.api-key=YOUR_KEY_HERE
llm.append-chat-completions=true
```
Restart backend after editing.

## Fixed in V5
- Summary, Comments, Report tabs are clickable.
- Details, Issues, Chunks, PR Comment tabs are clickable.
- Download JSON report works from Report tab.
- Copy PR comments works.
- Fixed Java regex compile error in RuleAnalyzerService.
- Still supports file upload, folder upload, SSE progress, chunk review, rule checks and LLM review.
