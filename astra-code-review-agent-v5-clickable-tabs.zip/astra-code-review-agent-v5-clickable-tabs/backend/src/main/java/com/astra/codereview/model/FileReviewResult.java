package com.astra.codereview.model;

import java.util.ArrayList;
import java.util.List;

public class FileReviewResult {
    public String fileName;
    public String relativePath;
    public String status = "QUEUED";
    public String severity = "GOOD_TO_HAVE";
    public String reviewer = "AUTO";
    public int score = 100;
    public int lineCount;
    public boolean largeFile;
    public int totalChunks;
    public int completedChunks;
    public String summary = "";
    public List<ReviewIssue> issues = new ArrayList<>();
    public List<String> chunkSummaries = new ArrayList<>();
}
