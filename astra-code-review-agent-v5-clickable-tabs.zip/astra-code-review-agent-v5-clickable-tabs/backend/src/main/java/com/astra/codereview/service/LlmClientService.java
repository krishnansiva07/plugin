package com.astra.codereview.service;

import com.astra.codereview.config.LlmProperties;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.stereotype.Service;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.*;

@Service
public class LlmClientService {
    private final LlmProperties props;
    private final ObjectMapper mapper = new ObjectMapper();

    public LlmClientService(LlmProperties props) { this.props = props; }

    public boolean isMockMode() { return props.isMockMode(); }

    public String call(String prompt) throws Exception {
        if (props.isMockMode()) return mock(prompt);
        if (props.getApiKey() == null || props.getApiKey().isBlank() || props.getApiKey().contains("PASTE_YOUR_KEY")) {
            throw new IllegalStateException("LLM api key is missing. Paste llm.api-key in application.properties or set llm.mock-mode=true.");
        }
        String url = props.getBaseUrl();
        if (url == null || url.isBlank()) throw new IllegalStateException("llm.base-url is missing");
        if (props.isAppendChatCompletions() && !url.endsWith("/chat/completions")) {
            url = url.replaceAll("/+$", "") + "/chat/completions";
        }

        Map<String, Object> body = new LinkedHashMap<>();
        body.put("model", props.getModelName());
        body.put("temperature", props.getTemperature());
        body.put("max_tokens", props.getMaxTokens());
        body.put("messages", List.of(
                Map.of("role", "system", "content", "You are ASTRA Code Review Agent. Return practical review comments as valid JSON only."),
                Map.of("role", "user", "content", prompt)
        ));

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(url))
                .timeout(Duration.ofSeconds(props.getTimeoutSeconds()))
                .header("Content-Type", "application/json")
                .header("Authorization", "Bearer " + props.getApiKey())
                .POST(HttpRequest.BodyPublishers.ofString(mapper.writeValueAsString(body)))
                .build();

        HttpResponse<String> response = HttpClient.newHttpClient().send(request, HttpResponse.BodyHandlers.ofString());
        if (response.statusCode() < 200 || response.statusCode() >= 300) {
            throw new IllegalStateException("LLM API failed. HTTP " + response.statusCode() + ": " + response.body());
        }
        JsonNode root = mapper.readTree(response.body());
        JsonNode content = root.at("/choices/0/message/content");
        if (content.isMissingNode() || content.asText().isBlank()) {
            JsonNode alt = root.at("/choices/0/text");
            if (!alt.isMissingNode()) return alt.asText();
            return response.body();
        }
        return content.asText();
    }

    private String mock(String prompt) {
        return "{\"summary\":\"Mock review completed. Configure llm.mock-mode=false and paste URL/model/key for real LLM review.\",\"score\":84,\"severity\":\"GOOD_TO_HAVE\",\"issues\":[{\"severity\":\"GOOD_TO_HAVE\",\"category\":\"Mock\",\"lineNumber\":1,\"whatIsWrong\":\"This is mock review output.\",\"whyItMatters\":\"It proves the UI and SSE flow are working.\",\"whatNeedsToBeChanged\":\"Set real LLM values in application.properties.\",\"suggestedCode\":\"llm.mock-mode=false\",\"prComment\":\"Switch to real LLM configuration when ready.\"}]}";
    }
}
