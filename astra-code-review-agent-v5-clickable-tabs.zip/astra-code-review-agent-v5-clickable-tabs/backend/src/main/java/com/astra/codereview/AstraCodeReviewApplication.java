package com.astra.codereview;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AstraCodeReviewApplication {
    public static void main(String[] args) {
        SpringApplication.run(AstraCodeReviewApplication.class, args);
    }
}
