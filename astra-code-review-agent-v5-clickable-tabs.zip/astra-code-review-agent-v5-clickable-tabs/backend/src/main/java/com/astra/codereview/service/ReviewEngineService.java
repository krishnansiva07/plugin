package com.astra.codereview.service;

import com.astra.codereview.model.*;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;

@Service
public class ReviewEngineService {
    private final RuleAnalyzerService ruleAnalyzer;
    private final LlmClientService llmClient;
    private final ObjectMapper mapper = new ObjectMapper();
    private final Map<String, ReviewSession> sessions = new ConcurrentHashMap<>();
    private final Map<String, List<SseEmitter>> emitters = new ConcurrentHashMap<>();
    private final ExecutorService executor = Executors.newFixedThreadPool(2);

    public ReviewEngineService(RuleAnalyzerService ruleAnalyzer, LlmClientService llmClient) {
        this.ruleAnalyzer = ruleAnalyzer; this.llmClient = llmClient;
    }

    public ReviewSession start(List<MultipartFile> files, String depth, String role) throws IOException {
        String id = "REV-" + System.currentTimeMillis();
        ReviewSession session = new ReviewSession(); session.reviewId = id;
        int index = 0;
        for (MultipartFile mf : files) {
            if (mf == null || mf.isEmpty()) continue;
            FileReviewResult f = new FileReviewResult();
            f.fileName = cleanName(Objects.requireNonNullElse(mf.getOriginalFilename(), "file-" + (++index)));
            f.relativePath = f.fileName;
            f.lineCount = new String(mf.getBytes(), StandardCharsets.UTF_8).split("\\R", -1).length;
            session.files.add(f);
        }
        sessions.put(id, session);
        byte[][] contents = new byte[files.size()][];
        for (int i=0;i<files.size();i++) contents[i] = files.get(i).getBytes();
        List<String> names = files.stream().map(f -> cleanName(Objects.requireNonNullElse(f.getOriginalFilename(), "file"))).toList();
        executor.submit(() -> process(session, names, contents, depth, role));
        return session;
    }

    public SseEmitter stream(String reviewId) {
        SseEmitter emitter = new SseEmitter(0L);
        emitters.computeIfAbsent(reviewId, k -> new CopyOnWriteArrayList<>()).add(emitter);
        emitter.onCompletion(() -> emitters.getOrDefault(reviewId, List.of()).remove(emitter));
        emitter.onTimeout(() -> emitters.getOrDefault(reviewId, List.of()).remove(emitter));
        ReviewSession session = sessions.get(reviewId);
        if (session != null) {
            for (ReviewEvent event : session.eventHistory) send(emitter, event);
        }
        return emitter;
    }

    public ReviewSession get(String id) { return sessions.get(id); }

    private void process(ReviewSession session, List<String> names, byte[][] contents, String depth, String role) {
        publish(session, event("REVIEW_STARTED", session, null, 0, "Review started"));
        AtomicInteger completed = new AtomicInteger();
        for (int i = 0; i < names.size(); i++) {
            FileReviewResult f = session.files.get(i);
            f.status = "RUNNING";
            publish(session, event("FILE_STARTED", session, f, completed.get(), "Analyzing " + f.fileName));
            String content = new String(contents[i], StandardCharsets.UTF_8);
            try {
                f.reviewer = detectReviewer(f.fileName, content);
                f.lineCount = content.split("\\R", -1).length;
                f.issues.addAll(ruleAnalyzer.analyze(f.fileName, content));
                publish(session, event("RULE_CHECK_COMPLETED", session, f, completed.get(), "Rule check completed. Issues so far: " + f.issues.size()));

                if (f.lineCount > 300) {
                    f.largeFile = true;
                    List<String> chunks = chunk(content, 160);
                    f.totalChunks = chunks.size();
                    int chunkNo = 0;
                    for (String chunk : chunks) {
                        chunkNo++;
                        publish(session, event("CHUNK_STARTED", session, f, completed.get(), "Reviewing chunk " + chunkNo + "/" + chunks.size()));
                        List<ReviewIssue> chunkIssues = callLlmAndParse(f, chunk, true);
                        f.issues.addAll(chunkIssues);
                        f.completedChunks = chunkNo;
                        f.chunkSummaries.add("Chunk " + chunkNo + " completed. Comments: " + chunkIssues.size());
                        calculateScoreAndSeverity(f);
                        publish(session, event("CHUNK_COMPLETED", session, f, completed.get(), "Chunk " + chunkNo + " completed"));
                    }
                    f.summary = "Large file review completed. " + f.completedChunks + "/" + f.totalChunks + " chunks analyzed.";
                } else {
                    publish(session, event("LLM_REVIEW_RUNNING", session, f, completed.get(), "LLM review running"));
                    f.issues.addAll(callLlmAndParse(f, content, false));
                    f.summary = (llmClient.isMockMode() ? "Mock " : "LLM ") + "review completed for " + f.fileName + ".";
                }
                dedupe(f);
                calculateScoreAndSeverity(f);
                f.status = "COMPLETED";
            } catch (Exception ex) {
                f.status = "COMPLETED";
                f.issues.add(new ReviewIssue("MAJOR", "LLM Integration", null,
                        "LLM review failed: " + safe(ex.getMessage()),
                        "Rule-based findings may still be available, but LLM enrichment did not complete.",
                        "Check llm.base-url, llm.model-name, llm.api-key, network access, or set llm.mock-mode=true.",
                        "llm.mock-mode=true", "LLM review failed. Please verify local LLM configuration."));
                f.summary = "Review completed with LLM error.";
                calculateScoreAndSeverity(f);
            }
            int done = completed.incrementAndGet();
            publish(session, event("FILE_COMPLETED", session, f, done, f.fileName + " completed"));
        }
        session.status = "COMPLETED";
        publish(session, event("REVIEW_COMPLETED", session, null, session.files.size(), "All files completed"));
    }

    private ReviewEvent event(String type, ReviewSession s, FileReviewResult f, int completed, String msg) {
        ReviewEvent e = ReviewEvent.of(type, s.reviewId);
        e.totalFiles = s.files.size(); e.completedFiles = completed; e.queuedFiles = Math.max(0, s.files.size() - completed - (f != null && "RUNNING".equals(f.status) ? 1 : 0));
        e.fileName = f == null ? null : f.fileName; e.result = f; e.message = msg; e.currentStep = msg;
        return e;
    }

    private void publish(ReviewSession s, ReviewEvent e) {
        s.eventHistory.add(e);
        for (SseEmitter emitter : emitters.getOrDefault(s.reviewId, List.of())) send(emitter, e);
    }

    private void send(SseEmitter emitter, ReviewEvent e) {
        try { emitter.send(SseEmitter.event().name(e.eventType).data(e)); } catch (Exception ignored) {}
    }

    private List<ReviewIssue> callLlmAndParse(FileReviewResult f, String content, boolean chunk) throws Exception {
        String prompt = buildPrompt(f, content, chunk);
        String raw = llmClient.call(prompt);
        return parseIssues(raw, f);
    }

    private String buildPrompt(FileReviewResult f, String content, boolean chunk) {
        if (content.length() > 18000) content = content.substring(0, 18000);
        return "Review Persona: " + f.reviewer + "\nFile: " + f.fileName + "\n" +
                "Return ONLY valid JSON in this format: {\"summary\":\"...\",\"score\":80,\"severity\":\"MAJOR\",\"issues\":[{\"severity\":\"MAJOR\",\"category\":\"API Design\",\"lineNumber\":10,\"whatIsWrong\":\"...\",\"whyItMatters\":\"...\",\"whatNeedsToBeChanged\":\"...\",\"suggestedCode\":\"...\",\"prComment\":\"...\"}]}\n" +
                "Focus on practical PR review comments. Do not give generic theory.\n" +
                (chunk ? "This is one chunk of a large file. Review only this chunk.\n" : "") +
                "CODE:\n```\n" + content + "\n```";
    }

    private List<ReviewIssue> parseIssues(String raw, FileReviewResult f) throws Exception {
        String json = extractJson(raw);
        JsonNode root = mapper.readTree(json);
        if (root.has("summary") && (f.summary == null || f.summary.isBlank())) f.summary = root.get("summary").asText();
        if (root.has("score")) f.score = root.get("score").asInt(f.score);
        List<ReviewIssue> out = new ArrayList<>();
        JsonNode arr = root.get("issues");
        if (arr != null && arr.isArray()) {
            for (JsonNode n : arr) {
                ReviewIssue ri = new ReviewIssue();
                ri.severity = text(n, "severity", "GOOD_TO_HAVE"); ri.category = text(n, "category", "General");
                ri.lineNumber = n.has("lineNumber") && n.get("lineNumber").canConvertToInt() ? n.get("lineNumber").asInt() : null;
                ri.whatIsWrong = text(n, "whatIsWrong", "Review comment"); ri.whyItMatters = text(n, "whyItMatters", "");
                ri.whatNeedsToBeChanged = text(n, "whatNeedsToBeChanged", ""); ri.suggestedCode = text(n, "suggestedCode", ""); ri.prComment = text(n, "prComment", ri.whatIsWrong);
                out.add(ri);
            }
        }
        return out;
    }

    private String extractJson(String raw) {
        if (raw == null) return "{\"issues\":[]}";
        raw = raw.trim();
        if (raw.startsWith("```")) raw = raw.replaceFirst("(?s)^```(?:json)?\\s*", "").replaceFirst("(?s)\\s*```$", "").trim();
        int start = raw.indexOf('{'); int end = raw.lastIndexOf('}');
        if (start >= 0 && end > start) return raw.substring(start, end + 1);
        return "{\"issues\":[{\"severity\":\"GOOD_TO_HAVE\",\"category\":\"LLM Output\",\"whatIsWrong\":\"LLM returned non JSON output.\",\"whyItMatters\":\"ASTRA needs JSON to render structured comments.\",\"whatNeedsToBeChanged\":\"Adjust model or prompt.\",\"prComment\":\"LLM output could not be parsed.\"}]}";
    }

    private String text(JsonNode n, String field, String def) { return n.has(field) && !n.get(field).isNull() ? n.get(field).asText() : def; }

    private void calculateScoreAndSeverity(FileReviewResult f) {
        int score = 100; String sev = "GOOD_TO_HAVE";
        for (ReviewIssue i : f.issues) {
            String s = i.severity == null ? "GOOD_TO_HAVE" : i.severity.toUpperCase(Locale.ROOT);
            if (s.contains("CRITICAL")) { score -= 30; sev = "CRITICAL"; }
            else if (s.contains("MAJOR")) { score -= 15; if (!sev.equals("CRITICAL")) sev = "MAJOR"; }
            else if (s.contains("MINOR")) { score -= 7; if (sev.equals("GOOD_TO_HAVE")) sev = "MINOR"; }
            else score -= 3;
        }
        f.score = Math.max(20, Math.min(f.score, score)); f.severity = sev;
    }

    private void dedupe(FileReviewResult f) {
        Set<String> seen = new LinkedHashSet<>(); List<ReviewIssue> unique = new ArrayList<>();
        for (ReviewIssue i : f.issues) {
            String key = (i.severity + "|" + i.category + "|" + i.whatIsWrong).toLowerCase(Locale.ROOT);
            if (seen.add(key)) unique.add(i);
        }
        f.issues = unique;
    }

    private List<String> chunk(String content, int linesPerChunk) {
        String[] lines = content.split("\\R", -1); List<String> chunks = new ArrayList<>();
        for (int i=0; i<lines.length; i+=linesPerChunk) {
            StringBuilder sb = new StringBuilder();
            for (int j=i; j<Math.min(lines.length, i+linesPerChunk); j++) sb.append(j+1).append(": ").append(lines[j]).append('\n');
            chunks.add(sb.toString());
        }
        return chunks;
    }

    private String detectReviewer(String file, String content) {
        String f = file.toLowerCase(Locale.ROOT);
        if (f.endsWith(".properties") || f.endsWith(".yml") || f.endsWith(".yaml")) return "CONFIG_SECURITY_REVIEWER";
        if (f.endsWith(".feature")) return "BDD_QA_REVIEWER";
        if (f.contains("test") || f.contains("page") || content.contains("WebDriver") || content.contains("playwright")) return "QA_AUTOMATION_REVIEWER";
        if (f.endsWith(".ts") || f.endsWith(".tsx") || f.endsWith(".jsx") || f.endsWith(".js")) return "FRONTEND_REVIEWER";
        if (f.equals("pom.xml") || f.endsWith("build.gradle")) return "DEPENDENCY_REVIEWER";
        if (f.endsWith(".tf") || f.endsWith(".ps1") || f.contains("jenkinsfile")) return "DEVOPS_REVIEWER";
        return "BACKEND_REVIEWER";
    }

    private String cleanName(String s) { return s.replace('\\', '/'); }
    private String safe(String s) { return s == null ? "Unknown error" : s.substring(0, Math.min(500, s.length())); }
}
