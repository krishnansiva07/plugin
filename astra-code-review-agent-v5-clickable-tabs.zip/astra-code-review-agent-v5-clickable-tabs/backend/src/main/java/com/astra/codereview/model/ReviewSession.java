package com.astra.codereview.model;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

public class ReviewSession {
    public String reviewId;
    public Instant startedAt = Instant.now();
    public String status = "STARTED";
    public List<FileReviewResult> files = new CopyOnWriteArrayList<>();
    public List<ReviewEvent> eventHistory = new CopyOnWriteArrayList<>();
}
