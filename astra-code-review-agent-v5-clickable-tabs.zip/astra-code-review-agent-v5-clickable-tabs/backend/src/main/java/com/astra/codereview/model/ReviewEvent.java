package com.astra.codereview.model;

public class ReviewEvent {
    public String eventType;
    public String reviewId;
    public Integer totalFiles;
    public Integer completedFiles;
    public Integer queuedFiles;
    public String fileName;
    public Integer fileIndex;
    public String currentStep;
    public String message;
    public FileReviewResult result;

    public static ReviewEvent of(String type, String reviewId) {
        ReviewEvent e = new ReviewEvent(); e.eventType = type; e.reviewId = reviewId; return e;
    }
}
