package com.astra.codereview.controller;

import com.astra.codereview.model.ReviewSession;
import com.astra.codereview.service.ReviewEngineService;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

import java.io.IOException;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api")
public class ReviewController {
    private final ReviewEngineService service;
    public ReviewController(ReviewEngineService service) { this.service = service; }

    @GetMapping("/health")
    public Map<String,String> health() { return Map.of("status", "UP", "app", "ASTRA Code Review Agent V4"); }

    @PostMapping(value = "/review/start", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public Map<String,Object> start(@RequestPart("files") List<MultipartFile> files,
                                    @RequestParam(defaultValue = "PR_READINESS") String depth,
                                    @RequestParam(defaultValue = "AUTO") String role) throws IOException {
        ReviewSession s = service.start(files, depth, role);
        return Map.of("reviewId", s.reviewId, "totalFiles", s.files.size(), "status", s.status);
    }

    @GetMapping(value = "/review/stream/{id}", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
    public SseEmitter stream(@PathVariable String id) { return service.stream(id); }

    @GetMapping("/review/report/{id}")
    public ReviewSession report(@PathVariable String id) { return service.get(id); }
}
