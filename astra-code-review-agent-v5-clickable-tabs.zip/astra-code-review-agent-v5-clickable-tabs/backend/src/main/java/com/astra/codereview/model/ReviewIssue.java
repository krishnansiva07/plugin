package com.astra.codereview.model;

public class ReviewIssue {
    public String severity;
    public String category;
    public Integer lineNumber;
    public String whatIsWrong;
    public String whyItMatters;
    public String whatNeedsToBeChanged;
    public String suggestedCode;
    public String prComment;

    public ReviewIssue() {}
    public ReviewIssue(String severity, String category, Integer lineNumber, String whatIsWrong, String whyItMatters, String whatNeedsToBeChanged, String suggestedCode, String prComment) {
        this.severity = severity; this.category = category; this.lineNumber = lineNumber; this.whatIsWrong = whatIsWrong;
        this.whyItMatters = whyItMatters; this.whatNeedsToBeChanged = whatNeedsToBeChanged; this.suggestedCode = suggestedCode; this.prComment = prComment;
    }
}
