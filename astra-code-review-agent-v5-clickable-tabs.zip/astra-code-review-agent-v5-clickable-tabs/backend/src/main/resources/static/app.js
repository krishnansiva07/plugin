let selectedFiles = [];
let results = [];
let activeIndex = 0;
let currentReviewId = null;
let activeQueueTab = 'files';
let activeDetailTab = 'details';
const $ = id => document.getElementById(id);

function initNavigation() {
  document.querySelectorAll('.nav').forEach(b => b.onclick = () => {
    document.querySelectorAll('.nav').forEach(x => x.classList.remove('active'));
    b.classList.add('active');
    document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
    $(b.dataset.page).classList.add('active');
  });
}

function initSourceSelection() {
  document.querySelectorAll('input[name=src]').forEach(r => r.onchange = () => {
    document.querySelectorAll('.source').forEach(x => x.classList.remove('selected'));
    r.closest('.source').classList.add('selected');
  });
}

function initQueueTabs() {
  document.querySelectorAll('.queue .tab').forEach(btn => {
    btn.onclick = () => {
      document.querySelectorAll('.queue .tab').forEach(x => x.classList.remove('active'));
      btn.classList.add('active');
      activeQueueTab = btn.dataset.tab || btn.textContent.trim().toLowerCase();
      renderQueueArea();
    };
  });
}

function initDetailTabs() {
  document.querySelectorAll('.detailTabs button').forEach(btn => {
    btn.onclick = () => {
      document.querySelectorAll('.detailTabs button').forEach(x => x.classList.remove('active'));
      btn.classList.add('active');
      activeDetailTab = btn.dataset.detail || 'details';
      renderDetails(results[activeIndex]);
    };
  });
}

$('addFile').onclick = () => {
  document.querySelector('input[name=src]:checked').value === 'folder' ? $('folderInput').click() : $('fileInput').click();
};

$('fileInput').onchange = e => {
  selectedFiles = [...selectedFiles, ...e.target.files];
  renderSelected();
};

$('folderInput').onchange = e => {
  selectedFiles = [...e.target.files];
  renderSelected();
};

function renderSelected() {
  $('fileCount').textContent = selectedFiles.length;
  const box = $('selectedFiles');
  if (!selectedFiles.length) {
    box.className = 'fileList empty';
    box.textContent = 'No files selected. Click Add File.';
    return;
  }
  box.className = 'fileList';
  box.innerHTML = '';
  selectedFiles.forEach((f, i) => {
    const d = document.createElement('div');
    d.className = 'fileItem';
    d.innerHTML = `<span>📄</span><div><b>${esc(f.name)}</b><small>${esc(f.webkitRelativePath || f.name)} • ${Math.max(1, Math.round(f.size / 1024))} KB</small></div><button class="remove">x</button>`;
    d.querySelector('button').onclick = () => { selectedFiles.splice(i, 1); renderSelected(); renderQueueArea(); };
    box.appendChild(d);
  });
  renderQueueArea();
}

$('startBtn').onclick = async () => {
  if (!selectedFiles.length) { alert('Please add files or select a folder'); return; }
  results = [];
  activeIndex = 0;
  renderQueueArea();
  renderDetails(null);
  setStatus('Review in Progress', true);
  const fd = new FormData();
  selectedFiles.forEach(f => fd.append('files', f, f.webkitRelativePath || f.name));
  fd.append('depth', $('depth').value);
  fd.append('role', $('role').value);
  try {
    const res = await fetch('/api/review/start', { method: 'POST', body: fd });
    if (!res.ok) { alert(await res.text()); setStatus('Ready', true); return; }
    const data = await res.json();
    currentReviewId = data.reviewId;
    openStream(currentReviewId);
  } catch (err) {
    alert('Unable to start review: ' + err.message);
    setStatus('Ready', true);
  }
};

function openStream(id) {
  const es = new EventSource('/api/review/stream/' + id);
  ['REVIEW_STARTED', 'FILE_STARTED', 'RULE_CHECK_COMPLETED', 'LLM_REVIEW_RUNNING', 'CHUNK_STARTED', 'CHUNK_COMPLETED', 'FILE_COMPLETED', 'REVIEW_COMPLETED']
    .forEach(t => es.addEventListener(t, e => handleEvent(t, JSON.parse(e.data), es)));
  es.onerror = () => setStatus('Stream reconnecting...', false);
}

function handleEvent(type, e, es) {
  if (e.result) {
    upsert(e.result);
    const idx = results.findIndex(r => r.fileName === e.result.fileName);
    if (idx >= 0) activeIndex = idx;
  }
  $('currentFile').textContent = e.fileName || '-';
  $('currentStep').textContent = e.currentStep || e.message || '-';
  updateStats(e);
  renderQueueArea();
  renderDetails(results[activeIndex]);
  if (type === 'REVIEW_COMPLETED') {
    setStatus('Ready', true);
    es.close();
    addHistory();
  }
}

function upsert(r) {
  const i = results.findIndex(x => x.fileName === r.fileName);
  if (i >= 0) results[i] = r; else results.push(r);
}

function updateStats(e) {
  const total = e.totalFiles || selectedFiles.length;
  const comp = e.completedFiles ?? results.filter(r => r.status === 'COMPLETED').length;
  const running = results.filter(r => r.status === 'RUNNING').length;
  const q = Math.max(0, total - comp - running);
  $('stTotal').textContent = total;
  $('stCompleted').textContent = comp;
  $('stRunning').textContent = running;
  $('stQueue').textContent = q;
  $('stCritical').textContent = results.filter(r => r.severity === 'CRITICAL').length;
  $('stMajor').textContent = results.filter(r => r.severity === 'MAJOR').length;
  $('stMinor').textContent = results.filter(r => r.severity === 'MINOR').length;
  const pct = total ? Math.round(comp * 100 / total) : 0;
  $('pct').textContent = pct + '%';
  $('barFill').style.width = pct + '%';
}

function baseRows() {
  return results.length ? results : selectedFiles.map(f => ({
    fileName: f.name,
    relativePath: f.webkitRelativePath || f.name,
    status: 'QUEUED', severity: '-', score: '-'
  }));
}

function renderQueueArea() {
  const box = $('queueList');
  box.innerHTML = '';
  if (activeQueueTab === 'summary') return renderSummary(box);
  if (activeQueueTab === 'comments') return renderAllComments(box);
  if (activeQueueTab === 'report') return renderReportTab(box);
  renderQueueRows(box);
}

function renderQueueRows(box) {
  const rows = baseRows();
  rows.forEach((r, i) => {
    const row = document.createElement('div');
    row.className = 'queueRow ' + (i === activeIndex ? 'active' : '');
    row.innerHTML = `<div><b>${esc(shortName(r.fileName))}</b><small>${esc(r.relativePath || r.fileName)}${r.largeFile ? ` • Large file ${r.completedChunks}/${r.totalChunks} chunks` : ''}</small></div><span class="badge ${r.status}">${esc(r.status)}</span><span class="badge ${r.severity}">${esc(r.severity)}</span><b>${r.score ?? '-'}/100</b>`;
    row.onclick = () => { activeIndex = i; renderQueueArea(); renderDetails(rows[i]); };
    box.appendChild(row);
  });
}

function renderSummary(box) {
  const totalIssues = results.reduce((s, r) => s + (r.issues || []).length, 0);
  const avg = results.length ? Math.round(results.reduce((s, r) => s + (Number(r.score) || 0), 0) / results.length) : '-';
  box.innerHTML = `<div class="summaryBox"><h3>Review Summary</h3><p><b>Total files:</b> ${selectedFiles.length || results.length}</p><p><b>Completed:</b> ${results.filter(r => r.status === 'COMPLETED').length}</p><p><b>Total comments:</b> ${totalIssues}</p><p><b>Average score:</b> ${avg}/100</p><p><b>PR Readiness:</b> ${results.some(r => ['CRITICAL', 'MAJOR'].includes(r.severity)) ? 'Needs fixes before PR' : 'Looks okay with minor improvements'}</p></div>`;
}

function renderAllComments(box) {
  const comments = results.flatMap(r => (r.issues || []).map(i => ({ file: r.fileName, issue: i })));
  if (!comments.length) { box.innerHTML = '<p class="muted pad">No comments yet. Start review first.</p>'; return; }
  comments.forEach((c, idx) => {
    const d = document.createElement('div');
    d.className = 'issue';
    d.innerHTML = `<h4>${idx + 1}. <span class="badge ${c.issue.severity}">${esc(c.issue.severity)}</span> ${esc(shortName(c.file))}</h4><p>${esc(c.issue.prComment || c.issue.whatIsWrong)}</p>`;
    box.appendChild(d);
  });
}

function renderReportTab(box) {
  box.innerHTML = `<div class="summaryBox"><h3>Report</h3><p>Download the current review report as JSON.</p><button onclick="downloadCurrentReport()">Download JSON Report</button><button onclick="copyAllPrComments()">Copy PR Comments</button></div>`;
}

function renderDetails(r) {
  if (!r) {
    $('detailTitle').textContent = 'Select a file';
    $('detailBadge').textContent = '';
    $('detailBody').innerHTML = 'Review comments will appear here immediately after a file or chunk completes.';
    return;
  }
  $('detailTitle').textContent = shortName(r.fileName);
  $('detailBadge').innerHTML = `<span class="badge ${r.status}">${esc(r.status)}</span>`;
  if (activeDetailTab === 'issues') return renderDetailIssues(r);
  if (activeDetailTab === 'chunks') return renderDetailChunks(r);
  if (activeDetailTab === 'pr') return renderDetailPr(r);
  renderDetailSummary(r);
}

function renderDetailSummary(r) {
  $('detailBody').innerHTML = `<h3>Summary</h3><p>${esc(r.summary || 'Waiting for result...')}</p><div class="stats mini"><div><b>${r.score ?? '-'}</b><span>Score</span></div><div><b>${(r.issues || []).length}</b><span>Issues</span></div><div><b>${r.completedChunks || 0}/${r.totalChunks || 0}</b><span>Chunks</span></div></div><h3>Top Issues</h3>${issueHtml(r, 3) || '<p class="green">No issues found yet.</p>'}`;
}

function renderDetailIssues(r) {
  $('detailBody').innerHTML = `<h3>Issues (${(r.issues || []).length})</h3>${issueHtml(r) || '<p class="green">No issues found.</p>'}`;
}

function renderDetailChunks(r) {
  const chunks = (r.chunkSummaries || []).map(c => `<div class="chunkLine">${esc(c)}</div>`).join('') || '<p class="muted">No chunk details. Small files do not need chunking.</p>';
  $('detailBody').innerHTML = `<h3>Chunks (${r.completedChunks || 0}/${r.totalChunks || 0})</h3>${chunks}`;
}

function renderDetailPr(r) {
  const comments = (r.issues || []).map((x, i) => `${i + 1}. [${x.severity}] ${x.prComment || x.whatIsWrong}`).join('\n');
  $('detailBody').innerHTML = `<h3>PR Comments</h3><pre id="prText">${esc(comments || 'No PR comments generated yet.')}</pre><button onclick="copyPrForActive()">Copy This File PR Comments</button>`;
}

function issueHtml(r, limit) {
  const arr = limit ? (r.issues || []).slice(0, limit) : (r.issues || []);
  return arr.map((x, idx) => `<div class="issue"><h4>${idx + 1}. <span class="badge ${x.severity}">${esc(x.severity)}</span> ${esc(x.whatIsWrong)}</h4><p><b>Category:</b> ${esc(x.category || '-')} ${x.lineNumber ? ` • <b>Line:</b> ${x.lineNumber}` : ''}</p><p><b>Why it matters:</b> ${esc(x.whyItMatters || '-')}</p><p><b>What to change:</b> ${esc(x.whatNeedsToBeChanged || '-')}</p>${x.suggestedCode ? `<pre>${esc(x.suggestedCode)}</pre>` : ''}<p><b>PR Comment:</b> ${esc(x.prComment || '-')}</p></div>`).join('');
}

function setStatus(t, ok) {
  $('statusText').textContent = t;
  $('readyDot').style.background = ok ? '#1fd36b' : '#ff4b4b';
}

function addHistory() {
  const h = $('historyList');
  if (!h) return;
  const div = document.createElement('div');
  div.className = 'issue';
  div.innerHTML = `<b>${esc(currentReviewId)}</b><p>${new Date().toLocaleString()} - ${results.length} files reviewed.</p>`;
  h.prepend(div);
}

async function downloadCurrentReport() {
  if (!currentReviewId) { alert('No review yet'); return; }
  const r = await fetch('/api/review/report/' + currentReviewId);
  const txt = JSON.stringify(await r.json(), null, 2);
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob([txt], { type: 'application/json' }));
  a.download = currentReviewId + '.json';
  a.click();
}

$('downloadReport').onclick = downloadCurrentReport;

function copyPrForActive() {
  const r = results[activeIndex];
  if (!r) return;
  const text = (r.issues || []).map((x, i) => `${i + 1}. [${x.severity}] ${x.prComment || x.whatIsWrong}`).join('\n');
  navigator.clipboard.writeText(text || 'No PR comments').then(() => alert('PR comments copied'));
}

function copyAllPrComments() {
  const text = results.flatMap(r => (r.issues || []).map((x, i) => `${shortName(r.fileName)} - [${x.severity}] ${x.prComment || x.whatIsWrong}`)).join('\n');
  navigator.clipboard.writeText(text || 'No PR comments').then(() => alert('All PR comments copied'));
}

function esc(s) { return String(s ?? '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c])); }
function shortName(s) { return String(s || '').split('/').pop(); }

initNavigation();
initSourceSelection();
initQueueTabs();
initDetailTabs();
renderSelected();
renderQueueArea();
