# Smart Playwright LangChain Framework v4.0

Enterprise-style Playwright TypeScript framework using installed Chrome, Edge, or an approved Chromium executable. It includes JSON test data, Page Object Model, LangChain-based LLM self-healing, optional healed-locator persistence, a custom colourful HTML report, the default Playwright HTML report, JUnit XML, corporate CA support, and Jenkins execution.

## Quick start

1. Install Node.js 20 or 22 LTS.
2. Extract the project.
3. Open PowerShell in the project root.
4. Install dependencies:

```powershell
npm ci
```

5. Copy the configuration:

```powershell
Copy-Item .env.example .env
```

6. Put the generated PEM certificate bundle in:

```text
certificates\generated-ca-bundle.pem
```

7. Configure `.env`.
8. Run:

```powershell
npm test
```

The command directly starts Playwright Test. Browser detection checks executable paths only; it does not launch temporary browsers.

## Reports

Custom consolidated report:

```text
reports\index.html
```

Default Playwright HTML report:

```text
playwright-report\index.html
```

Open the default report:

```powershell
npm run report:playwright
```

Raw results and Jenkins XML:

```text
reports\test-results.json
test-results\junit.xml
```

## Documentation

- [Complete configuration and usage](docs/CONFIGURATION_AND_USAGE.md)
- [Framework architecture](docs/ARCHITECTURE.md)
- [Execution flow](docs/EXECUTION_FLOW.md)
- [Self-healing guide](docs/SELF_HEALING.md)
- [Jenkins guide](docs/JENKINS.md)
