import { test } from '@playwright/test';
import { LoginPage } from '../src/pages/LoginPage';
import { readJsonFile } from '../src/utils/JsonData';

interface LoginTestData {
  run: boolean;
  testId: string;
  testName: string;
  username: string;
  password: string;
  expectedType: 'products' | 'error';
  expectedValue: string;
}

const testData = readJsonFile<LoginTestData[]>('test-data/login-tests.json').filter(row => row.run);

test.describe('SauceDemo Login', () => {
  for (const row of testData) {
    test(`[${row.testId}] ${row.testName}`, async ({ page }, testInfo) => {
      testInfo.annotations.push({ type: 'testId', description: row.testId });
      const loginPage = new LoginPage(page);
      await loginPage.open();
      await loginPage.login(row.username, row.password);
      if (row.expectedType === 'products') {
        await loginPage.verifyProductsPage(row.expectedValue);
      } else {
        await loginPage.verifyError(row.expectedValue);
      }
    });
  }
});
