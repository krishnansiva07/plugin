import { existsSync, readFileSync } from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';

const root = path.resolve(__dirname, '..');
const candidates = [
  'generated-ca-bundle.pem',
  'corporate-ca.pem',
  'cacert.pem',
  'cacert',
  'cacerts'
].map(name => path.join(root, 'certificates', name));
const certificate = candidates.find(existsSync);
const childEnvironment = { ...process.env };

if (certificate) {
  const content = readFileSync(certificate, 'utf8');
  if (!content.includes('-----BEGIN CERTIFICATE-----')) {
    console.error(`[CERTIFICATE] ${certificate} is not a PEM certificate bundle.`);
    process.exit(2);
  }
  childEnvironment.NODE_EXTRA_CA_CERTS = certificate;
  console.log(`[CERTIFICATE] Corporate CA configured: ${certificate}`);
}

const cli = path.join(root, 'node_modules', '@playwright', 'test', 'cli.js');
const result = spawnSync(process.execPath, [cli, 'test', ...process.argv.slice(2)], {
  cwd: root,
  env: childEnvironment,
  stdio: 'inherit',
  windowsHide: false
});

if (result.error) {
  console.error(result.error);
  process.exit(1);
}
process.exit(result.status ?? 1);
