# ITPS VIBIUM Framework

Production-ready Java Vibium + LLM test execution framework for business scenario packs.

## Purpose

This application lets testers upload Excel/JSON scenarios with test data, use an LLM token at runtime, execute the flow through the Vibium Java client, and publish post-run evidence as JSON, Excel, screenshots ZIP, and a BNP-green HTML report.

## What changed in this final product build

- Product name changed to **ITPS VIBIUM Framework**.
- UI redesigned with BNP-inspired green theme.
- Browser/Vibium configuration removed from UI for production simplicity.
- Default execution mode is **Vibium Managed Chrome for Testing**.
- Added dynamic-element handling with layered locator strategy.
- Added smart retry/wait for late-loaded elements.
- Added smart click/fill/select/check fallback for React/Angular/custom controls.
- Added downloadable and viewable `report.html`.
- Added faster default execution: failure-only screenshots, shorter balanced timeout, polling every 1.5s.

## Important browser note

Pure Java Vibium does not use local `chrome.exe` or `chromedriver.exe` like Selenium. It runs with Vibium-managed Chrome for Testing.

For locked corporate networks:

```cmd
set VIBIUM_SKIP_BROWSER_DOWNLOAD=1
mvn clean spring-boot:run
```

Before using the above, copy the Vibium browser cache from a machine where `vibium install` worked.

## Run locally

```cmd
mvn clean spring-boot:run
```

Open:

```text
http://localhost:8090
```

## Excel format

Recommended columns:

```text
id | name | url | steps | expected | data.username | data.password | testDataJson
```

Steps support either plain English or explicit Vibium action JSON. Explicit JSON is fastest and most stable.

Example step lines:

```json
{"action":"FILL","selectorType":"auto","target":"Username","value":"{{username}}"}
{"action":"FILL","selectorType":"auto","target":"Password","value":"{{password}}"}
{"action":"CLICK","selectorType":"auto","target":"login-button"}
{"action":"ASSERT_TEXT","value":"Products"}
```

## Supported actions

- `NAVIGATE`
- `CLICK`, `DOUBLE_CLICK`, `RIGHT_CLICK`
- `FILL`, `TYPE`, `CLEAR`
- `PRESS`
- `SELECT`
- `CHECK`, `UNCHECK`
- `ASSERT_TEXT`, `ASSERT_NOT_TEXT`
- `ASSERT_VISIBLE`
- `ASSERT_URL`, `ASSERT_TITLE`
- `WAIT`, `WAIT_FOR_TEXT`, `WAIT_FOR_VISIBLE`
- `SCROLL`, `SCROLL_TO`
- `HOVER`

## Supported selector types

- `auto` recommended
- `text`
- `label`
- `placeholder`
- `role`
- `testid`
- `css`
- `xpath`
- `title`

## Post-run artifacts

Each run creates:

```text
target/vibium-test-runs/<run-id>/
  report.html
  report.json
  report.xlsx
  screenshots.zip
  screenshots/
```

## Performance guidance

For daily smoke/sanity runs:

- Use explicit JSON steps in Excel instead of plain English to avoid LLM call per step.
- Keep screenshot mode as `Failure only`.
- Use headless mode.
- Use 4-6 seconds timeout unless the application is slow.
- Keep `Smart dynamic element fallback` enabled for unstable UI.

For debugging:

- Use headed mode.
- Change screenshots to `Every step`.
- Increase timeout to 10 seconds.
