package com.llmart.llm.controller;

import com.llmart.llm.model.RunConfig;
import com.llmart.llm.model.RunStatus;
import com.llmart.llm.model.TestScenario;
import com.llmart.llm.service.RunStore;
import com.llmart.llm.service.ScenarioFileParser;
import com.llmart.llm.service.TestRunService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/runs")
public class RunController {
    private final ScenarioFileParser parser;
    private final TestRunService testRunService;
    private final RunStore runStore;
    private final Path outputRoot;

    public RunController(ScenarioFileParser parser,
                         TestRunService testRunService,
                         RunStore runStore,
                         @Value("${runner.output-dir:target/vibium-test-runs}") String outputDir) {
        this.parser = parser;
        this.testRunService = testRunService;
        this.runStore = runStore;
        this.outputRoot = Path.of(outputDir);
    }

    @PostMapping(consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<?> startRun(
            @RequestParam("scenarioFile") MultipartFile scenarioFile,
            @RequestParam(required = false) String llmBaseUrl,
            @RequestParam(required = false) String llmApiKey,
            @RequestParam(required = false) String llmModel,
            @RequestParam(required = false) String appBaseUrl,
            @RequestParam(defaultValue = "false") boolean headless,
            @RequestParam(defaultValue = "true") boolean useLlm,
            @RequestParam(defaultValue = "true") boolean continueOnFailure,
            @RequestParam(defaultValue = "FAILURE_ONLY") String screenshotMode,
            @RequestParam(defaultValue = "6") int stepTimeoutSeconds,
            @RequestParam(defaultValue = "2") int retryCount,
            @RequestParam(defaultValue = "700") int retryDelayMs,
            @RequestParam(defaultValue = "0") int slowMoMs,
            @RequestParam(defaultValue = "true") boolean smartFallback,
            // Hidden/optional production settings. Not shown in UI because the product is Vibium managed by default.
            @RequestParam(required = false) MultipartFile vibiumBinaryFile,
            @RequestParam(required = false) String vibiumBinaryPath,
            @RequestParam(required = false, defaultValue = "VIBIUM_MANAGED") String browserMode,
            @RequestParam(required = false) String remoteDebugUrl
    ) {
        try {
            List<TestScenario> scenarios = parser.parse(scenarioFile);
            if (scenarios.isEmpty()) {
                return ResponseEntity.badRequest().body(Map.of("error", "No scenarios found in uploaded file"));
            }

            RunConfig config = new RunConfig();
            config.setLlmBaseUrl(llmBaseUrl);
            config.setLlmApiKey(llmApiKey);
            config.setLlmModel(llmModel);
            config.setAppBaseUrl(appBaseUrl);
            config.setVibiumBinaryPath(firstNonBlank(vibiumBinaryPath, saveUpload(vibiumBinaryFile, "uploaded-vibium-binaries")));
            config.setBrowserMode(firstNonBlank(browserMode, "VIBIUM_MANAGED"));
            config.setRemoteDebugUrl(remoteDebugUrl);
            config.setHeadless(headless);
            config.setUseLlm(useLlm);
            config.setContinueOnFailure(continueOnFailure);
            config.setScreenshotMode(firstNonBlank(screenshotMode, "FAILURE_ONLY"));
            config.setStepTimeoutSeconds(Math.max(2, Math.min(stepTimeoutSeconds, 30)));
            config.setRetryCount(Math.max(0, Math.min(retryCount, 5)));
            config.setRetryDelayMs(Math.max(100, Math.min(retryDelayMs, 5000)));
            config.setSlowMoMs(Math.max(0, Math.min(slowMoMs, 5000)));
            config.setSmartFallback(smartFallback);

            RunStatus status = testRunService.start(scenarios, config);
            return ResponseEntity.ok(status);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    @GetMapping("/{runId}")
    public ResponseEntity<?> getRun(@PathVariable String runId) {
        return runStore.get(runId)
                .<ResponseEntity<?>>map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.status(404).body(Map.of("error", "Run not found")));
    }

    @GetMapping("/{runId}/report.json")
    public ResponseEntity<?> downloadJson(@PathVariable String runId) {
        return download(runId, "report.json", MediaType.APPLICATION_JSON_VALUE, true);
    }

    @GetMapping("/{runId}/report.xlsx")
    public ResponseEntity<?> downloadExcel(@PathVariable String runId) {
        return download(runId, "report.xlsx", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", true);
    }

    @GetMapping("/{runId}/report.html")
    public ResponseEntity<?> downloadHtml(@PathVariable String runId) {
        return download(runId, "report.html", MediaType.TEXT_HTML_VALUE, false);
    }

    @GetMapping("/{runId}/screenshots.zip")
    public ResponseEntity<?> downloadScreenshots(@PathVariable String runId) {
        return download(runId, "screenshots.zip", "application/zip", true);
    }

    @GetMapping("/{runId}/screenshots/{filename:.+}")
    public ResponseEntity<?> screenshot(@PathVariable String runId, @PathVariable String filename) {
        return download(runId, "screenshots/" + filename, MediaType.IMAGE_PNG_VALUE, false);
    }

    private ResponseEntity<?> download(String runId, String relativeFile, String contentType, boolean attachment) {
        try {
            Path runDir = outputRoot.resolve(runId).normalize();
            Path path = runDir.resolve(relativeFile).normalize();
            if (!path.startsWith(runDir) || !Files.exists(path)) {
                return ResponseEntity.status(404).body(Map.of("error", "File not found"));
            }
            ByteArrayResource resource = new ByteArrayResource(Files.readAllBytes(path));
            ResponseEntity.BodyBuilder builder = ResponseEntity.ok().contentType(MediaType.parseMediaType(contentType));
            if (attachment) {
                builder.header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + path.getFileName() + "\"");
            }
            return builder.body(resource);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    private String saveUpload(MultipartFile file, String folder) throws Exception {
        if (file == null || file.isEmpty()) return "";
        String originalName = file.getOriginalFilename() == null ? "upload.bin" : file.getOriginalFilename();
        String safeName = originalName.replaceAll("[^a-zA-Z0-9._-]", "_");
        Path dir = outputRoot.resolve(folder);
        Files.createDirectories(dir);
        Path target = dir.resolve(System.currentTimeMillis() + "_" + safeName);
        file.transferTo(target);
        target.toFile().setExecutable(true);
        return target.toAbsolutePath().toString();
    }

    private String firstNonBlank(String... values) {
        for (String value : values) {
            if (value != null && !value.isBlank()) return value.trim();
        }
        return "";
    }
}
