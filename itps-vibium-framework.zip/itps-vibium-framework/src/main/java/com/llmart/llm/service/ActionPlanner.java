package com.llmart.llm.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.llmart.llm.model.AgentAction;
import com.llmart.llm.model.RunConfig;
import com.llmart.llm.model.TestScenario;
import org.springframework.stereotype.Service;

import java.util.Locale;
import java.util.Map;

@Service
public class ActionPlanner {
    private final LlmClient llmClient;
    private final ObjectMapper mapper = new ObjectMapper();

    public ActionPlanner(LlmClient llmClient) {
        this.llmClient = llmClient;
    }

    public AgentAction plan(TestScenario scenario, int stepNo, String step, String pageUrl, String pageTitle, String pageSnapshot, RunConfig config) throws Exception {
        String resolved = replaceData(step, scenario.getData());
        if (resolved.trim().startsWith("{") && resolved.trim().endsWith("}")) {
            AgentAction action = mapper.readValue(resolved, AgentAction.class);
            resolveActionData(action, scenario.getData());
            return action;
        }
        if (config.isUseLlm()) {
            String prompt = "You are the action planner for ITPS VIBIUM Java framework.\n" +
                    "Return exactly one compact JSON object. No markdown.\n" +
                    "Schema: {\"action\":\"ACTION\",\"selectorType\":\"auto|text|label|placeholder|role|testid|css|xpath|title\",\"target\":\"locator or visible label\",\"value\":\"data value if needed\",\"key\":\"keyboard key if needed\",\"seconds\":1}.\n" +
                    "Supported actions: NAVIGATE, CLICK, FILL, TYPE, CLEAR, PRESS, SELECT, CHECK, UNCHECK, ASSERT_TEXT, ASSERT_NOT_TEXT, ASSERT_VISIBLE, ASSERT_URL, ASSERT_TITLE, WAIT, SCROLL_TO, HOVER, DOUBLE_CLICK, RIGHT_CLICK.\n" +
                    "Prefer selectorType auto for dynamic elements. Prefer stable attributes such as id, name, data-test, data-testid, aria-label, label or placeholder from the Visible controls JSON.\n" +
                    "For Enter/Fill/Type steps use FILL and put the actual test data value in value. For buttons/links use CLICK.\n" +
                    "Scenario: " + scenario.getName() + "\n" +
                    "Current URL: " + pageUrl + "\n" +
                    "Current title: " + pageTitle + "\n" +
                    "Visible controls JSON: " + pageSnapshot + "\n" +
                    "Test data JSON: " + mapper.writeValueAsString(scenario.getData()) + "\n" +
                    "Step number: " + stepNo + "\n" +
                    "Step instruction: " + resolved;
            String json = llmClient.plan(prompt, config);
            AgentAction action = mapper.readValue(json, AgentAction.class);
            if (action.getAction() == null || action.getAction().isBlank()) {
                throw new IllegalArgumentException("LLM returned action without action field: " + json);
            }
            resolveActionData(action, scenario.getData());
            return action;
        }
        return heuristic(resolved, scenario);
    }

    public String toJson(AgentAction action) {
        try { return mapper.writeValueAsString(action); }
        catch (Exception e) { return String.valueOf(action); }
    }

    private AgentAction heuristic(String step, TestScenario scenario) {
        String lower = step.toLowerCase(Locale.ROOT);
        if (lower.startsWith("open ") || lower.startsWith("navigate") || lower.startsWith("go to ")) {
            String url = scenario.getUrl();
            int idx = lower.indexOf("http");
            if (idx >= 0) url = step.substring(idx).trim();
            return AgentAction.of("NAVIGATE", "auto", url, null);
        }
        if (lower.startsWith("wait for") && (lower.contains(" visible") || lower.contains("displayed"))) {
            return AgentAction.of("ASSERT_VISIBLE", "auto", cleanupTarget(step), null);
        }
        if (lower.startsWith("wait") || lower.contains("pause")) {
            AgentAction a = AgentAction.of("WAIT", null, null, null);
            a.setSeconds(1);
            return a;
        }
        if (lower.contains("not display") || lower.contains("should not see")) {
            String text = step.replaceAll("(?i)verify|assert|should not see|is not displayed|not displayed|text", "").trim();
            return AgentAction.of("ASSERT_NOT_TEXT", "text", text, null);
        }
        if (lower.contains("verify") || lower.contains("assert") || lower.contains("should see")) {
            String text = step.replaceAll("(?i)verify|assert|should see|text|is displayed|displayed|page is", "").trim();
            return AgentAction.of("ASSERT_TEXT", "text", text.isBlank() ? scenario.getExpected() : text, null);
        }
        if (lower.contains("enter") || lower.contains("fill") || lower.contains("type")) {
            String value = guessValue(step, scenario.getData());
            String field = guessField(step);
            return AgentAction.of("FILL", "auto", field, value);
        }
        if (lower.contains("select")) return AgentAction.of("SELECT", "auto", guessField(step), guessValue(step, scenario.getData()));
        if (lower.contains("press enter")) { AgentAction a = AgentAction.of("PRESS", null, null, null); a.setKey("Enter"); return a; }
        if (lower.contains("hover")) return AgentAction.of("HOVER", "auto", cleanupTarget(step), null);
        if (lower.contains("uncheck")) return AgentAction.of("UNCHECK", "auto", cleanupTarget(step), null);
        if (lower.contains("check")) return AgentAction.of("CHECK", "auto", cleanupTarget(step), null);
        return AgentAction.of("CLICK", "auto", cleanupTarget(step), null);
    }

    private String guessValue(String step, Map<String, Object> data) {
        String lower = step.toLowerCase(Locale.ROOT);
        for (Map.Entry<String, Object> entry : data.entrySet()) {
            String key = entry.getKey().toLowerCase(Locale.ROOT);
            String value = String.valueOf(entry.getValue());
            if (lower.contains(key) || lower.contains(key.replace("_", " ")) || lower.contains(value.toLowerCase(Locale.ROOT))) return value;
        }
        int idx = lower.indexOf("value ");
        if (idx >= 0) return step.substring(idx + 6).trim();
        idx = lower.indexOf(" as ");
        if (idx >= 0) return step.substring(idx + 4).trim();
        return "";
    }

    private String guessField(String step) {
        String cleaned = step.replaceAll("(?i)enter|fill|type|value|with|the", " ").trim();
        cleaned = cleaned.replaceAll("\\s+", " ");
        if (cleaned.toLowerCase(Locale.ROOT).contains(" in ")) cleaned = cleaned.substring(cleaned.toLowerCase(Locale.ROOT).lastIndexOf(" in ") + 4).trim();
        cleaned = cleaned.replaceAll("(?i)\\bfield\\b", " ").replaceAll("\\s+", " ").trim();
        return cleaned;
    }

    private String cleanupTarget(String step) {
        return step.replaceAll("(?i)click|button|link|tap|on|the|verify|assert|should see|is displayed|displayed|hover|check|uncheck", " ")
                .replaceAll("\\s+", " ").trim();
    }

    private void resolveActionData(AgentAction action, Map<String, Object> data) {
        if (action.getTarget() != null) action.setTarget(replaceData(action.getTarget(), data));
        if (action.getValue() != null) action.setValue(replaceData(action.getValue(), data));
        if (action.getKey() != null) action.setKey(replaceData(action.getKey(), data));
    }

    private String replaceData(String text, Map<String, Object> data) {
        String resolved = text == null ? "" : text;
        if (data == null) return resolved;
        for (Map.Entry<String, Object> entry : data.entrySet()) {
            resolved = resolved.replace("{{" + entry.getKey() + "}}", String.valueOf(entry.getValue()));
        }
        return resolved;
    }
}
