package com.llmart.llm.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.llmart.llm.model.RunStatus;
import com.llmart.llm.model.ScenarioResult;
import com.llmart.llm.model.StepResult;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Service;

import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.util.stream.Stream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

@Service
public class ReportService {
    private final ObjectMapper mapper = new ObjectMapper()
            .registerModule(new JavaTimeModule())
            .disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS)
            .enable(SerializationFeature.INDENT_OUTPUT);

    public void writeAll(RunStatus status, Path runDir) throws Exception {
        Files.createDirectories(runDir);
        mapper.writeValue(runDir.resolve("report.json").toFile(), status);
        writeExcel(status, runDir.resolve("report.xlsx"));
        writeHtml(status, runDir.resolve("report.html"));
        zipScreenshots(runDir.resolve("screenshots"), runDir.resolve("screenshots.zip"));
    }

    private void writeHtml(RunStatus status, Path output) throws Exception {
        long durationMs = 0;
        if (status.getStartedAt() != null && status.getFinishedAt() != null) {
            durationMs = Duration.between(status.getStartedAt(), status.getFinishedAt()).toMillis();
        }
        int stepTotal = status.getScenarios().stream().mapToInt(s -> s.getSteps().size()).sum();
        int stepPassed = status.getScenarios().stream().flatMap(s -> s.getSteps().stream()).mapToInt(s -> "PASSED".equals(s.getStatus()) ? 1 : 0).sum();
        int stepFailed = status.getScenarios().stream().flatMap(s -> s.getSteps().stream()).mapToInt(s -> "FAILED".equals(s.getStatus()) ? 1 : 0).sum();
        double passRate = status.getTotal() == 0 ? 0.0 : (status.getPassed() * 100.0 / status.getTotal());

        StringBuilder html = new StringBuilder();
        html.append("<!doctype html><html><head><meta charset='utf-8'/><meta name='viewport' content='width=device-width,initial-scale=1'/>")
                .append("<title>ITPS VIBIUM Report - ").append(esc(status.getRunId())).append("</title>")
                .append("<style>")
                .append(HTML_CSS)
                .append("</style></head><body>");
        html.append("<section class='hero'><div class='brand'><div class='logo'>ITPS</div><div><p>BNP Green Automation</p><h1>ITPS VIBIUM Execution Report</h1></div></div>")
                .append("<div class='pill ").append(statusClass(status.getStatus())).append("'>").append(esc(status.getStatus())).append("</div></section>");
        html.append("<section class='summary'>")
                .append(kpi("Run ID", status.getRunId()))
                .append(kpi("Scenarios", String.valueOf(status.getTotal())))
                .append(kpi("Passed", String.valueOf(status.getPassed())))
                .append(kpi("Failed", String.valueOf(status.getFailed())))
                .append(kpi("Pass Rate", String.format("%.1f%%", passRate)))
                .append(kpi("Duration", formatDuration(durationMs)))
                .append(kpi("Steps", stepPassed + " / " + stepTotal + " passed"))
                .append(kpi("Step Failed", String.valueOf(stepFailed)))
                .append("</section>");
        if (status.getMessage() != null && !status.getMessage().isBlank()) {
            html.append("<section class='notice'>").append(esc(status.getMessage())).append("</section>");
        }
        html.append("<section class='downloads'><a href='report.json'>JSON Report</a><a href='report.xlsx'>Excel Report</a><a href='screenshots.zip'>Screenshots ZIP</a></section>");
        html.append("<section class='scenarios'>");
        for (ScenarioResult scenario : status.getScenarios()) {
            html.append("<article class='scenario'><header><div><span class='sid'>").append(esc(scenario.getId())).append("</span>")
                    .append("<h2>").append(esc(scenario.getName())).append("</h2>")
                    .append("<p>").append(esc(scenario.getUrl())).append("</p></div><span class='pill ").append(statusClass(scenario.getStatus())).append("'>")
                    .append(esc(scenario.getStatus())).append("</span></header>");
            if (scenario.getErrorMessage() != null && !scenario.getErrorMessage().isBlank()) {
                html.append("<div class='error'>").append(esc(scenario.getErrorMessage())).append("</div>");
            }
            html.append("<div class='table-wrap'><table><thead><tr><th>#</th><th>Step</th><th>Status</th><th>ms</th><th>Vibium Action</th><th>Screenshot</th><th>Error</th></tr></thead><tbody>");
            for (StepResult step : scenario.getSteps()) {
                html.append("<tr><td>").append(step.getStepNo()).append("</td><td>").append(esc(step.getInstruction())).append("</td><td><span class='pill small ")
                        .append(statusClass(step.getStatus())).append("'>").append(esc(step.getStatus())).append("</span></td><td>").append(step.getDurationMs()).append("</td><td><code>")
                        .append(esc(step.getActionJson())).append("</code></td><td>");
                if (step.getScreenshot() != null && !step.getScreenshot().isBlank()) {
                    html.append("<a class='shot-link' href='").append(esc(step.getScreenshot())).append("'>open</a>")
                            .append("<img class='thumb' src='").append(esc(step.getScreenshot())).append("' alt='screenshot'/>");
                }
                html.append("</td><td class='err-cell'>").append(esc(step.getErrorMessage())).append("</td></tr>");
            }
            html.append("</tbody></table></div></article>");
        }
        html.append("</section><footer>Generated by ITPS VIBIUM Framework</footer></body></html>");
        Files.writeString(output, html.toString(), StandardCharsets.UTF_8);
    }

    private static final String HTML_CSS = """
            :root{--green:#007a3d;--green2:#014421;--lime:#c9df8a;--bg:#f4f8f4;--card:#fff;--line:#dfe8df;--text:#102218;--muted:#617069;--red:#b42318;--amber:#b45309;}
            *{box-sizing:border-box}body{margin:0;font-family:Segoe UI,Inter,Arial,sans-serif;background:linear-gradient(135deg,#eef7ef,#f7fbf7 45%,#ecfdf5);color:var(--text);padding:28px}.hero{background:linear-gradient(135deg,var(--green2),var(--green));color:#fff;border-radius:28px;padding:26px 30px;display:flex;align-items:center;justify-content:space-between;gap:20px;box-shadow:0 20px 70px rgba(1,68,33,.24)}.brand{display:flex;align-items:center;gap:18px}.logo{width:68px;height:68px;border-radius:20px;background:#fff;color:var(--green);display:grid;place-items:center;font-weight:900;font-size:22px;letter-spacing:-1px}.brand p{margin:0;color:#d7f7df;text-transform:uppercase;letter-spacing:2px;font-size:12px;font-weight:800}.brand h1{margin:5px 0 0;font-size:34px;letter-spacing:-1px}.pill{display:inline-flex;align-items:center;justify-content:center;border-radius:999px;padding:10px 16px;font-weight:900;font-size:13px;letter-spacing:.3px;color:#fff;white-space:nowrap}.small{padding:5px 10px;font-size:11px}.ok,.PASSED{background:#168044}.bad,.FAILED,.COMPLETED_WITH_FAILURES{background:var(--red)}.run,.RUNNING,.QUEUED{background:var(--amber)}.summary{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:14px;margin:22px 0}.kpi{background:var(--card);border:1px solid var(--line);border-radius:20px;padding:18px;box-shadow:0 8px 32px rgba(16,34,24,.08)}.kpi .label{color:var(--muted);font-size:12px;text-transform:uppercase;letter-spacing:1px;font-weight:900}.kpi .value{font-size:25px;font-weight:950;margin-top:8px;overflow-wrap:anywhere}.notice{background:#fff8e6;border:1px solid #f5d68c;border-radius:18px;padding:14px 16px;color:#624600;margin-bottom:18px}.downloads{display:flex;gap:12px;flex-wrap:wrap;margin-bottom:18px}.downloads a,.shot-link{color:var(--green);font-weight:900;text-decoration:none;border:1px solid #b7dfc8;background:#fff;border-radius:999px;padding:9px 13px}.scenario{background:#fff;border:1px solid var(--line);border-radius:24px;margin:18px 0;overflow:hidden;box-shadow:0 8px 40px rgba(16,34,24,.08)}.scenario header{display:flex;justify-content:space-between;gap:20px;padding:20px;background:#f8fcf8;border-bottom:1px solid var(--line)}.sid{font-size:12px;color:var(--green);font-weight:950;letter-spacing:1.2px}.scenario h2{margin:5px 0;font-size:22px}.scenario p{margin:0;color:var(--muted);overflow-wrap:anywhere}.error{margin:14px 18px;padding:12px 14px;border-radius:14px;background:#fff1f0;color:var(--red);font-weight:700}.table-wrap{overflow:auto}table{width:100%;border-collapse:collapse}th,td{padding:12px;border-bottom:1px solid var(--line);text-align:left;vertical-align:top;font-size:13px}th{font-size:12px;text-transform:uppercase;letter-spacing:.8px;color:var(--muted);background:#fff}code{font-family:Consolas,Monaco,monospace;display:block;max-width:460px;white-space:pre-wrap;overflow-wrap:anywhere;color:#193826}.err-cell{color:var(--red);font-weight:600}.thumb{display:block;max-width:180px;max-height:100px;margin-top:8px;border-radius:10px;border:1px solid var(--line)}footer{text-align:center;color:var(--muted);padding:24px}@media(max-width:900px){body{padding:14px}.hero,.scenario header{flex-direction:column;align-items:flex-start}.summary{grid-template-columns:1fr 1fr}.brand h1{font-size:26px}}@media(max-width:560px){.summary{grid-template-columns:1fr}}
            """;

    private String kpi(String label, String value) {
        return "<div class='kpi'><div class='label'>" + esc(label) + "</div><div class='value'>" + esc(value) + "</div></div>";
    }

    private String formatDuration(long ms) {
        long seconds = ms / 1000;
        long minutes = seconds / 60;
        long remSeconds = seconds % 60;
        if (minutes > 0) return minutes + "m " + remSeconds + "s";
        return seconds + "s";
    }

    private String statusClass(String status) {
        if (status == null) return "run";
        return switch (status) {
            case "PASSED" -> "ok";
            case "FAILED", "COMPLETED_WITH_FAILURES" -> "bad";
            default -> "run";
        };
    }

    private String esc(String value) {
        if (value == null) return "";
        return value.replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;")
                .replace("\"", "&quot;")
                .replace("'", "&#39;");
    }

    private void writeExcel(RunStatus status, Path output) throws Exception {
        try (Workbook wb = new XSSFWorkbook()) {
            CellStyle titleStyle = wb.createCellStyle();
            Font titleFont = wb.createFont();
            titleFont.setBold(true);
            titleFont.setFontHeightInPoints((short) 16);
            titleFont.setColor(IndexedColors.GREEN.getIndex());
            titleStyle.setFont(titleFont);

            CellStyle headerStyle = wb.createCellStyle();
            Font headerFont = wb.createFont();
            headerFont.setBold(true);
            headerFont.setColor(IndexedColors.WHITE.getIndex());
            headerStyle.setFont(headerFont);
            headerStyle.setFillForegroundColor(IndexedColors.GREEN.getIndex());
            headerStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
            headerStyle.setBorderBottom(BorderStyle.THIN);

            Sheet summary = wb.createSheet("Summary");
            int r = 0;
            Row title = summary.createRow(r++);
            title.createCell(0).setCellValue("ITPS VIBIUM Framework - Test Run Summary");
            title.getCell(0).setCellStyle(titleStyle);
            r++;
            r = summaryRow(summary, r, "Run ID", status.getRunId());
            r = summaryRow(summary, r, "Status", status.getStatus());
            r = summaryRow(summary, r, "Started At", status.getStartedAt() == null ? "" : status.getStartedAt().toString());
            r = summaryRow(summary, r, "Finished At", status.getFinishedAt() == null ? "" : status.getFinishedAt().toString());
            r = summaryRow(summary, r, "Total", String.valueOf(status.getTotal()));
            r = summaryRow(summary, r, "Passed", String.valueOf(status.getPassed()));
            r = summaryRow(summary, r, "Failed", String.valueOf(status.getFailed()));
            r = summaryRow(summary, r, "Message", status.getMessage() == null ? "" : status.getMessage());
            summary.autoSizeColumn(0);
            summary.autoSizeColumn(1);

            Sheet steps = wb.createSheet("Step Results");
            Row h = steps.createRow(0);
            String[] headers = {"Scenario ID", "Scenario Name", "Scenario Status", "Step No", "Instruction", "Vibium Action JSON", "Step Status", "Duration ms", "Screenshot", "Error"};
            for (int i = 0; i < headers.length; i++) {
                Cell c = h.createCell(i);
                c.setCellValue(headers[i]);
                c.setCellStyle(headerStyle);
            }
            int rowNo = 1;
            for (ScenarioResult sr : status.getScenarios()) {
                for (StepResult st : sr.getSteps()) {
                    Row row = steps.createRow(rowNo++);
                    row.createCell(0).setCellValue(sr.getId());
                    row.createCell(1).setCellValue(sr.getName());
                    row.createCell(2).setCellValue(sr.getStatus());
                    row.createCell(3).setCellValue(st.getStepNo());
                    row.createCell(4).setCellValue(st.getInstruction());
                    row.createCell(5).setCellValue(st.getActionJson());
                    row.createCell(6).setCellValue(st.getStatus());
                    row.createCell(7).setCellValue(st.getDurationMs());
                    row.createCell(8).setCellValue(st.getScreenshot() == null ? "" : st.getScreenshot());
                    row.createCell(9).setCellValue(st.getErrorMessage() == null ? "" : st.getErrorMessage());
                }
                if (sr.getSteps().isEmpty()) {
                    Row row = steps.createRow(rowNo++);
                    row.createCell(0).setCellValue(sr.getId());
                    row.createCell(1).setCellValue(sr.getName());
                    row.createCell(2).setCellValue(sr.getStatus());
                    row.createCell(9).setCellValue(sr.getErrorMessage() == null ? "" : sr.getErrorMessage());
                }
            }
            for (int i = 0; i < headers.length; i++) {
                steps.autoSizeColumn(i);
                if (steps.getColumnWidth(i) > 18000) steps.setColumnWidth(i, 18000);
            }
            steps.createFreezePane(0, 1);

            try (OutputStream os = Files.newOutputStream(output)) {
                wb.write(os);
            }
        }
    }

    private int summaryRow(Sheet sheet, int rowNo, String key, String value) {
        Row row = sheet.createRow(rowNo);
        row.createCell(0).setCellValue(key);
        row.createCell(1).setCellValue(value);
        return rowNo + 1;
    }

    private void zipScreenshots(Path screenshotsDir, Path output) throws Exception {
        if (!Files.exists(screenshotsDir)) {
            Files.createFile(output);
            return;
        }
        try (ZipOutputStream zos = new ZipOutputStream(Files.newOutputStream(output));
             Stream<Path> paths = Files.walk(screenshotsDir)) {
            paths.filter(Files::isRegularFile).forEach(path -> {
                try {
                    zos.putNextEntry(new ZipEntry(screenshotsDir.relativize(path).toString().replace("\\", "/")));
                    Files.copy(path, zos);
                    zos.closeEntry();
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            });
        }
    }
}
