package com.llmart.llm.model;

public class RunConfig {
    private String runId;
    private String llmBaseUrl;
    private String llmApiKey;
    private String llmModel;
    private String appBaseUrl;
    private String vibiumBinaryPath;
    private String chromeBinaryPath;
    private String chromeDriverPath;
    private String browserMode = "VIBIUM_MANAGED";
    private String remoteDebugUrl;
    private Integer remoteDebugPort;
    private boolean headless;
    private boolean useLlm;
    private boolean continueOnFailure;
    private String screenshotMode = "FAILURE_ONLY"; // ALL, FAILURE_ONLY, NONE
    private int stepTimeoutSeconds = 6;
    private int retryCount = 2;
    private int retryDelayMs = 700;
    private int slowMoMs = 0;
    private boolean smartFallback = true;

    public String getRunId() { return runId; }
    public void setRunId(String runId) { this.runId = runId; }
    public String getLlmBaseUrl() { return llmBaseUrl; }
    public void setLlmBaseUrl(String llmBaseUrl) { this.llmBaseUrl = llmBaseUrl; }
    public String getLlmApiKey() { return llmApiKey; }
    public void setLlmApiKey(String llmApiKey) { this.llmApiKey = llmApiKey; }
    public String getLlmModel() { return llmModel; }
    public void setLlmModel(String llmModel) { this.llmModel = llmModel; }
    public String getAppBaseUrl() { return appBaseUrl; }
    public void setAppBaseUrl(String appBaseUrl) { this.appBaseUrl = appBaseUrl; }
    public String getVibiumBinaryPath() { return vibiumBinaryPath; }
    public void setVibiumBinaryPath(String vibiumBinaryPath) { this.vibiumBinaryPath = vibiumBinaryPath; }
    public String getChromeBinaryPath() { return chromeBinaryPath; }
    public void setChromeBinaryPath(String chromeBinaryPath) { this.chromeBinaryPath = chromeBinaryPath; }
    public String getChromeDriverPath() { return chromeDriverPath; }
    public void setChromeDriverPath(String chromeDriverPath) { this.chromeDriverPath = chromeDriverPath; }
    public String getBrowserMode() { return browserMode; }
    public void setBrowserMode(String browserMode) { this.browserMode = browserMode; }
    public String getRemoteDebugUrl() { return remoteDebugUrl; }
    public void setRemoteDebugUrl(String remoteDebugUrl) { this.remoteDebugUrl = remoteDebugUrl; }
    public Integer getRemoteDebugPort() { return remoteDebugPort; }
    public void setRemoteDebugPort(Integer remoteDebugPort) { this.remoteDebugPort = remoteDebugPort; }
    public boolean isHeadless() { return headless; }
    public void setHeadless(boolean headless) { this.headless = headless; }
    public boolean isUseLlm() { return useLlm; }
    public void setUseLlm(boolean useLlm) { this.useLlm = useLlm; }
    public boolean isContinueOnFailure() { return continueOnFailure; }
    public void setContinueOnFailure(boolean continueOnFailure) { this.continueOnFailure = continueOnFailure; }
    public String getScreenshotMode() { return screenshotMode; }
    public void setScreenshotMode(String screenshotMode) { this.screenshotMode = screenshotMode; }
    public int getStepTimeoutSeconds() { return stepTimeoutSeconds; }
    public void setStepTimeoutSeconds(int stepTimeoutSeconds) { this.stepTimeoutSeconds = stepTimeoutSeconds; }
    public int getRetryCount() { return retryCount; }
    public void setRetryCount(int retryCount) { this.retryCount = retryCount; }
    public int getRetryDelayMs() { return retryDelayMs; }
    public void setRetryDelayMs(int retryDelayMs) { this.retryDelayMs = retryDelayMs; }
    public int getSlowMoMs() { return slowMoMs; }
    public void setSlowMoMs(int slowMoMs) { this.slowMoMs = slowMoMs; }
    public boolean isSmartFallback() { return smartFallback; }
    public void setSmartFallback(boolean smartFallback) { this.smartFallback = smartFallback; }
}
