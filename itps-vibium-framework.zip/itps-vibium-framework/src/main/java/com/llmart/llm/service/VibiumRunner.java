package com.llmart.llm.service;

import com.llmart.llm.model.*;
import com.vibium.Browser;
import com.vibium.Element;
import com.vibium.Page;
import com.vibium.Vibium;
import com.vibium.types.SelectorOptions;
import com.vibium.types.StartOptions;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.net.URI;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.time.Instant;
import java.util.Locale;
import java.util.function.BooleanSupplier;

@Service
public class VibiumRunner {
    private final ActionPlanner actionPlanner;
    private final ReportService reportService;
    private final Path outputRoot;

    public VibiumRunner(ActionPlanner actionPlanner,
                        ReportService reportService,
                        @Value("${runner.output-dir:target/vibium-test-runs}") String outputDir) {
        this.actionPlanner = actionPlanner;
        this.reportService = reportService;
        this.outputRoot = Path.of(outputDir);
    }

    public RunStatus execute(java.util.List<TestScenario> scenarios, RunConfig config, RunStatus status) {
        status.setStatus("RUNNING");
        status.setStartedAt(Instant.now());
        status.setTotal(scenarios.size());

        Browser browser = null;
        Path runDir = outputRoot.resolve(config.getRunId());
        Path screenshotsDir = runDir.resolve("screenshots");

        try {
            Files.createDirectories(screenshotsDir);

            StartOptions options = new StartOptions().headless(config.isHeadless());
            if (config.getVibiumBinaryPath() != null && !config.getVibiumBinaryPath().isBlank()) {
                options.executablePath(config.getVibiumBinaryPath().trim());
            }

            String browserMode = config.getBrowserMode() == null ? "VIBIUM_MANAGED" : config.getBrowserMode().trim();
            if ("REMOTE_BIDI_CONNECT".equalsIgnoreCase(browserMode) || "REMOTE_CONNECT".equalsIgnoreCase(browserMode)) {
                String connectUrl = config.getRemoteDebugUrl() == null ? "" : config.getRemoteDebugUrl().trim();
                if (!connectUrl.startsWith("ws://") && !connectUrl.startsWith("wss://")) {
                    throw new IllegalArgumentException("Remote WebDriver BiDi URL must start with ws:// or wss://");
                }
                options.connectURL(connectUrl);
                status.setMessage("ITPS VIBIUM running in Remote WebDriver BiDi mode.");
            } else {
                status.setMessage("ITPS VIBIUM running in managed Chrome for Testing mode. Browser/driver config is intentionally hidden from UI for production use.");
            }

            browser = Vibium.start(options);
            Page page = browser.page();

            for (TestScenario scenario : scenarios) {
                ScenarioResult scenarioResult = runScenario(page, scenario, config, screenshotsDir);
                status.getScenarios().add(scenarioResult);
                if ("PASSED".equals(scenarioResult.getStatus())) {
                    status.setPassed(status.getPassed() + 1);
                } else {
                    status.setFailed(status.getFailed() + 1);
                    if (!config.isContinueOnFailure()) break;
                }
            }
            status.setStatus(status.getFailed() == 0 ? "PASSED" : "COMPLETED_WITH_FAILURES");
        } catch (Exception e) {
            status.setStatus("FAILED");
            status.setMessage(e.getMessage());
        } finally {
            if (browser != null) {
                try { browser.stop(); } catch (Exception ignored) { }
            }
            status.setFinishedAt(Instant.now());
            try {
                reportService.writeAll(status, runDir);
            } catch (Exception e) {
                status.setMessage((status.getMessage() == null ? "" : status.getMessage() + " | ") + "Report write failed: " + e.getMessage());
            }
        }
        return status;
    }

    private ScenarioResult runScenario(Page page, TestScenario scenario, RunConfig config, Path screenshotsDir) {
        Instant started = Instant.now();
        ScenarioResult result = new ScenarioResult();
        result.setId(scenario.getId());
        result.setName(scenario.getName());
        result.setUrl(resolveUrl(scenario.getUrl(), config.getAppBaseUrl()));
        result.setStatus("RUNNING");

        try {
            if (result.getUrl() != null && !result.getUrl().isBlank()) {
                page.go(result.getUrl());
                safeWaitForLoad(page);
            }
            int stepNo = 1;
            for (String step : scenario.getSteps()) {
                StepResult stepResult = runStep(page, scenario, stepNo, step, config, screenshotsDir);
                result.getSteps().add(stepResult);
                if (!"PASSED".equals(stepResult.getStatus())) {
                    result.setStatus("FAILED");
                    result.setErrorMessage(stepResult.getErrorMessage());
                    if (!config.isContinueOnFailure()) break;
                }
                stepNo++;
            }
            if (!"FAILED".equals(result.getStatus())) {
                if (scenario.getExpected() != null && !scenario.getExpected().isBlank()) {
                    assertText(page, scenario.getExpected(), config);
                }
                result.setStatus("PASSED");
            }
        } catch (Exception e) {
            result.setStatus("FAILED");
            result.setErrorMessage(e.getMessage());
        } finally {
            result.setDurationMs(Duration.between(started, Instant.now()).toMillis());
        }
        return result;
    }

    private StepResult runStep(Page page, TestScenario scenario, int stepNo, String step, RunConfig config, Path screenshotsDir) {
        Instant started = Instant.now();
        StepResult result = new StepResult();
        result.setStepNo(stepNo);
        result.setInstruction(step);
        try {
            String snapshot = needsSnapshot(step, config) ? pageSnapshot(page) : "[]";
            AgentAction action = actionPlanner.plan(scenario, stepNo, step, safeUrl(page), safeTitle(page), snapshot, config);
            result.setActionJson(actionPlanner.toJson(action));
            executeWithRetry(page, scenario, action, config);
            result.setStatus("PASSED");
        } catch (Exception e) {
            result.setStatus("FAILED");
            result.setErrorMessage(e.getMessage());
        } finally {
            result.setDurationMs(Duration.between(started, Instant.now()).toMillis());
            if (shouldCapture(config, result.getStatus())) {
                result.setScreenshot(captureScreenshot(page, screenshotsDir, scenario.getId(), stepNo, result.getStatus()));
            }
        }
        return result;
    }

    private boolean needsSnapshot(String step, RunConfig config) {
        if (!config.isUseLlm()) return false;
        String s = step == null ? "" : step.trim();
        return !(s.startsWith("{") && s.endsWith("}"));
    }

    private boolean shouldCapture(RunConfig config, String stepStatus) {
        String mode = config.getScreenshotMode() == null ? "FAILURE_ONLY" : config.getScreenshotMode().toUpperCase(Locale.ROOT);
        if ("NONE".equals(mode)) return false;
        if ("ALL".equals(mode)) return true;
        return "FAILED".equals(stepStatus);
    }

    private void executeWithRetry(Page page, TestScenario scenario, AgentAction action, RunConfig config) throws Exception {
        int attempts = Math.max(1, config.getRetryCount() + 1);
        Exception last = null;
        for (int i = 1; i <= attempts; i++) {
            try {
                executeAction(page, scenario, action, config);
                if (config.getSlowMoMs() > 0) page.sleep(config.getSlowMoMs());
                return;
            } catch (Exception e) {
                last = e;
                if (i < attempts) {
                    page.sleep(config.getRetryDelayMs());
                }
            }
        }
        throw last == null ? new IllegalStateException("Action failed") : last;
    }

    private void executeAction(Page page, TestScenario scenario, AgentAction action, RunConfig config) throws Exception {
        String name = action.getAction() == null ? "" : action.getAction().trim().toUpperCase(Locale.ROOT);
        switch (name) {
            case "NAVIGATE", "OPEN", "GO" -> {
                String target = firstNonBlank(action.getTarget(), action.getValue(), scenario.getUrl(), config.getAppBaseUrl());
                page.go(resolveUrl(target, config.getAppBaseUrl()));
                safeWaitForLoad(page);
            }
            case "CLICK", "TAP" -> smartClick(page, action, config);
            case "DOUBLE_CLICK", "DBLCLICK" -> jsMouseAction(page, action.getTarget(), "dblclick", config);
            case "RIGHT_CLICK", "CONTEXT_CLICK" -> jsMouseAction(page, action.getTarget(), "contextmenu", config);
            case "FILL", "SET" -> smartFill(page, action, config);
            case "TYPE" -> smartType(page, action, config);
            case "CLEAR" -> {
                AgentAction clear = AgentAction.of("FILL", action.getSelectorType(), action.getTarget(), "");
                smartFill(page, clear, config);
            }
            case "PRESS", "KEY" -> {
                String key = firstNonBlank(action.getKey(), action.getValue(), "Enter");
                if (action.getTarget() != null && !action.getTarget().isBlank()) {
                    findElement(page, action, config).press(key);
                } else {
                    page.keyboard().press(key);
                }
            }
            case "SELECT", "SELECT_OPTION" -> smartSelect(page, action, config);
            case "CHECK" -> smartCheck(page, action, true, config);
            case "UNCHECK" -> smartCheck(page, action, false, config);
            case "ASSERT_TEXT", "VERIFY_TEXT", "WAIT_FOR_TEXT" -> assertText(page, firstNonBlank(action.getValue(), action.getTarget(), scenario.getExpected()), config);
            case "ASSERT_NOT_TEXT" -> assertNotText(page, firstNonBlank(action.getValue(), action.getTarget()), config);
            case "ASSERT_VISIBLE", "VERIFY_VISIBLE", "WAIT_FOR_VISIBLE" -> assertVisible(page, action, config);
            case "ASSERT_URL" -> assertUrl(page, firstNonBlank(action.getValue(), action.getTarget()), config);
            case "ASSERT_TITLE" -> assertTitle(page, firstNonBlank(action.getValue(), action.getTarget()), config);
            case "WAIT" -> page.sleep(((action.getSeconds() == null ? 1 : action.getSeconds()) * 1000L));
            case "SCROLL_TO" -> jsScrollTo(page, action.getTarget());
            case "SCROLL" -> page.evaluate("window.scrollBy(0," + firstNonBlank(action.getValue(), "600") + ")");
            case "HOVER", "MOUSE_OVER" -> jsMouseAction(page, action.getTarget(), "mouseover", config);
            default -> throw new IllegalArgumentException("Unsupported action: " + action.getAction() + ". Supported actions include NAVIGATE, CLICK, FILL, TYPE, CLEAR, PRESS, SELECT, CHECK, UNCHECK, ASSERT_TEXT, ASSERT_VISIBLE, ASSERT_URL, ASSERT_TITLE, WAIT, SCROLL_TO, HOVER.");
        }
    }

    private void smartClick(Page page, AgentAction action, RunConfig config) throws Exception {
        String selectorType = safeLower(action.getSelectorType());
        String target = trim(action.getTarget());
        if (config.isSmartFallback() && (selectorType.isBlank() || "auto".equals(selectorType))) {
            if (waitUntil(() -> jsSmartClick(page, target), config)) return;
        }
        try {
            findElement(page, action, config).click();
        } catch (Exception vibiumClickError) {
            if (config.isSmartFallback() && waitUntil(() -> jsSmartClick(page, target), config)) return;
            throw new IllegalStateException("Unable to click target '" + target + "'. Vibium click error: " + vibiumClickError.getMessage());
        }
    }

    private void smartFill(Page page, AgentAction action, RunConfig config) throws Exception {
        String value = nullToEmpty(action.getValue());
        try {
            findElement(page, action, config).fill(value);
        } catch (Exception vibiumFillError) {
            if (config.isSmartFallback() && waitUntil(() -> jsSmartFill(page, action.getTarget(), value), config)) return;
            throw new IllegalStateException("Unable to fill field '" + action.getTarget() + "'. Vibium fill error: " + vibiumFillError.getMessage());
        }
    }

    private void smartType(Page page, AgentAction action, RunConfig config) throws Exception {
        String value = nullToEmpty(action.getValue());
        try {
            findElement(page, action, config).type(value);
        } catch (Exception vibiumTypeError) {
            if (config.isSmartFallback() && waitUntil(() -> jsSmartFill(page, action.getTarget(), value), config)) return;
            throw new IllegalStateException("Unable to type into field '" + action.getTarget() + "'. Vibium type error: " + vibiumTypeError.getMessage());
        }
    }

    private void smartSelect(Page page, AgentAction action, RunConfig config) throws Exception {
        String value = nullToEmpty(action.getValue());
        try {
            findElement(page, action, config).selectOption(value);
        } catch (Exception vibiumSelectError) {
            if (config.isSmartFallback() && waitUntil(() -> jsSmartSelect(page, action.getTarget(), value), config)) return;
            throw new IllegalStateException("Unable to select value '" + value + "' in '" + action.getTarget() + "'. Vibium select error: " + vibiumSelectError.getMessage());
        }
    }

    private void smartCheck(Page page, AgentAction action, boolean checked, RunConfig config) throws Exception {
        try {
            Element el = findElement(page, action, config);
            if (checked) el.check(); else el.uncheck();
        } catch (Exception vibiumCheckError) {
            if (config.isSmartFallback() && waitUntil(() -> jsSmartCheck(page, action.getTarget(), checked), config)) return;
            throw new IllegalStateException("Unable to " + (checked ? "check" : "uncheck") + " '" + action.getTarget() + "'. Vibium error: " + vibiumCheckError.getMessage());
        }
    }

    private void assertText(Page page, String expected, RunConfig config) throws Exception {
        String target = nullToEmpty(expected);
        boolean found = waitUntil(() -> pageText(page).toLowerCase(Locale.ROOT).contains(target.toLowerCase(Locale.ROOT)), config);
        if (!found) throw new IllegalStateException("Text not found on page: " + target);
    }

    private void assertNotText(Page page, String notExpected, RunConfig config) throws Exception {
        String target = nullToEmpty(notExpected);
        boolean gone = waitUntil(() -> !pageText(page).toLowerCase(Locale.ROOT).contains(target.toLowerCase(Locale.ROOT)), config);
        if (!gone) throw new IllegalStateException("Unexpected text is still visible on page: " + target);
    }

    private void assertVisible(Page page, AgentAction action, RunConfig config) throws Exception {
        try {
            findElement(page, action, config);
        } catch (Exception vibiumFindError) {
            if (config.isSmartFallback() && waitUntil(() -> jsExistsVisible(page, action.getTarget()), config)) return;
            throw new IllegalStateException("Element not visible: " + action.getTarget() + ". Vibium error: " + vibiumFindError.getMessage());
        }
    }

    private void assertUrl(Page page, String expected, RunConfig config) throws Exception {
        String target = nullToEmpty(expected).toLowerCase(Locale.ROOT);
        boolean found = waitUntil(() -> safeUrl(page).toLowerCase(Locale.ROOT).contains(target), config);
        if (!found) throw new IllegalStateException("URL did not contain: " + expected + ". Current URL: " + safeUrl(page));
    }

    private void assertTitle(Page page, String expected, RunConfig config) throws Exception {
        String target = nullToEmpty(expected).toLowerCase(Locale.ROOT);
        boolean found = waitUntil(() -> safeTitle(page).toLowerCase(Locale.ROOT).contains(target), config);
        if (!found) throw new IllegalStateException("Title did not contain: " + expected + ". Current title: " + safeTitle(page));
    }

    private boolean waitUntil(BooleanSupplier supplier, RunConfig config) {
        long timeoutMs = Math.max(2, config.getStepTimeoutSeconds()) * 1000L;
        long end = System.currentTimeMillis() + timeoutMs;
        while (System.currentTimeMillis() <= end) {
            try {
                if (supplier.getAsBoolean()) return true;
            } catch (Exception ignored) { }
            try { Thread.sleep(200); } catch (InterruptedException ie) {
                Thread.currentThread().interrupt();
                return false;
            }
        }
        return false;
    }

    private Element findElement(Page page, AgentAction action, RunConfig config) {
        String selectorType = action.getSelectorType() == null ? "auto" : action.getSelectorType().trim().toLowerCase(Locale.ROOT);
        String target = action.getTarget() == null ? "" : action.getTarget().trim();
        long timeoutMs = Math.max(2, config.getStepTimeoutSeconds()) * 1000L;
        if (selectorType.equals("css")) return page.find(target);
        if (selectorType.equals("auto")) return findAuto(page, target, timeoutMs);

        SelectorOptions options = new SelectorOptions().timeout(timeoutMs);
        switch (selectorType) {
            case "label" -> options.label(target);
            case "placeholder" -> options.placeholder(target);
            case "role" -> applyRole(options, target);
            case "title" -> options.title(target);
            case "testid", "data-testid", "data-test" -> options.testid(target);
            case "xpath" -> options.xpath(target);
            case "text" -> options.text(target);
            default -> options.text(target);
        }
        return page.find(options);
    }

    private Element findAuto(Page page, String target, long timeoutMs) {
        if (looksLikeXpath(target)) return page.find(new SelectorOptions().timeout(timeoutMs).xpath(target));
        if (looksLikeCss(target)) {
            try { return page.find(target); } catch (Exception ignored) { }
        }
        Exception last = null;
        for (String type : new String[]{"testid", "label", "placeholder", "title", "text"}) {
            try {
                SelectorOptions options = new SelectorOptions().timeout(Math.min(timeoutMs, 2500L));
                switch (type) {
                    case "testid" -> options.testid(target);
                    case "label" -> options.label(target);
                    case "placeholder" -> options.placeholder(target);
                    case "title" -> options.title(target);
                    default -> options.text(target);
                }
                return page.find(options);
            } catch (Exception e) {
                last = e;
            }
        }
        if (last instanceof RuntimeException re) throw re;
        throw new IllegalStateException("Unable to find element: " + target);
    }

    private void applyRole(SelectorOptions options, String target) {
        if (target.contains(":")) {
            String[] parts = target.split(":", 2);
            options.role(parts[0].trim());
            if (!parts[1].trim().isBlank()) options.text(parts[1].trim());
        } else {
            options.role(target);
        }
    }

    private boolean jsSmartClick(Page page, String target) {
        try {
            Object result = page.evaluate(SMART_CLICK_SCRIPT.replace("__TARGET__", jsQuote(target)));
            return Boolean.parseBoolean(String.valueOf(result));
        } catch (Exception e) { return false; }
    }

    private boolean jsSmartFill(Page page, String target, String value) {
        try {
            Object result = page.evaluate(SMART_FILL_SCRIPT.replace("__TARGET__", jsQuote(target)).replace("__VALUE__", jsQuote(value)));
            return Boolean.parseBoolean(String.valueOf(result));
        } catch (Exception e) { return false; }
    }

    private boolean jsSmartSelect(Page page, String target, String value) {
        try {
            String script = BASE_LOCATOR_JS + """
                const el = findBest(__TARGET__, 'select');
                if (!el) return false;
                const wanted = (__VALUE__ || '').toLowerCase();
                const options = Array.from(el.options || []);
                const match = options.find(o => (o.value || '').toLowerCase() === wanted)
                    || options.find(o => (o.text || '').toLowerCase() === wanted)
                    || options.find(o => (o.text || '').toLowerCase().includes(wanted));
                if (!match) return false;
                el.value = match.value;
                fire(el); return true;
            })()
            """;
            Object result = page.evaluate(script.replace("__TARGET__", jsQuote(target)).replace("__VALUE__", jsQuote(value)));
            return Boolean.parseBoolean(String.valueOf(result));
        } catch (Exception e) { return false; }
    }

    private boolean jsSmartCheck(Page page, String target, boolean checked) {
        try {
            String script = BASE_LOCATOR_JS + """
                const el = findBest(__TARGET__, 'check');
                if (!el) return false;
                el.checked = __CHECKED__;
                fire(el); return true;
            })()
            """;
            Object result = page.evaluate(script.replace("__TARGET__", jsQuote(target)).replace("__CHECKED__", checked ? "true" : "false"));
            return Boolean.parseBoolean(String.valueOf(result));
        } catch (Exception e) { return false; }
    }

    private boolean jsExistsVisible(Page page, String target) {
        try {
            String script = BASE_LOCATOR_JS + "return !!findBest(__TARGET__, 'any'); })()";
            Object result = page.evaluate(script.replace("__TARGET__", jsQuote(target)));
            return Boolean.parseBoolean(String.valueOf(result));
        } catch (Exception e) { return false; }
    }

    private void jsMouseAction(Page page, String target, String eventType, RunConfig config) throws Exception {
        boolean done = waitUntil(() -> {
            try {
                String script = BASE_LOCATOR_JS + """
                    const el = findBest(__TARGET__, 'click');
                    if (!el) return false;
                    el.scrollIntoView({block:'center', inline:'center'}); el.focus();
                    el.dispatchEvent(new MouseEvent('__EVENT__', {bubbles:true,cancelable:true,view:window,button:__BUTTON__}));
                    if ('__EVENT__' === 'dblclick') el.dispatchEvent(new MouseEvent('click', {bubbles:true,cancelable:true,view:window}));
                    return true;
                })()
                """;
                script = script.replace("__TARGET__", jsQuote(target)).replace("__EVENT__", eventType).replace("__BUTTON__", "contextmenu".equals(eventType) ? "2" : "0");
                Object result = page.evaluate(script);
                return Boolean.parseBoolean(String.valueOf(result));
            } catch (Exception e) { return false; }
        }, config);
        if (!done) throw new IllegalStateException("Unable to perform mouse action '" + eventType + "' on target: " + target);
    }

    private void jsScrollTo(Page page, String target) throws Exception {
        String script = BASE_LOCATOR_JS + """
            const el = findBest(__TARGET__, 'any');
            if (el) { el.scrollIntoView({block:'center', inline:'center'}); return true; }
            return false;
        })()
        """;
        Object result = page.evaluate(script.replace("__TARGET__", jsQuote(target)));
        if (!Boolean.parseBoolean(String.valueOf(result))) {
            throw new IllegalStateException("Unable to scroll to target: " + target);
        }
    }

    private String captureScreenshot(Page page, Path screenshotsDir, String scenarioId, int stepNo, String status) {
        try {
            String filename = sanitize(scenarioId) + "_step_" + stepNo + "_" + status.toLowerCase(Locale.ROOT) + ".png";
            Path path = screenshotsDir.resolve(filename);
            Files.write(path, page.screenshot());
            return "screenshots/" + filename;
        } catch (Exception ignored) { return null; }
    }

    private String pageSnapshot(Page page) {
        try {
            Object value = page.evaluate("""
                (() => {
                  const norm = s => (s || '').toString().replace(/\\s+/g, ' ').trim();
                  function labelText(el) {
                    let labels = [];
                    if (el.id) document.querySelectorAll(`label[for="${CSS.escape(el.id)}"]`).forEach(l => labels.push(norm(l.innerText || l.textContent)));
                    let parentLabel = el.closest ? el.closest('label') : null;
                    if (parentLabel) labels.push(norm(parentLabel.innerText || parentLabel.textContent));
                    return labels.filter(Boolean).join(' | ');
                  }
                  const controls = Array.from(document.querySelectorAll('input, textarea, select, button, a, [role="button"], [role="textbox"], [contenteditable="true"], [data-test], [data-testid], [aria-label]'))
                    .filter(el => !el.disabled && el.type !== 'hidden' && (() => { const r = el.getBoundingClientRect(); const s = getComputedStyle(el); return r.width > 0 && r.height > 0 && s.visibility !== 'hidden' && s.display !== 'none'; })())
                    .slice(0, 90)
                    .map((el, i) => ({
                      index: i + 1, tag: el.tagName.toLowerCase(), type: el.getAttribute('type') || '', role: el.getAttribute('role') || '',
                      text: norm(el.innerText || el.textContent || el.value), label: labelText(el), placeholder: el.getAttribute('placeholder') || '',
                      name: el.getAttribute('name') || '', id: el.getAttribute('id') || '', aria: el.getAttribute('aria-label') || '',
                      testid: el.getAttribute('data-testid') || el.getAttribute('data-test') || el.getAttribute('data-qa') || el.getAttribute('data-cy') || '',
                      enabled: !el.disabled
                    }));
                  return JSON.stringify(controls);
                })()
                """);
            return value == null ? "[]" : String.valueOf(value);
        } catch (Exception e) { return "[]"; }
    }

    private String pageText(Page page) {
        try {
            Object value = page.evaluate("document.body ? document.body.innerText : ''");
            return value == null ? "" : String.valueOf(value);
        } catch (Exception e) { return page.content(); }
    }

    private void safeWaitForLoad(Page page) { try { page.waitForLoad(); } catch (Exception ignored) { } }
    private String safeUrl(Page page) { try { return page.url(); } catch (Exception e) { return ""; } }
    private String safeTitle(Page page) { try { return page.title(); } catch (Exception e) { return ""; } }

    private String resolveUrl(String url, String baseUrl) {
        if (url == null || url.isBlank()) return firstNonBlank(baseUrl, "about:blank");
        String trimmed = url.trim();
        if (trimmed.startsWith("http://") || trimmed.startsWith("https://") || trimmed.startsWith("about:")) return trimmed;
        if (baseUrl == null || baseUrl.isBlank()) return trimmed;
        return URI.create(baseUrl.endsWith("/") ? baseUrl : baseUrl + "/").resolve(trimmed).toString();
    }

    private String firstNonBlank(String... values) {
        for (String value : values) if (value != null && !value.isBlank()) return value.trim();
        return "";
    }
    private String nullToEmpty(String value) { return value == null ? "" : value; }
    private String trim(String value) { return value == null ? "" : value.trim(); }
    private String safeLower(String value) { return value == null ? "" : value.trim().toLowerCase(Locale.ROOT); }
    private boolean looksLikeXpath(String target) { return target.startsWith("//") || target.startsWith("(//"); }
    private boolean looksLikeCss(String target) { return target.startsWith("#") || target.startsWith(".") || target.startsWith("[") || target.contains("=") || target.contains(">") || target.contains(" "); }

    private String jsQuote(String value) {
        if (value == null) return "\"\"";
        return "\"" + value.replace("\\", "\\\\").replace("\"", "\\\"").replace("\r", "\\r").replace("\n", "\\n").replace("\t", "\\t") + "\"";
    }
    private String sanitize(String value) { return value == null || value.isBlank() ? "scenario" : value.replaceAll("[^a-zA-Z0-9._-]", "_"); }

    private static final String BASE_LOCATOR_JS = """
        (() => {
          const norm = s => (s || '').toString().toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim();
          const compact = s => (s || '').toString().toLowerCase().replace(/[^a-z0-9]+/g, '');
          function visible(el){ if(!el || el.disabled) return false; const st=getComputedStyle(el); if(st.visibility==='hidden'||st.display==='none') return false; const r=el.getBoundingClientRect(); return r.width>0 && r.height>0; }
          function labelText(el){ let labels=[]; if(el.id) document.querySelectorAll(`label[for="${CSS.escape(el.id)}"]`).forEach(l=>labels.push(l.innerText||l.textContent||'')); const p=el.closest?el.closest('label'):null; if(p) labels.push(p.innerText||p.textContent||''); return labels.join(' '); }
          function rawText(el){ return [el.innerText,el.textContent,el.value,el.getAttribute('aria-label'),el.getAttribute('placeholder'),el.getAttribute('name'),el.getAttribute('id'),el.getAttribute('title'),el.getAttribute('data-test'),el.getAttribute('data-testid'),el.getAttribute('data-qa'),el.getAttribute('data-cy'),labelText(el)].filter(Boolean).join(' '); }
          function cssLookup(target){ try { if(target && /^(#|\\.|\\[|input|button|select|textarea|a|\\w+\\[)/.test(target)) { const el = document.querySelector(target); if(visible(el)) return el; } } catch(e){} return null; }
          function score(el,target){ const raw=rawText(el); const text=norm(raw), tc=compact(target), tn=norm(target), ctext=compact(raw); const words=tn.split(' ').filter(Boolean); let s=0; if(!tn) s+=1; if(tn&&text===tn) s+=360; if(tn&&text.includes(tn)) s+=220; if(tc&&ctext.includes(tc)) s+=220; for(const a of ['id','name','value','data-test','data-testid','data-qa','data-cy','aria-label','title','placeholder']){ const v=el.getAttribute(a)||el[a]||''; if(tc&&compact(v)===tc) s+=320; if(tc&&compact(v).includes(tc)) s+=220; } for(const w of words) if(text.includes(w)) s+=30; const tag=el.tagName.toLowerCase(), type=(el.getAttribute('type')||'').toLowerCase(); if(tag==='button'||type==='submit'||el.getAttribute('role')==='button') s+=30; if((tn.includes('password')||tn.includes('pwd'))&&type==='password') s+=180; if((tn.includes('user')||tn.includes('email'))&&['text','email',''].includes(type)) s+=60; return s; }
          function findBest(target,kind){ const css=cssLookup(target); if(css) return css; let selector='input, textarea, select, button, a, [role="button"], [role="textbox"], [contenteditable="true"], [onclick], [data-test], [data-testid], [data-qa], [data-cy], [aria-label]'; if(kind==='select') selector='select'; if(kind==='check') selector='input[type="checkbox"], input[type="radio"], [role="checkbox"], [role="radio"]'; const list=Array.from(document.querySelectorAll(selector)).filter(visible); const ranked=list.map(el=>({el,score:score(el,target)})).sort((a,b)=>b.score-a.score); return ranked[0] && ranked[0].score>0 ? ranked[0].el : null; }
          function fire(el){ el.dispatchEvent(new Event('input',{bubbles:true})); el.dispatchEvent(new Event('change',{bubbles:true})); el.dispatchEvent(new KeyboardEvent('keyup',{bubbles:true})); }
    """;

    private static final String SMART_CLICK_SCRIPT = BASE_LOCATOR_JS + """
          const el = findBest(__TARGET__, 'click');
          if (!el) return false;
          el.scrollIntoView({block:'center', inline:'center'}); el.focus();
          ['mouseover','mousedown','mouseup'].forEach(type => el.dispatchEvent(new MouseEvent(type,{bubbles:true,cancelable:true,view:window})));
          if (typeof el.click === 'function') el.click(); else el.dispatchEvent(new MouseEvent('click',{bubbles:true,cancelable:true,view:window}));
          return true;
        })()
    """;

    private static final String SMART_FILL_SCRIPT = BASE_LOCATOR_JS + """
          const el = findBest(__TARGET__, 'input');
          if (!el) return false;
          el.scrollIntoView({block:'center', inline:'center'}); el.focus();
          if (el.isContentEditable) el.textContent = __VALUE__; else el.value = __VALUE__;
          fire(el); el.blur(); return true;
        })()
    """;
}
