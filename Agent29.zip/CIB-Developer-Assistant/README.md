# CIB Developer Assistant

Java 17 local coding and workspace agent with two interaction modes: **Chat** and **Agent**.

## Primary flow

Agent mode is designed for direct prompt-driven work:

1. Put an existing project or file path in the prompt.
2. The runtime resolves that explicit path as the primary live workspace, even if a different workspace was previously active.
3. Before drafting a plan, the runtime performs deterministic **live workspace evidence collection**: project profile, resolved resources, instructions, file index, key descriptors/build files, and focused task-derived searches.
4. The **same user-selected Agent model** analyses that evidence and creates a structured adaptive plan in one LLM call. The harness then performs deterministic structure/range checks, requires validation evidence for each step, and requires a dedicated final verification step after coherent changes. This avoids cross-model disagreement and reduces planning round trips. The plan editor lets the user edit, reorder, add, remove, or unselect steps before execution.
5. By default execution waits for **Approve plan & run step 1**. Approval locks the edited plan as an execution contract. Exactly one plan step is active at a time: the agent performs real tool work for that step, records step evidence, verifies any code/config mutation, completes the step, and only then unlocks the next step. Retained approved steps cannot be silently skipped, and a run cannot finish successfully while an approved step is incomplete.
6. One configured **Agent model** owns analysis, planning, plan review, coding/tool work, recovery reasoning and final verification for the whole task. Optional fallback models are takeover models only: they inherit the same workspace, approved plan, active step, persisted state and failure memory if the current model cannot continue.
- **Executor-pool recovery replan** replaces only unfinished work after all configured executor models are exhausted, while preserving completed steps and valid edits. Recovery can fetch missing concrete workspace evidence instead of treating an inspect/confirm request as a terminal failure.
7. The agent inspects targeted files, batches independent reads, edits the live workspace, executes the smallest useful build/test/check, repairs failures, and stops once the requested result is verified. Additional prompt paths are exposed as named resources with safe read/write roles.
8. A durable run record drives the progress bar and final completion state, so a stale SSE connection does not leave the UI waiting for a manual Stop click.

If a follow-up Agent prompt has no path, the current live workspace can be reused. If a new explicit path is supplied, that prompt path is authoritative and switches the active workspace.

## Long-running context management

The runtime uses a compact active context rather than resending the full historical transcript on every model call:

- proactive token estimation before each model call
- tool-schema tokens included in the estimate
- adaptive compaction based on usable input limit minus dynamic headroom; no fixed percentage trigger
- deterministic durable continuation checkpoints for most compactions
- periodic semantic checkpoint summarization (and forced-overflow summarization) instead of paying for a summary model call every time
- recent context tail retained after compaction
- only the two newest tool observations get the larger fresh-output allowance; older tool output is aggressively bounded
- superseded runtime recovery/verification/failover steering is removed instead of being resent for hundreds of turns
- Agent-mode **active model context** is deliberately bounded because the live workspace, approved plan, and run state are authoritative; persisted chat messages are not deleted by compaction
- provider input/output/cache usage captured when returned
- context-overflow recovery with one forced compaction attempt
- configurable adaptive non-actionable recovery attempts **per model** (default 10)
- configurable transient provider retries **per model** (default 10) before moving to the next configured fallback
- immediate model failover for explicit unavailable/unknown/unsupported-model errors instead of wasting the retry budget
- model failover preserves the approved plan, current step, workspace revisions, and durable run state
- repeated identical no-progress tool/model outcomes suppressed and redirected to a materially different strategy

Defaults are configurable in Settings. The default recent-context target is 8k tokens, the safety buffer is 20k tokens, and older tool observations default to a 1,200-character active-context cap. Context limits are resolved per active Agent/fallback model. Workspace retrieval uses the local lexical index and bounded current-file evidence; no secondary embedding model is required. The retrieval cache is invalidated after detected workspace mutations so recovery/planning cannot keep discovering against a stale pre-edit index. Durable objective/plan/model/verification/touched-file state is stored outside the active transcript and re-injected as a small suffix.

## Speed and quality controls

The Agent protocol emphasizes high-signal work rather than activity for its own sake:

- independent read/search calls are batched in one model turn and executed in parallel when safe
- targeted grep/index/range reads are preferred over broad recursive file dumps
- unchanged files should not be re-read without a reason
- exploratory subagents can use fresh context for independent investigation
- edits are no-op aware, avoiding synthetic revisions when content already matches
- verification is revision-aware and only a real changed revision requires a new verifier
- the smallest verifier that proves the requested change is preferred before broader suites
- successful verification can trigger a dedicated **active-step completion critic**; the normal workflow defers compile/test/check/run until the final verification step after coherent edits, while the critic can still advance a verified step when an explicit/intermediate verifier was genuinely required
- after all approved steps complete, successful verification triggers a separate original-request completion check instead of open-ended extra investigation
- transient provider retries are bounded and cancellable
- foreground commands use process pipes rather than temporary output files, avoiding Windows log-file sharing locks
- common provider tool-name/schema drift is repaired at the runtime boundary (`search`→`grep`, noisy `read/<channel>...` names, `query`→`pattern`, OpenAI-style patch text) instead of wasting retries
- stale exact-text edits explain that the file changed and direct the model to re-read current text before retrying

## Agent progress

The Agent run view keeps the progress bar synchronized with the approved plan. During execution the percentage is derived from **completed approved plan steps**, while tool activity updates the phase/detail without jumping the percentage ahead. Completed steps retain compact tool evidence that can be expanded while later steps are still running. A blocked/failed/cancelled/interrupted run keeps the percentage reached at the point it stopped; only successful completion becomes 100%, so a terminal error is no longer visually confused with success.

Activity events are displayed separately from planned steps. The browser retains only a bounded recent activity window and throttles Agent-card rendering, preventing long runs with hundreds of tool/model events from repeatedly rebuilding the full conversation DOM. The terminal state becomes 100% only after a successfully completed durable final response; blocked/failed/cancelled states remain below 100% and show their terminal phase explicitly.

Foreground shell/build/test output is also bounded in memory: small output is kept exactly, while very large output keeps the beginning and latest tail with an explicit truncation marker. Long-running foreground commands publish periodic activity heartbeats without advancing plan-derived progress, so Maven/Playwright/test runs do not appear frozen while they are still executing.

## UI

The main UI intentionally contains only **Chat** and **Agent** modes. Workspace selection is not a sidebar workflow; supply filesystem paths in Agent prompts.

Settings use a deliberately simpler model contract: **one Chat model**, **one Agent model**, and an ordered Agent fallback list. Chat can use a vision-capable model for images. Agent accepts only Chat / Agent model entries and uses the selected Agent model for the complete workflow; there are no hidden analysis/planner/validator/critic model assignments. The editable model library supports adding, testing, renaming and removing models plus context-window metadata. User-message editing uses a large responsive editor for long prompts. The sidebar also includes a **Prompt library** with reusable automation/development prompts. In Agent mode the model strip shows the selected Agent model and fallback count only.

## Chat image workflow

Images are intentionally handled in **Chat mode**, not inside the autonomous Agent loop. When an image is attached, select a vision-capable Chat model (for example a configured multimodal model), analyse the screenshot/image in Chat, and then give Agent the resulting textual findings together with the coding task or project path. Agent remains focused on repository evidence, planning, tool execution and verification. This avoids hidden vision-model calls and keeps image-model selection under the user’s control.

## Durable history and portable startup

The application JAR can still be copied and started from any folder:

```bat
java -jar advanced-ai-workbench.jar
```

Conversation history and durable Agent-run state are now stored independently from the extracted/JAR directory so replacing the application folder does not make old chats appear to disappear. The default per-user location is:

```text
Windows: %USERPROFILE%\.advanced-ai-workbench\
Linux/macOS: ~/.advanced-ai-workbench/
  data/
    chatdb.mv.db
    uploads/
    agent-cache/
    agent-runs/
  cache/
  logs/
```

On first use, if the old beside-JAR `data/` directory contains history and the new durable database does not yet exist, the runtime performs a best-effort non-overwriting migration. All locations remain overridable through the existing system properties such as `app.data-dir` and `advanced.ai.agentRunStore`.

## Build and run

Requirements:

- Java 17 or later
- Maven, or network access for the included Maven bootstrap script on first use

Windows:

```bat
validate-local.bat
run.bat
```

Linux/macOS:

```bash
./validate-local.sh
./run.sh
```

Normal `mvn install` / validation uses the release profile behavior and is **not blocked by optional environment-sensitive tests**. To run the complete test suite explicitly:

```bash
./mvnw -Pfull-tests test
```

On Windows use `mvnw.cmd -Pfull-tests test`.

The packaged JAR name is:

```text
target/advanced-ai-workbench.jar
```

## Example Agent prompts

```text
Project path: C:\work\payments-ui
Fix the failing login flow shown in the console error below. Inspect the project, implement the smallest correct fix, run the relevant tests, repair any failures, and stop as soon as the requested change is verified.
```

```text
Primary project: C:\work\new-playwright
Reference project: C:\work\old-selenium
Recorded flow: C:\work\recordings\payment.json
Use the Selenium project and recording as reference only. Implement the equivalent flow in the primary project, run it, fix failures, and verify the final result.
```

See the **Sample Prompts** section later in this README for more examples.

---

# Consolidated Documentation

All project documentation that was previously split across multiple Markdown files is consolidated below. This package intentionally contains **only one Markdown file: `README.md`**.

---

## Agent Architecture

### Runtime path

```text
User prompt
   |
   +-- Chat ------------------------------------------------> selected Chat model
   |                                                         +-- images allowed only when that Chat model is vision-capable
   |
   +-- Agent
        |
        +-- resolve live workspace + instructions/resources
        +-- local lexical index + focused live-file evidence bundle
        +-- SAME selected Agent model analyses evidence and creates structured plan
        +-- deterministic plan structure/verification checks
        +-- user edits/reorders/approves plan
        +-- SAME Agent model executes one approved step at a time
        |      +-- authoritative file reads/evidence injected for active step
        |      +-- edit/run/build/test/check
        |      +-- context overflow -> checkpoint/compact -> retry same model
        |      +-- repeated/no-progress failure -> configured fallback takeover
        |      +-- fallback inherits same step, diff, evidence and failure memory
        |      +-- all fallbacks exhausted -> bounded recovery replan of unfinished work
        +-- verification + completion gate
        +-- durable final result/history/progress
```

The Agent model contract is intentionally simple: one selected **Chat / Agent** model owns the whole Agent workflow. The Settings model library still allows adding, testing, renaming, editing context/type and removing models. Ordered fallbacks are takeover models only. Image analysis is user-selected in Chat mode and is intentionally kept outside the autonomous Agent loop.

### Executor-pool exhaustion recovery

Executor fallbacks are not simple task restarts. Each fallback inherits the approved objective, completed plan steps, active step, live workspace, current diff, verifier state, retrieval hints and prior failure evidence. If every configured executor is exhausted, the harness invokes a bounded second-order recovery path instead of immediately giving up:

1. the Analysis role diagnoses whether the failure is recoverable or a genuine external/environment/credential blocker;
2. for recoverable failures, the Planning role rewrites only the unfinished portion of the approved plan;
3. the independent Plan Validator rejects repeated/ungrounded recovery strategies;
4. completed steps and valid current edits remain intact;
5. after validation, the executor model cycle restarts from the configured primary model on the new active recovery step.

Recovery replanning is deliberately bounded (two accepted replans per run, with bounded validator revisions) so the agent changes strategy without entering an endless planner/executor loop. Authentication failures are surfaced directly rather than wasting the fallback chain. Recovery state and diagnosis are durable and are restored with conversation history.

### Context lifecycle

Durable session history is retained separately from the active prompt sent to the model. Before a model request, the runtime estimates messages plus tool definitions. When the input is approaching the usable context limit, older history is replaced with a structured checkpoint and a recent tail is retained.

The checkpoint preserves objective, important details, binding user constraints, completed work, active work, blockers, next actions, relevant files, exact paths, verifier state, and key decisions. If semantic summarization fails, a deterministic fallback checkpoint is created so context maintenance cannot strand the run.

### Progress, live status and completion

Run state is independent of the HTTP streaming transport. The backend persists a bounded activity timeline together with the plan, validation result, active model, failover count, verification state and progress. The UI shows stage-level progress (Index → Analyse → Plan → Validate → Review → Execute → Verify → Complete), live activity text, current model and per-step evidence. During an active plan step, real tool activity advances a bounded portion of that step instead of leaving the bar visually frozen or pretending the step is already complete.

The backend persists the final assistant message first and then marks the run response as durable. The browser polls run state while streaming is active. If the durable terminal response exists but the HTTP/SSE stream remains open, the browser closes only the stale transport and immediately returns the composer to Send state.

Conversation reopening treats messages as authoritative and loads attachments, projects and Agent-run metadata independently. Optional old metadata failure therefore cannot prevent an older chat from opening. Persisted Agent activity/plan state is reattached to the corresponding assistant message when available, with an ordered fallback for older records that predate message identifiers/timestamps.

### No-progress protection

Productive work is not restricted by a fixed step ceiling. Instead, guards are tied to actual progress:

- same tool + same args + same normalized result + same workspace revision -> warning, then block
- repeated verifier outcome without a new revision -> change strategy or stop as blocked
- repeated non-actionable model output without tool/workspace progress -> stop
- no-op edits do not create a new workspace revision
- process polling is allowed a small extra repeat window because process output can legitimately remain unchanged briefly

### Workspace authority

An explicit primary path in the current Agent prompt overrides an older active workspace. If the current prompt contains no path, the active workspace may be reused for follow-up work. Additional paths remain separate resources so reference inputs are not accidentally treated as writable primary projects.


### Evidence-first editable planning

Planning is single-model and evidence-first. The runtime gathers bounded read-only repository evidence, including key descriptors/search hits, and the selected Agent model analyses that evidence while producing structured JSON plan steps in one call. The harness checks step count/structure and requires explicit validation evidence on every step; one corrective retry is allowed if the returned structure is incomplete. Exact unproven filenames/methods should be inspected during execution instead of invented during planning.

The draft remains human-editable while approval is pending. The UI formats it as a plan board and can edit, reorder, add, remove and deselect steps through `/api/agent/runs/{id}/plan`. Approval locks the retained plan and starts only step 1.

### Token budget strategy

Active model context is treated as a cache, not durable state. Durable plan/model/workspace/verification state lives in `AgentRunService`. Agent history injection is capped, old tool observations are pruned, generated steering messages are tagged and superseded copies are removed, and compaction uses an adaptive high-water mark derived from the provider-safe input limit minus dynamic headroom rather than a fixed utilization percentage. Cheap deterministic pruning happens first. Most compactions use deterministic checkpoints; semantic compaction is periodic or used for forced overflow recovery. A local lexical workspace index is always available and is the Agent retrieval baseline. The strongest active-step hits are supplemented with bounded current file contents before model calls, so implementation is grounded in the live filesystem without depending on a secondary embedding model.

---

## Token Management

Agent mode now uses a layered context algorithm designed for long-running coding sessions.

### 1. Stable prefix

Static system instructions, project instructions and the original task remain at the front of the request. Changing runtime state is kept at the suffix so providers that support prompt caching can reuse the longest possible unchanged prefix.

### 2. Durable runtime state outside chat history

`AgentRunService` persists the objective, approved plan, active plan step, model/failover state, mutation revision, verification state and recently touched paths. Before each physical model call a single compact runtime-state suffix is regenerated from this durable state.

### 3. Local workspace retrieval index

`WorkspaceRetrievalIndexService` builds a bounded lexical index of source/config/instruction files. It uses the original objective plus the active plan step to rank likely-relevant files and injects a small hint set. It does not use embeddings and does not create another model call.

### 4. Deterministic pruning first

Old/oversized tool observations and superseded runtime steering are bounded before compaction. When the prompt approaches the adaptive high-water mark, pruning becomes more aggressive. Real user-authored messages are not removed by this stage.

### 5. Adaptive compaction threshold

The runtime first calculates the provider-safe input limit:

`inputLimit = contextWindow - max(outputAllowance, safetyBuffer)`

It then reserves dynamic input headroom for the next model/tool turn:

`headroom = clamp(contextWindow / 10, 8k, 24k)`

bounded to at most one quarter of the usable input limit.

Compaction begins when:

`estimatedInput > inputLimit - headroom`

This replaces the previous fixed 68% trigger.

Examples with the default 20k safety buffer and provider-managed output:

- 128k window -> input limit 108k -> adaptive threshold about 95.2k
- 200k window -> input limit 180k -> adaptive threshold about 160k

### 6. Rolling checkpoint + recent tail

Compaction replaces older chronology with a deterministic continuation checkpoint and keeps the recent tail (8k tokens by default). Periodically, or during forced overflow recovery, a small semantic summary call may improve that checkpoint. Compaction is never allowed to strand the run if the summarizer fails.

### 7. Telemetry

Agent progress now exposes provider tokens, current context, compaction count, pruned observation count, estimated active tokens saved, and provider cache-hit percentage when the provider reports cached input tokens.

---

## Agent Resources Guide

The runtime discovers repository instructions automatically. Use `AGENTS.md` for stable repository-wide rules and `.agents/skills/<skill-name>/SKILL.md` for focused repeatable workflows.

### What belongs in AGENTS.md

Keep it short and durable: architecture boundaries, validated build/test commands, required conventions, source-of-truth locations, and non-negotiable safety/quality rules. Avoid incident logs, temporary file names, secrets, and lengthy tutorials.

### What belongs in a skill

A skill should describe one repeatable workflow such as Playwright MCP diagnosis, Selenium-to-Playwright migration, API testing, or release validation. Include when to use it, evidence to inspect, steps, verification, and stop conditions.

### Recommended structure

```text
project/
├── AGENTS.md
└── .agents/
    └── skills/
        ├── playwright-mcp-testing/
        │   └── SKILL.md
        ├── selenium-to-playwright/
        │   └── SKILL.md
        └── framework-quality/
            └── SKILL.md
```

See `examples/agent-resources/` for starter templates. Adapt them to real project evidence rather than copying them blindly.

---

## OpenCode / Modern Coding-Agent Flow Comparison

The application is intentionally aligned with the practical interaction patterns users expect from modern coding agents such as OpenCode and Claude-style coding workflows, while retaining a local Java 17/Spring Boot implementation and explicit runtime safeguards.

| Area | Implemented behavior |
|---|---|
| Prompt-driven workspace | Explicit current-prompt path is authoritative; follow-up work can reuse the active local workspace |
| Single-model harness | One selected Agent model owns analysis, planning, execution and verification; fallbacks are takeover-only. Chat has its own model and image support. |
| Editable model library | Defaults are provided, but users can add, rename, change type/context, remove and assign arbitrary OpenAI-compatible model IDs |
| Executor failover | Ordered fallbacks inherit the same active plan step, live workspace, current diff, verifier state and durable task context rather than restarting the task |
| Executor-pool recovery | After all configured executors fail, the harness can inspect missing evidence and replan unfinished work while preserving completed steps and valid edits; external blockers stop safely |
| Plan-first workflow | Evidence -> analysis -> plan -> independent validation -> formatted human review -> sequential execution |
| Editable plan | User can edit, add, remove and reorder the draft before approval; approved plan becomes a sequential runtime contract |
| Multiple resources | Primary workspace plus separately role-scoped additional paths |
| Parallelism | Independent read/search calls can run concurrently; dependent mutations remain ordered |
| Subagents | Fresh-context delegated investigation with bounded tool protocol |
| MCP / LSP | Lazy MCP tool discovery plus language-server support when configured |
| Tool context | Large observations are bounded and superseded/old outputs are pruned |
| Workspace retrieval | Local lexical index is always available; configured embeddings can semantically rerank the strongest candidates with automatic lexical fallback |
| Durable state | Objective, plan, validation, active model, failovers, verification, touched paths and activity timeline live outside active transcript |
| Conversation resume | Older conversations load messages first; optional run/project/file metadata cannot block the chat, and persisted Agent state is reattached when available |
| Live progress | Stage strip, plan-derived percentage, current activity, model/failover state and per-step evidence update while work is running |
| Compaction | Adaptive reserved-headroom estimate -> deterministic/periodic semantic checkpoint -> recent tail |
| Constraint retention | Binding user constraints are explicitly preserved in checkpoints |
| Verification | Workspace-revision-aware build/test/check evidence before mutation steps can complete |
| No-op edits | Do not create synthetic mutation revisions |
| Loop control | Result-aware repeated-call and non-actionable-turn guards; identical no-progress behavior causes strategy/model change instead of endless repetition |
| Completion | Verified revision -> independent completion critic -> durable final response |
| Transport resilience | Final result is recoverable even if the streaming connection does not close |
| Productive work budget | No fixed ceiling on productive tool actions; bounded recovery limits prevent wasteful loops |

The target is behavioral quality and reliability rather than copying another product line-for-line. Performance work is concentrated on fewer irrelevant reads, hybrid retrieval, parallel safe reads, compact durable state, bounded role prompts, executor handoff without restarting completed steps, and UI rendering that updates incrementally instead of rebuilding the full transcript for every activity event.

---

## Sample Prompts

These prompts are written for the Agent's plan-first workflow. Replace paths, tags, URLs, and business names with your real values. The Agent automatically reads relevant `AGENTS.md` files and `.agents/skills/<name>/SKILL.md` resources when they exist.

### Playwright MCP + Java Selenium/TestNG/Cucumber — Diagnose and Self-Heal a Failing Test

```text
Project path: C:\work\selenium-framework

This is an existing Java + Selenium + TestNG + Cucumber framework. Keep Selenium as the test runner. Use Playwright MCP only as a live-browser diagnostic tool when browser evidence is needed.

First inspect AGENTS.md, relevant .agents/skills/*/SKILL.md files, pom.xml, the Cucumber/TestNG runner, hooks, page objects, step definitions, and workspace MCP configuration. Determine the active Cucumber tag expression from the runner/configuration instead of asking me to repeat it.

Run only the active/affected test scope. If it fails, use the real failure output to identify the first actionable cause. When UI evidence is needed, use Playwright MCP to inspect the live page, DOM/accessibility tree, visibility, frames, overlays, redirects, or locator state. Do not convert the framework to Playwright and do not add Playwright to pom.xml just to use MCP.

Apply the smallest maintainable Selenium/framework fix, rerun the affected tests, and continue the fix-run-verify loop until the current revision passes or a genuine external blocker is proven. Review the final diff.

If this task reveals reusable project conventions that are not already documented, create or update a concise AGENTS.md rule or a focused .agents/skills/<skill-name>/SKILL.md resource for future runs. Do not duplicate temporary debugging facts or secrets.
```

### Java Selenium/TestNG/Cucumber — Add Tests from an Existing Feature or Requirement

```text
Project path: C:\work\selenium-framework

Inspect AGENTS.md and relevant skills first. Understand the existing Cucumber runner, feature organization, glue, hooks, driver lifecycle, page-object/component pattern, test-data pattern, reporting, and Maven execution commands.

Implement automated coverage for this requirement: <paste requirement>.

Reuse the existing framework instead of creating a parallel architecture. Add or update feature scenarios, step definitions, page objects/components, test data, and utilities only where needed. Prefer stable locators and existing abstractions. Keep scenarios business-readable and avoid duplicate steps.

Run the smallest relevant Cucumber/TestNG scope, fix compile/runtime/test failures, then run the appropriate higher-level validation if reasonable. Review the final diff and summarize exactly what was added and verified.

If you discover a reusable testing convention, document it in AGENTS.md or a focused .agents/skills/<name>/SKILL.md only when it will help future tasks.
```

### Playwright MCP — Live Browser Investigation Without Changing the Test Runner

```text
Project path: C:\work\existing-framework
Application URL: <url>

Read AGENTS.md, relevant skills, and .agents/mcp.json first. Confirm the configured Playwright MCP server and use it only for browser investigation.

Reproduce the failing user flow in the live application. Inspect the accessibility/DOM state before and after the failure, including frames, dialogs, overlays, disabled controls, redirects, network-visible error states, and candidate stable locators. Correlate that evidence with the existing test/framework code.

Do not guess selectors from screenshots. Do not migrate or replace the existing runner unless I explicitly ask. Make only evidence-backed code/config changes, run the affected test, and verify the fix on the current workspace revision.

Capture any reusable Playwright MCP investigation procedure as a focused .agents/skills/playwright-mcp-testing/SKILL.md if the project does not already have one.
```

### Playwright — Build or Improve an Existing Playwright Framework

```text
Project path: C:\work\playwright-framework

Inspect AGENTS.md, .agents/skills, package.json, playwright.config.*, fixtures, page/component objects, test-data utilities, reporters, and CI configuration before changing anything.

Improve the framework for this goal: <goal>.

Preserve existing conventions that are sound. Prefer Playwright-native auto-waiting, role/test-id locators, fixtures, isolated test state, trace/video/screenshot artifacts on failure, and parallel-safe test data. Remove redundant sleeps/retries rather than layering more retries on top.

Implement the smallest coherent change set, run lint/typecheck if configured, run the targeted Playwright tests, diagnose real failures, and continue until verified. Review the final diff.

When a pattern will be reused, create/update AGENTS.md or a focused .agents/skills/<name>/SKILL.md with stable rules, commands, and examples—not task-specific history.
```

### Migration — Java Selenium to Playwright TypeScript

```text
Target project: C:\work\playwright-framework
Source reference: C:\work\selenium-framework

Treat the Selenium project as read-only unless I explicitly say otherwise. Inspect AGENTS.md and skills in both projects, then map the source runner, features/tests, page objects, waits, data, authentication/session handling, utilities, tags, reports, and CI behavior to the target Playwright architecture.

Migrate this scope: <feature/module/tag>.

Preserve business behavior and assertions; do not mechanically translate Selenium APIs line by line. Use Playwright-native fixtures, locators, waits, storage/auth state, and parallel-safe design. Reuse existing target conventions before introducing new abstractions.

Migrate incrementally, run the smallest target test scope after each meaningful batch, fix failures, and compare coverage against the source. Do not mark migration complete until the requested source scenarios have an explicit target mapping and the target tests pass or a genuine blocker is documented.

Create/update migration guidance in AGENTS.md and, if useful, .agents/skills/selenium-to-playwright/SKILL.md so later migration batches follow the same rules.
```

### Migration — Java Selenium to Playwright Java

```text
Target project: C:\work\playwright-java
Source reference: C:\work\selenium-framework

Inspect both frameworks and their AGENTS.md / skills before planning. Migrate <scope> from Selenium to Playwright Java while preserving business intent, data, assertions, tags/categories, and CI entry points.

Do not perform API-for-API translation. Replace manual Selenium waits with Playwright waiting semantics, use resilient locators, centralize browser/context lifecycle appropriately, and keep tests parallel-safe. Reuse the target project's patterns.

Run compile plus the targeted migrated tests, fix failures using actual output, review the diff, and provide a source-to-target coverage mapping.

Persist only reusable migration rules in AGENTS.md or .agents/skills/selenium-to-playwright/SKILL.md.
```

### Development — Implement a Feature in an Existing Application

```text
Project path: <path>

Inspect AGENTS.md, relevant skills, project structure, build configuration, and the nearest implementation/tests before planning.

Implement this feature: <requirement>.

Trace the existing architecture and data flow first. Reuse established patterns and public contracts. Keep the change focused, add/update tests for the requested behavior and important edge cases, and avoid unrelated refactoring.

Run the smallest high-signal build/test/check, fix failures caused by the change, then review the final diff. Do not claim completion without real verification.

If the work establishes a stable convention future developers/agents should follow, update AGENTS.md or add a focused skill. Keep those resources concise and reusable.
```

### Development — Diagnose and Fix a Bug

```text
Project path: <path>
Failure/error: <paste error or reproduction>

Read AGENTS.md and relevant skills. Reproduce or trace the failure using the smallest relevant command/test. Identify the first actionable root cause from code and runtime evidence; do not patch symptoms blindly.

Implement the smallest correct fix, add or update a regression test when practical, rerun the failing scope, and review the final diff. Continue until the current revision passes or a proven external blocker remains.

Record only a reusable diagnostic/fix convention in AGENTS.md or a skill if it will prevent repeated future work.
```

### Testing — API Contract and Regression Coverage

```text
Project path: <path>
API/requirement: <details>

Inspect AGENTS.md, relevant skills, existing API client/test utilities, schemas, authentication setup, test-data builders, and CI test commands.

Add focused automated coverage for happy paths, validation, authorization, important boundary values, error contracts, and backward-compatible response fields appropriate to this API. Reuse the existing framework and data patterns.

Execute the targeted suite, fix test or framework issues exposed by the new coverage, and summarize what behavior is now verified. Do not weaken assertions merely to make tests pass.

If reusable API-testing rules emerge, capture them in .agents/skills/api-testing/SKILL.md or AGENTS.md.
```

### Testing — Stabilize a Flaky UI Regression Suite

```text
Project path: <path>
Scope/tag: <scope>

Inspect AGENTS.md, skills, runner configuration, retries, waits, locators, fixtures/hooks, test data, parallel execution, and recent failure artifacts.

Run the smallest representative failing scope and classify each failure by evidence: product defect, locator instability, synchronization, shared state/test data, environment, or framework defect. Fix root causes; do not simply increase sleeps or global retries.

Rerun the affected tests enough to prove the current revision is stable within the available environment, then review the final diff and remaining external risks.

Capture stable anti-flakiness conventions in AGENTS.md or a focused UI-testing skill for future work.
```

### CI/CD — Repair or Optimize the Existing Pipeline

```text
Project path: <path>
Pipeline goal/failure: <details>

Inspect AGENTS.md, skills, build scripts, CI configuration, caching, test splitting, artifacts, environment variables, and the commands developers run locally.

Diagnose the current pipeline from configuration and real logs. Make focused changes that preserve security and reproducibility. Improve speed through safe caching, parallelism, scope selection, and elimination of duplicate work without skipping required quality gates.

Validate configuration syntax and run the closest local checks available. Clearly distinguish verified behavior from CI-only behavior that cannot be executed locally.

Document stable pipeline commands/conventions in AGENTS.md or a CI skill if useful for future agent runs.
```

### Code Review — Refactor Without Behavioral Drift

```text
Project path: <path>
Scope: <files/module>

Inspect AGENTS.md, relevant skills, tests, and callers before editing. Review the scope for correctness risks, duplication, overly complex control flow, error handling, concurrency/resource issues, and maintainability.

Refactor only where the benefit is concrete. Preserve external behavior and public contracts. Add/adjust tests for any behavior that was previously implicit or risky.

Run targeted build/tests/checks and review the final diff. Explain the measurable improvement and any deliberate non-changes.

Update AGENTS.md or a skill only for stable architectural/testing conventions, not opinions specific to this one refactor.
```

### Generic — Analyze a Framework and Create Future Agent Guidance

```text
Project path: <path>

Analyze the repository deeply but make no product-code changes unless needed to validate your findings. Read existing AGENTS.md, CLAUDE.md, .agents/skills, build/test configuration, architecture docs, and representative implementation/tests.

Identify the commands, architecture boundaries, coding/testing conventions, safety constraints, common workflows, and recurring failure patterns that a future coding agent must know.

Create or improve a concise root AGENTS.md and only the focused .agents/skills/<name>/SKILL.md files that materially improve future work. Keep instructions stable, evidence-based, non-duplicative, and free of secrets. Include exact validated commands where available.

Validate that the resources match the repository and do not conflict with existing instructions. Summarize what future tasks these resources improve.
```

---

## User Test Checklist

Use this checklist while testing the packaged build. It focuses on the issues reported for long Agent runs, synchronized plans, history, UI and reusable prompts.

### 1. Plan parsing and progress synchronization

Give the Agent a plan containing numbered steps plus decorative bullets/icons. Approve it.

Expected:
- only real textual steps appear in the approved plan
- decorative symbols do not increase total step count
- progress percentage advances primarily by approved-plan completion, with bounded within-step movement after real tool activity
- live status/phase can change frequently, but the bar never jumps beyond the active approved step

### 2. Strict plan execution

Use a task with at least 5 meaningful plan steps and allow it to edit code.

Expected:
- one active plan step at a time
- retained approved steps are not silently skipped
- implementation steps can complete from real workspace/diff evidence without compiling after every step
- after all coherent requested changes are complete, the final verification step runs the appropriate compile/test/check/execution and must pass before success
- success is not reported until every approved step completes
- a genuine blocker is shown as blocked rather than false success

### 3. Completed-step details during execution

While later steps are still running, expand earlier completed steps.

Expected:
- `Completed details` remains visible
- evidence from completed steps remains readable while newer activity continues
- live activity is separate from the plan board

### 4. Long-run responsiveness

Run a substantial build/test/migration task with many Agent/tool events and at least one command that runs for more than 15 seconds.

Expected:
- UI continues to move/update
- long foreground command shows periodic `Command still running (...)` activity
- heartbeat/model waiting does not fake completion; real tool activity can make bounded within-step progress
- old activity events are bounded/collapsed rather than growing the DOM indefinitely
- large command output does not cause runaway memory growth; output may contain an explicit truncation marker while preserving beginning/latest tail

### 5. History persistence

Create multiple Agent runs in one conversation, close the application, replace/extract the application folder, then restart.

Expected:
- conversation history remains available
- earlier Agent-run plan/progress/evidence is restored to the corresponding assistant response
- data is stored under `%USERPROFILE%\.advanced-ai-workbench\` on Windows or `~/.advanced-ai-workbench/` on Linux/macOS by default


### Single Agent model and model library

Open Settings and inspect the model library.

Expected:
- Settings opens every time, including in a browser/webview where persistent browser storage is restricted
- Home and Settings expose editable **Chat models** and **Agent models** text boxes
- both boxes accept comma-separated values; first Chat model is active, first Agent model is primary, remaining Agent models are ordered takeover fallbacks
- permission dropdowns and the model-library type dropdown are clickable and persist the selected value when Settings is saved
- the Agent screen shows the selected primary model plus fallback count; there are no separate Analysis/Planning/Validator/Critic selectors
- any model ID can be added, renamed, assigned a type/context window, tested and removed
- removing the active Agent model is prevented until a replacement is selected
- Chat accepts images only when the selected Chat model is vision-capable
- Agent rejects image input and does not make hidden vision-model calls

### Evidence-first planning with one model

Run the same substantial coding prompt against this Agent and your OpenCode setup using the same model where possible.

Expected:
- UI stages move through Index → Analyse → Plan → Review → Execute → Verify → Complete
- the selected Agent model handles the whole Agent task
- planning is created from live workspace evidence in one primary planning call (one corrective retry only if structured validation is missing)
- the plan is displayed in the formatted plan editor rather than raw model prose
- each plan step has a concrete objective and validation evidence
- the final plan step is a dedicated compile/test/check/run verification phase after coherent implementation changes, not a compile after every edit
- before editing an active step, the model receives bounded current contents of the strongest relevant live files; exact unproven methods/signatures are inspected instead of guessed
- the user can edit/reorder/add/remove steps before approval
- compare total duration, model calls, tokens, repeated read/search turns, fallback count and actual task completion with OpenCode

### Older-history recovery

Select several older Chat and Agent conversations, including conversations created before durable Agent activity was available.

Expected:
- selecting an old conversation immediately shows a loading state
- message loading is authoritative; a missing/old project, attachment or run metadata endpoint does not blank the conversation
- older Agent snapshots are attached by assistant-message ID when available and by ordered/timestamp fallback otherwise
- if an old chat truly fails to load, the currently open chat is restored instead of leaving an empty page

### Executor-pool exhaustion and recovery replan

Configure at least two execution models, then use a controlled test endpoint/model setup that makes every executor fail or repeatedly return no actionable progress for the active approved step.

Expected:
- each fallback takes over the same active step; completed steps do not run again
- the UI shows failover count/model changes rather than resetting the plan
- after the executor pool is exhausted, live status enters a recovery-analysis/replan phase
- a recoverable diagnosis creates a new validated plan for **unfinished work only** and restarts execution from the primary executor
- completed-step notes/evidence and valid workspace edits remain present
- recovery replan count is visible and survives history reopen/restart
- a genuine credential/permission/infrastructure blocker stops as `blocked` without futile replanning
- after the bounded recovery-replan limit is reached, the run stops cleanly and does not remain forever in a working state

### 6. Prompt library

Open `Prompt library`.

Expected:
- JUnit 5 tests for existing code
- JUnit tests from requirements
- fix from error/stack trace
- fix using a reference project
- migrate a feature from a reference project
- implement/modify feature, refactor, summarize project/module and code-review prompts
- Java Selenium + TestNG + Cucumber with Playwright MCP, Playwright framework and Selenium-to-Playwright migration prompts remain available
- prompts use a batch-changes-first, final-verification-last workflow

### 7. Agent-resource templates

Inspect `examples/agent-resources/`.

Expected:
- `AGENTS.md`
- `.agents/skills/playwright-mcp-testing/SKILL.md`
- `.agents/skills/selenium-to-playwright/SKILL.md`
- `.agents/skills/framework-quality/SKILL.md`

### 8. Full local validation

Before release use, run:

```bat
validate-local.bat
mvnw.cmd -Pfull-tests test
```

Share any failing console output, screenshot, or unexpected behavior and the exact test scenario used.

---

## Validation Report

Validation date: 2026-09-15

### Package status

**READY FOR USER VALIDATION.**

This build intentionally simplifies Agent orchestration to **one user-selected Agent model for the complete task**, with ordered fallback takeover only. Chat keeps an independent model and is the only mode that accepts image input.

A complete Spring Boot/Maven dependency-backed build could not be run in this sandbox because Maven bootstrap cannot resolve `repo.maven.apache.org`. Run `validate-local.bat` / `validate-local.sh` on a machine with dependency access before production use.

### Passed checks

- Frontend JavaScript syntax: **PASS**
  - `node --check src/main/resources/static/app.js`
  - `node --check src/main/resources/static/markdown.js`
- Frontend runtime smoke: **PASS**
  - application initialization completes even when browser `localStorage` / `sessionStorage` is unavailable
  - Settings opens from the sidebar
  - Chat models and Agent models are editable text inputs and preserve comma-separated values
  - permission and model-type dropdowns remain interactive
  - Prompt library opens and exposes the new developer/JUnit/debugging/reference-project prompts
- HTML/UI contract: **PASS**
  - required settings/model controls exist
  - no duplicate element IDs
  - Chat/Agent configuration uses editable comma-separated text boxes backed by the model datalist
  - legacy separate fallback editing is hidden; additional Agent models become ordered takeover fallbacks
  - old per-role Agent routing controls are not exposed
- Shell syntax: **PASS** (`run.sh`, `validate-local.sh`)
- `pom.xml` XML parse: **PASS**
- Java source syntax sanity: **PASS**
  - changed Java sources were parsed by `javac -proc:none`; no parser/language-level diagnostics were detected
  - unresolved Spring/Jackson/JUnit symbols are expected because Maven dependencies are not available in this sandbox
- Agent final-verification gate harness: **PASS** (`AGENT_BATCH_VERIFICATION_PASS`)
  - implementation steps can complete from real workspace evidence without compiling each step
  - the final approved step remains blocked while the latest mutation is unverified
  - successful final verification unlocks completion
- Single-model configuration harness: **`SINGLE_MODEL_HARNESS_PASS`**
  - Analysis → selected Agent model
  - Planning → selected Agent model
  - Plan review/validation → selected Agent model
  - Completion review → selected Agent model
  - semantic/embedding role routing disabled for Agent
  - ordered fallback pool remains available
- Visible product-version label scan: **PASS**
  - no application version label is shown in the UI

### Important flow changes verified

- **One Agent model for the whole task.** There are no hidden Analysis/Planner/Validator/Critic model assignments in the UI or effective backend routing.
- **Fallbacks are takeover only.** They preserve the approved plan, active step, current workspace, verifier state and failure memory; they do not split normal work across roles.
- **Faster planning path.** Initial Agent planning uses one evidence-backed model call instead of separate Analysis → Planning → Validator LLM calls. The harness checks structure/range, requires validation evidence for each step, and requires the **last** step to be a dedicated final verification phase.
- **Authoritative active-step context.** Local retrieval identifies relevant files, then the runtime preloads bounded **current file contents** for the strongest matches into the active model context. This reduces failures caused by planning/execution against filenames or stale snippets without the exact method/signature/data.
- **Retrieval remains local and deterministic.** Agent no longer depends on a separate embedding model. Retrieval caches are invalidated after mutations.
- **Chat/image separation.** Image attachments are accepted only in Chat mode. The selected Chat model must be vision-capable. Agent rejects image attachments rather than making hidden vision-model calls.
- **Model-library safety.** Agent selectors expose Chat / Agent entries only; dedicated Vision/OCR/Embedding entries are not offered as the primary Agent model.
- **Settings/dropdown startup fix.** Direct browser-storage access could throw in enterprise/privacy-restricted contexts and abort `app.js` before event handlers were wired, leaving Settings and dropdown-related UI apparently dead. Storage access is now guarded with an in-memory fallback, so the UI remains interactive even when persistence is denied.
- **Editable model lists.** Home and Settings now accept comma-separated Chat and Agent models. For Agent, the first value is the primary model and remaining values are ordered takeover fallbacks. For Chat, the first value is the active model.
- **Batch-then-verify execution.** Implementation steps advance from real reads/edits/diff evidence. Build/test/check/run is reserved for the final verification phase after all coherent requested changes are complete, unless the user explicitly asks for an intermediate run or it is needed to diagnose a concrete blocker.
- **Context recovery remains active.** Context overflow first checkpoints/compacts and retries the same Agent model. A larger-context fallback can take over only when necessary.
- **No-progress/repeated-failure guards remain active.** A failing strategy is redirected/fails over rather than consuming the full recovery budget with identical work.

### Maven build limitation in this environment

Attempted after the source/UI changes were complete:

```text
./mvnw -q -DskipTests compile
```

Result:

```text
Maven was not found. Bootstrapping Apache Maven 3.9.11...
curl: (6) Could not resolve host: repo.maven.apache.org
```

Therefore this report does **not** claim a complete Spring Boot `clean install` or the full JUnit suite in this sandbox.

### Required validation on your machine

Windows:

```bat
validate-local.bat
mvnw.cmd -Pfull-tests test
```

Linux/macOS:

```bash
./validate-local.sh
./mvnw -Pfull-tests test
```

A successful normal build should produce:

```text
target/advanced-ai-workbench.jar
```

---

## Agent Resource Starter Templates

The following templates were previously stored as separate Markdown files under `examples/agent-resources/`. They are retained here so the package has only one Markdown file while still preserving all guidance. Copy the relevant block into a target project when you want the Agent to use repository instructions or reusable skills.

### Repository `AGENTS.md` starter template

```markdown
# Repository Agent Instructions

## Purpose
Use this file for stable repository-wide rules. Keep task-specific notes, secrets, incident logs, and temporary paths out of it.

## Before changing code
1. Read the build configuration, nearest implementation, nearest tests, and relevant `.agents/skills/*/SKILL.md` files.
2. Reuse the current architecture and framework conventions before introducing a new abstraction.
3. Derive execution scope (tags, suites, modules, commands) from repository configuration when possible instead of asking the user to repeat it.

## Execution rules
- Work only inside the mapped project/resource paths.
- Prefer the smallest high-signal command/test first, then broaden validation when justified.
- Do not mark a planned step complete without real tool evidence.
- Code/config mutations must be verified on the current revision before the related plan step is completed.
- Do not hide failures with arbitrary sleeps, blanket retries, weaker assertions, or skipped tests.

## Quality
- Keep changes focused and review the final diff.
- Preserve public behavior outside the requested scope.
- Add/update focused tests when behavior changes or a regression is being fixed.
- Stop and report a blocker only when it is supported by concrete evidence.

## Commands
Replace these placeholders with commands validated for this repository:
- Build: `<build command>`
- Targeted test: `<targeted test command>`
- Full verification: `<full verification command>`

## Reusable knowledge
When a task reveals a stable repeatable workflow, update this file or create a focused skill. Do not duplicate the same instruction in multiple resources.
```

### Framework quality `SKILL.md` starter template

```markdown
# Framework Quality and Stability

## Use when
Improving an existing development or test framework for maintainability, speed, reliability, or CI quality.

## Inspect
- Build/test configuration and validated commands
- Lifecycle/fixtures/hooks and shared state
- Wait/retry policy and locator strategy for UI automation
- Test data and parallel execution
- Error handling, logging, reporting, failure artifacts, and CI behavior
- Duplicate utilities and unnecessary abstraction layers

## Workflow
1. Establish a measurable problem from code, logs, timings, or failures.
2. Identify the smallest root-cause change with the best expected impact.
3. Preserve existing external behavior and framework entry points unless the task requires otherwise.
4. Implement focused changes and targeted tests/checks.
5. Compare before/after evidence where practical.
6. Review the final diff for accidental complexity or behavior drift.

## Anti-patterns
Do not improve apparent stability by adding arbitrary sleeps, unlimited retries, broad exception swallowing, disabled tests, or weaker assertions.
```

### Playwright MCP testing `SKILL.md` starter template

```markdown
# Playwright MCP Browser Diagnosis

## Use when
An existing Selenium/TestNG/Cucumber or other non-Playwright runner needs live-browser evidence to diagnose a UI failure.

## Rules
- Keep the existing framework as the test runner unless migration is explicitly requested.
- Use Playwright MCP for live DOM/accessibility, frames, dialogs, overlays, redirects, visibility, and stable locator evidence.
- Do not add Playwright as a Java test dependency merely to use MCP.
- Prefer structured browser evidence over screenshot-coordinate guessing.

## Workflow
1. Read runner/tag configuration, hooks, affected page/component code, failure output, and `.agents/mcp.json`.
2. Derive the active test scope from repository configuration.
3. Run the smallest failing scope and capture the first actionable failure.
4. If browser evidence is needed, reproduce the flow with Playwright MCP and inspect the relevant live state.
5. Correlate browser evidence with the existing automation code.
6. Apply the smallest maintainable framework/test fix.
7. Rerun the affected scope and verify the current revision.
8. Review the final diff and report evidence.

## Stop conditions
Finish only when the affected scope passes on the current revision or a genuine external blocker is proven.
```

### Selenium-to-Playwright `SKILL.md` starter template

```markdown
# Selenium to Playwright Migration

## Use when
Migrating an existing Java Selenium framework or selected modules/features to Playwright.

## Principles
- Preserve business behavior and coverage, not Selenium API shape.
- Treat the source framework as read-only unless explicitly authorized.
- Reuse the target framework's fixtures, page/component patterns, reporting, data, and CI conventions.
- Prefer Playwright-native locators, auto-waiting, browser-context isolation, and parallel-safe state.

## Workflow
1. Map source runner/tags, scenarios/tests, page objects, waits, data, auth/session state, assertions, reports, and CI entry points.
2. Define an explicit source-to-target coverage mapping for the requested scope.
3. Migrate one coherent slice at a time.
4. Run the smallest target validation after each meaningful slice.
5. Fix target failures using actual runtime evidence; do not copy brittle Selenium waits/retries.
6. Run the requested final target scope and review the diff.
7. Update the coverage mapping and reusable migration rules.

## Completion
Do not call migration complete while requested source behavior lacks a target mapping or the target verification is failing without a proven external blocker.
```
