package com.llmart.llm.service;

import com.llmart.llm.dto.ChatSettings;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ModelCapabilityRegistryTest {

    @Test
    void recognisesConfiguredCibModelCapabilities() {
        var qwen = ModelCapabilityRegistry.profileFor("qwen3.8-27b");
        assertEquals(262_144, qwen.contextWindowTokens());
        assertTrue(qwen.toolCalling());
        assertTrue(qwen.preferredFor(ModelCapabilityRegistry.Role.EXECUTOR));

        var gptOss = ModelCapabilityRegistry.profileFor("gpt-oss-120b-ITG");
        assertEquals(131_072, gptOss.contextWindowTokens());
        assertTrue(gptOss.preferredFor(ModelCapabilityRegistry.Role.PLANNER));
        assertTrue(gptOss.preferredFor(ModelCapabilityRegistry.Role.CRITIC));
        assertFalse(gptOss.vision());

        var mistral = ModelCapabilityRegistry.profileFor("mistral-small-4-ITG");
        assertTrue(mistral.vision());
        assertEquals(262_144, mistral.contextWindowTokens());

        var embedding = ModelCapabilityRegistry.profileFor("qwen3-embedding-8b");
        assertTrue(embedding.embeddings());
        assertEquals(32_768, embedding.contextWindowTokens());
    }

    @Test
    void activeModelControlsAutoDetectedContextBudget() {
        ChatSettings settings = settings("qwen3.8-27b", "gpt-oss-120b-ITG", "gpt-oss-120b-ITG",
                "mistral-small-4-ITG", "qwen3-embedding-8b");

        assertEquals(262_144, settings.safeContextWindowTokens("qwen3.8-27b"));
        assertEquals(131_072, settings.safeContextWindowTokens("gpt-oss-120b-ITG"));
        assertEquals(262_144, settings.safeContextWindowTokens("mistral-small-4-ITG"));
    }

    @Test
    void agentUsesOnePrimaryModelForEveryHarnessStage() {
        ChatSettings settings = settings("qwen3.8-27b", "gpt-oss-120b-ITG", "gpt-oss-120b-ITG",
                "mistral-small-4-ITG", "qwen3-embedding-8b");

        assertEquals("qwen3.8-27b", settings.analysisModelOrPrimary());
        assertEquals("qwen3.8-27b", settings.plannerModelOrPrimary());
        assertEquals("qwen3.8-27b", settings.planValidatorModelOrPrimary());
        assertEquals("qwen3.8-27b", settings.criticModelOrPrimary());
        assertEquals(settings.chatModelOrPrimary(), settings.visionModelOrPrimary());
        assertEquals("", settings.embeddingModelName());
        assertFalse(settings.hasDedicatedVisionModel());
        assertFalse(settings.semanticRetrievalEnabled());
        assertFalse(settings.smartModelRoutingEnabled());
    }


    @Test
    void editableModelLibraryTypeAugmentsBackendRoleCapabilities() {
        ChatSettings settings = settings("qwen3.8-27b", "gpt-oss-120b-ITG", "gpt-oss-120b-ITG",
                "custom-vision", "qwen3-embedding-8b");

        assertTrue(settings.configuredForRole("custom-vision", ModelCapabilityRegistry.Role.VISION));
        // A known multimodal model remains vision-capable even when the coarse UI type is Chat / Agent.
        assertTrue(settings.configuredForRole("mistral-small-4-ITG", ModelCapabilityRegistry.Role.VISION));
    }

    private static ChatSettings settings(String model, String planner, String critic, String vision, String embedding) {
        return new ChatSettings(
                "http://localhost/v1", model, null, vision, critic, planner, critic, critic, embedding, true, true,
                0.1, 0, 0, 0, null, "mistral-small-4-ITG=chat\nqwen3-embedding-8b=embedding\ncustom-vision=vision", true, 8_000, 20_000, 1_200,
                null, true, 0, true,
                "allow", "allow", "allow", true, "",
                "allow", "allow", "allow", true, true,
                "mistral-small-4-ITG,qwen3.6-27b", 10
        );
    }
}
