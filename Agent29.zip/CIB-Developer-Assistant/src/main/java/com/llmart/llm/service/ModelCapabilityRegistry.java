package com.llmart.llm.service;

import org.springframework.stereotype.Service;

import java.util.*;

/**
 * Central model capability registry used by the harness to make model-aware decisions.
 *
 * The application still supports arbitrary OpenAI-compatible model names. Unknown models intentionally
 * receive conservative defaults rather than being rejected. The known entries below reflect the model
 * catalogue commonly used with this deployment and can be extended without changing the agent loop.
 */
@Service
public class ModelCapabilityRegistry {
    public enum Role { EXECUTOR, ANALYSIS, PLANNER, PLAN_VALIDATOR, CRITIC, VISION, OCR, EMBEDDING }

    public record ModelProfile(
            String canonicalName,
            int contextWindowTokens,
            boolean toolCalling,
            boolean vision,
            boolean embeddings,
            boolean ocr,
            Set<Role> preferredRoles
    ) {
        public ModelProfile {
            canonicalName = canonicalName == null ? "" : canonicalName;
            contextWindowTokens = Math.max(512, contextWindowTokens);
            preferredRoles = preferredRoles == null ? Set.of() : Set.copyOf(preferredRoles);
        }

        public boolean preferredFor(Role role) { return preferredRoles.contains(role); }
    }

    private static final int DEFAULT_CONTEXT = 128_000;

    private static final List<KnownModel> KNOWN = List.of(
            known("gpt-oss-120b", 131_072, true, false, false, false, Role.ANALYSIS, Role.PLAN_VALIDATOR, Role.PLANNER, Role.CRITIC, Role.EXECUTOR),
            known("mistral-small-4", 262_144, true, true, false, false, Role.EXECUTOR, Role.VISION, Role.ANALYSIS, Role.PLANNER),
            known("mistral-medium-2508", 128_000, true, false, false, false, Role.EXECUTOR),
            known("mistral-small-2506", 128_000, true, false, false, false, Role.EXECUTOR),
            known("mistral-ocr-2512", 128_000, false, true, false, true, Role.OCR, Role.VISION),
            known("mistral-ocr-4", 128_000, false, true, false, true, Role.OCR, Role.VISION),
            known("gemma-4-31b", 262_144, true, true, false, false, Role.VISION, Role.EXECUTOR),
            known("qwen3.8-27b", 262_144, true, false, false, false, Role.EXECUTOR, Role.ANALYSIS, Role.PLANNER),
            known("qwen-latest", 262_144, true, false, false, false, Role.EXECUTOR),
            known("qwen3.6-35b-a3b", 262_144, true, false, false, false, Role.EXECUTOR),
            known("qwen3.6-27b", 262_144, true, false, false, false, Role.EXECUTOR),
            known("qwen3-embedding-8b", 32_768, false, false, true, false, Role.EMBEDDING),
            known("bge-m3", 8_192, false, false, true, false, Role.EMBEDDING),
            known("bge-large-en-v1.5", 512, false, false, true, false, Role.EMBEDDING),
            known("multilingual-e5-large", 512, false, false, true, false, Role.EMBEDDING),
            known("claude", 200_000, true, true, false, false, Role.EXECUTOR, Role.ANALYSIS, Role.PLANNER, Role.PLAN_VALIDATOR, Role.CRITIC)
    );

    private static KnownModel known(String match, int context, boolean tools, boolean vision,
                                    boolean embeddings, boolean ocr, Role... roles) {
        return new KnownModel(match.toLowerCase(Locale.ROOT),
                new ModelProfile(match, context, tools, vision, embeddings, ocr,
                        roles == null || roles.length == 0 ? Set.of() : EnumSet.copyOf(Arrays.asList(roles))));
    }

    public ModelProfile profile(String model) { return profileFor(model); }

    public static ModelProfile profileFor(String model) {
        String normalized = normalize(model);
        for (KnownModel known : KNOWN) {
            if (normalized.contains(known.match())) {
                ModelProfile base = known.profile();
                return new ModelProfile(model == null ? base.canonicalName() : model.trim(),
                        base.contextWindowTokens(), base.toolCalling(), base.vision(), base.embeddings(), base.ocr(), base.preferredRoles());
            }
        }
        return new ModelProfile(model == null ? "" : model.trim(), DEFAULT_CONTEXT,
                true, false, false, false, Set.of(Role.EXECUTOR));
    }

    /** Conservative context hint for settings where the user has not supplied an explicit provider value. */
    public static int contextWindowHint(String model) { return profileFor(model).contextWindowTokens(); }

    public boolean supportsVision(String model) { return profileFor(model).vision(); }
    public boolean supportsEmbeddings(String model) { return profileFor(model).embeddings(); }

    /**
     * Pick a configured model for a role without inventing a model that the user did not configure.
     * Explicit role models are handled in ChatSettings before this helper is called.
     */
    public String choose(Role role, Collection<String> configuredModels, String fallback) {
        if (configuredModels != null) {
            for (String model : configuredModels) {
                if (model != null && !model.isBlank() && profileFor(model).preferredFor(role)) return model.trim();
            }
        }
        return fallback == null ? "" : fallback.trim();
    }

    private static String normalize(String value) {
        return value == null ? "" : value.trim().toLowerCase(Locale.ROOT);
    }

    private record KnownModel(String match, ModelProfile profile) { }
}
