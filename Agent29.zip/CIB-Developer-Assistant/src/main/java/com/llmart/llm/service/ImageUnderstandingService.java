package com.llmart.llm.service;

import com.llmart.llm.dto.ChatSettings;
import com.llmart.llm.entity.FileEntity;
import org.springframework.stereotype.Service;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;

@Service
public class ImageUnderstandingService {
    private final OpenAiCompatibleClient llm;

    public ImageUnderstandingService(OpenAiCompatibleClient llm) { this.llm = llm; }

    /** Uses the dedicated vision role automatically and falls back only to other vision-capable configured models. */
    public String describe(String apiKey, ChatSettings settings, List<FileEntity> attached, String userRequest) throws Exception {
        List<FileEntity> images = attached.stream()
                .filter(f -> f.getMimeType() != null && f.getMimeType().startsWith("image/"))
                .filter(f -> f.getSizeBytes() <= 8_000_000)
                .limit(4)
                .toList();
        if (images.isEmpty()) return "";

        List<Map<String, Object>> content = new ArrayList<>();
        String request = userRequest == null ? "" : userRequest;
        content.add(Map.of("type", "text", "text", """
                Analyze the attached image(s) for a downstream general-purpose AI assistant.
                Extract visible text and relevant structure faithfully. Depending on the image, identify UI controls,
                tables, charts, diagrams, error messages, code, logs, configuration, requirements, navigation, values,
                relationships and other details that materially help answer the user's request. Describe layout when it
                affects meaning. Be precise and do not invent text or details that are not visible.

                User's request:
                """ + request + "\n\nImages: " + images.stream().map(FileEntity::getOriginalName).toList()));

        for (FileEntity image : images) {
            byte[] bytes = Files.readAllBytes(Path.of(image.getStoredPath()));
            String dataUrl = "data:" + image.getMimeType() + ";base64," + Base64.getEncoder().encodeToString(bytes);
            content.add(Map.of("type", "image_url", "image_url", Map.of("url", dataUrl)));
        }

        List<Map<String, Object>> messages = List.of(
                Map.of("role", "system", "content", "You are a precise vision extractor for general software, document, data and UI analysis."),
                Map.of("role", "user", "content", content)
        );
        LinkedHashSet<String> candidates = new LinkedHashSet<>();
        String configuredVision = settings.visionModelOrPrimary();
        if (configuredVision != null && !configuredVision.isBlank() &&
                settings.configuredForRole(configuredVision, ModelCapabilityRegistry.Role.VISION)) {
            candidates.add(configuredVision.trim());
        }
        for (String candidate : settings.agentModels()) {
            if (candidate != null && !candidate.isBlank() && settings.configuredForRole(candidate, ModelCapabilityRegistry.Role.VISION)) {
                candidates.add(candidate.trim());
            }
        }
        String primary = settings.model() == null ? "" : settings.model().trim();
        if (!primary.isBlank() && settings.configuredForRole(primary, ModelCapabilityRegistry.Role.VISION)) candidates.add(primary);
        if (candidates.isEmpty()) {
            throw new IllegalStateException("No vision-capable model is configured for image analysis");
        }

        Exception lastFailure = null;
        for (String candidate : candidates) {
            try {
                String description = llm.complete(apiKey, settings.baseUrl(), candidate, 3000, messages);
                if (description != null && !description.isBlank()) {
                    return "Vision model: " + candidate + "\n" + description.strip();
                }
                lastFailure = new IllegalStateException("Vision model returned an empty image analysis: " + candidate);
            } catch (Exception failure) {
                lastFailure = failure;
            }
        }
        throw new IllegalStateException("Image analysis failed for every configured vision-capable model" +
                (lastFailure == null || lastFailure.getMessage() == null ? "" : ": " + lastFailure.getMessage()), lastFailure);
    }
}
