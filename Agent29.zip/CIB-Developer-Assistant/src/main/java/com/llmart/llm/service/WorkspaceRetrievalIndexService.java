package com.llmart.llm.service;

import com.llmart.llm.dto.ChatSettings;

import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Pattern;

/**
 * Hybrid workspace retrieval for Agent mode.
 *
 * A deterministic local lexical index is always available as the zero-dependency baseline. When semantic retrieval
 * is enabled and an embedding model is configured, the strongest lexical candidates are reranked semantically.
 * Provider/embedding failures never block the agent: retrieval falls back to lexical results automatically.
 * The live filesystem remains authoritative; returned snippets are retrieval hints only.
 */
@Service
public class WorkspaceRetrievalIndexService {
    private static final int MAX_FILES = 16_000;
    private static final int MAX_SCANNED_FILES = 50_000;
    private static final int MAX_INDEXED_FILE_BYTES = 192_000;
    private static final int MAX_SAMPLED_CHARS_PER_FILE = 36_000;
    private static final int MAX_TERMS_PER_FILE = 220;
    private static final int DEFAULT_RESULT_LIMIT = 8;
    private static final int DEFAULT_MAX_CHARS = 8_000;
    private static final Pattern SPLIT = Pattern.compile("[^A-Za-z0-9_.$-]+");
    private static final Set<String> SKIP_DIRS = Set.of(
            ".git", ".idea", ".vscode", "node_modules", "target", "build", "dist", "out", ".gradle",
            ".next", "coverage", ".venv", "venv", "vendor", ".terraform", ".dart_tool", ".cache", "bin", "obj"
    );
    private static final Set<String> INDEX_EXTENSIONS = Set.of(
            "java", "kt", "kts", "groovy", "scala", "xml", "properties", "yml", "yaml", "json", "jsonc",
            "js", "jsx", "ts", "tsx", "mjs", "cjs", "py", "go", "rs", "rb", "php", "cs", "fs", "fsx",
            "swift", "dart", "c", "h", "cc", "cpp", "cxx", "hpp", "sql", "sh", "bash", "zsh", "ps1",
            "md", "txt", "html", "htm", "css", "scss", "less", "vue", "svelte", "tf", "hcl", "toml"
    );
    private static final Set<String> IMPORTANT_NAMES = Set.of(
            "pom.xml", "build.gradle", "build.gradle.kts", "settings.gradle", "settings.gradle.kts", "package.json",
            "pyproject.toml", "requirements.txt", "go.mod", "cargo.toml", "composer.json", "gemfile", "makefile",
            "cmakelists.txt", "build.xml", "jenkinsfile", "dockerfile", "compose.yml", "compose.yaml", "agents.md",
            "claude.md", "readme.md", "application.properties", "application.yml", "application.yaml"
    );
    private static final Set<String> STOP = Set.of(
            "the", "and", "for", "that", "this", "with", "from", "have", "will", "would", "could", "should",
            "into", "about", "your", "you", "are", "was", "were", "how", "can", "use", "using", "file", "files",
            "project", "agent", "step", "plan", "task", "work", "working", "issue", "issues", "test", "tests",
            "then", "when", "where", "what", "which", "there", "their", "them", "need", "needs", "make"
    );

    private final Map<String, WorkspaceIndex> cache = new ConcurrentHashMap<>();
    private final Map<String, String> semanticResultCache = new ConcurrentHashMap<>();
    private final OpenAiCompatibleClient llm;

    public WorkspaceRetrievalIndexService(OpenAiCompatibleClient llm) {
        this.llm = llm;
    }

    public IndexStats warm(AgentWorkspaceService.Workspace ws) {
        WorkspaceIndex idx = index(ws, false);
        return idx.stats();
    }

    public IndexStats refresh(AgentWorkspaceService.Workspace ws) {
        WorkspaceIndex idx = index(ws, true);
        return idx.stats();
    }

    public String retrieve(AgentWorkspaceService.Workspace ws, String query) {
        return retrieve(ws, query, DEFAULT_RESULT_LIMIT, DEFAULT_MAX_CHARS);
    }

    public String retrieve(AgentWorkspaceService.Workspace ws, String query, int limit, int maxChars) {
        return retrieveInternal(ws, query, limit, maxChars, null);
    }

    /**
     * Hybrid retrieval: keep the deterministic lexical index as the safety baseline, then semantically rerank
     * the strongest live candidates with the configured embedding model. Any embedding/provider failure silently
     * falls back to lexical retrieval so repository work never depends on a secondary model.
     */
    public String retrieveHybrid(AgentWorkspaceService.Workspace ws, String query, int limit, int maxChars,
                                 String apiKey, ChatSettings settings, java.util.function.BooleanSupplier cancelled) {
        if (ws == null || query == null || query.isBlank() || settings == null || !settings.semanticRetrievalEnabled())
            return retrieve(ws, query, limit, maxChars);
        String embeddingModel = settings.embeddingModelName();
        if (embeddingModel.isBlank() || apiKey == null || apiKey.isBlank()) return retrieve(ws, query, limit, maxChars);

        WorkspaceIndex idx = index(ws, false);
        String cacheKey = cacheKey(ws) + "|" + idx.stats().generatedAt() + "|" + embeddingModel + "|" +
                Integer.toHexString(query.strip().toLowerCase(Locale.ROOT).hashCode()) + "|" + limit + "|" + maxChars;
        String cached = semanticResultCache.get(cacheKey);
        if (cached != null) return cached;

        try {
            List<ScoredFile> lexical = score(idx, query);
            if (lexical.isEmpty()) return "";
            int candidateCount = Math.min(36, lexical.size());
            List<ScoredFile> candidates = new ArrayList<>(lexical.subList(0, candidateCount));
            List<String> inputs = new ArrayList<>(candidateCount + 1);
            inputs.add(query);
            for (ScoredFile candidate : candidates) {
                IndexedFile file = candidate.file();
                inputs.add("path: " + file.path() + "\n" + clip(file.sample(), 5_000));
            }
            List<double[]> vectors = llm.embed(apiKey, settings.baseUrl(), embeddingModel, inputs,
                    cancelled == null ? () -> false : cancelled);
            if (vectors.size() != inputs.size()) return retrieve(ws, query, limit, maxChars);
            double maxLexical = candidates.stream().mapToDouble(ScoredFile::score).max().orElse(1.0);
            List<ScoredFile> reranked = new ArrayList<>();
            for (int i = 0; i < candidates.size(); i++) {
                ScoredFile candidate = candidates.get(i);
                double semantic = Math.max(-1.0, Math.min(1.0, cosine(vectors.get(0), vectors.get(i + 1))));
                double semantic01 = (semantic + 1.0) / 2.0;
                double lexical01 = Math.min(1.0, candidate.score() / Math.max(1.0, maxLexical));
                double fused = (lexical01 * 0.48) + (semantic01 * 0.52);
                reranked.add(new ScoredFile(candidate.file(), fused * 100.0));
            }
            reranked.sort(Comparator.comparingDouble(ScoredFile::score).reversed().thenComparing(v -> v.file().path()));
            String result = render(ws, query, terms(query), reranked, limit, maxChars,
                    "hybrid lexical + semantic reranking via " + embeddingModel);
            if (!result.isBlank()) {
                if (semanticResultCache.size() > 400) semanticResultCache.clear();
                semanticResultCache.put(cacheKey, result);
            }
            return result;
        } catch (Exception ignored) {
            return retrieve(ws, query, limit, maxChars);
        }
    }

    private String retrieveInternal(AgentWorkspaceService.Workspace ws, String query, int limit, int maxChars, String mode) {
        if (ws == null || query == null || query.isBlank()) return "";
        WorkspaceIndex idx = index(ws, false);
        Set<String> terms = terms(query);
        if (terms.isEmpty()) return "";
        return render(ws, query, terms, score(idx, query), limit, maxChars, mode == null ? "local lexical index" : mode);
    }

    private List<ScoredFile> score(WorkspaceIndex idx, String query) {
        Set<String> terms = terms(query);
        if (terms.isEmpty()) return List.of();
        List<ScoredFile> scored = new ArrayList<>();
        for (IndexedFile file : idx.files()) {
            double score = 0.0;
            String lowPath = file.path().toLowerCase(Locale.ROOT);
            for (String term : terms) {
                if (lowPath.contains(term)) score += 8.0;
                Integer frequency = file.termFrequency().get(term);
                if (frequency != null) score += Math.min(8, frequency) * 1.35;
            }
            if (score > 0 && isImportant(file.path())) score += 1.5;
            if (score > 0) scored.add(new ScoredFile(file, score));
        }
        scored.sort(Comparator.comparingDouble(ScoredFile::score).reversed().thenComparing(v -> v.file().path()));
        return scored;
    }

    private String render(AgentWorkspaceService.Workspace ws, String query, Set<String> terms, List<ScoredFile> scored,
                          int limit, int maxChars, String mode) {
        int wanted = Math.max(1, Math.min(limit, 16));
        int budget = Math.max(1_000, Math.min(maxChars, 24_000));
        StringBuilder out = new StringBuilder();
        out.append("WORKSPACE RETRIEVAL HINTS — ").append(mode).append("; live files/tools are authoritative.\n");
        out.append("queryTerms: ").append(String.join(", ", terms)).append('\n');
        int emitted = 0;
        for (ScoredFile match : scored) {
            if (emitted >= wanted || out.length() >= budget) break;
            Path file = ws.root().resolve(match.file().path()).normalize();
            if (!file.startsWith(ws.root()) || !Files.isRegularFile(file)) continue;
            String snippet = currentSnippet(file, terms, 900);
            if (snippet.isBlank()) snippet = clip(match.file().sample().replace("\r", "").strip(), 700);
            String block = "\n- " + match.file().path() + " (score=" + String.format(Locale.ROOT, "%.1f", match.score()) + ")" +
                    (snippet.isBlank() ? "" : "\n  " + snippet.replace("\n", "\n  "));
            if (out.length() + block.length() > budget) break;
            out.append(block);
            emitted++;
        }
        return emitted == 0 ? "" : out.toString();
    }

    private double cosine(double[] a, double[] b) {
        if (a == null || b == null || a.length == 0 || a.length != b.length) return 0.0;
        double dot = 0.0, aa = 0.0, bb = 0.0;
        for (int i = 0; i < a.length; i++) { dot += a[i] * b[i]; aa += a[i] * a[i]; bb += b[i] * b[i]; }
        if (aa <= 0.0 || bb <= 0.0) return 0.0;
        return dot / (Math.sqrt(aa) * Math.sqrt(bb));
    }

    public void invalidate(AgentWorkspaceService.Workspace ws) {
        if (ws != null) {
            String prefix = cacheKey(ws);
            cache.remove(prefix);
            semanticResultCache.keySet().removeIf(key -> key.startsWith(prefix + "|"));
        }
    }

    private WorkspaceIndex index(AgentWorkspaceService.Workspace ws, boolean force) {
        String key = cacheKey(ws);
        if (!force) {
            WorkspaceIndex existing = cache.get(key);
            if (existing != null && Objects.equals(existing.root(), ws.root().toString())) return existing;
        }
        WorkspaceIndex built = build(ws);
        cache.put(key, built);
        return built;
    }

    private WorkspaceIndex build(AgentWorkspaceService.Workspace ws) {
        List<IndexedFile> files = new ArrayList<>();
        int[] scanned = {0};
        int[] indexed = {0};
        try {
            Files.walkFileTree(ws.root(), EnumSet.noneOf(FileVisitOption.class), 12, new SimpleFileVisitor<>() {
                @Override public FileVisitResult preVisitDirectory(Path dir, BasicFileAttributes attrs) {
                    if (!dir.equals(ws.root())) {
                        String name = dir.getFileName().toString().toLowerCase(Locale.ROOT);
                        if (SKIP_DIRS.contains(name)) return FileVisitResult.SKIP_SUBTREE;
                    }
                    return scanned[0] >= MAX_SCANNED_FILES || indexed[0] >= MAX_FILES ? FileVisitResult.TERMINATE : FileVisitResult.CONTINUE;
                }

                @Override public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) {
                    if (++scanned[0] > MAX_SCANNED_FILES || indexed[0] >= MAX_FILES) return FileVisitResult.TERMINATE;
                    if (!attrs.isRegularFile() || !indexable(file, attrs.size())) return FileVisitResult.CONTINUE;
                    indexed[0]++;
                    String rel = ws.root().relativize(file).toString().replace('\\', '/');
                    try {
                        String sample = sample(file);
                        files.add(new IndexedFile(rel, frequencies(rel + "\n" + sample), clip(sample, 8_000)));
                    } catch (Exception ignored) {
                        files.add(new IndexedFile(rel, frequencies(rel), ""));
                    }
                    return FileVisitResult.CONTINUE;
                }
            });
        } catch (IOException ignored) { }
        return new WorkspaceIndex(ws.root().toString(), List.copyOf(files),
                new IndexStats(files.size(), scanned[0], Instant.now().toString()));
    }

    private boolean indexable(Path file, long size) {
        if (size < 0 || size > MAX_INDEXED_FILE_BYTES) return false;
        String name = file.getFileName().toString().toLowerCase(Locale.ROOT);
        if (IMPORTANT_NAMES.contains(name)) return true;
        int dot = name.lastIndexOf('.');
        return dot > 0 && INDEX_EXTENSIONS.contains(name.substring(dot + 1));
    }

    private String sample(Path file) throws IOException {
        byte[] bytes = Files.readAllBytes(file);
        if (bytes.length == 0) return "";
        int n = Math.min(bytes.length, MAX_SAMPLED_CHARS_PER_FILE);
        String head = new String(bytes, 0, n, StandardCharsets.UTF_8);
        if (bytes.length <= n) return head;
        int tailBytes = Math.min(8_000, bytes.length - n);
        String tail = new String(bytes, bytes.length - tailBytes, tailBytes, StandardCharsets.UTF_8);
        return head + "\n" + tail;
    }

    private Map<String,Integer> frequencies(String text) {
        Map<String,Integer> frequency = new HashMap<>();
        if (text == null) return Map.of();
        for (String raw : SPLIT.split(text.toLowerCase(Locale.ROOT))) {
            String term = raw.trim();
            if (term.length() < 3 || term.length() > 80 || STOP.contains(term) || term.matches("\\d+")) continue;
            if (!frequency.containsKey(term) && frequency.size() >= MAX_TERMS_PER_FILE) continue;
            frequency.merge(term, 1, Integer::sum);
        }
        return Map.copyOf(frequency);
    }

    private Set<String> terms(String text) {
        LinkedHashSet<String> out = new LinkedHashSet<>();
        if (text == null) return out;
        for (String raw : SPLIT.split(text.toLowerCase(Locale.ROOT))) {
            String term = raw.trim();
            if (term.length() < 3 || term.length() > 80 || STOP.contains(term) || term.matches("\\d+")) continue;
            out.add(term);
            if (out.size() >= 80) break;
        }
        return out;
    }

    private String currentSnippet(Path file, Set<String> terms, int maxChars) {
        try {
            List<String> lines = Files.readAllLines(file, StandardCharsets.UTF_8);
            List<String> matches = new ArrayList<>();
            for (int i = 0; i < lines.size() && matches.size() < 4; i++) {
                String low = lines.get(i).toLowerCase(Locale.ROOT);
                boolean hit = false;
                for (String term : terms) if (low.contains(term)) { hit = true; break; }
                if (!hit) continue;
                matches.add((i + 1) + ": " + clip(lines.get(i).strip(), 220));
            }
            String result = String.join("\n", matches);
            return clip(result, maxChars);
        } catch (Exception ignored) { return ""; }
    }

    private boolean isImportant(String path) {
        return IMPORTANT_NAMES.contains(Path.of(path).getFileName().toString().toLowerCase(Locale.ROOT));
    }

    private String cacheKey(AgentWorkspaceService.Workspace ws) {
        return ws.projectId() + "|" + ws.root().toAbsolutePath().normalize();
    }

    private static String clip(String value, int max) {
        if (value == null || value.length() <= max) return value == null ? "" : value;
        return value.substring(0, Math.max(0, max - 18)) + " …[clipped]";
    }

    private record IndexedFile(String path, Map<String,Integer> termFrequency, String sample) { }
    private record ScoredFile(IndexedFile file, double score) { }
    private record WorkspaceIndex(String root, List<IndexedFile> files, IndexStats stats) { }
    public record IndexStats(int indexedFiles, int visitedFiles, String generatedAt) { }
}
