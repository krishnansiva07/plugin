package com.llmart.llm.service;

import org.springframework.stereotype.Service;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Lightweight, stateless probe for editable user-defined model entries. */
@Service
public class ModelProbeService {
    private final OpenAiCompatibleClient llm;

    public ModelProbeService(OpenAiCompatibleClient llm) { this.llm = llm; }

    public Map<String,Object> probe(String apiKey, String baseUrl, String model, String rawType) throws Exception {
        if (apiKey == null || apiKey.isBlank()) throw new IllegalArgumentException("API key is required to test a model");
        if (baseUrl == null || baseUrl.isBlank()) throw new IllegalArgumentException("Base URL is required to test a model");
        if (model == null || model.isBlank()) throw new IllegalArgumentException("Model ID is required");
        String type = rawType == null ? "chat" : rawType.trim().toLowerCase(Locale.ROOT);
        long started = System.nanoTime();
        String capability;
        if ("embedding".equals(type)) {
            List<double[]> vectors = llm.embed(apiKey, baseUrl, model.trim(), List.of("model connectivity probe"), () -> false);
            if (vectors.isEmpty() || vectors.get(0).length == 0) throw new IllegalStateException("Embedding model returned no vector");
            capability = "embedding";
        } else {
            String reply = llm.complete(apiKey, baseUrl, model.trim(), 24,
                    List.of(Map.of("role", "user", "content", "Connection probe. Reply with OK only.")));
            if (reply == null || reply.isBlank()) throw new IllegalStateException("Model returned an empty response");
            capability = ("vision".equals(type) || "ocr".equals(type))
                    ? "text connectivity (image capability is exercised automatically on a real image)"
                    : "chat completion";
        }
        long elapsedMs = Math.max(1L, (System.nanoTime() - started) / 1_000_000L);
        Map<String,Object> out = new LinkedHashMap<>();
        out.put("ok", true);
        out.put("model", model.trim());
        out.put("type", type);
        out.put("capability", capability);
        out.put("elapsedMs", elapsedMs);
        return out;
    }
}
