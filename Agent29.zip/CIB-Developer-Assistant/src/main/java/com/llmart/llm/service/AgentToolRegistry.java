package com.llmart.llm.service;

import org.springframework.stereotype.Service;

import java.util.*;

/**
 * Stable built-in tool registry plus dynamic MCP definitions discovered per live workspace.
 * The LLM sees one merged tool catalog; routing remains generic and technology-independent.
 */
@Service
public class AgentToolRegistry {
    private final List<Map<String,Object>> builtIns;
    private final Set<String> builtInNames;
    private final Map<String,String> aliases;
    private final Set<String> parallelReadOnly;

    public AgentToolRegistry() {
        List<Map<String,Object>> t = new ArrayList<>();
        t.add(tool("inspect_workspace", "Inspect the active local workspace, important descriptors and likely toolchains.", emptyObject()));
        t.add(tool("workspace_profile", "Read the durable workspace profile so repeated tasks do not rediscover project basics.", emptyObject()));
        t.add(tool("workspace_profile_refresh", "Refresh the durable workspace profile after major structural changes.", emptyObject()));
        t.add(tool("list", "List files under an optional relative workspace path.", objectSchema(prop("path", stringSchema("Optional relative path prefix")))));
        t.add(tool("glob", "Find workspace files using a glob pattern.", objectSchema(prop("pattern", stringSchema("Glob such as src/**/*.java")), prop("maxMatches", integerSchema("Maximum matches; 0 or omitted returns all matches")), required("pattern"))));
        t.add(tool("grep", "Search text files in the workspace. Use regex=true only when needed.", objectSchema(prop("pattern", stringSchema("Literal text or Java regular expression")), prop("regex", booleanSchema("Interpret as regular expression")), prop("maxMatches", integerSchema("Maximum matches; 0 returns all")), required("pattern"))));
        t.add(tool("file_info", "Return metadata for a workspace file or directory.", objectSchema(prop("path", stringSchema("Relative workspace path")), required("path"))));
        t.add(tool("file_index", "Summarize a text/source file without injecting its full contents. Recommended before reading large structured or minified files.", objectSchema(prop("path", stringSchema("Relative workspace file path")), required("path"))));
        t.add(tool("read", "Read a text/source file with optional line bounds. Full reads of large files are guarded; use file_index/read_chunk/grep when advised.", objectSchema(prop("path", stringSchema("Relative workspace file path")), prop("startLine", integerSchema("Optional first line, 1-based")), prop("endLine", integerSchema("Optional last line, inclusive")), required("path"))));
        t.add(tool("read_chunk", "Read a character chunk from a large/minified workspace text file.", objectSchema(prop("path", stringSchema("Relative workspace file path")), prop("offsetChars", integerSchema("0-based character offset")), prop("maxChars", integerSchema("Chunk size; defaults to 16000 and is capped")), required("path"))));
        t.add(tool("read_many", "Read several text/source files in one tool call.", objectSchema(prop("paths", arrayOf(stringSchema("Relative workspace file path"))), required("paths"))));
        t.add(tool("instruction_catalog", "List project instruction files such as root/nested AGENTS.md and CLAUDE.md.", emptyObject()));
        t.add(tool("instructions_for", "Load instructions applicable to a relative workspace path, including nested AGENTS.md files.", objectSchema(prop("path", stringSchema("Relative file or directory path")), required("path"))));

        t.add(tool("resource_catalog", "List all prompt-resolved filesystem resources and aliases. Use this when the prompt contains multiple paths.", emptyObject()));
        t.add(tool("resource_list", "List files under a prompt-resolved resource alias.", objectSchema(prop("alias", stringSchema("Resource alias from resource_catalog, with or without @")), prop("path", stringSchema("Optional relative path inside the resource")), required("alias"))));
        t.add(tool("resource_info", "Return metadata for a prompt-resolved resource file/directory, including its generic role and large-text flag.", objectSchema(prop("alias", stringSchema("Resource alias")), prop("path", stringSchema("Optional relative path")), required("alias"))));
        t.add(tool("resource_index", "Summarize a prompt-resolved text resource without injecting the full file. Recommended for large structured/minified inputs.", objectSchema(prop("alias", stringSchema("Resource alias")), prop("path", stringSchema("Relative path; omit for a standalone file or focused project file")), required("alias"))));
        t.add(tool("resource_read", "Read a text/log/source file from a prompt-resolved resource. Full reads of large files are guarded.", objectSchema(prop("alias", stringSchema("Resource alias")), prop("path", stringSchema("Relative path; omit for a standalone file resource or its focused file")), prop("startLine", integerSchema("Optional first line, 1-based")), prop("endLine", integerSchema("Optional last line, inclusive")), required("alias"))));
        t.add(tool("resource_chunk", "Read a character chunk from a large/minified prompt-resolved text resource.", objectSchema(prop("alias", stringSchema("Resource alias")), prop("path", stringSchema("Relative path; omit for a standalone file or focused project file")), prop("offsetChars", integerSchema("0-based character offset")), prop("maxChars", integerSchema("Chunk size; defaults to 16000 and is capped")), required("alias"))));
        t.add(tool("resource_grep", "Search text in a prompt-resolved resource.", objectSchema(prop("alias", stringSchema("Resource alias")), prop("pattern", stringSchema("Literal text or regex")), prop("regex", booleanSchema("Interpret pattern as regex")), prop("maxMatches", integerSchema("Maximum matches; 0 means all")), required("alias","pattern"))));
        t.add(tool("resource_edit", "Edit a file in an explicitly supplied writable project resource.", objectSchema(prop("alias", stringSchema("Writable project alias")), prop("path", stringSchema("Relative file path")), prop("oldText", stringSchema("Exact existing text")), prop("newText", stringSchema("Replacement text")), prop("replaceAll", booleanSchema("Replace all matches")), required("alias","path","oldText","newText"))));
        t.add(tool("resource_write", "Create or replace a text file in an explicitly supplied writable project resource.", objectSchema(prop("alias", stringSchema("Writable project alias")), prop("path", stringSchema("Relative file path")), prop("content", stringSchema("Complete content")), required("alias","path","content"))));
        t.add(tool("resource_delete", "Delete a file from an explicitly supplied writable project resource.", objectSchema(prop("alias", stringSchema("Writable project alias")), prop("path", stringSchema("Relative file path")), required("alias","path"))));
        t.add(tool("resource_copy", "Copy a file between prompt-resolved resources. The destination resource must be writable; this supports migration from a read-only reference into a project.", objectSchema(prop("fromAlias", stringSchema("Source alias")), prop("fromPath", stringSchema("Source relative path; omit only for a standalone file resource")), prop("toAlias", stringSchema("Destination writable alias")), prop("toPath", stringSchema("Destination relative path")), prop("overwrite", booleanSchema("Replace destination when it exists")), required("fromAlias","toAlias","toPath"))));
        t.add(tool("resource_move", "Move a file between explicitly supplied writable resources.", objectSchema(prop("fromAlias", stringSchema("Source writable alias")), prop("fromPath", stringSchema("Source relative path")), prop("toAlias", stringSchema("Destination writable alias")), prop("toPath", stringSchema("Destination relative path")), prop("overwrite", booleanSchema("Replace destination when it exists")), required("fromAlias","fromPath","toAlias","toPath"))));
        t.add(tool("resource_build", "Detect and build an explicitly supplied writable project resource.", objectSchema(prop("alias", stringSchema("Writable project alias")), required("alias"))));
        t.add(tool("resource_test", "Detect and run tests for an explicitly supplied writable project resource.", objectSchema(prop("alias", stringSchema("Writable project alias")), required("alias"))));
        t.add(tool("resource_check", "Run lint/type/static checks for an explicitly supplied writable project resource.", objectSchema(prop("alias", stringSchema("Writable project alias")), required("alias"))));
        t.add(tool("resource_bash", "Run a shell command rooted at an explicitly supplied writable project resource.", objectSchema(prop("alias", stringSchema("Writable project alias")), prop("command", stringSchema("Shell command")), prop("timeoutSeconds", integerSchema("Optional timeout; 0 means no application timeout")), prop("verification", booleanSchema("True when this command verifies the current fix")), required("alias","command"))));

        t.add(tool("attachment_list", "List files uploaded in the current conversation with extraction status and IDs.", emptyObject()));
        t.add(tool("attachment_read", "Read extracted text from an uploaded document progressively.", objectSchema(prop("fileId", stringSchema("Uploaded attachment ID")), prop("offset", integerSchema("Character offset")), prop("maxChars", integerSchema("Maximum characters; 0 returns all remaining")), required("fileId"))));
        t.add(tool("attachment_search", "Search extracted text across uploaded documents and return matching snippets.", objectSchema(prop("query", stringSchema("Literal text to search for")), prop("fileId", stringSchema("Optional attachment ID; omit to search all current-conversation attachments")), prop("maxMatches", integerSchema("Maximum matches; 0 uses a generous default")), required("query"))));

        t.add(tool("skill_catalog", "List discovered reusable SKILL.md definitions with descriptions.", emptyObject()));
        t.add(tool("skill", "Load a SKILL.md on demand when its reusable workflow is relevant.", objectSchema(prop("name", stringSchema("Discovered skill ID/name")), required("name"))));
        t.add(tool("agent_catalog", "List available built-in and project-defined subagents.", emptyObject()));
        t.add(tool("task", "Delegate a focused investigation or implementation to a fresh-context subagent and return its report.", objectSchema(prop("agent", stringSchema("Subagent ID, for example explore or general")), prop("prompt", stringSchema("Self-contained delegated task")), required("agent","prompt"))));

        t.add(tool("tool_search", "Discover and load relevant deferred specialized built-in or MCP tool definitions into the active model context. Use this when the compact default palette does not expose a capability you need.", objectSchema(prop("query", stringSchema("Capability or keyword, for example browser, playwright, database, jira")), prop("maxResults", integerSchema("Maximum tool definitions to load; default 12")), required("query"))));
        t.add(tool("mcp_status", "List configured MCP servers and discovery/connection status for this workspace without loading every MCP schema into the model context.", emptyObject()));
        t.add(tool("lsp_status", "List configured Language Server Protocol servers for this workspace.", emptyObject()));
        t.add(tool("lsp", "Query a configured language server for semantic code intelligence.", objectSchema(
                prop("operation", enumSchema("diagnostics","definition","references","hover","document_symbols","workspace_symbols")),
                prop("path", stringSchema("Relative workspace file path; optional only for workspace_symbols")),
                prop("line", integerSchema("0-based line for position operations")),
                prop("character", integerSchema("0-based character for position operations")),
                prop("query", stringSchema("Workspace symbol query")),
                prop("server", stringSchema("Optional configured LSP server name")),
                required("operation"))));

        t.add(tool("edit", "Make a targeted exact-text replacement in an existing file.", objectSchema(prop("path", stringSchema("Relative workspace file path")), prop("oldText", stringSchema("Exact existing text with enough context to be unique")), prop("newText", stringSchema("Replacement text")), prop("replaceAll", booleanSchema("Replace all exact occurrences")), required("path","oldText","newText"))));
        t.add(tool("write", "Create or replace a text file with complete final content.", objectSchema(prop("path", stringSchema("Relative workspace file path")), prop("content", stringSchema("Complete final file content")), required("path","content"))));
        t.add(tool("copy", "Copy a workspace file.", objectSchema(prop("from", stringSchema("Source relative path")), prop("to", stringSchema("Destination relative path")), prop("overwrite", booleanSchema("Replace destination when it exists")), required("from","to"))));
        t.add(tool("move", "Move or rename a workspace file.", objectSchema(prop("from", stringSchema("Source relative path")), prop("to", stringSchema("Destination relative path")), prop("overwrite", booleanSchema("Replace destination when it exists")), required("from","to"))));
        t.add(tool("delete", "Delete one workspace file. Directories are not deleted.", objectSchema(prop("path", stringSchema("Relative workspace file path")), required("path"))));
        t.add(tool("apply_patch", "Apply a workspace patch. Prefer the structured changes array. Compatibility also accepts OpenAI-style *** Begin Patch text in patch.", objectSchema(
                prop("changes", arrayOf(objectSchema(prop("path", stringSchema("Relative workspace file path")), prop("operation", enumSchema("write","delete")), prop("content", stringSchema("Complete content for write")), required("path","operation")))),
                prop("patch", stringSchema("Optional compatibility patch text using *** Begin Patch / *** Update File / *** Add File / *** Delete File")))));

        t.add(tool("build", "Detect and run the normal project build.", objectSchema(prop("cwd", stringSchema("Optional relative working directory")))));
        t.add(tool("test", "Detect and run the normal project test suite.", objectSchema(prop("cwd", stringSchema("Optional relative working directory")))));
        t.add(tool("check", "Detect and run lint/typecheck/static verification.", objectSchema(prop("cwd", stringSchema("Optional relative working directory")))));
        t.add(tool("bash", "Run a shell command directly in the live workspace. Pipes, redirects, chaining and normal Git developer workflows are supported.", objectSchema(prop("command", stringSchema("Shell command")), prop("cwd", stringSchema("Optional relative working directory")), prop("timeoutSeconds", integerSchema("Optional timeout; 0 means no application timeout")), prop("verification", booleanSchema("True when this command verifies the current fix")), required("command"))));
        t.add(tool("process_start", "Start a long-running application/server in the background.", objectSchema(prop("command", stringSchema("Shell command")), prop("cwd", stringSchema("Optional relative working directory")), required("command"))));
        t.add(tool("process_status", "Check a managed background process.", objectSchema(prop("processId", stringSchema("Managed process ID")), required("processId"))));
        t.add(tool("process_output", "Read captured output from a managed background process.", objectSchema(prop("processId", stringSchema("Managed process ID")), prop("offset", integerSchema("Character offset")), prop("maxChars", integerSchema("Chunk size; 0 returns all captured output")), required("processId"))));
        t.add(tool("process_stop", "Stop a managed background process and descendants.", objectSchema(prop("processId", stringSchema("Managed process ID")), required("processId"))));
        t.add(tool("http_request", "Call an HTTP/HTTPS endpoint and return real status, headers and body.", objectSchema(prop("method", stringSchema("HTTP method, default GET")), prop("url", stringSchema("Full URL")), prop("headers", arrayOf(stringSchema("Header in Name: value form"))), prop("body", stringSchema("Optional body")), prop("timeoutSeconds", integerSchema("Optional timeout; 0 uses client default")), prop("verification", booleanSchema("True when this request verifies the current fix")), required("url"))));

        t.add(tool("workspace_status", "List files changed by explicit agent actions during this run. Not Git.", emptyObject()));
        t.add(tool("workspace_diff", "Review direct workspace changes from this run relative to first-seen contents. Not Git.", objectSchema(prop("path", stringSchema("Optional changed relative path")))));
        t.add(tool("todowrite", "Create/replace a todo list only before plan approval. Approved Agent plans are locked and cannot be replaced.", objectSchema(prop("items", arrayOf(stringSchema("Concise todo item"))), required("items"))));
        t.add(tool("todoread", "Read the optional todo list.", emptyObject()));
        t.add(tool("todo_update", "Update only the currently unlocked execution-plan step. Approved steps cannot be skipped. Completing a step requires real tool activity and successful verification when that step changed code/config; the runtime unlocks the next step automatically.", objectSchema(prop("index", integerSchema("1-based plan item index")), prop("status", enumSchema("in_progress","completed","blocked")), prop("note", stringSchema("Optional short progress/evidence note")), required("index","status"))));

        builtIns = List.copyOf(t);
        LinkedHashSet<String> names = new LinkedHashSet<>();
        for (Map<String,Object> item : builtIns) {
            Object function=item.get("function"); if (function instanceof Map<?,?> m) names.add(String.valueOf(m.get("name")));
        }
        builtInNames = Set.copyOf(names);
        parallelReadOnly = Set.of("inspect_workspace","workspace_profile","list","glob","grep","file_info","file_index","read","read_chunk","read_many",
                "instruction_catalog","instructions_for","resource_catalog","resource_list","resource_info","resource_index","resource_read","resource_chunk","resource_grep",
                "attachment_list","attachment_read","attachment_search","skill_catalog","skill",
                "agent_catalog","tool_search","mcp_status","lsp_status","lsp","process_status","process_output","workspace_status","workspace_diff","todoread");

        Map<String,String> legacy = new LinkedHashMap<>();
        legacy.put("list_project","list"); legacy.put("glob_project","glob"); legacy.put("search_project","grep"); legacy.put("regex_search","grep");
        legacy.put("search","grep"); legacy.put("find","grep"); legacy.put("search_files","grep"); legacy.put("find_files","glob");
        legacy.put("read_file","read"); legacy.put("read_file_range","read"); legacy.put("read_files","read_many");
        legacy.put("edit_file","edit"); legacy.put("write_file","write"); legacy.put("copy_file","copy"); legacy.put("move_file","move"); legacy.put("delete_file","delete");
        legacy.put("run_command","bash"); legacy.put("shell","bash"); legacy.put("terminal","bash"); legacy.put("set_plan","todowrite"); legacy.put("get_plan","todoread"); legacy.put("run_build","build"); legacy.put("run_tests","test"); legacy.put("run_check","check"); legacy.put("changed_files","workspace_status"); legacy.put("update_plan","todo_update"); legacy.put("todoupdate","todo_update");
        legacy.put("applypatch","apply_patch"); legacy.put("patch","apply_patch");
        aliases = Map.copyOf(legacy);
    }

    public List<Map<String,Object>> builtInDefinitions() { return builtIns; }
    /** Compatibility alias used by tests/older code. */
    public List<Map<String,Object>> nativeDefinitions() { return builtIns; }

    public List<Map<String,Object>> mergedDefinitions(List<Map<String,Object>> dynamic) {
        if (dynamic == null || dynamic.isEmpty()) return builtIns;
        ArrayList<Map<String,Object>> all = new ArrayList<>(builtIns); all.addAll(dynamic); return List.copyOf(all);
    }

    public String canonical(String tool) {
        if (tool == null) return "";
        String value = sanitizeToolName(tool);
        if (builtInNames.contains(value)) return value;
        String lower = value.toLowerCase(Locale.ROOT);
        if (builtInNames.contains(lower)) return lower;
        return aliases.getOrDefault(lower, value);
    }

    /** Repair common provider serialization noise without weakening the tool allowlist. */
    String sanitizeToolName(String tool) {
        String value = tool == null ? "" : tool.trim();
        int markup = value.indexOf('<');
        if (markup > 0) value = value.substring(0, markup);
        int channel = value.indexOf("|channel|");
        if (channel > 0) value = value.substring(0, channel);
        value = value.replaceFirst("(?i)^(?:functions?|tools?)\\.", "");
        value = value.replaceAll("^[`'\"]+|[`'\"\\s]+$", "");
        value = value.replaceAll("[^A-Za-z0-9_.:-]+$", "");
        return value.trim();
    }

    public boolean isKnownBuiltIn(String tool) {
        String canonical=canonical(tool); return builtInNames.contains(canonical);
    }
    /** Backward-compatible built-in lookup used by existing tests/callers. Dynamic MCP tools are run-scoped. */
    public boolean isKnown(String tool) { return isKnownBuiltIn(tool); }

    public boolean isParallelReadOnly(String tool) { return parallelReadOnly.contains(canonical(tool)); }
    public Set<String> names() { return builtInNames; }

    public List<Map<String,Object>> filterDefinitions(List<Map<String,Object>> source, Set<String> allowed, boolean excludeTask) {
        List<Map<String,Object>> out = new ArrayList<>();
        for (Map<String,Object> item : source) {
            String name=functionName(item);
            if (excludeTask && "task".equals(name)) continue;
            if (allowed == null || allowed.isEmpty() || allowed.contains(name) || (name.startsWith("mcp__") && allowed.contains("mcp"))) out.add(item);
        }
        return List.copyOf(out);
    }

    public List<Map<String,Object>> searchDefinitions(List<Map<String,Object>> source, String query, int maxResults) {
        if (source == null || source.isEmpty()) return List.of();
        String q = query == null ? "" : query.trim().toLowerCase(Locale.ROOT);
        if (q.isBlank()) return List.of();
        LinkedHashSet<String> terms = new LinkedHashSet<>(Arrays.asList(q.split("[^a-z0-9_.-]+")));
        terms.removeIf(String::isBlank);
        int limit = maxResults <= 0 ? 12 : Math.min(40, maxResults);
        record Scored(Map<String,Object> definition, int score, String name) {}
        List<Scored> scored = new ArrayList<>();
        for (Map<String,Object> def : source) {
            String name = functionName(def);
            Object f = def.get("function");
            String description = f instanceof Map<?,?> m ? String.valueOf(m.get("description")) : "";
            String haystack = (name + " " + description).toLowerCase(Locale.ROOT);
            int score = haystack.contains(q) ? 20 : 0;
            for (String term : terms) if (haystack.contains(term)) score += name.toLowerCase(Locale.ROOT).contains(term) ? 5 : 2;
            if (score > 0) scored.add(new Scored(def, score, name));
        }
        scored.sort(Comparator.comparingInt(Scored::score).reversed().thenComparing(Scored::name));
        return scored.stream().limit(limit).map(Scored::definition).toList();
    }

    public String functionName(Map<String,Object> definition) {
        Object f=definition.get("function"); return f instanceof Map<?,?> m ? String.valueOf(m.get("name")) : "";
    }

    private static Map<String,Object> tool(String name,String description,Map<String,Object> parameters) { return Map.of("type","function","function",Map.of("name",name,"description",description,"parameters",parameters)); }
    @SafeVarargs private static Map<String,Object> objectSchema(Map.Entry<String,Object>... entries) {
        LinkedHashMap<String,Object> properties=new LinkedHashMap<>(); List<String> required=new ArrayList<>();
        for (Map.Entry<String,Object> e:entries) { if ("__required__".equals(e.getKey())) { if(e.getValue() instanceof Collection<?> c) for(Object x:c) required.add(String.valueOf(x)); } else properties.put(e.getKey(),e.getValue()); }
        LinkedHashMap<String,Object> s=new LinkedHashMap<>(); s.put("type","object"); s.put("properties",properties); s.put("additionalProperties",false); if(!required.isEmpty()) s.put("required",required); return s;
    }
    private static Map<String,Object> emptyObject(){ return Map.of("type","object","properties",Map.of(),"additionalProperties",false); }
    private static Map.Entry<String,Object> prop(String n,Object s){ return Map.entry(n,s); }
    private static Map.Entry<String,Object> required(String... n){ return Map.entry("__required__",List.of(n)); }
    private static Map<String,Object> stringSchema(String d){ return Map.of("type","string","description",d); }
    private static Map<String,Object> integerSchema(String d){ return Map.of("type","integer","description",d); }
    private static Map<String,Object> booleanSchema(String d){ return Map.of("type","boolean","description",d); }
    private static Map<String,Object> enumSchema(String... v){ return Map.of("type","string","enum",List.of(v)); }
    private static Map<String,Object> arrayOf(Object s){ return Map.of("type","array","items",s); }
}
