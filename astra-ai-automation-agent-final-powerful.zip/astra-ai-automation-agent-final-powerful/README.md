# Astra AI Automation Agent - Final Generic Agent

This project is a Spring Boot UI application that uses Playwright MCP as the live browser execution layer and your configured LLM as the planning/code-generation layer.

## What is improved in this build

- Test Data field is **not mandatory**.
- The agent extracts data from the Scenario/Flow, Test Data, and Pre-action Instructions.
- Test Data can be JSON, key=value, key:value, or normal sentence format.
- High-level prompts like `login`, `sign on`, `search reference`, or `click Service Company` are converted into live browser actions.
- Login is handled generically: after username and password are typed, the agent looks for visible `Sign On`, `Login`, `Sign in`, `Submit`, or `Continue` and clicks it before moving to the next business action.
- Actions happen in one continuous MCP browser session, so the browser should not open/close for every action.
- Generated code is based on the successful live action trace, not on imaginary steps.
- Healer is optional. Enable it only when you want the generated Playwright test to be validated and repaired.

## Agent flow

1. **Planner Agent** understands the high-level scenario and creates safe browser goals.
2. **Executor Agent** opens the browser and performs live UI actions through Playwright MCP.
3. **Generator Agent** converts the successful trace into the selected framework/language.
4. **Healer Agent** is optional. It validates generated code and repairs it when validation fails.

## How to run on Windows

```powershell
cd <extracted-folder>
mvn clean spring-boot:run
```

Then open:

```text
http://localhost:8090/index.html
```

## Playwright MCP

The app starts Playwright MCP automatically using:

```powershell
npx -y @playwright/mcp@latest
```

Node.js must already be installed. The app uses stdio MCP, not the old HTTP `/mcp` endpoint, so you should not manually post to `http://localhost:8931/mcp`.

## Recommended first-run settings

- Show browser live: ON
- Ignore SSL errors: ON
- Plan before execution: ON
- Save generated code: ON
- Validate generated code: OFF for first trial
- Enable Healer Agent: OFF until basic live flow is stable
- Close browser after run: OFF
- Action delay: 1500 to 2500 ms
- Max steps: 25
- Min confidence: 45 to 60

## Example scenario without Test Data field

```gherkin
Scenario: Create a car request manually in AURA
Given user launches new Aura Application
When the user logs in with username "f44075" and password "Loop4149#" and clicks on sign on button
Then the user clicks the "Service Company" option
```

The Test Data box can be empty for the above scenario.

## Example Test Data formats

JSON:

```json
{
  "username": "f44075",
  "password": "Loop4149#",
  "agreementReference": "0002011/001 EUR"
}
```

Key-value:

```text
username=f44075
password=Loop4149#
agreementReference=0002011/001 EUR
```

Free text:

```text
username "f44075" and password "Loop4149#" and reference "0002011/001 EUR"
```

## Important usage note

This is a generic browser agent, not a recorded script player. For best results, write the business goal clearly, but you do not need to teach every user exact MCP steps. Example: `login using username "x" and password "y", then open Service Company and search reference "0002011/001 EUR"`.
