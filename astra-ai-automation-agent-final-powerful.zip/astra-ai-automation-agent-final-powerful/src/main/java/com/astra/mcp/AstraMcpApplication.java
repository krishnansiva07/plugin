package com.astra.mcp;
import org.springframework.boot.SpringApplication;import org.springframework.boot.autoconfigure.SpringBootApplication;
@SpringBootApplication public class AstraMcpApplication{public static void main(String[]a){SpringApplication.run(AstraMcpApplication.class,a);}}
