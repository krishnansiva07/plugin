package com.astra.mcp.controller;

import com.astra.mcp.dto.AgentRequest;
import com.astra.mcp.dto.AgentResponse;
import com.astra.mcp.service.AstraAgentService;
import com.astra.mcp.service.McpClientService;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/astra")
public class AstraController {
    private final AstraAgentService agent;
    private final McpClientService mcp;

    public AstraController(AstraAgentService agent, McpClientService mcp) {
        this.agent = agent;
        this.mcp = mcp;
    }

    @PostMapping("/run")
    public AgentResponse run(@RequestBody AgentRequest request) {
        return agent.run(request);
    }

    @PostMapping("/mcp/start")
    public String start(@RequestBody(required = false) Map<String, Object> body) {
        boolean ignoreHttpsErrors = body == null || Boolean.parseBoolean(String.valueOf(body.getOrDefault("ignoreHttpsErrors", true)));
        String userDataDir = body == null ? "C:/Temp/astra-mcp-profile" : String.valueOf(body.getOrDefault("userDataDir", "C:/Temp/astra-mcp-profile"));
        String startStatus = mcp.start(ignoreHttpsErrors, userDataDir);
        mcp.initialize();
        return startStatus + " / INITIALIZED";
    }

    @PostMapping("/mcp/stop")
    public String stop() {
        return mcp.stop();
    }

    @GetMapping("/mcp/status")
    public String status() {
        return mcp.isRunning() ? "RUNNING_STDIO" : "STOPPED";
    }

    @PostMapping("/mcp/reset")
    public String reset() {
        mcp.reset();
        return "RESET";
    }
}
