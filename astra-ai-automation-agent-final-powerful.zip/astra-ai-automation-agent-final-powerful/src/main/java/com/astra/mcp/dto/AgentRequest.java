package com.astra.mcp.dto;

public class AgentRequest {
    public String applicationUrl;
    public String scenario;
    public String testDataJson;
    public String expectedResult;
    public String targetFramework = "PLAYWRIGHT_TYPESCRIPT";
    public String projectPath;
    public String testFileName = "astra-generated.spec.ts";

    public boolean saveToProject = true;
    public boolean validateGeneratedCode = true;
    public boolean autoRepair = true;
    public int maxRepairAttempts = 1;

    public boolean headed = true;
    public boolean closeBrowserAfterRun = false;
    public boolean ignoreHttpsErrors = true;
    public boolean isolatedProfile = true;
    public String userDataDir = "C:/Temp/astra-mcp-profile";

    public int liveActionDelayMs = 1200;
    public int maxAgentSteps = 12;
    public String preActionInstructions = "";

    // Advanced agent controls
    public boolean generatePlan = true;
    public boolean strictNoGuessing = true;
    public int minActionConfidence = 60;
    public boolean manualAssistBeforeRun = false;
    public int manualAssistWaitSeconds = 0;
}
