package com.astra.mcp.dto;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class AgentResponse {
    public String status;
    public String validationStatus;
    public String message;
    public String planStatus;
    public String generatedCode;
    public String savedFilePath;
    public String validationOutput;
    public String finalSnapshot;
    public String rawLog;

    public List<String> missingData = new ArrayList<>();
    public List<Map<String, Object>> executionPlan = new ArrayList<>();
    public List<Map<String, Object>> actionTrace = new ArrayList<>();
    public List<Map<String, Object>> repairHistory = new ArrayList<>();
}
