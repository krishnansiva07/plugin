package com.astra.mcp.service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.stereotype.Service;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;

@Service
public class McpClientService {

    private final ObjectMapper objectMapper = new ObjectMapper();
    private final AtomicLong requestId = new AtomicLong(1);
    private final Map<Long, CompletableFuture<Map<String, Object>>> pending = new ConcurrentHashMap<>();

    private Process process;
    private BufferedWriter writer;
    private Thread stdoutThread;
    private Thread stderrThread;
    private volatile boolean initialized = false;

    public synchronized String start(boolean ignoreHttpsErrors, String userDataDir) {
        if (isRunning()) {
            return "RUNNING";
        }

        try {
            List<String> command = new ArrayList<>();
            command.add("cmd.exe");
            command.add("/c");
            command.add("npx.cmd");
            command.add("-y");
            command.add("@playwright/mcp@latest");

            if (ignoreHttpsErrors) {
                command.add("--ignore-https-errors");
            }

            if (userDataDir != null && !userDataDir.isBlank()) {
                command.add("--user-data-dir");
                command.add(userDataDir);
            }

            ProcessBuilder processBuilder = new ProcessBuilder(command);
            processBuilder.redirectErrorStream(false);
            process = processBuilder.start();
            writer = new BufferedWriter(new OutputStreamWriter(process.getOutputStream(), StandardCharsets.UTF_8));
            initialized = false;

            startStdoutReader();
            startStderrReader();

            return "STARTED_STDIO";
        } catch (Exception e) {
            return "ERROR: " + e.getMessage();
        }
    }

    public synchronized String stop() {
        try {
            if (process != null && process.isAlive()) {
                process.destroy();
            }
        } finally {
            process = null;
            writer = null;
            pending.clear();
            initialized = false;
        }
        return "STOPPED";
    }

    public synchronized void reset() {
        stop();
    }

    public synchronized boolean isRunning() {
        return process != null && process.isAlive() && writer != null;
    }

    public synchronized void initialize() {
        if (!isRunning()) {
            throw new RuntimeException("MCP stdio process is not running. Start MCP before initialize.");
        }
        if (initialized) {
            return;
        }

        Map<String, Object> response = call("initialize", Map.of(
                "protocolVersion", "2025-06-18",
                "capabilities", Map.of(),
                "clientInfo", Map.of(
                        "name", "astra-java-playwright-mcp-stdio-client",
                        "version", "1.0.0"
                )
        ));

        if (isError(response)) {
            throw new RuntimeException("MCP initialize failed: " + response);
        }

        notify("notifications/initialized", Map.of());
        initialized = true;
    }

    public Map<String, Object> tools() {
        return call("tools/list", Map.of());
    }

    public Map<String, Object> tool(String toolName, Map<String, Object> arguments) {
        Map<String, Object> safeArguments = normalizeToolArguments(arguments);
        return call("tools/call", Map.of(
                "name", toolName,
                "arguments", safeArguments
        ));
    }

    public String snapshot() {
        Map<String, Object> result = tool("browser_snapshot", Map.of());
        return String.valueOf(result);
    }

    public boolean isError(Map<String, Object> result) {
        if (result == null) {
            return true;
        }
        if (result.containsKey("error")) {
            return true;
        }
        Object nestedError = result.get("isError");
        return nestedError instanceof Boolean b && b;
    }

    public boolean isSessionNotFound(Map<String, Object> result) {
        if (result == null) {
            return false;
        }
        String text = String.valueOf(result).toLowerCase();
        return text.contains("session not found");
    }

    public Map<String, Object> call(String method, Object params) {
        long id = requestId.getAndIncrement();
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("jsonrpc", "2.0");
        body.put("id", id);
        body.put("method", method);
        body.put("params", params == null ? Map.of() : params);

        CompletableFuture<Map<String, Object>> future = new CompletableFuture<>();
        pending.put(id, future);
        send(body);

        try {
            Map<String, Object> response = future.get(120, TimeUnit.SECONDS);
            if (response.containsKey("error")) {
                return response;
            }
            Object result = response.get("result");
            if (result instanceof Map<?, ?> map) {
                return toStringObjectMap(map);
            }
            return response;
        } catch (Exception e) {
            pending.remove(id);
            return Map.of(
                    "error", "MCP_STDIO_TIMEOUT_OR_FAILURE",
                    "method", method,
                    "message", e.getMessage() == null ? e.toString() : e.getMessage()
            );
        }
    }

    public void notify(String method, Object params) {
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("jsonrpc", "2.0");
        body.put("method", method);
        body.put("params", params == null ? Map.of() : params);
        send(body);
    }

    private synchronized void send(Map<String, Object> body) {
        if (!isRunning()) {
            throw new RuntimeException("MCP stdio process is not running.");
        }
        try {
            String json = objectMapper.writeValueAsString(body);
            writer.write(json);
            writer.newLine();
            writer.flush();
        } catch (Exception e) {
            throw new RuntimeException("Failed to send MCP stdio message: " + e.getMessage(), e);
        }
    }

    private void startStdoutReader() {
        stdoutThread = new Thread(() -> {
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream(), StandardCharsets.UTF_8))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    if (line.isBlank()) {
                        continue;
                    }
                    handleStdoutLine(line);
                }
            } catch (Exception e) {
                failAllPending("MCP stdout reader stopped: " + e.getMessage());
            }
        }, "astra-mcp-stdio-stdout-reader");
        stdoutThread.setDaemon(true);
        stdoutThread.start();
    }

    private void startStderrReader() {
        stderrThread = new Thread(() -> {
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getErrorStream(), StandardCharsets.UTF_8))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    System.out.println("[MCP-STDERR] " + line);
                }
            } catch (Exception ignored) {
            }
        }, "astra-mcp-stdio-stderr-reader");
        stderrThread.setDaemon(true);
        stderrThread.start();
    }

    private void handleStdoutLine(String line) {
        try {
            Map<String, Object> message = objectMapper.readValue(line, new TypeReference<Map<String, Object>>() {});
            Object idValue = message.get("id");
            if (idValue instanceof Number number) {
                CompletableFuture<Map<String, Object>> future = pending.remove(number.longValue());
                if (future != null) {
                    future.complete(message);
                }
            } else if (idValue instanceof String text) {
                try {
                    CompletableFuture<Map<String, Object>> future = pending.remove(Long.parseLong(text));
                    if (future != null) {
                        future.complete(message);
                    }
                } catch (NumberFormatException ignored) {
                    System.out.println("[MCP-STDOUT] " + line);
                }
            } else {
                System.out.println("[MCP-STDOUT] " + line);
            }
        } catch (Exception e) {
            System.out.println("[MCP-STDOUT-NONJSON] " + line);
        }
    }

    private void failAllPending(String message) {
        Map<String, Object> error = Map.of("error", "MCP_STDIO_CLOSED", "message", message);
        for (CompletableFuture<Map<String, Object>> future : pending.values()) {
            future.complete(error);
        }
        pending.clear();
    }

    private Map<String, Object> normalizeToolArguments(Map<String, Object> arguments) {
        Map<String, Object> normalized = new LinkedHashMap<>();
        if (arguments != null) {
            normalized.putAll(arguments);
        }

        if (!normalized.containsKey("target") && normalized.containsKey("ref")) {
            normalized.put("target", normalized.get("ref"));
            normalized.remove("ref");
        }

        if (normalized.containsKey("value") && !normalized.containsKey("values")) {
            normalized.put("values", List.of(String.valueOf(normalized.get("value"))));
            normalized.remove("value");
        }

        return normalized;
    }

    private Map<String, Object> toStringObjectMap(Map<?, ?> map) {
        Map<String, Object> result = new LinkedHashMap<>();
        for (Map.Entry<?, ?> entry : map.entrySet()) {
            result.put(String.valueOf(entry.getKey()), entry.getValue());
        }
        return result;
    }
}
