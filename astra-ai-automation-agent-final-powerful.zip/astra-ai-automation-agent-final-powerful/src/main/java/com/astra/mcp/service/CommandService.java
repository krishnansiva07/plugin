package com.astra.mcp.service;

import org.springframework.stereotype.Service;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.concurrent.TimeUnit;

@Service
public class CommandService {
    public String run(List<String> command, File workingDirectory, int timeoutSeconds) {
        StringBuilder output = new StringBuilder();
        try {
            ProcessBuilder builder = new ProcessBuilder(command);
            if (workingDirectory != null) {
                builder.directory(workingDirectory);
            }
            builder.redirectErrorStream(true);
            Process process = builder.start();

            Thread readerThread = new Thread(() -> {
                try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream(), StandardCharsets.UTF_8))) {
                    String line;
                    while ((line = reader.readLine()) != null) {
                        synchronized (output) {
                            output.append(line).append(System.lineSeparator());
                        }
                    }
                } catch (Exception e) {
                    synchronized (output) {
                        output.append("OUTPUT_READER_ERROR: ").append(e.getMessage()).append(System.lineSeparator());
                    }
                }
            }, "astra-command-output-reader");
            readerThread.setDaemon(true);
            readerThread.start();

            boolean finished = process.waitFor(timeoutSeconds, TimeUnit.SECONDS);
            if (!finished) {
                process.destroyForcibly();
                synchronized (output) {
                    output.append("COMMAND_TIMEOUT_AFTER_SECONDS=").append(timeoutSeconds).append(System.lineSeparator());
                    output.append("EXIT_CODE=-1");
                }
                return output.toString();
            }
            readerThread.join(2000);
            synchronized (output) {
                output.append(System.lineSeparator()).append("EXIT_CODE=").append(process.exitValue());
                return output.toString();
            }
        } catch (Exception e) {
            synchronized (output) {
                output.append("COMMAND_ERROR: ").append(e.getMessage());
                return output.toString();
            }
        }
    }
}
