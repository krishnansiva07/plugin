package com.astra.mcp.config;
import dev.langchain4j.model.chat.ChatLanguageModel;import dev.langchain4j.model.openai.OpenAiChatModel;import org.springframework.beans.factory.annotation.Value;import org.springframework.context.annotation.*;import java.time.Duration;
@Configuration public class ChatConfig{
 @Value("${llm.api-key}") String key; @Value("${llm.base-url}") String url; @Value("${llm.model-name}") String model;
 @Bean ChatLanguageModel chatLanguageModel(){return OpenAiChatModel.builder().apiKey(key).baseUrl(url).modelName(model).temperature(0.1).maxTokens(4096).timeout(Duration.ofSeconds(180)).build();}
}
