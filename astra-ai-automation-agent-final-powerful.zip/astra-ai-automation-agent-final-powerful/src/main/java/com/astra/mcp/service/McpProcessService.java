package com.astra.mcp.service;

import org.springframework.stereotype.Service;

@Service
public class McpProcessService {
    // V10 uses MCP stdio transport in McpClientService for stable multi-step browser sessions.
}
