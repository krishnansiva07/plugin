package com.llmart.llm.service;

import com.llmart.llm.dto.TestCaseGenerationResponse;
import com.llmart.llm.exception.TcgenException;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@Service
public class TestCaseGeneratorService {

    private final FileTextExtractor fileTextExtractor;
    private final PromptBuilder promptBuilder;
    private final JsonResponseParser jsonResponseParser;
    private final LlmClient llmClient;
    private final ColumnSelectionService columnSelectionService;
    private final ExcelExpectedColumnsService excelExpectedColumnsService;

    public TestCaseGeneratorService(FileTextExtractor fileTextExtractor,
                                    PromptBuilder promptBuilder,
                                    JsonResponseParser jsonResponseParser,
                                    LlmClient llmClient,
                                    ColumnSelectionService columnSelectionService,
                                    ExcelExpectedColumnsService excelExpectedColumnsService) {
        this.fileTextExtractor = fileTextExtractor;
        this.promptBuilder = promptBuilder;
        this.jsonResponseParser = jsonResponseParser;
        this.llmClient = llmClient;
        this.columnSelectionService = columnSelectionService;
        this.excelExpectedColumnsService = excelExpectedColumnsService;
    }

    public TestCaseGenerationResponse generate(MultipartFile requirementsFile,
                                               MultipartFile expectedColumnsFile,
                                               String additionalPrompt,
                                               String apiKey,
                                               String modelName,
                                               String baseUrl,
                                               String selectedColumnsCsv,
                                               String fileUnderstandingMode,
                                               boolean useUploadedExcelColumns) {
        List<String> selectedColumns = resolveOutputColumns(requirementsFile, expectedColumnsFile, selectedColumnsCsv, useUploadedExcelColumns);
        String acceptanceCriteriaText = fileTextExtractor.extract(requirementsFile);
        String prompt = promptBuilder.buildPrompt(acceptanceCriteriaText, additionalPrompt, selectedColumns, fileUnderstandingMode);

        try {
            String llmResponse = llmClient.generate(prompt, apiKey, modelName, baseUrl);
            TestCaseGenerationResponse response = jsonResponseParser.parse(llmResponse, selectedColumns);
            response.setSourceFileName(requirementsFile.getOriginalFilename());
            return response;
        } catch (TcgenException ex) {
            throw ex;
        } catch (Exception ex) {
            throw new TcgenException("Failed to generate test cases from LLM.", ex);
        }
    }

    private List<String> resolveOutputColumns(MultipartFile requirementsFile,
                                              MultipartFile expectedColumnsFile,
                                              String selectedColumnsCsv,
                                              boolean useUploadedExcelColumns) {
        if (useUploadedExcelColumns) {
            List<String> columnTemplateColumns = excelExpectedColumnsService.detectExpectedColumnsFromSeparateExcel(expectedColumnsFile);
            if (!columnTemplateColumns.isEmpty()) {
                return columnTemplateColumns;
            }

            List<String> requirementExcelColumns = excelExpectedColumnsService.detectExpectedColumns(requirementsFile);
            if (!requirementExcelColumns.isEmpty()) {
                return requirementExcelColumns;
            }
        }

        if (StringUtils.hasText(selectedColumnsCsv)) {
            return columnSelectionService.resolveColumns(selectedColumnsCsv);
        }
        return columnSelectionService.defaultColumns();
    }
}
