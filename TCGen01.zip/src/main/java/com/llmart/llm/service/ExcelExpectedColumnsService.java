package com.llmart.llm.service;

import com.llmart.llm.exception.TcgenException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

@Service
public class ExcelExpectedColumnsService {

    private static final int MAX_ROWS_TO_SCAN = 80;

    private static final Set<String> EXPECTED_SCHEMA_SHEET_NAMES = Set.of(
            "outputschema", "output_schema", "outputcolumns", "output_columns",
            "expectedcolumns", "expected_columns", "columns", "testcaseformat",
            "test_case_format", "testcase_format", "format", "schema"
    );

    private static final Set<String> KNOWN_TEST_CASE_COLUMNS = Set.of(
            "testid", "tcid", "testcaseid", "testcase", "scenario", "testscenario",
            "module", "requirementid", "reqid", "acmapping", "precondition", "preconditions",
            "teststeps", "steps", "action", "testdata", "expectedresult", "expectedresults",
            "priority", "severity", "testtype", "type", "automationcandidate", "apiendpoint",
            "apimethod", "requestpayload", "statuscode", "dbvalidation", "uivalidation",
            "feature", "given", "when", "then", "examples", "tags", "remark", "remarks",
            "risk", "sprint", "jiraid", "owner", "comments", "application", "component"
    );

    /**
     * Use this when the requirements itself is an Excel file. This stays conservative, so TCGen does not
     * accidentally treat normal AC columns as the expected test-case output schema unless it looks like a schema.
     */
    public List<String> detectExpectedColumns(MultipartFile file) {
        if (file == null || file.isEmpty() || !isExcelFile(file.getOriginalFilename())) {
            return List.of();
        }

        try (Workbook workbook = WorkbookFactory.create(new ByteArrayInputStream(file.getBytes()))) {
            List<String> fromSchemaSheet = detectFromSchemaSheets(workbook);
            if (!fromSchemaSheet.isEmpty()) {
                return fromSchemaSheet;
            }

            List<String> fromAnyColumnSheet = detectFromColumnDefinitionTables(workbook);
            if (!fromAnyColumnSheet.isEmpty()) {
                return fromAnyColumnSheet;
            }

            return detectFromHeaderRows(workbook, true);
        } catch (IOException ex) {
            throw new TcgenException("Unable to read expected columns from uploaded Excel file.", ex);
        }
    }

    /**
     * Use this when the user uploads a separate Excel template only for output columns.
     * The first non-empty row is treated as the expected output column list.
     */
    public List<String> detectExpectedColumnsFromSeparateExcel(MultipartFile file) {
        if (file == null || file.isEmpty() || !isExcelFile(file.getOriginalFilename())) {
            return List.of();
        }

        try (Workbook workbook = WorkbookFactory.create(new ByteArrayInputStream(file.getBytes()))) {
            List<String> fromFirstRow = detectFromFirstNonEmptyRow(workbook);
            if (!fromFirstRow.isEmpty()) {
                return fromFirstRow;
            }

            List<String> fromSchemaSheet = detectFromSchemaSheets(workbook);
            if (!fromSchemaSheet.isEmpty()) {
                return fromSchemaSheet;
            }

            List<String> fromAnyColumnSheet = detectFromColumnDefinitionTables(workbook);
            if (!fromAnyColumnSheet.isEmpty()) {
                return fromAnyColumnSheet;
            }

            return detectFromHeaderRows(workbook, false);
        } catch (IOException ex) {
            throw new TcgenException("Unable to read expected columns from column template Excel file.", ex);
        }
    }

    public boolean isExcelFile(String fileName) {
        if (fileName == null) {
            return false;
        }
        String lower = fileName.toLowerCase(Locale.ROOT);
        return lower.endsWith(".xls") || lower.endsWith(".xlsx");
    }

    private List<String> detectFromFirstNonEmptyRow(Workbook workbook) {
        DataFormatter formatter = new DataFormatter();
        for (Sheet sheet : workbook) {
            int lastRow = Math.min(sheet.getLastRowNum(), MAX_ROWS_TO_SCAN);
            for (int rowIndex = sheet.getFirstRowNum(); rowIndex <= lastRow; rowIndex++) {
                Row row = sheet.getRow(rowIndex);
                if (row == null) {
                    continue;
                }
                List<String> rowValues = getNonEmptyRowValues(row, formatter);
                if (rowValues.size() >= 2 && !looksLikeColumnDefinitionHeader(rowValues)) {
                    return normalizeDetectedColumns(rowValues);
                }
            }
        }
        return List.of();
    }

    private boolean looksLikeColumnDefinitionHeader(List<String> rowValues) {
        Set<String> normalized = new LinkedHashSet<>();
        rowValues.forEach(value -> normalized.add(normalize(value)));
        return normalized.contains("column") || normalized.contains("columns")
                || normalized.contains("expectedcolumn") || normalized.contains("outputcolumn");
    }

    private List<String> detectFromSchemaSheets(Workbook workbook) {
        for (Sheet sheet : workbook) {
            String normalizedSheetName = normalize(sheet.getSheetName());
            if (EXPECTED_SCHEMA_SHEET_NAMES.contains(normalizedSheetName)) {
                List<String> columns = detectFromColumnDefinitionTable(sheet);
                if (!columns.isEmpty()) {
                    return columns;
                }
                columns = detectHeaderLikeRow(sheet, false);
                if (!columns.isEmpty()) {
                    return columns;
                }
            }
        }
        return List.of();
    }

    private List<String> detectFromColumnDefinitionTables(Workbook workbook) {
        for (Sheet sheet : workbook) {
            List<String> columns = detectFromColumnDefinitionTable(sheet);
            if (!columns.isEmpty()) {
                return columns;
            }
        }
        return List.of();
    }

    private List<String> detectFromColumnDefinitionTable(Sheet sheet) {
        DataFormatter formatter = new DataFormatter();
        int lastRow = Math.min(sheet.getLastRowNum(), MAX_ROWS_TO_SCAN);

        for (int rowIndex = sheet.getFirstRowNum(); rowIndex <= lastRow; rowIndex++) {
            Row row = sheet.getRow(rowIndex);
            if (row == null) {
                continue;
            }

            int columnHeaderIndex = findColumnHeaderIndex(row, formatter);
            if (columnHeaderIndex < 0) {
                continue;
            }

            List<String> columns = new ArrayList<>();
            for (int nextRowIndex = rowIndex + 1; nextRowIndex <= sheet.getLastRowNum(); nextRowIndex++) {
                Row dataRow = sheet.getRow(nextRowIndex);
                if (dataRow == null) {
                    continue;
                }

                String value = cleanCell(formatter.formatCellValue(dataRow.getCell(columnHeaderIndex)));
                if (value.isBlank()) {
                    continue;
                }

                if (value.length() > 80 || value.toLowerCase(Locale.ROOT).contains("prompt example")) {
                    break;
                }
                addColumn(columns, value);
            }

            if (columns.size() >= 2) {
                return columns;
            }
        }
        return List.of();
    }

    private int findColumnHeaderIndex(Row row, DataFormatter formatter) {
        for (Cell cell : row) {
            String value = normalize(formatter.formatCellValue(cell));
            if ("column".equals(value) || "columns".equals(value) || "expectedcolumn".equals(value)
                    || "expectedcolumns".equals(value) || "outputcolumn".equals(value) || "outputcolumns".equals(value)) {
                return cell.getColumnIndex();
            }
        }
        return -1;
    }

    private List<String> detectFromHeaderRows(Workbook workbook, boolean requireKnownHeaders) {
        for (Sheet sheet : workbook) {
            List<String> columns = detectHeaderLikeRow(sheet, requireKnownHeaders);
            if (!columns.isEmpty()) {
                return columns;
            }
        }
        return List.of();
    }

    private List<String> detectHeaderLikeRow(Sheet sheet, boolean requireKnownHeaders) {
        DataFormatter formatter = new DataFormatter();
        int lastRow = Math.min(sheet.getLastRowNum(), MAX_ROWS_TO_SCAN);

        for (int rowIndex = sheet.getFirstRowNum(); rowIndex <= lastRow; rowIndex++) {
            Row row = sheet.getRow(rowIndex);
            if (row == null) {
                continue;
            }

            List<String> rowValues = getNonEmptyRowValues(row, formatter);
            if (rowValues.size() < 2) {
                continue;
            }

            long knownCount = rowValues.stream()
                    .map(this::normalize)
                    .filter(KNOWN_TEST_CASE_COLUMNS::contains)
                    .count();

            boolean looksLikeOutputHeader = !requireKnownHeaders || knownCount >= 2 || containsStrongHeaderCombination(rowValues);
            if (looksLikeOutputHeader) {
                return normalizeDetectedColumns(rowValues);
            }
        }
        return List.of();
    }

    private List<String> getNonEmptyRowValues(Row row, DataFormatter formatter) {
        List<String> values = new ArrayList<>();
        short lastCellNum = row.getLastCellNum();
        if (lastCellNum < 0) {
            return values;
        }
        for (int cellIndex = row.getFirstCellNum(); cellIndex < lastCellNum; cellIndex++) {
            Cell cell = row.getCell(cellIndex);
            if (cell == null || cell.getCellType() == CellType.BLANK) {
                continue;
            }
            String value = cleanCell(formatter.formatCellValue(cell));
            if (!value.isBlank()) {
                values.add(value);
            }
        }
        return values;
    }

    private boolean containsStrongHeaderCombination(List<String> values) {
        Set<String> normalized = new LinkedHashSet<>();
        values.forEach(value -> normalized.add(normalize(value)));
        return normalized.containsAll(Arrays.asList("scenario", "expectedresult", "priority"))
                || normalized.containsAll(Arrays.asList("teststeps", "expectedresult", "testdata"))
                || normalized.containsAll(Arrays.asList("given", "when", "then"));
    }

    private List<String> normalizeDetectedColumns(List<String> detectedValues) {
        List<String> columns = new ArrayList<>();
        for (String value : detectedValues) {
            addColumn(columns, value);
        }
        return columns;
    }

    private void addColumn(List<String> columns, String value) {
        String cleanValue = cleanCell(value);
        if (cleanValue.isBlank() || isSerialNumberColumn(cleanValue)) {
            return;
        }
        boolean alreadyPresent = columns.stream().anyMatch(existing -> normalize(existing).equals(normalize(cleanValue)));
        if (!alreadyPresent) {
            columns.add(cleanValue);
        }
    }

    private String cleanCell(String value) {
        return value == null ? "" : value
                .replace('\u00A0', ' ')
                .replaceAll("\\s+", " ")
                .trim();
    }

    private boolean isSerialNumberColumn(String value) {
        String normalized = normalize(value);
        return "sno".equals(normalized) || "serialno".equals(normalized) || "serialnumber".equals(normalized);
    }

    private String normalize(String value) {
        return value == null ? "" : value.replaceAll("[^A-Za-z0-9]", "").toLowerCase(Locale.ROOT);
    }
}
