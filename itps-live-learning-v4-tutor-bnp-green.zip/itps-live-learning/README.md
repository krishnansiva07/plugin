# ITPS Live Learning Platform

Generic live learning platform using Spring Boot, Java 17 and LangChain4j.

## Latest V4 updates

- Fixed `[object Object]` tab issue.
- Tabs now support only valid string labels in UI.
- If a tab/subtopic has no content, it is not shown in the UI.
- Added learning depth selector:
  - Basics
  - Intermediate
  - Advanced
  - Basics to Advanced
- Roadmap generation now thinks like a tutor/textbook:
  - Basics first
  - Intermediate next
  - Advanced next
  - Quiz / Assessment at the end
- Roadmap is no longer forced to exactly 10 items. It is based on the requested topic.
- Content generation improved for technical and functional topics.
- Technical topics can include code/query examples and practice tasks.
- Functional topics focus on business purpose, actors, lifecycle, process flow, exceptions, and examples.
- BNP green design theme added.
- Quiz still opens as a separate page.
- Each quiz question loads live one by one.
- Programming/database topics get 1 or 2 coding exercises.
- Certificate title can be selected or customized.
- Add Note removed.
- Download current page as PDF retained.
- Copy button retained for code areas.

## Run

```bash
mvn clean spring-boot:run
```

Open:

```text
http://localhost:8090/index.html
```

## Configure LLM

Edit:

```text
src/main/resources/application.properties
```

```properties
llm.api-key=YOUR_KEY
llm.model-name=devstral-medium-2512
llm.base-url=YOUR_BASE_URL
```

Recommended: use environment variables instead of committing real keys.

```bash
set LLM_API_KEY=your-key
set LLM_MODEL_NAME=devstral-medium-2512
set LLM_BASE_URL=https://your-llm-endpoint/v1
```
