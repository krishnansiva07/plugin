let roadmap=null,currentIndex=0,currentTopic='',currentCategory='CUSTOM',currentContent=null,activeTab='';
let quizSession=null;
const $=id=>document.getElementById(id);

async function post(url, body){
  const res=await fetch(url,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
  return await res.json();
}

function selectedLevel(){ return $('levelSelect')?.value || 'Complete'; }

async function generateRoadmap(){
  const prompt=$('search').value.trim()||'SEPA Payment';
  showLearningView();
  roadmap=await post('/api/learning/roadmap',{userPrompt:prompt,level:selectedLevel(),purpose:'General Learning'});
  roadmap.modules=(roadmap.modules||[]).filter(m=>m && m.title);
  currentCategory=roadmap.category||'CUSTOM';
  $('courseTitle').innerText=roadmap.title||'Learning Path';
  renderModules();
  openModule(0);
}

function renderModules(){
  const box=$('modules'); box.innerHTML='';
  (roadmap?.modules||[]).forEach((m,i)=>{
    const div=document.createElement('div');
    div.className='module '+(i===currentIndex?'active ':'')+(m.status==='GENERATED'?'done':'');
    const stage=m.stage?`<small class="stageBadge">${escapeHtml(m.stage)}</small>`:'';
    div.innerHTML=`<span>${i+1}. ${escapeHtml(m.title)}${stage}</span>${m.status==='GENERATED'?' <b>✓</b>':''}`;
    div.onclick=()=>openModule(i);
    box.appendChild(div);
  });
  updateProgress();
}

async function openModule(i){
  currentIndex=i; renderModules(); showLearningView();
  const m=roadmap.modules[i]; currentTopic=m.title;
  if(m.title.toLowerCase().includes('quiz')){ startQuizPage(); return; }

  if(m.content){
    currentContent=normalizeContent(m.content);
    activeTab=m.activeTab || firstTab(currentContent);
    renderContent(currentContent, true);
    return;
  }

  $('topicTitle').innerText='Loading...'; $('summary').innerText='Generating textbook-style live content for '+m.title;
  const data=await post('/api/learning/content',{topic:roadmap.title,subTopic:m.title,category:roadmap.category,level:roadmap.level,purpose:roadmap.purpose});
  m.status='GENERATED';
  m.content=normalizeContent(data);
  currentContent=m.content;
  activeTab=firstTab(currentContent);
  m.activeTab=activeTab;
  renderContent(currentContent, false); renderModules();
}

function firstTab(data){
  const tabs=getVisibleTabs(data);
  return tabs[0] || 'Overview';
}

function normalizeContent(data){
  data=data||{};
  data.tabs=normalizeTabs(data.tabs);
  data.sections=normalizeSections(data.sections);
  data.relatedTopics=normalizeStringList(data.relatedTopics);
  data.quickActions=normalizeStringList(data.quickActions);
  data.diagram=normalizeDiagram(data.diagram);
  if(!data.title) data.title=currentTopic||'Learning Topic';
  if(!data.shortSummary) data.shortSummary='Learn this topic in a structured, simple, textbook-style format.';
  return data;
}

function normalizeTabs(raw){
  const result=[];
  if(Array.isArray(raw)){
    raw.forEach(t=>{
      let v='';
      if(typeof t==='string') v=t;
      else if(t && typeof t==='object') v=t.title||t.name||t.label||t.heading||t.tab||'';
      if(v && !result.includes(v)) result.push(v);
    });
  }else if(raw && typeof raw==='object'){
    Object.keys(raw).forEach(k=>{ if(k && !result.includes(k)) result.push(k); });
  }
  return result.length?result:['Overview'];
}

function normalizeSections(raw){
  const arr=[];
  if(!Array.isArray(raw)) return arr;
  raw.forEach((s,idx)=>{
    if(!s || typeof s!=='object') return;
    const heading=String(s.heading||s.title||s.name||'').trim();
    const type=String(s.type||'text');
    const tab=String(s.tab||s.group||s.category||'Overview').trim()||'Overview';
    const content=typeof s.content==='string'?s.content:(typeof s.text==='string'?s.text:'');
    const items=Array.isArray(s.items)?s.items.filter(x=>x!==null&&x!==undefined):[];
    const hasBody=(content&&content.trim().length>0)||items.length>0;
    if(!heading || !hasBody) return; // Do not show empty subtopics in UI
    arr.push({...s,heading,type,tab,content,items});
  });
  return arr;
}

function normalizeStringList(raw){
  const out=[];
  if(!Array.isArray(raw)) return out;
  raw.forEach(x=>{
    let v='';
    if(typeof x==='string') v=x;
    else if(x && typeof x==='object') v=x.title||x.name||x.label||x.topic||'';
    if(v && !out.includes(v)) out.push(v);
  });
  return out;
}

function normalizeDiagram(d){
  if(!d || !Array.isArray(d.nodes)) return null;
  d.nodes=d.nodes.map((n,i)=>({id:String(n.id||i+1),label:String(n.label||n.title||n.name||'Step '+(i+1)),icon:n.icon||'box'})).filter(n=>n.label);
  if(!d.nodes.length) return null;
  return d;
}

function renderContent(data, preserveTab){
  currentContent=normalizeContent(data);
  $('topicTitle').innerText=currentContent.title||currentTopic;
  $('summary').innerText=currentContent.shortSummary||'';
  const tabs=getVisibleTabs(currentContent);
  if(!preserveTab || !tabs.includes(activeTab)) activeTab=tabs[0]||'Overview';
  renderTabs(tabs);
  renderSectionsForTab(activeTab);
  renderDiagram(currentContent.diagram);
  $('related').innerHTML=(currentContent.relatedTopics||[]).map(x=>`<span class="relatedItem" onclick="deepDive('${escapeJs(x)}')">↗ ${escapeHtml(x)}</span>`).join('');
}

function getVisibleTabs(data){
  data=normalizeContentShallow(data);
  const backed=new Set((data.sections||[]).map(s=>s.tab||'Overview'));
  if(data.tabContent) Object.keys(data.tabContent).forEach(k=>{ if((data.tabContent[k]||[]).length) backed.add(k); });
  const fromTabs=(data.tabs||[]).filter(t=>backed.has(t));
  const all=[...fromTabs,...[...backed].filter(t=>!fromTabs.includes(t))];
  return all.length?all:['Overview'];
}
function normalizeContentShallow(d){ if(!d) return {}; return {tabs:normalizeTabs(d.tabs),sections:normalizeSections(d.sections),tabContent:d.tabContent}; }

function renderTabs(tabs){
  $('tabs').innerHTML=(tabs||[]).map((t,i)=>`<button type="button" class="tab ${t===activeTab || (!activeTab&&i===0)?'active':''}" onclick="selectTab('${escapeJs(t)}')">${escapeHtml(t)}</button>`).join('');
}

async function selectTab(tab){
  activeTab=tab;
  if(roadmap?.modules?.[currentIndex]) roadmap.modules[currentIndex].activeTab=tab;
  renderTabs(getVisibleTabs(currentContent));
  renderSectionsForTab(tab);
}

function getMatchingSections(tab){
  if(currentContent?.tabContent?.[tab]) return normalizeSections(currentContent.tabContent[tab]);
  const sections=currentContent?.sections||[];
  return sections.filter(s=>(s.tab||'Overview')===tab);
}

function renderSectionsForTab(tab){
  $('sections').innerHTML=''; $('onPage').innerHTML='';
  const sections=getMatchingSections(tab);
  if(!sections.length){
    $('sections').innerHTML=`<div class="section"><h3>No content available</h3><p>This tab has no useful generated content, so it should not normally appear. Regenerate the roadmap/content.</p></div>`;
    return;
  }
  sections.forEach((s,i)=>{
    $('onPage').innerHTML+=`<li><a href="#section-${i}">${escapeHtml(s.heading)}</a></li>`;
    const div=document.createElement('div'); div.className='section'; div.id=`section-${i}`;
    let body='';
    if(s.type==='code') body=codeBlock(s.content||'', i);
    else if(s.type==='steps') body=`<ol>${(s.items||[]).map(x=>`<li>${escapeHtml(typeof x==='string'?x:(x.text||x.label||JSON.stringify(x)))}</li>`).join('')}</ol>`;
    else if(s.type==='keyValue') body=(s.items||[]).map(x=>`<div class="kv"><b>${escapeHtml(x.key||x.term||'Term')}</b><span>${escapeHtml(x.value||x.description||'')}</span></div>`).join('');
    else if(s.type==='table') body=renderTable(s.items||[]);
    else body=`<p>${escapeHtml(s.content||'')}</p>`;
    div.innerHTML=`<h3>${i+1}. ${escapeHtml(s.heading)}</h3>${body}`;
    $('sections').appendChild(div);
  });
}

function renderTable(items){
  if(!items.length) return '';
  const keys=Object.keys(items[0]).slice(0,4);
  return `<table class="learnTable"><thead><tr>${keys.map(k=>`<th>${escapeHtml(k)}</th>`).join('')}</tr></thead><tbody>${items.map(row=>`<tr>${keys.map(k=>`<td>${escapeHtml(row[k])}</td>`).join('')}</tr>`).join('')}</tbody></table>`;
}

function codeBlock(content, i){
  const id='code-'+currentIndex+'-'+activeTab.replace(/[^a-z0-9]/gi,'')+'-'+i;
  return `<div class="codeWrap"><button class="copyCode" onclick="copyCode('${id}', this)">Copy</button><pre id="${id}" class="code">${escapeHtml(content)}</pre></div>`;
}

async function copyCode(id, btn){
  const txt=$(id)?.innerText||'';
  try{ await navigator.clipboard.writeText(txt); btn.innerText='Copied'; setTimeout(()=>btn.innerText='Copy',1200); }
  catch(e){ alert('Copy failed. Please select and copy manually.'); }
}

function renderDiagram(d){
  d=normalizeDiagram(d);
  if(!d){$('diagram').innerHTML='';return;}
  let html='';
  d.nodes.forEach((n,i)=>{html+=`<div class="node">${icon(n.icon)}<br>${escapeHtml(n.label)}</div>`; if(i<d.nodes.length-1) html+='<div class="arrow">→</div>';});
  $('diagram').innerHTML=html;
}
function icon(i){return i==='bank'?'🏦':i==='user'?'👤':i==='network'?'🌐':i==='box'?'📦':'●'}

async function deepDive(topic){
  $('summary').innerText='Loading live content for '+topic+'...';
  const data=await post('/api/learning/content',{topic:roadmap.title,subTopic:topic,category:roadmap.category,level:roadmap.level,purpose:roadmap.purpose});
  currentContent=normalizeContent(data);
  activeTab=firstTab(currentContent);
  renderContent(currentContent, false);
}
function nextTopic(){if(roadmap&&currentIndex<roadmap.modules.length-1)openModule(currentIndex+1)}
function previousTopic(){if(roadmap&&currentIndex>0)openModule(currentIndex-1)}
async function explainSimpler(){await deepDive('Explain '+currentTopic+' in very simple English')}
function downloadCurrentPagePdf(){ window.print(); }

function isProgrammingCourse(){
  const t=(roadmap?.title||$('search').value||'').toLowerCase();
  return /(java|python|javascript|typescript|c#|spring|react|angular|node|programming|coding|sql)/.test(t);
}

async function startQuizPage(){
  if(!roadmap){ await generateRoadmap(); }
  $('learningView').classList.add('hidden'); $('certificateBox').classList.add('hidden'); $('quizView').classList.remove('hidden');
  quizSession={index:0,total:isProgrammingCourse()?10:8,correct:0,answers:[],codingExercises:isProgrammingCourse()?2:0,startedAt:new Date()};
  $('quizView').innerHTML=`<div class="quizHeader"><h1>${escapeHtml(roadmap.title)} - Live Quiz</h1><p>Each question is loaded live. Pass mark is 80%.</p></div><div id="questionHost"></div>`;
  await loadQuestion();
}

async function loadQuestion(){
  const host=$('questionHost');
  const qNo=quizSession.index+1;
  const codingStart=quizSession.total-quizSession.codingExercises+1;
  const questionType=(isProgrammingCourse() && qNo>=codingStart)?'CODING':'MCQ';
  host.innerHTML=`<div class="questionCard"><h2>Loading Question ${qNo}...</h2></div>`;
  const q=await post('/api/learning/quiz/question',{topic:roadmap.title,subTopic:currentTopic,category:roadmap.category,level:roadmap.level,purpose:'General Learning',questionNumber:qNo,totalQuestions:quizSession.total,questionType});
  quizSession.currentQuestion=q;
  if(q.questionType==='CODING') renderCodingQuestion(qNo,q); else renderMcqQuestion(qNo,q);
}

function renderMcqQuestion(qNo,q){
  const pct=Math.round((qNo-1)/quizSession.total*100);
  $('questionHost').innerHTML=`
    <div class="quizProgress"><span style="width:${pct}%"></span></div>
    <div class="questionCard">
      <div class="qMeta">Question ${qNo} of ${quizSession.total} · MCQ</div>
      <h2>${escapeHtml(q.question)}</h2>
      <div class="options">
        ${(q.options||[]).map((o,i)=>`<button class="option" onclick="selectOption(this,'${escapeJs(o)}')"><b>${String.fromCharCode(65+i)}.</b> ${escapeHtml(o)}</button>`).join('')}
      </div>
      <div id="answerFeedback"></div>
      <div class="quizNav"><button onclick="submitCurrentQuestion()">Submit & Next</button></div>
    </div>`;
}

function renderCodingQuestion(qNo,q){
  const pct=Math.round((qNo-1)/quizSession.total*100);
  $('questionHost').innerHTML=`
    <div class="quizProgress"><span style="width:${pct}%"></span></div>
    <div class="questionCard">
      <div class="qMeta">Question ${qNo} of ${quizSession.total} · Coding Exercise</div>
      <h2>${escapeHtml(q.question)}</h2>
      <p>${escapeHtml(q.instruction||'Write your answer below. This coding exercise is for practice and completion.')}</p>
      <textarea id="codeAnswer" class="codeAnswer" placeholder="Write your code here..."></textarea>
      <details><summary>Show expected approach</summary>${codeBlock(q.sampleSolution||'Solution will be generated here.','sample')}</details>
      <div class="quizNav"><button onclick="submitCurrentQuestion()">Save & Next</button></div>
    </div>`;
}

function selectOption(btn,value){
  document.querySelectorAll('.option').forEach(b=>b.classList.remove('selected'));
  btn.classList.add('selected'); quizSession.selected=value;
}

function submitCurrentQuestion(){
  const q=quizSession.currentQuestion;
  let isCorrect=false,selected='';
  if(q.questionType==='CODING'){
    selected=$('codeAnswer')?.value||'';
    isCorrect=selected.trim().length>20;
  }else{
    selected=quizSession.selected||'';
    isCorrect=selected===q.correctAnswer;
  }
  quizSession.answers.push({question:q.question,selected,isCorrect,type:q.questionType});
  if(isCorrect) quizSession.correct++;
  quizSession.selected=''; quizSession.index++;
  if(quizSession.index>=quizSession.total) return showQuizResult();
  loadQuestion();
}

function showQuizResult(){
  const score=Math.round((quizSession.correct/quizSession.total)*100);
  const passed=score>=80;
  $('questionHost').innerHTML=`
    <div class="resultCard ${passed?'pass':'fail'}">
      <h1>${passed?'Congratulations, You Passed!':'Retake Required'}</h1>
      <div class="bigScore">${score}%</div>
      <p>Correct: ${quizSession.correct} / ${quizSession.total}. Pass mark: 80%.</p>
      ${passed?`<div class="certOptions"><input id="learnerName" placeholder="Learner name" value="Siva Kumar"><select id="certTitleSelect" onchange="onCertTitleChange()"><option>ITPS Live Certification</option><option>ITPS Live Learning Certification</option><option>ITPS Certified Learner</option><option value="CUSTOM">Custom title</option></select><input id="certTitleCustom" class="hidden" placeholder="Enter certificate title"></div><button onclick="showCertificate(${score})">Generate Certificate</button>`:`<button onclick="startQuizPage()">Retake Quiz</button><button onclick="showLearningView()">Revise Topics</button>`}
    </div>`;
}

function onCertTitleChange(){
  const custom=$('certTitleCustom');
  custom.classList.toggle('hidden', $('certTitleSelect').value!=='CUSTOM');
}

function selectedCertificateTitle(){
  const sel=$('certTitleSelect')?.value||'ITPS Live Certification';
  return sel==='CUSTOM' ? (($('certTitleCustom')?.value||'ITPS Live Certification').trim()) : sel;
}

async function showCertificate(score){
 const name=$('learnerName')?.value||'Learner';
 const title=selectedCertificateTitle();
 const cert=await fetch(`/api/learning/certificate?learnerName=${encodeURIComponent(name)}&courseTitle=${encodeURIComponent(roadmap.title)}&courseType=${encodeURIComponent(roadmap.category)}&level=${encodeURIComponent(roadmap.level||selectedLevel())}&score=${score}&certificateTitle=${encodeURIComponent(title)}`).then(r=>r.json());
 $('quizView').classList.add('hidden'); $('certificateBox').classList.remove('hidden');
 $('certificateBox').innerHTML=`<h2>ITPS</h2><h1>${escapeHtml(cert.title||title)}</h1><h3>Certificate of Successful Completion</h3><p>This certificate is proudly presented to</p><h1>${escapeHtml(cert.learnerName)}</h1><p>for successfully completing the live learning assessment on</p><h2>${escapeHtml(cert.courseTitle)}</h2><p>with a score of</p><div class="score">${cert.score}%</div><p>The learner has successfully passed the assessment by meeting the required passing score of 80%.</p><div class="certGrid"><div class="certItem"><b>Course Type</b><br>${escapeHtml(cert.courseType)}</div><div class="certItem"><b>Level</b><br>${escapeHtml(cert.level)}</div><div class="certItem"><b>Assessment Mode</b><br>${escapeHtml(cert.assessmentMode)}</div><div class="certItem"><b>Date</b><br>${escapeHtml(cert.completionDate)}</div></div><p><b>Certificate ID:</b> ${escapeHtml(cert.certificateId)}</p><button onclick="window.print()">Download / Print Certificate</button>`;
}

function showLearningView(){ $('learningView').classList.remove('hidden'); $('quizView').classList.add('hidden'); $('certificateBox').classList.add('hidden'); }
function updateProgress(){if(!roadmap)return;const total=roadmap.modules.length,done=roadmap.modules.filter(m=>m.status==='GENERATED').length,p=Math.round(done/total*100);$('progressBar').style.width=p+'%';$('progressText').innerText=p+'%';}
function escapeHtml(s){return String(s||'').replace(/[&<>\"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]))}
function escapeJs(s){return String(s||'').replace(/\\/g,'\\\\').replace(/'/g,"\\'").replace(/\n/g,' ')}
