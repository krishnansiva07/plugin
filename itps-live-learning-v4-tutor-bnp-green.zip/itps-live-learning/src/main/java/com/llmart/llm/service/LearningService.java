package com.llmart.llm.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.llmart.llm.model.LearningRequest;
import dev.langchain4j.model.chat.ChatLanguageModel;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

@Service
public class LearningService {
    private final ChatLanguageModel chatModel;
    private final ObjectMapper mapper = new ObjectMapper();
    private final Map<String, JsonNode> contentCache = new ConcurrentHashMap<>();
    private final Map<String, JsonNode> quizCache = new ConcurrentHashMap<>();

    public LearningService(ChatLanguageModel chatModel) {
        this.chatModel = chatModel;
    }

    public JsonNode classify(LearningRequest request) {
        String prompt = """
                You are a learning request classifier.
                Classify the request into TECHNICAL, FUNCTIONAL, CONCEPTUAL, PROCESS, FINANCE, CUSTOM.
                Identify topic, level, purpose, whether code is needed, business flow is needed, and quiz should be enabled.
                Default purpose is General Learning. Do not assume automation/testing unless explicitly asked.
                Return only valid JSON. No markdown.
                User request: %s
                """.formatted(nullSafe(request.getUserPrompt(), request.getTopic()));
        return parseOrFallback(chatModel.generate(prompt), fallbackClassification(request));
    }

    public JsonNode roadmap(LearningRequest request) {
        JsonNode classification = classify(request);
        String prompt = """
                You are ITPS Live Learning roadmap generator and a real tutor.
                Generate only a roadmap, not full lesson content.
                Topic: %s
                Category: %s
                Requested depth: %s
                Purpose: %s

                Teaching rules:
                - Do not assume automation/testing.
                - Do not include interview preparation.
                - Think like a textbook author: teach basics first, then intermediate, then advanced.
                - Do not force exactly 10 modules. Choose the number based on the topic. Usually 12 to 18 modules for Complete, 7 to 10 for Beginner, 9 to 13 for Intermediate/Advanced.
                - Last module must be Quiz / Assessment.
                - Every module must be meaningful and teachable; no empty or generic module names.
                - Technical topics should include foundations, syntax/structure, practical examples, patterns, mistakes, practice, summary.
                - Functional/business topics should include purpose, actors/parties, lifecycle, step-by-step flow, exceptions, examples, summary.
                - Return only valid JSON with this exact shape:
                  {title, category, level, purpose, modules[{id,title,stage,description,status}]}
                - stage must be one of: Basics, Intermediate, Advanced, Assessment.
                """.formatted(
                text(classification, "topic", nullSafe(request.getTopic(), request.getUserPrompt())),
                text(classification, "category", "CUSTOM"),
                text(classification, "level", defaultValue(request.getLevel(), "Beginner")),
                text(classification, "purpose", defaultValue(request.getPurpose(), "General Learning"))
        );
        return parseOrFallback(chatModel.generate(prompt), fallbackRoadmap(request, classification));
    }

    public JsonNode content(LearningRequest request) {
        String key = String.join("|", defaultValue(request.getTopic(), "custom"), defaultValue(request.getSubTopic(), "overview"), defaultValue(request.getLevel(), "beginner"));
        if (contentCache.containsKey(key)) return contentCache.get(key);

        String category = defaultValue(request.getCategory(), "AUTO");
        String prompt = """
                You are ITPS Live Learning Tutor. Teach like a clear textbook teacher.
                Create rich one-screen lesson content as strict JSON. No markdown.
                Topic: %s
                Sub topic: %s
                Level: %s
                Purpose: %s
                Category hint: %s

                Return JSON with this exact shape:
                {
                  "topicType":"TECHNICAL or FUNCTIONAL or CUSTOM",
                  "title":"lesson title",
                  "shortSummary":"2 sentence learning objective",
                  "tabs":["Overview","Concepts","Example","Practice","Summary"],
                  "sections":[
                    {"tab":"Overview","heading":"...","type":"text","content":"..."},
                    {"tab":"Concepts","heading":"...","type":"steps","items":["..."]},
                    {"tab":"Example","heading":"...","type":"code","content":"..."}
                  ],
                  "diagram":{"type":"FLOW","nodes":[{"id":"1","label":"...","icon":"box"}],"edges":[{"from":"1","to":"2","label":"..."}]},
                  "relatedTopics":["..."],
                  "quickActions":["Explain Simpler","Generate Quiz","Download Page as PDF"]
                }

                Important JSON rules:
                - tabs must be an array of strings only. Never return objects inside tabs.
                - Every tab you return must have at least one matching section with the same tab value.
                - Do not return empty sections. If a subtopic has no content, do not include it.
                - sections must include a tab field.

                Teaching quality rules:
                - Do not assume automation/testing.
                - Explain from basics to the selected depth. Use simple English, but not shallow content.
                - For technical topics include concept, syntax, practical example, common mistakes, and one small practice task.
                - For programming/database topics include useful code/query examples.
                - For functional/business topics do not include code unless requested; include business purpose, actors, lifecycle, step-by-step flow, exceptions, key terms.
                - Avoid generic filler. Content must be specific to the requested topic and subtopic.
                """.formatted(
                defaultValue(request.getTopic(), request.getUserPrompt()),
                defaultValue(request.getSubTopic(), "Overview"),
                defaultValue(request.getLevel(), "Beginner"),
                defaultValue(request.getPurpose(), "General Learning"),
                category
        );
        JsonNode result = parseOrFallback(chatModel.generate(prompt), fallbackContent(request));
        contentCache.put(key, result);
        return result;
    }

    public JsonNode quiz(LearningRequest request) {
        String prompt = """
                Create an ITPS Live Learning quiz for the topic.
                Topic: %s
                Level: %s
                Purpose: %s
                Generate 10 MCQ questions.
                Pass percentage is 80.
                Return only valid JSON:
                {quizId,title,passPercentage,questions[{questionId,question,options[],correctAnswer,explanation,linkedTopic}]}
                """.formatted(defaultValue(request.getTopic(), request.getUserPrompt()), defaultValue(request.getLevel(), "Beginner"), defaultValue(request.getPurpose(), "General Learning"));
        JsonNode quiz = parseOrFallback(chatModel.generate(prompt), fallbackQuiz(request));
        quizCache.put(text(quiz, "quizId", "QUIZ-DEMO"), quiz);
        return quiz;
    }


    public JsonNode quizQuestion(LearningRequest request) {
        int qNo = request.getQuestionNumber() == null ? 1 : request.getQuestionNumber();
        int total = request.getTotalQuestions() == null ? 10 : request.getTotalQuestions();
        String qType = defaultValue(request.getQuestionType(), "MCQ").toUpperCase();
        String topic = defaultValue(request.getTopic(), request.getUserPrompt());

        String prompt;
        if ("CODING".equals(qType)) {
            prompt = """
                    Create one live coding exercise for ITPS Live Learning.
                    Topic: %s
                    Current learning sub topic: %s
                    Level: %s
                    Question number: %d of %d
                    Return only valid JSON. No markdown.
                    Required JSON fields:
                    {questionId, questionType, question, instruction, sampleSolution, linkedTopic}
                    Rules:
                    - This is for a programming language or coding topic.
                    - Keep the exercise small enough to solve in 5 to 10 minutes.
                    - Use simple English.
                    - sampleSolution should contain clean sample code.
                    """.formatted(topic, defaultValue(request.getSubTopic(), "General"), defaultValue(request.getLevel(), "Beginner"), qNo, total);
        } else {
            prompt = """
                    Create exactly one live MCQ question for ITPS Live Learning.
                    Topic: %s
                    Current learning sub topic: %s
                    Level: %s
                    Category: %s
                    Question number: %d of %d
                    Return only valid JSON. No markdown.
                    Required JSON fields:
                    {questionId, questionType, question, options[], correctAnswer, explanation, linkedTopic}
                    Rules:
                    - options must be dynamic and relevant to this topic.
                    - exactly 4 options.
                    - correctAnswer must exactly match one option text.
                    - Avoid repeating previous common sample wording.
                    - Do not include testing/automation unless user purpose asks for it.
                    """.formatted(topic, defaultValue(request.getSubTopic(), "General"), defaultValue(request.getLevel(), "Beginner"), defaultValue(request.getCategory(), "CUSTOM"), qNo, total);
        }
        return parseOrFallback(chatModel.generate(prompt), fallbackQuizQuestion(request, qNo, total, qType));
    }

    public JsonNode certificate(String learnerName, String courseTitle, String courseType, String level, int score, String certificateTitle) {
        ObjectNode node = mapper.createObjectNode();
        node.put("title", defaultValue(certificateTitle, "ITPS Live Certification"));
        node.put("learnerName", defaultValue(learnerName, "Learner"));
        node.put("courseTitle", defaultValue(courseTitle, "Live Learning Assessment"));
        node.put("score", score);
        node.put("passPercentage", 80);
        node.put("result", score >= 80 ? "PASS" : "RETAKE_REQUIRED");
        node.put("courseType", defaultValue(courseType, "General Learning"));
        node.put("level", defaultValue(level, "Beginner"));
        node.put("assessmentMode", "Live Quiz");
        node.put("completionDate", LocalDate.now().format(DateTimeFormatter.ofPattern("dd-MMM-yyyy")));
        node.put("certificateId", "ITPS-" + System.currentTimeMillis());
        return node;
    }

    private JsonNode parseOrFallback(String response, JsonNode fallback) {
        try {
            String cleaned = response.replace("```json", "").replace("```", "").trim();
            int start = cleaned.indexOf('{');
            int end = cleaned.lastIndexOf('}');
            if (start >= 0 && end > start) cleaned = cleaned.substring(start, end + 1);
            return mapper.readTree(cleaned);
        } catch (Exception e) {
            return fallback;
        }
    }

    private JsonNode fallbackClassification(LearningRequest r) {
        ObjectNode n = mapper.createObjectNode();
        String prompt = nullSafe(r.getUserPrompt(), r.getTopic());
        String category = prompt.toLowerCase().matches(".*(java|spring|python|react|azure|api|docker|kafka|selenium).*" ) ? "TECHNICAL" : "FUNCTIONAL";
        n.put("topic", prompt.replace("I want to learn", "").trim());
        n.put("category", category);
        n.put("level", defaultValue(r.getLevel(), "Beginner"));
        n.put("purpose", defaultValue(r.getPurpose(), "General Learning"));
        n.put("needsCode", category.equals("TECHNICAL"));
        n.put("needsBusinessFlow", category.equals("FUNCTIONAL"));
        n.put("quizEnabled", true);
        return n;
    }

    private JsonNode fallbackRoadmap(LearningRequest r, JsonNode c) {
        ObjectNode n = mapper.createObjectNode();
        String category = text(c, "category", "CUSTOM");
        String topic = text(c, "topic", nullSafe(r.getTopic(), r.getUserPrompt()));
        String level = defaultValue(r.getLevel(), "Complete");
        n.put("title", topic + " Learning Path");
        n.put("category", category);
        n.put("level", level);
        n.put("purpose", defaultValue(r.getPurpose(), "General Learning"));
        var arr = n.putArray("modules");

        List<String[]> titles;
        if (category.equals("TECHNICAL")) {
            titles = List.of(
                    new String[]{"Basics", "What is " + topic + "?"},
                    new String[]{"Basics", "Why and where it is used"},
                    new String[]{"Basics", "Core terminology and building blocks"},
                    new String[]{"Basics", "Basic syntax and first example"},
                    new String[]{"Intermediate", "Common operations and practical usage"},
                    new String[]{"Intermediate", "Real-world example explained step by step"},
                    new String[]{"Intermediate", "Common mistakes and how to avoid them"},
                    new String[]{"Advanced", "Advanced concepts and best practices"},
                    new String[]{"Advanced", "Mini practice exercise"},
                    new String[]{"Advanced", "Summary and review"},
                    new String[]{"Assessment", "Quiz / Assessment"}
            );
        } else {
            titles = List.of(
                    new String[]{"Basics", "What is " + topic + "?"},
                    new String[]{"Basics", "Business purpose and real-life need"},
                    new String[]{"Basics", "Key parties and responsibilities"},
                    new String[]{"Intermediate", "End-to-end process flow"},
                    new String[]{"Intermediate", "Status lifecycle and important events"},
                    new String[]{"Intermediate", "Real-life business example"},
                    new String[]{"Advanced", "Exceptions, failures, returns, and edge cases"},
                    new String[]{"Advanced", "Rules, controls, and operational checks"},
                    new String[]{"Advanced", "Summary and review"},
                    new String[]{"Assessment", "Quiz / Assessment"}
            );
        }
        int i=1;
        for (String[] t: titles) {
            ObjectNode m=arr.addObject();
            m.put("id", "M"+i++);
            m.put("title", t[1]);
            m.put("stage", t[0]);
            m.put("description", "Learn " + t[1] + " for " + topic);
            m.put("status", "NOT_GENERATED");
        }
        return n;
    }

    private JsonNode fallbackContent(LearningRequest r) {
        ObjectNode n = mapper.createObjectNode();
        String category = defaultValue(r.getCategory(), "CUSTOM");
        String topic = defaultValue(r.getTopic(), "Topic");
        String sub = defaultValue(r.getSubTopic(), "Overview");
        boolean technical = category.equalsIgnoreCase("TECHNICAL") || topic.toLowerCase().matches(".*(java|python|sql|spring|react|api|database).*" );
        n.put("topicType", category);
        n.put("title", sub);
        n.put("shortSummary", "This lesson explains " + sub + " in a structured, textbook-style way with examples and review points.");
        var tabs = n.putArray("tabs");
        tabs.add("Overview").add("Key Concepts").add("Example").add("Practice").add("Summary");
        var sections = n.putArray("sections");
        ObjectNode s1 = sections.addObject(); s1.put("tab","Overview"); s1.put("heading", "Simple Explanation"); s1.put("type", "text"); s1.put("content", sub + " is an important part of " + topic + ". Start by understanding the purpose, then learn the structure, then practice with examples.");
        ObjectNode s2 = sections.addObject(); s2.put("tab","Key Concepts"); s2.put("heading", technical ? "Core Technical Points" : "Business Concepts"); s2.put("type", "steps");
        var items=s2.putArray("items"); items.add("Understand the purpose of this subtopic"); items.add("Learn the important terms"); items.add("Follow the flow step by step"); items.add("Practice with a realistic example");
        ObjectNode s3 = sections.addObject(); s3.put("tab","Example"); s3.put("heading", technical ? "Example" : "Real-Life Example"); s3.put("type", technical ? "code" : "text");
        s3.put("content", technical ? "-- Example for " + sub + "
SELECT column_name
FROM table_name
WHERE condition
ORDER BY column_name;" : "A real-life case is used to show how " + sub + " works from start to finish in a business process.");
        ObjectNode s4 = sections.addObject(); s4.put("tab","Practice"); s4.put("heading", "Practice Task"); s4.put("type", "text"); s4.put("content", "Try explaining this subtopic in your own words and apply it to one small example.");
        ObjectNode s5 = sections.addObject(); s5.put("tab","Summary"); s5.put("heading", "Quick Recap"); s5.put("type", "steps");
        var rec=s5.putArray("items"); rec.add("Know the purpose"); rec.add("Remember the important terms"); rec.add("Practice one example");
        ObjectNode d = n.putObject("diagram"); d.put("type", "FLOW");
        d.putArray("nodes").addObject().put("id","1").put("label","Basics").put("icon","box");
        d.withArray("nodes").addObject().put("id","2").put("label","Example").put("icon","box");
        d.withArray("nodes").addObject().put("id","3").put("label","Practice").put("icon","box");
        d.putArray("edges").addObject().put("from","1").put("to","2").put("label","");
        d.withArray("edges").addObject().put("from","2").put("to","3").put("label","");
        n.putArray("relatedTopics").add("Basics").add("Common Mistakes").add("Practice Questions");
        n.putArray("quickActions").add("Explain Simpler").add("Generate Quiz").add("Download Page as PDF");
        return n;
    }

    private JsonNode fallbackQuiz(LearningRequest r) {
        ObjectNode n = mapper.createObjectNode();
        n.put("quizId", "QUIZ-DEMO"); n.put("title", defaultValue(r.getTopic(), "Topic") + " Quiz"); n.put("passPercentage", 80);
        var qs = n.putArray("questions");
        for (int i=1;i<=10;i++) { ObjectNode q=qs.addObject(); q.put("questionId", "Q"+i); q.put("question", "Sample question " + i + " for " + defaultValue(r.getTopic(), "topic") + "?"); q.putArray("options").add("Option A").add("Option B").add("Option C").add("Option D"); q.put("correctAnswer", "Option A"); q.put("explanation", "Option A is correct for this sample question."); q.put("linkedTopic", defaultValue(r.getTopic(), "topic")); }
        return n;
    }


    private JsonNode fallbackQuizQuestion(LearningRequest r, int qNo, int total, String qType) {
        ObjectNode q = mapper.createObjectNode();
        String topic = defaultValue(r.getTopic(), "topic");
        q.put("questionId", "Q" + qNo);
        q.put("questionType", qType);
        q.put("linkedTopic", defaultValue(r.getSubTopic(), topic));
        if ("CODING".equals(qType)) {
            q.put("question", "Write a small program/example for " + topic + " based on what you learned.");
            q.put("instruction", "Create a simple, readable solution. This coding exercise is marked as completed when you enter a meaningful answer.");
            q.put("sampleSolution", "// Sample solution will depend on the topic.\n// Example: create a small method or class and print the result.");
        } else {
            q.put("question", "Which statement best describes " + topic + "?");
            var options = q.putArray("options");
            options.add(topic + " is the selected learning topic explained in this course");
            options.add(topic + " is unrelated to this course");
            options.add(topic + " is only used for certificates");
            options.add(topic + " is always a database table");
            q.put("correctAnswer", topic + " is the selected learning topic explained in this course");
            q.put("explanation", "The correct option is the one that matches the current learning topic.");
        }
        return q;
    }

    private String text(JsonNode node, String field, String def) { return node != null && node.has(field) ? node.get(field).asText(def) : def; }
    private String defaultValue(String v, String d) { return v == null || v.isBlank() ? d : v; }
    private String nullSafe(String a, String b) { return defaultValue(a, defaultValue(b, "Custom Topic")); }
}
