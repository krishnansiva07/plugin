import type { Locator, Page } from '@playwright/test';
import { envNumber } from '../../utils/Environment';
import { LlmClient } from '../../llm/LlmClient';

export interface SmartElement {
  description: string;
  primary: () => Locator;
  fallbacks?: Array<() => Locator>;
}

export class SmartActions {
  private readonly llm = new LlmClient();
  private readonly minimumConfidence = envNumber('LLM_MIN_CONFIDENCE', 0.85);

  constructor(private readonly page: Page) {}

  async fill(element: SmartElement, value: string): Promise<boolean> {
    const locator = await this.resolve(element, 'fill');
    await locator.fill(value);
    return false;
  }

  async click(element: SmartElement): Promise<boolean> {
    const locator = await this.resolve(element, 'click');
    await locator.click();
    return false;
  }

  private async isUsable(locator: Locator): Promise<boolean> {
    try {
      return (await locator.count()) === 1 && (await locator.isVisible());
    } catch {
      return false;
    }
  }

  private async resolve(element: SmartElement, action: string): Promise<Locator> {
    const candidates = [element.primary, ...(element.fallbacks ?? [])];
    for (const candidate of candidates) {
      const locator = candidate();
      if (await this.isUsable(locator)) return locator;
    }

    const primaryText = element.primary().toString();
    const error = `Unable to find a unique visible element for ${element.description}`;
    const suggestion = await this.llm.suggestLocator({
      elementDescription: element.description,
      failedLocator: primaryText,
      action,
      error,
      pageTitle: await this.page.title(),
      pageUrl: this.page.url(),
      relevantDom: (await this.page.locator('body').innerHTML()).slice(0, 20000)
    });

    if (suggestion && suggestion.confidence >= this.minimumConfidence) {
      const healed = this.page.locator(suggestion.selector);
      if (await this.isUsable(healed)) return healed;
    }
    throw new Error(error);
  }
}
