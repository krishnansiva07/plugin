import type { FullConfig, FullResult, Reporter, TestCase, TestResult } from '@playwright/test/reporter';
import fs from 'node:fs';
import path from 'node:path';

interface Row {
  serialNo: number;
  testId: string;
  testName: string;
  status: 'PASSED' | 'FAILED' | 'SKIPPED' | 'TIMED OUT' | 'INTERRUPTED';
  durationMs: number;
  error: string;
  attachments: Array<{ name: string; path: string }>;
}

function escapeHtml(value: string): string {
  return value.replace(/[&<>'"]/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' })[char] ?? char);
}

function parseTitle(title: string): { testId: string; testName: string } {
  const match = title.match(/^\[([^\]]+)]\s*(.+)$/);
  return match ? { testId: match[1], testName: match[2] } : { testId: 'N/A', testName: title };
}

function statusOf(result: TestResult): Row['status'] {
  switch (result.status) {
    case 'passed': return 'PASSED';
    case 'skipped': return 'SKIPPED';
    case 'timedOut': return 'TIMED OUT';
    case 'interrupted': return 'INTERRUPTED';
    default: return 'FAILED';
  }
}

export default class SmartHtmlReporter implements Reporter {
  private rows: Row[] = [];
  private outputDir = path.resolve('reports');
  private startedAt = new Date();
  private config?: FullConfig;

  onBegin(config: FullConfig): void {
    this.config = config;
    this.startedAt = new Date();
    this.rows = [];
  }

  onTestEnd(test: TestCase, result: TestResult): void {
    const parsed = parseTitle(test.title);
    this.rows.push({
      serialNo: this.rows.length + 1,
      testId: parsed.testId,
      testName: parsed.testName,
      status: statusOf(result),
      durationMs: result.duration,
      error: result.error?.message ?? '',
      attachments: result.attachments
        .filter(item => Boolean(item.path))
        .map(item => ({ name: item.name, path: item.path as string }))
    });
  }

  onEnd(result: FullResult): void {
    fs.mkdirSync(this.outputDir, { recursive: true });
    fs.writeFileSync(path.join(this.outputDir, 'test-results.json'), JSON.stringify(this.rows, null, 2), 'utf8');

    const total = this.rows.length;
    const passed = this.rows.filter(row => row.status === 'PASSED').length;
    const failed = this.rows.filter(row => ['FAILED', 'TIMED OUT', 'INTERRUPTED'].includes(row.status)).length;
    const skipped = this.rows.filter(row => row.status === 'SKIPPED').length;
    const executed = total - skipped;
    const percentage = executed > 0 ? (passed / executed) * 100 : 0;
    const metadata = (this.config?.metadata ?? {}) as Record<string, unknown>;
    const browser = String(metadata.selectedBrowser ?? 'Unknown');
    const environment = String(metadata.environment ?? process.env.ENVIRONMENT ?? 'QA');
    const duration = Date.now() - this.startedAt.getTime();

    const rowsHtml = this.rows.map(row => {
      const css = row.status.toLowerCase().replace(/\s+/g, '-');
      const detail = row.error
        ? `<details><summary>View error</summary><pre>${escapeHtml(row.error)}</pre></details>`
        : '';
      return `<tr data-status="${escapeHtml(row.status)}">
        <td>${row.serialNo}</td>
        <td>${escapeHtml(row.testId)}</td>
        <td>${escapeHtml(row.testName)}${detail}</td>
        <td><span class="status ${css}">${escapeHtml(row.status)}</span></td>
      </tr>`;
    }).join('\n');

    const html = `<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Smart Playwright Automation Report</title>
<style>
:root{--bg:#f4f7fb;--panel:#fff;--text:#172033;--muted:#667085;--border:#e4e7ec;--shadow:0 10px 30px rgba(16,24,40,.08)}
*{box-sizing:border-box}body{margin:0;background:var(--bg);font-family:Inter,Segoe UI,Arial,sans-serif;color:var(--text)}
.container{max-width:1220px;margin:32px auto;padding:0 20px}.hero{background:linear-gradient(135deg,#152a57,#3056a6);color:white;padding:30px;border-radius:18px;box-shadow:var(--shadow)}
.hero h1{margin:0 0 8px;font-size:28px}.meta{display:flex;gap:20px;flex-wrap:wrap;opacity:.92}.panel{background:var(--panel);border-radius:16px;box-shadow:var(--shadow);padding:22px;margin-top:22px}
.summary{width:100%;border-collapse:separate;border-spacing:0;overflow:hidden}.summary th,.summary td{padding:14px 16px;text-align:left;border-bottom:1px solid var(--border)}.summary th{background:#f8fafc}
.score{font-size:34px;font-weight:800;margin:18px 0 0}.score small{font-size:14px;font-weight:500;color:#dce7ff}.controls{display:flex;gap:12px;flex-wrap:wrap;margin-bottom:16px}
input,select{padding:11px 12px;border:1px solid #cfd6e4;border-radius:10px;font-size:14px;background:white}.results{width:100%;border-collapse:collapse}.results th,.results td{padding:14px 12px;border-bottom:1px solid var(--border);text-align:left}.results th{background:#f8fafc;position:sticky;top:0}.results tr:hover{background:#f8fbff}
.status{display:inline-block;padding:6px 11px;border-radius:999px;font-weight:800;font-size:12px}.passed{background:#dcfae6;color:#067647}.failed,.timed-out,.interrupted{background:#fee4e2;color:#b42318}.skipped{background:#eaecf0;color:#475467}
details{margin-top:8px}summary{cursor:pointer;color:#3056a6}pre{white-space:pre-wrap;background:#101828;color:#f9fafb;padding:12px;border-radius:8px;overflow:auto}.foot{color:var(--muted);font-size:13px;margin:18px 0;text-align:center}@media(max-width:700px){.results th:nth-child(2),.results td:nth-child(2){display:none}.hero h1{font-size:22px}}
</style></head><body><main class="container">
<section class="hero"><h1>Smart Playwright Automation Report</h1><div class="meta"><span>Environment: <b>${escapeHtml(environment)}</b></span><span>Browser: <b>${escapeHtml(browser)}</b></span><span>Result: <b>${escapeHtml(result.status)}</b></span><span>Duration: <b>${(duration / 1000).toFixed(1)}s</b></span></div><div class="score">${percentage.toFixed(2)}% <small>overall pass percentage</small></div></section>
<section class="panel"><h2>Consolidated Test Results</h2><table class="summary"><thead><tr><th>Result</th><th>Count</th><th>Percentage</th></tr></thead><tbody>
<tr><td>Total Tests</td><td>${total}</td><td>100.00%</td></tr><tr><td>Passed</td><td>${passed}</td><td>${total ? ((passed / total) * 100).toFixed(2) : '0.00'}%</td></tr><tr><td>Failed</td><td>${failed}</td><td>${total ? ((failed / total) * 100).toFixed(2) : '0.00'}%</td></tr><tr><td>Skipped</td><td>${skipped}</td><td>${total ? ((skipped / total) * 100).toFixed(2) : '0.00'}%</td></tr>
</tbody></table></section>
<section class="panel"><div class="controls"><input id="search" placeholder="Search Test ID or Test Name" oninput="filterRows()"><select id="status" onchange="filterRows()"><option value="">All statuses</option><option>PASSED</option><option>FAILED</option><option>SKIPPED</option><option>TIMED OUT</option><option>INTERRUPTED</option></select></div>
<div style="overflow:auto"><table class="results"><thead><tr><th>Serial No.</th><th>Test ID</th><th>Test Name</th><th>Status</th></tr></thead><tbody id="rows">${rowsHtml}</tbody></table></div></section>
<div class="foot">Generated ${escapeHtml(new Date().toLocaleString())} · Raw results: test-results.json</div></main>
<script>function filterRows(){const q=document.getElementById('search').value.toLowerCase();const s=document.getElementById('status').value;document.querySelectorAll('#rows tr').forEach(r=>{const ok=(!q||r.innerText.toLowerCase().includes(q))&&(!s||r.dataset.status===s);r.style.display=ok?'':'none'})}</script></body></html>`;

    fs.writeFileSync(path.join(this.outputDir, 'index.html'), html, 'utf8');
  }
}
