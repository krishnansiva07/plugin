import { env, envBoolean, envNumber } from '../utils/Environment';

export interface HealingRequest {
  elementDescription: string;
  failedLocator: string;
  action: string;
  error: string;
  pageTitle: string;
  pageUrl: string;
  relevantDom: string;
}

export interface HealingSuggestion {
  selector: string;
  confidence: number;
  reason: string;
}

export class LlmClient {
  readonly enabled = envBoolean('LLM_ENABLED', false);
  private readonly apiKey = env('LLM_API_KEY');
  private readonly baseUrl = env('LLM_BASE_URL').replace(/\/$/, '');
  private readonly modelName = env('LLM_MODEL_NAME');
  private readonly chatPath = env('LLM_CHAT_PATH', '/v1/chat/completions');
  private readonly timeoutMs = envNumber('LLM_TIMEOUT_MS', 15000);

  async suggestLocator(request: HealingRequest): Promise<HealingSuggestion | null> {
    if (!this.enabled) return null;
    if (!this.apiKey || !this.baseUrl || !this.modelName) {
      throw new Error('LLM is enabled, but LLM_API_KEY, LLM_BASE_URL or LLM_MODEL_NAME is missing.');
    }

    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), this.timeoutMs);
    try {
      const response = await fetch(`${this.baseUrl}${this.chatPath}`, {
        method: 'POST',
        signal: controller.signal,
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${this.apiKey}`
        },
        body: JSON.stringify({
          model: this.modelName,
          temperature: 0,
          max_tokens: 500,
          messages: [
            {
              role: 'system',
              content: 'Return strict JSON only: {"selector":"...","confidence":0.0,"reason":"..."}. Select one safe CSS selector from the supplied sanitized DOM. Never return JavaScript.'
            },
            { role: 'user', content: JSON.stringify(request) }
          ]
        })
      });
      if (!response.ok) throw new Error(`LLM request failed with HTTP ${response.status}: ${await response.text()}`);
      const payload = (await response.json()) as { choices?: Array<{ message?: { content?: string } }> };
      const content = payload.choices?.[0]?.message?.content?.trim();
      if (!content) return null;
      const clean = content.replace(/^```json\s*/i, '').replace(/```$/i, '').trim();
      const parsed = JSON.parse(clean) as HealingSuggestion;
      return typeof parsed.selector === 'string' && Number.isFinite(parsed.confidence) ? parsed : null;
    } finally {
      clearTimeout(timer);
    }
  }
}
