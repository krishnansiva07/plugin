# Smart Playwright JSON Framework

A Playwright TypeScript framework that uses an already-installed Chrome, Edge, or configured Chromium executable. It always runs in headed/UI mode and does not use ExcelJS or JSZip.

## Requirements

- Node.js 20 or 22 LTS
- npm
- Installed Chrome or Edge, or a Chromium executable path
- No Python, Java, Selenium WebDriver, ChromeDriver or EdgeDriver

## First run

```powershell
Copy-Item .env.example .env
npm ci
npm run preflight
npm test
```

Open the report:

```powershell
npm run report:open
```

The main report is `reports/index.html`.

## Browser selection

Edit only `.env`.

```env
BROWSER=auto
BROWSER_PRIORITY=chrome,edge
```

Force Chrome:

```env
BROWSER=chrome
```

Force Edge:

```env
BROWSER=edge
```

Use your office Chromium path:

```env
BROWSER=custom
BROWSER_EXECUTABLE_PATH=C:\Tools\Chromium\chrome.exe
```

The framework always sets `headless: false`, so the browser UI is visible.

## JSON test data

Edit `test-data/login-tests.json`. Set `"run": false` to skip a case. The sample contains five SauceDemo login scenarios.

## Reports

After execution:

- `reports/index.html` – colourful consolidated HTML dashboard
- `reports/test-results.json` – raw result output
- `test-results/junit.xml` – Jenkins JUnit result
- `test-results/artifacts/` – screenshots, traces and videos when configured

The main HTML table contains Serial No., Test ID, Test Name and Status. It also contains percentages, search and status filters.

## LLM self-healing

Normal deterministic locator fallback works without an LLM. To enable the OpenAI-compatible endpoint matching the supplied Java configuration:

```env
LLM_ENABLED=true
LLM_API_KEY=your-token
LLM_BASE_URL=https://your-corporate-endpoint
LLM_MODEL_NAME=your-model
LLM_CHAT_PATH=/v1/chat/completions
```

The mapping is:

- Java `apiKey` → `LLM_API_KEY`
- Java `baseUrl` → `LLM_BASE_URL`
- Java `modelName` → `LLM_MODEL_NAME`

The LLM receives sanitized page context and must return a single JSON selector suggestion. It is used only after normal and deterministic fallback locators fail.

## Office-system clean reinstall

```powershell
taskkill /F /IM node.exe 2>$null
Remove-Item node_modules -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item package-lock.json -Force -ErrorAction SilentlyContinue
npm cache clean --force
npm install
npm test
```

This project intentionally has no ExcelJS dependency.
