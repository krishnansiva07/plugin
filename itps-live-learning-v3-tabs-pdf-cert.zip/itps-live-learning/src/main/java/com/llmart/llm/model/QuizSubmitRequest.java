package com.llmart.llm.model;

import java.util.Map;

public class QuizSubmitRequest {
    private String quizId;
    private String learnerName;
    private String courseTitle;
    private String courseType;
    private String level;
    private Map<String, String> answers;

    public String getQuizId() { return quizId; }
    public void setQuizId(String quizId) { this.quizId = quizId; }
    public String getLearnerName() { return learnerName; }
    public void setLearnerName(String learnerName) { this.learnerName = learnerName; }
    public String getCourseTitle() { return courseTitle; }
    public void setCourseTitle(String courseTitle) { this.courseTitle = courseTitle; }
    public String getCourseType() { return courseType; }
    public void setCourseType(String courseType) { this.courseType = courseType; }
    public String getLevel() { return level; }
    public void setLevel(String level) { this.level = level; }
    public Map<String, String> getAnswers() { return answers; }
    public void setAnswers(Map<String, String> answers) { this.answers = answers; }
}
