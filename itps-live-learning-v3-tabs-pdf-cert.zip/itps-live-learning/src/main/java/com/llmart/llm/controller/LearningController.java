package com.llmart.llm.controller;

import com.llmart.llm.model.LearningRequest;
import com.llmart.llm.service.LearningService;
import com.fasterxml.jackson.databind.JsonNode;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/learning")
public class LearningController {
    private final LearningService learningService;

    public LearningController(LearningService learningService) {
        this.learningService = learningService;
    }

    @PostMapping("/classify")
    public JsonNode classify(@RequestBody LearningRequest request) {
        return learningService.classify(request);
    }

    @PostMapping("/roadmap")
    public JsonNode roadmap(@RequestBody LearningRequest request) {
        return learningService.roadmap(request);
    }

    @PostMapping("/content")
    public JsonNode content(@RequestBody LearningRequest request) {
        return learningService.content(request);
    }

    @PostMapping("/quiz")
    public JsonNode quiz(@RequestBody LearningRequest request) {
        return learningService.quiz(request);
    }

    @PostMapping("/quiz/question")
    public JsonNode quizQuestion(@RequestBody LearningRequest request) {
        return learningService.quizQuestion(request);
    }

    @GetMapping("/certificate")
    public JsonNode certificate(@RequestParam String learnerName,
                                @RequestParam String courseTitle,
                                @RequestParam(defaultValue = "General Learning") String courseType,
                                @RequestParam(defaultValue = "Beginner") String level,
                                @RequestParam int score,
                                @RequestParam(defaultValue = "ITPS Live Certification") String certificateTitle) {
        return learningService.certificate(learnerName, courseTitle, courseType, level, score, certificateTitle);
    }
}
