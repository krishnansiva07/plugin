package com.llmart.llm.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.llmart.llm.model.LearningRequest;
import dev.langchain4j.model.chat.ChatLanguageModel;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

@Service
public class LearningService {
    private final ChatLanguageModel chatModel;
    private final ObjectMapper mapper = new ObjectMapper();
    private final Map<String, JsonNode> contentCache = new ConcurrentHashMap<>();
    private final Map<String, JsonNode> quizCache = new ConcurrentHashMap<>();

    public LearningService(ChatLanguageModel chatModel) {
        this.chatModel = chatModel;
    }

    public JsonNode classify(LearningRequest request) {
        String prompt = """
                You are a learning request classifier.
                Classify the request into TECHNICAL, FUNCTIONAL, CONCEPTUAL, PROCESS, FINANCE, CUSTOM.
                Identify topic, level, purpose, whether code is needed, business flow is needed, and quiz should be enabled.
                Default purpose is General Learning. Do not assume automation/testing unless explicitly asked.
                Return only valid JSON. No markdown.
                User request: %s
                """.formatted(nullSafe(request.getUserPrompt(), request.getTopic()));
        return parseOrFallback(chatModel.generate(prompt), fallbackClassification(request));
    }

    public JsonNode roadmap(LearningRequest request) {
        JsonNode classification = classify(request);
        String prompt = """
                You are ITPS Live Learning roadmap generator.
                Generate only a roadmap, not full content.
                Topic: %s
                Category: %s
                Level: %s
                Purpose: %s
                Rules:
                - Generic learning platform.
                - Do not include interview preparation.
                - Last module must be Quiz / Assessment.
                - For technical topics include concept/example/common mistakes/summary.
                - For functional topics include purpose/parties/flow/status/exceptions/summary.
                - Return only valid JSON with: title, category, level, purpose, modules[{id,title,description,status}].
                """.formatted(
                text(classification, "topic", nullSafe(request.getTopic(), request.getUserPrompt())),
                text(classification, "category", "CUSTOM"),
                text(classification, "level", defaultValue(request.getLevel(), "Beginner")),
                text(classification, "purpose", defaultValue(request.getPurpose(), "General Learning"))
        );
        return parseOrFallback(chatModel.generate(prompt), fallbackRoadmap(request, classification));
    }

    public JsonNode content(LearningRequest request) {
        String key = String.join("|", defaultValue(request.getTopic(), "custom"), defaultValue(request.getSubTopic(), "overview"), defaultValue(request.getLevel(), "beginner"));
        if (contentCache.containsKey(key)) return contentCache.get(key);

        String category = defaultValue(request.getCategory(), "AUTO");
        String prompt = """
                You are ITPS Live Learning Tutor.
                Create one screen content as strict JSON. No markdown.
                Topic: %s
                Sub topic: %s
                Level: %s
                Purpose: %s
                Category hint: %s

                Return JSON with:
                topicType, title, shortSummary,
                tabs[],
                sections[{heading,type,content,items}],
                diagram{type,nodes[{id,label,icon}],edges[{from,to,label}]},
                relatedTopics[], quickActions[].

                Rules:
                - Do not assume automation/testing.
                - If technical, include code only if useful.
                - If functional/business, do not include code; include business flow and key terms.
                - Keep simple English.
                - Keep suitable for one live learning screen.
                """.formatted(
                defaultValue(request.getTopic(), request.getUserPrompt()),
                defaultValue(request.getSubTopic(), "Overview"),
                defaultValue(request.getLevel(), "Beginner"),
                defaultValue(request.getPurpose(), "General Learning"),
                category
        );
        JsonNode result = parseOrFallback(chatModel.generate(prompt), fallbackContent(request));
        contentCache.put(key, result);
        return result;
    }

    public JsonNode quiz(LearningRequest request) {
        String prompt = """
                Create an ITPS Live Learning quiz for the topic.
                Topic: %s
                Level: %s
                Purpose: %s
                Generate 10 MCQ questions.
                Pass percentage is 80.
                Return only valid JSON:
                {quizId,title,passPercentage,questions[{questionId,question,options[],correctAnswer,explanation,linkedTopic}]}
                """.formatted(defaultValue(request.getTopic(), request.getUserPrompt()), defaultValue(request.getLevel(), "Beginner"), defaultValue(request.getPurpose(), "General Learning"));
        JsonNode quiz = parseOrFallback(chatModel.generate(prompt), fallbackQuiz(request));
        quizCache.put(text(quiz, "quizId", "QUIZ-DEMO"), quiz);
        return quiz;
    }


    public JsonNode quizQuestion(LearningRequest request) {
        int qNo = request.getQuestionNumber() == null ? 1 : request.getQuestionNumber();
        int total = request.getTotalQuestions() == null ? 10 : request.getTotalQuestions();
        String qType = defaultValue(request.getQuestionType(), "MCQ").toUpperCase();
        String topic = defaultValue(request.getTopic(), request.getUserPrompt());

        String prompt;
        if ("CODING".equals(qType)) {
            prompt = """
                    Create one live coding exercise for ITPS Live Learning.
                    Topic: %s
                    Current learning sub topic: %s
                    Level: %s
                    Question number: %d of %d
                    Return only valid JSON. No markdown.
                    Required JSON fields:
                    {questionId, questionType, question, instruction, sampleSolution, linkedTopic}
                    Rules:
                    - This is for a programming language or coding topic.
                    - Keep the exercise small enough to solve in 5 to 10 minutes.
                    - Use simple English.
                    - sampleSolution should contain clean sample code.
                    """.formatted(topic, defaultValue(request.getSubTopic(), "General"), defaultValue(request.getLevel(), "Beginner"), qNo, total);
        } else {
            prompt = """
                    Create exactly one live MCQ question for ITPS Live Learning.
                    Topic: %s
                    Current learning sub topic: %s
                    Level: %s
                    Category: %s
                    Question number: %d of %d
                    Return only valid JSON. No markdown.
                    Required JSON fields:
                    {questionId, questionType, question, options[], correctAnswer, explanation, linkedTopic}
                    Rules:
                    - options must be dynamic and relevant to this topic.
                    - exactly 4 options.
                    - correctAnswer must exactly match one option text.
                    - Avoid repeating previous common sample wording.
                    - Do not include testing/automation unless user purpose asks for it.
                    """.formatted(topic, defaultValue(request.getSubTopic(), "General"), defaultValue(request.getLevel(), "Beginner"), defaultValue(request.getCategory(), "CUSTOM"), qNo, total);
        }
        return parseOrFallback(chatModel.generate(prompt), fallbackQuizQuestion(request, qNo, total, qType));
    }

    public JsonNode certificate(String learnerName, String courseTitle, String courseType, String level, int score, String certificateTitle) {
        ObjectNode node = mapper.createObjectNode();
        node.put("title", defaultValue(certificateTitle, "ITPS Live Certification"));
        node.put("learnerName", defaultValue(learnerName, "Learner"));
        node.put("courseTitle", defaultValue(courseTitle, "Live Learning Assessment"));
        node.put("score", score);
        node.put("passPercentage", 80);
        node.put("result", score >= 80 ? "PASS" : "RETAKE_REQUIRED");
        node.put("courseType", defaultValue(courseType, "General Learning"));
        node.put("level", defaultValue(level, "Beginner"));
        node.put("assessmentMode", "Live Quiz");
        node.put("completionDate", LocalDate.now().format(DateTimeFormatter.ofPattern("dd-MMM-yyyy")));
        node.put("certificateId", "ITPS-" + System.currentTimeMillis());
        return node;
    }

    private JsonNode parseOrFallback(String response, JsonNode fallback) {
        try {
            String cleaned = response.replace("```json", "").replace("```", "").trim();
            int start = cleaned.indexOf('{');
            int end = cleaned.lastIndexOf('}');
            if (start >= 0 && end > start) cleaned = cleaned.substring(start, end + 1);
            return mapper.readTree(cleaned);
        } catch (Exception e) {
            return fallback;
        }
    }

    private JsonNode fallbackClassification(LearningRequest r) {
        ObjectNode n = mapper.createObjectNode();
        String prompt = nullSafe(r.getUserPrompt(), r.getTopic());
        String category = prompt.toLowerCase().matches(".*(java|spring|python|react|azure|api|docker|kafka|selenium).*" ) ? "TECHNICAL" : "FUNCTIONAL";
        n.put("topic", prompt.replace("I want to learn", "").trim());
        n.put("category", category);
        n.put("level", defaultValue(r.getLevel(), "Beginner"));
        n.put("purpose", defaultValue(r.getPurpose(), "General Learning"));
        n.put("needsCode", category.equals("TECHNICAL"));
        n.put("needsBusinessFlow", category.equals("FUNCTIONAL"));
        n.put("quizEnabled", true);
        return n;
    }

    private JsonNode fallbackRoadmap(LearningRequest r, JsonNode c) {
        ObjectNode n = mapper.createObjectNode();
        String category = text(c, "category", "CUSTOM");
        String topic = text(c, "topic", nullSafe(r.getTopic(), r.getUserPrompt()));
        n.put("title", topic + " Learning Path");
        n.put("category", category);
        n.put("level", defaultValue(r.getLevel(), "Beginner"));
        n.put("purpose", defaultValue(r.getPurpose(), "General Learning"));
        var arr = n.putArray("modules");
        List<String> titles = category.equals("TECHNICAL") ?
                List.of("Introduction", "Core Concepts", "How It Works", "Example", "Common Mistakes", "Summary", "Quiz / Assessment") :
                List.of("Introduction", "Business Purpose", "Parties Involved", "Step-by-Step Flow", "Status Lifecycle", "Exceptions", "Summary", "Quiz / Assessment");
        int i=1; for (String t: titles) { ObjectNode m=arr.addObject(); m.put("id", "M"+i++); m.put("title", t); m.put("description", "Learn " + t + " for " + topic); m.put("status", "NOT_GENERATED"); }
        return n;
    }

    private JsonNode fallbackContent(LearningRequest r) {
        ObjectNode n = mapper.createObjectNode();
        n.put("topicType", defaultValue(r.getCategory(), "CUSTOM"));
        n.put("title", defaultValue(r.getSubTopic(), defaultValue(r.getTopic(), "Overview")));
        n.put("shortSummary", "Simple live learning content generated for this topic.");
        n.putArray("tabs").add("Overview").add("Flow").add("Example").add("Summary");
        var sections = n.putArray("sections");
        ObjectNode s = sections.addObject(); s.put("heading", "Simple Explanation"); s.put("type", "text"); s.put("content", "This section explains the selected topic in simple English.");
        ObjectNode d = n.putObject("diagram"); d.put("type", "FLOW");
        d.putArray("nodes").addObject().put("id","1").put("label","Start").put("icon","circle");
        d.withArray("nodes").addObject().put("id","2").put("label","Process").put("icon","box");
        d.withArray("nodes").addObject().put("id","3").put("label","End").put("icon","circle");
        d.putArray("edges").addObject().put("from","1").put("to","2").put("label","");
        d.withArray("edges").addObject().put("from","2").put("to","3").put("label","");
        n.putArray("relatedTopics").add("Basics").add("Example").add("Summary");
        n.putArray("quickActions").add("Explain Simpler").add("Show Example").add("Generate Quiz");
        return n;
    }

    private JsonNode fallbackQuiz(LearningRequest r) {
        ObjectNode n = mapper.createObjectNode();
        n.put("quizId", "QUIZ-DEMO"); n.put("title", defaultValue(r.getTopic(), "Topic") + " Quiz"); n.put("passPercentage", 80);
        var qs = n.putArray("questions");
        for (int i=1;i<=10;i++) { ObjectNode q=qs.addObject(); q.put("questionId", "Q"+i); q.put("question", "Sample question " + i + " for " + defaultValue(r.getTopic(), "topic") + "?"); q.putArray("options").add("Option A").add("Option B").add("Option C").add("Option D"); q.put("correctAnswer", "Option A"); q.put("explanation", "Option A is correct for this sample question."); q.put("linkedTopic", defaultValue(r.getTopic(), "topic")); }
        return n;
    }


    private JsonNode fallbackQuizQuestion(LearningRequest r, int qNo, int total, String qType) {
        ObjectNode q = mapper.createObjectNode();
        String topic = defaultValue(r.getTopic(), "topic");
        q.put("questionId", "Q" + qNo);
        q.put("questionType", qType);
        q.put("linkedTopic", defaultValue(r.getSubTopic(), topic));
        if ("CODING".equals(qType)) {
            q.put("question", "Write a small program/example for " + topic + " based on what you learned.");
            q.put("instruction", "Create a simple, readable solution. This coding exercise is marked as completed when you enter a meaningful answer.");
            q.put("sampleSolution", "// Sample solution will depend on the topic.\n// Example: create a small method or class and print the result.");
        } else {
            q.put("question", "Which statement best describes " + topic + "?");
            var options = q.putArray("options");
            options.add(topic + " is the selected learning topic explained in this course");
            options.add(topic + " is unrelated to this course");
            options.add(topic + " is only used for certificates");
            options.add(topic + " is always a database table");
            q.put("correctAnswer", topic + " is the selected learning topic explained in this course");
            q.put("explanation", "The correct option is the one that matches the current learning topic.");
        }
        return q;
    }

    private String text(JsonNode node, String field, String def) { return node != null && node.has(field) ? node.get(field).asText(def) : def; }
    private String defaultValue(String v, String d) { return v == null || v.isBlank() ? d : v; }
    private String nullSafe(String a, String b) { return defaultValue(a, defaultValue(b, "Custom Topic")); }
}
