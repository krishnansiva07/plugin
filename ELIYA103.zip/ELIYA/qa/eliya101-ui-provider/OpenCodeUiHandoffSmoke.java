import com.fasterxml.jackson.databind.ObjectMapper;
import com.llmart.llm.dto.ChatMode;
import com.llmart.llm.dto.ChatRequest;
import com.llmart.llm.service.OpenCodeExecutionService;
import com.llmart.llm.service.OpenCodeUiProviderConfig;
import com.llmart.llm.service.ProjectService;
import java.nio.file.*;
import java.util.*;

public class OpenCodeUiHandoffSmoke {
    static void check(boolean ok,String message){if(!ok)throw new AssertionError(message);}
    public static void main(String[] args) throws Exception {
        var config=new OpenCodeUiProviderConfig("https://company.example/v1/chat/completions", "agent-model-v1", "top-secret-do-not-log");
        check("company.example".equals(config.endpointHost()),"invalid endpoint host");
        check("eliya-ui/agent".equals(config.modelReference()),"wrong model ref");
        String configText=config.config().toString();
        check(configText.contains("https://company.example/v1"),"API root not normalized");
        check(!configText.contains("top-secret-do-not-log"),"API secret leaked into config");
        check("top-secret-do-not-log".equals(config.processEnvironment().get(OpenCodeUiProviderConfig.KEY_ENV)),"missing child credential");
        try {new OpenCodeUiProviderConfig("https://u:p@company.example/v1","abc","k");throw new AssertionError("Embedded credential accepted");}
        catch(IllegalArgumentException expected){}
        check(config.fingerprint().equals(new OpenCodeUiProviderConfig("https://company.example/v1", "agent-model-v1", "top-secret-do-not-log").fingerprint()),"stable config fingerprint missing");
        Path dir=Files.createTempDirectory("eliya101-ui-handoff-");
        System.setProperty("eliya.qa.workspace",dir.toString());
        System.setProperty("eliya.opencode.sessionStore",dir.resolve("sessions").toString());
        String executable=System.getenv("ELIYA_QA_MOCK_BINARY");
        check(executable!=null && Files.isExecutable(Path.of(executable)),"Mock executable missing");
        OpenCodeExecutionService service=new OpenCodeExecutionService(new ObjectMapper(),new ProjectService(),
                "opencode","http://127.0.0.1:4096","",executable,true);
        try {
            check(!Boolean.TRUE.equals(service.engineInfo().get("connected")),"engine started before UI credentials were supplied");
            ChatRequest req=new ChatRequest("p","Create a text file",List.of(),ChatMode.AGENT,
                    new ChatRequest.Settings("https://company.example/v1","agent-model-v1"));
            var state=service.launch(req,null,"top-secret-do-not-log");
            check((""+state.get("id")).startsWith("oc-"),"session creation failed");
            check("agent-model-v1".equals(state.get("model")),"wrong displayed model");
            check(Boolean.TRUE.equals(service.engineInfo().get("connected")),"configured engine not connected");
            System.out.println("PASS: ELIYA UI endpoint, model, and key configured in managed OpenCode process; explicit model switch admitted prompt");
            service.cancel((String)state.get("id"));
            ChatRequest wrong=new ChatRequest("p","Create another file",List.of(),ChatMode.AGENT,
                    new ChatRequest.Settings("https://company.example/v1","force-mismatch"));
            try {service.launch(wrong,null,"top-secret-do-not-log");throw new AssertionError("Public model fallback was accepted");}
            catch(IllegalStateException expected){check(expected.getMessage().contains("expected eliya-ui/agent"),"Expected model mismatch explanation: "+expected.getMessage());}
            System.out.println("PASS: public OpenCode default rejected BEFORE prompt admission");
        }finally{service.shutdown();}
        System.out.println("PASS: API key not embedded in provider config; UI credentials not needed from user again");
    }
}
