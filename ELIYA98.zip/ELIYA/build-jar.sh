#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if ! command -v mvn >/dev/null; then
  echo 'Maven not found. Install Maven or package with your IDE.' >&2
  exit 1
fi
mvn -DskipTests clean package
if [[ ! -f target/eliya.jar ]]; then
  echo 'Build ended without target/eliya.jar' >&2
  exit 1
fi
printf 'JAR ready: %s/target/eliya.jar\n' "$PWD"
printf 'Run: java -jar target/eliya.jar\n'
