"""ELIYA62 dark-terminal live action feed acceptance checks, without a model/provider."""
import asyncio,re,os
from pathlib import Path
from playwright.async_api import async_playwright
root=Path(__file__).resolve().parent.parent/'src/main/resources/static'
async def main():
  async with async_playwright() as pw:
    browser=await pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
    page=await browser.new_page(viewport={'width':1260,'height':900})
    errors=[]
    page.on('pageerror',lambda e:errors.append(str(e)))
    html=re.sub(r'<script src="[^"]+"></script>','',(root/'index.html').read_text())
    html=re.sub(r'<link rel="stylesheet"[^>]+>','',html)
    await page.set_content(html)
    await page.add_style_tag(content=(root/'app.css').read_text())
    await page.evaluate('''() => {
      window.__older=[{seq:1,type:'turn_start',data:{projectId:'p1',detail:'First instruction'}},
                      {seq:2,type:'agent_step',data:{tool:'read',status:'success',step:1,detail:'Read README.md',args:{path:'README.md'},output:'# README'}}];
      window.__detail={id:'s1',conversationId:'c1',status:'running',runId:'r1',projectId:'p1',prompt:'Inspect',
        fullPrompt:'Inspect',turns:[{role:'user',content:'Inspect the workspace'}],
        queue:[],question:{},answer:'',sequence:7,events:[
          {seq:3,type:'agent_step',data:{tool:'bash',status:'running',step:1,detail:'Run git status',args:{command:'git status'}}},
          {seq:4,type:'agent_step',data:{tool:'bash',status:'success',step:1,detail:'git status completed',args:{command:'git status'},output:'On branch main\\nworking tree clean'}},
          {seq:5,type:'agent_step',data:{tool:'edit',status:'success',step:2,detail:'Changed src/app.js',args:{path:'src/app.js'},output:'2 lines changed'}},
          {seq:6,type:'agent_step',data:{tool:'agent_recovery',status:'running',detail:'Retrying after tool failure'}},
          {seq:7,type:'error',data:{message:'Example provider failure <img src=x onerror=alert(1)>'}}
        ]};
      window.fetch=async (url,opts={})=>{
        const path=String(url);
        let response={};
        if(path==='/api/terminal/sessions') response=[{id:'s1',prompt:'Inspect',status:'running',queueCount:0}];
        else if(path==='/api/terminal/sessions/s1') response=window.__detail;
        else if(path.includes('/api/terminal/sessions/s1/activity')){
          response=path.includes('before=3') ? {events:window.__older,hasMore:false} :
            {events:window.__detail.events.slice(-3),hasMore:true};
        } else if(path==='/api/terminal/workspaces') response=[{id:'p1',name:'Workspace',localPath:'/tmp/work'}];
        else if(path==='/api/conversations')response=[];
        return new Response(JSON.stringify(response),{status:200,headers:{'Content-Type':'application/json'}});
      };
    }''')
    for file in ['markdown.js','prompt-catalog.js','app.js','confluence-composer.js']:
      await page.add_script_tag(content=(root/file).read_text())
    await page.evaluate('''() => {
      terminalUi.visible=true;terminalUi.selected='s1';terminalUi.draft=null;
      document.querySelector('#terminalDock').classList.remove('hidden');
      terminalUi.sessions=[{id:'s1',status:'running',prompt:'Inspect'}];
      terminalUi.detail=window.__detail;
      renderTerminalUi();
    }''')
    assert await page.get_by_text('Agent actions').count()==1
    assert await page.locator('section.terminal-action-feed:not(details)').count()==1
    assert await page.locator('.terminal-action-row').count()==5
    assert await page.get_by_text('Run git status').count()==1
    assert await page.locator('.terminal-action-command').count()==2
    assert await page.locator('.terminal-action-error').count()==1
    assert not await page.locator('img[src="x"]').count(), 'Untrusted provider event inserted HTML'
    await page.locator('.terminal-action-detail[data-action-detail="4"] > summary').click()
    assert await page.locator('.terminal-action-detail[data-action-detail="4"]').evaluate('(e)=>e.open')
    assert 'working tree clean' in await page.locator('.terminal-action-detail[data-action-detail="4"] pre').last.inner_text()
    await page.evaluate('renderTerminalUi()')
    assert await page.locator('.terminal-action-detail[data-action-detail="4"]').evaluate('(e)=>e.open'), 'Polling collapsed open tool detail'
    await page.evaluate('terminalUi.actionHistory.get("s1").loaded=false;terminalUi.actionHistory.get("s1").events.clear()')
    await page.evaluate('pollTerminalSessions()')
    await page.wait_for_function('() => terminalUi.actionHistory.get("s1")?.loaded && !terminalUi.actionHistory.get("s1")?.loading')
    assert await page.get_by_role('button',name='Load earlier actions').count()==1
    await page.get_by_role('button',name='Load earlier actions').click()
    await page.wait_for_function('() => document.querySelectorAll(".terminal-action-row").length === 7')
    assert not await page.locator('[data-terminal-more-actions]').count()
    seqs=await page.locator('.terminal-action-row').evaluate_all('(nodes)=>nodes.map(n=>Number(n.dataset.actionSeq))')
    assert seqs==[1,2,3,4,5,6,7],seqs
    assert not errors,errors
    if os.environ.get('ELIYA_ACTIONS_SCREENSHOT'):
      await page.evaluate('''() => {document.querySelector('#terminalConfigPanel').open=false; document.querySelector('#terminalOutput').scrollTop=0;}''')
      await page.locator('#terminalDock').screenshot(path=os.environ['ELIYA_ACTIONS_SCREENSHOT'])
    await browser.close()
  print('PASS: full visible action timeline; live start/end; input/output expansion; polling state; pagination; escaping; no page errors')
if __name__=='__main__':asyncio.run(main())
