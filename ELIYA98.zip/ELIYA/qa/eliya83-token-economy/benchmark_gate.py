#!/usr/bin/env python3
"""Strict quality-first Eliya/OpenCode provider-token benchmark acceptance gate.

CSV fields: task_id,run,agent,model,passed,total_tokens.
Only REAL provider-reported, same-task, same-model paired usage can establish parity.
A CI source test cannot substitute for live run records.
"""
import csv
import statistics
import sys
from collections import defaultdict
from pathlib import Path


def evaluate(path, minimum_tasks=10, minimum_repeats=3):
    rows = list(csv.DictReader(Path(path).open(encoding='utf-8', newline='')))
    required = {'task_id', 'run', 'agent', 'model', 'passed', 'total_tokens'}
    if not rows or not required.issubset(rows[0]):
        raise ValueError('CSV must contain ' + ', '.join(sorted(required)))
    groups = defaultdict(dict)
    for record in rows:
        agent = record['agent'].lower().strip()
        if agent not in {'eliya', 'opencode'}:
            continue
        key = (record['task_id'].strip(), record['run'].strip(), record['model'].strip())
        if not all(key) or agent in groups[key]:
            raise ValueError('Blank or duplicated task/run/model pairing')
        if record['passed'].lower() not in ('true', 'false'):
            raise ValueError('passed must be true/false')
        try:
            count = int(record['total_tokens'])
        except ValueError as exc:
            raise ValueError('Tokens must be provider-reported positive integer') from exc
        if count <= 0:
            raise ValueError('Missing or estimated total token usage is not accepted')
        groups[key][agent] = (count, record['passed'].lower() == 'true')
    if any(set(item) != {'eliya', 'opencode'} for item in groups.values()):
        raise ValueError('Unpaired run: both agents must report for each task/run/model')
    by_task = defaultdict(list)
    for (task, repeat, model), pair in groups.items():
        by_task[(task, model)].append(pair)
    if len({task for task, _ in by_task}) < minimum_tasks:
        raise ValueError(f'Need at least {minimum_tasks} distinct identical tasks')
    if any(len(pairs) < minimum_repeats for pairs in by_task.values()):
        raise ValueError(f'Need at least {minimum_repeats} pairs per task/model')
    if any(pair['opencode'][1] and not pair['eliya'][1] for pair in groups.values()):
        raise ValueError('Eliya failed a task verified as passed by OpenCode')
    eli_total = sum(pair['eliya'][0] for pair in groups.values())
    open_total = sum(pair['opencode'][0] for pair in groups.values())
    ratios = [statistics.median(p['eliya'][0] / p['opencode'][0] for p in pairs)
              for pairs in by_task.values()]
    aggregate = eli_total / open_total
    median = statistics.median(ratios)
    print(f'Paired trials={len(groups)}; tasks={len(by_task)}; total Eliya={eli_total:,}; '
          f'OpenCode={open_total:,}; aggregate ratio={aggregate:.3f}; median task ratio={median:.3f}')
    if aggregate > 1 or median > 1:
        raise ValueError('TOKEN GATE FAIL: Eliya used more provider tokens on aggregate or median task')
    print('COMPARISON GATE PASS on supplied records; source authenticity and live quality must be verified separately')
    return aggregate, median


if __name__ == '__main__':
    if len(sys.argv) != 2:
        sys.exit('Usage: python3 benchmark_gate.py real_provider_tokens.csv')
    try:
        evaluate(sys.argv[1])
    except (OSError, ValueError) as error:
        sys.exit('BENCHMARK NOT ACCEPTED: ' + str(error))
