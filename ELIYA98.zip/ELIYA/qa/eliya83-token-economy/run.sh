#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../.."
D="$(mktemp -d)"; trap 'rm -rf "$D"' EXIT
mkdir -p "$D/classes" "$D/stubs/com/fasterxml/jackson/core" "$D/stubs/com/fasterxml/jackson/databind" "$D/stubs/org/springframework/stereotype" "$D/stubs/com/llmart/llm/dto" "$D/stubs/com/llmart/llm/service"
cat > "$D/stubs/com/fasterxml/jackson/core/JsonProcessingException.java" <<'JAVA'
package com.fasterxml.jackson.core; public class JsonProcessingException extends Exception { }
JAVA
cat > "$D/stubs/com/fasterxml/jackson/databind/ObjectMapper.java" <<'JAVA'
package com.fasterxml.jackson.databind;
import com.fasterxml.jackson.core.JsonProcessingException;
public class ObjectMapper { public String writeValueAsString(Object o) throws JsonProcessingException { return String.valueOf(o); } }
JAVA
cat > "$D/stubs/org/springframework/stereotype/Service.java" <<'JAVA'
package org.springframework.stereotype; public @interface Service { }
JAVA
cat > "$D/stubs/com/llmart/llm/dto/ChatSettings.java" <<'JAVA'
package com.llmart.llm.dto;
public class ChatSettings {
 public String model(){return "model";}
 public boolean autoCompactEnabled(){return true;}
 public int safeContextWindowTokens(String model){return 128000;}
 public int safeMaxTokens(){return 4000;}
 public int safeCompactionBufferTokens(String model){return 8000;}
 public int safeOldToolOutputChars(){return 1500;}
 public int safeCompactionKeepTokens(String model){return 8000;}
 public Integer contextWindowTokens(){return null;}
 public String modelContextWindows(){return "";}
}
JAVA
cat > "$D/stubs/com/llmart/llm/service/AgentRunService.java" <<'JAVA'
package com.llmart.llm.service;
public class AgentRunService { public static class AgentRun { public String durableContextText(){return "preserved original objective and active plan";} } }
JAVA
javac --release 17 -encoding UTF-8 -d "$D/classes" \
  $(find "$D/stubs" -name '*.java') \
  src/main/java/com/llmart/llm/service/{ContextBudgetPolicy,ContextWindowManager,AgentEvidenceEconomyPolicy}.java \
  qa/eliya83-token-economy/EconomySmoke.java
java -cp "$D/classes" com.llmart.llm.service.EconomySmoke
python3 - <<'PY'
from pathlib import Path
agent=Path('src/main/java/com/llmart/llm/service/AgentService.java').read_text()
assert 'AgentEvidenceEconomyPolicy.adjust(' in agent
assert 'run.objective(), run.activePlanStepText()' in agent
assert 'contextWindows.pruneOldToolOutputs(messages, settings, aggressive)' in agent
assert 'contextWindows.upsertDurableRuntimeState(messages, run.durableContextText())' in agent
print('PASS: Agent integration retains durable plan and existing runtime pruning')
PY

python3 - <<'PYTEST'
import csv, importlib.util, tempfile
from pathlib import Path
p=Path('qa/eliya83-token-economy/benchmark_gate.py')
spec=importlib.util.spec_from_file_location('gate',p)
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
with tempfile.TemporaryDirectory() as d:
 f=Path(d)/'data.csv'
 with f.open('w',newline='') as fh:
  w=csv.writer(fh);w.writerow(['task_id','run','agent','model','passed','total_tokens'])
  for t in range(10):
   for r in range(3):
    w.writerow([f'task{t}',r,'eliya','same-model','true',85000])
    w.writerow([f'task{t}',r,'opencode','same-model','true',100000])
 a,b=m.evaluate(f)
 assert a<1 and b<1
 f.write_text('task_id,run,agent,model,passed,total_tokens\none,1,eliya,same-model,true,85000\n')
 try: m.evaluate(f)
 except ValueError: pass
 else: raise AssertionError('Unpaired benchmarks must fail closed')
print('PASS: strict real-run benchmark acceptance logic; synthetic records are NOT real results')
PYTEST
