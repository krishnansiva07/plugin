package com.llmart.llm.service;

import com.llmart.llm.dto.ChatSettings;
import java.util.*;

/** Standalone source-level, deterministic token economy and quality regression. */
public class EconomySmoke {
    static void check(boolean ok, String message) { if (!ok) throw new AssertionError(message); }
    static Map<String,Object> tool(String content) {
        Map<String,Object> m = new LinkedHashMap<>();
        m.put("role", "tool"); m.put("name", "bash"); m.put("content", content);
        return m;
    }
    public static void main(String[] args) {
        var normal = new ContextBudgetPolicy.Budget(ContextBudgetPolicy.Profile.BALANCED,
                4, 12_000, 24_000, 65_000, false);
        var targeted = AgentEvidenceEconomyPolicy.adjust(normal,
                "Fix stale wait in testscripts.banner", "Review BannerPage.java");
        check(targeted.files() <= 3 && targeted.retrievalChars() == 5_000
                && targeted.evidenceChars() == 9_000, "named-file optional context should be bounded");
        check(normal.retrievalChars() + normal.evidenceChars()
                > targeted.retrievalChars() + targeted.evidenceChars(), "must save optional evidence tokens");
        check(normal.equals(AgentEvidenceEconomyPolicy.adjust(normal,
                "Explain full E2E architecture of BannerPage.java", "Read file")), "architecture must stay full-depth");
        check(normal.equals(AgentEvidenceEconomyPolicy.adjust(normal,
                "Complete regression migration", "Fix BannerPage.java")), "broad requirements must be preserved");
        check(normal.equals(AgentEvidenceEconomyPolicy.adjust(normal,
                "Investigate the workspace", "Search sources")), "unspecified scope must remain full-depth");
        check(normal.equals(AgentEvidenceEconomyPolicy.adjust(normal,
                "Fix First.java Second.java Third.java", "Inspect classes")), "multi-file request needs full depth");
        System.setProperty("eliya.tokens.economy.enabled", "false");
        check(normal.equals(AgentEvidenceEconomyPolicy.adjust(normal,
                "Fix BannerPage.java", "Review")), "opt out must return legacy behavior");
        System.clearProperty("eliya.tokens.economy.enabled");

        var cm = new ContextWindowManager(new com.fasterxml.jackson.databind.ObjectMapper());
        String logs = "Build started\n".repeat(100)
                + "MODULE src/main/java/BannerPage.java:219 error: cannot find symbol ExpectedWait\n"
                + "working\n".repeat(200) + "BUILD FAILED\n".repeat(100);
        String bounded = ContextWindowManager.clipToolOutputWithDiagnostics(logs, 1_000);
        check(bounded.contains("BannerPage.java:219"), "must preserve middle-of-log failure evidence");
        check(bounded.length() < 1_150, "bounded tool logs must remain small");
        var messages = new ArrayList<Map<String,Object>>();
        messages.add(Map.of("role", "user", "content", "Do not modify the configuration"));
        for (int i=0; i<6; i++) messages.add(tool("build output " + i + ": " + "data ".repeat(1200)));
        int before = cm.estimate(messages, List.of(), new ChatSettings()).estimatedInputTokens();
        int changed = cm.pruneOldToolOutputs(messages, new ChatSettings());
        int after = cm.estimate(messages, List.of(), new ChatSettings()).estimatedInputTokens();
        check(changed == 4 && after < before, "tool observations must be bounded without touching the user instruction");
        check(messages.get(0).get("content").equals("Do not modify the configuration"),
                "user constraints must be preserved exactly");
        // Checkpoint is pure local compaction and only activates on sustained, tool-heavy work.
        var shortSession = new ArrayList<Map<String,Object>>();
        shortSession.add(Map.of("role", "user", "content", "Explain BannerPage.java"));
        check(!cm.shouldEconomyCompact(shortSession, List.of(), new ChatSettings(), "model"),
                "short investigations must not be compacted");
        var longSession = new ArrayList<Map<String,Object>>();
        longSession.add(Map.of("role", "user", "content", "Never delete source files"));
        for (int i=0; i<16; i++) {
            longSession.add(Map.of("role", "assistant", "content", "Step " + i + " " + "thinking ".repeat(320)));
            longSession.add(tool("Observation " + i + " " + "result ".repeat(170)));
        }
        check(cm.shouldEconomyCompact(longSession, List.of(), new ChatSettings(), "model"),
                "long sessions should checkpoint before repeated context costs grow");
        System.out.printf(Locale.ROOT,
                "PASS: 11 token economy and evidence-safety checks; optional context %d -> %d chars (%.1f%% reduction); synthetic prompt estimate %d -> %d tokens%n",
                36_000, 14_000, 100.0 * (36_000-14_000)/36_000, before, after);
    }
}
