#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../.."
D=$(mktemp -d)
trap 'rm -rf "$D"' EXIT
mkdir -p "$D/src/com/llmart/llm/service" "$D/src/org/springframework/stereotype" "$D/src/com/fasterxml/jackson/databind"
cp src/main/java/com/llmart/llm/service/{TerminalSkillStudioService,WorkspaceRootGuard,ArtifactVaultService,TerminalGitService}.java "$D/src/com/llmart/llm/service/"
cat > "$D/src/org/springframework/stereotype/Service.java" <<'JAVA'
package org.springframework.stereotype;public @interface Service {}
JAVA
cat > "$D/src/com/llmart/llm/service/ProjectService.java" <<'JAVA'
package com.llmart.llm.service;import java.nio.file.*;
class ProjectService {
 static Path workspace;
 Project require(String id){return new Project();}
 ProjectDto createLocal(String conversationId,String path,String name){return new ProjectDto("worktree-"+name);}
 record ProjectDto(String id) {}
 static class Project {boolean hasLocalPath(){return true;}String getLocalPath(){return workspace.toString();}}
}
JAVA
cat > "$D/src/com/fasterxml/jackson/databind/ObjectMapper.java" <<'JAVA'
package com.fasterxml.jackson.databind;
import java.io.*;import java.nio.file.*;import java.util.*;import com.llmart.llm.service.ArtifactVaultService;
public class ObjectMapper {
 private final Map<String,Object> values = new HashMap<>();
 public <T> T readValue(String json,Class<T> cls)throws IOException {
  if(cls == Map.class && json.contains("path"))return cls.cast(Map.of("path","../../escape.html","operation","write"));
  throw new IOException("unsupported fixture");
 }
 public <T> T readValue(File file,Class<T> cls)throws IOException {
  Object data=values.get(file.toString());
  if(data == null && file.toString().endsWith("manifest.json"))data=values.get(file.toString()+".tmp");
  if(cls.isArray() && data instanceof List<?> l) return cls.cast(l.toArray(new ArtifactVaultService.Entry[0]));
  throw new IOException("unsupported fixture");
 }
 public void writeValue(File file,Object value)throws IOException {values.put(file.toString(),value);Files.writeString(file.toPath(),"fixture-manifest");}
}
JAVA
cat > "$D/src/com/llmart/llm/service/HardeningSmoke.java" <<'JAVA'
package com.llmart.llm.service;
import java.nio.file.*;import java.util.*;
public class HardeningSmoke {
 static void check(boolean ok,String name){if(!ok)throw new AssertionError(name);}
 static void git(Path directory,String... args)throws Exception {
  List<String> command=new ArrayList<>();command.add("git");command.add("-C");command.add(directory.toString());command.addAll(List.of(args));
  Process process=new ProcessBuilder(command).redirectErrorStream(true).start();
  String output=new String(process.getInputStream().readAllBytes());
  if(process.waitFor()!=0)throw new IllegalStateException("Git setup failed: "+output);
 }
 public static void main(String[] args)throws Exception {
  Path root=Files.createTempDirectory("eliya-hardening-");
  ProjectService.workspace=root;
  TerminalSkillStudioService studio=new TerminalSkillStudioService(new ProjectService());
  var r=studio.create(new TerminalSkillStudioService.DefinitionRequest("p",".","eliya","skill","code-reviewer","Review source","Inspect sources and tests. Report evidence."));
  check(Files.isRegularFile(root.resolve(".agents/skills/code-reviewer/SKILL.md")),"Eliya skill saved");
  check("skill".equals(r.get("kind")),"Type returned");
  Files.createDirectory(root.resolve("backend"));
  studio.create(new TerminalSkillStudioService.DefinitionRequest("p","backend","opencode","agent","review-agent","Review TypeScript","Check concurrency and tests."));
  check(Files.isRegularFile(root.resolve("backend/.opencode/agents/review-agent.md")),"Nested repository agent");
  studio.create(new TerminalSkillStudioService.DefinitionRequest("p",".","claude","skill","security","Review security","Verify checks with test evidence."));
  check(Files.isRegularFile(root.resolve(".claude/skills/security/SKILL.md")),"Claude skill");
  boolean denied=false;
  try{studio.create(new TerminalSkillStudioService.DefinitionRequest("p",".","eliya","skill","code-reviewer","Again","Must not overwrite"));}catch(FileAlreadyExistsException ex){denied=true;}
  check(denied,"Existing definitions protected");
  denied=false;
  try{studio.create(new TerminalSkillStudioService.DefinitionRequest("p","../", "eliya","skill","escape","Bad","No"));}catch(SecurityException ex){denied=true;}
  check(denied,"Traversal rejected");
  denied=false;
  try{studio.create(new TerminalSkillStudioService.DefinitionRequest("p",".","eliya","skill","../escape","Bad","No"));}catch(IllegalArgumentException ex){denied=true;}
  check(denied,"Invalid definition names rejected");
  Path outer=Files.createTempDirectory("outside-agent-");
  try{
   Files.createSymbolicLink(root.resolve(".opencode"), outer);
   denied=false;
   try{studio.create(new TerminalSkillStudioService.DefinitionRequest("p",".","opencode","skill","evil","Bad","No"));}catch(SecurityException ex){denied=true;}
   check(denied,"Symlink escape rejected");
  }catch(UnsupportedOperationException|java.nio.file.FileSystemException ex){System.out.println("INFO: symlink test unavailable");}
  Path repo1=Files.createDirectory(root.resolve("frontend"));
  Path repo2=Files.createDirectory(root.resolve("automation"));
  for(Path repo:List.of(repo1,repo2)){
   git(repo,"init","-q");git(repo,"config","user.email","qa@example.invalid");
   git(repo,"config","user.name","ELIYA test");
   Files.writeString(repo.resolve("README.txt"),"Initial\n");
   git(repo,"add","README.txt");git(repo,"commit","-qm","initial");
  }
  TerminalGitService service=new TerminalGitService(new ProjectService());
  check(service.repositories("p").stream().anyMatch(m->"frontend".equals(m.get("path"))),"First repository discovered");
  check(service.repositories("p").stream().anyMatch(m->"automation".equals(m.get("path"))),"Second repository discovered");
  var branch=service.createBranch("p","automation","feature/qa-review");
  check(Boolean.FALSE.equals(branch.get("checkedOut")),"Creating branch does not change checkout");
  Files.writeString(repo1.resolve("README.txt"),"Edited\n");
  var review=service.review("p","frontend");
  check(review.get("status").toString().contains("README.txt"),"Git review reports changes");
  denied=false;
  try{service.createBranch("p","../", "bad");}catch(SecurityException ex){denied=true;}
  check(denied,"Repository traversal rejected");
  System.setProperty("eliya.terminal.worktrees",root.resolve("worktrees").toString());
  var tree=service.createWorktree("p","frontend","feature/isolated",UUID.randomUUID().toString());
  check(Files.isDirectory(Path.of(tree.get("path").toString()).resolve(".git")) ||
        Files.isRegularFile(Path.of(tree.get("path").toString()).resolve(".git")),"Worktree created");
  System.setProperty("eliya.artifacts.store",root.resolve("archive").toString());
  var vault=new ArtifactVaultService(new com.fasterxml.jackson.databind.ObjectMapper());
  String convo=UUID.randomUUID().toString();
  String answer="<!-- PROJECT_FILE_START: report.html -->\\n```html\\n<h1>OK</h1>\\n```\\n<!-- PROJECT_FILE_END -->"
     .replace("\\n", "\n");
  var archived=vault.archive(convo, 17, answer);
  check(archived.size()==1,"Artifact saved");
  check("report.html".equals(archived.get(0).path()),"Artifact name preserved");
  check(vault.get(convo,17,archived.get(0).id()).content().equals("<h1>OK</h1>"),"Artifact content retrievable");
  check(vault.archive(convo,17,answer).size()==1,"Idempotent archive");
  denied=false;
  try{vault.get(convo,17,"../../other");}catch(IllegalArgumentException ex){denied=true;}
  check(denied,"Artifact id traversal rejected");
  System.out.println("PASS: agent/skill formats, multi-repo Git branch/worktree/review, workspace safety and artifact archive");
 }
}
JAVA
mkdir -p "$D/classes"
javac --release 17 -d "$D/classes" $(find "$D/src" -name '*.java')
java -cp "$D/classes" com.llmart.llm.service.HardeningSmoke
