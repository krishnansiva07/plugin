import com.llmart.llm.service.AgentMarkdownOutcomeEvidence;
import java.nio.file.*;
import java.util.*;
public class EvidenceSmoke {
  static void check(boolean b,String reason){if(!b)throw new AssertionError(reason);}
  public static void main(String[] args)throws Exception {
    Path root=Files.createTempDirectory("eliya70-evidence");
    try {
      Files.createDirectories(root.resolve(".opencode/agents"));
      Files.writeString(root.resolve(".opencode/agents/code-reviewer.md"),
        "---\ndescription: Review single responsibility class design\n---\n" +
        "# Reviewer\nFocus on separation of concerns and one-class-one-responsibility skill.\n".repeat(18));
      String status="A  .opencode/agents/code-reviewer.md";
      String proof=AgentMarkdownOutcomeEvidence.collect(root,status,16_000);
      check(proof.contains("FILE: .opencode/agents/code-reviewer.md") && proof.contains("# Reviewer"), "Actual artifact missing from proof");
      check(!proof.contains("content excerpted"),"Small artifact should be fully reviewed");
      check(AgentMarkdownOutcomeEvidence.collect(root,"A  missing.md",16_000).isBlank(),"Missing file must not create proof");
      check(AgentMarkdownOutcomeEvidence.collect(root,"A  ../outside.md",16_000).isBlank(),"Path traversal must be rejected");
      check(AgentMarkdownOutcomeEvidence.collect(root,status+"\nM  src/Main.java",16_000).isBlank(),"Mixed-code result requires regular review");
      check(AgentMarkdownOutcomeEvidence.collect(root,status,100).isBlank(),"Too small a budget should not claim sufficient proof");
      Path link=root.resolve(".opencode/agents/link.md");
      try {Files.createSymbolicLink(link,root.resolve(".opencode/agents/code-reviewer.md"));
        check(AgentMarkdownOutcomeEvidence.collect(root,"A  .opencode/agents/link.md",16_000).isBlank(),"Symlink must be rejected");
      } catch(UnsupportedOperationException|SecurityException|java.nio.file.FileSystemException e) { /* unsupported fs */ }
      Files.writeString(root.resolve("large.md"),"# Topic\n"+"x".repeat(30000));
      String excerpt=AgentMarkdownOutcomeEvidence.collect(root,"A  large.md",4_000);
      check(excerpt.contains("content excerpted") && excerpt.length()<5_000,"Oversized Markdown evidence must be bounded and marked");
      System.out.println("PASS: ELIYA70 Markdown evidence (7 checks)");
    } finally {try(var walk=Files.walk(root)) {
      walk.sorted(Comparator.reverseOrder()).forEach(f->{try{Files.deleteIfExists(f);}catch(Exception ignored){}});
    }}
  }
}
