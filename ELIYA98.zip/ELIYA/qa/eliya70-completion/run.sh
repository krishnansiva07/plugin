#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../.."
D=$(mktemp -d);trap 'rm -rf "$D"' EXIT
mkdir -p "$D/classes" "$D/org/springframework/stereotype" "$D/com/fasterxml/jackson/core" "$D/com/fasterxml/jackson/databind" "$D/com/llmart/llm/dto" "$D/com/llmart/llm/service"
cat > "$D/org/springframework/stereotype/Service.java" <<'EOF'
package org.springframework.stereotype; public @interface Service {}
EOF
cat > "$D/com/fasterxml/jackson/core/JsonProcessingException.java" <<'EOF'
package com.fasterxml.jackson.core; public class JsonProcessingException extends Exception {}
EOF
cat > "$D/com/fasterxml/jackson/databind/ObjectMapper.java" <<'EOF'
package com.fasterxml.jackson.databind;
import com.fasterxml.jackson.core.JsonProcessingException;
public class ObjectMapper { public String writeValueAsString(Object o)throws JsonProcessingException{return String.valueOf(o);} }
EOF
cat > "$D/com/llmart/llm/dto/ChatSettings.java" <<'EOF'
package com.llmart.llm.dto;
public class ChatSettings {
 public String model(){return "model";}
 public boolean autoCompactEnabled(){return true;}
 public int safeContextWindowTokens(String model){return 128000;}
 public int safeMaxTokens(){return 4000;}
 public int safeCompactionBufferTokens(String model){return 8000;}
 public int safeOldToolOutputChars(){return 1500;}
 public int safeCompactionKeepTokens(String model){return 8000;}
}
EOF
cat > "$D/com/llmart/llm/service/AgentRunService.java" <<'EOF'
package com.llmart.llm.service;
public class AgentRunService {public static class AgentRun {public String durableContextText(){return "active locked plan / verification";}}}
EOF
cat > "$D/EconomySmoke.java" <<'EOF'
import com.llmart.llm.service.ContextWindowManager;
import com.llmart.llm.dto.ChatSettings;
import java.util.*;
public class EconomySmoke {
 static void check(boolean yes,String why){if(!yes)throw new AssertionError(why);}
 static Map<String,Object> msg(String role,String data){return new HashMap<>(Map.of("role",role,"content",data));}
 public static void main(String[] args) {
  var cm=new ContextWindowManager(new com.fasterxml.jackson.databind.ObjectMapper());
  var settings=new ChatSettings();
  var messages=new ArrayList<Map<String,Object>>();
  messages.add(msg("system", "Follow approved plan exactly"));
  messages.add(msg("user", "IMPORTANT: never delete files and respect all original requirements"));
  check(!cm.shouldEconomyCompact(messages,List.of(),settings,"model"),"Short task must not compact");
  for(int i=0;i<30;i++){
    messages.add(msg("assistant","Explanation step="+i+" and code evidence "+"a".repeat(4500)));
    var tool=msg("tool","result="+i+" output "+"x".repeat(1450));tool.put("name","read");
    messages.add(tool);
  }
  int before=cm.estimate(messages,List.of(),settings,"model").estimatedInputTokens();
  check(before>32000,"Workload did not reach an economy checkpoint: "+before);
  check(cm.shouldEconomyCompact(messages,List.of(),settings,"model"),"Long repeated tool history should trigger economy checkpoint");
  var result=cm.compact(messages,List.of(),settings,null,true,null,"model");
  check(result.compacted() && result.estimatedTokensSaved()>6000,"Cost checkpoint must shrink active context substantially: "+result);
  check(String.valueOf(messages.get(1).get("content")).contains("never delete files"), "Historic user safety constraint was lost");
  check(!cm.shouldEconomyCompact(messages,List.of(),settings,"model"), "No unnecessary repeat compaction");
  var off=new ChatSettings(){@Override public boolean autoCompactEnabled(){return false;}};
  check(!cm.shouldEconomyCompact(messages,List.of(),off,"model"), "Disabled setting must be respected");
  System.out.println("PASS: ELIYA70 token economy decision/compaction (6 checks); estimated input "+before+" -> "+result.after().estimatedInputTokens());
 }
}
EOF
javac --release 17 -d "$D/classes" \
  src/main/java/com/llmart/llm/service/AgentMarkdownOutcomeEvidence.java \
  qa/eliya70-completion/EvidenceSmoke.java
java -cp "$D/classes" EvidenceSmoke
javac --release 17 -d "$D/classes" \
  "$D/org/springframework/stereotype/Service.java" \
  "$D/com/fasterxml/jackson/core/JsonProcessingException.java" \
  "$D/com/fasterxml/jackson/databind/ObjectMapper.java" \
  "$D/com/llmart/llm/dto/ChatSettings.java" \
  "$D/com/llmart/llm/service/AgentRunService.java" \
  src/main/java/com/llmart/llm/service/ContextWindowManager.java \
  "$D/EconomySmoke.java"
java -cp "$D/classes" EconomySmoke
python3 - <<'PY'
from pathlib import Path
source=Path('src/main/java/com/llmart/llm/service/TerminalSessionService.java').read_text()
assert '"kind", "execution_followup"' not in source
assert 'session.status = "needs_input";' in source # genuine planning question retained
assert 'session.question = Map.of();' in source
assert '"execution_followup".equals(session.question.get("kind"))' in source
agent=Path('src/main/java/com/llmart/llm/service/AgentService.java').read_text()
assert 'AgentMarkdownOutcomeEvidence.collect(ws.root(), changed, 16_000)' in agent
assert 'contextWindows.shouldEconomyCompact(messages, availableTools, settings, model)' in agent
ui=Path('src/main/resources/static/app.js').read_text()
assert 'Task ended without confirmed completion' in ui
assert "['failed','blocked'].includes(status)" in ui
print('PASS: ELIYA70 backend/UI completion and token guard contracts')
PY
node --check src/main/resources/static/app.js
