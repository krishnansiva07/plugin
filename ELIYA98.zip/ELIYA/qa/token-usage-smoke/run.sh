#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../.."
TMP=$(mktemp -d)
trap 'rm -rf "$TMP"' EXIT
mkdir -p "$TMP/src/com/llmart/llm/service" "$TMP/src/org/springframework/stereotype" "$TMP/classes"
cat > "$TMP/src/org/springframework/stereotype/Service.java" <<'JAVA'
package org.springframework.stereotype; public @interface Service {}
JAVA
cat > "$TMP/src/com/llmart/llm/service/OpenAiCompatibleClient.java" <<'JAVA'
package com.llmart.llm.service;
class OpenAiCompatibleClient {
 record Usage(long inputTokens,long outputTokens,long totalTokens,long cachedInputTokens,long cacheWriteTokens) {}
}
JAVA
cat > "$TMP/src/com/llmart/llm/service/ProtectedRunSnapshotService.java" <<'JAVA'
package com.llmart.llm.service;class ProtectedRunSnapshotService {void discard(String id) {}}
JAVA
cat > "$TMP/src/com/llmart/llm/service/AgentCancelledException.java" <<'JAVA'
package com.llmart.llm.service;class AgentCancelledException extends RuntimeException {AgentCancelledException(String s){super(s);}}
JAVA
cat > "$TMP/src/com/llmart/llm/service/TokenActivitySmoke.java" <<'JAVA'
package com.llmart.llm.service;
import java.nio.file.*;import java.util.*;
public class TokenActivitySmoke {
 static void ok(boolean valid,String message){if(!valid)throw new AssertionError(message);}
 static Map<?,?> row(Object value){return (Map<?,?>)value;}
 public static void main(String[] args)throws Exception {
  var store=new AgentRunService(Files.createTempDirectory("eliya-tokens-"));
  var run=store.start("chat", "workspace");
  run.recordModelUsage(new OpenAiCompatibleClient.Usage(500,100,600,200,0),550,"Planning",0);
  run.recordModelUsage(new OpenAiCompatibleClient.Usage(100,40,0,0,0),130,"Planning",0);
  run.recordModelUsage(new OpenAiCompatibleClient.Usage(0,0,0,0,0),900,"Agent execution",2);
  var snapshot=row(run.snapshot().get("tokenUsage"));
  var items=(List<?>)snapshot.get("activities");
  ok(items.size()==2,"group count");
  var plan=row(items.get(0));
  ok(plan.get("totalTokens").equals(740L),"mixed provider totals");
  ok(plan.get("reportedCalls").equals(2L),"reported calls");
  ok(row(items.get(1)).get("unreportedCalls").equals(1L),"zero usage must be unreported");
  ok(((Number)snapshot.get("providerTotalTokens")).longValue()==740L,"aggregate exact tokens");
  var loaded=new AgentRunService(Path.of(System.getProperty("run.store"))).require(run.id());
  var restored=(List<?>)row(loaded.snapshot().get("tokenUsage")).get("activities");
  ok(restored.size()==2,"restore activity counts");
  ok(row(restored.get(0)).get("totalTokens").equals(740L),"restore provider values");
  ok(row(restored.get(1)).get("unreportedCalls").equals(1L),"restore missing provider usage");
  System.out.println("PASS: per-activity provider usage, grouped calls, missing usage, totals, restart persistence");
 }
}
JAVA
STORE="$TMP/runs"; mkdir -p "$STORE"
# Pass temp store path to the smoke harness without using mutable default data paths.
python3 - "$TMP/src/com/llmart/llm/service/TokenActivitySmoke.java" <<'PY'
import sys
p=sys.argv[1]
s=open(p).read().replace('var store=new AgentRunService(Files.createTempDirectory("eliya-tokens-"));','var store=new AgentRunService(Path.of(System.getProperty("run.store")));')
open(p,'w').write(s)
PY
javac --release 17 -d "$TMP/classes" $(find "$TMP/src" -name '*.java') \
 src/main/java/com/llmart/llm/service/TokenActivityLedger.java \
 src/main/java/com/llmart/llm/service/AgentRunService.java
java -Drun.store="$STORE" -cp "$TMP/classes" com.llmart.llm.service.TokenActivitySmoke
node --check src/main/resources/static/app.js
node - <<'JS'
const fs = require('fs'); const app=fs.readFileSync('src/main/resources/static/app.js','utf8');
if(!app.includes('tokenActivityReportHtml(usage, !message.streaming && !waiting)'))throw Error('Agent missing token report');
if(!app.includes('${tokenReport}'))throw Error('Terminal missing token report');
console.log('PASS: Agent and Terminal render usage at end of run');
JS

# Regression: AgentService is not compiled by the lightweight token ledger smoke test.
# Verify that subagent usage is associated with its declared parentStep and
# that read-only step verification is not misreported as a subagent execution.
python3 - <<'PYCODE'
from pathlib import Path
source = Path('src/main/java/com/llmart/llm/service/AgentService.java').read_text()
subagent = source.split('private String runSubagent(', 1)[1].split('private ', 1)[0]
expected = 'parentRun.recordModelUsage(turn.usage(), childEstimate.estimatedInputTokens(), "Subagent execution", parentStep);'
assert expected in subagent, 'runSubagent token activity must use the declared parentStep, not undefined step'
assert '"Subagent execution", step)' not in subagent, 'Undeclared step used in subagent token activity'
readonly = source.split('private StepCompletionDecision activeReadOnlyStepCompletionGate(', 1)[1].split('private StepCompletionDecision activeStepCompletionGate(', 1)[0]
assert '"Execution review", step)' in readonly, 'Read-only critic usage must be reported as execution review'
print('PASS: subagent parent-step binding and critic token activity classification')
PYCODE
