import com.llmart.llm.service.OpenCodeExecutionService;
import java.lang.reflect.*;
import java.time.Instant;
import java.util.*;

/** Exercises snapshot telemetry without a real provider or modifying user workspaces. */
public class OpenCodeTelemetrySmoke {
    private static void check(boolean expected, String message) {
        if (!expected) throw new AssertionError(message);
    }
    @SuppressWarnings("unchecked")
    public static void main(String[] args) throws Exception {
        Class<?> type=Class.forName("com.llmart.llm.service.OpenCodeExecutionService$Session");
        Constructor<?> ctor=type.getDeclaredConstructor(String.class,String.class,String.class,String.class,String.class,String.class);
        ctor.setAccessible(true);
        Object session=ctor.newInstance("oc-11111111-1111-1111-1111-111111111111", "remote-1", "conv", "workspace", "model", "instruction");
        Field status=type.getDeclaredField("status"); status.setAccessible(true);
        Field started=type.getDeclaredField("startedAt"); started.setAccessible(true);
        Field finished=type.getDeclaredField("finishedAt"); finished.setAccessible(true);
        Method snapshot=type.getDeclaredMethod("snapshot");snapshot.setAccessible(true);
        Method push=type.getDeclaredMethod("push",String.class,Map.class);push.setAccessible(true);
        started.set(session,Instant.now().minusSeconds(70).toString());
        status.set(session,"running");
        Map<String,Object> idle=(Map<String,Object>)snapshot.invoke(session);
        Map<String,Object> idleProgress=(Map<String,Object>)idle.get("progress");
        check(Boolean.TRUE.equals(idleProgress.get("indeterminate")),"eventless run must have unknown percent");
        check(((Number)idle.get("elapsedMs")).longValue()>=69000,"elapsed time missing while running");
        for (int i=0;i<5;i++) push.invoke(session,"agent_step",Map.of("tool","bash","status","success","detail","Tool finished"));
        Map<String,Object> active=(Map<String,Object>)snapshot.invoke(session);
        Map<String,Object> activeProgress=(Map<String,Object>)active.get("progress");
        check(!Boolean.TRUE.equals(activeProgress.get("indeterminate")),"observed events should report progress");
        check(Boolean.TRUE.equals(activeProgress.get("estimated")),"estimated progress must be labelled");
        int pct=((Number)activeProgress.get("progressPercent")).intValue();
        check(pct>=10 && pct<100,"running progress should stay below 100%: " + pct);
        check(((Number)activeProgress.get("observedActions")).intValue()==5,"actions not counted");
        status.set(session,"completed");
        push.invoke(session,"done",Map.of("status","completed"));
        Map<String,Object> done=(Map<String,Object>)snapshot.invoke(session);
        Map<String,Object> doneProgress=(Map<String,Object>)done.get("progress");
        check(((Number)doneProgress.get("progressPercent")).intValue()==100,"completed must be 100%");
        check(!Boolean.TRUE.equals(doneProgress.get("estimated")),"completed should not be estimated");
        check(done.get("finishedAt") != null,"final completion time missing");
        check(((Number)done.get("elapsedMs")).longValue()>=69000,"final duration lost");
        System.out.println("PASS: OpenCode unknown progress, verified events, estimated percent, final 100%, elapsed time");
    }
}
