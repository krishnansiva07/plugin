#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../.."
T="$(mktemp -d)"
trap 'rm -rf "$T"' EXIT
javac --release 17 -d "$T" \
  src/main/java/com/llmart/llm/service/AgentPlanRelevance.java \
  src/main/java/com/llmart/llm/service/AgentConversationIntent.java \
  qa/conversational-agent/AgentConversationIntentSmoke.java
java -cp "$T" com.llmart.llm.service.AgentConversationIntentSmoke
node --check src/main/resources/static/app.js
python3 - <<'PY'
from pathlib import Path
s=Path('src/main/java/com/llmart/llm/service/AgentService.java').read_text()
ui=Path('src/main/resources/static/app.js').read_text()
chat=Path('src/main/java/com/llmart/llm/service/ChatService.java').read_bytes()
assert 'runConversational(' in s and 'conversationalPlans' in s
assert 'restoreApprovedTask(' in s and 'originalAttachments()' in s
assert 'further generic approval' in s.lower() and 'planApprovalRequired()' not in s
assert 'if (intent == AgentConversationIntent.Kind.PLAN_PREVIEW)' in s
assert 'if (AgentConversationIntent.isFastReadOnly(request.message()))' in s
assert 'READ-ONLY QUESTION:' in s and 'toolRegistry.isParallelReadOnly(tool)' in s
assert 'if (!AgentConversationIntent.isFastReadOnly(request.message()))' in s
assert 'proposal.clarification(), java.time.Instant.now()' in s
assert 'Auto-approve routine tool actions' in Path('src/main/resources/static/index.html').read_text()
assert '${activityPanel}</div></details>${clarificationHtml}' in ui, 'clarification must follow collapsible live actions so it stays visible at the bottom'
assert 'agentPlanApproval: false' in ui
assert len(chat)>20000, 'unexpected ChatService content'
print('PASS: Agent-only routing, preview/OK continuity, immutable user scope, attachments and safety guards')
print('PASS: no general plan-approval calls; read-only answers skip planner/snapshot')
print('PASS: clarification stays below collapsible activity details; ChatService untouched by design')
PY
