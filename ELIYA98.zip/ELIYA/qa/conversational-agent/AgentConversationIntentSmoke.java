package com.llmart.llm.service;

public class AgentConversationIntentSmoke {
    private static void equals(Object expect, Object actual, String input) {
        if (!expect.equals(actual)) throw new AssertionError(input + ": expected=" + expect + " actual=" + actual);
    }
    public static void main(String[] args) {
        equals(AgentConversationIntent.Kind.PLAN_PREVIEW,
                AgentConversationIntent.classify("Create an execution prompt and plan for Selenium migration"), "prompt planning");
        equals(AgentConversationIntent.Kind.PLAN_PREVIEW,
                AgentConversationIntent.classify("Here is my plan:\n1. inspect\n2. migrate"), "user supplied plan");
        equals(AgentConversationIntent.Kind.PLAN_PREVIEW,
                AgentConversationIntent.classify("Review this plan and suggest improvements"), "plan review");
        equals(AgentConversationIntent.Kind.CONTINUE_PLAN,
                AgentConversationIntent.classify("Please continue"), "continuation");
        equals(AgentConversationIntent.Kind.CONTINUE_PLAN,
                AgentConversationIntent.classify("OK"), "confirmation");
        equals(AgentConversationIntent.Kind.DIRECT,
                AgentConversationIntent.classify("Fix the timeout and test it"), "direct fix");
        equals(AgentConversationIntent.Kind.DIRECT,
                AgentConversationIntent.classify("Review this plan and execute it"), "explicit execution overrides preview");
        equals(true, AgentConversationIntent.looksLikeIndependentInstruction("Please fix this different bug"), "new task vs. clarification");
        equals(false, AgentConversationIntent.looksLikeIndependentInstruction("Use Java 17 and the current framework"), "clarification answer");
        equals(AgentConversationIntent.Kind.DIRECT,
                AgentConversationIntent.classify("Implement the following plan now"), "direct implementation");
        equals(AgentConversationIntent.Kind.DIRECT,
                AgentConversationIntent.classify("Generate test cases from attached Word file"), "artifact generation");
        equals(AgentConversationIntent.Kind.DIRECT,
                AgentConversationIntent.classify("Generate prompt.md from these requirements"), "explicit prompt artifact");
        equals(AgentConversationIntent.Kind.DIRECT,
                AgentConversationIntent.classify("Review my plan and implement the code changes"), "review plus implement");
        equals(true, AgentConversationIntent.isFastReadOnly("Explain E2E Deep Search working principle"), "read-only");
        equals(false, AgentConversationIntent.isFastReadOnly("Fix Deep Search performance"), "implementation");
        System.out.println("Agent conversational intent routing PASS");
    }
}
