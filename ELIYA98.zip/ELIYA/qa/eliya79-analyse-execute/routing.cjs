const assert = require('node:assert/strict');
const { decide, isExecutionRequest } = require('../../src/main/resources/static/unified-routing.js');
const cases = [
  ['Hi', 'analyse', 'chat'],
  ['Can you check what is there in workspace?', 'analyse', 'chat'],
  ['Can you explain E2E Deep Search working principles?', 'analyse', 'chat'],
  ['Analyze complete architecture of the framework', 'analyse', 'chat'],
  ['Analyze BMSA-1234 using Jira MCP', 'analyse', 'chat'],
  ['Can you review this code and list gaps?', 'analyse', 'chat'],
  ['Create a complete phase-wise migration plan', 'analyse', 'chat'],
  ['Generate a prompt for a TestNG migration', 'analyse', 'chat'],
  ['Create an architecture diagram plan', 'analyse', 'chat'],
  ['Create test cases from attached requirements', 'analyse', 'agent'],
  ['Can you create an agent in .opencode?', 'analyse', 'agent'],
  ['Fix this Selenium failure', 'analyse', 'agent'],
  ['Implement the four-phase plan we discussed', 'analyse', 'agent'],
  ['Check the source and fix the failures', 'analyse', 'agent'],
  ['Analyze the stack trace and implement the fix', 'analyse', 'agent'],
  ['Please continue', 'analyse', 'chat'],
  ['What is polymorphism?', 'execute', 'agent'],
  ['Check the workspace', 'execute', 'agent'],
  ['Run targeted tests', 'execute', 'agent'],
];
for (const [text, selectedMode, wanted] of cases) {
  assert.equal(decide({text, selectedMode}), wanted, `${selectedMode}: ${text}`);
}
assert.equal(decide({text:'Please continue', selectedMode:'analyse', previousAssistantText:'Shall I implement the suggested fixes?'}), 'agent');
assert.equal(decide({text:'Yes', selectedMode:'analyse', previousAssistantText:'Workspace contains 100 files.'}), 'chat');
assert.equal(decide({text:'Explain the architecture',selectedMode:'analyse',previousAssistantMode:'agent'}),'chat');
assert.equal(decide({text:'', selectedMode:'analyse',attachments:[{name:'requirements.docx'}]}),'chat');
assert.equal(isExecutionRequest('Please create a phase wise plan'),false);
assert.equal(isExecutionRequest('Generate all possible test cases'),true);
assert.equal(isExecutionRequest('Can you tell me how to implement this?'),false);
console.log('PASS ELIYA79: 25 explicit mode / consent / intent checks');
