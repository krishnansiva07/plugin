"""ELIYA79 Chromium smoke: actual composer, explicit modes, shared conversation, and long-answer rendering."""
import asyncio, re
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parents[2]/'src/main/resources/static'
OUT=Path('/mnt/data/eliya79_preview'); OUT.mkdir(exist_ok=True)
async def main():
 async with async_playwright() as pw:
  browser=await pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
  for width in [1440,390]:
   page=await browser.new_page(viewport={'width':width,'height':850})
   errors=[]; page.on('pageerror',lambda error:errors.append(str(error)))
   html=re.sub(r'<script src="[^"]+"></script>','',(ROOT/'index.html').read_text())
   html=re.sub(r'<link rel="stylesheet"[^>]+>','',html)
   await page.set_content(html)
   await page.add_style_tag(content=(ROOT/'app.css').read_text())
   await page.evaluate('''() => {
     window.__posted=[];
     window.fetch=async(url,opts={})=>{
       if(String(url).includes('/api/chat/stream')) {
         const request=JSON.parse(opts.body); window.__posted.push(request);
         const response={id:window.__posted.length,role:'assistant',content:'## Verified result\\n\\nA source-backed explanation from the workspace.'};
         const data='event: done\\ndata: '+JSON.stringify(response)+'\\n\\n';
         return new Response(data,{status:200,headers:{'Content-Type':'text/event-stream'}});
       }
       return new Response(JSON.stringify([]),{status:200,headers:{'Content-Type':'application/json'}});
     };
   }''')
   for name in ['markdown.js','prompt-catalog.js','unified-routing.js','app.js','confluence-composer.js']:
    await page.add_script_tag(content=(ROOT/name).read_text())
   assert await page.locator('[data-workflow]').count()==2
   assert await page.locator('[data-workflow="analyse"]').get_attribute('aria-pressed')=='true'
   assert await page.locator('#chatModelPicker').is_hidden()
   assert await page.locator('#agentModelPicker').is_hidden()
   await page.evaluate('''() => {
     state.config.apiKey='fake-key';state.config.baseUrl='http://example.test';
     state.config.model='agent-model';state.config.chatModel='chat-model';
     state.conversationId='same-conversation';state.project={id:'test-project',name:'Test project',localWorkspace:true};
     state.messages=[];updateModeUi();
   }''')
   for i,(query,mode) in enumerate([
      ('Can you check what is there in the workspace?', 'chat'),
      ('Explain the E2E architecture and prepare a phase-wise plan', 'chat'),
      ('Implement the phase-wise plan we discussed', 'agent'),
   ]):
    await page.locator('#messageInput').fill(query)
    await page.locator('#sendBtn').click()
    await page.wait_for_function('(n)=>window.__posted.length>=n',arg=i+1)
    sent=await page.evaluate('window.__posted[window.__posted.length-1]')
    assert sent['mode']==mode,(query,mode,sent['mode'])
    assert sent['conversationId']=='same-conversation'
    await page.wait_for_function('() => !state.streaming')
   assert await page.locator('[data-workflow="execute"]').get_attribute('aria-pressed')=='true'
   await page.locator('[data-workflow="analyse"]').click()
   await page.locator('#messageInput').fill('Why was the framework designed that way?')
   await page.locator('#sendBtn').click()
   await page.wait_for_function('() => window.__posted.length >= 4')
   assert (await page.evaluate('window.__posted[3].mode'))=='chat'
   await page.wait_for_function('() => !state.streaming')
   # Long transcript should render final actual answer, not only a progress card.
   await page.evaluate('''() => {state.messages.push({role:'assistant',mode:'chat',content:'## Architecture\\n\\n'+'Verified design. '.repeat(3000),streaming:false});renderMessages();}''')
   assert await page.locator('.message.assistant .message-content').count()>=1
   assert await page.evaluate('document.documentElement.scrollWidth <= window.innerWidth+2'),'horizontal overflow'
   assert not errors,errors
   await page.screenshot(path=str(OUT/f'modes_{width}.png'),full_page=False)
   await page.close()
  await browser.close()
 print('PASS ELIYA79: desktop/mobile Analyse -> Analyse -> Execute -> Analyse, one conversation, rendered long answer')
asyncio.run(main())
