#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../.."
node --check src/main/resources/static/app.js
node --check src/main/resources/static/unified-routing.js
node qa/eliya79-analyse-execute/routing.cjs
python3 qa/eliya79-analyse-execute/browser.py
bash qa/intelligence-smoke/run.sh
bash qa/eliya76-handoff/run.sh
bash qa/eliya78-conversation/run.sh
