#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../.."
D=$(mktemp -d); trap 'rm -rf "$D"' EXIT
javac --release 17 -d "$D" src/main/java/com/llmart/llm/service/AgentResultPresentation.java qa/eliya75-answer-integrity/AnswerIntegritySmoke.java
java -cp "$D" com.llmart.llm.service.AnswerIntegritySmoke
python3 - <<'PY'
from pathlib import Path
p=Path('src/main/java/com/llmart/llm/service/AgentService.java').read_text()
assert 'AgentResultPresentation.needsAnalysisAnswer(run.objective(), finalMessage)' in p
assert 'recoverDeepAnalysisAnswer(apiKey, request, messages, ws, run,' in p
assert 'AgentResultPresentation.addFileReport(finalMessage,' in p
assert 'llm.completeTextWithUsage(' in p
assert 'deepAnalysisMarkdownArtifact(ws, changes)' in p
assert 'Agent token management:' not in p
assert 'run.markFinalAnswer(finalMessage);' in p
assert 'Do not merely say' in p and 'HTML' in p
print('PASS ELIYA75: evidence-bounded answer recovery and preservation integration checks')
PY
