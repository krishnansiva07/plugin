package com.llmart.llm.service;
public class AnswerIntegritySmoke {
 static void ck(boolean ok,String reason){if(!ok)throw new AssertionError(reason);}
 public static void main(String[] args) {
  String question="Can you explain the complete end-to-end architecture flow from UI to API to database?";
  String narrative="## Architecture overview\n\nThe `RequestController` receives requests from the UI. " +
     "`Service` validates payloads and sends data to `Repository`, which handles persistence. " +
     "This explanation is only an illustrative test fixture, not an actual repository finding.";
  ck(AgentResultPresentation.isDeepAnalysis(question),"E2E architecture classified incorrectly");
  ck(AgentResultPresentation.needsAnalysisAnswer(question,"All approved plan steps completed successfully and the latest workspace revision passed verification."),"Generic internal success message accepted as actual architecture answer");
  ck(!AgentResultPresentation.needsAnalysisAnswer(question,narrative),"Substantive architecture analysis was discarded");
  ck(!AgentResultPresentation.needsAnalysisAnswer("Fix flaky Java tests","Done"),"Routine fixes should never trigger an analysis-only model call");
  ck(!AgentResultPresentation.needsAnalysisAnswer("Create two markdown files","I created 2 files"),"File generation should not trigger analysis model call");
  String fileReport="I created 2 files in the workspace.\n\n**Files:**\n- `architecture.md` — created\n- `diagram.md` — created\n\n**Verification:** Completed on latest revision.\n\nDo you want to add anything?";
  String result=AgentResultPresentation.addFileReport(narrative,fileReport);
  ck(result.startsWith(narrative),"Detailed answer lost when files were created");
  ck(result.contains("architecture.md") && result.contains("### Files and verification"),"Verified outputs absent");
  ck(result.endsWith("Do you want to add anything?"),"Question not at bottom");
  ck(result.indexOf("Do you want to add anything?")==result.lastIndexOf("Do you want to add anything?"),"Duplicate bottom question");
  ck(AgentResultPresentation.addFileReport("All approved plan steps completed successfully",fileReport).equals(fileReport),"Generic success placeholder was not replaced");
  ck(AgentResultPresentation.analysisSynthesisFallback("Agent run completed.","").contains("can't confirm"),"No evidence should not generate fake flow");
  ck(AgentResultPresentation.analysisSynthesisFallback("Agent run completed.","read-only search returned no matching files").contains("observations"),"Fallback should distinguish evidence from verified flow");
  System.out.println("PASS ELIYA75: 11 answer integrity scenarios");
 }
}
