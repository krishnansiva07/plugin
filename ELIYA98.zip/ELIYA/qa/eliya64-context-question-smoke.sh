#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
TMP=$(mktemp -d);trap 'rm -rf "$TMP"' EXIT
mkdir -p "$TMP/src/com/llmart/llm/dto" "$TMP/src/com/llmart/llm/service" "$TMP/src/com/fasterxml/jackson/core" "$TMP/src/com/fasterxml/jackson/databind" "$TMP/src/org/springframework/stereotype" "$TMP/classes"
cat > "$TMP/src/org/springframework/stereotype/Service.java" <<'EOF'
package org.springframework.stereotype;public @interface Service {}
EOF
cat > "$TMP/src/com/fasterxml/jackson/core/JsonProcessingException.java" <<'EOF'
package com.fasterxml.jackson.core;public class JsonProcessingException extends Exception {public JsonProcessingException(){super();}}
EOF
cat > "$TMP/src/com/fasterxml/jackson/databind/ObjectMapper.java" <<'EOF'
package com.fasterxml.jackson.databind;import com.fasterxml.jackson.core.JsonProcessingException;
public class ObjectMapper {public String writeValueAsString(Object v) throws JsonProcessingException{return String.valueOf(v);}}
EOF
cat > "$TMP/src/com/llmart/llm/dto/ChatSettings.java" <<'EOF'
package com.llmart.llm.dto;
public class ChatSettings {
 public String model(){return "m";}
 public int safeContextWindowTokens(String m){return 128000;}
 public int safeMaxTokens(){return 4000;}
 public int safeCompactionBufferTokens(String m){return 8000;}
 public int safeOldToolOutputChars(){return 1600;}
 public int safeCompactionKeepTokens(String m){return 8000;}
 public boolean autoCompactEnabled(){return true;}
}
EOF
cat > "$TMP/src/com/llmart/llm/service/AgentRunService.java" <<'EOF'
package com.llmart.llm.service;
public class AgentRunService {public static class AgentRun {public void checkCancelled(){}public String durableContextText(){return "state";}}}
EOF
cat > "$TMP/src/com/llmart/llm/service/Eliya64Smoke.java" <<'EOF'
package com.llmart.llm.service;
import java.util.*;import java.util.concurrent.*;
class Eliya64Smoke {
 static void check(boolean ok,String detail){if(!ok) throw new AssertionError(detail);}
 public static void main(String[] unused)throws Exception {
  var manager=new ContextWindowManager(new com.fasterxml.jackson.databind.ObjectMapper());
  String evidence="class Orders {"+" important evidence".repeat(110)+"}";
  var messages=new ArrayList<Map<String,Object>>();
  messages.add(new HashMap<>(Map.of("role","user","content",evidence)));
  messages.add(new HashMap<>(Map.of("role","tool","name","read","content",evidence)));
  messages.add(new HashMap<>(Map.of("role","tool","name","other","content",evidence)));
  messages.add(new HashMap<>(Map.of("role","tool","name","read","content",evidence)));
  check(manager.pruneRepeatedToolObservations(messages)==1,"exact duplicate should be omitted once");
  check(messages.get(1).get("content").toString().contains("Repeated tool output omitted"),"older duplicate not compacted");
  check(messages.get(3).get("content").equals(evidence),"newest full evidence must remain");
  check(messages.get(2).get("content").equals(evidence),"different tool output must remain");
  check(messages.get(0).get("content").equals(evidence),"user content must never be compacted");
  check(manager.pruneRepeatedToolObservations(messages)==0,"dedup must be idempotent");
  var questions=new AgentQuestionService();
  questions.enable("run64");
  var notifications=new CopyOnWriteArrayList<Map<String,Object>>();
  questions.observe("run64", notifications::add);
  var executor=Executors.newSingleThreadExecutor();
  try {
   var future=executor.submit(()->questions.ask("run64","Which repository?",List.of("a","b"),new AgentRunService.AgentRun()));
   Map<String,Object> pending=Map.of();
   for(int i=0;i<100;i++) {pending=questions.pending("run64");if(!pending.isEmpty())break;Thread.sleep(10);}
   check(!pending.isEmpty(),"question was not published");
   check(notifications.size()==1 && "clarification".equals(notifications.get(0).get("kind")),
       "question event was not emitted immediately to Terminal subscriber");
   String qid=String.valueOf(pending.get("id"));
   check(!questions.answer("run64",qid,"Custom",""),"empty custom answer should fail");
   check(!questions.answer("run64",qid,"unlisted","wrong"),"unlisted choice should fail");
   check(questions.answer("run64",qid,"Custom","Use repo B"),"typed custom answer should be accepted");
   check(future.get(2,TimeUnit.SECONDS).contains("Use repo B"),"custom answer lost");
   check(!questions.answer("run64",qid,"Custom","second"),"expired answer accepted");
   System.out.println("PASS: exact tool output dedup preserves evidence, user prompts, and idempotence; optional typed clarification validates and resumes");
  } finally {executor.shutdownNow();}
 }
}
EOF
javac --release 17 -d "$TMP/classes" $(find "$TMP/src" -name '*.java') src/main/java/com/llmart/llm/service/ContextWindowManager.java src/main/java/com/llmart/llm/service/AgentQuestionService.java
java -cp "$TMP/classes" com.llmart.llm.service.Eliya64Smoke
