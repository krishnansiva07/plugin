import com.llmart.llm.service.OpenCodeExecutionService;
import com.llmart.llm.service.ProjectService;
import com.llmart.llm.dto.ChatMode;
import com.llmart.llm.dto.ChatRequest;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sun.net.httpserver.HttpServer;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.*;

public class EngineSelectionSmoke {
    static void check(boolean condition, String message) { if (!condition) throw new AssertionError(message); }
    static void reply(com.sun.net.httpserver.HttpExchange e, int code, String body) throws Exception {
        byte[] data = body.getBytes(StandardCharsets.UTF_8);
        e.getResponseHeaders().set("Content-Type", "application/json");
        e.sendResponseHeaders(code, data.length);
        try(var stream=e.getResponseBody()) { stream.write(data); }
    }
    public static void main(String[] args) throws Exception {
        System.setProperty("eliya.opencode.stallSeconds", "3");
        Path base = Files.createTempDirectory("eliya92-monitor-");
        System.setProperty("eliya.opencode.sessionStore", base.toString());
        HttpServer mock = HttpServer.create(new InetSocketAddress("127.0.0.1", 0), 0);
        mock.createContext("/api/", e -> {
            try {
                String path = e.getRequestURI().getPath();
                if (path.equals("/api/info")) reply(e, 200, "{\"data\":{\"version\":\"2.2.2\"}}");
                else if (path.equals("/api/model/default")) reply(e, 200, "{\"data\":{\"id\":\"model_ready\"}}");
                else if (path.equals("/api/session")) reply(e, 200, "{\"data\":{\"id\":\"ses_no_events\"}}");
                else if (path.endsWith("/prompt")) reply(e, 200, "{\"data\":{\"id\":\"user_1\"}}");
                else if (path.equals("/api/session/active")) reply(e, 200, "{\"data\":{\"ses_no_events\":{\"state\":\"running\"}}}");
                else if (path.endsWith("/log")) {
                    e.getResponseHeaders().set("Content-Type", "text/event-stream");
                    e.sendResponseHeaders(200, 0);
                    e.getResponseBody().close();
                } else if (path.endsWith("/interrupt")) reply(e,200,"{\"interrupted\":true}");
                else reply(e, 404,"{}");
            } catch (Exception ex) { throw new RuntimeException(ex); }
        });
        ExecutorService workers = Executors.newCachedThreadPool(r -> {Thread t = new Thread(r); t.setDaemon(true);return t;});
        mock.setExecutor(workers); mock.start();
        OpenCodeExecutionService service = new OpenCodeExecutionService(new ObjectMapper(), new ProjectService(),
            "opencode", "http://127.0.0.1:"+mock.getAddress().getPort(),"local-secret-for-tests", "opencode",false);
        try {
            check(!service.availableForAuto(), "Auto must not trust an unproven executable/provider");
            var req = new ChatRequest("proj1", "Create sample.txt", List.of(), ChatMode.AGENT, new ChatRequest.Settings("test-model"));
            String id = String.valueOf(service.launch(req,null).get("id"));
            // Regression 96: a quiet model run is still RUNNING when OpenCode's
            // authoritative /session/active endpoint reports the session active.
            Thread.sleep(6100);
            var response = service.get(id);
            check("running".equals(response.get("status")), "Active OpenCode task was falsely stalled: " + response);
            check(!"completed".equals(response.get("status")),"Must not report success without completion evidence");
            check("cancelled".equals(service.cancel(id).get("status")),"Active quiet session must remain cancellable");
            System.out.println("PASS: silent but active OpenCode session remains running, no false completion, cancellation preserved");
        } finally { service.shutdown();mock.stop(0);workers.shutdownNow(); }
    }
}
