import com.llmart.llm.service.OpenCodeExecutionService;
import com.llmart.llm.service.ProjectService;
import com.llmart.llm.dto.ChatMode;
import com.llmart.llm.dto.ChatRequest;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sun.net.httpserver.HttpServer;
import java.net.InetSocketAddress;
import java.nio.file.Files;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

/** A responsive HTTP server without a usable configured model is NOT a working agent. */
public class NoModelPreflightSmoke {
    public static void main(String[] args) throws Exception {
        System.setProperty("eliya.opencode.sessionStore", Files.createTempDirectory("no-model-test").toString());
        var server = HttpServer.create(new InetSocketAddress("127.0.0.1", 0), 0);
        var sessionCreates = new AtomicInteger();
        server.createContext("/api/", request -> {
            String path = request.getRequestURI().getPath();
            String body;
            if (path.equals("/api/info")) body = "{\"data\":{\"version\":\"2.2.2\"}}";
            else if (path.equals("/api/model/default")) body = "{\"data\":null}";
            else {
                sessionCreates.incrementAndGet();
                body = "{\"data\":{\"id\":\"unexpected_session\"}}";
            }
            byte[] bytes = body.getBytes(java.nio.charset.StandardCharsets.UTF_8);
            request.sendResponseHeaders(200, bytes.length);
            try (var response = request.getResponseBody()) { response.write(bytes); }
        });
        server.start();
        var service = new OpenCodeExecutionService(new ObjectMapper(), new ProjectService(),
                "opencode", "http://127.0.0.1:"+server.getAddress().getPort(), "mock-password", "opencode", false);
        try {
            if (service.availableForAuto()) throw new AssertionError("Auto must not trust untested providers");
            var instruction = new ChatRequest("proj1", "Create file.txt", List.of(), ChatMode.AGENT,
                    new ChatRequest.Settings("legacy-only-model"));
            try {
                service.launch(instruction, null);
                throw new AssertionError("The instruction was submitted to an unconfigured model");
            } catch (IllegalStateException expected) {
                if (!expected.getMessage().contains("OpenCode launch failed")) throw expected;
            }
            if (sessionCreates.get() != 0) throw new AssertionError("OpenCode created a session despite a failed preflight");
            System.out.println("PASS: missing OpenCode model fails before any task/session submission; Auto stays Legacy");
        } finally {service.shutdown();server.stop(0);}
    }
}
