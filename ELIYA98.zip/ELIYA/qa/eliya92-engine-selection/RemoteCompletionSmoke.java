import com.llmart.llm.service.OpenCodeExecutionService;
import com.llmart.llm.service.ProjectService;
import com.llmart.llm.dto.ChatMode;
import com.llmart.llm.dto.ChatRequest;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sun.net.httpserver.HttpServer;
import java.net.InetSocketAddress;
import java.nio.file.Files;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.concurrent.Executors;

/** A quiet SSE stream must still finish when the documented message/active APIs prove completion. */
public class RemoteCompletionSmoke {
    static void reply(com.sun.net.httpserver.HttpExchange e, String body) throws Exception {
        byte[] payload = body.getBytes(StandardCharsets.UTF_8);
        e.sendResponseHeaders(200, payload.length);
        try (var output = e.getResponseBody()) { output.write(payload); }
    }
    public static void main(String[] args) throws Exception {
        System.setProperty("eliya.opencode.stallSeconds", "30");
        System.setProperty("eliya.opencode.sessionStore", Files.createTempDirectory("eliya-quiet-completion").toString());
        HttpServer mock = HttpServer.create(new InetSocketAddress("127.0.0.1", 0), 0);
        mock.setExecutor(Executors.newCachedThreadPool(r->{ Thread t=new Thread(r,"quiet-mock");t.setDaemon(true);return t; }));
        mock.createContext("/api/", e -> {
            try {
                String path=e.getRequestURI().getPath();
                if (path.equals("/api/info")) reply(e,"{\"data\":{\"version\":\"2.2.2\"}}");
                else if (path.equals("/api/model/default")) reply(e,"{\"data\":{\"id\":\"configured\"}}");
                else if (path.equals("/api/session")) reply(e,"{\"data\":{\"id\":\"ses_quiet_success\"}}");
                else if (path.endsWith("/prompt")) reply(e,"{\"data\":{\"id\":\"user_1\"}}");
                else if (path.equals("/api/session/active")) reply(e,"{\"data\":{}}");
                else if (path.endsWith("/message")) {
                    if ("type=all".equals(e.getRequestURI().getQuery())) throw new AssertionError("Invalid type=all request");
                    reply(e,"{\"data\":{\"items\":[{\"info\":{\"id\":\"assistant_1\",\"role\":\"assistant\"},\"parts\":[{\"type\":\"text\",\"text\":\"Created sample.txt\"}]},{\"info\":{\"id\":\"user_1\",\"role\":\"user\"}}]}}");
                } else if (path.endsWith("/diff")) reply(e,"{\"data\":[]}");
                else if (path.endsWith("/log")) { e.getResponseHeaders().set("Content-Type","text/event-stream");e.sendResponseHeaders(200,0);e.getResponseBody().close(); }
                else reply(e,"{}");
            } catch(Exception ex){throw new RuntimeException(ex);}
        });
        mock.start();
        OpenCodeExecutionService service=new OpenCodeExecutionService(new ObjectMapper(),new ProjectService(),
                "opencode", "http://127.0.0.1:"+mock.getAddress().getPort(),"test-secret", "opencode",false);
        try {
            if (service.availableForAuto()) throw new AssertionError("Unproven task should start Legacy");
            var input=new ChatRequest("proj1", "Create sample.txt", List.of(), ChatMode.AGENT, new ChatRequest.Settings("test"));
            String id=String.valueOf(service.launch(input,null).get("id"));
            boolean completed=false;
            for(int i=0;i<110;i++) {
                if ("completed".equals(service.get(id).get("status"))) { completed=true;break; }
                Thread.sleep(150);
            }
            if (!completed) throw new AssertionError("Quiet but completed OpenCode run never reconciled: " + service.get(id));
            if (!service.availableForAuto()) throw new AssertionError("Verified successful execution should activate Auto");
            if (!String.valueOf(service.get(id).get("answer")).contains("Created sample.txt")) throw new AssertionError("Model answer lost");
            System.out.println("PASS: quiet OpenCode run completed from message history + inactive status, Auto activated only after proof");
        } finally { service.shutdown();mock.stop(0); }
    }
}
