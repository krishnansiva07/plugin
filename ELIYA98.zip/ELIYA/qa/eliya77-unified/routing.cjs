// Legacy one-composer routing tests have been superseded by the explicit ELIYA79
// Analyse/Execute contract. Keep the historical entry point usable for CI.
require('../eliya79-analyse-execute/routing.cjs');
