import asyncio,re
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parents[2]/'src/main/resources/static'
OUT=Path('/mnt/data/eliya77_preview')
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
  for w,h in [(1440,900),(390,844)]:
   page=await browser.new_page(viewport={'width':w,'height':h})
   html=re.sub(r'<script src="[^"]+"></script>','',(ROOT/'index.html').read_text())
   html=re.sub(r'<link rel="stylesheet"[^>]+>','',html)
   await page.set_content(html)
   await page.add_style_tag(content=(ROOT/'app.css').read_text())
   await page.evaluate('''() => {window.fetch=async()=>new Response('[]',{status:200,headers:{'Content-Type':'application/json'}});}''')
   for name in ['markdown.js','prompt-catalog.js','unified-routing.js','app.js','confluence-composer.js']:
    await page.add_script_tag(content=(ROOT/name).read_text())
   await page.evaluate('''() => {
    state.config.apiKey='masked';state.config.baseUrl='https://example.invalid';
    state.config.chatModel='conversation-model';state.config.model='execution-model';
    state.project={id:'test',name:'automation-framework',localWorkspace:true,files:1500};
    state.messages=[{role:'user',content:'Explain the E2E architecture flow of Deep Search'},
      {role:'assistant',mode:'agent',content:'## Deep Search — E2E architecture\\n\\nThe system starts with workspace indexing, then retrieves relevant symbols and source evidence. It builds context for the selected model, follows dependencies across files and streams the explanation back into this conversation.\\n\\n**Suggested next step:** Would you like a detailed class-by-class flow diagram?'}];
    document.querySelector('.setup-card').classList.add('hidden');
    document.querySelector('#welcome').classList.add('hidden');
    document.getElementById('conversationTitle').textContent='Deep Search architecture';
    updateModeUi();updateModelBadge();renderMessages();renderProjectBar();
  }''')
   await page.wait_for_timeout(350)
   await page.screenshot(path=str(OUT/f'unified_{w}.png'))
   await page.close()
  await browser.close()
 print('Preview saved')
asyncio.run(main())
