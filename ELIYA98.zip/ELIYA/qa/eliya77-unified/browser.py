"""Compatibility CI entry point: unified UI now has explicit Analyse/Execute modes."""
from pathlib import Path
import runpy
runpy.run_path(str(Path(__file__).resolve().parents[1]/'eliya79-analyse-execute/browser.py'),run_name='__main__')
