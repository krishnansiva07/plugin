"""ELIYA74 browser acceptance: stable streaming/final answers, readable Agent/Terminal, and mobile widths.
Uses fake session data; no provider/server credentials required."""
import asyncio, re, os
from pathlib import Path
from playwright.async_api import async_playwright

ROOT=Path(__file__).resolve().parent.parent/'src/main/resources/static'
OUT=Path(os.environ.get('ELIYA74_SCREENSHOTS','/mnt/data/eliya74_preview'))
OUT.mkdir(parents=True,exist_ok=True)

async def main():
 async with async_playwright() as pw:
  browser=await pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
  for width,height in [(1440,900),(390,844)]:
   page=await browser.new_page(viewport={'width':width,'height':height},device_scale_factor=1)
   errors=[]
   page.on('pageerror',lambda err:errors.append(str(err)))
   html=re.sub(r'<script src="[^"]+"></script>','',(ROOT/'index.html').read_text())
   html=re.sub(r'<link rel="stylesheet"[^>]+>','',html)
   await page.set_content(html)
   await page.add_style_tag(content=(ROOT/'app.css').read_text())
   await page.evaluate('''() => {
     window.fetch=async()=>new Response(JSON.stringify([]),{status:200,headers:{'Content-Type':'application/json'}});
   }''')
   for name in ['markdown.js','prompt-catalog.js','app.js','confluence-composer.js']:
    await page.add_script_tag(content=(ROOT/name).read_text())
   await page.evaluate('''() => {
     state.mode='agent';updateModeUi();
     state.messages=[{role:'user',content:'Create agent and reusable skill.'},
      {role:'assistant',mode:'agent',content:'I created 2 files: `.opencode/agents/code-reviewer.md` and `.opencode/skills/one-class-one-responsibility.md`.\\n\\nDo you want to add anything?',streaming:false,
       agentRunId:'r74',agentSteps:[{tool:'read',status:'success',step:1,detail:'Inspected workspace'},{tool:'write',status:'success',step:2,detail:'Created files'}],
       agentProgress:{percent:100,phase:'completed',status:'completed',detail:'2 files created',plan:[{index:1,text:'Inspect workspace',status:'completed'},{index:2,text:'Create agent and skill',status:'completed'}]}}];
     renderMessages();
   }''')
   assert await page.get_by_text('Do you want to add anything?',exact=False).count()>0
   await page.screenshot(path=str(OUT/f'agent_{width}.png'))
   await page.locator('.agent-run-disclosure > summary').click()
   await page.locator('.agent-activity-panel summary').click()
   assert await page.locator('.agent-activity-panel').evaluate('(n)=>n.open')
   await page.evaluate('refreshAgentCard(1)')
   assert await page.locator('.agent-activity-panel').evaluate('(n)=>n.open'), 'Expanded Agent details collapsed'
   assert await page.evaluate('document.documentElement.scrollWidth <= window.innerWidth+2'), 'Agent layout horizontally overflows'
   # Agent may hide its own folder setup without overwriting Chat's preference.
   await page.evaluate('''() => {state.workspaceFoldersVisible=true;state.agentFoldersVisible=false;state.mode='agent';updateModeUi();}''')
   assert await page.locator('#workspaceConfiguration').is_hidden()
   await page.click('#workspaceVisibilityToggle')
   assert await page.locator('#workspaceConfiguration').is_visible()
   await page.evaluate('''() => {state.mode='chat';updateModeUi();}''')
   assert await page.locator('#workspaceConfiguration').is_visible(), 'Chat folder visibility was mutated by Agent'
   await page.evaluate('''() => {state.mode='agent';state.agentFoldersVisible=false;updateModeUi();}''')
   await page.evaluate('''() => {
     document.getElementById('terminalDock').classList.remove('hidden');
     document.getElementById('terminalConfigPanel').open=false;
     terminalUi.visible=true;terminalUi.selected='s74';
     terminalUi.sessions=[{id:'s74',status:'running',prompt:'Create agents'}];
     terminalUi.detail={id:'s74',runId:'r74',status:'running',prompt:'Create agents',turns:[{role:'user',content:'Create agent and a reusable skill'}],
       queue:[],question:{},events:[{seq:1,type:'agent_step',data:{tool:'write',status:'success',detail:'Created agent definition',output:'OK'}}],
       answer:'I created 2 files: `code-reviewer.md` and `one-class-one-responsibility.md`.',
       progress:{progressPercent:83,progressPhase:'execute',progressDetail:'Writing files…',plan:[{status:'completed',text:'Write agent'},{status:'in_progress',text:'Write skill'}]}};
     renderTerminalUi();
   }''')
   assert await page.locator('.terminal-stream-raw').count()==1
   await page.evaluate('''() => {
      terminalUi.detail={...terminalUi.detail,status:'completed',answer:'',turns:[{role:'user',content:'Create agent and a reusable skill'}],progress:{progressPercent:100}};
      renderTerminalUi();
   }''')
   assert await page.locator('.terminal-final-answer').count()==1,'Streaming response vanished on completion without persisted turn'
   assert 'I created 2 files' in await page.locator('.terminal-final-answer').inner_text()
   await page.evaluate('''() => {
      terminalUi.detail={...terminalUi.detail,turns:[{role:'user',content:'Create agent and a reusable skill'},
          {role:'assistant',content:'Created files and verified both. Do you want to add anything?'}]};
      renderTerminalUi();
   }''')
   assert await page.locator('.terminal-final-answer').count()==1,'Final answer duplicated'
   assert 'Do you want to add anything?' in await page.locator('.terminal-final-answer').inner_text()
   assert await page.evaluate('document.documentElement.scrollWidth <= window.innerWidth+2'), 'Terminal layout overflows viewport'
   await page.screenshot(path=str(OUT/f'terminal_{width}.png'))
   assert not errors,errors
   await page.close()
  await browser.close()
 print('PASS ELIYA74: Agent disclosure persistence; final-answer continuity; no duplicate answer; 1440/390 widths; no browser errors')
asyncio.run(main())
