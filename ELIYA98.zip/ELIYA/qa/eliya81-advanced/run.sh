#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../.."
TMP="$(mktemp -d)";trap 'rm -rf "$TMP"' EXIT
javac -encoding UTF-8 -d "$TMP" src/main/java/com/llmart/llm/service/WorkspaceChunkIntelligence.java qa/eliya81-advanced/ChunkQualitySmoke.java
java -cp "$TMP" com.llmart.llm.service.ChunkQualitySmoke
javac -encoding UTF-8 -d "$TMP" src/main/java/com/llmart/llm/service/WorkspaceCodeIntelligence.java qa/eliya81-advanced/CrossLanguageSmoke.java
java -cp "$TMP" com.llmart.llm.service.CrossLanguageSmoke
node --check src/main/resources/static/conversation-render-diff.js
node --check src/main/resources/static/app.js
node qa/eliya81-advanced/renderer.cjs
node qa/eliya81-advanced/diagrams.cjs
node qa/eliya81-advanced/intents.cjs
python3 qa/eliya81-advanced/browser.py
bash qa/intelligence-smoke/run.sh
node qa/eliya80-conversational-intelligence/conversation.cjs
