const assert=require('node:assert/strict');
const diagram=require('../../src/main/resources/static/architecture-diagrams.js');
const svg=diagram.render('flowchart LR\nA[Request] --> B[Index] --> C[Analysis]');
assert.match(svg,/<svg/);assert.match(svg,/Request/);assert.match(svg,/Analysis/);
const attack=diagram.render('flowchart LR\nA[<script>alert(1)</script>] --> B[Answer]');
assert.ok(!attack.includes('<script>'),'HTML is never injected');
assert.equal(diagram.render('unknown js'), '');
assert.equal(diagram.render('flowchart TD\n'+('x'.repeat(9000))), '');
console.log('PASS ELIYA81: offline architecture diagrams, safe escaping, bounded rendering');
