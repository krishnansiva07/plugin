package com.llmart.llm.service;

import java.nio.file.*;
import java.util.*;

public class ChunkQualitySmoke {
    public static void main(String[] args) throws Exception {
        String first = "import java.io.IOException;\nclass Header { void load() {} }\n";
        String middle = "class ActualService { void synchronizePaymentState() { System.out.println(\"PAYMENT_SENT\"); } }\n";
        String end = "class Footer { void dispose() {} }\n";
        Path dir = Files.createTempDirectory("eliya-chunks");
        Path path = dir.resolve("Service.java");
        try {
            Files.writeString(path, first.repeat(40) + middle + end.repeat(40));
            var index = new WorkspaceChunkIntelligence();
            var result = index.find(dir, "Service.java", Set.of("synchronizepaymentstate"), 2);
            require(!result.isEmpty(), "Deep middle of file must be retrievable");
            require(result.get(0).text().contains("synchronizePaymentState"), "Result must contain actual source");
            require(result.get(0).startLine() > 20, "Line numbers must be grounded");
            require(index.find(dir, "../outside.java", Set.of("payment"), 2).isEmpty(), "Path traversal rejected");
            Files.writeString(path, "class Changed { void renderArchitecture() {} }");
            require(index.find(dir,"Service.java",Set.of("renderarchitecture"),2).size()==1,"Changed file refreshes passages");
            require(index.find(dir,"Service.java",Set.of("synchronizepaymentstate"),2).isEmpty(),"Stale passages invalidated");
            System.out.println("PASS ELIYA81: exact line citations, deep chunk matches, traversal guard, incremental invalidation");
        } finally {Files.deleteIfExists(path); Files.deleteIfExists(dir);}
    }
    private static void require(boolean check,String reason) {if(!check)throw new AssertionError(reason);}
}
