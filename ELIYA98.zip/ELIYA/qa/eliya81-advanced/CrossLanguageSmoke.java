package com.llmart.llm.service;
public class CrossLanguageSmoke {
    public static void main(String[] args) {
        var py = WorkspaceCodeIntelligence.analyse("core/payments.py", "from api.client import API\nclass PaymentGateway:\n    def authorize(self):\n        return 1\n");
        require(py.references().contains("api.client"), "Python import graph");
        require(py.symbols().containsKey("symbol:PaymentGateway"), "Python class symbols");
        var go = WorkspaceCodeIntelligence.analyse("payment/main.go", "package payment\nimport (\n \"org/project/service\"\n)\ntype Payment struct{}\nfunc Execute() {}\n");
        require(go.references().contains("org/project/service"), "Go import graph");
        require(go.symbols().containsKey("symbol:Execute"), "Go function symbols");
        var cs = WorkspaceCodeIntelligence.analyse("app/Order.cs", "using Company.Api;\nnamespace Company { public class OrderService {} }");
        require(cs.references().contains("Company.Api"), "C# using graph");
        require(cs.symbols().containsKey("symbol:OrderService"), "C# class symbols");
        System.out.println("PASS ELIYA81: Python, Go and C# symbol/import indexing");
    }
    private static void require(boolean check,String reason) {if(!check)throw new AssertionError(reason);}
}
