"""Real Chromium checks for incremental answer rendering, diagram safety and responsive Terminal."""
import asyncio,re
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parents[2]/'src/main/resources/static'
OUT=Path('/mnt/data/eliya81_preview');OUT.mkdir(exist_ok=True)
async def main():
 async with async_playwright() as pw:
  browser=await pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
  for width in (1440,390):
   page=await browser.new_page(viewport={'width':width,'height':900})
   errors=[];page.on('pageerror',lambda exc:errors.append(str(exc)))
   html=re.sub(r'<script src="[^"]+"></script>','',(ROOT/'index.html').read_text())
   html=re.sub(r'<link rel="stylesheet"[^>]+>','',html)
   await page.set_content(html)
   await page.add_style_tag(content=(ROOT/'app.css').read_text())
   for name in ['architecture-diagrams.js','markdown.js','prompt-catalog.js','unified-routing.js','conversation-intelligence.js','conversation-render-diff.js','app.js','confluence-composer.js']:
    await page.add_script_tag(content=(ROOT/name).read_text())
   await page.evaluate('''() => {
      state.messages=[{id:'u1',role:'user',content:'Explain my architecture'},
       {id:'a1',role:'assistant',mode:'chat',content:'## Workspace architecture\\n\\n```mermaid\\nflowchart LR\\nA[Workspace] --> B[Index] --> C[Analysis]\\n```'}];
      renderMessages();window.__first=document.querySelector('[data-message-index="0"]');
      window.__second=document.querySelector('[data-message-index="1"]');
   }''')
   assert await page.locator('.eliya-architecture-diagram svg').count()==1
   await page.evaluate('''() => {state.messages.push({id:'u2',role:'user',content:'Do a deep dive'});renderMessages();}''')
   assert await page.evaluate('document.querySelector(`[data-message-index="0"]`)===window.__first')
   # The last assistant may need to refresh its Regenerate/Next Step actions.
   # Older user content must remain mounted unchanged.
   await page.evaluate('''() => {state.messages[1].content+='\\n\\nNew verified finding';renderMessages();}''')
   assert await page.locator('.message.assistant').get_by_text('New verified finding').count()==1
   assert await page.evaluate('document.querySelector(`[data-message-index="0"]`)===window.__first')
   assert await page.evaluate('document.documentElement.scrollWidth<=window.innerWidth+2')
   await page.screenshot(path=str(OUT/f'analysis_{width}.png'),full_page=False)
   assert not errors,errors
   await page.close()
  await browser.close()
 print('PASS ELIYA81 Chromium: stable old DOM, updated answers, inline diagrams, mobile widths')
asyncio.run(main())
