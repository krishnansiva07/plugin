#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../.."
D="$(mktemp -d)"; trap 'rm -rf "$D"' EXIT
javac --release 17 -d "$D" src/main/java/com/llmart/llm/service/AgentOutcomeReviewPolicy.java qa/outcome-review-smoke/OutcomeReviewSmoke.java
java -cp "$D" OutcomeReviewSmoke
python3 - <<'PY'
from pathlib import Path
s = Path('src/main/java/com/llmart/llm/service/AgentService.java').read_text()
w = Path('src/main/java/com/llmart/llm/service/AgentWorkspaceService.java').read_text()
assert 'COMPLETE CHANGED-FILE HASH MANIFEST' in s
assert 'LATEST TARGETED TOOL EVIDENCE' in s
assert 'String key = outcomeEvidenceKey(ws, run);' in s
assert 'cachedStepCompletionGate(apiKey, request, ws, run, step, onStep, stepEvidenceReviews)' in s
assert 'finalOutcomeEvidenceAttempts.merge(reviewKey, 1, Integer::sum)' in s
assert 'finalOutcomeStalls <= 2' in s
assert 'reviewer could not SEE enough evidence' in s or 'reviewer could not SEE enough evidence'.lower() in s.lower()
assert 'run.lastSuccessfulVerificationRevision() < run.mutationRevision()' in s
assert 'Do not bypass the whole-plan gate for single compatibility verifier calls.' in s
assert 'return MISSING_EVIDENCE' in s
assert 'mutation is NOT required for an idempotent run' in s
assert 'No independent verifier succeeded for this run' in s
assert 'run.verificationAttemptCount() > successfulVerificationBefore' in s
assert 'run.verificationAttemptCount() > verifierBeforeBatch' in s
r = Path('src/main/java/com/llmart/llm/service/AgentRunService.java').read_text()
assert 'verificationAttemptCount.incrementAndGet()' in r
assert 'setLong(run.verificationAttemptCount, p, "verificationAttemptCount", 0)' in r
assert 'workspaceChangeManifest(Workspace ws)' in w
assert 'readOnly' in s
assert 'request.settings().criticModelOrPrimary()' in s
print('PASS: runtime integration contracts and fail-closed completion gates')
PY
