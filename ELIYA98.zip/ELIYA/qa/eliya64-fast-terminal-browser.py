"""ELIYA64 incremental stream, pinned clarification, keyboard and reconnect smoke.
All provider and server responses are deterministic browser mocks."""
import asyncio, re
from pathlib import Path
from playwright.async_api import async_playwright

ROOT = Path(__file__).resolve().parent.parent / 'src/main/resources/static'

async def main():
    async with async_playwright() as pw:
        browser=await pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
        page=await browser.new_page(viewport={'width':1200,'height':770})
        errors=[];page.on('pageerror',lambda err:errors.append(str(err)))
        html=re.sub(r'<script src="[^"]+"></script>','',(ROOT/'index.html').read_text())
        html=re.sub(r'<link rel="stylesheet"[^>]+>','',html)
        await page.set_content(html)
        await page.add_style_tag(content=(ROOT/'app.css').read_text())
        await page.evaluate('''() => {
          window.__answerCalls=[];
          window.__detail={id:'s64',conversationId:'c64',status:'running',runId:'r64',
            projectId:'p64',prompt:'Analyze repo',fullPrompt:'Analyze repo',turns:[{role:'user',content:'Analyze repo'}],
            queue:[],question:{},answer:'',sequence:5,events:[
              {seq:4,type:'agent_step',data:{tool:'read',status:'success',detail:'Read README.md'}},
              {seq:5,type:'agent_step',data:{tool:'bash',status:'success',detail:'Run tests',output:'OK'}}
            ]};
          window.fetch=async(url,opts={})=>{
            const path=String(url),method=opts.method||'GET';let answer={};
            if(path.endsWith('/answer') && method==='POST') {
              const request=JSON.parse(opts.body);window.__answerCalls.push(request);
              window.__detail.question={};window.__detail.status='running';
              answer={id:'s64',status:'running'};
            } else if(path.endsWith('/events')) {
              return new Response('',{status:404,headers:{'Content-Type':'text/plain'}});
            } else if(path==='/api/terminal/sessions') answer=[{id:'s64',prompt:'Analyze repo',status:window.__detail.status}];
            else if(path==='/api/terminal/sessions/s64')answer=window.__detail;
            else if(path.includes('/activity')) answer={events:window.__detail.events,hasMore:false};
            else if(path.includes('terminal/workspaces')) answer=[{id:'p64',name:'Workspace',localPath:'/tmp/repo'}];
            return new Response(JSON.stringify(answer),{status:200,headers:{'Content-Type':'application/json'}});
          };
        }''')
        for script in ['markdown.js','prompt-catalog.js','app.js','confluence-composer.js']:
            await page.add_script_tag(content=(ROOT/script).read_text())
        await page.evaluate('''() => {
            terminalUi.visible=true;terminalUi.selected='s64';terminalUi.detail=window.__detail;
            terminalUi.sessions=[{id:'s64',status:'running',prompt:'Analyze repo'}];
            document.querySelector('#terminalDock').classList.remove('hidden');
            renderTerminalUi();
            const detail=document.querySelector('[data-action-detail="5"]');detail.open=true;
            window.__originalMessage=document.querySelector('.terminal-message');
            window.__originalToolDetail=detail;
          }''')
        for i,word in [(6,'Hello '),(7,'world'),(8,'!')]:
            await page.evaluate('''([i,word])=>terminalApplyStreamDelta('s64',{type:'token',seq:i,text:word})''',[i,word])
        assert await page.locator('.terminal-stream-raw').inner_text()=='Hello world!'
        # The hot path must preserve completed message/tool nodes: no repeated innerHTML rebuild.
        kept=await page.evaluate('''() => ({
          message:window.__originalMessage===document.querySelector('.terminal-message'),
          detail:window.__originalToolDetail===document.querySelector('[data-action-detail="5"]'),
          expanded:window.__originalToolDetail.open})''')
        assert kept=={'message':True,'detail':True,'expanded':True},kept
        await page.evaluate('''() => {
          terminalApplyStreamDelta('s64',{type:'agent_step',seq:9,
            data:{tool:'grep',status:'success',detail:'Scanned symbols',output:'alerts()'}});
        }''')
        assert await page.locator('[data-action-seq="9"]').count()==1
        await page.evaluate('''() => {
          window.__detail.status='needs_input';
          window.__detail.question={kind:'clarification',id:'q64',reason:'Which Git repository?',choices:['repo-a','repo-b','Cancel']};
          terminalUi.detail=window.__detail;
          renderTerminalUi();
        }''')
        dock=page.locator('#terminalDecisionDock')
        assert await dock.is_visible() and await dock.get_by_text('Which Git repository?').is_visible()
        assert await page.locator('#terminalOutput .terminal-question').count()==0,'Question must not scroll with tools'
        await page.fill('#terminalClarificationText','Please use /workspace/repo-b')
        # Identical server snapshots must not erase the draft or rebuild the decision panel.
        await page.evaluate('renderTerminalUi()')
        assert await page.input_value('#terminalClarificationText')=='Please use /workspace/repo-b'
        await page.locator('#terminalClarificationText').press('Enter')
        await page.wait_for_function('() => window.__answerCalls.length === 1')
        first=await page.evaluate('window.__answerCalls[0]')
        assert first=={'questionId':'q64','choice':'Custom','detail':'Please use /workspace/repo-b'},first
        # A second question can be answered through a suggested option, no scroll needed.
        await page.evaluate('''() => {
          window.__detail.status='needs_input';
          window.__detail.question={kind:'clarification',id:'q65',reason:'Which module?',choices:['server','client','Cancel']};
          terminalUi.detail=window.__detail;renderTerminalUi();
        }''')
        await page.locator('[data-answer-choice="client"]').click()
        await page.wait_for_function('() => window.__answerCalls.length===2')
        second=await page.evaluate('window.__answerCalls[1]')
        assert second['questionId']=='q65' and second['choice']=='client',second
        # Type the answer in the normal composer as an alternative to the dock textarea.
        await page.evaluate('''() => {
          window.__detail.status='needs_input';
          window.__detail.question={kind:'clarification',id:'q66',reason:'Specify directory',choices:['Cancel']};
          terminalUi.detail=window.__detail;renderTerminalUi();
        }''')
        await page.fill('#terminalTask','Use the backend folder under C:/work')
        await page.press('#terminalTask','Enter')
        await page.wait_for_function('() => window.__answerCalls.length===3')
        third=await page.evaluate('window.__answerCalls[2]')
        assert third['questionId']=='q66' and third['choice']=='Custom' and third['detail'].startswith('Use the backend'),third
        # Exercise actual fetch-stream frame parsing, including split CRLF frames.
        await page.evaluate(r"""() => {
          window.__detail.status='running';window.__detail.question={};
          terminalUi.detail=window.__detail;renderTerminalUi();
          terminalStopStream();terminalUi.streamUnsupported=false;
          window.__fallbackFetch=window.fetch;
          window.fetch=(url,options={})=>{
            if(String(url).endsWith('/events')) {
              const encoder=new TextEncoder();
              const stream=new ReadableStream({start(controller){
                const frames=[
                  'data: {"type":"token","seq":11,"text":"SSE "}\r',
                  '\n\r\ndata: {"type":"token","seq":12,"text":"works"}\r\n\r\n'
                ];
                for(const frame of frames)controller.enqueue(encoder.encode(frame));
                setTimeout(()=>controller.close(),300);
              }});
              return Promise.resolve(new Response(stream,{status:200,headers:{'Content-Type':'text/event-stream'}}));
            }
            return window.__fallbackFetch(url,options);
          };
          terminalEnsureStream();
        }""")
        await page.wait_for_function('() => (terminalUi.detail?.answer || "").includes("SSE works")')
        assert 'SSE works' in await page.locator('.terminal-stream-raw').inner_text()
        await page.evaluate('terminalStopStream()')
        elapsed=await page.evaluate('''() => {
          const start=performance.now();
          for(let seq=13;seq<513;seq++)terminalApplyStreamDelta('s64',{type:'token',seq,text:'x'});
          return Math.round(performance.now()-start);
        }''')
        assert await page.locator('.terminal-stream-raw').inner_text(), 'Rapid token updates disappeared'
        await page.evaluate('terminalUi.visible=false')
        print(f'MEASURED synthetic 500 Terminal token updates: {elapsed} ms (local mocked Chromium, not provider latency)')
        assert not errors, errors
        await browser.close()
    print('PASS: incremental token text, no tool/message DOM replacement, chronological action updates, sticky clarification, option/custom/Enter/composer answers')

if __name__=='__main__':asyncio.run(main())
