import com.llmart.llm.service.OpenCodeExecutionService;
import com.llmart.llm.service.ProjectService;
import com.llmart.llm.dto.ChatMode;
import com.llmart.llm.dto.ChatRequest;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sun.net.httpserver.HttpServer;
import com.sun.net.httpserver.HttpExchange;
import java.net.*;
import java.nio.file.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;
import java.lang.reflect.*;

/** Negative contract tests: don't mark planning-only model output as completed code edits. */
public final class OpenCodeContractSmoke {
  static void check(boolean truth,String message) { if(!truth) throw new AssertionError(message); }
  static void reply(HttpExchange h,int status,String s) throws java.io.IOException {
    byte[] body=s.getBytes(StandardCharsets.UTF_8);
    h.getResponseHeaders().set("Content-Type","application/json");
    h.sendResponseHeaders(status,body.length);
    try(var out=h.getResponseBody()){out.write(body);}
  }
  static ChatRequest req(String text){
    return new ChatRequest("p",""+text,List.of(),ChatMode.AGENT,new ChatRequest.Settings("legacy-model"));
  }
  static void expireQuiet(OpenCodeExecutionService service,String localId) throws Exception {
    Field f=OpenCodeExecutionService.class.getDeclaredField("sessions");f.setAccessible(true);
    Object state=((Map<?,?>)f.get(service)).get(localId);
    Field quiet=state.getClass().getDeclaredField("lastActivityNanos");quiet.setAccessible(true);
    quiet.setLong(state,System.nanoTime()-TimeUnit.SECONDS.toNanos(70));
  }
  static String waitTerminal(OpenCodeExecutionService service,String id) throws InterruptedException {
    for(int n=0;n<12;n++){Thread.sleep(1200);
      String status=""+service.get(id).get("status");
      if(!"running".equals(status)) return status;
    }
    return "running";
  }
  public static void main(String[] args) throws Exception {
    Path work=Files.createTempDirectory("eliya98-contract-");
    System.setProperty("eliya.opencode.sessionStore",work.resolve("sessions").toString());
    System.setProperty("eliya.qa.workspace",work.toString());
    System.setProperty("eliya.opencode.stallSeconds","20");
    AtomicInteger next=new AtomicInteger(), submissions=new AtomicInteger();
    AtomicReference<String> scenario=new AtomicReference<>("no-files");
    AtomicBoolean busy=new AtomicBoolean(false);
    String auth="Basic "+Base64.getEncoder().encodeToString("opencode:mock-password-longer-than-16".getBytes(StandardCharsets.UTF_8));
    HttpServer server=HttpServer.create(new InetSocketAddress("127.0.0.1",0),0);
    server.createContext("/api/",h->{
      try{
        check(auth.equals(h.getRequestHeaders().getFirst("Authorization")),"auth failed");
        String path=h.getRequestURI().getPath();
        if(path.equals("/api/info")) reply(h,200,"{\"data\":{\"version\":\"2.2.2\"}}");
        else if(path.equals("/api/model/default")) reply(h,200,"{\"data\":{\"id\":\"configured\"}}");
        else if(path.equals("/api/session")) reply(h,200,"{\"data\":{\"id\":\"ses_"+next.incrementAndGet()+"\"}}");
        else if(path.endsWith("/prompt")) {submissions.incrementAndGet();
          String sid=path.split("/")[3];reply(h,200,"{\"data\":{\"id\":\"usr_"+sid+"\"}}");
        } else if(path.equals("/api/session/active"))
          reply(h,200,busy.get()?"{\"data\":{\"ses_3\":{\"status\":\"busy\"}}}":"{\"data\":{}}");
        else if(path.endsWith("/message")) {
          String sid=path.split("/")[3];
          if(scenario.get().equals("paginated-read")) {
            boolean page2=String.valueOf(h.getRequestURI().getRawQuery()).contains("cursor=page2");
            reply(h,200,page2
                ? "{\"data\":[{\"id\":\"usr_"+sid+"\",\"type\":\"user\",\"text\":\"Explain only\"}],\"cursor\":{\"next\":null}}"
                : "{\"data\":[{\"id\":\"assistant_"+sid+"\",\"type\":\"assistant\",\"content\":[{\"type\":\"text\",\"text\":\"Explanation complete\"}]}],\"cursor\":{\"next\":\"page2\"}}");
          } else {
          String assistant=scenario.get().equals("provider-error")
             ? "{\"id\":\"assistant_"+sid+"\",\"type\":\"assistant\",\"error\":{\"type\":\"ProviderError\",\"message\":\"Provider authentication rejected\"},\"content\":[]}"
             : "{\"id\":\"assistant_"+sid+"\",\"type\":\"assistant\",\"content\":[{\"type\":\"text\",\"text\":\"I planned it, but made no changes\"}]}";
          reply(h,200,"{\"data\":["+assistant+",{\"id\":\"usr_"+sid+"\",\"type\":\"user\",\"text\":\"task\"}]}");
          }
        } else if(path.endsWith("/diff")) reply(h,200,"{\"data\":[]}");
        else if(path.endsWith("/log")) reply(h,404,"{}");
        else if(path.endsWith("/interrupt")) reply(h,200,"{\"data\":{\"interrupted\":true}}");
        else reply(h,404,"{}");
      }catch(Throwable e){try{reply(h,500,"{}");}catch(Exception ignored){}}
    });
    ExecutorService pool=Executors.newCachedThreadPool(r->{Thread t=new Thread(r,"eliya98-mock");t.setDaemon(true);return t;});
    server.setExecutor(pool);server.start();
    OpenCodeExecutionService service=null;
    try {
      service=new OpenCodeExecutionService(new ObjectMapper(),new ProjectService(),"opencode", "http://127.0.0.1:"+server.getAddress().getPort(),"mock-password-longer-than-16","opencode",false);
      String noFiles=""+service.launch(req("Implement login service"),null).get("id");
      expireQuiet(service,noFiles);
      check("stalled".equals(waitTerminal(service,noFiles)),"Implementation without file changes was marked complete");
      check(!Boolean.TRUE.equals(service.engineInfo().get("autoEligible")),"Incomplete task must not enable Auto");
      check((""+service.get(noFiles).get("error")).contains("without any observed changed files"),"No-file failure not explained");
      System.out.println("PASS: assistant response but no modified files => incomplete, not success");

      scenario.set("provider-error");
      String error=""+service.launch(req("Explain existing code"),null).get("id");
      expireQuiet(service,error);
      check("failed".equals(waitTerminal(service,error)),"Provider message error did not fail the task");
      check((""+service.get(error).get("error")).contains("Provider authentication rejected"),"Provider error not displayed");
      System.out.println("PASS: provider error surfaced rather than reporting no observed tools");

      scenario.set("no-files");busy.set(true);
      String active=""+service.launch(req("Implement module B"),null).get("id");
      int accepted=submissions.get();
      try {service.message(active,req("Another task while the current one runs"));
        throw new AssertionError("Overlapping command accepted in same session");
      }catch(IllegalStateException expected){check(expected.getMessage().contains("active instruction"),"Missing concurrency explanation");}
      check(submissions.get()==accepted,"Overlapping command silently submitted remotely");
      String separate=""+service.launch(req("Implement independent module C"),null).get("id");
      check(!separate.equals(active) && submissions.get()==accepted+1,"Independent tab unable to run concurrently");
      System.out.println("PASS: same-session overlap rejected; separate OpenCode sessions run concurrently");
      service.cancel(active);service.cancel(separate);
      System.out.println("PASS: interruption endpoint responds for active sessions");
      scenario.set("paginated-read");busy.set(false);
      String paged=""+service.launch(req("Explain the architecture without changing files"),null).get("id");
      expireQuiet(service,paged);
      check("completed".equals(waitTerminal(service,paged)),"Completion failed to follow v2 cursor pagination");
      check((""+service.get(paged).get("answer")).contains("Explanation complete"),"Paged answer unavailable");
      check(!Boolean.TRUE.equals(service.engineInfo().get("autoEligible")),"Read-only reply with no tools must not prove coding engine for Auto");
      System.out.println("PASS: paginated OpenCode v2 history joins response to admitted user message");
    } finally { if(service!=null)service.shutdown();server.stop(0);pool.shutdownNow(); }
  }
}
