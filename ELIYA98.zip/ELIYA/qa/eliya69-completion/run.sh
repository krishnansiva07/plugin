#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../.."
D="$(mktemp -d)"; trap 'rm -rf "$D"' EXIT
javac --release 17 -d "$D" \
  src/main/java/com/llmart/llm/service/AgentArtifactVerificationPolicy.java \
  src/main/java/com/llmart/llm/service/AgentArtifactOutcomePolicy.java \
  qa/eliya69-completion/ArtifactOutcomeSmoke.java
java -cp "$D" ArtifactOutcomeSmoke
python3 - <<'PY'
from pathlib import Path
s=Path('src/main/java/com/llmart/llm/service/AgentService.java').read_text()
assert 'AgentArtifactOutcomePolicy.inspect(' in s
assert 'Named Markdown deliverables verified against the approved plan without a model retry' in s
assert 'Unverified outcome recorded without asking for routine guidance' in s
assert s.index('AgentArtifactOutcomePolicy.inspect(') < s.index('String diff = workspaces.workspaceDiff(ws, "");',s.index('AgentArtifactOutcomePolicy.inspect('))
print('PASS: runtime completion entry points')
PY
