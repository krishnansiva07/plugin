import com.llmart.llm.service.AgentArtifactOutcomePolicy;
import java.nio.file.*;

public class ArtifactOutcomeSmoke {
 static void check(boolean v, String detail) { if (!v) throw new AssertionError(detail); }
 static final String objective = "Create .opencode/.skills/one-class-one-responsibility.md and .opencode/.agents/code-reviewer.md, " +
         "make code reviewer refer to the skill; do not explore workspace";
 static final String plan = "Create .opencode/.skills/one-class-one-responsibility.md; " +
         "Create .opencode/.agents/code-reviewer.md; verify files and references";
 static final String changed = "A  .opencode/.skills/one-class-one-responsibility.md\n" +
         "A  .opencode/.agents/code-reviewer.md";
 static void put(Path root, String skill, String agent) throws Exception {
   var a=root.resolve(".opencode/.skills/one-class-one-responsibility.md");
   var b=root.resolve(".opencode/.agents/code-reviewer.md");
   Files.createDirectories(a.getParent()); Files.createDirectories(b.getParent());
   Files.writeString(a, skill); Files.writeString(b, agent);
 }
 public static void main(String[] args) throws Exception {
   Path p=Files.createTempDirectory("eliya69-proof");
   try {
     put(p, "# One class, one responsibility\nA class must focus on one single responsibility. Review methods and extract mixed concerns as necessary.",
        "# Code reviewer\nReview code changes and apply the one-class-one-responsibility skill to every changed class for safe refactoring.");
     var ok=AgentArtifactOutcomePolicy.inspect(p, changed, objective,plan,false,false);
     check(ok.satisfied(),"Expected success: "+ok);
     check(!AgentArtifactOutcomePolicy.inspect(p,changed,objective,plan,true,false).satisfied(),"Docs special validation protected");
     check(!AgentArtifactOutcomePolicy.inspect(p,changed,objective,plan,false,true).satisfied(),"Large task protected");
     check(!AgentArtifactOutcomePolicy.inspect(p,changed,objective+" and run the unit tests",plan,false,false).satisfied(),"Code test protected");
     check(!AgentArtifactOutcomePolicy.inspect(p,changed.replace("code-reviewer.md","missing.md"),objective,plan,false,false).satisfied(),"Missing target not accepted");
     check(!AgentArtifactOutcomePolicy.inspect(p,changed,objective,plan+"; add extra.md",false,false).satisfied(),"Additional approved plan file not accepted");
     check(!AgentArtifactOutcomePolicy.inspect(p,changed+"\nM  src/App.java",objective,plan,false,false).satisfied(),"Mixed code not accepted");
     check(!AgentArtifactOutcomePolicy.inspect(p,changed+"\nA  extra.md",objective,plan,false,false).satisfied(),"Unexpected Markdown change does not bypass review");
     check(!AgentArtifactOutcomePolicy.inspect(p,changed,objective,plan.replace(".opencode/.agents/code-reviewer.md", "elsewhere/code-reviewer.md"),false,false).satisfied(),"Plan path mismatch rejected");
     put(p, "# One class, one responsibility\nA class should focus on a single responsibility and make individual changes understandable.",
        "# Code reviewer\nReview the classes and provide refactoring suggestions; avoid rewriting code while doing analysis.");
     check(!AgentArtifactOutcomePolicy.inspect(p,changed,objective,plan,false,false).satisfied(),"Missing skill crossref not accepted");
     put(p, "# One class one responsibility\nThis skill guides single responsibility refactoring and separation of concerns for any class.",
        "# Code reviewer\nUse one-class-one-responsibility and review changes carefully for maintainable classes.");
     check(AgentArtifactOutcomePolicy.inspect(p,changed,objective,plan,false,false).satisfied(),"Restored skill reference accepted");
     put(p, "# TODO\nCreate the skill later; this document is only a placeholder for future implementation work.",
        "# Code reviewer\nUse one-class-one-responsibility to review code, design and tests in each changed class.");
     check(!AgentArtifactOutcomePolicy.inspect(p,changed,objective,plan,false,false).satisfied(),"Placeholder rejected");
     System.out.println("PASS: ELIYA69 named-artifact completion (12 cases)");
   } finally {
     try(var walk=Files.walk(p)){walk.sorted(java.util.Comparator.reverseOrder()).forEach(f->{try{Files.deleteIfExists(f);}catch(Exception ignored){}});}
   }
 }
}
