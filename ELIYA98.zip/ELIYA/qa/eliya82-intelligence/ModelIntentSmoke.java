package com.llmart.llm.service;
public class ModelIntentSmoke {
 private static void check(boolean value,String msg){ if(!value)throw new AssertionError(msg); }
 public static void main(String[] args) {
  var backend = new OpenAiCompatibleClient();
  var svc = new ModelIntentClassifier(backend);
  try {
   backend.reply="{\"intent\":\"execute\"}";
   check(svc.classify("key","http://localhost","model","Take care of the broken build", "", "analyse").engine().equals("agent"),"authorized action");
   check(svc.classify("key","http://localhost","model","Explain how to fix the build", "", "analyse").engine().equals("chat"),"read-only explanation");
   check(svc.classify("key","http://localhost","model","What does this do?", "", "analyse").engine().equals("chat"),"unapproved model action blocked");
   check(svc.classify("key","http://localhost","model","Yes", "Would you like to fix it or analyze it?", "analyse").engine().equals("chat"),"short consent does not execute");
   check(svc.classify("key","http://localhost","model","question", "", "execute").engine().equals("agent"),"explicit execute mode");
   check(ModelIntentClassifier.verifyModelDecision("disallowed", "Fix it").engine().equals("chat"),"model output invalid");
   backend.reply="{\"intent\":\"plan\"}";
   check(svc.classify("key","http://localhost","model","Get it done", "", "analyse").engine().equals("chat"),"model can recommend only read-only");
   System.out.println("PASS ELIYA82 model-backed ambiguity, safe fallback, explicit authorization");
  } finally {svc.close();}
 }
}
