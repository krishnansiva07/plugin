const assert=require('node:assert/strict');
const r=require('../../src/main/resources/static/unified-routing.js');
(async()=>{
 assert.equal(r.shouldModelAssist({text:'Please explain the architecture',selectedMode:'analyse'}),false);
 assert.equal(r.shouldModelAssist({text:'Please implement the fix',selectedMode:'analyse'}),false);
 assert.equal(r.shouldModelAssist({text:'Can you handle this broken workflow?',selectedMode:'analyse'}),true);
 assert.equal(await r.decideWithModel({text:'Can you handle this broken workflow?',selectedMode:'analyse'},async()=>({engine:'agent'})),'agent');
 assert.equal(await r.decideWithModel({text:'Can you handle this broken workflow?',selectedMode:'analyse'},async()=>{throw new Error('offline')}),'chat');
 assert.equal(await r.decideWithModel({text:'Can you check the workspace?',selectedMode:'analyse'},async()=>{throw new Error('should never call model')}),'chat');
 assert.equal(await r.decideWithModel({text:'Create the agent',selectedMode:'analyse'},async()=>{throw new Error('should never call model')}),'agent');
 console.log('PASS ELIYA82 model-assisted routing only for ambiguous main/Terminal decisions');
})().catch(e=>{console.error(e);process.exitCode=1});
