#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../.."
TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT
javac -encoding UTF-8 -d "$TMP/graph" src/main/java/com/llmart/llm/service/{WorkspaceCodeIntelligence,WorkspaceCallGraphService}.java qa/eliya82-intelligence/CallGraphSmoke.java
java -cp "$TMP/graph" com.llmart.llm.service.CallGraphSmoke
javac -encoding UTF-8 -d "$TMP/model" qa/eliya82-intelligence/stubs/org/springframework/stereotype/Service.java qa/eliya82-intelligence/stubs/jakarta/annotation/PreDestroy.java qa/eliya82-intelligence/stubs/com/llmart/llm/service/OpenAiCompatibleClient.java src/main/java/com/llmart/llm/service/ModelIntentClassifier.java qa/eliya82-intelligence/ModelIntentSmoke.java
java -cp "$TMP/model" com.llmart.llm.service.ModelIntentSmoke
node qa/eliya82-intelligence/routing.cjs
node --check src/main/resources/static/app.js
node --check src/main/resources/static/unified-routing.js
python3 qa/eliya82-intelligence/browser_intent.py
