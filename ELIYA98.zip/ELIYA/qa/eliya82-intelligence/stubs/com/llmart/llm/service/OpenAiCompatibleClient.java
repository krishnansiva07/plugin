package com.llmart.llm.service;
import java.util.*;
public class OpenAiCompatibleClient {
  public String reply = "{\"intent\":\"analyse\"}";
  public String complete(String key,String url,String model,int tokens,List<Map<String,Object>> messages) {return reply;}
}
