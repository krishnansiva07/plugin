package jakarta.annotation;
public @interface PreDestroy {}
