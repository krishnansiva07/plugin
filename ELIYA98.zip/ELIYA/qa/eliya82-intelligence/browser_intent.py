"""Chromium: ambiguous prompt reaches the optional model route; explicit commands don't."""
import asyncio,re
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parents[2]/'src/main/resources/static'
async def run():
 async with async_playwright() as pw:
  browser=await pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
  page=await browser.new_page(viewport={'width':1320,'height':850})
  html=re.sub(r'<script src="[^"]+"></script>','',(ROOT/'index.html').read_text())
  html=re.sub(r'<link rel="stylesheet"[^>]+>','',html)
  await page.set_content(html);await page.add_style_tag(content=(ROOT/'app.css').read_text())
  await page.evaluate('''() => {window.__requests=[]; window.fetch=async(url,opts={})=>{
    const path=String(url);
    if(path.includes('/api/chat/intent')) {window.__requests.push({type:'intent',body:JSON.parse(opts.body)});
      return new Response(JSON.stringify({engine:'agent',intent:'execute',modelUsed:true}),{headers:{'Content-Type':'application/json'}});}
    if(path.includes('/api/chat/stream')) {const body=JSON.parse(opts.body);
      window.__requests.push({type:'chat',body});return new Response('event: done\\ndata: '+JSON.stringify({role:'assistant',content:'Result delivered'})+'\\n\\n',
        {headers:{'Content-Type':'text/event-stream'}});}
    if(path.includes('/api/terminal/workspaces'))return new Response(JSON.stringify([{id:'w1',name:'Repo',localPath:'/tmp/eliya'}]),{headers:{'Content-Type':'application/json'}});
    if(path.includes('/api/terminal/sessions')&&opts.method==='POST') {window.__requests.push({type:'terminal',body:JSON.parse(opts.body)});
      return new Response(JSON.stringify({id:'t82',status:'running',projectId:'w1',queue:[]}),{headers:{'Content-Type':'application/json'}});}
    if(path.includes('/api/terminal/sessions')) return new Response(JSON.stringify([]),{headers:{'Content-Type':'application/json'}});
    return new Response(JSON.stringify([]),{headers:{'Content-Type':'application/json'}});
  };}''')
  for name in ['architecture-diagrams.js','markdown.js','prompt-catalog.js','unified-routing.js','conversation-intelligence.js','conversation-render-diff.js','app.js','confluence-composer.js']:
   await page.add_script_tag(content=(ROOT/name).read_text())
  await page.evaluate('''() => {state.config.apiKey='key';state.config.baseUrl='http://localhost';state.config.model='agent';
    state.config.chatModel='chat';state.conversationId='conv';state.project={id:'w1',name:'Repo',localWorkspace:true};state.messages=[];
    state.workflowMode='analyse';updateModeUi();}''')
  await page.locator('#messageInput').fill('Please take care of the broken build')
  await page.locator('#sendBtn').click()
  await page.wait_for_function('()=>!state.streaming && window.__requests.some(r=>r.type==="chat")',timeout=8000)
  first=await page.evaluate('window.__requests')
  assert len([x for x in first if x['type']=='intent'])==1,first
  assert [x for x in first if x['type']=='chat'][0]['body']['mode']=='agent',first
  await page.evaluate('''() => {state.workflowMode='analyse';state.mode='chat';updateModeUi()}''')
  await page.locator('#messageInput').fill('Explain the workspace architecture')
  await page.locator('#sendBtn').click()
  await page.wait_for_function('()=>!state.streaming && window.__requests.filter(r=>r.type==="chat").length===2',timeout=8000)
  second=await page.evaluate('window.__requests')
  assert len([x for x in second if x['type']=='intent'])==1,second
  assert [x for x in second if x['type']=='chat'][1]['body']['mode']=='chat',second
  assert await page.evaluate('typeof launchTerminalPrompt')=='function'
  assert await page.evaluate('terminalUi.workflowMode') in ('analyse','execute')
  assert await page.evaluate('window.EliyaUnifiedRouting.shouldModelAssist({text:"Please take care of the broken build",selectedMode:"analyse"})')
  assert await page.evaluate('document.documentElement.scrollWidth<=window.innerWidth+2')
  await browser.close()
 print('PASS ELIYA82 Chromium: model-assisted ambiguous action, fast deterministic Analyse, stable UI, Terminal shared router')
asyncio.run(run())
