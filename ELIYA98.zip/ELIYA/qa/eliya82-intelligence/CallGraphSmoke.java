package com.llmart.llm.service;
import java.util.*;
public class CallGraphSmoke {
  private static WorkspaceCallGraphService.Source source(String path, String text) {
    return new WorkspaceCallGraphService.Source(path,text,WorkspaceCodeIntelligence.analyse(path,text));
  }
  private static void check(boolean ok, String label) { if(!ok)throw new AssertionError(label); }
  public static void main(String[] args) {
    var targets = List.of(
      source("src/main/java/demo/Payment.java", "package demo; public class Payment { public int pay(){return 1;} }"),
      source("src/main/java/demo/Caller.java", "package demo; import demo.Payment; public class Caller { public int run(){ Payment p = new Payment(); return p.pay(); } }"),
      source("ui/pay.ts", "export function pay() { return 1; }"),
      source("ui/order.ts", "import {pay} from './pay'; export function order() { return pay(); }"),
      source("lib/worker.py", "def work():\n  return 3\n"),
      source("lib/controller.py", "from lib.worker import work\nwork()\n"),
      source("org/project/service/worker.go", "package service\nfunc Work() {}\n"),
      source("org/project/client/main.go", "package client\nimport \"org/project/service\"\nfunc Run() {}\n"),
      source("app/Invoice.cs", "class Invoice { }"),
      source("app/Flow.cs", "class Flow { void run() { var i = new Invoice(); } }"));
    var graph = WorkspaceCallGraphService.build(targets);
    check(graph.edges().stream().anyMatch(e -> e.from().endsWith("Caller.java") && e.to().endsWith("Payment.java") && e.kind().equals("call") && e.callee().equals("pay")), "Java invocation link");
    check(graph.edges().stream().anyMatch(e -> e.from().equals("ui/order.ts") && e.to().equals("ui/pay.ts") && e.kind().equals("import")), "TS module dependency");
    check(graph.edges().stream().anyMatch(e -> e.from().equals("lib/controller.py") && e.to().equals("lib/worker.py") && e.kind().equals("import")), "Python module dependency");
    check(graph.edges().stream().anyMatch(e -> e.from().equals("org/project/client/main.go") && e.to().equals("org/project/service/worker.go") && e.kind().equals("import")), "Go local package import");
    check(graph.edges().stream().anyMatch(e -> e.from().equals("lib/controller.py") && e.to().equals("lib/worker.py") && e.kind().equals("call") && e.callee().equals("work")), "Python imported direct call");
    check(graph.edges().stream().anyMatch(e -> e.from().equals("ui/order.ts") && e.to().equals("ui/pay.ts") && e.kind().equals("call") && e.callee().equals("pay")), "TS imported direct call");
    check(graph.edges().stream().anyMatch(e -> e.from().equals("app/Flow.cs") && e.to().equals("app/Invoice.cs") && e.kind().equals("construct")), "C# constructor dependency");
    check(graph.edges().stream().allMatch(e -> e.fromLine()>0 && e.toLine()>0), "Source location on each edge");
    var ambiguous = WorkspaceCallGraphService.build(List.of(source("x/Two.java", "class Two { void f(){} }"),
       source("y/Two.java", "class Two { void f(){} }"), source("z/Run.java","class Run { void f(){ new Two(); } }")));
    check(ambiguous.edges().stream().noneMatch(e -> e.kind().equals("construct")), "Do not invent ambiguous type targets");
    System.out.println("PASS ELIYA82 static Java/TS/Python/Go/C# relationships, ambiguity, line evidence");
  }
}
