package com.llmart.llm.service;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Comparator;

public class WorkspaceBoundarySmoke {
    private static void check(boolean value, String message) { if (!value) throw new AssertionError(message); }
    private static void rejects(Path root, String reason) {
        try { WorkspaceRootGuard.requireNarrow(root); } catch (IllegalArgumentException expected) { return; }
        throw new AssertionError(reason);
    }
    public static void main(String[] args) throws Exception {
        Path temporary = Files.createTempDirectory("eliya-project-boundary-");
        Path selected = Files.createDirectories(temporary.resolve("selected-project"));
        Path other = Files.createDirectories(temporary.resolve("unrelated-project"));
        Path child = Files.createDirectories(selected.resolve("src"));
        Files.writeString(selected.resolve("pom.xml"), "<project/>");
        Files.writeString(other.resolve("pom.xml"), "<project/>");
        try {
            PromptResourceResolver resolver = new PromptResourceResolver();
            check(WorkspaceRootGuard.requireNarrow(selected).equals(selected), "legitimate project rejected");
            rejects(selected.getRoot(), "filesystem root accepted");
            Path home = Path.of(System.getProperty("user.home")).toAbsolutePath().normalize();
            rejects(home, "home root accepted");
            check(resolver.primaryProjectPath("Compare with " + other + " and implement tests").isEmpty(),
                    "incidentally mentioned path became auto-selected workspace");
            check(resolver.primaryProjectPath("Project path: " + other).orElseThrow().equals(other),
                    "explicit project path should still map when no UI workspace is selected");
            check(resolver.primaryProjectPath("Project path: " + selected.getRoot()).isEmpty(),
                    "root drive was inferred as project workspace");
            // The current project is preserved; a prompt's stray absolute paths are NOT indexed as resources.
            var foreign = resolver.resolve("Change files in " + other + " and " + selected + "", selected);
            check(foreign.resources().size() == 1, "stray prompt path registered outside workspace");
            check(foreign.resources().get(0).root().equals(selected), "selected project root replaced");
            // A nonexistent child must never cause the fallback parser to mount its existing ancestor.
            var nonexistent = resolver.resolve("Input: " + other + "/nonexistent/src/Bad.java", selected);
            check(nonexistent.resources().size() == 1, "nonexistent path widened to ancestor folder");
            var drive = resolver.resolve("Reference: " + selected.getRoot(), selected);
            check(drive.resources().size() == 1, "drive root registered as reference");
            var homeReference = resolver.resolve("Reference: " + home, selected);
            check(homeReference.resources().size() == 1, "user home registered as reference");
            // Explicit selected reference stays read-only, and must never join the Agent baseline hashes.
            var reference = resolver.resolve("Reference [legacy] (read-only): " + other, selected);
            check(reference.resources().size() == 2, "explicit named reference not resolved");
            check(reference.resources().get(1).role() == PromptResourceResolver.ResourceRole.REFERENCE,
                    "named reference was promoted to writable");
            check(!reference.resources().get(1).writable(), "reference path became writable");
            // Existing opt-in secondary workspace continues to work, but never from stray prose.
            var secondary = resolver.resolve("Secondary workspace: " + other, selected);
            check(secondary.resources().size() == 2 && secondary.resources().get(1).writable(),
                    "explicit secondary workspace opt-in broken");
            // Legitimate selected in-root file references need no second alias.
            check(resolver.resolve("Input: " + selected.resolve("pom.xml"), selected).resources().size() == 1,
                    "same-workspace file duplicated");
            System.out.println("PASS: selected root only; incidental parent/root paths rejected; explicit read-only refs and secondary opt-in preserved");
        } finally {
            try (var walk = Files.walk(temporary)) {
                for (Path path : walk.sorted(Comparator.reverseOrder()).toList()) Files.deleteIfExists(path);
            }
        }
    }
}
