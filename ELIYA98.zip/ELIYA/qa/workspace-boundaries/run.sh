#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../.."
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
mkdir -p "$TMP/org/springframework/stereotype"
printf 'package org.springframework.stereotype; public @interface Service {}\n' > "$TMP/org/springframework/stereotype/Service.java"
javac -d "$TMP/classes" "$TMP/org/springframework/stereotype/Service.java" \
  src/main/java/com/llmart/llm/service/WorkspaceRootGuard.java \
  src/main/java/com/llmart/llm/service/PromptResourceResolver.java \
  qa/workspace-boundaries/WorkspaceBoundarySmoke.java
java -cp "$TMP/classes" com.llmart.llm.service.WorkspaceBoundarySmoke
python3 - <<'PY'
from pathlib import Path
app = Path('src/main/resources/static/app.js').read_text()
chat = Path('src/main/java/com/llmart/llm/service/ChatService.java').read_text()
agent = Path('src/main/java/com/llmart/llm/service/AgentService.java').read_text()
project = Path('src/main/java/com/llmart/llm/service/ProjectService.java').read_text()
workspace = Path('src/main/java/com/llmart/llm/service/AgentWorkspaceService.java').read_text()
assert "if (rememberedPath && !state.project?.localWorkspace)" in app
assert "projectId: state.project?.id || null" in app
assert "AgentWorkspaceSelection.canInferFromPrompt(effectiveProjectId)" in chat
assert "WorkspaceRootGuard.requireNarrow(root.toRealPath())" in project
assert "WorkspaceRootGuard.requireNarrow(Path.of(project.getLocalPath())" in workspace
assert '"workspace_root", "Selected project only: " + ws.root()' in agent
print('PASS: UI restoration fail-closed, project-id handoff and backend indexing/root guards')
PY
