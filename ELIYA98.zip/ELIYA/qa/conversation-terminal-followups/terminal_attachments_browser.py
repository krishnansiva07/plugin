"""Mocked Chromium smoke of Terminal paste/browse and selected attachment ownership."""
import asyncio,re
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parents[2]/'src/main/resources/static'
async def main():
 async with async_playwright() as pw:
  browser=await pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
  page=await browser.new_page(viewport={'width':1240,'height':900})
  errors=[]
  page.on('pageerror',lambda e:errors.append(str(e)))
  page.set_default_timeout(9000)
  html=re.sub(r'<script src="[^"]+"></script>','',(ROOT/'index.html').read_text())
  html=re.sub(r'<link rel="stylesheet"[^>]+>','',html)
  await page.set_content(html)
  await page.add_style_tag(content=(ROOT/'app.css').read_text())
  await page.evaluate('''() => {
    window.__testPosts=[];window.__uploads=[];
    window.fetch=async(url,options={})=>{
      const path=String(url).split('?')[0];const method=options.method||'GET';
      if(path==='/api/conversations'&&method==='POST')return new Response(JSON.stringify({id:'terminal-staging-conversation'}),{status:200,headers:{'Content-Type':'application/json'}});
      if(path==='/api/files'&&method==='POST'){
        const file=options.body.get('file');
        window.__uploads.push({name:file.name,conversationId:options.body.get('conversationId')});
        return new Response(JSON.stringify({id:'doc-'+window.__uploads.length,name:file.name,mimeType:file.type,size:file.size,extractionStatus:'ready',extractedCharacters:128,extractionMessage:'ready'}),{status:200,headers:{'Content-Type':'application/json'}});
      }
      if(path==='/api/terminal/workspaces')return new Response(JSON.stringify([{id:'w1',name:'Automation',localPath:'/tmp/automation'}]),{status:200,headers:{'Content-Type':'application/json'}});
      if(path==='/api/terminal/sessions'&&method==='POST'){
        const req=JSON.parse(options.body);window.__testPosts.push(req);
        return new Response(JSON.stringify({id:'t1',status:'running',projectId:req.projectId,queueCount:0}),{status:200,headers:{'Content-Type':'application/json'}});
      }
      if(path==='/api/terminal/sessions'&&method==='GET')return new Response(JSON.stringify([]),{status:200,headers:{'Content-Type':'application/json'}});
      if(path==='/api/terminal/sessions/t1')return new Response(JSON.stringify({id:'t1',status:'running',projectId:'w1',answer:'',queue:[],turns:[],events:[],question:{}}),{status:200,headers:{'Content-Type':'application/json'}});
      if(path==='/api/conversations')return new Response(JSON.stringify([]),{status:200,headers:{'Content-Type':'application/json'}});
      return new Response(JSON.stringify([]),{status:200,headers:{'Content-Type':'application/json'}});
    };
  }''')
  for name in ['markdown.js','prompt-catalog.js','app.js','confluence-composer.js']:
   await page.add_script_tag(content=(ROOT/name).read_text())
  await page.evaluate('''() => {
    state.config.apiKey='key';state.config.baseUrl='http://localhost';state.config.model='agent-x';state.config.chatModel='chat';
    state.project={id:'w1',name:'Automation',localPath:'/tmp/automation'};
  }''')
  await page.click('#launchTerminalBtn')
  await page.locator('#terminalFileInput').set_input_files({'name':'requirements.docx','mimeType':'application/vnd.openxmlformats-officedocument.wordprocessingml.document','buffer':b'fake-docx-for-transport-test'})
  await page.wait_for_function('() => window.__uploads.length === 1 && terminalUi.attachments.length===1')
  assert 'requirements.docx' in await page.locator('#terminalAttachmentTray').inner_text()
  assert await page.evaluate('window.__uploads[0].conversationId')=='terminal-staging-conversation'
  await page.fill('#terminalTask','Generate test cases from attached document')
  await page.press('#terminalTask','Enter')
  await page.wait_for_function('() => window.__testPosts.length === 1')
  req=await page.evaluate('window.__testPosts[0]')
  assert req['attachmentIds']==['doc-1'],req
  assert req['conversationId']=='terminal-staging-conversation',req
  assert req['message']=='Generate test cases from attached document',req
  await page.wait_for_function('() => terminalUi.attachments.length === 0')
  await page.evaluate('''() => {
    const file=new File(['requirement content'],'pasted.txt',{type:'text/plain'});
    const data=new DataTransfer();data.items.add(file);
    document.getElementById('terminalTask').dispatchEvent(new ClipboardEvent('paste',{bubbles:true,cancelable:true,clipboardData:data}));
  }''')
  await page.wait_for_function('() => window.__uploads.length===2 && terminalUi.attachments.length===1')
  assert 'pasted.txt' in await page.locator('#terminalAttachmentTray').inner_text()
  assert not errors, errors
  await browser.close()
  print('PASS: Terminal Word browse + pasted file, isolated staging, selected attachment IDs in agent request, clean composer; no page errors')
asyncio.run(main())
