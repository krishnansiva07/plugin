#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT
SRC="$ROOT/src/main/java/com/llmart/llm/service/ChatAnswerContinuation.java"
mkdir -p "$TMP/com/llmart/llm/service" "$TMP/classes"
cat > "$TMP/com/llmart/llm/service/Smoke.java" <<'JAVA'
package com.llmart.llm.service;
import java.util.*;
public final class Smoke {
 static void check(boolean value, String msg) {if (!value) throw new AssertionError(msg);}
 public static void main(String[] args) {
  var original = List.<Map<String,Object>>of(Map.of("role","system","content","No modifications"),Map.of("role","user","content","Full analysis please"));
  var next=ChatAnswerContinuation.nextContext(original,"A".repeat(12000));
  check(original.size()==2 && next.size()==4,"must not mutate original context");
  check(((String)next.get(2).get("content")).length()==8000,"bounded resume tail");
  check("assistant".equals(next.get(2).get("role")),"assistant continuation history");
  String old="Detailed sections already written. The final finding is: accurate retrieval";
  String incoming="The final finding is: accurate retrieval with source evidence and unverified conditions.";
  var combined=new StringBuilder(old);
  StringBuilder tokens=new StringBuilder();
  var merge=new ChatAnswerContinuation.TokenMerger(combined,tokens::append,true);
  for(int i=0;i<incoming.length();i+=7) merge.accept(incoming.substring(i,Math.min(incoming.length(),i+7)));
  merge.finish();
  check(combined.toString().equals(old+" with source evidence and unverified conditions."),"overlap removed once");
  check(tokens.toString().equals(" with source evidence and unverified conditions."),"stream matches persisted text");
  var noOverlap=new StringBuilder("one ending");
  var merger=new ChatAnswerContinuation.TokenMerger(noOverlap,x->{},true);
  merger.accept("different beginning");merger.finish();
  check(noOverlap.toString().endsWith("different beginning"),"no accidental overlap deletion");
  ChatAnswerContinuation.reportIncomplete(noOverlap,null,"max parts");
  check(noOverlap.toString().contains("incomplete"),"incomplete disclosure");
  System.out.println("PASS: bounded continuation context, no mutation, overlap removal, streamed text, incomplete disclosure");
 }
}
JAVA
javac --release 17 -d "$TMP/classes" "$SRC" "$TMP/com/llmart/llm/service/Smoke.java"
java -cp "$TMP/classes" com.llmart.llm.service.Smoke
