package com.llmart.llm.service;

import java.nio.file.*;
import java.util.*;

/** ELIYA38: 3k-file, false-link, snapshot-invalidation and zero-provider flow smoke. */
public final class FlowIntelligenceSmoke {
    private static void check(boolean condition, String description) {
        if (!condition) throw new AssertionError(description);
    }
    public static void main(String[] args) throws Exception {
        Path work = Files.createTempDirectory("eliya-flow-3k-");
        Path data = Files.createTempDirectory("eliya-flow-index-");
        try {
            System.setProperty("app.data-dir", data.toString());
            Files.createDirectories(work.resolve("ui"));
            Files.createDirectories(work.resolve("backend"));
            Files.createDirectories(work.resolve("fixtures"));
            Files.writeString(work.resolve("ui/alert-kpi.ts"), """
                    import axios from 'axios';
                    export const getAlertKpi = () => axios.get('/api/alerts/kpi');
                    export const saveAlertKpi = () => axios.post('/api/alerts/kpi');
                    // Unsupported: dynamic construction
                    export const dynamicAlert = (id) => fetch(`/api/alerts/${id}`);
                    """);
            Files.writeString(work.resolve("backend/AlertController.java"), """
                    package backend;
                    @RequestMapping("/api/alerts")
                    public class AlertController {
                        @GetMapping("/kpi") public int findAlertKpi() { return 42; }
                        @PostMapping("/kpi") public void saveAlertKpi() { }
                    }
                    """);
            Files.writeString(work.resolve("ui/angular.ts"), """
                    export class AlertView { load() { return this.http.get<number>('/api/alerts/kpi'); } }
                    """);
            Files.writeString(work.resolve("backend/Commented.java"), """
                    package backend;
                    public class Commented {
                      // @GetMapping("/api/alerts/kpi") should never create a second handler
                      /* @GetMapping("/api/alerts/kpi") should also be ignored */
                    }
                    """);
            Files.writeString(work.resolve("backend/KpiService.java"), """
                    package backend; public class KpiService { public int calculateAlertKpi(){return 42;} }
                    """);
            Files.writeString(work.resolve("ui/bad-urls.ts"), """
                    export const irrelevant = () => fetch('/api/alerts/dynamic');
                    export const external = () => fetch('https://example.org/api/alerts/kpi');
                    """);
            Files.writeString(work.resolve("backend/DuplicateController.java"), """
                    package backend; public class DuplicateController { @GetMapping("/api/duplicates") public int f(){return 1;} }
                    """);
            for (int i = 0; i < 2_993; i++)
                Files.writeString(work.resolve("fixtures/fixture" + i + ".txt"), "Data seed " + i);
            WorkspaceRetrievalIndexService retrieval = new WorkspaceRetrievalIndexService(new OpenAiCompatibleClient());
            var ws = AgentWorkspaceService.Workspace.forIndex("flow", work);
            long indexStarted = System.nanoTime();
            check(retrieval.refresh(ws).indexedFiles() == 3_000, "index all 3,000 files");
            long indexMillis = (System.nanoTime() - indexStarted) / 1_000_000L;
            String q = "Explain alert KPI calculation flow from UI to API and backend";
            long searchStarted = System.nanoTime();
            String result = retrieval.retrieveCachedRoot("flow", work, q, 12, 15_000);
            long searchMillis = (System.nanoTime() - searchStarted) / 1_000_000L;
            check(result.contains("MATCHED HTTP FLOW EDGES"), "flow matches loaded from prewarmed index");
            check(result.contains("GET /api/alerts/kpi: ui/alert-kpi.ts:L2 -> backend/AlertController.java:L4"),
                    "GET route and literal source lines grounded");
            check(result.contains("POST /api/alerts/kpi"), "POST route inferred separately from GET");
            check(result.contains("GET /api/alerts/kpi: ui/angular.ts:L1"),
                    "Angular generic http client call matched; comment examples excluded");
            check(!result.contains("GET /api/alerts/dynamic:"), "dynamic URLs don't generate fabricated links");
            check(retrieval.flowPlanHints(ws, q, 2000).contains("GET /api/alerts/kpi"),
                    "Agent planning sees reusable index evidence");
            check(retrieval.flowPlanHints(ws, "Hello!", 2000).isEmpty(), "non-code conversation never needs flow");
            // A duplicate route must make the match ambiguous and therefore unverified.
            Files.writeString(work.resolve("backend/DuplicateController.java"), """
                    package backend; public class DuplicateController {
                      @GetMapping("/api/alerts/kpi") public int duplicate(){return 17;}
                    }
                    """);
            retrieval.refreshPaths(ws, List.of("backend/DuplicateController.java"));
            check(!retrieval.retrieveCachedRoot("flow", work, q, 12, 15_000)
                    .contains("GET /api/alerts/kpi: "), "ambiguous route must not create misleading edge");
            check(retrieval.retrieveCachedRoot("flow", work, q, 12, 15_000).contains("POST /api/alerts/kpi"),
                    "independent known route retained");
            Files.delete(work.resolve("backend/DuplicateController.java"));
            retrieval.refreshPaths(ws, List.of("backend/DuplicateController.java"));
            check(retrieval.retrieveCachedRoot("flow", work, q, 12, 15_000)
                    .contains("GET /api/alerts/kpi"), "edges rebuilt when duplicate removed");
            var reloaded = new WorkspaceRetrievalIndexService(new OpenAiCompatibleClient());
            check(reloaded.refresh(ws).indexedFiles() == 2_999, "restart checkpoint stays consistent");
            check(reloaded.retrieveCachedRoot("flow", work, q, 12, 15_000).contains("GET /api/alerts/kpi"),
                    "restarted graph rebuilds without provider calls");
            System.out.println("PASS: 3,000-file indexed flow; two HTTP verbs; unambiguous route matching; dynamic URL rejection; " +
                    "incremental invalidation; cached Chat and Agent planning; no provider required");
            System.out.println("MEASURED SYNTHETIC INDEX=" + indexMillis + "ms, FIRST CACHED FLOW QUERY=" +
                    searchMillis + "ms (not end-to-end Agent timing)");
        } finally {
            try (var all = Files.walk(work)) {
                for (Path item : all.sorted(Comparator.reverseOrder()).toList()) Files.deleteIfExists(item);
            }
            try (var all = Files.walk(data)) {
                for (Path item : all.sorted(Comparator.reverseOrder()).toList()) Files.deleteIfExists(item);
            }
        }
    }
}
