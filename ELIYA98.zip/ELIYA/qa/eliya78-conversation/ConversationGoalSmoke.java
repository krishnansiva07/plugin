package com.llmart.llm.service;

public class ConversationGoalSmoke {
  private static void check(String prompt, boolean wanted) {
    boolean actual = AgentConversationIntent.isFastReadOnly(prompt);
    if (actual != wanted) throw new AssertionError(prompt + " read-only=" + actual + " expected " + wanted);
  }
  public static void main(String[] args) {
    check("Can you check what is there in the workspace?",true);
    check("Can you read ARCHITECTURE.md file and display here?",true);
    check("I need architecture of the workspace",true);
    check("I need complete E2E flow of our framework",true);
    check("Can you explain the entire E2E architecture of this codebase?",true);
    check("Tell me how to create agents and skills",true);
    check("Can you explain how to implement this plan?",true);
    check("What is there in this repository?",true);
    check("Can you inspect our codebase and identify gaps?",true);
    check("Please check the workspace and fix the test failures",false);
    check("Create the .opencode agents and skills files",false);
    check("Generate test cases from this attached Word document",false);
    check("Implement the phases and verify files",false);
    check("Analyze the report then fix the issues",false);
    if(!AgentResultPresentation.needsInvestigationAnswer("Can you check the workspace", "Task completed successfully.", true))
      throw new AssertionError("Generic success is not an answer");
    if(AgentResultPresentation.needsInvestigationAnswer("Can you check agents", "No AGENTS.md was found under the inspected workspace root. The workspace was not modified.", true))
      throw new AssertionError("Grounded zero matches are valid answers");
    if(!AgentResultPresentation.needsInvestigationAnswer("Explain E2E architecture", "done", true))
      throw new AssertionError("Deep architecture needs a substantive response");
    System.out.println("PASS ELIYA78: 17 conversational intent and answer-quality scenarios");
  }
}
