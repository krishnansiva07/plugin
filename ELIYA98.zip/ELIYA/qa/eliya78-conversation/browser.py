"""Acceptance: final Agent answer first, technical report secondary, final saved answer takes precedence."""
import asyncio, re
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parents[2]/'src/main/resources/static'
OUT=Path('/mnt/data/eliya78_preview');OUT.mkdir(exist_ok=True)
async def main():
 async with async_playwright() as pw:
  browser=await pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
  for width in (1440,390):
   page=await browser.new_page(viewport={'width':width,'height':900},device_scale_factor=1)
   errors=[];page.on('pageerror',lambda err:errors.append(str(err)))
   html=re.sub(r'<script src="[^"]+"></script>','',(ROOT/'index.html').read_text())
   html=re.sub(r'<link rel="stylesheet"[^>]+>','',html)
   await page.set_content(html)
   await page.add_style_tag(content=(ROOT/'app.css').read_text())
   await page.evaluate('''() => {window.fetch=async()=>new Response('[]',{status:200,headers:{'Content-Type':'application/json'}})}''')
   for name in ['markdown.js','prompt-catalog.js','unified-routing.js','app.js','confluence-composer.js']:
    await page.add_script_tag(content=(ROOT/name).read_text())
   await page.evaluate('''() => {
     state.messages=[
      {role:'user',content:'Can you check what is there in the workspace?'},
      {role:'assistant',mode:'agent',content:'All approved plan steps completed successfully.',streaming:true,
        agentSteps:[{step:1,tool:'list',status:'success',detail:'Listed repository root',output:'pom.xml src README.md'},
          {step:2,tool:'read',status:'success',detail:'Read pom.xml',output:'Spring Boot Java 17'}],
        agentProgress:{percent:94,phase:'execute',status:'running',plan:[{index:1,text:'Investigate evidence',status:'in_progress'}]}}
     ];
     const result='## Workspace overview\\n\\nThe selected repository contains `pom.xml`, `README.md`, and a `src/` tree.\\n\\n### Verified structure\\n\\n- `src/main/java`: Java services\\n- `src/main/resources`: application resources\\n- `pom.xml`: Maven project configuration\\n\\n### Suggested next step\\n\\nWould you like me to explain the full architecture?';
     applyCompletedChatMessage(state.messages[1],{content:result});
     state.messages[1].agentProgress={percent:100,phase:'completed',status:'completed',plan:[{index:1,text:'Investigate evidence',status:'completed'}]};
     renderMessages();
    }''')
   body=page.locator('.message.assistant .message-body')
   answer=body.locator('.message-content')
   report=body.locator('.agent-run-card')
   assert await answer.count()==1 and await report.count()==1
   assert await answer.evaluate('(el)=>el.compareDocumentPosition(el.parentElement.querySelector(".agent-run-card")) & Node.DOCUMENT_POSITION_FOLLOWING')
   assert 'Workspace overview' in await answer.inner_text()
   assert 'saved response did not match' not in (await body.inner_text()).lower()
   assert await report.locator('.agent-run-disclosure').evaluate('(e)=>!e.open')
   assert await page.evaluate('document.documentElement.scrollWidth <= window.innerWidth + 2')
   await page.screenshot(path=str(OUT/f'unified_answer_{width}.png'))
   assert not errors, errors
   await page.close()
  await browser.close()
 print('PASS ELIYA78: persisted answers above execution records, no false mismatch, responsive 1440/390, no JS errors')
asyncio.run(main())
