#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../.."
T=$(mktemp -d); trap 'rm -rf "$T"' EXIT
javac --release 17 -d "$T" src/main/java/com/llmart/llm/service/{AgentPlanRelevance,AgentConversationIntent,AgentResultPresentation}.java qa/eliya78-conversation/ConversationGoalSmoke.java
java -cp "$T" com.llmart.llm.service.ConversationGoalSmoke
node qa/eliya78-conversation/answer-integrity.cjs
python3 - <<'PY'
from pathlib import Path
s=Path('src/main/java/com/llmart/llm/service/AgentService.java').read_text()
assert 'final boolean investigationOnly' in s
assert 'if (investigationOnly) {' in s
assert 'Read-only investigation evidence reviewed' in s
assert 'investigationOnly ?' in s
assert 'No file writes' in s
assert 'AgentResultPresentation.needsInvestigationAnswer(' in s
assert s.index('if (investigationOnly) {\n                        completionStatus = looksLikeBlockedFinal(raw)') < s.index('StepCompletionDecision readOnlyDecision = activeReadOnlyStepCompletionGate')
assert 'The Agent could not independently verify' in s # still for WRITE tasks
ui=Path('src/main/resources/static/app.js').read_text()
assert ui.index('<div class="${contentClass}">') < ui.index('${assistant ? agentStepsHtml(message) : \'\'}')
assert 'Task stopped.</strong> Explain what you want' not in ui
print('PASS ELIYA78: evidence-first read-only completion; answer-first UI; write verification retained')
PY
