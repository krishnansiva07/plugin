import com.llmart.llm.service.OpenCodeExecutionService;
import com.llmart.llm.service.OpenCodeLocalRuntime;
import com.llmart.llm.service.ProjectService;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.file.*;
import java.util.Map;

public class ZeroConfigSmoke {
    private static void check(boolean yes, String message) { if (!yes) throw new AssertionError(message); }
    public static void main(String[] args) throws Exception {
        Path work = Files.createTempDirectory("eliya90-zero-config-");
        System.setProperty("eliya.opencode.sessionStore", work.resolve("session-store").toString());
        Path missing = work.resolve("missing");
        try {
            new OpenCodeLocalRuntime().findV2(missing.toString());
            throw new AssertionError("Missing executable was accepted");
        } catch (java.io.IOException expected) { check(expected.getMessage().contains("OpenCode 2"), "missing executable must be explained"); }
        String script = "#!/bin/sh\nif [ \"$1\" = \"--version\" ]; then echo \"opencode v2.2.2\"; exit 0; fi\nexec python3 \""+
            Path.of("qa/eliya90-zero-config/mock_server.py").toAbsolutePath() + "\" \"$5\"\n";
        Path mock = work.resolve("opencode");
        Files.writeString(mock, script); mock.toFile().setExecutable(true);
        var runtime = new OpenCodeLocalRuntime();
        check(runtime.findV2(mock.toString()).location().equals(mock.toString()), "OpenCode 2 discovered");
        check(runtime.randomPassword().length() >= 32, "random secret too short");
        check(runtime.availableLoopbackPort() > 0, "no ephemeral loopback port");
        var service = new OpenCodeExecutionService(new ObjectMapper(), new ProjectService(),
                "opencode", "http://127.0.0.1:4096", "", mock.toString(), true);
        String endpoint = "";
        try {
            Map<String,Object> result = service.engineInfo();
            check(Boolean.TRUE.equals(result.get("connected")), "ELIYA did not auto-start the managed server: " + result);
            check("automatic-local".equals(result.get("startupMode")), "must be zero config mode");
            endpoint = String.valueOf(result.get("endpoint"));
            check(endpoint.startsWith("http://127.0.0.1:") && !endpoint.endsWith(":4096"), "needs private dynamic loopback port");
            var wrongAuth = HttpClient.newHttpClient().send(HttpRequest.newBuilder(URI.create(endpoint + "/api/info")).GET().build(), HttpResponse.BodyHandlers.discarding());
            check(wrongAuth.statusCode() == 401, "missing credentials should be rejected by server");
            check(Boolean.TRUE.equals(service.engineInfo().get("connected")), "recheck must reuse the process");
        } finally { service.shutdown(); }
        System.out.println("PASS: OpenCode2 discovery, no-password managed start, loopback-only dynamic port, protected API, recheck and shutdown");
    }
}
