import base64
import http.server
import json
import os
import sys

port = int(sys.argv[1])
secret = os.environ['OPENCODE_PASSWORD']
class Handler(http.server.BaseHTTPRequestHandler):
    def do_GET(self):
        header = self.headers.get('Authorization', '')
        expected = 'Basic ' + base64.b64encode(('opencode:' + secret).encode()).decode()
        if header != expected:
            self.send_response(401)
            self.end_headers()
            return
        if self.path not in ('/api/info', '/api/model/default'):
            self.send_response(404)
            self.end_headers()
            return
        reply = json.dumps({'data': {'version': '2.2.2'} if self.path == '/api/info'
                else {'id': 'model_ready'}}).encode()
        self.send_response(200)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Content-Length', str(len(reply)))
        self.end_headers()
        self.wfile.write(reply)
    def log_message(self, *args):
        pass
http.server.ThreadingHTTPServer(('127.0.0.1', port), Handler).serve_forever()
