#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
TMP=$(mktemp -d)
trap 'rm -rf "$TMP"' EXIT
mkdir -p "$TMP/classes" "$TMP/work/.opencode/.skills/one-class-one-responsibility" "$TMP/work/.opencode/.agents"
cat > "$TMP/work/.opencode/.skills/one-class-one-responsibility/SKILL.md" <<'MD'
---
name: one-class-one-responsibility
description: Focus each class on a single responsibility.
---
Use this skill to identify classes mixing unrelated concerns. Give an actionable improvement and keep changes focused.
MD
cat > "$TMP/work/.opencode/.agents/code-reviewer.md" <<'MD'
---
description: Review code for responsibility boundaries and maintainability.
---
Apply the one-class-one-responsibility skill; check each changed class for mixed concerns and suggest specific refactoring.
MD
cat > "$TMP/Test.java" <<'JAVA'
import com.llmart.llm.service.AgentArtifactVerificationPolicy;
import java.nio.file.*;
import java.nio.charset.StandardCharsets;
public class Test {
 static void check(boolean val,String why){if(!val)throw new AssertionError(why);}
 public static void main(String[] args) throws Exception {
  Path root=Path.of(args[0]);
  String files="A  .opencode/.agents/code-reviewer.md\nA  .opencode/.skills/one-class-one-responsibility/SKILL.md";
  String task="Create .opencode agents and skills, add code-reviewer.md and one-class-one-responsibility.md";
  var ok=AgentArtifactVerificationPolicy.inspect(root,files,task,false,false);
  check(ok.passed(),"Markdown artifacts should verify: "+ok.detail());
  check(ok.detail().contains("Semantic content"),"Must not pretend semantic verification happened");
  check(!AgentArtifactVerificationPolicy.inspect(root,files,task,true,false).eligible(),"Dedicated docs mode must not be bypassed");
  check(!AgentArtifactVerificationPolicy.inspect(root,files,task,false,true).eligible(),"Large tasks must not bypass checks");
  check(!AgentArtifactVerificationPolicy.inspect(root,files,task+" and run the tests",false,false).eligible(),"Code/test task must retain real verifier");
  check(!AgentArtifactVerificationPolicy.inspect(root,files+"\nM  src/App.java",task,false,false).eligible(),"Mixed code changes require real verifier");
  check(!AgentArtifactVerificationPolicy.inspect(root,"D  .opencode/.agents/code-reviewer.md",task,false,false).eligible(),"Deletion must not be accepted");
  check(!AgentArtifactVerificationPolicy.inspect(root,"workspace clean (no final changes from this agent run)",task,false,false).eligible(),"No changed artifact cannot pass");
  Path missing=root.resolve(".opencode/.agents/not-there.md");
  check(!AgentArtifactVerificationPolicy.inspect(root,"A  "+root.relativize(missing),task,false,false).passed(),"Missing output must fail");
  check(!AgentArtifactVerificationPolicy.inspect(root,"A  ../../outside.md",task,false,false).passed(),"Traversal must never pass");
  Path empty=root.resolve("empty.md");Files.writeString(empty,"");
  check(!AgentArtifactVerificationPolicy.inspect(root,"A  empty.md",task,false,false).passed(),"Empty must fail");
  Path invalid=root.resolve("invalid.md");Files.write(invalid,new byte[]{(byte)0xc3,(byte)0x28});
  check(!AgentArtifactVerificationPolicy.inspect(root,"A  invalid.md",task,false,false).passed(),"Invalid UTF8 must fail");
  Path over=root.resolve("over.md");Files.writeString(over,"x".repeat(270000));
  check(!AgentArtifactVerificationPolicy.inspect(root,"A  over.md",task,false,false).eligible(),"Huge artifact requires a specialized verifier");
  Path link=root.resolve("link.md");
  try {Files.createSymbolicLink(link,root.resolve(".opencode/.agents/code-reviewer.md"));
      check(!AgentArtifactVerificationPolicy.inspect(root,"A  link.md",task,false,false).passed(),"Symlinks must not pass");} catch(UnsupportedOperationException|SecurityException|java.nio.file.FileSystemException ignored){}
  System.out.println("PASS: ELIYA68 autonomous artifact verification (12 cases)");
 }
}
JAVA
javac --release 17 -d "$TMP/classes" src/main/java/com/llmart/llm/service/AgentArtifactVerificationPolicy.java "$TMP/Test.java"
java -cp "$TMP/classes" Test "$TMP/work"
python - <<'PY'
from pathlib import Path
s=Path('src/main/java/com/llmart/llm/service/AgentService.java').read_text()
assert 'autoVerifyMarkdownArtifacts(ws, run, index, null)' in s
assert s.count('autoVerifyMarkdownArtifacts(ws, run, step, onStep)')>=3
assert 'run.markVerificationAttempt(true, checked.detail())' in s
assert 'semantic' in Path('src/main/java/com/llmart/llm/service/AgentArtifactVerificationPolicy.java').read_text().lower()
print('PASS: autonomous final-step / final-response verification hooks')
PY
