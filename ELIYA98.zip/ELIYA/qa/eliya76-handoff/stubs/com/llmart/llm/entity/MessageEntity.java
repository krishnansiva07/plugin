package com.llmart.llm.entity;
public class MessageEntity {
 private final Long id; private final String role, content;
 public MessageEntity(long id,String role,String content){this.id=id;this.role=role;this.content=content;}
 public Long getId(){return id;}public String getRole(){return role;}public String getContent(){return content;}
}
