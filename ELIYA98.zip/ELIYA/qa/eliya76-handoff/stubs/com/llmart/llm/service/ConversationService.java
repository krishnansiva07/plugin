package com.llmart.llm.service;
import com.llmart.llm.entity.MessageEntity;import java.util.*;
class ConversationService {
 private final Map<String,List<MessageEntity>> data = new HashMap<>();
 void put(String id,List<MessageEntity> messages){data.put(id,messages);}
 public List<MessageEntity> messageEntities(String id){return data.getOrDefault(id,List.of());}
 public Optional<MessageEntity> messageInConversation(String id,long messageId){return messageEntities(id).stream().filter(m->m.getId()==messageId).findFirst();}
 public MessageDto messageDto(MessageEntity message){return new MessageDto(message.getId()==1?List.of("document-1"):List.of());}
 record MessageDto(List<String> attachmentIds){}
}
