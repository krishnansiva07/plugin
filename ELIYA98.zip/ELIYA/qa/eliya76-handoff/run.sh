#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../.."
T=$(mktemp -d); trap 'rm -rf "$T"' EXIT
javac --release 17 -d "$T" src/main/java/com/llmart/llm/service/ConversationHandoffSelection.java qa/eliya76-handoff/HandoffSmoke.java
java -cp "$T" com.llmart.llm.service.HandoffSmoke
javac --release 17 -cp "$T" -d "$T" \
    qa/eliya76-handoff/stubs/org/springframework/stereotype/Service.java \
    qa/eliya76-handoff/stubs/com/llmart/llm/entity/MessageEntity.java \
    qa/eliya76-handoff/stubs/com/llmart/llm/service/ConversationService.java \
    src/main/java/com/llmart/llm/service/ConversationHandoffService.java \
    qa/eliya76-handoff/HandoffServiceSmoke.java
java -cp "$T" com.llmart.llm.service.HandoffServiceSmoke
python3 - <<'PY'
from pathlib import Path
s=Path('src/main/java/com/llmart/llm/service/AgentService.java').read_text()
r=Path('src/main/java/com/llmart/llm/service/AgentToolRegistry.java').read_text()
c=Path('src/main/java/com/llmart/llm/service/ConversationHandoffService.java').read_text()
chat=Path('src/main/java/com/llmart/llm/service/ChatService.java').read_text()
assert 'conversationHandoff.enrich' in s
assert 'ConversationHandoffSelection.executionSteps' in s
assert 'conversation_handoff_read' in s and 'conversation_handoff_search' in s
assert 'conversation_handoff_read' in r and 'conversation_handoff_search' in r
assert 'conversations.messageEntities(conversationId)' in c
assert 'runTerminal' in chat and 'visibleAgentAnswer' in chat
print('PASS ELIYA76: actual conversation-backed read/search tools, scope and existing Chat flow')
PY
