package com.llmart.llm.service;

import java.util.*;

public class HandoffSmoke {
    static void yes(boolean condition,String message){if(!condition)throw new AssertionError(message);}
    static void eq(Object expected,Object actual,String message){yes(Objects.equals(expected,actual), message + " expected="+expected+" actual="+actual);}
    public static void main(String[] args) {
        String plan="## Phase 1: Assess the framework\nMap dependencies and test packages.\n"+
                "## Phase 2: Create Playwright framework\nGenerate structure.\n"+
                "## Phase 3: Migrate test packages\nMove tests package by package.\n"+
                "## Phase 4: Verify\nRun regression.\n";
        var turns=List.of(
                new ConversationHandoffSelection.Turn(1,"user","Migrate legacy Selenium framework to Playwright",List.of("word-doc")),
                new ConversationHandoffSelection.Turn(2,"assistant",plan,List.of()),
                new ConversationHandoffSelection.Turn(3,"user","Implement the complete phase-wise plan we discussed",List.of()));
        yes(ConversationHandoffSelection.isPlanExecutionReply("Implement the complete phase-wise plan we discussed"),"full plan implementation recognized");
        yes(!ConversationHandoffSelection.isPlanExecutionReply("Implement phase 2 only"),"partial plan not auto-promoted to full execution");
        yes(ConversationHandoffSelection.isPlanExecutionReply("Implement the plan we discussed"),"natural handoff request");
        yes(ConversationHandoffSelection.isPlanExecutionReply("Please execute our plan from chat"),"same-conversation plan execution");
        var found=ConversationHandoffSelection.select(turns,3,"Implement the complete phase-wise plan we discussed").orElseThrow();
        eq(2L,found.answerId(),"source id");
        eq(1L,found.requirementId(),"requirement id");
        yes(found.attachments().contains("word-doc"),"attached requirements retained");
        yes(found.plan(),"recognize plan");
        eq(4,ConversationHandoffSelection.executionSteps(found.answer(),found.answerId()).size(),"phase tracking");
        yes(ConversationHandoffSelection.select(turns,3,"Fix unrelated timeout").isEmpty(),"no stale plan leakage");
        yes(ConversationHandoffSelection.select(turns,3,"Explain what we discussed above").isPresent(),"read-only context follow-up");
        yes(!ConversationHandoffSelection.isPlanExecutionReply("Explain phase 2"),"read-only inquiry never executes");
        yes(ConversationHandoffSelection.isPlanExecutionReply("Please continue"),"short continuation");
        var other=List.of(new ConversationHandoffSelection.Turn(10,"user","Explain architecture",List.of()),
                new ConversationHandoffSelection.Turn(11,"assistant","Layered architecture with service and API gateways",List.of()),
                new ConversationHandoffSelection.Turn(12,"user","Implement it",List.of()));
        yes(!ConversationHandoffSelection.select(other,12,"Implement it").orElseThrow().plan(),"design is not an approved plan");
        System.out.println("PASS ELIYA76: Chat-to-Agent plan selection, scoping, phases, followups and attachments");
    }
}
