package com.llmart.llm.service;
import com.llmart.llm.entity.MessageEntity;
import java.util.*;
public class HandoffServiceSmoke {
 static void yes(boolean c,String why){if(!c) throw new AssertionError(why);}
 public static void main(String[] args) {
   ConversationService db=new ConversationService();
   String huge="## Phase 1: Implement\n"+"Phase-detail ".repeat(6000);
   db.put("a",List.of(new MessageEntity(1,"user","Use Java 17 and the document requirements"),
           new MessageEntity(2,"assistant",huge),new MessageEntity(3,"user","Implement it")));
   db.put("b",List.of(new MessageEntity(4,"user","private another user's message")));
   ConversationHandoffService service=new ConversationHandoffService(db);
   var original=List.<Map<String,Object>>of(Map.of("role","system","content","system"),
           Map.of("role","user","content","Implement it"));
   var enriched=service.enrich("a","Implement it",original);
   yes(enriched.size()==3,"hand-off inserted directly before the authoritative user request");
   yes(enriched.get(2).get("content").equals("Implement it"),"current user request preserved");
   String packet=String.valueOf(enriched.get(1).get("content"));
   yes(packet.contains("document-1"),"prior attachment ID retained");
   yes(packet.contains("conversation_handoff_read"),"full answer access surfaced");
   yes(packet.contains("TRUNCATED IN PREVIEW"),"truncation explicitly reported");
   yes(service.read("a",2,15000,10000).contains("characters 15000..25000"),"paged full answer");
   yes(service.read("b",2,0,100).contains("does not exist"),"cross-conversation read blocked");
   yes(service.search("b","Use Java",10).contains("No matching"),"cross-conversation search blocked");
   yes(service.search("a","Phase-detail",10).contains("messageId=2"),"search saved message source");
   yes(service.enrich("a","Fix an unrelated error",original)==original,"no handoff for unrelated task");
   System.out.println("PASS ELIYA76: read/search pagination, source isolation, original requirement, attachments, context priority");
 }
}
