#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT
javac --release 17 -encoding UTF-8 -d "$TMP" \
  "$ROOT/src/main/java/com/llmart/llm/service/AgentPlanJsonEnvelope.java" \
  "$ROOT/src/main/java/com/llmart/llm/service/AgentPlanRecovery.java" \
  "$ROOT/qa/eliya84-planner-resilience/PlannerResilienceSmoke.java"
java -cp "$TMP" com.llmart.llm.service.PlannerResilienceSmoke
python3 - "$ROOT/src/main/java/com/llmart/llm/service/AgentService.java" <<'PY'
import sys
s=open(sys.argv[1]).read()
start=s.index('    private PlanProposal generatePlanProposal(')
end=s.index('    /**\n     * Lightweight same-model recovery',start)
segment=s[start:end]
assert segment.count('completeRoleText(')==1, 'planner must use a single model call'
assert 'AgentPlanRecovery.fromUserRequest' in segment, 'original-request fallback missing'
assert 'run.updateActivity("planning_recovery"' in segment, 'recovery progress missing'
assert 'Planner returned incomplete or malformed JSON' not in segment, 'old failure path retained'
assert 'run.recordModelUsage' in segment, 'token usage must be counted'
assert 'AgentPlanRecovery.refusal' in segment, 'provider safety refusal lost'
assert 'protectedSnapshots.begin(' in s, 'mutation safety lost'
print('PASS: planner single call, fallback, telemetry and rollback invariants')
PY
