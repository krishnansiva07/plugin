package com.llmart.llm.service;

import java.util.List;

public class PlannerResilienceSmoke {
    private static int count;
    private static void check(boolean condition, String message) {
        if (!condition) throw new AssertionError(message);
        count++;
    }
    public static void main(String[] args) {
        check(AgentPlanJsonEnvelope.extract("```json\n{\"plan\":[\"Inspect\",\"Verify\"]}\n```").equals("{\"plan\":[\"Inspect\",\"Verify\"]}"), "fence");
        check(AgentPlanJsonEnvelope.extract("<think>I thought of {x}</think> Result: {\"plan\":[\"Do { safe }\"]} trailing").equals("{\"plan\":[\"Do { safe }\"]}"), "thinking wrapper");
        check(AgentPlanJsonEnvelope.extract("{\"plan\":[{\"title\":\"Read source\"},{\"title\":\"Broken\"").startsWith("{\"plan\":["), "partial must be returned partial");
        check(AgentPlanRecovery.looksStructured("{\"plan\":[{\"title\":\"x\"}"), "structured partial");
        check(!AgentPlanRecovery.looksStructured("1. Inspect source\n2. Verify result"), "plain text plan");
        check(AgentPlanRecovery.plainSteps("1. Inspect relevant source\n2. Verify real outputs").size() == 2, "numbered list recovery");
        check(AgentPlanRecovery.plainSteps("{\"plan\":[\"Inspect source\",").isEmpty(), "never accept a JSON fragment as step");
        check(AgentPlanRecovery.fromUserRequest("Create agent and skill; only in agents folder", false).size()==2, "full requested scope fallback");
        check(AgentPlanRecovery.fromUserRequest("Explain architecture", true).size()==1, "read only fallback");
        check(AgentPlanRecovery.fromUserRequest("Explain architecture", true).get(0).contains("do not modify files"), "read-only safety");
        check(AgentPlanRecovery.refusal("I can't help with that request", ""), "refusal is not converted into execution");
        check(AgentPlanRecovery.refusal("", "content_filter"), "provider refusal");
        check(!AgentPlanRecovery.refusal("{\"plan\":[\"Inspect\"]}", "length"), "length is recoverable");
        check(AgentPlanRecovery.fromUserRequest("", false).isEmpty(), "cannot execute a missing objective");
        check(AgentPlanJsonEnvelope.extract("Before {\"other\":1}, then {\"plan\":[\"ok\"]}").equals("{\"plan\":[\"ok\"]}"), "prefer plan object");
        System.out.println("PASS: " + count + " planner resilience checks");
    }
}
