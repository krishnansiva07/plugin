#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
D=$(mktemp -d); trap 'rm -rf "$D"' EXIT
cat > "$D/ContextAuditSmoke.java" <<'JAVA'
import com.llmart.llm.service.AgentContextAudit;
import java.util.*;
class ContextAuditSmoke {
 public static void main(String[] args) {
  var calls=List.<Map<String,Object>>of(Map.of("function",Map.of("arguments","{\"content\":\"long content\"}")));
  var rows=List.<Map<String,Object>>of(
   Map.of("role","system","content","stable rule"),
   Map.of("role","system","content","[RUNTIME_STATE:durable]\nstate"),
   Map.of("role","system","content","[RUNTIME_RETRIEVAL:index]\nsymbol"),
   Map.of("role","user","content","my request"),
   Map.of("role","assistant","content","creating", "tool_calls",calls),
   Map.of("role","tool","content","exitCode=0; result"));
  var measured=AgentContextAudit.measure(rows,List.of(Map.of("function","shell tool")));
  if(measured.instructions()!=11 || measured.userText()!=10 || measured.toolResults()<=0 || measured.toolCallArguments()<=0 || measured.toolSchema()<=0)
    throw new AssertionError("Incorrect diagnostic attribution: "+measured);
  if(measured.summary().contains("my request") || measured.summary().contains("long content")) throw new AssertionError("Sensitive prompt exposed in audit");
  System.out.println("PASS: request context category accounting (strings never emitted; char estimates not token charges)");
 }
}
JAVA
javac --release 17 -d "$D" src/main/java/com/llmart/llm/service/AgentContextAudit.java "$D/ContextAuditSmoke.java"
java -cp "$D" ContextAuditSmoke
