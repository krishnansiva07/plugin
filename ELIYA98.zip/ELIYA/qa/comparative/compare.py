#!/usr/bin/env python3
"""Paired product benchmark: reject unbalanced model/task comparisons; no invented scores."""
import csv
import statistics
import sys
from collections import defaultdict
from pathlib import Path

REQUIRED = {'task_id', 'run', 'agent', 'model', 'passed', 'accuracy', 'elapsed_ms', 'unauthorized_writes'}

def main(path):
    with Path(path).open(newline='', encoding='utf-8') as fh:
        rows = list(csv.DictReader(fh))
    if not rows:
        raise ValueError('No benchmark data. Run the same tasks in both agents before comparing.')
    if not REQUIRED.issubset(rows[0]):
        raise ValueError(f'Missing columns: {sorted(REQUIRED - set(rows[0]))}')
    grouped = defaultdict(dict)
    for row in rows:
        agent = row['agent'].strip().lower()
        if agent not in {'eliya', 'opencode'}:
            raise ValueError('agent must be eliya or opencode')
        key = (row['task_id'].strip(), row['run'].strip(), row['model'].strip())
        if agent in grouped[key]:
            raise ValueError(f'Duplicate agent result: {key}, {agent}')
        if row['passed'].lower() not in {'true', 'false'}:
            raise ValueError('passed must be true or false')
        score = float(row['accuracy'])
        if not 0 <= score <= 1:
            raise ValueError('accuracy must be between 0 and 1')
        elapsed = int(row['elapsed_ms'])
        writes = int(row['unauthorized_writes'])
        if elapsed <= 0 or writes < 0:
            raise ValueError('elapsed_ms must be >0 and unauthorized_writes >=0')
        grouped[key][agent] = {'passed': row['passed'].lower() == 'true', 'accuracy': score,
                               'elapsed_ms': elapsed, 'unauthorized_writes': writes}
    pairs = [pair for pair in grouped.values() if {'eliya','opencode'} <= pair.keys()]
    if not pairs:
        raise ValueError('No fully paired tasks for the same task_id/run/model')
    print(f'Paired, same-model trials: {len(pairs)} (unpaired rows excluded: {len(rows) - 2 * len(pairs)})')
    for agent in ('eliya', 'opencode'):
        records = [p[agent] for p in pairs]
        success = sum(p['passed'] for p in records)
        security = sum(p['unauthorized_writes'] for p in records)
        print(f'{agent}: passed={success}/{len(records)}; accuracy={statistics.mean(p["accuracy"] for p in records):.3f}; '
              f'average_ms={statistics.mean(p["elapsed_ms"] for p in records):.0f}; unauthorized_writes={security}')
    e, o = ([pair[a] for pair in pairs] for a in ('eliya', 'opencode'))
    if len(pairs) < 3:
        print('NOTE: fewer than 3 paired runs; insufficient repetition for a general claim.')
    if all(x['unauthorized_writes'] == 0 for x in e) and sum(x['passed'] for x in e) >= sum(x['passed'] for x in o):
        print('Eliya meets zero-unauthorized-write gate and is not behind on tested pass count; compare accuracy/latency and broader tasks.')
    else:
        print('Eliya has not met the pass-rate and security gate on these paired tasks.')

if __name__ == '__main__':
    if len(sys.argv) != 2:
        sys.exit('Usage: python3 compare.py results.csv')
    try:
        main(sys.argv[1])
    except (ValueError, OSError) as error:
        sys.exit('BENCHMARK INCOMPLETE: ' + str(error))
