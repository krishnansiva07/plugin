#!/usr/bin/env python3
"""Compare provider-reported tokens on identical tasks, model and repeat; never invent parity."""
import csv
import statistics
import sys
from collections import defaultdict
from pathlib import Path

FIELDS = {'task_id', 'run', 'agent', 'model', 'passed', 'total_tokens'}
BASELINES = ('opencode', 'claude')


def compare(path):
    with Path(path).open(encoding='utf-8', newline='') as file:
        rows = list(csv.DictReader(file))
    if not rows or not FIELDS.issubset(rows[0]):
        raise ValueError('Need paired real provider usage rows with fields: ' + ', '.join(sorted(FIELDS)))
    trials = defaultdict(dict)
    for row in rows:
        agent = row['agent'].strip().lower()
        if agent not in ('eliya',) + BASELINES:
            raise ValueError('Unexpected agent: ' + agent)
        key = (row['task_id'].strip(), row['run'].strip(), row['model'].strip())
        if not all(key):
            raise ValueError('Task ID, repeat and model are required for each result')
        if agent in trials[key]:
            raise ValueError('Duplicate run: ' + repr((key, agent)))
        if row['passed'].lower() not in {'true', 'false'}:
            raise ValueError('passed must be true/false')
        try:
            tokens = int(row['total_tokens'])
        except ValueError:
            raise ValueError('Provider-reported total_tokens must be an integer') from None
        if tokens <= 0:
            raise ValueError('Missing/estimated/zero provider tokens cannot establish a parity claim')
        trials[key][agent] = (tokens, row['passed'].lower() == 'true')
    reports = 0
    for baseline in BASELINES:
        pairs = [(item['eliya'], item[baseline]) for item in trials.values() if 'eliya' in item and baseline in item]
        if not pairs:
            print(f'No same-task/same-model pairs for {baseline}; cannot compare.')
            continue
        reports += 1
        e_total = sum(e[0] for e, _ in pairs)
        b_total = sum(b[0] for _, b in pairs)
        e_pass = sum(e[1] for e, _ in pairs)
        b_pass = sum(b[1] for _, b in pairs)
        ratios = [e[0]/b[0] for e,b in pairs]
        print(f'Eliya vs {baseline}: {len(pairs)} paired task-run-model trials')
        print(f'  Provider total tokens: Eliya={e_total:,}; {baseline}={b_total:,}; '
              f'Eliya/baseline={e_total / b_total:.3f}; median per-task ratio={statistics.median(ratios):.3f}')
        print(f'  Verified pass: Eliya={e_pass}/{len(pairs)}; {baseline}={b_pass}/{len(pairs)}')
        if e_total <= b_total and e_pass >= b_pass:
            print('  GATE PASS for these paired trials ONLY (token total and completed-task count).')
        else:
            print('  GATE NOT MET. Lower tokens alone do not compensate for weaker task completion.')
    if reports == 0:
        raise ValueError('No fully paired task-run-model records. Do not claim OpenCode/Claude parity.')
    if any(len([t for t in trials if trials[t].get('eliya') and trials[t].get(b)]) < 3 for b in BASELINES if any(b in item for item in trials.values())):
        print('Note: fewer than three repeated pairs for at least one baseline; do not generalize.')


if __name__ == '__main__':
    if len(sys.argv) != 2:
        sys.exit('Usage: python3 qa/comparative/compare_tokens.py path/to/real_usage.csv')
    try:
        compare(sys.argv[1])
    except (ValueError, OSError) as exc:
        sys.exit('BENCHMARK INCOMPLETE: ' + str(exc))
