package com.fasterxml.jackson.databind;
import java.util.*;
public class JsonNode implements Iterable<JsonNode> {
 private final Object value;
 public JsonNode() {this(Map.of());}
 public JsonNode(Object value) {this.value=value;}
 public JsonNode path(String key) {
   if(value instanceof Map<?,?> m && m.containsKey(key)) return new JsonNode(m.get(key));
   return new JsonNode(null);
 }
 public boolean has(String key){return value instanceof Map<?,?> m && m.containsKey(key);}
 public String asText(){return value==null?"":String.valueOf(value);}
 public String asText(String def){return value==null?def:asText();}
 public int asInt(int fallback){try{return Integer.parseInt(asText());}catch(Exception e){return fallback;}}
 public int size(){return value instanceof List<?> l ? l.size() : 0;}
 public boolean isMissingNode(){return value==null;}
 public boolean isTextual(){return value instanceof String;}
 public boolean isObject(){return value instanceof Map;}
 public boolean isArray(){return value instanceof List;}
 public Iterator<JsonNode> iterator(){
  if(value instanceof List<?> a) return a.stream().map(JsonNode::new).iterator();
  return Collections.emptyIterator();
 }
}
