package com.fasterxml.jackson.databind;
import java.io.*; import java.util.*; import java.nio.file.*;
/** Isolated, tiny test-only JSON codec. Not included in the application artifact. */
public class ObjectMapper {
 public JsonNode readTree(File f) throws IOException{return readTree(Files.readString(f.toPath()));}
 public JsonNode readTree(String s){return new JsonNode(new Parser(s).value());}
 private static class Parser {
  final String s; int p;
  Parser(String s){this.s=s==null?"":s;}
  void skip(){while(p<s.length() && Character.isWhitespace(s.charAt(p)))p++;}
  Object value(){skip();if(p>=s.length())return null;char c=s.charAt(p);
   if(c=='{')return object();if(c=='[')return array();if(c=='"')return string();
   if(s.startsWith("true",p)){p+=4;return true;}if(s.startsWith("false",p)){p+=5;return false;}
   if(s.startsWith("null",p)){p+=4;return null;}int start=p;
   while(p<s.length()&&"0123456789-+eE.".indexOf(s.charAt(p))>=0)p++;
   if(p>start){try{return Double.valueOf(s.substring(start,p));}catch(NumberFormatException ignored){}}
   throw new IllegalArgumentException("Malformed JSON at " + p);
  }
  Object object(){p++;Map<String,Object> map=new LinkedHashMap<>();skip();if(s.charAt(p)=='}'){p++;return map;}
   while(true){skip();String key=string();skip();if(s.charAt(p++)!=':')throw new IllegalArgumentException("Expected colon");
    map.put(key,value());skip();char d=s.charAt(p++);if(d=='}')return map;if(d!=',')throw new IllegalArgumentException("Expected comma");}}
  Object array(){p++;List<Object> list=new ArrayList<>();skip();if(s.charAt(p)==']'){p++;return list;}
   while(true){list.add(value());skip();char d=s.charAt(p++);if(d==']')return list;if(d!=',')throw new IllegalArgumentException("Expected comma");}}
  String string(){skip();if(s.charAt(p++)!='"')throw new IllegalArgumentException("Expected string");StringBuilder b=new StringBuilder();
   while(p<s.length()){char c=s.charAt(p++);if(c=='"')return b.toString();
    if(c=='\\'){char e=s.charAt(p++);switch(e){case 'n'->b.append('\n');case 'r'->b.append('\r');case 't'->b.append('\t');
      case 'b'->b.append('\b');case 'f'->b.append('\f');case '"'->b.append('"');case '\\'->b.append('\\');case '/'->b.append('/');
      case 'u'->{b.append((char)Integer.parseInt(s.substring(p,p+4),16));p+=4;}default->throw new IllegalArgumentException("Bad escape");}
    }else b.append(c);}
   throw new IllegalArgumentException("Unclosed string");}
 }
 public String writeValueAsString(Object o){return json(o);}
 private String json(Object o){
  if(o==null)return "null";
  if(o instanceof Map<?,?> m){List<String> list=new ArrayList<>();m.forEach((k,v)->list.add(json(String.valueOf(k))+":"+json(v)));return "{"+String.join(",",list)+"}";}
  if(o instanceof Iterable<?> list){List<String> l=new ArrayList<>();for(Object x:list)l.add(json(x));return "["+String.join(",",l)+"]";}
  if(o instanceof Number || o instanceof Boolean)return String.valueOf(o);
  return "\""+String.valueOf(o).replace("\\","\\\\").replace("\"","\\\"").replace("\n","\\n")+"\"";
 }
 public void writeValue(File f,Object o) throws IOException{Files.writeString(f.toPath(),json(o));}
 @SuppressWarnings("unchecked") public <T> T convertValue(Object value,Class<T> cls){return (T)Map.of();}
 public JsonNode createObjectNode(){return new JsonNode();}
}
