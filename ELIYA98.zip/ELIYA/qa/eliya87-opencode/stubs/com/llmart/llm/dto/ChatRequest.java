package com.llmart.llm.dto;
public record ChatRequest(String projectId,String message,java.util.List<String> attachmentIds,ChatMode chatMode,Settings settings) {public String conversationId(){return null;} public boolean isRegenerate(){return false;} public record Settings(String model){} }
