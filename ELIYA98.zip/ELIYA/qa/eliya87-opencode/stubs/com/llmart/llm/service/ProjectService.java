package com.llmart.llm.service;
public class ProjectService { public Project require(String id){return new Project();} public static class Project{public boolean hasLocalPath(){return true;} public String getLocalPath(){return System.getProperty("eliya.qa.workspace", "/tmp");}} }
