package com.llmart.llm.dto;
public enum ChatMode {CHAT,AGENT}
