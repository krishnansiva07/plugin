package org.springframework.beans.factory.annotation;
public @interface Value {String value();}
