package org.springframework.web.servlet.mvc.method.annotation;
public class SseEmitter {
 public SseEmitter(long x){} public void onCompletion(Runnable r){} public void onTimeout(Runnable r){} public void onError(java.util.function.Consumer<Throwable> c){} public void complete(){}
 public void send(SseEventBuilder b) throws Exception{}
 public static SseEventBuilder event(){return new SseEventBuilder();}
 public static class SseEventBuilder {public SseEventBuilder name(String x){return this;}public SseEventBuilder data(Object o){return this;}}
}
