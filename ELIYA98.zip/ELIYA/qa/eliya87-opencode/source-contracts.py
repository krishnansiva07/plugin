from pathlib import Path
s = Path('src/main/java/com/llmart/llm/service/OpenCodeExecutionService.java').read_text()
c = Path('src/main/java/com/llmart/llm/controller/TerminalController.java').read_text()
a = Path('src/main/resources/static/app.js').read_text()
i = Path('src/main/resources/static/index.html').read_text()
p = Path('src/main/resources/application.properties').read_text()
checks = {
    'v2 create': '"/api/session"' in s,
    'v2 asynchronous prompt': '"/prompt"' in s,
    'v2 durable event log': '"/log?follow=true"' in s,
    'v2 interrupt': '"/interrupt?resume=false"' in s,
    'loopback restriction': '127.0.0.1' in s and 'localhost' in s and 'Remote tool execution is disabled' in s,
    'workspace canonicalization': 'toRealPath()' in s,
    'MCP restriction': 'rule("*mcp*", "*", "deny")' in s,
    'legacy fallback': 'return sessions.launch(key, request)' in c,
    'Terminal engine route': '"/engine"' in c,
    'OpenCode session route': 'openCode.launch(request, context)' in c,
    'UI indicator': 'terminalEngineIndicator' in i and 'refreshTerminalExecutionEngine' in a,
    'default auto-start': '${ELIYA_EXECUTION_ENGINE:opencode}' in p and '${ELIYA_OPENCODE_AUTO_START:true}' in p,
}
for k, v in checks.items(): print(('PASS' if v else 'FAIL'),k)
assert all(checks.values()), 'OpenCode bridge contract failed'
