"""Browser interaction smoke for agent instruction queue; APIs are mocked, no provider or file changes."""
import asyncio, re
from pathlib import Path
from playwright.async_api import async_playwright
root=Path(__file__).resolve().parent.parent/'src/main/resources/static'
async def main():
  async with async_playwright() as pw:
    browser=await pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
    page=await browser.new_page(viewport={'width':1200,'height':900})
    page.set_default_timeout(6000)
    errors=[]
    page.on('pageerror',lambda error: errors.append(str(error)))
    html=(root/'index.html').read_text()
    html=re.sub(r'<script src="[^"]+"></script>','',html)
    html=re.sub(r'<link rel="stylesheet"[^>]+>','',html)
    await page.set_content(html)
    await page.add_style_tag(content=(root/'app.css').read_text())
    await page.evaluate('''() => {
      window.__queueRequests=[];window.__terminalMock=null;
      window.fetch=async (url,opts={}) => {
        const path=String(url).split('?')[0],method=opts.method||'GET';
        let data={};try{data=JSON.parse(opts.body||'{}')}catch(_){}
        window.__queueRequests.push({path,method,data});
        let response={};
        if(path==='/api/terminal/workspaces')response=[{id:'w1',name:'Alpha',localPath:'/tmp/alpha'},{id:'w2',name:'Beta',localPath:'/tmp/beta'}];
        else if(path==='/api/terminal/capabilities')response={count:0,repositories:[]};
        else if(path==='/api/terminal/sessions'&&method==='GET')response=window.__terminalMock?[{
          ...window.__terminalMock,queueCount:window.__terminalMock.queue.length}]:[];
        else if(path==='/api/terminal/sessions'&&method==='POST'){
          window.__terminalMock={id:'test-session',conversationId:'test-conv',prompt:data.message,fullPrompt:data.message,
          status:'running',projectId:data.projectId,model:data.settings.model,referenceProjectIds:[],referenceProjectNames:{},
          turns:[{role:'user',content:data.message}],answer:'',queue:[],queuePaused:false,runId:'',events:[],question:{}};
          response=window.__terminalMock;
        }
        else if(path==='/api/terminal/sessions/test-session/message'&&method==='POST'){
          window.__terminalMock.queue.push({id:'q'+(window.__terminalMock.queue.length+1),prompt:data.message,
            projectId:data.projectId,model:data.settings.model,referenceProjectIds:[],referenceProjectNames:{}});
          response={...window.__terminalMock,queueCount:window.__terminalMock.queue.length};
        }
        else if(path.startsWith('/api/terminal/sessions/test-session/queue/')&&method==='PATCH'){
          const id=path.split('/').at(-1);window.__terminalMock.queue.find(q=>q.id===id).prompt=data.prompt;
          response=window.__terminalMock;
        }
        else if(path.endsWith('/move')&&method==='POST'){
          const id=path.split('/').at(-2),q=window.__terminalMock.queue,from=q.findIndex(item=>item.id===id),to=from+(data.direction==='up'?-1:1);
          [q[from],q[to]]=[q[to],q[from]];response=window.__terminalMock;
        }
        else if(path.startsWith('/api/terminal/sessions/test-session/queue/')&&method==='DELETE'){
          const id=path.split('/').at(-1);window.__terminalMock.queue=window.__terminalMock.queue.filter(q=>q.id!==id);
          response=window.__terminalMock;
        }
        else if(path.endsWith('/queue/resume')&&method==='POST'){
          window.__terminalMock.queuePaused=false;window.__terminalMock.status='queued';response=window.__terminalMock;
        }
        else if(path.endsWith('/interrupt-next')&&method==='POST'){
          window.__terminalMock.status='cancelling';response=window.__terminalMock;
        }
        else if(path==='/api/terminal/sessions/test-session')response=window.__terminalMock;
        else if(path==='/api/terminal/sessions/test-session/cancel'&&method==='POST'){
          window.__terminalMock.queuePaused=true;window.__terminalMock.status='cancelled';response=window.__terminalMock;
        }
        else if(path==='/api/conversations')response=[];
        return new Response(JSON.stringify(response),{status:200,headers:{'Content-Type':'application/json'}});
      };
    }''')
    for filename in ['markdown.js','prompt-catalog.js','app.js','confluence-composer.js']:
      await page.add_script_tag(content=(root/filename).read_text())
    await page.evaluate("state.config.apiKey='mock-key';state.config.baseUrl='http://mock.invalid';state.config.model='model-1';")
    await page.click('#launchTerminalBtn')
    await page.wait_for_function("() => document.querySelector('#terminalWorkspaceSelect').options.length===3")
    await page.evaluate("() => {document.getElementById('terminalWorkspaceSelect').value='w1';document.getElementById('terminalWorkspaceSelect').dispatchEvent(new Event('change',{bubbles:true}));}")
    await page.fill('#terminalTask','Build Alpha')
    await page.click('#terminalSendBtn')
    await page.wait_for_selector('[data-terminal-tab="test-session"]')
    await page.fill('#terminalTask','Run test suite')
    await page.click('#terminalSendBtn')
    await page.wait_for_selector('[data-terminal-queue-item="q1"]')
    assert '1 pending' in await page.locator('#terminalInputHint').inner_text()
    await page.click('#terminalConfigPanel summary')
    await page.evaluate("() => {document.getElementById('terminalWorkspaceSelect').value='w2';document.getElementById('terminalWorkspaceSelect').dispatchEvent(new Event('change',{bubbles:true}));}")
    await page.fill('#terminalTask','Write Beta report')
    await page.click('#terminalSendBtn')
    await page.wait_for_selector('[data-terminal-queue-item="q2"]')
    assert await page.evaluate("window.__terminalMock.queue[1].projectId")=='w2'
    await page.click('[data-terminal-queue-edit="q1"]')
    await page.fill('[data-terminal-queue-editor="q1"]','Run focused tests only')
    await page.click('[data-terminal-queue-save="q1"]')
    await page.wait_for_function("() => window.__terminalMock.queue[0].prompt==='Run focused tests only'")
    await page.click('[data-terminal-queue-move="q2"][data-direction="up"]')
    await page.wait_for_function("() => window.__terminalMock.queue[0].id==='q2'")
    await page.click('[data-terminal-queue-remove="q1"]')
    await page.wait_for_function("() => window.__terminalMock.queue.length===1")
    await page.click('[data-terminal-interrupt="test-session"]')
    await page.wait_for_function("() => window.__queueRequests.some(r=>r.path.endsWith('/interrupt-next'))")
    await page.evaluate("window.__terminalMock.status='cancelled';window.__terminalMock.queuePaused=true")
    await page.evaluate('pollTerminalSessions()')
    await page.wait_for_selector('[data-terminal-queue-resume]')
    await page.click('[data-terminal-queue-resume]')
    await page.wait_for_function("() => window.__queueRequests.some(r=>r.path.endsWith('/queue/resume'))")
    assert not errors,errors
    print('PASS: Chromium queue workflow — send while busy, scoped workspace, edit, reorder, remove, interrupt, resume, zero page errors')
    await browser.close()
asyncio.run(main())
