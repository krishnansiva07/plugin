#!/usr/bin/env bash
set -euo pipefail
BASE="$(cd "$(dirname "$0")/../.." && pwd)"
TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT
javac --release 17 -d "$TMP" \
  "$BASE/src/main/java/com/llmart/llm/service/AgentPreparationGuard.java" \
  "$BASE/qa/agent-reliability/AgentPreparationGuardSmoke.java" \
  "$BASE/qa/agent-reliability/SourceParseSmoke.java"
java -cp "$TMP" AgentPreparationGuardSmoke
java -cp "$TMP" SourceParseSmoke "$BASE/src/main/java"
python3 "$BASE/qa/agent-reliability/source-contracts.py" "$BASE/src/main/java/com/llmart/llm/service"
