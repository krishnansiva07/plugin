import javax.tools.*;
import com.sun.source.util.JavacTask;
import java.nio.file.*;
import java.util.*;

public final class SourceParseSmoke {
    public static void main(String[] args) throws Exception {
        JavaCompiler compiler = ToolProvider.getSystemJavaCompiler();
        if (compiler == null) throw new IllegalStateException("JDK required");
        List<Path> files;
        try (var walk = Files.walk(Path.of(args[0]))) {
            files = walk.filter(p -> p.toString().endsWith(".java")).toList();
        }
        DiagnosticCollector<JavaFileObject> diagnostics = new DiagnosticCollector<>();
        try (StandardJavaFileManager manager = compiler.getStandardFileManager(diagnostics, Locale.ROOT, null)) {
            Iterable<? extends JavaFileObject> sources = manager.getJavaFileObjectsFromPaths(files);
            JavacTask task = (JavacTask) compiler.getTask(null, manager, diagnostics,
                    List.of("--release", "17", "-proc:none"), null, sources);
            long parsed = 0;
            for (var tree : task.parse()) parsed++;
            long bad = diagnostics.getDiagnostics().stream().filter(d -> d.getKind() == Diagnostic.Kind.ERROR).count();
            if (bad != 0) {
                diagnostics.getDiagnostics().stream().filter(d -> d.getKind() == Diagnostic.Kind.ERROR)
                        .limit(25).forEach(System.err::println);
                throw new AssertionError("Java source parsing failed: " + bad + " diagnostics");
            }
            System.out.println("PASS: Java 17 parser accepted " + parsed + " source files (syntax only; Maven/type resolution not available)");
        }
    }
}
