import com.llmart.llm.service.AgentPreparationGuard;
import java.io.IOException;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;

public final class AgentPreparationGuardSmoke {
    private static void ok(boolean cond, String why) { if (!cond) throw new AssertionError(why); }
    public static void main(String[] args) throws Exception {
        List<String> updates = new ArrayList<>();
        AtomicInteger checks = new AtomicInteger();
        var fast = new AgentPreparationGuard("hash", 10, checks::incrementAndGet, updates::add);
        fast.directory(); fast.file(1024); fast.file(42); fast.reportNow();
        ok(fast.files() == 2 && fast.bytes() == 1066, "File/byte accounting corrupted");
        ok(checks.get() >= 3, "Cancellation checker was not polled");
        ok(updates.get(updates.size()-1).contains("files=2"), "No actionable progress");
        var cancelled = new AgentPreparationGuard("cancel", 10, () -> {throw new IllegalStateException("cancelled");}, null);
        try { cancelled.check(); throw new AssertionError("Cancellation swallowed"); }
        catch (IllegalStateException expected) {ok(expected.getMessage().equals("cancelled"), "Changed cancel error");}
        var expired = new AgentPreparationGuard("timeout", 1, null, null);
        Thread.sleep(1100);
        try { expired.check(); throw new AssertionError("Deadline ignored"); }
        catch (IOException expected) {ok(expected.getMessage().contains("timeout exceeded"), "Missing phase/deadline diagnostics");}
        System.out.println("PASS: stage accounting, progress, cancellation, deadline");
    }
}
