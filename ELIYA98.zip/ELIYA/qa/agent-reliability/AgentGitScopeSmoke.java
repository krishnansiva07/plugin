package com.llmart.llm.service;
import java.nio.file.*;
import java.util.*;

/** Bounded workspace git detection; does not execute shell or depend on providers. */
public class AgentGitScopeSmoke {
  private static void require(boolean valid, String why) { if(!valid) throw new AssertionError(why); }
  public static void main(String[] args) throws Exception {
    require(AgentGitScope.isSimpleGitStatusRequest("git status"),"plain git status should be read only");
    require(AgentGitScope.isSimpleGitStatusRequest("can you run git status?"),"polite request should be status");
    require(!AgentGitScope.isSimpleGitStatusRequest("git reset --hard"),"dangerous git command never status");
    require(!AgentGitScope.isSimpleGitStatusRequest("modify and git status"),"modified task not status");
    Path ws = Files.createTempDirectory("eliya61-git-test");
    try {
      require(AgentGitScope.gitRepositories(ws).isEmpty(),"empty workspace should have no repos");
      Path a=Files.createDirectories(ws.resolve("frontend"));
      Path b=Files.createDirectories(ws.resolve("backend"));
      Files.createDirectory(a.resolve(".git"));
      Files.createFile(b.resolve(".git")); // linked Git worktree metadata is a file
      require(AgentGitScope.gitRepositories(ws).size()==2,"two Git roots should trigger selection");
      Path ignored=Files.createDirectories(ws.resolve("node_modules").resolve("dep"));
      Files.createDirectory(ignored.resolve(".git"));
      require(AgentGitScope.gitRepositories(ws).size()==2,"exclude dependency repositories");
    } finally {
      try(var paths=Files.walk(ws)){paths.sorted(Comparator.reverseOrder()).forEach(p->{try{Files.deleteIfExists(p);}catch(Exception ignored){}});}
    }
    System.out.println("PASS: simple Git status classification; zero, multiple and worktree Git roots; skipped dependencies");
  }
}
