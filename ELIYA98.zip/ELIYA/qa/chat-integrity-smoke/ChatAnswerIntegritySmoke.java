package com.llmart.llm.service;

public class ChatAnswerIntegritySmoke {
    private static void eq(String actual, String expected, String label) {
        if (!expected.equals(actual)) throw new AssertionError(label + ": expected " + expected + ", received " + actual);
    }
    private static void ok(boolean condition, String label) {
        if (!condition) throw new AssertionError(label);
    }
    public static void main(String[] args) {
        ChatAnswerIntegrity.Resolved exact = ChatAnswerIntegrity.reconcile("A\nB", "A\nB");
        eq(exact.content(), "A\nB", "exact response");
        ok(!exact.divergent() && exact.unstreamedSuffix().isEmpty(), "exact metadata");

        ChatAnswerIntegrity.Resolved shorter = ChatAnswerIntegrity.reconcile("first\nsecond\nthird", "first");
        eq(shorter.content(), "first\nsecond\nthird", "persist complete stream even if done truncated");
        ok(shorter.divergent(), "flag truncated done");

        ChatAnswerIntegrity.Resolved empty = ChatAnswerIntegrity.reconcile("generated result", "");
        eq(empty.content(), "generated result", "preserve stream when done empty");

        ChatAnswerIntegrity.Resolved suffix = ChatAnswerIntegrity.reconcile("first", "first and second");
        eq(suffix.content(), "first and second", "returned valid longer result");
        eq(suffix.unstreamedSuffix(), " and second", "send missing suffix before done");
        ok(!suffix.divergent(), "valid longer result is not divergent");

        ChatAnswerIntegrity.Resolved incompatible = ChatAnswerIntegrity.reconcile("first and second", "different completion");
        eq(incompatible.content(), "first and second", "preserve visibly streamed divergent response");
        ok(incompatible.divergent(), "flag incompatible final response");

        ChatAnswerIntegrity.Resolved noStream = ChatAnswerIntegrity.reconcile("", "from final answer");
        eq(noStream.content(), "from final answer", "allow non-streamed valid completion");
        System.out.println("ChatAnswerIntegritySmoke: 6 scenarios passed");
    }
}
