#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
TEMP="$(mktemp -d)"
trap 'rm -rf "$TEMP"' EXIT
javac --release 17 -encoding UTF-8 -d "$TEMP" \
    "$ROOT/src/main/java/com/llmart/llm/service/AgentFocusedArtifactPolicy.java" \
    "$ROOT/qa/eliya86-focused-artifacts/FocusedArtifactSmoke.java"
java -cp "$TEMP" com.llmart.llm.service.FocusedArtifactSmoke
python3 - "$ROOT/src/main/java/com/llmart/llm/service/AgentService.java" <<'PY'
import sys
s=open(sys.argv[1], encoding='utf-8').read()
assert 'AgentFocusedArtifactPolicy.initialTools(request.message(), CORE_AGENT_TOOLS)' in s
assert 'request.attachmentIds() == null || request.attachmentIds().isEmpty()' in s, 'attachments must retain normal analysis' 
assert 'AgentFocusedArtifactPolicy.plan(task)' in s
assert s.index('AgentFocusedArtifactPolicy.plan(task)') < s.index('collectPlanningEvidence(ws, task, apiKey')
assert 'protectedSnapshots.begin(' in s, 'rollback baseline must not be bypassed'
assert 'cachedFinalPlanReview(' in s, 'verification still required'
print('PASS: focused plan skips only planner; rollback and verification remain intact')
PY
