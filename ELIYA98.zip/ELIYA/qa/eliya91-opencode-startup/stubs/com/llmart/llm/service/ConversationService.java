package com.llmart.llm.service;
import java.util.List;
public class ConversationService {
  public Object require(String id) {return id;}
  public Message addMessage(String conversationId, String role, String content, List<String> attachments) {return new Message();}
  public Object messageDto(Message message) {return message;}
  public static class Message { public Long getId() {return 1L;} }
}
