import com.llmart.llm.service.OpenCodeExecutionService;
import com.llmart.llm.service.ProjectService;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.nio.file.*;
import java.util.Map;
public class BootstrapFailureSmoke {
  public static void main(String[] args) throws Exception {
    Path dir=Files.createTempDirectory("eliya91-bootstrap-fail-");
    System.setProperty("eliya.opencode.sessionStore", dir.resolve("db").toString());
    Path fake=dir.resolve("opencode");
    Files.writeString(fake,"#!/bin/sh\nif [ \"$1\" = \"--version\" ]; then echo 'opencode v2.2.2'; exit 0; fi\nexit 23\n");
    fake.toFile().setExecutable(true);
    var service=new OpenCodeExecutionService(new ObjectMapper(),new ProjectService(),
      "opencode","http://127.0.0.1:4096","",fake.toString(),true);
    try {
      long t=System.nanoTime();
      Map<String,Object> result=service.engineInfo();
      long ms=(System.nanoTime()-t)/1_000_000;
      if (!Boolean.FALSE.equals(result.get("connected"))) throw new AssertionError(result);
      if (!String.valueOf(result.get("reason")).contains("code 23")) throw new AssertionError("Exit code missing: "+result);
      if (ms > 15_000) throw new AssertionError("Bootstrap failure hung for "+ms+" ms");
      System.out.println("PASS: OpenCode startup failure reported clearly in "+ms+"ms");
    } finally {service.shutdown();}
  }
}
