#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
D=$(mktemp -d); trap 'rm -rf "$D"' EXIT
mkdir -p "$D/org/springframework/stereotype" "$D/com/fasterxml/jackson/databind" "$D/com/llmart/llm/dto"
cat > "$D/org/springframework/stereotype/Service.java" <<'JAVA'
package org.springframework.stereotype;public @interface Service {}
JAVA
cat > "$D/com/llmart/llm/dto/ChatSettings.java" <<'JAVA'
package com.llmart.llm.dto;public class ChatSettings {
 public String baseUrl(){return "https://api.openai.com/v1";}public String chatModelOrPrimary(){return "model";}
 public int safeMaxTokens(){return 1024;}public double safeTemperature(){return 0.3;}
}
JAVA
cat > "$D/com/fasterxml/jackson/databind/JsonNode.java" <<'JAVA'
package com.fasterxml.jackson.databind;import java.util.*;
public class JsonNode implements Iterable<JsonNode> {
 private final Object v;
 public JsonNode(){this(null);}public JsonNode(Object v){this.v=v;}
 public JsonNode path(String k){return v instanceof Map<?,?> m&&m.containsKey(k)?new JsonNode(m.get(k)):new JsonNode();}
 public JsonNode get(int i){return v instanceof List<?> l&&i>=0&&i<l.size()?new JsonNode(l.get(i)):new JsonNode();}
 public JsonNode get(String n){return path(n);}
 public boolean isArray(){return v instanceof List<?>;}public boolean isEmpty(){return size()==0;}
 public int size(){return v instanceof List<?> l?l.size():v instanceof Map<?,?> m?m.size():0;}
 public boolean isObject(){return v instanceof Map<?,?>;}public boolean isNull(){return v==null;}
 public boolean isMissingNode(){return v==null;}public boolean isTextual(){return v instanceof String;}
 public boolean isNumber(){return v instanceof Number;}public double asDouble(double d){return v instanceof Number n?n.doubleValue():d;}
 public int asInt(int d){return v instanceof Number n?n.intValue():d;}public int asInt(){return asInt(0);}
 public long asLong(long d){return v instanceof Number n?n.longValue():d;}
 public String asText(){return asText("");}public String asText(String d){return v instanceof String s?s:d;}
 public Iterator<JsonNode> iterator(){return v instanceof List<?> l?l.stream().map(JsonNode::new).iterator():Collections.emptyIterator();}
}
JAVA
cat > "$D/com/fasterxml/jackson/databind/ObjectMapper.java" <<'JAVA'
package com.fasterxml.jackson.databind;
import java.util.*;
public class ObjectMapper {
 public JsonNode readTree(String t){return new JsonNode(new P(t).read());}
 public JsonNode createObjectNode(){return new JsonNode(Map.of());}
 public String writeValueAsString(Object o){return String.valueOf(o);}
 static final class P {
  final String s;int p;P(String s){this.s=s;}
  void ws(){while(p<s.length()&&Character.isWhitespace(s.charAt(p)))p++;}
  Object read(){ws();if(p>=s.length())throw new IllegalArgumentException("Unexpected EOF");char c=s.charAt(p);
   if(c=='{'){p++;Map<String,Object> m=new LinkedHashMap<>();ws();if(s.charAt(p)=='}'){p++;return m;}do{ws();String key=(String)read();ws();if(s.charAt(p++)!=':')throw new IllegalArgumentException("Expected colon");m.put(key,read());ws();c=s.charAt(p++);}while(c==',');if(c!='}')throw new IllegalArgumentException("Expected }");return m;}
   if(c=='['){p++;List<Object> a=new ArrayList<>();ws();if(s.charAt(p)==']'){p++;return a;}do{a.add(read());ws();c=s.charAt(p++);}while(c==',');if(c!=']')throw new IllegalArgumentException("Expected ]");return a;}
   if(c=='"'){p++;StringBuilder b=new StringBuilder();while(p<s.length()){c=s.charAt(p++);if(c=='"')return b.toString();if(c=='\\'){char n=s.charAt(p++);switch(n){case 'n'->b.append('\n');case 't'->b.append('\t');case 'r'->b.append('\r');case '"'->b.append('"');case '\\'->b.append('\\');default->b.append(n);}}else b.append(c);}throw new IllegalArgumentException("Unclosed string");}
   int start=p;while(p<s.length()&&!Character.isWhitespace(s.charAt(p))&&",]}".indexOf(s.charAt(p))<0)p++;String word=s.substring(start,p);
   return switch(word){case "null"->null;case "true"->true;case "false"->false;default->Long.parseLong(word);};
  }
 }
}
JAVA
javac --release 17 -d "$D/out" \
 "$D/org/springframework/stereotype/Service.java" "$D/com/llmart/llm/dto/ChatSettings.java" \
 "$D/com/fasterxml/jackson/databind/JsonNode.java" "$D/com/fasterxml/jackson/databind/ObjectMapper.java" \
 src/main/java/com/llmart/llm/service/AgentCancelledException.java \
 src/main/java/com/llmart/llm/service/ChatAnswerContinuation.java \
 src/main/java/com/llmart/llm/service/AgentPromptCachePolicy.java \
 src/main/java/com/llmart/llm/service/AgentRetrievalScopePolicy.java \
 src/main/java/com/llmart/llm/service/AgentStreamDecoder.java \
 src/main/java/com/llmart/llm/service/OpenAiCompatibleClient.java
cat > "$D/Smoke.java" <<'JAVA'
import java.lang.reflect.*;
class Smoke {
 public static void main(String[] args) throws Exception {
  Class<?> c=Class.forName("com.llmart.llm.service.AgentPromptCachePolicy");
  var supports=c.getDeclaredMethod("supportsKey",String.class);supports.setAccessible(true);
  if(!(boolean)supports.invoke(null,"https://api.openai.com/v1"))throw new AssertionError();
  if((boolean)supports.invoke(null,"https://api.openai.com.evil.example/v1"))throw new AssertionError();
  var affinity=c.getDeclaredMethod("affinity",String.class,String.class);affinity.setAccessible(true);
  String a=(String)affinity.invoke(null,"secret user path","qwen");
  if(a.contains("secret")||a.length()<20)throw new AssertionError();
  var policy=Class.forName("com.llmart.llm.service.AgentRetrievalScopePolicy");
  var skip=policy.getDeclaredMethod("skipAutomaticExploration",String.class);skip.setAccessible(true);
  if(!(boolean)skip.invoke(null,"Do not explore the workspace"))throw new AssertionError("Workspace restriction ignored");
  if((boolean)skip.invoke(null,"Explain the codebase flow"))throw new AssertionError("Ordinary retrieval disabled");
  System.out.println("PASS Java 17 isolated compile + stable cache affinity and retrieval scope");
 }
}
JAVA
javac --release 17 -cp "$D/out" -d "$D/out" "$D/Smoke.java"
java -cp "$D/out" Smoke
cat > "$D/SmokeStream.java" <<'JAVA'
package com.llmart.llm.service;
import com.fasterxml.jackson.databind.ObjectMapper;import java.util.*;
public class SmokeStream {
 public static void main(String[] args)throws Exception{
  var outputs=new ArrayList<String>();var d=new AgentStreamDecoder(new ObjectMapper(),outputs::add);
  d.accept("{\"choices\":[{\"delta\":{\"content\":\"progress\"},\"finish_reason\":null}]}");
  d.accept("{\"choices\":[{\"delta\":{\"tool_calls\":[{\"index\":0,\"id\":\"call_1\",\"function\":{\"name\":\"read\",\"arguments\":\"{\\\"pa\"}}]},\"finish_reason\":null}]}");
  d.accept("{\"choices\":[{\"delta\":{\"tool_calls\":[{\"index\":0,\"function\":{\"arguments\":\"th\\\":\\\"README.md\\\"}\"}}]},\"finish_reason\":null}]}");
  d.accept("{\"choices\":[{\"delta\":{},\"finish_reason\":\"tool_calls\"}]}");
  d.accept("{\"choices\":[],\"usage\":{\"prompt_tokens\":100}}");d.accept("[DONE]");
  if(!d.hasResult()||!"progress".equals(d.content())||outputs.size()!=1)throw new AssertionError("Stream content");
  if(!"read".equals(d.toolCalls().get(0).name())||!"README.md".equals(d.toolCalls().get(0).arguments().path("path").asText()))throw new AssertionError("Bad tool fragments");
  if(d.usage().path("prompt_tokens").asInt()!=100)throw new AssertionError("Usage frame lost");
  var partial=new AgentStreamDecoder(new ObjectMapper(),null);partial.accept("{\"choices\":[{\"delta\":{\"content\":\"partial\"},\"finish_reason\":null}]}");
  if(partial.hasResult())throw new AssertionError("Incomplete stream accepted");
  System.out.println("PASS fragmented streamed tool calls, progress, provider usage and incomplete stream guard");
 }
}
JAVA
javac --release 17 -cp "$D/out" -d "$D/out" "$D/SmokeStream.java"
java -cp "$D/out" com.llmart.llm.service.SmokeStream
