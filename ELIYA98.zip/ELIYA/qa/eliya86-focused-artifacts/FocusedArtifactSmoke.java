package com.llmart.llm.service;

import java.util.Set;

public class FocusedArtifactSmoke {
    private static int assertions;
    static void check(boolean b, String reason) {
        if (!b) throw new AssertionError(reason);
        assertions++;
    }
    public static void main(String[] args) {
        String request = "can you create .opencode folder and add 2 folders inside that is .agents and .skills. " +
                "can you add single class one responsibility skill one-class-one-responsibility.md and " +
                "add code-reviewer.md agent in .agents folder to refer appropriate skills from the .skills folder";
        check(AgentFocusedArtifactPolicy.eligible(request), "small two-file request should be focused");
        check(AgentFocusedArtifactPolicy.plan(request).size() == 2, "create + verify plan");
        check(AgentFocusedArtifactPolicy.plan(request).get(0).contains("code-reviewer.md"), "literal named files preserved");
        check(AgentFocusedArtifactPolicy.plan(request).get(1).contains("cross-file references"), "verification kept");
        Set<String> original = Set.of("read", "write", "tool_search", "work_items_discover", "documentation_inventory", "todo_update", "workspace_status");
        Set<String> selected = AgentFocusedArtifactPolicy.initialTools(request, original);
        check(selected.containsAll(Set.of("read", "write", "tool_search", "todo_update", "workspace_status")), "essential tools kept");
        check(!selected.contains("work_items_discover") && !selected.contains("documentation_inventory"), "unrelated schemas dropped");
        check(original.size() > selected.size(), "actual palette savings");
        check(!AgentFocusedArtifactPolicy.eligible("Migrate the whole project and create a status.md"), "broad task excluded");
        check(!AgentFocusedArtifactPolicy.eligible("Analyse code and create review.md"), "analysis task excluded");
        check(!AgentFocusedArtifactPolicy.eligible("Create App.java and update changelog.md"), "source edit excluded");
        check(!AgentFocusedArtifactPolicy.eligible("Create docs from Jira MCP in notes.md"), "MCP excluded");
        check(!AgentFocusedArtifactPolicy.eligible("Create summary.md from uploaded attachment"), "document attachment excluded");
        check(!AgentFocusedArtifactPolicy.eligible("Explain code-reviewer.md"), "explanation excluded");
        check(!AgentFocusedArtifactPolicy.eligible("Create docs using @legacy in summary.md"), "reference workspace excluded");
        check(AgentFocusedArtifactPolicy.initialTools("Migrate the whole project and create status.md", original).equals(original), "normal tool palette unchanged");
        System.setProperty("eliya.tokens.focusedArtifacts.enabled", "false");
        check(!AgentFocusedArtifactPolicy.eligible(request), "feature flag opt-out");
        System.clearProperty("eliya.tokens.focusedArtifacts.enabled");
        System.out.println("PASS: " + assertions + " focused artifact safety and token-economy checks");
    }
}
