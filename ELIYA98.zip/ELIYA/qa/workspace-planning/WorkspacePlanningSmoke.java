package com.llmart.llm.service;

import java.nio.file.Files;
import java.nio.file.Path;

/** Dependency-free Java 17 regression suite for path scoping and planning JSON extraction. */
public final class WorkspacePlanningSmoke {
    private static void check(boolean condition, String description) {
        if (!condition) throw new AssertionError(description);
    }
    private static void reject(Runnable action, String description) {
        try { action.run(); }
        catch (SecurityException | IllegalArgumentException expected) { return; }
        throw new AssertionError(description);
    }
    public static void main(String[] args) throws Exception {
        Path home = Files.createTempDirectory("eliya-selected-workspace-");
        Path selected = home.resolve("selected");
        Path different = home.resolve("other");
        Files.createDirectories(selected.resolve("frontend"));
        Files.createDirectories(different);
        try {
            // Once selected in the UI, path mentions cannot silently remap the agent root.
            check(!AgentWorkspaceSelection.canInferFromPrompt("selected-id"), "prompt path overrides selected UI workspace");
            check(AgentWorkspaceSelection.canInferFromPrompt(null), "no-workspace prompt mapping disabled");
            check(AgentWorkspaceSelection.canInferFromPrompt("  "), "blank workspace mapping disabled");
            check(WorkspaceCommandPaths.resolve(selected, null).equals(selected), "empty cwd changed workspace");
            check(WorkspaceCommandPaths.resolve(selected, ".").equals(selected), "dot cwd changed workspace");
            check(WorkspaceCommandPaths.resolve(selected, "frontend").equals(selected.resolve("frontend")), "relative cwd mismatch");
            check(WorkspaceCommandPaths.resolve(selected, "frontend\\").equals(selected.resolve("frontend")), "backslash cwd compatibility lost");
            check(WorkspaceCommandPaths.resolve(selected, selected.resolve("frontend").toString())
                    .equals(selected.resolve("frontend")), "absolute in-workspace cwd rejected");
            reject(() -> WorkspaceCommandPaths.resolve(selected, different.toString()), "other-workspace cwd allowed");
            reject(() -> WorkspaceCommandPaths.resolve(selected, "../other"), "parent traversal allowed");
            reject(() -> WorkspaceCommandPaths.resolve(selected, "missing"), "nonexistent cwd allowed");
            reject(() -> WorkspaceCommandPaths.resolve(selected, "C:\\Windows\\Temp"), "Windows drive path interpreted as relative");
            reject(() -> WorkspaceCommandPaths.resolve(selected, "\0bad"), "NUL cwd allowed");
            try {
                Files.createSymbolicLink(selected.resolve("alias"), different);
                reject(() -> WorkspaceCommandPaths.resolve(selected, "alias"), "symlink cwd escape allowed");
            } catch (UnsupportedOperationException | java.nio.file.FileSystemException ignored) {
                // Symlinks can be disabled on corporate Windows; the rest of the tests still run.
            }

            String objectJson = "```json\n{\"plan\":[{\"title\":\"Inspect\"}]}\n```";
            String rawArray = "[{\"title\":\"Inspect\"},{\"title\":\"Verify\"}]";
            String explainedObject = "Here is your plan:\n{\"plan\":[{\"title\":\"Inspect\"}]}";
            check(AgentPlanJsonEnvelope.extract(objectJson).startsWith("{\"plan\""), "fenced JSON rejected");
            check(AgentPlanJsonEnvelope.extract(rawArray).equals(rawArray), "bare JSON array lost its root");
            check(AgentPlanJsonEnvelope.extract(explainedObject).startsWith("{\"plan\""), "prose wrapper not removed");
            check(AgentPlanJsonEnvelope.extract("not-json").equals("not-json"), "plain text plan changed");
            check(AgentPlanStructure.isLastStepVerification("Verify changed classes with focused tests\nValidate: tests pass"),
                    "final verification contract regressed");
            check(!AgentPlanStructure.hasValidationEvidence("Edit files without test evidence"),
                    "unverified plan accepted");
            System.out.println("PASS: selected workspace stable, command cwd scoped, symlinks/traversal rejected, plan JSON envelopes, validation contract");
        } finally {
            try (var walk = Files.walk(home)) {
                for (Path path : walk.sorted(java.util.Comparator.reverseOrder()).toList()) Files.deleteIfExists(path);
            }
        }
    }
}
