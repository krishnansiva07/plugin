#!/usr/bin/env bash
set -euo pipefail
BASE="$(cd "$(dirname "$0")/../.." && pwd)"
OUT="$(mktemp -d)"
trap 'rm -rf "$OUT"' EXIT
javac --release 17 -encoding UTF-8 -d "$OUT" \
  "$BASE/src/main/java/com/llmart/llm/service/AgentWorkspaceSelection.java" \
  "$BASE/src/main/java/com/llmart/llm/service/WorkspaceCommandPaths.java" \
  "$BASE/src/main/java/com/llmart/llm/service/AgentPlanJsonEnvelope.java" \
  "$BASE/src/main/java/com/llmart/llm/service/AgentPlanStructure.java" \
  "$BASE/qa/workspace-planning/WorkspacePlanningSmoke.java"
java -cp "$OUT" com.llmart.llm.service.WorkspacePlanningSmoke
