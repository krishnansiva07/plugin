#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../.."
node --check src/main/resources/static/app.js
node --check src/main/resources/static/unified-routing.js
node --check src/main/resources/static/conversation-intelligence.js
node qa/eliya80-conversational-intelligence/conversation.cjs
python3 qa/eliya80-conversational-intelligence/browser.py
bash qa/eliya52-terminal-typecheck.sh
bash qa/eliya79-analyse-execute/run.sh
