"""Chromium acceptance: one conversational UI + modes and followups in Terminal."""
import asyncio,re
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parents[2]/'src/main/resources/static'
OUT=Path('/mnt/data/eliya80_preview');OUT.mkdir(exist_ok=True)
async def main():
 async with async_playwright() as pw:
  browser=await pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
  for width in (1440,390):
   page=await browser.new_page(viewport={'width':width,'height':850})
   errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
   html=re.sub(r'<script src="[^"]+"></script>','',(ROOT/'index.html').read_text())
   html=re.sub(r'<link rel="stylesheet"[^>]+>','',html)
   await page.set_content(html)
   await page.add_style_tag(content=(ROOT/'app.css').read_text())
   await page.evaluate('''() => {window.__sent=[];window.fetch=async(url,opts={})=>{
     const path=String(url);if(path.includes('/api/chat/stream')){
       const request=JSON.parse(opts.body);window.__sent.push(request);
       const reply={role:'assistant',id:'reply-'+window.__sent.length,
         content:'## Workspace findings\\n\\nJava Selenium TestNG framework, Maven modules and shared components. This is an illustrative test response with references: `pom.xml` and `src/test/java`.'};
       return new Response('event: done\\ndata: '+JSON.stringify(reply)+'\\n\\n',{headers:{'Content-Type':'text/event-stream'}});
     }
     if(path.includes('/api/terminal/workspaces'))return new Response(JSON.stringify([{id:'w1',name:'Repo',localPath:'/tmp/eliya'}]),{headers:{'Content-Type':'application/json'}});
     if(path.includes('/api/terminal/sessions')&&opts.method==='POST'){
        window.__sent.push(JSON.parse(opts.body));return new Response(JSON.stringify({id:'t1',status:'running',projectId:'w1',queue:[]}),{headers:{'Content-Type':'application/json'}});
     }
     if(path.includes('/api/terminal/sessions'))return new Response(JSON.stringify([]),{headers:{'Content-Type':'application/json'}});
     return new Response(JSON.stringify([]),{headers:{'Content-Type':'application/json'}});
   };}''')
   for name in ['markdown.js','prompt-catalog.js','unified-routing.js','conversation-intelligence.js','app.js','confluence-composer.js']:
    await page.add_script_tag(content=(ROOT/name).read_text())
   await page.evaluate('''() => {state.config.apiKey='test';state.config.baseUrl='http://localhost';state.config.model='agent';
     state.config.chatModel='chat';state.conversationId='conv-main';state.project={id:'w1',name:'Repo',localWorkspace:true};state.messages=[];updateModeUi();}''')
   assert await page.locator('[data-workflow="analyse"]').get_attribute('aria-pressed')=='true'
   await page.locator('#messageInput').fill('Can you analyse my workspace?')
   await page.locator('#sendBtn').click();await page.wait_for_function('()=>!state.streaming && window.__sent.length>0')
   assert await page.evaluate('window.__sent[0].mode')=='chat'
   assert await page.locator('.eliya-next-question').count()==1
   await page.locator('#messageInput').fill('Yes')
   await page.locator('#sendBtn').click();await page.wait_for_function('()=>!state.streaming && window.__sent.length>1')
   assert await page.evaluate('window.__sent[1].mode')=='chat'
   assert 'workspace architecture' in (await page.evaluate('window.__sent[1].message')).lower()
   await page.locator('#messageInput').fill('Implement the improvements we discussed')
   await page.locator('#sendBtn').click();await page.wait_for_function('()=>!state.streaming && window.__sent.length>2')
   assert await page.evaluate('window.__sent[2].mode')=='agent'
   await page.screenshot(path=str(OUT/f'main_{width}.png'))
   # Terminal has independent tabs but identical Analyse/Execute mode semantics.
   assert await page.locator('[data-terminal-workflow]').count()==2
   await page.locator('#launchTerminalBtn').click()
   assert await page.locator('#terminalModes').is_visible()
   assert await page.locator('[data-terminal-workflow="analyse"]').get_attribute('aria-pressed')=='true'
   await page.locator('[data-terminal-workflow="execute"]').click()
   assert await page.locator('[data-terminal-workflow="execute"]').get_attribute('aria-pressed')=='true'
   await page.locator('[data-terminal-workflow="analyse"]').click()
   assert await page.locator('[data-terminal-workflow="analyse"]').get_attribute('aria-pressed')=='true'
   assert await page.evaluate("terminalPayload('Explain the framework').mode")=='chat'
   await page.locator('[data-terminal-workflow="execute"]').click()
   assert await page.evaluate("terminalPayload('Create a skill').mode")=='agent'
   await page.locator('[data-terminal-workflow="analyse"]').click()
   assert await page.evaluate('document.documentElement.scrollWidth<=window.innerWidth+2')
   assert not errors,errors
   await page.screenshot(path=str(OUT/f'conversational_{width}.png'))
   await page.close()
  await browser.close()
 print('PASS ELIYA80: desktop/mobile answers, contextual follow-up, Analyse->Execute, Terminal mode UI')
asyncio.run(main())
