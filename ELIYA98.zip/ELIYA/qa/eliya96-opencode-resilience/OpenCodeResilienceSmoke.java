import com.llmart.llm.service.OpenCodeExecutionService;
import com.llmart.llm.service.ProjectService;
import com.llmart.llm.dto.ChatMode;
import com.llmart.llm.dto.ChatRequest;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.lang.reflect.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;

/** Exercises a real HTTP loopback adapter without an installed model or modifying a user's code. */
public class OpenCodeResilienceSmoke {
  static void ok(boolean b, String msg){ if(!b)throw new AssertionError(msg); }
  static void answer(HttpExchange x,int status,String json) throws java.io.IOException {
    byte[] bytes=json.getBytes(StandardCharsets.UTF_8);
    x.getResponseHeaders().set("Content-Type","application/json");
    x.sendResponseHeaders(status,bytes.length);
    try(var out=x.getResponseBody()) {out.write(bytes);}
  }
  public static void main(String[] args) throws Exception {
    Path store=Files.createTempDirectory("eliya96-oc-smoke-");
    System.setProperty("eliya.opencode.sessionStore", store.toString());
    Path workspace = Files.createTempDirectory("eliya96-workspace-");
    Files.createDirectories(workspace.resolve("demo"));
    Files.writeString(workspace.resolve("demo/README.md"), "Hello\n");
    System.setProperty("eliya.qa.workspace", workspace.toString());
    System.setProperty("eliya.opencode.stallSeconds", "20");
    AtomicBoolean active=new AtomicBoolean(true);
    AtomicBoolean toolsPresent=new AtomicBoolean(false);
    AtomicInteger polling=new AtomicInteger(0);
    HttpServer http=HttpServer.create(new InetSocketAddress("127.0.0.1",0),0);
    String auth="Basic "+Base64.getEncoder().encodeToString("opencode:secret-123456789012345".getBytes(StandardCharsets.UTF_8));
    http.createContext("/api/",ex->{
      try {
        ok(auth.equals(ex.getRequestHeaders().getFirst("Authorization")),"auth failed");
        String path=ex.getRequestURI().getPath();
        if(path.equals("/api/info")) answer(ex,200,"{\"data\":{\"version\":\"2.1.0\"}}");
        else if(path.equals("/api/model/default")) answer(ex,200,"{\"data\":{\"id\":\"model-ready\"}}");
        else if(path.equals("/api/session")) answer(ex,200,"{\"data\":{\"id\":\"ses_eliya96\"}}");
        else if(path.endsWith("/prompt")) answer(ex,200,"{\"data\":{\"id\":\"usr_task96\"}}");
        else if(path.equals("/api/session/active")) {
          polling.incrementAndGet();
          answer(ex,200,active.get()?"{\"data\":{\"ses_eliya96\":{\"status\":\"busy\"}}}":"{\"data\":{}}");
        } else if(path.endsWith("/log")) answer(ex,404,"{\"error\":\"experimental log disabled\"}");
        else if(path.endsWith("/message")) {
          String parts=toolsPresent.get() ? "{\"type\":\"tool\",\"id\":\"tool_96\",\"name\":\"write\",\"state\":{\"status\":\"completed\",\"title\":\"Wrote demo file\"}}," : "";
          answer(ex,200,"{\"data\":[{\"id\":\"asst_96\",\"type\":\"assistant\",\"content\":["+parts+"{\"type\":\"text\",\"text\":\"Finished requested task\"}]},{\"id\":\"usr_task96\",\"type\":\"user\",\"text\":\"Implement demo\"}]}");
        } else if(path.endsWith("/diff")) answer(ex,200,"{\"data\":[{\"file\":\"demo/README.md\",\"status\":\"added\",\"additions\":2,\"deletions\":0,\"patch\":\"+Hello\\n\"}]}");
        else if(path.endsWith("/interrupt")) answer(ex,200,"{\"interrupted\":true}");
        else answer(ex,404,"{}");
      }catch(Throwable error){error.printStackTrace();try{answer(ex,500,"{}");}catch(Exception ignored){}}
    });
    ExecutorService pool=Executors.newCachedThreadPool(r->{Thread t=new Thread(r,"eliya96-mock");t.setDaemon(true);return t;});
    http.setExecutor(pool);http.start();
    OpenCodeExecutionService service=null;
    try{
      service=new OpenCodeExecutionService(new ObjectMapper(),new ProjectService(),"opencode",
          "http://127.0.0.1:"+http.getAddress().getPort(),"secret-123456789012345","opencode",false);
      var request=new ChatRequest("proj1","Create a demo README",List.of(),ChatMode.AGENT,
          new ChatRequest.Settings("test-model"));
      String id=String.valueOf(service.launch(request,null).get("id"));
      var field=OpenCodeExecutionService.class.getDeclaredField("sessions");field.setAccessible(true);
      var map=(Map<?,?>)field.get(service);
      Object run=map.get(id);
      var last=run.getClass().getDeclaredField("lastActivityNanos");last.setAccessible(true);
      last.setLong(run,System.nanoTime()-TimeUnit.SECONDS.toNanos(70));
      Thread.sleep(7500); // multiple state polls and recovery attempts (SSE returns 404)
      ok("running".equals(service.get(id).get("status")),"ACTIVE OpenCode run was incorrectly stalled");
      ok(polling.get()>0,"did not monitor active state");
      ok(!Boolean.TRUE.equals(((Map<?,?>)service.get(id).get("progress")).get("estimated")),"heartbeats must not invent percentage");
      System.out.println("PASS: quiet ACTIVE remote session remains running and percentage unknown");
      toolsPresent.set(true);
      last.setLong(run,System.nanoTime()-TimeUnit.SECONDS.toNanos(10));
      Thread.sleep(6000);
      var progress=(Map<?,?>)service.get(id).get("progress");
      ok(((Number)progress.get("observedActions")).intValue() >= 1,"tool history not recovered while active");
      System.out.println("PASS: projected tool history recovers missing SSE actions");
      active.set(false);
      boolean completed=false;
      for(int i=0;i<8;i++){Thread.sleep(1800);if("completed".equals(service.get(id).get("status"))){completed=true;break;}}
      ok(completed,"idle + corresponding assistant answer not completed");
      var snapshot=service.get(id);
      var report=(Map<?,?>)snapshot.get("changeReport");
      ok(Boolean.TRUE.equals(report.get("filesVerified")),"diff evidence not fetched");
      ok(((Number)report.get("created")).intValue()==1,"created file not counted");
      ok(((List<?>)report.get("steps")).size()>0,"tool evidence not included in report");
      ok(((Number)snapshot.get("progressPercent")).intValue()==100,"confirmed completion not 100%");
      ok(((Number)snapshot.get("elapsedMs")).longValue()>=13000,"final elapsed duration missing");
      ok(Boolean.TRUE.equals(service.engineInfo().get("autoEligible")),"OpenCode completion not proven for Auto");
      System.out.println("PASS: idle + attributable answer -> completed; file diff and observed tools in report; Auto eligible");
      service.shutdown();
    } finally {if(service!=null)service.shutdown();http.stop(0);pool.shutdownNow();}
  }
}
