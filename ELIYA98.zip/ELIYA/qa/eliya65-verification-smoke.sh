#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
TMP=$(mktemp -d)
trap 'rm -rf "$TMP"' EXIT
mkdir -p "$TMP/classes"
cat > "$TMP/VerificationSmoke.java" <<'JAVA'
import com.llmart.llm.service.AgentVerificationPolicy;
public class VerificationSmoke {
  static void expect(boolean actual, boolean wanted, String scenario) {
    if (actual != wanted) throw new AssertionError(scenario+": expected "+wanted+" but got "+actual);
  }
  public static void main(String[] args) {
    var valid = AgentVerificationPolicy.checkShell("bash", "git status", "exitCode=0; working tree clean", true);
    expect(valid.passed(), true, "read-only verifier");
    expect(AgentVerificationPolicy.checkShell("bash", "mvn test", "exitCode=1; BUILD FAILURE", false).passed(), false, "failure exit code");
    expect(AgentVerificationPolicy.checkShell("bash", "find . -type f || cmd /c dir", "exitCode=0; files", true).passed(), false, "masked fallback");
    expect(AgentVerificationPolicy.checkShell("bash", "mvn test || true", "exitCode=0; BUILD FAILURE", false).passed(), false, "suppressed test failure");
    expect(AgentVerificationPolicy.checkShell("bash", "mkdir -p .opencode/agents", "exitCode=0;", true).passed(), false, "Unix mkdir used by cmd");
    expect(AgentVerificationPolicy.checkShell("bash", "echo hi", "exitCode=0; 'find' is not recognized as an internal or external command", true).passed(), false, "masked shell output");
    expect(AgentVerificationPolicy.checkShell("build", "", "exitCode=0; BUILD SUCCESS", true).passed(), true, "real successful build");
    expect(AgentVerificationPolicy.isShellTool("write"),false,"write is not shell");
    expect(AgentVerificationPolicy.isShellTool("resource_bash"),true,"resource shell");
    System.out.println("PASS: command fail-closed policy / Windows shell / independent exit result (9 scenarios)");
  }
}
JAVA
javac --release 17 -d "$TMP/classes" src/main/java/com/llmart/llm/service/AgentVerificationPolicy.java "$TMP/VerificationSmoke.java"
java -cp "$TMP/classes" VerificationSmoke
python - <<'PY'
from pathlib import Path
s=Path('src/main/java/com/llmart/llm/service/AgentService.java').read_text()
for contract in [
 'cachedFinalPlanReview(apiKey, request, ws, run, step, onStep, finalOutcomeReviews)',
 'APPROVED PLAN AND COMPLETION NOTES:',
 'ACTUAL CHANGED FILES:',
 'ACTUAL CHANGE EVIDENCE (prior/new content):',
 'INDEPENDENT VERIFIER RESULT:',
 'if (run.documentationMode())',
 'pruneHistoricalWriteArguments(messages)',
 'Do not resend the complete workspace',
 'verificationShellPolicy(tool, args, result)',
 'finalOutcomeApprovedRevision != run.mutationRevision()',
]:
 assert contract in s, contract
assert s.count('finalOutcomeApprovedRevision != run.mutationRevision()') >= 3
assert 'all file contents from workspace' not in s
print('PASS: final outcome gate, all finish paths, bounded code evidence, documentation priority, historical args')
PY
