package com.llmart.llm.service;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

public class RepositoryGuidanceSmoke {
    private static void check(boolean ok, String label) {
        if (!ok) throw new AssertionError(label);
    }
    public static void main(String[] args) throws Exception {
        String text = Files.readString(Path.of(args[0]));
        int p1 = text.indexOf("PROMPT 1 — ");
        int p2 = text.indexOf("PROMPT 2 — ");
        int p3 = text.indexOf("PROMPT 3 — ");
        int p4 = text.indexOf("PROMPT 4 — ");
        check(p1 >= 0 && p2 > p1 && p3 > p2 && p4 > p3, "Four source prompts missing");
        String legacy = text.substring(p1, p2);
        String playwright = text.substring(p2, p3);
        String strategy = text.substring(p3, p4);
        String migration = text.substring(p4);
        check(AgentPlanRelevance.isRepositoryGuidanceRequest(legacy), "Prompt 1 incorrectly classified");
        check(AgentPlanRelevance.isRepositoryGuidanceRequest(playwright), "Prompt 2 incorrectly classified");
        check(AgentPlanRelevance.isRepositoryGuidanceRequest(strategy), "Prompt 3 incorrectly classified");
        check(!AgentPlanRelevance.isRepositoryGuidanceRequest(migration), "Prompt 4 migration misclassified");
        check(AgentPlanRelevance.requestedGuidanceArtifacts(legacy).equals(List.of(
                "migration/legacy/agents.md", "migration/legacy/skills.md", "migration/legacy/source_map.md")),
                "Prompt 1 deliverables must be exact, excluding references");
        check(AgentPlanRelevance.requestedGuidanceArtifacts(playwright).equals(List.of(
                "agents.md", "skills.md", "migration/target/target_map.md")),
                "Prompt 2 deliverables must be exact, excluding references");
        check(AgentPlanRelevance.requestedGuidanceArtifacts(strategy).equals(List.of(
                "migration/migration.md", "migration/migration-ledger.csv",
                "migration/shared-component-registry.md", "migration/package_runbook.md")),
                "Prompt 3 deliverables must be exact, excluding inputs");
        List<String> valid = List.of(
                "Inspect configured legacy source and verify workspace target mappings.\nValidate: read only registered roots",
                "Create migration/legacy/AGENTS.md, SKILLS.md and SOURCE_MAP.md in workspace.\nValidate: three requested files exist",
                "Final verify generated AGENTS.md SKILLS.md SOURCE_MAP.md against legacy evidence and workspace boundaries.\nValidate: no source writes");
        check(AgentPlanRelevance.validate(legacy,"repository_guidance",valid).isBlank(), "Valid bounded guidance plan rejected");
        List<String> missing = List.of(
                "Read legacy and workspace paths\nValidate: confirmed",
                "Create AGENTS.md and SKILLS.md\nValidate: done",
                "Final verify AGENTS.md and SKILLS.md\nValidate: checked");
        check(AgentPlanRelevance.validate(legacy,"repository_guidance",missing).contains("source_map.md"),
                "Missing requested SOURCE_MAP must be rejected");
        check(!AgentPlanRelevance.validate(legacy,"repository_guidance",List.of(
                "documentation_inventory entire repository\nValidate: checked",
                "write AGENTS.md, SKILLS.md, SOURCE_MAP.md in workspace\nValidate: created",
                "documentation_validate\nValidate: passed")).isBlank(), "Full documentation route wrongly accepted");
        check(!AgentPlanRelevance.isRepositoryGuidanceRequest("Migrate the selected tests. Read AGENTS.md SKILLS.md MIGRATION.md"),
                "Plain migration must not become guidance task");
        check(AgentPlanRelevance.isRepositoryGuidanceRequest("Create AGENTS.md for a repository"),
                "Short direct create request should work");
        check(!AgentPlanRelevance.isRepositoryGuidanceRequest("Read AGENTS.md and then fix authentication"),
                "Read-only references must not count as deliverables");
        check(AgentPlanRelevance.validate("Document full codebase", "documentation", List.of(
                "Read repository\nValidate: inventoried", "Review output\nValidate: checked"))
                .contains("documentation_inventory"), "True full documentation protection lost");
        // Catch wiring regressions: correct classification must run before broad docs mode.
        String agent = Files.readString(Path.of(args[1]));
        int special = agent.indexOf("if (AgentPlanRelevance.isRepositoryGuidanceRequest(task))");
        int broadDocs = agent.indexOf("if (isDocumentationTask(task))", special);
        check(special > 0 && broadDocs > special, "AgentService routing must check guidance before broad documentation");
        check(agent.contains("new TaskProfile(\"repository_guidance\", 3, 8, false"),
                "Guidance must not activate the broad documentation/large-task executor");
        System.out.println("PASS: real four-prompt classification, routing priority, exact deliverables, missing-file rejection, full-documentation guard");
    }
}
