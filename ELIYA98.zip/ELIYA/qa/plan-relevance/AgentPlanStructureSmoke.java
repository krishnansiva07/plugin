package com.llmart.llm.service;

public class AgentPlanStructureSmoke {
    private static void check(boolean ok, String why) { if (!ok) throw new AssertionError(why); }
    public static void main(String[] args) {
        String implementation = "Migrate only selected Autowero_Consumer.feature tests to existing Playwright project\\nValidate: changed files are reviewed".replace("\\n", "\n");
        String simpleFinal = "Run Playwright type-check and selected feature tests\\nChecks: test run results and scenario parity".replace("\\n", "\n");
        check(AgentPlanStructure.hasValidationEvidence(simpleFinal), "Equivalent Checks label rejected");
        check(AgentPlanStructure.isLastStepVerification(simpleFinal), "Legitimate final step rejected without explicit word final");
        check(!AgentPlanStructure.isLastStepVerification(implementation), "Mutation step incorrectly treated as final verification");
        check(!AgentPlanStructure.isLastStepVerification("Implement feature and validate result\\nValidate: check files".replace("\\n", "\n")),
                "Implementation plus validate must not skip the final verification gate");
        check(!AgentPlanStructure.isLastStepVerification("Generate final report\\nValidate: report exists".replace("\\n", "\n")),
                "Ordinary per-step Validate must not imply task verification");
        String normalized = AgentPlanStructure.normalizeValidationLabel(simpleFinal);
        check(normalized.contains("Validate: test run results"), "Equivalent check label not normalized");
        check(AgentPlanStructure.hasValidationEvidence(normalized), "Normalized evidence missing");
        check(!AgentPlanStructure.hasValidationEvidence("Inspect source files\\nValidate: ".replace("\\n", "\n")),
                "Empty Validate placeholder incorrectly passed");
        check(!AgentPlanStructure.hasValidationEvidence("Inspect sources\nValidate:\nNew plan step".replace("\n", "\n")),
                "A blank evidence field must not consume the next line");
        check(AgentPlanStructure.isLastStepVerification("Ensure Selenium scenario coverage and Playwright parity\nValidate: coverage mapped".replace("\n", "\n")),
                "Ensure-style verification rejected");
        check(AgentPlanStructure.isLastStepVerification("Verify generated BRD against Jira evidence\\nValidate: issue traceability reviewed".replace("\\n", "\n")),
                "Document last step rejected");
        check(AgentPlanStructure.isLastStepVerification("Review UI to API tracing evidence\\nValidate: source path citations checked".replace("\\n", "\n")),
                "Read-only analysis last step rejected");
        check(AgentPlanStructure.isLastStepVerification("Compile and test the migrated Playwright project\\nValidate: compile and test evidence".replace("\\n", "\n")),
                "Type check last step rejected");
        check(!AgentPlanStructure.hasValidationEvidence("Analyze dependencies; verify references"),
                "Incidental verification word must not count as explicit evidence");
        System.out.println("PASS: explicit check evidence, semantic last-step verification, invalid-plan rejection, task categories");
    }
}
