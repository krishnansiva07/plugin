#!/usr/bin/env bash
set -euo pipefail
BASE="$(cd "$(dirname "$0")/../.." && pwd)"
TEMP="$(mktemp -d)"
trap 'rm -rf "$TEMP"' EXIT
javac --release 17 -encoding UTF-8 -d "$TEMP" \
  "$BASE/src/main/java/com/llmart/llm/service/AgentPlanRelevance.java" \
  "$BASE/src/main/java/com/llmart/llm/service/AgentPlanStructure.java" \
  "$BASE/qa/plan-relevance/AgentPlanStructureSmoke.java" \
  "$BASE/qa/plan-relevance/AgentPlanRelevanceSmoke.java" \
  "$BASE/qa/plan-relevance/RepositoryGuidanceSmoke.java"
java -cp "$TEMP" com.llmart.llm.service.AgentPlanRelevanceSmoke

java -cp "$TEMP" com.llmart.llm.service.AgentPlanStructureSmoke

java -cp "$TEMP" com.llmart.llm.service.RepositoryGuidanceSmoke "$BASE/qa/plan-relevance/fixtures/selenium-playwright-4-prompts.txt" "$BASE/src/main/java/com/llmart/llm/service/AgentService.java"
