#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
SRC="$ROOT/src/main/java/com/llmart/llm/service"
DIR="$(mktemp -d)"
trap 'rm -rf "$DIR"' EXIT
mkdir -p "$DIR/stubs/org/springframework/stereotype" "$DIR/stubs/com/llmart/llm/service" "$DIR/classes"
cat > "$DIR/stubs/org/springframework/stereotype/Service.java" <<'STUB'
package org.springframework.stereotype;
public @interface Service { }
STUB
cat > "$DIR/stubs/com/llmart/llm/service/AgentWorkspaceService.java" <<'STUB'
package com.llmart.llm.service;
import java.nio.file.Path;
public final class AgentWorkspaceService {
    public static final class Workspace {
        private final Path root;
        public Workspace(Path root) { this.root=root; }
        public Path root() { return root; }
    }
}
STUB
cat > "$DIR/stubs/com/llmart/llm/service/PolicySmoke.java" <<'TEST'
package com.llmart.llm.service;
import java.nio.file.*;
import java.util.*;
public final class PolicySmoke {
    private static void check(boolean result, String message) {
        if (!result) throw new AssertionError(message);
    }
    public static void main(String[] args) throws Exception {
        AgentToolRegistry registry = new AgentToolRegistry();
        AgentProfileService service = new AgentProfileService();
        var p = service.parse("reviewer", """
                ---
                tools:
                  read: true
                  grep: true
                  write: false
                permission:
                  edit: deny
                  bash: deny
                  mcp: deny
                ---
                Review without editing.
                """);
        check(p.allowedTools().equals(Set.of("read", "grep")), "tools parsed");
        for (String tool : List.of("write", "resource_write", "bash", "process_start", "mcp__jira__create", "tool_search"))
            check("deny".equals(AgentToolPolicy.decision(p,tool,registry)), tool + " must be denied");
        check(AgentToolPolicy.visible(p,"read",registry), "read allowed");
        var ask = service.parse("ask", "---\npermission:\n  edit: ask\n---\nAsk first");
        check("ask".equals(AgentToolPolicy.decision(ask,"write",registry)), "ask action");
        try {
            service.parse("unsafe", "---\npermission:\n  bash:\n    \"*\": allow\n---\nUnsafe");
            throw new AssertionError("Nested allow must be refused");
        } catch (IllegalArgumentException expected) { }
        Path root = Files.createTempDirectory("eliya-policy");
        try {
            Files.createDirectories(root.resolve(".agents/agents"));
            Files.writeString(root.resolve(".agents/agents/audit.md"), "---\npermission:\n  edit: deny\n---\nRead-only audit");
            var catalog = service.discover(new AgentWorkspaceService.Workspace(root));
            for (String name : List.of("architect", "developer", "tester", "reviewer", "documentation", "researcher", "analyst", "audit", "general", "explore"))
                check(catalog.containsKey(name), "built-in or custom profile exists: " + name);
            check("deny".equals(AgentToolPolicy.decision(catalog.get("reviewer"),"bash",registry)), "built in reviewer shell denied");
            check("deny".equals(AgentToolPolicy.decision(catalog.get("architect"),"edit",registry)), "built in architect edit denied");
        } finally {
            Files.deleteIfExists(root.resolve(".agents/agents/audit.md"));
            Files.deleteIfExists(root.resolve(".agents/agents"));
            Files.deleteIfExists(root.resolve(".agents"));
            Files.deleteIfExists(root);
        }
        System.out.println("PASS: 10 agent profiles discovered; tool policy and fail-closed parser checks passed");
    }
}
TEST
javac --release 17 -d "$DIR/classes" "$DIR/stubs/org/springframework/stereotype/Service.java" \
  "$DIR/stubs/com/llmart/llm/service/AgentWorkspaceService.java" \
  "$SRC/AgentToolRegistry.java" "$SRC/AgentProfileService.java" "$SRC/AgentToolPolicy.java" \
  "$DIR/stubs/com/llmart/llm/service/PolicySmoke.java"
java -cp "$DIR/classes" com.llmart.llm.service.PolicySmoke
