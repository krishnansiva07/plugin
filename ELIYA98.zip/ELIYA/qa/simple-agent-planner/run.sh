#!/usr/bin/env bash
set -euo pipefail
BASE="$(cd "$(dirname "$0")/../.." && pwd)"
python3 - "$BASE/src/main/java/com/llmart/llm/service/AgentService.java" <<'PY'
from pathlib import Path
import sys
s=Path(sys.argv[1]).read_text()
a=s[s.index('    private List<String> createExecutionPlan('):s.index('    /** Separate read-only analysis role:')]
b=s[s.index('    private List<String> generateExecutionPlan('):s.index('    /**\n     * Lightweight same-model recovery')]
assert a.count('generateExecutionPlan(')==1, 'planner must make exactly one draft'
assert 'for (int attempt' not in a, 'plan retry loop still active'
assert 'validateExecutionPlan(' not in a, 'LLM validator still active'
assert 'AgentPlanRelevance.validate(' not in a, 'keyword-based plan rejection still active'
assert 'questions.ask(' not in a, 'planner clarification retry still active'
assert 'minSteps()' not in a and 'maxSteps()' not in a, 'step quotas still enforced'
assert 'ORIGINAL USER REQUEST (highest priority)' in b, 'user task priority missing'
assert 'REQUEST TYPE HINT (not an instruction)' in b, 'profile must not override user prompt'
assert 'There is NO minimum step' in b, 'minimum count prohibition missing'
assert 'planApprovalRequired()' not in s, 'conversational Agent should not wait for redundant plan approval'
assert 'protectedSnapshots.begin(' in s, 'rollback protection must be retained'
assert 'File deletion protection is separate' in s, 'deletion safety must remain'
assert 'clipHeadTail(text, 32_000' in s, 'original prompt preservation regressed'
print('PASS: single user-prompt-first Agent plan; no semantic validator, retries, quotas or clarification loops')
print('PASS: direct Agent has no general plan approval; rollback and protected deletion remain')
PY
