package com.llmart.llm.service;

import java.nio.file.Path;
import java.util.Locale;

/** Fail closed before indexing or writing to any overly broad filesystem scope. */
final class WorkspaceRootGuard {
    private WorkspaceRootGuard() { }

    static Path requireNarrow(Path path) {
        if (path == null || !path.isAbsolute()) {
            throw new IllegalArgumentException("Select an absolute project directory; no drive or relative path is allowed");
        }
        Path root = path.toAbsolutePath().normalize();
        if (root.getParent() == null || root.equals(root.getRoot())) {
            throw new IllegalArgumentException("Refusing to index a filesystem/drive root: " + root +
                    ". Select the application project folder instead.");
        }
        Path home = home();
        if (home != null && (root.equals(home) || home.startsWith(root))) {
            throw new IllegalArgumentException("Refusing to index a user-home folder or its parent: " + root +
                    ". Select the application project folder instead.");
        }
        // Even with an explicit path, Windows installation folders are not source workspaces.
        for (String env : new String[] {"SystemRoot", "ProgramFiles", "ProgramFiles(x86)", "ProgramData"}) {
            String value = System.getenv(env);
            if (value == null || value.isBlank()) continue;
            try {
                Path system = Path.of(value).toAbsolutePath().normalize();
                if (root.equals(system) || root.startsWith(system)) {
                    throw new IllegalArgumentException("Refusing to index a Windows system folder: " + root);
                }
            } catch (java.nio.file.InvalidPathException ignored) { }
        }
        return root;
    }

    private static Path home() {
        String value = System.getProperty("user.home");
        if (value == null || value.isBlank()) return null;
        try { return Path.of(value).toAbsolutePath().normalize(); }
        catch (java.nio.file.InvalidPathException ignored) { return null; }
    }
}
