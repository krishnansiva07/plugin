package com.llmart.llm.service;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Deterministic planner-failure recovery. No model retry, plan critic, or external I/O.
 *
 * A truncated JSON plan cannot be trusted as complete: a missing tail may contain
 * required phases or constraints. Never treat partially parsed JSON as an approved plan.
 * Instead, preserve the ORIGINAL request as the execution contract and let the
 * executor inspect the live workspace. All existing tool permissions, snapshots,
 * and deliverable verification remain in force.
 */
final class AgentPlanRecovery {
    private static final Pattern BULLET = Pattern.compile("^\\s*(?:\\d{1,2}[.)]|[-*•])\\s+(.{9,})$", Pattern.UNICODE_CHARACTER_CLASS);
    private static final Pattern REFUSAL = Pattern.compile(
            "(?is)^\\s*(?:sorry[,!. ]+)?(?:i (?:cannot|can't|won't|will not) (?:help|assist|comply|provide)|" +
            "i (?:must|have to) (?:decline|refuse)|request (?:blocked|refused)|content (?:filtered|blocked))\\b");

    private AgentPlanRecovery() { }

    static boolean looksStructured(String response) {
        String candidate = AgentPlanJsonEnvelope.extract(response).strip();
        return candidate.startsWith("{") || candidate.startsWith("[");
    }

    static boolean refusal(String response, String finishReason) {
        String reason = finishReason == null ? "" : finishReason.strip().toLowerCase(Locale.ROOT);
        return reason.equals("content_filter") || reason.equals("safety") || reason.equals("refusal") ||
                (response != null && REFUSAL.matcher(response).find());
    }

    /** Accept numbered/bulleted natural-language plans, but never raw JSON fragments. */
    static List<String> plainSteps(String response) {
        if (response == null || response.isBlank() || looksStructured(response)) return List.of();
        LinkedHashSet<String> steps = new LinkedHashSet<>();
        for (String line : response.split("\\R")) {
            Matcher bullet = BULLET.matcher(line);
            if (!bullet.matches()) continue;
            String step = bullet.group(1).strip();
            if (step.startsWith("{") || step.startsWith("[") || step.startsWith("\"")) continue;
            if (!step.isBlank()) steps.add(step.length() > 1_200 ? step.substring(0, 1_200) : step);
            if (steps.size() >= 16) break;
        }
        return List.copyOf(steps);
    }

    /**
     * Generate a safe, complete task contract without inventing paths, subtasks or user decisions.
     * The verbatim full request remains in the model conversation, and the fallback
     * explicitly anchors every requested phase and constraint to that full request.
     */
    static List<String> fromUserRequest(String original, boolean readOnly) {
        if (original == null || original.isBlank()) return List.of();
        String oneLine = original.replaceAll("\\s+", " ").strip();
        String excerpt = oneLine.length() <= 900 ? oneLine : oneLine.substring(0, 900) +
                " ... [Full original request is preserved in conversation context]";
        if (readOnly) return List.of(
                "Investigate and answer the ORIGINAL USER REQUEST using current read-only workspace evidence: " +
                excerpt + "\nValidate: Ground conclusions in actual inspected source and disclose missing evidence; do not modify files.");
        return List.of(
                "Inspect the relevant live workspace and fulfill every requirement, phase and constraint in the ORIGINAL USER REQUEST, " +
                "without expanding scope or guessing missing facts: " + excerpt +
                "\nValidate: Apply requested changes only within authorized workspace scope; preserve user exclusions.",
                "Verify all deliverables and requested outcomes against the FULL ORIGINAL USER REQUEST; " +
                "run appropriate targeted checks, repair actual failures within scope, and report concrete results and any remaining blockers." +
                "\nValidate: Use observed files, outputs and tests rather than assumptions.");
    }
}
