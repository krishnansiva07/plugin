package com.llmart.llm.repository;

import com.llmart.llm.entity.MessageEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface MessageRepository extends JpaRepository<MessageEntity, Long> {
    List<MessageEntity> findByConversationIdOrderByCreatedAtAsc(String conversationId);
    Optional<MessageEntity> findByIdAndConversationId(Long id, String conversationId);
    void deleteByConversationId(String conversationId);
}
