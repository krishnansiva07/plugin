package com.llmart.llm.service;

/**
 * Keeps Chat's streamed output, persisted message, and done event consistent.
 * It intentionally does not modify Agent execution, context, or tool permissions.
 */
final class ChatAnswerIntegrity {
    private ChatAnswerIntegrity() { }

    record Resolved(String content, String unstreamedSuffix, boolean divergent) { }

    static Resolved reconcile(String streamed, String returned) {
        String live = streamed == null ? "" : streamed;
        String completed = returned == null ? "" : returned;
        if (live.isEmpty()) return new Resolved(completed, "", false);
        if (completed.equals(live)) return new Resolved(live, "", false);
        // If a model returned more than the stream transported, send that tail as
        // tokens before publishing the final DTO and saving the full answer.
        if (completed.startsWith(live)) {
            return new Resolved(completed, completed.substring(live.length()), false);
        }
        // Never erase or silently rewrite a visible response during completion.
        // This includes shorter, empty, and divergent returned answers.
        return new Resolved(live, "", true);
    }
}
