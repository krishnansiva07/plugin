package com.llmart.llm.service;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Conservative, deterministic completion evidence for an explicitly named, small Markdown
 * file-creation task. Used only if the independent artifact verifier has already passed
 * and a semantic reviewer gives NO USABLE DECISION. Not a generic substitute for tests,
 * an explicit negative semantic decision, or review of executable changes.
 */
public final class AgentArtifactOutcomePolicy {
    private static final Pattern NAMED_MD = Pattern.compile(
            "(?i)(?<![\\w.])((?:[\\w.-]+[/\\\\])*[\\w.-]+\\.(?:md|markdown))(?![\\w.])");
    private static final Pattern CHANGED = Pattern.compile("(?m)^[AM]  (.+\\.(?:md|markdown))\\s*$", Pattern.CASE_INSENSITIVE);
    private static final int MAX_FILES = 8;
    private static final Set<String> STOP = Set.of("a", "an", "one", "the", "with", "and", "for", "to", "md", "markdown", "file", "doc");

    public record Result(boolean eligible, boolean satisfied, String reason) {
        static Result skip(String why) { return new Result(false, false, why); }
        static Result fail(String why) { return new Result(true, false, why); }
        static Result pass(String why) { return new Result(true, true, why); }
    }

    private AgentArtifactOutcomePolicy() {}

    public static Result inspect(Path root, String workspaceStatus, String objective,
                                 String approvedPlan, boolean documentationMode, boolean largeTaskMode) {
        AgentArtifactVerificationPolicy.Result structural = AgentArtifactVerificationPolicy.inspect(
                root, workspaceStatus, objective, documentationMode, largeTaskMode);
        if (!structural.passed()) return Result.skip("No independent Markdown-only verifier pass: " + structural.detail());
        String task = objective == null ? "" : objective.toLowerCase(Locale.ROOT);
        if (!task.matches("(?s).*(?:create|add|write|generate).*"))
            return Result.skip("Not an explicit artifact-creation objective");
        if (task.matches("(?s).*(?:analy[sz]e|compare|research|summari[sz]e|migration|documentation for|report on).*"))
            return Result.skip("Task requires substantive semantic review");
        List<String> expected = names(objective);
        if (expected.isEmpty() || expected.size() > 3)
            return Result.skip("Original request did not specify a bounded set of exact Markdown filenames");
        // This automatic completion is only for a narrow plan matching the named deliverables.
        // Extra approved-plan Markdown artifacts require ordinary whole-plan review.
        List<String> inPlan = names(approvedPlan);
        if (!inPlan.isEmpty() && inPlan.stream().anyMatch(name ->
                expected.stream().noneMatch(wanted -> basename(wanted).equalsIgnoreCase(basename(name)))))
            return Result.skip("Approved plan names additional Markdown deliverables");
        List<String> changed = new ArrayList<>();
        Matcher status = CHANGED.matcher(workspaceStatus == null ? "" : workspaceStatus);
        while (status.find()) changed.add(clean(status.group(1)));
        if (changed.isEmpty() || changed.size() > MAX_FILES || changed.size() != expected.size())
            return Result.skip("Changed-file count does not match the explicitly requested deliverables");
        try {
            Path canonical = root.toRealPath();
            Set<String> matched = new HashSet<>();
            for (String specified : expected) {
                String basename = basename(specified);
                List<String> hits = changed.stream().filter(path ->
                        basename(path).equalsIgnoreCase(basename) &&
                                (!specified.contains("/") || clean(path).toLowerCase(Locale.ROOT)
                                        .endsWith(specified.toLowerCase(Locale.ROOT)))).toList();
                if (hits.size() != 1) return Result.fail("Requested Markdown path is missing or ambiguous: " + specified);
                String relative = hits.get(0);
                String lowPath = relative.toLowerCase(Locale.ROOT);
                if (task.contains(".opencode") && !lowPath.startsWith(".opencode/"))
                    return Result.fail("Requested artifact is outside the .opencode directory: " + relative);
                // If the approved plan provides a precise location, the actual file must
                // match it. A same-named file in another folder is not a completed step.
                for (String planned : inPlan) {
                    if (basename(planned).equalsIgnoreCase(basename) && planned.contains("/") &&
                            !lowPath.endsWith(planned.toLowerCase(Locale.ROOT)))
                        return Result.fail("Actual file does not match approved plan path: " + planned);
                }
                // A request for separate agent and skill folders cannot be satisfied by
                // placing both Markdown files in one folder.
                if (task.contains("agents") && task.contains("skills")) {
                    boolean agentDoc = basename.toLowerCase(Locale.ROOT).contains("agent") ||
                            basename.toLowerCase(Locale.ROOT).contains("reviewer");
                    if (agentDoc && !(lowPath.contains("/agents/") || lowPath.contains("/.agents/")))
                        return Result.fail("Agent file is not in the requested agents folder: " + relative);
                    if (!agentDoc && !(lowPath.contains("/skills/") || lowPath.contains("/.skills/")))
                        return Result.fail("Skill file is not in the requested skills folder: " + relative);
                }
                Path file = root.resolve(relative).toAbsolutePath().normalize();
                if (!file.startsWith(root.toAbsolutePath().normalize()) ||
                        !Files.isRegularFile(file, LinkOption.NOFOLLOW_LINKS) ||
                        !file.toRealPath().startsWith(canonical))
                    return Result.fail("Requested Markdown file is unsafe or unavailable: " + relative);
                String contents = Files.readString(file, StandardCharsets.UTF_8).toLowerCase(Locale.ROOT);
                if (contents.strip().length() < 40 ||
                        contents.matches("(?s).*(?:lorem ipsum|\\bTODO\\b|\\bTBD\\b|\\bPLACEHOLDER\\b).*"))
                    return Result.fail("Requested Markdown file lacks usable content: " + relative);
                // A deliberately narrow topical check: the expected document topic must appear
                // in the actual file contents. Do not confuse any arbitrary file write with fulfillment.
                String topic = basename.replaceFirst("(?i)\\.(md|markdown)$", "");
                List<String> words = List.of(topic.toLowerCase(Locale.ROOT).split("[-_]+"))
                        .stream().filter(w -> w.length() >= 4 && !STOP.contains(w)).toList();
                if (!words.isEmpty() && words.stream().noneMatch(w -> containsStem(contents, w)))
                    return Result.fail("Requested topic not evidenced by document content: " + relative);
                if (!contents.contains("#") && !contents.startsWith("---"))
                    return Result.fail("Markdown document lacks a heading or frontmatter: " + relative);
                matched.add(relative);
            }
            // When the user explicitly requests an agent referencing a skill, confirm the
            // actual agent text identifies the actual skill, not merely that both files exist.
            if ((task.contains("refer") || task.contains("reference") || task.contains("use the skill"))
                    && task.contains("skill") && task.contains("agent")) {
                List<String> agents = changed.stream().filter(p -> p.toLowerCase(Locale.ROOT).contains("agent") &&
                        !p.toLowerCase(Locale.ROOT).contains("skill")).toList();
                List<String> skills = changed.stream().filter(p -> p.toLowerCase(Locale.ROOT).contains("skill")).toList();
                if (agents.size() != 1 || skills.size() != 1)
                    return Result.skip("Agent/skill cross-reference requires a dedicated semantic review");
                String agent = Files.readString(root.resolve(agents.get(0)), StandardCharsets.UTF_8).toLowerCase(Locale.ROOT);
                String slug = basename(skills.get(0)).replaceFirst("(?i)\\.(md|markdown)$", "");
                if (slug.equalsIgnoreCase("SKILL")) slug = root.resolve(skills.get(0)).getParent().getFileName().toString();
                String meaningful = slug.toLowerCase(Locale.ROOT).replaceAll("^one-class-one-", "");
                if (!agent.contains(slug.toLowerCase(Locale.ROOT)) && !agent.contains(meaningful))
                    return Result.fail("Agent document does not reference the requested skill: " + slug);
            }
            // A validator cannot infer unspecified semantic requirements. This fallback is
            // intentionally limited to exact named file creation and content/topic evidence.
            return Result.pass("Independently verified " + matched.size() + " explicitly requested Markdown paths, " +
                    "UTF-8 content and filename/topic coverage" +
                    (task.contains("refer") && task.contains("skill") ? ", including agent-to-skill reference" : "") + ".");
        } catch (IOException | SecurityException problem) {
            return Result.fail("Cannot independently inspect requested artifact content: " + problem.getClass().getSimpleName());
        }
    }

    private static boolean containsStem(String content, String word) {
        if (content.contains(word)) return true;
        if (word.length() > 5 && content.contains(word.substring(0, word.length() - 2))) return true;
        return false;
    }
    private static List<String> names(String text) {
        if (text == null) return List.of();
        Matcher m = NAMED_MD.matcher(text);
        Set<String> distinct = new java.util.LinkedHashSet<>();
        while (m.find()) distinct.add(clean(m.group(1)));
        return new ArrayList<>(distinct);
    }
    private static String clean(String text) { return text.trim().replace('\\', '/').replaceFirst("^\\./", ""); }
    private static String basename(String text) { int n = text.lastIndexOf('/'); return text.substring(n + 1); }
}
