package com.llmart.llm.service;

import java.util.Locale;

/** Explicit user restrictions override automatic broad workspace evidence retrieval.
 * This does not block a targeted tool call against a user-named file; it only disables
 * the automatic retrieval bundle injected into every model request.
 */
final class AgentRetrievalScopePolicy {
    private AgentRetrievalScopePolicy() { }

    static boolean skipAutomaticExploration(String objective) {
        if (objective == null || objective.isBlank()) return false;
        String t = objective.toLowerCase(Locale.ROOT).replace('’', '\'');
        boolean negated = t.contains("do not explore") || t.contains("don't explore") ||
                t.contains("without exploring") || t.contains("no workspace exploration") ||
                t.contains("avoid exploring") || t.contains("skip exploring");
        boolean workspace = t.contains("workspace") || t.contains("repository") || t.contains("repo") ||
                t.contains("codebase") || t.contains("project files");
        return negated && workspace;
    }
}
