package com.llmart.llm.service;

import java.util.List;
import java.util.Map;

/** Per-request source-size attribution. Characters are diagnostic counts, never billed tokens. */
public final class AgentContextAudit {
    private AgentContextAudit() { }
    public record Sizes(long instructions, long runtimeState, long retrieval, long userText,
                        long assistantText, long toolCallArguments, long toolResults, long toolSchema) {
        public long total() { return instructions + runtimeState + retrieval + userText + assistantText + toolCallArguments + toolResults + toolSchema; }
        public String summary() {
            return "Approximate request content in characters (NOT tokens): instructions=" + instructions +
                    ", runtime=" + runtimeState + ", retrieval=" + retrieval + ", user=" + userText +
                    ", assistant=" + assistantText + ", historical tool args=" + toolCallArguments +
                    ", tool results=" + toolResults + ", tool schema=" + toolSchema;
        }
    }

    public static Sizes measure(List<Map<String,Object>> messages, List<Map<String,Object>> definitions) {
        long instructions=0, runtime=0, retrieval=0, users=0, assistant=0, arguments=0, results=0, tools=0;
        if (messages != null) for (Map<String,Object> message : messages) {
            if (message == null) continue;
            String role = String.valueOf(message.getOrDefault("role", ""));
            String content = String.valueOf(message.getOrDefault("content", ""));
            switch (role) {
                case "system" -> {
                    if (content.startsWith("[RUNTIME_STATE:") || content.startsWith("[RUNTIME_STEERING:")) runtime += content.length();
                    else if (content.startsWith("[RUNTIME_RETRIEVAL:")) retrieval += content.length();
                    else instructions += content.length();
                }
                case "user" -> users += content.length();
                case "assistant" -> {
                    assistant += content.length();
                    Object callList = message.get("tool_calls");
                    if (callList instanceof List<?> list) for (Object call : list) {
                        if (call instanceof Map<?,?> entry) {
                            Object function = entry.get("function");
                            if (function instanceof Map<?,?> f) arguments += String.valueOf(f.get("arguments")).length();
                        }
                    }
                }
                case "tool" -> results += content.length();
                default -> { }
            }
        }
        if (definitions != null) for (Map<String,Object> def : definitions) if (def != null) tools += def.toString().length();
        return new Sizes(instructions, runtime, retrieval, users, assistant, arguments, results, tools);
    }
}
