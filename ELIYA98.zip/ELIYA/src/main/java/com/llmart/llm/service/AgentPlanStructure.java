package com.llmart.llm.service;

import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Planning-format checks only. Task scope and relevance remain the responsibility of
 * AgentPlanRelevance; this class must never manufacture missing validation evidence.
 */
final class AgentPlanStructure {
    private static final Pattern VALIDATION_LINE = Pattern.compile(
            "(?im)^([\\t ]*(?:[-*]\\s*)?)(validate|validation|verify|verification|checks?|evidence|acceptance criteria|success criteria)\\s*:[\\t ]*(\\S[^\\r\\n]*)$");
    private static final Pattern VERIFICATION_INTENT = Pattern.compile(
            "(?i)\\b(?:verify|verification|validate|validation|test|tests|testing|compile|compilation|build|type[- ]?check|lint|run|rerun|regression|smoke|check|review|audit|confirm|ensure|cross[- ]?check)\\b");
    private static final Pattern IMPLEMENTATION_INTENT = Pattern.compile(
            "(?i)\\b(?:implement|implementing|modify|modifying|edit|editing|create|creating|refactor|refactoring|migrate|migrating|write|writing|develop|developing)\\b");

    private AgentPlanStructure() { }

    static boolean hasValidationEvidence(String text) {
        return text != null && VALIDATION_LINE.matcher(text).find();
    }

    /** Normalize common equivalent check labels; preserve the model's actual evidence. */
    static String normalizeValidationLabel(String text) {
        if (text == null || text.isBlank()) return text == null ? "" : text;
        Matcher matcher = VALIDATION_LINE.matcher(text);
        StringBuilder result = new StringBuilder();
        while (matcher.find()) {
            matcher.appendReplacement(result, Matcher.quoteReplacement(matcher.group(1) + "Validate: " + matcher.group(3)));
        }
        matcher.appendTail(result);
        return result.toString();
    }

    /** Caller already established that this is the last plan step. Never require the word 'final'. */
    static boolean isLastStepVerification(String step) {
        if (step == null || step.isBlank()) return false;
        // A routine per-step Validate: annotation is NOT proof that the main action verifies the whole task.
        String mainAction = VALIDATION_LINE.matcher(step).replaceAll(" ").toLowerCase(Locale.ROOT);
        if (!VERIFICATION_INTENT.matcher(mainAction).find()) return false;
        // Reject a last step that still performs the main implementation rather than verifying it.
        return !IMPLEMENTATION_INTENT.matcher(mainAction).find();
    }
}
