package com.llmart.llm.service;

import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.stream.Stream;

/** Discovers OpenCode/Claude-like reusable agent profiles from the selected workspace. */
@Service
public class AgentProfileService {
    public Map<String,AgentProfile> discover(AgentWorkspaceService.Workspace ws) {
        LinkedHashMap<String,AgentProfile> profiles = new LinkedHashMap<>();
        profiles.put("explore", new AgentProfile("explore", "Read-only project exploration and root-cause investigation", "subagent", "", """
                You are an Explore subagent. Investigate the requested question using read-only workspace evidence. Search broadly but return a compact, concrete report to the parent agent. Do not modify files or start long-running processes.
                """, Set.of("inspect_workspace","workspace_profile","list","glob","grep","file_info","read","read_many","attachment_list","attachment_read","attachment_search","skill","instruction_catalog","instructions_for","mcp_status","lsp_status","lsp")));
        profiles.put("general", new AgentProfile("general", "General-purpose delegated investigation and implementation", "subagent", "", """
                You are a General subagent. Complete the delegated task autonomously using the tools provided. Return evidence, files/locations inspected, actions taken, and blockers. Do not invoke another subagent.
                """, Set.of())); // empty => all parent tools except task
        // Native roles are available in every project. User profiles can override their instructions,
        // while the runtime still enforces the selected profile's declared tool permissions.
        profiles.put("researcher", nativeProfile("researcher", "Evidence-based research across workspace, documents and explicitly enabled MCP", """
                You are the Researcher subagent. Analyse the user's question using primary source evidence,
                local workspace documents and only the integrations the parent task explicitly permits.
                Cite paths, dates and uncertainty. Do not modify local or remote data or execute shell commands.
                """, Set.of("edit", "bash")));
        profiles.put("analyst", nativeProfile("analyst", "General-purpose functional, data and workflow analysis", """
                You are the Analyst subagent. Determine the question, inspect relevant evidence and derive
                actionable, well-supported answers. Separate established facts, assumptions and recommendations.
                Do not change files, run commands or mutate external systems.
                """, Set.of("edit", "bash")));
        profiles.put("architect", nativeProfile("architect", "Design and architectural impact analysis", """
                You are the Architecture subagent. Analyse the requested change, existing components, dependencies, constraints,
                trade-offs and verifiable acceptance criteria. Prefer reusing established architecture. Do not edit files.
                Return paths, specific evidence, risks and an implementation design; distinguish evidence from assumptions.
                """, Set.of("edit", "bash", "mcp")));
        profiles.put("reviewer", nativeProfile("reviewer", "Independent read-only code, correctness and security review", """
                You are the independent Reviewer subagent. Compare actual implementation against the user's requirements.
                Identify correctness, security, maintainability, test and regression gaps, with file-level evidence.
                You are read-only; never modify code or run arbitrary commands. Report unverified claims as unverified.
                """, Set.of("edit", "bash", "mcp")));
        profiles.put("developer", nativeProfile("developer", "Implement approved features and fixes using the existing project", """
                You are the Developer subagent. Implement the exact delegated task in the selected workspace.
                Inspect relevant code and project instructions first, prefer existing patterns, preserve unrelated behavior,
                and verify changed code using permitted tools. Return concrete files changed and test evidence.
                """, Set.of()));
        profiles.put("tester", nativeProfile("tester", "Create, execute and report tests and regression evidence", """
                You are the Tester subagent. Establish measurable acceptance checks for the delegated task.
                Reuse the existing test framework, generate focused tests when requested and permitted,
                run relevant verifications, diagnose failures and distinguish executed checks from proposed tests.
                """, Set.of()));
        profiles.put("documentation", nativeProfile("documentation", "Document verified implementation and behaviour", """
                You are the Documentation subagent. Follow the user's requested structure and format exactly;
                never inject a default documentation template. Document code-backed behaviour, test evidence,
                changed files, decisions, limitations and unresolved issues. Do not invent implementation details.
                """, Set.of("bash", "mcp")));
        for (String rootName : List.of(".agents/agents", ".opencode/agents", ".claude/agents")) {
            Path root = ws.root().resolve(rootName).normalize();
            if (!root.startsWith(ws.root()) || !Files.isDirectory(root) || Files.isSymbolicLink(root)) continue;
            Path verifiedWorkspaceRoot;
            try {
                verifiedWorkspaceRoot = ws.root().toRealPath();
                if (!root.toRealPath().startsWith(verifiedWorkspaceRoot)) continue;
            } catch (IOException invalidRoot) { continue; }
            final Path safeRoot = verifiedWorkspaceRoot;
            try (Stream<Path> files = Files.walk(root, 6)) {
                files.filter(Files::isRegularFile).filter(p -> p.getFileName().toString().toLowerCase(Locale.ROOT).endsWith(".md")).sorted().limit(256).forEach(path -> {
                    try {
                        // Do not read Markdown symlinks that escape the user-selected workspace.
                        if (!path.toRealPath().startsWith(safeRoot) || Files.size(path) > 131_072L) return;
                        String rel = root.relativize(path).toString().replace('\\','/');
                        String id = rel.replaceFirst("(?i)\\.md$", "");
                        AgentProfile p = parse(id, Files.readString(path, StandardCharsets.UTF_8));
                        if (Set.of("subagent","all").contains(p.mode())) profiles.put(id, p);
                    } catch (Exception ignored) { }
                });
            } catch (IOException ignored) { }
        }
        return Collections.unmodifiableMap(new LinkedHashMap<>(profiles));
    }

    public String catalogText(AgentWorkspaceService.Workspace ws) {
        Map<String,AgentProfile> profiles = discover(ws);
        if (profiles.isEmpty()) return "[No subagents available]";
        StringBuilder out = new StringBuilder();
        for (AgentProfile p : profiles.values()) out.append(p.id()).append(" — ").append(p.description())
                .append(p.permissions().isEmpty() ? "" : " [policy-controlled]").append('\n');
        return out.toString().stripTrailing();
    }

    public AgentProfile require(AgentWorkspaceService.Workspace ws, String id) {
        AgentProfile p = discover(ws).get(id);
        if (p == null) throw new IllegalArgumentException("Unknown subagent '" + id + "'. Available:\n" + catalogText(ws));
        return p;
    }

    private AgentProfile nativeProfile(String name, String description, String instructions, Set<String> deniedCategories) {
        LinkedHashMap<String,String> policy = new LinkedHashMap<>();
        for (String category : deniedCategories) policy.put(category, "deny");
        return new AgentProfile(name, description, "subagent", "", instructions,
                Set.of(), Map.copyOf(policy));
    }

    /**
     * Small intentionally strict subset of agent Markdown frontmatter. Supports:
     * tools: [read, grep], tools:\n  read: true, and permission:\n  edit: deny.
     * Unrecognized permission values fail closed rather than silently making an agent writable.
     * Project profiles can still inherit global policies when they do not declare permissions.
     */
    AgentProfile parse(String id, String text) {
        String description = "Project-defined subagent";
        String mode = "subagent";
        String model = ""; // model selection remains inherited from the run's configured model pool
        LinkedHashSet<String> tools = new LinkedHashSet<>();
        LinkedHashMap<String,String> permissions = new LinkedHashMap<>();
        String body = text == null ? "" : text;
        if (body.startsWith("---")) {
            int end = body.indexOf("\n---", 3);
            if (end < 0) throw new IllegalArgumentException("Unterminated agent frontmatter: " + id);
            String fm = body.substring(3, end);
            body = body.substring(end + 4).strip();
            String section = "";
            String nestedPermission = "";
            for (String line : fm.split("\\R")) {
                if (line.isBlank() || line.stripLeading().startsWith("#")) continue;
                int indent = line.length() - line.stripLeading().length();
                String content = line.trim();
                int colon = content.indexOf(':');
                if (colon < 0) continue;
                String key = stripQuotes(content.substring(0,colon).trim()).toLowerCase(Locale.ROOT);
                String value = stripQuotes(content.substring(colon+1).trim());
                if (indent == 0) {
                    section = "";
                    nestedPermission = "";
                    switch(key) {
                        case "description" -> { if (!value.isBlank()) description = value; }
                        case "mode" -> { if (!value.isBlank()) mode = value.toLowerCase(Locale.ROOT); }
                        case "tools" -> {
                            if (value.isBlank()) section = "tools";
                            else if (value.startsWith("{") && value.endsWith("}")) {
                                parseInlineToolFlags(value, tools, permissions);
                            } else addToolList(tools, value);
                        }
                        case "permission", "permissions" -> {
                            if (value.isBlank()) section = "permission";
                            else permissions.put("*", validPermission(value));
                        }
                        case "model" -> { /* Inherited by design; do not silently change model credentials. */ }
                        default -> { }
                    }
                } else if ("tools".equals(section)) {
                    if (isFalse(value)) permissions.put(key, "deny");
                    else if (isTrue(value)) tools.add(key);
                    else throw new IllegalArgumentException("Unsupported tool flag for " + key + ": " + value);
                } else if ("permission".equals(section)) {
                    // Nested resource-specific patterns must not silently become unconditional allow rules.
                    if (indent > 2 && !nestedPermission.isBlank()) {
                        String effect = validPermission(value);
                        // A broad deny may be enforced for the entire category; conditional allow/ask
                        // requires a resource matcher and cannot safely be treated as unrestricted.
                        if ("deny".equals(effect)) permissions.put(nestedPermission, "deny");
                        else throw new IllegalArgumentException("Resource-pattern permissions must not be silently widened: " + nestedPermission);
                    } else if (value.isBlank()) {
                        nestedPermission = key;
                    } else {
                        nestedPermission = "";
                        permissions.put(key, validPermission(value));
                    }
                }
            }
        }
        // Native safety guarantees survive workspace-specific prompt overrides for these role names.
        if (Set.of("reviewer", "architect").contains(id)) {
            permissions.put("edit", "deny");
            permissions.put("bash", "deny");
            permissions.put("mcp", "deny");
        }
        return new AgentProfile(id, description, mode, model, body, Set.copyOf(tools), Map.copyOf(permissions));
    }

    private static void parseInlineToolFlags(String raw, Set<String> tools, Map<String,String> permissions) {
        String body = raw.substring(1, raw.length()-1);
        for (String item : body.split(",")) {
            if (item.isBlank()) continue;
            String[] pair = item.split(":", 2);
            if (pair.length != 2) throw new IllegalArgumentException("Malformed inline tool permission: " + item);
            String name = pair[0].trim().replace("'", "").replace("\"", "").toLowerCase(Locale.ROOT);
            String flag = pair[1].trim().replace("'", "").replace("\"", "").toLowerCase(Locale.ROOT);
            if (name.isBlank()) throw new IllegalArgumentException("Tool name cannot be blank");
            if (isTrue(flag)) tools.add(name);
            else if (isFalse(flag)) permissions.put(name, "deny");
            else throw new IllegalArgumentException("Unsupported inline tool flag: " + flag);
        }
    }

    private static String validPermission(String value) {
        String result = value.trim().toLowerCase(Locale.ROOT);
        if (!Set.of("allow", "ask", "deny").contains(result))
            throw new IllegalArgumentException("Unsupported agent permission '" + value + "' (expected allow/ask/deny)");
        return result;
    }

    private static boolean isTrue(String value) { return Set.of("true", "allow", "yes").contains(value.toLowerCase(Locale.ROOT)); }
    private static boolean isFalse(String value) { return Set.of("false", "deny", "no").contains(value.toLowerCase(Locale.ROOT)); }

    private static void addToolList(Set<String> tools, String value) {
        for (String entry : value.replace("[", "").replace("]", "").split(",")) {
            String t = entry.trim().replace("\"", "").replace("'", "");
            if (!t.isBlank()) tools.add(t);
        }
    }

    private String stripQuotes(String s) {
        if (s == null) return "";
        String v=s.trim();
        if (v.length()>=2 && ((v.startsWith("\"")&&v.endsWith("\""))||(v.startsWith("'")&&v.endsWith("'")))) return v.substring(1,v.length()-1);
        return v;
    }

    public record AgentProfile(String id, String description, String mode, String model, String systemPrompt,
                               Set<String> allowedTools, Map<String,String> permissions) {
        public AgentProfile(String id, String description, String mode, String model, String systemPrompt, Set<String> allowedTools) {
            this(id, description, mode, model, systemPrompt, allowedTools, Map.of());
        }
    }
}
