package com.llmart.llm.service;

import org.springframework.stereotype.Service;
import java.io.IOException;
import java.nio.file.*;
import java.util.*;

/** Inventory compatible local agent/skill conventions in a workspace and its discovered Git repositories. */
@Service
public class TerminalWorkspaceDiscoveryService {
    private final ProjectService projects;
    private final TerminalGitService git;
    public TerminalWorkspaceDiscoveryService(ProjectService projects, TerminalGitService git) {
        this.projects = projects; this.git = git;
    }

    public List<com.llmart.llm.dto.ProjectDto> mappedWorkspaces() {
        return projects.mappedLocalWorkspaces();
    }

    public Map<String,Object> discover(String projectId) throws IOException {
        if (projectId == null || projectId.isBlank()) return Map.of("workspace", "", "items", List.of(), "repositories", List.of());
        var project = projects.require(projectId);
        if (!project.hasLocalPath()) throw new IllegalArgumentException("Capabilities require a local workspace");
        Path root = WorkspaceRootGuard.requireNarrow(Path.of(project.getLocalPath()).toRealPath());
        if (!Files.isDirectory(root, LinkOption.NOFOLLOW_LINKS) || Files.isSymbolicLink(root))
            throw new SecurityException("Workspace root must be a real local directory");
        List<Map<String,Object>> repositories = git.repositories(projectId);
        LinkedHashMap<String,Path> sources = new LinkedHashMap<>();
        sources.put(".", root);
        for (Map<String,Object> repo : repositories) {
            String relative = String.valueOf(repo.get("path"));
            Path path = root.resolve(relative).normalize();
            if (path.startsWith(root) && Files.isDirectory(path, LinkOption.NOFOLLOW_LINKS))
                sources.putIfAbsent(relative, path);
        }
        List<Map<String,String>> results = new ArrayList<>();
        for (var source : sources.entrySet()) {
            String repository = source.getKey();
            Path base = source.getValue();
            for (String name : List.of("AGENTS.md", "CLAUDE.md", ".opencode/instructions.md",
                    ".opencode/opencode.json", ".opencode/opencode.jsonc")) {
                Path path = base.resolve(name).normalize();
                if (Files.isRegularFile(path, LinkOption.NOFOLLOW_LINKS) && !Files.isSymbolicLink(path))
                    results.add(Map.of("path", root.relativize(path).toString().replace('\\', '/'),
                            "kind", name.endsWith(".md") ? "instructions" : "configuration", "repository", repository));
            }
            for (String folder : List.of(".agents/agents", ".agents/skills", ".opencode/agents", ".opencode/agent",
                    ".opencode/skills", ".opencode/skill", ".opencode/commands", ".opencode/command",
                    ".claude/agents", ".claude/skills", ".claude/rules", ".claude/commands")) {
                Path dir = base.resolve(folder);
                if (!Files.isDirectory(dir, LinkOption.NOFOLLOW_LINKS) || Files.isSymbolicLink(dir)) continue;
                try (var walk = Files.walk(dir, 3)) {
                    walk.filter(p -> !Files.isSymbolicLink(p) && Files.isRegularFile(p, LinkOption.NOFOLLOW_LINKS))
                            .filter(p -> p.getFileName().toString().equalsIgnoreCase("SKILL.md") ||
                                    p.getFileName().toString().toLowerCase(Locale.ROOT).endsWith(".md"))
                            .limit(120).forEach(path -> {
                                String kind = folder.contains("skills") || folder.contains("skill") ? "skill" :
                                        folder.contains("command") ? "command" : folder.contains("rules") ? "rule" : "agent";
                                results.add(Map.of("path", root.relativize(path).toString().replace('\\', '/'),
                                        "kind", kind, "repository", repository));
                            });
                }
            }
        }
        results.sort(Comparator.comparing(row -> row.get("path")));
        List<Map<String,String>> bounded = results.size() > 800
                ? List.copyOf(results.subList(0, 800)) : List.copyOf(results);
        return Map.of("workspace", root.toString(), "items", bounded, "count", bounded.size(),
                "repositories", repositories);
    }
}
