package com.llmart.llm.service;

import java.io.IOException;
import java.time.Duration;
import java.util.Objects;
import java.util.function.Consumer;

/**
 * Monotonic, cancellable and observable deadline for file-heavy Agent stages.
 * A deadline never allows an incomplete rollback baseline to pass as successful.
 */
public final class AgentPreparationGuard {
    private final long startNanos = System.nanoTime();
    private final long deadlineNanos;
    private final Runnable cancellation;
    private final Consumer<String> progress;
    private long lastProgressNanos = startNanos;
    private long files;
    private long directories;
    private long bytes;
    private final String phase;

    public AgentPreparationGuard(String phase, long timeoutSeconds, Runnable cancellation, Consumer<String> progress) {
        this.phase = Objects.requireNonNull(phase);
        this.deadlineNanos = startNanos + Duration.ofSeconds(Math.max(1, timeoutSeconds)).toNanos();
        this.cancellation = cancellation == null ? () -> {} : cancellation;
        this.progress = progress == null ? ignored -> {} : progress;
    }

    public void check() throws IOException {
        cancellation.run();
        if (System.nanoTime() - deadlineNanos >= 0) {
            throw new IOException(phase + " exceeded its " + Math.max(1L, Duration.ofNanos(deadlineNanos - startNanos).toSeconds()) +
                    "s safety deadline (files=" + files + ", dirs=" + directories + ", bytes=" + bytes +
                    "). No Agent edits were started in this stage. Check disk access, workspace size and excluded build folders.");
        }
        reportIfDue();
    }

    public void directory() throws IOException { directories++; check(); }
    public void file(long size) throws IOException { files++; bytes += Math.max(0L, size); check(); }
    public long files() { return files; }
    public long bytes() { return bytes; }
    public void reportNow() { progress.accept(details()); lastProgressNanos = System.nanoTime(); }
    private void reportIfDue() {
        long now = System.nanoTime();
        if (now - lastProgressNanos >= Duration.ofSeconds(3).toNanos()) {
            lastProgressNanos = now;
            progress.accept(details());
        }
    }
    public String details() {
        return phase + ": files=" + files + ", dirs=" + directories + ", read=" + (bytes / (1024 * 1024)) +
                " MiB, elapsed=" + Duration.ofNanos(System.nanoTime() - startNanos).toSeconds() + "s";
    }
}
