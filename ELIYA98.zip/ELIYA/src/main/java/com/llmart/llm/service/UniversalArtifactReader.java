package com.llmart.llm.service;

import java.io.IOException;
import java.nio.file.*;
import java.nio.charset.*;
import java.nio.ByteBuffer;
import java.util.*;

/** Strict read-only preview of known text file types recorded in a verified Agent run. */
final class UniversalArtifactReader {
    static final int MAX_BYTES = 1_500_000;
    private static final Set<String> ALLOWED = Set.of("md","markdown","html","htm","txt","json","jsonl",
            "yaml","yml","xml","java","js","jsx","ts","tsx","css","scss","properties",
            "sql","py","sh","ps1","bat","cmd","feature","csv","svg","toml","ini");
    private UniversalArtifactReader() {}
    static boolean supported(String name) {
        if (name == null) return false;
        int dot = name.lastIndexOf('.');
        return dot >= 0 && ALLOWED.contains(name.substring(dot + 1).toLowerCase(Locale.ROOT));
    }
    static void validate(Path root, Path target) throws IOException {
        if (root == null || target == null || !target.startsWith(root) || target.equals(root))
            throw new SecurityException("Artifact escapes selected workspace");
        if (!Files.isDirectory(root, LinkOption.NOFOLLOW_LINKS) || Files.isSymbolicLink(root))
            throw new SecurityException("Workspace root is unavailable or symbolic");
        Path cursor = root;
        for (Path part : root.relativize(target)) {
            cursor = cursor.resolve(part);
            if (Files.isSymbolicLink(cursor)) throw new SecurityException("Artifact preview refuses symbolic links");
        }
        if (!supported(target.getFileName().toString())) throw new IllegalArgumentException("Unsupported artifact preview type");
        if (!Files.isRegularFile(target, LinkOption.NOFOLLOW_LINKS))
            throw new IllegalArgumentException("Artifact is not a regular file in the workspace");
        if (Files.size(target) > MAX_BYTES) throw new IllegalArgumentException("Artifact exceeds 1.5 MB preview limit");
    }
    static String read(Path target) throws IOException {
        byte[] bytes;
        try (var input = Files.newInputStream(target, LinkOption.NOFOLLOW_LINKS)) { bytes = input.readNBytes(MAX_BYTES + 1); }
        if (bytes.length > MAX_BYTES) throw new IllegalArgumentException("Artifact exceeds 1.5 MB preview limit");
        try {
            return StandardCharsets.UTF_8.newDecoder().onMalformedInput(CodingErrorAction.REPORT)
                    .onUnmappableCharacter(CodingErrorAction.REPORT).decode(ByteBuffer.wrap(bytes)).toString();
        } catch (CharacterCodingException ex) { throw new IllegalArgumentException("Artifact is not valid UTF-8", ex); }
    }
}
