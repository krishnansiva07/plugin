package com.llmart.llm.service;

/** A selected UI workspace must not be replaced by incidental filesystem paths in an Agent prompt. */
final class AgentWorkspaceSelection {
    private AgentWorkspaceSelection() { }

    static boolean canInferFromPrompt(String selectedProjectId) {
        return selectedProjectId == null || selectedProjectId.isBlank();
    }
}
