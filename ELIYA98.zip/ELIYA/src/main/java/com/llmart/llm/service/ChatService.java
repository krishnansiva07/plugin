package com.llmart.llm.service;

import com.llmart.llm.dto.ChatMode;
import com.llmart.llm.dto.ChatRequest;
import com.llmart.llm.dto.MessageDto;
import com.llmart.llm.entity.ConversationEntity;
import com.llmart.llm.entity.MessageEntity;
import jakarta.annotation.PreDestroy;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.HashSet;
import java.util.Set;
import java.util.Locale;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

@Service
public class ChatService {
    private final ConversationService conversations;
    private final FileService files;
    private final ContextService contextService;
    private final ProjectService projects;
    private final OpenAiCompatibleClient llm;
    private final AgentService agentService;
    private final AgentRunService agentRuns;
    private final PromptResourceResolver resourceResolver;
    private final ChatMcpService chatMcp;
    private LocalProjectIndexService localIndex;
    private final Map<String, AtomicBoolean> chatCancellations = new ConcurrentHashMap<>();
    private final ScheduledExecutorService chatHeartbeat = Executors.newSingleThreadScheduledExecutor(r -> {
        Thread t = new Thread(r, "eliya-chat-sse-heartbeat");
        t.setDaemon(true);
        return t;
    });
    private final ExecutorService runExecutor = Executors.newFixedThreadPool(
            Math.max(2, Math.min(8, Runtime.getRuntime().availableProcessors())), r -> {
        Thread t = new Thread(r, "agent-run-executor"); t.setDaemon(true); return t;
    });

    public ChatService(ConversationService conversations, FileService files,
                       ContextService contextService, ProjectService projects,
                       OpenAiCompatibleClient llm, AgentService agentService, AgentRunService agentRuns,
                       PromptResourceResolver resourceResolver, ChatMcpService chatMcp) {
        this.conversations = conversations;
        this.files = files;
        this.contextService = contextService;
        this.projects = projects;
        this.llm = llm;
        this.agentService = agentService;
        this.agentRuns = agentRuns;
        this.resourceResolver = resourceResolver;
        this.chatMcp = chatMcp;
    }

    @Autowired
    public void setLocalIndex(LocalProjectIndexService localIndex) { this.localIndex = localIndex; }

    /** The Terminal observes the *same* agent stream without tying its lifecycle to an HTTP connection.
     * Events are delivered on the agent worker; do not send secrets or keys through the observer.
     */
    public void runTerminal(String apiKey, ChatRequest request, java.util.function.BiConsumer<String,Object> observer) {
        if (observer == null) throw new IllegalArgumentException("Terminal event observer is required");
        java.util.concurrent.CountDownLatch finished = new java.util.concurrent.CountDownLatch(1);
        streamInternal(apiKey, request, observer, finished);
        try { finished.await(); }
        catch (InterruptedException e) { Thread.currentThread().interrupt(); throw new IllegalStateException("Terminal worker interrupted", e); }
    }

    public SseEmitter stream(String apiKey, ChatRequest request) {
        return streamInternal(apiKey, request, null, null);
    }

    private final ThreadLocal<java.util.function.BiConsumer<String,Object>> terminalObserver = new ThreadLocal<>();

    private SseEmitter streamInternal(String apiKey, ChatRequest request,
                                     java.util.function.BiConsumer<String,Object> observer,
                                     java.util.concurrent.CountDownLatch terminalFinished) {
        if (apiKey == null || apiKey.isBlank()) throw new IllegalArgumentException("API key is required");
        SseEmitter emitter = new SseEmitter(0L);
        AtomicBoolean transportOpen = new AtomicBoolean(true);
        // A browser/proxy SSE disconnect is a transport event, not an execution cancellation. Agent and Chat work
        // continue server-side and persist their result. Only the explicit Stop endpoint cancels execution.
        Runnable closeTransport = () -> transportOpen.set(false);
        emitter.onTimeout(closeTransport);
        emitter.onError(error -> closeTransport.run());
        emitter.onCompletion(closeTransport);

        CompletableFuture.runAsync(() -> {
            if (observer != null) terminalObserver.set(observer);
            AtomicBoolean earlyChatCancellation = null;
            String activeChatConversation = null;
            ScheduledFuture<?> heartbeat = null;
            try {
                long startedNanos = System.nanoTime();
                ConversationEntity conversation = conversations.getOrCreate(request.conversationId());
                MessageEntity userMessage;

                if (request.isRegenerate()) {
                    userMessage = conversations.lastUserMessage(conversation.getId());
                    conversations.removeMessagesAfter(conversation.getId(), userMessage.getId());
                } else {
                    List<String> attachmentIds = request.attachmentIds() == null ? List.of() : request.attachmentIds();
                    files.requireForConversation(conversation.getId(), attachmentIds);
                    String userText = request.message();
                    if ((userText == null || userText.isBlank()) && attachmentIds.isEmpty()) {
                        throw new IllegalArgumentException("Message or attachment is required");
                    }
                    if (userText == null || userText.isBlank()) {
                        userText = "Please analyze the attached file(s).";
                    }
                    userMessage = conversations.addMessage(conversation.getId(), "user", userText.strip(), attachmentIds);
                }

                ChatMode mode = request.chatMode();
                if (mode == ChatMode.CHAT) {
                    earlyChatCancellation = new AtomicBoolean(false);
                    activeChatConversation = conversation.getId();
                    AtomicBoolean previousRun = chatCancellations.put(activeChatConversation, earlyChatCancellation);
                    if (previousRun != null) previousRun.set(true);
                    safeSend(emitter, transportOpen, "meta", Map.of("conversationId", conversation.getId(),
                            "userMessageId", userMessage.getId(), "mode", "chat"));
                    safeSend(emitter, transportOpen, "chat_status", Map.of(
                            "phase", "preparing", "detail", "Preparing Chat context…"));
                    // SSE keepalives prevent an idle corporate proxy from silently dropping a Chat
                    // stream during a slow MCP call or first-token provider delay. Comments are ignored
                    // by the token renderer and do not add content to the saved conversation.
                    heartbeat = chatHeartbeat.scheduleAtFixedRate(() -> {
                        if (!transportOpen.get()) return;
                        try { emitter.send(SseEmitter.event().comment("keep-alive")); }
                        catch (Exception ignored) { transportOpen.set(false); }
                    }, 10, 10, TimeUnit.SECONDS);
                }
                String effectiveProjectId = request.projectId();
                boolean autoResolvedWorkspace = false;

                // The explicitly selected UI workspace is authoritative for Agent execution. A path in
                // a prompt may be an input, reference, example, or diagnostic path; it must not silently
                // replace the active writable root. Prompt inference remains available ONLY when no
                // workspace was selected (backwards-compatible no-workspace Agent requests).
                if (mode == ChatMode.AGENT) {
                    if (AgentWorkspaceSelection.canInferFromPrompt(effectiveProjectId)) {
                        var inferred = resourceResolver.primaryProjectPath(userMessage.getContent());
                        if (inferred.isPresent()) {
                            var mapped = projects.createLocal(conversation.getId(), inferred.get().toString(),
                                    inferred.get().getFileName() == null ? "Prompt workspace" : inferred.get().getFileName().toString());
                            if (localIndex != null) localIndex.request(mapped, false);
                            effectiveProjectId = mapped.id();
                            autoResolvedWorkspace = true;
                        }
                    } else {
                        projects.requireConversation(effectiveProjectId, conversation.getId());
                        // A remembered workspace must not force unrelated Jira/Confluence/document analysis into
                        // repository mode. Keep it for coding/implementation prompts; otherwise this run is external-only.
                        if (externalAnalysisWithoutWorkspace(userMessage.getContent())) effectiveProjectId = null;
                    }
                } else if (effectiveProjectId != null && !effectiveProjectId.isBlank()) {
                    projects.requireConversation(effectiveProjectId, conversation.getId());
                    var selected = projects.require(effectiveProjectId);
                    if (localIndex != null && selected.hasLocalPath()) localIndex.request(projects.get(effectiveProjectId), false);
                }

                if (mode == ChatMode.AGENT && effectiveProjectId != null && !effectiveProjectId.isBlank()) {
                    var activeWorkspace = projects.require(effectiveProjectId);
                    if (!activeWorkspace.hasLocalPath()) {
                        throw new IllegalArgumentException("The selected Agent workspace is not a writable local-path workspace. Disconnect it or select a local path; Jira/Confluence/document analysis can run with no workspace selected.");
                    }
                    if (localIndex != null) localIndex.request(projects.get(effectiveProjectId), false);
                }

                List<String> selectedReferences = request.referenceProjectIds() == null ? List.of()
                        : request.referenceProjectIds().stream().filter(Objects::nonNull).distinct().limit(5).toList();
                Map<String,String> referenceNames = new LinkedHashMap<>();
                Set<String> usedNames = new HashSet<>();
                StringBuilder referencesForAgent = new StringBuilder();
                for (String id : selectedReferences) {
                    projects.requireConversation(id, conversation.getId());
                    var reference = projects.require(id);
                    if (!reference.hasLocalPath() || id.equals(effectiveProjectId)) continue;
                    if (localIndex != null) localIndex.request(projects.get(id), false);
                    String rawName = request.referenceProjectNames() == null ? null : request.referenceProjectNames().get(id);
                    String referenceName = rawName == null ? "Reference" + (referenceNames.size() + 1) : rawName.strip();
                    if (!referenceName.matches("[A-Za-z][A-Za-z0-9_-]{0,39}") || referenceName.equalsIgnoreCase("workspace")
                            || !usedNames.add(referenceName.toLowerCase(Locale.ROOT)))
                        throw new IllegalArgumentException("Reference names must be unique identifiers (letters, digits, _ or -, starting with a letter, up to 40 characters; not workspace).");
                    referenceNames.put(id, referenceName);
                    referencesForAgent.append("\nReference [").append(referenceName).append("] (read-only): ")
                            .append(reference.getLocalPath());
                }
                String agentPrompt = mode == ChatMode.AGENT && referencesForAgent.length() > 0
                        ? userMessage.getContent() + "\n\nSelected shared reference folders (use reference names in the task; all are read-only):" + referencesForAgent
                        : userMessage.getContent();
                ChatRequest effectiveRequest = new ChatRequest(request.conversationId(), agentPrompt,
                        request.attachmentIds(), effectiveProjectId, request.mode(), request.regenerate(),
                        request.settings(), selectedReferences, referenceNames, request.documentationTemplateSelected());

                Path chatWorkspaceRoot = null;
                if (mode == ChatMode.CHAT && effectiveProjectId != null && !effectiveProjectId.isBlank()) {
                    var chatProject = projects.require(effectiveProjectId);
                    if (chatProject.hasLocalPath()) chatWorkspaceRoot = Path.of(chatProject.getLocalPath()).toAbsolutePath().normalize();
                }
                if (mode == ChatMode.CHAT) {
                    // MCP discovery can be slow. Start it only for MCP-relevant prompts and overlap it with
                    // workspace/reference retrieval so ordinary Chat keeps the direct fast path. Workspace-local
                    // MCP configs are scoped to the active workspace and never reused for another project.
                    chatMcp.prefetchIfNeeded(userMessage.getContent(), chatWorkspaceRoot);
                    boolean workspaceQuery = effectiveProjectId != null && !effectiveProjectId.isBlank()
                            && contextService.shouldRetrieveWorkspace(userMessage.getContent());
                    safeSend(emitter, transportOpen, "chat_status", Map.of(
                            "phase", "context", "detail", workspaceQuery
                                    ? "Searching project and preparing context…" : "Preparing conversation context…"));
                }
                final AtomicBoolean contextCancellation = earlyChatCancellation;
                List<Map<String, Object>> context = contextService.build(
                        conversation.getId(), userMessage, request.settings(), effectiveProjectId, apiKey, mode,
                        () -> contextCancellation != null && contextCancellation.get());
                contextService.includeReferences(context, selectedReferences, referenceNames, userMessage.getContent(),
                        mode, request.settings(), apiKey, () -> contextCancellation != null && contextCancellation.get());
                if (contextCancellation != null) {
                    FastChatRetrieval.checkCancelled(contextCancellation::get);
                    safeSend(emitter, transportOpen, "chat_status", Map.of("phase", "context_ready",
                            "detail", "Context ready; requesting model response…",
                            "elapsedMillis", java.util.concurrent.TimeUnit.NANOSECONDS.toMillis(System.nanoTime() - startedNanos)));
                }
                if (mode == ChatMode.AGENT && referencesForAgent.length() > 0) {
                    Map<String,Object> last = new LinkedHashMap<>(context.get(context.size() - 1));
                    Object content = last.get("content");
                    if (content instanceof String text) last.put("content", text + "\n\nSelected shared reference folders (reference names are user-defined; always keep them read-only):" + referencesForAgent);
                    context.set(context.size() - 1, last);
                }

                AgentRunService.AgentRun agentRun = mode == ChatMode.AGENT
                        ? agentRuns.start(conversation.getId(), effectiveProjectId)
                        : null;
                Map<String,Object> meta = new LinkedHashMap<>();
                meta.put("conversationId", conversation.getId());
                meta.put("userMessageId", userMessage.getId());
                meta.put("mode", mode.wireName());
                if (agentRun != null) meta.put("agentRunId", agentRun.id());
                if (effectiveProjectId != null && !effectiveProjectId.isBlank()) meta.put("projectId", effectiveProjectId);
                if (autoResolvedWorkspace) meta.put("autoResolvedWorkspace", true);
                safeSend(emitter, transportOpen, "meta", meta);

                String answer;
                if (mode == ChatMode.AGENT) {
                    AgentService.AgentResult result = agentService.run(agentRun.id(), apiKey, effectiveRequest, context, event -> {
                        safeSend(emitter, transportOpen, "agent_step", event);
                    });
                    answer = result.answer();

                    // Persist the terminal result BEFORE relying on the SSE transport. If a proxy/browser keeps the
                    // stream open or drops the final event, the UI watchdog can recover this durable answer by run id.
                    MessageEntity assistant = conversations.addMessage(conversation.getId(), "assistant", answer, List.of());
                    MessageDto dto = conversations.messageDto(assistant);
                    agentRun.markResponsePersisted(String.valueOf(dto.id()), answer);
                    safeSend(emitter, transportOpen, "token", Map.of("text", visibleAgentAnswer(answer)));
                    if (!result.changes().isEmpty()) {
                        safeSend(emitter, transportOpen, "agent_changes", Map.of(
                                "count", result.changes().size(), "mode", "direct"));
                    }
                    safeSend(emitter, transportOpen, "done", dto);
                    safeComplete(emitter, transportOpen);
                    return;
                }

                AtomicBoolean chatCancelled = earlyChatCancellation;
                FastChatRetrieval.checkCancelled(chatCancelled::get);
                StringBuilder generated = new StringBuilder();
                BufferedTokenTransport tokenTransport = new BufferedTokenTransport(emitter, transportOpen);
                try {
                    var mcpAnswer = chatMcp.answer(apiKey, effectiveRequest, userMessage.getContent(), context,
                            chatCancelled::get, activity -> {
                                safeSend(emitter, transportOpen, "chat_status", Map.of(
                                        "phase", activity.status(), "detail", activity.detail(), "tool", activity.tool()));
                            }, token -> {
                                generated.append(token);
                                tokenTransport.accept(token);
                            }, chatWorkspaceRoot);
                    if (mcpAnswer.isPresent()) {
                        answer = mcpAnswer.get();
                        // MCP emitted its final tokens through the same buffered SSE transport.
                    } else {
                        safeSend(emitter, transportOpen, "chat_status", Map.of(
                                "phase", "generating", "detail", "Generating response…"));
                        answer = llm.streamContinuously(apiKey, request.settings(), context, token -> {
                            generated.append(token);
                            tokenTransport.accept(token);
                        }, chatCancelled::get, part -> safeSend(emitter, transportOpen, "chat_status", Map.of(
                                "phase", "continuing", "detail", "Continuing long answer automatically (part " + part + ")…")));
                    }
                    // The completed, persisted answer must never discard text that was already
                    // emitted to the user. This matters especially for MCP and multi-part Chat,
                    // where returned final text can disagree with the concatenated token stream.
                    ChatAnswerIntegrity.Resolved resolved = ChatAnswerIntegrity.reconcile(generated.toString(), answer);
                    if (!resolved.unstreamedSuffix().isEmpty()) {
                        // The provider returned a valid longer answer. Deliver its missing tail
                        // before the done event so streamed and saved content remain identical.
                        tokenTransport.accept(resolved.unstreamedSuffix());
                    }
                    if (resolved.divergent()) {
                        // No answer text is logged; discrepancies may contain private project data.
                        System.getLogger(ChatService.class.getName()).log(System.Logger.Level.WARNING,
                                "Chat final-response mismatch: preserving streamed text to prevent content loss");
                    }
                    tokenTransport.flush();

                    MessageEntity assistant = conversations.addMessage(conversation.getId(), "assistant", resolved.content(), List.of());
                    MessageDto dto = conversations.messageDto(assistant);
                    safeSend(emitter, transportOpen, "done", dto);
                    safeComplete(emitter, transportOpen);
                } catch (AgentCancelledException stopped) {
                    tokenTransport.flush();
                    String partial = generated.toString().stripTrailing();
                    if (!partial.isBlank()) {
                        partial += "\n\n*Generation stopped.*";
                        MessageEntity assistant = conversations.addMessage(conversation.getId(), "assistant", partial, List.of());
                        safeSend(emitter, transportOpen, "done", conversations.messageDto(assistant));
                    } else {
                        safeSend(emitter, transportOpen, "stopped", Map.of("message", "Generation stopped"));
                    }
                    safeComplete(emitter, transportOpen);
                } catch (Exception generationFailure) {
                    // A dropped provider connection must not discard a long answer the model already
                    // streamed. Save an explicitly incomplete draft so the user can continue from it.
                    tokenTransport.flush();
                    String partial = generated.toString().stripTrailing();
                    if (partial.isBlank()) throw generationFailure;
                    String warning = "\n\n[ELIYA: response incomplete] Generation was interrupted (" +
                            generationFailure.getClass().getSimpleName() + "). " +
                            "The partial analysis has been saved. Ask 'continue' to complete it.";
                    String persisted = partial + warning;
                    MessageEntity assistant = conversations.addMessage(conversation.getId(), "assistant", persisted, List.of());
                    safeSend(emitter, transportOpen, "token", Map.of("text", warning));
                    safeSend(emitter, transportOpen, "done", conversations.messageDto(assistant));
                    safeComplete(emitter, transportOpen);
                } finally {
                    chatCancellations.remove(conversation.getId(), chatCancelled);
                }
            } catch (AgentCancelledException cancelledEarly) {
                safeSend(emitter, transportOpen, "stopped", Map.of("message", "Generation stopped"));
                safeComplete(emitter, transportOpen);
            } catch (Exception e) {
                // Headers are already committed as text/event-stream. Send an SSE error event and close normally;
                // do not ask Spring MVC to serialize a second non-SSE error body on the same response.
                safeSend(emitter, transportOpen, "error", Map.of("message", safeMessage(e)));
                safeComplete(emitter, transportOpen);
            } finally {
                terminalObserver.remove();
                if (terminalFinished != null) terminalFinished.countDown();
                if (heartbeat != null) heartbeat.cancel(false);
                if (activeChatConversation != null && earlyChatCancellation != null)
                    chatCancellations.remove(activeChatConversation, earlyChatCancellation);
            }
        }, runExecutor);
        return emitter;
    }

    /** Explicit user cancellation for Chat mode. Network/SSE disconnects never call this. */
    public boolean cancelChat(String conversationId) {
        if (conversationId == null || conversationId.isBlank()) return false;
        AtomicBoolean flag = chatCancellations.get(conversationId);
        if (flag == null) return false;
        flag.set(true);
        return true;
    }

    private boolean externalAnalysisWithoutWorkspace(String prompt) {
        if (prompt == null || prompt.isBlank()) return false;
        String low = prompt.toLowerCase(java.util.Locale.ROOT);
        boolean workspaceIntent = java.util.List.of(
                "workspace", "project", "repository", " repo ", "codebase", "source code", "framework",
                "implement", "modify", "change code", "edit", "fix", "migrate", "migration", "refactor",
                "write code", "create code", "create automation", "automate", "add test", "write test",
                "test script", "page object", "compile", "build", "run test", "execute test", "selenium",
                "playwright", "java", "typescript", "pom.xml", "package.json")
                .stream().anyMatch(low::contains);
        if (workspaceIntent) return false;
        boolean externalEvidence = java.util.List.of(
                "jira", "confluence", "gitlab", "sonarqube", "sonar", "mcp", "atlassian",
                "acceptance criteria", "requirement document", "requirements document", "attached document",
                "attached file", "specification", "analysis report", "summarise", "summarize")
                .stream().anyMatch(low::contains)
                || java.util.regex.Pattern.compile("(?i)\\b[A-Z][A-Z0-9]{1,15}-\\d+\\b").matcher(prompt).find();
        return externalEvidence;
    }

    private void safeSend(SseEmitter emitter, AtomicBoolean transportOpen, String event, Object data) {
        var observer = terminalObserver.get();
        if (observer != null) {
            try { observer.accept(event, data); } catch (Exception ignored) { /* observer failure must not stop Agent */ }
            return;
        }
        if (!transportOpen.get()) return;
        try { emitter.send(SseEmitter.event().name(event).data(data)); }
        catch (Exception ignored) { transportOpen.set(false); }
    }

    private void safeComplete(SseEmitter emitter, AtomicBoolean transportOpen) {
        if (terminalObserver.get() != null) { transportOpen.set(false); return; }
        if (!transportOpen.getAndSet(false)) return;
        try { emitter.complete(); } catch (Exception ignored) {}
    }

    /** Coalesces tiny provider deltas into fewer browser/SSE updates without delaying normal streaming. */
    private final class BufferedTokenTransport {
        private static final int FLUSH_CHARS = 96;
        private static final long FLUSH_NANOS = 35_000_000L;
        private final SseEmitter emitter;
        private final AtomicBoolean transportOpen;
        private final StringBuilder pending = new StringBuilder();
        private long lastFlush = System.nanoTime();

        private BufferedTokenTransport(SseEmitter emitter, AtomicBoolean transportOpen) {
            this.emitter = emitter;
            this.transportOpen = transportOpen;
        }

        private void accept(String token) {
            if (token == null || token.isEmpty()) return;
            pending.append(token);
            long now = System.nanoTime();
            if (pending.length() >= FLUSH_CHARS || now - lastFlush >= FLUSH_NANOS) flush();
        }

        private void flush() {
            if (pending.isEmpty()) return;
            String chunk = pending.toString();
            pending.setLength(0);
            lastFlush = System.nanoTime();
            safeSend(emitter, transportOpen, "token", Map.of("text", chunk));
        }
    }

    @PreDestroy
    public void shutdownExecutor() { runExecutor.shutdownNow(); chatHeartbeat.shutdownNow(); }

    private String visibleAgentAnswer(String value) {
        if (value == null) return "";
        return value.replaceAll("(?is)<!--\\s*PROJECT_FILE_START:[^>]+-->.*?<!--\\s*PROJECT_FILE_END\\s*-->", "").strip();
    }

    private String safeMessage(Exception e) {
        String m = e.getMessage();
        if (m == null || m.isBlank()) return e.getClass().getSimpleName();
        return m.length() > 1500 ? m.substring(0, 1500) : m;
    }
}
