package com.llmart.llm.service;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * High-precision fast path for a few explicitly named Markdown deliverables.
 * Only the redundant planning-model call is removed. The ordinary agent still
 * creates the content, follows scoped workspace permissions, and independently
 * verifies the actual files. Ambiguous / broad requests use normal planning.
 */
public final class AgentFocusedArtifactPolicy {
    private static final Pattern NAMED_MARKDOWN = Pattern.compile(
            "(?i)(?<![\\w.])((?:[\\w.-]+[/\\\\])*[\\w.-]+\\.(?:md|markdown))(?![\\w.])");
    private static final Pattern CREATE = Pattern.compile("(?i)\\b(create|add|write|generate|make)\\b");
    private static final Pattern SOURCE_FILE = Pattern.compile(
            "(?i)\\b[\\w.-]+\\.(?:java|kt|ts|tsx|js|jsx|py|go|cs|sql|xml|yaml|yml|gradle|feature)\\b");
    private static final Pattern COMPLEX = Pattern.compile(
            "(?i)\\b(migrat(?:e|ion)|refactor|implement(?:ation)?|develop|build\\s+(?:the\\s+)?(?:app|system|framework)|" +
            "architecture|end[- ]to[- ]end|e2e|all\\s+(?:files|modules|repositories)|every\\s+(?:file|module)|" +
            "compare|analys(?:e|is|ing)|analyz(?:e|ing)|investigat|research|audit|restructur|fix\\s+(?:the\\s+)?(?:code|tests)|" +
            "codebase|cross[- ]repo|whole\\s+(?:project|repository)|entire\\s+(?:project|repository))\\b");
    private static final Set<String> FOCUSED_TOOLS = Set.of(
            "inspect_workspace", "list", "glob", "grep", "file_info", "read", "read_many",
            "tool_search", "write", "edit", "apply_patch", "bash", "workspace_status",
            "workspace_diff", "todo_update", "ask_user", "build", "test", "check",
            "resource_catalog", "resource_read", "conversation_handoff_read");

    private AgentFocusedArtifactPolicy() { }

    public static List<String> namedFiles(String request) {
        if (request == null) return List.of();
        Matcher matcher = NAMED_MARKDOWN.matcher(request);
        LinkedHashSet<String> names = new LinkedHashSet<>();
        while (matcher.find()) names.add(matcher.group(1).replace('\\', '/'));
        return List.copyOf(names);
    }

    public static boolean eligible(String request) {
        if (!Boolean.parseBoolean(System.getProperty("eliya.tokens.focusedArtifacts.enabled", "true"))) return false;
        if (request == null || request.isBlank() || request.length() > 2400) return false;
        List<String> names = namedFiles(request);
        return !names.isEmpty() && names.size() <= 3 && CREATE.matcher(request).find() &&
                !COMPLEX.matcher(request).find() && !SOURCE_FILE.matcher(request).find() &&
                !request.toLowerCase(Locale.ROOT).contains("@") &&
                !request.toLowerCase(Locale.ROOT).contains("mcp") &&
                !request.toLowerCase(Locale.ROOT).contains("attachment") &&
                !request.toLowerCase(Locale.ROOT).contains("upload") &&
                !request.toLowerCase(Locale.ROOT).contains("https://") &&
                !request.toLowerCase(Locale.ROOT).contains("http://");
    }

    public static List<String> plan(String request) {
        if (!eligible(request)) return List.of();
        String paths = String.join(", ", namedFiles(request));
        return List.of(
                "Create the requested Markdown deliverables (" + paths + ") in the user's specified directories. " +
                "Read existing target files or applicable instructions before overwriting. Include all requested content, " +
                "cross-references and conventions; do not modify unrelated files.",
                "Independently verify the actual on-disk Markdown files, requested directory placement, substantive " +
                "contents and any cross-file references. Record the verifier result and close only after all " +
                "user-requested deliverables are present and correct.");
    }

    /** Tool schemas are the same authoritative registry definitions; excluded tools remain discoverable on demand. */
    public static Set<String> initialTools(String request, Set<String> ordinaryTools) {
        if (!eligible(request)) return ordinaryTools;
        Set<String> selected = new LinkedHashSet<>(ordinaryTools);
        selected.retainAll(FOCUSED_TOOLS);
        return Collections.unmodifiableSet(selected);
    }
}
