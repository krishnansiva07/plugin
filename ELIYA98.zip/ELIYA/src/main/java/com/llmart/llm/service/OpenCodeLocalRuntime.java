package com.llmart.llm.service;

import java.io.IOException;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Base64;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.regex.Pattern;

/**
 * A Java-17-only OpenCode 2 launcher. Users need an installed OpenCode 2 binary,
 * but do not need npm, a terminal, a fixed port or a manually configured password
 * when ELIYA is started from its JAR.
 *
 * Never binds beyond 127.0.0.1; each ELIYA instance owns its own child process.
 */
public final class OpenCodeLocalRuntime {
    private static final Pattern V2 = Pattern.compile("(?i)(?:^|\\s)(?:opencode\\s*)?v?2\\.[0-9]+(?:\\.[0-9]+)?(?:\\s|$)");
    private static final SecureRandom RANDOM = new SecureRandom();
    private final boolean windows;
    private final Map<String,String> env;

    public OpenCodeLocalRuntime() { this(System.getProperty("os.name", ""), System.getenv()); }

    // Allows deterministic discovery tests on every development platform.
    OpenCodeLocalRuntime(String os, Map<String,String> env) {
        this.windows = os.toLowerCase(Locale.ROOT).contains("win");
        this.env = env;
    }

    public record Command(List<String> prefix, String location) {
        public List<String> withArgs(String... args) {
            List<String> result = new ArrayList<>(prefix);
            if (prefix.size() > 1 && "cmd.exe".equalsIgnoreCase(prefix.get(0))) {
                // Safe for a discovered, local batch launcher. Do not use untrusted prompt text here.
                StringBuilder line = new StringBuilder("\"\"").append(location).append('"');
                for (String arg : args) line.append(' ').append(arg);
                line.append('"');
                result.add(line.toString());
            } else result.addAll(List.of(args));
            return result;
        }
    }

    public Command findV2(String preferred) throws IOException {
        LinkedHashSet<Path> candidates = new LinkedHashSet<>();
        String configured = preferred == null || preferred.isBlank() ? "opencode" : preferred.trim();
        Path named = Path.of(configured);
        if (named.isAbsolute() || configured.contains("/") || configured.contains("\\")) {
            candidates.add(named.toAbsolutePath().normalize());
        } else {
            String path = env.getOrDefault("PATH", env.getOrDefault("Path", ""));
            for (String dir : path.split(Pattern.quote(System.getProperty("path.separator")))) {
                if (!dir.isBlank()) appendCandidates(candidates, Path.of(dir), configured);
            }
            if (windows) {
                appendCandidates(candidates, Path.of(env.getOrDefault("APPDATA", ""), "npm"), configured);
                String appData = env.getOrDefault("APPDATA", "");
                if (!appData.isBlank()) {
                    candidates.add(Path.of(appData, "npm", "node_modules", "@opencode", "cli", "bin", "opencode.exe"));
                }
                String local = env.getOrDefault("LOCALAPPDATA", "");
                if (!local.isBlank()) candidates.add(Path.of(local, "Programs", "opencode", "opencode.exe"));
            } else {
                String home = System.getProperty("user.home", "");
                for (String dir : List.of("/usr/local/bin", "/usr/bin", "/opt/homebrew/bin",
                        home + "/.local/bin", home + "/.bun/bin", home + "/.opencode/bin")) {
                    appendCandidates(candidates, Path.of(dir), configured);
                }
            }
        }
        for (Path candidate : candidates) {
            try {
                if (!Files.isRegularFile(candidate)) continue;
                Command command = commandFor(candidate);
                Process check = new ProcessBuilder(command.withArgs("--version"))
                        .redirectErrorStream(true).start();
                boolean finished = check.waitFor(5, TimeUnit.SECONDS);
                if (!finished) { check.destroyForcibly(); continue; }
                String version = new String(check.getInputStream().readNBytes(1024));
                if (check.exitValue() == 0 && V2.matcher(version.trim()).find()) return command;
            } catch (Exception ignored) { /* old or broken binary; examine next candidate */ }
        }
        throw new IOException("OpenCode 2 executable was not found. Install OpenCode 2 and check 'opencode --version' in a new terminal; then restart ELIYA. The legacy engine remains an optional manual setting.");
    }

    private void appendCandidates(LinkedHashSet<Path> out, Path directory, String name) {
        if (windows) {
            out.add(directory.resolve(name + ".exe"));
            out.add(directory.resolve(name + ".cmd"));
            out.add(directory.resolve(name + ".bat"));
        } else out.add(directory.resolve(name));
    }

    private Command commandFor(Path file) {
        String name = file.getFileName().toString().toLowerCase(Locale.ROOT);
        if (windows && (name.endsWith(".cmd") || name.endsWith(".bat")))
            return new Command(List.of("cmd.exe", "/d", "/s", "/c"), file.toString());
        return new Command(List.of(file.toString()), file.toString());
    }

    public int availableLoopbackPort() throws IOException {
        try (ServerSocket socket = new ServerSocket()) {
            socket.bind(new InetSocketAddress(InetAddress.getByName("127.0.0.1"), 0));
            return socket.getLocalPort();
        }
    }

    public String randomPassword() {
        byte[] bytes = new byte[32];
        RANDOM.nextBytes(bytes);
        return Base64.getUrlEncoder().withoutPadding().encodeToString(bytes);
    }

    public Process start(Command command, int port, String password) throws IOException {
        ProcessBuilder pb = new ProcessBuilder(command.withArgs("serve", "--hostname", "127.0.0.1",
                "--port", Integer.toString(port)));
        pb.environment().put("OPENCODE_PASSWORD", password);
        pb.environment().put("NO_PROXY", "localhost,127.0.0.1,::1");
        // The server may log its generated password; never copy child stdout to public logs.
        pb.redirectOutput(ProcessBuilder.Redirect.DISCARD);
        pb.redirectError(ProcessBuilder.Redirect.DISCARD);
        return pb.start();
    }
}
