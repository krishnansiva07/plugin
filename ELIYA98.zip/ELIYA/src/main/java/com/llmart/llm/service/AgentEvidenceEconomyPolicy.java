package com.llmart.llm.service;

import java.util.Locale;
import java.util.regex.Pattern;

/**
 * Opt-out, evidence-only token economy. Never truncates the user's instruction, an approved
 * plan, tool schemas, safety policies, a full tool result or verification evidence. Only
 * bounds OPTIONAL proactive retrieval for a specifically named source file/package.
 *
 * Tasks requiring architecture/impact analysis or broad changes retain the original budget.
 * The executor can always retrieve additional live code via its normal tools.
 */
public final class AgentEvidenceEconomyPolicy {
    private static final Pattern NAMED_SOURCE = Pattern.compile(
            "(?i)(?:[\\w./\\\\-]+\\.(?:java|kt|ts|tsx|js|jsx|py|go|cs|json|yaml|yml|xml|sql|md|feature|properties)\\b|\\btestscripts\\.[a-z][\\w.]*\\b)");
    private static final Pattern BROAD_SCOPE = Pattern.compile(
            "(?i)\\b(?:all|entire|whole|complete|comprehensive|architecture|end[- ]to[- ]end|e2e|migration|"
            + "regression|cross[- ](?:module|package|repo|language)|multiple|every|throughout|"
            + "dependency graph|dependencies|root causes|impact analysis|full|deep dive)\\b");

    private AgentEvidenceEconomyPolicy() { }

    public static ContextBudgetPolicy.Budget adjust(ContextBudgetPolicy.Budget normal,
                                                     String originalObjective, String activeStep) {
        if (normal == null || !Boolean.parseBoolean(
                System.getProperty("eliya.tokens.economy.enabled", "true"))) return normal;
        String objective = originalObjective == null ? "" : originalObjective;
        String step = activeStep == null ? "" : activeStep;
        // Never narrow a broad user objective just because the current step mentions one file.
        if (BROAD_SCOPE.matcher(objective).find() || BROAD_SCOPE.matcher(step).find()) return normal;
        if (!NAMED_SOURCE.matcher(objective).find() && !NAMED_SOURCE.matcher(step).find()) return normal;
        // More than one named file/package can imply a cross-file change; preserve full evidence.
        var matcher = NAMED_SOURCE.matcher(objective + " " + step);
        java.util.Set<String> named = new java.util.HashSet<>();
        while (matcher.find()) named.add(matcher.group().toLowerCase(Locale.ROOT));
        if (named.size() > 2) return normal;

        return new ContextBudgetPolicy.Budget(normal.profile(),
                Math.min(normal.files(), 3),
                Math.min(normal.retrievalChars(), 5_000),
                Math.min(normal.evidenceChars(), 9_000),
                normal.estimatedAvailableTokens(), normal.capacityEstimated());
    }
}
