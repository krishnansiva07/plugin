package com.llmart.llm.service;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;

/**
 * Model-output continuation for read-only Chat answers. Neither filesystem, MCP, nor Agent is invoked here.
 * Only a provider's explicit output-limit finish reason authorizes another generation request.
 * System properties allow immediate rollback if a gateway behaves unexpectedly.
 */
final class ChatAnswerContinuation {
    private static final int PREFIX_BUFFER = 512;
    private static final int RETAINED_TAIL = 8_000;

    static boolean enabled() {
        return !"false".equalsIgnoreCase(System.getProperty("eliya.chat.autoContinue.enabled", "true"));
    }

    static int maximumParts() {
        try {
            return Math.max(1, Math.min(20, Integer.parseInt(System.getProperty("eliya.chat.autoContinue.maxParts", "8"))));
        } catch (NumberFormatException ignored) { return 8; }
    }

    static List<Map<String,Object>> nextContext(List<Map<String,Object>> original, String generated) {
        // New list, never modify the original messages or change a user-provided request/source excerpt.
        ArrayList<Map<String,Object>> next = new ArrayList<>(original.size() + 2);
        for (Map<String,Object> message : original) next.add(new LinkedHashMap<>(message));
        String tail = generated == null ? "" : generated;
        if (tail.length() > RETAINED_TAIL) tail = tail.substring(tail.length() - RETAINED_TAIL);
        next.add(Map.of("role", "assistant", "content", tail));
        next.add(Map.of("role", "user", "content",
                "[ELIYA INTERNAL ANSWER CONTINUATION] Your previous reply was stopped by the model's " +
                "output-token limit, not by the user. Continue answering the ORIGINAL user request directly " +
                "from the last unfinished sentence. Do not restart, repeat sections, invent evidence or " +
                "change any requirement. Finish all remaining requested analysis, with caveats and source " +
                "paths intact. Only output the missing continuation; do not mention this internal message."));
        return next;
    }

    static void reportIncomplete(StringBuilder output, Consumer<String> onToken, String reason) {
        String message = "\n\n[ELIYA: response incomplete] " + reason;
        output.append(message);
        if (onToken != null) onToken.accept(message);
    }

    /** Delays only the first 512 characters of a continuation for bounded overlap removal. */
    static final class TokenMerger {
        private final StringBuilder answer;
        private final Consumer<String> onToken;
        private final boolean deduplicate;
        private final StringBuilder pending = new StringBuilder();
        private boolean prefixProcessed;

        TokenMerger(StringBuilder answer, Consumer<String> onToken, boolean deduplicate) {
            this.answer = answer;
            this.onToken = onToken;
            this.deduplicate = deduplicate;
            this.prefixProcessed = !deduplicate;
        }

        void accept(String token) {
            if (token == null || token.isEmpty()) return;
            if (prefixProcessed) { append(token); return; }
            pending.append(token);
            if (pending.length() >= PREFIX_BUFFER) flushPrefix();
        }

        void finish() { if (!prefixProcessed) flushPrefix(); }

        private void flushPrefix() {
            if (prefixProcessed) return;
            prefixProcessed = true;
            String prefix = pending.toString();
            pending.setLength(0);
            if (deduplicate) {
                int overlap = suffixPrefixOverlap(answer, prefix);
                prefix = prefix.substring(overlap);
            }
            append(prefix);
        }

        private void append(String value) {
            if (value.isEmpty()) return;
            answer.append(value);
            onToken.accept(value);
        }
    }

    static int suffixPrefixOverlap(CharSequence existing, CharSequence incoming) {
        int max = Math.min(Math.min(existing.length(), incoming.length()), PREFIX_BUFFER);
        // A handful of matching punctuation characters is normal across paragraphs and must not be stripped.
        for (int size = max; size >= 24; size--) {
            boolean matches = true;
            for (int j = 0; j < size; j++) {
                if (existing.charAt(existing.length() - size + j) != incoming.charAt(j)) {
                    matches = false;
                    break;
                }
            }
            if (matches) return size;
        }
        return 0;
    }

    private ChatAnswerContinuation() { }
}
