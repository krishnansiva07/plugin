package com.llmart.llm.service;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.CodingErrorAction;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;

/** Small, dependency-free boundary for read-only previews of Agent-created Markdown. */
final class MarkdownArtifactReader {
    static final int MAX_BYTES = 1_500_000;

    private MarkdownArtifactReader() { }

    static void validate(Path root, Path target) throws IOException {
        if (root == null || target == null || !target.startsWith(root) || target.equals(root))
            throw new SecurityException("Markdown file escapes selected workspace");
        if (!Files.isDirectory(root, LinkOption.NOFOLLOW_LINKS) || Files.isSymbolicLink(root))
            throw new SecurityException("Workspace root is unavailable or symbolic");
        Path cursor = root;
        for (Path part : root.relativize(target)) {
            cursor = cursor.resolve(part);
            if (Files.isSymbolicLink(cursor)) throw new SecurityException("Markdown preview refuses symbolic links");
        }
        if (!target.getFileName().toString().toLowerCase(java.util.Locale.ROOT).endsWith(".md"))
            throw new IllegalArgumentException("Only Markdown .md files can be previewed");
        if (!Files.isRegularFile(target, LinkOption.NOFOLLOW_LINKS))
            throw new IllegalArgumentException("Markdown file is missing from the workspace");
        if (Files.size(target) > MAX_BYTES)
            throw new IllegalArgumentException("Markdown preview exceeds 1.5 MB. Open the file locally.");
    }

    static String read(Path target) throws IOException {
        byte[] bytes;
        // Bounded read protects the UI if a file grows between validation and opening.
        try (var stream = Files.newInputStream(target, LinkOption.NOFOLLOW_LINKS)) {
            bytes = stream.readNBytes(MAX_BYTES + 1);
        }
        if (bytes.length > MAX_BYTES)
            throw new IllegalArgumentException("Markdown preview exceeds 1.5 MB. Open the file locally.");
        try {
            return StandardCharsets.UTF_8.newDecoder()
                    .onMalformedInput(CodingErrorAction.REPORT)
                    .onUnmappableCharacter(CodingErrorAction.REPORT)
                    .decode(ByteBuffer.wrap(bytes)).toString();
        } catch (CharacterCodingException e) {
            throw new IllegalArgumentException("Markdown file is not valid UTF-8", e);
        }
    }
}
