package com.llmart.llm.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.*;
import java.util.function.Consumer;

/**
 * OpenAI-compatible SSE tool-call assembler. Tool calls can be split across arbitrary delta boundaries;
 * never dispatch an incomplete call. The original tool-call index determines its order.
 */
final class AgentStreamDecoder {
    private final ObjectMapper mapper;
    private final Consumer<String> onText;
    private final StringBuilder text = new StringBuilder();
    private final TreeMap<Integer, Call> calls = new TreeMap<>();
    private JsonNode usage;
    private final Call legacy = new Call();
    private JsonNode fullMessage;
    private String finishReason = "";
    private boolean done;
    private boolean sawChoice;

    AgentStreamDecoder(ObjectMapper mapper, Consumer<String> onText) {
        this.mapper = mapper;
        this.onText = onText == null ? unused -> { } : onText;
    }

    /** Returns true on [DONE]. Failed or incomplete streams must not be silently treated as success. */
    boolean accept(String payload) throws Exception {
        if (payload == null || payload.isBlank()) return false;
        if ("[DONE]".equals(payload.trim())) { done = true; return true; }
        JsonNode root = mapper.readTree(payload);
        JsonNode error = root.path("error");
        if (!error.isMissingNode() && !error.isNull() && !error.isEmpty())
            throw new IllegalStateException("Agent model stream error: " + error.path("message").asText("provider error"));
        if (root.path("usage").isObject()) usage = root.path("usage");
        JsonNode choices = root.path("choices");
        if (!choices.isArray() || choices.isEmpty()) return false; // e.g. usage-only last frame
        sawChoice = true;
        JsonNode choice = choices.get(0);
        String finish = choice.path("finish_reason").asText("");
        if (!finish.isBlank()) finishReason = finish;
        JsonNode message = choice.path("message");
        if (message.isObject()) { fullMessage = message; return false; }
        JsonNode delta = choice.path("delta");
        JsonNode part = delta.path("content");
        if (part.isTextual()) addText(part.asText());
        else if (part.isArray()) for (JsonNode item : part) {
            if (item.isTextual()) addText(item.asText());
            else addText(item.path("text").asText(""));
        }
        // A few compatible gateways still stream the legacy function_call shape.
        JsonNode old = delta.path("function_call");
        if (old.isObject()) {
            String name = old.path("name").asText("");
            if (!name.isBlank()) legacy.name.append(name);
            String args = old.path("arguments").asText("");
            if (!args.isEmpty()) legacy.args.append(args);
        }
        JsonNode tc = delta.path("tool_calls");
        if (tc.isArray()) for (JsonNode item : tc) {
            int index = item.path("index").asInt(-1);
            if (index < 0 || index > 1024) throw new IllegalStateException("Invalid streamed tool call index");
            Call call = calls.computeIfAbsent(index, ignored -> new Call());
            String id = item.path("id").asText("");
            if (!id.isBlank()) call.id = id;
            JsonNode function = item.path("function");
            String name = function.path("name").asText("");
            if (!name.isBlank()) call.name.append(name);
            String args = function.path("arguments").asText("");
            if (!args.isEmpty()) {
                if (call.args.length() + args.length() > 2_000_000)
                    throw new IllegalStateException("Streamed tool arguments exceed the safety limit");
                call.args.append(args);
            }
        }
        return false;
    }

    private void addText(String chunk) {
        if (chunk == null || chunk.isEmpty()) return;
        text.append(chunk);
        onText.accept(chunk);
    }

    String content() {
        return fullMessage == null ? text.toString() : text.isEmpty() ? contentOf(fullMessage.path("content")) : text.toString();
    }

    private static String contentOf(JsonNode node) {
        if (node.isTextual()) return node.asText();
        if (node.isArray()) {
            StringBuilder value = new StringBuilder();
            for (JsonNode item : node) value.append(item.path("text").asText(""));
            return value.toString();
        }
        return "";
    }

    List<OpenAiCompatibleClient.AgentToolCall> toolCalls() throws Exception {
        if (fullMessage != null && fullMessage.path("tool_calls").isArray()) {
            List<OpenAiCompatibleClient.AgentToolCall> full = new ArrayList<>();
            for (JsonNode item : fullMessage.path("tool_calls")) {
                JsonNode function = item.path("function");
                if (!function.isObject()) continue;
                String name = function.path("name").asText("");
                if (name.isBlank()) throw new IllegalStateException("Incomplete streamed tool name");
                full.add(new OpenAiCompatibleClient.AgentToolCall(item.path("id").asText("call_" + full.size()),
                        name, parseArgs(function.path("arguments").asText("{}"))));
            }
            if (!full.isEmpty()) return full;
        }
        List<OpenAiCompatibleClient.AgentToolCall> result = new ArrayList<>();
        for (Call call : calls.values()) {
            if (call.name.isEmpty()) throw new IllegalStateException("Stream ended with incomplete tool name");
            result.add(new OpenAiCompatibleClient.AgentToolCall(call.id == null ? "call_" + UUID.randomUUID() : call.id,
                    call.name.toString(), parseArgs(call.args.isEmpty() ? "{}" : call.args.toString())));
        }
        if (result.isEmpty() && !legacy.name.isEmpty())
            result.add(new OpenAiCompatibleClient.AgentToolCall("call_" + UUID.randomUUID(), legacy.name.toString(),
                    parseArgs(legacy.args.isEmpty() ? "{}" : legacy.args.toString())));
        if (result.isEmpty() && fullMessage != null && fullMessage.path("function_call").isObject()) {
            JsonNode old = fullMessage.path("function_call");
            String name = old.path("name").asText("");
            if (!name.isBlank()) result.add(new OpenAiCompatibleClient.AgentToolCall("call_" + UUID.randomUUID(),
                    name, parseArgs(old.path("arguments").asText("{}"))));
        }
        return result;
    }

    private JsonNode parseArgs(String arguments) throws Exception {
        JsonNode value = mapper.readTree(arguments);
        if (!value.isObject()) throw new IllegalStateException("Streamed tool arguments must be a JSON object");
        return value;
    }

    JsonNode usage() { return usage; }
    String finishReason() { return finishReason; }
    boolean hasResult() { return sawChoice && (!finishReason.isBlank() || done || fullMessage != null); }

    private static final class Call {
        String id;
        final StringBuilder name = new StringBuilder();
        final StringBuilder args = new StringBuilder();
    }
}
