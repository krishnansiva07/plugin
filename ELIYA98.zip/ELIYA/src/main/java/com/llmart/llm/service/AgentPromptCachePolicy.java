package com.llmart.llm.service;

import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.HexFormat;
import java.util.Locale;

/** Optional prompt cache routing only for official OpenAI Chat Completions hosts.
 * Other compatible gateways have varying contracts and must not receive unknown fields.
 * Existing automatic prefix caching remains available for all supported providers.
 */
public final class AgentPromptCachePolicy {
    private AgentPromptCachePolicy() { }

    static boolean supportsKey(String baseUrl) {
        if (baseUrl == null) return false;
        try {
            URI uri = URI.create(baseUrl);
            return "https".equalsIgnoreCase(uri.getScheme()) && "api.openai.com".equalsIgnoreCase(uri.getHost());
        } catch (Exception ignored) { return false; }
    }

    static String affinity(String sessionId, String model) {
        if (sessionId == null || sessionId.isBlank() || model == null || model.isBlank()) return "";
        try {
            MessageDigest sha = MessageDigest.getInstance("SHA-256");
            byte[] hash = sha.digest(("eliya:v66:" + sessionId.strip() + ":" + model.strip()).getBytes(StandardCharsets.UTF_8));
            return "eliya-" + HexFormat.of().formatHex(hash, 0, 16);
        } catch (Exception e) { return ""; }
    }

    static boolean keyRejected(int status, String error) {
        if (status != 400 && status != 422) return false;
        String text = error == null ? "" : error.toLowerCase(Locale.ROOT);
        return text.contains("prompt_cache_key") && (text.contains("unknown") || text.contains("unsupported")
                || text.contains("unrecognized") || text.contains("extra field") || text.contains("not permitted"));
    }

    static boolean streamRejected(int status, String error) {
        if (status != 400 && status != 422) return false;
        String text = error == null ? "" : error.toLowerCase(Locale.ROOT);
        return (text.contains("stream_options") || text.contains("streaming") || text.contains("stream=true")
                || text.contains("stream not supported")) && (text.contains("unsupported")
                || text.contains("unknown") || text.contains("not supported") || text.contains("unrecognized")
                || text.contains("not allowed") || text.contains("invalid parameter"));
    }
}
