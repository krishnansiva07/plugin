package com.llmart.llm.service;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Actual, read-only post-write file evidence for a bounded Markdown-only result.
 * Does not interpret or approve semantics: the independent plan critic still does that.
 * All-or-nothing to avoid giving the critic a misleading partial file inventory.
 */
public final class AgentMarkdownOutcomeEvidence {
    private AgentMarkdownOutcomeEvidence() { }

    public static String collect(Path root, String status, int maxChars) {
        if (root == null || status == null || maxChars < 1_000) return "";
        List<String> paths = new ArrayList<>();
        for (String line : status.split("\\R")) {
            if (line.isBlank()) continue;
            if (line.length() < 4 || !line.substring(0, 3).matches("[AM]  ")) return "";
            String relative = line.substring(3).strip();
            String low = relative.toLowerCase(Locale.ROOT);
            if (!(low.endsWith(".md") || low.endsWith(".markdown"))) return "";
            paths.add(relative);
        }
        if (paths.isEmpty() || paths.size() > 8) return "";
        try {
            Path base = root.toAbsolutePath().normalize();
            Path realBase = base.toRealPath();
            StringBuilder result = new StringBuilder();
            int perFile = Math.max(800, maxChars / paths.size() - 120);
            for (String relative : paths) {
                Path file = base.resolve(relative).normalize();
                if (!file.startsWith(base) || !Files.isRegularFile(file, LinkOption.NOFOLLOW_LINKS) ||
                        !file.toRealPath().startsWith(realBase)) return "";
                for (Path parent = file; parent.startsWith(base); parent = parent.getParent()) {
                    if (Files.isSymbolicLink(parent)) return "";
                    if (parent.equals(base)) break;
                }
                if (Files.size(file) > 256_000) return "";
                String content = Files.readString(file, StandardCharsets.UTF_8);
                if (content.length() > perFile) {
                    int head = perFile * 2 / 3;
                    content = content.substring(0, head) + "\n[content excerpted; further read needed to approve complete semantics]\n" +
                            content.substring(content.length() - (perFile - head));
                }
                result.append("FILE: ").append(relative).append("\n````markdown\n")
                        .append(content).append("\n````\n");
            }
            if (result.length() > maxChars + 1_000) return "";
            return result.toString();
        } catch (IOException | SecurityException problem) {
            return ""; // Never invent a successful read or expose out-of-workspace paths.
        }
    }
}
