package com.llmart.llm.service;

import java.util.Locale;
import java.util.regex.Pattern;

/**
 * A verifier must be a trustworthy command, not merely a shell invocation whose
 * final exit status happens to be zero. Pure Java to keep this policy unit-testable
 * without Spring or a model connection.
 */
public final class AgentVerificationPolicy {
    private AgentVerificationPolicy() { }

    public record Result(boolean passed, String reason) { }

    private static final Pattern MASKED_ERROR = Pattern.compile(
            "(?is)(?:\\|\\|\\s*(?:true\\b|exit\\s+0\\b|cmd\\s*/c\\b|echo\\b|printf\\b|dir\\b|ls\\b|find\\b))|" +
            "(?:;\\s*exit\\s+0\\b)|(?:\\|\\s*\\|\\s*true\\b)");
    private static final Pattern SHELL_ERROR = Pattern.compile(
            "(?im)(?:is not recognized as an internal or external command|" +
            "the syntax of the command is incorrect|the system cannot find the (?:path|file) specified|" +
            "(?:command not found|no such file or directory)(?:\\s*$|\\s*\\n)|" +
            "^\\s*(?:bash|sh|cmd|powershell):\\s+.*(?:not found|error))");
    private static final Pattern WINDOWS_UNIX_COMMAND = Pattern.compile(
            "(?i)(?:^|[&|;\\n]\\s*)(?:mkdir\\s+-p\\b|find\\s+\\S+\\s+-type\\b|wc\\s+-[lcw]\\b)");

    public static Result checkShell(String tool, String command, String output, boolean windows) {
        String invocation = command == null ? "" : command;
        String response = output == null ? "" : output;
        if (MASKED_ERROR.matcher(invocation).find()) {
            return new Result(false, "Verification command masks an earlier failure with a fallback or forced success. Run independent checks and require each exit code to pass.");
        }
        if (windows && WINDOWS_UNIX_COMMAND.matcher(invocation).find()) {
            return new Result(false, "Unix-specific verification syntax was issued to Windows cmd. Select PowerShell/cmd-compatible commands or an available Unix shell.");
        }
        if (!response.startsWith("exitCode=0;")) {
            return new Result(false, "Verification command returned a nonzero/unknown exit code.");
        }
        if (SHELL_ERROR.matcher(response).find()) {
            return new Result(false, "Shell output contains a command execution error even though the final exit code is zero.");
        }
        return new Result(true, "Independent verifier command completed with exit code zero and no detected shell failure.");
    }

    public static boolean isShellTool(String tool) {
        return tool != null && switch (tool.toLowerCase(Locale.ROOT)) {
            case "bash", "build", "test", "check", "resource_bash", "resource_build", "resource_test", "resource_check" -> true;
            default -> false;
        };
    }
}
