package com.llmart.llm.service;

import org.springframework.stereotype.Service;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

/** Explicit user-driven creation of compatible local agents and skills, no implicit execution. */
@Service
public class TerminalSkillStudioService {
    private final ProjectService projects;
    public TerminalSkillStudioService(ProjectService projects) { this.projects = projects; }

    public record DefinitionRequest(String projectId, String repository, String format,
                                    String kind, String name, String description, String instructions) {}

    public Map<String,Object> create(DefinitionRequest req) throws IOException {
        if (req == null || req.projectId() == null) throw new IllegalArgumentException("Select a workspace");
        var project = projects.require(req.projectId());
        if (!project.hasLocalPath()) throw new IllegalArgumentException("Skill creation requires a local workspace");
        Path root = WorkspaceRootGuard.requireNarrow(Path.of(project.getLocalPath()).toRealPath());
        String repo = req.repository() == null || req.repository().isBlank() ? "." : req.repository();
        if (repo.indexOf('\0') >= 0 || Path.of(repo).isAbsolute()) throw new SecurityException("Invalid repository");
        Path base = root.resolve(repo).normalize();
        if (!base.startsWith(root) || !Files.isDirectory(base, LinkOption.NOFOLLOW_LINKS) || Files.isSymbolicLink(base))
            throw new SecurityException("Repository escapes workspace");
        base = base.toRealPath();
        if (!base.startsWith(root)) throw new SecurityException("Repository escapes workspace");
        String format = req.format() == null ? "eliya" : req.format().toLowerCase(Locale.ROOT);
        String dir = switch (format) {
            case "eliya" -> ".agents";
            case "opencode" -> ".opencode";
            case "claude" -> ".claude";
            default -> throw new IllegalArgumentException("Unsupported agent format");
        };
        String kind = req.kind() == null ? "" : req.kind().toLowerCase(Locale.ROOT);
        if (!kind.equals("skill") && !kind.equals("agent")) throw new IllegalArgumentException("Choose agent or skill");
        String name = Objects.requireNonNullElse(req.name(), "").trim();
        if (!name.matches("[a-z][a-z0-9-]{1,62}")) throw new IllegalArgumentException("Use a lowercase, hyphenated name (2-63 chars)");
        String description = Objects.requireNonNullElse(req.description(), "").replaceAll("[\\r\\n]+", " ").strip();
        String instructions = Objects.requireNonNullElse(req.instructions(), "").strip();
        if (description.isEmpty() || description.length() > 280 || instructions.isBlank() || instructions.length() > 100_000)
            throw new IllegalArgumentException("Description and instructions are required within size limits");
        Path destination = kind.equals("skill")
                ? base.resolve(dir).resolve("skills").resolve(name).resolve("SKILL.md")
                : base.resolve(dir).resolve("agents").resolve(name + ".md");
        Path cursor = base;
        for (Path segment : base.relativize(destination)) {
            cursor = cursor.resolve(segment);
            if (Files.isSymbolicLink(cursor)) throw new SecurityException("Definition path traverses a symbolic link");
        }
        // No overwrite or autonomous execution; only explicit creates. YAML scalar text is quoted safely.
        String meta = "---\nname: " + name + "\ndescription: " +
                "\"" + description.replace("\\", "\\\\").replace("\"", "\\\"") + "\"\n---\n\n";
        String content = meta + instructions + "\n";
        Files.createDirectories(destination.getParent());
        Files.writeString(destination, content, StandardCharsets.UTF_8, StandardOpenOption.CREATE_NEW);
        return Map.of("kind",kind,"format",format,"name",name,
                "path",root.relativize(destination).toString().replace('\\','/'),"bytes",content.getBytes(StandardCharsets.UTF_8).length);
    }
}
