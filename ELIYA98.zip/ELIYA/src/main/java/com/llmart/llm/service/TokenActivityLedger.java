package com.llmart.llm.service;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

/**
 * Provider token accounting grouped by the actual LLM activity. Shell/build/test calls do not
 * themselves consume model tokens; only the model calls that initiate or interpret them do.
 * Missing provider usage is never silently presented as an exact zero.
 */
public final class TokenActivityLedger {
    private static final int MAX_GROUPS = 512;
    private final LinkedHashMap<String, Entry> entries = new LinkedHashMap<>();

    public synchronized void record(String phase, int step, long estimatedInput, long input,
                                    long output, long total, long cached, long cacheWrite) {
        String label = phase == null || phase.isBlank() ? "Agent execution" : phase.strip();
        if (label.length() > 80) label = label.substring(0, 80);
        if (step > 0) label += " (step " + step + ")";
        if (!entries.containsKey(label) && entries.size() >= MAX_GROUPS) label = "Additional model activities";
        Entry item = entries.computeIfAbsent(label, k -> new Entry());
        item.calls++;
        item.estimatedInput += Math.max(0, estimatedInput);
        if (input > 0 || output > 0 || total > 0 || cached > 0 || cacheWrite > 0) {
            item.reportedCalls++;
            item.input += Math.max(0, input);
            item.output += Math.max(0, output);
            item.total += total > 0 ? total : Math.max(0, input) + Math.max(0, output);
            item.cached += Math.max(0, cached);
            item.cacheWrite += Math.max(0, cacheWrite);
        }
    }

    public synchronized List<Map<String, Object>> snapshot() {
        List<Map<String,Object>> values = new ArrayList<>(entries.size());
        for (Map.Entry<String, Entry> row : entries.entrySet()) {
            Entry e = row.getValue();
            Map<String,Object> data = new LinkedHashMap<>();
            data.put("activity", row.getKey());
            data.put("calls", e.calls);
            data.put("reportedCalls", e.reportedCalls);
            data.put("unreportedCalls", e.calls - e.reportedCalls);
            data.put("inputTokens", e.input);
            data.put("outputTokens", e.output);
            data.put("totalTokens", e.total);
            data.put("cachedInputTokens", e.cached);
            data.put("cacheWriteTokens", e.cacheWrite);
            data.put("estimatedInputTokens", e.estimatedInput);
            values.add(data);
        }
        return values;
    }

    public synchronized void store(Properties properties) {
        properties.setProperty("tokenActivity.count", Integer.toString(entries.size()));
        int index = 0;
        for (Map.Entry<String, Entry> row : entries.entrySet()) {
            String prefix = "tokenActivity." + index++ + ".";
            Entry e = row.getValue();
            properties.setProperty(prefix + "activity", row.getKey());
            properties.setProperty(prefix + "calls", Long.toString(e.calls));
            properties.setProperty(prefix + "reportedCalls", Long.toString(e.reportedCalls));
            properties.setProperty(prefix + "input", Long.toString(e.input));
            properties.setProperty(prefix + "output", Long.toString(e.output));
            properties.setProperty(prefix + "total", Long.toString(e.total));
            properties.setProperty(prefix + "cached", Long.toString(e.cached));
            properties.setProperty(prefix + "cacheWrite", Long.toString(e.cacheWrite));
            properties.setProperty(prefix + "estimatedInput", Long.toString(e.estimatedInput));
        }
    }

    public synchronized void restore(Properties properties) {
        entries.clear();
        int count = (int) boundedNumber(properties, "tokenActivity.count");
        for (int i = 0; i < Math.min(count, MAX_GROUPS); i++) {
            String prefix = "tokenActivity." + i + ".";
            String label = properties.getProperty(prefix + "activity", "");
            if (label.isBlank()) continue;
            Entry e = new Entry();
            e.calls = boundedNumber(properties, prefix + "calls");
            e.reportedCalls = Math.min(e.calls, boundedNumber(properties, prefix + "reportedCalls"));
            e.input = boundedNumber(properties, prefix + "input");
            e.output = boundedNumber(properties, prefix + "output");
            e.total = boundedNumber(properties, prefix + "total");
            e.cached = boundedNumber(properties, prefix + "cached");
            e.cacheWrite = boundedNumber(properties, prefix + "cacheWrite");
            e.estimatedInput = boundedNumber(properties, prefix + "estimatedInput");
            entries.put(label, e);
        }
    }

    private static long boundedNumber(Properties p, String key) {
        try { return Math.max(0, Long.parseLong(p.getProperty(key, "0"))); }
        catch (NumberFormatException ignored) { return 0; }
    }

    private static final class Entry {
        long calls, reportedCalls, input, output, total, cached, cacheWrite, estimatedInput;
    }
}
