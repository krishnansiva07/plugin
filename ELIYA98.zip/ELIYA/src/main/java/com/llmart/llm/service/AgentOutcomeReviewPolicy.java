package com.llmart.llm.service;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HexFormat;
import java.util.Locale;

/**
 * Final verification triage is deliberately conservative. Missing evidence is not an implementation defect.
 * Only a positive verdict backed by a successful real verifier can close an approved plan.
 */
public final class AgentOutcomeReviewPolicy {
    public enum Verdict { SATISFIED, MISSING_EVIDENCE, DEFECT }

    public record Decision(Verdict verdict, String reason) {
        public boolean satisfied() { return verdict == Verdict.SATISFIED; }
        public boolean needsEvidence() { return verdict == Verdict.MISSING_EVIDENCE; }
    }

    private AgentOutcomeReviewPolicy() { }

    public static Decision interpret(String modelResponse) {
        if (modelResponse == null || modelResponse.isBlank())
            return new Decision(Verdict.MISSING_EVIDENCE, "Final reviewer returned no decision; no defect is established");
        String raw = modelResponse.strip();
        String first = raw.lines().findFirst().orElse("").replace("`", "").replace("**", "").strip();
        String upper = first.toUpperCase(Locale.ROOT);
        for (Verdict verdict : Verdict.values()) {
            String name = verdict.name();
            if (!upper.startsWith(name)) continue;
            if (upper.length() > name.length() && !":-—–. \t".contains(upper.substring(name.length(), name.length() + 1))) continue;
            String inline = first.substring(name.length()).replaceFirst("^[\\s:–—.\\-]+", "").strip();
            String remaining = raw.lines().skip(1).reduce("", (a, b) -> a.isEmpty() ? b : a + "\n" + b).strip();
            String reason = inline.isEmpty() ? remaining : remaining.isEmpty() ? inline : inline + "\n" + remaining;
            return new Decision(verdict, reason.isBlank() ? "Reviewer gave no details" : reason);
        }
        // Old reviewers returned CONTINUE for both 'not proven' and 'broken'. Do not invent a defect.
        String reason = upper.startsWith("CONTINUE") ? first.substring(Math.min(8, first.length())).strip() : raw;
        return new Decision(Verdict.MISSING_EVIDENCE,
                reason.isBlank() ? "Outcome not yet supported by available evidence" : reason);
    }

    /** Deterministic, secret-free digest of the *actual evidence*, not merely a mutation counter. */
    public static String fingerprint(String plan, String verification, String changedFileManifest, String diff) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            for (String part : new String[] {plan, verification, changedFileManifest, diff}) {
                byte[] bytes = (part == null ? "" : part).getBytes(StandardCharsets.UTF_8);
                digest.update(Integer.toString(bytes.length).getBytes(StandardCharsets.US_ASCII));
                digest.update((byte) 0);
                digest.update(bytes);
                digest.update((byte) 0);
            }
            return HexFormat.of().formatHex(digest.digest());
        } catch (NoSuchAlgorithmException e) { throw new IllegalStateException("SHA-256 not available", e); }
    }

    /** Never replan or ask the user for routine missing evidence; stop with an explicit unverified outcome. */
    public static String nextAction(Decision decision, boolean alreadyAttempted) {
        if (decision.satisfied()) return "COMPLETE";
        if (alreadyAttempted) return "STOP_UNVERIFIED";
        return decision.needsEvidence() ? "INSPECT_EVIDENCE" : "CORRECT_CONFIRMED_GAP";
    }
}
