package com.llmart.llm.service;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.InvalidPathException;
import java.nio.file.LinkOption;
import java.nio.file.Path;

/** Resolves a command cwd against the immutable selected workspace, never the server process cwd. */
final class WorkspaceCommandPaths {
    private WorkspaceCommandPaths() { }

    static Path resolve(Path workspaceRoot, String cwd) {
        if (workspaceRoot == null) throw new IllegalArgumentException("No active workspace selected");
        Path root = workspaceRoot.toAbsolutePath().normalize();
        if (cwd == null || cwd.isBlank() || ".".equals(cwd.trim())) return root;
        String raw = cwd.trim();
        if (raw.indexOf('\0') >= 0) throw new SecurityException("Invalid command working directory");
        try {
            Path supplied = Path.of(raw);
            // A drive-qualified path has different semantics on POSIX and must never be treated
            // as a relative folder beneath the workspace. Windows Path.isAbsolute handles it.
            if (!supplied.isAbsolute() && raw.matches("(?i)^[a-z]:[\\\\/].*")) {
                throw new SecurityException("Command cwd is not an absolute path on this operating system: " + raw);
            }
            // Preserve legacy support for slash and backslash relative submodule paths.
            // On Windows Path already understands both forms; POSIX normalizes the user-facing
            // backslash notation rather than silently resolving a literal backslash folder.
            if (!supplied.isAbsolute() && raw.indexOf('\\') >= 0) supplied = Path.of(raw.replace('\\', '/'));
            Path target = (supplied.isAbsolute() ? supplied : root.resolve(supplied)).normalize();
            if (!target.startsWith(root)) throw new SecurityException("Command cwd escapes selected workspace: " + raw);
            // Reject symlink traversal even when the lexical path still appears inside the root.
            Path cursor = root;
            for (Path segment : root.relativize(target)) {
                cursor = cursor.resolve(segment);
                if (Files.isSymbolicLink(cursor)) throw new SecurityException("Command cwd follows a symbolic link: " + raw);
            }
            if (!Files.isDirectory(target, LinkOption.NOFOLLOW_LINKS)) {
                throw new IllegalArgumentException("Command cwd is not a directory in selected workspace: " + raw);
            }
            Path canonical = target.toRealPath();
            if (!canonical.startsWith(root)) throw new SecurityException("Command cwd escapes selected workspace: " + raw);
            return canonical;
        } catch (InvalidPathException e) {
            throw new IllegalArgumentException("Invalid command cwd: " + raw, e);
        } catch (IOException e) {
            throw new IllegalArgumentException("Cannot access command cwd: " + raw, e);
        }
    }
}
