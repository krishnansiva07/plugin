package com.llmart.llm.service;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.CodingErrorAction;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.HexFormat;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * Independent, read-only structural verification for small, self-contained Markdown artifacts.
 * It does NOT assert that the content semantically satisfies the user's objective: the approved-plan
 * outcome critic still checks every requirement after this independent structural verifier succeeds.
 * Code, large-task, deleted, mixed-media and repository-wide documentation workflows retain their
 * normal build/test/coverage verification gates.
 */
public final class AgentArtifactVerificationPolicy {
    private static final int MAX_ARTIFACTS = 24;
    private static final long MAX_ARTIFACT_BYTES = 256 * 1024;
    private static final long MAX_TOTAL_BYTES = 1024 * 1024;
    private static final Set<String> MARKDOWN_EXTENSIONS = Set.of(".md", ".markdown");

    public record Result(boolean eligible, boolean passed, String detail) {
        public static Result skip(String why) { return new Result(false, false, why); }
        public static Result fail(String why) { return new Result(true, false, why); }
        public static Result pass(String what) { return new Result(true, true, what); }
    }

    private AgentArtifactVerificationPolicy() { }

    public static Result inspect(Path root, String status, String objective,
                                 boolean documentationMode, boolean largeTaskMode) {
        if (documentationMode || largeTaskMode) return Result.skip("Dedicated documentation/large-task verifier required");
        if (root == null || status == null) return Result.skip("No workspace change inventory");
        String task = objective == null ? "" : objective.toLowerCase(Locale.ROOT);
        if (task.isBlank()) return Result.skip("No original user objective");
        if (!(task.contains(".md") || task.contains("markdown") || task.contains("agent") && task.contains("skill")))
            return Result.skip("Task is not an explicit Markdown artifact request");
        if (task.matches("(?s).*(?:compile|unit test|integration test|regression test|migrat(?:e|ion)|refactor|fix (?:a |the )?bug|modify java|modify typescript|run the tests).*"))
            return Result.skip("Task requires executable/project verification");

        List<String> paths = new ArrayList<>();
        for (String row : status.split("\\R")) {
            if (row.isBlank()) continue;
            if (row.length() < 4 || !row.substring(0, 3).matches("[AM]  "))
                return Result.skip("Non-additive/non-Markdown or unsupported workspace changes");
            String path = row.substring(3).strip();
            if (path.endsWith(" [text diff omitted]")) return Result.skip("Artifact text unavailable");
            String low = path.toLowerCase(Locale.ROOT);
            if (MARKDOWN_EXTENSIONS.stream().noneMatch(low::endsWith))
                return Result.skip("Changed workspace contains non-Markdown artifacts");
            paths.add(path);
        }
        if (paths.isEmpty() || paths.size() > MAX_ARTIFACTS) return Result.skip("No bounded Markdown-only change set");

        try {
            Path verifiedRoot = root.toRealPath();
            long total = 0;
            StringBuilder checked = new StringBuilder();
            for (String relative : paths) {
                Path path = root.resolve(relative).normalize();
                // Reject symlinks, including parent links, before following the path.
                if (!path.toAbsolutePath().normalize().startsWith(root.toAbsolutePath().normalize()))
                    return Result.fail("Artifact path escapes workspace: " + relative);
                Path candidate = path.toAbsolutePath().normalize();
                for (Path segment = candidate; segment != null && segment.startsWith(root.toAbsolutePath().normalize()); segment = segment.getParent()) {
                    if (Files.isSymbolicLink(segment)) return Result.fail("Artifact path traverses a symlink: " + relative);
                    if (segment.equals(root.toAbsolutePath().normalize())) break;
                }
                if (!Files.isRegularFile(candidate, LinkOption.NOFOLLOW_LINKS))
                    return Result.fail("Missing/nonregular artifact: " + relative);
                if (!candidate.toRealPath().startsWith(verifiedRoot))
                    return Result.fail("Artifact resolves outside the workspace: " + relative);
                long size = Files.size(candidate);
                if (size <= 0 || size > MAX_ARTIFACT_BYTES || (total += size) > MAX_TOTAL_BYTES)
                    return Result.skip("Artifact requires specialized verification (empty/oversized): " + relative);
                byte[] data = Files.readAllBytes(candidate);
                String text;
                try {
                    text = StandardCharsets.UTF_8.newDecoder()
                            .onMalformedInput(CodingErrorAction.REPORT)
                            .onUnmappableCharacter(CodingErrorAction.REPORT)
                            .decode(ByteBuffer.wrap(data)).toString();
                } catch (CharacterCodingException badEncoding) {
                    return Result.fail("Artifact is not valid UTF-8: " + relative);
                }
                if (text.strip().length() < 40 || text.indexOf('\0') >= 0)
                    return Result.fail("Artifact content is empty/insufficient: " + relative);
                checked.append(relative).append(" [").append(size).append(" bytes, SHA-256 ")
                        .append(hash(data).substring(0, 16)).append("]; ");
            }
            return Result.pass("Independent read-only Markdown structure check passed for " + paths.size() +
                    " changed artifact(s): " + checked +
                    "Semantic content, target-format compatibility, and approved-plan coverage must still be reviewed.");
        } catch (IOException | SecurityException problem) {
            return Result.fail("Cannot independently inspect Markdown artifacts: " + problem.getClass().getSimpleName());
        }
    }

    private static String hash(byte[] bytes) {
        try { return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(bytes)); }
        catch (NoSuchAlgorithmException error) { throw new IllegalStateException(error); }
    }
}
