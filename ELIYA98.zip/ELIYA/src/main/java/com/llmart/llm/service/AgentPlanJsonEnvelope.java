package com.llmart.llm.service;

/**
 * Extract a complete plan JSON envelope despite common reasoning tags, code fences,
 * leading prose or trailing commentary. No model call or regex-based JSON repair.
 */
final class AgentPlanJsonEnvelope {
    private AgentPlanJsonEnvelope() { }

    static String extract(String raw) {
        if (raw == null || raw.isBlank()) return "";
        String candidate = raw.strip();
        // Some thinking models echo private reasoning in the text field. If a full
        // reasoning block is present, ignore it rather than finding JSON inside it.
        candidate = candidate.replaceAll("(?is)<think>.*?</think>", "").strip();
        int marker = earliestPlanKey(candidate);
        int start = -1;
        if (marker >= 0) start = candidate.lastIndexOf('{', marker);
        if (start < 0) {
            int obj = candidate.indexOf('{');
            int arr = candidate.indexOf('[');
            start = obj < 0 ? arr : arr < 0 ? obj : Math.min(obj, arr);
        }
        if (start < 0) return candidate;
        // Balanced scan honors nested objects/arrays, quoted brackets and escapes.
        int square = 0, curly = 0;
        boolean quoted = false, escape = false;
        for (int i = start; i < candidate.length(); i++) {
            char c = candidate.charAt(i);
            if (escape) { escape = false; continue; }
            if (quoted && c == '\\') { escape = true; continue; }
            if (c == '"') { quoted = !quoted; continue; }
            if (quoted) continue;
            if (c == '{') curly++;
            else if (c == '}') curly--;
            else if (c == '[') square++;
            else if (c == ']') square--;
            if (curly < 0 || square < 0) break;
            if (curly == 0 && square == 0) return candidate.substring(start, i + 1).strip();
        }
        // Preserve the truncated fragment so callers can detect malformed JSON
        // and fall back to the ORIGINAL request, never a partial step list.
        return candidate.substring(start).strip();
    }

    private static int earliestPlanKey(String text) {
        int earliest = -1;
        for (String key : new String[] {"\"plan\"", "\"steps\"", "\"tasks\""}) {
            int from = 0;
            while (true) {
                int idx = text.indexOf(key, from);
                if (idx < 0) break;
                int colon = idx + key.length();
                while (colon < text.length() && Character.isWhitespace(text.charAt(colon))) colon++;
                if (colon < text.length() && text.charAt(colon) == ':') {
                    if (earliest < 0 || idx < earliest) earliest = idx;
                    break;
                }
                from = idx + key.length();
            }
        }
        return earliest;
    }
}
