package com.llmart.llm.service;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Conservative, cached code-flow edges. This is NOT a call graph: an edge is produced only when a
 * literal frontend HTTP path and verb uniquely match an annotated Spring controller route.
 * Dynamic routes, non-literal expressions, and ambiguous handlers intentionally yield no edge.
 * No network access, source execution, or filesystem reads are performed here.
 */
final class WorkspaceFlowIntelligence {
    record Source(String path, String sample) { }
    record Link(String caller, int callerLine, String controller, int controllerLine, String verb, String route) { }
    record Graph(List<Link> links) { }
    private record Route(String file, int line, String method, String path) { }
    private record Call(String file, int line, String method, String path) { }
    private static final Pattern MAPPING = Pattern.compile(
            "@(?:(Get|Post|Put|Patch|Delete)Mapping|RequestMapping)\\s*\\(\\s*(?:(?:value|path)\\s*=\\s*)?[\\\"']([^\\\"']{1,180})[\\\"']([^)]{0,250})\\)", Pattern.CASE_INSENSITIVE);
    private static final Pattern CLASS_DECL = Pattern.compile("\\b(?:class|interface|record)\\s+[A-Za-z_$][\\w$]*");
    private static final Pattern HTTP_CALL = Pattern.compile(
            "(?:(?:\\b(?:axios|http|api|client)|\\bthis\\.(?:http|api|client))\\s*\\.\\s*(get|post|put|patch|delete)(?:\\s*<[^>\\r\\n]{1,120}>)?|\\bfetch)\\s*\\(\\s*([\\\"'`])(/[^\\\"'`\\r\\n]{0,179})\\2", Pattern.CASE_INSENSITIVE);
    private static final Pattern FETCH_METHOD = Pattern.compile("\\bmethod\\s*:\\s*[\\\"'](GET|POST|PUT|PATCH|DELETE)[\\\"']", Pattern.CASE_INSENSITIVE);
    private static final Pattern REQUEST_METHOD = Pattern.compile("\\bRequestMethod\\.(GET|POST|PUT|PATCH|DELETE)\\b", Pattern.CASE_INSENSITIVE);
    private static final int MAX_LINKS = 2_000;
    private static final int MAX_CALLS = 4_000;

    private WorkspaceFlowIntelligence() { }

    static boolean flowQuestion(String question) {
        if (question == null || question.isBlank()) return false;
        String q = question.toLowerCase(Locale.ROOT);
        return q.matches("(?s).*(?:\\bflow\\b|\\btrace\\b|end.to.end|\\bkpi\\b|histogram|calcula(?:te|ted|tion)|\\bdashboard\\b|ui.to.api|frontend.to.backend|request.lifecycle|data.lineage).*");
    }

    static Graph build(List<Source> sources) {
        if (sources == null || sources.isEmpty()) return new Graph(List.of());
        List<Route> routes = new ArrayList<>();
        List<Call> calls = new ArrayList<>();
        for (Source source : sources) {
            if (source.sample() == null || source.sample().isBlank()) continue;
            String path = source.path().toLowerCase(Locale.ROOT);
            if (path.endsWith(".java")) {
                collectSpringRoutes(source, routes);
            } else if (path.matches(".*\\.(?:js|jsx|ts|tsx|mjs|cjs|vue|svelte)$")) {
                collectClientCalls(source, calls);
            }
        }
        Map<String,List<Route>> handlers = new HashMap<>();
        for (Route route : routes) handlers.computeIfAbsent(route.method() + " " + route.path(), k -> new ArrayList<>()).add(route);
        LinkedHashSet<Link> edges = new LinkedHashSet<>();
        for (Call call : calls) {
            List<Route> matching = handlers.getOrDefault(call.method() + " " + call.path(), List.of());
            if (matching.size() != 1) continue; // Do not invent a controller when routes are ambiguous.
            Route handler = matching.get(0);
            if (!handler.file().equals(call.file())) {
                edges.add(new Link(call.file(), call.line(), handler.file(), handler.line(), call.method(), call.path()));
                if (edges.size() >= MAX_LINKS) break;
            }
        }
        return new Graph(List.copyOf(edges));
    }

    private static void collectSpringRoutes(Source source, List<Route> output) {
        String body = withoutComments(source.sample());
        Matcher matcher = MAPPING.matcher(body);
        List<Mapping> mappings = new ArrayList<>();
        while (matcher.find() && mappings.size() < 250) {
            String prefix = matcher.group(1);
            String method = prefix == null ? null : prefix.toUpperCase(Locale.ROOT);
            if (method == null) {
                Matcher requestMethod = REQUEST_METHOD.matcher(matcher.group(3));
                if (requestMethod.find()) method = requestMethod.group(1).toUpperCase(Locale.ROOT);
            }
            String path = normalize(matcher.group(2));
            if (path != null) mappings.add(new Mapping(matcher.start(), matcher.end(), method, path));
        }
        Matcher classDecl = CLASS_DECL.matcher(body);
        int classStart = classDecl.find() ? classDecl.start() : -1;
        String classPath = "";
        for (Mapping map : mappings) {
            if (classStart >= 0 && map.start < classStart && classStart - map.end < 400
                    && map.method == null && body.substring(map.end, classStart).indexOf('{') < 0) {
                classPath = map.path.equals("/") ? "" : map.path;
                break;
            }
        }
        for (Mapping map : mappings) {
            if (output.size() >= MAX_CALLS) return;
            if (map.method == null || map.start < classStart || classStart < 0) continue;
            // Parameterized mappings may match dynamic URLs, but we cannot verify them safely from literals.
            String route = normalize(classPath + (map.path.equals("/") ? "" : map.path));
            if (route == null || route.contains("{") || route.contains("*")) continue;
            output.add(new Route(source.path(), line(body, map.start), map.method, route));
        }
    }

    private record Mapping(int start, int end, String method, String path) { }

    private static void collectClientCalls(Source source, List<Call> output) {
        String body = withoutComments(source.sample());
        Matcher matcher = HTTP_CALL.matcher(body);
        while (matcher.find() && output.size() < MAX_CALLS) {
            String verb = matcher.group(1) == null ? "GET" : matcher.group(1).toUpperCase(Locale.ROOT);
            String route = normalize(matcher.group(3));
            if (route == null || route.contains("$") || route.contains("{") || route.contains("*")) continue;
            if (matcher.group(1) == null) {
                String after = body.substring(matcher.end(), Math.min(body.length(), matcher.end() + 250));
                int closing = after.indexOf(')');
                if (closing >= 0) after = after.substring(0, closing);
                Matcher method = FETCH_METHOD.matcher(after);
                if (method.find()) verb = method.group(1).toUpperCase(Locale.ROOT);
                else if (after.contains("method")) continue; // uncertain dynamic method
            }
            output.add(new Call(source.path(), line(body, matcher.start()), verb, route));
        }
    }

    /** Keep offsets and line numbers stable; treat examples/comments as non-executable. */
    private static String withoutComments(String source) {
        char[] characters = source.toCharArray();
        boolean line = false, block = false, quoted = false, escaped = false;
        char quote = 0;
        for (int i = 0; i < characters.length; i++) {
            char now = source.charAt(i);
            char next = i + 1 < characters.length ? source.charAt(i + 1) : '\0';
            if (line) {
                if (now == '\n') line = false;
                else characters[i] = ' ';
                continue;
            }
            if (block) {
                if (now == '*' && next == '/') {
                    characters[i] = ' '; characters[++i] = ' '; block = false;
                } else if (now != '\n') characters[i] = ' ';
                continue;
            }
            if (quoted) {
                if (escaped) escaped = false;
                else if (now == '\\') escaped = true;
                else if (now == quote) quoted = false;
                continue;
            }
            if (now == '\'' || now == '"' || now == '`') { quoted = true; quote = now; continue; }
            if (now == '/' && next == '/') { characters[i] = ' '; characters[++i] = ' '; line = true; }
            else if (now == '/' && next == '*') { characters[i] = ' '; characters[++i] = ' '; block = true; }
        }
        return new String(characters);
    }

    private static String normalize(String raw) {
        if (raw == null || !raw.startsWith("/") || raw.contains("\\\\") || raw.contains("${")) return null;
        int query = raw.indexOf('?');
        if (query >= 0) raw = raw.substring(0, query);
        raw = raw.replaceAll("/+", "/");
        if (raw.length() > 1 && raw.endsWith("/")) raw = raw.substring(0, raw.length() - 1);
        return raw;
    }

    private static int line(String text, int offset) {
        int result = 1;
        for (int i = 0; i < offset; i++) if (text.charAt(i) == '\n') result++;
        return result;
    }
}
