package com.llmart.llm.service;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Bounded, incremental passage-level retrieval within files selected by the workspace index.
 * This is deliberately lexical and local: a missing embedding provider cannot delay answers.
 * Source is never executed and path/size guards prevent following workspace symlinks.
 */
final class WorkspaceChunkIntelligence {
    private static final int WINDOW = 1_800, OVERLAP = 240;
    private static final int MAX_SOURCE_CHARS = 480_000, MAX_CACHED_FILES = 64;
    private static final Pattern TERMS = Pattern.compile("[A-Za-z][A-Za-z0-9_]{2,79}");
    private final Map<String, Snapshot> snapshots = new ConcurrentHashMap<>();

    record Passage(String path, int startLine, int endLine, String text, double score) { }
    private record Chunk(int startLine, int endLine, String text, Map<String,Integer> tf) { }
    private record Snapshot(long size, long modified, List<Chunk> chunks) { }

    List<Passage> find(Path root, String relative, Set<String> queryTerms, int top) {
        if (root == null || relative == null || queryTerms == null || queryTerms.isEmpty()) return List.of();
        try {
            Path safeRoot = root.toAbsolutePath().normalize();
            Path file = safeRoot.resolve(relative).normalize();
            if (!file.startsWith(safeRoot) || !Files.isRegularFile(file) || Files.isSymbolicLink(file)
                    || !file.toRealPath().startsWith(safeRoot.toRealPath())
                    || Files.size(file) > MAX_SOURCE_CHARS || Files.size(file) == 0) return List.of();
            long size = Files.size(file), modified = Files.getLastModifiedTime(file).toMillis();
            String key = file.toString();
            Snapshot prior = snapshots.get(key);
            if (prior == null || prior.size != size || prior.modified != modified) {
                String content = Files.readString(file, StandardCharsets.UTF_8);
                prior = new Snapshot(size, modified, split(content));
                if (snapshots.size() >= MAX_CACHED_FILES) snapshots.clear();
                snapshots.put(key, prior);
            }
            return rank(relative, prior.chunks(), queryTerms, top);
        } catch (IOException | SecurityException e) { return List.of(); }
    }

    static List<Passage> rankText(String path, String content, Set<String> queryTerms, int top) {
        if (content == null || queryTerms == null || queryTerms.isEmpty()) return List.of();
        return rank(path, split(content), queryTerms, top);
    }

    private static List<Chunk> split(String content) {
        if (content == null || content.isBlank()) return List.of();
        // Prefer entire lines for source references; split oversized lines for safety.
        List<Chunk> chunks = new ArrayList<>();
        String[] lines = content.split("\n", -1);
        StringBuilder current = new StringBuilder();
        int startLine = 1;
        for (int i = 0; i < lines.length; i++) {
            String line = lines[i];
            if (current.length() > 0 && current.length() + line.length() > WINDOW) {
                chunks.add(chunk(startLine, i, current.toString()));
                // Line-based overlap: retain the tail to capture cross-boundary references.
                int tailStart = current.indexOf("\n", Math.max(0, current.length() - OVERLAP));
                String tail = tailStart < 0 ? "" : current.substring(tailStart + 1);
                current.setLength(0);
                current.append(tail);
                int newlines = (int)tail.chars().filter(c -> c == '\n').count();
                startLine = Math.max(1, i - newlines + 1);
            }
            if (current.length() == 0) startLine = i + 1;
            if (line.length() > WINDOW * 2) {
                if (!current.isEmpty()) { chunks.add(chunk(startLine, i + 1, current.toString())); current.setLength(0); }
                for (int off = 0; off < line.length(); off += WINDOW - OVERLAP)
                    chunks.add(chunk(i + 1, i + 1, line.substring(off, Math.min(line.length(), off + WINDOW))));
            } else current.append(line).append('\n');
        }
        if (!current.isEmpty()) chunks.add(chunk(startLine, lines.length, current.toString()));
        return List.copyOf(chunks);
    }

    private static Chunk chunk(int start, int end, String text) {
        Map<String,Integer> freq = new HashMap<>();
        Matcher matcher = TERMS.matcher(text);
        while (matcher.find()) freq.merge(matcher.group().toLowerCase(Locale.ROOT), 1, Integer::sum);
        return new Chunk(start, Math.max(start, end), text, Map.copyOf(freq));
    }

    private static List<Passage> rank(String path, List<Chunk> chunks, Set<String> terms, int top) {
        if (chunks.isEmpty()) return List.of();
        int take = Math.max(1, Math.min(3, top));
        List<Passage> found = new ArrayList<>();
        Map<String,Integer> df = new HashMap<>();
        for (Chunk c : chunks) for (String term : terms)
            if (c.tf.containsKey(term)) df.merge(term, 1, Integer::sum);
        for (Chunk c : chunks) {
            double value = 0;
            for (String term : terms) {
                int tf = c.tf.getOrDefault(term.toLowerCase(Locale.ROOT), 0);
                if (tf == 0) continue;
                double idf = Math.log1p((chunks.size() - df.getOrDefault(term, 0) + .5) /
                        (df.getOrDefault(term, 0) + .5));
                value += idf * (tf * 2.2 / (tf + 1.2));
            }
            if (value > 0) found.add(new Passage(path, c.startLine, c.endLine, c.text, value));
        }
        found.sort(Comparator.comparingDouble(Passage::score).reversed().thenComparingInt(Passage::startLine));
        // Avoid overlapping passages crowding out different areas of a source file.
        List<Passage> diverse = new ArrayList<>();
        for (Passage p : found) {
            if (diverse.stream().anyMatch(s -> Math.abs(s.startLine() - p.startLine()) <= 3)) continue;
            diverse.add(p);
            if (diverse.size() == take) break;
        }
        return List.copyOf(diverse);
    }
}
