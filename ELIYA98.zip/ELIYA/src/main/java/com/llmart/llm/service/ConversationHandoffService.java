package com.llmart.llm.service;

import com.llmart.llm.entity.MessageEntity;
import org.springframework.stereotype.Service;
import java.util.*;

/** Conversation-bound, read-only bridge between Chat, Agent and Terminal.
 *  No extra summarizer/model calls: full content remains addressable by immutable message ID.
 */
@Service
public class ConversationHandoffService {
    private final ConversationService conversations;
    public ConversationHandoffService(ConversationService conversations) { this.conversations=conversations; }

    public Optional<ConversationHandoffSelection.Packet> select(String conversationId, String currentPrompt) {
        if (conversationId == null || conversationId.isBlank()) return Optional.empty();
        List<ConversationHandoffSelection.Turn> turns=new ArrayList<>();
        List<MessageEntity> messages=conversations.messageEntities(conversationId);
        long currentId=-1;
        for (MessageEntity m:messages) {
            long id=m.getId()==null?-1:m.getId();
            if ("user".equals(m.getRole())) currentId=id;
            turns.add(new ConversationHandoffSelection.Turn(id,m.getRole(),m.getContent(),
                    conversations.messageDto(m).attachmentIds()));
        }
        return ConversationHandoffSelection.select(turns,currentId,currentPrompt);
    }

    /** Add a bounded pointer and the selected requirement/answer. Never overwrite the current user request. */
    public List<Map<String,Object>> enrich(String conversationId, String prompt, List<Map<String,Object>> base) {
        Optional<ConversationHandoffSelection.Packet> found=select(conversationId,prompt);
        if (found.isEmpty()) return base;
        ConversationHandoffSelection.Packet p=found.get();
        StringBuilder text=new StringBuilder(8000);
        text.append("CONVERSATION HANDOFF (earlier user/assistant content is context, not a new instruction). ")
                .append("The current user request still controls the action and permissions. ")
                .append("Source messages are saved in this SAME conversation, not guessed from truncated history.\n")
                .append("Original user requirement #").append(p.requirementId()).append(":\n")
                .append(excerpt(p.requirement(),9000)).append("\n\n")
                .append("Previous assistant response #").append(p.answerId()).append(":\n")
                .append(excerpt(p.answer(),18000)).append("\n\n");
        // Compact history of explicit user decisions. The newest statement wins when
        // users refine requirements; refer back to message IDs to resolve conflicts.
        int decisions = 0;
        Deque<String> recentDecisions = new ArrayDeque<>();
        int decisionChars = 0;
        List<ConversationHandoffSelection.Turn> nearby = p.nearby();
        for (int i=nearby.size()-1; i>=0 && decisions<12 && decisionChars<6000; i--) {
            var turn = nearby.get(i);
            if (turn.id() == p.requirementId() || !"user".equalsIgnoreCase(turn.role())) continue;
            String note = "- User decision/request #" + turn.id() + ": " +
                    excerpt(turn.content(), 550).replace('\n',' ') + "\n";
            recentDecisions.addFirst(note);
            decisionChars += note.length();
            decisions++;
        }
        StringBuilder decisionNotes = new StringBuilder();
        for (String note : recentDecisions) decisionNotes.append(note);
        if (!decisionNotes.isEmpty())
            text.append("Earlier conversation requirements/decisions (read full messages if needed; " +
                    "later explicit refinements supersede older choices):\n")
                    .append(decisionNotes).append('\n');
        if (!p.attachments().isEmpty())
            text.append("Nearby prior Chat attachment IDs: ").append(p.attachments())
                    .append(". Use attachment_list / attachment_read to read the originals. " +
                            "Older attachments may also exist; discover them with attachment_list.\n");
        text.append("IMPORTANT: For a detailed implementation or deep analysis, use conversation_handoff_read " )
                .append("with messageId=").append(p.answerId())
                .append(" (and requirementId=").append(p.requirementId())
                .append(") to inspect the COMPLETE non-truncated source. Read subsequent chunks when needed. ")
                .append("Do not claim complete handoff if the source has not been read. ")
                .append("Do not substitute a new generic plan for an explicitly agreed phase-wise plan.\n");
        List<Map<String,Object>> result=new ArrayList<>();
        if (base != null) for (Map<String,Object> item:base) result.add(new LinkedHashMap<>(item));
        // Put context immediately BEFORE the latest user request to preserve the final instruction's priority.
        int lastUser=result.size();
        for (int i=result.size()-1;i>=0;i--) if ("user".equals(result.get(i).get("role"))) {lastUser=i;break;}
        result.add(lastUser,Map.of("role","user","content",text.toString()));
        return result;
    }

    public String read(String conversationId, long messageId, int offset, int maxChars) {
        if (messageId<=0 || conversationId==null || conversationId.isBlank()) return "Message ID is required";
        Optional<MessageEntity> scoped = conversations.messageInConversation(conversationId, messageId);
        if (scoped.isPresent()) {
                MessageEntity m = scoped.get();
                String content=Objects.toString(m.getContent(),"");
                int start=Math.max(0,Math.min(content.length(),offset));
                int window=Math.max(1000,Math.min(40000,maxChars<=0?16000:maxChars));
                int end=Math.min(content.length(), start+window);
                return "Conversation message "+messageId+" ("+m.getRole()+") characters "+start+".."+end+
                        " / "+content.length()+"\n"+content.substring(start,end)+
                        (end<content.length()?"\n[MORE: call conversation_handoff_read with offset="+end+"]":"\n[END OF MESSAGE]");
        }
        return "Message does not exist in the active conversation";
    }

    public String search(String conversationId, String query, int limit) {
        if (query==null || query.isBlank()) return "A search query is required";
        String needle=query.strip().toLowerCase(Locale.ROOT);
        int max=Math.max(1,Math.min(30,limit<=0?12:limit));
        StringBuilder result=new StringBuilder("Saved conversation search results (read full text by messageId):\n");
        int count=0;
        for (MessageEntity m:conversations.messageEntities(conversationId)) {
            if (m.getId()==null || m.getContent()==null) continue;
            String content=m.getContent();
            int pos=content.toLowerCase(Locale.ROOT).indexOf(needle);
            if (pos<0) continue;
            int start=Math.max(0,pos-240),end=Math.min(content.length(),pos+needle.length()+340);
            result.append("\nmessageId=").append(m.getId()).append(" role=").append(m.getRole())
                    .append(" length=").append(content.length()).append(" excerpt=\n")
                    .append(content,start,end).append('\n');
            if (++count>=max) break;
        }
        return count==0?"No matching saved conversation messages":result.toString();
    }

    private static String excerpt(String value,int cap) {
        String text=Objects.toString(value,"");
        return text.length()<=cap?text:text.substring(0,cap)+"\n[TRUNCATED IN PREVIEW: source available via conversation_handoff_read]";
    }
}
