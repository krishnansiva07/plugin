package com.llmart.llm.service;

import java.io.IOException;
import java.nio.file.*;
import java.util.*;

/** Standalone, bounded, read-only Git repository discovery for Agent planning. */
final class AgentGitScope {
    private AgentGitScope() {}

    static boolean isSimpleGitStatusRequest(String task) {
        if (task == null) return false;
        return task.strip().toLowerCase(Locale.ROOT).matches(
                "(?s)^(?:(?:please|can you|could you|do you think|kindly)\\s+)*" +
                "(?:(?:run|show|check|get|execute|display)\\s+)?" +
                "(?:the\\s+)?git\\s+status(?:\\s+(?:command|for\\s+(?:the\\s+)?(?:selected|current)\\s+(?:repo|repository|workspace)))?[.!?\\s]*$");
    }

    static List<java.nio.file.Path> gitRepositories(java.nio.file.Path root) throws java.io.IOException {
        if (root == null || !java.nio.file.Files.isDirectory(root)) return List.of();
        java.util.ArrayDeque<java.util.Map.Entry<java.nio.file.Path,Integer>> queue = new java.util.ArrayDeque<>();
        queue.add(Map.entry(root.toRealPath(), 0));
        java.util.LinkedHashSet<java.nio.file.Path> found = new java.util.LinkedHashSet<>();
        int scanned = 0;
        while (!queue.isEmpty() && scanned++ < 350 && found.size() < 7) {
            var next = queue.removeFirst();
            java.nio.file.Path dir = next.getKey();
            if (java.nio.file.Files.exists(dir.resolve(".git"), java.nio.file.LinkOption.NOFOLLOW_LINKS)) {
                found.add(dir); continue;
            }
            if (next.getValue() >= 3) continue;
            try (var entries = java.nio.file.Files.newDirectoryStream(dir)) {
                for (var entry : entries) {
                    String name = entry.getFileName().toString().toLowerCase(Locale.ROOT);
                    if (Set.of(".git","node_modules","target","build","dist","vendor",".gradle",".idea",".venv","venv","coverage","data").contains(name)) continue;
                    if (java.nio.file.Files.isDirectory(entry, java.nio.file.LinkOption.NOFOLLOW_LINKS))
                        queue.addLast(Map.entry(entry, next.getValue()+1));
                }
            } catch (java.nio.file.AccessDeniedException ignored) { /* inaccessible siblings do not block discovery */ }
        }
        return List.copyOf(found);
    }
}
