package com.llmart.llm.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.stereotype.Service;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.regex.*;

/**
 * Immutable, conversation-bound copies of structured Chat file proposals. Files proposed in
 * Chat are NOT automatically applied to a workspace. Keeping bytes independently from the
 * message renderer prevents a later UI render or stream reconciliation from losing them.
 */
@Service
public class ArtifactVaultService {
    private static final Pattern MARKERS = Pattern.compile(
            "<!--\\s*PROJECT_FILE_START:([^\\n>]+?)\\s*-->([\\s\\S]*?)<!--\\s*PROJECT_FILE_END\\s*-->",
            Pattern.CASE_INSENSITIVE);
    private static final Pattern META = Pattern.compile("<!--\\s*PROJECT_FILE_META:([^>]+?)\\s*-->", Pattern.CASE_INSENSITIVE);
    private static final Pattern FENCE = Pattern.compile("^```[^\\n]*\\n([\\s\\S]*?)\\n```\\s*$");
    private static final int MAX_INPUT = 8_000_000;
    private static final int MAX_ARTIFACTS = 64;
    private static final int MAX_SINGLE_BYTES = 1_500_000;
    private static final int MAX_TOTAL_BYTES = 12_000_000;
    private final Path root;
    private final ObjectMapper json;

    public ArtifactVaultService(ObjectMapper json) {
        this.json = json;
        this.root = Path.of(System.getProperty("eliya.artifacts.store", "./data/assistant-artifacts"))
                .toAbsolutePath().normalize();
    }
    private static void validateConversation(String id) {
        if (id == null || !id.matches("[a-fA-F0-9-]{36}"))
            throw new IllegalArgumentException("Invalid conversation ID");
    }
    private Path directory(String conversationId, long messageId) {
        validateConversation(conversationId);
        if (messageId <= 0) throw new IllegalArgumentException("Invalid message ID");
        return root.resolve(conversationId).resolve(Long.toString(messageId));
    }
    public record Entry(String id, String path, String operation, int bytes) {}
    public record Content(Entry artifact, String content) {}

    /** Idempotent per message. Never includes mutable workspace paths in disk filenames. */
    public synchronized List<Entry> archive(String conversationId, long messageId, String response) throws IOException {
        Path folder = directory(conversationId, messageId);
        if (response == null || response.isBlank() || response.length() > MAX_INPUT) return List.of();
        Path manifest = folder.resolve("manifest.json");
        if (Files.isRegularFile(manifest, LinkOption.NOFOLLOW_LINKS)) return list(conversationId, messageId);
        List<Entry> entries = new ArrayList<>();
        List<String> bodies = new ArrayList<>();
        Matcher match = MARKERS.matcher(response);
        int total = 0;
        while (match.find() && entries.size() < MAX_ARTIFACTS) {
            String meta = match.group(1).trim();
            String path = meta;
            String operation = "write";
            if (meta.startsWith("{")) try {
                @SuppressWarnings("unchecked") Map<String,Object> fields = json.readValue(meta, Map.class);
                path = String.valueOf(fields.getOrDefault("path", ""));
                operation = String.valueOf(fields.getOrDefault("operation", "write"));
            } catch (Exception ignored) { continue; }
            if (path.isBlank() || path.length() > 512 || path.indexOf('\0') >= 0) continue;
            // Paths here are display-only: never use them to construct the storage location.
            String body = match.group(2).strip();
            Matcher embedded = META.matcher(body);
            if (embedded.find()) {
                for (String token : embedded.group(1).split(";")) {
                    String[] pair = token.split("=", 2);
                    if (pair.length == 2 && pair[0].strip().equals("operation")) operation = pair[1].strip();
                }
                body = embedded.replaceFirst("").strip();
            }
            Matcher fence = FENCE.matcher(body);
            if (fence.matches()) body = fence.group(1);
            operation = "delete".equalsIgnoreCase(operation) ? "delete" : "write";
            if ("delete".equals(operation)) body = "";
            byte[] bytes = body.getBytes(StandardCharsets.UTF_8);
            if (bytes.length > MAX_SINGLE_BYTES || total + bytes.length > MAX_TOTAL_BYTES) continue;
            total += bytes.length;
            String id = UUID.randomUUID().toString();
            entries.add(new Entry(id, path.replace('\\','/'), operation, bytes.length));
            bodies.add(body);
        }
        if (entries.isEmpty()) return List.of();
        // Write all content first, then the manifest last. An incomplete directory is ignored.
        Files.createDirectories(folder);
        for (int i = 0; i < entries.size(); i++)
            Files.writeString(folder.resolve(entries.get(i).id() + ".txt"), bodies.get(i), StandardCharsets.UTF_8,
                    StandardOpenOption.CREATE_NEW, StandardOpenOption.WRITE);
        Path temp = folder.resolve("manifest.json.tmp");
        json.writeValue(temp.toFile(), entries);
        try { Files.move(temp, manifest, StandardCopyOption.ATOMIC_MOVE); }
        catch (AtomicMoveNotSupportedException ex) { Files.move(temp, manifest); }
        return List.copyOf(entries);
    }
    public List<Entry> list(String conversationId, long messageId) throws IOException {
        Path manifest = directory(conversationId, messageId).resolve("manifest.json");
        if (!Files.isRegularFile(manifest, LinkOption.NOFOLLOW_LINKS)) return List.of();
        Entry[] data = json.readValue(manifest.toFile(), Entry[].class);
        if (data == null || data.length > MAX_ARTIFACTS) throw new IOException("Artifact index invalid");
        return List.of(data);
    }
    public Content get(String conversationId, long messageId, String id) throws IOException {
        if (id == null || !id.matches("[a-f0-9-]{36}")) throw new IllegalArgumentException("Invalid artifact ID");
        Entry entry = list(conversationId, messageId).stream().filter(e -> id.equals(e.id())).findFirst()
                .orElseThrow(() -> new NoSuchElementException("Artifact not found"));
        Path stored = directory(conversationId, messageId).resolve(id + ".txt");
        if (!Files.isRegularFile(stored, LinkOption.NOFOLLOW_LINKS) || Files.size(stored) > MAX_SINGLE_BYTES)
            throw new IOException("Artifact content missing or exceeds configured limit");
        return new Content(entry, Files.readString(stored, StandardCharsets.UTF_8));
    }
}
