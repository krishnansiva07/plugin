package com.llmart.llm.service;

import com.sun.source.tree.*;
import com.sun.source.util.JavacTask;
import com.sun.source.util.TreePathScanner;
import com.sun.source.util.Trees;
import javax.tools.*;
import java.net.URI;
import java.nio.file.Path;
import java.util.*;
import java.util.regex.*;

/**
 * Bounded, evidence-labeled STATIC relationship graph. An edge is admitted only if its
 * destination can be uniquely resolved from indexed declarations/explicit imports.
 * Dynamic dispatch, reflection, dependency injection and generated code are deliberately
 * left unresolved. Sources are never executed or modified.
 */
final class WorkspaceCallGraphService {
    record Source(String path, String text, WorkspaceCodeIntelligence.Structure structure) {}
    record Edge(String from, int fromLine, String caller, String to, int toLine,
                String callee, String kind) {}
    record Graph(List<Edge> edges, int filesInspected, boolean truncated) {}
    private static final int MAX_FILES = 8_000, MAX_EDGES = 8_000, MAX_CALLS_PER_FILE = 100;
    private static final int MAX_TEXT = 160_000;
    private static final Pattern DIRECT_CALL = Pattern.compile("(?<![\\w$.])([A-Za-z_$][\\w$]*)\\s*\\(");
    private static final Pattern REFERENCE_CALL = Pattern.compile("\\b([A-Za-z_$][\\w$]*)\\s*\\.\\s*([A-Za-z_$][\\w$]*)\\s*\\(");
    private static final Pattern JS_IMPORT = Pattern.compile("(?m)\\bimport\\s+(?:[^;\\n]+?\\s+from\\s+)?['\"]([^'\"]+)['\"]|\\brequire\\s*\\(\\s*['\"]([^'\"]+)['\"]\\s*\\)");
    private static final Pattern PY_IMPORT = Pattern.compile("(?m)^\\s*(?:from\\s+([\\w.]+)\\s+import\\s+([\\w*, ]+)|import\\s+([\\w.]+)(?:\\s+as\\s+(\\w+))?)");
    private static final Pattern CSHARP_NEW = Pattern.compile("\\bnew\\s+([A-Za-z_][\\w]*)\\s*\\(");

    private WorkspaceCallGraphService() {}

    static Graph build(List<Source> input) {
        if (input == null || input.isEmpty()) return new Graph(List.of(), 0, false);
        List<Source> sources = input.size() > MAX_FILES ? input.subList(0, MAX_FILES) : input;
        Map<String,List<Source>> names = new HashMap<>();
        Map<String,List<Source>> qualifiedPaths = new HashMap<>();
        Map<String,Source> paths = new HashMap<>();
        for (Source source : sources) {
            if (source == null || source.path() == null || source.structure() == null) continue;
            String path = norm(source.path()); paths.put(path, source);
            String suffix = path;
            while (true) {
                qualifiedPaths.computeIfAbsent(suffix, k -> new ArrayList<>()).add(source);
                int next = suffix.indexOf('/');
                if (next < 0) break;
                suffix = suffix.substring(next + 1);
            }
            String base = path.substring(path.lastIndexOf('/') + 1).replaceFirst("\\.[^.]+$", "");
            names.computeIfAbsent(base, k -> new ArrayList<>()).add(source);
            for (String symbol : source.structure().symbols().keySet()) {
                String name = symbol.substring(symbol.indexOf(':') + 1);
                if (!name.equals(base) && !symbol.startsWith("method:"))
                    names.computeIfAbsent(name, k -> new ArrayList<>()).add(source);
            }
        }
        LinkedHashSet<Edge> edges = new LinkedHashSet<>();
        for (Source source : sources) {
            if (source == null || source.text() == null || source.structure() == null) continue;
            String content = source.text();
            if (content.length() > MAX_TEXT) content = content.substring(0, MAX_TEXT);
            String path = source.path();
            String lower = path.toLowerCase(Locale.ROOT);
            Map<String,Source> resolved = new LinkedHashMap<>();
            for (String ref : source.structure().references()) {
                Source target = resolve(ref, path, paths, names, qualifiedPaths);
                if (target != null && !target.path().equals(path)) {
                    String alias = ref.replace('\\','/').replaceFirst("\\.(?:ts|tsx|js|jsx|mjs|cjs|py|java)$", "");
                    alias = alias.substring(Math.max(alias.lastIndexOf('/'), alias.lastIndexOf('.')) + 1);
                    resolved.putIfAbsent(alias, target);
                    add(edges, new Edge(path, findLine(content, ref), "import", target.path(), 1, alias, "import"));
                }
            }
            // JS/TS explicit local module imports use exact normalized paths, never basename alone.
            if (lower.matches(".*\\.(ts|tsx|js|jsx|mjs|cjs)$")) {
                Matcher imports = JS_IMPORT.matcher(content);
                while (imports.find()) {
                    String module = imports.group(1) == null ? imports.group(2) : imports.group(1);
                    Source target = resolve(module, path, paths, names, qualifiedPaths);
                    if (target == null || target.path().equals(path)) continue;
                    add(edges, new Edge(path, line(content, imports.start()), "import", target.path(), 1, module, "import"));
                    String statement = content.substring(imports.start(), imports.end()).replace(module, " ");
                    Matcher aliases = Pattern.compile("[A-Za-z_$][\\w$]*").matcher(statement.replaceAll("\\b(?:import|from|type|as|const|var|let|require)\\b", " "));
                    while (aliases.find()) resolved.putIfAbsent(aliases.group(), target);
                }
            }
            if (lower.endsWith(".py")) {
                Matcher imports = PY_IMPORT.matcher(content);
                while (imports.find()) {
                    String module = imports.group(1) == null ? imports.group(3) : imports.group(1);
                    Source target = resolve(module, path, paths, names, qualifiedPaths);
                    if (target == null || target.path().equals(path)) continue;
                    add(edges, new Edge(path, line(content, imports.start()), "import", target.path(), 1, module, "import"));
                    if (imports.group(1) != null) {
                        for (String imported : imports.group(2).split(",")) {
                            String symbol = imported.strip().split("\\s+")[0];
                            if (target.structure().symbols().keySet().stream().anyMatch(k -> k.endsWith(":" + symbol)))
                                resolved.putIfAbsent(symbol, target);
                        }
                    } else resolved.putIfAbsent(imports.group(4) == null ? module.substring(module.lastIndexOf('.') + 1) : imports.group(4), target);
                }
            }
            // Explicit receiver calls are only reported when an imported target actually declares the method.
            // Calls made through runtime-created objects remain unresolved unless the receiver is statically known.
            if (!lower.endsWith(".java")) {
                Matcher call = REFERENCE_CALL.matcher(content); int count = 0;
                while (call.find() && count++ < MAX_CALLS_PER_FILE && edges.size() < MAX_EDGES) {
                    Source target = resolved.get(call.group(1));
                    if (target == null) continue;
                    String symbol = call.group(2);
                    int destLine = uniqueMethodLine(target, symbol);
                    if (destLine > 0) add(edges, new Edge(path, line(content, call.start()), call.group(1),
                            target.path(), destLine, symbol, "call"));
                }
                // Direct calls are provable only for named functions explicitly imported
                // from a resolved module (not arbitrary same-name workspace functions).
                Matcher direct = DIRECT_CALL.matcher(content); int directCalls = 0;
                while (direct.find() && directCalls++ < MAX_CALLS_PER_FILE && edges.size() < MAX_EDGES) {
                    String symbol = direct.group(1);
                    Source target = resolved.get(symbol);
                    if (target == null) continue;
                    int dest = uniqueMethodLine(target, symbol);
                    if (dest > 0) add(edges, new Edge(path, line(content, direct.start()), symbol,
                            target.path(), dest, symbol, "call"));
                }
                if (lower.endsWith(".cs")) {
                    Matcher callNew = CSHARP_NEW.matcher(content);
                    while (callNew.find() && edges.size() < MAX_EDGES) {
                        Source dest = unique(names.get(callNew.group(1)));
                        if (dest != null && !dest.path().equals(path))
                            add(edges, new Edge(path, line(content, callNew.start()), "new", dest.path(), 1, callNew.group(1), "construct"));
                    }
                }
            } else javaCalls(path, content, source, names, resolved, edges);
            if (edges.size() >= MAX_EDGES) break;
        }
        return new Graph(List.copyOf(edges), sources.size(), input.size() > MAX_FILES || edges.size() >= MAX_EDGES);
    }

    private static void javaCalls(String path, String source, Source owner, Map<String,List<Source>> names,
                                  Map<String,Source> resolved, Set<Edge> edges) {
        JavaCompiler compiler = ToolProvider.getSystemJavaCompiler();
        if (compiler == null || source.isBlank()) return;
        String safe = path.replaceAll("[^A-Za-z0-9_$]", "_");
        JavaFileObject file = new SimpleJavaFileObject(URI.create("string:///" + safe + ".java"), JavaFileObject.Kind.SOURCE) {
            @Override public CharSequence getCharContent(boolean ignored) { return source; }
        };
        try (StandardJavaFileManager manager = compiler.getStandardFileManager(null, Locale.ROOT, null)) {
            JavacTask task = (JavacTask) compiler.getTask(null, manager, diagnostic -> {}, List.of("-proc:none"), null, List.of(file));
            for (CompilationUnitTree unit : task.parse()) {
                Trees trees = Trees.instance(task);
                new TreePathScanner<Void,Void>() {
                    private String currentMethod = "";
                    private final Map<String,String> types = new HashMap<>();
                    private int calls;
                    private int at(Tree n) {
                        long pos = trees.getSourcePositions().getStartPosition(unit, n);
                        return pos < 0 || unit.getLineMap() == null ? 0 : (int)unit.getLineMap().getLineNumber(pos);
                    }
                    @Override public Void visitMethod(MethodTree n, Void ignored) {
                        String old = currentMethod; currentMethod = n.getName().toString();
                        Map<String,String> previousTypes = new HashMap<>(types);
                        for (VariableTree arg : n.getParameters()) types.put(arg.getName().toString(), arg.getType().toString());
                        super.visitMethod(n, ignored);
                        types.clear(); types.putAll(previousTypes);
                        currentMethod = old; return null;
                    }
                    @Override public Void visitVariable(VariableTree n, Void ignored) {
                        if (n.getType() != null) types.put(n.getName().toString(), n.getType().toString());
                        return super.visitVariable(n, ignored);
                    }
                    @Override public Void visitMethodInvocation(MethodInvocationTree n, Void ignored) {
                        if (calls++ < MAX_CALLS_PER_FILE && edges.size() < MAX_EDGES) {
                            String method; Source target = null;
                            if (n.getMethodSelect() instanceof MemberSelectTree member) {
                                method = member.getIdentifier().toString();
                                String receiver = member.getExpression().toString();
                                String type = types.getOrDefault(receiver, receiver);
                                type = type.replaceAll("<.*", "");
                                target = resolved.get(type);
                                if (target == null && !type.contains(".") && (types.containsKey(receiver) || Character.isUpperCase(type.charAt(0)))) target = unique(names.get(type));
                            } else {
                                method = n.getMethodSelect().toString(); target = owner;
                            }
                            if (target != null) {
                                int dest = uniqueMethodLine(target, method);
                                if (dest > 0 && (!target.path().equals(path) || !method.equals(currentMethod)))
                                    add(edges, new Edge(path, at(n), currentMethod, target.path(), dest, method, "call"));
                            }
                        }
                        return super.visitMethodInvocation(n, ignored);
                    }
                    @Override public Void visitNewClass(NewClassTree n, Void ignored) {
                        String type = n.getIdentifier().toString().replaceAll("<.*", "");
                        Source dest = resolved.getOrDefault(type, unique(names.get(type)));
                        if (dest != null && !dest.path().equals(path) && edges.size() < MAX_EDGES)
                            add(edges, new Edge(path, at(n), currentMethod, dest.path(), 1, type, "construct"));
                        return super.visitNewClass(n, ignored);
                    }
                }.scan(unit, null);
            }
        } catch (Exception ignored) { /* syntax errors or missing compiler: do not invent edges */ }
    }

    private static int uniqueMethodLine(Source s, String name) {
        Integer line = null;
        for (var e : s.structure().symbols().entrySet()) {
            if (!e.getKey().equals("method:" + name) && !e.getKey().equals("function:" + name) && !e.getKey().equals("def:" + name) && !e.getKey().equals("symbol:" + name)) continue;
            if (line != null && !line.equals(e.getValue())) return 0;
            line = e.getValue();
        }
        return line == null ? 0 : line;
    }
    private static Source resolve(String ref, String source, Map<String,Source> paths,
                                  Map<String,List<Source>> names, Map<String,List<Source>> qualifiedPaths) {
        if (ref == null || ref.isBlank() || ref.startsWith("http:") || ref.startsWith("https:")) return null;
        String value = ref.replace('\\','/');
        if (value.startsWith(".")) {
            try {
                Path parent = Path.of(norm(source)).getParent();
                String raw = (parent == null ? Path.of("") : parent).resolve(value).normalize().toString().replace('\\','/');
                if (raw.startsWith("../") || raw.startsWith("/") || raw.equals("..")) return null;
                for (String ext : List.of("", ".ts", ".tsx", ".js", ".jsx", ".py", "/index.ts", "/index.js")) {
                    Source result = paths.get(raw + ext); if (result != null) return result;
                }
            } catch (Exception ignored) { return null; }
            return null;
        }
        String qualified = value.replace('.', '/');
        Source direct = paths.get(qualified);
        if (direct != null) return direct;
        List<Source> found = new ArrayList<>();
        for (String ext : List.of(".java", ".py", "/__init__.py", ".cs", ".go"))
            found.addAll(qualifiedPaths.getOrDefault(qualified + ext, List.of()));
        Source exact = unique(found);
        if (exact != null) return exact;
        // Go imports are package paths, not filenames. A unique local directory match
        // provides an import edge; packages with multiple candidate files are ambiguous.
        if (ref.contains("/") && source.toLowerCase(Locale.ROOT).endsWith(".go")) {
            for (var entry : paths.entrySet()) {
                String relative = entry.getKey(); int split = relative.lastIndexOf('/');
                String folder = split < 0 ? "" : relative.substring(0, split);
                if (folder.equals(qualified) || folder.endsWith("/" + qualified)) found.add(entry.getValue());
            }
            Source packageFile = unique(found);
            if (packageFile != null) return packageFile;
        }
        // Do not resolve external npm/pip/Go dependencies by a coincidental local basename.
        if (ref.contains("/") || ref.contains(".")) return null;
        return unique(names.get(ref));
    }
    private static Source unique(List<Source> sources) {
        if (sources == null || sources.isEmpty()) return null;
        Source chosen = sources.get(0);
        for (Source other : sources) if (!other.path().equals(chosen.path())) return null;
        return chosen;
    }
    private static void add(Set<Edge> edges, Edge edge) { if (edge.fromLine() > 0 && edge.toLine() > 0 && edges.size() < MAX_EDGES) edges.add(edge); }
    private static int findLine(String text, String target) { int index = text.indexOf(target); return index < 0 ? 0 : line(text, index); }
    private static int line(String text, int offset) { int result = 1; for (int i = 0; i < offset && i < text.length(); i++) if (text.charAt(i)=='\n') result++; return result; }
    private static String norm(String path) { return path.replace('\\','/'); }
}
