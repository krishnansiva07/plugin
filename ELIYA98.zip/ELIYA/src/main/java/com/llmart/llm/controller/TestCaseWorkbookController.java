package com.llmart.llm.controller;

import com.llmart.llm.service.TestCaseWorkbookService;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/artifacts/testcases")
public class TestCaseWorkbookController {
    private final TestCaseWorkbookService service;
    public TestCaseWorkbookController(TestCaseWorkbookService service) { this.service = service; }
    @PostMapping
    public Map<String,Object> start(@RequestHeader("Authorization") String auth,
                                    @RequestBody TestCaseWorkbookService.Request input) {
        if (auth == null || !auth.startsWith("Bearer ")) throw new IllegalArgumentException("Model key required");
        return service.start(auth.substring(7), input).snapshot();
    }
    @GetMapping("/{id}")
    public Map<String,Object> status(@PathVariable String id, @RequestParam String conversationId) {
        return service.require(conversationId, id).snapshot();
    }
    @PostMapping("/{id}/cancel")
    public Map<String,Object> cancel(@PathVariable String id,@RequestParam String conversationId) {
        return service.cancel(conversationId,id);
    }
    @GetMapping(value="/{id}/download", produces="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
    public ResponseEntity<byte[]> download(@PathVariable String id, @RequestParam String conversationId) {
        var job = service.require(conversationId, id);
        if (job.workbook == null) return ResponseEntity.status(HttpStatus.CONFLICT).build();
        return ResponseEntity.ok().contentType(MediaType.parseMediaType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"))
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=ELIYA_Test_Cases.xlsx")
                .header("Cache-Control", "no-store")
                .body(job.workbook);
    }
}
