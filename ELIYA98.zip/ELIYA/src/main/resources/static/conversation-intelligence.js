/* ELIYA80: conversational continuation is a presentation/context concern, NOT a second LLM planner.
 * All facts still come from retrieval and the model. Suggestions do not assert unverified findings.
 */
(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  if (root) root.EliyaConversationIntelligence = api;
})(typeof window !== 'undefined' ? window : null, function () {
  'use strict';
  const accepted = /^(?:yes(?: please)?|sure|ok(?:ay)?|go ahead|continue|please continue|proceed|do it|yes[, ]+proceed)[.!\s]*$/i;
  const declined = /^(?:no(?: thanks| thank you)?|not now|that's all|nothing else)[.!\s]*$/i;
  const questionInAnswer = /(?:would you like|do you want|shall i|should i|want me to|need me to)[^?]{0,230}\?\s*$/i;
  const technical = /\b(?:workspace|source|project|repository|framework|architecture|module|class|method|api|flow|ticket|jira|regression|test|error|skill|agent|dependency|deep search)\b/i;
  const reliable = output => String(output || '').trim().length >= 80 && !/^(?:task (?:failed|stopped)|completed successfully|the agent could not|an error occurred)/i.test(String(output).trim());
  function suggest({prompt = '', answer = '', mode = 'analyse', success = true} = {}) {
    const p = String(prompt).trim(), a = String(answer).trim();
    if (!success || !reliable(a) || !technical.test(p) || questionInAnswer.test(a) || /\?\s*$/.test(a)) return '';
    if (/\b(?:jira|ticket|[A-Z][A-Z0-9]+-\d+)\b/i.test(p) && /\b(?:compare|gap|missing|analyse|analyze|review)\b/i.test(p))
      return 'Would you like me to investigate any finding further or implement the identified changes?';
    if (/\b(?:create|generate|fix|implement|modify|update|build|migrate|add)\b/i.test(p) && mode === 'execute')
      return 'Would you like me to improve or extend anything in the completed work?';
    if (/\b(?:workspace|repository|project|codebase)\b/i.test(p))
      return 'Would you like to explore a specific module or trace its end-to-end architecture?';
    if (/\b(?:architecture|flow|deep search|dependency)\b/i.test(p))
      return 'Would you like me to trace a specific component or investigate any architectural gaps?';
    if (/\b(?:test|failure|regression|error)\b/i.test(p))
      return 'Would you like a deeper root-cause analysis or a proposed implementation plan?';
    return '';
  }
  // A free-form answer is ALWAYS passed through unchanged. Do not assume an isolated "yes"
  // authorises an implementation after a multi-option suggestion.
  function resolve(text, suggestion) {
    const value = String(text || '').trim(), s = String(suggestion || '');
    if (!accepted.test(value) || !s) return {text:value, action:'original'};
    if (/implement .*\?\s*$/i.test(s) && !/ or /i.test(s)) return {text:'Please implement the changes we just discussed.', action:'execute'};
    if (/explore a specific module|trace its end-to-end architecture/i.test(s))
      return {text:'Please analyse the workspace architecture and suggest relevant modules for a deeper investigation.', action:'analyse'};
    if (/trace a specific component|architectural gaps/i.test(s))
      return {text:'Please investigate architecture gaps in more detail using the workspace index.', action:'analyse'};
    if (/improve or extend/i.test(s))
      return {text:'Please review the completed work and suggest useful enhancements. Do not change files yet.', action:'analyse'};
    return {text:value, action:'original'}; // ambiguous multi-option question
  }
  return Object.freeze({suggest,resolve,isDecline: value => declined.test(String(value||'').trim())});
});
