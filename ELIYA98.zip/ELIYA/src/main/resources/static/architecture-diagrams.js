/* ELIYA81: bounded, dependency-free diagram rendering for simple Mermaid flowcharts.
 * Unrecognized syntax falls back to regular code. No generated HTML is executed.
 */
(function (root, factory) {
  const api=factory(); if(typeof module==='object'&&module.exports)module.exports=api;
  if(root)root.EliyaArchitectureDiagrams=api;
})(typeof window!=='undefined'?window:null,function(){
  'use strict';
  const esc=v=>String(v||'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const node=/^([\w-]{1,40})(?:\[([^\]\n]{1,90})\]|\{([^}\n]{1,90})\}|\(([^)\n]{1,90})\))?$/;
  function render(src){
    const source=String(src||'').trim();
    if(source.length>8000)return '';
    const rows=source.split(/\r?\n/).map(x=>x.trim()).filter(x=>x&&!x.startsWith('%%'));
    if(!/^(?:flowchart|graph)\s+(?:TD|TB|LR|RL)\s*$/i.test(rows[0]||''))return '';
    const horizontal=/\b(?:LR|RL)\b/i.test(rows[0]);
    const nodes=new Map(),edges=[];
    for(const row of rows.slice(1)){
      if(nodes.size>18 || edges.length>30)return '';
      const bits=row.split(/\s*(?:-->|==>|-.->)\s*/);
      if(bits.length>4)return '';
      const ids=[];
      for(const part of bits){
        const match=node.exec(part.trim());
        if(!match)return '';
        const id=match[1],text=(match[2]||match[3]||match[4]||id).replace(/<[^>]+>/g,'').slice(0,80);
        if(!nodes.has(id))nodes.set(id,{id,text,decision:Boolean(match[3])});
        else if(match[2]||match[3]||match[4])nodes.set(id,{id,text,decision:Boolean(match[3])});
        ids.push(id);
      }
      for(let i=1;i<ids.length;i++)edges.push([ids[i-1],ids[i]]);
    }
    if(!nodes.size)return '';
    // Bounded level assignment. Cycles are allowed, but cannot cause endless layout.
    const levels=new Map([...nodes.keys()].map(id=>[id,0]));
    for(let repeat=0;repeat<Math.min(nodes.size,12);repeat++){
      let changed=false;
      for(const [from,to] of edges){if(from===to)continue;
        const next=Math.min(11,(levels.get(from)||0)+1);
        if(next>(levels.get(to)||0)){levels.set(to,next);changed=true;}
      }
      if(!changed)break;
    }
    const lanes=new Map();for(const id of nodes.keys()){
      const level=levels.get(id)||0;if(!lanes.has(level))lanes.set(level,[]);lanes.get(level).push(id);
    }
    const xPos=new Map(), stepX=horizontal?215:225,stepY=horizontal?110:110;
    let maxLane=1;
    for(const [level,items] of lanes){maxLane=Math.max(maxLane,items.length);
      items.forEach((id,row)=>xPos.set(id,horizontal?{x:105+level*stepX,y:65+row*stepY}:{x:110+row*stepX,y:65+level*stepY}));
    }
    const maxLevel=Math.max(...lanes.keys());
    const width=horizontal?Math.min(2900,(maxLevel+1)*stepX+30):Math.min(2900,maxLane*stepX+40);
    const height=horizontal?maxLane*stepY+35:(maxLevel+1)*stepY+35;
    const segments=[];
    for(const [a,b] of edges){const p=xPos.get(a),q=xPos.get(b);if(!p||!q)continue;
      const x1=p.x+(horizontal?79:0),y1=p.y+(horizontal?0:27),x2=q.x-(horizontal?79:0),y2=q.y-(horizontal?0:27);
      segments.push(`<path d="M${x1} ${y1} L${x2} ${y2}" stroke="#7898c6" stroke-width="1.7" fill="none" marker-end="url(#eliya81-arrow)"/>`);
    }
    for(const n of nodes.values()){
      const p=xPos.get(n.id),label=n.text.length>27?n.text.slice(0,26)+'…':n.text;
      segments.push(n.decision
        ? `<path d="M${p.x} ${p.y-37} L${p.x+88} ${p.y} L${p.x} ${p.y+37} L${p.x-88} ${p.y} Z" fill="#eaf2ff" stroke="#618bce"/>`
        : `<rect x="${p.x-85}" y="${p.y-32}" width="170" height="64" rx="12" fill="#f2f6fc" stroke="#abc1e1"/>`);
      segments.push(`<text x="${p.x}" y="${p.y+5}" text-anchor="middle" font-size="13" font-family="system-ui,sans-serif" fill="#254165">${esc(label)}</text>`);
    }
    return `<section class="eliya-architecture-diagram" aria-label="Architecture flow diagram"><svg role="img" aria-label="Flowchart with ${nodes.size} components" viewBox="0 0 ${width} ${height}" width="${width}" height="${height}" xmlns="http://www.w3.org/2000/svg"><defs><marker id="eliya81-arrow" markerWidth="9" markerHeight="9" refX="6" refY="3" orient="auto"><path d="M0 0 L6 3 L0 6" stroke="#7898c6" fill="none"/></marker></defs>${segments.join('')}</svg><details><summary>View diagram source</summary><pre>${esc(source)}</pre></details></section>`;
  }
  return Object.freeze({render});
});
