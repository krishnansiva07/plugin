package com.llmart.llm.service;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class AgentPromptCachePolicyTest {
    @Test void officialHostOnlyAndHttps() {
        assertTrue(AgentPromptCachePolicy.supportsKey("https://api.openai.com/v1"));
        assertFalse(AgentPromptCachePolicy.supportsKey("http://api.openai.com/v1"));
        assertFalse(AgentPromptCachePolicy.supportsKey("https://api.openai.com.evil.example/v1"));
        assertFalse(AgentPromptCachePolicy.supportsKey("https://internal-cib-gateway/v1"));
    }
    @Test void stableNonRevealingAffinity() {
        String key = AgentPromptCachePolicy.affinity("C:\\sensitive\\path", "qwen");
        assertEquals(key, AgentPromptCachePolicy.affinity("C:\\sensitive\\path", "qwen"));
        assertFalse(key.contains("sensitive"));
        assertNotEquals(key, AgentPromptCachePolicy.affinity("other-session", "qwen"));
    }
    @Test void fallbacksRequireExplicitPreExecutionRejection() {
        assertTrue(AgentPromptCachePolicy.streamRejected(400, "stream_options unsupported"));
        assertFalse(AgentPromptCachePolicy.streamRejected(400, "messages invalid"));
        assertFalse(AgentPromptCachePolicy.streamRejected(503, "streaming unavailable"));
        assertTrue(AgentPromptCachePolicy.keyRejected(422, "unknown parameter prompt_cache_key"));
        assertFalse(AgentPromptCachePolicy.keyRejected(400, "context length exceeded"));
    }
}
