package com.llmart.llm.service;

import org.junit.jupiter.api.Test;

import java.util.Map;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;

class AgentToolPolicyTest {
    private final AgentToolRegistry registry = new AgentToolRegistry();
    private final AgentProfileService profiles = new AgentProfileService();

    @Test
    void reviewerRoleCannotAccessMutatingOrRemoteTools() {
        AgentProfileService.AgentProfile reviewer = new AgentProfileService.AgentProfile(
                "reviewer", "audit", "subagent", "", "Inspect only", Set.of(),
                Map.of("edit", "deny", "bash", "deny", "mcp", "deny"));
        for (String command : Set.of("edit", "write", "delete", "apply_patch", "resource_write", "bash",
                "resource_bash", "process_start", "http_request", "mcp__gitlab__create_issue", "tool_search",
                "presentation_create", "confluence_compose", "documentation_exclude_module")) {
            assertEquals("deny", AgentToolPolicy.decision(reviewer, command, registry), command);
            assertFalse(AgentToolPolicy.visible(reviewer, command, registry), command);
        }
        assertTrue(AgentToolPolicy.visible(reviewer, "read", registry));
        assertTrue(AgentToolPolicy.visible(reviewer, "grep", registry));
        assertTrue(AgentToolPolicy.visible(reviewer, "code_impact", registry));
    }

    @Test
    void yamlNestedToolsAndPermissionsAreUnderstood() {
        var profile = profiles.parse("quality-review", """
                ---
                description: Quality reviewer
                mode: subagent
                tools:
                  read: true
                  grep: true
                  write: false
                permission:
                  edit: deny
                  bash: deny
                  mcp: deny
                ---
                Only report evidence.
                """);
        assertEquals("Quality reviewer", profile.description());
        assertEquals(Set.of("read", "grep"), profile.allowedTools());
        assertEquals("deny", AgentToolPolicy.decision(profile, "resource_write", registry));
        assertEquals("deny", AgentToolPolicy.decision(profile, "bash", registry));
        assertEquals("deny", AgentToolPolicy.decision(profile, "mcp__jira__update", registry));
    }

    @Test
    void askIsNotSilentlyPromotedToAllow() {
        var profile = profiles.parse("developer", """
                ---
                permission:
                  edit: ask
                  bash: ask
                ---
                Implement carefully.
                """);
        assertEquals("ask", AgentToolPolicy.decision(profile, "write", registry));
        assertEquals("ask", AgentToolPolicy.decision(profile, "test", registry));
        assertEquals("inherit", AgentToolPolicy.decision(profile, "read", registry));
    }

    @Test
    void resourceWildcardCannotSilentlyWidenPermissions() {
        assertThrows(IllegalArgumentException.class, () -> profiles.parse("unsafe", """
                ---
                permission:
                  bash:
                    "*": allow
                ---
                Instructions
                """));
        assertThrows(IllegalArgumentException.class, () -> profiles.parse("unsafe", """
                ---
                permission:
                  edit: probably
                ---
                Instructions
                """));
    }

    @Test
    void userProfileMayInheritWhenNoPoliciesProvided() {
        var profile = profiles.parse("custom", """
                ---
                tools: [read, grep]
                ---
                Analyze source.
                """);
        assertEquals(Set.of("read", "grep"), profile.allowedTools());
        assertEquals("inherit", AgentToolPolicy.decision(profile, "read", registry));
    }
    @Test
    void inlineToolFlagsAreParsedAndUnsafeBuiltInOverrideStaysReadonly() {
        var profile = profiles.parse("reviewer", """
                ---
                tools: {read: true, grep: true, write: false}
                permission:
                  edit: allow
                  bash: allow
                  mcp: allow
                ---
                Project specific reviewer instructions.
                """);
        assertEquals(Set.of("read", "grep"), profile.allowedTools());
        assertEquals("deny", AgentToolPolicy.decision(profile, "write", registry));
        assertEquals("deny", AgentToolPolicy.decision(profile, "bash", registry));
        assertEquals("deny", AgentToolPolicy.decision(profile, "mcp__jira__update", registry));
    }

}
