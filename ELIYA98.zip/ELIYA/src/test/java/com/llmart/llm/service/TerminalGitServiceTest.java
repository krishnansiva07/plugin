package com.llmart.llm.service;

import com.llmart.llm.dto.ProjectDto;
import com.llmart.llm.entity.ProjectWorkspaceEntity;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.*;
import java.time.Instant;
import java.util.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

class TerminalGitServiceTest {
    @TempDir Path workspace;
    private void git(Path dir, String... arguments) throws Exception {
        var command = new ArrayList<String>(); command.add("git"); command.add("-C"); command.add(dir.toString());
        command.addAll(List.of(arguments));
        Process process = new ProcessBuilder(command).redirectErrorStream(true).start();
        String result = new String(process.getInputStream().readAllBytes());
        assertEquals(0, process.waitFor(), result);
    }
    private void initialize(String repoName) throws Exception {
        Path repo = Files.createDirectory(workspace.resolve(repoName));
        git(repo,"init"); git(repo,"config","user.name","ELIYA Test");
        git(repo,"config","user.email","test@example.local");
        Files.writeString(repo.resolve("source.txt"),repoName);
        git(repo,"add","."); git(repo,"commit","-m","initial");
    }
    @Test void choosesRepositoryWithoutMutatingAnotherRepository() throws Exception {
        initialize("service-a"); initialize("service-b");
        ProjectService projects = mock(ProjectService.class);
        ProjectWorkspaceEntity selected = mock(ProjectWorkspaceEntity.class);
        when(projects.require("selected")).thenReturn(selected);
        when(selected.hasLocalPath()).thenReturn(true);
        when(selected.getLocalPath()).thenReturn(workspace.toString());
        var service = new TerminalGitService(projects);
        assertEquals(2, service.repositories("selected").size());
        service.createBranch("selected", "service-b", "feature/code-review");
        assertEquals("feature/code-review", branchExists(workspace.resolve("service-b")));
        assertEquals("", branchExists(workspace.resolve("service-a")));
        assertThrows(Exception.class, ()->service.createBranch("selected", "../service-b", "bad"));
        assertThrows(Exception.class, ()->service.createBranch("selected", "service-a", "-invalid"));
    }
    private String branchExists(Path repo) throws Exception {
        Process p = new ProcessBuilder("git", "-C", repo.toString(), "branch", "--list", "feature/code-review")
                .redirectErrorStream(true).start();
        String output = new String(p.getInputStream().readAllBytes());
        assertEquals(0, p.waitFor());
        return output.contains("feature/code-review") ? "feature/code-review" : "";
    }
    @Test void worktreeCreatesSeparateMappedWorkspace() throws Exception {
        initialize("service-a");
        ProjectService projects = mock(ProjectService.class);
        ProjectWorkspaceEntity selected = mock(ProjectWorkspaceEntity.class);
        when(projects.require("selected")).thenReturn(selected);
        when(selected.hasLocalPath()).thenReturn(true);
        when(selected.getLocalPath()).thenReturn(workspace.toString());
        when(projects.createLocal(eq("conversation"), anyString(), anyString()))
                .thenAnswer(invocation -> new ProjectDto("separate", "conversation", invocation.getArgument(2),0,0,0,
                        invocation.getArgument(1),true,Instant.now(),Instant.now()));
        String original = System.getProperty("eliya.terminal.worktrees");
        try {
            System.setProperty("eliya.terminal.worktrees", workspace.resolve("trees").toString());
            Map<String,Object> result = new TerminalGitService(projects).createWorktree("selected", "service-a", "feature/isolated", "conversation");
            assertEquals("separate",result.get("projectId"));
            assertTrue(Files.exists(Path.of(result.get("path").toString()).resolve("source.txt")));
            assertNotEquals(workspace.resolve("service-a"),Path.of(result.get("path").toString()));
        } finally {
            if (original == null) System.clearProperty("eliya.terminal.worktrees");
            else System.setProperty("eliya.terminal.worktrees",original);
        }
    }
}
