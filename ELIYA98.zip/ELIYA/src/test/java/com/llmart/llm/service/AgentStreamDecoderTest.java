package com.llmart.llm.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import java.util.ArrayList;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

class AgentStreamDecoderTest {
    private final ObjectMapper mapper = new ObjectMapper();

    @Test void reconstructsFragmentedToolArgumentsInIndexOrder() throws Exception {
        List<String> received = new ArrayList<>();
        AgentStreamDecoder decoder = new AgentStreamDecoder(mapper, received::add);
        assertFalse(decoder.accept("{\"choices\":[{\"delta\":{\"content\":\"Inspecting \"},\"finish_reason\":null}]}"));
        assertFalse(decoder.accept("{\"choices\":[{\"delta\":{\"tool_calls\":[{\"index\":0,\"id\":\"call_1\",\"function\":{\"name\":\"read\",\"arguments\":\"{\\\"pa\"}}]},\"finish_reason\":null}]}"));
        assertFalse(decoder.accept("{\"choices\":[{\"delta\":{\"tool_calls\":[{\"index\":0,\"function\":{\"arguments\":\"th\\\":\\\"README.md\\\"}\"}}]},\"finish_reason\":null}]}"));
        assertFalse(decoder.accept("{\"choices\":[{\"delta\":{},\"finish_reason\":\"tool_calls\"}]}"));
        assertFalse(decoder.accept("{\"choices\":[],\"usage\":{\"prompt_tokens\":100,\"completion_tokens\":12}}"));
        assertTrue(decoder.accept("[DONE]"));
        assertEquals("Inspecting ", decoder.content());
        assertEquals("read", decoder.toolCalls().get(0).name());
        assertEquals("README.md", decoder.toolCalls().get(0).arguments().path("path").asText());
        assertEquals("tool_calls", decoder.finishReason());
        assertEquals(100, decoder.usage().path("prompt_tokens").asInt());
        assertTrue(decoder.hasResult());
        assertEquals(List.of("Inspecting "), received);
    }

    @Test void partialToolArgumentsCannotBeExecuted() throws Exception {
        AgentStreamDecoder decoder = new AgentStreamDecoder(mapper, null);
        decoder.accept("{\"choices\":[{\"delta\":{\"tool_calls\":[{\"index\":0,\"function\":{\"name\":\"write\",\"arguments\":\"{bad-json\"}}]},\"finish_reason\":null}]}" );
        decoder.accept("{\"choices\":[{\"delta\":{},\"finish_reason\":\"tool_calls\"}]}" );
        assertThrows(Exception.class, decoder::toolCalls);
    }

    @Test void incompleteTransportIsNotSuccessful() throws Exception {
        AgentStreamDecoder decoder = new AgentStreamDecoder(mapper, null);
        decoder.accept("{\"choices\":[{\"delta\":{\"content\":\"partial\"},\"finish_reason\":null}]}" );
        assertFalse(decoder.hasResult());
    }
}
