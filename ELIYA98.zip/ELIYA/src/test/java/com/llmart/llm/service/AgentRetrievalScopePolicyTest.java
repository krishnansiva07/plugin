package com.llmart.llm.service;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
class AgentRetrievalScopePolicyTest {
 @Test void respectsExplicitRestriction(){
  assertTrue(AgentRetrievalScopePolicy.skipAutomaticExploration("Do not explore the workspace. Create only the specified file."));
  assertTrue(AgentRetrievalScopePolicy.skipAutomaticExploration("Don't explore the repo to create this skill"));
  assertFalse(AgentRetrievalScopePolicy.skipAutomaticExploration("Explore the workspace and map the API flow"));
  assertFalse(AgentRetrievalScopePolicy.skipAutomaticExploration("Do not explore unrelated internet sites"));
 }
}
