package com.llmart.llm.service;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import java.nio.file.Files;
import java.nio.file.Path;
import static org.junit.jupiter.api.Assertions.*;

/** Verify that Chat does not present changed source as an up-to-date indexed structure. */
class WorkspaceRetrievalFreshnessTest {
    @TempDir Path temp;

    @Test
    void marksStaleIndexEvidenceUntilRefreshCompletes() throws Exception {
        Path source = temp.resolve("PaymentService.java");
        Files.writeString(source, "public class PaymentService { int computeSettlementLimit() { return 10; } }");
        WorkspaceRetrievalIndexService index = new WorkspaceRetrievalIndexService(null);
        index.warmRoot("freshness", temp);
        String original = index.retrieveCachedRoot("freshness", temp, "computeSettlementLimit", 6, 8_000);
        assertTrue(original.contains("PaymentService.java"), original);
        assertFalse(original.contains("STALE_INDEX:"), original);

        Files.writeString(source, "public class PaymentService { int computeSettlementLimit() { return 20; } }\n// changed");
        String changed = index.retrieveCachedRoot("freshness", temp, "computeSettlementLimit", 6, 8_000);
        assertTrue(changed.contains("STALE_INDEX:"), "changed code must not appear current under old structure");
        // A background or explicit refresh reuses unchanged fingerprints and updates this file.
        index.warmRoot("freshness", temp);
        String updated = index.retrieveCachedRoot("freshness", temp, "computeSettlementLimit", 6, 8_000);
        assertFalse(updated.contains("STALE_INDEX:"), updated);
    }
}
