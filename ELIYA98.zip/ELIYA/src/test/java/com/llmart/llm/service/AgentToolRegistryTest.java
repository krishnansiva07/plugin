package com.llmart.llm.service;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class AgentToolRegistryTest {

    @Test
    void exposesWorkspaceAgentToolsWithoutGitOperations() {
        AgentToolRegistry registry = new AgentToolRegistry();

        assertTrue(registry.isKnown("inspect_workspace"));
        assertTrue(registry.isKnown("read_file"));
        assertTrue(registry.isKnown("write_file"));
        assertTrue(registry.isKnown("apply_patch"));
        assertTrue(registry.isKnown("workspace_status"));
        assertTrue(registry.isKnown("workspace_diff"));
        assertTrue(registry.isKnown("workspace_checkpoint"));
        assertTrue(registry.isKnown("workspace_rollback"));
        assertTrue(registry.isKnown("run_build"));
        assertTrue(registry.isKnown("run_tests"));
        assertTrue(registry.isKnown("run_command"));
        assertTrue(registry.isKnown("attachment_list"));
        assertTrue(registry.isKnown("attachment_read"));
        assertTrue(registry.isKnown("skill"));
        assertTrue(registry.isKnown("resource_catalog"));
        assertTrue(registry.isKnown("resource_read"));
        assertTrue(registry.isKnown("resource_edit"));
        assertTrue(registry.isKnown("resource_build"));
        assertTrue(registry.isKnown("file_index"));
        assertTrue(registry.isKnown("read_chunk"));
        assertTrue(registry.isKnown("resource_index"));
        assertTrue(registry.isKnown("resource_chunk"));
        assertFalse(registry.isKnown("finish")); // normal assistant text ends the run

        assertFalse(registry.isKnown("git_status"));
        assertFalse(registry.isKnown("git_diff"));
        assertFalse(registry.names().stream().anyMatch(name -> name.startsWith("git_")));
        assertTrue(registry.isKnown("todo_update"));
        assertTrue(registry.isKnown("work_items_discover"));
        assertTrue(registry.isKnown("work_items_init"));
        assertTrue(registry.isKnown("work_items_add"));
        assertTrue(registry.isKnown("work_items_read"));
        assertTrue(registry.isKnown("work_items_update"));
        assertTrue(registry.isKnown("verification_failures"));
        assertTrue(registry.isKnown("presentation_inspect"));
        assertTrue(registry.isKnown("presentation_source_extract"));
        assertTrue(registry.isKnown("presentation_create"));
        assertTrue(registry.isKnown("presentation_validate"));
        assertTrue(registry.isKnown("presentation_preview"));
        assertEquals(83, registry.names().size());
        assertEquals(registry.names().size(), registry.nativeDefinitions().size());
    }
    @Test
    void repairsCommonProviderToolNameNoiseAndAliases() {
        AgentToolRegistry registry = new AgentToolRegistry();

        assertEquals("read", registry.canonical("read/<channel>commentary"));
        assertEquals("read", registry.canonical("functions.read/<channel>commentary"));
        assertEquals("grep", registry.canonical("search"));
        assertEquals("grep", registry.canonical("find"));
        assertEquals("apply_patch", registry.canonical("applypatch"));
        assertEquals("todo_update", registry.canonical("update_plan"));
    }


    @Test
    void exposesDocumentationIntelligenceTools() {
        AgentToolRegistry registry = new AgentToolRegistry();
        assertTrue(registry.names().contains("documentation_inventory"));
        assertTrue(registry.names().contains("documentation_record_module"));
        assertTrue(registry.names().contains("documentation_validate"));
    }
}
