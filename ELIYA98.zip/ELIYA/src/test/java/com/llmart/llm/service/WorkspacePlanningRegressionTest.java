package com.llmart.llm.service;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Files;
import java.nio.file.Path;

import static org.junit.jupiter.api.Assertions.*;

class WorkspacePlanningRegressionTest {
    @TempDir Path temp;

    @Test
    void selectedWorkspaceIsAuthoritativeAndCommandsStayInsideIt() throws Exception {
        Path primary = Files.createDirectories(temp.resolve("primary"));
        Path module = Files.createDirectories(primary.resolve("module"));
        Path other = Files.createDirectories(temp.resolve("other"));
        assertFalse(AgentWorkspaceSelection.canInferFromPrompt("active-project"));
        assertTrue(AgentWorkspaceSelection.canInferFromPrompt(null));
        assertEquals(primary, WorkspaceCommandPaths.resolve(primary, ""));
        assertEquals(module, WorkspaceCommandPaths.resolve(primary, "module"));
        assertEquals(module, WorkspaceCommandPaths.resolve(primary, module.toString()));
        assertThrows(SecurityException.class, () -> WorkspaceCommandPaths.resolve(primary, other.toString()));
        assertThrows(SecurityException.class, () -> WorkspaceCommandPaths.resolve(primary, "../other"));
        assertThrows(IllegalArgumentException.class, () -> WorkspaceCommandPaths.resolve(primary, "unknown"));
        try {
            Files.createSymbolicLink(primary.resolve("other-link"), other);
            assertThrows(SecurityException.class, () -> WorkspaceCommandPaths.resolve(primary, "other-link"));
        } catch (UnsupportedOperationException | java.nio.file.FileSystemException ignored) {
            // Some Windows configurations do not permit symlink creation.
        }
    }

    @Test
    void structuredPlannerAcceptsObjectAndTopLevelArrayEnvelopes() {
        assertEquals("{\"plan\":[{\"title\":\"Inspect\"}]}", AgentPlanJsonEnvelope.extract(
                "```json\n{\"plan\":[{\"title\":\"Inspect\"}]}\n```"));
        String rawArray = "[{\"title\":\"Inspect\"},{\"title\":\"Verify\"}]";
        assertEquals(rawArray, AgentPlanJsonEnvelope.extract(rawArray));
    }
}
