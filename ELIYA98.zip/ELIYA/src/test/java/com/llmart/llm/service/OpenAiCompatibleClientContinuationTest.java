package com.llmart.llm.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.llmart.llm.dto.ChatSettings;
import com.sun.net.httpserver.HttpServer;
import org.junit.jupiter.api.Test;

import java.net.InetSocketAddress;
import java.net.http.HttpClient;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

import static org.junit.jupiter.api.Assertions.*;

/** Integration contract against an in-process OpenAI-compatible SSE gateway; no external LLM required. */
class OpenAiCompatibleClientContinuationTest {
    private static ChatSettings settings(int port) {
        return new ChatSettings("http://127.0.0.1:" + port + "/v1", "mock", "mock", null, null,
                null, null, null, null, false, false, 0.1, 100, null, 128_000,
                null, null, true, 8_000, 20_000, 1_200, null, true, 0,
                true, "allow", "allow", "allow", false, "", "allow", "allow", "allow",
                false, true, "", 3, true, null, null);
    }

    private static String sse(String text, String finish) throws Exception {
        ObjectMapper mapper = new ObjectMapper();
        return "data: " + mapper.writeValueAsString(Map.of("choices", List.of(Map.of(
                "delta", Map.of("content", text))))) + "\n\n" +
                "data: " + mapper.writeValueAsString(Map.of("choices", List.of(Map.of(
                        "delta", Map.of(), "finish_reason", finish)))) + "\n\n" +
                "data: [DONE]\n\n";
    }

    @Test
    void automaticallyContinuesOnlyOutputLimitedChatAndPreservesStreamTranscript() throws Exception {
        AtomicInteger calls = new AtomicInteger();
        HttpServer server = HttpServer.create(new InetSocketAddress("127.0.0.1", 0), 0);
        server.createContext("/v1/chat/completions", exchange -> {
            int call = calls.incrementAndGet();
            String body = new String(exchange.getRequestBody().readAllBytes(), StandardCharsets.UTF_8);
            if (call == 2 && !body.contains("ELIYA INTERNAL ANSWER CONTINUATION")) {
                exchange.sendResponseHeaders(400, -1); exchange.close(); return;
            }
            String reply;
            try {
                reply = call == 1 ? sse("Detailed analysis of the feature. The important result is: source", "length")
                        : sse("The important result is: source-grounded, with explicit unverified gaps.", "stop");
            } catch (Exception e) { throw new IllegalStateException(e); }
            byte[] bytes = reply.getBytes(StandardCharsets.UTF_8);
            exchange.getResponseHeaders().set("Content-Type", "text/event-stream");
            exchange.sendResponseHeaders(200, bytes.length);
            exchange.getResponseBody().write(bytes);
            exchange.close();
        });
        server.start();
        try {
            var client = new OpenAiCompatibleClient(HttpClient.newHttpClient(), new ObjectMapper());
            var original = List.<Map<String,Object>>of(Map.of("role", "user", "content", "Analyze entire feature"));
            var chunks = new StringBuilder();
            var steps = new AtomicInteger();
            String result = client.streamContinuously("fake", settings(server.getAddress().getPort()), original,
                    chunks::append, () -> false, steps::set);
            assertEquals("Detailed analysis of the feature. The important result is: source-grounded, with explicit unverified gaps.", result);
            assertEquals(result, chunks.toString(), "SSE text must match persisted message");
            assertEquals(2, calls.get(), "one automatic continuation only");
            assertEquals(2, steps.get());
            assertEquals(1, original.size(), "never mutate original prompt");
        } finally { server.stop(0); }
    }

    @Test
    void normalStopDoesNotRepeatGeneration() throws Exception {
        AtomicInteger calls = new AtomicInteger();
        HttpServer server = HttpServer.create(new InetSocketAddress("127.0.0.1", 0), 0);
        server.createContext("/v1/chat/completions", exchange -> {
            calls.incrementAndGet();
            try {
                byte[] bytes = sse("Full answer finished", "stop").getBytes(StandardCharsets.UTF_8);
                exchange.sendResponseHeaders(200, bytes.length);
                exchange.getResponseBody().write(bytes);
            } catch (Exception e) { throw new IllegalStateException(e); }
            finally { exchange.close(); }
        });
        server.start();
        try {
            var client = new OpenAiCompatibleClient(HttpClient.newHttpClient(), new ObjectMapper());
            assertEquals("Full answer finished", client.streamContinuously("fake", settings(server.getAddress().getPort()),
                    List.of(Map.of("role", "user", "content", "Hello")), ignored -> {}, () -> false, ignored -> {}));
            assertEquals(1, calls.get());
        } finally { server.stop(0); }
    }
}
