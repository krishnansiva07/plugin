package com.llmart.llm.service;

import org.junit.jupiter.api.Test;
import java.util.*;
import java.util.concurrent.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class AgentQuestionServiceTest {
    @Test void onlyMatchingQuestionAnswerResumesThatAgent() throws Exception {
        var questions = new AgentQuestionService();
        var run = mock(AgentRunService.AgentRun.class);
        var pool = Executors.newSingleThreadExecutor();
        try {
            questions.enable("run-1");
            var wait = pool.submit(() -> questions.ask("run-1","Which project?",List.of("one","two"),run));
            Map<String,Object> pending = Map.of();
            for (int i=0;i<100 && pending.isEmpty();i++) {
                pending=questions.pending("run-1");
                if(pending.isEmpty()) Thread.sleep(10);
            }
            assertFalse(pending.isEmpty());
            assertFalse(questions.answer("run-1","wrong","one",null));
            assertFalse(questions.answer("run-1",pending.get("id").toString(),"third",null));
            assertTrue(questions.answer("run-1",pending.get("id").toString(),"two","yes"));
            assertTrue(wait.get(5,TimeUnit.SECONDS).contains("two"));
            assertTrue(questions.pending("run-1").isEmpty());
        } finally { questions.disable("run-1"); pool.shutdownNow(); }
    }
}
