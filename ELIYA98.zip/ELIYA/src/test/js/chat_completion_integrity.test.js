'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const source = fs.readFileSync(path.join(__dirname, '../../main/resources/static/app.js'), 'utf8');
const start = source.indexOf('function completedAnswerChoice(');
const end = source.indexOf('\nfunction messageHtml(', start);
assert.ok(start > 0 && end > start, 'Completion reconciliation must be present');
const ctx = {};
vm.runInNewContext(source.slice(start, end), ctx);
const apply = ctx.applyCompletedChatMessage;

test('normal persisted done keeps full streamed reply', () => {
  const assistant = { role:'assistant', mode:'chat', streaming:true, content:'## Done\n\n- A\n- B' };
  apply(assistant, {id:321, role:'assistant', content:'## Done\n\n- A\n- B'});
  assert.equal(assistant.content, '## Done\n\n- A\n- B');
  assert.equal(assistant.id, 321);
  assert.equal(assistant.streaming, false);
  assert.equal(assistant.chatCompletionWarning, undefined);
});

test('short done payload does not erase streamed code or sections', () => {
  const long = '### Agent definitions\n```markdown\nagent: implementer\n```\n### Skills\n- Java\n- Review';
  const assistant = { role:'assistant', mode:'chat', streaming:true, content:long };
  apply(assistant, {id:123, role:'assistant', content:'### Agent definitions'});
  assert.equal(assistant.content, long);
  assert.match(assistant.chatCompletionWarning, /server returned a different saved response/);
});

test('empty or differently formatted done payload cannot wipe displayed text', () => {
  for (const content of ['', 'totally different response']) {
    const assistant = { role:'assistant', mode:'chat', streaming:true, content:'Displayed full answer' };
    apply(assistant, {content});
    assert.equal(assistant.content, 'Displayed full answer');
    assert.equal(Boolean(assistant.chatCompletionWarning), Boolean(content));
  }
});

test('server payload may contain additional content without dropping streamed text', () => {
  const assistant = { role:'assistant', mode:'chat', streaming:true, content:'abc' };
  apply(assistant, {content:'abcdef', id:999});
  assert.equal(assistant.content, 'abcdef');
  assert.equal(assistant.chatCompletionWarning, undefined);
});

test('missing done payload retains streaming answer', () => {
  const assistant = { role:'assistant', mode:'chat', streaming:true, content:'full visible text' };
  apply(assistant, null);
  assert.equal(assistant.content, 'full visible text');
  assert.equal(assistant.streaming, false);
});

test('backend always saves the reconciled response before sending done', () => {
  const java = fs.readFileSync(path.join(__dirname, '../../main/java/com/llmart/llm/service/ChatService.java'), 'utf8');
  assert.match(java, /ChatAnswerIntegrity\.reconcile\(generated\.toString\(\), answer\)/);
  assert.match(java, /conversations\.addMessage\(conversation\.getId\(\), "assistant", resolved\.content\(\), List\.of\(\)\)/);
  assert.match(java, /tokenTransport\.accept\(resolved\.unstreamedSuffix\(\)\)/);
});

test('a completed long technical answer still renders agent and skill file references', () => {
  const scope = {window:{}};
  vm.runInNewContext(fs.readFileSync(path.join(__dirname, '../../main/resources/static/markdown.js'), 'utf8'), scope);
  const answer = [
    '## Agent Definition Files',
    '',
    '- `.agents/agents/implementer.md`',
    '- `.agents/agents/code-reviewer.md`',
    '',
    '## Skill Definition Files',
    '',
    '- `.agents/skills/java-service-implementation/SKILL.md`',
    '- `.agents/skills/junit-test-writing/SKILL.md`',
    '',
    '```markdown',
    '# Phase 0 - Scaffolding',
    'Build contracts and tests.',
    '```',
  ].join('\n');
  const streaming = scope.window.MarkdownRenderer.render(answer, {streaming:true});
  const complete = scope.window.MarkdownRenderer.render(answer, {streaming:false});
  for (const needle of ['implementer.md', 'code-reviewer.md', 'SKILL.md', 'Phase 0 - Scaffolding']) {
    assert.ok(streaming.includes(needle), `missing while streaming: ${needle}`);
    assert.ok(complete.includes(needle), `missing after completion: ${needle}`);
  }
  assert.equal((streaming.match(/<li>/g)||[]).length, (complete.match(/<li>/g)||[]).length);
});
