'use strict';
const test=require('node:test');const assert=require('node:assert/strict');const fs=require('node:fs');const path=require('node:path');
const resources=path.join(__dirname,'../../main/resources/static');
const app=fs.readFileSync(path.join(resources,'app.js'),'utf8');
const html=fs.readFileSync(path.join(resources,'index.html'),'utf8');
const controller=fs.readFileSync(path.join(__dirname,'../../main/java/com/llmart/llm/controller/TerminalController.java'),'utf8');
const agent=fs.readFileSync(path.join(__dirname,'../../main/java/com/llmart/llm/service/AgentService.java'),'utf8');
const session=fs.readFileSync(path.join(__dirname,'../../main/java/com/llmart/llm/service/TerminalSessionService.java'),'utf8');
test('Terminal hides the removed Git form but preserves repository actions via agent tools',()=>{
 for (const id of ['terminalGitPanel','terminalRepo','terminalBranch','terminalBranchCreate','terminalWorktreeCreate'])
   assert.doesNotMatch(html,new RegExp(`id="${id}"`));
 assert.match(controller,/@PostMapping\("\/git\/branch"\)/);
 assert.match(controller,/@PostMapping\("\/git\/worktree"\)/);
 assert.match(session,/canonicalWorkspaceKey\(session\.projectId\)/);
});
test('A terminal clarification can be answered without approving a plan',()=>{
 assert.match(agent,/case "ask_user"/);
 assert.match(app,/data-terminal-answer/);
 assert.match(controller,/@PostMapping\("\/sessions\/\{id\}\/answer"\)/);
 assert.match(session,/"Cancel"\.equalsIgnoreCase\(choice\)/);
 assert.match(session,/settings\.put\("agentPlanApproval", false\)/);
});
