'use strict';
const {test} = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const root='src/main/resources/static/';
const app=fs.readFileSync(root+'app.js','utf8');
const css=fs.readFileSync(root+'app.css','utf8');
const html=fs.readFileSync(root+'index.html','utf8');
const backend=fs.readFileSync('src/main/java/com/llmart/llm/service/TerminalSessionService.java','utf8');
const controller=fs.readFileSync('src/main/java/com/llmart/llm/controller/TerminalController.java','utf8');
function standalone(name, end) {
  const start=app.indexOf('function '+name+'(');
  assert.ok(start>=0,`Function ${name} exists`);
  const stop=app.indexOf(end,start);
  assert.ok(stop>start,`Function ${name} boundary`);
  const context={};vm.createContext(context);vm.runInContext(app.slice(start,stop),context);return context[name];
}
const command=standalone('terminalPathInstruction','function terminalOpenState');
const htmlPreview=standalone('firstHtmlPresentation','function previewChatResponse');
test('Terminal path instructions accept Windows and macOS/Linux paths, but not unrelated questions',()=>{
  assert.equal(command('/workspace C:\\work\\automation'), 'C:\\work\\automation');
  assert.equal(command('cd /Users/example/project'), '/Users/example/project');
  assert.equal(command('switch workspace to D:\\Tests'), 'D:\\Tests');
  assert.equal(command('Please review this Selenium code'),null);
});
test('HTML slide code fences are detected without treating ordinary Markdown as HTML',()=>{
  const markup='```html\n<!doctype html><html><body><h1>My deck</h1></body></html>\n```';
  assert.match(htmlPreview(markup),/<h1>My deck<\/h1>/);
  assert.match(htmlPreview('<html><body><p>Slides</p></body></html>'),/Slides/);
  assert.equal(htmlPreview('# Explanation\n```java\nclass Hello {}\n```'),null);
});
test('Terminal window has functional minimize, restore and maximize controls',()=>{
  for(const id of ['terminalMinimize','terminalRestore','terminalMaximize','terminalWorkspacePath','terminalMapWorkspace'])
    assert.match(html,new RegExp('id="'+id+'"'));
  assert.match(app,/terminalRestore.*addEventListener\('click'/);
  assert.match(app,/terminalMaximize.*addEventListener\('click'/);
  assert.match(css,/\.terminal-dock\.maximized/);
  assert.match(css,/\.terminal-dock\.minimized/);
});
test('Terminal follow-ups retain a stable server conversation and queue concurrent turns without persisting API keys',()=>{
  assert.match(controller,/@PostMapping\("\/sessions\/\{id\}\/message"\)/);
  assert.match(backend,/continuing\.conversationId/);
  assert.match(backend,/session\.queue\.addLast\(item\)/);
  assert.match(backend,/preparedInstructions\.put\(item\.id/);
  assert.match(backend,/queuePaused/);
  assert.match(backend,/session\.nextTurn\(request\)/);
  assert.match(backend,/turns\.addLast/);
  assert.doesNotMatch(backend,/put\("apiKey"/);
});
test('Chat prompt drafting defaults to one cohesive view with opt-out',()=>{
  assert.match(app,/const unifiedPrompt = promptResponse/);
  assert.match(app,/class="chat-unified-prompt"/);
  assert.match(app,/data-prompt-format/);
  assert.match(app,/data-full-preview/);
  assert.match(css,/\.chat-unified-prompt pre/);
});
test('Generated HTML previews are opaque origin, with restricted network and form capability',()=>{
  assert.match(app,/frame\.setAttribute\('sandbox', ext === 'svg' \? '' : 'allow-scripts'\)/);
  assert.match(app,/connect-src 'none'/);
  assert.match(app,/form-action 'none'/);
  assert.match(app,/frame\.srcdoc/);
  assert.match(app,/data-html-chat-preview/);
});
