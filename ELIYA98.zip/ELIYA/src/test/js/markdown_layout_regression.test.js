'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const root = path.join(__dirname, '../../main/resources/static');
const scope = {window: {}};
vm.runInNewContext(fs.readFileSync(path.join(root, 'markdown.js'), 'utf8'), scope);
const render = scope.window.MarkdownRenderer.render;

test('blank lines between code-path bullets remain a single compact Markdown list', () => {
  const answer = '## Agent Definitions\n\n- `.agents/agents/implementer.md`\n\n- `.agents/agents/test-writer.md`\n\n- `.agents/agents/code-reviewer.md`\n\n## Skills';
  const html = render(answer);
  assert.equal((html.match(/<ul class="md-list">/g) || []).length, 1);
  assert.equal((html.match(/<li>/g) || []).length, 3);
  assert.match(html, /\.agents\/agents\/implementer\.md/);
  assert.match(html, /<\/ul><h2/);
});

test('list boundaries are preserved across real paragraph gaps', () => {
  const html = render('- `one.md`\n\nSeparate explanation.\n\n- `two.md`');
  assert.equal((html.match(/<ul class="md-list">/g) || []).length, 2);
  assert.match(html, /Separate explanation/);
});

test('file paths and HTML are displayed safely', () => {
  const html = render('- `<script>alert(1)</script>`\n\n- `.agents/skills/example/SKILL.md`');
  assert.ok(!html.includes('<script>'));
  assert.ok(html.includes('&lt;script&gt;'));
  assert.equal((html.match(/<li>/g) || []).length, 2);
});

test('UI CSS includes responsive controls and bounded folder section', () => {
  const css = fs.readFileSync(path.join(root, 'app.css'), 'utf8');
  const app = fs.readFileSync(path.join(root, 'app.js'), 'utf8');
  assert.match(css, /\.workspace-configuration \{ max-height:/);
  assert.match(css, /\.mode-bar \{ width: min\(var\(--content-width\)/);
  assert.match(app, /function installComposerClearance\(\)/);
});
