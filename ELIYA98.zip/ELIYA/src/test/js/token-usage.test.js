const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const src = fs.readFileSync('src/main/resources/static/app.js', 'utf8');
const start = src.indexOf('function tokenActivityReportHtml(');
const end = src.indexOf('\nfunction ', start + 30);
assert.ok(start > 0 && end > start, 'Token usage formatter exists');
const esc = v => String(v).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
const report = vm.runInNewContext(src.slice(start,end) + '\ntokenActivityReportHtml;', {esc});
test('activity report renders per-stage measured tokens and totals', () => {
  const html = report({activities:[
    {activity:'Planning',calls:1,reportedCalls:1,unreportedCalls:0,inputTokens:520,outputTokens:80,totalTokens:600},
    {activity:'Agent execution (step 2)',calls:2,reportedCalls:1,unreportedCalls:1,inputTokens:700,outputTokens:100,totalTokens:800}
  ]}, true);
  assert.match(html,/Planning/);
  assert.match(html,/Agent execution \(step 2\)/);
  assert.match(html,/1,400 reported tokens/);
  assert.match(html,/1 unreported call/);
  assert.match(html,/Context estimates are not billed usage/);
});
test('missing provider usage is identified and activity label escaped', () => {
  const html = report({activities:[{activity:'<img src=x onerror=alert(1)>',calls:1,reportedCalls:0,unreportedCalls:1}]}, true);
  assert.doesNotMatch(html,/<img/);
  assert.match(html,/&lt;img/);
  assert.match(html,/Not reported/);
});
test('report is hidden until a run is finished and is absent without usage', () => {
  assert.equal(report({activities:[{activity:'Planning',calls:1}]},false),'');
  assert.equal(report(null,true),'');
});
