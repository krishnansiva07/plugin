
'use strict';
const test=require('node:test');const assert=require('node:assert/strict');const fs=require('node:fs');
const path='src/main/resources/static/';
const routing=require('../../main/resources/static/unified-routing.js');
const doc=[{id:'a',name:'ManagementRules.docx'},{id:'b',name:'UserNav.docx'}];
test('exact screenshot prompt starts document artifact immediately without Excel keyword',()=>{
  const prompt='can you generate testcases for the attached document';
  assert.equal(routing.documentArtifactIntent(prompt,doc),true);
  assert.equal(routing.interpret({text:prompt,attachments:doc,selectedMode:'auto'}).intent,'document-artifact');
});
test('new tab is same Chat UI; legacy separate agent tabs not rendered',()=>{
  const js=fs.readFileSync(path+'app.js','utf8');
  const start=js.indexOf('function renderUnifiedTabs()');const end=js.indexOf('async function openEliyaChatTab',start);
  assert.doesNotMatch(js.slice(start,end),/data-eliya-agent-tab="/);
  assert.match(js, /newChat\(\);\s*try \{ await ensureConversation\(\)/);
  const css=fs.readFileSync(path+'app.css','utf8');
  assert.match(css, /#terminalDock,#launchTerminalBtn\{display:none!important\}/);
});
test('test-case job starts before expensive text extraction and returns staged progress',()=>{
  const js=fs.readFileSync(path+'app.js','utf8');
  assert.ok(js.indexOf('documentArtifactIntent?.(quickText') < js.indexOf('await ensureDocumentAttachmentsReady(pendingAttachments)'));
  const java=fs.readFileSync('src/main/java/com/llmart/llm/service/TestCaseWorkbookService.java','utf8');
  const start=java.slice(java.indexOf('public Job start('),java.indexOf('private void process('));
  assert.doesNotMatch(start,/ensureReadableText/);
  assert.match(java,/ExecutorCompletionService/);
  assert.match(java,/job\.cancelled/);
});
test('OpenCode executor is routed through the main Chat endpoint when eligible',()=>{
  const java=fs.readFileSync('src/main/java/com/llmart/llm/controller/ChatController.java','utf8');
  assert.match(java,/openCodeBridge\.accepts\(request\)/);
  assert.match(java,/openCodeBridge\.stream\(request\)/);
});
test('editing running test-case request cancels old job before rewinding',()=>{
  const js=fs.readFileSync(path+'app.js','utf8');
  assert.match(js,/runningWorkbook\.testCaseJob/);
  assert.match(js,/artifacts\/testcases\/\$\{encodeURIComponent\(jobId\)\}\/cancel/);
});
