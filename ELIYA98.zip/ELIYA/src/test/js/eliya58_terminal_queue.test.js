'use strict';
const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const java=fs.readFileSync('src/main/java/com/llmart/llm/service/TerminalSessionService.java','utf8');
const controller=fs.readFileSync('src/main/java/com/llmart/llm/controller/TerminalController.java','utf8');
const client=fs.readFileSync('src/main/resources/static/app.js','utf8');
const css=fs.readFileSync('src/main/resources/static/app.css','utf8');
test('new instruction is queued while current task holds the session lane',()=>{
  assert.match(java,/activeWorkspaces\.containsKey\(session\.id\)/);
  assert.match(java,/session\.queue\.addLast\(item\)/);
  assert.match(java,/preparedInstructions\.put\(item\.id, new PreparedInstruction/);
  assert.match(java,/activeWorkspaces\.remove\(session\.id\);[\s\S]*?startNextQueued\(session\);/);
  assert.match(java,/MAX_PENDING_PER_SESSION = 25/);
});
test('queue exposes move, edit, remove, resume and interrupt endpoints',()=>{
  for (const path of ['/sessions/{id}/queue/{itemId}','/sessions/{id}/queue/{itemId}/move','/sessions/{id}/queue/resume','/sessions/{id}/interrupt-next'])
    assert.ok(controller.includes(path),`Missing route ${path}`);
  for (const fn of ['editQueued','moveQueued','removeQueued','resumeQueued','interruptAndNext'])
    assert.ok(java.includes(fn+'('),`Missing ${fn}`);
});
test('unsafe failures and cancelled runs pause queue and recovery requires provider reauthorization',()=>{
  assert.match(java,/!"completed"\.equals\(session\.status\)\) session\.queuePaused = true/);
  assert.match(java,/session\.queuePaused = !session\.queue\.isEmpty\(\)/);
  assert.match(java,/preparedInstructions\.clear\(\)/);
  assert.match(java,/cancelRequested \? "cancelled" : "completed"/);
  assert.match(java,/new PreparedInstruction\(key, requestFromQueue/);
  assert.doesNotMatch(java,/result\.put\("apiKey"/);
});
test('queue UI supports scoped preview editing and shows counts in tab and monitor',()=>{
  for(const action of ['terminal-queue-edit','terminal-queue-save','terminal-queue-dismiss','terminal-queue-remove',
    'terminal-queue-move','terminal-queue-resume','terminal-interrupt'])
    assert.ok(client.includes('data-'+action),`Missing UI action ${action}`);
  assert.match(client,/terminal-tab-queue/);
  assert.match(client,/queuedInstructions/);
  assert.match(client,/data-terminal-queue-editor/);
  assert.match(css,/\.terminal-pending-queue/);
  assert.doesNotMatch(client,/if \(isContinuation && terminalIsBusy\(active.status\)\) return toast/);
});
