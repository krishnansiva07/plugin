@echo off
setlocal
cd /d "%~dp0"
set "ELIYA_JAR=%~dp0eliya.jar"
if not exist "%ELIYA_JAR%" set "ELIYA_JAR=%~dp0target\eliya.jar"
if not exist "%ELIYA_JAR%" (
    echo Missing eliya.jar. Place this script beside eliya.jar or build the project.
    pause
    exit /b 1
)
echo Starting ELIYA with Legacy execution for a stable demo...
java -jar "%ELIYA_JAR%" --eliya.execution.engine=legacy --eliya.opencode.auto-start=false
if errorlevel 1 (
    echo ELIYA did not start. Review the Java error above.
    pause
)
endlocal
