#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
node --check src/main/resources/static/app.js
node --check src/main/resources/static/source-viewer.js
node --check src/main/resources/static/response-artifacts.js
node --test src/test/js/*.test.js qa/*.test.js
bash qa/eliya142-policy-smoke.sh
bash qa/native-agent-policy-smoke.sh
if command -v python >/dev/null && python -c 'import playwright' 2>/dev/null; then
  python qa/eliya143_browser_ui.py
  python qa/eliya133_browser_smoke.py
else
  echo 'Browser tests not run: Python Playwright package missing. Install package and use an existing browser (do not download browser).'
fi
