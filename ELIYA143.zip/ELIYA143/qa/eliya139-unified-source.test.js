'use strict';
const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const artifacts=require('../src/main/resources/static/response-artifacts');
const staticDir=path.join(__dirname,'../src/main/resources/static');
const app=fs.readFileSync(path.join(staticDir,'app.js'),'utf8');
const css=fs.readFileSync(path.join(staticDir,'app.css'),'utf8');
const html=fs.readFileSync(path.join(staticDir,'index.html'),'utf8');
const context=fs.readFileSync(path.join(__dirname,'../src/main/java/com/llmart/llm/service/ContextService.java'),'utf8');
const longPrompt=(count)=>'## Single migration prompt\nObjective: inspect legacy and create all utilities in the mapped workspace.\n'+
  Array.from({length:count},(_,i)=>`Validation step ${String(i+1).padStart(4,'0')}: verify migrated acceptance criterion ${i+1} with real evidence.`).join('\n');

test('single prompt overrides numbered stages and stays a complete, independent Markdown document',()=>{
 const q='Generate ONE single prompt containing all four stages: prompt 1 framework, prompt 2 and 3 utilities, prompt 4 reusable migration.';
 assert.equal(artifacts.expectedPromptCount(q),1);
 const text=longPrompt(1400)+'\n## Prompt 1\nCreate framework and verify.\n## Prompt 2\nCreate core utilities and verify.';
 const prompts=artifacts.promptSections(q,text);
 assert.equal(prompts.length,1);
 assert.equal(prompts[0].content,text);
 assert.equal(prompts[0].ready,true,prompts[0].reason);
 assert.match(artifacts.promptFileName(prompts[0],0),/^prompt-1.*\.md$/);
});
test('single Markdown fence with short optional introduction excludes prose from downloadable source',()=>{
 const q='Create one detailed reusable migration prompt in a single black viewer';
 const source=longPrompt(1100);
 const response=`Here is your generated document.\n\n\`\`\`markdown\n${source}\n\`\`\`\n\nYou can download it as Markdown.`;
 const p=artifacts.promptSections(q,response);
 assert.equal(p.length,1);
 assert.equal(p[0].content,source);
 assert.equal(p[0].content.split('\n').length,1102);
 assert.equal(p[0].ready,true,p[0].reason);
});
test('four independent prompts remain four dark viewer sources unless explicitly one is requested',()=>{
 const q='Generate four prompts: prompt 1 create framework, prompt 2 core utilities, prompt 3 advanced, prompt 4 reusable migration.';
 const response=[1,2,3,4].map(i=>`## Prompt ${i}\nStage ${i}: ${longPrompt(100)}`).join('\n\n');
 const prompts=artifacts.promptSections(q,response);
 assert.deepEqual(prompts.map(p=>p.number),[1,2,3,4]);
 assert.ok(prompts.every(p=>p.ready),prompts.map(p=>p.reason).join(','));
});
test('HTML generation automatically creates source viewer even without the word file',()=>{
 const q='Generate a beautiful standalone HTML report with 1000 rows';
 assert.equal(artifacts.requestedFormat(q),'html');
 const rows=Array.from({length:1100},(_,i)=>`<tr><td>${i}</td><td>Test ${i}</td></tr>`).join('\n');
 const htmlSource=`<!doctype html>\n<html><head><title>Report</title><script>const spread=[...Array(5)];</script></head><body><table>${rows}</table></body></html>`;
 const response=`Here is the HTML:\n\n\`\`\`html\n${htmlSource}\n\`\`\`\n\nSave the source as a file.`;
 const view=artifacts.sourceView(q,response);
 assert.equal(view.kind,'html');
 assert.equal(view.ready,true,view.reason);
 assert.equal(view.content,htmlSource);
 assert.ok(view.content.includes('<td>1099</td>'));
 assert.ok(view.content.split('\n').length>=1100);
 assert.equal(artifacts.detect(q,response).content,htmlSource);
});
test('incomplete HTML keeps full partial source visible, but never claims a complete downloadable artifact',()=>{
 const q='Create HTML report';
 const response='```html\n<!doctype html>\n<html><head><title>X</title></head><body>\n'+ 'Row\n'.repeat(1200);
 const v=artifacts.sourceView(q,response);
 assert.equal(v.kind,'html');
 assert.equal(v.ready,false);
 assert.ok(v.content.includes('Row\nRow\n'));
 assert.equal(v.content.length,response.length);
});

test('interrupted 1000-line prompt remains recoverable as a partial draft, but cannot be handed off',()=>{
 const q='Generate a single complete migration prompt';
 const partial=longPrompt(1250)+'\n[ELIYA: response incomplete] Generation was interrupted.';
 const items=artifacts.promptSections(q,partial);
 assert.equal(items.length,1);
 assert.equal(items[0].content,partial);
 assert.equal(items[0].ready,false);
 assert.equal(artifacts.promptSourceDownloadable(items[0]),true); // partial draft is clearly labelled, not complete
});
test('complete draft source is always downloadable even when Agent requirements are not met',()=>{
 const q='Generate a single reusable creative writing prompt';
 const item=artifacts.promptSections(q,'You are a writer. Create a joyful scene with a river, children and a bicycle. Give the story a warm ending.')[0];
 assert.equal(item.ready,false); // Fails implementation-specific acceptance gate.
 assert.equal(artifacts.promptSourceDownloadable(item),true);
});
test('1000+ line source viewer remains the sole inline rendering path for prompts and HTML',()=>{
 assert.match(app,/const rendered = \(loadingIndicator \|\| \(liveViewer \|\| \(promptPreview \? promptCards : htmlSource \? htmlViewer/);
 assert.match(app,/const promptPreview = promptResponse;/);
 assert.match(app,/data-file-copy/);
 assert.match(app,/data-source-full/);
 assert.match(app,/rawNode\.appendData\(source\.content\.slice\(prior\)\)/);
 assert.match(app,/viewer\.querySelector\('\.eliya-stream-size'\)/);
 assert.match(app,/markdownRawMode=false;\s*\$\('runMarkdownTitle'\)\.textContent=file\.filename/);
 assert.match(css,/\.run-markdown-content\.eliya-dark-source/);
 assert.match(css,/max-height:min\(76vh,860px\)/);
 assert.match(html,/app\.js\?v=143/);
 assert.match(context,/When asked for ONE prompt, produce exactly ONE/);
});
