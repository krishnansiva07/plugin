const assert=require('node:assert/strict');
const a=require('../src/main/resources/static/response-artifacts.js');
const html='<!doctype html>\n<html><head><title>Demo</title></head><body><main>Hi</main></body></html>';
assert.equal(a.detect('downloadable hyml file','```html\n'+html+'\n```').ready,true);
assert.equal(a.detect('download html','```html\n<div>Incomplete</div>\n```').ready,false);
assert.equal(a.detect('download html',html+'\n[ELIYA: response incomplete]').ready,false);
assert.equal(a.detect('download html',html).content,html);
assert.equal(a.detect('send json','```json\n{"ok":true}\n```').extension,'json');
assert.equal(a.detect('download json','```json\n{bad}\n```').ready,false);
assert.equal(a.detect('Explain how HTML works','<html>...</html>').requested,'');
assert.equal(a.detect('download yaml','```yaml\na: 1\n```\ntext\n```yaml\nb: 2\n```').ready,false);
const prompts='## Prompt 1 — Setup\nCreate project\n\n## Prompt 2 — Tests\nAdd tests';
const sections=a.promptSections('Give me prompts',prompts);
assert.equal(sections.length,2);
assert.match(sections[1].content,/Add tests/);
assert.doesNotMatch(sections[1].content,/Create project/);
const h=a.handoffMessage(15,sections[1].content,sections[1].title);
assert.match(h,/conversation message #15/);
assert.doesNotMatch(h,/Create project/);
assert.throws(()=>a.handoffMessage(15,''),/empty/);
assert.equal(a.promptSections('give me an explanation',prompts).length,0);
const partial=a.promptSections('Give prompts',prompts+'\n[ELIYA: response incomplete]');
assert.equal(partial.length,1);
assert.equal(partial[0].ready,false); // preserve incomplete draft, do not authorize Agent
assert.equal(a.promptSourceDownloadable(partial[0]),true); // clearly named .partial.md
console.log('ELIYA132 artifact and scoped prompt contract: PASS');
