@echo off
setlocal enabledelayedexpansion
cd /d "%~dp0.."
where node >nul 2>&1
if errorlevel 1 (echo ERROR: Node.js not found & exit /b 1)
node --check src\main\resources\static\app.js || exit /b 1
node --check src\main\resources\static\source-viewer.js || exit /b 1
node --check src\main\resources\static\response-artifacts.js || exit /b 1
set FAILED=0
for %%F in (src\test\js\*.test.js qa\*.test.js) do (
  node --test "%%F"
  if errorlevel 1 set FAILED=1
)
if !FAILED! NEQ 0 (echo JavaScript tests FAILED & exit /b 1)
where python >nul 2>&1
if errorlevel 1 (
  echo Browser tests skipped: Python not installed
) else (
  python -c "import playwright" >nul 2>&1
  if errorlevel 1 (
    echo Browser tests skipped: Python Playwright package missing
  ) else (
    python qa\eliya143_browser_ui.py || exit /b 1
    python qa\eliya133_browser_smoke.py || exit /b 1
  )
)
echo ELIYA143 frontend validation passed. Full Java/Maven build must be run separately.
