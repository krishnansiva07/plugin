"""ELIYA143 real installed Chromium tests. No network, fake model, or browser download.
Checks complete artifact bytes, source expansion, streamed text, mobile and accessibility.
"""
from playwright.sync_api import sync_playwright
from pathlib import Path
import re, os, shutil, sys
root=Path(__file__).resolve().parents[1]/'src/main/resources/static'
output=Path(__file__).resolve().parents[1]/'qa'/'screenshots-143'
output.mkdir(exist_ok=True)
markup=(root/'index.html').read_text()
markup=re.sub(r'<link rel="stylesheet" href="/([^?"]+)[^"]*"\s*/>',lambda m:'<style>'+(root/m.group(1)).read_text()+'</style>',markup)
markup=re.sub(r'<script src="/([^?"]+)[^"]*"></script>',lambda m:'<script>'+(root/m.group(1)).read_text().replace('</script','<\\/script')+'</script>',markup)
source='# Migration plan\n\n'+ '\n'.join(f'Step {i}: create Playwright TS behavior from Selenium and verify the matching acceptance criteria' for i in range(1,1602))
html='<!doctype html>\n<html><head><title>Large report</title></head><body>\n'+'\n'.join(f'<div data-row="{i}">row {i}</div>' for i in range(1400))+'\n<script>window.__unexpectedSourceExecution=true</script>\n</body></html>'
with sync_playwright() as pw:
    paths=[os.environ.get('ELIYA_BROWSER_BIN'), shutil.which('chromium'), shutil.which('google-chrome'), shutil.which('microsoft-edge')]
    browser_bin=next((f for f in paths if f and Path(f).is_file()),None)
    if not browser_bin:
        print('SKIP: installed Chrome/Edge/Chromium missing; no browser auto-download allowed')
        sys.exit(2)
    browser=pw.chromium.launch(executable_path=browser_bin,headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
    ctx=browser.new_context(viewport={'width':1440,'height':900},accept_downloads=True)
    page=ctx.new_page()
    errors=[]
    page.on('pageerror',lambda exc:errors.append(str(exc)))
    page.set_content(markup,wait_until='domcontentloaded',timeout=30000)
    page.wait_for_timeout(300)
    # Source represents exactly what a model produced. No implementation is performed.
    page.evaluate('''data => {
      state.conversationId='eliya143-browser';
      state.project={id:'demo',name:'Mapped workspace',localWorkspace:true};
      state.messages=[
        {role:'user',id:1,content:'Generate ONE complete implementation prompt',mode:'chat'},
        {role:'assistant',id:2,content:data.prompt,mode:'chat',streaming:false},
        {role:'user',id:3,content:'Generate a downloadable standalone HTML report',mode:'chat'},
        {role:'assistant',id:4,content:data.html,mode:'chat',streaming:false}
      ];renderMessages();
    }''',{'prompt':source,'html':html})
    cards=page.locator('.eliya-prompt-card')
    assert cards.count()==2, f'expected prompt and HTML cards; got {cards.count()}'
    prompt_card=cards.nth(0); html_card=cards.nth(1)
    prompt_text=prompt_card.locator('pre.eliya-prompt-text')
    assert len(prompt_text.inner_text())<len(source)/2, 'inline preview did not bound large source'
    assert 'Preview' in prompt_card.locator('.eliya-source-preview-note').inner_text()
    assert 'more lines' in html_card.locator('.eliya-source-preview-note').inner_text()
    assert page.evaluate('window.__unexpectedSourceExecution===true') is False, 'HTML executed in chat source viewer'
    prompt_card.locator('[data-inline-source]').click()
    assert prompt_text.inner_text()==source, 'inline expansion changed the source'
    assert prompt_card.locator('[data-inline-source]').get_attribute('aria-expanded')=='true'
    prompt_card.locator('[data-inline-source]').click()
    assert len(prompt_text.inner_text())<len(source)/2
    with page.expect_download() as d:
        prompt_card.locator('[data-prompt-download]').click()
    downloaded=d.value
    prompt_target=output/downloaded.suggested_filename
    downloaded.save_as(str(prompt_target))
    assert prompt_target.read_text()==source, 'downloaded Markdown differs from model output'
    with page.expect_download() as d:
        html_card.locator('[data-file-download]').click()
    downloaded=d.value
    html_target=output/downloaded.suggested_filename
    downloaded.save_as(str(html_target))
    assert html_target.read_text()==html, 'downloaded HTML differs from model output'
    prompt_card.locator('[data-prompt-full]').click()
    drawer=page.locator('#runMarkdownBackdrop')
    assert drawer.is_visible()
    assert page.locator('#runMarkdownContent pre').inner_text()==source
    assert page.evaluate("document.activeElement.id")=='runMarkdownClose', 'drawer focus not captured'
    page.keyboard.press('Escape')
    assert not drawer.is_visible()
    assert prompt_card.locator('[data-prompt-full]').evaluate('(el)=>el===document.activeElement'), 'focus was not restored'
    page.screenshot(path=str(output/'desktop.png'),full_page=False)
    # Reader scroll should not be reset when completed history re-renders.
    page.evaluate('''() => {
      const view=document.getElementById('chatView');
      view.scrollTop=190;state.userScrolledUp=true;
      state.messages[3].content+='\\n';renderMessages();
    }''')
    assert page.evaluate("document.getElementById('chatView').scrollTop")>=80, 'reconcile jumped to top'
    # Streaming source must append text and preserve the final full message on completion.
    page.evaluate('''raw => {
      state.messages=[{role:'user',content:'Generate one complete implementation prompt',id:10},
       {role:'assistant',content:raw.slice(0,500),id:11,mode:'chat',streaming:true}];
      renderMessages();
      state.messages[1].content=raw;updateStreamingMessage(1);
    }''',source)
    assert page.locator('.eliya-stream-source pre').inner_text()==source, 'streamed bytes were dropped'
    page.evaluate('''() => {state.messages[1].streaming=false;renderMessages();}''')
    assert page.locator('.eliya-prompt-card [data-prompt-download]').count()==1
    assert page.locator('.eliya-source-preview-note').count()==1
    page.set_viewport_size({'width':390,'height':844})
    page.wait_for_timeout(300)
    assert page.locator('.eliya-prompt-card').first.is_visible()
    page.evaluate("document.getElementById('toast')?.classList.add('hidden')")
    composer_height=page.locator('.composer-zone').bounding_box()['height']
    assert composer_height<245, f'mobile composer consumes {composer_height:.0f}px of the viewport'
    page.screenshot(path=str(output/'mobile.png'),full_page=False)
    assert not errors, f'Chromium JavaScript errors: {errors[:4]}'
    browser.close()
print('ELIYA143 Chromium UI: PASS. Full-source exports, streaming, expansion, focus, mobile.')
