/* ELIYA143: large source-document presentation. This module NEVER mutates source.
 * Preview text is an explicitly labelled viewport; copy/download/full view always
 * read the original complete message, never this preview.
 */
(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  if (root) root.EliyaSourceViewer = api;
})(typeof window !== 'undefined' ? window : null, function () {
  'use strict';
  const PREVIEW_CHAR_LIMIT = 12000;
  const PREVIEW_LINE_LIMIT = 140;
  function overview(value) {
    const source = String(value ?? '');
    let lines = source.length ? 1 : 0;
    for (let i = 0; i < source.length; i++) if (source.charCodeAt(i) === 10) lines++;
    return {chars:source.length, lines};
  }
  function preview(value, opts={}) {
    const source=String(value ?? '');
    const charLimit=Math.max(256, Number(opts.characters) || PREVIEW_CHAR_LIMIT);
    const lineLimit=Math.max(5, Number(opts.lines) || PREVIEW_LINE_LIMIT);
    const totals=overview(source);
    if (source.length<=charLimit && totals.lines<=lineLimit)
      return {text:source, abbreviated:false, hiddenChars:0, hiddenLines:0, ...totals};
    const upper=Math.min(charLimit,source.length);
    let cursor=0, seen=0;
    while(cursor<upper && seen<lineLimit){
      const end=source.indexOf('\n',cursor);
      if(end<0 || end>=upper){cursor=upper;break;}
      cursor=end+1;
      seen++;
    }
    if(cursor>upper)cursor=upper;
    if(cursor===0)cursor=upper;
    // Avoid splitting surrogate pairs, and prefer a line boundary when possible.
    if(cursor<source.length && cursor>0 && /[\uD800-\uDBFF]/.test(source[cursor-1]) && /[\uDC00-\uDFFF]/.test(source[cursor])) cursor--;
    const safeLineBreak=source.lastIndexOf('\n',cursor-1);
    if(safeLineBreak>cursor/3)cursor=safeLineBreak+1;
    const text=source.slice(0,cursor);
    const visibleLines=overview(text).lines;
    return {text,abbreviated:cursor<source.length,hiddenChars:source.length-cursor,
      hiddenLines:Math.max(0,totals.lines-visibleLines),...totals};
  }
  function label(detail){
    return detail.abbreviated
      ? `Preview · ${detail.hiddenLines.toLocaleString()} more lines / ${detail.hiddenChars.toLocaleString()} more characters. Open full view, expand here, or download the complete source.`
      : `Complete source · ${detail.lines.toLocaleString()} lines / ${detail.chars.toLocaleString()} characters.`;
  }
  return Object.freeze({preview,overview,label,PREVIEW_CHAR_LIMIT,PREVIEW_LINE_LIMIT});
});
