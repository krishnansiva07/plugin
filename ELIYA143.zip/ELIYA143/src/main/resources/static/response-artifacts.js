/* ELIYA132: A single, framework-free contract for prompts and user-downloadable artifacts.
 * Source content is never clipped or silently merged; a file is downloadable only
 * when its representation is complete enough to constitute a standalone file.
 */
(function(root,factory){
  const api=factory();
  if(typeof module==='object' && module.exports) module.exports=api;
  if(root) root.EliyaResponseArtifacts=api;
})(typeof window!=='undefined'?window:null,function(){
  'use strict';
  const clean = value=>String(value==null?'':value).replace(/\r\n/g,'\n').trim();
  const safeName = (name,fallback='artifact')=>clean(name).replace(/[^\w .-]+/g,'-').replace(/^\.+/,'').slice(0,80).trim()||fallback;
  const codeBlocks = text => {
    const result=[];
    const regex=/^(`{3,}|~{3,})([^\n]*)\n([\s\S]*?)\n\1\s*$/gm;
    let match;
    while((match=regex.exec(String(text||'')))!==null) result.push({language:clean(match[2]).toLowerCase(),text:match[3],start:match.index,end:regex.lastIndex});
    return result;
  };
  function fullHtml(src){
    const text=clean(src);
    // A fragment, an unfinished tag, or a placeholder is not a downloadable HTML document.
    return (/^<!doctype\s+html\b/i.test(text) || /^<html\b/i.test(text)) &&
      /<html\b[^>]*>[\s\S]*<\/html\s*>\s*$/i.test(text) &&
      /<head\b[^>]*>[\s\S]*<\/head\s*>/i.test(text) &&
      /<body\b[^>]*>[\s\S]*<\/body\s*>/i.test(text) &&
      !/\b(?:TODO|PLACEHOLDER|omitted for brevity|rest of (?:the )?code)\b/i.test(text) &&
      !/^\s*\.\.\.\s*$/m.test(text);
  }
  function fullJson(src){try{JSON.parse(clean(src));return true;}catch(_){return false;}}
  function requestedFormat(question){
    const q=String(question||'');
    if (/^\s*(?:how|what|why|when|where|which)\b/i.test(q) &&
        !/\b(?:give me|create for me|generate for me|write me|show me|provide me)\b/i.test(q))return '';
    // Generating an HTML page/report is artifact intent even when the user does
    // not literally say 'file' or 'download'. Prompt requests take precedence.
    if (!isPromptRequest(q) && /\b(?:create|generate|build|write|produce|render|make|share|show|give)\b[\s\S]{0,240}\b(?:html|html5|web\s*page|webpage)\b/i.test(q)) return 'html';
    const artifactIntent=/\b(?:download(?:able)?|file|artifact|export|save\s+as|standalone|self.contained|webpage|website|config(?:uration)?|document|source\s+code|output\s+file|send)\b/i.test(q);
    if (!artifactIntent) return '';
    if(/\b(?:html?|hyml|web\s*page|single.page\s+(?:site|website))\b/i.test(q))return 'html';
    if(/\b(?:yaml|yml)\b/i.test(q))return 'yaml';
    if(/\bjson\b/i.test(q))return 'json';
    if(/\b(?:markdown|\.md\b)\b/i.test(q))return 'md';
    return '';
  }
  function detect(question,answer){
    const format=requestedFormat(question);
    const src=clean(answer);
    if(!src || !format)return {requested:format,ready:false,reason:'Empty response'};
    if(/\[ELIYA:\s*response incomplete\]|Generation stopped/i.test(src))
      return {requested:format,ready:false,reason:'The response was interrupted. Generate a complete file before downloading.'};
    const fences=codeBlocks(src);
    let text='',ext=format;
    if(format==='html'){
      const candidates=[src,...fences.filter(b=>/^(?:html?|xml|)$/.test(b.language)).map(b=>b.text)];
      // Allow explanatory text before or after an unfenced full HTML document.
      const begin=src.search(/<!doctype\s+html\b|<html\b/i), closing=/<\/html\s*>/gi;
      if(begin>=0){let last;for(const match of src.matchAll(closing))last=match;
        if(last && last.index>=begin)candidates.push(src.slice(begin,last.index+last[0].length));}
      text=candidates.find(fullHtml)||'';
    }else if(format==='json'){
      const candidates=[src,...fences.filter(b=>/^(?:json|)$/.test(b.language)).map(b=>b.text)];
      text=candidates.find(fullJson)||'';
    }else if(format==='yaml'){
      // Multiple code blocks are separate snippets, never silently concatenated.
      const candidates=fences.filter(b=>/^(?:yaml|yml)$/.test(b.language));
      if(candidates.length===1 && !/\b(?:TODO|\.\.\.|PLACEHOLDER)\b/i.test(candidates[0].text))text=candidates[0].text;
      else if(fences.length===0 && !/^\s*```/m.test(src) && /^\s*[\w"'/-][^\n]*:\s*\S/m.test(src))text=src;
      ext='yml';
    }else if(format==='md'){
      text=src;
      if(fences.length===1 && fences[0].start===0 && fences[0].end===src.length && /^(?:md|markdown)$/.test(fences[0].language))text=fences[0].text;
    }
    const requestedName=String(question||'').match(/(?:^|[\s`'"(])([a-z0-9][a-z0-9_.-]{0,78}\.(?:html?|json|ya?ml|md))\b/i)?.[1];
    const fallback= format==='html'?'generated-page.html':format==='json'?'generated-data.json':format==='yaml'?'generated-config.yml':'generated-document.md';
    const filename=requestedName && (requestedName.toLowerCase().endsWith('.'+ext) || (ext==='yml' && requestedName.toLowerCase().endsWith('.yaml'))) ? safeName(requestedName) : fallback;
    return {requested:format,ready:!!text,extension:ext,content:text,filename,
      reason:text?'':'The response does not contain one complete '+format.toUpperCase()+' artifact.'};
  }
  function isPromptRequest(question){
    const q=clean(question);
    // A request to review or fix an EXISTING prompt is not a prompt-generation request.
    if(/^(?:check|verify|review|inspect|explain|fix|test|run)\b/i.test(q) &&
       !/\b(?:generate|create|write|draft|prepare|produce|give|share|provide)\b[\s\S]{0,180}\bprompts?\b/i.test(q))return false;
    if(/^(?:what|why|when|where|how|which)\b/i.test(q))return false;
    if(/\bprompts?\s*1\b[\s\S]*\bprompts?\s*2\b/i.test(q))return true;
    if(/\b(?:single|one|all[ -]?in[ -]?one)\s+(?:(?:complete|detailed|reusable|full|markdown|md|implementation|migration|combined)\s+){0,4}prompt\b/i.test(q))return true;
    return /\b(?:generate|create|write|draft|prepare|produce|give|share|provide|build|make|export|download|convert|turn)\b[\s\S]{0,650}\bprompts?\b|\b(?:implementation|execution|agent|complete|reusable)\s+prompts?\b|^prompts?\s+(?:for|to|based on)\b/i.test(q);
  }
  function singlePromptRequested(question){
    const q=clean(question);
    if(!isPromptRequest(q))return false;
    return /\b(?:single|one|1|all[ -]?in[ -]?one|one[ -]?combined)\s+(?:(?:complete|detailed|reusable|long|full|markdown|md|implementation|migration|combined|single|self[ -]?contained)\s+){0,4}prompt\b/i.test(q) ||
      /\b(?:everything|all|entire|whole|four|4)\b[\s\S]{0,110}\b(?:in|inside|into|as)\s+(?:a\s+)?(?:single|one)\s+prompt\b/i.test(q) ||
      /\b(?:one|single)\s+(?:black|dark)\s+(?:screen|viewer|block)\b[\s\S]{0,90}\bprompt\b/i.test(q);
  }
  // Count is a contract, not a display suggestion. Support both "four prompts" and
  // requests describing Prompt 1, Prompt 2, Prompt 3 and "4 reusable prompt".
  function expectedPromptCount(question){
    const q=clean(question);
    if(!isPromptRequest(q))return 0;
    if(singlePromptRequested(q))return 1;
    const wordNumbers={one:1,two:2,three:3,four:4,five:5,six:6,seven:7,eight:8,nine:9,ten:10};
    const written=q.match(/\b(\d{1,2}|one|two|three|four|five|six|seven|eight|nine|ten)\s+(?:(?:separate|standalone|independent|reusable|detailed|implementation|migration|complete)\s+){0,3}prompts?\b/i);
    if(written){
      const n=Number(written[1])||wordNumbers[written[1].toLowerCase()];
      if(n>=1&&n<=20)return n;
    }
    const labels=[...q.matchAll(/\bprompts?\s*(?:number\s*|no\.?\s*|#\s*)?(\d{1,2})\b/gi)].map(m=>Number(m[1]));
    // Handles "1 for framework, 2 for utilities ... 4 reusable prompt".
    for(const m of q.matchAll(/\b(\d{1,2})\s+(?:(?:reusable|implementation|migration|framework|utility|utilities|final|last)\s+){0,3}prompts?\b/gi))labels.push(Number(m[1]));
    if(labels.includes(1)&&labels.length>=2)return Math.min(20,Math.max(...labels));
    return 0;
  }
  function promptReadiness(question,content){
    const text=clean(content), q=String(question||'');
    if(!text || /\[ELIYA:\s*response incomplete\]|Generation stopped/i.test(text))
      return {ready:false,reason:'Prompt generation was interrupted.'};
    if(/^(?:sure[,. ]+|okay[,. ]+)?(?:let me|i(?:'ll| will| can) (?:first )?(?:inspect|analyse|analyze|prepare|create|generate|write))/i.test(text))
      return {ready:false,reason:'Only a preamble was generated, not the requested prompt.'};
    // Requirements often say "do not leave TODOs/placeholders". Reject actual
    // missing sections, not legitimate instructions that mention those words.
    if(/^[ \t]*(?:[-*]\s*)?(?:TODO|PLACEHOLDER|\.\.\.)(?:\s*[:=-]|\s*$)/im.test(text) ||
       /\b(?:same as above|remaining steps omitted|insert your details here|omitted for brevity)\b/i.test(text))
      return {ready:false,reason:'The prompt still contains omitted or placeholder instructions.'};
    // A selected card is never allowed to contain a second full prompt.
    // This catches model output that repeats the complete four-prompt bundle
    // INSIDE every labelled prompt (usually within a Markdown fence).
    const nested=[...text.matchAll(/^[ \t]*(?:#{1,6}[ \t]+)?(?:\*\*)?prompt[ \t]*#?[ \t]*\d{1,2}\b[^\n]*$/gim)];
    if(nested.length>1 && !singlePromptRequested(question))return {ready:false,reason:'This section contains multiple complete prompts. Generate a distinct prompt rather than repeating the four-prompt bundle.'};
    const fences=[...text.matchAll(/^[ \t]*(`{3,}|~{3,})(?:[^\n]*)$/gm)];
    if(fences.length%2!==0)return {ready:false,reason:'The generated prompt has an unclosed code block; the output may be truncated.'};
    const abbreviated=/\b(?:short|brief|one.line|single.sentence|tiny|minimal)\s+prompts?\b/i.test(q);
    if (!abbreviated && text.length<180)
      return {ready:false,reason:'This is an outline, not an independently executable implementation prompt.'};
    if (!abbreviated && !/\b(?:verify|validate|test|acceptance|criteria|confirm|check|evidence|success condition|completion)\b/i.test(text))
      return {ready:false,reason:'The prompt lacks verification or acceptance instructions.'};
    return {ready:true,reason:''};
  }
  function unwrapPromptDocument(text){
    // Models often put an entire four-prompt answer inside one ```markdown fence.
    // This wrapper is presentation, NOT one executable prompt.
    let src=clean(text);
    const outer=src.match(/^(`{3,}|~{3,})(?:md|markdown|text|plaintext)?[ \t]*\n([\s\S]*?)\n\1\s*$/i);
    if(outer && !outer[2].split("\n").some(line=>line.trim().startsWith(outer[1])))src=clean(outer[2]);
    return src;
  }
  function singlePromptBody(answer){
    const source=clean(answer);
    // With a single requested Markdown document, the Markdown code fence owns
    // the downloadable bytes. Prose before/after stays out of the .md file.
    const fenced=codeBlocks(source).filter(f=>/^(?:md|markdown|text|plaintext)$/.test(f.language));
    if(fenced.length===1 && codeBlocks(source).length===1 &&
      fenced[0].text.length>=source.length*0.7)return clean(fenced[0].text);
    return unwrapPromptDocument(source);
  }
  function promptSections(question,answer){
    if(!isPromptRequest(question))return [];
    const expected=expectedPromptCount(question);
    const original=clean(answer);
    if(!original)return [];
    if(/\[ELIYA:\s*response incomplete\]|Generation stopped/i.test(original))
      return [{number:1,title:'Incomplete generated Markdown source',content:original,ready:false,
        reason:'Generation ended before the requested prompt was complete. No Agent handoff is allowed.'}];
    const src=unwrapPromptDocument(original);
    if(singlePromptRequested(question)){
      const body=singlePromptBody(original);
      return [{title:'Single complete Markdown prompt',number:1,content:body,...promptReadiness(question,body)}];
    }
    // Only full-line, explicitly labelled headings are reliable boundaries.
    // Skip headings inside ordinary code fences so instructions/examples cannot
    // produce phantom prompts. The outer Markdown-document fence is unwrapped.
    // A migration prompt can legitimately contain hundreds of "Step 1:",
    // "Step 2:" instructions. They are NOT independent prompt boundaries.
    // Split only at explicit Prompt N headers; never truncate on numbered steps.
    const header=/^[ \t]*(?:#{1,6}[ \t]+)?(?:\*\*)?(?:\d{1,2}[.)][ \t]+)?prompt[ \t]*#?[ \t]*(\d{1,2})\b[^\n]*$/gim;
    const fenceSpans=codeBlocks(src);
    const marks=[...src.matchAll(header)].filter(match=>!fenceSpans.some(f=>match.index>=f.start&&match.index<f.end));
    // Four individually fenced Markdown documents are also four separate
    // prompts, even though their internal headings are inside code fences.
    if(marks.length<2 && fenceSpans.length>=2){
      const fenced=fenceSpans.map(f=>{
        if(!/^(?:md|markdown|text|plaintext)$/.test(f.language))return null;
        const first=clean(f.text).match(/^(?:#{1,6}\s+)?(?:\*\*)?prompt\s*#?\s*(\d{1,2})\b[^\n]*/i);
        return first?{number:Number(first[1]),title:first[0],content:clean(f.text)}:null;
      });
      if(fenced.every(Boolean)){
        const numberSet=fenced.map(p=>p.number);
        const validOrder=fenced.length===(expected||fenced.length) && numberSet.every((n,i)=>n===i+1);
        return fenced.map(part=>({...part,...(validOrder?promptReadiness(question,part.content):
          {ready:false,reason:`Expected ${expected||'ordered'} distinct prompts; found labels ${numberSet.join(', ')}.`})}));
      }
    }
    if(marks.length<2){
      const body=src;
      if(expected>1)return [{title:`Combined response — expected ${expected} separate prompts`,content:body,
        number:0,ready:false,reason:`Expected ${expected} separately labelled prompts but found ${marks.length} distinct section${marks.length===1?'':'s'}. Regenerate the prompt set. Never send this combined answer to Agent.`}];
      return [{title:'Complete prompt',content:body,number:1,...promptReadiness(question,body)}];
    }
    const sections=[];
    for(let i=0;i<marks.length;i++){
      const start=marks[i].index, end=i+1<marks.length?marks[i+1].index:src.length;
      const body=src.slice(start,end).trim();
      if(body)sections.push({number:Number(marks[i][1]),title:clean(marks[i][0]).replace(/^\s*#{1,6}\s*/,'').replace(/^\*\*/,'').replace(/\*\*$/,'').slice(0,100),content:body});
    }
    const numbers=sections.map(s=>s.number);
    const exact=expected ? (sections.length===expected && numbers.every((n,i)=>n===i+1))
      : (new Set(numbers).size===sections.length && numbers.every((n,i)=>n===i+1));
    const normalized=sections.map(s=>s.content.replace(/^.*\n/,'').replace(/\s+/g,' ').trim().toLowerCase());
    const duplicates=new Set(normalized).size!==normalized.length;
    const invalidSet=!exact ? `Requested ${expected||'sequential'} prompts but found sections numbered ${numbers.join(', ')}. Generate one separately headed section for each requested prompt.`
      : duplicates ? 'Two or more prompts contain the same instructions. Generate distinct, independently executable prompts.' : '';
    return sections.map(section=>({...section,...(invalidSet ? {ready:false,reason:invalidSet} : promptReadiness(question,section.content))}));
  }
  function promptSourceDownloadable(section){
    // Even an incomplete response is the user's generated text. Let them save
    // a clearly labelled PARTIAL draft, without authorizing Agent execution.
    return Boolean(clean(section?.content));
  }
  function draftFilename(filename){
    const name=safeName(filename,'generated.md');
    const dot=name.lastIndexOf('.');
    return dot>0?name.slice(0,dot)+'.partial'+name.slice(dot):name+'.partial';
  }
  // Renderer contract: exactly one source string owns inline display, copy,
  // download and full-screen view; never synthesize a shortened display copy.
  function sourceView(question,answer,streaming=false){
    const q=clean(question), src=String(answer||'');
    if(isPromptRequest(q))return {kind:'prompt',content:src,streaming:!!streaming};
    if(requestedFormat(q)!=='html')return {kind:'',content:''};
    // No HTML parsing/validation on every provider token; it is O(n) and makes
    // 1,000-line streams progressively slower. Validate once on completion.
    if(streaming)return {kind:'html',content:src,ready:false,streaming:true,filename:'generated-page.html'};
    const artifact=detect(q,src);
    const candidates=codeBlocks(src).filter(b=>/^(?:html?|xml|)$/.test(b.language));
    const partial=candidates.length===1?candidates[0].text:src;
    return {kind:'html',content:artifact.ready?artifact.content:partial,
      ready:!streaming&&artifact.ready,filename:artifact.filename||'generated-page.html',
      reason:artifact.reason||'',streaming:!!streaming};
  }
  function promptFileName(section,index){
    const n=Number(section?.number)||index+1;
    const label=clean(section?.title||'').replace(/^(?:prompt|step)\s*#?\s*\d+\s*[:.)—–-]?\s*/i,'')
      .replace(/[^a-z\d\s-]/gi,'').toLowerCase().replace(/\s+/g,'-').replace(/-+/g,'-').slice(0,45).replace(/-$/,'');
    return `prompt-${n}${label?'-'+label:''}.md`;
  }
  function handoffMessage(id,scope,title){
    if(!Number.isSafeInteger(Number(id))||Number(id)<=0)throw new Error('Saved Analyse response required');
    const selected=clean(scope);
    if(!selected)throw new Error('The selected prompt is empty');
    // ContextService accepts a scoped Agent prompt up to 80K chars when the
    // configured model has enough room. Do not arbitrarily reject a 32K prompt.
    if(selected.length>72000)throw new Error('Selected prompt is larger than the 72,000-character handoff safety limit. Split it into independently verifiable tasks or configure a larger context window.');
    return `Implement ONLY the selected prompt from conversation message #${Number(id)} in the currently selected workspace.\n`+
      `Selected scope: ${clean(title||'Prompt')}\n`+
      'This is an explicit scoped handoff. Do not execute unrelated sections, other prompts, or optional enhancements from the source response. ' +
      'Use the selected instructions below as the authoritative task, inspect relevant live files, and verify changes before declaring completion. '+
      'Ask only if a critical requirement prevents safe execution.\n\n'+
      '--- BEGIN SELECTED PROMPT ---\n'+selected+'\n--- END SELECTED PROMPT ---';
  }
  return Object.freeze({codeBlocks,fullHtml,requestedFormat,detect,isPromptRequest,singlePromptRequested,singlePromptBody,expectedPromptCount,promptReadiness,promptSections,promptSourceDownloadable,promptFileName,draftFilename,sourceView,handoffMessage,safeName});
});
