# ELIYA143 — Batched UI reliability and source-viewer release

Source-only incremental release based on ELIYA142. **No precompiled JAR is provided or claimed validated.** The native agent token optimizations from ELIYA142 are unchanged.

## Changes delivered

1. **Lossless long-form prompt parser.** Removed `Step N` as an independent prompt boundary: a 1,600-line single prompt containing hundreds of steps remains one complete document. Single-prompt recognition now supports “self-contained”. Separate `Prompt N` headings remain independent.
2. **Expandable artifact source viewers.** A completed Markdown or HTML source shows a small, explicit preview by default; `Show all inline` expands the full text, `Open full view` uses the dark inspector, and Copy/Download read original source bytes. Viewers display actual total line/character counts. No hidden fragments or unlabelled omission.
3. **Fixed streamed-source duplication.** Initial streaming HTML already contains a text node; incremental updates now resume at that actual length instead of blindly appending the entire current answer. The append path guards against tail mismatches and resets on source rewrites.
4. **Stream scheduling and reading.** Per-message throttling timers, cancellation at completion, per-frame scroll coalescing, and viewport message anchoring reduce repeated work and accidental scroll jumps.
5. **Contextual, lower-noise answers.** Follow-up suggestion is shown only for the latest completed assistant reply; no historic question spam.
6. **Dialog and mobile UX.** Full-source viewer focus return and keyboard Tab control; compact one-row mobile Analyse/Agent/Models; responsive source panels and reduced-motion support.
7. **Regression coverage.** Pure Node tests and real installed Chromium browser tests, with exact-byte exported files and screenshot evidence.

## Files modified

- `src/main/resources/static/response-artifacts.js` — parser boundary and self-contained prompt intent.
- `src/main/resources/static/source-viewer.js` — NEW bounded presentation-only excerpt contract.
- `src/main/resources/static/app.js` — source cards, expansion actions, streamed text, scroll behavior, focus and next-step gating.
- `src/main/resources/static/app.css` — long-source notes, mobile layout, reduced motion, focus visibility.
- `src/main/resources/static/index.html` — new module and v143 cache keys.
- `qa/eliya143-source-ux.test.js` — NEW Node regression contracts.
- `qa/eliya143_browser_ui.py` — NEW real Chromium regression, exact exports, mobile and focus.
- `qa/eliya139-unified-source.test.js`, `qa/response-artifacts-132.test.js`, `qa/eliya133_browser_smoke.py` — align old expectations with the already established partial-draft and HTML-source-viewer design; no production behavior weakened.

## Known limits

- The inline card is **only an excerpt** until expanded. The complete source is present in the original answer and in Copy/Download/Full view. This keeps very long completed chat histories responsive.
- The actual Java/Spring Boot build, live model provider SSE, real Agent cancellation and persisted backend history were not exercised in this environment. Maven is unavailable; no live OpenCode comparison is claimed.
- Browser regression used desktop and 390-pixel mobile Chromium; evaluate corporate Chrome/Edge and small devices separately.
- UX-06 to UX-08 remain planned in `ELIYA143_REQUIREMENTS.md` and must not be reported as implemented.
