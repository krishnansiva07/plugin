# ELIYA143 — Validation record

## Completed in this environment

| Validation | Result | Scope |
|---|---|---|
| `node --test src/test/js/*.test.js qa/*.test.js` | **PASS 170/170** | Existing and new Node source/behavior contracts |
| `python qa/eliya143_browser_ui.py` | **PASS** | Installed local Chromium; 1601-step Markdown prompt, 1400-row HTML, exact download content, inline full/preview, initial streaming chunk, HTML escaped, Escape/focus return, scroll anchoring, 390×844 mobile |
| `python qa/eliya133_browser_smoke.py` | **PASS** | Existing prompt, verification, handoff, HTML preview, mobile and Agent outcome screens; fixed stale selectors in the test to match the current viewer |
| `bash qa/eliya142-policy-smoke.sh` | **PASS** | Existing 130 Node tests + JDK-only agent optimization policy harness |
| `bash qa/native-agent-policy-smoke.sh` | **PASS** | Agent tool permission and read-only profiles, JDK 17 standalone compilation |
| `node --check app.js`, `markdown.js`, `response-artifacts.js`, `source-viewer.js` | **PASS** | JavaScript parsing |
| `python -m py_compile qa/eliya143_browser_ui.py` | **PASS** | Browser regression syntax |

All tests are repeatable offline except the optional live-app Maven build. Browser scripts do not download browsers or contact an LLM.

## Data integrity evidence

- A 1601-step source (1603 lines including headings) produces ONE prompt card, not 1601 fragments.
- Initial inline preview is deliberately bounded; the full-source dialog, inline expansion and `.md` download are equal to the original complete test string.
- HTML source with a `<script>` remains inert in source viewer; downloaded `.html` is identical to its original model-produced text. Rendering **a requested HTML preview** is a separate, sandboxed feature.
- On a streaming update, the second chunk does **not** duplicate the initial text already shown. Final render has a complete prompt card.
- Reducing mobile screen usage is tested in a 390×844 Chromium viewport (composer under 245 px with folders collapsed); screenshots in `qa/screenshots-143/`.

## Limitations and blockers

- **No full Maven/Spring Boot build:** Maven is not installed in this container. `build-jar-windows.cmd` must be run on a configured Windows workstation.
- **No live SSE / actual model billing:** The browser test injects known long source strings and exercises the actual frontend and download code. It does not prove provider network throughput or compare token usage against OpenCode.
- **No customer workspace test:** Browser checks use synthetic sample source data; integration with >2,000 indexed workspace files and remote MCP remains to be tested on target infrastructure.
- Existing ELIYA142 source-level performance policy remains unchanged; ELIYA143 is **UI release**, not a new token-cost claim.

## Evidence files

- `qa/screenshots-143/desktop.png` and `qa/screenshots-143/mobile.png`
- `validation/ELIYA143_NODE_TESTS.log`
- `validation/ELIYA143_POLICY_TESTS.log`
- `validation/ELIYA143_BROWSER_UI.log`
- `validation/ELIYA143_BROWSER_LEGACY.log`
