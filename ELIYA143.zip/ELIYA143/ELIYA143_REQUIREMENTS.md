# ELIYA143 — UI/UX Requirement Batches (incremental delivery)

**Baseline**: The user-supplied ELIYA141 source, carried forward through ELIYA142 performance release. This document records what has actually been changed and tested, versus follow-on work. The existing native ELIYA agent, Analyse/Agent split, explicit MCP permissions, workspace mapping and completion gates are preserved.

## Delivery order and acceptance criteria

| Batch | Priority | Scope and requirements | State | Evidence / acceptance |
|---|---|---|---|---|
| **UX-01 Source integrity** | P0 | A single requested prompt must remain one prompt even when it contains many numbered `Step N` instructions. Long Markdown/HTML must render in ONE dark viewer; initial preview bounded and explicitly labelled, never silently truncated. Show all inline / full dialog / copy / exact download. Partial outputs must be labelled `.partial`; cannot be executed as complete. HTML source must never execute in chat. | **Implemented and browser-verified** | `response-artifacts.js` parser; `source-viewer.js`; `app.js` source cards. `qa/eliya143-source-ux.test.js` and real Chromium `qa/eliya143_browser_ui.py` verify 1,600+ line Markdown and 1,400-line HTML downloaded byte-for-byte. |
| **UX-02 Streaming and scroll stability** | P0 | Do not reinsert the first streamed chunk on the next update; preserve all bytes through final rendering. Schedule at most one pending rendering timer **per message**, cancel timers at completion. Prevent automatic jump to bottom while reading earlier messages; scroll coalesces to one animation frame. | **Implemented and browser-verified** | Chromium test checks streaming text equals source and completion preserves output; static tests check timers and scroll anchoring. No full provider SSE load test performed here. |
| **UX-03 Relevant responses and focus** | P1 | No repeated suggestion underneath every historic answer. Show context-derived follow-up only for current completed assistant reply (if justified by evidence). Keyboard focus enters a full-source dialog and returns to initiating control on close; dialog traps Tab. Respect reduced-motion accessibility. | **Implemented and browser-verified (core paths)** | `app.js`, `app.css`; Chromium checks Escape and focus return; Node tests check latest-only guidance. Comprehensive accessibility audit is still pending. |
| **UX-04 Mobile conversation space** | P1 | Avoid multi-row Analyse/Agent/Models controls; reduce composer footprint and redundant hints, keep code/text in a readable dark panel, use responsive width. | **Implemented and browser-verified** | Mobile 390 × 844 Chromium viewport and screenshot; composer height acceptance `<245 px` in collapsed-folder state. Expanded workspace, virtual keyboards and other screen sizes require device testing. |
| **UX-05 Regression and packaging** | P0 | Check existing features, add repeatable tests, preserve all code and readable requirements/validation, package release with no fabricated JAR. | **Implemented** | 170/170 Node tests; ELIYA143 + ELIYA133 real Chromium smoke; ELIYA142 JDK optimization smoke and native agent policy smoke; `node --check` static scripts. |
| **UX-06 Agent live execution cockpit** | P1 | One readable lifecycle for Analyse→Agent, work items, real vs estimated stage %, current tool, approvals, cancellation, stage time/token usage, verified completion, and recovery from disconnected SSE. Maintain terminal and browser parity. | **Next release — not implemented in ELIYA143** | Requires SSE replay/disconnect tests, real backend JAR and model runs, explicit blocked/failed/cancelled outcomes and reliable token counters. |
| **UX-07 Long-running sessions and artifact reliability** | P1 | Resume browser tabs after refresh, retain preview expansion state, verify generated files exist, surface missing/partial artifacts and a retry only for failed steps; retain large transcript history without DOM growth. | **Next release — not implemented in ELIYA143** | Requires browser reload plus persisted backend sessions and high-volume history testing. |
| **UX-08 Accessibility & performance audit** | P2 | Keyboard-only user journeys, WCAG contrast, screen-reader status updates, mobile device matrix, 2,000-file workspace, 5,000-line documents and 60-minute runs; measure CPU, heap, rendering frame delays, provider token usage. | **Next release — not implemented in ELIYA143** | Requires Chrome Performance traces, service backend, actual provider counters, representative workspaces. |

## Requirement rules and non-negotiable safety

1. Never treat display excerpts as source of truth. Copy/download/Agent handoff must use the complete saved source, not the inline preview text.
2. Never mark a task or artifact complete merely because a stream stopped, UI progress reached 100%, or a file name appeared. Verification evidence and actual file presence still govern completion.
3. A prompt or HTML request is a source artifact, not a collection of fragments. Distinct **Prompt 1 / Prompt 2** headers identify independent prompts; numbered implementation steps do not.
4. Do not download a browser automatically for tests. Use an installed Chrome/Edge/Chromium, as requested.
5. Do not claim measured token superiority over OpenCode without comparable provider-reported input/output and verified task outcomes.
6. Do not lower delete/write approval protections, or enable MCP unless it is explicitly requested by the user.

## Steps to use the release

1. Stop the running ELIYA JAR; extract `ELIYA143.zip` as a **separate** source folder, retaining ELIYA142 for rollback.
2. Run `node --test src/test/js/*.test.js qa/*.test.js` on Linux/WSL/macOS; run the Windows Node suite from an environment supporting globs or use `qa/run-eliya143-validation.cmd`.
3. For Chromium, install Python Playwright **package only if required** and run `python qa/eliya143_browser_ui.py`; browser selection requires an **already installed** Chromium/Chrome/Edge (set `ELIYA_BROWSER_BIN` if necessary).
4. Build a JAR **on the target Java/Maven machine** with `build-jar-windows.cmd`, then start the JAR and open `http://localhost:8090` (if configured). The static browser tests **do not prove** this Java build succeeds.
5. Hard-refresh once; HTML loads `/app.css?v=143`, `/source-viewer.js?v=143`, and `/app.js?v=143`.
