# Remove Web Content Import

The generic **Import Web Content** feature has been removed.

Changes:

- Removed the **Import Web Content** tab from the UI.
- Removed URL input and Import Content controls.
- Removed the frontend `/api/import/url` call and URL-import JavaScript.
- Removed the backend `/api/import/url` endpoint.
- Removed `UrlImportService` and `UrlImportRequest`.
- Retained **Paste Text** and **Upload File** as the two content input methods.
- Retained all document extraction support for uploaded TXT, MD, HTML, DOCX, PDF, PPTX, JSON, XML, properties and Java files.

This reduces unnecessary network-facing surface area and keeps the formatter focused on user-provided content and uploaded documents.
