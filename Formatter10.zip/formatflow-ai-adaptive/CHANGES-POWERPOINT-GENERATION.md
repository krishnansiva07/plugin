# PowerPoint Generation Changes

- Added PowerPoint as a fourth destination in the UI.
- Added slide-specific LangGraph prompt guidance: h1 becomes deck title, h2 becomes slide titles, bullets remain concise, and tables are reserved for genuinely tabular content.
- Added deterministic PowerPoint `.pptx` generation using Apache POI, which was already part of the project dependency set.
- PowerPoint download now calls `/api/export` and sends the generated semantic HTML to the backend for native PPTX conversion.
- Added green/white presentation styling: title slide, top accent bar, slide numbers, readable bullets, table headers, table borders and soft green backgrounds.
- Added review checks so rich content is not over-condensed into too few slides and long slide text is repaired into presentation bullets.
- Copy for PowerPoint now copies the slide outline; download creates the actual `.pptx`.
