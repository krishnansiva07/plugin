# LLM 10-Attempt Recovery Policy

The active LLM client now gives transient model/gateway failures ten total chances before the request is classified as an LLM availability problem.

## Runtime behavior

1. Build the LLM request once.
2. Send attempt 1.
3. For transient HTTP failures (408, 429, 500, 502, 503, 504), transport failures, timeouts, connection resets, or malformed successful responses, replay the exact same serialized request.
4. Continue through attempt 10 without changing the prompt, model, temperature, message content, or `max_tokens`.
5. If any attempt succeeds, continue the normal LangGraph/presentation flow immediately.
6. Only after attempt 10 fails is the condition reported as `LLM unavailable after 10 attempts`.
7. The request-scoped circuit then prevents more failing model calls during the same formatting operation; deterministic fallback keeps the UI flow alive and is explicitly labelled as fallback.

## Exceptions that are not treated as an LLM outage

- Explicit token/context-limit 400/422 responses may reduce only `max_tokens` and resend the same prompt.
- 401/403 responses may try configured authentication-header discovery. Repeating a known-invalid credential shape ten times is intentionally avoided.
- Other non-transient client/configuration errors fail with their specific message rather than being mislabeled as an LLM service outage.

## Configuration

```properties
formatflow.llm.max-attempts=10
```

The Java configuration clamps this value to a maximum of 10 so the behavior remains deterministic.

## Regression coverage

Tests verify that:

- a transient failure can recover on attempt 10;
- all ten request bodies are byte-for-byte identical;
- a transient service is reported unavailable only after all ten attempts fail.
