@echo off
setlocal
echo Building FormatFlow AI...
call mvn clean package
if %errorlevel% neq 0 exit /b %errorlevel%
echo.
echo Build complete:
echo target\formatflow-ai-0.0.1-SNAPSHOT.jar
endlocal
