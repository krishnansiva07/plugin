# Adaptive LLM Pipeline

This revision changes FormatFlow AI from a two-LLM-pass formatter into a bounded adaptive semantic pipeline.

## Why

For a large source document, sending the same chunk once for formatting metadata and again for semantic layout is wasteful and can produce inconsistent decisions. Sending the entire document is also less reliable for tables/workflows and can exceed model context limits.

## New behavior

### Small content

One LLM call returns:

- line/block presentation metadata
- semantic layout decision
- table/workflow/checklist structures when justified

Java validates every semantic value before rendering.

### Large content

1. Java extracts source blocks.
2. Blank-line logical groups are kept together where possible.
3. Groups are packed into bounded chunks (default ~5,500 characters / 26 blocks).
4. Each chunk is sent to the LLM once.
5. The LLM returns formatting metadata + semantic metadata + a short continuity digest.
6. Only that small digest is supplied to the next chunk; prior full source is not resent.
7. Java rejects invented semantic values using exact-source-excerpt validation.
8. Java merges compatible sections across chunk boundaries.
9. The complete assembled `FormattedDocument` is then rendered once to Preview/Copy/Export.

## Preserve mode

The LLM may decide representation but may not rewrite source content. Semantic values must be exact substrings of the referenced source block. Invalid values fall back to source text.

## Content-changing modes

`Enhance` and `Summarize` remain explicit. They use separate prompts because they have different permissions and goals. Their result is then passed through the adaptive semantic formatter.

## Destination behavior

The prompt includes the selected output target. Confluence/Markdown prefer native tables, headings, lists and code blocks. PowerPoint may use visual workflows. Word/PDF use document-oriented structures.

## Configuration

```properties
formatflow.llm.adaptive-chunk-characters=5500
formatflow.llm.adaptive-chunk-blocks=26
formatflow.llm.continuity-characters=700
```
