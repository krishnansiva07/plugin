@echo off
setlocal
echo Starting FormatFlow AI...
mvn spring-boot:run
endlocal
