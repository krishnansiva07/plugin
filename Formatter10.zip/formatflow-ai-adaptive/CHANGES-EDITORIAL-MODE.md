# Editorial Mode Changes

- Kept `gpt-oss-120b`; no model replacement.
- UI output choices reduced to Confluence, Email and HTML.
- Removed Preserve/Enhance selection, Smart Semantic Layout, Symbols and other output-format choices from the active UI.
- Normal formatting now gives the LLM editorial freedom to rewrite, reorganize, deduplicate, split/merge paragraphs and create semantic structures.
- User formatting instructions embedded in the input are explicitly followed when they are clearly instructions.
- Factual grounding remains: do not invent facts; preserve literal technical identifiers/URLs/code/config values unless explicitly asked to change them.
- LLM returns a semantic HTML fragment instead of strict formatting metadata JSON.
- Confluence output is sanitized to simple editor-friendly HTML with no model CSS/classes/scripts.
- Email output gets deterministic Outlook-friendly inline styles after sanitization; subject is kept outside the body.
- HTML output receives a richer green/white portable inline presentation.
- Rich clipboard plus structured plain-text fallback retained.
- Large inputs, including oversized single paragraphs, are hard-split into bounded model calls with opening/previous-output continuity context.
- Browser download now saves the exact generated Confluence/Email/HTML instead of rebuilding it through the legacy document exporter.
- Added free-form renderer tests and updated the formatting-service test for the new flow.
