# Test Fix

Fixed the stale Confluence formatting unit test introduced after rich clipboard styling was added.

`FormattingServicePreserveTest` previously expected exact unstyled fragments such as `<h2>About me</h2>` and `<ul>`. The production renderer now intentionally adds inline styles and wrapper spans so colours, borders and typography can survive Confluence paste, making those exact string assertions invalid.

The test now parses the copied HTML with Jsoup and validates semantic structure, heading text, the expected Confluence green style, and list-item content. This keeps the test aligned with the intended rich-copy behavior instead of weakening the production output.
