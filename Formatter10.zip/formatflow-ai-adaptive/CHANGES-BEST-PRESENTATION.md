# Best Presentation Generation Update

This update upgrades the PowerPoint path from simple HTML-to-slide conversion into a presentation-focused formatter.

## What changed

- PowerPoint prompting now asks the LLM to create a real slide story, not a document outline.
- LangGraph ANALYZE now builds a slide plan with story arc, one key message per slide and suggested slide layout.
- CREATE guidance now supports:
  - `h1` as deck title
  - `h2` as slide title
  - `blockquote` as key takeaway
  - `h3` as two-column/topic-panel sections
  - `ol` as process/step slides
  - `table` as comparison/data slides
- Java PowerPoint export now applies professional layouts:
  - title slide
  - automatic agenda slide for multi-topic decks
  - key-message slide
  - standard bullet slide
  - two-column topic slide
  - process/flow slide
  - table slide with native borders and header styling
- Overloaded slides are automatically split.
- Too many subtopics are split into continued slides.
- Deterministic review now checks for:
  - missing deck title
  - too few slide topics
  - long paragraphs/bullets
  - missing agenda for larger decks
  - overloaded slides
  - lack of presentation-specific structures

## Design principle

The LLM decides the story and content coverage. Java owns the visual layout, slide density, borders, colors, sizing and splitting so the deck remains readable and consistent.
