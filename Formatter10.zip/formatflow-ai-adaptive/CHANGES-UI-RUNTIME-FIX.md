# UI runtime / stale asset fix

- Fixed the `Cannot read properties of null (reading addEventListener)` startup error caused when a cached pre-removal `app.js` still expected `#urlImportBtn` after **Import Web Content** was removed from the HTML.
- Added a version query to `app.js` and `app.css` and disabled browser caching for the static UI assets so HTML/JS versions cannot drift.
- Event binding is now null-safe: one optional/missing control cannot stop later controls such as **Process with LLM & Preview** from being wired.
- Added `favicon.ico`; the browser no longer generates a missing-favicon backend error.
- Missing static resources are returned as HTTP 404 rather than being wrapped by the global API error handler as HTTP 500.
