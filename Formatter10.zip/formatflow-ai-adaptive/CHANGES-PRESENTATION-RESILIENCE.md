# Presentation & LLM Resilience Improvements

## PowerPoint

- Removed character-level ellipsis truncation from the active HTML-to-PPT pipeline.
- Added pagination before rendering for overloaded bullet slides.
- Added continuation slides for process flows longer than five steps.
- Added continuation cards/slides when topic subsections exceed the two-column capacity.
- Added table pagination for more than eight data rows per slide.
- Added wide-table pagination; the first column is repeated while remaining columns are split into groups of four.
- Kept all table rows from generated HTML instead of stopping after ten rows.
- Added PowerPoint text autofit as a final protection against unusual text lengths.
- Added a regression test that verifies unique bullets, seven columns and fourteen table rows remain present in the exported PPTX.

## LLM failure handling

- ANALYZE failure -> deterministic local editorial plan.
- CREATE chunk failure -> preserve successful chunks and locally format only the failed chunk.
- Service outage/timeout/rate-limit/auth failure -> request-scoped circuit opens and remaining chunks use local fallback without repeated model calls.
- REVIEW failure -> deterministic Java review checks; the last usable draft is preserved.
- REPAIR is skipped after a degraded CREATE/REVIEW so a failing LLM cannot overwrite or block a usable result.
- Optional email-subject generation failure -> deterministic local subject; email body still succeeds.
- Transient LLM retries are configurable and default to ten attempts.
- UI reports when resilient fallback was used while still returning a normal preview.

## Configuration

```properties
formatflow.llm.max-attempts=10
```

## Validation note

This environment does not include Maven, so the full Maven test suite could not be executed here. Java source/test files were syntax-parsed by `javac`; the remaining compiler errors are dependency-resolution errors because the Maven classpath is unavailable in the sandbox.
## Exact same-request retry before fallback

- Transient LLM failures now replay the exact same serialized JSON request before local fallback is allowed.
- The model, prompt, temperature, `max_tokens`, message payload, and authentication shape remain unchanged during these retries.
- Default `formatflow.llm.max-attempts=10` means the original request plus up to nine identical retries. If attempt 10 also fails for a transient LLM/service condition, FormatFlow marks the LLM unavailable for that formatting request, reports the condition in the processing activity, and uses the deterministic fallback only to keep the user flow alive.
- Retry applies to HTTP 408/429/500/502/503/504 and transient transport/timeout/malformed-response failures.
- HTTP 400/422 token-limit errors remain a compatibility case: after the rejected request, FormatFlow may lower only `max_tokens` and resend the same prompt.
- 401/403 still use authentication-header discovery when enabled; blindly replaying an invalid credential shape is avoided.
- The LangGraph/local fallback layer receives an error only after the client-level identical retries have been exhausted.
- Added regression coverage that verifies all ten transient request bodies are byte-for-byte identical, that recovery on attempt 10 succeeds normally, and that the LLM-unavailable condition is reported only after all ten attempts fail.

