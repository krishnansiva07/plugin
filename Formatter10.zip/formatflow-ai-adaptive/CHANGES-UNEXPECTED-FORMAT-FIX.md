# Unexpected format error hardening

This revision addresses the opaque `Unexpected server error. Reference: XXXXXXXX` path seen while formatting richer DOCX content.

## What was found

- The uploaded Vibium documentation DOCX is a valid Office ZIP package and its `word/document.xml` can be streamed successfully.
- Formatting-time HTTP failures from the LLM client were represented by a private `RuntimeException`. The LangGraph free-form path deliberately re-threw arbitrary runtime exceptions, so an LLM 400/401/403/422/etc. could bypass the user-readable `IllegalStateException` handler and become an opaque reference code.
- The API-key validation request uses only 24 completion tokens while full formatting requested up to 5,200. Enterprise OpenAI-compatible gateways can accept validation but reject a larger `max_tokens` request.
- DOCX import previously discarded Word paragraph styles such as Heading1/Heading2/ListBullet/ListNumber/CodeBlock, reducing topic/slide structure signals for presentation generation.

## Changes

1. Formatting-time LLM HTTP errors now extend `IllegalStateException` and include the HTTP status plus a compact gateway error message.
2. `max_tokens` is conservatively capped at 4096 by default and automatically retried at 3072/2048/1024 when the gateway explicitly reports a token/context limit.
3. LangGraph runtime errors now fall back to the same bounded Analyze -> Create -> Review -> optional Repair stages executed sequentially. LLM/service failures are not hidden by this fallback.
4. FormattingService wraps any unexpected destination/rendering runtime failure with the exact processing stage.
5. API exception handling now has explicit request-JSON, missing-parameter and upload-size responses instead of routing those cases to the generic 500 handler.
6. Imported text is normalized to remove gateway-unsafe control/noncharacter code points while preserving normal Unicode, tabs and newlines.
7. DOCX streaming import now preserves Word Heading1-4, Title, ListBullet, ListNumber and CodeBlock semantics using lightweight markers so Confluence/HTML/PowerPoint generation sees the original document hierarchy.
8. Fixed PowerPoint source word-count regex so whitespace/newlines from Office imports are counted correctly.
9. Added regression tests for token-budget fallback, readable formatting HTTP errors, DOCX style preservation and imported-text sanitization.

## New configuration

```properties
formatflow.llm.max-completion-tokens=4096
```

Lower this only if the enterprise gateway enforces a smaller completion limit.
