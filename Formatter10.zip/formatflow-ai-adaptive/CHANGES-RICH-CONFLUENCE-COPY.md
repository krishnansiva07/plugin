# Rich Confluence Copy + Topic Coverage

This revision addresses three issues reported from real Confluence paste testing:

1. **Font colours were visible in the UI preview but not copied.**
   - Confluence clipboard HTML is now decorated after sanitization with deterministic inline colours and typography.
   - H1/H2/H3/H4 headings carry BNP-style green text; links and callouts carry compatible inline styling.

2. **Table borders/header design were not copied.**
   - Clipboard tables now include inline `border-collapse`, explicit cell borders, green header background/white text, and legacy `border/cellpadding/cellspacing/bgcolor` hints for editor compatibility.
   - The LLM still emits clean semantic tables; visual styling remains deterministic Java code.

3. **Too few topics/icons for rich content.**
   - ANALYZE now creates a topic-coverage map instead of over-condensing the source.
   - CREATE has a dynamic topic-heading target based on chunk size and explicitly avoids summarizing away unique content in FORMAT mode.
   - Confluence/HTML require an icon on every major H2 and most H3 headings, with varied semantic icons.
   - REVIEW and Java checks can trigger one bounded repair when long content has too few topic headings or weak icon coverage.
