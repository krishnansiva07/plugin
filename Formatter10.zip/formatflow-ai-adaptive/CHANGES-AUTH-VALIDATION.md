# API-key validation hardening

The presentation build used the same LLM validation code as the previous formatter, but the old validation message incorrectly treated every HTTP 401 **and** 403 as "API key rejected". Enterprise LLM gateways frequently use 403 for model/route permission issues, and copied keys may include a `Bearer ` prefix.

This build makes validation more resilient without storing the key:

- accepts a raw key or a value copied as `Bearer <key>`;
- removes accidental surrounding quotes;
- keeps the configured auth header as the first choice;
- after a 401/403 only, can auto-detect common OpenAI-compatible enterprise auth headers (`Authorization: Bearer`, `api-key`, `x-api-key`);
- caches only the successful **header style**, never the API key;
- uses the discovered header style for normal formatting calls too, so validation and generation behave consistently;
- distinguishes 401, 403, 404, 429 and request-schema failures instead of reporting all authorization failures as a bad key;
- surfaces a short service error message when the gateway provides one.

Auto-detection can be disabled with:

```properties
formatflow.llm.auth-auto-detect=false
```
