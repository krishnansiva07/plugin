# LangGraph Editorial Orchestration Changes

## Added

- LangGraph4j core 1.8.20 dependency (Java 17 compatible).
- Stateful editorial graph: `ANALYZE -> CREATE -> REVIEW -> [REPAIR -> REVIEW] -> FINALIZE`.
- One global editorial plan shared across all chunks.
- LLM quality reviewer with strict JSON routing result.
- Deterministic Java checks for duplicate headings, exact repeated long blocks, unsupported HTML and email H1 usage.
- Configurable quality threshold and bounded repair count.
- Representative beginning/middle/end sampling for very large documents.
- Unit tests for both pass-through and repair graph routes.

## Kept

- `gpt-oss-120b` as the configured model.
- Editorial freedom introduced in Formatter05.
- Confluence / Email / HTML as the only active destinations.
- Java sanitization and deterministic destination rendering after the AI graph.

## Default graph configuration

```properties
formatflow.langgraph.max-repairs=1
formatflow.langgraph.review-threshold=80
formatflow.langgraph.plan-sample-characters=18000
formatflow.langgraph.review-sample-characters=28000
```
