# Semantic Layout Layer

This build adds the semantic-layout layer requested for FormatFlow AI.

## Added
- LLM semantic analysis for TABLE, WORKFLOW, TIMELINE, COMPARISON, STATUS, CHECKLIST, KPI, HIERARCHY, ARCHITECTURE, CODE_GROUP and CALLOUT.
- Exact-source-excerpt validation in Preserve mode.
- Safe fallback to TEXT when the LLM returns an unsafe/invalid semantic structure.
- One structured-JSON repair attempt for semantic-layout responses.
- Structured-JSON repair for line-level formatting metadata.
- Chunk-by-chunk semantic processing for large documents.
- Safe coalescing of adjacent compatible semantic sections.
- HTML/Confluence/Markdown semantic renderers.
- Word semantic tables, workflows, timelines, cards, checklists and callouts.
- PowerPoint semantic tables/grids, workflow node shapes, cards, timelines and items.
- PDF semantic tables, workflow boxes, timelines/checklists/cards in a PDF-safe representation.
- UI option: Smart Semantic Layout.
- Processing information showing detected semantic layouts and fallback usage.
- Semantic demo input and validator/rendering tests.

## Preservation rule
In Format + Preserve mode, source content is not rewritten. Any visible semantic value returned by the LLM must match an exact excerpt from the referenced source block; otherwise it is rejected.

## Build
Run:

mvn clean test
mvn clean package

Then:

java -jar target/formatflow-ai-0.0.1-SNAPSHOT.jar

## Adaptive LLM revision

- Replaced duplicate normal-formatting LLM passes with `AdaptiveSemanticOrchestrator`.
- One bounded call now returns both line formatting metadata and semantic layout metadata.
- Added blank-line-aware adaptive chunking (`ContentParser.adaptiveChunks`).
- Added <=700 character previous-chunk continuity context; previous full source is not resent.
- Added `DocumentAssemblyService` to merge compatible validated sections into one final document before preview.
- Added deterministic formatting fallback per missing/invalid LLM item.
- Added low-memory `DocxStreamingTextExtractor` using StAX over `word/document.xml`.
- Added tests for adaptive chunk grouping, cross-chunk table assembly and streaming DOCX extraction.
