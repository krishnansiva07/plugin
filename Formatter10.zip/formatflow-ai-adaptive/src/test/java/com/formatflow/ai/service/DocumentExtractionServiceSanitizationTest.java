package com.formatflow.ai.service;

import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

class DocumentExtractionServiceSanitizationTest {

    @Test
    void removesGatewayUnsafeControlAndNonCharactersButKeepsNormalUnicode() {
        DocumentExtractionService service = new DocumentExtractionService(
                new ContentDiffService(), new DocxStreamingTextExtractor(), 1024 * 1024
        );

        String input = "Heading\u0000\n✅ Value\t42\uFFFE\nRésumé";
        String cleaned = service.sanitizeImportedText(input);

        assertThat(cleaned).contains("Heading", "✅ Value\t42", "Résumé");
        assertThat(cleaned).doesNotContain("\u0000", "\uFFFE");
    }
}
