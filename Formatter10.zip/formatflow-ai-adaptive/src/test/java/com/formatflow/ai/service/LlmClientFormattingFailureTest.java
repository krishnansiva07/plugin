package com.formatflow.ai.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.formatflow.ai.config.LlmProperties;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.http.HttpClient;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class LlmClientFormattingFailureTest {

    private HttpServer server;

    @AfterEach
    void stopServer() {
        if (server != null) server.stop(0);
    }

    @Test
    void replaysTheExactSameRequestAfterTransientGatewayFailure() throws Exception {
        AtomicInteger calls = new AtomicInteger();
        List<String> bodies = new ArrayList<>();
        server = HttpServer.create(new InetSocketAddress("127.0.0.1", 0), 0);
        server.createContext("/chat/completions", exchange -> {
            bodies.add(new String(exchange.getRequestBody().readAllBytes(), StandardCharsets.UTF_8));
            if (calls.incrementAndGet() == 1) {
                respond(exchange, 503, "{\"error\":{\"message\":\"temporary outage\"}}");
            } else {
                respond(exchange, 200, "{\"choices\":[{\"message\":{\"content\":\"RECOVERED\"}}]}");
            }
        });
        server.start();

        LlmClient client = clientFor(server.getAddress().getPort());
        String result = client.chat("test-key", "create my presentation", 1800, 0.2);

        assertThat(result).isEqualTo("RECOVERED");
        assertThat(calls.get()).isEqualTo(2);
        assertThat(bodies).hasSize(2);
        assertThat(bodies.get(1)).isEqualTo(bodies.get(0));
    }

    @Test
    void replaysSameRequestWhenSuccessfulResponseIsTemporarilyMalformed() throws Exception {
        AtomicInteger calls = new AtomicInteger();
        List<String> bodies = new ArrayList<>();
        server = HttpServer.create(new InetSocketAddress("127.0.0.1", 0), 0);
        server.createContext("/chat/completions", exchange -> {
            bodies.add(new String(exchange.getRequestBody().readAllBytes(), StandardCharsets.UTF_8));
            if (calls.incrementAndGet() == 1) {
                respond(exchange, 200, "{\"choices\":[]}");
            } else {
                respond(exchange, 200, "{\"choices\":[{\"message\":{\"content\":\"OK\"}}]}");
            }
        });
        server.start();

        LlmClient client = clientFor(server.getAddress().getPort());
        String result = client.chat("test-key", "format this document", 1200, 0.1);

        assertThat(result).isEqualTo("OK");
        assertThat(calls.get()).isEqualTo(2);
        assertThat(bodies.get(1)).isEqualTo(bodies.get(0));
    }


    @Test
    void canRecoverOnTheTenthIdenticalAttempt() throws Exception {
        AtomicInteger calls = new AtomicInteger();
        List<String> bodies = new ArrayList<>();
        server = HttpServer.create(new InetSocketAddress("127.0.0.1", 0), 0);
        server.createContext("/chat/completions", exchange -> {
            bodies.add(new String(exchange.getRequestBody().readAllBytes(), StandardCharsets.UTF_8));
            if (calls.incrementAndGet() < 10) {
                respond(exchange, 503, "{\"error\":{\"message\":\"temporary outage\"}}");
            } else {
                respond(exchange, 200, "{\"choices\":[{\"message\":{\"content\":\"RECOVERED_ON_TENTH\"}}]}");
            }
        });
        server.start();

        LlmClient client = clientFor(server.getAddress().getPort());
        String result = client.chat("test-key", "create my presentation", 1800, 0.2);

        assertThat(result).isEqualTo("RECOVERED_ON_TENTH");
        assertThat(calls.get()).isEqualTo(10);
        assertThat(bodies).hasSize(10);
        assertThat(bodies).allMatch(body -> body.equals(bodies.get(0)));
    }

    @Test
    void reportsLlmUnavailableOnlyAfterAllTenAttemptsFail() throws Exception {
        AtomicInteger calls = new AtomicInteger();
        List<String> bodies = new ArrayList<>();
        server = HttpServer.create(new InetSocketAddress("127.0.0.1", 0), 0);
        server.createContext("/chat/completions", exchange -> {
            calls.incrementAndGet();
            bodies.add(new String(exchange.getRequestBody().readAllBytes(), StandardCharsets.UTF_8));
            respond(exchange, 503, "{\"error\":{\"message\":\"temporary outage\"}}");
        });
        server.start();

        LlmClient client = clientFor(server.getAddress().getPort());

        assertThatThrownBy(() -> client.chat("test-key", "create my presentation", 1800, 0.2))
                .isInstanceOf(IllegalStateException.class)
                .hasMessageContaining("LLM unavailable after 10 attempts");
        assertThat(calls.get()).isEqualTo(10);
        assertThat(bodies).hasSize(10);
        assertThat(bodies).allMatch(body -> body.equals(bodies.get(0)));
    }

    @Test
    void lowersMaxTokensWhenGatewayReportsCompletionTokenLimit() throws Exception {
        AtomicInteger calls = new AtomicInteger();
        ObjectMapper mapper = new ObjectMapper();
        server = HttpServer.create(new InetSocketAddress("127.0.0.1", 0), 0);
        server.createContext("/chat/completions", exchange -> {
            calls.incrementAndGet();
            JsonNode request = mapper.readTree(exchange.getRequestBody());
            int maxTokens = request.path("max_tokens").asInt();
            if (maxTokens > 2048) {
                respond(exchange, 400, "{\"error\":{\"message\":\"max_tokens must be <= 2048\"}}");
            } else {
                respond(exchange, 200, "{\"choices\":[{\"message\":{\"content\":\"OK\"}}]}");
            }
        });
        server.start();

        LlmClient client = clientFor(server.getAddress().getPort());
        String result = client.chat("test-key", "format this document", 5200, 0.1);

        assertThat(result).isEqualTo("OK");
        assertThat(calls.get()).isGreaterThanOrEqualTo(2);
    }

    @Test
    void formattingHttpFailureIsReadableIllegalStateInsteadOfOpaqueRuntimeError() throws Exception {
        server = HttpServer.create(new InetSocketAddress("127.0.0.1", 0), 0);
        server.createContext("/chat/completions", exchange ->
                respond(exchange, 403, "{\"error\":{\"message\":\"model access denied\"}}"));
        server.start();

        LlmClient client = clientFor(server.getAddress().getPort());

        assertThatThrownBy(() -> client.chat("test-key", "format this document", 1200, 0.1))
                .isInstanceOf(IllegalStateException.class)
                .hasMessageContaining("HTTP 403")
                .hasMessageContaining("model access denied");
    }

    private LlmClient clientFor(int port) {
        LlmProperties properties = new LlmProperties();
        properties.setBaseUrl("http://127.0.0.1:" + port);
        properties.setChatPath("/chat/completions");
        properties.setModel("gpt-oss-120b");
        properties.setAuthHeader("Authorization");
        properties.setAuthPrefix("Bearer ");
        properties.setAuthAutoDetect(false);
        properties.setRequestTimeoutSeconds(5);
        properties.setMaxAttempts(10);
        return new LlmClient(HttpClient.newHttpClient(), new ObjectMapper(), properties);
    }

    private static void respond(HttpExchange exchange, int status, String body) throws IOException {
        byte[] bytes = body.getBytes(StandardCharsets.UTF_8);
        exchange.getResponseHeaders().set("Content-Type", "application/json");
        exchange.sendResponseHeaders(status, bytes.length);
        exchange.getResponseBody().write(bytes);
        exchange.close();
    }
}
