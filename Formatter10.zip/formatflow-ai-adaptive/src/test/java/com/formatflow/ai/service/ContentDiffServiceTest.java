package com.formatflow.ai.service;

import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

class ContentDiffServiceTest {

    private final ContentDiffService service = new ContentDiffService();

    @Test
    void identicalContentIsExactlyPreserved() {
        String content = "server.port=8090\nJava 17\nSpring Boot";
        var stats = service.compare(content, content);

        assertThat(stats.exactContentPreserved()).isTrue();
        assertThat(stats.addedWords()).isZero();
        assertThat(stats.removedWords()).isZero();
        assertThat(stats.originalCharacters()).isEqualTo(stats.formattedCharacters());
    }

    @Test
    void detectsAddedAndRemovedWords() {
        var stats = service.compare("alpha beta gamma", "alpha beta delta");

        assertThat(stats.exactContentPreserved()).isFalse();
        assertThat(stats.addedWords()).isEqualTo(1);
        assertThat(stats.removedWords()).isEqualTo(1);
    }
}
