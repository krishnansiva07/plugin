package com.formatflow.ai.service;

import com.formatflow.ai.model.FormatModels.*;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

class DocumentAssemblyServiceTest {

    private final DocumentAssemblyService service = new DocumentAssemblyService();

    @Test
    void adjacentTablesFromDifferentChunksAreMergedIntoOneDocumentTable() {
        List<SourceBlock> source = List.of(
                new SourceBlock("B00001", "Configuration", false, false, false),
                new SourceBlock("B00002", "Java: 17", false, false, false),
                new SourceBlock("B00003", "Port: 8090", false, false, false),
                new SourceBlock("B00004", "Model: gpt-oss-120b", false, false, false)
        );

        SemanticSection first = new SemanticSection(
                "S1", "TABLE", "B00001", "Configuration", "CONFIG",
                List.of("B00001", "B00002"),
                List.of("Property", "Value"),
                List.of(new SemanticRow(List.of(
                        new SemanticValue("B00002", "Java", "KEY", "NONE"),
                        new SemanticValue("B00002", "17", "VALUE", "NONE")
                ))),
                List.of(), List.of(), List.of()
        );

        SemanticSection second = new SemanticSection(
                "S9", "TABLE", "", "", "CONFIG",
                List.of("B00003", "B00004"),
                List.of("Property", "Value"),
                List.of(
                        new SemanticRow(List.of(
                                new SemanticValue("B00003", "Port", "KEY", "NONE"),
                                new SemanticValue("B00003", "8090", "VALUE", "NONE")
                        )),
                        new SemanticRow(List.of(
                                new SemanticValue("B00004", "Model", "KEY", "NONE"),
                                new SemanticValue("B00004", "gpt-oss-120b", "VALUE", "NONE")
                        ))
                ),
                List.of(), List.of(), List.of()
        );

        List<SemanticSection> result = service.assemble(List.of(first, second), source);

        assertThat(result).hasSize(1);
        assertThat(result.get(0).layoutType()).isEqualTo("TABLE");
        assertThat(result.get(0).rows()).hasSize(3);
        assertThat(result.get(0).sourceIds()).containsExactly("B00001", "B00002", "B00003", "B00004");
    }
}
