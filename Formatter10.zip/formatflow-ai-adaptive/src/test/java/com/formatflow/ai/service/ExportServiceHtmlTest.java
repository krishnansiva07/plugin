package com.formatflow.ai.service;

import com.formatflow.ai.model.FormatModels.*;
import org.junit.jupiter.api.Test;

import java.nio.charset.StandardCharsets;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

class ExportServiceHtmlTest {

    @Test
    void htmlExportIsFullStyledUtf8Document() {
        IconCatalog icons = new IconCatalog();
        DocumentRenderer renderer = new DocumentRenderer(icons);
        ExportService service = new ExportService(renderer, icons, new PdfFontResolver());
        FormattedDocument document = new FormattedDocument(
                "Network",
                List.of(
                        new DocumentBlock("B00001", "Network", BlockType.HEADING, "NETWORK", "🌐", "STRONG", "NONE"),
                        new DocumentBlock("B00002", "- Connection available", BlockType.BULLET, "NONE", "", "NONE", "CHECK")
                ),
                List.of(),
                "Network\n- Connection available",
                "Technical Team",
                "Inform",
                "HTML",
                "FORMAT",
                false,
                ""
        );

        ExportService.ExportedFile file = service.export(new ExportRequest(document, "HTML", "network"));
        String html = new String(file.bytes(), StandardCharsets.UTF_8);

        assertThat(file.filename()).isEqualTo("network.html");
        assertThat(file.contentType()).contains("text/html").contains("UTF-8");
        assertThat(html).startsWith("<!doctype html>");
        assertThat(html).contains("🌐").contains("✓").contains("<style>");
    }
}
