package com.formatflow.ai.service;

import com.formatflow.ai.model.FormatModels.*;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

class SemanticPresentationPolicyTest {

    private final SemanticPresentationPolicy policy = new SemanticPresentationPolicy();

    @Test
    void repeatedStructuredItemsBecomeTableInsteadOfCards() {
        SemanticSection section = new SemanticSection(
                "S1", "STATUS", "", "", "STATUS",
                List.of("B1", "B2", "B3"),
                List.of(), List.of(), List.of(), List.of(),
                List.of(
                        new SemanticItem("B1", "Data Analysis & Comparison", "Compare products and services", "", "NONE"),
                        new SemanticItem("B2", "Project Management", "Roadmaps and task ownership", "", "NONE"),
                        new SemanticItem("B3", "Resource Allocation", "Assigned capacity and utilization", "", "NONE")
                )
        );

        SemanticSection normalized = policy.normalize(List.of(section), "CONFLUENCE").get(0);

        assertThat(normalized.layoutType()).isEqualTo("TABLE");
        assertThat(normalized.columns()).containsExactly("Item", "Details");
        assertThat(normalized.rows()).hasSize(3);
    }
}
