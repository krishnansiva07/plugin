package com.formatflow.ai.service;

import com.formatflow.ai.model.FormatModels.*;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

class SemanticLayoutValidatorTest {

    @Test
    void rejectsInventedCellTextAndFallsBackWithoutLosingSource() {
        SemanticLayoutValidator validator = new SemanticLayoutValidator(new IconCatalog());
        List<SourceBlock> source = List.of(
                new SourceBlock("B00001", "Java version is 17.", false, false, false)
        );
        SemanticSection candidate = new SemanticSection(
                "S1", "TABLE", "", "", "CONFIG", List.of("B00001"),
                List.of("Property", "Value"),
                List.of(new SemanticRow(List.of(
                        new SemanticValue("B00001", "Java version", "KEY", "NONE"),
                        new SemanticValue("B00001", "18", "VALUE", "NONE")
                ))), List.of(), List.of(), List.of()
        );

        var result = validator.validateChunk(source, List.of(candidate), 1);
        assertThat(result.fallbackUsed()).isTrue();
        assertThat(result.sections()).anyMatch(s -> s.sourceIds().contains("B00001"));
    }

    @Test
    void acceptsExactWorkflowExcerpts() {
        SemanticLayoutValidator validator = new SemanticLayoutValidator(new IconCatalog());
        List<SourceBlock> source = List.of(
                new SourceBlock("B00001", "User sends request to ChatController.", false, false, false),
                new SourceBlock("B00002", "ChatController sends request to ChatService.", false, false, false)
        );
        SemanticSection candidate = new SemanticSection(
                "S1", "WORKFLOW", "", "", "PROCESS", List.of("B00001", "B00002"),
                List.of(), List.of(),
                List.of(
                        new SemanticNode("N1", "B00001", "User", "PEOPLE"),
                        new SemanticNode("N2", "B00001", "ChatController", "API"),
                        new SemanticNode("N3", "B00002", "ChatService", "API")
                ),
                List.of(
                        new SemanticEdge("N1", "N2", "B00001", "sends request to"),
                        new SemanticEdge("N2", "N3", "B00002", "sends request to")
                ), List.of()
        );

        var result = validator.validateChunk(source, List.of(candidate), 1);
        assertThat(result.sections().get(0).layoutType()).isEqualTo("WORKFLOW");
    }
}
