package com.formatflow.ai.service;

import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

class ContentParserTest {
    private final ContentParser parser = new ContentParser();

    @Test
    void identifiesBulletAndCodeWithoutChangingText() {
        var blocks = parser.parse("Network\n- Check endpoint\nserver.port=8090");
        assertThat(blocks).hasSize(3);
        assertThat(blocks.get(1).bulletLike()).isTrue();
        assertThat(blocks.get(2).codeLike()).isTrue();
        assertThat(blocks.get(2).text()).isEqualTo("server.port=8090");
    }
    @Test
    void adaptiveChunksKeepBlankLineGroupsTogether() {
        var blocks = parser.parse("Heading\nA: 1\nB: 2\n\nSecond Heading\nC: 3\nD: 4");
        var chunks = parser.adaptiveChunks(blocks, 1000, 4);

        assertThat(chunks).hasSize(2);
        assertThat(chunks.get(0)).extracting(com.formatflow.ai.model.FormatModels.SourceBlock::text).containsExactly("Heading", "A: 1", "B: 2");
        assertThat(chunks.get(1)).extracting(com.formatflow.ai.model.FormatModels.SourceBlock::text).containsExactly("Second Heading", "C: 3", "D: 4");
    }

}
