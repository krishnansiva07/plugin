package com.formatflow.ai.service;

import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

class LlmClientKeyNormalizationTest {

    @Test
    void acceptsRawKey() {
        assertThat(LlmClient.normalizeApiKey("abc123")).isEqualTo("abc123");
    }

    @Test
    void removesBearerPrefixAndWhitespace() {
        assertThat(LlmClient.normalizeApiKey("  Bearer abc123  ")).isEqualTo("abc123");
    }

    @Test
    void removesAccidentalQuotes() {
        assertThat(LlmClient.normalizeApiKey("\"Bearer abc123\"")).isEqualTo("abc123");
    }
}
