package com.formatflow.ai.service;

import com.formatflow.ai.model.FormatModels.*;
import org.apache.poi.xslf.usermodel.XMLSlideShow;
import org.apache.poi.xslf.usermodel.XSLFTextShape;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayInputStream;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

class ExportServicePowerPointTest {

    @Test
    void powerpointExportUsesGeneratedHtmlAsSlideOutline() throws Exception {
        IconCatalog icons = new IconCatalog();
        DocumentRenderer renderer = new DocumentRenderer(icons);
        ExportService service = new ExportService(renderer, icons, new PdfFontResolver());
        FormattedDocument document = new FormattedDocument(
                "",
                List.of(),
                List.of(),
                "Overview\nCapability one\nCapability two",
                "Technical Team",
                "Knowledge Sharing",
                "POWERPOINT",
                "FORMAT",
                true,
                ""
        );
        String html = """
                <h1>Automation Formatter</h1>
                <h2>📌 Overview</h2>
                <ul><li>Converts content into presentation-ready slides</li><li>Keeps the structure concise</li></ul>
                <h2>📊 Capability Matrix</h2>
                <table><tr><th>Area</th><th>Value</th></tr><tr><td>Confluence</td><td>Rich copy</td></tr></table>
                """;

        ExportService.ExportedFile file = service.export(new ExportRequest(document, "POWERPOINT", "formatter", html));

        assertThat(file.filename()).isEqualTo("formatter.pptx");
        assertThat(file.contentType()).isEqualTo("application/vnd.openxmlformats-officedocument.presentationml.presentation");
        assertThat(file.bytes().length).isGreaterThan(2500);
        try (XMLSlideShow ppt = new XMLSlideShow(new ByteArrayInputStream(file.bytes()))) {
            assertThat(ppt.getSlides().size()).isGreaterThanOrEqualTo(3);
        }
    }

    @Test
    void powerpointExportAddsAgendaAndSplitsProfessionalLayouts() throws Exception {
        IconCatalog icons = new IconCatalog();
        DocumentRenderer renderer = new DocumentRenderer(icons);
        ExportService service = new ExportService(renderer, icons, new PdfFontResolver());
        FormattedDocument document = new FormattedDocument(
                "",
                List.of(),
                List.of(),
                "Large presentation source",
                "Technical Team",
                "Knowledge Sharing",
                "POWERPOINT",
                "FORMAT",
                true,
                ""
        );
        String html = """
                <h1>Automation Platform Overview</h1>
                <h2>📌 Executive Message</h2><blockquote>One platform improves formatting consistency across channels.</blockquote>
                <h2>📋 Capabilities</h2><h3>Confluence</h3><ul><li>Rich copy</li><li>Topic icons</li></ul><h3>Email</h3><ul><li>Outlook-ready HTML</li><li>Concise body</li></ul>
                <h2>🔄 Workflow</h2><ol><li>Analyze source</li><li>Create slide plan</li><li>Review quality</li><li>Export deck</li></ol>
                <h2>📊 Comparison</h2><table><tr><th>Output</th><th>Strength</th></tr><tr><td>PPT</td><td>Native slides</td></tr><tr><td>HTML</td><td>Rich web view</td></tr></table>
                <h2>⚠️ Quality Controls</h2><ul><li>Missing topics are flagged</li><li>Long slide text is repaired</li></ul>
                <h2>🚀 Next Steps</h2><ul><li>Validate with real content</li><li>Share feedback</li></ul>
                """;

        ExportService.ExportedFile file = service.export(new ExportRequest(document, "POWERPOINT", "platform", html));

        try (XMLSlideShow ppt = new XMLSlideShow(new ByteArrayInputStream(file.bytes()))) {
            assertThat(ppt.getSlides().size()).isGreaterThanOrEqualTo(8); // title + auto agenda + six source slides
        }
    }

    @Test
    void powerpointPaginationPreservesBulletsTableRowsAndColumns() throws Exception {
        IconCatalog icons = new IconCatalog();
        DocumentRenderer renderer = new DocumentRenderer(icons);
        ExportService service = new ExportService(renderer, icons, new PdfFontResolver());
        FormattedDocument document = new FormattedDocument(
                "", List.of(), List.of(), "Lossless presentation source",
                "Technical Team", "Knowledge Sharing", "POWERPOINT", "FORMAT", true, ""
        );

        StringBuilder html = new StringBuilder("<h1>Lossless Deck</h1><h2>📌 Detailed Coverage</h2><ul>");
        for (int i = 1; i <= 13; i++) html.append("<li>UNIQUE_BULLET_").append(i).append("</li>");
        html.append("</ul><h2>📊 Wide Data</h2><table><tr>");
        for (int c = 1; c <= 7; c++) html.append("<th>HEADER_").append(c).append("</th>");
        html.append("</tr>");
        for (int r = 1; r <= 14; r++) {
            html.append("<tr>");
            for (int c = 1; c <= 7; c++) html.append("<td>CELL_").append(r).append('_').append(c).append("</td>");
            html.append("</tr>");
        }
        html.append("</table>");

        ExportService.ExportedFile file = service.export(new ExportRequest(
                document, "POWERPOINT", "lossless", html.toString()));

        try (XMLSlideShow ppt = new XMLSlideShow(new ByteArrayInputStream(file.bytes()))) {
            String allText = ppt.getSlides().stream()
                    .flatMap(slide -> slide.getShapes().stream())
                    .filter(XSLFTextShape.class::isInstance)
                    .map(XSLFTextShape.class::cast)
                    .map(XSLFTextShape::getText)
                    .reduce("", (a, b) -> a + "\n" + b);

            for (int i = 1; i <= 13; i++) assertThat(allText).contains("UNIQUE_BULLET_" + i);
            for (int c = 1; c <= 7; c++) assertThat(allText).contains("HEADER_" + c);
            assertThat(allText).contains("CELL_14_7");
            assertThat(ppt.getSlides().size()).isGreaterThan(5);
        }
    }

}
