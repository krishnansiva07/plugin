package com.formatflow.ai.service;

import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

class FreeformDocumentRendererTest {

    private final DocumentRenderer renderer = new DocumentRenderer(new IconCatalog());

    @Test
    void sanitizesExecutableMarkupButKeepsConfluenceStructure() {
        String raw = "<h2>About me</h2><script>alert(1)</script><ul><li>Maintain profiles</li></ul>";
        String html = renderer.sanitizeFreeformHtml(raw);

        assertThat(html).contains("<h2>About me</h2>", "<ul>", "Maintain profiles");
        assertThat(html).doesNotContain("<script", "alert(1)");
    }

    @Test
    void emailCopyAddsOnlyDeterministicInlinePresentation() {
        String safe = renderer.sanitizeFreeformHtml("<h2>Status</h2><p>Ready for review.</p><table><tr><th>Item</th><th>Status</th></tr><tr><td>API</td><td>Ready</td></tr></table>");
        String email = renderer.freeformCopyHtml(safe, "EMAIL");

        assertThat(email).contains("font-family:Arial", "border-collapse:collapse", "Ready for review.");
        assertThat(email).doesNotContain("<script", "<style");
    }

    @Test
    void plainTextFallbackKeepsBulletsAndTableRowsReadable() {
        String safe = renderer.sanitizeFreeformHtml("<h2>Actions</h2><ul><li>Review</li><li>Approve</li></ul><table><tr><th>Owner</th><th>Status</th></tr><tr><td>QA</td><td>Open</td></tr></table>");
        String text = renderer.freeformCopyText(safe);

        assertThat(text).contains("Actions", "• Review", "• Approve", "Owner | Status", "QA | Open");
    }

    @Test
    void confluenceCopyCarriesInlineColoursAndTableBorders() {
        String safe = renderer.sanitizeFreeformHtml(
                "<h2>🧪 Testing</h2><p>Coverage details.</p>" +
                "<table><thead><tr><th>Area</th><th>Status</th></tr></thead>" +
                "<tbody><tr><td>API</td><td>Ready</td></tr></tbody></table>");

        String confluence = renderer.freeformCopyHtml(safe, "CONFLUENCE");

        assertThat(confluence)
                .contains("color:#006b36", "border-collapse:collapse", "border=\"1\"",
                        "background-color:#006b36", "🧪 Testing", "API");
        assertThat(confluence).doesNotContain("<script", "<style");
    }
}
