const state = {
  format:"CONFLUENCE",
  operation:"FORMAT",
  originalContent:"",
  finalContent:"",
  previewHtml:"",
  copyHtml:"",
  copyText:"",
  document:null,
  currentPreview:"formatted",
  generatedEmailSubject:false
};
const $ = id => document.getElementById(id);

document.addEventListener("DOMContentLoaded", async()=>{
  try{
    bindEvents();
    updateCounts();
    await checkSession();
  }catch(e){
    // A missing/changed optional UI element must never leave the whole page dead.
    console.error("FormatFlow UI initialization failed",e);
    try{await checkSession()}catch{}
    toast("The UI recovered from an initialization issue. Refresh once if a control does not respond.",true);
  }
});

function bindEvents(){
  const on=(id,event,handler)=>{
    const node=$(id);
    if(!node){
      console.warn(`[FormatFlow] UI element #${id} is not present; skipping ${event} binding.`);
      return false;
    }
    node.addEventListener(event,handler);
    return true;
  };

  on("toggleKey","click",()=>{const key=$("apiKey");if(key)key.type=key.type==="password"?"text":"password"});
  on("validateKeyBtn","click",validateKey);
  on("apiKey","keydown",e=>{if(e.key==="Enter")validateKey()});
  on("disconnectBtn","click",disconnect);
  on("changeKeyBtn","click",()=>{const key=$("apiKey");if(key)key.value="";showAuth()});
  document.querySelectorAll(".input-tabs .tab").forEach(b=>b.addEventListener("click",()=>switchInputTab(b.dataset.tab)));
  on("contentInput","input",onContentChanged);
  on("emailSubject","input",()=>{state.generatedEmailSubject=false});
  on("uploadBtn","click",uploadFile);
  document.querySelectorAll(".activity-card").forEach(b=>b.addEventListener("click",()=>selectOperation(b)));
  document.querySelectorAll(".format-card").forEach(b=>b.addEventListener("click",()=>selectFormat(b)));
  on("previewBtn","click",preview);
  on("copyBtn","click",copyOutput);
  on("downloadBtn","click",downloadOutput);
  document.querySelectorAll(".mini-tab").forEach(b=>b.addEventListener("click",()=>{
    state.currentPreview=b.dataset.preview;
    document.querySelectorAll(".mini-tab").forEach(x=>x.classList.remove("active"));
    b.classList.add("active");
    renderPreviewMode();
  }));
}

async function checkSession(){
  try{
    const r=await fetch("/api/session/status");
    const d=await r.json();
    $("authEndpoint").textContent=`Model: ${d.model||"Not configured"} • Endpoint: ${d.baseUrl||"Not configured"}`;
    d.connected?showApp():showAuth();
  }catch{
    showAuth();
    showMessage("authMessage","Unable to reach FormatFlow server.",true);
  }
}

async function validateKey(){
  const apiKey=$("apiKey").value.trim();
  if(!apiKey){showMessage("authMessage","Enter the LLM API key.",true);return}
  setBusy("validateKeyBtn",true,"Validating...");
  try{
    const r=await fetch("/api/session/validate",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({apiKey})});
    const d=await r.json();
    if(!d.valid){showMessage("authMessage",d.message||"Validation failed.",true);return}
    $("apiKey").value="";
    showApp();
  }catch{
    showMessage("authMessage","Unable to validate the key.",true);
  }finally{
    setBusy("validateKeyBtn",false,"Validate & Continue");
  }
}

async function disconnect(){
  try{await fetch("/api/session/disconnect",{method:"POST"})}
  finally{state.document=null;state.copyHtml="";state.copyText="";showAuth()}
}
function showAuth(){$("authGate").classList.remove("hidden");$("appShell").classList.add("hidden")}
function showApp(){$("authGate").classList.add("hidden");$("appShell").classList.remove("hidden")}
function switchInputTab(name){document.querySelectorAll(".input-tabs .tab").forEach(x=>x.classList.toggle("active",x.dataset.tab===name));["paste","upload"].forEach(t=>$(t+"Tab").classList.toggle("active",t===name))}

function selectOperation(btn){
  state.operation=btn.dataset.operation;
  document.querySelectorAll(".activity-card").forEach(x=>x.classList.remove("selected"));
  btn.classList.add("selected");
  $("summaryOptions").classList.toggle("hidden",state.operation!=="SUMMARIZE");
  $("topProtectionText").textContent=state.operation==="SUMMARIZE"
    ? "Summarize + rewrite + destination formatting"
    : "Full formatting freedom • factual grounding retained";
}

function selectFormat(card){
  state.format=card.dataset.format;
  document.querySelectorAll(".format-card").forEach(x=>x.classList.remove("selected"));
  card.classList.add("selected");
  $("emailSubjectWrap").classList.toggle("hidden",state.format!=="EMAIL");
  updateActionLabels();
}

function updateActionLabels(){
  const copyLabel={CONFLUENCE:"Copy for Confluence",EMAIL:"Copy Email Body",HTML:"Copy Formatted HTML",POWERPOINT:"Copy Slide Outline"}[state.format];
  const downloadLabel={CONFLUENCE:"Download Confluence HTML",EMAIL:"Download Email HTML",HTML:"Download HTML",POWERPOINT:"Download PowerPoint"}[state.format];
  $("copyBtn").textContent=copyLabel;
  $("downloadBtn").textContent=downloadLabel;
}

function onContentChanged(){
  if(state.generatedEmailSubject){$("emailSubject").value="";state.generatedEmailSubject=false}
  updateCounts();
}

function updateCounts(){
  const t=$("contentInput").value;
  $("wordCount").textContent=`${wordCount(t)} words`;
  $("charCount").textContent=`${t.length} characters`;
}

async function uploadFile(){
  const file=$("fileInput").files[0];
  if(!file){showMessage("importMessage","Choose a file first.",true);return}
  const fd=new FormData();fd.append("file",file);showMessage("importMessage","Importing...");
  try{
    const d=await jsonOrError(await fetch("/api/import/file",{method:"POST",body:fd}));
    $("contentInput").value=d.content;updateCounts();switchInputTab("paste");
    showMessage("importMessage",`Imported ${d.words} words from ${d.source}.`,false);
  }catch(e){handleApiError(e,"importMessage")}
}

async function preview(){
  const content=$("contentInput").value;
  if(!content.trim()){toast("Add source content first.",true);return}
  const subjectWasBlank=!$("emailSubject").value.trim();
  const request={
    content,
    audience:$("audience").value,
    purpose:$("purpose").value,
    format:state.format,
    operation:state.operation,
    mode:"ENHANCE",
    summaryLength:$("summaryLength").value,
    visualStyle:"Professional Green",
    iconLevel:"RICH",
    emailSubject:$("emailSubject").value,
    generateEmailSubject:$("generateSubject").checked,
    smartLayout:false
  };

  setBusy("previewBtn",true,state.operation==="SUMMARIZE"?"Summarizing & formatting...":"Editing & formatting...");
  $("processingInfo").classList.remove("hidden");
  $("processingInfo").textContent="LangGraph is analyzing the document, creating a destination-specific draft, and reviewing it before finalizing. Large inputs keep one shared editorial plan across chunks.";

  try{
    const d=await jsonOrError(await fetch("/api/format/preview",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(request)}));
    state.originalContent=content;
    state.finalContent=d.finalContent||"";
    state.previewHtml=d.previewHtml||"";
    state.copyHtml=d.copyHtml||"";
    state.copyText=d.copyText||d.finalContent||"";
    state.document=d.document||null;
    if(state.format==="EMAIL" && d.document && d.document.emailSubject && subjectWasBlank) {
      $("emailSubject").value=d.document.emailSubject;
      state.generatedEmailSubject=true;
    }
    renderPreviewMode();
    updateStats(d.stats);
    $("copyBtn").disabled=false;
    $("downloadBtn").disabled=false;
    updateActionLabels();
    $("processingInfo").textContent=`${d.processing.activity} • ${d.processing.llmCalls} LLM call(s)${d.processing.chunked?` • ${d.processing.formattingChunks} chunks assembled`:" • Single model pass"}`;
    const fallbackUsed=(d.processing.activity||"").includes("Resilient fallback");
    toast(fallbackUsed?"Preview ready using resilient fallback; source content was preserved.":"Preview ready.",false);
  }catch(e){
    if(e.status===401)showAuth();
    else{toast(e.message||"Processing failed.",true);$("processingInfo").textContent="Processing failed. See the error message."}
  }finally{
    setBusy("previewBtn",false,"✦ Process with LLM & Preview");
  }
}

function renderPreviewMode(){
  if(!state.previewHtml && !state.finalContent)return;
  if(state.currentPreview==="formatted"){
    $("previewArea").innerHTML=state.previewHtml;
  }else if(state.currentPreview==="original"){
    $("previewArea").innerHTML=`<div class="side-box"><h4>Original Content</h4><pre>${escapeHtml(state.originalContent)}</pre></div>`;
  }else{
    $("previewArea").innerHTML=`<div class="side-by-side"><div class="side-box"><h4>Original</h4><pre>${escapeHtml(state.originalContent)}</pre></div><div class="side-box"><h4>LLM Output</h4><pre>${escapeHtml(state.finalContent)}</pre></div></div>`;
  }
}

function updateStats(s){
  $("statOriginal").textContent=s.originalWords;
  $("statFormatted").textContent=s.formattedWords;
  $("statAdded").textContent=s.addedWords;
  $("statRemoved").textContent=s.removedWords;
  $("statStatus").textContent=state.operation==="SUMMARIZE"?"Summarized":"Editorial";
  $("statStatus").style.color="var(--green)";
}

async function copyOutput(){
  if(!state.copyHtml && !state.copyText)return;
  try{
    if(state.format==="POWERPOINT"){
      await navigator.clipboard.writeText(state.copyText||"");
      toast("Slide outline copied.",false);
      return;
    }
    // Confluence handles a normal browser rich-copy particularly well.  Use an
    // off-screen selection first so inline heading colours, table borders and
    // cell backgrounds are transferred the same way as copying rendered web
    // content. ClipboardItem remains the modern fallback.
    if(state.format==="CONFLUENCE" && state.copyHtml && copyRichHtmlBySelection(state.copyHtml)){
      toast("Rich Confluence content copied with colours, icons and table formatting.",false);
      return;
    }
    if(state.copyHtml && navigator.clipboard && window.ClipboardItem){
      await navigator.clipboard.write([
        new ClipboardItem({
          "text/html":new Blob([state.copyHtml],{type:"text/html"}),
          "text/plain":new Blob([state.copyText],{type:"text/plain"})
        })
      ]);
      const msg=state.format==="CONFLUENCE"
        ? "Confluence-ready content copied. Paste directly into the Confluence editor."
        : state.format==="EMAIL"
          ? "Outlook-friendly email body copied."
          : "Formatted HTML content copied.";
      toast(msg,false);
    }else{
      await navigator.clipboard.writeText(state.copyText);
      toast("Rich clipboard is unavailable; structured plain text was copied.",true);
    }
  }catch{
    await navigator.clipboard.writeText(state.copyText);
    toast("Rich clipboard was unavailable; structured plain text was copied.",true);
  }
}

function copyRichHtmlBySelection(html){
  if(!html || !document.queryCommandSupported || !document.queryCommandSupported("copy"))return false;
  const host=document.createElement("div");
  host.setAttribute("contenteditable","true");
  host.setAttribute("aria-hidden","true");
  host.style.position="fixed";
  host.style.left="-10000px";
  host.style.top="0";
  host.style.width="900px";
  host.style.background="#fff";
  host.innerHTML=html;
  document.body.appendChild(host);
  const selection=window.getSelection();
  const range=document.createRange();
  range.selectNodeContents(host);
  selection.removeAllRanges();
  selection.addRange(range);
  let copied=false;
  try{copied=document.execCommand("copy")}catch{copied=false}
  selection.removeAllRanges();
  host.remove();
  return copied;
}

async function downloadOutput(){
  if(!state.copyHtml && !state.copyText)return;
  if(state.format==="POWERPOINT"){
    await downloadPowerPoint();
    return;
  }
  const subject=$("emailSubject").value.trim();
  const title=state.format==="EMAIL"?(subject||"Email"):state.format==="CONFLUENCE"?"Confluence Content":"HTML Content";
  const body=state.copyHtml||`<pre>${escapeHtml(state.copyText)}</pre>`;
  const html=`<!doctype html><html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>${escapeHtml(title)}</title></head><body>${body}</body></html>`;
  const blob=new Blob([html],{type:"text/html;charset=utf-8"});
  const url=URL.createObjectURL(blob);
  const a=document.createElement("a");
  a.href=url;
  a.download=state.format==="CONFLUENCE"?"formatflow-confluence.html":state.format==="EMAIL"?"formatflow-email.html":"formatflow-output.html";
  document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);
  toast(`${displayFormat(state.format)} HTML downloaded.`,false);
}

async function downloadPowerPoint(){
  if(!state.document){toast("Generate the preview before downloading PowerPoint.",true);return}
  setBusy("downloadBtn",true,"Generating PPTX...");
  try{
    const r=await fetch("/api/export",{
      method:"POST",
      headers:{"Content-Type":"application/json"},
      body:JSON.stringify({
        document:state.document,
        format:"POWERPOINT",
        filename:"formatflow-presentation",
        htmlContent:state.copyHtml||state.previewHtml||""
      })
    });
    if(!r.ok){
      const d=await r.json().catch(()=>({}));
      throw new Error(d.error||`PowerPoint export failed (${r.status}).`);
    }
    const blob=await r.blob();
    const url=URL.createObjectURL(blob);
    const a=document.createElement("a");
    a.href=url;
    a.download="formatflow-presentation.pptx";
    document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);
    toast("PowerPoint deck downloaded.",false);
  }catch(e){toast(e.message||"PowerPoint download failed.",true)}
  finally{setBusy("downloadBtn",false,"Download PowerPoint")}
}

async function jsonOrError(r){const d=await r.json().catch(()=>({}));if(!r.ok){const e=new Error(d.error||`Request failed (${r.status}).`);e.status=r.status;throw e}return d}
function handleApiError(e,id){if(e.status===401){showAuth();return}showMessage(id,e.message||"Request failed.",true)}
function showMessage(id,text,error=false){const n=$(id);if(!n){console.warn(`[FormatFlow] Message target #${id} is missing.`);return}n.textContent=text||"";n.classList.toggle("error",!!text&&error);n.classList.toggle("success",!!text&&!error)}
function setBusy(id,busy,label){const b=$(id);if(!b){console.warn(`[FormatFlow] Busy target #${id} is missing.`);return}b.disabled=busy;b.textContent=label}
function toast(text,error=false){const t=$("toast");t.textContent=text;t.classList.toggle("error",error);t.classList.remove("hidden");clearTimeout(window.__toastTimer);window.__toastTimer=setTimeout(()=>t.classList.add("hidden"),4500)}
function wordCount(t){const s=(t||"").trim();return s?s.split(/\s+/).length:0}
function escapeHtml(v){return(v||"").replaceAll("&","&amp;").replaceAll("<","&lt;").replaceAll(">","&gt;").replaceAll('"',"&quot;")}
function displayFormat(f){return({CONFLUENCE:"Confluence",EMAIL:"Email",HTML:"HTML",POWERPOINT:"PowerPoint"})[f]||f}
