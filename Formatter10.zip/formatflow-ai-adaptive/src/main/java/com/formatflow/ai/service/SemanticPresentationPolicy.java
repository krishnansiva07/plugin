package com.formatflow.ai.service;

import com.formatflow.ai.model.FormatModels.SemanticItem;
import com.formatflow.ai.model.FormatModels.SemanticRow;
import com.formatflow.ai.model.FormatModels.SemanticSection;
import com.formatflow.ai.model.FormatModels.SemanticValue;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * Converts LLM semantic intent into a representation that is appropriate for the
 * selected output. The LLM decides meaning; this class enforces deterministic
 * presentation rules so repeated structured data does not become a wall of cards.
 *
 * This class never creates new factual content. It only rearranges already
 * validated exact source excerpts held in SemanticItem fields.
 */
@Service
public class SemanticPresentationPolicy {

    public List<SemanticSection> normalize(List<SemanticSection> sections, String outputFormat) {
        if (sections == null || sections.isEmpty()) return List.of();
        String format = outputFormat == null ? "" : outputFormat.trim().toUpperCase(Locale.ROOT);

        List<SemanticSection> result = new ArrayList<>();
        for (SemanticSection section : sections) {
            result.add(normalizeSection(section, format));
        }
        return result;
    }

    private SemanticSection normalizeSection(SemanticSection section, String format) {
        String layout = upper(section.layoutType());

        // Repeated labelled facts are data, not cards. This fixes the previous
        // "everything becomes boxes" behaviour.
        if (Set.of("STATUS", "KPI", "CALLOUT").contains(layout)
                && structuredItemRatio(section.items()) >= 0.66
                && safe(section.items()).size() >= 3) {
            return itemSectionToTable(section);
        }

        // Confluence and Markdown are document-oriented targets. Native tables
        // survive copy/import much better than dashboard-card layouts.
        if (Set.of("CONFLUENCE", "MARKDOWN").contains(format)
                && Set.of("STATUS", "KPI").contains(layout)
                && safe(section.items()).size() >= 2) {
            return itemSectionToTable(section);
        }

        return section;
    }

    private SemanticSection itemSectionToTable(SemanticSection section) {
        List<SemanticItem> items = safe(section.items());

        boolean hasLabel = items.stream().anyMatch(i -> present(i.label()));
        boolean hasValue = items.stream().anyMatch(i -> present(i.value()));
        boolean hasStatus = items.stream().anyMatch(i -> present(i.status()));

        List<String> columns = new ArrayList<>();
        if (hasLabel) columns.add("Item");
        if (hasValue) columns.add("Details");
        if (hasStatus) columns.add("Status");

        if (columns.size() < 2) return section;

        List<SemanticRow> rows = new ArrayList<>();
        for (SemanticItem item : items) {
            List<SemanticValue> cells = new ArrayList<>();
            LinkedHashSet<String> seen = new LinkedHashSet<>();
            if (hasLabel) addCell(cells, seen, item.sourceId(), item.label(), "KEY");
            if (hasValue) addCell(cells, seen, item.sourceId(), item.value(), "VALUE");
            if (hasStatus) addCell(cells, seen, item.sourceId(), item.status(), "STATUS");

            // Semantic tables need at least two factual cells in a row.
            if (cells.size() >= 2) rows.add(new SemanticRow(cells));
        }

        if (rows.size() < 2) return section;

        return new SemanticSection(
                section.id(),
                "TABLE",
                section.titleSourceId(),
                section.title(),
                section.iconKey(),
                section.sourceIds(),
                columns,
                rows,
                List.of(),
                List.of(),
                List.of()
        );
    }

    private void addCell(List<SemanticValue> cells,
                         LinkedHashSet<String> seen,
                         String sourceId,
                         String value,
                         String role) {
        if (!present(value) || !seen.add(value)) return;
        cells.add(new SemanticValue(sourceId, value, role, "NONE"));
    }

    private double structuredItemRatio(List<SemanticItem> items) {
        List<SemanticItem> safe = safe(items);
        if (safe.isEmpty()) return 0;
        long structured = safe.stream().filter(i -> count(i.label(), i.value(), i.status()) >= 2).count();
        return structured / (double) safe.size();
    }

    private int count(String... values) {
        int count = 0;
        for (String value : values) if (present(value)) count++;
        return count;
    }

    private boolean present(String value) {
        return value != null && !value.isBlank();
    }

    private String upper(String value) {
        return value == null ? "" : value.trim().toUpperCase(Locale.ROOT);
    }

    private <T> List<T> safe(List<T> value) {
        return value == null ? List.of() : value;
    }
}
