package com.formatflow.ai.service;

import org.springframework.stereotype.Component;

import java.util.Locale;
import java.util.Map;
import java.util.Set;

@Component
public class IconCatalog {

    private static final Map<String, String> SYMBOLS = Map.ofEntries(
            Map.entry("NETWORK", "🌐"),
            Map.entry("SECURITY", "🔐"),
            Map.entry("API", "🔌"),
            Map.entry("DATABASE", "🗄"),
            Map.entry("CODE", "💻"),
            Map.entry("CONFIG", "⚙"),
            Map.entry("TEST", "🧪"),
            Map.entry("SUCCESS", "✅"),
            Map.entry("WARNING", "⚠"),
            Map.entry("PEOPLE", "👥"),
            Map.entry("BUSINESS", "📊"),
            Map.entry("DOCUMENT", "📄"),
            Map.entry("EMAIL", "✉"),
            Map.entry("INFO", "ℹ"),
            Map.entry("ACTION", "👉"),
            Map.entry("TIME", "⏱"),
            Map.entry("RELEASE", "🚀"),
            Map.entry("PROCESS", "🔄"),
            Map.entry("ARCHITECTURE", "◇"),
            Map.entry("DATA", "▦"),
            Map.entry("RISK", "⚠"),
            Map.entry("NONE", "")
    );

    private static final Map<String, String> PDF_SYMBOLS = Map.ofEntries(
            Map.entry("NETWORK", "◎"),
            Map.entry("SECURITY", "◆"),
            Map.entry("API", "↔"),
            Map.entry("DATABASE", "▣"),
            Map.entry("CODE", "< >"),
            Map.entry("CONFIG", "⚙"),
            Map.entry("TEST", "✓"),
            Map.entry("SUCCESS", "✓"),
            Map.entry("WARNING", "⚠"),
            Map.entry("PEOPLE", "◉"),
            Map.entry("BUSINESS", "▥"),
            Map.entry("DOCUMENT", "▤"),
            Map.entry("EMAIL", "✉"),
            Map.entry("INFO", "i"),
            Map.entry("ACTION", "→"),
            Map.entry("TIME", "◷"),
            Map.entry("RELEASE", "▲"),
            Map.entry("PROCESS", "↻"),
            Map.entry("ARCHITECTURE", "◇"),
            Map.entry("DATA", "▦"),
            Map.entry("RISK", "⚠"),
            Map.entry("NONE", "")
    );

    public Set<String> keys() {
        return SYMBOLS.keySet();
    }

    public String symbol(String key) {
        return SYMBOLS.getOrDefault(normalize(key), "");
    }

    public String pdfSymbol(String key) {
        return PDF_SYMBOLS.getOrDefault(normalize(key), "");
    }

    public String inferKey(String text) {
        if (text == null || text.isBlank()) return "NONE";
        String t = text.toLowerCase(Locale.ROOT);
        if (containsAny(t, "network", "connectivity", "dns", "proxy", "firewall", "port", "host")) return "NETWORK";
        if (containsAny(t, "security", "authentication", "authorization", "auth", "token", "certificate", "jwt", "secret")) return "SECURITY";
        if (containsAny(t, "api", "endpoint", "rest", "http", "service url")) return "API";
        if (containsAny(t, "database", "db", "sql", "repository", "storage")) return "DATABASE";
        if (containsAny(t, "configuration", "config", "properties", "settings", "setup")) return "CONFIG";
        if (containsAny(t, "test", "testing", "qa", "validation", "verify")) return "TEST";
        if (containsAny(t, "risk", "warning", "blocker", "issue", "error", "failure")) return "WARNING";
        if (containsAny(t, "release", "deploy", "deployment", "production", "go-live")) return "RELEASE";
        if (containsAny(t, "data", "record", "file", "payload")) return "DATA";
        if (containsAny(t, "process", "workflow", "flow", "lifecycle")) return "PROCESS";
        if (containsAny(t, "email", "mail", "message")) return "EMAIL";
        if (containsAny(t, "architecture", "design", "component")) return "ARCHITECTURE";
        if (containsAny(t, "action", "next step", "todo")) return "ACTION";
        return "DOCUMENT";
    }

    private boolean containsAny(String text, String... values) {
        for (String value : values) if (text.contains(value)) return true;
        return false;
    }

    public String normalize(String key) {
        if (key == null || key.isBlank()) return "NONE";
        String normalized = key.trim().toUpperCase(Locale.ROOT);
        return SYMBOLS.containsKey(normalized) ? normalized : "NONE";
    }
}
