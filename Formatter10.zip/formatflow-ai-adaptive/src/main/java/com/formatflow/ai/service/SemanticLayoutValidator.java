package com.formatflow.ai.service;

import com.formatflow.ai.model.FormatModels.*;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

@Service
public class SemanticLayoutValidator {

    private static final Set<String> COLUMN_LABELS = Set.of(
            "PROPERTY", "VALUE", "ITEM", "DETAILS", "COMPONENT", "DESCRIPTION",
            "STATUS", "STEP", "ACTION", "OWNER", "DATE", "METRIC", "RESULT",
            "OPTION", "OPTION A", "OPTION B", "CATEGORY", "TYPE", "SOURCE", "TARGET"
    );

    private final IconCatalog iconCatalog;

    public SemanticLayoutValidator(IconCatalog iconCatalog) {
        this.iconCatalog = iconCatalog;
    }

    public ValidationOutcome validateChunk(List<SourceBlock> sourceBlocks,
                                           List<SemanticSection> candidates,
                                           int sectionStart) {
        Map<String, SourceBlock> source = sourceBlocks.stream()
                .filter(b -> !b.blank())
                .collect(Collectors.toMap(SourceBlock::id, Function.identity(), (a, b) -> a, LinkedHashMap::new));

        Set<String> assigned = new LinkedHashSet<>();
        List<SemanticSection> accepted = new ArrayList<>();
        boolean fallback = false;
        int sequence = sectionStart;

        for (SemanticSection candidate : candidates == null ? List.<SemanticSection>of() : candidates) {
            List<String> ids = safeList(candidate.sourceIds()).stream()
                    .filter(source::containsKey)
                    .filter(id -> !assigned.contains(id))
                    .distinct()
                    .toList();
            if (ids.isEmpty()) continue;

            String layout = normalizeLayout(candidate.layoutType());
            String titleSourceId = safe(candidate.titleSourceId());
            String title = exactExcerpt(source, titleSourceId, candidate.title());
            String iconKey = iconCatalog.normalize(candidate.iconKey());
            List<String> columns = normalizeColumns(candidate.columns());
            List<SemanticRow> rows = validateRows(source, ids, candidate.rows());
            List<SemanticNode> nodes = validateNodes(source, ids, candidate.nodes());
            List<SemanticEdge> edges = validateEdges(source, ids, nodes, candidate.edges());
            List<SemanticItem> items = validateItems(source, ids, candidate.items());

            if (!structureIsUsable(layout, rows, nodes, edges, items)) {
                layout = "TEXT";
                rows = List.of(); nodes = List.of(); edges = List.of(); items = List.of(); columns = List.of();
                fallback = true;
            }

            List<String> representedIds = ids;
            if (!"TEXT".equals(layout) && !"CODE_GROUP".equals(layout)) {
                Set<String> represented = representedSourceIds(titleSourceId, title, rows, nodes, edges, items);
                representedIds = ids.stream().filter(represented::contains).toList();
                if (representedIds.isEmpty()) {
                    layout = "TEXT";
                    representedIds = ids;
                    rows = List.of(); nodes = List.of(); edges = List.of(); items = List.of(); columns = List.of();
                    fallback = true;
                } else if (representedIds.size() != ids.size()) {
                    fallback = true;
                }
            }

            accepted.add(new SemanticSection(
                    sectionId(sequence++), layout,
                    title.isBlank() ? "" : titleSourceId,
                    title,
                    iconKey,
                    representedIds,
                    columns,
                    rows,
                    nodes,
                    edges,
                    items
            ));
            assigned.addAll(representedIds);
        }

        // Fail safely: any omitted block is still rendered as immutable text.
        List<String> missing = source.keySet().stream().filter(id -> !assigned.contains(id)).toList();
        if (!missing.isEmpty()) {
            accepted.add(new SemanticSection(
                    sectionId(sequence), "TEXT", "", "", "DOCUMENT",
                    missing, List.of(), List.of(), List.of(), List.of(), List.of()
            ));
            fallback = true;
        }

        return new ValidationOutcome(accepted, fallback);
    }

    private List<SemanticRow> validateRows(Map<String, SourceBlock> source,
                                           List<String> sectionIds,
                                           List<SemanticRow> rows) {
        Set<String> allowed = new HashSet<>(sectionIds);
        List<SemanticRow> result = new ArrayList<>();
        for (SemanticRow row : safeList(rows)) {
            List<SemanticValue> cells = new ArrayList<>();
            for (SemanticValue cell : safeList(row.cells())) {
                if (!allowed.contains(cell.sourceId())) continue;
                String text = exactExcerpt(source, cell.sourceId(), cell.text());
                if (text.isBlank()) continue;
                cells.add(new SemanticValue(cell.sourceId(), text, safe(cell.role()), iconCatalog.normalize(cell.iconKey())));
            }
            if (!cells.isEmpty()) result.add(new SemanticRow(cells));
        }
        return result;
    }

    private List<SemanticNode> validateNodes(Map<String, SourceBlock> source,
                                             List<String> sectionIds,
                                             List<SemanticNode> nodes) {
        Set<String> allowed = new HashSet<>(sectionIds);
        List<SemanticNode> result = new ArrayList<>();
        Set<String> nodeIds = new HashSet<>();
        int generated = 1;
        for (SemanticNode node : safeList(nodes)) {
            if (!allowed.contains(node.sourceId())) continue;
            String text = exactExcerpt(source, node.sourceId(), node.text());
            if (text.isBlank()) continue;
            String id = safe(node.id());
            if (id.isBlank() || !nodeIds.add(id)) {
                do { id = "N" + generated++; } while (!nodeIds.add(id));
            }
            result.add(new SemanticNode(id, node.sourceId(), text, iconCatalog.normalize(node.iconKey())));
        }
        return result;
    }

    private List<SemanticEdge> validateEdges(Map<String, SourceBlock> source,
                                             List<String> sectionIds,
                                             List<SemanticNode> nodes,
                                             List<SemanticEdge> edges) {
        Set<String> allowedSources = new HashSet<>(sectionIds);
        Set<String> allowedNodes = nodes.stream().map(SemanticNode::id).collect(Collectors.toSet());
        List<SemanticEdge> result = new ArrayList<>();
        for (SemanticEdge edge : safeList(edges)) {
            if (!allowedNodes.contains(edge.from()) || !allowedNodes.contains(edge.to())) continue;
            String label = "";
            String sourceId = safe(edge.sourceId());
            if (!safe(edge.label()).isBlank()) {
                if (!allowedSources.contains(sourceId)) continue;
                label = exactExcerpt(source, sourceId, edge.label());
                if (label.isBlank()) continue;
            }
            result.add(new SemanticEdge(edge.from(), edge.to(), sourceId, label));
        }
        return result;
    }

    private List<SemanticItem> validateItems(Map<String, SourceBlock> source,
                                             List<String> sectionIds,
                                             List<SemanticItem> items) {
        Set<String> allowed = new HashSet<>(sectionIds);
        List<SemanticItem> result = new ArrayList<>();
        for (SemanticItem item : safeList(items)) {
            if (!allowed.contains(item.sourceId())) continue;
            String label = exactExcerpt(source, item.sourceId(), item.label());
            String value = exactExcerpt(source, item.sourceId(), item.value());
            String status = exactExcerpt(source, item.sourceId(), item.status());
            if (label.isBlank() && value.isBlank() && status.isBlank()) continue;
            result.add(new SemanticItem(item.sourceId(), label, value, status, iconCatalog.normalize(item.iconKey())));
        }
        return result;
    }


    private Set<String> representedSourceIds(String titleSourceId,
                                             String title,
                                             List<SemanticRow> rows,
                                             List<SemanticNode> nodes,
                                             List<SemanticEdge> edges,
                                             List<SemanticItem> items) {
        Set<String> ids = new LinkedHashSet<>();
        if (!safe(title).isBlank() && !safe(titleSourceId).isBlank()) ids.add(titleSourceId);
        for (SemanticRow row : rows) for (SemanticValue cell : row.cells()) ids.add(cell.sourceId());
        for (SemanticNode node : nodes) ids.add(node.sourceId());
        for (SemanticEdge edge : edges) if (!safe(edge.sourceId()).isBlank()) ids.add(edge.sourceId());
        for (SemanticItem item : items) ids.add(item.sourceId());
        return ids;
    }

    private boolean structureIsUsable(String layout,
                                      List<SemanticRow> rows,
                                      List<SemanticNode> nodes,
                                      List<SemanticEdge> edges,
                                      List<SemanticItem> items) {
        return switch (layout) {
            case "TABLE", "COMPARISON" -> !rows.isEmpty() && rows.stream().allMatch(r -> r.cells().size() >= 2);
            case "WORKFLOW", "ARCHITECTURE", "HIERARCHY" -> nodes.size() >= 2 && !edges.isEmpty();
            case "TIMELINE", "STATUS", "CHECKLIST", "KPI", "CALLOUT" -> !items.isEmpty();
            case "TEXT", "CODE_GROUP" -> true;
            default -> false;
        };
    }

    private String exactExcerpt(Map<String, SourceBlock> source, String sourceId, String requested) {
        if (sourceId == null || requested == null || requested.isBlank()) return "";
        SourceBlock block = source.get(sourceId);
        if (block == null) return "";
        String original = block.text();
        if (original.contains(requested)) return requested;

        // Case-insensitive recovery returns the exact original substring, never model-authored text.
        String lowerOriginal = original.toLowerCase(Locale.ROOT);
        String lowerRequested = requested.toLowerCase(Locale.ROOT);
        int index = lowerOriginal.indexOf(lowerRequested);
        if (index >= 0) return original.substring(index, index + requested.length());
        return "";
    }

    private List<String> normalizeColumns(List<String> columns) {
        List<String> result = new ArrayList<>();
        for (String column : safeList(columns)) {
            String normalized = safe(column).trim().toUpperCase(Locale.ROOT);
            if (COLUMN_LABELS.contains(normalized)) {
                result.add(toTitleCase(normalized));
            }
        }
        return result.size() >= 2 ? result : List.of("Item", "Details");
    }

    private String toTitleCase(String value) {
        if (value.equals("OPTION A") || value.equals("OPTION B")) return value.substring(0, 1) + value.substring(1).toLowerCase(Locale.ROOT);
        return Arrays.stream(value.split(" "))
                .map(x -> x.isEmpty() ? x : x.substring(0, 1) + x.substring(1).toLowerCase(Locale.ROOT))
                .collect(Collectors.joining(" "));
    }

    private String normalizeLayout(String layout) {
        String value = safe(layout).toUpperCase(Locale.ROOT);
        try { return SemanticLayoutType.valueOf(value).name(); }
        catch (Exception ex) { return "TEXT"; }
    }

    private String sectionId(int sequence) {
        return "S%04d".formatted(sequence);
    }

    private String safe(String value) {
        return value == null ? "" : value.trim();
    }

    private <T> List<T> safeList(List<T> value) {
        return value == null ? List.of() : value;
    }

    public record ValidationOutcome(List<SemanticSection> sections, boolean fallbackUsed) {}
}
