package com.formatflow.ai.service;

import com.formatflow.ai.model.FormatModels.*;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.function.ToIntFunction;

/**
 * Reassembles validated semantic sections from independently analysed chunks into
 * one coherent document. It never creates or rewrites factual content.
 */
@Service
public class DocumentAssemblyService {

    public List<SemanticSection> assemble(List<SemanticSection> sections,
                                          List<SourceBlock> sourceBlocks) {
        if (sections == null || sections.isEmpty()) return List.of();

        Map<String, Integer> sourceOrder = new HashMap<>();
        int index = 0;
        for (SourceBlock block : sourceBlocks) {
            sourceOrder.put(block.id(), index++);
        }

        List<SemanticSection> ordered = new ArrayList<>(sections);
        ordered.sort(Comparator.comparingInt(section -> firstSourceIndex(section, sourceOrder)));

        List<SemanticSection> result = new ArrayList<>();
        for (SemanticSection current : ordered) {
            if (!result.isEmpty()) {
                SemanticSection previous = result.get(result.size() - 1);
                if (mergeable(previous, current, sourceOrder)) {
                    result.set(result.size() - 1, merge(previous, current));
                    continue;
                }
            }
            result.add(current);
        }

        // Re-sequence section ids after cross-chunk coalescing.
        List<SemanticSection> resequenced = new ArrayList<>();
        int sequence = 1;
        for (SemanticSection section : result) {
            resequenced.add(new SemanticSection(
                    "S%04d".formatted(sequence++),
                    section.layoutType(),
                    section.titleSourceId(),
                    section.title(),
                    section.iconKey(),
                    section.sourceIds(),
                    section.columns(),
                    section.rows(),
                    section.nodes(),
                    section.edges(),
                    section.items()
            ));
        }
        return resequenced;
    }

    private boolean mergeable(SemanticSection a,
                              SemanticSection b,
                              Map<String, Integer> sourceOrder) {
        String type = upper(a.layoutType());
        if (!type.equals(upper(b.layoutType()))) return false;
        if (!Set.of("TABLE", "COMPARISON", "CHECKLIST", "TIMELINE", "CALLOUT", "STATUS", "KPI", "TEXT", "CODE_GROUP").contains(type)) {
            return false;
        }
        if (!areAdjacent(a, b, sourceOrder)) return false;

        if (Set.of("TABLE", "COMPARISON").contains(type)
                && !Objects.equals(normalizeColumns(a.columns()), normalizeColumns(b.columns()))) {
            return false;
        }

        String aTitle = safe(a.title());
        String bTitle = safe(b.title());
        // Same title, or one side is a continuation without its own title.
        return aTitle.isBlank() || bTitle.isBlank() || aTitle.equalsIgnoreCase(bTitle);
    }

    private boolean areAdjacent(SemanticSection a,
                                SemanticSection b,
                                Map<String, Integer> sourceOrder) {
        int aLast = lastSourceIndex(a, sourceOrder);
        int bFirst = firstSourceIndex(b, sourceOrder);
        return aLast >= 0 && bFirst >= 0 && bFirst - aLast <= 2;
    }

    private SemanticSection merge(SemanticSection a, SemanticSection b) {
        List<String> sourceIds = distinctConcat(a.sourceIds(), b.sourceIds());
        List<SemanticRow> rows = concat(a.rows(), b.rows());
        List<SemanticNode> nodes = concat(a.nodes(), b.nodes());
        List<SemanticEdge> edges = concat(a.edges(), b.edges());
        List<SemanticItem> items = concat(a.items(), b.items());

        String title = !safe(a.title()).isBlank() ? a.title() : b.title();
        String titleSourceId = !safe(a.title()).isBlank() ? a.titleSourceId() : b.titleSourceId();
        String iconKey = !"NONE".equalsIgnoreCase(safe(a.iconKey())) ? a.iconKey() : b.iconKey();

        return new SemanticSection(
                a.id(),
                a.layoutType(),
                titleSourceId,
                title,
                iconKey,
                sourceIds,
                !safeList(a.columns()).isEmpty() ? a.columns() : b.columns(),
                rows,
                nodes,
                edges,
                items
        );
    }

    private int firstSourceIndex(SemanticSection section, Map<String, Integer> order) {
        return safeList(section.sourceIds()).stream()
                .map(order::get)
                .filter(Objects::nonNull)
                .min(Integer::compareTo)
                .orElse(Integer.MAX_VALUE);
    }

    private int lastSourceIndex(SemanticSection section, Map<String, Integer> order) {
        return safeList(section.sourceIds()).stream()
                .map(order::get)
                .filter(Objects::nonNull)
                .max(Integer::compareTo)
                .orElse(-1);
    }

    private List<String> distinctConcat(List<String> a, List<String> b) {
        LinkedHashSet<String> values = new LinkedHashSet<>();
        values.addAll(safeList(a));
        values.addAll(safeList(b));
        return List.copyOf(values);
    }

    private <T> List<T> concat(List<T> a, List<T> b) {
        List<T> values = new ArrayList<>(safeList(a));
        values.addAll(safeList(b));
        return values;
    }

    private List<String> normalizeColumns(List<String> columns) {
        return safeList(columns).stream().map(this::upper).toList();
    }

    private String safe(String value) {
        return value == null ? "" : value.trim();
    }

    private String upper(String value) {
        return safe(value).toUpperCase(Locale.ROOT);
    }

    private <T> List<T> safeList(List<T> value) {
        return value == null ? List.of() : value;
    }
}
