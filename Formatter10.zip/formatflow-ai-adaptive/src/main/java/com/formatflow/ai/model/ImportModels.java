package com.formatflow.ai.model;

public final class ImportModels {

    private ImportModels() {}

    public record ImportResult(
            String source,
            String content,
            int words,
            int characters
    ) {}
}
