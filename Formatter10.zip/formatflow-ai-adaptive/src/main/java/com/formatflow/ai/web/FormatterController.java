package com.formatflow.ai.web;

import com.formatflow.ai.model.FormatModels.ExportRequest;
import com.formatflow.ai.model.FormatModels.FormatRequest;
import com.formatflow.ai.model.FormatModels.FormatResult;
import com.formatflow.ai.service.ExportService;
import com.formatflow.ai.service.FormattingService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.nio.charset.StandardCharsets;

@RestController
@RequestMapping("/api")
public class FormatterController {

    private final FormattingService formattingService;
    private final ExportService exportService;

    public FormatterController(FormattingService formattingService, ExportService exportService) {
        this.formattingService = formattingService;
        this.exportService = exportService;
    }

    @PostMapping("/format/preview")
    public FormatResult preview(@Valid @RequestBody FormatRequest request, HttpServletRequest servletRequest) {
        return formattingService.format(request, servletRequest.getSession(false));
    }

    @PostMapping("/export")
    public ResponseEntity<byte[]> export(@Valid @RequestBody ExportRequest request) {
        ExportService.ExportedFile file = exportService.export(request);
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.parseMediaType(file.contentType()));
        headers.setContentDisposition(ContentDisposition.attachment()
                .filename(file.filename(), StandardCharsets.UTF_8).build());
        headers.setCacheControl("no-store, max-age=0");
        return ResponseEntity.ok().headers(headers).body(file.bytes());
    }
}
