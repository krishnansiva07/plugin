package com.formatflow.ai.service;

import org.springframework.stereotype.Component;

import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamConstants;
import javax.xml.stream.XMLStreamReader;
import java.io.InputStream;
import java.nio.file.Path;
import java.util.Locale;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/**
 * Low-memory DOCX text + semantic-structure extractor.
 *
 * DOCX is a ZIP container. Instead of loading the complete package into
 * XWPFDocument, this extractor streams word/document.xml with StAX. In addition
 * to body text it preserves the most useful Word paragraph semantics (Heading
 * 1-4, title, bullet/number lists and code-block style) as lightweight Markdown-
 * like markers. That gives the downstream LLM a much better topic/slide signal
 * without the memory cost of a full Office object model.
 */
@Component
public class DocxStreamingTextExtractor {

    public String extract(Path path) throws Exception {
        try (ZipFile zip = new ZipFile(path.toFile())) {
            ZipEntry document = zip.getEntry("word/document.xml");
            if (document == null) {
                throw new IllegalArgumentException("DOCX does not contain word/document.xml.");
            }
            try (InputStream input = zip.getInputStream(document)) {
                return parseDocumentXml(input);
            }
        }
    }

    private String parseDocumentXml(InputStream input) throws Exception {
        XMLInputFactory factory = XMLInputFactory.newFactory();
        trySet(factory, XMLInputFactory.SUPPORT_DTD, false);
        trySet(factory, "javax.xml.stream.isSupportingExternalEntities", false);
        trySet(factory, XMLInputFactory.IS_COALESCING, true);

        XMLStreamReader reader = factory.createXMLStreamReader(input);
        StringBuilder out = new StringBuilder();
        StringBuilder paragraph = new StringBuilder();
        StringBuilder cell = new StringBuilder();
        StringBuilder row = new StringBuilder();

        boolean inText = false;
        boolean inCell = false;
        String paragraphStyle = "";

        try {
            while (reader.hasNext()) {
                int event = reader.next();
                if (event == XMLStreamConstants.START_ELEMENT) {
                    String local = reader.getLocalName();
                    switch (local) {
                        case "p" -> paragraphStyle = "";
                        case "t" -> inText = true;
                        case "pStyle" -> paragraphStyle = attributeValue(reader, "val");
                        case "tc" -> {
                            inCell = true;
                            cell.setLength(0);
                        }
                        case "tr" -> row.setLength(0);
                        case "tab" -> paragraph.append('\t');
                        case "br", "cr" -> paragraph.append('\n');
                        default -> { }
                    }
                } else if (event == XMLStreamConstants.CHARACTERS || event == XMLStreamConstants.CDATA) {
                    if (inText) paragraph.append(reader.getText());
                } else if (event == XMLStreamConstants.END_ELEMENT) {
                    String local = reader.getLocalName();
                    switch (local) {
                        case "t" -> inText = false;
                        case "p" -> {
                            String value = paragraph.toString().trim();
                            if (!value.isBlank()) {
                                if (inCell) {
                                    if (!cell.isEmpty()) cell.append(' ');
                                    cell.append(value);
                                } else {
                                    appendBlock(out, decorateParagraph(value, paragraphStyle));
                                }
                            }
                            paragraph.setLength(0);
                            paragraphStyle = "";
                        }
                        case "tc" -> {
                            if (!row.isEmpty()) row.append('\t');
                            row.append(cell.toString().trim());
                            cell.setLength(0);
                            inCell = false;
                        }
                        case "tr" -> {
                            String value = row.toString().trim();
                            if (!value.isBlank()) appendBlock(out, value);
                            row.setLength(0);
                        }
                        default -> { }
                    }
                }
            }
        } finally {
            reader.close();
        }
        return out.toString();
    }

    private String decorateParagraph(String value, String style) {
        String normalized = style == null ? "" : style.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]", "");
        if (normalized.equals("title")) return "# " + value;
        if (normalized.equals("heading1")) return "# " + value;
        if (normalized.equals("heading2")) return "## " + value;
        if (normalized.equals("heading3")) return "### " + value;
        if (normalized.equals("heading4")) return "#### " + value;
        if (normalized.startsWith("listbullet")) return "- " + value;
        if (normalized.startsWith("listnumber")) return "1. " + value;
        if (normalized.contains("codeblock") || normalized.equals("code")) return "    " + value;
        return value;
    }

    private String attributeValue(XMLStreamReader reader, String localName) {
        for (int i = 0; i < reader.getAttributeCount(); i++) {
            if (localName.equals(reader.getAttributeLocalName(i))) {
                String value = reader.getAttributeValue(i);
                return value == null ? "" : value;
            }
        }
        return "";
    }

    private void appendBlock(StringBuilder out, String value) {
        if (value == null || value.isBlank()) return;
        if (!out.isEmpty()) out.append("\n\n");
        out.append(value);
    }

    private void trySet(XMLInputFactory factory, String key, Object value) {
        try {
            factory.setProperty(key, value);
        } catch (IllegalArgumentException ignored) {
            // Some StAX implementations do not expose every optional property.
        }
    }
}
