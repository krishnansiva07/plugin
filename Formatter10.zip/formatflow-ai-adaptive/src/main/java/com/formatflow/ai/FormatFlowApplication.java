package com.formatflow.ai;

import com.formatflow.ai.config.LlmProperties;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;

@SpringBootApplication
@EnableConfigurationProperties(LlmProperties.class)
public class FormatFlowApplication {

    public static void main(String[] args) {
        SpringApplication.run(FormatFlowApplication.class, args);
    }
}
