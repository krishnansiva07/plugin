package com.formatflow.ai.config;

import com.formatflow.ai.web.SessionGuardInterceptor;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.CacheControl;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class WebConfig implements WebMvcConfigurer {

    private final SessionGuardInterceptor sessionGuardInterceptor;

    public WebConfig(SessionGuardInterceptor sessionGuardInterceptor) {
        this.sessionGuardInterceptor = sessionGuardInterceptor;
    }


    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        // The UI evolves independently of the backend. Do not let an older cached
        // app.js run against a newer index.html (or vice versa), because that can
        // leave controls unbound before any API request is sent.
        registry.addResourceHandler("/index.html")
                .addResourceLocations("classpath:/static/")
                .setCacheControl(CacheControl.noStore());
        registry.addResourceHandler("/js/**")
                .addResourceLocations("classpath:/static/js/")
                .setCacheControl(CacheControl.noStore());
        registry.addResourceHandler("/css/**")
                .addResourceLocations("classpath:/static/css/")
                .setCacheControl(CacheControl.noStore());
        registry.addResourceHandler("/favicon.ico")
                .addResourceLocations("classpath:/static/")
                .setCacheControl(CacheControl.noStore());
    }

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(sessionGuardInterceptor)
                .addPathPatterns("/api/**")
                .excludePathPatterns("/api/session/**");
    }
}
