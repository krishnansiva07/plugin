package com.formatflow.ai.web;

import com.formatflow.ai.model.ImportModels.ImportResult;
import com.formatflow.ai.service.DocumentExtractionService;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@RestController
@RequestMapping("/api/import")
public class ImportController {

    private final DocumentExtractionService documentExtractionService;

    public ImportController(DocumentExtractionService documentExtractionService) {
        this.documentExtractionService = documentExtractionService;
    }

    @PostMapping("/file")
    public ImportResult importFile(@RequestParam("file") MultipartFile file) {
        return documentExtractionService.extract(file);
    }
}
