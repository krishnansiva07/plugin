package com.formatflow.ai.service;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.font.PDFont;
import org.apache.pdfbox.pdmodel.font.PDType0Font;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.apache.pdfbox.pdmodel.font.Standard14Fonts;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

@Component
public class PdfFontResolver {

    private static final List<Path> REGULAR = List.of(
            Path.of("C:/Windows/Fonts/arial.ttf"),
            Path.of("C:/Windows/Fonts/segoeui.ttf"),
            Path.of("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"),
            Path.of("/usr/share/fonts/truetype/liberation2/LiberationSans-Regular.ttf"),
            Path.of("/System/Library/Fonts/Supplemental/Arial.ttf")
    );

    private static final List<Path> BOLD = List.of(
            Path.of("C:/Windows/Fonts/arialbd.ttf"),
            Path.of("C:/Windows/Fonts/segoeuib.ttf"),
            Path.of("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"),
            Path.of("/usr/share/fonts/truetype/liberation2/LiberationSans-Bold.ttf"),
            Path.of("/System/Library/Fonts/Supplemental/Arial Bold.ttf")
    );

    public FontPair resolve(PDDocument document) throws IOException {
        PDFont regular = loadFirst(document, REGULAR);
        PDFont bold = loadFirst(document, BOLD);
        if (regular == null) regular = new PDType1Font(Standard14Fonts.FontName.HELVETICA);
        if (bold == null) bold = new PDType1Font(Standard14Fonts.FontName.HELVETICA_BOLD);
        return new FontPair(regular, bold);
    }

    private PDFont loadFirst(PDDocument document, List<Path> candidates) throws IOException {
        for (Path path : candidates) {
            if (Files.isRegularFile(path)) {
                return PDType0Font.load(document, path.toFile());
            }
        }
        return null;
    }

    public record FontPair(PDFont regular, PDFont bold) {}
}
