package com.formatflow.ai.service;

import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Service;

@Service
public class SessionKeyService {

    private static final String SESSION_KEY = "FORMATFLOW_LLM_API_KEY";

    public void store(HttpSession session, String apiKey) {
        session.setAttribute(SESSION_KEY, apiKey);
    }

    public String require(HttpSession session) {
        if (session == null) {
            throw new IllegalStateException("LLM session is not connected.");
        }
        Object value = session.getAttribute(SESSION_KEY);
        if (!(value instanceof String key) || key.isBlank()) {
            throw new IllegalStateException("LLM session is not connected.");
        }
        return key;
    }

    public boolean isConnected(HttpSession session) {
        if (session == null) {
            return false;
        }
        Object value = session.getAttribute(SESSION_KEY);
        return value instanceof String key && !key.isBlank();
    }

    public void clear(HttpSession session) {
        if (session != null) {
            session.removeAttribute(SESSION_KEY);
        }
    }
}
