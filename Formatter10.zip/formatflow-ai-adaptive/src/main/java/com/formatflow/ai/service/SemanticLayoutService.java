package com.formatflow.ai.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.formatflow.ai.model.FormatModels.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class SemanticLayoutService {

    private final LlmClient llmClient;
    private final PromptFactory promptFactory;
    private final ContentParser contentParser;
    private final SemanticLayoutValidator validator;
    private final ObjectMapper objectMapper;
    private final int chunkCharacters;
    private final int chunkBlocks;

    public SemanticLayoutService(LlmClient llmClient,
                                 PromptFactory promptFactory,
                                 ContentParser contentParser,
                                 SemanticLayoutValidator validator,
                                 ObjectMapper objectMapper,
                                 @Value("${formatflow.llm.chunk-characters:9000}") int chunkCharacters,
                                 @Value("${formatflow.llm.chunk-blocks:40}") int chunkBlocks) {
        this.llmClient = llmClient;
        this.promptFactory = promptFactory;
        this.contentParser = contentParser;
        this.validator = validator;
        this.objectMapper = objectMapper;
        this.chunkCharacters = chunkCharacters;
        this.chunkBlocks = chunkBlocks;
    }

    public SemanticOutcome analyze(String apiKey,
                                   List<SourceBlock> blocks,
                                   String audience,
                                   String purpose,
                                   String outputFormat,
                                   String iconLevel) {
        List<List<SourceBlock>> chunks = contentParser.chunks(blocks, chunkCharacters, chunkBlocks);
        List<SemanticSection> all = new ArrayList<>();
        boolean fallback = false;
        int calls = 0;
        int sectionSequence = 1;

        for (int i = 0; i < chunks.size(); i++) {
            List<SourceBlock> chunk = chunks.get(i);
            try {
                String prompt = promptFactory.semanticLayout(chunk, audience, purpose, outputFormat, iconLevel, i + 1, chunks.size());
                String response = llmClient.chat(apiKey, prompt, 5000, 0.0);
                calls++;
                List<SemanticSection> parsed;
                try {
                    parsed = parseSections(response);
                } catch (RuntimeException invalidStructuredOutput) {
                    // One structured-output repair attempt. The same immutable source is supplied again;
                    // the model is told to fix only its JSON contract, not the source content.
                    String repaired = llmClient.chat(
                            apiKey,
                            prompt + "\n\nREPAIR REQUEST: Your previous response was not valid against the requested JSON contract. Return ONLY corrected strict JSON. Do not change, add or infer source facts.",
                            5000,
                            0.0
                    );
                    calls++;
                    parsed = parseSections(repaired);
                }
                SemanticLayoutValidator.ValidationOutcome validated = validator.validateChunk(chunk, parsed, sectionSequence);
                all.addAll(validated.sections());
                fallback |= validated.fallbackUsed();
                sectionSequence += validated.sections().size();
            } catch (RuntimeException ex) {
                // Production-safe degradation: preserve every source block as TEXT rather than losing content.
                SemanticLayoutValidator.ValidationOutcome safe = validator.validateChunk(chunk, List.of(), sectionSequence);
                all.addAll(safe.sections());
                fallback = true;
                sectionSequence += safe.sections().size();
            }
        }

        List<SemanticSection> coalesced = coalesce(all);
        List<String> detected = coalesced.stream()
                .map(SemanticSection::layoutType)
                .filter(x -> !"TEXT".equalsIgnoreCase(x))
                .distinct()
                .toList();

        return new SemanticOutcome(coalesced, calls, chunks.size(), fallback, detected);
    }


    private List<SemanticSection> coalesce(List<SemanticSection> sections) {
        if (sections.size() < 2) return sections;
        List<SemanticSection> result = new ArrayList<>();
        for (SemanticSection current : sections) {
            if (!result.isEmpty()) {
                SemanticSection previous = result.get(result.size() - 1);
                if (mergeable(previous, current)) {
                    result.set(result.size() - 1, merge(previous, current));
                    continue;
                }
            }
            result.add(current);
        }
        return result;
    }

    private boolean mergeable(SemanticSection a, SemanticSection b) {
        String type = a.layoutType() == null ? "" : a.layoutType().toUpperCase(Locale.ROOT);
        if (!type.equals(b.layoutType() == null ? "" : b.layoutType().toUpperCase(Locale.ROOT))) return false;
        if (!Set.of("TABLE", "COMPARISON", "STATUS", "CHECKLIST", "KPI", "TIMELINE", "CALLOUT").contains(type)) return false;
        String at = a.title() == null ? "" : a.title();
        String bt = b.title() == null ? "" : b.title();
        if (!at.isBlank() && !bt.isBlank() && !at.equals(bt)) return false;
        if ((type.equals("TABLE") || type.equals("COMPARISON")) && !Objects.equals(a.columns(), b.columns())) return false;
        return true;
    }

    private SemanticSection merge(SemanticSection a, SemanticSection b) {
        List<String> sourceIds = new ArrayList<>(a.sourceIds()); sourceIds.addAll(b.sourceIds());
        List<SemanticRow> rows = new ArrayList<>(a.rows()); rows.addAll(b.rows());
        List<SemanticItem> items = new ArrayList<>(a.items()); items.addAll(b.items());
        return new SemanticSection(
                a.id(), a.layoutType(),
                a.title() == null || a.title().isBlank() ? b.titleSourceId() : a.titleSourceId(),
                a.title() == null || a.title().isBlank() ? b.title() : a.title(),
                "NONE".equalsIgnoreCase(a.iconKey()) ? b.iconKey() : a.iconKey(),
                sourceIds, a.columns(), rows, a.nodes(), a.edges(), items
        );
    }

    private List<SemanticSection> parseSections(String raw) {
        JsonNode root = readJson(raw);
        JsonNode sections = root.path("sections");
        if (!sections.isArray()) {
            throw new IllegalStateException("LLM semantic response did not contain a sections array.");
        }

        List<SemanticSection> result = new ArrayList<>();
        int sequence = 1;
        for (JsonNode section : sections) {
            List<String> sourceIds = stringList(section.path("sourceIds"));
            List<String> columns = stringList(section.path("columns"));
            List<SemanticRow> rows = parseRows(section.path("rows"));
            List<SemanticNode> nodes = parseNodes(section.path("nodes"));
            List<SemanticEdge> edges = parseEdges(section.path("edges"));
            List<SemanticItem> items = parseItems(section.path("items"));

            JsonNode titleNode = section.path("title");
            String titleSourceId = titleNode.isObject() ? titleNode.path("sourceId").asText("") : "";
            String title = titleNode.isObject() ? titleNode.path("text").asText("") : "";

            result.add(new SemanticSection(
                    section.path("id").asText("R" + sequence++),
                    section.path("layout").asText("TEXT"),
                    titleSourceId,
                    title,
                    section.path("iconKey").asText("NONE"),
                    sourceIds,
                    columns,
                    rows,
                    nodes,
                    edges,
                    items
            ));
        }
        return result;
    }

    private List<SemanticRow> parseRows(JsonNode node) {
        if (!node.isArray()) return List.of();
        List<SemanticRow> result = new ArrayList<>();
        for (JsonNode row : node) {
            List<SemanticValue> cells = new ArrayList<>();
            JsonNode cellArray = row.path("cells");
            if (cellArray.isArray()) {
                for (JsonNode cell : cellArray) {
                    cells.add(new SemanticValue(
                            cell.path("sourceId").asText(""),
                            cell.path("text").asText(""),
                            cell.path("role").asText(""),
                            cell.path("iconKey").asText("NONE")
                    ));
                }
            }
            result.add(new SemanticRow(cells));
        }
        return result;
    }

    private List<SemanticNode> parseNodes(JsonNode node) {
        if (!node.isArray()) return List.of();
        List<SemanticNode> result = new ArrayList<>();
        for (JsonNode item : node) {
            result.add(new SemanticNode(
                    item.path("id").asText(""),
                    item.path("sourceId").asText(""),
                    item.path("text").asText(""),
                    item.path("iconKey").asText("NONE")
            ));
        }
        return result;
    }

    private List<SemanticEdge> parseEdges(JsonNode node) {
        if (!node.isArray()) return List.of();
        List<SemanticEdge> result = new ArrayList<>();
        for (JsonNode item : node) {
            result.add(new SemanticEdge(
                    item.path("from").asText(""),
                    item.path("to").asText(""),
                    item.path("sourceId").asText(""),
                    item.path("label").asText("")
            ));
        }
        return result;
    }

    private List<SemanticItem> parseItems(JsonNode node) {
        if (!node.isArray()) return List.of();
        List<SemanticItem> result = new ArrayList<>();
        for (JsonNode item : node) {
            result.add(new SemanticItem(
                    item.path("sourceId").asText(""),
                    item.path("label").asText(""),
                    item.path("value").asText(""),
                    item.path("status").asText(""),
                    item.path("iconKey").asText("NONE")
            ));
        }
        return result;
    }

    private List<String> stringList(JsonNode node) {
        if (!node.isArray()) return List.of();
        List<String> result = new ArrayList<>();
        for (JsonNode value : node) result.add(value.asText(""));
        return result;
    }

    private JsonNode readJson(String raw) {
        try {
            String cleaned = raw == null ? "" : raw.trim();
            if (cleaned.startsWith("```")) {
                cleaned = cleaned.replaceFirst("^```(?:json)?\\s*", "").replaceFirst("\\s*```$", "");
            }
            int first = cleaned.indexOf('{');
            int last = cleaned.lastIndexOf('}');
            if (first >= 0 && last > first) cleaned = cleaned.substring(first, last + 1);
            return objectMapper.readTree(cleaned);
        } catch (Exception ex) {
            throw new IllegalStateException("LLM returned invalid semantic-layout JSON.", ex);
        }
    }

    public record SemanticOutcome(
            List<SemanticSection> sections,
            int llmCalls,
            int chunks,
            boolean fallbackUsed,
            List<String> detectedLayouts
    ) {}
}
