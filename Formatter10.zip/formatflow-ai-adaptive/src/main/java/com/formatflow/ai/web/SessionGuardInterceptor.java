package com.formatflow.ai.web;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.formatflow.ai.service.SessionKeyService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

import java.util.Map;

@Component
public class SessionGuardInterceptor implements HandlerInterceptor {

    private final SessionKeyService sessionKeyService;
    private final ObjectMapper objectMapper;

    public SessionGuardInterceptor(SessionKeyService sessionKeyService, ObjectMapper objectMapper) {
        this.sessionKeyService = sessionKeyService;
        this.objectMapper = objectMapper;
    }

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        if (sessionKeyService.isConnected(request.getSession(false))) {
            return true;
        }

        response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
        response.setContentType(MediaType.APPLICATION_JSON_VALUE);
        objectMapper.writeValue(response.getWriter(), Map.of(
                "error", "LLM access is required.",
                "code", "LLM_SESSION_REQUIRED"
        ));
        return false;
    }
}
