package com.formatflow.ai.service;

import com.formatflow.ai.model.FormatModels.ContentStats;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

@Service
public class ContentDiffService {

    public ContentStats compare(String original, String formatted) {
        String left = original == null ? "" : original;
        String right = formatted == null ? "" : formatted;

        String[] leftWords = words(left);
        String[] rightWords = words(right);

        Map<String, Integer> leftCounts = counts(leftWords);
        Map<String, Integer> rightCounts = counts(rightWords);

        int added = 0;
        int removed = 0;

        for (Map.Entry<String, Integer> e : rightCounts.entrySet()) {
            int oldCount = leftCounts.getOrDefault(e.getKey(), 0);
            if (e.getValue() > oldCount) {
                added += e.getValue() - oldCount;
            }
        }

        for (Map.Entry<String, Integer> e : leftCounts.entrySet()) {
            int newCount = rightCounts.getOrDefault(e.getKey(), 0);
            if (e.getValue() > newCount) {
                removed += e.getValue() - newCount;
            }
        }

        return new ContentStats(
                leftWords.length,
                rightWords.length,
                added,
                removed,
                left.equals(right),
                left.length(),
                right.length()
        );
    }

    public int wordCount(String content) {
        return words(content == null ? "" : content).length;
    }

    private static String[] words(String value) {
        String trimmed = value.trim();
        return trimmed.isEmpty() ? new String[0] : trimmed.split("\\s+");
    }

    private static Map<String, Integer> counts(String[] words) {
        Map<String, Integer> result = new HashMap<>();
        for (String word : words) {
            String normalized = word.toLowerCase(Locale.ROOT);
            result.merge(normalized, 1, Integer::sum);
        }
        return result;
    }
}
