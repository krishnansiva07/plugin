package com.formatflow.ai.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.formatflow.ai.model.FormatModels.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

/**
 * One bounded LLM analysis call per source chunk.
 *
 * The same call returns BOTH:
 *  - line-level formatting metadata (formatItems), and
 *  - optional semantic layout sections (tables/workflows/checklists/etc.).
 *
 * This replaces the previous two-pass LLM design for normal formatting and keeps
 * large-document prompts small. A short digest from the previous chunk is passed
 * as continuity context; source text from previous chunks is never resent.
 */
@Service
public class AdaptiveSemanticOrchestrator {

    private static final Set<String> PLAN_TYPES = Set.of(
            "TITLE", "HEADING", "PARAGRAPH", "BULLET", "CODE", "CALLOUT", "QUOTE"
    );
    private static final Set<String> EMPHASIS = Set.of("NONE", "STRONG", "MUTED", "HIGHLIGHT");
    private static final Set<String> BULLETS = Set.of("NONE", "CHECK", "ARROW", "DOT");

    private final LlmClient llmClient;
    private final PromptFactory promptFactory;
    private final ContentParser contentParser;
    private final SemanticLayoutValidator semanticValidator;
    private final ObjectMapper objectMapper;
    private final IconCatalog iconCatalog;
    private final int chunkCharacters;
    private final int chunkBlocks;
    private final int continuityCharacters;

    public AdaptiveSemanticOrchestrator(LlmClient llmClient,
                                        PromptFactory promptFactory,
                                        ContentParser contentParser,
                                        SemanticLayoutValidator semanticValidator,
                                        ObjectMapper objectMapper,
                                        IconCatalog iconCatalog,
                                        @Value("${formatflow.llm.adaptive-chunk-characters:5500}") int chunkCharacters,
                                        @Value("${formatflow.llm.adaptive-chunk-blocks:26}") int chunkBlocks,
                                        @Value("${formatflow.llm.continuity-characters:700}") int continuityCharacters) {
        this.llmClient = llmClient;
        this.promptFactory = promptFactory;
        this.contentParser = contentParser;
        this.semanticValidator = semanticValidator;
        this.objectMapper = objectMapper;
        this.iconCatalog = iconCatalog;
        this.chunkCharacters = Math.max(1800, chunkCharacters);
        this.chunkBlocks = Math.max(8, chunkBlocks);
        this.continuityCharacters = Math.max(0, continuityCharacters);
    }

    public AnalysisOutcome analyze(String apiKey,
                                   List<SourceBlock> blocks,
                                   String audience,
                                   String purpose,
                                   String outputFormat,
                                   String iconLevel,
                                   boolean smartLayout) {
        List<List<SourceBlock>> chunks = contentParser.adaptiveChunks(blocks, chunkCharacters, chunkBlocks);
        Map<String, PlanItem> planById = new LinkedHashMap<>();
        List<SemanticSection> semanticSections = new ArrayList<>();
        int calls = 0;
        int sectionSequence = 1;
        boolean fallback = false;
        String previousDigest = "";

        for (int i = 0; i < chunks.size(); i++) {
            List<SourceBlock> chunk = chunks.get(i);
            try {
                String prompt = promptFactory.adaptiveChunkAnalysis(
                        chunk,
                        audience,
                        purpose,
                        outputFormat,
                        iconLevel,
                        smartLayout,
                        i + 1,
                        chunks.size(),
                        previousDigest
                );

                String response = llmClient.chat(apiKey, prompt, smartLayout ? 5200 : 3000, 0.0);
                calls++;
                JsonNode root;
                try {
                    root = readJson(response);
                } catch (RuntimeException invalidJson) {
                    String repaired = llmClient.chat(
                            apiKey,
                            prompt + "\n\nREPAIR REQUEST: Return ONLY strict valid JSON matching the requested schema. " +
                                    "Do not return source text outside semantic exact excerpts and do not change source facts.",
                            smartLayout ? 5200 : 3000,
                            0.0
                    );
                    calls++;
                    root = readJson(repaired);
                }

                PlanValidation chunkPlan = parseAndValidatePlan(root, chunk, iconLevel);
                planById.putAll(chunkPlan.items());
                fallback |= chunkPlan.fallbackUsed();

                if (smartLayout) {
                    List<SemanticSection> parsedSections = parseSections(root.path("sections"));
                    SemanticLayoutValidator.ValidationOutcome validated =
                            semanticValidator.validateChunk(chunk, parsedSections, sectionSequence);
                    semanticSections.addAll(validated.sections());
                    sectionSequence += validated.sections().size();
                    fallback |= validated.fallbackUsed();
                }

                previousDigest = clipDigest(root.path("chunkDigest").asText(""));
            } catch (RuntimeException ex) {
                // Fail safely per chunk. The source remains available and is never lost.
                fallback = true;
                for (SourceBlock block : chunk) {
                    if (!block.blank()) planById.put(block.id(), fallbackPlan(block, iconLevel));
                }
                if (smartLayout) {
                    SemanticLayoutValidator.ValidationOutcome safe =
                            semanticValidator.validateChunk(chunk, List.of(), sectionSequence);
                    semanticSections.addAll(safe.sections());
                    sectionSequence += safe.sections().size();
                }
                previousDigest = deterministicDigest(chunk);
            }
        }

        List<PlanItem> orderedPlan = new ArrayList<>();
        for (SourceBlock block : blocks) {
            if (block.blank()) continue;
            PlanItem item = planById.get(block.id());
            if (item == null) {
                item = fallbackPlan(block, iconLevel);
                fallback = true;
            }
            orderedPlan.add(item);
        }

        List<String> detected = semanticSections.stream()
                .map(SemanticSection::layoutType)
                .filter(type -> type != null && !"TEXT".equalsIgnoreCase(type))
                .distinct()
                .toList();

        return new AnalysisOutcome(
                orderedPlan,
                semanticSections,
                calls,
                chunks.size(),
                fallback,
                detected
        );
    }

    private PlanValidation parseAndValidatePlan(JsonNode root,
                                                  List<SourceBlock> chunk,
                                                  String iconLevel) {
        Map<String, SourceBlock> source = chunk.stream()
                .filter(block -> !block.blank())
                .collect(Collectors.toMap(SourceBlock::id, block -> block, (a, b) -> a, LinkedHashMap::new));

        Map<String, PlanItem> result = new LinkedHashMap<>();
        boolean fallbackUsed = false;
        JsonNode items = root.path("formatItems");
        if (items.isArray()) {
            for (JsonNode node : items) {
                String id = node.path("id").asText("");
                SourceBlock block = source.get(id);
                if (block == null || result.containsKey(id)) continue;

                String type = upper(node.path("type").asText("PARAGRAPH"));
                if (!PLAN_TYPES.contains(type)) {
                    type = fallbackPlan(block, iconLevel).type();
                    fallbackUsed = true;
                }
                if (block.codeLike()) type = "CODE";

                String emphasis = upper(node.path("emphasis").asText("NONE"));
                if (!EMPHASIS.contains(emphasis)) {
                    emphasis = "NONE";
                    fallbackUsed = true;
                }

                String bulletStyle = upper(node.path("bulletStyle").asText("NONE"));
                if (!BULLETS.contains(bulletStyle)) {
                    bulletStyle = "NONE";
                    fallbackUsed = true;
                }
                if ((block.bulletLike() || "BULLET".equals(type)) && "NONE".equals(bulletStyle)) {
                    bulletStyle = "CHECK";
                }

                String iconKey = "NONE".equalsIgnoreCase(iconLevel)
                        ? "NONE"
                        : iconCatalog.normalize(node.path("iconKey").asText("NONE"));
                if (!"NONE".equalsIgnoreCase(iconLevel)
                        && "NONE".equals(iconKey)
                        && Set.of("TITLE", "HEADING").contains(type)) {
                    iconKey = iconCatalog.inferKey(block.text());
                }

                result.put(id, new PlanItem(id, type, iconKey, emphasis, bulletStyle));
            }
        }

        // Missing metadata is filled locally instead of making another LLM call.
        for (SourceBlock block : chunk) {
            if (!block.blank() && !result.containsKey(block.id())) {
                result.put(block.id(), fallbackPlan(block, iconLevel));
                fallbackUsed = true;
            }
        }
        return new PlanValidation(result, fallbackUsed);
    }

    private PlanItem fallbackPlan(SourceBlock block, String iconLevel) {
        String type;
        String emphasis = "NONE";
        String bullet = "NONE";
        String text = block.text() == null ? "" : block.text().trim();

        if (block.codeLike()) {
            type = "CODE";
        } else if (block.bulletLike()) {
            type = "BULLET";
            bullet = "CHECK";
        } else if (looksLikeHeading(text)) {
            type = "HEADING";
            emphasis = "STRONG";
        } else {
            type = "PARAGRAPH";
        }

        String icon = "NONE";
        if (!"NONE".equalsIgnoreCase(iconLevel) && Set.of("TITLE", "HEADING").contains(type)) {
            icon = iconCatalog.inferKey(text);
        }
        return new PlanItem(block.id(), type, icon, emphasis, bullet);
    }

    private boolean looksLikeHeading(String value) {
        if (value == null || value.isBlank() || value.length() > 90) return false;
        if (value.endsWith(".") || value.endsWith(";") || value.contains("=")) return false;
        return value.matches("^#{1,6}\\s+.*")
                || value.endsWith(":")
                || value.equals(value.toUpperCase(Locale.ROOT))
                || value.matches("^[A-Z][A-Za-z0-9 /&()_-]{2,70}$");
    }

    private List<SemanticSection> parseSections(JsonNode sections) {
        if (!sections.isArray()) return List.of();
        List<SemanticSection> result = new ArrayList<>();
        int sequence = 1;
        for (JsonNode section : sections) {
            List<String> sourceIds = stringList(section.path("sourceIds"));
            List<String> columns = stringList(section.path("columns"));
            List<SemanticRow> rows = parseRows(section.path("rows"));
            List<SemanticNode> nodes = parseNodes(section.path("nodes"));
            List<SemanticEdge> edges = parseEdges(section.path("edges"));
            List<SemanticItem> semanticItems = parseSemanticItems(section.path("items"));

            JsonNode titleNode = section.path("title");
            String titleSourceId = titleNode.isObject() ? titleNode.path("sourceId").asText("") : "";
            String title = titleNode.isObject() ? titleNode.path("text").asText("") : "";

            result.add(new SemanticSection(
                    section.path("id").asText("R" + sequence++),
                    section.path("layout").asText("TEXT"),
                    titleSourceId,
                    title,
                    section.path("iconKey").asText("NONE"),
                    sourceIds,
                    columns,
                    rows,
                    nodes,
                    edges,
                    semanticItems
            ));
        }
        return result;
    }

    private List<SemanticRow> parseRows(JsonNode node) {
        if (!node.isArray()) return List.of();
        List<SemanticRow> result = new ArrayList<>();
        for (JsonNode row : node) {
            List<SemanticValue> cells = new ArrayList<>();
            JsonNode cellArray = row.path("cells");
            if (cellArray.isArray()) {
                for (JsonNode cell : cellArray) {
                    cells.add(new SemanticValue(
                            cell.path("sourceId").asText(""),
                            cell.path("text").asText(""),
                            cell.path("role").asText(""),
                            cell.path("iconKey").asText("NONE")
                    ));
                }
            }
            result.add(new SemanticRow(cells));
        }
        return result;
    }

    private List<SemanticNode> parseNodes(JsonNode node) {
        if (!node.isArray()) return List.of();
        List<SemanticNode> result = new ArrayList<>();
        for (JsonNode item : node) {
            result.add(new SemanticNode(
                    item.path("id").asText(""),
                    item.path("sourceId").asText(""),
                    item.path("text").asText(""),
                    item.path("iconKey").asText("NONE")
            ));
        }
        return result;
    }

    private List<SemanticEdge> parseEdges(JsonNode node) {
        if (!node.isArray()) return List.of();
        List<SemanticEdge> result = new ArrayList<>();
        for (JsonNode item : node) {
            result.add(new SemanticEdge(
                    item.path("from").asText(""),
                    item.path("to").asText(""),
                    item.path("sourceId").asText(""),
                    item.path("label").asText("")
            ));
        }
        return result;
    }

    private List<SemanticItem> parseSemanticItems(JsonNode node) {
        if (!node.isArray()) return List.of();
        List<SemanticItem> result = new ArrayList<>();
        for (JsonNode item : node) {
            result.add(new SemanticItem(
                    item.path("sourceId").asText(""),
                    item.path("label").asText(""),
                    item.path("value").asText(""),
                    item.path("status").asText(""),
                    item.path("iconKey").asText("NONE")
            ));
        }
        return result;
    }

    private List<String> stringList(JsonNode node) {
        if (!node.isArray()) return List.of();
        List<String> result = new ArrayList<>();
        for (JsonNode value : node) result.add(value.asText(""));
        return result;
    }

    private JsonNode readJson(String raw) {
        try {
            String cleaned = raw == null ? "" : raw.trim();
            if (cleaned.startsWith("```")) {
                cleaned = cleaned.replaceFirst("^```(?:json)?\\s*", "").replaceFirst("\\s*```$", "");
            }
            int first = cleaned.indexOf('{');
            int last = cleaned.lastIndexOf('}');
            if (first >= 0 && last > first) cleaned = cleaned.substring(first, last + 1);
            return objectMapper.readTree(cleaned);
        } catch (Exception ex) {
            throw new IllegalStateException("LLM returned invalid adaptive-analysis JSON.", ex);
        }
    }

    private String clipDigest(String value) {
        if (value == null) return "";
        String oneLine = value.replace('\r', ' ').replace('\n', ' ').replaceAll("\\s+", " ").trim();
        if (oneLine.length() <= continuityCharacters) return oneLine;
        return oneLine.substring(0, continuityCharacters).trim();
    }

    private String deterministicDigest(List<SourceBlock> chunk) {
        String joined = chunk.stream()
                .filter(block -> !block.blank())
                .limit(4)
                .map(SourceBlock::text)
                .collect(Collectors.joining(" | "));
        return clipDigest(joined);
    }

    private String upper(String value) {
        return value == null ? "" : value.trim().toUpperCase(Locale.ROOT);
    }

    private record PlanValidation(Map<String, PlanItem> items, boolean fallbackUsed) {}

    public record AnalysisOutcome(
            List<PlanItem> plan,
            List<SemanticSection> semanticSections,
            int llmCalls,
            int chunks,
            boolean fallbackUsed,
            List<String> detectedLayouts
    ) {}
}
