package com.formatflow.ai.web;

import com.formatflow.ai.config.LlmProperties;
import com.formatflow.ai.model.SessionModels.SessionStatus;
import com.formatflow.ai.model.SessionModels.ValidateKeyRequest;
import com.formatflow.ai.model.SessionModels.ValidateKeyResponse;
import com.formatflow.ai.service.LlmClient;
import com.formatflow.ai.service.SessionKeyService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/session")
public class SessionController {

    private final LlmClient llmClient;
    private final SessionKeyService sessionKeyService;
    private final LlmProperties properties;

    public SessionController(LlmClient llmClient,
                             SessionKeyService sessionKeyService,
                             LlmProperties properties) {
        this.llmClient = llmClient;
        this.sessionKeyService = sessionKeyService;
        this.properties = properties;
    }

    @GetMapping("/status")
    public SessionStatus status(HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        return statusOf(session);
    }

    @PostMapping("/validate")
    public ValidateKeyResponse validate(@Valid @RequestBody ValidateKeyRequest request,
                                        HttpServletRequest servletRequest) {
        LlmClient.ValidationResult validation = llmClient.validateKey(request.apiKey());

        if (!validation.valid()) {
            return new ValidateKeyResponse(false, validation.message(), statusOf(servletRequest.getSession(false)));
        }

        HttpSession session = servletRequest.getSession(true);
        sessionKeyService.store(session, request.apiKey());
        return new ValidateKeyResponse(true, validation.message(), statusOf(session));
    }

    @PostMapping("/disconnect")
    public SessionStatus disconnect(HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        if (session != null) {
            sessionKeyService.clear(session);
            session.invalidate();
        }
        return new SessionStatus(false, properties.getModel(), publicBaseUrl());
    }

    private SessionStatus statusOf(HttpSession session) {
        return new SessionStatus(
                sessionKeyService.isConnected(session),
                properties.getModel(),
                publicBaseUrl()
        );
    }

    private String publicBaseUrl() {
        String base = properties.getBaseUrl();
        if (base == null || base.isBlank()) return "Not configured";
        try {
            java.net.URI uri = java.net.URI.create(base);
            String host = uri.getHost();
            return host == null ? "Configured" : host;
        } catch (Exception ex) {
            return "Configured";
        }
    }
}
