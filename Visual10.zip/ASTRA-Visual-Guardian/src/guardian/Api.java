package guardian;

import java.io.IOException;
import java.io.InputStream;
import java.nio.channels.FileChannel;
import java.nio.channels.FileLock;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

import static guardian.Json.*;
import static guardian.Util.*;

/**
 * Everything the UI can ask for, without any HTTP server. Two front doors use it:
 * the built-in server ({@link Main}, no dependencies) and the Spring Boot controllers (folder spring/).
 * Requests and answers are bytes, so both front doors behave identically.
 *
 * Endpoints (all under /api, all need the X-Guardian-Token header):
 * <pre>
 * GET  suites | models | runs | runs/{id}[?since=] | runs/{id}/{report.html|report.xlsx|baseline.zip|execution.zip}
 *      runs/{id}/{images|diffs|reference-images}/{name}.png
 * POST suites | import | models | models/discover | models/test | runs | runs/resume | runs/command
 *      coverage/review | approve | compare
 * </pre>
 */
public final class Api implements AutoCloseable {
    public static final int JSON_LIMIT = 2 * 1024 * 1024, ZIP_LIMIT = 128 * 1024 * 1024;

    /** Security headers sent with every answer. */
    public static final Map<String, String> HEADERS = Map.of(
            "Cache-Control", "no-store",
            "X-Content-Type-Options", "nosniff",
            "X-Frame-Options", "DENY",
            "Referrer-Policy", "no-referrer",
            "Content-Security-Policy", "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' blob: data:; "
                    + "connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'none'");

    /** An answer: status, content type, body, and a file name when it is a download. */
    public record Reply(int status, String type, byte[] body, String filename) {
        public static Reply json(int status, Object value) {
            return new Reply(status, "application/json;charset=utf-8", write(value).getBytes(StandardCharsets.UTF_8), "");
        }

        public static Reply json(Object value) {
            return json(200, value);
        }

        static Reply download(String filename, String type, byte[] body) {
            return new Reply(200, type, body, filename);
        }

        static Reply text(int status, String text) {
            return new Reply(status, "text/plain;charset=utf-8", text.getBytes(StandardCharsets.UTF_8), "");
        }
    }

    final Path root;
    final Store store;
    final Models models;
    final Engine engine;
    /** Session token: the UI page carries it, every API call must send it back (stops other web pages calling the API). */
    public final String token = id() + id();
    private final FileChannel lockChannel;
    private final FileLock lock;

    private Api(Path root, Store store, Models models, Engine engine, FileChannel lockChannel, FileLock lock) {
        this.root = root;
        this.store = store;
        this.models = models;
        this.engine = engine;
        this.lockChannel = lockChannel;
        this.lock = lock;
    }

    /** Opens a data folder; only one Guardian process may use it at a time. */
    public static Api open(Path folder) throws Exception {
        Path dir = folder.toAbsolutePath();
        Files.createDirectories(dir);
        FileChannel channel = FileChannel.open(dir.resolve(".lock"), StandardOpenOption.CREATE, StandardOpenOption.WRITE);
        FileLock lock;
        try {
            lock = channel.tryLock();
        } catch (Exception e) {
            channel.close();
            throw e;
        }
        if (lock == null) {
            channel.close();
            throw new IOException("Another Guardian instance is using this data directory");
        }
        try {
            var store = new Store(dir);
            var models = new Models(dir);
            return new Api(dir, store, models, new Engine(store, models), channel, lock);
        } catch (Exception e) {
            lock.release();
            channel.close();
            throw e;
        }
    }

    public Path root() {
        return root;
    }

    /** Stops running executions, closes their browsers and frees the data folder. */
    @Override
    public void close() {
        for (var c : engine.active.values()) {
            c.stop = true;
            if (c.browser != null) c.browser.close();
        }
        try {
            lock.release();
            lockChannel.close();
        } catch (Exception ignored) {
            // shutting down anyway
        }
    }

    // ---------------------------------------------------------------- request checks and pages

    /**
     * Local-only checks for one request; null when it may proceed. Every request must name this computer in its
     * Host header (stops DNS-rebinding pages); API requests also need the session token and, when a browser
     * sends an Origin, this app's own origin.
     */
    public Reply refuse(String path, String host, String origin, String tokenHeader, int port) {
        if (!Set.of("127.0.0.1:" + port, "localhost:" + port).contains(host)) return Reply.text(403, "Invalid host");
        if (!path.startsWith("/api/")) return null;
        if (!token.equals(tokenHeader)) return Reply.json(403, obj("error", "Local session token required"));
        if (origin != null && !Set.of("http://127.0.0.1:" + port, "http://localhost:" + port).contains(origin))
            return Reply.json(403, obj("error", "Invalid origin"));
        return null;
    }

    /** The three UI files; index.html carries this session's token. */
    public Reply page(String path) throws IOException {
        String file = switch (path) {
            case "/" -> "index.html";
            case "/app.js" -> "app.js";
            case "/style.css" -> "style.css";
            default -> "";
        };
        if (file.isBlank()) return Reply.json(404, obj("error", "Not found"));
        try (InputStream in = Api.class.getResourceAsStream("/" + file)) {
            if (in == null) throw new NoSuchFileException(file);
            byte[] b = in.readAllBytes();
            if (file.equals("index.html")) b = new String(b, StandardCharsets.UTF_8).replace("__GUARDIAN_TOKEN__", token).getBytes(StandardCharsets.UTF_8);
            String type = file.endsWith(".js") ? "application/javascript" : file.endsWith(".css") ? "text/css" : "text/html;charset=utf-8";
            return new Reply(200, type, b, "");
        }
    }

    /** The answer for a failed request: 404 for missing items, the reason and a fix for AI model problems, else 400. */
    public static Reply error(Exception ex) {
        if (ex instanceof NoSuchFileException) return Reply.json(404, obj("error", "Requested item not found"));
        if (ex instanceof Models.ModelException m) return Reply.json(400, obj("error", clip(m.reason, 600), "hint", m.hint));
        return Reply.json(400, obj("error", message(ex)));
    }

    public static Reply methodNotAllowed() {
        return Reply.json(405, obj("error", "Method not allowed"));
    }

    public static Reply unknown() {
        return Reply.json(404, obj("error", "Unknown endpoint"));
    }

    /** Reads a request body, refusing more than max bytes. */
    public static byte[] readLimited(InputStream in, int max) throws IOException {
        byte[] b = in.readNBytes(max + 1);
        if (b.length > max) throw new IOException("Request exceeds size limit");
        return b;
    }

    // ---------------------------------------------------------------- dispatch for the built-in server

    public Reply get(String path, String since) throws Exception {
        switch (path) {
            case "/api/suites":
                return suites();
            case "/api/models":
                return modelSettings();
            case "/api/runs":
                return runs();
            default:
                break;
        }
        if (path.startsWith("/api/runs/")) {
            String[] seg = path.substring(10).split("/", 2);
            return seg.length == 1 ? run(seg[0], since) : runFile(seg[0], seg[1]);
        }
        return unknown();
    }

    public Reply post(String path, byte[] body) throws Exception {
        return switch (path) {
            case "/api/import" -> importZip(body);
            case "/api/suites" -> createSuite(body);
            case "/api/models" -> saveModelSettings(body);
            case "/api/models/discover" -> discoverModels(body);
            case "/api/models/test" -> testModel(body);
            case "/api/runs" -> startRun(body);
            case "/api/runs/resume" -> resumeRun(body);
            case "/api/runs/command" -> command(body);
            case "/api/coverage/review" -> reviewCoverage(body);
            case "/api/approve" -> approve(body);
            case "/api/compare" -> compare(body);
            default -> unknown();
        };
    }

    static Map<String, Object> json(byte[] body) {
        if (body.length > JSON_LIMIT) throw new IllegalArgumentException("Request exceeds size limit");
        return read(new String(body, StandardCharsets.UTF_8));
    }

    // ---------------------------------------------------------------- suites

    public Reply suites() throws Exception {
        return Reply.json(store.allSuites());
    }

    public Reply createSuite(byte[] body) throws Exception {
        return Reply.json(store.create(json(body)));
    }

    /** Imports a baseline or execution ZIP exported by another Guardian. */
    public Reply importZip(byte[] zip) throws Exception {
        if (zip.length > ZIP_LIMIT) throw new IOException("Request exceeds size limit");
        var r = store.importZip(zip);
        try {
            Report.write(store, map(r.get("run")));
        } catch (Exception ignored) {
            // the report is written again on first download
        }
        return Reply.json(r);
    }

    // ---------------------------------------------------------------- AI models

    public Reply modelSettings() throws Exception {
        return Reply.json(models.view());
    }

    public Reply saveModelSettings(byte[] body) throws Exception {
        models.saveSettings(json(body));
        return Reply.json(models.view());
    }

    public Reply discoverModels(byte[] body) throws Exception {
        String role = s(json(body), "role");
        if (!Models.ROLES.contains(role)) throw new IllegalArgumentException("Invalid role");
        return Reply.json(obj("models", models.discover(role, map(models.snapshot(obj()).get(role)))));
    }

    public Reply testModel(byte[] body) throws Exception {
        return Reply.json(models.test(s(json(body), "role")));
    }

    // ---------------------------------------------------------------- runs

    public Reply runs() throws Exception {
        // Cached per-run summaries: polling the list does not parse every run.json.
        var rows = new ArrayList<Object>();
        for (Object o : store.runSummaries()) {
            var r = map(o);
            if (engine.storageErrors.containsKey(s(r, "id"))) r.put("status", "ERROR");
            rows.add(r);
        }
        return Reply.json(rows);
    }

    /** One run for the UI. "since" is the "updated" value the UI already shows; unchanged runs get a short answer. */
    public Reply run(String runId, String since) throws Exception {
        String id = checkedId(runId);
        if (since != null && !since.isBlank() && !engine.storageErrors.containsKey(id) && since.equals(s(store.summary(id), "updated")))
            return Reply.json(obj("unchanged", true, "active", engine.active.containsKey(id)));
        var r = store.run(id);
        if (engine.storageErrors.containsKey(id)) {
            r.put("status", "ERROR");
            r.put("message", engine.storageErrors.get(id));
        }
        r.put("states", list(r.get("states")).stream().map(x -> (Object) Store.lightState(map(x))).toList());
        if (s(r, "mode").equals("REPLAY"))
            r.put("queue", list(r.get("queue")).stream().map(x -> x instanceof Map ? (Object) Store.lightState(map(x)) : x).toList());
        Coverage.refresh(r);
        var reviews = map(r.get("coverageReviews"));
        r.put("coverageExceptions", list(r.get("skipped")).stream().map(o -> {
            var x = new LinkedHashMap<>(map(o));
            String k = Coverage.key(x);
            x.put("reviewId", k);
            x.put("reviewed", Coverage.inherent(x) || reviews.containsKey(k));
            return (Object) x;
        }).toList());
        r.put("verdict", Report.verdict(r));
        r.put("active", engine.active.containsKey(id));
        return Reply.json(r);
    }

    /** Reports, exports and evidence images of one run. */
    public Reply runFile(String runId, String file) throws Exception {
        String id = checkedId(runId);
        if (file.equals("baseline.zip") || file.equals("execution.zip")) {
            if (engine.active.containsKey(id)) throw new IllegalArgumentException("Wait for execution to finish");
            return Reply.download(file, "application/zip", store.exportRun(id, file.equals("baseline.zip")));
        }
        if (file.equals("report.html") || file.equals("report.xlsx")) {
            if (engine.active.containsKey(id)) throw new IllegalArgumentException("Report is available when execution finishes");
            Path path = store.dir(id).resolve(file);
            if (!Files.exists(path)) Report.write(store, store.run(id));
            return Reply.download(file, file.endsWith("html") ? "text/html" : "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    Files.readAllBytes(path));
        }
        if (file.matches("(?:images|diffs|reference-images)/[a-zA-Z0-9_-]+\\.png"))
            return new Reply(200, "image/png", Files.readAllBytes(under(store.dir(id), file)), "");
        return unknown();
    }

    public Reply startRun(byte[] body) throws Exception {
        return Reply.json(engine.start(json(body)));
    }

    public Reply resumeRun(byte[] body) throws Exception {
        var in = json(body);
        return Reply.json(engine.resume(s(in, "id"), map(in.get("config"))));
    }

    /** Pause, continue, stop and the other run commands. */
    public Reply command(byte[] body) throws Exception {
        var in = json(body);
        engine.command(s(in, "id"), s(in, "command"));
        return Reply.json(obj("ok", true));
    }

    /** Marks coverage exceptions of a finished, unapproved capture as reviewed (out of scope, with a reason). */
    public Reply reviewCoverage(byte[] body) throws Exception {
        var in = json(body);
        String id = s(in, "id");
        synchronized (engine) {
            if (engine.active.containsKey(id)) throw new IllegalArgumentException("Finish or stop the run before review");
            var r = store.run(id);
            if (!s(r, "mode").equals("CAPTURE")
                    || !Set.of("REVIEW_REQUIRED", "COMPLETED", "INCOMPLETE", "ERROR", "STOPPED", "INTERRUPTED").contains(s(r, "status"))
                    || store.approved(s(r, "suiteId"), id))
                throw new IllegalArgumentException("Only unapproved captures can be reviewed");
            Coverage.review(r, s(in, "reason"), strings(in.get("ids")));
            if (Coverage.executionComplete(r) && Coverage.pendingReviews(r).isEmpty()) {
                r.put("status", "COMPLETED");
                r.put("message", "All discovered eligible paths processed; exclusions explicitly reviewed; baseline can be reviewed for approval");
            }
            r.put("updated", now());
            store.saveRun(r);
            Report.write(store, r);
            return Reply.json(r);
        }
    }

    /** Approves a finished capture as the suite's baseline. */
    public Reply approve(byte[] body) throws Exception {
        String id = s(json(body), "id");
        synchronized (engine) {
            if (engine.active.containsKey(id)) throw new IllegalArgumentException("Wait for execution to finish");
            return Reply.json(store.approve(id));
        }
    }

    public Reply compare(byte[] body) throws Exception {
        var in = json(body);
        return Reply.json(engine.compareRuns(s(in, "left"), s(in, "right")));
    }
}
