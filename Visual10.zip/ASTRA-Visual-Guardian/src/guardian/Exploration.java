package guardian;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import static guardian.Json.*;
import static guardian.Util.*;

/**
 * Keeps a capture organized and free of repeated navigation. One per capture run; its record lives in the run
 * ("exploration"), so a resumed capture continues with it.
 *
 * Rules, checked before a control is queued (and again just before it is clicked):
 * <ol>
 *   <li>A link to the page Guardian is on, or to a page that is already explored or already waiting, is not opened.</li>
 *   <li>A control in the shared page frame (header, menu bar, footer) is explored once, from the first page where it
 *       appears, not once per page. Its links are covered by rule 1.</li>
 *   <li>A control that led to the same page from two different pages is shared (for example a "Help" button in a
 *       toolbar on every page) and is not clicked again.</li>
 *   <li>A drop-down or section that is already open, and a tab that is already selected, are not clicked: that would
 *       only close it again or show the same view.</li>
 * </ol>
 * The order itself (finish a page and everything under it, then go back) is the Engine's queue: the controls of a
 * newly captured page are put first.
 */
final class Exploration {
    static final String WAITING = "waiting", EXPLORED = "explored", SET_ASIDE = "set aside";
    static final int MAX_ENTRIES = 20000;

    final Map<String, Object> record;
    /** Route a link leads to -> waiting or explored. */
    final Map<String, Object> targets;
    /** Shared-frame control -> the page where it was first queued. */
    final Map<String, Object> shared;
    /** Control signature -> {landing, sources, varies} for controls without a link address. */
    final Map<String, Object> outcomes;

    private Exploration(Map<String, Object> record) {
        this.record = record;
        targets = section("targets");
        shared = section("shared");
        outcomes = section("outcomes");
    }

    /** The run's exploration record; for older runs, rebuilt from the pages captured so far. */
    static Exploration of(Map<String, Object> run) {
        boolean fresh = !(run.get("exploration") instanceof Map);
        if (fresh) run.put("exploration", obj());
        var ex = new Exploration(map(run.get("exploration")));
        if (fresh) for (Object o : list(run.get("states"))) {
            var st = map(o);
            if (list(st.get("path")).isEmpty() || b(st, "arrived")) ex.targets.put(s(st, "route"), EXPLORED);
        }
        return ex;
    }

    private Map<String, Object> section(String name) {
        if (!(record.get(name) instanceof Map)) record.put(name, new LinkedHashMap<String, Object>());
        return map(record.get(name));
    }

    int avoided() {
        return num(record.get("avoided"), 0);
    }

    void countAvoided() {
        record.put("avoided", avoided() + 1);
    }

    // ---------------------------------------------------------------- before queuing and before clicking

    /**
     * Why control a, found on a page at pageRoute, should not be queued; "" when it should. With claim, a queued
     * link reserves its target and a queued shared control reserves its key, and the queue entry is annotated so the
     * check can be repeated just before clicking.
     */
    String skip(Map<String, Object> a, String pageRoute, Map<String, Object> entry, boolean claim) {
        String role = s(a, "role");
        if (s(a, "expanded").equals("true")) return "already open";
        if (role.equals("tab") && s(a, "selected").equals("true")) return "tab already selected";
        String target = target(a);
        if (!target.isEmpty()) {
            if (target.equals(pageRoute)) return "link to the same page";
            if (targets.containsKey(target)) return "page already " + (WAITING.equals(targets.get(target)) ? "waiting to be explored" : str(targets.get(target)));
            if (claim && targets.size() < MAX_ENTRIES) {
                targets.put(target, WAITING);
                entry.put("target", target);
            }
            return "";
        }
        String frame = s(a, "region");
        if (!frame.isEmpty() && !role.equals("scroll")) {
            String key = frame + "|" + role + "|" + plainLabel(s(a, "label"));
            if (shared.containsKey(key)) return "shared " + frame + " control already explored";
            if (claim && shared.size() < MAX_ENTRIES) {
                shared.put(key, s(entry, "parent"));
                entry.put("shared", key);
            }
            return "";
        }
        String sig = signature(a);
        if (b(map(outcomes.get(sig)), "shared")) return "leads to the same page from every page";
        if (claim) entry.put("signature", sig);
        return "";
    }

    /** The same check just before clicking: the page may have been explored through another path meanwhile. */
    String stale(Map<String, Object> entry) {
        String target = s(entry, "target");
        if (!target.isEmpty() && EXPLORED.equals(targets.get(target))) return "page already explored";
        String sig = s(entry, "signature");
        if (!sig.isEmpty() && b(map(outcomes.get(sig)), "shared")) return "leads to the same page from every page";
        return "";
    }

    /** The page behind this entry could not be opened safely (blocked request, endless sign-in): other links to it are not tried. */
    void setAside(Map<String, Object> entry) {
        String target = s(entry, "target");
        if (!target.isEmpty()) targets.put(target, SET_ASIDE);
    }

    /** Gives back a reservation when the queue entry is dropped without being explored (for example after an error), so another link may try. */
    void release(Map<String, Object> entry) {
        String target = s(entry, "target");
        if (!target.isEmpty() && WAITING.equals(targets.get(target))) targets.remove(target);
        String key = s(entry, "shared");
        if (!key.isEmpty()) shared.remove(key);
    }

    // ---------------------------------------------------------------- after clicking

    /**
     * Records where a queue entry led: the page (state id) and its route. When the address changed, the route counts
     * as explored, so links to it are not opened again. Controls without a link address learn their outcome.
     */
    void landed(Map<String, Object> entry, String fromState, String fromRoute, String route, String landingState) {
        String target = s(entry, "target");
        if (!target.isEmpty()) targets.put(target, EXPLORED);
        if (!route.isEmpty() && !route.equals(fromRoute) && targets.size() < MAX_ENTRIES) targets.put(route, EXPLORED);
        String sig = s(entry, "signature");
        if (sig.isEmpty() || fromState.isEmpty() || landingState.isEmpty()) return;
        var o = map(outcomes.get(sig));
        if (o.isEmpty()) {
            if (outcomes.size() >= MAX_ENTRIES) return;
            o = obj("landing", landingState, "sources", new ArrayList<>(List.of(fromState)), "shared", false, "varies", false);
            outcomes.put(sig, o);
            return;
        }
        if (b(o, "varies")) return;
        if (!s(o, "landing").equals(landingState)) {
            o.put("varies", true);
            o.put("shared", false);
            return;
        }
        var sources = list(o.get("sources"));
        if (!sources.contains(fromState)) sources.add(fromState);
        if (sources.size() >= 2) o.put("shared", true);
    }

    // ---------------------------------------------------------------- helpers

    /** The route a real link leads to ("" for buttons, and for "#" or javascript: links that only run page code). */
    static String target(Map<String, Object> a) {
        String href = s(a, "href");
        if (href.isBlank() || !b(a, "navigates")) return "";
        return Util.route("http://local" + (href.startsWith("/") ? href : "/" + href));
    }

    /** A label without counters such as "(3)" or "5 new", so "Notifications (3)" and "Notifications" are one control. */
    static String plainLabel(String label) {
        return Util.norm(Engine.counterless(label).replace("(#)", " ")).strip();
    }

    /** What identifies a control across pages: role, label without counters, and where it sits in the page. */
    static String signature(Map<String, Object> a) {
        return s(a, "role") + "|" + plainLabel(s(a, "label")) + "|" + s(a, "css");
    }
}
