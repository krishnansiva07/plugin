package guardian;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.util.concurrent.Executors;

/**
 * The built-in front door: Java's own small HTTP server on 127.0.0.1, no other dependencies.
 * It only moves bytes; every endpoint lives in {@link Api}. The Spring Boot version (folder spring/) uses the same Api.
 * Usage: java -jar visual-guardian.jar [--port 8765] [--data guardian-data]
 */
public class Main {
    final Api api;
    final HttpServer server;
    final int port;

    Main(int port, Path root) throws Exception {
        api = Api.open(root);
        server = HttpServer.create(new InetSocketAddress("127.0.0.1", port), 0);
        this.port = server.getAddress().getPort();
        server.setExecutor(Executors.newCachedThreadPool());
        server.createContext("/", this::handle);
    }

    public static void main(String[] args) throws Exception {
        System.setProperty("java.awt.headless", "true");
        useSystemProxies();
        int port = 8765;
        Path root = Path.of("guardian-data");
        for (int i = 0; i < args.length; i++) {
            if (args[i].equals("--port")) port = Integer.parseInt(args[++i]);
            else if (args[i].equals("--data")) root = Path.of(args[++i]);
            else throw new IllegalArgumentException("Unknown argument: " + args[i]);
        }
        var m = new Main(port, root);
        m.server.start();
        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            m.api.close();
            m.server.stop(0);
        }));
        System.out.println("ASTRA Visual Guardian — http://127.0.0.1:" + m.port);
        System.out.println("Data: " + m.api.root());
    }

    /**
     * Model servers are reached through the operating system's proxy settings unless Java proxy options are given.
     * The browser connection always goes direct (Browser uses NO_PROXY), and so do model servers on this computer.
     */
    public static void useSystemProxies() {
        if (System.getProperty("java.net.useSystemProxies") == null && System.getProperty("https.proxyHost") == null
                && System.getProperty("http.proxyHost") == null)
            System.setProperty("java.net.useSystemProxies", "true");
    }

    void handle(HttpExchange e) throws IOException {
        try {
            String path = e.getRequestURI().getPath(), method = e.getRequestMethod();
            var headers = e.getRequestHeaders();
            Api.Reply refusal = api.refuse(path, headers.getFirst("Host"), headers.getFirst("Origin"), headers.getFirst("X-Guardian-Token"), port);
            if (refusal != null) send(e, refusal);
            else if (!path.startsWith("/api/")) send(e, method.equals("GET") ? api.page(path) : Api.methodNotAllowed());
            else if (method.equals("GET")) send(e, api.get(path, query(e, "since")));
            else if (method.equals("POST")) send(e, api.post(path, body(e, path.equals("/api/import") ? Api.ZIP_LIMIT : Api.JSON_LIMIT)));
            else send(e, Api.methodNotAllowed());
        } catch (Exception ex) {
            try {
                send(e, Api.error(ex));
            } catch (IOException ignored) {
                // the client has gone
            }
        } finally {
            e.close();
        }
    }

    /** Value of a query-string parameter, or "" when absent. */
    static String query(HttpExchange e, String name) {
        String q = e.getRequestURI().getRawQuery();
        if (q == null) return "";
        for (String part : q.split("&")) {
            int i = part.indexOf('=');
            if ((i < 0 ? part : part.substring(0, i)).equals(name))
                return i < 0 ? "" : URLDecoder.decode(part.substring(i + 1), StandardCharsets.UTF_8);
        }
        return "";
    }

    static byte[] body(HttpExchange e, int max) throws IOException {
        try (var in = e.getRequestBody()) {
            return Api.readLimited(in, max);
        }
    }

    static void send(HttpExchange e, Api.Reply reply) throws IOException {
        var h = e.getResponseHeaders();
        h.set("Content-Type", reply.type());
        Api.HEADERS.forEach(h::set);
        if (!reply.filename().isBlank()) h.set("Content-Disposition", "attachment; filename=\"" + reply.filename() + "\"");
        e.sendResponseHeaders(reply.status(), reply.body().length);
        try (var out = e.getResponseBody()) {
            out.write(reply.body());
        }
    }
}
