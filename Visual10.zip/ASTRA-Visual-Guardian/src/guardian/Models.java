package guardian;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.net.ConnectException;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.ProxySelector;
import java.net.Socket;
import java.net.SocketAddress;
import java.net.URI;
import java.net.UnknownHostException;
import java.net.http.HttpClient;
import java.net.http.HttpConnectTimeoutException;
import java.net.http.HttpHeaders;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpTimeoutException;
import java.nio.channels.UnresolvedAddressException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.KeyStore;
import java.security.cert.Certificate;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLEngine;
import javax.net.ssl.SSLException;
import javax.net.ssl.SSLHandshakeException;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;
import javax.net.ssl.X509ExtendedTrustManager;

import static guardian.Json.*;
import static guardian.Util.*;

/**
 * Client for the optional AI roles: Agent (orders the controls to explore), Vision (describes screenshot
 * differences) and Reviewer (summarises the evidence). It speaks the OpenAI-compatible chat-completions API
 * offered by OpenAI, Azure OpenAI, Ollama, LM Studio, vLLM, LiteLLM and most company gateways.
 *
 * Every failure becomes a {@link ModelException} that carries the server's own reason and a plain fix,
 * because "HTTP 400" alone does not tell anyone what to change. Compatibility differences are handled
 * automatically where that is safe: a missing "/v1" in the address, models that need max_completion_tokens
 * or their default temperature, Azure's api-key header, "thinking" text around the answer, streamed answers,
 * company proxies and company certificate authorities.
 */
final class Models {
    static final Set<String> ROLES = Set.of("agent", "vision", "reviewer");
    static final int DEFAULT_TIMEOUT = 35, MAX_TIMEOUT = 300, DEFAULT_TOKENS = 800, MAX_TOKENS = 32000;
    static final Set<String> RESERVED_HEADERS = Set.of("connection", "content-length", "content-type", "expect", "host", "upgrade", "accept");

    final HttpClient client;
    final Path path;
    Map<String, Object> settings;
    /** API keys stay in this process (or come from GUARDIAN_<ROLE>_API_KEY); they are never written to disk. */
    final Map<String, String> keys = new HashMap<>();
    /** Configured base address -> the address that actually answered, when "/v1" had to be added. */
    final Map<String, String> workingBase = new ConcurrentHashMap<>();
    /** Endpoint + model -> request changes that server asked for ("max_completion_tokens", "no_temperature"). */
    final Map<String, Set<String>> quirks = new ConcurrentHashMap<>();

    Models(Path root) throws Exception {
        path = root.resolve("models.json");
        settings = Files.exists(path) ? load(path) : obj();
        client = HttpClient.newBuilder()
                .version(HttpClient.Version.HTTP_1_1)          // some gateways mishandle HTTP/2 upgrade requests
                .connectTimeout(Duration.ofSeconds(10))
                .followRedirects(HttpClient.Redirect.NEVER)    // never resend a key elsewhere; report the new address instead
                .proxy(new Proxies())
                .sslContext(Trust.context())
                .build();
    }

    /** A failed model call: what happened (with the server's own words) and what to change. */
    static final class ModelException extends Exception {
        final String reason, hint, serverText;
        final int status;

        ModelException(String reason, String hint) {
            this(reason, hint, 0, "");
        }

        ModelException(String reason, String hint, int status, String serverText) {
            super(hint.isBlank() ? reason : reason + ". " + hint);
            this.reason = reason;
            this.hint = hint;
            this.status = status;
            this.serverText = serverText;
        }
    }

    // ---------------------------------------------------------------- settings

    synchronized Map<String, Object> view() {
        var v = read(write(settings));
        for (String role : ROLES) {
            var m = map(v.get(role));
            m.put("keyConfigured", !key(role).isBlank());
            v.put(role, m);
        }
        return v;
    }

    synchronized String key(String role) {
        String env = System.getenv().getOrDefault("GUARDIAN_" + role.toUpperCase(Locale.ROOT) + "_API_KEY", "");
        return keys.getOrDefault(role, env).strip();
    }

    synchronized void saveSettings(Map<String, Object> input) throws Exception {
        var next = obj();
        for (String role : ROLES) {
            var m = map(input.get(role));
            String endpoint = s(m, "endpoint").strip(), model = s(m, "model").strip(), header = s(m, "keyHeader").strip();
            String key = s(m, "key").strip();
            if (!endpoint.isBlank()) url(endpoint);
            if (model.length() > 300) throw new IllegalArgumentException("Model ID too long");
            if (!header.isBlank() && (!header.matches("[A-Za-z0-9][A-Za-z0-9_-]{0,63}") || RESERVED_HEADERS.contains(header.toLowerCase(Locale.ROOT))))
                throw new IllegalArgumentException("Key header must be a header name such as Authorization, api-key or x-api-key");
            if (key.matches("(?s).*[\\r\\n\\t].*")) throw new IllegalArgumentException("The " + label(role) + " API key contains line breaks; paste only the key");
            var saved = obj("endpoint", endpoint, "model", model,
                    "timeout", bound(m.get("timeout"), DEFAULT_TIMEOUT, 5, MAX_TIMEOUT),
                    "maxTokens", bound(m.get("maxTokens"), DEFAULT_TOKENS, 64, MAX_TOKENS));
            if (!header.isBlank()) saved.put("keyHeader", header);
            next.put(role, saved);
            if (!key.isBlank()) keys.put(role, key);
            if (b(m, "clearKey")) keys.remove(role);
        }
        save(path, next);
        settings = next;
        workingBase.clear();
        quirks.clear();
    }

    /** The settings a run keeps, with per-run model or endpoint overrides applied. */
    synchronized Map<String, Object> snapshot(Map<String, Object> overrides) {
        var out = obj();
        for (String role : ROLES) {
            var m = read(write(map(settings.get(role))));
            var o = map(overrides.get(role));
            if (o.containsKey("model")) m.put("model", s(o, "model"));
            if (o.containsKey("endpoint")) m.put("endpoint", s(o, "endpoint"));
            if (!s(m, "endpoint").isBlank()) url(s(m, "endpoint"));
            out.put(role, m);
        }
        return out;
    }

    boolean enabled(Map<String, Object> model) {
        return !s(model, "model").isBlank() && !s(model, "endpoint").isBlank();
    }

    static String label(String role) {
        return role.isEmpty() ? role : role.substring(0, 1).toUpperCase(Locale.ROOT) + role.substring(1);
    }

    // ---------------------------------------------------------------- public operations

    /** "Test connection": a tiny request that proves address, key, model ID and answer format all work. */
    Map<String, Object> test(String role) throws Exception {
        if (!ROLES.contains(role)) throw new IllegalArgumentException("Invalid role");
        var m = map(snapshot(obj()).get(role));
        if (s(m, "endpoint").isBlank())
            throw new ModelException("No API base URL is set for the " + label(role) + " role", "Enter the address, save, then test again");
        if (s(m, "model").isBlank())
            throw new ModelException("No model ID is set for the " + label(role) + " role", "Use 'Discover models' to pick one, or type the exact ID");
        Object content = role.equals("vision")
                ? List.of(obj("type", "text", "text", "What color is this image? Answer in one word."), image(sampleImage()))
                : "Reply with OK";
        return complete(role, m, "Simple capability check", content);
    }

    /** "Discover models": the model IDs the server lists. */
    List<String> discover(String role, Map<String, Object> m) throws Exception {
        Address a = Address.of(s(m, "endpoint"));
        if (a.base().isBlank())
            throw new ModelException("No API base URL is set for the " + label(role) + " role", "Enter the address, save, then discover again");
        if (!a.deployment().isBlank()) return List.of(a.deployment());   // Azure: the deployment in the address is the model
        var json = send(role, m, "/models", null).json();
        Object data = json.containsKey("data") ? json.get("data") : json.get("models");
        var ids = new LinkedHashSet<String>();
        for (Object x : list(data)) {
            var e = map(x);
            String id = firstNonBlank(s(e, "id"), s(e, "name"), s(e, "model"), x instanceof String t ? t : "");
            if (!id.isBlank()) ids.add(id);
        }
        if (ids.isEmpty())
            throw new ModelException("The server answered but listed no models", "Type the exact model ID instead; some servers do not offer a model list");
        return new ArrayList<>(ids);
    }

    /** One chat request. Retries once per known compatibility difference the server reports. */
    Map<String, Object> complete(String role, Map<String, Object> m, String system, Object content) throws Exception {
        Set<String> q = quirks.computeIfAbsent(s(m, "endpoint") + "|" + s(m, "model"), k -> ConcurrentHashMap.newKeySet());
        int max = bound(m.get("maxTokens"), DEFAULT_TOKENS, 64, MAX_TOKENS);
        long start = System.nanoTime();
        for (int attempt = 0; ; attempt++) {
            var body = obj("model", s(m, "model"),
                    "messages", List.of(obj("role", "system", "content", system), obj("role", "user", "content", content)),
                    "stream", false);
            body.put(q.contains("max_completion_tokens") ? "max_completion_tokens" : "max_tokens", max);
            if (!q.contains("no_temperature")) body.put("temperature", 0.1);
            try {
                Answer answer = send(role, m, "/chat/completions", body);
                String text = answerText(answer.json(), max);
                var out = obj("text", clip(text, 8000), "usage", map(answer.json().get("usage")),
                        "elapsedMs", (System.nanoTime() - start) / 1_000_000, "model", s(m, "model"), "address", answer.url());
                var notes = new ArrayList<String>();
                if (!answer.note().isBlank()) notes.add(answer.note());
                if (q.contains("max_completion_tokens")) notes.add("This model needs max_completion_tokens instead of max_tokens; Guardian sends that automatically.");
                if (q.contains("no_temperature")) notes.add("This model accepts only its default temperature; Guardian leaves temperature out.");
                if (!notes.isEmpty()) out.put("note", String.join(" ", notes));
                return out;
            } catch (ModelException e) {
                if (attempt < 3 && e.status == 400) {
                    String said = e.serverText.toLowerCase(Locale.ROOT);
                    if (!q.contains("max_completion_tokens") && said.contains("max_tokens")
                            && (said.contains("max_completion_tokens") || said.contains("unsupported") || said.contains("not supported"))) {
                        q.add("max_completion_tokens");
                        continue;
                    }
                    if (!q.contains("no_temperature") && said.contains("temperature")) {
                        q.add("no_temperature");
                        continue;
                    }
                }
                throw e;
            }
        }
    }

    static Object image(byte[] data) {
        return obj("type", "image_url", "image_url", obj("url", "data:image/png;base64," + Base64.getEncoder().encodeToString(data)));
    }

    /** A 16x16 red square for the Vision test. */
    static byte[] sampleImage() throws IOException {
        var img = new java.awt.image.BufferedImage(16, 16, java.awt.image.BufferedImage.TYPE_INT_RGB);
        for (int y = 0; y < 16; y++) for (int x = 0; x < 16; x++) img.setRGB(x, y, 0xff0000);
        var out = new ByteArrayOutputStream();
        javax.imageio.ImageIO.write(img, "png", out);
        return out.toByteArray();
    }

    /** The first JSON object in a model's answer; models often wrap JSON in prose, ``` fences or thinking text. */
    static Map<String, Object> jsonObject(String text) {
        String t = stripThinking(text);
        int tries = 0;
        for (int start = t.indexOf('{'); start >= 0 && tries < 25; start = t.indexOf('{', start + 1), tries++) {
            int depth = 0;
            boolean inString = false, escaped = false;
            for (int i = start; i < t.length(); i++) {
                char c = t.charAt(i);
                if (inString) {
                    if (escaped) escaped = false;
                    else if (c == '\\') escaped = true;
                    else if (c == '"') inString = false;
                } else if (c == '"') inString = true;
                else if (c == '{') depth++;
                else if (c == '}' && --depth == 0) {
                    try {
                        Object o = Json.parse(t.substring(start, i + 1));
                        if (o instanceof Map) return map(o);
                    } catch (Exception ignored) {
                        // not this one; try the next opening brace
                    }
                    break;
                }
            }
        }
        throw new IllegalArgumentException("The answer has no JSON object: " + clip(t, 120));
    }

    // ---------------------------------------------------------------- transport

    /** The API base address, without pasted endpoint paths, with any query (Azure's ?api-version=) kept aside. */
    record Address(String base, String query) {
        static Address of(String endpoint) {
            String e = endpoint.strip(), q = "";
            int hash = e.indexOf('#');
            if (hash >= 0) e = e.substring(0, hash);
            int i = e.indexOf('?');
            if (i >= 0) {
                q = e.substring(i + 1);
                e = e.substring(0, i);
            }
            e = e.replaceAll("/+$", "");
            for (String tail : List.of("/chat/completions", "/completions", "/models"))
                if (e.toLowerCase(Locale.ROOT).endsWith(tail)) {
                    e = e.substring(0, e.length() - tail.length());
                    break;
                }
            return new Address(e.replaceAll("/+$", ""), q);
        }

        String url(String tail) {
            return base + tail + (query.isBlank() ? "" : "?" + query);
        }

        String host() {
            try {
                return Objects.toString(URI.create(base).getHost(), "").toLowerCase(Locale.ROOT);
            } catch (Exception e) {
                return "";
            }
        }

        boolean azure() {
            String h = host();
            return base.toLowerCase(Locale.ROOT).contains("/openai/deployments/") || h.endsWith(".openai.azure.com")
                    || h.endsWith(".cognitiveservices.azure.com") || h.endsWith(".services.ai.azure.com");
        }

        String deployment() {
            Matcher m = Pattern.compile("(?i)/openai/deployments/([^/]+)").matcher(base);
            return m.find() ? m.group(1) : "";
        }

        /** True when the address already names an API version (…/v1, …/v1beta, Azure's /openai/…). */
        boolean versioned() {
            return base.matches("(?i).*/v\\d+[a-z0-9.]*") || base.toLowerCase(Locale.ROOT).contains("/openai/");
        }
    }

    record Reply(int status, String body, HttpHeaders headers, String url) {}

    record Answer(Map<String, Object> json, String note, String url) {}

    /** Sends a request to the role's server. Adds "/v1" once when the configured address has no API version and answers 404. */
    Answer send(String role, Map<String, Object> m, String tail, Object body) throws ModelException, InterruptedException {
        Address configured = Address.of(s(m, "endpoint"));
        String known = workingBase.get(configured.base());
        Address a = known == null ? configured : new Address(known, configured.query());
        Reply r = exchange(role, m, a, tail, body);
        if (r.status() == 404 && known == null && !configured.versioned() && !configured.azure() && !mentionsModel(r.body())) {
            Address v1 = new Address(configured.base() + "/v1", configured.query());
            Reply retry = exchange(role, m, v1, tail, body);
            if (retry.status() != 404 || mentionsModel(retry.body())) {
                workingBase.put(configured.base(), v1.base());
                a = v1;
                r = retry;
            }
        }
        String note = a.base().equals(configured.base()) ? ""
                : "The address worked after adding /v1. Change the API base URL to " + a.base() + " to skip the extra request.";
        if (r.status() / 100 != 2) throw httpError(role, a, r);
        return new Answer(parse(r), note, r.url());
    }

    Reply exchange(String role, Map<String, Object> m, Address a, String tail, Object body) throws ModelException, InterruptedException {
        String target = a.url(tail);
        int timeout = bound(m.get("timeout"), DEFAULT_TIMEOUT, 5, MAX_TIMEOUT);
        HttpRequest.Builder req;
        try {
            req = HttpRequest.newBuilder(url(target)).timeout(Duration.ofSeconds(timeout)).header("Accept", "application/json");
        } catch (IllegalArgumentException e) {
            throw new ModelException("The API base URL is not a valid address: " + clip(target, 200), "Enter an address such as https://api.openai.com/v1");
        }
        authorize(req, role, m, a);
        if (body == null) req.GET();
        else req.header("Content-Type", "application/json").POST(HttpRequest.BodyPublishers.ofString(write(body)));
        String where = hostPort(target);
        try {
            var res = client.send(req.build(), HttpResponse.BodyHandlers.ofString());
            return new Reply(res.statusCode(), res.body(), res.headers(), target);
        } catch (HttpConnectTimeoutException e) {
            throw new ModelException("Could not connect to " + where + " within 10 seconds",
                    "The server is not reachable from this computer. Check the address. On a company network the request may need a proxy: "
                            + "Guardian uses the system proxy settings, or set GUARDIAN_PROXY=host:port before starting it");
        } catch (HttpTimeoutException e) {
            throw new ModelException("No answer from " + where + " within " + timeout + " seconds",
                    "Large or local models can take a minute or more on first use while they load. Raise 'Timeout seconds' for this role (up to "
                            + MAX_TIMEOUT + ") and test again");
        } catch (ConnectException e) {
            if (causedBy(e, UnresolvedAddressException.class)) throw unknownHost(a);
            throw new ModelException("Could not connect to " + where + " (connection refused)",
                    "Nothing is listening there. Check the host and port, and that the model server is running (Ollama: 'ollama serve'; LM Studio: start its local server)");
        } catch (UnknownHostException e) {
            throw unknownHost(a);
        } catch (SSLHandshakeException e) {
            String why = Objects.toString(e.getMessage(), "");
            if (why.contains("PKIX") || why.contains("certification path"))
                throw new ModelException("The server's HTTPS certificate is not trusted",
                        "This is common on company networks that inspect HTTPS. Guardian trusts Java's and the operating system's certificate stores"
                                + Trust.warning + "; if this persists, export your company's root certificate (.cer or .pem) and set GUARDIAN_CA_FILE to that file before starting Guardian");
            if (why.toLowerCase(Locale.ROOT).contains("subject alternative") || why.toLowerCase(Locale.ROOT).contains("no name matching"))
                throw new ModelException("The server's HTTPS certificate is for a different host name", "Use the host name the certificate was issued for");
            throw new ModelException("The HTTPS handshake with " + where + " failed: " + clip(why, 160),
                    "If the server only speaks plain HTTP, use http://. Servers that require a client certificate are not supported");
        } catch (SSLException e) {
            throw new ModelException("The server at " + where + " does not speak HTTPS", "Use http:// instead of https:// in the API base URL");
        } catch (IOException e) {
            String why = Objects.toString(e.getMessage(), e.getClass().getSimpleName());
            throw new ModelException("The server at " + where + " closed the connection without answering (" + clip(why, 120) + ")",
                    "If the server uses HTTPS, the address must start with https://. A proxy or firewall may also be dropping the request");
        }
    }

    static boolean causedBy(Throwable t, Class<? extends Throwable> type) {
        for (Throwable c = t; c != null; c = c.getCause()) if (type.isInstance(c)) return true;
        return false;
    }

    static ModelException unknownHost(Address a) {
        return new ModelException("Host name not found: " + a.host(),
                "Check the spelling. On a company network the name may only resolve when you are on the VPN or behind the proxy");
    }

    static String hostPort(String target) {
        try {
            URI u = URI.create(target);
            int port = u.getPort() >= 0 ? u.getPort() : "https".equalsIgnoreCase(u.getScheme()) ? 443 : 80;
            return u.getHost() + ":" + port;
        } catch (Exception e) {
            return target;
        }
    }

    /** Sends the key the way the server expects: "Authorization: Bearer" by default, "api-key" for Azure, or the configured header. */
    void authorize(HttpRequest.Builder req, String role, Map<String, Object> m, Address a) {
        String key = key(role);
        if (key.isBlank()) return;
        boolean prefixed = key.regionMatches(true, 0, "Bearer ", 0, 7);
        String header = s(m, "keyHeader").strip();
        if (header.isBlank()) header = a.azure() ? "api-key" : "Authorization";
        if (header.equalsIgnoreCase("Authorization")) req.header("Authorization", prefixed ? key : "Bearer " + key);
        else req.header(header, prefixed ? key.substring(7).strip() : key);
    }

    // ---------------------------------------------------------------- answers and errors

    static Map<String, Object> parse(Reply r) throws ModelException {
        String text = r.body() == null ? "" : r.body().strip();
        if (text.startsWith("data:")) return fromStream(text);
        if (text.isEmpty())
            throw new ModelException("The server answered with an empty body", "Check the API base URL; it should be an OpenAI-compatible API address (usually ending in /v1)");
        if (!text.startsWith("{") && !text.startsWith("["))
            throw new ModelException("The address answered with " + describe(text) + " instead of the model API",
                    "Check the API base URL: it should be the API address (usually ending in /v1), not a web page or a sign-in page");
        Object o;
        try {
            o = Json.parse(text);
        } catch (Exception e) {
            throw new ModelException("The answer is not valid JSON (" + clip(text, 100) + ")", "Check that the address is an OpenAI-compatible API");
        }
        if (o instanceof List<?> l) return obj("data", l);
        var json = map(o);
        if (json.containsKey("error") && !json.containsKey("choices") && !json.containsKey("data"))
            throw new ModelException("The model server returned an error: " + clip(errorText(json), 300), "");
        return json;
    }

    /** Joins a streamed ("data: {...}") answer, for servers that stream even when asked not to. */
    static Map<String, Object> fromStream(String text) throws ModelException {
        var content = new StringBuilder();
        var reasoning = new StringBuilder();
        String finish = "";
        Map<String, Object> usage = obj();
        for (String line : text.split("\\r?\\n")) {
            line = line.strip();
            if (!line.startsWith("data:")) continue;
            String data = line.substring(5).strip();
            if (data.isEmpty() || data.equals("[DONE]")) continue;
            Map<String, Object> chunk;
            try {
                chunk = read(data);
            } catch (Exception e) {
                continue;
            }
            if (chunk.containsKey("error")) throw new ModelException("The model server returned an error: " + clip(errorText(chunk), 300), "");
            if (chunk.get("usage") instanceof Map) usage = map(chunk.get("usage"));
            for (Object c : list(chunk.get("choices"))) {
                var choice = map(c);
                var delta = choice.containsKey("delta") ? map(choice.get("delta")) : map(choice.get("message"));
                content.append(contentText(delta.get("content")));
                reasoning.append(s(delta, "reasoning_content")).append(s(delta, "reasoning"));
                if (!s(choice, "finish_reason").isBlank()) finish = s(choice, "finish_reason");
            }
        }
        var message = obj("role", "assistant", "content", content.toString());
        if (reasoning.length() > 0) message.put("reasoning_content", reasoning.toString());
        return obj("choices", List.of(obj("index", 0, "message", message, "finish_reason", finish)), "usage", usage);
    }

    static String answerText(Map<String, Object> res, int max) throws ModelException {
        var choices = list(res.get("choices"));
        if (choices.isEmpty())
            throw new ModelException("The answer has no 'choices'",
                    "The address answered, but not in the chat-completions format. Check that the API base URL is an OpenAI-compatible API");
        var choice = map(choices.get(0));
        var message = map(choice.get("message"));
        String raw = contentText(message.get("content"));
        String text = stripThinking(raw);
        if (text.isBlank() && choice.containsKey("text")) text = stripThinking(s(choice, "text"));
        if (!text.isBlank()) return text;
        if (!s(message, "refusal").isBlank()) throw new ModelException("The model refused to answer: " + clip(s(message, "refusal"), 200), "");
        String thought = firstNonBlank(s(message, "reasoning_content"), s(message, "reasoning"), s(message, "thinking"));
        String finish = s(choice, "finish_reason");
        if (!thought.isBlank() || finish.equals("length") || !raw.isBlank())
            throw new ModelException("The model spent its whole answer on reasoning and returned no reply"
                    + (finish.equals("length") ? " (it stopped at the " + max + "-token limit)" : ""),
                    "Raise 'Maximum response tokens' for this role (for example to 4000), or turn reasoning/thinking off for this model on the server");
        throw new ModelException("The model returned an empty answer",
                "Check that the model ID is a chat model. Some servers return nothing while a model is still loading; test again in a minute");
    }

    static String contentText(Object content) {
        if (content instanceof List<?> parts) {
            var b = new StringBuilder();
            for (Object p : parts) {
                if (p instanceof String t) b.append(t);
                else if (!s(map(p), "text").isBlank()) b.append(s(map(p), "text"));
            }
            return b.toString();
        }
        return str(content);
    }

    /** Removes <think>…</think> blocks; an unfinished block (cut off by the token limit) leaves nothing. */
    static String stripThinking(String text) {
        String t = text.replaceAll("(?is)<(think|thinking|reasoning)>.*?</\\1>", "");
        if (t.matches("(?is)\\s*<(think|thinking|reasoning)>.*")) t = "";
        return t.strip();
    }

    static boolean mentionsModel(String body) {
        String said = serverMessage(body).toLowerCase(Locale.ROOT);
        return said.contains("model") || said.contains("deployment");
    }

    static String errorText(Map<String, Object> json) {
        Object e = json.get("error");
        if (e instanceof Map) {
            var em = map(e);
            return firstNonBlank(s(em, "message"), s(em, "msg"), s(em, "code"), write(em));
        }
        if (e instanceof String t && !t.isBlank()) return t;
        Object detail = json.get("detail");
        if (detail instanceof List<?> l && !l.isEmpty()) return firstNonBlank(s(map(l.get(0)), "msg"), str(l.get(0)));
        return firstNonBlank(s(json, "message"), str(detail), s(json, "title"), s(json, "error_description"));
    }

    /** The server's own explanation of a failed request, from JSON error bodies, plain text or an HTML page title. */
    static String serverMessage(String body) {
        String b = body == null ? "" : body.strip();
        if (b.isEmpty()) return "";
        if (b.startsWith("{") || b.startsWith("[")) {
            try {
                Object o = Json.parse(b);
                if (o instanceof Map) {
                    String t = errorText(map(o));
                    if (!t.isBlank()) return clip(t, 300);
                }
            } catch (Exception ignored) {
                // fall through to the raw text
            }
            return clip(b, 200);
        }
        return describe(b);
    }

    static String describe(String text) {
        if (text.startsWith("<")) {
            Matcher t = Pattern.compile("(?is)<title[^>]*>(.*?)</title>").matcher(text);
            return t.find() && !t.group(1).isBlank() ? "a web page (\"" + clip(t.group(1).replaceAll("\\s+", " "), 100) + "\")" : "a web page";
        }
        return "\"" + clip(text.replaceAll("\\s+", " "), 160) + "\"";
    }

    ModelException httpError(String role, Address a, Reply r) {
        int code = r.status();
        String key = key(role);
        String said = redact(serverMessage(r.body()), key);
        String lower = said.toLowerCase(Locale.ROOT);
        String reason = "The model server answered HTTP " + code + (said.isBlank() ? "" : ": " + said);
        String hint;
        if (code >= 300 && code < 400) {
            String to = redact(r.headers().firstValue("Location").orElse(""), key);
            reason = "The address redirects (HTTP " + code + ")" + (to.isBlank() ? "" : " to " + clip(to, 200));
            String newBase = to.isBlank() ? "" : Address.of(to).base();
            boolean onlyScheme = !newBase.isBlank() && newBase.replaceFirst("^https://", "http://").equals(a.base().replaceFirst("^https://", "http://"));
            hint = onlyScheme ? "Use https:// in the API base URL"
                    : newBase.startsWith("http") ? "If that address is right, enter " + clip(newBase, 200) + " as the API base URL. Guardian does not follow redirects, so the key is never sent to another address"
                    : "Enter the address it redirects to as the API base URL. Guardian does not follow redirects, so the key is never sent to another address";
        } else if (code == 401) {
            hint = key.isBlank()
                    ? "No API key is set for the " + label(role) + " role. Each role has its own key. Keys are kept in memory only, so after a restart enter the key again (or set GUARDIAN_"
                            + role.toUpperCase(Locale.ROOT) + "_API_KEY)"
                    : "The server did not accept the key. Check that it is the key for this server and has not expired"
                            + (a.azure() ? "" : ". If the server expects the key in another header (for example api-key or x-api-key), set 'Key header'");
        } else if (code == 403) {
            hint = "Access was denied. The key may not have access to this model, or a company gateway or firewall blocked the request";
        } else if (code == 404) {
            if (lower.contains("model") || lower.contains("deployment"))
                hint = a.azure()
                        ? "On Azure OpenAI the deployment name (not the model name) goes in the address; check it"
                        : "Check the exact model ID; 'Discover models' lists the IDs this server offers (Ollama: run 'ollama pull <model>' first)";
            else if (a.azure() && !a.deployment().isBlank() && !a.query().toLowerCase(Locale.ROOT).contains("api-version"))
                hint = "Azure OpenAI deployment addresses need an API version, for example https://NAME.openai.azure.com/openai/deployments/DEPLOYMENT?api-version=2024-10-21, or use the https://NAME.openai.azure.com/openai/v1 address";
            else
                hint = "Nothing was found at " + clip(r.url(), 200) + ". The API base URL usually ends in /v1: https://api.openai.com/v1, http://localhost:11434/v1 (Ollama), http://localhost:1234/v1 (LM Studio)";
        } else if (code == 429) {
            hint = "Rate limit or quota reached. Wait a minute and test again, or check the account's usage limits and billing";
        } else if (code == 400 || code == 422) {
            if (lower.matches("(?s).*(image|vision|multimodal|multi-modal).*"))
                hint = "This model does not accept images. Choose a vision-capable model for the Vision role, or leave the Vision role empty";
            else if (lower.contains("model") && lower.matches("(?s).*(not found|does not exist|unknown|invalid model|no such).*"))
                hint = "Check the exact model ID; 'Discover models' lists the IDs this server offers";
            else if (lower.matches("(?s).*(max_tokens|max_completion_tokens|max_output_tokens).*"))
                hint = "Lower 'Maximum response tokens' for this role";
            else if (lower.matches("(?s).*(context length|context_length|too long|maximum context|too many tokens).*"))
                hint = "The request is too long for this model's context window. Choose a model with a larger context";
            else
                hint = "The server rejected the request. Check the exact model ID and that the address is an OpenAI-compatible chat-completions API";
        } else if (code == 405) {
            hint = "This address does not accept chat requests. Check the API base URL (usually ending in /v1)";
        } else if (code == 413) {
            hint = "The request was too large for the server or a gateway in between (Vision requests carry two screenshots)";
        } else if (code == 408 || code == 504) {
            hint = "A gateway timed out waiting for the model. Raise 'Timeout seconds', or try again once the model has loaded";
        } else if (code == 502 || code == 503) {
            hint = "A gateway could not reach the model, or the model is still loading or overloaded. Try again in a minute";
        } else if (code >= 500) {
            hint = "The model server reported an internal error. Try again; if it persists, check the server's own logs";
        } else {
            hint = "";
        }
        return new ModelException(reason, hint, code, said);
    }

    static String redact(String text, String key) {
        String t = text == null ? "" : text;
        if (key.length() >= 6) t = t.replace(key, "[redacted]");
        return t.replaceAll("(?i)(bearer |api[_-]?key[=:] ?|token[=:] ?)[^ ,;\"]+", "$1[redacted]");
    }

    static String firstNonBlank(String... values) {
        for (String v : values) if (v != null && !v.isBlank() && !v.equals("null")) return v;
        return "";
    }

    static String setting(String env, String property) {
        String v = System.getProperty(property);
        if (v == null || v.isBlank()) v = System.getenv(env);
        return v == null ? "" : v.strip();
    }

    // ---------------------------------------------------------------- network environment

    /**
     * Proxy choice for model servers. Servers on this computer (Ollama, LM Studio) are always reached directly.
     * Otherwise GUARDIAN_PROXY (host:port, or "none") wins; else Java's proxy settings, which Guardian points at
     * the operating system's proxy configuration when it starts (java.net.useSystemProxies).
     */
    static final class Proxies extends ProxySelector {
        final ProxySelector system = ProxySelector.getDefault();
        final String forced = setting("GUARDIAN_PROXY", "guardian.proxy");

        @Override
        public List<Proxy> select(URI uri) {
            String host = Objects.toString(uri.getHost(), "").toLowerCase(Locale.ROOT);
            if (local(host) || forced.equalsIgnoreCase("none") || forced.equalsIgnoreCase("direct")) return List.of(Proxy.NO_PROXY);
            if (!forced.isBlank()) {
                try {
                    URI p = URI.create(forced.contains("://") ? forced : "http://" + forced);
                    if (p.getHost() != null)
                        return List.of(new Proxy(Proxy.Type.HTTP, InetSocketAddress.createUnresolved(p.getHost(), p.getPort() < 0 ? 8080 : p.getPort())));
                } catch (IllegalArgumentException ignored) {
                    // an unusable GUARDIAN_PROXY falls back to the system settings
                }
            }
            return system == null ? List.of(Proxy.NO_PROXY) : system.select(uri);
        }

        @Override
        public void connectFailed(URI uri, SocketAddress sa, IOException e) {
            if (system != null) system.connectFailed(uri, sa, e);
        }

        static boolean local(String h) {
            return h.equals("localhost") || h.endsWith(".localhost") || h.startsWith("127.") || h.equals("::1") || h.equals("[::1]");
        }
    }

    /**
     * Trusts the certificate authorities Java ships with, plus the operating system's own store (Windows certificate
     * store, macOS keychain) and extra certificates from GUARDIAN_CA_FILE. Company networks that inspect HTTPS re-sign
     * traffic with a company root that is usually in the Windows store but not in Java's, which makes Java alone fail
     * with "PKIX path building failed". Every store still checks the host name; nothing is trusted blindly.
     */
    static final class Trust extends X509ExtendedTrustManager {
        static volatile String warning = "";
        final List<X509ExtendedTrustManager> stores;

        Trust(List<X509ExtendedTrustManager> stores) {
            this.stores = stores;
        }

        static SSLContext context() {
            try {
                var stores = new ArrayList<X509ExtendedTrustManager>();
                add(stores, null);
                for (String type : List.of("Windows-ROOT", "KeychainStore")) {
                    try {
                        KeyStore ks = KeyStore.getInstance(type);
                        ks.load(null, null);
                        add(stores, ks);
                    } catch (Exception ignored) {
                        // not available on this operating system
                    }
                }
                String files = setting("GUARDIAN_CA_FILE", "guardian.caFile");
                if (!files.isBlank()) {
                    try {
                        KeyStore ks = KeyStore.getInstance(KeyStore.getDefaultType());
                        ks.load(null, null);
                        int n = 0;
                        for (String f : files.split(File.pathSeparator)) {
                            if (f.isBlank()) continue;
                            try (var in = Files.newInputStream(Path.of(f.strip()))) {
                                for (Certificate c : CertificateFactory.getInstance("X.509").generateCertificates(in))
                                    ks.setCertificateEntry("guardian-extra-" + n++, c);
                            }
                        }
                        if (n == 0) throw new IOException("no certificates found");
                        add(stores, ks);
                    } catch (Exception e) {
                        warning = " (GUARDIAN_CA_FILE could not be used: " + clip(Objects.toString(e.getMessage(), e.getClass().getSimpleName()), 120) + ")";
                        System.err.println("Guardian: GUARDIAN_CA_FILE could not be used: " + e);
                    }
                }
                SSLContext ctx = SSLContext.getInstance("TLS");
                ctx.init(null, new TrustManager[]{new Trust(stores)}, null);
                return ctx;
            } catch (Exception e) {
                try {
                    return SSLContext.getDefault();
                } catch (Exception again) {
                    throw new IllegalStateException(again);
                }
            }
        }

        static void add(List<X509ExtendedTrustManager> stores, KeyStore ks) throws Exception {
            var tmf = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
            tmf.init(ks);
            for (TrustManager tm : tmf.getTrustManagers()) if (tm instanceof X509ExtendedTrustManager x) stores.add(x);
        }

        interface Check {
            void run(X509ExtendedTrustManager tm) throws CertificateException;
        }

        /** Accepts when any store accepts. On rejection, reports the most specific reason: "issued for another host name"
         *  from the store that knows the issuer is more useful than "unknown issuer" from the stores that do not. */
        void any(Check check) throws CertificateException {
            CertificateException best = null;
            for (var tm : stores) {
                try {
                    check.run(tm);
                    return;
                } catch (CertificateException e) {
                    if (best == null || unknownIssuer(best) && !unknownIssuer(e)) best = e;
                }
            }
            throw best != null ? best : new CertificateException("No certificate store is available");
        }

        static boolean unknownIssuer(CertificateException e) {
            for (Throwable t = e; t != null; t = t.getCause()) {
                String m = Objects.toString(t.getMessage(), "");
                if (m.contains("PKIX") || m.contains("certification path")) return true;
            }
            return false;
        }

        @Override
        public void checkServerTrusted(X509Certificate[] chain, String auth, SSLEngine engine) throws CertificateException {
            any(tm -> tm.checkServerTrusted(chain, auth, engine));
        }

        @Override
        public void checkServerTrusted(X509Certificate[] chain, String auth, Socket socket) throws CertificateException {
            any(tm -> tm.checkServerTrusted(chain, auth, socket));
        }

        @Override
        public void checkServerTrusted(X509Certificate[] chain, String auth) throws CertificateException {
            any(tm -> tm.checkServerTrusted(chain, auth));
        }

        @Override
        public void checkClientTrusted(X509Certificate[] chain, String auth, SSLEngine engine) throws CertificateException {
            any(tm -> tm.checkClientTrusted(chain, auth, engine));
        }

        @Override
        public void checkClientTrusted(X509Certificate[] chain, String auth, Socket socket) throws CertificateException {
            any(tm -> tm.checkClientTrusted(chain, auth, socket));
        }

        @Override
        public void checkClientTrusted(X509Certificate[] chain, String auth) throws CertificateException {
            any(tm -> tm.checkClientTrusted(chain, auth));
        }

        @Override
        public X509Certificate[] getAcceptedIssuers() {
            return stores.stream().flatMap(tm -> Arrays.stream(tm.getAcceptedIssuers())).toArray(X509Certificate[]::new);
        }
    }
}
