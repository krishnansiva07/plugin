package guardian;

import java.net.URI;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.regex.Pattern;

import static guardian.Json.*;
import static guardian.Util.*;

/**
 * The "Pages to skip" setting. One rule per line; matching ignores case:
 * <pre>
 *   /admin               a path: that page and everything below it (/admin/users), but not /administrator
 *   /orders/&#42;/delete      &#42; matches anything
 *   #/settings           a single-page-app route after #
 *   https://host/path    a full address and everything below it
 *   logout               any other text: addresses that contain it
 *   title: Audit log     pages whose title contains the text
 *   label: Delete        links and buttons whose text contains it
 * </pre>
 * Capture never clicks a matching link or labelled control and never records or explores a matching page.
 * Comparison runs mark baseline pages that match as EXCLUDED instead of opening them. Both are listed in the
 * report as "Skipped by suite setting: rule" and need no coverage review, because the user asked for them.
 */
final class Skips {
    static final String REASON = "Skipped by suite setting";
    static final int MAX_RULES = 200, MAX_RULE_LENGTH = 300;

    record Rule(String kind, String text, Pattern pattern) {}

    final List<Rule> rules;

    Skips(Object setting) {
        var out = new ArrayList<Rule>();
        for (String line : strings(setting)) {
            String t = line.strip();
            if (!t.isEmpty() && out.size() < MAX_RULES) out.add(parse(clip(t, MAX_RULE_LENGTH)));
        }
        rules = List.copyOf(out);
    }

    static Skips of(Map<String, Object> cfg) {
        return new Skips(cfg.get("skipPages"));
    }

    boolean isEmpty() {
        return rules.isEmpty();
    }

    static String reason(String rule) {
        return REASON + ": " + rule;
    }

    static boolean isSettingSkip(Map<String, Object> x) {
        return s(x, "reason").startsWith(REASON);
    }

    // ---------------------------------------------------------------- matching

    /** The rule that skips this page (by address or title), or "". */
    String page(String address, String title) {
        String rule = url(address);
        return rule.isEmpty() ? match("title", title) : rule;
    }

    /** The rule that skips this link or control (by its text or its link address), or "". */
    String control(String label, String address) {
        String rule = match("label", label);
        return rule.isEmpty() && !address.isBlank() ? url(address) : rule;
    }

    /** The rule that skips a recorded click path: any step whose control is skipped. */
    String path(List<Object> actions, String origin) {
        for (Object o : actions) {
            var a = map(o);
            String href = s(a, "href");
            String rule = control(s(a, "label"), href.isBlank() ? "" : origin + href);
            if (!rule.isEmpty()) return rule;
        }
        return "";
    }

    String url(String address) {
        if (address == null || address.isBlank()) return "";
        String full = address, local = address;
        try {
            URI u = URI.create(address);
            if (u.getScheme() != null)
                local = Objects.toString(u.getRawPath(), "") + (u.getRawQuery() == null ? "" : "?" + u.getRawQuery())
                        + (u.getRawFragment() == null ? "" : "#" + u.getRawFragment());
        } catch (IllegalArgumentException ignored) {
            // match the text as given
        }
        for (Rule r : rules) {
            String target = switch (r.kind()) {
                case "path", "route" -> local;
                case "address", "contains" -> full;
                default -> null;
            };
            if (target != null && (r.pattern().matcher(target).find() || r.pattern().matcher(decode(target)).find())) return r.text();
        }
        return "";
    }

    String match(String kind, String text) {
        if (text == null || text.isBlank()) return "";
        for (Rule r : rules) if (r.kind().equals(kind) && r.pattern().matcher(text).find()) return r.text();
        return "";
    }

    // ---------------------------------------------------------------- parsing

    static final int FLAGS = Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE;
    /** A path rule ends at a path boundary: "/admin" covers "/admin/users" and "/admin?tab=1" but not "/administrator". */
    static final String END = "(?=$|[/?#&;])";

    static Rule parse(String line) {
        String lower = line.toLowerCase(Locale.ROOT);
        for (String kind : List.of("title", "label")) {
            if (lower.startsWith(kind + ":")) {
                String v = line.substring(kind.length() + 1).strip();
                return new Rule(kind, line, Pattern.compile(glob(v), FLAGS));
            }
        }
        String v = lower.startsWith("url:") ? line.substring(4).strip() : line;
        if (v.matches("(?i)https?://.*")) return new Rule("address", line, Pattern.compile("^" + glob(v.replaceAll("/+$", "")) + END, FLAGS));
        if (v.startsWith("/")) return new Rule("path", line, Pattern.compile(glob(v.length() > 1 ? v.replaceAll("/+$", "") : v) + END, FLAGS));
        if (v.startsWith("#")) return new Rule("route", line, Pattern.compile(glob(v) + END, FLAGS));
        return new Rule("contains", line, Pattern.compile(glob(v), FLAGS));
    }

    /** Literal text where each * matches anything. */
    static String glob(String text) {
        return String.join(".*", Arrays.stream(text.split("\\*", -1)).map(p -> p.isEmpty() ? "" : Pattern.quote(p)).toList());
    }

    static String decode(String s) {
        try {
            return URLDecoder.decode(s.replace("+", "%2B"), StandardCharsets.UTF_8);
        } catch (IllegalArgumentException e) {
            return s;
        }
    }
}
