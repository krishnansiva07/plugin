@echo off
setlocal
cd /d "%~dp0"
where java >nul 2>nul || (echo Java 17 or newer is required. & pause & exit /b 1)
echo Open http://127.0.0.1:8765 in your browser.
echo Keep this console open while executions are running.
java -jar visual-guardian.jar %*
if errorlevel 1 pause
