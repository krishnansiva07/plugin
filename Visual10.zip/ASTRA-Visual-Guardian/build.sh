#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")"
mkdir -p build/classes
find src -name '*.java' > build/sources.txt
javac --release 17 -encoding UTF-8 -d build/classes @build/sources.txt
cp resources/* build/classes/
jar --create --file build/visual-guardian.jar --main-class guardian.Main -C build/classes .
if command -v node >/dev/null 2>&1; then node --check resources/app.js; fi
printf 'Built build/visual-guardian.jar\n'
