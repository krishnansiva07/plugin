package guardian;
import java.nio.file.*;import java.util.*;import static guardian.Json.*;import static guardian.Util.*;
final class CheckpointChecks {
 static void check(String n,boolean b){if(!b)throw new AssertionError(n);System.out.println("PASS "+n);}
 static Map<String,Object> action(String label,String css){return obj("action","CLICK","label",label,"css",css,"role","button");}
 public static void main(String[] args)throws Exception{
  var a=action("View 123","#a");var b=action("View 456","#a");var c=action("Filter","#filter");var first=new ArrayList<Object>(List.of(a));var next=new ArrayList<Object>(List.of(a,c));var other=new ArrayList<Object>(List.of(b));
  check("exact numeric identities remain distinct",!Engine.pathKey(first).equals(Engine.pathKey(other)));check("shared prefix validated",Engine.prefix(first,next)&&!Engine.prefix(other,next)&&Engine.sharedPrefix(first,next)==1);
  var r=obj("states",new ArrayList<>(List.of(obj("path",first))),"queue",new ArrayList<>(List.of(obj("path",first),obj("path",next),obj("path",next),obj("path",other))),"issues",new ArrayList<>());
  Engine.recordPath(r,first,"CAPTURED","state-1");Engine.recordPath(r,next,"IN_PROGRESS","");Engine.recordPath(r,other,"FAILED","timeout");Engine.dedupPending(r);check("completed and duplicated queue entries removed, pending and failed retained",list(r.get("queue")).size()==2);
  Engine.addIssue(r,other,"timeout");Engine.addIssue(r,other,"retry failed");check("unresolved issue counted once",list(r.get("issues")).size()==1);Engine.clearIssue(r,other);check("successful retry clears prior issue",list(r.get("issues")).isEmpty());
  Path dir=Files.createTempDirectory("guardian-checkpoint-test");try{Path p=dir.resolve("run.json");save(p,r);var stored=load(p);check("journal survives disk reload",s(map(Engine.journal(stored).get(Engine.pathKey(first))),"status").equals("CAPTURED"));Engine.recordPath(stored,next,"CAPTURED","state-2");Engine.dedupPending(stored);check("resumed queue skips newly completed work",list(stored.get("queue")).size()==1);
   // A directory at the replacement target forces a filesystem exception on Linux.
   Path blocked=dir.resolve("blocked.json");Files.createDirectory(blocked);Files.writeString(blocked.resolve("lock"),"held");var unlock=new Thread(()->{try{Thread.sleep(350);Files.delete(blocked.resolve("lock"));Files.delete(blocked);}catch(Exception ex){throw new RuntimeException(ex);}});unlock.start();save(blocked,obj("ok",true));unlock.join();check("transient replacement failure retried successfully",b(load(blocked),"ok"));
  }finally{removeTree(dir);}
 }
}
