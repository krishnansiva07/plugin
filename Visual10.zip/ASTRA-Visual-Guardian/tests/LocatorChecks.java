package guardian;
import java.util.*;
import static guardian.Json.*;
final class LocatorChecks {
 static Map<String,Object> e(String label,String css,String id){return obj("tag","button","role","button","label",label,"css",css,"id",id,"type","","target","","form",false,"disabled",false,"href","","action","CLICK");}
 static Map<String,Object> dom(Object... e){return obj("elements",List.of(e));}
 static void check(String n,boolean b){if(!b)throw new AssertionError(n);System.out.println("PASS "+n);}
 public static void main(String[] args)throws Exception{
  var cfg=Store.config(obj());var old=e("Filter","//*[broken", "");var fresh=e("Filter","#filter-new", "new");
  check("invalid stored selector recovered from current DOM",Engine.match(old,dom(fresh),cfg).get("css").equals("#filter-new"));
  check("changed locator with stable identity",Engine.match(e("Filter","#old","same"),dom(e("Filter","#new","same"),e("Filter","#other","other")),cfg).get("css").equals("#new"));
  try{Engine.match(old,dom(fresh,e("Filter","#other","other")),cfg);throw new AssertionError("ambiguous accepted");}catch(Engine.Missing ex){check("ambiguous locator rejected",ex.ambiguous);}
  try{Engine.match(e("View 123","#old",""),dom(e("View 456","#new","")),cfg);throw new AssertionError("different record accepted");}catch(Engine.Missing ex){check("numeric identity mismatch rejected",!ex.ambiguous);}
  try{Engine.match(old,dom(e("Delete record","#filter-new","new")),cfg);throw new AssertionError("dangerous accepted");}catch(Engine.Missing ex){check("dangerous action excluded",true);}
  check("timeout configuration defaults",num(cfg.get("authSeconds"),0)==1800&&num(cfg.get("pageSeconds"),0)==60&&num(cfg.get("locatorSeconds"),0)==15);
  java.nio.file.Files.writeString(java.nio.file.Path.of(args[0]),Browser.actionScript(old));
 }
}
