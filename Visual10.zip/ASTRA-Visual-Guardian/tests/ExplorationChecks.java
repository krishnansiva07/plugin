package guardian;

import java.util.*;
import static guardian.Json.*;

/**
 * The rules that keep exploration from opening the same page again (CHANGES.md, item 9).
 * Usage: java -cp classes:test-classes guardian.ExplorationChecks
 */
public class ExplorationChecks {
    static int passed = 0;

    static void check(String name, boolean ok) {
        if (!ok) throw new AssertionError(name);
        passed++;
        System.out.println("PASS " + name);
    }

    static Map<String, Object> link(String label, String href) {
        return obj("role", "a", "tag", "a", "label", label, "href", href, "navigates", true, "css", "main > a:nth-of-type(1)", "region", "");
    }

    static Map<String, Object> button(String label, String css, String region) {
        return obj("role", "button", "tag", "button", "label", label, "href", "", "navigates", false, "css", css, "region", region);
    }

    public static void main(String[] args) {
        var run = obj("states", new ArrayList<>(List.of(obj("id", "home", "route", "/", "path", List.of()))));
        var ex = Exploration.of(run);
        check("the home page counts as explored", "explored".equals(ex.targets.get("/")));
        check("a link to the page Guardian is on is not opened", ex.skip(link("Invoices", "/invoices"), "/invoices", obj(), true).equals("link to the same page"));
        check("an in-page anchor is the same page", ex.skip(link("Top", "/invoices#top"), "/invoices", obj(), true).equals("link to the same page"));
        check("a link to an explored page is not opened", ex.skip(link("Home", "/"), "/invoices", obj(), true).equals("page already explored"));

        var first = obj("parent", "home");
        check("the first link to a new page is queued and reserves it", ex.skip(link("Reports", "/reports"), "/", first, true).isEmpty() && s(first, "target").equals("/reports"));
        check("a second link to that page waits for the first", ex.skip(link("Latest report", "/reports"), "/invoices", obj(), true).equals("page already waiting to be explored"));
        check("a #/ route is its own page", ex.skip(link("Settings", "/app#/settings"), "/app#/home", obj(), true).isEmpty());
        check("\"#\" and javascript: links are treated as buttons, not as pages",
                Exploration.target(obj("href", "/app", "navigates", false)).isEmpty() && Exploration.target(link("x", "/a")).equals("/a"));
        check("a reserved page is no longer stale-checked as explored before it is visited", ex.stale(first).isEmpty());
        ex.landed(first, "home", "/", "/reports", "reports");
        check("after landing, the page is explored", "explored".equals(ex.targets.get("/reports")));
        var viaButton = obj("parent", "home", "target", "/help");
        ex.targets.put("/help", "explored");
        check("a waiting link whose page was reached another way is dropped just before clicking", ex.stale(viaButton).equals("page already explored"));

        var bell = obj("parent", "home");
        check("a shared header control is queued the first time", ex.skip(button("Notifications", "header > button", "header"), "/", bell, true).isEmpty());
        check("the same header control is not explored again from another page", ex.skip(button("Notifications", "header > button", "header"), "/invoices", obj(), true).startsWith("shared header control"));
        check("a counter in the label does not make it a different control", ex.skip(button("Notifications (3)", "header > button", "header"), "/reports", obj(), true).startsWith("shared header control"));
        check("controls in page content are not shared", ex.skip(button("Notifications", "main > button", ""), "/invoices", obj(), true).isEmpty());

        var help1 = obj("parent", "invoices");
        ex.skip(button("Help center", "div.toolbar > button", ""), "/invoices", help1, true);
        ex.landed(help1, "invoices", "/invoices", "/help", "help");
        check("one observation does not make a control shared", ex.skip(button("Help center", "div.toolbar > button", ""), "/customers", obj(), true).isEmpty());
        var help2 = obj("parent", "help");
        ex.skip(button("Help center", "div.toolbar > button", ""), "/help", help2, true);
        ex.landed(help2, "help", "/help", "/help", "help");
        check("a control that led to the same page from two pages is shared and skipped", ex.skip(button("Help center", "div.toolbar > button", ""), "/reports", obj(), true).equals("leads to the same page from every page"));
        check("a queued copy of it is dropped just before clicking", ex.stale(obj("signature", Exploration.signature(button("Help center", "div.toolbar > button", "")))).equals("leads to the same page from every page"));

        var d1 = obj("parent", "a");
        ex.skip(button("Details", "main > section > button", ""), "/a", d1, true);
        ex.landed(d1, "a", "/a", "/a/details", "ad");
        var d2 = obj("parent", "b");
        ex.skip(button("Details", "main > section > button", ""), "/b", d2, true);
        ex.landed(d2, "b", "/b", "/b/details", "bd");
        check("a control that leads to different pages is never treated as shared", ex.skip(button("Details", "main > section > button", ""), "/c", obj(), true).isEmpty());

        var open = button("Filters", "main > button", "");
        open.put("expanded", "true");
        check("an already open drop-down or panel is not clicked", ex.skip(open, "/invoices", obj(), true).equals("already open"));
        var tab = obj("role", "tab", "label", "Monthly", "selected", "true", "css", "x");
        check("an already selected tab is not clicked", ex.skip(tab, "/reports", obj(), true).equals("tab already selected"));

        var failed = obj("parent", "home");
        ex.skip(link("Archive", "/archive"), "/", failed, true);
        ex.release(failed);
        check("after an error the reservation is released, so another link may try", ex.skip(link("Archive", "/archive"), "/x", obj(), true).isEmpty());
        var blocked = obj("parent", "home");
        ex.skip(link("Admin", "/admin"), "/", blocked, true);
        ex.setAside(blocked);
        check("a page that was blocked or kept asking for sign-in is not tried again", ex.skip(link("Admin", "/admin"), "/x", obj(), true).equals("page already set aside"));
        check("without claim, nothing is reserved (used at the depth limit)", ex.skip(link("Deep", "/deep"), "/", obj(), false).isEmpty() && !ex.targets.containsKey("/deep"));

        var old = obj("states", List.of(obj("id", "h", "route", "/", "path", List.of()), obj("id", "o", "route", "/orders", "path", List.of(obj("label", "Orders")), "arrived", true)));
        check("an older run without a record is rebuilt from its captured pages", "explored".equals(Exploration.of(old).targets.get("/orders")));
        check("Store.config keeps the exploration order (page by page unless level by level is chosen)",
                Store.config(obj()).get("explorationOrder").equals("depth") && Store.config(obj("explorationOrder", "breadth")).get("explorationOrder").equals("breadth")
                        && Store.config(obj("explorationOrder", "x")).get("explorationOrder").equals("depth"));
        System.out.println("TOTAL " + passed + " exploration-rule checks passed");
    }
}
