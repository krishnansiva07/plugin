#!/usr/bin/env python3
"""
Real-browser test for organized, page-by-page exploration without repeated navigation (CHANGES.md, item 9).

Usage:  GUARDIAN_TEST_BROWSER=/path/to/chrome python tests/organized_exploration.py visual-guardian.jar [--report]
  --report  only print what happened (no assertions); use it to compare versions.

The fixture is a small invoicing portal built the way most business apps are: every page repeats the same header
menu (Home, Invoices, Customers, Reports), a Notifications button in the header that opens a drop-down, a toolbar
button "Help center" (plain JavaScript, no link) and a footer link "Help". Lists lead to detail pages, detail pages
link back to their list and across to related records. A session clock in the header changes every second.

Checks:
  * every page is captured once, and the capture order is page by page: after a page is opened, everything under it
    is finished before Guardian goes back up and continues with the next control of the page it came from;
  * links to pages that were already explored (or are already waiting) are not opened again, and the header
    drop-down is explored once, not once per page;
  * Guardian goes back to the previous page instead of restarting from the home page for every path;
  * a comparison run against the baseline still passes.
"""
import collections, json, os, re, socket, subprocess, sys, tempfile, threading, time, urllib.error, urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

JAR = Path(sys.argv[1]).resolve()
REPORT = '--report' in sys.argv
BROWSER = os.environ.get('GUARDIAN_TEST_BROWSER', '/usr/bin/google-chrome')
passed = []
loads = []          # document requests in order
lock = threading.Lock()


def check(name, ok, detail=''):
    if REPORT:
        return
    if not ok:
        raise AssertionError(f'{name} -- {detail}')
    passed.append(name)
    print('PASS', name, flush=True)


HEADER = ('<header><nav><a href="/">Home</a> | <a href="/invoices">Invoices</a> | <a href="/customers">Customers</a> | '
          '<a href="/reports">Reports</a></nav> <span>Session expires in <b id="clock">15:00</b></span> '
          '<button type="button" id="bell" aria-expanded="false" onclick="toggleBell()">Notifications</button>'
          '<div id="drop" hidden><a href="/notifications">All notifications</a></div></header>'
          '<div class="toolbar"><button type="button" onclick="location.href=\'/help\'">Help center</button></div>')
FOOTER = '<footer><a href="/help">Help</a></footer>'
SCRIPT = ('<script>let t=900;setInterval(()=>{t--;document.getElementById("clock").textContent='
          'String(Math.floor(t/60)).padStart(2,"0")+":"+String(t%60).padStart(2,"0")},1000);'
          'function toggleBell(){const d=document.getElementById("drop"),b=document.getElementById("bell");'
          'd.hidden=!d.hidden;b.setAttribute("aria-expanded",String(!d.hidden))}'
          'function showFilters(){const p=document.getElementById("filters"),b=document.getElementById("fbtn");'
          'p.hidden=!p.hidden;b.setAttribute("aria-expanded",String(!p.hidden))}'
          'function tab(n){for(const x of ["Monthly","Yearly"]){document.getElementById("t"+x).setAttribute("aria-selected",String(x===n));'
          'document.getElementById("p"+x).hidden=x!==n}}</script>')
PAGES = {
    '/': ('Home', '<h1>Home</h1><p>Welcome back.</p><p><a href="/reports">Latest report</a></p>'),
    '/invoices': ('Invoices', '<h1>Invoices</h1><button type="button" id="fbtn" aria-expanded="false" onclick="showFilters()">Show filters</button>'
                              '<div id="filters" hidden><a href="/invoices/guide">Invoice guide</a> <a href="/invoices/overdue">Overdue invoices</a></div>'
                              '<ul><li><a href="/invoices/7">Invoice 7</a></li><li><a href="/invoices/8">Invoice 8</a></li></ul>'),
    '/invoices/7': ('Invoice 7', '<h1>Invoice 7</h1><p>Two lines, paid.</p><a href="/invoices">Back to invoices</a> <a href="/customers/a">Customer A</a>'),
    '/invoices/8': ('Invoice 8', '<h1>Invoice 8</h1><p>One line, open.</p><a href="/invoices">Back to invoices</a> <a href="/customers/b">Customer B</a>'),
    '/invoices/guide': ('Invoice guide', '<h1>Invoice guide</h1><p>How invoices are numbered.</p>'),
    '/invoices/overdue': ('Overdue invoices', '<h1>Overdue invoices</h1><p>None overdue.</p>'),
    '/customers': ('Customers', '<h1>Customers</h1><ul><li><a href="/customers/a">Customer A</a></li><li><a href="/customers/b">Customer B</a></li></ul>'),
    '/customers/a': ('Customer A', '<h1>Customer A</h1><p>Since 2019.</p><a href="/customers">Back to customers</a> <a href="/invoices/7">Invoice 7</a>'),
    '/customers/b': ('Customer B', '<h1>Customer B</h1><p>Since 2021.</p><a href="/customers">Back to customers</a> <a href="/invoices/8">Invoice 8</a>'),
    '/reports': ('Reports', '<h1>Reports</h1><div role="tablist"><button role="tab" id="tMonthly" aria-selected="true" onclick="tab(\'Monthly\')">Monthly</button>'
                            '<button role="tab" id="tYearly" aria-selected="false" onclick="tab(\'Yearly\')">Yearly</button></div>'
                            '<section id="pMonthly"><p>Monthly totals.</p></section><section id="pYearly" hidden><p>Yearly totals.</p><a href="/reports/archive">Yearly archive</a></section>'),
    '/reports/archive': ('Yearly archive', '<h1>Yearly archive</h1><p>2019 to 2025.</p>'),
    '/help': ('Help', '<h1>Help</h1><p>Contact the service desk.</p>'),
    '/notifications': ('Notifications', '<h1>Notifications</h1><p>No new notifications.</p>'),
}


SPA = """<!doctype html><html><head><title>Banking</title></head><body style="font:15px Arial;margin:16px">
<header><nav><a href="#/home">Overview</a> | <a href="#/accounts">Accounts</a> | <a href="#/statements">Statements</a> | <a href="#/settings">Settings</a></nav></header>
<main id="view"></main>
<script>
const views={
 '/home':['Overview','<h1>Overview</h1><p>Three accounts.</p><a href="#/statements">Latest statements</a>'],
 '/accounts':['Accounts','<h1>Accounts</h1><button type="button" onclick="openSummary()">Show summary</button><ul><li><a href="#/accounts/1">Account 1</a></li><li><a href="#/accounts/2">Account 2</a></li></ul><div id="dlg"></div>'],
 '/accounts/1':['Account 1','<h1>Account 1</h1><p>Current account.</p><a href="#/accounts">Back to accounts</a>'],
 '/accounts/2':['Account 2','<h1>Account 2</h1><p>Savings account.</p><a href="#/accounts">Back to accounts</a>'],
 '/statements':['Statements','<h1>Statements</h1><div role="tablist"><button role="tab" id="tA" aria-selected="true" onclick="pick(true)">This year</button><button role="tab" id="tB" aria-selected="false" onclick="pick(false)">Last year</button></div><p id="sv">This year: 12 statements.</p>'],
 '/settings':['Settings','<h1>Settings</h1><p>Language: English.</p>']};
function render(){const r=(location.hash||'#/home').slice(1);const v=views[r]||views['/home'];document.title='Banking - '+v[0];document.getElementById('view').innerHTML=v[1]}
function openSummary(){document.getElementById('dlg').innerHTML='<div role="dialog" aria-label="Summary"><h2>Summary</h2><p>Total balance.</p><a href="#/statements">Statements for all accounts</a></div>'}
function pick(a){document.getElementById('tA').setAttribute('aria-selected',String(a));document.getElementById('tB').setAttribute('aria-selected',String(!a));document.getElementById('sv').textContent=a?'This year: 12 statements.':'Last year: 12 statements.'}
window.addEventListener('hashchange',render);render();
</script></body></html>"""


class App(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass

    def do_GET(self):
        path = self.path.split('?')[0]
        if path == '/spa':
            with lock:
                loads.append(path)
            data = SPA.encode()
            self.send_response(200)
            self.send_header('Content-Type', 'text/html; charset=utf-8')
            self.send_header('Cache-Control', 'no-store')
            self.send_header('Content-Length', str(len(data)))
            self.end_headers()
            self.wfile.write(data)
            return
        if path == '/favicon.ico':
            self.send_response(404); self.end_headers(); return
        if path not in PAGES:
            self.send_response(404); self.end_headers(); return
        with lock:
            loads.append(path)
        title, body = PAGES[path]
        data = (f'<!doctype html><html><head><title>{title}</title></head><body style="font:15px Arial;margin:16px">'
                f'{HEADER}<main>{body}</main>{FOOTER}{SCRIPT}</body></html>').encode()
        self.send_response(200)
        self.send_header('Content-Type', 'text/html; charset=utf-8')
        self.send_header('Cache-Control', 'no-store')
        self.send_header('Content-Length', str(len(data)))
        self.end_headers()
        self.wfile.write(data)


app = ThreadingHTTPServer(('127.0.0.1', 0), App)
threading.Thread(target=app.serve_forever, daemon=True).start()
URL = f'http://127.0.0.1:{app.server_port}/'

with tempfile.TemporaryDirectory() as td:
    sock = socket.socket(); sock.bind(('127.0.0.1', 0)); port = sock.getsockname()[1]; sock.close()
    base = f'http://127.0.0.1:{port}'
    env = dict(os.environ)
    if hasattr(os, 'geteuid') and os.geteuid() == 0:
        env['GUARDIAN_TEST_NO_SANDBOX'] = '1'
    log = (Path(td) / 'server.log').open('w')
    proc = subprocess.Popen(['java', '-jar', str(JAR), '--port', str(port), '--data', str(Path(td) / 'data')], stdout=log, stderr=subprocess.STDOUT, env=env)
    try:
        for _ in range(150):
            try:
                html = urllib.request.urlopen(base, timeout=1).read().decode(); break
            except Exception:
                time.sleep(.2)
        token = re.search('name="guardian-token" content="([^"]+)"', html).group(1)

        def call(path, body=None):
            req = urllib.request.Request(base + '/api/' + path, data=json.dumps(body).encode() if body is not None else None,
                                         headers={'X-Guardian-Token': token, 'Content-Type': 'application/json'})
            try:
                return json.loads(urllib.request.urlopen(req, timeout=60).read())
            except urllib.error.HTTPError as e:
                raise AssertionError(f'{path}: HTTP {e.code} {e.read()[:300]}')

        def wait(rid, timeout=900):
            end = time.time() + timeout
            while time.time() < end:
                r = call('runs/' + rid)
                if not r['active']:
                    return r
                time.sleep(.5)
            raise AssertionError('timeout')

        cfg = dict(browser=BROWSER, headless=True, autoAuth=True, captureConsent=True, width=1100, height=800, settleMs=150,
                   pageSeconds=20, locatorSeconds=4, maxDepth=6, maxStates=80, maxActions=400, masks=['#clock'])
        suite = call('suites', dict(name='Invoicing portal', url=URL, config=cfg))
        started = time.time()
        rid = call('runs', dict(suiteId=suite['id'], mode='CAPTURE', target=URL, config=cfg))['id']
        cap = wait(rid)
        seconds = time.time() - started
        capture_loads = list(loads)
        states = cap['states']
        journal = list((cap.get('actionJournal') or {}).values())
        statuses = collections.Counter(j.get('status') for j in journal)
        per_page = collections.Counter(capture_loads)
        by_id = {s['id']: s for s in states}

        def label(s):
            extra = []
            if s['route'] in ('/',) and any(e for e in [s.get('path')] if e and e[-1].get('label') == 'Notifications'):
                extra.append('drop-down open')
            last = s['path'][-1]['label'] if s.get('path') else 'start'
            return f"{s['title']} [{s['route']}] via {last!r}"

        print(f'CAPTURE {cap["status"]} in {seconds:.0f} s: {len(states)} states, {len(capture_loads)} page loads, '
              f'{cap.get("browserActions", 0)} clicks, {cap.get("homeNavigations", 0)} restarts from home, '
              f'{cap.get("backNavigations", 0)} back navigations, {cap.get("avoidedNavigations", 0)} navigations avoided', flush=True)
        print('   journal:', dict(statuses), flush=True)
        print('   loads per page:', dict(per_page.most_common()), flush=True)
        for s in states:
            depth = int(s.get('depth', len(s.get('path') or [])))
            print('   ' + '  ' * depth + label(s), flush=True)

        # ---- checks
        routes = collections.Counter(s['route'] for s in states)
        titles = [s['title'] for s in states]
        expected_pages = {'/', '/invoices', '/invoices/7', '/invoices/8', '/invoices/guide', '/invoices/overdue', '/customers',
                          '/customers/a', '/customers/b', '/reports', '/reports/archive', '/help', '/notifications'}
        check('every page of the portal is captured', set(routes) == expected_pages, str(sorted(set(routes) ^ expected_pages)))
        # Allowed variants on the same address: the header drop-down (once), the open filter panel, the Yearly tab.
        variants = {r: n for r, n in routes.items() if n > 1}
        check('each page is captured once; only real variants share an address (drop-down once, filters, Yearly tab)',
              variants == {'/': 2, '/invoices': 2, '/reports': 2}, str(variants))

        # Page by page: each state's parent must be on the current path (a depth-first pre-order).
        stack, ordered = [], True
        for s in states:
            parent = s.get('parentId', None)
            if parent is None:
                ordered = False
                break
            while stack and stack[-1] != parent:
                stack.pop()
            if parent and not stack:
                ordered = False
                break
            stack.append(s['id'])
        check('capture order is page by page (finish everything under a page, then go back to where it came from)', ordered,
              [(s['title'], s.get('parentId')) for s in states])
        check('pages reached from a page are listed under it (parent recorded)',
              all(s.get('parentId') == '' or s.get('parentId') in by_id for s in states))

        repeated = {p: n for p, n in per_page.items() if n > 3}
        check('no page is loaded again and again (at most 3 loads each, counting the way back)', not repeated, str(repeated))
        check('known pages are hardly ever opened again (at most 2 duplicate landings)', statuses.get('DUPLICATE', 0) <= 2, str(dict(statuses)))
        check('links to known pages are skipped before clicking', cap.get('avoidedNavigations', 0) >= 20, str(cap.get('avoidedNavigations')))
        filters = next((s for s in states if s.get('path') and s['path'][-1]['label'] == 'Show filters'), None)
        under_filters = sorted(s['title'] for s in states if filters and s.get('parentId') == filters['id'])
        check('both links inside the open filter panel are explored from it (Guardian reopens the panel to come back)',
              under_filters == ['Invoice guide', 'Overdue invoices'], str(under_filters))
        check('Guardian goes back instead of restarting from the home page', cap.get('homeNavigations', 0) <= 1 and cap.get('backNavigations', 0) >= 5,
              f"home {cap.get('homeNavigations')}, back {cap.get('backNavigations')}")
        check('the capture finishes without review items', cap['status'] == 'COMPLETED', f"{cap['status']} {[x['reason'] for x in cap['coverageExceptions'] if not x['reviewed']][:5]}")

        if not REPORT:
            call('approve', dict(id=rid))
            rep = wait(call('runs', dict(suiteId=suite['id'], mode='REPLAY', target=URL, referenceId=rid, config=dict(captureConsent=True)))['id'])
            results = collections.Counter(x['status'] for x in rep['results'])
            print('REPLAY', rep['status'], dict(results), rep['verdict'], flush=True)
            check('a comparison run against this baseline passes', rep['status'] == 'COMPLETED' and set(results) == {'PASSED'}, str(dict(results)))

        # ---- single-page application with #/ addresses
        loads.clear()
        spa_url = f'http://127.0.0.1:{app.server_port}/spa#/home'
        suite2 = call('suites', dict(name='Banking SPA', url=spa_url, config=cfg))
        cap2 = wait(call('runs', dict(suiteId=suite2['id'], mode='CAPTURE', target=spa_url, config=cfg))['id'])
        states2 = cap2['states']
        print(f'SPA CAPTURE {cap2["status"]}: {len(states2)} states, {len(loads)} document loads, {cap2.get("homeNavigations", 0)} starts from home, '
              f'{cap2.get("backNavigations", 0)} back navigations, {cap2.get("avoidedNavigations", 0)} navigations avoided', flush=True)
        for s in states2:
            print('   ' + '  ' * int(s.get('depth', 0)) + label(s), flush=True)
        routes2 = collections.Counter(s['route'] for s in states2)
        check('SPA: every #/ page is captured once (variants: the summary dialog, the Last year tab)',
              set(routes2) == {'/spa#/home', '/spa#/accounts', '/spa#/accounts/1', '/spa#/accounts/2', '/spa#/statements', '/spa#/settings'}
              and {r: n for r, n in routes2.items() if n > 1} == {'/spa#/accounts': 2, '/spa#/statements': 2}, str(dict(routes2)))
        stack, ordered = [], True
        for s in states2:
            parent = s.get('parentId')
            while stack and stack[-1] != parent:
                stack.pop()
            if parent and not stack:
                ordered = False
            stack.append(s['id'])
        check('SPA: capture order is page by page', ordered)
        check('SPA: Guardian goes back through the app\'s own history instead of reloading the app for every path',
              cap2.get('homeNavigations', 0) <= 1 and len(loads) <= 6, f"starts from home {cap2.get('homeNavigations')}, document loads {len(loads)}")
        check('SPA: the capture finishes without review items', cap2['status'] == 'COMPLETED', cap2['status'])
        if not REPORT:
            call('approve', dict(id=cap2['id']))
            rep2 = wait(call('runs', dict(suiteId=suite2['id'], mode='REPLAY', target=spa_url, referenceId=cap2['id'], config=dict(captureConsent=True)))['id'])
            results2 = collections.Counter(x['status'] for x in rep2['results'])
            check('SPA: a comparison run against this baseline passes', rep2['status'] == 'COMPLETED' and set(results2) == {'PASSED'}, str(dict(results2)))
            print('TOTAL', len(passed), 'organized-exploration checks passed', flush=True)
    finally:
        proc.terminate()
        try:
            proc.wait(timeout=15)
        except subprocess.TimeoutExpired:
            proc.kill()
        log.close()
        app.shutdown()
