#!/usr/bin/env python3
"""Focused interrupted-capture and legacy checkpoint regression; mock CDP only."""
import os,sys,json,tempfile,subprocess,socket,re,time,threading,urllib.request
from pathlib import Path
from http.server import ThreadingHTTPServer,BaseHTTPRequestHandler
ROOT=Path(__file__).resolve().parents[1]
class Site(BaseHTTPRequestHandler):
    def log_message(self,*a):pass
    def do_GET(self):
        content=('<html><title>Home</title><main><h1>Home</h1><a href="/details">Details</a><button id="filter">Filter</button><button id="view">View report</button></main></html>' if self.path=='/' else '<html><title>Details</title><main><h1>Details</h1><a href="/">Home</a></main></html>').encode();self.send_response(200);self.send_header('Content-Length',str(len(content)));self.end_headers();self.wfile.write(content)
site=ThreadingHTTPServer(('127.0.0.1',0),Site);threading.Thread(target=site.serve_forever,daemon=True).start();url='http://127.0.0.1:'+str(site.server_port)
with tempfile.TemporaryDirectory() as td:
    data=Path(td)/'data'; sock=socket.socket();sock.bind(('127.0.0.1',0));port=sock.getsockname()[1];sock.close();base='http://127.0.0.1:'+str(port);p=subprocess.Popen(['java','-jar',str(ROOT/'build/visual-guardian.jar'),'--port',str(port),'--data',str(data)],stdout=subprocess.DEVNULL)
    try:
        for _ in range(80):
            try:html=urllib.request.urlopen(base,timeout=1).read().decode();break
            except Exception:time.sleep(.2)
        token=re.search('name="guardian-token" content="([^"]+)"',html).group(1)
        def api(path,body=None):
            req=urllib.request.Request(base+'/api/'+path,data=json.dumps(body).encode() if body is not None else None,headers={'X-Guardian-Token':token,'Content-Type':'application/json'});return json.load(urllib.request.urlopen(req,timeout=20))
        def wait(id):
            for _ in range(300):
                r=api('runs/'+id)
                if not r['active']:return r
                time.sleep(.2)
            raise AssertionError('timeout')
        cfg=dict(browser=str(ROOT/'tests/mock_browser.py'),headless=True,captureConsent=True,autoAuth=True,maxStates=2,maxActions=50,maxDepth=1,settleMs=100,locatorSeconds=2,pageSeconds=10)
        suite=api('suites',dict(name='Checkpoint fixture',url=url,config=cfg));rid=api('runs',dict(suiteId=suite['id'],mode='CAPTURE',target=url,config=cfg))['id'];r=wait(rid)
        assert r['status']=='INCOMPLETE' and len(r['states'])==2 and r['queue'],r['message'];print('PASS capture limit preserves pending paths and two completed states',flush=True)
        previous={s['id']:s['imageHash'] for s in r['states']};f=data/'runs'/rid/'run.json';raw=json.loads(f.read_text());raw.pop('actionJournal',None);raw['queue'].append({'path':raw['states'][0]['path']});raw['queue'].append(raw['queue'][0]);f.write_text(json.dumps(raw));
        api('runs/resume',dict(id=rid,config=dict(maxStates=20,maxActions=50)));after=wait(rid)
        assert after['status'] in ('COMPLETED','REVIEW_REQUIRED') and not after['queue'],after['message'];assert len(after['states'])>=4 and len({s['id'] for s in after['states']})==len(after['states']);assert all(next(s for s in after['states'] if s['id']==sid)['imageHash']==h for sid,h in previous.items());print('PASS legacy checkpoint resume deduplicates pending paths and preserves prior screenshots',flush=True)
        assert all(s.get('path') for s in after['actionJournal'].values());print('PASS resumed journal contains only new non-root paths',flush=True)
    finally:p.terminate();p.wait(timeout=15);site.shutdown()
