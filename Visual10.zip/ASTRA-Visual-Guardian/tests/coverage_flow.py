#!/usr/bin/env python3
"""Focused end-to-end coverage gate, legacy-skip recovery, and replay configuration on packaged JAR; mock CDP."""
import json,os,re,socket,subprocess,tempfile,threading,time,urllib.request,urllib.error,sys
from http.server import ThreadingHTTPServer,BaseHTTPRequestHandler
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
JAR=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else ROOT/'build/visual-guardian.jar'
class Site(BaseHTTPRequestHandler):
    def log_message(self,*args):pass
    def do_GET(self):
        body=('<html><title>Dashboard</title><main><h1>Dashboard</h1><a href="/payment-module">High Value Payment</a><a href="/delete">Delete record</a></main></html>' if self.path=='/' else '<html><title>Payment module</title><main><h1>Payment module</h1></main></html>').encode()
        self.send_response(200);self.send_header('Content-Length',str(len(body)));self.end_headers();self.wfile.write(body)
site=ThreadingHTTPServer(('127.0.0.1',0),Site);threading.Thread(target=site.serve_forever,daemon=True).start();url='http://127.0.0.1:'+str(site.server_port)
with tempfile.TemporaryDirectory() as td:
    data=Path(td)/'data';sock=socket.socket();sock.bind(('127.0.0.1',0));port=sock.getsockname()[1];sock.close();base='http://127.0.0.1:'+str(port);p=subprocess.Popen(['java','-jar',str(JAR),'--port',str(port),'--data',str(data)],stdout=subprocess.DEVNULL)
    try:
        for _ in range(80):
            try:html=urllib.request.urlopen(base,timeout=1).read().decode();break
            except Exception:time.sleep(.2)
        token=re.search('name="guardian-token" content="([^\"]+)"',html).group(1)
        def api(path,body=None,expected=200,raw=False):
            req=urllib.request.Request(base+'/api/'+path,data=json.dumps(body).encode() if body is not None else None,headers={'X-Guardian-Token':token,'Content-Type':'application/json'})
            try:res=urllib.request.urlopen(req,timeout=20);code=res.status;out=res.read()
            except urllib.error.HTTPError as ex:code=ex.code;out=ex.read()
            assert code==expected,(path,code,out[:300]);return out if raw else json.loads(out)
        def wait(rid):
            for _ in range(300):
                r=api('runs/'+rid)
                if not r['active']:return r
                time.sleep(.2)
            raise AssertionError('timeout')
        cfg=dict(browser=str(ROOT/'tests/mock_browser.py'),headless=True,autoViewport=True,captureConsent=True,autoAuth=True,maxStates=1,maxActions=50,maxDepth=3,settleMs=100,locatorSeconds=2,pageSeconds=10,expectedRoutes=['/','/payment-module'])
        suite=api('suites',dict(name='Coverage fixture',url=url,config=cfg));sid=suite['id'];rid=api('runs',dict(suiteId=sid,mode='CAPTURE',target=url,config=cfg))['id'];r=wait(rid)
        assert r['status']=='INCOMPLETE' and len(r['states'])==1 and r['queue'] and r['config']['viewportLocked'];print('PASS partial capture preserves pending work and locks capture viewport',flush=True)
        f=data/'runs'/rid/'run.json';old=json.loads(f.read_text());previous=old['states'][0]['imageHash'];state=old['states'][0];old['queue']=[];old['skipped'].append({'label':'High Value Payment','stateId':state['id'],'reason':'potentially mutating action'});f.write_text(json.dumps(old));
        api('runs/resume',dict(id=rid,config=dict(recoverCoverage=True,adaptiveLimits=True,readPostPaths=['/api/read'],allowedLabels=['Search'])));r=wait(rid)
        assert r['status']=='REVIEW_REQUIRED' and len(r['states'])==2 and not r['queue'] and r['states'][0]['imageHash']==previous and not r['coverage']['missingRoutes'];print('PASS legacy skip recovered with adaptive budget and preserved original screenshot',flush=True)
        assert 'review' in api('approve',{'id':rid},expected=400)['error'];print('PASS unreviewed capture is not approvable',flush=True)
        ids=[x['reviewId'] for x in r['coverageExceptions'] if not x['reviewed']];api('coverage/review',{'id':rid,'reason':'Deletion is excluded from read-only test scope','ids':ids});r=api('runs/'+rid);assert r['status']=='COMPLETED' and not r['coverage']['unreviewed'] and r['coverage']['excluded'];print('PASS review changes readiness without counting exclusions as passed',flush=True)
        api('approve',{'id':rid});assert b'Discovered module coverage' in api('runs/'+rid+'/report.html',raw=True);print('PASS approved baseline and structured coverage report',flush=True)
        replay=api('runs',dict(suiteId=sid,mode='REPLAY',target=url,referenceId=rid,reuseApprovedReads=True,config=dict(captureConsent=True)));assert replay['config']['readPostPaths']==['/api/read'] and replay['config']['allowedLabels']==['Search'] and replay['config']['viewportLocked'];r=wait(replay['id']);assert r['status']=='COMPLETED' and all(x['status']=='PASSED' for x in r['results']);print('PASS replay inherits explicitly approved read configuration and locked viewport',flush=True)
    finally:p.terminate();p.wait(timeout=15);site.shutdown()
