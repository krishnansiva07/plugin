#!/usr/bin/env python3
"""
Real-browser regression test for the sign-in and storage fixes (CHANGES.md, items 1-4).

Usage:  GUARDIAN_TEST_BROWSER=/path/to/chrome python tests/signin_fixes.py visual-guardian.jar

The fixture application:
  * is entered on one port and redirects to another port on the same host (like http -> https),
  * has a "Login history" menu item, a "PIN code" field and a shipping-address field on every page,
  * has a report page whose text starts with "Please wait while the report is generated",
  * has a page that always asks for a password (/trap) and a link that ends the session (/expire),
  * signs in by itself on /login after a short delay (standing in for a person typing),
  * also serves a dashboard with a single "quick unlock" password box (a false positive the user overrides),
  * and a second host name (localhost vs 127.0.0.1) that the user confirms as part of the application.
"""
import io, json, os, re, socket, subprocess, sys, tempfile, threading, time, urllib.error, urllib.parse, urllib.request, zipfile
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

JAR = Path(sys.argv[1]).resolve()
BROWSER = os.environ.get('GUARDIAN_TEST_BROWSER', '/usr/bin/google-chrome')
passed = []


def check(name, ok, detail=''):
    if not ok:
        raise AssertionError(f'{name} {detail}')
    passed.append(name)
    print('PASS', name, flush=True)


MENU = ('<nav><a href="/accounts">Accounts</a> <a href="/login-history">Login history</a> '
        '<a href="/reports">Reports</a> <a href="/trap">Trap</a> <a href="/expire">Expire</a></nav>')
FIELDS = '<input name="pincode" placeholder="PIN code"> <input name="addr" autocomplete="shipping street-address">'


def page(title, body):
    return f'<!doctype html><html><head><title>{title}</title></head><body style="font:16px Arial;margin:20px">{body}</body></html>'


class App(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass

    def reply(self, code=200, body='', headers=()):
        data = body.encode()
        self.send_response(code)
        for k, v in headers:
            self.send_header(k, v)
        self.send_header('Content-Type', 'text/html; charset=utf-8')
        self.send_header('Content-Length', str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def signed_in(self):
        return 'sess=ok' in (self.headers.get('Cookie') or '')

    def do_GET(self):
        path = self.path.split('?')[0]
        if path == '/login':
            return self.reply(body=page('Sign in', '<h1>Sign in</h1><form action="/do-login" method="get">'
                                       '<input name="username"> <input type="password" name="password"> <button>Sign in</button></form>'
                                       '<script>setTimeout(()=>document.forms[0].submit(),1200)</script>'))
        if path == '/do-login':
            return self.reply(302, headers=[('Set-Cookie', 'sess=ok; Path=/'), ('Location', '/home')])
        if path == '/widget':  # no sign-in needed; one password box is a "quick unlock" widget, not a login
            return self.reply(body=page('Operations', '<h1>Operations dashboard</h1><nav><a href="/widget-detail">Queue detail</a></nav>'
                                       '<label>Quick unlock <input type="password" name="unlock"></label>'))
        if path == '/widget-detail':
            return self.reply(body=page('Queue detail', '<h1>Queue detail</h1><nav><a href="/widget">Back</a></nav>'))
        if path == '/trap':  # always asks for a password, even when signed in
            return self.reply(body=page('Confirm', '<h1>Confirm your password</h1>' + MENU + '<input type="password" name="confirm">'))
        if not self.signed_in():
            return self.reply(302, headers=[('Location', '/login')])
        if path == '/expire':
            return self.reply(302, headers=[('Set-Cookie', 'sess=; Path=/; Max-Age=0'), ('Location', '/login')])
        if path in ('/', ''):
            return self.reply(302, headers=[('Location', '/home')])
        if path == '/home':
            return self.reply(body=page('Dashboard', '<h1>Dashboard</h1>' + MENU + FIELDS))
        if path == '/accounts':
            return self.reply(body=page('Accounts', '<h1>Accounts overview</h1>' + MENU + FIELDS))
        if path == '/login-history':
            return self.reply(body=page('Login history', '<h1>Login history</h1>' + MENU +
                                       '<label>User ID <input name="userId"></label> <button type="button">Next</button>'))
        if path == '/reports':
            return self.reply(body=page('Reports', '<p>Please wait while the report is generated. Figures refresh hourly.</p>'
                                       '<h1>Reports</h1>' + MENU + '<table><tr><th>Branch</th><th>Total</th></tr>'
                                       '<tr><td>Chennai</td><td>42</td></tr></table>'))
        return self.reply(404, 'not found')


def serve(handler):
    server = ThreadingHTTPServer(('127.0.0.1', 0), handler)
    threading.Thread(target=server.serve_forever, daemon=True).start()
    return server


app = serve(App)
APP = app.server_port


class Entry(BaseHTTPRequestHandler):
    """The address people type; everything moves to the application's real port (like http -> https)."""
    def log_message(self, *args):
        pass

    def do_GET(self):
        host = 'localhost' if self.path.startswith('/other-host') else '127.0.0.1'
        target = '/home' if self.path.startswith('/other-host') else self.path
        self.send_response(302)
        self.send_header('Location', f'http://{host}:{APP}{target}')
        self.send_header('Content-Length', '0')
        self.end_headers()


entry = serve(Entry)
ENTRY = f'http://127.0.0.1:{entry.server_port}'

with tempfile.TemporaryDirectory() as td:
    data = Path(td) / 'data'
    sock = socket.socket(); sock.bind(('127.0.0.1', 0)); port = sock.getsockname()[1]; sock.close()
    base = f'http://127.0.0.1:{port}'
    env = dict(os.environ)
    if hasattr(os, 'geteuid') and os.geteuid() == 0:
        env['GUARDIAN_TEST_NO_SANDBOX'] = '1'
    log = (Path(td) / 'server.log').open('w')
    proc = subprocess.Popen(['java', '-jar', str(JAR), '--port', str(port), '--data', str(data)], stdout=log, stderr=subprocess.STDOUT, env=env)
    try:
        for _ in range(100):
            try:
                html = urllib.request.urlopen(base, timeout=1).read().decode(); break
            except Exception:
                time.sleep(.2)
        token = re.search('name="guardian-token" content="([^"]+)"', html).group(1)

        def api(path, body=None, expected=200, raw=False):
            payload = body if isinstance(body, bytes) else (json.dumps(body).encode() if body is not None else None)
            headers = {'X-Guardian-Token': token, 'Content-Type': 'application/zip' if isinstance(body, bytes) else 'application/json'}
            req = urllib.request.Request(base + '/api/' + path, data=payload, headers=headers)
            try:
                res = urllib.request.urlopen(req, timeout=30); code = res.status; out = res.read()
            except urllib.error.HTTPError as e:
                code = e.code; out = e.read()
            assert code == expected, (path, code, out[:400])
            return out if raw else json.loads(out)

        def wait(rid, timeout=300, until=None):
            seen = []
            end = time.time() + timeout
            while time.time() < end:
                r = api('runs/' + rid)
                if not seen or seen[-1] != r['status']:
                    seen.append(r['status'])
                if until and until(r):
                    return r, seen
                if not until and not r['active']:
                    return r, seen
                time.sleep(.4)
            raise AssertionError(f'timeout; statuses {seen}; last message: {r.get("message")}')

        cfg = dict(browser=BROWSER, headless=True, autoAuth=True, captureConsent=True, width=900, height=700,
                   settleMs=150, pageSeconds=20, locatorSeconds=3, authSeconds=120, maxDepth=1, maxStates=20, maxActions=60)

        # ---- 1-4: capture through a port redirect, misleading labels, a credential trap and a session expiry
        suite = api('suites', dict(name='Sign-in fixes fixture', url=ENTRY + '/', config=cfg))
        rid = api('runs', dict(suiteId=suite['id'], mode='CAPTURE', target=ENTRY + '/', config=cfg))['id']
        started = time.time()
        cap, statuses = wait(rid, timeout=int(os.environ.get('GUARDIAN_TEST_CAPTURE_TIMEOUT', '420')))
        print('CAPTURE', cap['status'], f'{time.time() - started:.0f}s', 'statuses:', statuses, flush=True)
        routes = sorted({s['route'] for s in cap['states']})
        print('routes:', routes, flush=True)
        check('redirect to another port on the same host is accepted without help',
              cap['status'] in ('REVIEW_REQUIRED', 'COMPLETED') and '/home' in routes, cap.get('message', ''))
        check('pages with "Login history", a PIN-code field and "Please wait" text are captured, not treated as sign-in',
              {'/home', '/accounts', '/login-history', '/reports'} <= set(routes), str(routes))
        check('the sign-in page itself is never captured', '/login' not in routes)
        loops = [x for x in cap['skipped'] if x.get('reason', '').startswith('Sign-in requested again')]
        loop_labels = sorted(x['path'][-1]['label'] for x in loops)
        check('paths that keep asking for sign-in are set aside after 2 fresh sign-ins (no endless loop)',
              loop_labels == ['Expire', 'Trap'], str(loop_labels))
        check('the sign-in address is learned for spotting later session expiry', '/login' in cap.get('loginRoutes', []), str(cap.get('loginRoutes')))

        run_dir = data / 'runs' / rid
        stored = json.loads((run_dir / 'run.json').read_text())
        details = sorted(p.name for p in (run_dir / 'states').glob('*.json'))
        check('run.json keeps no page DOM; each captured page has its own detail file',
              all('dom' not in s and 'structure' not in s for s in stored['states']) and len(details) == len(stored['states']), str(details))
        check('detail endpoint answers "unchanged" when nothing changed',
              api(f'runs/{rid}?since={urllib.parse.quote(cap["updated"])}').get('unchanged') is True)
        check('execution list is served from cached summaries', any(r['id'] == rid and r['states'] == len(cap['states']) for r in api('runs')))

        # ---- replay uses baseline details from the per-page files
        pending = [x['reviewId'] for x in cap['coverageExceptions'] if not x['reviewed']]
        if pending:
            api('coverage/review', dict(id=rid, reason='Fixture: inputs, depth limit and sign-in traps are out of scope', ids=pending))
        api('approve', dict(id=rid))
        rep = api('runs', dict(suiteId=suite['id'], mode='REPLAY', target=ENTRY + '/', referenceId=rid, config=dict(captureConsent=True)))
        rep, _ = wait(rep['id'], timeout=300)
        check('replay of the approved baseline passes every page',
              rep['status'] == 'COMPLETED' and rep['results'] and all(x['status'] == 'PASSED' for x in rep['results']),
              str([(x['title'], x['status'], x.get('reason')) for x in rep['results']]))

        # ---- portable baseline stays self-contained (older installations can import it)
        z = zipfile.ZipFile(io.BytesIO(api(f'runs/{rid}/baseline.zip', raw=True)))
        exported = json.loads(z.read('run.json'))
        check('exported baseline embeds page details for portability', all('dom' in s and 'structure' in s for s in exported['states']))
        imported = api('import', api(f'runs/{rid}/baseline.zip', raw=True))
        imported_dir = data / 'runs' / imported['run']['id']
        check('imported baseline is stored in the light format with detail files',
              len(list((imported_dir / 'states').glob('*.json'))) == len(cap['states'])
              and all('dom' not in s for s in json.loads((imported_dir / 'run.json').read_text())['states']))

        # ---- override: a "quick unlock" password box on the real home page; Return control twice continues
        manual = dict(cfg, autoAuth=False, maxDepth=1)
        widget_suite = api('suites', dict(name='Override fixture', url=f'http://127.0.0.1:{APP}/widget', config=manual))
        wid = api('runs', dict(suiteId=widget_suite['id'], mode='CAPTURE', target=f'http://127.0.0.1:{APP}/widget', config=manual))['id']
        wait(wid, timeout=60, until=lambda r: r['status'] == 'AWAITING_INPUT')
        time.sleep(1.5)
        api('runs/command', dict(id=wid, command='continue'))
        first, _ = wait(wid, timeout=30, until=lambda r: 'Return control again' in (r.get('message') or ''))
        check('first Return control on a page that looks like sign-in explains why and asks once more',
              first['status'] == 'AWAITING_INPUT' and 'password box' in first['message'], first['message'])
        api('runs/command', dict(id=wid, command='continue'))
        done, _ = wait(wid, timeout=180)
        check('second Return control continues the run and remembers the override',
              done['status'] in ('REVIEW_REQUIRED', 'COMPLETED') and 'password-field' in done.get('authOverrides', [])
              and {'/widget', '/widget-detail'} <= {s['route'] for s in done['states']},
              f"{done['status']} {done.get('message')} {[s['route'] for s in done['states']]}")

        # ---- another host name: the user confirms it once (twice-click) and the run continues there
        other_suite = api('suites', dict(name='Other host fixture', url=ENTRY + '/other-host', config=dict(cfg, maxDepth=0)))
        oid = api('runs', dict(suiteId=other_suite['id'], mode='CAPTURE', target=ENTRY + '/other-host', config=dict(cfg, maxDepth=0)))['id']
        hinted, _ = wait(oid, timeout=60, until=lambda r: 'not the address you entered' in (r.get('message') or ''))
        check('a different host is not accepted silently; the run explains and waits', hinted['status'] == 'AWAITING_INPUT', hinted['message'])
        api('runs/command', dict(id=oid, command='continue'))
        wait(oid, timeout=20, until=lambda r: 'Return control again' in (r.get('message') or ''))
        api('runs/command', dict(id=oid, command='continue'))
        other, _ = wait(oid, timeout=120)
        check('confirmed host is accepted and kept for resume',
              other['status'] in ('REVIEW_REQUIRED', 'COMPLETED') and any('localhost' in o for o in other.get('appOrigins', []))
              and any(s['route'] == '/home' for s in other['states']), f"{other['status']} {other.get('appOrigins')} {other.get('message')}")
        print('TOTAL', len(passed), 'checks passed', flush=True)
    finally:
        proc.terminate()
        try:
            proc.wait(timeout=15)
        except subprocess.TimeoutExpired:
            proc.kill()
        log.close()
        app.shutdown(); entry.shutdown()
