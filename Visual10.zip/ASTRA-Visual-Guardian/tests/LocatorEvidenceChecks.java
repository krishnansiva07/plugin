package guardian;

import java.nio.file.*;
import java.util.*;
import static guardian.Json.*;

/**
 * Matching controls that share a label (CHANGES.md, "Locators"). Look-alikes are chosen only on evidence:
 * link address, row/list-item text, a counter-only label change, or exact position while capturing.
 * Usage: java guardian.LocatorEvidenceChecks [context-script.js legacy-script.js]  (scripts are used by locator_context_dom.js)
 */
public class LocatorEvidenceChecks {
    static int passed = 0;

    static void check(String name, boolean ok) {
        if (!ok) throw new AssertionError(name);
        passed++;
        System.out.println("PASS " + name);
    }

    static Map<String, Object> link(String label, String href, String css, String context) {
        return obj("tag", "a", "role", "a", "label", label, "css", css, "id", "", "testId", "", "name", "", "href", href,
                "type", "", "target", "", "form", false, "disabled", false, "context", context, "action", "CLICK");
    }

    static Map<String, Object> button(String label, String css, String context) {
        return obj("tag", "button", "role", "button", "label", label, "css", css, "id", "", "testId", "", "name", "", "href", "",
                "type", "", "target", "", "form", false, "disabled", false, "context", context, "action", "CLICK");
    }

    static Map<String, Object> dom(Object... elements) {
        return obj("elements", List.of(elements));
    }

    public static void main(String[] args) throws Exception {
        var cfg = Store.config(obj());

        var header = link("Home", "/", "header > a:nth-of-type(1)", "");
        var footer = link("Home", "/", "footer > a:nth-of-type(1)", "");
        check("repeated links to the same address are interchangeable",
                Engine.match(footer, dom(header, footer), cfg).get("css").equals(footer.get("css")));

        var d1 = link("Details", "/account/1", "tr:nth-of-type(2) a", "ACC-001 Ravi Kumar Details View");
        var d2 = link("Details", "/account/2", "tr:nth-of-type(3) a", "ACC-002 Priya Sharma Details View");
        check("row links are told apart by their address", Engine.match(d2, dom(d1, d2), cfg).get("href").equals("/account/2"));

        var v2 = button("View", "tr:nth-of-type(3) button", "ACC-002 Priya Sharma Details View");
        var v2moved = button("View", "tr:nth-of-type(2) button", "ACC-002 Priya Sharma Details View");
        var v1moved = button("View", "tr:nth-of-type(3) button", "ACC-001 Ravi Kumar Details View");
        check("row buttons are told apart by row text, even after the rows are reordered",
                Engine.match(v2, dom(v2moved, v1moved), cfg).get("css").equals("tr:nth-of-type(2) button"));
        check("row text still matches when a value in the row changed",
                Engine.match(button("View", "x", "ACC-002 Priya Sharma 1,200.00 Details View"),
                        dom(button("View", "a", "ACC-001 Ravi Kumar 900.00 Details View"), button("View", "b", "ACC-002 Priya Sharma 1,250.00 Details View")),
                        cfg).get("css").equals("b"));

        var same1 = button("View", "tr:nth-of-type(2) button", "Pending Details View");
        var same2 = button("View", "tr:nth-of-type(3) button", "Pending Details View");
        try {
            Engine.match(same2, dom(same1, same2), cfg, false);
            throw new AssertionError("identical rows accepted in replay");
        } catch (Engine.Missing ex) {
            check("identical rows are never guessed between in replay", ex.ambiguous);
        }
        check("while capturing, the exact position decides between identical rows",
                Engine.match(same2, dom(same1, same2), cfg, true).get("css").equals("tr:nth-of-type(3) button"));

        var legacy = button("View", "tr:nth-of-type(3) button", "");
        legacy.remove("context");
        try {
            Engine.match(legacy, dom(button("View", "a", "ACC-001 Ravi Kumar"), button("View", "b", "ACC-002 Priya Sharma")), cfg, false);
            throw new AssertionError("legacy look-alike accepted in replay");
        } catch (Engine.Missing ex) {
            check("older recorded steps without row text stay strict in replay", ex.ambiguous);
        }

        var alerts = obj("tag", "button", "role", "tab", "label", "Alerts (3)", "css", "#t", "id", "", "testId", "", "name", "", "href", "",
                "type", "", "target", "", "form", false, "disabled", false, "action", "CLICK");
        var later = new LinkedHashMap<>(alerts);
        later.put("label", "Alerts (4)");
        check("a label that changes only in its counter is the same control", Engine.match(alerts, dom(later), cfg).get("label").equals("Alerts (4)"));
        try {
            Engine.match(button("View 123", "#a", ""), dom(button("View 456", "#b", "")), cfg);
            throw new AssertionError("different record accepted");
        } catch (Engine.Missing ex) {
            check("a different record number is still a different control", !ex.ambiguous);
        }

        if (args.length >= 2) {
            var withRow = button("View", "//*[broken", "ACC-002 Priya Sharma Details View");
            var withoutRow = button("View", "//*[broken", "");
            Files.writeString(Path.of(args[0]), Browser.actionScript(withRow));
            Files.writeString(Path.of(args[1]), Browser.actionScript(withoutRow));
        }
        System.out.println("TOTAL " + passed + " locator evidence checks passed");
    }
}
