#!/usr/bin/env python3
"""
Real-browser test for locating controls that share a label (CHANGES.md, "Locators").

Usage:  GUARDIAN_TEST_BROWSER=/path/to/chrome python tests/locator_fixes.py visual-guardian.jar

The fixture is a small banking-style app with:
  * "Home" and "Help" links in both the header and the footer (same label, same address),
  * an accounts table where every row has a "Details" link (different addresses) and a "View" button (no address),
  * an "Alerts (N)" tab whose count changes on every page load,
  * and, for the replay, a "migrated" mode where the table rows come back in reverse order.
"""
import itertools, json, os, re, socket, subprocess, sys, tempfile, threading, time, urllib.error, urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

JAR = Path(sys.argv[1]).resolve()
BROWSER = os.environ.get('GUARDIAN_TEST_BROWSER', '/usr/bin/google-chrome')
passed = []
LOCATOR_ERRORS = ('Ambiguous element', 'Element missing', 'Live selector invalid')


def check(name, ok, detail=''):
    if not ok:
        raise AssertionError(f'{name} {detail}')
    passed.append(name)
    print('PASS', name, flush=True)


ACCOUNTS = [('ACC-001', 'Ravi Kumar', 1), ('ACC-002', 'Priya Sharma', 2), ('ACC-003', 'Arun Prakash', 3)]
counter = itertools.count(3)
state = {'reversed': False}
HEADER = '<header><nav><a href="/">Home</a> <a href="/accounts">Accounts</a> <a href="/help">Help</a></nav></header>'
FOOTER = '<footer><a href="/">Home</a> <a href="/help">Help</a></footer>'
SCRIPT = ('<script>function view(b,n){document.getElementById("panel").innerHTML="<h2>Quick view: "+n+"</h2>"}'
          'function alerts(){document.getElementById("alerts").hidden=false}</script>')


def page(title, body):
    return (f'<!doctype html><html><head><title>{title}</title></head><body style="font:16px Arial;margin:20px">'
            f'{HEADER}<main>{body}</main>{FOOTER}{SCRIPT}</body></html>')


class App(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass

    def do_GET(self):
        path = self.path.split('?')[0]
        if path == '/':
            body = page('Branch dashboard', f'<h1>Branch dashboard</h1><div role="tablist"><button role="tab" type="button" onclick="alerts()">Alerts ({next(counter)})</button></div>'
                                            '<section id="alerts" hidden><h2>Alerts panel</h2><p>No critical alerts</p></section>')
        elif path == '/accounts':
            rows = list(reversed(ACCOUNTS)) if state['reversed'] else ACCOUNTS
            cells = ''.join(f'<tr><td>{acc}</td><td>{name}</td><td><a href="/account/{n}">Details</a> '
                            f'<button type="button" onclick="view(this,\'{name}\')">View</button></td></tr>' for acc, name, n in rows)
            body = page('Accounts', f'<h1>Accounts</h1><table><tr><th>Account</th><th>Name</th><th></th></tr>{cells}</table><section id="panel"></section>')
        elif path.startswith('/account/'):
            acc, name, n = ACCOUNTS[int(path.rsplit('/', 1)[1]) - 1]
            body = page(f'Account {acc}', f'<h1>Account {acc}</h1><p>Holder: {name}</p>')
        elif path == '/help':
            body = page('Help', '<h1>Help</h1><p>Contact the branch desk.</p>')
        else:
            self.send_response(404); self.end_headers(); return
        data = body.encode()
        self.send_response(200)
        self.send_header('Content-Type', 'text/html; charset=utf-8')
        self.send_header('Content-Length', str(len(data)))
        self.end_headers()
        self.wfile.write(data)


app = ThreadingHTTPServer(('127.0.0.1', 0), App)
threading.Thread(target=app.serve_forever, daemon=True).start()
URL = f'http://127.0.0.1:{app.server_port}/'

with tempfile.TemporaryDirectory() as td:
    data = Path(td) / 'data'
    sock = socket.socket(); sock.bind(('127.0.0.1', 0)); port = sock.getsockname()[1]; sock.close()
    base = f'http://127.0.0.1:{port}'
    env = dict(os.environ)
    if hasattr(os, 'geteuid') and os.geteuid() == 0:
        env['GUARDIAN_TEST_NO_SANDBOX'] = '1'
    log = (Path(td) / 'server.log').open('w')
    proc = subprocess.Popen(['java', '-jar', str(JAR), '--port', str(port), '--data', str(data)], stdout=log, stderr=subprocess.STDOUT, env=env)
    try:
        for _ in range(100):
            try:
                html = urllib.request.urlopen(base, timeout=1).read().decode(); break
            except Exception:
                time.sleep(.2)
        token = re.search('name="guardian-token" content="([^"]+)"', html).group(1)

        def api(path, body=None, expected=200):
            req = urllib.request.Request(base + '/api/' + path, data=json.dumps(body).encode() if body is not None else None,
                                         headers={'X-Guardian-Token': token, 'Content-Type': 'application/json'})
            try:
                res = urllib.request.urlopen(req, timeout=30); code = res.status; out = res.read()
            except urllib.error.HTTPError as e:
                code = e.code; out = e.read()
            assert code == expected, (path, code, out[:400])
            return json.loads(out)

        def wait(rid, timeout=420):
            end = time.time() + timeout
            while time.time() < end:
                r = api('runs/' + rid)
                if not r['active']:
                    return r
                time.sleep(.4)
            raise AssertionError(f'timeout: {r.get("status")} {r.get("message")}')

        def visible_text(run_id, state_id):
            """Normalised visible text of a captured or observed page (from its detail file, or inline for older runs)."""
            f = data / 'runs' / run_id / 'states' / f'{state_id}.json'
            detail = json.loads(f.read_text()) if f.exists() else next(s for s in json.loads((data / 'runs' / run_id / 'run.json').read_text())['states'] if s['id'] == state_id)
            return ' '.join(x for x in detail.get('structure', []) if x.startswith('visible text:'))

        cfg = dict(browser=BROWSER, headless=True, autoAuth=True, captureConsent=True, width=1000, height=800, settleMs=150,
                   pageSeconds=20, locatorSeconds=4, maxDepth=2, maxStates=40, maxActions=120, masks=[])
        suite = api('suites', dict(name='Locator fixture', url=URL, config=cfg))
        rid = api('runs', dict(suiteId=suite['id'], mode='CAPTURE', target=URL, config=cfg))['id']
        cap = wait(rid)
        locator_issues = [x['reason'] for x in cap.get('issues', []) if x['reason'].startswith(LOCATOR_ERRORS)]
        print('CAPTURE', cap['status'], len(cap['states']), 'states;', len(locator_issues), 'locator issues', flush=True)
        for reason in sorted(set(locator_issues)):
            print('   issue:', reason, flush=True)
        titles = [s['title'] for s in cap['states']]
        texts = {s['id']: visible_text(rid, s['id']) for s in cap['states']}
        check('capture has no locator failures for repeated links, row buttons or changing counts', not locator_issues, str(sorted(set(locator_issues))))
        check('every account page is reached through its own "Details" link',
              all(f'Account {acc}' in titles for acc, _, _ in ACCOUNTS), str(titles))
        quick = {name for name in (n for _, n, _ in ACCOUNTS) if any(f'quick view: {name.lower()}' in t for t in texts.values())}
        check('every row\'s "View" button opens its own quick view', quick == {n for _, n, _ in ACCOUNTS}, str(quick))
        check('the "Alerts (N)" tab is found although its count changes', any('alerts panel' in t and 'no critical alerts' in t for t in texts.values()))

        # Replay against a "migrated" system whose table rows come back in reverse order.
        pending = [x['reviewId'] for x in cap['coverageExceptions'] if not x['reviewed']]
        if pending:
            api('coverage/review', dict(id=rid, reason='Fixture: depth limit and inputs are out of scope', ids=pending))
        api('approve', dict(id=rid))
        state['reversed'] = True
        rep = api('runs', dict(suiteId=suite['id'], mode='REPLAY', target=URL, referenceId=rid, config=dict(captureConsent=True)))
        rep = wait(rep['id'])
        replay_locator = [(x['title'], x.get('reason', '')) for x in rep['results'] if x.get('reason', '').startswith(LOCATOR_ERRORS)]
        check('replay after the rows were reordered finds every control', not replay_locator, str(replay_locator))
        wrong, compared = [], 0
        for st in cap['states']:
            before = texts[st['id']]
            m = re.search(r'quick view: ([a-z ]+?)(?: \||$| account| name| home| help| contact)', before)
            if m:
                after = visible_text(rep['id'], st['id'])
                compared += 1
                if f'quick view: {m.group(1)}' not in after:
                    wrong.append(m.group(1))
        check('reordered rows: each "View" click still opens the same person (matched by row text, not position)', compared >= 3 and not wrong, f'{compared} compared; wrong: {wrong}')
        print('TOTAL', len(passed), 'locator checks passed', flush=True)
    finally:
        proc.terminate()
        try:
            proc.wait(timeout=15)
        except subprocess.TimeoutExpired:
            proc.kill()
        log.close()
        app.shutdown()
