#!/usr/bin/env python3
"""Upgrade check (real browser): data written by an OLDER jar is resumed, approved, replayed and exported by the NEW jar.
Usage: python tests/upgrade_check.py OLDER_JAR NEW_JAR   (GUARDIAN_TEST_BROWSER must point at Chrome)"""
import io, json, os, re, socket, subprocess, sys, tempfile, threading, time, urllib.error, urllib.request, zipfile
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

OLD, NEW = Path(sys.argv[1]).resolve(), Path(sys.argv[2]).resolve()
BROWSER = os.environ['GUARDIAN_TEST_BROWSER']
passed = []


def check(name, ok, detail=''):
    if not ok:
        raise AssertionError(f'{name} {detail}')
    passed.append(name); print('PASS', name, flush=True)


PAGES = {'/': 'Home', '/accounts': 'Accounts', '/reports': 'Reports', '/branches': 'Branches'}


class Site(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def do_GET(self):
        title = PAGES.get(self.path)
        if not title:
            self.send_response(404); self.end_headers(); return
        links = ' '.join(f'<a href="{p}">{t}</a>' for p, t in PAGES.items() if p != self.path)
        body = f'<!doctype html><html><title>{title}</title><body style="font:16px Arial;margin:20px"><h1>{title}</h1><nav>{links}</nav></body></html>'.encode()
        self.send_response(200); self.send_header('Content-Type', 'text/html'); self.send_header('Content-Length', str(len(body))); self.end_headers(); self.wfile.write(body)


site = ThreadingHTTPServer(('127.0.0.1', 0), Site)
threading.Thread(target=site.serve_forever, daemon=True).start()
URL = f'http://127.0.0.1:{site.server_port}/'


class Guardian:
    def __init__(self, jar, data):
        s = socket.socket(); s.bind(('127.0.0.1', 0)); self.port = s.getsockname()[1]; s.close()
        env = dict(os.environ)
        if hasattr(os, 'geteuid') and os.geteuid() == 0:
            env['GUARDIAN_TEST_NO_SANDBOX'] = '1'
        self.proc = subprocess.Popen(['java', '-jar', str(jar), '--port', str(self.port), '--data', str(data)],
                                     stdout=subprocess.DEVNULL, stderr=subprocess.STDOUT, env=env)
        self.base = f'http://127.0.0.1:{self.port}'
        for _ in range(100):
            try:
                html = urllib.request.urlopen(self.base, timeout=1).read().decode(); break
            except Exception:
                time.sleep(.2)
        self.token = re.search('name="guardian-token" content="([^"]+)"', html).group(1)

    def api(self, path, body=None, expected=200, raw=False):
        payload = body if isinstance(body, bytes) else (json.dumps(body).encode() if body is not None else None)
        req = urllib.request.Request(self.base + '/api/' + path, data=payload,
                                     headers={'X-Guardian-Token': self.token, 'Content-Type': 'application/zip' if isinstance(body, bytes) else 'application/json'})
        try:
            res = urllib.request.urlopen(req, timeout=30); code = res.status; out = res.read()
        except urllib.error.HTTPError as e:
            code = e.code; out = e.read()
        assert code == expected, (path, code, out[:400])
        return out if raw else json.loads(out)

    def wait(self, rid, timeout=240):
        end = time.time() + timeout
        while time.time() < end:
            r = self.api('runs/' + rid)
            if not r['active']:
                return r
            time.sleep(.4)
        raise AssertionError('timeout ' + str(r.get('status')) + ' ' + str(r.get('message')))

    def stop(self):
        self.proc.terminate()
        try:
            self.proc.wait(timeout=15)
        except subprocess.TimeoutExpired:
            self.proc.kill()


cfg = dict(browser=BROWSER, headless=True, autoAuth=True, captureConsent=True, width=900, height=700, settleMs=150,
           pageSeconds=20, locatorSeconds=3, maxDepth=1, maxActions=40)
with tempfile.TemporaryDirectory() as td:
    data = Path(td) / 'data'
    # ---- original version: one interrupted capture (like an unfinished BMS run) and one approved baseline
    old = Guardian(OLD, data)
    try:
        s1 = old.api('suites', dict(name='Unfinished capture', url=URL, config=dict(cfg, maxStates=2)))
        unfinished = old.api('runs', dict(suiteId=s1['id'], mode='CAPTURE', target=URL, config=dict(cfg, maxStates=2)))['id']
        r = old.wait(unfinished)
        check('original jar leaves an incomplete capture with pending work', r['status'] == 'INCOMPLETE' and r['queue'] and len(r['states']) == 2, r['status'])
        early_hashes = {s['id']: s['imageHash'] for s in r['states']}
        s2 = old.api('suites', dict(name='Approved by original', url=URL, config=dict(cfg, maxStates=20)))
        approved = old.api('runs', dict(suiteId=s2['id'], mode='CAPTURE', target=URL, config=dict(cfg, maxStates=20)))['id']
        r2 = old.wait(approved)
        ids = [x['reviewId'] for x in r2['coverageExceptions'] if not x['reviewed']]
        if ids:
            old.api('coverage/review', dict(id=approved, reason='Depth limit is outside this check', ids=ids))
        old.api('approve', dict(id=approved))
        legacy_json = json.loads((data / 'runs' / unfinished / 'run.json').read_text())
        check('original jar stores page DOM inside run.json', all('dom' in s for s in legacy_json['states']))
    finally:
        old.stop()

    # ---- new version on the same data folder
    new = Guardian(NEW, data)
    try:
        listed = {r['id']: r for r in new.api('runs')}
        check('execution list shows runs written by the original jar', unfinished in listed and approved in listed and listed[unfinished]['status'] == 'INCOMPLETE')
        detail = new.api('runs/' + unfinished)
        check('run detail opens and leaves out bulky page data', len(detail['states']) == 2 and all('dom' not in s for s in detail['states']))
        new.api('runs/resume', dict(id=unfinished, config=dict(recoverCoverage=True, maxStates=20, maxActions=40)))
        resumed = new.wait(unfinished)
        check('unfinished capture resumes and finishes', resumed['status'] in ('REVIEW_REQUIRED', 'COMPLETED') and not resumed['queue'] and len(resumed['states']) == 4,
              f"{resumed['status']} {resumed['message']} {len(resumed['states'])}")
        check('screenshots captured by the original jar are unchanged',
              all(next(s for s in resumed['states'] if s['id'] == sid)['imageHash'] == h for sid, h in early_hashes.items()))
        migrated = json.loads((data / 'runs' / unfinished / 'run.json').read_text())
        details = list((data / 'runs' / unfinished / 'states').glob('*.json'))
        check('resumed run is migrated to the light format', all('dom' not in s for s in migrated['states']) and len(details) == 4,
              f'{len(details)} detail files')
        ids = [x['reviewId'] for x in resumed['coverageExceptions'] if not x['reviewed']]
        if ids:
            new.api('coverage/review', dict(id=unfinished, reason='Depth limit is outside this check', ids=ids))
        new.api('approve', dict(id=unfinished))
        check('migrated capture can be approved (evidence found in detail files)', any(b['runId'] == unfinished for b in new.api('suites')[0]['baselines'] + new.api('suites')[1]['baselines']))
        rep = new.api('runs', dict(suiteId=s1['id'], mode='REPLAY', target=URL, referenceId=unfinished, config=dict(captureConsent=True)))
        rep = new.wait(rep['id'])
        check('replay against the migrated baseline passes', rep['status'] == 'COMPLETED' and all(x['status'] == 'PASSED' for x in rep['results']),
              str([(x['title'], x['status'], x.get('reason')) for x in rep['results']]))
        rep2 = new.api('runs', dict(suiteId=s2['id'], mode='REPLAY', target=URL, referenceId=approved, config=dict(captureConsent=True)))
        rep2 = new.wait(rep2['id'])
        check('replay against a baseline approved by the original jar passes', rep2['status'] == 'COMPLETED' and rep2['results'] and all(x['status'] == 'PASSED' for x in rep2['results']),
              str([(x['title'], x['status'], x.get('reason')) for x in rep2['results']]))
        legacy_baseline_json = json.loads((data / 'runs' / approved / 'run.json').read_text())
        check('approved baselines from the original jar are left untouched on disk', all('dom' in s for s in legacy_baseline_json['states']))
        z = zipfile.ZipFile(io.BytesIO(new.api(f'runs/{unfinished}/baseline.zip', raw=True)))
        check('exported baseline embeds page details (importable by the original jar)', all('dom' in s for s in json.loads(z.read('run.json'))['states']))
        print('TOTAL', len(passed), 'upgrade checks passed', flush=True)
    finally:
        new.stop()
        site.shutdown()
