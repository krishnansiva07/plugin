// Click step with a stale selector and look-alike "View" buttons: the row text decides, otherwise nothing is clicked.
// Usage: node tests/locator_context_dom.js context-script.js legacy-script.js  (scripts written by LocatorEvidenceChecks)
const fs = require('fs'), vm = require('vm'), assert = require('assert');
const withRow = fs.readFileSync(process.argv[2], 'utf8');
const withoutRow = fs.readFileSync(process.argv[3], 'utf8');

function run(name, script, rows, expectedRow) {
  const clicks = rows.map(() => 0);
  const nodes = rows.map((rowText, i) => ({
    tagName: 'BUTTON', id: '', innerText: 'View', disabled: false, isConnected: true,
    getAttribute: () => null, closest: () => null,
    parentElement: { closest: () => ({ innerText: rowText }) },
    getBoundingClientRect: () => ({ width: 50, height: 20 }), scrollIntoView() {}, click() { clicks[i]++; }
  }));
  const document = { querySelectorAll(s) { if (s.startsWith('//')) throw new SyntaxError('bad CSS'); return nodes; } };
  const result = vm.runInNewContext(script, { document, getComputedStyle: () => ({ visibility: 'visible', display: 'block' }), URL, location: { origin: 'https://example.test' } });
  assert.equal(result, expectedRow !== null, name);
  rows.forEach((_, i) => assert.equal(clicks[i], i === expectedRow ? 1 : 0, name + ' (row ' + i + ')'));
  console.log('PASS ' + name);
}

run('stale selector: the button in the matching row is clicked', withRow, ['ACC-001 Ravi Kumar Details View', 'ACC-002 Priya Sharma Details View'], 1);
run('stale selector: identical rows are never clicked', withRow, ['ACC-002 Priya Sharma Details View', 'ACC-002 Priya Sharma Details View'], null);
run('stale selector without recorded row text: look-alikes are never clicked', withoutRow, ['ACC-001 Ravi Kumar Details View', 'ACC-002 Priya Sharma Details View'], null);
