#!/usr/bin/env python3
"""
Checks the AI model "Test connection" and "Discover models" buttons against stand-in model servers
(no real model needed): one plain-HTTP OpenAI-compatible server and one HTTPS server whose certificate
comes from a private certificate authority, like a company network that inspects HTTPS.

Usage:  python tests/model_test_check.py visual-guardian.jar [--report]
  --report  only print what each scenario returns (no assertions); useful to compare versions.
Needs: Java 17+, Python 3, openssl (for the HTTPS scenarios).
"""
import json, re, socket, ssl, subprocess, sys, tempfile, threading, time, urllib.error, urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

JAR = Path(sys.argv[1]).resolve()
REPORT = '--report' in sys.argv
passed = []


def check(name, ok, detail=''):
    if REPORT:
        return
    if not ok:
        raise AssertionError(f'{name} -- {detail}')
    passed.append(name)
    print('PASS', name, flush=True)


def answer(text, extra=None):
    msg = {'role': 'assistant', 'content': text}
    msg.update(extra or {})
    return {'choices': [{'index': 0, 'message': msg, 'finish_reason': 'stop'}], 'usage': {'total_tokens': 12}}


class FakeLLM(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass

    def raw(self, code, data, ctype='application/json', headers=()):
        self.send_response(code)
        for k, v in headers:
            self.send_header(k, v)
        self.send_header('Content-Type', ctype)
        self.send_header('Content-Length', str(len(data)))
        self.end_headers()
        try:
            self.wfile.write(data)
        except (BrokenPipeError, ConnectionResetError):
            pass  # the client gave up first (the slow-model scenario)

    def reply(self, code, obj, headers=()):
        self.raw(code, json.dumps(obj).encode(), headers=headers)

    def do_GET(self):
        if self.path.startswith('/ok/v1/models'):
            return self.reply(200, {'object': 'list', 'data': [{'id': 'fake-model'}, {'id': 'fake-vision'}]})
        return self.reply(404, {'detail': 'Not Found'})

    def do_POST(self):
        body = json.loads(self.rfile.read(int(self.headers.get('Content-Length', 0))) or b'{}')
        path = self.path
        images = any(isinstance(m.get('content'), list) and any(p.get('type') == 'image_url' for p in m['content']) for m in body.get('messages', []))
        if path.startswith('/ok/v1/chat/completions'):
            return self.reply(200, answer('Red' if images else 'OK'))
        if path.startswith('/auth/v1/chat/completions'):
            if self.headers.get('Authorization') != 'Bearer right-key':
                return self.reply(401, {'error': {'message': 'Incorrect API key provided: wr***ey.', 'type': 'invalid_request_error', 'code': 'invalid_api_key'}})
            return self.reply(200, answer('OK'))
        if path.startswith('/xkey/v1/chat/completions'):
            if self.headers.get('x-api-key') != 'gateway-key' or self.headers.get('Authorization'):
                return self.reply(401, {'message': 'Missing or invalid x-api-key'})
            return self.reply(200, answer('OK'))
        if path.startswith('/new/v1/chat/completions'):
            if 'max_tokens' in body:
                return self.reply(400, {'error': {'message': "Unsupported parameter: 'max_tokens' is not supported with this model. Use 'max_completion_tokens' instead.", 'type': 'invalid_request_error', 'param': 'max_tokens'}})
            if body.get('temperature', 1) != 1:
                return self.reply(400, {'error': {'message': "Unsupported value: 'temperature' does not support 0.1 with this model. Only the default (1) value is supported.", 'type': 'invalid_request_error', 'param': 'temperature'}})
            return self.reply(200, answer('OK'))
        if path.startswith('/think/v1/chat/completions'):
            return self.reply(200, answer('', {'reasoning_content': 'The user wants me to reply OK. Let me think about how to reply...'}))
        if path.startswith('/thinktag/v1/chat/completions'):
            return self.reply(200, answer('<think>The user wants OK. {"order":[9]}</think>\nOK'))
        if path.startswith('/parts/v1/chat/completions'):
            return self.reply(200, answer([{'type': 'text', 'text': 'O'}, {'type': 'text', 'text': 'K'}]))
        if path.startswith('/stream/v1/chat/completions'):
            chunks = ['data: ' + json.dumps({'choices': [{'index': 0, 'delta': {'content': t}}]}) for t in ('O', 'K')]
            return self.raw(200, ('\n\n'.join(chunks + ['data: [DONE]']) + '\n\n').encode(), 'text/event-stream')
        if path.startswith('/html/v1/chat/completions'):
            return self.raw(200, b'<!doctype html><html><head><title>Company Sign In</title></head><body>Sign in</body></html>', 'text/html')
        if path.startswith('/nomodel/v1/chat/completions'):
            return self.reply(404, {'error': {'message': f"The model `{body.get('model')}` does not exist or you do not have access to it.", 'type': 'invalid_request_error', 'code': 'model_not_found'}})
        if path.startswith('/textonly/v1/chat/completions'):
            if images:
                return self.reply(400, {'error': {'message': 'Invalid content type. image_url is only supported by certain models.', 'type': 'invalid_request_error'}})
            return self.reply(200, answer('OK'))
        if path.startswith('/busy/v1/chat/completions'):
            return self.reply(429, {'error': {'message': 'Rate limit reached for requests', 'type': 'requests'}})
        if path.startswith('/redirect/v1/chat/completions'):
            return self.reply(307, {}, [('Location', 'https://models.example.test/v1/chat/completions')])
        if path.startswith('/slow/v1/chat/completions'):
            time.sleep(8)
            return self.reply(200, answer('OK'))
        if path.startswith('/openai/deployments/gpt4o/chat/completions'):
            if 'api-version=' not in path:
                return self.reply(404, {'error': {'code': '404', 'message': 'Resource not found'}})
            if self.headers.get('api-key') != 'azure-key' or self.headers.get('Authorization'):
                return self.reply(401, {'error': {'code': '401', 'message': 'Access denied due to invalid subscription key or wrong API endpoint.'}})
            return self.reply(200, answer('OK'))
        return self.reply(404, {'detail': 'Not Found'})


def serve(server):
    threading.Thread(target=server.serve_forever, daemon=True).start()
    return server


def free_port():
    s = socket.socket()
    s.bind(('127.0.0.1', 0))
    port = s.getsockname()[1]
    s.close()
    return port


def make_certificates(folder):
    """A private CA and a localhost server certificate it signed (like a company TLS-inspection root)."""
    def run(*args):
        subprocess.run(args, cwd=folder, check=True, capture_output=True)
    run('openssl', 'req', '-x509', '-newkey', 'rsa:2048', '-nodes', '-keyout', 'ca.key', '-out', 'ca.pem', '-days', '2',
        '-subj', '/CN=Guardian Test Company Root', '-addext', 'basicConstraints=critical,CA:TRUE', '-addext', 'keyUsage=critical,keyCertSign,cRLSign')
    run('openssl', 'req', '-newkey', 'rsa:2048', '-nodes', '-keyout', 'server.key', '-out', 'server.csr', '-subj', '/CN=localhost')
    (folder / 'ext.cnf').write_text('subjectAltName=DNS:localhost,IP:127.0.0.1\nbasicConstraints=CA:FALSE\nkeyUsage=digitalSignature,keyEncipherment\nextendedKeyUsage=serverAuth\n')
    run('openssl', 'x509', '-req', '-in', 'server.csr', '-CA', 'ca.pem', '-CAkey', 'ca.key', '-CAcreateserial', '-out', 'server.pem', '-days', '2', '-extfile', 'ext.cnf')


class Guardian:
    def __init__(self, data, env=None):
        import os
        self.port = free_port()
        self.base = f'http://127.0.0.1:{self.port}'
        full_env = dict(os.environ)
        full_env.update(env or {})
        self.proc = subprocess.Popen(['java', '-jar', str(JAR), '--port', str(self.port), '--data', str(data)],
                                     stdout=subprocess.DEVNULL, stderr=subprocess.STDOUT, env=full_env)
        for _ in range(150):
            try:
                html = urllib.request.urlopen(self.base, timeout=1).read().decode()
                break
            except Exception:
                time.sleep(.2)
        self.token = re.search('name="guardian-token" content="([^"]+)"', html).group(1)

    def api(self, path, body):
        req = urllib.request.Request(self.base + '/api/' + path, data=json.dumps(body).encode(),
                                     headers={'X-Guardian-Token': self.token, 'Content-Type': 'application/json'})
        try:
            res = urllib.request.urlopen(req, timeout=90)
            return res.status, json.loads(res.read())
        except urllib.error.HTTPError as e:
            return e.code, json.loads(e.read() or b'{}')

    def configure(self, role, endpoint, model='fake-model', key='', timeout=35, header=''):
        settings = {r: {'endpoint': '', 'model': '', 'timeout': 35, 'maxTokens': 800, 'clearKey': True} for r in ('agent', 'vision', 'reviewer')}
        settings[role] = {'endpoint': endpoint, 'model': model, 'timeout': timeout, 'maxTokens': 800, 'key': key, 'clearKey': not key, 'keyHeader': header}
        return self.api('models', settings)

    def run(self, action, role, endpoint, **kw):
        code, saved = self.configure(role, endpoint, **kw)
        if code != 200:
            return code, saved.get('error', ''), saved
        code, out = self.api('models/' + action, {'role': role})
        text = out.get('text') or ', '.join(out.get('models', [])) if code == 200 else (out.get('error', '') + ' | ' + out.get('hint', ''))
        return code, text, out

    def stop(self):
        self.proc.terminate()
        try:
            self.proc.wait(timeout=10)
        except subprocess.TimeoutExpired:
            self.proc.kill()


with tempfile.TemporaryDirectory() as td:
    td = Path(td)
    plain = serve(ThreadingHTTPServer(('127.0.0.1', 0), FakeLLM))
    L = f'http://127.0.0.1:{plain.server_port}'
    make_certificates(td)
    secure = ThreadingHTTPServer(('0.0.0.0', 0), FakeLLM)  # reachable as 127.0.0.2 too, which the certificate does not name
    ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    ctx.load_cert_chain(td / 'server.pem', td / 'server.key')
    secure.socket = ctx.wrap_socket(secure.socket, server_side=True)
    serve(secure)
    S = f'https://localhost:{secure.server_port}'

    SCENARIOS = [
        # name, action, role, endpoint, options
        ('working server', 'test', 'agent', f'{L}/ok/v1', {}),
        ('vision test on a vision model', 'test', 'vision', f'{L}/ok/v1', {}),
        ('base address without /v1', 'test', 'agent', f'{L}/ok', {}),
        ('full chat/completions address pasted', 'test', 'agent', f'{L}/ok/v1/chat/completions', {}),
        ('wrong API key', 'test', 'agent', f'{L}/auth/v1', {'key': 'wrong-key'}),
        ('no API key set', 'test', 'agent', f'{L}/auth/v1', {}),
        ('right API key', 'test', 'agent', f'{L}/auth/v1', {'key': 'right-key'}),
        ('key pasted with "Bearer "', 'test', 'agent', f'{L}/auth/v1', {'key': 'Bearer right-key'}),
        ('gateway with x-api-key header', 'test', 'agent', f'{L}/xkey/v1', {'key': 'gateway-key', 'header': 'x-api-key'}),
        ('newer model rejects max_tokens and temperature', 'test', 'agent', f'{L}/new/v1', {}),
        ('thinking model returns only reasoning', 'test', 'agent', f'{L}/think/v1', {}),
        ('answer wrapped in <think> tags', 'test', 'agent', f'{L}/thinktag/v1', {}),
        ('answer as a list of parts', 'test', 'agent', f'{L}/parts/v1', {}),
        ('server streams although asked not to', 'test', 'agent', f'{L}/stream/v1', {}),
        ('sign-in web page instead of the API', 'test', 'agent', f'{L}/html/v1', {}),
        ('unknown model ID', 'test', 'agent', f'{L}/nomodel/v1', {}),
        ('vision test on a text-only model', 'test', 'vision', f'{L}/textonly/v1', {}),
        ('rate limited', 'test', 'agent', f'{L}/busy/v1', {}),
        ('endpoint redirects', 'test', 'agent', f'{L}/redirect/v1', {}),
        ('slow model', 'test', 'agent', f'{L}/slow/v1', {'timeout': 5}),
        ('Azure OpenAI deployment address', 'test', 'agent', f'{L}/openai/deployments/gpt4o/chat/completions?api-version=2024-10-21', {'key': 'azure-key'}),
        ('Azure address without api-version', 'test', 'agent', f'{L}/openai/deployments/gpt4o', {'key': 'azure-key'}),
        ('nothing listening', 'test', 'agent', 'http://127.0.0.1:9/v1', {}),
        ('unknown host name', 'test', 'agent', 'http://no-such-host.invalid/v1', {}),
        ('https:// to a plain-HTTP server', 'test', 'agent', f'https://127.0.0.1:{plain.server_port}/ok/v1', {}),
        ('http:// to an HTTPS-only server', 'test', 'agent', f'http://localhost:{secure.server_port}/ok/v1', {}),
        ('HTTPS with a company certificate', 'test', 'agent', f'{S}/ok/v1', {}),
        ('discover models', 'discover', 'agent', f'{L}/ok/v1', {}),
        ('discover models without /v1', 'discover', 'agent', f'{L}/ok', {}),
        ('discover on an Azure deployment address', 'discover', 'agent', f'{L}/openai/deployments/gpt4o?api-version=2024-10-21', {}),
    ]

    results = {}
    app = Guardian(td / 'data')
    try:
        for name, action, role, endpoint, options in SCENARIOS:
            results[name] = app.run(action, role, endpoint, **options)
            print(f'{name:48} -> HTTP {results[name][0]}: {results[name][1][:260]}', flush=True)
    finally:
        app.stop()

    app = Guardian(td / 'data2', {'GUARDIAN_CA_FILE': str(td / 'ca.pem')})
    try:
        trusted = app.run('test', 'agent', f'{S}/ok/v1')
        print(f'{"HTTPS, company root given in GUARDIAN_CA_FILE":48} -> HTTP {trusted[0]}: {trusted[1][:200]}', flush=True)
        wrong_name = app.run('test', 'agent', f'https://127.0.0.2:{secure.server_port}/ok/v1')
        print(f'{"same server, address not in its certificate":48} -> HTTP {wrong_name[0]}: {wrong_name[1][:200]}', flush=True)
    finally:
        app.stop()
    app = Guardian(td / 'data3', {'GUARDIAN_CA_FILE': str(td / 'missing.pem')})
    try:
        broken = app.run('test', 'agent', f'{S}/ok/v1')
        print(f'{"GUARDIAN_CA_FILE points at a missing file":48} -> HTTP {broken[0]}: {broken[1][:260]}', flush=True)
    finally:
        app.stop()

    ok = lambda n, want='OK': results[n][0] == 200 and results[n][1].strip() == want
    failed = lambda n, *words: results[n][0] != 200 and all(w.lower() in results[n][1].lower() for w in words)
    check('a working server answers OK', ok('working server'))
    check('the Vision test sends an image and gets an answer', ok('vision test on a vision model', 'Red'), results['vision test on a vision model'])
    check('a base address without /v1 is corrected automatically, with a note', ok('base address without /v1') and '/v1' in results['base address without /v1'][2].get('note', ''), results['base address without /v1'])
    check('a pasted .../chat/completions address works', ok('full chat/completions address pasted'))
    check("a wrong key shows the server's own reason", failed('wrong API key', 'incorrect api key', 'did not accept the key'), results['wrong API key'])
    check('a missing key says keys are per role and kept in memory', failed('no API key set', 'no api key is set for the agent role', 'GUARDIAN_AGENT_API_KEY'), results['no API key set'])
    check('the right key works', ok('right API key'))
    check('a key pasted with "Bearer " is not sent twice-prefixed', ok('key pasted with "Bearer "'))
    check('a custom key header (x-api-key) is sent instead of Authorization', ok('gateway with x-api-key header'), results['gateway with x-api-key header'])
    check('models that reject max_tokens/temperature work after automatic retries', ok('newer model rejects max_tokens and temperature') and 'max_completion_tokens' in results['newer model rejects max_tokens and temperature'][2].get('note', ''), results['newer model rejects max_tokens and temperature'])
    check('a reasoning-only answer says to raise Maximum response tokens', failed('thinking model returns only reasoning', 'reasoning', 'maximum response tokens'), results['thinking model returns only reasoning'])
    check('<think> text is removed from the answer', ok('answer wrapped in <think> tags'), results['answer wrapped in <think> tags'])
    check('an answer given as a list of parts is joined', ok('answer as a list of parts'), results['answer as a list of parts'])
    check('a streamed answer is joined', ok('server streams although asked not to'), results['server streams although asked not to'])
    check('a web page instead of the API is named, with its title', failed('sign-in web page instead of the API', 'web page', 'Company Sign In', 'API base URL'), results['sign-in web page instead of the API'])
    check('an unknown model ID points to Discover models', failed('unknown model ID', 'does not exist', 'discover models'), results['unknown model ID'])
    check('a text-only model in the Vision role is explained', failed('vision test on a text-only model', 'does not accept images'), results['vision test on a text-only model'])
    check('rate limits are explained', failed('rate limited', '429', 'rate limit'), results['rate limited'])
    check('a redirect names the new address and is not followed', failed('endpoint redirects', 'redirects', 'enter https://models.example.test/v1 as the API base URL'), results['endpoint redirects'])
    check('a slow model says to raise Timeout seconds', failed('slow model', 'within 5 seconds', 'timeout seconds'), results['slow model'])
    check('Azure OpenAI deployment addresses work with the api-key header', ok('Azure OpenAI deployment address'), results['Azure OpenAI deployment address'])
    check('an Azure address without api-version says how to fix it', failed('Azure address without api-version', 'api-version'), results['Azure address without api-version'])
    check('no server listening explains the refused connection', failed('nothing listening', 'could not connect', 'connection refused'), results['nothing listening'])
    check('an unknown host name is reported as such', failed('unknown host name', 'host name not found', 'no-such-host.invalid'), results['unknown host name'])
    check('https:// to a plain-HTTP server says to use http://', failed('https:// to a plain-HTTP server', 'http://'), results['https:// to a plain-HTTP server'])
    check('http:// to an HTTPS-only server suggests https://', failed('http:// to an HTTPS-only server', 'https://'), results['http:// to an HTTPS-only server'])
    check('an untrusted company certificate explains GUARDIAN_CA_FILE', failed('HTTPS with a company certificate', 'not trusted', 'GUARDIAN_CA_FILE'), results['HTTPS with a company certificate'])
    check('the company root in GUARDIAN_CA_FILE is trusted (host name still checked)', trusted is not None and trusted[0] == 200 and trusted[1] == 'OK', trusted)
    check('a trusted company root does not bypass the host-name check', wrong_name[0] != 200 and 'different host name' in wrong_name[1], wrong_name)
    check('an unreadable GUARDIAN_CA_FILE is reported instead of stopping Guardian', broken[0] != 200 and 'could not be used' in broken[1], broken)
    check('discover lists the model IDs', results['discover models'][0] == 200 and results['discover models'][2].get('models') == ['fake-model', 'fake-vision'], results['discover models'])
    check('discover also corrects a base address without /v1', results['discover models without /v1'][0] == 200 and results['discover models without /v1'][2].get('models') == ['fake-model', 'fake-vision'], results['discover models without /v1'])
    check('discover on an Azure deployment address returns the deployment name', results['discover on an Azure deployment address'][2].get('models') == ['gpt4o'], results['discover on an Azure deployment address'])
    if not REPORT:
        print('TOTAL', len(passed), 'model checks passed', flush=True)
    plain.shutdown()
    secure.shutdown()
