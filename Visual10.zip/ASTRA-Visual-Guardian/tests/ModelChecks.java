package guardian;

import java.util.*;
import static guardian.Json.*;

/**
 * Model-answer handling that does not need a server (CHANGES.md, "AI model connection").
 * The full connection behaviour is checked by model_test_check.py against stand-in servers.
 * Usage: java -cp classes:test-classes guardian.ModelChecks
 */
public class ModelChecks {
    static int passed = 0;

    static void check(String name, boolean ok) {
        if (!ok) throw new AssertionError(name);
        passed++;
        System.out.println("PASS " + name);
    }

    /** The project's JSON reader returns every number as a Double; compare as whole numbers. */
    static List<Integer> ints(Object list) {
        return list(list).stream().map(x -> num(x, -1)).toList();
    }

    static boolean fails(Runnable r) {
        try {
            r.run();
            return false;
        } catch (RuntimeException e) {
            return true;
        }
    }

    public static void main(String[] args) throws Exception {
        // The Agent's answer is JSON, but models wrap it in prose, fences or thinking text.
        check("plain JSON", ints(Models.jsonObject("{\"order\":[2,0,1]}").get("order")).equals(List.of(2, 0, 1)));
        check("JSON in a ``` fence with prose", ints(Models.jsonObject("Sure!\n```json\n{\"order\":[1]}\n```\nDone.").get("order")).equals(List.of(1)));
        check("braces inside <think> are ignored", ints(Models.jsonObject("<think>maybe {\"order\":[9]}?</think>{\"order\":[0]}").get("order")).equals(List.of(0)));
        check("a brace inside a JSON string does not end the object", ints(Models.jsonObject("{\"note\":\"a } b\",\"order\":[3]}").get("order")).equals(List.of(3)));
        check("invalid JSON before the real object is skipped", ints(Models.jsonObject("{not json} then {\"order\":[4]}").get("order")).equals(List.of(4)));
        check("no JSON is a clear error, not an index error", fails(() -> Models.jsonObject("I cannot rank these.")));

        check("<think> blocks are removed", Models.stripThinking("<think>plan</think>\nOK").equals("OK"));
        check("<thinking> blocks are removed", Models.stripThinking("<Thinking>x</Thinking>OK").equals("OK"));
        check("an unfinished <think> leaves nothing", Models.stripThinking("<think>ran out of tok").isEmpty());

        var a = Models.Address.of("https://api.example.com/v1/chat/completions/");
        check("a pasted chat/completions address becomes the base", a.base().equals("https://api.example.com/v1") && a.versioned());
        var az = Models.Address.of("https://acme.openai.azure.com/openai/deployments/gpt4o/chat/completions?api-version=2024-10-21");
        check("Azure: query kept aside and re-added", az.url("/chat/completions").equals("https://acme.openai.azure.com/openai/deployments/gpt4o/chat/completions?api-version=2024-10-21"));
        check("Azure: detected, deployment name read", az.azure() && az.deployment().equals("gpt4o"));
        check("Azure v1 address detected by host", Models.Address.of("https://acme.openai.azure.com/openai/v1").azure());
        check("Ollama root address is not versioned (so /v1 may be added)", !Models.Address.of("http://localhost:11434").versioned());
        check("Gemini-style /v1beta counts as versioned", Models.Address.of("https://x.example.com/v1beta/openai").versioned() || Models.Address.of("https://x.example.com/v1beta").versioned());

        check("server message from OpenAI-style error JSON", Models.serverMessage("{\"error\":{\"message\":\"Incorrect API key provided\"}}").equals("Incorrect API key provided"));
        check("server message from FastAPI validation errors", Models.serverMessage("{\"detail\":[{\"msg\":\"field required\"}]}").equals("field required"));
        check("server message names an HTML page by its title", Models.serverMessage("<html><head><title>Sign in</title></head></html>").contains("Sign in"));
        check("the key never appears in messages", Models.redact("bad key sk-secret-123456 for Bearer abc", "sk-secret-123456").equals("bad key [redacted] for Bearer [redacted]"));

        var parts = Models.answerText(obj("choices", List.of(obj("message", obj("content", List.of(obj("type", "text", "text", "O"), obj("type", "text", "text", "K")))))), 800);
        check("content given as a list of parts is joined", parts.equals("OK"));
        var streamed = Models.fromStream("data: {\"choices\":[{\"delta\":{\"content\":\"O\"}}]}\n\ndata: {\"choices\":[{\"delta\":{\"content\":\"K\"},\"finish_reason\":\"stop\"}]}\n\ndata: [DONE]\n");
        check("a streamed answer is joined", Models.answerText(streamed, 800).equals("OK"));
        boolean explained;
        try {
            Models.answerText(obj("choices", List.of(obj("finish_reason", "length", "message", obj("content", "", "reasoning_content", "thinking...")))), 800);
            explained = false;
        } catch (Models.ModelException e) {
            explained = e.reason.contains("800-token limit") && e.hint.contains("Maximum response tokens");
        }
        check("a reasoning-only answer cut at the limit names the limit and the setting", explained);

        var dir = java.nio.file.Files.createTempDirectory("models");
        var models = new Models(dir);
        boolean rejected;
        try {
            models.saveSettings(obj("agent", obj("endpoint", "https://x.example.com/v1", "model", "m", "keyHeader", "Host")));
            rejected = false;
        } catch (IllegalArgumentException e) {
            rejected = true;
        }
        check("reserved header names are refused as Key header", rejected);
        try {
            models.saveSettings(obj("agent", obj("endpoint", "https://x.example.com/v1", "model", "m", "key", "sk-abc\nsk-def")));
            rejected = false;
        } catch (IllegalArgumentException e) {
            rejected = true;
        }
        check("a key with a line break is refused with a clear message", rejected);
        models.saveSettings(obj("agent", obj("endpoint", "https://x.example.com/v1", "model", "m", "key", "  sk-abc  ", "timeout", 999, "maxTokens", 99999)));
        check("pasted keys are trimmed", models.key("agent").equals("sk-abc"));
        check("timeout is capped at 300 s and tokens at 32000", num(map(models.view().get("agent")).get("timeout"), 0) == 300 && num(map(models.view().get("agent")).get("maxTokens"), 0) == 32000);
        check("keys are not written to disk", !java.nio.file.Files.readString(dir.resolve("models.json")).contains("sk-abc"));
        System.out.println("TOTAL " + passed + " model checks passed");
    }
}
