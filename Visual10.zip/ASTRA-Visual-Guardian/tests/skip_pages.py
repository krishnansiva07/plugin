#!/usr/bin/env python3
"""
Real-browser test for the "Pages to skip" setting (CHANGES.md, "Pages to skip").

Usage:  GUARDIAN_TEST_BROWSER=/path/to/chrome python tests/skip_pages.py visual-guardian.jar

The fixture is a small portal. Every page has a header with Home, Shipments, Admin and Reports links.
  /admin, /admin/users     skipped by the path rule "/admin" (never requested)
  /administrator           NOT skipped: "/admin" must not match a longer name
  /audit ("Audit log")     reached by a button; skipped by "title: Audit log" (opened once, not recorded)
  /partner                 skipped by "label: Partner" (never requested)
The comparison run adds "/reports" and "label: Shipments", so Reports, Shipments and Shipment 7 (reached through
the Shipments link) are EXCLUDED without being opened, and the run still completes with a PASS.
"""
import collections, json, os, re, socket, subprocess, sys, tempfile, threading, time, urllib.error, urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

JAR = Path(sys.argv[1]).resolve()
BROWSER = os.environ.get('GUARDIAN_TEST_BROWSER', '/usr/bin/google-chrome')
passed = []
hits = collections.Counter()


def check(name, ok, detail=''):
    if not ok:
        raise AssertionError(f'{name} {detail}')
    passed.append(name)
    print('PASS', name, flush=True)


HEADER = '<header><nav><a href="/">Home</a> <a href="/shipments">Shipments</a> <a href="/admin">Admin</a> <a href="/reports">Reports</a></nav></header>'
PAGES = {
    '/': ('Portal home', '<h1>Portal home</h1><p><a href="/administrator">Administrator guide</a></p>'
                         '<p><a href="/partner">Partner portal</a></p>'
                         '<p><button type="button" onclick="location.href=\'/audit\'">Open audit</button></p>'),
    '/shipments': ('Shipments', '<h1>Shipments</h1><ul><li><a href="/shipments/7">Shipment 7</a></li></ul>'),
    '/shipments/7': ('Shipment 7', '<h1>Shipment 7</h1><p>Two items, shipped.</p>'),
    '/admin': ('Admin', '<h1>Admin</h1><a href="/admin/users">Users</a>'),
    '/admin/users': ('Users', '<h1>Users</h1>'),
    '/administrator': ('Administrator guide', '<h1>Administrator guide</h1><p>How to contact an administrator.</p>'),
    '/reports': ('Reports', '<h1>Reports</h1><p>Monthly totals.</p>'),
    '/audit': ('Audit log', '<h1>Audit log</h1><p>Sensitive entries.</p>'),
    '/partner': ('Partner portal', '<h1>Partner portal</h1>'),
}


class App(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass

    def do_GET(self):
        path = self.path.split('?')[0]
        if path not in PAGES:
            self.send_response(404); self.end_headers(); return
        hits[path] += 1
        title, body = PAGES[path]
        data = (f'<!doctype html><html><head><title>{title}</title></head><body style="font:16px Arial;margin:20px">'
                f'{HEADER}<main>{body}</main></body></html>').encode()
        self.send_response(200)
        self.send_header('Content-Type', 'text/html; charset=utf-8')
        self.send_header('Content-Length', str(len(data)))
        self.end_headers()
        self.wfile.write(data)


app = ThreadingHTTPServer(('127.0.0.1', 0), App)
threading.Thread(target=app.serve_forever, daemon=True).start()
URL = f'http://127.0.0.1:{app.server_port}/'

with tempfile.TemporaryDirectory() as td:
    data = Path(td) / 'data'
    sock = socket.socket(); sock.bind(('127.0.0.1', 0)); port = sock.getsockname()[1]; sock.close()
    base = f'http://127.0.0.1:{port}'
    env = dict(os.environ)
    if hasattr(os, 'geteuid') and os.geteuid() == 0:
        env['GUARDIAN_TEST_NO_SANDBOX'] = '1'
    log = (Path(td) / 'server.log').open('w')
    proc = subprocess.Popen(['java', '-jar', str(JAR), '--port', str(port), '--data', str(data)], stdout=log, stderr=subprocess.STDOUT, env=env)
    try:
        for _ in range(100):
            try:
                html = urllib.request.urlopen(base, timeout=1).read().decode(); break
            except Exception:
                time.sleep(.2)
        token = re.search('name="guardian-token" content="([^"]+)"', html).group(1)

        def call(path, body=None, expected=200, raw=False):
            req = urllib.request.Request(base + '/api/' + path, data=json.dumps(body).encode() if body is not None else None,
                                         headers={'X-Guardian-Token': token, 'Content-Type': 'application/json'})
            try:
                res = urllib.request.urlopen(req, timeout=30); code = res.status; out = res.read()
            except urllib.error.HTTPError as e:
                code = e.code; out = e.read()
            assert code == expected, (path, code, out[:400])
            return out.decode() if raw else json.loads(out)

        def wait(rid, timeout=420):
            end = time.time() + timeout
            while time.time() < end:
                r = call('runs/' + rid)
                if not r['active']:
                    return r
                time.sleep(.4)
            raise AssertionError(f'timeout: {r.get("status")} {r.get("message")}')

        rules = ['/admin', 'title: Audit log', 'label: Partner']
        cfg = dict(browser=BROWSER, headless=True, autoAuth=True, captureConsent=True, width=1000, height=800, settleMs=150,
                   pageSeconds=20, locatorSeconds=4, maxDepth=3, maxStates=40, maxActions=150, masks=[], skipPages=rules)
        suite = call('suites', dict(name='Skip fixture', url=URL, config=cfg))
        check('the suite keeps the rules', suite['config'].get('skipPages') == rules, str(suite['config'].get('skipPages')))
        rid = call('runs', dict(suiteId=suite['id'], mode='CAPTURE', target=URL, config=cfg))['id']
        cap = wait(rid)
        titles = sorted(s['title'] for s in cap['states'])
        setting = [x for x in cap['coverageExceptions'] if x['reason'].startswith('Skipped by suite setting')]
        others = [x for x in cap['coverageExceptions'] if not x['reason'].startswith('Skipped by suite setting')]
        print('CAPTURE', cap['status'], titles, flush=True)
        for x in setting:
            print('   skipped:', x['reason'], '|', x.get('label'), '|', x.get('url'), flush=True)
        check('pages that match no rule are captured', titles == ['Administrator guide', 'Portal home', 'Reports', 'Shipment 7', 'Shipments'], str(titles))
        check('"/admin" does not skip /administrator', 'Administrator guide' in titles)
        check('links to skipped paths are never clicked (/admin, /admin/users never requested)', hits['/admin'] == 0 and hits['/admin/users'] == 0, str(hits))
        check('label: rules stop the click (/partner never requested)', hits['/partner'] == 0, str(hits))
        check('a page reached by a button and matching a title: rule is not recorded', 'Audit log' not in titles and hits['/audit'] >= 1, str(hits))
        reasons = sorted({x['reason'] for x in setting})
        check('each rule appears once in the coverage exceptions, with the address',
              reasons == ['Skipped by suite setting: /admin', 'Skipped by suite setting: label: Partner', 'Skipped by suite setting: title: Audit log']
              and len(setting) == 3 and {x.get('url') for x in setting} == {'/admin', '/partner', '/audit'}, str([(x['reason'], x.get('url')) for x in setting]))
        check('setting skips need no review', all(x['reviewed'] for x in setting))
        check('the capture completes without a coverage review', cap['status'] == 'COMPLETED' and not others, f"{cap['status']} {[x['reason'] for x in others]}")
        events = ' '.join(e['message'] for e in cap['events'])
        check('the events say which page was skipped and why', 'Skipped /audit (suite setting "title: Audit log")' in events)

        call('approve', dict(id=rid))
        hits.clear()
        more = rules + ['/reports', 'label: Shipments']
        rep = call('runs', dict(suiteId=suite['id'], mode='REPLAY', target=URL, referenceId=rid, config=dict(captureConsent=True, skipPages=more)))
        rep = wait(rep['id'])
        status = {x['title']: x['status'] for x in rep['results']}
        print('REPLAY', rep['status'], status, '|', rep['verdict'], flush=True)
        check('baseline pages matching a rule are EXCLUDED: by address, and by a skipped step on the way (Shipments > Shipment 7)',
              status == {'Portal home': 'PASSED', 'Administrator guide': 'PASSED', 'Reports': 'EXCLUDED', 'Shipments': 'EXCLUDED', 'Shipment 7': 'EXCLUDED'}, str(status))
        check('excluded pages are not opened during the comparison', hits['/reports'] == 0 and hits['/shipments'] == 0 and hits['/shipments/7'] == 0, str(hits))
        check('excluded results name the rule', {x['reason'] for x in rep['results'] if x['status'] == 'EXCLUDED'} == {'Skipped by suite setting: /reports', 'Skipped by suite setting: label: Shipments'})
        check('a comparison with exclusions still completes and passes', rep['status'] == 'COMPLETED' and rep['verdict'] == 'PASS — selected captured states only; 3 excluded by suite setting', f"{rep['status']} {rep['verdict']}")
        report = call(f"runs/{rep['id']}/report.html", raw=True)
        check('the HTML report lists the exclusions', report.count('Skipped by suite setting') >= 3 and '3 excluded by suite setting' in report)
        rerun = call('runs', dict(suiteId=suite['id'], mode='REPLAY', target=URL, referenceId=rid, parentId=rep['id'], selection='INCOMPLETE', config=dict(captureConsent=True, skipPages=more)), expected=400)
        check('"rerun incomplete" does not pick excluded pages (nothing to rerun)', 'No matching baseline states' in rerun.get('error', ''), str(rerun))
        print('TOTAL', len(passed), 'skip-page checks passed', flush=True)
    finally:
        proc.terminate()
        try:
            proc.wait(timeout=15)
        except subprocess.TimeoutExpired:
            proc.kill()
        log.close()
        app.shutdown()
