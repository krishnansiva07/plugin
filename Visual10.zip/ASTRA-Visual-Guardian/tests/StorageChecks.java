package guardian;

import java.nio.file.*;
import java.util.*;
import static guardian.Json.*;
import static guardian.Util.*;

/** Storage-format checks for the light run.json + per-state detail files (see CHANGES.md, item 4). */
public class StorageChecks {
    static int passed = 0;

    static void check(String name, boolean ok) {
        if (!ok) throw new AssertionError(name);
        passed++;
        System.out.println("PASS " + name);
    }

    public static void main(String[] args) throws Exception {
        Path root = Files.createTempDirectory("guardian-storage");
        try {
            var store = new Store(root);
            // A run in the earlier format: DOM snapshot and structure inline in run.json.
            var states = new ArrayList<Object>();
            for (int i = 0; i < 3; i++) {
                var dom = obj("title", "Page " + i, "visibleText", "Text " + i, "headings", List.of("Heading " + i),
                        "elements", List.of(obj("tag", "a", "role", "a", "label", "Link " + i, "css", "a:nth-of-type(" + (i + 1) + ")", "href", "/p" + i, "options", List.of())),
                        "dialogs", List.of());
                states.add(obj("id", "state" + i, "fingerprint", "fp" + i, "title", "Page " + i, "route", "/p" + i, "path", List.of(),
                        "dom", dom, "structure", Engine.structure(dom), "image", "images/state" + i + ".png", "imageHash", "x"));
            }
            var legacy = obj("id", "run-legacy", "suiteId", "suite", "mode", "CAPTURE", "status", "INCOMPLETE", "created", now(), "updated", now(),
                    "states", states, "queue", new ArrayList<>(), "skipped", new ArrayList<>(), "issues", new ArrayList<>(),
                    "results", new ArrayList<>(), "config", Store.config(obj()));
            save(store.runPath("run-legacy"), legacy);

            var loaded = store.run("run-legacy");
            check("older run.json with inline page details still loads", list(loaded.get("states")).stream().allMatch(o -> map(o).containsKey("dom")));
            store.saveRun(loaded);
            var onDisk = load(store.runPath("run-legacy"));
            check("saving moves page details out of run.json",
                    list(onDisk.get("states")).stream().noneMatch(o -> map(o).containsKey("dom") || map(o).containsKey("structure")));
            try (var files = Files.list(store.dir("run-legacy").resolve("states"))) {
                check("one detail file per captured page", files.count() == 3);
            }
            var first = map(list(onDisk.get("states")).get(0));
            check("page details come back for comparison",
                    Engine.structure(map(map(states.get(0)).get("dom"))).equals(strings(store.hydrate("run-legacy", first).get("structure"))));
            check("DOM evidence is found for baseline approval", store.stateDom("run-legacy", first) != null);
            check("records held in memory become light after saving", list(loaded.get("states")).stream().noneMatch(o -> map(o).containsKey("dom")));

            var summaries = store.runSummaries();
            check("execution list summary reflects the run", summaries.size() == 1
                    && num(map(summaries.get(0)).get("states"), 0) == 3 && s(map(summaries.get(0)), "status").equals("INCOMPLETE"));
            loaded.put("status", "STOPPED");
            loaded.put("updated", now());
            store.saveRun(loaded);
            check("summary follows saves", s(store.summary("run-legacy"), "status").equals("STOPPED"));
            var edited = load(store.runPath("run-legacy"));
            edited.put("status", "ERROR");
            edited.put("message", "Edited outside the application");
            save(store.runPath("run-legacy"), edited);
            check("summary notices edits made outside the application", s(store.summary("run-legacy"), "status").equals("ERROR"));

            var action = obj("action", "SELECT", "tag", "select", "role", "select", "label", "Branch", "css", "#branch", "href", "",
                    "option", "Chennai", "index", 3, "options", List.of(obj("label", "Chennai", "index", 3)),
                    "external", false, "query", false, "disabled", false, "expanded", "", "selected", "");
            var compact = Engine.compactAction(action);
            check("compact path steps keep the same action identity",
                    Engine.actionKey(action).equals(Engine.actionKey(compact)) && !compact.containsKey("options") && s(compact, "option").equals("Chennai"));
        } finally {
            removeTree(root);
        }
        System.out.println("TOTAL " + passed + " storage checks passed");
    }
}
