package guardian;

import java.util.*;
import static guardian.Json.*;

/**
 * The "Pages to skip" rules (CHANGES.md, "Pages to skip").
 * Usage: java -cp classes:test-classes guardian.SkipChecks
 */
public class SkipChecks {
    static int passed = 0;

    static void check(String name, boolean ok) {
        if (!ok) throw new AssertionError(name);
        passed++;
        System.out.println("PASS " + name);
    }

    static Skips rules(String... lines) {
        return new Skips(List.of((Object[]) lines));
    }

    public static void main(String[] args) {
        String app = "https://bank.example.com";
        var s = rules("/admin", "/reports/*/export", "#/settings", "logout", "title: Audit log", "label: Delete", app + "/legacy/");

        check("a path rule skips that page", s.url(app + "/admin").equals("/admin"));
        check("a path rule skips pages below it", s.url(app + "/admin/users?page=2").equals("/admin"));
        check("a path rule skips the page with a query or fragment", s.url(app + "/admin?tab=roles").equals("/admin") && s.url(app + "/admin#top").equals("/admin"));
        check("a path rule does not skip a longer name (/administrator)", s.url(app + "/administrator").isEmpty());
        check("a path rule also matches under a context path (/bank/admin)", s.url(app + "/bank/admin/users").equals("/admin"));
        check("a path rule does not look at the host name", rules("/admin").url("https://admin.example.com/home").isEmpty());
        check("matching ignores case", s.url(app + "/ADMIN/Users").equals("/admin"));
        check("* matches anything", s.url(app + "/reports/2026/q3/export").equals("/reports/*/export") && s.url(app + "/reports/q3/view").isEmpty());
        check("#/route rules match single-page-app routes", s.url(app + "/app#/settings/profile").equals("#/settings") && s.url(app + "/app#/settingsx").isEmpty());
        check("plain text matches anywhere in the address", s.url(app + "/auth/logout?next=/").equals("logout"));
        check("a full-address rule matches that address and below", s.url(app + "/legacy/a/b").equals(app + "/legacy/") && s.url(app + "/legacy").equals(app + "/legacy/"));
        check("a full-address rule does not match another host", s.url("https://other.example.com/legacy/a").isEmpty());
        check("percent-encoded addresses match decoded rules", rules("/rapports/année").url(app + "/rapports/ann%C3%A9e/2026").equals("/rapports/année"));
        check("title: rules match page titles (case-insensitive, contains)", s.page(app + "/x", "Bank — AUDIT LOG").equals("title: Audit log"));
        check("title: rules do not match addresses", s.page(app + "/audit-log", "Bank").isEmpty());
        check("label: rules match link and button text", s.control("Delete account", "").equals("label: Delete"));
        check("label: rules do not match page titles", s.page(app + "/x", "Delete history").isEmpty());
        check("a control is also skipped by its link address", s.control("Users", app + "/admin/users").equals("/admin"));
        check("an ordinary control is kept", s.control("Accounts", app + "/accounts").isEmpty());
        var path = List.<Object>of(obj("label", "Menu", "href", ""), obj("label", "Admin area", "href", "/admin"), obj("label", "Users", "href", "/admin/users"));
        check("a recorded path is skipped when any step is skipped", s.path(path, app).equals("/admin"));
        check("a recorded path without skipped steps is kept", s.path(List.of(obj("label", "Accounts", "href", "/accounts")), app).isEmpty());
        check("url: prefix is accepted for address rules", rules("url: /admin").url(app + "/admin/x").equals("url: /admin"));
        check("blank lines are ignored", rules("", "  ", "/a").rules.size() == 1);
        check("rules are limited to 200", new Skips(Collections.nCopies(500, "/x")).rules.size() == Skips.MAX_RULES);
        check("regex characters in rules are literal", rules("/a.b(1)").url(app + "/a.b(1)/c").equals("/a.b(1)") && rules("/a.b(1)").url(app + "/aXb(1)").isEmpty());
        check("setting skips need no coverage review", Coverage.inherent(obj("reason", Skips.reason("/admin"), "label", "Admin")));
        check("other skips still need review", !Coverage.inherent(obj("reason", "potentially mutating action", "label", "Delete")));
        check("old coverage keys are unchanged (no url field)", Coverage.key(obj("stateId", "s1", "label", "A", "reason", "r")).equals(
                Util.hash(obj("stateId", "s1", "label", "A", "reason", "r", "path", null, "element", null))));
        check("Store.config keeps the rules", Store.config(obj("skipPages", List.of("/admin", " ", "title: x"))).get("skipPages").equals(List.of("/admin", "title: x")));
        System.out.println("TOTAL " + passed + " skip-rule checks passed");
    }
}
