package guardian.boot;

import guardian.Api;
import guardian.Main;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Map;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.core.env.Environment;

/**
 * Spring Boot front door for ASTRA Visual Guardian.
 *
 * Same engine, data folder and UI as the dependency-free jar (guardian.Main): Spring MVC serves the same
 * endpoints by calling the same {@link Api}. Build with "mvn package", run with
 * "java -jar target/visual-guardian-spring.jar". It accepts the plain jar's options (--port 8765 --data folder)
 * as well as Spring's own (--server.port=8765 --guardian.data=folder).
 *
 * Like the plain jar it listens on 127.0.0.1 only; LocalOnlyGuard also refuses non-local callers if
 * server.address is ever changed.
 */
@SpringBootApplication
public class GuardianApplication {

    public static void main(String[] args) {
        System.setProperty("java.awt.headless", "true");
        Main.useSystemProxies();
        SpringApplication app = new SpringApplication(GuardianApplication.class);
        app.setDefaultProperties(Map.of(
                "server.address", "127.0.0.1",
                "server.port", "8765",
                "guardian.data", "guardian-data",
                "spring.web.resources.add-mappings", "false",
                "server.error.whitelabel.enabled", "false",
                "spring.main.banner-mode", "off"));
        app.run(springArgs(args));
    }

    /** "--port 8765 --data folder" (the plain jar's options) become "--server.port=8765 --guardian.data=folder". */
    static String[] springArgs(String[] args) {
        var out = new ArrayList<String>();
        for (int i = 0; i < args.length; i++) {
            if (args[i].equals("--port") && i + 1 < args.length) out.add("--server.port=" + args[++i]);
            else if (args[i].equals("--data") && i + 1 < args.length) out.add("--guardian.data=" + args[++i]);
            else out.add(args[i]);
        }
        return out.toArray(String[]::new);
    }

    /** The data folder is locked while this bean lives; closing it stops running executions and their browsers. */
    @Bean(destroyMethod = "close")
    public Api guardianApi(@Value("${guardian.data}") String data) throws Exception {
        return Api.open(Path.of(data));
    }

    @Bean
    public ApplicationRunner announce(Environment environment, Api api) {
        return args -> {
            System.out.println("ASTRA Visual Guardian (Spring Boot) — http://127.0.0.1:" + environment.getProperty("local.server.port"));
            System.out.println("Data: " + api.root());
        };
    }
}
