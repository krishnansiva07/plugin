package guardian.boot;

import guardian.Api;
import jakarta.servlet.http.HttpServletRequest;
import java.util.Map;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/** Anything not mapped elsewhere: 404 for unknown addresses, 405 for unsupported methods (same answers as the plain jar). */
@RestController
public class FallbackController {

    @RequestMapping("/**")
    public ResponseEntity<byte[]> other(HttpServletRequest request) {
        if (!request.getMethod().equals("GET")) return Replies.of(Api.methodNotAllowed());
        return Replies.of(request.getRequestURI().startsWith("/api/") ? Api.unknown() : Api.Reply.json(404, Map.of("error", "Not found")));
    }
}
