package guardian.boot;

import guardian.Api;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/** Settings for the optional AI roles (Agent, Vision, Reviewer), model discovery and the connection test. */
@RestController
@RequestMapping("/api/models")
public class ModelController {
    private final Api api;

    public ModelController(Api api) {
        this.api = api;
    }

    @GetMapping
    public ResponseEntity<byte[]> settings() throws Exception {
        return Replies.of(api.modelSettings());
    }

    @PostMapping
    public ResponseEntity<byte[]> save(HttpServletRequest request) throws Exception {
        return Replies.of(api.saveModelSettings(Replies.body(request, Api.JSON_LIMIT)));
    }

    @PostMapping("/discover")
    public ResponseEntity<byte[]> discover(HttpServletRequest request) throws Exception {
        return Replies.of(api.discoverModels(Replies.body(request, Api.JSON_LIMIT)));
    }

    /** On failure the answer carries "error" (what happened) and "hint" (what to change). */
    @PostMapping("/test")
    public ResponseEntity<byte[]> test(HttpServletRequest request) throws Exception {
        return Replies.of(api.testModel(Replies.body(request, Api.JSON_LIMIT)));
    }
}
