package guardian.boot;

import guardian.Api;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

/** Errors become the same JSON answers as in the plain jar: {"error": what happened, "hint": what to change}. */
@RestControllerAdvice
public class ApiErrors {
    @ExceptionHandler(Exception.class)
    public ResponseEntity<byte[]> failed(Exception ex) {
        return Replies.of(Api.error(ex));
    }
}
