package guardian.boot;

import guardian.Api;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

/** The UI: one page, its script and its style sheet. The page carries this session's API token. */
@RestController
public class PageController {
    private final Api api;

    public PageController(Api api) {
        this.api = api;
    }

    @GetMapping({"/", "/app.js", "/style.css"})
    public ResponseEntity<byte[]> page(HttpServletRequest request) throws Exception {
        return Replies.of(api.page(request.getRequestURI()));
    }
}
