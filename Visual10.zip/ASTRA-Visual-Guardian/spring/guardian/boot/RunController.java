package guardian.boot;

import guardian.Api;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/** Executions: capture a baseline, compare (replay) against it, review coverage, approve, reports and evidence. */
@RestController
@RequestMapping("/api")
public class RunController {
    private final Api api;

    public RunController(Api api) {
        this.api = api;
    }

    @GetMapping("/runs")
    public ResponseEntity<byte[]> runs() throws Exception {
        return Replies.of(api.runs());
    }

    /** One run; "since" lets the UI poll cheaply (an unchanged run gets a short answer). */
    @GetMapping("/runs/{id}")
    public ResponseEntity<byte[]> run(@PathVariable("id") String id,
                                      @RequestParam(name = "since", required = false, defaultValue = "") String since) throws Exception {
        return Replies.of(api.run(id, since));
    }

    /** report.html, report.xlsx, baseline.zip or execution.zip. */
    @GetMapping("/runs/{id}/{file}")
    public ResponseEntity<byte[]> file(@PathVariable("id") String id, @PathVariable("file") String file) throws Exception {
        return Replies.of(api.runFile(id, file));
    }

    /** Screenshots: images/, diffs/ and reference-images/. */
    @GetMapping("/runs/{id}/{folder}/{name}")
    public ResponseEntity<byte[]> image(@PathVariable("id") String id, @PathVariable("folder") String folder,
                                        @PathVariable("name") String name) throws Exception {
        return Replies.of(api.runFile(id, folder + "/" + name));
    }

    @PostMapping("/runs")
    public ResponseEntity<byte[]> start(HttpServletRequest request) throws Exception {
        return Replies.of(api.startRun(Replies.body(request, Api.JSON_LIMIT)));
    }

    @PostMapping("/runs/resume")
    public ResponseEntity<byte[]> resume(HttpServletRequest request) throws Exception {
        return Replies.of(api.resumeRun(Replies.body(request, Api.JSON_LIMIT)));
    }

    /** Pause, continue, stop and the other run commands. */
    @PostMapping("/runs/command")
    public ResponseEntity<byte[]> command(HttpServletRequest request) throws Exception {
        return Replies.of(api.command(Replies.body(request, Api.JSON_LIMIT)));
    }

    @PostMapping("/coverage/review")
    public ResponseEntity<byte[]> review(HttpServletRequest request) throws Exception {
        return Replies.of(api.reviewCoverage(Replies.body(request, Api.JSON_LIMIT)));
    }

    @PostMapping("/approve")
    public ResponseEntity<byte[]> approve(HttpServletRequest request) throws Exception {
        return Replies.of(api.approve(Replies.body(request, Api.JSON_LIMIT)));
    }

    @PostMapping("/compare")
    public ResponseEntity<byte[]> compare(HttpServletRequest request) throws Exception {
        return Replies.of(api.compare(Replies.body(request, Api.JSON_LIMIT)));
    }
}
