package guardian.boot;

import guardian.Api;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/** Application suites (an application URL plus its settings) and importing exported baselines. */
@RestController
@RequestMapping("/api")
public class SuiteController {
    private final Api api;

    public SuiteController(Api api) {
        this.api = api;
    }

    @GetMapping("/suites")
    public ResponseEntity<byte[]> suites() throws Exception {
        return Replies.of(api.suites());
    }

    @PostMapping("/suites")
    public ResponseEntity<byte[]> create(HttpServletRequest request) throws Exception {
        return Replies.of(api.createSuite(Replies.body(request, Api.JSON_LIMIT)));
    }

    /** A baseline.zip or execution.zip exported by another Guardian. */
    @PostMapping("/import")
    public ResponseEntity<byte[]> importZip(HttpServletRequest request) throws Exception {
        return Replies.of(api.importZip(Replies.body(request, Api.ZIP_LIMIT)));
    }
}
