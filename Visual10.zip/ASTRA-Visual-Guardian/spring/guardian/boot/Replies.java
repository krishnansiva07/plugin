package guardian.boot;

import guardian.Api;
import jakarta.servlet.http.HttpServletRequest;
import java.io.IOException;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;

/** Converts between Spring MVC and {@link Api}: request bodies in (with size limits), answers out. */
final class Replies {
    private Replies() {
    }

    static ResponseEntity<byte[]> of(Api.Reply reply) {
        ResponseEntity.BodyBuilder builder = ResponseEntity.status(reply.status()).contentType(MediaType.parseMediaType(reply.type()));
        if (!reply.filename().isBlank()) builder = builder.header("Content-Disposition", "attachment; filename=\"" + reply.filename() + "\"");
        return builder.body(reply.body());
    }

    /** The request body, refusing more than max bytes (2 MB for JSON, 128 MB for ZIP imports). */
    static byte[] body(HttpServletRequest request, int max) throws IOException {
        return Api.readLimited(request.getInputStream(), max);
    }
}
