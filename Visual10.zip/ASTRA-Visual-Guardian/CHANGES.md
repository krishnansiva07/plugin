# Changes — 26 November 2026, release 4 (organized exploration)

## 9. Page-by-page exploration without repeated navigation

**What was wrong.** Exploration was breadth-first: each page's controls went to the back of one long queue, and
every path that did not continue from the current page started again from the home page and repeated all its
clicks. Shared controls were queued again from every page (the header menu, a Notifications drop-down, a toolbar
"Help" button, footer links), so most clicks landed on pages that were already captured, and drop-downs were captured
once per page. On an 11-page test portal (`tests/organized_exploration.py`) the previous version needed 590 s,
694 page loads, 213 restarts from the home page and 214 landings on known pages, and captured 26 states.

**Now** (`Exploration.java` new, `Engine.java`, `Browser.java`):

- **Page by page** (default): the controls of a newly captured page are explored first, in reading order; when
  everything under that page is done, Guardian goes back to the page it came from and continues there.
- **Going back instead of starting over**: back in history to the page's address, a reload for in-page views (open
  drop-down, panel, tab), or loading the address; accepted only if the page looks exactly as when captured
  (scroll position restored first). Starting from the home page is now the last resort.
- **Not opened again**: links to the current page or to pages already explored or waiting; shared header, menu-bar and
  footer controls after their first time; controls that led to the same page from two different pages; open
  drop-downs; selected tabs. Checked before queuing and again just before clicking.
- Captured pages record the page they were reached from and their depth: the UI and the report show a tree. New
  counters: Back navigations, Navigations avoided, Starts from home page.
- New setting **Exploration order** (suite and per execution): "Page by page" (default) or "Level by level" (the old
  breadth-first order, useful for very large applications under a tight state budget).

Same portal now: 25 s, 14 page loads, 0 restarts from the home page, 107 navigations avoided, 2 landings on known
pages, 14 states (each page once; the only same-address variants are the drop-down, the filter panel and the Yearly
tab). A comparison run against that baseline passes 14/14.

**Compatibility.** Baselines and runs from earlier versions replay unchanged. A resumed older capture continues page by
page; its earlier pages are listed without a parent.

---

# Changes — 26 November 2026, release 3 (AI connection, Pages to skip, Spring Boot)

## 6. AI model connection: "Test connection" now works with more servers and says what is wrong

**Why it failed before.** Every problem came back as a bare status such as "Model endpoint returned HTTP 404", with
the server's explanation thrown away, and several common set-ups could not work at all. Against 33 stand-in server
situations the previous version connected in 6 (two of those returned the model's hidden reasoning or a raw list as
the answer). Typical causes:

- the API base URL without `/v1` (Ollama, LM Studio, vLLM);
- a key kept in memory only, so lost after restart, or entered for one role but tested on another;
- Azure OpenAI addresses (the `?api-version=` query was broken and the key went in the wrong header);
- gateways that want the key in `x-api-key`, or a key pasted with "Bearer ";
- newer models that reject `max_tokens` or `temperature`;
- "thinking" models that return reasoning instead of an answer, or wrap the answer in `<think>`;
- company networks: a proxy Java did not use, or HTTPS inspection certificates Java does not trust;
- slow first load of local models.

**Now** (`Models.java`, rewritten):

- Every failure has a reason (with the server's own words) and a fix, shown under the role's buttons and in the notice.
- Adds a missing `/v1` automatically and tells you; accepts a pasted `.../chat/completions` address.
- Azure OpenAI: query kept, `api-key` header used, deployment name offered by "Discover models".
- New optional **Key header** per role (for example `x-api-key`); a pasted "Bearer " prefix is handled; keys are trimmed and
  keys with line breaks are refused with a clear message.
- Retries automatically with `max_completion_tokens` and without `temperature` when the server asks.
- Removes `<think>` blocks; joins answers given in parts or streamed; explains reasoning-only answers.
- Uses the system proxy for remote servers (never for this computer); `GUARDIAN_PROXY` overrides.
- Trusts the Windows certificate store (and macOS keychain) besides Java's; `GUARDIAN_CA_FILE` adds a company root.
  Host names are still checked.
- Redirects are reported with the new address, never followed (the key is never sent elsewhere).
- Timeout up to 300 s, response tokens up to 32,000.
- During an execution a role that fails 3 times is turned off for the rest of it, instead of adding a timeout to every page.
- The Agent's JSON is found inside prose, code fences or thinking text.

## 7. Pages to skip

New suite setting (also per execution): one rule per line — a path (`/admin` covers `/admin/users`, not
`/administrator`), `*` wildcards, `#/route`, a full address, any text in the address, `title: …` or `label: …`.
Capture never clicks matching links or controls and never records matching pages; comparison runs mark matching
baseline pages **EXCLUDED** without opening them. Exclusions are listed in the report, need no review, and do not stop
a PASS. Files: `Skips.java` (new), `Engine.java`, `Store.java`, `Coverage.java`, `Report.java`, UI.

## 8. Spring Boot front door, and how it all works

- The endpoints moved from `Main.java` into `Api.java`, which has no web-server code. `Main.java` (built-in server) is now
  a small adapter, and the new `spring/` folder adds Spring Boot 4.1 controllers around the same `Api`. `pom.xml` builds
  `target/visual-guardian-spring.jar`. The plain jar is unchanged for users and still needs no downloads.
- `ARCHITECTURE.md` explains the components, a run from start to finish, exploration, sign-in, comparison, AI roles,
  data on disk, and has a feature checklist for deciding what to keep or remove.

**Not verified here:** the Spring Boot jar was not built or run, because package downloads were turned off in this
environment. Its classes were compiled against stand-ins for the Spring and Servlet classes they use, and every
endpoint goes through `Api`, which is covered by all tests through the plain jar. Build and smoke-test it with
`mvn package` before relying on it.

## Also fixed

- Starting or resuming an execution could answer "ConcurrentModificationException" (HTTP 400) even though the run
  started: the answer was written while the new run thread was already changing it. Present since the original
  version and timing-dependent; seen once in the coverage test during this release. Start and resume now answer with a
  copy taken before the run thread starts.

**Compatibility.** Data, settings and ZIPs from earlier versions work unchanged. Old coverage review IDs are unchanged.

---

# Changes — 25–26 November 2026 (blocker and locator fixes)

Four problems that stopped real runs are fixed, plus one start-up race found while testing. Existing data keeps working (see Compatibility).

## 1. Sign-in detection no longer misfires, and you can override it

The old check treated a page as a sign-in page when, for example:

- any field name contained "pin" (`pincode`, `branchMapping`, even the standard `shipping` address field),
- any link started with "Login" ("Login history"),
- the page text started with "Please wait",
- or the word "login" appeared anywhere in the text ("Last login: …") next to a user field.

Clicking **Return control** could not override it, so a run could wait forever.

Now a page counts as a sign-in step only with a strong signal:

- exactly one visible password box (change-password forms have two or more);
- a one-time-code or PIN field **and** wording about it (OTP, verification code, PIN, two-step, authenticator) in the title, headings or labels. A field named `pincode` or `pin_code` (postal PIN) does not count;
- a username box, a sign-in button (Sign in, Log in, Continue, Next) and a "Sign in"-style title, on a page with few controls;
- only a "Sign in" or "Sign in with …" button on a nearly empty page.

"Please wait" or "Redirecting" now means "still loading" only on a nearly empty page, and never means sign-in.

**New optional suite settings** (also in the Start execution form, so existing suites can use them):

- **Logged-in marker**: a CSS selector visible only after sign-in, for example `a[href*=logout]`. When it is visible, the page is never treated as sign-in.
- **Sign-in page addresses**: text that appears in the sign-in page URL, for example `/Login.aspx`. Matching pages always count as sign-in.
- **Other application hosts**: see item 2.

**Return control override.** If the page still looks like sign-in, or is on another host, the run says why and asks you to click Return control again. The second click continues, and the overridden check is ignored for the rest of that run.

**Session expiry is still caught.** Sign-in addresses seen while you log in are remembered for the run, so a later session expiry is detected even after you override a check.

## 2. Redirects to the same application are accepted

- The application is now identified by its host. Any scheme or port on the host you entered is accepted automatically everywhere: while waiting for sign-in, while crawling, and in the request filter. So are its `www` variant and redirects such as http → https or :80 → :8443.
- A different host (for example `bms.bank.local` → `bms2.bank.local`) is accepted when it is listed in **Other application hosts** (`*.bank.local` is allowed), or when you confirm it with Return control twice. Confirmed hosts are kept with the run for resume.

## 3. Sign-in retries are limited

- **Capture:** a path that leads to a sign-in step again after 2 fresh sign-ins is set aside as a coverage exception ("Sign-in requested again on this path …"), and the run continues. Review or exclude it like other exceptions, or use **Resume / recover coverage** to try it again.
- **Replay:** the same situation marks that page FAILED ("Target asked for sign-in again …") instead of looping.

## 4. Saving and the history screen stay fast as runs grow

- **Page data in separate files.** Each page's DOM snapshot and structure are written once to `runs/<run>/states/<state>.json`. `run.json` keeps only a small record per page.
- **Fewer saves.** Per-click checkpoints are written at most every 2 seconds. Path completions and status changes are always written straight away.
- **Smaller path records.** Path steps in the queue, journal and issues drop bulky fields, such as dropdown option lists.
- **No rescanning.** Visited-action and exclusion de-duplication use in-memory indexes instead of rescanning and re-hashing whole lists after every path.
- **Cheaper polling.** The execution list comes from cached summaries. The open run is polled with `?since=`, and the server answers "unchanged" when nothing changed. UI reads no longer wait for the crawler's writes.

Measured on a synthetic run of 500 pages × 200 controls:

| | Before | After |
|---|---|---|
| `run.json` size | 41.9 MB | 2.6 MB |
| One save | 438 ms | 29 ms |
| Saves per explored path | 5–14 | about 1 |

## 5. Controls that share a label are found reliably (26 November 2026)

**Before:** when several controls had the same label, a step failed with "Ambiguous element". Examples are "Home" in both the header and footer, or a "Details" link and "View" button on every table row. A label whose count changed ("Alerts (3)" → "Alerts (4)") failed with "Element missing". On a small test page this broke 15 paths, and only 2 of the 10 pages were captured.

**Now** one of several look-alikes is chosen only when something identifies it:

- **Link address.** Repeated links to the same address are interchangeable.
- **Row text.** This is the text of its table row or list item, such as account number and name. It still works after rows are reordered or a value in the row changes.
- **Counter.** A label that differs only in a count, such as "(3)", "[12]" or "5 new/unread/pending", is the same control.
- **Exact position, while capturing only.** The path was found on that same page moments earlier.

**Still never:** a replay never chooses by position; identical look-alikes are not clicked; "View 123" is still not "View 456". The message now says why, for example "Ambiguous element: View (3 look-alikes; no id, link address, row text or position tells them apart)".

**Older steps:** recorded steps now include the row text (`context`). Steps recorded by earlier versions don't have it: while capturing or resuming they fall back to exact position, and in replay they stay as strict as before. For the most reliable replay after migration, capture the baseline again with this version before migrating.

Tests: `tests/locator_fixes.py` (real browser, 6 checks), `tests/LocatorEvidenceChecks.java` (9 checks), `tests/locator_context_dom.js` (3 checks).

## Also fixed

- **Browser start-up race.** Chrome creates `DevToolsActivePort` before it writes the port into it. Reading the file too early failed the run with "Index 0 out of bounds for length 0". The launcher now waits until the file contains a port.

## Compatibility

- **Older runs.** Runs from earlier versions load as before. The first save by this version, for example when you resume, moves page details into `states/`. After that, don't open that run with an older version, which would not find the page details.
- **Approved baselines** created by earlier versions are not rewritten. They replay normally.
- **ZIP exports.** Exported baseline and execution ZIPs still contain the page details, so older installations can import them.
- **New settings are optional.** Without them, the stricter checks, the Return control override and automatic same-host acceptance still apply.

## Tests added

- `tests/signin_fixes.py`: real-browser test of items 1–4 (15 checks). It uses a fake app with a port redirect, a "Login history" menu, a PIN-code field, a "Please wait" report, a password trap, a session-expiry link and a second host name.
- `tests/StorageChecks.java`: storage format and upgrade checks (10 checks).
