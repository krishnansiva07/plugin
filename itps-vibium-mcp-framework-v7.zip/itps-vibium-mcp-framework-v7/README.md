# ITPS VIBIUM Framework V7

Java Spring Boot test runner using Vibium MCP for browser execution.

## Run

```cmd
set VIBIUM_SKIP_BROWSER_DOWNLOAD=1
mvn clean spring-boot:run
```

Open `http://localhost:8090`.

## Vibium MCP configuration

`src/main/resources/application.properties`

```properties
itps.vibium.mcp.command=C:\\tools\\vibium-portable\\node_modules\\.bin\\vibium.cmd
itps.vibium.mcp.args=mcp
```

## V7 element discovery changes

Vibium `browser_map` is retained for native `@e` references, but it is no longer treated as the complete page inventory.

V7 additionally performs a recursive browser-side element scan that discovers:

- semantic controls such as buttons, inputs, links, selects and text areas
- elements with roles, tabindex, click handlers, pointer cursor or contenteditable
- icon and SVG controls
- elements identified through aria labels, title, placeholder, name, test IDs and data attributes
- controls inside open shadow roots
- controls inside same-origin iframes
- repeated controls with their parent/container context
- selected chips/tokens inside custom multi-select controls
- element position, visibility and generated unique CSS selector

The runner ranks candidates against each instruction before asking the LLM to plan the action. A selector is rejected when it matches no visible element or multiple visible elements. This prevents the framework from clicking the first random match.

A complete per-step inventory is written to:

```text
target/itps-vibium-runs/<run-id>/elements/<test-id>_step_<n>_elements.json
```

## Reports

Each run writes:

```text
target/itps-vibium-runs/<run-id>/
```

- `report.html` – consolidated results
- `logs.html` – searchable technical logs
- `report.xlsx`
- `report.json`
- `screenshots.zip`
- `elements/` – complete element inventories by step
- `mcp-transcript.json`
- `mcp-process.log`

## Known browser limitations

No browser automation tool can inspect elements inside closed shadow roots, cross-origin iframe documents, or canvas-only controls through normal DOM inspection. V7 records these conditions in the technical logs rather than silently selecting a different element.
