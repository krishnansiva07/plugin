package com.itps.vibium.service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.itps.vibium.model.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.time.Duration;
import java.time.Instant;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Service
public class ItpsMcpRunner {
    private final LlmClient llmClient;
    private final ReportService reportService;
    private final RunStore runStore;
    private final ObjectMapper mapper = new ObjectMapper();
    private final Path outputRoot;
    private final int requestTimeoutSeconds;
    private final boolean skipBrowserDownload;

    public ItpsMcpRunner(LlmClient llmClient,
                         ReportService reportService,
                         RunStore runStore,
                         @Value("${runner.output-dir:target/itps-vibium-runs}") String outputDir,
                         @Value("${itps.vibium.mcp.request-timeout-seconds:90}") int requestTimeoutSeconds,
                         @Value("${itps.vibium.skip-browser-download:true}") boolean skipBrowserDownload) {
        this.llmClient = llmClient;
        this.reportService = reportService;
        this.runStore = runStore;
        this.outputRoot = Path.of(outputDir);
        this.requestTimeoutSeconds = requestTimeoutSeconds;
        this.skipBrowserDownload = skipBrowserDownload;
    }

    public void execute(List<TestScenario> scenarios, RunConfig config, RunStatus status) {
        Instant runStart = Instant.now();
        status.setStatus("RUNNING");
        status.setStartedAt(runStart);
        Path runDir = outputRoot.resolve(config.getRunId());
        Path screenshotDir = runDir.resolve("screenshots");
        McpClient mcp = null;
        try {
            Files.createDirectories(screenshotDir);
            List<String> args = mcpArgsWithScreenshotDir(config.getMcpArgs(), screenshotDir);
            mcp = new McpClient(config.getMcpCommand(), args, Duration.ofSeconds(requestTimeoutSeconds), skipBrowserDownload);
            mcp.start();
            List<McpTool> tools = mcp.initializeAndListTools();
            McpToolCatalog catalog = new McpToolCatalog(tools);
            writeToolsManifest(runDir, tools);
            startBrowserOnce(mcp, catalog, config);

            List<ScenarioResult> results = new ArrayList<>();
            for (TestScenario scenario : scenarios) {
                results.add(executeScenario(mcp, catalog, scenario, config, screenshotDir));
            }

            status.setScenarios(results);
            status.setTotal(results.size());
            int passed = (int) results.stream().filter(s -> "PASSED".equals(s.getStatus())).count();
            status.setPassed(passed);
            status.setFailed(results.size() - passed);
            status.setStatus(status.getFailed() == 0 ? "PASSED" : "COMPLETED_WITH_FAILURES");
            status.setMessage("V7 MCP execution completed. Summary and searchable technical logs were generated separately.");
        } catch (Exception e) {
            status.setStatus("FAILED");
            status.setMessage("Vibium MCP execution failed: " + e.getMessage());
        } finally {
            if (mcp != null) {
                mcp.writeDiagnostics(runDir);
                try { mcp.close(); } catch (Exception ignored) {}
            }
            status.setFinishedAt(Instant.now());
            try { reportService.writeReports(status, runDir); }
            catch (Exception reportError) {
                status.setMessage((status.getMessage() == null ? "" : status.getMessage() + " | ") + "Report generation failed: " + reportError.getMessage());
                try { reportService.writeFallbackHtml(status, runDir, reportError); } catch (Exception ignored) {}
            }
        }
    }

    private List<String> mcpArgsWithScreenshotDir(String rawArgs, Path screenshotDir) {
        List<String> args = new ArrayList<>(splitArgs(rawArgs));
        boolean hasScreenshotDir = args.stream().anyMatch(a -> a.equalsIgnoreCase("--screenshot-dir"));
        if (!hasScreenshotDir) {
            args.add("--screenshot-dir");
            args.add(screenshotDir.toAbsolutePath().toString());
        }
        return args;
    }

    private void startBrowserOnce(McpClient mcp, McpToolCatalog catalog, RunConfig config) throws Exception {
        Optional<McpTool> start = catalog.startTool();
        if (start.isEmpty()) return;
        Map<String, Object> args = new LinkedHashMap<>();
        if (schemaContains(start.get(), "headless")) args.put("headless", config.isHeadless());
        if (config.getBrowserId() != null && !"vibium-managed-chrome".equalsIgnoreCase(config.getBrowserId())) {
            String executable = config.getBrowserExecutable();
            boolean applied = false;
            for (String key : List.of("executablePath", "browserExecutable", "browserPath", "binary", "executable")) {
                if (schemaContains(start.get(), key) && executable != null && !executable.isBlank()) { args.put(key, executable); applied = true; break; }
            }
            if (!applied) {
                for (String key : List.of("browser", "channel", "browserName")) {
                    if (schemaContains(start.get(), key)) { args.put(key, config.getBrowserId()); applied = true; break; }
                }
            }
            if (!applied) throw new IllegalStateException("Selected browser '" + config.getBrowserName() + "' is installed, but this Vibium MCP version does not expose browser/channel/executablePath in browser_start. Select Vibium Managed Chrome for Testing.");
        }
        JsonNode result = mcp.callTool(start.get().getName(), args);
        assertMcpToolSuccess(start.get().getName(), result);
    }

    private ScenarioResult executeScenario(McpClient mcp, McpToolCatalog catalog, TestScenario scenario, RunConfig config, Path screenshotDir) {
        long scenarioStart = System.currentTimeMillis();
        ScenarioResult out = new ScenarioResult();
        out.setId(scenario.getId());
        out.setName(scenario.getName());
        out.setUrl(resolveUrl(scenario.getUrl(), config.getAppBaseUrl()));
        out.setStatus("RUNNING");

        List<String> steps = new ArrayList<>();
        if (notBlank(out.getUrl())) steps.add("Navigate to " + out.getUrl());
        steps.addAll(scenario.getSteps());
        if (notBlank(scenario.getExpected())) steps.add("Verify " + applyData(scenario.getExpected(), scenario.getData()) + " is displayed");

        boolean failed = false;
        int stepNo = 1;
        for (String raw : steps) {
            StepResult sr = executeStep(mcp, catalog, scenario, config, raw, stepNo, screenshotDir);
            out.getSteps().add(sr);
            if (!"PASSED".equals(sr.getStatus())) {
                failed = true;
                out.setErrorMessage(sr.getErrorMessage());
                if (!config.isContinueOnFailure()) break;
            }
            stepNo++;
        }
        out.setStatus(failed ? "FAILED" : "PASSED");
        out.setDurationMs(System.currentTimeMillis() - scenarioStart);
        return out;
    }

    private StepResult executeStep(McpClient mcp, McpToolCatalog catalog, TestScenario scenario, RunConfig config, String rawStep, int stepNo, Path screenshotDir) {
        StepResult sr = new StepResult();
        long start = System.currentTimeMillis();
        String instruction = applyData(rawStep, scenario.getData());
        sr.setStepNo(stepNo);
        sr.setInstruction(instruction);

        String beforeFingerprint = "";
        String beforeShot = "";
        try {
            beforeFingerprint = pageFingerprint(mcp, catalog);
            if (config.isStrictEvidence() && requiresPostEvidence(expectedIntent(instruction))) {
                beforeShot = captureScreenshotQuietly(mcp, catalog, screenshotDir, scenario.getId(), stepNo + "_before");
            }
            PlannedStep plan = planStep(mcp, catalog, instruction, scenario, config, null);
            sr.setPlanSource(plan.source());
            sr.setActionJson(plan.plan().toString());
            sr.setPageInventory(plan.observation() == null ? "" : compact(plan.observation().toString(), 60000));
            writeElementInventory(screenshotDir.getParent(), scenario.getId(), stepNo, plan.observation());
            executeValidatedPlan(mcp, catalog, plan.plan(), sr, instruction, config, plan.observation(), beforeFingerprint, beforeShot, screenshotDir, scenario.getId(), stepNo);
            sr.setStatus("PASSED");
            if (shouldScreenshot(config, true) && (sr.getScreenshot() == null || sr.getScreenshot().isBlank())) {
                sr.setScreenshot(captureScreenshot(mcp, catalog, screenshotDir, scenario.getId(), String.valueOf(stepNo)));
            }
        } catch (Exception first) {
            Exception finalError = first;
            for (int retry = 0; retry < config.getRetryCount(); retry++) {
                try {
                    Thread.sleep(config.getRetryDelayMs());
                    PlannedStep replan = planStep(mcp, catalog, instruction, scenario, config, finalError.getMessage());
                    sr.setPlanSource(replan.source());
                    sr.setActionJson(replan.plan().toString());
                    sr.setPageInventory(replan.observation() == null ? "" : compact(replan.observation().toString(), 60000));
                    writeElementInventory(screenshotDir.getParent(), scenario.getId(), stepNo, replan.observation());
                    executeValidatedPlan(mcp, catalog, replan.plan(), sr, instruction, config, replan.observation(), beforeFingerprint, beforeShot, screenshotDir, scenario.getId(), stepNo);
                    sr.setStatus("PASSED");
                    finalError = null;
                    break;
                } catch (Exception retryError) {
                    finalError = retryError;
                }
            }
            if (finalError != null) {
                sr.setStatus("FAILED");
                sr.setErrorMessage(finalError.getMessage());
                if (shouldScreenshot(config, false)) sr.setScreenshot(captureScreenshotQuietly(mcp, catalog, screenshotDir, scenario.getId(), String.valueOf(stepNo)));
            }
        } finally {
            sr.setDurationMs(System.currentTimeMillis() - start);
        }
        return sr;
    }

    private PlannedStep planStep(McpClient mcp, McpToolCatalog catalog, String instruction, TestScenario scenario, RunConfig config, String failure) throws Exception {
        JsonNode direct = parseDirectJson(instruction);
        if (direct != null) return new PlannedStep("EXPLICIT_JSON", normalizePlan(direct), null);
        if (isNavigate(instruction)) return new PlannedStep("DIRECT_NAVIGATE", directNavigatePlan(catalog, instruction), null);
        if (isWait(instruction)) return new PlannedStep("DIRECT_WAIT", directWaitPlan(catalog), null);

        if (!config.isUseLlm()) {
            throw new IllegalStateException("Natural-language step requires LLM planning in V7 MCP mode. Enable Use LLM or provide explicit JSON MCP calls. Step: " + instruction);
        }
        if (!llmClient.isConfigured(config)) {
            throw new IllegalStateException("LLM Base URL/token/model are required for natural-language UI action planning. Step: " + instruction);
        }

        JsonNode observation = observePage(mcp, catalog);
        if (observation instanceof ObjectNode objectObservation) {
            objectObservation.set("rankedCandidates", rankCandidates(observation, instruction, 80));
        }
        String prompt = buildAgentPrompt(instruction, scenario, catalog, observation, failure);
        JsonNode planned = mapper.readTree(llmClient.planMcpCall(prompt, config));
        return new PlannedStep("LLM_MAP_DOM_CLOSED_LOOP", normalizePlan(planned), observation);
    }

    private JsonNode observePage(McpClient mcp, McpToolCatalog catalog) {
        ObjectNode out = mapper.createObjectNode();
        out.set("url", safeToolResult(mcp, catalog.urlTool(), Map.of()));
        out.set("title", safeToolResult(mcp, catalog.titleTool(), Map.of()));
        out.set("text", safeToolResult(mcp, catalog.textTool(), Map.of()));
        out.set("map", safeMap(mcp, catalog));
        out.set("domProbe", safeDomProbe(mcp, catalog));
        return out;
    }

    private void executeValidatedPlan(McpClient mcp, McpToolCatalog catalog, JsonNode originalPlan, StepResult sr,
                                      String instruction, RunConfig config, JsonNode observation, String beforeFingerprint,
                                      String beforeScreenshot, Path screenshotDir, String scenarioId, int stepNo) throws Exception {
        JsonNode plan = removeNoOpStart(originalPlan);
        if (plan == null || flattenCalls(plan).isEmpty()) throw new IllegalStateException("No executable MCP tool calls returned. Plan=" + originalPlan);
        String expectedIntent = expectedIntent(instruction);
        if (requiresRealAction(expectedIntent) && !containsRealAction(plan, expectedIntent)) {
            throw new IllegalStateException("Planner did not return a real MCP action for instruction='" + instruction + "'. Plan=" + originalPlan);
        }

        List<String> tools = new ArrayList<>();
        List<Map<String, Object>> argsList = new ArrayList<>();
        List<String> results = new ArrayList<>();
        boolean executedAction = false;

        for (JsonNode call : flattenCalls(plan)) {
            String toolName = firstText(call, "tool", "name", "mcpTool", "toolName");
            if (isBrowserStart(toolName)) continue;
            McpTool tool = catalog.findByName(toolName).orElseThrow(() -> new IllegalArgumentException("MCP tool not found: " + toolName));
            Map<String, Object> args = normalizeArgsForTool(tool, call.path("arguments"));
            if (isActionTool(tool.getName())) validateSelectorUniqueness(mcp, catalog, tool.getName(), args);
            JsonNode result = mcp.callTool(tool.getName(), args);
            assertMcpToolSuccess(tool.getName(), result);
            tools.add(tool.getName());
            argsList.add(args);
            results.add(compact(result.toString(), 4000));
            if (!isNoOpTool(tool.getName())) executedAction = true;
            if (isActionTool(tool.getName())) {
                sleep(250);
            }
        }

        sr.setToolName(String.join(" → ", tools));
        sr.setToolArguments(mapper.writeValueAsString(argsList));
        sr.setMcpResult(String.join("\n---\n", results));

        String afterScreenshot = shouldScreenshot(config, true) ? captureScreenshotQuietly(mcp, catalog, screenshotDir, scenarioId, String.valueOf(stepNo)) : "";
        if (notBlank(afterScreenshot)) sr.setScreenshot(afterScreenshot);

        JsonNode afterObservation = observePage(mcp, catalog);
        if (isAssert(expectedIntent)) {
            assertInstruction(instruction, sr.getMcpResult(), afterObservation);
            sr.setEvidence("Assertion validated against Vibium map/text/DOM probe.");
        } else if (config.isStrictEvidence() && executedAction && requiresPostEvidence(expectedIntent)) {
            String afterFingerprint = pageFingerprint(mcp, catalog);
            boolean changed = !Objects.equals(beforeFingerprint, afterFingerprint);
            boolean screenshotChanged = screenshotsDifferent(screenshotDir, beforeScreenshot, afterScreenshot);
            if (!changed && !screenshotChanged) {
                throw new IllegalStateException("MCP tool returned success but no DOM/text/URL/screenshot evidence changed. This prevents fake pass. Step='" + instruction + "'. Tools=" + tools + ". Try a more descriptive step or check mcp-transcript.json and screenshots.");
            }
            sr.setEvidence("Closed-loop evidence passed: " + (changed ? "DOM/text/url changed" : "visual screenshot changed") + ".");
        } else {
            sr.setEvidence("MCP tool completed without error; strict visual evidence not required for this step.");
        }
    }

    private void validateSelectorUniqueness(McpClient mcp, McpToolCatalog catalog, String toolName, Map<String, Object> args) {
        Object raw = args.get("selector");
        if (raw == null) return;
        String selector = String.valueOf(raw).trim();
        if (selector.isBlank() || selector.startsWith("@") || selector.startsWith("text=") || selector.startsWith("role=")) return;
        Optional<McpTool> eval = catalog.evaluateTool();
        if (eval.isEmpty()) return;
        try {
            String encoded = Base64.getEncoder().encodeToString(selector.getBytes(StandardCharsets.UTF_8));
            String script = "(() => {const s=atob('" + encoded + "');let all=[];try{if(s.startsWith('//')){const x=document.evaluate(s,document,null,XPathResult.ORDERED_NODE_SNAPSHOT_TYPE,null);for(let i=0;i<x.snapshotLength;i++)all.push(x.snapshotItem(i));}else all=[...document.querySelectorAll(s)];}catch(e){return JSON.stringify({selector:s,error:e.message,count:0,visible:0});}const vis=all.filter(e=>{try{const r=e.getBoundingClientRect(),c=getComputedStyle(e);return r.width>1&&r.height>1&&c.display!=='none'&&c.visibility!=='hidden'}catch(x){return false}});return JSON.stringify({selector:s,count:all.length,visible:vis.length,tags:vis.slice(0,10).map(e=>({tag:e.tagName,id:e.id||'',text:(e.innerText||e.value||e.getAttribute?.('aria-label')||'').trim().slice(0,80)}))});})()";
            Map<String,Object> evalArgs=new LinkedHashMap<>();
            if(schemaContains(eval.get(),"expression"))evalArgs.put("expression",script);else if(schemaContains(eval.get(),"script"))evalArgs.put("script",script);else evalArgs.put("code",script);
            JsonNode inspected=unwrapJsonString(mcp.callTool(eval.get().getName(),evalArgs));
            int count=inspected.path("count").asInt(-1), visible=inspected.path("visible").asInt(-1);
            if(count==0) throw new IllegalStateException("Selector matched no elements before " + toolName + ": " + selector);
            if(visible==0) throw new IllegalStateException("Selector matched only hidden elements before " + toolName + ": " + selector);
            if(visible>1) throw new IllegalStateException("Ambiguous selector matched " + visible + " visible elements before " + toolName + ": " + selector + ". Candidate evidence=" + compact(inspected.toString(),1200));
        } catch (IllegalStateException e) { throw e; }
        catch (Exception ignored) { }
    }

    private Map<String, Object> normalizeArgsForTool(McpTool tool, JsonNode argsNode) {
        Map<String, Object> args = toMap(argsNode);
        if (args.containsKey("selector") && args.get("selector") instanceof Collection<?> c && !c.isEmpty()) {
            args.put("selector", String.valueOf(c.iterator().next()));
        }
        if (!args.containsKey("selector")) {
            for (String k : List.of("ref", "target", "locator")) {
                if (args.containsKey(k) && schemaContains(tool, "selector")) {
                    args.put("selector", args.get(k));
                    break;
                }
            }
        }
        if (schemaContains(tool, "timeout") && !args.containsKey("timeout")) args.put("timeout", 15000);
        return args;
    }

    private String buildAgentPrompt(String instruction, TestScenario scenario, McpToolCatalog catalog, JsonNode observation, String failure) throws Exception {
        StringBuilder sb = new StringBuilder();
        sb.append("You are the execution brain for ITPS VIBIUM Framework V7. Plan browser actions using Vibium MCP only.\n");
        sb.append("The browser is already started. Never call browser_start.\n");
        sb.append("Instruction: ").append(instruction).append("\n");
        sb.append("Scenario: ").append(scenario.getId()).append(" - ").append(scenario.getName()).append("\n");
        sb.append("Test data: ").append(mapper.writeValueAsString(scenario.getData())).append("\n");
        sb.append("Selection policy:\n");
        sb.append("- Use rankedCandidates first. Each candidate contains a stable candidateId, accessibleName, context, interactiveReason and a unique cssSelector.\n");
        sb.append("- Prefer Vibium @e refs when the map exposes the exact intended element. Otherwise use the candidate cssSelector.\n");
        sb.append("- Never reduce an icon instruction to visible text. Search/filter/calendar/menu icons must be identified by accessibleName, aria, title, test id, SVG metadata, surrounding context or unique position inside the correct container.\n");
        sb.append("- Never choose the first matching element when multiple candidates exist. Use containerContext, selectedValues, nearby text and occurrence evidence.\n");
        sb.append("- For repeated controls, select the element inside the container described by the instruction. Example: the Perimeter control containing BCEF and Monaco, not the first Perimeter control.\n");
        sb.append("- Do not use a generic selector that matches multiple elements. Return a unique selector or a precise @e ref.\n");
        sb.append("- For custom dropdowns, click the correct container/input, then type/fill, wait for options, re-map if required, and click the exact option.\n");
        sb.append("- For click/fill/select, return at least one real action tool. browser_map/browser_wait_for_load alone is not an action.\n");
        sb.append("- Return only minified JSON: {\"calls\":[{\"tool\":\"browser_click\",\"arguments\":{\"selector\":\"#unique-selector\"}}],\"why\":\"candidateId and evidence used\"}.\n");
        sb.append("Available MCP tools:\n").append(catalog.toPromptText()).append("\n");
        sb.append("Current observation. rankedCandidates is intentionally placed at the end and must be considered before raw map data:\n")
                .append(compact(observation == null ? "" : observation.toString(), 60000)).append("\n");
        if (failure != null) sb.append("Previous attempt failed: ").append(failure).append("\nReturn a corrected plan using different evidence.\n");
        return sb.toString();
    }

    private JsonNode safeDomProbe(McpClient mcp, McpToolCatalog catalog) {
        Optional<McpTool> eval = catalog.evaluateTool();
        if (eval.isEmpty()) return mapper.createObjectNode().put("note", "No browser_evaluate/eval MCP tool available");
        String script = "(() => {" +
                "const result=[];const seen=new Set();let seq=0;" +
                "const norm=s=>(s||'').toString().replace(/\\s+/g,' ').trim();" +
                "const visible=e=>{try{const r=e.getBoundingClientRect(),c=getComputedStyle(e);return r.width>1&&r.height>1&&c.display!=='none'&&c.visibility!=='hidden'&&c.opacity!=='0'}catch(x){return false}};" +
                "const css=e=>{try{if(e.id)return '#'+CSS.escape(e.id);for(const a of ['data-testid','data-test','data-cy','name','aria-label']){const v=e.getAttribute&&e.getAttribute(a);if(v){const q='['+a+'=\\\"'+CSS.escape(v)+'\\\"]';if(document.querySelectorAll(q).length===1)return q}}let p=[];for(let n=e;n&&n.nodeType===1&&p.length<9;n=n.parentElement){let x=n.tagName.toLowerCase();const cls=[...n.classList].filter(c=>c&&!/[0-9a-f]{8,}/i.test(c)).slice(0,2);if(cls.length)x+='.'+cls.map(CSS.escape).join('.');const siblings=n.parentElement?[...n.parentElement.children].filter(v=>v.tagName===n.tagName):[];if(siblings.length>1)x+=':nth-of-type('+(siblings.indexOf(n)+1)+')';p.unshift(x);const q=p.join(' > ');try{if(document.querySelectorAll(q).length===1)return q}catch(z){}}return p.join(' > ')}catch(x){return ''}};" +
                "const label=e=>{try{let a=norm(e.getAttribute?.('aria-label'));if(a)return a;const ids=norm(e.getAttribute?.('aria-labelledby'));if(ids){const t=ids.split(/\\s+/).map(id=>norm(document.getElementById(id)?.innerText||document.getElementById(id)?.textContent)).filter(Boolean).join(' ');if(t)return t}if(e.labels&&e.labels.length){const t=[...e.labels].map(x=>norm(x.innerText||x.textContent)).filter(Boolean).join(' ');if(t)return t}if(e.id){const l=document.querySelector('label[for=\\\"'+CSS.escape(e.id)+'\\\"]');if(l)return norm(l.innerText||l.textContent)}let p=e.closest?.('label');if(p)return norm(p.innerText||p.textContent);return ''}catch(x){return ''}};" +
                "const context=e=>{try{const a=[];let n=e;for(let i=0;n&&i<4;i++,n=n.parentElement){const h=n.querySelector?.(':scope > label,:scope > legend,:scope > h1,:scope > h2,:scope > h3,:scope > h4,:scope > [class*=label],:scope > [class*=title]');const t=norm(h?.innerText||h?.textContent);if(t&&t.length<180)a.push(t);const own=norm(n.getAttribute?.('aria-label')||n.getAttribute?.('title'));if(own)a.push(own)}return [...new Set(a)].slice(0,6).join(' | ')}catch(x){return ''}};" +
                "const reason=e=>{const tag=(e.tagName||'').toLowerCase(),r=norm(e.getAttribute?.('role')),c=getComputedStyle(e);const z=[];if(['button','input','select','textarea','a','summary','option'].includes(tag))z.push(tag);if(r)z.push('role='+r);if(e.hasAttribute?.('onclick'))z.push('onclick');if(e.tabIndex>=0)z.push('tabindex');if(c.cursor==='pointer')z.push('cursor:pointer');if(e.isContentEditable)z.push('contenteditable');if(tag==='svg'||tag==='path'||e.closest?.('svg'))z.push('icon/svg');return z.join(',')};" +
                "const candidate=e=>{if(!e||seen.has(e)||!visible(e))return false;const tag=(e.tagName||'').toLowerCase();const role=norm(e.getAttribute?.('role'));const c=getComputedStyle(e);return ['button','input','select','textarea','a','summary','option','label','svg'].includes(tag)||['button','link','tab','menuitem','checkbox','radio','combobox','option','switch','textbox','searchbox'].includes(role)||e.hasAttribute?.('onclick')||e.tabIndex>=0||e.isContentEditable||c.cursor==='pointer'||e.hasAttribute?.('data-testid')||e.hasAttribute?.('data-test')||e.hasAttribute?.('aria-label')};" +
                "const add=(e,scope)=>{if(!candidate(e))return;seen.add(e);const r=e.getBoundingClientRect(),tag=(e.tagName||'').toLowerCase();const text=norm(e.innerText||e.textContent).slice(0,220);const val=norm(e.value).slice(0,160);const acc=label(e)||norm(e.getAttribute?.('alt'))||norm(e.getAttribute?.('title'))||norm(e.getAttribute?.('placeholder'))||val||text;result.push({candidateId:'dom-'+(++seq),scope,tag,role:norm(e.getAttribute?.('role')),type:norm(e.getAttribute?.('type')),accessibleName:acc.slice(0,240),text,context:context(e),id:e.id||'',name:norm(e.getAttribute?.('name')),placeholder:norm(e.getAttribute?.('placeholder')),ariaLabel:norm(e.getAttribute?.('aria-label')),title:norm(e.getAttribute?.('title')),testId:norm(e.getAttribute?.('data-testid')||e.getAttribute?.('data-test')||e.getAttribute?.('data-cy')),value:val,selectedValues:(()=>{try{return [...e.querySelectorAll?.('[class*=chip],[class*=tag],[class*=token],[role=option][aria-selected=true]')||[]].map(x=>norm(x.innerText||x.textContent)).filter(Boolean).slice(0,20)}catch(x){return []}})(),checked:!!e.checked,disabled:!!e.disabled,interactiveReason:reason(e),cssSelector:css(e),rect:{x:Math.round(r.x),y:Math.round(r.y),w:Math.round(r.width),h:Math.round(r.height)},zIndex:getComputedStyle(e).zIndex||'',viewport:{w:innerWidth,h:innerHeight}})};" +
                "const walk=(root,scope)=>{let all=[];try{all=[...root.querySelectorAll('*')]}catch(x){}for(const e of all){add(e,scope);if(e.shadowRoot)walk(e.shadowRoot,scope+' > shadow('+((e.id||e.tagName||'host'))+')');if(e.tagName==='IFRAME'){try{if(e.contentDocument)walk(e.contentDocument,scope+' > iframe('+((e.name||e.id||'same-origin'))+')')}catch(x){result.push({candidateId:'frame-'+(++seq),scope,tag:'iframe',accessibleName:'cross-origin iframe',cssSelector:css(e),interactiveReason:'cross-origin iframe'})}}}};" +
                "walk(document,'document');result.sort((a,b)=>(b.disabled?0:1)-(a.disabled?0:1)||(a.rect.y-b.rect.y)||(a.rect.x-b.rect.x));return JSON.stringify({version:2,totalCandidates:result.length,viewportCandidates:result.filter(x=>x.rect.x+x.rect.w>0&&x.rect.y+x.rect.h>0&&x.rect.x<innerWidth&&x.rect.y<innerHeight).length,elements:result.slice(0,5000),truncated:result.length>5000});" +
                "})()";
        Map<String, Object> args = new LinkedHashMap<>();
        if (schemaContains(eval.get(), "expression")) args.put("expression", script);
        else if (schemaContains(eval.get(), "script")) args.put("script", script);
        else args.put("code", script);
        JsonNode raw = safeToolResult(mcp, eval, args);
        return unwrapJsonString(raw);
    }

    private JsonNode unwrapJsonString(JsonNode raw) {
        if (raw == null) return mapper.createObjectNode().put("error", "empty DOM probe result");
        List<String> texts = new ArrayList<>();
        collectTextValues(raw, texts);
        texts.sort(Comparator.comparingInt(String::length).reversed());
        for (String text : texts) {
            String t = text == null ? "" : text.trim();
            if (!(t.startsWith("{") || t.startsWith("["))) continue;
            try { return mapper.readTree(t); } catch (Exception ignored) {}
        }
        return raw;
    }

    private void collectTextValues(JsonNode node, List<String> out) {
        if (node == null) return;
        if (node.isTextual()) { out.add(node.asText()); return; }
        if (node.isArray()) for (JsonNode c : node) collectTextValues(c, out);
        else if (node.isObject()) node.fields().forEachRemaining(e -> collectTextValues(e.getValue(), out));
    }

    private ArrayNode rankCandidates(JsonNode observation, String instruction, int limit) {
        ArrayNode ranked = mapper.createArrayNode();
        JsonNode elements = findElementsArray(observation);
        if (elements == null || !elements.isArray()) return ranked;
        Set<String> tokens = instructionTokens(instruction);
        List<Map.Entry<Integer, JsonNode>> scored = new ArrayList<>();
        for (JsonNode e : elements) {
            int score = candidateScore(e, tokens, instruction);
            if (score > 0) scored.add(Map.entry(score, e));
        }
        scored.sort((a,b) -> Integer.compare(b.getKey(), a.getKey()));
        for (int i=0;i<Math.min(limit, scored.size());i++) {
            ObjectNode copy = scored.get(i).getValue().deepCopy();
            copy.put("matchScore", scored.get(i).getKey());
            ranked.add(copy);
        }
        return ranked;
    }

    private JsonNode findElementsArray(JsonNode node) {
        if (node == null) return null;
        if (node.isObject()) {
            JsonNode direct = node.get("elements");
            if (direct != null && direct.isArray()) return direct;
            Iterator<JsonNode> it = node.elements();
            while (it.hasNext()) { JsonNode found = findElementsArray(it.next()); if (found != null) return found; }
        } else if (node.isArray()) {
            for (JsonNode c : node) { JsonNode found = findElementsArray(c); if (found != null) return found; }
        }
        return null;
    }

    private Set<String> instructionTokens(String instruction) {
        Set<String> stop = Set.of("click","select","type","enter","fill","the","a","an","in","on","from","to","and","button","icon","field","dropdown","element","with","of","is","that","same");
        Set<String> out = new LinkedHashSet<>();
        for (String t : (instruction == null ? "" : instruction.toLowerCase(Locale.ROOT)).split("[^a-z0-9_-]+")) if (t.length()>1 && !stop.contains(t)) out.add(t);
        return out;
    }

    private int candidateScore(JsonNode e, Set<String> tokens, String instruction) {
        String name = e.path("accessibleName").asText("").toLowerCase(Locale.ROOT);
        String text = e.path("text").asText("").toLowerCase(Locale.ROOT);
        String context = e.path("context").asText("").toLowerCase(Locale.ROOT);
        String attrs = (e.path("id").asText("")+" "+e.path("name").asText("")+" "+e.path("ariaLabel").asText("")+" "+e.path("title").asText("")+" "+e.path("testId").asText("")+" "+e.path("placeholder").asText("")).toLowerCase(Locale.ROOT);
        int score = 0;
        for (String t : tokens) {
            if (name.equals(t)) score += 40; else if (name.contains(t)) score += 20;
            if (attrs.contains(t)) score += 18;
            if (text.contains(t)) score += 10;
            if (context.contains(t)) score += 12;
            if (e.path("selectedValues").toString().toLowerCase(Locale.ROOT).contains(t)) score += 25;
        }
        String lower = instruction == null ? "" : instruction.toLowerCase(Locale.ROOT);
        String reason = e.path("interactiveReason").asText("").toLowerCase(Locale.ROOT);
        if (lower.contains("icon") && reason.contains("icon")) score += 18;
        if (lower.contains("dropdown") && (reason.contains("select") || "combobox".equalsIgnoreCase(e.path("role").asText()))) score += 18;
        if (lower.contains("second") && e.path("rect").path("y").asInt() > 0) score += Math.min(8, e.path("rect").path("y").asInt()/150);
        if (e.path("disabled").asBoolean(false)) score -= 100;
        return score;
    }

    private void writeElementInventory(Path runDir, String scenarioId, int stepNo, JsonNode observation) {
        if (observation == null) return;
        try {
            Path dir = runDir.resolve("elements");
            Files.createDirectories(dir);
            String safe = (scenarioId == null ? "scenario" : scenarioId).replaceAll("[^a-zA-Z0-9._-]", "_");
            mapper.writerWithDefaultPrettyPrinter().writeValue(dir.resolve(safe + "_step_" + stepNo + "_elements.json").toFile(), observation);
        } catch (Exception ignored) {}
    }

    private JsonNode safeMap(McpClient mcp, McpToolCatalog catalog) {
        Optional<McpTool> mapTool = catalog.mapTool();
        if (mapTool.isEmpty()) return mapper.createObjectNode().put("note", "No browser_map/snapshot tool available");
        Map<String, Object> args = new LinkedHashMap<>();
        if (schemaContains(mapTool.get(), "selector")) args.put("selector", "body");
        return safeToolResult(mcp, mapTool, args);
    }

    private JsonNode safeToolResult(McpClient mcp, Optional<McpTool> tool, Map<String, Object> args) {
        try {
            if (tool.isEmpty()) return mapper.createObjectNode().put("note", "tool not available");
            return mcp.callTool(tool.get().getName(), args == null ? Map.of() : args);
        } catch (Exception e) {
            return mapper.createObjectNode().put("error", e.getMessage());
        }
    }

    private String pageFingerprint(McpClient mcp, McpToolCatalog catalog) {
        JsonNode obs = observePage(mcp, catalog);
        String text = compact(extractText(obs), 50000);
        return Integer.toHexString(Objects.hash(text));
    }

    private boolean screenshotsDifferent(Path screenshotDir, String before, String after) {
        if (!notBlank(before) || !notBlank(after)) return false;
        try {
            Path b = screenshotDir.resolve(before);
            Path a = screenshotDir.resolve(after);
            if (!Files.exists(b) || !Files.exists(a)) return false;
            byte[] bb = Files.readAllBytes(b);
            byte[] aa = Files.readAllBytes(a);
            return !Arrays.equals(bb, aa);
        } catch (Exception e) { return false; }
    }

    private void assertInstruction(String instruction, String mcpResult, JsonNode observation) {
        String expected = instruction.replaceFirst("(?i)^(verify|assert|check)\\s+", "").trim();
        expected = expected.replaceFirst("(?i)\\s+(is|should be)\\s+(displayed|visible|present).*$", "").trim();
        if (expected.isBlank()) return;
        String haystack = ((mcpResult == null ? "" : mcpResult) + "\n" + (observation == null ? "" : observation.toString())).toLowerCase(Locale.ROOT);
        if (!haystack.contains(expected.toLowerCase(Locale.ROOT))) {
            throw new IllegalStateException("Assertion failed. Expected Vibium map/text/DOM to contain: " + expected);
        }
    }

    private void assertMcpToolSuccess(String toolName, JsonNode result) {
        if (result == null || result.isMissingNode()) return;
        if (result.path("isError").asBoolean(false)) throw new IllegalStateException("MCP tool returned isError=true for " + toolName + ": " + compact(result.toString(), 2000));
        String text = extractText(result).toLowerCase(Locale.ROOT);
        String[] fatal = {"element not found", "not found", "timeout", "timed out", "failed", "error:", "exception", "unable to", "cannot", "invalid selector"};
        for (String f : fatal) if (text.contains(f)) throw new IllegalStateException("MCP tool result indicates failure for " + toolName + ": " + compact(text, 2000));
    }

    private JsonNode directNavigatePlan(McpToolCatalog catalog, String step) throws Exception {
        McpTool navigate = catalog.navigateTool().orElseThrow(() -> new IllegalArgumentException("No navigation MCP tool found"));
        String url = step.replaceFirst("(?i)^navigate\\s+to\\s+", "").trim();
        ArrayNode calls = mapper.createArrayNode();
        calls.add(simpleCall(navigate.getName(), argBySchema(navigate, "url", url, "href")));
        catalog.waitTool().ifPresent(wait -> calls.add(simpleCall(wait.getName(), Map.of())));
        ObjectNode plan = mapper.createObjectNode();
        plan.set("calls", calls);
        return plan;
    }

    private JsonNode directWaitPlan(McpToolCatalog catalog) {
        ObjectNode plan = mapper.createObjectNode();
        ArrayNode calls = plan.putArray("calls");
        catalog.waitTool().ifPresent(tool -> calls.add(simpleCall(tool.getName(), Map.of())));
        return plan;
    }

    private JsonNode removeNoOpStart(JsonNode plan) {
        ObjectNode out = mapper.createObjectNode();
        ArrayNode calls = mapper.createArrayNode();
        for (JsonNode c : flattenCalls(plan)) {
            String tool = firstText(c, "tool", "name", "mcpTool", "toolName");
            if (!isBrowserStart(tool)) calls.add(c);
        }
        out.set("calls", calls);
        return out;
    }

    private List<JsonNode> flattenCalls(JsonNode plan) {
        List<JsonNode> out = new ArrayList<>();
        if (plan == null || plan.isMissingNode() || plan.isNull()) return out;
        if (plan.has("calls") && plan.path("calls").isArray()) plan.path("calls").forEach(out::add);
        else out.add(plan);
        return out;
    }

    private boolean containsRealAction(JsonNode plan, String intent) {
        for (JsonNode c : flattenCalls(plan)) {
            String t = Optional.ofNullable(firstText(c, "tool", "name", "mcpTool", "toolName")).orElse("").toLowerCase(Locale.ROOT);
            if (isNoOpTool(t)) continue;
            if ("NAVIGATE".equals(intent) && containsAny(t, "navigate", "goto", "go", "open")) return true;
            if ("CLICK".equals(intent) && containsAny(t, "click", "tap", "press", "evaluate")) return true;
            if ("FILL".equals(intent) && containsAny(t, "fill", "type", "input", "write", "press", "evaluate")) return true;
            if ("SELECT".equals(intent) && containsAny(t, "select", "click", "press", "fill", "type", "evaluate")) return true;
            if ("ASSERT".equals(intent) && containsAny(t, "map", "snapshot", "text", "assert", "evaluate")) return true;
            if ("OTHER".equals(intent)) return true;
        }
        return false;
    }

    private boolean requiresRealAction(String intent) { return Set.of("NAVIGATE", "CLICK", "FILL", "SELECT", "ASSERT", "OTHER").contains(intent); }
    private boolean requiresPostEvidence(String intent) { return Set.of("CLICK", "SELECT", "FILL").contains(intent); }
    private boolean isActionTool(String tool) { return containsAny(tool, "click", "fill", "type", "select", "press", "navigate", "evaluate"); }
    private boolean isNoOpTool(String tool) { return containsAny(tool, "start", "map", "snapshot", "screenshot", "wait", "text", "title", "url") && !containsAny(tool, "click", "fill", "type", "navigate", "select", "press", "evaluate"); }
    private boolean isBrowserStart(String tool) { return tool != null && tool.toLowerCase(Locale.ROOT).contains("start"); }

    private String expectedIntent(String step) {
        String l = step == null ? "" : step.toLowerCase(Locale.ROOT).trim();
        if (isNavigate(step)) return "NAVIGATE";
        if (l.startsWith("click") || l.startsWith("tap") || l.startsWith("open")) return "CLICK";
        if (l.startsWith("enter") || l.startsWith("type") || l.startsWith("fill") || l.startsWith("search for")) return "FILL";
        if (l.startsWith("select") || l.contains("drop down") || l.contains("dropdown")) return "SELECT";
        if (l.startsWith("verify") || l.startsWith("assert") || l.startsWith("check")) return "ASSERT";
        if (l.startsWith("wait")) return "WAIT";
        return "OTHER";
    }

    private boolean isAssert(String intent) { return "ASSERT".equals(intent); }
    private boolean isNavigate(String step) { return step != null && step.trim().toLowerCase(Locale.ROOT).startsWith("navigate to "); }
    private boolean isWait(String step) { return step != null && step.trim().toLowerCase(Locale.ROOT).startsWith("wait"); }

    private String captureScreenshot(McpClient mcp, McpToolCatalog catalog, Path screenshotDir, String scenarioId, String stepNo) throws Exception {
        Optional<McpTool> tool = catalog.screenshotTool();
        if (tool.isEmpty()) return "";
        Files.createDirectories(screenshotDir);
        String safeScenario = scenarioId == null ? "scenario" : scenarioId.replaceAll("[^a-zA-Z0-9._-]", "_");
        String safeStep = stepNo == null ? "step" : stepNo.replaceAll("[^a-zA-Z0-9._-]", "_");
        String fileName = safeScenario + "_step_" + safeStep + ".png";
        Path out = screenshotDir.resolve(fileName).toAbsolutePath();
        long before = System.currentTimeMillis();
        Map<String, Object> args = new LinkedHashMap<>();
        if (schemaContains(tool.get(), "path")) args.put("path", out.toString());
        else if (schemaContains(tool.get(), "file")) args.put("file", out.toString());
        else if (schemaContains(tool.get(), "output")) args.put("output", out.toString());
        if (schemaContains(tool.get(), "annotate")) args.put("annotate", true);
        JsonNode result = mcp.callTool(tool.get().getName(), args);
        assertMcpToolSuccess(tool.get().getName(), result);
        if (Files.exists(out) && Files.size(out) > 0) return fileName;
        Optional<byte[]> png = findImageBytes(result);
        if (png.isPresent()) { Files.write(out, png.get()); return fileName; }
        Optional<Path> pathFromResult = findPngPath(result);
        if (pathFromResult.isPresent() && Files.exists(pathFromResult.get())) { Files.copy(pathFromResult.get(), out, StandardCopyOption.REPLACE_EXISTING); return fileName; }
        Optional<Path> newest = newestPng(screenshotDir, before - 1000);
        if (newest.isPresent()) { Files.copy(newest.get(), out, StandardCopyOption.REPLACE_EXISTING); return fileName; }
        return "";
    }

    private String captureScreenshotQuietly(McpClient mcp, McpToolCatalog catalog, Path screenshotDir, String scenarioId, String stepNo) {
        try { return captureScreenshot(mcp, catalog, screenshotDir, scenarioId, stepNo); }
        catch (Exception ignored) { return ""; }
    }

    private Optional<Path> newestPng(Path dir, long afterMs) {
        try (var stream = Files.list(dir)) {
            return stream.filter(p -> p.getFileName().toString().toLowerCase(Locale.ROOT).endsWith(".png"))
                    .filter(p -> {
                        try { return Files.getLastModifiedTime(p).toMillis() >= afterMs; } catch (Exception e) { return false; }
                    })
                    .max(Comparator.comparingLong(p -> {
                        try { return Files.getLastModifiedTime(p).toMillis(); } catch (Exception e) { return 0L; }
                    }));
        } catch (Exception e) { return Optional.empty(); }
    }

    private Optional<byte[]> findImageBytes(JsonNode node) {
        if (node == null || node.isNull() || node.isMissingNode()) return Optional.empty();
        if (node.isObject()) {
            String type = node.path("type").asText("");
            String mime = node.path("mimeType").asText("");
            String data = node.path("data").asText("");
            if ((("image".equalsIgnoreCase(type)) || mime.toLowerCase(Locale.ROOT).contains("png")) && notBlank(data)) {
                try { return Optional.of(Base64.getDecoder().decode(cleanBase64(data))); } catch (Exception ignored) {}
            }
            Iterator<Map.Entry<String, JsonNode>> it = node.fields();
            while (it.hasNext()) { Optional<byte[]> found = findImageBytes(it.next().getValue()); if (found.isPresent()) return found; }
        } else if (node.isArray()) {
            for (JsonNode c : node) { Optional<byte[]> found = findImageBytes(c); if (found.isPresent()) return found; }
        } else if (node.isTextual()) {
            String text = node.asText();
            if (text.startsWith("data:image/png;base64,")) text = text.substring("data:image/png;base64,".length());
            if (text.length() > 1000 && text.matches("^[A-Za-z0-9+/=\\r\\n]+$")) {
                try { return Optional.of(Base64.getDecoder().decode(cleanBase64(text))); } catch (Exception ignored) {}
            }
        }
        return Optional.empty();
    }

    private Optional<Path> findPngPath(JsonNode node) {
        String text = extractText(node);
        Matcher m = Pattern.compile("([A-Za-z]:\\\\[^\\n\"']+?\\.png)").matcher(text);
        if (m.find()) return Optional.of(Path.of(m.group(1)));
        m = Pattern.compile("(/[^\\n\"']+?\\.png)").matcher(text);
        if (m.find()) return Optional.of(Path.of(m.group(1)));
        return Optional.empty();
    }

    private String cleanBase64(String s) { return s == null ? "" : s.replace("data:image/png;base64,", "").replaceAll("\\s+", ""); }

    private Map<String, Object> toMap(JsonNode n) {
        if (n == null || n.isMissingNode() || n.isNull()) return new LinkedHashMap<>();
        return mapper.convertValue(n, new TypeReference<Map<String, Object>>() {});
    }

    private Map<String, Object> argBySchema(McpTool tool, String primary, String value, String fallback) {
        Map<String, Object> args = new LinkedHashMap<>();
        args.put(schemaContains(tool, primary) ? primary : fallback, value);
        return args;
    }

    private ObjectNode simpleCall(String tool, Map<String, Object> args) {
        ObjectNode c = mapper.createObjectNode();
        c.put("tool", tool);
        c.set("arguments", mapper.valueToTree(args == null ? Map.of() : args));
        return c;
    }

    private JsonNode normalizePlan(JsonNode plan) {
        if (plan == null) return mapper.createObjectNode();
        if (plan.isArray()) { ObjectNode p = mapper.createObjectNode(); p.set("calls", plan); return p; }
        if (plan.has("tool") || plan.has("calls") || plan.has("name") || plan.has("mcpTool")) return plan;
        return plan;
    }

    private JsonNode parseDirectJson(String step) throws Exception {
        String t = step == null ? "" : step.trim();
        if (!t.startsWith("{") && !t.startsWith("[")) return null;
        return mapper.readTree(t);
    }

    private String applyData(String input, Map<String, Object> data) {
        if (input == null || data == null) return input;
        String out = input;
        for (Map.Entry<String, Object> e : data.entrySet()) {
            String value = e.getValue() == null ? "" : String.valueOf(e.getValue());
            out = out.replace("{{" + e.getKey() + "}}", value);
            out = out.replace("${" + e.getKey() + "}", value);
        }
        return out;
    }

    private List<String> splitArgs(String args) {
        if (args == null || args.isBlank()) return List.of();
        List<String> out = new ArrayList<>();
        Matcher m = Pattern.compile("([^\\s\"]+)|\"([^\"]*)\"").matcher(args);
        while (m.find()) out.add(m.group(1) != null ? m.group(1) : m.group(2));
        return out;
    }

    private String resolveUrl(String url, String base) {
        if (!notBlank(url)) return "";
        String t = url.trim();
        if (t.startsWith("http://") || t.startsWith("https://")) return t;
        if (!notBlank(base)) return t;
        if (base.endsWith("/") && t.startsWith("/")) return base.substring(0, base.length() - 1) + t;
        if (!base.endsWith("/") && !t.startsWith("/")) return base + "/" + t;
        return base + t;
    }

    private boolean shouldScreenshot(RunConfig config, boolean pass) {
        String mode = config.getScreenshotMode() == null ? "ALL" : config.getScreenshotMode();
        if ("NONE".equalsIgnoreCase(mode)) return false;
        if ("ALL".equalsIgnoreCase(mode)) return true;
        return !pass;
    }

    private String firstText(JsonNode node, String... fields) {
        if (node == null) return null;
        for (String f : fields) {
            JsonNode v = node.path(f);
            if (v.isTextual() && !v.asText().isBlank()) return v.asText();
        }
        return null;
    }

    private boolean schemaContains(McpTool tool, String term) {
        return tool != null && tool.getInputSchema() != null && tool.getInputSchema().toString().toLowerCase(Locale.ROOT).contains(term.toLowerCase(Locale.ROOT));
    }

    private boolean containsAny(String text, String... terms) {
        if (text == null) return false;
        String l = text.toLowerCase(Locale.ROOT);
        for (String t : terms) if (l.contains(t.toLowerCase(Locale.ROOT))) return true;
        return false;
    }

    private boolean notBlank(String value) { return value != null && !value.trim().isEmpty(); }

    private String compact(String text, int max) {
        if (text == null) return "";
        String s = text.replaceAll("\\s+", " ").trim();
        return s.length() <= max ? s : s.substring(0, max) + "...";
    }

    private String extractText(JsonNode node) {
        if (node == null) return "";
        if (node.isTextual()) return node.asText();
        if (node.isNumber() || node.isBoolean()) return node.asText();
        StringBuilder sb = new StringBuilder();
        if (node.isObject()) node.fields().forEachRemaining(e -> sb.append(' ').append(e.getKey()).append(' ').append(extractText(e.getValue())));
        else if (node.isArray()) for (JsonNode c : node) sb.append(' ').append(extractText(c));
        return sb.toString();
    }

    private void sleep(long ms) { try { Thread.sleep(ms); } catch (InterruptedException e) { Thread.currentThread().interrupt(); } }

    private void writeToolsManifest(Path runDir, List<McpTool> tools) {
        try {
            Files.createDirectories(runDir);
            Files.writeString(runDir.resolve("mcp-tools.json"), mapper.writerWithDefaultPrettyPrinter().writeValueAsString(tools), StandardCharsets.UTF_8);
        } catch (Exception ignored) {}
    }

    private record PlannedStep(String source, JsonNode plan, JsonNode observation) {}
}
