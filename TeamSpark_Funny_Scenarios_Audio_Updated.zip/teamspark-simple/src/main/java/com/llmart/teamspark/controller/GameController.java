package com.llmart.teamspark.controller;

import com.llmart.teamspark.dto.ConnectionResponse;
import com.llmart.teamspark.dto.ScenarioRequest;
import com.llmart.teamspark.dto.ScenarioResponse;
import com.llmart.teamspark.service.ScenarioService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/game")
public class GameController {

    private static final String API_KEY_HEADER = "X-LLM-API-Key";

    private final ScenarioService scenarioService;

    public GameController(ScenarioService scenarioService) {
        this.scenarioService = scenarioService;
    }

    @PostMapping("/test-connection")
    public ConnectionResponse testConnection(@RequestHeader(API_KEY_HEADER) String apiKey) {
        String response = scenarioService.testConnection(apiKey);
        boolean success = response != null && response.toLowerCase().contains("connection successful");
        return new ConnectionResponse(success,
                success ? "Connection successful" : "The model responded, but the expected validation message was different.");
    }

    @PostMapping("/scenario")
    public ScenarioResponse generateScenario(
            @RequestHeader(API_KEY_HEADER) String apiKey,
            @Valid @RequestBody ScenarioRequest request) {
        return scenarioService.generate(apiKey, request.category(), request.selectedMembers());
    }

    @ExceptionHandler({IllegalArgumentException.class, IllegalStateException.class})
    public ResponseEntity<ErrorResponse> handleBadRequest(RuntimeException ex) {
        return ResponseEntity.badRequest().body(new ErrorResponse(ex.getMessage()));
    }

    public record ErrorResponse(String message) {
    }
}
