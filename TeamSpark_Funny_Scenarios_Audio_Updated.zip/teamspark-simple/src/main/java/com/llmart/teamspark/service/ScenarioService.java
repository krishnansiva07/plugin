package com.llmart.teamspark.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.llmart.teamspark.dto.ScenarioResponse;
import dev.langchain4j.model.chat.ChatLanguageModel;
import dev.langchain4j.model.openai.OpenAiChatModel;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.time.Duration;
import java.util.List;

@Service
public class ScenarioService {

    private static final int MIN_ENGLISH_WORDS = 25;
    private static final int MAX_ENGLISH_WORDS = 30;
    private static final int MAX_GENERATION_ATTEMPTS = 3;

    private final ObjectMapper objectMapper;
    private final String baseUrl;
    private final String modelName;

    public ScenarioService(
            ObjectMapper objectMapper,
            @Value("${llm.base-url}") String baseUrl,
            @Value("${llm.model-name}") String modelName) {
        this.objectMapper = objectMapper;
        this.baseUrl = baseUrl;
        this.modelName = modelName;
    }

    public String testConnection(String apiKey) {
        validateKey(apiKey);
        return createModel(apiKey).generate(ScenarioPromptFactory.connectionPrompt());
    }

    public ScenarioResponse generate(String apiKey, String category, List<String> selectedMembers) {
        validateKey(apiKey);

        ChatLanguageModel model = createModel(apiKey);
        String basePrompt = ScenarioPromptFactory.build(category, selectedMembers);
        String prompt = basePrompt;
        ScenarioResponse lastResponse = null;

        for (int attempt = 1; attempt <= MAX_GENERATION_ATTEMPTS; attempt++) {
            String raw = model.generate(prompt);
            lastResponse = parseResponse(raw);

            int englishWords = countWords(lastResponse.english());
            if (englishWords >= MIN_ENGLISH_WORDS && englishWords <= MAX_ENGLISH_WORDS) {
                return lastResponse;
            }

            prompt = ScenarioPromptFactory.correctionPrompt(
                    basePrompt,
                    lastResponse.english(),
                    englishWords
            );
        }

        throw new IllegalStateException(
                "The model could not create a 25-30 word English scenario after "
                        + MAX_GENERATION_ATTEMPTS + " attempts. Please generate again."
        );
    }

    private ChatLanguageModel createModel(String apiKey) {
        return OpenAiChatModel.builder()
                .apiKey(apiKey.trim())
                .baseUrl(baseUrl)
                .modelName(modelName)
                .temperature(1.0)
                .maxTokens(300)
                .timeout(Duration.ofSeconds(60))
                .build();
    }

    private ScenarioResponse parseResponse(String raw) {
        if (!StringUtils.hasText(raw)) {
            throw new IllegalStateException("The model returned an empty response.");
        }

        String cleaned = raw.trim();
        if (cleaned.startsWith("```")) {
            cleaned = cleaned.replaceFirst("^```(?:json)?\\s*", "")
                    .replaceFirst("\\s*```$", "")
                    .trim();
        }

        try {
            JsonNode root = objectMapper.readTree(cleaned);
            String english = root.path("english").asText("").trim();
            String french = root.path("french").asText("").trim();

            if (!StringUtils.hasText(english) || !StringUtils.hasText(french)) {
                throw new IllegalStateException("The model response did not contain both English and French scenarios.");
            }
            return new ScenarioResponse(english, french);
        } catch (JsonProcessingException ex) {
            throw new IllegalStateException("The model response was not valid JSON. Please generate again.", ex);
        }
    }

    static int countWords(String text) {
        if (!StringUtils.hasText(text)) {
            return 0;
        }
        return text.trim().split("\\s+").length;
    }

    private void validateKey(String apiKey) {
        if (!StringUtils.hasText(apiKey)) {
            throw new IllegalArgumentException("Enter your API key before continuing.");
        }
    }
}
