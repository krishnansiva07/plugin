package com.llmart.teamspark.service;

import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

public final class ScenarioPromptFactory {

    private static final List<String> COMEDY_CUES = List.of(
            "a harmless misunderstanding that becomes ridiculous",
            "an animal behaving like a very serious human",
            "an everyday object doing something completely unexpected",
            "a strange rule everyone suddenly has to follow",
            "a silly competition starting for no good reason",
            "a funny mix-up involving the wrong person or wrong item",
            "a normal activity interrupted by one absurd surprise",
            "a harmless problem that gets funnier every second"
    );

    private ScenarioPromptFactory() {
    }

    public static String build(String category, List<String> selectedMembers) {
        String players = selectedMembers == null || selectedMembers.isEmpty()
                ? "the selected players"
                : String.join(", ", selectedMembers);

        String comedyCue = COMEDY_CUES.get(ThreadLocalRandom.current().nextInt(COMEDY_CUES.size()));

        return """
                You create VERY SHORT and genuinely funny situations for a live team game.

                PLACE / CATEGORY: %s
                Players answering: %s
                Comedy direction for this turn: %s

                Create ONE situation only.

                STRICT ENGLISH RULES:
                - English MUST contain 25 to 30 words TOTAL, including the final question.
                - Use very simple everyday English. A person should understand it in 5 seconds.
                - Maximum 2 short sentences.
                - Put the player immediately inside the situation using "You".
                - Include ONE clear, harmless, ridiculous twist.
                - Make people imagine the scene and laugh before answering.
                - Finish with a short question such as "What do you do?" or "How do you react?"
                - Do NOT mention the players' names inside the situation.

                HUMOUR RULES:
                - Prefer absurd surprise, awkward misunderstanding, funny animal behaviour,
                  strange objects, silly rules, or an unexpected social problem.
                - Keep it playful and suitable for colleagues on a Teams call.
                - Do NOT create generic motivational, philosophical or serious situations.
                - Avoid boring clichés such as simply being lost, stuck, late, alone,
                  having no signal, a normal power cut, or merely dropping/losing a phone.
                - No politics, religion, sexual content, insults, violence, medical emergencies,
                  illegal acts, humiliation or jokes about personal characteristics.

                FRENCH RULES:
                - Translate the SAME situation naturally into simple French.
                - Keep the same joke and meaning.
                - French does not need the exact same word count.

                Return ONLY valid JSON. No markdown. No explanation.
                {"english":"25-30 word English scenario","french":"French translation"}
                """.formatted(category, players, comedyCue);
    }

    public static String correctionPrompt(String originalPrompt, String previousEnglish, int wordCount) {
        return originalPrompt + """

                IMPORTANT CORRECTION:
                Your previous English scenario had %d words:
                "%s"

                Reject it and create a DIFFERENT, FUNNIER scenario.
                The new English scenario MUST be between 25 and 30 words inclusive.
                Count the English words before returning the JSON.
                """.formatted(wordCount, previousEnglish == null ? "" : previousEnglish.replace("\"", "'"));
    }

    public static String connectionPrompt() {
        return "Reply with exactly: TeamSpark connection successful";
    }
}
