package com.llmart.teamspark.dto;

public record ScenarioResponse(
        String english,
        String french
) {
}
