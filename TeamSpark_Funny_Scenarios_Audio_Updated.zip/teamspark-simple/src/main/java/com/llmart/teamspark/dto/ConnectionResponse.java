package com.llmart.teamspark.dto;

public record ConnectionResponse(boolean success, String message) {
}
