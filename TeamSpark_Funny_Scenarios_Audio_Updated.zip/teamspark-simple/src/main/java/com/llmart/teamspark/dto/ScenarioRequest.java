package com.llmart.teamspark.dto;

import jakarta.validation.constraints.NotBlank;
import java.util.List;

public record ScenarioRequest(
        @NotBlank String category,
        List<String> selectedMembers
) {
}
