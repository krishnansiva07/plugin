package com.llmart.teamspark.service;

import org.junit.jupiter.api.Test;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

class ScenarioPromptFactoryTest {

    @Test
    void promptContainsStrictFunnyScenarioRules() {
        String prompt = ScenarioPromptFactory.build("Forest", List.of("Siva", "Sara"));

        assertThat(prompt)
                .contains("Forest")
                .contains("Siva, Sara")
                .contains("25 to 30 words")
                .contains("very simple everyday English")
                .contains("ridiculous twist")
                .contains("French")
                .contains("\"english\"")
                .contains("\"french\"");
    }
}
