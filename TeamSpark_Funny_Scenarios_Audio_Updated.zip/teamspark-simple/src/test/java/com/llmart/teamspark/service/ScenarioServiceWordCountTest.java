package com.llmart.teamspark.service;

import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

class ScenarioServiceWordCountTest {

    @Test
    void countsWordsUsingWhitespace() {
        String text = "You enter the office and every chair starts rolling away whenever someone tries to sit down. Your manager declares standing illegal. What do you do?";
        assertThat(ScenarioService.countWords(text)).isEqualTo(25);
    }
}
