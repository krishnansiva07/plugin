@echo off
setlocal
cd /d "%~dp0"
echo Starting TeamSpark...
mvn spring-boot:run
endlocal
