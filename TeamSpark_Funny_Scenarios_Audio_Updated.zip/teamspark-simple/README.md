# TeamSpark

TeamSpark is a simple Spring Boot web game for team calls. A game admin creates teams, randomly selects one player from each team, chooses a place/category, and generates one funny scenario in English and French.

## Main flow

1. Open TeamSpark and enter the LLM API key.
2. Choose 2 to 6 teams.
3. Enter team names and members.
4. Start the game.
5. Click **Choose Members** to randomly select one member from every team.
6. Choose a category and click **Generate Scenario**.
7. The selected members explain how they would react.
8. Click **Next Turn**. TeamSpark automatically selects the next set of members.

A member is not selected again until the other members in that team have had a turn. Members added during the game join the available selection pool.

## LLM configuration

The model name and API URL are fixed in `src/main/resources/application.properties`.

The API key is entered by the game admin in the browser. It is kept only in browser memory while the page is open and is sent to the Spring Boot backend only when the LLM is called. It is not written to `application.properties`.

## Run in IntelliJ

1. Open the project as a Maven project.
2. Use Java 17.
3. Allow Maven dependencies to download.
4. Run `TeamSparkApplication.java`.
5. Open `http://localhost:8090`.

## Run from terminal

```bash
mvn clean spring-boot:run
```

Or build the executable jar:

```bash
mvn clean package
java -jar target/teamspark.jar
```

## Scenario quality rules

TeamSpark now enforces a concise live-game format:
- English scenario must be 25-30 words.
- Very simple everyday English.
- One clear funny/absurd twist.
- Maximum two short sentences.
- French describes the exact same situation.
- The backend checks the English word count and automatically retries up to three times when the model misses the limit.

## Scenario audio

Each generated language card includes a speaker icon:
- English uses the browser English text-to-speech voice.
- French uses the browser French text-to-speech voice.
- Starting one language automatically stops the other.
- No extra LLM/API request is made for audio; it uses the browser Web Speech API.

For a Teams screen-share session, enable **Share system audio** if you want remote participants to hear the spoken scenario.
