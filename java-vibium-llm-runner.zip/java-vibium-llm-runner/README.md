# Java Vibium LLM Runner

This is a Java Spring Boot application that uses the real Vibium Java client, not Selenium and not Node Vibium. It lets you upload test scenarios from JSON or Excel, call an OpenAI-compatible LLM endpoint to convert plain-English steps into Vibium actions, and run the scenarios in headed or headless mode.

## Stack

- Java 17
- Spring Boot 3.2.6
- Vibium Java client: `com.vibium:vibium:26.3.18`
- Apache POI for Excel input/report output
- OpenAI-compatible LLM API: `<base-url>/chat/completions`

## Run locally

```bash
mvn clean spring-boot:run
```

Open:

```text
http://localhost:8090
```

## UI fields

| Field | Purpose |
|---|---|
| Scenario file | Upload `.json`, `.xlsx`, or `.xls` scenarios. |
| Application base URL | Optional base URL used when scenario URLs are relative. |
| LLM base URL | Example: `https://ai4devs.group.echonet/api/v1`. The app calls `/chat/completions`. |
| Token/API key | Sent as `Authorization: Bearer <token>`. |
| Model name | Example: `gpt-oss-120b`. |
| Headed/Headless | Starts Vibium visible or headless. |
| Vibium binary path/upload | Optional. Use only when you want to point Java Vibium to a specific Vibium executable. |
| Chrome/ChromeDriver path | Stored/displayed for migration and diagnostics. Vibium Java does not expose a chromedriver path option. |

## Excel format

The first sheet is read. Headers are case-insensitive.

Required/recommended columns:

```text
id | name | url | steps | expected | data.username | data.password | data.searchTerm | testDataJson
```

`steps` can be separated by new lines or by `|`.

Example:

```text
Open login page | Enter username in Username field | Enter password in Password field | Click Login button | Verify Dashboard
```

You can reference data using placeholders:

```text
Enter {{username}} in Username field
```

## JSON format

```json
{
  "scenarios": [
    {
      "id": "TC001",
      "name": "Login success",
      "url": "/login",
      "data": { "username": "demo.user", "password": "Password@123" },
      "steps": [
        "Open login page",
        "Enter {{username}} in Username field",
        "Enter {{password}} in Password field",
        "Click Login button",
        "Verify Dashboard"
      ],
      "expected": "Dashboard"
    }
  ]
}
```

## Post-run output

For each run, the app creates:

```text
target/vibium-test-runs/<run-id>/
  report.json
  report.xlsx
  screenshots.zip
  screenshots/
    TC001_step_1_passed.png
```

The UI also provides download links for the JSON report, Excel report, and screenshots ZIP.

## Important Vibium note

`StartOptions.executablePath(...)` in the Java client points to the Vibium binary, not `chromedriver.exe`. Vibium handles Chrome/browser setup itself. If your corporate network blocks automatic downloads, install/run the Vibium binary manually on that machine and provide the Vibium binary path in the UI.

## Security note

Do not commit real tokens in `application.properties`, Excel, JSON, or screenshots. Put tokens only in the UI at runtime.
