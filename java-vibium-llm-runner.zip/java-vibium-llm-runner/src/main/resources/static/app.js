const $ = (id) => document.getElementById(id);
let currentRunId = null;
let pollTimer = null;

$('runBtn').addEventListener('click', async () => {
    const file = $('scenarioFile').files[0];
    if (!file) {
        showMessage('Please select JSON or Excel scenario file.', true);
        return;
    }

    const form = new FormData();
    form.append('scenarioFile', file);
    appendIfValue(form, 'llmBaseUrl', $('llmBaseUrl').value);
    appendIfValue(form, 'llmApiKey', $('llmApiKey').value);
    appendIfValue(form, 'llmModel', $('llmModel').value);
    appendIfValue(form, 'appBaseUrl', $('appBaseUrl').value);
    appendIfValue(form, 'vibiumBinaryPath', $('vibiumBinaryPath').value);
    appendIfValue(form, 'chromeBinaryPath', $('chromeBinaryPath').value);
    appendIfValue(form, 'chromeDriverPath', $('chromeDriverPath').value);
    form.append('headless', $('headless').value);
    form.append('useLlm', $('useLlm').checked);
    form.append('continueOnFailure', $('continueOnFailure').checked);
    if ($('vibiumBinaryFile').files[0]) form.append('vibiumBinaryFile', $('vibiumBinaryFile').files[0]);
    if ($('driverFile').files[0]) form.append('driverFile', $('driverFile').files[0]);

    $('runBtn').disabled = true;
    showMessage('Starting Vibium run...');
    try {
        const res = await fetch('/api/runs', { method: 'POST', body: form });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || 'Failed to start run');
        currentRunId = data.runId;
        render(data);
        pollTimer = setInterval(loadRun, 2000);
    } catch (e) {
        showMessage(e.message, true);
        $('runBtn').disabled = false;
    }
});

function appendIfValue(form, key, value) {
    if (value && value.trim()) form.append(key, value.trim());
}

async function loadRun() {
    if (!currentRunId) return;
    const res = await fetch(`/api/runs/${currentRunId}`);
    const data = await res.json();
    render(data);
    if (['PASSED', 'FAILED', 'COMPLETED_WITH_FAILURES'].includes(data.status)) {
        clearInterval(pollTimer);
        $('runBtn').disabled = false;
        showMessage(`Run completed with status: ${data.status}`);
    }
}

function render(run) {
    $('runTitle').textContent = `${run.runId || ''} - ${run.status || ''}`;
    const downloads = $('downloads');
    if (run.runId) {
        downloads.classList.remove('hidden');
        downloads.innerHTML = `
            <a href="/api/runs/${run.runId}/report.json">Download JSON report</a>
            <a href="/api/runs/${run.runId}/report.xlsx">Download Excel report</a>
            <a href="/api/runs/${run.runId}/screenshots.zip">Download screenshots ZIP</a>
        `;
    }
    $('summary').innerHTML = metric('Total', run.total ?? 0) + metric('Passed', run.passed ?? 0) + metric('Failed', run.failed ?? 0) + metric('Status', run.status ?? '-');
    $('scenarioResults').innerHTML = (run.scenarios || []).map(scenarioHtml).join('');
}

function metric(label, value) {
    return `<div class="metric"><div class="label">${escapeHtml(label)}</div><div class="value">${escapeHtml(String(value))}</div></div>`;
}

function scenarioHtml(s) {
    const rows = (s.steps || []).map(st => `
        <tr>
            <td>${st.stepNo ?? ''}</td>
            <td>${escapeHtml(st.instruction || '')}</td>
            <td class="code">${escapeHtml(st.actionJson || '')}</td>
            <td><span class="status ${st.status}">${escapeHtml(st.status || '')}</span></td>
            <td>${st.durationMs ?? ''}</td>
            <td>${st.screenshot ? `<a href="/api/runs/${currentRunId}/${st.screenshot}" target="_blank">view</a>` : ''}</td>
            <td>${escapeHtml(st.errorMessage || '')}</td>
        </tr>
    `).join('');
    return `
        <div class="scenario">
            <div class="scenario-title">
                <div><strong>${escapeHtml(s.id || '')} - ${escapeHtml(s.name || '')}</strong><br/><small>${escapeHtml(s.url || '')}</small></div>
                <span class="status ${s.status}">${escapeHtml(s.status || '')}</span>
            </div>
            <table class="steps">
                <thead><tr><th>#</th><th>Step</th><th>Vibium action JSON</th><th>Status</th><th>ms</th><th>Screenshot</th><th>Error</th></tr></thead>
                <tbody>${rows}</tbody>
            </table>
        </div>
    `;
}

function showMessage(text, isError = false) {
    $('message').textContent = text;
    $('message').style.color = isError ? '#b91c1c' : '#64748b';
}

function escapeHtml(str) {
    return str.replace(/[&<>'"]/g, c => ({'&':'&amp;', '<':'&lt;', '>':'&gt;', "'":'&#39;', '"':'&quot;'}[c]));
}
