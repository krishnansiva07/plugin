package com.llmart.llm.model;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

public class RunStatus {
    private String runId;
    private String status = "CREATED";
    private Instant startedAt;
    private Instant finishedAt;
    private int total;
    private int passed;
    private int failed;
    private String message;
    private List<ScenarioResult> scenarios = new ArrayList<>();

    public String getRunId() { return runId; }
    public void setRunId(String runId) { this.runId = runId; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public Instant getStartedAt() { return startedAt; }
    public void setStartedAt(Instant startedAt) { this.startedAt = startedAt; }
    public Instant getFinishedAt() { return finishedAt; }
    public void setFinishedAt(Instant finishedAt) { this.finishedAt = finishedAt; }
    public int getTotal() { return total; }
    public void setTotal(int total) { this.total = total; }
    public int getPassed() { return passed; }
    public void setPassed(int passed) { this.passed = passed; }
    public int getFailed() { return failed; }
    public void setFailed(int failed) { this.failed = failed; }
    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }
    public List<ScenarioResult> getScenarios() { return scenarios; }
    public void setScenarios(List<ScenarioResult> scenarios) { this.scenarios = scenarios; }
}
