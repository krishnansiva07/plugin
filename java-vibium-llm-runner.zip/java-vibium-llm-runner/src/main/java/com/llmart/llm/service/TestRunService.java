package com.llmart.llm.service;

import com.llmart.llm.model.RunConfig;
import com.llmart.llm.model.RunStatus;
import com.llmart.llm.model.TestScenario;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;

@Service
public class TestRunService {
    private final VibiumRunner vibiumRunner;
    private final RunStore runStore;

    public TestRunService(VibiumRunner vibiumRunner, RunStore runStore) {
        this.vibiumRunner = vibiumRunner;
        this.runStore = runStore;
    }

    public RunStatus start(List<TestScenario> scenarios, RunConfig config) {
        String runId = "RUN-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();
        config.setRunId(runId);
        RunStatus status = new RunStatus();
        status.setRunId(runId);
        status.setStatus("QUEUED");
        status.setTotal(scenarios.size());
        runStore.put(status);

        CompletableFuture.runAsync(() -> {
            vibiumRunner.execute(scenarios, config, status);
            runStore.put(status);
        });
        return status;
    }
}
