package com.llmart.llm.model;

public class AgentAction {
    private String action;
    private String selectorType;
    private String target;
    private String value;
    private String key;
    private Integer seconds;

    public String getAction() { return action; }
    public void setAction(String action) { this.action = action; }
    public String getSelectorType() { return selectorType; }
    public void setSelectorType(String selectorType) { this.selectorType = selectorType; }
    public String getTarget() { return target; }
    public void setTarget(String target) { this.target = target; }
    public String getValue() { return value; }
    public void setValue(String value) { this.value = value; }
    public String getKey() { return key; }
    public void setKey(String key) { this.key = key; }
    public Integer getSeconds() { return seconds; }
    public void setSeconds(Integer seconds) { this.seconds = seconds; }

    public static AgentAction of(String action, String selectorType, String target, String value) {
        AgentAction a = new AgentAction();
        a.setAction(action);
        a.setSelectorType(selectorType);
        a.setTarget(target);
        a.setValue(value);
        return a;
    }
}
