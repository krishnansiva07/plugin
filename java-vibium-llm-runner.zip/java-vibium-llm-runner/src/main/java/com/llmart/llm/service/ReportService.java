package com.llmart.llm.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.llmart.llm.model.RunStatus;
import com.llmart.llm.model.ScenarioResult;
import com.llmart.llm.model.StepResult;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Service;

import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.stream.Stream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

@Service
public class ReportService {
    private final ObjectMapper mapper = new ObjectMapper()
            .registerModule(new JavaTimeModule())
            .disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS)
            .enable(SerializationFeature.INDENT_OUTPUT);

    public void writeAll(RunStatus status, Path runDir) throws Exception {
        Files.createDirectories(runDir);
        mapper.writeValue(runDir.resolve("report.json").toFile(), status);
        writeExcel(status, runDir.resolve("report.xlsx"));
        zipScreenshots(runDir.resolve("screenshots"), runDir.resolve("screenshots.zip"));
    }

    private void writeExcel(RunStatus status, Path output) throws Exception {
        try (Workbook wb = new XSSFWorkbook()) {
            CellStyle titleStyle = wb.createCellStyle();
            Font titleFont = wb.createFont();
            titleFont.setBold(true);
            titleFont.setFontHeightInPoints((short) 14);
            titleStyle.setFont(titleFont);

            CellStyle headerStyle = wb.createCellStyle();
            Font headerFont = wb.createFont();
            headerFont.setBold(true);
            headerStyle.setFont(headerFont);
            headerStyle.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
            headerStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
            headerStyle.setBorderBottom(BorderStyle.THIN);

            Sheet summary = wb.createSheet("Summary");
            int r = 0;
            Row title = summary.createRow(r++);
            title.createCell(0).setCellValue("Java Vibium LLM Test Run Summary");
            title.getCell(0).setCellStyle(titleStyle);
            r++;
            r = summaryRow(summary, r, "Run ID", status.getRunId());
            r = summaryRow(summary, r, "Status", status.getStatus());
            r = summaryRow(summary, r, "Started At", status.getStartedAt() == null ? "" : status.getStartedAt().toString());
            r = summaryRow(summary, r, "Finished At", status.getFinishedAt() == null ? "" : status.getFinishedAt().toString());
            r = summaryRow(summary, r, "Total", String.valueOf(status.getTotal()));
            r = summaryRow(summary, r, "Passed", String.valueOf(status.getPassed()));
            r = summaryRow(summary, r, "Failed", String.valueOf(status.getFailed()));
            r = summaryRow(summary, r, "Message", status.getMessage() == null ? "" : status.getMessage());
            summary.autoSizeColumn(0);
            summary.autoSizeColumn(1);

            Sheet steps = wb.createSheet("Step Results");
            Row h = steps.createRow(0);
            String[] headers = {"Scenario ID", "Scenario Name", "Scenario Status", "Step No", "Instruction", "Action JSON", "Step Status", "Duration ms", "Screenshot", "Error"};
            for (int i = 0; i < headers.length; i++) {
                Cell c = h.createCell(i);
                c.setCellValue(headers[i]);
                c.setCellStyle(headerStyle);
            }
            int rowNo = 1;
            for (ScenarioResult sr : status.getScenarios()) {
                for (StepResult st : sr.getSteps()) {
                    Row row = steps.createRow(rowNo++);
                    row.createCell(0).setCellValue(sr.getId());
                    row.createCell(1).setCellValue(sr.getName());
                    row.createCell(2).setCellValue(sr.getStatus());
                    row.createCell(3).setCellValue(st.getStepNo());
                    row.createCell(4).setCellValue(st.getInstruction());
                    row.createCell(5).setCellValue(st.getActionJson());
                    row.createCell(6).setCellValue(st.getStatus());
                    row.createCell(7).setCellValue(st.getDurationMs());
                    row.createCell(8).setCellValue(st.getScreenshot() == null ? "" : st.getScreenshot());
                    row.createCell(9).setCellValue(st.getErrorMessage() == null ? "" : st.getErrorMessage());
                }
                if (sr.getSteps().isEmpty()) {
                    Row row = steps.createRow(rowNo++);
                    row.createCell(0).setCellValue(sr.getId());
                    row.createCell(1).setCellValue(sr.getName());
                    row.createCell(2).setCellValue(sr.getStatus());
                    row.createCell(9).setCellValue(sr.getErrorMessage() == null ? "" : sr.getErrorMessage());
                }
            }
            for (int i = 0; i < headers.length; i++) {
                steps.autoSizeColumn(i);
                if (steps.getColumnWidth(i) > 18000) steps.setColumnWidth(i, 18000);
            }
            steps.createFreezePane(0, 1);

            try (OutputStream os = Files.newOutputStream(output)) {
                wb.write(os);
            }
        }
    }

    private int summaryRow(Sheet sheet, int rowNo, String key, String value) {
        Row row = sheet.createRow(rowNo);
        row.createCell(0).setCellValue(key);
        row.createCell(1).setCellValue(value);
        return rowNo + 1;
    }

    private void zipScreenshots(Path screenshotsDir, Path output) throws Exception {
        if (!Files.exists(screenshotsDir)) {
            Files.createFile(output);
            return;
        }
        try (ZipOutputStream zos = new ZipOutputStream(Files.newOutputStream(output));
             Stream<Path> paths = Files.walk(screenshotsDir)) {
            paths.filter(Files::isRegularFile).forEach(path -> {
                try {
                    zos.putNextEntry(new ZipEntry(screenshotsDir.relativize(path).toString().replace("\\", "/")));
                    Files.copy(path, zos);
                    zos.closeEntry();
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            });
        }
    }
}
