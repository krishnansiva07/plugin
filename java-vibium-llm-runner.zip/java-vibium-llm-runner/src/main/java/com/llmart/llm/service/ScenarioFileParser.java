package com.llmart.llm.service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.llmart.llm.model.TestScenario;
import org.apache.poi.ss.usermodel.*;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.InputStream;
import java.util.*;

@Service
public class ScenarioFileParser {
    private final ObjectMapper objectMapper = new ObjectMapper();

    public List<TestScenario> parse(MultipartFile file) throws Exception {
        String filename = Optional.ofNullable(file.getOriginalFilename()).orElse("scenario.json").toLowerCase(Locale.ROOT);
        if (filename.endsWith(".xlsx") || filename.endsWith(".xls")) {
            return parseExcel(file.getInputStream());
        }
        return parseJson(file.getBytes());
    }

    private List<TestScenario> parseJson(byte[] bytes) throws Exception {
        JsonNode root = objectMapper.readTree(bytes);
        JsonNode arrayNode = root.isArray() ? root : root.path("scenarios");
        if (!arrayNode.isArray()) {
            throw new IllegalArgumentException("JSON must be an array or object with scenarios array");
        }
        List<TestScenario> scenarios = objectMapper.convertValue(arrayNode, new TypeReference<List<TestScenario>>() {});
        normalize(scenarios);
        return scenarios;
    }

    private List<TestScenario> parseExcel(InputStream inputStream) throws Exception {
        try (Workbook workbook = WorkbookFactory.create(inputStream)) {
            Sheet sheet = workbook.getSheetAt(0);
            if (sheet == null) {
                throw new IllegalArgumentException("Excel file has no sheet");
            }
            Row headerRow = sheet.getRow(0);
            if (headerRow == null) {
                throw new IllegalArgumentException("Excel first row must contain headers");
            }

            Map<String, Integer> headers = new LinkedHashMap<>();
            for (Cell cell : headerRow) {
                String header = cellToString(cell).trim();
                if (!header.isBlank()) {
                    headers.put(header.toLowerCase(Locale.ROOT), cell.getColumnIndex());
                }
            }

            List<TestScenario> scenarios = new ArrayList<>();
            for (int i = 1; i <= sheet.getLastRowNum(); i++) {
                Row row = sheet.getRow(i);
                if (row == null) continue;

                String id = cell(row, headers, "id");
                String name = cell(row, headers, "name");
                String stepsRaw = cell(row, headers, "steps");
                if (isBlank(id) && isBlank(name) && isBlank(stepsRaw)) continue;

                TestScenario scenario = new TestScenario();
                scenario.setId(isBlank(id) ? "TC" + String.format("%03d", i) : id.trim());
                scenario.setName(isBlank(name) ? scenario.getId() : name.trim());
                scenario.setUrl(cell(row, headers, "url"));
                scenario.setExpected(cell(row, headers, "expected"));
                scenario.setSteps(splitSteps(stepsRaw));

                Map<String, Object> data = new LinkedHashMap<>();
                for (Map.Entry<String, Integer> h : headers.entrySet()) {
                    String key = h.getKey();
                    if (key.startsWith("data.")) {
                        data.put(key.substring("data.".length()), cellToString(row.getCell(h.getValue())));
                    }
                }
                String testDataJson = firstNonBlank(cell(row, headers, "testdatajson"), cell(row, headers, "testdata"), cell(row, headers, "data"));
                if (!isBlank(testDataJson)) {
                    try {
                        Map<String, Object> jsonData = objectMapper.readValue(testDataJson, new TypeReference<Map<String, Object>>() {});
                        data.putAll(jsonData);
                    } catch (Exception e) {
                        data.put("raw", testDataJson);
                    }
                }
                scenario.setData(data);
                scenarios.add(scenario);
            }
            normalize(scenarios);
            return scenarios;
        }
    }

    private void normalize(List<TestScenario> scenarios) {
        int i = 1;
        for (TestScenario scenario : scenarios) {
            if (isBlank(scenario.getId())) scenario.setId("TC" + String.format("%03d", i));
            if (isBlank(scenario.getName())) scenario.setName(scenario.getId());
            if (scenario.getSteps() == null) scenario.setSteps(new ArrayList<>());
            if (scenario.getData() == null) scenario.setData(new LinkedHashMap<>());
            i++;
        }
    }

    private List<String> splitSteps(String stepsRaw) {
        if (isBlank(stepsRaw)) return new ArrayList<>();
        return Arrays.stream(stepsRaw.split("\\r?\\n|\\|"))
                .map(String::trim)
                .filter(s -> !s.isBlank())
                .toList();
    }

    private String cell(Row row, Map<String, Integer> headers, String header) {
        Integer index = headers.get(header.toLowerCase(Locale.ROOT));
        return index == null ? "" : cellToString(row.getCell(index));
    }

    private String cellToString(Cell cell) {
        if (cell == null) return "";
        DataFormatter formatter = new DataFormatter();
        return formatter.formatCellValue(cell);
    }

    private boolean isBlank(String value) {
        return value == null || value.trim().isEmpty();
    }

    private String firstNonBlank(String... values) {
        for (String value : values) {
            if (!isBlank(value)) return value;
        }
        return "";
    }
}
