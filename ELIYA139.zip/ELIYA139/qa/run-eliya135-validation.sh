#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
qa/run-eliya134-validation.sh
qa/run-eliya135-mcp-smoke.sh
printf '\nELIYA135 MCP/tool-test evidence source and browser regression suite: PASS\n'
printf 'NOTE: This is not a full Maven build or a live run of @123.\n'
