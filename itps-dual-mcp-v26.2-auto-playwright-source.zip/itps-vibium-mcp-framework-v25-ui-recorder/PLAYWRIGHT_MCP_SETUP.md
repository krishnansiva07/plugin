# Playwright MCP automatic startup

No `C:\tools\playwright-mcp` installation is required.

When the UI runner is **Playwright MCP**, the backend starts:

```cmd
npx.cmd -y @playwright/mcp@latest --isolated
```

The framework then initializes the MCP session over STDIO, lists tools, executes the selected Excel sheets, calls `browser_close`, and terminates the MCP process.

## Machine requirements

- Java 17
- Node.js with `node`, `npm`, and `npx` available in PATH
- Chrome or Edge
- Network access to npm on first use, or an existing npm cache

## Vibium

Only Vibium uses the configured portable tools folder:

```properties
itps.vibium.mcp.command=C:\\tools\\vibium-portable\\node_modules\\.bin\\vibium.cmd
itps.vibium.mcp.args=mcp
```

## Playwright MCP

```properties
itps.playwright.mcp.command=npx.cmd
itps.playwright.mcp.args=-y @playwright/mcp@latest --isolated
itps.playwright.mcp.request-timeout-seconds=120
```
