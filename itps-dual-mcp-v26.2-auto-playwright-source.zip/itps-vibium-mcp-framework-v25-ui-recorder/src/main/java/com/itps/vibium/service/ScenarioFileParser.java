package com.itps.vibium.service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.itps.vibium.model.TestScenario;
import org.apache.poi.ss.usermodel.*;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.InputStream;
import java.util.*;

@Service
public class ScenarioFileParser {
    private final ObjectMapper objectMapper = new ObjectMapper();

    public List<TestScenario> parse(MultipartFile file) throws Exception { return parse(file, List.of()); }

    public List<TestScenario> parse(MultipartFile file, String sheetName) throws Exception {
        return parse(file, blank(sheetName) ? List.of() : List.of(sheetName));
    }

    public List<TestScenario> parse(MultipartFile file, List<String> sheetNames) throws Exception {
        String filename = Optional.ofNullable(file.getOriginalFilename()).orElse("scenario.json").toLowerCase(Locale.ROOT);
        if (filename.endsWith(".xlsx") || filename.endsWith(".xls")) return parseExcel(file.getInputStream(), sheetNames);
        return parseJson(file.getBytes());
    }

    public List<String> sheetNames(MultipartFile file) throws Exception {
        String filename = Optional.ofNullable(file.getOriginalFilename()).orElse("").toLowerCase(Locale.ROOT);
        if (!(filename.endsWith(".xlsx") || filename.endsWith(".xls"))) return List.of();
        try (Workbook workbook = WorkbookFactory.create(file.getInputStream())) {
            List<String> names = new ArrayList<>();
            for (int i = 0; i < workbook.getNumberOfSheets(); i++) names.add(workbook.getSheetName(i));
            return names;
        }
    }

    private List<TestScenario> parseJson(byte[] bytes) throws Exception {
        JsonNode root = objectMapper.readTree(bytes);
        JsonNode arrayNode = root.isArray() ? root : root.path("scenarios");
        if (!arrayNode.isArray()) throw new IllegalArgumentException("JSON must be an array or an object with scenarios array");
        List<TestScenario> scenarios = objectMapper.convertValue(arrayNode, new TypeReference<List<TestScenario>>() {});
        normalize(scenarios);
        return scenarios;
    }

    private List<TestScenario> parseExcel(InputStream inputStream, List<String> selectedSheetNames) throws Exception {
        try (Workbook workbook = WorkbookFactory.create(inputStream)) {
            List<Sheet> sheets = new ArrayList<>();
            if (selectedSheetNames == null || selectedSheetNames.isEmpty()) {
                sheets.add(workbook.getSheetAt(0));
            } else {
                for (String name : selectedSheetNames) {
                    Sheet sheet = workbook.getSheet(name);
                    if (sheet == null) throw new IllegalArgumentException("Excel sheet not found: " + name);
                    sheets.add(sheet);
                }
            }
            List<TestScenario> scenarios = new ArrayList<>();
            Set<String> usedIds = new HashSet<>();
            for (Sheet sheet : sheets) parseSheet(sheet, scenarios, usedIds, sheets.size() > 1);
            normalize(scenarios);
            return scenarios;
        }
    }

    private void parseSheet(Sheet sheet, List<TestScenario> scenarios, Set<String> usedIds, boolean multiSheet) throws Exception {
        Row headerRow = sheet.getRow(0);
        if (headerRow == null) throw new IllegalArgumentException("Excel first row must contain headers in sheet: " + sheet.getSheetName());
        Map<String, Integer> headers = new LinkedHashMap<>();
        for (Cell cell : headerRow) {
            String header = cellToString(cell).trim();
            if (!header.isBlank()) headers.put(header.toLowerCase(Locale.ROOT), cell.getColumnIndex());
        }
        for (int i = 1; i <= sheet.getLastRowNum(); i++) {
            Row row = sheet.getRow(i);
            if (row == null) continue;
            String id = cell(row, headers, "id");
            String name = cell(row, headers, "name");
            String stepsRaw = cell(row, headers, "steps");
            String runValue = cell(row, headers, "run");
            if (headers.containsKey("run") && !isRunEnabled(runValue)) continue;
            if (blank(id) && blank(name) && blank(stepsRaw)) continue;
            String baseId = blank(id) ? "TC" + String.format("%03d", i) : id.trim();
            String uniqueId = baseId;
            if (usedIds.contains(uniqueId)) uniqueId = safeSheetPrefix(sheet.getSheetName()) + "_" + baseId;
            int suffix = 2;
            while (usedIds.contains(uniqueId)) uniqueId = safeSheetPrefix(sheet.getSheetName()) + "_" + baseId + "_" + suffix++;
            usedIds.add(uniqueId);
            TestScenario scenario = new TestScenario();
            scenario.setId(uniqueId);
            scenario.setName((multiSheet ? "[" + sheet.getSheetName() + "] " : "") + (blank(name) ? baseId : name.trim()));
            scenario.setUrl(cell(row, headers, "url"));
            scenario.setExpected(cell(row, headers, "expected"));
            scenario.setSteps(splitSteps(stepsRaw));
            Map<String, Object> data = new LinkedHashMap<>();
            data.put("sourceSheet", sheet.getSheetName());
            for (Map.Entry<String, Integer> h : headers.entrySet()) {
                String key = h.getKey();
                if (key.startsWith("data.")) data.put(key.substring("data.".length()), cellToString(row.getCell(h.getValue())));
            }
            String dataJson = firstNonBlank(cell(row, headers, "testdatajson"), cell(row, headers, "testdata"), cell(row, headers, "data"));
            if (!blank(dataJson)) {
                try { data.putAll(objectMapper.readValue(dataJson, new TypeReference<Map<String, Object>>() {})); }
                catch (Exception e) { data.put("raw", dataJson); }
            }
            scenario.setData(data);
            scenarios.add(scenario);
        }
    }

    private String safeSheetPrefix(String value) {
        return value == null ? "SHEET" : value.trim().replaceAll("[^A-Za-z0-9]+", "_").replaceAll("^_+|_+$", "");
    }

    private void normalize(List<TestScenario> scenarios) {
        int i = 1;
        for (TestScenario scenario : scenarios) {
            if (blank(scenario.getId())) scenario.setId("TC" + String.format("%03d", i));
            if (blank(scenario.getName())) scenario.setName(scenario.getId());
            if (scenario.getSteps() == null) scenario.setSteps(new ArrayList<>());
            if (scenario.getData() == null) scenario.setData(new LinkedHashMap<>());
            scenario.setSteps(scenario.getSteps().stream().map(this::replaceWindowsLineNoise).filter(s -> !blank(s)).toList());
            i++;
        }
    }

    private String replaceWindowsLineNoise(String s) { return s == null ? "" : s.trim(); }

    private List<String> splitSteps(String stepsRaw) {
        if (blank(stepsRaw)) return new ArrayList<>();
        return Arrays.stream(stepsRaw.split("\\r?\\n|\\|"))
                .map(String::trim).filter(s -> !s.isBlank()).toList();
    }

    private String cell(Row row, Map<String, Integer> headers, String header) {
        Integer index = headers.get(header.toLowerCase(Locale.ROOT));
        return index == null ? "" : cellToString(row.getCell(index));
    }

    private String cellToString(Cell cell) {
        if (cell == null) return "";
        return new DataFormatter().formatCellValue(cell);
    }

    private boolean isRunEnabled(String value) {
        if (blank(value)) return false;
        String v = value.trim().toLowerCase(Locale.ROOT);
        return Set.of("true","yes","y","1","run","execute","enabled").contains(v);
    }

    private boolean blank(String value) { return value == null || value.trim().isEmpty(); }
    private String firstNonBlank(String... values) {
        for (String v : values) if (!blank(v)) return v;
        return "";
    }
}
