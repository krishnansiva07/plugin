package com.itps.vibium.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.itps.vibium.model.McpTool;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicLong;

public class McpClient implements AutoCloseable {
    private final ObjectMapper mapper = new ObjectMapper();
    private final AtomicLong idCounter = new AtomicLong(1);
    private final Map<Long, CompletableFuture<JsonNode>> pending = new ConcurrentHashMap<>();
    private final List<String> logs = Collections.synchronizedList(new ArrayList<>());
    private final List<Map<String, Object>> transcript = Collections.synchronizedList(new ArrayList<>());
    private final String command;
    private final List<String> args;
    private final Duration timeout;
    private final boolean skipBrowserDownload;
    private Process process;
    private BufferedWriter writer;
    private ExecutorService ioPool;

    public McpClient(String command, List<String> args, Duration timeout, boolean skipBrowserDownload) {
        this.command = command;
        this.args = args == null ? List.of() : args;
        this.timeout = timeout == null ? Duration.ofSeconds(60) : timeout;
        this.skipBrowserDownload = skipBrowserDownload;
    }

    public void start() throws Exception {
        List<String> requestedCommand = new ArrayList<>();
        requestedCommand.add(command);
        requestedCommand.addAll(args);
        List<String> cmd = platformCommand(requestedCommand);
        ProcessBuilder builder = new ProcessBuilder(cmd);
        builder.redirectErrorStream(false);
        if (skipBrowserDownload) builder.environment().put("VIBIUM_SKIP_BROWSER_DOWNLOAD", "1");
        transcript.add(Map.of("ts", Instant.now().toString(), "event", "process_start", "command", cmd));
        process = builder.start();
        writer = new BufferedWriter(new OutputStreamWriter(process.getOutputStream(), StandardCharsets.UTF_8));
        ioPool = Executors.newFixedThreadPool(2, r -> {
            Thread t = new Thread(r, "mcp-io");
            t.setDaemon(true);
            return t;
        });
        ioPool.submit(this::readStdoutLoop);
        ioPool.submit(this::readStderrLoop);
    }

    private List<String> platformCommand(List<String> requestedCommand) {
        if (requestedCommand == null || requestedCommand.isEmpty()) {
            throw new IllegalArgumentException("MCP command is empty");
        }
        String os = System.getProperty("os.name", "").toLowerCase(Locale.ROOT);
        String executable = requestedCommand.get(0).toLowerCase(Locale.ROOT);
        if (os.contains("win") && (executable.endsWith(".cmd") || executable.endsWith(".bat"))) {
            List<String> wrapped = new ArrayList<>();
            wrapped.add("cmd.exe");
            wrapped.add("/d");
            wrapped.add("/s");
            wrapped.add("/c");
            wrapped.addAll(requestedCommand);
            return wrapped;
        }
        return requestedCommand;
    }

    public List<McpTool> initializeAndListTools() throws Exception {
        ObjectNode params = mapper.createObjectNode();
        params.put("protocolVersion", "2024-11-05");
        ObjectNode capabilities = params.putObject("capabilities");
        capabilities.putObject("sampling");
        ObjectNode roots = capabilities.putObject("roots");
        roots.put("listChanged", false);
        ObjectNode clientInfo = params.putObject("clientInfo");
        clientInfo.put("name", "itps-dual-mcp-framework");
        clientInfo.put("version", "26.2.0");
        request("initialize", params);

        ObjectNode initialized = mapper.createObjectNode();
        initialized.put("jsonrpc", "2.0");
        initialized.put("method", "notifications/initialized");
        initialized.set("params", mapper.createObjectNode());
        send(initialized);

        JsonNode toolsResponse = request("tools/list", mapper.createObjectNode());
        List<McpTool> tools = new ArrayList<>();
        JsonNode toolsNode = toolsResponse.path("tools");
        if (toolsNode.isArray()) {
            for (JsonNode n : toolsNode) {
                tools.add(new McpTool(n.path("name").asText(), n.path("description").asText(""), n.path("inputSchema")));
            }
        }
        return tools;
    }

    public JsonNode callTool(String name, Map<String, Object> arguments) throws Exception {
        ObjectNode params = mapper.createObjectNode();
        params.put("name", name);
        params.set("arguments", mapper.valueToTree(arguments == null ? Map.of() : arguments));
        return request("tools/call", params);
    }

    public JsonNode request(String method, JsonNode params) throws Exception {
        long id = idCounter.getAndIncrement();
        ObjectNode msg = mapper.createObjectNode();
        msg.put("jsonrpc", "2.0");
        msg.put("id", id);
        msg.put("method", method);
        msg.set("params", params == null ? mapper.createObjectNode() : params);
        CompletableFuture<JsonNode> future = new CompletableFuture<>();
        pending.put(id, future);
        long start = System.currentTimeMillis();
        send(msg);
        try {
            JsonNode response = future.get(timeout.toMillis(), TimeUnit.MILLISECONDS);
            long ms = System.currentTimeMillis() - start;
            transcript.add(Map.of("ts", Instant.now().toString(), "direction", "response", "method", method, "id", id, "ms", ms, "payload", compact(response.toString(), 8000)));
            if (response.has("error")) throw new IllegalStateException("MCP error for " + method + ": " + response.path("error"));
            return response.path("result");
        } catch (TimeoutException te) {
            pending.remove(id);
            transcript.add(Map.of("ts", Instant.now().toString(), "direction", "timeout", "method", method, "id", id, "timeoutSeconds", timeout.toSeconds()));
            throw new IllegalStateException("MCP timeout after " + timeout.toSeconds() + " seconds for method " + method);
        }
    }

    private synchronized void send(ObjectNode msg) throws IOException {
        String line = mapper.writeValueAsString(msg);
        transcript.add(Map.of("ts", Instant.now().toString(), "direction", "request", "payload", compact(line, 8000)));
        writer.write(line);
        writer.newLine();
        writer.flush();
    }

    private void readStdoutLoop() {
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream(), StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String trimmed = line.trim();
                if (trimmed.isBlank()) continue;
                if (!trimmed.startsWith("{")) {
                    logs.add("OUT: " + trimmed);
                    transcript.add(Map.of("ts", Instant.now().toString(), "direction", "stdout", "line", trimmed));
                    continue;
                }
                try {
                    JsonNode msg = mapper.readTree(trimmed);
                    if (msg.has("id")) {
                        long id = msg.path("id").asLong();
                        CompletableFuture<JsonNode> future = pending.remove(id);
                        if (future != null) future.complete(msg);
                    } else {
                        logs.add("NOTIFY: " + trimmed);
                        transcript.add(Map.of("ts", Instant.now().toString(), "direction", "notify", "payload", compact(trimmed, 8000)));
                    }
                } catch (Exception parseError) {
                    logs.add("OUT-NON-JSON: " + trimmed);
                }
            }
        } catch (Exception e) {
            logs.add("stdout reader closed: " + e.getMessage());
        }
    }

    private void readStderrLoop() {
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getErrorStream(), StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (!line.isBlank()) {
                    logs.add("ERR: " + line);
                    transcript.add(Map.of("ts", Instant.now().toString(), "direction", "stderr", "line", line));
                }
            }
        } catch (Exception e) {
            logs.add("stderr reader closed: " + e.getMessage());
        }
    }

    public List<String> getLogs() { return List.copyOf(logs); }
    public List<Map<String, Object>> getTranscript() { return List.copyOf(transcript); }

    public void writeDiagnostics(Path runDir) {
        try {
            Files.createDirectories(runDir);
            mapper.writerWithDefaultPrettyPrinter().writeValue(runDir.resolve("mcp-transcript.json").toFile(), getTranscript());
            Files.writeString(runDir.resolve("mcp-process.log"), String.join(System.lineSeparator(), getLogs()), StandardCharsets.UTF_8);
        } catch (Exception ignored) {}
    }

    @Override
    public void close() {
        try { if (writer != null) writer.close(); } catch (Exception ignored) {}
        if (process != null && process.isAlive()) {
            process.destroy();
            try { if (!process.waitFor(3, TimeUnit.SECONDS)) process.destroyForcibly(); }
            catch (InterruptedException e) { Thread.currentThread().interrupt(); process.destroyForcibly(); }
        }
        if (ioPool != null) ioPool.shutdownNow();
    }

    private String compact(String s, int max) {
        if (s == null) return "";
        String oneLine = s.replaceAll("\\s+", " ").trim();
        return oneLine.length() <= max ? oneLine : oneLine.substring(0, max) + "...";
    }
}
