# V26 Dual Engine Update

## Added
- Execution engine selector: `VIBIUM` or `PLAYWRIGHT`.
- Vibium routes to the existing `ItpsMcpRunner`.
- Superseded in V26.2: Playwright routes only to `PlaywrightMcpExecutionEngine` and starts `@playwright/mcp` dynamically through npx.
- Excel worksheet list is rendered as checkboxes.
- Multiple selected worksheets are parsed and executed in one run.
- Duplicate test IDs across sheets are safely prefixed with the worksheet name.
- Playwright screenshots and existing consolidated reports use the same run output folder.

## Playwright supported step forms
- `Navigate to https://...`
- `Click "Save"`
- `Click "Save" using xpath="//button[.='Save']"`
- `Click "Save" using css="#save"`
- `Type "BCEF" in "Search" using xpath="//input[@name='search']"`
- `Select "BCEF" from "Fund" using css="select[name='fund']"`
- `Check`, `Uncheck`, `Press`, `Upload`, `Double-click`, and `Verify`.

## Runtime prerequisites
- Java 17
- Chrome/Edge installed, or a browser executable discovered by the UI
- Vibium portable + Node.js only when VIBIUM is selected
- Playwright Java dependency is packaged in the Spring Boot JAR; installed Chrome/Edge can be launched through executablePath.

## Build
`mvn clean package -DskipTests`

## Run
`java -jar target/itps-vibium-mcp-framework-26.0.0-DUAL-ENGINE.jar`

## V26.1 Playwright MCP correction
- UI runner value is now `PLAYWRIGHT_MCP`.
- Selecting it starts the configured Microsoft `@playwright/mcp` process over STDIO.
- Backend performs MCP initialize, tools/list, and tools/call.
- Deterministic actions use `browser_navigate`, `browser_click`, `browser_type`, `browser_select_option`, `browser_press_key`, `browser_file_upload`, `browser_wait_for`, and `browser_take_screenshot`.
- Optional LLM healing uses a fresh `browser_snapshot` and can call only discovered Playwright MCP tools.
- `browser_run_code_unsafe` is explicitly forbidden in the healing prompt.
