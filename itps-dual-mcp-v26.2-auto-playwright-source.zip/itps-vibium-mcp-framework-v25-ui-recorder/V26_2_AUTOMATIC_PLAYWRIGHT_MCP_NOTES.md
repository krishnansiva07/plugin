# V26.2 automatic Playwright MCP changes

- Removed direct Playwright Java dependency and executor.
- Playwright selection now routes only to `PlaywrightMcpExecutionEngine`.
- Starts Playwright MCP dynamically through `npx.cmd -y @playwright/mcp@latest`.
- Vibium continues to use the portable tools path.
- Supports multi-sheet checkbox selection from the uploaded Excel workbook.
- Both runners use the common run store, reports, screenshots, retries, and LLM healing records.
- Playwright MCP process is closed after each run.
