@echo off
setlocal
cd /d "%~dp0"
title ITPS Dual MCP Framework V26.2

where java >nul 2>&1 || (echo ERROR: Java 17 is not available in PATH.& pause & exit /b 1)
where node >nul 2>&1 || (echo ERROR: Node.js is not available in PATH.& pause & exit /b 1)
where npx >nul 2>&1 || (echo ERROR: npx is not available in PATH.& pause & exit /b 1)

set "JAR="
for %%F in (target\itps-vibium-mcp-framework-26.2.0-DUAL-MCP.jar itps-vibium-mcp-framework-26.2.0-DUAL-MCP.jar itps-framework.jar) do (
  if exist "%%F" set "JAR=%%F"
)
if not defined JAR (echo ERROR: Executable JAR not found.& pause & exit /b 1)

start "" cmd /c "timeout /t 6 /nobreak >nul && start http://localhost:8090"
java -jar "%JAR%" --spring.config.additional-location=optional:file:./application.properties
pause
