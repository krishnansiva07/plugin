package com.llmart.llm.dto;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.llmart.llm.service.ModelCapabilityRegistry;

import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.Locale;
import java.util.Set;
import java.util.stream.Collectors;

public record ChatSettings(
        String baseUrl,
        String model,
        String chatModel,
        String visionModel,
        String analysisModel,
        String plannerModel,
        String planValidatorModel,
        String criticModel,
        String embeddingModel,
        Boolean smartModelRouting,
        Boolean semanticRetrieval,
        Double temperature,
        Integer maxTokens,
        Integer contextChars,
        Integer contextWindowTokens,
        String modelContextWindows,
        String modelTypes,
        Boolean autoCompact,
        Integer compactionKeepTokens,
        Integer compactionBufferTokens,
        Integer oldToolOutputChars,
        String systemPrompt,
        Boolean useFileContext,
        Integer agentMaxSteps,
        Boolean agentAllowCommands,
        String agentEditPermission,
        String agentShellPermission,
        @JsonAlias("agentGitPermission") String agentReviewPermission,
        Boolean agentAutoApprove,
        String agentExtraCommands,
        String agentMcpPermission,
        String agentTaskPermission,
        String agentLspPermission,
        Boolean agentParallelReadTools,
        Boolean agentPlanApproval,
        String agentFallbackModels,
        Integer agentRecoveryAttempts,
        Boolean agentConfirmFileDeletion
) {
    public double safeTemperature() { return temperature == null ? 0.7 : Math.max(0.0, Math.min(2.0, temperature)); }
    /**
     * 0 means provider-managed maximum. Positive values are passed through without an application-side cap.
     */
    public int safeMaxTokens() { return maxTokens == null || maxTokens <= 0 ? 0 : maxTokens; }
    /**
     * Legacy character budget kept for settings compatibility only. Agent context management is token based.
     */
    public int safeContextChars() { return contextChars == null || contextChars <= 0 ? 0 : contextChars; }

    /**
     * Provider/model context-window size in tokens. A positive explicit setting always wins. When it is left at 0,
     * the runtime uses conservative model-name hints and otherwise falls back to 128k rather than waiting for an overflow.
     */
    public int safeContextWindowTokens() { return safeContextWindowTokens(model); }

    /** Context budget for the model that is actually handling the current request/failover turn. */
    public int safeContextWindowTokens(String activeModel) {
        Integer perModel = configuredContextWindow(activeModel);
        if (perModel != null && perModel > 0) return Math.max(512, perModel);
        if (contextWindowTokens != null && contextWindowTokens > 0) return Math.max(16_000, contextWindowTokens);
        if (contextChars != null && contextChars > 0) return Math.max(16_000, contextChars / 4);
        return Math.max(16_000, ModelCapabilityRegistry.contextWindowHint(activeModel));
    }

    /** Optional per-model context-window overrides supplied by the editable UI model library. */
    private Integer configuredContextWindow(String activeModel) {
        if (modelContextWindows == null || modelContextWindows.isBlank() || activeModel == null || activeModel.isBlank()) return null;
        String wanted = activeModel.trim();
        for (String line : modelContextWindows.split("[\r\n,]+")) {
            String value = line == null ? "" : line.trim();
            if (value.isBlank()) continue;
            int split = value.lastIndexOf('=');
            if (split <= 0 || split >= value.length() - 1) continue;
            String id = value.substring(0, split).trim();
            if (!wanted.equalsIgnoreCase(id)) continue;
            try { return Integer.parseInt(value.substring(split + 1).trim()); } catch (NumberFormatException ignored) { return null; }
        }
        return null;
    }


    /** Optional editable model-library type mapping supplied by the UI as modelId=chat|vision|ocr|embedding. */
    public String configuredModelType(String activeModel) {
        if (modelTypes == null || modelTypes.isBlank() || activeModel == null || activeModel.isBlank()) return "";
        String wanted = activeModel.trim();
        for (String line : modelTypes.split("[\r\n,]+")) {
            String value = line == null ? "" : line.trim();
            if (value.isBlank()) continue;
            int split = value.lastIndexOf('=');
            if (split <= 0 || split >= value.length() - 1) continue;
            String id = value.substring(0, split).trim();
            if (!wanted.equalsIgnoreCase(id)) continue;
            String type = value.substring(split + 1).trim().toLowerCase(Locale.ROOT);
            return Set.of("chat", "vision", "ocr", "embedding").contains(type) ? type : "";
        }
        return "";
    }

    public boolean configuredForRole(String activeModel, ModelCapabilityRegistry.Role role) {
        String type = configuredModelType(activeModel);
        boolean byLibraryType = !type.isBlank() && switch (role) {
            case VISION -> "vision".equals(type) || "ocr".equals(type);
            case OCR -> "ocr".equals(type);
            case EMBEDDING -> "embedding".equals(type);
            case EXECUTOR, ANALYSIS, PLANNER, PLAN_VALIDATOR, CRITIC -> "chat".equals(type) || "vision".equals(type);
        };
        // UI types are intentionally coarse (for example a multimodal coding model may be stored as Chat / Agent),
        // so a user-supplied type augments rather than erases capabilities known by the built-in registry.
        return byLibraryType || ModelCapabilityRegistry.profileFor(activeModel).preferredFor(role);
    }

    public boolean autoCompactEnabled() { return autoCompact == null || Boolean.TRUE.equals(autoCompact); }
    public int safeCompactionKeepTokens() { return safeCompactionKeepTokens(model); }
    public int safeCompactionKeepTokens(String activeModel) {
        int configured = compactionKeepTokens == null ? 8_000 : compactionKeepTokens;
        return Math.max(2_000, Math.min(configured, Math.max(2_000, safeContextWindowTokens(activeModel) / 2)));
    }
    public int safeCompactionBufferTokens() { return safeCompactionBufferTokens(model); }
    public int safeCompactionBufferTokens(String activeModel) {
        int configured = compactionBufferTokens == null ? 20_000 : compactionBufferTokens;
        return Math.max(4_000, Math.min(configured, Math.max(4_000, safeContextWindowTokens(activeModel) / 2)));
    }
    public int safeOldToolOutputChars() {
        int configured = oldToolOutputChars == null ? 1_200 : oldToolOutputChars;
        return Math.max(400, Math.min(configured, 20_000));
    }
    public boolean fileContextEnabled() { return useFileContext == null || useFileContext; }
    /** Agent mode intentionally uses one selected model for analysis, planning, execution and verification. */
    public boolean smartModelRoutingEnabled() { return false; }
    /** Agent retrieval is deterministic/local. No secondary embedding model is required for a run. */
    public boolean semanticRetrievalEnabled() { return false; }

    /** Chat can use a model independently from the Agent execution model. */
    public String chatModelOrPrimary() { return chatModel == null || chatModel.isBlank() ? (model == null ? "" : model.trim()) : chatModel.trim(); }

    public boolean hasDedicatedVisionModel() { return false; }
    /** Images are handled only in Chat mode by chatModelOrPrimary(); Agent never auto-routes to a vision role. */
    public String visionModelOrPrimary() { return chatModelOrPrimary(); }
    private String agentPrimaryModel() { return model == null ? "" : model.trim(); }
    public String analysisModelOrPrimary() { return agentPrimaryModel(); }
    public String plannerModelOrPrimary() { return agentPrimaryModel(); }
    public String planValidatorModelOrPrimary() { return agentPrimaryModel(); }
    public String criticModelOrPrimary() { return agentPrimaryModel(); }
    public String embeddingModelName() { return ""; }

    private String roleModel(String explicit, ModelCapabilityRegistry.Role role, String fallback) {
        if (smartModelRoutingEnabled()) {
            // Do not route a role to an obviously incompatible model type (for example an embedding model as planner).
            // User-defined Chat/Vision entries remain eligible through configuredForRole().
            if (explicit != null && !explicit.isBlank() && configuredForRole(explicit.trim(), role)) return explicit.trim();
            for (String candidate : agentModels()) {
                if (configuredForRole(candidate, role)) return candidate;
            }
        }
        return fallback == null ? "" : fallback.trim();
    }
    /**
     * Kept only for backward-compatible JSON/settings loading. Agent runs no longer use a fixed step ceiling.
     */
    public int safeAgentMaxSteps() { return 0; }
    public boolean agentCommandsAllowed() { return agentAllowCommands == null || Boolean.TRUE.equals(agentAllowCommands); }
    public String editPermission() { return normalizePermission(agentEditPermission, "allow"); }
    public String shellPermission() {
        if (!agentCommandsAllowed()) return "deny";
        return normalizePermission(agentShellPermission, "allow");
    }
    public String reviewPermission() { return normalizePermission(agentReviewPermission, "allow"); }
    public String mcpPermission() { return normalizePermission(agentMcpPermission, "allow"); }
    public String taskPermission() { return normalizePermission(agentTaskPermission, "allow"); }
    public String lspPermission() { return normalizePermission(agentLspPermission, "allow"); }
    public boolean parallelReadTools() { return agentParallelReadTools == null || Boolean.TRUE.equals(agentParallelReadTools); }
    public boolean autoApproveAgent() { return Boolean.TRUE.equals(agentAutoApprove); }
    /** Independent guard. Plan approval, general tool grants and auto-approve never bypass this check. */
    public boolean confirmFileDeletion() { return agentConfirmFileDeletion == null || agentConfirmFileDeletion; }
    /** Plan-first execution is mandatory; this flag controls only whether execution pauses for human approval. */
    public boolean planApprovalRequired() { return agentPlanApproval == null || Boolean.TRUE.equals(agentPlanApproval); }

    /**
     * Ordered Agent model pool: primary first, followed by at most two optional fallback models.
     * Duplicates and a fallback matching the primary are ignored case-insensitively. The runtime
     * always starts a new run on the primary model; fallbacks never overwrite the saved primary.
     */
    public java.util.List<String> agentModels() {
        java.util.List<String> ordered = new java.util.ArrayList<>();
        LinkedHashSet<String> seen = new LinkedHashSet<>();
        if (model != null && !model.isBlank()) {
            String primary = model.trim();
            ordered.add(primary);
            seen.add(primary.toLowerCase(Locale.ROOT));
        }
        if (agentFallbackModels != null && !agentFallbackModels.isBlank()) {
            for (String raw : agentFallbackModels.split("[,\r\n]+")) {
                String candidate = raw == null ? "" : raw.trim();
                if (candidate.isBlank()) continue;
                String key = candidate.toLowerCase(Locale.ROOT);
                if (!seen.add(key)) continue;
                ordered.add(candidate);
                if (ordered.size() >= 3) break; // primary + at most two fallbacks
            }
        }
        return java.util.List.copyOf(ordered);
    }

    /** Soft stall threshold before the runtime re-anchors the same model; reaching it never ends the run by itself. */
    public int safeAgentRecoveryAttempts() {
        int configured = agentRecoveryAttempts == null ? 3 : agentRecoveryAttempts;
        return Math.max(1, Math.min(configured, 50));
    }

    public Set<String> extraAgentCommands() {
        if (agentExtraCommands == null || agentExtraCommands.isBlank()) return Set.of();
        LinkedHashSet<String> result = Arrays.stream(agentExtraCommands.split("[,\\n]"))
                .map(String::trim)
                .filter(s -> s.matches("[A-Za-z0-9._+-]{1,80}"))
                .map(s -> s.toLowerCase(Locale.ROOT))
                .collect(Collectors.toCollection(LinkedHashSet::new));
        return Set.copyOf(result);
    }

    private String normalizePermission(String value, String fallback) {
        if (value == null) return fallback;
        String p = value.trim().toLowerCase(Locale.ROOT);
        return (p.equals("allow") || p.equals("ask") || p.equals("deny")) ? p : fallback;
    }
}
