package com.llmart.llm.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.llmart.llm.dto.ChatRequest;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.regex.Pattern;

/**
 * Lightweight MCP tool loop for Chat mode.
 *
 * Chat remains a conversational surface: ordinary prompts still use the existing streaming path.
 * When a prompt clearly asks for Jira/Confluence/GitLab/SonarQube/MCP data, this service gives the
 * selected Chat model read-only MCP tools, lets it retrieve the evidence it needs, and then returns
 * a normal assistant answer. Mutating MCP tools are deliberately not exposed from Chat; external
 * write actions stay in Agent mode where the existing MCP permission/approval flow is available.
 */
@Service
public class ChatMcpService {
    private static final Pattern ISSUE_KEY = Pattern.compile("(?i)(?:^|\\b)[A-Z][A-Z0-9]{1,15}-\\d+(?:\\b|$)");
    private static final Set<String> MCP_HINTS = Set.of(
            "mcp", "jira", "confluence", "gitlab", "sonarqube", "sonar", "atlassian",
            "ticket", "jira issue", "jira story", "acceptance criteria", "confluence page", "space key",
            "merge request", "pull request", "quality gate");

    private final OpenAiCompatibleClient llm;
    private final McpManager mcp;
    private final ObjectMapper mapper;

    public ChatMcpService(OpenAiCompatibleClient llm, McpManager mcp, ObjectMapper mapper) {
        this.llm = llm;
        this.mcp = mcp;
        this.mapper = mapper;
    }

    public boolean shouldHandle(String prompt) {
        if (prompt == null || prompt.isBlank()) return false;
        String low = prompt.toLowerCase(Locale.ROOT);
        if (ISSUE_KEY.matcher(prompt).find()) return true;
        for (String hint : MCP_HINTS) if (low.contains(hint)) return true;
        return false;
    }

    public Optional<String> answer(String apiKey, ChatRequest request, List<Map<String,Object>> baseContext,
                                   BooleanSupplier cancelled, Consumer<McpActivity> activity) throws Exception {
        String prompt = latestUserText(baseContext);
        if (!shouldHandle(prompt)) return Optional.empty();
        if (mcp.configuredServerNames(null).isEmpty()) return Optional.empty();

        McpManager.Catalog fullCatalog = mcp.catalog(null);
        List<Map<String,Object>> tools = new ArrayList<>();
        Set<String> allowed = new LinkedHashSet<>();
        for (Map<String,Object> def : fullCatalog.definitions()) {
            String name = functionName(def);
            if (name.isBlank() || !mcp.isChatReadOnly(fullCatalog, name)) continue;
            tools.add(def);
            allowed.add(name);
        }

        // A configured MCP endpoint that cannot expose any safe read tools should not silently make Chat hallucinate.
        if (tools.isEmpty()) {
            String detail = fullCatalog.diagnostics().isEmpty()
                    ? "No read-only MCP tools were discovered."
                    : String.join("; ", fullCatalog.diagnostics());
            return Optional.of("I couldn't retrieve the requested external data in Chat mode. " + detail +
                    " Chat intentionally exposes only read/search MCP operations; use Agent mode for external write actions.");
        }

        List<Map<String,Object>> messages = copyMessages(baseContext);
        insertMcpInstructions(messages, fullCatalog.diagnostics());
        String model = request.settings().chatModelOrPrimary();
        Map<String,Integer> repeated = new HashMap<>();
        int forcedEvidenceTurns = 0;

        while (true) {
            if (cancelled != null && cancelled.getAsBoolean()) throw new AgentCancelledException("Chat MCP request cancelled");
            OpenAiCompatibleClient.AgentCompletion turn = llm.completeAgent(
                    apiKey, request.settings().baseUrl(), model, request.settings().safeMaxTokens(),
                    messages, tools, false, cancelled == null ? () -> false : cancelled);

            String raw = turn.content() == null ? "" : turn.content().trim();
            if (turn.hasToolCall()) {
                appendNativeAssistant(messages, turn.toolCalls(), raw);
                for (OpenAiCompatibleClient.AgentToolCall call : turn.toolCalls()) {
                    String name = call.name() == null ? "" : call.name().trim();
                    String result = executeReadTool(fullCatalog, allowed, name, call.arguments(), cancelled, repeated, activity);
                    appendNativeToolResult(messages, call.id(), name, result);
                }
                continue;
            }

            JsonNode envelope = parseEnvelope(raw);
            if (envelope != null && envelope.isObject()) {
                String type = envelope.path("type").asText("").trim().toLowerCase(Locale.ROOT);
                if ("tool".equals(type)) {
                    String name = envelope.path("tool").asText("").trim();
                    String result = executeReadTool(fullCatalog, allowed, name, envelope.path("args"), cancelled, repeated, activity);
                    appendFallbackToolTranscript(messages, raw, name, result);
                    continue;
                }
                if ("tools".equals(type) && envelope.path("calls").isArray()) {
                    List<String> results = new ArrayList<>();
                    int count = 0;
                    for (JsonNode node : envelope.path("calls")) {
                        if (++count > 8) break;
                        String name = node.path("tool").asText("").trim();
                        String result = executeReadTool(fullCatalog, allowed, name, node.path("args"), cancelled, repeated, activity);
                        results.add("TOOL RESULT for " + name + ":\n" + clip(result, 24_000));
                    }
                    if (!raw.isBlank()) messages.add(Map.of("role", "assistant", "content", clip(raw, 12_000)));
                    messages.add(Map.of("role", "user", "content", String.join("\n\n", results) +
                            "\n\nContinue the user's request. Use another MCP read tool if needed, otherwise answer normally."));
                    continue;
                }
                if ("final".equals(type)) {
                    String message = envelope.path("message").asText("").trim();
                    if (!message.isBlank()) return Optional.of(message);
                }
            }

            if (!raw.isBlank()) {
                // If the user explicitly requested live external evidence but the model answered without touching MCP,
                // give it one bounded corrective opportunity before returning prose.
                if (forcedEvidenceTurns < 1 && clearlyRequiresRetrievedEvidence(prompt)) {
                    forcedEvidenceTurns++;
                    messages.add(Map.of("role", "assistant", "content", clip(raw, 12_000)));
                    messages.add(Map.of("role", "user", "content",
                            "Use an available MCP read/search tool now to ground the answer in the requested Jira/Confluence/DevOps source. Do not answer from memory. After retrieving evidence, answer the original request."));
                    continue;
                }
                return Optional.of(raw);
            }

            return Optional.of("The Chat model returned no usable response after MCP processing.");
        }
    }

    private String executeReadTool(McpManager.Catalog catalog, Set<String> allowed, String name, JsonNode args,
                                   BooleanSupplier cancelled, Map<String,Integer> repeated,
                                   Consumer<McpActivity> activity) {
        if (name == null || name.isBlank() || !allowed.contains(name)) {
            return "MCP TOOL NOT AVAILABLE IN CHAT: " + (name == null ? "" : name) +
                    ". Chat exposes read/search MCP operations only. Use Agent mode for mutating external actions.";
        }
        String fingerprint = name + "|" + canonicalArgs(args);
        int count = repeated.merge(fingerprint, 1, Integer::sum);
        if (count > 3) return "REPEATED MCP CALL SUPPRESSED: choose a different query/tool or answer from the evidence already retrieved.";
        try {
            if (activity != null) activity.accept(new McpActivity(name, "running", "Calling MCP read tool"));
            String result = mcp.call(null, catalog, name, args, cancelled == null ? () -> false : cancelled);
            if (activity != null) activity.accept(new McpActivity(name, result != null && result.contains("isError=true") ? "error" : "success", summarize(result)));
            return clip(result, 32_000);
        } catch (AgentCancelledException cancelledException) {
            throw cancelledException;
        } catch (Exception e) {
            String result = "MCP TOOL ERROR: " + safe(e.getMessage());
            if (activity != null) activity.accept(new McpActivity(name, "error", result));
            return result;
        }
    }

    private void insertMcpInstructions(List<Map<String,Object>> messages, List<String> diagnostics) {
        String diag = diagnostics == null || diagnostics.isEmpty() ? "" : "\nMCP status: " + String.join("; ", diagnostics);
        String protocol = """
                CHAT MCP MODE
                - The user is asking for external DevOps information. Use the available MCP read/search tools whenever Jira, Confluence, GitLab, SonarQube or another configured MCP source is needed.
                - Do not invent issue/page contents, comments, statuses, acceptance criteria or search results. Retrieve them first.
                - Chat mode is read/analysis only for MCP. Mutating external actions are intentionally not available here; tell the user to use Agent mode if a write/update action is requested.
                - Retrieve only the evidence required for the question. Do not dump whole projects/spaces into context.
                - After tool use, answer normally in concise Markdown.
                - Compatibility fallback when native tool calling is unavailable: return exactly one JSON object: {\"type\":\"tool\",\"tool\":\"exact_tool_name\",\"args\":{...}}. For multiple independent reads use {\"type\":\"tools\",\"calls\":[...]}. When done, return normal prose or {\"type\":\"final\",\"message\":\"...\"}.
                """ + diag;
        int insert = !messages.isEmpty() && "system".equals(String.valueOf(messages.get(0).get("role"))) ? 1 : 0;
        messages.add(insert, Map.of("role", "system", "content", protocol));
    }

    private List<Map<String,Object>> copyMessages(List<Map<String,Object>> source) {
        List<Map<String,Object>> out = new ArrayList<>();
        if (source != null) for (Map<String,Object> message : source) out.add(new LinkedHashMap<>(message));
        return out;
    }

    private String latestUserText(List<Map<String,Object>> messages) {
        if (messages == null) return "";
        for (int i = messages.size() - 1; i >= 0; i--) {
            Map<String,Object> message = messages.get(i);
            if (!"user".equals(String.valueOf(message.get("role")))) continue;
            Object content = message.get("content");
            if (content instanceof String text) return text;
            if (content instanceof List<?> parts) {
                StringBuilder out = new StringBuilder();
                for (Object part : parts) {
                    if (part instanceof Map<?,?> map && "text".equals(String.valueOf(map.get("type")))) {
                        Object value = map.get("text");
                        if (value != null) out.append(value).append('\n');
                    }
                }
                return out.toString();
            }
        }
        return "";
    }

    private boolean clearlyRequiresRetrievedEvidence(String prompt) {
        if (prompt == null) return false;
        String low = prompt.toLowerCase(Locale.ROOT);
        return ISSUE_KEY.matcher(prompt).find() || low.contains("jira") || low.contains("confluence") ||
                low.contains("gitlab") || low.contains("sonarqube") || low.contains("mcp") ||
                low.contains("acceptance criteria") || low.contains("ticket") || low.contains("issue");
    }

    private String functionName(Map<String,Object> definition) {
        if (definition == null) return "";
        Object fn = definition.get("function");
        if (!(fn instanceof Map<?,?> map)) return "";
        Object name = map.get("name");
        return name == null ? "" : String.valueOf(name).trim();
    }

    private void appendNativeAssistant(List<Map<String,Object>> messages,
                                       List<OpenAiCompatibleClient.AgentToolCall> calls, String content) {
        List<Map<String,Object>> toolCalls = new ArrayList<>();
        for (OpenAiCompatibleClient.AgentToolCall call : calls) {
            Map<String,Object> fn = new LinkedHashMap<>();
            fn.put("name", call.name());
            try { fn.put("arguments", mapper.writeValueAsString(call.arguments())); }
            catch (Exception ignored) { fn.put("arguments", "{}"); }
            Map<String,Object> item = new LinkedHashMap<>();
            item.put("id", call.id());
            item.put("type", "function");
            item.put("function", fn);
            toolCalls.add(item);
        }
        Map<String,Object> assistant = new LinkedHashMap<>();
        assistant.put("role", "assistant");
        if (content != null && !content.isBlank()) assistant.put("content", clip(content, 12_000));
        assistant.put("tool_calls", toolCalls);
        messages.add(assistant);
    }

    private void appendNativeToolResult(List<Map<String,Object>> messages, String id, String name, String result) {
        Map<String,Object> tool = new LinkedHashMap<>();
        tool.put("role", "tool");
        tool.put("tool_call_id", id == null ? "" : id);
        tool.put("name", name == null ? "" : name);
        tool.put("content", clip(result, 32_000));
        messages.add(tool);
    }

    private void appendFallbackToolTranscript(List<Map<String,Object>> messages, String raw, String tool, String result) {
        if (raw != null && !raw.isBlank()) messages.add(Map.of("role", "assistant", "content", clip(raw, 12_000)));
        messages.add(Map.of("role", "user", "content", "TOOL RESULT for " + tool + ":\n" + clip(result, 32_000) +
                "\n\nContinue the original request. Use another MCP read tool if needed; otherwise answer normally."));
    }

    private JsonNode parseEnvelope(String raw) {
        if (raw == null || raw.isBlank()) return null;
        String text = raw.trim();
        if (text.startsWith("```")) {
            int first = text.indexOf('\n');
            int last = text.lastIndexOf("```");
            if (first >= 0 && last > first) text = text.substring(first + 1, last).trim();
        }
        try { return mapper.readTree(text); } catch (Exception ignored) { return null; }
    }

    private String canonicalArgs(JsonNode args) {
        try { return mapper.writeValueAsString(args == null || args.isNull() ? mapper.createObjectNode() : args); }
        catch (Exception e) { return "{}"; }
    }

    private String summarize(String result) {
        if (result == null || result.isBlank()) return "MCP returned no content";
        String one = result.replaceAll("\\s+", " ").trim();
        return one.length() <= 240 ? one : one.substring(0, 240) + "…";
    }

    private String clip(String value, int max) {
        if (value == null) return "";
        if (value.length() <= max) return value;
        int head = Math.max(1, max * 2 / 3);
        int tail = Math.max(1, max - head - 40);
        return value.substring(0, head) + "\n...[MCP output clipped]...\n" + value.substring(value.length() - tail);
    }

    private String safe(String value) { return value == null || value.isBlank() ? "unknown error" : value.replaceAll("[\\r\\n]+", " ").trim(); }

    public record McpActivity(String tool, String status, String detail) {}
}
