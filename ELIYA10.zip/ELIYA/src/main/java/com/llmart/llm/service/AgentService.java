package com.llmart.llm.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.llmart.llm.dto.ChatRequest;
import com.llmart.llm.dto.ChatSettings;
import com.llmart.llm.dto.ProjectPatchRequest;
import jakarta.annotation.PreDestroy;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.util.*;
import java.util.concurrent.*;
import java.util.function.Consumer;

/**
 * OpenCode-style model-step agent loop.
 *
 * Important runtime properties:
 * - the user-selected local directory is the live workspace (no mirror/staging/apply phase);
 * - native provider tool calls are the primary protocol;
 * - one model step may request multiple tools and all calls are executed before the next model turn;
 * - approved plans are sequential runtime gates: one active step at a time; implementation steps advance from real workspace evidence, while compilation/test/execution is deferred to a final verification phase after coherent changes are complete;
 * - there is no application-imposed model-step or tool-action ceiling; the run continues until verified completion,
 *   cancellation, permission denial/blocker, provider refusal, or a non-recoverable environment failure;
 * - JSON tool envelopes are only a compatibility fallback for providers without native function calling.
 */
@Service
public class AgentService {

    private static final int MAX_CONSECUTIVE_NON_ACTIONABLE_TURNS = 10;
    private static final int MAX_CONSECUTIVE_EMPTY_SUBAGENT_TURNS = 2;
    private static final int PROVIDER_RETRIES_PER_MODEL_ACTIVATION = 3;
    private static final int PROVIDER_MODEL_CYCLES = 3;
    /**
     * No-progress recovery is deliberately a soft cycle, not a hard execution budget. Long migrations can
     * legitimately hit the same-model recovery path many times across independent plan steps. The run must not
     * fail merely because a historical recovery counter reached an arbitrary ceiling.
     */
    private static final int RECOVERY_EVIDENCE_MAX_CHARS = 18_000;
    /** Keep the default tool surface compact. Specialized built-ins and MCP schemas are loaded on demand via tool_search. */
    private static final Set<String> CORE_AGENT_TOOLS = Set.of(
            "inspect_workspace","list","glob","grep","file_info","read","read_many",
            "resource_catalog","resource_read","resource_grep","tool_search",
            "edit","write","apply_patch","build","test","check","bash",
            "workspace_status","workspace_diff","workspace_checkpoint","workspace_rollback","todoread","todo_update",
            "work_items_discover","work_items_init","work_items_add","work_items_read","work_items_update","verification_failures");
    /** Tools that remain meaningful when Agent mode is intentionally running without a local project workspace. */
    private static final Set<String> EXTERNAL_AGENT_BUILTINS = Set.of(
            "attachment_list", "attachment_read", "attachment_search", "mcp_status");

    private static final String EXTERNAL_AGENT_PROTOCOL = """
            You are ELIYA running in AGENT mode without a local project workspace. This is a valid operating mode.

            OPERATING PRINCIPLES
            - Complete the user's information/analysis task using configured MCP sources (for example Jira, Confluence, GitLab or SonarQube), uploaded requirement documents, and conversation evidence.
            - There is NO local workspace for this run. Never invent one and never request workspace/file/shell/edit tools. If the user explicitly needs code changes, tell them to select or mention the project path; otherwise continue the Jira/Confluence/document analysis normally.
            - For Jira/Confluence/DevOps facts, retrieve the needed evidence through MCP before making factual claims. Do not invent issue contents, acceptance criteria, page text, statuses, comments, links or search results.
            - Use attachment_list / attachment_read / attachment_search when the current-message excerpt is not enough for an uploaded requirement document.
            - Retrieve only the evidence needed for the request. Avoid dumping entire spaces/projects into model context.
            - MCP permissions are enforced by the runtime. Read and write MCP operations use the same configured permission/approval policy as workspace Agent mode.
            - Return a concise, evidence-grounded final Markdown answer/report. Clearly state when an external source is unavailable.

            COMPATIBILITY FALLBACK
            If native function calling is unavailable, return exactly one JSON object per turn:
              {"type":"tool","tool":"exact_tool_name","reason":"short reason","args":{...}}
            Or batch independent calls:
              {"type":"tools","calls":[{"tool":"exact_tool_name","reason":"short reason","args":{...}}]}
            When the task is complete:
              {"type":"final","status":"completed|blocked","message":"concise Markdown answer"}
            """;
    private final ExecutorService parallelReadExecutor = Executors.newFixedThreadPool(
            Math.max(4, Math.min(16, Runtime.getRuntime().availableProcessors() * 2)), r -> {
        Thread t = new Thread(r, "agent-parallel-read"); t.setDaemon(true); return t;
    });

    private static final String AGENT_PROTOCOL = """
            You are a capable general-purpose LOCAL WORKSPACE AGENT. Your job is to complete the user's task in the live local workspace, not merely describe how it could be done.

            OPERATING PRINCIPLES
            - The runtime creates a concise execution plan before work begins. After approval, that plan is a contract: exactly one step is active at a time and every retained step must reach completed before the run may finish successfully. Never skip an approved step. Use todo_update to complete implementation steps after real workspace/tool evidence (for example reads, edits and diff review). Do NOT compile/test after every edit or implementation step. Batch coherent requested changes first, then use the plan's final verification step to compile/test/check/run the current workspace once, based on the user request and project type. The runtime then unlocks the next step automatically.
            - The active workspace is the real user-selected filesystem directory. Work directly there after configured permission checks. Explicit additional prompt paths are exposed as resource aliases. Never invent paths.
            - Treat @-prefixed framework/CLI syntax carefully. Tokens such as @rerun.txt, @failed.txt, @args.txt or Cucumber tags are NOT resource aliases unless resource_catalog explicitly lists that exact alias. For a file in the active workspace, use ordinary workspace tools with the real relative path (for example rerun.txt, without the @ syntax marker).
            - Inspect only the evidence you need, prefer targeted/parallel reads, then edit/run/verify. Use subagents, MCP and LSP when they materially help.
            - Use the available tool names exactly. Built-in text search is grep; tool_search loads deferred specialized built-ins and MCP tools when the compact default palette does not expose a capability you need. If a tool call fails, read the error and change strategy instead of repeating the same call unchanged.
            - For edit failures, re-read the current target and retry with exact current text. For patch-schema/context failures, use structured apply_patch, edit, or write with current evidence.
            - Batch independent reads in one turn. Avoid re-reading unchanged files or repeating identical command/test output.
            - Keep changes focused and preserve project conventions. You have freedom to choose the best implementation path; do not ask the user for routine coding decisions once the plan is approved.
            - File deletion protection is separate from plan approval. When deletion approval is enabled, use dedicated delete/resource_delete/apply_patch/move tools for any removal, show the real paths to the user and wait for the dedicated human confirmation. Never circumvent a denied deletion through bash, MCP, subagents, patches or another tool.
            - For normal code/config changes, defer build/test/check/run until all coherent requested changes are implemented. In the final verification phase, run the smallest high-signal compile/test/check/command appropriate to the project and the user's request. If that final verifier fails, diagnose the actual output, fix the cause, and rerun the relevant final verifier.
            - For genuinely large tasks, use the durable work-item ledger. Inventory the scope, initialize concise work items, process them in small batches, and use cheap structural checks at batch boundaries when useful. Create a lightweight workspace_checkpoint before a risky batch so a bad batch can be rolled back without discarding earlier good work. Do not run a full browser/regression suite after every batch. Failed items must be marked failed and revisited from the failed queue; successful final completion requires no unresolved work items and a passing final verifier.
            - Never invent file contents, command results, test results, or completion. Final response: concise summary of changes plus real verification or blocker.

            WORKSPACE / RESOURCE MODEL
            - Primary workspace tools: inspect_workspace, workspace_profile, list, glob, grep, file_info, file_index, read, read_chunk, read_many, edit, write, copy, move, delete, apply_patch, build, test, check, bash, process_*, http_request, workspace_status, workspace_diff, todowrite, todoread, todo_update, work_items_* and verification_failures.
            - Explicit additional paths: use resource_catalog and resource_* tools. Reference/input/diagnostic resources are read-only; secondary workspace resources may be writable.
            - Project instructions (AGENTS.md/CLAUDE.md/etc.), skills, MCP and LSP are discovered by the runtime. Respect relevant project instructions while prioritizing the user's requested outcome.
            - The runtime manages context automatically. Compaction is a continuation checkpoint, not a signal to stop.

            COMPATIBILITY FALLBACK
            If native tools are unavailable and JSON compatibility mode is used, return exactly one JSON object per turn.
            Prefer a batched tool object when several actions can be selected from the current evidence (up to 8 calls):
              {"type":"tools","calls":[{"tool":"tool_name","reason":"short reason","args":{...}}, ...]}
            For one action this legacy shape is also accepted:
              {"type":"tool","tool":"tool_name","reason":"short reason","args":{...}}
            After real work is complete:
              {"type":"final","status":"completed|blocked","message":"concise Markdown summary"}
            Do not put later-plan-step actions in the same batch. Batch independent reads/searches whenever possible to reduce model round-trips.
            """;

    private final OpenAiCompatibleClient llm;
    private final AgentWorkspaceService workspaces;
    private final AgentApprovalService approvals;
    private final AgentRunService runs;
    private final AgentToolRegistry toolRegistry;
    private final FileService files;
    private final McpManager mcp;
    private final WorkspaceProfileService workspaceProfiles;
    private final WorkspaceRetrievalIndexService workspaceRetrieval;
    private final AgentProfileService agentProfiles;
    private final LspManager lsp;
    private final ContextWindowManager contextWindows;
    private final ObjectMapper objectMapper;
    /** Reuse active-step retrieval/live-file evidence until either the plan step or workspace revision changes. */
    private final ConcurrentMap<String, String> activeContextCache = new ConcurrentHashMap<>();

    public AgentService(OpenAiCompatibleClient llm, AgentWorkspaceService workspaces,
                        AgentApprovalService approvals, AgentRunService runs,
                        AgentToolRegistry toolRegistry, FileService files, McpManager mcp,
                        WorkspaceProfileService workspaceProfiles, WorkspaceRetrievalIndexService workspaceRetrieval,
                        AgentProfileService agentProfiles, LspManager lsp,
                        ContextWindowManager contextWindows, ObjectMapper objectMapper) {
        this.llm = llm;
        this.workspaces = workspaces;
        this.approvals = approvals;
        this.runs = runs;
        this.toolRegistry = toolRegistry;
        this.files = files;
        this.mcp = mcp;
        this.workspaceProfiles = workspaceProfiles;
        this.workspaceRetrieval = workspaceRetrieval;
        this.agentProfiles = agentProfiles;
        this.lsp = lsp;
        this.contextWindows = contextWindows;
        this.objectMapper = objectMapper;
    }

    public AgentResult run(String runId, String apiKey, ChatRequest request, List<Map<String, Object>> baseContext,
                           Consumer<Map<String, Object>> onStep) throws Exception {
        AgentRunService.AgentRun run = runs.require(runId);
        Consumer<Map<String,Object>> downstreamSteps = onStep;
        onStep = event -> {
            run.recordActivityEvent(event);
            downstreamSteps.accept(event);
        };
        String selectedAgentModel = request.settings().model() == null ? "" : request.settings().model().trim();
        if (selectedAgentModel.isBlank()) throw new IllegalArgumentException("Agent model is required");
        String selectedAgentType = request.settings().configuredModelType(selectedAgentModel);
        if (Set.of("embedding", "ocr", "vision").contains(selectedAgentType)) {
            throw new IllegalArgumentException("Agent model '" + selectedAgentModel + "' is configured as " + selectedAgentType + ". Choose a Chat / Agent model that can perform planning, tool use, coding and verification.");
        }
        run.configureModelPool(request.settings().agentModels());
        if (request.projectId() == null || request.projectId().isBlank()) {
            return runWithoutWorkspace(run, apiKey, request, baseContext, onStep);
        }
        AgentWorkspaceService.Workspace ws = null;
        String completionStatus = "running";
        try {
            run.updateProgress(4, "starting", "Resolving workspace and task context");
            ws = workspaces.prepare(request.projectId(), request.message());
            run.updateProgress(8, "planning", "Discovering workspace capabilities");
            McpManager.Catalog mcpCatalog = mcp.catalog(ws.root());
            // Keep MCP schemas out of every model turn. They are discovered lazily through tool_search.
            List<Map<String,Object>> availableTools = new CopyOnWriteArrayList<>(toolRegistry.filterDefinitions(toolRegistry.builtInDefinitions(), CORE_AGENT_TOOLS, false));
            List<Map<String, Object>> messages = prepareMessages(baseContext, ws);
            run.setObjective(latestUserTask(messages));
            WorkspaceRetrievalIndexService.IndexStats indexStats = workspaceRetrieval.warm(ws);
            String embeddingModel = request.settings().embeddingModelName();
            String indexDetail = "Local retrieval index ready: " + indexStats.indexedFiles() + " relevant text/source files" +
                    (embeddingModel.isBlank() ? " · semantic reranking disabled/lexical fallback active" : " · semantic reranker: " + embeddingModel);
            onStep.accept(stepEvent(0, "workspace_index", indexDetail, "success", null, null, null));
            String projectInstructions = workspaces.projectInstructions(ws);
            if (!projectInstructions.isBlank()) messages.add(1, Map.of("role", "system", "content", projectInstructions));
            StringBuilder runtimeCatalog = new StringBuilder(workspaceProfiles.profileText(ws));
            String resourceCatalog = workspaces.resourceCatalog(ws);
            if (!resourceCatalog.isBlank() && !"[No prompt resources resolved]".equals(resourceCatalog)) {
                runtimeCatalog.append("\n\nPROMPT RESOURCES\n").append(resourceCatalog);
            }
            String mcpStatus = mcpCatalog.diagnostics().isEmpty() ? "" : String.join("\n", mcpCatalog.diagnostics());
            if (!mcpStatus.isBlank()) {
                runtimeCatalog.append("\n\nMCP STATUS\n").append(mcpStatus);
            }
            String lspStatus = lsp.status(ws.root());
            if (!lspStatus.isBlank()) {
                runtimeCatalog.append("\n\nLSP STATUS\n").append(lspStatus);
            }
            messages.add(Math.min(2, messages.size()), Map.of("role", "system", "content", runtimeCatalog.toString()));
            onStep.accept(stepEvent(0, "workspace_resolution", "Using live workspace: " + ws.root(), "success", null, workspaces.resourceCatalog(ws), null));

            run.updateProgress(9, "analysing", "Analysing the live workspace before planning");
            List<String> executionPlan;
            try {
                executionPlan = createExecutionPlan(apiKey, request, messages, ws, run, onStep);
            } catch (ProviderModelException providerFailure) {
                String stopped = "Execution stopped because provider/model recovery was exhausted during planning. " +
                        "Last model: " + providerFailure.model() + ". Error: " + providerFailure.providerDetail();
                run.markFinalAnswer(stopped);
                run.finish("failed");
                onStep.accept(stepEvent(0, "model_error",
                        "Provider/model recovery exhausted during planning",
                        "error", null, clipUi(providerFailure.providerDetail()), null));
                return new AgentResult(stopped, List.of());
            }
            run.setPlan(executionPlan);
            onStep.accept(stepEvent(0, "plan", "Execution plan ready", "success", null, run.planText(), null));

            String finalMessage = null;
            if (request.settings().planApprovalRequired()) {
                run.updateProgress(13, "plan_review", "Validated plan is ready for your approval");
                AgentApprovalService.Approval planApproval = approvals.create(run.id(), "plan_approval", "Review execution plan before autonomous work starts");
                onStep.accept(stepEvent(0, "plan_approval", "Review the plan and approve execution", "approval", null, run.planText(), planApproval.id()));
                AgentApprovalService.Decision decision = approvals.await(planApproval.id(), Duration.ZERO, run);
                if (decision == AgentApprovalService.Decision.DENY) {
                    finalMessage = "Plan was not approved, so the agent did not change files or run project commands.";
                    run.markFinalAnswer(finalMessage);
                    run.finish("cancelled");
                    return new AgentResult(finalMessage, List.of());
                }
                onStep.accept(stepEvent(0, "plan_approval", "Plan approved; autonomous execution started", "success", null, null, null));
            }
            run.markPlanStarted();
            messages.add(Map.of("role", "system", "content", "APPROVED SEQUENTIAL EXECUTION PLAN:\n" + run.planText() +
                    "\n\nSEQUENTIAL GATE: Only the current in_progress step is unlocked. Do not begin later steps and never skip an approved step. Complete implementation steps from real workspace evidence and call todo_update on the active index. " +
                    (run.largeTaskMode()
                            ? "LARGE-TASK MODE: inventory independent work with work_items_discover or work_items_init/work_items_add, process only a bounded batch at a time, update ledger statuses as items complete/fail, create workspace_checkpoint before risky batches, use cheap structural checks at batch boundaries when useful, and use verification_failures plus failed work-item reads for targeted recovery. Roll back only the bad batch when necessary. Do not run full browser/regression verification after every batch. "
                            : "Do not compile/test after each edit; batch coherent changes first. ") +
                    "The final verification step must run the appropriate compile/test/check/run on the fully changed workspace before successful completion. The runtime unlocks exactly one next plan step, and large-task completion additionally requires no unresolved work items or verifier failures."));
            messages.add(Map.of("role", "system", "content", activeStepContract(run)));
            run.updateProgress(15, "executing", "Approved plan started; executing step 1");

            long toolActivity = 0;
            Map<String,Integer> repeatedCalls = new HashMap<>();
            Map<String,Integer> repeatedNoProgress = new HashMap<>();
            Map<String,Integer> verificationSteering = new HashMap<>();
            long recoveryTurns = 0;
            final int recoveryLimit = request.settings().safeAgentRecoveryAttempts();
            boolean transportReported = false;
            boolean requireToolNextTurn = false;
            int step = 0;
            int lastPlanIndex = run.activePlanIndex();
            int explorationTurnsWithoutMutation = 0;

            while (true) {
                step++;
                run.checkCancelled();
                int currentPlanIndex = run.activePlanIndex();
                if (currentPlanIndex != lastPlanIndex) {
                    // A newly unlocked plan step is a fresh recovery scope. Do not let duplicate-call or
                    // recovery fingerprints from a previous step poison a long (>hundreds of turns) run.
                    // Also checkpoint an oversized completed-step transcript before the next executor turn. The
                    // durable plan/workspace state is re-injected separately, so carrying every read/build log from
                    // prior steps only increases latency and provider token spend.
                    repeatedCalls.clear();
                    repeatedNoProgress.clear();
                    verificationSteering.clear();
                    recoveryTurns = 0;
                    explorationTurnsWithoutMutation = 0;
                    checkpointAtPlanBoundary(apiKey, request, messages, availableTools, run, step, onStep);
                    lastPlanIndex = currentPlanIndex;
                    if (currentPlanIndex > 0) messages.add(Map.of("role", "system", "content", activeStepContract(run)));
                }
                run.updateActivity("executing", currentPlanIndex > 0
                        ? "Executing planned step " + currentPlanIndex + " · model turn " + step
                        : "Completing task · model turn " + step);
                OpenAiCompatibleClient.AgentCompletion turn;
                try {
                    turn = completeAgentTurn(apiKey, request, messages, ws, run, requireToolNextTurn, availableTools, step, onStep);
                } catch (ProviderModelException providerFailure) {
                    completionStatus = "failed";
                    finalMessage = "Execution stopped because provider/model recovery was exhausted. " +
                            "Last model: " + providerFailure.model() + ". Error: " + providerFailure.providerDetail();
                    onStep.accept(stepEvent(step, "model_error",
                            "Provider/model recovery exhausted; execution stopped with run state preserved",
                            "error", null, clipUi(providerFailure.providerDetail()), null));
                    break;
                } catch (ExecutorPoolExhaustedException exhausted) {
                    RecoveryReplanDecision recovery = attemptExecutorRecoveryReplan(apiKey, request, messages, ws, run, onStep, step,
                            exhausted.getMessage(), exhausted.providerDetail());
                    if (recovery.recovered()) {
                        recoveryTurns = 0;
                        repeatedNoProgress.clear();
                        repeatedCalls.clear();
                        verificationSteering.clear();
                        lastPlanIndex = run.activePlanIndex();
                        requireToolNextTurn = false;
                        transportReported = false;
                        continue;
                    }
                    completionStatus = "failed";
                    finalMessage = recoveryExhaustedMessage(recoveryTurns, recoveryLimit, run, recovery.reason());
                    onStep.accept(stepEvent(step, "loop_guard", "Executor recovery was exhausted", "error", null,
                            clipUi(recovery.reason()), null));
                    break;
                }
                requireToolNextTurn = false;
                run.checkCancelled();

                if (!transportReported) {
                    transportReported = true;
                    String transport = turn.nativeToolsUsed()
                            ? "Native model tool calling active"
                            : turn.jsonModeUsed()
                            ? "Native tools unavailable; JSON compatibility mode active"
                            : "Provider exposes neither native tools nor JSON response mode; best-effort compatibility mode active";
                    onStep.accept(stepEvent(step, "agent_transport", transport, "success", null, null, null));
                }

                String raw = turn.content() == null ? "" : turn.content().trim();

                // Output truncation is not an executor-quality failure. Preserve the partial reasoning once and ask the
                // same model to continue with an actionable tool call. Escalate only if the provider repeatedly truncates
                // without producing a tool action (usually a too-small max-output setting/provider cap).
                if (!turn.hasToolCall() && isOutputTruncated(turn.finishReason())) {
                    String fp = "output-truncated|" + run.mutationRevision() + "|" + normalizeNoProgress(raw);
                    int repeats = repeatedNoProgress.merge(fp, 1, Integer::sum);
                    if (!raw.isBlank() && repeats == 1) messages.add(Map.of("role", "assistant", "content", clipHistoricalAssistant(raw)));
                    if (repeats >= 3) {
                        String why = "Provider ended " + repeats + " executor responses at the output-token limit without an actionable tool call";
                        if (switchToNextModel(run, onStep, step, why)) {
                            repeatedNoProgress.clear();
                            messages.add(Map.of("role", "system", "content", modelFailoverContinuation(run)));
                            continue;
                        }
                        throw new ExecutorPoolExhaustedException("All executor models repeatedly hit the output-token limit", why, null);
                    }
                    messages.add(Map.of("role", "user", "content", "[RUNTIME_STEERING:output-truncated] Your previous response reached the provider output limit before an action completed. Continue from the existing state; do not restart analysis. Emit the next concrete tool call (or a compact compatibility JSON tool batch) now."));
                    requireToolNextTurn = turn.nativeToolsUsed();
                    onStep.accept(stepEvent(step, "output_limit", "Model output reached its token limit; continuing the same active step", "running", null, null, null));
                    continue;
                }

                // Native tools: one assistant model step can contain multiple tool calls. Execute all of them
                // before asking the model to reason again, matching modern agent runtimes and dramatically
                // reducing the old 40/80-step one-tool-at-a-time behavior.
                if (turn.hasToolCall()) {
                    List<OpenAiCompatibleClient.AgentToolCall> calls = turn.toolCalls();
                    appendNativeAssistantTurn(messages, calls, raw);

                    long successfulVerificationBefore = run.lastSuccessfulVerificationRevision();
                    long mutationBeforeTurn = run.mutationRevision();
                    long activityThisTurn = executeNativeCalls(calls, messages, ws, run, request, apiKey, mcpCatalog,
                            availableTools, step, onStep, repeatedCalls);
                    toolActivity += activityThisTurn;
                    boolean mutationProgress = run.mutationRevision() > mutationBeforeTurn;
                    boolean verificationProgress = run.lastSuccessfulVerificationRevision() > successfulVerificationBefore;
                    boolean explorationHeavyStep = run.hasOpenPlanItems() && !looksReadOnlyPlanStep(run.activePlanStepText()) && !looksVerificationPlanStep(run.activePlanStepText());
                    if (mutationProgress || verificationProgress) explorationTurnsWithoutMutation = 0;
                    else if (activityThisTurn > 0 && explorationHeavyStep) explorationTurnsWithoutMutation++;

                    // Reading is useful, but endless "one more file" loops are not progress. After several successful read/search
                    // turns on an implementation step, steer the executor to either make the grounded change or explicitly identify
                    // the missing fact. If it continues exploring without mutation, treat that as a no-progress strategy and fail over.
                    if (activityThisTurn > 0 && explorationHeavyStep && explorationTurnsWithoutMutation == 6) {
                        messages.add(Map.of("role", "system", "content", "[RUNTIME_STEERING:exploration-budget] You have completed multiple read/search turns for the active implementation step without changing the workspace. Use the evidence already collected. On the next turn either make the smallest grounded implementation change, run the relevant verifier if no change is actually required, or identify one precise missing fact and inspect only that fact. Do not continue broad exploration."));
                        onStep.accept(stepEvent(step, "execution_focus", "Sufficient exploration collected; steering executor toward implementation", "running", null, run.activePlanStepText(), null));
                    }
                    if (activityThisTurn > 0 && explorationHeavyStep && explorationTurnsWithoutMutation >= 10) {
                        String why = "Implementation step spent " + explorationTurnsWithoutMutation + " consecutive tool turns exploring without a workspace change or verifier progress";
                        run.recordExecutionFailure(why);
                        if (switchToNextModel(run, onStep, step, why)) {
                            explorationTurnsWithoutMutation = 0;
                            recoveryTurns = 0;
                            repeatedNoProgress.clear();
                            repeatedCalls.clear();
                            verificationSteering.clear();
                            messages.add(Map.of("role", "system", "content", modelFailoverContinuation(run)));
                            requireToolNextTurn = false;
                            continue;
                        }
                        RecoveryReplanDecision recovery = attemptExecutorRecoveryReplan(apiKey, request, messages, ws, run, onStep, step,
                                "All executors exhausted after repeated exploration without implementation progress", why);
                        if (recovery.recovered()) {
                            explorationTurnsWithoutMutation = 0;
                            recoveryTurns = 0;
                            repeatedNoProgress.clear();
                            repeatedCalls.clear();
                            verificationSteering.clear();
                            lastPlanIndex = run.activePlanIndex();
                            requireToolNextTurn = false;
                            transportReported = false;
                            continue;
                        }
                        completionStatus = "failed";
                        finalMessage = recoveryExhaustedMessage(recoveryTurns, recoveryLimit, run, recovery.reason());
                        onStep.accept(stepEvent(step, "loop_guard", "Stopped repeated exploration without implementation progress", "error", null, clipUi(recovery.reason()), null));
                        break;
                    }

                    if (activityThisTurn > 0) {
                        recoveryTurns = 0;
                    } else {
                        recoveryTurns++;
                        String stalledFingerprint = "native-no-progress|" + run.mutationRevision() + "|" + normalizeNoProgress(raw);
                        int identicalStalls = repeatedNoProgress.merge(stalledFingerprint, 1, Integer::sum);
                        boolean fastEscalate = identicalStalls >= 3;
                        if (fastEscalate || recoveryTurns >= recoveryLimit) {
                            String why = fastEscalate
                                    ? "Same no-progress executor outcome repeated " + identicalStalls + " times"
                                    : "No actionable progress after " + recoveryTurns + " recovery attempts";
                            if (switchToNextModel(run, onStep, step, why)) {
                                recoveryTurns = 0;
                                repeatedNoProgress.clear();
                                repeatedCalls.clear();
                                verificationSteering.clear();
                                messages.add(Map.of("role", "system", "content", modelFailoverContinuation(run)));
                                requireToolNextTurn = false;
                                continue;
                            }
                            run.markRepeatedCallPrevented();
                            RecoveryReplanDecision recovery = attemptExecutorRecoveryReplan(apiKey, request, messages, ws, run, onStep, step,
                                    "No actionable progress after all executor models exhausted their recovery attempts", raw);
                            if (recovery.recovered()) {
                                recoveryTurns = 0;
                                repeatedNoProgress.clear();
                                repeatedCalls.clear();
                                verificationSteering.clear();
                                lastPlanIndex = run.activePlanIndex();
                                requireToolNextTurn = false;
                                transportReported = false;
                                continue;
                            }
                            completionStatus = "failed";
                            finalMessage = recoveryExhaustedMessage(recoveryTurns, recoveryLimit, run, recovery.reason());
                            onStep.accept(stepEvent(step, "loop_guard",
                                    "Focused recovery could not be initialized",
                                    "error", null, clipUi(recovery.reason()), null));
                            break;
                        }
                        messages.add(Map.of("role", "user", "content", recoveryDirective((int) recoveryTurns, recoveryLimit, true, raw)));
                        requireToolNextTurn = turn.nativeToolsUsed();
                        onStep.accept(stepEvent(step, "agent_recovery",
                                "Tool call produced no actionable progress; switching strategy (recovery " + recoveryTurns + "/" + recoveryLimit + " on " + effectiveModel(run, request.settings()) + ")",
                                "running", null, clipUi(raw), null));
                    }
                    if (run.mutationRevision() > 0 && run.verifiedCurrentRevision() &&
                            run.lastSuccessfulVerificationRevision() > successfulVerificationBefore) {
                        if (run.hasOpenPlanItems()) {
                            boolean stepAdvanced = false;
                            int activeIndex = run.activePlanIndex();
                            if (activeIndex > 0 && activeIndex == run.planSize()) {
                                // The final approved step is explicitly the verification boundary. A successful real
                                // verifier on the current revision is sufficient deterministic evidence to close it.
                                try {
                                    run.updatePlan(activeIndex, "completed", "Runtime verifier passed on the latest workspace revision: " + run.lastVerification());
                                    stepAdvanced = true;
                                    onStep.accept(stepEvent(step, "plan_step_complete",
                                            "Final verification step completed from the real verifier result",
                                            "success", null, clipUi(run.lastVerification()), null));
                                } catch (Exception gateFailure) {
                                    onStep.accept(stepEvent(step, "plan_gate",
                                            "Final verifier passed, but the sequential gate kept the step active",
                                            "running", null, clipUi(safe(gateFailure.getMessage())), null));
                                }
                            } else {
                                StepCompletionDecision stepDecision = activeStepCompletionGate(apiKey, request, ws, run, step, onStep);
                                if (stepDecision.satisfied() && activeIndex > 0) {
                                    try {
                                        run.updatePlan(activeIndex, "completed", "Runtime completion critic: " + stepDecision.reason());
                                        stepAdvanced = true;
                                        onStep.accept(stepEvent(step, "plan_step_complete",
                                                "Verification and evidence satisfy plan step " + activeIndex + "; advanced automatically",
                                                "success", null, clipUi(stepDecision.reason()), null));
                                    } catch (Exception gateFailure) {
                                        onStep.accept(stepEvent(step, "plan_gate",
                                                "Step completion critic passed, but the sequential gate kept the step active",
                                                "running", null, clipUi(safe(gateFailure.getMessage())), null));
                                    }
                                }
                            }

                            if (run.hasOpenPlanItems()) {
                                run.updateProgress(86, "plan_gate", "Verification passed; continuing the next required plan work");
                                messages.add(Map.of("role", "user", "content", stepAdvanced
                                        ? "[RUNTIME_STEERING:step-advanced] The previous active step was automatically completed from verified evidence. Continue only the newly unlocked step " + run.activePlanIndex() + ": " + run.activePlanStepText()
                                        : planContinuationPrompt(run, true)));
                                onStep.accept(stepEvent(step, "plan_gate",
                                        stepAdvanced
                                                ? "Sequential plan advanced to step " + run.activePlanIndex()
                                                : "Verification passed, but the active step still needs implementation evidence",
                                        "running", null, run.planText(), null));
                            } else {
                                // Every approved step is complete and the latest mutation revision has just passed a
                                // real verifier. Those are deterministic runtime facts, so the runtime finishes here instead
                                // of spending another full model round-trip asking a critic to restate them.
                                run.updateProgress(96, "completion_check", "All approved steps complete and latest workspace revision verified");
                                completionStatus = "completed";
                                finalMessage = "All approved plan steps completed successfully and the latest workspace revision passed verification.";
                                onStep.accept(stepEvent(step, "finish", "Verified task completed without an extra completion-model call", "done", null, null, null));
                                break;
                            }
                        } else {
                            run.updateProgress(96, "completion_check", "Approved work complete and latest workspace revision verified");
                            completionStatus = "completed";
                            finalMessage = "The requested workspace changes completed successfully and the latest workspace revision passed verification.";
                            onStep.accept(stepEvent(step, "finish", "Verified task completed without an extra completion-model call", "done", null, null, null));
                            break;
                        }
                    }
                    continue;
                }

                JsonNode envelope = parseEnvelope(raw);
                if (envelope != null && envelope.isObject()) {
                    String type = envelope.path("type").asText("").trim().toLowerCase(Locale.ROOT);
                    if ("final".equals(type) && toolActivity > 0) {
                        String requestedStatus = normalizeFinalStatus(envelope.path("status").asText("completed"));
                        String requestedMessage = envelope.path("message").asText("").trim();
                        if ("completed".equals(requestedStatus) && run.hasOpenPlanItems()) {
                            if (!raw.isBlank()) messages.add(Map.of("role", "assistant", "content", raw));
                            messages.add(Map.of("role", "user", "content", planContinuationPrompt(run, false)));
                            onStep.accept(stepEvent(step, "plan_gate", "Final response deferred; approved plan step " + run.activePlanIndex() + " is still active", "running", null, run.planText(), null));
                            requireToolNextTurn = turn.nativeToolsUsed();
                            continue;
                        }
                        if ("completed".equals(requestedStatus) && requiresCurrentRevisionVerification(run)) {
                            if (verificationSteeringBlocked(verificationSteering, run)) {
                                completionStatus = "failed";
                                finalMessage = "Execution stopped: the model repeatedly attempted to finish the same unverified workspace revision without producing a new verifier result or fix. The runtime stopped the no-progress verification loop to protect the token budget.";
                                onStep.accept(stepEvent(step, "loop_guard", "Stopped repeated finish-without-verification loop", "error", null, clipUi(raw), null));
                                break;
                            }
                            String finishFingerprint = "unverified-final|" + run.mutationRevision() + "|" + normalizeNoProgress(raw);
                            int finishRepeat = repeatedNoProgress.merge(finishFingerprint, 1, Integer::sum);
                            if (!raw.isBlank() && finishRepeat == 1) messages.add(Map.of("role", "assistant", "content", raw));
                            else if (finishRepeat > 1) run.markRepeatedCallPrevented();
                            messages.add(Map.of("role", "user", "content", verificationRequiredPrompt(run)));
                            onStep.accept(stepEvent(step, "verification_required",
                                    "Workspace changed after the last successful verifier; continuing until the current revision is verified",
                                    "running", null, null, null));
                            requireToolNextTurn = turn.nativeToolsUsed();
                            continue;
                        }
                        completionStatus = requestedStatus;
                        finalMessage = requestedMessage.isBlank() ? "Agent run completed." : requestedMessage;
                        onStep.accept(stepEvent(step, "finish", "Agent prepared the final response", "done", null, null, null));
                        break;
                    }
                    if ("tools".equals(type) && envelope.path("calls").isArray()) {
                        JsonNode callsNode = envelope.path("calls");
                        List<String> resultBlocks = new ArrayList<>();
                        long mutationBeforeBatch = run.mutationRevision();
                        long verifierBeforeBatch = run.lastSuccessfulVerificationRevision();
                        int executedCount = 0;
                        int activePlanAtBatchStart = run.activePlanIndex();
                        int callNumber = 0;
                        for (JsonNode callNode : callsNode) {
                            if (++callNumber > 8) break;
                            String requestedTool = callNode.path("tool").asText("").trim();
                            String tool = toolRegistry.canonical(requestedTool);
                            JsonNode args = normalizeLegacyArgs(requestedTool, tool, callNode.path("args"));
                            String detail = callNode.path("reason").asText("").trim();
                            if (detail.isBlank()) detail = describeTool(tool, args);
                            onStep.accept(stepEvent(step, tool, detail, "running", args, null, null));
                            String result;
                            String status;
                            boolean executed = false;
                            if (!isKnownTool(requestedTool, tool, mcpCatalog)) {
                                result = unknownToolMessage(requestedTool, mcpCatalog);
                                status = "error";
                            } else {
                                PreparedCall compatibilityCall = new PreparedCall(
                                        new OpenAiCompatibleClient.AgentToolCall("compat_" + step + "_" + callNumber, requestedTool, args),
                                        requestedTool, tool, args, detail);
                                ToolExecution execution = preflightCall(compatibilityCall, mcpCatalog);
                                if (execution == null) execution = executeWithPermission(ws, run, tool, args, request.settings(), detail, step, onStep,
                                        mcpCatalog, availableTools, apiKey, request);
                                execution = applyRepeatOutcomeGuard(compatibilityCall, execution, run, repeatedCalls, mcpCatalog);
                                result = execution.result();
                                status = execution.status();
                                if (execution.executed()) {
                                    observeRun(ws, run, tool, args, result);
                                    toolActivity++;
                                    executedCount++;
                                    executed = true;
                                }
                            }
                            onStep.accept(stepEvent(step, tool, summarizeResult(tool, result), status, args, clipUi(result), null));
                            resultBlocks.add("CALL " + callNumber + " " + tool + " [" + status + "]\n" + clip(result));
                            if (activePlanAtBatchStart > 0 && run.activePlanIndex() != activePlanAtBatchStart) {
                                resultBlocks.add("Remaining compatibility calls deferred because the sequential plan advanced to step " + run.activePlanIndex() + ".");
                                break;
                            }
                            if (!executed && result.startsWith("SUBAGENT LOOP BLOCKED:")) break;
                        }
                        if (!raw.isBlank()) messages.add(Map.of("role", "assistant", "content", clipHistoricalAssistant(raw)));
                        messages.add(Map.of("role", "user", "content", "BATCH TOOL RESULTS:\n" + String.join("\n\n", resultBlocks) +
                                "\n\nContinue the same active plan step. Batch additional independent tool calls when useful, otherwise advance/finish only when evidence supports it."));

                        if (executedCount > 0) {
                            recoveryTurns = 0;
                            boolean mutationProgress = run.mutationRevision() > mutationBeforeBatch;
                            boolean verifierProgress = run.lastSuccessfulVerificationRevision() > verifierBeforeBatch;
                            boolean explorationHeavyStep = run.hasOpenPlanItems() && !looksReadOnlyPlanStep(run.activePlanStepText()) && !looksVerificationPlanStep(run.activePlanStepText());
                            if (mutationProgress || verifierProgress) explorationTurnsWithoutMutation = 0;
                            else if (explorationHeavyStep) explorationTurnsWithoutMutation++;
                            if (run.verifiedCurrentRevision() && run.lastSuccessfulVerificationRevision() > verifierBeforeBatch && run.hasOpenPlanItems()) {
                                StepCompletionDecision stepDecision = activeStepCompletionGate(apiKey, request, ws, run, step, onStep);
                                if (stepDecision.satisfied() && run.activePlanIndex() > 0) {
                                    int completedIndex = run.activePlanIndex();
                                    try {
                                        run.updatePlan(completedIndex, "completed", "Runtime completion critic: " + stepDecision.reason());
                                        onStep.accept(stepEvent(step, "plan_step_complete", "Compatibility batch verifier satisfies plan step " + completedIndex + "; advanced automatically",
                                                "success", null, clipUi(stepDecision.reason()), null));
                                        if (run.hasOpenPlanItems()) messages.add(Map.of("role", "system", "content", activeStepContract(run)));
                                    } catch (Exception gateFailure) {
                                        onStep.accept(stepEvent(step, "plan_gate", "Step completion critic passed, but the sequential gate kept the step active",
                                                "running", null, clipUi(safe(gateFailure.getMessage())), null));
                                    }
                                }
                            }
                            if (explorationHeavyStep && explorationTurnsWithoutMutation == 6) {
                                messages.add(Map.of("role", "system", "content", "[RUNTIME_STEERING:exploration-budget] Enough read/search evidence has been collected for this implementation step. Make the smallest grounded change or inspect exactly one missing fact; do not continue broad exploration."));
                            }
                        } else {
                            recoveryTurns++;
                            String fingerprint = "compat-batch-no-progress|" + run.mutationRevision() + "|" + normalizeNoProgress(String.join(" ", resultBlocks));
                            int repeats = repeatedNoProgress.merge(fingerprint, 1, Integer::sum);
                            if (repeats >= 3 || recoveryTurns >= recoveryLimit) {
                                String why = repeats >= 3 ? "Same compatibility batch made no progress " + repeats + " times" : "Compatibility batch made no progress after " + recoveryTurns + " attempts";
                                if (switchToNextModel(run, onStep, step, why)) {
                                    recoveryTurns = 0; repeatedNoProgress.clear(); repeatedCalls.clear(); verificationSteering.clear();
                                    messages.add(Map.of("role", "system", "content", modelFailoverContinuation(run)));
                                    continue;
                                }
                                RecoveryReplanDecision recovery = attemptExecutorRecoveryReplan(apiKey, request, messages, ws, run, onStep, step,
                                        "Compatibility batch exhausted executor fallbacks", why);
                                if (recovery.recovered()) {
                                    recoveryTurns = 0; repeatedNoProgress.clear(); repeatedCalls.clear(); verificationSteering.clear();
                                    lastPlanIndex = run.activePlanIndex(); requireToolNextTurn = false; transportReported = false;
                                    continue;
                                }
                                completionStatus = "failed";
                                finalMessage = recoveryExhaustedMessage(recoveryTurns, recoveryLimit, run, recovery.reason());
                                break;
                            }
                        }
                        continue;
                    }
                    if ("tool".equals(type)) {
                        String requestedTool = envelope.path("tool").asText("").trim();
                        String tool = toolRegistry.canonical(requestedTool);
                        JsonNode args = normalizeLegacyArgs(requestedTool, tool, envelope.path("args"));
                        String detail = envelope.path("reason").asText("").trim();
                        if (detail.isBlank()) detail = describeTool(tool, args);
                        String result;
                        String status;
                        boolean compatibilityExecuted = false;

                        onStep.accept(stepEvent(step, tool, detail, "running", args, null, null));
                        if (!isKnownTool(requestedTool, tool, mcpCatalog)) {
                            result = unknownToolMessage(requestedTool, mcpCatalog);
                            status = "error";
                        } else {
                            PreparedCall compatibilityCall = new PreparedCall(
                                    new OpenAiCompatibleClient.AgentToolCall("compat_" + step, requestedTool, args),
                                    requestedTool, tool, args, detail);
                            ToolExecution execution = preflightCall(compatibilityCall, mcpCatalog);
                            if (execution == null) {
                                execution = executeWithPermission(ws, run, tool, args, request.settings(), detail, step, onStep,
                                        mcpCatalog, availableTools, apiKey, request);
                            }
                            execution = applyRepeatOutcomeGuard(compatibilityCall, execution, run, repeatedCalls, mcpCatalog);
                            result = execution.result();
                            status = execution.status();
                            if (execution.executed()) {
                                observeRun(ws, run, tool, args, result);
                                toolActivity++;
                                compatibilityExecuted = true;
                            }
                        }
                        onStep.accept(stepEvent(step, tool, summarizeResult(tool, result), status, args, clipUi(result), null));
                        appendFallbackToolTranscript(messages, raw, tool, result);
                        if (compatibilityExecuted) {
                            recoveryTurns = 0;
                            if (isVerifier(tool, args) && run.verifiedCurrentRevision() && run.hasOpenPlanItems()) {
                                StepCompletionDecision stepDecision = activeStepCompletionGate(apiKey, request, ws, run, step, onStep);
                                if (stepDecision.satisfied() && run.activePlanIndex() > 0) {
                                    int completedIndex = run.activePlanIndex();
                                    try {
                                        run.updatePlan(completedIndex, "completed", "Runtime completion critic: " + stepDecision.reason());
                                        onStep.accept(stepEvent(step, "plan_step_complete",
                                                "Compatibility verifier evidence satisfies plan step " + completedIndex + "; advanced automatically",
                                                "success", null, clipUi(stepDecision.reason()), null));
                                        if (run.hasOpenPlanItems()) {
                                            messages.add(Map.of("role", "system", "content",
                                                    "[RUNTIME_STEERING:step-advanced] Verified evidence completed the previous step. Continue only step " +
                                                            run.activePlanIndex() + ": " + run.activePlanStepText()));
                                        }
                                    } catch (Exception gateFailure) {
                                        onStep.accept(stepEvent(step, "plan_gate",
                                                "Step completion critic passed, but the sequential gate kept the step active",
                                                "running", null, clipUi(safe(gateFailure.getMessage())), null));
                                    }
                                }
                            }
                        } else {
                            recoveryTurns++;
                            String stalledFingerprint = "compat-no-progress|" + run.mutationRevision() + "|" + normalizeNoProgress(result);
                            int identicalStalls = repeatedNoProgress.merge(stalledFingerprint, 1, Integer::sum);
                            boolean fastEscalate = identicalStalls >= 3;
                            if (fastEscalate || recoveryTurns >= recoveryLimit) {
                                String why = fastEscalate
                                        ? "Same compatibility no-progress outcome repeated " + identicalStalls + " times"
                                        : "Compatibility tool flow made no progress after " + recoveryTurns + " attempts";
                                if (switchToNextModel(run, onStep, step, why)) {
                                    recoveryTurns = 0;
                                    repeatedNoProgress.clear();
                                    repeatedCalls.clear();
                                    verificationSteering.clear();
                                    messages.add(Map.of("role", "system", "content", modelFailoverContinuation(run)));
                                    continue;
                                }
                                run.markRepeatedCallPrevented();
                                RecoveryReplanDecision recovery = attemptExecutorRecoveryReplan(apiKey, request, messages, ws, run, onStep, step,
                                        "Compatibility tool flow made no progress after all executor fallbacks", result);
                                if (recovery.recovered()) {
                                    recoveryTurns = 0;
                                    repeatedNoProgress.clear();
                                    repeatedCalls.clear();
                                    verificationSteering.clear();
                                    lastPlanIndex = run.activePlanIndex();
                                    requireToolNextTurn = false;
                                    transportReported = false;
                                    continue;
                                }
                                completionStatus = "failed";
                                finalMessage = recoveryExhaustedMessage(recoveryTurns, recoveryLimit, run, recovery.reason());
                                onStep.accept(stepEvent(step, "loop_guard",
                                        "Focused recovery could not be initialized",
                                        "error", null, clipUi(recovery.reason()), null));
                                break;
                            }
                            messages.add(Map.of("role", "user", "content", recoveryDirective((int) recoveryTurns, recoveryLimit, true, result)));
                            onStep.accept(stepEvent(step, "agent_recovery",
                                    "Compatibility tool call made no progress; switching strategy (recovery " + recoveryTurns + "/" + recoveryLimit + " on " + effectiveModel(run, request.settings()) + ")",
                                    "running", null, clipUi(result), null));
                        }
                        continue;
                    }
                }

                // A prose response after real work can finish only when the current mutated revision is verified.
                if (!raw.isBlank() && toolActivity > 0) {
                    // Read-only investigation/analysis steps should not depend on the model remembering a bookkeeping
                    // todo_update call. When the active step made real read/search tool progress without mutating the
                    // workspace, a small evidence critic may advance it automatically. This closes a common source of
                    // long no-progress loops while keeping implementation steps behind the normal verifier gate.
                    if (run.hasOpenPlanItems() && !looksLikeBlockedFinal(raw) &&
                            run.mutationRevision() == run.planStepStartMutationRevision() &&
                            run.planStepToolActivity() > 0 && looksReadOnlyPlanStep(run.activePlanStepText())) {
                        StepCompletionDecision readOnlyDecision = activeReadOnlyStepCompletionGate(apiKey, request, run, step, onStep);
                        if (readOnlyDecision.satisfied() && run.activePlanIndex() > 0) {
                            int completedIndex = run.activePlanIndex();
                            try {
                                run.updatePlan(completedIndex, "completed", "Runtime evidence critic: " + readOnlyDecision.reason());
                                onStep.accept(stepEvent(step, "plan_step_complete",
                                        "Read-only plan step " + completedIndex + " satisfied by workspace evidence; advanced automatically",
                                        "success", null, clipUi(readOnlyDecision.reason()), null));
                                if (run.hasOpenPlanItems()) {
                                    messages.add(Map.of("role", "system", "content", activeStepContract(run)));
                                    requireToolNextTurn = turn.nativeToolsUsed();
                                    continue;
                                }
                            } catch (Exception gateFailure) {
                                onStep.accept(stepEvent(step, "plan_gate", "Read-only completion critic passed, but the sequential gate kept the step active",
                                        "running", null, clipUi(safe(gateFailure.getMessage())), null));
                            }
                        }
                    }
                    if (run.hasOpenPlanItems() && !looksLikeBlockedFinal(raw)) {
                        messages.add(Map.of("role", "assistant", "content", raw));
                        messages.add(Map.of("role", "user", "content", planContinuationPrompt(run, false)));
                        onStep.accept(stepEvent(step, "plan_gate", "Final response deferred; approved plan step " + run.activePlanIndex() + " is still active", "running", null, run.planText(), null));
                        requireToolNextTurn = turn.nativeToolsUsed();
                        continue;
                    }
                    if (requiresCurrentRevisionVerification(run)) {
                        if (looksLikeBlockedFinal(raw) && externalVerificationBlocker(run.lastVerification())) {
                            completionStatus = "blocked";
                            finalMessage = raw;
                            onStep.accept(stepEvent(step, "finish",
                                    "Agent stopped because the execution environment prevented required verification",
                                    "blocked", null, clipUi(raw), null));
                            break;
                        }
                        if (verificationSteeringBlocked(verificationSteering, run)) {
                            completionStatus = "failed";
                            finalMessage = "Execution stopped: the model repeatedly tried to finish an unverified workspace revision without a new fix or verifier result. The duplicate verification loop was stopped to protect the token budget.";
                            onStep.accept(stepEvent(step, "loop_guard", "Stopped repeated finish-without-verification loop", "error", null, clipUi(raw), null));
                            break;
                        }
                        String finishFingerprint = "unverified-prose|" + run.mutationRevision() + "|" + normalizeNoProgress(raw);
                        int finishRepeat = repeatedNoProgress.merge(finishFingerprint, 1, Integer::sum);
                        if (finishRepeat == 1) messages.add(Map.of("role", "assistant", "content", raw));
                        else run.markRepeatedCallPrevented();
                        messages.add(Map.of("role", "user", "content", verificationRequiredPrompt(run)));
                        onStep.accept(stepEvent(step, "verification_required",
                                "The current workspace revision is not successfully verified; continuing the build/run/fix loop",
                                "running", null, clipUi(raw), null));
                        requireToolNextTurn = turn.nativeToolsUsed();
                        continue;
                    }
                    completionStatus = looksLikeBlockedFinal(raw) ? "blocked" : "completed";
                    finalMessage = raw;
                    onStep.accept(stepEvent(step, "finish", "Agent completed after verified tool activity", "done", null, null, null));
                    break;
                }

                // Recover from non-actionable turns instead of terminating early. Identical prose is not echoed back
                // repeatedly because that reinforces the same response pattern; the steering prompt changes strategy.
                String noProgressFingerprint = run.mutationRevision() + "|" + normalizeNoProgress(raw);
                int noProgressCount = repeatedNoProgress.merge(noProgressFingerprint, 1, Integer::sum);
                recoveryTurns++;
                boolean fastEscalate = noProgressCount >= 3;
                if (fastEscalate || recoveryTurns >= recoveryLimit) {
                    String why = fastEscalate
                            ? "Same non-actionable response repeated " + noProgressCount + " times"
                            : "Non-actionable responses after " + recoveryTurns + " recovery attempts";
                    if (switchToNextModel(run, onStep, step, why)) {
                        recoveryTurns = 0;
                        repeatedNoProgress.clear();
                        repeatedCalls.clear();
                        verificationSteering.clear();
                        messages.add(Map.of("role", "system", "content", modelFailoverContinuation(run)));
                        requireToolNextTurn = false;
                        continue;
                    }
                    run.markRepeatedCallPrevented();
                    RecoveryReplanDecision recovery = attemptExecutorRecoveryReplan(apiKey, request, messages, ws, run, onStep, step,
                            "Non-actionable responses exhausted every executor model", raw);
                    if (recovery.recovered()) {
                        recoveryTurns = 0;
                        repeatedNoProgress.clear();
                        repeatedCalls.clear();
                        verificationSteering.clear();
                        lastPlanIndex = run.activePlanIndex();
                        requireToolNextTurn = false;
                        transportReported = false;
                        continue;
                    }
                    completionStatus = "failed";
                    finalMessage = recoveryExhaustedMessage(recoveryTurns, recoveryLimit, run, recovery.reason());
                    onStep.accept(stepEvent(step, "loop_guard",
                            "Focused recovery could not be initialized",
                            "error", null, clipUi(recovery.reason()), null));
                    break;
                }
                boolean duplicate = noProgressCount > 1;
                if (duplicate) run.markRepeatedCallPrevented();
                if (!raw.isBlank() && !duplicate) messages.add(Map.of("role", "assistant", "content", raw));
                messages.add(Map.of("role", "user", "content", recoveryDirective((int) recoveryTurns, recoveryLimit, duplicate, raw)));
                requireToolNextTurn = turn.nativeToolsUsed();
                onStep.accept(stepEvent(step, "agent_recovery",
                        (duplicate ? "Duplicate non-actionable response detected; forcing a different strategy" : "Model returned without an actionable tool call") +
                                " (recovery " + recoveryTurns + "/" + recoveryLimit + " on " + effectiveModel(run, request.settings()) + ")",
                        "running", null, clipUi(raw), null));
            }

            // Execution/verification outcome is authoritative. Post-processing must never convert a successful
            // task into FAILED merely because diff/report formatting encountered an unsupported file.
            List<ProjectPatchRequest.ProjectPatchFile> changes = List.of();
            int totalWorkspaceChanges = 0;
            int omittedTextWorkspaceChanges = 0;
            boolean hasResourceChanges = false;
            String reportingWarning = null;
            try {
                changes = workspaces.changes(ws);
                totalWorkspaceChanges = workspaces.changeCount(ws);
                omittedTextWorkspaceChanges = workspaces.omittedTextChangeCount(ws);
                hasResourceChanges = workspaces.hasResourceChanges(ws);
            } catch (Exception reportingFailure) {
                reportingWarning = "Workspace change summary was unavailable: " + providerFailureDetail(reportingFailure);
                try { onStep.accept(stepEvent(run.activePlanIndex(), "reporting_warning",
                        "Task outcome preserved; workspace reporting encountered a non-fatal problem",
                        "warning", null, clipUi(reportingWarning), null)); } catch (Exception ignored) { }
            }
            try {
                finalMessage = decorateFinalMessage(finalMessage, ws, totalWorkspaceChanges, hasResourceChanges, run, completionStatus);
                if (omittedTextWorkspaceChanges > 0) finalMessage += "\n\n> Workspace reporting: " + omittedTextWorkspaceChanges +
                        " changed file(s) were tracked safely by hash with text diff omitted because the content was binary, non-UTF-8, or too large.";
            } catch (Exception reportingFailure) {
                String detail = providerFailureDetail(reportingFailure);
                reportingWarning = reportingWarning == null ? detail : reportingWarning + "; " + detail;
                if (finalMessage == null || finalMessage.isBlank()) finalMessage = "Agent run " + completionStatus + ".";
            }
            if (reportingWarning != null && !reportingWarning.isBlank()) {
                finalMessage = (finalMessage == null ? "Agent run " + completionStatus + "." : finalMessage) +
                        "\n\n> Reporting warning: " + reportingWarning;
            }
            run.markFinalAnswer(finalMessage);
            run.finish(completionStatus);
            return new AgentResult(finalMessage, changes);
        } catch (AgentCancelledException cancelled) {
            try { onStep.accept(stepEvent(run.activePlanIndex(), "run_cancelled", "Agent run was cancelled", "error", null, null, null)); }
            catch (Exception ignored) { }
            run.finish("cancelled");
            throw cancelled;
        } catch (Exception e) {
            String failureDetail = providerFailureDetail(e);
            try { onStep.accept(stepEvent(run.activePlanIndex(), "run_failure", "Agent run failed: " + failureDetail, "error", null, clipUi(failureDetail), null)); }
            catch (Exception ignored) { }
            run.finish("failed");
            throw e;
        } finally {
            clearActiveContextCache(run);
            approvals.cancelRun(run.id());
            workspaces.stopRunProcesses(run.id());
            workspaces.cleanup(ws); // direct workspace cleanup is intentionally a no-op
        }
    }

    /**
     * Agent mode without a local project is intentionally supported for Jira/Confluence/MCP and requirement-document
     * analysis. The existing workspace execution path is left untouched and selected whenever a projectId is present.
     */
    private AgentResult runWithoutWorkspace(AgentRunService.AgentRun run, String apiKey, ChatRequest request,
                                            List<Map<String,Object>> baseContext,
                                            Consumer<Map<String,Object>> onStep) throws Exception {
        String finalMessage = null;
        String completionStatus = "running";
        try {
            run.updateProgress(4, "starting", "Resolving MCP and requirement context");
            McpManager.Catalog mcpCatalog = mcp.catalog(null);
            List<Map<String,Object>> availableTools = new CopyOnWriteArrayList<>(
                    toolRegistry.filterDefinitions(toolRegistry.builtInDefinitions(), EXTERNAL_AGENT_BUILTINS, false));
            availableTools.addAll(mcpCatalog.definitions());
            Set<String> allowedTools = new LinkedHashSet<>();
            for (Map<String,Object> def : availableTools) {
                Object fn = def.get("function");
                if (fn instanceof Map<?,?> map && map.get("name") != null) allowedTools.add(String.valueOf(map.get("name")));
            }

            List<Map<String,Object>> messages = prepareExternalAgentMessages(baseContext, mcpCatalog);
            String task = latestUserTask(messages);
            run.setObjective(task);
            run.configureLargeTask(false, 10);
            String status = mcpCatalog.diagnostics().isEmpty() ? "No MCP server diagnostics available" : String.join("\n", mcpCatalog.diagnostics());
            onStep.accept(stepEvent(0, "context_resolution",
                    "No local workspace selected; using MCP, attachments and conversation evidence",
                    "success", null, clipUi(status), null));

            List<String> plan = List.of(
                    "Gather the Jira/Confluence/MCP and uploaded requirement evidence needed for the user's request, correlate it, and produce the requested analysis/report without inventing unavailable facts\n" +
                            "Validate: final response is grounded in retrieved or user-supplied evidence and clearly identifies any unavailable source");
            run.setPlan(plan);
            run.setPlanValidation("approved", "External-evidence Agent plan: workspace is intentionally optional for this run.");
            onStep.accept(stepEvent(0, "plan", "External analysis plan ready", "success", null, run.planText(), null));

            if (request.settings().planApprovalRequired()) {
                run.updateProgress(13, "plan_review", "External analysis plan is ready for your approval");
                AgentApprovalService.Approval approval = approvals.create(run.id(), "plan_approval",
                        "Review the Jira/Confluence/document analysis plan before execution starts");
                onStep.accept(stepEvent(0, "plan_approval", "Review the plan and approve execution", "approval", null, run.planText(), approval.id()));
                AgentApprovalService.Decision decision = approvals.await(approval.id(), Duration.ZERO, run);
                if (decision == AgentApprovalService.Decision.DENY) {
                    finalMessage = "Plan was not approved, so the agent did not call MCP tools or continue the analysis.";
                    run.markFinalAnswer(finalMessage);
                    run.finish("cancelled");
                    return new AgentResult(finalMessage, List.of());
                }
                onStep.accept(stepEvent(0, "plan_approval", "Plan approved; external analysis started", "success", null, null, null));
            }

            run.markPlanStarted();
            messages.add(Map.of("role", "system", "content",
                    "APPROVED EXTERNAL ANALYSIS PLAN:\n" + run.planText() +
                            "\n\nUse only the MCP/attachment tools exposed for this no-workspace run. Complete the user's requested analysis and then return the final answer."));
            run.updateProgress(18, "executing", "Collecting external and requirement evidence");

            boolean expectsMcpEvidence = looksLikeMcpEvidenceTask(task);
            int mcpCalls = 0;
            int forcedEvidenceTurns = 0;
            int emptyTurns = 0;
            int step = 0;
            Map<String,Integer> repeatedCalls = new HashMap<>();

            while (true) {
                step++;
                run.checkCancelled();
                OpenAiCompatibleClient.AgentCompletion turn = completeExternalAgentTurn(
                        apiKey, request, messages, availableTools, run, false, step, onStep);
                String raw = turn.content() == null ? "" : turn.content().trim();

                if (turn.hasToolCall()) {
                    appendNativeAssistantTurn(messages, turn.toolCalls(), raw);
                    boolean executedAny = false;
                    for (OpenAiCompatibleClient.AgentToolCall call : turn.toolCalls()) {
                        String requested = call.name() == null ? "" : call.name().trim();
                        String tool = toolRegistry.canonical(requested);
                        if (mcp.isMcpTool(mcpCatalog, requested)) tool = requested;
                        JsonNode args = normalizeLegacyArgs(requested, tool, call.arguments());
                        String result;
                        String toolStatus;
                        if (!allowedTools.contains(tool) && !allowedTools.contains(requested)) {
                            result = "TOOL NOT AVAILABLE WITHOUT A WORKSPACE: " + requested +
                                    ". Select/mention a local project path if the task requires workspace operations.";
                            toolStatus = "error";
                        } else {
                            String selectedTool = allowedTools.contains(tool) ? tool : requested;
                            onStep.accept(stepEvent(step, selectedTool, describeTool(selectedTool, args), "running", args, null, null));
                            ToolExecution execution = executeWithPermission(null, run, selectedTool, args, request.settings(),
                                    describeTool(selectedTool, args), step, onStep, mcpCatalog, availableTools, apiKey, request);
                            PreparedCall prepared = new PreparedCall(call, requested, selectedTool, args, describeTool(selectedTool, args));
                            execution = applyRepeatOutcomeGuard(prepared, execution, run, repeatedCalls, mcpCatalog);
                            result = execution.result();
                            toolStatus = execution.status();
                            if (execution.executed()) {
                                observeRun(null, run, selectedTool, args, result);
                                executedAny = true;
                                if (mcp.isMcpTool(mcpCatalog, selectedTool)) mcpCalls++;
                            }
                        }
                        onStep.accept(stepEvent(step, tool, summarizeResult(tool, result), toolStatus, args, clipUi(result), null));
                        appendNativeToolResult(messages, call.id(), requested, result);
                    }
                    if (executedAny) emptyTurns = 0; else emptyTurns++;
                    continue;
                }

                JsonNode envelope = parseEnvelope(raw);
                if (envelope != null && envelope.isObject()) {
                    String type = envelope.path("type").asText("").trim().toLowerCase(Locale.ROOT);
                    if ("tool".equals(type)) {
                        String requested = envelope.path("tool").asText("").trim();
                        String selectedTool = mcp.isMcpTool(mcpCatalog, requested) ? requested : toolRegistry.canonical(requested);
                        JsonNode args = normalizeLegacyArgs(requested, selectedTool, envelope.path("args"));
                        String result;
                        String toolStatus;
                        if (!allowedTools.contains(selectedTool)) {
                            result = "TOOL NOT AVAILABLE WITHOUT A WORKSPACE: " + requested;
                            toolStatus = "error";
                        } else {
                            onStep.accept(stepEvent(step, selectedTool, describeTool(selectedTool, args), "running", args, null, null));
                            ToolExecution execution = executeWithPermission(null, run, selectedTool, args, request.settings(),
                                    describeTool(selectedTool, args), step, onStep, mcpCatalog, availableTools, apiKey, request);
                            PreparedCall prepared = new PreparedCall(
                                    new OpenAiCompatibleClient.AgentToolCall("external_" + step, requested, args),
                                    requested, selectedTool, args, describeTool(selectedTool, args));
                            execution = applyRepeatOutcomeGuard(prepared, execution, run, repeatedCalls, mcpCatalog);
                            result = execution.result();
                            toolStatus = execution.status();
                            if (execution.executed()) {
                                observeRun(null, run, selectedTool, args, result);
                                if (mcp.isMcpTool(mcpCatalog, selectedTool)) mcpCalls++;
                            }
                        }
                        onStep.accept(stepEvent(step, selectedTool, summarizeResult(selectedTool, result), toolStatus, args, clipUi(result), null));
                        appendFallbackToolTranscript(messages, raw, selectedTool, result);
                        continue;
                    }
                    if ("tools".equals(type) && envelope.path("calls").isArray()) {
                        List<String> results = new ArrayList<>();
                        int n = 0;
                        for (JsonNode call : envelope.path("calls")) {
                            if (++n > 8) break;
                            String requested = call.path("tool").asText("").trim();
                            String selectedTool = mcp.isMcpTool(mcpCatalog, requested) ? requested : toolRegistry.canonical(requested);
                            JsonNode args = normalizeLegacyArgs(requested, selectedTool, call.path("args"));
                            String result;
                            String toolStatus;
                            if (!allowedTools.contains(selectedTool)) {
                                result = "TOOL NOT AVAILABLE WITHOUT A WORKSPACE: " + requested;
                                toolStatus = "error";
                            } else {
                                onStep.accept(stepEvent(step, selectedTool, describeTool(selectedTool, args), "running", args, null, null));
                                ToolExecution execution = executeWithPermission(null, run, selectedTool, args, request.settings(),
                                        describeTool(selectedTool, args), step, onStep, mcpCatalog, availableTools, apiKey, request);
                                result = execution.result();
                                toolStatus = execution.status();
                                if (execution.executed()) {
                                    observeRun(null, run, selectedTool, args, result);
                                    if (mcp.isMcpTool(mcpCatalog, selectedTool)) mcpCalls++;
                                }
                            }
                            onStep.accept(stepEvent(step, selectedTool, summarizeResult(selectedTool, result), toolStatus, args, clipUi(result), null));
                            results.add("TOOL RESULT for " + selectedTool + ":\n" + clip(result));
                        }
                        if (!raw.isBlank()) messages.add(Map.of("role", "assistant", "content", clipHistoricalAssistant(raw)));
                        messages.add(Map.of("role", "user", "content", String.join("\n\n", results) +
                                "\n\nContinue the approved external-analysis task. Use another MCP/attachment tool if needed, otherwise return the final result."));
                        continue;
                    }
                    if ("final".equals(type)) {
                        String requestedStatus = normalizeFinalStatus(envelope.path("status").asText("completed"));
                        String requestedMessage = envelope.path("message").asText("").trim();
                        if (expectsMcpEvidence && mcpCalls == 0 && !mcpCatalog.definitions().isEmpty() && forcedEvidenceTurns < 2) {
                            forcedEvidenceTurns++;
                            messages.add(Map.of("role", "assistant", "content", clipHistoricalAssistant(raw)));
                            messages.add(Map.of("role", "user", "content",
                                    "The request depends on Jira/Confluence/DevOps facts. Use an appropriate MCP tool now before finalizing; do not answer those facts from memory."));
                            continue;
                        }
                        completionStatus = requestedStatus;
                        finalMessage = requestedMessage.isBlank() ? "External analysis completed." : requestedMessage;
                        break;
                    }
                }

                if (!raw.isBlank()) {
                    if (expectsMcpEvidence && mcpCalls == 0 && !mcpCatalog.definitions().isEmpty() && forcedEvidenceTurns < 2) {
                        forcedEvidenceTurns++;
                        messages.add(Map.of("role", "assistant", "content", clipHistoricalAssistant(raw)));
                        messages.add(Map.of("role", "user", "content",
                                "Use a relevant MCP tool now to retrieve the requested Jira/Confluence/DevOps evidence. Do not finalize from model memory."));
                        continue;
                    }
                    completionStatus = looksLikeBlockedFinal(raw) ? "blocked" : "completed";
                    finalMessage = raw;
                    break;
                }

                emptyTurns++;
                if (emptyTurns >= MAX_CONSECUTIVE_EMPTY_SUBAGENT_TURNS + 1) {
                    completionStatus = "failed";
                    finalMessage = "Agent stopped because the selected model repeatedly returned no content or MCP tool call for the external-analysis task.";
                    break;
                }
                messages.add(Map.of("role", "user", "content",
                        "Continue the approved analysis. Call the required MCP/attachment tool or return a substantive final answer."));
            }

            // This no-workspace mode has one broad evidence-to-report plan step. Real MCP/attachment calls are already
            // recorded as plan activity. A direct answer from user-supplied document/conversation context is also valid
            // evidence and is recorded explicitly so the durable plan can close without fabricating a workspace verifier.
            if (!"failed".equals(completionStatus) && !"cancelled".equals(completionStatus)) {
                while (run.activePlanIndex() > 0) {
                    if (run.planStepToolActivity() <= 0) {
                        run.recordPlanToolActivity("external_analysis", "Evidence-based Jira/Confluence/document analysis completed without a local workspace");
                    }
                    int completedIndex = run.activePlanIndex();
                    run.updatePlan(completedIndex, "completed", "External evidence gathered/analyzed and final response prepared");
                    if (run.activePlanIndex() > 0) {
                        onStep.accept(stepEvent(step, "plan_step_complete", "External analysis advanced to approved plan step " + run.activePlanIndex(),
                                "success", null, null, null));
                    }
                }
            }
            String finishStatus = "failed".equals(completionStatus) || "blocked".equals(completionStatus) ? "error" : "done";
            onStep.accept(stepEvent(step, "finish", "External analysis " + completionStatus, finishStatus, null, null, null));
            run.markFinalAnswer(finalMessage == null || finalMessage.isBlank() ? "External analysis completed." : finalMessage);
            run.finish(completionStatus);
            return new AgentResult(finalMessage == null || finalMessage.isBlank() ? "External analysis completed." : finalMessage, List.of());
        } catch (AgentCancelledException cancelled) {
            try { onStep.accept(stepEvent(run.activePlanIndex(), "run_cancelled", "Agent run was cancelled", "error", null, null, null)); }
            catch (Exception ignored) { }
            run.finish("cancelled");
            throw cancelled;
        } catch (Exception e) {
            String failureDetail = providerFailureDetail(e);
            try { onStep.accept(stepEvent(run.activePlanIndex(), "run_failure", "External Agent run failed: " + failureDetail,
                    "error", null, clipUi(failureDetail), null)); } catch (Exception ignored) { }
            run.finish("failed");
            throw e;
        } finally {
            approvals.cancelRun(run.id());
        }
    }

    private List<Map<String,Object>> prepareExternalAgentMessages(List<Map<String,Object>> baseContext,
                                                                   McpManager.Catalog catalog) {
        List<Map<String,Object>> messages = new ArrayList<>();
        boolean merged = false;
        String diagnostics = catalog == null || catalog.diagnostics().isEmpty()
                ? "[No MCP diagnostics]" : String.join("\n", catalog.diagnostics());
        if (baseContext != null) {
            for (Map<String,Object> message : baseContext) {
                if (!merged && "system".equals(String.valueOf(message.get("role")))) {
                    Map<String,Object> copy = new LinkedHashMap<>(message);
                    copy.put("content", String.valueOf(message.getOrDefault("content", "")) + "\n\n" + EXTERNAL_AGENT_PROTOCOL +
                            "\n\nMCP STATUS\n" + diagnostics);
                    messages.add(copy);
                    merged = true;
                } else messages.add(new LinkedHashMap<>(message));
            }
        }
        if (!merged) messages.add(0, Map.of("role", "system", "content", EXTERNAL_AGENT_PROTOCOL + "\n\nMCP STATUS\n" + diagnostics));
        return messages;
    }

    private boolean looksLikeMcpEvidenceTask(String task) {
        if (task == null || task.isBlank()) return false;
        String low = task.toLowerCase(Locale.ROOT);
        if (low.contains("jira") || low.contains("confluence") || low.contains("gitlab") || low.contains("sonarqube") ||
                low.contains("sonar") || low.contains("mcp") || low.contains("atlassian") || low.contains("acceptance criteria")) return true;
        return java.util.regex.Pattern.compile("(?i)\\b[A-Z][A-Z0-9]{1,15}-\\d+\\b").matcher(task).find();
    }

    private OpenAiCompatibleClient.AgentCompletion completeExternalAgentTurn(String apiKey, ChatRequest request,
                                                                              List<Map<String,Object>> messages,
                                                                              List<Map<String,Object>> tools,
                                                                              AgentRunService.AgentRun run,
                                                                              boolean requireTool,
                                                                              int step,
                                                                              Consumer<Map<String,Object>> onStep) throws Exception {
        boolean overflowRecovered = false;
        int retriesOnActivation = 0;
        int modelActivations = 1;
        final int maxModelActivations = providerRecoveryActivationLimit(run);
        while (true) {
            run.checkCancelled();
            String model = effectiveModel(run, request.settings());
            ContextWindowManager.ContextEstimate estimate = contextWindows.estimate(messages, tools, request.settings(), model);
            run.recordContextEstimate(estimate.estimatedInputTokens(), estimate.contextWindowTokens());
            try {
                OpenAiCompatibleClient.AgentCompletion turn = llm.completeAgent(apiKey, request.settings().baseUrl(), model,
                        request.settings().safeMaxTokens(), messages, tools, requireTool, run::cancelled);
                run.recordModelUsage(turn.usage(), estimate.estimatedInputTokens());
                return turn;
            } catch (AgentCancelledException cancelled) {
                throw cancelled;
            } catch (Exception e) {
                String error = providerFailureDetail(e);
                if (isContextWindowFailure(e) && !overflowRecovered) {
                    ContextWindowManager.CompactionResult compacted = contextWindows.compact(
                            messages, tools, request.settings(), run, true, null, model);
                    overflowRecovered = true;
                    if (compacted.compacted()) {
                        run.recordCompaction(compacted.estimatedTokensSaved(), compacted.reason());
                        onStep.accept(stepEvent(step, "context_compaction", "External Agent context compacted: " + formatCompaction(compacted),
                                "success", null, null, null));
                        continue;
                    }
                }
                run.recordExecutionFailure("External Agent model/provider failure on " + model + ": " + error);
                if (!isAuthenticationFailure(e) && retriesOnActivation < PROVIDER_RETRIES_PER_MODEL_ACTIVATION) {
                    retriesOnActivation++;
                    onStep.accept(stepEvent(step, "model_retry", "Retrying " + model + " after provider/model failure (retry " +
                            retriesOnActivation + "/" + PROVIDER_RETRIES_PER_MODEL_ACTIVATION + ")", "running", null, clipUi(error), null));
                    sleepCancellable(run, providerRetryDelayMs(retriesOnActivation));
                    continue;
                }
                if (!isAuthenticationFailure(e) && modelActivations < maxModelActivations &&
                        switchToNextModelCyclic(run, onStep, step, error)) {
                    modelActivations++;
                    retriesOnActivation = 0;
                    overflowRecovered = false;
                    messages.add(Map.of("role", "system", "content",
                            "MODEL FAILOVER CONTINUATION: preserve all retrieved MCP/document evidence and continue the same external-analysis task."));
                    continue;
                }
                throw new ProviderModelException(model, error, e);
            }
        }
    }

    /** Task shape controls plan granularity, never capability. Even one configured model can run the full harness. */
    private record TaskProfile(String level, int minSteps, int maxSteps, boolean largeTask, int batchSize, String guidance) { }

    private TaskProfile classifyTask(String task) {
        String value = task == null ? "" : task.toLowerCase(Locale.ROOT);
        int signals = 0;
        if (value.length() > 900) signals += 2; else if (value.length() > 350) signals++;
        for (String word : List.of("framework", "architecture", "migrate", "migration", "refactor", "multiple", "across", "integration", "self-heal", "self healing", "end-to-end", "e2e", "performance", "security", "repository", "codebase")) {
            if (value.contains(word)) signals++;
        }
        long pathHints = Arrays.stream(value.split("\\s+")).filter(v -> v.contains("/") || v.contains("\\")).count();
        if (pathHints > 1) signals++;

        int explicitScale = 0;
        java.util.regex.Matcher countMatcher = java.util.regex.Pattern.compile("\\b(\\d{2,5})\\b").matcher(value);
        while (countMatcher.find()) {
            try { explicitScale = Math.max(explicitScale, Integer.parseInt(countMatcher.group(1))); } catch (Exception ignored) { }
        }
        boolean broadScope = List.of("all tests", "all cases", "entire project", "whole project", "full migration", "large migration", "hundreds", "thousands", "1000", "1,000")
                .stream().anyMatch(value::contains);
        boolean migrationScale = (value.contains("migrat") || value.contains("refactor")) &&
                (value.contains("framework") || value.contains("module") || value.contains("feature") || value.contains("project"));
        if (explicitScale >= 25 || broadScope || (migrationScale && signals >= 4)) {
            int batch = explicitScale >= 500 ? 10 : explicitScale >= 100 ? 10 : 8;
            return new TaskProfile("large", 5, 12, true, batch,
                    "Use a hierarchical master plan: inventory scope first, then process independent work items in durable batches. Initialize the work-item ledger before bulk edits, use cheap structural validation at batch boundaries, keep failures in the failed queue, and reserve full runtime/regression verification for the final phase.");
        }
        if (signals >= 4) return new TaskProfile("complex", 4, 10, false, 10, "Use a compact but complete multi-stage plan. Separate materially different implementation/verification concerns; do not create cosmetic steps.");
        if (signals >= 2) return new TaskProfile("normal", 3, 7, false, 10, "Use only the steps needed to inspect, implement and verify the requested scope.");
        return new TaskProfile("focused", 2, 5, false, 10, "Keep the plan short. Do not inflate a focused edit/bug fix into a large process; batch the coherent edit first and reserve compile/test/execution for the final verification step.");
    }

    private TaskProfile refineTaskProfile(TaskProfile initial, String evidence) {
        if (initial == null || initial.largeTask()) return initial;
        String value = evidence == null ? "" : evidence;
        long pathRows = value.lines().filter(line -> line.stripLeading().startsWith("- ") && line.contains("/")).limit(80).count();
        boolean wideEvidence = value.length() > 28_000 || pathRows >= 35;
        if (wideEvidence && ("complex".equals(initial.level()) || "normal".equals(initial.level()))) {
            return new TaskProfile("large", 5, 12, true, 10,
                    "Repository evidence shows a wide change surface. Inventory scope into the durable work-item ledger and execute in small batches with structural checks, targeted failure recovery, and one final full verification.");
        }
        return initial;
    }

    private List<String> fallbackPlan(TaskProfile profile) {
        if (profile != null && profile.largeTask()) {
            return List.of(
                    "Inventory the complete requested scope from live workspace evidence and initialize the durable work-item ledger with independent migration/change units\nValidate: ledger coverage is grounded in source files/scenarios/modules and batch size is bounded",
                    "Process the first bounded batch of pending work items using existing project conventions and mark each item completed or failed with evidence\nValidate: changed files match only the active batch and failures are recorded explicitly",
                    "Continue remaining batches from the durable ledger, using cheap compile/type/static checks at sensible batch boundaries instead of full regression after every batch\nValidate: ledger progress advances monotonically and structural errors are fixed before the next dependent batch",
                    "Drain the failed work-item and verifier-failure queues by grouping common root causes, fixing them once, and rerunning only the smallest relevant checks\nValidate: no failed/pending work items remain except genuine external blockers",
                    "Perform final project verification on the latest complete workspace revision and review the final diff for omissions or unintended edits\nValidate: appropriate final verifier(s) pass and the durable ledger has no unresolved items"
            );
        }
        if (profile != null && "focused".equals(profile.level())) {
            return List.of(
                    "Inspect the exact affected implementation/signature and confirm the requested behavior from live workspace evidence\nValidate: relevant source/config and the intended change are identified before editing",
                    "Implement the complete focused change while preserving surrounding behavior\nValidate: inspect the current workspace diff and confirm the requested edits are present; do not compile/test yet",
                    "Perform final verification after all requested changes are complete using the smallest appropriate compile/test/check/run command and fix any change-caused failure\nValidate: final verifier passes on the latest workspace revision or a genuine external blocker is captured"
            );
        }
        return List.of(
                "Inspect the relevant implementation, configuration and dependencies identified during workspace analysis and confirm the concrete target behavior\nValidate: change surface and constraints are grounded in current workspace evidence",
                "Implement the requested changes across the affected files as one coherent change set while preserving unrelated behavior\nValidate: inspect the current diff/evidence and confirm the requested implementation is complete; defer compile/test/execution",
                "Review the complete changed workspace for omissions, integration mismatches or unintended edits and correct them before verification\nValidate: final diff matches the requested scope and project conventions",
                "Perform final project verification only after the coherent changes are complete, choosing compile/test/check/run commands from the project and user request; diagnose and fix any change-caused failure\nValidate: appropriate final verifier(s) pass on the latest workspace revision or a genuine external blocker is captured"
        );
    }

    private List<String> createExecutionPlan(String apiKey, ChatRequest request,
                                                     List<Map<String,Object>> messages,
                                                     AgentWorkspaceService.Workspace ws,
                                                     AgentRunService.AgentRun run,
                                                     Consumer<Map<String,Object>> onStep) throws Exception {
        String task = latestUserTask(messages);
        TaskProfile taskProfile = classifyTask(task);
        run.updateProgress(9, "indexing", "Collecting live repository evidence for the Agent model");
        String evidence = collectPlanningEvidence(ws, task, apiKey, request.settings(), run);
        taskProfile = refineTaskProfile(taskProfile, evidence);
        run.configureLargeTask(taskProfile.largeTask(), taskProfile.batchSize());
        onStep.accept(stepEvent(0, "task_profile", "Task profile: " + taskProfile.level() + " · target plan " + taskProfile.minSteps() + "-" + taskProfile.maxSteps() + " steps" +
                (taskProfile.largeTask() ? " · durable batching enabled (" + taskProfile.batchSize() + " items/batch)" : ""), "success", null, taskProfile.guidance(), null));
        if (run.largeTaskMode() && !run.workItemsText("", 0, 1).startsWith("[No matching")) {
            evidence += "\n\nRESUMED LARGE-TASK STATE\n" + run.workItemsText("", 0, 40);
        }
        onStep.accept(stepEvent(0, "plan_analysis", "Live workspace evidence prepared for the selected Agent model",
                "success", null, clipUi(evidence), null));

        // One-model harness: the same user-selected Agent model analyses evidence and creates the plan in a single call.
        // This removes cross-model disagreement and two extra LLM round trips while preserving deterministic plan checks.
        run.updateProgress(11, "planning", "Selected Agent model is analysing evidence and building the execution plan");
        List<String> fallback = fallbackPlan(taskProfile);
        String feedback = "";
        try {
            for (int attempt = 0; attempt < 2; attempt++) {
                List<String> plan = generateExecutionPlan(apiKey, request, run, task, evidence,
                        "Analyse the supplied live workspace evidence yourself before finalising the plan. Facts in the evidence are authoritative; unknown facts must be inspected during execution.",
                        feedback, taskProfile, onStep);
                if (plan.size() < taskProfile.minSteps() || plan.size() > taskProfile.maxSteps()) {
                    feedback = "Keep the plan within " + taskProfile.minSteps() + "-" + taskProfile.maxSteps() + " executable steps without padding.";
                    continue;
                }
                boolean hasValidation = plan.stream().allMatch(item -> item != null && item.toLowerCase(Locale.ROOT).contains("validate:"));
                boolean hasFinalVerification = !plan.isEmpty() && looksFinalVerificationPlanStep(plan.get(plan.size() - 1));
                if ((!hasValidation || !hasFinalVerification) && attempt == 0) {
                    feedback = !hasValidation
                            ? "Every plan step must include an explicit Validate: proof/check. Return corrected structured JSON only."
                            : "The LAST plan step must be a dedicated final verification step using compile/test/check/run after all implementation changes. Do not compile/test after each implementation step. Return corrected structured JSON only.";
                    continue;
                }
                if (!hasValidation || !hasFinalVerification) {
                    run.setPlanValidation("fallback", "Planner did not produce explicit per-step validation evidence plus a dedicated final verification step.");
                    return fallback;
                }
                if (taskProfile.largeTask() && attempt == 0) {
                    PlanValidation validation = validateExecutionPlan(apiKey, request, run, task, evidence,
                            "Large-task mode requires complete inventory, bounded batches, durable work-item tracking, targeted failure recovery, and final verification.",
                            plan, onStep);
                    if (!validation.approved()) {
                        feedback = "Large-task validator: " + validation.summary() +
                                ". Preserve the user's scope, but explicitly cover inventory/ledger, bounded batching, batch structural validation, failed-item recovery, and final full verification.";
                        continue;
                    }
                    run.setPlanValidation("approved", "Large-task plan passed deterministic checks and one independent same-model validation pass: " + validation.summary());
                } else {
                    run.setPlanValidation("approved", "Single-model plan passed deterministic structure, range and final-verification checks.");
                }
                onStep.accept(stepEvent(0, "plan_validation", "Plan checks passed",
                        "success", null, taskProfile.largeTask()
                                ? "Large-task plan validated for inventory, batching, failure recovery and final verification."
                                : "Evidence-grounded structured plan with explicit validation evidence and a final verification phase.", null));
                return plan;
            }
        } catch (AgentCancelledException cancelled) {
            throw cancelled;
        } catch (ProviderModelException providerFailure) {
            throw providerFailure;
        } catch (Exception e) {
            String failureDetail = providerFailureDetail(e);
            run.setPlanValidation("fallback", failureDetail);
            onStep.accept(stepEvent(0, "plan_recovery", "Planner output was unusable; using the deterministic evidence-safe fallback plan",
                    "success", null, clipUi(failureDetail), null));
        }
        run.setPlanValidation("fallback", "Structured planning checks did not pass after one corrective retry.");
        return fallback;
    }

    /** Separate read-only analysis role: synthesizes workspace evidence before the planning model sees it. */
    private String analysePlanningEvidence(String apiKey, ChatRequest request, AgentRunService.AgentRun run,
                                           String task, String evidence, Consumer<Map<String,Object>> onStep) {
        String model = request.settings().analysisModelOrPrimary();
        run.updateProgress(10, "analysing", "Analysing architecture, constraints and likely change surface");
        try {
            List<Map<String,Object>> prompt = new ArrayList<>();
            prompt.add(Map.of("role", "system", "content", """
                    You are the READ-ONLY analysis stage of a coding-agent harness. Do not propose edits yet and do not call tools.
                    From the supplied repository evidence, identify: the concrete request, relevant architecture/code areas, constraints,
                    likely dependencies, risks, and the smallest verification strategy. Distinguish facts from assumptions. Never invent files,
                    classes, failures or commands not supported by the evidence. Return a concise analysis that a separate planner can use.
                    """));
            prompt.add(Map.of("role", "user", "content", "USER TASK:\n" + task + "\n\nWORKSPACE EVIDENCE:\n" + evidence));
            ContextWindowManager.ContextEstimate estimate = contextWindows.estimate(prompt, List.of(), request.settings(), model);
            run.recordContextEstimate(estimate.estimatedInputTokens(), estimate.contextWindowTokens());
            int maxOut = request.settings().safeMaxTokens() > 0 ? Math.min(2_400, request.settings().safeMaxTokens()) : 2_400;
            onStep.accept(stepEvent(0, "model_route", "Analysis model: " + model, "success", null, null, null));
            OpenAiCompatibleClient.AgentCompletion completion = completeRoleText(
                    apiKey, request, run, model, ModelCapabilityRegistry.Role.ANALYSIS, maxOut, prompt, 0, onStep, "analysis");
            run.recordModelUsage(completion.usage(), estimate.estimatedInputTokens());
            String value = completion.content() == null ? "" : completion.content().strip();
            if (!value.isBlank()) {
                onStep.accept(stepEvent(0, "analysis", "Independent workspace analysis complete", "success", null, clipUi(value), null));
                return value;
            }
        } catch (AgentCancelledException cancelled) {
            throw cancelled;
        } catch (Exception e) {
            onStep.accept(stepEvent(0, "analysis", "Analysis model unavailable; planner will use raw workspace evidence", "running", null, clipUi(providerFailureDetail(e)), null));
        }
        return "Use the raw workspace evidence directly. Treat unsupported assumptions as unknown and verify them during execution.";
    }

    private List<String> generateExecutionPlan(String apiKey, ChatRequest request, AgentRunService.AgentRun run,
                                                String task, String evidence, String analysis, String validatorFeedback, TaskProfile taskProfile,
                                                Consumer<Map<String,Object>> onStep) throws Exception {
        List<Map<String,Object>> planning = new ArrayList<>();
        planning.add(Map.of("role", "system", "content", """
                You are the planning phase of the SAME coding-agent model that will execute this task. First analyse the supplied live workspace evidence silently, then build a sequential execution plan grounded in that evidence. Do not merely paraphrase the user's prompt.
                Every step must define a concrete outcome and its validation evidence. For implementation steps, validation means workspace evidence
                such as targeted reads, tool results or diff review; do NOT compile/test/run after every edit or step. Batch all coherent requested changes first.
                The LAST plan step must be a dedicated final verification phase that chooses the appropriate compile/test/check/run command from the project
                and the user's request, and fixes any change-caused verification failure before completion. Intermediate execution is allowed only when the user
                explicitly requested it or a concrete blocker cannot be diagnosed without it. Do not invent files or failures that are not supported by evidence.
                If an exact file/method is not proven, make targeted inspection part of the step rather than guessing a name.

                Return ONLY valid JSON in this shape:
                {"plan":[{"title":"short action title","objective":"specific outcome","files":["only evidence-backed paths/classes"],
                "validation":["concrete proof/check"],"dependsOn":[1],"risk":"low|medium|high"}]}
                Produce the number of steps requested in TASK PROFILE; never pad the plan just to reach a count. `files` may be empty when the exact path is not yet proven. `validation` must never be empty.
                Dependencies must reference earlier step numbers only. No Markdown, prose outside JSON, checkboxes, emoji or approval language.
                The UI renders these fields as structured plan cards while the runtime preserves a backwards-compatible text representation.
                """));
        String feedbackBlock = validatorFeedback == null || validatorFeedback.isBlank() ? "" :
                "\n\nVALIDATOR FEEDBACK FROM PREVIOUS DRAFT:\n" + validatorFeedback + "\nRevise the plan to address every valid concern.";
        planning.add(Map.of("role", "user", "content", "USER TASK:\n" + task +
                "\n\nTASK PROFILE: " + taskProfile.level() + " · " + taskProfile.minSteps() + "-" + taskProfile.maxSteps() + " steps. " + taskProfile.guidance() +
                "\n\nREAD-ONLY ANALYSIS:\n" + analysis +
                "\n\nWORKSPACE EVIDENCE:\n" + evidence + feedbackBlock));
        String plannerModel = request.settings().plannerModelOrPrimary();
        ContextWindowManager.ContextEstimate estimate = contextWindows.estimate(planning, List.of(), request.settings(), plannerModel);
        run.recordContextEstimate(estimate.estimatedInputTokens(), estimate.contextWindowTokens());
        int maxOut = request.settings().safeMaxTokens() > 0 ? Math.min(2_600, request.settings().safeMaxTokens()) : 2_600;
        onStep.accept(stepEvent(0, "model_route", "Agent model for planning: " + plannerModel, "success", null, null, null));
        OpenAiCompatibleClient.AgentCompletion completion = completeRoleText(
                apiKey, request, run, plannerModel, ModelCapabilityRegistry.Role.PLANNER, maxOut, planning, 0, onStep, "planning");
        run.recordModelUsage(completion.usage(), estimate.estimatedInputTokens());
        List<String> parsed = parsePlanItems(completion.content());
        if (parsed.size() < taskProfile.minSteps() || parsed.size() > taskProfile.maxSteps()) throw new IllegalStateException("Planner returned " + parsed.size() + " steps; expected " + taskProfile.minSteps() + "-" + taskProfile.maxSteps() + " for a " + taskProfile.level() + " task: " + clipUi(completion.content()));
        onStep.accept(stepEvent(0, "plan", "Planner produced " + parsed.size() + " executable steps", "success", null, clipUi(completion.content()), null));
        return parsed;
    }

    /** Independent validator uses a different configured role model when available and never edits the plan directly. */
    private PlanValidation validateExecutionPlan(String apiKey, ChatRequest request, AgentRunService.AgentRun run,
                                                 String task, String evidence, String analysis, List<String> plan,
                                                 Consumer<Map<String,Object>> onStep) throws Exception {
        run.updateProgress(12, "plan_validation", "Validating coverage, grounding, ordering and verification strategy");
        String validatorModel = request.settings().planValidatorModelOrPrimary();
        List<Map<String,Object>> prompt = new ArrayList<>();
        prompt.add(Map.of("role", "system", "content", """
                You are an independent PLAN VALIDATOR for a coding-agent harness. Review the proposed plan against the user's request and evidence.
                Check: evidence grounding, full request coverage, dependency/order correctness, executable steps, minimal scope, verification strategy,
                and unsupported assumptions. Do not add optional scope. Do not call tools.
                If the plan is ready, return first line `APPROVED`, then a short reason.
                If the plan is conceptually wrong or incomplete, return first line `REVISE`, then concise actionable feedback only.
                If the plan may be correct but exact workspace facts are missing (for example an unconfirmed file, class, public method,
                method signature, configuration key or command), return first line `NEEDS_EVIDENCE`, then state exactly what must be
                inspected/confirmed. Prefer NEEDS_EVIDENCE over rejecting a plan merely because the supplied excerpt omitted a verifiable fact.
                Do not rewrite the plan yourself and do not invent the missing evidence.
                """));
        prompt.add(Map.of("role", "user", "content", "USER TASK:\n" + task +
                "\n\nANALYSIS:\n" + analysis +
                "\n\nPROPOSED PLAN:\n" + numberedPlan(plan) +
                "\n\nEVIDENCE EXCERPT:\n" + clipHeadTail(evidence, 12_000, "[Evidence clipped for validation]")));
        ContextWindowManager.ContextEstimate estimate = contextWindows.estimate(prompt, List.of(), request.settings(), validatorModel);
        run.recordContextEstimate(estimate.estimatedInputTokens(), estimate.contextWindowTokens());
        int maxOut = request.settings().safeMaxTokens() > 0 ? Math.min(1_600, request.settings().safeMaxTokens()) : 1_600;
        onStep.accept(stepEvent(0, "model_route", "Plan validator: " + validatorModel, "success", null, null, null));
        OpenAiCompatibleClient.AgentCompletion completion = completeRoleText(
                apiKey, request, run, validatorModel, ModelCapabilityRegistry.Role.PLAN_VALIDATOR, maxOut, prompt, 0, onStep, "plan validation");
        run.recordModelUsage(completion.usage(), estimate.estimatedInputTokens());
        String raw = completion.content() == null ? "" : completion.content().strip();
        if (raw.isBlank()) return new PlanValidation(false, false, "Validator returned an empty response.");
        DecisionLine decision = parseDecisionLine(raw, "APPROVED", "REVISE", "NEEDS_EVIDENCE");
        String summary = decision.summary();
        if ("APPROVED".equals(decision.token())) return new PlanValidation(true, false, summary.isBlank() ? "Grounded, ordered and verifiable." : summary);
        if ("NEEDS_EVIDENCE".equals(decision.token())) return new PlanValidation(false, true, summary.isBlank() ? raw : summary);
        return new PlanValidation(false, false, summary.isBlank() ? raw : summary);
    }

    /**
     * Lightweight same-model recovery after ordinary executor steering has stalled.
     *
     * Older builds launched an analyst -> recovery planner -> recovery validator loop here. That multiplied model
     * calls and could itself fail with an empty/blocked validator response even though the approved plan and workspace
     * were still usable. Recovery now keeps the approved plan, trims stale context deterministically, re-anchors the
     * active step, and gives the currently active Agent model another focused pass. Provider/model failover is handled
     * separately by the bounded fallback layer; no secondary recovery-planning model call is used here.
     */
    private RecoveryReplanDecision attemptExecutorRecoveryReplan(String apiKey, ChatRequest request,
                                                                  List<Map<String,Object>> messages,
                                                                  AgentWorkspaceService.Workspace ws,
                                                                  AgentRunService.AgentRun run,
                                                                  Consumer<Map<String,Object>> onStep,
                                                                  int step, String failureSummary,
                                                                  String providerOrTurnDetail) {
        if (!run.planLocked() || run.activePlanIndex() <= 0 || !run.hasOpenPlanItems()) {
            return new RecoveryReplanDecision(false,
                    "No active approved plan step is available for focused recovery. Last failure: " + safe(failureSummary));
        }

        String model = effectiveModel(run, request.settings());
        if (model == null || model.isBlank()) {
            return new RecoveryReplanDecision(false, "No configured Agent model is available for focused recovery.");
        }

        // Recovery is intentionally non-terminal. A long task can stall repeatedly on unrelated files/steps, so a
        // historical counter is telemetry only. Each stall epoch gets a fresh compacted continuation plus bounded
        // live-workspace evidence and then resumes the SAME selected Agent model.
        long recoveryOrdinal = run.recoveryReplans() + 1;
        run.updateActivity("recovering", "Re-anchoring active plan step " + run.activePlanIndex() +
                " · recovery cycle " + recoveryOrdinal);
        try {
            onStep.accept(stepEvent(step, "focused_recovery",
                    "No-progress threshold reached; preserving the approved plan and refreshing the same Agent model (cycle " + recoveryOrdinal + ")",
                    "running", null, clipUi(failureSummary), null));
        } catch (Exception ignored) { }

        int steeringPruned = 0;
        int observationsPruned = 0;
        long beforeTokens = 0;
        long afterTokens = 0;
        String recoveryMaintenanceNote = "";
        try {
            steeringPruned = contextWindows.pruneSupersededRuntimeSteering(messages);
            observationsPruned = contextWindows.pruneOldToolOutputs(messages, request.settings(), true);
            ContextWindowManager.ContextEstimate before = contextWindows.estimate(messages, List.of(), request.settings(), model);
            beforeTokens = before.estimatedInputTokens();
            ContextWindowManager.CompactionResult compacted = contextWindows.compact(
                    messages, List.of(), request.settings(), run, true, null, model);
            if (compacted.compacted()) {
                run.recordCompaction(compacted.estimatedTokensSaved(), "focused-recovery " + compacted.reason());
            }
            ContextWindowManager.ContextEstimate after = contextWindows.estimate(messages, List.of(), request.settings(), model);
            afterTokens = after.estimatedInputTokens();
        } catch (AgentCancelledException cancelled) {
            throw cancelled;
        } catch (Exception maintenanceFailure) {
            // Context cleanup is an optimization. Never turn a cleanup problem into a fatal no-progress stop.
            recoveryMaintenanceNote = " Context refresh warning: " + safe(maintenanceFailure.getMessage()) + ".";
        }
        clearActiveContextCache(run);

        String recoveryEvidence = "";
        try {
            recoveryEvidence = collectRecoveryEvidence(ws, run, failureSummary, providerOrTurnDetail,
                    apiKey, request.settings());
        } catch (AgentCancelledException cancelled) {
            throw cancelled;
        } catch (Exception evidenceFailure) {
            // Fresh evidence materially improves recovery, but the executor can still continue using live tools.
            recoveryMaintenanceNote += " Evidence refresh warning: " + safe(evidenceFailure.getMessage()) + ".";
        }

        StringBuilder steering = new StringBuilder();
        steering.append("[RUNTIME_STEERING:focused-recovery]\n")
                .append("RECOVERY CYCLE ").append(recoveryOrdinal).append(" — this is NOT a terminal retry budget.\n")
                .append("Continue the EXISTING approved plan. Do not replan and do not restart completed work.\n")
                .append("ACTIVE STEP ").append(run.activePlanIndex()).append(": ").append(run.activePlanStepText()).append("\n")
                .append("The previous strategy stalled: ").append(clipHeadTail(safe(failureSummary), 900, "[failure clipped]")).append("\n")
                .append("Use the live workspace as the source of truth. Change strategy rather than repeating the prior prose/call. ")
                .append("Prefer one high-signal read/search if a fact is missing, then take the smallest concrete action that advances this step. ")
                .append("Use todo_update when the active implementation step is evidenced complete. ")
                .append("Compile/test/check/run only in the final verification step unless a concrete failure requires a targeted diagnostic command.");
        if (providerOrTurnDetail != null && !providerOrTurnDetail.isBlank()) {
            steering.append("\nLAST STALLED DETAIL: ")
                    .append(clipHeadTail(providerOrTurnDetail, 1_200, "[detail clipped]"));
        }
        if (!run.failureMemoryText().isBlank()) {
            steering.append("\nAVOID REPEATING:\n")
                    .append(clipHeadTail(run.failureMemoryText(), 1_800, "[failure memory clipped]"));
        }
        if (recoveryEvidence != null && !recoveryEvidence.isBlank()) {
            steering.append("\n\nFRESH RECOVERY EVIDENCE (bounded snapshot; live workspace remains authoritative):\n")
                    .append(clipHeadTail(recoveryEvidence, RECOVERY_EVIDENCE_MAX_CHARS, "[fresh recovery evidence clipped]"));
        }
        if (!recoveryMaintenanceNote.isBlank()) steering.append("\n").append(recoveryMaintenanceNote.strip());
        messages.add(Map.of("role", "system", "content", steering.toString()));
        // Keep only the newest focused-recovery instruction in the physical model transcript.
        steeringPruned += contextWindows.pruneSupersededRuntimeSteering(messages);

        String recoveryNote = "Focused same-plan recovery cycle " + recoveryOrdinal + " after: " +
                clipHeadTail(safe(failureSummary), 600, "[clipped]");
        run.recordRecoveryReplan(recoveryNote);
        run.setPlanValidation("approved", "Approved plan preserved during repeatable focused same-model recovery.");
        if (!run.restartModelCycle(recoveryNote)) {
            return new RecoveryReplanDecision(false, "No configured Agent model is available for focused recovery.");
        }

        String contextDetail = "Focused recovery cycle " + recoveryOrdinal + " ready on the same Agent model" +
                (beforeTokens > 0 ? "; context ~" + beforeTokens + " → ~" + afterTokens + " estimated tokens" : "") +
                (steeringPruned + observationsPruned > 0 ? "; pruned " + (steeringPruned + observationsPruned) + " stale runtime/tool message(s)" : "") +
                ". The no-progress threshold will re-anchor again if needed instead of terminating the run.";
        try {
            onStep.accept(stepEvent(step, "focused_recovery", contextDetail,
                    "success", null, clipUi(run.activePlanStepText()), null));
        } catch (Exception ignored) { }
        return new RecoveryReplanDecision(true, contextDetail);
    }

    private String collectRecoveryEvidence(AgentWorkspaceService.Workspace ws, AgentRunService.AgentRun run,
                                           String failureSummary, String providerOrTurnDetail,
                                           String apiKey, ChatSettings settings) {
        StringBuilder out = new StringBuilder();
        out.append("ORIGINAL OBJECTIVE:\n").append(run.objective()).append("\n\n");
        out.append("APPROVED PLAN / CURRENT STATE:\n").append(run.planText()).append("\n\n");
        out.append("ACTIVE STEP: ").append(run.activePlanIndex()).append(" — ").append(run.activePlanStepText()).append("\n");
        out.append("FAILURE SUMMARY: ").append(safe(failureSummary)).append("\n");
        if (!run.failureMemoryText().isBlank()) {
            out.append("FAILED APPROACHES/OUTCOMES TO AVOID REPEATING:\n")
                    .append(clipHeadTail(run.failureMemoryText(), 5_000, "[Failure memory clipped]")).append("\n");
        }
        if (providerOrTurnDetail != null && !providerOrTurnDetail.isBlank()) {
            out.append("LAST MODEL/TOOL DETAIL:\n")
                    .append(clipHeadTail(providerOrTurnDetail, 8_000, "[Last failure detail clipped]")).append("\n");
        }
        if (!run.lastVerification().isBlank()) {
            out.append("LAST VERIFICATION:\n")
                    .append(clipHeadTail(run.lastVerification(), 6_000, "[Verification detail clipped]")).append("\n");
        }
        appendPlanningEvidence(out, "Current workspace status", () -> workspaces.workspaceStatus(ws), 6_000);
        appendPlanningEvidence(out, "Current workspace diff", () -> workspaces.workspaceDiff(ws, ""), 16_000);
        String query = (run.objective() + " " + run.activePlanStepText() + " " + safe(failureSummary)).strip();
        String hints = workspaceRetrieval.retrieveHybrid(ws, query, 10, 12_000, apiKey, settings, run::cancelled);
        if (!hints.isBlank()) out.append("\n\n## Recovery retrieval hints\n")
                .append(clipHeadTail(hints, 12_000, "[Recovery retrieval hints clipped]"));
        return clipHeadTail(out.toString(), 46_000, "[Recovery evidence clipped; live workspace remains authoritative]");
    }

    private boolean looksLikeEvidenceRequest(String feedback) {
        if (feedback == null || feedback.isBlank()) return false;
        String low = feedback.toLowerCase(Locale.ROOT);
        boolean asksToInspect = low.contains("inspect") || low.contains("read ") || low.contains("confirm") ||
                low.contains("identify the exact") || low.contains("verify the exact") || low.contains("before proceeding");
        boolean namesEvidence = low.contains("method") || low.contains("signature") || low.contains("class") ||
                low.contains("file") || low.contains("path") || low.contains("configuration") || low.contains("public api") ||
                low.contains("overload") || low.contains("parameter");
        return asksToInspect && namesEvidence;
    }

    /**
     * Read-only evidence acquisition used when a plan validator says the route depends on an exact workspace fact
     * that was not present in the bounded planning excerpt. This closes the validator -> inspection -> replan loop
     * instead of treating a request such as "inspect LlmClient and confirm the real method signatures" as terminal.
     */
    private String collectValidatorRequestedEvidence(AgentWorkspaceService.Workspace ws, String request,
                                                     String apiKey, ChatSettings settings,
                                                     AgentRunService.AgentRun run) {
        if (ws == null || request == null || request.isBlank()) return "";
        StringBuilder out = new StringBuilder("VALIDATOR-REQUESTED READ-ONLY WORKSPACE EVIDENCE\nRequest: ")
                .append(clipHeadTail(request, 3_000, "[validator request clipped]")).append('\n');

        try {
            String retrieval = workspaceRetrieval.retrieveHybrid(ws, request, 12, 14_000, apiKey, settings, run::cancelled);
            if (!retrieval.isBlank()) out.append("\n## Retrieval hints\n").append(retrieval);
        } catch (Exception ignored) { }

        LinkedHashSet<String> terms = new LinkedHashSet<>();
        java.util.regex.Matcher fileMatcher = java.util.regex.Pattern.compile(
                "(?i)\\b([A-Za-z_][A-Za-z0-9_.-]*\\.(?:java|kt|kts|groovy|scala|js|jsx|ts|tsx|py|rb|go|rs|cs|xml|json|ya?ml|properties|gradle|md))\\b")
                .matcher(request);
        while (fileMatcher.find() && terms.size() < 12) terms.add(fileMatcher.group(1));
        java.util.regex.Matcher classMatcher = java.util.regex.Pattern.compile("\\b([A-Z][A-Za-z0-9_]{3,})\\b").matcher(request);
        while (classMatcher.find() && terms.size() < 12) terms.add(classMatcher.group(1));
        java.util.regex.Matcher methodMatcher = java.util.regex.Pattern.compile("\\b([a-zA-Z_][A-Za-z0-9_]{2,})\\s*\\(").matcher(request);
        Set<String> generic = Set.of("inspect", "confirm", "before", "after", "return", "public", "private", "protected",
                "method", "methods", "signature", "signatures", "validation", "completion", "current", "specific", "without");
        while (methodMatcher.find() && terms.size() < 14) {
            String term = methodMatcher.group(1);
            if (!generic.contains(term.toLowerCase(Locale.ROOT))) terms.add(term);
        }

        LinkedHashMap<String,Integer> ranges = new LinkedHashMap<>();
        for (String term : terms) {
            if (term == null || term.isBlank()) continue;
            try {
                String search = workspaces.search(ws, term, 10);
                if (!search.startsWith("[No matches")) {
                    int safeHitsBefore = ranges.size();
                    java.util.regex.Matcher hit = java.util.regex.Pattern.compile("(?m)^---\\s+(.+?):(\\d+)\\s+---$").matcher(search);
                    while (hit.find() && ranges.size() < 8) {
                        String path = hit.group(1).trim();
                        int line;
                        try { line = Integer.parseInt(hit.group(2)); } catch (Exception ignored) { continue; }
                        if (safeValidatorEvidencePath(path)) ranges.putIfAbsent(path + "@" + line, line);
                    }
                    int added = ranges.size() - safeHitsBefore;
                    if (added > 0) out.append("\n\n## Search: ").append(term).append(" — ").append(added).append(" safe source location(s) selected");
                }
            } catch (Exception ignored) { }

            if (term.indexOf('.') < 0 && Character.isUpperCase(term.charAt(0))) {
                try {
                    String matches = workspaces.glob(ws, "**/*" + term + "*", 6);
                    if (!matches.startsWith("[No files")) {
                        List<String> safeMatches = new ArrayList<>();
                        for (String path : matches.split("\\R")) {
                            String value = path.trim();
                            if (safeValidatorEvidencePath(value)) {
                                safeMatches.add(value);
                                ranges.putIfAbsent(value + "@1", 1);
                            }
                            if (ranges.size() >= 8) break;
                        }
                        if (!safeMatches.isEmpty()) out.append("\n\n## Path matches: ").append(term).append('\n').append(String.join("\n", safeMatches));
                    }
                } catch (Exception ignored) { }
            }
        }

        int reads = 0;
        for (Map.Entry<String,Integer> entry : ranges.entrySet()) {
            if (reads >= 6) break;
            String key = entry.getKey();
            int at = key.lastIndexOf('@');
            String path = at > 0 ? key.substring(0, at) : key;
            int line = entry.getValue();
            try {
                String excerpt = workspaces.readFileRange(ws, path, Math.max(1, line - 35), line + 80);
                out.append("\n\n## Authoritative file excerpt: ").append(path).append('\n')
                        .append(clipHeadTail(excerpt, 7_000, "[file excerpt clipped]"));
                reads++;
            } catch (Exception ignored) { }
        }

        return clipHeadTail(out.toString(), 30_000, "[Validator-requested evidence clipped; live workspace remains authoritative]");
    }

    private boolean safeValidatorEvidencePath(String rawPath) {
        if (rawPath == null || rawPath.isBlank()) return false;
        String p = rawPath.replace('\\','/').toLowerCase(Locale.ROOT);
        String name = p.substring(p.lastIndexOf('/') + 1);
        if (name.equals(".env") || name.startsWith(".env.") || name.endsWith(".pem") || name.endsWith(".key") ||
                name.endsWith(".p12") || name.endsWith(".pfx") || name.endsWith(".jks") || name.contains("credential") ||
                name.contains("secret")) return false;
        return true;
    }

    private String analyseRecoveryFailure(String apiKey, ChatRequest request, AgentRunService.AgentRun run,
                                          String evidence, int step, Consumer<Map<String,Object>> onStep) throws Exception {
        String model = request.settings().analysisModelOrPrimary();
        List<Map<String,Object>> prompt = new ArrayList<>();
        prompt.add(Map.of("role", "system", "content", """
                You are the RECOVERY ANALYST in a coding-agent harness. Every configured executor model has already failed
                or made no actionable progress on the current approved step. Diagnose the reason from CURRENT workspace state,
                diff, verification output and failure evidence. Never invent files or results. Distinguish an implementation/
                strategy failure from a genuine external blocker such as missing permission, unavailable required infrastructure,
                invalid credentials, or a provider/service outage that no code change can solve.

                First line must be exactly one of:
                RECOVERABLE
                BLOCKED_EXTERNAL

                Then provide a concise diagnosis, what assumptions/approaches should change, what existing edits must be preserved,
                and the concrete evidence the replanner should use. Do not write the new plan yourself and do not call tools.
                """));
        prompt.add(Map.of("role", "user", "content", evidence));
        ContextWindowManager.ContextEstimate estimate = contextWindows.estimate(prompt, List.of(), request.settings(), model);
        run.recordContextEstimate(estimate.estimatedInputTokens(), estimate.contextWindowTokens());
        int maxOut = request.settings().safeMaxTokens() > 0 ? Math.min(2_200, request.settings().safeMaxTokens()) : 2_200;
        onStep.accept(stepEvent(step, "model_route", "Recovery analysis model: " + model, "success", null, null, null));
        OpenAiCompatibleClient.AgentCompletion completion = completeRoleText(
                apiKey, request, run, model, ModelCapabilityRegistry.Role.ANALYSIS, maxOut, prompt, step, onStep, "recovery analysis");
        run.recordModelUsage(completion.usage(), estimate.estimatedInputTokens());
        String value = completion.content() == null ? "" : completion.content().strip();
        if (value.isBlank()) throw new IllegalStateException("Recovery analyst returned an empty response");
        onStep.accept(stepEvent(step, "recovery_analysis", "Recovery diagnosis complete", "success", null, clipUi(value), null));
        return value;
    }

    private List<String> generateRecoveryPlan(String apiKey, ChatRequest request, AgentRunService.AgentRun run,
                                              String evidence, String diagnosis, String validatorFeedback,
                                              int step, Consumer<Map<String,Object>> onStep) throws Exception {
        String model = request.settings().plannerModelOrPrimary();
        List<Map<String,Object>> prompt = new ArrayList<>();
        prompt.add(Map.of("role", "system", "content", """
                You are the RECOVERY PLANNER for a coding-agent harness. Completed plan steps are immutable and the live workspace
                may already contain valid partial edits. Replace ONLY the unfinished work with the shortest evidence-grounded route
                that can satisfy the original objective. Preserve valid current edits; do not restart completed work. The first
                recovery step must directly address the diagnosed failure/incorrect assumption. Include targeted verification where
                code/config changes are involved. Do not invent files, commands or failures.

                Return ONLY valid JSON using the same structured plan schema:
                {"plan":[{"title":"short action title","objective":"specific remaining outcome","files":["evidence-backed paths/classes"],
                "validation":["concrete proof/check"],"dependsOn":[],"risk":"low|medium|high"}]}
                Produce 1-8 remaining steps. `files` may be empty when exact paths are still intentionally discovered by the step.
                `validation` must never be empty. No Markdown or prose outside the JSON.
                """));
        String feedback = validatorFeedback == null || validatorFeedback.isBlank() ? "" :
                "\n\nVALIDATOR FEEDBACK FROM PREVIOUS RECOVERY DRAFT:\n" + validatorFeedback + "\nAddress every valid concern.";
        prompt.add(Map.of("role", "user", "content", "RECOVERY DIAGNOSIS:\n" + diagnosis +
                "\n\nCURRENT EVIDENCE:\n" + evidence + feedback));
        ContextWindowManager.ContextEstimate estimate = contextWindows.estimate(prompt, List.of(), request.settings(), model);
        run.recordContextEstimate(estimate.estimatedInputTokens(), estimate.contextWindowTokens());
        int maxOut = request.settings().safeMaxTokens() > 0 ? Math.min(2_200, request.settings().safeMaxTokens()) : 2_200;
        onStep.accept(stepEvent(step, "model_route", "Recovery planning model: " + model, "success", null, null, null));
        OpenAiCompatibleClient.AgentCompletion completion = completeRoleText(
                apiKey, request, run, model, ModelCapabilityRegistry.Role.PLANNER, maxOut, prompt, step, onStep, "recovery planning");
        run.recordModelUsage(completion.usage(), estimate.estimatedInputTokens());
        List<String> parsed = parsePlanItems(completion.content());
        if (parsed.isEmpty()) throw new IllegalStateException("Recovery planner response contained no executable steps");
        onStep.accept(stepEvent(step, "recovery_plan", "Recovery planner produced " + parsed.size() + " remaining step" +
                (parsed.size() == 1 ? "" : "s"), "success", null, numberedPlan(parsed), null));
        return parsed;
    }

    private PlanValidation validateRecoveryPlan(String apiKey, ChatRequest request, AgentRunService.AgentRun run,
                                                String evidence, String diagnosis, List<String> plan,
                                                int step, Consumer<Map<String,Object>> onStep) throws Exception {
        String model = request.settings().planValidatorModelOrPrimary();
        List<Map<String,Object>> prompt = new ArrayList<>();
        prompt.add(Map.of("role", "system", "content", """
                You are an independent RECOVERY PLAN VALIDATOR. The original executor pool failed, so be strict.
                Check that the proposed remaining-work plan: addresses the diagnosed cause rather than repeating the failed strategy;
                preserves completed work and valid current edits; contains no unsupported assumptions; is executable with available
                workspace/tool evidence; includes enough verification; and still covers the unfinished part of the user's objective.
                Return first line `APPROVED`, `REVISE`, or `NEEDS_EVIDENCE`, followed by a short reason/actionable feedback.
                Use NEEDS_EVIDENCE when the recovery route depends on a concrete workspace fact that can be verified read-only (for example
                exact file/class/method/signature/configuration names). State exactly what must be inspected. Do not rewrite the plan and do not
                reject a recoverable route merely because the current evidence excerpt omitted a fact that the runtime can fetch.
                """));
        prompt.add(Map.of("role", "user", "content", "RECOVERY DIAGNOSIS:\n" + diagnosis +
                "\n\nPROPOSED REMAINING PLAN:\n" + numberedPlan(plan) +
                "\n\nCURRENT EVIDENCE:\n" + clipHeadTail(evidence, 18_000, "[Recovery evidence clipped for validation]")));
        ContextWindowManager.ContextEstimate estimate = contextWindows.estimate(prompt, List.of(), request.settings(), model);
        run.recordContextEstimate(estimate.estimatedInputTokens(), estimate.contextWindowTokens());
        int maxOut = request.settings().safeMaxTokens() > 0 ? Math.min(1_500, request.settings().safeMaxTokens()) : 1_500;
        onStep.accept(stepEvent(step, "model_route", "Recovery plan validator: " + model, "success", null, null, null));
        OpenAiCompatibleClient.AgentCompletion completion = completeRoleText(
                apiKey, request, run, model, ModelCapabilityRegistry.Role.PLAN_VALIDATOR, maxOut, prompt, step, onStep, "recovery plan validation");
        run.recordModelUsage(completion.usage(), estimate.estimatedInputTokens());
        String raw = completion.content() == null ? "" : completion.content().strip();
        if (raw.isBlank()) return new PlanValidation(false, false, "Recovery validator returned an empty response.");
        DecisionLine decision = parseDecisionLine(raw, "APPROVED", "REVISE", "NEEDS_EVIDENCE");
        String summary = decision.summary();
        if ("APPROVED".equals(decision.token())) return new PlanValidation(true, false,
                summary.isBlank() ? "Recovery route is grounded, non-repetitive and verifiable." : summary);
        if ("NEEDS_EVIDENCE".equals(decision.token())) return new PlanValidation(false, true, summary.isBlank() ? raw : summary);
        return new PlanValidation(false, false, summary.isBlank() ? raw : summary);
    }

    private String recoveryReplanContinuation(AgentRunService.AgentRun run, String diagnosis) {
        return "[RUNTIME_STEERING:recovery-replan]\nRECOVERY REPLAN ACCEPTED. Every previous executor model exhausted the old strategy. " +
                "The runtime has preserved completed steps and the live workspace, replaced only unfinished work, and restarted the executor chain. " +
                "Do not redo completed steps or revert valid partial edits. Active step is " + run.activePlanIndex() + ": " + run.activePlanStepText() +
                "\nRecovery diagnosis: " + clipHeadTail(diagnosis, 1_200, "[diagnosis clipped]") +
                "\nCurrent sequential plan:\n" + run.planText();
    }

    private record RecoveryReplanDecision(boolean recovered, String reason) { }

    private String numberedPlan(List<String> plan) {
        StringBuilder out = new StringBuilder();
        for (int i = 0; i < (plan == null ? 0 : plan.size()); i++) out.append(i + 1).append(". ").append(plan.get(i)).append('\n');
        return out.toString().stripTrailing();
    }

    private record PlanValidation(boolean approved, boolean needsEvidence, String summary) { }

    private String latestUserTask(List<Map<String,Object>> messages) {
        if (messages == null) return "Complete the requested task";
        for (int i = messages.size() - 1; i >= 0; i--) {
            Map<String,Object> message = messages.get(i);
            if (!"user".equals(String.valueOf(message.getOrDefault("role", "")))) continue;
            String text = String.valueOf(message.getOrDefault("content", "")).strip();
            if (text.isBlank() || text.startsWith("TOOL RESULT for ")) continue;
            return clipHeadTail(text, 8_000, "[Older parts of the user task omitted for planning]");
        }
        return "Complete the requested task";
    }

    /** Read-only deterministic discovery performed before the planner is allowed to draft a plan. */
    private String collectPlanningEvidence(AgentWorkspaceService.Workspace ws, String task, String apiKey, ChatSettings settings, AgentRunService.AgentRun run) {
        StringBuilder out = new StringBuilder();
        appendPlanningEvidence(out, "Workspace profile", () -> workspaces.inspectWorkspace(ws), 3_500);
        appendPlanningEvidence(out, "Resolved prompt resources", () -> workspaces.resourceCatalog(ws), 2_500);
        appendPlanningEvidence(out, "Project instructions", () -> workspaces.projectInstructions(ws), 5_000);

        String files = "";
        try { files = workspaces.listFiles(ws, ""); } catch (Exception ignored) { }
        if (!files.isBlank()) {
            out.append("\n\n## File index\n").append(clipHeadTail(files, 6_000, "[File index clipped; agent can query it again during execution]"));
            Set<String> paths = new LinkedHashSet<>(Arrays.asList(files.split("\\R")));
            List<String> priority = List.of("AGENTS.md", "CLAUDE.md", "README.md", "pom.xml", "build.gradle", "build.gradle.kts",
                    "package.json", "pyproject.toml", "requirements.txt", "application.properties", "application.yml", "application.yaml");
            int read = 0;
            for (String candidate : priority) {
                String matched = paths.stream().filter(p -> p.equalsIgnoreCase(candidate) || p.toLowerCase(Locale.ROOT).endsWith("/" + candidate.toLowerCase(Locale.ROOT))).findFirst().orElse(null);
                if (matched == null) continue;
                final String path = matched;
                appendPlanningEvidence(out, "Key file: " + path, () -> workspaces.readFileRange(ws, path, 1, 180), 4_500);
                if (++read >= 3) break;
            }
        }

        String indexedHints = workspaceRetrieval.retrieveHybrid(ws, task, 7, 6_000, apiKey, settings, run::cancelled);
        if (!indexedHints.isBlank()) {
            out.append("\n\n## Local retrieval index hints\n")
                    .append(clipHeadTail(indexedHints, 6_000, "[Retrieval hints clipped]"));
        }

        LinkedHashSet<String> terms = new LinkedHashSet<>();
        Set<String> stop = Set.of("this","that","with","from","into","then","have","will","should","agent","plan","user","please","make","work","working","issue","issues","test","tests","project");
        for (String word : (task == null ? "" : task.toLowerCase(Locale.ROOT)).split("[^a-z0-9_.$/-]+")) {
            if (word.length() >= 4 && !stop.contains(word) && !word.matches("\\d+")) terms.add(word);
            if (terms.size() >= 2) break;
        }
        for (String term : terms) {
            final String query = term;
            appendPlanningEvidence(out, "Relevant matches for '" + query + "'", () -> workspaces.search(ws, query, 6), 3_000);
        }
        return clipHeadTail(out.toString(), 24_000, "[Planning evidence clipped; live workspace remains authoritative]");
    }

    private void appendPlanningEvidence(StringBuilder out, String title, PlanningEvidenceSupplier supplier, int maxChars) {
        try {
            String value = supplier.get();
            if (value == null || value.isBlank() || value.startsWith("[No ")) return;
            out.append("\n\n## ").append(title).append("\n")
                    .append(clipHeadTail(value, maxChars, "[Evidence section clipped]"));
        } catch (Exception ignored) { }
    }

    @FunctionalInterface
    private interface PlanningEvidenceSupplier { String get() throws Exception; }

    private List<String> parsePlanItems(String raw) {
        if (raw == null || raw.isBlank()) return List.of();
        LinkedHashSet<String> unique = new LinkedHashSet<>();
        try {
            String candidate = raw.trim();
            if (candidate.startsWith("```")) {
                int firstLine = candidate.indexOf('\n');
                if (firstLine >= 0) candidate = candidate.substring(firstLine + 1);
                int fence = candidate.lastIndexOf("```");
                if (fence >= 0) candidate = candidate.substring(0, fence).trim();
            }
            int objectStart = candidate.indexOf('{');
            int objectEnd = candidate.lastIndexOf('}');
            if (objectStart >= 0 && objectEnd > objectStart) candidate = candidate.substring(objectStart, objectEnd + 1);
            JsonNode json = objectMapper.readTree(candidate);
            JsonNode arr = json != null && json.isArray() ? json : json == null ? null : json.path("plan");
            if (arr != null && arr.isArray()) {
                for (JsonNode item : arr) {
                    String text = item.isTextual() ? item.asText() : structuredPlanItemText(item);
                    addPlanItem(unique, text);
                    if (unique.size() >= 12) break;
                }
                if (!unique.isEmpty()) return List.copyOf(unique);
            }
        } catch (Exception ignored) { }
        for (String line : raw.split("\\R")) {
            addPlanItem(unique, line);
            if (unique.size() >= 12) break;
        }
        return List.copyOf(unique);
    }

    /** Convert planner JSON into a compact, human-readable structure while keeping the existing PlanItem contract. */
    private String structuredPlanItemText(JsonNode item) {
        if (item == null || !item.isObject()) return "";
        String legacy = item.path("text").asText("").strip();
        if (!legacy.isBlank()) return legacy;
        String title = item.path("title").asText("").strip();
        String objective = item.path("objective").asText("").strip();
        if (title.isBlank() && objective.isBlank()) return "";
        StringBuilder out = new StringBuilder(title.isBlank() ? objective : title);
        if (!objective.isBlank() && !objective.equalsIgnoreCase(title)) out.append("\nObjective: ").append(objective);
        appendStructuredArray(out, "Files", item.path("files"), false);
        appendStructuredArray(out, "Validate", item.path("validation"), false);
        JsonNode deps = item.path("dependsOn");
        if (deps.isArray() && !deps.isEmpty()) {
            List<String> values = new ArrayList<>();
            for (JsonNode dep : deps) if (dep.canConvertToInt() && dep.asInt() > 0) values.add(String.valueOf(dep.asInt()));
            if (!values.isEmpty()) out.append("\nDepends on: ").append(String.join(", ", values));
        }
        String risk = item.path("risk").asText("").strip().toLowerCase(Locale.ROOT);
        if (Set.of("low", "medium", "high").contains(risk)) out.append("\nRisk: ").append(risk);
        return out.toString();
    }

    private void appendStructuredArray(StringBuilder out, String label, JsonNode node, boolean required) {
        if (node == null || !node.isArray()) return;
        List<String> values = new ArrayList<>();
        for (JsonNode value : node) {
            String text = value.asText("").strip();
            if (!text.isBlank()) values.add(text.replaceAll("\\s+", " "));
            if (values.size() >= 6) break;
        }
        if (!values.isEmpty()) out.append("\n").append(label).append(": ").append(String.join(" • ", values));
        else if (required) out.append("\n").append(label).append(": [required]");
    }

    private void addPlanItem(Set<String> out, String raw) {
        String item = cleanPlanItem(raw);
        if (item.isBlank()) return;
        String low = item.toLowerCase(Locale.ROOT);
        if (Set.of("plan", "execution plan", "steps", "todo", "pending", "completed", "done", "in progress", "in_progress").contains(low)) return;
        if (low.startsWith("here is") || low.startsWith("here's") || low.startsWith("execution plan:")) return;
        // Decoration-only lines were previously being counted as planned work. Require meaningful letters/digits
        // and enough descriptive content to be executable.
        if (!item.matches("(?s).*[\\p{L}\\p{N}].*") || item.replaceAll("[^\\p{L}\\p{N}]", "").length() < 8) return;
        out.add(item);
    }

    private String cleanPlanItem(String value) {
        if (value == null) return "";
        String item = value.strip();
        if (item.isBlank() || item.startsWith("```") || item.startsWith("~~~") || item.matches("^#{1,6}\\s+.*")) return "";
        item = item.replaceFirst("^\\d{1,2}[.)]\\s*", "");
        item = item.replaceFirst("^\\[[ xX✓✔]\\]\\s*", "");
        item = item.replaceFirst("^[\\-*•‣▪▫◦]+\\s*", "");
        // Strip common visual/status prefixes without treating the symbol itself as work.
        item = item.replaceFirst("^(?:✅|☑️?|✔️?|✓|🔲|⬜|🟩|🟢|🔹|🔸|➡️?|→|➜|➤|▶️?|⏳|🛠️?|⚙️?)\\s*", "");
        item = item.replaceFirst("^(?i:(?:step|task)\\s+\\d{1,2}\\s*[:.)-]\\s*)", "");
        item = item.replaceAll("^\\*\\*|\\*\\*$", "").strip();
        if (item.matches("^[\\p{So}\\p{Sk}\\p{Sm}\\p{Punct}\\s]+$")) return "";
        return item.length() <= 1_400 ? item : item.substring(0, 1_400);
    }

    private List<Map<String, Object>> prepareMessages(List<Map<String, Object>> baseContext,
                                                       AgentWorkspaceService.Workspace ws) {
        List<Map<String, Object>> messages = new ArrayList<>();
        boolean merged = false;
        if (baseContext != null) {
            for (Map<String, Object> message : baseContext) {
                if (!merged && "system".equals(String.valueOf(message.get("role")))) {
                    Map<String, Object> copy = new LinkedHashMap<>(message);
                    copy.put("content", String.valueOf(message.getOrDefault("content", "")) + "\n\n" + AGENT_PROTOCOL +
                            "\n\nACTIVE LIVE WORKSPACE ROOT: " + ws.root());
                    messages.add(copy);
                    merged = true;
                } else {
                    messages.add(new LinkedHashMap<>(message));
                }
            }
        }
        if (!merged) {
            messages.add(0, Map.of("role", "system", "content", AGENT_PROTOCOL +
                    "\n\nACTIVE LIVE WORKSPACE ROOT: " + ws.root()));
        }
        return messages;
    }

    private long executeNativeCalls(List<OpenAiCompatibleClient.AgentToolCall> calls,
                                    List<Map<String,Object>> messages,
                                    AgentWorkspaceService.Workspace ws,
                                    AgentRunService.AgentRun run,
                                    ChatRequest request,
                                    String apiKey,
                                    McpManager.Catalog mcpCatalog,
                                    List<Map<String,Object>> availableTools,
                                    int step,
                                    Consumer<Map<String,Object>> onStep,
                                    Map<String,Integer> repeatedCalls) {
        List<PreparedCall> prepared = new ArrayList<>();
        for (OpenAiCompatibleClient.AgentToolCall call : calls) {
            String requested = call.name() == null ? "" : call.name().trim();
            String tool = toolRegistry.canonical(requested);
            JsonNode args = normalizeLegacyArgs(requested, tool, call.arguments());
            prepared.add(new PreparedCall(call, requested, tool, args, describeTool(tool,args)));
        }
        long activity = 0;
        int i = 0;
        while (i < prepared.size()) {
            PreparedCall first = prepared.get(i);
            boolean parallel = request.settings().parallelReadTools() && canParallel(first, request.settings(), mcpCatalog);
            int end = i + 1;
            if (parallel) while (end < prepared.size() && canParallel(prepared.get(end), request.settings(), mcpCatalog)) end++;
            if (parallel && end - i > 1) {
                List<PreparedCall> group = prepared.subList(i,end);
                for (PreparedCall c : group) onStep.accept(stepEvent(step,c.tool(),c.detail(),"running",c.args(),null,null));
                List<Future<ToolExecution>> futures = new ArrayList<>();
                for (PreparedCall c : group) {
                    ToolExecution pre = preflightCall(c, mcpCatalog);
                    if (pre != null) futures.add(CompletableFuture.completedFuture(pre));
                    else futures.add(parallelReadExecutor.submit(() -> executeWithPermission(ws, run, c.tool(), c.args(), request.settings(), c.detail(), step,
                            onStep, mcpCatalog, availableTools, apiKey, request)));
                }
                for (int k=0;k<group.size();k++) {
                    PreparedCall c=group.get(k); ToolExecution e;
                    try { e=futures.get(k).get(); } catch (Exception ex) { e=new ToolExecution("TOOL ERROR: "+safe(ex.getMessage()),"error",false); }
                    e = applyRepeatOutcomeGuard(c, e, run, repeatedCalls, mcpCatalog);
                    if (e.executed()) { observeRun(ws, run,c.tool(),c.args(),e.result()); activity++; }
                    onStep.accept(stepEvent(step,c.tool(),summarizeResult(c.tool(),e.result()),e.status(),c.args(),clipUi(e.result()),null));
                    appendNativeToolResult(messages,c.call().id(),c.requestedTool(),e.result());
                }
            } else {
                PreparedCall c=first;
                int activePlanBefore = run.activePlanIndex();
                onStep.accept(stepEvent(step,c.tool(),c.detail(),"running",c.args(),null,null));
                ToolExecution e=preflightCall(c,mcpCatalog);
                if (e==null) e=executeWithPermission(ws,run,c.tool(),c.args(),request.settings(),c.detail(),step,onStep,
                        mcpCatalog,availableTools,apiKey,request);
                e=applyRepeatOutcomeGuard(c,e,run,repeatedCalls,mcpCatalog);
                if (e.executed()) { observeRun(ws, run,c.tool(),c.args(),e.result()); activity++; }
                onStep.accept(stepEvent(step,c.tool(),summarizeResult(c.tool(),e.result()),e.status(),c.args(),clipUi(e.result()),null));
                appendNativeToolResult(messages,c.call().id(),c.requestedTool(),e.result());
                int activePlanAfter = run.activePlanIndex();
                if (activePlanBefore > 0 && activePlanAfter != activePlanBefore && i + 1 < prepared.size()) {
                    for (int j = i + 1; j < prepared.size(); j++) {
                        PreparedCall deferred = prepared.get(j);
                        String deferredResult = "DEFERRED BY SEQUENTIAL PLAN GATE: step " + activePlanBefore +
                                " completed in this model turn. Later tool calls from the same response were not executed. " +
                                (activePlanAfter > 0 ? "Step " + activePlanAfter + " is now active; request this tool again only if it belongs to that step." : "All approved plan steps are complete.");
                        onStep.accept(stepEvent(step, "plan_gate", "Deferred " + deferred.tool() + " after plan-step boundary", "success", deferred.args(), null, null));
                        appendNativeToolResult(messages, deferred.call().id(), deferred.requestedTool(), deferredResult);
                    }
                    return activity;
                }
            }
            i=end;
        }
        return activity;
    }

    private ToolExecution preflightCall(PreparedCall c, McpManager.Catalog mcpCatalog) {
        if (!isKnownTool(c.requestedTool(), c.tool(), mcpCatalog)) {
            return new ToolExecution(unknownToolMessage(c.requestedTool(), mcpCatalog), "error", false);
        }
        return null;
    }

    /**
     * Result-aware loop protection. Repeating a command is allowed when it produces new evidence; only the same
     * call producing the same normalized outcome on the same workspace revision is considered a no-progress loop.
     * This preserves unlimited useful build/test/diagnostic work while stopping token-burning duplicates.
     */
    private ToolExecution applyRepeatOutcomeGuard(PreparedCall c, ToolExecution execution,
                                                  AgentRunService.AgentRun run,
                                                  Map<String,Integer> repeatedOutcomes,
                                                  McpManager.Catalog mcpCatalog) {
        if (execution == null) return new ToolExecution("TOOL ERROR: empty execution result", "error", false);
        boolean eligible = !execution.executed() || isRepeatGuardEligible(c.tool(), c.args(), mcpCatalog) ||
                (isMutationTool(c.tool()) && explicitlyNoWorkspaceChange(execution.result()));
        if (!eligible) return execution;

        String outcome = normalizeToolOutcome(execution.result());
        String fingerprint = c.tool() + "|args=" + Integer.toHexString(canonicalArgs(c.args()).hashCode()) +
                "|revision=" + run.mutationRevision() + "|status=" + execution.status() +
                "|outcome=" + Integer.toHexString(outcome.hashCode());
        if (repeatedOutcomes.size() > 8_000) repeatedOutcomes.clear();
        int count = repeatedOutcomes.merge(fingerprint, 1, Integer::sum);
        int limit = Set.of("process_status", "process_output").contains(c.tool()) ? 4 : 3;
        if (count == limit - 1) {
            return new ToolExecution(execution.result() +
                    "\n\nDOOM LOOP WARNING: this exact tool call is producing the same outcome repeatedly on the same workspace revision. " +
                    "Do not repeat it unchanged again; inspect different evidence, wait only when the process genuinely needs time, modify the workspace, or change strategy.",
                    execution.status(), execution.executed());
        }
        if (count >= limit) {
            run.markRepeatedCallPrevented();
            return new ToolExecution("REPEATED TOOL CALL SUPPRESSED: this exact call has already produced the same result repeatedly on workspace revision " +
                    run.mutationRevision() + ". Choose a different tool, arguments, path, command, or re-read current state before retrying. " +
                    "The last real result was:\n" + execution.result(), "error", false);
        }
        return execution;
    }

    private String normalizeToolOutcome(String result) {
        if (result == null || result.isBlank()) return "<blank>";
        String normalized = result.toLowerCase(Locale.ROOT).replaceAll("\\s+", " ").trim();
        if (normalized.length() <= 6_000) return normalized;
        return normalized.substring(0, 4_000) + "|tail|" + normalized.substring(normalized.length() - 2_000);
    }

    private ToolExecution applyChildRepeatOutcomeGuard(PreparedCall c, ToolExecution execution,
                                                       AgentRunService.AgentRun parentRun,
                                                       Map<String,Integer> repeatedOutcomes,
                                                       McpManager.Catalog mcpCatalog) {
        if (execution == null) return new ToolExecution("TOOL ERROR: empty execution result", "error", false);
        boolean eligible = !execution.executed() || isRepeatGuardEligible(c.tool(), c.args(), mcpCatalog) ||
                (isMutationTool(c.tool()) && explicitlyNoWorkspaceChange(execution.result()));
        if (!eligible) return execution;
        String outcome = normalizeToolOutcome(execution.result());
        String fingerprint = c.tool() + "|args=" + Integer.toHexString(canonicalArgs(c.args()).hashCode()) +
                "|revision=" + parentRun.mutationRevision() + "|status=" + execution.status() +
                "|outcome=" + Integer.toHexString(outcome.hashCode());
        if (repeatedOutcomes.size() > 2_000) repeatedOutcomes.clear();
        int count = repeatedOutcomes.merge(fingerprint, 1, Integer::sum);
        int limit = Set.of("process_status", "process_output").contains(c.tool()) ? 4 : 3;
        if (count == limit - 1) {
            return new ToolExecution(execution.result() +
                    "\n\nSUBAGENT LOOP WARNING: this exact call is producing the same outcome repeatedly. Change strategy instead of repeating it.",
                    execution.status(), execution.executed());
        }
        if (count >= limit) {
            parentRun.markRepeatedCallPrevented();
            return new ToolExecution("SUBAGENT REPEATED CALL SUPPRESSED: the same tool call produced the same result repeatedly without workspace progress. " +
                    "Choose a different investigation strategy. Last result:\n" + execution.result(),
                    "error", false);
        }
        return execution;
    }

    private boolean isRepeatGuardEligible(String tool, JsonNode args, McpManager.Catalog catalog) {
        if ("todoread".equals(tool)) return false;
        if (Set.of("process_status","process_output","workspace_status","workspace_diff").contains(tool)) return true;
        if (Set.of("build","test","check","resource_build","resource_test","resource_check").contains(tool)) return true;
        if (Set.of("bash","resource_bash","http_request").contains(tool) && args != null && args.path("verification").asBoolean(false)) return true;
        return toolRegistry.isParallelReadOnly(tool) || mcp.isReadOnly(catalog,tool);
    }

    private boolean isMutationTool(String tool) {
        return Set.of("edit", "write", "copy", "move", "delete", "apply_patch", "workspace_rollback",
                "resource_edit", "resource_write", "resource_delete", "resource_copy", "resource_move").contains(tool);
    }

    private boolean explicitlyNoWorkspaceChange(String result) {
        return result != null && (result.startsWith("workspaceChanged=false;") || result.startsWith("resourceChanged=false;"));
    }

    private boolean directMutationChanged(String result) {
        // New mutation tools report the marker explicitly. Keep the fallback true for compatibility with custom/older tools.
        return result == null || !explicitlyNoWorkspaceChange(result);
    }

    private boolean canParallel(PreparedCall c, ChatSettings settings, McpManager.Catalog catalog) {
        if (!isKnownTool(c.requestedTool(),c.tool(),catalog)) return false;
        boolean readOnly=toolRegistry.isParallelReadOnly(c.tool()) || mcp.isReadOnly(catalog,c.tool());
        if (!readOnly) return false;
        String p=permissionFor(c.tool(),settings);
        return "allow".equals(p) || ("ask".equals(p) && settings.autoApproveAgent());
    }

    private boolean isKnownTool(String requested, String canonical, McpManager.Catalog catalog) {
        return toolRegistry.isKnownBuiltIn(requested) || toolRegistry.isKnownBuiltIn(canonical) || mcp.isMcpTool(catalog,canonical) || mcp.isMcpTool(catalog,requested);
    }

    private String unknownToolMessage(String requested, McpManager.Catalog catalog) {
        LinkedHashSet<String> names=new LinkedHashSet<>(toolRegistry.names());
        if (catalog!=null) names.addAll(catalog.byFunction().keySet());
        String repaired = toolRegistry.canonical(requested);
        String hint = repaired != null && !repaired.isBlank() && !Objects.equals(repaired, requested)
                ? " The runtime interpreted the closest canonical name as '" + repaired + "'." : "";
        return "TOOL ERROR: unknown tool '" + requested + "'." + hint +
                " Use exact built-in names (grep searches text; glob matches paths; tool_search discovers deferred MCP tools). Available tools: " +
                String.join(", ", names);
    }

    private String runSubagent(AgentWorkspaceService.Workspace ws, AgentRunService.AgentRun parentRun,
                               ChatRequest request, String apiKey, McpManager.Catalog mcpCatalog,
                               List<Map<String,Object>> availableTools, String agentId, String prompt,
                               int parentStep, Consumer<Map<String,Object>> onStep) throws Exception {
        AgentProfileService.AgentProfile profile=agentProfiles.require(ws,agentId);
        List<Map<String,Object>> childTools=new CopyOnWriteArrayList<>(toolRegistry.filterDefinitions(availableTools,profile.allowedTools(),true));
        Set<String> childNames=new HashSet<>(); for(Map<String,Object>d:childTools) childNames.add(toolRegistry.functionName(d));
        // Subagents use the same ordered model pool as the parent run and preserve parent run state across failover.
        String model=effectiveModel(parentRun, request.settings());
        List<Map<String,Object>> child=new ArrayList<>();
        child.add(Map.of("role","system","content",profile.systemPrompt()+"\n\nACTIVE LIVE WORKSPACE ROOT: "+ws.root()+
                "\n\n"+workspaceProfiles.profileText(ws)+"\n\n"+workspaces.projectInstructions(ws)+
                "\n\nPrompt-resolved resources:\n"+workspaces.resourceCatalog(ws)+
                "\n\nAvailable skills:\n"+workspaces.availableSkills(ws)+
                "\n\nYou are a child session. Do not invoke another subagent. Use real tools and return a concise evidence-based report to the parent."));
        child.add(Map.of("role","user","content",prompt));
        long toolActivity=0; int childTurn=0;
        boolean childOverflowRecovered = false;
        int emptyChildTurns = 0;
        int childTransientFailures = 0;
        int childModelActivations = 1;
        final int maxChildModelActivations = providerRecoveryActivationLimit(parentRun);
        Map<String,Integer> childRepeatedOutcomes = new HashMap<>();
        while(true){
            childTurn++; parentRun.checkCancelled();
            model=effectiveModel(parentRun, request.settings());
            prepareActiveContext(apiKey, request, model, child, childTools, request.settings(), ws, parentRun, parentStep, onStep, false);
            ContextWindowManager.ContextEstimate childEstimate = contextWindows.estimate(child, childTools, request.settings());
            parentRun.recordContextEstimate(childEstimate.estimatedInputTokens(), childEstimate.contextWindowTokens());
            OpenAiCompatibleClient.AgentCompletion turn;
            try {
                turn=llm.completeAgent(apiKey,request.settings().baseUrl(),model,request.settings().safeMaxTokens(),child,childTools,false,parentRun::cancelled);
                parentRun.recordModelUsage(turn.usage(), childEstimate.estimatedInputTokens());
            } catch(Exception e){
                if(isContextWindowFailure(e) && !childOverflowRecovered){
                    ContextWindowManager.CompactionResult compacted = contextWindows.compact(child, childTools, request.settings(), parentRun, true,
                            null, model);
                    childOverflowRecovered = true;
                    if(compacted.compacted()){
                        parentRun.recordCompaction(compacted.estimatedTokensSaved(), "subagent:"+agentId+" "+compacted.reason());
                        onStep.accept(stepEvent(parentStep,"context_compaction","Subagent "+agentId+": provider overflow recovered: "+formatCompaction(compacted),"success",null,null,null));
                        continue;
                    }
                }
                String childError = providerFailureDetail(e);
                if (!isAuthenticationFailure(e) && childTransientFailures < PROVIDER_RETRIES_PER_MODEL_ACTIVATION) {
                    childTransientFailures++;
                    onStep.accept(stepEvent(parentStep, "model_retry",
                            "Subagent " + agentId + ": retrying " + model + " (retry " + childTransientFailures + "/" + PROVIDER_RETRIES_PER_MODEL_ACTIVATION + ")",
                            "running", null, clipUi(childError), null));
                    sleepCancellable(parentRun, providerRetryDelayMs(childTransientFailures));
                    continue;
                }
                if (!isAuthenticationFailure(e) && childModelActivations < maxChildModelActivations &&
                        switchToNextModelCyclic(parentRun, onStep, parentStep, "Subagent " + agentId + ": " + childError)) {
                    childModelActivations++;
                    childTransientFailures = 0;
                    childOverflowRecovered = false;
                    child.add(Map.of("role", "system", "content", modelFailoverContinuation(parentRun)));
                    continue;
                }
                return "SUBAGENT " + agentId + " BLOCKED\nProvider/model recovery exhausted: " + childError + "\n\nchildToolActions=" + toolActivity;
            }
            childOverflowRecovered = false;
            childTransientFailures = 0;
            String raw=turn.content()==null?"":turn.content().trim();
            if(turn.hasToolCall()){
                emptyChildTurns = 0;
                appendNativeAssistantTurn(child,turn.toolCalls(),raw);
                for(OpenAiCompatibleClient.AgentToolCall call:turn.toolCalls()){
                    String requested=call.name()==null?"":call.name().trim(); String tool=toolRegistry.canonical(requested);
                    JsonNode args=normalizeLegacyArgs(requested,tool,call.arguments());
                    if (Set.of("todowrite", "todo_update").contains(tool)) {
                        appendNativeToolResult(child, call.id(), requested, "SUBAGENT TOOL DENIED: child sessions cannot advance or replace the parent approved plan.");
                        continue;
                    }
                    if(!childNames.contains(requested)&&!childNames.contains(tool)){
                        appendNativeToolResult(child,call.id(),requested,"SUBAGENT TOOL DENIED: tool is not available to subagent '"+agentId+"'.");
                        continue;
                    }
                    onStep.accept(stepEvent(parentStep,"subagent:"+agentId+"→"+tool,describeTool(tool,args),"running",args,null,null));
                    PreparedCall childCall = new PreparedCall(call, requested, tool, args, describeTool(tool,args));
                    ToolExecution execution = preflightCall(childCall, mcpCatalog);
                    if (execution == null) {
                        execution=executeWithPermission(ws,parentRun,tool,args,request.settings(),"Subagent "+agentId+": "+describeTool(tool,args),parentStep,onStep,
                                mcpCatalog,childTools,apiKey,request);
                    }
                    execution = applyChildRepeatOutcomeGuard(childCall, execution, parentRun, childRepeatedOutcomes, mcpCatalog);
                    if(execution.executed()){ observeRun(ws, parentRun,tool,args,execution.result()); toolActivity++; }
                    onStep.accept(stepEvent(parentStep,"subagent:"+agentId+"→"+tool,summarizeResult(tool,execution.result()),execution.status(),args,clipUi(execution.result()),null));
                    appendNativeToolResult(child,call.id(),requested,execution.result());
                    if (execution.result().startsWith("SUBAGENT LOOP BLOCKED:")) {
                        return "SUBAGENT " + agentId + " BLOCKED\n" + execution.result() + "\n\nchildToolActions=" + toolActivity;
                    }
                }
                continue;
            }
            JsonNode env=parseEnvelope(raw);
            if(env!=null&&env.isObject()&&"tool".equals(env.path("type").asText(""))){
                emptyChildTurns = 0;
                String requested=env.path("tool").asText(""); String tool=toolRegistry.canonical(requested);
                JsonNode args=normalizeLegacyArgs(requested,tool,env.path("args"));
                if (Set.of("todowrite", "todo_update").contains(tool)) {
                    child.add(Map.of("role", "user", "content", "Child sessions cannot advance or replace the parent approved plan. Continue delegated work and report evidence."));
                    continue;
                }
                if(!childNames.contains(requested)&&!childNames.contains(tool)){ child.add(Map.of("role","user","content","That tool is unavailable to this subagent. Use one of: "+String.join(", ",childNames))); continue; }
                PreparedCall childCall = new PreparedCall(
                        new OpenAiCompatibleClient.AgentToolCall("subagent_compat_" + childTurn, requested, args),
                        requested, tool, args, describeTool(tool,args));
                ToolExecution execution = preflightCall(childCall, mcpCatalog);
                if (execution == null) {
                    execution=executeWithPermission(ws,parentRun,tool,args,request.settings(),"Subagent "+agentId+": "+describeTool(tool,args),parentStep,onStep,
                            mcpCatalog,childTools,apiKey,request);
                }
                execution = applyChildRepeatOutcomeGuard(childCall, execution, parentRun, childRepeatedOutcomes, mcpCatalog);
                if(execution.executed()){ observeRun(ws, parentRun,tool,args,execution.result()); toolActivity++; }
                appendFallbackToolTranscript(child,raw,tool,execution.result());
                if (execution.result().startsWith("SUBAGENT LOOP BLOCKED:")) {
                    return "SUBAGENT " + agentId + " BLOCKED\n" + execution.result() + "\n\nchildToolActions=" + toolActivity;
                }
                continue;
            }
            if(!raw.isBlank()) return "SUBAGENT "+agentId+" REPORT\n"+raw+"\n\nchildToolActions="+toolActivity;
            emptyChildTurns++;
            if (emptyChildTurns >= MAX_CONSECUTIVE_EMPTY_SUBAGENT_TURNS) {
                parentRun.markRepeatedCallPrevented();
                return "SUBAGENT " + agentId + " BLOCKED\nThe subagent returned empty/non-actionable turns repeatedly; the child session was stopped to protect the token budget.\n\nchildToolActions=" + toolActivity;
            }
            child.add(Map.of("role","user","content","Continue the delegated task using the available tools, then return your findings."));
        }
    }

    /**
     * Verification-assisted sequential plan advancement. Some providers successfully edit and verify the active step
     * but repeatedly fail to emit the bookkeeping todo_update call. A small independent critic can close that protocol
     * gap when the evidence is sufficient, preventing false "all executors exhausted" failures after a green build.
     */
    private boolean looksFinalVerificationPlanStep(String stepText) {
        String value = stepText == null ? "" : stepText.toLowerCase(Locale.ROOT);
        if (value.isBlank()) return false;
        boolean verifyIntent = List.of("verify", "verification", "validate", "test", "compile", "build", "run ", "regression", "smoke", "check ")
                .stream().anyMatch(value::contains);
        boolean finalBoundary = List.of("final", "after all", "after the", "latest workspace", "complete change", "all requested changes")
                .stream().anyMatch(value::contains);
        boolean implementationIntent = List.of("implement the feature", "implement requested", "modify feature", "create feature", "refactor the", "migrate the", "write implementation")
                .stream().anyMatch(value::contains);
        return verifyIntent && finalBoundary && !implementationIntent;
    }

    private boolean looksVerificationPlanStep(String stepText) {
        String value = stepText == null ? "" : stepText.toLowerCase(Locale.ROOT);
        if (value.isBlank()) return false;
        boolean verifyIntent = List.of("verify", "validate", "test", "compile", "build", "run ", "regression", "smoke", "check ")
                .stream().anyMatch(value::contains);
        boolean mutationIntent = List.of("implement", "modify", "edit", "create", "refactor", "migrate", "fix ", "update ", "write ")
                .stream().anyMatch(value::contains);
        return verifyIntent && !mutationIntent;
    }

    private boolean looksReadOnlyPlanStep(String stepText) {
        String value = stepText == null ? "" : stepText.toLowerCase(Locale.ROOT);
        if (value.isBlank()) return false;
        boolean readIntent = List.of("inspect", "analyse", "analyze", "identify", "trace", "review", "discover", "understand", "map", "confirm", "locate", "investigate")
                .stream().anyMatch(value::contains);
        boolean mutationIntent = List.of("implement", "modify", "change", "edit", "create", "add ", "remove", "refactor", "migrate", "fix ", "update ", "write ")
                .stream().anyMatch(value::contains);
        return readIntent && !mutationIntent;
    }

    /** Evidence-only completion gate for an explicitly read-only active step. */
    private StepCompletionDecision activeReadOnlyStepCompletionGate(String apiKey, ChatRequest request,
                                                                     AgentRunService.AgentRun run, int step,
                                                                     Consumer<Map<String,Object>> onStep) {
        int activeIndex = run.activePlanIndex();
        String evidence = run.activePlanEvidenceText();
        if (activeIndex <= 0 || evidence.isBlank()) return new StepCompletionDecision(false, "No active read-only evidence");
        try {
            List<Map<String,Object>> gate = new ArrayList<>();
            gate.add(Map.of("role", "system", "content", """
                    You are the READ-ONLY STEP COMPLETION CRITIC in a coding-agent harness. Decide whether the supplied
                    real search/read/inspection evidence is enough to satisfy ONLY the active investigation step. Do not
                    require a file mutation or build for a genuinely read-only step. Do not judge later implementation work.
                    First line exactly SATISFIED or CONTINUE, followed by one concise evidence-based reason. Do not call tools.
                    """));
            gate.add(Map.of("role", "user", "content", "ORIGINAL OBJECTIVE:\n" + run.objective() +
                    "\n\nACTIVE STEP " + activeIndex + ":\n" + run.activePlanStepText() +
                    "\n\nRECORDED LIVE TOOL EVIDENCE:\n" + evidence));
            String model = request.settings().criticModelOrPrimary();
            ContextWindowManager.ContextEstimate estimate = contextWindows.estimate(gate, List.of(), request.settings(), model);
            run.recordContextEstimate(estimate.estimatedInputTokens(), estimate.contextWindowTokens());
            int maxOut = request.settings().safeMaxTokens() > 0 ? Math.min(700, request.settings().safeMaxTokens()) : 700;
            OpenAiCompatibleClient.AgentCompletion completion = completeRoleText(apiKey, request, run, model,
                    ModelCapabilityRegistry.Role.CRITIC, maxOut, gate, step, onStep, "read-only step completion check");
            run.recordModelUsage(completion.usage(), estimate.estimatedInputTokens());
            String raw = completion.content() == null ? "" : completion.content().strip();
            DecisionLine decision = parseDecisionLine(raw, "SATISFIED", "CONTINUE");
            String reason = decision.summary();
            boolean satisfied = "SATISFIED".equals(decision.token());
            return new StepCompletionDecision(satisfied, reason.isBlank() ? raw : reason);
        } catch (Exception e) {
            return new StepCompletionDecision(false, "Read-only completion critic unavailable: " + safe(e.getMessage()));
        }
    }

    private StepCompletionDecision activeStepCompletionGate(String apiKey, ChatRequest request,
                                                            AgentWorkspaceService.Workspace ws,
                                                            AgentRunService.AgentRun run, int step,
                                                            Consumer<Map<String,Object>> onStep) {
        int activeIndex = run.activePlanIndex();
        if (activeIndex <= 0 || run.activePlanStepText().isBlank()) return new StepCompletionDecision(false, "No active plan step");
        try {
            String diff = "";
            try { diff = workspaces.workspaceDiff(ws, ""); } catch (Exception ignored) { }
            List<Map<String,Object>> gate = new ArrayList<>();
            gate.add(Map.of("role", "system", "content", """
                    You are the STEP COMPLETION CRITIC in a coding-agent harness. The current workspace revision has just passed
                    a real verifier. Decide whether the ACTIVE approved plan step itself is already satisfied by the recorded
                    workspace/tool evidence. Do not judge later steps and do not reward protocol wording. A successful compile alone
                    is not enough when the step requires behavior/tests/configuration that the supplied evidence does not prove.

                    First line must be exactly SATISFIED or CONTINUE. Then give one concise evidence-based reason. Do not call tools.
                    """));
            String gateEvidence = "ORIGINAL OBJECTIVE:\n" + run.objective() +
                    "\n\nACTIVE STEP " + activeIndex + ":\n" + run.activePlanStepText() +
                    "\n\nPLAN STATE:\n" + run.planText() +
                    "\n\nACTIVE STEP TOOL EVIDENCE:\n" + (run.activePlanEvidenceText().isBlank() ? "[none recorded]" : run.activePlanEvidenceText()) +
                    "\n\nLAST VERIFIER:\n" + run.lastVerification() +
                    "\n\nCURRENT WORKSPACE DIFF:\n" + clipHeadTail(diff, 14_000, "[diff clipped]");
            gate.add(Map.of("role", "user", "content", gateEvidence));
            String model = request.settings().criticModelOrPrimary();
            ContextWindowManager.ContextEstimate estimate = contextWindows.estimate(gate, List.of(), request.settings(), model);
            run.recordContextEstimate(estimate.estimatedInputTokens(), estimate.contextWindowTokens());
            int maxOut = request.settings().safeMaxTokens() > 0 ? Math.min(900, request.settings().safeMaxTokens()) : 900;
            if (!model.equals(effectiveModel(run, request.settings()))) {
                onStep.accept(stepEvent(step, "model_route", "Step completion critic: " + model, "success", null, null, null));
            }
            OpenAiCompatibleClient.AgentCompletion completion = completeRoleText(
                    apiKey, request, run, model, ModelCapabilityRegistry.Role.CRITIC, maxOut, gate, step, onStep, "step completion check");
            run.recordModelUsage(completion.usage(), estimate.estimatedInputTokens());
            String raw = completion.content() == null ? "" : completion.content().strip();
            DecisionLine decision = parseDecisionLine(raw, "SATISFIED", "CONTINUE");
            String reason = decision.summary();
            boolean satisfied = "SATISFIED".equals(decision.token());
            onStep.accept(stepEvent(step, "step_completion_check",
                    satisfied ? "Active plan step satisfied by verified evidence" : "Active plan step still needs work",
                    satisfied ? "success" : "running", null, clipUi(reason.isBlank() ? raw : reason), null));
            return new StepCompletionDecision(satisfied, reason.isBlank() ? raw : reason);
        } catch (Exception e) {
            onStep.accept(stepEvent(step, "step_completion_check",
                    "Step completion check unavailable; preserving the active sequential gate",
                    "running", null, clipUi(safe(e.getMessage())), null));
            return new StepCompletionDecision(false, "Completion critic unavailable");
        }
    }

    private record StepCompletionDecision(boolean satisfied, String reason) { }

    /**
     * After a new workspace revision has passed a verifier, ask the model once — with no tools exposed — whether
     * the original request is actually satisfied. This prevents the common "tests are green but agent keeps
     * searching/polling" tail without blindly assuming that every intermediate green build means the whole task is done.
     * Return CONTINUE when more requested work remains; otherwise return the final user-facing answer.
     */
    private String completionGate(String apiKey, ChatRequest request, List<Map<String,Object>> messages,
                                  AgentRunService.AgentRun run, int step, Consumer<Map<String,Object>> onStep) {
        try {
            List<Map<String,Object>> gate = new ArrayList<>(messages);
            gate.add(Map.of("role", "user", "content", """
                    RUNTIME COMPLETION CHECK. The current workspace revision has just passed its required verifier.
                    Decide whether the user's ORIGINAL request is fully satisfied based only on the conversation, workspace evidence and verifier result already present.
                    - If any requested implementation/fix/migration/test/documentation work is still incomplete, output exactly: CONTINUE
                    - If the request is complete, return the concise final answer to the user now: what changed and the verification performed.
                    - Do not propose extra optional work. Do not request or simulate tools. Do not repeat investigation that is already complete.
                    """));
            String criticModel = request.settings().criticModelOrPrimary();
            // A critic may have a smaller context window than the active executor. Bound the copied completion
            // prompt against the critic's own window before sending it, without mutating the live executor history.
            contextWindows.pruneSupersededRuntimeSteering(gate);
            ContextWindowManager.ContextEstimate estimate = contextWindows.estimate(gate, List.of(), request.settings(), criticModel);
            if (estimate.estimatedInputTokens() > estimate.inputLimitTokens()) {
                contextWindows.pruneOldToolOutputs(gate, request.settings(), true);
                estimate = contextWindows.estimate(gate, List.of(), request.settings(), criticModel);
                if (estimate.estimatedInputTokens() > estimate.inputLimitTokens()) {
                    contextWindows.compact(gate, List.of(), request.settings(), run, true, null, criticModel);
                    estimate = contextWindows.estimate(gate, List.of(), request.settings(), criticModel);
                }
            }
            run.recordContextEstimate(estimate.estimatedInputTokens(), estimate.contextWindowTokens());
            int maxOut = request.settings().safeMaxTokens() > 0 ? Math.min(2_500, request.settings().safeMaxTokens()) : 2_500;
            if (!criticModel.equals(effectiveModel(run, request.settings()))) {
                onStep.accept(stepEvent(step, "model_route", "Completion critic: " + criticModel, "success", null, null, null));
            }
            OpenAiCompatibleClient.AgentCompletion completion = completeRoleText(
                    apiKey, request, run, criticModel, ModelCapabilityRegistry.Role.CRITIC, maxOut, gate, step, onStep, "completion check");
            run.recordModelUsage(completion.usage(), estimate.estimatedInputTokens());
            String value = completion.content() == null ? "" : completion.content().trim();
            // An empty critic response is not evidence that the task is complete. Continue the executor instead of
            // silently treating a provider/formatting glitch as success.
            if (value.isBlank()) {
                onStep.accept(stepEvent(step, "completion_check",
                        "Completion critic returned no decision; continuing normal agent flow",
                        "running", null, null, null));
                return "CONTINUE";
            }
            boolean shouldContinue = decisionTokenMatches(value, "CONTINUE");
            onStep.accept(stepEvent(step, "completion_check",
                    "Verified revision completion check: " + (shouldContinue ? "more requested work remains" : "task satisfied"),
                    shouldContinue ? "running" : "success", null, null, null));
            return shouldContinue ? "CONTINUE" : value;
        } catch (Exception e) {
            // Completion acceleration is an optimization, not a correctness dependency. Resume the ordinary agent loop.
            onStep.accept(stepEvent(step, "completion_check", "Completion check unavailable; continuing normal agent flow", "running", null, clipUi(safe(e.getMessage())), null));
            return "CONTINUE";
        }
    }

    private OpenAiCompatibleClient.AgentCompletion completeAgentTurn(String apiKey, ChatRequest request,
                                                                      List<Map<String, Object>> messages,
                                                                      AgentWorkspaceService.Workspace ws,
                                                                      AgentRunService.AgentRun run,
                                                                      boolean requireTool,
                                                                      List<Map<String,Object>> availableTools,
                                                                      int step,
                                                                      Consumer<Map<String,Object>> onStep) throws Exception {
        boolean overflowRecovered = false;
        int retriesOnActivation = 0;
        int modelActivations = 1;
        final int maxModelActivations = providerRecoveryActivationLimit(run);
        while (true) {
            run.checkCancelled();
            String model = effectiveModel(run, request.settings());
            prepareActiveContext(apiKey, request, model, messages, availableTools, request.settings(), ws, run, step, onStep, false);
            ContextWindowManager.ContextEstimate estimate = contextWindows.estimate(messages, availableTools, request.settings(), model);
            run.recordContextEstimate(estimate.estimatedInputTokens(), estimate.contextWindowTokens());
            try {
                OpenAiCompatibleClient.AgentCompletion turn = llm.completeAgent(apiKey, request.settings().baseUrl(), model,
                        request.settings().safeMaxTokens(), messages,
                        availableTools, requireTool, run::cancelled);
                run.recordModelUsage(turn.usage(), estimate.estimatedInputTokens());
                if (run.modelCalls() == 1 || run.modelCalls() % 10 == 0) {
                    onStep.accept(stepEvent(step, "token_usage", tokenUsageDetail(run), "success", null, null, null));
                }
                return turn;
            } catch (AgentCancelledException cancelled) {
                throw cancelled;
            } catch (Exception e) {
                String error = providerFailureDetail(e);
                // First recover genuine context overflow deterministically without changing models.
                if (isContextWindowFailure(e) && !overflowRecovered) {
                    ContextWindowManager.CompactionResult compacted = contextWindows.compact(messages, availableTools,
                            request.settings(), run, true, null, model);
                    overflowRecovered = true;
                    if (compacted.compacted()) {
                        run.recordCompaction(compacted.estimatedTokensSaved(), compacted.reason());
                        onStep.accept(stepEvent(step, "context_compaction",
                                "Provider context overflow recovered on " + model + ": " + formatCompaction(compacted),
                                "success", null, null, null));
                        continue;
                    }
                }

                run.recordExecutionFailure("Agent model/provider failure on " + model + ": " + error);
                if (!isAuthenticationFailure(e) && retriesOnActivation < PROVIDER_RETRIES_PER_MODEL_ACTIVATION) {
                    retriesOnActivation++;
                    onStep.accept(stepEvent(step, "model_retry",
                            "Retrying " + model + " after provider/model failure (retry " + retriesOnActivation + "/" + PROVIDER_RETRIES_PER_MODEL_ACTIVATION + ")",
                            "running", null, clipUi(error), null));
                    sleepCancellable(run, providerRetryDelayMs(retriesOnActivation));
                    continue;
                }

                if (!isAuthenticationFailure(e) && modelActivations < maxModelActivations &&
                        switchToNextModelCyclic(run, onStep, step, error)) {
                    modelActivations++;
                    retriesOnActivation = 0;
                    overflowRecovered = false;
                    messages.add(Map.of("role", "system", "content", modelFailoverContinuation(run)));
                    continue;
                }

                throw new ProviderModelException(model, error, e);
            }
        }
    }

    /**
     * Completed plan steps are durable state, not chat history. When a step boundary is crossed with a large active
     * transcript, create a deterministic checkpoint before the next model call. This keeps long multi-step runs fast
     * without imposing a hard token/step limit and without spending another LLM call just to summarize history.
     */
    private void checkpointAtPlanBoundary(String apiKey, ChatRequest request,
                                          List<Map<String,Object>> messages,
                                          List<Map<String,Object>> availableTools,
                                          AgentRunService.AgentRun run, int step,
                                          Consumer<Map<String,Object>> onStep) {
        if (messages == null || messages.size() < 6 || request == null || request.settings() == null) return;
        try {
            String model = effectiveModel(run, request.settings());
            contextWindows.pruneSupersededRuntimeSteering(messages);
            contextWindows.pruneOldToolOutputs(messages, request.settings(), false);
            ContextWindowManager.ContextEstimate estimate = contextWindows.estimate(messages, availableTools, request.settings(), model);
            int threshold = Math.max(24_000, Math.min(48_000, estimate.contextWindowTokens() / 3));
            if (estimate.estimatedInputTokens() < threshold) return;
            ContextWindowManager.CompactionResult result = contextWindows.compact(
                    messages, availableTools, request.settings(), run, true, null, model);
            if (!result.compacted()) return;
            run.recordCompaction(result.estimatedTokensSaved(), "plan-boundary " + result.reason());
            onStep.accept(stepEvent(step, "context_checkpoint",
                    "Completed-step context checkpoint: " + formatCompaction(result),
                    "success", null, null, null));
        } catch (Exception ignored) {
            // Performance optimization only. A checkpoint failure must never block execution of the next plan step.
        }
    }

    private void prepareActiveContext(String apiKey, ChatRequest request, String model,
                                      List<Map<String,Object>> messages, List<Map<String,Object>> availableTools,
                                      ChatSettings settings, AgentWorkspaceService.Workspace ws, AgentRunService.AgentRun run, int step,
                                      Consumer<Map<String,Object>> onStep, boolean forced) {
        // Keep changing runtime state and retrieval hints at the suffix. The stable system/user prefix therefore stays
        // provider-cache friendly while the model receives the exact active plan/revision without replaying old events.
        contextWindows.upsertDurableRuntimeState(messages, run.durableContextText());
        String retrievalQuery = (run.objective() + " " + run.activePlanStepText()).strip();
        String retrievalBundle = activeContextBundle(ws, run, retrievalQuery);
        contextWindows.upsertRetrievalHints(messages, retrievalBundle);

        ContextWindowManager.ContextEstimate beforePrune = contextWindows.estimate(messages, availableTools, settings, model);
        boolean aggressive = contextWindows.shouldAggressivelyPrune(messages, availableTools, settings, model);
        int steeringPruned = contextWindows.pruneSupersededRuntimeSteering(messages);
        int pruned = contextWindows.pruneOldToolOutputs(messages, settings, aggressive);
        ContextWindowManager.ContextEstimate before = contextWindows.estimate(messages, availableTools, settings, model);
        long pruningSaved = Math.max(0, beforePrune.estimatedInputTokens() - before.estimatedInputTokens());
        if (pruned + steeringPruned > 0 || pruningSaved > 0) run.recordPruning(pruned + steeringPruned, pruningSaved);
        run.recordContextEstimate(before.estimatedInputTokens(), before.contextWindowTokens());
        boolean should = forced || contextWindows.shouldCompact(messages, availableTools, settings, model);
        if (!should) return;
        // Keep compaction deterministic. A recovery mechanism must not spend another provider call summarizing
        // history, because that can compound the same context/provider failure it is trying to solve.
        ContextWindowManager.CompactionResult result = contextWindows.compact(messages, availableTools, settings, run, forced, null, model);
        if (!result.compacted()) return;
        run.recordCompaction(result.estimatedTokensSaved(), result.reason());
        String extra = (pruned > 0 ? "; pruned " + pruned + (aggressive ? " aggressively" : "") + " old/oversized tool observation(s)" : "") +
                (steeringPruned > 0 ? "; removed " + steeringPruned + " superseded runtime steering message(s)" : "") +
                (pruningSaved > 0 ? "; saved ~" + pruningSaved + " tokens before compaction" : "");
        onStep.accept(stepEvent(step, "context_compaction", formatCompaction(result) + extra,
                "success", null, null, null));
    }


    private String activeContextBundle(AgentWorkspaceService.Workspace ws, AgentRunService.AgentRun run, String retrievalQuery) {
        if (ws == null || run == null || retrievalQuery == null || retrievalQuery.isBlank()) return "";
        String key = run.id() + "|" + run.activePlanIndex() + "|" + run.mutationRevision() + "|" + Integer.toHexString(retrievalQuery.hashCode());
        String cached = activeContextCache.get(key);
        if (cached != null) return cached;

        String retrievalHints = workspaceRetrieval.retrieve(ws, retrievalQuery, 8, 7_000);
        String liveEvidence = retrievalHints.isBlank() ? "" : collectActiveStepFileEvidence(ws, retrievalHints, run);
        String bundle = retrievalHints + (liveEvidence.isBlank() ? "" : "\n\n" + liveEvidence);
        if (activeContextCache.size() > 256) activeContextCache.clear();
        activeContextCache.put(key, bundle);
        return bundle;
    }

    private void clearActiveContextCache(AgentRunService.AgentRun run) {
        if (run == null) return;
        String prefix = run.id() + "|";
        activeContextCache.keySet().removeIf(key -> key.startsWith(prefix));
    }



    /**
     * Convert retrieval hits into a small bundle of CURRENT file contents. Retrieval snippets are useful for discovery,
     * but the executor must see authoritative source before it edits. This deliberately reads only the strongest few
     * files. The runtime caches this bundle for the active step/revision and refreshes it only when the step or workspace changes.
     */
    private String collectActiveStepFileEvidence(AgentWorkspaceService.Workspace ws, String retrievalHints, AgentRunService.AgentRun run) {
        if (ws == null || retrievalHints == null || retrievalHints.isBlank()) return "";
        LinkedHashSet<String> paths = new LinkedHashSet<>();
        for (String rawLine : retrievalHints.split("\\R")) {
            String line = rawLine == null ? "" : rawLine.strip();
            if (!line.startsWith("- ")) continue;
            int score = line.indexOf(" (score=");
            String path = (score > 2 ? line.substring(2, score) : line.substring(2)).strip();
            String low = path.toLowerCase(Locale.ROOT);
            if (path.isBlank() || low.endsWith(".env") || low.contains("/secrets/") || low.endsWith(".pem") ||
                    low.endsWith(".key") || low.endsWith(".jks") || low.endsWith(".p12") || low.endsWith(".pfx")) continue;
            paths.add(path);
            int preloadLimit = run != null && run.largeTaskMode() ? 6 : 3;
            if (paths.size() >= preloadLimit) break;
        }
        if (paths.isEmpty()) return "";
        StringBuilder out = new StringBuilder("ACTIVE STEP LIVE FILE EVIDENCE — current filesystem contents; authoritative for implementation.\n");
        int budget = run != null && run.largeTaskMode() ? 18_000 : 11_000;
        for (String path : paths) {
            try {
                String body = workspaces.readFileRange(ws, path, 1, 180);
                if (body == null || body.isBlank()) continue;
                String block = "\n### " + path + "\n" + clipHeadTail(body, 3_500, "[File excerpt clipped; use read/read_chunk for more]");
                if (out.length() + block.length() > budget) break;
                out.append(block);
            } catch (Exception ignored) {
                // Discovery is advisory. The executor can still use read tools when a file cannot be preloaded.
            }
        }
        return out.length() <= 100 ? "" : out.toString();
    }
    private ContextWindowManager.CompactionSummarizer compactionSummarizer(String apiKey, ChatRequest request,
                                                                              String model,
                                                                              AgentRunService.AgentRun run) {
        String summaryModel = model == null || model.isBlank() ? request.settings().model() : model;
        return (prompt, maxOutputTokens) -> {
            run.checkCancelled();
            int estimatedInput = Math.max(1, (prompt.length() + 2) / 3) + 256;
            OpenAiCompatibleClient.AgentCompletion summary = llm.completeTextWithUsage(
                    apiKey, request.settings().baseUrl(), summaryModel, maxOutputTokens,
                    List.of(Map.of("role", "user", "content", prompt)), run::cancelled);
            run.recordModelUsage(summary.usage(), estimatedInput);
            return summary.content();
        };
    }

    private String formatCompaction(ContextWindowManager.CompactionResult result) {
        ContextWindowManager.ContextEstimate after = result.after();
        return result.reason() + ": saved ~" + result.estimatedTokensSaved() + " active tokens; context now ~" +
                after.estimatedInputTokens() + "/" + after.contextWindowTokens() + " tokens";
    }

    private String tokenUsageDetail(AgentRunService.AgentRun run) {
        long total = run.providerTotalTokens();
        String provider = total > 0
                ? "provider run total " + total + " tokens (input " + run.providerInputTokens() +
                ", output " + run.providerOutputTokens() + ", cached input " + run.cachedInputTokens() + ")"
                : "provider did not report usage; runtime estimates are active";
        return "Context ~" + run.currentContextTokens() + "/" + run.contextWindowTokens() + " tokens; " +
                provider + "; compactions " + run.compactions() +
                "; pruned observations " + run.prunedObservations() +
                "; estimated pruning savings " + run.estimatedTokensSavedByPruning() + " tokens";
    }

    private ToolExecution executeWithPermission(AgentWorkspaceService.Workspace ws, AgentRunService.AgentRun run,
                                                String tool, JsonNode args, ChatSettings settings, String detail,
                                                int step, Consumer<Map<String, Object>> onStep,
                                                McpManager.Catalog mcpCatalog, List<Map<String,Object>> availableTools,
                                                String apiKey, ChatRequest request) {
        String permission = permissionFor(tool, settings);
        if ("deny".equals(permission)) {
            return new ToolExecution("TOOL DENIED BY PERMISSION: " + tool, "error", false);
        }
        try {
            run.updateActivity(phaseForTool(tool), detail);
            if ("ask".equals(permission) && !settings.autoApproveAgent() && !run.isToolApprovedForRun(tool)) {
                AgentApprovalService.Approval approval = approvals.create(run.id(), tool, detail);
                onStep.accept(stepEvent(step, tool, detail, "approval", args, null, approval.id()));
                AgentApprovalService.Decision decision = approvals.await(approval.id(), Duration.ZERO, run);
                if (decision == AgentApprovalService.Decision.DENY) {
                    return new ToolExecution("TOOL DENIED BY USER: " + tool, "error", false);
                }
                if (decision == AgentApprovalService.Decision.RUN) run.approveToolForRun(tool);
                onStep.accept(stepEvent(step, tool, decision == AgentApprovalService.Decision.RUN
                        ? "Allowed for this run — executing tool" : "Approved once — executing tool",
                        "running", args, null, null));
            }
            // This approval is independent of the approved PLAN, general Ask/Allow grants, and
            // agentAutoApprove. A user must explicitly approve each impacted operation once.
            // In particular a general "Allow this run" for edit/delete never bypasses this gate.
            if (settings.confirmFileDeletion()) {
                if (Set.of("bash", "resource_bash", "process_start").contains(tool)
                        && AgentDeletionCommandGuard.isPotentialDestructiveShell(text(args, "command"))) {
                    return new ToolExecution("FILE PROTECTION: destructive shell syntax is blocked. " +
                            "Use the explicit delete/resource_delete, move or apply_patch tool, which lists " +
                            "affected files and requests separate approval. Arbitrary shell commands cannot " +
                            "be safely parsed into a complete list of file deletions.", "error", false);
                }
                List<String> protectedChanges = ws == null ? List.of() :
                        workspaces.previewProtectedFileChanges(ws, tool, args, checkpointScope(run), run.touchedPaths());
                if (AgentDeletionCommandGuard.isPotentialDestructiveMcp(tool)) {
                    protectedChanges = new ArrayList<>(protectedChanges);
                    protectedChanges.add("EXTERNAL MCP OPERATION: " + tool +
                            " (external server controls affected files; review the full input and only approve if trusted)");
                }
                if (!protectedChanges.isEmpty()) {
                    String fileList = String.join("\n", protectedChanges);
                    String summary = "FILE DELETION APPROVAL REQUIRED: " + protectedChanges.size() +
                            " affected path(s) for " + tool + ". This confirmation is for this operation only.";
                    AgentApprovalService.Approval fileApproval = approvals.create(run.id(), tool, summary + "\n" + fileList, false);
                    Map<String,Object> approvalEvent = stepEvent(step, tool, summary, "approval", args, fileList, fileApproval.id());
                    approvalEvent.put("approvalType", "file_deletion");
                    onStep.accept(approvalEvent);
                    AgentApprovalService.Decision fileDecision = approvals.await(fileApproval.id(), Duration.ZERO, run);
                    if (fileDecision != AgentApprovalService.Decision.ONCE) {
                        onStep.accept(stepEvent(step, tool, "File operation denied; no protected file changes executed",
                                "error", args, fileList, null));
                        return new ToolExecution("FILE OPERATION DENIED: " + fileList, "error", false);
                    }
                    // Re-evaluate exactly the operation and its target paths before executing;
                    // approval is NOT reusable if a parallel task changed which files are affected.
                    List<String> currentChanges = ws == null ? List.of() :
                            workspaces.previewProtectedFileChanges(ws, tool, args, checkpointScope(run), run.touchedPaths());
                    if (AgentDeletionCommandGuard.isPotentialDestructiveMcp(tool)) {
                        currentChanges = new ArrayList<>(currentChanges);
                        currentChanges.add("EXTERNAL MCP OPERATION: " + tool +
                                " (external server controls affected files; review the full input and only approve if trusted)");
                    }
                    if (!protectedChanges.equals(currentChanges)) {
                        return new ToolExecution("FILE PROTECTION: affected paths changed while waiting for approval. " +
                                "Re-inspect the workspace and submit the operation again for a fresh approval.", "error", false);
                    }
                    onStep.accept(stepEvent(step, tool, "User explicitly approved these file changes once",
                            "running", args, fileList, null));
                }
            }
            String result = execute(ws, run, tool, args, settings, mcpCatalog, availableTools, apiKey, request, step, onStep);
            String status = isFailedCommandResult(tool, result) || (tool != null && tool.startsWith("mcp__") && result != null && result.contains("isError=true")) ? "error" : "success";
            return new ToolExecution(result, status, true);
        } catch (AgentCancelledException cancelled) {
            throw cancelled;
        } catch (Exception e) {
            String error = "TOOL ERROR: " + safe(e.getMessage());
            if (tool != null && tool.startsWith("resource_") && error.toLowerCase(Locale.ROOT).contains("unknown resource alias")) {
                String guided = error + "\n\n" + workspaces.resourceCatalog(ws) +
                        "\n\nRECOVERABLE: only aliases listed above are ELIYA resources. If the token is framework/CLI syntax such as @rerun.txt, use an ordinary workspace path without the leading @ marker. Continue the active plan; do not abort the run for this reference mistake.";
                // Count the recovery catalog as useful tool activity so one mistaken @file reference cannot exhaust
                // a long-running migration's no-progress budget before the model gets the real alias map.
                return new ToolExecution(guided, "error", true);
            }
            // A verifier that could not even start is still a real verification attempt. Recording it lets the
            // agent distinguish an external execution blocker from an ordinary unverified edit, rather than
            // repeatedly forcing the model back into the same command forever.
            if (isVerifier(tool, args)) {
                run.markVerificationAttempt(false, summarizeResult(tool, error));
                run.recordVerificationFailures(error);
            }
            return new ToolExecution(error, "error", false);
        }
    }

    private String execute(AgentWorkspaceService.Workspace ws, AgentRunService.AgentRun run, String tool,
                           JsonNode args, ChatSettings settings, McpManager.Catalog mcpCatalog,
                           List<Map<String,Object>> availableTools, String apiKey, ChatRequest request,
                           int parentStep, Consumer<Map<String,Object>> onStep) throws Exception {
        if (mcp.isMcpTool(mcpCatalog, tool)) return mcp.call(ws == null ? null : ws.root(), mcpCatalog, tool, args, run::cancelled);
        return switch (tool) {
            case "inspect_workspace" -> workspaces.inspectWorkspace(ws);
            case "workspace_profile" -> workspaceProfiles.profileText(ws);
            case "workspace_profile_refresh" -> workspaceProfiles.refresh(ws);
            case "list" -> workspaces.listFiles(ws, firstNonBlank(text(args, "path"), text(args, "prefix")));
            case "glob" -> workspaces.glob(ws, requiredText(args, "pattern"), args.path("maxMatches").asInt(0));
            case "grep" -> args.path("regex").asBoolean(false)
                    ? workspaces.regexSearch(ws, requiredText(args, "pattern"), args.path("maxMatches").asInt(0))
                    : workspaces.search(ws, requiredText(args, "pattern"), args.path("maxMatches").asInt(0));
            case "file_info" -> workspaces.fileInfo(ws, requiredText(args, "path"));
            case "file_index" -> workspaces.fileIndex(ws, requiredText(args, "path"));
            case "read" -> {
                int start = args.path("startLine").asInt(1);
                int end = args.has("endLine") ? args.path("endLine").asInt(Integer.MAX_VALUE) : Integer.MAX_VALUE;
                yield workspaces.readFileRange(ws, requiredText(args, "path"), start, end);
            }
            case "read_chunk" -> workspaces.readFileChunk(ws, requiredText(args, "path"), Math.max(0L, args.path("offsetChars").asLong(0L)), args.path("maxChars").asInt(0));
            case "read_many" -> workspaces.readFiles(ws, stringList(args, "paths"));
            case "instruction_catalog" -> workspaces.instructionCatalog(ws);
            case "instructions_for" -> workspaces.instructionsFor(ws, requiredText(args, "path"));
            case "resource_catalog" -> workspaces.resourceCatalog(ws);
            case "resource_list" -> workspaces.resourceList(ws, requiredText(args, "alias"), text(args, "path"));
            case "resource_info" -> workspaces.resourceFileInfo(ws, requiredText(args, "alias"), text(args, "path"));
            case "resource_index" -> workspaces.resourceIndex(ws, requiredText(args, "alias"), text(args, "path"));
            case "resource_read" -> workspaces.resourceRead(ws, requiredText(args, "alias"), text(args, "path"),
                    args.path("startLine").asInt(1), args.has("endLine") ? args.path("endLine").asInt(Integer.MAX_VALUE) : Integer.MAX_VALUE);
            case "resource_chunk" -> workspaces.resourceReadChunk(ws, requiredText(args, "alias"), text(args, "path"),
                    Math.max(0L, args.path("offsetChars").asLong(0L)), args.path("maxChars").asInt(0));
            case "resource_grep" -> workspaces.resourceGrep(ws, requiredText(args, "alias"), requiredText(args, "pattern"),
                    args.path("regex").asBoolean(false), args.path("maxMatches").asInt(0));
            case "resource_edit" -> workspaces.resourceEdit(ws, requiredText(args, "alias"), requiredText(args, "path"),
                    requiredText(args, "oldText"), text(args, "newText"), args.path("replaceAll").asBoolean(false));
            case "resource_write" -> workspaces.resourceWrite(ws, requiredText(args, "alias"), requiredText(args, "path"), text(args, "content"));
            case "resource_delete" -> workspaces.resourceDelete(ws, requiredText(args, "alias"), requiredText(args, "path"));
            case "resource_copy" -> workspaces.resourceCopy(ws, requiredText(args, "fromAlias"), text(args, "fromPath"), requiredText(args, "toAlias"), requiredText(args, "toPath"), args.path("overwrite").asBoolean(false));
            case "resource_move" -> workspaces.resourceMove(ws, requiredText(args, "fromAlias"), requiredText(args, "fromPath"), requiredText(args, "toAlias"), requiredText(args, "toPath"), args.path("overwrite").asBoolean(false));
            case "resource_build" -> workspaces.resourceBuild(ws, requiredText(args, "alias"), settings.agentCommandsAllowed(), run).asToolText();
            case "resource_test" -> workspaces.resourceTests(ws, requiredText(args, "alias"), settings.agentCommandsAllowed(), run).asToolText();
            case "resource_check" -> workspaces.resourceCheck(ws, requiredText(args, "alias"), settings.agentCommandsAllowed(), run).asToolText();
            case "resource_bash" -> workspaces.resourceCommand(ws, requiredText(args, "alias"), requiredText(args, "command"),
                    Math.max(0L, args.path("timeoutSeconds").asLong(0L)), settings.agentCommandsAllowed(), settings.extraAgentCommands(), run).asToolText();
            case "attachment_list" -> files.attachmentListForAgent(run.conversationId());
            case "attachment_read" -> files.attachmentTextForAgent(run.conversationId(), requiredText(args, "fileId"),
                    Math.max(0, args.path("offset").asInt(0)), args.path("maxChars").asInt(0));
            case "attachment_search" -> files.attachmentSearchForAgent(run.conversationId(), requiredText(args, "query"),
                    text(args, "fileId"), args.path("maxMatches").asInt(0));
            case "skill_catalog" -> workspaces.availableSkills(ws);
            case "skill" -> workspaces.loadSkill(ws, requiredText(args, "name"));
            case "agent_catalog" -> agentProfiles.catalogText(ws);
            case "task" -> runSubagent(ws, run, request, apiKey, mcpCatalog, availableTools,
                    requiredText(args, "agent"), requiredText(args, "prompt"), parentStep, onStep);
            case "tool_search" -> loadDeferredTools(availableTools, mcpCatalog, requiredText(args, "query"), args.path("maxResults").asInt(12));
            case "mcp_status" -> mcp.status(ws == null ? null : ws.root());
            case "lsp_status" -> lsp.status(ws.root());
            case "lsp" -> lsp.call(ws.root(), requiredText(args, "operation"), text(args, "path"),
                    Math.max(0, args.path("line").asInt(0)), Math.max(0, args.path("character").asInt(0)),
                    text(args, "query"), text(args, "server"), run::cancelled);
            case "edit" -> workspaces.editFile(ws, requiredText(args, "path"), requiredText(args, "oldText"), text(args, "newText"), args.path("replaceAll").asBoolean(false));
            case "write" -> workspaces.writeFile(ws, requiredText(args, "path"), text(args, "content"));
            case "copy" -> workspaces.copyFile(ws, requiredText(args, "from"), requiredText(args, "to"), args.path("overwrite").asBoolean(false));
            case "move" -> workspaces.moveFile(ws, requiredText(args, "from"), requiredText(args, "to"), args.path("overwrite").asBoolean(false));
            case "delete" -> workspaces.deleteFile(ws, requiredText(args, "path"));
            case "apply_patch" -> workspaces.applyPatch(ws, args.path("changes"), text(args, "patch"));
            case "build" -> workspaces.runBuild(ws, text(args, "cwd"), settings.agentCommandsAllowed(), run).asToolText();
            case "test" -> workspaces.runTests(ws, text(args, "cwd"), settings.agentCommandsAllowed(), run).asToolText();
            case "check" -> workspaces.runCheck(ws, text(args, "cwd"), settings.agentCommandsAllowed(), run).asToolText();
            case "bash" -> workspaces.runCommand(ws, requiredText(args, "command"), text(args, "cwd"),
                    settings.agentCommandsAllowed(), settings.extraAgentCommands(),
                    Math.max(0L, args.path("timeoutSeconds").asLong(0L)), run).asToolText();
            case "process_start" -> workspaces.startProcess(ws, requiredText(args, "command"), text(args, "cwd"), settings.agentCommandsAllowed(), run);
            case "process_status" -> workspaces.processStatus(ws, requiredText(args, "processId"));
            case "process_output" -> workspaces.processOutput(ws, requiredText(args, "processId"),
                    Math.max(0L, args.path("offset").asLong(0L)), args.path("maxChars").asInt(0));
            case "process_stop" -> workspaces.stopProcess(ws, requiredText(args, "processId"));
            case "http_request" -> workspaces.httpRequest(firstNonBlank(text(args, "method"), "GET"), requiredText(args, "url"),
                    stringList(args, "headers"), text(args, "body"), args.path("timeoutSeconds").asLong(0), run);
            case "workspace_status" -> workspaces.workspaceStatus(ws);
            case "workspace_diff" -> workspaces.workspaceDiff(ws, text(args, "path"));
            case "workspace_checkpoint" -> workspaces.createCheckpoint(ws, checkpointScope(run), text(args, "label"));
            case "workspace_rollback" -> workspaces.rollbackCheckpoint(ws, checkpointScope(run), requiredText(args, "checkpointId"), run.touchedPaths());
            case "todowrite" -> setTodos(run, stringList(args, "items"));
            case "todoread" -> run.planText();
            case "todo_update" -> updateTodo(run, args);
            case "work_items_discover" -> discoverWorkItems(ws, run, args);
            case "work_items_init" -> initializeWorkItems(run, args);
            case "work_items_add" -> addWorkItems(run, args);
            case "work_items_read" -> run.workItemsText(text(args, "status"), Math.max(0, args.path("offset").asInt(0)), args.path("limit").asInt(50));
            case "work_items_update" -> updateWorkItems(run, args);
            case "verification_failures" -> run.verificationFailureText();
            default -> throw new IllegalArgumentException("Unknown agent tool: " + tool);
        };
    }

    private String loadDeferredTools(List<Map<String,Object>> availableTools, McpManager.Catalog mcpCatalog, String query, int maxResults) {
        List<Map<String,Object>> catalog = new ArrayList<>(toolRegistry.builtInDefinitions());
        if (mcpCatalog != null && mcpCatalog.definitions() != null) catalog.addAll(mcpCatalog.definitions());
        List<Map<String,Object>> matches = toolRegistry.searchDefinitions(catalog, query, maxResults);
        if (matches.isEmpty()) return "[No deferred tools matched: " + query + "]";
        Set<String> active = new HashSet<>();
        for (Map<String,Object> def : availableTools) active.add(toolRegistry.functionName(def));
        List<String> loaded = new ArrayList<>();
        for (Map<String,Object> def : matches) {
            String name = toolRegistry.functionName(def);
            if (active.add(name)) { availableTools.add(def); loaded.add(name); }
        }
        if (loaded.isEmpty()) return "[Matching tools were already loaded: " + query + "]";
        return "Loaded " + loaded.size() + " deferred tool definition(s):\n" + String.join("\n", loaded);
    }

    JsonNode normalizeLegacyArgs(String requestedTool, String canonicalTool, JsonNode rawArgs) {
        JsonNode args = rawArgs == null || !rawArgs.isObject() ? objectMapper.createObjectNode() : rawArgs.deepCopy();
        if (!(args instanceof com.fasterxml.jackson.databind.node.ObjectNode obj)) return args;
        String requested = requestedTool == null ? "" : toolRegistry.sanitizeToolName(requestedTool).toLowerCase(Locale.ROOT);

        // Providers frequently emit generic `search({query: ...})` even when the exposed built-in is grep(pattern).
        // Repair the schema once at the boundary instead of making the model burn recovery turns on the same error.
        if ("grep".equals(canonicalTool) && !obj.hasNonNull("pattern")) {
            for (String candidate : List.of("query", "text", "term", "search", "needle")) {
                if (obj.hasNonNull(candidate) && !obj.path(candidate).asText("").isBlank()) {
                    obj.set("pattern", obj.path(candidate));
                    break;
                }
            }
        }
        if ("regex_search".equals(requested)) {
            if (!obj.hasNonNull("pattern") && obj.hasNonNull("regex") && obj.path("regex").isTextual()) {
                obj.set("pattern", obj.path("regex"));
            }
            obj.put("regex", true);
        }
        if ("list".equals(canonicalTool) && !obj.hasNonNull("path") && obj.hasNonNull("prefix")) obj.set("path", obj.path("prefix"));
        if ("glob".equals(canonicalTool) && !obj.hasNonNull("pattern")) {
            for (String candidate : List.of("query", "glob", "pathPattern")) {
                if (obj.hasNonNull(candidate) && !obj.path(candidate).asText("").isBlank()) {
                    obj.set("pattern", obj.path(candidate));
                    break;
                }
            }
        }
        if ("read_file_range".equals(requested) && !obj.has("endLine")) obj.put("endLine", 200);
        if ("todowrite".equals(canonicalTool) && !obj.has("items") && obj.has("todos")) obj.set("items", obj.path("todos"));
        if ("todo_update".equals(canonicalTool)) {
            if (!obj.has("index") && obj.has("id")) obj.set("index", obj.path("id"));
            if (!obj.has("status") && obj.has("state")) obj.set("status", obj.path("state"));
        }
        if ("apply_patch".equals(canonicalTool) && !obj.has("patch") && obj.hasNonNull("input") && obj.path("input").isTextual()) {
            obj.set("patch", obj.path("input"));
        }
        return obj;
    }

    private String setTodos(AgentRunService.AgentRun run, List<String> items) {
        if (run.planLocked()) {
            throw new IllegalStateException("Approved sequential plan is locked. Use todo_update only on active step " + run.activePlanIndex());
        }
        run.setPlan(items);
        return "Todos updated:\n" + run.planText();
    }

    private String updateTodo(AgentRunService.AgentRun run, JsonNode args) {
        int index = args == null ? 0 : args.path("index").asInt(0);
        if (index < 1) throw new IllegalArgumentException("Todo index must be >= 1");
        run.updatePlan(index, requiredText(args, "status"), text(args, "note"));
        return "Todos updated:\n" + run.planText();
    }

    private String discoverWorkItems(AgentWorkspaceService.Workspace ws, AgentRunService.AgentRun run, JsonNode args) throws Exception {
        String mode = requiredText(args, "mode").toLowerCase(Locale.ROOT);
        String query = requiredText(args, "query");
        int max = Math.max(1, Math.min(5_000, args.path("maxItems").asInt(2_000)));
        List<String> items = workspaces.discoverWorkItems(ws, mode, query, args.path("regex").asBoolean(false), max);
        if (items.isEmpty()) throw new IllegalStateException("Work-item discovery produced no items for " + mode + ": " + query);
        run.initializeWorkItems(items, args.path("batchSize").asInt(run.workItemBatchSize()));
        return "Discovered and initialized " + items.size() + " durable work items without replaying the full inventory through model context.\n" +
                run.workItemsText("", 0, 20);
    }

    private String initializeWorkItems(AgentRunService.AgentRun run, JsonNode args) {
        List<String> items = stringList(args, "items");
        if (items.isEmpty()) throw new IllegalArgumentException("At least one work item is required");
        run.initializeWorkItems(items, args.path("batchSize").asInt(run.workItemBatchSize()));
        return "Large-task work-item ledger initialized.\n" + run.workItemsText("", 0, 50);
    }

    private String addWorkItems(AgentRunService.AgentRun run, JsonNode args) {
        List<String> items = stringList(args, "items");
        if (items.isEmpty()) throw new IllegalArgumentException("At least one work item is required");
        run.addWorkItems(items);
        return "Work items added.\n" + run.workItemsText("", 0, 50);
    }

    private String updateWorkItems(AgentRunService.AgentRun run, JsonNode args) {
        List<String> ids = stringList(args, "ids");
        run.updateWorkItems(ids, requiredText(args, "status"), text(args, "note"));
        return "Work items updated.\n" + run.workItemsText("", 0, 50);
    }

    private int progressForTool(String tool, AgentRunService.AgentRun run) {
        if (tool == null) return 18;
        if (Set.of("edit", "write", "copy", "move", "delete", "apply_patch", "resource_edit", "resource_write", "resource_delete", "resource_copy", "resource_move").contains(tool)) return 48;
        if (Set.of("build", "test", "check", "resource_build", "resource_test", "resource_check").contains(tool)) return 72;
        if (Set.of("bash", "resource_bash", "process_start", "process_status", "process_output", "process_stop", "http_request").contains(tool)) return run.mutationRevision() > 0 ? 68 : 36;
        if ("workspace_checkpoint".equals(tool)) return 56;
        if ("workspace_rollback".equals(tool)) return 58;
        if (Set.of("work_items_discover","work_items_init","work_items_add","work_items_update").contains(tool)) return 52;
        if (Set.of("work_items_read","verification_failures").contains(tool)) return run.mutationRevision() > 0 ? 66 : 28;
        if (Set.of("workspace_status", "workspace_diff").contains(tool)) return 84;
        if ("task".equals(tool)) return 30;
        if (tool.startsWith("mcp__") || "lsp".equals(tool) || "lsp_status".equals(tool)) return run.mutationRevision() > 0 ? 64 : 32;
        return run.mutationRevision() > 0 ? 62 : 24;
    }

    private String phaseForTool(String tool) {
        if (tool == null) return "working";
        if (Set.of("edit", "write", "copy", "move", "delete", "apply_patch", "resource_edit", "resource_write", "resource_delete", "resource_copy", "resource_move").contains(tool)) return "editing";
        if (Set.of("build", "test", "check", "resource_build", "resource_test", "resource_check").contains(tool)) return "verifying";
        if (Set.of("bash", "resource_bash", "process_start", "process_status", "process_output", "process_stop", "http_request").contains(tool)) return "executing";
        if (Set.of("workspace_checkpoint","workspace_rollback","work_items_discover","work_items_init","work_items_add","work_items_read","work_items_update","verification_failures").contains(tool)) return "large_task";
        if (Set.of("workspace_status", "workspace_diff").contains(tool)) return "reviewing";
        if ("task".equals(tool)) return "delegating";
        return "inspecting";
    }

    private void observeRun(AgentWorkspaceService.Workspace ws, AgentRunService.AgentRun run, String tool, JsonNode args, String result) {
        run.recordPlanToolActivity(tool, summarizeResult(tool, result));
        if (isMutationTool(tool)) {
            if (directMutationChanged(result)) {
                List<String> changedPaths = mutationPaths(tool, args);
                run.recordTouchedPaths(changedPaths);
                run.markMutation(mutationNeedsVerification(tool, args));
                // Direct edit/write/patch tools already tell us exactly which paths changed. Refresh those entries
                // in-place instead of invalidating and rebuilding the whole workspace index on the next model turn.
                if ("workspace_rollback".equals(tool)) workspaceRetrieval.invalidate(ws);
                else workspaceRetrieval.refreshPaths(ws, changedPaths);
                clearActiveContextCache(run);
                run.updateActivity("editing", "Workspace changes applied");
            } else {
                run.updateActivity("editing", "Requested edit already matched the workspace; no new revision created");
            }
        } else if ("resource_bash".equals(tool) && result != null && result.contains("resourceChanged=true")) {
            run.markMutation(true);
            // Shell/resource commands may mutate unknown paths, so full invalidation remains the safe fallback.
            workspaceRetrieval.invalidate(ws);
            clearActiveContextCache(run);
        } else if ("bash".equals(tool) && result != null && result.contains("workspaceChanged=true")) {
            // Shell commands are intentionally unrestricted within the selected workspace and may edit files.
            // Any detected shell mutation creates a new revision that must be verified before completion.
            run.markMutation(true);
            workspaceRetrieval.invalidate(ws);
            clearActiveContextCache(run);
        }
        if ("workspace_diff".equals(tool)) run.markDiffReview();
        if (isVerifier(tool, args)) {
            boolean success = result != null && (result.startsWith("exitCode=0;") || httpVerificationSuccess(result));
            run.markVerificationAttempt(success, summarizeResult(tool, result));
            if (success) {
                if (!run.largeTaskMode() || run.activePlanIndex() == run.planSize()) run.clearVerificationFailures();
            } else run.recordVerificationFailures(result);
            run.updateActivity(success ? "verified" : "fixing",
                    success ? "Verification passed" : "Verification failed; diagnosing and fixing" +
                            (run.largeTaskMode() ? " from the captured failure queue" : ""));
        }
    }

    private boolean isVerifier(String tool, JsonNode args) {
        return Set.of("build", "test", "check", "resource_build", "resource_test", "resource_check").contains(tool)
                || (("bash".equals(tool) || "resource_bash".equals(tool) || "http_request".equals(tool))
                && args != null && args.path("verification").asBoolean(false));
    }

    private boolean looksLikeBlockedFinal(String raw) {
        if (raw == null || raw.isBlank()) return false;
        String low = raw.stripLeading().toLowerCase(Locale.ROOT);
        while (low.startsWith(">")) low = low.substring(1).stripLeading();
        return low.startsWith("blocked:") || low.startsWith("**blocked:**") || low.startsWith("**status: blocked**")
                || low.startsWith("status: blocked");
    }

    private boolean externalVerificationBlocker(String lastVerification) {
        if (lastVerification == null || lastVerification.isBlank()) return false;
        String low = lastVerification.toLowerCase(Locale.ROOT);
        return low.contains("unable to start command")
                || low.contains("cannot run program")
                || low.contains("createprocess error")
                || low.contains("being used by another process")
                || low.contains("sharing violation")
                || low.contains("access is denied")
                || low.contains("permission denied")
                || low.contains("operation not permitted")
                || low.contains("no space left on device")
                || low.contains("not enough storage");
    }

    private boolean httpVerificationSuccess(String result) {
        if (result == null || !result.startsWith("statusCode=")) return false;
        int semi = result.indexOf(';');
        String value = semi < 0 ? result.substring("statusCode=".length()) : result.substring("statusCode=".length(), semi);
        try {
            int code = Integer.parseInt(value.trim());
            return code >= 200 && code < 400;
        } catch (Exception ignored) { return false; }
    }

    private boolean requiresCurrentRevisionVerification(AgentRunService.AgentRun run) {
        return run.verificationRequired() || (run.largeTaskMode() && run.hasVerificationFailures());
    }

    private List<String> mutationPaths(String tool, JsonNode args) {
        if (args == null || args.isMissingNode() || args.isNull()) return List.of();
        LinkedHashSet<String> paths = new LinkedHashSet<>();
        if (Set.of("edit", "write", "delete", "resource_edit", "resource_write", "resource_delete").contains(tool)) {
            String path = text(args, "path");
            if (!path.isBlank()) paths.add(path);
        } else if (Set.of("resource_copy", "resource_move").contains(tool)) {
            for (String key : List.of("fromPath", "toPath")) { String path = text(args, key); if (!path.isBlank()) paths.add(path); }
        } else if (Set.of("copy", "move").contains(tool)) {
            for (String key : List.of("from", "to")) { String path = text(args, key); if (!path.isBlank()) paths.add(path); }
        } else if ("apply_patch".equals(tool)) {
            if (args.path("changes").isArray()) {
                for (JsonNode change : args.path("changes")) {
                    String path = change.path("path").asText("").strip();
                    if (!path.isBlank()) paths.add(path);
                }
            }
            String patch = args.path("patch").asText("");
            if (!patch.isBlank()) {
                java.util.regex.Matcher m = java.util.regex.Pattern.compile("(?m)^(?:\\+\\+\\+|---)\\s+(?:[ab]/)?([^\\t\\r\\n]+)").matcher(patch);
                while (m.find() && paths.size() < 30) {
                    String path = m.group(1).strip();
                    if (!path.equals("/dev/null") && !path.isBlank()) paths.add(path);
                }
            }
        }
        return List.copyOf(paths);
    }

    private boolean mutationNeedsVerification(String tool, JsonNode args) {
        List<String> paths = new ArrayList<>();
        if (Set.of("edit", "write", "delete", "resource_edit", "resource_write", "resource_delete").contains(tool)) paths.add(text(args, "path"));
        else if (Set.of("resource_copy", "resource_move").contains(tool)) { paths.add(text(args, "fromPath")); paths.add(text(args, "toPath")); }
        else if (Set.of("copy", "move").contains(tool)) { paths.add(text(args, "from")); paths.add(text(args, "to")); }
        else if ("apply_patch".equals(tool) && args != null) {
            if (args.path("changes").isArray()) {
                for (JsonNode change : args.path("changes")) paths.add(change.path("path").asText(""));
            }
            if (!text(args, "patch").isBlank()) return true;
        }
        for (String path : paths) {
            String p = path == null ? "" : path.replace('\\','/').toLowerCase(Locale.ROOT);
            String name = p.substring(p.lastIndexOf('/') + 1);
            if (Set.of("pom.xml", "package.json", "build.gradle", "build.gradle.kts", "settings.gradle", "settings.gradle.kts",
                    "pyproject.toml", "setup.py", "requirements.txt", "go.mod", "cargo.toml", "makefile", "cmakelists.txt",
                    "dockerfile", "compose.yml", "compose.yaml", "application.properties", "application.yml", "application.yaml").contains(name)) return true;
            int dot = name.lastIndexOf('.');
            String ext = dot < 0 ? "" : name.substring(dot + 1);
            if (Set.of("java","kt","kts","groovy","scala","js","jsx","ts","tsx","mjs","cjs","py","rb","php","go","rs",
                    "c","cc","cpp","cxx","h","hpp","cs","fs","swift","dart","vue","svelte","jsp","html","css","scss","less",
                    "xml","json","yaml","yml","toml","properties","gradle","sql","graphql","proto","sh","bash","zsh","ps1","bat","cmd",
                    "tf","hcl","bzl","sbt","ex","exs","clj","cljs","zig","hs","erl").contains(ext)) return true;
        }
        return false;
    }

    private String verificationRequiredPrompt(AgentRunService.AgentRun run) {
        String last = run.lastVerification().isBlank() ? "No verifier has successfully run for this revision yet." :
                "Last verifier: " + run.lastVerification();
        return "[RUNTIME_STEERING:verification-required]\nThe live workspace has changed and the current revision is not successfully verified. " + last + " " +
                "Do not repeat the previous final response and do not finish as completed yet. Your next useful action must produce new verification evidence or a fix. " +
                "Use build/test/check for the primary workspace, resource_build/resource_test/resource_check for an additional project, bash/resource_bash with verification=true, or http_request with verification=true as appropriate. " +
                "If verification fails, inspect the real error, fix the cause, and rerun. Continue until the current revision passes. " +
                "Only return blocked if a genuine external/environment/permission blocker prevents verification.";
    }

    private String permissionFor(String tool, ChatSettings settings) {
        if (tool != null && tool.startsWith("mcp__")) return settings.mcpPermission();
        if ("task".equals(tool)) return settings.taskPermission();
        if ("lsp".equals(tool) || "lsp_status".equals(tool)) return settings.lspPermission();
        if (Set.of("edit", "write", "copy", "move", "delete", "apply_patch", "workspace_rollback", "resource_edit", "resource_write", "resource_delete", "resource_copy", "resource_move").contains(tool)) return settings.editPermission();
        if (Set.of("bash", "build", "test", "check", "resource_bash", "resource_build", "resource_test", "resource_check", "process_start", "process_stop", "http_request").contains(tool)) return settings.shellPermission();
        if (Set.of("workspace_status", "workspace_diff").contains(tool)) return settings.reviewPermission();
        return "allow";
    }

    private String decorateFinalMessage(String message, AgentWorkspaceService.Workspace ws,
                                        int totalWorkspaceChanges, boolean hasResourceChanges,
                                        AgentRunService.AgentRun run, String status) {
        String result = message == null || message.isBlank() ? "Agent run completed." : message.strip();
        if (totalWorkspaceChanges > 0) {
            if (hasResourceChanges) {
                result += "\n\n> Direct resources: " + totalWorkspaceChanges + " file(s) were changed across the primary workspace and explicitly supplied writable resources.";
            } else {
                result += "\n\n> Direct workspace: " + totalWorkspaceChanges + " file(s) were changed directly under `" + ws.root() + "`.";
            }
        }
        if (run.lastVerificationAttemptRevision() >= 0 && !run.lastVerification().isBlank()) {
            result += "\n\n> Last recorded verifier: " + run.lastVerification();
        }
        if (run.modelCalls() > 0) {
            String usage = run.providerTotalTokens() > 0
                    ? run.providerTotalTokens() + " provider-reported tokens"
                    : "provider usage unavailable; runtime context estimates were used";
            result += "\n\n> Agent token management: " + usage + "; " + run.modelCalls() + " model call(s); " +
                    run.compactions() + " context compaction(s); current active context ~" + run.currentContextTokens() +
                    "/" + run.contextWindowTokens() + " tokens.";
        }
        if ("blocked".equals(status) && !result.toLowerCase(Locale.ROOT).contains("blocked")) {
            result = "**Status: Blocked**\n\n" + result;
        }
        return result;
    }

    private void appendNativeAssistantTurn(List<Map<String, Object>> messages,
                                           List<OpenAiCompatibleClient.AgentToolCall> calls,
                                           String assistantContent) {
        List<Map<String, Object>> toolCalls = new ArrayList<>();
        for (OpenAiCompatibleClient.AgentToolCall call : calls) {
            Map<String, Object> function = new LinkedHashMap<>();
            function.put("name", call.name());
            try { function.put("arguments", objectMapper.writeValueAsString(sanitizeHistoricalToolArgs(call.arguments()))); }
            catch (Exception ignored) { function.put("arguments", "{}"); }
            Map<String, Object> item = new LinkedHashMap<>();
            item.put("id", call.id());
            item.put("type", "function");
            item.put("function", function);
            toolCalls.add(item);
        }
        Map<String, Object> assistant = new LinkedHashMap<>();
        assistant.put("role", "assistant");
        if (assistantContent != null && !assistantContent.isBlank()) assistant.put("content", assistantContent);
        assistant.put("tool_calls", toolCalls);
        messages.add(assistant);
    }

    private void appendNativeToolResult(List<Map<String, Object>> messages, String callId, String tool, String result) {
        Map<String, Object> toolResult = new LinkedHashMap<>();
        toolResult.put("role", "tool");
        toolResult.put("tool_call_id", callId);
        toolResult.put("name", tool);
        toolResult.put("content", clip(result));
        messages.add(toolResult);
    }

    private void appendFallbackToolTranscript(List<Map<String, Object>> messages, String raw, String tool, String result) {
        if (raw != null && !raw.isBlank()) messages.add(Map.of("role", "assistant", "content", clipHistoricalAssistant(raw)));
        messages.add(Map.of("role", "user", "content", "TOOL RESULT for " + tool + ":\n" + clip(result) +
                "\n\nContinue the same task. Use another tool if needed, otherwise return the final JSON response."));
    }

    private JsonNode parseEnvelope(String raw) {
        if (raw == null || raw.isBlank()) return null;
        String text = raw.trim();
        if (text.startsWith("```")) {
            int firstNl = text.indexOf('\n'), last = text.lastIndexOf("```");
            if (firstNl >= 0 && last > firstNl) text = text.substring(firstNl + 1, last).trim();
        }
        try { return objectMapper.readTree(text); } catch (Exception ignored) { }
        int start = text.indexOf('{');
        if (start < 0) return null;
        boolean inString = false, escape = false;
        int depth = 0;
        for (int i = start; i < text.length(); i++) {
            char c = text.charAt(i);
            if (inString) {
                if (escape) escape = false;
                else if (c == '\\') escape = true;
                else if (c == '"') inString = false;
                continue;
            }
            if (c == '"') { inString = true; continue; }
            if (c == '{') depth++;
            else if (c == '}' && --depth == 0) {
                try { return objectMapper.readTree(text.substring(start, i + 1)); }
                catch (Exception ignored) { return null; }
            }
        }
        return null;
    }

    private Map<String, Object> stepEvent(int step, String tool, String detail, String status,
                                          JsonNode args, String output, String approvalId) {
        Map<String, Object> event = new LinkedHashMap<>();
        event.put("step", step);
        event.put("tool", tool == null || tool.isBlank() ? "agent" : tool);
        event.put("detail", safe(detail));
        event.put("status", status);
        if (args != null && !args.isMissingNode() && !args.isNull()) event.put("args", args);
        if (output != null && !output.isBlank()) event.put("output", output);
        if (approvalId != null) event.put("approvalId", approvalId);
        return event;
    }

    private String describeTool(String tool, JsonNode args) {
        if (Set.of("read", "read_chunk", "file_info", "file_index", "write", "edit", "delete").contains(tool)) return tool + " " + text(args, "path");
        if (Set.of("move", "copy").contains(tool)) return tool + " " + text(args, "from") + " -> " + text(args, "to");
        if ("apply_patch".equals(tool)) return "Apply direct multi-file workspace change";
        if ("grep".equals(tool)) return "Search workspace for " + text(args, "pattern");
        if ("glob".equals(tool)) return "Glob " + text(args, "pattern");
        if ("bash".equals(tool)) return "Run " + text(args, "command");
        if (tool != null && tool.startsWith("resource_")) {
            String alias = text(args, "alias");
            if (Set.of("resource_read", "resource_chunk", "resource_info", "resource_index", "resource_edit", "resource_write", "resource_delete").contains(tool)) return tool + " @" + alias + "/" + text(args, "path");
            if (Set.of("resource_copy", "resource_move").contains(tool)) return tool + " @" + text(args, "fromAlias") + "/" + text(args, "fromPath") + " -> @" + text(args, "toAlias") + "/" + text(args, "toPath");
            if ("resource_grep".equals(tool)) return "Search @" + alias + " for " + text(args, "pattern");
            if ("resource_bash".equals(tool)) return "Run in @" + alias + ": " + text(args, "command");
            return tool + (alias.isBlank() ? "" : " @" + alias);
        }
        if ("process_start".equals(tool)) return "Start background process: " + text(args, "command");
        if (Set.of("process_status", "process_output", "process_stop").contains(tool)) return tool + " " + text(args, "processId");
        if ("http_request".equals(tool)) return firstNonBlank(text(args, "method"), "GET") + " " + text(args, "url");
        if ("workspace_profile".equals(tool)) return "Read durable workspace profile";
        if ("workspace_profile_refresh".equals(tool)) return "Refresh durable workspace profile";
        if ("instruction_catalog".equals(tool)) return "List project instruction files";
        if ("instructions_for".equals(tool)) return "Load instructions for " + text(args, "path");
        if ("attachment_list".equals(tool)) return "List uploaded conversation attachments";
        if ("attachment_read".equals(tool)) return "Read uploaded attachment " + text(args, "fileId");
        if ("attachment_search".equals(tool)) return "Search attachments for " + text(args, "query");
        if ("skill_catalog".equals(tool)) return "List available skills";
        if ("skill".equals(tool)) return "Load skill " + text(args, "name");
        if ("agent_catalog".equals(tool)) return "List available subagents";
        if ("task".equals(tool)) return "Delegate to " + text(args, "agent") + ": " + text(args, "prompt");
        if ("mcp_status".equals(tool)) return "Inspect MCP server/tool status";
        if (tool != null && tool.startsWith("mcp__")) return "Call external MCP tool " + tool;
        if (Set.of("build", "test", "check").contains(tool)) return tool + " in " + (text(args, "cwd").isBlank() ? "." : text(args, "cwd"));
        return tool;
    }

    private boolean isFailedCommandResult(String tool, String result) {
        if (Set.of("bash", "build", "test", "check", "resource_bash", "resource_build", "resource_test", "resource_check").contains(tool)) {
            return result != null && !result.startsWith("exitCode=0;");
        }
        if ("http_request".equals(tool) && result != null && result.startsWith("statusCode=")) {
            return !httpVerificationSuccess(result);
        }
        return false;
    }

    private boolean isOutputTruncated(String finishReason) {
        String value = finishReason == null ? "" : finishReason.trim().toLowerCase(Locale.ROOT);
        return value.equals("length") || value.equals("max_tokens") || value.equals("max_output_tokens") || value.contains("token_limit");
    }

    private boolean isContextWindowFailure(Exception e) {
        String text = (e.getMessage() == null ? "" : e.getMessage()).toLowerCase(Locale.ROOT);
        return text.contains("context length") || text.contains("context window") || text.contains("maximum context") ||
                text.contains("too many tokens") || text.contains("token limit") || text.contains("prompt is too long") ||
                text.contains("input too long");
    }

    private boolean verificationSteeringBlocked(Map<String,Integer> counters, AgentRunService.AgentRun run) {
        String key = run.mutationRevision() + "|" + run.lastVerificationAttemptRevision() + "|" +
                run.lastSuccessfulVerificationRevision() + "|" + Integer.toHexString(run.lastVerification().hashCode());
        int count = counters.merge(key, 1, Integer::sum);
        if (count > MAX_CONSECUTIVE_NON_ACTIONABLE_TURNS) {
            run.markRepeatedCallPrevented();
            return true;
        }
        return false;
    }

    private record DecisionLine(String token, String summary) { }

    /**
     * Providers do not always obey an exact first-line decision format. Accept harmless punctuation such as
     * `APPROVED - reason`, `SATISFIED: reason`, or Markdown emphasis while still requiring a known decision token.
     */
    private DecisionLine parseDecisionLine(String raw, String... allowedTokens) {
        if (raw == null || raw.isBlank()) return new DecisionLine("", "");
        String first = raw.lines().findFirst().orElse("").trim();
        String cleaned = first.replace("`", "").replace("**", "").trim();
        String upper = cleaned.toUpperCase(Locale.ROOT);
        String matched = "";
        String inline = "";
        if (allowedTokens != null) {
            for (String candidate : allowedTokens) {
                if (candidate == null || candidate.isBlank()) continue;
                String expected = candidate.trim().toUpperCase(Locale.ROOT);
                if (!upper.startsWith(expected)) continue;
                if (upper.length() > expected.length()) {
                    char boundary = upper.charAt(expected.length());
                    if (!(Character.isWhitespace(boundary) || boundary == ':' || boundary == '-' || boundary == '–' || boundary == '—' || boundary == '.')) continue;
                }
                matched = expected;
                inline = cleaned.substring(Math.min(cleaned.length(), expected.length()))
                        .replaceFirst("^[\\s:–—.\\-]+", "").trim();
                break;
            }
        }
        String rest = raw.lines().skip(1).reduce("", (a,b) -> a.isBlank() ? b : a + "\n" + b).strip();
        String summary = inline.isBlank() ? rest : (rest.isBlank() ? inline : inline + "\n" + rest);
        return new DecisionLine(matched, summary);
    }

    private boolean decisionTokenMatches(String raw, String expected) {
        return expected != null && expected.equals(parseDecisionLine(raw, expected).token());
    }

    private String normalizeNoProgress(String raw) {
        if (raw == null || raw.isBlank()) return "<blank>";
        String normalized = raw.toLowerCase(Locale.ROOT).replaceAll("\\s+", " ").trim();
        if (normalized.length() > 1200) normalized = normalized.substring(0, 1200);
        return normalized;
    }

    /**
     * Adaptive recovery prompt. It deliberately rotates strategy rather than replaying a static warning, because
     * repeated steering text can reinforce the same model failure mode. The agent still has freedom to choose the
     * actual implementation; these are recovery hints, not a second rulebook.
     */
    private String recoveryDirective(int attempt, int maxAttempts, boolean duplicate, String raw) {
        String low = raw == null ? "" : raw.toLowerCase(Locale.ROOT);
        String specific;
        if (low.contains("unknown resource alias")) {
            specific = "Use resource_catalog to confirm real aliases. If the @ token is framework/CLI syntax such as @rerun.txt, @failed.txt or an argument file in the active workspace, do not treat it as a resource alias; use ordinary workspace tools with the filename/path without the leading @ marker.";
        } else if (low.contains("unknown tool") || low.contains("tool error")) {
            specific = "Use an exact built-in tool name now. For code/text search use grep; use glob for path matching; tool_search is only for discovering deferred MCP tools.";
        } else if (low.contains("oldtext") || low.contains("was not found") || low.contains("pattern is required")) {
            specific = "Re-read the exact current file region, then edit using current text. If exact replacement is brittle, use a structured apply_patch or a complete write only after reading the file.";
        } else if (low.contains("apply_patch") || low.contains("non-empty changes") || low.contains("patch")) {
            specific = "Recover the patch with current file evidence. apply_patch accepts either a structured changes array or OpenAI-style *** Begin Patch text; edit/write are valid fallbacks.";
        } else if (low.contains("not found") || low.contains("no such file") || low.contains("cannot find")) {
            specific = "Do not guess the path. Inspect the live workspace/resource catalog, then glob/list/read the resolved location before acting.";
        } else if (low.contains("compile") || low.contains("test") || low.contains("exitcode=") || low.contains("failed")) {
            specific = "Use the latest failure output as evidence: identify the first actionable root cause, change the implementation, then rerun the smallest relevant verifier.";
        } else {
            specific = switch (Math.floorMod(attempt - 1, 5)) {
                case 0 -> "Inspect a smaller, directly relevant part of the workspace and take one concrete action from that evidence.";
                case 1 -> "Change the investigation route: search by symbol/text or file pattern instead of repeating the previous prose or call.";
                case 2 -> "Choose the simplest direct implementation path that satisfies the approved plan, then verify it.";
                case 3 -> "Use a different available tool or different arguments that can produce new evidence on the current workspace revision.";
                default -> "Re-check the resolved workspace and the user's requested outcome, then continue with the shortest evidence-driven fix-and-verify loop.";
            };
        }
        return "[RUNTIME_STEERING:recovery]\nRECOVERY " + attempt + "/" + maxAttempts + ". " +
                (duplicate ? "Do not repeat the prior response or identical tool call. " : "The previous turn made no actionable progress. ") +
                specific + " Continue the approved plan autonomously. Your next turn should use real tools unless the task is already complete after verified tool activity.";
    }

    private String recoveryExhaustedMessage(long attempts, int perModelLimit, AgentRunService.AgentRun run, String finalReason) {
        String reason = finalReason == null || finalReason.isBlank() ? "Focused recovery could not be initialized." : finalReason.strip();
        return "Execution stopped because the runtime could not initialize another focused recovery cycle. " +
                "This is not a no-progress retry-budget stop; repeated model stalls are recoverable without a fixed ceiling. " +
                "Last local stall count: " + attempts + " (re-anchor threshold " + perModelLimit + "). Focused recovery cycles completed: " +
                run.recoveryReplans() + ". Completed plan steps and current workspace changes were preserved. Detail: " + reason;
    }

    private String effectiveModel(AgentRunService.AgentRun run, ChatSettings settings) {
        String active = run == null ? "" : run.activeModel();
        if (active != null && !active.isBlank()) return active;
        return settings == null || settings.model() == null ? "" : settings.model().trim();
    }

    private boolean switchToLargerContextModel(AgentRunService.AgentRun run, ChatSettings settings,
                                               Consumer<Map<String,Object>> onStep, int step, String reason) {
        if (run == null || settings == null) return false;
        List<String> pool = run.modelPool();
        String current = run.activeModel();
        int currentIndex = pool.indexOf(current);
        if (currentIndex < 0) currentIndex = 0;
        int currentWindow = settings.safeContextWindowTokens(current);
        String best = null;
        int bestWindow = currentWindow;
        for (int i = currentIndex + 1; i < pool.size(); i++) {
            String candidate = pool.get(i);
            int window = settings.safeContextWindowTokens(candidate);
            if (window > bestWindow) { best = candidate; bestWindow = window; }
        }
        if (best == null || !run.switchToModel(best, "Context failover: " + reason)) return false;
        onStep.accept(stepEvent(step, "model_failover",
                "Context limit: switching " + current + " → " + best + " (" + currentWindow + " → " + bestWindow + " tokens) while preserving the active step",
                "success", null, clipUi(reason), null));
        return true;
    }

    private boolean switchToNextModel(AgentRunService.AgentRun run, Consumer<Map<String,Object>> onStep, int step, String reason) {
        String previous = run.activeModel();
        run.recordExecutionFailure((previous == null || previous.isBlank() ? "executor" : previous) + ": " + safe(reason));
        if (!run.switchToNextModel(reason)) return false;
        String next = run.activeModel();
        onStep.accept(stepEvent(step, "model_failover",
                "Switching model " + (previous == null || previous.isBlank() ? "[unknown]" : previous) + " → " + next +
                        "; preserving approved plan step " + run.activePlanIndex(),
                "success", null, clipUi(reason), null));
        return true;
    }

    private int providerRecoveryActivationLimit(AgentRunService.AgentRun run) {
        int poolSize = run == null ? 0 : run.modelPool().size();
        return Math.max(1, poolSize) * PROVIDER_MODEL_CYCLES;
    }

    /** Cyclic provider failover: primary -> fallback 1 -> fallback 2 -> primary. Caller enforces the 3-cycle budget. */
    private boolean switchToNextModelCyclic(AgentRunService.AgentRun run, Consumer<Map<String,Object>> onStep, int step, String reason) {
        if (run == null || run.modelPool().size() < 2) return false;
        String previous = run.activeModel();
        run.recordExecutionFailure((previous == null || previous.isBlank() ? "executor" : previous) + ": " + safe(reason));
        if (!run.switchToNextModelCyclic(reason)) return false;
        String next = run.activeModel();
        onStep.accept(stepEvent(step, "model_failover",
                "Provider recovery: " + (previous == null || previous.isBlank() ? "[unknown]" : previous) + " → " + next +
                        "; preserving the same run, workspace and approved plan step " + run.activePlanIndex(),
                "success", null, clipUi(reason), null));
        return true;
    }

    private long providerRetryDelayMs(int retryNumber) {
        return Math.min(4_000L, 500L << Math.min(3, Math.max(0, retryNumber - 1)));
    }

    private String providerFailureDetail(Throwable failure) {
        if (failure == null) return "Provider request failed";
        Throwable cursor = failure;
        for (int depth = 0; depth < 5 && cursor != null; depth++, cursor = cursor.getCause()) {
            String message = cursor.getMessage();
            if (message != null && !message.isBlank()) {
                return safe(cursor.getClass().getSimpleName() + ": " + message);
            }
        }
        return safe(failure.getClass().getSimpleName());
    }

    private String modelFailoverContinuation(AgentRunService.AgentRun run) {
        String failures = run.failureMemoryText();
        return "[RUNTIME_STEERING:model-failover]\nMODEL FAILOVER CONTINUATION. Active model is now '" + run.activeModel() + "'. Preserve all prior workspace evidence and tool results. " +
                "Do not restart the task or recreate the plan. Continue only approved plan step " + run.activePlanIndex() +
                (run.activePlanStepText().isBlank() ? "." : ": " + run.activePlanStepText()) +
                " When the step is genuinely complete, use todo_update for that active index; the runtime will unlock the next step." +
                (failures.isBlank() ? "" : "\n\nFAILED APPROACHES/OUTCOMES ALREADY OBSERVED — choose a materially different strategy:\n" + failures);
    }

    /**
     * High-signal per-step execution contract. This is intentionally small and re-injected at step boundaries so a
     * single strong model can behave like a coding agent without carrying the entire planning transcript forever.
     */
    private String activeStepContract(AgentRunService.AgentRun run) {
        if (run == null || run.activePlanIndex() <= 0) return "[RUNTIME_STEERING:no-active-step]";
        String failures = run.failureMemoryText();
        return "[RUNTIME_STEERING:active-step-contract]\n" +
                "ACTIVE STEP " + run.activePlanIndex() + ":\n" + run.activePlanStepText() +
                "\n\nEXECUTION CONTRACT:\n" +
                "1. Ground yourself in the live workspace before editing. If a class/method/config/signature is relevant, read/search the exact current implementation instead of assuming it.\n" +
                "2. Make the smallest coherent change that satisfies this step; do not perform later plan steps.\n" +
                "3. Use tool output as the source of truth. If an edit/tool/command fails, change strategy from the error instead of repeating the same call.\n" +
                "4. For implementation steps, prove completion from live workspace evidence/diff and DO NOT build/test/check after each edit. Reserve compile/test/check/run for the final verification step after all requested changes are in place, unless the user explicitly requested an intermediate run or a concrete blocker requires it.\n" +
                "5. When an implementation step is evidenced complete, call todo_update for the active index. In large-task mode, keep the work-item ledger current and resolve failed items before final completion. On the final verification step, only complete it after the latest workspace revision has a successful appropriate verifier (or report a genuine external blocker).\n" +
                (failures.isBlank() ? "" : "\nDO NOT REPEAT THESE FAILED STRATEGIES/OUTCOMES:\n" + failures);
    }

    private String planContinuationPrompt(AgentRunService.AgentRun run, boolean verificationJustPassed) {
        String prefix = verificationJustPassed
                ? "The current workspace revision has passed verification. "
                : "The approved plan is still in progress. ";
        return "[RUNTIME_STEERING:plan-continuation]\n" + prefix + "Only step " + run.activePlanIndex() + " is unlocked: " + run.activePlanStepText() +
                ". Do not start a later step. If this active step's intended outcome is satisfied, call todo_update with index=" +
                run.activePlanIndex() + " and status=completed. Otherwise continue working on this step with real tools.";
    }

    private boolean isModelUnavailableFailure(Exception e) {
        String text = (e.getMessage() == null ? "" : e.getMessage()).toLowerCase(Locale.ROOT);
        return text.contains("model not found") || text.contains("unknown model") || text.contains("unsupported model") ||
                text.contains("model does not exist") || text.contains("invalid model") || text.contains("no such model") ||
                (text.contains("404") && text.contains("model"));
    }

    /**
     * Execute a specialized harness role on the run's currently active Agent model. If that provider/model call fails,
     * the same bounded cyclic fallback policy is used while preserving the role prompt, run, workspace and approved plan.
     */
    private OpenAiCompatibleClient.AgentCompletion completeRoleText(String apiKey, ChatRequest request,
                                                                     AgentRunService.AgentRun run, String roleModel,
                                                                     ModelCapabilityRegistry.Role role, int maxOut,
                                                                     List<Map<String,Object>> prompt, int step,
                                                                     Consumer<Map<String,Object>> onStep, String purpose) throws Exception {
        String executor = effectiveModel(run, request.settings());
        String selected = executor == null || executor.isBlank()
                ? (roleModel == null ? "" : roleModel.trim())
                : executor;
        if (selected.isBlank()) throw new IllegalStateException("No configured Agent model is available for " + purpose);

        List<Map<String,Object>> activePrompt = copyRolePrompt(prompt);
        int retriesOnActivation = 0;
        int modelActivations = 1;
        final int maxModelActivations = providerRecoveryActivationLimit(run);
        boolean overflowRecovered = false;

        while (true) {
            run.checkCancelled();
            String active = effectiveModel(run, request.settings());
            // Keep planning/validation on the run's active model. After provider failover, continue the exact same
            // role prompt on the newly active fallback model without recreating the plan/task.
            if (modelActivations > 1 && active != null && !active.isBlank()) selected = active;

            ContextWindowManager.ContextEstimate preflight = contextWindows.estimate(activePrompt, List.of(), request.settings(), selected);
            if (preflight.estimatedInputTokens() > preflight.inputLimitTokens()) {
                activePrompt = reduceRolePrompt(activePrompt, request.settings(), selected, run, purpose);
                ContextWindowManager.ContextEstimate reduced = contextWindows.estimate(activePrompt, List.of(), request.settings(), selected);
                onStep.accept(stepEvent(step, "context_compaction",
                        "Reduced " + purpose + " input before the model call: ~" + preflight.estimatedInputTokens() +
                                " → ~" + reduced.estimatedInputTokens() + " estimated tokens",
                        "success", null, null, null));
            }

            try {
                return llm.completeTextWithUsage(apiKey, request.settings().baseUrl(), selected, maxOut, activePrompt, run::cancelled);
            } catch (AgentCancelledException cancelled) {
                throw cancelled;
            } catch (Exception failure) {
                if (isContextWindowFailure(failure) && !overflowRecovered) {
                    List<Map<String,Object>> retryPrompt = reduceRolePrompt(activePrompt, request.settings(), selected, run, purpose);
                    ContextWindowManager.ContextEstimate before = contextWindows.estimate(activePrompt, List.of(), request.settings(), selected);
                    ContextWindowManager.ContextEstimate after = contextWindows.estimate(retryPrompt, List.of(), request.settings(), selected);
                    overflowRecovered = true;
                    if (after.estimatedInputTokens() < before.estimatedInputTokens()) {
                        activePrompt = retryPrompt;
                        onStep.accept(stepEvent(step, "context_compaction",
                                "Provider rejected " + purpose + " input size; continuing on " + selected + " with ~" +
                                        after.estimatedInputTokens() + " estimated tokens",
                                "success", null, null, null));
                        continue;
                    }
                }

                String error = providerFailureDetail(failure);
                run.recordExecutionFailure("Agent model/provider failure during " + purpose + " on " + selected + ": " + error);
                if (!isAuthenticationFailure(failure) && retriesOnActivation < PROVIDER_RETRIES_PER_MODEL_ACTIVATION) {
                    retriesOnActivation++;
                    onStep.accept(stepEvent(step, "model_retry",
                            "Retrying " + selected + " for " + purpose + " (retry " + retriesOnActivation + "/" + PROVIDER_RETRIES_PER_MODEL_ACTIVATION + ")",
                            "running", null, clipUi(error), null));
                    sleepCancellable(run, providerRetryDelayMs(retriesOnActivation));
                    continue;
                }

                if (!isAuthenticationFailure(failure) && modelActivations < maxModelActivations &&
                        switchToNextModelCyclic(run, onStep, step, purpose + ": " + error)) {
                    modelActivations++;
                    retriesOnActivation = 0;
                    overflowRecovered = false;
                    continue;
                }

                onStep.accept(stepEvent(step, "model_error",
                        "Agent model/provider recovery exhausted during " + purpose,
                        "error", null, clipUi(error), null));
                throw new ProviderModelException(selected, error, failure);
            }
        }
    }

    private List<Map<String,Object>> copyRolePrompt(List<Map<String,Object>> prompt) {
        List<Map<String,Object>> copy = new ArrayList<>();
        if (prompt == null) return copy;
        for (Map<String,Object> message : prompt) {
            copy.add(message == null ? new LinkedHashMap<>() : new LinkedHashMap<>(message));
        }
        return copy;
    }

    /**
     * Deterministic prompt reduction for no-tools role calls. Preserve system instructions and both ends of the
     * evidence-bearing messages. No summarizer/model call is used, so overflow recovery cannot recursively overload
     * the same provider.
     */
    private List<Map<String,Object>> reduceRolePrompt(List<Map<String,Object>> prompt, ChatSettings settings,
                                                       String model, AgentRunService.AgentRun run, String purpose) {
        List<Map<String,Object>> reduced = copyRolePrompt(prompt);
        contextWindows.pruneSupersededRuntimeSteering(reduced);
        contextWindows.pruneOldToolOutputs(reduced, settings, true);
        ContextWindowManager.CompactionResult compacted = contextWindows.compact(
                reduced, List.of(), settings, run, true, null, model);
        if (compacted.compacted()) {
            run.recordCompaction(compacted.estimatedTokensSaved(), "role-" + purpose + " " + compacted.reason());
        }

        // Two-message planning/validation prompts often have no legal transcript boundary to compact. Bound their
        // individual content directly while preserving task/instruction heads and newest evidence tails.
        int systemBudget = 7_000;
        int regularBudget = 14_000;
        for (int i = 0; i < reduced.size(); i++) {
            Map<String,Object> message = reduced.get(i);
            Object contentValue = message.get("content");
            if (!(contentValue instanceof String content) || content.isBlank()) continue;
            String roleName = String.valueOf(message.getOrDefault("role", ""));
            int budget = "system".equals(roleName) ? systemBudget : regularBudget;
            if (content.length() <= budget) continue;
            Map<String,Object> replacement = new LinkedHashMap<>(message);
            replacement.put("content", clipHeadTail(content, budget,
                    "[Role input clipped for provider-safe context; use live tools for exact workspace facts]"));
            reduced.set(i, replacement);
        }
        return reduced;
    }

    private OpenAiCompatibleClient.AgentCompletion completeTextForRun(String apiKey, ChatRequest request,
                                                                       AgentRunService.AgentRun run, int maxOut,
                                                                       List<Map<String,Object>> prompt, int step,
                                                                       Consumer<Map<String,Object>> onStep, String purpose) throws Exception {
        int retriesOnActivation = 0;
        int modelActivations = 1;
        final int maxModelActivations = providerRecoveryActivationLimit(run);
        while (true) {
            run.checkCancelled();
            String model = effectiveModel(run, request.settings());
            try {
                return llm.completeTextWithUsage(apiKey, request.settings().baseUrl(), model, maxOut, prompt, run::cancelled);
            } catch (AgentCancelledException cancelled) {
                throw cancelled;
            } catch (Exception e) {
                String error = providerFailureDetail(e);
                if (!isAuthenticationFailure(e) && retriesOnActivation < PROVIDER_RETRIES_PER_MODEL_ACTIVATION) {
                    retriesOnActivation++;
                    onStep.accept(stepEvent(step, "model_retry",
                            "Retrying " + model + " for " + purpose + " (retry " + retriesOnActivation + "/" + PROVIDER_RETRIES_PER_MODEL_ACTIVATION + ")",
                            "running", null, clipUi(error), null));
                    sleepCancellable(run, providerRetryDelayMs(retriesOnActivation));
                    continue;
                }
                if (!isAuthenticationFailure(e) && modelActivations < maxModelActivations &&
                        switchToNextModelCyclic(run, onStep, step, purpose + ": " + error)) {
                    modelActivations++;
                    retriesOnActivation = 0;
                    continue;
                }
                throw e;
            }
        }
    }

    private boolean isTransientModelFailure(Exception e) {
        String text = (e.getMessage() == null ? "" : e.getMessage()).toLowerCase(Locale.ROOT);
        return text.contains("429") || text.contains("500") || text.contains("502") || text.contains("503") ||
                text.contains("504") || text.contains("timeout") || text.contains("timed out") ||
                text.contains("connection reset") || text.contains("connection refused") || text.contains("temporarily unavailable");
    }

    /** Authentication/authorization failures are account/configuration blockers; cycling models only wastes tokens. */
    private boolean isAuthenticationFailure(Exception e) {
        String text = (e.getMessage() == null ? "" : e.getMessage()).toLowerCase(Locale.ROOT);
        return text.contains("401") || text.contains("403") || text.contains("unauthorized") ||
                text.contains("invalid api key") || text.contains("invalid_api_key") ||
                text.contains("authentication") || text.contains("forbidden");
    }

    private void sleepCancellable(AgentRunService.AgentRun run, long waitMs) throws InterruptedException {
        long deadline = System.nanoTime() + Duration.ofMillis(waitMs).toNanos();
        while (System.nanoTime() < deadline) {
            run.checkCancelled();
            Thread.sleep(Math.min(100L, Math.max(1L, waitMs)));
        }
    }

    private String canonicalArgs(JsonNode args) {
        try { return objectMapper.writeValueAsString(args); }
        catch (Exception ignored) { return String.valueOf(args); }
    }

    private String summarizeResult(String tool, String result) {
        if (result == null || result.isBlank()) return tool + " completed";
        String first = result.replace('\r', ' ').replace('\n', ' ').replaceAll("\\s+", " ").trim();
        return first.length() > 240 ? first.substring(0, 240) + "…" : first;
    }

    private String normalizeFinalStatus(String value) {
        return "blocked".equalsIgnoreCase(value) ? "blocked" : "completed";
    }

    private String checkpointScope(AgentRunService.AgentRun run) {
        String conversation = run == null || run.conversationId() == null ? "conversation" : run.conversationId();
        String project = run == null || run.projectId() == null ? "project" : run.projectId();
        // Stable across application restart/new run id so the last good batch checkpoint remains usable.
        return project + "--" + conversation;
    }

    private String requiredText(JsonNode node, String field) {
        String value = text(node, field);
        if (value == null || value.isBlank()) throw new IllegalArgumentException(field + " is required");
        return value;
    }

    private String text(JsonNode node, String field) {
        if (node == null || node.isMissingNode() || node.isNull()) return "";
        JsonNode value = node.path(field);
        return value.isMissingNode() || value.isNull() ? "" : value.asText("");
    }

    private String firstNonBlank(String first, String second) {
        return first != null && !first.isBlank() ? first : second == null ? "" : second;
    }

    private List<String> stringList(JsonNode node, String field) {
        JsonNode arr = node == null ? null : node.path(field);
        if (arr == null || !arr.isArray()) return List.of();
        List<String> out = new ArrayList<>();
        for (JsonNode item : arr) {
            String value = item.asText("").trim();
            if (!value.isBlank()) out.add(value);
        }
        return out;
    }

    /** Bound a single tool result placed back into the model transcript. The full result is still used by the
     * runtime for verification/events; only repeatedly-sent model context is bounded. */
    private String clip(String value) {
        return clipHeadTail(value, 50_000, "[Tool output bounded to 50k characters for active model context. Re-run with a targeted command/read for exact omitted details.]");
    }

    private String clipHistoricalAssistant(String value) {
        return clipHeadTail(value, 12_000, "[Large historical tool envelope bounded after execution; live workspace state is authoritative.]");
    }

    private String clipUi(String value) {
        return clipHeadTail(value, 30_000, "[UI output clipped; the command/tool result itself was processed in full.]");
    }

    private String clipHeadTail(String value, int maxChars, String marker) {
        if (value == null) return "";
        if (value.length() <= maxChars) return value;
        int head = Math.max(500, (int)(maxChars * 0.72));
        int tail = Math.max(250, maxChars - head);
        return value.substring(0, head) + "\n...\n" + marker + "\n...\n" + value.substring(value.length() - tail);
    }

    private JsonNode sanitizeHistoricalToolArgs(JsonNode node) {
        if (node == null || node.isNull() || node.isMissingNode()) return objectMapper.createObjectNode();
        JsonNode copy = node.deepCopy();
        sanitizeHistoricalToolArgsInPlace(copy);
        return copy;
    }

    private void sanitizeHistoricalToolArgsInPlace(JsonNode node) {
        if (node == null) return;
        if (node.isObject()) {
            List<String> names = new ArrayList<>();
            node.fieldNames().forEachRemaining(names::add);
            for (String name : names) {
                JsonNode child = node.get(name);
                if (child != null && child.isTextual() && child.asText().length() > 8_000) {
                    String text = child.asText();
                    String bounded = clipHeadTail(text, 8_000, "[Large tool argument omitted from historical context after execution; length=" + text.length() + "]");
                    ((com.fasterxml.jackson.databind.node.ObjectNode) node).put(name, bounded);
                } else {
                    sanitizeHistoricalToolArgsInPlace(child);
                }
            }
        } else if (node.isArray()) {
            for (JsonNode child : node) sanitizeHistoricalToolArgsInPlace(child);
        }
    }

    private String safe(String value) {
        if (value == null || value.isBlank()) return "Unknown error";
        String clean = value.replace('\u0000', ' ');
        return clean.length() > 1_200 ? clean.substring(0, 1_200) : clean;
    }

    private static final class ProviderModelException extends Exception {
        private final String model;
        private final String providerDetail;
        private ProviderModelException(String model, String providerDetail, Throwable cause) {
            super(providerDetail, cause);
            this.model = model == null ? "" : model;
            this.providerDetail = providerDetail == null ? "" : providerDetail;
        }
        private String model() { return model; }
        private String providerDetail() { return providerDetail; }
    }

    private static final class ExecutorPoolExhaustedException extends Exception {
        private final String providerDetail;
        private ExecutorPoolExhaustedException(String message, String providerDetail, Throwable cause) {
            super(message, cause);
            this.providerDetail = providerDetail == null ? "" : providerDetail;
        }
        private String providerDetail() { return providerDetail; }
    }

    private record PreparedCall(OpenAiCompatibleClient.AgentToolCall call, String requestedTool, String tool, JsonNode args, String detail) {}
    private record ToolExecution(String result, String status, boolean executed) {}
    @PreDestroy
    public void shutdownExecutors() { parallelReadExecutor.shutdownNow(); }

    public record AgentResult(String answer, List<ProjectPatchRequest.ProjectPatchFile> changes) {}
}
