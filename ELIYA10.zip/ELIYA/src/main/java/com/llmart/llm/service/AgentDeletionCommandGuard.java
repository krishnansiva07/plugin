package com.llmart.llm.service;

import java.util.Locale;
import java.util.regex.Pattern;

/**
 * Blocks obvious shell deletion syntax from bypassing per-file approvals. This is intentionally
 * a defense in depth, NOT a sandbox: a launched script/build or an external MCP server can delete
 * files internally. Such workloads need OS-level confinement for an absolute guarantee.
 */
final class AgentDeletionCommandGuard {
    private static final Pattern RISKY = Pattern.compile(
            "(?i)(?:^|[\\s;&|()\"\'])(?:rm|rmdir|unlink|shred|del|erase|rd|remove-item|ri|git\\s+clean|git\\s+reset\\s+--hard|git\\s+restore|git\\s+checkout\\s+--|powershell(?:\\.exe)?\\s+.*remove-item)(?=\\s|$|[;&|()])|(?:os\\.remove|os\\.unlink|shutil\\.rmtree|fs\\.rmSync|fs\\.unlinkSync|Files\\.delete)\\s*\\(");

    static boolean isPotentialDestructiveShell(String command) {
        return command != null && RISKY.matcher(command).find();
    }

    static boolean isPotentialDestructiveMcp(String name) {
        if (name == null) return false;
        String tool = name.toLowerCase(Locale.ROOT);
        return tool.matches(".*(?:delete|remove|unlink|purge|clear_files|clean_workspace|reset_workspace).*" );
    }

    private AgentDeletionCommandGuard() { }
}
