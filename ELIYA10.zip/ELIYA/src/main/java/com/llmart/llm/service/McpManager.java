package com.llmart.llm.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import jakarta.annotation.PreDestroy;
import org.springframework.stereotype.Service;

import java.io.*;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.nio.file.attribute.PosixFilePermission;
import java.time.Duration;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicLong;
import java.util.function.BooleanSupplier;

/**
 * Generic Model Context Protocol client/registry.  The agent core does not know Playwright,
 * Vibium, databases, browsers, or any other MCP-specific semantics.  Enabled servers describe
 * their tools through tools/list and those schemas are surfaced to the model dynamically.
 *
 * Supported transports:
 *  - stdio (the common local MCP transport used by Playwright/Vibium and many developer servers)
 *  - Streamable HTTP for ordinary JSON or SSE responses
 *
 * Configuration is merged from ~/.agents/mcp.json, ELIYA's user-level ~/.eliya/mcp.json,
 * and workspace-local .agents/.opencode MCP files. ELIYA's manual configuration therefore
 * becomes available to the existing agent/tool flow without changing the agent architecture.
 */
@Service
public class McpManager {
    private static final String PROTOCOL_VERSION = "2025-06-18";
    private final ObjectMapper mapper;
    private final HttpClient http;
    private final Map<String, McpSession> sessions = new ConcurrentHashMap<>();

    public McpManager(ObjectMapper mapper, HttpClient http) {
        this.mapper = mapper;
        this.http = http;
    }

    public Catalog catalog(Path workspaceRoot) {
        Path root = contextRoot(workspaceRoot);
        LinkedHashMap<String, ServerConfig> configs = discoverConfigs(root);
        List<Map<String,Object>> definitions = new ArrayList<>();
        Map<String, ToolRef> byFunction = new LinkedHashMap<>();
        List<String> diagnostics = new ArrayList<>();
        for (ServerConfig cfg : configs.values()) {
            if (!cfg.enabled()) continue;
            try {
                McpSession session = sessions.computeIfAbsent(sessionKey(root, cfg), k -> createSession(root, cfg));
                List<McpTool> tools = session.listTools();
                for (McpTool tool : tools) {
                    String function = uniqueFunctionName(cfg.name(), tool.name(), byFunction.keySet());
                    Map<String,Object> schema = normalizeSchema(tool.inputSchema());
                    String description = "MCP " + cfg.name() + " / " + tool.name() + ": " +
                            (tool.description() == null || tool.description().isBlank() ? "External MCP tool" : tool.description());
                    definitions.add(Map.of("type", "function", "function", Map.of(
                            "name", function,
                            "description", description,
                            "parameters", schema
                    )));
                    byFunction.put(function, new ToolRef(cfg.name(), tool.name(), tool.readOnlyHint()));
                }
                diagnostics.add(cfg.name() + ": connected; tools=" + tools.size());
            } catch (Exception e) {
                diagnostics.add(cfg.name() + ": unavailable: " + safe(e.getMessage()));
            }
        }
        return new Catalog(List.copyOf(definitions), Map.copyOf(byFunction), List.copyOf(diagnostics));
    }

    public String call(Path workspaceRoot, Catalog catalog, String functionName, JsonNode arguments) throws Exception {
        return call(workspaceRoot, catalog, functionName, arguments, () -> false);
    }

    public String call(Path workspaceRoot, Catalog catalog, String functionName, JsonNode arguments, BooleanSupplier cancelled) throws Exception {
        Path root = contextRoot(workspaceRoot);
        ToolRef ref = catalog.byFunction().get(functionName);
        if (ref == null) throw new IllegalArgumentException("Unknown MCP tool: " + functionName);
        ServerConfig cfg = discoverConfigs(root).get(ref.server());
        if (cfg == null || !cfg.enabled()) throw new IllegalStateException("MCP server is no longer enabled: " + ref.server());
        McpSession session = sessions.computeIfAbsent(sessionKey(root, cfg), k -> createSession(root, cfg));
        JsonNode result = session.callTool(ref.tool(), arguments == null || !arguments.isObject() ? mapper.createObjectNode() : arguments, cancelled == null ? () -> false : cancelled);
        return renderToolResult(ref, result);
    }

    public String status(Path workspaceRoot) {
        Catalog catalog = catalog(workspaceRoot);
        if (catalog.diagnostics().isEmpty()) return "[No MCP servers configured]";
        StringBuilder out = new StringBuilder(String.join("\n", catalog.diagnostics()));
        if (!catalog.definitions().isEmpty()) {
            out.append("\nAvailable MCP functions:");
            for (Map<String,Object> def : catalog.definitions()) {
                Object f = def.get("function");
                if (f instanceof Map<?,?> fn) {
                    out.append("\n- ").append(fn.get("name")).append(": ").append(fn.get("description"));
                    Object params = fn.get("parameters");
                    if (params != null) out.append("; parameters=").append(params);
                }
            }
        }
        return out.toString();
    }

    public boolean isMcpTool(Catalog catalog, String name) {
        return catalog != null && catalog.byFunction().containsKey(name);
    }

    public boolean isReadOnly(Catalog catalog, String name) {
        ToolRef ref = catalog == null ? null : catalog.byFunction().get(name);
        return ref != null && ref.readOnlyHint();
    }

    public List<String> configuredServerNames(Path workspaceRoot) {
        return discoverConfigs(contextRoot(workspaceRoot)).values().stream().filter(ServerConfig::enabled).map(ServerConfig::name).toList();
    }

    /**
     * Chat mode is intentionally read/analysis oriented. Prefer the MCP annotation when present and
     * conservatively infer common read-only verbs for internal servers that omit annotations.
     */
    public boolean isChatReadOnly(Catalog catalog, String functionName) {
        ToolRef ref = catalog == null ? null : catalog.byFunction().get(functionName);
        if (ref == null) return false;
        if (ref.readOnlyHint()) return true;
        String name = ref.tool() == null ? "" : ref.tool().trim().toLowerCase(Locale.ROOT);
        if (name.isBlank()) return false;
        if (name.matches(".*(?:create|update|edit|delete|remove|add_|add-|comment|transition|upload|write|set_|set-|assign|move|close|merge|approve|reject|resolve).*")) return false;
        return name.matches("^(?:get|list|search|read|find|fetch|query|lookup|view|describe|download|browse|inspect|status|whoami)(?:[_-].*|$)")
                || name.contains("_get_") || name.contains("_list_") || name.contains("_search_")
                || name.contains("_read_") || name.contains("_find_") || name.contains("_fetch_")
                || name.contains("_query_") || name.contains("_lookup_")
                || name.matches(".*(?:[_-](?:get|list|search|read|find|fetch|query|lookup|view|describe|download|browse|inspect|status|whoami))$");
    }

    /**
     * Returns the ELIYA-managed global remote MCP configuration without ever returning secret
     * header values to the browser.  The browser only needs to know which headers are already
     * configured so blank password fields can safely mean "keep existing value".
     */
    public ManualConfigView manualConfiguration() {
        ServerConfig cfg = readManagedConfig();
        if (cfg == null) {
            return new ManualConfigView("itg-devops", false, "remote", "", 100000L, List.of());
        }
        List<String> configured = cfg.headers().entrySet().stream()
                .filter(e -> e.getValue() != null && !e.getValue().isBlank())
                .map(Map.Entry::getKey).sorted(String.CASE_INSENSITIVE_ORDER).toList();
        return new ManualConfigView(cfg.name(), cfg.enabled(), "http".equals(cfg.type()) ? "remote" : cfg.type(),
                cfg.url(), cfg.timeoutMillis(), configured);
    }

    /**
     * Saves one user-level remote MCP server. Non-blank incoming headers replace matching values;
     * blank values preserve any already configured secret so opening Settings never erases tokens.
     */
    public synchronized ManualConfigView saveManualConfiguration(String rawName, boolean enabled, String rawUrl,
                                                                   long timeoutMillis, Map<String,String> incomingHeaders) {
        String name = sanitizeId(rawName == null || rawName.isBlank() ? "itg-devops" : rawName);
        if (name.isBlank()) throw new IllegalArgumentException("MCP connection name is required");
        String url = rawUrl == null ? "" : rawUrl.trim();
        if (enabled && url.isBlank()) throw new IllegalArgumentException("MCP server URL is required when MCP is enabled");
        if (!url.isBlank()) {
            URI uri;
            try { uri = URI.create(url); } catch (Exception e) { throw new IllegalArgumentException("Invalid MCP server URL"); }
            String scheme = uri.getScheme() == null ? "" : uri.getScheme().toLowerCase(Locale.ROOT);
            if (!Set.of("http", "https").contains(scheme) || uri.getHost() == null)
                throw new IllegalArgumentException("MCP server URL must be an absolute http/https URL");
        }
        long timeout = timeoutMillis <= 0 ? 100000L : Math.min(timeoutMillis, TimeUnit.MINUTES.toMillis(30));

        ServerConfig existing = readManagedConfig();
        boolean hasIncomingHeaders = incomingHeaders != null && incomingHeaders.values().stream()
                .anyMatch(v -> v != null && !v.trim().isBlank());
        if (!enabled && url.isBlank() && !hasIncomingHeaders && existing == null) return manualConfiguration();

        LinkedHashMap<String,String> headers = new LinkedHashMap<>();
        if (existing != null) headers.putAll(existing.headers());
        if (incomingHeaders != null) {
            incomingHeaders.forEach((key, value) -> {
                String k = normalizeHeaderName(key);
                String v = value == null ? "" : value.trim();
                if (!k.isBlank() && !v.isBlank()) headers.put(k, v);
            });
        }

        ObjectNode root = mapper.createObjectNode();
        ObjectNode mcp = root.putObject("mcp");
        ObjectNode node = mcp.putObject(name);
        node.put("type", "remote");
        node.put("url", url);
        node.put("enabled", enabled);
        node.put("timeout", timeout); // OpenCode-compatible milliseconds
        ObjectNode headerNode = node.putObject("headers");
        headers.forEach(headerNode::put);
        writeManagedConfig(root);
        resetSessions();
        return manualConfiguration();
    }

    public synchronized void clearManualConfiguration() {
        Path file = managedConfigPath();
        try { Files.deleteIfExists(file); }
        catch (IOException e) { throw new IllegalStateException("Unable to remove MCP configuration: " + safe(e.getMessage()), e); }
        resetSessions();
    }

    public ConnectionTest testManualConfiguration() {
        ServerConfig cfg = readManagedConfig();
        if (cfg == null) return new ConnectionTest(false, "", 0, List.of(), "No manual MCP configuration is saved");
        if (!cfg.enabled()) return new ConnectionTest(false, cfg.name(), 0, List.of(), "MCP configuration is disabled");
        McpSession session = null;
        try {
            session = createSession(Path.of(System.getProperty("user.home", ".")).toAbsolutePath().normalize(), cfg);
            List<McpTool> tools = session.listTools();
            List<String> names = tools.stream().map(McpTool::name).filter(n -> n != null && !n.isBlank()).sorted().toList();
            return new ConnectionTest(true, cfg.name(), names.size(), names, "Connected and tool discovery succeeded");
        } catch (Exception e) {
            return new ConnectionTest(false, cfg.name(), 0, List.of(), safe(redactSecrets(e.getMessage(), cfg.headers())));
        } finally {
            if (session != null) try { session.close(); } catch (Exception ignored) { }
        }
    }

    private void resetSessions() {
        for (McpSession session : sessions.values()) {
            try { session.close(); } catch (Exception ignored) { }
        }
        sessions.clear();
    }

    private Path managedConfigPath() {
        Path home = Path.of(System.getProperty("user.home", ".")).toAbsolutePath().normalize();
        return home.resolve(".eliya").resolve("mcp.json");
    }

    private ServerConfig readManagedConfig() {
        Path file = managedConfigPath();
        if (!Files.isRegularFile(file) || Files.isSymbolicLink(file)) return null;
        try {
            JsonNode root = mapper.readTree(Files.readString(file, StandardCharsets.UTF_8));
            JsonNode servers = root.path("mcp");
            if (!servers.isObject()) servers = root.path("servers");
            if (!servers.isObject()) return null;
            Iterator<Map.Entry<String,JsonNode>> fields = servers.fields();
            if (!fields.hasNext()) return null;
            Map.Entry<String,JsonNode> entry = fields.next();
            return parseConfig(entry.getKey(), entry.getValue());
        } catch (Exception e) {
            throw new IllegalStateException("Unable to read ELIYA MCP configuration: " + safe(e.getMessage()), e);
        }
    }

    private void writeManagedConfig(JsonNode root) {
        Path file = managedConfigPath();
        Path dir = file.getParent();
        try {
            Files.createDirectories(dir);
            Path temp = Files.createTempFile(dir, "mcp-", ".json.tmp");
            Files.writeString(temp, mapper.writerWithDefaultPrettyPrinter().writeValueAsString(root) + System.lineSeparator(),
                    StandardCharsets.UTF_8, StandardOpenOption.WRITE, StandardOpenOption.TRUNCATE_EXISTING);
            try {
                Files.setPosixFilePermissions(temp, EnumSet.of(PosixFilePermission.OWNER_READ, PosixFilePermission.OWNER_WRITE));
            } catch (UnsupportedOperationException ignored) { }
            try {
                Files.move(temp, file, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (AtomicMoveNotSupportedException e) {
                Files.move(temp, file, StandardCopyOption.REPLACE_EXISTING);
            }
            try {
                Files.setPosixFilePermissions(file, EnumSet.of(PosixFilePermission.OWNER_READ, PosixFilePermission.OWNER_WRITE));
            } catch (UnsupportedOperationException ignored) { }
        } catch (IOException e) {
            throw new IllegalStateException("Unable to save MCP configuration: " + safe(e.getMessage()), e);
        }
    }

    @PreDestroy
    public void shutdown() {
        for (McpSession session : sessions.values()) {
            try { session.close(); } catch (Exception ignored) { }
        }
        sessions.clear();
    }

    private McpSession createSession(Path root, ServerConfig cfg) {
        try {
            return switch (cfg.type()) {
                case "http", "streamable-http", "streamable_http" -> new HttpMcpSession(cfg);
                default -> new StdioMcpSession(root, cfg);
            };
        } catch (Exception e) {
            throw new IllegalStateException("Unable to start MCP server " + cfg.name() + ": " + safe(e.getMessage()), e);
        }
    }

    private Path contextRoot(Path workspaceRoot) {
        if (workspaceRoot != null) return workspaceRoot.toAbsolutePath().normalize();
        return Path.of(System.getProperty("user.home", ".")).toAbsolutePath().normalize();
    }

    private LinkedHashMap<String, ServerConfig> discoverConfigs(Path workspaceRoot) {
        LinkedHashMap<String, ServerConfig> merged = new LinkedHashMap<>();
        Path home = Path.of(System.getProperty("user.home", ".")).toAbsolutePath().normalize();
        for (Path file : List.of(home.resolve(".agents/mcp.json"), home.resolve(".eliya/mcp.json"), workspaceRoot.resolve(".agents/mcp.json"), workspaceRoot.resolve(".opencode/mcp.json"))) {
            if (!Files.isRegularFile(file) || Files.isSymbolicLink(file)) continue;
            try {
                JsonNode root = mapper.readTree(Files.readString(file, StandardCharsets.UTF_8));
                JsonNode servers = root.path("servers");
                if (!servers.isObject()) servers = root.path("mcp");
                if (!servers.isObject()) continue;
                Iterator<Map.Entry<String,JsonNode>> fields = servers.fields();
                while (fields.hasNext()) {
                    Map.Entry<String,JsonNode> entry = fields.next();
                    ServerConfig cfg = parseConfig(entry.getKey(), entry.getValue());
                    if (cfg != null) merged.put(cfg.name(), cfg);
                }
            } catch (Exception ignored) { }
        }
        return merged;
    }

    private ServerConfig parseConfig(String rawName, JsonNode node) {
        String name = sanitizeId(rawName);
        if (name.isBlank() || node == null || !node.isObject()) return null;
        boolean enabled = !node.has("enabled") || node.path("enabled").asBoolean(true);
        String type = node.path("type").asText("stdio").trim().toLowerCase(Locale.ROOT);
        if ("local".equals(type)) type = "stdio";
        if ("remote".equals(type)) type = "http";
        String command = node.path("command").isTextual() ? node.path("command").asText("") : "";
        List<String> args = new ArrayList<>();
        if (node.path("command").isArray()) {
            JsonNode arr = node.path("command");
            if (!arr.isEmpty()) command = arr.get(0).asText("");
            for (int i=1;i<arr.size();i++) args.add(arr.get(i).asText(""));
        }
        if (node.path("args").isArray()) for (JsonNode a : node.path("args")) args.add(a.asText(""));
        Map<String,String> env = new LinkedHashMap<>();
        if (node.path("env").isObject()) node.path("env").fields().forEachRemaining(e -> env.put(e.getKey(), e.getValue().asText("")));
        Map<String,String> headers = new LinkedHashMap<>();
        if (node.path("headers").isObject()) node.path("headers").fields().forEachRemaining(e -> {
            String key = normalizeHeaderName(e.getKey());
            String value = e.getValue().asText("").trim();
            if (!key.isBlank() && !value.isBlank()) headers.put(key, value);
        });
        String url = node.path("url").asText("").trim();
        String cwd = node.path("cwd").asText("").trim();
        long timeoutMillis;
        if (node.has("timeout")) timeoutMillis = Math.max(0L, node.path("timeout").asLong(0L));
        else if (node.has("timeoutMillis")) timeoutMillis = Math.max(0L, node.path("timeoutMillis").asLong(0L));
        else timeoutMillis = TimeUnit.SECONDS.toMillis(Math.max(0L, node.path("timeoutSeconds").asLong(0L)));
        return new ServerConfig(name, enabled, type, command, List.copyOf(args), Map.copyOf(env), Map.copyOf(headers), url, cwd, timeoutMillis);
    }

    private Map<String,Object> normalizeSchema(JsonNode inputSchema) {
        try {
            JsonNode schema = inputSchema == null || !inputSchema.isObject() ? mapper.readTree("{\"type\":\"object\",\"properties\":{}}") : inputSchema;
            @SuppressWarnings("unchecked") Map<String,Object> map = mapper.convertValue(schema, Map.class);
            LinkedHashMap<String,Object> result = new LinkedHashMap<>(map == null ? Map.of() : map);
            result.putIfAbsent("type", "object");
            result.putIfAbsent("properties", Map.of());
            return result;
        } catch (Exception e) {
            return Map.of("type","object","properties",Map.of());
        }
    }

    private String renderToolResult(ToolRef ref, JsonNode response) {
        if (response == null || response.isNull()) return "MCP " + ref.server() + "/" + ref.tool() + " returned no content";
        JsonNode result = response.path("result");
        if (response.has("error")) return "MCP PROTOCOL ERROR " + ref.server() + "/" + ref.tool() + ": " + response.path("error").toString();
        boolean isError = result.path("isError").asBoolean(false);
        StringBuilder out = new StringBuilder();
        out.append("mcpServer=").append(ref.server()).append("; tool=").append(ref.tool()).append("; isError=").append(isError).append('\n');
        JsonNode content = result.path("content");
        if (content.isArray()) {
            for (JsonNode item : content) {
                String type = item.path("type").asText("");
                if ("text".equals(type)) out.append(item.path("text").asText("")).append('\n');
                else out.append(item.toString()).append('\n');
            }
        }
        if (result.has("structuredContent")) out.append("structuredContent=").append(result.path("structuredContent")).append('\n');
        if (out.toString().trim().equals("mcpServer=" + ref.server() + "; tool=" + ref.tool() + "; isError=" + isError)) out.append(result.toString());
        return out.toString().stripTrailing();
    }

    private String sessionKey(Path root, ServerConfig cfg) {
        return root.toAbsolutePath().normalize() + "|" + cfg.name() + "|" + cfg.type() + "|" + cfg.command() + "|" + cfg.url() + "|" + cfg.timeoutMillis() + "|" + Integer.toHexString(cfg.headers().hashCode());
    }

    private String uniqueFunctionName(String server, String tool, Set<String> used) {
        String base = "mcp__" + sanitizeFunction(server) + "__" + sanitizeFunction(tool);
        if (base.length() > 60) base = base.substring(0, 48) + "__" + Integer.toHexString(base.hashCode());
        String value = base;
        int i = 2;
        while (used.contains(value)) value = (base.length() > 56 ? base.substring(0,56) : base) + "_" + i++;
        return value;
    }

    private String sanitizeFunction(String value) {
        String s = value == null ? "tool" : value.replaceAll("[^A-Za-z0-9_-]", "_");
        return s.isBlank() ? "tool" : s;
    }

    private String sanitizeId(String value) {
        String s = value == null ? "" : value.trim().replaceAll("[^A-Za-z0-9._-]", "_");
        return s.length() > 100 ? s.substring(0,100) : s;
    }

    private String normalizeHeaderName(String value) {
        String s = value == null ? "" : value.trim();
        if (!s.matches("[!#$%&'*+.^_`|~0-9A-Za-z-]{1,128}")) return "";
        return s;
    }

    private String redactSecrets(String value, Map<String,String> headers) {
        String out = value == null ? "" : value;
        if (headers != null) {
            for (String secret : headers.values()) {
                if (secret != null && !secret.isBlank()) out = out.replace(secret, "***");
            }
        }
        return out;
    }

    private String safe(String value) {
        if (value == null || value.isBlank()) return "unknown error";
        String s = value.replace('\n',' ').replace('\r',' ').replaceAll("\\s+", " ").trim();
        return s.length() > 800 ? s.substring(0,800) : s;
    }

    public record Catalog(List<Map<String,Object>> definitions, Map<String,ToolRef> byFunction, List<String> diagnostics) {
        public static Catalog empty() { return new Catalog(List.of(), Map.of(), List.of()); }
    }
    public record ToolRef(String server, String tool, boolean readOnlyHint) {}
    public record ManualConfigView(String name, boolean enabled, String type, String url, long timeoutMillis,
                                   List<String> configuredHeaders) {}
    public record ConnectionTest(boolean connected, String name, int toolCount, List<String> tools, String message) {}
    private record McpTool(String name, String description, JsonNode inputSchema, boolean readOnlyHint) {}
    private record ServerConfig(String name, boolean enabled, String type, String command, List<String> args,
                                Map<String,String> env, Map<String,String> headers, String url, String cwd, long timeoutMillis) {}

    private interface McpSession extends AutoCloseable {
        List<McpTool> listTools() throws Exception;
        JsonNode callTool(String name, JsonNode arguments, BooleanSupplier cancelled) throws Exception;
        @Override void close();
    }

    private final class StdioMcpSession implements McpSession {
        private final ServerConfig cfg;
        private final Process process;
        private final BufferedWriter stdin;
        private final AtomicLong ids = new AtomicLong(1);
        private final Map<Long, CompletableFuture<JsonNode>> pending = new ConcurrentHashMap<>();
        private volatile List<McpTool> cachedTools;

        StdioMcpSession(Path workspaceRoot, ServerConfig cfg) throws Exception {
            this.cfg = cfg;
            if (cfg.command() == null || cfg.command().isBlank()) throw new IllegalArgumentException("stdio MCP command is required");
            List<String> command = new ArrayList<>(); command.add(cfg.command()); command.addAll(cfg.args());
            ProcessBuilder pb = new ProcessBuilder(command);
            Path cwd = cfg.cwd().isBlank() ? workspaceRoot : workspaceRoot.resolve(cfg.cwd()).normalize();
            if (!cwd.startsWith(workspaceRoot) || !Files.isDirectory(cwd)) throw new SecurityException("Invalid MCP cwd: " + cfg.cwd());
            pb.directory(cwd.toFile());
            pb.environment().putAll(cfg.env());
            process = pb.start();
            stdin = new BufferedWriter(new OutputStreamWriter(process.getOutputStream(), StandardCharsets.UTF_8));
            Thread stdoutThread = new Thread(() -> readStdout(process.getInputStream()), "mcp-stdout-" + cfg.name());
            stdoutThread.setDaemon(true);
            stdoutThread.start();
            Thread stderrThread = new Thread(() -> drain(process.getErrorStream()), "mcp-stderr-" + cfg.name());
            stderrThread.setDaemon(true);
            stderrThread.start();
            initialize();
        }

        private void initialize() throws Exception {
            ObjectNode params = mapper.createObjectNode();
            params.put("protocolVersion", PROTOCOL_VERSION);
            params.set("capabilities", mapper.createObjectNode());
            params.set("clientInfo", mapper.valueToTree(Map.of("name","advanced-ai-workbench","version","rolling")));
            request("initialize", params);
            notify("notifications/initialized", mapper.createObjectNode());
        }

        @Override public List<McpTool> listTools() throws Exception {
            if (cachedTools != null) return cachedTools;
            List<McpTool> all = new ArrayList<>();
            String cursor = null;
            do {
                ObjectNode params = mapper.createObjectNode(); if (cursor != null) params.put("cursor", cursor);
                JsonNode response = request("tools/list", params);
                JsonNode result = response.path("result");
                for (JsonNode t : result.path("tools")) all.add(parseTool(t));
                cursor = result.path("nextCursor").asText("").trim(); if (cursor.isBlank()) cursor = null;
            } while (cursor != null);
            cachedTools = List.copyOf(all);
            return cachedTools;
        }

        @Override public JsonNode callTool(String name, JsonNode arguments, BooleanSupplier cancelled) throws Exception {
            ObjectNode params = mapper.createObjectNode(); params.put("name", name); params.set("arguments", arguments);
            return request("tools/call", params, cancelled);
        }

        private JsonNode request(String method, JsonNode params) throws Exception {
            return request(method, params, () -> false);
        }

        private JsonNode request(String method, JsonNode params, BooleanSupplier cancelled) throws Exception {
            if (!process.isAlive()) throw new IllegalStateException("MCP process exited with code " + process.exitValue());
            long id = ids.getAndIncrement();
            CompletableFuture<JsonNode> future = new CompletableFuture<>(); pending.put(id, future);
            ObjectNode msg = mapper.createObjectNode(); msg.put("jsonrpc","2.0"); msg.put("id",id); msg.put("method",method); msg.set("params",params);
            send(msg);
            long deadline = cfg.timeoutMillis() > 0 ? System.nanoTime() + TimeUnit.MILLISECONDS.toNanos(cfg.timeoutMillis()) : Long.MAX_VALUE;
            try {
                while (true) {
                    if (cancelled != null && cancelled.getAsBoolean()) {
                        future.cancel(true);
                        throw new AgentCancelledException("Agent run was cancelled during MCP operation");
                    }
                    if (!process.isAlive()) throw new IllegalStateException("MCP process exited with code " + process.exitValue());
                    if (System.nanoTime() >= deadline) throw new TimeoutException("MCP request timed out: " + method);
                    try { return future.get(200, TimeUnit.MILLISECONDS); } catch (TimeoutException ignored) { }
                }
            } finally { pending.remove(id); }
        }

        private void notify(String method, JsonNode params) throws Exception {
            ObjectNode msg = mapper.createObjectNode(); msg.put("jsonrpc","2.0"); msg.put("method",method); msg.set("params",params); send(msg);
        }

        private synchronized void send(JsonNode node) throws Exception { stdin.write(mapper.writeValueAsString(node)); stdin.newLine(); stdin.flush(); }

        private void readStdout(InputStream in) {
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    try {
                        JsonNode json = mapper.readTree(line);
                        if (json.has("id")) {
                            long id = json.path("id").asLong(Long.MIN_VALUE);
                            CompletableFuture<JsonNode> future = pending.get(id);
                            if (future != null) future.complete(json);
                        } else if ("notifications/tools/list_changed".equals(json.path("method").asText(""))) {
                            cachedTools = null;
                        }
                    } catch (Exception ignored) { }
                }
            } catch (Exception ignored) { }
            IllegalStateException failure = new IllegalStateException("MCP server stopped: " + cfg.name());
            pending.values().forEach(f -> f.completeExceptionally(failure));
        }

        private void drain(InputStream in) { try { in.transferTo(OutputStream.nullOutputStream()); } catch (Exception ignored) { } }

        @Override public void close() {
            try { stdin.close(); } catch (Exception ignored) { }
            if (process.isAlive()) { process.destroy(); if (process.isAlive()) process.destroyForcibly(); }
        }
    }

    private final class HttpMcpSession implements McpSession {
        private final ServerConfig cfg;
        private String sessionId;
        private volatile List<McpTool> cachedTools;
        private final AtomicLong ids = new AtomicLong(1);
        HttpMcpSession(ServerConfig cfg) throws Exception {
            this.cfg = cfg;
            if (cfg.url() == null || cfg.url().isBlank()) throw new IllegalArgumentException("HTTP MCP url is required");
            ObjectNode params = mapper.createObjectNode(); params.put("protocolVersion", PROTOCOL_VERSION);
            params.set("capabilities", mapper.createObjectNode());
            params.set("clientInfo", mapper.valueToTree(Map.of("name","advanced-ai-workbench","version","rolling")));
            post(requestNode("initialize", params, ids.getAndIncrement()), "initialize");
            post(notificationNode("notifications/initialized", mapper.createObjectNode()), "notifications/initialized");
        }
        @Override public List<McpTool> listTools() throws Exception {
            if (cachedTools != null) return cachedTools;
            List<McpTool> all = new ArrayList<>(); String cursor = null;
            do {
                ObjectNode p = mapper.createObjectNode(); if (cursor != null) p.put("cursor", cursor);
                JsonNode response = post(requestNode("tools/list", p, ids.getAndIncrement()), "tools/list");
                JsonNode result = response.path("result");
                for (JsonNode t : result.path("tools")) all.add(parseTool(t));
                cursor = result.path("nextCursor").asText("").trim(); if (cursor.isBlank()) cursor = null;
            } while (cursor != null);
            cachedTools = List.copyOf(all); return cachedTools;
        }
        @Override public JsonNode callTool(String name, JsonNode arguments, BooleanSupplier cancelled) throws Exception {
            ObjectNode p = mapper.createObjectNode(); p.put("name",name); p.set("arguments",arguments);
            return post(requestNode("tools/call",p,ids.getAndIncrement()), "tools/call", cancelled);
        }
        private JsonNode post(JsonNode body, String method) throws Exception {
            return post(body, method, () -> false);
        }
        private JsonNode post(JsonNode body, String method, BooleanSupplier cancelled) throws Exception {
            HttpRequest.Builder b = HttpRequest.newBuilder(URI.create(cfg.url())).header("Content-Type","application/json").header("Accept","application/json, text/event-stream").header("MCP-Protocol-Version",PROTOCOL_VERSION).header("Mcp-Method", method);
            Set<String> reserved = Set.of("content-type", "accept", "mcp-protocol-version", "mcp-session-id", "mcp-method");
            for (Map.Entry<String,String> entry : cfg.headers().entrySet()) {
                if (!reserved.contains(entry.getKey().toLowerCase(Locale.ROOT))) b.header(entry.getKey(), entry.getValue());
            }
            if (sessionId != null && !sessionId.isBlank()) b.header("Mcp-Session-Id", sessionId);
            if (cfg.timeoutMillis() > 0) b.timeout(Duration.ofMillis(cfg.timeoutMillis()));
            CompletableFuture<HttpResponse<String>> future = http.sendAsync(b.POST(HttpRequest.BodyPublishers.ofString(mapper.writeValueAsString(body))).build(), HttpResponse.BodyHandlers.ofString());
            HttpResponse<String> response;
            while (true) {
                if (cancelled != null && cancelled.getAsBoolean()) { future.cancel(true); throw new AgentCancelledException("Agent run was cancelled during MCP HTTP operation"); }
                try { response = future.get(200, TimeUnit.MILLISECONDS); break; }
                catch (TimeoutException ignored) { }
                catch (ExecutionException e) { Throwable cause=e.getCause(); if(cause instanceof Exception ex) throw ex; throw e; }
            }
            response.headers().firstValue("Mcp-Session-Id").ifPresent(v -> sessionId = v);
            if (response.statusCode() == 202 || response.statusCode() == 204) return mapper.createObjectNode();
            if (response.statusCode() < 200 || response.statusCode() >= 300) throw new IllegalStateException("HTTP MCP " + response.statusCode() + ": " + safe(redactSecrets(response.body(), cfg.headers())));
            String text = response.body() == null ? "" : response.body().trim();
            if (text.startsWith("data:" ) || text.contains("\ndata:")) {
                for (String line : text.split("\\R")) if (line.startsWith("data:")) { String data=line.substring(5).trim(); if (!data.isBlank()) return mapper.readTree(data); }
            }
            return text.isBlank() ? mapper.createObjectNode() : mapper.readTree(text);
        }
        @Override public void close() { }
    }

    private McpTool parseTool(JsonNode t) {
        String name = t.path("name").asText("").trim();
        String description = t.path("description").asText("");
        JsonNode schema = t.path("inputSchema");
        boolean readOnly = t.path("annotations").path("readOnlyHint").asBoolean(false);
        return new McpTool(name, description, schema, readOnly);
    }

    private ObjectNode requestNode(String method, JsonNode params, long id) {
        ObjectNode n=mapper.createObjectNode(); n.put("jsonrpc","2.0"); n.put("id",id); n.put("method",method); n.set("params",params); return n;
    }
    private ObjectNode notificationNode(String method, JsonNode params) {
        ObjectNode n=mapper.createObjectNode(); n.put("jsonrpc","2.0"); n.put("method",method); n.set("params",params); return n;
    }
}
