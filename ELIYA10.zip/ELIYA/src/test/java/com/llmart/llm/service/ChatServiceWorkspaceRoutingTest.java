package com.llmart.llm.service;

import org.junit.jupiter.api.Test;

import java.lang.reflect.Method;

import static org.junit.jupiter.api.Assertions.*;

class ChatServiceWorkspaceRoutingTest {

    @Test
    void externalAnalysisDoesNotForceRememberedWorkspaceButMixedCodeTasksKeepIt() throws Exception {
        ChatService service = new ChatService(null, null, null, null, null, null, null, null, null);
        Method method = ChatService.class.getDeclaredMethod("externalAnalysisWithoutWorkspace", String.class);
        method.setAccessible(true);

        assertTrue((boolean) method.invoke(service,
                "Read Jira PAY-4582 and linked Confluence pages and create an analysis report"));
        assertTrue((boolean) method.invoke(service,
                "Analyse the attached requirement document and summarise gaps"));

        assertFalse((boolean) method.invoke(service,
                "Read Jira PAY-4582 and compare it with the current project workspace"));
        assertFalse((boolean) method.invoke(service,
                "Use Jira PAY-4582, Confluence and the attached requirement document to implement the missing Playwright tests"));
    }
}
