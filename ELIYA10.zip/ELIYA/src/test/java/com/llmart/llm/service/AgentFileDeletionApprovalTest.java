package com.llmart.llm.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.llmart.llm.entity.ProjectWorkspaceEntity;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class AgentFileDeletionApprovalTest {
    @TempDir Path temp;
    private final ObjectMapper json = new ObjectMapper();

    @Test
    void deletionGrantIsAlwaysSingleOperationEvenForManualRestCalls() {
        AgentApprovalService service = new AgentApprovalService();
        AgentApprovalService.Approval deletion = service.create("run", "delete", "DELETE: /project/file", false);
        assertFalse(deletion.allowRunGrant());
        assertFalse(service.resolve(deletion.id(), AgentApprovalService.Decision.RUN),
                "The REST action=run grant must be rejected on deletion approvals");
        assertTrue(service.resolve(deletion.id(), AgentApprovalService.Decision.ONCE));

        AgentApprovalService.Approval generic = service.create("run", "edit", "normal editor approval");
        assertTrue(generic.allowRunGrant());
        assertTrue(service.resolve(generic.id(), AgentApprovalService.Decision.RUN),
                "General permission behavior must remain intact");
    }

    @Test
    void preflightsDirectDeletionAndStructuredAndTextPatchWithoutChangingFiles() throws Exception {
        Path project = temp.resolve("project");
        Files.createDirectories(project);
        Files.writeString(project.resolve("keep.txt"), "keep");
        Files.writeString(project.resolve("delete.txt"), "delete me");
        AgentWorkspaceService service = service(project);
        AgentWorkspaceService.Workspace ws = service.prepare("p");
        ObjectNode direct = json.createObjectNode().put("path", "delete.txt");
        assertTrue(String.join("", service.previewProtectedFileChanges(ws, "delete", direct, "run", List.of()))
                .contains("DELETE: delete.txt"));

        ArrayNode changes = json.createArrayNode();
        changes.addObject().put("path", "keep.txt").put("operation", "write").put("content", "safe");
        changes.addObject().put("path", "delete.txt").put("operation", "delete");
        ObjectNode structured = json.createObjectNode();
        structured.set("changes", changes);
        List<String> affected = service.previewProtectedFileChanges(ws, "apply_patch", structured, "run", List.of());
        assertEquals(1, affected.size());
        assertTrue(affected.get(0).contains("delete.txt"));

        ObjectNode patch = json.createObjectNode().put("patch",
                "*** Begin Patch\n*** Delete File: delete.txt\n*** End Patch");
        assertEquals(1, service.previewProtectedFileChanges(ws, "apply_patch", patch, "run", List.of()).size());
        assertTrue(Files.exists(project.resolve("delete.txt")), "Preflight must not mutate files");
        assertTrue(Files.readString(project.resolve("keep.txt")).equals("keep"));
        service.cleanup(ws);
    }

    @Test
    void moveAndOverwriteAreDetectedButNormalNonDestructiveCopyIsNot() throws Exception {
        Path project = temp.resolve("project");
        Files.createDirectories(project);
        Files.writeString(project.resolve("source.txt"), "new content");
        Files.writeString(project.resolve("destination.txt"), "existing content");
        AgentWorkspaceService service = service(project);
        AgentWorkspaceService.Workspace ws = service.prepare("p");
        ObjectNode change = json.createObjectNode().put("from", "source.txt").put("to", "destination.txt")
                .put("overwrite", true);
        assertEquals(2, service.previewProtectedFileChanges(ws, "move", change, "run", List.of()).size());
        assertEquals(1, service.previewProtectedFileChanges(ws, "copy", change, "run", List.of()).size());
        change.put("to", "new-file.txt");
        assertEquals(1, service.previewProtectedFileChanges(ws, "move", change, "run", List.of()).size());
        assertTrue(service.previewProtectedFileChanges(ws, "copy", change, "run", List.of()).isEmpty());
        service.cleanup(ws);
    }

    @Test
    void obviousShellDeletionIsBlockedWithoutBlockingRegularBuilds() {
        assertTrue(AgentDeletionCommandGuard.isPotentialDestructiveShell("rm -rf ./src"));
        assertTrue(AgentDeletionCommandGuard.isPotentialDestructiveShell("bash -lc 'rm -rf ./src'"));
        assertTrue(AgentDeletionCommandGuard.isPotentialDestructiveShell("git clean -fd"));
        assertTrue(AgentDeletionCommandGuard.isPotentialDestructiveShell("Remove-Item src\\test -Recurse"));
        assertTrue(AgentDeletionCommandGuard.isPotentialDestructiveShell("del /F /Q test.txt"));
        assertFalse(AgentDeletionCommandGuard.isPotentialDestructiveShell("mvn test"));
        assertFalse(AgentDeletionCommandGuard.isPotentialDestructiveShell("git status --short"));
        assertTrue(AgentDeletionCommandGuard.isPotentialDestructiveMcp("mcp__filesystem__delete_file"));
        assertFalse(AgentDeletionCommandGuard.isPotentialDestructiveMcp("mcp__confluence__read_page"));
    }

    private AgentWorkspaceService service(Path project) {
        ProjectService projects = mock(ProjectService.class);
        ProjectWorkspaceEntity entity = mock(ProjectWorkspaceEntity.class);
        when(projects.require("p")).thenReturn(entity);
        when(entity.hasLocalPath()).thenReturn(true);
        when(entity.getLocalPath()).thenReturn(project.toString());
        return new AgentWorkspaceService(projects, json, new PromptResourceResolver());
    }

}
