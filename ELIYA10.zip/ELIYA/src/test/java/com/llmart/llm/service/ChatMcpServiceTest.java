package com.llmart.llm.service;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ChatMcpServiceTest {
    @Test
    void detectsExternalMcpRequestsWithoutHijackingOrdinaryChat() {
        ChatMcpService service = new ChatMcpService(null, null, null);
        assertTrue(service.shouldHandle("Read Jira PAY-123 and explain the acceptance criteria"));
        assertTrue(service.shouldHandle("What is the status of ABC-42?"));
        assertTrue(service.shouldHandle("Search Confluence for the SEPA architecture"));
        assertTrue(service.shouldHandle("Check the SonarQube quality gate"));
        assertFalse(service.shouldHandle("Explain Java inheritance with an example"));
    }
}
