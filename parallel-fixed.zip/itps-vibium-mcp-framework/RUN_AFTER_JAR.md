# Run tests after generating the JAR

Follow these steps after `target/itps-vibium-mcp-framework-1.0.0.jar` has been generated.

## 1. Check prerequisites

Open a terminal in the project root and verify:

```bash
java -version
node --version
```

Java must be 17 or later. Node.js is required by the localhost MCP bridge. Maven is not required just to run an already-built JAR.

## 2. Provide Vibium

The configured portable location is `tools/vibium-portable`.

From the project root:

```bash
cd tools
mkdir vibium-portable
cd vibium-portable
npm init -y
npm install vibium@latest
cd ../..
```

Confirm the executable exists:

Windows:

```bat
dir tools\vibium-portable\node_modules\.bin\vibium.cmd
```

macOS/Linux:

```bash
ls -l tools/vibium-portable/node_modules/.bin/vibium
chmod +x tools/vibium-portable/node_modules/.bin/vibium
```

If Vibium is already installed globally, either set `VIBIUM_MCP_COMMAND` before starting the bridge or edit `tools/local-mcp-bridge/local-mcp-config.json` so `windowsCommand`/`macCommand` names the working executable.

Confirm Vibium itself starts before continuing:

Windows:

```bat
tools\vibium-portable\node_modules\.bin\vibium.cmd --help
```

macOS/Linux:

```bash
tools/vibium-portable/node_modules/.bin/vibium --help
```

## 3. Start the local MCP bridge

Keep this first terminal open for the entire test run.

Windows:

```bat
start-local-mcp-windows.cmd
```

Optional readiness check in another Windows terminal:

```bat
tools\local-mcp-bridge\check-local-mcp-windows.cmd
```

macOS/Linux:

```bash
chmod +x start-local-mcp-mac.sh tools/local-mcp-bridge/start-local-mcp-mac.sh
./start-local-mcp-mac.sh
```

Expected output includes:

```text
Listening : 127.0.0.1:8765
Version   : vibium v...
Isolation : unique VIBIUM_SESSION per browser; 250 ms startup spacing
Status    : READY
Max users : 4 simultaneous browser sessions
```

The bridge launches one Vibium MCP child process per framework browser session. It gives each worker a unique session identity/runtime directory and spaces child startups using `childStartupSpacingMs`. Its limit is controlled by `maxClients` in `tools/local-mcp-bridge/local-mcp-config.json` and should remain at least as large as the selected parallel-browser count.

## 4. Start the framework JAR

Open a second terminal in the project root.

Windows:

```bat
start-framework-jar-windows.cmd
```

macOS/Linux:

```bash
chmod +x start-framework-jar-mac.sh
./start-framework-jar-mac.sh
```

Equivalent direct command:

```bash
java -jar target/itps-vibium-mcp-framework-1.0.0.jar --spring.config.additional-location=optional:file:./config/application-local.properties
```

Wait until Spring reports that the application started, then open:

```text
http://localhost:8090
```

## 5. Prepare the scenario file

Upload `.xlsx`, `.xls`, or `.json`.

For Excel:

1. Put headers in row 1.
2. Use `Id`, `Name`, `Url`, `Steps`, and optionally `Expected`, `Run`, `TestDataJson`, or `data.*` columns.
3. Put each step on its own line or separate steps with `|`.
4. If a `Run` column exists, mark rows with `true`, `yes`, `y`, `1`, `run`, `execute`, or `enabled`.
5. Select the worksheets to execute after upload.

For JSON, upload an array of scenario objects or an object with a `scenarios` array.

## 6. Choose the browser-session mode

### One browser for all tests — default

Leave **Separate browser for each test** and **Parallel execution** unchecked.

- Tests run sequentially.
- One browser remains open for the complete run.
- Login and cookie/session state continue into later tests.
- Optional cookie replacement runs once after the first successful scenario URL navigation.

This is the correct choice when the session cookie has an extension or later tests depend on the same authenticated session.

### A fresh browser for every test

Check **Separate browser for each test**.

- Each scenario receives a clean MCP client and browser.
- With **Parallel execution** unchecked, isolated browsers run one at a time.
- Optional cookie replacement runs separately in each test browser.

### Parallel tests

Check **Parallel execution**. The UI automatically enables **Separate browser for each test**.

Select two, three, or four parallel browsers. Each concurrently executing scenario is isolated; shared-browser parallel execution is intentionally rejected because it would race browser state and cookies.

Start with two browsers and increase only if the machine has enough CPU and memory.

## 7. Configure the optional cookie replacement

Leave **Replace one session cookie after the home page opens** unchecked when no cookie change is required.

When it is required:

1. Check the option.
2. Enter the exact name of a cookie that exists after the scenario home URL loads.
3. Enter the new cookie value.
4. Do not add the cookie to the scenario steps; the framework performs the transaction automatically.

The runtime then performs this exact transaction:

1. Reads all existing cookies before removing anything, using `browser_storage_state` first and `browser_get_cookies` as a fallback.
2. Finds the existing cookie whose name exactly matches the UI name and selects the best domain/path match when duplicates exist.
3. Copies every existing attribute accepted by the active set-cookie schema.
4. Removes every cookie with one clear-all operation.
5. Restores only the matched cookie name with the value entered in the UI.
6. Refreshes the current page.
7. Reads cookies again and verifies the exact name/value pair.

Vibium 26.5.31 exposes name, value, domain, and path on `browser_set_cookie`, so those existing fields are injected. If a future or alternate MCP schema exposes expiry, `HttpOnly`, `Secure`, `SameSite`, or partition fields, the framework injects those too.

The value field is optional only in the sense that the entire cookie feature is optional. When the checkbox is enabled, both cookie name and replacement value are mandatory.

If the named cookie is not present at the home page, the cookie step fails before any cookie is removed. If the installed Vibium MCP build does not expose native cookie tools, disable this option or upgrade Vibium.

## 8. Configure remaining execution options

- **Headless**: run without visible browser windows.
- **Allow self-signed/internal HTTPS certificates**: use only for authorized internal test systems.
- **Continue on failure**: keep evaluating independent scenarios and permitted later work.
- **Validate actions**: require observable evidence instead of trusting only a successful MCP response.
- **LLM self-healing**: retry eligible failed steps with a materially different plan.
- **Screenshot**: all passed steps, failures only, or none.
- **Timeout**: per-step action/verification allowance.
- **Failure healing attempts**: bounded retry count.

Natural-language steps that cannot be handled deterministically require the configured LLM endpoint and a valid token. Explicit XPath, CSS, and JSON MCP steps can use deterministic paths where supported.

## 9. Run and monitor

Click **Run tests**.

The UI polls the run status and shows total, passed, failed, duration, and error details. In isolated parallel mode, a browser startup failure is attached only to its scenario; other tests continue.

Do not close either terminal until the run finishes.

## 10. Download results

Use the result buttons for:

- Execution report (`report.html`)
- Technical logs (`logs.html`)
- Excel results (`report.xlsx`)
- JSON results (`report.json`)
- Screenshots (`screenshots.zip`)

Select failed tests and click **Rerun selected** to reuse the same execution configuration while the framework process is still running.

Artifacts are also stored under:

```text
target/itps-vibium-runs/<RUN-ID>/
```

## Troubleshooting

### The page opens but tests do not start

- Confirm the bridge terminal still says it is ready.
- Confirm port `8765` matches both `config/application-local.properties` and `tools/local-mcp-bridge/local-mcp-config.json`.
- Check the run's `mcp-process.log` and `mcp-transcript.json`.

### `ITPS_BRIDGE_BUSY`

- Reduce the parallel-browser count.
- Check for clients from another run.
- Keep `maxClients` at four unless the machine is intentionally sized for more; the framework UI is capped at four.

### Parallel browser initialization fails

- Install or update the portable runtime with `npm install vibium@latest`.
- Stop every old bridge window, then start exactly one bridge for the run.
- Confirm the bridge prints the `Version`, `Max users`, and `Isolation` lines shown above.
- Keep `childStartupSpacingMs` at `250` or raise it to `500` on a slower Windows workstation.
- Read `tools/local-mcp-bridge/logs/local-mcp-<date>.log`; initialization failures now include the child exit code and Vibium stderr.

### Vibium command not found

- Recheck the executable path under `tools/vibium-portable/node_modules/.bin`.
- Run the executable's `--help` command directly.
- Correct `windowsCommand` or `macCommand` in the bridge config.

### Cookie setup fails

- Verify the cookie exists immediately after the configured URL loads.
- Match the name exactly, including case.
- Inspect `mcp-tools.json` for `browser_storage_state` (or `browser_get_cookies`), `browser_set_cookie`, `browser_delete_cookies` (or `browser_clear_cookies`), and `browser_reload`.
- Upgrade Vibium if native cookie tools are absent.
- Disable cookie replacement to confirm the rest of the test flow independently.

### Selected installed browser is rejected

The current Vibium `browser_start` schema may not accept a browser channel or executable path. Select **Vibium Managed Chrome for Testing**.

### Internal HTTPS page remains blocked

- Enable the internal-certificate option only for an approved environment.
- Confirm the browser displays a standard Chrome privacy interstitial.
- Do not use this option to bypass trust checks on systems you do not own or administer.

### Port 8090 is already in use

Change `server.port` in `config/application-local.properties`, restart the JAR, and open the new port.
