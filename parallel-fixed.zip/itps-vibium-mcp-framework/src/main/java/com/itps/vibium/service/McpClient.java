package com.itps.vibium.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.itps.vibium.model.McpTool;

import java.io.*;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Minimal MCP JSON-RPC client supporting two local transports:
 * 1) PROCESS_STDIO - starts Vibium as a child process (legacy mode)
 * 2) EXTERNAL_TCP - connects to the manually started local MCP bridge
 */
public class McpClient implements AutoCloseable {
    private enum Transport { PROCESS_STDIO, EXTERNAL_TCP }

    private final ObjectMapper mapper = new ObjectMapper();
    private final AtomicLong idCounter = new AtomicLong(1);
    private final Map<Long, CompletableFuture<JsonNode>> pending = new ConcurrentHashMap<>();
    private final List<String> logs = Collections.synchronizedList(new ArrayList<>());
    private final List<Map<String, Object>> transcript = Collections.synchronizedList(new ArrayList<>());
    private final Transport transport;
    private final String command;
    private final List<String> args;
    private final String host;
    private final int port;
    private final Duration timeout;
    private final Duration connectTimeout;
    private final boolean skipBrowserDownload;

    private Process process;
    private Socket socket;
    private InputStream responseStream;
    private InputStream errorStream;
    private BufferedWriter writer;
    private ExecutorService ioPool;

    /** Legacy child-process stdio mode. */
    public McpClient(String command, List<String> args, Duration timeout, boolean skipBrowserDownload) {
        this.transport = Transport.PROCESS_STDIO;
        this.command = command;
        this.args = args == null ? List.of() : List.copyOf(args);
        this.host = null;
        this.port = -1;
        this.timeout = timeout == null ? Duration.ofSeconds(60) : timeout;
        this.connectTimeout = Duration.ofSeconds(15);
        this.skipBrowserDownload = skipBrowserDownload;
    }

    private McpClient(String host, int port, Duration connectTimeout, Duration requestTimeout) {
        this.transport = Transport.EXTERNAL_TCP;
        this.command = null;
        this.args = List.of();
        this.host = host == null || host.isBlank() ? "127.0.0.1" : host.trim();
        this.port = port;
        this.timeout = requestTimeout == null ? Duration.ofSeconds(60) : requestTimeout;
        this.connectTimeout = connectTimeout == null ? Duration.ofSeconds(10) : connectTimeout;
        this.skipBrowserDownload = true;
    }

    public static McpClient externalTcp(String host, int port, Duration connectTimeout, Duration requestTimeout) {
        if (port < 1 || port > 65535) throw new IllegalArgumentException("Invalid external MCP port: " + port);
        return new McpClient(host, port, connectTimeout, requestTimeout);
    }

    public void start() throws Exception {
        if (transport == Transport.EXTERNAL_TCP) startExternalTcp();
        else startProcessStdio();
        startReaders();
    }

    private void startProcessStdio() throws Exception {
        if (command == null || command.isBlank()) throw new IllegalStateException("Vibium MCP command is empty");
        List<String> cmd = new ArrayList<>();
        cmd.add(command);
        cmd.addAll(args);
        ProcessBuilder builder = new ProcessBuilder(cmd);
        builder.redirectErrorStream(false);
        if (skipBrowserDownload) builder.environment().put("VIBIUM_SKIP_BROWSER_DOWNLOAD", "1");
        transcript.add(Map.of("ts", Instant.now().toString(), "event", "process_start", "transport", "PROCESS_STDIO", "command", cmd));
        process = builder.start();
        responseStream = process.getInputStream();
        errorStream = process.getErrorStream();
        writer = new BufferedWriter(new OutputStreamWriter(process.getOutputStream(), StandardCharsets.UTF_8));
    }

    private void startExternalTcp() throws Exception {
        transcript.add(Map.of("ts", Instant.now().toString(), "event", "external_connect", "transport", "EXTERNAL_TCP", "host", host, "port", port));
        socket = new Socket();
        socket.setKeepAlive(true);
        socket.setTcpNoDelay(true);
        try {
            socket.connect(new InetSocketAddress(host, port), Math.toIntExact(Math.min(Integer.MAX_VALUE, connectTimeout.toMillis())));
        } catch (IOException e) {
            try { socket.close(); } catch (Exception ignored) { }
            throw new IllegalStateException("Cannot connect to local Vibium MCP bridge at " + host + ":" + port
                    + ". Start the bridge first using start-local-mcp-windows.cmd or start-local-mcp-mac.sh. Cause: " + e.getMessage(), e);
        }
        responseStream = socket.getInputStream();
        errorStream = null; // bridge keeps Vibium stderr in its own terminal/log so JSON-RPC is never corrupted
        writer = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream(), StandardCharsets.UTF_8));
        logs.add("Connected to external MCP bridge at " + host + ":" + port);
    }

    private void startReaders() {
        int threads = errorStream == null ? 1 : 2;
        ioPool = Executors.newFixedThreadPool(threads, r -> {
            Thread t = new Thread(r, "mcp-io");
            t.setDaemon(true);
            return t;
        });
        ioPool.submit(this::readStdoutLoop);
        if (errorStream != null) ioPool.submit(this::readStderrLoop);
    }

    public List<McpTool> initializeAndListTools() throws Exception {
        ObjectNode params = mapper.createObjectNode();
        params.put("protocolVersion", "2024-11-05");
        ObjectNode capabilities = params.putObject("capabilities");
        capabilities.putObject("sampling");
        ObjectNode roots = capabilities.putObject("roots");
        roots.put("listChanged", false);
        ObjectNode clientInfo = params.putObject("clientInfo");
        clientInfo.put("name", "itps-vibium-framework");
        clientInfo.put("version", "1.0.0");
        request("initialize", params);

        ObjectNode initialized = mapper.createObjectNode();
        initialized.put("jsonrpc", "2.0");
        initialized.put("method", "notifications/initialized");
        initialized.set("params", mapper.createObjectNode());
        send(initialized);

        JsonNode toolsResponse = request("tools/list", mapper.createObjectNode());
        List<McpTool> tools = new ArrayList<>();
        JsonNode toolsNode = toolsResponse.path("tools");
        if (toolsNode.isArray()) {
            for (JsonNode n : toolsNode) {
                tools.add(new McpTool(n.path("name").asText(), n.path("description").asText(""), n.path("inputSchema")));
            }
        }
        return tools;
    }

    public JsonNode callTool(String name, Map<String, Object> arguments) throws Exception {
        ObjectNode params = mapper.createObjectNode();
        params.put("name", name);
        params.set("arguments", mapper.valueToTree(arguments == null ? Map.of() : arguments));
        return request("tools/call", params);
    }

    public JsonNode request(String method, JsonNode params) throws Exception {
        boolean sensitiveCookieCall = isSensitiveCookieCall(method, params);
        long id = idCounter.getAndIncrement();
        ObjectNode msg = mapper.createObjectNode();
        msg.put("jsonrpc", "2.0");
        msg.put("id", id);
        msg.put("method", method);
        msg.set("params", params == null ? mapper.createObjectNode() : params);
        CompletableFuture<JsonNode> future = new CompletableFuture<>();
        pending.put(id, future);
        long start = System.currentTimeMillis();
        send(msg);
        try {
            JsonNode response = future.get(timeout.toMillis(), TimeUnit.MILLISECONDS);
            long ms = System.currentTimeMillis() - start;
            transcript.add(Map.of("ts", Instant.now().toString(), "direction", "response", "method", method, "id", id, "ms", ms,
                    "payload", compact(sensitiveCookieCall ? redactSensitive(response).toString() : response.toString(), 8000)));
            if (response.has("error")) {
                JsonNode safeError = sensitiveCookieCall ? redactSensitive(response.path("error")) : response.path("error");
                throw new IllegalStateException("MCP error for " + method + ": " + safeError);
            }
            return response.path("result");
        } catch (TimeoutException te) {
            pending.remove(id);
            transcript.add(Map.of("ts", Instant.now().toString(), "direction", "timeout", "method", method, "id", id, "timeoutSeconds", timeout.toSeconds()));
            throw new IllegalStateException("MCP timeout after " + timeout.toSeconds() + " seconds for method " + method);
        } catch (ExecutionException ee) {
            Throwable cause = ee.getCause() == null ? ee : ee.getCause();
            throw new IllegalStateException("MCP connection closed while waiting for " + method + ": " + cause.getMessage(), cause);
        }
    }

    private synchronized void send(ObjectNode msg) throws IOException {
        if (writer == null) throw new IOException("MCP transport is not started");
        String line = mapper.writeValueAsString(msg);
        boolean sensitiveCookieCall = isSensitiveCookieCall(msg.path("method").asText(""), msg.path("params"));
        String transcriptLine = sensitiveCookieCall ? mapper.writeValueAsString(redactSensitive(msg)) : line;
        transcript.add(Map.of("ts", Instant.now().toString(), "direction", "request", "payload", compact(transcriptLine, 8000)));
        writer.write(line);
        writer.newLine();
        writer.flush();
    }

    private void readStdoutLoop() {
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(responseStream, StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String trimmed = line.trim();
                if (trimmed.isBlank()) continue;
                if (!trimmed.startsWith("{")) {
                    logs.add("OUT: " + trimmed);
                    transcript.add(Map.of("ts", Instant.now().toString(), "direction", "stdout", "line", trimmed));
                    continue;
                }
                try {
                    JsonNode msg = mapper.readTree(trimmed);
                    if (msg.has("id")) {
                        long id = msg.path("id").asLong();
                        CompletableFuture<JsonNode> future = pending.remove(id);
                        if (future != null) future.complete(msg);
                    } else {
                        logs.add("NOTIFY: " + trimmed);
                        transcript.add(Map.of("ts", Instant.now().toString(), "direction", "notify", "payload", compact(trimmed, 8000)));
                    }
                } catch (Exception parseError) {
                    logs.add("OUT-NON-JSON: " + trimmed);
                }
            }
            failPending(new EOFException(connectionEndedMessage()));
        } catch (Exception e) {
            logs.add("MCP response reader closed: " + e.getMessage());
            failPending(e);
        }
    }

    private void readStderrLoop() {
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(errorStream, StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (!line.isBlank()) {
                    logs.add("ERR: " + line);
                    transcript.add(Map.of("ts", Instant.now().toString(), "direction", "stderr", "line", line));
                }
            }
        } catch (Exception e) {
            logs.add("stderr reader closed: " + e.getMessage());
        }
    }

    private void failPending(Throwable error) {
        pending.forEach((id, future) -> future.completeExceptionally(error));
        pending.clear();
    }

    private String connectionEndedMessage() {
        List<String> snapshot;
        synchronized (logs) {
            snapshot = new ArrayList<>(logs);
        }
        int from = Math.max(0, snapshot.size() - 5);
        String tail = snapshot.subList(from, snapshot.size()).stream()
                .map(this::safeTransportDiagnostic)
                .filter(value -> !value.isBlank())
                .reduce((left, right) -> left + " | " + right)
                .orElse("");
        return tail.isBlank() ? "MCP stream ended" : "MCP stream ended. Last transport output: " + tail;
    }

    private String safeTransportDiagnostic(String value) {
        if (value == null) return "";
        String safe = value.replaceAll("(?i)(cookie[^=:\\s]*[=:]\\s*)[^;\\s]+", "$1[REDACTED]")
                .replaceAll("[\\r\\n]+", " ")
                .replaceAll("\\s+", " ")
                .trim();
        return compact(safe, 1000);
    }

    public List<String> getLogs() { return List.copyOf(logs); }
    public List<Map<String, Object>> getTranscript() { return List.copyOf(transcript); }

    public void writeDiagnostics(Path runDir) {
        try {
            Files.createDirectories(runDir);
            mapper.writerWithDefaultPrettyPrinter().writeValue(runDir.resolve("mcp-transcript.json").toFile(), getTranscript());
            Files.writeString(runDir.resolve("mcp-process.log"), String.join(System.lineSeparator(), getLogs()), StandardCharsets.UTF_8);
        } catch (Exception ignored) { }
    }

    @Override
    public void close() {
        try { if (writer != null) writer.close(); } catch (Exception ignored) { }
        try { if (socket != null) socket.close(); } catch (Exception ignored) { }
        if (process != null && process.isAlive()) {
            process.destroy();
            try { if (!process.waitFor(3, TimeUnit.SECONDS)) process.destroyForcibly(); }
            catch (InterruptedException e) { Thread.currentThread().interrupt(); process.destroyForcibly(); }
        }
        if (ioPool != null) ioPool.shutdownNow();
        failPending(new CancellationException("MCP client closed"));
    }

    private String compact(String s, int max) {
        if (s == null) return "";
        String oneLine = s.replaceAll("\\s+", " ").trim();
        return oneLine.length() <= max ? oneLine : oneLine.substring(0, max) + "...";
    }

    private boolean isSensitiveCookieCall(String method, JsonNode params) {
        if (!"tools/call".equals(method) || params == null) return false;
        String toolName = params.path("name").asText("").toLowerCase(Locale.ROOT);
        return toolName.contains("cookie") || toolName.contains("storage_state")
                || toolName.contains("restore_storage");
    }

    private JsonNode redactSensitive(JsonNode source) {
        JsonNode copy = source == null ? mapper.nullNode() : source.deepCopy();
        redactSensitiveInPlace(copy);
        return copy;
    }

    private void redactSensitiveInPlace(JsonNode node) {
        if (node == null) return;
        if (node.isObject()) {
            ObjectNode object = (ObjectNode) node;
            List<String> fields = new ArrayList<>();
            object.fieldNames().forEachRemaining(fields::add);
            for (String field : fields) {
                JsonNode value = object.get(field);
                if (field.equalsIgnoreCase("value") || field.equalsIgnoreCase("cookieValue")
                        || field.equalsIgnoreCase("sessionCookieValue")) {
                    object.put(field, "[REDACTED]");
                } else if (value != null && value.isTextual()) {
                    String text = value.asText().trim();
                    if (text.startsWith("{") || text.startsWith("[")) {
                        try {
                            JsonNode parsed = mapper.readTree(text);
                            redactSensitiveInPlace(parsed);
                            object.put(field, mapper.writeValueAsString(parsed));
                        } catch (Exception ignored) { }
                    }
                } else {
                    redactSensitiveInPlace(value);
                }
            }
        } else if (node.isArray()) {
            for (JsonNode child : node) redactSensitiveInPlace(child);
        }
    }
}
