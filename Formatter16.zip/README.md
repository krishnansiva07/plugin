# FormatFlow AI

FormatFlow AI is a Java 17 + Spring Boot formatter for **Confluence, Email/Outlook, HTML, and PowerPoint**. It uses an LLM for semantic/editorial planning and Java for deterministic validation, sanitization, rendering, pagination, and export.

## Core workflow

```text
Source text / uploaded document
        ↓
ANALYZE
LLM builds a global editorial or presentation plan
        ↓
CREATE
LLM restructures content for the selected destination/design
        ↓
REVIEW
LLM + Java validate quality, coverage, structure and destination fitness
        ↓
REPAIR (maximum one semantic repair by default, when required)
        ↓
Java sanitizer / renderer
        ↓
Confluence / Email / HTML / PowerPoint
```

Transient LLM requests are retried up to **10 total attempts** before the request is marked unavailable. If all attempts fail, FormatFlow preserves the source/best generated content and uses deterministic fallback so the UI flow does not crash.

## PowerPoint: LLM presentation planner

PowerPoint uses a presentation-specific planning contract. The LLM is responsible for deciding:

- deck narrative and slide purpose
- BNP-green predefined layout
- whether a chart is appropriate
- native chart type
- whether a diagram is appropriate
- diagram type
- how source content should be grouped or shortened for that design
- the exact source-backed data evidence required for charts

Java remains the final safety layer. It validates the LLM choice, preserves factual content, rejects incompatible visuals, paginates overflow, and renders editable PowerPoint objects.

### BNP-green predefined layouts

Supported layouts include:

- Executive overview
- Key message
- Bullets
- Two column
- Three cards (2 + 1)
- Four cards (2 x 2)
- Five-step process
- Checklist
- Table
- Chart
- Diagram
- Code / JSON
- Comparison
- Timeline
- Next steps

Cards are **not** inferred merely because the content happens to contain three or four headings. The LLM must intentionally select a card layout, and Java validates that the content is genuinely peer-grouped.

### Native PowerPoint charts

Supported editable chart types:

- Column
- Horizontal bar
- Line
- Area
- Pie
- Doughnut
- Scatter
- Radar

A chart is allowed only when real numeric source data is available. The LLM planner records exact chart data evidence; CREATE must emit a real HTML table containing the categories and numeric series. Java checks that the table contains multiple source-backed data points before chart generation.

Chart-selection examples:

- ordered time trend → line
- cumulative/volume progression → area
- categorical comparison → column
- ranking/long category labels → horizontal bar
- part-to-whole → pie/doughnut
- numeric relationship → scatter
- multidimensional maturity/profile → radar

### Blank-chart runtime fix

PowerPoint chart frames are attached using Apache POI's XSLF chart-frame contract. The chart anchor passed to `slide.addChart(...)` is converted to **EMU** coordinates before attachment. Passing ordinary PowerPoint point values directly produced microscopic chart frames that appeared blank even though the slide title and insight panel rendered normally.

The renderer now:

1. creates the native `XSLFChart` part;
2. attaches it with an EMU-sized chart rectangle;
3. plots the source-backed data;
4. validates the embedded chart workbook and chart series;
5. falls back visibly to a BNP-green source-data table if native chart generation cannot complete.

A chart failure never leaves an empty chart rectangle and never cancels the whole PPTX export.

Regression coverage includes the business sample used during development:

- Revenue Jan–Sep: 260, 275, 290, 305, 320, 340, 360, 380, 410
- Regional share: EMEA 45%, APAC 35%, AMER 20%

The regression verifies chart types, source labels/values, embedded workbook data, and non-microscopic chart-frame extents.

### Native PowerPoint diagrams

Supported BNP-green editable diagram designs:

- Linear process
- Chevron process
- Cycle
- Swimlane
- Hierarchy
- Hub and spoke
- Pipeline
- Architecture flow
- Funnel
- Pyramid
- 2 x 2 matrix
- Decision tree
- Feedback loop
- Converging flow
- Diverging flow
- Before / after
- Comparison flow
- Roadmap

The LLM chooses the diagram based on source meaning. Java validates structure and can reject/replace an unsuitable diagram without inventing facts. Diagrams use native PowerPoint shapes/connectors rather than screenshots.

### PowerPoint overflow/content preservation

The renderer does not silently discard content. It creates continuation slides for:

- long bullet groups
- large tables
- wide tables
- crowded charts
- long processes
- excess cards
- large diagrams/swimlanes

Checkbox/list glyphs are normalized so a list does not render duplicate markers such as `• □ item`.

## Confluence

Confluence preview, rich clipboard copy, and HTML export derive from one canonical sanitized HTML tree. Supported structures include:

- H1-H4 hierarchy
- paragraphs
- bullets and numbered lists
- real HTML tables
- blockquote callouts
- pre/code blocks
- emphasis and links

Large tables preserve all data rows. Header rows are normalized into `thead`, preventing the header from being counted again inside `tbody`.

## Email / Outlook

Email uses the same semantic workflow with destination-specific guidance. The Java renderer applies conservative inline formatting suitable for Outlook-style editors. Subject generation is optional; if that LLM call fails, a deterministic local subject is used without losing the formatted body.

## HTML

HTML uses the sanitized semantic draft with the portable BNP-green web renderer.

## LLM configuration

The API key is entered in the UI and stored only in the server-side HTTP session.

```properties
formatflow.llm.base-url=https://ai4devs.group.echonet/api/v1
formatflow.llm.model=gpt-oss-120b
formatflow.llm.chat-path=/chat/completions
formatflow.llm.max-attempts=10
```

The application does not store the API key in `application.properties`.

## Build and run

Requirements:

- Java 17+
- Maven 3.9+

Windows:

```bat
test.bat
build.bat
run.bat
```

Or directly:

```bash
mvn clean test
mvn clean package
java -jar target/formatflow-ai-0.0.1-SNAPSHOT.jar
```

Open:

```text
http://localhost:8090
```

## Testing

The test suite includes coverage for:

- LLM analyze/create/review/repair orchestration
- 10-attempt LLM retry/fallback behavior
- Confluence canonical table handling and row preservation
- predefined BNP PowerPoint layouts
- content-aware chart selection
- all supported native chart families
- chart pagination
- chart embedded workbook/source-data preservation
- chart-frame EMU sizing regression
- Phase 1 + Phase 2 diagram catalog
- diagram overflow/fallback
- duplicate checklist-marker normalization
- lossless PowerPoint bullets/tables

Run the complete suite with:

```bash
mvn clean test
```

`test.bat` and `test.sh` are also provided and return a failing process status if Maven tests fail.

## Security and reliability controls

Java still controls executable/output safety:

- sanitizes model HTML
- removes scripts and unsupported tags/attributes
- restricts links to supported safe protocols
- keeps the API key session-only
- bounds semantic repair loops
- preserves source content during LLM failure
- does not invent chart or diagram data during local fallback

## Documentation policy

This `README.md` is the **single Markdown documentation file** shipped with the project. Feature changes, runtime fixes, architecture notes, and validation guidance are consolidated here to avoid multiple stale or conflicting `.md` files.

## Confluence Jsoup compatibility fix

Confluence table canonicalization uses explicit direct-child traversal rather than CSS `:scope > ...` selectors. This avoids `SelectorParseException` on Jsoup runtimes that reject that selector form while preserving the correct `<thead>` / `<tbody>` split and data-row counts.
