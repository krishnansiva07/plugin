#!/usr/bin/env sh
set -eu
mvn clean test
echo "All Maven tests PASSED."
