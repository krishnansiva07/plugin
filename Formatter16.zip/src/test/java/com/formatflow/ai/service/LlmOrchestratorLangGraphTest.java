package com.formatflow.ai.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

class LlmOrchestratorLangGraphTest {

    @Test
    void langGraphFinalizesAfterAnalyzeCreateAndPassingReview() {
        LlmClient client = mock(LlmClient.class);
        ObjectMapper mapper = new ObjectMapper();
        IconCatalog icons = new IconCatalog();
        PromptFactory prompts = new PromptFactory(mapper, icons);
        LlmOrchestrator orchestrator = new LlmOrchestrator(
                client, prompts, new ContentParser(), mapper, icons,
                9000, 40, 1, 80, 18000, 28000
        );

        when(client.chat(anyString(), anyString(), anyInt(), anyDouble()))
                .thenReturn("- Use one clear overview section\n- Preserve employee capabilities")
                .thenReturn("<h2>About me</h2><p>Employee self-service overview.</p><ul><li>Maintain profiles</li><li>Access appraisal reviews</li></ul>")
                .thenReturn("{\"pass\":true,\"score\":94,\"issues\":[],\"repairInstruction\":\"\"}");

        LlmOrchestrator.FreeformOutcome result = orchestrator.freeform(
                "key",
                "About me application lets employees maintain profiles and access appraisal reviews.",
                "Co-worker",
                "New joiner onboarding",
                "CONFLUENCE",
                "FORMAT",
                "Short"
        );

        assertThat(result.html()).contains("<h2>About me</h2>", "Maintain profiles");
        assertThat(result.llmCalls()).isEqualTo(3);
        assertThat(result.chunks()).isEqualTo(1);
        assertThat(result.workflowActivity()).contains("Analyze", "Create", "Review").doesNotContain("Repair");
        verify(client, times(3)).chat(anyString(), anyString(), anyInt(), anyDouble());
    }

    @Test
    void langGraphRunsOneBoundedRepairPassWhenReviewFails() {
        LlmClient client = mock(LlmClient.class);
        ObjectMapper mapper = new ObjectMapper();
        IconCatalog icons = new IconCatalog();
        PromptFactory prompts = new PromptFactory(mapper, icons);
        LlmOrchestrator orchestrator = new LlmOrchestrator(
                client, prompts, new ContentParser(), mapper, icons,
                9000, 40, 1, 80, 18000, 28000
        );

        when(client.chat(anyString(), anyString(), anyInt(), anyDouble()))
                .thenReturn("- Merge repeated ideas\n- Keep the page easy to scan")
                .thenReturn("<h2>About me</h2><p>Overview.</p><h2>About me</h2><p>Repeated overview.</p>")
                .thenReturn("{\"pass\":false,\"score\":62,\"issues\":[\"Duplicate heading\"],\"repairInstruction\":\"Merge the repeated About me section.\"}")
                .thenReturn("<h2>About me</h2><p>Overview.</p><ul><li>Maintain profiles</li></ul>")
                .thenReturn("{\"pass\":true,\"score\":93,\"issues\":[],\"repairInstruction\":\"\"}");

        LlmOrchestrator.FreeformOutcome result = orchestrator.freeform(
                "key",
                "About me application lets employees maintain profiles.",
                "Co-worker",
                "Inform",
                "CONFLUENCE",
                "FORMAT",
                "Short"
        );

        assertThat(result.html()).contains("<h2>About me</h2>").doesNotContain("Repeated overview");
        assertThat(result.llmCalls()).isEqualTo(5);
        assertThat(result.workflowActivity()).contains("Repair");
        verify(client, times(5)).chat(anyString(), anyString(), anyInt(), anyDouble());
    }
    @Test
    void llmOutageFallsBackWithoutBreakingFormattingFlow() {
        LlmClient client = mock(LlmClient.class);
        ObjectMapper mapper = new ObjectMapper();
        IconCatalog icons = new IconCatalog();
        PromptFactory prompts = new PromptFactory(mapper, icons);
        LlmOrchestrator orchestrator = new LlmOrchestrator(
                client, prompts, new ContentParser(), mapper, icons,
                9000, 40, 1, 80, 18000, 28000
        );

        when(client.chat(anyString(), anyString(), anyInt(), anyDouble()))
                .thenThrow(new IllegalStateException("LLM service returned HTTP 503."));

        LlmOrchestrator.FreeformOutcome result = orchestrator.freeform(
                "key",
                "Automation Platform\n- Preserve every test case\n- Generate PowerPoint without dropping table rows",
                "Technical Team",
                "Knowledge Sharing",
                "POWERPOINT",
                "FORMAT",
                "Short"
        );

        assertThat(result.html())
                .contains("Automation Platform")
                .contains("Preserve every test case")
                .contains("Generate PowerPoint without dropping table rows");
        assertThat(result.workflowActivity()).contains("Resilient fallback");
        assertThat(result.llmCalls()).isEqualTo(1);
    }

    @Test
    void powerpointUsesLlmAsStructuredPresentationPlanner() {
        LlmClient client = mock(LlmClient.class);
        ObjectMapper mapper = new ObjectMapper();
        IconCatalog icons = new IconCatalog();
        PromptFactory prompts = new PromptFactory(mapper, icons);
        LlmOrchestrator orchestrator = new LlmOrchestrator(
                client, prompts, new ContentParser(), mapper, icons,
                9000, 40, 1, 80, 18000, 28000
        );

        String plannerJson = """
                {
                  "deckNarrative":"Show the execution trend visually.",
                  "slides":[{
                    "slideId":"S1",
                    "purpose":"Show monthly execution growth",
                    "layout":"CHART",
                    "chartType":"LINE",
                    "diagramType":"NONE",
                    "contentStrategy":"Use the source month/execution table as a line chart",
                    "designReason":"Ordered monthly values are a trend"
                  }]
                }
                """;
        String createHtml = """
                <h1>Execution Trend</h1>
                <h2 data-layout="CHART" data-chart="LINE">Monthly execution trend</h2>
                <table><tr><th>Month</th><th>Executions</th></tr><tr><td>Jan</td><td>100</td></tr><tr><td>Feb</td><td>135</td></tr><tr><td>Mar</td><td>162</td></tr></table>
                """;

        when(client.chat(anyString(), anyString(), anyInt(), anyDouble()))
                .thenReturn(plannerJson)
                .thenReturn(createHtml)
                .thenReturn("{\"pass\":true,\"score\":96,\"issues\":[],\"repairInstruction\":\"\"}");

        LlmOrchestrator.FreeformOutcome result = orchestrator.freeform(
                "key",
                "Monthly execution trend\nMonth | Executions\nJan | 100\nFeb | 135\nMar | 162",
                "Management",
                "Knowledge Sharing",
                "POWERPOINT",
                "FORMAT",
                "Short"
        );

        assertThat(result.html()).contains("data-layout=\"CHART\"", "data-chart=\"LINE\"");
        assertThat(result.workflowActivity()).contains("LLM Presentation Planner", "Analyze design", "Review design");
        assertThat(result.llmCalls()).isEqualTo(3);

        ArgumentCaptor<String> promptCaptor = ArgumentCaptor.forClass(String.class);
        verify(client, times(3)).chat(anyString(), promptCaptor.capture(), anyInt(), anyDouble());
        assertThat(promptCaptor.getAllValues().get(0)).contains("POWERPOINT PRESENTATION-PLANNER OUTPUT CONTRACT", "chartType", "diagramType");
        assertThat(promptCaptor.getAllValues().get(1)).contains("Show the execution trend visually", "\"layout\":\"CHART\"", "\"chartType\":\"LINE\"");
    }

    @Test
    void malformedPowerpointPlannerGetsOneSemanticRepairBeforeFallback() {
        LlmClient client = mock(LlmClient.class);
        ObjectMapper mapper = new ObjectMapper();
        IconCatalog icons = new IconCatalog();
        PromptFactory prompts = new PromptFactory(mapper, icons);
        LlmOrchestrator orchestrator = new LlmOrchestrator(
                client, prompts, new ContentParser(), mapper, icons,
                9000, 40, 1, 80, 18000, 28000
        );

        when(client.chat(anyString(), anyString(), anyInt(), anyDouble()))
                .thenReturn("Use a nice chart")
                .thenReturn("{\"deckNarrative\":\"Trend\",\"slides\":[{\"slideId\":\"S1\",\"purpose\":\"Trend\",\"layout\":\"CHART\",\"chartType\":\"LINE\",\"diagramType\":\"NONE\",\"contentStrategy\":\"Plot month values\",\"designReason\":\"Ordered time series\"}]}")
                .thenReturn("<h1>Trend</h1><h2 data-layout=\"CHART\" data-chart=\"LINE\">Trend</h2><table><tr><th>Month</th><th>Runs</th></tr><tr><td>Jan</td><td>10</td></tr><tr><td>Feb</td><td>20</td></tr></table>")
                .thenReturn("{\"pass\":true,\"score\":95,\"issues\":[],\"repairInstruction\":\"\"}");

        LlmOrchestrator.FreeformOutcome result = orchestrator.freeform(
                "key", "Trend\nJan 10\nFeb 20", "Management", "Inform", "POWERPOINT", "FORMAT", "Short");

        assertThat(result.html()).contains("data-chart=\"LINE\"");
        assertThat(result.llmCalls()).isEqualTo(4);
        ArgumentCaptor<String> promptCaptor = ArgumentCaptor.forClass(String.class);
        verify(client, times(4)).chat(anyString(), promptCaptor.capture(), anyInt(), anyDouble());
        assertThat(promptCaptor.getAllValues().get(1)).contains("PRESENTATION-PLAN REPAIR");
    }

}
