@echo off
setlocal
echo Running FormatFlow AI tests...
call mvn clean test
if %errorlevel% neq 0 (
  echo.
  echo Tests FAILED. Review the Maven failure details above.
  exit /b %errorlevel%
)
echo.
echo All Maven tests PASSED.
endlocal
