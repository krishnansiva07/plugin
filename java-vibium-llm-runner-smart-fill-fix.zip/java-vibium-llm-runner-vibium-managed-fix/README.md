# Java Vibium LLM Runner - Smart Fill Fix

This build keeps **real Java Vibium** execution and fixes the issue where button clicks work but text values are not entered.

## What was fixed

1. Added a **page controls snapshot** before every step so the LLM can see available inputs, buttons, labels, placeholders, names and ids.
2. Improved the LLM prompt to force `FILL` action for Enter/Fill/Type steps and to use test data values.
3. Added explicit action JSON support inside Excel/JSON steps.
4. Added a **Smart Fill fallback**:
   - First tries Vibium `find(...).fill(value)`.
   - If field lookup fails, it uses a JS fallback to find visible inputs by label, placeholder, id, name, aria-label, type and nearby text.
   - Dispatches `input`, `change`, and `keyup` events so React/Angular forms can detect the value.

## Recommended Excel format

Use one row per scenario. Supported columns:

```text
id | name | url | steps | expected | data.username | data.password | data.email | testDataJson
```

For stable execution, use explicit JSON actions in the `steps` column, one action per line:

```json
{"action":"NAVIGATE"}
{"action":"FILL","selectorType":"auto","target":"username","value":"{{username}}"}
{"action":"FILL","selectorType":"auto","target":"password","value":"{{password}}"}
{"action":"CLICK","selectorType":"role","target":"button:Login"}
{"action":"ASSERT_TEXT","value":"Products"}
```

Natural-language steps are still supported:

```text
Open login page
Enter {{username}} in username field
Enter {{password}} in password field
Click Login button
Verify Products
```

## Browser mode

Use:

```text
Browser launch mode = Vibium Managed Chrome for Testing
```

ChromeDriver path is not used by pure Vibium Java.

## Run

```bash
mvn clean spring-boot:run
```

Open:

```text
http://localhost:8090
```

## Corporate network note

If Chrome for Testing download is blocked, install/copy Vibium cache from a machine where `vibium install` works, then run with:

```cmd
set VIBIUM_SKIP_BROWSER_DOWNLOAD=1
mvn clean spring-boot:run
```
