package com.llmart.llm.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.llmart.llm.model.RunConfig;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.*;

@Service
public class LlmClient {
    private final ObjectMapper mapper = new ObjectMapper();
    private final RestTemplate restTemplate = new RestTemplate();

    public String plan(String prompt, RunConfig config) throws Exception {
        if (config.getLlmBaseUrl() == null || config.getLlmBaseUrl().isBlank()) {
            throw new IllegalArgumentException("LLM base URL is required when Use LLM is ON");
        }
        String endpoint = normalizeEndpoint(config.getLlmBaseUrl());

        Map<String, Object> body = new LinkedHashMap<>();
        body.put("model", defaultIfBlank(config.getLlmModel(), "gpt-oss-120b"));
        body.put("temperature", 0.1);
        body.put("max_tokens", 700);
        body.put("messages", List.of(
                Map.of("role", "system", "content", systemPrompt()),
                Map.of("role", "user", "content", prompt)
        ));

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        if (config.getLlmApiKey() != null && !config.getLlmApiKey().isBlank()) {
            headers.setBearerAuth(config.getLlmApiKey().trim());
        }
        String raw = restTemplate.postForObject(endpoint, new HttpEntity<>(body, headers), String.class);
        JsonNode root = mapper.readTree(raw);
        String content = root.path("choices").path(0).path("message").path("content").asText();
        return extractJson(content);
    }

    private String systemPrompt() {
        return "You are a Java Vibium browser automation planner. " +
                "Return only one minified JSON object. No markdown. " +
                "Allowed action values: NAVIGATE, CLICK, FILL, TYPE, PRESS, SELECT, CHECK, UNCHECK, ASSERT_TEXT, WAIT. " +
                "Allowed selectorType values: auto, css, text, label, placeholder, role, title, testid, xpath. Prefer auto for input fields if uncertain. " +
                "For Enter/Fill/Type instructions you must return FILL with a non-empty value from test data. " +
                "Example for login field: {\"action\":\"FILL\",\"selectorType\":\"auto\",\"target\":\"Username\",\"value\":\"john\"}. " +
                "Example for button: {\"action\":\"CLICK\",\"selectorType\":\"role\",\"target\":\"button:Login\"}.";
    }

    private String normalizeEndpoint(String base) {
        String trimmed = base.trim();
        if (trimmed.endsWith("/chat/completions")) return trimmed;
        if (trimmed.endsWith("/")) return trimmed + "chat/completions";
        return trimmed + "/chat/completions";
    }

    private String extractJson(String content) {
        if (content == null) return "{}";
        String trimmed = content.trim();
        if (trimmed.startsWith("```")) {
            trimmed = trimmed.replaceFirst("^```(?:json)?", "").replaceFirst("```$", "").trim();
        }
        int start = trimmed.indexOf('{');
        int end = trimmed.lastIndexOf('}');
        if (start >= 0 && end >= start) {
            return trimmed.substring(start, end + 1);
        }
        return trimmed;
    }

    private String defaultIfBlank(String value, String fallback) {
        return value == null || value.isBlank() ? fallback : value;
    }
}
