package com.llmart.llm.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.llmart.llm.model.RunConfig;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Starts the user supplied chromedriver.exe, creates a WebDriver BiDi session,
 * and exposes the returned webSocketUrl to Vibium through StartOptions.connectURL(...).
 *
 * Important: this is not Selenium. ChromeDriver is used only as a small local
 * WebDriver BiDi bridge because Vibium expects a BiDi websocket, not a CDP
 * /json/version websocket.
 */
public class ChromedriverBidiManager implements AutoCloseable {
    private final Process driverProcess;
    private final String sessionId;
    private final String connectUrl;
    private final String driverBaseUrl;
    private final HttpClient client;

    private ChromedriverBidiManager(Process driverProcess,
                                    String sessionId,
                                    String connectUrl,
                                    String driverBaseUrl,
                                    HttpClient client) {
        this.driverProcess = driverProcess;
        this.sessionId = sessionId;
        this.connectUrl = connectUrl;
        this.driverBaseUrl = driverBaseUrl;
        this.client = client;
    }

    public String getConnectUrl() {
        return connectUrl;
    }

    public static ChromedriverBidiManager fromConfig(RunConfig config, Path runDir) throws Exception {
        String driverPath = blankToNull(config.getChromeDriverPath());
        String browserPath = blankToNull(config.getChromeBinaryPath());

        if (driverPath == null) {
            throw new IllegalArgumentException("ChromeDriver path is required for ChromeDriver BiDi mode. Browse/select chromedriver.exe in the UI.");
        }
        if (browserPath == null) {
            throw new IllegalArgumentException("Chrome/Chromium/Edge executable path is required. Paste chrome.exe/chromium.exe/msedge.exe path in the UI.");
        }

        Path driverExe = Path.of(driverPath);
        Path browserExe = Path.of(browserPath);
        if (!Files.exists(driverExe)) {
            throw new IllegalArgumentException("ChromeDriver executable not found: " + driverPath);
        }
        if (!Files.exists(browserExe)) {
            throw new IllegalArgumentException("Browser executable not found: " + browserPath);
        }
        driverExe.toFile().setExecutable(true);

        int port = config.getRemoteDebugPort() != null && config.getRemoteDebugPort() > 0
                ? config.getRemoteDebugPort()
                : findFreePort();
        String driverBaseUrl = "http://127.0.0.1:" + port;

        Files.createDirectories(runDir);
        Path driverLog = runDir.resolve("chromedriver-bidi.log");

        List<String> command = new ArrayList<>();
        command.add(driverExe.toAbsolutePath().toString());
        command.add("--port=" + port);
        command.add("--allowed-origins=*");

        ProcessBuilder pb = new ProcessBuilder(command);
        pb.redirectErrorStream(true);
        pb.redirectOutput(driverLog.toFile());
        Process process = pb.start();

        HttpClient client = HttpClient.newBuilder()
                .connectTimeout(Duration.ofSeconds(2))
                .build();

        try {
            waitForDriverReady(client, process, driverBaseUrl, driverLog);
            SessionInfo session = createBidiSession(client, driverBaseUrl, browserExe, config, runDir);
            return new ChromedriverBidiManager(process, session.sessionId(), session.webSocketUrl(), driverBaseUrl, client);
        } catch (Exception e) {
            process.destroyForcibly();
            throw e;
        }
    }

    private static void waitForDriverReady(HttpClient client, Process process, String driverBaseUrl, Path driverLog) throws Exception {
        Exception last = null;
        long end = System.currentTimeMillis() + 20_000;
        while (System.currentTimeMillis() < end) {
            if (!process.isAlive()) {
                throw new IllegalStateException("ChromeDriver exited before it became ready. Check chromedriver path/version. Log: " + driverLog);
            }
            try {
                HttpRequest request = HttpRequest.newBuilder(URI.create(driverBaseUrl + "/status"))
                        .timeout(Duration.ofSeconds(2))
                        .GET()
                        .build();
                HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
                if (response.statusCode() >= 200 && response.statusCode() < 300) {
                    return;
                }
            } catch (Exception e) {
                last = e;
            }
            Thread.sleep(300);
        }
        throw new IllegalStateException("Timed out waiting for ChromeDriver at " + driverBaseUrl + ". Log: " + driverLog +
                (last == null ? "" : " | Last error: " + last.getMessage()), last);
    }

    private static SessionInfo createBidiSession(HttpClient client,
                                                 String driverBaseUrl,
                                                 Path browserExe,
                                                 RunConfig config,
                                                 Path runDir) throws Exception {
        ObjectMapper mapper = new ObjectMapper();

        Path profileDir = runDir.resolve("chromedriver-browser-profile");
        Files.createDirectories(profileDir);

        String browserPath = browserExe.toAbsolutePath().toString();
        boolean isEdge = browserExe.getFileName().toString().toLowerCase(Locale.ROOT).contains("msedge");

        List<String> args = new ArrayList<>();
        args.add("--user-data-dir=" + profileDir.toAbsolutePath());
        args.add("--no-first-run");
        args.add("--no-default-browser-check");
        args.add("--disable-popup-blocking");
        args.add("--disable-extensions");
        if (config.isHeadless()) {
            args.add("--headless=new");
            args.add("--disable-gpu");
            args.add("--window-size=1366,768");
        }

        Map<String, Object> browserOptions = new LinkedHashMap<>();
        browserOptions.put("binary", browserPath);
        browserOptions.put("args", args);

        Map<String, Object> alwaysMatch = new LinkedHashMap<>();
        alwaysMatch.put("browserName", isEdge ? "MicrosoftEdge" : "chrome");
        alwaysMatch.put("webSocketUrl", true);
        alwaysMatch.put(isEdge ? "ms:edgeOptions" : "goog:chromeOptions", browserOptions);

        Map<String, Object> capabilities = new LinkedHashMap<>();
        capabilities.put("alwaysMatch", alwaysMatch);

        Map<String, Object> payload = new LinkedHashMap<>();
        payload.put("capabilities", capabilities);

        String body = mapper.writeValueAsString(payload);
        HttpRequest request = HttpRequest.newBuilder(URI.create(driverBaseUrl + "/session"))
                .timeout(Duration.ofSeconds(30))
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(body))
                .build();
        HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
        if (response.statusCode() < 200 || response.statusCode() >= 300) {
            throw new IllegalStateException("ChromeDriver could not create browser session. HTTP " + response.statusCode() + ": " + response.body());
        }

        JsonNode root = mapper.readTree(response.body());
        JsonNode value = root.path("value");
        String sessionId = value.path("sessionId").asText(null);
        JsonNode caps = value.path("capabilities");
        String wsUrl = caps.path("webSocketUrl").asText(null);

        if (sessionId == null || sessionId.isBlank()) {
            throw new IllegalStateException("ChromeDriver session response did not contain sessionId: " + response.body());
        }
        if (wsUrl == null || wsUrl.isBlank()) {
            throw new IllegalStateException("ChromeDriver session was created but WebDriver BiDi webSocketUrl was missing. " +
                    "Use matching Chrome/Chromium and ChromeDriver versions, preferably 115+. " +
                    "Do not pass /json/version or /devtools/browser URL to Vibium; that is CDP, not WebDriver BiDi. Response: " + response.body());
        }

        return new SessionInfo(sessionId, wsUrl);
    }

    private static int findFreePort() throws IOException {
        try (ServerSocket socket = new ServerSocket(0)) {
            socket.setReuseAddress(true);
            return socket.getLocalPort();
        }
    }

    private static String blankToNull(String value) {
        return value == null || value.trim().isBlank() ? null : value.trim();
    }

    @Override
    public void close() {
        if (sessionId != null && !sessionId.isBlank()) {
            try {
                HttpRequest request = HttpRequest.newBuilder(URI.create(driverBaseUrl + "/session/" + sessionId))
                        .timeout(Duration.ofSeconds(5))
                        .DELETE()
                        .build();
                client.send(request, HttpResponse.BodyHandlers.discarding());
            } catch (Exception ignored) {
            }
        }
        if (driverProcess != null && driverProcess.isAlive()) {
            driverProcess.destroy();
            try {
                if (!driverProcess.waitFor(3, java.util.concurrent.TimeUnit.SECONDS)) {
                    driverProcess.destroyForcibly();
                }
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                driverProcess.destroyForcibly();
            }
        }
    }

    private record SessionInfo(String sessionId, String webSocketUrl) { }
}
