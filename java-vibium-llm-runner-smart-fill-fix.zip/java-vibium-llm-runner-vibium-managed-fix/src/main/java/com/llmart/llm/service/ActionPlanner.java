package com.llmart.llm.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.llmart.llm.model.AgentAction;
import com.llmart.llm.model.RunConfig;
import com.llmart.llm.model.TestScenario;
import org.springframework.stereotype.Service;

import java.util.Locale;
import java.util.Map;

@Service
public class ActionPlanner {
    private final LlmClient llmClient;
    private final ObjectMapper mapper = new ObjectMapper();

    public ActionPlanner(LlmClient llmClient) {
        this.llmClient = llmClient;
    }

    public AgentAction plan(TestScenario scenario, int stepNo, String step, String pageUrl, String pageTitle, String pageSnapshot, RunConfig config) throws Exception {
        String resolved = replaceData(step, scenario.getData());
        if (resolved.trim().startsWith("{") && resolved.trim().endsWith("}")) {
            AgentAction action = mapper.readValue(resolved, AgentAction.class);
            if (action.getTarget() != null) action.setTarget(replaceData(action.getTarget(), scenario.getData()));
            if (action.getValue() != null) action.setValue(replaceData(action.getValue(), scenario.getData()));
            if (action.getKey() != null) action.setKey(replaceData(action.getKey(), scenario.getData()));
            return action;
        }
        if (config.isUseLlm()) {
            String prompt = "Scenario: " + scenario.getName() + "\n" +
                    "Current URL: " + pageUrl + "\n" +
                    "Current title: " + pageTitle + "\n" +
                    "Visible controls JSON: " + pageSnapshot + "\n" +
                    "Test data JSON: " + mapper.writeValueAsString(scenario.getData()) + "\n" +
                    "Step number: " + stepNo + "\n" +
                    "Step instruction: " + resolved + "\n" +
                    "Rules: For Enter/Fill/Type steps return action FILL. Put field name/label/placeholder/name/id in target. Put the actual value from test data in value. For buttons use CLICK. Return exactly one JSON object.";
            String json = llmClient.plan(prompt, config);
            AgentAction action = mapper.readValue(json, AgentAction.class);
            if (action.getAction() == null || action.getAction().isBlank()) {
                throw new IllegalArgumentException("LLM returned action without action field: " + json);
            }
            if (action.getValue() != null) {
                action.setValue(replaceData(action.getValue(), scenario.getData()));
            }
            return action;
        }
        return heuristic(resolved, scenario);
    }

    public String toJson(AgentAction action) {
        try {
            return mapper.writeValueAsString(action);
        } catch (Exception e) {
            return String.valueOf(action);
        }
    }

    private AgentAction heuristic(String step, TestScenario scenario) {
        String lower = step.toLowerCase(Locale.ROOT);
        if (lower.startsWith("open ") || lower.startsWith("navigate") || lower.startsWith("go to ")) {
            String url = scenario.getUrl();
            int idx = lower.indexOf("http");
            if (idx >= 0) url = step.substring(idx).trim();
            return AgentAction.of("NAVIGATE", null, url, null);
        }
        if (lower.startsWith("wait")) {
            AgentAction a = AgentAction.of("WAIT", null, null, null);
            a.setSeconds(2);
            return a;
        }
        if (lower.contains("verify") || lower.contains("assert") || lower.contains("should see")) {
            String text = step.replaceAll("(?i)verify|assert|should see|text|is displayed|displayed", "").trim();
            return AgentAction.of("ASSERT_TEXT", "text", text.isBlank() ? scenario.getExpected() : text, null);
        }
        if (lower.contains("enter") || lower.contains("fill") || lower.contains("type")) {
            String value = guessValue(step, scenario.getData());
            String field = guessField(step);
            return AgentAction.of("FILL", "auto", field, value);
        }
        if (lower.contains("select")) {
            String value = guessValue(step, scenario.getData());
            String field = guessField(step);
            return AgentAction.of("SELECT", "auto", field, value);
        }
        if (lower.contains("press enter")) {
            AgentAction a = AgentAction.of("PRESS", null, null, null);
            a.setKey("Enter");
            return a;
        }
        if (lower.contains("uncheck")) {
            return AgentAction.of("UNCHECK", "text", cleanupTarget(step), null);
        }
        if (lower.contains("check")) {
            return AgentAction.of("CHECK", "text", cleanupTarget(step), null);
        }
        return AgentAction.of("CLICK", "text", cleanupTarget(step), null);
    }

    private String guessValue(String step, Map<String, Object> data) {
        String lower = step.toLowerCase(Locale.ROOT);
        for (Map.Entry<String, Object> entry : data.entrySet()) {
            String key = entry.getKey().toLowerCase(Locale.ROOT);
            String value = String.valueOf(entry.getValue());
            if (lower.contains(key) || lower.contains(key.replace("_", " ")) || lower.contains(value.toLowerCase(Locale.ROOT))) {
                return value;
            }
        }
        int idx = lower.indexOf("value ");
        if (idx >= 0) return step.substring(idx + 6).trim();
        idx = lower.indexOf(" as ");
        if (idx >= 0) return step.substring(idx + 4).trim();
        return "";
    }

    private String guessField(String step) {
        String cleaned = step.replaceAll("(?i)enter|fill|type|value|with|the", " ").trim();
        cleaned = cleaned.replaceAll("\\s+", " ");
        if (cleaned.toLowerCase(Locale.ROOT).contains(" in ")) {
            cleaned = cleaned.substring(cleaned.toLowerCase(Locale.ROOT).lastIndexOf(" in ") + 4).trim();
        }
        cleaned = cleaned.replaceAll("(?i)\\bfield\\b", " ").replaceAll("\\s+", " ").trim();
        return cleaned;
    }

    private String cleanupTarget(String step) {
        return step.replaceAll("(?i)click|button|link|tap|on|the|verify|assert|should see|is displayed|displayed", " ")
                .replaceAll("\\s+", " ")
                .trim();
    }

    private String replaceData(String text, Map<String, Object> data) {
        String resolved = text == null ? "" : text;
        if (data == null) return resolved;
        for (Map.Entry<String, Object> entry : data.entrySet()) {
            resolved = resolved.replace("{{" + entry.getKey() + "}}", String.valueOf(entry.getValue()));
        }
        return resolved;
    }
}
