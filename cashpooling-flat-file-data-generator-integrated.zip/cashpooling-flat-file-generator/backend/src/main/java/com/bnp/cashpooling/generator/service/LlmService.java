package com.bnp.cashpooling.generator.service;

import com.bnp.cashpooling.generator.model.GenerationRequest;
import com.bnp.cashpooling.generator.model.LlmInterpretRequest;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.List;
import java.util.Map;

@Service
public class LlmService {
    private final ObjectMapper mapper;
    private final String defaultBaseUrl;
    private final String defaultModel;
    private final Duration timeout;

    public LlmService(ObjectMapper mapper,
                      @Value("${llm.base-url}") String defaultBaseUrl,
                      @Value("${llm.model-name}") String defaultModel,
                      @Value("${llm.timeout-seconds:90}") long timeoutSeconds) {
        this.mapper = mapper;
        this.defaultBaseUrl = defaultBaseUrl;
        this.defaultModel = defaultModel;
        this.timeout = Duration.ofSeconds(timeoutSeconds);
    }

    public GenerationRequest interpret(LlmInterpretRequest request) throws Exception {
        String baseUrl = isBlank(request.getBaseUrl()) ? defaultBaseUrl : request.getBaseUrl().trim();
        String model = isBlank(request.getModelName()) ? defaultModel : request.getModelName().trim();
        String endpoint = baseUrl.replaceAll("/+$", "") + "/chat/completions";
        String systemPrompt = """
            You convert a plain-English fixed-width flat-file requirement into JSON for CASHPOOLING FLAT FILE DATA GENERATOR.
            Return ONLY valid JSON, no markdown. The JSON must match this shape:
            {
              "fileName":"CASHPOOLING_FILE",
              "recordCount":10,
              "lineSeparator":"CRLF",
              "encoding":"UTF-8",
              "header":{"enabled":true,"lineWidth":20,"fields":[FieldConfig...]},
              "detail":{"enabled":true,"lineWidth":100,"fields":[FieldConfig...]},
              "footer":{"enabled":true,"lineWidth":20,"fields":[FieldConfig...]}
            }
            FieldConfig keys: name,width,ruleType,value,prefix,suffix,format,startDate,endDate,inputDateFormat,dateStep,dateStepUnit,dateOffset,dateOffsetUnit,randomLength,sequenceStart,sequenceStep,
            sourceField,substringStart,substringLength,conditionField,conditionMap,defaultValue,alignment,padCharacter,truncate.
            ruleType must be one of STATIC, EMPTY, RANDOM_NUMERIC, RANDOM_ALPHA, RANDOM_ALPHANUMERIC, SEQUENCE,
            DATE_TIME, RANDOM_DATE_TIME, DATE_SEQUENCE, DEPENDENT_DATE, RECORD_COUNT, COPY_FIELD, SUBSTRING, CONDITIONAL, EXPRESSION.
            alignment is LEFT or RIGHT. For numeric record count use RECORD_COUNT, RIGHT alignment and padCharacter "0".
            Fields are contiguous and must fit within lineWidth. Dependencies may reference only earlier fields in the same section.
            For random dates between a start and end use RANDOM_DATE_TIME with startDate/endDate in yyyy-MM-ddT HH:mm-compatible form and inputDateFormat. For increasing dates use DATE_SEQUENCE. For a date based on an earlier field use DEPENDENT_DATE with sourceField, inputDateFormat, dateOffset and dateOffsetUnit.
            For composite values use EXPRESSION with placeholders such as ${recordNumber}, ${recordCount},
            ${timestamp:yyyyMMddHHmmss}, ${randomNumeric:6}, ${field:AccountNumber}.
            Do not include secrets or the API token in the result.
            """;
        Map<String, Object> body = Map.of(
            "model", model,
            "temperature", 0.1,
            "max_tokens", 3500,
            "messages", List.of(
                Map.of("role", "system", "content", systemPrompt),
                Map.of("role", "user", "content", request.getPrompt())
            )
        );
        HttpClient client = HttpClient.newBuilder().connectTimeout(timeout).build();
        HttpRequest httpRequest = HttpRequest.newBuilder(URI.create(endpoint))
            .timeout(timeout)
            .header("Authorization", "Bearer " + request.getToken())
            .header("Content-Type", "application/json")
            .POST(HttpRequest.BodyPublishers.ofString(mapper.writeValueAsString(body)))
            .build();
        HttpResponse<String> response = client.send(httpRequest, HttpResponse.BodyHandlers.ofString());
        if (response.statusCode() < 200 || response.statusCode() >= 300) {
            throw new IllegalStateException("LLM endpoint returned HTTP " + response.statusCode() + ". Verify token and endpoint access.");
        }
        JsonNode root = mapper.readTree(response.body());
        JsonNode contentNode = root.at("/choices/0/message/content");
        if (contentNode.isMissingNode() || contentNode.asText().isBlank()) throw new IllegalStateException("LLM response did not contain configuration JSON.");
        String content = stripCodeFence(contentNode.asText());
        return mapper.readValue(content, GenerationRequest.class);
    }

    public Map<String, String> defaults() {
        return Map.of("baseUrl", defaultBaseUrl, "modelName", defaultModel);
    }

    private String stripCodeFence(String text) {
        String trimmed = text.trim();
        if (trimmed.startsWith("```")) {
            trimmed = trimmed.replaceFirst("^```(?:json)?\\s*", "");
            trimmed = trimmed.replaceFirst("\\s*```$", "");
        }
        return trimmed.trim();
    }
    private boolean isBlank(String value) { return value == null || value.isBlank(); }
}
