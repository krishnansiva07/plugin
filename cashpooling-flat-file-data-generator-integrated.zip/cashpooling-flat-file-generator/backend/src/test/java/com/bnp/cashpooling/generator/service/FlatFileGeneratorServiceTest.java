package com.bnp.cashpooling.generator.service;

import com.bnp.cashpooling.generator.model.*;
import org.junit.jupiter.api.Test;
import java.nio.charset.StandardCharsets;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

class FlatFileGeneratorServiceTest {
    private final FlatFileGeneratorService service = new FlatFileGeneratorService();
    @Test void generatesHeaderDetailsAndZeroPaddedFooterCount() {
        GenerationRequest request = new GenerationRequest();
        request.setFileName("sample"); request.setRecordCount(1000); request.setLineSeparator("LF");
        FieldConfig headerField = field("header",20,RuleType.EXPRESSION); headerField.setValue("DERIVATIVE${date:yyMMdd}");
        request.setHeader(section(20,headerField));
        FieldConfig detailField=field("record",8,RuleType.SEQUENCE); detailField.setAlignment(Alignment.RIGHT); detailField.setPadCharacter("0");
        request.setDetail(section(8,detailField));
        FieldConfig footerField=field("count",6,RuleType.RECORD_COUNT); footerField.setAlignment(Alignment.RIGHT); footerField.setPadCharacter("0");
        request.setFooter(section(6,footerField));
        String output=new String(service.generate(request), StandardCharsets.UTF_8);
        String[] lines=output.split("\\n");
        assertEquals(1002,lines.length); assertEquals(20,lines[0].length()); assertTrue(lines[0].startsWith("DERIVATIVE")); assertEquals("001000",lines[1001]);
    }

    @Test void generatesRandomDateInsideConfiguredRange() {
        GenerationRequest request = new GenerationRequest();
        request.setFileName("dates"); request.setRecordCount(5); request.setLineSeparator("LF");
        request.setHeader(disabled()); request.setFooter(disabled());
        FieldConfig date = field("value", 8, RuleType.RANDOM_DATE_TIME);
        date.setStartDate("2026-01-01T00:00"); date.setEndDate("2026-01-31T23:59");
        date.setInputDateFormat("yyyy-MM-dd'T'HH:mm"); date.setFormat("yyyyMMdd");
        request.setDetail(section(8, date));
        String output = new String(service.generate(request), StandardCharsets.UTF_8);
        for (String line : output.split("\n")) {
            assertTrue(line.compareTo("20260101") >= 0 && line.compareTo("20260131") <= 0);
        }
    }

    @Test void generatesDateDependentOnEarlierField() {
        GenerationRequest request = new GenerationRequest();
        request.setFileName("dependent-date"); request.setRecordCount(1); request.setLineSeparator("LF");
        request.setHeader(disabled()); request.setFooter(disabled());
        FieldConfig transaction = field("TransactionDate", 8, RuleType.STATIC); transaction.setValue("20260729");
        FieldConfig settlement = field("SettlementDate", 8, RuleType.DEPENDENT_DATE);
        settlement.setSourceField("TransactionDate"); settlement.setInputDateFormat("yyyyMMdd");
        settlement.setDateOffset(2L); settlement.setDateOffsetUnit("DAYS"); settlement.setFormat("yyyyMMdd");
        request.setDetail(section(16, transaction, settlement));
        assertEquals("2026072920260731", new String(service.generate(request), StandardCharsets.UTF_8));
    }

    @Test void rejectsTotalFieldWidthBeyondLineWidth(){
        GenerationRequest request=new GenerationRequest(); request.setHeader(disabled()); request.setFooter(disabled());
        request.setDetail(section(5,field("a",3,RuleType.STATIC),field("b",3,RuleType.STATIC)));
        assertFalse(service.validate(request).isEmpty());
    }
    private FieldConfig field(String n,int w,RuleType t){FieldConfig f=new FieldConfig();f.setName(n);f.setWidth(w);f.setRuleType(t);return f;}
    private SectionConfig section(int w,FieldConfig...f){SectionConfig s=new SectionConfig();s.setEnabled(true);s.setLineWidth(w);s.setFields(List.of(f));return s;}
    private SectionConfig disabled(){SectionConfig s=new SectionConfig();s.setEnabled(false);return s;}
}
