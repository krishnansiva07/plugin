#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../.."
TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT
javac --release 17 -d "$TMP" \
  $(find qa/eliya87-opencode/stubs -name '*.java') \
  src/main/java/com/llmart/llm/service/OpenCodeExecutionService.java \
  qa/eliya87-opencode/OpenCodeHttpSmoke.java
java -cp "$TMP" OpenCodeHttpSmoke
node --check src/main/resources/static/app.js
python3 qa/eliya87-opencode/source-contracts.py
