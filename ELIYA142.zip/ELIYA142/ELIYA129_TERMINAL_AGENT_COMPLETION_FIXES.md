# ELIYA129 — Terminal discoverability and conversational Agent completion

Based on the supplied `ELIYA128.zip`. This is a source patch; a production JAR has **not** been compiled or run on the user's Windows machine.

## 1. `eliya analyse` not found in randomly opened terminals

**Root cause in 128:** JAR startup generated `%LOCALAPPDATA%\Eliya\bin\eliya.cmd` and wrote the user registry PATH. A process cannot change the already-inherited PATH of Windows Explorer, VS Code or IntelliJ. New terminal windows launched by an existing IDE may still inherit the old PATH until sign-out/sign-in. Therefore successful registry update is *not* the same as a reliably discoverable command.

**129 change:** First attempts to install `eliya.cmd` in an existing, trusted, user-owned PATH directory, preferring `%LOCALAPPDATA%\Microsoft\WindowsApps` or `%LOCALAPPDATA%\Eliya\bin` **only if those locations already occur in the JAR process's inherited PATH**. The command then works in fresh terminals that inherit that existing PATH, including those opened by VS Code and IntelliJ. The installer will not overwrite unrelated launchers, native `.exe`/`.com`/`.bat` aliases, symlinks, or shared/system PATH directories. If WindowsApps is unwritable, it falls back to Eliya's private bin plus the previous HKCU registration. It never invokes PowerShell, alters script policy, requests elevation, or changes the system PATH. JAR startup proceeds even if setup is blocked.

`GET /api/cli/setup-state` now distinguishes "registered" from "ready in fresh terminals". The browser warns when the OS has not adopted the new PATH, rather than silently showing success.

> Windows limitation: If corporate policy blocks *both* the trusted existing PATH locations and per-user registration, a bare command cannot be installed by a JAR. If the fallback registry path was newly registered, Windows/IDE process environment refresh may still require a new login. That is an OS restriction, not an AI failure.

On macOS/Linux, v128's safe `~/.local/bin` launcher and login/interactive shell profile setup remain in place.

## 2. Agent says completed but does not answer the user

**Root cause in 128:** Successful tool verification can skip the model's final assistant generation and leave `All approved plan steps completed successfully...` as the final chat text. A generic generated file list is appended only for tracked mutations. `Do you want to add anything?` is not a task-relevant next event. SSE completion alone also does not prove the outcome, so the durable run status remains authoritative.

**129 change:** Before persisting the final assistant answer and returning the SSE `done` payload, build a grounded conversational completion from:

- the user's actual task objective;
- completed plan items (never pending items);
- tracked workspace files, using real `created` / `updated` / `deleted` metadata;
- verification only when the *latest* workspace revision recorded a successful check;
- any substantive architecture explanation already produced (it is preserved, not overwritten).

The final answer identifies what was actually changed and what was/wasn't verified. For implementation tasks it offers **one contextual next action**, followed by `Would you like me to do that?`. The action is chosen conservatively from observed changed files and verifier status. The response does **not** claim an unobserved build, test, file, or deployment. Blocked/failed states are not converted to successes.

### Example response (illustrative; actual filenames/results come from workspace evidence)

> I made 2 tracked workspace file changes for your request: Add checkout coverage.
>
> **Completed work**
> - Added Selenium checkout tests
> - Updated page-object locators
>
> **Files created or changed**
> - Created `src/test/java/CheckoutTest.java`
> - Updated `src/main/java/CheckoutPage.java`
>
> **Verification:** The latest workspace revision passed the recorded check — `mvn test: 25 passed`.
>
> **Suggested next step:** run the broader regression suite to check for unintended failures
>
> Would you like me to do that?

### Follow-up semantics

- **"Yes", "OK", "Sure", "Go ahead"** executes the *exact proposed action* in the *same conversation and mapped workspace*, not a stale implementation plan.
- **"Yes, and exclude smoke tests"** passes the explicit additional constraint to the next Agent turn.
- **"No"** performs no further work.
- A new explicit instruction (e.g. "also include Cucumber scenarios") goes through the regular Agent workflow with retained chat history.
- A completed Agent response in the browser includes a **Continue suggested next step** button for a one-click explicit affirmative. Plain text replies also work, including from the terminal.
- A generic "yes" without an actual recorded suggestion does **not** start arbitrary work.
- If a formal pending plan/clarification exists, that flow keeps priority over an unrelated historical suggestion.

## Changed files

- `src/main/java/com/llmart/llm/cli/EliyaCliAutoSetup.java`
- `src/main/java/com/llmart/llm/cli/EliyaCliBridge.java`
- `src/main/java/com/llmart/llm/service/AgentCompletionNarrator.java` (new)
- `src/main/java/com/llmart/llm/service/AgentService.java`
- `src/main/resources/static/app.js`
- `qa/eliya128/AutoCliSetupSmoke.java`
- `qa/eliya129/AgentNarratorSmoke.java` (new)
- `qa/eliya129/run-completion-smoke.sh` (new)

## Validation (source-only and offline)

- Windows launcher Java smoke: **36 assertions** and executable-JAR path check passed.
- Conversation-completion Java smoke: **20 assertions** passed.
- CLI bridge Java smoke and renderer smoke passed.
- JavaScript regression suite: **112/112** passed.
- JavaScript `node --check` passed.
- **Not verified:** full Spring Boot Maven compilation/package, real Windows PATH propagation, fresh VS Code/IntelliJ terminal on Windows, real LLM provider runs or interactive Agent UI in a browser. Maven/online dependencies are not available in this runner.

## End-to-end validation on user's Windows system

1. Build with installed Maven and Java 17+: `mvn clean package` or `build-jar-windows.cmd`.
2. Run `java -jar target\eliya.jar`; confirm browser opens and CLI setup message reports an existing PATH location.
3. Open **new** CMD, PowerShell, VS Code terminal and IntelliJ terminal; from each run `where eliya` (CMD) or `Get-Command eliya` (PowerShell) followed by `eliya analyse` in a project folder.
4. Run `eliya agent "Create a small verified file"`; ensure the browser conversation contains the final answer, file list, verifier honesty and suggested next step.
5. Reply `yes` in that same Agent conversation. It should perform the suggested next action only, return a new verification-grounded answer and not rerun or rewrite the previous task wholesale.
6. Reload the browser and confirm that the final answer remains persisted and readable.
7. Check `http://127.0.0.1:8090/api/cli/setup-state` for the setup diagnostic if registration was blocked.

No change to native Eliya vs OpenCode engine selection or existing MCP access policy is included.
