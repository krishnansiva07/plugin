#!/usr/bin/env python3
"""Compare measured Eliya/OpenCode run exports, not theoretical or estimated tokens.

Usage: python qa/eliya142-compare-runs.py --eliya eliya-run.json --opencode opencode-run.json
Both files should contain a run status object with a tokenUsage or usage object.
Export from the corresponding run-detail API (or a saved copy of it).
"""
import argparse
import json
from pathlib import Path


def load(path):
    data = json.loads(Path(path).read_text(encoding='utf-8'))
    if not isinstance(data, dict):
        raise ValueError(f'{path}: expected a JSON run object')
    usage = data.get('tokenUsage') or data.get('usage') or data.get('progress', {}).get('tokenUsage') or {}
    if not isinstance(usage, dict):
        usage = {}
    return data, usage


def number(data, *keys):
    for key in keys:
        if key in data and data[key] is not None:
            try:
                return max(0, int(data[key]))
            except (TypeError, ValueError):
                pass
    return 0


def metrics(data, usage):
    input_tokens = number(usage, 'providerInputTokens', 'inputTokens')
    output_tokens = number(usage, 'providerOutputTokens', 'outputTokens')
    cache_read = number(usage, 'cachedInputTokens', 'cacheReadTokens')
    cache_write = number(usage, 'cacheWriteTokens')
    total = number(usage, 'providerTotalTokens', 'totalTokens')
    reported = usage.get('providerReported') is True or number(usage, 'reportedCalls') > 0
    missing = number(usage, 'unreportedCalls')
    if not total and reported:
        total = input_tokens + output_tokens + (cache_read + cache_write if usage.get('inputExcludesCache') else 0)
    required_rev = int(data.get('verificationRequiredRevision', -1))
    verified_rev = int(data.get('lastSuccessfulVerificationRevision', -1))
    has_verifier = number(data, 'verificationAttemptCount') > 0
    verified = bool(data.get('lastVerificationSuccessful')) and has_verifier and (
        data.get('verifiedCurrentRevision') is True or (required_rev >= 0 and verified_rev >= required_rev))
    return dict(task=(data.get('objective') or data.get('prompt') or data.get('fullPrompt') or '').strip(),
                model=(usage.get('model') or data.get('activeModel') or data.get('model') or '').strip(),
                status=data.get('status', ''), verified=verified,
                elapsed_ms=number(usage, 'elapsedMs'), calls=number(usage, 'modelCalls'),
                input=input_tokens, output=output_tokens, cache_read=cache_read,
                cache_write=cache_write, total=total, reported=reported, missing=missing)


def compare(left, right):
    lines = ['ELIYA / OPENCODE VERIFIED-RUN ACCOUNTING',
             f"Eliya status={left['status']}, OpenCode status={right['status']}",
             f"Model: {left['model'] or '(unknown)'} / {right['model'] or '(unknown)'}",
             f"Reported total: {left['total'] if left['reported'] else 'N/A'} / {right['total'] if right['reported'] else 'N/A'}",
             f"Model calls: {left['calls']} / {right['calls']}",
             f"Elapsed ms: {left['elapsed_ms'] or 'N/A'} / {right['elapsed_ms'] or 'N/A'}"]
    problems = []
    if not left['task'] or left['task'] != right['task']:
        problems.append('Different/missing original task text')
    if not left['model'] or left['model'] != right['model']:
        problems.append('Different/missing model')
    if not left['reported'] or not right['reported'] or left['missing'] or right['missing']:
        problems.append('Missing/partial provider-reported token usage')
    if left['status'] != 'completed' or right['status'] != 'completed':
        problems.append('Both runs must complete')
    if problems:
        lines += ['NOT COMPARABLE: ' + '; '.join(problems)]
        return '\n'.join(lines), False
    delta = (right['total'] - left['total']) / right['total'] * 100 if right['total'] else 0
    lines += [f'ELIYA token difference vs OpenCode: {delta:+.1f}% (negative = Eliya uses more).',
              'Provider-token total is not a monetary cost comparison. Confirm equal settings, cache state,',
              'tool/MCP permissions, workspace snapshot, output quality, and real verifier results.']
    if not left['verified'] or not right['verified']:
        lines += ['CAUTION: At least one run lacks explicit successful current-revision verifier evidence;',
                  'do NOT claim Eliya is better until outcome equivalence is verified.']
        return '\n'.join(lines), False
    return '\n'.join(lines), delta > 0


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--eliya', required=True, help='Eliya run-detail JSON')
    ap.add_argument('--opencode', required=True, help='OpenCode run-detail JSON')
    args = ap.parse_args()
    report, advantage = compare(metrics(*load(args.eliya)), metrics(*load(args.opencode)))
    print(report)
    if advantage:
        print('Eliya used fewer reported tokens on this one verified comparison; repeat across tasks before generalizing.')


if __name__ == '__main__':
    main()
