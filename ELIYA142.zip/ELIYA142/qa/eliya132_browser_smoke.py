from playwright.sync_api import sync_playwright
from pathlib import Path
HTML='<!doctype html>\n<html><head><title>Ready</title></head><body><main>Complete file</main></body></html>'
with sync_playwright() as p:
    b=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
    page=b.new_page(viewport={'width':1440,'height':900},accept_downloads=True)
    exceptions=[]
    page.on('pageerror',lambda e: exceptions.append(str(e)))
    root=Path(__file__).resolve().parents[1]/'src/main/resources/static'
    import re
    markup=(root/'index.html').read_text()
    markup=re.sub(r'<link rel="stylesheet" href="/([^?"]+)[^"]*"\s*/>',
         lambda m:'<style>'+ (root/m.group(1)).read_text() +'</style>',markup)
    markup=re.sub(r'<script src="/([^?"]+)[^"]*"></script>',
         lambda m:'<script>'+(root/m.group(1)).read_text().replace('</script','<\\/script')+'</script>', markup)
    page.set_content(markup,wait_until='domcontentloaded',timeout=15000)
    page.wait_for_timeout(800)
    print('initial page errors',exceptions[:5]);exceptions.clear()
    page.evaluate('''() => {
      state.conversationId='browser-smoke';
      state.project={id:'demo', name:'Demo Workspace',localWorkspace:true};
      state.messages=[
        {role:'user',content:'Give me two detailed prompts',id:10},
        {role:'assistant',content:'## Prompt 1 — Setup\\nCreate the framework completely.\\n\\n## Prompt 2 — Validation\\nRun existing tests only.',id:11,mode:'chat',streaming:false},
        {role:'user',content:'Create a downloadable html file',id:12},
        {role:'assistant',content:'```html\\n<!doctype html>\\n<html><head><title>Ready</title></head><body><main>Complete file</main></body></html>\\n```',id:13,mode:'chat',streaming:false}
      ];
      renderMessages();
    }''')
    assert page.locator('.eliya-prompt-card').count()==2
    assert page.locator('.eliya-artifact-panel [data-file-download]').count()==1
    page.screenshot(path='/mnt/data/eliya_work/eliya132-browser-desktop.png',full_page=True)
    with page.expect_download() as d:
        page.locator('.eliya-artifact-panel [data-file-download]').click()
    print('HTML download:',d.value.suggested_filename)
    assert d.value.suggested_filename=='generated-page.html'
    page.locator('[data-file-preview]').click()
    assert page.locator('.artifact-preview-frame').count()==1
    page.locator('#runMarkdownEdit').click()
    assert page.locator('#eliyaArtifactEditor').count()==1
    page.locator('#eliyaArtifactEditor').fill(HTML.replace('Ready','Edited'))
    page.locator('#runMarkdownSaveEdit').click()
    assert page.locator('iframe.artifact-preview-frame').count()==1
    with page.expect_download() as d:
        page.locator('#runMarkdownDownload').click()
    print('Edited download:',d.value.suggested_filename)
    assert d.value.suggested_filename=='generated-page.html'
    path='/mnt/data/eliya_work/eliya132-edited-browser.html'
    d.value.save_as(path)
    assert '<title>Edited</title>' in Path(path).read_text()
    page.locator('#runMarkdownClose').click()
    page.locator('[data-prompt-implement][data-prompt-number="1"]').click()
    detail=page.evaluate('''() => ({scope:state.pendingHandoff?.scopeText,
        message:document.querySelector('#messageInput').value,
        mode:state.workflowMode})''')
    assert 'Run existing tests only' in detail['scope']
    assert 'Create the framework' not in detail['scope']
    assert detail['mode']=='execute'
    assert 'Run existing tests only' in detail['message']
    print('Scoped handoff:',detail['mode'], detail['scope'].splitlines()[0]);
    print('Late page errors:',exceptions[:5]);exceptions.clear()
    page.locator('#handoffDismissBtn').click()
    assert page.evaluate('state.pendingHandoff===null')
    page.set_viewport_size({'width':390,'height':844})
    page.wait_for_timeout(600)  # allow responsive sidebar transition to finish
    page.screenshot(path='/mnt/data/eliya_work/eliya132-browser-mobile.png',full_page=True)
    print('ELIYA132 Chromium UI smoke: PASS')
    b.close()

