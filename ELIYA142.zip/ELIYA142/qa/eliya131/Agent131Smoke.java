package com.llmart.llm.service;
import java.util.List;
public class Agent131Smoke {
  private static int passed;
  private static void check(boolean yes, String message) {
    if (!yes) throw new AssertionError(message);
    passed++;
  }
  public static void main(String[] args) {
    check(AgentCompletionContract.requiresLocalEvidence("Create Java Selenium test classes"),"must validate new test classes");
    check(AgentCompletionContract.requiresLocalEvidence("Fix the framework code"),"fix should produce local evidence");
    check(AgentCompletionContract.requiresLocalEvidence("Generate Markdown report"),"report should exist");
    check(!AgentCompletionContract.requiresLocalEvidence("Analyse the existing Java Selenium framework"),"analysis is read-only");
    check(!AgentCompletionContract.requiresLocalEvidence("Explain WebDriver startup flow"),"explanation is read-only");
    check(!AgentCompletionContract.requiresLocalEvidence("Create a Jira MCP issue"),"external MCP not a local file");
    String outcome=AgentCompletionNarrator.complete("", "Create test classes", List.of(), 0, "", false, "blocked");
    check(outcome.contains("not verified complete"),"blocked execution must not look successful");
    String explanation="Execution timed out while running the Java 17 tests";
    check(AgentCompletionNarrator.complete(explanation,"Fix tests",List.of(),0,"",false,"failed").equals(explanation),
            "preserve concrete failure details without masking them");
    System.out.println("ELIYA131 completion contract: "+passed+" checks passed");
  }
}
