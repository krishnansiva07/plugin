#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../.."
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
javac --release 17 -encoding UTF-8 -d "$TMP" \
 src/main/java/com/llmart/llm/dto/ProjectPatchRequest.java \
 src/main/java/com/llmart/llm/service/{Hashing,AgentPlanRelevance,AgentResultPresentation,AgentAnalysisOutcome,AgentCompletionNarrator,AgentCompletionContract}.java \
 qa/eliya131/Agent131Smoke.java
java -cp "$TMP" com.llmart.llm.service.Agent131Smoke
bash qa/eliya126/run-java-cli-smoke.sh
bash qa/eliya127/run-rich-renderer-smoke.sh
bash qa/eliya128/run-auto-setup-smoke.sh
bash qa/eliya129/run-completion-smoke.sh
bash qa/eliya130/run.sh
node --check src/main/resources/static/app.js
python -m py_compile qa/eliya131/terminal_benchmark.py
