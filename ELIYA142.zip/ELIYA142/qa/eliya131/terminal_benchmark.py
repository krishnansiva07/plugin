#!/usr/bin/env python3
"""Live CLI timing benchmark. Does not generate files or silently change a workspace.
Usage: python qa/eliya131/terminal_benchmark.py --workspace D:\\Automation\\Project --runs 3
Requires a built Eliya JAR, running server, CLI registration, and configured model.
"""
import argparse
import json
import os
import pathlib
import shutil
import statistics
import subprocess
import sys
import time

PROMPT = ("Analyse the mapped project's test framework architecture. "
          "Identify the TestNG or Cucumber entry point, the driver lifecycle, "
          "and two specific risks. Cite actual repository file paths. "
          "Do not modify any files.")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--workspace", required=True)
    parser.add_argument("--runs", type=int, default=3)
    parser.add_argument("--timeout", type=int, default=300)
    parser.add_argument("--output", default="terminal-benchmark-results.json")
    args = parser.parse_args()
    workspace = pathlib.Path(args.workspace).resolve()
    if not workspace.is_dir():
        parser.error("--workspace must be an existing directory")
    if not 1 <= args.runs <= 20:
        parser.error("--runs must be between 1 and 20")
    if not shutil.which("eliya"):
        parser.error("eliya CLI not on PATH; start the JAR and reopen the terminal")
    measurements = []
    for i in range(args.runs):
        start = time.monotonic()
        try:
            result = subprocess.run(["eliya", "analyse", PROMPT], cwd=workspace,
                                    capture_output=True, text=True, timeout=args.timeout,
                                    encoding="utf-8", errors="replace")
            elapsed = round(time.monotonic() - start, 3)
            combined = result.stdout + "\n" + result.stderr
            # Output contents may contain private repository data; never write them to the benchmark JSON.
            record = {"iteration": i + 1, "elapsed_seconds": elapsed,
                      "exit_code": result.returncode,
                      "response_chars": len(result.stdout),
                      "has_error": result.returncode != 0,
                      "has_substantive_answer": len(result.stdout.strip()) > 200,
                      "requires_manual_accuracy_review": True}
        except subprocess.TimeoutExpired:
            elapsed = round(time.monotonic() - start, 3)
            record = {"iteration": i + 1, "elapsed_seconds": elapsed,
                      "exit_code": None, "timed_out": True,
                      "requires_manual_accuracy_review": True}
        print("Run", i + 1, record, flush=True)
        measurements.append(record)
    valid = [x["elapsed_seconds"] for x in measurements if x.get("exit_code") == 0]
    report = {"method": "cold-CLI-process, running-server, independent sessions",
              "mode": "analyse", "workspace": str(workspace),
              "runs": measurements,
              "mean_success_seconds": round(statistics.mean(valid), 3) if valid else None,
              "median_success_seconds": round(statistics.median(valid), 3) if valid else None,
              "quality_verified": False,
              "note": "Inspect analysis against source manually. No performance improvement is implied without matched baseline/model/hardware."}
    path = pathlib.Path(args.output).resolve()
    path.write_text(json.dumps(report, indent=2), encoding="utf-8")
    print("Saved benchmark metrics:", path)
    return 0 if len(valid) == args.runs else 1

if __name__ == "__main__":
    sys.exit(main())
