# ELIYA131 touched modules

- `cli/EliyaCliBridge.java`: localhost, session-specific activation/mode/run, secure status, per-run approval and question endpoints, cancellation, run outcome, SSE transport and CLI edit overlap guard.
- `cli/EliyaCliLauncher.java`: per-process session ID, interactive questions/approvals, cancellation and stop UX, verified done status and execution metrics.
- `service/ChatService.java`: forward Agent clarification events to active CLI SSE observer.
- `service/AgentApprovalService.java`: bind CLI approval resolution to owning Agent run.
- `service/AgentRunService.java`: latest-revision verification and outstanding verification failures gate final status.
- `service/AgentService.java`: reject successful status when requested local deliverable lacks tracked changes.
- `service/AgentCompletionNarrator.java`: ensure incomplete/generic outcomes are not presented as success; preserve substantive failure explanation.
- `service/AgentCompletionContract.java`: narrow local-deliverable detection for source evidence gate.
- `qa/eliya126/run-java-cli-smoke.sh`: updated compiler stubs and session isolation/localhost/auth coverage.
- `qa/token-usage-smoke/run.sh`: three additional strict verification cases.
- `qa/eliya131/`: focused tests and benchmark harness.
