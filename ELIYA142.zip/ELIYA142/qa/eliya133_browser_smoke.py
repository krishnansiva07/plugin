"""Real Chromium regression of ELIYA133 response flow; no fake backend-success assertions."""
from playwright.sync_api import sync_playwright
from pathlib import Path
import re
import os, shutil, sys
root=Path(__file__).resolve().parents[1]/'src/main/resources/static'
out=Path(__file__).resolve().parents[1]/'qa'/'screenshots-133'
out.mkdir(parents=True,exist_ok=True)
markup=(root/'index.html').read_text()
markup=re.sub(r'<link rel="stylesheet" href="/([^?"]+)[^"]*"\s*/>',lambda m:'<style>'+(root/m.group(1)).read_text()+'</style>',markup)
markup=re.sub(r'<script src="/([^?"]+)[^"]*"></script>',lambda m:'<script>'+(root/m.group(1)).read_text().replace('</script','<\\/script')+'</script>',markup)
a='''## Prompt 1 — Framework setup
Objective: Create a complete Playwright TypeScript Cucumber framework in the selected workspace. Inspect the legacy project first. Implement feature files, step definitions, browser configuration, Page Objects, test execution scripts and documented dependencies. Keep the reference project read only. Verify every generated file exists and compile the framework. Acceptance criteria: run a smoke scenario successfully and list the exact files modified, test commands and evidence. No browser downloads.
'''
prompt_b='''## Prompt 2 — Regression migration
Objective: Migrate legacy Selenium Cucumber scenarios to the already generated Playwright TypeScript framework. Compare the feature files and step definitions in the legacy reference. Add missing scenarios and ensure data/config parity. Use installed Chrome or Edge only; do not download browsers. Keep the existing implementation intact. Verify all migrated scenarios by running TypeScript checks and Cucumber tests. Acceptance criteria: show source-to-target scenario mapping and actual test results; incomplete tests must be reported, not claimed as passing.
'''
html='<!doctype html>\n<html><head><title>Artifact</title></head><body><main>Valid complete file</main></body></html>'
with sync_playwright() as p:
 candidates=[os.environ.get('ELIYA_BROWSER_BIN'),shutil.which('chromium'),shutil.which('chromium-browser'),shutil.which('google-chrome'),shutil.which('microsoft-edge')]
 if sys.platform=='win32':
  for name in ('PROGRAMFILES','PROGRAMFILES(X86)','LOCALAPPDATA'):
   base=os.environ.get(name)
   if base:
    candidates += [str(Path(base)/'Google/Chrome/Application/chrome.exe'),str(Path(base)/'Microsoft/Edge/Application/msedge.exe')]
 elif sys.platform=='darwin':
  candidates += ['/Applications/Google Chrome.app/Contents/MacOS/Google Chrome','/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge']
 installed=next((path for path in candidates if path and Path(path).is_file()),None)
 if not installed: raise RuntimeError('Installed Chrome/Edge/Chromium required. Set ELIYA_BROWSER_BIN to browser executable; no browser will be downloaded.')
 b=p.chromium.launch(executable_path=installed,headless=True,args=['--no-sandbox'])
 page=b.new_page(viewport={'width':1440,'height':900},accept_downloads=True)
 errors=[]
 page.on('pageerror',lambda e:errors.append(str(e)))
 page.set_content(markup,wait_until='domcontentloaded',timeout=25000)
 page.wait_for_timeout(400)
 page.evaluate('''args => {
    state.conversationId='eliya133-browser';state.project={id:'demo',name:'Demo Workspace',localWorkspace:true};
    state.messages=[
      {role:'user',content:'Can you check migration completed successfully?',id:30},
      {role:'assistant',content:'Let me inspect the actual workspace files to verify the migration state.',id:31,mode:'chat',streaming:false},
      {role:'user',content:'Give me two detailed implementation prompts',id:32},
      {role:'assistant',content:args.a+'\\n'+args.b,id:33,mode:'chat',streaming:false},
      {role:'user',content:'Generate downloadable html file',id:34},
      {role:'assistant',content:'```html\\n'+args.html+'\\n```',id:35,mode:'chat',streaming:false}
    ];renderMessages();
  }''',{'a':a,'b':prompt_b,'html':html})
 assert page.locator('.eliya-verification-result.not-established').count()==1
 assert page.locator('[data-complete-verification]').count()==1
 assert page.locator('[data-handoff-msg]').count()==0
 assert page.locator('.eliya-prompt-card').count()==2
 assert page.locator('[data-prompt-implement]').count()==2
 assert page.locator('.eliya-artifact-panel [data-file-download]').count()==1
 page.evaluate("document.getElementById('toast')?.classList.add('hidden')")
 page.screenshot(path=str(out/'eliya133-desktop.png'),full_page=True)
 page.locator('.eliya-prompt-card').first.scroll_into_view_if_needed()
 page.screenshot(path=str(out/'eliya133-prompt-cards.png'),full_page=False)
 with page.expect_download() as d: page.locator('.eliya-artifact-panel [data-file-download]').click()
 assert d.value.suggested_filename=='generated-page.html'
 page.locator('[data-file-preview]').click()
 assert page.locator('#runMarkdownBackdrop:not(.hidden)').count()==1
 assert page.locator('.artifact-preview-frame').count()==1
 page.screenshot(path=str(out/'eliya133-artifact-drawer.png'),full_page=False)
 page.locator('#runMarkdownClose').click()
 page.locator('[data-prompt-implement][data-prompt-number="1"]').click()
 selected=page.evaluate('''() => ({scope:state.pendingHandoff?.scopeText,prompt:document.getElementById('messageInput').value,mode:state.workflowMode})''')
 assert selected['mode']=='execute'
 assert 'Regression migration' in selected['scope']
 assert 'Framework setup' not in selected['scope']
 assert 'No browser downloads' not in selected['prompt']
 page.locator('#handoffDismissBtn').click()
 page.evaluate('''() => { state.messages=[
    {role:'user',content:'Generate a complete implementation prompt',id:50},
    {role:'assistant',content:'Let me prepare that prompt for you.',id:51,mode:'chat',streaming:false},
    {role:'user',content:'Generate two prompts',id:52},
    {role:'assistant',content:'## Prompt 1\\nJust do it.\\n\\n## Prompt 2\\nSame as above.',id:53,mode:'chat',streaming:false}
  ];renderMessages();}''')
 assert page.locator('[data-recover-prompt]').count()==1
 assert page.locator('[data-prompt-implement]').count()==0
 assert page.locator('[data-prompt-complete]').count()==2
 assert page.locator('[data-prompt-download]').count()==0
 page.set_viewport_size({'width':390,'height':844});page.wait_for_timeout(450)
 page.screenshot(path=str(out/'eliya133-mobile.png'),full_page=True)
 page.evaluate('''() => {state.messages=[{role:'user',content:'Implement fixes',id:80},
  {role:'assistant',content:'The final verification was blocked.',id:81,mode:'agent',streaming:false,
   agentBackendStatus:'blocked',agentProgress:{status:'blocked',percent:80,phase:'verification',detail:'Test failed',
   plan:[{index:1,text:'Apply change',status:'completed'},{index:2,text:'Verify',status:'blocked'}]}}];renderMessages();}''')
 assert page.locator('.eliya-agent-outcome.attention').count()==1
 assert 'Blocked' in page.locator('.eliya-agent-outcome').inner_text()
 page.evaluate('''() => {state.messages[1].content='All checks passed with recorded evidence.';
   state.messages[1].agentBackendStatus='completed';state.messages[1].agentProgress.status='completed';
   state.messages[1].agentProgress.percent=100;
   state.messages[1].agentProgress.plan[1].status='completed';renderMessages();}''')
 assert page.locator('.eliya-agent-outcome.completed').count()==1
 assert not errors,f'Chromium runtime errors: {errors[:8]}'
 b.close()
print('ELIYA133 Chromium UI: PASS. Screenshots:',out)
