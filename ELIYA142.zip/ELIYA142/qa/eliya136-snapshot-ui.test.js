const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const source = fs.readFileSync(path.join(__dirname,'../src/main/resources/static/app.js'), 'utf8');
const match = source.match(/function agentStageHtml\(progress, waiting\) \{[\s\S]*?\n\}\n\nfunction activityAgeText\(/);
assert.ok(match, 'stage renderer must exist');
const stage = new Function(match[0].replace(/\nfunction activityAgeText\($/, '') + '\nreturn agentStageHtml;')();

test('failed protected snapshot never marks unexecuted stages as completed', () => {
  const html = stage({ status:'failed', phase:'failed', activePlanIndex:0,
    activityEvents:[{tool:'run_failure', output:'Protected rollback snapshot exceeded its 180s safety deadline'}]}, false);
  assert.match(html, /agent-stage failed[^>]*><i>!<\/i><b>Execute<\/b>/);
  assert.doesNotMatch(html, /class="agent-stage done"/);
  assert.doesNotMatch(html, /<i>✓<\/i>/);
});

test('normal completed run still shows successful stage progression', () => {
  const html = stage({status:'completed',phase:'completed'},false);
  assert.match(html, /class="agent-stage done"/);
});

test('failed plan does not incorrectly show execution verified', () => {
  const html = stage({status:'blocked',phase:'blocked',activePlanIndex:0,activityEvents:[]},false);
  assert.match(html,/agent-stage failed[^>]*><i>!<\/i><b>Plan<\/b>/);
  assert.doesNotMatch(html, /class="agent-stage done"/);
});
