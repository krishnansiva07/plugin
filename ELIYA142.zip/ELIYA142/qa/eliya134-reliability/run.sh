#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../.."
build="$(mktemp -d)"
trap 'rm -rf "$build"' EXIT
javac -d "$build" \
  src/main/java/com/llmart/llm/service/AgentPlanRelevance.java \
  src/main/java/com/llmart/llm/service/AgentConversationIntent.java \
  src/main/java/com/llmart/llm/service/MigrationResumePreflight.java \
  src/main/java/com/llmart/llm/service/AgentPendingPlanStore.java \
  src/main/java/com/llmart/llm/service/AgentMigrationExecutionEvidence.java \
  qa/eliya134-reliability/ReliabilitySmoke.java
java -cp "$build" com.llmart.llm.service.ReliabilitySmoke
python3 qa/eliya134-reliability/source-contracts.py
javac -d "$build" qa/eliya134-reliability/SourceParserSmoke.java
java -cp "$build" SourceParserSmoke
