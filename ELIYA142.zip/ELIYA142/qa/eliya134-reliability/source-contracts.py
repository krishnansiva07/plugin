from pathlib import Path
s=Path('src/main/java/com/llmart/llm/service/AgentService.java').read_text()
frontend=Path('src/main/resources/static/app.js').read_text()
checks={
 'preflight before planner/index': s.index('MigrationResumePreflight.inspect(ws.root(), migrationRequest)') < s.index('McpManager.Catalog mcpCatalog = mcp.catalogForAgentIfRelevant(ws.root()'),
 'missing ledger fails closed': 'run.finish("blocked");' in s and 'Migration resume BLOCKED before any workspace edits.' in s,
 'stale plan guarded': 'continuation.migrationFingerprint().equals(migrationResume.fingerprint())' in s,
 'plan persisted': 'rememberPlan(run.conversationId(), new PendingConversationalPlan(' in s,
 'approval replay consumed': 'pendingPlanStore.consume(active.conversationId(), request.projectId())' in s,
 'planning context includes ledger': 'resume.report()).append(' in s,
 'migration final gate checks focused tests': 'migrationTestEvidence.hasPassedFocusedTest()' in s,
 'approve button': 'data-approve-conversation-plan=' in frontend,
 'approve action sends confirmation': "sendMessage({overrideMessage:'OK'})" in frontend,
}
for name,result in checks.items():
 print(f'{"PASS" if result else "FAIL"} {name}')
assert all(checks.values())
