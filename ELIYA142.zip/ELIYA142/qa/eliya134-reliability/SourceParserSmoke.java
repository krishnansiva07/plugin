import javax.tools.*;
import com.sun.source.util.JavacTask;
import java.io.File;
import java.nio.file.*;
import java.util.*;

/** Parses every Java source without resolving offline Spring/Jackson dependencies. */
public final class SourceParserSmoke {
  public static void main(String[] args) throws Exception {
    JavaCompiler compiler=ToolProvider.getSystemJavaCompiler();
    if (compiler==null) throw new IllegalStateException("JDK javac is required");
    List<File> sourceFiles;
    try (var stream=Files.walk(Path.of("src/main/java"))) {
      sourceFiles=stream.filter(p -> p.toString().endsWith(".java")).map(Path::toFile).toList();
    }
    DiagnosticCollector<JavaFileObject> diagnostics=new DiagnosticCollector<>();
    try (StandardJavaFileManager manager=compiler.getStandardFileManager(diagnostics,null,null)) {
      var compilationUnits=manager.getJavaFileObjectsFromFiles(sourceFiles);
      JavacTask task=(JavacTask)compiler.getTask(null,manager,diagnostics,List.of("--release","17","-proc:none"),null,compilationUnits);
      task.parse();
      List<Diagnostic<? extends JavaFileObject>> errors=diagnostics.getDiagnostics().stream()
          .filter(d -> d.getKind()==Diagnostic.Kind.ERROR).toList();
      for (var error:errors) System.err.println(error.getSource()+":"+error.getLineNumber()+" "+error.getMessage(Locale.ROOT));
      if (!errors.isEmpty()) throw new AssertionError(errors.size()+" Java parse errors");
    }
    System.out.println("ELIYA134 Java 17 source parse: PASS ("+sourceFiles.size()+" files)");
  }
}
