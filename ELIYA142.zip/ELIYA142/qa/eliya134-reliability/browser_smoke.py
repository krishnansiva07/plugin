"""Real installed-Chromium checks for ELIYA134 explicit plan approval control; backend not mocked as successful."""
from playwright.sync_api import sync_playwright
from pathlib import Path
import os,re,shutil

project=Path(__file__).resolve().parents[2]
root=project/'src/main/resources/static'
markup=(root/'index.html').read_text()
markup=re.sub(r'<link rel="stylesheet" href="/([^?"]+)[^"]*"\s*/>',lambda m:'<style>'+(root/m.group(1)).read_text()+'</style>',markup)
markup=re.sub(r'<script src="/([^?"]+)[^"]*"></script>',lambda m:'<script>'+(root/m.group(1)).read_text().replace('</script','<\\/script')+'</script>',markup)
installed=next((p for p in [os.environ.get('ELIYA_BROWSER_BIN'),shutil.which('chromium'),shutil.which('google-chrome'),shutil.which('microsoft-edge')] if p and Path(p).is_file()),None)
if not installed: raise RuntimeError('Set ELIYA_BROWSER_BIN to installed Chromium/Chrome/Edge; no browser downloaded')
out=project/'qa/screenshots-134';out.mkdir(exist_ok=True)
with sync_playwright() as pw:
 browser=pw.chromium.launch(executable_path=installed,headless=True,args=['--no-sandbox'])
 page=browser.new_page(viewport={'width':1440,'height':900})
 errors=[]
 page.on('pageerror',lambda error:errors.append(str(error)))
 page.set_content(markup,wait_until='domcontentloaded',timeout=30000)
 page.wait_for_timeout(450)
 preview='''## Proposed execution plan

1. Inspect migration ledger and map `testscripts.banner` methods.
2. Compare missing Playwright tests.
3. Implement one approved batch and test it.

**Awaiting explicit approval. No code or migration ledger was changed.** Review the scope above; reply **OK** or **Please continue** to execute ONLY this plan.'''
 page.evaluate('''content => {
   state.conversationId='eliya134-browser';
   state.project={id:'project-demo',name:'Disposable QA Project',localWorkspace:true};
   state.messages=[{role:'user',content:'Prepare plan, stop for explicit approval',id:40},
      {role:'assistant',content,id:41,mode:'agent',streaming:false,agentBackendStatus:'completed'}];
   renderMessages();
 }''',preview)
 button=page.locator('[data-approve-conversation-plan]')
 assert button.count()==1,'Expected explicit approval below saved Agent plan'
 assert 'Approve' in button.inner_text()
 page.screenshot(path=str(out/'eliya134-review-plan.png'),full_page=True)
 page.evaluate('''() => {window.__planCommand=null;window.sendMessage=async o=>{window.__planCommand=o}}''')
 button.click()
 assert page.evaluate('window.__planCommand?.overrideMessage')=='OK','Approval must send an explicit same-conversation OK message'
 page.evaluate('''() => {state.messages.push({role:'user',content:'What about the target workspace?',id:42});renderMessages()}''')
 assert page.locator('[data-approve-conversation-plan]').count()==0,'Old approval is not actionable after newer turn'
 page.evaluate('''() => {state.messages=[{role:'user',content:'Stop for approval',id:43},
     {role:'assistant',content:'## Proposed execution plan\\n\\nNeeds more information.\\n\\n**One clarification before execution:** Which source?',id:44,mode:'agent',streaming:false,agentBackendStatus:'completed'}];renderMessages()}''')
 assert page.locator('[data-approve-conversation-plan]').count()==0,'Clarification must not show executable approval'
 page.set_viewport_size({'width':390,'height':780})
 page.evaluate('''content => {state.messages=[{role:'user',content:'Prepare plan for approval',id:45},
   {role:'assistant',content,id:46,mode:'agent',streaming:false,agentBackendStatus:'completed'}];renderMessages()}''',preview)
 assert page.locator('[data-approve-conversation-plan]').count()==1,'Mobile plan approval must remain available'
 page.screenshot(path=str(out/'eliya134-plan-mobile.png'),full_page=True)
 assert not errors,errors
 browser.close()
print('ELIYA134 Chromium plan approval smoke: PASS (desktop, mobile, one-turn scope, consent)')
