package com.llmart.llm.service;

import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.time.Instant;
import java.util.*;

public final class ReliabilitySmoke {
    private static int count;
    private static void yes(boolean check, String reason) { if (!check) throw new AssertionError(reason); count++; }
    private static final String PROMPT = """
        SOURCE_PACKAGE: testscripts.banner
        RUN_MODE: RESUME_INCOMPLETE
        Use existing migration files and ledger only.
        PREPARE AND PRESENT THE COMPLETE PACKAGE PLAN.
        STOP and await explicit approval before ANY implementation or workbook edits.
        IMPLEMENT ONE APPROVED BATCH ONLY.
        Verify with Playwright test runner and update ledger only on test PASS.
        """;
    private static Path fixture(Path parent) throws Exception {
        Path root = Files.createDirectories(parent.resolve("playwright"));
        Path migration = Files.createDirectories(root.resolve("migration"));
        Files.writeString(migration.resolve("MIGRATION.md"), "# Migration rules\n", StandardCharsets.UTF_8);
        Files.writeString(migration.resolve("PACKAGE_RUNBOOK.md"), "# Runbook\n", StandardCharsets.UTF_8);
        Files.writeString(migration.resolve("shared-component-registry.md"), "# Shared\n", StandardCharsets.UTF_8);
        Files.writeString(migration.resolve("migration-ledger.csv"),
                "source_package,source_method,migration_status,target_path\r\n" +
                "testscripts.banner,Banner001,PASSED,apps/regression/test1.spec.ts\r\n" +
                "testscripts.banner,Banner002,MIGRATED,apps/regression/test2.spec.ts\r\n" +
                "testscripts.banner,Banner003,NOT_STARTED,\r\n" +
                "testscripts.banner,Banner004,FAILED,\r\n" +
                "testscripts.banner,Banner005,BLOCKED,\r\n" +
                "testscripts.bannerExtra,Other001,NOT_STARTED,\r\n", StandardCharsets.UTF_8);
        return root;
    }
    public static void main(String[] args) throws Exception {
        yes(AgentConversationIntent.classify(PROMPT) == AgentConversationIntent.Kind.PLAN_PREVIEW,
                "explicit stop/approval takes precedence over implementation clause");
        yes(AgentConversationIntent.classify(PROMPT + "\nNo further approval after this checkpoint.") == AgentConversationIntent.Kind.PLAN_PREVIEW,
                "later no-further-approval instruction cannot cancel explicit first approval gate");
        yes(AgentConversationIntent.classify("Do not stop and await approval. Implement now") == AgentConversationIntent.Kind.DIRECT,
                "explicit negation of stopping does not create an approval gate");
        yes(AgentConversationIntent.classify("Implement the migration now without approval") == AgentConversationIntent.Kind.DIRECT,
                "direct request stays direct");
        yes(AgentConversationIntent.classify("OK") == AgentConversationIntent.Kind.CONTINUE_PLAN, "OK means continuation");
        yes(AgentConversationIntent.classify("Please create an execution plan") == AgentConversationIntent.Kind.PLAN_PREVIEW,
                "ordinary planning remains read-only");
        Path scratch = Files.createTempDirectory("eliya134-reliability-");
        Path root = fixture(scratch);
        MigrationResumePreflight.Result before = MigrationResumePreflight.inspect(root, PROMPT);
        yes(before.applicable() && before.ready(), "existing ledger read successfully");
        yes(before.sourcePackage().equals("testscripts.banner"), "package spelling exact");
        yes(before.verified() == 1 && before.needsVerification() == 1 && before.pending() == 2 && before.blocked() == 1,
                "pass/unverified/incomplete/blocked statuses distinct");
        yes(before.nextBatch().size() == 3, "bounded list exactly three eligible methods");
        yes(before.nextBatch().get(0).startsWith("Banner002"), "migrated methods verified before rewriting");
        yes(before.nextBatch().stream().noneMatch(id -> id.contains("Banner001") || id.contains("Other001") || id.contains("Banner005")),
                "completed/held/other-package tests not reimplemented");
        yes(before.report().contains("SHA-256") && !before.fingerprint().isBlank(), "provenance fingerprint is recorded");
        yes(MigrationResumePreflight.inspect(scratch, PROMPT).report().contains("Select "), "mis-mapped parent project identified");
        yes(!MigrationResumePreflight.inspect(root, "Check migration progress").applicable(), "ordinary requests unaffected");
        String noPkg="RUN_MODE: RESUME_INCOMPLETE\nSTOP for approval";
        yes(!MigrationResumePreflight.inspect(root, noPkg).ready(), "resume without package fails closed");
        // A ledger update invalidates a previously approved snapshot.
        Path ledger=root.resolve("migration/migration-ledger.csv");
        String original=Files.readString(ledger);
        Files.writeString(ledger, original.replace("Banner003,NOT_STARTED", "Banner003,PASSED"));
        MigrationResumePreflight.Result changed = MigrationResumePreflight.inspect(root, PROMPT);
        yes(changed.ready() && !before.fingerprint().equals(changed.fingerprint()), "stale approval fingerprint rejected");
        yes(!MigrationResumePreflight.selectedBatchVerified(before, changed),
                "one new PASS elsewhere cannot pretend the approved batch is verified");
        Files.writeString(ledger, original.replace("Banner002,MIGRATED", "Banner002,PASSED")
                .replace("Banner003,NOT_STARTED", "Banner003,PASSED")
                .replace("Banner004,FAILED", "Banner004,PASSED"));
        yes(MigrationResumePreflight.selectedBatchVerified(before, MigrationResumePreflight.inspect(root, PROMPT)),
                "the exact approved batch is verified after all IDs change status");
        // Unsupported/ambiguous ledger records stop instead of guessing.
        Files.writeString(ledger, original.replace("Banner002,MIGRATED", "Banner002,MYSTERY"));
        yes(!MigrationResumePreflight.inspect(root, PROMPT).ready(), "unknown status blocks");
        Files.writeString(ledger, original.replace("Banner004,FAILED", "Banner003,FAILED"));
        yes(!MigrationResumePreflight.inspect(root, PROMPT).ready(), "duplicate method blocks");
        Files.writeString(ledger, "source_package,unknown,status\ntestscripts.banner,abc,PENDING\n");
        yes(!MigrationResumePreflight.inspect(root, PROMPT).ready(), "missing identity column blocks");
        Files.delete(ledger);
        yes(!MigrationResumePreflight.inspect(root, PROMPT).ready(), "missing ledger blocks and is never recreated");
        yes(!Files.exists(ledger), "preflight does not generate new files");
        Files.writeString(ledger, original);
        // Persisted explicit approval survives restart, is bound to the workspace and is one-time.
        Path pendingDir=scratch.resolve("pending");
        AgentPendingPlanStore store=new AgentPendingPlanStore(pendingDir);
        AgentPendingPlanStore.Pending item=new AgentPendingPlanStore.Pending(
                "workspace-123", PROMPT, List.of("Inspect existing ledger", "Implement only approved batch", "Run tests"),
                List.of("attachment-a"), "", Instant.now(), before.fingerprint());
        store.save("conversation-xyz", item);
        AgentPendingPlanStore afterRestart=new AgentPendingPlanStore(pendingDir);
        yes(afterRestart.load("conversation-xyz", "workspace-123").isPresent(), "approved plan recoverable across server restart");
        yes(afterRestart.load("conversation-xyz", "different-project").isEmpty(), "cross-workspace approval rejected");
        yes(afterRestart.consume("conversation-xyz", "workspace-123").isPresent(), "exact saved plan consumed once");
        yes(afterRestart.consume("conversation-xyz", "workspace-123").isEmpty(), "replay rejected");
        store.save("conversation-xyz", item);
        afterRestart.discard("conversation-xyz");
        yes(afterRestart.load("conversation-xyz", "workspace-123").isEmpty(), "new independent instruction clears stale plan");
        // Pure evidence gate: build/lint/list is NOT a migrated-test execution.
        AgentMigrationExecutionEvidence evidence=new AgentMigrationExecutionEvidence();
        evidence.observe(Map.of("tool","build", "status","success", "detail","tsc compiled"));
        evidence.observe(Map.of("tool","bash", "status","success", "args", "npx playwright test --list"));
        yes(!evidence.hasPassedFocusedTest(), "build and discovery do not establish passed tests");
        evidence.observe(Map.of("tool","test", "status","error", "detail","4 failures"));
        yes(!evidence.hasPassedFocusedTest(), "failed tests do not pass");
        evidence.observe(Map.of("tool","bash", "status","success", "args", "npx playwright test --project=chromium", "detail","exitCode=0"));
        yes(evidence.hasPassedFocusedTest(), "actual successful Playwright command recognized");
        yes(evidence.report().contains("failed observed test runs=1"), "failed test evidence retained");
        AgentMigrationExecutionEvidence commandFailure=new AgentMigrationExecutionEvidence();
        commandFailure.observe(Map.of("tool","bash", "status","success", "args","npx playwright test",
                "output", "exitCode=1; failed tests"));
        yes(!commandFailure.hasPassedFocusedTest(), "transport success cannot disguise exitCode=1 test failure");
        System.out.println("ELIYA134 reliability smoke: PASS (" + count + " assertions)");
    }
}
