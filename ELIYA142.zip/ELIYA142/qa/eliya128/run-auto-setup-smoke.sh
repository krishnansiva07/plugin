#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../.."
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
javac --release 17 -encoding UTF-8 -d "$TMP" \
  src/main/java/com/llmart/llm/cli/EliyaCliAutoSetup.java \
  qa/eliya128/AutoCliSetupSmoke.java
java -cp "$TMP" com.llmart.llm.cli.AutoCliSetupSmoke
jar --create --file "$TMP/setup-smoke.jar" --main-class com.llmart.llm.cli.AutoCliSetupSmoke -C "$TMP" com
java -jar "$TMP/setup-smoke.jar" --jar-classpath-check
