package com.llmart.llm.service;

import com.llmart.llm.dto.ProjectPatchRequest;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Properties;

public class Agent130Smoke {
    private static int checks;
    private static void check(boolean valid, String message) {
        checks++;
        if (!valid) throw new AssertionError(message);
    }
    public static void main(String[] args) throws Exception {
        String explanation = "## Findings\n\nDriverManager shares an instance across parallel runners. This can leak browser sessions during concurrent test execution. " +
                "Inspect the real driver factory and thread ownership before changing production code.\n\n" +
                "## Recommendations\n\n- Isolate WebDriver lifecycle for parallel test execution\n- Centralize explicit wait handling";
        check(AgentAnalysisOutcome.isAnalysis("Analyse the framework"), "analysis intent");
        check(!AgentAnalysisOutcome.isAnalysis("Create framework"), "mutation intent");
        String answer = AgentCompletionNarrator.complete(explanation, "Analyse the framework", List.of(), 0, "", false, "completed");
        check(answer.contains("DriverManager shares"), "analysis text retained");
        check(answer.contains("**Suggested next step:** prepare a scoped implementation plan for this recommendation: Isolate WebDriver lifecycle"), "evidence-based suggestion");
        check(!answer.contains("tracked workspace file change"), "no invented file changes");
        check(AgentCompletionNarrator.acceptedNextInstruction("yes", answer).contains("Isolate WebDriver lifecycle"), "yes continues analysis suggestion");
        String savedReportAnswer = AgentCompletionNarrator.complete(explanation,"Analyse framework and generate docs/report.md",
                List.of(new ProjectPatchRequest.ProjectPatchFile("docs/report.md", explanation, Hashing.ABSENT, "write")),
                1, "markdown read-back passed", true,"completed");
        check(savedReportAnswer.contains("prepare a scoped implementation plan for this recommendation"),
                "analysis report suggests next action from its actual findings");
        String unverifiedReportAnswer = AgentCompletionNarrator.complete(explanation,"Analyse framework and generate docs/report.md",
                List.of(new ProjectPatchRequest.ProjectPatchFile("docs/report.md", explanation, Hashing.ABSENT, "write")),
                1, "", false,"completed");
        check(unverifiedReportAnswer.contains("verify the generated analysis report"),
                "unverified analysis report must prioritize read-back over implementation");
        check(AgentCompletionNarrator.acceptedNextInstruction("yes, only for Chrome", answer).contains("User's additional constraint: for Chrome"), "yes with user constraint");
        check(AgentCompletionNarrator.acceptedNextInstruction("no", answer).isBlank(), "no must not act");
        check(AgentCompletionNarrator.acceptedNextInstruction("yes", "No suggested step").isBlank(), "no stale arbitrary continuation");
        String noRecommendations = "## Analysis\n\n" + "The observed feature binding mechanism is consistent across the inspected files. ".repeat(3);
        check(!AgentCompletionNarrator.complete(noRecommendations,"Explain this flow",List.of(),0,"",false,"completed")
                .contains("**Suggested next step:**"), "no invented recommendation");
        check(AgentAnalysisOutcome.recommendedAction("Analyse the project", "## Recommendations\n- Delete the repository and start again")
                .isBlank(), "destructive recommendation is not converted into action");
        Path project = Files.createTempDirectory("eliya130 reports with spaces ");
        try {
            Path report = project.resolve("docs/review.md");
            Files.createDirectories(report.getParent());
            Files.writeString(report, "# Framework Review\n\n" + explanation + "\n\n## Limits\n\nNo tests were executed.");
            var correct = new ProjectPatchRequest.ProjectPatchFile("docs/review.md", "", Hashing.ABSENT, "write");
            var other = new ProjectPatchRequest.ProjectPatchFile("docs/other.md", "", Hashing.ABSENT, "write");
            check(AgentAnalysisOutcome.verifiedMarkdownReport(project,"Analyse and save docs/review.md", List.of(correct)) != null,
                    "read-back from recorded report path");
            check(AgentAnalysisOutcome.verifiedMarkdownReport(project,"Analyse and save docs/other.md", List.of(correct)) == null,
                    "wrong named file never substituted");
            check(AgentAnalysisOutcome.verifiedMarkdownReport(project,"Analyse my framework", List.of(correct)) == null,
                    "no implicit on-disk report consumption");
            check(AgentAnalysisOutcome.verifiedMarkdownReport(project,"Analyse and save docs/review.md", List.of(other)) == null,
                    "no untracked file read");
            Path escaped = project.getParent().resolve("escaped.md");
            check(AgentAnalysisOutcome.verifiedMarkdownReport(project,"Analyse and save ../escaped.md",
                    List.of(new ProjectPatchRequest.ProjectPatchFile("../escaped.md","",Hashing.ABSENT,"write"))) == null,
                    "prevent path traversal");
        } finally {
            try(var stream = Files.walk(project)) {
                stream.sorted(java.util.Comparator.reverseOrder()).forEach(path -> {
                    try { Files.deleteIfExists(path); } catch (Exception ignored) { }
                });
            }
        }
        check(!AgentImpactRetrievalPolicy.needsImpactReport("What is in pom.xml?", "pom.xml"),
                "simple factual query avoids impact lookup");
        check(AgentImpactRetrievalPolicy.needsImpactReport("Explain the architecture", "repository"),
                "deep analysis keeps impact lookup");
        check(AgentImpactRetrievalPolicy.needsImpactReport("How does login work?", "login"),
                "flow inspection retains impact evidence");
        check(AgentImpactRetrievalPolicy.needsImpactReport("What files call DriverManager?", "DriverManager callers"),
                "caller investigation retains impact evidence");
        check(AgentImpactRetrievalPolicy.needsImpactReport("Fix the flaky test", "flaky test"),
                "mutating tasks retain full retrieval");
        check(AgentResultPresentation.isUnfulfilledAnalysis(AgentResultPresentation.analysisSynthesisFallback("", "")),
                "missing evidence must not be reported completed");
        check(!AgentResultPresentation.isUnfulfilledAnalysis(explanation),
                "complete findings are not treated as blocked");
        AgentStageMetrics metrics = new AgentStageMetrics();
        metrics.record("tools", 120); metrics.record("tools", 30);
        metrics.record("planning", 8); metrics.record("unknown", 100); metrics.record("tools", -30);
        check(metrics.snapshot().get("tools") == 150, "accumulated tool timing");
        check(metrics.snapshot().get("planning") == 8, "planning timing");
        Properties p = new Properties(); metrics.store(p);
        AgentStageMetrics reloaded = new AgentStageMetrics(); reloaded.restore(p);
        check(reloaded.snapshot().get("tools") == 150, "persist and restore timing");
        check(reloaded.snapshot().size() == 7, "bounded metric names");
        System.out.println("ELIYA130 analysis outcome and performance telemetry: " + checks + " checks passed");
    }
}
