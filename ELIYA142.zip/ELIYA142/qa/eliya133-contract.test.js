const {test}=require('node:test');
const assert=require('node:assert/strict');
const ux=require('../src/main/resources/static/response-experience');
const artifacts=require('../src/main/resources/static/response-artifacts');
const handoff=require('../src/main/resources/static/workflow-handoff');
const validOne='## Prompt 1 — Fix a regression\nObjective: Inspect the current workspace and compare the latest commit against expected behavior. Modify only the affected files; keep the legacy reference folder read-only. Preserve existing behavior. Verify with the installed test runner and an independent file read-back. Acceptance criteria: list actual changed files, executed commands, passed and failed checks and unresolved limitations. Never claim success for a test that was not run.';
test('migration verification with no workspace keyword is a verification intent',()=>{
 for(const q of ['Can you check migration completed successfully?', 'Check whether migration is complete','Verify test coverage','Was the framework migration successful?'])assert.equal(ux.intent(q),'verification',q);
 assert.equal(ux.intent('What is a prompt?'),'answer');
 assert.equal(ux.intent('Generate an implementation prompt based on the above analysis'),'prompt');
});
test('acknowledgement is not a verification result and never exposes handoff',()=>{
 const outcome=ux.result({question:'Can you check migration completed successfully?',answer:'Let me inspect the actual workspace files to verify the migration state.'});
 assert.equal(outcome.status,'unverified');assert.equal(outcome.showHandoff,false);
 const followup=ux.verificationFollowup('Can you check migration completed successfully?');
 assert.match(followup,/read.only/i);assert.match(followup,/Verdict/);assert.match(followup,/tests pass/i);
});
test('verdict is only presented when actual textual evidence accompanies it',()=>{
 const question='Verify migration completed';
 const text='**Verdict:** Inconclusive\n\n**Evidence:** Inspected `src/test/java/LegacyTest.java` and `pom.xml`, but the available snippets do not establish the full migration coverage. Tests were not run. **Unverified:** runtime regression execution, browser login and report export. Do not assume missing evidence means tests passed.';
 const outcome=ux.result({question,answer:text});
 assert.equal(outcome.status,'reported');assert.equal(outcome.verdict,'inconclusive');
 assert.equal(ux.result({question,answer:'**Verdict:** Verified. Everything is fine.'}).status,'unverified');
});
test('prompts are independent and incomplete drafts cannot be implemented',()=>{
 const sections=artifacts.promptSections('Give two detailed implementation prompts',`${validOne}\n\n## Prompt 2 — Migrate tests\n${'Compare Selenium and Playwright scenarios in the mapped reference and workspace. ' .repeat(4)} Verify build and test results; record exact file paths and acceptance criteria.`);
 assert.equal(sections.length,2);
 assert.equal(sections[0].ready,true);
 assert.equal(sections[1].ready,true);
 assert.doesNotMatch(sections[1].content,/Fix a regression/);
 const handoffText=artifacts.handoffMessage(12,sections[1].content,sections[1].title);
 assert.match(handoffText,/Migrate tests/);assert.doesNotMatch(handoffText,/Fix a regression/);
 assert.equal(handoff.validDraft({draft:{conversationId:'x',projectId:'p',messageId:12,scopeText:sections[1].content},conversationId:'x',projectId:'p',mode:'agent',message:handoffText}),true);
 assert.equal(handoff.validDraft({draft:{conversationId:'x',projectId:'p',messageId:12,scopeText:sections[1].content},conversationId:'x',projectId:'p',mode:'agent',message:handoffText.replace('Compare Selenium and Playwright','Replace Selenium and Playwright')}),false);
 const short=artifacts.promptSections('Generate two prompts','## Prompt 1\nDo it.\n\n## Prompt 2\nSame as above.');
 assert.equal(short.length,2);assert.equal(short.every(p=>!p.ready),true);
});
test('structured artifacts are all-or-nothing',()=>{
 const html='<!doctype html><html><head><title>Fine</title></head><body><main>OK</main></body></html>';
 assert.equal(artifacts.detect('download html file',`\`\`\`html\n${html}\n\`\`\``).ready,true);
 assert.equal(artifacts.detect('download HTML file','<html><body>fragment</body></html>').ready,false);
 assert.equal(artifacts.detect('download json','```json\n{"valid":true}\n```').ready,true);
 assert.equal(artifacts.detect('download json','```json\n{"invalid":}\n```').ready,false);
 assert.equal(artifacts.detect('download yaml','```yaml\na: 1\n```\n```yaml\nb: 2\n```').ready,false);
});
