#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../.."
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
javac --release 17 -encoding UTF-8 -d "$TMP" \
 src/main/java/com/llmart/llm/dto/ProjectPatchRequest.java \
 src/main/java/com/llmart/llm/service/Hashing.java \
 src/main/java/com/llmart/llm/service/AgentPlanRelevance.java \
 src/main/java/com/llmart/llm/service/AgentResultPresentation.java \
 src/main/java/com/llmart/llm/service/AgentAnalysisOutcome.java \
 src/main/java/com/llmart/llm/service/AgentCompletionNarrator.java \
 qa/eliya129/AgentNarratorSmoke.java
java -cp "$TMP" com.llmart.llm.service.AgentNarratorSmoke
