'use strict';
const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const artifacts=require('../src/main/resources/static/response-artifacts');
const experience=require('../src/main/resources/static/response-experience');
const handoff=require('../src/main/resources/static/workflow-handoff');
const root=path.join(__dirname,'../src/main/resources/static');
const app=fs.readFileSync(path.join(root,'app.js'),'utf8');
const css=fs.readFileSync(path.join(root,'app.css'),'utf8');
const promptRequest='Analyse existing Java selenium framework and migrate Java selenium to Playwright TypeScript. No target framework exists. Prompt 1 to create the framework, prompt 2 and prompt 3 for utilities, and 4 reusable prompt.';
const names=['New Cucumber Playwright framework','Core utilities','Advanced utilities','Reusable migration prompt'];
const body=n=>`Objective: implement only stage ${n} in the mapped target workspace. Legacy is the Java Selenium reference; first inspect real sources. `+
 'Use installed Chrome or Edge rather than download browsers. Verify each change through exact file paths, test results, checks, acceptance criteria, and limitations. '.repeat(5);
const sample=()=>names.map((name,i)=>`## Prompt ${i+1} — ${name}\n${body(i+1)}`).join('\n\n');
const sections=src=>artifacts.promptSections(promptRequest,src);

test('user migration request is understood as four distinct generate-only prompts',()=>{
 assert.equal(artifacts.isPromptRequest(promptRequest),true);
 assert.equal(experience.intent(promptRequest),'prompt');
 assert.equal(artifacts.expectedPromptCount(promptRequest),4);
 for(const q of ['Check the prompt','Review my existing prompt','Fix the prompt before running'])
   assert.equal(artifacts.isPromptRequest(q),false,q);
});
test('all four top-level sections are distinct and independently downloadable',()=>{
 const prompts=sections(sample());
 assert.equal(prompts.length,4);
 assert.deepEqual(prompts.map(p=>p.number),[1,2,3,4]);
 assert.ok(prompts.every(p=>p.ready),prompts.map(p=>p.reason).join('; '));
 assert.deepEqual(prompts.map(p=>artifacts.promptFileName(p,p.number-1)),[
   'prompt-1-new-cucumber-playwright-framework.md','prompt-2-core-utilities.md',
   'prompt-3-advanced-utilities.md','prompt-4-reusable-migration-prompt.md']);
 for(let i=0;i<prompts.length;i++){
   assert.match(prompts[i].content,new RegExp(`implement only stage ${i+1}`));
   for(let j=0;j<prompts.length;j++)if(i!==j)
     assert.doesNotMatch(prompts[i].content,new RegExp(`implement only stage ${j+1}`));
 }
});
test('full fenced Markdown response is still four prompts, never a combined implement task',()=>{
 for(const start of ['```markdown','````md','~~~text']){
   const marker=start.startsWith('~~~~')?'~~~~':start.startsWith('~~~')?'~~~':start.startsWith('````')?'````':'```';
   const prompts=sections(`${start}\n${sample()}\n${marker}`);
   assert.equal(prompts.length,4,start);
   assert.ok(prompts.every(p=>p.ready),start);
 }
});
test('one fenced Markdown document per prompt remains separate',()=>{
 const fenced=names.map((name,i)=>'```markdown\n## Prompt '+(i+1)+' — '+name+'\n'+body(i+1)+'\n```').join('\n\n');
 assert.deepEqual(sections(fenced).map(p=>p.number),[1,2,3,4]);
 assert.ok(sections(fenced).every(p=>p.ready));
});
test('combined or incomplete four-prompt answers cannot be handed off',()=>{
 const combined=sections('The following is a complete migration prompt. '+body(1).repeat(5));
 assert.equal(combined.length,1);
 assert.equal(combined[0].ready,false);
 assert.match(combined[0].reason,/Expected 4 separately labelled prompts/);
 const three=sections(sample().slice(0,sample().indexOf('## Prompt 4')));
 assert.equal(three.length,3);
 assert.ok(three.every(p=>!p.ready));
});
test('duplicate, nested prompt bundle and unclosed code block are blocked',()=>{
 const repeats=names.map((name,i)=>`## Prompt ${i+1} — ${name}\n${body(9)}`).join('\n\n');
 assert.ok(sections(repeats).every(p=>!p.ready));
 const nested=names.map((name,i)=>`## Prompt ${i+1} — ${name}\n${body(i+1)}\n\n\`\`\`markdown\n## Prompt 1 — copied\n${body(1)}\n## Prompt 2 — copied\n${body(2)}\n\`\`\``).join('\n\n');
 assert.ok(sections(nested).every(p=>!p.ready));
 const unfinished=sample().replace('## Prompt 4 — Reusable migration prompt','## Prompt 4 — Reusable migration prompt\n```typescript');
 assert.equal(sections(unfinished).at(-1).ready,false);
});
test('Agent receives exact selected prompt 4 and no framework creation prompt 1',()=>{
 const prompts=sections(sample());
 const scoped=artifacts.handoffMessage(53,prompts[3].content,prompts[3].title);
 assert.match(scoped,/Implement ONLY the selected prompt/);
 assert.match(scoped,/Reusable migration prompt/);
 assert.doesNotMatch(scoped,/New Cucumber Playwright framework/);
 assert.doesNotMatch(scoped,/implement only stage 1/);
 const args={draft:{conversationId:'abc',projectId:'project',messageId:53,scopeText:prompts[3].content},conversationId:'abc',projectId:'project',mode:'agent',message:scoped};
 assert.equal(handoff.validDraft(args),true);
 assert.equal(handoff.validDraft({...args,message:scoped.replace('only stage 4','only stage 1')}),false);
});
test('UI always shows individual dark viewers, selected downloads, and a regeneration path',()=>{
 assert.match(app,/data-prompt-implement="\$\{index\}" data-prompt-number="\$\{n\}"/);
 assert.match(app,/data-prompt-download="\$\{index\}" data-prompt-number="\$\{n\}"/);
 assert.match(app,/data-prompt-regenerate-set/);
 assert.match(app,/!requestIsPrompt[\s\S]{0,110}requestedFile/);
 assert.match(app,/promptFileName\(scope/);
 assert.match(css,/\.eliya-prompt-text\s*\{background:#0b1323!important/);
 assert.match(app,/const promptSuggestion = !requestIsPrompt/);
});
