#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../.."
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
mkdir -p "$TMP/src" "$TMP/classes"
make() { local f="$TMP/src/$1"; mkdir -p "$(dirname "$f")"; cat > "$f"; }
make org/springframework/stereotype/Component.java <<'JAVA'
package org.springframework.stereotype;
public @interface Component {}
JAVA
make org/springframework/web/bind/annotation/RestController.java <<'JAVA'
package org.springframework.web.bind.annotation;
public @interface RestController {}
JAVA
make org/springframework/web/bind/annotation/RequestMapping.java <<'JAVA'
package org.springframework.web.bind.annotation;
public @interface RequestMapping { String value() default ""; }
JAVA
make org/springframework/web/bind/annotation/GetMapping.java <<'JAVA'
package org.springframework.web.bind.annotation;
public @interface GetMapping { String value() default ""; }
JAVA
make org/springframework/web/bind/annotation/PostMapping.java <<'JAVA'
package org.springframework.web.bind.annotation;
public @interface PostMapping { String value() default ""; String path() default ""; String[] produces() default {}; }
JAVA
make org/springframework/web/bind/annotation/RequestParam.java <<'JAVA'
package org.springframework.web.bind.annotation;
public @interface RequestParam { String value() default ""; }
JAVA
make org/springframework/web/bind/annotation/RequestBody.java <<'JAVA'
package org.springframework.web.bind.annotation;
public @interface RequestBody {}
JAVA
make org/springframework/web/bind/annotation/RequestHeader.java <<'JAVA'
package org.springframework.web.bind.annotation;
public @interface RequestHeader { String value(); boolean required() default true; }
JAVA
make jakarta/annotation/PreDestroy.java <<'JAVA'
package jakarta.annotation;
public @interface PreDestroy {}
JAVA
make jakarta/servlet/http/HttpServletRequest.java <<'JAVA'
package jakarta.servlet.http;
public interface HttpServletRequest { String getRemoteAddr(); }
JAVA
make org/springframework/context/event/EventListener.java <<'JAVA'
package org.springframework.context.event;
public @interface EventListener { Class<?>[] value() default {}; }
JAVA
make org/springframework/boot/context/event/ApplicationReadyEvent.java <<'JAVA'
package org.springframework.boot.context.event;
public class ApplicationReadyEvent {}
JAVA
make org/springframework/boot/web/servlet/context/ServletWebServerApplicationContext.java <<'JAVA'
package org.springframework.boot.web.servlet.context;
public class ServletWebServerApplicationContext {
  public Server getWebServer() { return new Server(); }
  public static class Server { public int getPort() { return 8090; } }
}
JAVA
make org/springframework/http/HttpStatus.java <<'JAVA'
package org.springframework.http;
public enum HttpStatus { FORBIDDEN, CONFLICT, BAD_REQUEST }
JAVA
make org/springframework/web/server/ResponseStatusException.java <<'JAVA'
package org.springframework.web.server;
public class ResponseStatusException extends RuntimeException {
  public ResponseStatusException(org.springframework.http.HttpStatus status, String message) {super(status+": "+message);}
}
JAVA
make org/springframework/http/ResponseEntity.java <<'JAVA'
package org.springframework.http;
public class ResponseEntity<T> {
  private final int status; private final T value;
  public ResponseEntity(int status,T value){this.status=status;this.value=value;}
  public int getStatusCodeValue(){return status;}
  public T getBody(){return value;}
  public static <T> ResponseEntity<T> ok(T value){return new ResponseEntity<>(200,value);}
  public static BodyBuilder status(HttpStatus code){return new BodyBuilder(code==HttpStatus.CONFLICT?409:403);}
  public static BodyBuilder badRequest(){return new BodyBuilder(400);}
  public static class BodyBuilder {
    private final int status;
    BodyBuilder(int status){this.status=status;}
    public <T> ResponseEntity<T> body(T value){return new ResponseEntity<>(status,value);}
    public <T> ResponseEntity<T> build(){return new ResponseEntity<>(status,null);}
  }
}
JAVA
make com/fasterxml/jackson/databind/ObjectMapper.java <<'JAVA'
package com.fasterxml.jackson.databind;
public class ObjectMapper {
  public String writeValueAsString(Object object) { return "{}"; }
  public JsonNode readTree(String value) { return new JsonNode(); }
  public com.fasterxml.jackson.databind.node.JsonNodeFactory getNodeFactory() { return new com.fasterxml.jackson.databind.node.JsonNodeFactory(); }
}
JAVA
make com/fasterxml/jackson/databind/JsonNode.java <<'JAVA'
package com.fasterxml.jackson.databind;
public class JsonNode implements Iterable<JsonNode> {
  public java.util.Iterator<JsonNode> iterator(){return java.util.Collections.emptyIterator();}
  public boolean isArray(){return false;}
  public boolean isObject(){return false;}
  public boolean isMissingNode(){return false;}
  public long asLong(){return 0L;}
  public java.util.Iterator<java.util.Map.Entry<String,JsonNode>> fields(){return java.util.Collections.emptyIterator();}
  public JsonNode path(String name){return this;}
  public String asText(){return "";}
  public String asText(String other){return other;}
  public boolean asBoolean(){return false;}
  public boolean hasNonNull(String key){return false;}
}
JAVA
make com/fasterxml/jackson/databind/node/JsonNodeFactory.java <<'JAVA'
package com.fasterxml.jackson.databind.node;
public class JsonNodeFactory {
 public com.fasterxml.jackson.databind.JsonNode textNode(String val) {return new com.fasterxml.jackson.databind.JsonNode();}
}
JAVA
make org/springframework/http/MediaType.java <<'JAVA'
package org.springframework.http;
public class MediaType { public static final String TEXT_EVENT_STREAM_VALUE="text/event-stream"; }
JAVA
make org/springframework/web/servlet/mvc/method/annotation/SseEmitter.java <<'JAVA'
package org.springframework.web.servlet.mvc.method.annotation;
public class SseEmitter {
 public SseEmitter(){}
 public SseEmitter(Long ttl){}
 public void onCompletion(Runnable callback){}
 public void onTimeout(Runnable callback){}
 public void onError(java.util.function.Consumer<Throwable> callback){}
 public void complete(){}
 public void send(EventBuilder event){}
 public static EventBuilder event(){return new EventBuilder();}
 public static class EventBuilder { public EventBuilder name(String name){return this;} public EventBuilder data(Object data){return this;} }
}
JAVA
make com/llmart/llm/dto/ChatSettings.java <<'JAVA'
package com.llmart.llm.dto;
public record ChatSettings(String baseUrl, String model) {}
JAVA
make com/llmart/llm/dto/ChatRequest.java <<'JAVA'
package com.llmart.llm.dto;
import java.util.List;
public record ChatRequest(String conversationId, String message, List<String> attachmentIds, String projectId,
                          String mode, boolean regenerate, ChatSettings settings) {}
JAVA
make com/llmart/llm/dto/MessageDto.java <<'JAVA'
package com.llmart.llm.dto;
public record MessageDto(String role, String mode, String content) {}
JAVA
make com/llmart/llm/service/ChatService.java <<'JAVA'
package com.llmart.llm.service;
import com.llmart.llm.dto.ChatRequest;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;
public class ChatService {
  public ChatRequest last;
  public SseEmitter stream(String key, ChatRequest request){this.last=request;return new SseEmitter();}
  public void runTerminal(String key, ChatRequest request, java.util.function.BiConsumer<String,Object> observer){
    this.last=request; observer.accept("done", java.util.Map.of("content","Test response"));
  }
  public boolean cancelChat(String conversationId){return false;}
}
JAVA
make org/springframework/boot/SpringApplication.java <<'JAVA'
package org.springframework.boot;
public class SpringApplication { public static void run(Class<?> cls,String... args) {} }
JAVA
make com/llmart/llm/LlmApplication.java <<'JAVA'
package com.llmart.llm;
public class LlmApplication {}
JAVA
make com/llmart/llm/entity/ConversationEntity.java <<'JAVA'
package com.llmart.llm.entity;
public class ConversationEntity {
 private final String id=java.util.UUID.randomUUID().toString();
 public String getId(){return id;}
}
JAVA
make com/llmart/llm/service/ConversationService.java <<'JAVA'
package com.llmart.llm.service;
import java.util.*;
import com.llmart.llm.dto.ConversationDto;
import com.llmart.llm.entity.ConversationEntity;
public class ConversationService {
  public List<ConversationDto> list(){return List.of();}
  public ConversationEntity create(){return new ConversationEntity();}
  public List<com.llmart.llm.dto.MessageDto> listMessages(String id){return List.of(new com.llmart.llm.dto.MessageDto("assistant","chat","review"));}
}
JAVA
make com/llmart/llm/service/ProjectService.java <<'JAVA'
package com.llmart.llm.service;
import com.llmart.llm.dto.ProjectDto;
import java.nio.file.*;
public class ProjectService {
  public java.util.List<ProjectDto> mappedLocalWorkspaces(){return java.util.List.of();}
  public ProjectDto createLocal(String conversation,String raw,String name){
    Path p=Path.of(raw).toAbsolutePath().normalize();
    if(!Files.isDirectory(p)) throw new IllegalArgumentException("Project path is not a directory");
    return new ProjectDto(p.toString(),conversation,p.getFileName().toString(),0,0,0,p.toString(),true,null,null);
  }
}
JAVA
make com/llmart/llm/service/AgentRunService.java <<'JAVA'
package com.llmart.llm.service;
import java.util.*;
public class AgentRunService {
 public Optional<Map<String,Object>> latestForConversation(String conversationId){return Optional.empty();}
 public boolean cancel(String id){return false;}
 public AgentRun require(String id){return new AgentRun();}
 public static class AgentRun { public String conversationId(){return "test-conversation";} }
}
JAVA
make com/llmart/llm/service/AgentQuestionService.java <<'JAVA'
package com.llmart.llm.service;
import java.util.*;
public class AgentQuestionService {
 public Map<String,Object> pending(String id){return Map.of();}
 public boolean answer(String run,String q,String choice,String detail){return false;}
}
JAVA
make com/llmart/llm/service/AgentApprovalService.java <<'JAVA'
package com.llmart.llm.service;
public class AgentApprovalService {
 public enum Decision { ONCE, RUN, DENY }
 public boolean resolveForRun(String approval,String run,Decision decision){return true;}
}
JAVA
make com/llmart/llm/service/LocalProjectIndexService.java <<'JAVA'
package com.llmart.llm.service;
import com.llmart.llm.dto.ProjectDto;
public class LocalProjectIndexService { public void request(ProjectDto dto, boolean refresh) {} }
JAVA
cat > "$TMP/src/CliSmoke.java" <<'JAVA'
import com.llmart.llm.cli.*;
import com.llmart.llm.service.*;
import org.springframework.boot.web.servlet.context.ServletWebServerApplicationContext;
import java.nio.file.*;
import java.lang.reflect.*;
import java.util.*;
public class CliSmoke {
  private static void check(boolean value, String reason) { if(!value)throw new AssertionError(reason); }
  public static void main(String[] args) throws Exception {
    Path data=Files.createTempDirectory("eliya-cli-test-");
    Path project=Files.createDirectories(data.resolve("my java project"));
    System.setProperty("app.data-dir",data.toString());
    System.setProperty("eliya.browser.enabled","false");
    System.setProperty("eliya.startup.workspace",project.toString());
    ChatService chat = new ChatService();
    EliyaCliBridge bridge=new EliyaCliBridge(new ProjectService(),new ConversationService(),
        new LocalProjectIndexService(),new ServletWebServerApplicationContext(),chat,
        new AgentRunService(),new AgentQuestionService(),new AgentApprovalService());
    bridge.ready();
    check(bridge.setupState(()->"127.0.0.1").getStatusCodeValue()==200,"local setup-status unavailable");
    check(bridge.setupState(()->"8.8.8.8").getStatusCodeValue()==403,"setup-status exposed to remote clients");
    Path credentials=EliyaCliBridge.bridgeFile();
    check(Files.exists(credentials),"credential file was not created");
    List<String> lines=Files.readAllLines(credentials);
    check("8090".equals(lines.get(0)),"wrong port");
    check(lines.get(1).length()==64,"token not random 256-bit hex");
    check(project.toString().equals(bridge.selection(()->"127.0.0.1").getBody().project().localPath()),"startup selection");
    check(bridge.selection(()->"8.8.8.8").getStatusCodeValue()==403,"remote selection allowed");
    check(bridge.activate(new EliyaCliBridge.ActivationRequest(project.toString()),"invalid",()->"127.0.0.1").getStatusCodeValue()==403,"invalid credential allowed");
    Path second=Files.createDirectories(data.resolve("typescript"));
    String first=bridge.selection(()->"127.0.0.1").getBody().version();
    check(bridge.activate(new EliyaCliBridge.ActivationRequest(second.toString()),lines.get(1),()->"127.0.0.1").getStatusCodeValue()==200,"valid CLI activation failed");
    var after=bridge.selection(()->"127.0.0.1").getBody();
    check(second.toString().equals(after.project().localPath()),"workspace was not changed");
    check(!first.equals(after.version()),"UI revision was not updated");
    check(bridge.activate(new EliyaCliBridge.ActivationRequest(null),lines.get(1),()->"127.0.0.1").getStatusCodeValue()==200,"open command failed");
    check(after.version().equals(bridge.selection(()->"127.0.0.1").getBody().version()),"open command changed selection");
    check(bridge.activate(new EliyaCliBridge.ActivationRequest(data.resolve("missing").toString()),lines.get(1),()->"127.0.0.1").getStatusCodeValue()==400,"invalid path accepted");
    check(bridge.mode(new EliyaCliBridge.ModeRequest("agent",second.toString()),"bad",()->"127.0.0.1").getStatusCodeValue()==403,"mode was unauthenticated");
    check(bridge.mode(new EliyaCliBridge.ModeRequest("agent",second.toString()),lines.get(1),()->"127.0.0.1").getStatusCodeValue()==200,"mode switch rejected");
    check("agent".equals(bridge.selection(()->"127.0.0.1").getBody().mode()),"Agent mode not selected");
    try {
      bridge.run(new EliyaCliBridge.TerminalPrompt("agent","edit",second.toString()),lines.get(1),()->"127.0.0.1");
      throw new AssertionError("unconfigured AI credentials should reject request");
    } catch (org.springframework.web.server.ResponseStatusException expected) { /* no credentials */ }
    check(bridge.browserSettings(new EliyaCliBridge.BrowserSettings("test-key",new com.llmart.llm.dto.ChatSettings("http://example.com","model")),
            "wrong","http://example.com",()->"127.0.0.1").getStatusCodeValue()==403,"cross-site settings accepted");
    check(bridge.browserSettings(new EliyaCliBridge.BrowserSettings("test-key",new com.llmart.llm.dto.ChatSettings("http://example.com","model")),
            "settings-sync","http://127.0.0.1:8090",()->"127.0.0.1").getStatusCodeValue()==200,"browser settings not synced");
    check(bridge.browserSettings(new EliyaCliBridge.BrowserSettings("test-key",new com.llmart.llm.dto.ChatSettings("http://example.com","model")),
            "settings-sync","http://localhost:8090",()->"127.0.0.1").getStatusCodeValue()==200,
            "canonical localhost settings synchronization rejected");
    check(bridge.run(new EliyaCliBridge.TerminalPrompt("analyse","inspect",second.toString()),lines.get(1),()->"127.0.0.1") instanceof
            org.springframework.web.servlet.mvc.method.annotation.SseEmitter,"Analyse did not use ChatService");
    for(int i=0;i<50 && chat.last==null;i++)Thread.sleep(20);
    check("chat".equals(chat.last.mode()) && "inspect".equals(chat.last.message()),"Analyse routing wrong");
    String sharedConversation=chat.last.conversationId();
    check(bridge.run(new EliyaCliBridge.TerminalPrompt("implement","",second.toString()),lines.get(1),()->"127.0.0.1") instanceof
            org.springframework.web.servlet.mvc.method.annotation.SseEmitter,"implement handoff failed");
    for(int i=0;i<50 && !"agent".equals(chat.last.mode());i++)Thread.sleep(20);
    check("agent".equals(chat.last.mode()) && sharedConversation.equals(chat.last.conversationId()),"implement lost session");
    // ELIYA131: terminal sessions A and B must not change the browser's active project.
    String sidA=java.util.UUID.randomUUID().toString();
    String sidB=java.util.UUID.randomUUID().toString();
    String browserWorkspace=bridge.selection(()->"127.0.0.1").getBody().project().localPath();
    var a=bridge.activate(new EliyaCliBridge.ActivationRequest(project.toString(),sidA),lines.get(1),()->"127.0.0.1");
    var b=bridge.activate(new EliyaCliBridge.ActivationRequest(second.toString(),sidB),lines.get(1),()->"127.0.0.1");
    check(a.getStatusCodeValue()==200 && b.getStatusCodeValue()==200,"per-terminal activation failed");
    var selA=(EliyaCliBridge.Selection)((java.util.Map<?,?>)a.getBody()).get("selection");
    var selB=(EliyaCliBridge.Selection)((java.util.Map<?,?>)b.getBody()).get("selection");
    check(!selA.conversationId().equals(selB.conversationId()),"independent terminals shared conversation");
    check(!selA.project().localPath().equals(selB.project().localPath()),"independent terminals shared workspace");
    check(bridge.selection(()->"127.0.0.1").getBody().project().localPath().equals(browserWorkspace),
        "CLI terminal mutated global browser selection");
    bridge.mode(new EliyaCliBridge.ModeRequest("agent",project.toString(),sidA),lines.get(1),()->"127.0.0.1");
    var bStatus=bridge.status(lines.get(1),sidB,()->"127.0.0.1");
    var statusMap=(java.util.Map<?,?>)bStatus.getBody();
    check("analyse".equals(((EliyaCliBridge.Selection)statusMap.get("selection")).mode()),
        "Agent in terminal A changed terminal B's mode");
    check(bridge.terminalResult(sidA,lines.get(1),()->"127.0.0.1").getStatusCodeValue()==200,
        "terminal result endpoint unavailable");
    check(bridge.cancelSession(sidA,"wrong",()->"127.0.0.1").getStatusCodeValue()==403,
        "terminal cancel endpoint accepted bad credential");
    check(bridge.terminalQuestion(sidA,"unknown-run","wrong",()->"127.0.0.1").getStatusCodeValue()==403,
        "terminal question endpoint accepted bad credential");
    check(bridge.refresh(lines.get(1),()->"127.0.0.1").getStatusCodeValue()==200,"refresh failed");
    check(bridge.status(lines.get(1),null,()->"127.0.0.1").getStatusCodeValue()==200,"status failed");
    Path nested=Files.createDirectories(data.resolve("ide-project").resolve("src").resolve("test").resolve("java"));
    Files.writeString(data.resolve("ide-project").resolve("pom.xml"),"<project />");
    check(ProjectDirectoryLocator.fromWorkingDirectory(nested).equals(data.resolve("ide-project")),
            "nested IDE terminal did not resolve Maven project root");
    check(ProjectDirectoryLocator.detectedProject(nested).equals(data.resolve("ide-project")),
            "plain java -jar project auto-detection failed");
    Method parse=EliyaCliLauncher.class.getDeclaredMethod("parseWorkspace",String[].class);
    parse.setAccessible(true);
    String result=(String)parse.invoke(null,(Object)new String[]{"change","workspace",second.toString()});
    check(result.equals(second.toString()),"change workspace parsing failed");
    result=(String)parse.invoke(null,(Object)new String[]{"workspace",project.toString()});
    check(result.equals(project.toString()),"workspace parsing failed");
    check(parse.invoke(null,(Object)new String[]{"open"})==null,"open should not remap");
    bridge.shutdown();
    check(!Files.exists(credentials),"bridge secret was not removed on shutdown");
    System.out.println("ELIYA CLI Java smoke: startup, auth, workspace switching, syntax and teardown passed");
  }
}
JAVA
mapfile -t sources < <(find "$TMP/src" -name '*.java' | sort)
javac --release 17 -encoding UTF-8 -d "$TMP/classes" \
  "${sources[@]}" \
  src/main/java/com/llmart/llm/dto/ProjectDto.java \
  src/main/java/com/llmart/llm/dto/ConversationDto.java \
  src/main/java/com/llmart/llm/cli/ProjectDirectoryLocator.java \
  src/main/java/com/llmart/llm/cli/EliyaCliLauncher.java \
  src/main/java/com/llmart/llm/cli/EliyaTerminalRenderer.java \
  src/main/java/com/llmart/llm/cli/EliyaCliAutoSetup.java \
  src/main/java/com/llmart/llm/cli/EliyaCliBridge.java
java -cp "$TMP/classes" CliSmoke
