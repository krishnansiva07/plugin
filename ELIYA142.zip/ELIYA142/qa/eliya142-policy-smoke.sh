#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
OUT="$(mktemp -d)"
trap 'rm -rf "$OUT"' EXIT
javac -encoding UTF-8 -d "$OUT" \
 src/main/java/com/llmart/llm/service/AgentToolPalettePolicy.java \
 src/main/java/com/llmart/llm/service/AgentTurnEvidenceEconomy.java \
 src/main/java/com/llmart/llm/service/AgentFocusedCodePlanPolicy.java \
 qa/Eliya142PolicySmoke.java
java -cp "$OUT" com.llmart.llm.service.Eliya142PolicySmoke
node --test src/test/js/*.test.js
