'use strict';
const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const root=path.join(__dirname,'../src/main/resources/static');
const intelligence=require(path.join(root,'conversation-intelligence'));
const artifacts=require(path.join(root,'response-artifacts'));
const context={window:{}};
vm.runInNewContext(fs.readFileSync(path.join(root,'markdown.js'),'utf8'),context);
const render=context.window.MarkdownRenderer.render;
const app=fs.readFileSync(path.join(root,'app.js'),'utf8');
const server=fs.readFileSync(path.join(__dirname,'../src/main/java/com/llmart/llm/service/TerminalSessionService.java'),'utf8');

test('bare check uses last task and mapped workspace without requesting another prompt',()=>{
 const result=intelligence.contextualize('check',{lastUser:'Migrate the legacy login flow to Playwright',lastAssistant:'Migration has two gaps',workspaceMapped:true});
 assert.equal(result.action,'contextual-check');
 assert.match(result.text,/Migrate the legacy login flow to Playwright/);
 assert.match(result.text,/Inspect the currently mapped workspace/);
 assert.match(result.text,/read-only check/);
 assert.match(result.text,/Do not generate a prompt/);
});
test('check with a mapped workspace but no earlier task still acts read-only',()=>{
 const result=intelligence.contextualize('Please verify it',{workspaceMapped:true});
 assert.equal(result.action,'contextual-check');
 assert.match(result.text,/No previous user task/);
 assert.match(result.text,/mapped workspace/);
});
test('no available scope never fabricates a previous task; explicit edits unchanged',()=>{
 assert.equal(intelligence.contextualize('check',{}).text,'check');
 for(const q of ['fix it','generate a migration prompt','check tests and fix them'])
   assert.equal(intelligence.contextualize(q,{lastUser:'Verify smoke tests',workspaceMapped:true}).text,q);
});
test('checking an existing prompt does not display newly generated prompt controls',()=>{
 for(const q of ['Check the prompt','Review the prompt I used','Explain why my prompt failed','what is prompt factory?']) {
   assert.equal(artifacts.isPromptRequest(q),false,q);
   assert.deepEqual(artifacts.promptSections(q,'A complete answer'),[],q);
 }
 assert.equal(artifacts.isPromptRequest('Generate a detailed implementation prompt'),true);
});
test('72K handoff allows long selected prompts without silently shortening',()=>{
 const src='Analyse workspace, implement all explicit checks. Verify results and report test evidence.\n'.repeat(700);
 const result=artifacts.handoffMessage(12,src,'Regression tests');
 assert.equal(result.includes(src.trim()),true);
 assert.match(result,/BEGIN SELECTED PROMPT/);
 assert.throws(()=>artifacts.handoffMessage(12,'A'.repeat(72001),'Too long'),/72,000/);
});
test('dark code block keeps long source and only a single code text container',()=>{
 const marker='VERY_LAST_LINE_137';
 const content='```typescript\n'+('const count: number = 42;\n').repeat(1200)+marker+'\n```';
 const html=render(content);
 assert.match(html,/code-large/);
 assert.match(html,/complete source/);
 assert.ok(html.includes(marker),'last line preserved');
 assert.equal((html.match(/<pre>/g)||[]).length,1);
 assert.equal((html.match(/<span>\d+<\/span>/g)||[]).length,0,'no thousands of line number nodes');
 assert.ok(html.length>20000);
});
test('both Chat and Terminal short-check routes use contextualize',()=>{
 assert.match(app,/lastUser,lastAssistant,workspaceMapped:Boolean\(state\.project\?\.localWorkspace\)/);
 assert.match(app,/lastUser:previousTerminalUser,lastAssistant:previousTerminalAnswer/);
 assert.doesNotMatch(app,/slice\(-50000\)/);
 assert.match(server,/MAX_RESULT_CHARS/);
 assert.doesNotMatch(server,/content\.length\(\) > 35000/);
});

test('CLI supports one-shot eliya check without asking for a prompt',()=>{
 const cli=fs.readFileSync(path.join(__dirname,'../src/main/java/com/llmart/llm/cli/EliyaCliLauncher.java'),'utf8');
 assert.match(cli,/command\.equals\("check"\)/);
 assert.match(cli,/execute\(running, "analyse", "Check the latest task/);
 assert.match(cli,/eliya check\s+Verify the latest task/);
});
