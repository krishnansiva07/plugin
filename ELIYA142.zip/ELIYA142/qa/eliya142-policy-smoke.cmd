@echo off
setlocal EnableExtensions
cd /d "%~dp0\.."
set "OUT=%TEMP%\eliya142-policy-smoke-%RANDOM%"
mkdir "%OUT%" || exit /b 1
javac -encoding UTF-8 -d "%OUT%" ^
 src\main\java\com\llmart\llm\service\AgentToolPalettePolicy.java ^
 src\main\java\com\llmart\llm\service\AgentTurnEvidenceEconomy.java ^
 src\main\java\com\llmart\llm\service\AgentFocusedCodePlanPolicy.java ^
 qa\Eliya142PolicySmoke.java
if errorlevel 1 goto fail
java -cp "%OUT%" com.llmart.llm.service.Eliya142PolicySmoke
if errorlevel 1 goto fail
node --test src\test\js\*.test.js
if errorlevel 1 goto fail
rmdir /s /q "%OUT%"
echo ELIYA142 policy + JS smoke tests passed.
exit /b 0
:fail
echo ELIYA142 validation failed.
rmdir /s /q "%OUT%"
exit /b 1
