#!/usr/bin/env bash
# Source-level regression suite. This does not claim to replace Maven/Spring Boot E2E checks.
set -euo pipefail
cd "$(dirname "$0")/.."
for js in src/main/resources/static/{app.js,response-artifacts.js,response-experience.js,workflow-handoff.js}; do
  node --check "$js"
done
node --test src/test/js/*.test.js qa/eliya133-contract.test.js
node qa/response-artifacts-132.test.js
qa/eliya133-policy/run.sh
scratch="$(mktemp -d)"
trap 'rm -rf "$scratch"' EXIT
javac -d "$scratch" src/main/java/com/llmart/llm/service/ConversationHandoffSelection.java qa/eliya132-jvm/ScopeContractCheck.java
java -cp "$scratch" com.llmart.llm.service.ScopeContractCheck
python qa/eliya133_browser_smoke.py
printf '\nELIYA133 focused regression suite: PASS\n'
