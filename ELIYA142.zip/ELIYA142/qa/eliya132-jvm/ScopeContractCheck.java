package com.llmart.llm.service;
import java.util.List;
public class ScopeContractCheck {
  public static void main(String[] args) {
    String scoped="Implement ONLY the selected prompt from conversation message #77 in the currently selected workspace.\n--- BEGIN SELECTED PROMPT ---\nExecute test B only\n--- END SELECTED PROMPT ---";
    if (!ConversationHandoffSelection.isScopedPrompt(scoped)) throw new AssertionError("scoped detection failed");
    if (ConversationHandoffSelection.explicitSourceId(scoped).orElse(-1)!=77) throw new AssertionError("source reference failed");
    var hist=List.of(
      new ConversationHandoffSelection.Turn(75,"user","Generate implementation prompts",List.of(),"chat"),
      new ConversationHandoffSelection.Turn(77,"assistant","## Prompt 1\nTask A\n## Prompt 2\nTask B",List.of(),"chat"),
      new ConversationHandoffSelection.Turn(80,"user",scoped,List.of(),"agent"));
    var packet=ConversationHandoffSelection.select(hist,80,scoped);
    if (packet.isEmpty() || packet.get().answerId()!=77) throw new AssertionError("persisted-source selection failed");
    if (ConversationHandoffSelection.explicitSourceId("Implement the agreed analysis from conversation message #77").orElse(-1)!=77)
      throw new AssertionError("legacy handoff regression");
    System.out.println("ELIYA132 Java scoped handoff contract: PASS");
  }
}
