package com.llmart.llm.service;
public final class PolicySmoke {
  private static void yes(boolean pass,String name) {if (!pass) throw new AssertionError(name);}
  public static void main(String[] args) {
    yes(MappedWorkspaceEvidencePolicy.shouldRetrieve("Can you check migration completed successfully?"),"migration implicit workspace");
    yes(MappedWorkspaceEvidencePolicy.shouldRetrieve("Verify Playwright tests"),"tests implicit workspace");
    yes(!MappedWorkspaceEvidencePolicy.shouldRetrieve("What is a good prompt?"),"ordinary question no retrieval");
    yes(AgentResultPresentation.needsInvestigationAnswer("Check migration completed successfully", "Let me inspect files now.",true),"preamble invalid");
    yes(AgentResultPresentation.needsInvestigationAnswer("Check migration completed successfully", "Migration is complete!",true),"unsupported completion invalid");
    yes(!AgentResultPresentation.needsInvestigationAnswer("Check migration completed successfully", "**Verdict:** Inconclusive\n\n**Evidence:** The workspace index shows src/test/java/FrameworkTest.java, but we cannot establish missing scenario counts. Tests did not run. Limitations: browser integration has not been checked.",true),"grounded inconclusive accepted");
    System.out.println("ELIYA133 Java policy smoke: PASS");
  }
}
