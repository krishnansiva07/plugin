#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../.."
out="$(mktemp -d)"
trap 'rm -rf "$out"' EXIT
javac -d "$out" src/main/java/com/llmart/llm/service/MappedWorkspaceEvidencePolicy.java src/main/java/com/llmart/llm/service/AgentResultPresentation.java qa/eliya133-policy/PolicySmoke.java
java -cp "$out" com.llmart.llm.service.PolicySmoke
