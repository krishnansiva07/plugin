#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
node --check src/main/resources/static/app.js
node --check src/main/resources/static/response-artifacts.js
node --check src/main/resources/static/response-experience.js
node --test src/test/js/*.test.js qa/eliya133-contract.test.js
node qa/response-artifacts-132.test.js
qa/eliya133-policy/run.sh
qa/eliya134-reliability/run.sh
scratch="$(mktemp -d)"
trap 'rm -rf "$scratch"' EXIT
javac --release 17 -d "$scratch" src/main/java/com/llmart/llm/service/ConversationHandoffSelection.java qa/eliya132-jvm/ScopeContractCheck.java
java -cp "$scratch" com.llmart.llm.service.ScopeContractCheck
python3 qa/eliya133_browser_smoke.py
python3 qa/eliya134-reliability/browser_smoke.py
printf '\nELIYA134 source-level & Chromium QA: PASS (not a full Maven/live-agent build)\n'
