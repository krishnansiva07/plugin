#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
OUT="$(mktemp -d)"
trap 'rm -rf "$OUT"' EXIT
javac --release 17 -d "$OUT" \
  src/main/java/com/llmart/llm/service/McpPromptGate.java \
  src/main/java/com/llmart/llm/service/McpToolOutcomePolicy.java \
  src/main/java/com/llmart/llm/service/AgentMcpTestEvidence.java \
  qa/eliya135/McpTestReliabilitySmoke.java
java -cp "$OUT" com.llmart.llm.service.McpTestReliabilitySmoke
