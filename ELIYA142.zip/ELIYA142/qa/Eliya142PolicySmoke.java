package com.llmart.llm.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** JDK-only tests, including a measured before/after schema-count comparison. */
public class Eliya142PolicySmoke {
    private static final Set<String> DEFAULT = Set.of(
            "inspect_workspace","list","glob","grep","file_info","read","read_many","code_impact",
            "mcp_scaffold","rag_scaffold","learning_recall","resource_catalog","resource_read",
            "resource_grep","tool_search","knowledge_search","knowledge_read","conversation_handoff_read",
            "conversation_handoff_search","edit","write","apply_patch","build","test","check",
            "bash","workspace_status","workspace_diff","workspace_checkpoint","workspace_rollback",
            "todoread","todo_update","ask_user","work_items_discover","work_items_init",
            "work_items_add","work_items_read","work_items_update","verification_failures",
            "documentation_inventory","documentation_coverage","documentation_module",
            "documentation_record_module","documentation_exclude_module","documentation_knowledge",
            "documentation_template","documentation_validate","presentation_source_extract",
            "presentation_inspect","presentation_create","presentation_validate",
            "presentation_preview","confluence_compose","confluence_validate");

    private static void require(boolean value, String message) {
        if (!value) throw new AssertionError(message);
    }

    public static void main(String[] args) {
        var read = AgentToolPalettePolicy.select("Explain how LoginService.java authenticates", true, DEFAULT);
        var edit = AgentToolPalettePolicy.select("Fix login in LoginService.java", false, DEFAULT);
        var migration = AgentToolPalettePolicy.select("Migrate all Java Selenium tests", false, DEFAULT);
        var specialized = AgentToolPalettePolicy.select("Create Confluence documentation", false, DEFAULT);
        require(!read.contains("edit") && read.contains("read") && read.contains("tool_search"), "read only palette");
        require(edit.contains("edit") && edit.contains("test"), "code palette");
        require(!edit.contains("presentation_create"), "avoid unrelated schemas");
        require(migration.contains("work_items_read") && migration.contains("work_items_discover"), "large task ledger");
        require(specialized.equals(DEFAULT), "specialized full capability");
        require(AgentFocusedCodePlanPolicy.plan("Fix src/main/java/LoginService.java", false).size() == 2, "focused plan");
        require(AgentFocusedCodePlanPolicy.plan("Migrate all src/main/java/LoginService.java", false).isEmpty(), "no narrow migration");
        var history = new ArrayList<Map<String,Object>>();
        history.add(Map.of("role","system","content","[RUNTIME_STEERING:active-step-contract] 1"));
        history.add(Map.of("role","tool","name","read","content","a".repeat(200)));
        require(!AgentTurnEvidenceEconomy.shouldDeferRetrieval(history), "one observation insufficient");
        history.add(Map.of("role","tool","name","grep","content","b".repeat(200)));
        require(AgentTurnEvidenceEconomy.shouldDeferRetrieval(history), "two live observations");
        history.add(Map.of("role","system","content","[RUNTIME_STEERING:active-step-contract] 2"));
        require(!AgentTurnEvidenceEconomy.shouldDeferRetrieval(history), "new step must get a primer");
        System.out.printf("BASELINE tools=%d, read-only=%d (%.1f%% fewer schemas), " +
                "code-fix=%d (%.1f%% fewer schemas), migration=%d, specialized=%d%n",
                DEFAULT.size(), read.size(), 100.0 * (DEFAULT.size()-read.size())/DEFAULT.size(),
                edit.size(), 100.0 * (DEFAULT.size()-edit.size())/DEFAULT.size(),
                migration.size(), specialized.size());
        System.out.println("PASS: policy smoke checks; tool-schema COUNT is not measured token billing");
    }
}
