# ELIYA 132 — Unified UI and scoped prompt-to-Agent handoff

Date: 2026-11-10
Based on: User-supplied ELIYA131 source archive.

## Why

The prior UI could render prompt output across unrelated text and code cards, offered a generic **Implement in Agent** action that referenced a whole saved analysis, and downloaded an assistant response as Markdown even when the user requested a standalone HTML, JSON or YAML file. A user could mistake a fragment for a ready-to-download artifact. Too many secondary buttons competed with the primary action.

## Changed

1. **Complete prompt cards:** When the user asks for prompt(s), render each full prompt in a continuous, scrollable source view. For multiple `## Prompt 1`, `## Prompt 2`, etc., create separate cards. Common preamble constraints accompany each independently usable prompt. Each card has **Open full view**, **Copy prompt**, **Download .md**, and **Implement this prompt**.
2. **Selected-scope handoff:** Implement prepares a reviewable Agent draft containing only that prompt and a source message ID. It does **not** execute automatically. Switching or deleting the scope invalidates the handoff. Any previous unsent draft is restorable with Cancel handoff. Existing whole-analysis handoff remains available for non-prompt analysis.
3. **Backend authorization scope:** `ConversationHandoffSelection` recognizes the selected-prompt marker; `AgentService` does not convert the complete historical analysis into steps for scoped runs. `ConversationHandoffService` supplies a short pointer, not all other proposed prompt sections. Context construction rejects oversized selected instructions instead of silently truncating them.
4. **Requested files:** Detect explicit downloadable HTML/HTML-typo HYML, JSON, YAML, and Markdown requests. A structurally complete HTML or parseable JSON response produces **Preview** and **Download** controls with the matching extension/MIME. Incomplete output presents **Generate complete file** rather than a misleading file download. YAML export uses a single coherent source block, but is not a full YAML parser.
5. **Artifact preview:** Safe sandboxed HTML preview, raw source, edit-to-download controls (local only; saved messages/workspace are untouched), copy and direct file download. Saved Chat artifacts also gain direct Download.
6. **Clean visual presentation:** Neutral/indigo styling, condensed `More` secondary actions, a collapsible model selector, responsive prompt/artifact cards, source content without artificial empty code-space, and clearer selected-scope status.
7. **Generation guidance:** Chat system guidance requests standalone full prompts and complete file outputs instead of fragmented snippets; automatic output continuation remains in place.

## Validated here

- JavaScript syntax: `node --check` on modified scripts.
- Node regression suite: `node --test src/test/js/*.test.js` — **112 passed, 0 failed**.
- New pure artifact/parser tests: `node qa/response-artifacts-132.test.js` — PASS.
- Java core scoped-handoff smoke: compile `ConversationHandoffSelection.java` and `qa/eliya132-jvm/ScopeContractCheck.java` using `javac`, then execute — PASS.
- Chromium/Playwright UI integration: `python qa/eliya132_browser_smoke.py` — PASS. Verified two independent prompt cards, actual `generated-page.html` download, sandbox preview, in-preview edit, downloaded edited bytes, selected-only Prompt 2 handoff, and Cancel handoff. Tested desktop and mobile viewport.

## Build and known limits

- Full Maven/Spring Boot compile and integration tests **could not run in this sandbox**. Maven is not installed, and the runtime cannot resolve `repo.maven.apache.org`. The attached ZIP is **complete updated source**, not a prebuilt `eliya.jar`.
- On a machine with Maven/network or preseeded dependencies, run `./build-jar.sh` (Linux/macOS) or `build-jar-windows.cmd` (Windows), or `./mvnw clean package -DskipTests`.
- Real LLM provider output quality and full Java end-to-end Agent behavior were not exercised here. The UI refuses to label incomplete structured outputs as ready, but it cannot prove semantic completeness of arbitrary generated HTML or YAML.
- A local preview edit does not overwrite the original message or project. Download the edited version to keep it.

## Code touched

`src/main/resources/static/response-artifacts.js` (new), `app.js`, `app.css`, `index.html`, `workflow-handoff.js`; `src/main/java/com/llmart/llm/service/{ContextService,ConversationHandoffSelection,ConversationHandoffService,AgentService}.java`; Node/Java/Chromium smoke tests and updated old prompt-layout regression expectations.
