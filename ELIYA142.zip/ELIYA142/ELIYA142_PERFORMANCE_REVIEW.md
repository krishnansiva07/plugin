# ELIYA142 — Agent performance and usability review

**Source:** `ELIYA141(1).zip` (the user's uploaded source).  **Output:** ELIYA142 source patch.
**Validation level:** 130 passing Node/browser-contract tests; 1 JDK-only policy smoke test;
JDK compiled the three standalone policy classes. **Not** a validated Spring Boot JAR / live-model benchmark.

## Executive result

ELIYA141 has real foundations (deterministic compaction, prompt-cache routing, lazy MCP,
completion gates, durable run state and usage accounting). Its major efficiency problem is
**the cost of each repeated LLM request**, rather than a single large context. This patch
reduces the default function schema surface for common work, stops replaying a retrieval
primer after the current step has live source evidence, eliminates the planner round trip
for high-precision single-source edits, and avoids repeated context-size serialization.

**Do not claim "less tokens than OpenCode" yet.** Tool count is not billed tokens; the
same tasks, model, cache and completion quality must be measured with provider usage.

## Detailed findings and changes

| Finding in 141 | Why it matters | Change in 142 | Limitation |
|---|---|---|---|
| 54 built-in core function schemas were advertised in ordinary workspace Agent turns | Tool definitions are part of each model request, even when unrelated | `AgentToolPalettePolicy` advertises 20 schemas on read-only investigations, 31 on ordinary code fixes, and 36 on broad code migrations; unknown/specialized work keeps existing definitions; `tool_search` still exposes deferred tools | Fewer definitions does not mean the same percentage fewer tokens. The provider may count schemas differently. |
| Proactive retrieval hints can be resent alongside newly read source/tool results | Duplicated evidence inflates subsequent prompts | `AgentTurnEvidenceEconomy` removes the automatic retrieval bundle after two substantive source observations **in the current plan step** | No suppression without an active-step anchor; retries/compaction/new step can re-enable retrieval. Source tools remain available. |
| Context policy was estimating/serializing the same growing transcript repeatedly | Avoidable CPU work on long sessions | Reuses `ContextEstimate` for aggressive-prune, economy-checkpoint, and compact decisions | Actual CPU savings require profiling on the target machine. |
| Single-file fixes invoked a separate planning call and broad planning evidence gathering | Adds one LLM call before execution for an obvious inspect/edit/verify workflow | `AgentFocusedCodePlanPolicy` creates a short two-step plan only for a single named source file with an explicit change verb, no attachment or broad scope | Complex changes and unspecified target files stay on original planner. |
| Old runtime active-step instructions were accumulating | Repeated instructions waste context and can confuse execution | Prunes superseded active-step, step-advanced and exploration-budget steering; retains newest | Durable original requirements/locked plan preserved. |
| Runtime numbers were hard to interpret | Users can mistake estimates for billed savings | Added persisted `initialToolSchemas`, `baselineToolSchemas`, `proactiveRetrievalDeferred` to run usage, and surfaced them in execution timing | These are structural counters, not billable token measurements. |
| Eliya vs OpenCode UI could display a token % despite different tasks/models | Misleading comparison | No percentage when prompt, model or reported usage mismatch | Output equivalence still needs human or deterministic verification. |

### Static measurement from this source

Default tools: **54**. Read-only: **20** (63.0% fewer schema definitions).
Ordinary code edit: **31** (42.6% fewer definitions). Broad code migration: **36**.
Specialized Confluence/presentation/MCP requests: **54** (no capability narrowing).
The baseline harness uses the **exact 54 tool identifiers** declared in `CORE_AGENT_TOOLS`.

On the hot context-preparation path, `ContextWindowManager.estimate(...)` is no longer
re-run separately for three policy decisions. The remaining estimates reflect different
actual message states (before/after pruning); thresholds are unchanged.

### User-experience changes

The run's execution-timing panel now reports initial schema count and how many context
preparations have skipped proactive retrieval after current-step evidence. The comparison
panel refuses to generate an unfair percentage for mismatched prompts/models or missing
provider counters. Existing ELIYA141 long Markdown/HTML dark viewer and chat inactivity
warnings are preserved and are not claimed newly implemented by ELIYA142.

### Safety and compatibility

- Original user task, approved steps, real read results and verification evidence are **not** rewritten.
- MCP remains gated by explicit prompt authorization. `tool_search` exposes deferred
  schemas, never bypassing tool permissions or file/deletion safeguards.
- Large migrations preserve work-item ledger availability. Specialized document and
  presentation workflows retain the original tool set.
- Agent must still verify changed code/artifacts; no completion gate was relaxed.
- Unknown task categories fall back to original full schemas rather than guessing.
- New counters are backward-compatible with older run-history properties.
- No external models, browsers or Maven dependencies have been added.

## How to run in Windows

1. Extract `ELIYA142.zip` into a separate directory. Stop the running `ELIYA141` server.
2. From this new directory use `build-jar-windows.cmd` or `mvnw.cmd clean package` with
   the established Java 17+ / Maven setup. Start the JAR with the existing launch method
   and open `http://localhost:8090` (if configured for port 8090). Hard refresh once;
   `/app.js?v=142` identifies the new browser code.
3. Test a read-only source question, one named-file fix, an ordinary code task and a
   Java Selenium→Playwright TypeScript migration. Confirm on-disk output and verification;
   use Agent run timing/usage details to inspect the schema and retrieval counters.
4. For local policy tests, run `qa/eliya142-policy-smoke.sh` on Unix/WSL (requires JDK
   and Node), or compile `AgentToolPalettePolicy.java`, `AgentTurnEvidenceEconomy.java`,
   `AgentFocusedCodePlanPolicy.java` and `qa/Eliya142PolicySmoke.java` with `javac`.

### Rollback switches (Java system properties)

Each new optimization can be disabled independently **when starting the JAR**:

```text
-Deliya.tokens.adaptiveTools.enabled=false
-Deliya.tokens.evidenceHandoff.enabled=false
-Deliya.tokens.focusedCodePlan.enabled=false
```

The original ELIYA141 features retain their existing switches. Disabling a new switch
returns that path to its earlier behavior without changing stored workspace files.

## How to establish a fair OpenCode comparison

Run on **the same machine/provider/model, same prompt, same cloned workspace snapshot,
same browser/tests and same verified deliverable**. Clear or separately classify cold and
warm prompt/provider caches. Do at least **3 repeated runs per task** and report median
(and slow-tail) time as well as provider-reported input, output and cache counters:

1. Explain the architecture of an existing Java Selenium Cucumber framework (read-only).
2. Fix one specifically named source-file defect and run an appropriate test.
3. Make a medium cross-file change and verify the changed APIs or tests.
4. Create a Playwright TypeScript Cucumber framework from a legacy Selenium reference.
5. Query explicitly configured `Jira MCP`, compare requirements to workspace files and
   generate and verify a full HTML traceability report.
6. Generate a long Markdown or HTML prompt with actual 1,000+ line completeness checks.

Use the built-in Execution Monitor's Eliya/OpenCode comparison for actual runs, or export
run-detail JSON and invoke:

```bash
python qa/eliya142-compare-runs.py --eliya eliya-run.json --opencode opencode-run.json
```

The script refuses a comparable percentage if prompt, model, success state or provider
usage does not match. It warns when successful verification of the current workspace
revision is not available. Read-only analysis requires separate content/evidence review.

### Acceptance criteria

- No failed safeguards, missing required output, unverified claims or narrower migration scope.
- Fewer provider-reported total tokens than OpenCode **at equivalent verified quality**
  across the benchmark suite (not just one chosen task).
- Better or equivalent median end-to-end latency, with no large regressions in slow-tail runs.
- Prompt/context usage not reported by the provider is **not** counted as zero.

### Unresolved risks / next engineering work

- ELIYA141's stream handlers use blocking line iterators. They check cancellation between
  lines; a provider that never supplies another line may still delay cancellation.
  The UI inactivity warning is not a backend first-token/idle-stream timeout. Address
  this with a separately tested, cancellable transport design (avoid replaying partially
  executed tool calls).
- The full Maven build cannot run in this environment (`mvn` is missing, Maven Central
  hostname does not resolve). JUnit/Java Spring integration and the Windows JAR must be
  validated locally before treating this as a production release.
- The ELIYA141 artifact design still lacks a per-chunk resumable on-disk checkpoint;
  a 2,000-line HTML/Markdown generation may lose in-flight text on abrupt process death.
- Very broad tasks may still use the original planner and multiple outcome reviews;
  cutting them without reliable completion evidence could silently reduce quality.
- Provider throughput, context size, disk speed, model stability and user prompts have
  not been benchmarked here; no guaranteed percentage reduction is claimed.
