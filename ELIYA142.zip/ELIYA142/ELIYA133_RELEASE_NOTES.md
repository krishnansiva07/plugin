# ELIYA133 — Intent-aware Analyse → Prompt → Agent UI

Date: 2026-11-11. Base: **ELIYA132**, including all ELIYA131 upstream source, existing terminal, Maven/Java structure, workspace/permission and MCP wiring.

## Problem being fixed

A request to *check whether a migration completed* previously generated a short "let me inspect" acknowledgement and an irrelevant **Implement in Agent** button. General message actions showed Copy / Markdown / Preview whether or not the user had requested an artifact. Prompts and downloadable files could still be partial even though the UI treated them as complete.

## Implemented

1. **Task-specific response experience** (`response-experience.js`): local, deterministic presentation routing for verification, analysis, prompt generation and ordinary answers. Natural verification questions such as "Can you check migration completed successfully?" no longer need the word *workspace*.
2. **Workspace retrieval and truthful Analyse results** (`MappedWorkspaceEvidencePolicy`, `ContextService`): migration/Playwright/Selenium/Cucumber verification requests trigger mapped indexed context. Model instructions require a verdict, actual inspected paths/symbols, unverified areas and next steps. Analyse remains strictly read-only and does NOT claim to have run browser tests/compilers based on indexed snippets.
3. **No premature Implement**: a short acknowledgement, incomplete analysis or verification result cannot show a generic "Implement in Agent" action. The UI flags missing verification and offers **Complete verification in Analyse**. Substantive technical analysis with evidence can offer **Generate implementation prompt**; when selected, that request incorporates the exact saved analysis text, within a hard size bound.
4. **Whole, individually actionable prompts** (`response-artifacts.js`, `app.js`): a short outline or incomplete prompt card has **Generate complete prompt**, not Implement/Download. Independently complete prompts show a contextual **Implement this prompt** action plus Copy, Full View and Download. Existing message ID, selected text and workspace guards still protect Analyse → Agent handoff; only the selected section is authoritative.
5. **Artifact integrity and presentation**: standalone HTML requires `html`, `head`, `body` and closing tags and rejects placeholder output. Existing structured JSON/YAML detection and format-aware downloads remain. The artifact preview is a right-side desktop panel/full-screen mobile view with local edit/copy/download and HTML sandboxing. These are browser-local edits, not workspace writes.
6. **Simplified response toolbar**: the top-level answer row is Copy + contextual More. Export/preview variants live in More rather than competing with the primary task. Unnecessary composer authoring buttons were hidden; existing prompt factory, keyboard shortcuts and advanced features remain in the project.
7. **More explicit completion states**: Agent shows a final result derived from backend status and pending steps/work items/verifier failures. Missing model narrative is not a completion. Backend `AgentResultPresentation` now asks for real verification verdict/evidence for read-only migration checks; final report rendering exceptions block completed status rather than reporting unqualified success.
8. **Frontend cache bust**: script and CSS URLs updated for version 133.

## Demo acceptance scenarios

- "Can you check migration completed successfully?" → Analyse retrieves mapped workspace context. If the response is only "let me inspect", it displays **Verification not established**, and does NOT offer implementation. Genuine verification requires source-backed findings, and unrun tests remain unverified.
- "Generate an implementation prompt from those findings" → one continuous, standalone prompt. Incomplete drafts show **Generate complete prompt** rather than an executable action.
- "Give me two separate prompts" → two cards. Implement on Prompt 2 passes Prompt 2 only, without Prompt 1; the original saved response remains available for context.
- "Create a downloadable HTML report" → valid complete HTML gets Preview / Download `.html`. Incomplete HTML gets Generate complete file.
- "Fix the agreed issues" in Agent → prior native orchestration, approval, rollback and verification remain; the UI shows live stages and a result banner whose status comes from the backend, not from the model's description.

## What this release does NOT prove

- No full Maven/Spring Boot compilation was possible here: Maven is absent and `repo.maven.apache.org` cannot be resolved. This is a **source ZIP, not a prebuilt JAR**.
- No real LLM provider or live workspace migration, Jira MCP, Playwright test suite or backend Agent end-to-end run was exercised in this environment. The new presentation contract is covered by unit/Chromium simulations plus isolated Java tests.
- A browser-side verdict checks the presence of a formatted verdict and textual evidence, not independent proof that every cited file exists. The server instructs the model not to invent evidence, but a live repository acceptance run is required to evaluate factual accuracy.
- YAML content still uses a conservative structural acceptance test, not a complete YAML parser. Complex YAML needs downstream validation.
- Not a complete rewrite of the existing orchestration, indexing or terminal subsystems. They remain as in ELIYA132 except for targeted guards described above.

## Build and validate on your machine

1. Extract the archive and open the `ELIYA133` source directory. Java **17+** and Maven are needed for full packaging.
2. Run `build-jar-windows.cmd` on Windows (or `./build-jar.sh` on Linux/macOS). The output should be `target/eliya.jar` after a successful Maven build.
3. Run `java -jar target/eliya.jar`, open the UI at the configured localhost address, then perform a hard refresh to load the versioned assets.
4. Run `bash qa/run-eliya133-validation.sh` on a machine with Node, Java compiler, Python Playwright and an **installed Chrome/Edge/Chromium**. Set `ELIYA_BROWSER_BIN` if necessary; the QA script does not download a browser. For Windows, the Java/JS/Chromium components can be launched individually.
5. Configure your real LLM; select a **disposable** workspace and mapped legacy reference; test read-only migration verification, complete prompts, scoped Agent execution, real browser-based tests, artifact export, cancellation and verification failures.

See `ELIYA133_VALIDATION.md` for the exact test results and limitations.
