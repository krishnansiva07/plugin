# ELIYA135 — MCP-assisted Test Debugging Reliability

## User-reported issue
ELIYA134 was asked to use its configured MCP connection to run test `@123` and repair a failing `Select Search` step. It hallucinated explanations or fixes. The exact application defect cannot be reconstructed from the ELIYA source ZIP alone: the original MCP call outputs, application test project and execution trace were not supplied.

## Confirmed ELIYA134 gaps

1. `AgentService.executeWithPermission` treated an MCP response as successful unless the returned text literally included `isError=true`. A browser tool response can contain `isError=false` but include a locator error, timeout, or "No tests found" in its payload.
2. `AgentService.observeRun` also classified non-shell MCP execution as useful activity without recognizing the same embedded operation failures.
3. General final verification could accept local verifier success without separately establishing that the *requested exact tagged test* was actually run. A browser MCP snapshot/click does not necessarily execute a test from a Playwright/NX repository.
4. The execution protocol did not contain an explicit targeted browser-debug checklist for `test @123` flows.

## Implemented changes

- `McpToolOutcomePolicy`: distinguishes JSON-RPC transport success from browser/test operation failures. Includes standard Playwright locator, timeout, assertion, no-tests-found, and structured-failure cases. Non-browser MCP business text such as Jira issue `status: failed` remains ordinary source data.
- `AgentMcpTestEvidence`: recognizes explicitly requested MCP-assisted test execution by exact identifier (for example `@123`), requires source/runner discovery and a genuine exact-target runner result, and rejects browser clicks, snapshots, generic shell searches, different identifiers, zero-tests-run outcomes, and exit-zero without a passing test summary.
- `AgentService`: injects focused live-test and selector-debug requirements for such tasks; marks MCP operation failures as errors in Agent tool status; blocks final `completed` status when there is no passing exact-target execution evidence. Existing file edits are preserved for manual follow-up.
- `qa/run-eliya135-mcp-smoke.sh`: deterministic Java 17 tests for false-success and false-failure cases.

## The actual Select/Search defect
This update **does not claim to fix** the Select/Search step inside the user's application. A concrete fix requires the target test source, UI snapshot/trace, failure stack and selector/DOM evidence. ELIYA135 should now obtain these rather than guess.

## Verification

- 18 new Java 17 MCP/test outcome assertions passed.
- Existing 117 JavaScript tests passed.
- Existing ELIYA134 34 reliability assertions passed.
- Existing ELIYA133 and ELIYA134 Chromium browser workflows passed.
- Existing Java 17 source parser reports 166 source files parsed.
- No full Maven build and no live connection to the user's MCP server or `@123` project test were available.

## How to test in the real environment

1. Build/run this source in the existing Java 17 environment.
2. Verify mapped Playwright workspace and the MCP server connection; test discovery must list real available tools.
3. Ask Agent: `Use the configured Playwright MCP to investigate test @123. Identify the exact test and runner, execute it, capture the Select Search failure and a fresh browser accessibility snapshot, inspect the failing code, make the smallest grounded fix, and rerun the exact test. Report the original and final results, exact files changed, and evidence. If the test cannot run, mark it BLOCKED without claiming a fix.`
4. Confirm that MCP `browser_click` timeouts are displayed as errors, and that success is impossible without a passing recorded test run for `@123`.
5. For exact cause analysis, collect ELIYA's Agent activity output and targeted Playwright trace/console/run logs (remove credentials/session data before sharing).
