# ELIYA138 — Four Independent Prompt Generation, Display & Scoped Agent Handoff

Base: **ELIYA137 source fixes**, which incorporated ELIYA136. This package contains editable source; it is NOT a prebuilt, end-to-end verified JAR.

## Specific user defect addressed

Input example: "Analyse the mapped **legacy** Java Selenium/Cucumber framework, use **workspace** as the target Playwright TypeScript project (it currently has **no framework**), generate four prompts: (1) new framework, (2) core utilities, (3) advanced utilities, (4) reusable feature/scenario migration prompt."

Previously, the UI sometimes parsed a single Markdown-fenced response as **one** prompt. "Implement with Agent" could therefore be offered on a combined four-prompt response, and the full content was sent as the selected scope. Different intent detectors could also show a generic "Generate implementation prompt" CTA for the same prompt-generation request. This is a response parsing and action-routing issue, not proof of an LLM failure.

## Changes

1. Detect prompt-generation intent even for long requests or requests that specify "Prompt 1, Prompt 2, Prompt 3, and 4 reusable prompt" without repeating the verb "generate".
2. Infer expected prompt count from the request and enforce the count/sequence. A combined, missing, incorrectly numbered, repeated, or nested prompt set cannot offer an implementation handoff; a regeneration action is provided.
3. Recognize separate top-level headings, one outer `markdown`/`md`/`text` fence wrapping all prompts, and multiple individually fenced Markdown prompts. Preserve the full exact text for each separate stage.
4. Give **each prompt** its own dark, scrollable, selectable complete preview, full-screen view, Copy, and **Download this .md**. Filenames identify the prompt number/title, e.g. `prompt-4-reusable-migration-prompt.md`.
5. **Implement with Agent · this prompt only** prepares ONLY that selected prompt, using existing conversation/project validation, handoff markers and server scoped-selection policy. It does not execute the other three prompts, and the user reviews the handoff and presses Send before execution.
6. Hide generic "Generate implementation prompt" suggestions and the combined-document download UI for answers where the request itself is prompt generation. Regeneration asks for the explicitly requested set, with no execution.
7. Tighten Chat model instructions for the requested count, clear stages, `legacy` as reference, `workspace` as target, no assumed Playwright framework, and no meta-prompt substitutes. Tighten the Agent protocol to prioritize the delimited selected prompt over sibling sections in the source answer.
8. Bump JS/CSS asset versions to `138` to avoid stale browser caches.

## Validation performed

- PASS: `node --test src/test/js/*.test.js qa/eliya133-contract.test.js qa/eliya136-snapshot-ui.test.js qa/eliya137-responsive-output.test.js qa/eliya138-scoped-migration-prompts.test.js` — **136/136** tests passed, including **8 new scoped four-prompt regression tests**.
- PASS: `node --check` for modified browser JavaScript files.
- NOT VERIFIED: Full Java/JAR Maven build (the environment does not have the `mvn` command or accessible Maven dependencies); live Ollama/Qwen/other model integration, actual localhost:8090 browser screenshot/interaction, and a real Agent run with user workspace permissions. There is no evidence that these end-to-end tasks passed.

## Windows user acceptance checklist

1. Extract this ZIP to a new folder. Build with `build-jar-windows.cmd` using Java 17 and an available Maven environment.
2. Start locally and hard-refresh `http://localhost:8090/` so assets `app.js?v=138`, `response-artifacts.js?v=138` and `app.css?v=138` load.
3. Map **workspace** to the new/empty target TypeScript Playwright folder and **legacy** to the existing Java Selenium framework as the reference. Select **Analyse**.
4. Request FOUR PROMPTS ONLY: #1 create Playwright TypeScript Cucumber framework from scratch, #2 core utilities, #3 additional reusable utilities, #4 reusable migration prompt for each feature/scenario. Explicitly say *do not implement*.
5. Expect four distinct dark prompt cards, each with a full view, copy and `Download this .md`. Check each file's contents and unique scope; in particular #4 must not contain the complete text of #1–#3.
6. Click **Implement with Agent · this prompt only** on #2. Confirm the composer/banner includes **only prompt #2** between the selection markers; verify it does not contain the other three prompt bodies. Clicking should prepare the handoff, not silently execute it.
7. Press **Send** only when ready to execute and with a real writable workspace. Confirm Agent's plan and edited files concern #2 only, with required approvals and verified completion.
8. Repeat for #4. Test response styles: one outer Markdown fence and four separate fences. Incomplete/duplicate/missing prompts must show a regeneration warning, not an executable combined scope.
9. Check browser console and server logs, verify final artifacts on disk, and note any remaining model truncation/context-window errors separately.

## Scope caveat

The client-side parser and controls are deterministic and covered by tests. The model itself may still generate incorrect or unfinished prompts, and this package does NOT guarantee the correctness or completeness of a migration architecture without inspecting a real legacy framework or running the newly generated code. A genuine Agent implementation is subject to model context limits, backend approvals and available dependencies.
