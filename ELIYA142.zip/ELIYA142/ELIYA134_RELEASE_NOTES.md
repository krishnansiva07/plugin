# ELIYA134 — Agent Reliability: plan approval, migration resume and verification

Date: 2026-11-11. Base: ELIYA133 source. **Source release, not a prebuilt JAR.**

## Why this release exists

A detailed Selenium-to-Playwright Prompt 4 included `SOURCE_PACKAGE: testscripts.banner`, `RUN_MODE: RESUME_INCOMPLETE`, a required **STOP for explicit approval**, and instructions to implement **one approved batch only**. Earlier Agent intent classification could treat this mixed planning/execution instruction as direct implementation. `RUN_MODE` and `SOURCE_PACKAGE` were not connected to deterministic migration-ledger resume logic. Existing migration work had to be preserved.

## Implemented

1. **Explicit approval takes priority** (`AgentConversationIntent`): a `STOP/await approval` instruction causes a plan preview even if the same prompt contains `IMPLEMENT ONE APPROVED BATCH`. Direct requests without an approval gate remain direct. Negated gates such as "do not stop and await approval" do not force approval.
2. **Deterministic migration preflight** (`MigrationResumePreflight`): before provider calls, index warming, snapshot or edits, validate selected primary workspace and existing `migration/MIGRATION.md`, `migration/migration-ledger.csv`, `migration/PACKAGE_RUNBOOK.md`, `migration/shared-component-registry.md`. Explicitly identify a likely wrong parent root. Never regenerate missing migration files automatically.
3. **Source-package scoped ledger inspection**: parse bounded CSV including quoted fields; scope exactly to `testscripts.banner` rather than similarly named packages; require source method/case identity and state; reject duplicate IDs, unknown states and ambiguous schema. Distinguish VERIFIED, migrated-but-unverified, incomplete/retry, and held. Prioritize verification of existing migrated work, selecting **up to five** eligible method identities for a single batch. If source methods have test-case IDs, retain both identities.
4. **Plan provenance and stale-state guard**: fingerprint the four required migration artifacts using SHA-256. Save the preflight fingerprint alongside the proposed plan. On later approval, re-read source state and **block changes made after review**, requiring a fresh plan. The ledger and approved plan act as durable checkpoints; this is not an automatic continuation of a half-executed process.
5. **Durable, single-use conversational approval** (`AgentPendingPlanStore`): store pending plan previews in application data, bound to conversation and project, TTL 2 hours; consume once after an explicit `OK`, reject cross-project reuse, clear on independent new tasks; atomic file replacement and owner-only permissions on POSIX. The saved plan contains the original prompt and steps, so protect application data appropriately.
6. **Reliable final migration gate**: a completed Agent migration batch must independently verify **each exact selected method ID** transitioned to a verified/PASSED ledger state, not just a higher package-wide PASS count. The runtime must also have a successful test command and current-revision verifier evidence. Successful build or `--list` alone is not enough. Failed test exit codes are not test success even if the transport call succeeded. Missing evidence marks the batch blocked.
7. **UI approval as an explicit action** (`app.js`/`app.css`): one **Approve & execute this plan** control is shown immediately below the last eligible plan preview, not on regular analysis or a pending clarification. Clicking submits the single explicit `OK` continuation. The plan-preview outcome says **Plan ready · awaiting approval**, not "Completed implementation". Desktop and mobile checked.
8. **Reuse of ELIYA133 UX**: scoped prompt cards, generated HTML/Markdown artifacts, native Agent stages, workspace references, permissions and MCP gating retained.

## Use it for Prompt 4

1. Build the source on a machine with configured Maven dependencies, then launch the generated jar and refresh the UI.
2. Select the existing primary Playwright project root, not its parent, and the actual legacy reference. ELIYA does **not** auto-switch roots.
3. Paste the **original complete Prompt 4 unchanged**, including `SOURCE_PACKAGE: testscripts.banner`, `RUN_MODE: RESUME_INCOMPLETE`, and explicit review/approval stop instruction.
4. Review the preflight summary and proposed plan. Missing migration files or ambiguous ledger records now produce precise blockers, not recreated files or guesses.
5. Use **Approve & execute this plan**, and monitor bounded migration batch execution. Approve destructive changes separately as required by existing permissions.
6. Check final method IDs, actual test commands, status, and remaining migration rows. A blocked report means execution was **not verified complete**; it does not authorize changing ledger state to PASSED.

## Limits — important

- This does **not** prove your real Java Selenium package or Playwright project migrated. No access to your live Windows workspace or actual migration-ledger contents is available in this environment.
- A full Maven/Spring Boot JAR build and a live configured LLM/Agent run have **not** been performed. See the validation record for what was tested.
- Preflight supports common ledger column names and statuses, not every custom CSV schema. Unknown custom columns/states fail closed with their names, rather than guessing. Adjust the mapping to the real ledger if needed.
- Approval survives process restart only while its persisted TTL remains valid, with an unchanged project and migration fingerprint. A running batch does not automatically resume individual in-flight shell processes after a crash; ELIYA re-reconciles the ledger in a new run.
- Test-evidence gating recognizes Playwright, Cucumber, NX, npm/pnpm/yarn and Vitest test commands; it does not establish parity of assertions or test quality by itself. Source-to-target comparisons remain a required part of the prompt/Agent workflow.

## Files changed

- `src/main/java/com/llmart/llm/service/AgentConversationIntent.java`
- `src/main/java/com/llmart/llm/service/AgentService.java`
- `src/main/java/com/llmart/llm/service/MigrationResumePreflight.java` (new)
- `src/main/java/com/llmart/llm/service/AgentPendingPlanStore.java` (new)
- `src/main/java/com/llmart/llm/service/AgentMigrationExecutionEvidence.java` (new)
- `src/main/resources/static/app.js`, `app.css`, `index.html`
- `qa/eliya134-reliability/*` (new)

See `ELIYA134_VALIDATION.md` and `qa/run-eliya134-validation.sh`.
