# ELIYA136 — Protected Snapshot Performance and Truthful Agent Status

## Incident reproduced from screenshots
- The Agent run stopped during the rollback baseline, before editing any files.
- Error: `Protected rollback snapshot exceeded its 180s safety deadline (files=14725, dirs=2182, bytes=370465849)`.
- The request was to edit four Markdown files in `Migration Prompts/`; a full writable workspace snapshot was still attempted.
- Frontend previously marked Index through Verify with success ticks for terminal failures, even with 0/8 plan steps complete.

## Source changes (on top of ELIYA135)
1. `ProtectedRunSnapshotService`: preserve fail-closed whole-writable-root safety, but enumerate eligible files once and copy concurrently via a bounded 1–8 worker pool (default 4, configurable with `-Deliya.rollback.copyThreads=4`). A shared 180-second safety deadline and cancellation remain enforced. No writable Agent action is permitted before a complete manifest exists.
2. Add common generated/cache folder exclusions `.nx`, `.turbo`, `playwright-report`, `test-results`, `allure-results`, `allure-report`, `__pycache__`, `.pytest_cache`, `.mypy_cache`, `.terraform`. Keep the exclusion set consistent with `AgentTaskRollbackService` hashing/diff logic. Existing exclusions remain.
3. Thread-safe deadline/progress accounting in `AgentPreparationGuard`.
4. On fail/cancel/block, stage strip no longer paints all previous stages as verified success. It shows a failure point, with earlier stages as only reached, not verified.
5. Tests: 2 additional JUnit regression cases and 3 frontend stage-rendering tests.

## Scope and safety notes
- This is a targeted mitigation of copying overhead and misleading progress UI. It **does not** implement a task-scoped snapshot or guarantee success on every Windows filesystem.
- Existing rollback protection, deletion approval, and per-run transaction boundaries remain enabled. Do **not** disable rollback to circumvent the incident.
- The whole writable workspace and any writable reference outside the primary root still get protected. Read-only references are not snapshot targets.
- Cache/build exclusions intentionally do not roll back those generated output directories. Other source files remain protected.
- Windows antivirus, network-mounted drives, HDD latency, or oversized writable roots may still exceed the deadline. Check configured workspace root and move `app.data-dir` to a fast independent local disk outside every protected root.
- Last-resort startup property: `-Deliya.agent.snapshotTimeoutSeconds=600` (10 minutes). This increases the bounded wait; it is not a replacement for scope/performance improvements.
- Some external MCP/process side effects cannot be rolled back by the Java workspace snapshot.

## Verification limitations
- Tested locally with a stubbed Java 17 snapshot harness and synthetic 1,202-file workspace; binary/text restore and generated-output exclusion succeeded.
- 117 existing JS regressions and 3 new frontend stage tests passed.
- Not verified: full Maven build, packaged JAR, and real 14,725-file Windows ORION workspace under its actual antivirus/disk load.
