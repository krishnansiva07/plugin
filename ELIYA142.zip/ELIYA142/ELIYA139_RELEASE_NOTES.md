# ELIYA139 — Unified Long Prompt and HTML Source Viewer

Base: ELIYA138 Scoped Prompts source package. **Source release**; it is not a prebuilt or end-to-end verified JAR.

## Requested behavior

- **A single prompt** means exactly **one dark Markdown source panel**, even when that prompt covers framework creation, two utility stages, and a reusable Java Selenium → Playwright TypeScript migration stage. It is not split just because the body mentions Prompt 1/2/3/4.
- **N separate prompts** means N separate dark panels, each with independent source, Copy, `.md` download, and (only if executable and correctly scoped) Agent handoff.
- **Generated standalone HTML** appears directly as complete, unexecuted HTML source in a dark scrollable panel, with **Copy HTML**, **Download .html**, **Open full source**, and **Preview HTML**. Preview uses the existing restricted iframe. HTML source itself is never injected as executable markup into the chat.
- Displayed source is the same text the application uses for copying and downloading; the response is not artificially shortened or re-parsed into numerous inline code blocks.
- During streaming, source remains in a persistent dark panel and is appended as text. At completion, long source remains scrollable; 1,000+ lines do not trigger a client-side line limit.
- Optional commentary outside a single Markdown document fence is not included in the downloaded `.md` file. In an HTML answer, a standalone full HTML document can be identified even if explanatory text appears outside it.
- If output was interrupted, the partial Markdown source remains visible in the dark viewer. Interrupted/unclosed source cannot be downloaded as a **complete** file. An otherwise intact Markdown draft can be saved even if it is not yet safe for Agent implementation.
- Long HTML is not incorrectly rejected merely because JavaScript uses the `...` spread operator.

## Source changes

- `src/main/resources/static/response-artifacts.js` — distinguish explicit single prompt from separate prompt sets; canonical source extraction; HTML file classification; large HTML validation; retained interrupted source; separate implementation and download safety policies.
- `src/main/resources/static/app.js` — persistent streamed source display; one dark panel at completion; HTML source actions; exact source copy/download; isolated HTML preview; source-first handling for generated prompts and HTML.
- `src/main/resources/static/app.css` — readable dark source containers with bounded-height vertical scroll, suitable for 1,000+ lines; full-view dark styling and mobile width protections.
- `src/main/resources/static/index.html` — asset cache version **139**.
- `src/main/java/com/llmart/llm/service/ContextService.java` — model instruction to honor single-vs-multiple document requests and preserve full source.
- `qa/eliya139-unified-source.test.js` — long-document and source contract tests.

## Verification performed here

- **PASS: 144/144 JavaScript tests**:

  ```text
  node --test src/test/js/*.test.js qa/eliya133-contract.test.js qa/eliya136-snapshot-ui.test.js qa/eliya137-responsive-output.test.js qa/eliya138-scoped-migration-prompts.test.js qa/eliya139-unified-source.test.js
  ```

- **PASS: JavaScript syntax checks** for modified JS files.
- Test fixtures include a **1,400-line single prompt** and **1,100+ line HTML output**, incomplete HTML, interrupted prompt, Markdown containing multiple numbered stages, and existing four-prompt scoping safeguards.
- **NOT VERIFIED: Java/Spring Boot JAR build.** The current environment lacks a usable Maven installation/dependency cache. Build on your Windows machine with Java 17 and Maven using `build-jar-windows.cmd`.
- **NOT VERIFIED: production browser visual/e2e run.** Browser navigation to the local UI was blocked by this execution environment, so no screenshot or complete interaction result is claimed.
- **NOT VERIFIED: live model output length, saved backend response, clipboard permissions, or production Agent execution.** Model output remains constrained by provider output budget and Chat continuation limits; UI display fixes do not make a model emit an unlimited number of tokens.

## Acceptance tests on your Windows system

1. Extract the ZIP, install/build dependencies as required, and run `build-jar-windows.cmd`. Start the generated JAR and hard-refresh `http://localhost:8090/`. Check that the loaded `app.js`, `app.css`, and `response-artifacts.js` are version **139**.
2. In **Analyse**, request **ONE SINGLE Markdown prompt** covering: framework creation from scratch, core utilities, advanced utilities, and reusable migration for Java Selenium → Playwright TypeScript/Cucumber. Map `legacy` to the reference Java project and `workspace` to the target project. Confirm **one** dark prompt panel, not four. Scroll to the end, Copy and Download `.md`, then compare the complete content.
3. Request **FOUR SEPARATE prompts** for those stages. Confirm exactly four individual source panels. Prepare Agent handoff from only Prompt 2; verify the composer contains only Prompt 2, not all four.
4. Ask for a standalone HTML report containing **at least 1,000 lines**. Confirm the last generated line is present in the dark source panel, Copy/Download match, and Preview HTML opens the rendered page in the isolated frame.
5. Disconnect/interrupt generation of a large prompt. Confirm the incomplete source remains visible and cannot be advertised as a completed downloadable prompt. Retry completion and verify the final file.
6. Confirm generating prompts **does not execute** any Agent task, and Agent handoff remains an explicit separately confirmed action.

## Scope caveat

The UI source document contract is improved, but model-generation length and correctness remain dependent on your configured LLM provider, continuation logic, context window, and machine. ELIYA139 is not represented as a fully validated, stable production release until the Windows JAR and live end-to-end acceptance checks pass.
