# ELIYA132 Validation

## Run with Node 18+ and Java 17+

```bash
node --check src/main/resources/static/app.js
node --check src/main/resources/static/response-artifacts.js
node --test src/test/js/*.test.js
node qa/response-artifacts-132.test.js
javac -d /tmp/eliya132-jvm src/main/java/com/llmart/llm/service/ConversationHandoffSelection.java qa/eliya132-jvm/ScopeContractCheck.java
java -cp /tmp/eliya132-jvm com.llmart.llm.service.ScopeContractCheck
```

Browser test (requires `playwright` Python and installed Chromium at `/usr/bin/chromium`):

```bash
python qa/eliya132_browser_smoke.py
```

## Manual test flows (on an actual Java server)

1. Analyse: request `Give me 5 separate prompts to migrate Selenium to Playwright`. Each card must have its own complete text and own Implement action. Select Prompt 3: Agent composer must include Prompt 3 and its shared preamble but **not** Prompts 1, 2, 4, or 5. Send starts execution only after explicit confirmation.
2. With a draft already in the composer, click Implement. Cancel restores the original draft. Change workspace between prepare and send: the handoff must be rejected.
3. Analyse: `Generate a downloadable HTML file named report.html` — complete fenced HTML should have a preview and direct `report.html` download. An HTML fragment must show `Generate complete file` instead.
4. Preview generated HTML, edit its source, Apply edits, then download. Verify edited download differs from the original message but does not change workspace files.
5. Generate JSON and YAML file requests. Malformed JSON must be refused as ready. Single YAML blocks should export `.yml` but require external YAML validation when correctness matters.
6. Verify mobile narrow viewport, dark theme, models popover, long prompt scrolling, and `More` secondary actions.
7. Run end-to-end with your real LLM provider and workspace, inspect streaming reconnection, Agent completion evidence, deletion approvals, and final artifact files.
