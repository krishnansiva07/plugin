/* ELIYA133: Presentation policy; the assistant's intent and real evidence determine actions.
 * Pure, dependency-free and testable in browser/Node. Never fabricates a verification verdict.
 */
(function(root, factory) {
  const api=factory();
  if (typeof module==='object' && module.exports) module.exports=api;
  if (root) root.EliyaResponseExperience=api;
})(typeof window!=='undefined'?window:null,function(){
  'use strict';
  const normal = value=>String(value??'').replace(/\r\n/g,'\n').trim();
  const askPrompt = /\b(?:give|write|generate|create|draft|prepare|produce|build|make|convert|turn|provide|share|export|download)\b[\s\S]{0,650}\bprompts?\b|\b(?:implementation|execution|agent|complete|reusable|ready.to.use)\s+prompts?\b|\bprompts?\s+(?:for|to|based on|from)\b/i;
  const informationalPrompt = /^(?:what|why|how|when|where|which)\b.{0,70}\bprompts?\b/i;
  const verify = /\b(?:verify|verification|validate|validation|confirm|audit|check|assess|is|was|were|has|have|whether|did)\b.{0,130}\b(?:migrat(?:ion|ed|e)|framework|test(?:s|ing)?|scenario|coverage|release|deploy(?:ment|ed)?|implementation|complete(?:d|ness)?|success(?:ful|fully)?|passed|ready|done|finished|correct|working)\b|\b(?:migration|deployment|implementation|coverage)\b.{0,120}\b(?:complete|success|verified|valid|passed|check|verify)\b/i;
  const proposal = /\b(?:recommend(?:ed|ations?)?|propos(?:e|ed|al)|implement(?:ation)?\s+plan|fix(?:es|ing)?\s+the\s+gaps|actionable steps|changes\s+needed|next steps?|suggest(?:ed|ion)?|remediation)\b/i;
  const evidence = /(?:\b(?:src[/\\]|tests?[/\\]|pom\.xml\b|package\.json\b|\.feature\b|\.java\b|\.ts\b|\.xml\b|\.json\b)|\b(?:evidence|findings?|test results?|observed|inspected files?|line\s+\d+|source paths?|limitations?)\s*[:\-]|\b(?:passed|failed)\s+\d+\b)/i;
  const acknowledgement = /^(?:(?:sure|okay|ok|certainly|understood)[.,! ]+)?(?:let me|i(?:'ll| will| am going to| can| would)\s+(?:first\s+)?(?:check|inspect|review|analyse|analyze|verify|validate|look|investigate|start|examine|compare|search)|i need to (?:check|inspect|review|verify|investigate))\b/i;
  const explicitVerdict = /(?:^|\n)\s*(?:\*\*)?(?:verdict|migration status|verification status|result|outcome)(?:\*\*)?\s*[:\-]\s*(?:\*\*)?\s*(verified|partially verified|not verified|inconclusive|complete|partially complete|incomplete|failed|passed|blocked|cannot confirm|unable to confirm)\b/i;
  const stopped = /\[ELIYA:\s*response incomplete\]|\bGeneration stopped\b/i;
  const placeholder = /\b(?:TODO|PLACEHOLDER|insert (?:your|the)|rest of the code|same as above)\b|\.\.\./i;
  function intent(question) {
    const q=normal(question);
    if (typeof window!=='undefined' && window.EliyaResponseArtifacts?.isPromptRequest?.(q)) return 'prompt';
    if ((askPrompt.test(q) || /\bprompt\s*1\b[\s\S]*\bprompt\s*2\b/i.test(q)) && !informationalPrompt.test(q)) return 'prompt';
    if (verify.test(q)) return 'verification';
    if (/\b(?:analyse|analyze|inspect|compare|investigate|review|explain|trace|identify|find gaps?)\b/i.test(q)) return 'analysis';
    return 'answer';
  }
  function result({question='',answer='',streaming=false,mode='chat'}={}) {
    const type=intent(question), output=normal(answer);
    if(mode==='agent') return {intent:type,status:streaming?'executing':'finished',showHandoff:false,showPromptCta:false};
    if(streaming)return {intent:type,status:'working',showHandoff:false,showPromptCta:false};
    if(!output || stopped.test(output)) return {intent:type,status:'incomplete',showHandoff:false,showPromptCta:false};
    if(type==='verification') {
      const verdict=output.match(explicitVerdict);
      const hasEvidence=evidence.test(output) && output.length>=140;
      const complete=Boolean(verdict && hasEvidence && !acknowledgement.test(output));
      return {intent:type,status:complete?'reported':'unverified',verdict:complete?verdict[1].toLowerCase():'not established',
        showHandoff:false,showPromptCta:false,hasEvidence};
    }
    if(type==='prompt'){
      const incomplete=acknowledgement.test(output) && output.length<300;
      return {intent:type,status:incomplete?'incomplete':'ready',showHandoff:false,showPromptCta:false};
    }
    const substantive=output.length>=140 && !acknowledgement.test(output);
    const actionable=substantive && proposal.test(output) && evidence.test(output);
    return {intent:type,status:substantive?'answered':'incomplete',showHandoff:false,
      showPromptCta:actionable && type==='analysis',hasEvidence:evidence.test(output)};
  }
  function verificationFollowup(question){
    const q=normal(question);
    return `Complete the verification requested below NOW using the current mapped workspace and reference context. This is a READ-ONLY investigation. Read real available source/configuration evidence; compare legacy and target for feature/scenario coverage and configuration. State a clear **Verdict:** Verified / Partially verified / Not verified / Inconclusive, and give **Evidence** with real file paths or inspected symbols, **Missing/unverified** checks, and **Next steps**. Do not state that commands/tests ran unless execution evidence exists; static index retrieval alone never proves all tests pass. If available evidence is insufficient, say Inconclusive and identify precisely what remains to be checked. Do not answer with 'let me inspect' or promise future work. Original request: ${q}`;
  }
  function promptFollowup(question){
    return `Generate ONE COMPLETE, SELF-CONTAINED implementation prompt from the immediately preceding completed Analyse findings about: ${normal(question)}. Include objective, selected workspace/reference roles, source-backed findings versus unknowns, exact in-scope modifications, constraints, ordered implementation and independent acceptance/verification checks. Do not invent absent paths or silently execute. Output a single complete reusable prompt, not an introduction, outline or pieces. If multiple separate prompts were expressly requested, make each independent.`;
  }
  return Object.freeze({intent,result,verificationFollowup,promptFollowup});
});
