/* ELIYA81: keyed conversation DOM reconciliation, no framework dependency.
 * Kept separate so main conversation, Agent, and Terminal can share predictable updates.
 */
(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  if (root) root.EliyaRenderDiff = api;
})(typeof window !== 'undefined' ? window : null, function () {
  'use strict';
  const weak = new WeakMap();
  function memo(message, index, count, render) {
    if (typeof count === 'function') {render=count;count=index+1;} // public test/legacy API
    // Completed Chat turns are immutable display documents. Re-running Markdown
    // parsing on every spinner/status update was O(history size) work and made
    // 1,000-line artifacts increasingly sluggish. Agent and live messages are
    // deliberately excluded because their live approval/run state can change.
    if (!message || message.streaming || message.agentProgress || message.testCaseJob ||
        message.agentRunId || message.__eliyaEditing) return render(message,index);
    const prior=weak.get(message);
    const key=[message.role,message.id,message.mode,message.chatCompletionWarning,
      message.archivedFiles?.length,message.attachmentIds?.length,index,index===count-1];
    if(prior && prior.content===message.content && prior.index===index &&
       prior.key.length===key.length && key.every((part,j)=>part===prior.key[j]))return prior.html;
    const html=render(message,index);
    weak.set(message,{content:message.content,index,key,html});
    return html;
  }
  function reconcile(root, items, render) {
    if (!root) return {added:0, changed:0, removed:0, unchanged:0};
    const existing = [...root.children].filter(n => n.classList?.contains('message'));
    const nextHtml = items.map((message, i) => memo(message, i, items.length, render));
    const stats = {added:0, changed:0, removed:0, unchanged:0};
    for (let i=0;i<nextHtml.length;i++) {
      const current = existing[i];
      const html = nextHtml[i];
      if (current && current.__eliyaRenderedHtml === html) {stats.unchanged++;continue;}
      const template = document.createElement('template');
      template.innerHTML = html;
      const replacement = template.content.firstElementChild;
      if (!replacement) continue;
      replacement.__eliyaRenderedHtml = html;
      if (current) {
        // A changed Agent card preserves a user's expanded disclosures.
        const open = [...current.querySelectorAll('details')].map(d => ({open:d.open,cls:d.className}));
        replacement.querySelectorAll('details').forEach((node, j) => {
          if (open[j]?.cls === node.className) node.open = open[j].open;
        });
        current.replaceWith(replacement);stats.changed++;
      } else {root.appendChild(replacement);stats.added++;}
    }
    for (let i=nextHtml.length;i<existing.length;i++) {existing[i].remove();stats.removed++;}
    return stats;
  }
  return Object.freeze({reconcile,memo});
});
