package com.llmart.llm.service;

import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * Avoid paying for the same proactive search bundle *and* source-grounded tool output
 * in one turn. A new active step or loss of live evidence automatically re-enables
 * retrieval. Nothing here prevents the agent from calling read/grep/knowledge tools.
 */
final class AgentTurnEvidenceEconomy {
    private static final Set<String> SOURCE_TOOLS = Set.of(
            "inspect_workspace", "glob", "grep", "read", "read_many", "file_info",
            "code_impact", "resource_read", "resource_grep", "knowledge_read",
            "knowledge_search", "documentation_module", "lsp", "conversation_handoff_read");
    private AgentTurnEvidenceEconomy() { }

    static boolean shouldDeferRetrieval(List<Map<String,Object>> history) {
        if (!Boolean.parseBoolean(System.getProperty("eliya.tokens.evidenceHandoff.enabled", "true")) ||
                history == null || history.isEmpty()) return false;
        int boundary = -1;
        for (int i = history.size() - 1; i >= 0; i--) {
            Map<String,Object> row = history.get(i);
            if (!"system".equals(String.valueOf(row.get("role")))) continue;
            String content = String.valueOf(row.getOrDefault("content", ""));
            if (content.startsWith("[RUNTIME_STEERING:active-step-contract]") ||
                    content.startsWith("CONVERSATION INVESTIGATION:")) { boundary = i; break; }
        }
        if (boundary < 0) return false;
        int sourceReads = 0;
        // Only evidence *after the current step boundary* is eligible. A new step
        // therefore gets its own source primer, even after a long previous step.
        for (int i = history.size() - 1; i > boundary; i--) {
            Map<String,Object> row = history.get(i);
            String role = String.valueOf(row.getOrDefault("role", ""));
            String content = String.valueOf(row.getOrDefault("content", ""));
            if (content.length() < 80 || content.length() > 250_000) continue;
            String tool = "";
            if ("tool".equals(role)) tool = String.valueOf(row.getOrDefault("name", ""));
            else if ("user".equals(role) && content.startsWith("TOOL RESULT for ")) {
                int end = content.indexOf(':');
                if (end > "TOOL RESULT for ".length()) tool = content.substring("TOOL RESULT for ".length(), end);
            }
            if (!SOURCE_TOOLS.contains(tool.trim().toLowerCase(Locale.ROOT))) continue;
            String lower = content.strip().toLowerCase(Locale.ROOT);
            if (lower.startsWith("error") || lower.startsWith("[error") ||
                    lower.contains("tool failed") || lower.contains("permission denied")) continue;
            if (++sourceReads >= 2) return true;
        }
        return false;
    }
}
