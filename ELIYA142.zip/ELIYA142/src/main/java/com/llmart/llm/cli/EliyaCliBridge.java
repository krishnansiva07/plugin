package com.llmart.llm.cli;

import com.llmart.llm.dto.ProjectDto;
import com.llmart.llm.dto.ChatRequest;
import com.llmart.llm.dto.ChatSettings;
import com.llmart.llm.dto.MessageDto;
import com.llmart.llm.service.ChatService;
import com.llmart.llm.service.AgentRunService;
import com.llmart.llm.service.AgentQuestionService;
import com.llmart.llm.service.AgentApprovalService;
import org.springframework.http.MediaType;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;
import org.springframework.web.server.ResponseStatusException;
import com.llmart.llm.service.ConversationService;
import com.llmart.llm.service.LocalProjectIndexService;
import com.llmart.llm.service.ProjectService;
import jakarta.annotation.PreDestroy;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.boot.web.servlet.context.ServletWebServerApplicationContext;
import org.springframework.context.event.EventListener;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.awt.Desktop;
import java.awt.GraphicsEnvironment;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.nio.file.attribute.PosixFilePermission;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.*;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

/** Loopback-only CLI-to-browser bridge. CLI mutations require a per-process random bearer secret.
 * The ordinary browser polls a read-only selection revision to adopt terminal workspace changes.
 */
@RestController
@RequestMapping("/api/cli")
public class EliyaCliBridge {
    public record ActivationRequest(String workspace, String sessionId) {
        public ActivationRequest(String workspace) { this(workspace, null); }
    }
    public record Selection(String version, ProjectDto project, String conversationId, String mode) { }
    public record BrowserSettings(String apiKey, ChatSettings settings) { }
    public record TerminalPrompt(String mode, String prompt, String workspace, String sessionId) {
        public TerminalPrompt(String mode, String prompt, String workspace) { this(mode, prompt, workspace, null); }
    }
    public record ModeRequest(String mode, String workspace, String sessionId) {
        public ModeRequest(String mode, String workspace) { this(mode, workspace, null); }
    }
    public record ApprovalDecision(String runId, String approvalId, String decision) { }
    public record QuestionAnswer(String runId, String questionId, String choice, String detail) { }

    private final ProjectService projects;
    private final ConversationService conversations;
    private final LocalProjectIndexService indexJobs;
    private final ChatService chat;
    private final AgentRunService agentRuns;
    private final AgentQuestionService questions;
    private final AgentApprovalService approvals;
    // Each CLI process owns its selection and conversation; browser selection remains independent.
    private final ConcurrentHashMap<String, Selection> terminalSelections = new ConcurrentHashMap<>();
    private final Map<String, String> conversationByWorkspace = new java.util.concurrent.ConcurrentHashMap<>();
    private volatile BrowserSettings browserSettings;
    // Prevent parallel writes to the same workspace (sessions remain independently addressable).
    private final ConcurrentHashMap<String,String> activeAgentWorkspaces = new ConcurrentHashMap<>();
    private final ExecutorService terminalWorkers = Executors.newFixedThreadPool(8, task -> {
        Thread thread = new Thread(task, "eliya-cli-run"); thread.setDaemon(true); return thread;
    });
    private final ServletWebServerApplicationContext webServer;
    private final String token;
    private final String instance = UUID.randomUUID().toString();
    private final AtomicLong revision = new AtomicLong();
    private volatile Selection current = new Selection("", null, null, "analyse");
    private volatile boolean published;
    private volatile EliyaCliAutoSetup.SetupResult cliSetup =
            new EliyaCliAutoSetup.SetupResult(false, null, "CLI setup not started");

    public EliyaCliBridge(ProjectService projects, ConversationService conversations,
                          LocalProjectIndexService indexJobs, ServletWebServerApplicationContext webServer,
                          ChatService chat, AgentRunService agentRuns, AgentQuestionService questions, AgentApprovalService approvals) {
        this.projects = projects;
        this.conversations = conversations;
        this.indexJobs = indexJobs;
        this.webServer = webServer;
        this.chat = chat;
        this.agentRuns = agentRuns;
        this.questions = questions;
        this.approvals = approvals;
        byte[] random = new byte[32];
        new SecureRandom().nextBytes(random);
        this.token = HexFormat.of().formatHex(random);
    }

    public static Path bridgeFile() {
        String data = System.getProperty("app.data-dir");
        if (data == null || data.isBlank()) throw new IllegalStateException("Eliya data path not initialized");
        return Path.of(data).resolve("eliya-cli-bridge.txt");
    }

    @EventListener(ApplicationReadyEvent.class)
    public void ready() {
        int port = webServer.getWebServer().getPort();
        try {
            Path target = bridgeFile();
            Files.createDirectories(target.getParent());
            Path tmp = Files.createTempFile(target.getParent(), ".eliya-cli-", ".tmp");
            restrictFile(tmp);
            Files.writeString(tmp, port + "\n" + token + "\n", StandardCharsets.UTF_8,
                    StandardOpenOption.TRUNCATE_EXISTING);
            try { Files.move(tmp, target, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING); }
            catch (AtomicMoveNotSupportedException ex) { Files.move(tmp, target, StandardCopyOption.REPLACE_EXISTING); }
            restrictFile(target);
            published = true;
        } catch (Exception ex) {
            System.err.println("ELIYA CLI bridge unavailable: " + ex.getMessage());
        }

        // Per-OS CLI setup is part of JAR startup, not a separate PowerShell/script installer.
        // It is safe to skip when running from IDE classes and never blocks browser startup.
        cliSetup = EliyaCliAutoSetup.onJarStartup(com.llmart.llm.LlmApplication.class);
        System.out.println("ELIYA CLI: " + cliSetup.message());

        String workspace = System.getProperty("eliya.startup.workspace", "").trim();
        if (workspace.isEmpty()) {
            // `java -jar` may be invoked from an IDE project; don't index arbitrary home/drive folders.
            Path detected = ProjectDirectoryLocator.detectedProject(Path.of(""));
            if (detected != null) workspace = detected.toString();
        }
        if (!workspace.isEmpty()) {
            try { activateWorkspace(workspace); }
            catch (Exception ex) { System.err.println("ELIYA workspace was not mapped: " + ex.getMessage()); }
        }
        String url = "http://localhost:" + port + "/";
        System.out.println("ELIYA ready: " + url);
        if (!"false".equalsIgnoreCase(System.getProperty("eliya.browser.enabled", "true")) &&
                !"true".equalsIgnoreCase(System.getenv("ELIYA_NO_BROWSER"))) openBrowser(url);
    }

    private synchronized ProjectDto activateWorkspace(String workspace) {
        if (workspace == null) return current.project(); // `eliya open` must preserve selection.
        Path path = Path.of(workspace).toAbsolutePath().normalize();
        String key = path.toString();
        String conversationId = conversationByWorkspace.computeIfAbsent(key, ignored -> {
            // Reopen the same workspace conversation after an application restart,
            // but never reuse a deleted conversation ID.
            Set<String> existing = new HashSet<>();
            conversations.list().forEach(conversation -> existing.add(conversation.id()));
            return projects.mappedLocalWorkspaces().stream()
                    .filter(project -> key.equals(project.localPath()))
                    .map(ProjectDto::conversationId)
                    .filter(existing::contains)
                    .findFirst()
                    .orElseGet(() -> conversations.create().getId());
        });
        ProjectDto project = projects.createLocal(conversationId, key, null);
        indexJobs.request(project, false);
        current = new Selection(instance + ":" + revision.incrementAndGet(), project, conversationId, "analyse");
        System.out.println("ELIYA workspace: " + project.localPath() + " (background indexing enabled)");
        return project;
    }

    /** A CLI session has its own persistent conversation and immutable project selection.
     * Never switch the global browser selection because another IDE terminal ran a command.
     */
    private synchronized Selection activateTerminalWorkspace(String sessionId, String workspace) {
        if (!validSessionId(sessionId)) throw new IllegalArgumentException("Invalid terminal session identifier");
        Selection previous = terminalSelections.get(sessionId);
        if (workspace == null || workspace.isBlank()) {
            if (previous != null) return previous;
            if (current.project() == null) throw new IllegalArgumentException("No mapped project; run eliya in a project folder");
            workspace = current.project().localPath();
        }
        Path root = Path.of(workspace).toAbsolutePath().normalize();
        if (!Files.isDirectory(root)) throw new IllegalArgumentException("Workspace directory does not exist: " + root);
        if (previous != null && previous.project() != null &&
                root.toString().equals(previous.project().localPath())) return previous;
        String conversationId = conversations.create().getId();
        ProjectDto project = projects.createLocal(conversationId, root.toString(), null);
        indexJobs.request(project, false);
        Selection selection = new Selection(instance + ":" + revision.incrementAndGet(),
                project, conversationId, previous == null ? "analyse" : previous.mode());
        terminalSelections.put(sessionId, selection);
        return selection;
    }

    private static boolean validSessionId(String id) {
        if (id == null || id.isBlank()) return false;
        try { UUID.fromString(id); return true; }
        catch (IllegalArgumentException ex) { return false; }
    }

    private synchronized Selection selectTerminalMode(String sessionId, String mode, String workspace) {
        Selection selection = activateTerminalWorkspace(sessionId, workspace);
        String normalized = mode == null ? "" : mode.toLowerCase(Locale.ROOT).trim();
        if (!Set.of("analyse", "agent").contains(normalized))
            throw new IllegalArgumentException("Mode must be analyse or agent");
        Selection updated = new Selection(instance + ":" + revision.incrementAndGet(),
                selection.project(), selection.conversationId(), normalized);
        terminalSelections.put(sessionId, updated);
        return updated;
    }

    private Selection ownedSession(String sessionId) {
        if (!validSessionId(sessionId)) throw new IllegalArgumentException("A valid terminal session is required");
        Selection selection = terminalSelections.get(sessionId);
        if (selection == null) throw new IllegalArgumentException("Unknown terminal session");
        return selection;
    }

    private AgentRunService.AgentRun ownedRun(String sessionId, String runId) {
        Selection selection = ownedSession(sessionId);
        AgentRunService.AgentRun run = agentRuns.require(runId);
        if (!selection.conversationId().equals(run.conversationId()))
            throw new SecurityException("Run does not belong to this terminal session");
        return run;
    }

    private synchronized Selection chooseMode(String mode, String workspace) {
        // Never allow one terminal to execute against another terminal's globally
        // selected project. The calling terminal pins its canonical workspace.
        if (workspace != null && !workspace.isBlank() &&
                (current.project() == null || !Path.of(current.project().localPath()).equals(
                        Path.of(workspace).toAbsolutePath().normalize()))) {
            activateWorkspace(workspace);
        }
        if (current.project() == null || current.conversationId() == null)
            throw new IllegalArgumentException("No workspace selected. Run `eliya` from a project folder or `eliya workspace <path>`.");
        String normalized = mode == null ? "" : mode.toLowerCase(Locale.ROOT).trim();
        if (!Set.of("analyse", "agent").contains(normalized))
            throw new IllegalArgumentException("Mode must be analyse or agent");
        current = new Selection(instance + ":" + revision.incrementAndGet(),
                current.project(), current.conversationId(), normalized);
        return current;
    }

    private boolean authorized(String credential, HttpServletRequest request) {
        return isLoopback(request.getRemoteAddr()) && credential != null &&
                MessageDigest.isEqual(credential.getBytes(StandardCharsets.UTF_8), token.getBytes(StandardCharsets.UTF_8));
    }

    /** Browser settings never go into the bridge file, logs, or terminal JSON response.
     * Same-origin application JavaScript alone can supply these settings (custom header blocks cross-origin forms).
     */
    @PostMapping("/browser-settings")
    public ResponseEntity<?> browserSettings(@RequestBody BrowserSettings supplied,
            @RequestHeader(value = "X-Eliya-Local-UI", required = false) String marker,
            @RequestHeader(value = "Origin", required = false) String origin,
            HttpServletRequest request) {
        String expected = "http://127.0.0.1:" + webServer.getWebServer().getPort();
        String altExpected = "http://localhost:" + webServer.getWebServer().getPort();
        if (!isLoopback(request.getRemoteAddr()) || !"settings-sync".equals(marker) ||
                (origin != null && !origin.equals(expected) && !origin.equals(altExpected))) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        }
        if (supplied == null || supplied.settings() == null || supplied.apiKey() == null ||
                supplied.apiKey().isBlank() || supplied.settings().baseUrl() == null ||
                supplied.settings().baseUrl().isBlank() || supplied.settings().model() == null ||
                supplied.settings().model().isBlank()) {
            browserSettings = null;
            return ResponseEntity.ok(Map.of("configured", false));
        }
        browserSettings = supplied; // process memory only; never disclose credential to the CLI.
        return ResponseEntity.ok(Map.of("configured", true));
    }

    /** Read-only setup diagnostic for the locally opened browser. Never exposes API credentials. */
    @GetMapping("/setup-state")
    public ResponseEntity<?> setupState(HttpServletRequest request) {
        if (!isLoopback(request.getRemoteAddr())) return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        boolean windows = EliyaCliAutoSetup.detectPlatform(System.getProperty("os.name", "")) ==
                EliyaCliAutoSetup.Platform.WINDOWS;
        boolean readyInNewTerminals = cliSetup.installed() &&
                (!windows || cliSetup.message().startsWith("Eliya CLI installed directly"));
        return ResponseEntity.ok(Map.of("installed", cliSetup.installed(),
                "readyInNewTerminals", readyInNewTerminals,
                "message", cliSetup.message(), "platform", System.getProperty("os.name", "unknown")));
    }

    @GetMapping("/status")
    public ResponseEntity<?> status(@RequestHeader(value = "X-Eliya-CLI-Token", required = false) String credential,
                                    @RequestHeader(value = "X-Eliya-Session", required = false) String sessionId,
                                    HttpServletRequest request) {
        if (!authorized(credential, request)) return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        return ResponseEntity.ok(Map.of("selection", (sessionId == null || sessionId.isBlank())
                        ? current : terminalSelections.getOrDefault(sessionId, current),
                "sessionId", sessionId == null ? "" : sessionId,
                "modelConfigured", browserSettings != null,
                "url", "http://localhost:" + webServer.getWebServer().getPort() + "/"));
    }

    @PostMapping("/mode")
    public ResponseEntity<?> mode(@RequestBody ModeRequest body,
            @RequestHeader(value = "X-Eliya-CLI-Token", required = false) String credential,
            HttpServletRequest request) {
        if (!authorized(credential, request)) return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        if (body != null && body.sessionId() != null && !body.sessionId().isBlank() &&
                !validSessionId(body.sessionId())) return ResponseEntity.badRequest().body(Map.of("error", "Invalid session ID"));
        try { return ResponseEntity.ok(body != null && validSessionId(body.sessionId())
                ? selectTerminalMode(body.sessionId(), body.mode(), body.workspace())
                : chooseMode(body == null ? null : body.mode(), body == null ? null : body.workspace())); }
        catch (IllegalArgumentException e) { return ResponseEntity.badRequest().body(Map.of("error", e.getMessage())); }
    }

    /** Runs exactly the same native Chat/Agent pipeline as the browser, using the
     * current mapped workspace and a workspace-scoped persistent conversation.
     * This endpoint is callable only by the token-bearing local launcher.
     */
    @PostMapping(path = "/run", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
    public SseEmitter run(@RequestBody TerminalPrompt body,
            @RequestHeader(value = "X-Eliya-CLI-Token", required = false) String credential,
            HttpServletRequest request) {
        if (!authorized(credential, request)) throw new ResponseStatusException(HttpStatus.FORBIDDEN,
                "Not an authorized local Eliya terminal");
        if (body != null && body.sessionId() != null && !body.sessionId().isBlank() &&
                !validSessionId(body.sessionId()))
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Invalid terminal session ID");
        BrowserSettings configuration = browserSettings;
        if (configuration == null) throw new ResponseStatusException(HttpStatus.CONFLICT,
                "Configure the API key, Base URL and models in Eliya browser Settings first.");
        if (body == null) throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Prompt is required");
        String mode = body == null ? null : body.mode();
        if (mode == null || !Set.of("analyse", "agent", "implement").contains(mode))
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Mode must be analyse, agent or implement");
        Selection selection;
        try { selection = validSessionId(body.sessionId())
                ? selectTerminalMode(body.sessionId(), "implement".equals(mode) ? "agent" : mode, body.workspace())
                : chooseMode("implement".equals(mode) ? "agent" : mode, body.workspace()); }
        catch (IllegalArgumentException ex) { throw new ResponseStatusException(HttpStatus.BAD_REQUEST, ex.getMessage()); }
        String prompt = body.prompt() == null ? "" : body.prompt().strip();
        if ("implement".equals(mode)) {
            java.util.List<MessageDto> history = conversations.listMessages(selection.conversationId());
            boolean hasAnalysis = history.stream().anyMatch(m -> "assistant".equals(m.role()) &&
                    ("chat".equals(m.mode()) || m.mode() == null) && m.content() != null && !m.content().isBlank());
            if (!hasAnalysis) throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                    "No completed Analyse response in this workspace conversation. Run `eliya analyse` first.");
            prompt = "Implement the last agreed Analyse plan from this conversation in the selected workspace. " +
                    "Read its findings and constraints, apply the requested changes, run appropriate verification, " +
                    "and report evidence of success or failure.";
            mode = "agent";
        }
        if (prompt.isBlank()) throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Prompt cannot be empty");
        // The request retains its own immutable workspace snapshot even if another terminal switches.
        ChatRequest chatRequest = new ChatRequest(selection.conversationId(), prompt, List.of(),
                selection.project().id(), "agent".equals(mode) ? "agent" : "chat", false, configuration.settings());
        String workspaceRoot = selection.project().localPath();
        String workspaceKey;
        try { workspaceKey = Path.of(workspaceRoot).toRealPath().toString(); }
        catch (Exception ex) { workspaceKey = Path.of(workspaceRoot).toAbsolutePath().normalize().toString(); }
        final String lockedRoot = workspaceKey;
        final boolean agentMode = "agent".equals(mode);
        final String owner = validSessionId(body.sessionId()) ? body.sessionId() : "browser-cli-" + UUID.randomUUID();
        if (agentMode) synchronized (activeAgentWorkspaces) {
            Path requested = Path.of(lockedRoot);
            boolean conflicting = activeAgentWorkspaces.keySet().stream().anyMatch(active -> {
                Path root = Path.of(active);
                return requested.startsWith(root) || root.startsWith(requested);
            });
            if (conflicting) throw new ResponseStatusException(HttpStatus.CONFLICT,
                    "Another terminal Agent is modifying this workspace or an overlapping folder. " +
                    "Finish or cancel that Agent before starting a conflicting edit.");
            activeAgentWorkspaces.put(lockedRoot, owner);
        }
        SseEmitter output = new SseEmitter(0L);
        AtomicBoolean open = new AtomicBoolean(true);
        output.onCompletion(() -> open.set(false));
        output.onError(error -> open.set(false));
        output.onTimeout(() -> open.set(false));
        try {
            terminalWorkers.submit(() -> {
                try {
                    chat.runTerminal(configuration.apiKey(), chatRequest, (event, data) -> {
                        if (!open.get()) return; // Disconnect does not cancel Agent; completion persists server-side.
                        try { output.send(SseEmitter.event().name(event).data(data)); }
                        catch (Exception ex) { open.set(false); }
                    });
                } catch (Exception ex) {
                    if (open.get()) try { output.send(SseEmitter.event().name("error")
                            .data(Map.of("message", "CLI execution failed: " + ex.getClass().getSimpleName()))); }
                    catch (Exception ignored) { }
                } finally {
                    if (agentMode) activeAgentWorkspaces.remove(lockedRoot, owner);
                    try { output.complete(); } catch (Exception ignored) { }
                }
            });
        } catch (RuntimeException ex) {
            if (agentMode) activeAgentWorkspaces.remove(lockedRoot, owner);
            throw ex;
        }
        return output;
    }

    @PostMapping("/refresh")
    public ResponseEntity<?> refresh(
            @RequestHeader(value = "X-Eliya-CLI-Token", required = false) String credential,
            HttpServletRequest request) {
        if (!authorized(credential, request)) return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        // No browser-global selection changes for an independent terminal run.
        return ResponseEntity.ok(Map.of("refreshed", true));
    }

    @GetMapping("/selection")
    public ResponseEntity<Selection> selection(HttpServletRequest servletRequest) {
        if (!isLoopback(servletRequest.getRemoteAddr())) return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        return ResponseEntity.ok(current);
    }

    @PostMapping("/activate")
    public ResponseEntity<?> activate(@RequestBody ActivationRequest request,
                                      @RequestHeader(value = "X-Eliya-CLI-Token", required = false) String credential,
                                      HttpServletRequest servletRequest) {
        if (!authorized(credential, servletRequest)) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(Map.of("error", "Not an authorized local Eliya CLI"));
        }
        if (request != null && request.sessionId() != null && !request.sessionId().isBlank() &&
                !validSessionId(request.sessionId())) return ResponseEntity.badRequest().body(Map.of("error", "Invalid session ID"));
        try {
            Selection selection = request != null && validSessionId(request.sessionId())
                    ? activateTerminalWorkspace(request.sessionId(), request.workspace())
                    : activateGlobalSelection(request == null ? null : request.workspace());
            return ResponseEntity.ok(Map.of("selection", selection,
                    "url", "http://localhost:" + webServer.getWebServer().getPort() + "/"));
        }
        catch (IllegalArgumentException exception) { return ResponseEntity.badRequest().body(Map.of("error", exception.getMessage())); }
    }

    private Selection activateGlobalSelection(String workspace) {
        activateWorkspace(workspace);
        return current;
    }

    /** Snapshot timings and exact verification status from the authoritative Agent run. */
    @GetMapping("/session/result")
    public ResponseEntity<?> terminalResult(@RequestParam String sessionId,
            @RequestHeader(value = "X-Eliya-CLI-Token", required = false) String credential,
            HttpServletRequest request) {
        if (!authorized(credential, request)) return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        try {
            Selection selection = ownedSession(sessionId);
            return ResponseEntity.ok(agentRuns.latestForConversation(selection.conversationId())
                    .orElseGet(() -> Map.of("status", "no_agent_run")));
        } catch (IllegalArgumentException ex) { return ResponseEntity.badRequest().body(Map.of("error", ex.getMessage())); }
    }

    @PostMapping("/session/cancel")
    public ResponseEntity<?> cancelSession(@RequestParam String sessionId,
            @RequestHeader(value = "X-Eliya-CLI-Token", required = false) String credential,
            HttpServletRequest request) {
        if (!authorized(credential, request)) return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        try {
            Selection selection = ownedSession(sessionId);
            boolean stopped = agentRuns.latestForConversation(selection.conversationId())
                    .map(snapshot -> agentRuns.cancel(String.valueOf(snapshot.get("id")))).orElse(false);
            stopped |= chat.cancelChat(selection.conversationId());
            return ResponseEntity.ok(Map.of("cancellationRequested", stopped));
        } catch (IllegalArgumentException ex) { return ResponseEntity.badRequest().body(Map.of("error", ex.getMessage())); }
    }

    @GetMapping("/session/question")
    public ResponseEntity<?> terminalQuestion(@RequestParam String sessionId, @RequestParam String runId,
            @RequestHeader(value = "X-Eliya-CLI-Token", required = false) String credential,
            HttpServletRequest request) {
        if (!authorized(credential, request)) return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        try { ownedRun(sessionId, runId); return ResponseEntity.ok(questions.pending(runId)); }
        catch (RuntimeException ex) { return ResponseEntity.badRequest().body(Map.of("error", "Run unavailable for this session")); }
    }

    @PostMapping("/session/question")
    public ResponseEntity<?> answerQuestion(@RequestParam String sessionId, @RequestBody QuestionAnswer answer,
            @RequestHeader(value = "X-Eliya-CLI-Token", required = false) String credential,
            HttpServletRequest request) {
        if (!authorized(credential, request)) return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        try {
            ownedRun(sessionId, answer.runId());
            if (!questions.answer(answer.runId(), answer.questionId(), answer.choice(), answer.detail()))
                return ResponseEntity.status(HttpStatus.CONFLICT).body(Map.of("error", "Question expired or invalid"));
            return ResponseEntity.ok(Map.of("answered", true));
        } catch (RuntimeException ex) { return ResponseEntity.badRequest().body(Map.of("error", "Run unavailable for this session")); }
    }

    @PostMapping("/session/approval")
    public ResponseEntity<?> decideApproval(@RequestParam String sessionId, @RequestBody ApprovalDecision answer,
            @RequestHeader(value = "X-Eliya-CLI-Token", required = false) String credential,
            HttpServletRequest request) {
        if (!authorized(credential, request)) return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        try {
            ownedRun(sessionId, answer.runId());
            AgentApprovalService.Decision decision = switch (answer.decision() == null ? "" : answer.decision().toLowerCase(Locale.ROOT)) {
                case "once" -> AgentApprovalService.Decision.ONCE;
                case "run" -> AgentApprovalService.Decision.RUN;
                case "deny" -> AgentApprovalService.Decision.DENY;
                default -> throw new IllegalArgumentException("Decision must be once, run or deny");
            };
            if (!approvals.resolveForRun(answer.approvalId(), answer.runId(), decision))
                return ResponseEntity.status(HttpStatus.CONFLICT).body(Map.of("error", "Approval expired, invalid or restricted"));
            return ResponseEntity.ok(Map.of("resolved", true));
        } catch (RuntimeException ex) { return ResponseEntity.badRequest().body(Map.of("error", "Run unavailable for this session")); }
    }

    private static boolean isLoopback(String host) {
        try { return java.net.InetAddress.getByName(host).isLoopbackAddress(); }
        catch (Exception ex) { return false; }
    }

    private static void restrictFile(Path file) {
        try { Files.setPosixFilePermissions(file, Set.of(PosixFilePermission.OWNER_READ, PosixFilePermission.OWNER_WRITE)); }
        catch (UnsupportedOperationException | java.io.IOException ignored) { /* Windows inherits user-profile ACLs. */ }
    }

    @PreDestroy
    public void shutdown() {
        terminalWorkers.shutdownNow();
        if (!published) return;
        try {
            Path file = bridgeFile();
            List<String> lines = Files.readAllLines(file, StandardCharsets.UTF_8);
            if (lines.size() > 1 && token.equals(lines.get(1))) Files.deleteIfExists(file);
        } catch (Exception ignored) { }
    }

    /** Open only a fixed localhost Eliya URL. A closed/headless desktop is non-fatal. */
    public static void openBrowser(String baseUrl) {
        try {
            URI address = URI.create(baseUrl);
            if (!("localhost".equalsIgnoreCase(address.getHost()) || "127.0.0.1".equals(address.getHost())) || !"http".equals(address.getScheme())) return;
            if (!GraphicsEnvironment.isHeadless() && Desktop.isDesktopSupported() &&
                    Desktop.getDesktop().isSupported(Desktop.Action.BROWSE)) {
                Desktop.getDesktop().browse(address);
                return;
            }
            String os = System.getProperty("os.name", "").toLowerCase(Locale.ROOT);
            String[] command = os.contains("win")
                    ? new String[]{"rundll32", "url.dll,FileProtocolHandler", address.toString()}
                    : os.contains("mac") ? new String[]{"open", address.toString()}
                    : new String[]{"xdg-open", address.toString()};
            new ProcessBuilder(command).start();
        } catch (Exception ex) {
            System.out.println("Open Eliya in your browser: " + baseUrl);
        }
    }
}
