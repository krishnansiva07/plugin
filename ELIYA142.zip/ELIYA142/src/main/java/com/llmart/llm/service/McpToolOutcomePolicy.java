package com.llmart.llm.service;

import java.util.regex.Pattern;

/**
 * Treat transport success separately from the success of the operation executed by an MCP server.
 * Many browser servers place locator errors in text, even when the outer JSON-RPC call succeeded.
 * Conservative anchored patterns avoid flagging ordinary page content containing the word "error".
 */
final class McpToolOutcomePolicy {
    private static final Pattern OPERATION_FAILURE = Pattern.compile(
            "(?im)^\\s*(?:Error:|TimeoutError:|AssertionError:|Strict mode violation:|" +
            "PlaywrightError:|locator\\.[a-z]+:.*(?:timeout|failed|error)|" +
            "(?:\\d+\\s+)?failed\\s+tests?\\b|" +
            "(?:Tests?:\\s*)?\\d+\\s+failed\\b|" +
            "No tests found\\b|" +
            "(?:status|result)\\s*[:=]\\s*(?:FAIL(?:ED)?|ERROR|TIMED_OUT)\\b)");

    private McpToolOutcomePolicy() { }

    static boolean failed(String tool, String output) {
        if (tool == null || !tool.startsWith("mcp__")) return false;
        if (output == null || output.isBlank()) return true;
        String trimmed = output.stripLeading();
        if (trimmed.startsWith("MCP PROTOCOL ERROR ") || trimmed.contains("isError=true")) return true;
        // Only browser/test MCPs should interpret arbitrary text as a command result.
        // A Jira/Confluence page containing "status: failed" is ordinary source data.
        String name = tool.toLowerCase(java.util.Locale.ROOT);
        boolean browserOrTests = name.contains("playwright") || name.contains("browser") ||
                name.contains("selenium") || name.contains("webdriver") || name.contains("cypress") ||
                name.contains("test");
        if (!browserOrTests) return false;
        if (OPERATION_FAILURE.matcher(output).find()) return true;
        // Structured tool status is an exact machine-readable field, not an arbitrary log sentence.
        return output.matches("(?s).*\\\"(?:status|outcome)\\\"\\s*:\\s*\\\"(?:failed|error|timeout)\\\".*");
    }
}
