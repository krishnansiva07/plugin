package com.llmart.llm.service;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.security.MessageDigest;
import java.util.*;
import java.util.regex.*;

/**
 * Read-only, deterministic gate for explicit SOURCE_PACKAGE + RUN_MODE: RESUME_INCOMPLETE tasks.
 * Never creates migration files, invents source paths or treats a model-written claim as ledger evidence.
 * The existing migration ledger is the durable source of truth for batch resume.
 */
final class MigrationResumePreflight {
    private static final Pattern PACKAGE = Pattern.compile("(?im)^\\s*(?:[-*]\\s*)?SOURCE[ _-]*PACKAGE\\s*[:=]\\s*`?([A-Za-z_][\\w]*(?:\\.[A-Za-z_][\\w]*)+)`?\\s*$");
    private static final Pattern RUN_MODE = Pattern.compile("(?im)^\\s*(?:[-*]\\s*)?RUN[ _-]*MODE\\s*[:=]\\s*`?([A-Z_]+)`?\\s*$");
    private static final List<String> REQUIRED = List.of(
            "migration/MIGRATION.md", "migration/migration-ledger.csv",
            "migration/PACKAGE_RUNBOOK.md", "migration/shared-component-registry.md");
    private static final long MAX_CSV_BYTES = 5_000_000;
    private static final long MAX_DOCUMENT_BYTES = 1_000_000;
    private static final int MAX_ROWS = 50_000;
    private static final int MAX_COLUMNS = 80;
    private static final Set<String> VERIFIED = Set.of("verified", "passed", "pass", "completed", "complete", "success", "successful");
    private static final Set<String> IMPLEMENTED_UNVERIFIED = Set.of("migrated", "implemented", "ported", "created", "converted", "ready_for_validation", "unverified");
    private static final Set<String> INCOMPLETE = Set.of("pending", "todo", "not_started", "not_migrated", "in_progress", "started", "partial", "partially_migrated", "incomplete", "failed", "error", "retry", "needs_fix", "needs_migration", "missing");
    private static final Set<String> BLOCKED = Set.of("blocked", "skipped", "on_hold", "needs_approval", "deferred");

    record Result(boolean applicable, boolean ready, String sourcePackage, String fingerprint,
                  int verified, int needsVerification, int pending, int blocked,
                  List<String> nextBatch, Map<String,String> statusById, String report) {
        static Result notApplicable() { return new Result(false, true, "", "", 0, 0, 0, 0, List.of(), Map.of(), ""); }
        static Result stop(String pkg, String reason) { return new Result(true, false, pkg, "", 0, 0, 0, 0, List.of(), Map.of(), reason); }
        String instruction() {
            if (!applicable || !ready) return "";
            return "MIGRATION RESUME PRE-FLIGHT (LIVE FILE EVIDENCE; RECHECK BEFORE EVERY WRITE):\n" + report +
                    "\nOnly the listed unfinished methods may be selected for the NEXT bounded batch. " +
                    "Previously implemented but unverified methods require comparison/verification BEFORE rewriting. " +
                    "Use the original prompt's other requirements, mapped legacy sources, registered target components, " +
                    "and approval rules. Do not fabricate discovery or label a ledger row PASSED without execution evidence. " +
                    "Update the existing ledger after each verified change, not a parallel ledger. " +
                    "When any row, mapping, or target implementation is inconsistent, stop and show the mismatch.\n";
        }
    }

    static Result inspect(Path primaryWorkspace, String request) {
        if (request == null) return Result.notApplicable();
        Matcher mode = RUN_MODE.matcher(request);
        if (!mode.find() || !"RESUME_INCOMPLETE".equalsIgnoreCase(mode.group(1))) return Result.notApplicable();
        Matcher source = PACKAGE.matcher(request);
        if (!source.find()) return Result.stop("", "RUN_MODE=RESUME_INCOMPLETE requires a concrete SOURCE_PACKAGE: Java package. No changes made.");
        String pkg = source.group(1);
        if (primaryWorkspace == null) return Result.stop(pkg, "No primary workspace mapped. Select the existing Playwright project; migration cannot resume.");
        try {
            Path root = primaryWorkspace.toRealPath();
            if (!Files.isDirectory(root, LinkOption.NOFOLLOW_LINKS)) return Result.stop(pkg, "Primary workspace is not a directory: " + root);
            if (!Files.isDirectory(root.resolve("migration"), LinkOption.NOFOLLOW_LINKS)) {
                Path nested = root.resolve("playwright/migration");
                return Result.stop(pkg, "Migration directory not found under selected PRIMARY workspace " + root + ". " +
                        (Files.isDirectory(nested, LinkOption.NOFOLLOW_LINKS)
                                ? "Found a nested playwright/migration directory. Select " + root.resolve("playwright") + " as the primary workspace; no automatic root switching."
                                : "Expected migration/MIGRATION.md and migration/migration-ledger.csv. No files created."));
            }
            List<Path> documents = new ArrayList<>();
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            for (String name : REQUIRED) {
                Path file = root.resolve(name).normalize();
                if (!file.startsWith(root) || !Files.isRegularFile(file, LinkOption.NOFOLLOW_LINKS) || hasSymlink(root, file))
                    return Result.stop(pkg, "Missing or unsafe REQUIRED migration artifact: " + name + " under " + root + ". Reconcile Prompt 1-3 artifacts first; nothing was recreated.");
                long size = Files.size(file);
                long limit = name.endsWith(".csv") ? MAX_CSV_BYTES : MAX_DOCUMENT_BYTES;
                if (size == 0 || size > limit) return Result.stop(pkg, "Required migration artifact empty/too large: " + name + " (" + size + " bytes). No changes made.");
                digest.update(name.getBytes(StandardCharsets.UTF_8));
                digest.update((byte) 0);
                digest.update(Files.readAllBytes(file));
                documents.add(file);
            }
            String csv = Files.readString(root.resolve("migration/migration-ledger.csv"), StandardCharsets.UTF_8);
            List<List<String>> rows = parseCsv(csv);
            if (rows.size() < 2) return Result.stop(pkg, "migration/migration-ledger.csv contains no migration records; cannot safely resume.");
            List<String> header = rows.get(0).stream().map(MigrationResumePreflight::normalize).toList();
            int packageCol = column(header, "source_package", "legacy_package", "java_package", "package", "package_name");
            int sourceClassCol = column(header, "source_class", "legacy_class", "java_class", "source_file", "source_path", "legacy_path");
            int idCol = column(header, "source_method", "source_method_id", "legacy_method", "legacy_test_method", "java_method", "method_id", "test_id", "source_test", "source_test_id", "test_method", "test_method_name", "source_test_method", "java_test_method", "method_name", "method");
            int caseIdCol = column(header, "test_case_id", "scenario_id", "case_id", "data_row_id");
            int statusCol = column(header, "status", "migration_status", "state", "verification_status", "test_status", "current_status");
            if (idCol < 0 || statusCol < 0) return Result.stop(pkg,
                    "Ledger schema cannot establish exactly which Java methods were migrated. Expected a source-method/test ID and migration status column; found: " + header + ". No changes made.");
            if (packageCol < 0 && sourceClassCol < 0) {
                // A fully qualified method column can identify a package without a separate
                // package column; unqualified names cannot be safely scoped.
                boolean allQualified = rows.stream().skip(1).filter(row -> !row.stream().allMatch(String::isBlank))
                        .allMatch(row -> value(row, idCol).contains("."));
                if (!allQualified) return Result.stop(pkg,
                        "Ledger has no source-package/source-class column or consistently fully-qualified method IDs. " +
                        "Cannot isolate " + pkg + " safely; found: " + header + ".");
            }
            LinkedHashSet<String> ids = new LinkedHashSet<>();
            LinkedHashMap<String,String> statusById = new LinkedHashMap<>();
            List<String> unverified = new ArrayList<>();
            List<String> pending = new ArrayList<>();
            List<String> held = new ArrayList<>();
            int verified = 0, included = 0;
            for (int n = 1; n < rows.size(); n++) {
                List<String> row = rows.get(n);
                if (row.stream().allMatch(String::isBlank)) continue;
                String rowPackage = value(row, packageCol >= 0 ? packageCol : sourceClassCol).trim();
                if (packageCol < 0 && sourceClassCol < 0) rowPackage = value(row, idCol).trim();
                String slashPackage = pkg.replace('.', '/');
                // Accept actual package/class paths only, not similarly-prefixed package names.
                boolean inPackage = rowPackage.equals(pkg) || rowPackage.startsWith(pkg + ".") ||
                        rowPackage.replace('\\','/').contains("/" + slashPackage + "/") ||
                        rowPackage.replace('\\','/').endsWith("/" + slashPackage + ".java");
                if (!inPackage) continue;
                included++;
                String id = value(row, idCol).trim();
                if (id.isBlank()) return Result.stop(pkg, "Missing source-method identity at ledger record " + (n + 1) + ".");
                String caseId = value(row, caseIdCol).trim();
                if (!caseId.isBlank() && !caseId.equals(id)) id += " #" + caseId;
                if (id.isBlank() || !ids.add(id)) return Result.stop(pkg, "Duplicate/missing source-method identity at ledger record " + (n + 1) + ": '" + id + "'. Stop to avoid duplicated coverage.");
                String rawStatus = value(row, statusCol);
                String status = normalize(rawStatus);
                statusById.put(id, status);
                if (VERIFIED.contains(status)) verified++;
                else if (IMPLEMENTED_UNVERIFIED.contains(status)) unverified.add(id + " [" + rawStatus.trim() + "; verify existing target first]");
                else if (INCOMPLETE.contains(status)) pending.add(id + " [" + rawStatus.trim() + "]");
                else if (BLOCKED.contains(status)) held.add(id + " [" + rawStatus.trim() + "]");
                else return Result.stop(pkg, "Unknown migration status '" + rawStatus + "' for " + id + " in ledger record " + (n + 1) + ". Stop; do not guess whether the test is complete.");
            }
            if (included == 0) return Result.stop(pkg, "No ledger records belong to SOURCE_PACKAGE " + pkg + ". Check actual Java package/migration mappings; no changes made.");
            List<String> batch = new ArrayList<>();
            // Existing target methods first: validate/repair, not duplicate.
            for (String id : unverified) if (batch.size() < 5) batch.add(id);
            for (String id : pending) if (batch.size() < 5) batch.add(id);
            String fingerprint = HexFormat.of().formatHex(digest.digest());
            String report = "Primary workspace: " + root + "\nSource package: " + pkg +
                    "\nLedger/documents SHA-256 fingerprint: " + fingerprint +
                    "\nRecords: " + included + " (verified=" + verified + ", implemented but unverified=" +
                    unverified.size() + ", pending/retry=" + pending.size() + ", held=" + held.size() + ")" +
                    "\nNext eligible batch (up to 5, NOT executed): " + batch +
                    "\nHeld records (require investigation/approval): " + held +
                    "\nExisting mapping/registry/runbook files: " + REQUIRED +
                    "\nImportant: ledger status is an inventory claim, not independently proven browser-test success.";
            return new Result(true, true, pkg, fingerprint, verified, unverified.size(), pending.size(), held.size(), List.copyOf(batch), Map.copyOf(statusById), report);
        } catch (Exception e) {
            return Result.stop(pkg, "Migration preflight failed safely (" + e.getClass().getSimpleName() + "): " + e.getMessage() + ". No changes made.");
        }
    }

    /** Verify the actual selected method IDs, not just a package-wide PASS count. */
    static boolean selectedBatchVerified(Result before, Result after) {
        if (before == null || after == null || !before.applicable() || !before.ready() || !after.ready() ||
                !before.sourcePackage().equals(after.sourcePackage()) || before.nextBatch().isEmpty()) return false;
        for (String entry : before.nextBatch()) {
            int marker = entry.lastIndexOf(" [");
            String id = marker >= 0 ? entry.substring(0, marker) : entry;
            if (!VERIFIED.contains(after.statusById().getOrDefault(id, ""))) return false;
        }
        return true;
    }

    private static boolean hasSymlink(Path root, Path file) {
        for (Path p = file; p != null && p.startsWith(root); p = p.getParent()) {
            if (Files.isSymbolicLink(p)) return true;
            if (p.equals(root)) break;
        }
        return false;
    }
    private static String value(List<String> row, int idx) { return idx < 0 || idx >= row.size() ? "" : row.get(idx); }
    private static int column(List<String> header, String... options) {
        for (String option : options) { int index = header.indexOf(option); if (index >= 0) return index; }
        return -1;
    }
    private static String normalize(String s) {
        return (s == null ? "" : s.strip().replace("\ufeff", "")).toLowerCase(Locale.ROOT)
                .replaceAll("[^a-z0-9]+", "_").replaceAll("^_+|_+$", "");
    }
    /** Parses quoted comma/CRLF/newline CSV with a hard row/column bound; rejects broken quotes. */
    private static List<List<String>> parseCsv(String text) throws IOException {
        List<List<String>> out = new ArrayList<>();
        List<String> row = new ArrayList<>();
        StringBuilder cell = new StringBuilder();
        boolean quotes = false;
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if (c == '"') {
                if (quotes && i + 1 < text.length() && text.charAt(i + 1) == '"') { cell.append('"'); i++; }
                else if (!quotes && cell.toString().trim().isEmpty()) { quotes = true; }
                else if (quotes) quotes = false;
                else throw new IOException("Malformed quote in migration ledger");
            } else if (c == ',' && !quotes) {
                row.add(cell.toString()); cell.setLength(0);
                if (row.size() > MAX_COLUMNS) throw new IOException("Too many ledger columns");
            } else if ((c == '\n' || c == '\r') && !quotes) {
                if (c == '\r' && i + 1 < text.length() && text.charAt(i + 1) == '\n') i++;
                row.add(cell.toString()); cell.setLength(0);
                out.add(List.copyOf(row)); row.clear();
                if (out.size() > MAX_ROWS) throw new IOException("Too many migration ledger rows");
            } else cell.append(c);
        }
        if (quotes) throw new IOException("Unclosed quote in migration ledger");
        if (!row.isEmpty() || !cell.isEmpty()) { row.add(cell.toString()); out.add(List.copyOf(row)); }
        return out;
    }
}
