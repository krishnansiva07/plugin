package com.llmart.llm.service;

import java.io.*;
import java.nio.file.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.time.*;
import java.util.*;

/**
 * Durable, single-use confirmation record for a conversational plan preview.
 * A restart must not convert a queued plan into direct authorization, lose its scope,
 * or associate approval with another project/conversation. Treat saved prompt text as private.
 */
final class AgentPendingPlanStore {
    private static final int MAGIC = 0x454C5034; // ELP4
    private static final int MAX_TEXT = 1_000_000;
    private static final int MAX_ITEMS = 128;
    private static final Duration TTL = Duration.ofHours(2);
    private final Path directory;

    record Pending(String projectId, String originalTask, List<String> steps,
                   List<String> attachments, String clarification, Instant createdAt,
                   String migrationFingerprint) {
        boolean matches(String project) {
            return Objects.equals(projectId == null ? "" : projectId, project == null ? "" : project)
                    && createdAt != null && createdAt.isAfter(Instant.now().minus(TTL))
                    && !createdAt.isAfter(Instant.now().plusSeconds(60));
        }
    }

    AgentPendingPlanStore() {
        this(Path.of(System.getProperty("eliya.agent.pendingPlanDir", "./data/agent-pending-plans")));
    }
    AgentPendingPlanStore(Path directory) { this.directory = directory.toAbsolutePath().normalize(); }

    synchronized void save(String conversationId, Pending plan) throws IOException {
        requireConversation(conversationId);
        if (plan == null || !plan.matches(plan.projectId()) || plan.steps() == null || plan.steps().isEmpty())
            throw new IOException("Cannot persist an empty/expired Agent plan");
        ensureDirectory();
        Path destination = key(conversationId);
        Path temp = Files.createTempFile(directory, "pending-", ".tmp");
        ownerOnly(temp, false);
        try {
            try (DataOutputStream out = new DataOutputStream(new BufferedOutputStream(Files.newOutputStream(temp)))) {
                out.writeInt(MAGIC);
                out.writeLong(plan.createdAt().toEpochMilli());
                write(out, plan.projectId()); write(out, plan.originalTask());
                writeList(out, plan.steps()); writeList(out, plan.attachments());
                write(out, plan.clarification()); write(out, plan.migrationFingerprint());
            }
            try { Files.move(temp, destination, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (AtomicMoveNotSupportedException e) { Files.move(temp, destination, StandardCopyOption.REPLACE_EXISTING); }
        } finally { Files.deleteIfExists(temp); }
    }

    synchronized Optional<Pending> load(String conversationId, String projectId) {
        if (conversationId == null || conversationId.isBlank()) return Optional.empty();
        Path path = key(conversationId);
        if (!Files.isRegularFile(path, LinkOption.NOFOLLOW_LINKS)) return Optional.empty();
        try {
            if (Files.size(path) > 4_000_000) { Files.deleteIfExists(path); return Optional.empty(); }
            try (DataInputStream in = new DataInputStream(new BufferedInputStream(Files.newInputStream(path, LinkOption.NOFOLLOW_LINKS)))) {
                if (in.readInt() != MAGIC) throw new IOException("Unsupported plan format");
                Instant created = Instant.ofEpochMilli(in.readLong());
                Pending plan = new Pending(read(in), read(in), readList(in), readList(in), read(in), created, read(in));
                if (!plan.matches(projectId)) {
                    // Keep a still-valid record bound to a DIFFERENT project; no cross-workspace approval.
                    if (created.isBefore(Instant.now().minus(TTL))) Files.deleteIfExists(path);
                    return Optional.empty();
                }
                if (plan.steps().isEmpty()) return Optional.empty();
                return Optional.of(plan);
            }
        } catch (Exception failure) { return Optional.empty(); } // corrupted record never grants approval
    }

    /** Exactly one conversation confirmation can consume this plan in this server instance. */
    synchronized Optional<Pending> consume(String conversationId, String projectId) {
        Optional<Pending> item = load(conversationId, projectId);
        if (item.isEmpty()) return Optional.empty();
        try { Files.deleteIfExists(key(conversationId)); }
        catch (IOException e) { return Optional.empty(); } // cannot establish single-use: fail closed
        return item;
    }

    synchronized void discard(String conversationId) {
        if (conversationId == null || conversationId.isBlank()) return;
        try { Files.deleteIfExists(key(conversationId)); } catch (IOException ignored) { }
    }

    private void ensureDirectory() throws IOException {
        if (Files.isSymbolicLink(directory)) throw new IOException("Pending-plan store must not be a symlink");
        Files.createDirectories(directory);
        if (!Files.isDirectory(directory, LinkOption.NOFOLLOW_LINKS)) throw new IOException("Pending-plan store unavailable");
        ownerOnly(directory, true);
    }
    private static void ownerOnly(Path file, boolean directory) throws IOException {
        try {
            Files.setPosixFilePermissions(file, java.nio.file.attribute.PosixFilePermissions.fromString(
                    directory ? "rwx------" : "rw-------"));
        } catch (UnsupportedOperationException ignored) {
            // Windows ACLs use the current user's inherited default policy.
        }
    }
    private static void requireConversation(String value) throws IOException {
        if (value == null || value.isBlank()) throw new IOException("Conversation ID required");
    }
    private Path key(String conversationId) {
        try {
            MessageDigest sha = MessageDigest.getInstance("SHA-256");
            return directory.resolve(HexFormat.of().formatHex(sha.digest(conversationId.getBytes(StandardCharsets.UTF_8))) + ".plan");
        } catch (Exception e) { throw new IllegalStateException(e); }
    }
    private static void write(DataOutputStream out, String text) throws IOException {
        byte[] bytes = Objects.toString(text, "").getBytes(StandardCharsets.UTF_8);
        if (bytes.length > MAX_TEXT) throw new IOException("Pending plan text too large");
        out.writeInt(bytes.length); out.write(bytes);
    }
    private static String read(DataInputStream in) throws IOException {
        int length = in.readInt();
        if (length < 0 || length > MAX_TEXT) throw new IOException("Invalid plan field size");
        byte[] bytes = in.readNBytes(length);
        if (bytes.length != length) throw new EOFException("Truncated pending-plan field");
        return new String(bytes, StandardCharsets.UTF_8);
    }
    private static void writeList(DataOutputStream out, List<String> values) throws IOException {
        List<String> list = values == null ? List.of() : values;
        if (list.size() > MAX_ITEMS) throw new IOException("Too many plan items");
        out.writeInt(list.size());
        for (String value : list) write(out, value);
    }
    private static List<String> readList(DataInputStream in) throws IOException {
        int count = in.readInt();
        if (count < 0 || count > MAX_ITEMS) throw new IOException("Invalid plan item count");
        List<String> values = new ArrayList<>();
        for (int i = 0; i < count; i++) values.add(read(in));
        return List.copyOf(values);
    }
}
