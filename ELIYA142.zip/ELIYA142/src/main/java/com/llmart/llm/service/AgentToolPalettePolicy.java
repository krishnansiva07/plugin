package com.llmart.llm.service;

import java.util.LinkedHashSet;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Pattern;

/**
 * Task-specific *advertised* function schemas, not an authorization policy. Every omitted
 * built-in remains available through tool_search and the existing workspace/MCP permission
 * gates. Do not compress user instructions, delete tools from the registry, or narrow a
 * potentially specialized task. This runs locally and consumes no model tokens.
 */
final class AgentToolPalettePolicy {
    private static final Set<String> READ_ONLY = Set.of(
            "inspect_workspace", "list", "glob", "grep", "file_info", "read", "read_many",
            "code_impact", "resource_catalog", "resource_read", "resource_grep",
            "tool_search", "knowledge_search", "knowledge_read",
            "conversation_handoff_read", "conversation_handoff_search", "workspace_status",
            "workspace_diff", "todoread", "ask_user");
    private static final Set<String> CODE = Set.of(
            "inspect_workspace", "list", "glob", "grep", "file_info", "read", "read_many",
            "code_impact", "resource_catalog", "resource_read", "resource_grep",
            "tool_search", "knowledge_search", "knowledge_read",
            "conversation_handoff_read", "conversation_handoff_search",
            "edit", "write", "apply_patch", "build", "test", "check", "bash",
            "workspace_status", "workspace_diff", "workspace_checkpoint", "workspace_rollback",
            "todoread", "todo_update", "ask_user", "verification_failures");
    private static final Set<String> LARGE_CODE = Set.of(
            "work_items_discover", "work_items_init", "work_items_add",
            "work_items_read", "work_items_update");
    private static final Pattern SPECIALIZED = Pattern.compile(
            "(?i)\\b(?:confluence|powerpoint|pptx|slides?|presentation|documentation|" +
            "functional docs?|technical docs?|docs?|mcp|rag|skills?|subagents?|agents?\\.md|" +
            "learning_recall|knowledge base)\\b");
    private static final Pattern CODE_TASK = Pattern.compile(
            "(?i)\\b(?:implement|develop|fix|refactor|debug|enhance|improve|migrate|migration|" +
            "framework|source code|unit tests?|test scripts?|java|selenium|playwright|typescript|" +
            "python|repository|repo|api|application|bug|compile|code|classes|methods)\\b");
    private static final Pattern LARGE_TASK = Pattern.compile(
            "(?i)\\b(?:migrat(?:ion|e)|entire|whole|all modules|all files|end.to.end|" +
            "e2e|codebase|large.scale|multiple modules|framework)\\b");

    private AgentToolPalettePolicy() { }

    static Set<String> select(String objective, boolean readOnly, Set<String> defaultNames) {
        if (defaultNames == null) return Set.of();
        if (!Boolean.parseBoolean(System.getProperty("eliya.tokens.adaptiveTools.enabled", "true")))
            return Set.copyOf(defaultNames);
        String text = objective == null ? "" : objective;
        // Specialized requests keep their existing rich palette (some include mandatory
        // coverage or artifact workflows); don't guess which schema can be removed.
        if (SPECIALIZED.matcher(text).find()) return Set.copyOf(defaultNames);
        Set<String> reduced;
        if (readOnly) {
            LinkedHashSet<String> inspection = new LinkedHashSet<>(READ_ONLY);
            // Read-only Git questions have a deterministic local command path. Do not
            // force a second discovery/model turn just to expose the existing shell tool.
            if (text.toLowerCase(Locale.ROOT).matches("(?s).*\\bgit\\b.*")) inspection.add("bash");
            reduced = inspection;
        } else if (CODE_TASK.matcher(text).find()) {
            LinkedHashSet<String> coding = new LinkedHashSet<>(CODE);
            if (LARGE_TASK.matcher(text).find()) coding.addAll(LARGE_CODE);
            reduced = coding;
        } else return Set.copyOf(defaultNames); // unfamiliar task: preserve capabilities
        LinkedHashSet<String> result = new LinkedHashSet<>(defaultNames);
        result.retainAll(reduced);
        // Always retain on-demand discovery. This is essential for unknown provider,
        // browser, file-format and MCP workflows that surface later in the same task.
        if (defaultNames.contains("tool_search")) result.add("tool_search");
        return Set.copyOf(result);
    }
}
