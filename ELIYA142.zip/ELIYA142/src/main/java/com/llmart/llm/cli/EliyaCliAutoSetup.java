package com.llmart.llm.cli;

import java.io.IOException;
import java.net.URL;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.attribute.PosixFilePermission;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Installs the user-level `eliya` launcher as part of starting the *executable JAR*.
 * No PowerShell scripts, administrator privileges, system PATH changes, or shell execution-policy changes.
 * Windows: HKCU\\Environment\\Path + per-user .cmd; macOS/Linux: ~/.local/bin + shell startup PATH.
 * On managed devices, registry/profile writes may be blocked; start-up and browser launch must still work.
 */
public final class EliyaCliAutoSetup {
    static final String MARKER = "ELIYA AUTO-CLI V128";
    private static final String PROFILE_START = "# >>> ELIYA AUTO-CLI V128 >>>";
    private static final String PROFILE_END = "# <<< ELIYA AUTO-CLI V128 <<<";
    private static final String REGISTRY_KEY = "HKCU\\Environment";
    private static final Pattern REG_PATH = Pattern.compile("(?m)^\\s*Path\\s+(REG_SZ|REG_EXPAND_SZ)\\s+(.*?)\\s*$",
            Pattern.CASE_INSENSITIVE);

    public enum Platform { WINDOWS, MAC, LINUX, UNSUPPORTED }
    public record SetupResult(boolean installed, Path launcher, String message) { }
    record RunResult(int exit, String output) { }
    @FunctionalInterface interface CommandRunner { RunResult run(String... args) throws Exception; }
    private EliyaCliAutoSetup() { }

    /** Called once at application ready, before opening the browser. Never prevents Eliya startup. */
    public static SetupResult onJarStartup(Class<?> applicationClass) {
        if ("false".equalsIgnoreCase(System.getProperty("eliya.cli.auto-install", "true")) ||
                "off".equalsIgnoreCase(System.getenv("ELIYA_CLI_AUTO_SETUP"))) {
            return new SetupResult(false, null, "CLI auto-setup disabled by user configuration");
        }
        Path jar = launchedJar(applicationClass);
        if (jar == null) {
            // Running in IntelliJ or during tests: there is no JAR path to register.
            return new SetupResult(false, null, "CLI auto-setup skipped (not running an executable JAR)");
        }
        Platform platform = detectPlatform(System.getProperty("os.name", ""));
        Path home = Path.of(System.getProperty("user.home", ".")).toAbsolutePath().normalize();
        try {
            return switch (platform) {
                case WINDOWS -> installWindows(jar, home, windowsLocalAppData(home), EliyaCliAutoSetup::runCommand);
                case MAC, LINUX -> installPosix(jar, home, platform, System.getenv("SHELL"));
                case UNSUPPORTED -> new SetupResult(false, null,
                        "Unsupported OS for automatic CLI registration; browser interface remains available");
            };
        } catch (Exception e) {
            return new SetupResult(false, null, "OS denied automatic CLI setup: " + safeMessage(e) +
                    ". Browser startup continues; no security policy was changed.");
        }
    }

    static Platform detectPlatform(String name) {
        String os = name.toLowerCase(Locale.ROOT);
        if (os.startsWith("windows")) return Platform.WINDOWS;
        if (os.contains("mac") || os.contains("darwin")) return Platform.MAC;
        if (os.contains("linux")) return Platform.LINUX;
        return Platform.UNSUPPORTED;
    }

    /** Do not register guessed paths during IDE execution; pin the exact executable JAR. */
    static Path launchedJar(Class<?> type) {
        try {
            URL source = type.getProtectionDomain().getCodeSource().getLocation();
            if (source != null && "file".equalsIgnoreCase(source.getProtocol())) {
                Path path = Path.of(source.toURI()).toAbsolutePath().normalize();
                if (Files.isRegularFile(path) && path.getFileName().toString()
                        .toLowerCase(Locale.ROOT).endsWith(".jar")) return path;
            }
        } catch (Exception ignored) { /* Spring Boot may use a nested-JAR code source. */ }
        // `java -jar <path>` also sets java.class.path to that one executable archive.
        // Never guess a JAR from an IDE/classpath with multiple entries.
        try {
            String classPath = System.getProperty("java.class.path", "");
            if (classPath.contains(System.getProperty("path.separator", ":"))) return null;
            Path candidate = Path.of(classPath).toAbsolutePath().normalize();
            return Files.isRegularFile(candidate) && candidate.getFileName().toString()
                    .toLowerCase(Locale.ROOT).endsWith(".jar") ? candidate : null;
        } catch (Exception ignored) { return null; }
    }

    static Path windowsLocalAppData(Path home) {
        String raw = System.getenv("LOCALAPPDATA");
        return raw == null || raw.isBlank() ? home.resolve("AppData/Local") : Path.of(raw).toAbsolutePath().normalize();
    }

    static SetupResult installWindows(Path jar, Path home, Path localAppData, CommandRunner runner) throws Exception {
        return installWindows(jar, home, localAppData, runner, System.getenv("PATH"));
    }

    static SetupResult installWindows(Path jar, Path home, Path localAppData,
                                      CommandRunner runner, String inheritedPath) throws Exception {
        Path java = javaExecutable(true);
        // The shell that launched the JAR cannot update Explorer/IDE parent process environments.
        // Prefer an existing, per-user PATH directory: this makes `eliya` visible immediately
        // in fresh CMD/PowerShell/IDE terminals, without waiting for a registry broadcast.
        Path alreadyOnPath = findWritableUserPathDirectory(home, localAppData, inheritedPath);
        Path bin = alreadyOnPath == null ? localAppData.resolve("Eliya/bin").toAbsolutePath().normalize() : alreadyOnPath;
        Path launcher = bin.resolve("eliya.cmd");
        try {
            ensureLauncherWritable(launcher);
        } catch (IOException blockedInExistingPath) {
            if (alreadyOnPath == null) throw blockedInExistingPath;
            // WindowsApps may be present on PATH but locked down by enterprise policy.
            // Do not lose all CLI setup just because the fast-path installer is blocked.
            alreadyOnPath = null;
            bin = localAppData.resolve("Eliya/bin").toAbsolutePath().normalize();
            launcher = bin.resolve("eliya.cmd");
            ensureLauncherWritable(launcher);
        }
        String contents = "@echo off\r\nrem " + MARKER + " - created automatically by the running Eliya JAR\r\n" +
                "setlocal DisableDelayedExpansion\r\n" +
                "\"" + cmdEscape(java.toString()) + "\" -jar \"" + cmdEscape(jar.toString()) + "\" --eliya-cli %*\r\n" +
                "exit /b %errorlevel%\r\n";
        try { writeManagedLauncher(launcher, contents, false); }
        catch (IOException blockedExistingPath) {
            if (alreadyOnPath == null) throw blockedExistingPath;
            alreadyOnPath = null;
            bin = localAppData.resolve("Eliya/bin").toAbsolutePath().normalize();
            launcher = bin.resolve("eliya.cmd");
            ensureLauncherWritable(launcher);
            writeManagedLauncher(launcher, contents, false);
        }
        if (alreadyOnPath != null) {
            return new SetupResult(true, launcher,
                    "Eliya CLI installed directly in an existing user PATH directory: " + bin +
                    ". Open any NEW terminal and run `eliya analyse` or `eliya agent`.");
        }
        String registration = registerWindowsPath(bin, runner);
        boolean registered = registration.startsWith("Registered") || registration.startsWith("Already");
        return new SetupResult(registered, launcher,
                registration + "; launcher: " + launcher +
                (registered ? ". Open a NEW terminal; Windows may require sign-out/sign-in to refresh PATH." :
                ". CLI command is NOT registered; use Java -jar <jar> --eliya-cli until IT permits user PATH installation."));
    }

    /** Existing PATH beats a registry edit. Never write to a system, shared or third-party directory.
     * Accept only the user's standard WindowsApps alias location or Eliya's own bin if already on PATH.
     * No enumeration of arbitrary writable PATH entries: a shared writable directory is unsafe.
     */
    static Path findWritableUserPathDirectory(Path home, Path localAppData, String inheritedPath) {
        if (inheritedPath == null || inheritedPath.isBlank()) return null;
        Path trustedWindowsApps = localAppData.toAbsolutePath().normalize().resolve("Microsoft/WindowsApps");
        Path trustedEliya = localAppData.toAbsolutePath().normalize().resolve("Eliya/bin");
        for (String entry : inheritedPath.split(";")) {
            if (entry.isBlank() || entry.contains("%") || entry.contains("\"")) continue;
            try {
                Path candidate = Path.of(entry.strip()).toAbsolutePath().normalize();
                if (!candidate.equals(trustedWindowsApps) && !candidate.equals(trustedEliya)) continue;
                if (!Files.isDirectory(candidate) || !Files.isWritable(candidate) ||
                        Files.isSymbolicLink(candidate)) continue;
                // Respect existing .exe/.com/.bat aliases: Windows PATHEXT can resolve
                // those instead of our .cmd even when the file was installed successfully.
                boolean occupied = false;
                for (String extension : List.of(".exe", ".com", ".bat")) {
                    if (Files.exists(candidate.resolve("eliya" + extension))) { occupied = true; break; }
                }
                if (occupied) continue;
                Path launcher = candidate.resolve("eliya.cmd");
                if (Files.exists(launcher) && !Files.isRegularFile(launcher)) continue;
                if (Files.isRegularFile(launcher) &&
                        !Files.readString(launcher, StandardCharsets.UTF_8).contains(MARKER)) continue;
                return candidate;
            } catch (Exception ignored) { /* try next inherited entry */ }
        }
        return null;
    }

    /** Registry access is user-scoped only; never use setx (PATH truncation) or PowerShell policy bypass. */
    static String registerWindowsPath(Path bin, CommandRunner runner) throws Exception {
        RunResult env = runner.run("reg.exe", "query", REGISTRY_KEY);
        if (env.exit != 0) return "Could not read the Windows user environment (registry permission/policy)";
        RunResult read = runner.run("reg.exe", "query", REGISTRY_KEY, "/v", "Path");
        String current = "";
        String type = "REG_EXPAND_SZ";
        if (read.exit != 0 && REG_PATH.matcher(env.output).find())
            return "Existing Windows PATH could not be read; left unchanged";
        if (read.exit == 0) {
            Matcher match = REG_PATH.matcher(read.output);
            if (!match.find()) return "Windows PATH has an unrecognized registry format; left unchanged";
            type = match.group(1).toUpperCase(Locale.ROOT);
            current = match.group(2).trim();
            if (current.indexOf('\ufffd') >= 0) return "Windows PATH encoding was ambiguous; left unchanged";
        }
        String entry = bin.toString();
        if (Arrays.stream(current.split(";"))
                .map(String::trim).anyMatch(element -> element.replace('/', '\\').replaceAll("[\\\\]+$", "")
                        .equalsIgnoreCase(entry.replace('/', '\\').replaceAll("[\\\\]+$", "")))) {
            return "Already registered Eliya CLI in user PATH";
        }
        String updated = current.isEmpty() ? entry : entry + ";" + current;
        if (updated.length() > 30000 || updated.contains("\r") || updated.contains("\n"))
            return "Windows user PATH is too long or invalid; left unchanged";
        // Preserve existing registry value type and all prior entries. Never touch the system PATH.
        RunResult write = runner.run("reg.exe", "add", REGISTRY_KEY, "/v", "Path", "/t", type,
                "/d", updated, "/f");
        return write.exit == 0 ? "Registered Eliya CLI in Windows user PATH" :
                "Windows user PATH update blocked (permissions/policy)";
    }

    static SetupResult installPosix(Path jar, Path home, Platform platform, String shell) throws IOException {
        return installPosix(jar, home, platform, shell, javaExecutable(false));
    }

    static SetupResult installPosix(Path jar, Path home, Platform platform, String shell, Path java) throws IOException {
        Path bin = home.resolve(".local/bin");
        Path launcher = bin.resolve("eliya");
        ensureLauncherWritable(launcher);
        String contents = "#!/bin/sh\n# " + MARKER + " - created automatically by the running Eliya JAR\n" +
                "exec " + shQuote(java.toString()) + " -jar " + shQuote(jar.toString()) +
                " --eliya-cli \"$@\"\n";
        writeManagedLauncher(launcher, contents, true);

        // Shell profiles must opt the *next* shell into PATH; a running Java process cannot edit its parent shell.
        // Do not create ~/.bash_profile (it can suppress ~/.profile). Only touch known current-user profiles.
        List<String> profiles = new ArrayList<>();
        if (platform == Platform.MAC) {
            profiles.add(".zprofile");
            profiles.add(".zshrc");
            if (shell != null && shell.contains("bash")) {
                profiles.add(".bashrc");
                if (Files.exists(home.resolve(".bash_profile"))) profiles.add(".bash_profile");
            }
        } else {
            profiles.add(".profile");
            profiles.add(".bashrc");
            if (shell != null && shell.contains("zsh")) {
                profiles.add(".zshrc");
                if (Files.exists(home.resolve(".zprofile"))) profiles.add(".zprofile");
            }
        }
        int updated = 0;
        List<String> warnings = new ArrayList<>();
        for (String name : profiles) {
            try { if (installProfileBlock(home.resolve(name))) updated++; }
            catch (IOException e) { warnings.add(name + ": " + safeMessage(e)); }
        }
        if (updated == 0 && !warnings.isEmpty()) return new SetupResult(false, launcher,
                "CLI launcher written, but shell PATH could not be configured: " + String.join("; ", warnings));
        return new SetupResult(true, launcher, "Installed `eliya` in " + launcher +
                " and configured shell PATH for new terminals" +
                (warnings.isEmpty() ? "" : " (profile warnings: " + String.join("; ", warnings) + ")"));
    }

    private static boolean installProfileBlock(Path profile) throws IOException {
        if (Files.isSymbolicLink(profile)) throw new IOException("symlink profile requires manual review");
        String current = Files.exists(profile) ? Files.readString(profile, StandardCharsets.UTF_8) : "";
        if (current.contains(PROFILE_START)) return true;
        String block = PROFILE_START + "\n" +
                "case :\"$PATH\": in *:\"$HOME/.local/bin\":*) ;; *) export PATH=\"$HOME/.local/bin:$PATH\" ;; esac\n" +
                PROFILE_END + "\n";
        Files.writeString(profile, (current.isEmpty() || current.endsWith("\n") ? "" : "\n") + block,
                StandardCharsets.UTF_8, java.nio.file.StandardOpenOption.CREATE, java.nio.file.StandardOpenOption.APPEND);
        return true;
    }

    private static void ensureLauncherWritable(Path launcher) throws IOException {
        if (Files.isSymbolicLink(launcher)) {
            // v125/v126/v127 used a symlink to their source tree. Do not overwrite its target.
            // Replace only a symlink that resolves to the legacy Eliya launcher.
            Path target = Files.readSymbolicLink(launcher);
            Path resolved = launcher.getParent().resolve(target).normalize();
            if (!Files.isRegularFile(resolved) || !Files.readString(resolved).contains("ELIYA JAR not found"))
                throw new IOException("An unrelated launcher already occupies " + launcher);
            return;
        }
        if (Files.exists(launcher) && !Files.readString(launcher, StandardCharsets.UTF_8).contains(MARKER))
            throw new IOException("An unrelated launcher already occupies " + launcher);
        Files.createDirectories(launcher.getParent());
    }

    private static void writeManagedLauncher(Path launcher, String contents, boolean executable) throws IOException {
        if (Files.isRegularFile(launcher) && !Files.isSymbolicLink(launcher) &&
                contents.equals(Files.readString(launcher, StandardCharsets.UTF_8))) return;
        Path tmp = Files.createTempFile(launcher.getParent(), ".eliya-launcher-", ".tmp");
        try {
            Files.writeString(tmp, contents, StandardCharsets.UTF_8);
            if (executable) {
                try { Files.setPosixFilePermissions(tmp, Set.of(PosixFilePermission.OWNER_READ,
                        PosixFilePermission.OWNER_WRITE, PosixFilePermission.OWNER_EXECUTE,
                        PosixFilePermission.GROUP_READ, PosixFilePermission.GROUP_EXECUTE,
                        PosixFilePermission.OTHERS_READ, PosixFilePermission.OTHERS_EXECUTE)); }
                catch (UnsupportedOperationException ignore) { /* non-POSIX FS */ }
            }
            try { Files.move(tmp, launcher, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (AtomicMoveNotSupportedException ex) { Files.move(tmp, launcher, StandardCopyOption.REPLACE_EXISTING); }
        } finally { Files.deleteIfExists(tmp); }
    }

    private static Path javaExecutable(boolean windows) {
        Path java = Path.of(System.getProperty("java.home", ""), "bin", windows ? "java.exe" : "java");
        return java.toAbsolutePath().normalize();
    }

    private static String cmdEscape(String text) {
        // An absolute Java/JAR location is data, not a command. Escape CMD percent expansion.
        return text.replace("%", "%%").replace("\r", "").replace("\n", "");
    }

    private static String shQuote(String text) {
        return "'" + text.replace("'", "'\\''") + "'";
    }

    private static String safeMessage(Exception e) {
        String message = e.getMessage();
        return message == null ? e.getClass().getSimpleName() : message;
    }

    private static RunResult runCommand(String... args) throws Exception {
        Process process = new ProcessBuilder(args).redirectErrorStream(true).start();
        if (!process.waitFor(Duration.ofSeconds(8).toMillis(), TimeUnit.MILLISECONDS)) {
            process.destroyForcibly();
            throw new IOException("Windows registry command timed out");
        }
        String output;
        try (var stdout = process.getInputStream()) {
            output = new String(stdout.readNBytes(65536), Charset.defaultCharset());
        }
        return new RunResult(process.exitValue(), output);
    }
}
