package com.llmart.llm.service;

import java.util.*;
import java.util.regex.Pattern;

/** A compile/check/list command is not evidence that migrated browser tests ran. */
final class AgentMigrationExecutionEvidence {
    private static final Set<String> TEST_TOOLS = Set.of("test", "resource_test");
    private static final Pattern TEST_COMMAND = Pattern.compile(
            "(?is)(?:\\bplaywright\\s+test\\b|\\bcucumber(?:-js)?\\b|\\bnx\\s+(?:run\\s+[^\\s]+:(?:test|e2e)|test\\b|e2e\\b)|" +
            "\\b(?:npm|pnpm|yarn)\\s+(?:run\\s+)?(?:test|e2e)\\b|\\bnpx\\s+vitest\\s+run\\b)");
    private static final Pattern DRY_RUN = Pattern.compile(
            "(?i)(?:--list(?:-tests)?\\b|--dry-run\\b|--help\\b|\\b(?:list|discover)\\s+tests\\b)");
    private static final Pattern NONZERO_EXIT = Pattern.compile("(?i)\\bexitCode\\s*[=:]\\s*(?!0\\b)\\d+");
    private final List<String> passed = new ArrayList<>();
    private final List<String> failed = new ArrayList<>();

    void observe(Map<String,Object> event) {
        if (event == null) return;
        String tool = String.valueOf(event.getOrDefault("tool", "")).toLowerCase(Locale.ROOT);
        String status = String.valueOf(event.getOrDefault("status", "")).toLowerCase(Locale.ROOT);
        if (!("success".equals(status) || "error".equals(status))) return;
        String args = String.valueOf(event.getOrDefault("args", ""));
        String detail = String.valueOf(event.getOrDefault("detail", ""));
        String command = args + " " + detail;
        boolean test = TEST_TOOLS.contains(tool) ||
                (Set.of("bash", "resource_bash", "run_command").contains(tool) && TEST_COMMAND.matcher(command).find());
        if (!test || DRY_RUN.matcher(command).find()) return;
        String output = String.valueOf(event.getOrDefault("output", ""));
        // A tool may report transport success despite the underlying test command failing.
        // A later successful build is not allowed to conceal this failed test execution.
        if (NONZERO_EXIT.matcher(output).find() || NONZERO_EXIT.matcher(detail).find()) status = "error";
        String evidence = tool + ": " + (detail.length() > 180 ? detail.substring(0, 180) : detail);
        if ("success".equals(status)) passed.add(evidence);
        else failed.add(evidence);
    }
    boolean hasPassedFocusedTest() { return !passed.isEmpty(); }
    String report() {
        return "Successful test runs=" + passed.size() + "; failed observed test runs=" + failed.size() +
                (passed.isEmpty() ? "; no focused test execution evidence recorded" : "; last passed: " + passed.get(passed.size()-1));
    }
}
