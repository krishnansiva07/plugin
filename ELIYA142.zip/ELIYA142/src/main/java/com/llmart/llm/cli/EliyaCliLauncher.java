package com.llmart.llm.cli;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.llmart.llm.LlmApplication;
import org.springframework.boot.SpringApplication;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.util.Arrays;
import java.util.Locale;
import java.util.Scanner;

/** CLI launcher for Windows CMD/PowerShell, IntelliJ, VS Code, macOS and Linux terminals.
 * Commands attach to the existing application through its per-process loopback credential.
 * Model credentials live only in the running application's memory, supplied by browser Settings.
 */
public final class EliyaCliLauncher {
    private static final ObjectMapper JSON = new ObjectMapper();
    private static Boolean colorOverride;
    private EliyaCliLauncher() { }
    private static final class Running {
        private final HttpClient client;
        private final URI base;
        private final String token;
        private final String sessionId = java.util.UUID.randomUUID().toString();
        private String workspace;
        private volatile String activeRunId = "";
        Running(HttpClient client, URI base, String token) {
            this.client = client; this.base = base; this.token = token;
        }
        HttpClient client() { return client; }
        URI base() { return base; }
        String token() { return token; }
        String sessionId() { return sessionId; }
    }

    public static void run(String[] argv) {
        String[] rawArgs = Arrays.copyOfRange(argv, 1, argv.length);
        boolean noBrowser = Arrays.asList(rawArgs).contains("--no-browser") ||
                "true".equalsIgnoreCase(System.getenv("ELIYA_NO_BROWSER"));
        boolean noColor = Arrays.asList(rawArgs).contains("--no-color");
        boolean forceColor = Arrays.asList(rawArgs).contains("--color");
        colorOverride = noColor ? Boolean.FALSE : forceColor ? Boolean.TRUE : null;
        String[] args = Arrays.stream(rawArgs)
                .filter(arg -> !"--no-browser".equals(arg) && !"--no-color".equals(arg) && !"--color".equals(arg))
                .toArray(String[]::new);
        boolean browser = !noBrowser;
        if (Arrays.stream(args).anyMatch(arg -> arg.equals("--help") || arg.equals("-h") || arg.equals("help"))) {
            help(); return;
        }
        try {
            String command = args.length == 0 ? "open-project" : args[0].toLowerCase(Locale.ROOT);
            boolean aiCommand = command.equals("analyse") || command.equals("analyze") ||
                    command.equals("agent") || command.equals("implement") || command.equals("check");
            Running running = discover();
            if (running == null) {
                if (aiCommand || command.equals("status") || command.equals("workspace") && args.length == 1) {
                    throw new IllegalStateException("Eliya is not running. Start the JAR first: java -jar eliya.jar");
                }
                String workspace = parseWorkspace(args);
                if (workspace != null) System.setProperty("eliya.startup.workspace", workspace);
                if (!browser) System.setProperty("eliya.browser.enabled", "false");
                System.out.println("Starting Eliya" + (workspace == null ? "" : " for " + workspace) + " …");
                SpringApplication.run(LlmApplication.class);
                return;
            }
            if (aiCommand) {
                // A shell in a project maps that project without changing the working directory.
                // In the user's home/root, keep the previously selected workspace.
                Path project = ProjectDirectoryLocator.fromWorkingDirectory(Path.of(""));
                if (project != null) activate(running, project.toString(), false);
                String mode = command.equals("analyze") || command.equals("check") ? "analyse" : command;
                if (mode.equals("implement")) {
                    if (args.length > 1) throw new IllegalArgumentException("Use `eliya implement` without a prompt; it continues the latest analysis");
                    execute(running, "implement", "");
                } else {
                    chooseMode(running, mode);
                    if (command.equals("check")) {
                        if (args.length > 1) throw new IllegalArgumentException("Use `eliya check` without extra arguments, or `eliya analyse \"check <topic>\"` for a targeted review");
                        execute(running, "analyse", "Check the latest task and its result in this workspace conversation against current source evidence. Report a supported verdict, actual findings and limitations. Do not ask for a new prompt or modify files.");
                    } else if (args.length > 1) execute(running, mode, String.join(" ", Arrays.copyOfRange(args, 1, args.length)));
                    else interactive(running, mode);
                }
                return;
            }
            if (command.equals("cancel") && args.length == 2) {
                checked(request(running, "POST", "/api/cli/session/cancel?sessionId=" + args[1],
                        java.util.Map.of(), Duration.ofSeconds(8)));
                System.out.println("Cancellation request submitted for session " + args[1]);
                return;
            }
            if (command.equals("status") || command.equals("workspace") && args.length == 1) {
                status(running); return;
            }
            String workspace = parseWorkspace(args);
            activate(running, workspace, browser);
        } catch (IllegalArgumentException ex) {
            System.err.println("ELIYA: " + ex.getMessage()); System.exit(2);
        } catch (Exception ex) {
            System.err.println("ELIYA: " + ex.getMessage()); System.exit(1);
        }
    }

    private static void help() {
        System.out.println("ELIYA terminal launcher\n" +
                "  eliya                             Map current project and open browser\n" +
                "  eliya analyse                     Interactive read-only analysis\n" +
                "  eliya analyse \"Review framework\" One-shot analysis\n" +
                "  eliya check                       Verify the latest task in this workspace\n" +
                "  eliya agent                       Interactive execution\n" +
                "  eliya agent \"Add tests\"        One-shot execution\n" +
                "  eliya implement                   Execute last analysis in this workspace\n" +
                "  eliya workspace                   Show current workspace/session\n" +
                "  eliya workspace <path>            Select project workspace\n" +
                "  eliya change workspace <path>     Select project workspace\n" +
                "  eliya status                      Show connection, mode, model readiness\n" +
                "  eliya cancel <session-id>         Cancel a specific active CLI session\n" +
                "  eliya open                        Open browser; keep workspace\n" +
                "  eliya --no-browser                Launch/attach without browser\n" +
                "  eliya analyse --color           Force rich ANSI colors\n" +
                "  eliya analyse --no-color        Readable plain text (also NO_COLOR=1)\n" +
                "Inside interactive mode: check, /analyse, /agent, /implement, /workspace <path>, /status, /help, /exit.\n" +
                "Start the JAR and configure Base URL, API key, and models in browser Settings before AI commands.\n" +
                "Relative paths resolve against the current shell directory. Quote paths with spaces.");
    }

    private static String parseWorkspace(String[] args) {
        if (args.length == 0) {
            Path project = ProjectDirectoryLocator.fromWorkingDirectory(Path.of(""));
            return project == null ? null : project.toString();
        }
        if (args.length == 1 && args[0].equalsIgnoreCase("open")) return null;
        String raw;
        if (args.length == 2 && (args[0].equalsIgnoreCase("workspace") ||
                args[0].equalsIgnoreCase("use") || args[0].equals("--workspace"))) raw = args[1];
        else if (args.length == 3 && args[0].equalsIgnoreCase("change") && args[1].equalsIgnoreCase("workspace")) raw = args[2];
        else throw new IllegalArgumentException("Unknown command. Run `eliya --help` for usage.");
        if (raw.isBlank()) throw new IllegalArgumentException("Workspace path cannot be empty");
        Path path = Path.of(raw).toAbsolutePath().normalize();
        if (!Files.isDirectory(path)) throw new IllegalArgumentException("Workspace directory does not exist: " + path);
        return path.toString();
    }

    private static Running discover() throws Exception {
        Path bridge = EliyaCliBridge.bridgeFile();
        if (!Files.isRegularFile(bridge)) return null;
        var lines = Files.readAllLines(bridge, StandardCharsets.UTF_8);
        if (lines.size() < 2) return null;
        int port;
        try { port = Integer.parseInt(lines.get(0).trim()); }
        catch (NumberFormatException ex) { return null; }
        if (port <= 0 || port > 65535) return null;
        String token = lines.get(1).trim();
        if (!token.matches("[a-f0-9]{64}")) return null;
        var running = new Running(HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(3)).build(),
                URI.create("http://localhost:" + port), token);
        try {
            var response = request(running, "GET", "/api/cli/status", null, Duration.ofSeconds(4));
            if (response.statusCode() == 403) throw new IllegalStateException("Running Eliya rejected this terminal credential");
            if (response.statusCode() == 200) {
                try { running.workspace = JSON.readTree(response.body()).path("selection")
                        .path("project").path("localPath").asText(""); }
                catch (Exception ignored) { }
                return running;
            }
            throw new IllegalStateException("CLI bridge returned HTTP " + response.statusCode());
        } catch (java.net.ConnectException | java.net.http.HttpTimeoutException e) {
            System.err.println("Old Eliya bridge is stale; starting a new process if requested.");
            return null;
        }
    }

    private static HttpResponse<String> request(Running running, String method, String endpoint,
                                                Object payload, Duration timeout) throws Exception {
        HttpRequest.Builder builder = HttpRequest.newBuilder(running.base().resolve(endpoint))
                .timeout(timeout).header("X-Eliya-CLI-Token", running.token())
                .header("X-Eliya-Session", running.sessionId());
        if ("POST".equals(method)) builder.header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(JSON.writeValueAsString(payload)));
        else builder.GET();
        return running.client().send(builder.build(), HttpResponse.BodyHandlers.ofString());
    }

    private static JsonNode checked(HttpResponse<String> response) throws Exception {
        if (response.statusCode() >= 400) {
            String detail = response.body();
            try { detail = JSON.readTree(detail).path("error").asText(detail); }
            catch (Exception ignored) { }
            throw new IllegalStateException("HTTP " + response.statusCode() + ": " + detail);
        }
        return JSON.readTree(response.body());
    }

    private static void activate(Running running, String workspace, boolean browser) throws Exception {
        JsonNode response = checked(request(running, "POST", "/api/cli/activate",
                new EliyaCliBridge.ActivationRequest(workspace, running.sessionId()), Duration.ofSeconds(30)));
        if (browser) EliyaCliBridge.openBrowser(running.base().toString());
        JsonNode project = response.path("selection").path("project");
        String selectedPath = project.path("localPath").asText("");
        if (!selectedPath.isBlank()) running.workspace = selectedPath;
        System.out.println(workspace == null ? "Eliya is already running." :
                "Workspace: " + project.path("localPath").asText(workspace) + " (indexing scheduled)");
    }

    private static void chooseMode(Running running, String mode) throws Exception {
        JsonNode chosen = checked(request(running, "POST", "/api/cli/mode",
                new EliyaCliBridge.ModeRequest(mode, running.workspace, running.sessionId()), Duration.ofSeconds(15)));
        String selectedPath = chosen.path("project").path("localPath").asText("");
        if (!selectedPath.isBlank()) running.workspace = selectedPath;
        EliyaTerminalRenderer.system(colorOverride).banner(mode,
                chosen.path("project").path("localPath").asText("not selected"));
    }

    private static void status(Running running) throws Exception {
        JsonNode result = checked(request(running, "GET", "/api/cli/status", null, Duration.ofSeconds(5)));
        JsonNode selection = result.path("selection");
        System.out.println("Eliya: running at " + result.path("url").asText());
        System.out.println("Workspace: " + selection.path("project").path("localPath").asText("none"));
        System.out.println("Mode: " + selection.path("mode").asText("analyse"));
        System.out.println("Model configured in browser: " + result.path("modelConfigured").asBoolean());
        System.out.println("Independent CLI session: " + running.sessionId());
    }

    private static void interactive(Running running, String initialMode) throws Exception {
        if (System.console() == null && System.in.available() == 0) {
            // IDE terminals normally expose stdin even when System.console() is null;
            // do not block if invoked from a non-interactive script without stdin.
            // Scripts should use one-shot quoted prompts instead.
        }
        Scanner input = new Scanner(System.in, StandardCharsets.UTF_8);
        String mode = initialMode;
        System.out.println("Describe a task or type check to verify the last result. /agent or /analyse switches, /exit quits. Ctrl+C cancels an active run.");
        while (true) {
            EliyaTerminalRenderer.system(colorOverride).prompt(mode);
            if (!input.hasNextLine()) return;
            String line = input.nextLine().strip();
            if (line.isBlank()) continue;
            if (line.equalsIgnoreCase("/exit") || line.equalsIgnoreCase("/quit")) return;
            try {
                if (line.equalsIgnoreCase("/help")) { help(); continue; }
                if (line.equalsIgnoreCase("/status")) { status(running); continue; }
                if (line.equalsIgnoreCase("/cancel") || line.equalsIgnoreCase("/stop")) {
                    cancel(running); continue;
                }
                if (line.equalsIgnoreCase("/analyse") || line.equalsIgnoreCase("/analyze") || line.equalsIgnoreCase("/agent")) {
                    mode = line.equalsIgnoreCase("/agent") ? "agent" : "analyse";
                    chooseMode(running, mode); continue;
                }
                if (line.equalsIgnoreCase("/implement")) {
                    chooseMode(running, "agent"); mode = "agent";
                    execute(running, "implement", "", input); continue;
                }
                if (line.startsWith("/workspace ")) {
                    String path = line.substring("/workspace ".length()).strip();
                    if (path.length() > 1 && path.startsWith("\"") && path.endsWith("\""))
                        path = path.substring(1, path.length() - 1);
                    Path folder = Path.of(path).toAbsolutePath().normalize();
                    if (!Files.isDirectory(folder)) throw new IllegalArgumentException("Directory does not exist: " + folder);
                    activate(running, folder.toString(), false);
                    chooseMode(running, mode); continue;
                }
                execute(running, mode, line, input);
            } catch (Exception error) {
                System.err.println("ELIYA: " + error.getMessage());
            }
        }
    }

    private static void execute(Running running, String mode, String prompt) throws Exception {
        execute(running, mode, prompt, new Scanner(System.in, StandardCharsets.UTF_8));
    }

    private static void execute(Running running, String mode, String prompt, Scanner input) throws Exception {
        final boolean[] complete = {false};
        Thread cancelHook = new Thread(() -> {
            if (!complete[0]) {
                try { cancel(running); } catch (Exception ignored) { }
            }
        }, "eliya-cli-cancel-on-interrupt");
        Runtime.getRuntime().addShutdownHook(cancelHook);
        try { executeStream(running, mode, prompt, input); }
        finally {
            complete[0] = true;
            try { Runtime.getRuntime().removeShutdownHook(cancelHook); }
            catch (IllegalStateException ignored) { /* JVM shutdown is already cancelling the run */ }
        }
    }

    private static void executeStream(Running running, String mode, String prompt, Scanner input) throws Exception {
        HttpRequest req = HttpRequest.newBuilder(running.base().resolve("/api/cli/run"))
                .header("X-Eliya-CLI-Token", running.token())
                .header("X-Eliya-Session", running.sessionId())
                .header("Content-Type", "application/json")
                .header("Accept", "text/event-stream")
                .POST(HttpRequest.BodyPublishers.ofString(JSON.writeValueAsString(
                        new EliyaCliBridge.TerminalPrompt(mode, prompt, running.workspace, running.sessionId())))).build();
        HttpResponse<InputStream> response = running.client().send(req, HttpResponse.BodyHandlers.ofInputStream());
        if (response.statusCode() >= 400) {
            try (InputStream stream = response.body()) {
                String error = new String(stream.readAllBytes(), StandardCharsets.UTF_8);
                try {
                    JsonNode parsed = JSON.readTree(error);
                    error = parsed.path("detail").asText(parsed.path("message").asText(
                            parsed.path("error").asText(error)));
                } catch (Exception ignored) { }
                throw new IllegalStateException("HTTP " + response.statusCode() + ": " + error);
            }
        }
        boolean gotDone = false;
        boolean gotText = false;
        boolean successful = true;
        String lastRunId = "";
        StringBuilder streamedAnswer = new StringBuilder();
        EliyaTerminalRenderer renderer = EliyaTerminalRenderer.system(colorOverride);
        String event = "message";
        StringBuilder data = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(response.body(), StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.isEmpty()) {
                    if (!data.isEmpty()) {
                        JsonNode item;
                        try { item = JSON.readTree(data.toString()); }
                        catch (Exception ignored) { item = JSON.getNodeFactory().textNode(data.toString()); }
                        switch (event) {
                            case "token" -> {
                                String text = item.path("text").asText("");
                                if (!text.isEmpty()) { renderer.text(text); streamedAnswer.append(text); gotText = true; }
                            }
                            case "meta" -> {
                                if (item.hasNonNull("agentRunId")) {
                                    lastRunId = item.path("agentRunId").asText();
                                    running.activeRunId = lastRunId;
                                    renderer.activity("Agent", "running", "Run: " + lastRunId);
                                }
                            }
                            case "agent_step" -> {
                                String activity = item.path("detail").asText(item.path("message").asText(""));
                                if (activity.isBlank()) activity = item.path("type").asText("");
                                String tool = item.path("tool").asText("Agent");
                                String step = item.path("step").asText("");
                                String description = step.isBlank() ? activity : step + ": " + activity;
                                renderer.activity(tool, item.path("status").asText("running"), description);
                                String approvalId = item.path("approvalId").asText("");
                                if (!approvalId.isBlank() && !lastRunId.isBlank())
                                    handleApproval(running, input, renderer, lastRunId, approvalId, description,
                                            !"file_deletion".equals(item.path("approvalType").asText("")));
                            }
                            case "agent_question" -> {
                                if (!lastRunId.isBlank()) handleQuestion(running, input, renderer, lastRunId, item);
                            }
                            case "agent_changes" -> renderer.activity("Files", "success",
                                    "Changed files: " + item.path("count").asText("see browser report"));
                            case "chat_status" -> {
                                if (!gotText) {
                                    String detail = item.path("detail").asText("");
                                    renderer.activity("Analyse", item.path("phase").asText("running"), detail);
                                }
                            }
                            case "error" -> {
                                renderer.error(item.path("message").asText("AI execution failed"));
                                throw new IllegalStateException("AI execution failed. See error above.");
                            }
                            case "stopped" -> {
                                renderer.error(item.path("message").asText("Run stopped without completing"));
                                throw new IllegalStateException("Run stopped without completing");
                            }
                            case "done" -> {
                                String finalAnswer = item.path("content").asText("");
                                if (!gotText) renderer.text(finalAnswer);
                                else if (!finalAnswer.isBlank() && !finalAnswer.equals(streamedAnswer.toString()) &&
                                        finalAnswer.startsWith(streamedAnswer.toString()))
                                    renderer.text(finalAnswer.substring(streamedAnswer.length()));
                                gotDone = true;
                                if ("agent".equals(mode) || "implement".equals(mode)) {
                                    JsonNode result = checked(request(running, "GET",
                                            "/api/cli/session/result?sessionId=" + running.sessionId(), null, Duration.ofSeconds(8)));
                                    String status = result.path("status").asText("unknown");
                                    successful = "completed".equals(status);
                                    reportExecution(renderer, result);
                                    if (!successful) renderer.error("Agent outcome: " + status +
                                            ". Do not treat this task as successfully completed.");
                                }
                                renderer.completion(successful);
                            }
                            default -> { }
                        }
                    }
                    event = "message"; data.setLength(0);
                } else if (line.startsWith("event:")) event = line.substring(6).strip();
                else if (line.startsWith("data:")) {
                    if (!data.isEmpty()) data.append('\n');
                    data.append(line.substring(5).stripLeading());
                }
            }
            // A truncated SSE response must not hide a partially received Markdown line.
            if (!gotDone) renderer.endResponse();
        } finally {
            renderer.endResponse();
        }
        try { request(running, "POST", "/api/cli/refresh", java.util.Map.of(), Duration.ofSeconds(5)); }
        catch (Exception ignored) { /* completion is durable even if browser refresh fails */ }
        running.activeRunId = "";
        if (!gotDone) throw new IllegalStateException("Stream ended without a completion event. Check the conversation and run status in Eliya.");
        if (!successful) throw new IllegalStateException("Agent completion verification failed; see the reported run status.");
    }    private static void cancel(Running running) throws Exception {
        JsonNode reply = checked(request(running, "POST",
                "/api/cli/session/cancel?sessionId=" + running.sessionId(), java.util.Map.of(), Duration.ofSeconds(8)));
        System.out.println(reply.path("cancellationRequested").asBoolean()
                ? "Cancellation requested for this terminal session."
                : "No active Agent or Analyse execution found in this terminal session.");
    }

    private static void handleApproval(Running running, Scanner input, EliyaTerminalRenderer renderer,
                                       String runId, String approvalId, String description, boolean allowRun) throws Exception {
        renderer.activity("Approval", "warning", description);
        System.out.print("Approve this specific action? [yes/no" + (allowRun ? "/run" : "") + "] (default no): ");
        String response = input.hasNextLine() ? input.nextLine().strip().toLowerCase(Locale.ROOT) : "no";
        String decision = response.equals("yes") || response.equals("y") ? "once" :
                allowRun && response.equals("run") ? "run" : "deny";
        checked(request(running, "POST", "/api/cli/session/approval?sessionId=" + running.sessionId(),
                new EliyaCliBridge.ApprovalDecision(runId, approvalId, decision), Duration.ofSeconds(8)));
        renderer.activity("Approval", "success", "Decision recorded: " + decision);
    }

    private static void handleQuestion(Running running, Scanner input, EliyaTerminalRenderer renderer,
                                       String runId, JsonNode question) throws Exception {
        String id = question.path("id").asText("");
        if (id.isBlank()) return;
        renderer.activity("Question", "warning", question.path("reason").asText("Agent requires clarification"));
        JsonNode choices = question.path("choices");
        if (choices.isArray()) {
            StringBuilder options = new StringBuilder();
            for (JsonNode choice : choices) {
                if (!options.isEmpty()) options.append(" / ");
                options.append(choice.asText());
            }
            System.out.println("Choices: " + options);
        }
        System.out.print("Your answer (empty = Cancel): ");
        String response = input.hasNextLine() ? input.nextLine().strip() : "Cancel";
        if (response.isEmpty()) response = "Cancel";
        String choice = "Custom";
        String detail = response;
        if (choices.isArray()) for (JsonNode option : choices)
            if (option.asText().equalsIgnoreCase(response)) { choice = option.asText(); detail = ""; break; }
        checked(request(running, "POST", "/api/cli/session/question?sessionId=" + running.sessionId(),
                new EliyaCliBridge.QuestionAnswer(runId, id, choice, detail), Duration.ofSeconds(8)));
        renderer.activity("Question", "success", "Clarification submitted");
    }

    /** Print measured server timings, never fabricated benchmark numbers. */
    private static void reportExecution(EliyaTerminalRenderer renderer, JsonNode result) {
        String runId = result.path("id").asText("");
        JsonNode usage = result.path("tokenUsage");
        if (runId.isBlank() || usage.isMissingNode()) {
            renderer.activity("Metrics", "warning", "No authoritative Agent run metrics were available");
            return;
        }
        renderer.activity("Verification", result.path("status").asText("unknown"),
                "Status: " + result.path("status").asText("unknown") +
                " | " + result.path("lastVerification").asText("No verification recorded"));
        renderer.activity("Timing", "info", "Total elapsed: " + usage.path("elapsedMs").asLong() + " ms");
        JsonNode stages = usage.path("stageTimeMs");
        if (stages.isObject()) stages.fields().forEachRemaining(stage ->
                renderer.activity("Timing", "info", stage.getKey() + ": " + stage.getValue().asLong() + " ms"));
        renderer.activity("Tokens", "info", "Provider input " + usage.path("providerInputTokens").asLong() +
                ", output " + usage.path("providerOutputTokens").asLong() +
                " (" + usage.path("usageStatus").asText("not_reported") + ")");
    }


}
