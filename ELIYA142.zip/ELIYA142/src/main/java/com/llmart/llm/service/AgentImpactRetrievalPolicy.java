package com.llmart.llm.service;

import java.util.regex.Pattern;

/** Avoid redundant dependency-impact retrieval for simple factual inspections only. */
final class AgentImpactRetrievalPolicy {
    private static final Pattern NEEDS_IMPACT = Pattern.compile(
            "(?i)\\b(?:impact|dependency|dependencies|affected|callers|calls|references|downstream|" +
            "upstream|flow|trace|architecture|entry.point|design|sequence|lifecycle|integration)\\b");
    private AgentImpactRetrievalPolicy() { }

    static boolean needsImpactReport(String objective, String query) {
        if (!AgentConversationIntent.isFastReadOnly(objective) ||
                AgentResultPresentation.isDeepAnalysis(objective)) return true;
        String request = objective == null ? "" : objective.strip();
        if (request.matches("(?is)^(?:how|why)\\b.*")) return true;
        return NEEDS_IMPACT.matcher(request + " " + (query == null ? "" : query)).find();
    }
}
