package com.llmart.llm.service;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;

/** Bounded, thread-safe task timing; no prompt, API credential or file contents are stored. */
final class AgentStageMetrics {
    private static final Set<String> STAGES = Set.of(
            "workspace", "planning", "retrieval", "tools", "verification", "answer", "finalization");
    private final ConcurrentHashMap<String, AtomicLong> milliseconds = new ConcurrentHashMap<>();

    void record(String stage, long elapsedMs) {
        if (!STAGES.contains(stage) || elapsedMs < 0) return;
        milliseconds.computeIfAbsent(stage, ignored -> new AtomicLong()).addAndGet(elapsedMs);
    }

    Map<String, Long> snapshot() {
        Map<String, Long> result = new LinkedHashMap<>();
        for (String stage : new String[]{"workspace", "planning", "retrieval", "tools", "verification", "answer", "finalization"})
            result.put(stage, milliseconds.getOrDefault(stage, new AtomicLong()).get());
        return result;
    }

    void store(Properties p) {
        snapshot().forEach((stage, time) -> p.setProperty("stageTimeMs." + stage, Long.toString(time)));
    }

    void restore(Properties p) {
        for (String stage : STAGES) {
            try { record(stage, Long.parseLong(p.getProperty("stageTimeMs." + stage, "0"))); }
            catch (NumberFormatException ignored) { /* Legacy run state remains readable. */ }
        }
    }
}
