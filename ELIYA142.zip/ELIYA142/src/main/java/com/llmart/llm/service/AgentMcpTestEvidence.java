package com.llmart.llm.service;

import java.util.Map;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Fail-closed proof for exact-tag tests requested through an MCP-assisted debug flow. */
final class AgentMcpTestEvidence {
    private static final Pattern TEST_TAG = Pattern.compile("(?i)\\b(?:test(?:\\s+case)?|scenario|tag)\\s*[:#]?\\s*(@[a-z0-9_-]+)\\b");
    private static final Pattern PASS_REPORT = Pattern.compile("\\b(?:[1-9]\\d*\\s+(?i:passed)|PASS|PASSED)\\b");
    private static final Pattern TEST_RUN_COMMAND = Pattern.compile("(?i)(?:\\bplaywright\\s+test\\b|\\bnx\\s+(?:test|run\\s+\\S+:test)\\b|\\b(?:npm|yarn|pnpm)\\s+(?:run\\s+)?test\\b|\\b(?:mvn|gradle)\\s+test\\b|\\bcucumber\\b|\\b(?:jest|vitest)\\b)");
    private final String tag;
    private boolean successfulRerun;
    private String lastFailure = "";

    AgentMcpTestEvidence(String objective) {
        if (objective == null || !McpPromptGate.explicitlyRequested(objective) ||
                !Pattern.compile("(?i)\\b(?:run|rerun|execute|fix|repair|debug)\\b").matcher(objective).find()) {
            tag = "";
            return;
        }
        Matcher m = TEST_TAG.matcher(objective);
        tag = m.find() ? m.group(1) : "";
    }

    boolean applicable() { return !tag.isEmpty(); }
    String tag() { return tag; }
    boolean verified() { return !applicable() || successfulRerun; }

    String instructions() {
        if (!applicable()) return "";
        return "[EXACT MCP TEST CONTRACT] Requested test identifier: " + tag + "\\n" +
                "1. Discover the ACTUAL test source and the configured test runner; read the exact test and Search/Select step before editing. " +
                "Determine whether the @-prefixed identifier is a tag, ID or title from real source; it is not an ELIYA resource alias.\\n" +
                "2. Use the configured MCP tool to reproduce/inspect the real browser state (snapshot, trace, console, locator candidates); " +
                "a browser navigation or click is NOT itself proof that the test runner passed.\\n" +
                "3. Fix only from observed selector/DOM/timing evidence; avoid guessed XPath, arbitrary sleeps, invented UI text or repeated identical failing actions.\\n" +
                "4. Execute the exact tagged test through its project runner or a genuine MCP test-runner tool. " +
                "Use configured Chrome/Edge where required. Capture actual exit/status, failed step, and result.\\n" +
                "5. If execution is unavailable, report BLOCKED/UNVERIFIED, not PASSED or FIXED. " +
                "Do not mark a plan complete from MCP tool connectivity alone.\\n";
    }

    void observe(Map<String,Object> event) {
        if (!applicable() || event == null) return;
        String status = String.valueOf(event.getOrDefault("status", ""));
        if (!status.equals("success") && !status.equals("error")) return;
        String tool = String.valueOf(event.getOrDefault("tool", "")).toLowerCase(Locale.ROOT);
        boolean localRunner = tool.equals("test") || tool.equals("resource_test") || tool.equals("bash") || tool.equals("resource_bash");
        boolean mcpRunner = tool.startsWith("mcp__") && (
                tool.matches(".*(?:run|execute).*(?:test|spec).*") ||
                tool.matches(".*(?:test|spec).*(?:run|execute).*"));
        if (!localRunner && !mcpRunner) return;
        String args = String.valueOf(event.getOrDefault("args", ""));
        if ((tool.equals("bash") || tool.equals("resource_bash")) && !TEST_RUN_COMMAND.matcher(args).find()) return;
        String output = String.valueOf(event.getOrDefault("output", ""));
        Pattern exactTag = Pattern.compile("(?i)(?<![a-z0-9_-])" + Pattern.quote(tag) + "(?![a-z0-9_-])");
        if (!exactTag.matcher(args).find() && !exactTag.matcher(output).find()) return;
        boolean passed = status.equals("success") && !McpToolOutcomePolicy.failed(tool, output) &&
                PASS_REPORT.matcher(output).find() &&
                (!localRunner || output.startsWith("exitCode=0;"));
        if (passed && !output.matches("(?is).*\\b(?:no tests found|0 tests? (?:run|executed|passed)|0 passed)\\b.*")) {
            successfulRerun = true;
            lastFailure = "";
        } else {
            successfulRerun = false;
            lastFailure = "Exact tagged test " + tag + " was not verified as passing (tool " + tool + ", status " + status + ")";
        }
    }

    String failureSummary() {
        return "Test " + tag + " has no successful recorded exact-tag runner execution. " +
                (lastFailure.isBlank() ? "A browser MCP action, source edit, or model claim is not a passing test result." : lastFailure);
    }
}
