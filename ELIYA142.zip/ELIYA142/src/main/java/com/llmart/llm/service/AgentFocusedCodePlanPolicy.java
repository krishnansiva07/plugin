package com.llmart.llm.service;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** No-LLM planner only for unambiguous *single source-file* edits. */
final class AgentFocusedCodePlanPolicy {
    private static final Pattern FILE = Pattern.compile(
            "(?i)(?<![\\w.-])(?:[\\w.-]+[/\\\\])*[\\w.-]+\\.(?:java|kt|ts|tsx|js|jsx|py|go|cs)(?![\\w.-])");
    private static final Pattern CHANGE = Pattern.compile(
            "(?i)\\b(?:fix|correct|modify|update|change|patch|refactor)\\b");
    private static final Pattern BROAD = Pattern.compile(
            "(?i)\\b(?:migrat(?:e|ion)|all|every|entire|whole|multi[- ]?module|" +
            "cross[- ]?file|framework|architecture|end[- ]to[- ]end|e2e|" +
            "deep analysis|security audit|compare|integration|mcp|confluence|generate)\\b");
    private AgentFocusedCodePlanPolicy() { }

    static List<String> plan(String objective, boolean hasAttachments) {
        if (!Boolean.parseBoolean(System.getProperty("eliya.tokens.focusedCodePlan.enabled", "true")) ||
                hasAttachments || objective == null || objective.length() > 1800 ||
                !CHANGE.matcher(objective).find() || BROAD.matcher(objective).find()) return List.of();
        Matcher matcher = FILE.matcher(objective);
        List<String> names = new ArrayList<>();
        while (matcher.find()) {
            String name = matcher.group().replace('\\', '/');
            if (!names.contains(name)) names.add(name);
            if (names.size() > 1) return List.of();
        }
        if (names.size() != 1) return List.of();
        String file = names.get(0);
        return List.of(
                "Read the actual current " + file + " and any directly necessary adjacent code. " +
                "Apply only the user-requested targeted fix. Preserve unrelated behavior, live path permissions, " +
                "and project conventions; record actual changed files.",
                "Verify the fix with the smallest appropriate build/test/check or focused diagnostic, " +
                "inspect the resulting diff and report any unverified requirements. " +
                "Do not claim completion when verification fails.");
    }
}
