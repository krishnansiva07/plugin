package com.llmart.llm.service;

import com.llmart.llm.dto.ProjectPatchRequest;
import java.util.List;
import java.util.Map;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** A grounded conversational completion is part of the deliverable, not a tool-status label.
 * No new model call or fabricated action is required. The next step is explicit and resumable.
 */
final class AgentCompletionNarrator {
    private static final Pattern SUGGESTION = Pattern.compile(
            "(?m)^\\*\\*Suggested next step:\\*\\*\\s+(.{8,220})\\s*$");
    private static final Pattern ACCEPT = Pattern.compile(
            "(?is)^(?:yes|yes please|sure|ok|okay|go ahead|proceed|do it|please do|sounds good)" +
            "(?:[,.! ]+(?:and|also|but|only|except|please)\\s+(.{1,400}))?[.! ]*$");
    private AgentCompletionNarrator() { }

    static String suggestedAction(String answer) {
        if (answer == null) return "";
        Matcher m = SUGGESTION.matcher(answer);
        return m.find() ? m.group(1).strip() : "";
    }

    static String acceptedNextInstruction(String userReply, String assistantAnswer) {
        String suggestion = suggestedAction(assistantAnswer);
        if (suggestion.isBlank() || userReply == null) return "";
        Matcher accepted = ACCEPT.matcher(userReply.strip());
        if (!accepted.matches()) return "";
        String addition = accepted.group(1) == null ? "" : accepted.group(1).strip();
        return "Continue the SAME completed task in the currently mapped workspace. " +
               "The user explicitly accepted this exact suggested follow-up: " + suggestion + ". " +
               "Carry out only this action, inspect the current workspace first, run relevant verification, " +
               "and explain the actual result and files changed. " +
               (addition.isBlank() ? "" : "User's additional constraint: " + addition + ". ") +
               "Do not repeat or overwrite the previously completed task unnecessarily.";
    }

    static String complete(String prior, String objective,
                           List<ProjectPatchRequest.ProjectPatchFile> changes,
                           int totalChanged, String verification, boolean verified,
                           String status) {
        return complete(prior, objective, changes, totalChanged, verification, verified, status, List.of());
    }

    static String complete(String prior, String objective,
                           List<ProjectPatchRequest.ProjectPatchFile> changes,
                           int totalChanged, String verification, boolean verified,
                           String status, List<Map<String,Object>> plan) {
        if (!"completed".equals(status)) {
            String explanation = prior == null ? "" : prior.strip();
            String state = status == null ? "unknown" : status;
            if (explanation.startsWith("## Outcome:")) return explanation;
            if (!explanation.isBlank() && !explanation.matches("(?is)^(?:task completed|agent run completed|done[.!]?|completed successfully)[.! ]*$"))
                return explanation; // Preserve informative failure details and existing contract.
            return "## Outcome: " + state + " — not verified complete\n\n" +
                    (explanation.isBlank() ? "I couldn't produce a verified result from the available execution evidence." : explanation) +
                    "\n\n**Verification:** " + (verification == null || verification.isBlank()
                    ? "No successful final verification was recorded."
                    : safeLine(verification, 350));
        }
        String answer = prior == null ? "" : prior.strip().replaceAll(
                "(?is)\\s*Do you want to add anything\\?\\s*$", "");
        List<ProjectPatchRequest.ProjectPatchFile> files = changes == null ? List.of() : changes;
        boolean wrote = totalChanged > 0;
        boolean meaningful = AgentResultPresentation.hasSubstantiveAnswer(answer);
        StringBuilder result = new StringBuilder();
        if (wrote) {
            if (meaningful) result.append(answer).append("\n\n---\n\n");
            result.append("### What I completed\n\n");
            result.append("I made ").append(totalChanged).append(totalChanged == 1 ? " tracked workspace file change" : " tracked workspace file changes");
            String task = oneLineObjective(objective);
            if (!task.isBlank()) result.append(" for your request: ").append(task);
            result.append(".\n\n");
            if (plan != null && !plan.isEmpty()) {
                List<String> completedSteps = plan.stream().filter(row -> "completed".equals(row.get("status")))
                    .map(row -> safeLine(String.valueOf(row.getOrDefault("text", "")), 175))
                    .filter(text -> !text.isBlank()).limit(5).toList();
                if (!completedSteps.isEmpty()) {
                    result.append("**Completed work**\n\n");
                    for (String item : completedSteps) result.append("- ").append(item).append("\n");
                    result.append("\n");
                }
            }
            if (!files.isEmpty()) {
                result.append("**Files created or changed**\n\n");
                for (int i=0; i<Math.min(files.size(), 30); i++) {
                    ProjectPatchRequest.ProjectPatchFile f = files.get(i);
                    if (f == null || f.path() == null) continue;
                    String action = "delete".equalsIgnoreCase(f.operation()) ? "Deleted" :
                        Hashing.ABSENT.equals(f.baselineHash()) ? "Created" : "Updated";
                    result.append("- ").append(action).append(" `")
                          .append(f.path().replace("`", "")).append("`\n");
                }
                if (totalChanged > Math.min(files.size(), 30)) result.append("- Plus ")
                    .append(totalChanged - Math.min(files.size(), 30)).append(" other tracked change(s)\n");
                result.append("\n");
            } else result.append("The file-change inventory could not be loaded; inspect the detailed execution report for paths.\n\n");
        } else {
            if (meaningful) result.append(answer).append("\n\n");
            else if (!answer.isBlank()) result.append(answer).append("\n\n");
            // Don't claim that implementation happened when no actual change was observed.
            if (!meaningful) result.append("**Files:** No tracked local workspace changes were recorded.\n\n");
            if (verification != null && !verification.isBlank()) result.append("**Verification evidence:** ")
                    .append(safeLine(verification, 350)).append("\n\n");
            // Read-only analysis is itself a deliverable. Preserve the full explanation and
            // offer only a recommendation explicitly present in that explanation.
            if (meaningful && AgentAnalysisOutcome.isAnalysis(objective)) {
                String proposed = AgentAnalysisOutcome.recommendedAction(objective, answer);
                if (!proposed.isBlank()) result.append("**Suggested next step:** ").append(proposed);
            }
        }
        if (wrote) {
            result.append("**Verification:** ");
            if (verified) result.append("The latest workspace revision passed the recorded check");
            else result.append("No successful verification of the latest workspace revision was recorded");
            if (verification != null && !verification.isBlank()) result.append(" — ").append(safeLine(verification, 280));
            result.append(".\n\n");
        }
        // The run ends after its actual result. The model's specific proposal (if any)
        // remains in the substantive answer; never append an inferred stock question.
        return result.toString().strip();
    }

    private static String safeLine(String value, int length) {
        String safe = value.replace('\n', ' ').replace('\r', ' ').replace('`', '\'').strip();
        return safe.length() <= length ? safe : safe.substring(0, length) + "…";
    }
    private static String oneLineObjective(String value) {
        if (value == null) return "";
        String first = value.split("[\\r\\n]", 2)[0].replace('`','\'').strip();
        if (first.length() > 170) first = first.substring(0, 167) + "…";
        return first;
    }
}
