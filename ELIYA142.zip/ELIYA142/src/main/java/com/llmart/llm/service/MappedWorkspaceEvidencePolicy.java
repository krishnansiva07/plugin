package com.llmart.llm.service;

import java.util.Locale;

/**
 * Cheap, pure routing for a selected project that needs workspace evidence without
 * asking the user to repeat the words "workspace", "repo" or "project".
 * Called only when a selected workspace is already mapped. MCP access is NOT implied.
 */
final class MappedWorkspaceEvidencePolicy {
    private MappedWorkspaceEvidencePolicy() { }

    static boolean shouldRetrieve(String prompt) {
        if (prompt == null || prompt.isBlank()) return false;
        String low = prompt.toLowerCase(Locale.ROOT);
        boolean externalComparison = low.matches("(?s).*(?:jira|confluence|mcp|issue|story|ticket|acceptance criteria).*") &&
                low.matches("(?s).*(?:compare|match|gap|coverage|against|html report|report|traceability|implemented|missing).*");
        boolean currentImplementation = low.matches("(?s).*(?:analy[sz]e|review|inspect|compare|validate|verify|check|identify|find).*") &&
                low.matches("(?s).*(?:what (?:we|have)|what is (?:done|missing)|feature|functionality|implementation|test cases|tests|scenarios|coverage|requirements).*");
        // A natural verification question often omits "workspace": "Can you check migration
        // completed successfully?" must inspect the selected project, not provide a promise.
        boolean migrationAudit = low.matches("(?s).*(?:migrat(?:ion|ed|e)|playwright|selenium|cucumber).*\\b(?:complete|completed|successfully|successful|coverage|correct|verify|verified|validate|check|passed|gap|missing|ready)\\b.*") ||
                low.matches("(?s).*(?:verify|validate|check|confirm|audit|assess).*\\b(?:migrat(?:ion|ed|e)|framework|coverage|regression|tests?|scenarios?)\\b.*");
        return externalComparison || currentImplementation || migrationAudit;
    }
}
