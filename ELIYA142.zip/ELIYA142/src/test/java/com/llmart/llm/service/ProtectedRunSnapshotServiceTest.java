package com.llmart.llm.service;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.charset.StandardCharsets;
import java.util.Map;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class ProtectedRunSnapshotServiceTest {
    @TempDir Path tmp;

    private AgentWorkspaceService.Workspace workspace(Path root) {
        AgentWorkspaceService.Workspace ws = mock(AgentWorkspaceService.Workspace.class);
        when(ws.root()).thenReturn(root);
        when(ws.resources()).thenReturn(Map.of());
        return ws;
    }

    @Test void rollbackRestoresBinaryTextAndRemovesNewFilesAfterTimeout() throws Exception {
        Path root = tmp.resolve("project"); Files.createDirectories(root.resolve("src"));
        Path existing = root.resolve("src/test.java");
        Path binary = root.resolve("screenshots/image.bin"); Files.createDirectories(binary.getParent());
        byte[] original = {0, 127, -1, 10, 0};
        Files.writeString(existing, "original test", StandardCharsets.UTF_8); Files.write(binary, original);
        ProtectedRunSnapshotService service = new ProtectedRunSnapshotService(tmp.resolve("snapshots"));
        service.begin("run1", workspace(root));
        Files.writeString(existing, "modified test"); Files.delete(binary);
        Files.createDirectories(root.resolve("generated/nested"));
        Files.writeString(root.resolve("generated/nested/new.txt"), "new");
        String status = service.rollback("run1");
        assertTrue(status.contains("Rollback completed"));
        assertEquals("original test", Files.readString(existing));
        assertArrayEquals(original, Files.readAllBytes(binary));
        assertFalse(Files.exists(root.resolve("generated")));
        assertFalse(Files.exists(tmp.resolve("snapshots/run1")));
    }

    @Test void largeWorkspaceSkipsGeneratedBuildDirectoriesAndProtectsSourceFiles() throws Exception {
        Path root = Files.createDirectories(tmp.resolve("monorepo"));
        Path source = root.resolve("Migration Prompts/prompt-1.md");
        Files.createDirectories(source.getParent());
        Files.writeString(source, "original");
        for (String generated : java.util.List.of(".nx", "playwright-report", "test-results", "allure-results", "__pycache__")) {
            Path output = Files.createDirectories(root.resolve(generated));
            Files.writeString(output.resolve("large-build-output.bin"), "do not snapshot");
        }
        ProtectedRunSnapshotService service = new ProtectedRunSnapshotService(tmp.resolve("snapshots"));
        String outcome = service.begin("generated", workspace(root));
        assertTrue(outcome.contains("files=1"));
        Files.writeString(source, "updated");
        service.rollback("generated");
        assertEquals("original", Files.readString(source));
    }

    @Test void concurrentCopyCompletesAndCanRollbackManyFiles() throws Exception {
        Path root = Files.createDirectories(tmp.resolve("large-workspace"));
        for (int i = 0; i < 300; i++) {
            Path file = root.resolve("src/group-" + (i / 30) + "/file-" + i + ".md");
            Files.createDirectories(file.getParent());
            Files.writeString(file, "original-" + i);
        }
        ProtectedRunSnapshotService service = new ProtectedRunSnapshotService(tmp.resolve("snapshots"));
        String outcome = service.begin("parallel", workspace(root));
        assertTrue(outcome.contains("files=300"));
        Files.writeString(root.resolve("src/group-0/file-0.md"), "modified");
        service.rollback("parallel");
        assertEquals("original-0", Files.readString(root.resolve("src/group-0/file-0.md")));
    }

    @Test void baselineIsNotRepeatedOrAccidentallyDiscarded() throws Exception {
        Path root = tmp.resolve("workspace"); Files.createDirectory(root);
        Files.writeString(root.resolve("keep.txt"), "protected");
        ProtectedRunSnapshotService service = new ProtectedRunSnapshotService(tmp.resolve("snapshots"));
        var ws = workspace(root);
        service.begin("run2", ws);
        assertThrows(java.io.IOException.class, () -> service.begin("run2", ws));
        assertTrue(Files.exists(tmp.resolve("snapshots/run2/manifest.properties")));
        service.discard("run2");
        assertFalse(Files.exists(tmp.resolve("snapshots/run2")));
    }
}
