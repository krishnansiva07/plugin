package com.llmart.llm.service;

import org.junit.jupiter.api.Test;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;

class AgentOptimizationPoliciesTest {
    private static final Set<String> CORE = Set.of("inspect_workspace", "glob", "read", "grep",
            "edit", "write", "bash", "build", "test", "tool_search", "ask_user",
            "documentation_inventory", "presentation_create", "work_items_discover", "work_items_read");

    @Test void readOnlyPalettePreservesDiscoveryAndOmitsMutations() {
        var tools = AgentToolPalettePolicy.select("Explain how LoginService.java authenticates users", true, CORE);
        assertTrue(tools.containsAll(Set.of("read", "grep", "tool_search")));
        assertFalse(tools.contains("edit"));
        assertFalse(tools.contains("build"));
        assertTrue(tools.size() < CORE.size());
    }

    @Test void ordinaryCodeEditKeepsVerifiersButOmitsSpecializedPptTools() {
        var tools = AgentToolPalettePolicy.select("Fix a Selenium null pointer in LoginService.java", false, CORE);
        assertTrue(tools.containsAll(Set.of("read", "edit", "build", "test", "bash", "tool_search")));
        assertFalse(tools.contains("presentation_create"));
        assertFalse(tools.contains("documentation_inventory"));
    }

    @Test void migrationRetainsLargeWorkItemCapabilities() {
        var tools = AgentToolPalettePolicy.select("Migrate all Selenium tests to Playwright TypeScript", false, CORE);
        assertTrue(tools.containsAll(Set.of("work_items_discover", "work_items_read", "tool_search")));
    }

    @Test void specializedRequestsKeepFullSet() {
        assertEquals(CORE, AgentToolPalettePolicy.select("Create full Confluence documentation", false, CORE));
        assertEquals(CORE, AgentToolPalettePolicy.select("Build MCP server with Java", false, CORE));
        assertEquals(CORE, AgentToolPalettePolicy.select("Create presentation slides", false, CORE));
    }

    @Test void unknownRequestsDoNotLoseCapabilities() {
        assertEquals(CORE, AgentToolPalettePolicy.select("Handle this requirement", false, CORE));
    }

    @Test void onlyLiveSourceEvidenceWithinCurrentStepSuppressesDuplicatePrimer() {
        var history = new ArrayList<Map<String,Object>>();
        history.add(Map.of("role", "system", "content", "[RUNTIME_STEERING:active-step-contract] step 1"));
        history.add(Map.of("role", "tool", "name", "read", "content", "class LoginService {" + "a".repeat(120) + "}"));
        assertFalse(AgentTurnEvidenceEconomy.shouldDeferRetrieval(history));
        history.add(Map.of("role", "tool", "name", "grep", "content", "LoginService matches at line 42 " + "b".repeat(120)));
        assertTrue(AgentTurnEvidenceEconomy.shouldDeferRetrieval(history));
        history.add(Map.of("role", "system", "content", "[RUNTIME_STEERING:active-step-contract] step 2"));
        assertFalse(AgentTurnEvidenceEconomy.shouldDeferRetrieval(history));
    }

    @Test void failedToolsAndUserTextCannotSuppressRetrieval() {
        var history = new ArrayList<Map<String,Object>>();
        history.add(Map.of("role", "system", "content", "[RUNTIME_STEERING:active-step-contract] step 1"));
        history.add(Map.of("role", "tool", "name", "read", "content", "permission denied " + "x".repeat(100)));
        history.add(Map.of("role", "user", "content", "look at this " + "y".repeat(150)));
        assertFalse(AgentTurnEvidenceEconomy.shouldDeferRetrieval(history));
    }

    @Test void legacyJsonToolTranscriptsAlsoSupportEvidenceHandoff() {
        var history = new ArrayList<Map<String,Object>>();
        history.add(Map.of("role", "system", "content", "[RUNTIME_STEERING:active-step-contract] step"));
        history.add(Map.of("role", "user", "content", "TOOL RESULT for read:\n" + "x".repeat(150)));
        history.add(Map.of("role", "user", "content", "TOOL RESULT for grep:\n" + "y".repeat(150)));
        assertTrue(AgentTurnEvidenceEconomy.shouldDeferRetrieval(history));
    }

    @Test void focusedPlanOnlyForSingleFileNoAttachmentsNoBroadScope() {
        assertEquals(2, AgentFocusedCodePlanPolicy.plan("Fix login in src/main/java/LoginService.java", false).size());
        assertTrue(AgentFocusedCodePlanPolicy.plan("Fix login in LoginService.java and User.java", false).isEmpty());
        assertTrue(AgentFocusedCodePlanPolicy.plan("Migrate the framework from LoginService.java", false).isEmpty());
        assertTrue(AgentFocusedCodePlanPolicy.plan("Fix login in LoginService.java", true).isEmpty());
    }
}
