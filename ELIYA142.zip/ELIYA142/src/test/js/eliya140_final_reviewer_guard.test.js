const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const code = fs.readFileSync(path.resolve(__dirname, '../../main/java/com/llmart/llm/service/AgentService.java'),'utf8');

test('blank reviewer output is a provider failure and cannot become successful evidence', () => {
  assert.match(code, /reply\.content\(\) == null \|\| reply\.content\(\)\.isBlank\(\)/);
  assert.match(code, /throw new EmptyRoleResponseException\(/);
  assert.match(code, /run\.recordModelUsage\(reply\.usage\(\), preflight\.estimatedInputTokens\(\)/);
});

test('empty role responses are retried and bounded, with model failover available', () => {
  assert.match(code, /final int maxEmptyRoleReplies = Math\.min\(4, Math\.max\(2, run\.modelPool\(\)\.size\(\) \* 2\)\)/);
  assert.match(code, /if \(emptyReply && emptyRoleReplies >= maxEmptyRoleReplies\)/);
  assert.match(code, /int retriesAllowed = emptyReply \? 1 : PROVIDER_RETRIES_PER_MODEL_ACTIVATION/);
  assert.match(code, /switchToNextModelCyclic\(run, onStep, step/);
});

test('reviewer output budget is not restricted to 700 tokens', () => {
  assert.match(code, /Math\.min\(2_048, request\.settings\(\)\.safeMaxTokens\(\)\) : 2_048/);
});

test('no-evidence outcomes are blocked, confirmed defects failed', () => {
  assert.match(code, /completionStatus = decision\.needsEvidence\(\) \? "blocked" : "failed"/);
  assert.match(code, /completionStatus = outcome\.outcomeVerdict\(\) == AgentOutcomeReviewPolicy\.Verdict\.MISSING_EVIDENCE/);
  assert.match(code, /completionStatus = actual\.outcomeVerdict\(\) == AgentOutcomeReviewPolicy\.Verdict\.MISSING_EVIDENCE/);
});
