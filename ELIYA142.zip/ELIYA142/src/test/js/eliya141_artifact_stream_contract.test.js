const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const base = path.join(__dirname, '..', '..', 'main');
const artifacts = require(path.join(base, 'resources/static/response-artifacts.js'));
const chat = require(path.join(base, 'resources/static/conversation-intelligence.js'));
const app = fs.readFileSync(path.join(base, 'resources/static/app.js'),'utf8');
const java = name => fs.readFileSync(path.join(base,'java/com/llmart/llm/service',name),'utf8');
const q = 'Generate one complete 1500-line implementation prompt in Markdown for Java Selenium to Playwright TypeScript migration; source legacy and target workspace.';

test('one large prompt remains one complete exact-byte Markdown document', () => {
  const source = '# Migration implementation\n' + Array.from({length:1500}, (_,i)=>`- Step ${i+1}: inspect the Java source and verify the migrated TypeScript behavior`).join('\n');
  const sections=artifacts.promptSections(q,source);
  assert.equal(sections.length,1);
  assert.equal(sections[0].content,source);
  assert.equal(sections[0].ready,true);
  assert.equal(artifacts.sourceView(q,source,true).content,source);
  assert.equal(artifacts.sourceView(q,source).content,source);
});

test('four complete prompts are independently scoped; no combined Agent handoff', () => {
  const request='Generate 4 separate implementation prompts for Java Selenium to Playwright TypeScript.';
  const source=Array.from({length:4}, (_,i)=>`## Prompt ${i+1}\n\nImplement phase ${i+1}. Inspect workspace and verify the actual behavior.\n`+ 'Target only this phase. '.repeat(20)).join('\n\n');
  const sections=artifacts.promptSections(request,source);
  assert.equal(sections.length,4);
  assert.ok(sections.every(s=>s.ready));
  const handoff=artifacts.handoffMessage(123, sections[1].content,sections[1].title);
  assert.match(handoff,/phase 2/);
  assert.doesNotMatch(handoff,/phase 1|phase 3|phase 4/);
});

test('interrupted Markdown prompt can be downloaded as partial, not handed to Agent', () => {
  const partial='# Partial prompt\n\nVerify the staged migration.\n\n[ELIYA: response incomplete] provider interrupted';
  const sections=artifacts.promptSections(q,partial);
  assert.equal(sections.length,1);
  assert.equal(sections[0].ready,false);
  assert.equal(artifacts.promptSourceDownloadable(sections[0]),true);
  assert.equal(artifacts.draftFilename('prompt-1.md'),'prompt-1.partial.md');
});

test('long HTML source stays complete through preview and document extraction', () => {
  const html='<!doctype html>\n<html><head><title>Report</title></head><body>\n'+Array.from({length:1150}, (_,i)=>`<p>line ${i}</p>`).join('\n')+'\n</body></html>';
  const question='Generate a downloadable full HTML report';
  assert.equal(artifacts.sourceView(question,html,true).content,html);
  const file=artifacts.sourceView(question,html);
  assert.equal(file.content,html);
  assert.equal(file.ready,true);
  assert.equal(artifacts.draftFilename('report.html'),'report.partial.html');
});

test('follow-up is evidence-derived and suppressed for generated artifacts', () => {
  const answer='The analysis located missing retry coverage.\n\n## Recommendations\n- Verify the Cucumber hooks against actual Grid runs';
  assert.equal(chat.suggest({prompt:'Analyze Java Selenium workspace',answer}),
      'Would you like me to verify the Cucumber hooks against actual Grid runs?');
  assert.equal(chat.suggest({prompt:'Generate a complete implementation prompt in Markdown',answer}), '');
  assert.equal(chat.suggest({prompt:'Analyze Java Selenium workspace',answer:'Here is the full architecture. '+ 'a'.repeat(100)}), '');
});

test('long-source streaming exposes all draft actions and stall controls', () => {
  for(const marker of ['data-live-source-copy','data-live-source-download','data-live-source-full',
    'data-file-download-partial','data-stop-unresponsive-chat','chatLastProgressAt','updateChatHealthNotice'])
    assert.ok(app.includes(marker),`missing ${marker}`);
  assert.match(app,/if \(chatProgressWatch\) clearInterval\(chatProgressWatch\)/);
  assert.match(app,/assistant\.chatLastProgressAt = Date\.now\(\)/);
  assert.match(app,/content\.innerHTML=`<section class=\"eliya-prompts eliya-source-flow\"/);
});

test('completion policy does not append a fixed closing question',()=>{
  const result=java('AgentResultPresentation.java');
  const service=java('AgentService.java');
  const narrator=java('AgentCompletionNarrator.java');
  assert.doesNotMatch(result,/\+ "\\n\\n" \+ question/);
  assert.doesNotMatch(service,/result\.append\("\\n\\nDo you want to add anything\?"\)/);
  assert.doesNotMatch(narrator,/append\("\\n\\nWould you like me to do that\?"\)/);
});

test('instructions explicitly prohibiting TODOs are not mistaken for omitted content',()=>{
  const valid='# Migration\n\nInspect legacy framework and implement workspace utilities. Verify with real checks; do not leave TODO placeholders in the generated code.\n'+ 'Acceptance requirements with details. '.repeat(9);
  assert.equal(artifacts.promptReadiness(q,valid).ready,true);
  assert.equal(artifacts.promptReadiness(q,valid+'\nTODO: fill in the test environment').ready,false);
});
