const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const java = (name) => fs.readFileSync(path.resolve(__dirname,
  `../../main/java/com/llmart/llm/service/${name}.java`), 'utf8');
const ui = fs.readFileSync(path.resolve(__dirname, '../../main/resources/static/app.js'), 'utf8');

test('agent advertises task-appropriate tools while preserving deferred discovery', () => {
  assert.match(java('AgentService'), /AgentToolPalettePolicy\.select\(request\.message\(\)/);
  assert.match(java('AgentToolPalettePolicy'), /result\.add\("tool_search"\)/);
});

test('agent defers redundant retrieval only when live source evidence is present', () => {
  assert.match(java('AgentService'), /AgentTurnEvidenceEconomy\.shouldDeferRetrieval\(messages\)/);
  assert.match(java('AgentService'), /liveEvidenceAlreadyAvailable \? "" : activeContextBundle/);
  assert.match(java('AgentTurnEvidenceEconomy'), /current step boundary/i);
});

test('hot context path reuses the size envelope rather than repeating full estimates', () => {
  const service = java('AgentService');
  assert.match(service, /shouldAggressivelyPrune\(beforePrune, settings\)/);
  assert.match(service, /shouldEconomyCompact\(messages, settings, before\)/);
  assert.match(service, /shouldCompact\(before, settings\)/);
});

test('single-file fixes do not spend a planner call, broad migrations still use normal planner', () => {
  assert.match(java('AgentService'), /AgentFocusedCodePlanPolicy\.plan\(task/);
  assert.match(java('AgentFocusedCodePlanPolicy'), /BROAD\.matcher\(objective\)\.find\(\)/);
});

test('user can inspect the measured optimization and live/provider token metrics', () => {
  assert.match(ui, /Initial tool schemas:/);
  assert.match(ui, /Proactive evidence replay avoided on/);
  assert.match(java('AgentRunService'), /usage\.put\("initialToolSchemas"/);
  assert.match(java('AgentRunService'), /usage\.put\("proactiveRetrievalDeferred"/);
});

test('comparison refuses misleading percentages for different tasks or models', () => {
  assert.match(ui, /const comparable=reason && sameTask && sameModel/);
  assert.match(ui, /Comparative token percentage withheld/);
});
