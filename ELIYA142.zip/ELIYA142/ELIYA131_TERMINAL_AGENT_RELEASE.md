# ELIYA131 — Localhost, Isolated CLI Sessions, Interactive Agent, Verified Completion

Baseline: user-uploaded ELIYA130.zip. This is an **updated source release**, not a compiled JAR.

## What changed

1. **Canonical browser URL**: JAR auto-opens `http://localhost:8090/`. CLI status, browser activation and CLI networking advertise/use `localhost`. The settings sync accepts both localhost and 127.0.0.1 for backward compatibility, but don't alternate browser origins: they have different local storage. The server still binds loopback (`127.0.0.1`) so it is not exposed on a LAN.
2. **Independent CLI sessions**: every launcher invocation generates a session UUID; per-session workspace, conversation and Analyse/Agent mode are maintained in the server. The CLI's workspace selection does **not** change the browser-global selection or a different CLI process's mode. `/workspace` changes only the current CLI session. Multiple Agents editing the same or parent/child workspace paths are rejected with a conflict rather than editing concurrently.
3. **Streaming Agent**: CLI runs delegate to the existing `ChatService` / `AgentService` engine. Live events, final Markdown and file-change results are sent over SSE; disconnecting the SSE transport does not silently terminate server-side Agent execution.
4. **Interactive approval and clarification**: file/tool approval events and Agent questions are handled in the command-line reader. Approvals are bound to the requesting run ID and terminal session. Unknown, expired, or cross-session approvals are refused. File-deletion approvals cannot grant blanket run-wide permission. Closed stdin defaults to deny/cancel.
5. **Server-side cancellation**: Ctrl+C makes a best-effort server cancellation request. A separate terminal can issue `eliya cancel <session-id>` reliably (session UUID is shown by `eliya status`). `/cancel` and `/stop` work between interactive prompts; during a long-running prompt use Ctrl+C or the separate cancellation command. `AgentRunService.cancel` also terminates registered tool processes when possible.
6. **Strict completion gate**: required verification must match the *latest* workspace revision. Unresolved verification failures or a request for local file deliverables with no tracked file/resource changes cannot be reported as completed. Existing HTML-report evidence, plans and documentation coverage checks remain enabled.
7. **Better conversational outcome**: preserve the model-produced explanation, append recorded changed files and verification results, and offer an evidence-based next step. Failed/blocked runs remain failures. Terminal `done` checks the actual run snapshot before printing completion.
8. **Direct terminal metrics**: the CLI shows elapsed time, each recorded stage timing, provider token counts and whether usage was fully reported. Absent usage is never displayed as an exact successful zero.
9. **Performance/learning**: existing fast read-only routing, indexed retrieval, context compaction, recovery and verified-workspace learning are retained. Reuse of existing analysis/report avoids duplicate synthesis where applicable. Verified learning remains **explicitly user-approved** and only recalls nonstale source-backed lessons; it is not training model weights.

## Quick start (after building the JAR)

```powershell
java -jar target\eliya.jar
```

The browser opens at `http://localhost:8090`. Save the Base URL, key, and model in browser Settings; if the CLI reports `Model configured in browser: false`, reload the **localhost** browser tab and save settings again (never paste keys into terminal output).

Open a new terminal in an IntelliJ, VS Code, PowerShell, or CMD project:

```powershell
eliya analyse
# In the interactive CLI:
# Review the API test framework and cite file paths
# /agent
# Create focused API tests for authentication
# /status
# /exit
```

In a different project terminal, `eliya agent` uses a separate conversation and workspace. A new CLI process **does not automatically resume** a previous process's conversation; this is intentional session isolation.

### Cancel an active CLI run

While the Agent is running, press Ctrl+C (best effort) or in another terminal:

```powershell
eliya cancel <session-uuid>
```

### Measured performance benchmark (requires live model)

```powershell
python qa\eliya131\terminal_benchmark.py --workspace "D:\Automation\SeleniumFramework" --runs 3
```

The harness stores **only metrics**, not repository/source output. Compare against the exact same benchmark on ELIYA130 (same model, provider, hardware, prompt and workspace) and manually verify analysis quality. This release does not claim an unmeasured speedup.

## Tests run in this environment

- `bash qa/eliya131/run.sh` — passed (8 new completion cases; CLI session isolation & localhost smoke; prior 127/128/129/130 source-level smoke).
- `bash qa/token-usage-smoke/run.sh` — passed (3 new strict latest-revision completion cases plus pre-existing token accounting).
- `node --test src/test/js/*.test.js` — **112 passed, zero failed**.
- `node --check src/main/resources/static/app.js` — passed.
- Python benchmark harness compiled; its live benchmark was **not** run.

## Important limits / remaining acceptance work

- A complete Maven compilation, packaged JAR startup, real IDE/PowerShell sessions, live SSE, real provider execution, network/UI/browser synchronization, approval timeout/cancellation behavior, and performance/quality benchmarking **have not been end-to-end verified** in this environment. Maven is unavailable; the source-level Java tests use mock/stub dependencies for the CLI bridge.
- Automatic CLI registration inherits OS/IDE PATH restrictions from earlier releases. A long-running IntelliJ parent process may need restarting or a PATH refresh; Java cannot retroactively update every already-running parent process's environment.
- The per-workspace conflict check added here serializes CLI-to-CLI conflicting edits. Browser Agent executions and older TerminalSessionService-managed tasks have their own coordinators; cross-entrypoint collision avoidance still requires full shared-lock validation.
- CLI model settings are held in process memory and synchronized by the browser. Settings do not survive restarting the Java process without a fresh browser sync. Persistent credential vault support is not implemented here.
- Ctrl+C is best-effort. Use the explicit `eliya cancel` endpoint for a deterministic request, then verify the run stopped in history. On completed runs cancellation is no longer applicable.
- The `VerifiedLearningMemoryService` already supports opt-in source-backed lessons. This release does **not** automatically learn from every run, nor does it claim to do so.
