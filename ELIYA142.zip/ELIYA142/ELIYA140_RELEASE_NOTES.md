# ELIYA140 — Final Reviewer Recovery / False Failure Triage

## Observed failure in ELIYA139
- After a roughly 34-minute run with three tracked workspace changes, final reviewer returned no text.
- `AgentOutcomeReviewPolicy.interpret("")` classified it as `MISSING_EVIDENCE` with the exact text `Final reviewer returned no decision; no defect is established`.
- The completion branch later converted this unproven outcome into `failed`, even when no actual defect was identified.
- 97% progress was not proof of completion; changes are preserved and still require inspection.

## Source changes in ELIYA140
- `AgentService.completeRoleText(...)`: empty text now becomes a provider error, producing explicit `model_empty_response` diagnostics and entering the bounded retry/model-failover path. It no longer silently enters final outcome triage as if it were a valid reviewer decision.
- Record provider token usage for empty responses, to avoid hiding their expense.
- Allow at most one same-model retry for an empty role reply, then a configured model failover; cap blank responses at 2–4 total depending on configured model pool.
- Increase the final verifier's output allowance from 700 to up to 2,048 tokens (subject to configured `safeMaxTokens`). This reduces the chance that reasoning-enabled models exhaust their output allowance without emitting a verdict.
- Treat `MISSING_EVIDENCE` outcomes as `blocked`, not `failed`, in the known final-review branches. A confirmed `DEFECT` remains `failed`.
- No bypass of independent test/build verification or of the final approved-plan evidence gate.

## Tests and limitations
- 116 JavaScript tests passed (`node --test src/test/js/*.test.js`), including four *source-contract* regression checks for the newly wired Java logic.
- These source-contract checks are not an end-to-end Java runtime verification.
- Full Maven compile/test and live model/tool execution could not be performed here: Maven and the cached Spring dependencies were unavailable. Build and runtime verification must be completed on the target Windows environment.
- The screenshots alone do not expose the exact provider `finish_reason` or whether all 3 changed files meet requirements. A missing reviewer response might be caused by output-token exhaustion, a model/provider issue, or a response-decoding problem; the source code alone does not establish which cause occurred in that run.

## Build / validation on Windows
1. Back up your current ELIYA139 folder. Extract ELIYA140_Source_Fixes.zip as a separate folder.
2. Open a Windows terminal in the extracted `ELIYA140` directory.
3. Run `mvnw.cmd clean package` (requires Maven bootstrap or a local Maven installation and dependency access).
4. Launch with `run.bat` or the project's established JAR launch method, confirm localhost:8090.
5. Use a small test Agent task that makes a file change and runs a real validator, then inspect the final outcome.
6. Re-run the original prompt only after checking the three changes already made. Do not discard or repeat verified work.
7. If blank-reviewer errors recur, inspect the activity `model_empty_response` event and the `finish_reason` from the provider. If missing, inspect backend logs and response payloads; this build exposes more diagnostic context.

## Acceptance outcomes
- Reviewer returns `SATISFIED` with real verifier + plan evidence: Completed.
- Reviewer returns an empty response and recovery yields a proper verdict: continue based on verdict.
- Reviewer remains empty after bounded recovery: Blocked / unverified, NOT silently failed as implementation.
- Reviewer returns `MISSING_EVIDENCE` after bounded evidence attempt: Blocked / unverified; no replan of working code.
- Reviewer proves a concrete `DEFECT`: Failed; show exact gap, preserve changes and report.

## Separate concern (not fixed by this patch)
Screenshot attachment `prompt-1-complete-prompt.html` is an HTML file rather than the requested Markdown source. The prompt-generation/downloading/handoff policy needs a separate end-to-end test to ensure `.md` output and that only the selected prompt's text is sent to Agent. ELIYA140 addresses the **final-review false-failure issue shown in the screenshot**, not that independent UI contract.
