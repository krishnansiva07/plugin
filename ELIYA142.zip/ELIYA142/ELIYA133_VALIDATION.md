# ELIYA133 — Validation record

Date: 2026-11-11

| Test | Result | Scope |
|---|---|---|
| `node --check` modified front-end scripts | PASS | JS parsing |
| `node --test src/test/js/*.test.js qa/eliya133-contract.test.js` | **117 pass, 0 fail** | 112 retained regressions + 5 intent/verification/prompt/artifact contracts |
| `node qa/response-artifacts-132.test.js` | PASS | 132 artifact/handoff regression |
| `qa/eliya133-policy/run.sh` | PASS | Java standalone implicit workspace routing and verification result gates |
| `javac` / `java` on `ConversationHandoffSelection` + `ScopeContractCheck` | PASS | Selected source ID and scoped handoff preservation |
| `python qa/eliya133_browser_smoke.py` | PASS | Real installed Chromium; desktop/mobile UI, incomplete verification, two prompt cards, selected Prompt 2 only, incomplete drafts disabled, HTML preview/download |
| Full Maven/Spring Boot build | **NOT RUN** | Maven not installed; Maven repository DNS unavailable |
| Real local migration / LLM / Agent execution | **NOT RUN** | No configured target workspace/provider in this isolated test environment |

All browser assertions use test-fixture responses. The browser uses a genuine Chromium executable but does not contact a running Spring Boot server. Passing a UI assertion does **not** establish backend integration or model quality.

## Artifacts captured

`qa/screenshots-133/eliya133-desktop.png`, `eliya133-prompt-cards.png`, `eliya133-artifact-drawer.png`, `eliya133-mobile.png`.

## Recommended additional checks on the target machine

- Maven compile/package and all Spring Boot tests.
- Prompt generation quality over long real Analyse replies, and clipping/recovery behavior.
- Automatic and manual workspace index refresh after file mutations.
- Analyse read-only inspection versus executing actual Chrome/Edge tests in Agent.
- Implementation refusal when source prompt or mapped workspace changes mid-handoff.
- Real Agent exception in the final requested report step must be reported as blocked/failed; review backend run state and generated files.
- Cross-platform browser UI and all registered MCP tools, including explicit MCP gating.
