# ELIYA142 — Adaptive agent token economy and fair comparison

**Build status:** source-only release from user-supplied ELIYA141 ZIP. No production JAR claim.

Implemented:
- Adaptive starting tool schema palette (default 54; read-only 20; routine code 31; migration 36; specialized remains 54).
- Evidence-aware suppression of duplicated proactive retrieval within the same plan step.
- Reused context-window estimates for three policy decisions, reducing repeated JSON-size work.
- No-planner fast path for precisely scoped single-file source fixes.
- Pruning of outdated active-step runtime steering, without dropping original instructions.
- Durable tool-palette/retrieval telemetry and an execution-timing UI explanation.
- Comparison UI blocks percentages when tasks/models differ or token data is incomplete.
- JDK-only smoke harness, 130 Node tests, JUnit tests and run-comparison CLI.

Validation: 130/130 JS tests; JDK policy smoke PASS; `javac` on three new policies PASS;
`node --check` app.js PASS; `python -m py_compile` comparison script PASS.
Maven/Spring compilation unavailable: Maven not installed and Maven Central DNS inaccessible.

Safety: opt-out flags in ELIYA142_PERFORMANCE_REVIEW.md; existing verification/approval
and workspace safety unchanged. Live benchmark against OpenCode is pending.
