# ELIYA137 — Contextual Checks & Long Output UI Reliability

Base: uploaded ELIYA136 source. This is a source patch, **not** a validated production JAR.

## Changes
1. `check`, `verify`, `review`, `inspect`, or `validate` on their own reuse the most recent user task in the **same conversation** and the mapped workspace/reference context. This applies to Analyse and the independent Terminal conversation. They remain read-only; commands explicitly requesting changes continue to follow the Agent path. When the conversation contains no earlier task, checking a mapped workspace is a generic, evidence-based inspection rather than an invented prior instruction. This is implemented as a small, deterministic contextualization layer; no second LLM call is required.
2. Model instructions in Chat and Agent say that a short `check` must not be rejected merely because the user didn't supply another long prompt.
3. CLI now accepts `eliya check` as a one-shot read-only check of the latest task in that workspace conversation; interactive mode also describes how to use `check` without requiring a template.
4. Discussing or checking an existing prompt no longer triggers the UI's **generate new prompt** display path. Prompt cards remain opt-in for actual requests to generate prompts.
5. Long fenced source blocks (>240 lines or >24,000 characters) bypass high-cost syntax highlighting and thousands of number spans. They retain **all text** in one scrollable dark code viewer with Expand, Wrap, Copy, Download. Blank code fences remain hidden while streaming.
6. Terminal live response no longer shows only the latest 50,000 characters. Transcript turns no longer discard content beyond 35,000 characters. It is bounded by the existing 600,000-character session safety ceiling, and exceeding that ceiling now shows an explicit truncation note. The browser keeps at most 8 in-memory answer fallbacks.
7. Selected implementation prompt handoff cap raised from 32,000 to 72,000 characters. The actual per-model `ContextService` window still independently enforces its limit, and longer tasks may need splitting.
8. Static asset URLs version-bumped so existing browser caches don't continue loading earlier JS/CSS.

## Tests performed
- PASS: `node --test src/test/js/*.test.js qa/eliya133-contract.test.js qa/eliya136-snapshot-ui.test.js` — 120 tests.
- PASS: `node --test qa/eliya137-responsive-output.test.js` — 8 targeted tests.
- PASS: `node --check` on changed JavaScript files.
- Browser visual test: attempted but Chromium headless did not complete in this container. No visual guarantee asserted.
- Full Java Maven compile/JAR, Windows installation, model-backed end-to-end Agent/MCP tests: **NOT VERIFIED**. Maven could not download its dependencies in this environment (external repository DNS unavailable).

## Out of scope / important constraints
- Native Agent snapshots, approvals, cancellation, rollback, security and MCP gates were not disabled.
- This release does **not** prove all historical UI bugs or model failures are fixed. Any provider response that stops before completing a long prompt must still be handled as incomplete, and the server model context remains a separate limit.
- Copy the source into a clean folder, use the existing Windows build script (`build-jar-windows.cmd`) with Java 17 and Maven access, then verify a real workspace workflow before replacing the live ELIYA installation.

## Manual acceptance check on Windows
1. Open localhost:8090, map a writable workspace and its existing reference(s), choose Analyse.
2. Request a specific verification task, then send `check`. Expect evidence and a verdict/limitations rather than `provide the prompt`.
3. Generate a long prompt with >300 lines in a fenced block. Confirm dark panel shows complete tail, scrolls independently, and Expand/Copy/Download all preserve the last line.
4. Open an independent Terminal tab; send a task, then `check`. Ensure it refers to **that tab's** task, not the unrelated Chat tab.
5. Check that file modifications require the configured Agent permissions, while `check` remains read-only.
6. Test 70,000-character Agent handoff under the selected model's actual context limit and record exact admission error if it cannot fit.
