package com.llmart.llm.service;
import java.util.*;
public class SuperAgentSmoke {
  static void verify(boolean b, String message) { if (!b) throw new AssertionError(message); }
  public static void main(String[] args) {
    var history = List.<Map<String,Object>>of(Map.of("role", "system", "content", "System"),
      Map.of("role", "assistant", "content", "BMSA-1234 gap analysis: finding 1 missing alert validation. Finding 2 partial regression coverage. Recommended changes in AlertService.java and AlertTest.java."),
      Map.of("role", "user", "content", "Implement the first two"));
    var handoff = AgentAnalysisHandoff.extend("Implement the first two", history);
    verify(handoff.isPresent(), "reference to previous analysis lost");
    verify(handoff.get().contains("BMSA-1234"), "Jira context lost");
    verify(handoff.get().contains("re-check live sources") || handoff.get().contains("Read current files"), "staleness protection missing");
    verify(AgentAnalysisHandoff.extend("yes", history).isEmpty(), "ambiguous yes is not write authorization");
    verify(AgentAnalysisHandoff.extend("Implement a new standalone project", history).isEmpty(), "unrelated work should not import old findings");
    verify(AgentAnalysisHandoff.extend("Implement", List.of()).isEmpty(), "no previous findings");
    verify(AgentAnalysisHandoff.extend("Implement", List.of(Map.of("role", "assistant", "content", "Implementation completed successfully, all fixes validated in the pipeline, expected functionality is now working according to requirements."))).isEmpty(), "completed old work is not pending implementation");
    var valid = ParallelAgentResearchPolicy.validate(List.of(new ParallelAgentResearchPolicy.Task("architect", "Trace API dependencies"),
        new ParallelAgentResearchPolicy.Task("reviewer", "Check existing test and security gaps")));
    verify(valid.size() == 2, "safe parallel tasks not accepted");
    for (String denied : List.of("edit", "write", "bash", "test", "task", "task_parallel", "mcp__jira_write", "delete", "apply_patch", "tool_search"))
        verify(!ParallelAgentResearchPolicy.safeTool(denied), "unsafe parallel tool allowed: " + denied);
    verify(ParallelAgentResearchPolicy.safeTool("read_many"), "safe read missing");
    try { ParallelAgentResearchPolicy.validate(List.of(new ParallelAgentResearchPolicy.Task("developer", "Implement"),
       new ParallelAgentResearchPolicy.Task("reviewer", "Review"))); throw new AssertionError("developer delegation permitted"); }
    catch (IllegalArgumentException expected) { }
    try { ParallelAgentResearchPolicy.validate(List.of(new ParallelAgentResearchPolicy.Task("explore", "A")));
       throw new AssertionError("single task should not use parallel flow"); }
    catch (IllegalArgumentException expected) { }
    System.out.println("Superagent conversation, constrained parallel research: PASS");
  }
}
