from pathlib import Path
svc=Path('src/main/java/com/llmart/llm/service')
s=(svc/'AgentService.java').read_text()
r=(svc/'AgentToolRegistry.java').read_text()
assert 'case "task_parallel" -> runParallelResearch' in s
assert 'ParallelAgentResearchPolicy.validate(proposals)' in s
assert 'readOnly && !ParallelAgentResearchPolicy.safeTool' in s
assert 'task_parallel' in r
assert 'AgentAnalysisHandoff.extend(request.message(), baseContext)' in s
assert 'baseContext = replaceLatestUserText(baseContext, handoff.get())' in s
assert 'readOnly ? Math.min(maxChildTurns, 18)' in s
print('Superagent integration contract: PASS')
assert s.index('AgentOutcomeReviewPolicy.readyForFinalReview(') < s.index('completeAgentTurn(apiKey, request, messages, ws, run, requireToolNextTurn, availableTools, step, onStep);')
assert 'finalReviewEvidencePending = true;' in s
assert '"Final outcome verification retry"' in s
print('Verified-completion preflight and empty-critic retry: PASS')
