#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../.."
TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT
javac --release 17 -d "$TMP" \
  src/main/java/com/llmart/llm/service/AgentAnalysisHandoff.java \
  src/main/java/com/llmart/llm/service/ParallelAgentResearchPolicy.java \
  qa/superagent/SuperAgentSmoke.java
java -cp "$TMP" com.llmart.llm.service.SuperAgentSmoke
bash qa/conversational-agent/run.sh
bash qa/outcome-review-smoke/run.sh
node --check src/main/resources/static/app.js
python3 qa/superagent/contracts.py
