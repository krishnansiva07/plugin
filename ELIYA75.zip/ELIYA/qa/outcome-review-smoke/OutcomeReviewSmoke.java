import com.llmart.llm.service.AgentOutcomeReviewPolicy;

public class OutcomeReviewSmoke {
    static void expect(boolean condition, String message) {
        if (!condition) throw new AssertionError(message);
    }
    public static void main(String[] args) {
        var good = AgentOutcomeReviewPolicy.interpret("SATISFIED\nEverything required is verified");
        expect(good.satisfied(), "positive decision");
        expect("COMPLETE".equals(AgentOutcomeReviewPolicy.nextAction(good, false)), "positive completion");
        var missing = AgentOutcomeReviewPolicy.interpret("MISSING_EVIDENCE: Need test result for package A");
        expect(!missing.satisfied() && missing.needsEvidence(), "missing evidence is not a defect");
        expect("INSPECT_EVIDENCE".equals(AgentOutcomeReviewPolicy.nextAction(missing, false)), "inspect evidence first");
        expect("STOP_UNVERIFIED".equals(AgentOutcomeReviewPolicy.nextAction(missing, true)), "no repeated inspection loop");
        var defect = AgentOutcomeReviewPolicy.interpret("DEFECT\nCompilation failed on class B");
        expect(!defect.needsEvidence() && !defect.satisfied(), "confirmed gap is distinct");
        expect("CORRECT_CONFIRMED_GAP".equals(AgentOutcomeReviewPolicy.nextAction(defect, false)), "focused correction");
        expect("STOP_UNVERIFIED".equals(AgentOutcomeReviewPolicy.nextAction(defect, true)), "do not loop on same defect");
        expect(AgentOutcomeReviewPolicy.interpret("CONTINUE: insufficient proof").needsEvidence(), "old protocol safe fallback");
        expect(AgentOutcomeReviewPolicy.interpret("I think it is done").needsEvidence(), "malformed response fails closed");
        expect(AgentOutcomeReviewPolicy.interpret("").needsEvidence(), "empty response fails closed");
        expect(!AgentOutcomeReviewPolicy.interpret("SATISFIEDLY yes").satisfied(), "boundary not accidentally positive");
        expect(AgentOutcomeReviewPolicy.readyForFinalReview(true, false, true, true, 2, 2),
                "closed plan, green current verifier should finish without another executor turn");
        expect(!AgentOutcomeReviewPolicy.readyForFinalReview(true, true, true, true, 2, 2),
                "must not finish open plan");
        expect(!AgentOutcomeReviewPolicy.readyForFinalReview(true, false, true, false, 2, 2),
                "must not finish failed verifier");
        expect(!AgentOutcomeReviewPolicy.readyForFinalReview(true, false, true, true, 1, 2),
                "must not finish stale verification");
        String a = AgentOutcomeReviewPolicy.fingerprint("p", "verified", "file A sha1", "read summary");
        expect(a.equals(AgentOutcomeReviewPolicy.fingerprint("p", "verified", "file A sha1", "read summary")), "stable evidence key");
        expect(!a.equals(AgentOutcomeReviewPolicy.fingerprint("p", "verified", "file A sha2", "read summary")), "file changes invalidate");
        expect(!a.equals(AgentOutcomeReviewPolicy.fingerprint("p", "verified", "file A sha1", "new tool evidence")), "new evidence invalidates");
        expect(!a.equals(AgentOutcomeReviewPolicy.fingerprint("p", "FAILED", "file A sha1", "read summary")), "verifier changes invalidate");
        System.out.println("PASS: outcome verification triage, quality guards and evidence fingerprints (14 checks)");
    }
}
