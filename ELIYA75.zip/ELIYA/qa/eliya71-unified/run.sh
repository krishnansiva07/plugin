#!/usr/bin/env bash
set -euo pipefail
BASE="$(cd "$(dirname "$0")/../.." && pwd)"
TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT
javac --release 17 -d "$TMP" \
  "$BASE/src/main/java/com/llmart/llm/dto/ChatMode.java" \
  "$BASE/src/main/java/com/llmart/llm/service/UnifiedIntentRouter.java" \
  "$BASE/src/main/java/com/llmart/llm/service/AnalysisFollowUpPolicy.java" \
  "$BASE/qa/eliya71-unified/UnifiedIntentSmoke.java"
java -cp "$TMP" UnifiedIntentSmoke
node --check "$BASE/src/main/resources/static/app.js"
python3 "$BASE/qa/eliya71-unified/ui-contracts.py" "$BASE/src/main/resources/static"
