from pathlib import Path
import sys
root = Path(sys.argv[1])
html = (root / 'index.html').read_text()
js = (root / 'app.js').read_text()
css = (root / 'app.css').read_text()
assert 'id="modeBar"' in html
assert 'data-mode="chat"' not in html and 'data-mode="agent"' not in html, 'Visible Chat/Agent toggle still present'
assert 'id="workspaceQuickOpen"' in html and 'id="chatModelSelect"' in html
assert "mode: 'auto'" in js and "meta.mode === 'agent'" in js
assert "$('workspaceQuickOpen').onclick" in js
assert 'unified-mode-bar' in css and 'composer-zone' in css
assert 'activeAgentClarification()' in js and 'refreshUnifiedComposer()' in js
assert 'questionId:pending.question.id' in js and 'if (pending && !regenerate)' in js
assert 'Reply in the message box below and press Enter' in js
assert 'mode.wireName()' in (root.parent.parent / 'java/com/llmart/llm/service/ChatService.java').read_text()

print('Unified UI source contracts: PASS')
