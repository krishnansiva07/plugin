import com.llmart.llm.service.UnifiedIntentRouter;
import com.llmart.llm.service.AnalysisFollowUpPolicy;
import com.llmart.llm.dto.ChatMode;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class UnifiedIntentSmoke {
    static void expect(ChatMode expected, String prompt, String previous) {
        ChatMode actual = UnifiedIntentRouter.resolve("auto", prompt, previous);
        if (actual != expected) throw new AssertionError(prompt + ": expected " + expected + " but got " + actual);
    }
    public static void main(String[] args) {
        expect(ChatMode.CHAT, "Analyse the alerting system and give recommendations", "");
        expect(ChatMode.CHAT, "How do I fix the alerting system?", "");
        expect(ChatMode.CHAT, "More analysis on the third issue", "");
        expect(ChatMode.CHAT, "No, do not implement; analyse further", "");
        expect(ChatMode.CHAT, "Don't change the files, review the implementation", "");
        expect(ChatMode.AGENT, "Analyse the gaps and implement the fixes", "");
        expect(ChatMode.AGENT, "Implement the recommended fixes", "");
        expect(ChatMode.AGENT, "Fix the failing tests", "");
        expect(ChatMode.AGENT, "Generate the documents in workspace", "");
        expect(ChatMode.AGENT, "Rollback the last operation", "");
        expect(ChatMode.AGENT, "Yes", "Would you like me to implement the fixes?");
        expect(ChatMode.CHAT, "Yes", "Do you want more examples?");
        expect(ChatMode.CHAT, "Yes", "Would you like me to implement the fixes, or investigate further?");
        expect(ChatMode.CHAT, "Explain Jenkins CI/CD pipeline", "");
        expect(ChatMode.CHAT, "Can you pull BMSA-1234 using Jira MCP and compare with the workspace what needs to be done?", "");
        expect(ChatMode.AGENT, "Implement", "I identified two implementation gaps. Would you like me to implement them or analyse further?");
        expect(ChatMode.AGENT, "Implement the first two", "Two missing requirements and three test gaps were found.");
        expect(ChatMode.CHAT, "Analyse further", "I identified two implementation gaps.");
        expect(ChatMode.CHAT, "Yes", "Would you like me to implement or investigate further?");
        expect(ChatMode.AGENT, "Run the tests", "");
        if (UnifiedIntentRouter.resolve("agent", "explain", "") != ChatMode.AGENT)
            throw new AssertionError("Legacy explicit Agent route must be preserved");
        String body = AnalysisFollowUpPolicy.finish("Three problems identified.", "Analyse the pipeline");
        if (!body.contains("Would you like me to implement")) throw new AssertionError("Missing follow-up question");
        if (!"Hello".equals(AnalysisFollowUpPolicy.finish("Hello", "Hi"))) throw new AssertionError("Greeting changed");
        List<Map<String,Object>> context = new ArrayList<>();
        context.add(new HashMap<>(Map.of("role", "system", "content", "Existing configuration")));
        AnalysisFollowUpPolicy.instruct(context);
        if (!String.valueOf(context.get(0).get("content")).contains("Existing configuration"))
            throw new AssertionError("Existing system message overwritten");
        System.out.println("Unified intent and analysis follow-up smoke: PASS");
    }
}
