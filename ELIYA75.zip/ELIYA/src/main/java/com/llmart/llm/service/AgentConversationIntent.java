package com.llmart.llm.service;

import java.util.Locale;
import java.util.regex.Pattern;

/**
 * Cheap, local routing for unambiguous conversational Agent instructions.
 * Unclassified instructions execute normally; no separate intent-model call is needed.
 * The original user text always remains the authoritative scope.
 */
final class AgentConversationIntent {
    enum Kind { PLAN_PREVIEW, CONTINUE_PLAN, DIRECT }

    private static final Pattern CONTINUATION = Pattern.compile(
            "^(?:ok(?:ay)?|yes|yes please|please continue|continue|go ahead|proceed|" +
            "please proceed|start execution|start implementation|execute (?:it|the plan)|" +
            "implement (?:it|the plan)|do it|looks good(?:,? (?:proceed|continue))?|" +
            "approved|i approve|yes,? (?:go ahead|proceed|implement it|execute it))\\s*[!.]*$",
            Pattern.CASE_INSENSITIVE);
    private static final Pattern PREVIEW_REQUEST = Pattern.compile(
            "\\b(?:create|generate|write|prepare|draft|give|provide|show|share|suggest|review|" +
            "improve|outline|propose|design)\\b.{0,90}\\b(?:prompt|implementation plan|" +
            "execution plan|action plan|proposed plan|plan for (?:implementation|execution))\\b",
            Pattern.CASE_INSENSITIVE | Pattern.DOTALL);
    private static final Pattern PLAN_HEADER = Pattern.compile(
            "^(?:(?:here is|here's|this is) (?:my |the )?(?:execution |implementation )?plan|" +
            "(?:my |the )?(?:execution |implementation )?plan\\s*[:\\-]|" +
            "review (?:my|this|the) plan\\b|i (?:will|want to) share (?:my|the) plan\\b)", Pattern.CASE_INSENSITIVE | Pattern.DOTALL);
    private static final Pattern DIRECT_ARTIFACT = Pattern.compile(
            "\\b(?:save|write|create|generate|produce)\\b.{0,100}\\b[\\w.-]+\\.(?:md|txt|docx|xlsx|pptx|pdf|json|java|ts|py)\\b|" +
            "\\b(?:review|check) (?:my |this |the )?plan\\b.{0,60}\\b(?:and )?(?:implement|fix|apply|execute|make changes|create files)\\b",
            Pattern.CASE_INSENSITIVE | Pattern.DOTALL);
    private static final Pattern EXECUTE_NOW = Pattern.compile(
            "\\b(?:execute|apply|implement|start implementing|run|fix|code|make the changes)\\b.{0,35}" +
            "\\b(?:now|directly|immediately|this plan|following plan|these steps)\\b|" +
            "\\b(?:execute|implement|apply) (?:it|this|my|the|following) plan\\b|" +
            "\\b(?:execute|implement|apply) it\\b",
            Pattern.CASE_INSENSITIVE | Pattern.DOTALL);

    private AgentConversationIntent() { }

    static Kind classify(String text) {
        String prompt = text == null ? "" : text.strip();
        if (CONTINUATION.matcher(prompt).matches()) return Kind.CONTINUE_PLAN;
        if (EXECUTE_NOW.matcher(prompt).find() || DIRECT_ARTIFACT.matcher(prompt).find()) return Kind.DIRECT;
        if (PREVIEW_REQUEST.matcher(prompt).find() || PLAN_HEADER.matcher(prompt).find()) return Kind.PLAN_PREVIEW;
        return Kind.DIRECT;
    }

    /** Distinguish an answer to a pending question from a fresh explicit instruction. */
    static boolean looksLikeIndependentInstruction(String text) {
        if (text == null || text.isBlank()) return false;
        String low = text.strip().toLowerCase(Locale.ROOT);
        return Pattern.compile("^(?:please\\s+)?(?:fix|implement|execute|create|generate|" +
                "run|delete|remove|write|migrate|refactor|explain|analy[sz]e|investigate|" +
                "summari[sz]e|review|cancel|stop|new task)\\b", Pattern.CASE_INSENSITIVE)
                .matcher(low).find();
    }

    /** A simple read-only question can skip the planning model entirely. */
    static boolean isFastReadOnly(String text) {
        if (text == null || text.isBlank()) return false;
        if (classify(text) != Kind.DIRECT) return false;
        String low = text.strip().toLowerCase(Locale.ROOT);
        if (AgentPlanRelevance.isReadOnlyAnalysisRequest(text)) return true;
        if ((low.startsWith("how ") || low.startsWith("why ") || low.startsWith("tell me ") ||
                low.startsWith("can you explain ") || low.startsWith("can you tell ")) &&
                !Pattern.compile("\\b(?:implement|fix|modify|edit|delete|migrate|refactor|execute|run|" +
                        "generate|build|save|write|update|change)\\b", Pattern.CASE_INSENSITIVE).matcher(low).find())
            return true;
        return false;
    }
}
