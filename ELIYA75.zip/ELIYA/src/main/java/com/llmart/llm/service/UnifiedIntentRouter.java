package com.llmart.llm.service;

import com.llmart.llm.dto.ChatMode;
import java.util.regex.Pattern;

/**
 * Conservative intent selection for the single-message composer.
 * Read-only questions never mutate a workspace. Explicit action requests and
 * affirmative replies to an offered implementation enter the existing Agent
 * approval/verification pipeline. Legacy chat/agent API clients are unchanged.
 */
public final class UnifiedIntentRouter {
    private UnifiedIntentRouter() {}

    private static final Pattern ANALYSIS_FIRST = Pattern.compile(
            "^(?:please\\s+)?(?:how|why|what|when|where|which|who|explain|describe|analyse|analyze|review|investigate|assess|compare|evaluate|suggest|recommend|brainstorm|tell me|show me|is it|can we|could we|should we|would it|plan|design a plan|create a plan|draft a plan)\\b",
            Pattern.CASE_INSENSITIVE);
    private static final Pattern EXPLICIT_ACTION = Pattern.compile(
            "\\b(?:implement|apply (?:the|these|those|this|your) (?:changes|fixes|recommendations|plan)|fix (?:the|this|these|my|our)|modify|refactor|migrate|deploy|run (?:the|my|our|all) (?:tests?|build|commands?|pipeline)|execute (?:the|this|these)|rollback|roll back|undo (?:the|last)|update (?:the|this|these|my|our)|integrate|create (?:a|an|the|new) (?:file|folder|component|app|application|module|endpoint|document|report|test|script|project|branch)|generate (?:the|a|an) (?:files?|documents?|reports?|tests?|code|application)|write (?:the|a|an) (?:files?|tests?|code|program|script)|add (?:the|this|these|a|an|new) (?:feature|function|class|method|endpoint|file|test)|remove (?:the|these|this) (?:files?|code|feature)|delete (?:the|these|this) (?:files?|folder)|change (?:the|this|these|my|our) (?:code|files?|implementation)|start (?:implementing|coding|the implementation))\\b",
            Pattern.CASE_INSENSITIVE);
    private static final Pattern ACTION_START = Pattern.compile(
            "^(?:please\\s+)?(?:implement|fix|refactor|migrate|deploy|execute|rollback|undo|update|integrate|generate|code|build|patch|correct|repair|modify|change|remove|delete|edit|apply|run|create|write|add)\\b",
            Pattern.CASE_INSENSITIVE);
    private static final Pattern DEEPER_ANALYSIS = Pattern.compile(
            "^(?:please\\s+)?(?:analyse|analyze|investigate|explore|research|explain|compare|review|look deeper|dig deeper|more analysis|further analysis|not yet|don't implement|do not implement|hold off)\\b",
            Pattern.CASE_INSENSITIVE);
    private static final Pattern AFFIRMATIVE = Pattern.compile(
            "^(?:yes|yep|sure|ok|okay|go ahead|proceed|do it|sounds good|let's do it|lets do it|please do|start)\\s*[.!]?$",
            Pattern.CASE_INSENSITIVE);
    private static final Pattern IMPLEMENTATION_OFFER = Pattern.compile(
            "(?is)(?:would you like|do you want|shall i|should i|want me to).{0,190}?(?:implement|apply|fix|make the changes|proceed with implementation)");

    public static ChatMode resolve(String declaredMode, String userMessage, String previousAssistant) {
        // Legacy callers and independent Terminal sessions explicitly select a mode.
        if (!"auto".equalsIgnoreCase(String.valueOf(declaredMode))
                && !"unified".equalsIgnoreCase(String.valueOf(declaredMode))) {
            return ChatMode.from(declaredMode);
        }
        String prompt = userMessage == null ? "" : userMessage.strip();
        if (prompt.isEmpty()) return ChatMode.CHAT;
        // A negated action is a hard read-only request, not an authorization.
        if (Pattern.compile("(?i)\\b(?:do not|don\'t|dont|never|not now|no need to)\\s+(?:\\w+\\s+){0,3}?(?:implement|apply|fix|edit|modify|change|delete|run|write)\\b")
                .matcher(prompt).find()) return ChatMode.CHAT;
        boolean combinedExecution = EXPLICIT_ACTION.matcher(prompt).find()
                && Pattern.compile("(?i)\\b(?:and|then|also)\\s+(?:please\\s+)?(?:implement|fix|apply|update|create|generate|write|run|execute)\\b")
                        .matcher(prompt).find();
        if (combinedExecution) return ChatMode.AGENT;
        if (DEEPER_ANALYSIS.matcher(prompt).find()) return ChatMode.CHAT;
        if (AFFIRMATIVE.matcher(prompt).matches()) {
            String offer = previousAssistant == null ? "" : previousAssistant;
            // "Yes" to an either/or question is ambiguous. Do not infer write approval.
            return IMPLEMENTATION_OFFER.matcher(offer).find()
                    && !Pattern.compile("(?is)\\bor\\s+(?:investigate|analyse|analyze|explore|compare|research|review)").matcher(offer).find()
                    ? ChatMode.AGENT : ChatMode.CHAT;
        }
        if (ANALYSIS_FIRST.matcher(prompt).find()) {
            // Requests like "analyse the gaps and implement the fixes" explicitly authorize work.
            return EXPLICIT_ACTION.matcher(prompt).find() &&
                   Pattern.compile("(?i)\\b(?:and|then|also)\\s+(?:please\\s+)?(?:implement|fix|apply|update|create|generate|write|run|execute)\\b").matcher(prompt).find()
                    ? ChatMode.AGENT : ChatMode.CHAT;
        }
        if (ACTION_START.matcher(prompt).find() || EXPLICIT_ACTION.matcher(prompt).find()) return ChatMode.AGENT;
        return ChatMode.CHAT;
    }
}
