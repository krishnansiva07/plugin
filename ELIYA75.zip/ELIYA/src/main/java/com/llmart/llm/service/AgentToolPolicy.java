package com.llmart.llm.service;

import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * Runtime-enforced, agent-specific tool policy. A subagent cannot widen parent run permissions.
 * Unclassified new tools are treated as mutating, not silently granted to read-only agents.
 */
public final class AgentToolPolicy {
    private AgentToolPolicy() { }

    private static final Set<String> SHELL = Set.of("bash", "build", "test", "check", "resource_bash",
            "resource_build", "resource_test", "resource_check", "process_start", "process_stop", "http_request");
    private static final Set<String> MUTATIONS = Set.of("edit", "write", "copy", "move", "delete",
            "apply_patch", "workspace_rollback", "resource_edit", "resource_write", "resource_delete",
            "resource_copy", "resource_move", "presentation_create", "confluence_compose",
            "documentation_module_update", "documentation_exclude_module", "documentation_init", "documentation_discover",
            "work_items_init", "work_items_add", "work_items_update", "workspace_checkpoint",
            "workspace_profile_refresh", "todo_update", "todowrite");

    public static String category(String tool, AgentToolRegistry registry) {
        if (tool == null) return "edit";
        if (tool.startsWith("mcp__") || tool.equals("mcp") || tool.equals("tool_search") || tool.equals("mcp_status")) return "mcp";
        if (tool.equals("task") || tool.equals("task_parallel") || tool.equals("agent_catalog")) return "task";
        if (SHELL.contains(tool)) return "bash";
        if (MUTATIONS.contains(tool)) return "edit";
        if (tool.equals("lsp")) return "lsp";
        if (registry.isParallelReadOnly(tool)) return "read";
        return "edit"; // safe default for future/unknown actions
    }

    public static String decision(AgentProfileService.AgentProfile profile, String tool, AgentToolRegistry registry) {
        if (profile == null || profile.permissions() == null || profile.permissions().isEmpty()) return "inherit";
        Map<String,String> permissions = profile.permissions();
        String normalized = registry.canonical(tool);
        String category = category(normalized, registry);
        String rule = permissions.get(normalized.toLowerCase(Locale.ROOT));
        if (rule == null) rule = permissions.get(category);
        if (rule == null) rule = permissions.get("*");
        return rule == null ? "inherit" : rule;
    }

    public static boolean visible(AgentProfileService.AgentProfile profile, String tool, AgentToolRegistry registry) {
        return !"deny".equals(decision(profile, tool, registry));
    }
}
