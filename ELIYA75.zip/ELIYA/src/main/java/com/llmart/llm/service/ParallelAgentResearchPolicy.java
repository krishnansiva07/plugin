package com.llmart.llm.service;

import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/** Read-only, independent investigations can run concurrently; mutations and reviews stay gated. */
public final class ParallelAgentResearchPolicy {
    private ParallelAgentResearchPolicy() {}
    public record Task(String agent, String prompt) {}
    private static final Set<String> PROFILES = Set.of("explore", "analyst", "architect", "reviewer");
    // Deliberate allowlist: even a project-overridden agent profile cannot gain write/shell/MCP access.
    private static final Set<String> READ_TOOLS = Set.of("inspect_workspace", "workspace_profile", "list",
            "glob", "grep", "file_info", "file_index", "read", "read_chunk", "read_many", "code_impact",
            "workspace_status", "workspace_diff", "attachment_list", "attachment_read", "attachment_search",
            "knowledge_search", "knowledge_read", "skill_catalog", "skill", "lsp", "lsp_status",
            "resource_catalog", "resource_read", "resource_grep", "documentation_coverage",
            "documentation_knowledge", "documentation_module", "verification_failures");
    public static boolean safeTool(String tool) { return tool != null && READ_TOOLS.contains(tool); }
    public static List<Task> validate(List<Task> tasks) {
        if (tasks == null || tasks.size() != 2)
            throw new IllegalArgumentException("Parallel research requires exactly two independent read-only investigations");
        HashSet<String> seen = new HashSet<>();
        for (Task t : tasks) {
            if (t == null || t.agent() == null || !PROFILES.contains(t.agent().toLowerCase(Locale.ROOT)))
                throw new IllegalArgumentException("Parallel research allows only explore, analyst, architect or reviewer");
            if (t.prompt() == null || t.prompt().isBlank() || t.prompt().length() > 4000)
                throw new IllegalArgumentException("Each parallel research prompt must contain 1–4000 characters");
            if (!seen.add(t.agent().toLowerCase(Locale.ROOT)))
                throw new IllegalArgumentException("Use different specialist agents for independent parallel work");
        }
        return List.copyOf(tasks);
    }
}
