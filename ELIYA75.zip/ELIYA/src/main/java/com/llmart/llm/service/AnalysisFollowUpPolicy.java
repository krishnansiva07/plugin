package com.llmart.llm.service;

import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

/** Keep substantive analysis conversational without interrupting active edits. */
public final class AnalysisFollowUpPolicy {
    private AnalysisFollowUpPolicy() {}
    private static final Pattern ANALYSIS = Pattern.compile(
            "(?i)\\b(analys[ei]s|analy[sz]e|investigat(?:e|ion)|review|assess|diagnos(?:e|is)|architectur(?:e|al)|gap(?:s| analysis)?|root cause|compare|evaluat(?:e|ion)|recommendation|suggest improvement|how (?:can|should|would) (?:we|i) improve)\\b");
    private static final Pattern ALREADY_OFFERS_CHOICE = Pattern.compile(
            "(?is)(?:would you like|do you want|shall i|should i|want me to).{0,220}?(?:implement|apply|fix|investigate further|analyse further|analyze further|explore further|deeper analysis)");

    public static void instruct(List<Map<String, Object>> context) {
        String guidance = "ELIYA UNIFIED CONVERSATION: Answer the user's actual request thoroughly. "
                + "When your response delivers substantive analysis, end with ONE specific, natural question based on the findings: "
                + "ask whether they want you to implement the recommendations, investigate a named uncertainty in more depth, "
                + "or evaluate another concrete approach. Do not repeat generic yes/no prompts, offer irrelevant implementation, "
                + "or ask this after greetings, quick facts, or completed execution. "
                + "Treat replies such as 'implement the first two', 'go ahead', or 'analyse the third problem further' "
                + "as context-dependent instructions. Analysis is read-only unless the user explicitly authorizes changes. "
                + "Do not imply files were edited or commands run if you have not used the execution workflow.";
        if (!context.isEmpty() && "system".equals(context.get(0).get("role"))
                && context.get(0).get("content") instanceof String existing) {
            java.util.LinkedHashMap<String,Object> first = new java.util.LinkedHashMap<>(context.get(0));
            first.put("content", existing + "\n\n" + guidance);
            context.set(0, first);
        } else {
            context.add(0, Map.of("role", "system", "content", guidance));
        }
    }

    /** Guaranteed fallback only for recognizable analytical requests; the model normally chooses the better question. */
    public static String finish(String answer, String prompt) {
        if (answer == null || answer.isBlank() || prompt == null || !ANALYSIS.matcher(prompt).find()) return answer;
        if (ALREADY_OFFERS_CHOICE.matcher(answer.substring(Math.max(0, answer.length() - 650))).find()) return answer;
        return answer
                + "\n\nWould you like me to implement the recommended changes, investigate the findings further, or compare alternative approaches?";
    }
}
