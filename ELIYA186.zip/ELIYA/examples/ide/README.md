# Eliya in your IDE and terminal

Type `eliya` in any terminal inside a project — including the IntelliJ and VS Code terminals — and the chat opens
full screen in that terminal, like opencode. Nothing to install beyond the `eliya` command.

| You want | Run |
|---|---|
| Chat in this terminal (full screen) | `eliya` (starts in Analyse) or `eliya agent` |
| Chat in a separate terminal window | `eliya --new-terminal` |
| The browser UI as its own app window | `eliya --window` |
| The browser UI in a tab (previous `eliya`) | `eliya web` |
| A simple line chat (scripts, odd consoles) | `eliya --line` |

Windows consoles: the line chat is the default; `eliya --tui` starts the full-screen chat (preview, uses a small
PowerShell helper for key input). Set `ELIYA_UI=tui` to make it the default, or `ELIYA_UI=classic` to keep the
previous behaviour everywhere.

## VS Code
1. Merge `vscode/settings.json` into your user settings: adds an **Eliya** terminal profile (terminal `+` menu).
2. Merge `vscode/keybindings.json`: **Ctrl+Alt+E** opens the chat as an editor tab, **Ctrl+Alt+W** the app window.
3. Copy `vscode/tasks.json` to `.vscode/tasks.json` for the window / new-terminal tasks.

## IntelliJ IDEA (and other JetBrains IDEs)
- Simplest: open the built-in terminal (Alt+F12) and type `eliya`.
- Menu entries: copy `intellij/Eliya.xml` into the IDE's `tools` folder (path in the file) and restart. You get
  **Tools > External Tools > Eliya chat (new terminal window)** and **Eliya app window**; give them shortcuts in
  Settings > Keymap > External Tools.

## Keys in the chat
Enter send · Alt+Enter / Ctrl+J / Shift+Enter new line · paste keeps multi-line text in the box · Tab switches
Analyse/Agent · PgUp/PgDn scroll · Ctrl+O copy the last answer · `/help` for all commands · Ctrl+D exit.
While a task runs: Enter adds your message to the running Agent task, Ctrl+Q queues it as the next task, Ctrl+C stops.
Select text with the mouse to copy it (hold Shift in terminals that need it).
