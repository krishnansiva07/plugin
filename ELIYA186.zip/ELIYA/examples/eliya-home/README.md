# ELIYA home folder examples

Copy these into `~/.eliya/` (Windows: `%USERPROFILE%\.eliya\`), or point `ELIYA_HOME` / `ELIYA_POLICY` elsewhere.

| File | Purpose |
| --- | --- |
| `config.properties` | Model settings, written by `eliya setup` |
| `policy.json` | Command allow/ask/deny rules and a run budget for every Agent run |
| `schedule.json` | Recurring unattended jobs (daily time + weekdays, or every N minutes) |
| `tasks/inbox/*.md` | Drop a task file here and ELIYA runs it (rename the `.sample` to `.md`) |

Task files move to `tasks/processing/`, then `tasks/done/` or `tasks/failed/` with the result appended.
Reports: `<ELIYA data dir>/autonomous-runs/<id>/report.md`.
