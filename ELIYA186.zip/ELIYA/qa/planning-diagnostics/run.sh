#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../.."
TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT
javac --release 17 -encoding UTF-8 -d "$TMP" \
  src/main/java/com/llmart/llm/service/AgentPlanRelevance.java \
  src/main/java/com/llmart/llm/service/AgentPlanJsonEnvelope.java \
  src/main/java/com/llmart/llm/service/AgentPlanRecovery.java \
  src/main/java/com/llmart/llm/service/AgentPlanSpecificity.java \
  src/main/java/com/llmart/llm/service/MigrationIntent.java \
  src/main/java/com/llmart/llm/service/AgentFailureAdvisor.java \
  src/main/java/com/llmart/llm/service/AgentPlanningTerms.java \
  src/main/java/com/llmart/llm/service/AgentConversationIntent.java \
  src/main/java/com/llmart/llm/service/AgentReadOnlySearchPolicy.java \
  qa/planning-diagnostics/PlanningDiagnosticsSmoke.java
java -cp "$TMP" com.llmart.llm.service.PlanningDiagnosticsSmoke
python3 - <<'PY'
from pathlib import Path
s=Path('src/main/java/com/llmart/llm/service/AgentService.java').read_text()
p=Path('src/main/java/com/llmart/llm/service/AgentPlanParser.java').read_text()
assert 'AgentPlanSpecificity.mismatch(task, parsed)' in p, 'specificity gate not wired to planner'
stage=Path('src/main/java/com/llmart/llm/service/AgentPlanningStage.java').read_text()
assert 'AgentPlanParser.judge(' in stage, 'planner does not use the specificity-checking parser'
assert 'AgentFailureAdvisor.append(finalMessage, completionStatus,' in s, 'failure advice not wired to finalization'
assert 'protectedSnapshots.begin(' in s, 'protected changes must remain guarded'
assert 'readOnlyMissingEvidenceRecoveryAttempted' in s, 'one safe read-only recovery attempt missing'
assert 'Never edit files during this read-only investigation' in s, 'read-only recovery must not mutate'
print('PASS: planner and result delivery integrations wired, rollback still present')
PY
