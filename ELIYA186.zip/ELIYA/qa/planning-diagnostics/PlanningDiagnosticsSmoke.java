package com.llmart.llm.service;
import java.util.List;

public class PlanningDiagnosticsSmoke {
    private static int checks;
    private static void check(boolean condition, String label) {
        if (!condition) throw new AssertionError(label);
        checks++;
    }
    public static void main(String[] args) {
        String migration = "Migrate Java Selenium to Playwright TypeScript. Step 1: Analyze legacy classes and test coverage. " +
                "Step 2: Build a Cucumber TS framework. Step 3: Migrate scenarios and reusable components. " +
                "Step 4: Run tests and report evidence; do not delete legacy files.";
        var reconstructed = AgentPlanRecovery.fromUserRequest(migration, false);
        check(reconstructed.size() == 5, "four named phases plus verification must be retained");
        check(reconstructed.get(0).contains("Analyze legacy classes"), "phase 1 lost");
        check(reconstructed.get(1).contains("Build a Cucumber TS framework"), "phase 2 lost");
        check(reconstructed.get(2).contains("Migrate scenarios"), "phase 3 lost");
        check(reconstructed.get(3).contains("Run tests"), "phase 4 lost");
        check(AgentPlanSpecificity.mismatch(migration, List.of(
                "Inspect the relevant live workspace and fulfill every requirement in the original user request",
                "Verify all deliverables and requested outcomes against the full original user request"))
                .contains("generic"), "template plan should be rejected");
        check(AgentPlanSpecificity.mismatch(migration, List.of(
                "Analyze requirements", "Implement requested changes", "Test changes"))
                .contains("generic"), "three generic planner steps must be rejected");
        check(AgentPlanSpecificity.mismatch(migration, List.of(
                "Inspect Selenium Java classes and map reusable Playwright TS APIs",
                "Create requested Cucumber TS framework and migrate scenarios",
                "Run Playwright tests and report results")).isEmpty(), "concrete plan rejected");
        check(AgentPlanSpecificity.mismatch("Use Jira MCP to create a BRD .docx", List.of(
                "Inspect repository files", "Write BRD .docx", "Verify files"))
                .contains("jira"), "missing named MCP source not detected");
        check(AgentPlanSpecificity.mismatch("Use Jira MCP to create a BRD .docx", List.of(
                "Retrieve Jira MCP evidence", "Write BRD .docx", "Verify artifact"))
                .isBlank(), "explicitly grounded document plan rejected");
        check(AgentPlanSpecificity.mismatch("Generate Word .docx and Markdown .md from Jira MCP tickets", List.of(
                "Retrieve Jira MCP tickets", "Create Word .docx", "Verify Word .docx"))
                .contains("Markdown"), "missing requested Markdown not detected");
        String longRequest = "Migrate the full codebase safely.\n" +
                java.util.stream.IntStream.rangeClosed(1, 70)
                  .mapToObj(i -> "Phase " + i + ": Process module" + i + " without skipping tests")
                  .collect(java.util.stream.Collectors.joining("\n"));
        var longPlan = AgentPlanRecovery.fromUserRequest(longRequest, false);
        check(longPlan.size() <= 49, "unbounded plan step list");
        check(longPlan.toString().contains("module1") && longPlan.toString().contains("module70"),
                "large phased task silently lost an early or late phase");
        String denied = AgentFailureAdvisor.append("Denied: shell permission required", "blocked", "Permission denied to run command", "");
        check(denied.contains("approval") && denied.contains("Do not weaken"), "safe permission recovery missing");
        String evidence = AgentFailureAdvisor.append("Need independent test result", "blocked", "missing evidence", "not verified on current revision");
        check(evidence.contains("Missing proof is not") && evidence.contains("Run the exact missing"), "verification is falsely labeled defect");
        String provider = AgentFailureAdvisor.append("Provider timeout", "failed", "Model/provider unavailable", "");
        check(provider.contains("connection settings"), "provider repair missing");
        String verified = AgentFailureAdvisor.append("Pass with evidence", "completed", "", "");
        check(verified.equals("Pass with evidence"), "successful results must not be modified");
        System.out.println("PASS plan specificity + phase-preserving recovery + reasoned error guidance: " + checks + " checks");
    }
}
