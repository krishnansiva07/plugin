const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');
const source = fs.readFileSync(path.join(__dirname,'../src/main/resources/static/app.js'),'utf8');
const start = source.indexOf('function terminalRecoveryFocus(reason) {');
const end = source.indexOf('\nfunction terminalFastPatch(detail)',start);
const markup = source.slice(start,end);
function dialog() {
  const classSet = new Set(['hidden']);
  const dock = {innerHTML:'',textContent:'',classList:{add(x){classSet.add(x);},remove(x){classSet.delete(x);}},querySelector(){return null;}};
  const terminalUi = {visible:true,decisionSignature:null,recoveryDismissed:new Set()};
  const escape = s => String(s).replace(/[&<>"']/g, x=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[x]));
  const ctx = {$:()=>dock, terminalUi, esc:escape, requestAnimationFrame() {}};
  const render = vm.runInNewContext(markup+'\nrenderTerminalDecision',ctx);
  return {render,dock,terminalUi,classSet};
}
test('live clarification renders accessible modal and real user choices',()=>{
  const d = dialog();
  d.render({id:'id1',status:'needs_input',question:{kind:'clarification',id:'q1',reason:'Which suite?',choices:['Smoke','Regression','Cancel']}});
  assert.match(d.dock.innerHTML,/role="dialog" aria-modal="true"/);
  assert.match(d.dock.innerHTML,/data-answer-choice="Smoke"/);
  assert.match(d.dock.innerHTML,/data-answer-choice="Cancel"/);
  assert.match(d.dock.innerHTML,/id="terminalClarificationText"/);
  assert.equal(d.classSet.has('hidden'),false);
});
test('exhausted failed run offers linked investigation without lying about run status',()=>{
  const d=dialog();
  const run={id:'id1',runId:'run2',status:'blocked',error:'Actual failure: browser driver unavailable'};
  d.render(run);
  assert.match(d.dock.innerHTML,/browser driver unavailable/);
  assert.match(d.dock.innerHTML,/Inspect test setup, fix and rerun/);
  assert.match(d.dock.innerHTML,/data-terminal-recovery="continue"/);
  assert.match(d.dock.innerHTML,/data-terminal-recovery="report"/);
  assert.match(d.dock.innerHTML,/data-terminal-recovery="dismiss"/);
  assert.equal(run.status,'blocked');
});
test('dismissed failed decision stays dismissed for same run but not a new run',()=>{
  const d=dialog();
  d.render({id:'id1',runId:'r1',status:'blocked'});
  const signature=d.terminalUi.decisionSignature;
  d.terminalUi.recoveryDismissed.add(signature);d.terminalUi.decisionSignature=null;
  d.render({id:'id1',runId:'r1',status:'blocked'});
  assert.equal(d.classSet.has('hidden'),true);
  d.render({id:'id1',runId:'r2',status:'failed'});
  assert.equal(d.classSet.has('hidden'),false);
});
test('verified completion never opens a question',()=>{
  const d=dialog();d.render({id:'id1',status:'completed'});
  assert.equal(d.classSet.has('hidden'),true);
});
test('question reason is HTML-escaped',()=>{
  const d=dialog();d.render({id:'id1',status:'needs_input',question:{kind:'clarification',id:'q2',reason:'<img src=x onerror=alert(1)>',choices:['OK']}});
  assert.doesNotMatch(d.dock.innerHTML,/<img src=/);
  assert.match(d.dock.innerHTML,/&lt;img/);
});
test('rejected plan still offers correction, retaining evidence',()=>{
  const d=dialog();d.render({id:'id1',runId:'r1',status:'needs_input',question:{kind:'plan_correction',reason:'Plan missed suite setup'}});
  assert.match(d.dock.innerHTML,/Correct plan and continue/);
  assert.match(d.dock.innerHTML,/Plan missed suite setup/);
});
