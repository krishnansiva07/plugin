package com.llmart.llm.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * ELIYA180: fault injection for the audit's release blockers — no false completion from empty/skipped tests,
 * missing/unreadable/tampered ledgers, oversized/unreadable files, unresolved scope or truncated discovery — plus a
 * >125k-file workspace with >5k candidate items and old API at the first, middle and last file.
 */
public final class AuditFixes {
    private static final ObjectMapper JSON = new ObjectMapper();
    private static int passed;

    static void check(boolean condition, String name) {
        if (!condition) throw new AssertionError("FAILED: " + name);
        passed++;
    }

    static JsonNode args(String json) throws Exception { return JSON.readTree(json); }

    public static void main(String[] a) throws Exception {
        verifierRejectsEmptyTests();
        testEvidenceFromReports();
        migrationNeverPassesWithoutTests();
        failClosedLedger();
        unscannableFiles();
        scopeFailsClosed();
        truncatedDiscoveryIsIncomplete();
        completionAuditReopens();
        largeWorkspace(Integer.parseInt(a.length > 0 ? a[0] : "130000"));
        System.out.println("ELIYA180 audit fixes: " + passed + " checks passed");
    }

    // ---------------------------------------------------------------------------------------- P0-C verifier

    static void verifierRejectsEmptyTests() {
        check(!AgentVerificationPolicy.checkShell("bash", "mvn test", "exitCode=0;\nTests run: 0, Failures: 0, Errors: 0, Skipped: 0", false).passed(),
                "Maven zero tests rejected");
        check(!AgentVerificationPolicy.checkShell("bash", "mvn test -DskipTests", "exitCode=0;\nBUILD SUCCESS", false).passed(), "skipTests rejected");
        check(!AgentVerificationPolicy.checkShell("bash", "./mvnw verify -Dmaven.test.skip=true", "exitCode=0;\nBUILD SUCCESS", false).passed(), "maven.test.skip rejected");
        check(AgentVerificationPolicy.checkShell("bash", "mvn test -DskipTests=false", "exitCode=0;\nTests run: 3, Failures: 0, Errors: 0, Skipped: 0", false).passed(),
                "explicit skipTests=false allowed");
        check(!AgentVerificationPolicy.checkShell("bash", "python3 -m pytest -q", "exitCode=0;\ncollected 0 items\n\nno tests ran in 0.01s", false).passed(), "pytest none rejected");
        check(!AgentVerificationPolicy.checkShell("bash", "npx jest", "exitCode=0;\nTests:       0 total", false).passed(), "jest none rejected");
        check(!AgentVerificationPolicy.checkShell("bash", "node --test", "exitCode=0;\n# tests 0\n# pass 0", false).passed(), "node none rejected");
        check(!AgentVerificationPolicy.checkShell("test", "", "exitCode=0;\nRan 0 tests in 0.000s\n\nOK", false).passed(), "unittest none rejected");
        check(!AgentVerificationPolicy.checkShell("bash", "go test ./...", "exitCode=0;\n?   example.com/x [no test files]", false).passed(), "go none rejected");
        check(AgentVerificationPolicy.checkShell("bash", "python3 -m unittest", "exitCode=0;\nRan 4 tests in 0.01s\n\nOK", false).passed(), "unittest 4 accepted");
        check(AgentVerificationPolicy.checkShell("bash", "javac -d out Main.java", "exitCode=0;", false).passed(), "non-test verifier unaffected");
        check(AgentTestEvidence.fromOutput("[INFO] Tests run: 2, Failures: 0, Errors: 0, Skipped: 1, Time elapsed: 0.1 s - in a.B\n[INFO] Results:\n[INFO] Tests run: 2, Failures: 0, Errors: 0, Skipped: 1").executed() == 1,
                "surefire summary minus skipped");
        check(AgentTestEvidence.fromOutput("Tests:       1 failed, 4 passed, 5 total").executed() == 5, "jest counts");
        check(AgentTestEvidence.fromOutput("3 scenarios (3 passed)").executed() == 3 || AgentTestEvidence.fromOutput("3 Scenarios (3 passed)").executed() == 3, "cucumber counts");
        check(!AgentTestEvidence.fromOutput("BUILD SUCCESS").known(), "unknown when no count");
    }

    static void testEvidenceFromReports() throws Exception {
        Path root = Files.createTempDirectory("eliya180-reports");
        long start = System.currentTimeMillis();
        Path reports = Files.createDirectories(root.resolve("target/surefire-reports"));
        Files.writeString(reports.resolve("TEST-a.BTest.xml"), "<?xml version=\"1.0\"?><testsuite name=\"a.BTest\" tests=\"3\" skipped=\"1\" failures=\"0\" errors=\"0\"></testsuite>");
        AgentTestEvidence.Count count = AgentTestEvidence.fromReports(root, start);
        check(count.known() && count.executed() == 2 && count.source().contains("JUnit XML"), "reports counted: " + count.describe());
        check(!AgentTestEvidence.fromReports(root, System.currentTimeMillis() + 60_000).known(), "old reports ignored");
        Files.writeString(reports.resolve("TEST-a.BTest.xml"), "<testsuite name=\"a.BTest\" tests=\"0\"></testsuite>");
        check(AgentTestEvidence.fromReports(root, start).none(), "zero in reports");
    }

    // ------------------------------------------------------------------------------- migration verification

    static MigrationEngine engine(String output, int exit) {
        return new MigrationEngine((dir, command, timeout, cancelled) -> new MigrationEngine.CommandResult(exit, output, false));
    }

    static Path javaxProject() throws Exception {
        Path root = Files.createTempDirectory("eliya180-mig");
        Files.createDirectories(root.resolve("src/a"));
        Files.writeString(root.resolve("src/a/A.java"), "import javax.servlet.http.HttpServlet;\nclass A {}\n");
        return root;
    }

    static void migrate(Path root) throws Exception {
        Files.writeString(root.resolve("src/a/A.java"), "import jakarta.servlet.http.HttpServlet;\nclass A {}\n");
    }

    static void migrationNeverPassesWithoutTests() throws Exception {
        // Exit 0 but no test count and no reports → not verified.
        Path root = javaxProject();
        MigrationEngine e = engine("BUILD SUCCESS", 0);
        e.init(root, args("{\"verifyCommand\":\"mvn test\"}"), "Migrate from javax to jakarta");
        check(e.baseline(root, args("{}"), () -> false).text().contains("NO TEST COUNT"), "baseline warns about missing test evidence");
        migrate(root);
        e.update(root, args("{\"items\":[\"src/a/A.java\"],\"status\":\"migrated\"}"));
        MigrationEngine.Outcome v = e.verify(root, args("{}"), () -> false);
        check(v.failed() && v.text().contains("NO_TEST_EVIDENCE"), "no test evidence → not verified: " + v.text());
        check(e.completionProblem(root, true) != null, "not complete");
        // Zero tests reported → not verified.
        MigrationEngine zero = engine("Tests run: 0, Failures: 0, Errors: 0, Skipped: 0", 0);
        check(zero.verify(root, args("{}"), () -> false).text().contains("NO_TESTS_EXECUTED"), "zero tests → not verified");
        // Skip flags rejected outright.
        check(zero.verify(root, args("{\"command\":\"mvn test -DskipTests\"}"), () -> false).text().startsWith("REJECTED"), "skip flag rejected in verify");
        check(zero.baseline(root, args("{\"command\":\"mvn test -Dmaven.test.skip=true\"}"), () -> false).text().startsWith("REJECTED"), "skip flag rejected in baseline");
        // Real evidence → verified.
        MigrationEngine ok = engine("Tests run: 4, Failures: 0, Errors: 0, Skipped: 0", 0);
        check(!ok.verify(root, args("{}"), () -> false).failed() && ok.completionProblem(root, true) == null, "with executed tests → verified");
        // No verification command: not verified unless the user approved residue-only.
        Path none = javaxProject();
        MigrationEngine noCmd = engine("", 0);
        noCmd.init(none, args("{\"verifyCommand\":\"\"}"), "Migrate from javax to jakarta");
        migrate(none);
        noCmd.update(none, args("{\"items\":[\"src/a/A.java\"],\"status\":\"migrated\"}"));
        MigrationEngine.Outcome noCmdOut = noCmd.verify(none, args("{}"), () -> false); check(noCmdOut.text().contains("NO_TEST_COMMAND"), "no command → not verified: " + noCmdOut.text());
        Path approved = javaxProject();
        noCmd.init(approved, args("{\"verifyCommand\":\"\",\"residueOnly\":true,\"noTestsReason\":\"legacy module has no tests; reviewed manually\"}"), "Migrate from javax to jakarta");
        migrate(approved);
        noCmd.update(approved, args("{\"items\":[\"src/a/A.java\"],\"status\":\"migrated\"}"));
        MigrationEngine.Outcome residueOnly = noCmd.verify(approved, args("{}"), () -> false);
        check(!residueOnly.failed() && residueOnly.text().contains("residue-only verification approved"), "approved residue-only → verified with label");
        check(noCmd.status(approved).text().contains("Verification without tests approved"), "approval visible in status");
        // Maven projects that skip tests by default get an override.
        Path pom = Files.createTempDirectory("eliya180-pom");
        Files.writeString(pom.resolve("pom.xml"), "<project><properties><maven.test.skip>true</maven.test.skip></properties></project>");
        String detected = MigrationEngine.detectVerifyCommand(pom, "");
        check(detected.equals("mvn test -Dmaven.test.skip=false") && !detected.contains("-q"), "maven skip default overridden: " + detected);
    }

    // ---------------------------------------------------------------------------------------- P0-B ledger

    static void failClosedLedger() throws Exception {
        Path root = javaxProject();
        MigrationEngine e = engine("Tests run: 1, Failures: 0, Errors: 0, Skipped: 0", 0);
        e.init(root, args("{\"verifyCommand\":\"mvn test\"}"), "Migrate from javax to jakarta");
        Path csv = root.resolve("migration/javax-to-jakarta/items.csv");
        // Tampering: mark everything verified by hand.
        Files.writeString(csv, Files.readString(csv).replace(",pending,", ",verified,"));
        MigrationEngine.Problem tampered = e.completionProblem(root, true);
        check(tampered != null && tampered.text().contains("changed outside the migration tools"), "tampered ledger rejected");
        // Missing ledger while the run used the engine → problem, not success.
        Files.delete(root.resolve("migration/ACTIVE"));
        check(e.completionProblem(root, true) != null && e.completionProblem(root, true).text().contains("missing or unreadable"), "missing ledger fails closed");
        check(e.completionProblem(root, false) == null, "no migration at all → nothing to block");
        // Unreadable spec.json → problem.
        Files.writeString(root.resolve("migration/ACTIVE"), "javax-to-jakarta\n");
        Files.writeString(root.resolve("migration/javax-to-jakarta/spec.json"), "{broken");
        MigrationEngine.Problem unreadable = e.completionProblem(root, true);
        check(unreadable != null && !unreadable.unfinished(), "unreadable ledger fails closed");
    }

    static void unscannableFiles() throws Exception {
        Path root = Files.createTempDirectory("eliya180-unscannable");
        Files.createDirectories(root.resolve("src"));
        // Latin-1 (not UTF-8) file with the old API: still scanned.
        Files.write(root.resolve("src/Legacy.java"), "// café\nimport javax.servlet.Filter;\n".getBytes(StandardCharsets.ISO_8859_1));
        // Oversized file with the old API: becomes an UNSCANNED item, never a silent pass.
        System.setProperty("eliya.migration.max.scan.mb", "1");
        StringBuilder big = new StringBuilder("import javax.servlet.Servlet;\n");
        while (big.length() < 1_300_000) big.append("// filler line to make the file large\n");
        Files.writeString(root.resolve("src/Huge.java"), big);
        MigrationEngine e = engine("Tests run: 2, Failures: 0, Errors: 0, Skipped: 0", 0);
        MigrationEngine.Outcome init = e.init(root, args("{\"verifyCommand\":\"mvn test\"}"), "Migrate from javax to jakarta");
        List<MigrationEngine.Item> items = MigrationEngine.readItems(root.resolve("migration/javax-to-jakarta"));
        check(items.stream().anyMatch(i -> i.path.equals("src/Legacy.java") && i.residue == 1), "Latin-1 file scanned");
        check(items.stream().anyMatch(i -> i.path.equals("src/Huge.java") && i.kind.startsWith("UNSCANNED")), "oversized file listed as UNSCANNED: " + init.text());
        check(init.text().contains("could not be scanned"), "coverage mentions unscanned files");
        Files.writeString(root.resolve("src/Legacy.java"), "import jakarta.servlet.Filter;\n");
        e.update(root, args("{\"items\":[\"src/Legacy.java\",\"src/Huge.java\"],\"status\":\"migrated\"}"));
        MigrationEngine.Outcome v = e.verify(root, args("{}"), () -> false);
        check(v.failed() && v.text().contains("could not be scanned (TOO_LARGE"), "oversized file cannot be verified by scan: " + v.text());
        check(e.completionProblem(root, true).unfinished(), "unscanned item keeps the migration open");
        e.update(root, args("{\"items\":[\"src/Huge.java\"],\"status\":\"not_applicable\",\"note\":\"generated file, regenerated from the new schema\"}"));
        check(e.completionProblem(root, true) == null, "explicit, explained decision closes it");
        System.clearProperty("eliya.migration.max.scan.mb");
    }

    // ---------------------------------------------------------------------------------------- R4 scope

    static void scopeFailsClosed() throws Exception {
        Path root = javaxProject();
        MigrationEngine e = engine("Tests run: 1, Failures: 0, Errors: 0, Skipped: 0", 0);
        MigrationEngine.Outcome wrong = e.init(root, args("{\"scope\":[\"billing\"],\"verifyCommand\":\"mvn test\"}"), "Migrate from javax to jakarta");
        check(wrong.failed() && wrong.text().startsWith("SCOPE NOT FOUND") && !Files.exists(root.resolve("migration")), "unresolved scope stops, nothing created");
        MigrationEngine.Outcome broadened = e.init(root, args("{\"scope\":[\"billing\"],\"broadenScope\":true,\"verifyCommand\":\"mvn test\"}"), "Migrate from javax to jakarta");
        check(!broadened.failed() && broadened.text().contains("Work items: 1"), "explicitly broadened scope proceeds");
    }

    // ---------------------------------------------------------------------------------------- P0-A coverage

    static void truncatedDiscoveryIsIncomplete() throws Exception {
        Path root = Files.createTempDirectory("eliya180-trunc");
        Files.createDirectories(root.resolve("src"));
        for (int i = 0; i < 300; i++) Files.writeString(root.resolve("src/F" + i + ".java"), i % 3 == 0 ? "import javax.servlet.Filter;\n" : "class F {}\n");
        System.setProperty("eliya.migration.max.visited", "100");
        MigrationEngine e = engine("Tests run: 1, Failures: 0, Errors: 0, Skipped: 0", 0);
        MigrationEngine.Outcome init = e.init(root, args("{\"verifyCommand\":\"mvn test\"}"), "Migrate from javax to jakarta");
        System.clearProperty("eliya.migration.max.visited");
        check(init.text().contains("COVERAGE INCOMPLETE") && init.text().contains("TRAVERSAL LIMIT"), "traversal limit reported: " + init.text());
        // Even with every tracked item verified, completion is refused.
        for (MigrationEngine.Item item : MigrationEngine.readItems(root.resolve("migration/javax-to-jakarta")))
            Files.writeString(root.resolve(item.path), "import jakarta.servlet.Filter;\n");
        e.update(root, args("{\"items\":" + JSON.writeValueAsString(MigrationEngine.readItems(root.resolve("migration/javax-to-jakarta")).stream().map(i -> i.id).toList()) + ",\"status\":\"migrated\"}"));
        check(!e.verify(root, args("{}"), () -> false).failed(), "tracked items verified");
        MigrationEngine.Problem p = e.completionProblem(root, true);
        check(p != null && p.text().contains("coverage is incomplete"), "incomplete coverage blocks completion");
        // Item cap behaves the same way.
        System.setProperty("eliya.migration.max.items", "10");
        Path capped = Files.createTempDirectory("eliya180-cap");
        Files.createDirectories(capped.resolve("src"));
        for (int i = 0; i < 40; i++) Files.writeString(capped.resolve("src/G" + i + ".java"), "import javax.servlet.Filter;\n");
        MigrationEngine.Outcome capInit = e.init(capped, args("{\"verifyCommand\":\"mvn test\"}"), "Migrate from javax to jakarta");
        System.clearProperty("eliya.migration.max.items");
        check(capInit.text().contains("LEDGER LIMIT REACHED"), "item cap reported as incomplete coverage");
    }

    static void completionAuditReopens() throws Exception {
        Path root = javaxProject();
        MigrationEngine e = engine("Tests run: 1, Failures: 0, Errors: 0, Skipped: 0", 0);
        e.init(root, args("{\"verifyCommand\":\"mvn test\"}"), "Migrate from javax to jakarta");
        migrate(root);
        e.update(root, args("{\"items\":[\"src/a/A.java\"],\"status\":\"migrated\"}"));
        e.verify(root, args("{}"), () -> false);
        check(e.completionProblem(root, true) == null, "ledger says done");
        check(e.completionAudit(root) == 0, "audit finds nothing new");
        // A file the inventory never saw, and a verified file that regressed.
        Files.writeString(root.resolve("src/a/Late.java"), "import javax.servlet.Filter;\n");
        Files.writeString(root.resolve("src/a/A.java"), "import javax.servlet.http.HttpServlet;\nclass A {}\n");
        check(e.completionAudit(root) == 2, "audit reopens the new file and the regression");
        MigrationEngine.Problem p = e.completionProblem(root, true);
        check(p != null && p.unfinished(), "work reopened, run continues");
        check(MigrationEngine.readItems(root.resolve("migration/javax-to-jakarta")).stream().anyMatch(i -> i.path.equals("src/a/Late.java")), "late file added to the ledger");
    }

    // ---------------------------------------------------------------------------------------- large workspace

    static void largeWorkspace(int files) throws Exception {
        Path root = Files.createTempDirectory("eliya180-large");
        int perDir = 1000, matchEvery = 21;
        Set<Integer> special = Set.of(0, files / 2, files - 1);
        long t0 = System.currentTimeMillis();
        int expected = 0;
        for (int i = 0; i < files; i++) {
            Path dir = root.resolve("src/m" + (i / perDir));
            if (i % perDir == 0) Files.createDirectories(dir);
            boolean old = special.contains(i) || i % matchEvery == 7;
            if (old) expected++;
            Files.writeString(dir.resolve("F" + i + ".java"), old ? "import javax.servlet.http.HttpServlet;\nclass F" + i + " {}\n" : "class F" + i + " {}\n");
        }
        long created = System.currentTimeMillis() - t0;
        MigrationEngine e = engine("Tests run: 1, Failures: 0, Errors: 0, Skipped: 0", 0);
        long t1 = System.currentTimeMillis();
        MigrationEngine.Outcome init = e.init(root, args("{\"verifyCommand\":\"mvn test\"}"), "Migrate from javax to jakarta");
        long discovery = System.currentTimeMillis() - t1;
        List<MigrationEngine.Item> items = MigrationEngine.readItems(root.resolve("migration/javax-to-jakarta"));
        Set<String> paths = items.stream().map(i -> i.path).collect(Collectors.toSet());
        check(items.size() == expected && (files < 125_000 || expected > 5_000), "all " + expected + " candidate items discovered (got " + items.size() + ")");
        check(paths.contains("src/m0/F0.java") && paths.contains("src/m" + (files / 2 / perDir) + "/F" + (files / 2) + ".java") &&
                paths.contains("src/m" + ((files - 1) / perDir) + "/F" + (files - 1) + ".java"), "first, middle and last file found");
        check(!init.text().contains("INCOMPLETE") && init.text().contains(files + " files visited"), "coverage complete: " + init.text().lines().filter(l -> l.startsWith("Coverage")).findFirst().orElse(""));
        long t2 = System.currentTimeMillis();
        int reopened = e.completionAudit(root);
        long audit = System.currentTimeMillis() - t2;
        check(reopened == 0, "completion audit over the whole workspace agrees with the ledger");
        System.out.println("Large workspace: " + files + " files (created in " + created + " ms), " + expected + " items, discovery " + discovery +
                " ms, completion audit " + audit + " ms");
        try (var walk = Files.walk(root)) { walk.sorted(java.util.Comparator.reverseOrder()).forEach(p -> p.toFile().delete()); }
    }
}
