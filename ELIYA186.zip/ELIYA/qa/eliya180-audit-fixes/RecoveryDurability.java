package com.llmart.llm.service;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

/** ELIYA180: staged recovery survives a JVM restart; persistence failures are visible. */
public final class RecoveryDurability {
    static int passed;
    static void check(boolean c, String n) { if (!c) throw new AssertionError("FAILED: " + n); passed++; }

    public static void main(String[] a) throws Exception {
        Path store = Files.createTempDirectory("eliya180-runs");
        AgentRunService runs = new AgentRunService(store);
        AgentRunService.AgentRun run = runs.start("conv-1", "proj-1");
        run.setObjective("Migrate billing to Spring Boot 3");
        run.setPlan(List.of("Inventory billing", "Migrate billing", "Verify billing"));
        run.finish("failed");
        AgentRecoveryStore staging = new AgentRecoveryStore(runs);
        staging.stage(run);
        check(Files.isRegularFile(store.resolve("recovery-staged.properties")), "staged marker written");
        // "Restart": new services from the same folder; the in-memory seed is gone.
        AgentRunService rebooted = new AgentRunService(store);
        AgentRecoveryStore afterRestart = new AgentRecoveryStore(rebooted);
        AgentRunService.RecoverySeed seed = afterRestart.consume("conv-1", "proj-1");
        check(seed != null && seed.priorRunId().equals(run.id()) && seed.plan().size() == 3, "seed rebuilt after restart");
        check(afterRestart.consume("conv-1", "proj-1") == null, "used at most once");
        // Workspace fallback after restart (new conversation, same project).
        AgentRunService.AgentRun run2 = rebooted.start("conv-2", "proj-2");
        run2.setPlan(List.of("Inspect the orders module", "Migrate the orders module"));
        run2.finish("blocked");
        new AgentRecoveryStore(rebooted).stage(run2);
        check(new AgentRecoveryStore(new AgentRunService(store)).consume("other-conversation", "proj-2") != null, "workspace fallback after restart");
        // Persistence failure is visible: make the store directory unwritable by replacing it with a file.
        Path brokenStore = Files.createTempDirectory("eliya180-broken");
        AgentRunService broken = new AgentRunService(brokenStore);
        AgentRunService.AgentRun r = broken.start("c", "p");
        Files.walk(brokenStore).sorted(java.util.Comparator.reverseOrder()).forEach(p -> p.toFile().delete());
        Files.writeString(brokenStore, "not a directory");
        r.setObjective("trigger a snapshot write");
        r.finish("completed");
        check(!broken.persistenceFailure(r.id()).isBlank(), "persistence failure reported: " + broken.persistenceFailure(r.id()));
        System.out.println("ELIYA180 recovery durability: " + passed + " checks passed");
    }
}
