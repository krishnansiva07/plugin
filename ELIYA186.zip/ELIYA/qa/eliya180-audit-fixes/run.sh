#!/bin/bash
# ELIYA180: the audit's release blockers as fault-injection tests (no false completion, fail-closed ledger,
# explicit scan outcomes, scope, coverage, durable recovery) + a >125k-file migration discovery run.
# ELIYA180_LARGE_FILES overrides the large-workspace size (default 130000).
set -euo pipefail
BASE="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
HERE="$BASE/qa/eliya180-audit-fixes"
S="$BASE/src/main/java/com/llmart/llm/service"
source "$BASE/qa/lib/qa-env.sh"
JACKSON_CP="$(eliya_jackson_cp)"
[ -n "$JACKSON_CP" ] || eliya_skip "ELIYA180 audit-fix checks (Jackson not found; set ELIYA_JACKSON_CP)"
OUT="$(mktemp -d)"; trap 'rm -rf "$OUT"' EXIT
mkdir -p "$OUT/stubs/org/springframework/stereotype" "$OUT/stubs/com/llmart/llm/service" "$OUT/a" "$OUT/b"
echo 'package org.springframework.stereotype; public @interface Service {}' > "$OUT/stubs/org/springframework/stereotype/Service.java"
mkdir -p "$OUT/stubs/org/springframework/beans/factory/annotation"
echo 'package org.springframework.beans.factory.annotation; public @interface Autowired { boolean required() default true; }' > "$OUT/stubs/org/springframework/beans/factory/annotation/Autowired.java"
echo 'package com.llmart.llm.service; public class ProtectedRunSnapshotService { public void discard(String id) {} }' > "$OUT/stubs/com/llmart/llm/service/ProtectedRunSnapshotService.java"
printf 'package com.llmart.llm.service;\npublic class OpenAiCompatibleClient { public record Usage(long inputTokens, long outputTokens, long totalTokens, long cachedInputTokens, long cacheWriteTokens, boolean providerReported) {} }\n' > "$OUT/stubs/com/llmart/llm/service/OpenAiCompatibleClient.java"
javac --release 17 -proc:none -encoding UTF-8 -cp "$JACKSON_CP" -d "$OUT/a" \
  "$S/MigrationIntent.java" "$S/MigrationPacks.java" "$S/MigrationEngine.java" "$S/AgentTestEvidence.java" "$S/AgentTestWorkflow.java" \
  "$S/AgentCancelledException.java" "$S/AgentVerificationPolicy.java" "$HERE/AuditFixes.java" 2>&1 | grep -v -E '^Note:|Picked up' || true
java -Xmx1g -cp "$JACKSON_CP:$OUT/a" com.llmart.llm.service.AuditFixes "${ELIYA180_LARGE_FILES:-130000}" 2>&1 | grep -v 'Picked up'
javac --release 17 -proc:none -encoding UTF-8 -d "$OUT/b" $(find "$OUT/stubs" -name '*.java') \
  "$S/AgentCancelledException.java" "$S/AgentStageMetrics.java" "$S/TokenActivityLedger.java" "$S/AgentRunService.java" \
  "$S/AgentRecoveryStore.java" "$S/AgentRecoveryContext.java" "$S/AgentQuestionAnswers.java" "$HERE/RecoveryDurability.java" 2>&1 | grep -v -E '^Note:|Picked up' || true
java -cp "$OUT/b" com.llmart.llm.service.RecoveryDurability 2>&1 | grep -v 'Picked up'
