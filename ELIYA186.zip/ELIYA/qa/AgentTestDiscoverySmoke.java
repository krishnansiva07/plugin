package com.llmart.llm.service;

import java.nio.file.*;
import java.nio.charset.StandardCharsets;

/** Standalone smoke test; no Spring or external model is needed. */
public final class AgentTestDiscoverySmoke {
    private static void require(boolean condition, String description) {
        if (!condition) throw new AssertionError(description);
    }
    public static void main(String[] args) throws Exception {
        Path root = Files.createTempDirectory("eliya-test-preflight-");
        try {
            Files.writeString(root.resolve("pom.xml"), """
                <project><properties><maven.test.skip>true</maven.test.skip></properties>
                  <dependencies><dependency><artifactId>testng</artifactId></dependency>
                    <dependency><artifactId>cucumber-java</artifactId></dependency></dependencies></project>
                """, StandardCharsets.UTF_8);
            Files.writeString(root.resolve("testng.xml"), "<suite name=\"s\"></suite>");
            Path javaTest = root.resolve("src/test/java/demo/LoginTest.java");
            Files.createDirectories(javaTest.getParent());
            Files.writeString(javaTest, "class LoginTest {}", StandardCharsets.UTF_8);
            Path javaConfig = root.resolve("src/test/java/demo/Hooks.java");
            Files.writeString(javaConfig, "class Hooks { String url=System.getenv(\"GRID_URL\"); }", StandardCharsets.UTF_8);
            String report = AgentTestDiscovery.inspect(root, "");
            require(report.contains("runner=Maven + TestNG dependency/config + Cucumber"),"Maven framework discovery");
            require(report.contains("POM disables tests"),"Maven skip hazard detected");
            require(report.contains("LoginTest.java"),"Test entry point detected");
            require(report.contains("GRID_URL"),"Environment variable name detected");
            require(!report.contains("String url="),"No source code disclosed");
            boolean outsideRejected = false;
            try { AgentTestDiscovery.inspect(root, "../"); } catch (SecurityException expected) { outsideRejected=true; }
            require(outsideRejected,"Traversal outside workspace rejected");
            Path ts = root.resolve("web");Files.createDirectories(ts);
            Files.writeString(ts.resolve("package.json"),"{\"name\":\"ui\",\"devDependencies\":{\"@playwright/test\":\"1\"}}");
            Files.writeString(ts.resolve("playwright.config.ts"),"export default {};");
            String playwright = AgentTestDiscovery.inspect(root,"web");
            require(playwright.contains("+ Playwright"),"Playwright framework detected");
            require(playwright.contains("npx --no-install playwright test"),"Non-installing fallback command");
            require(playwright.contains("node_modules not detected"),"Dependency preflight hint");
            Files.writeString(ts.resolve(".env"),"PRIVATE_PASSWORD=DO_NOT_LEAK");
            require(!AgentTestDiscovery.inspect(root,"web").contains("DO_NOT_LEAK"),"Do not read .env values");
            System.out.println("AgentTestDiscovery smoke: PASS (9 assertions)");
        } finally {
            try (var files = Files.walk(root)) {
                files.sorted(java.util.Comparator.reverseOrder()).forEach(f->{try{Files.deleteIfExists(f);}catch(Exception ignored){}});
            }
        }
    }
}
