#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
command -v java >/dev/null || { echo 'Java 17 or newer is required on PATH.' >&2; exit 1; }
./build-jar.sh
exec java -jar target/eliya.jar --browser
