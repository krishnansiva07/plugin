package com.llmart.llm.service;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.function.BooleanSupplier;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Bounded, read-only test-definition inventory from the active workspace's cached index.
 * No filesystem traversal, model inference, shell commands, or test execution occurs here.
 * Counts source declarations, NOT runtime cases expanded by data providers/loops/projects.
 */
final class WorkspaceTestInventory {
    private static final int MAX_TEST_FILES = 5_000;
    private static final long MAX_SOURCE_BYTES = 1_000_000;
    private static final long MAX_TOTAL_BYTES = 24_000_000;
    private static final int MAX_REPORTED_FILES = 50;
    private static final Pattern COUNT_REQUEST = Pattern.compile(
            "(?is)(?:\\b(?:how many|number of|count|total(?: number)? of)\\b.{0,110}\\b(?:tests?|test cases?|specs?|scenarios?)\\b" +
            "|\\b(?:tests?|test cases?|specs?|scenarios?)\\b.{0,80}\\b(?:count|total|number)\\b)");
    private static final Pattern RESULT_REQUEST = Pattern.compile(
            "(?i)\\b(?:passed|failed|passing|failing|executed|running|run results?|test results?|success rate|pass rate)\\b");
    private static final Pattern JS_TEST = Pattern.compile(
            "(?<![\\w$.])(?:test|it)\\s*(?:\\.\\s*(?:only|skip|fixme|fail))?\\s*\\(");
    private static final Pattern JS_EACH = Pattern.compile(
            "(?<![\\w$.])(?:test|it)\\s*\\.\\s*(?:(?:only|skip|fixme)\\s*\\.\\s*)?each\\s*\\(");
    private static final Pattern JAVA_TEST = Pattern.compile("(?m)@(?:org\\.(?:junit\\.(?:jupiter\\.api\\.)?|testng\\.annotations\\.))?Test\\b|@ParameterizedTest\\b|@RepeatedTest\\b");
    private static final Pattern FEATURE_SCENARIO = Pattern.compile("(?im)^\\s*(?:Scenario|Scenario Outline|Scenario Template):");
    private static final Pattern PYTHON_TEST = Pattern.compile("(?m)^\\s*(?:async\\s+)?def\\s+test_[a-zA-Z_0-9]+\\s*\\(");

    private WorkspaceTestInventory() {}

    static boolean isCountRequest(String prompt) {
        return prompt != null && COUNT_REQUEST.matcher(prompt).find() && !RESULT_REQUEST.matcher(prompt).find();
    }

    static boolean isTestPath(String relativePath) {
        if (relativePath == null) return false;
        String p = relativePath.replace('\\', '/').toLowerCase(Locale.ROOT);
        String name = p.substring(p.lastIndexOf('/') + 1);
        if (name.matches(".+\\.(spec|test)\\.[cm]?[jt]sx?")) return true;
        if (name.endsWith(".feature")) return true;
        if (name.matches("test_.+\\.py") || name.matches(".+_test\\.py")) return true;
        return name.endsWith(".java") &&
                (p.contains("/src/test/") || p.startsWith("src/test/") ||
                        name.matches(".+(?:test|tests|it)\\.java"));
    }

    static String inspect(Path root, List<String> indexedPaths, boolean indexIncomplete, BooleanSupplier cancelled) {
        if (root == null || indexedPaths == null) return "";
        Path normalizedRoot = root.toAbsolutePath().normalize();
        StringBuilder report = new StringBuilder("\n\nDETERMINISTIC READ-ONLY TEST SOURCE INVENTORY (live file contents; not README inference):\n");
        int matched = 0, inspected = 0, unreadable = 0, definitions = 0, dynamic = 0, reported = 0;
        long totalBytes = 0;
        boolean capped = false;
        List<String> rows = new ArrayList<>();
        Path realRoot;
        try { realRoot = normalizedRoot.toRealPath(); }
        catch (IOException missing) { return report.append("Workspace path is not accessible; no test count can be confirmed.\n").toString(); }
        for (String relative : indexedPaths) {
            if (cancelled != null && cancelled.getAsBoolean()) throw new AgentCancelledException("Test inventory cancelled");
            if (!isTestPath(relative)) continue;
            matched++;
            if (matched > MAX_TEST_FILES || totalBytes >= MAX_TOTAL_BYTES) { capped = true; break; }
            Path target = normalizedRoot.resolve(relative).normalize();
            if (!target.startsWith(normalizedRoot)) { unreadable++; continue; }
            try {
                // A symlink nested within the workspace must not escape the user's mapped root.
                Path realTarget = target.toRealPath();
                if (!realTarget.startsWith(realRoot) || !Files.isRegularFile(realTarget)) { unreadable++; continue; }
                long bytes = Files.size(realTarget);
                if (bytes > MAX_SOURCE_BYTES || bytes > MAX_TOTAL_BYTES - totalBytes) { unreadable++; continue; }
                String content = Files.readString(realTarget, StandardCharsets.UTF_8);
                totalBytes += bytes;
                int count = declarationCount(relative, content);
                if (count < 0) { unreadable++; continue; }
                inspected++;
                definitions += count;
                boolean expanded = dynamicCases(relative, content);
                if (expanded) dynamic++;
                if (reported++ < MAX_REPORTED_FILES)
                    rows.add("- " + relative + ": " + count + " static test declaration(s)" + (expanded ? " (runtime expansion possible)" : ""));
            } catch (IOException | SecurityException unreadableFile) { unreadable++; }
        }
        report.append("Inspected source files: ").append(inspected)
                .append("; static test declarations: ").append(definitions)
                .append("; unreadable/oversized/missing: ").append(unreadable)
                .append("; candidate test files found in index: ").append(matched).append(".\n");
        for (String row : rows) report.append(row).append('\n');
        if (reported > MAX_REPORTED_FILES)
            report.append("... ").append(reported - MAX_REPORTED_FILES).append(" additional inspected test file(s) omitted from breakdown.\n");
        if (inspected == 0) report.append("No readable indexed test files were inspected; a zero test count is NOT confirmed.\n");
        else if (unreadable == 0 && !capped && !indexIncomplete && dynamic == 0)
            report.append("Count is complete for supported test definitions in the indexed workspace snapshot, based on current readable files.\n");
        else report.append("COUNT IS A LOWER-BOUND/STATIC INVENTORY, NOT AN EXACT RUNTIME TEST COUNT.\n");
        if (indexIncomplete) report.append("Index reports incomplete scanning; unindexed files may contain additional tests.\n");
        if (capped) report.append("Inventory safety limit reached; remaining indexed test files were NOT counted.\n");
        if (dynamic > 0) report.append("Parameterized/loop/data-driven declarations found in ").append(dynamic)
                .append(" file(s); runner expansion may produce more executable cases.\n");
        report.append("Only source declarations were counted. Tests were NOT run; Playwright projects, data-provider rows, and filtered/skipped cases can change runtime totals. "
                + "For Playwright, `npx playwright test --list` gives the runner-discovered count. "
                + "Answer the user's inventory question directly with the static count and its caveats. "
                + "Do NOT substitute README claims or show migration-success/test-execution verification warnings.\n");
        return report.toString();
    }

    static int declarationCount(String relative, String contents) {
        String path = relative.replace('\\', '/').toLowerCase(Locale.ROOT);
        if (path.endsWith(".feature")) return count(FEATURE_SCENARIO, contents);
        if (path.endsWith(".java")) return count(JAVA_TEST, stripCommentsAndStrings(contents));
        if (path.endsWith(".py")) return count(PYTHON_TEST, stripCommentsAndStrings(contents));
        if (path.matches(".+\\.[cm]?[jt]sx?")) {
            String clean = stripCommentsAndStrings(contents);
            return count(JS_TEST, clean) + count(JS_EACH, clean);
        }
        return -1;
    }

    private static boolean dynamicCases(String relative, String contents) {
        String path = relative.toLowerCase(Locale.ROOT);
        if (path.endsWith(".feature")) return Pattern.compile("(?im)^\\s*Scenario (?:Outline|Template):").matcher(contents).find();
        if (path.endsWith(".java")) return Pattern.compile("(?i)@(?:ParameterizedTest|RepeatedTest)|dataProvider\\s*=|@Test\\s*\\(").matcher(contents).find();
        if (path.endsWith(".py")) return contents.contains("parametrize");
        return JS_EACH.matcher(stripCommentsAndStrings(contents)).find()
                || Pattern.compile("(?s)\\b(?:for|forEach|map)\\s*\\(?[\\s\\S]{0,250}\\b(?:test|it)\\s*\\(").matcher(stripCommentsAndStrings(contents)).find();
    }

    private static int count(Pattern pattern, String source) {
        int n = 0;
        Matcher m = pattern.matcher(source);
        while (m.find()) n++;
        return n;
    }

    /** Keep line breaks, mask comments and string literals so fake test(...) inside them is ignored. */
    static String stripCommentsAndStrings(String text) {
        StringBuilder b = new StringBuilder(text.length());
        int mode = 0; // code, line-comment, block-comment, single, double, template
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i), next = i + 1 < text.length() ? text.charAt(i + 1) : 0;
            if (mode == 0) {
                if (c == '/' && next == '/') { b.append("  "); i++; mode = 1; continue; }
                if (c == '/' && next == '*') { b.append("  "); i++; mode = 2; continue; }
                if (c == '\'' || c == '"' || c == '`') { b.append(' '); mode = c == '\'' ? 3 : c == '"' ? 4 : 5; continue; }
                b.append(c);
            } else if (mode == 1) {
                b.append(c == '\n' ? '\n' : ' ');
                if (c == '\n') mode = 0;
            } else if (mode == 2) {
                if (c == '*' && next == '/') { b.append("  "); i++; mode = 0; }
                else b.append(c == '\n' ? '\n' : ' ');
            } else {
                if (c == '\\' && next != 0) { b.append("  "); i++; continue; }
                b.append(c == '\n' ? '\n' : ' ');
                if ((mode == 3 && c == '\'') || (mode == 4 && c == '"') || (mode == 5 && c == '`')) mode = 0;
            }
        }
        return b.toString();
    }
}
