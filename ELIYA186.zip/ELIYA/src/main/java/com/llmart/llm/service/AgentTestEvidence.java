package com.llmart.llm.service;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.FileVisitResult;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * How many tests actually executed, from runner output or from JUnit-style XML reports written by the run.
 * An exit code of zero with zero (or unknown) executed tests is not test evidence.
 */
final class AgentTestEvidence {

    /** executed = tests that ran (not skipped); -1 = unknown. */
    record Count(int executed, int skipped, int failed, String source) {
        static final Count UNKNOWN = new Count(-1, 0, 0, "");
        boolean known() { return executed >= 0; }
        boolean none() { return executed == 0; }
        String describe() {
            return !known() ? "test count not reported" : executed + " test" + (executed == 1 ? "" : "s") + " executed" +
                    (skipped > 0 ? ", " + skipped + " skipped" : "") + (failed > 0 ? ", " + failed + " failed" : "") +
                    (source.isBlank() ? "" : " (" + source + ")");
        }
    }

    private static final Pattern SUREFIRE = Pattern.compile("(?m)Tests run:\\s*(\\d+),\\s*Failures:\\s*(\\d+),\\s*Errors:\\s*(\\d+),\\s*Skipped:\\s*(\\d+)(.*)$");
    private static final Pattern GRADLE = Pattern.compile("(?m)(\\d+)\\s+tests?\\s+completed(?:,\\s*(\\d+)\\s+failed)?(?:,\\s*(\\d+)\\s+skipped)?");
    private static final Pattern PASSED = Pattern.compile("(?mi)(?:^|[\\s,(])(\\d+)\\s+(?:passed|passing)\\b");
    private static final Pattern FAILED_N = Pattern.compile("(?mi)(?:^|[\\s,(])(\\d+)\\s+(?:failed|failing)\\b");
    private static final Pattern SKIPPED_N = Pattern.compile("(?mi)(?:^|[\\s,(])(\\d+)\\s+(?:skipped|pending)\\b");
    private static final Pattern UNITTEST = Pattern.compile("(?m)^Ran\\s+(\\d+)\\s+tests?\\b");
    private static final Pattern NODE_TEST = Pattern.compile("(?m)^(?:#|ℹ)\\s*tests\\s+(\\d+)\\s*$");
    private static final Pattern NODE_SKIP = Pattern.compile("(?m)^(?:#|ℹ)\\s*skipped\\s+(\\d+)\\s*$");
    private static final Pattern JEST = Pattern.compile("(?m)^Tests:\\s+(?:(\\d+)\\s+failed,\\s+)?(?:(\\d+)\\s+skipped,\\s+)?(?:(\\d+)\\s+passed,\\s+)?(\\d+)\\s+total");
    private static final Pattern DOTNET = Pattern.compile("(?mi)Total tests:\\s*(\\d+)|Passed!\\s+-\\s+Failed:\\s*(\\d+),\\s+Passed:\\s*(\\d+),\\s+Skipped:\\s*(\\d+)");
    private static final Pattern CARGO = Pattern.compile("(?m)test result: \\w+\\.\\s+(\\d+)\\s+passed;\\s+(\\d+)\\s+failed;\\s+(\\d+)\\s+ignored");
    private static final Pattern GO_PASS = Pattern.compile("(?m)^(?:---\\s+PASS:|ok\\s+\\S+)");
    private static final Pattern CUCUMBER = Pattern.compile("(?mi)^(\\d+)\\s+Scenarios?\\s*\\(");
    private static final Pattern ZERO = Pattern.compile("(?i)\\bno tests? (?:to run|found|were found|ran|executed)\\b|\\bcollected 0 items\\b|" +
            "\\bRan 0 tests\\b|\\bno test files\\b|\\b0 (?:tests|passing)\\b|\\bTests run:\\s*0,|\\bno tests matched\\b|\\bNo specs found\\b|" +
            "\\btests are skipped\\b|\\bTests are skipped\\b|\\bSkipping test execution\\b");

    private static final Pattern RUNNER = Pattern.compile(
            "(?i)(?:\\b(?:mvn|mvnw|gradle|gradlew)(?:\\.cmd|\\.bat)?\\b[^\\n]{0,160}\\b(?:test|verify|check|integrationTest)\\b|" +
            "\\b(?:npm|pnpm|yarn|bun)\\s+(?:run\\s+)?(?:test|e2e|spec)(?:\\b|:)|\\b(?:npx|pnpm\\s+exec|yarn)\\s+(?:playwright|jest|vitest|cypress|mocha)\\b|" +
            "\\b(?:pytest|jest|vitest|mocha|cucumber-js|playwright\\s+test)\\b|\\bpython3?\\s+-m\\s+(?:pytest|unittest)\\b|\\bnode\\s+--test\\b|" +
            "\\b(?:go\\s+test|dotnet\\s+test|cargo\\s+test)\\b)");
    private static final Pattern SKIP = Pattern.compile(
            "(?i)(?:-DskipTests(?:=true)?\\b(?!=false)|-Dmaven\\.test\\.skip(?:=true)?\\b(?!=false)|-Dmaven\\.test\\.failure\\.ignore|-DtestFailureIgnore|" +
            "\\s-x\\s+test\\b|--passWithNoTests|--exclude-task\\s+test\\b|--no-tests\\b)");

    private AgentTestEvidence() { }

    /** A command that runs tests (Maven/Gradle/npm/pytest/unittest/node/go/dotnet/cargo/Playwright …). */
    static boolean isRunnerCommand(String command) { return command != null && RUNNER.matcher(command).find(); }

    /** The skip/ignore flag in a test command, or null. */
    static String skipFlag(String command) {
        if (command == null) return null;
        Matcher m = SKIP.matcher(command);
        return m.find() ? m.group().strip() : null;
    }

    /** Executed tests from runner output; UNKNOWN when the runner did not report a count. */
    static Count fromOutput(String output) {
        if (output == null || output.isBlank()) return Count.UNKNOWN;
        Matcher m = SUREFIRE.matcher(output);
        int summaryRun = 0, summarySkip = 0, summaryFail = 0, classRun = 0, classSkip = 0, classFail = 0;
        boolean summary = false, any = false;
        while (m.find()) {
            any = true;
            int run = Integer.parseInt(m.group(1)), fail = Integer.parseInt(m.group(2)) + Integer.parseInt(m.group(3)), skip = Integer.parseInt(m.group(4));
            if (m.group(5) != null && m.group(5).contains(" in ")) { classRun += run; classSkip += skip; classFail += fail; }
            else { summary = true; summaryRun += run; summarySkip += skip; summaryFail += fail; }
        }
        if (any) {
            int run = summary ? summaryRun : classRun, skip = summary ? summarySkip : classSkip, fail = summary ? summaryFail : classFail;
            return new Count(Math.max(0, run - skip), skip, fail, "Maven Surefire summary");
        }
        if ((m = JEST.matcher(output)).find()) {
            int total = Integer.parseInt(m.group(4)), skip = m.group(2) == null ? 0 : Integer.parseInt(m.group(2));
            return new Count(Math.max(0, total - skip), skip, m.group(1) == null ? 0 : Integer.parseInt(m.group(1)), "Jest/Vitest summary");
        }
        if ((m = CARGO.matcher(output)).find()) {
            int passed = 0, failed = 0, ignored = 0;
            m.reset();
            while (m.find()) { passed += Integer.parseInt(m.group(1)); failed += Integer.parseInt(m.group(2)); ignored += Integer.parseInt(m.group(3)); }
            return new Count(passed + failed, ignored, failed, "cargo test");
        }
        if ((m = DOTNET.matcher(output)).find()) {
            if (m.group(1) != null) return new Count(Integer.parseInt(m.group(1)), 0, 0, "dotnet test");
            int failed = Integer.parseInt(m.group(2)), passed = Integer.parseInt(m.group(3)), skipped = Integer.parseInt(m.group(4));
            return new Count(failed + passed, skipped, failed, "dotnet test");
        }
        if ((m = NODE_TEST.matcher(output)).find()) {
            int tests = Integer.parseInt(m.group(1));
            Matcher skip = NODE_SKIP.matcher(output);
            int skipped = skip.find() ? Integer.parseInt(skip.group(1)) : 0;
            return new Count(Math.max(0, tests - skipped), skipped, 0, "node --test");
        }
        if ((m = UNITTEST.matcher(output)).find()) {
            int ran = 0;
            m.reset();
            while (m.find()) ran = Integer.parseInt(m.group(1));
            int skipped = 0;
            Matcher skip = Pattern.compile("(?m)skipped=(\\d+)").matcher(output);
            if (skip.find()) skipped = Integer.parseInt(skip.group(1));
            return new Count(Math.max(0, ran - skipped), skipped, 0, "unittest");
        }
        if ((m = GRADLE.matcher(output)).find()) {
            int total = Integer.parseInt(m.group(1)), skipped = m.group(3) == null ? 0 : Integer.parseInt(m.group(3));
            return new Count(Math.max(0, total - skipped), skipped, m.group(2) == null ? 0 : Integer.parseInt(m.group(2)), "Gradle summary");
        }
        if ((m = CUCUMBER.matcher(output)).find()) {
            int last = 0;
            m.reset();
            while (m.find()) last = Integer.parseInt(m.group(1));
            return new Count(last, 0, 0, "Cucumber scenarios");
        }
        int passed = lastNumber(PASSED, output), failed = lastNumber(FAILED_N, output), skipped = lastNumber(SKIPPED_N, output);
        if (passed >= 0 || failed >= 0)
            return new Count(Math.max(0, passed) + Math.max(0, failed), Math.max(0, skipped), Math.max(0, failed), "runner summary");
        int goPasses = 0;
        m = GO_PASS.matcher(output);
        while (m.find()) goPasses++;
        if (goPasses > 0) return new Count(goPasses, 0, 0, "go test");
        if (ZERO.matcher(output).find()) return new Count(0, 0, 0, "runner reported no tests");
        return Count.UNKNOWN;
    }

    private static int lastNumber(Pattern pattern, String text) {
        Matcher m = pattern.matcher(text);
        int value = -1;
        while (m.find()) value = Integer.parseInt(m.group(1));
        return value;
    }

    /** True when the output explicitly says that no tests ran (even if counts are missing). */
    static boolean saysNoTests(String output) { return output != null && ZERO.matcher(output).find(); }

    private static final Set<String> REPORT_DIRS = Set.of("surefire-reports", "failsafe-reports", "test-results", "test-reports", "junit-reports");
    private static final Pattern SUITE = Pattern.compile("<testsuites?\\b([^>]*)>");
    private static final Pattern ATTR = Pattern.compile("\\b(tests|skipped|failures|errors|disabled)\\s*=\\s*\"(\\d+)\"");

    /** Executed tests from JUnit-style XML reports written at or after {@code sinceMillis}; UNKNOWN when none. */
    static Count fromReports(Path root, long sinceMillis) {
        if (root == null || !Files.isDirectory(root)) return Count.UNKNOWN;
        int[] totals = {0, 0, 0, 0}; // tests, skipped, failed, files
        long since = sinceMillis - 2_000;
        try {
            Files.walkFileTree(root, Set.of(), 9, new SimpleFileVisitor<>() {
                int visited;
                @Override public FileVisitResult preVisitDirectory(Path dir, BasicFileAttributes attrs) {
                    String name = dir.getFileName() == null ? "" : dir.getFileName().toString();
                    if (!dir.equals(root) && (name.equals(".git") || name.equals("node_modules") || name.equals(".venv") || name.equals("venv")))
                        return FileVisitResult.SKIP_SUBTREE;
                    return ++visited > 20_000 ? FileVisitResult.TERMINATE : FileVisitResult.CONTINUE;
                }
                @Override public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) {
                    String name = file.getFileName().toString();
                    Path parent = file.getParent();
                    boolean inReportDir = false;
                    for (Path p = parent; p != null && !p.equals(root); p = p.getParent())
                        if (REPORT_DIRS.contains(p.getFileName().toString())) { inReportDir = true; break; }
                    if (!name.endsWith(".xml") || !(inReportDir || name.startsWith("TEST-") || name.matches("(?i)junit.*\\.xml")))
                        return FileVisitResult.CONTINUE;
                    if (attrs.lastModifiedTime().toMillis() < since || attrs.size() > 20_000_000) return FileVisitResult.CONTINUE;
                    try {
                        String head = new String(Files.readAllBytes(file), StandardCharsets.UTF_8);
                        Matcher suite = SUITE.matcher(head);
                        if (!suite.find()) return FileVisitResult.CONTINUE;
                        Matcher attr = ATTR.matcher(suite.group(1));
                        int tests = 0, skipped = 0, failed = 0;
                        while (attr.find()) {
                            int v = Integer.parseInt(attr.group(2));
                            switch (attr.group(1)) {
                                case "tests" -> tests = v;
                                case "skipped", "disabled" -> skipped += v;
                                default -> failed += v;
                            }
                        }
                        totals[0] += tests; totals[1] += skipped; totals[2] += failed; totals[3]++;
                    } catch (IOException ignored) { }
                    return FileVisitResult.CONTINUE;
                }
                @Override public FileVisitResult visitFileFailed(Path file, IOException exc) { return FileVisitResult.CONTINUE; }
            });
        } catch (IOException ignored) { }
        if (totals[3] == 0) return Count.UNKNOWN;
        return new Count(Math.max(0, totals[0] - totals[1]), totals[1], totals[2], totals[3] + " JUnit XML report" + (totals[3] == 1 ? "" : "s"));
    }

    /** Output count when reported, otherwise the run's XML reports. */
    static Count of(String output, Path root, long sinceMillis) {
        Count fromOutput = fromOutput(output);
        if (fromOutput.known() && fromOutput.executed() > 0) return fromOutput;
        Count reports = fromReports(root, sinceMillis);
        if (reports.known()) return reports;
        return fromOutput;
    }
}
