package com.llmart.llm.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.TimeUnit;
import java.util.function.Predicate;
import java.util.regex.Pattern;

/**
 * Agent tool {@code mcp_configure}: sets up an MCP server end to end — prerequisite check (Node.js/npx), config
 * entry (all projects or this project), MCP master switch, start + tool listing, and for Playwright a browser
 * check/install. Reports a verified result or the exact blocker and fix. The caller handles user approval.
 */
final class McpServerInstaller {

    record CommandResult(int exit, String output) { }

    /** Runs a short local command (node/npx version checks). Replaceable in tests. */
    interface Commands { CommandResult run(List<String> command, Duration timeout); }

    /** What happened. {@code success=false} means the user must act (the text says what). */
    record Outcome(boolean success, String text) { }

    /** Starts/tests servers; implemented by {@link McpManager}, replaceable in tests. */
    interface Servers {
        Path userServersFile();
        boolean masterSwitchOn();
        void enableMasterSwitch();
        McpManager.ServerTest test(Path workspaceRoot, String name);
        String callTool(Path workspaceRoot, String server, String tool) throws Exception;
    }

    static final long SERVER_TIMEOUT_MILLIS = 180_000L; // first npx download can take a while
    private static final Pattern PACKAGE = Pattern.compile("(?:@[a-z0-9][a-z0-9._-]*/)?[a-z0-9][a-z0-9._-]*(?:@[a-z0-9._-]+)?");
    private static final List<String> BROWSERS = List.of("chrome", "firefox", "webkit", "msedge");
    private static final ObjectMapper JSON = new ObjectMapper();

    private final Servers servers;
    private final Commands commands;
    private final boolean windows;
    private final boolean mac;
    private final Map<String, String> env;
    private final Predicate<Path> exists;

    McpServerInstaller(Servers servers, Commands commands, String osName, Map<String, String> env, Predicate<Path> exists) {
        this.servers = servers;
        this.commands = commands;
        String os = osName == null ? "" : osName.toLowerCase(Locale.ROOT);
        this.windows = os.contains("win");
        this.mac = os.contains("mac");
        this.env = env == null ? Map.of() : env;
        this.exists = exists;
    }

    static McpServerInstaller forManager(McpManager mcp) {
        Servers servers = new Servers() {
            public Path userServersFile() { return mcp.userServersFile(); }
            public boolean masterSwitchOn() { return mcp.globallyEnabled(); }
            public void enableMasterSwitch() { mcp.enableMasterSwitch(); }
            public McpManager.ServerTest test(Path root, String name) { return mcp.testServer(root, name); }
            public String callTool(Path root, String server, String tool) throws Exception {
                return String.valueOf(mcp.callServerTool(root, server, tool, null));
            }
        };
        return new McpServerInstaller(servers, McpServerInstaller::runCommand, System.getProperty("os.name", ""),
                System.getenv(), Files::exists);
    }

    static CommandResult runCommand(List<String> command, Duration timeout) {
        try {
            Process process = new ProcessBuilder(command).redirectErrorStream(true).start();
            process.getOutputStream().close();
            byte[] out = process.getInputStream().readNBytes(8192);
            if (!process.waitFor(timeout.toMillis(), TimeUnit.MILLISECONDS)) { process.destroyForcibly(); return new CommandResult(-1, "timed out"); }
            return new CommandResult(process.exitValue(), new String(out, StandardCharsets.UTF_8).strip());
        } catch (Exception failure) {
            return new CommandResult(-1, String.valueOf(failure.getMessage()));
        }
    }

    /** Short description for the approval prompt. */
    String approvalDetail(JsonNode args, Path workspaceRoot) {
        String server = text(args, "server");
        Optional<McpKnownServers.Known> known = McpKnownServers.byId(server);
        String title = known.map(McpKnownServers.Known::title).orElse(server.isBlank() ? "an MCP server" : server);
        boolean project = "project".equalsIgnoreCase(text(args, "scope"));
        String file = project ? (workspaceRoot == null ? ".opencode/mcp.json in this project"
                : workspaceRoot.resolve(".opencode").resolve("mcp.json").toString()) : servers.userServersFile().toString();
        String run = known.map(k -> "npx " + String.join(" ", k.baseArgs())).orElse(text(args, "package").isBlank()
                ? text(args, "url") : "npx -y " + text(args, "package"));
        return "Configure " + title + ": check Node.js, add it to " + file + ", turn the MCP master switch on, and start `" +
                run + "` (downloads from npm the first time)" +
                (known.map(k -> k.id().equals("playwright")).orElse(false) ? "; install a browser if none is found" : "");
    }

    Outcome configure(Path workspaceRoot, JsonNode args) {
        String server = text(args, "server");
        String packageName = text(args, "package");
        String url = text(args, "url");
        Optional<McpKnownServers.Known> known = McpKnownServers.byId(server);
        if (known.isEmpty() && packageName.isBlank() && url.isBlank()) {
            McpKnownServers.Known guess = McpKnownServers.mentionedIn(server).stream().findFirst().orElse(null);
            if (guess != null) known = Optional.of(guess);
        }
        if (known.isEmpty() && packageName.isBlank() && url.isBlank())
            return new Outcome(false, "UNKNOWN MCP SERVER: '" + server + "'. " + McpKnownServers.catalogText());
        if (!packageName.isBlank() && !PACKAGE.matcher(packageName.toLowerCase(Locale.ROOT)).matches())
            return new Outcome(false, "INVALID PACKAGE NAME: " + packageName + " (expected an npm package such as @scope/server-name)");
        if (!url.isBlank() && !url.matches("https?://\\S+"))
            return new Outcome(false, "INVALID URL: " + url + " (expected http:// or https://)");
        String name = known.map(McpKnownServers.Known::id).orElseGet(() -> sanitize(server.isBlank()
                ? (packageName.isBlank() ? url.replaceAll("^https?://", "") : packageName) : server));
        String title = known.map(McpKnownServers.Known::title).orElse(name);
        String scope = text(args, "scope").toLowerCase(Locale.ROOT);
        boolean project = scope.equals("project");
        if (project && workspaceRoot == null)
            return new Outcome(false, "BLOCKED: scope=project needs a project folder. Use scope=user, or select a workspace first.");
        List<String> report = new ArrayList<>();

        // 1. Prerequisites
        boolean usesNpx = url.isBlank();
        if (usesNpx) {
            String minNode = known.map(McpKnownServers.Known::minNode).orElse("18.0");
            CommandResult node = commands.run(List.of(windows ? "node.exe" : "node", "--version"), Duration.ofSeconds(15));
            if (node.exit() != 0)
                return new Outcome(false, "BLOCKED: Node.js is not installed or not on PATH (`node --version` failed: " + clip(node.output(), 200) + "). " +
                        title + " runs with npx, which comes with Node.js " + minNode + "+. Install the Node.js LTS from https://nodejs.org, " +
                        "open a new terminal, restart Eliya, then ask again. Nothing was changed.");
            if (!McpKnownServers.nodeAtLeast(node.output(), minNode))
                return new Outcome(false, "BLOCKED: Node.js " + node.output() + " is too old; " + title + " needs Node.js " + minNode +
                        " or newer. Update Node.js (https://nodejs.org LTS), restart Eliya, then ask again. Nothing was changed.");
            CommandResult npx = commands.run(windows ? List.of("cmd.exe", "/c", "npx", "--version") : List.of("npx", "--version"), Duration.ofSeconds(30));
            if (npx.exit() != 0)
                return new Outcome(false, "BLOCKED: npx is not available (`npx --version` failed: " + clip(npx.output(), 200) + "). " +
                        "Reinstall Node.js (npx ships with npm), restart Eliya, then ask again. Nothing was changed.");
            report.add("Prerequisites: Node.js " + node.output() + ", npx " + npx.output());
        }

        // 2. Command line for the server
        List<String> serverArgs = new ArrayList<>();
        String browserNote = "";
        if (known.isPresent()) {
            McpKnownServers.Known k = known.get();
            serverArgs.addAll(k.baseArgs());
            if (k.id().equals("playwright")) {
                String browser = text(args, "browser").toLowerCase(Locale.ROOT);
                if (!browser.isBlank() && !BROWSERS.contains(browser))
                    return new Outcome(false, "INVALID BROWSER: " + browser + " (use chrome, firefox, webkit or msedge). Nothing was changed.");
                if (browser.isBlank() && !installed("chrome") && installed("msedge")) {
                    browser = "msedge";
                    browserNote = "Google Chrome was not found, so Microsoft Edge (installed) is used.";
                }
                if (!browser.isBlank()) serverArgs.add("--browser=" + browser);
                if (headless(args)) serverArgs.add("--headless");
            } else if (k.id().equals("chrome-devtools")) {
                if (headless(args)) serverArgs.add("--headless=true");
            } else if (k.id().equals("filesystem")) {
                if (workspaceRoot == null)
                    return new Outcome(false, "BLOCKED: the filesystem server needs a folder to allow. Select a project workspace first. Nothing was changed.");
                serverArgs.add(workspaceRoot.toAbsolutePath().normalize().toString());
            }
        } else if (!packageName.isBlank()) {
            serverArgs.addAll(List.of("-y", packageName));
        }

        // 3. Write the configuration entry
        Path file = project ? workspaceRoot.resolve(".opencode").resolve("mcp.json") : servers.userServersFile();
        ObjectNode entry = JSON.createObjectNode();
        if (usesNpx) {
            entry.put("type", "local");
            entry.put("command", "npx");
            ArrayNode list = entry.putArray("args");
            serverArgs.forEach(list::add);
        } else {
            entry.put("type", "remote");
            entry.put("url", url);
        }
        entry.put("enabled", true);
        entry.put("timeout", SERVER_TIMEOUT_MILLIS);
        boolean replaced;
        try { replaced = writeEntry(file, name, entry); }
        catch (IOException failure) {
            return new Outcome(false, "BLOCKED: could not write " + file + ": " + failure.getMessage());
        }
        report.add("Config: " + (replaced ? "updated" : "added") + " entry \"" + name + "\" in " + file + " → " +
                (usesNpx ? "npx " + String.join(" ", serverArgs) : url));
        if (!browserNote.isBlank()) report.add("Browser: " + browserNote);

        // 4. Master switch
        boolean wasOn = servers.masterSwitchOn();
        if (!wasOn) servers.enableMasterSwitch();
        report.add("MCP master switch: " + (wasOn ? "already on" : "turned on"));

        // 5. Start and list tools
        McpManager.ServerTest test = servers.test(workspaceRoot, name);
        if (!test.connected()) {
            report.add("Connection: FAILED — " + clip(test.error(), 600));
            return new Outcome(false, "MCP CONFIGURED BUT NOT CONNECTED: " + title + "\n" + String.join("\n", report) +
                    "\nLikely cause and fix: " + diagnose(test.error(), title) +
                    "\nThe configuration is kept, so the next attempt only needs the fix above. Do not report this task as completed.");
        }
        report.add("Connection: server started; " + test.tools().size() + " tools: " + clip(String.join(", ", test.tools()), 500));

        // 6. Playwright browser
        if (known.map(k -> k.id().equals("playwright")).orElse(false)) {
            String browser = serverArgs.stream().filter(a -> a.startsWith("--browser=")).map(a -> a.substring(10)).findFirst().orElse("chrome");
            boolean systemBrowser = browser.equals("chrome") || browser.equals("msedge"); // firefox/webkit are Playwright builds
            boolean present = systemBrowser && installed(browser);
            boolean install = args.path("installBrowser").isBoolean() ? args.path("installBrowser").asBoolean() : !present;
            if (!install) {
                report.add("Browser: " + (present ? browser + " found on this computer" : browser + " not checked (installBrowser=false)"));
            } else if (test.tools().contains("browser_install")) {
                try {
                    String result = servers.callTool(workspaceRoot, name, "browser_install");
                    boolean failed = result.contains("\"isError\":true");
                    report.add("Browser: " + (failed ? "install reported a problem — " + clip(result, 300)
                            : browser + " installed with the server's browser_install tool"));
                } catch (Exception failure) {
                    report.add("Browser: install failed — " + clip(String.valueOf(failure.getMessage()), 300) +
                            ". The Agent can retry later with the browser_install MCP tool.");
                }
            } else {
                report.add("Browser: " + browser + " was not found and this server version has no browser_install tool; install " + browser + " manually.");
            }
        }

        String usage = known.flatMap(k -> k.examplePrompts().stream().findFirst()).orElse("Use " + name + " MCP to …");
        return new Outcome(true, "MCP CONFIGURED AND VERIFIED: " + title + "\n" +
                known.map(k -> "What it is: " + k.summary() + " Used for: " + k.usedFor() + ".\n").orElse("") +
                String.join("\n", report) +
                "\nHow to use it: put the word \"MCP\" in an Agent request, for example: \"" + usage + "\". " +
                "Its tools are available from the next Agent request (this run started before the server existed)." +
                (project ? "" : "\nIt is available in every project. Remove the \"" + name + "\" entry from " + file + " to undo."));
    }

    private boolean headless(JsonNode args) {
        if (args.path("headless").isBoolean()) return args.path("headless").asBoolean();
        // A server without a display cannot open a visible browser window.
        return !windows && !mac && isBlank(env.get("DISPLAY")) && isBlank(env.get("WAYLAND_DISPLAY"));
    }

    /** Chrome/Edge installed in the usual places (Playwright uses the installed stable channel for these). */
    boolean installed(String browser) {
        List<Path> candidates = new ArrayList<>();
        if (windows) {
            for (String var : List.of("ProgramFiles", "ProgramFiles(x86)", "LOCALAPPDATA")) {
                String root = env.get(var);
                if (isBlank(root)) continue;
                if (browser.equals("chrome")) candidates.add(Path.of(root, "Google", "Chrome", "Application", "chrome.exe"));
                if (browser.equals("msedge")) candidates.add(Path.of(root, "Microsoft", "Edge", "Application", "msedge.exe"));
            }
        } else if (mac) {
            if (browser.equals("chrome")) candidates.add(Path.of("/Applications/Google Chrome.app"));
            if (browser.equals("msedge")) candidates.add(Path.of("/Applications/Microsoft Edge.app"));
        } else {
            if (browser.equals("chrome")) candidates.addAll(List.of(Path.of("/opt/google/chrome/chrome"), Path.of("/usr/bin/google-chrome"),
                    Path.of("/usr/bin/google-chrome-stable")));
            if (browser.equals("msedge")) candidates.addAll(List.of(Path.of("/opt/microsoft/msedge/msedge"), Path.of("/usr/bin/microsoft-edge")));
        }
        return candidates.stream().anyMatch(exists);
    }

    /** Merge one server entry into an MCP JSON file; returns true when an entry with that name was replaced. */
    static boolean writeEntry(Path file, String name, ObjectNode entry) throws IOException {
        ObjectNode root = JSON.createObjectNode();
        if (Files.isRegularFile(file)) {
            if (Files.isSymbolicLink(file)) throw new IOException("refusing to write through a symbolic link");
            String existing = Files.readString(file, StandardCharsets.UTF_8);
            if (!existing.isBlank()) {
                JsonNode parsed;
                try { parsed = JSON.readTree(existing); }
                catch (Exception invalid) { throw new IOException("existing file is not valid JSON; fix or remove it first (" + invalid.getMessage() + ")"); }
                if (!(parsed instanceof ObjectNode object)) throw new IOException("existing file is not a JSON object");
                root = object;
            }
        }
        String container = root.path("mcp").isObject() ? "mcp" : root.path("servers").isObject() ? "servers"
                : root.path("mcpServers").isObject() ? "mcpServers" : "mcp";
        if (container.equals("mcpServers")) { // Eliya reads "mcp"/"servers"; keep other tools' section, add ours
            container = "mcp";
        }
        ObjectNode servers = root.path(container).isObject() ? (ObjectNode) root.path(container) : root.putObject(container);
        boolean replaced = servers.has(name);
        servers.set(name, entry);
        Files.createDirectories(file.toAbsolutePath().getParent());
        Path temp = Files.createTempFile(file.toAbsolutePath().getParent(), ".mcp-", ".json.tmp");
        Files.writeString(temp, JSON.writerWithDefaultPrettyPrinter().writeValueAsString(root) + System.lineSeparator(), StandardCharsets.UTF_8);
        try { Files.move(temp, file, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
        catch (AtomicMoveNotSupportedException notAtomic) { Files.move(temp, file, StandardCopyOption.REPLACE_EXISTING); }
        return replaced;
    }

    /** Turn a start failure into a concrete fix. */
    static String diagnose(String error, String title) {
        String e = error == null ? "" : error.toLowerCase(Locale.ROOT);
        if (e.matches("(?s).*(enotfound|etimedout|econnrefused|econnreset|eai_again|getaddrinfo|self[- ]signed|unable_to_get_issuer|unable to get local issuer|cert_|e403|e407|407|proxy|network).*"))
            return "npx could not download the server package from npm (network, proxy or certificate). On a company network set npm's proxy " +
                    "(`npm config set proxy http://host:port` and `npm config set https-proxy http://host:port`) or your internal registry " +
                    "(`npm config set registry <url>`), and for a company certificate `npm config set cafile <file>`; then ask again.";
        if (e.contains("timed out"))
            return "the server did not answer in time — usually the first npx download is slow. Ask again (the download is cached), " +
                    "or run `npx " + "-y <package> --help` once in a terminal to pre-download it.";
        if (e.contains("cannot start mcp command") || e.contains("no such file") || e.contains("cannot run program"))
            return "the npx command could not be started. Install Node.js (it provides npx), make sure `npx --version` works in a new terminal, restart Eliya, and ask again.";
        if (e.contains("unsupported engine") || e.contains("requires node") || e.contains("node.js version"))
            return "Node.js is too old for " + title + ". Update to the current Node.js LTS, restart Eliya, and ask again.";
        if (e.contains("e404") || e.contains("not found") || e.contains("404"))
            return "the npm package was not found. Check the package name (or your internal registry mirrors it).";
        if (e.contains("master switch"))
            return "the MCP master switch is off. Turn on \"Enable MCP access\" in Settings and ask again.";
        return "start the same command in a terminal to see the full error (`npx <package>`), fix it, and ask again.";
    }

    private static String sanitize(String raw) {
        String id = raw.toLowerCase(Locale.ROOT).replaceAll("^@", "").replaceAll("@[^/]*$", "").replaceAll("[^a-z0-9]+", "-")
                .replaceAll("^-+|-+$", "");
        return id.isBlank() ? "server" : id.length() > 40 ? id.substring(0, 40) : id;
    }

    private static String text(JsonNode args, String field) {
        return args == null ? "" : args.path(field).asText("").strip();
    }

    private static boolean isBlank(String value) { return value == null || value.isBlank(); }

    private static String clip(String value, int max) {
        String clean = value == null ? "" : value.replaceAll("\\s+", " ").strip();
        return clean.length() <= max ? clean : clean.substring(0, max) + "…";
    }
}
