package com.llmart.llm.service;

import org.springframework.stereotype.Service;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.time.Duration;
import java.time.Instant;
import java.util.Map;
import java.util.Objects;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Function;

/**
 * Holds staged recovery seeds until the next Agent run in the same conversation (or, as a fallback, the same
 * workspace) consumes them. A seed is used at most once and expires after 30 minutes.
 * ELIYA180: staging is durable — a small marker file (prior run id, workspace, time) survives a JVM restart, and the
 * seed itself is rebuilt from the persisted prior run, so a restart between "Recover" and the next run loses nothing.
 */
@Service
public class AgentRecoveryStore {
    static final Set<String> RECOVERABLE = Set.of("failed", "blocked", "interrupted", "cancelled");
    private static final Duration TTL = Duration.ofMinutes(30);
    private final Map<String, AgentRunService.RecoverySeed> byConversation = new ConcurrentHashMap<>();
    private final Path file;
    private final Function<String, AgentRunService.RecoverySeed> loader;
    private volatile String lastPersistenceError = "";

    /** In-memory only (tests). */
    AgentRecoveryStore() { this(null, null); }

    @org.springframework.beans.factory.annotation.Autowired
    public AgentRecoveryStore(AgentRunService runs) {
        this(runs == null ? null : runs.storeDirectory().resolve("recovery-staged.properties"),
                runs == null ? null : priorRunId -> runs.require(priorRunId).recoverySeed());
    }

    AgentRecoveryStore(Path file, Function<String, AgentRunService.RecoverySeed> loader) {
        this.file = file;
        this.loader = loader;
    }

    /** Stage recovery of a terminated run. Throws if the run is still active or already completed. */
    public AgentRunService.RecoverySeed stage(AgentRunService.AgentRun prior) {
        if (prior == null) throw new IllegalArgumentException("Unknown run");
        if (!RECOVERABLE.contains(prior.status()))
            throw new IllegalStateException("Only failed, blocked, interrupted or cancelled runs can be recovered (status: " + prior.status() + ")");
        AgentRunService.RecoverySeed seed = prior.recoverySeed();
        if (seed.plan().isEmpty()) throw new IllegalStateException("The run has no plan to recover; start the task again instead");
        byConversation.put(prior.conversationId(), seed);
        synchronized (this) {
            Properties markers = readMarkers();
            markers.setProperty(prior.conversationId(), seed.priorRunId() + "|" + nullToEmpty(seed.projectId()) + "|" + seed.stagedAt().toEpochMilli());
            writeMarkers(markers);
        }
        return seed;
    }

    /** Consume the seed for this conversation, or for this workspace when the follow-up uses a new conversation. */
    public AgentRunService.RecoverySeed consume(String conversationId, String projectId) {
        purgeExpired();
        AgentRunService.RecoverySeed seed = conversationId == null ? null : byConversation.remove(conversationId);
        if (seed == null && projectId != null && !projectId.isBlank()) {
            for (Map.Entry<String, AgentRunService.RecoverySeed> entry : byConversation.entrySet()) {
                if (Objects.equals(projectId, entry.getValue().projectId()) && byConversation.remove(entry.getKey(), entry.getValue())) {
                    seed = entry.getValue();
                    break;
                }
            }
        }
        synchronized (this) {
            Properties markers = readMarkers();
            if (seed != null) {
                markers.remove(seed.conversationId());
                writeMarkers(markers);
                return seed;
            }
            // After a restart the in-memory seed is gone: rebuild it from the durable marker and the persisted prior run.
            if (loader == null || markers.isEmpty()) return null;
            String key = conversationId != null && markers.containsKey(conversationId) ? conversationId : null;
            if (key == null && projectId != null && !projectId.isBlank()) {
                for (String candidate : markers.stringPropertyNames()) {
                    String[] parts = markers.getProperty(candidate).split("\\|", -1);
                    if (parts.length >= 2 && projectId.equals(parts[1])) { key = candidate; break; }
                }
            }
            if (key == null) return null;
            String[] parts = markers.getProperty(key).split("\\|", -1);
            markers.remove(key);
            writeMarkers(markers);
            if (parts.length < 3) return null;
            Instant stagedAt;
            try { stagedAt = Instant.ofEpochMilli(Long.parseLong(parts[2])); } catch (NumberFormatException invalid) { return null; }
            if (stagedAt.isBefore(Instant.now().minus(TTL))) return null;
            try {
                AgentRunService.RecoverySeed rebuilt = loader.apply(parts[0]);
                if (rebuilt == null || rebuilt.plan().isEmpty()) return null;
                return new AgentRunService.RecoverySeed(rebuilt.priorRunId(), rebuilt.conversationId(), rebuilt.projectId(), rebuilt.priorStatus(),
                        rebuilt.objective(), rebuilt.originalTaskContract(), rebuilt.plan(), rebuilt.evidence(), rebuilt.touchedPaths(),
                        rebuilt.stoppingReason(), rebuilt.lastVerification(), stagedAt);
            } catch (RuntimeException priorRunGone) {
                return null;
            }
        }
    }

    public void discard(String conversationId) {
        if (conversationId == null) return;
        byConversation.remove(conversationId);
        synchronized (this) {
            Properties markers = readMarkers();
            if (markers.remove(conversationId) != null) writeMarkers(markers);
        }
    }

    /** Empty when staging is durable; otherwise why the last marker write failed (shown to the user). */
    public String persistenceError() { return lastPersistenceError; }

    private void purgeExpired() {
        Instant cutoff = Instant.now().minus(TTL);
        byConversation.values().removeIf(seed -> seed.stagedAt().isBefore(cutoff));
    }

    private Properties readMarkers() {
        Properties markers = new Properties();
        if (file == null || !Files.isRegularFile(file)) return markers;
        try (InputStream in = Files.newInputStream(file)) { markers.load(in); }
        catch (IOException unreadable) { lastPersistenceError = "cannot read " + file + ": " + unreadable.getMessage(); }
        return markers;
    }

    private void writeMarkers(Properties markers) {
        if (file == null) return;
        try {
            Files.createDirectories(file.toAbsolutePath().getParent());
            Path tmp = file.resolveSibling(file.getFileName() + ".tmp");
            try (OutputStream out = Files.newOutputStream(tmp)) { markers.store(out, "ELIYA staged recoveries"); }
            try { Files.move(tmp, file, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (AtomicMoveNotSupportedException notAtomic) { Files.move(tmp, file, StandardCopyOption.REPLACE_EXISTING); }
            lastPersistenceError = "";
        } catch (IOException failed) {
            lastPersistenceError = "cannot save staged recovery to " + file + ": " + failed.getMessage();
            System.err.println("ELIYA: " + lastPersistenceError);
        }
    }

    private static String nullToEmpty(String value) { return value == null ? "" : value; }
}
