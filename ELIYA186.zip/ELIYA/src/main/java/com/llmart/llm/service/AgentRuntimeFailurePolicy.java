package com.llmart.llm.service;

import java.io.FileNotFoundException;
import java.net.ConnectException;
import java.net.SocketTimeoutException;
import java.net.UnknownHostException;
import java.nio.file.AccessDeniedException;
import java.nio.file.FileSystemException;
import java.nio.file.NoSuchFileException;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.TimeoutException;

/**
 * Classifies unexpected runtime errors in the Agent loop and decides what to do with them.
 *
 * <p>Before, any exception that escaped a loop iteration terminated the run as "failed" without repair or a
 * question. Now every error becomes one of: a bounded safe repair (retry with backoff, compact context, or feed
 * the error back to the executor), a meaningful user decision, or a clear non-recoverable outcome.</p>
 */
final class AgentRuntimeFailurePolicy {
    enum Kind { TRANSIENT, CONTEXT_OVERFLOW, PLAN_GATE, WORKSPACE_ACCESS, CREDENTIALS, SAFETY, UNEXPECTED }
    enum Action { RETRY, COMPACT_AND_RETRY, STEER_AND_CONTINUE, ASK_USER, STOP }

    /** What to do now. {@code question}/{@code choices}/{@code retryChoice} apply to ASK_USER. */
    record Decision(Kind kind, Action action, long backoffMs, String message, String question,
                    List<String> choices, String retryChoice) { }

    static final String RETRY_CHOICE = "Retry after fixing it";
    static final String STOP_CHOICE = "Stop and keep current work";

    private AgentRuntimeFailurePolicy() { }

    static Kind classify(Throwable error) {
        for (Throwable t = error; t != null; t = t.getCause() == t ? null : t.getCause()) {
            String message = String.valueOf(t.getMessage()).toLowerCase(Locale.ROOT);
            if (t instanceof SecurityException || message.contains("path escapes") || message.contains("symbolic link is not allowed"))
                return Kind.SAFETY;
            if (t.getClass().getSimpleName().equals("ProtectedRollbackException")) return Kind.SAFETY;
            if (message.contains("401") || message.contains("403") || message.contains("invalid api key") ||
                    message.contains("unauthorized") || message.contains("authentication") || message.contains("forbidden"))
                return Kind.CREDENTIALS;
            if (message.contains("context length") || message.contains("context window") || message.contains("maximum context") ||
                    message.contains("too many tokens") || message.contains("prompt is too long") || message.contains("context_length_exceeded"))
                return Kind.CONTEXT_OVERFLOW;
            if (t instanceof SocketTimeoutException || t instanceof ConnectException || t instanceof UnknownHostException ||
                    t instanceof TimeoutException || t instanceof java.net.http.HttpTimeoutException ||
                    message.contains("connection reset") || message.contains("timed out") || message.contains("429") ||
                    message.contains("rate limit") || message.contains("502") || message.contains("503") || message.contains("504") ||
                    message.contains("temporarily unavailable") || message.contains("overloaded"))
                return Kind.TRANSIENT;
            if (t instanceof AccessDeniedException || t instanceof NoSuchFileException || t instanceof FileNotFoundException ||
                    (t instanceof FileSystemException && !(t instanceof NoSuchFileException)) || message.contains("access is denied") ||
                    message.contains("permission denied") || message.contains("disk full") || message.contains("no space left"))
                return Kind.WORKSPACE_ACCESS;
            if (t instanceof IllegalStateException && (message.contains("plan gate") || message.contains("approved plan") ||
                    message.contains("plan contract") || message.contains("final verification step") || message.contains("cannot complete")))
                return Kind.PLAN_GATE;
        }
        return Kind.UNEXPECTED;
    }

    /** {@code attempt} is how many times this same error (fingerprint) has occurred, starting at 1. */
    static Decision decide(Throwable error, int attempt) {
        Kind kind = classify(error);
        String detail = detail(error);
        return switch (kind) {
            case SAFETY -> new Decision(kind, Action.STOP, 0,
                    "Stopped for safety: " + detail + ". No further changes were attempted; existing work and rollback protection are preserved.",
                    "", List.of(), "");
            case CREDENTIALS -> ask(kind, "The model provider rejected the credentials (" + detail + "). Fix the API key or access, " +
                    "then choose retry. The task, plan and workspace changes are preserved.");
            case TRANSIENT -> attempt <= 3
                    ? new Decision(kind, Action.RETRY, Math.min(30_000L, 2_000L * (1L << (attempt - 1))), "Temporary error, retrying: " + detail, "", List.of(), "")
                    : ask(kind, "A temporary error kept recurring (" + detail + ") after 3 automatic retries. " +
                        "Check the network/provider, then choose retry. Work so far is preserved.");
            case CONTEXT_OVERFLOW -> attempt <= 2
                    ? new Decision(kind, Action.COMPACT_AND_RETRY, 0, "Context too large; compacting older tool output and retrying", "", List.of(), "")
                    : ask(kind, "The conversation still exceeds the model's context window after compaction (" + detail + "). " +
                        "Switch to a larger-context model or narrow the task, then choose retry.");
            case PLAN_GATE -> attempt <= 2
                    ? new Decision(kind, Action.STEER_AND_CONTINUE, 0, "Plan gate rejected an action: " + detail, "", List.of(), "")
                    : ask(kind, "The executor repeatedly tried an action the plan gate does not allow (" + detail + "). " +
                        "Choose retry to let it try a different approach, or stop and keep the current work.");
            case WORKSPACE_ACCESS -> ask(kind, "A workspace file or folder could not be accessed (" + detail + "). " +
                    "Check that it exists and is not locked or read-only, then choose retry. Nothing else was changed.");
            case UNEXPECTED -> attempt <= 1
                    ? new Decision(kind, Action.STEER_AND_CONTINUE, 0, "Unexpected runtime error: " + detail, "", List.of(), "")
                    : ask(kind, "An unexpected internal error repeated (" + detail + "). This is likely an ELIYA defect. " +
                        "Choose retry to attempt a different approach, or stop and keep the current work (the run report includes the error).");
        };
    }

    /**
     * ELIYA173 API: a model-turn transport failure (I/O or timeout, before any tool was dispatched) is safe to retry
     * without approval. Security failures, cancellation and code defects are never silently retried.
     */
    static boolean retryModelTurnWithoutApproval(Throwable error) {
        for (int depth = 0; error != null && depth < 5; error = error.getCause() == error ? null : error.getCause(), depth++) {
            if (error instanceof AgentCancelledException || error instanceof SecurityException) return false;
            if (error instanceof java.io.IOException || error instanceof TimeoutException ||
                    error instanceof java.net.http.HttpTimeoutException) return true;
        }
        return false;
    }

    /** ELIYA173 API: a specific, non-generic question for a failed model action. */
    static String question(String phase, String step, String failure) {
        return "ELIYA encountered an unexpected error before a model action could complete. " +
                "No permission, verification or rollback safeguard will be changed.\n\n" +
                "Phase: " + clipText(phase, 80) + "\n" +
                "Active step: " + clipText(step, 300) + "\n" +
                "Observed error: " + clipText(failure, 700) + "\n\n" +
                "I have not established that the task is complete. You can retry this exact step once " +
                "after checking the issue, or stop and preserve completed work. " +
                "Retrying will not skip any required tests or approvals.";
    }

    private static String clipText(String value, int cap) {
        String clean = value == null ? "not available" : value.replaceAll("\\s+", " ").strip();
        return clean.length() <= cap ? clean : clean.substring(0, cap) + "…";
    }

    /** Stable key so different errors get separate retry budgets. */
    static String fingerprint(Throwable error) {
        String message = String.valueOf(error.getMessage()).replaceAll("\\d+", "#").replaceAll("\\s+", " ");
        return error.getClass().getName() + "|" + (message.length() > 160 ? message.substring(0, 160) : message);
    }

    /** Outcome for an error outside the execution loop (planning/setup), where the run cannot continue in place. */
    static String terminalOutcome(Throwable error) {
        Kind kind = classify(error);
        String detail = detail(error);
        return switch (kind) {
            case CREDENTIALS -> "The model provider rejected the credentials (" + detail + "). Fix the API key, then run the task again.";
            case TRANSIENT -> "A temporary network/provider error stopped the run (" + detail + "). Retry when the provider is reachable; use Continue to resume.";
            case CONTEXT_OVERFLOW -> "The request exceeded the model's context window (" + detail + "). Use a larger-context model or narrow the task.";
            case WORKSPACE_ACCESS -> "A workspace file or folder could not be accessed (" + detail + "). Fix access and use Continue to resume.";
            case SAFETY -> "Stopped for safety: " + detail + ". No further changes were attempted.";
            case PLAN_GATE, UNEXPECTED -> "The run stopped on an internal error (" + detail + "). Work so far is preserved; use Continue to resume, " +
                    "and include the run report if it repeats.";
        };
    }

    static String status(Throwable error) {
        Kind kind = classify(error);
        return kind == Kind.SAFETY || kind == Kind.UNEXPECTED || kind == Kind.PLAN_GATE ? "failed" : "blocked";
    }

    private static Decision ask(Kind kind, String question) {
        return new Decision(kind, Action.ASK_USER, 0, question, question, List.of(RETRY_CHOICE, STOP_CHOICE, "Cancel"), RETRY_CHOICE);
    }

    private static String detail(Throwable error) {
        String message = error.getMessage();
        String text = error.getClass().getSimpleName() + (message == null || message.isBlank() ? "" : ": " + message.replaceAll("\\s+", " "));
        return text.length() > 300 ? text.substring(0, 300) + "…" : text;
    }
}
