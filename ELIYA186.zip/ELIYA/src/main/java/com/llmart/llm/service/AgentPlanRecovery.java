package com.llmart.llm.service;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Deterministic planner-failure recovery. No model retry, plan critic, or external I/O.
 *
 * A truncated JSON plan cannot be trusted as complete: a missing tail may contain
 * required phases or constraints. Never treat partially parsed JSON as an approved plan.
 * Instead, preserve the ORIGINAL request as the execution contract and let the
 * executor inspect the live workspace. All existing tool permissions, snapshots,
 * and deliverable verification remain in force.
 */
final class AgentPlanRecovery {
    private static final Pattern BULLET = Pattern.compile("^\\s*(?:\\d{1,2}[.)]|[-*•])\\s+(.{9,})$", Pattern.UNICODE_CHARACTER_CLASS);
    private static final Pattern NAMED_PHASE = Pattern.compile(
            "(?i)^\\s*(?:(?:[-*]\\s*)?)(?:step|phase|stage|prompt|task)\\s*(\\d{1,3})\\s*[:.)\\-]\\s*(.{4,})$");
    private static final Pattern NUMBERED_PHASE = Pattern.compile(
            "^\\s*(\\d{1,3})[.)]\\s+(.{4,})$");
    private static final Pattern INLINE_PHASE = Pattern.compile("(?i)\\b(?:step|phase|stage|prompt)\\s+\\d{1,3}\\s*:");
    private static final Pattern REQUIREMENT_LINE = Pattern.compile(
            "^\\s*(?:[-*•]\\s+|(?:\\d{1,3}[.)])\\s+)(.{10,})$");
    private static final Pattern ACTION_CLAUSE = Pattern.compile(
            "(?i)^(?:please\\s+)?(?:do\\s+not\\s+|don't\\s+|never\\s+|ensure\\s+|" +
            "fix\\s+|add\\s+|remove\\s+|create\\s+|generate\\s+|migrate\\s+|" +
            "run\\s+|test\\s+|verify\\s+|validate\\s+|implement\\s+|" +
            "support\\s+|handle\\s+|preserve\\s+|configure\\s+|" +
            "include\\s+|provide\\s+|improve\\s+|update\\s+|" +
            "when\\s+|if\\s+).+");
    private static final Pattern REFUSAL = Pattern.compile(
            "(?is)^\\s*(?:sorry[,!. ]+)?(?:i (?:cannot|can't|won't|will not) (?:help|assist|comply|provide)|" +
            "i (?:must|have to) (?:decline|refuse)|request (?:blocked|refused)|content (?:filtered|blocked))\\b");

    private AgentPlanRecovery() { }

    static boolean looksStructured(String response) {
        String candidate = AgentPlanJsonEnvelope.extract(response).strip();
        return candidate.startsWith("{") || candidate.startsWith("[");
    }

    static boolean refusal(String response, String finishReason) {
        String reason = finishReason == null ? "" : finishReason.strip().toLowerCase(Locale.ROOT);
        return reason.equals("content_filter") || reason.equals("safety") || reason.equals("refusal") ||
                (response != null && REFUSAL.matcher(response).find());
    }

    /** Accept numbered/bulleted natural-language plans, but never raw JSON fragments. */
    static List<String> plainSteps(String response) {
        if (response == null || response.isBlank() || looksStructured(response)) return List.of();
        LinkedHashSet<String> steps = new LinkedHashSet<>();
        for (String line : response.split("\\R")) {
            Matcher bullet = BULLET.matcher(line);
            if (!bullet.matches()) continue;
            String step = bullet.group(1).strip();
            if (step.startsWith("{") || step.startsWith("[") || step.startsWith("\"")) continue;
            if (!step.isBlank()) steps.add(step.length() > 1_200 ? step.substring(0, 1_200) : step);
            if (steps.size() >= 16) break;
        }
        return List.copyOf(steps);
    }

    /**
     * Generate a safe, complete task contract without inventing paths, subtasks or user decisions.
     * The verbatim full request remains in the model conversation, and the fallback
     * explicitly anchors every requested phase and constraint to that full request.
     */
    static List<String> fromUserRequest(String original, boolean readOnly) {
        if (original == null || original.isBlank()) return List.of();
        String oneLine = original.replaceAll("\\s+", " ").strip();
        String excerpt = oneLine.length() <= 900 ? oneLine : oneLine.substring(0, 900) +
                " ... [Full original request is preserved in conversation context]";
        if (readOnly) return List.of(
                "Investigate and answer this specific question using actual read-only workspace or requested source evidence: " +
                excerpt + "\nValidate: Ground conclusions in inspected files/source records; do not modify files.");

        // Preserve explicitly numbered user phases instead of collapsing a migration,
        // multi-prompt generation, or multi-stage document task into two generic steps.
        // Each extracted phase retains its own scope and must be executed in order.
        List<String> phases = extractUserPhases(original);
        if (phases.size() >= 2) {
            List<String> plan = new ArrayList<>();
            for (String phase : phases) {
                plan.add("Execute the explicitly requested " + phase +
                        "\nValidate: Check this phase against its original acceptance conditions and real output evidence.");
            }
            plan.add("Independently verify all requested phases and outputs against the FULL ORIGINAL USER REQUEST. " +
                    "Report exact file paths, tests and unresolved verification, without claiming unexecuted work passed." +
                    "\nValidate: Use tool results and read-back evidence; respect original exclusions and permissions.");
            return List.copyOf(plan);
        }
        // ELIYA173: a multi-requirement brief without numbered phases keeps each explicit clause as its own step
        // rather than collapsing into a generic template. The original full task remains authoritative.
        List<String> requirements = extractUserRequirements(original);
        if (requirements.size() >= 2) {
            List<String> plan = new ArrayList<>();
            plan.add("Inspect the exact workspace/source evidence needed for the requested changes. " +
                    "Identify affected modules and existing test/configuration contracts before editing." +
                    "\nValidate: Ground affected paths and dependencies in actual reads; do not invent files.");
            for (String item : requirements) {
                plan.add("Satisfy user requirement: " + item +
                        "\nValidate: Demonstrate this specific requirement with a real change, output or finding, " +
                        "respecting all original constraints and approvals.");
            }
            plan.add("Verify the complete original requirement set against saved files and actual " +
                    "runner/output evidence; repair any in-scope failure and rerun the relevant check." +
                    "\nValidate: Record exact changed paths, executed commands and unfinished requirements; " +
                    "never report skipped tests or missing artifacts as passed.");
            return List.copyOf(plan);
        }
        // Deterministic last resort (planner failed twice). Keep the headline of each step action-first
        // so runtime step classification is correct, and seed the search with concrete request terms.
        List<String> terms = AgentPlanningTerms.extract(original, 6);
        String searchHint = terms.isEmpty() ? "" : " Start by searching for: " + String.join(", ", terms) + ".";
        return List.of(
                "Locate and read the files, classes and configuration involved in the request." + searchHint +
                "\nScope: " + excerpt +
                "\nValidate: Name the exact files/symbols that must change before editing anything.",
                "Make the requested change in the files identified in step 1, keeping unrelated behaviour unchanged." +
                "\nValidate: Every requested outcome maps to an actual edit or an explicit finding.",
                "Run the project's relevant build/test/check on the latest workspace revision; repair in-scope failures before finishing." +
                "\nValidate: Report the exact command, its result and any requirement that remains unverified.");
    }

    static boolean hasExplicitMultiRequirements(String original) {
        return original != null && (extractUserPhases(original).size() >= 2 ||
                extractUserRequirements(original).size() >= 2);
    }

    /** Capture distinct explicit instructions (bullets / action clauses), not incidental paragraphs or code. */
    static List<String> extractUserRequirements(String original) {
        LinkedHashSet<String> items = new LinkedHashSet<>();
        if (original == null) return List.of();
        boolean inCode = false;
        for (String line : original.split("\\R")) {
            String value = line.strip();
            if (value.startsWith("```") || value.startsWith("~~~")) { inCode = !inCode; continue; }
            if (inCode || value.isBlank()) continue;
            if (value.endsWith(":")) continue; // a heading that introduces requirements is not itself one
            Matcher bullet = REQUIREMENT_LINE.matcher(value);
            if (bullet.matches()) {
                addRequirement(items, bullet.group(1));
            } else if (ACTION_CLAUSE.matcher(value).matches()) {
                // Semicolons often separate distinct requirements on a single line.
                for (String clause : value.split("(?i);\\s*|\\s+and\\s+(?=(?:also\\s+)?(?:run|execute|verify|validate|test|preserve|configure|generate|create|fix|remove|add|migrate|implement|support)\\b)"))
                    if (ACTION_CLAUSE.matcher(clause.strip()).matches()) addRequirement(items, clause);
            }
        }
        // A large prompt may contain hundreds of constraints. Never silently drop any:
        // combine adjacent items in order while keeping each verbatim.
        if (items.size() > 36) {
            List<String> all = new ArrayList<>(items);
            List<String> grouped = new ArrayList<>();
            int perGroup = (all.size() + 35) / 36;
            for (int i = 0; i < all.size(); i += perGroup)
                grouped.add("requirements " + (i + 1) + "–" + Math.min(all.size(), i + perGroup) +
                        ": " + String.join("; ", all.subList(i, Math.min(all.size(), i + perGroup))));
            return grouped;
        }
        return List.copyOf(items);
    }

    private static void addRequirement(LinkedHashSet<String> items, String raw) {
        String value = raw.replaceAll("\\s+", " ").strip();
        if (value.length() >= 10 && !value.startsWith("{") && !value.startsWith("[") &&
                !value.startsWith("//") && !value.startsWith("#")) items.add(value);
    }

    static List<String> extractUserPhases(String original) {
        List<String> phases = new ArrayList<>();
        String normalized = INLINE_PHASE.matcher(original).replaceAll("\n$0");
        for (String line : normalized.split("\\R")) {
            String value = line.strip();
            Matcher named = NAMED_PHASE.matcher(value);
            Matcher numbered = NUMBERED_PHASE.matcher(value);
            if (named.matches()) {
                phases.add("phase " + named.group(1) + ": " + named.group(2).strip());
            } else if (numbered.matches()) {
                phases.add("item " + numbered.group(1) + ": " + numbered.group(2).strip());
            }
        }
        // A long original prompt is kept separately as the authoritative contract.
        // Do not silently drop numbered sections beyond a fixed plan-step quota:
        // group them in order, retaining every captured title/requirement.
        if (phases.size() > 48) {
            List<String> groups = new ArrayList<>();
            int perGroup = (phases.size() + 47) / 48;
            for (int i = 0; i < phases.size(); i += perGroup) {
                groups.add("ordered user instructions " + (i + 1) + "–" +
                        Math.min(phases.size(), i + perGroup) + ": " +
                        String.join("; ", phases.subList(i, Math.min(phases.size(), i + perGroup))));
            }
            return groups;
        }
        return phases;
    }

}
