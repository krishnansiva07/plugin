package com.llmart.llm.autonomy;

import jakarta.annotation.PreDestroy;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Service;

import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/**
 * Local triggers that start autonomous runs without anyone at the keyboard:
 * <ul>
 *   <li><b>Task inbox:</b> drop a {@code .md}/{@code .txt} file into {@code ~/.eliya/tasks/inbox/}. It moves to
 *       {@code processing/}, then {@code done/} or {@code failed/} with the result appended.</li>
 *   <li><b>Schedule:</b> jobs in {@code ~/.eliya/schedule.json} (daily time + weekdays, or every N minutes).</li>
 * </ul>
 * Runs execute one at a time. Disable with {@code -Deliya.autonomous.triggers=false}; the folder can be changed
 * with {@code ELIYA_HOME} (default {@code ~/.eliya}).
 */
@Service
public class AutonomousTriggerService {
    private final AutonomousRunService runner;
    private final ScheduledExecutorService poller = Executors.newSingleThreadScheduledExecutor(task -> {
        Thread thread = new Thread(task, "eliya-trigger-poller"); thread.setDaemon(true); return thread;
    });
    private final ExecutorService worker = Executors.newSingleThreadExecutor(task -> {
        Thread thread = new Thread(task, "eliya-autonomous-run"); thread.setDaemon(true); return thread;
    });
    private final Set<String> queued = ConcurrentHashMap.newKeySet();
    private volatile String lastScheduleError = "";

    public AutonomousTriggerService(AutonomousRunService runner) {
        this.runner = runner;
    }

    public static Path home() {
        String override = System.getenv("ELIYA_HOME");
        return override != null && !override.isBlank() ? Path.of(override) : Path.of(System.getProperty("user.home"), ".eliya");
    }

    @EventListener(ApplicationReadyEvent.class)
    public void start() {
        if ("false".equalsIgnoreCase(System.getProperty("eliya.autonomous.triggers", "true"))) return;
        try { Files.createDirectories(home().resolve("tasks").resolve("inbox")); } catch (Exception ignored) { }
        poller.scheduleWithFixedDelay(this::poll, 15, 20, TimeUnit.SECONDS);
        System.out.println("ELIYA autonomous triggers: inbox " + home().resolve("tasks").resolve("inbox") +
                ", schedule " + home().resolve("schedule.json"));
    }

    @PreDestroy
    public void stop() {
        poller.shutdownNow();
        worker.shutdownNow();
    }

    void poll() {
        try { pollInbox(); } catch (Exception error) { System.err.println("ELIYA inbox: " + error.getMessage()); }
        try { pollSchedule(LocalDateTime.now()); } catch (Exception error) {
            String message = error.getMessage() == null ? error.getClass().getSimpleName() : error.getMessage();
            if (!message.equals(lastScheduleError)) System.err.println("ELIYA schedule.json ignored: " + message);
            lastScheduleError = message;
        }
    }

    void pollInbox() throws Exception {
        Path tasks = home().resolve("tasks");
        Path inbox = tasks.resolve("inbox");
        if (!Files.isDirectory(inbox)) return;
        List<Path> files = new ArrayList<>();
        try (DirectoryStream<Path> stream = Files.newDirectoryStream(inbox)) {
            for (Path file : stream) {
                String name = file.getFileName().toString().toLowerCase(Locale.ROOT);
                if (Files.isRegularFile(file) && (name.endsWith(".md") || name.endsWith(".txt")) && !name.startsWith(".")) files.add(file);
            }
        }
        files.sort(null);
        for (Path file : files) {
            // Skip files still being written (modified in the last 3 seconds).
            if (System.currentTimeMillis() - Files.getLastModifiedTime(file).toMillis() < 3_000) continue;
            Path processing = tasks.resolve("processing");
            Files.createDirectories(processing);
            Path claimed = processing.resolve(file.getFileName());
            Files.move(file, claimed, StandardCopyOption.REPLACE_EXISTING);
            worker.submit(() -> runTaskFile(tasks, claimed));
        }
    }

    private void runTaskFile(Path tasks, Path claimed) {
        String outcome;
        String folder;
        try {
            AutonomousTaskFile task = AutonomousTaskFile.parse(Files.readString(claimed, StandardCharsets.UTF_8), null);
            if (task.workspace().isBlank()) throw new IllegalArgumentException("Task file has no 'workspace:' in its front matter");
            if (task.task().isBlank()) throw new IllegalArgumentException("Task file has no task text");
            AutonomousRunService.RunResult result = runner.run(new AutonomousRunService.RunRequest(task.task(), task.workspace(),
                    task.inPlace(), task.maxMinutes(), task.maxTurns(), task.maxTokens(),
                    "inbox:" + claimed.getFileName(), false), null, null);
            folder = "completed".equals(result.status()) ? "done" : "failed";
            outcome = "status: " + result.status() + "\nbranch: " + result.branch() + "\nreport: " + result.reportPath();
        } catch (Exception error) {
            folder = "failed";
            outcome = "status: failed\nerror: " + error.getMessage();
        }
        try {
            Path target = tasks.resolve(folder);
            Files.createDirectories(target);
            Files.writeString(claimed, Files.readString(claimed, StandardCharsets.UTF_8) +
                    "\n\n<!-- ELIYA result\n" + outcome + "\n-->\n", StandardCharsets.UTF_8);
            Files.move(claimed, target.resolve(claimed.getFileName()), StandardCopyOption.REPLACE_EXISTING);
        } catch (Exception ignored) { }
    }

    void pollSchedule(LocalDateTime now) throws Exception {
        Path file = home().resolve("schedule.json");
        if (!Files.isRegularFile(file)) return;
        AutonomousSchedule schedule = AutonomousSchedule.load(file);
        lastScheduleError = "";
        Path stateFile = home().resolve("schedule-state.properties");
        Properties state = new Properties();
        if (Files.isRegularFile(stateFile)) try (InputStream in = Files.newInputStream(stateFile)) { state.load(in); }
        for (AutonomousSchedule.Job job : schedule.jobs()) {
            String last = state.getProperty(job.id());
            LocalDateTime lastRun = last == null ? null : LocalDateTime.parse(last);
            if (!job.due(now, lastRun) || !queued.add(job.id())) continue;
            state.setProperty(job.id(), now.toString()); // record before running: never double-fire after a restart
            Files.createDirectories(stateFile.getParent());
            try (OutputStream out = Files.newOutputStream(stateFile)) { state.store(out, "ELIYA schedule last-run times"); }
            worker.submit(() -> {
                try {
                    runner.run(new AutonomousRunService.RunRequest(job.task(), job.workspace(), job.inPlace(),
                            job.maxMinutes(), job.maxTurns(), job.maxTokens(), "schedule:" + job.id(), false), null, null);
                } catch (Exception error) {
                    System.err.println("ELIYA scheduled job " + job.id() + " failed: " + error.getMessage());
                } finally {
                    queued.remove(job.id());
                }
            });
        }
    }
}
