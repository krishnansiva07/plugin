package com.llmart.llm.service;

import java.util.Locale;
import java.util.regex.Pattern;

/**
 * Classifies an approved plan step as exploration, implementation or verification.
 *
 * <p>Extracted from {@code AgentService}. The previous heuristics scanned the WHOLE step text with
 * plain substring matching, which caused two systematic misclassifications:</p>
 * <ul>
 *   <li>Steps frequently embed a quoted excerpt of the user's request and a trailing {@code Validate:} line.
 *       Words there ("fix", "update", "changes") made a pure investigation step look like implementation,
 *       so the exploration budget aborted it after a handful of read-only turns.</li>
 *   <li>Substrings matched inside other words ("latest" contains "test", "address" contains "add").</li>
 * </ul>
 * <p>Classification now uses only the step's own action headline and whole-word prefixes.</p>
 */
final class AgentPlanStepClassifier {
    private static final Pattern NUMBER_PREFIX = Pattern.compile("^(?:\\d+[.)]\\s*|[-*•]\\s*)");
    private static final Pattern READ = words("inspect", "analy[sz]", "identif", "trace", "review", "discover",
            "understand", "map", "confirm", "locate", "investigat", "read", "search", "explor", "find", "examin",
            "study", "collect", "gather", "determin", "list", "audit", "grep");
    // Explicit verb forms (not bare prefixes): "address" is not "add", "implementation"/"modifications"
    // describe what to inspect, "builder" is not "build".
    private static final Pattern MUTATION = forms("implement(?:s|ed|ing)?", "modif(?:y|ies|ied|ying)", "edit(?:s|ed|ing)?",
            "creat(?:e|es|ed|ing)", "add(?:s|ed|ing)?", "remov(?:e|es|ed|ing)", "delet(?:e|es|ed|ing)",
            "refactor(?:s|ed|ing)?", "migrat(?:e|es|ed|ing)", "fix(?:es|ed|ing)?", "updat(?:e|es|ed|ing)",
            "writ(?:e|es|ing)", "renam(?:e|es|ed|ing)", "replac(?:e|es|ed|ing)", "introduc(?:e|es|ed|ing)",
            "extract(?:s|ed|ing)?", "generat(?:e|es|ed|ing)", "appl(?:y|ies|ied|ying)", "patch(?:es|ed|ing)?",
            "convert(?:s|ed|ing)?", "port(?:s|ed|ing)?", "split(?:s|ting)?", "mov(?:e|es|ed|ing)", "wire|wiring", "insert(?:s|ed|ing)?");
    private static final Pattern VERIFY = forms("verif(?:y|ies|ied|ying|ication)", "validat(?:e|es|ed|ing|ion)", "tests?|tested|testing",
            "compil(?:e|es|ed|ing|ation)", "build(?:s|ing)?", "run(?:s|ning)?", "regression", "smoke", "check(?:s|ed|ing)?", "lint(?:s|ed|ing)?");
    private static final Pattern FINAL_BOUNDARY = Pattern.compile(
            "\\b(?:final|finally|after all|after the|latest workspace|complete change|all requested changes|end[- ]to[- ]end|full)\\b");

    private AgentPlanStepClassifier() { }

    private static Pattern words(String... stems) {
        return Pattern.compile("\\b(?:" + String.join("|", stems) + ")[a-z]*\\b");
    }

    private static Pattern forms(String... alternatives) {
        return Pattern.compile("\\b(?:" + String.join("|", alternatives) + ")\\b");
    }

    /**
     * The step's own action: the first line, before any "Validate:" clause and before a ':' that
     * introduces a long quoted user excerpt (e.g. "Inspect the target for: &lt;user text&gt;").
     */
    static String headline(String stepText) {
        if (stepText == null) return "";
        String first = stepText.strip().split("\\R", 2)[0];
        first = NUMBER_PREFIX.matcher(first).replaceFirst("");
        int validate = first.toLowerCase(Locale.ROOT).indexOf("validate:");
        if (validate > 0) first = first.substring(0, validate);
        int colon = first.indexOf(": ");
        // Keep short labels such as "Step 2: Fix X" intact; cut only a long excerpt after the action phrase.
        if (colon >= 12 && first.length() - colon > 40) first = first.substring(0, colon);
        return first.toLowerCase(Locale.ROOT).strip();
    }

    static boolean isReadOnly(String stepText) {
        String value = headline(stepText);
        return !value.isBlank() && READ.matcher(value).find() && !MUTATION.matcher(value).find();
    }

    static boolean isVerification(String stepText) {
        String value = headline(stepText);
        return !value.isBlank() && VERIFY.matcher(value).find() && !MUTATION.matcher(value).find();
    }

    static boolean isFinalVerification(String stepText) {
        String value = headline(stepText);
        return isVerification(stepText) && FINAL_BOUNDARY.matcher(value).find();
    }

    /** Implementation steps are subject to the runtime exploration budget; others are not. */
    static boolean isImplementation(String stepText) {
        return !headline(stepText).isBlank() && !isReadOnly(stepText) && !isVerification(stepText);
    }
}
