package com.llmart.llm.service;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Generic understanding of a migration request: <b>from</b> what, <b>to</b> what, over which <b>scope</b>, proven by
 * which <b>check</b>. Works for any technology (versions, frameworks, libraries, languages, config formats); it does
 * not depend on a list of known products. Confirmation and evidence checks happen in {@link MigrationEngine}.
 */
final class MigrationIntent {

    /** source/target as the user wrote them; scope = modules/packages/paths; verify = how the user wants it proven. */
    record Spec(String source, String target, List<String> scope, String verify, boolean allScope, String phrasing) {
        String summary() {
            return (source.isBlank() ? "?" : source) + " → " + (target.isBlank() ? "?" : target) +
                    (scope.isEmpty() ? (allScope ? ", whole project" : "") : ", scope: " + String.join(", ", scope)) +
                    (verify.isBlank() ? "" : ", verify: " + verify);
        }
    }

    private static final String VERB = "(?:migrat(?:e|es|ed|ing|ion)|convert(?:s|ed|ing)?|port(?:s|ed|ing)?|" +
            "upgrad(?:e|es|ed|ing)|downgrad(?:e|ing)|mov(?:e|es|ing)|switch(?:es|ing)?|transition(?:s|ing)?|" +
            "moderni[sz](?:e|ing)|re-?platform(?:ing)?|rewrit(?:e|ing)|translat(?:e|ing)|replac(?:e|es|ing)|bump(?:ing)?)";
    // A technology name: words, versions, dots, plus, hash, slashes ("Spring Boot 2.7", "Java 8", "AngularJS", "C#", "@angular/core").
    private static final String TECH = "([@\\w.+#/-]+(?:[ \\t]+(?!(?:to|into|with|and|for|in|on|across|using|then|so|but|by)\\b)[@\\w.+#/-]+){0,3})";
    private static final Pattern FROM_TO = Pattern.compile("(?i)\\b" + VERB + "\\b[^.\\n]{0,80}?\\bfrom\\s+" + TECH + "\\s+(?:to|into|onto|→|->)\\s+" + TECH);
    // "upgrade Spring Boot from 2.7 to 3.2": the subject carries the name, from/to carry versions.
    private static final Pattern SUBJECT_VERSIONS = Pattern.compile("(?i)\\b" + VERB + "\\s+(?:the\\s+|our\\s+)?([A-Za-z@][\\w.+#/-]*(?:\\s+[A-Za-z][\\w.+#/-]*){0,2})\\s+from\\s+(v?\\d[\\w.+-]*)\\s+(?:to|→|->)\\s+(v?\\d[\\w.+-]*)");
    // "javax to jakarta migration", "Java 8 → 17 upgrade"
    private static final Pattern NOUN_FORM = Pattern.compile("(?i)([@\\w.+#/-]+(?:\\s+[@\\w.+#/-]+)?)\\s+(?:to|→|->)\\s+([@\\w.+#/-]+(?:\\s+[\\w.+-]+)?)\\s+(?:migration|upgrade|conversion|port(?:ing)?)\\b");
    private static final Pattern REPLACE_WITH = Pattern.compile("(?i)\\breplac(?:e|es|ing)\\s+(?:the\\s+|all\\s+)?" + TECH + "\\s+(?:with|by)\\s+" + TECH);
    private static final Pattern ARROW = Pattern.compile("(?i)" + TECH + "\\s*(?:→|->|=>)\\s*" + TECH);
    private static final Pattern VERB_TO = Pattern.compile("(?i)\\b" + VERB + "\\s+(?:the\\s+|our\\s+|this\\s+|my\\s+)?(?:project\\s+|app(?:lication)?\\s+|code(?:base)?\\s+|tests?\\s+)?(?:from\\s+)?" +
            TECH + "\\s+(?:to|into|onto)\\s+" + TECH);
    private static final Pattern TO_ONLY = Pattern.compile("(?i)\\b(?:upgrad(?:e|ing)|migrat(?:e|ing)|mov(?:e|ing)|switch(?:ing)?|port(?:ing)?|convert(?:ing)?)\\b[^.\\n]{0,80}?\\b(?:modules?|packages?|project|app(?:lication)?|code(?:base)?|repo(?:sitory)?|tests?|services?|everything|it)[`'\"]?\\s+(?:to|onto)\\s+" + TECH);
    private static final Pattern MIGRATION_WORD = Pattern.compile("(?i)\\b(?:migrat(?:e|es|ed|ing|ion|ions)|moderni[sz](?:e|ation)|re-?platform)");
    private static final Pattern SCOPE_LIST = Pattern.compile("(?i)\\b(?:the\\s+)?([\\w.,/ `'\"-]{1,160}?)\\s+(modules?|packages?|folders?|directories|projects?|services?)\\b(?!')");
    private static final Pattern SCOPE_IN = Pattern.compile("(?i)\\b(?:in|under|for|of)\\s+(?:the\\s+)?(?:modules?|packages?|folders?|directories|projects?)?\\s*([`'\"]?[\\w./-]+(?:/[\\w.-]+)*[`'\"]?(?:\\s*(?:,|and)\\s*[`'\"]?[\\w./-]+[`'\"]?)*)");
    private static final Pattern ALL_SCOPE = Pattern.compile("(?i)\\b(?:all|every|entire|whole|full|complete)\\s+(?:the\\s+)?(?:project|codebase|repo(?:sitory)?|app(?:lication)?|modules?|tests?|files?|code|suite|migration)\\b|\\beverything\\b|\\bacross the\\b");
    private static final Pattern VERIFY = Pattern.compile("(?i)\\b(?:verify|check|prove|validate|confirm)\\s+(?:it\\s+|them\\s+|this\\s+)?(?:with|by|using)\\s+[`'\"]?([^`'\".\\n]{3,80})|\\b(?:then\\s+)?run\\s+(?:the\\s+)?([`'\"][^`'\"\\n]{2,80}[`'\"]|(?:unit\\s+|integration\\s+|e2e\\s+|all\\s+|its\\s+|their\\s+|the\\s+)?tests?(?:\\s+(?:with|using)\\s+[^.\\n]{2,60})?)");
    private static final java.util.Set<String> NOT_TECH = java.util.Set.of("it", "them", "this", "that", "the", "a", "an", "our", "my",
            "project", "app", "application", "code", "codebase", "repo", "repository", "everything", "tests", "test", "files", "file",
            "version", "latest", "new", "newer", "old", "module", "modules");

    private MigrationIntent() { }

    /** Any migration-like request, even when source/target cannot be extracted (the Agent then proposes the spec). */
    static boolean isMigration(String text) {
        if (text == null || text.isBlank()) return false;
        if (parse(text).isPresent()) return true;
        // "create a Flyway migration", "database migration script": a schema-change file, not a technology migration.
        if (SCHEMA_MIGRATION.matcher(text).find()) return false;
        return MIGRATION_WORD.matcher(text).find();
    }

    private static final Pattern SCHEMA_MIGRATION = Pattern.compile("(?i)\\b(?:flyway|liquibase|alembic|knex|sequelize|prisma|typeorm|" +
            "django|rails|ef\\s+core|entity\\s+framework|db|database|schema|sql|data)\\s+migrations?\\b|\\bmigrations?\\s+(?:file|script|class|folder)s?\\b|" +
            "\\b(?:create|add|generate|write|run|apply)\\s+(?:a\\s+|an\\s+|the\\s+|new\\s+|pending\\s+)*migrations?\\b(?!\\s+(?:from|of|to)\\b)");

    static Optional<Spec> parse(String text) {
        if (text == null || text.isBlank()) return Optional.empty();
        String source = "", target = "";
        String phrasing = "";
        Matcher m;
        if ((m = SUBJECT_VERSIONS.matcher(text)).find()) {
            source = m.group(1) + " " + m.group(2); target = m.group(1) + " " + m.group(3); phrasing = "subject-versions";
        }
        else if ((m = FROM_TO.matcher(text)).find()) { source = m.group(1); target = m.group(2); phrasing = "from-to"; }
        else if ((m = NOUN_FORM.matcher(text)).find()) { source = m.group(1); target = m.group(2); phrasing = "noun-form"; }
        else if ((m = REPLACE_WITH.matcher(text)).find()) { source = m.group(1); target = m.group(2); phrasing = "replace-with"; }
        else if ((m = VERB_TO.matcher(text)).find() && !isFiller(m.group(1))) { source = m.group(1); target = m.group(2); phrasing = "verb-to"; }
        else if ((m = ARROW.matcher(text)).find() && MIGRATION_WORD.matcher(text).find()) { source = m.group(1); target = m.group(2); phrasing = "arrow"; }
        else if ((m = TO_ONLY.matcher(text)).find()) { target = m.group(1); phrasing = "target-only"; }
        if (phrasing.isEmpty()) return Optional.empty();
        String matched = m.group(0);
        source = clean(source);
        target = clean(target);
        // "Java 8 → 17": a bare version target takes the source's name.
        if (target.matches("v?\\d[\\w.]*") && source.matches("(?i)[a-z@][\\w.+#/-]*(?:\\s+[a-z][\\w.+#/-]*)*\\s+v?\\d[\\w.]*"))
            target = source.replaceAll("\\s+v?\\d[\\w.]*$", "") + " " + target;
        // "migration of the payment module to Spring Boot 3": the module is scope, not the source technology.
        if (source.matches("(?i)^(?:of\\s+)?(?:the\\s+|our\\s+)?[\\w./-]+(?:\\s+(?:and|,)\\s+[\\w./-]+)*\\s+(?:modules?|packages?|services?|projects?|apps?|application|folders?)$"))
            source = "";
        source = source.replaceFirst("(?i)^of\\s+", "");
        if (isFiller(source)) source = "";
        if (isFiller(target)) target = "";
        if (source.isBlank() && target.isBlank()) return Optional.empty();
        if (!plausible(matched, source, target, text)) return Optional.empty();
        // "upgrade to Java 21" style without "migrate": still a migration only with a real target.
        boolean allScope = ALL_SCOPE.matcher(text).find();
        return Optional.of(new Spec(source, target, scope(text, source, target), verify(text), allScope, phrasing));
    }

    private static final Pattern STRONG_VERB = Pattern.compile("(?i)\\b(?:migrat|upgrad|downgrad|port(?:s|ed|ing)?\\b|moderni|re-?platform)");
    private static final Pattern CONTEXT = Pattern.compile("(?i)\\b(?:migrat\\w*|project|codebase|code base|modules?|packages?|framework|library|libraries|" +
            "dependency|dependencies|version|tests?|test suite|app(?:lication)?|services?|repo(?:sitory)?|all files|imports?|api)\\b");
    private static final java.util.Set<String> KNOWN_TECH = java.util.Set.of("javax", "jakarta", "java", "jdk", "kotlin", "scala", "groovy",
            "spring", "boot", "junit", "testng", "mockito", "jest", "vitest", "mocha", "jasmine", "karma", "cypress", "selenium", "playwright",
            "webdriver", "puppeteer", "moment", "dayjs", "luxon", "lodash", "underscore", "jquery", "react", "angular", "angularjs", "vue",
            "svelte", "next", "nuxt", "webpack", "vite", "rollup", "babel", "typescript", "javascript", "node", "deno", "python", "django",
            "flask", "fastapi", "pytest", "unittest", "maven", "gradle", "ant", "npm", "yarn", "pnpm", "log4j", "slf4j", "logback",
            "hibernate", "jpa", "jdbc", "mybatis", "struts", "jsf", "jsp", "servlet", "tomcat", "jetty", "wildfly", "weblogic", "websphere",
            "mysql", "postgres", "postgresql", "oracle", "mongodb", "redis", "kafka", "rabbitmq", "graphql", "rest", "soap", "grpc",
            "dotnet", ".net", "c#", "csharp", "go", "golang", "rust", "ruby", "rails", "php", "laravel", "swift", "objective-c",
            "android", "ios", "flutter", "xamarin", "bootstrap", "tailwind", "sass", "less", "redux", "mobx", "rxjs", "enzyme", "jenkins",
            "github", "gitlab", "azure", "aws", "gcp", "terraform", "docker", "kubernetes", "helm", "cucumber", "gherkin", "openapi", "swagger");

    /** Generic verbs (move, switch, replace, convert …) only count when the names look like technologies. */
    private static boolean plausible(String matched, String source, String target, String text) {
        if (STRONG_VERB.matcher(matched).find()) return true;
        if (MIGRATION_WORD.matcher(text).find()) return true;
        if (techLike(source) || techLike(target)) return true;
        if (TECH_CONTEXT.matcher(text).find()) return true;
        return CONTEXT.matcher(text).find() && (hasVersion(source) || hasVersion(target));
    }

    private static final Pattern TECH_CONTEXT = Pattern.compile("(?i)\\b(?:library|libraries|framework|dependency|dependencies|sdk|api|" +
            "imports?|test runner|build tool|runtime|toolkit|orm|driver)\\b");

    private static boolean hasVersion(String value) { return value != null && value.matches(".*\\d.*"); }

    static boolean techLike(String value) {
        if (value == null || value.isBlank()) return false;
        if (value.matches(".*\\b(?:v?\\d+(?:\\.\\d+)*|\\d+\\.x)\\b.*") && value.matches(".*[A-Za-z].*")) return true;
        if (value.matches(".*[@/#+].*") || value.matches(".*[a-z]\\.[a-z].*")) return true;
        for (String word : value.toLowerCase(Locale.ROOT).split("[\\s]+")) if (KNOWN_TECH.contains(word)) return true;
        return false;
    }

    private static boolean isFiller(String value) {
        String v = value == null ? "" : value.strip().toLowerCase(Locale.ROOT);
        return v.isBlank() || NOT_TECH.contains(v) || v.matches("(?:the|our|my|this)\\s+(?:project|app|application|code|codebase|tests?)");
    }

    /** Trim trailing filler words ("Spring Boot 3 for the billing" → "Spring Boot 3"). */
    static String clean(String raw) {
        if (raw == null) return "";
        String value = raw.strip().replaceAll("^[`'\"]|[`'\",;:]+$", "").replaceAll("[`'\"]", "");
        value = value.replaceAll("(?i)\\s+(?:version|framework|library|everywhere|now|please|first|only|completely|fully|tests?|scripts?|code|files?|project|app|application|codebase|suites?)$", "");
        value = value.replaceAll("(?i)^(?:the|our|my|this|a|an)\\s+", "");
        return value.strip();
    }

    static List<String> scope(String text, String source, String target) {
        LinkedHashSet<String> out = new LinkedHashSet<>();
        Matcher list = SCOPE_LIST.matcher(text);
        while (list.find()) {
            String names = list.group(1);
            // take the words right before "modules/packages": "the billing and orders modules"
            String tail = names.replaceAll("(?is).*\\b(?:migrate|upgrade|convert|port|move|switch|in|for|of|from|to|across|all|every|each|both)\\b", "");
            for (String name : tail.split("\\s*(?:,|\\band\\b|&)\\s*")) addScope(out, name, source, target);
        }
        Matcher in = SCOPE_IN.matcher(text);
        while (in.find()) {
            String names = in.group(1);
            if (names.contains("/") || names.contains("`") || names.matches("(?s).*\\b[a-z]+(?:\\.[a-z0-9_]+){2,}\\b.*")) {
                for (String name : names.split("\\s*(?:,|\\band\\b)\\s*")) addScope(out, name, source, target);
            }
        }
        return List.copyOf(out);
    }

    private static void addScope(LinkedHashSet<String> out, String raw, String source, String target) {
        String name = raw == null ? "" : raw.strip().replaceAll("[`'\"]", "").replaceAll("^(?:the|all|our)\\s+", "");
        if (name.isBlank() || name.length() > 80 || isFiller(name)) return;
        String lower = name.toLowerCase(Locale.ROOT);
        if (!source.isBlank() && lower.equals(source.toLowerCase(Locale.ROOT))) return;
        if (!target.isBlank() && lower.equals(target.toLowerCase(Locale.ROOT))) return;
        if (lower.matches("(?:java|spring|boot|junit|python|node|react|angular|vue|selenium|playwright|test|tests|maven|gradle|npm|all|every|both)")) return;
        if (name.split("\\s+").length > 3 || name.matches("v?\\d[\\w.]*")) return;
        out.add(name);
    }

    static String verify(String text) {
        Matcher m = VERIFY.matcher(text);
        if (!m.find()) return "";
        String value = m.group(1) != null ? m.group(1) : m.group(2);
        return value == null ? "" : value.replaceAll("[`'\"]", "").strip();
    }

    /** Words of a technology name worth checking in a plan ("Spring Boot 3.2" → spring, boot). */
    static List<String> keyTerms(String tech) {
        List<String> out = new ArrayList<>();
        if (tech == null) return out;
        for (String word : tech.toLowerCase(Locale.ROOT).split("[^a-z0-9#+]+")) {
            if (word.length() >= 3 && !word.matches("\\d+") && !NOT_TECH.contains(word)) out.add(word);
        }
        if (out.isEmpty() && !tech.isBlank()) out.add(tech.toLowerCase(Locale.ROOT).strip());
        return out;
    }
}
