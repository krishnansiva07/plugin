package com.llmart.llm.cli.tui;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

/**
 * Raw-mode access to the controlling terminal on Linux/macOS (and other systems with {@code stty} and /dev/tty),
 * without native libraries. Restores the terminal on close and on JVM shutdown.
 */
final class UnixTuiTerminal extends TuiTerminal {
    private static final File TTY = new File("/dev/tty");
    private final InputStream input;
    private final OutputStream output;
    private final String savedState;
    private volatile boolean closed;
    private final Thread restoreHook;

    private UnixTuiTerminal(InputStream input, OutputStream output, String savedState) {
        this.input = input; this.output = output; this.savedState = savedState;
        this.restoreHook = new Thread(this::restore, "eliya-tui-restore");
    }

    static UnixTuiTerminal create() {
        if (System.getProperty("os.name", "").toLowerCase(Locale.ROOT).contains("win")) return null;
        if (!TTY.exists() || !TTY.canRead() || !TTY.canWrite()) return null;
        try {
            String saved = stty("-g").strip();
            if (saved.isEmpty()) return null;
            return new UnixTuiTerminal(new FileInputStream(TTY), new FileOutputStream(TTY), saved);
        } catch (Exception unavailable) {
            return null;
        }
    }

    static boolean available() {
        if (System.getProperty("os.name", "").toLowerCase(Locale.ROOT).contains("win")) return false;
        if (!TTY.exists() || !TTY.canRead() || !TTY.canWrite()) return false;
        try { return !stty("-g").isBlank(); } catch (Exception unavailable) { return false; }
    }

    static String stty(String... args) throws IOException, InterruptedException {
        String[] command = new String[args.length + 1];
        command[0] = "stty";
        System.arraycopy(args, 0, command, 1, args.length);
        Process process = new ProcessBuilder(command).redirectInput(TTY).redirectError(ProcessBuilder.Redirect.DISCARD).start();
        byte[] out = process.getInputStream().readAllBytes();
        if (!process.waitFor(3, TimeUnit.SECONDS)) { process.destroyForcibly(); throw new IOException("stty timed out"); }
        if (process.exitValue() != 0) throw new IOException("stty " + String.join(" ", args) + " failed");
        return new String(out, StandardCharsets.UTF_8);
    }

    /** Enter raw mode and the alternate screen; enables bracketed paste. No mouse capture, so selection/copy stays native. */
    @Override
    public void enter() throws IOException, InterruptedException {
        Runtime.getRuntime().addShutdownHook(restoreHook);
        stty("raw", "-echo");
        write("\u001b[?1049h\u001b[?2004h\u001b[?1007h\u001b[H\u001b[2J");
        flush();
    }

    /** Rows and columns; falls back to 24x80. */
    @Override
    public int[] size() {
        try {
            String[] parts = stty("size").strip().split("\\s+");
            int rows = Integer.parseInt(parts[0]), cols = Integer.parseInt(parts[1]);
            if (rows > 0 && cols > 0) return new int[]{rows, cols};
        } catch (Exception ignored) { }
        return new int[]{envInt("LINES", 24), envInt("COLUMNS", 80)};
    }

    private static int envInt(String name, int fallback) {
        try { return Integer.parseInt(System.getenv(name)); } catch (Exception e) { return fallback; }
    }

    @Override
    public InputStream input() { return input; }

    @Override
    public synchronized void write(String text) throws IOException { output.write(text.getBytes(StandardCharsets.UTF_8)); }

    @Override
    public synchronized void flush() throws IOException { output.flush(); }

    private synchronized void restore() {
        if (closed) return;
        closed = true;
        try {
            output.write("\u001b[?2026l\u001b[?1007l\u001b[?2004l\u001b[0m\u001b[?25h\u001b[?1049l".getBytes(StandardCharsets.UTF_8));
            output.flush();
        } catch (IOException ignored) { }
        try { stty(savedState); } catch (Exception ignored) {
            try { stty("sane"); } catch (Exception alsoIgnored) { }
        }
    }

    @Override
    public void close() {
        restore();
        try { Runtime.getRuntime().removeShutdownHook(restoreHook); } catch (IllegalStateException shuttingDown) { }
        try { input.close(); } catch (IOException ignored) { }
    }
}
