package com.llmart.llm.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.regex.Pattern;

/**
 * Built-in knowledge of well-known MCP servers, so "configure Playwright MCP" works without the user knowing the
 * package name, command, options or prerequisites. Facts come from each project's README (checked Nov 2026).
 */
final class McpKnownServers {

    /** One well-known server. {@code baseArgs} follow {@code npx}; {@code minNode} is "major.minor". */
    record Known(String id, String title, List<String> aliases, String summary, String usedFor,
                 String minNode, List<String> baseArgs, String browserRequirement, String docs,
                 List<String> examplePrompts, List<String> options) {
        String npxPackage() { return baseArgs.stream().filter(arg -> !arg.startsWith("-")).findFirst().orElse(""); }
    }

    static final List<Known> ALL = List.of(
            new Known("playwright", "Playwright MCP (Microsoft)",
                    List.of("playwright mcp", "playwright", "@playwright/mcp", "playwright-mcp", "microsoft playwright"),
                    "Microsoft's official Playwright MCP server. It gives the Agent a real browser it can drive through " +
                    "structured page snapshots (the accessibility tree), so it does not need screenshots or a vision model.",
                    "open pages, click, type, fill forms, select options, upload files, take screenshots, read console and " +
                    "network messages, and check a web app's behaviour end to end",
                    "18.0", List.of("-y", "@playwright/mcp@latest"),
                    "Uses Google Chrome by default (--browser can pick chrome, firefox, webkit or msedge). If the browser is " +
                    "missing, the server's browser_install tool downloads it.",
                    "https://playwright.dev/docs/getting-started-mcp",
                    List.of("Use Playwright MCP to open http://localhost:8080 and check that the login page shows an error for a wrong password",
                            "Use Playwright MCP to go through the checkout flow on http://localhost:3000 and report anything broken"),
                    List.of("--headless (no visible window)", "--browser=chrome|firefox|webkit|msedge", "--isolated (fresh profile each session)")),
            new Known("chrome-devtools", "Chrome DevTools MCP (Google)",
                    List.of("chrome devtools mcp", "chrome-devtools mcp", "chrome-devtools-mcp", "chrome devtools", "devtools mcp"),
                    "Google's Chrome DevTools MCP server. It controls and inspects a live Chrome browser with DevTools.",
                    "performance traces, network requests, console errors, screenshots and DOM inspection while debugging a web app",
                    "20.19", List.of("-y", "chrome-devtools-mcp@latest"),
                    "Needs Google Chrome (current stable). Chrome starts automatically on the first tool call.",
                    "https://github.com/ChromeDevTools/chrome-devtools-mcp",
                    List.of("Use Chrome DevTools MCP to record a performance trace of http://localhost:3000 and list the slowest requests"),
                    List.of("--headless=true", "--isolated=true", "--channel=stable|beta|canary|dev")),
            new Known("filesystem", "Filesystem MCP (reference server)",
                    List.of("filesystem mcp", "file system mcp", "server-filesystem", "@modelcontextprotocol/server-filesystem"),
                    "The Model Context Protocol reference server for reading and writing files in folders you allow.",
                    "letting MCP clients read, search and edit files inside the allowed folders",
                    "18.0", List.of("-y", "@modelcontextprotocol/server-filesystem"),
                    "", "https://github.com/modelcontextprotocol/servers/tree/main/src/filesystem",
                    List.of("Use filesystem MCP to list the files in the docs folder"),
                    List.of("allowed folder paths are passed as arguments (Eliya uses the project folder)")),
            new Known("memory", "Memory MCP (reference server)",
                    List.of("memory mcp", "server-memory", "@modelcontextprotocol/server-memory", "knowledge graph mcp"),
                    "The Model Context Protocol reference server that keeps a small knowledge graph across sessions.",
                    "remembering entities, relations and notes between runs",
                    "18.0", List.of("-y", "@modelcontextprotocol/server-memory"),
                    "", "https://github.com/modelcontextprotocol/servers/tree/main/src/memory",
                    List.of("Use memory MCP to remember that the staging URL is https://staging.example.com"),
                    List.of()),
            new Known("sequential-thinking", "Sequential Thinking MCP (reference server)",
                    List.of("sequential thinking mcp", "sequential-thinking mcp", "server-sequential-thinking",
                            "@modelcontextprotocol/server-sequential-thinking"),
                    "The Model Context Protocol reference server for step-by-step structured reasoning.",
                    "breaking a hard problem into revisable thinking steps",
                    "18.0", List.of("-y", "@modelcontextprotocol/server-sequential-thinking"),
                    "", "https://github.com/modelcontextprotocol/servers/tree/main/src/sequentialthinking",
                    List.of(), List.of()));

    private McpKnownServers() { }

    static Optional<Known> byId(String idOrAlias) {
        if (idOrAlias == null) return Optional.empty();
        String wanted = idOrAlias.strip().toLowerCase(Locale.ROOT).replaceAll("\\s+mcp$", "").replace('_', '-');
        for (Known known : ALL) {
            if (known.id().equals(wanted)) return Optional.of(known);
            for (String alias : known.aliases()) {
                String a = alias.toLowerCase(Locale.ROOT);
                if (a.equals(wanted) || a.equals(wanted + " mcp") || a.replaceAll("\\s+mcp$", "").equals(wanted)) return Optional.of(known);
            }
        }
        return Optional.empty();
    }

    /** Known servers named in free text (longest aliases first, whole words). */
    static List<Known> mentionedIn(String text) {
        List<Known> found = new ArrayList<>();
        if (text == null || text.isBlank()) return found;
        String lower = text.toLowerCase(Locale.ROOT);
        for (Known known : ALL) {
            for (String alias : known.aliases()) {
                Pattern pattern = Pattern.compile("(?<![a-z0-9@/-])" + Pattern.quote(alias.toLowerCase(Locale.ROOT)) + "(?![a-z0-9-])");
                if (pattern.matcher(lower).find()) { found.add(known); break; }
            }
        }
        return found;
    }

    private static final Pattern MCP_WORD = Pattern.compile("(?i)(?<![a-z0-9])mcp(?![a-z0-9])");
    private static final Pattern SETUP_VERB = Pattern.compile(
            "(?i)\\b(?:configure|config|set\\s*up|setup|install|add|enable|connect|register|integrate|hook\\s*up|wire\\s*up)\\b");

    /** "configure playwright MCP", "set up the Playwright MCP server", "add chrome devtools mcp" … */
    static boolean isSetupRequest(String text) {
        return text != null && MCP_WORD.matcher(text).find() && SETUP_VERB.matcher(text).find();
    }

    /** Short, factual context for the model when the user talks about an MCP server Eliya knows. */
    static String knowledgeFor(String text, boolean agentMode) {
        if (text == null || !MCP_WORD.matcher(text).find()) return "";
        List<Known> mentioned = mentionedIn(text);
        boolean setup = isSetupRequest(text);
        if (mentioned.isEmpty() && !setup) return "";
        StringBuilder out = new StringBuilder("ELIYA MCP KNOWLEDGE (built in, authoritative for Eliya):\n");
        for (Known known : mentioned) {
            out.append("- ").append(known.title()).append(": ").append(known.summary()).append(" Used for: ")
                    .append(known.usedFor()).append(". Runs locally with `npx ").append(String.join(" ", known.baseArgs()))
                    .append("` (Node.js ").append(known.minNode()).append("+").append(").");
            if (!known.browserRequirement().isBlank()) out.append(' ').append(known.browserRequirement());
            if (!known.options().isEmpty()) out.append(" Options: ").append(String.join("; ", known.options())).append('.');
            out.append(" Docs: ").append(known.docs()).append('\n');
        }
        out.append("- How Eliya uses MCP: servers are read from ~/.eliya/mcp-servers.json (Eliya-managed, all projects), ")
                .append("~/.agents/mcp.json, and the project's .opencode/mcp.json or .agents/mcp.json. MCP stays off until the ")
                .append("MCP master switch is on, and MCP tools are only loaded when the user's request contains the word \"MCP\".\n");
        if (setup) {
            if (agentMode) {
                out.append("- To configure a server, call the mcp_configure tool (server=")
                        .append(mentioned.isEmpty() ? "<name>" : mentioned.get(0).id())
                        .append("). It checks Node.js/npx, writes the config, turns the MCP master switch on, starts the server and ")
                        .append("lists its tools — one approval covers all of it. Do NOT hand-write MCP config files or run npx yourself ")
                        .append("for a known server. Report the tool's verified result; if it reports a blocker, say exactly what the user must do.\n");
            } else {
                out.append("- This is Analyse mode (read-only): explain what the server is and what configuring it involves. ")
                        .append("To have Eliya configure it, the user switches to Agent mode (Tab in the terminal chat, or the Agent toggle) ")
                        .append("and sends the same request; Eliya then checks Node.js, writes the config, enables MCP and verifies the connection.\n");
            }
        }
        return out.toString();
    }

    /** Human list for "which servers do you know?" and for unknown names. */
    static String catalogText() {
        StringBuilder out = new StringBuilder("Built-in MCP servers Eliya can configure:\n");
        for (Known known : ALL) out.append("- ").append(known.id()).append(": ").append(known.title()).append(" — ").append(known.usedFor()).append('\n');
        out.append("Other servers: give the exact npx package (for example @scope/server-name) or a URL for a remote server.");
        return out.toString();
    }

    /** Compare "v20.11.1" with "20.19". */
    static boolean nodeAtLeast(String versionOutput, String minimum) {
        int[] have = parseVersion(versionOutput), need = parseVersion(minimum);
        if (have == null || need == null) return false;
        for (int i = 0; i < 3; i++) {
            if (have[i] != need[i]) return have[i] > need[i];
        }
        return true;
    }

    static int[] parseVersion(String text) {
        if (text == null) return null;
        java.util.regex.Matcher m = Pattern.compile("(\\d+)(?:\\.(\\d+))?(?:\\.(\\d+))?").matcher(text);
        if (!m.find()) return null;
        return new int[]{Integer.parseInt(m.group(1)), m.group(2) == null ? 0 : Integer.parseInt(m.group(2)),
                m.group(3) == null ? 0 : Integer.parseInt(m.group(3))};
    }
}
