package com.llmart.llm.cli.tui;

import java.util.ArrayList;
import java.util.List;

/** Thread-safe conversation transcript shown by the terminal chat. */
public final class TuiTranscript {
    public enum Kind { USER, ASSISTANT, ACTIVITY, INFO, ERROR, APPROVAL, QUESTION, RESULT, QUEUED }

    public static final class Entry {
        private final Kind kind;
        private final String title;
        private String status;
        private final StringBuilder text = new StringBuilder();

        Entry(Kind kind, String title, String status, String text) {
            this.kind = kind; this.title = title == null ? "" : title; this.status = status == null ? "" : status;
            if (text != null) this.text.append(text);
        }
        public Kind kind() { return kind; }
        public String title() { return title; }
        public synchronized String status() { return status; }
        public synchronized String text() { return text.toString(); }
        synchronized void status(String value) { status = value == null ? "" : value; }
        synchronized void append(String delta) { text.append(delta); }
        synchronized void replace(String value) { text.setLength(0); text.append(value == null ? "" : value); }
    }

    /** Notified after every change; implementations must not call back into the transcript while locked. */
    public interface Observer {
        void added(Entry entry);
        void appended(Entry entry, String delta);
        void updated(Entry entry);
    }

    private static final int MAX_ENTRIES = 3000;
    private final List<Entry> entries = new ArrayList<>();
    private final List<Observer> observers = new java.util.concurrent.CopyOnWriteArrayList<>();
    private volatile long version;

    public void observe(Observer observer) { observers.add(observer); }
    public long version() { return version; }

    public Entry add(Kind kind, String title, String status, String text) {
        Entry entry = new Entry(kind, title, status, text);
        synchronized (this) {
            entries.add(entry);
            if (entries.size() > MAX_ENTRIES) entries.subList(0, entries.size() - MAX_ENTRIES).clear();
            version++;
        }
        for (Observer observer : observers) observer.added(entry);
        return entry;
    }

    public void append(Entry entry, String delta) {
        if (delta == null || delta.isEmpty()) return;
        entry.append(delta);
        synchronized (this) { version++; }
        for (Observer observer : observers) observer.appended(entry, delta);
    }

    public void update(Entry entry, String status, String text) {
        if (status != null) entry.status(status);
        if (text != null) entry.replace(text);
        synchronized (this) { version++; }
        for (Observer observer : observers) observer.updated(entry);
    }

    public synchronized List<Entry> snapshot() { return new ArrayList<>(entries); }

    public synchronized Entry last() { return entries.isEmpty() ? null : entries.get(entries.size() - 1); }

    public synchronized void clear() { entries.clear(); version++; }

    /** Last assistant answer (what /copy copies). */
    public synchronized String lastAnswer() {
        for (int i = entries.size() - 1; i >= 0; i--)
            if (entries.get(i).kind() == Kind.ASSISTANT && !entries.get(i).text().isBlank()) return entries.get(i).text();
        return "";
    }

    /** Markdown export of the visible conversation. */
    public synchronized String toMarkdown() {
        StringBuilder out = new StringBuilder("# Eliya terminal conversation\n\n");
        for (Entry entry : entries) {
            switch (entry.kind()) {
                case USER -> out.append("## You\n\n").append(entry.text().strip()).append("\n\n");
                case ASSISTANT -> out.append("## Eliya\n\n").append(entry.text().strip()).append("\n\n");
                case ERROR -> out.append("> **Error:** ").append(entry.text().strip().replace("\n", "\n> ")).append("\n\n");
                case INFO, QUEUED -> { }
                default -> out.append("- ").append(entry.title().isBlank() ? "" : "**" + entry.title() + "** ")
                        .append(entry.status().isBlank() ? "" : "(" + entry.status() + ") ")
                        .append(entry.text().strip().replace("\n", " ")).append('\n');
            }
        }
        return out.toString();
    }
}
