package com.llmart.llm.autonomy;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.nio.file.Path;
import java.time.DayOfWeek;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.EnumSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * {@code ~/.eliya/schedule.json}: recurring local jobs.
 * <pre>
 * {"jobs":[
 *   {"id":"nightly-tests","workspace":"C:\\projects\\shop","time":"02:00","days":["MON","TUE","WED","THU","FRI"],
 *    "task":"Run the full test suite and fix any failing tests.","maxMinutes":45},
 *   {"id":"todo-sweep","workspace":"/home/me/app","everyMinutes":240,"task":"Resolve one TODO in src/ with tests."}
 * ]}
 * </pre>
 */
public record AutonomousSchedule(List<Job> jobs) {
    public record Job(String id, String workspace, String task, LocalTime time, Set<DayOfWeek> days, long everyMinutes,
                      boolean inPlace, long maxMinutes, long maxTurns, long maxTokens, boolean enabled) {
        /** Whether the job is due at {@code now}, given when it last ran (null = never). */
        public boolean due(LocalDateTime now, LocalDateTime lastRun) {
            if (!enabled) return false;
            if (everyMinutes > 0) return lastRun == null || Duration.between(lastRun, now).toMinutes() >= everyMinutes;
            if (time == null || !days.contains(now.getDayOfWeek())) return false;
            LocalDateTime slot = now.toLocalDate().atTime(time);
            // Due once per day, within a 30-minute catch-up window after the slot (e.g. the JAR was starting).
            return !now.isBefore(slot) && now.isBefore(slot.plusMinutes(30)) && (lastRun == null || lastRun.isBefore(slot));
        }
    }

    private static final ObjectMapper JSON = new ObjectMapper();

    public static AutonomousSchedule load(Path file) throws Exception {
        JsonNode root = JSON.readTree(file.toFile());
        List<Job> jobs = new ArrayList<>();
        for (JsonNode node : root.path("jobs")) {
            String id = node.path("id").asText("").strip();
            String task = node.path("task").asText("").strip();
            String workspace = node.path("workspace").asText("").strip();
            if (id.isEmpty() || task.isEmpty() || workspace.isEmpty()) continue;
            LocalTime time = node.hasNonNull("time") ? LocalTime.parse(node.path("time").asText().strip()) : null;
            Set<DayOfWeek> days = EnumSet.noneOf(DayOfWeek.class);
            if (node.path("days").isArray()) {
                for (JsonNode day : node.path("days")) days.add(parseDay(day.asText()));
            } else {
                days = EnumSet.allOf(DayOfWeek.class);
            }
            jobs.add(new Job(id, workspace, task, time, days, Math.max(0, node.path("everyMinutes").asLong(0)),
                    "in-place".equalsIgnoreCase(node.path("mode").asText("")) || node.path("inPlace").asBoolean(false),
                    node.path("maxMinutes").asLong(0), node.path("maxTurns").asLong(0), node.path("maxTokens").asLong(0),
                    node.path("enabled").asBoolean(true)));
        }
        return new AutonomousSchedule(List.copyOf(jobs));
    }

    private static DayOfWeek parseDay(String raw) {
        String value = raw.strip().toUpperCase(Locale.ROOT);
        for (DayOfWeek day : DayOfWeek.values()) if (day.name().startsWith(value.substring(0, Math.min(3, value.length())))) return day;
        throw new IllegalArgumentException("Unknown day: " + raw);
    }
}
