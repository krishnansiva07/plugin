package com.llmart.llm.cli.tui;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;

/**
 * Full-screen terminal chat (like opencode): header, scrollable transcript, multi-line message box, status and hints.
 * No mouse capture, so the terminal's own text selection and copy/paste keep working.
 */
public final class EliyaTui implements TuiController.View {
    private static final String[] SPINNER = {"⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"};
    private static final List<String> COMMANDS = List.of("/analyse", "/agent", "/implement", "/check", "/queue", "/send",
            "/drop", "/stop", "/new", "/workspace", "/status", "/copy", "/export", "/web", "/window", "/clear", "/help", "/exit");

    private final TuiTerminal terminal;
    private final TuiController controller;
    private final TuiInputBox input = new TuiInputBox();
    private final Object lock = new Object();
    private final Map<TuiTranscript.Entry, Cached> cache = new IdentityHashMap<>();
    private volatile boolean exit;
    private volatile boolean dirty = true;
    private int rows = 24, cols = 80;
    private int scroll;            // lines above the bottom (0 = follow the conversation)
    private int lastTotalLines;
    private long lastCtrlC;
    private String flash = "";
    private long flashUntil;
    private int spinner;

    private record Cached(String text, String status, int width, List<String> lines) { }

    public EliyaTui(TuiTerminal terminal, TuiController controller) {
        this.terminal = terminal;
        this.controller = controller;
    }

    /** Run until the user exits. Restores the terminal in all cases. */
    public void run() throws Exception {
        controller.attach(this);
        int[] size = terminal.size();
        rows = size[0]; cols = size[1];
        terminal.enter();
        Thread painter = new Thread(this::paintLoop, "eliya-tui-paint");
        painter.setDaemon(true);
        try {
            painter.start();
            controller.start();
            changed();
            TuiKeys keys = new TuiKeys(terminal.input());
            while (!exit) {
                TuiKeys.Key key = keys.read();
                if (key.type() == TuiKeys.Type.EOF) break;
                synchronized (lock) { handle(key); }
                changed();
            }
        } finally {
            exit = true;
            if (controller.running()) {
                try { controller.stop(); Thread.sleep(300); } catch (Exception ignored) { }
            }
            terminal.close();
            controller.shutdown();
        }
    }

    // --------------------------------------------------------------------------------------------- key handling

    void handle(TuiKeys.Key key) {
        switch (key.type()) {
            case PASTE -> input.insert(key.text());
            case CHAR -> {
                String text = key.text();
                if (controller.approval() != null && input.isEmpty() && text.length() == 1 && "yYaAnN".contains(text)) {
                    controller.submit(text.toLowerCase());
                } else input.insert(text);
            }
            case NEWLINE -> input.insert("\n");
            case ENTER -> {
                String text = input.text();
                if (text.endsWith("\\") && !text.endsWith("\\\\")) { input.backspace(); input.insert("\n"); return; }
                String message = input.take();
                if (!message.isEmpty()) { scroll = 0; controller.submit(message); }
            }
            case TAB -> {
                String text = input.text();
                if (text.startsWith("/") && !text.contains(" ")) complete(text);
                else if (input.isEmpty()) controller.toggleMode();
                else input.insert("    ");
            }
            case BACKSPACE -> input.backspace();
            case DELETE -> input.delete();
            case LEFT -> input.left();
            case RIGHT -> input.right();
            case HOME -> input.home();
            case END -> input.end();
            case UP -> { if (!input.up()) scrollBy(3); }
            case DOWN -> { if (!input.down()) scrollBy(-3); }
            case PAGE_UP -> scrollBy(Math.max(1, transcriptHeight() - 2));
            case PAGE_DOWN -> scrollBy(-Math.max(1, transcriptHeight() - 2));
            case ESCAPE -> { if (scroll > 0) scroll = 0; }
            case CTRL -> control(key.ctrl());
            default -> { }
        }
    }

    private void control(char letter) {
        switch (letter) {
            case 'c' -> {
                if (controller.running()) { controller.stop(); flash("Stopping the task…"); }
                else if (!input.isEmpty()) input.clear();
                else if (System.currentTimeMillis() - lastCtrlC < 2000) exit = true;
                else { lastCtrlC = System.currentTimeMillis(); flash("Press Ctrl+C again to exit"); }
            }
            case 'd' -> { if (input.isEmpty()) exit = true; else input.delete(); }
            case 'q' -> {
                String message = input.take();
                if (message.isEmpty()) flash("Type a message, then Ctrl+Q queues it as the next task");
                else controller.queueNext(message);
            }
            case 'a' -> input.home();
            case 'e' -> input.end();
            case 'u' -> input.clear();
            case 'w' -> input.deleteWordBefore();
            case 'p' -> input.historyPrevious();
            case 'n' -> input.historyNext();
            case 'l' -> { cache.clear(); }
            case 'o' -> controller.submit("/copy");
            default -> { }
        }
    }

    private void complete(String prefix) {
        List<String> matches = COMMANDS.stream().filter(command -> command.startsWith(prefix.toLowerCase())).toList();
        if (matches.size() == 1) input.set(matches.get(0) + " ");
        else if (!matches.isEmpty()) flash(String.join("  ", matches));
    }

    private void flash(String text) { flash = text; flashUntil = System.currentTimeMillis() + 2500; }

    private void scrollBy(int lines) { scroll = Math.max(0, scroll + lines); }

    // --------------------------------------------------------------------------------------------- View services

    @Override public void changed() { dirty = true; }

    @Override public void exit() { exit = true; }

    @Override public String copy(String text) {
        try { terminal.write(TuiClipboard.osc52(text)); terminal.flush(); } catch (IOException ignored) { }
        String command = TuiClipboard.copyNative(text);
        return "Copied the last answer (" + text.length() + " characters)" + (command == null ? " via the terminal clipboard" : " with " + command) + ".";
    }

    @Override public void openWeb(String url, boolean window) {
        if (window) com.llmart.llm.cli.EliyaUiLauncher.openAppWindow(url);
        else com.llmart.llm.cli.EliyaCliBridge.openBrowser(url);
    }

    // --------------------------------------------------------------------------------------------------- paint

    private void paintLoop() {
        long lastSizeCheck = 0, lastTick = 0;
        while (!exit) {
            long now = System.currentTimeMillis();
            if (now - lastSizeCheck > 600) {
                lastSizeCheck = now;
                int[] size = terminal.size();
                if (size[0] != rows || size[1] != cols) { synchronized (lock) { rows = size[0]; cols = size[1]; cache.clear(); } dirty = true; }
            }
            if (controller.running() && now - lastTick > 120) { lastTick = now; spinner++; dirty = true; }
            if (!flash.isEmpty() && now > flashUntil) { flash = ""; dirty = true; }
            if (dirty) {
                dirty = false;
                try {
                    String frame;
                    synchronized (lock) { frame = frame(); }
                    terminal.write(frame);
                    terminal.flush();
                } catch (IOException ignored) { }
            }
            try { Thread.sleep(30); } catch (InterruptedException interrupted) { return; }
        }
    }

    private int inputWidth() { return Math.max(10, cols - 4); }

    private int inputRows() {
        int lines = input.layout(inputWidth()).rows().size();
        return Math.max(1, Math.min(lines, Math.max(3, rows / 3)));
    }

    private int transcriptHeight() { return Math.max(1, rows - 1 - 1 - (inputRows() + 2) - 1); }

    /** Build one complete frame (package-visible for tests). */
    String frame() {
        StringBuilder out = new StringBuilder(rows * cols + 256);
        out.append("\u001b[?2026h\u001b[?25l\u001b[H");
        int width = cols;
        // Header
        out.append(line(header(width), width));
        // Transcript
        int height = transcriptHeight();
        List<String> lines = transcriptLines(width);
        int total = lines.size();
        if (scroll > 0 && total > lastTotalLines) scroll += total - lastTotalLines; // keep the view still while reading
        lastTotalLines = total;
        int maxScroll = Math.max(0, total - height);
        if (scroll > maxScroll) scroll = maxScroll;
        int end = total - scroll;
        int start = Math.max(0, end - height);
        for (int i = 0; i < height; i++) {
            int index = start + i;
            String text = index < end ? lines.get(index) : "";
            if (i == height - 1 && scroll > 0) text = TuiText.GRAY + "  ↓ " + scroll + " more lines — PgDn or Esc to follow" + TuiText.RESET;
            out.append(line(text, width));
        }
        // Status line
        out.append(line(statusLine(width), width));
        // Input box
        TuiInputBox.Layout layout = input.layout(inputWidth());
        int boxRows = inputRows();
        int first = Math.max(0, Math.min(layout.cursorRow() - boxRows + 1, layout.rows().size() - boxRows));
        if (layout.cursorRow() < first) first = layout.cursorRow();
        String color = boxColor();
        String title = boxTitle();
        out.append(line(color + "╭─ " + TuiText.BOLD + title + TuiText.RESET + color + " " +
                "─".repeat(Math.max(0, width - 5 - TuiText.visibleWidth(title))) + "╮" + TuiText.RESET, width));
        for (int i = 0; i < boxRows; i++) {
            int index = first + i;
            String content = index < layout.rows().size() ? layout.rows().get(index) : "";
            if (input.isEmpty() && i == 0) content = TuiText.GRAY + placeholder() + TuiText.RESET;
            out.append(line(color + "│" + TuiText.RESET + " " + TuiText.pad(clip(content, inputWidth()), inputWidth()) + " " + color + "│" + TuiText.RESET, width));
        }
        out.append(line(color + "╰" + "─".repeat(Math.max(0, width - 2)) + "╯" + TuiText.RESET, width));
        // Footer (last row, no newline to avoid scrolling)
        String footer = TuiText.GRAY + TuiText.fit(footer(), width) + TuiText.RESET;
        out.append(footer).append("\u001b[K");
        // Cursor
        int cursorRow = 1 + height + 1 + 1 + (layout.cursorRow() - first) + 1;
        int cursorCol = 3 + layout.cursorColumn();
        out.append("\u001b[").append(cursorRow).append(';').append(Math.min(width, cursorCol)).append('H');
        out.append("\u001b[?25h\u001b[?2026l");
        return out.toString();
    }

    private static String line(String text, int width) {
        return clip(text, width) + "\u001b[0m\u001b[K\r\n";
    }

    /** Cut a styled string to {@code width} visible cells. */
    static String clip(String styled, int width) {
        if (TuiText.visibleWidth(styled) <= width) return styled;
        StringBuilder out = new StringBuilder();
        int used = 0;
        for (int i = 0; i < styled.length(); ) {
            char c = styled.charAt(i);
            if (c == '\u001b') { int next = TuiText.skipEscape(styled, i); out.append(styled, i, next); i = next; continue; }
            int cp = styled.codePointAt(i);
            int w = TuiText.width(cp);
            if (used + w > width) break;
            out.appendCodePoint(cp); used += w;
            i += Character.charCount(cp);
        }
        return out.append(TuiText.RESET).toString();
    }

    private String header(int width) {
        String mode = TuiController.label(controller.mode());
        String modeStyle = "agent".equals(controller.mode()) ? TuiText.MAGENTA : TuiText.CYAN;
        String workspace = controller.workspace().isBlank() ? "no workspace" : shortPath(controller.workspace());
        String model = controller.modelConfigured() ? controller.model() : "model not configured";
        String state;
        if (controller.approval() != null) state = TuiText.YELLOW + "● approval needed" + TuiText.RESET;
        else if (controller.question() != null) state = TuiText.BLUE + "● question" + TuiText.RESET;
        else if (controller.running()) state = TuiText.YELLOW + "● running " + elapsed() + TuiText.RESET;
        else state = TuiText.GREEN + "● ready" + TuiText.RESET;
        String left = TuiText.BOLD + " ELIYA " + TuiText.RESET + TuiText.GRAY + "│ " + TuiText.RESET + modeStyle + TuiText.BOLD + mode +
                TuiText.RESET + TuiText.GRAY + " │ " + TuiText.RESET + TuiText.fit(workspace, Math.max(10, width / 3)) +
                TuiText.GRAY + " │ " + TuiText.fit(model, 28) + TuiText.RESET;
        int gap = width - TuiText.visibleWidth(left) - TuiText.visibleWidth(state) - 1;
        return gap > 0 ? left + " ".repeat(gap) + state : left;
    }

    static String shortPath(String path) {
        String home = System.getProperty("user.home", "");
        return !home.isBlank() && path.startsWith(home) ? "~" + path.substring(home.length()) : path;
    }

    private String elapsed() {
        long seconds = Math.max(0, (System.currentTimeMillis() - controller.runStartedAt()) / 1000);
        return seconds < 60 ? seconds + "s" : (seconds / 60) + "m" + String.format("%02d", seconds % 60) + "s";
    }

    private String statusLine(int width) {
        if (!flash.isEmpty()) return TuiText.YELLOW + " " + TuiText.fit(flash, width - 2) + TuiText.RESET;
        int queued = controller.queued().size();
        String queue = queued == 0 ? "" : TuiText.GRAY + "  · " + queued + " queued" + TuiText.RESET;
        if (controller.approval() != null)
            return TuiText.YELLOW + TuiText.BOLD + " Approval: " + TuiText.RESET + TuiText.YELLOW +
                    (controller.approval().allowRun() ? "y = this action · a = all this run · n = deny" : "y = allow deletion · n = deny") + TuiText.RESET + queue;
        if (controller.question() != null)
            return TuiText.BLUE + " Answer the question: number, option text or your own words — Enter sends" + TuiText.RESET + queue;
        if (controller.running())
            return TuiText.YELLOW + " " + SPINNER[spinner % SPINNER.length] + " " + TuiText.RESET +
                    TuiText.fit(controller.activity().isBlank() ? "working…" : controller.activity(), Math.max(10, width - 30)) + queue;
        return queue.isEmpty() ? "" : queue;
    }

    private String boxColor() {
        if (controller.approval() != null) return TuiText.YELLOW;
        if (controller.question() != null) return TuiText.BLUE;
        return "agent".equals(controller.mode()) ? TuiText.MAGENTA : TuiText.CYAN;
    }

    private String boxTitle() {
        if (controller.approval() != null) return "Approval (y / a / n)";
        if (controller.question() != null) return "Your answer";
        if (controller.running()) return controller.runId().isBlank() ? "Message (queued until done)" : "Add to running task";
        return TuiController.label(controller.mode());
    }

    private String placeholder() {
        if (controller.approval() != null) return "Press y, a or n";
        if (controller.question() != null) return "Type 1, 2 … or your own answer";
        if (controller.running()) return controller.runId().isBlank()
                ? "Type a message — it runs when the current answer finishes"
                : "Enter: add to the running task · Ctrl+Q: queue as next task · Ctrl+C: stop";
        return "agent".equals(controller.mode()) ? "Describe a change to make…" : "Ask about the project…";
    }

    private String footer() {
        if (controller.running()) return " Enter add to task · Ctrl+Q queue next · Ctrl+C stop · PgUp/PgDn scroll · /web browser";
        return " Enter send · Alt+Enter new line · Tab Analyse/Agent · PgUp/PgDn scroll · Ctrl+O copy answer · /help · Ctrl+D exit";
    }

    // ------------------------------------------------------------------------------------------ transcript lines

    List<String> transcriptLines(int width) {
        List<String> lines = new ArrayList<>();
        List<TuiTranscript.Entry> entries = controller.transcript().snapshot();
        cache.keySet().retainAll(new java.util.HashSet<>(entries)); // Entry equality is identity
        TuiTranscript.Kind previous = null;
        for (TuiTranscript.Entry entry : entries) {
            boolean compact = entry.kind() == TuiTranscript.Kind.ACTIVITY && previous == TuiTranscript.Kind.ACTIVITY;
            if (!compact && previous != null) lines.add("");
            String text = entry.text(), status = entry.status();
            Cached cached = cache.get(entry);
            if (cached == null || cached.width() != width || !cached.text().equals(text) || !cached.status().equals(status)) {
                cached = new Cached(text, status, width, render(entry, text, status, width));
                cache.put(entry, cached);
            }
            lines.addAll(cached.lines());
            previous = entry.kind();
        }
        return lines;
    }

    static List<String> render(TuiTranscript.Entry entry, String text, String status, int width) {
        List<String> out = new ArrayList<>();
        int inner = Math.max(10, width - 4);
        switch (entry.kind()) {
            case USER -> {
                String label = entry.title().isBlank() ? "You" : entry.title();
                out.add(TuiText.CYAN + "┃ " + TuiText.BOLD + label + TuiText.RESET);
                for (String row : TuiText.wrap(text, inner)) out.add(TuiText.CYAN + "┃ " + TuiText.RESET + row);
            }
            case ASSISTANT -> {
                out.add(TuiText.MAGENTA + TuiText.BOLD + "◆ Eliya" + TuiText.RESET);
                out.addAll(markdown(text, inner));
            }
            case ACTIVITY -> {
                String icon = switch (status) {
                    case "success", "completed", "done" -> TuiText.GREEN + "✓";
                    case "error", "failed", "denied", "blocked" -> TuiText.RED + "✗";
                    case "warning" -> TuiText.YELLOW + "!";
                    case "running", "started" -> TuiText.YELLOW + "◌";
                    default -> TuiText.GRAY + "·";
                };
                String title = entry.title().isBlank() ? "" : TuiText.BOLD + entry.title() + TuiText.RESET + " ";
                out.add("  " + icon + TuiText.RESET + " " + title + TuiText.GRAY +
                        TuiText.fit(text, Math.max(10, width - 6 - TuiText.visibleWidth(entry.title()))) + TuiText.RESET);
            }
            case INFO -> { for (String row : TuiText.wrap(text, inner)) out.add(TuiText.GRAY + "  " + row + TuiText.RESET); }
            case ERROR -> {
                List<String> rows = TuiText.wrap((entry.title().isBlank() ? "" : entry.title() + ": ") + text, inner);
                for (int i = 0; i < rows.size(); i++) out.add(TuiText.RED + (i == 0 ? "✗ " : "  ") + rows.get(i) + TuiText.RESET);
            }
            case APPROVAL -> {
                out.add(TuiText.YELLOW + TuiText.BOLD + "⚠ " + entry.title() + TuiText.RESET);
                for (String row : TuiText.wrap(text, inner)) out.add(TuiText.YELLOW + "│ " + TuiText.RESET + row);
            }
            case QUESTION -> {
                out.add(TuiText.BLUE + TuiText.BOLD + "? " + entry.title() + TuiText.RESET);
                for (String row : TuiText.wrap(text, inner)) out.add(TuiText.BLUE + "│ " + TuiText.RESET + row);
            }
            case RESULT -> {
                String color = "success".equals(status) ? TuiText.GREEN : TuiText.YELLOW;
                List<String> rows = TuiText.wrap(text, inner);
                for (int i = 0; i < rows.size(); i++)
                    out.add(color + (i == 0 ? "■ " + TuiText.BOLD + entry.title() + ": " + TuiText.RESET + color : "  ") + rows.get(i) + TuiText.RESET);
            }
            case QUEUED -> {
                List<String> rows = TuiText.wrap(text, inner);
                for (int i = 0; i < rows.size(); i++)
                    out.add(TuiText.GRAY + (i == 0 ? "⏳ " + entry.title() + ": " : "   ") + rows.get(i) + TuiText.RESET);
            }
        }
        return out;
    }

    /**
     * Light Markdown styling that keeps the text itself unchanged (so mouse-copied text matches the answer).
     * ELIYA184: a ```markdown fence wrapping the whole answer is shown dimmed and its content is styled as Markdown
     * (not as one cyan code block); headings, tables, bold and inline code get colour, syntax markers are dimmed.
     */
    static List<String> markdown(String text, int width) {
        List<String> out = new ArrayList<>();
        String[] rows = TuiText.sanitize(text).split("\n", -1);
        int[] wrapper = wrapperFence(rows);
        boolean code = false;
        for (int index = 0; index < rows.length; index++) {
            String raw = rows[index];
            String trimmed = raw.stripLeading();
            if (wrapper != null && (index == wrapper[0] || index == wrapper[1])) {
                out.add("  " + TuiText.GRAY + raw + TuiText.RESET);
                continue;
            }
            if (trimmed.startsWith("```") || trimmed.startsWith("~~~")) {
                code = !code;
                out.add("  " + TuiText.GRAY + raw + TuiText.RESET);
                continue;
            }
            if (code) {
                for (String row : TuiText.wrap(raw, width)) out.add("  " + TuiText.CYAN + row + TuiText.RESET);
                continue;
            }
            boolean heading = trimmed.matches("#{1,6}\\s.*");
            boolean rule = trimmed.matches("(?:-{3,}|\\*{3,}|_{3,})");
            boolean tableDivider = trimmed.startsWith("|") && trimmed.matches("\\|?[\\s:|-]+\\|?") && trimmed.contains("-");
            String style = heading ? (trimmed.startsWith("###") ? TuiText.BOLD : TuiText.BOLD + TuiText.MAGENTA)
                    : trimmed.startsWith(">") || rule || tableDivider ? TuiText.GRAY : "";
            List<String> wrapped = TuiText.wrap(raw, width);
            boolean bullet = trimmed.matches("([-*+]|\\d+[.)]) .*");
            int indent = bullet ? raw.length() - trimmed.length() + trimmed.indexOf(' ') + 1 : 0;
            for (int i = 0; i < wrapped.size(); i++) {
                String row = i > 0 && bullet ? " ".repeat(Math.min(indent, 8)) + wrapped.get(i).stripLeading() : wrapped.get(i);
                out.add("  " + (style.isEmpty() ? inlineStyles(row, trimmed.startsWith("|")) : style + row + TuiText.RESET));
            }
        }
        return out;
    }

    /** Bold and `code` spans styled, their markers dimmed; table pipes dimmed. Text itself is unchanged. */
    static String inlineStyles(String row, boolean tableRow) {
        String styled = row.replaceAll("\\*\\*([^*\\n]+?)\\*\\*",
                        java.util.regex.Matcher.quoteReplacement(TuiText.GRAY + "**" + TuiText.RESET + TuiText.BOLD) + "$1" +
                        java.util.regex.Matcher.quoteReplacement(TuiText.RESET + TuiText.GRAY + "**" + TuiText.RESET))
                .replaceAll("`([^`\\n]+?)`",
                        java.util.regex.Matcher.quoteReplacement(TuiText.GRAY + "`" + TuiText.RESET + TuiText.CYAN) + "$1" +
                        java.util.regex.Matcher.quoteReplacement(TuiText.RESET + TuiText.GRAY + "`" + TuiText.RESET));
        if (tableRow) styled = styled.replace("|", TuiText.GRAY + "|" + TuiText.RESET);
        return styled;
    }

    /** Line indexes {open, close} of a ```markdown fence that wraps the whole answer (close -1 while streaming), or null. */
    static int[] wrapperFence(String[] rows) {
        int open = -1;
        for (int i = 0; i < rows.length; i++) {
            if (rows[i].isBlank()) continue;
            if (rows[i].stripLeading().matches("(?i)(`{3,}|~{3,})\\s*(?:markdown|md|gfm|mdx)\\s*")) open = i;
            break;
        }
        if (open < 0) return null;
        char marker = rows[open].stripLeading().charAt(0);
        int last = rows.length - 1;
        while (last > open && rows[last].isBlank()) last--;
        if (last > open && rows[last].strip().matches("[`~]{3,}") && rows[last].strip().charAt(0) == marker) {
            boolean inside = false;
            for (int i = open + 1; i < last; i++) {
                String t = rows[i].stripLeading();
                if (!(t.startsWith("```") || t.startsWith("~~~"))) continue;
                if (!inside) inside = true;
                else if (t.strip().matches("[`~]{3,}")) inside = false;
            }
            if (!inside) return new int[]{open, last};
        }
        int depth = 0;
        for (int i = open + 1; i < rows.length; i++) {
            String t = rows[i].strip();
            if (!(t.startsWith("```") || t.startsWith("~~~"))) continue;
            if (!t.matches("[`~]{3,}")) { depth++; continue; }
            if (depth > 0) { depth--; continue; }
            if (t.charAt(0) == marker) return new int[]{open, i};
        }
        return new int[]{open, -1};
    }

    /** After exit: save the conversation so it can still be copied from a file. */
    public static Path saveOnExit(TuiController controller, Path directory) {
        try {
            boolean any = controller.transcript().snapshot().stream().anyMatch(entry -> entry.kind() == TuiTranscript.Kind.USER);
            if (!any) return null;
            Files.createDirectories(directory);
            Path file = directory.resolve("last-terminal-chat.md");
            Files.writeString(file, controller.transcript().toMarkdown(), StandardCharsets.UTF_8);
            return file;
        } catch (Exception ignored) {
            return null;
        }
    }
}
