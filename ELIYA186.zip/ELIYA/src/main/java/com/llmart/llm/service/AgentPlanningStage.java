package com.llmart.llm.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.llmart.llm.dto.ChatRequest;
import com.llmart.llm.dto.ChatSettings;

import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.function.Consumer;

/**
 * Agent planning stage, extracted from {@code AgentService}: task classification, read-only planning
 * evidence, the planner model call (draft + one corrective refinement), deterministic fallback and plan preview.
 *
 * <p>Model routing/failover and UI event formatting stay in {@code AgentService}; this class reaches them only
 * through the narrow {@link Runtime} interface, which keeps planning independently readable and testable.</p>
 */
final class AgentPlanningStage {
    /** Services the planning stage borrows from the executor runtime. */
    interface Runtime {
        OpenAiCompatibleClient.AgentCompletion completeRoleText(String apiKey, ChatRequest request, AgentRunService.AgentRun run,
                                                                String model, ModelCapabilityRegistry.Role role, int maxOut,
                                                                List<Map<String,Object>> prompt, int step,
                                                                Consumer<Map<String,Object>> onStep, String purpose) throws Exception;
        Map<String,Object> stepEvent(int step, String tool, String detail, String status, String output);
        String clipUi(String value);
        String clipHeadTail(String value, int maxChars, String marker);
        String providerFailureDetail(Throwable failure);
    }

    record TaskProfile(String level, int minSteps, int maxSteps, boolean largeTask, int batchSize, String guidance) { }

    private static final ObjectMapper JSON = new ObjectMapper();
    private final Runtime runtime;
    private final AgentWorkspaceService workspaces;
    private final WorkspaceRetrievalIndexService workspaceRetrieval;
    private final ContextWindowManager contextWindows;
    private final ExecutorService parallelReadExecutor;

    AgentPlanningStage(Runtime runtime, AgentWorkspaceService workspaces, WorkspaceRetrievalIndexService workspaceRetrieval,
                       ContextWindowManager contextWindows, ExecutorService parallelReadExecutor) {
        this.runtime = runtime;
        this.workspaces = workspaces;
        this.workspaceRetrieval = workspaceRetrieval;
        this.contextWindows = contextWindows;
        this.parallelReadExecutor = parallelReadExecutor;
    }

    TaskProfile classifyTask(String task) {
        String value = task == null ? "" : task.toLowerCase(Locale.ROOT);
        if (AgentPlanRelevance.isRepositoryGuidanceRequest(task)) {
            return new TaskProfile("repository_guidance", 3, 8, false, 8,
                    "This is repository guidance / migration setup, NOT broad documentation or code migration. " +
                    "Resolve configured legacy and workspace roots; inspect only needed evidence; create or update exactly " +
                    "the requested instruction files inside workspace; verify their contents, path boundaries and input " +
                    "traceability in the FINAL step. No documentation_inventory, documentation_validate, templates, " +
                    "work-item ledger generation unless the user requests a ledger file, code modification, or full build.");
        }
        if (AgentService.isDocumentationTask(task)) {
            return new TaskProfile("documentation", 5, 10, true, 8,
                    "Use the dedicated repository documentation workflow for deterministic coverage and evidence, but preserve the user's requested document scope/structure exactly. Use documentation_template only when the UI explicitly selected it. Finish with documentation_validate against the actual user-requested output files; do not substitute compile/test for documentation validation.");
        }
        // External Jira/Confluence BRDs are output-artifact tasks even with dozens of issue IDs.
        // Do not promote them into a repository migration / compilation workflow.
        if (AgentPlanRelevance.isExternalDocumentRequest(task)) {
            return new TaskProfile("external_document", 3, 8, false, 10,
                    "Retrieve only user-requested sources (use MCP only when explicitly requested and enabled), analyse descriptions/comments/attachments/visuals as required, consolidate with source traceability, write exactly the requested artifacts, and verify artifact completeness. Do not inventory/compile the codebase or enforce a documentation template.");
        }
        if (AgentService.isSimpleGitStatusRequest(task) || AgentPlanRelevance.isReadOnlyAnalysisRequest(task)) {
            return new TaskProfile("analysis", AgentService.isSimpleGitStatusRequest(task) ? 1 : 2,
                    AgentService.isSimpleGitStatusRequest(task) ? 3 : 6, false, 10,
                    "Read-only evidence analysis: inspect only requested workspace/MCP sources, correlate facts with source paths or Jira keys, report findings and unknowns, and verify traceability. Do not edit files or run project compilation unless explicitly requested.");
        }
        int signals = 0;
        if (value.length() > 900) signals += 2; else if (value.length() > 350) signals++;
        for (String word : List.of("framework", "architecture", "migrate", "migration", "refactor", "multiple", "across", "integration", "self-heal", "self healing", "end-to-end", "e2e", "performance", "security", "repository", "codebase")) {
            if (value.contains(word)) signals++;
        }
        long pathHints = Arrays.stream(value.split("\\s+")).filter(v -> v.contains("/") || v.contains("\\")).count();
        if (pathHints > 1) signals++;

        int explicitScale = AgentPlanRelevance.explicitWorkItemCount(task);
        // Global scope must be explicit: a Jira key (e.g. BMSA-1000) or a named feature's
        // "all tests for this feature" does not authorize repository-wide migration batching.
        boolean scopedFeature = AgentPlanRelevance.isSingleFeatureMigrationRequest(task);
        boolean broadScope = List.of("all tests", "all cases", "entire project", "whole project", "full migration", "large migration", "hundreds", "thousands")
                .stream().anyMatch(value::contains) && !scopedFeature;
        boolean migration = MigrationIntent.isMigration(task);
        if (migration && !value.contains("migrat")) signals++; // "upgrade/convert/port/replace X to Y" counts like "migrate"
        boolean migrationScale = (migration || value.contains("refactor")) &&
                (value.contains("framework") || value.contains("module") || value.contains("feature") || value.contains("project") ||
                        value.contains("codebase") || value.contains("all ") || value.contains("across") || value.contains("package"));
        if ((explicitScale >= 25 && !scopedFeature) || broadScope || (migrationScale && signals >= 4 && !scopedFeature)) {
            int batch = explicitScale >= 500 ? 10 : explicitScale >= 100 ? 10 : 8;
            return new TaskProfile("large", 5, 12, true, batch,
                    migration
                            ? "Migration: plan with the migration engine phases — migration_init (spec + inventory + ledger), migration_baseline, optional automatic rewrite recipe, batches in dependency order each followed by migration_verify, fixing failed items, and a final full verification with a report against the baseline."
                            : "Use a hierarchical master plan: inventory scope first, then process independent work items in durable batches. Initialize the work-item ledger before bulk edits, use cheap structural validation at batch boundaries, keep failures in the failed queue, and reserve full runtime/regression verification for the final phase.");
        }
        if (signals >= 4) return new TaskProfile("complex", 4, 10, false, 10, "Use a compact but complete multi-stage plan. Separate materially different implementation/verification concerns; do not create cosmetic steps.");
        if (signals >= 2) return new TaskProfile("normal", 3, 7, false, 10, "Use only the steps needed to inspect, implement and verify the requested scope.");
        return new TaskProfile("focused", 2, 5, false, 10, "Keep the plan short. Do not inflate a focused edit/bug fix into a large process; batch the coherent edit first and reserve compile/test/execution for the final verification step.");
    }

    /**
     * Single-pass Agent planner. The user request defines the scope; heuristics never
     * reject a usable draft or ask the user to debug Eliya's plan validator.
     * Explicit plan previews await an OK; direct Agent requests execute without a plan approval.
     */
    List<String> createExecutionPlan(String apiKey, ChatRequest request,
                                             String task,
                                             AgentWorkspaceService.Workspace ws,
                                             AgentRunService.AgentRun run,
                                             Consumer<Map<String,Object>> onStep) throws Exception {
        // Small, explicitly named Markdown artifacts need generation and verification,
        // not another provider call just to discover an obvious two-step plan.
        // All content generation, protected snapshots and evidence gates remain unchanged.
        List<String> focusedPlan = (request.attachmentIds() == null || request.attachmentIds().isEmpty())
                ? AgentFocusedArtifactPolicy.plan(task) : List.of();
        if (!focusedPlan.isEmpty()) {
            run.configureDocumentationMode(false);
            run.configureLargeTask(false, 10);
            run.setPlanValidation("approved", "Focused artifact plan derived from exact requested filenames; no planner model call.");
            onStep.accept(runtime.stepEvent(0, "planning_fast_path", "Focused Markdown artifacts: direct execution and independent verification; planner call skipped", "success", String.join("\n", focusedPlan)));
            return focusedPlan;
        }
        // Single-file fixes have a deterministic, evidence-first two-step plan.
        // No extra planning model round trip or broad planning-index search is needed.
        List<String> focusedCodePlan = AgentFocusedCodePlanPolicy.plan(task,
                request.attachmentIds() != null && !request.attachmentIds().isEmpty());
        if (!focusedCodePlan.isEmpty()) {
            run.configureDocumentationMode(false);
            run.configureLargeTask(false, 10);
            run.setPlanValidation("approved", "Single-file code fix; deterministic plan without a planner model call.");
            onStep.accept(runtime.stepEvent(0, "planning_fast_path", "Scoped single-file fix: inspect, change and independently verify without redundant planning", "success", String.join("\n", focusedCodePlan)));
            return focusedCodePlan;
        }
        TaskProfile profile = classifyTask(task);
        run.configureDocumentationMode("documentation".equals(profile.level()));
        run.configureLargeTask(profile.largeTask(), profile.batchSize());
        run.updateProgress(9, "indexing", "Collecting relevant workspace evidence");
        String evidence = collectPlanningEvidence(ws, task, apiKey, request.settings(), run);
        String selectedSkillInstructions = SkillSelection.prompt(SkillSelection.select(ws.root(), task), false);
        if (!selectedSkillInstructions.isBlank()) evidence = selectedSkillInstructions + "\n\n" + evidence;
        onStep.accept(runtime.stepEvent(0, "plan_analysis", "Workspace evidence ready; drafting one plan from the user's request", "success", runtime.clipUi(evidence)));

        try {
            run.checkCancelled();
            run.updateProgress(11, "planning", "Creating the initial execution plan");
            List<String> plan = generateExecutionPlan(apiKey, request, run, task, evidence,
                    profile, onStep);
            // Plan specificity was checked in the single-pass planner; no unrelated
            // extra LLM validator or human approval loop is introduced.
            if (plan.isEmpty()) {
                throw new IllegalStateException("The planner did not return an actionable plan. " +
                        "No workspace changes were made. Check the configured planner model response.");
            }
            run.setPlanValidation("approved", "Original-request-driven plan ready; " +
                    "no LLM plan validator or corrective planning retry was run.");
            onStep.accept(runtime.stepEvent(0, "plan_validation", "Initial plan ready; following the user-selected execution behavior", "success", "Plan follows the original user request; runtime will verify real outcomes."));
            return plan;
        } catch (AgentCancelledException cancelled) {
            throw cancelled;
        } catch (AgentService.ProviderModelException providerFailure) {
            throw providerFailure;
        } catch (Exception failure) {
            run.setPlanValidation("rejected", runtime.providerFailureDetail(failure));
            onStep.accept(runtime.stepEvent(0, "plan", "Planner could not return a usable plan", "error", runtime.clipUi(runtime.providerFailureDetail(failure))));
            throw failure;
        }
    }

    /** Plan preview is a one-model-call response, not a second validation or planning stage. */
    record PlanProposal(List<String> steps, String improvedPrompt,
                                List<String> suggestions, String clarification) { }

    PlanProposal createPlanProposal(String apiKey, ChatRequest request,
                                            AgentWorkspaceService.Workspace ws,
                                            AgentRunService.AgentRun run,
                                            Consumer<Map<String,Object>> onStep) throws Exception {
        String task = request.message();
        TaskProfile profile = classifyTask(task);
        run.configureDocumentationMode("documentation".equals(profile.level()));
        run.configureLargeTask(profile.largeTask(), profile.batchSize());
        run.updateProgress(9, "planning", "Preparing a proposed plan from the user requirement");
        String evidence = collectPlanningEvidence(ws, task, apiKey, request.settings(), run);
        String selectedSkillInstructions = SkillSelection.prompt(SkillSelection.select(ws.root(), task), false);
        if (!selectedSkillInstructions.isBlank()) evidence = selectedSkillInstructions + "\n\n" + evidence;
        PlanProposal proposal = generatePlanProposal(apiKey, request, run, task, evidence, profile, onStep, true);
        if (proposal.steps().isEmpty()) throw new IllegalStateException(
                "The planner returned no executable steps. No workspace changes were made.");
        return proposal;
    }

    /** A final clarification (only when essential) is deliberately placed below suggestions. */
    static String formatPlanProposal(PlanProposal proposal, String originalTask) {
        StringBuilder answer = new StringBuilder("## Proposed execution plan\n\n");
        if (!proposal.improvedPrompt().isBlank()) {
            answer.append("**Suggested execution prompt**\n\n> ")
                    .append(proposal.improvedPrompt().replace("\n", "\n> ")).append("\n\n");
        }
        int index = 0;
        for (String step : proposal.steps()) answer.append(++index).append(". ")
                .append(step.replace("\n", " ").strip()).append("\n");
        if (!proposal.suggestions().isEmpty()) {
            answer.append("\n**Optional improvements**\n\n");
            for (String suggestion : proposal.suggestions()) answer.append("- ").append(suggestion).append("\n");
        }
        if (!proposal.clarification().isBlank()) {
            answer.append("\n**One clarification before execution:** ")
                    .append(proposal.clarification()).append("\n");
        } else {
            answer.append("\n**Awaiting explicit approval. No code or migration ledger was changed.** " +
                    "Review the scope above; reply **OK** or **Please continue** to execute ONLY this plan. " +
                    "If the workspace or migration ledger changes before confirmation, Eliya will block stale execution.\n");
        }
        return answer.toString();
    }

    /** Separate read-only analysis role: synthesizes workspace evidence before the planning model sees it. */
    String analysePlanningEvidence(String apiKey, ChatRequest request, AgentRunService.AgentRun run,
                                           String task, String evidence, Consumer<Map<String,Object>> onStep) {
        String model = request.settings().analysisModelOrPrimary();
        run.updateProgress(10, "analysing", "Analysing architecture, constraints and likely change surface");
        try {
            List<Map<String,Object>> prompt = new ArrayList<>();
            prompt.add(Map.of("role", "system", "content", """
                    You are the READ-ONLY analysis stage of a coding-agent harness. Do not propose edits yet and do not call tools.
                    From the supplied repository evidence, identify: the concrete request, relevant architecture/code areas, constraints,
                    likely dependencies, risks, and the smallest verification strategy. Distinguish facts from assumptions. Never invent files,
                    classes, failures or commands not supported by the evidence. Return a concise analysis that a separate planner can use.
                    """));
            prompt.add(Map.of("role", "user", "content", "USER TASK:\n" + task + "\n\nWORKSPACE EVIDENCE:\n" + evidence));
            ContextWindowManager.ContextEstimate estimate = contextWindows.estimate(prompt, List.of(), request.settings(), model);
            run.recordContextEstimate(estimate.estimatedInputTokens(), estimate.contextWindowTokens());
            int maxOut = request.settings().safeMaxTokens() > 0 ? Math.min(2_400, request.settings().safeMaxTokens()) : 2_400;
            onStep.accept(runtime.stepEvent(0, "model_route", "Analysis model: " + model, "success", null));
            OpenAiCompatibleClient.AgentCompletion completion = runtime.completeRoleText(
                    apiKey, request, run, model, ModelCapabilityRegistry.Role.ANALYSIS, maxOut, prompt, 0, onStep, "analysis");
            run.recordModelUsage(completion.usage(), estimate.estimatedInputTokens(), "Analysis", 0);
            String value = completion.content() == null ? "" : completion.content().strip();
            if (!value.isBlank()) {
                onStep.accept(runtime.stepEvent(0, "analysis", "Independent workspace analysis complete", "success", runtime.clipUi(value)));
                return value;
            }
        } catch (AgentCancelledException cancelled) {
            throw cancelled;
        } catch (Exception e) {
            onStep.accept(runtime.stepEvent(0, "analysis", "Analysis model unavailable; planner will use raw workspace evidence", "running", runtime.clipUi(runtime.providerFailureDetail(e))));
        }
        return "";
    }

    List<String> generateExecutionPlan(String apiKey, ChatRequest request, AgentRunService.AgentRun run,
                                                String task, String evidence, TaskProfile taskProfile,
                                                Consumer<Map<String,Object>> onStep) throws Exception {
        return generatePlanProposal(apiKey, request, run, task, evidence, taskProfile, onStep, false).steps();
    }

    /** One planner/refinement model call with context accounting, refusal detection and usage telemetry. */
    OpenAiCompatibleClient.AgentCompletion planningCall(String apiKey, ChatRequest request, AgentRunService.AgentRun run,
                                                                String plannerModel, int maxOut, List<Map<String,Object>> prompt,
                                                                Consumer<Map<String,Object>> onStep, String usageLabel) throws Exception {
        ContextWindowManager.ContextEstimate estimate = contextWindows.estimate(prompt, List.of(), request.settings(), plannerModel);
        run.recordContextEstimate(estimate.estimatedInputTokens(), estimate.contextWindowTokens());
        OpenAiCompatibleClient.AgentCompletion completion = runtime.completeRoleText(
                apiKey, request, run, plannerModel, ModelCapabilityRegistry.Role.PLANNER, maxOut, prompt, 0, onStep, "planning");
        run.recordModelUsage(completion.usage(), estimate.estimatedInputTokens(), usageLabel, 0);
        String response = completion.content() == null ? "" : completion.content().strip();
        if (AgentPlanRecovery.refusal(response, completion.finishReason())) {
            throw new IllegalStateException("The planner declined the request; execution was not started.");
        }
        return completion;
    }

    PlanProposal generatePlanProposal(String apiKey, ChatRequest request, AgentRunService.AgentRun run,
                                               String task, String evidence, TaskProfile taskProfile,
                                               Consumer<Map<String,Object>> onStep, boolean planPreview) throws Exception {
        String analysis = AgentPlanningSettings.analysisStageEnabled(taskProfile.level(), planPreview)
                ? analysePlanningEvidence(apiKey, request, run, task, evidence, onStep) : "";
        List<Map<String,Object>> planning = new ArrayList<>();
        planning.add(Map.of("role", "system", "content", AgentPlanPrompt.system(planPreview)));
        planning.add(Map.of("role", "user", "content",
                AgentPlanPrompt.user(task, evidence, analysis, taskProfile.level(), planPreview)));
        String plannerModel = request.settings().plannerModelOrPrimary();
        // The response cap is an upper bound, not a request to generate more steps.
        // Preserve the user's lower configured cap when one is explicitly set.
        int required = taskProfile.largeTask() ? 6_400 : 4_200;
        int maxOut = request.settings().safeMaxTokens() > 0
                ? Math.min(required, request.settings().safeMaxTokens()) : required;
        onStep.accept(runtime.stepEvent(0, "model_route", "Agent model for planning: " + plannerModel, "success", null));

        OpenAiCompatibleClient.AgentCompletion completion = planningCall(apiKey, request, run, plannerModel, maxOut, planning, onStep, "Planning");
        String response = completion.content() == null ? "" : completion.content().strip();
        AgentPlanParser.Draft draft = AgentPlanParser.judge(response, task, evidence);
        String acceptedResponse = response;
        List<String> parsed = draft.usable() ? draft.steps() : List.of();

        // A generic or malformed first draft gets ONE corrective round that states exactly what was wrong.
        // Previously the runtime jumped straight to a deterministic two-step plan built from the user's own
        // words, which is the main reason Agent plans looked generic.
        if (!draft.problem().isBlank() && AgentPlanningSettings.correctiveRoundEnabled()) {
            run.updateActivity("planning", "Refining a generic plan draft: " + draft.problem());
            onStep.accept(runtime.stepEvent(0, "plan_refine", "Plan draft was not specific enough; asking the planner once more", "running", runtime.clipUi(draft.problem())));
            try {
                OpenAiCompatibleClient.AgentCompletion retry = planningCall(apiKey, request, run, plannerModel, maxOut,
                        AgentPlanPrompt.corrective(planning, response, draft.problem()), onStep, "Planning refinement");
                String retryResponse = retry.content() == null ? "" : retry.content().strip();
                AgentPlanParser.Draft second = AgentPlanParser.judge(retryResponse, task, evidence);
                // Prefer the refined draft whenever it is usable; keep a usable-but-soft first draft otherwise.
                if (second.usable()) {
                    parsed = second.steps();
                    acceptedResponse = retryResponse;
                    completion = retry;
                    draft = second;
                }
            } catch (AgentCancelledException | AgentService.ProviderModelException fatal) {
                throw fatal;
            } catch (Exception refinementFailure) {
                onStep.accept(runtime.stepEvent(0, "plan_refine", "Plan refinement unavailable; continuing with the best draft", "running", runtime.clipUi(runtime.providerFailureDetail(refinementFailure))));
            }
        }
        String envelope = AgentPlanJsonEnvelope.extract(acceptedResponse);
        boolean recovered = false;
        String recoveryReason = draft.problem();
        if (parsed.isEmpty()) {
            // Last resort: both planner rounds failed. The ORIGINAL request stays authoritative.
            parsed = AgentPlanRecovery.fromUserRequest(task, AgentConversationIntent.isFastReadOnly(task));
            recovered = true;
            if (recoveryReason.isBlank()) recoveryReason = "unusable planner response";
        }
        // Anything from the request that no step covers is attached (quoted) to the final step as a checklist,
        // so it is verified instead of silently dropped. No step is invented.
        List<String> withChecklist = AgentRequirementCoverage.attachChecklist(task, parsed);
        if (withChecklist != parsed) {
            parsed = withChecklist;
            onStep.accept(runtime.stepEvent(0, "plan_coverage", "Requirements not mapped to a step were attached to the final step as a checklist",
                    "warning", null));
        }
        if (recovered) {
            run.updateActivity("planning_recovery", "Using the original user request as the execution contract");
            onStep.accept(runtime.stepEvent(0, "planning_recovery", "Planner could not produce a specific plan (" + recoveryReason + "); continuing with a request-derived plan", "warning", null));
        }
        String improved = "";
        String clarification = "";
        List<String> suggestions = List.of();
        if (planPreview) {
            try {
                JsonNode payload = JSON.readTree(envelope);
                if (payload != null && payload.isObject()) {
                    improved = payload.path("improved_prompt").asText("").strip();
                    clarification = payload.path("clarification").asText("").strip();
                    JsonNode suggestionsNode = payload.path("suggestions");
                    if (suggestionsNode.isArray()) {
                        List<String> safeSuggestions = new ArrayList<>();
                        for (JsonNode suggestion : suggestionsNode) {
                            if (suggestion.isTextual() && !suggestion.asText().isBlank())
                                safeSuggestions.add(suggestion.asText().strip());
                            if (safeSuggestions.size() >= 3) break;
                        }
                        suggestions = List.copyOf(safeSuggestions);
                    }
                }
            } catch (Exception ignored) { /* A valid plan remains usable even without optional suggestions. */ }
        }
        onStep.accept(runtime.stepEvent(0, "plan", "Planner produced " + parsed.size() + " executable steps", "success", recovered ? String.join("\n", parsed) : runtime.clipUi(completion.content())));
        return new PlanProposal(parsed, improved, suggestions, clarification);
    }


    /** Read-only deterministic discovery performed before the planner is allowed to draft a plan. */
    String collectPlanningEvidence(AgentWorkspaceService.Workspace ws, String task, String apiKey, ChatSettings settings, AgentRunService.AgentRun run) {
        StringBuilder out = new StringBuilder();
        MigrationResumePreflight.Result resume = MigrationResumePreflight.inspect(ws.root(), task);
        if (resume.applicable()) {
            out.append("## Authoritative migration resume state (read only)\n")
                    .append(resume.report()).append("\n\n");
        }
        appendPlanningEvidence(out, "Workspace profile", () -> workspaces.inspectWorkspace(ws), 3_500);
        appendPlanningEvidence(out, "Resolved prompt resources", () -> workspaces.resourceCatalog(ws), 2_500);
        appendPlanningEvidence(out, "Project instructions", () -> workspaces.projectInstructions(ws), 5_000);

        String files = "";
        try { files = workspaces.listFiles(ws, ""); } catch (Exception ignored) { }
        if (!files.isBlank()) {
            out.append("\n\n## File index\n").append(runtime.clipHeadTail(files, 6_000, "[File index clipped; agent can query it again during execution]"));
            Set<String> paths = new LinkedHashSet<>(Arrays.asList(files.split("\\R")));
            List<String> priority = List.of("AGENTS.md", "CLAUDE.md", "README.md", "pom.xml", "build.gradle", "build.gradle.kts",
                    "package.json", "pyproject.toml", "requirements.txt", "application.properties", "application.yml", "application.yaml");
            int read = 0;
            for (String candidate : priority) {
                String matched = paths.stream().filter(p -> p.equalsIgnoreCase(candidate) || p.toLowerCase(Locale.ROOT).endsWith("/" + candidate.toLowerCase(Locale.ROOT))).findFirst().orElse(null);
                if (matched == null) continue;
                final String path = matched;
                appendPlanningEvidence(out, "Key file: " + path, () -> workspaces.readFileRange(ws, path, 1, 180), 4_500);
                if (++read >= 3) break;
            }
        }

        // Index/embedding backends provide optional hints: transient embedding/model failures
        // must never prevent a plan from using the live workspace tools and lexical evidence.
        // Cancellation remains authoritative and is never swallowed.
        try {
            out.append("\n\n## Read-only task impact / evidence gate\n")
                    .append(boundedPlanningEvidence(() -> workspaceRetrieval.impactReport(ws, task, 3_200), run,
                            "impact analysis", 10));
        } catch (AgentCancelledException cancelled) {
            throw cancelled;
        } catch (Exception unavailable) {
            out.append("\n\n[Optional impact index unavailable; inspect live code during execution]");
        }
        try {
            java.util.concurrent.atomic.AtomicBoolean timeoutCancel = new java.util.concurrent.atomic.AtomicBoolean(false);
            String indexedHints = boundedPlanningEvidence(() -> workspaceRetrieval.retrieveHybrid(ws, task, 7, 6_000,
                    apiKey, settings, () -> timeoutCancel.get() || run.cancelled()), run,
                    "optional semantic retrieval", 12, timeoutCancel);
            if (!indexedHints.isBlank()) {
                out.append("\n\n## Local retrieval index hints\n")
                        .append(runtime.clipHeadTail(indexedHints, 6_000, "[Retrieval hints clipped]"));
            }
        } catch (AgentCancelledException cancelled) {
            throw cancelled;
        } catch (Exception unavailable) {
            out.append("\n\n[Optional hybrid retrieval unavailable; use live workspace tools during execution]");
        }

        // Concrete anchors from the request (paths, identifiers, quoted names) first, then distinctive words.
        int searched = 0;
        for (String term : AgentPlanningTerms.extract(task, AgentPlanningSettings.evidenceSearchTerms())) {
            final String query = term;
            int before = out.length();
            appendPlanningEvidence(out, "Relevant matches for '" + query + "'", () -> workspaces.search(ws, query, 6), 2_400);
            if (out.length() > before && ++searched >= AgentPlanningSettings.evidenceSearchHits()) break;
        }
        return runtime.clipHeadTail(out.toString(), 24_000, "[Planning evidence clipped; live workspace remains authoritative]");
    }

    String boundedPlanningEvidence(EvidenceSupplier work, AgentRunService.AgentRun run,
                                           String description, int timeoutSeconds) throws Exception {
        return boundedPlanningEvidence(work, run, description, timeoutSeconds, new java.util.concurrent.atomic.AtomicBoolean(false));
    }

    String boundedPlanningEvidence(EvidenceSupplier work, AgentRunService.AgentRun run,
                                           String description, int timeoutSeconds,
                                           java.util.concurrent.atomic.AtomicBoolean stopRequested) throws Exception {
        Future<String> future = parallelReadExecutor.submit(work::get);
        long deadline = System.nanoTime() + TimeUnit.SECONDS.toNanos(timeoutSeconds);
        try {
            while (true) {
                run.checkCancelled();
                long remaining = deadline - System.nanoTime();
                if (remaining <= 0) throw new TimeoutException(description + " exceeded " + timeoutSeconds + "s");
                try { return future.get(Math.min(remaining, TimeUnit.SECONDS.toNanos(3)), TimeUnit.NANOSECONDS); }
                catch (TimeoutException waiting) {
                    if (System.nanoTime() >= deadline) throw waiting;
                    run.updateActivity("indexing", "Preparing " + description + " (bounded optional evidence)");
                }
            }
        } finally {
            stopRequested.set(true);
            if (!future.isDone()) future.cancel(true);
        }
    }

    void appendPlanningEvidence(StringBuilder out, String title, EvidenceSupplier supplier, int maxChars) {
        try {
            String value = supplier.get();
            if (value == null || value.isBlank() || value.startsWith("[No ")) return;
            out.append("\n\n## ").append(title).append("\n")
                    .append(runtime.clipHeadTail(value, maxChars, "[Evidence section clipped]"));
        } catch (Exception ignored) { }
    }

    @FunctionalInterface
    interface EvidenceSupplier { String get() throws Exception; }
}
