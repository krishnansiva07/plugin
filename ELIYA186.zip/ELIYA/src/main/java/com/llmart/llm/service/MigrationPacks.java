package com.llmart.llm.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Optional knowledge for common migrations: the old-API patterns to find ("residue"), the files to look in, an
 * automatic-rewrite recipe when one exists, and the usual old→new mapping. The engine works without a pack; a pack
 * only makes discovery sharper and the work faster. Patterns are line-based Java regular expressions.
 */
final class MigrationPacks {

    record Residue(String label, String regex, List<String> extensions) {
        Pattern pattern() { return Pattern.compile(regex); }
    }

    record Pack(String id, String title, Pattern sourceMatch, Pattern targetMatch, List<Residue> residue,
                String recipe, String recipeNote, List<String[]> mapping, String notes) { }

    private static final List<String> JAVA = List.of(".java", ".kt", ".groovy");
    private static final List<String> JVM_BUILD = List.of("pom.xml", ".gradle", ".gradle.kts", ".properties", ".yml", ".yaml");
    private static final List<String> JVM_ALL = concat(JAVA, JVM_BUILD, List.of(".xml", ".jsp", ".tag"));
    private static final List<String> JS = List.of(".js", ".jsx", ".ts", ".tsx", ".mjs", ".cjs", ".vue", ".svelte", "package.json");
    private static final String JAVAX_EE = "\\bjavax\\.(?:servlet|persistence|validation|annotation\\.(?:PostConstruct|PreDestroy|Resource|Generated|Priority|security)|" +
            "transaction|ws\\.rs|inject|xml\\.bind|mail|faces|ejb|jms|websocket|json|el|batch|enterprise|interceptor|decorator|security\\.enterprise)\\b";
    private static final String REWRITE = "mvn -U org.openrewrite.maven:rewrite-maven-plugin:run -Drewrite.recipeArtifactCoordinates=%s -Drewrite.activeRecipes=%s";
    private static final String REWRITE_NOTE = "OpenRewrite (Maven; needs access to Maven Central or your mirror). For Gradle use the " +
            "org.openrewrite.rewrite plugin with the same recipe. Review the diff, then let Eliya finish what the recipe did not cover.";

    static final List<Pack> ALL = List.of(
            new Pack("javax-to-jakarta", "Java EE javax.* → Jakarta EE jakarta.*",
                    Pattern.compile("(?i)javax|java\\s*ee|j2ee"), Pattern.compile("(?i)jakarta"),
                    List.of(new Residue("javax EE package", JAVAX_EE, JVM_ALL)),
                    REWRITE.formatted("org.openrewrite.recipe:rewrite-migrate-java:RELEASE", "org.openrewrite.java.migrate.jakarta.JavaxMigrationToJakarta"),
                    REWRITE_NOTE,
                    List.of(new String[]{"javax.servlet.*", "jakarta.servlet.*"}, new String[]{"javax.persistence.*", "jakarta.persistence.*"},
                            new String[]{"javax.validation.*", "jakarta.validation.*"}, new String[]{"javax.annotation.PostConstruct/PreDestroy", "jakarta.annotation.*"},
                            new String[]{"javax.transaction.*", "jakarta.transaction.*"}, new String[]{"javax.ws.rs.*", "jakarta.ws.rs.*"},
                            new String[]{"javax.inject.*", "jakarta.inject.*"}, new String[]{"javax.xml.bind.*", "jakarta.xml.bind.*"},
                            new String[]{"javax:javaee-api / javax.servlet-api dependencies", "jakarta.* API dependencies (e.g. jakarta.servlet-api 6)"}),
                    "javax.sql, javax.crypto, javax.net, javax.naming, javax.management and javax.swing are part of the JDK and stay unchanged."),
            new Pack("spring-boot-3", "Spring Boot 2.x → 3.x",
                    Pattern.compile("(?i)spring\\s*boot\\s*2|boot\\s*2|spring\\s*boot$|^spring$"), Pattern.compile("(?i)spring\\s*boot\\s*3|boot\\s*3"),
                    List.of(new Residue("javax EE package", JAVAX_EE, JVM_ALL),
                            new Residue("removed Spring Security adapter", "\\bWebSecurityConfigurerAdapter\\b|\\.antMatchers\\(|\\.mvcMatchers\\(|\\.authorizeRequests\\(", JAVA),
                            new Residue("Boot 2 Gradle plugin", "org\\.springframework\\.boot['\"]?\\)?\\s*version\\s*['\"]2\\.", List.of(".gradle", ".gradle.kts")),
                            new Residue("renamed property", "^\\s*spring\\.(?:redis\\.|data\\.cassandra\\.(?!.*\\.)|mvc\\.throw-exception-if-no-handler-found)", List.of(".properties", ".yml", ".yaml"))),
                    REWRITE.formatted("org.openrewrite.recipe:rewrite-spring:RELEASE", "org.openrewrite.java.spring.boot3.UpgradeSpringBoot_3_0"),
                    REWRITE_NOTE + " Spring Boot 3 needs Java 17+.",
                    List.of(new String[]{"spring-boot-starter-parent 2.x", "3.x (Java 17+)"}, new String[]{"javax.* (Java EE)", "jakarta.*"},
                            new String[]{"WebSecurityConfigurerAdapter", "SecurityFilterChain @Bean"}, new String[]{"antMatchers/mvcMatchers", "requestMatchers"},
                            new String[]{"authorizeRequests()", "authorizeHttpRequests()"}, new String[]{"spring.redis.*", "spring.data.redis.*"}),
                    "Check third-party libraries for Jakarta-compatible versions; trailing-slash URL matching is off by default in Boot 3."),
            new Pack("java-version", "Java version upgrade",
                    Pattern.compile("(?i)java|jdk|^$"), Pattern.compile("(?i)^(?:java|jdk|openjdk)\\s*(?:1[1-9]|2\\d)\\b"),
                    List.of(new Residue("old Java level in build", "<java\\.version>1\\.[5-8]</java\\.version>|<maven\\.compiler\\.(?:source|target|release)>(?:1\\.)?[5-9]<|" +
                                    "<(?:source|target|release)>(?:1\\.)?[5-9]</|sourceCompatibility\\s*=\\s*['\"]?(?:JavaVersion\\.VERSION_)?1[._][5-8]|jvmTarget\\s*=\\s*['\"]1\\.8", JVM_BUILD),
                            new Residue("removed/internal JDK API", "\\bsun\\.misc\\.(?:BASE64Encoder|BASE64Decoder|Unsafe)\\b|\\bjavax\\.xml\\.bind\\b|\\bjavax\\.activation\\b|\\bjavax\\.annotation\\.Generated\\b", JAVA),
                            new Residue("deprecated boxing constructor", "\\bnew\\s+(?:Integer|Long|Short|Byte|Double|Float|Boolean|Character)\\s*\\(", JAVA)),
                    REWRITE.formatted("org.openrewrite.recipe:rewrite-migrate-java:RELEASE", "org.openrewrite.java.migrate.UpgradeToJava17"),
                    REWRITE_NOTE + " Use UpgradeToJava21 for Java 21.",
                    List.of(new String[]{"<java.version>1.8</java.version>", "<java.version>17</java.version> (or 21)"},
                            new String[]{"sun.misc.BASE64Encoder/Decoder", "java.util.Base64"}, new String[]{"javax.xml.bind (JAXB)", "jakarta.xml.bind + implementation dependency"},
                            new String[]{"new Integer(x)", "Integer.valueOf(x)"}),
                    "Update build plugins (maven-compiler-plugin 3.11+, surefire 3.x) and libraries that use internal JDK APIs (Lombok, Mockito, ByteBuddy)."),
            new Pack("junit4-to-junit5", "JUnit 4 → JUnit 5 (Jupiter)",
                    Pattern.compile("(?i)junit\\s*4|junit$"), Pattern.compile("(?i)junit\\s*5|jupiter"),
                    List.of(new Residue("JUnit 4 import", "^\\s*import\\s+(?:static\\s+)?org\\.junit\\.(?!jupiter|platform)", JAVA),
                            new Residue("JUnit 4 runner/rule", "@RunWith\\s*\\(|@Rule\\b|@ClassRule\\b|@Test\\s*\\(\\s*expected", JAVA),
                            new Residue("JUnit 4 dependency", "<artifactId>junit</artifactId>|['\"]junit:junit:", List.of("pom.xml", ".gradle", ".gradle.kts"))),
                    REWRITE.formatted("org.openrewrite.recipe:rewrite-testing-frameworks:RELEASE", "org.openrewrite.java.testing.junit5.JUnit4to5Migration"),
                    REWRITE_NOTE,
                    List.of(new String[]{"org.junit.Test", "org.junit.jupiter.api.Test"}, new String[]{"@Before/@After", "@BeforeEach/@AfterEach"},
                            new String[]{"@BeforeClass/@AfterClass", "@BeforeAll/@AfterAll"}, new String[]{"@Ignore", "@Disabled"},
                            new String[]{"org.junit.Assert.*", "org.junit.jupiter.api.Assertions.* (message is the LAST argument)"},
                            new String[]{"@Test(expected = X.class)", "assertThrows(X.class, () -> ...)"}, new String[]{"@RunWith(MockitoJUnitRunner.class)", "@ExtendWith(MockitoExtension.class)"},
                            new String[]{"junit:junit dependency", "org.junit.jupiter:junit-jupiter (+ surefire 2.22+/3.x)"}),
                    "Keep the vintage engine only if some tests must stay on JUnit 4 temporarily."),
            new Pack("selenium-to-playwright", "Selenium WebDriver → Playwright",
                    Pattern.compile("(?i)selenium|webdriver"), Pattern.compile("(?i)playwright"),
                    List.of(new Residue("Selenium API", "\\borg\\.openqa\\.selenium\\b|\\bfrom\\s+selenium\\b|require\\(['\"]selenium-webdriver|from\\s+['\"]selenium-webdriver", concat(JAVA, JS, List.of(".py", ".cs"))),
                            new Residue("WebDriver usage", "\\bWebDriver(?:Wait)?\\b|\\bdriver\\.find(?:Element|Elements)\\(|\\bBy\\.(?:id|xpath|cssSelector|name|className|linkText|tagName)\\(", concat(JAVA, JS, List.of(".py", ".cs")))),
                    "", "", List.of(new String[]{"driver.findElement(By.id(\"x\"))", "page.locator(\"#x\") / page.getByTestId(\"x\")"},
                            new String[]{"WebDriverWait + ExpectedConditions", "auto-waiting locators / expect(locator).toBeVisible()"},
                            new String[]{"driver.get(url)", "page.navigate(url) / page.goto(url)"}, new String[]{"element.sendKeys(text)", "locator.fill(text)"},
                            new String[]{"Thread.sleep", "remove; rely on auto-waiting or expect(...)"}),
                    "Prefer role/label/test-id locators; verify each migrated test with the Playwright runner."),
            new Pack("python2-to-python3", "Python 2 → Python 3",
                    Pattern.compile("(?i)python\\s*2|py2"), Pattern.compile("(?i)python\\s*3|py3"),
                    List.of(new Residue("print statement", "^\\s*print\\s+(?![(=])\\S", List.of(".py")),
                            new Residue("Python 2 builtin", "\\.(?:iteritems|itervalues|iterkeys|has_key)\\(|\\bxrange\\(|\\bunicode\\(|\\braw_input\\(|\\bbasestring\\b|\\blong\\(|\\bexecfile\\(", List.of(".py")),
                            new Residue("Python 2 syntax", "except\\s+[\\w.]+\\s*,\\s*\\w+\\s*:|^\\s*exec\\s+[\"'\\w]", List.of(".py")),
                            new Residue("renamed module", "^\\s*(?:import|from)\\s+(?:urllib2|urlparse|ConfigParser|Queue|StringIO|cStringIO|cPickle|HTMLParser|httplib|Tkinter|__builtin__)\\b", List.of(".py"))),
                    "", "", List.of(new String[]{"print x", "print(x)"}, new String[]{"d.iteritems()", "d.items()"}, new String[]{"xrange", "range"},
                            new String[]{"unicode / basestring", "str"}, new String[]{"raw_input", "input"}, new String[]{"except E, e:", "except E as e:"},
                            new String[]{"urllib2 / urlparse", "urllib.request / urllib.parse"}, new String[]{"ConfigParser / Queue / StringIO", "configparser / queue / io"},
                            new String[]{"integer division a / b", "a // b where integer division was intended"}),
                    "Check bytes/str handling at I/O boundaries and dict ordering assumptions."),
            new Pack("log4j1-to-log4j2", "Log4j 1.x → Log4j 2",
                    Pattern.compile("(?i)log4j\\s*1|log4j$"), Pattern.compile("(?i)log4j\\s*2|slf4j|logback"),
                    List.of(new Residue("Log4j 1 API", "\\borg\\.apache\\.log4j\\.", JAVA),
                            new Residue("Log4j 1 dependency/config", "<artifactId>log4j</artifactId>|['\"]log4j:log4j:|^\\s*log4j\\.(?:rootLogger|appender)", concat(JVM_BUILD, List.of(".properties")))),
                    "", "", List.of(new String[]{"org.apache.log4j.Logger", "org.apache.logging.log4j.LogManager.getLogger"},
                            new String[]{"log4j.properties", "log4j2.xml / log4j2.properties"}), ""),
            new Pack("jest-to-vitest", "Jest → Vitest",
                    Pattern.compile("(?i)jest"), Pattern.compile("(?i)vitest"),
                    List.of(new Residue("Jest API", "\\bjest\\.(?:fn|mock|spyOn|useFakeTimers|useRealTimers|clearAllMocks|resetAllMocks|requireActual)\\(|from\\s+['\"]@jest/globals['\"]", JS),
                            new Residue("Jest dependency/config", "\"jest\"\\s*:|\"ts-jest\"|\"babel-jest\"", List.of("package.json"))),
                    "", "", List.of(new String[]{"jest.fn / jest.mock / jest.spyOn", "vi.fn / vi.mock / vi.spyOn"},
                            new String[]{"jest.requireActual", "await vi.importActual"}, new String[]{"jest config", "vitest.config (test.globals, environment)"}), ""),
            new Pack("moment-to-dayjs", "moment → Day.js",
                    Pattern.compile("(?i)^moment(?:\\.js|js)?$"), Pattern.compile("(?i)day\\.?js"),
                    List.of(new Residue("moment import", "from\\s+['\"]moment['\"]|require\\(['\"]moment['\"]\\)|\"moment\"\\s*:", JS)),
                    "", "", List.of(new String[]{"moment()", "dayjs()"}, new String[]{"moment(x).format(f)", "dayjs(x).format(f)"},
                            new String[]{"plugins (duration, relativeTime, utc …)", "dayjs.extend(plugin)"}), ""));

    private MigrationPacks() { }

    static Optional<Pack> byId(String id) {
        if (id == null || id.isBlank()) return Optional.empty();
        return ALL.stream().filter(p -> p.id().equalsIgnoreCase(id.strip())).findFirst();
    }

    /** Best pack for this source/target; Spring Boot 3 wins over plain javax→jakarta, specific packs over Java version. */
    static Optional<Pack> match(String source, String target) {
        String s = source == null ? "" : source.strip(), t = target == null ? "" : target.strip();
        for (Pack pack : ALL) {
            if (pack.targetMatch().matcher(t).find() && (s.isBlank() || pack.sourceMatch().matcher(s).find())) return Optional.of(pack);
        }
        return Optional.empty();
    }

    /**
     * Residue for a migration without a pack: usages of the source technology's name in imports/requires/includes and
     * dependency declarations. Rough on purpose; the Agent can add precise patterns when it initialises the migration.
     */
    static List<Residue> generic(String source) {
        List<Residue> out = new ArrayList<>();
        for (String term : MigrationIntent.keyTerms(source)) {
            if (term.length() < 3 || term.matches("\\d.*")) continue;
            String q = Pattern.quote(term);
            out.add(new Residue("import of " + term,
                    "(?i)^\\s*(?:import|from|using|#include|require|use)\\b[^\\n]*\\b" + q + "\\b|require\\(\\s*['\"][^'\"]*\\b" + q + "\\b[^'\"]*['\"]\\s*\\)|" +
                            "from\\s+['\"][^'\"]*\\b" + q + "\\b[^'\"]*['\"]", List.of()));
            out.add(new Residue("dependency on " + term,
                    "(?i)\"[^\"]*\\b" + q + "\\b[^\"]*\"\\s*:\\s*\"|<artifactId>[^<]*\\b" + q + "\\b[^<]*</artifactId>|['\"][\\w.-]*:" + q + "[\\w.-]*:|^\\s*" + q + "\\b[\\w.-]*\\s*(?:[=<>~!]=|$)",
                    List.of("package.json", "pom.xml", ".gradle", ".gradle.kts", "requirements.txt", "pyproject.toml", ".csproj", "go.mod", "Gemfile")));
        }
        return out;
    }

    /** Recipe command adjusted for the target (UpgradeToJava21 for Java 21). */
    static String recipeFor(Pack pack, String target) {
        if (pack == null || pack.recipe().isBlank()) return "";
        if (pack.id().equals("java-version")) {
            Matcher m = Pattern.compile("(\\d+)").matcher(target == null ? "" : target);
            if (m.find() && Integer.parseInt(m.group(1)) >= 21) return pack.recipe().replace("UpgradeToJava17", "UpgradeToJava21");
        }
        return pack.recipe();
    }

    private static List<String> concat(List<String> a, List<String> b) { List<String> out = new ArrayList<>(a); out.addAll(b); return List.copyOf(out); }

    private static List<String> concat(List<String> a, List<String> b, List<String> c) { return concat(concat(a, b), c); }

    static boolean appliesTo(Residue residue, String fileName) {
        if (residue.extensions().isEmpty()) return true;
        String name = fileName.toLowerCase(Locale.ROOT);
        for (String ext : residue.extensions()) if (name.endsWith(ext.toLowerCase(Locale.ROOT))) return true;
        return false;
    }
}
