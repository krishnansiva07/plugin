package com.llmart.llm.cli.tui;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.llmart.llm.cli.EliyaCliBridge;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/** {@link TuiBackend} over the token-protected local CLI bridge (same pipeline as the browser). */
public final class HttpTuiBackend implements TuiBackend {
    private static final ObjectMapper JSON = new ObjectMapper();
    private final HttpClient client;
    private final URI base;
    private final String token;
    private final String sessionId;
    private volatile String workspace;

    public HttpTuiBackend(HttpClient client, URI base, String token, String sessionId, String workspace) {
        this.client = client; this.base = base; this.token = token; this.sessionId = sessionId;
        this.workspace = workspace == null ? "" : workspace;
    }

    private String sessionQuery() { return "?sessionId=" + URLEncoder.encode(sessionId, StandardCharsets.UTF_8); }

    private HttpRequest.Builder builder(String endpoint, Duration timeout) {
        HttpRequest.Builder builder = HttpRequest.newBuilder(base.resolve(endpoint))
                .header("X-Eliya-CLI-Token", token).header("X-Eliya-Session", sessionId);
        if (timeout != null) builder.timeout(timeout);
        return builder;
    }

    private JsonNode call(String method, String endpoint, Object payload, Duration timeout) throws Exception {
        HttpRequest.Builder builder = builder(endpoint, timeout);
        if ("POST".equals(method)) builder.header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(JSON.writeValueAsString(payload == null ? Map.of() : payload)));
        else builder.GET();
        HttpResponse<String> response = client.send(builder.build(), HttpResponse.BodyHandlers.ofString());
        if (response.statusCode() >= 400) throw new IllegalStateException(errorText(response.statusCode(), response.body()));
        String body = response.body();
        return body == null || body.isBlank() ? JSON.createObjectNode() : JSON.readTree(body);
    }

    static String errorText(int status, String body) {
        String detail = body == null ? "" : body;
        String code = "";
        try {
            JsonNode parsed = JSON.readTree(detail);
            code = parsed.path("code").asText("");
            detail = parsed.path("detail").asText(parsed.path("message").asText(parsed.path("error").asText(detail)));
        } catch (Exception ignored) { }
        if (detail.isBlank()) detail = "no details";
        // ELIYA184: the server now sends a code and a full explanation; show it as the user's next step.
        switch (code) {
            case "WORKSPACE_BUSY": return "Workspace busy — " + detail;
            case "MODEL_NOT_CONFIGURED": return detail;
            case "NO_ANALYSIS": case "NO_WORKSPACE": case "EMPTY_PROMPT": return detail;
            default: break;
        }
        return switch (status) {
            case 401, 403 -> "Eliya rejected this terminal (HTTP " + status + "). Restart `eliya`. " + detail;
            case 409 -> "Conflict (HTTP 409): " + detail +
                    ("no details".equals(detail) ? " — another Agent task may still be running in this workspace; type /stop to stop it." : "");
            case 428 -> detail;
            case 429 -> "Provider rate limit reached (HTTP 429). Wait and retry. " + detail;
            default -> "HTTP " + status + ": " + detail;
        };
    }

    @Override
    public void run(String mode, String prompt, Listener listener) throws Exception {
        HttpRequest request = builder("/api/cli/run", null)
                .header("Content-Type", "application/json").header("Accept", "text/event-stream")
                .POST(HttpRequest.BodyPublishers.ofString(JSON.writeValueAsString(
                        new EliyaCliBridge.TerminalPrompt(mode, prompt, workspace, sessionId)))).build();
        HttpResponse<InputStream> response = client.send(request, HttpResponse.BodyHandlers.ofInputStream());
        if (response.statusCode() >= 400) {
            try (InputStream body = response.body()) {
                throw new IllegalStateException(errorText(response.statusCode(),
                        new String(body.readAllBytes(), StandardCharsets.UTF_8)));
            }
        }
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(response.body(), StandardCharsets.UTF_8))) {
            readEvents(reader, listener);
        }
    }

    /** Parse an SSE stream and dispatch events (package-visible for tests). */
    static void readEvents(BufferedReader reader, Listener listener) throws Exception {
        String event = "message";
        StringBuilder data = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            if (line.startsWith("event:")) { event = line.substring(6).strip(); continue; }
            if (line.startsWith("data:")) { if (data.length() > 0) data.append('\n'); data.append(line.substring(5).stripLeading()); continue; }
            if (!line.isEmpty() || data.length() == 0) continue;
            dispatch(event, data.toString(), listener);
            event = "message";
            data.setLength(0);
        }
        if (data.length() > 0) dispatch(event, data.toString(), listener);
    }

    private static void dispatch(String event, String raw, Listener listener) {
        JsonNode item;
        try { item = JSON.readTree(raw); } catch (Exception notJson) { item = JSON.getNodeFactory().textNode(raw); }
        switch (event) {
            case "token" -> { String text = item.path("text").asText(""); if (!text.isEmpty()) listener.token(text); }
            case "meta" -> { if (item.hasNonNull("agentRunId")) listener.runId(item.path("agentRunId").asText()); }
            case "agent_step" -> {
                String detail = item.path("detail").asText(item.path("message").asText(""));
                if (detail.isBlank()) detail = item.path("type").asText("");
                listener.step(item.path("tool").asText("Agent"), item.path("status").asText("running"), detail,
                        item.path("step").asText(""), item.path("approvalId").asText(""), item.path("approvalType").asText(""));
            }
            case "agent_question" -> {
                List<String> choices = new ArrayList<>();
                item.path("choices").forEach(choice -> choices.add(choice.asText()));
                listener.question(item.path("id").asText(""), item.path("reason").asText("The Agent needs your input"), choices);
            }
            case "agent_changes" -> listener.changes(item.path("count").asText(""));
            case "chat_status" -> listener.status(item.path("phase").asText("running"), item.path("detail").asText(""));
            case "error" -> listener.error(item.path("message").asText(item.isTextual() ? item.asText() : "Execution failed"));
            case "stopped" -> listener.stopped(item.path("message").asText("Run stopped"));
            case "done" -> listener.done(item.path("content").asText(""));
            default -> { }
        }
    }

    @Override
    public void approve(String runId, String approvalId, String decision) throws Exception {
        call("POST", "/api/cli/session/approval" + sessionQuery(),
                new EliyaCliBridge.ApprovalDecision(runId, approvalId, decision), Duration.ofSeconds(8));
    }

    @Override
    public void answer(String runId, String questionId, String choice, String detail) throws Exception {
        call("POST", "/api/cli/session/question" + sessionQuery(),
                new EliyaCliBridge.QuestionAnswer(runId, questionId, choice, detail), Duration.ofSeconds(8));
    }

    @Override
    public boolean cancel() throws Exception {
        return call("POST", "/api/cli/session/cancel" + sessionQuery(), Map.of(), Duration.ofSeconds(8))
                .path("cancellationRequested").asBoolean();
    }

    @Override
    public String addInput(String runId, String text) throws Exception {
        return submitInput(runId, text).id();
    }

    @Override
    public InputResult submitInput(String runId, String text) throws Exception {
        JsonNode reply = call("POST", "/api/cli/session/input" + sessionQuery(),
                new EliyaCliBridge.RunInput(runId, text), Duration.ofSeconds(8));
        return new InputResult(reply.path("id").asText(""), reply.path("status").asText("pending"),
                reply.path("kind").asText("refine"), reply.path("reply").asText(""));
    }

    @Override
    public ActiveRun activeRun() {
        try {
            JsonNode reply = call("GET", "/api/cli/session/active" + sessionQuery(), null, Duration.ofSeconds(5));
            if (!reply.path("active").asBoolean(false)) return null;
            return new ActiveRun(reply.path("runId").asText(""), reply.path("status").asText(""),
                    reply.path("activity").asText(""), reply.path("task").asText(""), reply.path("terminalOpen").asBoolean(false));
        } catch (Exception olderServerOrUnavailable) {
            return null;
        }
    }

    @Override
    public List<SkillInfo> skills() throws Exception {
        JsonNode reply = call("GET", "/api/cli/skills" + sessionQuery(), null, Duration.ofSeconds(8));
        List<SkillInfo> out = new ArrayList<>();
        reply.path("skills").forEach(skill -> {
            List<String> aliases = new ArrayList<>();
            skill.path("aliases").forEach(alias -> aliases.add(alias.asText()));
            out.add(new SkillInfo(skill.path("name").asText(""), skill.path("description").asText(""),
                    List.copyOf(aliases), skill.path("source").asText("")));
        });
        return out;
    }

    @Override
    public String memory(String query) throws Exception {
        String q = query == null || query.isBlank() ? "" : "&query=" + URLEncoder.encode(query, StandardCharsets.UTF_8);
        return call("GET", "/api/cli/memory" + sessionQuery() + q, null, Duration.ofSeconds(8)).path("text").asText("");
    }

    @Override
    public int clearMemory() throws Exception {
        return call("POST", "/api/cli/memory/clear" + sessionQuery(), Map.of(), Duration.ofSeconds(8)).path("cleared").asInt(0);
    }

    @Override
    public String mode(String mode) throws Exception {
        JsonNode chosen = call("POST", "/api/cli/mode", new EliyaCliBridge.ModeRequest(mode, workspace, sessionId),
                Duration.ofSeconds(15));
        String selected = chosen.path("project").path("localPath").asText("");
        if (!selected.isBlank()) workspace = selected;
        return workspace;
    }

    @Override
    public String activate(String folder, boolean fresh) throws Exception {
        JsonNode reply = call("POST", "/api/cli/activate",
                new EliyaCliBridge.ActivationRequest(folder, sessionId, fresh), Duration.ofSeconds(30));
        String selected = reply.path("selection").path("project").path("localPath").asText("");
        if (!selected.isBlank()) workspace = selected;
        return workspace;
    }

    @Override
    public Status status() throws Exception {
        JsonNode result = call("GET", "/api/cli/status", null, Duration.ofSeconds(5));
        JsonNode selection = result.path("selection");
        String selected = selection.path("project").path("localPath").asText("");
        if (!selected.isBlank()) workspace = selected;
        return new Status(workspace, selection.path("mode").asText("analyse"), result.path("modelConfigured").asBoolean(),
                result.path("model").asText(""), result.path("chatModel").asText(""),
                result.path("configurationHint").asText(""), result.path("url").asText(base.toString()), sessionId);
    }

    @Override
    public RunResult latestResult() throws Exception {
        JsonNode result = call("GET", "/api/cli/session/result" + sessionQuery(), null, Duration.ofSeconds(8));
        return new RunResult(result.path("status").asText("unknown"), result.path("lastVerification").asText(""),
                result.path("id").asText(""));
    }

    @Override
    public void refresh() {
        try { call("POST", "/api/cli/refresh", Map.of(), Duration.ofSeconds(5)); }
        catch (Exception ignored) { /* browser refresh is best effort */ }
    }
}
