package com.llmart.llm.service;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Enforced workflow for requests that ask the Agent to run or fix tests. The runtime, not the model, guarantees:
 * <ol>
 *   <li><b>Preflight:</b> test discovery (build tool, runner, suites, config) runs before the first test execution.</li>
 *   <li><b>Targeted execution:</b> after a failure the runtime extracts the failing tests and proposes the exact
 *       targeted re-run command for the detected runner.</li>
 *   <li><b>Diagnosis:</b> failing tests and first error lines are fed back with required next actions.</li>
 *   <li><b>No shortcuts:</b> skipping/disabling tests ({@code -DskipTests}, {@code @Disabled}, {@code .skip(}, …) is
 *       blocked unless the user asked for it.</li>
 *   <li><b>Re-verification:</b> the run cannot finish while the latest test run failed, no test ran, or files changed
 *       after the last passing run.</li>
 * </ol>
 */
final class AgentTestWorkflow {
    private static final Pattern REQUEST = Pattern.compile(
            "(?i)\\b(?:run|execute|rerun|perform|launch|start)\\b.{0,75}\\b(?:tests?|testcases?|test.cases?|scenarios?|specs?|suites?)\\b|" +
            "\\b(?:fix|repair|resolve|debug|make)\\b.{0,50}\\b(?:failing|failed|broken|red|flaky)\\b.{0,40}(?:\\b(?:tests?|specs?|scenarios?|builds?|suites?)\\b|\\w+(?:Test|Tests|Spec|IT)\\b)|" +
            "\\b(?:tests?|specs?|suites?)\\b.{0,30}\\b(?:are|is)\\s+(?:failing|broken|red)\\b");
    private static final Pattern RUNNER_COMMAND = Pattern.compile(
            "(?i)(?:\\b(?:mvn|mvnw|gradle|gradlew)(?:\\.cmd|\\.bat)?\\b[^\\n]{0,160}\\b(?:test|verify|check|integrationTest)\\b|" +
            "\\b(?:npm|pnpm|yarn|bun)\\s+(?:run\\s+)?(?:test|e2e|spec)(?:\\b|:)|\\b(?:npx|pnpm\\s+exec|yarn)\\s+(?:playwright|jest|vitest|cypress)\\b|" +
            "\\b(?:pytest|jest|vitest|cucumber-js|playwright\\s+test)\\b|\\bnode\\s+--test\\b|\\b(?:go\\s+test|dotnet\\s+test|cargo\\s+test)\\b)");
    private static final Pattern SKIP_COMMAND = Pattern.compile(
            "(?i)(?:-DskipTests\\b|-Dmaven\\.test\\.skip|-Dmaven\\.test\\.failure\\.ignore|-DtestFailureIgnore|\\s-x\\s+test\\b|--passWithNoTests|" +
            "--exclude-task\\s+test\\b|testFailureIgnore\\s*=\\s*true)");
    private static final Pattern SKIP_EDIT = Pattern.compile(
            "(?:@Disabled\\b|@Ignore\\b|@pytest\\.mark\\.skip|@unittest\\.skip|\\b(?:it|test|describe)\\.skip\\(|\\bx(?:it|describe|test)\\(|" +
            "\\btest\\.fixme\\(|enabled\\s*=\\s*false|\\bt\\.Skip\\(|<skip>true</skip>|<testFailureIgnore>true</testFailureIgnore>)");
    private static final Pattern USER_ALLOWS_SKIP = Pattern.compile(
            "(?i)\\b(?:skip|disable|ignore|quarantine|exclude)\\b.{0,40}\\b(?:tests?|specs?|scenarios?)\\b");
    // Failing test identifiers across common runners.
    private static final List<Pattern> FAILING = List.of(
            Pattern.compile("(?m)^\\[ERROR\\]\\s+((?:[\\w$]+\\.)*[A-Z][\\w$]*)[.#]([a-zA-Z_$][\\w$]*)(?::\\d+)?"),  // Surefire summary
            Pattern.compile("(?m)^(?:ERROR|FAIL):\\s+(?=\\w+\\s+\\(([\\w.]+?)(?:\\.\\w+)?\\))(\\w+)"),                      // Python unittest (class, test)
            Pattern.compile("(?m)^\\[ERROR\\]\\s+([\\w.$]+)\\.([\\w$]+)\\s+(?:Time elapsed|<<<)"),             // Surefire per test
            Pattern.compile("(?m)\\bFAILED:\\s+([\\w.$]+)\\.?([\\w$]*)"),                                      // TestNG
            Pattern.compile("(?m)^FAILED\\s+([\\w/.-]+\\.py)::([\\w\\[\\]-]+)"),                                // pytest
            Pattern.compile("(?m)(?:✘|✗|×)\\s+\\d*\\s*(?:\\[[^\\]]+\\]\\s*›\\s*)?([\\w/.-]+\\.(?:spec|test)\\.[jt]sx?):\\d+:\\d+\\s*›\\s*(.+)$"), // Playwright
            Pattern.compile("(?m)^\\s+\\d+\\)\\s+(?:\\[[^\\]]+\\]\\s*›\\s*)?([\\w/.-]+\\.(?:spec|test)\\.[jt]sx?):\\d+:\\d+\\s*›\\s*(.+?)\\s*─*\\s*$"), // Playwright line/list/dot reporter
            Pattern.compile("(?m)^\\s*●\\s+(.+?)\\s+›\\s+(.+)$"),                                             // Jest
            Pattern.compile("(?m)^(\\w[\\w.]*Test)\\s*>\\s*(\\w+)\\(?\\)?\\s+FAILED"),                          // Gradle
            Pattern.compile("(?m)^--- FAIL:\\s+(\\S+)()"));                                                    // go test
    private static final Pattern ERROR_LINE = Pattern.compile(
            "(?i)(?:assertion(?:error| failed)|expected[:\\s]|but was|caused by:|exception:|error:|\\bat [\\w.$]+\\([\\w]+\\.java:\\d+\\))");

    enum Runner { MAVEN, GRADLE, PLAYWRIGHT, JEST, PYTEST, NPM, OTHER }

    private final boolean userAllowsSkip;
    private boolean preflightDone;
    private int runs;
    private String lastState = "NONE";               // NONE, PASSED, FAILED
    private long lastPassingRevision = -1;
    private Runner lastRunner = Runner.OTHER;
    private final Set<String> failingTests = new LinkedHashSet<>();
    private int gateReentries;
    private boolean browserMcp;

    /** Typical browser-test failures where looking at the live page helps. */
    private static final Pattern UI_FAILURE = Pattern.compile(
            "(?i)(?:locator\\.|getBy(?:Role|Text|Label|TestId)|waiting for (?:locator|selector)|toBeVisible|toHaveText|" +
            "strict mode violation|element(?:s)? (?:is|are) not (?:visible|attached)|TimeoutError)");

    private AgentTestWorkflow(boolean userAllowsSkip) {
        this.userAllowsSkip = userAllowsSkip;
    }

    /** Null when the request is not about running/fixing tests. */
    static AgentTestWorkflow forObjective(String objective) {
        if (objective == null || !REQUEST.matcher(objective).find()) return null;
        return new AgentTestWorkflow(USER_ALLOWS_SKIP.matcher(objective).find());
    }

    static boolean isRunner(String tool, String command) {
        String t = tool == null ? "" : tool.toLowerCase(Locale.ROOT);
        if (t.equals("test") || t.equals("resource_test")) return true;
        return (t.equals("bash") || t.equals("resource_bash") || t.equals("process_start")) &&
                command != null && RUNNER_COMMAND.matcher(command).find();
    }

    boolean preflightDone() { return preflightDone; }

    /** Browser MCP tools (Playwright/Chrome DevTools) are available for diagnosing failures in this run. */
    void enableBrowserMcp() { browserMcp = true; }

    boolean browserMcp() { return browserMcp; }

    /** ELIYA178: how to use Playwright MCP to fix failing UI tests — evidence first, real test run last. */
    static String browserMcpProtocol() {
        return """
                [PLAYWRIGHT MCP TEST-FIX WORKFLOW]
                Browser MCP tools (browser_navigate, browser_snapshot, browser_click, browser_type, browser_console_messages,
                browser_network_requests, …) are loaded. They act only on the browser and are allowed while file protection is on.
                1. Run the real tests first with the project's runner (for Playwright: `npx playwright test`, add `--reporter=line`
                   for compact output). Note each failing test, the failing line, the locator and the error.
                2. Read the failing test source and its page objects/fixtures. Find the page URL: playwright.config baseURL plus the
                   path the test visits. If the app is not running, start it with process_start (the webServer command from
                   playwright.config, or the package.json start/dev script), wait until the URL answers, and stop it when done.
                3. For each locator, assertion-text or timeout failure: browser_navigate to the page, repeat the test's steps up to
                   the failing point (browser_click/browser_type/browser_fill_form), then browser_snapshot. Compare the test's
                   locator and expected text with what the snapshot really shows; check browser_console_messages and
                   browser_network_requests for app errors. If a browser tool reports that the browser is not installed, call
                   browser_install once and retry; if it still fails, report it as an environment blocker.
                4. Fix from that evidence only: prefer role/label/test-id locators (getByRole, getByLabel, getByTestId) that match
                   the snapshot, correct the expected text, or wait for a real condition. No fixed sleeps, no skipping, no
                   deleting or weakening assertions. If the snapshot shows the APPLICATION is wrong (a real bug), fix the app code
                   when it is in this workspace, otherwise report it as an application defect — do not bend the test to the bug.
                5. Re-run ONLY the fixed tests with the runner, then the full requested scope once. A browser click or snapshot is
                   never proof that a test passes; only the runner's result counts. Report per test: cause seen in the browser,
                   change made, and the final runner result. Tests you could not fix are reported as failing with the reason
                   (login/credentials, missing test data, environment, application defect).
                """;
    }

    /** The user asked for Playwright MCP but no browser MCP server is connected in this run. */
    static String browserMcpMissing(boolean masterSwitchOn) {
        return "[PLAYWRIGHT MCP NOT AVAILABLE IN THIS RUN] The user asked to use Playwright MCP, but no Playwright/Chrome DevTools " +
                "MCP server is connected" + (masterSwitchOn ? "" : " (the MCP master switch is off)") + ". Diagnose and fix the failing " +
                "tests from the runner output and the source (the test workflow still applies). In the final answer say clearly that live " +
                "browser inspection was not available and that the user can run \"configure Playwright MCP\" in Agent mode once, then repeat the request.";
    }

    void markPreflight() { preflightDone = true; }

    /** Error text when this action would skip or disable tests; null when allowed. */
    String blockReason(String tool, String command, String editContent) {
        if (userAllowsSkip) return null;
        if (command != null && SKIP_COMMAND.matcher(command).find())
            return "TEST WORKFLOW: skipping tests or ignoring failures is not allowed for this request (" +
                    firstMatch(SKIP_COMMAND, command) + "). Run the real tests and fix the cause.";
        if (editContent != null && SKIP_EDIT.matcher(editContent).find() &&
                Set.of("edit", "write", "apply_patch", "resource_edit", "resource_write").contains(tool))
            return "TEST WORKFLOW: disabling or skipping tests (" + firstMatch(SKIP_EDIT, editContent) + ") is not allowed " +
                    "for this request. Fix the code or the test expectation for a real reason instead.";
        return null;
    }

    /** Record a completed runner execution; returns the enforced diagnosis to append to the tool result. */
    String afterRun(String command, String output, boolean failed, long mutationRevision) {
        runs++;
        lastRunner = runnerOf(command);
        String text = output == null ? "" : output;
        if (!failed) {
            lastState = "PASSED";
            lastPassingRevision = mutationRevision;
            failingTests.clear();
            return "\nTEST WORKFLOW: run passed. If files change again, the tests must be re-run before finishing.";
        }
        lastState = "FAILED";
        List<String> found = failingTests(text);
        failingTests.clear();
        failingTests.addAll(found);
        StringBuilder out = new StringBuilder("\n\nTEST FAILURE DIAGNOSIS (enforced by the runtime)\n");
        if (found.isEmpty()) out.append("Failing tests: not identifiable from the output (check the full runner report).\n");
        else out.append("Failing tests: ").append(String.join(", ", found.subList(0, Math.min(12, found.size()))))
                .append(found.size() > 12 ? " (+" + (found.size() - 12) + " more)" : "").append('\n');
        List<String> errors = errorLines(text);
        if (!errors.isEmpty()) out.append("First errors:\n").append(String.join("\n", errors)).append('\n');
        out.append("Required next steps:\n")
                .append("1. Read each failing test and the code it exercises at the reported lines (do not guess).\n")
                .append("2. Decide whether the code or the test expectation is wrong; fix the real cause. Do not skip, disable or delete tests.\n")
                .append("3. Re-run ONLY the failing tests");
        String targeted = targetedCommand(lastRunner, found);
        if (!targeted.isBlank()) out.append(", e.g. `").append(targeted).append('`');
        out.append(".\n4. When they pass, re-run the full requested scope once to confirm nothing else broke.");
        if (browserMcp && (lastRunner == Runner.PLAYWRIGHT || UI_FAILURE.matcher(text).find()))
            out.append("\nPlaywright MCP: before editing, open each failing page with browser_navigate, repeat the steps to the failing ")
                    .append("point and take browser_snapshot; fix the locator/expectation/wait from what the snapshot shows (see the ")
                    .append("PLAYWRIGHT MCP TEST-FIX WORKFLOW).");
        return out.toString();
    }

    /** Why the run may not finish yet (null when the test workflow is satisfied). */
    String completionProblem(long mutationRevision) {
        if (runs == 0) return "No test runner has been executed yet; this request requires running the tests.";
        if ("FAILED".equals(lastState)) return "The latest test run failed" +
                (failingTests.isEmpty() ? "" : " (" + String.join(", ", new ArrayList<>(failingTests).subList(0, Math.min(6, failingTests.size()))) + ")") +
                "; fix the cause and re-run.";
        if (mutationRevision > lastPassingRevision) return "Files changed after the last passing test run; re-run the tests on the current revision.";
        return null;
    }

    /** At most three times the runtime sends the executor back instead of letting the run end failed/blocked. */
    boolean allowGateReentry() { return ++gateReentries <= 3; }

    static List<String> failingTests(String output) {
        LinkedHashSet<String> out = new LinkedHashSet<>();
        for (Pattern pattern : FAILING) {
            Matcher matcher = pattern.matcher(output);
            while (matcher.find() && out.size() < 40) {
                String cls = matcher.group(1).strip();
                String method = matcher.groupCount() >= 2 && matcher.group(2) != null ? matcher.group(2).strip() : "";
                out.add(method.isEmpty() ? cls : cls + (cls.endsWith(".py") ? "::" : "#") + method);
            }
        }
        return List.copyOf(out);
    }

    static String targetedCommand(Runner runner, List<String> tests) {
        if (tests.isEmpty()) return "";
        List<String> few = tests.subList(0, Math.min(5, tests.size()));
        return switch (runner) {
            case MAVEN -> "mvn -q test -Dtest=" + String.join(",", few.stream().map(t -> simpleClass(t)).toList()) + " -DfailIfNoTests=false";
            case GRADLE -> "gradle test " + String.join(" ", few.stream().map(t -> "--tests " + t.replace('#', '.')).toList());
            case PYTEST -> "pytest " + String.join(" ", few);
            case PLAYWRIGHT -> "npx playwright test " + String.join(" ", few.stream().map(t -> t.split("#", 2)[0]).distinct().toList());
            case JEST -> "npx jest -t \"" + few.get(0).replaceAll(".*#", "").replace("\"", "") + "\"";
            default -> "";
        };
    }

    static Runner runnerOf(String command) {
        String c = command == null ? "" : command.toLowerCase(Locale.ROOT);
        if (c.matches("(?s).*\\b(?:mvn|mvnw)\\b.*")) return Runner.MAVEN;
        if (c.matches("(?s).*\\b(?:gradle|gradlew)\\b.*")) return Runner.GRADLE;
        if (c.contains("playwright")) return Runner.PLAYWRIGHT;
        if (c.contains("jest")) return Runner.JEST;
        if (c.contains("pytest")) return Runner.PYTEST;
        if (c.matches("(?s).*\\b(?:npm|pnpm|yarn)\\b.*")) return Runner.NPM;
        return Runner.OTHER;
    }

    private static String simpleClass(String test) {
        String[] parts = test.split("#", 2);
        String cls = parts[0].contains(".") ? parts[0].substring(parts[0].lastIndexOf('.') + 1) : parts[0];
        return parts.length > 1 && !parts[1].isBlank() ? cls + "#" + parts[1] : cls;
    }

    private static List<String> errorLines(String output) {
        List<String> out = new ArrayList<>();
        for (String line : output.split("\\R")) {
            if (ERROR_LINE.matcher(line).find()) {
                String clean = line.strip();
                out.add("  " + (clean.length() > 220 ? clean.substring(0, 220) + "…" : clean));
                if (out.size() >= 8) break;
            }
        }
        return out;
    }

    private static String firstMatch(Pattern pattern, String text) {
        Matcher matcher = pattern.matcher(text);
        return matcher.find() ? matcher.group().strip() : "";
    }
}
