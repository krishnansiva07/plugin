package com.llmart.llm.cli;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.Optional;
import java.util.Properties;
import java.util.function.Predicate;

/**
 * Durable "workspace path -> terminal conversation" mapping.
 *
 * <p>Previously every {@code eliya} process got a random session id and therefore a brand-new
 * conversation. A follow-up command in a new shell ({@code eliya implement}, "continue", "now fix it")
 * lost the earlier analysis, and implement failed with "No completed Analyse response". The terminal now
 * resumes the workspace's last terminal conversation unless the user asks for {@code --new}.</p>
 */
final class TerminalConversationStore {
    private final Path file;
    private final Properties values = new Properties();

    TerminalConversationStore(Path file) {
        this.file = file;
        load();
    }

    static TerminalConversationStore inDataDirectory() {
        String data = System.getProperty("app.data-dir");
        Path base = data == null || data.isBlank()
                ? Path.of(System.getProperty("user.home"), ".eliya") : Path.of(data);
        return new TerminalConversationStore(base.resolve("cli-terminal-conversations.properties"));
    }

    /** The stored conversation for this workspace, only if it still exists. */
    synchronized Optional<String> find(String workspaceKey, Predicate<String> stillExists) {
        String id = values.getProperty(workspaceKey);
        if (id == null || id.isBlank()) return Optional.empty();
        if (stillExists != null && !stillExists.test(id)) {
            values.remove(workspaceKey);
            save();
            return Optional.empty();
        }
        return Optional.of(id);
    }

    synchronized void remember(String workspaceKey, String conversationId) {
        if (workspaceKey == null || conversationId == null || conversationId.isBlank()) return;
        if (conversationId.equals(values.getProperty(workspaceKey))) return;
        values.setProperty(workspaceKey, conversationId);
        save();
    }

    private void load() {
        if (!Files.isRegularFile(file)) return;
        try (InputStream in = Files.newInputStream(file)) {
            values.load(in);
        } catch (IOException ignored) {
            // A corrupt mapping only means the next command starts a fresh conversation.
        }
    }

    private void save() {
        try {
            Files.createDirectories(file.getParent());
            Path tmp = Files.createTempFile(file.getParent(), ".cli-conv-", ".tmp");
            try (OutputStream out = Files.newOutputStream(tmp)) {
                values.store(out, "ELIYA terminal conversation per workspace (safe to delete)");
            }
            Files.move(tmp, file, StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException ignored) {
            // Non-fatal: conversation continuity is a convenience, never a correctness dependency.
        }
    }
}
