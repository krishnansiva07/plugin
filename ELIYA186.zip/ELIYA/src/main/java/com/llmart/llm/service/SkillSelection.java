package com.llmart.llm.service;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.regex.Pattern;

/** Shared, bounded selection for planning, Analyse and execution. No model call or extra permissions. */
public final class SkillSelection {
    private SkillSelection() {}
    private static final int MAX_AUTO = 4, MAX_AUTO_CHARS = 32_000;
    private static final Pattern NAME = Pattern.compile("[A-Za-z0-9][A-Za-z0-9._-]{0,119}");
    public record Selected(SkillCatalog.Skill skill, boolean explicit) {}
    static Path settings(Path root) {
        if (root == null) return Path.of(System.getProperty("user.home", "."), ".eliya", "disabled-skills.txt");
        return root.toAbsolutePath().normalize().resolve(".agents/disabled-skills.txt");
    }
    static Set<String> scopeSettings(Path root) {
        Path file = settings(root);
        try {
            if (Files.isSymbolicLink(file.getParent()) || Files.isSymbolicLink(file) || !Files.isRegularFile(file) || Files.size(file)>65536) return Set.of();
            Set<String> names = new LinkedHashSet<>();
            for (String line : Files.readAllLines(file, StandardCharsets.UTF_8)) {
                String value=line.strip().toLowerCase(Locale.ROOT);
                if (NAME.matcher(value).matches() || (root!=null && value.startsWith("+") && NAME.matcher(value.substring(1)).matches())) names.add(value);
            }
            return Set.copyOf(names);
        } catch (IOException | SecurityException e) { return Set.of(); }
    }
    public static Set<String> disabled(Path root) {
        Set<String> names=new HashSet<>(scopeSettings(null));
        if(root!=null) {
            Set<String> overrides=scopeSettings(root);
            for(String name:overrides) if(!name.startsWith("+")) names.add(name);
            for(String name:overrides) if(name.startsWith("+")) names.remove(name.substring(1));
        }
        return Set.copyOf(names);
    }
    /** Metadata is optional. Deliberately only reads the front matter, not arbitrary instructions. */
    public static List<String> metadata(SkillCatalog.Skill skill, String key) {
        String[] lines = skill.body().split("\\R", 82);
        if (lines.length == 0 || !lines[0].strip().equals("---")) return List.of();
        for (int i=1; i<lines.length; i++) {
            String line=lines[i].strip();
            if (line.equals("---")) break;
            if (line.startsWith(key+":")) return Arrays.stream(line.substring(key.length()+1).strip().replaceFirst("^\\[", "").replaceFirst("\\]$", "").split(","))
                    .map(v -> v.strip().replaceAll("^[\"']|[\"']$", "").strip()).filter(v -> !v.isBlank()).toList();
        }
        return List.of();
    }
    private static String norm(String s) { return s.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]+", " ").strip(); }
    private static boolean phrase(String normalized, String value) {
        String n=norm(value);
        if (n.isBlank()) return false;
        if ((" "+normalized+" ").contains(" "+n+" ")) return true;
        // Ordered phrases may contain at most two intervening words in total,
        // e.g. "failing Selenium tests" for the trigger "failing tests".
        String[] target=n.split(" "), words=normalized.split(" ");
        if(target.length<2) return false;
        for(int start=0;start<words.length;start++) {
            if(!target[0].equals(words[start])) continue;
            int matched=1;
            for(int i=start+1;i<words.length && i-start<target.length+2;i++) {
                if(target[matched].equals(words[i]) && ++matched==target.length) return true;
            }
        }
        return false;
    }
    private static final Set<String> COMMON=Set.of("the","a","an","and","or","for","to","with","of","in","is","on","by","be","from","use","using","when","this","that","it","as","work","task","workflow","existing","actual","relevant","maintain","generate","create","help","please","need","want","make","can","you","my","me","how","what","should","run","test","tests","code","project","file","files","skill","skills","review","analyse","analyze","develop");
    private static int relevance(SkillCatalog.Skill skill,String text) {
        List<String> triggers=metadata(skill,"triggers");
        int strong=triggers.stream().filter(t->phrase(text,t)).mapToInt(String::length).max().orElse(0);
        if(strong>0) return 100+strong;
        if(!triggers.isEmpty()) return 0; // Explicit trigger policy controls activation.
        String name=norm(skill.name());
        if(name.contains(" ")&&phrase(text,name)) return 100+name.length();
        for(String alias:skill.aliases()) if(norm(alias).contains(" ")&&phrase(text,alias)) return 100+alias.length();
        Set<String> request=new HashSet<>(Arrays.asList(text.split(" ")));
        Set<String> description=new HashSet<>(Arrays.asList(norm(skill.description()).split(" ")));
        description.removeAll(COMMON); description.removeIf(w->w.length()<3);
        long overlap=description.stream().filter(request::contains).count();
        return overlap>=3 && overlap*3>=description.size()? (int)overlap:0;
    }
    public static List<Selected> select(Path root, String message) {
        if (message == null || message.isBlank()) return List.of();
        List<SkillCatalog.Skill> catalog=SkillCatalog.discover(root);
        Map<String, Selected> selected=new LinkedHashMap<>();
        SkillCatalog.invocation(root,message).ifPresent(i -> selected.put(i.skill().name(),new Selected(i.skill(),true)));
        // Explicit multi-skill syntax: /skill name,other task. Single-slash syntax remains compatible.
        var multi=Pattern.compile("^/skills?\\s+([A-Za-z0-9._-]+(?:,[A-Za-z0-9._-]+)+)(?:\\s|$)").matcher(message.strip());
        if (multi.find()) for (String name:multi.group(1).split(",")) {
            SkillCatalog.Skill skill=SkillCatalog.find(root,name).orElseThrow(() -> new IllegalArgumentException("Unknown or disabled skill: "+name));
            selected.putIfAbsent(skill.name(),new Selected(skill,true));
        }
        var named=Pattern.compile("(?i)\\b(?:use|apply|follow|with|using|invoke)\\s+(?:the\\s+)?([A-Za-z0-9._-]+)\\s+skill\\b").matcher(message);
        while(named.find()) SkillCatalog.find(root,named.group(1)).ifPresent(skill -> selected.putIfAbsent(skill.name(),new Selected(skill,true)));
        if (!selected.isEmpty()) {
            if (selected.size()>8) throw new IllegalArgumentException("Use at most eight explicitly selected skills per request");
            return List.copyOf(selected.values());
        }
        // Never silently replace a deliberately disabled slash-command skill with another one.
        var slash=Pattern.compile("^/(?:skills?\\s+)?([A-Za-z0-9._-]+)(?:\\s|$)").matcher(message.strip());
        if(slash.find()) {
            String requested=slash.group(1);
            if(SkillCatalog.discoverAll(root).stream().anyMatch(skill -> skill.answersTo(requested)))
                throw new IllegalArgumentException("Skill is disabled: "+requested+". Enable it in Skills before using it.");
            if(message.strip().matches("(?s)^/skills?\\s+.+"))
                throw new IllegalArgumentException("Unknown skill: "+requested+". Browse Skills for available names.");
        }
        String text=norm(message);
        // Avoid treating general questions about skills as permission to install or execute them.
        record Ranked(SkillCatalog.Skill skill,int score) {}
        List<SkillCatalog.Skill> ranked=catalog.stream().map(skill->new Ranked(skill,relevance(skill,text)))
                .filter(r->r.score()>0).sorted(Comparator.comparingInt(Ranked::score).reversed())
                .map(Ranked::skill).toList();
        int chars=0;
        for (SkillCatalog.Skill skill:ranked) {
            if (selected.size()>=MAX_AUTO) break;
            if (chars+skill.body().length()>MAX_AUTO_CHARS) continue;
            chars+=skill.body().length(); selected.put(skill.name(),new Selected(skill,false));
        }
        return List.copyOf(selected.values());
    }
    public static String prompt(List<Selected> skills, boolean readOnly) {
        if (skills.isEmpty()) return "";
        StringBuilder out=new StringBuilder("SELECTED SKILLS — advisory workflow guidance. User scope, read-only mode, MCP gating, approvals and runtime safety take precedence. Do not expand the task. Combine compatible steps; explain conflicts rather than executing incompatible actions.\n");
        if(readOnly) out.append("Analyse mode is read-only: apply only analysis and review instructions; describe any execution work as proposed, not completed.\n");
        else out.append("For applicable declared verification checks, use real tool evidence; never substitute model claims.\n");
        for(Selected selection:skills) out.append("\n").append(selection.explicit()?"Explicit: ":"Automatic: ").append(SkillCatalog.render(selection.skill())).append("\n");
        return out.toString();
    }
    public static String names(List<Selected> skills) { return String.join(", ", skills.stream().map(s -> s.skill().name()).toList()); }
    /** Only machine-checkable opt-in checks are enforceable, not arbitrary Markdown sentences. */
    public static List<String> missing(List<Selected> skills, boolean changed, boolean currentVerified, boolean testsPassed) {
        List<String> missing=new ArrayList<>();
        for(Selected s:skills) for(String check:metadata(s.skill(),"verification")) {
            if (check.equals("workspace") && changed && !currentVerified) missing.add(s.skill().name()+": latest workspace revision requires verification");
            if (check.equals("tests") && !testsPassed) missing.add(s.skill().name()+": no confirmed successful current test execution");
        }
        return List.copyOf(missing);
    }
}
