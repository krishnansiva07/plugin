package com.llmart.llm.service;

import java.util.Locale;

/**
 * Failure explanations grounded in the error already recorded by the runtime.
 * No code change, test success, approval or retry is claimed by this presenter.
 */
final class AgentFailureAdvisor {
    private AgentFailureAdvisor() { }

    static String append(String report, String status, String detail, String verification) {
        String existing = report == null ? "" : report.strip();
        if (!"blocked".equals(status) && !"failed".equals(status)) return existing;
        if (existing.contains("### Why execution stopped and how to proceed")) return existing;
        String source = (detail == null ? "" : detail) + "\n" + (verification == null ? "" : verification);
        String lower = source.toLowerCase(Locale.ROOT);
        String diagnosis;
        String safeAction;
        if (contains(lower, "401", "403", "429", "provider", "model unavailable", "model/provider", "connection refused", "api key", "rate limit")) {
            diagnosis = "The recorded failure points to model/provider authentication, connectivity, rate limits or availability; this is not evidence of a coding defect.";
            safeAction = "Inspect the provider/model error and connection settings, restore access, then retry the unfinished step with the same task and workspace. Do not skip verification or change providers/credentials without authorization.";
        } else if (contains(lower, "permission", "access denied", "unauthorized", "approval", "readonly", "read-only", "denied")) {
            diagnosis = "The recorded failure suggests a workspace, tool or approval restriction.";
            safeAction = "Identify the exact denied path/tool/permission, request the required approval or restore access, and resume the same step. Do not weaken deletion, workspace or rollback safeguards.";
        } else if (contains(lower, "index", "no actual read/search", "workspace read", "workspace path", "not readable", "not found", "missing source")) {
            diagnosis = "The runtime could not confirm that the required workspace/source evidence was accessible.";
            safeAction = "Inspect the configured writable workspace and read-only reference paths, check file visibility/index coverage, retry the smallest failing read or targeted re-index, then continue the original task.";
        } else if (contains(lower, "no independent verifier", "missing evidence", "could not independently verify", "unverified", "not verified", "test execution", "runner summary", "not passed", "verification incomplete")) {
            diagnosis = "Completion evidence is missing or stale. Missing proof is not, by itself, a confirmed implementation defect.";
            safeAction = "Run the exact missing independent check against the current revision, capture its exit code/output and required file read-back, then re-evaluate the original acceptance criteria. Fix code only if the check identifies a real defect.";
        } else if (contains(lower, "test failed", "tests failed", "compilation failed", "build failed", "syntax error", "unresolved tool error", "failing", "exception")) {
            diagnosis = "A real tool, build or test failure was recorded, but its underlying code cause still needs to be isolated.";
            safeAction = "Inspect the first actionable failing command/stack trace, make the smallest in-scope repair, and rerun that command and the affected tests before continuing the plan.";
        } else if (contains(lower, "prompt deliverable", "no created or modified", "artifact", "html report", "docx", "markdown")) {
            diagnosis = "A requested output artifact or its read-back/format validation could not be established.";
            safeAction = "Compare requested outputs with the actual saved files, regenerate only missing/incomplete artifacts in the approved workspace, then read them back and validate their required format/content.";
        } else if (contains(lower, "loop", "repeated", "non-actionable", "executor recovery", "stall")) {
            diagnosis = "The execution strategy repeated without producing new evidence or progress; repeated identical attempts were stopped to avoid wasted tokens.";
            safeAction = "Inspect the last failed tool call and active plan step; switch to a smaller, different diagnostic action with fresh evidence, then resume from the saved state rather than restarting completed work.";
        } else {
            diagnosis = "The available record does not establish one specific root cause. The incomplete state must not be presented as a successful execution.";
            safeAction = "Open the last failed execution event and its tool output, identify the first failing dependency, then attempt a targeted in-scope correction and resume the unfinished step with verification.";
        }
        return existing + "\n\n### Why execution stopped and how to proceed\n\n" +
                "**Diagnosis from recorded evidence:** " + diagnosis + "\n\n" +
                "**Recommended recovery:** " + safeAction + "\n\n" +
                "The exact blocker and earlier completed work remain available in Agent activity; " +
                "this message does not claim that a retry or verification has already succeeded.";
    }

    private static boolean contains(String lower, String... needles) {
        for (String item : needles) if (lower.contains(item)) return true;
        return false;
    }
}
