package com.llmart.llm.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Builds planner prompts. Extracted from {@code AgentService.generatePlanProposal}.
 *
 * <p>The previous prompt asked only for a "SHORT actionable plan", with no requirement to reference
 * the evidence, so models produced placeholder steps ("Analyse the codebase", "Implement the changes",
 * "Verify"). Those either passed through as a vague contract or were replaced by a deterministic fallback
 * built from the user's own words. Either way the executor received no real plan.</p>
 */
final class AgentPlanPrompt {
    private AgentPlanPrompt() { }

    static String system(boolean planPreview) {
        String base = """
                You plan tasks for the Eliya coding agent. The ORIGINAL USER REQUEST is authoritative:
                preserve every requested phase, named path, output, constraint, exclusion and ordering.

                Write a task-SPECIFIC plan grounded in the LIVE WORKSPACE EVIDENCE:
                - Each step names the concrete files, classes, functions, endpoints, modules or commands it acts on,
                  taken from the evidence (e.g. "Update `OrderService.retry()` in src/main/java/.../OrderService.java").
                  If the target is not in the evidence yet, say exactly what to locate and how
                  (e.g. "Locate the retry policy: grep for `RetryTemplate` under src/main").
                - Each step starts with one action verb and states its own outcome; one concern per step.
                - Implementation steps say WHAT changes, not just "implement the changes".
                - End code-changing plans with ONE verification step that names the real command when known
                  (build/test tool from the workspace profile, e.g. `mvn -q test -Dtest=OrderServiceTest`).
                - Read-only questions: investigation steps only, no edits, no build.
                - Never invent paths, classes or commands that the evidence contradicts; unknowns become a
                  "locate ..." step. No MCP unless the user explicitly requested it.
                - Typical size 2-7 steps; use more only for genuinely multi-phase requests. No cosmetic steps.

                FORBIDDEN placeholder steps (rejected automatically): "Analyse the requirements",
                "Inspect the codebase", "Implement the requested changes", "Test the changes",
                "Verify the solution", "Provide a summary".
                """;
        return base + (planPreview
                ? "\nReturn ONLY compact JSON: {\"plan\":[\"Action 1\",\"Action 2\"]," +
                  "\"improved_prompt\":\"optional\",\"suggestions\":[],\"clarification\":\"\"}. " +
                  "Suggestions are optional and must never change the user's requirements."
                : "\nReturn ONLY compact JSON: {\"plan\":[\"Step 1\",\"Step 2\"]}. No narrative outside JSON.");
    }

    static String user(String task, String evidence, String analysis, String requestType, boolean planPreview) {
        StringBuilder out = new StringBuilder();
        out.append("ORIGINAL USER REQUEST (highest priority):\n").append(task);
        if (analysis != null && !analysis.isBlank()) {
            out.append("\n\nREAD-ONLY ANALYSIS OF THE EVIDENCE (facts vs assumptions):\n").append(analysis);
        }
        out.append("\n\nLIVE WORKSPACE EVIDENCE (partial; unknowns become 'locate' steps):\n").append(evidence);
        if (MigrationIntent.isMigration(task)) {
            out.append("\n\nMIGRATION (generic engine): ").append(MigrationIntent.parse(task).map(MigrationIntent.Spec::summary)
                    .orElse("source/target not explicit — confirm them from build files"))
                    .append(". Plan the phases: migration_init (spec, inventory, ledger) → migration_baseline → optional automatic ")
                    .append("rewrite recipe → batches in dependency order, each followed by migration_verify → fix failed items → final ")
                    .append("full verification and report against the baseline. Name the source and target in the plan.");
        }
        String mcpKnowledge = McpKnownServers.knowledgeFor(task, true);
        if (!mcpKnowledge.isBlank()) out.append("\n\n").append(mcpKnowledge);
        out.append("\n\nREQUEST TYPE HINT (not an instruction): ").append(requestType);
        out.append("\n\nRESPONSE MODE: ").append(planPreview
                ? "PLAN PREVIEW ONLY: concise proposed steps, optional improvements, and one question only " +
                  "if a critical requirement is ambiguous. Do not execute."
                : "EXECUTE: return the executable plan; no approval needed.");
        return out.toString();
    }

    /** One corrective round when the first draft was unusable or generic. */
    static List<Map<String,Object>> corrective(List<Map<String,Object>> original, String previousResponse, String problem) {
        List<Map<String,Object>> retry = new ArrayList<>(original);
        if (previousResponse != null && !previousResponse.isBlank()) {
            retry.add(Map.of("role", "assistant", "content",
                    previousResponse.length() > 6_000 ? previousResponse.substring(0, 6_000) : previousResponse));
        }
        retry.add(Map.of("role", "user", "content", "PLAN REJECTED: " + problem + ".\n" +
                "Rewrite the plan so every step names the concrete files/classes/commands from the LIVE WORKSPACE " +
                "EVIDENCE it acts on (or states exactly what to locate and how). Keep every user requirement. " +
                "Return ONLY the JSON object, complete and valid."));
        return retry;
    }
}
