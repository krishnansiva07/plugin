package com.llmart.llm.service;

import org.springframework.stereotype.Service;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.*;
import java.util.Properties;

/** Local-only, persisted performance limits. No browser storage or JVM launch flags required. */
@Service
public class WorkspaceIndexingSettings {
    public record Limits(int maxFiles, int maxScannedFiles, int maxFileBytes,
                         int maxSourceChars, int maxReadLines, int maxFullReadKb) { }

    public static final Limits DEFAULTS = new Limits(150_000, 300_000, 1_500_000, 48_000, 2_500, 256);
    private final Path location;
    private volatile Limits current;

    public WorkspaceIndexingSettings() {
        this(Path.of(System.getProperty("app.data-dir", "./data"), "workspace-indexing.properties"));
    }

    // Package-visible constructor makes read/write/restart behavior testable without Spring.
    WorkspaceIndexingSettings(Path location) {
        this.location = location.toAbsolutePath().normalize();
        this.current = load();
    }

    public Limits current() { return current; }

    /** Source-index identity; changing read-only tool limits must not trigger a 125k-file rescan. */
    public static int indexFingerprint(Limits settings) {
        return java.util.Objects.hash(settings.maxFiles(), settings.maxScannedFiles(),
                settings.maxFileBytes(), settings.maxSourceChars());
    }

    /** All values have hard safety bounds and the scan cap must cover the index cap. */
    public static Limits validate(Limits value) {
        if (value == null) throw new IllegalArgumentException("Indexing preferences are required");
        require("Maximum indexed files", value.maxFiles(), 2_000, 200_000);
        require("Maximum scanned files", value.maxScannedFiles(), value.maxFiles(), 500_000);
        require("Indexed source file bytes", value.maxFileBytes(), 32_000, 8_000_000);
        require("Source sample characters", value.maxSourceChars(), 8_000, 200_000);
        require("Read lines per request", value.maxReadLines(), 100, 10_000);
        require("Full file read KB", value.maxFullReadKb(), 64, 8192);
        return value;
    }

    private static void require(String label, int number, int min, int max) {
        if (number < min || number > max) throw new IllegalArgumentException(
                label + " must be between " + min + " and " + max);
    }

    public synchronized Limits save(Limits value) throws IOException {
        Limits accepted = validate(value);
        Properties properties = new Properties();
        properties.setProperty("maxFiles", Integer.toString(accepted.maxFiles()));
        properties.setProperty("maxScannedFiles", Integer.toString(accepted.maxScannedFiles()));
        properties.setProperty("maxFileBytes", Integer.toString(accepted.maxFileBytes()));
        properties.setProperty("maxSourceChars", Integer.toString(accepted.maxSourceChars()));
        properties.setProperty("maxReadLines", Integer.toString(accepted.maxReadLines()));
        properties.setProperty("maxFullReadKb", Integer.toString(accepted.maxFullReadKb()));
        Files.createDirectories(location.getParent());
        Path temp = Files.createTempFile(location.getParent(), "indexing-", ".tmp");
        try {
            try (OutputStream out = Files.newOutputStream(temp)) {
                properties.store(out, "ELIYA workspace indexing preferences; edit through Settings");
            }
            try { Files.move(temp, location, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING); }
            catch (AtomicMoveNotSupportedException exception) { Files.move(temp, location, StandardCopyOption.REPLACE_EXISTING); }
        } finally { Files.deleteIfExists(temp); }
        current = accepted;
        return accepted;
    }

    private Limits load() {
        if (!Files.isRegularFile(location)) return DEFAULTS;
        Properties properties = new Properties();
        try (InputStream in = Files.newInputStream(location)) {
            properties.load(in);
            return validate(new Limits(
                Integer.parseInt(properties.getProperty("maxFiles")),
                Integer.parseInt(properties.getProperty("maxScannedFiles")),
                Integer.parseInt(properties.getProperty("maxFileBytes")),
                Integer.parseInt(properties.getProperty("maxSourceChars")),
                Integer.parseInt(properties.getProperty("maxReadLines")),
                Integer.parseInt(properties.getProperty("maxFullReadKb"))));
        } catch (Exception invalid) { return DEFAULTS; }
    }
}
