package com.llmart.llm.service;

import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;

/**
 * ELIYA149: mapped project and named reference routing.
 * Pure, deterministic; never makes permission or filesystem decisions.
 * A UI-selected project is the default target for repository investigations.
 */
final class WorkspaceIntentPolicy {
    private WorkspaceIntentPolicy() { }

    private static final Pattern PROJECT_INVESTIGATION = Pattern.compile(
            "(?is)^\\s*(?:(?:please|can you|could you|would you|i want you to|i need you to|let's|kindly)\\s+){0,2}" +
            "(?:analyse|analyze|review|inspect|audit|investigate|assess|evaluate|trace|check|verify|summari[sz]e|explain|understand|compare|find|identify|describe|map)\\b");
    private static final Pattern PROJECT_SUBJECT = Pattern.compile(
            "(?is)\\b(?:this|our|current|existing|configured|mapped|selected|legacy|implementation|architecture|" +
            "design|framework|code|source|classes|modules|functions|methods|dependencies|project|app|application|" +
            "api|endpoint|flow|tests?|testcases?|scenarios?|features?|defects?|bugs?|gaps?|risks?|performance|" +
            "structure|solution|system|files?|configuration|migrat\\w*|playwright|selenium|scripts?|pipeline|integration|unit|coverage|spec)\\b");
    private static final Pattern GENERAL_REFERENCE_REQUEST = Pattern.compile(
            "(?is)\\b(?:all\\s+)?(?:reference(?:s|\\s+(?:projects?|folders?|codebases?|sources?))|" +
            "mapped\\s+references|configured\\s+references)\\b");
    private static final Pattern GREETING = Pattern.compile(
            "(?is)^\\s*(?:hi|hello|hey|thanks|thank you|good morning|good afternoon|good evening)[!.? ]*\\s*$");

    /** Used only when a primary project is actually selected. Never invokes repository work for general chat. */
    static boolean implicitProjectInvestigation(String query) {
        if (query == null || query.isBlank() || GREETING.matcher(query).matches()) return false;
        String text = query.strip();
        // A short contextual request defaults to the selected project, rather than guessing a topic.
        if (text.matches("(?is)^(?:(?:please|can you|could you)\\s+)?(?:analyse|analyze|review|inspect|audit|check|verify)(?:\\s+(?:it|this|that))?[.?! ]*$")) return true;
        return PROJECT_INVESTIGATION.matcher(text).find() && PROJECT_SUBJECT.matcher(text).find();
    }

    static Set<String> mentionedReferenceIds(String query, Map<String,String> names) {
        Set<String> matches = new LinkedHashSet<>();
        if (query == null || query.isBlank() || names == null || names.isEmpty()) return matches;
        for (var entry : names.entrySet()) {
            String name = entry.getValue();
            if (entry.getKey() == null || name == null || !name.matches("[A-Za-z][A-Za-z0-9_-]{0,39}")) continue;
            Pattern exact = Pattern.compile("(?i)(?<![A-Za-z0-9_-])" + Pattern.quote(name) + "(?![A-Za-z0-9_-])");
            if (exact.matcher(query).find()) matches.add(entry.getKey());
        }
        return matches;
    }

    /**
     * An explicit alias scopes a read-only Analyse request to that reference by default.
     * Primary evidence is additionally needed when the user requests a comparison to the
     * mapped project, a migration, or an implementation proposal for the target project.
     */
    static boolean includePrimaryForQuery(String query, Map<String,String> names) {
        if (mentionedReferenceIds(query, names).isEmpty()) return true;
        String remainder = query == null ? "" : query;
        // Exclude alias text itself from primary-target detection (an alias may be "Current" or "Main").
        for (String alias : names.values()) {
            if (alias == null || !alias.matches("[A-Za-z][A-Za-z0-9_-]{0,39}")) continue;
            remainder = remainder.replaceAll("(?i)(?<![A-Za-z0-9_-])" + Pattern.quote(alias) +
                    "(?![A-Za-z0-9_-])", " ");
        }
        return Pattern.compile("(?is).*(?:\\b(?:workspace|primary|target)\\b|" +
                "\\b(?:our|this|main|current|selected)\\s+(?:project|workspace|code|framework|application)\\b|" +
                "\\b(?:migrat\\w*|implement|develop|modify|change|update|refactor|port|convert|reuse|integrate|fix|repair)\\b).*"
        ).matcher(remainder).matches();
    }

    static boolean requestsAllReferences(String query) {
        return query != null && GENERAL_REFERENCE_REQUEST.matcher(query).find();
    }

    /** A short alias-only question needs architecture terms to retrieve useful source, not an alias string absent from files. */
    static String sourceRetrievalQuery(String query, String alias) {
        String text = query == null ? "" : query.strip();
        // For a broad/short investigation the user's alias or "analyse" is absent from source
        // tokens; enrich the retrieval query without expanding the user's task contract.
        if (text.length() > 120 || !text.matches("(?is).*(?:analyse|analyze|review|inspect|architecture|design|framework|structure|code|project|migration|verify|check|assess|audit).*"))
            return text;
        return text + "\nRelevant project source README, build, architecture, modules, entrypoints, configuration, implementation, dependencies and tests.";
    }
}
