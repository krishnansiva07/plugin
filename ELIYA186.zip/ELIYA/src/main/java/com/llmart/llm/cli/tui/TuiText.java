package com.llmart.llm.cli.tui;

import java.util.ArrayList;
import java.util.List;

/** Display width, wrapping and ANSI styling helpers for the full-screen terminal UI. */
public final class TuiText {
    public static final String RESET = "\u001b[0m";
    public static final String BOLD = "\u001b[1m";
    public static final String DIM = "\u001b[2m";
    public static final String INVERSE = "\u001b[7m";
    public static final String RED = "\u001b[31m";
    public static final String GREEN = "\u001b[32m";
    public static final String YELLOW = "\u001b[33m";
    public static final String BLUE = "\u001b[34m";
    public static final String MAGENTA = "\u001b[35m";
    public static final String CYAN = "\u001b[36m";
    public static final String GRAY = "\u001b[90m";

    private TuiText() { }

    /** Terminal cell width of a code point (0 for controls/combining marks, 2 for wide CJK/emoji). */
    public static int width(int cp) {
        if (cp == 0 || cp < 32 || (cp >= 0x7f && cp < 0xa0)) return 0;
        if (Character.getType(cp) == Character.NON_SPACING_MARK || Character.getType(cp) == Character.ENCLOSING_MARK
                || cp == 0x200b || cp == 0x200d || (cp >= 0xfe00 && cp <= 0xfe0f)) return 0;
        if ((cp >= 0x1100 && cp <= 0x115f) || (cp >= 0x2e80 && cp <= 0xa4cf) || (cp >= 0xac00 && cp <= 0xd7a3)
                || (cp >= 0xf900 && cp <= 0xfaff) || (cp >= 0xfe30 && cp <= 0xfe4f) || (cp >= 0xff00 && cp <= 0xff60)
                || (cp >= 0xffe0 && cp <= 0xffe6) || (cp >= 0x1f300 && cp <= 0x1f64f) || (cp >= 0x1f900 && cp <= 0x1f9ff)
                || (cp >= 0x20000 && cp <= 0x3fffd)) return 2;
        return 1;
    }

    /** Visible width of a string that may contain ANSI SGR sequences. */
    public static int visibleWidth(String text) {
        int total = 0;
        for (int i = 0; i < text.length(); ) {
            char c = text.charAt(i);
            if (c == '\u001b') { i = skipEscape(text, i); continue; }
            int cp = text.codePointAt(i);
            total += width(cp);
            i += Character.charCount(cp);
        }
        return total;
    }

    static int skipEscape(String text, int i) {
        int j = i + 1;
        if (j < text.length() && text.charAt(j) == '[') {
            j++;
            while (j < text.length() && (text.charAt(j) < '@' || text.charAt(j) > '~')) j++;
            return Math.min(text.length(), j + 1);
        }
        if (j < text.length() && text.charAt(j) == ']') { // OSC ... BEL
            int bel = text.indexOf('\u0007', j);
            return bel < 0 ? text.length() : bel + 1;
        }
        return Math.min(text.length(), j + 1);
    }

    /** Remove control characters that would corrupt the screen (keeps tabs as spaces). */
    public static String sanitize(String text) {
        if (text == null) return "";
        StringBuilder out = new StringBuilder(text.length());
        for (int i = 0; i < text.length(); ) {
            int cp = text.codePointAt(i);
            i += Character.charCount(cp);
            if (cp == '\t') out.append("    ");
            else if (cp == '\n') out.append('\n');
            else if (cp == 0x1b || cp < 32 || (cp >= 0x7f && cp < 0xa0)) continue;
            else out.appendCodePoint(cp);
        }
        return out.toString();
    }

    /** Word-wrap plain text (no ANSI) to {@code width} cells; hard newlines are kept; long words are split. */
    public static List<String> wrap(String text, int width) {
        List<String> lines = new ArrayList<>();
        int max = Math.max(4, width);
        for (String paragraph : sanitize(text).split("\n", -1)) {
            if (paragraph.isEmpty()) { lines.add(""); continue; }
            StringBuilder line = new StringBuilder();
            int lineWidth = 0;
            int i = 0;
            while (i < paragraph.length()) {
                int end = i;
                boolean space = paragraph.charAt(i) == ' ';
                while (end < paragraph.length() && (paragraph.charAt(end) == ' ') == space) end++;
                String token = paragraph.substring(i, end);
                int tokenWidth = visibleWidth(token);
                if (lineWidth + tokenWidth <= max) { line.append(token); lineWidth += tokenWidth; }
                else if (space) { lines.add(line.toString().stripTrailing()); line.setLength(0); lineWidth = 0; }
                else if (tokenWidth <= max) { lines.add(line.toString().stripTrailing()); line.setLength(0); line.append(token); lineWidth = tokenWidth; }
                else {
                    for (int k = 0; k < token.length(); ) {
                        int cp = token.codePointAt(k);
                        int w = width(cp);
                        if (lineWidth + w > max) { lines.add(line.toString()); line.setLength(0); lineWidth = 0; }
                        line.appendCodePoint(cp); lineWidth += w;
                        k += Character.charCount(cp);
                    }
                }
                i = end;
            }
            lines.add(line.toString().stripTrailing());
        }
        return lines;
    }

    /** Cut a plain string to at most {@code width} cells, adding an ellipsis when cut. */
    public static String fit(String text, int width) {
        String clean = sanitize(text).replace('\n', ' ');
        if (visibleWidth(clean) <= width) return clean;
        StringBuilder out = new StringBuilder();
        int used = 0;
        for (int i = 0; i < clean.length(); ) {
            int cp = clean.codePointAt(i);
            int w = width(cp);
            if (used + w > Math.max(0, width - 1)) break;
            out.appendCodePoint(cp); used += w;
            i += Character.charCount(cp);
        }
        return out.append('…').toString();
    }

    /** Pad a styled string with spaces to exactly {@code width} visible cells (assumes it already fits). */
    public static String pad(String styled, int width) {
        int missing = width - visibleWidth(styled);
        return missing <= 0 ? styled : styled + " ".repeat(missing);
    }
}
