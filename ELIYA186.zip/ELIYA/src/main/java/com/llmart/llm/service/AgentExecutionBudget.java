package com.llmart.llm.service;

/**
 * Central, overridable runtime budgets for the Agent execution loop.
 *
 * <p>These used to be magic numbers spread through {@code AgentService}. The old exploration limit
 * (steer at 6, abort at 10 read/search turns) was too tight for real repositories: an implementation step
 * on a large codebase routinely needs more than ten reads before the first edit, and hitting the limit
 * switched models or ended the run as failed. Every value can be overridden with a JVM system property
 * (e.g. {@code -Deliya.agent.explorationLimitTurns=24}).</p>
 */
final class AgentExecutionBudget {
    private AgentExecutionBudget() { }

    /** Read/search turns on an implementation step before the runtime nudges the executor to edit. */
    static int explorationSteerTurns() {
        return bounded("eliya.agent.explorationSteerTurns", 8, 2, 200);
    }

    /** Read/search turns without any change or verifier progress before failover/recovery. */
    static int explorationLimitTurns() {
        return Math.max(explorationSteerTurns() + 2, bounded("eliya.agent.explorationLimitTurns", 16, 4, 400));
    }

    /** Corrective turns the executor gets when the final reviewer cannot see enough evidence. */
    static int finalReviewCorrectiveTurns() {
        return bounded("eliya.agent.finalReviewCorrectiveTurns", 3, 1, 20);
    }

    /** Autonomous evidence-gathering attempts per unchanged evidence set. */
    static int autonomousEvidenceAttempts() {
        return bounded("eliya.agent.autonomousEvidenceAttempts", 2, 1, 10);
    }

    /**
     * When true (default), a run whose latest revision passed a real verifier and whose plan is complete is
     * reported as completed even if the model reviewer still says MISSING_EVIDENCE; the reviewer's caveat is
     * shown in the answer. A concrete DEFECT verdict still fails the run.
     */
    static boolean acceptVerifiedOutcomeOnMissingEvidence() {
        return !"false".equalsIgnoreCase(System.getProperty("eliya.agent.acceptVerifiedOnMissingEvidence", "true"));
    }

    private static int bounded(String property, int fallback, int min, int max) {
        try {
            int value = Integer.parseInt(System.getProperty(property, Integer.toString(fallback)).trim());
            return Math.max(min, Math.min(max, value));
        } catch (NumberFormatException invalid) {
            return fallback;
        }
    }
}
