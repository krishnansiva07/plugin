package com.llmart.llm.controller;

import com.llmart.llm.service.ProjectService;
import com.llmart.llm.service.SkillManagement;
import org.springframework.web.bind.annotation.*;
import java.io.IOException;
import java.nio.file.Path;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/skills")
public class SkillController {
    private final ProjectService projects;
    public SkillController(ProjectService projects) { this.projects=projects; }
    private Path root(String projectId) {
        if(projectId==null || projectId.isBlank()) return null;
        var project=projects.require(projectId);
        if(!project.hasLocalPath()) throw new IllegalArgumentException("Choose a local workspace or global skills");
        return Path.of(project.getLocalPath()).toAbsolutePath().normalize();
    }
    @GetMapping public List<Map<String,Object>> list(@RequestParam(required=false) String projectId) { return SkillManagement.list(root(projectId)); }
    @GetMapping("/{name}") public Map<String,String> get(@PathVariable String name,@RequestParam(required=false) String projectId) {
        var s=SkillManagement.get(root(projectId),name); return Map.of("name",s.name(),"content",s.body(),"source",s.source());
    }
    public record Save(String content,boolean overwrite) {}
    public record Toggle(boolean enabled) {}
    @PutMapping("/{name}") public Map<String,Object> save(@PathVariable String name,@RequestParam(required=false) String projectId,@RequestBody Save body) throws IOException {
        SkillManagement.save(root(projectId),name,body.content(),body.overwrite()); return Map.of("saved",true,"name",name);
    }
    @PutMapping("/{name}/enabled") public Map<String,Object> toggle(@PathVariable String name,@RequestParam(required=false) String projectId,@RequestBody Toggle body) throws IOException {
        SkillManagement.toggle(root(projectId),name,body.enabled()); return Map.of("enabled",body.enabled());
    }
}
