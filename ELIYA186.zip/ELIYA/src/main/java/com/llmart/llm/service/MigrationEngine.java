package com.llmart.llm.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.FileVisitResult;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.StandardOpenOption;
import java.nio.file.attribute.BasicFileAttributes;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.concurrent.TimeUnit;
import java.util.function.BooleanSupplier;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Generic migration engine used by the Agent tools migration_init / migration_baseline / migration_status /
 * migration_verify / migration_update. Same phases for any migration: understand (spec + workspace evidence),
 * discover (work items from old-API "residue"), baseline (tests before), transform in batches (Agent), verify each
 * batch (no residue left + no NEW test failures vs the baseline), durable ledger, and a completion check.
 * State lives in the workspace under {@code migration/<id>/} so any later run (browser, terminal, unattended) resumes.
 */
final class MigrationEngine {

    /** Runs a shell command in a directory; replaceable in tests. */
    interface Runner { CommandResult run(Path dir, String command, Duration timeout, BooleanSupplier cancelled); }

    record CommandResult(int exit, String output, boolean timedOut) { }

    /** Tool result. testCommand/testFailed are set when a test command ran (for the enforced test workflow). */
    record Outcome(String text, boolean failed, String testCommand, String testOutput, boolean testFailed) {
        static Outcome ok(String text) { return new Outcome(text, false, "", "", false); }
        static Outcome error(String text) { return new Outcome(text, true, "", "", false); }
    }

    /** Ledger row. Status: pending, migrated, verified, failed, blocked, not_applicable. */
    static final class Item {
        String id, module, path, kind, status, evidence, note;
        int residue;
        Item(String id, String module, String path, String kind, int residue, String status, String evidence, String note) {
            this.id = id; this.module = module; this.path = path; this.kind = kind; this.residue = residue;
            this.status = status; this.evidence = evidence; this.note = note;
        }
    }

    record Problem(boolean unfinished, String text) { }

    static final String ROOT_DIR = "migration";
    static final Set<String> STATUSES = Set.of("pending", "migrated", "verified", "failed", "blocked", "not_applicable");
    private static final Set<String> SKIP_DIRS = Set.of(".git", ".svn", ".hg", "node_modules", "target", "build", "dist", "out", ".gradle",
            ".idea", ".vscode", "__pycache__", ".venv", "venv", "env", ".tox", ".mypy_cache", ".pytest_cache", "bin", "obj",
            ".next", ".nuxt", "coverage", ".eliya", "migration", "test-results", "playwright-report", ".terraform", "vendor", "third_party");
    private static final Set<String> TEXT_EXT = Set.of(".java", ".kt", ".kts", ".groovy", ".scala", ".xml", ".gradle", ".properties", ".yml", ".yaml",
            ".json", ".js", ".jsx", ".ts", ".tsx", ".mjs", ".cjs", ".vue", ".svelte", ".py", ".rb", ".go", ".cs", ".csproj", ".fs", ".php",
            ".jsp", ".tag", ".html", ".htm", ".css", ".scss", ".less", ".sql", ".sh", ".bat", ".cmd", ".ps1", ".toml", ".cfg", ".ini", ".txt",
            ".md", ".feature", ".swift", ".m", ".c", ".h", ".cpp", ".hpp", ".rs", ".dart", ".tf", ".env");
    /** Files larger than this are not scanned; they become explicit UNSCANNED items, never a silent pass. */
    static long maxScanBytes() { return limit("ELIYA_MIGRATION_MAX_SCAN_MB", 64) * 1024 * 1024; }
    /** Traversal limit; reaching it marks discovery coverage INCOMPLETE (default far above the 300k index limit). */
    static long maxVisited() { return limit("ELIYA_MIGRATION_MAX_VISITED", 2_000_000); }
    /** Ledger size limit; exceeding it marks coverage INCOMPLETE instead of dropping items silently. */
    static long maxItems() { return limit("ELIYA_MIGRATION_MAX_ITEMS", 500_000); }

    private static long limit(String name, long fallback) {
        String raw = System.getProperty(name.toLowerCase(Locale.ROOT).replace('_', '.'), System.getenv(name));
        try { return raw == null || raw.isBlank() ? fallback : Math.max(1, Long.parseLong(raw.strip())); }
        catch (NumberFormatException invalid) { return fallback; }
    }

    /** Result of scanning one file for old-API usage. Only SCANNED is evidence; everything else is unknown. */
    enum ScanState { SCANNED, TOO_LARGE, READ_ERROR, MISSING }

    /** Discovery coverage: what was visited, scanned, left out and why. */
    static final class Coverage {
        long visited, textFiles, scanned, tooLarge, readErrors, nonText, matched;
        boolean truncatedVisit, truncatedItems;
        final Map<String, Long> skippedExtensions = new TreeMap<>();
        boolean complete() { return !truncatedVisit && !truncatedItems; }
        String line() {
            return visited + " files visited, " + scanned + " scanned, " + matched + " with old API" +
                    (tooLarge + readErrors > 0 ? ", " + (tooLarge + readErrors) + " could not be scanned (listed as UNSCANNED items)" : "") +
                    (nonText > 0 ? ", " + nonText + " non-source files skipped" : "") +
                    (truncatedVisit ? "; TRAVERSAL LIMIT REACHED (" + maxVisited() + " files) — coverage incomplete" : "") +
                    (truncatedItems ? "; LEDGER LIMIT REACHED (" + maxItems() + " items) — coverage incomplete" : "");
        }
    }
    static final int BATCH = 8;
    private static final ObjectMapper JSON = new ObjectMapper();

    private final Runner runner;

    MigrationEngine(Runner runner) { this.runner = runner; }

    static MigrationEngine standard() { return new MigrationEngine(MigrationEngine::runShell); }

    // ================================================================================================== init

    Outcome init(Path root, JsonNode args, String request) throws IOException {
        if (root == null) return Outcome.error("BLOCKED: a migration needs a project workspace. Select the project folder first.");
        MigrationIntent.Spec parsed = MigrationIntent.parse(request).orElse(new MigrationIntent.Spec("", "", List.of(), "", false, ""));
        String source = firstNonBlank(text(args, "source"), parsed.source());
        String target = firstNonBlank(text(args, "target"), parsed.target());
        List<String> scope = list(args, "scope");
        if (scope.isEmpty()) scope = parsed.scope();
        String verify = firstNonBlank(text(args, "verifyCommand"), "");
        Map<String, String> facts = facts(root);
        if (source.isBlank()) source = inferSource(target, facts);
        if (target.isBlank())
            return Outcome.error("MIGRATION TARGET UNKNOWN: say what to migrate to (for example target=\"Spring Boot 3.2\"). " +
                    "Nothing was created. Workspace evidence: " + factsLine(facts));
        final String src = source;
        MigrationPacks.Pack pack = MigrationPacks.byId(text(args, "pack")).orElseGet(() -> MigrationPacks.match(src, target).orElse(null));
        List<MigrationPacks.Residue> residue = new ArrayList<>();
        if (pack != null) residue.addAll(pack.residue());
        for (String custom : list(args, "residuePatterns")) {
            try { Pattern.compile(custom); residue.add(new MigrationPacks.Residue("custom", custom, List.of())); }
            catch (Exception invalid) { return Outcome.error("INVALID residue pattern " + custom + ": " + invalid.getMessage()); }
        }
        if (pack == null && list(args, "residuePatterns").isEmpty()) residue.addAll(MigrationPacks.generic(source));
        if (verify.isBlank()) verify = detectVerifyCommand(root, firstNonBlank(parsed.verify(), ""));
        String id = slug(source.isBlank() ? "to-" + target : source + "-to-" + target);
        Path dir = root.resolve(ROOT_DIR).resolve(id);
        boolean exists = Files.isRegularFile(dir.resolve("items.csv"));
        if (exists && !args.path("restart").asBoolean(false)) {
            Files.writeString(root.resolve(ROOT_DIR).resolve("ACTIVE"), id + System.lineSeparator(), StandardCharsets.UTF_8);
            return Outcome.ok("MIGRATION RESUMED (existing ledger kept): " + id + "\n" + status(root).text() +
                    "\nUse restart=true only to rebuild the ledger from scratch.");
        }

        // Discover work items
        List<Path> roots = scopeRoots(root, scope);
        List<String> unmatchedScope = new ArrayList<>();
        for (int i = 0; i < scope.size(); i++) if (roots.get(i) == null) unmatchedScope.add(scope.get(i));
        // ELIYA180: a scope that cannot be resolved never silently widens to the whole project.
        boolean broaden = args.path("broadenScope").asBoolean(false);
        if (!unmatchedScope.isEmpty() && !broaden)
            return Outcome.error("SCOPE NOT FOUND: " + String.join(", ", unmatchedScope) + " did not match any folder or package in " + root +
                    ". Nothing was created. Correct the scope (folder path, folder name or Java/Python package), or pass broadenScope=true " +
                    "only if the user explicitly agreed to migrate " + (roots.stream().allMatch(p -> p == null) ? "the whole project" : "the scope that was found") + ".");
        List<Path> searchRoots = roots.stream().filter(p -> p != null).distinct().toList();
        if (searchRoots.isEmpty()) searchRoots = List.of(root);
        Map<String, Integer> hits = new TreeMap<>();
        Map<String, String> kinds = new LinkedHashMap<>();
        List<String> exclude = list(args, "exclude").stream().map(e -> e.replace('\\', '/').replaceAll("^\\./", "")).toList();
        Coverage coverage = new Coverage();
        Map<String, String> unscanned = new TreeMap<>();
        for (Path base : searchRoots) scanResidue(root, base, residue, hits, kinds, unscanned, coverage);
        java.util.function.Predicate<String> excluded = path -> exclude.stream().anyMatch(e -> path.equals(e) || path.startsWith(e.endsWith("/") ? e : e + "/") ||
                path.matches(e.replace(".", "\\.").replace("**", "\u0000").replace("*", "[^/]*").replace("\u0000", ".*")));
        hits.keySet().removeIf(excluded);
        unscanned.keySet().removeIf(excluded);
        List<Item> items = new ArrayList<>();
        List<String> ordered = new ArrayList<>(hits.keySet());
        ordered.sort(Comparator.comparingInt(MigrationEngine::orderRank).thenComparing(p -> p));
        int n = 1;
        for (String path : ordered) {
            if (items.size() >= maxItems()) { coverage.truncatedItems = true; break; }
            items.add(new Item(String.format("M%04d", n++), module(path), path, kinds.getOrDefault(path, ""), hits.get(path), "pending", "", ""));
        }
        // Files that could not be scanned are work items too: their state is unknown, never "no old API".
        for (Map.Entry<String, String> u : unscanned.entrySet()) {
            if (items.size() >= maxItems()) { coverage.truncatedItems = true; break; }
            items.add(new Item(String.format("M%04d", n++), module(u.getKey()), u.getKey(), "UNSCANNED: " + u.getValue(), -1, "pending", "",
                    "could not be scanned automatically — review it, then mark migrated (if changed) or not_applicable with a reason"));
        }
        Files.createDirectories(dir);
        ObjectNode spec = JSON.createObjectNode();
        spec.put("id", id).put("source", source).put("target", target).put("verifyCommand", verify)
                .put("pack", pack == null ? "" : pack.id()).put("created", Instant.now().toString()).put("request", clip(request, 2000));
        ArrayNode scopeNode = spec.putArray("scope"); scope.forEach(scopeNode::add);
        ArrayNode excludeNode = spec.putArray("exclude"); exclude.forEach(excludeNode::add);
        ArrayNode residueNode = spec.putArray("residue");
        for (MigrationPacks.Residue r : residue) {
            ObjectNode node = residueNode.addObject(); node.put("label", r.label()).put("regex", r.regex());
            ArrayNode ext = node.putArray("extensions"); r.extensions().forEach(ext::add);
        }
        ObjectNode factsNode = spec.putObject("facts"); facts.forEach(factsNode::put);
        spec.set("coverage", coverageNode(coverage));
        boolean residueOnly = args.path("residueOnly").asBoolean(false) && !text(args, "noTestsReason").isBlank();
        spec.put("residueOnlyApproved", residueOnly);
        spec.put("noTestsReason", residueOnly ? text(args, "noTestsReason") : "");
        Files.writeString(dir.resolve("spec.json"), JSON.writerWithDefaultPrettyPrinter().writeValueAsString(spec), StandardCharsets.UTF_8);
        writeItems(dir, items);
        Files.writeString(dir.resolve("PLAN.md"), plan(spec, pack, items, unmatchedScope, target), StandardCharsets.UTF_8);
        if (!Files.exists(dir.resolve("MAPPING.md"))) Files.writeString(dir.resolve("MAPPING.md"), mapping(pack, source, target), StandardCharsets.UTF_8);
        Files.writeString(root.resolve(ROOT_DIR).resolve("ACTIVE"), id + System.lineSeparator(), StandardCharsets.UTF_8);

        StringBuilder out = new StringBuilder("MIGRATION INITIALISED: ").append(source.isBlank() ? "?" : source).append(" → ").append(target).append('\n');
        out.append("Ledger: ").append(ROOT_DIR).append('/').append(id).append("/ (PLAN.md, MAPPING.md, items.csv, spec.json)\n");
        out.append("Workspace evidence: ").append(factsLine(facts)).append('\n');
        out.append("Knowledge pack: ").append(pack == null ? "none (generic discovery from the source name" +
                (list(args, "residuePatterns").isEmpty() ? "" : " + your patterns") + ")" : pack.title()).append('\n');
        if (!scope.isEmpty()) out.append("Scope: ").append(String.join(", ", scope))
                .append(unmatchedScope.isEmpty() ? "" : " (not found as folders/packages: " + String.join(", ", unmatchedScope) + "; searched the whole project)").append('\n');
        out.append("Work items: ").append(items.size()).append(" files in ").append(items.stream().map(i -> i.module).distinct().count()).append(" modules\n");
        out.append("Coverage: ").append(coverage.line()).append('\n');
        if (!coverage.complete()) out.append("COVERAGE INCOMPLETE: this migration cannot be reported as complete until discovery covers the whole scope " +
                "(narrow the scope, add exclude patterns for generated/vendored code, or raise ELIYA_MIGRATION_MAX_VISITED / ELIYA_MIGRATION_MAX_ITEMS).\n");
        if (residueOnly) out.append("Verification without tests APPROVED by the user: ").append(text(args, "noTestsReason")).append('\n');
        if (!items.isEmpty()) out.append("First batch: ").append(String.join(", ", items.stream().limit(BATCH).map(i -> i.id + " " + i.path).toList())).append('\n');
        String recipe = MigrationPacks.recipeFor(pack, target);
        if (!recipe.isBlank()) out.append("Automatic rewrite available (optional, run before manual edits): ").append(recipe).append('\n');
        out.append("Verify command: ").append(verify.isBlank() ? "none detected — pass verifyCommand to migration_baseline" : verify).append('\n');
        if (items.isEmpty()) out.append("NO RESIDUE FOUND with the current patterns. If the migration is still needed, call migration_init again with " +
                "residuePatterns (regexes for the old API/imports/config) and restart=true, or mark it done if nothing uses the source.\n");
        out.append("Next: migration_baseline (run the tests before changing anything).");
        return Outcome.ok(out.toString());
    }

    // ============================================================================================== baseline

    Outcome baseline(Path root, JsonNode args, BooleanSupplier cancelled) throws IOException {
        Path dir = activeDir(root);
        if (dir == null) return Outcome.error("NO ACTIVE MIGRATION: call migration_init first.");
        ObjectNode spec = (ObjectNode) JSON.readTree(Files.readString(dir.resolve("spec.json")));
        String command = firstNonBlank(text(args, "command"), spec.path("verifyCommand").asText(""));
        if (command.isBlank()) command = detectVerifyCommand(root, "");
        ObjectNode baseline = JSON.createObjectNode();
        baseline.put("time", Instant.now().toString()).put("command", command);
        if (command.isBlank()) {
            baseline.put("available", false).put("reason", "no test command detected");
            Files.writeString(dir.resolve("baseline.json"), JSON.writerWithDefaultPrettyPrinter().writeValueAsString(baseline), StandardCharsets.UTF_8);
            return Outcome.ok("BASELINE UNAVAILABLE: no test/build command detected. Pass command=\"…\" (for example mvn -q test, " +
                    "npm test, pytest) so verification can tell new failures from old ones. Verification will rely on residue checks only.");
        }
        String skip = AgentTestEvidence.skipFlag(command);
        if (skip != null) return Outcome.error("REJECTED: the verification command skips or ignores tests (" + skip + "). Use a command that runs them.");
        spec.put("verifyCommand", command);
        Files.writeString(dir.resolve("spec.json"), JSON.writerWithDefaultPrettyPrinter().writeValueAsString(spec), StandardCharsets.UTF_8);
        long started = System.currentTimeMillis();
        CommandResult result = runner.run(root, command, timeout(), cancelled);
        AgentTestEvidence.Count executed = AgentTestEvidence.of(result.output(), root, started);
        baseline.put("executed", executed.executed()).put("evidence", executed.describe());
        List<String> failing = AgentTestWorkflow.failingTests(result.output());
        baseline.put("available", true).put("exit", result.exit()).put("timedOut", result.timedOut());
        ArrayNode failingNode = baseline.putArray("failing"); failing.forEach(failingNode::add);
        baseline.put("outputTail", tail(result.output(), 4000));
        Files.writeString(dir.resolve("baseline.json"), JSON.writerWithDefaultPrettyPrinter().writeValueAsString(baseline), StandardCharsets.UTF_8);
        String noTests = !executed.known() || executed.none()
                ? "\nWARNING: " + (executed.none() ? "NO TESTS EXECUTED" : "NO TEST COUNT") + " in the baseline (" + executed.describe() + "). Items can only be verified " +
                  "with a command that really runs tests, or with residue-only verification explicitly approved by the user." : "";
        String text = "BASELINE RECORDED before migration: `" + command + "` → exit " + result.exit() + " · " + executed.describe() +
                (result.timedOut() ? " (timed out)" : "") +
                (result.exit() == 0 ? " — all passing." : failing.isEmpty() ? " — already failing before the migration (no test names parsed; " +
                        "only a change from this state counts as a regression)." : " — already failing before the migration: " +
                        String.join(", ", failing.subList(0, Math.min(15, failing.size()))) + (failing.size() > 15 ? " …" : "") +
                        ". These are NOT caused by the migration.") +
                noTests + "\nOutput tail:\n" + tail(result.output(), 1500) + "\nNext: migrate the first batch (see migration_status), then migration_verify.";
        return new Outcome(text, false, command, result.output(), result.exit() != 0);
    }

    // ================================================================================================ status

    Outcome status(Path root) throws IOException {
        Path dir = activeDir(root);
        if (dir == null) return Outcome.error("NO ACTIVE MIGRATION: call migration_init first.");
        JsonNode spec = JSON.readTree(Files.readString(dir.resolve("spec.json")));
        List<Item> items = readItems(dir);
        Map<String, Long> counts = counts(items);
        List<Item> next = nextBatch(items);
        StringBuilder out = new StringBuilder("MIGRATION STATUS: ").append(spec.path("source").asText("?")).append(" → ").append(spec.path("target").asText("?"))
                .append(" (").append(ROOT_DIR).append('/').append(spec.path("id").asText()).append(")\n");
        out.append("Items: ").append(items.size()).append(" — ").append(countsLine(counts)).append('\n');
        out.append("Coverage: ").append(spec.path("coverage").path("summary").asText("not recorded"))
                .append(spec.path("coverage").path("complete").asBoolean(true) ? "" : " — INCOMPLETE").append('\n');
        if (spec.path("residueOnlyApproved").asBoolean(false)) out.append("Verification without tests approved: ").append(spec.path("noTestsReason").asText()).append('\n');
        JsonNode baseline = readBaseline(dir);
        out.append("Baseline: ").append(baseline == null ? "not recorded (run migration_baseline)" :
                !baseline.path("available").asBoolean() ? "unavailable" : "`" + baseline.path("command").asText() + "` exit " + baseline.path("exit").asInt() +
                        (baseline.path("failing").size() > 0 ? ", " + baseline.path("failing").size() + " pre-existing failures" : "")).append('\n');
        if (!next.isEmpty()) {
            out.append("Next batch (").append(next.size()).append("):\n");
            for (Item item : next) out.append("  ").append(item.id).append(' ').append(item.path).append(" [").append(item.status)
                    .append(item.residue > 0 ? ", " + item.residue + " old-API hits: " + item.kind : "").append(item.note.isBlank() ? "" : "; " + clip(item.note, 160)).append("]\n");
        } else out.append("No unfinished items.\n");
        List<Item> blocked = items.stream().filter(i -> i.status.equals("blocked")).toList();
        if (!blocked.isEmpty()) out.append("Blocked (need you): ").append(String.join("; ", blocked.stream().limit(10).map(i -> i.id + " " + i.path + ": " + clip(i.note, 120)).toList())).append('\n');
        out.append("Rules: ").append(ROOT_DIR).append('/').append(spec.path("id").asText()).append("/MAPPING.md");
        return Outcome.ok(out.toString());
    }

    // ================================================================================================ verify

    Outcome verify(Path root, JsonNode args, BooleanSupplier cancelled) throws IOException {
        Path dir = activeDir(root);
        if (dir == null) return Outcome.error("NO ACTIVE MIGRATION: call migration_init first.");
        JsonNode spec = JSON.readTree(Files.readString(dir.resolve("spec.json")));
        List<Item> items = readItems(dir);
        List<String> ids = list(args, "items");
        List<Item> selected = new ArrayList<>();
        for (Item item : items) {
            if (ids.isEmpty() ? item.status.equals("migrated") || item.status.equals("failed") : ids.contains(item.id) || ids.contains(item.path)) selected.add(item);
        }
        if (selected.isEmpty())
            return Outcome.error("NOTHING TO VERIFY: mark migrated items with migration_update (status=migrated) or pass items=[ids].");
        List<MigrationPacks.Residue> residue = residue(spec);
        Map<String, String> residueLeft = new LinkedHashMap<>();
        for (Item item : selected) {
            Path file = root.resolve(item.path).normalize();
            if (!file.startsWith(root)) { residueLeft.put(item.id, "outside workspace"); continue; }
            if (!Files.exists(file)) { item.residue = 0; continue; } // removed or renamed as part of the migration (deliberate)
            Hit hit = scanFile(file, item.path, residue);
            if (hit.state != ScanState.SCANNED) {
                item.residue = -1;
                residueLeft.put(item.id, "could not be scanned (" + hit.state + (hit.detail.isBlank() ? "" : ": " + hit.detail) +
                        ") — review it and mark it not_applicable with a reason, or reduce/split the file");
                continue;
            }
            item.residue = hit.count;
            if (hit.count > 0) residueLeft.put(item.id, hit.count + " old-API hits (" + hit.labels + ") e.g. line " + hit.firstLine + ": " + clip(hit.sample, 120));
        }
        String command = firstNonBlank(text(args, "command"), spec.path("verifyCommand").asText(""));
        boolean residueOnlyApproved = spec.path("residueOnlyApproved").asBoolean(false);
        CommandResult result = null;
        List<String> newFailures = new ArrayList<>();
        String testVerdict;
        String skip = AgentTestEvidence.skipFlag(command);
        if (skip != null) return Outcome.error("REJECTED: the verification command skips or ignores tests (" + skip + "). Use a command that runs them.");
        if (command.isBlank()) {
            if (residueOnlyApproved) testVerdict = "no tests — residue-only verification approved by the user (" + spec.path("noTestsReason").asText() + ")";
            else {
                testVerdict = "NO_TEST_COMMAND: no verification command — provide one that runs tests (migration_baseline command=…), " +
                        "or start the migration with residueOnly=true and the user's reason";
                newFailures.add(testVerdict);
            }
        } else {
            long started = System.currentTimeMillis();
            result = runner.run(root, command, timeout(), cancelled);
            AgentTestEvidence.Count executed = AgentTestEvidence.of(result.output(), root, started);
            List<String> failing = AgentTestWorkflow.failingTests(result.output());
            JsonNode baseline = readBaseline(dir);
            Set<String> before = new LinkedHashSet<>();
            int baselineExit = 0;
            boolean haveBaseline = baseline != null && baseline.path("available").asBoolean();
            if (haveBaseline) { baseline.path("failing").forEach(f -> before.add(f.asText())); baselineExit = baseline.path("exit").asInt(); }
            for (String test : failing) if (!before.contains(test)) newFailures.add(test);
            // A failing run whose failures cannot be named cannot be compared with the baseline: not verified.
            if (result.exit() != 0 && failing.isEmpty())
                newFailures.add("command failed (exit " + result.exit() + ")" + (result.timedOut() ? " — timed out" : "") +
                        (haveBaseline && baselineExit != 0 ? ", and its failures cannot be compared with the baseline" : "") + ": " + firstErrorLine(result.output()));
            // ELIYA180: exit 0 with zero or unreported executed tests is not test evidence.
            if (result.exit() == 0 && newFailures.isEmpty() && (!executed.known() || executed.none()) && !residueOnlyApproved)
                newFailures.add((executed.none() ? "NO_TESTS_EXECUTED" : "NO_TEST_EVIDENCE") + ": `" + command + "` exited 0 but " + executed.describe() +
                        " — run a command that executes tests (and prints a summary or writes JUnit reports)");
            testVerdict = "`" + command + "` exit " + result.exit() + " · " + executed.describe() + (newFailures.isEmpty()
                    ? (result.exit() == 0 ? " — passing" : " — only pre-existing failures (same as baseline)")
                    : " — NEW failures: " + String.join(", ", newFailures.subList(0, Math.min(10, newFailures.size()))));
        }
        boolean testsOk = newFailures.isEmpty();
        int verified = 0, failed = 0;
        for (Item item : selected) {
            String residueProblem = residueLeft.get(item.id);
            if (residueProblem == null && testsOk) { item.status = "verified"; item.evidence = clip("residue 0; " + testVerdict, 300); item.note = ""; verified++; }
            else {
                item.status = "failed"; failed++;
                item.evidence = clip(testVerdict, 300);
                item.note = clip(residueProblem != null ? residueProblem : "tests: " + String.join(", ", newFailures), 300);
            }
        }
        writeItems(dir, items);
        appendLog(dir, "verify " + selected.size() + " item(s): " + verified + " verified, " + failed + " failed; " + testVerdict);
        Map<String, Long> counts = counts(items);
        StringBuilder out = new StringBuilder(failed == 0 ? "MIGRATION BATCH VERIFIED: " : "MIGRATION BATCH NOT VERIFIED: ")
                .append(verified).append(" verified, ").append(failed).append(" failed.\n");
        out.append("Tests: ").append(testVerdict).append('\n');
        if (!residueLeft.isEmpty()) {
            out.append("Old API still present:\n");
            residueLeft.forEach((id, problem) -> out.append("  ").append(id).append(' ')
                    .append(selected.stream().filter(i -> i.id.equals(id)).findFirst().map(i -> i.path).orElse("")).append(": ").append(problem).append('\n'));
        }
        if (result != null && !newFailures.isEmpty()) out.append("Runner output tail:\n").append(tail(result.output(), 2500)).append('\n');
        out.append("Overall: ").append(countsLine(counts)).append('\n');
        long remaining = counts.getOrDefault("pending", 0L) + counts.getOrDefault("migrated", 0L) + counts.getOrDefault("failed", 0L);
        out.append(failed > 0 ? "Next: fix the failed items (old API left or new test failures), then migration_verify them again."
                : remaining > 0 ? "Next: migration_status for the next batch." : "All items are verified. Run the full verification once more and report.");
        return new Outcome(out.toString(), failed > 0, result == null ? "" : command, result == null ? "" : result.output(), !testsOk);
    }

    // ================================================================================================ update

    Outcome update(Path root, JsonNode args) throws IOException {
        Path dir = activeDir(root);
        if (dir == null) return Outcome.error("NO ACTIVE MIGRATION: call migration_init first.");
        String status = text(args, "status").toLowerCase(Locale.ROOT);
        if (status.equals("verified")) return Outcome.error("Items become verified only through migration_verify (residue check + tests).");
        if (!STATUSES.contains(status)) return Outcome.error("Status must be one of: pending, migrated, failed, blocked, not_applicable.");
        String note = text(args, "note");
        if ((status.equals("blocked") || status.equals("not_applicable")) && note.isBlank())
            return Outcome.error("A note is required for " + status + " (say why, so the user can act on it).");
        List<String> ids = list(args, "items");
        if (ids.isEmpty()) return Outcome.error("Pass items=[ids or paths] to update.");
        List<Item> items = readItems(dir);
        List<String> changed = new ArrayList<>();
        List<String> unknown = new ArrayList<>(ids);
        for (Item item : items) {
            if (ids.contains(item.id) || ids.contains(item.path)) {
                item.status = status; if (!note.isBlank()) item.note = clip(note, 300);
                changed.add(item.id); unknown.remove(item.id); unknown.remove(item.path);
            }
        }
        // Files the migration created or that discovery missed can be added as new items.
        if (args.path("add").asBoolean(false)) {
            int next = items.size() + 1;
            for (String path : new ArrayList<>(unknown)) {
                Path file = root.resolve(path).normalize();
                if (!file.startsWith(root) || !Files.isRegularFile(file)) continue;
                String rel = root.relativize(file).toString().replace('\\', '/');
                items.add(new Item(String.format("M%04d", next++), module(rel), rel, "added", 0, status, "", clip(note, 300)));
                changed.add(rel); unknown.remove(path);
            }
        }
        writeItems(dir, items);
        appendLog(dir, "update " + changed + " -> " + status + (note.isBlank() ? "" : " (" + clip(note, 120) + ")"));
        return Outcome.ok("Updated " + changed.size() + " item(s) to " + status + (unknown.isEmpty() ? "" : "; unknown: " + unknown) +
                (status.equals("migrated") ? ". Next: migration_verify for these items." : "") + "\nOverall: " + countsLine(counts(items)));
    }

    // ========================================================================================= completion gate

    /** Null when the active migration has nothing left; otherwise what is left (unfinished=true means keep working). */
    Problem completionProblem(Path root) { return completionProblem(root, false); }

    /**
     * Fail-closed completion check. {@code expectLedger}: this run used the migration engine, so a missing or unreadable
     * ledger, a ledger changed outside the migration tools, or incomplete discovery coverage is a problem, never success.
     */
    Problem completionProblem(Path root, boolean expectLedger) {
        try {
            Path dir = activeDir(root);
            if (dir == null) return expectLedger ? new Problem(false, "the migration ledger (migration/ACTIVE, items.csv, spec.json) is missing or " +
                    "unreadable, so completion cannot be confirmed") : null;
            JsonNode spec = JSON.readTree(Files.readString(dir.resolve("spec.json")));
            String recorded = spec.path("ledgerSha256").asText("");
            String actual = sha256(dir.resolve("items.csv"));
            if (!recorded.isBlank() && !recorded.equals(actual))
                return new Problem(false, "the migration ledger items.csv was changed outside the migration tools (hash mismatch), so its statuses " +
                        "are not trusted. Restore it from version control or rebuild it with migration_init restart=true");
            List<Item> items = readItems(dir);
            Map<String, Long> counts = counts(items);
            long open = counts.getOrDefault("pending", 0L) + counts.getOrDefault("migrated", 0L) + counts.getOrDefault("failed", 0L);
            long blocked = counts.getOrDefault("blocked", 0L);
            if (open > 0) return new Problem(true, open + " of " + items.size() + " migration items are not verified yet (" + countsLine(counts) + ")");
            if (blocked > 0) return new Problem(false, blocked + " migration item(s) are blocked and need you: " +
                    String.join("; ", items.stream().filter(i -> i.status.equals("blocked")).limit(8).map(i -> i.path + " — " + clip(i.note, 100)).toList()));
            if (!spec.path("coverage").path("complete").asBoolean(true))
                return new Problem(false, "discovery coverage is incomplete (" + spec.path("coverage").path("summary").asText("limits reached") +
                        "); files outside the scanned set were never analysed");
            return null;
        } catch (Exception unreadable) {
            return new Problem(false, "the migration ledger could not be read (" + unreadable.getMessage() + "), so completion cannot be confirmed");
        }
    }

    /**
     * Re-run discovery over the whole recorded scope at completion: old API found in a verified item, in a file the
     * ledger never listed, or in a file that cannot be scanned re-opens the work. Returns how many items were (re)opened.
     */
    int completionAudit(Path root) {
        try {
            Path dir = activeDir(root);
            if (dir == null) return 0;
            ObjectNode spec = (ObjectNode) JSON.readTree(Files.readString(dir.resolve("spec.json")));
            List<MigrationPacks.Residue> residue = residue(spec);
            List<String> scope = iterable(spec.path("scope"));
            List<Path> roots = scope.isEmpty() ? List.of(root) : scopeRoots(root, scope).stream().filter(p -> p != null).distinct().toList();
            if (roots.isEmpty()) roots = List.of(root);
            List<String> exclude = iterable(spec.path("exclude"));
            Map<String, Integer> hits = new TreeMap<>();
            Map<String, String> kinds = new LinkedHashMap<>();
            Map<String, String> unscanned = new TreeMap<>();
            Coverage coverage = new Coverage();
            for (Path base : roots) scanResidue(root, base, residue, hits, kinds, unscanned, coverage);
            java.util.function.Predicate<String> excluded = path -> exclude.stream().anyMatch(e -> path.equals(e) || path.startsWith(e.endsWith("/") ? e : e + "/") ||
                    path.matches(e.replace(".", "\\.").replace("**", "\u0000").replace("*", "[^/]*").replace("\u0000", ".*")));
            hits.keySet().removeIf(excluded);
            unscanned.keySet().removeIf(excluded);
            List<Item> items = readItems(dir);
            Map<String, Item> byPath = new LinkedHashMap<>();
            for (Item item : items) byPath.put(item.path, item);
            int reopened = 0, next = items.size() + 1;
            for (Map.Entry<String, Integer> hit : hits.entrySet()) {
                Item item = byPath.get(hit.getKey());
                if (item == null) {
                    items.add(new Item(String.format("M%04d", next++), module(hit.getKey()), hit.getKey(), kinds.getOrDefault(hit.getKey(), ""), hit.getValue(),
                            "pending", "", "found by the completion audit (not in the original inventory)"));
                    reopened++;
                } else if (item.status.equals("verified") || (item.status.equals("not_applicable") && !item.kind.startsWith("UNSCANNED"))) {
                    if (item.status.equals("not_applicable") && !item.note.isBlank()) continue; // user explained why it stays
                    item.status = "failed"; item.residue = hit.getValue();
                    item.note = "completion audit: old API found again (" + kinds.getOrDefault(hit.getKey(), "") + ")";
                    reopened++;
                }
            }
            for (Map.Entry<String, String> u : unscanned.entrySet()) {
                Item item = byPath.get(u.getKey());
                if (item == null) {
                    items.add(new Item(String.format("M%04d", next++), module(u.getKey()), u.getKey(), "UNSCANNED: " + u.getValue(), -1, "pending", "",
                            "found by the completion audit; could not be scanned — review it"));
                    reopened++;
                } else if (item.status.equals("verified")) {
                    item.status = "failed"; item.residue = -1; item.note = "completion audit: file can no longer be scanned (" + u.getValue() + ")";
                    reopened++;
                }
            }
            spec.set("coverage", coverageNode(coverage));
            ObjectNode audit = spec.putObject("completionAudit");
            audit.put("time", Instant.now().toString()).put("reopened", reopened).put("filesWithOldApi", hits.size()).put("unscanned", unscanned.size());
            Files.writeString(dir.resolve("spec.json"), JSON.writerWithDefaultPrettyPrinter().writeValueAsString(spec), StandardCharsets.UTF_8);
            writeItems(dir, items);
            appendLog(dir, "completion audit: " + reopened + " item(s) reopened; " + coverage.line());
            return reopened;
        } catch (Exception failed) {
            return 0; // completionProblem(root, true) reports an unreadable ledger
        }
    }

    /** Short report for the final answer. */
    String report(Path root) {
        try {
            Path dir = activeDir(root);
            if (dir == null) return "";
            JsonNode spec = JSON.readTree(Files.readString(dir.resolve("spec.json")));
            return "Migration " + spec.path("source").asText("?") + " → " + spec.path("target").asText("?") + ": " + countsLine(counts(readItems(dir))) +
                    " (ledger: " + ROOT_DIR + "/" + spec.path("id").asText() + "/items.csv). Say \"continue the migration\" to resume.";
        } catch (Exception unreadable) {
            return "";
        }
    }

    boolean active(Path root) {
        try { return activeDir(root) != null; } catch (Exception e) { return false; }
    }

    // ============================================================================================== protocol

    /** System guidance for a migration request (Agent). */
    static String protocol(String request) {
        MigrationIntent.Spec spec = MigrationIntent.parse(request).orElse(null);
        MigrationPacks.Pack pack = spec == null ? null : MigrationPacks.match(spec.source(), spec.target()).orElse(null);
        return "[MIGRATION ENGINE — applies to any migration]\n" +
                "Understood request: " + (spec == null ? "a migration, but source/target are not explicit — propose them from workspace evidence" : spec.summary()) +
                (pack == null ? "" : "\nKnowledge pack: " + pack.title()) + "\n" +
                "Workflow (tools keep durable state in migration/<id>/ so any later run resumes):\n" +
                "1. migration_init with source, target, scope and verifyCommand you are confident about (inspect build files first if unsure). " +
                "It discovers the work items from old-API usages and shows the spec for the user's approval. If the existing ledger is " +
                "found it resumes instead — never rebuild it unless asked.\n" +
                "2. migration_baseline: run the tests BEFORE changing anything, so pre-existing failures are not blamed on the migration.\n" +
                "3. If init reported an automatic rewrite recipe and the build tool is available, run it once with bash, review the diff, " +
                "then continue manually with what it did not cover.\n" +
                "4. Work in batches from migration_status (dependency order: build files, shared code, then the rest, tests last). For each " +
                "item read the file, apply the rules in MAPPING.md (add rules you discover there), edit, then migration_update status=migrated.\n" +
                "5. migration_verify after every batch: an item is verified only when no old API remains in it and the tests show no NEW " +
                "failures versus the baseline. Fix failed items and verify again. Never skip, disable or delete tests to pass.\n" +
                "6. Continue batch by batch until migration_status shows nothing unfinished. Items you genuinely cannot finish: " +
                "migration_update status=blocked with the reason (credentials, missing dependency, needs a decision).\n" +
                "7. Final answer: counts (verified/blocked), what changed per module, baseline vs final test result, and anything the user must do.";
    }

    /** Guidance for Analyse/Chat mode. */
    static String analyseGuidance(String request) {
        MigrationIntent.Spec spec = MigrationIntent.parse(request).orElse(null);
        MigrationPacks.Pack pack = spec == null ? null : MigrationPacks.match(spec.source(), spec.target()).orElse(null);
        return "[MIGRATION ANALYSIS] Understood: " + (spec == null ? "a migration (source/target not explicit)" : spec.summary()) +
                (pack == null ? "" : "; known migration: " + pack.title() + (pack.recipe().isBlank() ? "" : " (an automatic OpenRewrite recipe exists)")) +
                ". In this read-only mode: confirm source and target from the project's build files, list affected modules and old-API " +
                "usages with evidence, risks and a batch order, and the verification command. Then tell the user that Agent mode " +
                "executes it with Eliya's migration engine (ledger, test baseline, batch verification, resume) — the same request works " +
                "in the browser and the terminal (`eliya agent \"...\"`).";
    }

    // =============================================================================================== helpers

    private Path activeDir(Path root) throws IOException {
        if (root == null) return null;
        Path marker = root.resolve(ROOT_DIR).resolve("ACTIVE");
        if (!Files.isRegularFile(marker)) return null;
        String id = Files.readString(marker, StandardCharsets.UTF_8).strip();
        if (!id.matches("[a-z0-9][a-z0-9._-]{0,90}")) return null;
        Path dir = root.resolve(ROOT_DIR).resolve(id);
        return Files.isRegularFile(dir.resolve("items.csv")) && Files.isRegularFile(dir.resolve("spec.json")) ? dir : null;
    }

    private static JsonNode readBaseline(Path dir) {
        try { return Files.isRegularFile(dir.resolve("baseline.json")) ? JSON.readTree(Files.readString(dir.resolve("baseline.json"))) : null; }
        catch (Exception unreadable) { return null; }
    }

    private static List<MigrationPacks.Residue> residue(JsonNode spec) {
        List<MigrationPacks.Residue> out = new ArrayList<>();
        for (JsonNode node : spec.path("residue")) {
            List<String> ext = new ArrayList<>();
            node.path("extensions").forEach(e -> ext.add(e.asText()));
            out.add(new MigrationPacks.Residue(node.path("label").asText(""), node.path("regex").asText(""), ext));
        }
        return out;
    }

    private record Hit(ScanState state, int count, String labels, int firstLine, String sample, String detail) { }

    /** Line-by-line scan (no whole-file read); UTF-8 with a Latin-1 fallback so odd encodings are still scanned. */
    private static Hit scanFile(Path file, String rel, List<MigrationPacks.Residue> residue) {
        try {
            if (!Files.exists(file)) return new Hit(ScanState.MISSING, 0, "", 0, "", "");
            long size = Files.size(file);
            if (size > maxScanBytes()) return new Hit(ScanState.TOO_LARGE, 0, "", 0, "", (size / (1024 * 1024)) + " MB > " + (maxScanBytes() / (1024 * 1024)) + " MB");
            String fileName = file.getFileName().toString();
            List<Pattern> patterns = new ArrayList<>();
            List<String> labelsOf = new ArrayList<>();
            for (MigrationPacks.Residue r : residue) {
                if (!MigrationPacks.appliesTo(r, fileName)) continue;
                patterns.add(Pattern.compile(r.regex()));
                labelsOf.add(r.label());
            }
            if (patterns.isEmpty()) return new Hit(ScanState.SCANNED, 0, "", 0, "", "");
            try { return scanLines(file, StandardCharsets.UTF_8, patterns, labelsOf); }
            catch (java.nio.charset.CharacterCodingException notUtf8) { return scanLines(file, StandardCharsets.ISO_8859_1, patterns, labelsOf); }
        } catch (IOException | RuntimeException failed) {
            return new Hit(ScanState.READ_ERROR, 0, "", 0, "", clip(String.valueOf(failed.getMessage()), 160));
        }
    }

    private static Hit scanLines(Path file, java.nio.charset.Charset charset, List<Pattern> patterns, List<String> labelsOf) throws IOException {
        int count = 0, firstLine = 0, lineNo = 0;
        String sample = "";
        LinkedHashSet<String> labels = new LinkedHashSet<>();
        java.nio.charset.CharsetDecoder decoder = charset.newDecoder()
                .onMalformedInput(java.nio.charset.CodingErrorAction.REPORT).onUnmappableCharacter(java.nio.charset.CodingErrorAction.REPORT);
        try (java.io.BufferedReader reader = new java.io.BufferedReader(new java.io.InputStreamReader(Files.newInputStream(file), decoder), 65536)) {
            String line;
            while ((line = reader.readLine()) != null) {
                lineNo++;
                for (int i = 0; i < patterns.size(); i++) {
                    Matcher m = patterns.get(i).matcher(line);
                    while (m.find()) {
                        count++;
                        labels.add(labelsOf.get(i));
                        if (firstLine == 0) { firstLine = lineNo; sample = line.strip(); }
                        if (m.end() == m.start() && m.end() >= line.length()) break;
                    }
                }
            }
        } catch (java.io.UncheckedIOException wrapped) {
            if (wrapped.getCause() instanceof java.nio.charset.CharacterCodingException coding) throw coding;
            throw wrapped.getCause();
        }
        return new Hit(ScanState.SCANNED, count, String.join(", ", labels), firstLine, sample, "");
    }

    private static void scanResidue(Path root, Path base, List<MigrationPacks.Residue> residue, Map<String, Integer> hits, Map<String, String> kinds,
                                    Map<String, String> unscanned, Coverage coverage) throws IOException {
        Files.walkFileTree(base, new SimpleFileVisitor<>() {
            @Override public FileVisitResult preVisitDirectory(Path dir, BasicFileAttributes attrs) {
                if (!dir.equals(base) && (SKIP_DIRS.contains(dir.getFileName().toString()) || attrs.isSymbolicLink())) return FileVisitResult.SKIP_SUBTREE;
                return FileVisitResult.CONTINUE;
            }
            @Override public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) {
                if (++coverage.visited > maxVisited()) { coverage.truncatedVisit = true; return FileVisitResult.TERMINATE; }
                if (!attrs.isRegularFile()) return FileVisitResult.CONTINUE;
                if (!textFile(file)) {
                    coverage.nonText++;
                    String name = file.getFileName().toString().toLowerCase(Locale.ROOT);
                    int dot = name.lastIndexOf('.');
                    coverage.skippedExtensions.merge(dot < 0 ? "(none)" : name.substring(dot), 1L, Long::sum);
                    return FileVisitResult.CONTINUE;
                }
                coverage.textFiles++;
                String rel = root.relativize(file).toString().replace('\\', '/');
                Hit hit = scanFile(file, rel, residue);
                switch (hit.state) {
                    case SCANNED -> {
                        coverage.scanned++;
                        if (hit.count > 0) { coverage.matched++; hits.merge(rel, hit.count, Integer::sum); kinds.put(rel, hit.labels); }
                    }
                    case TOO_LARGE -> { coverage.tooLarge++; unscanned.put(rel, "too large to scan (" + hit.detail + ")"); }
                    default -> { coverage.readErrors++; unscanned.put(rel, "read error (" + hit.detail + ")"); }
                }
                return FileVisitResult.CONTINUE;
            }
            @Override public FileVisitResult visitFileFailed(Path file, IOException exc) {
                coverage.readErrors++;
                try { unscanned.put(root.relativize(file).toString().replace('\\', '/'), "unreadable (" + clip(String.valueOf(exc.getMessage()), 120) + ")"); }
                catch (Exception ignored) { }
                return FileVisitResult.CONTINUE;
            }
        });
    }

    private static ObjectNode coverageNode(Coverage coverage) {
        ObjectNode node = JSON.createObjectNode();
        node.put("complete", coverage.complete()).put("summary", coverage.line()).put("visited", coverage.visited).put("textFiles", coverage.textFiles)
                .put("scanned", coverage.scanned).put("matched", coverage.matched).put("tooLarge", coverage.tooLarge).put("readErrors", coverage.readErrors)
                .put("nonText", coverage.nonText).put("truncatedVisit", coverage.truncatedVisit).put("truncatedItems", coverage.truncatedItems);
        ObjectNode ext = node.putObject("skippedExtensions");
        coverage.skippedExtensions.entrySet().stream().sorted(Map.Entry.<String, Long>comparingByValue().reversed()).limit(15)
                .forEach(e -> ext.put(e.getKey(), e.getValue()));
        return node;
    }

    static String sha256(Path file) throws IOException {
        try {
            java.security.MessageDigest digest = java.security.MessageDigest.getInstance("SHA-256");
            return java.util.HexFormat.of().formatHex(digest.digest(Files.readAllBytes(file)));
        } catch (java.security.NoSuchAlgorithmException impossible) { throw new IllegalStateException(impossible); }
    }

    private static boolean textFile(Path file) {
        String name = file.getFileName().toString().toLowerCase(Locale.ROOT);
        if (name.equals("pom.xml") || name.equals("package.json") || name.equals("requirements.txt") || name.equals("gemfile") ||
                name.equals("go.mod") || name.equals("dockerfile") || name.equals("makefile")) return true;
        if (name.equals("package-lock.json") || name.equals("yarn.lock") || name.equals("pnpm-lock.yaml")) return false;
        int dot = name.lastIndexOf('.');
        return dot >= 0 && TEXT_EXT.contains(name.substring(dot));
    }

    /** Build files first, then shared/common code, then other sources, tests last. */
    static int orderRank(String path) {
        String p = path.toLowerCase(Locale.ROOT);
        String name = p.substring(p.lastIndexOf('/') + 1);
        if (name.equals("pom.xml") || name.endsWith(".gradle") || name.endsWith(".gradle.kts") || name.equals("package.json") ||
                name.equals("requirements.txt") || name.equals("pyproject.toml") || name.endsWith(".csproj") || name.equals("go.mod")) return 0;
        if (name.endsWith(".properties") || name.endsWith(".yml") || name.endsWith(".yaml") || name.endsWith(".xml")) return 1;
        boolean test = p.contains("/test/") || p.startsWith("test/") || p.contains("/tests/") || p.startsWith("tests/") || p.contains("__tests__") ||
                name.contains(".test.") || name.contains(".spec.") || name.startsWith("test_") || name.endsWith("test.java") || name.endsWith("tests.java");
        boolean shared = p.matches(".*(?:^|/)(?:common|shared|core|util|utils|base|lib|libs|support|framework)(?:/|$).*");
        if (test) return shared ? 4 : 5;
        return shared ? 2 : 3;
    }

    static String module(String path) {
        int slash = path.indexOf('/');
        if (slash < 0) return "(root)";
        String first = path.substring(0, slash);
        return first.equals("src") ? "(root)" : first;
    }

    /** Resolve scope names to folders: exact relative paths, folder names anywhere, or Java/Python packages. */
    static List<Path> scopeRoots(Path root, List<String> scope) {
        List<Path> out = new ArrayList<>();
        for (String raw : scope) {
            String name = raw.strip().replace('\\', '/');
            Path found = null;
            Path direct = root.resolve(name).normalize();
            if (direct.startsWith(root) && Files.isDirectory(direct)) found = direct;
            if (found == null && name.matches("[A-Za-z_][\\w]*(?:\\.[A-Za-z_][\\w]*)+")) found = findDir(root, name.replace('.', '/'));
            if (found == null && name.matches("[\\w.-]+")) found = findDir(root, name);
            out.add(found);
        }
        return out;
    }

    private static Path findDir(Path root, String suffix) {
        Path[] found = {null};
        try {
            Files.walkFileTree(root, Set.of(), 12, new SimpleFileVisitor<>() {
                @Override public FileVisitResult preVisitDirectory(Path dir, BasicFileAttributes attrs) {
                    if (!dir.equals(root) && SKIP_DIRS.contains(dir.getFileName().toString())) return FileVisitResult.SKIP_SUBTREE;
                    String rel = root.relativize(dir).toString().replace('\\', '/');
                    if (rel.equals(suffix) || rel.endsWith("/" + suffix)) { found[0] = dir; return FileVisitResult.TERMINATE; }
                    return FileVisitResult.CONTINUE;
                }
            });
        } catch (IOException ignored) { }
        return found[0];
    }

    /** Facts from build files: versions the user may not have stated. */
    static Map<String, String> facts(Path root) {
        Map<String, String> facts = new LinkedHashMap<>();
        try {
            Path pom = root.resolve("pom.xml");
            if (Files.isRegularFile(pom)) {
                String text = Files.readString(pom);
                facts.put("build", "maven");
                Matcher boot = Pattern.compile("(?s)<artifactId>spring-boot-starter-parent</artifactId>\\s*<version>([^<]+)</version>").matcher(text);
                if (boot.find()) facts.put("spring boot", boot.group(1).strip());
                Matcher java = Pattern.compile("<(?:java\\.version|maven\\.compiler\\.release|maven\\.compiler\\.source|release)>([^<]+)<").matcher(text);
                if (java.find()) facts.put("java", java.group(1).strip());
                if (text.contains("<artifactId>junit</artifactId>")) facts.put("junit", "4");
                if (text.contains("junit-jupiter")) facts.put("junit", facts.containsKey("junit") ? "4+5" : "5");
            }
            for (String gradle : List.of("build.gradle", "build.gradle.kts")) {
                Path file = root.resolve(gradle);
                if (!Files.isRegularFile(file)) continue;
                String text = Files.readString(file);
                facts.put("build", "gradle");
                Matcher boot = Pattern.compile("org\\.springframework\\.boot['\"]?\\)?\\s*version\\s*['\"]([^'\"]+)").matcher(text);
                if (boot.find()) facts.put("spring boot", boot.group(1));
                Matcher java = Pattern.compile("(?:sourceCompatibility\\s*=\\s*['\"]?(?:JavaVersion\\.VERSION_)?|languageVersion\\.set\\(JavaLanguageVersion\\.of\\()([\\d._]+)").matcher(text);
                if (java.find()) facts.put("java", java.group(1).replace('_', '.'));
            }
            Path pkg = root.resolve("package.json");
            if (Files.isRegularFile(pkg)) {
                facts.put("build", facts.containsKey("build") ? facts.get("build") + "+npm" : "npm");
                JsonNode json = JSON.readTree(Files.readString(pkg));
                for (String section : List.of("dependencies", "devDependencies")) {
                    json.path(section).fields().forEachRemaining(e -> {
                        String name = e.getKey();
                        if (List.of("react", "@angular/core", "angular", "vue", "jest", "vitest", "moment", "dayjs", "typescript", "next", "webpack", "vite",
                                "@playwright/test", "selenium-webdriver", "cypress", "express", "lodash").contains(name))
                            facts.put(name, e.getValue().asText());
                    });
                }
            }
            if (Files.isRegularFile(root.resolve("requirements.txt")) || Files.isRegularFile(root.resolve("pyproject.toml")) ||
                    Files.isRegularFile(root.resolve("setup.py"))) facts.put("python", "project");
        } catch (Exception unreadable) { /* facts are best effort */ }
        return facts;
    }

    static String factsLine(Map<String, String> facts) {
        if (facts.isEmpty()) return "no build files recognised";
        List<String> parts = new ArrayList<>();
        facts.forEach((k, v) -> parts.add(k + " " + v));
        return String.join(", ", parts);
    }

    /** "Java 21" with pom java.version 1.8 → "Java 1.8". */
    static String inferSource(String target, Map<String, String> facts) {
        String t = target == null ? "" : target.toLowerCase(Locale.ROOT);
        for (Map.Entry<String, String> fact : facts.entrySet()) {
            String key = fact.getKey().toLowerCase(Locale.ROOT);
            if (key.equals("build") || key.equals("python")) continue;
            String bare = key.replace("@angular/core", "angular").replace("@", "");
            if (t.startsWith(bare) || t.startsWith(bare.replace(" ", ""))) {
                String version = fact.getValue().replaceAll("^[\\^~>=<v ]+", "");
                String name = target.replaceAll("\\s*v?\\d[\\w.]*\\s*$", "").strip();
                return (name.isBlank() ? fact.getKey() : name) + " " + version;
            }
        }
        return "";
    }

    static String detectVerifyCommand(Path root, String hint) {
        if (hint != null && hint.matches("(?i).*\\b(?:mvn|mvnw|gradle|gradlew|npm|npx|yarn|pnpm|pytest|python|go|dotnet|cargo|make|\\./)\\b.*")) return hint;
        boolean windows = System.getProperty("os.name", "").toLowerCase(Locale.ROOT).contains("win");
        if (Files.isRegularFile(root.resolve("pom.xml"))) {
            String mvn = Files.isRegularFile(root.resolve(windows ? "mvnw.cmd" : "mvnw")) ? (windows ? "mvnw.cmd" : "./mvnw") : "mvn";
            // No -q: the Surefire summary is the test evidence. A build that skips tests by default must not "pass" with zero tests.
            String override = "";
            try {
                String pom = Files.readString(root.resolve("pom.xml"));
                if (pom.matches("(?s).*<maven\\.test\\.skip>\\s*true\\s*</maven\\.test\\.skip>.*")) override += " -Dmaven.test.skip=false";
                if (pom.matches("(?s).*<skipTests>\\s*true\\s*</skipTests>.*")) override += " -DskipTests=false";
            } catch (IOException ignored) { }
            return mvn + " test" + override;
        }
        if (Files.isRegularFile(root.resolve("build.gradle")) || Files.isRegularFile(root.resolve("build.gradle.kts")))
            return Files.isRegularFile(root.resolve(windows ? "gradlew.bat" : "gradlew")) ? (windows ? "gradlew.bat test" : "./gradlew test") : "gradle test";
        Path pkg = root.resolve("package.json");
        if (Files.isRegularFile(pkg)) {
            try {
                JsonNode scripts = JSON.readTree(Files.readString(pkg)).path("scripts");
                if (scripts.has("test") && !scripts.path("test").asText().contains("no test specified")) return "npm test";
            } catch (Exception ignored) { }
        }
        if (Files.isRegularFile(root.resolve("go.mod"))) return "go test ./...";
        try (var stream = Files.list(root)) {
            if (stream.anyMatch(p -> p.toString().endsWith(".sln") || p.toString().endsWith(".csproj"))) return "dotnet test";
        } catch (IOException ignored) { }
        if (Files.isRegularFile(root.resolve("Cargo.toml"))) return "cargo test";
        boolean python = Files.isRegularFile(root.resolve("pytest.ini")) || Files.isRegularFile(root.resolve("pyproject.toml")) ||
                Files.isRegularFile(root.resolve("setup.py")) || Files.isRegularFile(root.resolve("requirements.txt")) || Files.isDirectory(root.resolve("tests"));
        if (python && hasPythonTests(root)) return (windows ? "python" : "python3") + " -m pytest -q";
        return "";
    }

    private static boolean hasPythonTests(Path root) {
        try (var stream = Files.walk(root, 4)) {
            return stream.anyMatch(p -> p.getFileName().toString().matches("test_.*\\.py|.*_test\\.py"));
        } catch (IOException e) { return false; }
    }

    static Duration timeout() {
        try {
            String raw = System.getenv("ELIYA_MIGRATION_TEST_TIMEOUT_MINUTES");
            return Duration.ofMinutes(raw == null || raw.isBlank() ? 30 : Math.max(1, Long.parseLong(raw.strip())));
        } catch (NumberFormatException invalid) { return Duration.ofMinutes(30); }
    }

    static CommandResult runShell(Path dir, String command, Duration timeout, BooleanSupplier cancelled) {
        boolean windows = System.getProperty("os.name", "").toLowerCase(Locale.ROOT).contains("win");
        List<String> argv = windows ? List.of("cmd.exe", "/c", command) : List.of("/bin/sh", "-c", command);
        Process process;
        try {
            process = new ProcessBuilder(argv).directory(dir.toFile()).redirectErrorStream(true).start();
            process.getOutputStream().close();
        } catch (IOException failed) {
            return new CommandResult(127, "Cannot start `" + command + "`: " + failed.getMessage(), false);
        }
        StringBuilder output = new StringBuilder();
        Thread reader = new Thread(() -> {
            try (var in = process.getInputStream()) {
                byte[] buffer = new byte[8192];
                int read;
                while ((read = in.read(buffer)) >= 0) {
                    synchronized (output) {
                        output.append(new String(buffer, 0, read, StandardCharsets.UTF_8));
                        if (output.length() > 400_000) output.delete(0, output.length() - 300_000);
                    }
                }
            } catch (IOException ignored) { }
        }, "migration-command-output");
        reader.setDaemon(true);
        reader.start();
        long deadline = System.nanoTime() + timeout.toNanos();
        boolean timedOut = false;
        try {
            while (!process.waitFor(200, TimeUnit.MILLISECONDS)) {
                if (cancelled != null && cancelled.getAsBoolean()) {
                    process.descendants().forEach(ProcessHandle::destroyForcibly);
                    process.destroyForcibly();
                    throw new AgentCancelledException("Agent run was cancelled during a migration command");
                }
                if (System.nanoTime() > deadline) {
                    timedOut = true;
                    process.descendants().forEach(ProcessHandle::destroyForcibly);
                    process.destroyForcibly();
                    break;
                }
            }
            reader.join(2000);
        } catch (InterruptedException interrupted) {
            process.destroyForcibly();
            Thread.currentThread().interrupt();
        }
        int exit;
        try { exit = timedOut ? 124 : process.exitValue(); } catch (IllegalThreadStateException stillRunning) { exit = 124; }
        synchronized (output) { return new CommandResult(exit, output.toString(), timedOut); }
    }

    // ------------------------------------------------------------------------------------------- ledger I/O

    static List<Item> readItems(Path dir) throws IOException {
        List<Item> items = new ArrayList<>();
        List<String> lines = Files.readAllLines(dir.resolve("items.csv"), StandardCharsets.UTF_8);
        for (int i = 1; i < lines.size(); i++) {
            List<String> cells = csv(lines.get(i));
            if (cells.size() < 8) continue;
            int residue;
            try { residue = Integer.parseInt(cells.get(4).strip()); } catch (NumberFormatException e) { residue = 0; }
            String status = cells.get(5).strip().toLowerCase(Locale.ROOT);
            items.add(new Item(cells.get(0), cells.get(1), cells.get(2), cells.get(3), residue, STATUSES.contains(status) ? status : "pending",
                    cells.get(6), cells.get(7)));
        }
        return items;
    }

    static void writeItems(Path dir, List<Item> items) throws IOException {
        StringBuilder out = new StringBuilder("id,module,path,kind,residue,status,evidence,note\n");
        for (Item item : items) {
            out.append(String.join(",", List.of(q(item.id), q(item.module), q(item.path), q(item.kind), Integer.toString(item.residue),
                    q(item.status), q(item.evidence), q(item.note)))).append('\n');
        }
        Path temp = dir.resolve("items.csv.tmp");
        Files.writeString(temp, out.toString(), StandardCharsets.UTF_8);
        Files.move(temp, dir.resolve("items.csv"), java.nio.file.StandardCopyOption.REPLACE_EXISTING);
        // Integrity: the completion check rejects a ledger edited outside the migration tools.
        Path specFile = dir.resolve("spec.json");
        if (Files.isRegularFile(specFile)) {
            JsonNode spec = JSON.readTree(Files.readString(specFile));
            if (spec instanceof ObjectNode object) {
                object.put("ledgerSha256", sha256(dir.resolve("items.csv")));
                Files.writeString(specFile, JSON.writerWithDefaultPrettyPrinter().writeValueAsString(object), StandardCharsets.UTF_8);
            }
        }
    }

    private static String q(String value) {
        String v = value == null ? "" : value.replace("\r", " ").replace("\n", " ");
        return v.contains(",") || v.contains("\"") ? "\"" + v.replace("\"", "\"\"") + "\"" : v;
    }

    static List<String> csv(String line) {
        List<String> out = new ArrayList<>();
        StringBuilder cell = new StringBuilder();
        boolean quoted = false;
        for (int i = 0; i < line.length(); i++) {
            char c = line.charAt(i);
            if (quoted) {
                if (c == '"' && i + 1 < line.length() && line.charAt(i + 1) == '"') { cell.append('"'); i++; }
                else if (c == '"') quoted = false;
                else cell.append(c);
            } else if (c == '"') quoted = true;
            else if (c == ',') { out.add(cell.toString()); cell.setLength(0); }
            else cell.append(c);
        }
        out.add(cell.toString());
        return out;
    }

    static Map<String, Long> counts(List<Item> items) {
        Map<String, Long> counts = new LinkedHashMap<>();
        for (String status : List.of("verified", "migrated", "pending", "failed", "blocked", "not_applicable")) counts.put(status, 0L);
        for (Item item : items) counts.merge(item.status, 1L, Long::sum);
        return counts;
    }

    static String countsLine(Map<String, Long> counts) {
        List<String> parts = new ArrayList<>();
        counts.forEach((k, v) -> { if (v > 0) parts.add(v + " " + k.replace('_', ' ')); });
        return parts.isEmpty() ? "no items" : String.join(", ", parts);
    }

    /** Failed items first (they need fixing), then migrated-but-unverified, then pending in ledger order. */
    static List<Item> nextBatch(List<Item> items) {
        List<Item> out = new ArrayList<>();
        for (String status : List.of("failed", "migrated", "pending"))
            for (Item item : items) if (item.status.equals(status) && out.size() < BATCH) out.add(item);
        return out;
    }

    private static void appendLog(Path dir, String line) {
        try {
            Files.writeString(dir.resolve("log.md"), "- " + Instant.now() + " " + line + System.lineSeparator(), StandardCharsets.UTF_8,
                    StandardOpenOption.CREATE, StandardOpenOption.APPEND);
        } catch (IOException ignored) { }
    }

    private static String plan(ObjectNode spec, MigrationPacks.Pack pack, List<Item> items, List<String> unmatchedScope, String target) {
        StringBuilder out = new StringBuilder("# Migration: ").append(spec.path("source").asText("?")).append(" → ").append(spec.path("target").asText()).append("\n\n");
        out.append("Created by Eliya on ").append(spec.path("created").asText()).append(". The ledger (`items.csv`) is the source of truth; ")
                .append("`baseline.json` holds the test result before the migration.\n\n");
        out.append("## Request\n\n").append(spec.path("request").asText("")).append("\n\n");
        out.append("## Workspace evidence\n\n");
        spec.path("facts").fields().forEachRemaining(e -> out.append("- ").append(e.getKey()).append(": ").append(e.getValue().asText()).append('\n'));
        out.append("\n## Scope\n\n").append(spec.path("scope").isEmpty() ? "Whole project." : String.join(", ", iterable(spec.path("scope"))))
                .append(unmatchedScope.isEmpty() ? "" : " (not found: " + String.join(", ", unmatchedScope) + ")").append("\n\n");
        out.append("## Verification\n\n`").append(spec.path("verifyCommand").asText("(none)")).append("` — an item is verified when no old API remains in it ")
                .append("and the tests show no new failures versus the baseline.\n\n");
        out.append("## Steps\n\n1. Baseline tests\n");
        String recipe = MigrationPacks.recipeFor(pack, target);
        if (!recipe.isBlank()) out.append("2. Optional automatic rewrite: `").append(recipe).append("`\n   ").append(pack.recipeNote()).append('\n');
        out.append(recipe.isBlank() ? "2" : "3").append(". Batches of ").append(BATCH).append(" in dependency order (build files → shared code → other code → tests)\n");
        out.append(recipe.isBlank() ? "3" : "4").append(". Verify every batch; fix failures; repeat\n");
        out.append(recipe.isBlank() ? "4" : "5").append(". Final full verification and report\n\n");
        out.append("## Work items by module\n\n");
        Map<String, Long> perModule = new TreeMap<>();
        for (Item item : items) perModule.merge(item.module, 1L, Long::sum);
        perModule.forEach((m, c) -> out.append("- ").append(m).append(": ").append(c).append('\n'));
        if (pack != null && !pack.notes().isBlank()) out.append("\n## Notes\n\n").append(pack.notes()).append('\n');
        return out.toString();
    }

    private static String mapping(MigrationPacks.Pack pack, String source, String target) {
        StringBuilder out = new StringBuilder("# Old → new rules: ").append(source.isBlank() ? "?" : source).append(" → ").append(target).append("\n\n");
        out.append("Eliya applies these rules and adds new ones it discovers. Edit freely — this file guides every batch.\n\n");
        out.append("| Old | New |\n|---|---|\n");
        if (pack != null) for (String[] row : pack.mapping()) out.append("| ").append(row[0].replace("|", "\\|")).append(" | ").append(row[1].replace("|", "\\|")).append(" |\n");
        else out.append("| (add rules) | |\n");
        return out.toString();
    }

    private static List<String> iterable(JsonNode array) { List<String> out = new ArrayList<>(); array.forEach(n -> out.add(n.asText())); return out; }

    private static String firstErrorLine(String output) {
        for (String line : output.split("\\R")) {
            String l = line.strip();
            if (l.matches("(?i).*\\b(?:error|exception|failed|failure|cannot find symbol|traceback)\\b.*")) return clip(l, 200);
        }
        return clip(tail(output, 200), 200);
    }

    static String slug(String raw) {
        String s = raw.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9.]+", "-").replaceAll("^-+|-+$", "").replaceAll("-{2,}", "-");
        if (s.isBlank()) s = "migration";
        if (!s.matches("[a-z0-9].*")) s = "m-" + s;
        return s.length() > 80 ? s.substring(0, 80) : s;
    }

    private static String tail(String value, int max) {
        String v = value == null ? "" : value;
        return v.length() <= max ? v : "…" + v.substring(v.length() - max);
    }

    private static String clip(String value, int max) {
        String v = value == null ? "" : value.replaceAll("\\s+", " ").strip();
        return v.length() <= max ? v : v.substring(0, max) + "…";
    }

    private static String text(JsonNode args, String field) { return args == null ? "" : args.path(field).asText("").strip(); }

    private static List<String> list(JsonNode args, String field) {
        List<String> out = new ArrayList<>();
        if (args == null) return out;
        JsonNode node = args.path(field);
        if (node.isArray()) node.forEach(n -> { if (!n.asText("").isBlank()) out.add(n.asText().strip()); });
        else if (node.isTextual() && !node.asText().isBlank()) for (String part : node.asText().split("\\s*,\\s*")) if (!part.isBlank()) out.add(part.strip());
        return out;
    }

    private static String firstNonBlank(String a, String b) { return a != null && !a.isBlank() ? a : b == null ? "" : b; }
}
