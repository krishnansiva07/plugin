package com.llmart.llm.cli.tui;

import java.util.List;

/** What the terminal chat needs from a running Eliya server. The HTTP implementation talks to the CLI bridge. */
public interface TuiBackend {

    /** Streamed events of one Analyse/Agent run, in arrival order. Called from the run thread. */
    interface Listener {
        void token(String text);
        void runId(String runId);
        void step(String tool, String status, String detail, String step, String approvalId, String approvalType);
        void question(String id, String reason, List<String> choices);
        void changes(String count);
        void status(String phase, String detail);
        void error(String message);
        void stopped(String message);
        void done(String content);
    }

    record Status(String workspace, String mode, boolean modelConfigured, String model, String chatModel,
                  String hint, String url, String sessionId) { }

    record RunResult(String status, String verification, String runId) { }

    /** ELIYA184: what the server did with input typed during a run (kind: refine, stop, skip, status). */
    record InputResult(String id, String status, String kind, String reply) { }

    /** ELIYA184: an Agent task still running in this workspace (possibly left by a closed terminal). */
    record ActiveRun(String runId, String status, String activity, String task, boolean terminalOpen) { }

    /** ELIYA184: one available skill. */
    record SkillInfo(String name, String description, List<String> aliases, String source) { }

    /** Blocks until the run's stream ends. */
    void run(String mode, String prompt, Listener listener) throws Exception;

    void approve(String runId, String approvalId, String decision) throws Exception;

    void answer(String runId, String questionId, String choice, String detail) throws Exception;

    /** Returns true when a run was actually asked to stop. */
    boolean cancel() throws Exception;

    /** Add text to the running Agent task (delivered after its current action). Returns the input id. */
    String addInput(String runId, String text) throws Exception;

    /** Like {@link #addInput} but reports how the server treated it (stop / skip / status are acted on at once). */
    default InputResult submitInput(String runId, String text) throws Exception {
        return new InputResult(addInput(runId, text), "pending", "refine", "");
    }

    /** An Agent task still running for this terminal's workspace, or null. */
    default ActiveRun activeRun() throws Exception { return null; }

    /** Skills available in this workspace (built-in, user and project). */
    default List<SkillInfo> skills() throws Exception { return List.of(); }

    /** This workspace's project memory: newest notes, or matches for {@code query}. */
    default String memory(String query) throws Exception { return "Project memory is not available."; }

    /** Delete this workspace's project memory; returns the number of notes removed. */
    default int clearMemory() throws Exception { return 0; }

    /** Select Analyse/Agent; returns the workspace the server uses for this session. */
    String mode(String mode) throws Exception;

    /** Map a project folder; {@code fresh} starts a new conversation. Returns the selected workspace. */
    String activate(String workspace, boolean fresh) throws Exception;

    Status status() throws Exception;

    RunResult latestResult() throws Exception;

    /** Tell open browser tabs that the conversation changed. */
    void refresh();
}
