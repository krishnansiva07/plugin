package com.llmart.llm.service;

import java.util.List;

/** The system message that tells the executor exactly what a linked recovery run inherits. */
final class AgentRecoveryContext {
    private AgentRecoveryContext() { }

    static String prompt(AgentRunService.RecoverySeed seed, int keptSteps) {
        StringBuilder out = new StringBuilder("LINKED RECOVERY OF RUN ").append(seed.priorRunId())
                .append(" (previous status: ").append(seed.priorStatus()).append(").\n")
                .append("This run CONTINUES that task; it is not a new task and not a blind replay.\n\n");
        if (!seed.originalTaskContract().isBlank())
            out.append("ORIGINAL TASK (authoritative):\n").append(clip(seed.originalTaskContract(), 4_000)).append("\n\n");
        out.append("WHY THE PREVIOUS RUN STOPPED:\n").append(seed.stoppingReason().isBlank() ? "(not recorded)" : seed.stoppingReason()).append("\n\n");
        if (keptSteps > 0) {
            out.append("ALREADY COMPLETED (do NOT redo; their side effects are in the workspace):\n");
            for (int i = 0; i < keptSteps && i < seed.plan().size(); i++) {
                AgentRunService.PlanItem item = seed.plan().get(i);
                out.append(i + 1).append(". ").append(clip(item.text().split("\\R", 2)[0], 240)).append('\n');
                List<String> evidence = seed.evidence().get(item.index());
                if (evidence != null) for (String line : evidence.subList(Math.max(0, evidence.size() - 3), evidence.size()))
                    out.append("   evidence: ").append(clip(line, 240)).append('\n');
            }
            out.append('\n');
        }
        if (!seed.touchedPaths().isEmpty()) {
            out.append("FILES CHANGED BY THE PREVIOUS RUN (re-read before editing; the user may have changed them since):\n");
            seed.touchedPaths().stream().limit(40).forEach(path -> out.append("- ").append(path).append('\n'));
            out.append('\n');
        }
        if (!seed.lastVerification().isBlank())
            out.append("LAST VERIFICATION OF THE PREVIOUS RUN (stale; must be re-run):\n").append(clip(seed.lastVerification(), 800)).append("\n\n");
        out.append("RULES: start at the first unfinished step; first address the stopping reason with a DIFFERENT approach than the one that failed; ")
                .append("do not repeat destructive operations; earlier verification does not count. The final step must verify the CURRENT workspace.");
        return out.toString();
    }

    private static String clip(String value, int max) {
        String text = value == null ? "" : value.strip();
        return text.length() <= max ? text : text.substring(0, max) + " …";
    }
}
