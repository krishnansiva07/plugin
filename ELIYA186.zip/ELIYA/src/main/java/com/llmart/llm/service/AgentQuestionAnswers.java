package com.llmart.llm.service;

import java.util.List;
import java.util.Locale;
import java.util.Optional;

/**
 * Interprets answers to Agent questions consistently.
 *
 * <p>Some UI paths submitted a clicked option as {@code choice="Custom", detail="<option text>"}, and the
 * backend compared answers with exact strings, so clicking "Retry after fixing provider" produced
 * "User selected: Custom\nDetails: Retry after fixing provider" and the run stopped instead of retrying.
 * All answer checks now go through this class.</p>
 */
public final class AgentQuestionAnswers {
    private AgentQuestionAnswers() { }

    /** Normalised form for comparing an option with typed text: case, spacing and trailing punctuation ignored. */
    static String normalize(String value) {
        return value == null ? "" : value.strip().replaceAll("\\s+", " ").replaceAll("[.!?]+$", "").toLowerCase(Locale.ROOT);
    }

    /** The offered option that free text exactly corresponds to, if any. */
    public static Optional<String> matchOption(String text, List<String> options) {
        String wanted = normalize(text);
        if (wanted.isEmpty() || options == null) return Optional.empty();
        for (String option : options) if (normalize(option).equals(wanted)) return Optional.of(option);
        return Optional.empty();
    }

    /** The option the user chose, from a recorded answer ("User selected: X" or a Custom detail equal to an option). */
    public static String selectedOption(String answer) {
        if (answer == null) return "";
        String text = answer.strip();
        if (!text.startsWith("User selected:")) return "";
        String rest = text.substring("User selected:".length()).strip();
        if (rest.startsWith("Custom")) {
            int details = rest.indexOf("Details:");
            return details < 0 ? "" : rest.substring(details + "Details:".length()).strip();
        }
        int newline = rest.indexOf('\n');
        return newline < 0 ? rest : rest.substring(0, newline).strip();
    }

    /** True when the recorded answer selects {@code option} (exact choice, or typed text equal to it). */
    public static boolean selects(String answer, String option) {
        return !normalize(option).isEmpty() && normalize(selectedOption(answer)).equals(normalize(option));
    }

    /** Explicit short consent typed instead of clicking ("retry", "yes", "continue"...). Fails closed. */
    public static boolean shortConsent(String answer) {
        String chosen = normalize(selectedOption(answer));
        return List.of("yes", "y", "retry", "try again", "continue", "proceed", "ok").contains(chosen);
    }
}
