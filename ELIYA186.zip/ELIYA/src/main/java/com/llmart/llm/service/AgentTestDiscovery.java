package com.llmart.llm.service;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.regex.*;
import java.util.stream.Stream;

/**
 * Bounded, read-only test-run preflight.  Facts are derived from the selected
 * workspace rather than guessed by the model.  Never reads .env, credentials,
 * secret values or remote endpoints; it reports paths and variable *names* only.
 */
final class AgentTestDiscovery {
    private static final Set<String> OMIT = Set.of("node_modules", "target", "build", "dist", "out", ".git",
            ".gradle", ".idea", ".cache", ".next", "venv", ".venv", "__pycache__", "coverage", "test-results");
    private static final Set<String> MARKERS = Set.of("pom.xml", "build.gradle", "build.gradle.kts", "package.json",
            "playwright.config.ts", "playwright.config.js", "playwright.config.mjs", "playwright.config.mts",
            "testng.xml", "junit-platform.properties", "cucumber.properties", "pytest.ini", "pyproject.toml",
            "gradlew", "gradlew.bat", "mvnw", "mvnw.cmd", "package-lock.json", "pnpm-lock.yaml", "yarn.lock");
    private static final Pattern VARIABLE = Pattern.compile(
            "(?:System\\.getenv\\s*\\(\\s*[\\\"']([A-Za-z_][A-Za-z0-9_]*)[\\\"']|" +
            "process\\.env\\.([A-Za-z_][A-Za-z0-9_]*)|\\$\\{(?:env:|ENV:)?([A-Za-z_][A-Za-z0-9_]*)\\})");
    private static final Pattern TAGS = Pattern.compile("(?i)(cucumber\\.filter\\.tags|cucumberOptions|tags\\s*=|suiteXmlFiles|testng|junit|playwright|selenium)");

    private AgentTestDiscovery() { }

    static String inspect(Path workspace, String cwd) throws IOException {
        if (workspace == null || !Files.isDirectory(workspace))
            throw new IOException("The mapped workspace does not exist or is not a directory");
        Path root = workspace.toRealPath();
        String requested = cwd == null ? "" : cwd.strip().replace('\\', '/');
        if (requested.startsWith("/") || requested.matches("(?i)^[a-z]:.*"))
            throw new SecurityException("Test module must be relative to the mapped workspace");
        Path module = root.resolve(requested.isBlank() ? "." : requested).normalize();
        if (!module.startsWith(root) || !Files.isDirectory(module) || !module.toRealPath().startsWith(root))
            throw new SecurityException("Test module is unavailable or outside the mapped workspace");
        StringBuilder answer = new StringBuilder("TEST WORKSPACE PREFLIGHT (read-only; no tests executed)\n");
        answer.append("module=").append(root.relativize(module).toString().isEmpty() ? "." : root.relativize(module)).append('\n');
        boolean maven = Files.isRegularFile(module.resolve("pom.xml"));
        boolean gradle = Files.isRegularFile(module.resolve("build.gradle")) || Files.isRegularFile(module.resolve("build.gradle.kts"));
        boolean node = Files.isRegularFile(module.resolve("package.json"));
        boolean playwright = Stream.of("playwright.config.ts", "playwright.config.js", "playwright.config.mjs", "playwright.config.mts")
                .anyMatch(name -> Files.isRegularFile(module.resolve(name)));
        List<String> recommendations = new ArrayList<>();
        if (maven) {
            String pom = boundedRead(module.resolve("pom.xml"));
            answer.append("runner=Maven");
            if (pom.contains("testng")) answer.append(" + TestNG dependency/config");
            if (pom.toLowerCase(Locale.ROOT).contains("cucumber")) answer.append(" + Cucumber dependency/config");
            answer.append('\n');
            if (pom.matches("(?s).*<maven\\.test\\.skip>\\s*true\\s*</maven\\.test\\.skip>.*") ||
                    pom.matches("(?s).*<skipTests>\\s*true\\s*</skipTests>.*"))
                answer.append("risk=POM disables tests by default; test tool must override maven.test.skip and skipTests\n");
            recommendations.add((Files.isRegularFile(module.resolve("mvnw")) ? "./mvnw" :
                    Files.isRegularFile(module.resolve("mvnw.cmd")) ? "mvnw.cmd" : "mvn") +
                    " -Dmaven.test.skip=false -DskipTests=false -DfailIfNoTests=true test");
        }
        if (gradle) {
            answer.append("runner=Gradle\n");
            recommendations.add((Files.isRegularFile(module.resolve("gradlew")) ? "./gradlew" :
                    Files.isRegularFile(module.resolve("gradlew.bat")) ? "gradlew.bat" : "gradle") + " test");
        }
        if (node) {
            String pkg = boundedRead(module.resolve("package.json"));
            answer.append("runner=Node package manager");
            if (playwright || pkg.contains("@playwright/test")) answer.append(" + Playwright");
            answer.append('\n');
            String manager = Files.isRegularFile(module.resolve("pnpm-lock.yaml")) ? "pnpm" :
                    Files.isRegularFile(module.resolve("yarn.lock")) ? "yarn" : "npm";
            boolean testScript = Pattern.compile("[\\\"']test[\\\"']\\s*:").matcher(pkg).find();
            if (testScript) recommendations.add(manager + " run test");
            else if (playwright) recommendations.add("npx --no-install playwright test");
            else answer.append("risk=No test script in package.json; inspect scripts and test files\n");
            if (!Files.isDirectory(module.resolve("node_modules")))
                answer.append("dependency_check=node_modules not detected; inspect lockfile before authorized install\n");
        }
        if (Files.isRegularFile(module.resolve("pytest.ini")) || Files.isRegularFile(module.resolve("pyproject.toml"))) {
            answer.append("runner_candidate=pytest\n");
            recommendations.add("python -m pytest -q");
        }
        if (!maven && !gradle && !node && recommendations.isEmpty())
            answer.append("runner=not detected in chosen module; inspect discovered nested modules below\n");
        if (!recommendations.isEmpty()) answer.append("candidate_commands (use existing test tool where possible):\n - ")
                .append(String.join("\n - ", recommendations)).append('\n');

        List<String> descriptors = new ArrayList<>();
        List<String> entries = new ArrayList<>();
        LinkedHashSet<String> varNames = new LinkedHashSet<>();
        List<String> configHints = new ArrayList<>();
        // Prune large generated trees before descending; a 100k-file workspace must
        // not require scanning all of node_modules/target just to find test settings.
        final int[] sampled = {0};
        Files.walkFileTree(module, EnumSet.noneOf(FileVisitOption.class), 6, new SimpleFileVisitor<>() {
            @Override public FileVisitResult preVisitDirectory(Path dir, java.nio.file.attribute.BasicFileAttributes attrs) {
                return !dir.equals(module) && OMIT.contains(dir.getFileName().toString())
                        ? FileVisitResult.SKIP_SUBTREE : FileVisitResult.CONTINUE;
            }
            @Override public FileVisitResult visitFileFailed(Path file, IOException error) {
                return FileVisitResult.CONTINUE; // show discovered evidence without stalling on an unreadable file
            }
            @Override public FileVisitResult visitFile(Path f, java.nio.file.attribute.BasicFileAttributes attrs) {
                if (!attrs.isRegularFile() || sampled[0] >= 5000) return sampled[0] >= 5000
                        ? FileVisitResult.TERMINATE : FileVisitResult.CONTINUE;
                sampled[0]++;
                String path = module.relativize(f).toString().replace('\\', '/');
                String name = f.getFileName().toString();
                if (MARKERS.contains(name) && descriptors.size() < 35) descriptors.add(path);
                boolean runner = name.matches("(?i).*(Test|Tests|Spec|Runner)\\.(java|ts|js|py)")
                        || name.endsWith(".feature") || name.equals("testng.xml");
                if (runner && entries.size() < 30) entries.add(path);
                // Never inspect .env, certificates, keystores or passwords.
                boolean safeConfig = name.matches("(?i)(pom\\.xml|build\\.gradle(\\.kts)?|package\\.json|" +
                        "playwright\\.config\\..+|testng\\.xml|cucumber\\.properties|" +
                        "junit-platform\\.properties|application(-[A-Za-z0-9_-]+)?\\.(properties|ya?ml)|" +
                        "settings\\.gradle(\\.kts)?|.*Runner\\.java|.*Hooks\\.java|.*\\.env\\.example)");
                if (!safeConfig || Files.isSymbolicLink(f)) return FileVisitResult.CONTINUE;
                String content = boundedRead(f);
                Matcher matcher = VARIABLE.matcher(content);
                while (matcher.find() && varNames.size() < 36)
                    for (int g = 1; g <= 3; g++) if (matcher.group(g) != null) varNames.add(matcher.group(g));
                if (TAGS.matcher(content).find() && configHints.size() < 18) configHints.add(path);
                return FileVisitResult.CONTINUE;
            }
        });
        if (sampled[0] >= 5000) answer.append("inventory_note=bounded at 5000 sampled files; target module cwd for deeper analysis\n");
        answer.append("runner_and_build_files=").append(descriptors.isEmpty() ? "[none]" : String.join(", ", descriptors)).append('\n');
        answer.append("test_entrypoints=").append(entries.isEmpty() ? "[none discovered]" : String.join(", ", entries)).append('\n');
        answer.append("files_with_runner_or_tag_clues=").append(configHints.isEmpty() ? "[none]" : String.join(", ", configHints)).append('\n');
        answer.append("referenced_environment_variable_names_only=")
                .append(varNames.isEmpty() ? "[none in sampled config files]" : String.join(", ", varNames)).append('\n');
        answer.append("NEXT: read the listed suite, runner, browser settings and CI definitions; use test to run actual tests, ")
                .append("inspect output/test reports, diagnose/fix and rerun. Ask only for unresolved secrets, external infrastructure or approval. ")
                .append("Do not claim passing tests without executed-test evidence.\n");
        return answer.toString();
    }

    private static String boundedRead(Path file) {
        try {
            if (Files.isSymbolicLink(file) || !Files.isRegularFile(file)) return "";
            byte[] bytes;
            try (var stream = Files.newInputStream(file)) { bytes = stream.readNBytes(65_536); }
            return new String(bytes, StandardCharsets.UTF_8);
        } catch (IOException ex) { return ""; }
    }
}
