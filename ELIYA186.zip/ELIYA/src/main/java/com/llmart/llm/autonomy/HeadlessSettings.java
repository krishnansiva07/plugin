package com.llmart.llm.autonomy;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.llmart.llm.dto.ChatSettings;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Derives unattended-run settings from the user's settings. Explicit "deny" permissions are never relaxed. */
public final class HeadlessSettings {
    private static final ObjectMapper JSON = new ObjectMapper()
            .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

    private HeadlessSettings() { }

    @SuppressWarnings("unchecked")
    public static ChatSettings from(ChatSettings base, boolean isolated) {
        Map<String,Object> values = JSON.convertValue(base, LinkedHashMap.class);
        values.put("agentAutoApprove", true);
        values.put("agentPlanApproval", false);
        // In an isolated worktree every change is reviewable on a branch; in place, deletions stay protected
        // (and any deletion prompt is denied automatically because nobody is there to answer).
        values.put("agentConfirmFileDeletion", !isolated);
        for (String key : List.of("agentEditPermission", "agentShellPermission", "agentReviewPermission",
                "agentTaskPermission", "agentLspPermission")) {
            if (!"deny".equalsIgnoreCase(String.valueOf(values.get(key)))) values.put(key, "allow");
        }
        if (Boolean.FALSE.equals(values.get("agentAllowCommands"))) values.put("agentShellPermission", "deny");
        // MCP can reach remote systems: keep the user's explicit choice, default to deny when unset.
        if (values.get("agentMcpPermission") == null) values.put("agentMcpPermission", "deny");
        return JSON.convertValue(values, ChatSettings.class);
    }
}
