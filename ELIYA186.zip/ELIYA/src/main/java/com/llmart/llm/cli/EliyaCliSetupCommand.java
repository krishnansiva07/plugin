package com.llmart.llm.cli;

import java.io.Console;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Scanner;

/**
 * {@code eliya setup}: save provider, model and API key for terminal use (no browser needed).
 * {@code eliya setup --show} prints the resolved configuration without the key.
 */
final class EliyaCliSetupCommand {
    private EliyaCliSetupCommand() { }

    static void run(String[] args) throws Exception {
        Path file = EliyaCliModelConfig.defaultFile(System.getenv());
        EliyaCliModelConfig.Resolved current = EliyaCliModelConfig.load();
        boolean show = args.length > 1 && ("--show".equals(args[1]) || "show".equals(args[1]));
        if (show) {
            System.out.println("Config file: " + file);
            System.out.println("Source: " + current.source());
            System.out.println("Base URL: " + current.settings().getOrDefault("baseUrl", "(not set)"));
            System.out.println("Model: " + current.settings().getOrDefault("model", "(not set)"));
            System.out.println("Analyse model: " + current.settings().getOrDefault("chatModel", "(same as model)"));
            System.out.println("API key: " + (current.apiKey() == null || current.apiKey().isBlank() ? "(not set)" : "set"));
            System.out.println("Ready: " + current.complete());
            return;
        }
        Console console = System.console();
        Scanner scanner = new Scanner(System.in, StandardCharsets.UTF_8);
        System.out.println("ELIYA terminal setup. Values are saved to " + file + " (owner-only permissions).");
        System.out.println("Press Enter to keep the value shown in brackets.");
        Map<String,String> values = new LinkedHashMap<>();
        values.put("base.url", ask(scanner, "OpenAI-compatible Base URL", str(current.settings().get("baseUrl"), "https://api.openai.com/v1")));
        values.put("model", ask(scanner, "Agent model", str(current.settings().get("model"), "")));
        values.put("chat.model", ask(scanner, "Analyse model", str(current.settings().get("chatModel"), values.get("model"))));
        String key;
        if (console != null) {
            char[] secret = console.readPassword("API key%s: ", current.apiKey() == null ? "" : " [keep existing]");
            key = secret == null ? "" : new String(secret).strip();
        } else {
            System.out.print("API key (input is visible; prefer ELIYA_API_KEY in non-interactive shells): ");
            key = scanner.hasNextLine() ? scanner.nextLine().strip() : "";
        }
        if (!key.isBlank()) values.put("api.key", key);
        values.put("max.tokens", ask(scanner, "Max output tokens (0 = provider default)", str(current.settings().get("maxTokens"), "0")));
        EliyaCliModelConfig.write(file, values);
        EliyaCliModelConfig.Resolved saved = EliyaCliModelConfig.load();
        System.out.println(saved.complete()
                ? "Saved. Terminal commands are ready: eliya analyse \"...\" / eliya agent \"...\""
                : "Saved, but Base URL, model and API key are all required before AI commands can run.");
    }

    private static String ask(Scanner scanner, String label, String fallback) {
        System.out.print(label + (fallback == null || fallback.isBlank() ? "" : " [" + fallback + "]") + ": ");
        String value = scanner.hasNextLine() ? scanner.nextLine().strip() : "";
        return value.isBlank() ? fallback : value;
    }

    private static String str(Object value, String fallback) {
        return value == null || String.valueOf(value).isBlank() ? fallback : String.valueOf(value);
    }
}
