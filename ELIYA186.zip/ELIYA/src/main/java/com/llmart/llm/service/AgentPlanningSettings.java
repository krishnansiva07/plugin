package com.llmart.llm.service;

/**
 * Planning-stage switches. All defaults favour plan quality; each can be turned off with a JVM property
 * when token cost matters more than plan specificity.
 */
final class AgentPlanningSettings {
    private AgentPlanningSettings() { }

    /** One corrective planner round when the first draft is malformed, a placeholder, or names nothing concrete. */
    static boolean correctiveRoundEnabled() {
        return !"false".equalsIgnoreCase(System.getProperty("eliya.planning.correctiveRound", "true"));
    }

    /**
     * Run the read-only analysis role before planning for multi-concern work. It was implemented but never
     * called; for complex/large tasks it gives the planner a fact/assumption summary of the evidence.
     */
    static boolean analysisStageEnabled(String profileLevel, boolean planPreview) {
        String mode = System.getProperty("eliya.planning.analysisStage", "auto").trim().toLowerCase(java.util.Locale.ROOT);
        if (mode.equals("false") || mode.equals("off")) return false;
        if (mode.equals("true") || mode.equals("always")) return true;
        return "complex".equals(profileLevel) || "large".equals(profileLevel) || (planPreview && "normal".equals(profileLevel));
    }

    /** Candidate request terms considered for evidence search. */
    static int evidenceSearchTerms() {
        return bounded("eliya.planning.searchTerms", 8, 1, 30);
    }

    /** Stop after this many terms produced matches (keeps the planning prompt bounded). */
    static int evidenceSearchHits() {
        return bounded("eliya.planning.searchHits", 4, 1, 20);
    }

    private static int bounded(String property, int fallback, int min, int max) {
        try {
            return Math.max(min, Math.min(max, Integer.parseInt(System.getProperty(property, Integer.toString(fallback)).trim())));
        } catch (NumberFormatException invalid) {
            return fallback;
        }
    }
}
