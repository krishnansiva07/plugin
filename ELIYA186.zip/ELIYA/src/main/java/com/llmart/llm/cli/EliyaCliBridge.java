package com.llmart.llm.cli;

import com.llmart.llm.dto.ProjectDto;
import com.llmart.llm.dto.ChatRequest;
import com.llmart.llm.dto.ChatSettings;
import com.llmart.llm.dto.MessageDto;
import com.llmart.llm.service.ChatService;
import com.llmart.llm.service.AgentRunService;
import com.llmart.llm.service.AgentQuestionService;
import com.llmart.llm.service.AgentApprovalService;
import org.springframework.http.MediaType;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;
import org.springframework.web.server.ResponseStatusException;
import com.llmart.llm.service.ConversationService;
import com.llmart.llm.service.LocalProjectIndexService;
import com.llmart.llm.service.ProjectService;
import jakarta.annotation.PreDestroy;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.boot.web.servlet.context.ServletWebServerApplicationContext;
import org.springframework.context.event.EventListener;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.awt.Desktop;
import java.awt.GraphicsEnvironment;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.nio.file.attribute.PosixFilePermission;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.*;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

/** Loopback-only CLI-to-browser bridge. CLI mutations require a per-process random bearer secret.
 * The ordinary browser polls a read-only selection revision to adopt terminal workspace changes.
 */
@RestController
@RequestMapping("/api/cli")
public class EliyaCliBridge {
    /** @param fresh true to start a new terminal conversation instead of resuming the workspace's last one */
    public record ActivationRequest(String workspace, String sessionId, Boolean fresh) {
        public ActivationRequest(String workspace) { this(workspace, null, null); }
        public ActivationRequest(String workspace, String sessionId) { this(workspace, sessionId, null); }
    }
    /** Model settings supplied by the terminal (environment / ~/.eliya/config.properties). Held in memory only. */
    public record TerminalSettings(String sessionId, String apiKey, Map<String,Object> settings) { }
    public record Selection(String version, ProjectDto project, String conversationId, String mode) { }
    public record BrowserSettings(String apiKey, ChatSettings settings) { }
    public record TerminalPrompt(String mode, String prompt, String workspace, String sessionId) {
        public TerminalPrompt(String mode, String prompt, String workspace) { this(mode, prompt, workspace, null); }
    }
    public record ModeRequest(String mode, String workspace, String sessionId) {
        public ModeRequest(String mode, String workspace) { this(mode, workspace, null); }
    }
    public record ApprovalDecision(String runId, String approvalId, String decision) { }
    /** `eliya run`: unattended task. Budgets of 0 use the headless defaults. */
    public record AutonomousPrompt(String task, String workspace, String sessionId, Boolean inPlace,
                                   Long maxMinutes, Long maxTurns, Long maxTokens, Boolean keepWorktree) { }
    public record QuestionAnswer(String runId, String questionId, String choice, String detail) { }

    private final ProjectService projects;
    private final ConversationService conversations;
    private final LocalProjectIndexService indexJobs;
    private final ChatService chat;
    private final AgentRunService agentRuns;
    private final AgentQuestionService questions;
    private final AgentApprovalService approvals;
    private final com.llmart.llm.autonomy.AutonomousRunService autonomous;
    // Each CLI process owns its selection and conversation; browser selection remains independent.
    private final ConcurrentHashMap<String, Selection> terminalSelections = new ConcurrentHashMap<>();
    private final Map<String, String> conversationByWorkspace = new java.util.concurrent.ConcurrentHashMap<>();
    private volatile BrowserSettings browserSettings;
    // Per-terminal-session settings pushed by the launcher, and a server-side fallback from env/config file.
    private final ConcurrentHashMap<String, BrowserSettings> terminalSettings = new ConcurrentHashMap<>();
    private final TerminalConversationStore terminalConversations = TerminalConversationStore.inDataDirectory();
    private static final com.fasterxml.jackson.databind.ObjectMapper SETTINGS_JSON = new com.fasterxml.jackson.databind.ObjectMapper()
            .configure(com.fasterxml.jackson.databind.DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
    // Prevent parallel writes to the same workspace (sessions remain independently addressable).
    // ELIYA184: the lock records who holds it and which run, so a conflict can say what is running, a finished or
    // vanished run never blocks the workspace, and a new terminal can stop a task left running by a closed one.
    private final ConcurrentHashMap<String,WorkspaceLock> activeAgentWorkspaces = new ConcurrentHashMap<>();

    private static final class WorkspaceLock {
        final String owner;
        final String conversationId;
        final java.time.Instant startedAt = java.time.Instant.now();
        final String prompt;
        final AtomicBoolean streamOpen;
        volatile String runId = "";
        WorkspaceLock(String owner, String conversationId, String prompt, AtomicBoolean streamOpen) {
            this.owner = owner; this.conversationId = conversationId; this.streamOpen = streamOpen;
            String line = prompt == null ? "" : prompt.replaceAll("\\s+", " ").strip();
            this.prompt = line.length() > 90 ? line.substring(0, 89) + "…" : line;
        }
    }
    @org.springframework.beans.factory.annotation.Autowired(required = false)
    private com.llmart.llm.service.ProjectMemoryService projectMemory;
    private final ExecutorService terminalWorkers = Executors.newFixedThreadPool(8, task -> {
        Thread thread = new Thread(task, "eliya-cli-run"); thread.setDaemon(true); return thread;
    });
    private final ServletWebServerApplicationContext webServer;
    private final String token;
    private final String instance = UUID.randomUUID().toString();
    private final AtomicLong revision = new AtomicLong();
    private volatile Selection current = new Selection("", null, null, "analyse");
    private volatile boolean published;
    private volatile EliyaCliAutoSetup.SetupResult cliSetup =
            new EliyaCliAutoSetup.SetupResult(false, null, "CLI setup not started");

    public EliyaCliBridge(ProjectService projects, ConversationService conversations,
                          LocalProjectIndexService indexJobs, ServletWebServerApplicationContext webServer,
                          ChatService chat, AgentRunService agentRuns, AgentQuestionService questions, AgentApprovalService approvals,
                          com.llmart.llm.autonomy.AutonomousRunService autonomous) {
        this.projects = projects;
        this.conversations = conversations;
        this.indexJobs = indexJobs;
        this.webServer = webServer;
        this.chat = chat;
        this.agentRuns = agentRuns;
        this.questions = questions;
        this.approvals = approvals;
        this.autonomous = autonomous;
        // Scheduled / inbox runs use the same configuration the terminal would: browser-synced or server config.
        autonomous.setDefaultModel(() -> {
            BrowserSettings effective = effectiveSettings(null);
            return effective == null ? null
                    : new com.llmart.llm.autonomy.AutonomousRunService.ModelAccess(effective.apiKey(), effective.settings());
        });
        byte[] random = new byte[32];
        new SecureRandom().nextBytes(random);
        this.token = HexFormat.of().formatHex(random);
    }

    public static Path bridgeFile() {
        String data = System.getProperty("app.data-dir");
        if (data == null || data.isBlank()) throw new IllegalStateException("Eliya data path not initialized");
        return Path.of(data).resolve("eliya-cli-bridge.txt");
    }

    @EventListener(ApplicationReadyEvent.class)
    public void ready() {
        int port = webServer.getWebServer().getPort();
        try {
            Path target = bridgeFile();
            Files.createDirectories(target.getParent());
            Path tmp = Files.createTempFile(target.getParent(), ".eliya-cli-", ".tmp");
            restrictFile(tmp);
            Files.writeString(tmp, port + "\n" + token + "\n", StandardCharsets.UTF_8,
                    StandardOpenOption.TRUNCATE_EXISTING);
            try { Files.move(tmp, target, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING); }
            catch (AtomicMoveNotSupportedException ex) { Files.move(tmp, target, StandardCopyOption.REPLACE_EXISTING); }
            restrictFile(target);
            published = true;
        } catch (Exception ex) {
            System.err.println("ELIYA CLI bridge unavailable: " + ex.getMessage());
        }

        // Per-OS CLI setup is part of JAR startup, not a separate PowerShell/script installer.
        // It is safe to skip when running from IDE classes and never blocks browser startup.
        cliSetup = EliyaCliAutoSetup.onJarStartup(com.llmart.llm.LlmApplication.class);
        System.out.println("ELIYA CLI: " + cliSetup.message());

        String workspace = System.getProperty("eliya.startup.workspace", "").trim();
        if (workspace.isEmpty()) {
            // `java -jar` may be invoked from an IDE project; don't index arbitrary home/drive folders.
            Path detected = ProjectDirectoryLocator.detectedProject(Path.of(""));
            if (detected != null) workspace = detected.toString();
        }
        if (!workspace.isEmpty()) {
            try { activateWorkspace(workspace); }
            catch (Exception ex) { System.err.println("ELIYA workspace was not mapped: " + ex.getMessage()); }
        }
        String url = "http://localhost:" + port + "/";
        System.out.println("ELIYA ready: " + url);
        if (!"false".equalsIgnoreCase(System.getProperty("eliya.browser.enabled", "true")) &&
                !"true".equalsIgnoreCase(System.getenv("ELIYA_NO_BROWSER"))) openBrowser(url);
    }

    private synchronized ProjectDto activateWorkspace(String workspace) {
        if (workspace == null) return current.project(); // `eliya open` must preserve selection.
        Path path = Path.of(workspace).toAbsolutePath().normalize();
        String key = path.toString();
        String conversationId = conversationByWorkspace.computeIfAbsent(key, ignored -> {
            // Reopen the same workspace conversation after an application restart,
            // but never reuse a deleted conversation ID.
            Set<String> existing = new HashSet<>();
            conversations.list().forEach(conversation -> existing.add(conversation.id()));
            return projects.mappedLocalWorkspaces().stream()
                    .filter(project -> key.equals(project.localPath()))
                    .map(ProjectDto::conversationId)
                    .filter(existing::contains)
                    .findFirst()
                    .orElseGet(() -> conversations.create().getId());
        });
        ProjectDto project = projects.createLocal(conversationId, key, null);
        indexJobs.request(project, false);
        current = new Selection(instance + ":" + revision.incrementAndGet(), project, conversationId, "analyse");
        System.out.println("ELIYA workspace: " + project.localPath() + " (background indexing enabled)");
        return project;
    }

    /** A CLI session has its own persistent conversation and immutable project selection.
     * Never switch the global browser selection because another IDE terminal ran a command.
     */
    private synchronized Selection activateTerminalWorkspace(String sessionId, String workspace) {
        return activateTerminalWorkspace(sessionId, workspace, false);
    }

    private synchronized Selection activateTerminalWorkspace(String sessionId, String workspace, boolean fresh) {
        if (!validSessionId(sessionId)) throw new IllegalArgumentException("Invalid terminal session identifier");
        Selection previous = terminalSelections.get(sessionId);
        if (workspace == null || workspace.isBlank()) {
            if (previous != null) return previous;
            if (current.project() == null) throw new IllegalArgumentException("No mapped project; run eliya in a project folder");
            workspace = current.project().localPath();
        }
        Path root = Path.of(workspace).toAbsolutePath().normalize();
        if (!Files.isDirectory(root)) throw new IllegalArgumentException("Workspace directory does not exist: " + root);
        if (previous != null && previous.project() != null &&
                root.toString().equals(previous.project().localPath())) return previous;
        // Resume this workspace's terminal conversation so follow-ups ("eliya implement", "continue") keep
        // the earlier analysis and history. `--new` starts a fresh conversation explicitly.
        String key = root.toString();
        String conversationId = fresh ? null : terminalConversations.find(key, this::conversationExists).orElse(null);
        if (conversationId == null) conversationId = conversations.create().getId();
        terminalConversations.remember(key, conversationId);
        ProjectDto project = projects.createLocal(conversationId, root.toString(), null);
        indexJobs.request(project, false);
        Selection selection = new Selection(instance + ":" + revision.incrementAndGet(),
                project, conversationId, previous == null ? "analyse" : previous.mode());
        terminalSelections.put(sessionId, selection);
        return selection;
    }

    private static boolean validSessionId(String id) {
        if (id == null || id.isBlank()) return false;
        try { UUID.fromString(id); return true; }
        catch (IllegalArgumentException ex) { return false; }
    }

    private synchronized Selection selectTerminalMode(String sessionId, String mode, String workspace) {
        Selection selection = activateTerminalWorkspace(sessionId, workspace);
        String normalized = mode == null ? "" : mode.toLowerCase(Locale.ROOT).trim();
        if (!Set.of("analyse", "agent").contains(normalized))
            throw new IllegalArgumentException("Mode must be analyse or agent");
        Selection updated = new Selection(instance + ":" + revision.incrementAndGet(),
                selection.project(), selection.conversationId(), normalized);
        terminalSelections.put(sessionId, updated);
        return updated;
    }

    private Selection ownedSession(String sessionId) {
        if (!validSessionId(sessionId)) throw new IllegalArgumentException("A valid terminal session is required");
        Selection selection = terminalSelections.get(sessionId);
        if (selection == null) throw new IllegalArgumentException("Unknown terminal session");
        return selection;
    }

    private AgentRunService.AgentRun ownedRun(String sessionId, String runId) {
        Selection selection = ownedSession(sessionId);
        AgentRunService.AgentRun run = agentRuns.require(runId);
        if (!selection.conversationId().equals(run.conversationId()))
            throw new SecurityException("Run does not belong to this terminal session");
        return run;
    }

    private synchronized Selection chooseMode(String mode, String workspace) {
        // Never allow one terminal to execute against another terminal's globally
        // selected project. The calling terminal pins its canonical workspace.
        if (workspace != null && !workspace.isBlank() &&
                (current.project() == null || !Path.of(current.project().localPath()).equals(
                        Path.of(workspace).toAbsolutePath().normalize()))) {
            activateWorkspace(workspace);
        }
        if (current.project() == null || current.conversationId() == null)
            throw new IllegalArgumentException("No workspace selected. Run `eliya` from a project folder or `eliya workspace <path>`.");
        String normalized = mode == null ? "" : mode.toLowerCase(Locale.ROOT).trim();
        if (!Set.of("analyse", "agent").contains(normalized))
            throw new IllegalArgumentException("Mode must be analyse or agent");
        current = new Selection(instance + ":" + revision.incrementAndGet(),
                current.project(), current.conversationId(), normalized);
        return current;
    }

    private boolean conversationExists(String conversationId) {
        try {
            return conversations.list().stream().anyMatch(conversation -> conversationId.equals(conversation.id()));
        } catch (Exception unavailable) {
            return false;
        }
    }

    /** Terminal-supplied settings win, then browser-synced settings, then the server's own env/config file. */
    private BrowserSettings effectiveSettings(String sessionId) {
        if (sessionId != null) {
            BrowserSettings supplied = terminalSettings.get(sessionId);
            if (supplied != null) return supplied;
        }
        BrowserSettings browser = browserSettings;
        if (browser != null) return browser;
        return toBrowserSettings(EliyaCliModelConfig.load());
    }

    private String settingsSource(String sessionId) {
        if (sessionId != null && terminalSettings.containsKey(sessionId)) return "terminal";
        if (browserSettings != null) return "browser";
        EliyaCliModelConfig.Resolved server = EliyaCliModelConfig.load();
        return server.complete() ? "server " + server.source() : "none";
    }

    private static BrowserSettings toBrowserSettings(EliyaCliModelConfig.Resolved resolved) {
        if (resolved == null || !resolved.complete()) return null;
        try {
            return new BrowserSettings(resolved.apiKey(), SETTINGS_JSON.convertValue(resolved.settings(), ChatSettings.class));
        } catch (IllegalArgumentException invalid) {
            System.err.println("ELIYA terminal model configuration is invalid: " + invalid.getMessage());
            return null;
        }
    }

    /** Token-authorized: the launcher supplies model settings from its environment / config file. */
    @PostMapping("/terminal-settings")
    public ResponseEntity<?> terminalSettings(@RequestBody TerminalSettings supplied,
            @RequestHeader(value = "X-Eliya-CLI-Token", required = false) String credential,
            HttpServletRequest request) {
        if (!authorized(credential, request)) return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        if (supplied == null || !validSessionId(supplied.sessionId()))
            return ResponseEntity.badRequest().body(Map.of("error", "A valid terminal session is required"));
        Map<String,Object> settings = supplied.settings() == null ? Map.of() : supplied.settings();
        BrowserSettings converted = toBrowserSettings(new EliyaCliModelConfig.Resolved(supplied.apiKey(),
                new LinkedHashMap<>(settings), "terminal"));
        if (converted == null) {
            terminalSettings.remove(supplied.sessionId());
            return ResponseEntity.ok(Map.of("configured", false));
        }
        terminalSettings.put(supplied.sessionId(), converted); // process memory only; never echoed back
        return ResponseEntity.ok(Map.of("configured", true, "model", converted.settings().model()));
    }

    private boolean authorized(String credential, HttpServletRequest request) {
        return isLoopback(request.getRemoteAddr()) && credential != null &&
                MessageDigest.isEqual(credential.getBytes(StandardCharsets.UTF_8), token.getBytes(StandardCharsets.UTF_8));
    }

    /** Browser settings never go into the bridge file, logs, or terminal JSON response.
     * Same-origin application JavaScript alone can supply these settings (custom header blocks cross-origin forms).
     */
    @PostMapping("/browser-settings")
    public ResponseEntity<?> browserSettings(@RequestBody BrowserSettings supplied,
            @RequestHeader(value = "X-Eliya-Local-UI", required = false) String marker,
            @RequestHeader(value = "Origin", required = false) String origin,
            HttpServletRequest request) {
        String expected = "http://127.0.0.1:" + webServer.getWebServer().getPort();
        String altExpected = "http://localhost:" + webServer.getWebServer().getPort();
        if (!isLoopback(request.getRemoteAddr()) || !"settings-sync".equals(marker) ||
                (origin != null && !origin.equals(expected) && !origin.equals(altExpected))) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        }
        if (supplied == null || supplied.settings() == null || supplied.apiKey() == null ||
                supplied.apiKey().isBlank() || supplied.settings().baseUrl() == null ||
                supplied.settings().baseUrl().isBlank() || supplied.settings().model() == null ||
                supplied.settings().model().isBlank()) {
            browserSettings = null;
            return ResponseEntity.ok(Map.of("configured", false));
        }
        browserSettings = supplied; // process memory only; never disclose credential to the CLI.
        return ResponseEntity.ok(Map.of("configured", true));
    }

    /** Read-only setup diagnostic for the locally opened browser. Never exposes API credentials. */
    @GetMapping("/setup-state")
    public ResponseEntity<?> setupState(HttpServletRequest request) {
        if (!isLoopback(request.getRemoteAddr())) return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        boolean windows = EliyaCliAutoSetup.detectPlatform(System.getProperty("os.name", "")) ==
                EliyaCliAutoSetup.Platform.WINDOWS;
        boolean readyInNewTerminals = cliSetup.installed() &&
                (!windows || cliSetup.message().startsWith("Eliya CLI installed directly"));
        return ResponseEntity.ok(Map.of("installed", cliSetup.installed(),
                "readyInNewTerminals", readyInNewTerminals,
                "message", cliSetup.message(), "platform", System.getProperty("os.name", "unknown")));
    }

    @GetMapping("/status")
    public ResponseEntity<?> status(@RequestHeader(value = "X-Eliya-CLI-Token", required = false) String credential,
                                    @RequestHeader(value = "X-Eliya-Session", required = false) String sessionId,
                                    HttpServletRequest request) {
        if (!authorized(credential, request)) return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        // A session-specific status must never silently report another session's selection.
        Selection selected = sessionId == null || sessionId.isBlank() ? current : terminalSelections.get(sessionId);
        if (selected == null) return ResponseEntity.status(HttpStatus.NOT_FOUND).body(Map.of(
                "error", "Unknown terminal session; activate the workspace in this terminal first.",
                "sessionId", sessionId));
        BrowserSettings configured = effectiveSettings(sessionId);
        Map<String,Object> result = new LinkedHashMap<>();
        result.put("selection", selected);
        result.put("sessionId", sessionId == null ? "" : sessionId);
        result.put("modelConfigured", configured != null);
        // Only public model identifiers are returned; credentials never leave server memory.
        result.put("model", configured == null ? "" : configured.settings().model());
        result.put("chatModel", configured == null ? "" :
                (configured.settings().chatModel() == null || configured.settings().chatModel().isBlank()
                        ? configured.settings().model() : configured.settings().chatModel()));
        result.put("settingsSource", settingsSource(sessionId));
        result.put("configurationHint", configured == null
                ? "Run `eliya setup` (or set ELIYA_BASE_URL, ELIYA_API_KEY and ELIYA_MODEL), or save provider/model/API key in browser Settings."
                : "ready");
        result.put("url", "http://localhost:" + webServer.getWebServer().getPort() + "/");
        return ResponseEntity.ok(result);
    }

    @PostMapping("/mode")
    public ResponseEntity<?> mode(@RequestBody ModeRequest body,
            @RequestHeader(value = "X-Eliya-CLI-Token", required = false) String credential,
            HttpServletRequest request) {
        if (!authorized(credential, request)) return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        if (body != null && body.sessionId() != null && !body.sessionId().isBlank() &&
                !validSessionId(body.sessionId())) return ResponseEntity.badRequest().body(Map.of("error", "Invalid session ID"));
        try { return ResponseEntity.ok(body != null && validSessionId(body.sessionId())
                ? selectTerminalMode(body.sessionId(), body.mode(), body.workspace())
                : chooseMode(body == null ? null : body.mode(), body == null ? null : body.workspace())); }
        catch (IllegalArgumentException e) { return ResponseEntity.badRequest().body(Map.of("error", e.getMessage())); }
    }

    /** Runs exactly the same native Chat/Agent pipeline as the browser, using the
     * current mapped workspace and a workspace-scoped persistent conversation.
     * This endpoint is callable only by the token-bearing local launcher.
     */
    @PostMapping(path = "/run", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
    public SseEmitter run(@RequestBody TerminalPrompt body,
            @RequestHeader(value = "X-Eliya-CLI-Token", required = false) String credential,
            HttpServletRequest request, jakarta.servlet.http.HttpServletResponse response) {
        // ELIYA184: errors are written as JSON with a code. Throwing ResponseStatusException here produced an EMPTY
        // 409/400 body for an event-stream request (Spring's error page cannot be rendered as text/event-stream), so
        // the terminal only showed "HTTP 409" without the reason.
        if (!authorized(credential, request)) return jsonError(response, HttpStatus.FORBIDDEN, "NOT_AUTHORIZED",
                "Not an authorized local Eliya terminal. Restart `eliya` in this terminal.", Map.of());
        if (body != null && body.sessionId() != null && !body.sessionId().isBlank() &&
                !validSessionId(body.sessionId()))
            return jsonError(response, HttpStatus.BAD_REQUEST, "BAD_SESSION", "Invalid terminal session ID", Map.of());
        BrowserSettings configuration = effectiveSettings(body == null ? null : body.sessionId());
        if (configuration == null) return jsonError(response, HttpStatus.PRECONDITION_REQUIRED, "MODEL_NOT_CONFIGURED",
                "No model is configured for the terminal. Run `eliya setup` (or set ELIYA_BASE_URL, ELIYA_API_KEY and " +
                "ELIYA_MODEL), or open the browser UI once so its saved Settings reach this Eliya server.", Map.of());
        if (body == null) return jsonError(response, HttpStatus.BAD_REQUEST, "BAD_REQUEST", "Prompt is required", Map.of());
        String mode = body.mode();
        if (mode == null || !Set.of("analyse", "agent", "implement").contains(mode))
            return jsonError(response, HttpStatus.BAD_REQUEST, "BAD_MODE", "Mode must be analyse, agent or implement", Map.of());
        Selection selection;
        try { selection = validSessionId(body.sessionId())
                ? selectTerminalMode(body.sessionId(), "implement".equals(mode) ? "agent" : mode, body.workspace())
                : chooseMode("implement".equals(mode) ? "agent" : mode, body.workspace()); }
        catch (IllegalArgumentException ex) { return jsonError(response, HttpStatus.BAD_REQUEST, "NO_WORKSPACE", ex.getMessage(), Map.of()); }
        String prompt = body.prompt() == null ? "" : body.prompt().strip();
        if ("implement".equals(mode)) {
            java.util.List<MessageDto> history = conversations.listMessages(selection.conversationId());
            boolean hasAnalysis = history.stream().anyMatch(m -> "assistant".equals(m.role()) &&
                    ("chat".equals(m.mode()) || m.mode() == null) && m.content() != null && !m.content().isBlank());
            if (!hasAnalysis) return jsonError(response, HttpStatus.BAD_REQUEST, "NO_ANALYSIS",
                    "No completed Analyse response in this workspace conversation. Run `eliya analyse` first.", Map.of());
            prompt = "Implement the last agreed Analyse plan from this conversation in the selected workspace. " +
                    "Read its findings and constraints, apply the requested changes, run appropriate verification, " +
                    "and report evidence of success or failure.";
            mode = "agent";
        }
        if (prompt.isBlank()) return jsonError(response, HttpStatus.BAD_REQUEST, "EMPTY_PROMPT", "Prompt cannot be empty", Map.of());
        // The request retains its own immutable workspace snapshot even if another terminal switches.
        ChatRequest chatRequest = new ChatRequest(selection.conversationId(), prompt, List.of(),
                selection.project().id(), "agent".equals(mode) ? "agent" : "chat", false, configuration.settings());
        String workspaceRoot = selection.project().localPath();
        String workspaceKey;
        try { workspaceKey = Path.of(workspaceRoot).toRealPath().toString(); }
        catch (Exception ex) { workspaceKey = Path.of(workspaceRoot).toAbsolutePath().normalize().toString(); }
        final String lockedRoot = workspaceKey;
        final boolean agentMode = "agent".equals(mode);
        final String owner = validSessionId(body.sessionId()) ? body.sessionId() : "browser-cli-" + UUID.randomUUID();
        AtomicBoolean open = new AtomicBoolean(true);
        final WorkspaceLock lock = agentMode ? new WorkspaceLock(owner, selection.conversationId(), prompt, open) : null;
        if (agentMode) synchronized (activeAgentWorkspaces) {
            Path requested = Path.of(lockedRoot);
            releaseStaleLocks();
            Map.Entry<String,WorkspaceLock> conflicting = activeAgentWorkspaces.entrySet().stream().filter(active -> {
                Path root = Path.of(active.getKey());
                return requested.startsWith(root) || root.startsWith(requested);
            }).findFirst().orElse(null);
            if (conflicting != null) return jsonError(response, HttpStatus.CONFLICT, "WORKSPACE_BUSY",
                    busyMessage(conflicting.getKey(), conflicting.getValue(), owner, selection.conversationId()),
                    busyDetails(conflicting.getKey(), conflicting.getValue()));
            activeAgentWorkspaces.put(lockedRoot, lock);
        }
        SseEmitter output = new SseEmitter(0L);
        output.onCompletion(() -> open.set(false));
        output.onError(error -> open.set(false));
        output.onTimeout(() -> open.set(false));
        try {
            terminalWorkers.submit(() -> {
                try {
                    chat.runTerminal(configuration.apiKey(), chatRequest, (event, data) -> {
                        if (lock != null && "meta".equals(event) && data instanceof Map<?,?> meta && meta.get("agentRunId") != null)
                            lock.runId = String.valueOf(meta.get("agentRunId"));
                        if (!open.get()) return; // Disconnect does not cancel Agent; completion persists server-side.
                        try { output.send(SseEmitter.event().name(event).data(data)); }
                        catch (Exception ex) { open.set(false); }
                    });
                } catch (Exception ex) {
                    if (open.get()) try { output.send(SseEmitter.event().name("error")
                            .data(Map.of("message", "CLI execution failed: " + ex.getClass().getSimpleName()))); }
                    catch (Exception ignored) { }
                } finally {
                    if (agentMode) activeAgentWorkspaces.remove(lockedRoot, lock);
                    try { output.complete(); } catch (Exception ignored) { }
                }
            });
        } catch (RuntimeException ex) {
            if (agentMode) activeAgentWorkspaces.remove(lockedRoot, lock);
            throw ex;
        }
        return output;
    }

    /** Write a JSON error ({code, message, error, …}) for an event-stream endpoint and end the request. */
    private SseEmitter jsonError(jakarta.servlet.http.HttpServletResponse response, HttpStatus status, String code,
                                 String message, Map<String,Object> details) {
        Map<String,Object> body = new LinkedHashMap<>();
        body.put("code", code);
        body.put("message", message);
        body.put("error", message);
        body.put("status", status.value());
        if (details != null) body.putAll(details);
        try {
            response.setStatus(status.value());
            response.setContentType("application/json");
            response.setCharacterEncoding("UTF-8");
            response.getWriter().write(SETTINGS_JSON.writeValueAsString(body));
            response.flushBuffer();
        } catch (Exception writeFailure) {
            throw new ResponseStatusException(status, message);
        }
        return null;
    }

    /** A lock whose run has finished (or no longer exists) never blocks the workspace. */
    private void releaseStaleLocks() {
        activeAgentWorkspaces.entrySet().removeIf(entry -> {
            WorkspaceLock held = entry.getValue();
            if (held.runId.isBlank()) return false; // still preparing; the run id arrives with the first event
            return agentRuns.find(held.runId).map(AgentRunService.AgentRun::finished).orElse(true);
        });
    }

    private String busyMessage(String root, WorkspaceLock held, String requester, String requesterConversation) {
        StringBuilder out = new StringBuilder("Another Eliya Agent task is still running in this workspace");
        if (!root.isBlank()) out.append(" (").append(root).append(")");
        out.append(": started ").append(ago(held.startedAt));
        if (!held.prompt.isBlank()) out.append(" for \"").append(held.prompt).append("\"");
        String waiting = held.runId.isBlank() ? "" : waitingFor(held.runId);
        if (!waiting.isBlank()) out.append(", now ").append(waiting);
        out.append(". ");
        if (!held.streamOpen.get()) out.append("The terminal that started it was closed, but the task kept running. ");
        out.append(requester.equals(held.owner) ? "Wait for it, or press Ctrl+C / type /stop to stop it."
                : "Type /stop here (or `eliya cancel` in a shell) to stop it — finished work is kept — then send your message again.");
        return out.toString();
    }

    private Map<String,Object> busyDetails(String root, WorkspaceLock held) {
        Map<String,Object> details = new LinkedHashMap<>();
        details.put("workspace", root);
        details.put("runId", held.runId);
        details.put("startedAt", held.startedAt.toString());
        details.put("task", held.prompt);
        details.put("terminalOpen", held.streamOpen.get());
        if (!held.runId.isBlank()) details.put("activity", waitingFor(held.runId));
        return details;
    }

    /** "waiting for your approval", "waiting for your answer" or the run's current activity. */
    private String waitingFor(String runId) {
        try {
            if (!questions.pending(runId).isEmpty()) return "waiting for your answer to a question";
            return agentRuns.find(runId).map(run -> {
                String phase = run.progressPhase();
                String detail = run.progressDetail();
                if ("plan_review".equals(phase) || detail.toLowerCase(java.util.Locale.ROOT).contains("approval"))
                    return "waiting for your approval";
                return detail.isBlank() ? phase : detail.length() > 120 ? detail.substring(0, 119) + "…" : detail;
            }).orElse("");
        } catch (RuntimeException unavailable) {
            return "";
        }
    }

    private static String ago(java.time.Instant at) {
        long seconds = Math.max(0, java.time.Duration.between(at, java.time.Instant.now()).getSeconds());
        if (seconds < 60) return seconds + "s ago";
        if (seconds < 3600) return (seconds / 60) + " min ago";
        return (seconds / 3600) + " h " + ((seconds % 3600) / 60) + " min ago";
    }

    /** Unattended run (`eliya run`): isolated worktree, headless approvals, budgets, report. Streams events. */
    @PostMapping(path = "/autonomous", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
    public SseEmitter autonomous(@RequestBody AutonomousPrompt body,
            @RequestHeader(value = "X-Eliya-CLI-Token", required = false) String credential,
            HttpServletRequest request, jakarta.servlet.http.HttpServletResponse response) {
        if (!authorized(credential, request)) return jsonError(response, HttpStatus.FORBIDDEN, "NOT_AUTHORIZED",
                "Not an authorized local Eliya terminal. Restart `eliya` in this terminal.", Map.of());
        if (body == null || body.task() == null || body.task().isBlank())
            return jsonError(response, HttpStatus.BAD_REQUEST, "BAD_REQUEST", "Task text is required", Map.of());
        String workspace = body.workspace();
        if ((workspace == null || workspace.isBlank()) && current.project() != null) workspace = current.project().localPath();
        if (workspace == null || workspace.isBlank())
            return jsonError(response, HttpStatus.BAD_REQUEST, "NO_WORKSPACE", "Run `eliya run` inside a project folder", Map.of());
        BrowserSettings configuration = effectiveSettings(body.sessionId());
        if (configuration == null) return jsonError(response, HttpStatus.PRECONDITION_REQUIRED, "MODEL_NOT_CONFIGURED",
                "No model is configured for the terminal. Run `eliya setup` (or set ELIYA_BASE_URL, ELIYA_API_KEY and " +
                "ELIYA_MODEL), or open the browser UI once so its saved Settings reach this Eliya server.", Map.of());
        com.llmart.llm.autonomy.AutonomousRunService.RunRequest runRequest;
        try {
            runRequest = new com.llmart.llm.autonomy.AutonomousRunService.RunRequest(body.task(), workspace,
                    Boolean.TRUE.equals(body.inPlace()), nz(body.maxMinutes()), nz(body.maxTurns()), nz(body.maxTokens()),
                    "terminal", Boolean.TRUE.equals(body.keepWorktree()));
        } catch (IllegalArgumentException invalid) {
            return jsonError(response, HttpStatus.BAD_REQUEST, "BAD_REQUEST", invalid.getMessage(), Map.of());
        }
        SseEmitter output = new SseEmitter(0L);
        AtomicBoolean open = new AtomicBoolean(true);
        output.onCompletion(() -> open.set(false));
        output.onError(error -> open.set(false));
        output.onTimeout(() -> open.set(false));
        terminalWorkers.submit(() -> {
            java.util.function.BiConsumer<String,Object> send = (event, data) -> {
                if (!open.get()) return; // disconnect does not cancel the unattended run
                try { output.send(SseEmitter.event().name(event).data(data)); }
                catch (Exception ex) { open.set(false); }
            };
            try {
                var result = autonomous.run(runRequest, new com.llmart.llm.autonomy.AutonomousRunService.ModelAccess(
                        configuration.apiKey(), configuration.settings()), send);
                send.accept("autonomous_result", result);
            } catch (Exception ex) {
                send.accept("error", Map.of("message", "Autonomous run failed: " +
                        (ex.getMessage() == null ? ex.getClass().getSimpleName() : ex.getMessage())));
            } finally {
                try { output.complete(); } catch (Exception ignored) { }
            }
        });
        return output;
    }

    private static long nz(Long value) { return value == null || value < 0 ? 0 : value; }

    @PostMapping("/refresh")
    public ResponseEntity<?> refresh(
            @RequestHeader(value = "X-Eliya-CLI-Token", required = false) String credential,
            HttpServletRequest request) {
        if (!authorized(credential, request)) return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        // No browser-global selection changes for an independent terminal run.
        return ResponseEntity.ok(Map.of("refreshed", true));
    }

    @GetMapping("/selection")
    public ResponseEntity<Selection> selection(HttpServletRequest servletRequest) {
        if (!isLoopback(servletRequest.getRemoteAddr())) return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        return ResponseEntity.ok(current);
    }

    @PostMapping("/activate")
    public ResponseEntity<?> activate(@RequestBody ActivationRequest request,
                                      @RequestHeader(value = "X-Eliya-CLI-Token", required = false) String credential,
                                      HttpServletRequest servletRequest) {
        if (!authorized(credential, servletRequest)) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(Map.of("error", "Not an authorized local Eliya CLI"));
        }
        if (request != null && request.sessionId() != null && !request.sessionId().isBlank() &&
                !validSessionId(request.sessionId())) return ResponseEntity.badRequest().body(Map.of("error", "Invalid session ID"));
        try {
            Selection selection = request != null && validSessionId(request.sessionId())
                    ? activateTerminalWorkspace(request.sessionId(), request.workspace(), Boolean.TRUE.equals(request.fresh()))
                    : activateGlobalSelection(request == null ? null : request.workspace());
            return ResponseEntity.ok(Map.of("selection", selection,
                    "url", "http://localhost:" + webServer.getWebServer().getPort() + "/"));
        }
        catch (IllegalArgumentException exception) { return ResponseEntity.badRequest().body(Map.of("error", exception.getMessage())); }
    }

    private Selection activateGlobalSelection(String workspace) {
        activateWorkspace(workspace);
        return current;
    }

    /** Snapshot timings and exact verification status from the authoritative Agent run. */
    @GetMapping("/session/result")
    public ResponseEntity<?> terminalResult(@RequestParam String sessionId,
            @RequestHeader(value = "X-Eliya-CLI-Token", required = false) String credential,
            HttpServletRequest request) {
        if (!authorized(credential, request)) return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        try {
            Selection selection = ownedSession(sessionId);
            return ResponseEntity.ok(agentRuns.latestForConversation(selection.conversationId())
                    .orElseGet(() -> Map.of("status", "no_agent_run")));
        } catch (IllegalArgumentException ex) { return ResponseEntity.badRequest().body(Map.of("error", ex.getMessage())); }
    }

    @PostMapping("/session/cancel")
    public ResponseEntity<?> cancelSession(@RequestParam String sessionId,
            @RequestHeader(value = "X-Eliya-CLI-Token", required = false) String credential,
            HttpServletRequest request) {
        if (!authorized(credential, request)) return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        try {
            Selection selection = ownedSession(sessionId);
            boolean stopped = agentRuns.latestForConversation(selection.conversationId())
                    .map(snapshot -> agentRuns.cancel(String.valueOf(snapshot.get("id")))).orElse(false);
            stopped |= chat.cancelChat(selection.conversationId());
            // ELIYA184: also stop an Agent task another (possibly closed) terminal left running in this workspace,
            // which otherwise blocks every new Agent request here with "workspace busy".
            WorkspaceLock other = workspaceLockFor(selection);
            if (other != null && !other.runId.isBlank()) stopped |= agentRuns.cancel(other.runId);
            return ResponseEntity.ok(Map.of("cancellationRequested", stopped));
        } catch (IllegalArgumentException ex) { return ResponseEntity.badRequest().body(Map.of("error", ex.getMessage())); }
    }

    @GetMapping("/session/question")
    public ResponseEntity<?> terminalQuestion(@RequestParam String sessionId, @RequestParam String runId,
            @RequestHeader(value = "X-Eliya-CLI-Token", required = false) String credential,
            HttpServletRequest request) {
        if (!authorized(credential, request)) return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        try { ownedRun(sessionId, runId); return ResponseEntity.ok(questions.pending(runId)); }
        catch (RuntimeException ex) { return ResponseEntity.badRequest().body(Map.of("error", "Run unavailable for this session")); }
    }

    @PostMapping("/session/question")
    public ResponseEntity<?> answerQuestion(@RequestParam String sessionId, @RequestBody QuestionAnswer answer,
            @RequestHeader(value = "X-Eliya-CLI-Token", required = false) String credential,
            HttpServletRequest request) {
        if (!authorized(credential, request)) return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        try {
            ownedRun(sessionId, answer.runId());
            if (!questions.answer(answer.runId(), answer.questionId(), answer.choice(), answer.detail()))
                return ResponseEntity.status(HttpStatus.CONFLICT).body(Map.of("error", "Question expired or invalid"));
            return ResponseEntity.ok(Map.of("answered", true));
        } catch (RuntimeException ex) { return ResponseEntity.badRequest().body(Map.of("error", "Run unavailable for this session")); }
    }

    @PostMapping("/session/approval")
    public ResponseEntity<?> decideApproval(@RequestParam String sessionId, @RequestBody ApprovalDecision answer,
            @RequestHeader(value = "X-Eliya-CLI-Token", required = false) String credential,
            HttpServletRequest request) {
        if (!authorized(credential, request)) return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        try {
            ownedRun(sessionId, answer.runId());
            AgentApprovalService.Decision decision = switch (answer.decision() == null ? "" : answer.decision().toLowerCase(Locale.ROOT)) {
                case "once" -> AgentApprovalService.Decision.ONCE;
                case "run" -> AgentApprovalService.Decision.RUN;
                case "deny" -> AgentApprovalService.Decision.DENY;
                default -> throw new IllegalArgumentException("Decision must be once, run or deny");
            };
            if (!approvals.resolveForRun(answer.approvalId(), answer.runId(), decision))
                return ResponseEntity.status(HttpStatus.CONFLICT).body(Map.of("error", "Approval expired, invalid or restricted"));
            return ResponseEntity.ok(Map.of("resolved", true));
        } catch (RuntimeException ex) { return ResponseEntity.badRequest().body(Map.of("error", "Run unavailable for this session")); }
    }

    /** Add input to this session's running Agent task; delivered after its current action (ELIYA175 queue). */
    public record RunInput(String runId, String text) { }

    @PostMapping("/session/input")
    public ResponseEntity<?> addRunInput(@RequestParam String sessionId, @RequestBody RunInput body,
            @RequestHeader(value = "X-Eliya-CLI-Token", required = false) String credential,
            HttpServletRequest request) {
        if (!authorized(credential, request)) return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        if (body == null || body.runId() == null) return ResponseEntity.badRequest().body(Map.of("error", "runId is required"));
        try {
            ownedRun(sessionId, body.runId());
            var input = agentRuns.require(body.runId()).submitUserInput(body.text());
            return ResponseEntity.ok(input.toMap());
        } catch (IllegalStateException finished) {
            return ResponseEntity.status(HttpStatus.CONFLICT).body(Map.of("error", String.valueOf(finished.getMessage())));
        } catch (IllegalArgumentException invalid) {
            return ResponseEntity.badRequest().body(Map.of("error", String.valueOf(invalid.getMessage())));
        } catch (RuntimeException ex) {
            return ResponseEntity.badRequest().body(Map.of("error", "Run unavailable for this session"));
        }
    }

    /** The Agent lock covering this session's workspace, if another task holds it. */
    private WorkspaceLock workspaceLockFor(Selection selection) {
        if (selection == null || selection.project() == null || selection.project().localPath() == null) return null;
        Path requested;
        try { requested = Path.of(selection.project().localPath()).toRealPath(); }
        catch (Exception ex) { requested = Path.of(selection.project().localPath()).toAbsolutePath().normalize(); }
        synchronized (activeAgentWorkspaces) {
            releaseStaleLocks();
            for (Map.Entry<String,WorkspaceLock> entry : activeAgentWorkspaces.entrySet()) {
                Path root = Path.of(entry.getKey());
                if (requested.startsWith(root) || root.startsWith(requested)) return entry.getValue();
            }
        }
        return null;
    }

    /**
     * ELIYA184: an Agent task still running for this terminal's workspace — from this conversation or one left
     * running by a terminal that was closed. The terminal chat shows it at start so the user can stop it.
     */
    @GetMapping("/session/active")
    public ResponseEntity<?> activeRun(@RequestParam String sessionId,
            @RequestHeader(value = "X-Eliya-CLI-Token", required = false) String credential,
            HttpServletRequest request) {
        if (!authorized(credential, request)) return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        try {
            Selection selection = ownedSession(sessionId);
            WorkspaceLock held = workspaceLockFor(selection);
            String runId = held != null && !held.runId.isBlank() ? held.runId
                    : agentRuns.latestRun(selection.conversationId()).filter(run -> !run.finished())
                            .map(AgentRunService.AgentRun::id).orElse("");
            if (runId.isBlank()) return ResponseEntity.ok(Map.of("active", false));
            AgentRunService.AgentRun run = agentRuns.find(runId).orElse(null);
            if (run == null || run.finished()) return ResponseEntity.ok(Map.of("active", false));
            Map<String,Object> result = new LinkedHashMap<>();
            result.put("active", true);
            result.put("runId", runId);
            result.put("status", run.status());
            result.put("activity", waitingFor(runId));
            result.put("startedAt", run.createdAt().toString());
            result.put("task", held == null ? "" : held.prompt);
            result.put("terminalOpen", held != null && held.streamOpen.get());
            result.put("sameConversation", selection.conversationId().equals(run.conversationId()));
            return ResponseEntity.ok(result);
        } catch (IllegalArgumentException ex) { return ResponseEntity.badRequest().body(Map.of("error", ex.getMessage())); }
    }

    /** ELIYA184: skills available in this terminal's workspace (built-in, user and project). */
    @GetMapping("/skills")
    public ResponseEntity<?> skills(@RequestParam String sessionId,
            @RequestHeader(value = "X-Eliya-CLI-Token", required = false) String credential,
            HttpServletRequest request) {
        if (!authorized(credential, request)) return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        try {
            Selection selection = ownedSession(sessionId);
            Path root = selection.project() == null ? null : Path.of(selection.project().localPath());
            List<Map<String,Object>> skills = com.llmart.llm.service.SkillCatalog.discover(root).stream()
                    .map(skill -> {
                        Map<String,Object> row = new LinkedHashMap<>();
                        row.put("name", skill.name());
                        row.put("description", skill.description());
                        row.put("aliases", skill.aliases());
                        row.put("source", skill.source());
                        return row;
                    }).toList();
            return ResponseEntity.ok(Map.of("skills", skills));
        } catch (IllegalArgumentException ex) { return ResponseEntity.badRequest().body(Map.of("error", ex.getMessage())); }
    }

    /** ELIYA184: this workspace's project memory (eliya-mem): newest notes, or a search. */
    @GetMapping("/memory")
    public ResponseEntity<?> memory(@RequestParam String sessionId, @RequestParam(required = false) String query,
            @RequestHeader(value = "X-Eliya-CLI-Token", required = false) String credential,
            HttpServletRequest request) {
        if (!authorized(credential, request)) return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        if (projectMemory == null) return ResponseEntity.ok(Map.of("text", "Project memory is not available in this server."));
        try {
            Selection selection = ownedSession(sessionId);
            if (selection.project() == null) return ResponseEntity.ok(Map.of("text", "No workspace selected."));
            return ResponseEntity.ok(Map.of("text", projectMemory.searchText(Path.of(selection.project().localPath()),
                    query == null ? "" : query, 8_000)));
        } catch (IllegalArgumentException ex) { return ResponseEntity.badRequest().body(Map.of("error", ex.getMessage())); }
    }

    @PostMapping("/memory/clear")
    public ResponseEntity<?> clearMemory(@RequestParam String sessionId,
            @RequestHeader(value = "X-Eliya-CLI-Token", required = false) String credential,
            HttpServletRequest request) {
        if (!authorized(credential, request)) return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        if (projectMemory == null) return ResponseEntity.ok(Map.of("cleared", 0));
        try {
            Selection selection = ownedSession(sessionId);
            if (selection.project() == null) return ResponseEntity.ok(Map.of("cleared", 0));
            return ResponseEntity.ok(Map.of("cleared", projectMemory.clear(Path.of(selection.project().localPath()))));
        } catch (IllegalArgumentException ex) { return ResponseEntity.badRequest().body(Map.of("error", ex.getMessage()));
        } catch (java.io.IOException ex) { return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Map.of("error", String.valueOf(ex.getMessage()))); }
    }

    private static boolean isLoopback(String host) {
        try { return java.net.InetAddress.getByName(host).isLoopbackAddress(); }
        catch (Exception ex) { return false; }
    }

    private static void restrictFile(Path file) {
        try { Files.setPosixFilePermissions(file, Set.of(PosixFilePermission.OWNER_READ, PosixFilePermission.OWNER_WRITE)); }
        catch (UnsupportedOperationException | java.io.IOException ignored) { /* Windows inherits user-profile ACLs. */ }
    }

    @PreDestroy
    public void shutdown() {
        terminalWorkers.shutdownNow();
        if (!published) return;
        try {
            Path file = bridgeFile();
            List<String> lines = Files.readAllLines(file, StandardCharsets.UTF_8);
            if (lines.size() > 1 && token.equals(lines.get(1))) Files.deleteIfExists(file);
        } catch (Exception ignored) { }
    }

    /** Open only a fixed localhost Eliya URL. A closed/headless desktop is non-fatal. */
    public static void openBrowser(String baseUrl) {
        try {
            URI address = URI.create(baseUrl);
            if (!("localhost".equalsIgnoreCase(address.getHost()) || "127.0.0.1".equals(address.getHost())) || !"http".equals(address.getScheme())) return;
            if (!GraphicsEnvironment.isHeadless() && Desktop.isDesktopSupported() &&
                    Desktop.getDesktop().isSupported(Desktop.Action.BROWSE)) {
                Desktop.getDesktop().browse(address);
                return;
            }
            String os = System.getProperty("os.name", "").toLowerCase(Locale.ROOT);
            String[] command = os.contains("win")
                    ? new String[]{"rundll32", "url.dll,FileProtocolHandler", address.toString()}
                    : os.contains("mac") ? new String[]{"open", address.toString()}
                    : new String[]{"xdg-open", address.toString()};
            new ProcessBuilder(command).start();
        } catch (Exception ex) {
            System.out.println("Open Eliya in your browser: " + baseUrl);
        }
    }
}
