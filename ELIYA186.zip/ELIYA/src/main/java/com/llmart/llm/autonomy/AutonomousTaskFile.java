package com.llmart.llm.autonomy;

import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

/**
 * Parses an inbox task file: optional front matter followed by the task text.
 * <pre>
 * ---
 * workspace: C:\projects\shop
 * mode: worktree        # or in-place
 * maxMinutes: 30
 * maxTurns: 200
 * maxTokens: 1500000
 * ---
 * Fix the failing OrderServiceTest and keep the public API unchanged.
 * </pre>
 */
public record AutonomousTaskFile(String task, String workspace, boolean inPlace, long maxMinutes, long maxTurns, long maxTokens) {

    public static AutonomousTaskFile parse(String content, String defaultWorkspace) {
        String text = content == null ? "" : content.replace("\r\n", "\n");
        Map<String,String> meta = new LinkedHashMap<>();
        if (text.startsWith("---\n")) {
            int end = text.indexOf("\n---", 4);
            if (end > 0) {
                for (String line : text.substring(4, end).split("\n")) {
                    String clean = line.replaceAll("\\s+#.*$", "").strip();
                    int colon = clean.indexOf(':');
                    if (colon > 0) meta.put(clean.substring(0, colon).strip().toLowerCase(Locale.ROOT), clean.substring(colon + 1).strip());
                }
                int bodyStart = text.indexOf('\n', end + 1);
                text = bodyStart < 0 ? "" : text.substring(bodyStart + 1);
            }
        }
        String workspace = unquote(meta.getOrDefault("workspace", defaultWorkspace == null ? "" : defaultWorkspace));
        String mode = meta.getOrDefault("mode", "worktree").toLowerCase(Locale.ROOT);
        return new AutonomousTaskFile(text.strip(), workspace, mode.startsWith("in"),
                number(meta.get("maxminutes")), number(meta.get("maxturns")), number(meta.get("maxtokens")));
    }

    private static long number(String raw) {
        if (raw == null) return 0;
        try { return Math.max(0, Long.parseLong(raw.replace("_", "").strip())); }
        catch (NumberFormatException invalid) { return 0; }
    }

    private static String unquote(String value) {
        String v = value == null ? "" : value.strip();
        if (v.length() >= 2 && ((v.startsWith("\"") && v.endsWith("\"")) || (v.startsWith("'") && v.endsWith("'"))))
            v = v.substring(1, v.length() - 1);
        return v;
    }
}
