package com.llmart.llm.cli.tui;

import java.io.IOException;
import java.io.InputStream;

/** A terminal the full-screen chat can draw on: raw key input, size, output, and restore on close. */
public abstract class TuiTerminal implements AutoCloseable {

    /** Raw terminal access on Linux/macOS, or {@code null} when unavailable (Windows, pipes, no /dev/tty). */
    public static TuiTerminal open() { return UnixTuiTerminal.create(); }

    /** True when an interactive Unix terminal with raw-mode support is attached. */
    public static boolean supported() { return UnixTuiTerminal.available(); }

    /** Windows console (preview): raw keys through a PowerShell helper; {@code null} when not possible. */
    public static TuiTerminal openWindows() { return WindowsTuiTerminal.create(); }

    /** Enter raw mode and the alternate screen. */
    public abstract void enter() throws IOException, InterruptedException;

    /** {rows, columns}. */
    public abstract int[] size();

    public abstract InputStream input();

    public abstract void write(String text) throws IOException;

    public abstract void flush() throws IOException;

    @Override
    public abstract void close();
}
