package com.llmart.llm.cli.tui;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Pattern;

/**
 * Chat logic shared by the full-screen and line-mode terminal views: routes what the user sends to a new run,
 * the running Agent task, a pending approval, a pending question, the next-task queue or a slash command.
 */
public final class TuiController {

    /** Screen-specific services the controller needs from a view. */
    public interface View {
        void changed();
        void exit();
        /** Copy text to the clipboard; returns a short description of how it was copied. */
        String copy(String text);
        /** Open the browser UI ({@code window=true}: app-style window). */
        void openWeb(String url, boolean window);
    }

    public record Approval(String runId, String approvalId, String description, boolean allowRun) { }
    public record Question(String runId, String id, String reason, List<String> choices) { }

    private final TuiBackend backend;
    private final TuiTranscript transcript = new TuiTranscript();
    private final boolean autoApprove;
    private final Path exportDir;
    private final ExecutorService runner = Executors.newSingleThreadExecutor(daemon("eliya-tui-run"));
    private final ExecutorService actions = Executors.newSingleThreadExecutor(daemon("eliya-tui-action"));
    private final Deque<String> queued = new ArrayDeque<>();
    private View view;
    private volatile String welcomeHint = "Enter sends · Alt+Enter or Ctrl+J new line · Tab switches Analyse/Agent · /help for commands";

    private volatile String mode;
    private volatile String workspace = "";
    private volatile String model = "";
    private volatile String chatModel = "";
    private volatile String webUrl = "";
    private volatile boolean modelConfigured = true;
    private volatile boolean running;
    private volatile boolean userStopped;
    private volatile long runStartedAt;
    private volatile String runId = "";
    private volatile String activity = "";
    private volatile Approval approval;
    private volatile Question question;
    private volatile TuiTranscript.Entry answer;
    private volatile TuiTranscript.Entry lastStep;
    private volatile List<TuiBackend.SkillInfo> skillCache;

    /** ELIYA184: words that control a running task (the server decides exactly; this only picks labels). */
    private static final Pattern CONTROL = Pattern.compile(
            "(?i)^\\s*(?:please\\s+|ok(?:ay)?[,\\s]+|eliya[,\\s]+|now\\s+|just\\s+)*" +
            "(?:stop|abort|cancel|halt|kill|quit|end|pause|skip|status|progress|that'?s enough|enough|wrap(?: it)? up|" +
            "move on|next step|what are you doing|where are you|how far|any update)\\b.*");
    private static final Pattern STOP_WORD = Pattern.compile(
            "(?i)^\\s*(?:please\\s+|ok(?:ay)?[,\\s]+|eliya[,\\s]+|now\\s+|just\\s+)*(?:stop|abort|cancel|halt|quit|enough|that'?s enough)\\b.{0,60}$");

    public TuiController(TuiBackend backend, String mode, boolean autoApprove, Path exportDir) {
        this.backend = backend;
        this.mode = "agent".equals(mode) ? "agent" : "analyse";
        this.autoApprove = autoApprove;
        this.exportDir = exportDir;
    }

    private static java.util.concurrent.ThreadFactory daemon(String name) {
        return task -> { Thread thread = new Thread(task, name); thread.setDaemon(true); return thread; };
    }

    public void attach(View view) { this.view = view; }
    public void welcomeHint(String hint) { if (hint != null && !hint.isBlank()) welcomeHint = hint; }
    public TuiTranscript transcript() { return transcript; }
    public String mode() { return mode; }
    public String workspace() { return workspace; }
    public String model() { return "agent".equals(mode) ? model : (chatModel.isBlank() ? model : chatModel); }
    public boolean modelConfigured() { return modelConfigured; }
    public boolean running() { return running; }
    public String runId() { return runId; }
    public String activity() { return activity; }
    public long runStartedAt() { return runStartedAt; }
    public Approval approval() { return approval; }
    public Question question() { return question; }
    public synchronized List<String> queued() { return new ArrayList<>(queued); }

    private void changed() { if (view != null) view.changed(); }
    private void info(String text) { transcript.add(TuiTranscript.Kind.INFO, "", "", text); changed(); }
    private void error(String text) { transcript.add(TuiTranscript.Kind.ERROR, "", "", text); changed(); }

    /** Load status and select the mode; shows a welcome line. */
    public void start() {
        try {
            workspace = backend.mode(mode);
            loadStatus();
        } catch (Exception failure) {
            error(String.valueOf(failure.getMessage()) + "\nOpen a project with /workspace <folder> (or start `eliya` inside a project folder).");
        }
        info("Eliya " + label(mode) + " · " + (workspace.isBlank() ? "no workspace selected" : workspace) + "\n" + welcomeHint);
        if (!modelConfigured) error("No model configured. Run `eliya setup`, set ELIYA_BASE_URL / ELIYA_API_KEY / ELIYA_MODEL, or use browser Settings.");
        // ELIYA184: a task left running by a closed terminal would block Agent requests here ("workspace busy").
        try {
            TuiBackend.ActiveRun active = backend.activeRun();
            if (active != null) info(activeRunNotice(active));
        } catch (Exception ignored) { /* older server: no notice */ }
    }

    static String activeRunNotice(TuiBackend.ActiveRun active) {
        StringBuilder out = new StringBuilder("An Agent task is still running in this workspace");
        if (!active.task().isBlank()) out.append(": \"").append(active.task()).append('"');
        if (!active.activity().isBlank()) out.append(" — ").append(active.activity());
        out.append(active.terminalOpen() ? " (started in another terminal)." : " (its terminal was closed; it kept running).");
        out.append("\n/stop stops it (finished work is kept) · /web shows it in the browser · new Agent tasks here wait until it ends.");
        return out.toString();
    }

    private void loadStatus() throws Exception {
        TuiBackend.Status status = backend.status();
        if (status.workspace() != null && !status.workspace().isBlank()) workspace = status.workspace();
        model = status.model() == null ? "" : status.model();
        chatModel = status.chatModel() == null ? "" : status.chatModel();
        modelConfigured = status.modelConfigured();
        webUrl = status.url() == null ? "" : status.url();
    }

    static String label(String mode) { return "agent".equals(mode) ? "Agent" : "Analyse"; }

    // ----------------------------------------------------------------------------------------------------- input

    /** Route one message from the input box (Enter). */
    public void submit(String raw) {
        String text = raw == null ? "" : raw.strip();
        if (text.isEmpty()) return;
        Approval pendingApproval = approval;
        Question pendingQuestion = question;
        if (isCommand(text)) { command(text); return; }
        if (pendingApproval != null && controlDuringApproval(pendingApproval, text)) return;
        if (pendingApproval != null) { decideApproval(pendingApproval, text); return; }
        if (pendingQuestion != null) { answerQuestion(pendingQuestion, text); return; }
        if (running) {
            String current = runId;
            if (!current.isBlank()) addToRunningTask(current, text);
            else if (STOP_WORD.matcher(text).matches()) stop();  // "stop" while an answer streams stops it
            else queueNext(text);  // Analyse answers cannot take input mid-stream: run it next
            return;
        }
        startRun(mode, text);
    }

    /** True for "/word ..." commands; a pasted absolute path such as "/home/me/x" is a normal message. */
    static boolean isCommand(String text) {
        if (!text.startsWith("/") || text.length() < 2) return false;
        String head = text.substring(1).split("\\s", 2)[0];
        return head.matches("[a-zA-Z?]+") && !head.contains("/");
    }

    /** Ctrl+Q / "/queue": run this message as the next task once the current one finishes. */
    public void queueNext(String raw) {
        String text = raw == null ? "" : raw.strip();
        if (text.isEmpty()) return;
        if (!running && approval == null && question == null) { startRun(mode, text); return; }
        synchronized (this) { queued.addLast(text); }
        transcript.add(TuiTranscript.Kind.QUEUED, "Queued next", "", text);
        changed();
    }

    private void addToRunningTask(String current, String text) {
        boolean control = CONTROL.matcher(text).matches();
        transcript.add(TuiTranscript.Kind.USER, control ? "Instruction to the running task" : "Added to running task", "pending", text);
        changed();
        actions.submit(() -> {
            try {
                // ELIYA184: the server acts on stop / skip / status at once; other text refines the task.
                TuiBackend.InputResult result = backend.submitInput(current, text);
                switch (result.kind()) {
                    case "stop" -> {
                        userStopped = true;
                        activity = "stopping…";
                        transcript.add(TuiTranscript.Kind.ACTIVITY, "Stop", "warning",
                                "Stopping the current action — the results so far will follow");
                    }
                    case "skip" -> transcript.add(TuiTranscript.Kind.ACTIVITY, "Skip", "info",
                            result.reply().isBlank() ? "Interrupting the current action and skipping this step" : result.reply());
                    case "status" -> transcript.add(TuiTranscript.Kind.INFO, "", "", "Progress — " + result.reply());
                    default -> transcript.add(TuiTranscript.Kind.ACTIVITY, "Input", "info",
                            result.reply().isBlank() ? "Will be applied after the Agent's current action" : result.reply());
                }
            } catch (Exception failed) {
                if (control) {
                    // A stop/status for a task that just ended must not become the next task.
                    transcript.add(TuiTranscript.Kind.INFO, "", "", "The task already finished — nothing to " +
                            (text.toLowerCase(Locale.ROOT).contains("skip") ? "skip." : "stop."));
                } else {
                    // Finished meanwhile (409) or analyse run: keep the message instead of losing it.
                    synchronized (this) { queued.addLast(text); }
                    transcript.add(TuiTranscript.Kind.QUEUED, "Queued next", "", text + "\n(" + failed.getMessage() + ")");
                    if (!running) sendNextQueued();
                }
            }
            changed();
        });
    }

    /**
     * ELIYA184: "stop …", "skip this step" or "status" typed while an approval is pending (for example for the
     * `git push` of the last step) used to be rejected as "answer y/a/n". Stop ends the task (the approval wait ends
     * with it); skip denies this action and skips the step; status answers and keeps the approval open.
     */
    private boolean controlDuringApproval(Approval pending, String text) {
        String value = text.strip().toLowerCase(Locale.ROOT);
        if (value.matches("y|yes|once|1|a|all|run|always|2|n|no|deny|3")) return false;
        if (!CONTROL.matcher(text).matches() || runId.isBlank()) return false;
        boolean skip = value.matches("(?:please\\s+)?(?:skip|move on|next step).*");
        boolean status = value.matches("(?:status|progress|what are you doing|where are you|how far|any update).*");
        if (!status) approval = null;
        if (skip) {
            transcript.add(TuiTranscript.Kind.ACTIVITY, "Approval", "info", "Denied this action to skip the step");
            actions.submit(() -> {
                try { backend.approve(pending.runId(), pending.approvalId(), "deny"); }
                catch (Exception failed) { error("Approval could not be recorded: " + failed.getMessage()); }
            });
        }
        addToRunningTask(runId, text);
        return true;
    }

    private void decideApproval(Approval pending, String text) {
        String value = text.toLowerCase(Locale.ROOT);
        String decision = switch (value) {
            case "y", "yes", "once", "1" -> "once";
            case "a", "all", "run", "always", "2" -> pending.allowRun() ? "run" : null;
            case "n", "no", "deny", "3" -> "deny";
            default -> null;
        };
        if (decision == null) {
            error("Answer the approval with y (this action), " + (pending.allowRun() ? "a (all actions this run), " : "") + "or n (deny).");
            return;
        }
        approval = null;
        transcript.add(TuiTranscript.Kind.ACTIVITY, "Approval", "success", "Decision: " + decisionLabel(decision));
        changed();
        actions.submit(() -> {
            try { backend.approve(pending.runId(), pending.approvalId(), decision); }
            catch (Exception failed) { error("Approval could not be recorded: " + failed.getMessage()); }
        });
    }

    static String decisionLabel(String decision) {
        return switch (decision) { case "once" -> "approved this action"; case "run" -> "approved for this run"; default -> "denied"; };
    }

    /** Exact option text (or its number) is sent as that option; anything else is a custom answer. */
    static String[] questionAnswer(List<String> choices, String text) {
        String trimmed = text.strip();
        if (trimmed.matches("\\d{1,2}")) {
            int index = Integer.parseInt(trimmed) - 1;
            if (index >= 0 && index < choices.size()) return new String[]{choices.get(index), ""};
        }
        for (String choice : choices) if (choice.equalsIgnoreCase(trimmed)) return new String[]{choice, ""};
        return new String[]{"Custom", trimmed};
    }

    private void answerQuestion(Question pending, String text) {
        String[] answerParts = questionAnswer(pending.choices(), text);
        question = null;
        transcript.add(TuiTranscript.Kind.USER, "Answer", "", "Custom".equals(answerParts[0]) ? answerParts[1] : answerParts[0]);
        changed();
        actions.submit(() -> {
            try { backend.answer(pending.runId(), pending.id(), answerParts[0], answerParts[1]); }
            catch (Exception failed) { error("Answer could not be sent: " + failed.getMessage()); }
        });
    }

    public void toggleMode() {
        if (running) { info("Mode can be switched after the current task finishes (Ctrl+C stops it)."); return; }
        switchMode("agent".equals(mode) ? "analyse" : "agent");
    }

    private void switchMode(String next) {
        try {
            workspace = backend.mode(next);
            mode = next;
            info("Mode: " + label(next) + (next.equals("agent") ? " — can edit files and run commands (with approvals)" : " — read-only analysis"));
        } catch (Exception failed) { error("Mode change failed: " + failed.getMessage()); }
    }

    /** Ctrl+C while running / "/stop". */
    public void stop() {
        if (!running) {
            // ELIYA184: no task here, but one left running by a closed terminal may still hold this workspace.
            actions.submit(() -> {
                try {
                    if (backend.cancel()) info("Stopped the Agent task that was still running in this workspace. Finished work is kept.");
                    else info("Nothing is running.");
                } catch (Exception failed) { error("Stop failed: " + failed.getMessage()); }
            });
            return;
        }
        userStopped = true;
        activity = "stopping…";
        changed();
        actions.submit(() -> {
            try { if (!backend.cancel()) info("No active run found for this terminal."); }
            catch (Exception failed) { error("Stop failed: " + failed.getMessage()); }
        });
    }

    /** "/skip": skip the running step (the server interrupts its command); "/progress": status snapshot. */
    private void controlRunningTask(String text, String idleMessage) {
        if (!running || runId.isBlank()) { info(idleMessage); return; }
        addToRunningTask(runId, text);
    }

    // ------------------------------------------------------------------------------------------------- commands

    private void command(String text) {
        String[] parts = text.split("\\s+", 2);
        String name = parts[0].toLowerCase(Locale.ROOT);
        String argument = parts.length > 1 ? parts[1].strip() : "";
        switch (name) {
            case "/help", "/?" -> info(help());
            case "/analyse", "/analyze", "/agent" -> {
                String next = name.equals("/agent") ? "agent" : "analyse";
                if (running) { info("Mode can be switched after the current task finishes."); return; }
                if (!next.equals(mode)) switchMode(next);
                if (!argument.isEmpty()) startRun(next, argument);
            }
            case "/mode" -> toggleMode();
            case "/implement" -> {
                if (running) { info("A task is running; use /queue to run something next."); return; }
                if (!"agent".equals(mode)) switchMode("agent");
                startRun("implement", "");
            }
            case "/check" -> {
                if (running) { info("A task is running; use /queue to run something next."); return; }
                startRun("analyse", "Check the latest task and its result in this workspace conversation against current source evidence. Report a supported verdict, actual findings and limitations. Do not ask for a new prompt or modify files.");
            }
            case "/queue", "/next" -> { if (argument.isEmpty()) info(queueSummary()); else queueNext(argument); }
            case "/send" -> { if (running) info("The queue is sent automatically when the task finishes."); else sendNextQueued(); }
            case "/drop" -> { int count; synchronized (this) { count = queued.size(); queued.clear(); } info("Dropped " + count + " queued message(s)."); }
            case "/stop", "/cancel" -> stop();
            case "/skip" -> controlRunningTask("skip the current step", "Nothing is running — /skip skips the running step of an Agent task.");
            case "/progress" -> controlRunningTask("status", "Nothing is running.");
            case "/skills" -> listSkills(argument);
            case "/skill" -> {
                if (argument.isBlank()) { info("Use /skill name[,name] task, or /skills to browse."); return; }
                if (running) { info("A task is running; use /queue to run the skill next."); return; }
                startRun(mode, text);
            }
            case "/memory" -> memoryCommand(argument);
            case "/new" -> {
                if (running) { info("Stop the current task first (Ctrl+C)."); return; }
                try { workspace = backend.activate(workspace.isBlank() ? null : workspace, true); backend.mode(mode);
                    transcript.clear(); info("New conversation started in " + workspace); }
                catch (Exception failed) { error("Could not start a new conversation: " + failed.getMessage()); }
            }
            case "/workspace", "/cd" -> workspaceCommand(argument);
            case "/status" -> {
                try { loadStatus(); info("Workspace: " + (workspace.isBlank() ? "none" : workspace) + "\nMode: " + label(mode) +
                        "\nModel: " + (modelConfigured ? model() : "not configured") + "\nBrowser UI: " + webUrl); }
                catch (Exception failed) { error("Status unavailable: " + failed.getMessage()); }
            }
            case "/copy" -> {
                String last = transcript.lastAnswer();
                if (last.isBlank()) info("Nothing to copy yet.");
                else info(view == null ? "Clipboard unavailable." : view.copy(last));
            }
            case "/export", "/save" -> export(argument);
            case "/clear" -> { transcript.clear(); changed(); }
            case "/web", "/browser", "/window" -> {
                if (webUrl.isBlank()) { try { loadStatus(); } catch (Exception ignored) { } }
                if (view != null) view.openWeb(webUrl, name.equals("/window"));
                info("Opened the browser UI (same conversation): " + webUrl);
            }
            case "/exit", "/quit" -> { if (view != null) view.exit(); }
            default -> {
                // ELIYA184: "/code-review src/x", "/anydoc file.docx" — run a skill by name or alias.
                TuiBackend.SkillInfo skill = findSkill(name.substring(1));
                if (skill == null) { error("Unknown command " + name + ". Type /help, or /skills for skills."); return; }
                if (running) { info("A task is running; use /queue to run " + name + " next."); return; }
                startRun(mode, text);
            }
        }
    }

    private List<TuiBackend.SkillInfo> skillList() {
        List<TuiBackend.SkillInfo> cached = skillCache;
        if (cached != null) return cached;
        try { cached = List.copyOf(backend.skills()); }
        catch (Exception unavailable) { cached = List.of(); }
        skillCache = cached;
        return cached;
    }

    private TuiBackend.SkillInfo findSkill(String name) {
        TuiBackend.SkillInfo found = matchSkill(skillList(), name);
        if (found == null) {
            // A skill added to the project (or ~/.eliya/skills) after the list was loaded: reload once.
            skillCache = null;
            found = matchSkill(skillList(), name);
        }
        return found;
    }

    private static TuiBackend.SkillInfo matchSkill(List<TuiBackend.SkillInfo> skills, String name) {
        for (TuiBackend.SkillInfo skill : skills) {
            if (skill.name().equalsIgnoreCase(name)) return skill;
            for (String alias : skill.aliases()) if (alias.equalsIgnoreCase(name)) return skill;
        }
        return null;
    }

    private void listSkills(String filter) {
        skillCache = null; // pick up skills installed since the last listing
        List<TuiBackend.SkillInfo> skills = skillList();
        if (skills.isEmpty()) { info("No enabled skills available in this workspace."); return; }
        String f = filter.toLowerCase(Locale.ROOT);
        StringBuilder out = new StringBuilder("Skills — run one with /<name> [task], e.g. /code-review src/main\n");
        for (TuiBackend.SkillInfo skill : skills) {
            String line = skill.name() + " " + skill.description() + " " + String.join(" ", skill.aliases());
            if (!f.isBlank() && !line.toLowerCase(Locale.ROOT).contains(f)) continue;
            out.append("  /").append(skill.name());
            if (!skill.aliases().isEmpty()) out.append(" (/").append(String.join(", /", skill.aliases())).append(')');
            if (!"built-in".equals(skill.source())) out.append(" [").append(skill.source()).append(']');
            out.append("\n      ").append(TuiText.fit(skill.description(), 150)).append('\n');
        }
        info(out.toString().stripTrailing());
    }

    private void memoryCommand(String argument) {
        actions.submit(() -> {
            try {
                if (argument.equalsIgnoreCase("clear")) {
                    int removed = backend.clearMemory();
                    info("Project memory cleared for this workspace (" + removed + " note(s) removed).");
                } else {
                    info("Project memory" + (argument.isBlank() ? " (newest first)" : " matching \"" + argument + "\"") + "\n" +
                            backend.memory(argument) + "\n/memory <words> searches · /memory clear deletes this workspace's notes");
                }
            } catch (Exception failed) { error("Project memory unavailable: " + failed.getMessage()); }
        });
    }

    private void workspaceCommand(String argument) {
        if (argument.isEmpty()) { info("Workspace: " + (workspace.isBlank() ? "none" : workspace)); return; }
        if (running) { info("Stop the current task before changing workspace."); return; }
        String raw = argument.length() > 1 && argument.startsWith("\"") && argument.endsWith("\"")
                ? argument.substring(1, argument.length() - 1) : argument;
        if (raw.startsWith("~")) raw = System.getProperty("user.home") + raw.substring(1);
        Path folder = Path.of(raw);
        if (!folder.isAbsolute() && !workspace.isBlank()) folder = Path.of(workspace).resolve(raw);
        folder = folder.toAbsolutePath().normalize();
        if (!Files.isDirectory(folder)) { error("Directory does not exist: " + folder); return; }
        try { workspace = backend.activate(folder.toString(), false); backend.mode(mode); info("Workspace: " + workspace + " (indexing scheduled)"); }
        catch (Exception failed) { error("Workspace change failed: " + failed.getMessage()); }
    }

    private void export(String argument) {
        try {
            Path target;
            if (argument.isEmpty()) {
                Files.createDirectories(exportDir);
                target = exportDir.resolve("eliya-chat-" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss")) + ".md");
            } else {
                target = Path.of(argument).toAbsolutePath().normalize();
                if (target.getParent() != null) Files.createDirectories(target.getParent());
            }
            Files.writeString(target, transcript.toMarkdown(), StandardCharsets.UTF_8);
            info("Conversation saved to " + target);
        } catch (Exception failed) { error("Export failed: " + failed.getMessage()); }
    }

    private synchronized String queueSummary() {
        if (queued.isEmpty()) return "No queued messages. /queue <text> (or Ctrl+Q while typing) runs a message after the current task.";
        StringBuilder out = new StringBuilder("Queued next:");
        int i = 1;
        for (String item : queued) out.append("\n ").append(i++).append(". ").append(TuiText.fit(item, 120));
        return out.append("\n/send runs the next one now, /drop clears the queue.").toString();
    }

    static String help() {
        return """
                Send: Enter · New line: Alt+Enter, Ctrl+J or Shift+Enter · Paste: multi-line paste stays in the box
                While a task runs: Enter adds your message to the running Agent task (after its current action)
                                   "stop" / "stop and show the results so far" stops it now and shows what was done
                                   "skip this step" moves on · "status" shows progress · Ctrl+Q queues the next task
                Approvals: y = this action, a = all ordinary actions this run, n = deny
                Questions: type the option number, the option text, or your own answer
                Scroll: PgUp/PgDn (mouse wheel works in most terminals) · History: ↑/↓ on an empty box
                Commands:
                  /analyse [task]  read-only analysis      /agent [task]   edit files and run commands
                  /implement       run the last analysis    /check          verify the latest task
                  /queue <text>    run after current task   /send /drop     send or clear the queue
                  /stop            stop the running task    /new            new conversation
                  /skip            skip the running step     /progress       progress of the running task
                  /skills [word]   list enabled skills; /skill name[,name] task runs selected skills
                  /memory [words]  project memory of this workspace (/memory clear deletes it)
                  /workspace <dir> change project           /status         workspace, mode, model
                  /copy            copy the last answer      /export [file]  save conversation as Markdown
                  /web             open the browser UI      /window         browser UI in an app window
                  /clear           clear the screen          /exit           quit (Ctrl+D)
                Select text with the mouse to copy (hold Shift if your terminal needs it).""";
    }

    // --------------------------------------------------------------------------------------------------- runs

    private void startRun(String runMode, String prompt) {
        running = true;
        userStopped = false;
        runId = "";
        activity = "agent".equals(runMode) || "implement".equals(runMode) ? "planning…" : "thinking…";
        runStartedAt = System.currentTimeMillis();
        answer = null;
        lastStep = null;
        if (!prompt.isBlank()) transcript.add(TuiTranscript.Kind.USER, "", "", prompt);
        else transcript.add(TuiTranscript.Kind.USER, "", "", "/implement");
        changed();
        runner.submit(() -> {
            boolean failed = false;
            try { backend.run(runMode, prompt, new RunListener()); }
            catch (Exception failure) { failed = true; error(String.valueOf(failure.getMessage())); }
            finally { finishRun(runMode, failed); }
        });
    }

    private void finishRun(String runMode, boolean failed) {
        approval = null;
        question = null;
        backend.refresh();
        if (!failed && ("agent".equals(runMode) || "implement".equals(runMode)) && !runId.isBlank()) {
            try {
                TuiBackend.RunResult result = backend.latestResult();
                boolean ok = "completed".equals(result.status());
                boolean stoppedByYou = userStopped && "cancelled".equals(result.status());
                transcript.add(TuiTranscript.Kind.RESULT, "Outcome", ok ? "success" : "warning",
                        "Status: " + (stoppedByYou ? "stopped at your request" : result.status()) +
                        (result.verification().isBlank() ? "" : " · " + result.verification()) +
                        (ok ? "" : stoppedByYou ? "\nThe results so far are above. Say \"continue\" to resume, or describe the next task."
                                : "\nDo not treat this task as successfully completed."));
            } catch (Exception unavailable) {
                transcript.add(TuiTranscript.Kind.RESULT, "Outcome", "warning", "Run status unavailable: " + unavailable.getMessage());
            }
        }
        running = false;
        runId = "";
        activity = "";
        answer = null;
        changed();
        boolean hasQueued;
        synchronized (this) { hasQueued = !queued.isEmpty(); }
        if (hasQueued) {
            if (userStopped) info("Task stopped. Queued messages are kept: /send runs the next one, /drop clears them.");
            else sendNextQueued();
        }
    }

    private void sendNextQueued() {
        String next;
        synchronized (this) { next = queued.pollFirst(); }
        if (next == null) { info("The queue is empty."); return; }
        startRun(mode, next);
    }

    private final class RunListener implements TuiBackend.Listener {
        private final StringBuilder streamed = new StringBuilder();

        @Override public void token(String text) {
            streamed.append(text);
            TuiTranscript.Entry current = answer;
            if (current == null) { answer = transcript.add(TuiTranscript.Kind.ASSISTANT, "", "", text); lastStep = null; }
            else transcript.append(current, text);
            activity = "writing…";
            changed();
        }

        @Override public void runId(String id) {
            runId = id;
            transcript.add(TuiTranscript.Kind.ACTIVITY, "Agent", "info", "Run " + id);
            changed();
        }

        @Override public void step(String tool, String status, String detail, String step, String approvalId, String approvalType) {
            String description = step == null || step.isBlank() ? detail : step + ": " + detail;
            activity = tool + (detail.isBlank() ? "" : " · " + TuiText.fit(detail, 60));
            TuiTranscript.Entry previous = lastStep;
            if (previous != null && previous == transcript.last() && previous.title().equals(tool)
                    && "running".equals(previous.status()) && approvalId.isBlank()) {
                transcript.update(previous, status, description);
            } else {
                lastStep = transcript.add(TuiTranscript.Kind.ACTIVITY, tool, status, description);
            }
            answer = null; // text after tool activity starts a new answer block
            if (!approvalId.isBlank() && !runId.isBlank()) {
                boolean allowRun = !"file_deletion".equals(approvalType);
                if (autoApprove && allowRun) {
                    transcript.add(TuiTranscript.Kind.ACTIVITY, "Approval", "info", "Auto-approved for this run (--yes)");
                    String id = runId;
                    actions.submit(() -> {
                        try { backend.approve(id, approvalId, "run"); }
                        catch (Exception failed) { error("Auto-approval failed: " + failed.getMessage()); }
                    });
                } else {
                    approval = new Approval(runId, approvalId, description, allowRun);
                    transcript.add(TuiTranscript.Kind.APPROVAL, "Approval needed", "", description + "\n" +
                            (allowRun ? "y = allow this action · a = allow all ordinary actions this run · n = deny"
                                      : "Deletion — y = allow this deletion · n = deny"));
                    lastStep = null;
                }
            }
            changed();
        }

        @Override public void question(String id, String reason, List<String> choices) {
            if (id.isBlank() || runId.isBlank()) return;
            question = new Question(runId, id, reason, List.copyOf(choices));
            StringBuilder text = new StringBuilder(reason);
            for (int i = 0; i < choices.size(); i++) text.append("\n  ").append(i + 1).append(". ").append(choices.get(i));
            text.append("\nType a number, the option, or your own answer.");
            transcript.add(TuiTranscript.Kind.QUESTION, "Question", "", text.toString());
            answer = null;
            lastStep = null;
            changed();
        }

        @Override public void changes(String count) {
            transcript.add(TuiTranscript.Kind.ACTIVITY, "Files", "success", "Changed files: " + (count.isBlank() ? "see report" : count));
            changed();
        }

        @Override public void status(String phase, String detail) {
            if (!detail.isBlank()) activity = TuiText.fit(detail, 70);
            changed();
        }

        @Override public void error(String message) {
            transcript.add(TuiTranscript.Kind.ERROR, "", "", message);
            changed();
        }

        @Override public void stopped(String message) {
            transcript.add(TuiTranscript.Kind.ERROR, "Stopped", "", message);
            changed();
        }

        @Override public void done(String content) {
            String all = streamed.toString();
            String missing = all.isEmpty() ? content
                    : content.length() > all.length() && content.startsWith(all) ? content.substring(all.length()) : "";
            if (!missing.isBlank()) {
                TuiTranscript.Entry current = answer;
                if (current != null && !all.isEmpty()) transcript.append(current, missing);
                else transcript.add(TuiTranscript.Kind.ASSISTANT, "", "", missing);
            }
            changed();
        }
    }

    public void shutdown() {
        runner.shutdownNow();
        actions.shutdownNow();
    }
}
