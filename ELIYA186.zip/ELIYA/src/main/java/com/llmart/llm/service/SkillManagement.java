package com.llmart.llm.service;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

/** User-initiated local skill management; no execution or implicit installation. */
public final class SkillManagement {
    private SkillManagement() {}
    public static List<Map<String,Object>> list(Path root) {
        Set<String> disabled=SkillSelection.disabled(root);
        return SkillCatalog.discoverAll(root).stream().map(skill -> {
            Map<String,Object> item=new LinkedHashMap<>();
            item.put("name",skill.name()); item.put("description",skill.description()); item.put("source",skill.source());
            item.put("aliases",skill.aliases()); item.put("enabled",!disabled.contains(skill.name().toLowerCase(Locale.ROOT)));
            item.put("triggers",SkillSelection.metadata(skill,"triggers")); item.put("verification",SkillSelection.metadata(skill,"verification"));
            return item;
        }).toList();
    }
    public static SkillCatalog.Skill get(Path root,String name) {
        return SkillCatalog.discoverAll(root).stream().filter(s -> s.name().equalsIgnoreCase(name)).findFirst()
                .orElseThrow(() -> new IllegalArgumentException("Skill not found: "+name));
    }
    public static synchronized void save(Path root,String name,String content,boolean overwrite) throws IOException {
        if (name==null || !name.matches("[a-z][a-z0-9-]{1,62}")) throw new IllegalArgumentException("Use a lowercase hyphenated skill name (2–63 characters)");
        if(content==null || content.isBlank() || content.getBytes(StandardCharsets.UTF_8).length>256*1024) throw new IllegalArgumentException("Skill content must be nonempty and at most 256 KB");
        content=content.strip().replace("\r\n", "\n");
        if(!content.startsWith("---\n")) throw new IllegalArgumentException("SKILL.md needs YAML front matter");
        int end=content.indexOf("\n---",4);
        if(end<0 || (end+4<content.length() && content.charAt(end+4)!='\n')) throw new IllegalArgumentException("Close the YAML front matter with ---");
        String header=content.substring(4,end);
        if(!java.util.regex.Pattern.compile("(?m)^description:\\s*[^\\s].*$").matcher(header).find()) throw new IllegalArgumentException("Description required in front matter");
        // Keep the canonical directory id and the declared YAML name consistent.
        if(java.util.regex.Pattern.compile("(?m)^name:").matcher(header).find())
            header=header.replaceFirst("(?m)^name:.*$", "name: "+name);
        else header="name: "+name+"\n"+header;
        content="---\n"+header+content.substring(end);
        var parsed=SkillCatalog.parse(content,name,"custom","");
        if(parsed.description().isBlank()) throw new IllegalArgumentException("Description required");
        for(String check:SkillSelection.metadata(parsed,"verification")) if(!Set.of("workspace","tests").contains(check)) throw new IllegalArgumentException("Unknown verification check: "+check);
        Path base=root==null?Path.of(System.getProperty("user.home", ".")).toRealPath():WorkspaceRootGuard.requireNarrow(root.toRealPath());
        Path dest=base.resolve(root==null?".eliya/skills":".agents/skills").resolve(name).resolve("SKILL.md");
        safePath(base,dest);
        if(Files.exists(dest,LinkOption.NOFOLLOW_LINKS) && !overwrite) throw new IllegalArgumentException("Skill already exists. Select it and explicitly save changes.");
        atomicWrite(dest,content.strip()+"\n",overwrite);
    }
    public static synchronized void toggle(Path root,String name,boolean enabled) throws IOException {
        var skill=get(root,name);
        Path base=root==null?Path.of(System.getProperty("user.home", ".")).toRealPath():WorkspaceRootGuard.requireNarrow(root.toRealPath());
        Path dest=base.resolve(root==null?".eliya/disabled-skills.txt":".agents/disabled-skills.txt");
        safePath(base,dest);
        Set<String> disabled=new TreeSet<>(SkillSelection.scopeSettings(root));
        String key=skill.name().toLowerCase(Locale.ROOT);
        disabled.remove(key); disabled.remove("+"+key);
        if(!enabled) disabled.add(key); else if(root!=null) disabled.add("+"+key);
        atomicWrite(dest,String.join("\n",disabled)+"\n",true);
    }
    private static void safePath(Path base,Path dest) {
        if(!dest.normalize().startsWith(base)) throw new SecurityException("Skill path escapes scope");
        Path current=base;
        for(Path segment:base.relativize(dest)) {
            current=current.resolve(segment);
            if(Files.isSymbolicLink(current)) throw new SecurityException("Skill path contains a symbolic link");
        }
    }
    private static void atomicWrite(Path dest,String text,boolean overwrite) throws IOException {
        Files.createDirectories(dest.getParent());
        Path tmp=Files.createTempFile(dest.getParent(),".skill-", ".tmp");
        try {
            Files.writeString(tmp,text,StandardCharsets.UTF_8);
            if(!overwrite) Files.move(tmp,dest);
            else {
                try { Files.move(tmp,dest,StandardCopyOption.ATOMIC_MOVE,StandardCopyOption.REPLACE_EXISTING); }
                catch(AtomicMoveNotSupportedException e) { Files.move(tmp,dest,StandardCopyOption.REPLACE_EXISTING); }
            }
        } finally { Files.deleteIfExists(tmp); }
    }
}
