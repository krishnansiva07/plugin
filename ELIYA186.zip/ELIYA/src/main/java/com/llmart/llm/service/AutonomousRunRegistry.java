package com.llmart.llm.service;

import java.time.Duration;
import java.time.Instant;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Marks conversations that belong to unattended (headless) runs and carries their budget.
 * The executor consults it per turn; interactive browser/terminal runs are unaffected unless a
 * user-level budget is configured in {@code ~/.eliya/policy.json}.
 */
public final class AutonomousRunRegistry {
    /** Limits for one run; 0 means unlimited. */
    public record Budget(long maxMinutes, long maxTurns, long maxTokens) {
        public static final Budget NONE = new Budget(0, 0, 0);

        public static Budget headlessDefault() {
            return new Budget(longProp("eliya.autonomous.maxMinutes", 60),
                    longProp("eliya.autonomous.maxTurns", 300),
                    longProp("eliya.autonomous.maxTokens", 3_000_000));
        }

        /** Exceeded limit description, or null while within budget. */
        public String exceeded(Instant startedAt, long turns, long tokens) {
            if (maxMinutes > 0 && startedAt != null &&
                    Duration.between(startedAt, Instant.now()).toMinutes() >= maxMinutes)
                return "time budget of " + maxMinutes + " minute(s)";
            if (maxTurns > 0 && turns > maxTurns) return "turn budget of " + maxTurns + " model turns";
            if (maxTokens > 0 && tokens > maxTokens) return "token budget of " + maxTokens + " provider tokens";
            return null;
        }

        /** Tightest non-zero value of each limit. */
        public Budget min(Budget other) {
            return new Budget(tight(maxMinutes, other.maxMinutes), tight(maxTurns, other.maxTurns), tight(maxTokens, other.maxTokens));
        }

        private static long tight(long a, long b) { return a <= 0 ? b : b <= 0 ? a : Math.min(a, b); }
    }

    private record Entry(boolean headless, Budget budget) { }

    private static final Map<String, Entry> BY_CONVERSATION = new ConcurrentHashMap<>();

    private AutonomousRunRegistry() { }

    public static void register(String conversationId, boolean headless, Budget budget) {
        if (conversationId != null) BY_CONVERSATION.put(conversationId, new Entry(headless, budget == null ? Budget.NONE : budget));
    }

    public static void unregister(String conversationId) {
        if (conversationId != null) BY_CONVERSATION.remove(conversationId);
    }

    public static boolean isHeadless(String conversationId) {
        Entry entry = conversationId == null ? null : BY_CONVERSATION.get(conversationId);
        return entry != null && entry.headless();
    }

    /** Effective budget: the run's own budget combined with the user policy file budget. */
    public static Budget budgetFor(String conversationId) {
        Entry entry = conversationId == null ? null : BY_CONVERSATION.get(conversationId);
        Map<String,Long> user = AgentCommandPolicy.userBudget();
        Budget fromUser = new Budget(user.getOrDefault("maxMinutes", 0L), user.getOrDefault("maxTurns", 0L),
                user.getOrDefault("maxTokens", 0L));
        return entry == null ? fromUser : entry.budget().min(fromUser);
    }

    private static long longProp(String name, long fallback) {
        try { return Math.max(0, Long.parseLong(System.getProperty(name, Long.toString(fallback)).trim())); }
        catch (NumberFormatException invalid) { return fallback; }
    }
}
