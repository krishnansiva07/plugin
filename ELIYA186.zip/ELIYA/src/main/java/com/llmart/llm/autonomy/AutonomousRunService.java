package com.llmart.llm.autonomy;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.llmart.llm.dto.ChatRequest;
import com.llmart.llm.dto.ChatSettings;
import com.llmart.llm.dto.ProjectDto;
import com.llmart.llm.service.AgentApprovalService;
import com.llmart.llm.service.AgentRunService;
import com.llmart.llm.service.AutonomousRunRegistry;
import com.llmart.llm.service.ChatService;
import com.llmart.llm.service.ConversationService;
import com.llmart.llm.service.LocalProjectIndexService;
import com.llmart.llm.service.ProjectService;
import org.springframework.stereotype.Service;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.time.Instant;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.BiConsumer;
import java.util.function.Supplier;

/**
 * Runs an Agent task unattended on the local machine, using the same Agent pipeline as the browser/terminal.
 *
 * <ul>
 *   <li><b>Isolation:</b> in a git repository the run works in its own worktree + branch
 *       ({@code eliya/auto-...}); the user's checkout is never modified. Outside git, or with
 *       {@code inPlace}, it works in the workspace with the existing rollback snapshots.</li>
 *   <li><b>Headless safety:</b> ordinary actions are auto-approved; command-policy "ask" rules become deny;
 *       any approval prompt that still appears (e.g. file deletion in-place) is denied automatically.</li>
 *   <li><b>Budgets:</b> time/turn/token limits stop the run cleanly as "blocked".</li>
 *   <li><b>Results:</b> changes are committed on the branch; {@code report.md} and {@code result.json} are written
 *       under {@code <data-dir>/autonomous-runs/<id>/}; a desktop notification is shown.</li>
 * </ul>
 */
@Service
public class AutonomousRunService {
    /** Model credentials and settings for a run (never written to reports). */
    public record ModelAccess(String apiKey, ChatSettings settings) { }

    /** What to run. Budget values of 0 use the headless defaults. */
    public record RunRequest(String task, String workspace, boolean inPlace, long maxMinutes, long maxTurns,
                             long maxTokens, String trigger, boolean keepWorktree) {
        public RunRequest {
            if (task == null || task.isBlank()) throw new IllegalArgumentException("Task text is required");
            if (workspace == null || workspace.isBlank()) throw new IllegalArgumentException("Workspace path is required");
            trigger = trigger == null || trigger.isBlank() ? "manual" : trigger;
        }
    }

    /** Final outcome, also persisted as result.json. */
    public record RunResult(String id, String status, String workspace, String executionRoot, String branch,
                            String commit, List<String> changedFiles, String diffStat, String answer,
                            String lastVerification, String reportPath, String trigger, String startedAt,
                            String finishedAt, long providerTokens, List<String> notes) {
        public int exitCode() {
            return switch (status) { case "completed" -> 0; case "blocked" -> 3; default -> 1; };
        }
    }

    private static final ObjectMapper JSON = new ObjectMapper()
            .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false)
            .enable(SerializationFeature.INDENT_OUTPUT);

    private final ChatService chat;
    private final ConversationService conversations;
    private final ProjectService projects;
    private final LocalProjectIndexService indexJobs;
    private final AgentRunService agentRuns;
    private final AgentApprovalService approvals;
    private final Set<String> busyWorkspaces = ConcurrentHashMap.newKeySet();
    private volatile Supplier<ModelAccess> defaultModel = () -> null;

    public AutonomousRunService(ChatService chat, ConversationService conversations, ProjectService projects,
                                LocalProjectIndexService indexJobs, AgentRunService agentRuns,
                                AgentApprovalService approvals) {
        this.chat = chat;
        this.conversations = conversations;
        this.projects = projects;
        this.indexJobs = indexJobs;
        this.agentRuns = agentRuns;
        this.approvals = approvals;
    }

    /** The CLI bridge supplies its effective settings (terminal/browser/server config) for triggered runs. */
    public void setDefaultModel(Supplier<ModelAccess> supplier) {
        if (supplier != null) defaultModel = supplier;
    }

    public ModelAccess defaultModel() {
        return defaultModel.get();
    }

    public static Path dataDirectory() {
        String data = System.getProperty("app.data-dir");
        return data == null || data.isBlank() ? Path.of(System.getProperty("user.home"), ".eliya") : Path.of(data);
    }

    /**
     * Execute synchronously on the calling thread. {@code observer} receives the same events as a terminal run
     * plus {@code autonomous} status events; it may be null.
     */
    public RunResult run(RunRequest request, ModelAccess model, BiConsumer<String,Object> observer) throws Exception {
        BiConsumer<String,Object> out = observer == null ? (e, d) -> { } : observer;
        ModelAccess access = model != null ? model : defaultModel.get();
        if (access == null || access.apiKey() == null || access.apiKey().isBlank() || access.settings() == null)
            throw new IllegalStateException("No model configured. Run `eliya setup`, set ELIYA_BASE_URL/ELIYA_API_KEY/ELIYA_MODEL, or save browser Settings.");
        Path workspace = Path.of(request.workspace()).toAbsolutePath().normalize();
        if (!Files.isDirectory(workspace)) throw new IllegalArgumentException("Workspace directory does not exist: " + workspace);
        String lockKey = workspace.toRealPath().toString();
        if (!busyWorkspaces.add(lockKey))
            throw new IllegalStateException("Another autonomous run is already working on " + workspace);

        String id = UUID.randomUUID().toString().replace("-", "").substring(0, 12);
        Path runDir = dataDirectory().resolve("autonomous-runs").resolve(id);
        Files.createDirectories(runDir);
        Instant started = Instant.now();
        List<String> notes = java.util.Collections.synchronizedList(new java.util.ArrayList<>());
        GitWorktreeManager worktrees = new GitWorktreeManager(dataDirectory().resolve("worktrees"));
        GitWorktreeManager.Worktree worktree = null;
        String conversationId = null;
        StringBuilder answer = new StringBuilder();
        String[] runIdHolder = {""};
        try {
            Path executionRoot = workspace;
            if (!request.inPlace() && GitWorktreeManager.isGitRepository(workspace)) {
                worktree = worktrees.create(workspace, id, request.task());
                executionRoot = worktree.path();
                notes.add("Isolated in git worktree on branch " + worktree.branch() + " (your working copy was not modified).");
                if (worktree.baseWasDirty())
                    notes.add("Your workspace had uncommitted changes; the run started from the last commit and does not include them.");
            } else if (!request.inPlace()) {
                notes.add("Workspace is not a git repository: ran in place with ELIYA rollback snapshots.");
            } else {
                notes.add("Ran in place (--in-place); ELIYA rollback snapshots protect the run.");
            }
            out.accept("autonomous", Map.of("id", id, "phase", "started", "executionRoot", executionRoot.toString(),
                    "branch", worktree == null ? "" : worktree.branch()));

            conversationId = conversations.create().getId();
            ProjectDto project = projects.createLocal(conversationId, executionRoot.toString(),
                    "ELIYA auto " + GitWorktreeManager.slug(request.task(), 30));
            indexJobs.request(project, false);
            AutonomousRunRegistry.Budget budget = AutonomousRunRegistry.Budget.headlessDefault().min(
                    new AutonomousRunRegistry.Budget(request.maxMinutes(), request.maxTurns(), request.maxTokens()));
            AutonomousRunRegistry.register(conversationId, true, budget);

            ChatSettings headless = HeadlessSettings.from(access.settings(), worktree != null);
            ChatRequest chatRequest = new ChatRequest(conversationId, prompt(request, worktree != null), List.of(),
                    project.id(), "agent", false, headless);
            chat.runTerminal(access.apiKey(), chatRequest, (event, data) -> {
                if ("meta".equals(event) && data instanceof Map<?,?> meta && meta.get("agentRunId") != null)
                    runIdHolder[0] = String.valueOf(meta.get("agentRunId"));
                if ("done".equals(event) && data instanceof Map<?,?> done && done.get("content") != null) {
                    answer.setLength(0);
                    answer.append(done.get("content"));
                }
                if ("agent_step".equals(event) && data instanceof Map<?,?> step && step.get("approvalId") != null
                        && !runIdHolder[0].isBlank()) {
                    // Unattended: nobody can answer. Deny, and let the Agent choose a permitted path.
                    approvals.resolveForRun(String.valueOf(step.get("approvalId")), runIdHolder[0], AgentApprovalService.Decision.DENY);
                    notes.add("Auto-denied an approval request: " + step.get("detail"));
                }
                out.accept(event, data);
            });

            Map<String,Object> snapshot = agentRuns.latestForConversation(conversationId).orElse(Map.of());
            String status = String.valueOf(snapshot.getOrDefault("status", "failed"));
            if (!Set.of("completed", "blocked", "failed", "cancelled").contains(status)) status = "failed";
            String verification = String.valueOf(snapshot.getOrDefault("lastVerification", ""));
            long tokens = tokens(snapshot.get("tokenUsage"));

            GitWorktreeManager.Outcome outcome = null;
            if (worktree != null) {
                outcome = worktrees.finish(worktree, "ELIYA autonomous run " + id + " (" + status + "): " +
                        oneLine(request.task(), 120), request.keepWorktree());
                if (!outcome.committed()) notes.add("No file changes were produced; the empty branch was removed.");
                else notes.add("Review: git log " + worktree.branch() + "  |  merge: git merge " + worktree.branch());
            }
            RunResult result = new RunResult(id, status, workspace.toString(), executionRoot.toString(),
                    outcome != null && outcome.committed() ? worktree.branch() : "",
                    outcome == null ? "" : outcome.commit(), outcome == null ? List.of() : outcome.changedFiles(),
                    outcome == null ? "" : outcome.diffStat(), answer.toString(), verification,
                    runDir.resolve("report.md").toString(), request.trigger(), started.toString(), Instant.now().toString(),
                    tokens, List.copyOf(notes));
            writeReport(runDir, request, result);
            notifyResult(result, request);
            out.accept("autonomous", Map.of("id", id, "phase", "finished", "status", status,
                    "report", result.reportPath(), "branch", result.branch()));
            return result;
        } catch (Exception failure) {
            notes.add("Runner error: " + failure.getMessage());
            if (worktree != null) {
                try { worktrees.finish(worktree, "ELIYA autonomous run " + id + " (failed): partial work", request.keepWorktree()); }
                catch (Exception ignored) { notes.add("Worktree cleanup failed; remove it with: git worktree prune"); }
            }
            RunResult result = new RunResult(id, "failed", workspace.toString(), worktree == null ? workspace.toString() : worktree.path().toString(),
                    worktree == null ? "" : worktree.branch(), "", List.of(), "", answer.toString(), "",
                    runDir.resolve("report.md").toString(), request.trigger(), started.toString(), Instant.now().toString(), 0, List.copyOf(notes));
            writeReport(runDir, request, result);
            notifyResult(result, request);
            throw failure;
        } finally {
            AutonomousRunRegistry.unregister(conversationId);
            busyWorkspaces.remove(lockKey);
        }
    }

    private static String prompt(RunRequest request, boolean isolated) {
        return request.task().strip() + "\n\n[Unattended ELIYA run: nobody is available to answer questions or approvals. " +
                "Make reasonable, conservative decisions, stay within the requested scope, verify your work with the " +
                "project's build/tests, and finish with a clear summary of what changed and what remains." +
                (isolated ? " You are working on an isolated git branch; do not push, merge or switch branches." : "") + "]";
    }

    private void writeReport(Path runDir, RunRequest request, RunResult result) {
        try {
            Files.writeString(runDir.resolve("result.json"), JSON.writeValueAsString(result), StandardCharsets.UTF_8);
            StringBuilder md = new StringBuilder("# ELIYA autonomous run ").append(result.id()).append("\n\n");
            md.append("| Field | Value |\n| --- | --- |\n");
            row(md, "Status", "**" + result.status() + "**");
            row(md, "Trigger", result.trigger());
            row(md, "Workspace", result.workspace());
            row(md, "Branch", result.branch().isBlank() ? "(none)" : "`" + result.branch() + "`");
            row(md, "Commit", result.commit().isBlank() ? "(none)" : "`" + result.commit() + "`");
            row(md, "Started", result.startedAt());
            row(md, "Finished", result.finishedAt());
            row(md, "Duration", Duration.between(Instant.parse(result.startedAt()), Instant.parse(result.finishedAt())).toSeconds() + " s");
            row(md, "Provider tokens", Long.toString(result.providerTokens()));
            md.append("\n## Task\n\n").append(request.task().strip()).append("\n");
            md.append("\n## Result\n\n").append(result.answer().isBlank() ? "_No final answer was produced._" : result.answer().strip()).append("\n");
            if (!result.lastVerification().isBlank() && !"null".equals(result.lastVerification()))
                md.append("\n## Last verification\n\n```\n").append(result.lastVerification().strip()).append("\n```\n");
            if (!result.changedFiles().isEmpty()) {
                md.append("\n## Changed files\n\n");
                for (String file : result.changedFiles()) md.append("- `").append(file).append("`\n");
                if (!result.diffStat().isBlank()) md.append("\n```\n").append(result.diffStat()).append("\n```\n");
            }
            if (!result.notes().isEmpty()) {
                md.append("\n## Notes\n\n");
                for (String note : result.notes()) md.append("- ").append(note).append("\n");
            }
            Files.writeString(runDir.resolve("report.md"), md.toString(), StandardCharsets.UTF_8);
        } catch (Exception ignored) { /* the run outcome is still returned to the caller */ }
    }

    private void notifyResult(RunResult result, RunRequest request) {
        new LocalNotifier(dataDirectory().resolve("autonomous-runs").resolve("notifications.log")).notify(
                "ELIYA run " + result.status(),
                oneLine(request.task(), 80) + (result.branch().isBlank() ? "" : " → " + result.branch()) +
                        " (" + result.changedFiles().size() + " file(s)). Report: " + result.reportPath());
    }

    private static void row(StringBuilder md, String key, String value) {
        md.append("| ").append(key).append(" | ").append(value.replace("|", "\\|")).append(" |\n");
    }

    private static long tokens(Object usage) {
        if (usage instanceof Map<?,?> map) {
            Object total = map.get("providerTotalTokens");
            if (total == null) total = map.get("totalTokens");
            if (total instanceof Number number) return number.longValue();
        }
        return 0;
    }

    private static String oneLine(String text, int max) {
        String value = text == null ? "" : text.replaceAll("\\s+", " ").strip();
        return value.length() <= max ? value : value.substring(0, max - 1) + "…";
    }
}
