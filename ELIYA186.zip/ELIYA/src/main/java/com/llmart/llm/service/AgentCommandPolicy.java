package com.llmart.llm.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Pattern;

/**
 * Local allow / ask / deny rules for shell commands the Agent wants to run (OpenCode-style permissions).
 *
 * <p>Rule sources, evaluated in order; within a layer the LAST matching rule wins:</p>
 * <ol>
 *   <li>Hard denies (built in, never overridable): disk formatting, recursive deletion of a root or home,
 *       shutdown/reboot, fork bombs, piping downloads into a shell.</li>
 *   <li>Defaults (built in): {@code git push}, {@code npm publish}, {@code mvn deploy} and similar ask; common
 *       read-only/build commands are allowed. Headless (unattended) runs turn every "ask" into "deny", because
 *       nobody is there to answer.</li>
 *   <li>User file {@code ~/.eliya/policy.json} (or {@code ELIYA_POLICY}): may allow, ask or deny anything except hard denies.</li>
 *   <li>Workspace file {@code <workspace>/.eliya/policy.json}: may only TIGHTEN (ask/deny). Allow rules from a
 *       repository are ignored, so a cloned repo cannot grant itself permissions.</li>
 * </ol>
 *
 * <p>File format: {@code {"commands":[{"pattern":"mvn *","effect":"allow"},{"pattern":"git push*","effect":"deny"}],
 * "budget":{"maxMinutes":60,"maxTurns":300,"maxTokens":3000000}}}. Patterns are globs ({@code *}, {@code ?})
 * matched case-insensitively against each segment of a chained command ({@code &&}, {@code ||}, {@code ;}, {@code |}).</p>
 */
public final class AgentCommandPolicy {
    public enum Effect { ALLOW, ASK, DENY }

    /** Outcome for one command. {@code effect == null} means no rule matched: keep the normal permission. */
    public record Decision(Effect effect, String rule, String segment) {
        static final Decision NONE = new Decision(null, "", "");
        public boolean denied() { return effect == Effect.DENY; }
        public boolean asks() { return effect == Effect.ASK; }
        public boolean allowed() { return effect == Effect.ALLOW; }
    }

    record Rule(String pattern, Effect effect, String source, Pattern compiled) {
        static Rule of(String pattern, Effect effect, String source) {
            return new Rule(pattern, effect, source, glob(pattern));
        }
        boolean matches(String segment) { return compiled.matcher(segment).matches(); }
    }

    private static final ObjectMapper JSON = new ObjectMapper();
    private static final Pattern SPLIT = Pattern.compile("\\s*(?:&&|\\|\\||;|\\||\\r?\\n)\\s*");
    private static final Map<Path, Cached> CACHE = new ConcurrentHashMap<>();

    private static final List<Pattern> HARD_DENY = List.of(
            Pattern.compile("(?i)\\brm\\s+(?:-[a-z]*r[a-z]*f?|-[a-z]*f[a-z]*r)[a-z]*\\s+(?:--no-preserve-root\\s+)?(?:/|~|\\$home|/\\*|~/\\*)(?:\\s|$)"),
            Pattern.compile("(?i)\\b(?:mkfs(?:\\.\\w+)?|fdisk|diskpart|format\\s+[a-z]:)"),
            Pattern.compile("(?i)\\bdd\\s+.*\\bof=/dev/(?:sd|nvme|hd|disk)"),
            Pattern.compile("(?i)\\b(?:shutdown|reboot|poweroff|halt|init\\s+0|stop-computer|restart-computer)\\b"),
            Pattern.compile(":\\(\\)\\s*\\{\\s*:\\|:&\\s*\\};:"),
            Pattern.compile("(?i)\\b(?:curl|wget|iwr|invoke-webrequest)\\b[^|]*\\|\\s*(?:sudo\\s+)?(?:sh|bash|zsh|pwsh|powershell|iex)\\b"),
            Pattern.compile("(?i)\\b(?:del|erase)\\s+(?:/[a-z]\\s+)*[a-z]:\\\\(?:\\*|\\s|$)"),
            Pattern.compile("(?i)\\b(?:rd|rmdir)\\s+(?:/[a-z]\\s+)*[a-z]:\\\\?(?:\\s|$)"),
            Pattern.compile("(?i)remove-item\\s+.*-recurse.*\\s[a-z]:\\\\?(?:\\s|$)"),
            Pattern.compile("(?i)\\bchmod\\s+-r\\s+777\\s+/(?:\\s|$)"));

    private static final List<Rule> DEFAULTS = List.of(
            // Publishing / remote side effects: require a human by default (denied when headless).
            Rule.of("git push*", Effect.ASK, "default"),
            Rule.of("git remote set-url*", Effect.ASK, "default"),
            Rule.of("git reset --hard*", Effect.ASK, "default"),
            Rule.of("git clean -*f*", Effect.ASK, "default"),
            Rule.of("git checkout -- *", Effect.ASK, "default"),
            Rule.of("npm publish*", Effect.ASK, "default"),
            Rule.of("yarn publish*", Effect.ASK, "default"),
            Rule.of("pnpm publish*", Effect.ASK, "default"),
            Rule.of("mvn*deploy*", Effect.ASK, "default"),
            Rule.of("gradle*publish*", Effect.ASK, "default"),
            Rule.of("docker push*", Effect.ASK, "default"),
            Rule.of("kubectl *", Effect.ASK, "default"),
            Rule.of("terraform apply*", Effect.ASK, "default"),
            Rule.of("sudo *", Effect.ASK, "default"),
            Rule.of("runas *", Effect.ASK, "default"));

    private record Cached(long modified, List<Rule> rules, Map<String,Long> budget) { }

    private AgentCommandPolicy() { }

    /** Shell-capable tools whose command text is checked. */
    public static boolean isShellTool(String tool) {
        return tool != null && (tool.equals("bash") || tool.equals("resource_bash") || tool.equals("process_start"));
    }

    public static Decision evaluate(String command, Path workspaceRoot, boolean headless) {
        return evaluate(command, userPolicyFile(), workspaceRoot == null ? null : workspaceRoot.resolve(".eliya").resolve("policy.json"), headless);
    }

    /** Test hook with explicit policy files. */
    public static Decision evaluateForTest(String command, Path userFile, Path workspaceFile, boolean headless) {
        return evaluate(command, userFile, workspaceFile, headless);
    }

    static Decision evaluate(String command, Path userFile, Path workspaceFile, boolean headless) {
        if (command == null || command.isBlank()) return Decision.NONE;
        String normalized = command.strip().replaceAll("[ \\t]+", " ");
        for (Pattern hard : HARD_DENY) {
            if (hard.matcher(normalized).find()) return new Decision(Effect.DENY, "hard-deny: " + hard.pattern(), normalized);
        }
        List<Rule> rules = new ArrayList<>(DEFAULTS);
        rules.addAll(load(userFile, "user", true).rules());
        rules.addAll(load(workspaceFile, "workspace", false).rules());

        Decision strictest = null;
        boolean allSegmentsAllowed = true;
        for (String segment : SPLIT.split(normalized)) {
            String value = segment.strip();
            if (value.isEmpty()) continue;
            Rule match = null;
            for (Rule rule : rules) if (rule.matches(value)) match = rule; // last match wins
            if (match == null) { allSegmentsAllowed = false; continue; }
            Effect effect = match.effect();
            if (headless && effect == Effect.ASK) effect = Effect.DENY; // nobody can answer an unattended prompt
            Decision decision = new Decision(effect, match.source() + ": " + match.pattern(), value);
            if (effect != Effect.ALLOW) allSegmentsAllowed = false;
            if (strictest == null || rank(effect) > rank(strictest.effect())) strictest = decision;
        }
        if (strictest == null) return Decision.NONE;
        if (strictest.effect() == Effect.ALLOW && !allSegmentsAllowed) return Decision.NONE; // partial allow grants nothing
        return strictest;
    }

    /** Budget limits from the user policy file (workspace files cannot raise budgets). */
    public static Map<String,Long> userBudget() {
        return load(userPolicyFile(), "user", true).budget();
    }

    static Path userPolicyFile() {
        String override = System.getenv("ELIYA_POLICY");
        if (override != null && !override.isBlank()) return Path.of(override);
        return Path.of(System.getProperty("user.home"), ".eliya", "policy.json");
    }

    private static int rank(Effect effect) {
        return effect == Effect.DENY ? 3 : effect == Effect.ASK ? 2 : 1;
    }

    private static Cached load(Path file, String source, boolean allowRulesTrusted) {
        if (file == null || !Files.isRegularFile(file)) return new Cached(0, List.of(), Map.of());
        try {
            long modified = Files.getLastModifiedTime(file).toMillis();
            Cached cached = CACHE.get(file);
            if (cached != null && cached.modified() == modified) return cached;
            JsonNode root = JSON.readTree(file.toFile());
            List<Rule> rules = new ArrayList<>();
            for (JsonNode node : root.path("commands")) {
                String pattern = node.path("pattern").asText("").strip();
                Effect effect = parse(node.path("effect").asText(""));
                if (pattern.isEmpty() || effect == null) continue;
                if (effect == Effect.ALLOW && !allowRulesTrusted) continue; // repositories may only tighten
                rules.add(Rule.of(pattern, effect, source));
            }
            Map<String,Long> budget = new java.util.LinkedHashMap<>();
            JsonNode b = root.path("budget");
            for (String key : List.of("maxMinutes", "maxTurns", "maxTokens")) {
                if (b.path(key).canConvertToLong() && b.path(key).asLong() > 0) budget.put(key, b.path(key).asLong());
            }
            Cached loaded = new Cached(modified, List.copyOf(rules), Map.copyOf(budget));
            CACHE.put(file, loaded);
            return loaded;
        } catch (Exception invalid) {
            System.err.println("ELIYA policy file ignored (" + file + "): " + invalid.getMessage());
            return new Cached(0, List.of(), Map.of());
        }
    }

    private static Effect parse(String raw) {
        return switch (raw.strip().toLowerCase(Locale.ROOT)) {
            case "allow" -> Effect.ALLOW;
            case "ask" -> Effect.ASK;
            case "deny" -> Effect.DENY;
            default -> null;
        };
    }

    static Pattern glob(String pattern) {
        StringBuilder regex = new StringBuilder("(?is)");
        for (char c : pattern.strip().toCharArray()) {
            switch (c) {
                case '*' -> regex.append(".*");
                case '?' -> regex.append('.');
                default -> regex.append(Pattern.quote(String.valueOf(c)));
            }
        }
        return Pattern.compile(regex.toString());
    }
}
