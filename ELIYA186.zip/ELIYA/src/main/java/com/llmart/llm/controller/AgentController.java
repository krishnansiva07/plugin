package com.llmart.llm.controller;

import com.llmart.llm.service.AgentApprovalService;
import com.llmart.llm.service.AgentRunService;
import com.llmart.llm.service.AgentTaskRollbackService;
import java.io.IOException;
import org.springframework.web.bind.annotation.*;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/agent")
public class AgentController {
    private final AgentApprovalService approvals;
    private final AgentRunService runs;
    private final AgentTaskRollbackService rollback;
    @org.springframework.beans.factory.annotation.Autowired(required = false)
    private com.llmart.llm.service.AgentQuestionService questions;
    @org.springframework.beans.factory.annotation.Autowired(required = false)
    private com.llmart.llm.service.AgentWorkspaceService workspaces;
    @org.springframework.beans.factory.annotation.Autowired(required = false)
    private com.llmart.llm.service.ConversationService conversations;

    public AgentController(AgentApprovalService approvals, AgentRunService runs, AgentTaskRollbackService rollback) {
        this.approvals = approvals;
        this.runs = runs;
        this.rollback = rollback;
    }

    @GetMapping("/conversations/{conversationId}/rollback/latest")
    public Map<String,Object> latestRollback(@PathVariable String conversationId, @RequestParam String projectId) throws IOException {
        var target = rollback.latestAvailable(conversationId, projectId, "");
        return target.isPresent() ? rollback.preview(target.get()) : Map.of("available", false);
    }

    @PostMapping("/conversations/{conversationId}/rollback/latest")
    public Map<String,Object> rollbackLatest(@PathVariable String conversationId, @RequestBody Map<String,Object> body) throws IOException {
        String projectId = String.valueOf(body.getOrDefault("projectId", ""));
        String target = rollback.latestAvailable(conversationId, projectId, "")
                .orElseThrow(() -> new IllegalArgumentException("No completed operation available for rollback"));
        return rollback.rollback(target, conversationId, projectId);
    }

    @PostMapping("/approvals/{id}")
    public Map<String, Object> resolve(@PathVariable String id, @RequestBody Map<String, Object> body) {
        String action = String.valueOf(body.getOrDefault("action", "")).trim().toLowerCase();
        AgentApprovalService.Decision decision;
        if ("run".equals(action) || "always".equals(action)) decision = AgentApprovalService.Decision.RUN;
        else if ("once".equals(action) || Boolean.TRUE.equals(body.get("approved"))) decision = AgentApprovalService.Decision.ONCE;
        else decision = AgentApprovalService.Decision.DENY;
        boolean resolved = approvals.resolve(id, decision);
        return Map.of("resolved", resolved, "decision", decision.name().toLowerCase());
    }


    @PutMapping("/runs/{id}/plan")
    public Map<String, Object> updatePlan(@PathVariable String id, @RequestBody Map<String, Object> body) {
        Object raw = body.get("items");
        java.util.List<String> items = new java.util.ArrayList<>();
        if (raw instanceof java.util.Collection<?> values) {
            for (Object value : values) {
                String text = value == null ? "" : String.valueOf(value).trim();
                if (!text.isBlank()) items.add(text);
            }
        }
        AgentRunService.AgentRun run = runs.require(id);
        run.replaceDraftPlan(items);
        return run.snapshot();
    }

    @PostMapping("/runs/{id}/cancel")
    public Map<String, Object> cancel(@PathVariable String id) {
        AgentRunService.AgentRun run = runs.require(id);
        boolean accepted = runs.cancel(id);
        int approvalsReleased = approvals.cancelRun(id);
        if (questions != null) questions.cancel(id);
        if (accepted && workspaces != null) workspaces.stopRunProcesses(id);
        Map<String,Object> result = new LinkedHashMap<>();
        // `cancelled` is retained for older clients, but means request accepted.
        // `finished`/`status` are the evidence of actual backend termination.
        result.put("cancelled", accepted);
        result.put("stopAccepted", accepted);
        result.put("finished", run.finished());
        result.put("status", run.status());
        result.put("approvalsReleased", approvalsReleased);
        return result;
    }

    @GetMapping("/runs/{id}/artifacts/{index}")
    public Map<String,Object> artifact(@PathVariable String id, @PathVariable int index) throws IOException {
        return rollback.artifactFile(id, index);
    }

    @GetMapping(value = "/runs/{id}/artifacts/{index}/download", produces = "application/octet-stream")
    public org.springframework.http.ResponseEntity<org.springframework.core.io.Resource> downloadArtifact(
            @PathVariable String id, @PathVariable int index) throws IOException {
        java.nio.file.Path path = rollback.downloadableArtifact(id, index);
        String name = path.getFileName().toString().replaceAll("[^a-zA-Z0-9._-]", "_");
        return org.springframework.http.ResponseEntity.ok()
                .contentType(org.springframework.http.MediaType.APPLICATION_OCTET_STREAM)
                .contentLength(java.nio.file.Files.size(path))
                .header(org.springframework.http.HttpHeaders.CONTENT_DISPOSITION,
                        "attachment; filename=\"" + name + "\"")
                .header("X-Content-Type-Options", "nosniff")
                .body(new org.springframework.core.io.InputStreamResource(java.nio.file.Files.newInputStream(path)));
    }

    @GetMapping("/runs/{id}/markdown/{index}")
    public Map<String,Object> markdown(@PathVariable String id, @PathVariable int index) throws IOException {
        return rollback.markdownFile(id, index);
    }

    @GetMapping("/runs/{id}/file-integrity")
    public Map<String,Object> fileIntegrity(@PathVariable String id) throws IOException {
        return rollback.currentFileIntegrity(id);
    }

    @GetMapping("/runs/{id}/completion-report")
    public Map<String,Object> completionReport(@PathVariable String id) {
        return rollback.completionReport(id);
    }

    @org.springframework.beans.factory.annotation.Autowired(required = false)
    private com.llmart.llm.service.AgentRecoveryStore recoveries;

    /**
     * Stage a linked recovery of a terminated run. The next Agent run in the same conversation (or workspace)
     * restores the original plan, completed steps, evidence and task contract instead of replanning from scratch.
     */
    @PostMapping("/runs/{id}/recovery")
    public Map<String,Object> stageRecovery(@PathVariable String id) {
        if (recoveries == null) throw new IllegalStateException("Agent recovery service unavailable");
        var seed = recoveries.stage(runs.require(id));
        Map<String,Object> result = new java.util.LinkedHashMap<>();
        result.put("staged", true);
        result.put("priorRunId", seed.priorRunId());
        result.put("conversationId", seed.conversationId());
        result.put("completedSteps", seed.restorableCompletedSteps());
        result.put("remainingSteps", seed.plan().size() - seed.restorableCompletedSteps());
        result.put("stoppingReason", seed.stoppingReason());
        return result;
    }

    /**
     * Input typed while the Agent is running. It is delivered to the running task after its current action
     * (before the next model turn). Returns 409-style errors when the run already finished.
     */
    @PostMapping("/runs/{id}/input")
    public org.springframework.http.ResponseEntity<Map<String,Object>> submitRunInput(@PathVariable String id, @RequestBody Map<String,Object> body) {
        var run = runs.require(id);
        try {
            var input = run.submitUserInput(String.valueOf(body == null ? "" : body.getOrDefault("text", "")));
            Map<String,Object> result = new java.util.LinkedHashMap<>(input.toMap());
            result.put("queued", true);
            result.put("pendingCount", run.userInputs().stream().filter(u -> "pending".equals(u.status())).count());
            return org.springframework.http.ResponseEntity.ok(result);
        } catch (IllegalStateException finishedOrFull) {
            // Finished run or too many waiting inputs: the UI offers "queue as next task" instead.
            return org.springframework.http.ResponseEntity.status(org.springframework.http.HttpStatus.CONFLICT)
                    .body(Map.of("message", String.valueOf(finishedOrFull.getMessage()), "finished", run.finished()));
        }
    }

    @GetMapping("/runs/{id}/input")
    public Map<String,Object> listRunInput(@PathVariable String id) {
        var run = runs.require(id);
        return Map.of("runId", id, "finished", run.finished(), "status", run.status(),
                "inputs", run.userInputs().stream().map(com.llmart.llm.service.AgentRunService.UserInput::toMap).toList());
    }

    @DeleteMapping("/runs/{id}/input/{inputId}")
    public Map<String,Object> withdrawRunInput(@PathVariable String id, @PathVariable String inputId) {
        return Map.of("withdrawn", runs.require(id).withdrawUserInput(inputId));
    }

    @PostMapping("/runs/{id}/answer")
    public Map<String,Object> answerQuestion(@PathVariable String id, @RequestBody Map<String,Object> response) {
        runs.require(id); // prevent writing responses for nonexistent run IDs
        if (questions == null) throw new IllegalStateException("Agent clarification service unavailable");
        String qId = String.valueOf(response.getOrDefault("questionId", ""));
        String choice = String.valueOf(response.getOrDefault("choice", ""));
        String detail = String.valueOf(response.getOrDefault("detail", ""));
        boolean answered = questions.answer(id, qId, choice, detail);
        if (answered && conversations != null) {
            // Preserve the natural-language reply when the conversation is reopened.
            var run = runs.require(id);
            String userAnswer = detail.isBlank() ? choice : detail;
            if (!userAnswer.isBlank()) conversations.addMessage(run.conversationId(), "user", userAnswer, List.of());
        }
        if (answered && "Cancel".equalsIgnoreCase(choice)) runs.cancel(id);
        return Map.of("answered", answered);
    }

    @GetMapping("/runs/active")
    public List<Map<String,Object>> activeRunStatuses() {
        return runs.activeExecutionRuns();
    }

    @GetMapping("/runs/recent")
    public List<Map<String,Object>> recentRunUsage() {
        return runs.recentExecutionUsage(60);
    }

    @GetMapping("/runs/{id}")
    public Map<String, Object> status(@PathVariable String id) {
        Map<String,Object> result = new LinkedHashMap<>(runs.status(id));
        if (questions != null) {
            Map<String,Object> question = questions.pending(id);
            if (!question.isEmpty()) { result.put("question", question); result.put("needsInput", true); }
        }
        return result;
    }

    @GetMapping("/conversations/{conversationId}/latest-run")
    public Map<String, Object> latestRun(@PathVariable String conversationId) {
        return runs.latestForConversation(conversationId).orElseGet(Map::of);
    }

    @GetMapping("/conversations/{conversationId}/runs")
    public List<Map<String, Object>> conversationRuns(@PathVariable String conversationId) {
        return runs.forConversation(conversationId);
    }
}
