package com.llmart.llm.service;

import java.util.List;
import java.util.Locale;

/**
 * High-confidence plan-quality checks only. These checks must never replace the
 * user's instructions, require a particular number of steps, or invent paths.
 * They catch obvious placeholder plans before they are marked approved.
 */
final class AgentPlanSpecificity {
    private AgentPlanSpecificity() { }

    static String mismatch(String task, List<String> steps) {
        if (task == null || task.isBlank()) return "Original user request is missing";
        if (steps == null || steps.isEmpty()) return "The planner provided no executable steps";
        String plan = String.join("\n", steps).toLowerCase(Locale.ROOT);
        String request = task.toLowerCase(Locale.ROOT);
        int placeholders = 0;
        int vagueSteps = 0;
        for (String step : steps) {
            String value = step.toLowerCase(Locale.ROOT);
            String headline = value.split("\\R", 2)[0].replaceAll("^(?:\\d+[.)]\\s*|[-*]\\s*)", "").strip();
            // Require several wholly vague actions before rejecting; a normal
            // exploratory step in an otherwise concrete plan is perfectly valid.
            if (headline.matches("(?:analy[sz]e|inspect|review|understand) (?:the )?(?:requirements|user request|project|codebase|workspace|existing implementation)") ||
                    headline.matches("(?:implement|apply|make|perform|complete|execute) (?:the )?(?:requested changes|solution|task|requirements|implementation)") ||
                    headline.matches("(?:test|verify|validate|check|review) (?:the )?(?:changes|solution|implementation|result|outcome|work)") ||
                    headline.matches("(?:provide|write|prepare) (?:a )?(?:summary|report|final answer)")) {
                vagueSteps++;
            }
            if (value.contains("fulfill every requirement") ||
                    value.contains("fulfil every requirement") ||
                    value.contains("requirements in the original user request") ||
                    value.contains("complete the requested task as described") ||
                    value.contains("inspect the relevant live workspace and fulfill") ||
                    value.contains("verify all deliverables and requested outcomes against the full original user request")) {
                placeholders++;
            }
        }
        if (placeholders > 0 && placeholders >= steps.size() - 1 &&
                (steps.size() <= 2 || placeholders >= 2)) {
            return "The returned plan is a generic execution placeholder, not a task-specific breakdown";
        }
        if (steps.size() >= 3 && vagueSteps >= Math.max(2, (steps.size() * 3 + 3) / 4)) {
            return "Most plan steps are generic analyse/implement/test placeholders without task-specific actions";
        }
        // Explicitly selected external sources must not disappear from the plan.
        for (String source : List.of("jira", "confluence", "gitlab", "sonarqube", "playwright")) {
            if (request.contains(source + " mcp") && !plan.contains(source)) {
                return "The plan omitted the explicitly requested " + source + " MCP evidence source";
            }
        }
        // ELIYA173/179: a superficially specific plan must still name the source and target of an explicit migration
        // (any technology, not only Selenium -> Playwright).
        java.util.Optional<MigrationIntent.Spec> migrationSpec = MigrationIntent.parse(task);
        if (migrationSpec.isPresent()) {
            MigrationIntent.Spec spec = migrationSpec.get();
            List<String> targetTerms = MigrationIntent.keyTerms(spec.target());
            List<String> sourceTerms = MigrationIntent.keyTerms(spec.source());
            if (!targetTerms.isEmpty() && targetTerms.stream().noneMatch(plan::contains))
                return "The plan omitted the explicit " + spec.target() + " migration target";
            boolean sameName = !sourceTerms.isEmpty() && targetTerms.containsAll(sourceTerms);
            if (!sourceTerms.isEmpty() && !sameName && sourceTerms.stream().noneMatch(plan::contains))
                return "The plan omitted the " + spec.source() + " migration source scope";
        }
        boolean explicitRun = request.matches("(?s).*\\b(?:run|execute)\\s+(?:the\\s+)?(?:integration\\s+|regression\\s+|unit\\s+|automated\\s+|e2e\\s+|all\\s+)?tests?\\b.*");
        if (explicitRun && !(java.util.regex.Pattern.compile("\\b(?:run|runs|rerun|execute|executes)\\b").matcher(plan).find() &&
                java.util.regex.Pattern.compile("\\b(?:tests?|suites?|specs?)\\b").matcher(plan).find()))
            return "The plan omitted the explicitly requested real test execution";
        // Deliverables are not optional if the user expressly requested their format.
        if ((request.contains(".docx") || request.contains("word document")) &&
                AgentPlanRelevance.isExternalDocumentRequest(task) &&
                !(plan.contains("docx") || plan.contains("word document"))) {
            return "The plan omitted the explicitly requested Word document deliverable";
        }
        if (AgentPlanRelevance.isMarkdownOutputRequest(task) &&
                AgentPlanRelevance.isExternalDocumentRequest(task) &&
                !(plan.contains(".md") || plan.contains("markdown"))) {
            return "The plan omitted the explicitly requested Markdown deliverable";
        }
        return "";
    }

    /**
     * Soft quality signal used to trigger ONE corrective planner round (never to discard a plan outright):
     * the workspace evidence contains concrete code anchors, the request is a code task, yet most steps
     * name no file, identifier or command at all.
     */
    static String lacksConcreteAnchors(String task, List<String> steps, String evidence) {
        if (steps == null || steps.size() < 2 || task == null) return "";
        if (AgentConversationIntent.isFastReadOnly(task) || AgentPlanRelevance.isExternalDocumentRequest(task)) return "";
        if (!AgentPlanningTerms.hasConcreteAnchor(evidence)) return "";
        long anchored = steps.stream().filter(AgentPlanningTerms::hasConcreteAnchor).count();
        // Allow a generic final verification step and one exploratory step.
        if (anchored == 0 || anchored * 2 < steps.size() - 1) {
            return "Only " + anchored + " of " + steps.size() +
                    " steps reference a concrete file, class, function or command from the workspace evidence";
        }
        return "";
    }
}
