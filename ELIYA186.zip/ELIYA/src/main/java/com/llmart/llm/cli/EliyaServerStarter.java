package com.llmart.llm.cli;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Starts a detached, headless ELIYA server for terminal commands ({@code eliya analyse|agent}) when no
 * instance is running. The server writes the normal CLI bridge file, which the launcher polls.
 */
final class EliyaServerStarter {
    private EliyaServerStarter() { }

    static long startTimeoutSeconds() {
        try {
            String raw = System.getenv("ELIYA_START_TIMEOUT");
            return raw == null || raw.isBlank() ? 120 : Math.max(10, Long.parseLong(raw.strip()));
        } catch (NumberFormatException invalid) {
            return 120;
        }
    }

    static Process start(Path logFile) throws IOException {
        Path jar = runnableJar();
        Files.createDirectories(logFile.getParent());
        List<String> command = new ArrayList<>();
        boolean windows = System.getProperty("os.name", "").toLowerCase(Locale.ROOT).contains("win");
        // Survive the terminal closing (SIGHUP) on Unix-like systems when nohup is available.
        if (!windows && Files.isExecutable(Path.of("/usr/bin/nohup"))) command.add("/usr/bin/nohup");
        command.add(javaExecutable(windows));
        String extraJvm = System.getenv("ELIYA_JAVA_OPTS");
        if (extraJvm != null && !extraJvm.isBlank()) command.addAll(List.of(extraJvm.strip().split("\\s+")));
        command.addAll(List.of("-jar", jar.toString(), "--eliya-cli", "--serve"));
        ProcessBuilder builder = new ProcessBuilder(command)
                .redirectErrorStream(true)
                .redirectOutput(ProcessBuilder.Redirect.appendTo(logFile.toFile()))
                .redirectInput(windows ? ProcessBuilder.Redirect.PIPE : ProcessBuilder.Redirect.from(new File("/dev/null")));
        builder.environment().put("ELIYA_NO_BROWSER", "true");
        Process process = builder.start();
        if (windows) process.getOutputStream().close();
        return process;
    }

    /** The JAR this launcher runs from ({@code java -jar eliya.jar}), or ELIYA_JAR. */
    static Path runnableJar() {
        String configured = System.getenv("ELIYA_JAR");
        if (configured != null && !configured.isBlank() && Files.isRegularFile(Path.of(configured))) return Path.of(configured);
        String classPath = System.getProperty("java.class.path", "");
        for (String entry : classPath.split(File.pathSeparator)) {
            if (entry.toLowerCase(Locale.ROOT).endsWith(".jar") && Files.isRegularFile(Path.of(entry))) {
                return Path.of(entry).toAbsolutePath();
            }
        }
        throw new IllegalStateException("Cannot locate the ELIYA JAR to start a background server. " +
                "Set ELIYA_JAR or start Eliya first with `eliya --no-browser`.");
    }

    private static String javaExecutable(boolean windows) {
        return ProcessHandle.current().info().command()
                .filter(path -> Files.isExecutable(Path.of(path)))
                .orElse(Path.of(System.getProperty("java.home"), "bin", windows ? "java.exe" : "java").toString());
    }
}
