package com.llmart.llm.cli.tui;

import java.util.ArrayList;
import java.util.List;

/** Multi-line message editor with cursor, history and paste support. Positions are code-point based. */
public final class TuiInputBox {
    private final StringBuilder text = new StringBuilder();
    private int cursor;                      // index into text (char index, kept on code-point boundaries)
    private final List<String> history = new ArrayList<>();
    private int historyIndex = -1;
    private String draftBeforeHistory = "";

    public String text() { return text.toString(); }
    public int cursor() { return cursor; }
    public boolean isEmpty() { return text.length() == 0; }

    public void insert(String value) {
        if (value == null || value.isEmpty()) return;
        String clean = value.replace("\r\n", "\n").replace('\r', '\n').replace("\t", "    ");
        StringBuilder safe = new StringBuilder();
        for (int i = 0; i < clean.length(); ) {
            int cp = clean.codePointAt(i);
            i += Character.charCount(cp);
            if (cp == '\n' || cp >= 32 && cp != 0x7f) safe.appendCodePoint(cp);
        }
        text.insert(cursor, safe);
        cursor += safe.length();
        historyIndex = -1;
    }

    public void backspace() {
        if (cursor == 0) return;
        int start = text.offsetByCodePoints(cursor, -1);
        text.delete(start, cursor);
        cursor = start;
    }

    public void delete() {
        if (cursor >= text.length()) return;
        text.delete(cursor, text.offsetByCodePoints(cursor, 1));
    }

    public void deleteWordBefore() {
        int i = cursor;
        while (i > 0 && text.charAt(i - 1) == ' ') i--;
        while (i > 0 && text.charAt(i - 1) != ' ' && text.charAt(i - 1) != '\n') i--;
        text.delete(i, cursor);
        cursor = i;
    }

    public void left() { if (cursor > 0) cursor = text.offsetByCodePoints(cursor, -1); }
    public void right() { if (cursor < text.length()) cursor = text.offsetByCodePoints(cursor, 1); }
    public void home() { cursor = text.lastIndexOf("\n", cursor - 1) + 1; }
    public void end() { int nl = text.indexOf("\n", cursor); cursor = nl < 0 ? text.length() : nl; }

    /** Move up a line; returns false when already on the first line (caller may use history). */
    public boolean up() {
        int lineStart = text.lastIndexOf("\n", cursor - 1) + 1;
        if (lineStart == 0) return false;
        int column = cursor - lineStart;
        int prevStart = text.lastIndexOf("\n", lineStart - 2) + 1;
        cursor = Math.min(prevStart + column, lineStart - 1);
        return true;
    }

    /** Move down a line; returns false when already on the last line. */
    public boolean down() {
        int nl = text.indexOf("\n", cursor);
        if (nl < 0) return false;
        int lineStart = text.lastIndexOf("\n", cursor - 1) + 1;
        int column = cursor - lineStart;
        int nextEnd = text.indexOf("\n", nl + 1);
        cursor = Math.min(nl + 1 + column, nextEnd < 0 ? text.length() : nextEnd);
        return true;
    }

    public void clear() { text.setLength(0); cursor = 0; historyIndex = -1; }

    public void set(String value) { text.setLength(0); text.append(value == null ? "" : value); cursor = text.length(); }

    /** Take the message (trimmed of trailing blank lines) and remember it in history. */
    public String take() {
        String value = text.toString().strip();
        if (!value.isEmpty() && (history.isEmpty() || !history.get(history.size() - 1).equals(value))) history.add(value);
        while (history.size() > 200) history.remove(0);
        clear();
        return value;
    }

    public void historyPrevious() {
        if (history.isEmpty()) return;
        if (historyIndex < 0) { draftBeforeHistory = text.toString(); historyIndex = history.size(); }
        if (historyIndex > 0) set(history.get(--historyIndex));
    }

    public void historyNext() {
        if (historyIndex < 0) return;
        if (++historyIndex >= history.size()) { historyIndex = -1; set(draftBeforeHistory); }
        else set(history.get(historyIndex));
    }

    /** Visual layout: wrapped rows (plain text) and the cursor's row/column inside them. */
    public record Layout(List<String> rows, int cursorRow, int cursorColumn) { }

    public Layout layout(int width) {
        int max = Math.max(4, width);
        List<String> rows = new ArrayList<>();
        int cursorRow = 0, cursorColumn = 0;
        String value = text.toString();
        int index = 0;
        String[] lines = value.split("\n", -1);
        for (String line : lines) {
            StringBuilder row = new StringBuilder();
            int rowWidth = 0;
            int lineStart = index;
            for (int i = 0; i <= line.length(); ) {
                if (lineStart + i == cursor) { cursorRow = rows.size(); cursorColumn = rowWidth; }
                if (i == line.length()) break;
                int cp = line.codePointAt(i);
                int w = TuiText.width(cp);
                if (rowWidth + w > max) { rows.add(row.toString()); row.setLength(0); rowWidth = 0;
                    if (lineStart + i == cursor) { cursorRow = rows.size(); cursorColumn = 0; } }
                row.appendCodePoint(cp);
                rowWidth += w;
                i += Character.charCount(cp);
            }
            rows.add(row.toString());
            index += line.length() + 1;
        }
        if (cursorColumn >= max) { cursorRow++; cursorColumn = 0; if (cursorRow >= rows.size()) rows.add(""); }
        return new Layout(rows, cursorRow, cursorColumn);
    }
}
