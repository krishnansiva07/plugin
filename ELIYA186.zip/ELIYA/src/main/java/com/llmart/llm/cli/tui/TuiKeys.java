package com.llmart.llm.cli.tui;

import java.io.IOException;
import java.io.InputStream;
import java.io.PushbackInputStream;
import java.nio.charset.StandardCharsets;

/** Decodes raw terminal bytes into key events, including bracketed paste. */
public final class TuiKeys {
    public enum Type { CHAR, ENTER, NEWLINE, BACKSPACE, DELETE, LEFT, RIGHT, UP, DOWN, HOME, END, PAGE_UP, PAGE_DOWN,
        TAB, ESCAPE, CTRL, PASTE, EOF, UNKNOWN }

    /** {@code text} holds the typed character or the pasted block; {@code ctrl} the letter for Ctrl+letter. */
    public record Key(Type type, String text, char ctrl) {
        static Key of(Type type) { return new Key(type, "", '\0'); }
        public boolean isCtrl(char letter) { return type == Type.CTRL && ctrl == letter; }
    }

    private final PushbackInputStream in;

    public TuiKeys(InputStream input) {
        this.in = new PushbackInputStream(input, 64);
    }

    public Key read() throws IOException {
        int b = in.read();
        if (b < 0) return Key.of(Type.EOF);
        if (b == 0x1b) return escape();
        if (b == '\r') return Key.of(Type.ENTER);
        if (b == '\n') return Key.of(Type.NEWLINE);           // Ctrl+J: newline in the message box
        if (b == '\t') return Key.of(Type.TAB);
        if (b == 0x7f || b == 0x08) return Key.of(Type.BACKSPACE);
        if (b < 32) return new Key(Type.CTRL, "", (char) ('a' + b - 1));
        return new Key(Type.CHAR, utf8(b), '\0');
    }

    private Key escape() throws IOException {
        if (in.available() == 0) {
            // A lone ESC (no sequence follows quickly) is the Escape key.
            try { Thread.sleep(25); } catch (InterruptedException interrupted) { Thread.currentThread().interrupt(); }
            if (in.available() == 0) return Key.of(Type.ESCAPE);
        }
        int next = in.read();
        if (next == '\r' || next == '\n') return Key.of(Type.NEWLINE);   // Alt+Enter: newline
        if (next == '[') return csi();
        if (next == 'O') {                                               // SS3: application cursor keys
            int code = in.read();
            return switch (code) {
                case 'A' -> Key.of(Type.UP); case 'B' -> Key.of(Type.DOWN);
                case 'C' -> Key.of(Type.RIGHT); case 'D' -> Key.of(Type.LEFT);
                case 'H' -> Key.of(Type.HOME); case 'F' -> Key.of(Type.END);
                default -> Key.of(Type.UNKNOWN);
            };
        }
        if (next >= 0) in.unread(next);
        return Key.of(Type.ESCAPE);
    }

    private Key csi() throws IOException {
        StringBuilder params = new StringBuilder();
        int c;
        while ((c = in.read()) >= 0 && (c < '@' || c > '~')) params.append((char) c);
        if (c < 0) return Key.of(Type.EOF);
        String p = params.toString();
        switch (c) {
            case 'A': return Key.of(Type.UP);
            case 'B': return Key.of(Type.DOWN);
            case 'C': return Key.of(Type.RIGHT);
            case 'D': return Key.of(Type.LEFT);
            case 'H': return Key.of(Type.HOME);
            case 'F': return Key.of(Type.END);
            case 'Z': return Key.of(Type.TAB);   // Shift+Tab treated as Tab
            case '~':
                switch (p) {
                    case "1": case "7": return Key.of(Type.HOME);
                    case "4": case "8": return Key.of(Type.END);
                    case "3": return Key.of(Type.DELETE);
                    case "5": return Key.of(Type.PAGE_UP);
                    case "6": return Key.of(Type.PAGE_DOWN);
                    case "200": return new Key(Type.PASTE, readPaste(), '\0');
                    case "13;2": case "27;2;13": return Key.of(Type.NEWLINE); // Shift+Enter (xterm modifyOtherKeys)
                    default: return Key.of(Type.UNKNOWN);
                }
            case 'u':
                if (p.equals("13;2") || p.equals("13;3")) return Key.of(Type.NEWLINE); // kitty/CSI-u Shift/Alt+Enter
                return Key.of(Type.UNKNOWN);
            default: return Key.of(Type.UNKNOWN);
        }
    }

    /** Bracketed paste: everything until ESC[201~ is literal text (newlines included). */
    private String readPaste() throws IOException {
        java.io.ByteArrayOutputStream buffer = new java.io.ByteArrayOutputStream();
        byte[] end = "\u001b[201~".getBytes(StandardCharsets.US_ASCII);
        int matched = 0;
        int b;
        while ((b = in.read()) >= 0) {
            if (b == end[matched]) {
                matched++;
                if (matched == end.length) break;
                continue;
            }
            if (matched > 0) { buffer.write(end, 0, matched); matched = 0; if (b == end[0]) { matched = 1; continue; } }
            buffer.write(b);
        }
        return buffer.toString(StandardCharsets.UTF_8).replace("\r\n", "\n").replace('\r', '\n');
    }

    private String utf8(int first) throws IOException {
        int extra = first >= 0xf0 ? 3 : first >= 0xe0 ? 2 : first >= 0xc0 ? 1 : 0;
        byte[] bytes = new byte[extra + 1];
        bytes[0] = (byte) first;
        for (int i = 1; i <= extra; i++) {
            int b = in.read();
            if (b < 0) break;
            bytes[i] = (byte) b;
        }
        return new String(bytes, StandardCharsets.UTF_8);
    }
}
