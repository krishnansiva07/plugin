package com.llmart.llm.service;

import org.springframework.stereotype.Service;
import java.util.*;
import java.util.concurrent.*;

/** Session-specific clarification bridge. Questions are NOT plan approvals or permission grants. */
@Service
public class AgentQuestionService {
    private final ConcurrentMap<String, Pending> questions = new ConcurrentHashMap<>();
    private final Set<String> enabledRuns = ConcurrentHashMap.newKeySet();
    private final ConcurrentMap<String, java.util.function.Consumer<Map<String,Object>>> questionListeners = new ConcurrentHashMap<>();
    public void observe(String runId, java.util.function.Consumer<Map<String,Object>> listener) {
        if (runId != null && !runId.isBlank() && listener != null) questionListeners.put(runId, listener);
    }
    public void enable(String runId) { if (runId != null && !runId.isBlank()) enabledRuns.add(runId); }
    public void disable(String runId) { enabledRuns.remove(runId); questionListeners.remove(runId); cancel(runId); }
    public boolean enabled(String runId) { return enabledRuns.contains(runId); }
    private record Pending(String id, String question, List<String> choices, CompletableFuture<String> response) {}

    public String ask(String runId, String question, List<String> choices, AgentRunService.AgentRun run) throws Exception {
        if (question == null || question.isBlank()) throw new IllegalArgumentException("Question cannot be blank");
        if (question.length() > 2000) throw new IllegalArgumentException("Question is too long");
        // Never offer empty, context-free OK/Continue choices when the model omitted
        // the requested possible answers. The question must still be recoverable.
        List<String> options = choices == null || choices.isEmpty() ?
                List.of("Provide the missing information", "Stop and preserve completed work", "Cancel")
            : choices.stream().filter(Objects::nonNull).map(String::trim).filter(x -> !x.isBlank()).distinct().limit(8).toList();
        if (options.isEmpty()) throw new IllegalArgumentException("Provide at least one response option");
        if (options.stream().noneMatch(x -> x.equalsIgnoreCase("Cancel"))) {
            List<String> withCancel = new ArrayList<>(options);
            withCancel.add("Cancel"); options = List.copyOf(withCancel);
        }
        Pending pending = new Pending(UUID.randomUUID().toString(), question, options, new CompletableFuture<>());
        if (questions.putIfAbsent(runId, pending) != null) throw new IllegalStateException("Another clarification is already pending");
        var listener = questionListeners.get(runId);
        if (listener != null) try { listener.accept(pending(runId)); }
        catch (RuntimeException ignored) { /* UI notification cannot abort a pending question */ }
        try {
            while (true) {
                run.checkCancelled();
                try {
                    String response = pending.response().get(250, TimeUnit.MILLISECONDS);
                    // Cancel may resolve the future at the exact same instant as the worker poll.
                    // A late "continue" must never resume a cancelled or terminated run.
                    run.checkCancelled();
                    return response;
                } catch (TimeoutException ignored) { /* nonblocking check of run cancellation */ }
            }
        } finally { questions.remove(runId, pending); }
    }
    public Map<String,Object> pending(String runId) {
        Pending q = questions.get(runId);
        if (q == null) return Map.of();
        return Map.of("kind", "clarification", "id", q.id(), "reason", q.question(), "choices", q.choices());
    }
    public boolean answer(String runId, String questionId, String choice, String detail) {
        Pending q = questions.get(runId);
        if (q == null || !q.id().equals(questionId)) return false;
        if (detail != null && detail.length() > 8000) throw new IllegalArgumentException("Clarification text is too long");
        boolean custom = "Custom".equals(choice);
        // A clicked option submitted as free text (or typed exactly) is recorded as that option, so every
        // backend check sees "User selected: <option>" regardless of which UI path sent it.
        if (custom) {
            Optional<String> option = AgentQuestionAnswers.matchOption(detail, q.choices());
            if (option.isPresent()) { choice = option.get(); custom = false; detail = null; }
        }
        if (!q.choices().contains(choice) && !custom) return false;
        if (custom && (detail == null || detail.isBlank())) return false;
        return q.response().complete(custom ? "User selected: Custom\nDetails: " + detail.trim()
                : "User selected: " + choice + (detail == null || detail.isBlank() ? "" : "\nDetails: " + detail));
    }
    public void cancel(String runId) {
        Pending q = questions.remove(runId);
        if (q != null) q.response().complete("User cancelled the clarification; stop the affected task safely.");
    }
}
