package com.llmart.llm.service;

import java.util.Arrays;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * ELIYA184: models sometimes wrap their whole final answer in a {@code ```markdown} (or bare {@code ```}) fence. Every
 * renderer then shows the report as source code — raw "##" and "**" in a dark code box in the browser, a cyan code
 * block in the terminal. The answer is meant to be read, so the wrapper fence is removed before the answer is saved.
 *
 * <p>Only a fence that wraps the answer is removed: it must open within the first two short lines, be labelled
 * markdown/md (or be unlabelled and contain Markdown prose rather than code), and its nested code blocks must balance.
 * Code blocks inside the answer, and fences in the middle of a longer answer, are left alone.</p>
 */
final class AgentAnswerFormat {
    private AgentAnswerFormat() { }

    private static final Pattern FENCE = Pattern.compile("^\\s{0,3}(`{3,}|~{3,})\\s*([^\\s`~]*)\\s*(.*)$");
    private static final Pattern DOC_LABEL = Pattern.compile("(?i)markdown|md|gfm|mdx");
    private static final Pattern PLAIN_LABEL = Pattern.compile("(?i)|text|txt|plaintext");
    private static final Pattern SOURCE_WORDS = Pattern.compile(
            "(?i)\\.(?:md|markdown)\\b|\\b(?:raw|source|template|copy|paste|file content|contents of)\\b");
    /** The request itself asks for Markdown as source text, so the fence is what the user wants to see. */
    private static final Pattern WANTS_SOURCE = Pattern.compile(
            "(?i)\\b(?:raw|unrendered|plain)\\s+(?:markdown|md)\\b|\\bmarkdown\\s+(?:source|code|syntax|text|block)\\b" +
            "|\\bcode\\s*block\\b|\\bfenced\\b|\\bcopy(?:\\s*(?:and|&|-)?\\s*paste|able)\\b");

    /** True when the answer to this request must keep a wrapping fence (prompt generation, raw Markdown asked for). */
    static boolean keepFenceFor(String objective) {
        if (objective == null || objective.isBlank()) return false;
        return AgentConversationIntent.isPromptGenerationRequest(objective) || WANTS_SOURCE.matcher(objective).find();
    }

    /** The answer without a wrapping Markdown fence, or the answer unchanged. */
    static String unwrapMarkdownFence(String answer) {
        if (answer == null || answer.indexOf("```") < 0 && answer.indexOf("~~~") < 0) return answer;
        String text = answer.replace("\r\n", "\n");
        List<String> lines = Arrays.asList(text.split("\n", -1));
        int open = -1;
        int introLines = 0, introChars = 0;
        for (int i = 0; i < lines.size(); i++) {
            String line = lines.get(i);
            if (line.isBlank()) continue;
            if (FENCE.matcher(line).matches()) { open = i; break; }
            introLines++; introChars += line.length();
            if (introLines > 2 || introChars > 240) return answer;
        }
        if (open < 0) return answer;
        Matcher opener = FENCE.matcher(lines.get(open));
        if (!opener.matches() || !opener.group(3).isBlank()) return answer;
        String fence = opener.group(1);
        String label = opener.group(2);
        boolean docLabel = DOC_LABEL.matcher(label).matches();
        boolean plainLabel = PLAIN_LABEL.matcher(label).matches();
        if (!docLabel && !plainLabel) return answer;
        String intro = String.join("\n", lines.subList(0, open)).strip();
        if (!intro.isEmpty() && (!docLabel || SOURCE_WORDS.matcher(intro).find())) return answer;

        // The classic wrapper ends the answer with its closing fence: prefer the last line when what lies between
        // is balanced. Otherwise find the close by nesting: a fence with a language opens a level, a bare one closes.
        int close = -1, depth = 0;
        int last = lines.size() - 1;
        while (last > open && lines.get(last).isBlank()) last--;
        Matcher lastFence = FENCE.matcher(lines.get(last));
        if (last > open && lastFence.matches() && lastFence.group(2).isEmpty() && lastFence.group(3).isBlank() &&
                lastFence.group(1).charAt(0) == fence.charAt(0) && lastFence.group(1).length() >= fence.length() &&
                balanced(lines.subList(open + 1, last))) close = last;
        for (int i = open + 1; close < 0 && i < lines.size(); i++) {
            Matcher m = FENCE.matcher(lines.get(i));
            if (!m.matches()) continue;
            boolean bare = m.group(2).isEmpty() && m.group(3).isBlank();
            if (!bare) { depth++; continue; }
            if (depth > 0) { depth--; continue; }
            if (m.group(1).charAt(0) == fence.charAt(0) && m.group(1).length() >= fence.length()) { close = i; break; }
        }
        List<String> innerLines = lines.subList(open + 1, close < 0 ? lines.size() : close);
        String inner = String.join("\n", innerLines).strip();
        String outro = close < 0 ? "" : String.join("\n", lines.subList(close + 1, lines.size())).strip();
        if (inner.isEmpty()) return answer;
        if (close < 0 && depth > 0) return answer;                  // truncated or unbalanced: leave as is
        // A bare nested fence closed the wrapper too early: what follows would render broken; leave it alone.
        long outroFences = Arrays.stream(outro.split("\n")).filter(l -> FENCE.matcher(l).matches()).count();
        if (outroFences % 2 != 0) return answer;
        if (!docLabel && (!intro.isEmpty() || !outro.isEmpty() || !looksLikeMarkdownProse(inner))) return answer;
        if (docLabel && !intro.isEmpty() && !hasMarkdownStructure(inner)) return answer;
        StringBuilder out = new StringBuilder();
        if (!intro.isEmpty()) out.append(intro).append("\n\n");
        out.append(inner);
        if (!outro.isEmpty()) out.append("\n\n").append(outro);
        return out.toString();
    }

    /** Fences pair up in order (a fence with a language inside an open block is content). */
    static boolean balanced(List<String> lines) {
        boolean inside = false;
        for (String line : lines) {
            Matcher m = FENCE.matcher(line);
            if (!m.matches()) continue;
            boolean bare = m.group(2).isEmpty() && m.group(3).isBlank();
            if (!inside) inside = true;
            else if (bare) inside = false;
        }
        return !inside;
    }

    static boolean hasMarkdownStructure(String text) {
        return Pattern.compile("(?m)^\\s{0,3}#{1,6}\\s+\\S|^\\s*\\|.+\\|\\s*$|^\\s*(?:[-*+]|\\d+[.)])\\s+\\S|\\*\\*[^*\\n]+\\*\\*")
                .matcher(text).find();
    }

    /** Headings, tables, lists, bold or links — and not mostly code. */
    static boolean looksLikeMarkdownProse(String text) {
        int signals = 0;
        if (Pattern.compile("(?m)^\\s{0,3}#{1,6}\\s+\\S").matcher(text).find()) signals += 2;
        if (Pattern.compile("(?m)^\\s*\\|.+\\|\\s*$").matcher(text).find() &&
                Pattern.compile("(?m)^\\s*\\|?\\s*:?-{3,}").matcher(text).find()) signals += 2;
        if (Pattern.compile("(?m)^\\s*(?:[-*+]|\\d+[.)])\\s+\\S").matcher(text).find()) signals++;
        if (Pattern.compile("\\*\\*[^*\\n]+\\*\\*").matcher(text).find()) signals++;
        if (Pattern.compile("\\[[^\\]\\n]+\\]\\([^)\\s]+\\)").matcher(text).find()) signals++;
        String[] lines = text.split("\n");
        long codeish = Arrays.stream(lines).filter(l -> l.matches(
                "^\\s*(?:import |package |public |private |class |def |function |const |let |var |#include|SELECT |\\}|\\{).*|.*[;{]\\s*$")).count();
        return signals >= 2 && codeish * 2 < lines.length;
    }
}
