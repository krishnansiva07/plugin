package com.llmart.llm.cli;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.attribute.PosixFilePermission;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

/**
 * Model/provider configuration for terminal use, independent of the browser.
 *
 * <p>Before this, AI commands worked only after the browser had pushed its settings into the running
 * server's memory, so after every restart {@code eliya agent "..."} failed with HTTP 409 until someone opened
 * the browser. Configuration can now come from (highest priority first):</p>
 * <ol>
 *   <li>environment variables: {@code ELIYA_BASE_URL}, {@code ELIYA_API_KEY}, {@code ELIYA_MODEL},
 *       {@code ELIYA_CHAT_MODEL}, {@code ELIYA_MAX_TOKENS}, {@code ELIYA_CONTEXT_WINDOW}, {@code ELIYA_TEMPERATURE}</li>
 *   <li>the config file ({@code ELIYA_CONFIG}, default {@code ~/.eliya/config.properties}) written by
 *       {@code eliya setup}: keys {@code base.url}, {@code api.key}, {@code model}, {@code chat.model},
 *       {@code max.tokens}, {@code context.window.tokens}, {@code temperature}, {@code embedding.model},
 *       plus any raw ChatSettings field as {@code setting.<fieldName>} (e.g. {@code setting.agentShellPermission=ask})</li>
 * </ol>
 * <p>Pure Java (no Spring) so the launcher and the server share it.</p>
 */
public final class EliyaCliModelConfig {
    /** Resolved configuration. {@code settings} uses ChatSettings JSON property names. */
    public record Resolved(String apiKey, Map<String,Object> settings, String source) {
        public boolean complete() {
            return apiKey != null && !apiKey.isBlank() && notBlank(settings.get("baseUrl")) && notBlank(settings.get("model"));
        }
        public String model() { return String.valueOf(settings.getOrDefault("model", "")); }
    }

    private static final Map<String,String> ENV_TO_FIELD = Map.of(
            "ELIYA_BASE_URL", "baseUrl", "ELIYA_MODEL", "model", "ELIYA_CHAT_MODEL", "chatModel",
            "ELIYA_MAX_TOKENS", "maxTokens", "ELIYA_CONTEXT_WINDOW", "contextWindowTokens",
            "ELIYA_TEMPERATURE", "temperature", "ELIYA_EMBEDDING_MODEL", "embeddingModel");
    private static final Map<String,String> FILE_TO_FIELD = Map.of(
            "base.url", "baseUrl", "model", "model", "chat.model", "chatModel", "max.tokens", "maxTokens",
            "context.window.tokens", "contextWindowTokens", "temperature", "temperature",
            "embedding.model", "embeddingModel");
    private static final Set<String> NUMERIC = Set.of("maxTokens", "contextWindowTokens", "temperature");

    private EliyaCliModelConfig() { }

    public static Path defaultFile(Map<String,String> env) {
        String override = env == null ? null : env.get("ELIYA_CONFIG");
        if (override != null && !override.isBlank()) return Path.of(override);
        return Path.of(System.getProperty("user.home"), ".eliya", "config.properties");
    }

    public static Resolved load() {
        return load(System.getenv(), defaultFile(System.getenv()));
    }

    public static Resolved load(Map<String,String> env, Path file) {
        Map<String,Object> settings = new LinkedHashMap<>();
        String apiKey = null;
        String source = "none";
        Properties props = new Properties();
        if (file != null && Files.isRegularFile(file)) {
            try (InputStream in = Files.newInputStream(file)) {
                props.load(in);
                source = "file " + file;
            } catch (IOException ignored) { }
        }
        for (Map.Entry<String,String> entry : FILE_TO_FIELD.entrySet()) {
            put(settings, entry.getValue(), props.getProperty(entry.getKey()));
        }
        for (String name : props.stringPropertyNames()) {
            if (name.startsWith("setting.") && name.length() > "setting.".length()) {
                put(settings, name.substring("setting.".length()), props.getProperty(name));
            }
        }
        if (notBlank(props.getProperty("api.key"))) apiKey = props.getProperty("api.key").strip();
        boolean fromEnv = false;
        if (env != null) {
            for (Map.Entry<String,String> entry : ENV_TO_FIELD.entrySet()) {
                if (notBlank(env.get(entry.getKey()))) { put(settings, entry.getValue(), env.get(entry.getKey())); fromEnv = true; }
            }
            if (notBlank(env.get("ELIYA_API_KEY"))) { apiKey = env.get("ELIYA_API_KEY").strip(); fromEnv = true; }
        }
        if (fromEnv) source = source.equals("none") ? "environment" : "environment + " + source;
        if (!settings.containsKey("chatModel") && settings.containsKey("model")) settings.put("chatModel", settings.get("model"));
        // Terminal runs never wait for a browser plan approval.
        settings.putIfAbsent("agentPlanApproval", false);
        return new Resolved(apiKey, settings, source);
    }

    /** Write (or update) the config file with owner-only permissions. */
    public static void write(Path file, Map<String,String> values) throws IOException {
        Properties props = new Properties();
        if (Files.isRegularFile(file)) try (InputStream in = Files.newInputStream(file)) { props.load(in); }
        for (Map.Entry<String,String> entry : values.entrySet()) {
            if (entry.getValue() == null || entry.getValue().isBlank()) continue;
            props.setProperty(entry.getKey(), entry.getValue().strip());
        }
        Files.createDirectories(file.toAbsolutePath().getParent());
        Path tmp = Files.createTempFile(file.toAbsolutePath().getParent(), ".eliya-config-", ".tmp");
        restrict(tmp);
        try (OutputStream out = Files.newOutputStream(tmp)) {
            props.store(out, "ELIYA terminal model configuration (contains an API key: keep private)");
        }
        Files.move(tmp, file, StandardCopyOption.REPLACE_EXISTING);
        restrict(file);
    }

    private static void put(Map<String,Object> settings, String field, String raw) {
        if (!notBlank(raw)) return;
        String value = raw.strip();
        if (NUMERIC.contains(field)) {
            try {
                settings.put(field, field.equals("temperature") ? (Object) Double.parseDouble(value) : (Object) Integer.parseInt(value));
            } catch (NumberFormatException ignored) { /* invalid numbers are ignored, never fatal */ }
            return;
        }
        String low = value.toLowerCase(Locale.ROOT);
        if (low.equals("true") || low.equals("false")) settings.put(field, Boolean.parseBoolean(low));
        else settings.put(field, value);
    }

    private static void restrict(Path file) {
        try {
            Files.setPosixFilePermissions(file, Set.of(PosixFilePermission.OWNER_READ, PosixFilePermission.OWNER_WRITE));
        } catch (UnsupportedOperationException | IOException ignored) { /* Windows: user-profile ACLs apply */ }
    }

    private static boolean notBlank(Object value) {
        return value != null && !String.valueOf(value).isBlank();
    }
}
