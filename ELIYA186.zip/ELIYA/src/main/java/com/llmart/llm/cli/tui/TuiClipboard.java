package com.llmart.llm.cli.tui;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

/** Copy text: the terminal's OSC 52 clipboard (works over SSH) plus the desktop clipboard command when present. */
public final class TuiClipboard {
    private TuiClipboard() { }

    public static String osc52(String text) {
        return "\u001b]52;c;" + Base64.getEncoder().encodeToString(text.getBytes(StandardCharsets.UTF_8)) + "\u0007";
    }

    static List<String[]> commands() {
        String os = System.getProperty("os.name", "").toLowerCase(Locale.ROOT);
        List<String[]> commands = new ArrayList<>();
        if (os.contains("mac")) commands.add(new String[]{"pbcopy"});
        else if (os.contains("win")) commands.add(new String[]{"clip"});
        else {
            if (System.getenv("WAYLAND_DISPLAY") != null) commands.add(new String[]{"wl-copy"});
            commands.add(new String[]{"xclip", "-selection", "clipboard"});
            commands.add(new String[]{"xsel", "--clipboard", "--input"});
            commands.add(new String[]{"clip.exe"}); // WSL
        }
        return commands;
    }

    /** Try desktop clipboard commands; returns the command used or null. */
    public static String copyNative(String text) {
        for (String[] command : commands()) {
            try {
                Process process = new ProcessBuilder(command).redirectErrorStream(true)
                        .redirectOutput(ProcessBuilder.Redirect.DISCARD).start();
                byte[] bytes = command[0].startsWith("clip") ? ("\uFEFF" + text).getBytes(StandardCharsets.UTF_16LE) : text.getBytes(StandardCharsets.UTF_8);
                try (var stdin = process.getOutputStream()) { stdin.write(bytes); }
                if (process.waitFor(3, TimeUnit.SECONDS) && process.exitValue() == 0) return command[0];
                process.destroyForcibly();
            } catch (Exception notAvailable) { /* try the next one */ }
        }
        return null;
    }
}
