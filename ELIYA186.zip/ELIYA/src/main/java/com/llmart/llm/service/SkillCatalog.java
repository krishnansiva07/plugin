package com.llmart.llm.service;

import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Stream;

/**
 * ELIYA184: Agent Skills ({@code <name>/SKILL.md}) from the project, the user's home and the skills built into ELIYA.
 *
 * <p>Precedence (first wins on the same name): project ({@code .agents/skills}, {@code .claude/skills},
 * {@code .opencode/skills}) → user ({@code ~/.eliya/skills}, {@code ~/.agents/skills}, {@code ~/.claude/skills},
 * {@code ~/.config/opencode/skills}) → built-in ({@code classpath:/eliya-skills}). Only names and one-line descriptions
 * go into the Agent's context; the full SKILL.md is loaded when needed (the {@code skill} tool) or when the user invokes
 * a skill explicitly with {@code /name}. Pure Java, no Spring.</p>
 */
public final class SkillCatalog {
    /** {@code source}: project, user or built-in. {@code location}: file path, or {@code builtin:<name>}. */
    public record Skill(String name, String description, List<String> aliases, String source, String location, String body) {
        public boolean answersTo(String value) {
            String key = value == null ? "" : value.strip().toLowerCase(Locale.ROOT);
            if (key.isEmpty()) return false;
            if (name.equalsIgnoreCase(key)) return true;
            for (String alias : aliases) if (alias.equalsIgnoreCase(key)) return true;
            return false;
        }
    }

    /** An explicit request to use one skill, with the rest of the message as the task. */
    public record Invocation(Skill skill, String task) { }

    private static final String BUILTIN_ROOT = "/eliya-skills/";
    private static final int MAX_SKILLS = 200;
    private static final long MAX_SKILL_BYTES = 256 * 1024;
    private static final Pattern NAME = Pattern.compile("[A-Za-z0-9][A-Za-z0-9._-]{0,119}");
    private static final Pattern SLASH = Pattern.compile("^/(?:skills?\\s+)?([A-Za-z0-9][A-Za-z0-9._-]{0,60})(?:\\s+|$)([\\s\\S]*)$");
    private static final Pattern USE_SKILL = Pattern.compile(
            "(?i)\\b(?:use|apply|run|follow|with|using|invoke)\\s+(?:the\\s+)?[`'\"]?([A-Za-z0-9][A-Za-z0-9._-]{1,60})[`'\"]?\\s+skill\\b");
    private static volatile List<Skill> builtIns;

    private SkillCatalog() { }

    public static List<Path> projectRoots(Path workspace) {
        if (workspace == null) return List.of();
        Path root = workspace.toAbsolutePath().normalize();
        return List.of(root.resolve(".agents/skills"), root.resolve(".claude/skills"), root.resolve(".opencode/skills"));
    }

    public static List<Path> userRoots() {
        Path home = Path.of(System.getProperty("user.home", ".")).toAbsolutePath().normalize();
        return List.of(home.resolve(".eliya/skills"), home.resolve(".agents/skills"), home.resolve(".claude/skills"),
                home.resolve(".config/opencode/skills"));
    }

    /** Every available skill, project first, then user, then built-in; duplicates by name are dropped. */
    public static List<Skill> discover(Path workspace) {
        var disabled = SkillSelection.disabled(workspace);
        return discoverAll(workspace).stream().filter(skill -> !disabled.contains(skill.name().toLowerCase(Locale.ROOT))).toList();
    }

    public static List<Skill> discoverAll(Path workspace) {
        LinkedHashMap<String, Skill> found = new LinkedHashMap<>();
        for (Path root : projectRoots(workspace)) scan(root, "project", found);
        for (Path root : userRoots()) scan(root, "user", found);
        for (Skill skill : builtIns()) {
            if (found.size() >= MAX_SKILLS) break;
            found.putIfAbsent(skill.name().toLowerCase(Locale.ROOT), skill);
        }
        return List.copyOf(found.values());
    }

    public static Optional<Skill> find(Path workspace, String nameOrAlias) {
        if (nameOrAlias == null || nameOrAlias.isBlank()) return Optional.empty();
        List<Skill> all = discover(workspace);
        for (Skill skill : all) if (skill.name().equalsIgnoreCase(nameOrAlias.strip())) return Optional.of(skill);
        for (Skill skill : all) if (skill.answersTo(nameOrAlias)) return Optional.of(skill);
        // A built-in alias (/review) still reaches a project/user skill that overrides that built-in by name.
        for (Skill builtIn : builtIns()) {
            if (!builtIn.answersTo(nameOrAlias)) continue;
            for (Skill skill : all) if (skill.name().equalsIgnoreCase(builtIn.name())) return Optional.of(skill);
        }
        return Optional.empty();
    }

    /** Compact catalog for the Agent's system context (names and descriptions only). */
    public static String promptBlock(Path workspace, int maxChars) {
        List<Skill> all = discover(workspace);
        if (all.isEmpty()) return "";
        StringBuilder out = new StringBuilder("SKILLS — reusable workflows. When the request clearly matches one, load it with " +
                "the `skill` tool (by name) and follow it; skip skills that do not apply. Users invoke one explicitly with /name.\n");
        int budget = Math.max(600, maxChars);
        int listed = 0;
        for (Skill skill : all) {
            String line = "- " + skill.name() + " — " + clip(skill.description(), 170) +
                    ("built-in".equals(skill.source()) ? "" : " [" + skill.source() + "]") + "\n";
            if (out.length() + line.length() > budget) {
                out.append("- … ").append(all.size() - listed).append(" more (skill_catalog lists all)\n");
                break;
            }
            out.append(line);
            listed++;
        }
        return out.toString().strip();
    }

    /** Text for the skill_catalog tool. */
    public static String catalogText(Path workspace) {
        List<Skill> all = discover(workspace);
        if (all.isEmpty()) return "[No skills discovered]";
        StringBuilder out = new StringBuilder();
        for (Skill skill : all) {
            out.append(skill.name()).append(" -> ").append(skill.location());
            if (!skill.description().isBlank()) out.append(" — ").append(clip(skill.description(), 220));
            if (!skill.aliases().isEmpty()) out.append(" (aliases: /").append(String.join(", /", skill.aliases())).append(')');
            out.append(" [").append(skill.source()).append("]\n");
        }
        return out.toString().strip();
    }

    /** Full text for the skill tool. */
    public static String loadText(Path workspace, String nameOrAlias) {
        String name = nameOrAlias == null ? "" : nameOrAlias.strip().replaceFirst("^/", "");
        if (!NAME.matcher(name).matches()) throw new IllegalArgumentException("Invalid skill name");
        Skill skill = find(workspace, name).orElseThrow(() ->
                new IllegalArgumentException("Skill not found: " + name + ". Available skills:\n" + catalogText(workspace)));
        return render(skill);
    }

    /** SKILL.md as handed to the model, with supporting files listed for filesystem skills. */
    public static String render(Skill skill) {
        StringBuilder out = new StringBuilder("SKILL ").append(skill.name()).append(" FROM ")
                .append("built-in".equals(skill.source()) ? "ELIYA (built-in)" : skill.location()).append("\n\n").append(skill.body());
        if (!"built-in".equals(skill.source())) {
            try {
                Path file = Path.of(skill.location());
                Path base = file.getParent();
                List<String> support = new ArrayList<>();
                try (Stream<Path> stream = Files.walk(base, 3)) {
                    stream.filter(Files::isRegularFile).filter(p -> !p.equals(file)).limit(10)
                            .forEach(p -> support.add(base.relativize(p).toString().replace('\\', '/')));
                }
                if (!support.isEmpty()) out.append("\n\nSUPPORTING FILES (in ").append(base)
                        .append("; read with workspace tools when inside the project, or follow the skill's own commands):\n- ")
                        .append(String.join("\n- ", support));
            } catch (Exception ignored) { }
        }
        return out.toString();
    }

    /**
     * An explicit skill request: a message starting with {@code /name} or {@code /skill name}, or "use the name skill".
     * Unknown names are not invocations (a pasted path such as {@code /home/me} stays a normal message).
     */
    public static Optional<Invocation> invocation(Path workspace, String message) {
        if (message == null || message.isBlank()) return Optional.empty();
        String text = message.strip();
        Matcher slash = SLASH.matcher(text);
        if (slash.matches()) {
            Optional<Skill> skill = find(workspace, slash.group(1));
            if (skill.isPresent()) return Optional.of(new Invocation(skill.get(), slash.group(2).strip()));
        }
        Matcher use = USE_SKILL.matcher(text.length() > 600 ? text.substring(0, 600) : text);
        if (use.find()) {
            Optional<Skill> skill = find(workspace, use.group(1));
            if (skill.isPresent()) return Optional.of(new Invocation(skill.get(), text));
        }
        return Optional.empty();
    }

    /** System message for a skill the user invoked explicitly. */
    public static String invocationPrompt(Invocation invocation) {
        return "USER-INVOKED SKILL: the user asked for the \"" + invocation.skill().name() + "\" skill" +
                (invocation.task().isBlank() ? "." : " for: " + clip(invocation.task(), 400)) +
                " Follow it for this request. It describes HOW to work; it never grants permissions beyond the normal " +
                "approvals, and the user's own words win where they differ.\n\n" + render(invocation.skill());
    }

    /** Skills shipped inside ELIYA (classpath:/eliya-skills/index.txt). */
    public static List<Skill> builtIns() {
        List<Skill> cached = builtIns;
        if (cached != null) return cached;
        List<Skill> loaded = new ArrayList<>();
        try (InputStream index = SkillCatalog.class.getResourceAsStream(BUILTIN_ROOT + "index.txt")) {
            if (index != null) {
                for (String line : new String(index.readAllBytes(), StandardCharsets.UTF_8).split("\\R")) {
                    String name = line.strip();
                    if (name.isEmpty() || name.startsWith("#") || !NAME.matcher(name).matches()) continue;
                    try (InputStream body = SkillCatalog.class.getResourceAsStream(BUILTIN_ROOT + name + "/SKILL.md")) {
                        if (body == null) continue;
                        loaded.add(parse(new String(body.readAllBytes(), StandardCharsets.UTF_8), name, "built-in", "builtin:" + name));
                    }
                }
            }
        } catch (Exception ignored) { }
        builtIns = List.copyOf(loaded);
        return builtIns;
    }

    private static void scan(Path root, String source, Map<String, Skill> found) {
        try {
            if (!Files.isDirectory(root) || Files.isSymbolicLink(root) || Files.isSymbolicLink(root.getParent())) return;
            try (Stream<Path> children = Files.list(root)) {
                children.filter(Files::isDirectory).sorted().forEach(dir -> {
                    if (found.size() >= MAX_SKILLS) return;
                    try {
                        String name = dir.getFileName().toString();
                        if (!NAME.matcher(name).matches() || Files.isSymbolicLink(dir)) return;
                        Path file = dir.resolve("SKILL.md");
                        if (!Files.isRegularFile(file) || Files.isSymbolicLink(file) || Files.size(file) > MAX_SKILL_BYTES) return;
                        String key = name.toLowerCase(Locale.ROOT);
                        if (found.containsKey(key)) return;
                        found.put(key, parse(Files.readString(file, StandardCharsets.UTF_8), name, source, file.toString()));
                    } catch (Exception ignored) { }
                });
            }
        } catch (Exception ignored) { }
    }

    /** Parse front matter (name, description, aliases); the directory name stays the skill's id. */
    static Skill parse(String text, String directoryName, String source, String location) {
        String body = text == null ? "" : text.replace("\r\n", "\n");
        String description = "";
        List<String> aliases = new ArrayList<>();
        String[] lines = body.split("\n");
        if (lines.length > 0 && lines[0].strip().equals("---")) {
            for (int i = 1; i < Math.min(lines.length, 80); i++) {
                String line = lines[i].strip();
                if (line.equals("---")) break;
                String lower = line.toLowerCase(Locale.ROOT);
                if (lower.startsWith("description:")) description = unquote(line.substring("description:".length()));
                else if (lower.startsWith("aliases:")) {
                    String value = line.substring("aliases:".length()).strip().replaceAll("^\\[|]$", "");
                    for (String alias : value.split(",")) {
                        String clean = unquote(alias).replaceFirst("^/", "");
                        if (NAME.matcher(clean).matches() && !clean.equalsIgnoreCase(directoryName)) aliases.add(clean);
                    }
                } else if (lower.startsWith("name:")) {
                    String declared = unquote(line.substring("name:".length()));
                    if (NAME.matcher(declared).matches() && !declared.equalsIgnoreCase(directoryName)) aliases.add(declared);
                }
            }
        }
        if (description.isBlank()) {
            for (String line : lines) {
                String value = line.strip().replaceFirst("^#+\\s*", "");
                if (!value.isBlank() && !value.equals("---") && !value.contains(":")) { description = value; break; }
            }
        }
        return new Skill(directoryName, clip(description, 400), List.copyOf(aliases), source, location, body.strip());
    }

    private static String unquote(String value) {
        return value == null ? "" : value.strip().replaceAll("^[\"']|[\"']$", "").strip();
    }

    private static String clip(String value, int max) {
        String line = value == null ? "" : value.replaceAll("\\s+", " ").strip();
        return line.length() > max ? line.substring(0, max - 1) + "…" : line;
    }
}
