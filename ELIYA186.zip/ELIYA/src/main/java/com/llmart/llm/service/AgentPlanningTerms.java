package com.llmart.llm.service;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Extracts the search terms used to gather planning evidence from a user request.
 *
 * <p>The previous implementation took the first two words of four or more letters, so a request such as
 * "Eliya analyse the OrderService retry logic" searched for "eliya" and "analyse" and gave the planner no
 * relevant code. Here, concrete code anchors (paths, file names, CamelCase/snake_case identifiers,
 * dotted names, quoted strings) win, followed by distinctive domain words.</p>
 */
final class AgentPlanningTerms {
    private static final Pattern QUOTED = Pattern.compile("[\"'`]([^\"'`\\n]{3,80})[\"'`]");
    private static final Pattern PATH_OR_FILE = Pattern.compile(
            "(?<![\\w.-])(?:[\\w.-]+[/\\\\])*[\\w-]+\\.[A-Za-z][A-Za-z0-9]{0,9}(?![\\w])");
    private static final Pattern CAMEL = Pattern.compile("\\b[A-Za-z]*[a-z][A-Z][A-Za-z0-9]*\\b|\\b[A-Z][a-z0-9]+(?:[A-Z][a-z0-9]+)+\\b");
    private static final Pattern SNAKE = Pattern.compile("\\b[a-z][a-z0-9]*(?:_[a-z0-9]+)+\\b");
    private static final Pattern DOTTED = Pattern.compile("\\b[a-z][\\w]*(?:\\.[a-z_][\\w]*){2,}\\b");
    private static final Pattern WORD = Pattern.compile("[a-z][a-z0-9_-]{3,}");
    private static final Set<String> STOP = Set.of(
            "this", "that", "with", "from", "into", "then", "have", "will", "should", "would", "could", "agent",
            "plan", "user", "please", "make", "work", "working", "issue", "issues", "test", "tests", "project", "eliya",
            "analyse", "analyze", "analysis", "implement", "implementation", "create", "update", "change", "changes", "using", "code", "file",
            "files", "need", "needs", "want", "also", "only", "each", "every", "there", "their", "what", "when",
            "where", "which", "while", "about", "after", "before", "existing", "current", "check", "review", "explain", "show",
            "give", "help", "write", "find", "look", "fix", "able", "properly", "correctly", "sometimes", "always", "never",
            "feature", "functionality", "application", "system", "repository", "codebase", "workspace", "requirement", "requirements", "task", "tasks", "step",
            "steps", "good", "better", "best", "like", "same", "other", "through", "does", "doing", "done", "used",
            "uses", "based", "etc", "here", "them", "they", "your", "ours", "these", "those", "some", "more");
    private static final Set<String> COMMON_EXTENSIONS_AS_WORDS = Set.of("e.g", "i.e", "etc.");

    private AgentPlanningTerms() { }

    /** Ordered, de-duplicated search terms, most specific first. */
    static List<String> extract(String task, int max) {
        if (task == null || task.isBlank() || max <= 0) return List.of();
        LinkedHashSet<String> anchors = new LinkedHashSet<>();
        addAll(anchors, QUOTED, task, 1);
        addAll(anchors, PATH_OR_FILE, task, 0);
        addAll(anchors, CAMEL, task, 0);
        addAll(anchors, SNAKE, task, 0);
        addAll(anchors, DOTTED, task, 0);
        List<String> out = new ArrayList<>();
        for (String anchor : anchors) {
            String value = anchor.strip();
            if (value.length() < 3 || COMMON_EXTENSIONS_AS_WORDS.contains(value.toLowerCase(Locale.ROOT))) continue;
            if (value.matches("\\d+(?:\\.\\d+)*")) continue; // version numbers are not useful search anchors
            if (!containsIgnoreCase(out, value)) out.add(value);
            if (out.size() >= max) return out;
        }
        Matcher words = WORD.matcher(task.toLowerCase(Locale.ROOT));
        while (words.find() && out.size() < max) {
            String word = words.group();
            if (STOP.contains(word) || word.matches(".*\\d{3,}.*")) continue;
            if (!containsIgnoreCase(out, word)) out.add(word);
        }
        return out;
    }

    /** True when the text names at least one concrete code anchor (path, file, identifier). */
    static boolean hasConcreteAnchor(String text) {
        if (text == null || text.isBlank()) return false;
        return PATH_OR_FILE.matcher(text).find() || CAMEL.matcher(text).find() ||
                SNAKE.matcher(text).find() || DOTTED.matcher(text).find() || text.contains("`");
    }

    private static void addAll(Set<String> out, Pattern pattern, String text, int group) {
        Matcher matcher = pattern.matcher(text);
        while (matcher.find()) out.add(matcher.group(group));
    }

    private static boolean containsIgnoreCase(List<String> values, String candidate) {
        for (String value : values) if (value.equalsIgnoreCase(candidate)) return true;
        return false;
    }
}
