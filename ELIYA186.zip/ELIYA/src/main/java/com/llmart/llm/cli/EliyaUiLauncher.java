package com.llmart.llm.cli;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Opens Eliya surfaces outside the current terminal: the browser UI as an app-style window
 * (Edge/Chrome/Chromium {@code --app=}), or the terminal chat in a new OS terminal window.
 */
public final class EliyaUiLauncher {
    private EliyaUiLauncher() { }

    /** Which surface a launcher invocation opens. */
    public enum UiChoice { CLASSIC, CHAT, LINE_CHAT, WINDOW, NEW_TERMINAL }

    /**
     * {@code eliya} (no command), {@code eliya chat}, and interactive {@code eliya analyse|agent} without a prompt open the
     * terminal chat. {@code --window} opens the browser UI as an app window, {@code --new-terminal} opens the chat in a new
     * terminal window. {@code eliya web}, {@code --browser}, {@code --no-browser}, {@code --classic}, ELIYA_UI=classic or a
     * non-interactive shell keep the previous behaviour.
     */
    public static UiChoice chooseUi(String[] args, java.util.List<String> given, boolean noBrowser, String envUi, boolean console,
                                    java.util.function.BooleanSupplier rawTerminalSupported) {
        String env = envUi == null ? "" : envUi.strip().toLowerCase(Locale.ROOT);
        String command = args.length == 0 ? "" : args[0].toLowerCase(Locale.ROOT);
        boolean chatCommand = command.equals("chat");
        boolean interactiveAi = args.length == 1 && (command.equals("analyse") || command.equals("analyze") || command.equals("agent"));
        boolean bare = args.length == 0;
        if (given.contains("--new-terminal")) return bare || chatCommand || interactiveAi ? UiChoice.NEW_TERMINAL : UiChoice.CLASSIC;
        if (given.contains("--window")) return bare || chatCommand || interactiveAi ? UiChoice.WINDOW : UiChoice.CLASSIC;
        if (command.equals("web") || given.contains("--browser") || given.contains("--classic")) return UiChoice.CLASSIC;
        if (!(bare || chatCommand || interactiveAi)) return UiChoice.CLASSIC;
        if (bare && noBrowser && !given.contains("--tui") && !given.contains("--line")) return UiChoice.CLASSIC; // headless server
        if (!chatCommand && !given.contains("--tui") && !given.contains("--line")) {
            if (env.equals("classic") || env.equals("browser") || env.equals("web")) return UiChoice.CLASSIC;
            if (env.equals("window")) return bare ? UiChoice.WINDOW : UiChoice.CLASSIC;
            if (!console) return UiChoice.CLASSIC;
        }
        if (given.contains("--line") || env.equals("line")) return UiChoice.LINE_CHAT;
        // --tui / ELIYA_UI=tui also asks for the Windows full-screen preview (falls back to the line chat).
        return rawTerminalSupported.getAsBoolean() || given.contains("--tui") || env.equals("tui") ? UiChoice.CHAT : UiChoice.LINE_CHAT;
    }

    public static String chatMode(String[] args) {
        int index = args.length > 0 && args[0].equalsIgnoreCase("chat") ? 1 : 0;
        String word = args.length > index ? args[index].toLowerCase(Locale.ROOT) : "";
        return word.equals("agent") ? "agent" : "analyse";
    }

    enum Os { WINDOWS, MAC, LINUX }

    static Os os() {
        String name = System.getProperty("os.name", "").toLowerCase(Locale.ROOT);
        return name.contains("win") ? Os.WINDOWS : name.contains("mac") ? Os.MAC : Os.LINUX;
    }

    /** Candidate Chromium-family browsers that support {@code --app=URL}. */
    static List<List<String>> appWindowCommands(Os os, String url, java.util.function.Predicate<Path> exists) {
        List<List<String>> commands = new ArrayList<>();
        String app = "--app=" + url;
        switch (os) {
            case WINDOWS -> {
                List<String> roots = new ArrayList<>();
                for (String variable : List.of("ProgramFiles(x86)", "ProgramFiles", "LOCALAPPDATA")) {
                    String value = System.getenv(variable);
                    if (value != null && !value.isBlank()) roots.add(value);
                }
                for (String root : roots) {
                    for (String relative : List.of("Microsoft\\Edge\\Application\\msedge.exe", "Google\\Chrome\\Application\\chrome.exe")) {
                        Path candidate = Path.of(root, relative);
                        if (exists.test(candidate)) commands.add(List.of(candidate.toString(), app, "--new-window"));
                    }
                }
                // App Paths registration lets `start msedge` work even when the install path differs.
                commands.add(List.of("cmd", "/c", "start", "\"\"", "msedge", app));
                commands.add(List.of("cmd", "/c", "start", "\"\"", "chrome", app));
            }
            case MAC -> {
                for (String appName : List.of("Google Chrome", "Microsoft Edge", "Chromium", "Brave Browser")) {
                    Path bundle = Path.of("/Applications", appName + ".app");
                    if (exists.test(bundle)) commands.add(List.of("open", "-na", appName, "--args", app));
                }
            }
            case LINUX -> {
                for (String binary : List.of("google-chrome", "google-chrome-stable", "chromium", "chromium-browser",
                        "microsoft-edge", "microsoft-edge-stable", "brave-browser")) {
                    Path found = onPath(binary, exists);
                    if (found != null) commands.add(List.of(found.toString(), app));
                }
            }
        }
        return commands;
    }

    static Path onPath(String binary, java.util.function.Predicate<Path> exists) {
        String path = System.getenv("PATH");
        if (path == null) return null;
        for (String dir : path.split(java.io.File.pathSeparator)) {
            if (dir.isBlank()) continue;
            Path candidate = Path.of(dir, binary);
            if (exists.test(candidate)) return candidate;
        }
        return null;
    }

    /** Open the browser UI in an app window (no tabs/address bar); falls back to the default browser. */
    public static void openAppWindow(String url) {
        if (!isLocalUrl(url)) return;
        for (List<String> command : appWindowCommands(os(), url, Files::isRegularFile)) {
            if (startDetached(command)) return;
        }
        for (List<String> command : appWindowCommands(os(), url, Files::isDirectory)) { // mac .app bundles
            if (startDetached(command)) return;
        }
        EliyaCliBridge.openBrowser(url);
    }

    static boolean isLocalUrl(String url) {
        try {
            java.net.URI address = java.net.URI.create(url);
            return "http".equals(address.getScheme()) &&
                    ("localhost".equalsIgnoreCase(address.getHost()) || "127.0.0.1".equals(address.getHost()));
        } catch (Exception invalid) { return false; }
    }

    static boolean startDetached(List<String> command) {
        try {
            new ProcessBuilder(command).redirectErrorStream(true).redirectOutput(ProcessBuilder.Redirect.DISCARD).start();
            return true;
        } catch (Exception unavailable) {
            return false;
        }
    }

    /** Commands that open a new terminal window running {@code eliyaCommand} in {@code directory}. */
    static List<List<String>> newTerminalCommands(Os os, List<String> eliyaCommand, String directory,
                                                  java.util.function.Predicate<Path> exists) {
        List<List<String>> commands = new ArrayList<>();
        String joinedPosix = String.join(" ", eliyaCommand.stream().map(EliyaUiLauncher::shQuote).toList());
        switch (os) {
            case WINDOWS -> {
                if (onPath("wt.exe", exists) != null || exists.test(Path.of(String.valueOf(System.getenv("LOCALAPPDATA")),
                        "Microsoft", "WindowsApps", "wt.exe"))) {
                    List<String> wt = new ArrayList<>(List.of("wt.exe", "-w", "new", "--title", "Eliya", "-d", directory));
                    wt.addAll(eliyaCommand);
                    commands.add(wt);
                }
                List<String> start = new ArrayList<>(List.of("cmd", "/c", "start", "\"Eliya\"", "/D", directory));
                start.addAll(eliyaCommand);
                commands.add(start);
            }
            case MAC -> {
                String script = "cd " + shQuote(directory) + " && " + joinedPosix;
                commands.add(List.of("osascript", "-e", "tell application \"Terminal\" to do script \"" +
                        script.replace("\\", "\\\\").replace("\"", "\\\"") + "\"", "-e", "tell application \"Terminal\" to activate"));
            }
            case LINUX -> {
                String shell = "cd " + shQuote(directory) + " && " + joinedPosix + "; exec ${SHELL:-sh}";
                String preferred = System.getenv("TERMINAL");
                if (preferred != null && !preferred.isBlank() && onPath(preferred, exists) != null)
                    commands.add(List.of(preferred, "-e", "sh", "-c", shell));
                if (onPath("x-terminal-emulator", exists) != null) commands.add(List.of("x-terminal-emulator", "-e", "sh", "-c", shell));
                if (onPath("gnome-terminal", exists) != null) commands.add(List.of("gnome-terminal", "--title=Eliya", "--", "sh", "-c", shell));
                if (onPath("konsole", exists) != null) commands.add(List.of("konsole", "-e", "sh", "-c", shell));
                if (onPath("xfce4-terminal", exists) != null) commands.add(List.of("xfce4-terminal", "-T", "Eliya", "-x", "sh", "-c", shell));
                if (onPath("kitty", exists) != null) commands.add(List.of("kitty", "--title", "Eliya", "sh", "-c", shell));
                if (onPath("alacritty", exists) != null) commands.add(List.of("alacritty", "-t", "Eliya", "-e", "sh", "-c", shell));
                if (onPath("wezterm", exists) != null) commands.add(List.of("wezterm", "start", "--", "sh", "-c", shell));
                if (onPath("xterm", exists) != null) commands.add(List.of("xterm", "-T", "Eliya", "-e", "sh", "-c", shell));
            }
        }
        return commands;
    }

    static String shQuote(String value) {
        if (value.matches("[A-Za-z0-9_./:=@%+-]+")) return value;
        return "'" + value.replace("'", "'\"'\"'") + "'";
    }

    /** Open the terminal chat in a new terminal window. Returns false when no terminal program was found. */
    public static boolean openNewTerminal(List<String> eliyaCommand, String directory) {
        for (List<String> command : newTerminalCommands(os(), eliyaCommand, directory, Files::isRegularFile)) {
            if (startDetached(command)) return true;
        }
        return false;
    }
}
