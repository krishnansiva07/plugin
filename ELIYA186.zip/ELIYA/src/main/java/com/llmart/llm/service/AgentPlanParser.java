package com.llmart.llm.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * Parses planner model output into plan steps and judges whether the draft is usable.
 * Extracted from {@code AgentService} (parsePlanItems and the JSON/plain-text branch of generatePlanProposal).
 */
final class AgentPlanParser {
    private static final ObjectMapper JSON = new ObjectMapper();

    private AgentPlanParser() { }

    /**
     * Result of parsing one planner response.
     * @param steps   parsed steps (empty when unusable)
     * @param problem why the draft was rejected or is weak; blank when good
     * @param hard    true when the draft is unusable (empty/malformed/placeholder); false for a soft quality issue
     */
    record Draft(List<String> steps, String problem, boolean hard) {
        boolean usable() { return !steps.isEmpty() && !hard; }
    }

    /** Parse a planner response and apply hard (placeholder) and soft (no concrete anchors) quality checks. */
    static Draft judge(String response, String task, String evidence) {
        String text = response == null ? "" : response.strip();
        if (text.isBlank()) return new Draft(List.of(), "empty planner response", true);
        String envelope = AgentPlanJsonEnvelope.extract(text);
        List<String> parsed = List.of();
        if (AgentPlanRecovery.looksStructured(text)) {
            try {
                JsonNode json = JSON.readTree(envelope);
                JsonNode items = json.isArray() ? json : json.path("plan");
                if (!items.isArray() && json.isObject()) items = json.path("steps");
                if (!items.isArray() && json.isObject()) items = json.path("tasks");
                if (items.isArray()) {
                    parsed = parseItems(envelope).stream().map(AgentPlanStructure::normalizeValidationLabel).toList();
                }
            } catch (Exception malformed) {
                // A truncated JSON array must NOT be accepted as a partial plan.
                return new Draft(List.of(), "incomplete or malformed planner JSON", true);
            }
        } else {
            parsed = AgentPlanRecovery.plainSteps(text).stream().map(AgentPlanStructure::normalizeValidationLabel).toList();
        }
        if (parsed.isEmpty()) return new Draft(List.of(), "planner response contained no executable steps", true);
        String placeholder = AgentPlanSpecificity.mismatch(task, parsed);
        if (!placeholder.isBlank()) return new Draft(List.of(), placeholder, true);
        String vague = AgentPlanSpecificity.lacksConcreteAnchors(task, parsed, evidence);
        // Requirement-to-step coverage: every phase, named file/module and migration source/target in the request
        // must be visible in some step. Gaps trigger the planner's corrective round (soft, never discards the plan).
        String gaps = AgentRequirementCoverage.gapSummary(task, parsed);
        String problem = vague.isBlank() ? gaps : gaps.isBlank() ? vague : vague + ". " + gaps;
        return new Draft(parsed, problem, false);
    }

    static List<String> parseItems(String raw) {
        if (raw == null || raw.isBlank()) return List.of();
        LinkedHashSet<String> unique = new LinkedHashSet<>();
        try {
            JsonNode json = JSON.readTree(AgentPlanJsonEnvelope.extract(raw));
            JsonNode arr = json != null && json.isArray() ? json : json == null ? null : json.path("plan");
            if (arr != null && !arr.isArray() && json != null && json.isObject()) arr = json.path("steps");
            if (arr != null && !arr.isArray() && json != null && json.isObject()) arr = json.path("tasks");
            if (arr != null && arr.isArray()) {
                for (JsonNode item : arr) {
                    String text = item.isTextual() ? item.asText() : structuredPlanItemText(item);
                    addPlanItem(unique, text);
                    if (unique.size() >= 60) break;
                }
                if (!unique.isEmpty()) return List.copyOf(unique);
            }
        } catch (Exception ignored) { }
        for (String line : raw.split("\\R")) {
            addPlanItem(unique, line);
            if (unique.size() >= 60) break;
        }
        return List.copyOf(unique);
    }

    /** Convert planner JSON into a compact, human-readable structure while keeping the existing PlanItem contract. */
    private static String structuredPlanItemText(JsonNode item) {
        if (item == null || !item.isObject()) return "";
        String legacy = item.path("text").asText("").strip();
        if (!legacy.isBlank()) {
            if (AgentPlanStructure.hasValidationEvidence(legacy)) return legacy;
            StringBuilder out = new StringBuilder(legacy);
            appendPlanValidationEvidence(out, item);
            return out.toString();
        }
        String title = item.path("title").asText("").strip();
        String objective = item.path("objective").asText("").strip();
        if (title.isBlank() && objective.isBlank()) return "";
        StringBuilder out = new StringBuilder(title.isBlank() ? objective : title);
        if (!objective.isBlank() && !objective.equalsIgnoreCase(title)) out.append("\nObjective: ").append(objective);
        appendStructuredArray(out, "Files", item.path("files"), false);
        appendPlanValidationEvidence(out, item);
        JsonNode deps = item.path("dependsOn");
        if (deps.isArray() && !deps.isEmpty()) {
            List<String> values = new ArrayList<>();
            for (JsonNode dep : deps) if (dep.canConvertToInt() && dep.asInt() > 0) values.add(String.valueOf(dep.asInt()));
            if (!values.isEmpty()) out.append("\nDepends on: ").append(String.join(", ", values));
        }
        String risk = item.path("risk").asText("").strip().toLowerCase(Locale.ROOT);
        if (Set.of("low", "medium", "high").contains(risk)) out.append("\nRisk: ").append(risk);
        return out.toString();
    }

    /** Providers sometimes use alternate JSON check-field names or a single validation string. */
    private static void appendPlanValidationEvidence(StringBuilder out, JsonNode item) {
        for (String key : List.of("validation", "validations", "checks", "verification", "acceptanceCriteria", "successCriteria")) {
            JsonNode node = item.path(key);
            if (node.isArray() && !node.isEmpty()) {
                int before = out.length();
                appendStructuredArray(out, "Validate", node, false);
                if (out.length() > before) return;
            }
            if (node.isTextual() && !node.asText("").isBlank()) {
                out.append("\nValidate: ").append(node.asText("").strip());
                return;
            }
        }
    }

    private static void appendStructuredArray(StringBuilder out, String label, JsonNode node, boolean required) {
        if (node == null || !node.isArray()) return;
        List<String> values = new ArrayList<>();
        for (JsonNode value : node) {
            String text = value.asText("").strip();
            if (!text.isBlank()) values.add(text.replaceAll("\\s+", " "));
            if (values.size() >= 6) break;
        }
        if (!values.isEmpty()) out.append("\n").append(label).append(": ").append(String.join(" • ", values));
        else if (required) out.append("\n").append(label).append(": [required]");
    }

    private static void addPlanItem(Set<String> out, String raw) {
        String item = cleanPlanItem(raw);
        if (item.isBlank()) return;
        String low = item.toLowerCase(Locale.ROOT);
        if (Set.of("plan", "execution plan", "steps", "todo", "pending", "completed", "done", "in progress", "in_progress").contains(low)) return;
        if (low.startsWith("here is") || low.startsWith("here's") || low.startsWith("execution plan:")) return;
        // Decoration-only lines were previously being counted as planned work. Require meaningful letters/digits
        // and enough descriptive content to be executable.
        if (!item.matches("(?s).*[\\p{L}\\p{N}].*") || item.replaceAll("[^\\p{L}\\p{N}]", "").length() < 8) return;
        out.add(item);
    }

    private static String cleanPlanItem(String value) {
        if (value == null) return "";
        String item = value.strip();
        if (item.isBlank() || item.startsWith("```") || item.startsWith("~~~") || item.matches("^#{1,6}\\s+.*")) return "";
        item = item.replaceFirst("^\\d{1,2}[.)]\\s*", "");
        item = item.replaceFirst("^\\[[ xX✓✔]\\]\\s*", "");
        item = item.replaceFirst("^[\\-*•‣▪▫◦]+\\s*", "");
        // Strip common visual/status prefixes without treating the symbol itself as work.
        item = item.replaceFirst("^(?:✅|☑️?|✔️?|✓|🔲|⬜|🟩|🟢|🔹|🔸|➡️?|→|➜|➤|▶️?|⏳|🛠️?|⚙️?)\\s*", "");
        item = item.replaceFirst("^(?i:(?:step|task)\\s+\\d{1,2}\\s*[:.)-]\\s*)", "");
        item = item.replaceAll("^\\*\\*|\\*\\*$", "").strip();
        if (item.matches("^[\\p{So}\\p{Sk}\\p{Sm}\\p{Punct}\\s]+$")) return "";
        return item.length() <= 1_400 ? item : item.substring(0, 1_400);
    }
}
