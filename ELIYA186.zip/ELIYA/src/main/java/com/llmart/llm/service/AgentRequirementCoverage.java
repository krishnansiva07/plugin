package com.llmart.llm.service;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Requirement-to-step coverage for Agent plans.
 *
 * <p>Requirements are extracted only from the user's own words: explicitly numbered phases/steps, named files and
 * paths, named modules, migration source and target, and requested output files. A plan is checked so that every
 * requirement is visibly covered by at least one step. Gaps are fed back to the planner's corrective round; any gap
 * that remains is attached to the final step as a checklist quoting the request, so it is verified rather than
 * silently dropped. Nothing here invents new steps or work.</p>
 */
final class AgentRequirementCoverage {
    /** One requirement in the user's words, with the terms that show a step covers it. */
    record Requirement(String kind, String text, List<String> evidenceTerms, int minimumMatches) { }

    private static final Pattern FILE_OR_PATH = Pattern.compile(
            "(?<![\\w.-])(?:[\\w.-]+[/\\\\])*[\\w-]+\\.(?:java|kt|ts|tsx|js|jsx|py|go|cs|xml|ya?ml|json|properties|gradle|md|html|xlsx|docx|feature|sql|sh|cmd|ps1)(?![\\w])",
            Pattern.CASE_INSENSITIVE);
    private static final Pattern MIGRATE = Pattern.compile(
            "(?i)\\b(?:migrat(?:e|ion|ing)|convert(?:ing)?|port(?:ing)?|upgrad(?:e|ing)|mov(?:e|ing))\\b[^.\\n]{0,80}?\\bfrom\\s+([\\w.+#/-]+(?:\\s+[\\w.+#/-]+)?)\\s+(?:to|into)\\s+([\\w.+#/-]+(?:\\s+[\\w.+#/-]+)?)");
    private static final Pattern MIGRATE_TO = Pattern.compile(
            "(?i)\\b(?:migrat(?:e|ion)|convert|port|upgrade)\\s+(?:the\\s+)?([\\w.+#/-]+(?:\\s+[\\w.+#/-]+)?)\\s+(?:to|into)\\s+([\\w.+#/-]+(?:\\s+[\\w.+#/-]+)?)");
    private static final Pattern MODULE_LIST = Pattern.compile(
            "(?i)\\b(?:modules?|services?|components?|packages?|microservices?)\\s*(?::|named|called|like|such as|including)?\\s*" +
            "((?:[`'\"]?[\\w./-]+[`'\"]?\\s*(?:,|and|&)\\s*){1,20}[`'\"]?[\\w./-]+[`'\"]?)");
    // "the billing, orders and shipping modules": list written BEFORE the noun.
    private static final Pattern MODULE_LIST_BEFORE = Pattern.compile(
            "(?i)((?:[`'\"]?[\\w./-]+[`'\"]?\\s*(?:,|\\band\\b|&)\\s*){1,20}[`'\"]?[\\w./-]+[`'\"]?)\\s+(?:modules|services|components|packages|microservices)\\b");
    private static final Pattern WORD = Pattern.compile("[a-z][a-z0-9_-]{2,}");
    private static final Set<String> STOP = Set.of("the", "and", "for", "with", "that", "this", "into", "from", "then", "all",
            "any", "each", "every", "must", "should", "will", "make", "sure", "using", "use", "new", "existing", "code",
            "file", "files", "step", "phase", "item", "task", "please", "also", "only", "not", "are", "its", "their", "them",
            "have", "has", "been", "was", "were", "able", "need", "needs", "want", "like", "same", "other");
    private static final Set<String> FILLER_MODULES = Set.of("and", "or", "the", "a", "an", "all", "each", "every", "other", "etc");

    private AgentRequirementCoverage() { }

    static List<Requirement> extract(String task) {
        List<Requirement> out = new ArrayList<>();
        if (task == null || task.isBlank()) return out;
        // 1) Explicit numbered phases/steps the user wrote: each must map to a step (by its key words).
        for (String phase : AgentPlanRecovery.extractUserPhases(task)) {
            String body = phase.replaceFirst("(?i)^(?:phase|item|ordered user instructions)\\s*[\\d–-]*\\s*:\\s*", "");
            List<String> words = keyWords(body, 6);
            if (!words.isEmpty()) out.add(new Requirement("phase", body.strip(), words, Math.max(1, (words.size() + 1) / 2)));
        }
        // 1b) Explicit bullet / action-clause requirements of a multi-requirement brief (ELIYA173 extraction).
        List<String> bullets = AgentPlanRecovery.extractUserRequirements(task);
        if (bullets.size() >= 2) {
            for (String bullet : bullets) {
                List<String> words = keyWords(bullet, 6);
                if (!words.isEmpty()) out.add(new Requirement("requirement", bullet, words, Math.max(1, (words.size() + 1) / 2)));
            }
        }
        // 2) Migration source and target must both appear.
        Matcher migrate = MIGRATE.matcher(task);
        Matcher migrateTo = MIGRATE_TO.matcher(task);
        if (migrate.find()) addMigration(out, migrate.group(1), migrate.group(2));
        else if (migrateTo.find()) addMigration(out, migrateTo.group(1), migrateTo.group(2));
        else MigrationIntent.parse(task).ifPresent(spec -> addMigration(out, spec.source(), spec.target())); // ELIYA179: any phrasing
        // 3) Named modules/services each need a step (or an inventory step that names them).
        for (Pattern listPattern : List.of(MODULE_LIST, MODULE_LIST_BEFORE)) {
            Matcher modules = listPattern.matcher(task);
            while (modules.find()) {
                for (String raw : modules.group(1).split("\\s*(?:,|\\band\\b|&)\\s*")) {
                    String name = raw.replaceAll("[`'\"]", "").replaceFirst("(?i)^(?:the|all|both|our|my)\\s+", "").strip();
                    if (name.length() < 2 || name.contains(" ") || FILLER_MODULES.contains(name.toLowerCase(Locale.ROOT))) continue;
                    out.add(new Requirement("module", name, List.of(name), 1));
                }
            }
        }
        // 4) Named files, paths and requested output files.
        Set<String> seen = new LinkedHashSet<>();
        Matcher files = FILE_OR_PATH.matcher(task);
        while (files.find()) {
            String file = files.group().replace('\\', '/');
            if (!seen.add(file.toLowerCase(Locale.ROOT))) continue;
            String base = file.contains("/") ? file.substring(file.lastIndexOf('/') + 1) : file;
            out.add(new Requirement("file", file, List.of(base), 1));
        }
        return dedupe(out);
    }

    /** Requirements that no step covers. */
    static List<Requirement> uncovered(String task, List<String> steps) {
        String plan = String.join("\n", steps == null ? List.of() : steps).toLowerCase(Locale.ROOT);
        List<Requirement> missing = new ArrayList<>();
        for (Requirement requirement : extract(task)) if (!covered(requirement, plan)) missing.add(requirement);
        return missing;
    }

    /** Short description for the planner's corrective round; blank when everything is covered. */
    static String gapSummary(String task, List<String> steps) {
        List<Requirement> missing = uncovered(task, steps);
        if (missing.isEmpty()) return "";
        List<String> items = new ArrayList<>();
        for (Requirement requirement : missing.subList(0, Math.min(8, missing.size())))
            items.add(requirement.kind() + " \"" + clip(requirement.text(), 90) + "\"");
        return "The plan does not cover these requirements from the request: " + String.join("; ", items) +
                (missing.size() > 8 ? " (+" + (missing.size() - 8) + " more)" : "");
    }

    /**
     * Keep every requirement visible: append any still-uncovered requirements, quoted from the request, to the final
     * step as a checklist. No new step is created.
     */
    static List<String> attachChecklist(String task, List<String> steps) {
        if (steps == null || steps.isEmpty()) return steps;
        List<Requirement> missing = uncovered(task, steps);
        if (missing.isEmpty()) return steps;
        StringBuilder checklist = new StringBuilder("\nRequirement checklist from the request (each must be done or explicitly reported):");
        for (Requirement requirement : missing.subList(0, Math.min(20, missing.size())))
            checklist.append("\n- ").append(requirement.kind()).append(": ").append(clip(requirement.text(), 200));
        List<String> out = new ArrayList<>(steps);
        int last = out.size() - 1;
        out.set(last, out.get(last) + checklist);
        return List.copyOf(out);
    }

    private static boolean covered(Requirement requirement, String plan) {
        int hits = 0;
        for (String term : requirement.evidenceTerms()) {
            String t = term.toLowerCase(Locale.ROOT);
            if (t.length() >= 3 && plan.contains(t)) hits++;
            else if (t.length() > 5 && plan.contains(t.substring(0, t.length() - 2))) hits++; // migrate/migration, test/tests
        }
        // A generic "each module" step does not count: every named module must be visible so it is verified by name.
        return hits >= requirement.minimumMatches();
    }

    private static void addMigration(List<Requirement> out, String source, String target) {
        String from = trimArticle(source);
        String to = trimArticle(target);
        if (!from.isBlank()) out.add(new Requirement("migration source", from, keyWords(from, 3), 1));
        if (!to.isBlank()) out.add(new Requirement("migration target", to, keyWords(to, 3), 1));
    }

    private static String trimArticle(String value) {
        return value == null ? "" : value.replaceFirst("(?i)^(?:the|a|an)\\s+", "").replaceAll("[.,;:]+$", "").strip();
    }

    static List<String> keyWords(String text, int max) {
        List<String> words = new ArrayList<>();
        Matcher matcher = WORD.matcher(text.toLowerCase(Locale.ROOT));
        while (matcher.find() && words.size() < max) {
            String word = matcher.group();
            if (!STOP.contains(word) && !words.contains(word)) words.add(word);
        }
        return words;
    }

    private static List<Requirement> dedupe(List<Requirement> requirements) {
        List<Requirement> out = new ArrayList<>();
        Set<String> keys = new LinkedHashSet<>();
        for (Requirement requirement : requirements)
            if (keys.add(requirement.kind() + "|" + requirement.text().toLowerCase(Locale.ROOT))) out.add(requirement);
        return out;
    }

    private static String clip(String value, int max) {
        String text = value == null ? "" : value.replaceAll("\\s+", " ").strip();
        return text.length() <= max ? text : text.substring(0, max - 1) + "…";
    }
}
