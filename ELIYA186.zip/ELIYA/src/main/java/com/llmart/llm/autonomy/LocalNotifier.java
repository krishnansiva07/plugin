package com.llmart.llm.autonomy;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.time.Instant;
import java.util.List;
import java.util.Locale;

/**
 * Best-effort desktop notification on the machine running the JAR (Windows balloon tip, macOS
 * Notification Center, Linux notify-send), plus an append-only notifications log. Never throws.
 * Disable desktop popups with {@code -Deliya.autonomous.desktopNotifications=false}.
 */
public final class LocalNotifier {
    private final Path logFile;

    public LocalNotifier(Path logFile) {
        this.logFile = logFile;
    }

    public void notify(String title, String body) {
        log(title, body);
        if ("false".equalsIgnoreCase(System.getProperty("eliya.autonomous.desktopNotifications", "true"))) return;
        try {
            List<String> command = command(System.getProperty("os.name", ""), clip(title, 60), clip(body, 220));
            if (command.isEmpty()) return;
            Process process = new ProcessBuilder(command).redirectErrorStream(true)
                    .redirectOutput(ProcessBuilder.Redirect.DISCARD).start();
            process.getOutputStream().close(); // fire and forget; the Windows script exits by itself
        } catch (Exception ignored) {
            // Notifications are a convenience; the report file is the record of truth.
        }
    }

    static List<String> command(String osName, String title, String body) {
        String os = osName.toLowerCase(Locale.ROOT);
        if (os.contains("win")) {
            String script = "Add-Type -AssemblyName System.Windows.Forms; Add-Type -AssemblyName System.Drawing; " +
                    "$n = New-Object System.Windows.Forms.NotifyIcon; $n.Icon = [System.Drawing.SystemIcons]::Information; " +
                    "$n.Visible = $true; $n.ShowBalloonTip(10000, " + psQuote(title) + ", " + psQuote(body) + ", 'Info'); " +
                    "Start-Sleep -Seconds 11; $n.Dispose()";
            return List.of("powershell.exe", "-NoProfile", "-NonInteractive", "-WindowStyle", "Hidden", "-Command", script);
        }
        if (os.contains("mac")) {
            return List.of("osascript", "-e", "display notification " + appleQuote(body) + " with title " + appleQuote(title));
        }
        if (Files.isExecutable(Path.of("/usr/bin/notify-send"))) return List.of("/usr/bin/notify-send", title, body);
        return List.of();
    }

    private void log(String title, String body) {
        if (logFile == null) return;
        try {
            Files.createDirectories(logFile.getParent());
            Files.writeString(logFile, Instant.now() + "  " + title + " — " + body.replaceAll("\\s+", " ") + System.lineSeparator(),
                    StandardCharsets.UTF_8, StandardOpenOption.CREATE, StandardOpenOption.APPEND);
        } catch (Exception ignored) { }
    }

    static String psQuote(String value) { return "'" + value.replace("'", "''") + "'"; }

    static String appleQuote(String value) { return "\"" + value.replace("\\", "\\\\").replace("\"", "\\\"") + "\""; }

    private static String clip(String value, int max) {
        String clean = value == null ? "" : value.replaceAll("[\\r\\n\\t]+", " ").strip();
        return clean.length() <= max ? clean : clean.substring(0, max - 1) + "…";
    }
}
