package com.llmart.llm.cli.tui;

import java.io.BufferedReader;
import java.io.FileDescriptor;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PipedInputStream;
import java.io.PipedOutputStream;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.util.Base64;
import java.util.HexFormat;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

/**
 * Windows console terminal for the full-screen chat (preview). Java cannot switch a Windows console to raw input
 * without native code, so a small PowerShell helper reads keys ({@code [Console]::ReadKey}) and sends them over a
 * loopback socket with a one-time token. Output goes straight to the console as VT sequences.
 */
final class WindowsTuiTerminal extends TuiTerminal {
    private final Process helper;
    private final Socket socket;
    private final PipedInputStream keys;
    private final OutputStream output = new FileOutputStream(FileDescriptor.out);
    private volatile int rows, cols;
    private volatile boolean closed;

    private WindowsTuiTerminal(Process helper, Socket socket, PipedInputStream keys, int rows, int cols) {
        this.helper = helper; this.socket = socket; this.keys = keys; this.rows = rows; this.cols = cols;
    }

    static String script(int port, String token) throws IOException {
        try (InputStream in = WindowsTuiTerminal.class.getResourceAsStream("/eliya-tui/windows-keys.ps1")) {
            if (in == null) throw new IOException("windows-keys.ps1 missing from the JAR");
            String text = new String(in.readAllBytes(), StandardCharsets.UTF_8);
            return text.replace("__PORT__", Integer.toString(port)).replace("__TOKEN__", token);
        }
    }

    /** {@code -EncodedCommand} takes Base64 of UTF-16LE and is not subject to script-file execution policy. */
    static String encoded(String script) {
        return Base64.getEncoder().encodeToString(script.getBytes(StandardCharsets.UTF_16LE));
    }

    /** Parse "H vt rows cols" (handshake) / "S rows cols" (resize); returns {vt, rows, cols} or null. */
    static int[] parseSize(String line) {
        String[] parts = line.strip().split("\\s+");
        try {
            if (parts.length == 4 && parts[0].equals("H"))
                return new int[]{Integer.parseInt(parts[1]), Integer.parseInt(parts[2]), Integer.parseInt(parts[3])};
            if (parts.length == 3 && parts[0].equals("S"))
                return new int[]{1, Integer.parseInt(parts[1]), Integer.parseInt(parts[2])};
        } catch (NumberFormatException invalid) { return null; }
        return null;
    }

    static WindowsTuiTerminal create() {
        if (!System.getProperty("os.name", "").toLowerCase(Locale.ROOT).contains("win")) return null;
        Process process = null;
        try (ServerSocket server = new ServerSocket(0, 1, InetAddress.getLoopbackAddress())) {
            byte[] secret = new byte[16];
            new SecureRandom().nextBytes(secret);
            String token = HexFormat.of().formatHex(secret);
            server.setSoTimeout(15_000);
            process = new ProcessBuilder("powershell.exe", "-NoLogo", "-NoProfile", "-ExecutionPolicy", "Bypass",
                    "-EncodedCommand", encoded(script(server.getLocalPort(), token))).inheritIO().start();
            Socket socket = server.accept();
            socket.setSoTimeout(15_000);
            BufferedReader reader = new BufferedReader(new InputStreamReader(socket.getInputStream(), StandardCharsets.UTF_8));
            if (!token.equals(reader.readLine())) { socket.close(); process.destroy(); return null; }
            int[] hello = parseSize(String.valueOf(reader.readLine()));
            if (hello == null || hello[0] != 1) { socket.close(); process.destroy(); return null; } // console cannot show VT
            socket.setSoTimeout(0);
            PipedInputStream keys = new PipedInputStream(1 << 16);
            PipedOutputStream sink = new PipedOutputStream(keys);
            WindowsTuiTerminal terminal = new WindowsTuiTerminal(process, socket, keys, hello[1], hello[2]);
            Thread pump = new Thread(() -> terminal.pump(reader, sink), "eliya-windows-keys");
            pump.setDaemon(true);
            pump.start();
            return terminal;
        } catch (Exception unavailable) {
            if (process != null) process.destroyForcibly();
            return null;
        }
    }

    private void pump(BufferedReader reader, PipedOutputStream sink) {
        try (sink) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.startsWith("K ")) {
                    sink.write(Base64.getDecoder().decode(line.substring(2).strip()));
                    sink.flush();
                } else {
                    int[] size = parseSize(line);
                    if (size != null && size[1] > 0 && size[2] > 0) { rows = size[1]; cols = size[2]; }
                }
            }
        } catch (Exception ended) { /* helper closed */ }
    }

    @Override public void enter() throws IOException {
        write("\u001b[?1049h\u001b[H\u001b[2J");
        flush();
    }

    @Override public int[] size() { return new int[]{Math.max(5, rows), Math.max(20, cols)}; }

    @Override public InputStream input() { return keys; }

    @Override public synchronized void write(String text) throws IOException { output.write(text.getBytes(StandardCharsets.UTF_8)); }

    @Override public synchronized void flush() throws IOException { output.flush(); }

    @Override public synchronized void close() {
        if (closed) return;
        closed = true;
        try { write("\u001b[0m\u001b[?25h\u001b[?1049l"); flush(); } catch (IOException ignored) { }
        try { socket.close(); } catch (IOException ignored) { }   // the helper restores the console and exits
        try { if (!helper.waitFor(3, TimeUnit.SECONDS)) helper.destroyForcibly(); }
        catch (InterruptedException interrupted) { helper.destroyForcibly(); Thread.currentThread().interrupt(); }
        try { keys.close(); } catch (IOException ignored) { }
    }
}
