package com.llmart.llm.autonomy;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * Isolates an unattended run in its own git worktree and branch, so the user's working copy is never touched.
 * After the run, changes are committed on the branch for review/merge and the worktree folder is removed
 * (the branch stays in the user's repository).
 */
public final class GitWorktreeManager {
    /** An active isolated checkout. */
    public record Worktree(Path repositoryRoot, Path path, String branch, String baseCommit, boolean baseWasDirty) { }

    /** Result of finishing a worktree. */
    public record Outcome(boolean committed, String commit, String diffStat, List<String> changedFiles) { }

    private final Path worktreesDirectory;

    public GitWorktreeManager(Path worktreesDirectory) {
        this.worktreesDirectory = worktreesDirectory;
    }

    /** True when {@code folder} is inside a git work tree and git is installed. */
    public static boolean isGitRepository(Path folder) {
        try {
            return "true".equals(git(folder, 15, "rev-parse", "--is-inside-work-tree").output().strip());
        } catch (Exception notGit) {
            return false;
        }
    }

    public Worktree create(Path workspace, String runId, String label) throws IOException {
        Path repo = Path.of(git(workspace, 15, "rev-parse", "--show-toplevel").require().strip());
        String base = git(repo, 15, "rev-parse", "HEAD").require().strip();
        boolean dirty = !git(repo, 30, "status", "--porcelain").require().isBlank();
        String stamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd-HHmm"));
        String branch = "eliya/auto-" + stamp + "-" + slug(label, 24) + "-" + runId.substring(0, Math.min(6, runId.length()));
        Files.createDirectories(worktreesDirectory);
        Path path = worktreesDirectory.resolve(repo.getFileName() + "-" + runId).toAbsolutePath().normalize();
        git(repo, 120, "worktree", "add", "-b", branch, path.toString(), base).require();
        // Map a sub-folder workspace onto the same sub-folder inside the worktree.
        Path relative = repo.toRealPath().relativize(workspace.toAbsolutePath().normalize().toRealPath());
        Path mapped = relative.toString().isEmpty() ? path : path.resolve(relative.toString());
        return new Worktree(repo, mapped, branch, base, dirty);
    }

    /** Commit everything on the run branch and remove the worktree folder (unless {@code keepFolder}). */
    public Outcome finish(Worktree worktree, String message, boolean keepFolder) throws IOException {
        Path top = Path.of(git(worktree.path(), 15, "rev-parse", "--show-toplevel").require().strip());
        git(top, 120, "add", "-A").require();
        boolean hasChanges = !git(top, 30, "diff", "--cached", "--name-only").require().isBlank();
        String commit = "";
        if (hasChanges) {
            git(top, 120, "-c", "user.name=ELIYA", "-c", "user.email=eliya@localhost",
                    "commit", "--no-verify", "-q", "-m", message).require();
            commit = git(top, 15, "rev-parse", "HEAD").require().strip();
        }
        String stat = hasChanges ? git(top, 60, "diff", "--stat", worktree.baseCommit(), "HEAD").require().strip() : "";
        List<String> files = new ArrayList<>();
        if (hasChanges) {
            for (String line : git(top, 60, "diff", "--name-only", worktree.baseCommit(), "HEAD").require().split("\\R")) {
                if (!line.isBlank()) files.add(line.strip());
            }
        }
        if (!keepFolder) {
            git(worktree.repositoryRoot(), 120, "worktree", "remove", "--force", top.toString());
            if (!hasChanges) git(worktree.repositoryRoot(), 30, "branch", "-D", worktree.branch()); // nothing to review
        }
        return new Outcome(hasChanges, commit, stat, List.copyOf(files));
    }

    static String slug(String text, int max) {
        String value = text == null ? "" : text.toLowerCase(java.util.Locale.ROOT).replaceAll("[^a-z0-9]+", "-").replaceAll("^-+|-+$", "");
        if (value.isEmpty()) value = "task";
        return value.length() <= max ? value : value.substring(0, max).replaceAll("-+$", "");
    }

    record Result(int exit, String output) {
        String require() throws IOException {
            if (exit != 0) throw new IOException("git failed (exit " + exit + "): " + output.strip());
            return output;
        }
    }

    static Result git(Path directory, int timeoutSeconds, String... args) throws IOException {
        List<String> command = new ArrayList<>();
        command.add("git");
        command.addAll(List.of(args));
        // Output goes to a temp file so the timeout applies even if git produces a lot of output.
        Path out = Files.createTempFile("eliya-git-", ".out");
        try {
            ProcessBuilder builder = new ProcessBuilder(command).directory(directory.toFile())
                    .redirectErrorStream(true).redirectOutput(out.toFile());
            builder.environment().put("GIT_TERMINAL_PROMPT", "0"); // never block on credential prompts
            Process process = builder.start();
            process.getOutputStream().close();
            if (!process.waitFor(timeoutSeconds, TimeUnit.SECONDS)) {
                process.destroyForcibly();
                throw new IOException("git " + String.join(" ", args) + " timed out after " + timeoutSeconds + "s");
            }
            return new Result(process.exitValue(), Files.readString(out, StandardCharsets.UTF_8));
        } catch (InterruptedException interrupted) {
            Thread.currentThread().interrupt();
            throw new IOException("git interrupted", interrupted);
        } finally {
            Files.deleteIfExists(out);
        }
    }
}
