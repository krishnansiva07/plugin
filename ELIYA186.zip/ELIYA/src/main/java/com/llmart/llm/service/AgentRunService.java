package com.llmart.llm.service;

import org.springframework.stereotype.Service;

import java.time.Instant;
import java.nio.file.*;
import java.nio.charset.StandardCharsets;
import java.io.*;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Consumer;
import java.util.function.BiConsumer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.time.Duration;

@Service
public class AgentRunService {
    private static final int MAX_RETAINED_RUNS = 1000;
    private static final int MAX_ACTIVITY_EVENTS_IN_MEMORY = 20_000;
    private static final int ACTIVITY_EVENTS_IN_SNAPSHOT = 500;
    private final Map<String, AgentRun> runs = new ConcurrentHashMap<>();
    // A deleted run may still be unwinding on a worker thread. Tombstoning its id prevents that stale worker
    // from recreating history files after the user explicitly cleared history.
    private final Set<String> suppressedRunIds = ConcurrentHashMap.newKeySet();
    private final Path storeDir;
    private final Object activityJournalLock = new Object();

    public AgentRunService() {
        this(Path.of(System.getProperty("advanced.ai.agentRunStore", "./data/agent-runs")));
    }

    /** Directory holding persisted runs (used by durable recovery staging). */
    Path storeDirectory() { return storeDir; }

    /** ELIYA180: why the last snapshot of this run could not be saved (empty when it was saved). */
    public String persistenceFailure(String runId) { return runId == null ? "" : persistenceFailures.getOrDefault(runId, ""); }

    private final Map<String, String> persistenceFailures = new java.util.concurrent.ConcurrentHashMap<>();

    AgentRunService(Path storeDir) {
        this.storeDir = storeDir.toAbsolutePath().normalize();
        try { Files.createDirectories(this.storeDir); } catch (Exception ignored) { }
        loadPersistedRuns();
    }

    /** A fresh direct submission must never inherit a different interrupted task's ledger.
     * Resumption is explicit: the caller must identify the intent to resume first.
     */
    public AgentRun start(String conversationId, String projectId) {
        return start(conversationId, projectId, false);
    }

    public AgentRun start(String conversationId, String projectId, boolean resumeInterrupted) {
        prune();
        AgentRun prior = resumeInterrupted ? runs.values().stream()
                .filter(candidate -> Objects.equals(conversationId, candidate.conversationId()))
                .filter(candidate -> Objects.equals(projectId, candidate.projectId()))
                .filter(candidate -> "interrupted".equals(candidate.status))
                .max(Comparator.comparing(AgentRun::createdAt))
                .orElse(null) : null;
        AgentRun run = new AgentRun(UUID.randomUUID().toString(), conversationId, projectId, Instant.now(),
                this::persistQuietly, this::appendActivityQuietly);
        if (prior != null) run.inheritLargeTaskStateFrom(prior);
        runs.put(run.id(), run);
        persistQuietly(run);
        return run;
    }

    /** User-visible, evidence-only candidates; no unapproved memories are persisted. */
    public List<AgentRun> verifiedCandidates(String projectId) {
        if (projectId == null || projectId.isBlank()) return List.of();
        return runs.values().stream()
                .filter(run -> projectId.equals(run.projectId()))
                .filter(run -> "completed".equals(run.status()) && run.mutationRevision() > 0)
                .filter(run -> run.verificationAttemptCount() > 0 && run.lastVerificationSuccessful()
                        && run.verifiedCurrentRevision() && !run.hasVerificationFailures())
                .sorted(Comparator.comparing(AgentRun::createdAt).reversed())
                .limit(30).toList();
    }

    public AgentRun require(String id) {
        AgentRun run = runs.get(id);
        if (run == null) throw new NoSuchElementException("Agent run not found");
        return run;
    }

    public boolean cancel(String id) {
        AgentRun run = runs.get(id);
        return run != null && run.cancel();
    }

    public Map<String, Object> status(String id) {
        return require(id).snapshot();
    }

    /** Remove durable agent-run history for a deleted conversation without touching user workspace files. */
    public int deleteForConversation(String conversationId) {
        if (conversationId == null || conversationId.isBlank()) return 0;
        List<String> ids = runs.values().stream()
                .filter(run -> conversationId.equals(run.conversationId()))
                .map(AgentRun::id)
                .toList();
        ids.forEach(this::deleteRunHistory);
        return ids.size();
    }

    /** Clear every retained Agent run, including orphaned on-disk history from previously deleted chats. */
    public int clearHistory() {
        LinkedHashSet<String> ids = new LinkedHashSet<>(runs.keySet());
        if (Files.isDirectory(storeDir)) {
            try (var stream = Files.list(storeDir)) {
                stream.map(path -> path.getFileName().toString())
                        .map(AgentRunService::historyRunId)
                        .filter(Objects::nonNull)
                        .forEach(ids::add);
            } catch (Exception ignored) { }
        }
        ids.forEach(this::deleteRunHistory);
        return ids.size();
    }

    private void deleteRunHistory(String id) {
        if (id == null || id.isBlank()) return;
        suppressedRunIds.add(id);
        AgentRun run = runs.remove(id);
        if (run != null && !run.finished()) run.cancel();
        try { Files.deleteIfExists(storeDir.resolve(id + ".properties")); } catch (Exception ignored) { }
        try { Files.deleteIfExists(storeDir.resolve(id + ".properties.tmp")); } catch (Exception ignored) { }
        try { Files.deleteIfExists(storeDir.resolve(id + ".events")); } catch (Exception ignored) { }
        // Clear recovery data along with deleted execution history, outside user workspaces.
        try { new ProtectedRunSnapshotService().discard(id); } catch (Exception ignored) { }
    }

    private static String historyRunId(String fileName) {
        if (fileName == null) return null;
        for (String suffix : List.of(".properties.tmp", ".properties", ".events")) {
            if (fileName.endsWith(suffix) && fileName.length() > suffix.length()) {
                return fileName.substring(0, fileName.length() - suffix.length());
            }
        }
        return null;
    }

    /** Latest durable agent-run snapshot for restoring plan/progress after reopening chat history. */
    /** ELIYA184: the newest run of a conversation (live object, for resume-after-stop and the terminal). */
    public Optional<AgentRun> latestRun(String conversationId) {
        if (conversationId == null || conversationId.isBlank()) return Optional.empty();
        return runs.values().stream()
                .filter(run -> conversationId.equals(run.conversationId()))
                .max(Comparator.comparing(AgentRun::createdAt));
    }

    /** ELIYA184: look a run up without throwing (stale terminal locks, status checks). */
    public Optional<AgentRun> find(String id) {
        return id == null || id.isBlank() ? Optional.empty() : Optional.ofNullable(runs.get(id));
    }

    public Optional<Map<String, Object>> latestForConversation(String conversationId) {
        if (conversationId == null || conversationId.isBlank()) return Optional.empty();
        return runs.values().stream()
                .filter(run -> conversationId.equals(run.conversationId()))
                .max(Comparator.comparing(AgentRun::createdAt))
                .map(AgentRun::snapshot);
    }

    /** Durable agent-run snapshots for every retained Agent response in a conversation. */
    public List<Map<String, Object>> forConversation(String conversationId) {
        if (conversationId == null || conversationId.isBlank()) return List.of();
        return runs.values().stream()
                .filter(run -> conversationId.equals(run.conversationId()))
                .sorted(Comparator.comparing(AgentRun::createdAt))
                .map(AgentRun::snapshot)
                .toList();
    }

    /** Lightweight, read-only index of Legacy execution runs for comparison with OpenCode.
     * Only usage, status and timing metadata are returned (no prompts beyond objective).
     */
    public List<Map<String,Object>> recentExecutionUsage(int limit) {
        int count=Math.max(1,Math.min(limit,100));
        return runs.values().stream()
                .filter(AgentRun::finished)
                .sorted(Comparator.comparing(AgentRun::createdAt).reversed())
                .limit(count)
                .map(run -> {
                    Map<String,Object> snapshot=run.snapshot();
                    Map<String,Object> result=new LinkedHashMap<>();
                    for(String key:List.of("id","projectId","conversationId","createdAt","finishedAt","status","tokenUsage"))
                        if(snapshot.containsKey(key))result.put(key,snapshot.get(key));
                    result.put("engine","legacy");
                    result.put("prompt",String.valueOf(snapshot.getOrDefault("objective","")));
                    result.put("model",String.valueOf(snapshot.getOrDefault("activeModel","")));
                    return result;
                }).toList();
    }

    /** Lightweight live Agent status: polled regardless of whether Terminal UI is open. */
    public List<Map<String,Object>> activeExecutionRuns() {
        return runs.values().stream()
                .filter(run -> !run.finished() && ("running".equals(run.status()) ||
                        "queued".equals(run.status()) || "cancelling".equals(run.status())))
                .sorted(Comparator.comparing(AgentRun::createdAt).reversed())
                .limit(100)
                .map(run -> {
                    Map<String,Object> result = new LinkedHashMap<>();
                    result.put("id", run.id());
                    result.put("conversationId", run.conversationId());
                    result.put("projectId", run.projectId());
                    result.put("engine", "agent");
                    result.put("status", run.status());
                    result.put("prompt", run.objective == null ? "Agent execution" : run.objective);
                    result.put("createdAt", run.createdAt().toString());
                    result.put("progressPercent", run.progressPercent());
                    result.put("progressPhase", run.progressPhase());
                    result.put("lastActivityAt", run.lastActivityAt().toString());
                    result.put("observedActions", run.totalToolActions());
                    return result;
                }).toList();
    }

    private void prune() {
        if (runs.size() < MAX_RETAINED_RUNS) return;
        runs.values().stream()
                .filter(AgentRun::finished)
                .sorted(Comparator.comparing(AgentRun::createdAt))
                .limit(Math.max(1, runs.size() - MAX_RETAINED_RUNS + 20L))
                .map(AgentRun::id)
                .toList()
                .forEach(id -> {
                    runs.remove(id);
                    try { Files.deleteIfExists(storeDir.resolve(id + ".properties")); } catch (Exception ignored) { }
                    try { Files.deleteIfExists(storeDir.resolve(id + ".events")); } catch (Exception ignored) { }
                });
    }

    private void persistQuietly(AgentRun run) {
        if (run == null || suppressedRunIds.contains(run.id())) return;
        // Parallel subagents can report token usage for the same parent run. Serialize that run's
        // snapshot and atomic rename so concurrent writers cannot corrupt the shared temporary file.
        synchronized (run) {
            if (suppressedRunIds.contains(run.id())) return;
            try {
                Files.createDirectories(storeDir);
                Properties p = run.toProperties();
                Path tmp = storeDir.resolve(run.id() + ".properties.tmp");
                Path target = storeDir.resolve(run.id() + ".properties");
                try (OutputStream out = Files.newOutputStream(tmp, StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING)) {
                    p.store(out, "ELIYA agent run");
                }
                try { Files.move(tmp, target, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
                catch (AtomicMoveNotSupportedException e) { Files.move(tmp, target, StandardCopyOption.REPLACE_EXISTING); }
                persistenceFailures.remove(run.id());
            } catch (Exception failed) {
                // ELIYA180: never silent — the run reports that it cannot be recovered after a restart.
                String reason = failed.getClass().getSimpleName() + ": " + failed.getMessage();
                if (persistenceFailures.put(run.id(), reason) == null)
                    System.err.println("ELIYA: could not save agent run " + run.id() + " to " + storeDir + " (" + reason + ")");
            }
        }
    }

    /**
     * Activity is append-journaled independently from the coalesced run snapshot. A JVM crash, provider failure,
     * broken SSE connection, or forced application close can therefore preserve every completed activity event.
     */
    private void appendActivityQuietly(String runId, AgentRun.ActivityEvent event) {
        if (runId == null || runId.isBlank() || event == null || suppressedRunIds.contains(runId)) return;
        try {
            Files.createDirectories(storeDir);
            Path journal = storeDir.resolve(runId + ".events");
            String encoded = AgentRun.encodeActivity(event) + System.lineSeparator();
            synchronized (activityJournalLock) {
                Files.writeString(journal, encoded, StandardCharsets.UTF_8,
                        StandardOpenOption.CREATE, StandardOpenOption.WRITE, StandardOpenOption.APPEND);
            }
        } catch (Exception ignored) { }
    }

    private void restoreActivityJournal(AgentRun run) {
        if (run == null) return;
        Path journal = storeDir.resolve(run.id() + ".events");
        if (!Files.isRegularFile(journal)) return;
        ArrayDeque<AgentRun.ActivityEvent> restored = new ArrayDeque<>();
        try (BufferedReader reader = Files.newBufferedReader(journal, StandardCharsets.UTF_8)) {
            String line;
            while ((line = reader.readLine()) != null) {
                AgentRun.ActivityEvent event = AgentRun.decodeActivity(line.trim());
                if (event == null) continue;
                restored.addLast(event);
                while (restored.size() > MAX_ACTIVITY_EVENTS_IN_MEMORY) restored.removeFirst();
            }
        } catch (Exception ignored) { return; }
        if (restored.isEmpty()) return;
        synchronized (run) {
            run.activityEvents.clear();
            run.activityEvents.addAll(restored);
            AgentRun.ActivityEvent last = run.activityEvents.peekLast();
            if (last != null && (run.lastActivityAt == null || last.at().isAfter(run.lastActivityAt))) {
                run.lastActivityAt = last.at();
            }
        }
    }

    private void loadPersistedRuns() {
        if (!Files.isDirectory(storeDir)) return;
        try (var stream = Files.list(storeDir)) {
            stream.filter(p -> p.getFileName().toString().endsWith(".properties")).sorted().forEach(path -> {
                try (InputStream in = Files.newInputStream(path)) {
                    Properties props = new Properties(); props.load(in);
                    AgentRun run = AgentRun.fromProperties(props, this::persistQuietly, this::appendActivityQuietly);
                    if (run != null) {
                        restoreActivityJournal(run);
                        // A JVM restart cannot safely resume an in-flight tool call. Preserve the run and mark it
                        // interrupted so the UI/user can see exactly where it stopped instead of losing the state.
                        if (!run.finished()) {
                            // The JVM no longer owns ANY in-flight worker after a restart.
                            // Queued/cancelling/input-wait states must not remain active forever.
                            // Terminal statuses without a finishedAt are finalized, never replayed.
                            if (Set.of("completed", "cancelled", "failed", "blocked", "stalled")
                                    .contains(run.status())) {
                                run.finishedAt = Instant.now();
                                run.persist();
                            } else {
                                run.markInterruptedByRestart();
                            }
                        }
                        runs.put(run.id(), run);
                    }
                } catch (Exception ignored) { }
            });
        } catch (Exception ignored) { }
        prune();
    }

    public static final class AgentRun {
        private final String id;
        private final String conversationId;
        private volatile String projectId;
        private final Instant createdAt;
        private final AtomicBoolean cancelled = new AtomicBoolean(false);
        private final AtomicReference<Process> activeProcess = new AtomicReference<>();
        // The worker may be blocked waiting for a provider's first token or a filesystem call.
        // Track the owning worker so Stop can interrupt that wait, not merely set a flag.
        private final AtomicReference<Thread> activeWorker = new AtomicReference<>();
        private final AtomicLong mutationRevision = new AtomicLong(0);
        private final AtomicLong lastVerificationAttemptRevision = new AtomicLong(-1);
        // Monotonic count: repeated successful checks on the same unmodified revision are still NEW evidence.
        private final AtomicLong verificationAttemptCount = new AtomicLong(0);
        private final AtomicLong verificationRequiredRevision = new AtomicLong(-1);
        private final AtomicLong lastSuccessfulVerificationRevision = new AtomicLong(-1);
        private final AtomicLong lastDiffRevision = new AtomicLong(-1);
        private final AtomicBoolean lastVerificationSuccessful = new AtomicBoolean(false);
        private final AtomicLong modelCalls = new AtomicLong(0);
        private final TokenActivityLedger tokenActivity = new TokenActivityLedger();
        private final AtomicLong providerInputTokens = new AtomicLong(0);
        private final AtomicLong providerOutputTokens = new AtomicLong(0);
        private final AtomicLong providerTotalTokens = new AtomicLong(0);
        private final AtomicLong cachedInputTokens = new AtomicLong(0);
        private final AtomicLong cacheWriteTokens = new AtomicLong(0);
        private final AtomicLong estimatedInputTokens = new AtomicLong(0);
        private final AtomicLong currentContextTokens = new AtomicLong(0);
        private final AtomicLong contextWindowTokens = new AtomicLong(0);
        private final AtomicLong compactions = new AtomicLong(0);
        private final AtomicLong estimatedTokensSavedByCompaction = new AtomicLong(0);
        private final AtomicLong prunedObservations = new AtomicLong(0);
        private final AtomicLong estimatedTokensSavedByPruning = new AtomicLong(0);
        private final AtomicLong repeatedCallsPrevented = new AtomicLong(0);
        private final AtomicLong totalToolActions = new AtomicLong(0);
        private final AtomicLong lastSoftPersistNanos = new AtomicLong(0);
        private final AtomicLong progressPercent = new AtomicLong(2);
        private final AtomicBoolean responsePersisted = new AtomicBoolean(false);
        private volatile String progressPhase = "starting";
        private volatile String progressDetail = "Preparing agent run";
        private volatile String failureStage = "";
        private volatile String finalAnswer = "";
        private volatile String assistantMessageId = "";
        private volatile String lastCheckpointReason = "";
        private volatile String loopBlockReason = "";
        private volatile String objective = "";
        // Immutable original request survives compaction, model failover and persisted-run recovery.
        private volatile String originalTaskContract = "";
        private final AtomicLong evidenceAssemblyMs = new AtomicLong(0);
        private final AtomicLong evidenceCharacters = new AtomicLong(0);
        private final AtomicLong evidenceFiles = new AtomicLong(0);
        private final AtomicLong evidenceSymbols = new AtomicLong(0);
        private final AtomicLong evidenceCacheHits = new AtomicLong(0);
        private final AtomicLong initialToolSchemas = new AtomicLong(0);
        private final AtomicLong baselineToolSchemas = new AtomicLong(0);
        private final AtomicLong proactiveRetrievalDeferred = new AtomicLong(0);
        private final AtomicLong providerLatencyMs = new AtomicLong(0);
        private final AtomicLong providerTimedCalls = new AtomicLong(0);
        private final AgentStageMetrics stageTimings = new AgentStageMetrics();
        private volatile String contextProfile = "BALANCED";
        private volatile String evidenceReferences = "";
        private volatile String planValidationStatus = "not_run";
        private volatile String planValidationSummary = "";
        private final ArrayDeque<ActivityEvent> activityEvents = new ArrayDeque<>();
        private final LinkedHashSet<String> touchedPaths = new LinkedHashSet<>();
        private final List<PlanItem> plan = new ArrayList<>();
        private final Map<Integer, ArrayDeque<String>> planEvidence = new LinkedHashMap<>();
        private volatile String recoveredFromRunId = "";
        private final List<UserInput> userInputs = new ArrayList<>();
        static final int MAX_PENDING_USER_INPUT = 20;
        static final int MAX_USER_INPUT_CHARS = 8_000;
        // ELIYA184: "stop … show me the results so far" typed while the task runs ends it with a results report.
        private volatile boolean stopWithReport = false;
        private volatile String stopInstruction = "";
        private volatile Instant stopRequestedAt;
        private volatile String stopActiveAction = "";
        // A "skip this step" input kills only the running command; the run itself continues.
        private final AtomicBoolean actionInterruptedByUser = new AtomicBoolean(false);
        static final String USER_SKIP_NOTE = "Skipped at your request";
        private final ArrayDeque<String> failureMemory = new ArrayDeque<>();
        private volatile boolean largeTaskMode = false;
        private volatile int workItemBatchSize = 10;
        private volatile boolean documentationMode = false;
        private volatile boolean documentationCoverageComplete = false;
        private volatile boolean documentationValidated = false;
        private volatile String documentationCoverageSummary = "";
        private volatile String documentationValidationSummary = "";
        private final LinkedHashMap<String, WorkItem> workItems = new LinkedHashMap<>();
        private final ArrayDeque<String> verificationFailureQueue = new ArrayDeque<>();
        private volatile boolean planLocked = false;
        private volatile int activePlanIndex = 0;
        private final AtomicLong planStepToolActivity = new AtomicLong(0);
        private final AtomicLong planStepStartMutationRevision = new AtomicLong(0);
        private final List<String> modelPool = new ArrayList<>();
        private volatile int activeModelIndex = 0;
        private volatile String activeModel = "";
        private final AtomicLong modelFailovers = new AtomicLong(0);
        private final AtomicLong recoveryReplans = new AtomicLong(0);
        private volatile String lastModelError = "";
        private volatile String lastRecoveryAnalysis = "";
        private final Set<String> approvedToolsForRun = ConcurrentHashMap.newKeySet();
        private volatile String status = "running";
        private volatile String lastVerification = "";
        private volatile Instant lastActivityAt;
        private volatile Instant finishedAt;
        private final Consumer<AgentRun> persistHook;
        private final BiConsumer<String, ActivityEvent> activityPersistHook;

        private AgentRun(String id, String conversationId, String projectId, Instant createdAt,
                         Consumer<AgentRun> persistHook, BiConsumer<String, ActivityEvent> activityPersistHook) {
            this.id = id;
            this.conversationId = conversationId;
            this.projectId = projectId;
            this.createdAt = createdAt;
            this.lastActivityAt = createdAt;
            this.persistHook = persistHook == null ? ignored -> { } : persistHook;
            this.activityPersistHook = activityPersistHook == null ? (ignoredId, ignoredEvent) -> { } : activityPersistHook;
        }

        private void persist() { persistHook.accept(this); }

        /** Coalesce non-critical telemetry/activity disk writes; correctness checkpoints still call persist(). */
        private void persistSoft() {
            long now = System.nanoTime();
            long previous = lastSoftPersistNanos.get();
            if (previous != 0 && now - previous < 250_000_000L) return;
            if (lastSoftPersistNanos.compareAndSet(previous, now)) persist();
        }

        public String id() { return id; }
        public String conversationId() { return conversationId; }
        public String projectId() { return projectId; }

        /** Bind an inferred workspace only when the run had no explicitly selected root.
         * Prevent a later callback or prompt from silently changing an already-bound scope.
         */
        public synchronized void bindInferredProject(String resolvedProjectId) {
            if (resolvedProjectId == null || resolvedProjectId.isBlank())
                throw new IllegalArgumentException("Resolved Agent workspace is required");
            if (projectId != null && !projectId.isBlank()) {
                if (!projectId.equals(resolvedProjectId))
                    throw new IllegalStateException("Cannot switch an active Agent run to a different workspace");
                return;
            }
            checkCancelled();
            projectId = resolvedProjectId;
            persist();
        }
        public Instant createdAt() { return createdAt; }
        public boolean cancelled() { return cancelled.get(); }
        public boolean finished() { return finishedAt != null; }
        public long mutationRevision() { return mutationRevision.get(); }
        public long lastVerificationAttemptRevision() { return lastVerificationAttemptRevision.get(); }
        public long verificationAttemptCount() { return verificationAttemptCount.get(); }
        public long verificationRequiredRevision() { return verificationRequiredRevision.get(); }
        public long lastSuccessfulVerificationRevision() { return lastSuccessfulVerificationRevision.get(); }
        public long lastDiffRevision() { return lastDiffRevision.get(); }
        public String lastVerification() { return lastVerification; }
        public boolean lastVerificationSuccessful() { return lastVerificationSuccessful.get(); }
        public long modelCalls() { return modelCalls.get(); }
        public long providerInputTokens() { return providerInputTokens.get(); }
        public long providerOutputTokens() { return providerOutputTokens.get(); }
        public long providerTotalTokens() { return providerTotalTokens.get(); }
        public long cachedInputTokens() { return cachedInputTokens.get(); }
        public long compactions() { return compactions.get(); }
        public long prunedObservations() { return prunedObservations.get(); }
        public long estimatedTokensSavedByPruning() { return estimatedTokensSavedByPruning.get(); }
        public long currentContextTokens() { return currentContextTokens.get(); }
        public long contextWindowTokens() { return contextWindowTokens.get(); }
        public long totalToolActions() { return totalToolActions.get(); }
        public Instant lastActivityAt() { return lastActivityAt == null ? createdAt : lastActivityAt; }
        public int progressPercent() { return (int) progressPercent.get(); }
        public String progressPhase() { return progressPhase == null ? "" : progressPhase; }
        public String progressDetail() { return progressDetail == null ? "" : progressDetail; }
        public boolean responsePersisted() { return responsePersisted.get(); }
        public String status() { return status; }
        public String finalAnswer() { return finalAnswer == null ? "" : finalAnswer; }
        public String assistantMessageId() { return assistantMessageId == null ? "" : assistantMessageId; }
        public synchronized String activeModel() { return activeModel == null ? "" : activeModel; }
        public synchronized List<String> modelPool() { return List.copyOf(modelPool); }
        public long modelFailovers() { return modelFailovers.get(); }
        public long recoveryReplans() { return recoveryReplans.get(); }
        public String lastModelError() { return lastModelError == null ? "" : lastModelError; }
        public String lastRecoveryAnalysis() { return lastRecoveryAnalysis == null ? "" : lastRecoveryAnalysis; }
        public synchronized boolean hasNextModel() { return activeModelIndex + 1 < modelPool.size(); }
        public synchronized int activePlanIndex() { return activePlanIndex; }
        public synchronized boolean planLocked() { return planLocked; }
        public synchronized boolean largeTaskMode() { return largeTaskMode; }
        public synchronized int workItemBatchSize() { return workItemBatchSize; }
        public synchronized boolean documentationMode() { return documentationMode; }
        public synchronized boolean documentationCoverageComplete() { return documentationCoverageComplete; }
        public synchronized boolean documentationValidated() { return documentationValidated; }
        public synchronized String documentationCoverageSummary() { return documentationCoverageSummary == null ? "" : documentationCoverageSummary; }
        public synchronized String documentationValidationSummary() { return documentationValidationSummary == null ? "" : documentationValidationSummary; }
        public long planStepToolActivity() { return planStepToolActivity.get(); }
        public boolean loopBlocked() { return loopBlockReason != null && !loopBlockReason.isBlank(); }
        public String loopBlockReason() { return loopBlockReason == null ? "" : loopBlockReason; }
        public void markLoopBlocked(String reason) { loopBlockReason = reason == null ? "Repeated no-progress loop" : reason; persist(); }
        public boolean isToolApprovedForRun(String tool) { return tool != null && approvedToolsForRun.contains(tool); }
        public void approveToolForRun(String tool) { if (tool != null && !tool.isBlank()) { approvedToolsForRun.add(tool); persist(); } }


        private void touchActivity() { lastActivityAt = Instant.now(); }

        /** Update the visible phase/detail without moving the plan-derived percentage. */
        public void updateActivity(String phase, String detail) {
            if (phase != null && !phase.isBlank()) progressPhase = phase.strip();
            if (detail != null && !detail.isBlank()) progressDetail = detail.strip();
            touchActivity();
            persistSoft();
        }

        public synchronized void setObjective(String value) {
            objective = value == null ? "" : value.strip();
            if (originalTaskContract.isBlank() && !objective.isBlank()) originalTaskContract = objective;
            persist();
        }

        public synchronized String objective() { return objective == null ? "" : objective; }
        public synchronized String originalTaskContract() { return originalTaskContract; }

        public void recordContextEvidence(String profile, int files, int symbols, int chars, long elapsedMs) {
            contextProfile = profile == null ? "BALANCED" : profile;
            evidenceAssemblyMs.addAndGet(Math.max(0, elapsedMs));
            evidenceFiles.addAndGet(Math.max(0, files));
            evidenceSymbols.addAndGet(Math.max(0, symbols));
            evidenceCharacters.addAndGet(Math.max(0, chars));
            persistSoft();
        }
        public void recordEvidenceReferences(List<String> references) {
            // Durable provenance only: never persist prompt bodies or code to the telemetry ledger.
            evidenceReferences = references == null ? "" :
                    references.stream().limit(8).map(ref -> clipDurable(ref, 220))
                            .reduce((a, b) -> a + "\n" + b).orElse("");
            persistSoft();
        }
        public void recordEvidenceCacheHit() { evidenceCacheHits.incrementAndGet(); persistSoft(); }
        public void recordStageDuration(String stage, long elapsedMs) {
            stageTimings.record(stage, elapsedMs);
            persistSoft();
        }

        /** Measured schema count only; smaller palettes cannot guarantee a billed-token saving. */
        public void recordInitialToolPalette(int exposed, int defaultCount) {
            initialToolSchemas.set(Math.max(0, exposed));
            baselineToolSchemas.set(Math.max(0, defaultCount));
            persistSoft();
        }

        /** Number of context preparations that reused live evidence instead of automatic retrieval. */
        public void recordProactiveRetrievalDeferred() {
            proactiveRetrievalDeferred.incrementAndGet();
            persistSoft();
        }

        public void recordProviderLatency(long elapsedMs) {
            providerLatencyMs.addAndGet(Math.max(0, elapsedMs));
            providerTimedCalls.incrementAndGet();
            persistSoft();
        }


        public synchronized void setPlanValidation(String status, String summary) {
            planValidationStatus = status == null || status.isBlank() ? "not_run" : status.strip().toLowerCase(Locale.ROOT);
            planValidationSummary = summary == null ? "" : summary.strip();
            persist();
        }

        public String planValidationStatus() { return planValidationStatus == null ? "not_run" : planValidationStatus; }
        public String planValidationSummary() { return planValidationSummary == null ? "" : planValidationSummary; }

        /** Persist a bounded activity timeline so reopening chat history restores the live agent story, not just final text. */
        public synchronized void recordActivityEvent(Map<String,Object> event) {
            if (event == null || event.isEmpty()) return;
            int step = 0;
            try { step = Integer.parseInt(String.valueOf(event.getOrDefault("step", "0"))); } catch (Exception ignored) { }
            String tool = String.valueOf(event.getOrDefault("tool", "agent"));
            String detail = String.valueOf(event.getOrDefault("detail", ""));
            String statusValue = String.valueOf(event.getOrDefault("status", "running"));
            String args = String.valueOf(event.getOrDefault("args", ""));
            String approvalId = String.valueOf(event.getOrDefault("approvalId", ""));
            if ("null".equalsIgnoreCase(approvalId)) approvalId = "";
            String output = String.valueOf(event.getOrDefault("output", ""));
            String approvalType = String.valueOf(event.getOrDefault("approvalType", ""));
            String approvalExpiresAt = String.valueOf(event.getOrDefault("approvalExpiresAt", ""));
            if (args.length() > 3000) args = args.substring(0, 3000) + " …";
            int outputLimit = "file_deletion".equals(approvalType) ? 12_000 : 1800;
            if (output.length() > outputLimit) output = output.substring(0, outputLimit) + " …";
            ActivityEvent durableEvent = new ActivityEvent(Instant.now(), step, tool, statusValue, detail, args, approvalId,
                    output, approvalType, approvalExpiresAt);
            activityEvents.addLast(durableEvent);
            while (activityEvents.size() > MAX_ACTIVITY_EVENTS_IN_MEMORY) activityEvents.removeFirst();
            syncActivityFromEvent(tool, detail, statusValue);
            // Journal every activity event immediately; the heavier full-state snapshot can remain coalesced.
            activityPersistHook.accept(id, durableEvent);
            persistSoft();
        }

        private void syncActivityFromEvent(String tool, String detail, String statusValue) {
            if (finished()) return;
            String t = tool == null ? "" : tool.toLowerCase(Locale.ROOT);
            String nextPhase;
            if (t.contains("workspace_index") || t.equals("indexing")) nextPhase = "indexing";
            else if (t.contains("recovery_")) nextPhase = "recovering";
            else if (t.contains("plan_validation")) nextPhase = "plan_validation";
            else if (t.contains("plan_analysis") || t.equals("analysis") || t.contains("workspace_resolution")) nextPhase = "analysing";
            else if (t.equals("plan_approval") || "approval".equalsIgnoreCase(statusValue)) nextPhase = "plan_review";
            else if ((t.equals("plan") || t.contains("model_route")) && !planLocked) nextPhase = "planning";
            else if (t.contains("verification") || t.equals("build") || t.equals("test") || t.equals("check")) nextPhase = "verifying";
            else if (t.equals("finish") || t.contains("completion_check")) nextPhase = "finalizing";
            else nextPhase = planLocked ? "executing" : progressPhase;
            if (nextPhase != null && !nextPhase.isBlank()) progressPhase = nextPhase;
            if (detail != null && !detail.isBlank()) progressDetail = detail.strip();
            touchActivity();
        }

        public synchronized List<Map<String,Object>> activitySnapshot() {
            List<Map<String,Object>> out = new ArrayList<>();
            for (ActivityEvent event : activityEvents) {
                Map<String,Object> row = new LinkedHashMap<>();
                row.put("at", event.at().toString());
                row.put("step", event.step());
                row.put("tool", event.tool());
                row.put("status", event.status());
                row.put("detail", event.detail());
                if (!event.args().isBlank()) row.put("args", event.args());
                if (!event.approvalId().isBlank()) row.put("approvalId", event.approvalId());
                if (!event.approvalType().isBlank()) row.put("approvalType", event.approvalType());
                if (!event.approvalExpiresAt().isBlank()) row.put("approvalExpiresAt", event.approvalExpiresAt());
                if (!event.output().isBlank()) row.put("output", event.output());
                out.add(row);
            }
            return List.copyOf(out);
        }

        public synchronized void recordTouchedPaths(Collection<String> paths) {
            if (paths == null) return;
            for (String raw : paths) {
                if (raw == null) continue;
                String path = raw.strip();
                if (path.isBlank()) continue;
                touchedPaths.add(path);
                while (touchedPaths.size() > 200) {
                    Iterator<String> it = touchedPaths.iterator();
                    if (it.hasNext()) { it.next(); it.remove(); } else break;
                }
            }
            persist();
        }

        public synchronized List<String> touchedPaths() { return List.copyOf(touchedPaths); }

        /** Bounded per-step memory of strategies/errors that must not be repeated across executor failovers. */
        public synchronized void recordExecutionFailure(String value) {
            if (value == null) return;
            String line = value.replaceAll("\\s+", " ").strip();
            if (line.isBlank()) return;
            if (line.length() > 700) line = line.substring(0, 700) + " …";
            if (failureMemory.isEmpty() || !failureMemory.peekLast().equals(line)) failureMemory.addLast(line);
            while (failureMemory.size() > 50) failureMemory.removeFirst();
            persistSoft();
        }

        public synchronized String failureMemoryText() {
            if (failureMemory.isEmpty()) return "";
            StringBuilder out = new StringBuilder();
            int i = 1;
            for (String item : failureMemory) out.append(i++).append(". ").append(item).append('\n');
            return out.toString().stripTrailing();
        }

        private synchronized void clearFailureMemory() { failureMemory.clear(); }


        public synchronized void configureLargeTask(boolean enabled, int batchSize) {
            largeTaskMode = enabled;
            if (batchSize > 0) workItemBatchSize = Math.max(3, Math.min(50, batchSize));
            persist();
        }

        public synchronized void configureDocumentationMode(boolean enabled) {
            documentationMode = enabled;
            if (!enabled) {
                documentationCoverageComplete = false;
                documentationValidated = false;
                documentationCoverageSummary = "";
                documentationValidationSummary = "";
            }
            persist();
        }

        public synchronized void updateDocumentationCoverage(boolean complete, String summary) {
            documentationMode = true;
            documentationCoverageComplete = complete;
            documentationCoverageSummary = summary == null ? "" : summary.strip();
            if (!complete) documentationValidated = false;
            progressPhase = "documentation";
            if (!documentationCoverageSummary.isBlank()) progressDetail = documentationCoverageSummary;
            persist();
        }

        public synchronized void updateDocumentationValidation(boolean passed, String summary) {
            documentationMode = true;
            documentationValidated = passed;
            documentationValidationSummary = summary == null ? "" : summary.strip();
            progressPhase = passed ? "documentation_validated" : "documentation";
            if (!documentationValidationSummary.isBlank()) progressDetail = documentationValidationSummary;
            persist();
        }

        public synchronized void initializeWorkItems(List<String> items, int batchSize) {
            configureLargeTask(true, batchSize);
            workItems.clear();
            verificationFailureQueue.clear();
            addWorkItemsInternal(items);
            recalculatePlanProgress();
            progressPhase = "large_task";
            progressDetail = workItemProgressDetail();
            persist();
        }

        public synchronized void addWorkItems(List<String> items) {
            configureLargeTask(true, workItemBatchSize);
            addWorkItemsInternal(items);
            recalculatePlanProgress();
            persist();
        }

        private void addWorkItemsInternal(List<String> items) {
            for (String raw : items == null ? List.<String>of() : items) {
                if (raw == null || raw.isBlank()) continue;
                String value = raw.replaceAll("\\s+", " ").strip();
                if (value.length() > 700) value = value.substring(0, 700);
                String id = stableWorkItemId(value);
                workItems.putIfAbsent(id, new WorkItem(id, value, "pending", "", 0));
            }
        }

        private String stableWorkItemId(String value) {
            String base = value == null ? "item" : value.toLowerCase(Locale.ROOT)
                    .replaceAll("[^a-z0-9]+", "-").replaceAll("(^-+|-+$)", "");
            if (base.length() > 36) base = base.substring(0, 36);
            if (base.isBlank()) base = "item";
            String candidate = base;
            int suffix = 2;
            while (workItems.containsKey(candidate) && !Objects.equals(workItems.get(candidate).title(), value)) {
                candidate = base + "-" + suffix++;
            }
            return candidate;
        }

        public synchronized void updateWorkItems(List<String> ids, String newStatus, String note) {
            String statusValue = normalizeWorkItemStatus(newStatus);
            if (ids == null || ids.isEmpty()) throw new IllegalArgumentException("At least one work-item id is required");
            if ("in_progress".equals(statusValue)) {
                long alreadyActive = workItems.values().stream()
                        .filter(item -> "in_progress".equals(item.status()) && !ids.contains(item.id())).count();
                long requested = ids.stream().distinct().filter(workItems::containsKey).count();
                if (alreadyActive + requested > workItemBatchSize) {
                    throw new IllegalStateException("Large-task batch limit is " + workItemBatchSize +
                            " active work items. Complete/fail the current batch before starting more items.");
                }
            }
            String finalNote = note == null ? "" : note.replaceAll("\\s+", " ").strip();
            if (finalNote.length() > 500) finalNote = finalNote.substring(0, 500);
            for (String id : ids) {
                WorkItem old = workItems.get(id);
                if (old == null) throw new IllegalArgumentException("Unknown work-item id: " + id);
                int attempts = old.attempts() + (Set.of("in_progress", "failed").contains(statusValue) ? 1 : 0);
                workItems.put(id, new WorkItem(old.id(), old.title(), statusValue, finalNote, attempts));
            }
            recalculatePlanProgress();
            progressDetail = workItemProgressDetail();
            persist();
        }

        public synchronized String workItemsText(String statusFilter, int offset, int limit) {
            String filter = statusFilter == null ? "" : statusFilter.strip().toLowerCase(Locale.ROOT);
            int skip = Math.max(0, offset);
            int max = limit <= 0 ? 50 : Math.min(200, limit);
            StringBuilder out = new StringBuilder();
            int matched = 0, emitted = 0;
            for (WorkItem item : workItems.values()) {
                if (!filter.isBlank() && !filter.equals(item.status())) continue;
                if (matched++ < skip) continue;
                if (emitted++ >= max) break;
                out.append(item.id()).append(" [").append(item.status()).append("] ").append(item.title());
                if (!item.note().isBlank()) out.append(" — ").append(item.note());
                out.append('\n');
            }
            if (out.isEmpty()) return "[No matching work items]";
            return workItemProgressDetail() + "\n" + out.toString().stripTrailing();
        }

        public synchronized List<Map<String,Object>> workItemsSnapshot(int maxItems) {
            int max = maxItems <= 0 ? 200 : Math.min(5000, maxItems);
            List<Map<String,Object>> out = new ArrayList<>();
            for (WorkItem item : workItems.values()) {
                if (out.size() >= max) break;
                Map<String,Object> row = new LinkedHashMap<>();
                row.put("id", item.id()); row.put("title", item.title()); row.put("status", item.status());
                row.put("note", item.note()); row.put("attempts", item.attempts());
                out.add(row);
            }
            return List.copyOf(out);
        }

        public synchronized Map<String,Object> workItemSummary() {
            Map<String,Long> counts = new LinkedHashMap<>();
            for (String status : List.of("pending","in_progress","completed","failed","blocked")) counts.put(status, 0L);
            for (WorkItem item : workItems.values()) counts.compute(item.status(), (k,v) -> v == null ? 1L : v + 1L);
            Map<String,Object> summary = new LinkedHashMap<>();
            summary.put("enabled", largeTaskMode);
            summary.put("batchSize", workItemBatchSize);
            summary.put("total", workItems.size());
            summary.putAll(counts);
            summary.put("verificationFailures", verificationFailureQueue.size());
            return summary;
        }

        public synchronized boolean hasUnresolvedWorkItems() {
            return workItems.values().stream().anyMatch(i -> Set.of("pending","in_progress","failed","blocked").contains(i.status()));
        }

        public synchronized void recordVerificationFailures(String result) {
            if (result == null || result.isBlank()) return;
            for (String raw : result.split("\\R")) {
                String line = raw == null ? "" : raw.replaceAll("\\s+", " ").strip();
                String low = line.toLowerCase(Locale.ROOT);
                if (line.length() < 4) continue;
                boolean signal = low.contains("failed") || low.contains("failure") || low.contains("error") ||
                        low.startsWith("fail ") || low.startsWith("fail:") || low.contains(" fail ") ||
                        low.startsWith("✘") || low.startsWith("×") || low.startsWith("x ");
                if (!signal) continue;
                if (line.length() > 500) line = line.substring(0, 500) + " …";
                if (!verificationFailureQueue.contains(line)) verificationFailureQueue.addLast(line);
                while (verificationFailureQueue.size() > 100) verificationFailureQueue.removeFirst();
            }
            persist();
        }

        public synchronized boolean hasVerificationFailures() { return !verificationFailureQueue.isEmpty(); }

        public synchronized void clearVerificationFailures() {
            verificationFailureQueue.clear();
            persist();
        }

        public synchronized String verificationFailureText() {
            if (verificationFailureQueue.isEmpty()) return "[No unresolved verifier failures]";
            Map<String,Integer> groups = new LinkedHashMap<>();
            for (String failure : verificationFailureQueue) groups.merge(failureCategory(failure), 1, Integer::sum);
            StringBuilder out = new StringBuilder("Failure clusters: ");
            out.append(groups.entrySet().stream().map(e -> e.getKey() + "=" + e.getValue()).reduce((a,b) -> a + ", " + b).orElse("none"));
            out.append('\n');
            int i = 1;
            for (String failure : verificationFailureQueue) {
                if (i > 30) { out.append("... ").append(verificationFailureQueue.size() - 30).append(" more"); break; }
                out.append(i++).append(". [").append(failureCategory(failure)).append("] ").append(failure).append('\n');
            }
            return out.toString().stripTrailing();
        }

        private static String failureCategory(String failure) {
            String low = failure == null ? "" : failure.toLowerCase(Locale.ROOT);
            if (low.contains("locator") || low.contains("strict mode") || low.contains("element") || low.contains("selector")) return "locator";
            if (low.contains("fixture") || low.contains("module not found") || low.contains("cannot find module") || low.contains("import")) return "fixture/import";
            if (low.contains("compile") || low.contains("compilation") || low.contains("typescript") || low.contains("type error") || low.contains("cannot find symbol")) return "compile/type";
            if (low.contains("timeout") || low.contains("timed out")) return "timeout";
            if (low.contains("assert") || low.contains("expected") || low.contains("actual")) return "assertion";
            if (low.contains("data") || low.contains("excel") || low.contains("csv") || low.contains("json")) return "test-data";
            return "other";
        }

        private synchronized String workItemProgressDetail() {
            if (workItems.isEmpty()) return largeTaskMode ? "Large-task mode enabled; inventory not initialized" : "";
            long completed = workItems.values().stream().filter(i -> "completed".equals(i.status())).count();
            long failed = workItems.values().stream().filter(i -> "failed".equals(i.status())).count();
            long active = workItems.values().stream().filter(i -> "in_progress".equals(i.status())).count();
            return completed + "/" + workItems.size() + " work items completed" +
                    (active > 0 ? "; " + active + " active" : "") + (failed > 0 ? "; " + failed + " failed" : "");
        }

        private static String normalizeWorkItemStatus(String value) {
            String status = value == null ? "pending" : value.trim().toLowerCase(Locale.ROOT);
            return switch (status) {
                case "pending", "in_progress", "completed", "failed", "blocked" -> status;
                default -> throw new IllegalArgumentException("Unsupported work-item status: " + value);
            };
        }

        public void recordPruning(long observations, long estimatedTokensSaved) {
            prunedObservations.addAndGet(Math.max(0, observations));
            estimatedTokensSavedByPruning.addAndGet(Math.max(0, estimatedTokensSaved));
            persistSoft();
        }

        /** Durable state is stored outside active chat history and re-injected as a small suffix before each call. */
        public synchronized String durableContextText() {
            StringBuilder out = new StringBuilder();
            out.append("DURABLE AGENT STATE — runtime authoritative; do not infer newer state from compacted history.\n");
            if (!originalTaskContract().isBlank()) {
                out.append("originalUserTaskContract (immutable, stored in full outside active context): ")
                        .append(clipDurable(originalTaskContract(), 5_500)).append('\n');
            }
            if (!objective().isBlank() && !objective().equals(originalTaskContract()))
                out.append("currentObjective: ").append(clipDurable(objective(), 1400)).append('\n');
            out.append("activeModel: ").append(activeModel()).append("; failovers=").append(modelFailovers())
                    .append("; recoveryReplans=").append(recoveryReplans()).append('\n');
            out.append("workspaceRevision: ").append(mutationRevision()).append("; verificationRequired=").append(verificationRequired())
                    .append("; currentRevisionVerified=").append(verifiedCurrentRevision()).append('\n');
            if (!lastVerification().isBlank()) out.append("lastVerification: ").append(clipDurable(lastVerification(), 1000)).append('\n');
            if (!touchedPaths.isEmpty()) out.append("touchedPaths: ").append(String.join(", ", touchedPaths)).append('\n');
            if (!evidenceReferences.isBlank())
                out.append("lastSourceEvidenceReferences (check live file hashes before relying on these):\n")
                        .append(clipDurable(evidenceReferences, 1700)).append('\n');
            if (hasPlan()) {
                out.append("activePlanIndex: ").append(activePlanIndex()).append('\n');
                out.append("plan:\n").append(clipDurable(planText(), 4200)).append('\n');
            }
            if (!lastModelError().isBlank()) out.append("lastModelError: ").append(clipDurable(lastModelError(), 700)).append('\n');
            if (!lastRecoveryAnalysis().isBlank()) out.append("lastRecoveryAnalysis: ").append(clipDurable(lastRecoveryAnalysis(), 1200)).append('\n');
            if (!failureMemory.isEmpty()) out.append("avoidRepeatingFailures:\n").append(clipDurable(failureMemoryText(), 1800)).append('\n');
            if (largeTaskMode) {
                out.append("largeTask: ").append(workItemProgressDetail()).append("; batchSize=").append(workItemBatchSize).append('\n');
                if (!verificationFailureQueue.isEmpty()) out.append("verificationFailureQueue:\n").append(clipDurable(verificationFailureText(), 1800)).append('\n');
                if (!workItems.isEmpty()) out.append("activeWorkItems:\n").append(clipDurable(workItemsText("in_progress", 0, 12), 1800)).append('\n');
            }
            if (documentationMode) {
                out.append("documentationMode: true; coverageComplete=").append(documentationCoverageComplete)
                        .append("; validated=").append(documentationValidated).append('\n');
                if (!documentationCoverageSummary().isBlank()) out.append("documentationCoverage: ").append(clipDurable(documentationCoverageSummary(), 900)).append('\n');
                if (!documentationValidationSummary().isBlank()) out.append("documentationValidation: ").append(clipDurable(documentationValidationSummary(), 900)).append('\n');
            }
            if (loopBlocked()) out.append("loopBlock: ").append(clipDurable(loopBlockReason(), 700)).append('\n');
            out.append("continuation: continue only the active approved step; live workspace/tool results override historical summaries.");
            return out.toString();
        }

        private static String clipDurable(String value, int max) {
            if (value == null || value.length() <= max) return value == null ? "" : value;
            return value.substring(0, Math.max(0, max - 22)) + " …[state clipped]";
        }

        public synchronized void configureModelPool(List<String> models) {
            LinkedHashSet<String> clean = new LinkedHashSet<>();
            for (String model : models == null ? List.<String>of() : models) {
                if (model != null && !model.isBlank()) clean.add(model.trim());
            }
            modelPool.clear();
            modelPool.addAll(clean);
            activeModelIndex = 0;
            activeModel = modelPool.isEmpty() ? "" : modelPool.get(0);
            modelFailovers.set(0);
            lastModelError = "";
            persist();
        }

        public synchronized boolean switchToNextModel(String error) {
            lastModelError = error == null ? "" : error.strip();
            if (activeModelIndex + 1 >= modelPool.size()) { persist(); return false; }
            activeModelIndex++;
            activeModel = modelPool.get(activeModelIndex);
            modelFailovers.incrementAndGet();
            persist();
            return true;
        }

        /**
         * Provider-recovery failover is cyclic: primary -> fallback(s) -> primary. The caller owns the
         * bounded cycle budget so successful calls reset recovery immediately while long runs never enter
         * an unbounded failover loop. This method changes only the active runtime model; the saved primary
         * configuration and approved plan/workspace state are untouched.
         */
        public synchronized boolean switchToNextModelCyclic(String error) {
            lastModelError = error == null ? "" : error.strip();
            if (modelPool.size() < 2) { persist(); return false; }
            activeModelIndex = Math.floorMod(activeModelIndex + 1, modelPool.size());
            activeModel = modelPool.get(activeModelIndex);
            modelFailovers.incrementAndGet();
            persist();
            return true;
        }

        /** Context-specific failover may choose a later, larger-context model without disturbing completed work. */
        public synchronized boolean switchToModel(String targetModel, String error) {
            if (targetModel == null || targetModel.isBlank()) return false;
            int index = -1;
            for (int i = activeModelIndex + 1; i < modelPool.size(); i++) {
                if (targetModel.equals(modelPool.get(i))) { index = i; break; }
            }
            if (index < 0) return false;
            lastModelError = error == null ? "" : error.strip();
            activeModelIndex = index;
            activeModel = modelPool.get(index);
            modelFailovers.incrementAndGet();
            persist();
            return true;
        }

        /**
         * Start a fresh executor pass from the primary model after a recovery replan.
         * Failover telemetry is intentionally preserved so the UI/history reflects the complete run.
         */
        public synchronized boolean restartModelCycle(String reason) {
            lastModelError = reason == null ? "" : reason.strip();
            if (modelPool.isEmpty()) { activeModelIndex = 0; activeModel = ""; persist(); return false; }
            activeModelIndex = 0;
            activeModel = modelPool.get(0);
            persist();
            return true;
        }

        public synchronized void recordRecoveryReplan(String analysis) {
            recoveryReplans.incrementAndGet();
            lastRecoveryAnalysis = analysis == null ? "" : analysis.strip();
            progressPhase = "recovering";
            progressDetail = "Focused same-model recovery prepared; resuming the active step";
            touchActivity();
            persist();
        }

        private synchronized void inheritLargeTaskStateFrom(AgentRun prior) {
            if (prior == null || !prior.largeTaskMode()) return;
            largeTaskMode = true;
            // Resume must retain the original acceptance contract; the new user message
            // may be only 'continue' and must never replace the requested deliverables.
            if (!prior.originalTaskContract().isBlank()) originalTaskContract = prior.originalTaskContract();
            workItemBatchSize = prior.workItemBatchSize();
            documentationMode = prior.documentationMode();
            documentationCoverageComplete = prior.documentationCoverageComplete();
            documentationValidated = prior.documentationValidated();
            documentationCoverageSummary = prior.documentationCoverageSummary();
            documentationValidationSummary = prior.documentationValidationSummary();
            synchronized (prior) {
                for (WorkItem item : prior.workItems.values()) {
                    workItems.put(item.id(), new WorkItem(item.id(), item.title(), item.status(), item.note(), item.attempts()));
                }
                verificationFailureQueue.addAll(prior.verificationFailureQueue);
                touchedPaths.addAll(prior.touchedPaths);
            }
            long inheritedRevision = Math.max(0, prior.mutationRevision());
            if (inheritedRevision > 0) {
                mutationRevision.set(inheritedRevision);
                verificationRequiredRevision.set(inheritedRevision);
                lastVerificationAttemptRevision.set(-1);
                lastSuccessfulVerificationRevision.set(-1);
                lastVerificationSuccessful.set(false);
                lastVerification = "Inherited workspace changes require fresh verification after restart.";
            }
            progressPhase = "resuming";
            progressDetail = workItems.isEmpty()
                    ? "Resuming interrupted large task"
                    : "Recovered durable large-task ledger after restart: " + workItemProgressDetail();
            lastCheckpointReason = "Recovered durable work-item state from interrupted run " + prior.id();
        }

        public void checkCancelled() {
            if (cancelled()) throw new AgentCancelledException("Agent run was cancelled");
        }

        public boolean cancel() {
            // A second Stop on an in-flight cancellation is accepted rather than falsely
            // reporting that the backend does not recognize the requested cancellation.
            if (finished()) return "cancelled".equals(status);
            if (!cancelled.compareAndSet(false, true)) return true;
            status = "cancelling"; // only the worker's finally/finish confirms termination
            progressPhase = "cancelling";
            progressDetail = "Stopping active model, tool and workspace work";
            terminate(activeProcess.get());
            Thread worker = activeWorker.get();
            if (worker != null && worker != Thread.currentThread()) worker.interrupt();
            persist();
            return true;
        }

        /** Called by the execution worker, including the preparation and context phases. */
        public void registerWorker(Thread worker) {
            Objects.requireNonNull(worker, "worker");
            activeWorker.set(worker);
            // Stop can race with registration; never allow a cancelled worker to begin.
            if (cancelled()) {
                worker.interrupt();
                checkCancelled();
            }
        }

        public void unregisterWorker(Thread worker) {
            activeWorker.compareAndSet(worker, null);
        }

        public void registerProcess(Process process) {
            checkCancelled();
            activeProcess.set(process);
            if (cancelled()) terminate(process);
        }

        public void unregisterProcess(Process process) {
            activeProcess.compareAndSet(process, null);
        }

        public long markMutation() {
            return markMutation(true);
        }

        public long markMutation(boolean verificationRequired) {
            long revision = mutationRevision.incrementAndGet();
            if (verificationRequired) verificationRequiredRevision.set(revision);
            // A documentation PASS describes a specific workspace state. Any later mutation must invalidate it so
            // the final plan step cannot close against stale functional/technical documents or stale source evidence.
            if (documentationMode && documentationValidated) {
                documentationValidated = false;
                documentationValidationSummary = "Workspace changed after documentation validation; run documentation_validate again.";
            }
            persist();
            return revision;
        }

        public void recordContextEstimate(long currentTokens, long windowTokens) {
            currentContextTokens.set(Math.max(0, currentTokens));
            contextWindowTokens.set(Math.max(0, windowTokens));
            persistSoft();
        }

        public void recordModelUsage(OpenAiCompatibleClient.Usage usage, long estimatedInputForCall) {
            recordModelUsage(usage, estimatedInputForCall, "Agent execution", activePlanIndex);
        }

        /** Record usage once for each completed LLM call, preserving its activity and plan step. */
        public void recordModelUsage(OpenAiCompatibleClient.Usage usage, long estimatedInputForCall,
                                     String activity, int step) {
            modelCalls.incrementAndGet();
            estimatedInputTokens.addAndGet(Math.max(0, estimatedInputForCall));
            long input = usage == null ? 0 : Math.max(0, usage.inputTokens());
            long output = usage == null ? 0 : Math.max(0, usage.outputTokens());
            long total = usage == null ? 0 : Math.max(0, usage.totalTokens());
            long cached = usage == null ? 0 : Math.max(0, usage.cachedInputTokens());
            long write = usage == null ? 0 : Math.max(0, usage.cacheWriteTokens());
            tokenActivity.record(activity, step, estimatedInputForCall, input, output, total, cached, write,
                    usage != null && usage.providerReported());
            providerInputTokens.addAndGet(input);
            providerOutputTokens.addAndGet(output);
            providerTotalTokens.addAndGet(total > 0 ? total : input + output);
            cachedInputTokens.addAndGet(cached);
            cacheWriteTokens.addAndGet(write);
            // Preserve every completed call in the durable ledger, including short runs and crashes.
            persist();
        }

        public List<Map<String,Object>> tokenActivitySnapshot() { return tokenActivity.snapshot(); }

        public void recordCompaction(long estimatedTokensSaved, String reason) {
            compactions.incrementAndGet();
            estimatedTokensSavedByCompaction.addAndGet(Math.max(0, estimatedTokensSaved));
            lastCheckpointReason = reason == null ? "" : reason;
            persist();
        }

        public void markRepeatedCallPrevented() { repeatedCallsPrevented.incrementAndGet(); persist(); }

        /**
         * Monotonic phase progress before/after execution. While an approved plan is active, the percentage is
         * authoritative plan progress and tool/activity updates may change only the phase/detail.
         */
        public void updateProgress(int percent, String phase, String detail) {
            // Delayed callbacks must not overwrite the user's Stop/cancelling phase.
            if (cancelled() || finished()) return;
            int bounded = Math.max(0, Math.min(99, percent));
            synchronized (this) {
                if (planLocked && hasOpenPlanItems()) {
                    if (phase != null && !phase.isBlank()) progressPhase = phase.strip();
                    if (detail != null && !detail.isBlank()) progressDetail = detail.strip();
                    touchActivity();
                    persist();
                    return;
                }
            }
            long before = progressPercent.getAndAccumulate(bounded, Math::max);
            if (bounded >= before) {
                if (phase != null && !phase.isBlank()) progressPhase = phase.strip();
                if (detail != null && !detail.isBlank()) progressDetail = detail.strip();
            }
            touchActivity();
            persist();
        }

        public void markFinalAnswer(String answer) {
            finalAnswer = answer == null ? "" : answer;
            updateProgress(97, "finalizing", "Preparing final response");
        }

        public void markResponsePersisted(String messageId, String answer) {
            if (answer != null && !answer.isBlank()) finalAnswer = answer;
            assistantMessageId = messageId == null ? "" : messageId;
            responsePersisted.set(true);
            if ("completed".equals(status)) {
                progressPercent.set(100);
                progressPhase = "completed";
                progressDetail = "Task completed";
            } else {
                progressPercent.updateAndGet(value -> Math.max(1, Math.min(99, value)));
                progressPhase = status;
                if (progressDetail == null || progressDetail.isBlank() || "Persisting final response".equals(progressDetail)) {
                    progressDetail = "blocked".equals(status) ? "Task blocked" : "Task " + status;
                }
            }
            persist();
        }

        public void markVerificationAttempt(boolean successful, String summary) {
            verificationAttemptCount.incrementAndGet();
            long rev = mutationRevision.get();
            lastVerificationAttemptRevision.set(rev);
            if (successful) lastSuccessfulVerificationRevision.set(rev);
            lastVerificationSuccessful.set(successful);
            lastVerification = summary == null ? "" : summary;
            persist();
        }

        public boolean verifiedCurrentRevision() {
            long required = verificationRequiredRevision.get();
            if (required < 0) return true;
            if (lastVerificationAttemptRevision.get() >= required && !lastVerificationSuccessful.get()) return false;
            return lastSuccessfulVerificationRevision.get() >= required;
        }

        public boolean verificationRequired() {
            return !verifiedCurrentRevision();
        }

        public void markDiffReview() {
            lastDiffRevision.set(mutationRevision.get());
            persist();
        }

        public boolean diffReviewedCurrentRevision() {
            return lastDiffRevision.get() >= mutationRevision.get();
        }

        public synchronized void setPlan(List<String> items) {
            if (planLocked) throw new IllegalStateException("Approved execution plan is locked; use todo_update on the active step instead of replacing it");
            plan.clear();
            planEvidence.clear();
            int i = 1;
            for (String item : items == null ? List.<String>of() : items) {
                String value = normalizePlanText(item);
                if (value.isBlank()) continue;
                plan.add(new PlanItem(i++, value, "pending", ""));
            }
            activePlanIndex = 0;
            planStepToolActivity.set(0);
            planStepStartMutationRevision.set(mutationRevision.get());
            recalculatePlanProgress();
            persist();
        }

        /** Replace the human-reviewable draft before approval. Once execution starts the plan is immutable. */
        public synchronized void replaceDraftPlan(List<String> items) {
            if (planLocked || activePlanIndex > 0) {
                throw new IllegalStateException("Execution has already started; the approved plan can no longer be edited");
            }
            LinkedHashSet<String> clean = new LinkedHashSet<>();
            for (String item : items == null ? List.<String>of() : items) {
                String value = normalizePlanText(item);
                if (value.isBlank()) continue;
                clean.add(value);
                if (clean.size() >= 15) break;
            }
            if (clean.isEmpty()) throw new IllegalArgumentException("At least one plan step is required");
            plan.clear();
            planEvidence.clear();
            int index = 1;
            for (String item : clean) plan.add(new PlanItem(index++, item, "pending", ""));
            planStepToolActivity.set(0);
            planStepStartMutationRevision.set(mutationRevision.get());
            recalculatePlanProgress();
            planValidationStatus = "needs_review";
            planValidationSummary = "Plan edited by the user after model validation; user approval is authoritative for this edited draft.";
            progressPhase = "plan_review";
            progressDetail = "Plan updated; waiting for approval";
            persist();
        }

        /**
         * Replace only the unfinished portion of an already-approved plan after every executor model has
         * exhausted its recovery path. Completed steps/evidence stay immutable; the newly validated
         * remaining steps become the active sequential contract immediately.
         */
        public synchronized void reviseRemainingPlan(List<String> remainingItems, String reason) {
            if (!planLocked) throw new IllegalStateException("Recovery replanning requires an approved/locked plan");
            LinkedHashSet<String> clean = new LinkedHashSet<>();
            for (String item : remainingItems == null ? List.<String>of() : remainingItems) {
                String value = normalizePlanText(item);
                if (value.isBlank()) continue;
                clean.add(value);
                if (clean.size() >= 12) break;
            }
            if (clean.isEmpty()) throw new IllegalArgumentException("Recovery replan must contain at least one remaining step");

            List<PlanItem> completed = new ArrayList<>();
            Map<Integer, ArrayDeque<String>> completedEvidence = new LinkedHashMap<>();
            for (PlanItem item : plan) {
                if (!"completed".equals(item.status())) continue;
                int nextIndex = completed.size() + 1;
                completed.add(new PlanItem(nextIndex, item.text(), "completed", item.note()));
                ArrayDeque<String> evidence = planEvidence.get(item.index());
                if (evidence != null && !evidence.isEmpty()) completedEvidence.put(nextIndex, new ArrayDeque<>(evidence));
            }

            plan.clear();
            planEvidence.clear();
            plan.addAll(completed);
            planEvidence.putAll(completedEvidence);
            int index = plan.size() + 1;
            boolean firstRecoveryStep = true;
            for (String item : clean) {
                String note = firstRecoveryStep && reason != null && !reason.isBlank()
                        ? "Recovery replan: " + clipDurable(reason.replaceAll("\\s+", " ").strip(), 280)
                        : "";
                plan.add(new PlanItem(index++, item, "pending", note));
                firstRecoveryStep = false;
            }
            activePlanIndex = completed.size() + 1;
            if (activePlanIndex <= plan.size()) {
                PlanItem first = plan.get(activePlanIndex - 1);
                plan.set(activePlanIndex - 1, new PlanItem(first.index(), first.text(), "in_progress",
                        first.note().isBlank() ? "Recovery execution started" : first.note()));
            } else {
                activePlanIndex = 0;
            }
            clearFailureMemory();
            planStepToolActivity.set(0);
            planStepStartMutationRevision.set(mutationRevision.get());
            recalculatePlanProgress();
            progressPhase = "recovering";
            progressDetail = "Recovery plan validated; resuming from step " + activePlanIndex;
            persist();
        }

        public synchronized void lockPlan() {
            planLocked = true;
            persist();
        }

        public synchronized void updatePlan(int index, String newStatus, String note) {
            if (index < 1 || index > plan.size()) throw new IllegalArgumentException("Plan index is out of range");
            String status = normalizePlanStatus(newStatus);
            PlanItem old = plan.get(index - 1);
            if (planLocked) {
                if (index != activePlanIndex) {
                    throw new IllegalStateException("Sequential plan gate: only active step " + activePlanIndex + " can be updated; step " + index + " is locked");
                }
                if ("skipped".equals(status)) {
                    throw new IllegalStateException("Approved plan contract: retained steps cannot be skipped. Complete the active step or report a genuine blocker.");
                }
                if ("completed".equals(status) && planStepToolActivity.get() <= 0) {
                    throw new IllegalStateException("Sequential plan gate: step " + index + " cannot complete without real tool activity");
                }
                // Implementation steps may complete from real workspace/tool evidence without compiling after every edit.
                // The final approved step is the verification boundary: if the workspace changed, it cannot close until
                // the latest revision has passed a real verifier. This batches build/test/check/run after coherent edits.
                if ("completed".equals(status) && index == plan.size() && verificationRequired()) {
                    throw new IllegalStateException("Final verification step cannot complete until the latest workspace revision passes a real verifier");
                }
                if ("completed".equals(status) && index == plan.size() && documentationMode) {
                    if (!documentationCoverageComplete) {
                        throw new IllegalStateException("Documentation final step cannot complete until repository module coverage is complete");
                    }
                    if (!documentationValidated) {
                        throw new IllegalStateException("Documentation final step cannot complete until documentation_validate passes");
                    }
                }
                if ("completed".equals(status) && index == plan.size() && largeTaskMode) {
                    if (workItems.isEmpty()) {
                        throw new IllegalStateException("Large-task final step cannot complete before the durable work-item inventory is initialized");
                    }
                    if (hasUnresolvedWorkItems()) {
                        throw new IllegalStateException("Large-task final step cannot complete while pending/in-progress/failed/blocked work items remain");
                    }
                    if (hasVerificationFailures()) {
                        throw new IllegalStateException("Large-task final step cannot complete while verifier failures remain unresolved");
                    }
                }
                if ("pending".equals(status)) {
                    throw new IllegalStateException("Sequential plan gate: the active approved step cannot be moved back to pending");
                }
            }
            String finalNote = note == null ? "" : note.strip();
            if ("completed".equals(status) && finalNote.isBlank()) finalNote = completionEvidence(index);
            plan.set(index - 1, new PlanItem(old.index(), old.text(), status, finalNote));
            if (planLocked && "completed".equals(status)) {
                int next = index + 1;
                if (next <= plan.size()) {
                    PlanItem nextItem = plan.get(next - 1);
                    plan.set(next - 1, new PlanItem(nextItem.index(), nextItem.text(), "in_progress", "Unlocked after step " + index + " completed"));
                    activePlanIndex = next;
                    clearFailureMemory();
                    planStepToolActivity.set(0);
                    planStepStartMutationRevision.set(mutationRevision.get());
                } else {
                    activePlanIndex = 0;
                    clearFailureMemory();
                }
            }
            recalculatePlanProgress();
            persist();
        }

        public synchronized void recordPlanToolActivity(String tool) { recordPlanToolActivity(tool, ""); }

        /** Evidence collected after every plan step closed (final outcome review follow-ups). */
        private static final int POST_PLAN_EVIDENCE_KEY = 0;

        public synchronized void recordPlanToolActivity(String tool, String summary) {
            if (!planLocked || plan.isEmpty()) return;
            String t = tool == null ? "" : tool.trim().toLowerCase(Locale.ROOT);
            if (Set.of("todowrite", "todoread", "todo_update").contains(t)) return;
            // After the last step closes, the final reviewer may ask for targeted proof. Those reads/tests
            // used to be dropped here, so the reviewer never saw them and its cached MISSING_EVIDENCE verdict
            // repeated until the run ended "blocked". Record them under a dedicated post-plan key instead.
            boolean postPlan = activePlanIndex <= 0;
            if (!postPlan) planStepToolActivity.incrementAndGet();
            totalToolActions.incrementAndGet();
            String evidence = summary == null ? "" : summary.replaceAll("\\s+", " ").strip();
            if (!evidence.isBlank()) {
                if (evidence.length() > 360) evidence = evidence.substring(0, 360) + " …";
                int key = postPlan ? POST_PLAN_EVIDENCE_KEY : activePlanIndex;
                ArrayDeque<String> items = planEvidence.computeIfAbsent(key, ignored -> new ArrayDeque<>());
                String line = (t.isBlank() ? "tool" : t) + ": " + evidence;
                if (items.isEmpty() || !items.peekLast().equals(line)) items.addLast(line);
                while (items.size() > 20) items.removeFirst();
            }
            recalculatePlanProgress();
            touchActivity();
            persist();
        }

        private synchronized String completionEvidence(int index) {
            ArrayDeque<String> evidence = planEvidence.get(index);
            if (evidence == null || evidence.isEmpty()) return "Completed with recorded tool evidence.";
            String value = evidence.peekLast();
            return value == null || value.isBlank() ? "Completed with recorded tool evidence." : value;
        }

        public synchronized List<Map<String,Object>> planSnapshot() {
            List<Map<String,Object>> out = new ArrayList<>();
            for (PlanItem item : plan) {
                Map<String,Object> row = new LinkedHashMap<>();
                row.put("index", item.index());
                row.put("text", item.text());
                row.put("status", item.status());
                row.put("note", item.note());
                ArrayDeque<String> evidence = planEvidence.get(item.index());
                row.put("evidence", evidence == null ? List.of() : List.copyOf(evidence));
                out.add(row);
            }
            return List.copyOf(out);
        }

        public synchronized String activePlanStepText() {
            if (activePlanIndex < 1 || activePlanIndex > plan.size()) return "";
            return plan.get(activePlanIndex - 1).text();
        }

        /** Workspace revision when the current plan step was unlocked. */
        public long planStepStartMutationRevision() { return planStepStartMutationRevision.get(); }

        /** Bounded tool evidence collected only for the current active step. */
        public synchronized String activePlanEvidenceText() {
            // With no active step, expose post-plan evidence so the final reviewer (and its cache key)
            // reflects the targeted proof gathered after the plan closed.
            ArrayDeque<String> evidence = planEvidence.get(activePlanIndex < 1 ? POST_PLAN_EVIDENCE_KEY : activePlanIndex);
            if (evidence == null || evidence.isEmpty()) return "";
            StringBuilder out = new StringBuilder();
            for (String item : evidence) out.append("- ").append(item).append('\n');
            return out.toString().stripTrailing();
        }

        public synchronized String planText() {
            if (plan.isEmpty()) return "[No plan set]";
            StringBuilder out = new StringBuilder();
            for (PlanItem item : plan) {
                out.append(item.index()).append(". [").append(item.status()).append("] ").append(item.text());
                if (!item.note().isBlank()) out.append(" — ").append(item.note());
                out.append('\n');
            }
            return out.toString().stripTrailing();
        }

        public synchronized boolean hasPlan() { return !plan.isEmpty(); }
        public synchronized int planSize() { return plan.size(); }

        public synchronized boolean hasOpenPlanItems() {
            return plan.stream().anyMatch(item -> "pending".equals(item.status()) || "in_progress".equals(item.status()));
        }

        /** Compatibility helper. Locked approved plans must be progressed step-by-step, never bulk-completed. */
        public synchronized void completeOpenPlanItems(String note) {
            if (planLocked) throw new IllegalStateException("Approved plan is sequentially locked and cannot be bulk-completed");
            if (plan.isEmpty()) return;
            String n = note == null ? "" : note.strip();
            for (int i = 0; i < plan.size(); i++) {
                PlanItem old = plan.get(i);
                if ("pending".equals(old.status()) || "in_progress".equals(old.status())) {
                    plan.set(i, new PlanItem(old.index(), old.text(), "completed", n));
                }
            }
            recalculatePlanProgress();
            persist();
        }

        public synchronized void markPlanStarted() {
            if (plan.isEmpty()) return;
            planLocked = true;
            int firstOpen = -1;
            for (int i = 0; i < plan.size(); i++) {
                String status = plan.get(i).status();
                if ("pending".equals(status) || "in_progress".equals(status)) { firstOpen = i; break; }
            }
            if (firstOpen < 0) { activePlanIndex = 0; persist(); return; }
            PlanItem first = plan.get(firstOpen);
            plan.set(firstOpen, new PlanItem(first.index(), first.text(), "in_progress", first.note().isBlank() ? "Execution started" : first.note()));
            activePlanIndex = first.index();
            planStepToolActivity.set(0);
            planStepStartMutationRevision.set(mutationRevision.get());
            recalculatePlanProgress();
            persist();
        }

        public String recoveredFromRunId() { return recoveredFromRunId == null ? "" : recoveredFromRunId; }

        /**
         * Input typed while this task runs. A refinement is queued and delivered after the current action. ELIYA184:
         * a control instruction is acted on at once — "stop … show the results so far" interrupts the current action
         * and ends the run with a results report, "skip this step" interrupts the current action and skips the active
         * plan step, "status" is answered immediately with a progress snapshot (see {@link RunControl}).
         */
        public synchronized UserInput submitUserInput(String text) {
            String value = text == null ? "" : text.strip();
            if (value.isEmpty()) throw new IllegalArgumentException("Input cannot be empty");
            if (value.length() > MAX_USER_INPUT_CHARS) throw new IllegalArgumentException("Input is too long (max " + MAX_USER_INPUT_CHARS + " characters)");
            if (finished()) throw new IllegalStateException("This task has already finished; send the input as a new task instead");
            RunControl.Kind kind = RunControl.classify(value);
            if (kind == RunControl.Kind.SKIP_STEP) {
                int named = RunControl.namedStep(value);
                // Only the running step can be skipped at once; another step number is an ordinary instruction.
                if (!planLocked || activePlanIndex < 1 || (named > 0 && named != activePlanIndex)) kind = RunControl.Kind.REFINE;
            }
            String id = UUID.randomUUID().toString();
            Instant now = Instant.now();
            UserInput input;
            switch (kind) {
                case STOP_AND_REPORT -> {
                    input = new UserInput(id, value, now, "stopping", now, "stop",
                            "Stopping the current action; the results so far will be shown.");
                    userInputs.add(input);
                    requestStopWithReport(value);
                }
                case SKIP_STEP -> {
                    input = new UserInput(id, value, now, "skipping", null, "skip",
                            "Interrupting the current action and skipping step " + activePlanIndex + ".");
                    userInputs.add(input);
                    interruptActiveAction();
                }
                case STATUS -> {
                    input = new UserInput(id, value, now, "answered", now, "status", StopReport.progress(this));
                    userInputs.add(input);
                }
                default -> {
                    long pending = userInputs.stream().filter(u -> "pending".equals(u.status())).count();
                    if (pending >= MAX_PENDING_USER_INPUT) throw new IllegalStateException("Too many inputs are waiting; wait for the Agent to pick them up");
                    input = new UserInput(id, value, now, "pending", null, "refine",
                            "Will be applied after the current action" +
                                    (progressDetail == null || progressDetail.isBlank() ? "." : ": " + clipDurable(progressDetail, 160)));
                    userInputs.add(input);
                }
            }
            touchActivity();
            return input;
        }

        /** Mark every pending input (and accepted skip request) delivered, in submission order (executor loop). */
        public synchronized List<UserInput> takePendingUserInput() {
            List<UserInput> delivered = new ArrayList<>();
            for (int i = 0; i < userInputs.size(); i++) {
                UserInput input = userInputs.get(i);
                if (!"pending".equals(input.status()) && !"skipping".equals(input.status())) continue;
                UserInput done = new UserInput(input.id(), input.text(), input.submittedAt(), "delivered", Instant.now(),
                        input.kind(), input.reply());
                userInputs.set(i, done);
                delivered.add(done);
            }
            return delivered;
        }

        /** ELIYA184: end the run now and present the results so far (instead of a bare "cancelled"). */
        public void requestStopWithReport(String instruction) {
            if (finished()) return;
            if (!stopWithReport) {
                stopInstruction = instruction == null ? "" : clipDurable(instruction.strip(), 600);
                stopRequestedAt = Instant.now();
                stopActiveAction = clipDurable(progressDetail(), 300);
                stopWithReport = true;
            }
            cancel();
        }

        /** True when the user asked to stop and see the results so far (typed or Stop pressed). */
        public boolean stopWithReport() { return stopWithReport; }
        public String stopInstruction() { return stopInstruction == null ? "" : stopInstruction; }
        public Instant stopRequestedAt() { return stopRequestedAt; }
        /** What the task was doing when the stop arrived. */
        public String stopActiveAction() { return stopActiveAction == null ? "" : stopActiveAction; }

        /** Kill the running command (not the run): used by "skip this step". */
        public void interruptActiveAction() {
            Process process = activeProcess.get();
            if (process != null && process.isAlive()) {
                actionInterruptedByUser.set(true);
                terminate(process);
            }
        }

        /** True once after the running command was killed by {@link #interruptActiveAction()}. */
        public boolean consumeActionInterrupt() { return actionInterruptedByUser.getAndSet(false); }

        /**
         * Mark the active plan step as skipped on the user's explicit instruction and unlock the next one.
         * The model may never skip an approved step on its own; this is the user's decision. Returns the skipped
         * step number, or 0 when no step was active.
         */
        public synchronized int skipActiveStepByUser(String instruction) {
            if (!planLocked || activePlanIndex < 1 || activePlanIndex > plan.size()) return 0;
            int index = activePlanIndex;
            PlanItem old = plan.get(index - 1);
            plan.set(index - 1, new PlanItem(old.index(), old.text(), "skipped",
                    clipDurable(USER_SKIP_NOTE + (instruction == null || instruction.isBlank() ? "" : ": " + instruction.strip()), 400)));
            int next = index + 1;
            if (next <= plan.size()) {
                PlanItem nextItem = plan.get(next - 1);
                plan.set(next - 1, new PlanItem(nextItem.index(), nextItem.text(), "in_progress", "Unlocked after step " + index + " was skipped by the user"));
                activePlanIndex = next;
            } else {
                activePlanIndex = 0;
            }
            clearFailureMemory();
            planStepToolActivity.set(0);
            planStepStartMutationRevision.set(mutationRevision.get());
            recalculatePlanProgress();
            persist();
            return index;
        }

        /** A step the user explicitly skipped counts as resolved for the plan gate (never for verification). */
        static boolean skippedByUser(PlanItem item) {
            return item != null && "skipped".equals(item.status()) && item.note() != null && item.note().startsWith(USER_SKIP_NOTE);
        }

        /** The latest activity events (newest last), bounded; cheaper than {@link #activitySnapshot()}. */
        public synchronized List<Map<String,Object>> recentActivity(int max) {
            int limit = Math.max(1, Math.min(max, 200));
            ArrayDeque<Map<String,Object>> out = new ArrayDeque<>();
            Iterator<ActivityEvent> it = activityEvents.descendingIterator();
            while (it.hasNext() && out.size() < limit) {
                ActivityEvent event = it.next();
                Map<String,Object> row = new LinkedHashMap<>();
                row.put("at", event.at().toString());
                row.put("step", event.step());
                row.put("tool", event.tool());
                row.put("status", event.status());
                row.put("detail", event.detail());
                if (!event.args().isBlank()) row.put("args", event.args());
                if (!event.output().isBlank()) row.put("output", event.output());
                out.addFirst(row);
            }
            return List.copyOf(out);
        }

        /** Withdraw an input the Agent has not picked up yet. */
        public synchronized boolean withdrawUserInput(String inputId) {
            for (int i = 0; i < userInputs.size(); i++) {
                UserInput input = userInputs.get(i);
                if (input.id().equals(inputId) && "pending".equals(input.status())) {
                    userInputs.set(i, new UserInput(input.id(), input.text(), input.submittedAt(), "withdrawn", null, input.kind(), input.reply()));
                    return true;
                }
            }
            return false;
        }

        public synchronized List<UserInput> userInputs() { return List.copyOf(userInputs); }

        /** Make a mid-run addition part of the task contract, so the final review checks it too. */
        public synchronized void addObjectiveAddendum(String text) {
            if (text == null || text.isBlank()) return;
            objective = objective() + "\n\nUser addition during execution: " + clipDurable(text.strip(), 2_000);
            persist();
        }

        /** Snapshot for a linked recovery run (only meaningful for failed/blocked/interrupted/cancelled runs). */
        public synchronized RecoverySeed recoverySeed() {
            Map<Integer, List<String>> evidence = new LinkedHashMap<>();
            for (Map.Entry<Integer, ArrayDeque<String>> entry : planEvidence.entrySet())
                evidence.put(entry.getKey(), List.copyOf(entry.getValue()));
            String reason = firstNonBlankValue(loopBlockReason, lastModelError, failureStage == null || failureStage.isBlank() ? "" : "Stopped during the " + failureStage + " stage",
                    progressDetail, finalAnswer);
            return new RecoverySeed(id, conversationId, projectId, status, objective(), originalTaskContract == null ? "" : originalTaskContract,
                    List.copyOf(plan), Map.copyOf(evidence), List.copyOf(touchedPaths()), clipDurable(reason, 1_500),
                    lastVerification == null ? "" : lastVerification, Instant.now());
        }

        /**
         * Restore a terminated run's progress into this (new, not yet started) run: keep the original task contract,
         * mark the completed plan prefix as done with its evidence, and carry touched paths. Verification state is NOT
         * inherited: the reopened final step must verify the current workspace again. Call after setPlan(seed.planTexts())
         * and before markPlanStarted().
         */
        public synchronized int restoreFromRecovery(RecoverySeed seed) {
            if (seed == null || planLocked) return 0;
            recoveredFromRunId = seed.priorRunId();
            if (!seed.originalTaskContract().isBlank()) originalTaskContract = seed.originalTaskContract();
            if (!seed.objective().isBlank()) objective = seed.objective();
            touchedPaths.addAll(seed.touchedPaths());
            int keep = Math.min(seed.restorableCompletedSteps(), plan.size());
            for (int i = 0; i < keep; i++) {
                PlanItem current = plan.get(i);
                String note = seed.plan().get(i).note();
                plan.set(i, new PlanItem(current.index(), current.text(), "completed",
                        clipDurable("Restored from run " + seed.priorRunId() + (note == null || note.isBlank() ? "" : ": " + note), 600)));
                List<String> prior = seed.evidence().get(current.index());
                if (prior != null && !prior.isEmpty()) planEvidence.put(current.index(), new ArrayDeque<>(prior));
            }
            progressPhase = "resuming";
            progressDetail = "Recovering run " + seed.priorRunId() + ": " + keep + " completed step(s) kept, " +
                    (plan.size() - keep) + " remaining";
            recalculatePlanProgress();
            persist();
            return keep;
        }

        private static String firstNonBlankValue(String... values) {
            for (String value : values) if (value != null && !value.isBlank()) return value;
            return "";
        }

        public void finish(String finalStatus) {
            // Stop wins every race with model/tool completion. A late completed outcome must
            // never supersede the user's explicit cancellation.
            if (cancelled()) status = "cancelled";
            else status = finalStatus == null || finalStatus.isBlank() ? "completed" : finalStatus;
            synchronized (this) {
                // Input typed after the executor's last turn was never seen by the Agent: say so (the UI offers it
                // as the next task) instead of silently dropping it.
                for (int i = 0; i < userInputs.size(); i++) {
                    UserInput input = userInputs.get(i);
                    if ("pending".equals(input.status()) || "skipping".equals(input.status()))
                        userInputs.set(i, new UserInput(input.id(), input.text(), input.submittedAt(), "undelivered", null, input.kind(), input.reply()));
                }
                // ELIYA131: the final run status cannot be completed while a required verification
                // is stale or failed for the latest workspace mutation.
                if ("completed".equals(status) && mutationRevision.get() > 0 && verificationRequired()) {
                    status = "blocked";
                    loopBlockReason = "The latest workspace changes have not passed required verification; " +
                            "run appropriate checks and inspect their results before declaring completion.";
                }
                if ("completed".equals(status) && hasVerificationFailures()) {
                    status = "blocked";
                    loopBlockReason = "There are unresolved verification failures; successful earlier steps do not qualify as final completion.";
                }
                if ("completed".equals(status) && planLocked && !plan.isEmpty() && plan.stream().anyMatch(item -> !"completed".equals(item.status()) && !skippedByUser(item))) {
                    status = "blocked";
                    loopBlockReason = "Approved plan is incomplete; every retained step must complete before the run can finish successfully.";
                }
                if ("completed".equals(status) && documentationMode && !documentationCoverageComplete) {
                    status = "blocked";
                    loopBlockReason = "Documentation coverage is incomplete; every discovered module must be completed or explicitly excluded with evidence.";
                }
                if ("completed".equals(status) && documentationMode && !documentationValidated) {
                    status = "blocked";
                    loopBlockReason = "Documentation validation has not passed. Run documentation_validate after generating the final documents.";
                }
                if ("completed".equals(status) && largeTaskMode && workItems.isEmpty()) {
                    status = "blocked";
                    loopBlockReason = "Large task did not initialize its durable work-item inventory, so completion cannot be proven.";
                }
                if ("completed".equals(status) && largeTaskMode && hasUnresolvedWorkItems()) {
                    status = "blocked";
                    loopBlockReason = "Large task still has unresolved work items. Complete or explicitly block the remaining items before successful completion.";
                }
                if ("completed".equals(status) && largeTaskMode && !verificationFailureQueue.isEmpty()) {
                    status = "blocked";
                    loopBlockReason = "Large task still has unresolved verification failures. Fix and rerun the relevant verifier before successful completion.";
                }
            }
            // Preserve the stage which actually stopped the run. Replacing the phase
            // with "blocked" used to make the UI falsely mark Plan as failed.
            if (!"completed".equals(status)) {
                if (hasVerificationFailures() || (mutationRevision.get() > 0 && verificationRequired()))
                    failureStage = "verify";
                else if (planLocked && hasOpenPlanItems()) failureStage = "execute";
                else if ("not_run".equals(planValidationStatus) && hasPlan() && !planLocked) failureStage = "plan";
                else if (progressPhase != null && !progressPhase.isBlank() &&
                        !java.util.Set.of("blocked", "failed", "cancelled", "interrupted", "stalled").contains(progressPhase))
                    failureStage = progressPhase;
                else if (failureStage.isBlank()) failureStage = "analyse";
            }
            if ("completed".equals(status)) {
                progressPercent.accumulateAndGet(98, Math::max);
                progressPhase = "finalizing";
                progressDetail = "Persisting final response";
            } else if ("blocked".equals(status)) {
                progressPercent.updateAndGet(value -> Math.max(1, Math.min(99, value)));
                progressPhase = "blocked";
                progressDetail = loopBlocked() ? loopBlockReason() : "Task blocked";
            } else if ("cancelled".equals(status)) {
                progressPercent.updateAndGet(value -> Math.max(1, Math.min(99, value)));
                progressPhase = "cancelled";
                progressDetail = "Task cancelled";
            } else if ("failed".equals(status)) {
                progressPercent.updateAndGet(value -> Math.max(1, Math.min(99, value)));
                progressPhase = "failed";
                progressDetail = "Task failed";
            }
            finishedAt = Instant.now();
            terminate(activeProcess.getAndSet(null));
            persist();
        }

        private synchronized void recalculatePlanProgress() {
            if (plan.isEmpty()) return;
            long completed = plan.stream().filter(item -> "completed".equals(item.status()) || skippedByUser(item)).count();
            if (!planLocked) {
                progressPercent.accumulateAndGet(12, Math::max);
                return;
            }
            if (largeTaskMode && !workItems.isEmpty()) {
                long workCompleted = workItems.values().stream().filter(item -> "completed".equals(item.status())).count();
                long workActive = workItems.values().stream().filter(item -> "in_progress".equals(item.status())).count();
                double workFraction = (workCompleted + Math.min(0.5, workActive * 0.15)) / Math.max(1.0, workItems.size());
                double planFraction = completed / Math.max(1.0, plan.size());
                double combined = Math.min(1.0, (workFraction * 0.78) + (planFraction * 0.22));
                progressPercent.set(Math.max(15, Math.min(88, (int)Math.round(15 + combined * 73))));
                progressPhase = completed == plan.size() && !hasUnresolvedWorkItems() ? "tasks_complete" : "executing";
                progressDetail = workItemProgressDetail();
                touchActivity();
                return;
            }
            double span = 73.0 / Math.max(1, plan.size());
            double base = 15.0 + completed * span;
            if (completed < plan.size() && activePlanIndex > 0) {
                double actions = Math.max(0, planStepToolActivity.get());
                // Real tool activity gives bounded within-step movement without pretending the step is complete.
                double activityFraction = Math.min(0.72, (actions / (actions + 4.0)) * 0.72);
                base += span * activityFraction;
            }
            progressPercent.set(Math.max(15, Math.min(88, (int)Math.round(base))));
            if (completed == plan.size()) progressPhase = "tasks_complete";
            else if (progressPhase == null || progressPhase.isBlank() || "working".equals(progressPhase)) progressPhase = "executing";
            if (progressDetail == null || progressDetail.isBlank() || progressDetail.matches("\\d+/\\d+ planned steps completed")) {
                progressDetail = completed + "/" + plan.size() + " planned steps completed";
            }
            touchActivity();
        }

        private void markInterruptedByRestart() {
            status = "interrupted";
            progressPercent.updateAndGet(value -> Math.max(1, Math.min(99, value)));
            progressPhase = "interrupted";
            progressDetail = "Agent run was interrupted by application restart";
            if (finalAnswer == null || finalAnswer.isBlank()) finalAnswer = "Agent run was interrupted by application restart before completion.";
            finishedAt = Instant.now();
            recordActivityEvent(Map.of(
                    "step", activePlanIndex,
                    "tool", "run_interrupted",
                    "status", "error",
                    "detail", "Application restarted while this run was active; persisted history and task state were recovered"));
            persist();
        }

        private Properties toProperties() {
            Properties p = new Properties();
            p.setProperty("id", id);
            p.setProperty("conversationId", conversationId == null ? "" : conversationId);
            p.setProperty("projectId", projectId == null ? "" : projectId);
            p.setProperty("createdAt", createdAt.toString());
            p.setProperty("status", status == null ? "running" : status);
            p.setProperty("cancelled", Boolean.toString(cancelled()));
            p.setProperty("mutationRevision", Long.toString(mutationRevision()));
            p.setProperty("verificationRequiredRevision", Long.toString(verificationRequiredRevision()));
            p.setProperty("lastVerificationAttemptRevision", Long.toString(lastVerificationAttemptRevision()));
            p.setProperty("verificationAttemptCount", Long.toString(verificationAttemptCount()));
            p.setProperty("lastSuccessfulVerificationRevision", Long.toString(lastSuccessfulVerificationRevision()));
            p.setProperty("lastDiffRevision", Long.toString(lastDiffRevision()));
            p.setProperty("lastVerificationSuccessful", Boolean.toString(lastVerificationSuccessful()));
            p.setProperty("lastVerification", lastVerification == null ? "" : lastVerification);
            p.setProperty("progressPercent", Integer.toString(progressPercent()));
            p.setProperty("progressPhase", progressPhase());
            p.setProperty("progressDetail", progressDetail());
            p.setProperty("failureStage", failureStage == null ? "" : failureStage);
            p.setProperty("responsePersisted", Boolean.toString(responsePersisted()));
            p.setProperty("finalAnswer", finalAnswer());
            p.setProperty("assistantMessageId", assistantMessageId());
            p.setProperty("planValidationStatus", planValidationStatus());
            p.setProperty("planValidationSummary", planValidationSummary());
            synchronized (this) {
                int skip = Math.max(0, activityEvents.size() - ACTIVITY_EVENTS_IN_SNAPSHOT);
                List<ActivityEvent> recentActivity = activityEvents.stream().skip(skip).toList();
                p.setProperty("activity.count", Integer.toString(recentActivity.size()));
                int ai = 0;
                for (ActivityEvent event : recentActivity) p.setProperty("activity." + (ai++), encodeActivity(event));
            }
            tokenActivity.store(p);
            p.setProperty("modelCalls", Long.toString(modelCalls.get()));
            p.setProperty("providerInputTokens", Long.toString(providerInputTokens.get()));
            p.setProperty("providerOutputTokens", Long.toString(providerOutputTokens.get()));
            p.setProperty("providerTotalTokens", Long.toString(providerTotalTokens.get()));
            p.setProperty("cachedInputTokens", Long.toString(cachedInputTokens.get()));
            p.setProperty("cacheWriteTokens", Long.toString(cacheWriteTokens.get()));
            p.setProperty("estimatedInputTokens", Long.toString(estimatedInputTokens.get()));
            p.setProperty("currentContextTokens", Long.toString(currentContextTokens.get()));
            p.setProperty("contextWindowTokens", Long.toString(contextWindowTokens.get()));
            p.setProperty("compactions", Long.toString(compactions.get()));
            p.setProperty("estimatedTokensSavedByCompaction", Long.toString(estimatedTokensSavedByCompaction.get()));
            p.setProperty("prunedObservations", Long.toString(prunedObservations.get()));
            p.setProperty("estimatedTokensSavedByPruning", Long.toString(estimatedTokensSavedByPruning.get()));
            p.setProperty("repeatedCallsPrevented", Long.toString(repeatedCallsPrevented.get()));
            p.setProperty("totalToolActions", Long.toString(totalToolActions.get()));
            p.setProperty("lastActivityAt", lastActivityAt().toString());
            p.setProperty("lastCheckpointReason", lastCheckpointReason == null ? "" : lastCheckpointReason);
            p.setProperty("loopBlockReason", loopBlockReason == null ? "" : loopBlockReason);
            p.setProperty("objective", objective == null ? "" : objective);
            p.setProperty("originalTaskContract", originalTaskContract == null ? "" : originalTaskContract);
            p.setProperty("contextProfile", contextProfile);
            p.setProperty("evidenceReferences", evidenceReferences);
            p.setProperty("evidenceAssemblyMs", Long.toString(evidenceAssemblyMs.get()));
            p.setProperty("evidenceCharacters", Long.toString(evidenceCharacters.get()));
            p.setProperty("evidenceFiles", Long.toString(evidenceFiles.get()));
            p.setProperty("evidenceSymbols", Long.toString(evidenceSymbols.get()));
            p.setProperty("evidenceCacheHits", Long.toString(evidenceCacheHits.get()));
            p.setProperty("initialToolSchemas", Long.toString(initialToolSchemas.get()));
            p.setProperty("baselineToolSchemas", Long.toString(baselineToolSchemas.get()));
            p.setProperty("proactiveRetrievalDeferred", Long.toString(proactiveRetrievalDeferred.get()));
            p.setProperty("providerLatencyMs", Long.toString(providerLatencyMs.get()));
            p.setProperty("providerTimedCalls", Long.toString(providerTimedCalls.get()));
            stageTimings.store(p);
            p.setProperty("planLocked", Boolean.toString(planLocked));
            p.setProperty("largeTaskMode", Boolean.toString(largeTaskMode));
            p.setProperty("workItemBatchSize", Integer.toString(workItemBatchSize));
            p.setProperty("documentationMode", Boolean.toString(documentationMode));
            p.setProperty("documentationCoverageComplete", Boolean.toString(documentationCoverageComplete));
            p.setProperty("documentationValidated", Boolean.toString(documentationValidated));
            p.setProperty("documentationCoverageSummary", documentationCoverageSummary == null ? "" : documentationCoverageSummary);
            p.setProperty("documentationValidationSummary", documentationValidationSummary == null ? "" : documentationValidationSummary);
            p.setProperty("activePlanIndex", Integer.toString(activePlanIndex));
            p.setProperty("planStepToolActivity", Long.toString(planStepToolActivity.get()));
            p.setProperty("planStepStartMutationRevision", Long.toString(planStepStartMutationRevision.get()));
            p.setProperty("activeModelIndex", Integer.toString(activeModelIndex));
            p.setProperty("activeModel", activeModel == null ? "" : activeModel);
            p.setProperty("modelFailovers", Long.toString(modelFailovers.get()));
            p.setProperty("recoveryReplans", Long.toString(recoveryReplans.get()));
            p.setProperty("lastModelError", lastModelError == null ? "" : lastModelError);
            p.setProperty("lastRecoveryAnalysis", lastRecoveryAnalysis == null ? "" : lastRecoveryAnalysis);
            synchronized (this) {
                p.setProperty("modelPool.count", Integer.toString(modelPool.size()));
                for (int i = 0; i < modelPool.size(); i++) p.setProperty("modelPool." + i, modelPool.get(i));
                p.setProperty("failureMemory.count", Integer.toString(failureMemory.size()));
                int failureIndex = 0;
                for (String failure : failureMemory) p.setProperty("failureMemory." + failureIndex++, failure);
                p.setProperty("touchedPaths.count", Integer.toString(touchedPaths.size()));
                int touchedIndex = 0;
                for (String path : touchedPaths) p.setProperty("touchedPaths." + touchedIndex++, path);
                p.setProperty("workItems.count", Integer.toString(workItems.size()));
                int workItemIndex = 0;
                for (WorkItem item : workItems.values()) {
                    String wp = "workItems." + workItemIndex++ + ".";
                    p.setProperty(wp + "id", item.id());
                    p.setProperty(wp + "title", item.title());
                    p.setProperty(wp + "status", item.status());
                    p.setProperty(wp + "note", item.note());
                    p.setProperty(wp + "attempts", Integer.toString(item.attempts()));
                }
                p.setProperty("verificationFailures.count", Integer.toString(verificationFailureQueue.size()));
                int vfIndex = 0;
                for (String failure : verificationFailureQueue) p.setProperty("verificationFailures." + vfIndex++, failure);
                p.setProperty("plan.count", Integer.toString(plan.size()));
                for (int i = 0; i < plan.size(); i++) {
                    PlanItem item = plan.get(i);
                    String prefix = "plan." + i + ".";
                    p.setProperty(prefix + "text", item.text());
                    p.setProperty(prefix + "status", item.status());
                    p.setProperty(prefix + "note", item.note());
                    ArrayDeque<String> evidence = planEvidence.get(item.index());
                    int evidenceCount = evidence == null ? 0 : evidence.size();
                    p.setProperty(prefix + "evidence.count", Integer.toString(evidenceCount));
                    if (evidence != null) {
                        int evidenceIndex = 0;
                        for (String value : evidence) p.setProperty(prefix + "evidence." + evidenceIndex++, value);
                    }
                }
            }
            if (finishedAt != null) p.setProperty("finishedAt", finishedAt.toString());
            return p;
        }

        private static AgentRun fromProperties(Properties p, Consumer<AgentRun> persistHook,
                                               BiConsumer<String, ActivityEvent> activityPersistHook) {
            String id = p.getProperty("id", "").trim();
            if (id.isBlank()) return null;
            Instant created; try { created = Instant.parse(p.getProperty("createdAt")); } catch (Exception e) { created = Instant.now(); }
            AgentRun run = new AgentRun(id, emptyToNull(p.getProperty("conversationId")),
                    emptyToNull(p.getProperty("projectId")), created, persistHook, activityPersistHook);
            run.status = p.getProperty("status", "running");
            run.cancelled.set(Boolean.parseBoolean(p.getProperty("cancelled", "false")));
            setLong(run.mutationRevision, p, "mutationRevision", 0);
            setLong(run.verificationRequiredRevision, p, "verificationRequiredRevision", -1);
            setLong(run.lastVerificationAttemptRevision, p, "lastVerificationAttemptRevision", -1);
            setLong(run.verificationAttemptCount, p, "verificationAttemptCount", 0);
            setLong(run.lastSuccessfulVerificationRevision, p, "lastSuccessfulVerificationRevision", -1);
            setLong(run.lastDiffRevision, p, "lastDiffRevision", -1);
            run.lastVerificationSuccessful.set(Boolean.parseBoolean(p.getProperty("lastVerificationSuccessful", "false")));
            run.lastVerification = p.getProperty("lastVerification", "");
            setLong(run.progressPercent, p, "progressPercent", 2);
            run.progressPhase = p.getProperty("progressPhase", "starting");
            run.progressDetail = p.getProperty("progressDetail", "Preparing agent run");
            run.failureStage = p.getProperty("failureStage", "");
            run.responsePersisted.set(Boolean.parseBoolean(p.getProperty("responsePersisted", "false")));
            run.finalAnswer = p.getProperty("finalAnswer", "");
            run.assistantMessageId = p.getProperty("assistantMessageId", "");
            run.planValidationStatus = p.getProperty("planValidationStatus", "not_run");
            run.planValidationSummary = p.getProperty("planValidationSummary", "");
            int activityCount = 0;
            try { activityCount = Integer.parseInt(p.getProperty("activity.count", "0")); } catch (Exception ignored) { }
            for (int i = 0; i < Math.max(0, activityCount); i++) {
                ActivityEvent event = decodeActivity(p.getProperty("activity." + i, ""));
                if (event != null) run.activityEvents.addLast(event);
            }
            run.tokenActivity.restore(p);
            setLong(run.modelCalls, p, "modelCalls", 0); setLong(run.providerInputTokens, p, "providerInputTokens", 0);
            setLong(run.providerOutputTokens, p, "providerOutputTokens", 0); setLong(run.providerTotalTokens, p, "providerTotalTokens", 0);
            setLong(run.cachedInputTokens, p, "cachedInputTokens", 0); setLong(run.cacheWriteTokens, p, "cacheWriteTokens", 0);
            setLong(run.estimatedInputTokens, p, "estimatedInputTokens", 0); setLong(run.currentContextTokens, p, "currentContextTokens", 0);
            setLong(run.contextWindowTokens, p, "contextWindowTokens", 0); setLong(run.compactions, p, "compactions", 0);
            setLong(run.estimatedTokensSavedByCompaction, p, "estimatedTokensSavedByCompaction", 0);
            setLong(run.prunedObservations, p, "prunedObservations", 0);
            setLong(run.estimatedTokensSavedByPruning, p, "estimatedTokensSavedByPruning", 0);
            setLong(run.repeatedCallsPrevented, p, "repeatedCallsPrevented", 0);
            setLong(run.totalToolActions, p, "totalToolActions", 0);
            try { run.lastActivityAt = Instant.parse(p.getProperty("lastActivityAt", created.toString())); } catch (Exception ignored) { run.lastActivityAt = created; }
            run.lastCheckpointReason = p.getProperty("lastCheckpointReason", "");
            run.loopBlockReason = p.getProperty("loopBlockReason", "");
            run.objective = p.getProperty("objective", "");
            run.originalTaskContract = p.getProperty("originalTaskContract", run.objective);
            run.contextProfile = p.getProperty("contextProfile", "BALANCED");
            run.evidenceReferences = p.getProperty("evidenceReferences", "");
            setLong(run.evidenceAssemblyMs, p, "evidenceAssemblyMs", 0);
            setLong(run.evidenceCharacters, p, "evidenceCharacters", 0);
            setLong(run.evidenceFiles, p, "evidenceFiles", 0);
            setLong(run.evidenceSymbols, p, "evidenceSymbols", 0);
            setLong(run.evidenceCacheHits, p, "evidenceCacheHits", 0);
            setLong(run.initialToolSchemas, p, "initialToolSchemas", 0);
            setLong(run.baselineToolSchemas, p, "baselineToolSchemas", 0);
            setLong(run.proactiveRetrievalDeferred, p, "proactiveRetrievalDeferred", 0);
            setLong(run.providerLatencyMs, p, "providerLatencyMs", 0);
            setLong(run.providerTimedCalls, p, "providerTimedCalls", 0);
            run.stageTimings.restore(p);
            run.planLocked = Boolean.parseBoolean(p.getProperty("planLocked", "false"));
            run.largeTaskMode = Boolean.parseBoolean(p.getProperty("largeTaskMode", "false"));
            run.documentationMode = Boolean.parseBoolean(p.getProperty("documentationMode", "false"));
            run.documentationCoverageComplete = Boolean.parseBoolean(p.getProperty("documentationCoverageComplete", "false"));
            run.documentationValidated = Boolean.parseBoolean(p.getProperty("documentationValidated", "false"));
            run.documentationCoverageSummary = p.getProperty("documentationCoverageSummary", "");
            run.documentationValidationSummary = p.getProperty("documentationValidationSummary", "");
            try { run.workItemBatchSize = Math.max(3, Math.min(50, Integer.parseInt(p.getProperty("workItemBatchSize", "10")))); }
            catch (Exception ignored) { run.workItemBatchSize = 10; }
            try { run.activePlanIndex = Integer.parseInt(p.getProperty("activePlanIndex", "0")); } catch (Exception ignored) { run.activePlanIndex = 0; }
            setLong(run.planStepToolActivity, p, "planStepToolActivity", 0);
            setLong(run.planStepStartMutationRevision, p, "planStepStartMutationRevision", run.mutationRevision());
            try { run.activeModelIndex = Integer.parseInt(p.getProperty("activeModelIndex", "0")); } catch (Exception ignored) { run.activeModelIndex = 0; }
            run.activeModel = p.getProperty("activeModel", "");
            setLong(run.modelFailovers, p, "modelFailovers", 0);
            setLong(run.recoveryReplans, p, "recoveryReplans", 0);
            run.lastModelError = p.getProperty("lastModelError", "");
            run.lastRecoveryAnalysis = p.getProperty("lastRecoveryAnalysis", "");
            int modelCount; try { modelCount = Integer.parseInt(p.getProperty("modelPool.count", "0")); } catch (Exception ignored) { modelCount = 0; }
            for (int i = 0; i < Math.max(0, modelCount); i++) {
                String model = p.getProperty("modelPool." + i, "").strip();
                if (!model.isBlank()) run.modelPool.add(model);
            }
            if (run.activeModel.isBlank() && !run.modelPool.isEmpty()) {
                run.activeModelIndex = Math.max(0, Math.min(run.activeModelIndex, run.modelPool.size() - 1));
                run.activeModel = run.modelPool.get(run.activeModelIndex);
            }
            int failureCount;
            try { failureCount = Integer.parseInt(p.getProperty("failureMemory.count", "0")); } catch (Exception e) { failureCount = 0; }
            for (int i = 0; i < Math.min(8, Math.max(0, failureCount)); i++) {
                String value = p.getProperty("failureMemory." + i, "").strip();
                if (!value.isBlank()) run.failureMemory.addLast(value);
            }
            int touchedCount;
            try { touchedCount = Integer.parseInt(p.getProperty("touchedPaths.count", "0")); } catch (Exception e) { touchedCount = 0; }
            for (int i = 0; i < Math.max(0, touchedCount); i++) {
                String path = p.getProperty("touchedPaths." + i, "").strip();
                if (!path.isBlank()) run.touchedPaths.add(path);
            }
            int workItemCount;
            try { workItemCount = Integer.parseInt(p.getProperty("workItems.count", "0")); } catch (Exception e) { workItemCount = 0; }
            for (int i = 0; i < Math.max(0, workItemCount); i++) {
                String wp = "workItems." + i + ".";
                String idValue = p.getProperty(wp + "id", "").strip();
                String title = p.getProperty(wp + "title", "").strip();
                if (idValue.isBlank() || title.isBlank()) continue;
                String statusValue;
                try { statusValue = normalizeWorkItemStatus(p.getProperty(wp + "status", "pending")); } catch (Exception ignored) { statusValue = "pending"; }
                int attempts = 0; try { attempts = Integer.parseInt(p.getProperty(wp + "attempts", "0")); } catch (Exception ignored) { }
                run.workItems.put(idValue, new WorkItem(idValue, title, statusValue, p.getProperty(wp + "note", ""), Math.max(0, attempts)));
            }
            int vfCount;
            try { vfCount = Integer.parseInt(p.getProperty("verificationFailures.count", "0")); } catch (Exception e) { vfCount = 0; }
            for (int i = 0; i < Math.min(100, Math.max(0, vfCount)); i++) {
                String value = p.getProperty("verificationFailures." + i, "").strip();
                if (!value.isBlank()) run.verificationFailureQueue.addLast(value);
            }
            int planCount;
            try { planCount = Integer.parseInt(p.getProperty("plan.count", "0")); } catch (Exception e) { planCount = 0; }
            for (int i = 0; i < Math.max(0, planCount); i++) {
                String prefix = "plan." + i + ".";
                String text = p.getProperty(prefix + "text", "").strip();
                if (text.isBlank()) continue;
                String planStatus;
                try { planStatus = normalizePlanStatus(p.getProperty(prefix + "status", "pending")); } catch (Exception ignored) { planStatus = "pending"; }
                int restoredIndex = run.plan.size() + 1;
                run.plan.add(new PlanItem(restoredIndex, text, planStatus, p.getProperty(prefix + "note", "")));
                int evidenceCount;
                try { evidenceCount = Integer.parseInt(p.getProperty(prefix + "evidence.count", "0")); } catch (Exception ignored) { evidenceCount = 0; }
                if (evidenceCount > 0) {
                    ArrayDeque<String> evidence = new ArrayDeque<>();
                    for (int e = 0; e < Math.min(6, evidenceCount); e++) {
                        String value = p.getProperty(prefix + "evidence." + e, "").strip();
                        if (!value.isBlank()) evidence.addLast(value);
                    }
                    if (!evidence.isEmpty()) run.planEvidence.put(restoredIndex, evidence);
                }
            }
            String finished = p.getProperty("finishedAt", "");
            if (!finished.isBlank()) try { run.finishedAt = Instant.parse(finished); } catch (Exception ignored) { }
            return run;
        }

        private static void setLong(AtomicLong target, Properties p, String key, long fallback) {
            try { target.set(Long.parseLong(p.getProperty(key, Long.toString(fallback)))); } catch (Exception e) { target.set(fallback); }
        }
        private static String emptyToNull(String value) { return value == null || value.isBlank() ? null : value; }

        public Map<String, Object> snapshot() {
            Map<String, Object> map = new LinkedHashMap<>();
            map.put("id", id);
            map.put("conversationId", conversationId == null ? "" : conversationId);
            map.put("projectId", projectId == null ? "" : projectId);
            map.put("status", status);
            map.put("cancelled", cancelled());
            map.put("createdAt", createdAt.toString());
            if (finishedAt != null) map.put("finishedAt", finishedAt.toString());
            map.put("mutationRevision", mutationRevision());
            map.put("lastVerificationAttemptRevision", lastVerificationAttemptRevision());
            map.put("verificationAttemptCount", verificationAttemptCount());
            map.put("verificationRequiredRevision", verificationRequiredRevision());
            map.put("lastSuccessfulVerificationRevision", lastSuccessfulVerificationRevision());
            map.put("lastDiffRevision", lastDiffRevision());
            map.put("lastVerification", lastVerification);
            map.put("lastVerificationSuccessful", lastVerificationSuccessful());
            map.put("activeModel", activeModel());
            map.put("modelPool", modelPool());
            map.put("modelFailovers", modelFailovers());
            map.put("recoveryReplans", recoveryReplans());
            map.put("lastModelError", lastModelError());
            map.put("lastRecoveryAnalysis", lastRecoveryAnalysis());
            map.put("objective", objective());
            map.put("recoveredFromRunId", recoveredFromRunId());
            map.put("userInputs", userInputs().stream().map(UserInput::toMap).toList());
            map.put("planValidationStatus", planValidationStatus());
            map.put("planValidationSummary", planValidationSummary());
            map.put("largeTaskMode", largeTaskMode());
            map.put("workItemBatchSize", workItemBatchSize());
            map.put("documentationMode", documentationMode());
            map.put("documentationCoverageComplete", documentationCoverageComplete());
            map.put("documentationValidated", documentationValidated());
            map.put("documentationCoverageSummary", documentationCoverageSummary());
            map.put("documentationValidationSummary", documentationValidationSummary());
            map.put("workItemSummary", workItemSummary());
            map.put("workItems", workItemsSnapshot(200));
            map.put("verificationFailures", List.copyOf(verificationFailureQueue));
            map.put("activityEvents", activitySnapshot());
            map.put("touchedPaths", touchedPaths());
            map.put("activePlanIndex", activePlanIndex());
            map.put("planLocked", planLocked());
            map.put("planStepToolActivity", planStepToolActivity());
            map.put("progressPercent", progressPercent());
            map.put("progressPhase", progressPhase());
            map.put("progressDetail", progressDetail());
            map.put("failureStage", failureStage == null ? "" : failureStage);
            map.put("blockReason", loopBlockReason == null ? "" : loopBlockReason);
            map.put("lastActivityAt", lastActivityAt().toString());
            map.put("totalToolActions", totalToolActions());
            map.put("responsePersisted", responsePersisted());
            if (finished() && !finalAnswer().isBlank()) map.put("finalAnswer", finalAnswer());
            if (!assistantMessageId().isBlank()) map.put("assistantMessageId", assistantMessageId());
            Map<String,Object> usage = new LinkedHashMap<>();
            usage.put("contextProfile", contextProfile);
            usage.put("evidenceAssemblyMs", evidenceAssemblyMs.get());
            usage.put("evidenceCharacters", evidenceCharacters.get());
            usage.put("evidenceFiles", evidenceFiles.get());
            usage.put("evidenceSymbols", evidenceSymbols.get());
            usage.put("evidenceCacheHits", evidenceCacheHits.get());
            usage.put("initialToolSchemas", initialToolSchemas.get());
            usage.put("baselineToolSchemas", baselineToolSchemas.get());
            usage.put("proactiveRetrievalDeferred", proactiveRetrievalDeferred.get());
            usage.put("providerLatencyMs", providerLatencyMs.get());
            usage.put("providerTimedCalls", providerTimedCalls.get());
            usage.put("stageTimeMs", stageTimings.snapshot());
            usage.put("elapsedMs", Math.max(0, java.time.Duration.between(createdAt,
                    finishedAt == null ? java.time.Instant.now() : finishedAt).toMillis()));
            usage.put("engine", "legacy");
            usage.put("scope", "task");
            usage.put("model", activeModel == null ? "" : activeModel);
            usage.put("providerReported", tokenActivity.snapshot().stream().anyMatch(row ->
                    ((Number)row.getOrDefault("reportedCalls",0)).longValue() > 0));
            usage.put("reportedCalls", tokenActivity.snapshot().stream().mapToLong(row ->
                    ((Number)row.getOrDefault("reportedCalls",0)).longValue()).sum());
            usage.put("unreportedCalls", tokenActivity.snapshot().stream().mapToLong(row ->
                    ((Number)row.getOrDefault("unreportedCalls",0)).longValue()).sum());
            usage.put("usageStatus", ((Number)usage.get("reportedCalls")).longValue() == 0 ? "not_reported"
                    : ((Number)usage.get("unreportedCalls")).longValue() > 0 ? "partial" : "reported");
            usage.put("inputExcludesCache", false); // OpenAI ChatCompletions input normally includes cached input.
            usage.put("modelCalls", modelCalls.get());
            usage.put("activities", tokenActivity.snapshot());
            usage.put("modelCallBreakdown", tokenActivity.callSnapshot());
            usage.put("providerInputTokens", providerInputTokens.get());
            usage.put("providerOutputTokens", providerOutputTokens.get());
            usage.put("providerTotalTokens", providerTotalTokens.get());
            usage.put("cachedInputTokens", cachedInputTokens.get());
            usage.put("cacheWriteTokens", cacheWriteTokens.get());
            usage.put("estimatedInputTokens", estimatedInputTokens.get());
            usage.put("currentContextTokens", currentContextTokens.get());
            usage.put("contextWindowTokens", contextWindowTokens.get());
            usage.put("compactions", compactions.get());
            usage.put("estimatedTokensSavedByCompaction", estimatedTokensSavedByCompaction.get());
            usage.put("prunedObservations", prunedObservations.get());
            usage.put("estimatedTokensSavedByPruning", estimatedTokensSavedByPruning.get());
            long providerInput = providerInputTokens.get();
            usage.put("cacheHitPercent", providerInput <= 0 ? 0.0 : Math.min(100.0, (cachedInputTokens.get() * 100.0) / providerInput));
            usage.put("repeatedCallsPrevented", repeatedCallsPrevented.get());
            usage.put("toolActions", totalToolActions.get());
            usage.put("lastCheckpointReason", lastCheckpointReason);
            usage.put("loopBlockReason", loopBlockReason);
            map.put("tokenUsage", usage);
            map.put("approvedToolsForRun", List.copyOf(approvedToolsForRun));
            synchronized (this) {
                map.put("plan", planSnapshot());
            }
            return map;
        }

        private static String normalizePlanText(String raw) {
            if (raw == null) return "";
            String value = raw.strip();
            if (value.isBlank()) return "";
            value = value.replaceFirst("^\\d{1,2}[.)]\\s*", "");
            value = value.replaceFirst("^\\[[ xX✓✔]\\]\\s*", "");
            value = value.replaceFirst("^[\\-*•‣▪▫◦]+\\s*", "");
            value = value.replaceFirst("^(?:✅|☑️?|✔️?|✓|🔲|⬜|🟩|🟢|🔹|🔸|➡️?|→|➜|➤|▶️?|⏳|🛠️?|⚙️?)\\s*", "").strip();
            if (!value.matches("(?s).*[\\p{L}\\p{N}].*") || value.replaceAll("[^\\p{L}\\p{N}]", "").length() < 3) return "";
            return value.length() <= 1_400 ? value : value.substring(0, 1_400);
        }

        private static String normalizePlanStatus(String value) {
            String status = value == null ? "pending" : value.trim().toLowerCase(Locale.ROOT);
            return switch (status) {
                case "pending", "in_progress", "completed", "blocked", "skipped" -> status;
                default -> throw new IllegalArgumentException("Unsupported plan status: " + value);
            };
        }

        private static String encodeActivity(ActivityEvent event) {
            String raw = String.join("\u001f", event.at().toString(), Integer.toString(event.step()), safeActivity(event.tool()),
                    safeActivity(event.status()), safeActivity(event.detail()), safeActivity(event.args()),
                    safeActivity(event.approvalId()), safeActivity(event.output()),
                    safeActivity(event.approvalType()), safeActivity(event.approvalExpiresAt()));
            return Base64.getEncoder().encodeToString(raw.getBytes(StandardCharsets.UTF_8));
        }

        private static ActivityEvent decodeActivity(String encoded) {
            if (encoded == null || encoded.isBlank()) return null;
            try {
                String raw = new String(Base64.getDecoder().decode(encoded), StandardCharsets.UTF_8);
                String[] parts = raw.split("\u001f", -1);
                if (parts.length < 6) return null;
                // Backward compatible with the original 6-field encoding and the first durable-history 7-field encoding.
                if (parts.length == 6) {
                    return new ActivityEvent(Instant.parse(parts[0]), Integer.parseInt(parts[1]),
                            parts[2], parts[3], parts[4], "", "", parts[5], "", "");
                }
                if (parts.length == 7) {
                    return new ActivityEvent(Instant.parse(parts[0]), Integer.parseInt(parts[1]),
                            parts[2], parts[3], parts[4], parts[5], "", parts[6], "", "");
                }
                return new ActivityEvent(Instant.parse(parts[0]), Integer.parseInt(parts[1]),
                        parts[2], parts[3], parts[4], parts[5], parts[6], parts[7],
                        parts.length > 8 ? parts[8] : "", parts.length > 9 ? parts[9] : "");
            } catch (Exception ignored) { return null; }
        }

        private static String safeActivity(String value) { return value == null ? "" : value.replace("\u001f", " "); }

        private record ActivityEvent(Instant at, int step, String tool, String status, String detail, String args,
                                     String approvalId, String output, String approvalType, String approvalExpiresAt) { }

        private static void terminate(Process process) {
            if (process == null || !process.isAlive()) return;
            try {
                process.descendants().forEach(handle -> {
                    try { handle.destroy(); } catch (Exception ignored) { }
                });
                process.destroy();
                if (process.isAlive()) {
                    process.descendants().forEach(handle -> {
                        try { handle.destroyForcibly(); } catch (Exception ignored) { }
                    });
                    process.destroyForcibly();
                }
            } catch (Exception ignored) { }
        }
    }

    public record PlanItem(int index, String text, String status, String note) {}

    /**
     * Input the user typed while the Agent was running. It is delivered to the executor at the next turn boundary
     * (after the current action). status: pending -> delivered, or withdrawn by the user, or undelivered when the
     * run ended first (the UI then offers it as the next task).
     */
    public record UserInput(String id, String text, Instant submittedAt, String status, Instant deliveredAt,
                            String kind, String reply) {
        /**
         * kind (ELIYA184): refine (normal instruction), stop (stop + results so far), skip (skip the active step),
         * status (progress question answered at once). reply: what the runtime did or answered, for the UI.
         */
        public UserInput {
            kind = kind == null || kind.isBlank() ? "refine" : kind;
            reply = reply == null ? "" : reply;
        }

        public UserInput(String id, String text, Instant submittedAt, String status, Instant deliveredAt) {
            this(id, text, submittedAt, status, deliveredAt, "refine", "");
        }

        public Map<String,Object> toMap() {
            Map<String,Object> map = new LinkedHashMap<>();
            map.put("id", id);
            map.put("text", text);
            map.put("status", status);
            map.put("kind", kind);
            map.put("submittedAt", submittedAt.toString());
            if (deliveredAt != null) map.put("deliveredAt", deliveredAt.toString());
            if (!reply.isBlank()) map.put("reply", reply);
            return map;
        }
    }

    /**
     * Everything a linked recovery run needs from a terminated run so it continues instead of starting over:
     * the original task contract, the plan with step statuses and evidence, touched files and why it stopped.
     */
    public record RecoverySeed(String priorRunId, String conversationId, String projectId, String priorStatus,
                               String objective, String originalTaskContract, List<PlanItem> plan,
                               Map<Integer, List<String>> evidence, List<String> touchedPaths, String stoppingReason,
                               String lastVerification, Instant stagedAt) {
        /** Completed prefix that may be kept. The final step is always reopened so verification re-runs. */
        public int restorableCompletedSteps() {
            int count = 0;
            for (PlanItem item : plan) { if (!"completed".equals(item.status())) break; count++; }
            return Math.min(count, Math.max(0, plan.size() - 1));
        }
        public List<String> planTexts() { return plan.stream().map(PlanItem::text).toList(); }
    }
    public record WorkItem(String id, String title, String status, String note, int attempts) {}


    /**
     * ELIYA184: what a message typed while an Agent task runs is asking for.
     *
     * <p>Most messages refine the running task; they are delivered to the model after its current action. Some are
     * instructions to the runtime itself, and waiting for the current action (for example a long {@code git push} or a
     * test run) would make them useless:</p>
     * <ul>
     *   <li>{@link Kind#STOP_AND_REPORT}: "stop", "stop running the last instruction and show me the result so far",
     *       "abort", "that's enough" — interrupt the current action, end the run and show the results so far.</li>
     *   <li>{@link Kind#SKIP_STEP}: "skip this step", "stop the current step and continue" — interrupt the current
     *       action, mark the active plan step as skipped by the user and continue with the next one.</li>
     *   <li>{@link Kind#STATUS}: "status", "what are you doing?", "show me the progress" — answer at once with a progress
     *       snapshot; the task keeps running.</li>
     * </ul>
     * <p>Detection is deliberately conservative: conditional or behavioural instructions ("stop at the first failure",
     * "stop creating new files", "don't stop") stay refinements. Pure Java, no Spring.</p>
     */
    public static final class RunControl {
        public enum Kind { REFINE, STOP_AND_REPORT, SKIP_STEP, STATUS }

        private RunControl() { }

        private static final String STOP = "(?:stop|halt|abort|cancel|terminate|kill|end|quit|interrupt|pause)";
        private static final Pattern LEADING_FILLER = Pattern.compile(
                "^(?:please|pls|plz|kindly|ok(?:ay)?|hey|hi|eliya|now|just|so|then|and|but|wait|hold on|right|" +
                "can you|could you|would you|will you|can u|i want you to|i need you to|you can|you should|let'?s)[\\s,:;.!-]+");
        private static final Pattern STARTS_STOP = Pattern.compile("^" + STOP + "(?:ped|ping|s)?\\b\\s*(.*)$");
        private static final Pattern STOP_WORD = Pattern.compile("(?<!don't |dont |do not |never |not |without )\\b" + STOP + "\\b");
        private static final Pattern NEGATED = Pattern.compile(
                "^(?:don'?t|do not|never|no need to|not|without)\\s+(?:" + STOP + "|skip)\\b");
        // "stop at the first failure", "stop when tests pass", "stop running tests after each edit": a rule for the task.
        private static final Pattern QUALIFIED = Pattern.compile(
                "\\b(?:at|after|before|when|whenever|if|unless|until|once|every|each|again|anymore|any more|whenever|instead|" +
                "first time|for (?:each|every)|as soon as)\\b");
        private static final Pattern CONTINUE = Pattern.compile(
                "\\b(?:and|then|&)?\\s*(?<!don't |dont |do not |never |not )(?:continue|proceed|move on|go on|carry on|keep going|" +
                "go ahead|do the rest|(?:go|jump|skip) to the next|with the next|next step|rest of the (?:steps|plan|task))\\b");
        private static final Pattern NO_CONTINUE = Pattern.compile(
                "\\b(?:don'?t|do not|never|not)\\s+(?:continue|proceed|go on|carry on|go ahead|do anything else|do more)\\b");
        private static final Pattern REPORT = Pattern.compile(
                "\\b(?:show|give|tell|send|display|print|share|report|summari[sz]e|list|return)\\b(?:\\s+[\\w'-]+){0,5}?\\s+" +
                "(?:result|results|output|outputs|summary|status|progress|findings|work|changes|outcome)\\b" +
                "|\\b(?:so far|till now|until now|up to now|up till now|till date|till execution|until execution|" +
                "till the execution|until the execution|till here|up to here|up to this point|till this point|" +
                "what (?:you|u) (?:have|did|got|found|completed)|what(?:'s| is| has been) (?:done|completed))\\b" +
                "|\\b(?:last|latest|current|partial) (?:result|results|output|outputs|status)\\b");
        private static final Pattern FILLERS_ONLY = Pattern.compile(
                "^(?:(?:it|this|that|now|right now|immediately|everything|all|all of it|here|there|for now|please|" +
                "the task|this task|the run|this run|the agent|the execution|execution|the process|the job|the work|" +
                "working|the whole thing|everything now|asap|at once)\\s*)*$");
        private static final Pattern RUNNING_OBJECT = Pattern.compile("^(?:running|executing|doing|working on|processing)\\b.*$");
        private static final Pattern ACTIVITY_GERUND = Pattern.compile(
                "^(?:pushing|building|testing|deploying|installing|downloading|cloning|uploading|scanning|indexing|" +
                "migrating|compiling|committing|fetching|pulling|syncing)\\b");
        private static final Pattern DETERMINER_ACTIVITY = Pattern.compile(
                "^(?:the|this|that|current|currently|last|latest|ongoing|active|running|present)\\b(?:\\s+[\\w./:-]+){0,4}?\\s*" +
                "(?:step|command|instruction|action|task|process|operation|job|execution|run|script|push|build|tests?|" +
                "deploy(?:ment)?|install(?:ation)?|download|clone|upload|scan|migration|request|call|thing|one|work)" +
                "(?:\\s+(?:now|please|immediately|right now))*$");
        private static final Pattern CURRENT_ACTION = Pattern.compile(
                "^(?:it|this|that|(?:running |executing |doing )?(?:it|this|that)|" +
                "(?:running |executing |doing )?(?:the |this |that )?(?:current|currently running|last|latest|running|active|ongoing)?\\s*" +
                "(?:[\\w./:-]+\\s+){0,3}?(?:step|command|instruction|action|task|operation|job|one|part|process|push|build|tests?))\\b.*$");
        private static final Pattern SKIP = Pattern.compile("^skip\\b\\s*(.*)$");
        private static final Pattern SKIP_OBJECT = Pattern.compile(
                "^(?:(?:it|this|that)(?:\\s+(?:one|step|command|part))?|" +
                "(?:the |this |that )?(?:current|currently running|running|active|last|latest|ongoing)?\\s*(?:[\\w./:-]+\\s+){0,3}?" +
                "(?:step|command|instruction|action|task|operation|job|one|part|push|build)|step\\s*#?\\d{1,3})" +
                "(?:\\s+(?:now|please|and (?:continue|proceed|move on|go on|carry on)(?: with the (?:rest|next(?: step)?))?))*$|^$");
        private static final Pattern MOVE_ON = Pattern.compile(
                "^(?:move on|go to the next step|proceed to the next step|continue with the next step|jump to the next step|" +
                "next step(?: please)?|move to the next step|go on to the next step)\\b.*$");
        private static final Pattern ENOUGH = Pattern.compile(
                "^(?:that'?s enough|that is enough|enough|enough for now|wrap (?:it )?up|stop here|no more|" +
                "don'?t continue|do not continue|leave it (?:here|there)|that will do|that'?ll do)$");
        private static final Pattern STATUS = Pattern.compile(
                "^(?:status|progress|update|status update|any update|any progress|" +
                "what(?:'s| is) (?:the )?(?:status|progress)|where are (?:you|we)(?: now)?|" +
                "what are you (?:doing|working on)(?: now| right now)?|what is happening|what'?s happening|" +
                "how far (?:are you|along are you|along)|how is it going|how'?s it going|" +
                "(?:show|give|tell)(?: me)?(?: the| a)? (?:progress|status|update))" +
                "(?:\\s+(?:now|please|so far|till now|until now|right now|update|report|of the (?:task|run)|on the (?:task|run)))*$");
        // "show me the results so far", "what have you done so far": a progress question, not a change request.
        private static final Pattern STATUS_QUESTION = Pattern.compile(
                "^(?:(?:show|give|tell)(?: me)?(?:\\s+[\\w'-]+){0,3}?\\s+(?:result|results|output|outputs|summary|status|progress|findings|work|changes|outcome)" +
                "(?:\\s+(?:so far|till now|until now|up to now|up till now|now|please|of the (?:task|run)))*" +
                "|.*\\b(?:so far|till now|until now|up to now|up till now)|what (?:have you|did you) (?:done|do|completed|finish(?:ed)?)(?: so far| till now| until now)?)$");
        private static final Pattern STEP_NUMBER = Pattern.compile("\\bstep\\s*#?(\\d{1,3})\\b");

        /** Classify one input typed during a running task. */
        public static Kind classify(String text) {
            String norm = normalize(text);
            if (norm.isEmpty() || norm.length() > 400) return Kind.REFINE;
            if (NEGATED.matcher(norm).find()) return Kind.REFINE;
            int words = norm.split("\\s+").length;

            Matcher skip = SKIP.matcher(norm);
            if (skip.matches() && SKIP_OBJECT.matcher(skip.group(1).strip()).matches()) return Kind.SKIP_STEP;
            if (MOVE_ON.matcher(norm).matches() && words <= 8) return Kind.SKIP_STEP;

            boolean report = REPORT.matcher(norm).find();
            boolean refusesToContinue = NO_CONTINUE.matcher(norm).find();
            boolean continues = !refusesToContinue && CONTINUE.matcher(norm).find();
            Matcher stop = STARTS_STOP.matcher(norm);
            if (stop.matches()) {
                String rest = stop.group(1).strip();
                if (refusesToContinue) return Kind.STOP_AND_REPORT;
                String object = continues ? CONTINUE.split(rest, 2)[0].replaceAll("[\\s,;]+$", "").strip() : rest;
                if (continues && !report) {
                    // "stop the current step and continue": skip; "stop and continue" alone is not a stop either.
                    return object.isEmpty() || CURRENT_ACTION.matcher(object).matches() ? Kind.SKIP_STEP : Kind.REFINE;
                }
                if (report) return Kind.STOP_AND_REPORT;
                if (QUALIFIED.matcher(rest).find()) return Kind.REFINE;
                if (FILLERS_ONLY.matcher(rest).matches()) return Kind.STOP_AND_REPORT;
                int restWords = rest.isEmpty() ? 0 : rest.split("\\s+").length;
                if (RUNNING_OBJECT.matcher(rest).matches() && restWords <= 7) return Kind.STOP_AND_REPORT;
                if (ACTIVITY_GERUND.matcher(rest).find() && restWords <= 3) return Kind.STOP_AND_REPORT;
                if (DETERMINER_ACTIVITY.matcher(rest).matches() && restWords <= 6) return Kind.STOP_AND_REPORT;
                return Kind.REFINE;
            }
            if (report && STOP_WORD.matcher(norm).find() && !continues) return Kind.STOP_AND_REPORT;
            if (ENOUGH.matcher(norm).matches()) return Kind.STOP_AND_REPORT;
            if (!STOP_WORD.matcher(norm).find() && words <= 12 &&
                    (STATUS.matcher(norm).matches() || (report && STATUS_QUESTION.matcher(norm).matches())))
                return Kind.STATUS;
            return Kind.REFINE;
        }

        private static final Pattern RESUME = Pattern.compile(
                "^(?:continue|resume|go on|carry on|proceed|keep going|continue please|please continue)" +
                "(?:\\s+(?:the task|the run|the work|with the task|with the rest|from where (?:you|it) stopped|from where you left off|" +
                "where you left off|where you stopped|from step\\s*#?\\d{1,3}|from the last step|now))*$");

        /** A short, explicit request to resume the task that was just stopped ("continue", "resume from step 4"). */
        public static boolean isResume(String text) {
            String norm = normalize(text);
            return !norm.isEmpty() && norm.length() <= 80 && RESUME.matcher(norm).matches();
        }

        /** Step number named in a skip request ("skip step 3"), or 0 when none is named. */
        public static int namedStep(String text) {
            Matcher m = STEP_NUMBER.matcher(normalize(text));
            return m.find() ? Integer.parseInt(m.group(1)) : 0;
        }

        /** Short user-facing label for a kind. */
        public static String label(Kind kind) {
            return switch (kind) {
                case STOP_AND_REPORT -> "stop";
                case SKIP_STEP -> "skip";
                case STATUS -> "status";
                default -> "refine";
            };
        }

        static String normalize(String text) {
            if (text == null) return "";
            String value = text.toLowerCase(Locale.ROOT)
                    .replace('’', '\'').replace('‘', '\'').replace('“', '"').replace('”', '"')
                    .replace('–', '-').replace('—', '-')
                    .replaceAll("[\"`*_]", " ")
                    .replaceAll("\\s+", " ").strip();
            value = value.replaceAll("^/+", "").replaceAll("[.!?\\s]+$", "").strip();
            for (int i = 0; i < 5; i++) {
                String next = LEADING_FILLER.matcher(value).replaceFirst("").strip();
                if (next.equals(value)) break;
                value = next;
            }
            return value;
        }
    }

    /**
     * ELIYA184: what the user sees when they stop a running Agent task ("stop … show me the results so far", the Stop
     * button or Ctrl+C), and the immediate answer to "status" while it runs. Built only from the run's recorded state —
     * plan steps, tool events and their real output, touched files, verification — never from a model call, so it is
     * instant and cannot invent results.
     */
    public static final class StopReport {
        private StopReport() { }

        private static final int OUTPUT_LINES = 25;
        private static final int OUTPUT_CHARS = 1_600;

        /** Final conversation answer after a user stop. */
        public static String render(AgentRun run) {
            StringBuilder out = new StringBuilder("## Stopped at your request — results so far\n\n");
            String instruction = run.stopInstruction();
            if (!instruction.isBlank()) out.append("> ").append(oneLine(instruction, 300)).append("\n\n");

            List<Map<String,Object>> events = run.recentActivity(60);
            List<Map<String,Object>> plan = run.planSnapshot();
            String running = runningAction(run, events);
            if (!running.isBlank()) out.append("**Was running:** ").append(running).append(" — interrupted, not finished.\n\n");

            out.append("### Plan progress\n\n");
            if (plan.isEmpty()) out.append("No plan steps were recorded before the stop.\n\n");
            else {
                for (Map<String,Object> row : plan) out.append(planLine(row, true)).append('\n');
                out.append('\n');
            }

            List<Map<String,Object>> results = latestResults(events, 2);
            if (!results.isEmpty()) {
                out.append("### Latest results\n\n");
                for (Map<String,Object> event : results) {
                    out.append("**`").append(text(event, "tool")).append("`** · ")
                            .append(oneLine(firstNonBlank(text(event, "detail"), text(event, "args")), 200))
                            .append(" — ").append(statusWord(text(event, "status"))).append("\n\n");
                    String output = tail(text(event, "output"));
                    if (!output.isBlank()) out.append("```text\n").append(output).append("\n```\n\n");
                }
            }

            List<String> files = run.touchedPaths();
            out.append("### Changes so far\n\n");
            if (files.isEmpty()) out.append("No workspace files were changed.\n\n");
            else {
                for (int i = 0; i < Math.min(files.size(), 15); i++)
                    out.append("- `").append(files.get(i).replace("`", "")).append("`\n");
                if (files.size() > 15) out.append("- … and ").append(files.size() - 15).append(" more\n");
                out.append('\n');
            }

            String verification = run.lastVerification();
            boolean verified = run.lastVerificationSuccessful() && run.verifiedCurrentRevision();
            out.append("**Verification:** ");
            if (verification == null || verification.isBlank())
                out.append(run.mutationRevision() > 0 ? "not run on the latest changes." : "nothing to verify yet.");
            else out.append(oneLine(verification, 300)).append(verified ? " (passed on the latest changes)." :
                    " (not confirmed for the latest changes).");
            out.append("\n\n");

            int resumeStep = firstOpenStep(plan);
            out.append("Nothing was rolled back. ");
            if (resumeStep > 0) out.append("Say **continue** to resume from step ").append(resumeStep)
                    .append(", or describe what to do instead.");
            else out.append("Describe the next task, or say **continue** to pick the work up again.");
            return out.toString().strip();
        }

        /** Immediate answer to "status" / "what are you doing?" while the task keeps running. */
        public static String progress(AgentRun run) {
            StringBuilder out = new StringBuilder();
            long seconds = Math.max(0, Duration.between(run.createdAt(), Instant.now()).getSeconds());
            out.append("Running for ").append(duration(seconds));
            String detail = run.progressDetail();
            if (!detail.isBlank()) out.append(" · now: ").append(oneLine(detail, 160));
            out.append('\n');
            List<Map<String,Object>> plan = run.planSnapshot();
            for (Map<String,Object> row : plan) out.append(planLine(row, false).replace("**", "")).append('\n');
            List<Map<String,Object>> results = latestResults(run.recentActivity(40), 1);
            if (!results.isEmpty()) {
                Map<String,Object> last = results.get(0);
                out.append("Last result: ").append(text(last, "tool")).append(" · ")
                        .append(oneLine(firstNonBlank(text(last, "detail"), text(last, "args")), 160))
                        .append(" (").append(statusWord(text(last, "status"))).append(")\n");
            }
            int files = run.touchedPaths().size();
            out.append(files == 0 ? "No files changed yet." : files + " file(s) changed so far.");
            out.append(" Type \"stop\" to stop and see the results so far, or \"skip this step\" to move on.");
            return out.toString().strip();
        }

        private static String planLine(Map<String,Object> row, boolean withEvidence) {
            String status = text(row, "status");
            String note = text(row, "note");
            String icon = switch (status) {
                case "completed" -> "✅";
                case "in_progress" -> "⏹";
                case "skipped" -> "⏭";
                case "blocked", "failed" -> "⚠";
                default -> "⬜";
            };
            String label = switch (status) {
                case "completed" -> "";
                case "in_progress" -> withEvidence ? " — stopped while running" : " — in progress";
                case "skipped" -> " — skipped";
                case "blocked", "failed" -> " — " + status;
                default -> " — not started";
            };
            StringBuilder line = new StringBuilder("- ").append(icon).append(" **Step ").append(text(row, "index")).append("** · ")
                    .append(oneLine(text(row, "text"), 140)).append(label);
            if (withEvidence && "completed".equals(status) && !note.isBlank()) line.append(" — ").append(oneLine(note, 160));
            if (withEvidence && "skipped".equals(status) && !note.isBlank()) line.append(" (").append(oneLine(note, 120)).append(')');
            return line.toString();
        }

        private static int firstOpenStep(List<Map<String,Object>> plan) {
            for (Map<String,Object> row : plan) {
                String status = text(row, "status");
                if (!"completed".equals(status) && !"skipped".equals(status)) {
                    try { return Integer.parseInt(text(row, "index")); } catch (NumberFormatException ignored) { return 0; }
                }
            }
            return 0;
        }

        /** The action in flight when the stop arrived: the newest "running" tool event, else the recorded activity. */
        private static String runningAction(AgentRun run, List<Map<String,Object>> events) {
            for (int i = events.size() - 1; i >= 0; i--) {
                Map<String,Object> event = events.get(i);
                String status = text(event, "status");
                if (!"running".equals(status) && !"started".equals(status)) continue;
                if (finishedLater(events, i)) break;
                String tool = text(event, "tool");
                if (ignoredTool(tool)) continue;
                String what = oneLine(firstNonBlank(text(event, "args"), text(event, "detail")), 180);
                String elapsed = "";
                try {
                    Instant at = Instant.parse(text(event, "at"));
                    Instant end = run.stopRequestedAt() == null ? Instant.now() : run.stopRequestedAt();
                    elapsed = " (" + duration(Math.max(0, Duration.between(at, end).getSeconds())) + ")";
                } catch (Exception ignored) { }
                String step = run.activePlanIndex() > 0 ? "Step " + run.activePlanIndex() + " · " : "";
                return step + "`" + tool + "` " + what + elapsed;
            }
            String fallback = firstNonBlank(run.stopActiveAction(), run.progressDetail());
            if (fallback.isBlank() || fallback.toLowerCase(Locale.ROOT).startsWith("stopping")) return "";
            return (run.activePlanIndex() > 0 ? "Step " + run.activePlanIndex() + " · " : "") + oneLine(fallback, 200);
        }

        private static boolean finishedLater(List<Map<String,Object>> events, int index) {
            String tool = text(events.get(index), "tool");
            for (int j = index + 1; j < events.size(); j++) {
                Map<String,Object> later = events.get(j);
                if (tool.equals(text(later, "tool")) && !"running".equals(text(later, "status"))) return true;
            }
            return false;
        }

        /** Newest completed tool events that carry real output (or at least a result), newest last. */
        private static List<Map<String,Object>> latestResults(List<Map<String,Object>> events, int max) {
            List<Map<String,Object>> picked = new ArrayList<>();
            for (int i = events.size() - 1; i >= 0 && picked.size() < max; i--) {
                Map<String,Object> event = events.get(i);
                String status = text(event, "status");
                if (!"success".equals(status) && !"error".equals(status) && !"completed".equals(status) && !"failed".equals(status)) continue;
                if (ignoredTool(text(event, "tool"))) continue;
                if (text(event, "output").isBlank() && text(event, "detail").isBlank()) continue;
                picked.add(0, event);
            }
            return picked;
        }

        private static boolean ignoredTool(String tool) {
            String t = tool == null ? "" : tool.toLowerCase(Locale.ROOT);
            return t.isBlank() || t.equals("user_input") || t.equals("run_cancelled") || t.startsWith("plan") ||
                    t.equals("todo_update") || t.equals("todoread") || t.equals("agent_transport") || t.equals("workspace_index") ||
                    t.equals("workspace_resolution") || t.equals("protected_snapshot") || t.equals("model_route") ||
                    t.equals("context") || t.endsWith("_checkpoint") || t.equals("flow_discovery") || t.equals("test_preflight");
        }

        private static String tail(String output) {
            if (output == null || output.isBlank()) return "";
            String clean = output.replace("\r\n", "\n").replace("```", "'''").strip();
            String[] lines = clean.split("\n");
            int from = Math.max(0, lines.length - OUTPUT_LINES);
            StringBuilder out = new StringBuilder();
            if (from > 0) out.append("…\n");
            for (int i = from; i < lines.length; i++) out.append(lines[i]).append('\n');
            String text = out.toString().strip();
            return text.length() > OUTPUT_CHARS ? "…" + text.substring(text.length() - OUTPUT_CHARS) : text;
        }

        private static String statusWord(String status) {
            return switch (status == null ? "" : status) {
                case "success", "completed" -> "finished";
                case "error", "failed" -> "failed";
                default -> status == null || status.isBlank() ? "recorded" : status;
            };
        }

        static String duration(long seconds) {
            if (seconds < 60) return seconds + "s";
            if (seconds < 3600) return (seconds / 60) + "m " + (seconds % 60) + "s";
            return (seconds / 3600) + "h " + ((seconds % 3600) / 60) + "m";
        }

        private static String text(Map<String,Object> row, String key) {
            Object value = row == null ? null : row.get(key);
            return value == null ? "" : String.valueOf(value);
        }

        private static String firstNonBlank(String a, String b) { return a != null && !a.isBlank() ? a : b == null ? "" : b; }

        private static String oneLine(String value, int max) {
            String line = value == null ? "" : value.replaceAll("\\s+", " ").strip();
            return line.length() > max ? line.substring(0, max - 1) + "…" : line;
        }
    }
}
