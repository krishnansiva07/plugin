---
name: test-driven
description: Red-green-refactor - prove a bug or new behaviour with a failing test, make it pass minimally, clean up. Use for bug fixes and new behaviour.
aliases: [tdd, test-driven-development, red-green-refactor]
triggers: [fix the bug, failing tests, test driven development]
verification: [workspace]
---

# Test-driven (test-driven)

## Cycle

1. **Find the test setup:** `test_profile` (runner, suites, profiles), existing tests near the code, naming style.
2. **Red** — write the smallest test that expresses the behaviour (for a bug: reproduces it). Run only that test
   and confirm it fails **for the right reason** (assertion, not a compile error or missing fixture).
3. **Green** — make the minimal code change that passes it. Run the test again.
4. **Refactor** — tidy names and duplication in both code and test while everything stays green.
5. **Widen** — run the module's or project's suite to catch regressions.

## Rules

- Never weaken an assertion, skip/disable a test (`@Disabled`, `.skip`, `-DskipTests`, `-x test`) or delete a test to
  get green — unless the user explicitly asks; then say so in the result.
- Test behaviour through public interfaces, not private internals.
- One reason to fail per test; descriptive names (`rejectsZeroQuantity`, `retriesThreeTimesOnTimeout`).
- Deterministic: no real network, clock or random values without control; no order dependence.
- If something cannot be tested automatically (UI look, external system), state the manual check instead of
  pretending a test covers it.

## Report

Test(s) added, the failing-then-passing evidence (command + result), and the final suite result.
