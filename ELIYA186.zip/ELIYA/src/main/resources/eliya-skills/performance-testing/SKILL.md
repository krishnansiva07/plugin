---
name: performance-testing
description: Plan or execute authorized performance tests with measurable workload and limits.
triggers: [performance testing, load testing, performance test plan]
---

# Performance Testing

## Workflow

Define realistic workload, baseline, latency percentiles, throughput, error rates and resource constraints. Use only approved non-production targets and load limits; collect actual results if authorized. Explain variability and bottlenecks; never invent performance figures.

## Outcome

Give the requested deliverable, factual evidence, verification status, limitations and any next action. User intent and runtime permission boundaries take precedence.
