---
name: test-reporting
description: Consolidate actual test execution evidence into clear QA reports.
triggers: [test reporting, test execution report, regression report]
---

# Test Reporting

## Workflow

Use runner results, timestamps and environment details. Distinguish total, passed, failed, skipped and unknown counts; avoid double-counting reruns. Link findings to suites and evidence. Validate requested report artifacts and disclose missing sources.

## Outcome

Give the requested deliverable, factual evidence, verification status, limitations and any next action. User intent and runtime permission boundaries take precedence.
