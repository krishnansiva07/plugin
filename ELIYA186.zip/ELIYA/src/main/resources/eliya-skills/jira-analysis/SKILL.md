---
name: jira-analysis
description: Analyse Jira requirements and traceable coverage using authorized evidence only.
triggers: [jira story analysis, jira requirements, jira test coverage]
---

# Jira Analysis

## Workflow

Use attached or already supplied story details. Use Jira MCP only when explicitly requested and enabled by the user. Extract acceptance criteria, dependencies, gaps and test coverage with issue IDs. Do not invent unavailable fields or mutate Jira without authorization.

## Outcome

Give the requested deliverable, factual evidence, verification status, limitations and any next action. User intent and runtime permission boundaries take precedence.
