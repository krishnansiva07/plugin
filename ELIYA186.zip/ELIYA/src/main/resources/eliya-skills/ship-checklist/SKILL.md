---
name: ship-checklist
description: Pre-merge and release checklist - full verification, changelog, config, rollback plan, then git steps with approval. Use for 'ship it' or 'release'.
aliases: [ship, release, shipping]
triggers: [release readiness, prepare for release, package the application, ship it]
verification: [workspace]
---

# Ship checklist (ship-checklist)

## Before anything leaves the machine

1. **Clean state:** `git status` — only intended changes; no debug code, secrets, large binaries or local config.
2. **Full verification:** the project's complete build and test command (not only the tests you touched); lint or
   type checks if the project has them. Record the exact command and result.
3. **Review:** run `code-review` on the diff (`git diff main...HEAD` or `workspace_diff`).
4. **Release notes / changelog** entry in the project's existing format; version bump only if the project versions
   releases that way.
5. **Config & data:** new settings documented with safe defaults; database migrations reversible or with a backup
   step; feature flags default to off when the change is risky.
6. **Rollback plan:** one or two lines — how to revert (revert commit, flag off, previous artifact).

## Git and remote steps

- Show the summary (branch, commits, files, verification) and **ask before** `git commit`, `git push`, creating a
  pull request (`gh pr create --fill` or with `--title/--body`) or deploying. ELIYA's command policy asks for these
  anyway; never bypass it.
- Non-interactive commands only: pass messages and titles as arguments; a command that waits for a terminal prompt
  will hang. If authentication is missing, stop and tell the user what to run themselves.
- If a remote step fails, report the exact error; do not retry with force options (`--force`, `--no-verify`) unless
  the user explicitly asks.

## Report

Checklist with ✓/✗ per item, the verification evidence, what was pushed or opened (links/ids), and the rollback
plan.
