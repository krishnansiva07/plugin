---
name: playwright-automation
description: Develop maintainable Playwright TypeScript automation using existing fixtures and runner.
triggers: [playwright automation, playwright tests, typescript playwright]
---

# Playwright Automation

## Workflow

Inspect package scripts, Playwright configuration, fixtures, locators, storage state and reporters. Reuse existing conventions and web-first assertions. Preserve scope and browser settings; run targeted tests when authorized, capture actual runner output and report failures.

## Outcome

Give the requested deliverable, factual evidence, verification status, limitations and any next action. User intent and runtime permission boundaries take precedence.
