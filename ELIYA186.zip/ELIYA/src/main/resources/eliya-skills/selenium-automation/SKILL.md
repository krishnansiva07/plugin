---
name: selenium-automation
description: Develop and maintain Java Selenium UI automation in an existing framework.
triggers: [selenium automation, selenium scripts, selenium tests, java selenium]
---

# Selenium Automation

## Workflow

Inspect runner, hooks, page objects, locators, waits, data and Grid settings. Reuse existing abstractions; use explicit condition-based waits and stable locators. Make minimal changes for execution requests, then run relevant tests and report actual counts. For analysis, only propose changes.

## Outcome

Give the requested deliverable, factual evidence, verification status, limitations and any next action. User intent and runtime permission boundaries take precedence.
