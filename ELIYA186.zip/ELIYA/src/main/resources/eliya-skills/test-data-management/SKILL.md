---
name: test-data-management
description: Manage deterministic test data, privacy, environment isolation and cleanup.
triggers: [test data management, generate test data, test data strategy]
---

# Test Data Management

## Workflow

Inspect data schemas, fixtures, sources and lifecycle. Prefer synthetic, reproducible data and safe cleanup; never disclose credentials or personal records. Check constraints, isolation and traceability; report environment assumptions.

## Outcome

Give the requested deliverable, factual evidence, verification status, limitations and any next action. User intent and runtime permission boundaries take precedence.
