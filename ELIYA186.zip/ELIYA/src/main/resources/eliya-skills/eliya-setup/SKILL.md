---
name: eliya-setup
description: Recommend the best ELIYA setup for this project (AGENTS.md, command policy, MCP servers, skills, verification). Read-only. Use for 'set up ELIYA'.
aliases: [claude-code-setup, setup, automation-recommender, recommend-automations]
triggers: [set up eliya, configure eliya for this project]
---

# Recommend an ELIYA setup for this project (eliya-setup)

Read-only analysis. Do not create or change files unless the user then asks you to apply a recommendation.

## 1. Look at the project (evidence, not guesses)

- `inspect_workspace` and `workspace_profile`: languages, build tools, descriptors.
- Build and test entry points: `pom.xml`, `build.gradle*`, `package.json` scripts, `pyproject.toml`, `Makefile`,
  `test_profile` for the real test runner and suites.
- Existing ELIYA/agent config: `AGENTS.md`, `CLAUDE.md`, `.agents/skills/`, `.claude/skills/`, `.opencode/`,
  `mcp_status`, `~/.eliya/policy.json` (if readable), CI files (`.github/workflows/`, `Jenkinsfile`).
- Signals: UI/browser tests (Playwright, Selenium, Cypress), external services (databases, Jira, GitHub),
  generated folders, secrets/config that must not be touched, repository size.

## 2. Recommend the top 1–2 items per category (only where the evidence supports it)

| Category | What to recommend |
|---|---|
| **Project instructions** (`AGENTS.md`) | exact build/test commands, folders never to edit, coding conventions, "definition of done" |
| **Command policy** (`~/.eliya/policy.json`) | allow safe read/test commands, ask for `git push`/deploy, deny destructive ones |
| **MCP servers** (`mcp_configure`) | Playwright MCP for UI tests, Chrome DevTools for front-end debugging, others only with a real need |
| **Project skills** (`.agents/skills/<name>/SKILL.md`) | repeated workflows seen in the repo (release notes, migration steps, test-data setup) |
| **Verification** | the single command that proves a change works (and a faster targeted one) |
| **Unattended runs** (`eliya run`) | recurring, low-risk tasks that suit an isolated branch (dependency bumps, flaky-test triage) |
| **Built-in skills** | which of `code-review`, `test-driven`, `spec-first`, `anydoc`, `eliya-mem` fit this team |

## 3. Report

For each recommendation give: **what**, **why (the file or signal you saw)**, **how to apply** (the exact file
content or command), and **effort**. Order by value. End with: "Say which ones to apply and I'll make the changes."
Ask for more options in one category ("what MCP servers?") to list 3–5 there.
