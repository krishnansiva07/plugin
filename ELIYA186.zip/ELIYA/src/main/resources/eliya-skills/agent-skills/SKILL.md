---
name: agent-skills
description: Engineering lifecycle for code changes (spec, plan, build, test, review, simplify, ship) and which skill fits each phase. Use for feature work.
aliases: [lifecycle, engineering-lifecycle, addy-agent-skills]
triggers: [engineering lifecycle, implement a new feature]
---

# Engineering lifecycle (agent-skills)

Follow the phase that matches the request; load its skill with `skill` when you need the details.

| Phase | Skill | Slash command | Use when |
|---|---|---|---|
| Define | `spec-first` | `/spec` | new feature or significant change; requirements are fuzzy |
| Plan | `task-breakdown` | `/plan` | you have a spec and need small, verifiable tasks |
| Build | `incremental-build` | `/build` | implementing: one thin, working slice at a time |
| Test | `test-driven` | `/tdd` | fixing a bug or adding behaviour — prove it with a test |
| Review | `code-review` | `/review` | before merging anything; reviewing your own or others' changes |
| Simplify | `simplify-code` | `/simplify` | working code that is harder to read than it needs to be |
| Ship | `ship-checklist` | `/ship` | preparing a release, merge or deployment |

## Routing

- New functionality → `spec-first`, then `task-breakdown`, then `incremental-build` + `test-driven`.
- Bug → `test-driven` (reproduce with a failing test first), then `code-review`.
- "Review this" / pull request → `code-review`.
- Refactor → `test-driven` (pin behaviour) → `simplify-code` → `code-review`.
- Release → `ship-checklist`.

## Rules that apply in every phase

- Evidence over assertion: claims about the code cite files you read; "it works" means a check you ran.
- Small steps: each change leaves the project building and its tests passing.
- Stay in scope: do what was asked; list unrelated problems as follow-ups instead of fixing them silently.
- ELIYA's runtime already enforces plan steps, approvals and final verification — these skills decide *how well*
  each step is done, not whether the gates apply.
