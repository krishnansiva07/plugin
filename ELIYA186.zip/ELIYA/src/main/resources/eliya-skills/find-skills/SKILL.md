---
name: find-skills
description: Find, compare and install Agent Skills from skills.sh, or list installed ones. Use for 'is there a skill for X?' or 'install a skill'.
aliases: [skills, skill-finder, install-skill]
triggers: [find a skill, install a skill, discover skills]
---

# Find and install skills (find-skills)

ELIYA reads Agent Skills (folders with a `SKILL.md`) from these places, first match wins:

| Where | Scope |
|---|---|
| `<project>/.agents/skills/`, `<project>/.claude/skills/`, `<project>/.opencode/skills/` | this project (commit them to share with the team) |
| `~/.eliya/skills/`, `~/.agents/skills/`, `~/.claude/skills/`, `~/.config/opencode/skills/` | every project on this machine |
| built into ELIYA | always available; a project or user skill with the same name overrides it |

Skills installed for Claude Code, Codex or OpenCode in those folders work in ELIYA without changes.

## Workflow

1. **Check what exists first.** Call `skill_catalog`. If a listed skill fits, load it with `skill` and use it.
2. **Search the ecosystem** (needs Node.js 18+ and network access):
   - `npx -y skills find <keywords>` — e.g. `npx -y skills find playwright`, `npx -y skills find code review`.
   - Browse https://skills.sh for popularity and the source repository.
3. **Present options before installing.** For each candidate give: name, what it does, source repository,
   and the exact install command. Prefer well-known sources and actively maintained repositories.
4. **Install only after the user agrees** (the shell command also needs ELIYA's normal approval):
   - this project: `npx -y skills add <owner/repo> --skill <name> -a claude-code`
     (installs into `.claude/skills/`, which ELIYA reads)
   - list a repository's skills without installing: `npx -y skills add <owner/repo> --list`
5. **Verify:** call `skill_catalog` again and confirm the new skill appears; read its `SKILL.md` and point out
   anything it would run (scripts, network calls, tools that change files) before using it.

## Safety

- A skill is instructions plus optional scripts: treat a third-party skill like third-party code. Read it before
  first use; never run its scripts without the user's approval.
- Never install skills globally or modify `~/.claude`/`~/.agents` unless the user asks for "all projects".
- If Node.js or network access is missing, say so and offer the manual route: copy the skill folder into
  `.agents/skills/<name>/`.

## Creating a skill

When the user repeats the same workflow, offer to capture it as a project skill:
`.agents/skills/<name>/SKILL.md` with front matter (`name`, a one-line `description` that says *when* to use it,
optional `aliases`) followed by short, concrete steps. Then it can be invoked with `/<name>`.
