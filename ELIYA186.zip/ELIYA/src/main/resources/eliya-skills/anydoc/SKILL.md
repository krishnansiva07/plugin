---
name: anydoc
description: Read or convert Word, PowerPoint, Excel, ODF, RTF, EPUB, CSV or PDF files to Markdown. Use when a task needs a document's contents.
aliases: [convert-documents, documents-to-markdown, doc2md, convert-documents-to-markdown]
triggers: [convert document to markdown, convert pdf to markdown, convert word to markdown]
---

# Documents to Markdown (anydoc)

Pick the lightest route that answers the request.

## 1. Built into ELIYA (offline, no install)

- **Uploaded to the conversation:** `attachment_list`, then `attachment_read` / `attachment_search`.
- **Inside the workspace, need the content:** `knowledge_search` (ELIYA's local document index) and
  `knowledge_read` with the source path; for one file, `presentation_source_extract` with
  `sourceAlias: "workspace"` and `sourcePath: "<relative path>"` (Apache Tika, up to 60,000 characters).
- Plain-text formats (`.md`, `.txt`, `.csv`, `.json`, `.xml`, `.html`) can simply be `read`.

## 2. Firecrawl AnyDoc CLI (faithful Markdown with tables and headings)

Use it when the user wants a Markdown **file**, when table/heading structure matters, or when the built-in
extraction loses layout. Needs Node.js 20+; the first run downloads the converter.

```bash
npx -y @firecrawl/anydoc "docs/requirements.docx"                    # Markdown to stdout
npx -y @firecrawl/anydoc "docs/requirements.docx" -o docs/requirements.md
npx -y @firecrawl/anydoc - --format csv < data.csv                    # from stdin
```

Supported: `.doc .docx .docm`, `.ppt .pptx` (and variants), `.xls .xlsx .xlsm .xlsb`, `.odt .ods .odp`, `.rtf`,
`.epub`, `.csv`, text-based `.pdf`. Exit code 0 = success, 1 = could not convert, 2 = usage error; the error is one
`anydoc: …` line on stderr.

## Rules

- Quote paths with spaces. Write output next to the source (or where the user asked); never overwrite an existing
  `.md` without saying so.
- **Scanned / image-only PDFs** fail with a "needs OCR" error. Hosted OCR (`--ocr hosted`) uploads the whole document
  to Firecrawl and needs an API key: ask the user first and never send confidential documents without explicit
  consent. Otherwise report which pages could not be read.
- Large outputs: read the generated Markdown in parts (`read` with line ranges or `grep`) instead of pasting it all.
- After converting, check the result (headings present, tables intact, no empty output) before using it, and tell
  the user which route you used.
