---
name: framework-migration
description: Migrate automation frameworks with source-target parity, rollback and evidence.
triggers: [framework migration, migrate selenium, selenium to playwright, selenium playwright migration]
---

# Framework Migration

## Workflow

Identify the authorized source and target; keep read-only references untouched. Inventory scope, runner, scenarios, dependencies and configuration; establish baseline where permitted. Map semantics and data, migrate in coherent batches, use the migration ledger if available, verify parity and report exclusions. Never disable rollback or indexing safety.

## Outcome

Give the requested deliverable, factual evidence, verification status, limitations and any next action. User intent and runtime permission boundaries take precedence.
