---
name: code-review
description: Five-axis review (correctness, design, readability, security and performance, tests) with findings by severity. Use before merging or for 'review this'.
aliases: [review, code-review-and-quality, pr-review]
triggers: [review the code, code review, review my automation framework, review this code]
---

# Code review (code-review)

Read-only unless the user asks for fixes.

## Scope

- Changes from this run: `workspace_diff`. Git changes: `git diff`, `git diff --staged` or `git diff main...HEAD`
  (read-only `bash`). Named files/folders: read them and their callers.
- Read enough surrounding code to judge behaviour, not just the diff lines.

## Five axes

1. **Correctness** — logic errors, edge cases (null/empty/limits), error handling, concurrency, resource leaks,
   broken contracts with callers.
2. **Design** — right place for the change, duplication, coupling, consistency with existing patterns.
3. **Readability** — names, function size, comments that explain *why*, dead code.
4. **Security & performance** — input validation, injection, secrets in code/logs, authz checks; N+1 queries,
   needless work in loops, unbounded memory.
5. **Tests** — are the changed behaviours covered? Do tests assert outcomes, not implementation details?

## Report

Findings ranked **Critical → Major → Minor → Nit**. Each: `file:line`, what is wrong, a concrete failure scenario
(input → wrong result), and the suggested fix. Then what is good, and a verdict: *approve*, *approve with nits*, or
*changes requested*. Do not pad the list — no finding is better than an invented one.
