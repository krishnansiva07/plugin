---
name: test-case-design
description: Design traceable functional, boundary, negative and risk-based test cases.
triggers: [generate test cases, design test cases, test case design, acceptance criteria coverage]
---

# Test Case Design

## Workflow

Read source requirements and acceptance criteria, identify ambiguities, map scenarios and expected outcomes to requirement IDs, include data and preconditions, deduplicate and prioritize. Validate traceability and report uncovered or ambiguous requirements; do not invent business rules.

## Outcome

Give the requested deliverable, factual evidence, verification status, limitations and any next action. User intent and runtime permission boundaries take precedence.
