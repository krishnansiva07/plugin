---
name: incremental-build
description: Implement in thin, working slices - smallest change, verify, repeat, keep the build green. Use while writing or changing code.
aliases: [build, incremental-implementation, implement]
triggers: [implement changes, implement the feature, modify the code]
verification: [workspace]
---

# Incremental build (incremental-build)

## Loop

1. **Pick one slice** from the plan — the smallest change that moves toward the goal.
2. **Read first:** the files you will touch and their callers (`read`, `grep`, `code_impact`), plus applicable
   `AGENTS.md` rules (`instructions_for`). Follow the existing style, patterns and libraries.
3. **Change only what the slice needs** (`edit` / `apply_patch`). No drive-by refactors, renames or formatting of
   unrelated code.
4. **Verify the slice** with the cheapest real check: the targeted test, a compile, or a type check. Batch several
   tightly related edits before one check rather than compiling after every line.
5. **Keep it green:** if the check fails, fix it now — don't stack new slices on a broken build.
6. Repeat. Run the full relevant suite at the end.

## Guidelines

- Prefer extending an existing seam over creating a parallel mechanism.
- New behaviour behind a clear interface; keep public APIs stable unless the task is to change them.
- Leave the code simpler or equal, never more tangled. If a slice needs a refactor, make that its own slice first.
- When stuck after two failed attempts, stop guessing: re-read the error and the code, then try a different approach
  or ask with evidence.
