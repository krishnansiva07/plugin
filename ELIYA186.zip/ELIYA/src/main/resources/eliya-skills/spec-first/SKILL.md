---
name: spec-first
description: Write a short spec (goal, behaviour, interfaces, edge cases, tests, out of scope) before coding. Use for new features or fuzzy requirements.
aliases: [spec, spec-driven-development, define]
triggers: [define requirements, write a specification, new feature specification]
---

# Spec first (spec-first)

A spec is cheap; rework is not. Produce one before writing code when the change is new behaviour, touches more
than a couple of files, or the request leaves real choices open.

## Steps

1. **Read before asking.** Inspect the relevant code (`grep`, `read`, `code_impact`) so questions are specific.
2. **Ask only what blocks you** (`ask_user`, at most 3 questions, each with concrete options). Make reasonable
   assumptions for the rest and write them down.
3. **Write the spec** (in the answer, or `docs/specs/<feature>.md` if the user wants a file):
   - **Goal** — one or two sentences: the user-visible outcome.
   - **Behaviour** — numbered, testable statements ("When X, the system does Y").
   - **Interfaces** — APIs, classes, CLI flags, config keys, data shapes that change; existing ones reused.
   - **Edge cases & errors** — empty input, limits, concurrency, permissions, failure modes.
   - **Test plan** — which tests prove each behaviour (unit / integration / UI), and the command to run them.
   - **Out of scope** — what this change deliberately does not do.
   - **Assumptions & open questions.**
4. **Confirm** with the user when the spec changes direction or scope; otherwise continue to `task-breakdown`.

Keep it to one screen when possible. A spec that is longer than the code it describes is a smell.
