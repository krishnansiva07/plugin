---
name: release-readiness
description: Assess release readiness from actual tests, risks, CI and rollback evidence.
triggers: [qa release readiness, go no go, release risk analysis]
---

# Release Readiness

## Workflow

Identify requested release scope and verified test results; separate passed, failed, skipped and not-run checks. Review known defects, environment and rollback readiness. Report evidence-backed risks and go/no-go recommendation, never assume production deployment approval.

## Outcome

Give the requested deliverable, factual evidence, verification status, limitations and any next action. User intent and runtime permission boundaries take precedence.
