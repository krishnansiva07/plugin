---
name: task-breakdown
description: Break a spec or request into small, ordered, verifiable tasks with acceptance checks. Use before any change larger than one file.
aliases: [plan, planning-and-task-breakdown, breakdown]
triggers: [create an implementation plan, break down the task, migration plan]
---

# Task breakdown (task-breakdown)

## Steps

1. Start from the spec (or the request plus what you read in the code). List every behaviour that must change.
2. Slice **vertically**: each task delivers one working piece end to end (model → logic → API/UI → test),
   not "all models first, then all services".
3. Make each task small: one focused change, a few files, finishable and verifiable on its own.
4. For every task write:
   - **Change** — the files/symbols involved.
   - **Done when** — an observable check (a test name, a command and its expected result, a UI behaviour).
   - **Depends on** — earlier tasks, if any.
5. Order by dependency, then by risk: do the riskiest unknown early so surprises surface first.
6. Put verification inside the plan (tests per task, full suite at the end) — not as an afterthought.

## Good task

> 3. Validate the order quantity in `OrderService.place()` (reject ≤ 0 with `InvalidOrderException`).
> Done when: `OrderServiceTest.rejectsZeroQuantity` passes and `mvn -q test` is green.

## Smells

- A task called "implement the feature" or "fix everything".
- Tasks that cannot be checked independently.
- More than ~8 tasks for one request: split the request or group into milestones.
