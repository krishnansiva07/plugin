---
name: qa-architect
description: Assess QA architecture, automation feasibility, coverage, reliability and maintainability.
triggers: [qa architecture, test architecture, automation architecture, automation feasibility]
---

# Qa Architect

## Workflow

Inspect actual framework boundaries, execution entry points, dependencies and CI. Map current strengths and risks to concrete files. Compare alternatives with explicit trade-offs; propose incremental changes and measurable acceptance criteria. Do not rewrite the architecture for a review.

## Outcome

Give the requested deliverable, factual evidence, verification status, limitations and any next action. User intent and runtime permission boundaries take precedence.
