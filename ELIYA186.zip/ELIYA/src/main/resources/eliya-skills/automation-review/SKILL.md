---
name: automation-review
description: Review automation code for flakiness, maintainability, coverage and execution safety.
triggers: [automation code review, review automation scripts, automation review]
---

# Automation Review

## Workflow

Inspect actual changed files and representative tests. Assess assertions, waits, locators, data, parallelism, error handling and secrets. Rank findings by impact with source paths, reproduction evidence and specific fixes. Do not implement unless requested.

## Outcome

Give the requested deliverable, factual evidence, verification status, limitations and any next action. User intent and runtime permission boundaries take precedence.
