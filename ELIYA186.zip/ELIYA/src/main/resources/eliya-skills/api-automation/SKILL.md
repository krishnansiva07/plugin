---
name: api-automation
description: Design and maintain REST API tests with contract, auth, data and negative coverage.
triggers: [api automation, rest assured, api test automation, api tests]
---

# Api Automation

## Workflow

Read contracts and existing client/helpers; cover success, error, authentication and schema cases with reusable test data. Do not expose credentials or call unauthorized production endpoints. Run configured tests if asked and report response assertions, counts and gaps.

## Outcome

Give the requested deliverable, factual evidence, verification status, limitations and any next action. User intent and runtime permission boundaries take precedence.
