---
name: simplify-code
description: Make working code clearer and smaller without changing behaviour, protected by tests. Use for 'clean this up', 'simplify' or 'refactor for clarity'.
aliases: [simplify, code-simplify, refactor-for-clarity]
triggers: [simplify the code, refactor for clarity, clean up the code]
verification: [workspace]
---

# Simplify code (simplify-code)

Behaviour must not change. Clarity beats cleverness.

## Steps

1. **Pin behaviour:** find the tests that cover the code (`grep` for the class/function in test folders). If there
   are none, add characterisation tests first (see `test-driven`) or tell the user the risk.
2. **Look for:** duplicated blocks, dead or unreachable code, flags and parameters nobody uses, deep nesting
   (prefer early returns), long functions doing several things, names that need a comment to understand,
   needless abstraction layers with a single implementation.
3. **One small refactor at a time** (`edit`), run the tests after each meaningful step.
4. **Keep public APIs** unless the user approves a change; check callers with `grep`/`code_impact`.
5. Stop when further changes are taste, not clarity.

## Report

Before/after summary per change (what and why), tests run and their result, and anything you chose not to change
because it would alter behaviour.
