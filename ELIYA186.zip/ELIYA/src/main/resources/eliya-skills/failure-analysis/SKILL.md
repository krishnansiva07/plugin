---
name: failure-analysis
description: Diagnose regression and automated test failures from logs, reports and source evidence.
triggers: [failure analysis, regression failure, failing test cases, root cause analysis]
---

# Failure Analysis

## Workflow

Inspect real error messages and runner output. Classify product, framework, locator, synchronization, data or environment failures; distinguish hypotheses from evidence. For fixes, reproduce, apply minimal correction and rerun the affected scope; never suppress failures or weaken assertions.

## Outcome

Give the requested deliverable, factual evidence, verification status, limitations and any next action. User intent and runtime permission boundaries take precedence.
