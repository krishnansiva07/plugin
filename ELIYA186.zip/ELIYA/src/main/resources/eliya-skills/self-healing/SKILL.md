---
name: self-healing
description: Repair broken UI locators using DOM evidence without changing test intent.
triggers: [self healing, locator failure, broken locator]
---

# Self Healing

## Workflow

Inspect current DOM, page object, intended element and error. Prefer semantic or stable attributes and prove unique matches. Reject ambiguous targets; do not silently change business actions or assertions. When authorized, implement and rerun affected scenarios.

## Outcome

Give the requested deliverable, factual evidence, verification status, limitations and any next action. User intent and runtime permission boundaries take precedence.
