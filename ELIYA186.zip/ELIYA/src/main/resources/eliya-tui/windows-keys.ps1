# Eliya terminal chat key helper for Windows consoles (started by the Eliya launcher; not meant to be run by hand).
# Reads keys from the console without echo and sends them to the launcher over a loopback socket, encoded like a
# Unix terminal would send them. Restores the console (Ctrl+C handling, output code page, VT mode) when done.
$ErrorActionPreference = 'Stop'
$port = __PORT__
$token = '__TOKEN__'
$client = New-Object System.Net.Sockets.TcpClient('127.0.0.1', $port)
$stream = $client.GetStream()
$utf8 = New-Object System.Text.UTF8Encoding($false)
$writer = New-Object System.IO.StreamWriter($stream, $utf8)
$writer.AutoFlush = $true
$writer.NewLine = "`n"
$E = [string][char]27

$vt = 0
$outHandle = [IntPtr]::Zero
$originalMode = $null
try {
    Add-Type -Namespace EliyaTui -Name Native -MemberDefinition @'
[DllImport("kernel32.dll")] public static extern IntPtr GetStdHandle(int handle);
[DllImport("kernel32.dll")] public static extern bool GetConsoleMode(IntPtr handle, out uint mode);
[DllImport("kernel32.dll")] public static extern bool SetConsoleMode(IntPtr handle, uint mode);
'@
    $outHandle = [EliyaTui.Native]::GetStdHandle(-11)
    $mode = [uint32]0
    if ([EliyaTui.Native]::GetConsoleMode($outHandle, [ref]$mode)) {
        $originalMode = $mode
        if ([EliyaTui.Native]::SetConsoleMode($outHandle, ($mode -bor 4))) { $vt = 1 }  # ENABLE_VIRTUAL_TERMINAL_PROCESSING
    }
} catch { $vt = 0 }
# Terminals that always process VT sequences (ConPTY based).
if ($env:WT_SESSION -or $env:TERM_PROGRAM -eq 'vscode' -or $env:TERMINAL_EMULATOR -eq 'JetBrains-JediTerm' -or $env:ConEmuANSI -eq 'ON') { $vt = 1 }

$originalEncoding = [Console]::OutputEncoding
$originalCtrlC = [Console]::TreatControlCAsInput
function Send-Key([string]$text) { $writer.WriteLine('K ' + [Convert]::ToBase64String($utf8.GetBytes($text))) }

try {
    [Console]::OutputEncoding = $utf8
    [Console]::TreatControlCAsInput = $true
    $writer.WriteLine($token)
    $lastW = [Console]::WindowWidth
    $lastH = [Console]::WindowHeight
    $writer.WriteLine("H $vt $lastH $lastW")
    while ($true) {
        if ($client.Client.Poll(0, [System.Net.Sockets.SelectMode]::SelectRead) -and $client.Client.Available -eq 0) { break }
        $w = [Console]::WindowWidth
        $h = [Console]::WindowHeight
        if ($w -ne $lastW -or $h -ne $lastH) { $lastW = $w; $lastH = $h; $writer.WriteLine("S $h $w") }
        if (-not [Console]::KeyAvailable) { Start-Sleep -Milliseconds 15; continue }
        $k = [Console]::ReadKey($true)
        $ctrl = ($k.Modifiers -band [ConsoleModifiers]::Control) -ne 0
        $alt = ($k.Modifiers -band [ConsoleModifiers]::Alt) -ne 0
        $shift = ($k.Modifiers -band [ConsoleModifiers]::Shift) -ne 0
        $key = $k.Key.ToString()
        if ($key -eq 'Enter') {
            # More keys already waiting after Enter means a multi-line paste: keep it in the message box.
            if ($alt) { Send-Key ($E + "`r") }
            elseif ($shift) { Send-Key ($E + '[13;2u') }
            elseif ($ctrl -or [Console]::KeyAvailable) { Send-Key "`n" }
            else { Send-Key "`r" }
        }
        elseif ($key -eq 'UpArrow') { Send-Key ($E + '[A') }
        elseif ($key -eq 'DownArrow') { Send-Key ($E + '[B') }
        elseif ($key -eq 'RightArrow') { Send-Key ($E + '[C') }
        elseif ($key -eq 'LeftArrow') { Send-Key ($E + '[D') }
        elseif ($key -eq 'Home') { Send-Key ($E + '[H') }
        elseif ($key -eq 'End') { Send-Key ($E + '[F') }
        elseif ($key -eq 'PageUp') { Send-Key ($E + '[5~') }
        elseif ($key -eq 'PageDown') { Send-Key ($E + '[6~') }
        elseif ($key -eq 'Delete') { Send-Key ($E + '[3~') }
        elseif ($key -eq 'Escape') { Send-Key $E }
        elseif ($key -eq 'Tab') { if ($shift) { Send-Key ($E + '[Z') } else { Send-Key "`t" } }
        elseif ($key -eq 'Backspace') { Send-Key ([string][char]127) }
        elseif ($k.KeyChar -ne [char]0) {
            $c = $k.KeyChar
            if ([char]::IsHighSurrogate($c)) { $low = [Console]::ReadKey($true); Send-Key ([string]$c + [string]$low.KeyChar) }
            else { Send-Key ([string]$c) }
        }
    }
} catch {
    # The launcher closed the connection or the console went away.
} finally {
    [Console]::TreatControlCAsInput = $originalCtrlC
    [Console]::OutputEncoding = $originalEncoding
    if ($originalMode -ne $null) { [void][EliyaTui.Native]::SetConsoleMode($outHandle, $originalMode) }
    $client.Close()
}
