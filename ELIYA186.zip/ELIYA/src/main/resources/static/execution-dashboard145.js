/* ELIYA145: single authoritative view model for Analyse and Agent. No invented
 * progress, usage, or artifact verification. Pure and independently testable. */
(function(root,factory){
  const api=factory();
  if(typeof module==='object'&&module.exports)module.exports=api;
  if(root)root.EliyaExecutionDashboard145=api;
})(typeof window!=='undefined'?window:null,function(){
  'use strict';
  const labels={workspace:'Workspace setup',planning:'Planning/context',retrieval:'Evidence retrieval',
    tools:'Tools and commands',verification:'Verification',answer:'Response synthesis',finalization:'Final report'};
  const safe=(value,max=220)=>String(value??'').replace(/[\u0000-\u001f\u007f]/g,' ').trim().slice(0,max);
  const integer=value=>Number.isFinite(Number(value))&&Number(value)>=0?Math.floor(Number(value)):0;
  const duration=ms=>ms>=1000?`${(ms/1000).toFixed(1)} s`:`${Math.round(ms)} ms`;
  function fromMessage(message,experience){
    const view=experience?.stateFor(message);
    if(!view)return null;
    const progress=message.agentProgress||{};
    const usage=progress.tokenUsage||{};
    const source=usage.stageTimeMs||{};
    const stages=Object.entries(labels).filter(([key])=>Number.isFinite(Number(source[key]))&&Number(source[key])>0)
      .map(([key,label])=>({key,label,ms:integer(source[key]),duration:duration(integer(source[key]))}));
    const plan=Array.isArray(progress.plan)?progress.plan.slice(0,120).map((item,i)=>({
      number:integer(item.index)||i+1,title:safe(item.title||item.text||item.description||item.note||`Step ${i+1}`,180),
      status:safe(item.status||'pending',35),note:safe(item.note||'',220)
    })):[];
    const events=Array.isArray(message.agentSteps)?message.agentSteps.slice(-20).map(step=>({
      tool:safe(step.tool||'Action',85),status:safe(step.status||'unknown',30),detail:safe(step.detail||'',220),
      timestamp:safe(step.timestamp||step.at||'',65)
    })):[];
    const approvals=Array.isArray(message.agentSteps)?message.agentSteps.filter(step=>
      step.status==='approval' && step.approvalId).slice(-8).map(step=>({
      id:safe(step.approvalId,110),type:safe(step.approvalType||'tool',45),detail:safe(step.detail||'Approval requested',170)
    })):[];
    const question=progress.question?.id?{
      id:safe(progress.question.id,100),reason:safe(progress.question.reason||progress.question.question||'The Agent needs an answer.',350)
    }:null;
    const reported=usage.providerReported===true;
    const runId=safe(message.agentRunId||'',100);
    // Presence of a backend status is not the same as verified workspace files.
    const fileReport=message.agentCompletionReport;
    const current=message.agentFileIntegrity;
    const artifacts=current?.intact===true?'Current workspace hashes match sealed report':
      current?.status==='changed_or_missing'?'Workspace changed or files missing':
      current?.status==='partial_scan'?'File scan incomplete':
      current?.status==='rolled_back'?'Workspace changes rolled back':
      current?.available===false?'No sealed file report':
      fileReport?.filesVerified===true?'Sealed change report (current files not checked)':
      'Current file integrity not checked';
    return {view,runId,stages,plan,events,approvals,question,artifacts,
      startedAt:safe(message.startedAt||progress.startedAt||'',70),
      elapsedMs:integer(progress.elapsedMs||usage.elapsedMs),
      providerLatency:integer(usage.providerLatencyMs),
      tokens:reported?integer(usage.providerTotalTokens).toLocaleString('en-US'):'Unavailable',
      usageLabel:reported?(integer(usage.unreportedCalls)?'Partial provider usage':'Provider-reported usage'):'Usage not reported',
      failedChecks:Array.isArray(progress.verificationFailures)?progress.verificationFailures.slice(0,8).map(x=>safe(x,220)):[],
      fileIssues:Array.isArray(current?.issues)?current.issues.slice(0,8).map(x=>safe(x,230)):[],
      lastActivityAt:safe(progress.lastActivityAt||'',70)};
  }
  return Object.freeze({fromMessage,duration});
});
