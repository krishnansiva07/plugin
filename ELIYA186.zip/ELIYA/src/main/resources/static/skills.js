/* Skill management. All writes are explicit, scope-pinned user actions. */
(() => {
  const get = id => document.getElementById(id);
  const dialog = get('skillManagerDialog');
  if (!dialog) return;
  let projectId = null, loaded = [], selected = null, editScope = null, generation = 0, dirty = false, busy = false;
  const status = text => { get('skillManagerStatus').textContent = text; };
  const scope = () => get('skillScope').value === 'workspace' ? projectId : null;
  const endpoint = (path='', id=scope()) => '/api/skills'+path+(id?'?projectId='+encodeURIComponent(id):'');
  const discard = () => !dirty || window.confirm('Discard unsaved skill edits?');
  function resetEditor() { selected=null; editScope=scope(); dirty=false; get('skillName').value=''; get('skillName').readOnly=false; get('skillContent').value=''; get('skillEditHint').textContent='Select a skill or create a new one.'; }
  function draw() {
    const list=get('skillList'); list.replaceChildren();
    const q=get('skillSearch').value.trim().toLowerCase();
    for(const item of loaded.filter(x => [x.name,x.description,x.source,...(x.aliases||[])].join(' ').toLowerCase().includes(q))) {
      const row=document.createElement('div');row.className='skill-list-item';
      const open=document.createElement('button');open.type='button';open.className='skill-open';open.textContent=item.name+' · '+item.source;
      open.onclick=()=>select(item);
      const desc=document.createElement('small');desc.textContent=item.description;
      const toggle=document.createElement('button');toggle.type='button';toggle.textContent=item.enabled?'Disable':'Enable';toggle.setAttribute('aria-label',(item.enabled?'Disable ':'Enable ')+item.name);toggle.onclick=()=>setEnabled(item);
      row.append(open,toggle,desc);list.append(row);
    }
    if(!list.children.length) list.textContent='No matching skills.';
  }
  async function refresh() {
    const request=++generation,id=scope();status('Loading skills…');
    try {const result=await api(endpoint('',id));if(request!==generation)return;loaded=result;draw();status(`${loaded.length} skills · ${loaded.filter(x=>x.enabled).length} enabled`);}
    catch(e){if(request===generation)status(e.message);}
  }
  async function select(item) {
    if(busy||!discard())return;
    const id=scope(), request=++generation;status('Loading '+item.name+'…');
    try {const data=await api(endpoint('/'+encodeURIComponent(item.name),id));if(request!==generation)return;selected=item;editScope=id;dirty=false;get('skillName').value=item.name;get('skillName').readOnly=true;get('skillContent').value=data.content;get('skillEditHint').textContent=item.source==='project'?'Save a project-local definition (existing .agents definition is replaced only after confirmation).':'Save creates or updates a local override in the selected scope; the original is not edited.';status('Loaded '+item.name);}
    catch(e){if(request===generation)status(e.message);}
  }
  async function setEnabled(item){
    if(busy)return;busy=true;const id=scope();
    try {await api(endpoint('/'+encodeURIComponent(item.name)+'/enabled',id),{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify({enabled:!item.enabled})});await refresh();}
    catch(e){status(e.message);}finally{busy=false;}
  }
  get('skillManagerBtn').onclick=()=>{
    projectId=state.project?.localWorkspace?state.project.id:null;
    get('skillScope').options[0].disabled=!projectId;get('skillScope').value=projectId?'workspace':'global';
    resetEditor();dialog.showModal();refresh();
  };
  get('skillManagerClose').onclick=()=>{if(discard())dialog.close();};
  dialog.addEventListener('cancel',e=>{if(!discard())e.preventDefault();});
  get('skillScope').onchange=()=>{if(busy||!discard()){get('skillScope').value=editScope?'workspace':'global';return;}resetEditor();refresh();};
  get('skillSearch').oninput=draw;get('skillRefresh').onclick=refresh;
  get('skillCreate').onclick=()=>{if(busy||!discard())return;generation++;resetEditor();get('skillContent').value='---\nname: my-qa-skill\ndescription: Describe when this skill should be used\ntriggers: [specific task phrase]\nverification: [workspace]\n---\n\n# Workflow\n\n1. Inspect the relevant evidence.\n2. Perform the requested task within the permitted scope.\n3. Verify actual outcomes.\n';dirty=true;get('skillName').focus();};
  for(const id of ['skillName','skillContent'])get(id).oninput=()=>{dirty=true;};
  get('skillSave').onclick=async()=>{
    if(busy)return;const name=get('skillName').value.trim(),content=get('skillContent').value,id=scope();
    if(!/^[a-z][a-z0-9-]{1,62}$/.test(name)){status('Use a lowercase hyphenated skill name (2–63 characters).');return;}
    if(editScope!==id){status('Scope changed; reload the skill first.');return;}
    if(!confirm(`Save ${name} in ${id?'the current workspace':'your user skill library'}? This may replace a local definition.`))return;
    busy=true;
    try {await api(endpoint('/'+encodeURIComponent(name),id),{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify({content,overwrite:!!selected})});dirty=false;await refresh();busy=false;const item=loaded.find(x=>x.name===name);if(item)await select(item);status('Saved '+name+'; new requests can use it immediately.');}
    catch(e){status(e.message);}finally{busy=false;}
  };
  get('skillExport').onclick=()=>{const content=get('skillContent').value;if(!content.trim())return;const url=URL.createObjectURL(new Blob([content],{type:'text/markdown;charset=utf-8'}));const a=document.createElement('a');a.href=url;a.download='SKILL.md';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);};
})();
