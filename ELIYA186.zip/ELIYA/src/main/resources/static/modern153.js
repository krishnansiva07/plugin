/* Modern-only Eliya shell. Preserve all existing backend and conversation handlers. */
(function(root){
 'use strict';
 function initialize(doc){
  if(!doc || !doc.body)return;
  doc.body.classList.add('eliya-modern153');
  const sidebar=doc.getElementById('sidebar');
  const tabs=doc.querySelector('.eliya-unified-tabs');
  if(!sidebar || !tabs || doc.getElementById('eliyaSidebarToggle'))return;
  const btn=doc.createElement('button');btn.id='eliyaSidebarToggle';btn.type='button';
  btn.className='eliya-sidebar-toggle';btn.textContent='☰';
  btn.title='Show or hide navigation';btn.setAttribute('aria-label','Toggle navigation');
  btn.setAttribute('aria-controls','sidebar');
  const key='eliya.navigation.collapsed';
  let collapsed=false;
  try{collapsed=root.localStorage.getItem(key)==='true';}catch(_){}
  function update(){doc.body.classList.toggle('eliya-sidebar-collapsed',collapsed);btn.setAttribute('aria-expanded',String(!collapsed));}
  btn.addEventListener('click',function(){collapsed=!collapsed;try{root.localStorage.setItem(key,String(collapsed));}catch(_){}update();});
  tabs.insertBefore(btn,tabs.firstChild);update();
 }
 const api={initialize};if(typeof module==='object'&&module.exports)module.exports=api;
 if(root && root.document){if(root.document.readyState==='loading')root.document.addEventListener('DOMContentLoaded',()=>initialize(root.document));else initialize(root.document);}
})(typeof window!=='undefined'?window:undefined);
