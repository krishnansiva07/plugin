package com.llmart.llm.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;

import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

/** ELIYA177: "configure Playwright MCP" is understood and configured end to end. */
class McpServerInstallerTest {
    private static final ObjectMapper JSON = new ObjectMapper();

    @Test void knowsPlaywrightMcp() {
        assertEquals("playwright", McpKnownServers.byId("Playwright MCP").orElseThrow().id());
        assertTrue(McpKnownServers.isSetupRequest("configure playwright MCP"));
        assertFalse(McpKnownServers.isSetupRequest("configure playwright tests"));
        String agent = McpKnownServers.knowledgeFor("configure playwright MCP", true);
        assertTrue(agent.contains("@playwright/mcp@latest"));
        assertTrue(agent.contains("mcp_configure"));
        assertTrue(McpKnownServers.knowledgeFor("configure playwright MCP", false).contains("Agent mode"));
    }

    @Test void configuresVerifiesAndTurnsMcpOn() throws Exception {
        Path home = Files.createTempDirectory("mcp-home");
        Path file = home.resolve(".eliya/mcp-servers.json");
        List<String> calls = new ArrayList<>();
        boolean[] master = {false};
        McpServerInstaller.Servers servers = new McpServerInstaller.Servers() {
            public Path userServersFile() { return file; }
            public boolean masterSwitchOn() { return master[0]; }
            public void enableMasterSwitch() { master[0] = true; }
            public McpManager.ServerTest test(Path root, String name) {
                calls.add("test:" + name);
                return new McpManager.ServerTest(true, List.of("browser_navigate", "browser_install"), "");
            }
            public String callTool(Path root, String server, String tool) { calls.add("call:" + tool); return "ok"; }
        };
        McpServerInstaller.Commands commands = (command, timeout) ->
                new McpServerInstaller.CommandResult(0, command.get(0).startsWith("node") ? "v20.11.1" : "10.2.4");
        McpServerInstaller installer = new McpServerInstaller(servers, commands, "Linux", Map.of(), path -> false);
        McpServerInstaller.Outcome outcome = installer.configure(null, JSON.readTree("{\"server\":\"playwright\"}"));
        assertTrue(outcome.success(), outcome.text());
        assertTrue(master[0]);
        assertEquals(List.of("test:playwright", "call:browser_install"), calls);
        assertEquals("@playwright/mcp@latest",
                JSON.readTree(Files.readString(file)).path("mcp").path("playwright").path("args").get(1).asText());
    }

    @Test void missingNodeIsABlockerAndChangesNothing() throws Exception {
        Path file = Files.createTempDirectory("mcp-home").resolve("servers.json");
        McpServerInstaller.Servers servers = new McpServerInstaller.Servers() {
            public Path userServersFile() { return file; }
            public boolean masterSwitchOn() { return false; }
            public void enableMasterSwitch() { fail("must not enable MCP"); }
            public McpManager.ServerTest test(Path root, String name) { fail("must not start"); return null; }
            public String callTool(Path root, String server, String tool) { fail("must not call"); return null; }
        };
        McpServerInstaller installer = new McpServerInstaller(servers,
                (command, timeout) -> new McpServerInstaller.CommandResult(1, "not found"), "Windows 11", Map.of(), path -> false);
        McpServerInstaller.Outcome outcome = installer.configure(null, JSON.readTree("{\"server\":\"playwright\"}"));
        assertFalse(outcome.success());
        assertTrue(outcome.text().startsWith("BLOCKED: Node.js"));
        assertFalse(Files.exists(file));
    }

    @Test void windowsLaunchesNpxThroughCmd() {
        assertEquals(List.of("cmd.exe", "/c", "npx", "-y", "@playwright/mcp@latest"),
                McpManager.launchCommand("npx", List.of("-y", "@playwright/mcp@latest"), true, name -> null));
        assertEquals(List.of("npx", "-y"), McpManager.launchCommand("npx", List.of("-y"), false, name -> null));
    }
}
