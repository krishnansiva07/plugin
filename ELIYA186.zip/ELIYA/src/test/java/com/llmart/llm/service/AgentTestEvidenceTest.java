package com.llmart.llm.service;

import org.junit.jupiter.api.Test;

import java.nio.file.Files;
import java.nio.file.Path;

import static org.junit.jupiter.api.Assertions.*;

/** ELIYA180: an exit code of zero without executed tests is never verification evidence. */
class AgentTestEvidenceTest {

    @Test void zeroOrSkippedTestsAreRejected() {
        assertFalse(AgentVerificationPolicy.checkShell("bash", "mvn test", "exitCode=0;\nTests run: 0, Failures: 0, Errors: 0, Skipped: 0", false).passed());
        assertFalse(AgentVerificationPolicy.checkShell("bash", "mvn test -DskipTests", "exitCode=0;\nBUILD SUCCESS", false).passed());
        assertFalse(AgentVerificationPolicy.checkShell("bash", "python3 -m pytest", "exitCode=0;\ncollected 0 items", false).passed());
        assertTrue(AgentVerificationPolicy.checkShell("bash", "mvn test", "exitCode=0;\nTests run: 5, Failures: 0, Errors: 0, Skipped: 0", false).passed());
        assertTrue(AgentVerificationPolicy.checkShell("build", "", "exitCode=0;\nBUILD SUCCESS", false).passed());
    }

    @Test void countsComeFromOutputOrJUnitReports() throws Exception {
        assertEquals(4, AgentTestEvidence.fromOutput("Ran 4 tests in 0.01s\n\nOK").executed());
        assertFalse(AgentTestEvidence.fromOutput("BUILD SUCCESS").known());
        Path root = Files.createTempDirectory("evidence");
        long start = System.currentTimeMillis();
        Path reports = Files.createDirectories(root.resolve("build/test-results/test"));
        Files.writeString(reports.resolve("TEST-x.XTest.xml"), "<testsuite name=\"x\" tests=\"2\" skipped=\"0\" failures=\"0\" errors=\"0\"/>");
        assertEquals(2, AgentTestEvidence.of("BUILD SUCCESSFUL", root, start).executed());
    }
}
