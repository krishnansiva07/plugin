package com.llmart.llm.service;

import org.junit.jupiter.api.Test;
import java.io.IOException;
import java.util.List;
import java.util.concurrent.TimeoutException;
import static org.junit.jupiter.api.Assertions.*;

class AgentRuntimeFlowRecoveryTest {
    @Test void retriesOnlyModelTurnTransportErrors() {
        assertTrue(AgentRuntimeFailurePolicy.retryModelTurnWithoutApproval(new IOException("connection reset")));
        assertTrue(AgentRuntimeFailurePolicy.retryModelTurnWithoutApproval(
                new RuntimeException("wrapped", new TimeoutException("timeout"))));
        assertFalse(AgentRuntimeFailurePolicy.retryModelTurnWithoutApproval(new SecurityException("denied")));
        assertFalse(AgentRuntimeFailurePolicy.retryModelTurnWithoutApproval(new IllegalStateException("tool failure")));
    }

    @Test void fallbackKeepsSeparateExplicitUserRequirements() {
        String request = "Migrate Selenium tests to Playwright TypeScript.\n" +
                "- Preserve Cucumber feature scenarios and step mappings\n" +
                "- Run integration tests with the existing runner\n" +
                "- Keep the legacy reference read only";
        List<String> plan = AgentPlanRecovery.fromUserRequest(request, false);
        assertTrue(plan.size() >= 5, plan.toString());
        assertTrue(plan.stream().anyMatch(step -> step.contains("Preserve Cucumber")));
        assertTrue(plan.stream().anyMatch(step -> step.contains("Run integration tests")));
        assertTrue(plan.stream().anyMatch(step -> step.contains("legacy reference read only")));
    }

    @Test void rejectsPlansThatDropTheSpecificMigrationDestinationOrTestRun() {
        String request = "Migrate Selenium tests to Playwright and run integration tests";
        assertFalse(AgentPlanSpecificity.mismatch(request,
                List.of("Inspect Selenium modules", "Modify Selenium test classes", "Verify changes")).isBlank());
        assertEquals("",AgentPlanSpecificity.mismatch(request, List.of(
                "Inspect Selenium test module and existing run configuration",
                "Migrate Selenium flows to Playwright with preserved assertions",
                "Run integration tests with the project test runner and report the results")));
    }
}
