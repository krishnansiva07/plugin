package com.llmart.llm.cli.tui;

import org.junit.jupiter.api.Test;

import java.io.BufferedReader;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/** ELIYA176: the terminal chat reads the same SSE events as the browser and the classic terminal. */
class HttpTuiBackendTest {

    @Test void parsesEveryRunEventInOrder() throws Exception {
        String stream = """
                event: meta
                data: {"agentRunId":"run-1"}

                event: agent_step
                data: {"tool":"run_command","status":"waiting","detail":"mvn test","step":"3","approvalId":"ap-1","approvalType":"command"}

                event: agent_question
                data: {"id":"q1","reason":"Which module?","choices":["api","web"]}

                event: token
                data: {"text":"Hello "}

                event: token
                data: {"text":"world"}

                event: chat_status
                data: {"phase":"writing","detail":"Composing answer"}

                event: agent_changes
                data: {"count":2}

                event: done
                data: {"content":"Hello world"}

                """;
        List<String> seen = new ArrayList<>();
        HttpTuiBackend.readEvents(new BufferedReader(new StringReader(stream)), new TuiBackend.Listener() {
            public void token(String text) { seen.add("token:" + text); }
            public void runId(String runId) { seen.add("run:" + runId); }
            public void step(String tool, String status, String detail, String step, String approvalId, String approvalType) {
                seen.add("step:" + tool + ":" + status + ":" + detail + ":" + step + ":" + approvalId + ":" + approvalType);
            }
            public void question(String id, String reason, List<String> choices) { seen.add("question:" + id + ":" + reason + ":" + choices); }
            public void changes(String count) { seen.add("changes:" + count); }
            public void status(String phase, String detail) { seen.add("status:" + phase + ":" + detail); }
            public void error(String message) { seen.add("error:" + message); }
            public void stopped(String message) { seen.add("stopped:" + message); }
            public void done(String content) { seen.add("done:" + content); }
        });
        assertEquals(List.of("run:run-1", "step:run_command:waiting:mvn test:3:ap-1:command",
                "question:q1:Which module?:[api, web]", "token:Hello ", "token:world",
                "status:writing:Composing answer", "changes:2", "done:Hello world"), seen);
    }

    @Test void errorsAndStopsAreReported() throws Exception {
        String stream = "event: error\ndata: {\"message\":\"Provider unavailable\"}\n\nevent: stopped\ndata: {\"message\":\"Run stopped\"}\n";
        List<String> seen = new ArrayList<>();
        HttpTuiBackend.readEvents(new BufferedReader(new StringReader(stream)), new TuiBackend.Listener() {
            public void token(String text) { }
            public void runId(String runId) { }
            public void step(String tool, String status, String detail, String step, String approvalId, String approvalType) { }
            public void question(String id, String reason, List<String> choices) { }
            public void changes(String count) { }
            public void status(String phase, String detail) { }
            public void error(String message) { seen.add("error:" + message); }
            public void stopped(String message) { seen.add("stopped:" + message); }
            public void done(String content) { }
        });
        assertEquals(List.of("error:Provider unavailable", "stopped:Run stopped"), seen);
    }

    @Test void httpErrorsAreExplained() {
        assertTrue(HttpTuiBackend.errorText(409, "{\"error\":\"Run already finished\"}").contains("Run already finished"));
        assertTrue(HttpTuiBackend.errorText(403, "").startsWith("Eliya rejected this terminal"));
    }
}
