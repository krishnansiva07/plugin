package com.llmart.llm.service;

import org.junit.jupiter.api.Test;
import java.util.Map;
import java.nio.file.Files;
import java.nio.file.Path;
import static org.junit.jupiter.api.Assertions.*;

class AgentReadOnlySearchPolicyTest {
    @Test void grepAuditReadOnlyAndSafe() {
        String q = "run the verification greps on Migration/prompt-*.md and report which are missing";
        assertTrue(AgentConversationIntent.isFastReadOnly(q));
        assertTrue(AgentReadOnlySearchPolicy.isAudit(q));
        assertFalse(AgentReadOnlySearchPolicy.isAudit("fix the greps and report missing"));
        assertFalse(AgentConversationIntent.isFastReadOnly("Run tests and fix failures"));
        assertTrue(AgentReadOnlySearchPolicy.isSafeSearchCommand("rg -n 'foo' Migration/"));
        assertFalse(AgentReadOnlySearchPolicy.isSafeSearchCommand("rg foo && rm -rf Migration/"));
        assertFalse(AgentReadOnlySearchPolicy.isSafeSearchCommand("rg --pre='sh' foo"));
        assertFalse(AgentReadOnlySearchPolicy.isSafeSearchCommand("rg foo ../secrets"));
    }

    @Test void portableWindowsLineCountDoesNotRequireUnixShell() throws Exception {
        Path dir = Files.createTempDirectory("eliya-count-");
        try {
            Files.writeString(dir.resolve("prompt.md"), "one\ntwo\n");
            String receipt = AgentPortableInspection.execute(dir, "wc -l prompt.md");
            assertTrue(receipt.startsWith("exitCode=0;"));
            assertTrue(receipt.contains("2 prompt.md"));
            assertFalse(AgentPortableInspection.supports("wc -l ../private"));
            assertFalse(AgentPortableInspection.supports("wc -l prompt.md; del x"));
        } finally {
            Files.deleteIfExists(dir.resolve("prompt.md"));
            Files.delete(dir);
        }
    }

    @Test void grepMissingMatchesAreNotFailedBuilds() {
        assertTrue(AgentReadOnlySearchPolicy.isNoMatch("bash", "rg foo Migration/", "exitCode=1;"));
        assertFalse(AgentReadOnlySearchPolicy.isNoMatch("bash", "rg foo Migration/", "exitCode=2; permission denied"));
        assertFalse(AgentReadOnlySearchPolicy.isNoMatch("build", "rg foo Migration/", "exitCode=1;"));
        var ledger = new AgentUniversalOutcomeEvidence();
        ledger.observe(Map.of("tool", "bash", "status", "error",
                "args", "{\"command\":\"rg foo Migration/\"}", "output", "exitCode=1;"));
        assertTrue(ledger.hasReadEvidence());
        assertFalse(ledger.hasUnresolvedToolFailures());
        assertTrue(ledger.report("completed", 0, false, "").contains("code-build verifier is not required"));
    }
}
