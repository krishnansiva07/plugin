package com.llmart.llm.service;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import java.nio.file.Path;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

class SkillSelectionTest {
    @TempDir Path root;
    @Test void selectsMultipleRelevantSkillsWithoutExpandingReadOnlyMode() {
        var selected=SkillSelection.select(root,"Fix the failing Selenium tests");
        var names=selected.stream().map(s->s.skill().name()).toList();
        assertTrue(names.containsAll(List.of("selenium-automation","test-driven")));
        assertTrue(SkillSelection.prompt(selected,true).contains("Analyse mode is read-only"));
        assertTrue(SkillSelection.select(root,"hello").isEmpty());
    }
    @Test void explicitSkillManagementPersistsAndVerificationUsesEvidence() throws Exception {
        String content="---\nname: custom-skill-check\ndescription: Focused quality validation\ntriggers: [special quality check]\nverification: [workspace,tests]\n---\n# Validate real evidence";
        SkillManagement.save(root,"custom-skill-check",content,false);
        var selected=SkillSelection.select(root,"/skill custom-skill-check perform verification");
        assertEquals(1,selected.size());
        assertTrue(selected.get(0).explicit());
        assertEquals(2,SkillSelection.missing(selected,true,false,false).size());
        assertTrue(SkillSelection.missing(selected,true,true,true).isEmpty());
        SkillManagement.toggle(root,"custom-skill-check",false);
        assertTrue(SkillCatalog.find(root,"custom-skill-check").isEmpty());
        assertThrows(IllegalArgumentException.class,()->SkillSelection.select(root,"/custom-skill-check run"));
        SkillManagement.toggle(root,"custom-skill-check",true);
        assertEquals("project",SkillCatalog.find(root,"custom-skill-check").orElseThrow().source());
        assertThrows(IllegalArgumentException.class,()->SkillManagement.save(root,"custom-skill-check",content,false));
    }
}
