package com.llmart.llm.service;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Files;
import java.nio.file.Path;

import static org.junit.jupiter.api.Assertions.*;

/** Regression: a workspace larger than ten thousand files stays fully inventoried in compact mode. */
class WorkspaceRetrievalIndexTenThousandFilesTest {
    @TempDir Path workspace;

    @Test
    void indexesFilesBeyondTenThousandWithoutTruncatingTheManifest() throws Exception {
        Path features = Files.createDirectories(workspace.resolve("src/test/resources/features"));
        for (int i = 0; i < 10_050; i++) {
            Files.writeString(features.resolve("businessScenario" + i + ".feature"),
                    "Feature: migration coverage " + i + "\nScenario: paymentFlow" + i +
                    "\nGiven coverage case " + i + " exists\n");
        }
        WorkspaceRetrievalIndexService index = new WorkspaceRetrievalIndexService(null);
        var stats = index.warmRoot("ten-thousand-coverage", workspace);

        assertEquals(10_050, stats.indexedFiles());
        assertFalse(stats.scanIncomplete(), "A large workspace must not silently lose the last files");
        String evidence = index.retrieveCachedRoot("ten-thousand-coverage", workspace,
                "businessScenario10049 paymentFlow10049", 8, 12_000);
        assertTrue(evidence.contains("businessScenario10049.feature"),
                "The last indexed feature must still be discoverable");
    }
}
