package com.llmart.llm.cli;

import org.junit.jupiter.api.Test;

import java.nio.file.Path;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/** ELIYA176: app-window and new-terminal command construction for each OS. */
class EliyaUiLauncherTest {

    @Test void linuxAppWindowUsesChromiumFamilyOnPath() {
        var commands = EliyaUiLauncher.appWindowCommands(EliyaUiLauncher.Os.LINUX, "http://localhost:8080/",
                path -> path.getFileName().toString().equals("chromium"));
        assertFalse(commands.isEmpty());
        assertEquals("--app=http://localhost:8080/", commands.get(0).get(1));
    }

    @Test void macAppWindowUsesOpen() {
        var commands = EliyaUiLauncher.appWindowCommands(EliyaUiLauncher.Os.MAC, "http://localhost:8080/",
                path -> path.toString().equals("/Applications/Google Chrome.app"));
        assertEquals(List.of("open", "-na", "Google Chrome", "--args", "--app=http://localhost:8080/"), commands.get(0));
    }

    @Test void windowsFallsBackToStartCommands() {
        var commands = EliyaUiLauncher.appWindowCommands(EliyaUiLauncher.Os.WINDOWS, "http://localhost:8080/", path -> false);
        assertTrue(commands.stream().anyMatch(command -> command.contains("msedge")));
    }

    @Test void onlyLocalUrlsAreOpened() {
        assertTrue(EliyaUiLauncher.isLocalUrl("http://localhost:9000/"));
        assertFalse(EliyaUiLauncher.isLocalUrl("http://example.com/"));
        assertFalse(EliyaUiLauncher.isLocalUrl("file:///etc/passwd"));
    }

    @Test void newTerminalCommandsQuoteTheDirectory() {
        var commands = EliyaUiLauncher.newTerminalCommands(EliyaUiLauncher.Os.LINUX,
                List.of("/usr/bin/java", "-jar", "/opt/eliya app/eliya.jar", "--eliya-cli", "chat", "analyse"),
                "/home/me/my project", path -> path.getFileName().toString().equals("gnome-terminal"));
        assertEquals(1, commands.size());
        String script = commands.get(0).get(commands.get(0).size() - 1);
        assertTrue(script.startsWith("cd '/home/me/my project' && /usr/bin/java -jar '/opt/eliya app/eliya.jar' --eliya-cli chat analyse"), script);
        var mac = EliyaUiLauncher.newTerminalCommands(EliyaUiLauncher.Os.MAC, List.of("java", "-jar", "e.jar"), "/tmp", path -> false);
        assertEquals("osascript", mac.get(0).get(0));
        var windows = EliyaUiLauncher.newTerminalCommands(EliyaUiLauncher.Os.WINDOWS, List.of("java.exe", "-jar", "e.jar"), "C:\\work", path -> false);
        assertTrue(windows.get(windows.size() - 1).containsAll(List.of("cmd", "/c", "start", "/D", "C:\\work", "java.exe")));
    }

    @Test void chatModeAndChoice() {
        assertEquals("agent", EliyaUiLauncher.chatMode(new String[]{"agent"}));
        assertEquals(EliyaUiLauncher.UiChoice.CHAT,
                EliyaUiLauncher.chooseUi(new String[]{}, List.of(), false, null, true, () -> true));
        assertEquals(EliyaUiLauncher.UiChoice.CLASSIC,
                EliyaUiLauncher.chooseUi(new String[]{"web"}, List.of("web"), false, null, true, () -> true));
    }
}
