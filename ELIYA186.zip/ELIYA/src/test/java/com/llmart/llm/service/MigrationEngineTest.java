package com.llmart.llm.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/** ELIYA179: the generic migration engine — understand, discover, baseline, verify, resume, complete. */
class MigrationEngineTest {
    private static final ObjectMapper JSON = new ObjectMapper();

    @Test void understandsMigrationsInAnyPhrasing() {
        assertEquals("Spring Boot 2.7", MigrationIntent.parse("Upgrade Spring Boot from 2.7 to 3.2 across all modules").orElseThrow().source());
        assertEquals("dayjs", MigrationIntent.parse("Replace moment with dayjs in the frontend").orElseThrow().target());
        assertEquals("Java 17", MigrationIntent.parse("Java 8 → 17 upgrade for the payments service").orElseThrow().target());
        assertFalse(MigrationIntent.isMigration("move the button to the header"));
        assertFalse(MigrationIntent.isMigration("Create a Flyway migration for the orders table"));
    }

    @Test void discoversVerifiesAgainstBaselineAndCompletes() throws Exception {
        Path root = Files.createTempDirectory("migration-engine");
        Files.createDirectories(root.resolve("src/main/java/a"));
        Files.writeString(root.resolve("pom.xml"), "<project><artifactId>x</artifactId><dependencies><dependency><artifactId>junit</artifactId></dependency></dependencies></project>");
        Files.writeString(root.resolve("src/main/java/a/ATest.java"), "import org.junit.Test;\nclass ATest { @Test public void t() {} }\n");
        List<String> commands = new ArrayList<>();
        int[] exit = {0};
        MigrationEngine engine = new MigrationEngine((dir, command, timeout, cancelled) -> {
            commands.add(command);
            return new MigrationEngine.CommandResult(exit[0], exit[0] == 0 ? "Tests run: 1, Failures: 0, Errors: 0, Skipped: 0" : "[ERROR] a.ATest.t:3 boom", false);
        });
        MigrationEngine.Outcome init = engine.init(root, JSON.readTree("{}"), "Convert our JUnit 4 tests to JUnit 5");
        assertFalse(init.failed(), init.text());
        assertTrue(init.text().contains("Work items: 2 files"), init.text());
        assertTrue(init.text().contains("Verify command: mvn test"), "verify command detected from pom.xml");
        assertFalse(engine.baseline(root, JSON.readTree("{}"), () -> false).failed());
        assertTrue(engine.completionProblem(root).unfinished());

        Files.writeString(root.resolve("src/main/java/a/ATest.java"), "import org.junit.jupiter.api.Test;\nclass ATest { @Test void t() {} }\n");
        engine.update(root, JSON.readTree("{\"items\":[\"src/main/java/a/ATest.java\"],\"status\":\"migrated\"}"));
        exit[0] = 1; // a NEW failure compared with the passing baseline
        MigrationEngine.Outcome broken = engine.verify(root, JSON.readTree("{}"), () -> false);
        assertTrue(broken.failed() && broken.testFailed(), broken.text());
        exit[0] = 0;
        MigrationEngine.Outcome ok = engine.verify(root, JSON.readTree("{}"), () -> false);
        assertFalse(ok.failed(), ok.text());

        Files.writeString(root.resolve("pom.xml"), "<project><artifactId>x</artifactId><dependencies><dependency><artifactId>junit-jupiter</artifactId></dependency></dependencies></project>");
        engine.update(root, JSON.readTree("{\"items\":[\"pom.xml\"],\"status\":\"migrated\"}"));
        assertFalse(engine.verify(root, JSON.readTree("{}"), () -> false).failed());
        assertNull(engine.completionProblem(root));
        assertTrue(engine.init(root, JSON.readTree("{}"), "Convert our JUnit 4 tests to JUnit 5").text().startsWith("MIGRATION RESUMED"));
        assertEquals(4, commands.size()); // baseline + three verifications
    }

    @Test void itemsBecomeVerifiedOnlyThroughVerification() throws Exception {
        Path root = Files.createTempDirectory("migration-engine");
        Files.writeString(root.resolve("app.py"), "print 'x'\n");
        MigrationEngine engine = new MigrationEngine((dir, command, timeout, cancelled) -> new MigrationEngine.CommandResult(0, "Ran 1 test\n\nOK", false));
        engine.init(root, JSON.readTree("{\"verifyCommand\":\"python3 app.py\"}"), "Port the Python 2 scripts to Python 3");
        assertTrue(engine.update(root, JSON.readTree("{\"items\":[\"app.py\"],\"status\":\"verified\"}")).failed());
        engine.update(root, JSON.readTree("{\"items\":[\"app.py\"],\"status\":\"migrated\"}"));
        MigrationEngine.Outcome residue = engine.verify(root, JSON.readTree("{}"), () -> false);
        assertTrue(residue.failed() && residue.text().contains("print statement"), "old API still in the file");
    }
}
