package com.llmart.llm.service;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import java.nio.file.*;
import static org.junit.jupiter.api.Assertions.*;

class RollbackProtectionSettingsTest {
    @TempDir Path temp;

    @Test void persistsAndReloadsSnapshotLimitsWithoutJvmArguments() throws Exception {
        Path location = temp.resolve("rollback-protection.properties");
        var initial = new RollbackProtectionSettings(location);
        assertEquals(100_000, initial.current().maxFiles());
        var updated = new RollbackProtectionSettings.Limits(160_000, 8192, 900);
        initial.save(updated);
        assertEquals(updated, new RollbackProtectionSettings(location).current());
        assertEquals(8192L * 1024 * 1024, updated.maxBytes());
    }

    @Test void invalidValuesCannotDisableSafetyOrOverwriteExistingPreferences() throws Exception {
        var settings = new RollbackProtectionSettings(temp.resolve("s.properties"));
        var original = settings.current();
        assertThrows(IllegalArgumentException.class,
                () -> settings.save(new RollbackProtectionSettings.Limits(0, 4096, 900)));
        assertThrows(IllegalArgumentException.class,
                () -> settings.save(new RollbackProtectionSettings.Limits(200_000, 999999, 900)));
        assertThrows(IllegalArgumentException.class,
                () -> settings.save(new RollbackProtectionSettings.Limits(200_000, 4096, 10)));
        assertEquals(original, settings.current());
    }
}
