package com.llmart.llm.service;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class AgentConversationIntentReadOnlyTest {
    @Test void sourceDocumentIsInputNotOutput() {
        assertTrue(AgentConversationIntent.isFastReadOnly("Please analyze the attached file(s)."));
        assertTrue(AgentConversationIntent.isFastReadOnly("Please analyze prompt-1-complete-prompt.md and summarize it."));
        assertTrue(AgentConversationIntent.isFastReadOnly("Review the attached markdown file and explain its phases."));
    }
    @Test void explicitWrittenDeliverablesOrMutationsStillRequireProtectedExecution() {
        assertFalse(AgentConversationIntent.isFastReadOnly("Analyze prompt-1-complete-prompt.md and implement its instructions."));
        assertFalse(AgentConversationIntent.isFastReadOnly("Analyze README.md and create migration-plan.md."));
        assertFalse(AgentConversationIntent.isFastReadOnly("Please analyze and provide a markdown file with the findings."));
        assertFalse(AgentConversationIntent.isFastReadOnly("Review the architecture and deliver the answer as an HTML file."));
    }
}
