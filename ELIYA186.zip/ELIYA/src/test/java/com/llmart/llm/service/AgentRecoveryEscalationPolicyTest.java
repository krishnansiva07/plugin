package com.llmart.llm.service;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class AgentRecoveryEscalationPolicyTest {
    @Test void onlyUnchangedStepWithoutMutationEscalates() {
        var policy = new AgentRecoveryEscalationPolicy();
        for (int i=0;i<3;i++) assertFalse(policy.needsDecision(2, 7));
        assertTrue(policy.needsDecision(2, 7));
        assertFalse(policy.needsDecision(2, 8)); // real file change
        assertFalse(policy.needsDecision(3, 8)); // a different step
    }
    @Test void consentGrantsOnlyAnotherBoundedEpoch() {
        var policy = new AgentRecoveryEscalationPolicy();
        for (int i=0;i<4;i++) policy.needsDecision(1, 0);
        policy.continueSameScope();
        for (int i=0;i<3;i++) assertFalse(policy.needsDecision(1, 0));
        assertTrue(policy.needsDecision(1, 0));
    }
    @Test void acceptsClearSameScopeConsentButRejectsUnsafeOrAmbiguousAnswers() {
        assertTrue(AgentRecoveryEscalationPolicy.permitsSameScopeRetry("User selected: Custom\nDetails: continue"));
        assertTrue(AgentRecoveryEscalationPolicy.permitsSameScopeRetry("User selected: Continue safely"));
        assertTrue(AgentRecoveryEscalationPolicy.permitsSameScopeRetry("yes"));
        for (String response : new String[]{"No", "stop", "keep current work", "cancel",
                "maybe", "continue but skip verification", "continue and delete files", "continue and bypass permissions",
                "User selected: Custom\nDetails: not sure"}) {
            assertFalse(AgentRecoveryEscalationPolicy.permitsSameScopeRetry(response), response);
        }
    }
    @Test void visibleQuestionIsSpecificAndScopeBounded() {
        String question = AgentRecoveryEscalationPolicy.decisionQuestion("Migrate Selenium code", "Refactor core", "Build failed");
        assertTrue(question.contains("Build failed"));
        assertTrue(question.contains("Migrate Selenium code"));
        assertTrue(question.contains("same" ) || question.contains("EXACT original scope"));
        assertTrue(question.contains("rollback protection"));
    }
}
