package com.llmart.llm.service;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

class WorkspaceTestInventoryTest {
    @TempDir Path workspace;

    @Test void classifiesCountAsInventoryRatherThanVerification() {
        assertTrue(WorkspaceTestInventory.isCountRequest("can you check how many test cases present"));
        assertTrue(WorkspaceTestInventory.isCountRequest("count scenarios in my workspace"));
        assertFalse(WorkspaceTestInventory.isCountRequest("verify that the migration passed"));
        assertFalse(WorkspaceTestInventory.isCountRequest("how many tests passed"));
    }

    @Test void countsRealPlaywrightDeclarationsNotCommentsDescribeOrStrings() throws Exception {
        String path = "tests/auth/login.spec.ts";
        Path source = workspace.resolve(path);
        Files.createDirectories(source.getParent());
        Files.writeString(source, """
                import { test } from '@playwright/test';
                // test('fake', () => {});
                const str = "test('fake', () => {})";
                /* test('fake', () => {}); */
                test.describe('Login', () => {
                  test('valid login', async () => {});
                  test.only('logout', async () => {});
                  test.skip('future', async () => {});
                });
                """);
        String result = WorkspaceTestInventory.inspect(workspace, List.of(path), false, () -> false);
        assertTrue(result.contains("static test declarations: 3"), result);
        assertTrue(result.contains(path + ": 3"), result);
    }

    @Test void detectsParameterizedCasesAndDoesNotClaimRuntimeCount() throws Exception {
        String path = "tests/account.test.ts";
        Path source = workspace.resolve(path);
        Files.createDirectories(source.getParent());
        Files.writeString(source, "test.each([{x:1},{x:2}])('account %i', ({x}) => {});");
        String result = WorkspaceTestInventory.inspect(workspace, List.of(path), false, () -> false);
        assertTrue(result.contains("static test declarations: 1"), result);
        assertTrue(result.contains("NOT AN EXACT RUNTIME TEST COUNT"), result);
    }

    @Test void keepsFeatureOutlineStaticCountDistinctFromExampleRows() throws Exception {
        String path = "features/login.feature";
        Path source = workspace.resolve(path);
        Files.createDirectories(source.getParent());
        Files.writeString(source, """
                Feature: Login
                Scenario: standard login
                  Given user logs in
                Scenario Outline: invalid login
                  Given <user> logs in
                Examples:
                  | user |
                  | a |
                  | b |
                """);
        String result = WorkspaceTestInventory.inspect(workspace, List.of(path), false, () -> false);
        assertTrue(result.contains("static test declarations: 2"), result);
        assertTrue(result.contains("NOT AN EXACT RUNTIME TEST COUNT"), result);
    }

    @Test void reportsIndexIncompleteAndUnreadableWithoutClaimingZero() {
        String result = WorkspaceTestInventory.inspect(workspace, List.of("tests/missing.spec.ts"), true, () -> false);
        assertTrue(result.contains("No readable indexed test files were inspected"), result);
        assertTrue(result.contains("Index reports incomplete scanning"), result);
    }

    @Test void refusesSymlinkOutsideConfiguredWorkspace() throws Exception {
        Path outside = Files.createTempFile("test-outside", ".spec.ts");
        try {
            Files.writeString(outside, "test('outside', () => {});");
            Path link = workspace.resolve("outside.spec.ts");
            Files.createSymbolicLink(link, outside);
            String result = WorkspaceTestInventory.inspect(workspace, List.of("outside.spec.ts"), false, () -> false);
            assertTrue(result.contains("static test declarations: 0"), result);
            assertTrue(result.contains("No readable indexed test files were inspected"), result);
        } finally { Files.deleteIfExists(outside); }
    }
}
