package com.llmart.llm.service;

import com.llmart.llm.dto.ProjectPatchRequest;
import org.junit.jupiter.api.Test;
import java.util.List;
import java.util.Map;
import static org.junit.jupiter.api.Assertions.*;

class AgentCompletionNarratorOutcomeTest {
    @Test
    void blockedRunStillReportsCompletedStepsChangedFilesAndNextAction() {
        var files = List.of(new ProjectPatchRequest.ProjectPatchFile("src/test/Example.java", "source", null, "write"));
        var plan = List.<Map<String,Object>>of(
            Map.of("text", "Create test project", "status", "completed"),
            Map.of("text", "Execute headed tests", "status", "in_progress"));
        String answer = AgentCompletionNarrator.complete("Browser session unavailable", "Execute headed tests",
                files, 1, "No runner output", false, "blocked", plan);
        assertTrue(answer.contains("Outcome: blocked"));
        assertTrue(answer.contains("Create test project"));
        assertTrue(answer.contains("src/test/Example.java"));
        assertTrue(answer.contains("Execute headed tests"));
        assertTrue(answer.contains("Browser session unavailable"));
        assertTrue(answer.contains("No runner output"));
        assertTrue(answer.contains("Improvement opportunities"));
        assertTrue(answer.contains("Suggested next step"));
        assertFalse(answer.contains("Tests passed"));
    }

    @Test
    void verifiedCompletionExplainsOutcomeWithoutStockQuestion() {
        var files = List.of(new ProjectPatchRequest.ProjectPatchFile("README.md", "description", null, "write"));
        String answer = AgentCompletionNarrator.complete("Updated project documentation", "Update documentation",
                files, 1, "Document read-back passed", true, "completed", List.of());
        assertTrue(answer.contains("What I completed"));
        assertTrue(answer.contains("Files created or changed"));
        assertTrue(answer.contains("Improvements and next step"));
        assertFalse(answer.contains("Do you want to add anything?"));
    }

    @Test
    void failedRunDoesNotInventChangedFilesOrVerifiedTests() {
        String answer = AgentCompletionNarrator.complete("", "Run tests", List.of(), 0,
                "", false, "failed", List.of());
        assertTrue(answer.contains("Outcome: failed"));
        assertTrue(answer.contains("No tracked workspace changes"));
        assertTrue(answer.contains("not verified"));
        assertTrue(answer.contains("What remains"));
    }
}
