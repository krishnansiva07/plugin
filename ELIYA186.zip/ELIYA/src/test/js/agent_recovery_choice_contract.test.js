const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');

const app = fs.readFileSync('src/main/resources/static/app.js', 'utf8');
const start = app.indexOf('async function submitAgentChatAnswer(');
const end = app.indexOf('// ELIYA82:', start);
assert.ok(start > 0 && end > start);
const fn = app.slice(start, end);

async function send(answer, choices) {
  const calls = [];
  const message = {agentProgress:{question:{choices}}};
  const context = {
    state:{messages:[]},
    api:async (url,options)=>{calls.push({url,body:JSON.parse(options.body)});return {answered:true};},
    $:()=>({value:'', classList:{},placeholder:'',setAttribute(){}}),
    autoGrow(){},renderMessages(){},scrollBottom(){},
    encodeURIComponent,
    Date
  };
  vm.runInNewContext(fn + '\nthis.submit = submitAgentChatAnswer;', context);
  await context.submit(answer, {runId:'run-1',questionId:'question-1',message});
  return calls[0];
}

test('recovery preset survives UI-to-server transport as the exact chosen option',async()=>{
  const call = await send('Retry after fixing provider',
    ['Retry after fixing provider','Stop and keep current work','Cancel']);
  assert.match(call.url,/\/api\/agent\/runs\/run-1\/answer$/);
  assert.equal(call.body.choice,'Retry after fixing provider');
  assert.equal(call.body.detail,'');
});

test('stopping and preserving work is not silently converted to cancel',async()=>{
  const call = await send('Stop and keep current work',
    ['Retry after fixing provider','Stop and keep current work','Cancel']);
  assert.equal(call.body.choice,'Stop and keep current work');
});

test('a real free-text answer is Custom and keeps the typed content',async()=>{
  const call = await send('The suite lives in qa/integration and uses Chrome Grid',
    ['Retry this step safely','Stop and keep current work','Cancel']);
  assert.equal(call.body.choice,'Custom');
  assert.equal(call.body.detail,'The suite lives in qa/integration and uses Chrome Grid');
});
