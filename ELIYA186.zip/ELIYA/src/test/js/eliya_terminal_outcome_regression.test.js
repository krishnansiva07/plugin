'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const vm=require('node:vm');
const path=require('node:path');
const root=path.resolve(__dirname,'../../main');
const app=fs.readFileSync(path.join(root,'resources/static/app.js'),'utf8');
const run=fs.readFileSync(path.join(root,'java/com/llmart/llm/service/AgentRunService.java'),'utf8');
const chat=fs.readFileSync(path.join(root,'java/com/llmart/llm/service/ChatService.java'),'utf8');
const narrator=fs.readFileSync(path.join(root,'java/com/llmart/llm/service/AgentCompletionNarrator.java'),'utf8');
function functionSource(name, end){const a=app.indexOf(`function ${name}(`),b=app.indexOf(end,a);assert.ok(a>=0 && b>a,`${name} available`);return app.slice(a,b);}
const stage=functionSource('agentStageHtml','function activityAgeText');
const fallback=functionSource('agentSnapshotOutcomeText','function startAgentWatch');
const renderStage=(progress,waiting=false)=>vm.runInNewContext(`${stage};agentStageHtml(progress,waiting)`,{progress,waiting});
const fallbackAnswer=snapshot=>vm.runInNewContext(`${fallback};agentSnapshotOutcomeText(snapshot)`,{snapshot});

test('blocked after execution does not falsely paint Plan red',()=>{
 const html=renderStage({status:'blocked',phase:'blocked',failureStage:'verify',planLocked:true,activePlanIndex:0,plan:[{status:'completed'}]});
 assert.match(html,/class="agent-stage failed"[^>]*><i>!<\/i><b>Verify<\/b>/);
 assert.doesNotMatch(html,/class="agent-stage failed"[^>]*><i>!<\/i><b>Plan<\/b>/);
});
test('legacy blocked runs with finished plan do not default to red Plan',()=>{
 const html=renderStage({status:'blocked',phase:'blocked',activePlanIndex:0,planLocked:true,plan:[{status:'completed'}]});
 assert.match(html,/class="agent-stage failed"[^>]*><i>!<\/i><b>Complete<\/b>/);
});
test('genuine planning failure is marked at Plan',()=>{
 const html=renderStage({status:'blocked',phase:'blocked',failureStage:'plan',activePlanIndex:0,plan:[]});
 assert.match(html,/class="agent-stage failed"[^>]*><i>!<\/i><b>Plan<\/b>/);
});
test('terminal fallback remains truthful about incomplete work and provides next step',()=>{
 const text=fallbackAnswer({status:'blocked',plan:[{status:'completed',text:'Created framework'},{status:'in_progress',text:'Run test suite'}],lastVerification:'No test process completed',lastVerificationSuccessful:false,touchedPaths:['src/A.java'],blockReason:'Browser not available'});
 for(const expected of ['not verified complete','Created framework','Run test suite','Browser not available','No test process completed','Suggested next step','not independently verified'])assert.ok(text.includes(expected),expected);
 assert.doesNotMatch(text,/tests passed|task completed successfully/i);
});
test('backend persists stage across restarts and failure message rather than sending SSE error only',()=>{
 for(const expected of ['p.setProperty("failureStage"','run.failureStage = p.getProperty("failureStage"','map.put("failureStage"','map.put("blockReason"']) assert.ok(run.includes(expected),expected);
 for(const expected of ['catch (Exception executionFailure)','AgentCompletionNarrator.complete(prior','conversations.addMessage(conversation.getId(), "assistant", answer','agentRun.markResponsePersisted'])assert.ok(chat.includes(expected),expected);
 for(const expected of ['### What was completed','### What remains','### Verification','### Suggested next step','### Improvements and next step'])assert.ok(narrator.includes(expected),expected);
});
