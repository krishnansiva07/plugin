// ELIYA156: a clicked or exactly typed popup option must reach the backend as that exact choice.
// Reproduces the "Retry after fixing provider" bug by executing the real app.js functions with a mock API.
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const src = fs.readFileSync(path.resolve(__dirname, '../../main/resources/static/app.js'), 'utf8');

function extract(name) {
  const start = src.search(new RegExp(`(?:async )?function ${name}\\(`));
  assert.ok(start >= 0, `${name} not found`);
  const end = src.indexOf('\n}\n', start);
  return src.slice(start, end + 2);
}

function harness() {
  const sent = [];
  const sandbox = {
    sent,
    api: async (route, options) => { sent.push({ route, body: JSON.parse(options.body) }); return { answered: true }; },
    $: () => ({ value: '' }), autoGrow: () => {}, state: { messages: [] },
    renderMessages: () => {}, scrollBottom: () => {}, startAgentWatch: () => {},
  };
  const code = `${extract('matchQuestionChoice')}\n${extract('submitAgentChatAnswer')}\nreturn {matchQuestionChoice, submitAgentChatAnswer};`;
  const fns = new Function(...Object.keys(sandbox), code)(...Object.values(sandbox));
  return { ...fns, sent };
}

const pending = () => ({
  runId: 'run-1', questionId: 'q-1',
  message: { executionEngine: 'eliya', agentProgress: { question: {
    choices: ['Retry after fixing provider', 'Stop and keep current work', 'Cancel'] } } },
});

test('clicking "Retry after fixing provider" sends the exact choice, not Custom', async () => {
  const h = harness();
  await h.submitAgentChatAnswer('Retry after fixing provider', pending(), 'Retry after fixing provider');
  assert.equal(h.sent[0].body.choice, 'Retry after fixing provider');
  assert.equal(h.sent[0].body.detail, '');
});

test('typing an option (any case, trailing period) is submitted as that option', async () => {
  const h = harness();
  await h.submitAgentChatAnswer('  retry after fixing PROVIDER. ', pending());
  assert.equal(h.sent[0].body.choice, 'Retry after fixing provider');
});

test('genuine free text is still Custom with the text as detail', async () => {
  const h = harness();
  await h.submitAgentChatAnswer('Use the staging endpoint instead', pending());
  assert.deepEqual(h.sent[0].body, { questionId: 'q-1', choice: 'Custom', detail: 'Use the staging endpoint instead' });
});

test('cancel shortcut still maps to Cancel', async () => {
  const h = harness();
  await h.submitAgentChatAnswer('cancel', pending());
  assert.equal(h.sent[0].body.choice, 'Cancel');
});

test('dialog buttons and terminal composer pass the exact choice', () => {
  assert.match(src, /submitAgentChatAnswer\(response,active,custom \? null : button\.dataset\.agentDialogChoice\)/);
  assert.match(src, /terminalSubmitClarification\(id,question\.id,exact \|\| 'Custom',exact \? '' : typed\)/);
  assert.match(src, /terminalSubmitClarification\(pending\.id,pending\.question\.id,exactChoice \|\| 'Custom'/);
});
