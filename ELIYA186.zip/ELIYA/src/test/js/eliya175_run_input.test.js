// ELIYA175: input typed while the Agent runs. Executes the real app.js functions against a mock server.
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const src = fs.readFileSync(path.resolve(__dirname, '../../main/resources/static/app.js'), 'utf8');
const html = fs.readFileSync(path.resolve(__dirname, '../../main/resources/static/index.html'), 'utf8');

function extract(name) {
  const start = src.search(new RegExp(`(?:async )?function ${name}\\(`));
  assert.ok(start >= 0, `${name} not found`);
  return src.slice(start, src.indexOf('\n}\n', start) + 2);
}

function harness({ inputStatuses = {}, failPost = false, streaming = true } = {}) {
  const calls = [], toasts = [], sent = [];
  const elements = {};
  const el = id => elements[id] || (elements[id] = { value: '', innerHTML: '', classList: { toggle() {} } });
  const context = {
    calls, toasts, sent, elements,
    $: el, esc: v => String(v), toast: m => toasts.push(m), autoGrow() {}, refreshChatComposer() {},
    setInterval: () => 1, clearInterval() {}, setTimeout: (fn) => fn(),
    encodeURIComponent, JSON, Date, String, Set, Promise,
    state: { streaming, conversationId: 'c1', activeAgentRunId: 'run-1',
      messages: [{ role: 'assistant', streaming: true, mode: 'agent', agentRunId: 'run-1' }] },
    runInputState: { items: [], next: [], pollTimer: null, userStopped: false },
    sendMessage: async ({ overrideMessage }) => sent.push(overrideMessage),
    api: async (url, options = {}) => {
      calls.push({ url, method: options.method || 'GET', body: options.body ? JSON.parse(options.body) : null });
      if (options.method === 'POST') { if (failPost) throw new Error('HTTP 409'); return { id: 'in-1', status: 'pending', queued: true }; }
      if (options.method === 'DELETE') return { withdrawn: true };
      return { inputs: Object.entries(inputStatuses).map(([id, status]) => ({ id, status })) };
    },
  };
  const names = ['runInputTargetRunId', 'addInputWhileRunning', 'ensureRunInputPolling', 'refreshRunInputStatus',
    'withdrawRunInput', 'onRunFinishedForInputQueue', 'renderRunInputQueue'];
  vm.runInNewContext(names.map(extract).join('\n') + `\nthis.fns = {${names.join(',')}};`, context);
  return context;
}

test('input during an Agent run is posted to the running task, not started as a new task', async () => {
  const h = harness();
  h.elements.messageInput = { value: 'Also update the README' };
  await h.fns.addInputWhileRunning('Also update the README', 'task');
  assert.equal(h.calls[0].url, '/api/agent/runs/run-1/input');
  assert.deepEqual(h.calls[0].body, { text: 'Also update the README' });
  assert.equal(h.runInputState.items[0].status, 'pending');
  assert.equal(h.elements.messageInput.value, '');
  assert.match(h.elements.runInputQueue.innerHTML, /After current action/);
});

test('queue-next holds the input and starts it as the next task when the run finishes', async () => {
  const h = harness();
  await h.fns.addInputWhileRunning('Now add integration tests', 'next');
  assert.equal(h.calls.length, 0);
  assert.match(h.elements.runInputQueue.innerHTML, /Next task/);
  h.state.streaming = false;
  await h.fns.onRunFinishedForInputQueue();
  assert.deepEqual(h.sent, ['Now add integration tests']);
  assert.equal(h.runInputState.next.length, 0);
});

test('if the task already finished, "add to task" falls back to queue-next (nothing is lost)', async () => {
  const h = harness({ failPost: true });
  await h.fns.addInputWhileRunning('One more thing', 'task');
  assert.equal(h.runInputState.next[0].text, 'One more thing');
});

test('input the Agent never picked up is moved to the next-task queue', async () => {
  const h = harness({ inputStatuses: { 'in-1': 'undelivered' } });
  h.runInputState.items.push({ id: 'in-1', runId: 'run-1', text: 'Late note', status: 'pending', conversationId: 'c1' });
  await h.fns.refreshRunInputStatus();
  assert.equal(h.runInputState.next[0].text, 'Late note');
  assert.equal(h.runInputState.items.length, 0);
});

test('delivered inputs are shown as delivered', async () => {
  const h = harness({ inputStatuses: { 'in-1': 'delivered' } });
  h.runInputState.items.push({ id: 'in-1', runId: 'run-1', text: 'Note', status: 'pending', conversationId: 'c1' });
  await h.fns.refreshRunInputStatus();
  assert.match(h.elements.runInputQueue.innerHTML, /Delivered to the task/);
});

test('after the user presses Stop, queued tasks wait for an explicit "Send now"', async () => {
  const h = harness();
  h.runInputState.next.push({ id: 'n1', text: 'Next', conversationId: 'c1' });
  h.runInputState.userStopped = true;
  h.state.streaming = false;
  await h.fns.onRunFinishedForInputQueue();
  assert.deepEqual(h.sent, []);
  h.fns.renderRunInputQueue();
  assert.match(h.elements.runInputQueue.innerHTML, /Send now/);
});

test('a queued task from another conversation is not started here', async () => {
  const h = harness();
  h.runInputState.next.push({ id: 'n1', text: 'Other tab', conversationId: 'c2' });
  h.state.streaming = false;
  await h.fns.onRunFinishedForInputQueue();
  assert.deepEqual(h.sent, []);
});

test('Analyse (chat) streaming has no run to join, so input goes to queue-next', () => {
  const h = harness();
  h.state.messages = [{ role: 'assistant', streaming: true, mode: 'chat' }];
  assert.equal(h.fns.runInputTargetRunId(), null);
});

test('wiring: composer, buttons, panel and terminal button exist', () => {
  assert.match(src, /if \(state\.streaming\) \{\s*\/\/ Input while a task is running/);
  assert.match(html, /id="queueNextBtn"/);
  assert.match(html, /id="runInputQueue"/);
  assert.match(html, /id="terminalAddToRunBtn"/);
  assert.match(src, /\/api\/agent\/runs\/\$\{encodeURIComponent\(runId\)\}\/input/);
  // declared at the top so startup rendering cannot hit the temporal dead zone
  assert.ok(src.indexOf('const runInputState') < src.indexOf('function setStreaming('));
  assert.ok(src.indexOf('const runInputState') < 400);
});
