const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const html = fs.readFileSync(path.join(__dirname, '../../main/resources/static/index.html'), 'utf8');
test('app branding has no release suffix', () => {
  assert.match(html, /<title>ELIYA<\/title>/);
  assert.match(html, /class="brand-text">ELIYA<\/span>/);
  assert.doesNotMatch(html, /<title>\s*ELIYA\s*(?:v?\d+)/i);
  assert.doesNotMatch(html, /class="brand-text">\s*ELIYA\s*(?:v?\d+)/i);
});
