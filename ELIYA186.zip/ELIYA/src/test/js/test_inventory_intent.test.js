const test = require('node:test');
const assert = require('node:assert/strict');
const response = require('../../main/resources/static/response-experience.js');

test('a count of workspace test cases is an inventory question, not a verification', () => {
  const question = 'can you check how many test cases present';
  assert.equal(response.intent(question), 'inventory');
  const result = response.result({question, answer:'One statically declared test found in tests/auth/login.spec.ts.', mode:'chat'});
  assert.notEqual(result.intent, 'verification');
  assert.notEqual(result.status, 'unverified');
});
test('verification of a migration still uses the verification safeguard', () => {
  const result = response.result({question:'verify migration is complete',answer:'Not checked',mode:'chat'});
  assert.equal(result.intent, 'verification');
  assert.equal(result.status, 'unverified');
});
