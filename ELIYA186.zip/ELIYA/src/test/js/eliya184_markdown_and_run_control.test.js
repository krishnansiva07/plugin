'use strict';
// ELIYA184: (1) answers wrapped in a ```markdown fence render as Markdown instead of raw text in a dark code box;
// (2) stop / skip / status typed while the Agent runs are shown for what they are; (3) an Agent report is not
// forced into the dark prompt-source viewer. Executes the real markdown.js and app.js functions.
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const root = path.join(__dirname, '../../main/resources/static');
const scope = { window: {} };
vm.runInNewContext(fs.readFileSync(path.join(root, 'markdown.js'), 'utf8'), scope);
const { render, unwrapAnswerFence } = scope.window.MarkdownRenderer;
const app = fs.readFileSync(path.join(root, 'app.js'), 'utf8');

function extract(name) {
  const start = app.search(new RegExp(`(?:async )?function ${name}\\(`));
  assert.ok(start >= 0, `${name} not found`);
  return app.slice(start, app.indexOf('\n}\n', start) + 2);
}

const wrapped = '```markdown\n## Test results\n\n| Suite | Result |\n|---|---|\n| OrderServiceTest | **passed** |\n\n- 42 tests\n```';

test('an answer wrapped in ```markdown renders as Markdown (no dark code block)', () => {
  const html = render(wrapped, { answer: true });
  assert.match(html, /<h2 class="md-h md-h2">Test results<\/h2>/);
  assert.match(html, /<table class="md-table">/);
  assert.match(html, /<strong>passed<\/strong>/);
  assert.ok(!/<div class="md-unwrapped">[\s\S]*class="code-block/.test(html.split('<details')[0]), 'body is not a code block');
  assert.match(html, /<details class="md-source"><summary>Markdown source<\/summary>/, 'source stays available');
});

test('without the answer option (composer preview) a fence stays a code block', () => {
  assert.match(render(wrapped), /class="code-block/);
  assert.ok(!/md-unwrapped/.test(render(wrapped)));
});

test('nested code blocks survive, real code and source requests stay code', () => {
  const nested = '```md\n# Report\n\n```java\nint x = 1;\n```\n\nDone\n```';
  const u = unwrapAnswerFence(nested);
  assert.equal(u.inner, '# Report\n\n```java\nint x = 1;\n```\n\nDone');
  assert.match(render(nested, { answer: true }), /data-lang="java"/);
  assert.equal(unwrapAnswerFence('```\npublic class A {\n  int x;\n}\n```'), null, 'bare code fence untouched');
  assert.equal(unwrapAnswerFence('```bash\nmvn test\n```'), null);
  assert.equal(unwrapAnswerFence("Here's the README.md content:\n```markdown\n# Title\n```"), null, 'explicit source kept');
  assert.equal(unwrapAnswerFence('## plain markdown\n- ok'), null);
});

test('intro line and appended test report are kept around the unwrapped answer', () => {
  const u = unwrapAnswerFence('Here is the summary:\n\n```markdown\n## Done\n- a\n```\n\n---\n\n### Tests\n```text\nTests run: 3\n```');
  assert.equal(u.intro, 'Here is the summary:');
  assert.equal(u.inner, '## Done\n- a');
  assert.equal(u.outro, '---\n\n### Tests\n```text\nTests run: 3\n```');
});

test('a bare fence around Markdown prose is unwrapped, streaming shows no source panel', () => {
  const prose = '```\n## Summary\n| a | b |\n|---|---|\n| 1 | 2 |\n```';
  const html = render(prose, { answer: true, streaming: true });
  assert.match(html, /md-table/);
  assert.ok(!/md-source/.test(html));
});

test('stop / skip / status replies are shown in the run-input panel', async () => {
  const toasts = [];
  const elements = {};
  const el = id => elements[id] || (elements[id] = { value: '', innerHTML: '', classList: { toggle() {} } });
  let reply = { id: 'in-1', status: 'stopping', kind: 'stop', reply: 'Stopping the current action' };
  const context = {
    $: el, esc: v => String(v), toast: m => toasts.push(m), autoGrow() {}, refreshChatComposer() {},
    setInterval: () => 1, clearInterval() {}, setTimeout: fn => fn(), encodeURIComponent, JSON, Date, String, Set, Promise,
    state: { streaming: true, conversationId: 'c1', activeAgentRunId: 'run-1',
      messages: [{ role: 'assistant', streaming: true, mode: 'agent', agentRunId: 'run-1' }] },
    runInputState: { items: [], next: [], pollTimer: null, userStopped: false },
    sendMessage: async () => {},
    api: async () => reply,
  };
  const names = ['runInputTargetRunId', 'addInputWhileRunning', 'ensureRunInputPolling', 'renderRunInputQueue'];
  vm.runInNewContext(names.map(extract).join('\n') + `\nthis.fns = {${names.join(',')}};`, context);
  await context.fns.addInputWhileRunning('stop running the last instruction and show me the results so far', 'task');
  assert.equal(context.runInputState.userStopped, true, 'queued next tasks do not auto-start after a stop');
  assert.match(toasts.at(-1), /Stopping now/);
  assert.match(el('runInputQueue').innerHTML, /Stopping now/);

  reply = { id: 'in-2', status: 'answered', kind: 'status', reply: 'Running for 2m 5s · now: git push' };
  await context.fns.addInputWhileRunning('status', 'task');
  assert.match(el('runInputQueue').innerHTML, /run-input-reply">Running for 2m 5s/);
  assert.match(el('runInputQueue').innerHTML, /data-run-input-dismiss="in-2"/);

  reply = { id: 'in-3', status: 'skipping', kind: 'skip', reply: '' };
  await context.fns.addInputWhileRunning('skip this step', 'task');
  assert.match(el('runInputQueue').innerHTML, /Skipping this step/);
  assert.match(toasts.at(-1), /Skipping the current step/);
});

test('an Agent report is not forced into the dark prompt viewer', () => {
  const context = {};
  vm.runInNewContext(extract('agentAnswerIsPromptDocument') + '\nthis.fn = agentAnswerIsPromptDocument;', context);
  assert.equal(context.fn('## Outcome\nTests pass. Files changed: `A.java`.'), false);
  assert.equal(context.fn('## Prompt 1: Migrate the framework\nDo X and verify.'), true);
  assert.equal(context.fn('```markdown\n' + 'Implement the change and verify with mvn test. '.repeat(8) + '\n```'), true);
  assert.match(app, /isPromptRequest\?\.\(precedingText\) &&\s*\(message\.mode !== 'agent' \|\| agentAnswerIsPromptDocument\(displayContent\)\)/);
});
