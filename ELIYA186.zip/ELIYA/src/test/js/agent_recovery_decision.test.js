const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const agent = fs.readFileSync('src/main/java/com/llmart/llm/service/AgentService.java','utf8');
const questions = fs.readFileSync('src/main/java/com/llmart/llm/service/AgentQuestionService.java','utf8');
const controller = fs.readFileSync('src/main/java/com/llmart/llm/controller/AgentController.java','utf8');
const app = fs.readFileSync('src/main/resources/static/app.js','utf8');

test('unchanged-step stalls ask, not endless silent replan', () => {
  assert.match(agent,/recoveryEscalations\.computeIfAbsent/);
  assert.match(agent,/escalation\.needsDecision\(run\.activePlanIndex\(\), run\.mutationRevision\(\)\)/);
  assert.match(agent,/questions\.ask\(run\.id\(\), question,/);
  assert.match(agent,/escalation\.continueSameScope\(\)/);
});
test('all six fallback exhaustion outcomes honor a user pause', () => {
  const matches = agent.match(/completionStatus = recovery\.userPaused\(\) \? "blocked" : "failed";/g) || [];
  assert.equal(matches.length,6);
  assert.match(agent,/recoveryEscalations\.remove\(run\.id\(\)\)/);
});
test('question uses same run, run-bound answer and cancellation', () => {
  assert.match(questions,/questions\.putIfAbsent\(runId, pending\)/);
  assert.match(questions,/run\.checkCancelled\(\)/);
  assert.match(controller,/@PostMapping\("\/runs\/\{id\}\/answer"\)/);
  assert.match(controller,/"Cancel"\.equalsIgnoreCase\(choice\)\) runs\.cancel\(id\)/);
});
test('Agent chat offers actionable recovery choices through existing run-bound endpoint', () => {
  assert.match(app,/data-agent-recovery-choice/);
  assert.match(app,/pending\.questionId !== recoveryChoice\.dataset\.agentRecoveryQuestion/);
  assert.match(app,/submitAgentChatAnswer\(recoveryChoice\.dataset\.agentRecoveryChoice, pending\)/);
  assert.match(app,/api\/agent\/runs\/\$\{encodeURIComponent\(pending\.runId\)\}\/answer/);
});
