const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const root=path.resolve(__dirname,'../../..');
const source=fs.readFileSync(path.join(root,'src/main/resources/static/skills.js'),'utf8');
const html=fs.readFileSync(path.join(root,'src/main/resources/static/index.html'),'utf8');
function harness(){
 const nodes=new Map(),calls=[];let selectedScope='workspace';
 function element(){return {children:[],value:'',textContent:'',options:[{}],append(...n){this.children.push(...n)},replaceChildren(){this.children=[]},setAttribute(){},focus(){},addEventListener(){},showModal(){this.open=true},close(){this.open=false}};}
 const document={getElementById(id){if(!nodes.has(id))nodes.set(id,element());return nodes.get(id)},createElement(){return element()}};
 const skill={name:'qa-skill',source:'project',description:'QA checks',enabled:true,aliases:[]};
 const api=async(url,opt)=>{calls.push({url,opt});if(opt?.method==='PUT'){if(url.includes('/enabled'))skill.enabled=JSON.parse(opt.body).enabled;return {saved:true};}if(url.includes('/qa-skill'))return {content:'---\nname: qa-skill\ndescription: QA checks\n---\n# QA'};return [skill];};
 const context=vm.createContext({document,api,state:{project:{localWorkspace:true,id:'p-1'}},window:{confirm:()=>true},confirm:()=>true,Blob,URL,setTimeout});
 vm.runInContext(source,context);
 return {get:document.getElementById,calls,skill};
}
const flush=()=>new Promise(resolve=>setImmediate(resolve));
test('skill manager markup has unique controls and loads after app',()=>{
 for(const id of ['skillManagerBtn','skillManagerDialog','skillScope','skillSearch','skillList','skillContent','skillSave','skillExport'])assert.equal(html.split(`id="${id}"`).length,2,id);
 assert.ok(html.indexOf('/skills.js')>html.indexOf('/app.js'));
});
test('manager loads scope, toggles enabled, edits and saves via explicit scoped PUT',async()=>{
 const h=harness();h.get('skillManagerBtn').onclick();await flush();
 assert.equal(h.calls[0].url,'/api/skills?projectId=p-1');
 assert.equal(h.get('skillManagerDialog').open,true);
 const item=h.get('skillList').children[0];await item.children[1].onclick();await flush();
 assert.equal(h.skill.enabled,false);
 assert.equal(h.calls.find(x=>x.url.includes('/enabled')).url,'/api/skills/qa-skill/enabled?projectId=p-1');
 await h.get('skillList').children[0].children[0].onclick();await flush();
 assert.match(h.get('skillContent').value,/# QA/);
 h.get('skillContent').value+='\nUpdated';h.get('skillContent').oninput();
 await h.get('skillSave').onclick();await flush();
 const put=h.calls.find(x=>x.opt?.method==='PUT'&&!x.url.includes('/enabled'));
 assert.equal(put.url,'/api/skills/qa-skill?projectId=p-1');assert.equal(JSON.parse(put.opt.body).overwrite,true);
});
