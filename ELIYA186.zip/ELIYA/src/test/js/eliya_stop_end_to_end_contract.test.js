'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');

const root = path.resolve(__dirname, '../../main');
const app = fs.readFileSync(path.join(root,'resources/static/app.js'), 'utf8');
const server = fs.readFileSync(path.join(root,'java/com/llmart/llm/service/AgentRunService.java'), 'utf8');
const controller = fs.readFileSync(path.join(root,'java/com/llmart/llm/controller/AgentController.java'), 'utf8');
const chat = fs.readFileSync(path.join(root,'java/com/llmart/llm/service/ChatService.java'), 'utf8');
const agent = fs.readFileSync(path.join(root,'java/com/llmart/llm/service/AgentService.java'), 'utf8');
const stopStart = app.indexOf('let stopRequestPending144=false;');
const stopEnd = app.indexOf('function stopAgentWatch()', stopStart);
assert.ok(stopStart >= 0 && stopEnd > stopStart, 'Stop implementation is available for executable UI tests');
const stopSource = app.slice(stopStart, stopEnd);

function mockStop({mode='agent', runId='run-123', globalRunId=runId, conversation='conv-123',
                    engine='legacy', response={stopAccepted:true, finished:false, status:'cancelling'},
                    networkError, streaming=true}={}) {
  const calls=[], notices=[], button={disabled:false, textContent:'Stop'};
  const message={role:'assistant', mode, streaming, executionEngine:engine};
  if(runId) message.agentRunId=runId;
  let aborts=0, renders=0;
  const state={messages:[message], activeAgentRunId:globalRunId, conversationId:conversation,
    abortController:{abort:()=>aborts++}};
  const env={state, encodeURIComponent, console,
    $:(id)=>id==='runStatusStop'?button:null,
    api:async(url,opts)=>{calls.push({url,opts});if(networkError)throw networkError;return response;},
    toast:(msg)=>notices.push(msg),
    renderRunStatusStrip:()=>renders++};
  vm.createContext(env);
  vm.runInContext(stopSource,env);
  return {run:()=>vm.runInContext('stopCurrentRun()',env), calls, notices, button,
    state, message, get aborts(){return aborts},get renders(){return renders}};
}

test('positive: Stop targets the active native Agent run and retains durable polling', async()=>{
 const h=mockStop(); await h.run();
 assert.equal(h.calls.length,1);
 assert.equal(h.calls[0].url,'/api/agent/runs/run-123/cancel');
 assert.equal(h.calls[0].opts.method,'POST');
 assert.equal(h.aborts,1);
 assert.equal(h.message.agentStopConfirmed,true);
 assert.equal(h.button.disabled,false);
 assert.ok(h.notices.some(note=>/Waiting for the backend worker/.test(note)));
});

test('negative: unconfirmed Stop keeps SSE alive for retry, and does not claim cancelled', async()=>{
 const h=mockStop({response:{cancelled:false,finished:false,status:'running'}}); await h.run();
 assert.equal(h.aborts,0);
 assert.equal(h.message.agentStopConfirmed,false);
 assert.match(h.notices.join('\n'),/not confirmed/i);
 await h.run(); assert.equal(h.calls.length,2,'retry should be possible');
});

test('negative: offline backend does not close live stream', async()=>{
 const h=mockStop({networkError:new Error('backend unavailable')}); await h.run();
 assert.equal(h.aborts,0);assert.equal(h.message.agentStopConfirmed,false);
 assert.match(h.notices.join('\n'),/backend unavailable/);
});

test('negative: pending Agent without run ID is never falsely reported stopped', async()=>{
 const h=mockStop({runId:null,globalRunId:null}); await h.run();
 assert.equal(h.calls.length,0);assert.equal(h.aborts,0);
 assert.match(h.notices.join('\n'),/run ID not available/i);
});

test('positive: OpenCode session cancellation uses the correct backend', async()=>{
 const h=mockStop({engine:'opencode',response:{status:'cancelled',finished:true}});
 await h.run(); assert.equal(h.calls[0].url,'/api/terminal/sessions/run-123/cancel');
 assert.equal(h.aborts,1);
});

test('negative: OpenCode active session not confirmed returns retryable status', async()=>{
 const h=mockStop({engine:'opencode',response:{status:'running'}});await h.run();
 assert.equal(h.aborts,0);assert.equal(h.message.agentStopConfirmed,false);
});

test('positive: Analyse/Chat stop routes to conversation cancellation', async()=>{
 const h=mockStop({mode:'chat',runId:null,globalRunId:'stale-agent-run',response:{cancelled:true}});
 await h.run();assert.equal(h.calls[0].url,'/api/chat/cancel?conversationId=conv-123');
 assert.equal(h.aborts,1);assert.equal(h.message.chatStopConfirmed,true);
});

test('negative: Analyse/Chat backend refusal preserves stream for retry', async()=>{
 const h=mockStop({mode:'chat',runId:null,globalRunId:null,response:{cancelled:false}});
 await h.run();assert.equal(h.aborts,0);assert.equal(h.message.chatStopConfirmed,false);
});

test('negative: a stale global run cannot override the currently streaming message run', async()=>{
 const h=mockStop({runId:'correct-run',globalRunId:'other-tab-run'});
 await h.run();assert.equal(h.calls[0].url,'/api/agent/runs/correct-run/cancel');
});

test('positive: repeated Stop requests are accepted while worker is winding down',()=>{
 assert.match(server,/if \(!cancelled\.compareAndSet\(false, true\)\) return true;/);
 assert.match(server,/private final AtomicReference<Thread> activeWorker/);
 assert.match(server,/worker\.interrupt\(\)/);
 assert.match(server,/if \(cancelled\(\)\) status = "cancelled";/);
 assert.match(server,/if \(cancelled\(\) \|\| finished\(\)\) return;/);
});

test('positive: Agent stop releases approvals, questions, and tracked processes',()=>{
 for(const pattern of [/approvals\.cancelRun\(id\)/,/questions\.cancel\(id\)/,/workspaces\.stopRunProcesses\(id\)/,
   /result\.put\("finished", run\.finished\(\)\)/,/result\.put\("status", run\.status\(\)\)/])
   assert.match(controller,pattern);
});

test('positive: Agent run ID exists before slow context assembly and supports interrupt',()=>{
 assert.ok(chat.indexOf('agentRun = agentRuns.start(') < chat.indexOf('contextService.build('));
 assert.ok(chat.indexOf('agentRun.registerWorker(Thread.currentThread())') < chat.indexOf('contextService.build('));
 assert.match(chat,/preparationCancelled, readPrimaryEvidence/);
 assert.match(chat,/if \(agentRun != null\) agentRun\.checkCancelled\(\);/);
 assert.match(chat,/agentRun\.unregisterWorker\(Thread\.currentThread\(\)\)/);
});

test('negative: cancellation is never converted to a successful or failed completed workflow',()=>{
 assert.match(chat,/if \(agentRun != null && agentRun\.cancelled\(\)\) \{/);
 assert.match(chat,/if \(agentRun\.cancelled\(\)\) throw new AgentCancelledException\("Agent stopped before final response persistence"\)/);
 assert.match(agent,/if \(run\.cancelled\(\)\) \{\s*run\.finish\("cancelled"\);/);
});
