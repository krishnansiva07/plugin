const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const root=path.resolve(__dirname,'../../main/resources/static');
test('modern-only shell loads after existing application',()=>{
 const html=fs.readFileSync(path.join(root,'index.html'),'utf8');
 assert.match(html,/href="\/modern153\.css"/);
 assert.match(html,/src="\/modern153\.js"/);
 assert.ok(html.indexOf('/modern153.js')>html.indexOf('/app.js'));
 assert.doesNotMatch(html,/>\s*(Modern UI|Classic UI)\s*</);
 assert.match(html,/<title>ELIYA<\/title>/);
});
test('modern shell supports collapsible sidebar without classic toggle',()=>{
 const code=fs.readFileSync(path.join(root,'modern153.js'),'utf8');
 assert.match(code,/eliyaSidebarToggle/);
 assert.match(code,/eliya\.navigation\.collapsed/);
 assert.match(code,/aria-expanded/);
 assert.doesNotMatch(code,/Classic UI|eliya\.ui\.modern\.enabled/);
});
