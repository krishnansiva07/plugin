const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const html = fs.readFileSync('src/main/resources/static/index.html','utf8');
const app = fs.readFileSync('src/main/resources/static/app.js','utf8');
const service = fs.readFileSync('src/main/java/com/llmart/llm/service/ProtectedRunSnapshotService.java','utf8');
const intent = fs.readFileSync('src/main/java/com/llmart/llm/service/AgentConversationIntent.java','utf8');
const agent = fs.readFileSync('src/main/java/com/llmart/llm/service/AgentService.java','utf8');

test('rollback limits are separate from indexing and editable via persistent Settings',()=>{
  for (const id of ['rollbackMaxFiles','rollbackMaxSizeMb','rollbackTimeoutSeconds','applyRollbackSettings'])
    assert.match(html, new RegExp(`id="${id}"`));
  assert.match(app,/api\/settings\/rollback/);
  assert.match(app,/loadRollbackSettings\(\)/);
  assert.match(app,/persistRollbackSettings\(\)/);
  assert.match(html,/Read-only analysis does not need a rollback snapshot/);
});

test('runtime snapshot limits are taken from saved settings per run and never disable protection',()=>{
  assert.match(service,/rollbackSettings\.current\(\)/);
  assert.match(service,/limits\.maxFiles\(\)/);
  assert.match(service,/limits\.maxBytes\(\)/);
  assert.match(service,/limits\.timeoutSeconds\(\)/);
  assert.match(service,/This is not an indexing limit/);
  assert.match(intent,/REQUESTED_OUTPUT_FILE/);
  assert.match(agent,/boolean readOnlyQuestion = AgentConversationIntent\.isFastReadOnly\(request\.message\(\)\)/);
  assert.match(agent,/if \(!investigationOnly\)/);
});
