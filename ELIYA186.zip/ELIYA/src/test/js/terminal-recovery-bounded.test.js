const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const source = fs.readFileSync(path.join(__dirname, '../../main/java/com/llmart/llm/service/TerminalSessionService.java'), 'utf8');
test('terminal history selects bounded newest checkpoints and rejects symlinks', () => {
  assert.match(source, /newestSessionFiles\(files, MAX_SESSIONS\)/);
  assert.match(source, /PriorityQueue<Path> newest/);
  assert.match(source, /LinkOption\.NOFOLLOW_LINKS/);
  assert.match(source, /result\.sort\(oldestFirst\.reversed\(\)\)/);
});
