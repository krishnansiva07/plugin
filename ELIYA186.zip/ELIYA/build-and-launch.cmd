@echo off
setlocal EnableExtensions
cd /d "%~dp0"
where java >nul 2>nul
if errorlevel 1 (
  echo Java 17 or newer is required on PATH.
  exit /b 1
)
call build-jar-windows.cmd
if errorlevel 1 (
  echo Build or tests did not pass. ELIYA was NOT launched.
  exit /b 1
)
java -jar "target\eliya.jar" --browser
exit /b %errorlevel%
