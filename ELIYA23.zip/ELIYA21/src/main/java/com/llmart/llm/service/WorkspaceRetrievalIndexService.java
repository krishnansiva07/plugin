package com.llmart.llm.service;

import com.llmart.llm.dto.ChatSettings;

import org.apache.tika.Tika;
import org.springframework.stereotype.Service;

import java.io.InputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Pattern;

/**
 * Hybrid workspace retrieval for Agent mode.
 *
 * A deterministic local lexical index is always available as the zero-dependency baseline. When semantic retrieval
 * is enabled and an embedding model is configured, the strongest lexical candidates are reranked semantically.
 * Provider/embedding failures never block the agent: retrieval falls back to lexical results automatically.
 * The live filesystem remains authoritative; returned snippets are retrieval hints only.
 */
@Service
public class WorkspaceRetrievalIndexService {
    private static final int MAX_FILES = positiveIntProperty("eliya.index.maxFiles", 16_000, 2_000, 200_000);
    private static final int MAX_SCANNED_FILES = positiveIntProperty("eliya.index.maxScannedFiles", 50_000, 5_000, 500_000);
    private static final int MAX_INDEXED_FILE_BYTES = positiveIntProperty("eliya.index.maxFileBytes", 192_000, 32_000, 2_000_000);
    // Office/PDF files are compressed containers, not UTF-8 text. Keep a separate, bounded
    // binary document limit rather than excluding legitimate requirements documents.
    private static final int MAX_INDEXED_DOCUMENT_BYTES = positiveIntProperty("eliya.index.maxDocumentBytes", 8_000_000, 192_000, 32_000_000);
    private static final int MAX_SAMPLED_CHARS_PER_FILE = 36_000;
    private static final int MAX_TERMS_PER_FILE = 220;
    private static final int DEFAULT_RESULT_LIMIT = 8;
    private static final int DEFAULT_MAX_CHARS = 8_000;
    private static final Pattern SPLIT = Pattern.compile("[^A-Za-z0-9_.$-]+");
    private static int positiveIntProperty(String name, int fallback, int min, int max) {
        try {
            int value = Integer.parseInt(System.getProperty(name, Integer.toString(fallback)));
            return Math.max(min, Math.min(max, value));
        } catch (Exception ignored) {
            return fallback;
        }
    }

    private static final Set<String> SKIP_DIRS = Set.of(
            ".git", ".idea", ".vscode", "node_modules", "target", "build", "dist", "out", ".gradle",
            ".next", "coverage", ".venv", "venv", "vendor", ".terraform", ".dart_tool", ".cache", "bin", "obj"
    );
    private static final Set<String> INDEX_EXTENSIONS = Set.of(
            "java", "kt", "kts", "groovy", "scala", "xml", "properties", "yml", "yaml", "json", "jsonc",
            "js", "jsx", "ts", "tsx", "mjs", "cjs", "py", "go", "rs", "rb", "php", "cs", "fs", "fsx",
            "swift", "dart", "c", "h", "cc", "cpp", "cxx", "hpp", "sql", "sh", "bash", "zsh", "ps1",
            "md", "txt", "html", "htm", "css", "scss", "less", "vue", "svelte", "tf", "hcl", "toml"
    );
    private static final Set<String> DOCUMENT_EXTENSIONS = Set.of("docx", "pdf", "xlsx", "pptx");
    private static final Set<String> IMPORTANT_NAMES = Set.of(
            "pom.xml", "build.gradle", "build.gradle.kts", "settings.gradle", "settings.gradle.kts", "package.json",
            "pyproject.toml", "requirements.txt", "go.mod", "cargo.toml", "composer.json", "gemfile", "makefile",
            "cmakelists.txt", "build.xml", "jenkinsfile", "dockerfile", "compose.yml", "compose.yaml", "agents.md",
            "claude.md", "readme.md", "application.properties", "application.yml", "application.yaml"
    );
    private static final Set<String> STOP = Set.of(
            "the", "and", "for", "that", "this", "with", "from", "have", "will", "would", "could", "should",
            "into", "about", "your", "you", "are", "was", "were", "how", "can", "use", "using", "file", "files",
            "project", "agent", "step", "plan", "task", "work", "working", "issue", "issues", "test", "tests",
            "then", "when", "where", "what", "which", "there", "their", "them", "need", "needs", "make"
    );

    private static final Set<String> SECRET_NAMES = Set.of(".env", "credentials", "secrets", "id_rsa", "id_ed25519");
    private final Map<String, WorkspaceIndex> cache = new ConcurrentHashMap<>();
    private final Map<String, String> semanticResultCache = new ConcurrentHashMap<>();
    private final OpenAiCompatibleClient llm;

    public WorkspaceRetrievalIndexService(OpenAiCompatibleClient llm) {
        this.llm = llm;
    }

    /** Index a user-selected folder immediately, without starting an Agent run. */
    public IndexStats warmRoot(String projectId, Path root) {
        return refresh(AgentWorkspaceService.Workspace.forIndex(projectId, root));
    }

    /** Never trigger a filesystem walk from a user-facing Chat or status request. */
    public IndexStats cachedStats(String projectId, Path root) {
        WorkspaceIndex cached = cache.get(projectId + "|" + root.toAbsolutePath().normalize());
        return cached == null ? null : cached.stats();
    }

    public String retrieveCachedRoot(String projectId, Path root, String query, int limit, int maxChars) {
        if (query == null || query.isBlank()) return "";
        WorkspaceIndex idx = cache.get(projectId + "|" + root.toAbsolutePath().normalize());
        if (idx == null) return "";
        var ws = AgentWorkspaceService.Workspace.forIndex(projectId, root);
        Set<String> queryTerms = terms(query);
        List<ScoredFile> matched = score(idx, query);
        // A question like "how does the attached project work?" is NOT a request for a file
        // whose contents contain "attached". Always supply a real manifest and useful entry
        // points for overview/no-match requests instead of claiming that no project was provided.
        if (isOverviewRequest(query) || queryTerms.isEmpty() || matched.isEmpty())
            return projectOverview(idx, maxChars, !matched.isEmpty() ? matched : List.of());
        return render(ws, query, queryTerms, matched, limit, maxChars, "local cached lexical index");
    }

    private boolean isOverviewRequest(String query) {
        String q = query.toLowerCase(Locale.ROOT);
        boolean workspace = q.matches("(?s).*\\b(project|codebase|repository|repo|workspace|application|app)\\b.*");
        boolean overview = q.matches("(?s).*\\b(overview|architecture|structure|walkthrough|explain|describe|understand)\\b.*")
                || q.matches("(?s).*\\b(how|what)\\b.*\\b(works|work|does|built)\\b.*");
        return workspace && overview;
    }

    private String projectOverview(WorkspaceIndex idx, int maxChars, List<ScoredFile> matches) {
        int budget = Math.max(1_000, Math.min(maxChars, 24_000));
        StringBuilder out = new StringBuilder("ACTIVE LOCAL PROJECT: indexed codebase evidence (not a chat attachment).\n");
        out.append("Indexed source/config files: ").append(idx.files().size()).append(".\nFile tree:\n");
        List<IndexedFile> sorted = new ArrayList<>(idx.files());
        sorted.sort(Comparator.comparing(IndexedFile::path, String.CASE_INSENSITIVE_ORDER));
        int treeLimit = Math.min(6_000, budget / 3);
        for (IndexedFile file : sorted) {
            String line = "- " + file.path() + "\n";
            if (out.length() + line.length() > treeLimit) { out.append("... [file tree truncated]\n"); break; }
            out.append(line);
        }

        // Use only already-cached, bounded samples. No directory walk, network call or DB load
        // is allowed during Chat context construction. Prioritise documented entry points.
        LinkedHashMap<String, IndexedFile> selected = new LinkedHashMap<>();
        for (ScoredFile match : matches) selected.put(match.file().path(), match.file());
        sorted.sort(Comparator.comparingInt((IndexedFile file) -> overviewPriority(file.path()))
                .thenComparing(IndexedFile::path, String.CASE_INSENSITIVE_ORDER));
        for (IndexedFile file : sorted) selected.putIfAbsent(file.path(), file);
        out.append("\nRelevant project entry points / cached source excerpts:\n");
        int included = 0;
        for (IndexedFile file : selected.values()) {
            if (included >= 10 || out.length() >= budget - 300) break;
            if (file.sample().isBlank()) continue;
            int room = Math.min(1_700, budget - out.length() - file.path().length() - 100);
            if (room < 120) break;
            String snippet = redact(clip(file.sample().replace("\r", ""), room));
            out.append("\n--- ").append(file.path()).append(" ---\n").append(snippet).append('\n');
            included++;
        }
        out.append("\nThis is a bounded overview. For detailed implementation questions, retrieve matching files; ")
                .append("do not infer behavior unsupported by the excerpts.\n");
        return clip(out.toString(), budget);
    }

    private int overviewPriority(String path) {
        String name = Path.of(path).getFileName().toString().toLowerCase(Locale.ROOT);
        if (name.equals("readme.md") || name.equals("agents.md")) return 0;
        if (name.equals("pom.xml") || name.equals("package.json") || name.equals("build.gradle") || name.equals("pyproject.toml")) return 1;
        if (name.equals("application.yml") || name.equals("application.yaml") || name.equals("application.properties")) return 2;
        if (name.equals("app.java") || name.equals("main.java") || name.equals("main.py") || name.equals("index.ts")
                || name.equals("index.js") || name.equals("app.ts") || name.equals("app.js") || name.equals("server.js")) return 3;
        if (name.endsWith("application.java") || name.endsWith("controller.java") || name.endsWith("service.java")) return 4;
        if (isImportant(path)) return 5;
        return 6;
    }

    public String retrieveRoot(String projectId, Path root, String query, int limit, int maxChars) {
        return retrieve(AgentWorkspaceService.Workspace.forIndex(projectId, root), query, limit, maxChars);
    }

    public IndexStats warm(AgentWorkspaceService.Workspace ws) {
        WorkspaceIndex idx = cache.get(cacheKey(ws));
        // Agent can inspect live files with its tools while the independent background
        // worker builds the index. Never run a duplicate directory walk in Agent startup.
        return idx == null ? new IndexStats(0, 0, "pending") : idx.stats();
    }

    public IndexStats refresh(AgentWorkspaceService.Workspace ws) {
        WorkspaceIndex idx = index(ws, true);
        return idx.stats();
    }

    public String retrieve(AgentWorkspaceService.Workspace ws, String query) {
        return retrieve(ws, query, DEFAULT_RESULT_LIMIT, DEFAULT_MAX_CHARS);
    }

    public String retrieve(AgentWorkspaceService.Workspace ws, String query, int limit, int maxChars) {
        return retrieveInternal(ws, query, limit, maxChars, null);
    }

    /**
     * Hybrid retrieval: keep the deterministic lexical index as the safety baseline, then semantically rerank
     * the strongest live candidates with the configured embedding model. Any embedding/provider failure silently
     * falls back to lexical retrieval so repository work never depends on a secondary model.
     */
    public String retrieveHybrid(AgentWorkspaceService.Workspace ws, String query, int limit, int maxChars,
                                 String apiKey, ChatSettings settings, java.util.function.BooleanSupplier cancelled) {
        if (ws == null || query == null || query.isBlank() || settings == null || !settings.semanticRetrievalEnabled())
            return retrieve(ws, query, limit, maxChars);
        String embeddingModel = settings.embeddingModelName();
        if (embeddingModel.isBlank() || apiKey == null || apiKey.isBlank()) return retrieve(ws, query, limit, maxChars);

        WorkspaceIndex idx = cache.get(cacheKey(ws));
        if (idx == null) return "";
        String cacheKey = cacheKey(ws) + "|" + idx.stats().generatedAt() + "|" + embeddingModel + "|" +
                Integer.toHexString(query.strip().toLowerCase(Locale.ROOT).hashCode()) + "|" + limit + "|" + maxChars;
        String cached = semanticResultCache.get(cacheKey);
        if (cached != null) return cached;

        try {
            List<ScoredFile> lexical = score(idx, query);
            if (lexical.isEmpty()) return "";
            int candidateCount = Math.min(36, lexical.size());
            List<ScoredFile> candidates = new ArrayList<>(lexical.subList(0, candidateCount));
            List<String> inputs = new ArrayList<>(candidateCount + 1);
            inputs.add(query);
            for (ScoredFile candidate : candidates) {
                IndexedFile file = candidate.file();
                inputs.add("path: " + file.path() + "\n" + clip(file.sample(), 5_000));
            }
            List<double[]> vectors = llm.embed(apiKey, settings.baseUrl(), embeddingModel, inputs,
                    cancelled == null ? () -> false : cancelled);
            if (vectors.size() != inputs.size()) return retrieve(ws, query, limit, maxChars);
            double maxLexical = candidates.stream().mapToDouble(ScoredFile::score).max().orElse(1.0);
            List<ScoredFile> reranked = new ArrayList<>();
            for (int i = 0; i < candidates.size(); i++) {
                ScoredFile candidate = candidates.get(i);
                double semantic = Math.max(-1.0, Math.min(1.0, cosine(vectors.get(0), vectors.get(i + 1))));
                double semantic01 = (semantic + 1.0) / 2.0;
                double lexical01 = Math.min(1.0, candidate.score() / Math.max(1.0, maxLexical));
                double fused = (lexical01 * 0.48) + (semantic01 * 0.52);
                reranked.add(new ScoredFile(candidate.file(), fused * 100.0));
            }
            reranked.sort(Comparator.comparingDouble(ScoredFile::score).reversed().thenComparing(v -> v.file().path()));
            String result = render(ws, query, terms(query), reranked, limit, maxChars,
                    "hybrid lexical + semantic reranking via " + embeddingModel);
            if (!result.isBlank()) {
                if (semanticResultCache.size() > 400) semanticResultCache.clear();
                semanticResultCache.put(cacheKey, result);
            }
            return result;
        } catch (Exception ignored) {
            return retrieve(ws, query, limit, maxChars);
        }
    }

    private String retrieveInternal(AgentWorkspaceService.Workspace ws, String query, int limit, int maxChars, String mode) {
        if (ws == null || query == null || query.isBlank()) return "";
        WorkspaceIndex idx = cache.get(cacheKey(ws));
        if (idx == null) return "";
        Set<String> terms = terms(query);
        if (terms.isEmpty()) return "";
        return render(ws, query, terms, score(idx, query), limit, maxChars, mode == null ? "local lexical index" : mode);
    }

    private List<ScoredFile> score(WorkspaceIndex idx, String query) {
        Set<String> terms = terms(query);
        if (terms.isEmpty()) return List.of();
        List<ScoredFile> scored = new ArrayList<>();
        for (IndexedFile file : idx.files()) {
            double score = 0.0;
            String lowPath = file.path().toLowerCase(Locale.ROOT);
            for (String term : terms) {
                if (lowPath.contains(term)) score += 8.0;
                Integer frequency = file.termFrequency().get(term);
                if (frequency != null) score += Math.min(8, frequency) * 1.35;
            }
            if (score > 0 && isImportant(file.path())) score += 1.5;
            if (score > 0) scored.add(new ScoredFile(file, score));
        }
        scored.sort(Comparator.comparingDouble(ScoredFile::score).reversed().thenComparing(v -> v.file().path()));
        return scored;
    }

    private String render(AgentWorkspaceService.Workspace ws, String query, Set<String> terms, List<ScoredFile> scored,
                          int limit, int maxChars, String mode) {
        int wanted = Math.max(1, Math.min(limit, 16));
        int budget = Math.max(1_000, Math.min(maxChars, 24_000));
        StringBuilder out = new StringBuilder();
        out.append("WORKSPACE RETRIEVAL HINTS — ").append(mode).append("; live files/tools are authoritative.\n");
        out.append("queryTerms: ").append(String.join(", ", terms)).append('\n');
        int emitted = 0;
        for (ScoredFile match : scored) {
            if (emitted >= wanted || out.length() >= budget) break;
            Path file = ws.root().resolve(match.file().path()).normalize();
            if (!file.startsWith(ws.root()) || !Files.isRegularFile(file)) continue;
            // Files.readAllLines on Office/PDF containers yields binary garbage or a
            // decoding error. Use the text extracted into the bounded cache instead.
            String snippet = isDocument(file) ? clip(match.file().sample(), 900) : currentSnippet(file, terms, 900);
            if (snippet.isBlank()) snippet = clip(match.file().sample().replace("\r", "").strip(), 700);
            snippet = redact(snippet);
            String block = "\n- " + match.file().path() + " (score=" + String.format(Locale.ROOT, "%.1f", match.score()) + ")" +
                    (snippet.isBlank() ? "" : "\n  " + snippet.replace("\n", "\n  "));
            if (out.length() + block.length() > budget) break;
            out.append(block);
            emitted++;
        }
        return emitted == 0 ? "" : out.toString();
    }

    private double cosine(double[] a, double[] b) {
        if (a == null || b == null || a.length == 0 || a.length != b.length) return 0.0;
        double dot = 0.0, aa = 0.0, bb = 0.0;
        for (int i = 0; i < a.length; i++) { dot += a[i] * b[i]; aa += a[i] * a[i]; bb += b[i] * b[i]; }
        if (aa <= 0.0 || bb <= 0.0) return 0.0;
        return dot / (Math.sqrt(aa) * Math.sqrt(bb));
    }

    public void invalidate(AgentWorkspaceService.Workspace ws) {
        if (ws != null) {
            String prefix = cacheKey(ws);
            cache.remove(prefix);
            clearSemanticCache(prefix);
        }
    }

    /**
     * Refresh only files the runtime already knows were changed. This keeps the local retrieval index hot across
     * normal edit/write/patch operations instead of walking the whole repository again after every mutation.
     * If the index has not been built yet, this is intentionally a no-op; the first retrieval will build it once.
     */
    public void refreshPaths(AgentWorkspaceService.Workspace ws, Collection<String> changedPaths) {
        if (ws == null || changedPaths == null || changedPaths.isEmpty()) return;
        String key = cacheKey(ws);
        WorkspaceIndex existing = cache.get(key);
        if (existing == null) return;

        LinkedHashSet<String> normalized = new LinkedHashSet<>();
        for (String raw : changedPaths) {
            if (raw == null || raw.isBlank()) continue;
            try {
                Path supplied = Path.of(raw.strip());
                Path resolved = supplied.isAbsolute() ? supplied.normalize() : ws.root().resolve(supplied).normalize();
                if (!resolved.startsWith(ws.root())) continue;
                String rel = ws.root().relativize(resolved).toString().replace('\\', '/');
                if (!rel.isBlank()) normalized.add(rel);
            } catch (Exception ignored) { }
        }
        if (normalized.isEmpty()) return;

        cache.computeIfPresent(key, (ignored, current) -> {
            LinkedHashMap<String, IndexedFile> byPath = new LinkedHashMap<>();
            for (IndexedFile file : current.files()) byPath.put(file.path(), file);
            for (String rel : normalized) {
                byPath.remove(rel);
                Path file = ws.root().resolve(rel).normalize();
                try {
                    if (!file.startsWith(ws.root()) || !Files.isRegularFile(file)) continue;
                    long size = Files.size(file);
                    if (!indexable(file, size)) continue;
                    String sample = sample(file);
                    byPath.put(rel, new IndexedFile(rel, frequencies(rel + "\n" + sample), clip(sample, 8_000)));
                } catch (Exception ignoredFailure) {
                    if (Files.isRegularFile(file)) byPath.put(rel, new IndexedFile(rel, frequencies(rel), ""));
                }
            }
            List<IndexedFile> files = new ArrayList<>(byPath.values());
            if (files.size() > MAX_FILES) files = new ArrayList<>(files.subList(0, MAX_FILES));
            return new WorkspaceIndex(current.root(), List.copyOf(files),
                    new IndexStats(files.size(), current.stats().visitedFiles(), Instant.now().toString(),
                            files.stream().mapToLong(f -> f.sample().length()).sum()));
        });
        clearSemanticCache(key);
    }

    private void clearSemanticCache(String prefix) {
        semanticResultCache.keySet().removeIf(key -> key.startsWith(prefix + "|"));
    }

    private WorkspaceIndex index(AgentWorkspaceService.Workspace ws, boolean force) {
        String key = cacheKey(ws);
        if (!force) {
            WorkspaceIndex existing = cache.get(key);
            if (existing != null && Objects.equals(existing.root(), ws.root().toString())) return existing;
        }
        WorkspaceIndex built = build(ws);
        cache.put(key, built);
        return built;
    }

    private WorkspaceIndex build(AgentWorkspaceService.Workspace ws) {
        List<IndexedFile> files = new ArrayList<>();
        int[] scanned = {0};
        int[] indexed = {0};
        try {
            Files.walkFileTree(ws.root(), EnumSet.noneOf(FileVisitOption.class), 12, new SimpleFileVisitor<>() {
                @Override public FileVisitResult preVisitDirectory(Path dir, BasicFileAttributes attrs) {
                    if (!dir.equals(ws.root())) {
                        String name = dir.getFileName().toString().toLowerCase(Locale.ROOT);
                        if (SKIP_DIRS.contains(name)) return FileVisitResult.SKIP_SUBTREE;
                    }
                    return scanned[0] >= MAX_SCANNED_FILES || indexed[0] >= MAX_FILES ? FileVisitResult.TERMINATE : FileVisitResult.CONTINUE;
                }

                @Override public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) {
                    if (++scanned[0] > MAX_SCANNED_FILES || indexed[0] >= MAX_FILES) return FileVisitResult.TERMINATE;
                    if (!attrs.isRegularFile() || !indexable(file, attrs.size())) return FileVisitResult.CONTINUE;
                    indexed[0]++;
                    String rel = ws.root().relativize(file).toString().replace('\\', '/');
                    try {
                        String sample = sample(file);
                        files.add(new IndexedFile(rel, frequencies(rel + "\n" + sample), clip(sample, 8_000)));
                    } catch (Exception ignored) {
                        files.add(new IndexedFile(rel, frequencies(rel), ""));
                    }
                    return FileVisitResult.CONTINUE;
                }
            });
        } catch (IOException ignored) { }
        return new WorkspaceIndex(ws.root().toString(), List.copyOf(files),
                new IndexStats(files.size(), scanned[0], Instant.now().toString(),
                        files.stream().mapToLong(f -> f.sample().length()).sum()));
    }

    private boolean indexable(Path file, long size) {
        if (size < 0 || size > (isDocument(file) ? MAX_INDEXED_DOCUMENT_BYTES : MAX_INDEXED_FILE_BYTES)) return false;
        String name = file.getFileName().toString().toLowerCase(Locale.ROOT);
        if (SECRET_NAMES.contains(name) || name.startsWith(".env.") ||
                name.matches(".*\\.(pem|p12|pfx|jks|keystore|key|crt|cer)$")) return false;
        if (IMPORTANT_NAMES.contains(name)) return true;
        int dot = name.lastIndexOf('.');
        return dot > 0 && (INDEX_EXTENSIONS.contains(name.substring(dot + 1))
                || DOCUMENT_EXTENSIONS.contains(name.substring(dot + 1)));
    }

    private String sample(Path file) throws IOException {
        if (isDocument(file)) {
            // Reuse the application's already-bundled Tika parsers. This is text-only
            // background indexing: visual evidence remains the Agent's responsibility.
            Tika parser = new Tika();
            // Allow Tika to finish parsing normal documents before clipping the
            // indexed excerpt. Too low a parser limit can reject longer DOCX.
            parser.setMaxStringLength(600_000);
            try (InputStream input = Files.newInputStream(file)) {
                return clip(parser.parseToString(input).replace('\u0000', ' '), MAX_SAMPLED_CHARS_PER_FILE);
            } catch (Exception error) {
                throw new IOException("Cannot extract text from " + file.getFileName() + ": " + error.getMessage(), error);
            }
        }
        byte[] bytes = Files.readAllBytes(file);
        if (bytes.length == 0) return "";
        int n = Math.min(bytes.length, MAX_SAMPLED_CHARS_PER_FILE);
        String head = new String(bytes, 0, n, StandardCharsets.UTF_8);
        if (bytes.length <= n) return head;
        int tailBytes = Math.min(8_000, bytes.length - n);
        String tail = new String(bytes, bytes.length - tailBytes, tailBytes, StandardCharsets.UTF_8);
        return head + "\n" + tail;
    }

    private boolean isDocument(Path file) {
        String name = file.getFileName().toString().toLowerCase(Locale.ROOT);
        int dot = name.lastIndexOf('.');
        return dot > 0 && DOCUMENT_EXTENSIONS.contains(name.substring(dot + 1));
    }

    private Map<String,Integer> frequencies(String text) {
        Map<String,Integer> frequency = new HashMap<>();
        if (text == null) return Map.of();
        for (String raw : SPLIT.split(text.toLowerCase(Locale.ROOT))) {
            String term = raw.trim();
            if (term.length() < 3 || term.length() > 80 || STOP.contains(term) || term.matches("\\d+")) continue;
            if (!frequency.containsKey(term) && frequency.size() >= MAX_TERMS_PER_FILE) continue;
            frequency.merge(term, 1, Integer::sum);
        }
        return Map.copyOf(frequency);
    }

    private Set<String> terms(String text) {
        LinkedHashSet<String> out = new LinkedHashSet<>();
        if (text == null) return out;
        for (String raw : SPLIT.split(text.toLowerCase(Locale.ROOT))) {
            String term = raw.trim();
            if (term.length() < 3 || term.length() > 80 || STOP.contains(term) || term.matches("\\d+")) continue;
            out.add(term);
            if (out.size() >= 80) break;
        }
        return out;
    }

    private String currentSnippet(Path file, Set<String> terms, int maxChars) {
        try {
            List<String> lines = Files.readAllLines(file, StandardCharsets.UTF_8);
            List<String> matches = new ArrayList<>();
            for (int i = 0; i < lines.size() && matches.size() < 4; i++) {
                String low = lines.get(i).toLowerCase(Locale.ROOT);
                boolean hit = false;
                for (String term : terms) if (low.contains(term)) { hit = true; break; }
                if (!hit) continue;
                matches.add((i + 1) + ": " + clip(lines.get(i).strip(), 220));
            }
            String result = String.join("\n", matches);
            return clip(result, maxChars);
        } catch (Exception ignored) { return ""; }
    }

    private String redact(String text) {
        if (text == null || text.isBlank()) return "";
        return text.replaceAll("(?im)^([\\w.-]*(?:api[_-]?key|token|password|secret)[\\w.-]*\\s*[=:]\\s*)([^\\s#]+)", "$1[REDACTED]")
                .replaceAll("(?i)(Bearer\\s+)[A-Za-z0-9._~+/-]{16,}", "$1[REDACTED]");
    }

    private boolean isImportant(String path) {
        return IMPORTANT_NAMES.contains(Path.of(path).getFileName().toString().toLowerCase(Locale.ROOT));
    }

    private String cacheKey(AgentWorkspaceService.Workspace ws) {
        return ws.projectId() + "|" + ws.root().toAbsolutePath().normalize();
    }

    private static String clip(String value, int max) {
        if (value == null || value.length() <= max) return value == null ? "" : value;
        return value.substring(0, Math.max(0, max - 18)) + " …[clipped]";
    }

    private record IndexedFile(String path, Map<String,Integer> termFrequency, String sample) { }
    private record ScoredFile(IndexedFile file, double score) { }
    private record WorkspaceIndex(String root, List<IndexedFile> files, IndexStats stats) { }
    public record IndexStats(int indexedFiles, int visitedFiles, String generatedAt, long indexedCharacters) {
        public IndexStats(int indexedFiles, int visitedFiles, String generatedAt) {
            this(indexedFiles, visitedFiles, generatedAt, 0L);
        }
    }
}
