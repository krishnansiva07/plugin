package com.llmart.llm.service;

import com.llmart.llm.dto.ProjectDto;
import jakarta.annotation.PreDestroy;
import org.springframework.stereotype.Service;

import java.nio.file.Path;
import java.time.Instant;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * One bounded background worker for project/reference indexing. Registering a folder never
 * performs a full filesystem traversal or bulk H2 writes on a servlet/chat thread.
 */
@Service
public class LocalProjectIndexService {
    private final WorkspaceRetrievalIndexService retrieval;
    private final Map<String, Job> jobs = new ConcurrentHashMap<>();
    private final ExecutorService worker = Executors.newSingleThreadExecutor(r -> {
        Thread thread = new Thread(r, "eliya-project-index");
        thread.setDaemon(true);
        return thread;
    });

    public LocalProjectIndexService(WorkspaceRetrievalIndexService retrieval) { this.retrieval = retrieval; }

    public synchronized Map<String, Object> request(ProjectDto project, boolean force) {
        if (project == null || !project.localWorkspace()) throw new IllegalArgumentException("A local project is required");
        Job previous = jobs.get(project.id());
        if (previous != null && previous.path.equals(project.localPath())
                && ("queued".equals(previous.phase) || "indexing".equals(previous.phase))) return result(previous);
        if (!force && retrieval.cachedStats(project.id(), Path.of(project.localPath())) != null) {
            return status(project);
        }
        Job job = new Job(project.id(), project.localPath());
        jobs.put(project.id(), job);
        worker.execute(() -> {
            job.phase = "indexing";
            job.detail = "Scanning source files in the background";
            try {
                // The retrieval index already has bounded file/size/count limits and skips build folders.
                // Do not do the old second walk to copy every source file into the H2 database.
                WorkspaceRetrievalIndexService.IndexStats stats = retrieval.warmRoot(job.id, Path.of(job.path));
                job.files = stats.indexedFiles();
                job.scanned = stats.visitedFiles();
                job.detail = stats.indexedFiles() == 0
                        ? "No supported files indexed; scanned " + stats.visitedFiles() + " files (check formats, file sizes and access)"
                        : stats.indexedCharacters() == 0 ? "Files indexed, but no readable text extracted; use Agent document/vision analysis"
                        : "Ready for Chat and Agent";
                job.phase = "completed";
            } catch (Exception exception) {
                job.detail = exception.getMessage() == null ? exception.getClass().getSimpleName() : exception.getMessage();
                job.phase = "failed";
            } finally {
                job.finishedAt = Instant.now().toString();
            }
        });
        return result(job);
    }

    public Map<String, Object> status(ProjectDto project) {
        Job job = jobs.get(project.id());
        if (job != null && job.path.equals(project.localPath())) return result(job);
        WorkspaceRetrievalIndexService.IndexStats cached = retrieval.cachedStats(project.id(), Path.of(project.localPath()));
        if (cached == null) return Map.of("phase", "not_started", "fileCount", 0, "detail", "Index not started");
        return Map.of("phase", "completed", "fileCount", cached.indexedFiles(), "scannedCount", cached.visitedFiles(),
                "indexedCharacters", cached.indexedCharacters(),
                "detail", cached.indexedFiles() == 0
                        ? "No supported files indexed; scanned " + cached.visitedFiles() + " files (check formats, file sizes and access)"
                        : cached.indexedCharacters() == 0 ? "Files indexed, but no readable text extracted; use Agent document/vision analysis"
                        : "Ready for Chat and Agent",
                "finishedAt", cached.generatedAt());
    }

    private Map<String, Object> result(Job job) {
        Map<String, Object> data = new LinkedHashMap<>();
        data.put("phase", job.phase);
        data.put("fileCount", job.files);
        data.put("scannedCount", job.scanned);
        var cached = retrieval.cachedStats(job.id, Path.of(job.path));
        data.put("indexedCharacters", cached == null ? 0L : cached.indexedCharacters());
        data.put("detail", job.detail);
        if (job.finishedAt != null) data.put("finishedAt", job.finishedAt);
        return data;
    }

    private static final class Job {
        final String id;
        final String path;
        volatile String phase = "queued";
        volatile String detail = "Waiting for background index worker";
        volatile int files;
        volatile int scanned;
        volatile String finishedAt;
        Job(String id, String path) { this.id = id; this.path = path; }
    }

    @PreDestroy public void shutdown() { worker.shutdownNow(); }
}
