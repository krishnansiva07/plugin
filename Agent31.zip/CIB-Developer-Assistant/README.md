# CIB Developer Assistant

Java 17 local coding/workspace assistant with two modes: **Chat** and **Agent**.

## What Agent mode does

Agent works directly on the user-selected local project. There is no temporary mirror or delayed apply phase.

1. Resolve the project path from the prompt/current project.
2. Discover project instructions, build metadata, resources, MCP/LSP status and a local retrieval index.
3. Use the single selected **Agent model** to create a structured sequential plan.
4. Show the plan for review/approval unless plan approval is disabled.
5. Lock the approved plan and execute exactly one active step at a time.
6. Read/search only the evidence needed for the active step, batch independent reads, and edit the live workspace.
7. Defer compile/test/check/run until the final verification step unless an intermediate verifier is explicitly required.
8. Require the latest changed workspace revision to pass a real verifier before successful completion.
9. Persist durable run/progress state so a UI/SSE interruption does not lose the run state.

The same selected Agent model owns planning, execution and verification reasoning. **There is no model fallback chain.** Chat has its own independently selected model.

## Speed design

The current runtime keeps the existing plan-first architecture while reducing unnecessary work:

- **Incremental retrieval-index refresh for direct edits.** `edit`, `write`, `copy`, `move`, `delete`, and `apply_patch` refresh only known changed paths instead of invalidating and rebuilding the whole workspace index.
- **Safe full invalidation for unknown shell mutations.** `bash`/resource commands can change arbitrary files, so a detected unknown shell mutation still invalidates the index for correctness.
- **Active-step evidence cache.** Retrieval hints plus bounded current-file evidence are reused while the active plan step and workspace revision are unchanged.
- **Parallel reads.** Independent read/search tool calls can run together before the next model turn.
- **Bounded context.** Old/oversized tool observations are pruned; durable plan/workspace facts are re-injected separately.
- **Plan-boundary checkpoints.** Oversized completed-step transcript history is compacted before the next plan step without forcing an extra model summary call in the normal case.
- **Deterministic final verification completion.** When the final approved step is the verification step and the latest revision passes a real verifier, the runtime closes that step directly instead of calling a completion critic.
- **No extra final completion-model round trip.** When all approved steps are complete and the latest workspace revision is verified, the runtime finishes from those deterministic facts.
- **Provider/model errors stop.** Authentication, unavailable model, rate/provider failures and other model/provider errors stop the Agent run instead of switching models or starting an expensive recovery replan.
- **One context-overflow recovery.** A genuine context-window overflow may compact once and retry the same selected Agent model. If it still fails, the run stops.
- **No-op aware editing.** An edit that already matches the workspace does not create a fake mutation revision.

These optimizations reduce latency without removing plan approval, sequential execution, live-workspace editing, or revision-aware verification.

## Error and recovery behavior

There are two different failure classes:

### Model/provider failure

The run stops immediately and preserves current workspace/run state. No alternate model is selected and no recovery replan is launched.

A context-window overflow is the single exception: the runtime may compact once and retry the **same** model.

### Coding/tool failure

Normal coding failures remain recoverable inside the active plan step. Examples include:

- compile/test failure caused by the current change
- stale exact-text edit
- wrong locator/path assumption
- command/tool schema mismatch that can be corrected locally
- non-actionable/duplicate model output while the provider itself is healthy

The agent can inspect the real error, change strategy and continue the same approved step. Productive work does not have a fixed step ceiling; no-progress guards prevent endless repetition.

## Context and token management

The live workspace and durable run state are authoritative; the full project is not resent every turn.

The runtime uses:

- provider/model context-window hints or configured per-model context values
- token estimation including tool schemas
- bounded tool-output history
- superseded runtime-steering cleanup
- durable objective/plan/revision/verification state outside chat history
- deterministic context checkpoints
- periodic semantic compaction only when useful
- one forced compaction attempt for context overflow
- local lexical retrieval plus bounded current-file evidence

Default recent-context and safety-buffer settings remain configurable in Settings.

## Planning and sequential execution

The selected Agent model receives live evidence and returns a structured plan. The harness checks that:

- the plan size matches the task profile
- each step contains validation evidence
- the final step is a dedicated compile/test/check/run verification phase

If the model returns structurally unusable plan output while the provider is healthy, a deterministic evidence-safe fallback plan may be used. A genuine provider/model call error does **not** trigger that fallback; the run stops.

After approval:

- only one step is `in_progress`
- later steps remain locked
- implementation steps advance from real tool/workspace evidence
- the final verification step cannot complete until the latest required workspace revision has passed a real verifier
- successful final verification can close the final step deterministically
- successful completion becomes 100%; blocked/failed/cancelled states do not masquerade as success

## Workspace retrieval

`WorkspaceRetrievalIndexService` maintains a local lexical index for relevant source/text files while skipping common build/vendor/cache directories.

Normal direct mutations update only changed entries. This is especially important for large Java automation repositories where repeatedly walking thousands of files after every edit adds avoidable latency.

The runtime still performs a full invalidation when a shell/resource command may have changed unknown paths.

## Tool execution

The compact default Agent surface includes workspace inspection, list/glob/grep/read tools, edit/write/patch, build/test/check/bash, workspace diff/status, TODO plan progress, resource tools, MCP/LSP discovery and targeted tool loading.

Multiple independent read-only calls may execute in parallel. Mutations remain ordered and are observed by the revision/verification state machine.

## Verification model

A workspace mutation increments the run mutation revision when the change requires verification. The runtime records verifier attempts against that revision.

A successful completion requires the latest required revision to be verified. Small changes should use the smallest high-signal verifier that proves the requested behavior; broad builds/tests are used when the scope requires them.

## UI

The main UI contains only **Chat** and **Agent** modes.

- Chat model and Agent model are selected independently.
- Agent uses one selected Chat/Agent-capable model for the whole task.
- Image understanding belongs to Chat mode; Agent remains focused on repository/tool work.
- Chat document attachments are extracted locally before the LLM call, so the selected provider does not need a native file-upload API. Supported readable formats include DOC/DOCX/DOCM, PDF with embedded text, XLS/XLSX/XLSM, PPT/PPTX/PPTM, RTF, OpenDocument files, TXT/Markdown/CSV/JSON/XML/HTML/YAML and common source/configuration files.
- Current-message documents are always treated as direct context. If an older upload has no cached extraction, Chat automatically retries extraction before sending. If extraction still fails, the request stops with a clear application error instead of allowing the model to claim it cannot access the attachment.
- The attachment chip shows extraction readiness and extracted character count before the message is sent. Image-only/scanned PDFs require OCR and are reported as unreadable rather than silently guessed.
- Settings and model-library state are persisted when browser storage is available and fall back to in-memory state when storage is restricted.
- The Agent card displays plan progress, live activity, active step, verification and terminal state.

## Durable data

Default per-user data location:

```text
Windows: %USERPROFILE%\.advanced-ai-workbench\
Linux/macOS: ~/.advanced-ai-workbench/
  data/
    chatdb.mv.db
    uploads/
    agent-cache/
    agent-runs/
  cache/
  logs/
```

Locations can be overridden with the existing application/system properties.

## Build and run

Requirements:

- Java 17 or later
- Maven, or network access on first use so the included wrapper can bootstrap Maven

Linux/macOS:

```bash
./mvnw clean package
java -jar target/advanced-ai-workbench.jar
```

Windows:

```bat
mvnw.cmd clean package
java -jar target\advanced-ai-workbench.jar
```

## Validation

The included validation scripts now run the full test suite by default.

Linux/macOS:

```bash
./validate-local.sh
```

Windows:

```bat
validate-local.bat
```

Validation performs:

1. Java availability
2. JavaScript syntax checks when Node is installed
3. Maven availability/bootstrap
4. clean package
5. `-Pfull-tests test`

For an explicitly fast local smoke check only:

```bash
FAST_VALIDATION=1 ./validate-local.sh
```

or on Windows:

```bat
set FAST_VALIDATION=1
validate-local.bat
```

Do not treat `FAST_VALIDATION=1` as a release/full validation.

## Source integrity

`SOURCE_MANIFEST_SHA256.txt` contains SHA-256 hashes for the shipped source/configuration files. It is regenerated only after final packaging changes so the manifest describes the actual package contents.

## Key source areas

```text
src/main/java/com/llmart/llm/service/AgentService.java
  orchestration, plan execution, context preparation, model-error behavior,
  completion gates, tool observation

src/main/java/com/llmart/llm/service/AgentRunService.java
  durable run state, sequential plan gate, mutation/verification revisions,
  progress and persistence

src/main/java/com/llmart/llm/service/WorkspaceRetrievalIndexService.java
  local lexical retrieval, full indexing and incremental changed-path refresh

src/main/java/com/llmart/llm/service/ContextWindowManager.java
  token estimation, pruning and compaction

src/main/java/com/llmart/llm/service/OpenAiCompatibleClient.java
  OpenAI-compatible transport and tool/JSON/plain protocol compatibility

src/main/resources/static/app.js
src/main/resources/static/index.html
  Chat/Agent UI, settings, SSE progress and model selection
```

## Recommended performance comparison

When comparing this build with another coding agent on the same repository/model/task, record:

- total duration
- model-call count
- provider-reported input/output tokens
- number of retrieval/index rebuilds
- repeated read/search calls
- tool-action count
- time from final successful verifier to terminal completion
- whether the requested task actually completed correctly

The intended improvement is lower harness overhead and fewer redundant model turns **without reducing task-completion quality or verification safety**.
