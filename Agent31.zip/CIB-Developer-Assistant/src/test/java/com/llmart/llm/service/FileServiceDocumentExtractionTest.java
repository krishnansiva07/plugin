package com.llmart.llm.service;

import com.llmart.llm.dto.FileDto;
import com.llmart.llm.entity.ConversationEntity;
import com.llmart.llm.entity.FileEntity;
import com.llmart.llm.repository.FileRepository;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.mock.web.MockMultipartFile;

import java.io.ByteArrayOutputStream;
import java.nio.file.Path;
import java.util.concurrent.atomic.AtomicReference;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

class FileServiceDocumentExtractionTest {

    @TempDir
    Path tempDir;

    @Mock
    FileRepository repository;

    @Mock
    ConversationService conversations;

    private AutoCloseable mocks;
    private FileService service;
    private final AtomicReference<FileEntity> saved = new AtomicReference<>();

    @BeforeEach
    void setUp() {
        mocks = MockitoAnnotations.openMocks(this);
        when(conversations.require(anyString())).thenReturn(new ConversationEntity("c1", "test"));
        when(repository.save(any(FileEntity.class))).thenAnswer(invocation -> {
            FileEntity entity = invocation.getArgument(0);
            saved.set(entity);
            return entity;
        });
        service = new FileService(repository, conversations, tempDir.toString());
    }

    @AfterEach
    void tearDown() throws Exception {
        mocks.close();
    }

    @Test
    void extractsDocxTextAtUploadTime() throws Exception {
        byte[] bytes;
        try (XWPFDocument document = new XWPFDocument(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            document.createParagraph().createRun().setText("Teamspark document summary content");
            document.createTable(1, 2).getRow(0).getCell(0).setText("Owner");
            document.getTables().get(0).getRow(0).getCell(1).setText("Siva");
            document.write(out);
            bytes = out.toByteArray();
        }

        MockMultipartFile upload = new MockMultipartFile(
                "file",
                "teamspark.docx",
                "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                bytes);

        FileDto dto = service.save("c1", upload);

        assertEquals("ready", dto.extractionStatus());
        assertTrue(dto.extractedCharacters() > 0);
        assertNotNull(saved.get());
        assertTrue(saved.get().getExtractedText().contains("Teamspark document summary content"));
        assertTrue(saved.get().getExtractedText().contains("Owner"));
    }
}
