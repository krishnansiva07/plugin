# npm Installation Troubleshooting

## Error refers to an unavailable registry

The portable package lock in version 1.0.1 does not contain a hard-coded registry host. npm will use the registry configured on the machine.

Check it:

```bat
npm config get registry
```

For public npm access:

```bat
npm config set registry https://registry.npmjs.org/
```

On a corporate network, use the organisation-approved npm/Artifactory registry instead.

## Clean a partially installed node_modules folder on Windows

Close IDE terminals and applications that may be using Node.js, then run from the project root:

```bat
taskkill /F /IM node.exe 2>NUL
rd /s /q node_modules
npm cache verify
npm ci
```

If Windows still reports `EPERM`, restart the machine and delete `node_modules` before opening the project in an IDE.

## Unknown `unsafe-perm` warning

This setting normally comes from a user or global `.npmrc`, not this project. Locate and remove it if your organisation does not require it:

```bat
npm config get userconfig
npm config get globalconfig
npm config delete unsafe-perm --location=user
```

The warning itself does not cause the registry timeout.
