# Smart Playwright Framework - User and Developer Guide

## 1. Purpose

This framework provides a reusable Playwright TypeScript foundation for UI automation using installed Chrome or Edge in headed mode. The sample application is SauceDemo (`https://www.saucedemo.com/`).

It combines deterministic Playwright automation with optional, controlled LLM locator recovery. LLM healing is a fallback, not the main execution engine.

## 2. Architecture

```text
Excel execution control and test data
                 |
                 v
        Playwright test specification
                 |
                 v
       Fixtures and Page Objects
                 |
                 v
          SmartActions layer
                 |
       +---------+----------+
       |                    |
Primary locator       Deterministic fallback
                            |
                       Optional LLM
                            |
                    Strict validation
                            |
                      One retry only
                 |
                 v
HTML + Excel + JUnit + Playwright evidence
```

## 3. Key decisions

- Installed Chrome and Edge only; bundled Chromium is disabled.
- Chrome is preferred when `BROWSER=auto`; Edge is the fallback.
- Execution is always headed/UI.
- One worker is the default so the UI run is easy to follow.
- Page objects contain business actions and element descriptions.
- Tests contain scenarios and assertions, not raw selectors.
- Excel contains execution selection and data, not TypeScript code.
- LLM healing never executes arbitrary JavaScript and never edits source files.

## 4. Prerequisites

1. Windows 10/11 or Windows Server with interactive desktop for visible Jenkins execution.
2. Node.js 22 or newer; Node.js 24 LTS is recommended.
3. npm.
4. Google Chrome or Microsoft Edge installed.
5. Access to SauceDemo or the target application.
6. Jenkins plugins when CI publishing is used:
   - GitLab plugin for the supplied push trigger;
   - JUnit plugin;
   - HTML Publisher plugin.

## 5. Installation

Extract the project and open a terminal in the root folder.

```bash
npm config get registry
npm ci
```

The project lock file is registry-portable. npm uses the registry configured on the machine. On corporate networks, configure the approved Artifactory/npm registry before installation.

Do not run `npx playwright install chromium`. The project sets `PLAYWRIGHT_SKIP_BROWSER_DOWNLOAD=1` in Jenkins and resolves the installed browser executable.

Validate the setup:

```bash
npm run preflight
```

Expected output includes Node.js version, detected Chrome/Edge locations, selected browser, headed execution mode, Excel file status, and LLM status.

## 6. Configuration

Copy `.env.example` to `.env` only when overriding defaults.

### Application settings

```properties
BASE_URL=https://www.saucedemo.com/
ENVIRONMENT=QA
```

### Browser settings

```properties
BROWSER=auto
BROWSER_PRIORITY=chrome,edge
SLOW_MO=0
WORKERS=1
RECORD_VIDEO=false
```

`BROWSER=auto` selects installed Chrome first and installed Edge second. Set `BROWSER=chrome` or `BROWSER=edge` to force a browser. If the requested browser is absent, the preflight fails before tests start.

Headed execution is fixed in `playwright.config.ts`:

```typescript
headless: false
```

### LLM settings

```properties
LLM_ENABLED=false
LLM_API_KEY=
LLM_BASE_URL=
LLM_MODEL_NAME=
LLM_CHAT_PATH=/v1/chat/completions
LLM_MIN_CONFIDENCE=0.85
LLM_TIMEOUT_MS=15000
LLM_DOM_MAX_LENGTH=20000
LLM_MAX_CALLS_PER_TEST=1
HEALING_MODE=runtime
```

The framework also reads `config/config.properties` with the Java-compatible keys:

```properties
apiKey=
baseUrl=
modelName=
chatPath=/v1/chat/completions
```

Environment variables take precedence and should be used in Jenkins.


### Optional video recording

`RECORD_VIDEO=false` is the default. This keeps the framework independent of Playwright browser and ffmpeg downloads. When video evidence is required, set `RECORD_VIDEO=true` and install only the Playwright ffmpeg helper:

```bash
npx playwright install ffmpeg
```

This command does not install Chromium; browser execution still uses installed Chrome or Edge.

## 7. Commands

| Command | Purpose |
|---|---|
| `npm run preflight` | Validate Node, browser, Excel, and LLM configuration |
| `npm test` | Auto-detect Chrome/Edge and run all enabled tests |
| `npm run test:chrome` | Run with installed Chrome |
| `npm run test:edge` | Run with installed Edge |
| `npm run test:smoke` | Run tests tagged `@smoke` |
| `npm run test:debug` | Run Playwright debug mode using the installed browser |
| `npm run typecheck` | Compile-time TypeScript validation |
| `npm run excel:create` | Regenerate the sample Excel workbook |
| `npm run sample-report:create` | Generate a sample management report without running tests |
| `npm run report:open` | Open `reports/index.html` |
| `npm run clean` | Remove old reports and test results |

## 8. Excel data usage

Workbook: `test-data/TestExecution.xlsx`

### ExecutionControl sheet

| Run | TestID | TestName | DataSheet | Tags |
|---|---|---|---|---|
| Y | TC_LOGIN_001 | Login with valid credentials | LoginData | smoke,regression |

- `Run=Y`: test is created and executed.
- `Run=N`: test is excluded.
- `TestID` must be unique.
- `Tags` are comma-separated and become Playwright tags.

### LoginData sheet

| TestID | Username | Password | ExpectedType | ExpectedValue |
|---|---|---|---|---|
| TC_LOGIN_001 | standard_user | secret_sauce | PageTitle | Products |

Supported expected types in the sample:

- `PageTitle`: validate the Products page.
- `ErrorMessage`: validate a login error message.

### Adding a test case

1. Add a row to `ExecutionControl`.
2. Add a row with the same TestID to `LoginData`.
3. Set `Run=Y`.
4. Execute `npm test`.

## 9. Page Object Model

### Responsibilities

- `LoginPage`: login fields, login action, and login error assertion.
- `InventoryPage`: Products page assertion.
- `SmartActions`: click, fill, clear, read text, and resolve elements.
- `SmartLocator`: primary, fallback, LLM, validation, and healing evidence.
- Fixtures: create page objects for each isolated test.

A page object describes an element semantically:

```typescript
const loginButton = {
  key: 'login.submit',
  description: 'SauceDemo Login button',
  primary: { type: 'testId', value: 'login-button' },
  fallbacks: [
    { type: 'role', role: 'button', value: 'Login', exact: true },
    { type: 'css', value: 'input[type="submit"][value="Login"]' }
  ]
};
```

The test only performs the business flow:

```typescript
await loginPage.open();
await loginPage.login(username, password);
await inventoryPage.expectLoaded('Products');
```

## 10. Self-healing flow

### Layer 1 - Primary locator

The framework first uses the stable page-object locator. SauceDemo uses `data-test`, configured through Playwright's `testIdAttribute`.

### Layer 2 - Deterministic healing

If the primary locator is missing, non-unique, invisible, or the wrong tag, the framework tries known semantic fallbacks such as label, placeholder, role, or stable CSS.

### Layer 3 - LLM healing

When deterministic candidates fail and LLM is enabled, the framework sends:

- element key and description;
- intended action;
- failed locator and diagnostics;
- page title and URL;
- sanitized accessibility snapshot;
- sanitized and truncated DOM;
- nearby expected text.

The LLM must return strict JSON containing one locator, confidence, and reason. Arbitrary JavaScript is rejected.

### Validation

The candidate must:

1. match exactly one element;
2. be visible;
3. match the expected tag when configured;
4. meet the minimum LLM confidence;
5. be used for one retry only.

### Modes

- `HEALING_MODE=runtime`: validate and retry the action.
- `HEALING_MODE=report`: record the candidate but fail the test without retrying.

### Demo

Set `DEMO_HEALING=true` and run:

```bash
npm run test:healing-demo
```

The demo intentionally breaks the primary username test ID. The placeholder fallback recovers it, and the report shows `PASSED - HEALED`.

## 11. HTML report

Primary file: `reports/index.html`

### Consolidated summary

The top section displays:

- total tests;
- passed;
- passed with healing;
- failed;
- flaky;
- skipped;
- percentage for every result;
- overall pass percentage.

The pass percentage is:

```text
(Passed + Passed with Healing) / (Total - Skipped) x 100
```

### Main table

The visible table contains exactly:

1. Serial No.
2. Test ID
3. Test Name
4. Status

Clicking a row expands duration, browser, environment, retry, tags, test steps, errors, evidence links, and healing details.

### Output files

```text
reports/
  index.html
  execution-summary.json
  test-results.xlsx
  evidence/
playwright-report/
test-results/
  junit.xml
  artifacts/
healing-results/
  healing-events.ndjson
```

## 12. Jenkins usage

The included declarative pipeline:

1. uses agent label `windows_hvd`;
2. optionally accepts browser and LLM parameters;
3. installs packages using `npm ci`;
4. removes old results;
5. runs preflight;
6. executes tests;
7. publishes JUnit;
8. publishes the custom HTML report;
9. archives HTML, Excel, screenshots, traces, optional videos, JUnit, and healing events.

### Headed-mode requirement

For the UI to be visible, start the Jenkins agent inside an interactive logged-in Windows desktop session and keep the session unlocked. A Jenkins Windows service can run the test, but the browser may appear in a non-visible service session.

### LLM secret

Create a Jenkins Secret Text credential and inject it:

```groovy
withCredentials([string(credentialsId: 'llm-api-key', variable: 'LLM_API_KEY')]) {
    bat 'npm test'
}
```

Store the non-secret base URL and model name as job, folder, or node environment variables.

## 13. Adding a new page and test

1. Create `src/pages/NewPage.ts` extending `BasePage`.
2. Describe elements using stable primary locators and semantic fallbacks.
3. Add business actions and web-first assertions.
4. Add the page object to `src/fixtures/testFixtures.ts` when it is widely reused.
5. Create a spec under `tests/`.
6. Add an annotation or title using `TEST_ID | Test Name`.
7. Add Excel rows when the scenario is data-driven.
8. Run `npm run typecheck`, `npm run preflight`, and the new test.

## 14. Troubleshooting

### Chrome or Edge not detected

- Run `npm run preflight`.
- Confirm the browser is installed, not only copied as a portable folder.
- Try `npm run test:chrome` or `npm run test:edge`.
- Confirm the Jenkins user can access the browser installation.

### Browser opens but is not visible in Jenkins

- Do not run only as a background Windows service.
- Launch the agent from an interactive user desktop.
- Keep the desktop session connected and unlocked.

### Excel file error

- Confirm both required sheets exist.
- Confirm Test IDs match between `ExecutionControl` and `LoginData`.
- Close the workbook in Excel if another process has locked it.
- Regenerate with `npm run excel:create` when needed.

### LLM call fails

- Keep `LLM_ENABLED=false` until all values are configured.
- Verify the corporate endpoint is OpenAI chat-completions compatible.
- Set `LLM_CHAT_PATH` when the path differs.
- Check proxy, certificate, and Jenkins credential configuration.
- Review the original Playwright failure; a business defect must not be healed.

### Report missing

The custom reporter writes the report during the Playwright end event. Run:

```bash
npm run sample-report:create
npm run report:open
```

This validates local report rendering even before browser execution.

## 15. Security controls

- Password values are masked in attached test data.
- DOM values, password/token/secret attributes, scripts, event handlers, and styles are removed or redacted before an LLM call.
- Only a limited DOM snapshot is sent.
- API keys are not logged.
- The LLM cannot execute JavaScript.
- Source files are not automatically modified.
- Every healing action appears in the report and NDJSON audit file.

## 16. Recommended adoption sequence

1. Run deterministic automation with `LLM_ENABLED=false`.
2. Validate browser detection, Excel data, report, and Jenkins publication.
3. Run the deterministic healing demo.
4. Configure the corporate LLM in a non-production environment.
5. Use `HEALING_MODE=report` initially.
6. Review suggestions and confidence.
7. Move to `HEALING_MODE=runtime` after governance approval.


## 19. npm installation troubleshooting

See `docs/NPM_INSTALL_TROUBLESHOOTING.md`. The quick Windows recovery sequence is:

```bat
taskkill /F /IM node.exe 2>NUL
rd /s /q node_modules
npm cache verify
npm ci
```

Use `npm config get registry` to verify that npm is not pointing to an unavailable registry.
