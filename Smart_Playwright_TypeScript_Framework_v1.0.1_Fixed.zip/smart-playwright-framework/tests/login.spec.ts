import { test } from '../src/fixtures/testFixtures';
import { loadLoginTestCases } from '../src/data/ExcelTestData';

const testCases = await loadLoginTestCases();

test.describe('SauceDemo Excel-driven login', () => {
  for (const data of testCases) {
    test(
      `${data.testId} | ${data.testName}`,
      { tag: data.tags },
      async ({ loginPage, inventoryPage }, testInfo) => {
        testInfo.annotations.push(
          { type: 'testId', description: data.testId },
          { type: 'testName', description: data.testName },
        );

        await testInfo.attach('test-data', {
          body: Buffer.from(JSON.stringify({
            testId: data.testId,
            username: data.username,
            password: data.password ? '[MASKED]' : '',
            expectedType: data.expectedType,
            expectedValue: data.expectedValue,
          }, null, 2)),
          contentType: 'application/json',
        });

        await test.step('Open SauceDemo login page', async () => {
          await loginPage.open();
        });

        await test.step('Submit login credentials', async () => {
          await loginPage.login(data.username, data.password);
        });

        await test.step('Validate expected result', async () => {
          if (data.expectedType === 'PageTitle') {
            await inventoryPage.expectLoaded(data.expectedValue);
          } else {
            await loginPage.expectErrorContaining(data.expectedValue);
          }
        });
      },
    );
  }
});
