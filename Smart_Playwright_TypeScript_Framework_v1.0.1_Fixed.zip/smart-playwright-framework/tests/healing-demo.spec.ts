import { test } from '../src/fixtures/testFixtures';
import { LoginPage } from '../src/pages/LoginPage';

const enabled = (process.env.DEMO_HEALING ?? 'false').toLowerCase() === 'true';

if (enabled) {
  test.describe('Self-healing demonstration', () => {
    test(
      'TC_HEAL_001 | Recover an intentionally broken username locator',
      { tag: ['@healing-demo'] },
      async ({ page, inventoryPage }, testInfo) => {
        testInfo.annotations.push(
          { type: 'testId', description: 'TC_HEAL_001' },
          { type: 'testName', description: 'Recover an intentionally broken username locator' },
        );

        const loginPage = new LoginPage(page, testInfo, true);
        await loginPage.open();
        await loginPage.login('standard_user', 'secret_sauce');
        await inventoryPage.expectLoaded('Products');
      },
    );
  });
}
