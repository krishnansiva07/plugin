import path from 'node:path';
import ExcelJS from 'exceljs';

export interface LoginTestCase {
  run: boolean;
  testId: string;
  testName: string;
  tags: string[];
  username: string;
  password: string;
  expectedType: 'PageTitle' | 'ErrorMessage';
  expectedValue: string;
}

function normaliseHeader(value: unknown): string {
  return String(value ?? '').trim().replace(/\s+/g, '').toLowerCase();
}

function rowToRecord(row: ExcelJS.Row, headers: Map<number, string>): Record<string, string> {
  const record: Record<string, string> = {};
  for (const [column, header] of headers.entries()) {
    const cell = row.getCell(column);
    const value = cell.text || String(cell.value ?? '');
    record[header] = value.trim();
  }
  return record;
}

function parseRun(value: string): boolean {
  return ['y', 'yes', 'true', '1', 'run'].includes(value.trim().toLowerCase());
}

function parseTags(value: string): string[] {
  return value
    .split(',')
    .map(tag => tag.trim())
    .filter(Boolean)
    .map(tag => tag.startsWith('@') ? tag : `@${tag}`);
}

export async function loadLoginTestCases(
  workbookPath = path.join(process.cwd(), 'test-data', 'TestExecution.xlsx'),
): Promise<LoginTestCase[]> {
  const workbook = new ExcelJS.Workbook();
  await workbook.xlsx.readFile(workbookPath);

  const control = workbook.getWorksheet('ExecutionControl');
  const data = workbook.getWorksheet('LoginData');
  if (!control || !data) {
    throw new Error('TestExecution.xlsx must contain ExecutionControl and LoginData sheets.');
  }

  const readSheet = (worksheet: ExcelJS.Worksheet): Record<string, string>[] => {
    const headerRow = worksheet.getRow(1);
    const headers = new Map<number, string>();
    headerRow.eachCell((cell, column) => {
      headers.set(column, normaliseHeader(cell.text || cell.value));
    });

    const rows: Record<string, string>[] = [];
    worksheet.eachRow((row, rowNumber) => {
      if (rowNumber > 1) {
        rows.push(rowToRecord(row, headers));
      }
    });
    return rows;
  };

  const controlRows = readSheet(control);
  const dataRows = readSheet(data);
  const dataByTestId = new Map(dataRows.map(row => [row.testid, row]));

  return controlRows
    .filter(row => parseRun(row.run ?? ''))
    .map(row => {
      const testId = row.testid;
      const testName = row.testname;
      if (!testId || !testName) {
        throw new Error('Every enabled ExecutionControl row must contain TestID and TestName.');
      }
      const testData = dataByTestId.get(testId);
      if (!testData) {
        throw new Error(`No LoginData row was found for TestID ${testId}.`);
      }

      const expectedType = testData.expectedtype as LoginTestCase['expectedType'];
      if (expectedType !== 'PageTitle' && expectedType !== 'ErrorMessage') {
        throw new Error(`Unsupported ExpectedType "${testData.expectedtype}" for ${testId}.`);
      }

      return {
        run: true,
        testId,
        testName,
        tags: parseTags(row.tags ?? ''),
        username: testData.username ?? '',
        password: testData.password ?? '',
        expectedType,
        expectedValue: testData.expectedvalue ?? '',
      };
    });
}
