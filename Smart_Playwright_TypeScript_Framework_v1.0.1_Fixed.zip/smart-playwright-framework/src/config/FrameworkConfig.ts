import { loadEnvironment } from './EnvLoader';

export type BrowserPreference = 'auto' | 'chrome' | 'edge';
export type HealingMode = 'report' | 'runtime';

function asBoolean(value: string | undefined, defaultValue: boolean): boolean {
  if (value === undefined) {
    return defaultValue;
  }
  return ['1', 'true', 'yes', 'y', 'on'].includes(value.trim().toLowerCase());
}

function asNumber(value: string | undefined, defaultValue: number): number {
  if (value === undefined || value.trim() === '') {
    return defaultValue;
  }
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : defaultValue;
}

function asBrowser(value: string | undefined): BrowserPreference {
  const normalized = (value ?? 'auto').trim().toLowerCase();
  if (normalized === 'chrome' || normalized === 'edge' || normalized === 'auto') {
    return normalized;
  }
  throw new Error(`Unsupported BROWSER value "${value}". Use auto, chrome, or edge.`);
}

function asHealingMode(value: string | undefined): HealingMode {
  const normalized = (value ?? 'runtime').trim().toLowerCase();
  if (normalized === 'report' || normalized === 'runtime') {
    return normalized;
  }
  throw new Error(`Unsupported HEALING_MODE value "${value}". Use report or runtime.`);
}

export interface FrameworkConfig {
  baseUrl: string;
  environment: string;
  workers: number;
  browser: {
    preference: BrowserPreference;
    priority: Array<'chrome' | 'edge'>;
    slowMo: number;
    headed: true;
    recordVideo: boolean;
  };
  llm: {
    enabled: boolean;
    apiKey?: string;
    baseUrl?: string;
    modelName?: string;
    chatPath: string;
    timeoutMs: number;
    minimumConfidence: number;
    domMaxLength: number;
    maxCallsPerTest: number;
    healingMode: HealingMode;
  };
}

export function getFrameworkConfig(): FrameworkConfig {
  loadEnvironment();

  const priority = (process.env.BROWSER_PRIORITY ?? 'chrome,edge')
    .split(',')
    .map(value => value.trim().toLowerCase())
    .filter((value): value is 'chrome' | 'edge' => value === 'chrome' || value === 'edge');

  const uniquePriority = [...new Set(priority)];
  if (uniquePriority.length === 0) {
    uniquePriority.push('chrome', 'edge');
  }

  return {
    baseUrl: process.env.BASE_URL?.trim() || 'https://www.saucedemo.com/',
    environment: process.env.ENVIRONMENT?.trim() || 'QA',
    workers: Math.max(1, Math.floor(asNumber(process.env.WORKERS, 1))),
    browser: {
      preference: asBrowser(process.env.BROWSER),
      priority: uniquePriority,
      slowMo: Math.max(0, asNumber(process.env.SLOW_MO, 0)),
      headed: true,
      recordVideo: asBoolean(process.env.RECORD_VIDEO, false),
    },
    llm: {
      enabled: asBoolean(process.env.LLM_ENABLED, false),
      apiKey: process.env.LLM_API_KEY?.trim() || undefined,
      baseUrl: process.env.LLM_BASE_URL?.trim() || undefined,
      modelName: process.env.LLM_MODEL_NAME?.trim() || undefined,
      chatPath: process.env.LLM_CHAT_PATH?.trim() || '/v1/chat/completions',
      timeoutMs: Math.max(1_000, asNumber(process.env.LLM_TIMEOUT_MS, 15_000)),
      minimumConfidence: Math.min(1, Math.max(0, asNumber(process.env.LLM_MIN_CONFIDENCE, 0.85))),
      domMaxLength: Math.max(1_000, Math.floor(asNumber(process.env.LLM_DOM_MAX_LENGTH, 20_000))),
      maxCallsPerTest: Math.max(0, Math.floor(asNumber(process.env.LLM_MAX_CALLS_PER_TEST, 1))),
      healingMode: asHealingMode(process.env.HEALING_MODE),
    },
  };
}
