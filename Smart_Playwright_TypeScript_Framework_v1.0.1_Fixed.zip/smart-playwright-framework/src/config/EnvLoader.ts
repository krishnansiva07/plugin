import fs from 'node:fs';
import path from 'node:path';

let loaded = false;

function parseKeyValueFile(filePath: string): Record<string, string> {
  if (!fs.existsSync(filePath)) {
    return {};
  }

  const result: Record<string, string> = {};
  const content = fs.readFileSync(filePath, 'utf8');

  for (const rawLine of content.split(/\r?\n/)) {
    const line = rawLine.trim();
    if (!line || line.startsWith('#')) {
      continue;
    }

    const separator = line.indexOf('=');
    if (separator < 1) {
      continue;
    }

    const key = line.slice(0, separator).trim();
    let value = line.slice(separator + 1).trim();
    if ((value.startsWith('"') && value.endsWith('"')) ||
        (value.startsWith("'") && value.endsWith("'"))) {
      value = value.slice(1, -1);
    }
    result[key] = value;
  }

  return result;
}

export function loadEnvironment(projectRoot = process.cwd()): void {
  if (loaded) {
    return;
  }

  const envValues = parseKeyValueFile(path.join(projectRoot, '.env'));
  for (const [key, value] of Object.entries(envValues)) {
    if (process.env[key] === undefined) {
      process.env[key] = value;
    }
  }

  const propertyValues = parseKeyValueFile(path.join(projectRoot, 'config', 'config.properties'));
  const mapping: Record<string, string> = {
    apiKey: 'LLM_API_KEY',
    baseUrl: 'LLM_BASE_URL',
    modelName: 'LLM_MODEL_NAME',
    chatPath: 'LLM_CHAT_PATH',
  };

  for (const [propertyName, environmentName] of Object.entries(mapping)) {
    if (process.env[environmentName] === undefined && propertyValues[propertyName]) {
      process.env[environmentName] = propertyValues[propertyName];
    }
  }

  loaded = true;
}
