import fs from 'node:fs';
import path from 'node:path';
import ExcelJS from 'exceljs';
import type {
  FullConfig,
  FullResult,
  Reporter,
  Suite,
  TestCase,
  TestResult,
  TestStep,
} from '@playwright/test/reporter';
import { getFrameworkConfig } from '../config/FrameworkConfig';
import { renderSmartReport } from './HtmlTemplate';
import type {
  ReportAttachment,
  ReportStatus,
  ReportStep,
  ReportTestResult,
  SmartReportData,
} from './ReportModel';

interface ReporterOptions {
  outputDir?: string;
}

export default class SmartHtmlReporter implements Reporter {
  private readonly outputDir: string;
  private readonly results = new Map<string, ReportTestResult>();
  private startedAt = new Date();
  private config?: FullConfig;

  constructor(options: ReporterOptions = {}) {
    this.outputDir = path.resolve(options.outputDir ?? 'reports');
  }

  onBegin(config: FullConfig, _suite: Suite): void {
    this.config = config;
    this.startedAt = new Date();
    fs.rmSync(this.outputDir, { recursive: true, force: true });
    fs.mkdirSync(path.join(this.outputDir, 'evidence'), { recursive: true });
  }

  onTestEnd(test: TestCase, result: TestResult): void {
    const annotations = test.annotations;
    const parsed = this.parseIdentity(test, annotations);
    const healingEvents = this.readHealingEvents(result);
    const healed = healingEvents.length > 0 || annotations.some(item => item.type === 'healed');
    const status = this.mapStatus(result, healed);
    const attachments = this.processAttachments(test, result);
    const tags = [...new Set([...(test.tags ?? []), ...annotations.filter(item => item.type === 'tag').map(item => item.description ?? '')])]
      .filter(Boolean);

    this.results.set(test.id, {
      serialNo: 0,
      testId: parsed.testId,
      testName: parsed.testName,
      status,
      durationMs: result.duration,
      retry: result.retry,
      error: this.formatErrors(result),
      browser: this.readProjectName(test),
      environment: getFrameworkConfig().environment,
      file: path.relative(process.cwd(), test.location.file),
      tags,
      steps: this.flattenSteps(result.steps),
      attachments,
      healingEvents,
    });
  }

  async onEnd(_result: FullResult): Promise<void> {
    const endedAt = new Date();
    const tests = [...this.results.values()]
      .sort((a, b) => a.testId.localeCompare(b.testId, undefined, { numeric: true }))
      .map((test, index) => ({ ...test, serialNo: index + 1 }));

    const count = (status: ReportStatus): number => tests.filter(test => test.status === status).length;
    const passed = count('PASSED');
    const healed = count('PASSED - HEALED');
    const failed = count('FAILED');
    const skipped = count('SKIPPED');
    const flaky = count('FLAKY');
    const interrupted = count('INTERRUPTED');
    const timedOut = count('TIMED OUT');
    const executed = Math.max(0, tests.length - skipped);
    const passPercentage = executed === 0 ? 0 : ((passed + healed) / executed) * 100;
    const browser = tests.find(test => test.browser)?.browser ?? process.env.RESOLVED_BROWSER_NAME ?? process.env.BROWSER ?? 'auto';

    const report: SmartReportData = {
      summary: {
        projectName: this.config?.metadata?.projectName as string || 'Smart Playwright Framework',
        environment: getFrameworkConfig().environment,
        browser,
        executionMode: 'Headed / UI',
        startTime: this.startedAt.toISOString(),
        endTime: endedAt.toISOString(),
        durationMs: endedAt.getTime() - this.startedAt.getTime(),
        total: tests.length,
        passed,
        healed,
        failed,
        skipped,
        flaky,
        interrupted,
        timedOut,
        passPercentage,
      },
      tests,
    };

    fs.mkdirSync(this.outputDir, { recursive: true });
    fs.writeFileSync(path.join(this.outputDir, 'execution-summary.json'), JSON.stringify(report, null, 2));
    fs.writeFileSync(path.join(this.outputDir, 'index.html'), renderSmartReport(report));
    await this.writeExcel(report);
  }

  printsToStdio(): boolean {
    return false;
  }

  private parseIdentity(test: TestCase, annotations: TestCase['annotations']): { testId: string; testName: string } {
    const annotationId = annotations.find(item => item.type === 'testId')?.description;
    const annotationName = annotations.find(item => item.type === 'testName')?.description;
    const match = test.title.match(/^(.*?)\s*\|\s*(.*)$/);

    return {
      testId: annotationId || match?.[1]?.trim() || test.id,
      testName: annotationName || match?.[2]?.trim() || test.title,
    };
  }

  private mapStatus(result: TestResult, healed: boolean): ReportStatus {
    if (result.status === 'passed') {
      if (healed) {
        return 'PASSED - HEALED';
      }
      if (result.retry > 0) {
        return 'FLAKY';
      }
      return 'PASSED';
    }
    if (result.status === 'skipped') return 'SKIPPED';
    if (result.status === 'timedOut') return 'TIMED OUT';
    if (result.status === 'interrupted') return 'INTERRUPTED';
    return 'FAILED';
  }

  private readProjectName(test: TestCase): string {
    try {
      return process.env.RESOLVED_BROWSER_NAME || test.parent.project()?.name || process.env.BROWSER || 'Installed Chrome/Edge';
    } catch {
      return process.env.RESOLVED_BROWSER_NAME || process.env.BROWSER || 'Installed Chrome/Edge';
    }
  }

  private formatErrors(result: TestResult): string | undefined {
    const messages = result.errors
      .map(error => error.stack || error.message || String(error))
      .filter(Boolean);
    return messages.length ? messages.join('\n\n') : undefined;
  }

  private flattenSteps(steps: TestStep[]): ReportStep[] {
    const output: ReportStep[] = [];
    const visit = (items: TestStep[], prefix = ''): void => {
      for (const step of items) {
        const title = prefix ? `${prefix} > ${step.title}` : step.title;
        output.push({
          title,
          durationMs: step.duration,
          error: step.error?.message,
        });
        visit(step.steps, title);
      }
    };
    visit(steps);
    return output;
  }

  private readHealingEvents(result: TestResult): unknown[] {
    const events: unknown[] = [];
    for (const attachment of result.attachments) {
      if (!attachment.name.startsWith('healing-') || !attachment.body) {
        continue;
      }
      try {
        events.push(JSON.parse(attachment.body.toString('utf8')));
      } catch {
        events.push({ raw: attachment.body.toString('utf8') });
      }
    }
    return events;
  }

  private processAttachments(test: TestCase, result: TestResult): ReportAttachment[] {
    const testFolder = `${this.safeName(this.parseIdentity(test, test.annotations).testId)}-retry-${result.retry}`;
    const targetFolder = path.join(this.outputDir, 'evidence', testFolder);
    fs.mkdirSync(targetFolder, { recursive: true });

    return result.attachments.map((attachment, index) => {
      if (attachment.path && fs.existsSync(attachment.path)) {
        const extension = path.extname(attachment.path);
        const fileName = `${String(index + 1).padStart(2, '0')}-${this.safeName(attachment.name)}${extension}`;
        const targetPath = path.join(targetFolder, fileName);
        fs.copyFileSync(attachment.path, targetPath);
        return {
          name: attachment.name,
          contentType: attachment.contentType,
          relativePath: path.relative(this.outputDir, targetPath).replaceAll(path.sep, '/'),
        };
      }

      if (attachment.body && !attachment.name.startsWith('healing-')) {
        const extension = this.extensionFor(attachment.contentType);
        const fileName = `${String(index + 1).padStart(2, '0')}-${this.safeName(attachment.name)}${extension}`;
        const targetPath = path.join(targetFolder, fileName);
        fs.writeFileSync(targetPath, attachment.body);
        return {
          name: attachment.name,
          contentType: attachment.contentType,
          relativePath: path.relative(this.outputDir, targetPath).replaceAll(path.sep, '/'),
        };
      }

      return {
        name: attachment.name,
        contentType: attachment.contentType,
        inlineText: attachment.body?.toString('utf8'),
      };
    });
  }

  private safeName(value: string): string {
    const cleaned = value.replace(/[^a-zA-Z0-9._-]+/g, '-').replace(/^-+|-+$/g, '');
    return cleaned || 'attachment';
  }

  private extensionFor(contentType: string): string {
    if (contentType.includes('json')) return '.json';
    if (contentType.includes('html')) return '.html';
    if (contentType.includes('plain')) return '.txt';
    if (contentType.includes('png')) return '.png';
    if (contentType.includes('jpeg')) return '.jpg';
    return '.bin';
  }

  private async writeExcel(report: SmartReportData): Promise<void> {
    const workbook = new ExcelJS.Workbook();
    workbook.creator = 'Smart Playwright Framework';
    workbook.created = new Date();

    const summary = workbook.addWorksheet('Summary');
    summary.columns = [
      { header: 'Result', key: 'result', width: 28 },
      { header: 'Count', key: 'count', width: 12 },
      { header: 'Percentage', key: 'percentage', width: 15 },
    ];
    const rows = [
      ['Total Tests', report.summary.total, 1],
      ['Passed', report.summary.passed, report.summary.total ? report.summary.passed / report.summary.total : 0],
      ['Passed with Healing', report.summary.healed, report.summary.total ? report.summary.healed / report.summary.total : 0],
      ['Failed', report.summary.failed, report.summary.total ? report.summary.failed / report.summary.total : 0],
      ['Flaky', report.summary.flaky, report.summary.total ? report.summary.flaky / report.summary.total : 0],
      ['Skipped', report.summary.skipped, report.summary.total ? report.summary.skipped / report.summary.total : 0],
    ];
    rows.forEach(row => summary.addRow(row));
    summary.getColumn(3).numFmt = '0.00%';

    const details = workbook.addWorksheet('TestResults');
    details.columns = [
      { header: 'Serial No.', key: 'serialNo', width: 12 },
      { header: 'Test ID', key: 'testId', width: 22 },
      { header: 'Test Name', key: 'testName', width: 48 },
      { header: 'Status', key: 'status', width: 22 },
      { header: 'Duration (ms)', key: 'durationMs', width: 16 },
      { header: 'Browser', key: 'browser', width: 24 },
      { header: 'Environment', key: 'environment', width: 16 },
      { header: 'Error', key: 'error', width: 70 },
    ];
    report.tests.forEach(test => details.addRow(test));
    details.views = [{ state: 'frozen', ySplit: 1 }];
    details.autoFilter = { from: 'A1', to: 'H1' };

    for (const worksheet of [summary, details]) {
      const header = worksheet.getRow(1);
      header.font = { bold: true, color: { argb: 'FFFFFFFF' } };
      header.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF1D4ED8' } };
      header.alignment = { vertical: 'middle', horizontal: 'center' };
      header.height = 24;
      worksheet.eachRow((row, rowNumber) => {
        if (rowNumber > 1) {
          row.alignment = { vertical: 'top', wrapText: true };
        }
      });
    }

    await workbook.xlsx.writeFile(path.join(this.outputDir, 'test-results.xlsx'));
  }
}
