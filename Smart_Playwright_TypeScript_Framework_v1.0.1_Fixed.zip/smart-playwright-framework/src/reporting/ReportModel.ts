export type ReportStatus = 'PASSED' | 'PASSED - HEALED' | 'FAILED' | 'SKIPPED' | 'FLAKY' | 'INTERRUPTED' | 'TIMED OUT';

export interface ReportAttachment {
  name: string;
  contentType: string;
  relativePath?: string;
  inlineText?: string;
}

export interface ReportStep {
  title: string;
  durationMs: number;
  error?: string;
}

export interface ReportTestResult {
  serialNo: number;
  testId: string;
  testName: string;
  status: ReportStatus;
  durationMs: number;
  retry: number;
  error?: string;
  browser: string;
  environment: string;
  file: string;
  tags: string[];
  steps: ReportStep[];
  attachments: ReportAttachment[];
  healingEvents: unknown[];
}

export interface ReportSummary {
  projectName: string;
  environment: string;
  browser: string;
  executionMode: 'Headed / UI';
  startTime: string;
  endTime: string;
  durationMs: number;
  total: number;
  passed: number;
  healed: number;
  failed: number;
  skipped: number;
  flaky: number;
  interrupted: number;
  timedOut: number;
  passPercentage: number;
}

export interface SmartReportData {
  summary: ReportSummary;
  tests: ReportTestResult[];
}
