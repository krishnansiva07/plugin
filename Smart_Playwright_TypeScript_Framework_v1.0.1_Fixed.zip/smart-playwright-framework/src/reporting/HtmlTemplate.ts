import type { SmartReportData } from './ReportModel';

function escapeScriptJson(value: unknown): string {
  return JSON.stringify(value).replace(/<\//g, '<\\/');
}

function formatDate(value: string): string {
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? value : date.toLocaleString();
}

export function renderSmartReport(data: SmartReportData): string {
  const { summary } = data;
  const executed = Math.max(0, summary.total - summary.skipped);

  return `<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Smart Playwright Automation Report</title>
  <style>
    :root {
      --bg: #f4f7fb;
      --surface: #ffffff;
      --surface-2: #f8fafc;
      --text: #172033;
      --muted: #667085;
      --border: #e4e7ec;
      --brand: #1d4ed8;
      --brand-dark: #173ea4;
      --pass: #15803d;
      --pass-bg: #dcfce7;
      --fail: #b42318;
      --fail-bg: #fee4e2;
      --heal: #b45309;
      --heal-bg: #fef3c7;
      --skip: #475467;
      --skip-bg: #eaecf0;
      --flaky: #7c3aed;
      --flaky-bg: #ede9fe;
      --shadow: 0 10px 28px rgba(16, 24, 40, 0.08);
    }
    * { box-sizing: border-box; }
    body {
      margin: 0;
      background: var(--bg);
      color: var(--text);
      font-family: Inter, "Segoe UI", Arial, sans-serif;
      line-height: 1.45;
    }
    .shell { max-width: 1440px; margin: 0 auto; padding: 28px; }
    .hero {
      background: linear-gradient(125deg, #0f2f6d, #1d4ed8 58%, #3b82f6);
      color: #fff;
      padding: 28px 32px;
      border-radius: 18px;
      box-shadow: var(--shadow);
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      gap: 24px;
    }
    .hero h1 { margin: 0 0 8px; font-size: 30px; letter-spacing: -0.5px; }
    .hero p { margin: 0; color: rgba(255,255,255,.82); }
    .hero-badge {
      min-width: 170px;
      border: 1px solid rgba(255,255,255,.25);
      background: rgba(255,255,255,.12);
      border-radius: 14px;
      padding: 14px 16px;
      text-align: center;
      backdrop-filter: blur(6px);
    }
    .hero-badge strong { display: block; font-size: 30px; }
    .meta-grid {
      display: grid;
      grid-template-columns: repeat(6, minmax(130px, 1fr));
      gap: 12px;
      margin: 18px 0;
    }
    .meta-item, .card, .panel {
      background: var(--surface);
      border: 1px solid var(--border);
      box-shadow: var(--shadow);
      border-radius: 14px;
    }
    .meta-item { padding: 14px 16px; }
    .meta-label { color: var(--muted); font-size: 12px; text-transform: uppercase; letter-spacing: .6px; }
    .meta-value { margin-top: 5px; font-weight: 700; word-break: break-word; }
    .summary-layout {
      display: grid;
      grid-template-columns: 1.05fr 2fr;
      gap: 18px;
      margin-bottom: 18px;
    }
    .pass-panel { padding: 22px; display: grid; grid-template-columns: 150px 1fr; gap: 22px; align-items: center; }
    .donut {
      width: 142px;
      height: 142px;
      border-radius: 50%;
      background: conic-gradient(var(--pass) 0 ${summary.passPercentage}%, #e8edf5 ${summary.passPercentage}% 100%);
      display: grid;
      place-items: center;
      position: relative;
    }
    .donut::after { content: ''; width: 102px; height: 102px; background: #fff; border-radius: 50%; position: absolute; }
    .donut-label { position: relative; z-index: 1; text-align: center; }
    .donut-label strong { display: block; font-size: 28px; }
    .donut-label span { color: var(--muted); font-size: 12px; }
    .pass-panel h2 { margin: 0 0 8px; }
    .pass-panel p { color: var(--muted); margin: 4px 0; }
    .summary-table-wrap { padding: 18px 20px; }
    .summary-table-wrap h2 { margin: 0 0 12px; font-size: 19px; }
    table { border-collapse: collapse; width: 100%; }
    th, td { border-bottom: 1px solid var(--border); padding: 12px 14px; text-align: left; }
    th { color: #344054; background: #f9fafb; font-size: 13px; text-transform: uppercase; letter-spacing: .45px; }
    .summary-table td:nth-child(2), .summary-table td:nth-child(3) { text-align: right; font-variant-numeric: tabular-nums; }
    .panel { overflow: hidden; }
    .panel-head { padding: 20px; border-bottom: 1px solid var(--border); display: flex; justify-content: space-between; gap: 16px; align-items: center; flex-wrap: wrap; }
    .panel-head h2 { margin: 0; font-size: 20px; }
    .controls { display: flex; gap: 10px; flex-wrap: wrap; }
    input[type="search"], select {
      border: 1px solid #cfd5df;
      background: #fff;
      border-radius: 9px;
      padding: 10px 12px;
      color: var(--text);
      min-width: 210px;
      outline: none;
    }
    input[type="search"]:focus, select:focus { border-color: var(--brand); box-shadow: 0 0 0 3px rgba(29,78,216,.12); }
    .results-table tbody tr.result-row { cursor: pointer; transition: background .15s ease; }
    .results-table tbody tr.result-row:hover { background: #f8fbff; }
    .results-table td:first-child { width: 90px; text-align: center; }
    .results-table th:first-child { text-align: center; }
    .status {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      min-width: 116px;
      border-radius: 999px;
      padding: 6px 11px;
      font-size: 12px;
      font-weight: 800;
      letter-spacing: .25px;
    }
    .status-passed { color: var(--pass); background: var(--pass-bg); }
    .status-failed, .status-timed-out, .status-interrupted { color: var(--fail); background: var(--fail-bg); }
    .status-passed-healed { color: var(--heal); background: var(--heal-bg); }
    .status-skipped { color: var(--skip); background: var(--skip-bg); }
    .status-flaky { color: var(--flaky); background: var(--flaky-bg); }
    .detail-row { display: none; background: #fbfcfe; }
    .detail-row.open { display: table-row; }
    .detail-box { padding: 16px 18px 22px; }
    .detail-grid { display: grid; grid-template-columns: repeat(5, minmax(130px, 1fr)); gap: 10px; margin-bottom: 14px; }
    .detail-item { background: white; border: 1px solid var(--border); border-radius: 9px; padding: 10px; }
    .detail-item span { display: block; color: var(--muted); font-size: 11px; text-transform: uppercase; }
    .detail-item strong { display: block; margin-top: 3px; font-size: 13px; word-break: break-word; }
    .detail-section { margin-top: 14px; }
    .detail-section h3 { font-size: 14px; margin: 0 0 7px; }
    .error-box { white-space: pre-wrap; background: #fff4f2; color: #912018; border: 1px solid #fecdca; padding: 12px; border-radius: 8px; max-height: 320px; overflow: auto; }
    .step-list { margin: 0; padding-left: 20px; }
    .step-list li { margin: 5px 0; }
    .attachments { display: flex; gap: 8px; flex-wrap: wrap; }
    .attachment-link { display: inline-block; text-decoration: none; color: var(--brand); background: #eff6ff; border: 1px solid #bfdbfe; border-radius: 8px; padding: 7px 10px; font-size: 12px; font-weight: 650; }
    .attachment-link:hover { background: #dbeafe; }
    .empty { text-align: center; padding: 28px; color: var(--muted); }
    footer { text-align: center; color: var(--muted); padding: 22px; font-size: 12px; }
    @media (max-width: 1100px) {
      .meta-grid { grid-template-columns: repeat(3, 1fr); }
      .summary-layout { grid-template-columns: 1fr; }
      .detail-grid { grid-template-columns: repeat(2, 1fr); }
    }
    @media (max-width: 700px) {
      .shell { padding: 12px; }
      .hero { flex-direction: column; }
      .meta-grid { grid-template-columns: 1fr 1fr; }
      .pass-panel { grid-template-columns: 1fr; text-align: center; justify-items: center; }
      .results-table { font-size: 12px; }
      th, td { padding: 10px 8px; }
      .status { min-width: auto; }
    }
    @media print {
      body { background: white; }
      .shell { max-width: none; padding: 0; }
      .hero, .meta-item, .card, .panel { box-shadow: none; }
      .controls { display: none; }
      .detail-row { display: none !important; }
    }
  </style>
</head>
<body>
  <main class="shell">
    <section class="hero">
      <div>
        <h1>Smart Playwright Automation Report</h1>
        <p>Installed Chrome/Edge · Headed UI execution · Excel-driven tests · Controlled self-healing</p>
      </div>
      <div class="hero-badge">
        <span>Overall result</span>
        <strong>${summary.passPercentage.toFixed(2)}%</strong>
        <span>pass percentage</span>
      </div>
    </section>

    <section class="meta-grid">
      <div class="meta-item"><div class="meta-label">Project</div><div class="meta-value">${summary.projectName}</div></div>
      <div class="meta-item"><div class="meta-label">Environment</div><div class="meta-value">${summary.environment}</div></div>
      <div class="meta-item"><div class="meta-label">Browser</div><div class="meta-value">${summary.browser}</div></div>
      <div class="meta-item"><div class="meta-label">Mode</div><div class="meta-value">${summary.executionMode}</div></div>
      <div class="meta-item"><div class="meta-label">Started</div><div class="meta-value">${formatDate(summary.startTime)}</div></div>
      <div class="meta-item"><div class="meta-label">Duration</div><div class="meta-value">${formatDuration(summary.durationMs)}</div></div>
    </section>

    <section class="summary-layout">
      <div class="card pass-panel">
        <div class="donut"><div class="donut-label"><strong>${summary.passPercentage.toFixed(1)}%</strong><span>Passed</span></div></div>
        <div>
          <h2>Execution quality</h2>
          <p><strong>${summary.passed + summary.healed}</strong> of <strong>${executed}</strong> executed tests passed.</p>
          <p>Skipped tests are excluded from the pass-percentage denominator.</p>
        </div>
      </div>
      <div class="card summary-table-wrap">
        <h2>Consolidated test results</h2>
        <table class="summary-table">
          <thead><tr><th>Result</th><th>Count</th><th>Percentage</th></tr></thead>
          <tbody>
            ${summaryRow('Total Tests', summary.total, summary.total)}
            ${summaryRow('Passed', summary.passed, summary.total)}
            ${summaryRow('Passed with Healing', summary.healed, summary.total)}
            ${summaryRow('Failed', summary.failed, summary.total)}
            ${summaryRow('Flaky', summary.flaky, summary.total)}
            ${summaryRow('Skipped', summary.skipped, summary.total)}
            ${summary.timedOut ? summaryRow('Timed Out', summary.timedOut, summary.total) : ''}
            ${summary.interrupted ? summaryRow('Interrupted', summary.interrupted, summary.total) : ''}
          </tbody>
        </table>
      </div>
    </section>

    <section class="panel">
      <div class="panel-head">
        <h2>Detailed test results</h2>
        <div class="controls">
          <input id="search" type="search" placeholder="Search Test ID or test name">
          <select id="statusFilter">
            <option value="ALL">All statuses</option>
            <option value="PASSED">Passed</option>
            <option value="PASSED - HEALED">Passed - Healed</option>
            <option value="FAILED">Failed</option>
            <option value="FLAKY">Flaky</option>
            <option value="SKIPPED">Skipped</option>
            <option value="TIMED OUT">Timed Out</option>
            <option value="INTERRUPTED">Interrupted</option>
          </select>
        </div>
      </div>
      <div style="overflow-x:auto">
        <table class="results-table">
          <thead>
            <tr><th>Serial No.</th><th>Test ID</th><th>Test Name</th><th>Status</th></tr>
          </thead>
          <tbody id="resultsBody"></tbody>
        </table>
      </div>
      <div id="emptyState" class="empty" hidden>No matching test results.</div>
    </section>

    <footer>Generated automatically by Smart Playwright Framework · Click a result row to view steps and evidence.</footer>
  </main>

  <script id="reportData" type="application/json">${escapeScriptJson(data)}</script>
  <script>
    const report = JSON.parse(document.getElementById('reportData').textContent);
    const body = document.getElementById('resultsBody');
    const search = document.getElementById('search');
    const statusFilter = document.getElementById('statusFilter');
    const emptyState = document.getElementById('emptyState');

    function escapeHtml(value) {
      return String(value ?? '')
        .replaceAll('&', '&amp;')
        .replaceAll('<', '&lt;')
        .replaceAll('>', '&gt;')
        .replaceAll('"', '&quot;')
        .replaceAll("'", '&#039;');
    }

    function statusClass(status) {
      return 'status-' + status.toLowerCase().replaceAll(' ', '-').replaceAll('---', '-');
    }

    function formatMs(value) {
      if (value < 1000) return value + ' ms';
      const seconds = value / 1000;
      if (seconds < 60) return seconds.toFixed(2) + ' s';
      const minutes = Math.floor(seconds / 60);
      return minutes + 'm ' + Math.round(seconds % 60) + 's';
    }

    function render() {
      const query = search.value.trim().toLowerCase();
      const status = statusFilter.value;
      const filtered = report.tests.filter(test => {
        const textMatch = !query || test.testId.toLowerCase().includes(query) || test.testName.toLowerCase().includes(query);
        const statusMatch = status === 'ALL' || test.status === status;
        return textMatch && statusMatch;
      });

      body.innerHTML = filtered.map(test => {
        const steps = test.steps.length
          ? '<ol class="step-list">' + test.steps.map(step => '<li><strong>' + escapeHtml(step.title) + '</strong> — ' + formatMs(step.durationMs) + (step.error ? '<div class="error-box">' + escapeHtml(step.error) + '</div>' : '') + '</li>').join('') + '</ol>'
          : '<span>No test steps were recorded.</span>';
        const attachments = test.attachments.filter(item => item.relativePath).length
          ? '<div class="attachments">' + test.attachments.filter(item => item.relativePath).map(item => '<a class="attachment-link" href="' + encodeURI(item.relativePath) + '" target="_blank" rel="noopener">' + escapeHtml(item.name) + '</a>').join('') + '</div>'
          : '<span>No file attachments.</span>';
        const error = test.error ? '<div class="detail-section"><h3>Error</h3><div class="error-box">' + escapeHtml(test.error) + '</div></div>' : '';
        const healing = test.healingEvents.length ? '<div class="detail-section"><h3>Healing details</h3><div class="error-box">' + escapeHtml(JSON.stringify(test.healingEvents, null, 2)) + '</div></div>' : '';

        return '<tr class="result-row" data-id="' + test.serialNo + '">' +
          '<td>' + test.serialNo + '</td>' +
          '<td><strong>' + escapeHtml(test.testId) + '</strong></td>' +
          '<td>' + escapeHtml(test.testName) + '</td>' +
          '<td><span class="status ' + statusClass(test.status) + '">' + escapeHtml(test.status) + '</span></td>' +
          '</tr>' +
          '<tr class="detail-row" id="detail-' + test.serialNo + '"><td colspan="4"><div class="detail-box">' +
            '<div class="detail-grid">' +
              '<div class="detail-item"><span>Duration</span><strong>' + formatMs(test.durationMs) + '</strong></div>' +
              '<div class="detail-item"><span>Browser</span><strong>' + escapeHtml(test.browser) + '</strong></div>' +
              '<div class="detail-item"><span>Environment</span><strong>' + escapeHtml(test.environment) + '</strong></div>' +
              '<div class="detail-item"><span>Retry</span><strong>' + test.retry + '</strong></div>' +
              '<div class="detail-item"><span>Tags</span><strong>' + escapeHtml(test.tags.join(', ') || '-') + '</strong></div>' +
            '</div>' +
            error +
            '<div class="detail-section"><h3>Steps</h3>' + steps + '</div>' +
            '<div class="detail-section"><h3>Evidence</h3>' + attachments + '</div>' +
            healing +
          '</div></td></tr>';
      }).join('');

      emptyState.hidden = filtered.length > 0;
      body.querySelectorAll('.result-row').forEach(row => {
        row.addEventListener('click', () => {
          const detail = document.getElementById('detail-' + row.dataset.id);
          detail.classList.toggle('open');
        });
      });
    }

    search.addEventListener('input', render);
    statusFilter.addEventListener('change', render);
    render();
  </script>
</body>
</html>`;
}

function summaryRow(label: string, count: number, total: number): string {
  const percentage = total === 0 ? 0 : (count / total) * 100;
  return `<tr><td>${label}</td><td>${count}</td><td>${percentage.toFixed(2)}%</td></tr>`;
}

function formatDuration(milliseconds: number): string {
  const totalSeconds = Math.max(0, Math.round(milliseconds / 1000));
  const minutes = Math.floor(totalSeconds / 60);
  const seconds = totalSeconds % 60;
  return minutes > 0 ? `${minutes}m ${seconds}s` : `${seconds}s`;
}
