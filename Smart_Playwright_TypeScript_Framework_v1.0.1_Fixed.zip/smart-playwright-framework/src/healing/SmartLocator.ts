import type { Locator, Page, TestInfo } from '@playwright/test';
import { getFrameworkConfig } from '../config/FrameworkConfig';
import { SmartLocatorError } from '../core/errors/FrameworkErrors';
import { OpenAiCompatibleClient } from '../llm/OpenAiCompatibleClient';
import type { HealingRequest } from '../llm/LlmTypes';
import { collectSanitizedPageContext } from './DomSanitizer';
import type { ElementDescriptor, LocatorSpec } from './ElementDescriptor';
import { locatorSpecToString } from './ElementDescriptor';
import { HealingRepository, type HealingEvent } from './HealingRepository';
import { createLocator } from './LocatorFactory';

export interface ResolvedLocator {
  locator: Locator;
  healed: boolean;
  method?: 'deterministic' | 'llm';
  usedSpec: LocatorSpec;
}

interface ValidationResult {
  valid: boolean;
  reason: string;
}

export class SmartLocator {
  private readonly llmClient = new OpenAiCompatibleClient();
  private readonly repository = new HealingRepository();
  private llmCalls = 0;

  constructor(
    private readonly page: Page,
    private readonly testInfo: TestInfo,
  ) {}

  async resolve(descriptor: ElementDescriptor, intendedAction: string): Promise<ResolvedLocator> {
    const diagnostics: string[] = [];
    const primary = await this.validateSpec(descriptor.primary, descriptor, diagnostics);
    if (primary.valid) {
      return {
        locator: createLocator(this.page, descriptor.primary),
        healed: false,
        usedSpec: descriptor.primary,
      };
    }

    for (const fallback of descriptor.fallbacks ?? []) {
      const validation = await this.validateSpec(fallback, descriptor, diagnostics);
      if (validation.valid) {
        const event = this.buildEvent(
          descriptor,
          intendedAction,
          'deterministic',
          fallback,
          1,
          `Deterministic fallback matched after primary locator failed: ${primary.reason}`,
        );
        await this.recordHealing(event);

        if (getFrameworkConfig().llm.healingMode === 'report') {
          throw new SmartLocatorError(
            `Healing candidate found for ${descriptor.description}, but HEALING_MODE=report does not retry actions.`,
            diagnostics,
          );
        }

        return {
          locator: createLocator(this.page, fallback),
          healed: true,
          method: 'deterministic',
          usedSpec: fallback,
        };
      }
    }

    const framework = getFrameworkConfig();
    if (!framework.llm.enabled || this.llmCalls >= framework.llm.maxCallsPerTest) {
      throw new SmartLocatorError(
        `Unable to resolve ${descriptor.description}. LLM healing is disabled or the per-test call limit was reached.`,
        diagnostics,
      );
    }

    this.llmCalls += 1;
    const context = await collectSanitizedPageContext(this.page, framework.llm.domMaxLength);
    const request: HealingRequest = {
      elementKey: descriptor.key,
      elementDescription: descriptor.description,
      intendedAction,
      failedLocator: descriptor.primary,
      diagnostics,
      pageUrl: context.pageUrl,
      pageTitle: context.pageTitle,
      accessibilitySnapshot: context.accessibilitySnapshot,
      relevantDom: context.relevantDom,
      nearbyText: descriptor.nearbyText ?? [],
    };

    const suggestion = await this.llmClient.suggestLocator(request);
    if (suggestion.confidence < framework.llm.minimumConfidence) {
      throw new SmartLocatorError(
        `LLM confidence ${suggestion.confidence} was below the minimum ${framework.llm.minimumConfidence}.`,
        diagnostics,
      );
    }

    const llmValidation = await this.validateSpec(suggestion.locator, descriptor, diagnostics);
    if (!llmValidation.valid) {
      throw new SmartLocatorError(
        `LLM locator was rejected: ${llmValidation.reason}`,
        diagnostics,
      );
    }

    const event = this.buildEvent(
      descriptor,
      intendedAction,
      'llm',
      suggestion.locator,
      suggestion.confidence,
      suggestion.reason,
    );
    await this.recordHealing(event);

    if (framework.llm.healingMode === 'report') {
      throw new SmartLocatorError(
        `LLM healing candidate found for ${descriptor.description}, but HEALING_MODE=report does not retry actions.`,
        diagnostics,
      );
    }

    return {
      locator: createLocator(this.page, suggestion.locator),
      healed: true,
      method: 'llm',
      usedSpec: suggestion.locator,
    };
  }

  private async validateSpec(
    spec: LocatorSpec,
    descriptor: ElementDescriptor,
    diagnostics: string[],
  ): Promise<ValidationResult> {
    const label = locatorSpecToString(spec);
    try {
      const locator = createLocator(this.page, spec);
      const count = await locator.count();
      if (count !== 1) {
        const reason = count === 0 ? 'matched no elements' : `matched ${count} elements`;
        diagnostics.push(`${label}: ${reason}`);
        return { valid: false, reason };
      }

      const visible = await locator.isVisible();
      if (!visible) {
        diagnostics.push(`${label}: element is not visible`);
        return { valid: false, reason: 'element is not visible' };
      }

      if (descriptor.expectedTag) {
        const tag = await locator.evaluate(element => element.tagName.toLowerCase());
        if (tag !== descriptor.expectedTag.toLowerCase()) {
          const reason = `expected <${descriptor.expectedTag}> but found <${tag}>`;
          diagnostics.push(`${label}: ${reason}`);
          return { valid: false, reason };
        }
      }

      return { valid: true, reason: 'valid' };
    } catch (error) {
      const reason = error instanceof Error ? error.message : String(error);
      diagnostics.push(`${label}: ${reason}`);
      return { valid: false, reason };
    }
  }

  private buildEvent(
    descriptor: ElementDescriptor,
    action: string,
    method: 'deterministic' | 'llm',
    healedLocator: LocatorSpec,
    confidence: number,
    reason: string,
  ): HealingEvent {
    return {
      timestamp: new Date().toISOString(),
      testId: this.readTestId(),
      elementKey: descriptor.key,
      elementDescription: descriptor.description,
      action,
      method,
      originalLocator: descriptor.primary,
      healedLocator,
      confidence,
      reason,
      pageUrl: this.page.url(),
    };
  }

  private readTestId(): string {
    return this.testInfo.annotations.find(annotation => annotation.type === 'testId')?.description
      ?? this.testInfo.title.match(/^(\S+)\s*\|/)?.[1]
      ?? this.testInfo.title;
  }

  private async recordHealing(event: HealingEvent): Promise<void> {
    this.repository.record(event);
    this.testInfo.annotations.push({
      type: 'healed',
      description: `${event.method}:${event.elementKey}`,
    });
    await this.testInfo.attach(`healing-${event.elementKey}`, {
      body: Buffer.from(JSON.stringify(event, null, 2), 'utf8'),
      contentType: 'application/json',
    });
  }
}
