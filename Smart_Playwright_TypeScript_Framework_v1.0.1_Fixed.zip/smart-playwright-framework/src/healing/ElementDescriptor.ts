import type { Page } from '@playwright/test';

export type PlaywrightRole = Parameters<Page['getByRole']>[0];

export type LocatorSpec =
  | { type: 'testId'; value: string }
  | { type: 'role'; role: PlaywrightRole; value: string; exact?: boolean }
  | { type: 'label'; value: string; exact?: boolean }
  | { type: 'placeholder'; value: string; exact?: boolean }
  | { type: 'text'; value: string; exact?: boolean }
  | { type: 'css'; value: string }
  | { type: 'xpath'; value: string };

export interface ElementDescriptor {
  key: string;
  description: string;
  primary: LocatorSpec;
  fallbacks?: LocatorSpec[];
  nearbyText?: string[];
  expectedTag?: string;
}

export function locatorSpecToString(spec: LocatorSpec): string {
  switch (spec.type) {
    case 'role':
      return `role=${spec.role}, name=${spec.value}`;
    default:
      return `${spec.type}=${spec.value}`;
  }
}

export function isLocatorSpec(value: unknown): value is LocatorSpec {
  if (!value || typeof value !== 'object') return false;
  const candidate = value as Record<string, unknown>;
  if (typeof candidate.type !== 'string' || typeof candidate.value !== 'string' || !candidate.value.trim()) return false;
  if (candidate.type === 'role') return typeof candidate.role === 'string' && candidate.role.length > 0;
  return ['testId', 'label', 'placeholder', 'text', 'css', 'xpath'].includes(candidate.type);
}
