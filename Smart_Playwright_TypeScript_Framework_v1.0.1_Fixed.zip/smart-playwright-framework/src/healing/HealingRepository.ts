import fs from 'node:fs';
import path from 'node:path';
import type { LocatorSpec } from './ElementDescriptor';

export interface HealingEvent {
  timestamp: string;
  testId: string;
  elementKey: string;
  elementDescription: string;
  action: string;
  method: 'deterministic' | 'llm';
  originalLocator: LocatorSpec;
  healedLocator: LocatorSpec;
  confidence: number;
  reason: string;
  pageUrl: string;
}

export class HealingRepository {
  private readonly outputFile: string;

  constructor(outputDirectory = path.join(process.cwd(), 'healing-results')) {
    fs.mkdirSync(outputDirectory, { recursive: true });
    this.outputFile = path.join(outputDirectory, 'healing-events.ndjson');
  }

  record(event: HealingEvent): void {
    fs.appendFileSync(this.outputFile, `${JSON.stringify(event)}\n`, 'utf8');
  }
}
