import type { Locator, Page } from '@playwright/test';
import type { LocatorSpec } from './ElementDescriptor';

export function createLocator(page: Page, spec: LocatorSpec): Locator {
  switch (spec.type) {
    case 'testId':
      return page.getByTestId(spec.value);
    case 'role':
      return page.getByRole(spec.role, { name: spec.value, exact: spec.exact });
    case 'label':
      return page.getByLabel(spec.value, { exact: spec.exact });
    case 'placeholder':
      return page.getByPlaceholder(spec.value, { exact: spec.exact });
    case 'text':
      return page.getByText(spec.value, { exact: spec.exact });
    case 'css':
      return page.locator(spec.value);
    case 'xpath':
      return page.locator(`xpath=${spec.value}`);
  }
}
