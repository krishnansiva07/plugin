import type { Page } from '@playwright/test';

export interface SanitizedPageContext {
  pageUrl: string;
  pageTitle: string;
  accessibilitySnapshot: string;
  relevantDom: string;
}

export async function collectSanitizedPageContext(
  page: Page,
  maximumLength: number,
): Promise<SanitizedPageContext> {
  const [pageTitle, accessibilitySnapshot, relevantDom] = await Promise.all([
    page.title().catch(() => ''),
    page.locator('body').ariaSnapshot().catch(() => ''),
    page.evaluate(() => {
      const clone = document.body.cloneNode(true) as HTMLElement;
      clone.querySelectorAll('script, style, noscript, svg, canvas').forEach(node => node.remove());
      clone.querySelectorAll('input, textarea').forEach(element => {
        element.setAttribute('value', '[REDACTED]');
        if (element instanceof HTMLTextAreaElement) {
          element.textContent = '[REDACTED]';
        }
      });
      clone.querySelectorAll('*').forEach(element => {
        for (const attribute of Array.from(element.attributes)) {
          const name = attribute.name.toLowerCase();
          if (name.includes('token') || name.includes('secret') || name.includes('password') ||
              name === 'authorization' || name === 'cookie') {
            element.setAttribute(attribute.name, '[REDACTED]');
          }
          if (name === 'style' || name.startsWith('on')) {
            element.removeAttribute(attribute.name);
          }
        }
      });
      return clone.outerHTML;
    }).catch(() => ''),
  ]);

  const truncate = (value: string): string => value.length <= maximumLength
    ? value
    : `${value.slice(0, maximumLength)}\n...[TRUNCATED]`;

  return {
    pageUrl: page.url(),
    pageTitle,
    accessibilitySnapshot: truncate(accessibilitySnapshot),
    relevantDom: truncate(relevantDom),
  };
}
