import { expect, type Page, type TestInfo } from '@playwright/test';
import { BasePage } from '../core/BasePage';
import type { ElementDescriptor } from '../healing/ElementDescriptor';

export class InventoryPage extends BasePage {
  private readonly productsTitle: ElementDescriptor = {
    key: 'inventory.title',
    description: 'Products page title',
    primary: { type: 'testId', value: 'title' },
    fallbacks: [
      { type: 'role', role: 'heading', value: 'Products', exact: true },
      { type: 'text', value: 'Products', exact: true },
    ],
    nearbyText: ['Products', 'Swag Labs'],
  };

  constructor(page: Page, testInfo: TestInfo) {
    super(page, testInfo);
  }

  async expectLoaded(expectedTitle = 'Products'): Promise<void> {
    const title = await this.locator(this.productsTitle, 'assert products page');
    await expect(title).toHaveText(expectedTitle, { ignoreCase: true });
    await expect(this.page).toHaveURL(/inventory\.html/i);
  }
}
