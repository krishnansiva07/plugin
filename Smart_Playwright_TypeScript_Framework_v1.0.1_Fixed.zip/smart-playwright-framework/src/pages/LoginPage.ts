import { expect, type Page, type TestInfo } from '@playwright/test';
import { BasePage } from '../core/BasePage';
import type { ElementDescriptor } from '../healing/ElementDescriptor';

export class LoginPage extends BasePage {
  private readonly username: ElementDescriptor;

  private readonly password: ElementDescriptor = {
    key: 'login.password',
    description: 'SauceDemo password input',
    primary: { type: 'testId', value: 'password' },
    fallbacks: [
      { type: 'label', value: 'Password', exact: false },
      { type: 'placeholder', value: 'Password', exact: false },
      { type: 'css', value: 'input[name="password"]' },
    ],
    expectedTag: 'input',
    nearbyText: ['Swag Labs', 'Password'],
  };

  private readonly loginButton: ElementDescriptor = {
    key: 'login.submit',
    description: 'SauceDemo Login button',
    primary: { type: 'testId', value: 'login-button' },
    fallbacks: [
      { type: 'role', role: 'button', value: 'Login', exact: true },
      { type: 'css', value: 'input[type="submit"][value="Login"]' },
    ],
    expectedTag: 'input',
    nearbyText: ['Swag Labs', 'Login'],
  };

  private readonly errorMessage: ElementDescriptor = {
    key: 'login.error',
    description: 'SauceDemo login error message',
    primary: { type: 'testId', value: 'error' },
    fallbacks: [
      { type: 'css', value: '[data-test="error"]' },
      { type: 'css', value: '.error-message-container' },
    ],
    nearbyText: ['Epic sadface'],
  };

  constructor(page: Page, testInfo: TestInfo, demoBrokenPrimary = false) {
    super(page, testInfo);
    this.username = {
      key: 'login.username',
      description: 'SauceDemo username input',
      primary: {
        type: 'testId',
        value: demoBrokenPrimary ? 'username-intentionally-broken' : 'username',
      },
      fallbacks: [
        { type: 'label', value: 'Username', exact: false },
        { type: 'placeholder', value: 'Username', exact: false },
        { type: 'css', value: 'input[name="user-name"]' },
      ],
      expectedTag: 'input',
      nearbyText: ['Swag Labs', 'Username'],
    };
  }

  async open(): Promise<void> {
    await this.page.goto('/');
    await expect(this.page).toHaveTitle(/Swag Labs/i);
  }

  async login(username: string, password: string): Promise<void> {
    await this.actions.fill(this.username, username);
    await this.actions.fill(this.password, password);
    await this.actions.click(this.loginButton);
  }

  async expectErrorContaining(expectedText: string): Promise<void> {
    const locator = await this.locator(this.errorMessage, 'assert error message');
    await expect(locator).toContainText(expectedText, { ignoreCase: true });
  }
}
