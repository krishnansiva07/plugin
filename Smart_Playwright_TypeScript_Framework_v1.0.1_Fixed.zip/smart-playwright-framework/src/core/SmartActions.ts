import type { Locator, Page, TestInfo } from '@playwright/test';
import type { ElementDescriptor } from '../healing/ElementDescriptor';
import { SmartLocator } from '../healing/SmartLocator';

export class SmartActions {
  private readonly resolver: SmartLocator;

  constructor(
    private readonly page: Page,
    testInfo: TestInfo,
  ) {
    this.resolver = new SmartLocator(page, testInfo);
  }

  async locator(descriptor: ElementDescriptor, action = 'locate'): Promise<Locator> {
    const result = await this.resolver.resolve(descriptor, action);
    return result.locator;
  }

  async click(descriptor: ElementDescriptor): Promise<void> {
    const locator = await this.locator(descriptor, 'click');
    await locator.click();
  }

  async fill(descriptor: ElementDescriptor, value: string): Promise<void> {
    const locator = await this.locator(descriptor, 'fill');
    await locator.fill(value);
  }

  async clear(descriptor: ElementDescriptor): Promise<void> {
    const locator = await this.locator(descriptor, 'clear');
    await locator.clear();
  }

  async textContent(descriptor: ElementDescriptor): Promise<string> {
    const locator = await this.locator(descriptor, 'read text');
    return (await locator.textContent())?.trim() ?? '';
  }

  async isVisible(descriptor: ElementDescriptor): Promise<boolean> {
    const locator = await this.locator(descriptor, 'check visibility');
    return locator.isVisible();
  }

  get rawPage(): Page {
    return this.page;
  }
}
