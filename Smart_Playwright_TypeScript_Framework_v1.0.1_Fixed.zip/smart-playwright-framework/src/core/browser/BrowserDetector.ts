import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { execFileSync, spawnSync } from 'node:child_process';
import type { BrowserPreference } from '../../config/FrameworkConfig';

export interface BrowserInstallation {
  name: 'chrome' | 'edge';
  displayName: 'Google Chrome' | 'Microsoft Edge';
  executablePath: string;
  version?: string;
  source: 'standard-path' | 'path' | 'registry';
}

interface CandidatePath {
  filePath: string;
  source: BrowserInstallation['source'];
}

function isFile(filePath: string | undefined): filePath is string {
  if (!filePath) {
    return false;
  }
  try {
    return fs.statSync(filePath).isFile();
  } catch {
    return false;
  }
}

function deduplicate(candidates: CandidatePath[]): CandidatePath[] {
  const seen = new Set<string>();
  return candidates.filter(candidate => {
    const key = path.normalize(candidate.filePath).toLowerCase();
    if (seen.has(key)) {
      return false;
    }
    seen.add(key);
    return true;
  });
}

function findOnPath(commands: string[]): CandidatePath[] {
  const results: CandidatePath[] = [];
  const finder = process.platform === 'win32' ? 'where.exe' : 'which';

  for (const command of commands) {
    try {
      const output = execFileSync(finder, [command], {
        encoding: 'utf8',
        stdio: ['ignore', 'pipe', 'ignore'],
        windowsHide: true,
      });
      for (const line of output.split(/\r?\n/).map(value => value.trim()).filter(Boolean)) {
        results.push({ filePath: line, source: 'path' });
      }
    } catch {
      // Command is not present on PATH.
    }
  }

  return results;
}

function queryWindowsRegistry(executableName: string): CandidatePath[] {
  if (process.platform !== 'win32') {
    return [];
  }

  const roots = [
    `HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\App Paths\\${executableName}`,
    `HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\App Paths\\${executableName}`,
    `HKLM\\SOFTWARE\\WOW6432Node\\Microsoft\\Windows\\CurrentVersion\\App Paths\\${executableName}`,
  ];
  const results: CandidatePath[] = [];

  for (const registryKey of roots) {
    try {
      const output = execFileSync('reg.exe', ['query', registryKey, '/ve'], {
        encoding: 'utf8',
        stdio: ['ignore', 'pipe', 'ignore'],
        windowsHide: true,
      });
      const match = output.match(/REG_SZ\s+(.+)$/m);
      if (match?.[1]) {
        results.push({ filePath: match[1].trim(), source: 'registry' });
      }
    } catch {
      // Registry key does not exist or is not readable.
    }
  }

  return results;
}

function standardPaths(browser: 'chrome' | 'edge'): CandidatePath[] {
  const home = os.homedir();
  const candidates: CandidatePath[] = [];

  if (process.platform === 'win32') {
    const programFiles = process.env.ProgramFiles;
    const programFilesX86 = process.env['ProgramFiles(x86)'];
    const localAppData = process.env.LOCALAPPDATA;

    const relative = browser === 'chrome'
      ? path.join('Google', 'Chrome', 'Application', 'chrome.exe')
      : path.join('Microsoft', 'Edge', 'Application', 'msedge.exe');

    for (const base of [programFiles, programFilesX86, localAppData]) {
      if (base) {
        candidates.push({ filePath: path.join(base, relative), source: 'standard-path' });
      }
    }
  } else if (process.platform === 'darwin') {
    const appPath = browser === 'chrome'
      ? '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'
      : '/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge';
    const userAppPath = browser === 'chrome'
      ? path.join(home, 'Applications', 'Google Chrome.app', 'Contents', 'MacOS', 'Google Chrome')
      : path.join(home, 'Applications', 'Microsoft Edge.app', 'Contents', 'MacOS', 'Microsoft Edge');
    candidates.push(
      { filePath: appPath, source: 'standard-path' },
      { filePath: userAppPath, source: 'standard-path' },
    );
  } else {
    const names = browser === 'chrome'
      ? ['google-chrome', 'google-chrome-stable', 'chrome']
      : ['microsoft-edge', 'microsoft-edge-stable', 'msedge'];
    candidates.push(...findOnPath(names));
  }

  return candidates;
}

function readVersion(executablePath: string): string | undefined {
  const result = spawnSync(executablePath, ['--version'], {
    encoding: 'utf8',
    timeout: 5_000,
    windowsHide: true,
  });
  const combined = `${result.stdout ?? ''} ${result.stderr ?? ''}`.trim();
  return combined.split(/\r?\n/).map(line => line.trim()).find(Boolean) || undefined;
}

export function findInstalledBrowser(browser: 'chrome' | 'edge'): BrowserInstallation | undefined {
  const executableName = browser === 'chrome' ? 'chrome.exe' : 'msedge.exe';
  const pathNames = browser === 'chrome'
    ? ['chrome', 'google-chrome', 'google-chrome-stable']
    : ['msedge', 'microsoft-edge', 'microsoft-edge-stable'];

  const candidates = deduplicate([
    ...standardPaths(browser),
    ...findOnPath(pathNames),
    ...queryWindowsRegistry(executableName),
  ]);

  const match = candidates.find(candidate => isFile(candidate.filePath));
  if (!match) {
    return undefined;
  }

  return {
    name: browser,
    displayName: browser === 'chrome' ? 'Google Chrome' : 'Microsoft Edge',
    executablePath: path.resolve(match.filePath),
    version: readVersion(match.filePath),
    source: match.source,
  };
}

export function resolveInstalledBrowser(
  preference: BrowserPreference,
  priority: Array<'chrome' | 'edge'> = ['chrome', 'edge'],
): BrowserInstallation {
  const requested = preference === 'auto' ? priority : [preference];

  for (const browser of requested) {
    const installation = findInstalledBrowser(browser);
    if (installation) {
      return installation;
    }
  }

  const requestedText = preference === 'auto'
    ? priority.map(value => value === 'chrome' ? 'Google Chrome' : 'Microsoft Edge').join(' or ')
    : preference === 'chrome' ? 'Google Chrome' : 'Microsoft Edge';

  throw new Error(
    `${requestedText} is not installed or could not be detected. ` +
    `Install Chrome or Edge, or set BROWSER to the browser that is available. ` +
    `Bundled Playwright Chromium is intentionally disabled.`,
  );
}
