import type { Locator, Page, TestInfo } from '@playwright/test';
import { SmartActions } from './SmartActions';
import type { ElementDescriptor } from '../healing/ElementDescriptor';

export abstract class BasePage {
  protected readonly actions: SmartActions;

  protected constructor(
    protected readonly page: Page,
    protected readonly testInfo: TestInfo,
  ) {
    this.actions = new SmartActions(page, testInfo);
  }

  protected locator(descriptor: ElementDescriptor, action = 'locate'): Promise<Locator> {
    return this.actions.locator(descriptor, action);
  }
}
