export class FrameworkConfigurationError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'FrameworkConfigurationError';
  }
}

export class SmartLocatorError extends Error {
  constructor(message: string, public readonly diagnostics: string[] = []) {
    super(message);
    this.name = 'SmartLocatorError';
  }
}
