import type { LocatorSpec } from '../healing/ElementDescriptor';

export interface HealingRequest {
  elementKey: string;
  elementDescription: string;
  intendedAction: string;
  failedLocator: LocatorSpec;
  diagnostics: string[];
  pageUrl: string;
  pageTitle: string;
  accessibilitySnapshot: string;
  relevantDom: string;
  nearbyText: string[];
}

export interface HealingSuggestion {
  locator: LocatorSpec;
  confidence: number;
  reason: string;
}

export interface LlmClient {
  suggestLocator(request: HealingRequest): Promise<HealingSuggestion>;
}
