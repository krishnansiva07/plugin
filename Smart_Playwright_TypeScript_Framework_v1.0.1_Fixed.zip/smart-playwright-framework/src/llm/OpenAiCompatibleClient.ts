import { getFrameworkConfig } from '../config/FrameworkConfig';
import { FrameworkConfigurationError } from '../core/errors/FrameworkErrors';
import type { LlmClient, HealingRequest, HealingSuggestion } from './LlmTypes';
import { isLocatorSpec } from '../healing/ElementDescriptor';

interface ChatCompletionResponse {
  choices?: Array<{
    message?: {
      content?: string;
    };
  }>;
}

function buildEndpoint(baseUrl: string, chatPath: string): string {
  if (/\/chat\/completions\/?$/i.test(baseUrl)) {
    return baseUrl;
  }
  return new URL(chatPath.replace(/^\//, ''), `${baseUrl.replace(/\/+$/, '')}/`).toString();
}

function parseJsonObject(content: string): unknown {
  const cleaned = content
    .replace(/^```json\s*/i, '')
    .replace(/^```\s*/i, '')
    .replace(/```$/i, '')
    .trim();

  try {
    return JSON.parse(cleaned);
  } catch {
    const firstBrace = cleaned.indexOf('{');
    const lastBrace = cleaned.lastIndexOf('}');
    if (firstBrace >= 0 && lastBrace > firstBrace) {
      return JSON.parse(cleaned.slice(firstBrace, lastBrace + 1));
    }
    throw new Error('LLM response did not contain valid JSON.');
  }
}

function isSuggestion(value: unknown): value is HealingSuggestion {
  if (!value || typeof value !== 'object') {
    return false;
  }
  const candidate = value as Partial<HealingSuggestion>;
  return Boolean(
    isLocatorSpec(candidate.locator) &&
    typeof candidate.confidence === 'number' &&
    candidate.confidence >= 0 && candidate.confidence <= 1 &&
    typeof candidate.reason === 'string',
  );
}

export class OpenAiCompatibleClient implements LlmClient {
  async suggestLocator(request: HealingRequest): Promise<HealingSuggestion> {
    const config = getFrameworkConfig().llm;
    if (!config.enabled) {
      throw new FrameworkConfigurationError('LLM healing is disabled.');
    }
    if (!config.apiKey || !config.baseUrl || !config.modelName) {
      throw new FrameworkConfigurationError(
        'LLM_ENABLED=true requires LLM_API_KEY, LLM_BASE_URL, and LLM_MODEL_NAME.',
      );
    }

    const endpoint = buildEndpoint(config.baseUrl, config.chatPath);
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), config.timeoutMs);

    const systemPrompt = [
      'You are a locator recovery service for Playwright tests.',
      'Return one JSON object only. Do not return JavaScript, markdown, prose, or XPath unless unavoidable.',
      'Prefer data-test, accessible role/name, label, placeholder, or stable CSS attributes.',
      'Never use nth-position selectors when a semantic locator can be used.',
      'Allowed locator shapes:',
      '{"type":"testId","value":"..."}',
      '{"type":"role","role":"button|textbox|heading|...","value":"accessible name","exact":true|false}',
      '{"type":"label","value":"...","exact":true|false}',
      '{"type":"placeholder","value":"...","exact":true|false}',
      '{"type":"text","value":"...","exact":true|false}',
      '{"type":"css","value":"..."}',
      'Response schema:',
      '{"locator":<allowed locator>,"confidence":0.0,"reason":"brief reason"}',
    ].join('\n');

    try {
      const response = await fetch(endpoint, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${config.apiKey}`,
        },
        body: JSON.stringify({
          model: config.modelName,
          temperature: 0,
          max_tokens: 500,
          messages: [
            { role: 'system', content: systemPrompt },
            { role: 'user', content: JSON.stringify(request) },
          ],
        }),
        signal: controller.signal,
      });

      if (!response.ok) {
        const body = await response.text();
        throw new Error(`LLM HTTP ${response.status}: ${body.slice(0, 500)}`);
      }

      const payload = await response.json() as ChatCompletionResponse;
      const content = payload.choices?.[0]?.message?.content;
      if (!content) {
        throw new Error('LLM response did not contain choices[0].message.content.');
      }

      const parsed = parseJsonObject(content);
      if (!isSuggestion(parsed)) {
        throw new Error('LLM response did not match the healing response schema.');
      }

      return parsed;
    } finally {
      clearTimeout(timeout);
    }
  }
}
