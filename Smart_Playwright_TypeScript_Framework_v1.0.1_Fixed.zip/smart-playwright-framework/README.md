# Smart Playwright TypeScript Framework

A production-style Playwright framework that:

- always launches an installed Google Chrome or Microsoft Edge browser;
- always runs in headed/UI mode;
- detects browser locations across Windows, macOS, and Linux;
- uses modern fixtures, page objects, component-friendly OOP, and web-first assertions;
- reads SauceDemo test cases from Excel;
- writes a consolidated management HTML report and Excel result file;
- publishes JUnit XML and evidence for Jenkins;
- supports deterministic and optional LLM-based locator healing without rewriting source code.

## Quick start

### 1. Prerequisites

- Node.js 22 or newer. Node.js 24 LTS is recommended.
- Installed Google Chrome or Microsoft Edge.
- npm.

### 2. Install

Check the configured npm registry first:

```bash
npm config get registry
```

Then install:

```bash
npm ci
```

Version 1.0.1 uses a portable lock file without environment-specific registry URLs. On corporate networks, npm will use the organisation-approved registry configured on the machine.

The framework intentionally does not run `playwright install`; it uses the browser already installed on the machine.

### 3. Configure

Copy `.env.example` to `.env` when custom values are required. Defaults already point to SauceDemo.

```properties
BASE_URL=https://www.saucedemo.com/
BROWSER=auto
WORKERS=1
RECORD_VIDEO=false
LLM_ENABLED=false
```

Browser selection:

- `auto`: Chrome first, Edge second.
- `chrome`: require installed Chrome.
- `edge`: require installed Edge.

Execution is always headed. There is no headless switch.

### 4. Validate the machine

```bash
npm run preflight
```

### 5. Run

```bash
npm test
npm run test:chrome
npm run test:edge
npm run test:smoke
```

### 6. Open the report

```bash
npm run report:open
```

Primary report: `reports/index.html`

Other outputs:

- `reports/test-results.xlsx`
- `reports/execution-summary.json`
- `playwright-report/index.html`
- `test-results/junit.xml`
- screenshots, traces, attachments, and optional videos
- `healing-results/healing-events.ndjson`

## Excel workbook

Edit `test-data/TestExecution.xlsx`.

- `ExecutionControl`: set `Run` to `Y` or `N`; maintain Test ID, name, and tags.
- `LoginData`: maintain input data and expected result.
- `Environment`: reference information.
- `ResultsTemplate`: shows the generated output structure.

Regenerate the sample workbook:

```bash
npm run excel:create
```

## Self-healing

Normal order:

1. primary locator;
2. deterministic semantic fallbacks;
3. optional LLM suggestion;
4. strict uniqueness, visibility, and tag validation;
5. one controlled retry;
6. healing evidence in the report.

Enable the optional LLM client:

```properties
LLM_ENABLED=true
LLM_API_KEY=...
LLM_BASE_URL=https://your-company-endpoint.example/
LLM_MODEL_NAME=your-model
LLM_CHAT_PATH=/v1/chat/completions
HEALING_MODE=runtime
```

The same settings can be supplied using `config/config.properties` with `apiKey`, `baseUrl`, and `modelName`, matching the supplied Java sample.

Run the deterministic healing demonstration:

```bash
# Windows Command Prompt
set DEMO_HEALING=true && npm run test:healing-demo

# PowerShell
$env:DEMO_HEALING='true'; npm run test:healing-demo
```

## Jenkins

The included `Jenkinsfile` targets `windows_hvd`, runs `npm ci`, executes preflight and tests, publishes JUnit, publishes `reports/index.html`, and archives all evidence.

A headed browser is visible only when the Jenkins agent runs in an interactive logged-in Windows desktop session. A background Windows service may launch the browser in a non-visible session.

## Installation troubleshooting

See `docs/NPM_INSTALL_TROUBLESHOOTING.md` for Windows `EPERM`, registry timeout, proxy, and `.npmrc` guidance.

## Full guide

See `docs/USAGE_GUIDE.md` and the supplied Word guide.

### Optional video recording

Video is disabled by default so the framework needs no Playwright browser or ffmpeg download. To enable it, set `RECORD_VIDEO=true` and install only the Playwright ffmpeg helper with `npx playwright install ffmpeg`. This does not install Chromium.
