import { defineConfig } from '@playwright/test';
import { loadEnvironment } from './src/config/EnvLoader';
import { getFrameworkConfig } from './src/config/FrameworkConfig';
import { resolveInstalledBrowser } from './src/core/browser/BrowserDetector';

loadEnvironment();
const framework = getFrameworkConfig();
const browser = resolveInstalledBrowser(framework.browser.preference, framework.browser.priority);
process.env.RESOLVED_BROWSER_NAME = browser.displayName;
process.env.RESOLVED_BROWSER_VERSION = browser.version ?? '';

if (!process.env.PW_FRAMEWORK_CONFIG_LOGGED) {
  process.env.PW_FRAMEWORK_CONFIG_LOGGED = 'true';
  console.log(`\n============================================================`);
  console.log(` SMART PLAYWRIGHT FRAMEWORK`);
  console.log(`============================================================`);
  console.log(` Environment      : ${framework.environment}`);
  console.log(` Base URL         : ${framework.baseUrl}`);
  console.log(` Browser request  : ${framework.browser.preference}`);
  console.log(` Selected browser : ${browser.displayName}`);
  console.log(` Browser version  : ${browser.version ?? 'Unable to read'}`);
  console.log(` Browser path     : ${browser.executablePath}`);
  console.log(` Execution mode   : Headed / UI`);
  console.log(` Workers          : ${framework.workers}`);
  console.log(` Self-healing     : ${framework.llm.enabled ? 'LLM + deterministic' : 'Deterministic only'}`);
  console.log(`============================================================\n`);
}

export default defineConfig({
  metadata: {
    projectName: 'Smart Playwright Framework',
    selectedBrowser: `${browser.displayName} ${browser.version ?? ''}`.trim(),
  },
  testDir: './tests',
  timeout: 60_000,
  expect: {
    timeout: 10_000,
  },
  fullyParallel: false,
  workers: framework.workers,
  retries: process.env.CI ? 1 : 0,
  forbidOnly: Boolean(process.env.CI),
  outputDir: 'test-results/artifacts',
  reporter: [
    ['line'],
    ['junit', { outputFile: 'test-results/junit.xml' }],
    ['./src/reporting/SmartHtmlReporter.ts', { outputDir: 'reports' }],
    ['html', { outputFolder: 'playwright-report', open: 'never' }],
  ],
  use: {
    baseURL: framework.baseUrl,
    browserName: 'chromium',
    headless: false,
    testIdAttribute: 'data-test',
    viewport: null,
    ignoreHTTPSErrors: true,
    actionTimeout: 15_000,
    navigationTimeout: 30_000,
    screenshot: 'only-on-failure',
    video: framework.browser.recordVideo ? 'retain-on-failure' : 'off',
    trace: 'retain-on-failure',
    launchOptions: {
      executablePath: browser.executablePath,
      slowMo: framework.browser.slowMo,
      args: ['--start-maximized'],
    },
  },
});
