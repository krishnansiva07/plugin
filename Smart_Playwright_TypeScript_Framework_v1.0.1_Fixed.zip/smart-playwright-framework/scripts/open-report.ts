import fs from 'node:fs';
import path from 'node:path';
import { spawn } from 'node:child_process';

const report = path.resolve('reports', 'index.html');
if (!fs.existsSync(report)) {
  console.error(`Report not found: ${report}\nRun npm test or npm run sample-report:create first.`);
  process.exit(1);
}

if (process.platform === 'win32') {
  spawn('cmd.exe', ['/c', 'start', '', report], { detached: true, stdio: 'ignore' }).unref();
} else if (process.platform === 'darwin') {
  spawn('open', [report], { detached: true, stdio: 'ignore' }).unref();
} else {
  spawn('xdg-open', [report], { detached: true, stdio: 'ignore' }).unref();
}

console.log(`Opened ${report}`);
