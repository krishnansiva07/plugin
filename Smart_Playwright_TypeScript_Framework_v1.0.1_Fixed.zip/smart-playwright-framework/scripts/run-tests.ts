import { spawnSync } from 'node:child_process';
import { loadEnvironment } from '../src/config/EnvLoader';

loadEnvironment();

const inputArgs = process.argv.slice(2);
const playwrightArgs: string[] = ['playwright', 'test'];

for (const arg of inputArgs) {
  if (arg.startsWith('--browser=')) {
    process.env.BROWSER = arg.split('=', 2)[1];
  } else if (arg === '--demo-healing') {
    process.env.DEMO_HEALING = 'true';
  } else {
    playwrightArgs.push(arg);
  }
}

process.env.PLAYWRIGHT_SKIP_BROWSER_DOWNLOAD = '1';

const npx = process.platform === 'win32' ? 'npx.cmd' : 'npx';

const preflight = spawnSync(npx, ['tsx', 'scripts/preflight.ts'], {
  stdio: 'inherit',
  env: process.env,
  cwd: process.cwd(),
});
if (preflight.status !== 0) {
  process.exit(preflight.status ?? 1);
}

const run = spawnSync(npx, playwrightArgs, {
  stdio: 'inherit',
  env: process.env,
  cwd: process.cwd(),
});
process.exit(run.status ?? 1);
