import fs from 'node:fs';
import path from 'node:path';

for (const folder of ['reports', 'playwright-report', 'test-results']) {
  fs.rmSync(path.join(process.cwd(), folder), { recursive: true, force: true });
}
for (const folder of ['reports', 'test-results']) {
  fs.mkdirSync(path.join(process.cwd(), folder), { recursive: true });
}
console.log('Previous reports and test results were removed.');
