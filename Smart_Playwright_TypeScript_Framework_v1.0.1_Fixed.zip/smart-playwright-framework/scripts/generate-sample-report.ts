import fs from 'node:fs';
import path from 'node:path';
import { renderSmartReport } from '../src/reporting/HtmlTemplate';
import type { SmartReportData } from '../src/reporting/ReportModel';

const now = new Date();
const report: SmartReportData = {
  summary: {
    projectName: 'Smart Playwright Framework',
    environment: 'QA',
    browser: 'Google Chrome 149',
    executionMode: 'Headed / UI',
    startTime: new Date(now.getTime() - 92_000).toISOString(),
    endTime: now.toISOString(),
    durationMs: 92_000,
    total: 5,
    passed: 3,
    healed: 1,
    failed: 1,
    skipped: 0,
    flaky: 0,
    interrupted: 0,
    timedOut: 0,
    passPercentage: 80,
  },
  tests: [
    { serialNo: 1, testId: 'TC_LOGIN_001', testName: 'Login with valid credentials', status: 'PASSED', durationMs: 8650, retry: 0, browser: 'Google Chrome', environment: 'QA', file: 'tests/login.spec.ts', tags: ['@smoke', '@regression'], steps: [{ title: 'Open SauceDemo login page', durationMs: 2600 }, { title: 'Submit login credentials', durationMs: 1900 }, { title: 'Validate expected result', durationMs: 2200 }], attachments: [], healingEvents: [] },
    { serialNo: 2, testId: 'TC_LOGIN_002', testName: 'Login with locked user', status: 'PASSED', durationMs: 7410, retry: 0, browser: 'Google Chrome', environment: 'QA', file: 'tests/login.spec.ts', tags: ['@regression'], steps: [{ title: 'Open SauceDemo login page', durationMs: 2400 }, { title: 'Submit login credentials', durationMs: 1800 }, { title: 'Validate expected result', durationMs: 1700 }], attachments: [], healingEvents: [] },
    { serialNo: 3, testId: 'TC_LOGIN_003', testName: 'Login with invalid password', status: 'PASSED', durationMs: 7280, retry: 0, browser: 'Google Chrome', environment: 'QA', file: 'tests/login.spec.ts', tags: ['@regression', '@negative'], steps: [{ title: 'Open SauceDemo login page', durationMs: 2300 }, { title: 'Submit login credentials', durationMs: 1800 }, { title: 'Validate expected result', durationMs: 1600 }], attachments: [], healingEvents: [] },
    { serialNo: 4, testId: 'TC_HEAL_001', testName: 'Recover an intentionally broken username locator', status: 'PASSED - HEALED', durationMs: 9650, retry: 0, browser: 'Google Chrome', environment: 'QA', file: 'tests/healing-demo.spec.ts', tags: ['@healing-demo'], steps: [{ title: 'Open SauceDemo login page', durationMs: 2500 }, { title: 'Resolve username with deterministic healing', durationMs: 2100 }, { title: 'Validate expected result', durationMs: 1900 }], attachments: [], healingEvents: [{ method: 'deterministic', elementKey: 'login.username', confidence: 1, reason: 'Placeholder fallback uniquely matched the visible username input.' }] },
    { serialNo: 5, testId: 'TC_LOGIN_005', testName: 'Login with empty password', status: 'FAILED', durationMs: 10420, retry: 0, browser: 'Google Chrome', environment: 'QA', file: 'tests/login.spec.ts', tags: ['@negative'], steps: [{ title: 'Open SauceDemo login page', durationMs: 2500 }, { title: 'Submit login credentials', durationMs: 1800 }, { title: 'Validate expected result', durationMs: 5500, error: 'Expected error to contain Password is required.' }], attachments: [], healingEvents: [], error: 'Expected locator to contain text "Password is required", but the actual message was different.' },
  ],
};

const outputDir = path.join(process.cwd(), 'reports');
fs.mkdirSync(outputDir, { recursive: true });
fs.writeFileSync(path.join(outputDir, 'index.html'), renderSmartReport(report));
fs.writeFileSync(path.join(outputDir, 'execution-summary.json'), JSON.stringify(report, null, 2));
console.log(`Created sample report: ${path.join(outputDir, 'index.html')}`);
