import fs from 'node:fs';
import path from 'node:path';
import { loadEnvironment } from '../src/config/EnvLoader';
import { getFrameworkConfig } from '../src/config/FrameworkConfig';
import { findInstalledBrowser, resolveInstalledBrowser } from '../src/core/browser/BrowserDetector';

loadEnvironment();

function nodeMajorVersion(): number {
  return Number(process.versions.node.split('.')[0]);
}

function pass(label: string, value: string): void {
  console.log(`[PASS] ${label.padEnd(22)} ${value}`);
}

function fail(label: string, value: string): void {
  console.error(`[FAIL] ${label.padEnd(22)} ${value}`);
}

let failed = false;
const config = getFrameworkConfig();

console.log('\nSMART PLAYWRIGHT PREFLIGHT');
console.log('------------------------------------------------------------');

if (nodeMajorVersion() >= 22) {
  pass('Node.js', process.version);
} else {
  fail('Node.js', `${process.version}; Node.js 22 or newer is required.`);
  failed = true;
}

const chrome = findInstalledBrowser('chrome');
const edge = findInstalledBrowser('edge');
console.log(`[INFO] Installed Chrome       ${chrome ? `${chrome.version ?? ''} (${chrome.executablePath})` : 'Not detected'}`);
console.log(`[INFO] Installed Edge         ${edge ? `${edge.version ?? ''} (${edge.executablePath})` : 'Not detected'}`);

try {
  const selected = resolveInstalledBrowser(config.browser.preference, config.browser.priority);
  pass('Selected browser', `${selected.displayName} - ${selected.executablePath}`);
  pass('Execution mode', 'Headed / UI');
  pass('Video recording', config.browser.recordVideo ? 'Enabled (Playwright ffmpeg required)' : 'Disabled');
} catch (error) {
  fail('Selected browser', error instanceof Error ? error.message : String(error));
  failed = true;
}

const workbook = path.join(process.cwd(), 'test-data', 'TestExecution.xlsx');
if (fs.existsSync(workbook)) {
  pass('Excel test data', workbook);
} else {
  fail('Excel test data', `${workbook} was not found. Run npm run excel:create.`);
  failed = true;
}

if (config.llm.enabled) {
  if (config.llm.apiKey && config.llm.baseUrl && config.llm.modelName) {
    pass('LLM configuration', `${config.llm.modelName} @ ${config.llm.baseUrl}`);
  } else {
    fail('LLM configuration', 'LLM_ENABLED=true but API key, base URL, or model name is missing.');
    failed = true;
  }
} else {
  pass('LLM configuration', 'Disabled; deterministic healing remains available.');
}

console.log('------------------------------------------------------------');
if (failed) {
  console.error('Preflight failed. Correct the items above before execution.\n');
  process.exit(1);
}
console.log('Preflight passed. The framework is ready to run.\n');
