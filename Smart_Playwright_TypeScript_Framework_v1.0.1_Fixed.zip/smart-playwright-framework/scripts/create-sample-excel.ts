import fs from 'node:fs';
import path from 'node:path';
import ExcelJS from 'exceljs';

const output = path.join(process.cwd(), 'test-data', 'TestExecution.xlsx');
fs.mkdirSync(path.dirname(output), { recursive: true });

const workbook = new ExcelJS.Workbook();
workbook.creator = 'Smart Playwright Framework';
workbook.created = new Date();

const control = workbook.addWorksheet('ExecutionControl');
control.columns = [
  { header: 'Run', key: 'run', width: 10 },
  { header: 'TestID', key: 'testId', width: 20 },
  { header: 'TestName', key: 'testName', width: 48 },
  { header: 'DataSheet', key: 'dataSheet', width: 18 },
  { header: 'Tags', key: 'tags', width: 24 },
];
control.addRows([
  ['Y', 'TC_LOGIN_001', 'Login with valid credentials', 'LoginData', 'smoke,regression'],
  ['Y', 'TC_LOGIN_002', 'Login with locked user', 'LoginData', 'regression'],
  ['Y', 'TC_LOGIN_003', 'Login with invalid password', 'LoginData', 'regression,negative'],
  ['Y', 'TC_LOGIN_004', 'Login with empty username', 'LoginData', 'regression,negative'],
  ['Y', 'TC_LOGIN_005', 'Login with empty password', 'LoginData', 'regression,negative'],
]);

const login = workbook.addWorksheet('LoginData');
login.columns = [
  { header: 'TestID', key: 'testId', width: 20 },
  { header: 'Username', key: 'username', width: 24 },
  { header: 'Password', key: 'password', width: 24 },
  { header: 'ExpectedType', key: 'expectedType', width: 20 },
  { header: 'ExpectedValue', key: 'expectedValue', width: 58 },
];
login.addRows([
  ['TC_LOGIN_001', 'standard_user', 'secret_sauce', 'PageTitle', 'Products'],
  ['TC_LOGIN_002', 'locked_out_user', 'secret_sauce', 'ErrorMessage', 'locked out'],
  ['TC_LOGIN_003', 'standard_user', 'invalid_password', 'ErrorMessage', 'Username and password do not match'],
  ['TC_LOGIN_004', '', 'secret_sauce', 'ErrorMessage', 'Username is required'],
  ['TC_LOGIN_005', 'standard_user', '', 'ErrorMessage', 'Password is required'],
]);

const environment = workbook.addWorksheet('Environment');
environment.columns = [
  { header: 'Key', key: 'key', width: 26 },
  { header: 'Value', key: 'value', width: 60 },
  { header: 'Description', key: 'description', width: 60 },
];
environment.addRows([
  ['BASE_URL', 'https://www.saucedemo.com/', 'Sample application base URL'],
  ['BROWSER', 'auto', 'Detect installed Chrome, then Edge'],
  ['EXECUTION_MODE', 'Headed / UI', 'Fixed framework behaviour'],
  ['LLM_ENABLED', 'false', 'Set true only after LLM values are configured'],
]);

const results = workbook.addWorksheet('ResultsTemplate');
results.columns = [
  { header: 'Serial No.', key: 'serial', width: 12 },
  { header: 'Test ID', key: 'testId', width: 20 },
  { header: 'Test Name', key: 'testName', width: 48 },
  { header: 'Status', key: 'status', width: 22 },
  { header: 'Duration', key: 'duration', width: 18 },
  { header: 'Error', key: 'error', width: 65 },
];

for (const sheet of workbook.worksheets) {
  const header = sheet.getRow(1);
  header.height = 26;
  header.font = { bold: true, color: { argb: 'FFFFFFFF' } };
  header.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF1D4ED8' } };
  header.alignment = { horizontal: 'center', vertical: 'middle' };
  sheet.views = [{ state: 'frozen', ySplit: 1 }];
  sheet.autoFilter = { from: 'A1', to: `${sheet.getColumn(sheet.columnCount).letter}1` };
  sheet.eachRow((row, rowNumber) => {
    if (rowNumber > 1) row.alignment = { vertical: 'top', wrapText: true };
  });
}

for (let row = 2; row <= 500; row += 1) {
  control.getCell(`A${row}`).dataValidation = { type: 'list', allowBlank: false, formulae: ['"Y,N"'] };
}

await workbook.xlsx.writeFile(output);
console.log(`Created ${output}`);
