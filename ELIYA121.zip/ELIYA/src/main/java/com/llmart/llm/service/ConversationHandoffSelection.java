package com.llmart.llm.service;

import java.util.*;
import java.util.regex.*;

/** Stateless selection: persisted conversation messages, not the LLM's truncated context window. */
final class ConversationHandoffSelection {
    record Turn(long id, String role, String content, List<String> attachments) {
        Turn {
            role = role == null ? "" : role;
            content = content == null ? "" : content;
            attachments = attachments == null ? List.of() : List.copyOf(attachments);
        }
    }
    record Packet(long answerId, long requirementId, String requirement, String answer,
                  List<String> attachments, List<Turn> nearby, boolean plan, boolean referential) {}

    private static final Pattern REFERENCE = Pattern.compile(
            "(?i)\\b(?:previous|earlier|above|discussed|agreed|our (?:plan|discussion|design)|" +
            "that (?:plan|approach|flow|architecture|answer)|this (?:plan|approach|flow)|" +
            "implement it|execute it|do it|as discussed|what did we decide|" +
            "based on (?:our|the) (?:chat|discussion|plan|analysis)|those (?:steps|phases)|" +
            "phase[- ]?[1-9]|please continue|go ahead)\\b");
    private static final Pattern EXPLICIT_SOURCE = Pattern.compile(
            "(?i)\\b(?:analysis|plan) from conversation message #(\\d+)\\b");
    static OptionalLong explicitSourceId(String prompt) {
        Matcher match = EXPLICIT_SOURCE.matcher(prompt == null ? "" : prompt);
        if (!match.find()) return OptionalLong.empty();
        try { long id = Long.parseLong(match.group(1)); return id > 0 ? OptionalLong.of(id) : OptionalLong.empty(); }
        catch (NumberFormatException ignored) { return OptionalLong.empty(); }
    }
    private static final Pattern PLAN = Pattern.compile(
            "(?im)(?:^\\s{0,5}#{0,4}\\s*(?:phase\\s*[1-9]|step\\s*[1-9])\\b|" +
            "\\b(?:implementation plan|execution plan|proposed plan|migration plan|phase-wise plan)\\b|" +
            "^\\s*[1-9][.)]\\s+.{10,})");
    private static final Pattern NUMBERED_STEP_LINE = Pattern.compile("(?m)^\\s*(?:[1-9]|1[0-9]|2[0-4])[.)]\\s+(.+)$");
    private static final Pattern PHASE_LINE = Pattern.compile(
            "(?im)^\\s*(?:#{1,4}\\s*)?(?:(?:phase|step)\\s*([1-9][0-9]?)\\s*[:.)\\-–]?)\\s+(.+)$");

    private ConversationHandoffSelection() {}

    static boolean isPlan(String answer) {
        return answer != null && answer.length() >= 60 && PLAN.matcher(answer).find();
    }
    static boolean isReferential(String prompt) {
        return prompt != null && (REFERENCE.matcher(prompt).find() || explicitSourceId(prompt).isPresent());
    }
    static boolean isPlanExecutionReply(String prompt) {
        if (prompt == null) return false;
        // A common Analyse -> Execute handoff is just "can you implement".
        // It is a reference to the preceding answer, not a new independent task.
        if (prompt.strip().matches("(?i)(?:can|could|would|will)\\s+you\\s+(?:please\\s+)?(?:implement|execute|apply)(?:\\s+(?:it|this|that|these|those|the\\s+(?:above\\s+)?plan))?[?.! ]*")) return true;
        if (prompt.strip().matches("(?i)(?:please\\s+)?(?:implement|execute|apply)(?:\\s+now)?[.! ]*")) return true;
        return prompt.strip().matches("(?i)(?:please\\s+)?(?:implement (?:it|the plan)|" +
                "execute (?:it|the plan)|apply (?:it|the plan)|follow (?:the|our) plan|" +
                "please continue|continue|proceed|go ahead|start implementation|" +
                "ok(?:ay)?|yes(?: please)?|do it|" +
                "(?:implement|execute|apply|follow)\\s+(?:the|our|my)\\s+plan" +
                "(?:\\s+(?:we\\s+)?discussed|\\s+above|\\s+from\\s+chat|\\s+now)?|" +
                "(?:implement|execute|apply|start)\\s+(?:the|our|my)\\s+" +
                "(?:complete|entire|whole|agreed|previous|discussed)\\s+.{0,65}?(?:plan|all phases|all steps)" +
                "(?:\\s+we discussed)?)[.! ]*");
    }

    static Optional<Packet> select(List<Turn> history, long currentUserId, String currentPrompt) {
        if (history == null || history.isEmpty()) return Optional.empty();
        OptionalLong explicitSource = explicitSourceId(currentPrompt);
        int currentIndex = history.size();
        for (int i=0;i<history.size();i++) if (history.get(i).id() == currentUserId) { currentIndex=i; break; }
        int last = -1;
        for (int i=currentIndex-1;i>=0;i--) {
            Turn turn=history.get(i);
            if (explicitSource.isPresent() && turn.id() != explicitSource.getAsLong()) continue;
            if ("assistant".equalsIgnoreCase(turn.role()) && !turn.content().isBlank()) { last=i; break; }
        }
        if (last<0) return Optional.empty();
        Turn answer = history.get(last);
        int userIndex=-1;
        for (int i=last-1;i>=0;i--) if ("user".equalsIgnoreCase(history.get(i).role())) { userIndex=i;break; }
        if (userIndex<0) return Optional.empty();
        Turn original=history.get(userIndex);
        boolean referential=isReferential(currentPrompt) || isPlanExecutionReply(currentPrompt);
        // Never silently import an unrelated old plan for a new independent task.
        if (!referential) return Optional.empty();
        LinkedHashSet<String> attachments=new LinkedHashSet<>();
        // Include relevant files attached to the initiating requirement and nearest supporting turns.
        int from=Math.max(0,userIndex-30);
        List<Turn> nearby=new ArrayList<>();
        // Bring forward attachments from the relevant recent discussion only. Older
        // uploaded files remain reachable through attachment_list, avoiding accidental
        // preloading of unrelated documents from different topics in a long conversation.
        for (int i=from;i<=last;i++) {
            attachments.addAll(history.get(i).attachments());
            Turn turn=history.get(i);
            // Earlier user decisions remain relevant even when the final Chat answer is long.
            // Assistant output is available by ID via conversation_handoff_read.
            if (i>=userIndex || "user".equalsIgnoreCase(turn.role()) || !turn.attachments().isEmpty())
                nearby.add(turn);
        }
        // With a specifically selected older analysis, keep any newer user refinements.
        // Do not bulk-import attachments or unrelated assistant answers from later turns.
        if (explicitSource.isPresent()) for (int i=last+1;i<currentIndex;i++) {
            Turn turn=history.get(i);
            if ("user".equalsIgnoreCase(turn.role())) nearby.add(turn);
        }
        return Optional.of(new Packet(answer.id(),original.id(),original.content(),answer.content(),
                List.copyOf(attachments),List.copyOf(nearby),isPlan(answer.content()),true));
    }

    static List<String> executionSteps(String plan, long sourceId) {
        List<String> steps=new ArrayList<>();
        Matcher m=PHASE_LINE.matcher(plan == null ? "" : plan);
        while (m.find() && steps.size()<24) {
            String item=m.group().strip().replaceAll("\\s+"," ");
            if (item.length()>400) item=item.substring(0,400);
            steps.add(item + " (Use conversation_handoff_read for the COMPLETE source plan; source message " + sourceId + ")");
        }
        if (steps.isEmpty()) {
            Matcher numbered = NUMBERED_STEP_LINE.matcher(plan == null ? "" : plan);
            while (numbered.find() && steps.size() < 24) {
                String item = numbered.group().strip().replaceAll("\\s+", " ");
                steps.add((item.length() > 400 ? item.substring(0, 400) : item) +
                        " (Read the complete Chat plan via conversation_handoff_read message " + sourceId + ")");
            }
        }
        if (steps.isEmpty()) {
            steps.add("Implement the agreed Chat plan from conversation message " + sourceId +
                    " using conversation_handoff_read for the complete authoritative details. Validate: verify every requested deliverable.");
        }
        return List.copyOf(steps);
    }
}
