/* ELIYA120: pure, testable protocol for user-controlled Analyse -> Agent handoff. */
(function(root,factory) {
  const api=factory();
  if (typeof module==='object' && module.exports) module.exports=api;
  if (root) root.EliyaWorkflowHandoff=api;
})(typeof window!=='undefined' ? window : null,function(){
  'use strict';
  function resolveMode({workflowMode='analyse',regenerate=false,previousAssistantMode='chat'}={}) {
    return regenerate ? (previousAssistantMode==='agent'?'agent':'chat')
      : workflowMode==='execute'?'agent':'chat';
  }
  function makePrompt(id) {
    const source=Number(id);
    if (!Number.isSafeInteger(source) || source<=0) throw new Error('A saved analysis message is required');
    return `Implement the agreed analysis from conversation message #${source} in the currently selected workspace. `+
      'Read the complete saved analysis and original requirements using conversation_handoff_read. '+
      'Implement the agreed scope, validate affected files and tests, and report verified results. '+
      'If a critical requirement is ambiguous, ask one focused question before changes.';
  }
  function canHandoff(message) {
    return !!message && message.role==='assistant' && message.mode==='chat' && !message.agentRunId &&
      !message.streaming && Number.isSafeInteger(Number(message.id)) && Number(message.id)>0 &&
      !!String(message.content||'').trim();
  }
  function validDraft({draft,conversationId,projectId,mode,message}={}) {
    if (!draft) return true;
    if (draft.conversationId!==conversationId || (draft.projectId||null)!==(projectId||null) || mode!=='agent') return false;
    const marker=new RegExp('\\banalysis from conversation message #'+Number(draft.messageId)+'\\b','i');
    return marker.test(String(message||''));
  }
  return Object.freeze({resolveMode,makePrompt,canHandoff,validDraft});
});
