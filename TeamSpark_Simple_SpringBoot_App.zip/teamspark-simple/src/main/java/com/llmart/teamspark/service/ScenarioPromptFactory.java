package com.llmart.teamspark.service;

import java.util.List;

public final class ScenarioPromptFactory {

    private ScenarioPromptFactory() {
    }

    public static String build(String category, List<String> selectedMembers) {
        String players = selectedMembers == null || selectedMembers.isEmpty()
                ? "the selected players"
                : String.join(", ", selectedMembers);

        return """
                You are the host of a light-hearted corporate team game.

                Create ONE short, funny and imaginative situation for the category: %s.
                The people who will answer are: %s.

                Requirements:
                - Make it suitable for a workplace team call.
                - Keep it playful, surprising and easy to answer verbally.
                - Avoid politics, religion, sexual content, insults, protected-class stereotypes,
                  violence, medical emergencies, illegal acts and anything humiliating.
                - Do not target or make jokes about the players' personal characteristics.
                - The English and French text must describe the SAME situation.
                - Each language should be 2 to 4 sentences maximum.
                - End each language with a question asking what the player would do.
                - Return ONLY valid JSON. No markdown and no code fence.

                Required JSON format:
                {"english":"English scenario here","french":"French scenario here"}
                """.formatted(category, players);
    }

    public static String connectionPrompt() {
        return "Reply with exactly: TeamSpark connection successful";
    }
}
