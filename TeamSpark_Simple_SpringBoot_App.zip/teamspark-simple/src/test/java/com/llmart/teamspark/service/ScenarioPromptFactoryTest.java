package com.llmart.teamspark.service;

import org.junit.jupiter.api.Test;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

class ScenarioPromptFactoryTest {

    @Test
    void promptContainsCategoryPlayersAndBilingualJsonContract() {
        String prompt = ScenarioPromptFactory.build("Forest", List.of("Siva", "Sara"));

        assertThat(prompt)
                .contains("Forest")
                .contains("Siva, Sara")
                .contains("English")
                .contains("French")
                .contains("\"english\"")
                .contains("\"french\"");
    }
}
