#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
SMOKE="$ROOT/qa/stabilization"
TEMP="$(mktemp -d)"
trap 'rm -rf "$TEMP"' EXIT
S="$ROOT/src/main/java/com/llmart/llm/service"
javac --release 17 -encoding UTF-8 -d "$TEMP/classes" \
  "$SMOKE/stubs/org/springframework/stereotype/Service.java" \
  "$SMOKE/stubs/org/apache/tika/Tika.java" \
  "$SMOKE/stubs/com/llmart/llm/dto/ChatSettings.java" \
  "$SMOKE/stubs/com/llmart/llm/service/OpenAiCompatibleClient.java" \
  "$SMOKE/stubs/com/llmart/llm/service/AgentWorkspaceService.java" \
  "$SMOKE/stubs/com/llmart/llm/service/ProtectedRunSnapshotService.java" \
  "$S/WorkspaceRetrievalIndexService.java" "$S/WorkspaceEmbeddingStore.java" \
  "$S/WorkspaceCodeIntelligence.java" "$S/WorkspaceFlowIntelligence.java" \
  "$S/WorkspaceChunkIntelligence.java" "$S/WorkspaceCallGraphService.java" \
  "$S/AgentRunService.java" "$S/AgentStageMetrics.java" \
  "$S/TokenActivityLedger.java" "$S/AgentCancelledException.java" \
  "$SMOKE/StabilizationSmoke.java"
java -Xmx768m -cp "$TEMP/classes" com.llmart.llm.service.StabilizationSmoke "$TEMP"
