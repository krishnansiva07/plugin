const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const staticRoot = path.resolve(__dirname,'../../main/resources/static');
const javaRoot = path.resolve(__dirname,'../../main/java/com/llmart/llm');
const artifacts=require(path.join(staticRoot,'response-artifacts.js'));
const workflow=require(path.join(staticRoot,'workflow-handoff.js'));
const app=fs.readFileSync(path.join(staticRoot,'app.js'),'utf8');
const java=(name)=>fs.readFileSync(path.join(javaRoot,name),'utf8');
const request='Generate one complete implementation prompt for Java Selenium to Playwright TypeScript migration.';

test('saved 994+ line migration prompt is not silently chopped in artifact extraction',()=>{
  const content='# Migration\n'+Array.from({length:1600},(_,i)=>`Step ${i}: implement and verify this mapped workspace stage.`).join('\n');
  const source=content+'\n<!-- ELIYA_PROMPT_COMPLETE -->';
  const section=artifacts.promptSections(request,source)[0];
  assert.equal(section.content,content);
  assert.equal(section.content.split('\n').length,1601);
  assert.equal(section.ready,true);
});

test('oversized prompt is handed off by an exact saved-source range, not rejected or pasted',()=>{
  const selected='# Large migration\n'+('Implement the Java Selenium to Playwright conversion and verify source parity.\n').repeat(1300);
  assert.ok(selected.length>72000);
  const source='# Analyse summary\n\n## Prompt 1\nDo unrelated thing.\n\n'+selected+'\n\n## Prompt 3\nDo not implement me.';
  const handoff=artifacts.handoffMessage(354,selected,'Migration',source);
  assert.ok(handoff.length<2000);
  assert.match(handoff,/conversation_handoff_read/);
  const exact=selected.trim();
  const start=source.indexOf(exact);
  const ref=`messageId=354 start=${start} length=${exact.length} end=${start+exact.length}`;
  assert.ok(handoff.includes(ref));
  assert.doesNotMatch(handoff,/Do unrelated thing|Do not implement me/);
  const draft={conversationId:'a',projectId:'p',messageId:354,scopeText:selected,
    scopeReference:handoff.match(/--- BEGIN SELECTED PROMPT SOURCE REFERENCE ---\n[^\n]+\n--- END SELECTED PROMPT SOURCE REFERENCE ---/)[0]};
  assert.equal(workflow.validDraft({draft,conversationId:'a',projectId:'p',mode:'agent',message:handoff}),true);
  assert.equal(workflow.validDraft({draft,conversationId:'a',projectId:'p',mode:'agent',message:handoff.replace('length='+exact.length,'length=3')}),false);
  assert.throws(()=>artifacts.handoffMessage(354,selected,'Migration','different text'),/Cannot identify/);
});

test('monitor polls active Agent endpoint independently of opening the monitor and combines both counts',()=>{
  assert.match(app,/api\('\/api\/agent\/runs\/active'\)/);
  assert.match(app,/const active = \[\.\.\.terminalActive,/);
  assert.match(app,/terminalRunIds\.has\(String\(run\.id\)\)/);
  assert.match(app,/active\.length-locallyPending\.length/);
  assert.match(app,/locallyPending\.length} connecting/);
  assert.match(app,/activeRunIds\.has\(String\(message\.agentRunId\)\)/);
  assert.match(app,/data-monitor-agent/);
  assert.match(java('controller/AgentController.java'),/GetMapping\("\/runs\/active"\)/);
  assert.match(java('service/AgentRunService.java'),/activeExecutionRuns\(\)/);
});

test('large workspace uses bounded memory per file rather than stopping at ten thousand',()=>{
  const code=java('service/WorkspaceRetrievalIndexService.java');
  assert.match(code,/eliya\.index\.maxFiles", 100_000/);
  assert.match(code,/eliya\.index\.maxScannedFiles", 300_000/);
  assert.match(code,/hasManySupportedFiles\(ws\.root\(\), COMPACT_THRESHOLD\)/);
  assert.match(code,/cachedExcerpt\(sample, compact\)/);
  assert.match(code,/indexTerms\(file, rel, sample, compact\)/);
  assert.match(code,/if \(version < 4 && count >= COMPACT_THRESHOLD\) return null/);
});
