# Screenshot report filtering update

## Screenshot mode behavior

- `ALL`: reportable screenshots from passed and failed steps are available in `screenshots-report.html`.
- `FAILURE_ONLY`: only failure snapshots are exposed in `screenshots-report.html`. Internal screenshots used for closed-loop validation are not exposed as passed report screenshots.
- `NONE`: no reportable screenshots are rendered in the screenshot HTML report.

A failure snapshot captured before a successful LangGraph healing attempt is retained, so a healed step can still contribute its failure-time screenshot when `FAILURE_ONLY` is selected.

## Screenshot HTML filters

The standalone screenshot report now supports:

- All
- Failed
- Passed
- Healed
- Rerun
- Free-text search by scenario/test/step text

The report remains standalone: images are Base64 embedded and do not depend on framework HTTP URLs.
