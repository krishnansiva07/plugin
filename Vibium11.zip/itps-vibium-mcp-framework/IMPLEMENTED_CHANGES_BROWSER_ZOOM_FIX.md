# Browser Zoom Fix

- Browser maximize behavior is unchanged.
- Removed CSS/document zoom fallback for Windows.
- Windows zoom now targets the real Chrome/Edge/Firefox window through the desktop layer.
- The active Vibium page is temporarily given a unique title so the correct browser window is targeted, including parallel execution.
- Native zoom operations are serialized across parallel workers to prevent focus races.
- Zoom is reset to 100% before applying the selected standard browser zoom step.
- `window.devicePixelRatio` is sampled before/after as a verification signal where `browser_evaluate` is available.
- The original page title is restored after zoom handling.
- If `browser_get_url` is unavailable, `location.origin` is used to determine the zoom scope.
