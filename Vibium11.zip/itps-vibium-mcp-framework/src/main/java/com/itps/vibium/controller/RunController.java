package com.itps.vibium.controller;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.itps.vibium.model.AdditionalCookie;
import com.itps.vibium.model.RunConfig;
import com.itps.vibium.model.RunStatus;
import com.itps.vibium.model.TestScenario;
import com.itps.vibium.service.RunStore;
import com.itps.vibium.service.ScenarioFileParser;
import com.itps.vibium.service.TestRunService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

@RestController
@RequestMapping("/api/runs")
public class RunController {
    private final ScenarioFileParser parser;
    private final TestRunService testRunService;
    private final RunStore runStore;
    private final ObjectMapper mapper;
    private final Path outputRoot;
    private final String defaultMcpCommand;
    private final String defaultMcpArgs;
    private final String defaultMcpMode;
    private final String defaultMcpHost;
    private final int defaultMcpPort;
    private final int defaultMcpConnectTimeoutSeconds;

    public RunController(ScenarioFileParser parser,
                         TestRunService testRunService,
                         RunStore runStore,
                         ObjectMapper mapper,
                         @Value("${runner.output-dir:target/itps-vibium-runs}") String outputDir,
                         @Value("${itps.vibium.mcp.command:vibium}") String defaultMcpCommand,
                         @Value("${itps.vibium.mcp.args:mcp}") String defaultMcpArgs,
                         @Value("${itps.vibium.mcp.mode:external-tcp}") String defaultMcpMode,
                         @Value("${itps.vibium.mcp.host:127.0.0.1}") String defaultMcpHost,
                         @Value("${itps.vibium.mcp.port:8765}") int defaultMcpPort,
                         @Value("${itps.vibium.mcp.connect-timeout-seconds:10}") int defaultMcpConnectTimeoutSeconds) {
        this.parser = parser;
        this.testRunService = testRunService;
        this.runStore = runStore;
        this.mapper = mapper;
        this.outputRoot = Path.of(outputDir);
        this.defaultMcpCommand = defaultMcpCommand;
        this.defaultMcpArgs = defaultMcpArgs;
        this.defaultMcpMode = defaultMcpMode;
        this.defaultMcpHost = defaultMcpHost;
        this.defaultMcpPort = defaultMcpPort;
        this.defaultMcpConnectTimeoutSeconds = defaultMcpConnectTimeoutSeconds;
    }

    @PostMapping("/sheets")
    public ResponseEntity<?> sheets(@RequestParam("scenarioFile") MultipartFile scenarioFile) {
        try { return ResponseEntity.ok(Map.of("sheets", parser.sheetNames(scenarioFile))); }
        catch (Exception e) { return ResponseEntity.badRequest().body(Map.of("error", e.getMessage())); }
    }

    @PostMapping(consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<?> startRun(
            @RequestParam("scenarioFile") MultipartFile scenarioFile,
            @RequestParam(required = false) List<String> sheetNames,
            @RequestParam(required = false) String llmBaseUrl,
            @RequestParam(required = false) String llmApiKey,
            @RequestParam(required = false) String llmModel,
            @RequestParam(required = false) String appBaseUrl,
            @RequestParam(defaultValue = "vibium-managed-chrome") String browserId,
            @RequestParam(required = false) String browserName,
            @RequestParam(required = false) String browserExecutable,
            @RequestParam(defaultValue = "false") boolean headless,
            @RequestParam(defaultValue = "100") int browserZoomPercent,
            @RequestParam(defaultValue = "false") boolean separateBrowserPerTest,
            @RequestParam(defaultValue = "false") boolean parallelExecution,
            @RequestParam(defaultValue = "2") int parallelThreads,
            @RequestParam(defaultValue = "false") boolean replaceSessionCookie,
            @RequestParam(required = false) String sessionCookieName,
            @RequestParam(required = false) String sessionCookieValue,
            @RequestParam(required = false) String additionalCookiesJson,
            @RequestParam(defaultValue = "true") boolean allowInsecureCertificates,
            @RequestParam(defaultValue = "true") boolean useLlm,
            @RequestParam(defaultValue = "true") boolean continueOnFailure,
            @RequestParam(defaultValue = "ALL") String screenshotMode,
            @RequestParam(defaultValue = "true") boolean strictEvidence,
            @RequestParam(defaultValue = "15") int stepTimeoutSeconds,
            @RequestParam(defaultValue = "1") int retryCount,
            @RequestParam(defaultValue = "800") int retryDelayMs,
            @RequestParam(defaultValue = "3") int maxAgentTurns,
            @RequestParam(defaultValue = "0") int failedScenarioRerunCount,
            @RequestParam(defaultValue = "true") boolean enableSelfHealing,
            @RequestParam(defaultValue = "0.75") double healingConfidenceThreshold) {
        try {
            List<TestScenario> scenarios = parser.parse(scenarioFile, sheetNames);
            if (scenarios.isEmpty()) return ResponseEntity.badRequest().body(Map.of("error", "No scenarios found in uploaded file"));
            if (replaceSessionCookie && (blank(sessionCookieName) || blank(sessionCookieValue))) {
                return ResponseEntity.badRequest().body(Map.of("error", "Cookie name and replacement value are required when cookie replacement is enabled."));
            }
            List<AdditionalCookie> additionalCookies = parseAdditionalCookies(
                    additionalCookiesJson, replaceSessionCookie ? sessionCookieName : null);

            RunConfig config = new RunConfig();
            config.setLlmBaseUrl(llmBaseUrl);
            config.setLlmApiKey(llmApiKey);
            config.setLlmModel(llmModel);
            config.setAppBaseUrl(appBaseUrl);
            config.setMcpCommand(defaultMcpCommand);
            config.setMcpArgs(defaultMcpArgs);
            // Parallel execution uses a fixed pool of independent Vibium/browser processes.
            // Separate-browser-per-test (sequential mode) also needs isolated stdio processes.
            config.setMcpMode((parallelExecution || separateBrowserPerTest) ? "process-stdio" : defaultMcpMode);
            config.setMcpHost(defaultMcpHost);
            config.setMcpPort(defaultMcpPort);
            config.setMcpConnectTimeoutSeconds(defaultMcpConnectTimeoutSeconds);
            config.setBrowserId(browserId);
            config.setBrowserName(blank(browserName) ? browserId : browserName);
            config.setBrowserExecutable(browserExecutable);
            config.setHeadless(headless);
            config.setBrowserZoomPercent(Math.max(50, Math.min(browserZoomPercent, 200)));
            // In parallel mode the selected browser count is the entire pool; browsers are reused
            // across tests and immediate failed-scenario reruns. Separate-per-test applies only
            // when parallel execution is off.
            config.setSeparateBrowserPerTest(!parallelExecution && separateBrowserPerTest);
            config.setParallelExecution(parallelExecution);
            config.setParallelThreads(Math.max(1, Math.min(parallelThreads, 4)));
            config.setReplaceSessionCookie(replaceSessionCookie);
            config.setSessionCookieName(blank(sessionCookieName) ? null : sessionCookieName.trim());
            config.setSessionCookieValue(sessionCookieValue);
            config.setAdditionalCookies(additionalCookies);
            config.setAllowInsecureCertificates(allowInsecureCertificates);
            config.setUseLlm(useLlm);
            config.setContinueOnFailure(continueOnFailure);
            config.setStrictEvidence(strictEvidence);
            config.setScreenshotMode(blank(screenshotMode) ? "ALL" : screenshotMode);
            config.setStepTimeoutSeconds(Math.max(3, Math.min(stepTimeoutSeconds, 60)));
            config.setRetryCount(Math.max(0, Math.min(retryCount, 3)));
            config.setRetryDelayMs(Math.max(100, Math.min(retryDelayMs, 5000)));
            config.setMaxAgentTurns(Math.max(1, Math.min(maxAgentTurns, 6)));
            // Agentic Step (LangGraph) is now the only supported execution engine.
            config.setEnableAgenticActions(true);
            config.setFailedScenarioRerunCount(Math.max(0, Math.min(failedScenarioRerunCount, 5)));
            config.setEnableSelfHealing(enableSelfHealing);
            config.setHealingConfidenceThreshold(Math.max(0.50, Math.min(healingConfidenceThreshold, 0.99)));

            RunStatus status = testRunService.start(scenarios, config);
            return ResponseEntity.ok(status);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    private List<AdditionalCookie> parseAdditionalCookies(String json, String replacementCookieName) throws Exception {
        if (blank(json)) return List.of();
        List<AdditionalCookie> cookies = mapper.readValue(json, new TypeReference<>() { });
        if (cookies == null || cookies.isEmpty()) return List.of();
        if (cookies.size() > 10) throw new IllegalArgumentException("A maximum of 10 additional cookies can be added.");

        Set<String> names = new LinkedHashSet<>();
        for (AdditionalCookie cookie : cookies) {
            if (cookie == null || blank(cookie.getName()) || cookie.getValue() == null || cookie.getValue().isBlank()) {
                throw new IllegalArgumentException("Every additional cookie requires both a name and value.");
            }
            cookie.setName(cookie.getName().trim());
            if (!names.add(cookie.getName())) {
                throw new IllegalArgumentException("Additional cookie names must be unique: " + cookie.getName());
            }
            if (!blank(replacementCookieName) && replacementCookieName.trim().equals(cookie.getName())) {
                throw new IllegalArgumentException("Additional cookie '" + cookie.getName()
                        + "' duplicates the cookie selected for replacement.");
            }
        }
        return List.copyOf(cookies);
    }


    @PostMapping("/{runId}/rerun")
    public ResponseEntity<?> rerunSelected(@PathVariable String runId, @RequestBody Map<String, List<String>> request) {
        try {
            return ResponseEntity.ok(testRunService.rerunSelected(runId, request.get("testIds")));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    @GetMapping("/{runId}")
    public ResponseEntity<?> getRun(@PathVariable String runId) {
        return runStore.get(runId).<ResponseEntity<?>>map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.status(404).body(Map.of("error", "Run not found")));
    }

    @GetMapping("/{runId}/report.json")
    public ResponseEntity<?> downloadJson(@PathVariable String runId) { return download(runId, "report.json", MediaType.APPLICATION_JSON_VALUE, true); }
    @GetMapping("/{runId}/report.xlsx")
    public ResponseEntity<?> downloadExcel(@PathVariable String runId) { return download(runId, "report.xlsx", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", true); }
    @GetMapping("/{runId}/report.html")
    public ResponseEntity<?> downloadHtml(@PathVariable String runId) { return download(runId, "report.html", MediaType.TEXT_HTML_VALUE, false); }
    @GetMapping("/{runId}/outlook-report.html")
    public ResponseEntity<?> outlookHtml(@PathVariable String runId) { return download(runId, "outlook-report.html", MediaType.TEXT_HTML_VALUE, false); }
    @GetMapping("/{runId}/screenshots-report.html")
    public ResponseEntity<?> screenshotsHtml(@PathVariable String runId) { return download(runId, "screenshots-report.html", MediaType.TEXT_HTML_VALUE, false); }
    @GetMapping("/{runId}/screenshots.zip")
    public ResponseEntity<?> downloadScreenshots(@PathVariable String runId) { return download(runId, "screenshots.zip", "application/zip", true); }
    @GetMapping("/{runId}/screenshots/{filename:.+}")
    public ResponseEntity<?> screenshot(@PathVariable String runId, @PathVariable String filename) { return download(runId, "screenshots/" + filename, MediaType.IMAGE_PNG_VALUE, false); }
    @GetMapping("/{runId}/mcp-tools.json")
    public ResponseEntity<?> mcpTools(@PathVariable String runId) { return download(runId, "mcp-tools.json", MediaType.APPLICATION_JSON_VALUE, true); }
    @GetMapping("/{runId}/mcp-transcript.json")
    public ResponseEntity<?> mcpTranscript(@PathVariable String runId) { return download(runId, "mcp-transcript.json", MediaType.APPLICATION_JSON_VALUE, true); }
    @GetMapping("/{runId}/mcp-process.log")
    public ResponseEntity<?> mcpProcessLog(@PathVariable String runId) { return download(runId, "mcp-process.log", MediaType.TEXT_PLAIN_VALUE, true); }
    @GetMapping("/{runId}/report-generation.log")
    public ResponseEntity<?> reportGenerationLog(@PathVariable String runId) { return download(runId, "report-generation.log", MediaType.TEXT_PLAIN_VALUE, true); }

    private ResponseEntity<?> download(String runId, String relativeFile, String contentType, boolean attachment) {
        try {
            Path runDir = outputRoot.resolve(runId).normalize();
            Path path = runDir.resolve(relativeFile).normalize();
            if (!path.startsWith(runDir) || !Files.exists(path)) {
                if ("report.html".equals(relativeFile)) {
                    String html = "<!doctype html><html><body style=\"font-family:Segoe UI,Arial;margin:30px\"><h2>Report not available yet</h2><p>The run is still executing or report generation failed before the report file was written.</p><p>Run ID: " + runId + "</p></body></html>";
                    return ResponseEntity.ok().contentType(MediaType.TEXT_HTML).body(new ByteArrayResource(html.getBytes()));
                }
                return ResponseEntity.status(404).body(Map.of("error", "File not found"));
            }
            byte[] bytes = Files.readAllBytes(path);
            ByteArrayResource resource = new ByteArrayResource(bytes);
            ResponseEntity.BodyBuilder builder = ResponseEntity.ok()
                    .contentType(MediaType.parseMediaType(contentType))
                    .contentLength(bytes.length)
                    .header(HttpHeaders.CACHE_CONTROL, "no-store, no-cache, must-revalidate")
                    .header(HttpHeaders.CONTENT_DISPOSITION,
                            (attachment ? "attachment" : "inline") + "; filename=\"" + path.getFileName() + "\"");
            return builder.body(resource);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    private boolean blank(String value) { return value == null || value.trim().isEmpty(); }
}
