package com.itps.vibium.service;

/**
 * Serializes native desktop-window operations that temporarily require foreground focus.
 * This prevents parallel browser workers from stealing focus while another worker is
 * applying a browser-level command such as Chrome zoom.
 */
final class NativeBrowserUiLock {
    static final Object LOCK = new Object();

    private NativeBrowserUiLock() { }
}
