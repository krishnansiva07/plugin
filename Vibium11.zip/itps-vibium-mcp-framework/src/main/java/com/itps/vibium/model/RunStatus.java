package com.itps.vibium.model;

import java.time.Instant;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

public class RunStatus {
    private String runId;
    private volatile String status = "CREATED";
    private Instant startedAt;
    private Instant finishedAt;
    private volatile int total;
    private volatile int executed;
    private volatile int passed;
    private volatile int failed;
    private volatile int running;
    private volatile int pending;
    private volatile double passPercentage;
    private volatile String message;
    private volatile String screenshotMode = "ALL";
    private List<ScenarioResult> scenarios = new CopyOnWriteArrayList<>();

    public String getRunId() { return runId; }
    public void setRunId(String runId) { this.runId = runId; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public Instant getStartedAt() { return startedAt; }
    public void setStartedAt(Instant startedAt) { this.startedAt = startedAt; }
    public Instant getFinishedAt() { return finishedAt; }
    public void setFinishedAt(Instant finishedAt) { this.finishedAt = finishedAt; }
    public int getTotal() { return total; }
    public void setTotal(int total) { this.total = total; }
    public int getExecuted() { return executed; }
    public void setExecuted(int executed) { this.executed = executed; }
    public int getPassed() { return passed; }
    public void setPassed(int passed) { this.passed = passed; }
    public int getFailed() { return failed; }
    public void setFailed(int failed) { this.failed = failed; }
    public int getRunning() { return running; }
    public void setRunning(int running) { this.running = running; }
    public int getPending() { return pending; }
    public void setPending(int pending) { this.pending = pending; }
    public double getPassPercentage() { return passPercentage; }
    public void setPassPercentage(double passPercentage) { this.passPercentage = passPercentage; }
    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }
    public String getScreenshotMode() { return screenshotMode; }
    public void setScreenshotMode(String screenshotMode) { this.screenshotMode = screenshotMode == null || screenshotMode.isBlank() ? "ALL" : screenshotMode; }
    public List<ScenarioResult> getScenarios() { return scenarios; }
    public void setScenarios(List<ScenarioResult> scenarios) {
        this.scenarios = new CopyOnWriteArrayList<>(scenarios == null ? List.of() : scenarios);
    }
}
