# Browser maximize and zoom fixes

## Browser maximize
- Browser startup still passes `--start-maximized` when the installed Vibium `browser_start` schema supports launch arguments.
- After startup, the framework now prefers Vibium's native `browser_window` OS-window state and requests the schema's maximized enum value.
- Required width/height values are supplied when an installed Vibium schema requires them.
- On Windows, older Vibium builds fall back to the Win32 `ShowWindowAsync(..., SW_MAXIMIZE)` call with retries while the new browser window is being created.
- The same behavior is used by normal execution, shared-browser execution, parallel browser pools, separate-browser execution, and the UI recorder.

## Real browser zoom
- The selected UI value is posted as `browserZoomPercent` and stored in `RunConfig`.
- Reruns now copy `browserZoomPercent`; they no longer fall back to 100%.
- Browser zoom uses Vibium `browser_keys`, first resetting the browser to 100% (`Ctrl+0` / `Cmd+0`) and then applying Chrome's native zoom steps.
- Supported UI values map to native Chrome zoom levels: 50, 67, 75, 80, 90, 100, 110, 125, 150, 175 and 200 percent.
- Zoom is applied after navigation/state-changing actions so it remains correct when the test enters a different origin.
- CSS zoom remains only as a compatibility fallback for an old MCP build without `browser_keys`; it is no longer the primary implementation.
