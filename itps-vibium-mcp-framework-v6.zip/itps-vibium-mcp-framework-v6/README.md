# ITPS VIBIUM Framework V6

Java Spring Boot application for executing Excel/JSON scenarios through Vibium MCP and generating consolidated and technical reports.

## Run

```cmd
set VIBIUM_SKIP_BROWSER_DOWNLOAD=1
mvn clean spring-boot:run
```

Open `http://localhost:8090`.

## Configuration

The Vibium MCP command is configured in `src/main/resources/application.properties`:

```properties
itps.vibium.mcp.command=C:\\tools\\vibium-portable\\node_modules\\.bin\\vibium.cmd
itps.vibium.mcp.args=mcp
```

## Reports

Each run writes files under:

```text
target/itps-vibium-runs/<run-id>/
```

- `report.html` – consolidated results
- `logs.html` – searchable technical logs
- `report.xlsx`
- `report.json`
- `screenshots.zip`
- `mcp-transcript.json`
- `mcp-process.log`
- `report-generation.log` when an individual report artifact fails

## V6 fixes

- Fixed Java `Instant` JSON serialization by registering Jackson Java Time support.
- Report artifacts are generated independently, so one failed format does not block the others.
- Fixed HTML opening and binary file downloads.
- Reduced status text to `PASSED`, `FAILED`, or `COMPLETED`.
- Simplified the UI and removed unnecessary marketing/implementation text.
- LLM base URL and model are fixed; only the token is empty per run.
- Retained installed-browser selection.
