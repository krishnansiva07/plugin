/* ELIYA77: deterministic, zero-token choice of the existing Chat or Agent backend.
 * A single composer owns the conversation; model modes are implementation details.
 * Uncertain workspace-related requests route to Agent so Eliya can investigate.
 */
(function (root, factory) {
  const router = factory();
  if (typeof module === 'object' && module.exports) module.exports = router;
  if (root) root.EliyaUnifiedRouting = router;
})(typeof window !== 'undefined' ? window : null, function () {
  'use strict';
  const ACTION = /\b(?:implement|apply|execute|fix|refactor|migrate|deploy|build|modify|edit|change|update|delete|remove|rollback|run|test|compile|install|create|generate|produce|write|save|export|add|commit|push|merge|develop|configure|set up|setup)\b/i;
  const FOLLOWUP = /^(?:ok(?:ay)?|yes(?: please)?|no(?: thanks)?|please continue|continue|go ahead|proceed|do it|implement it|execute it|apply it|start|yes[,.]? (?:do it|proceed|continue|implement|create|add|fix)|anything else|what about (?:that|it)|explain (?:that|it)|tell me more|why|how|and then|next|phase\s*\d+)[.!?\s]*$/i;
  const WORKSPACE = /\b(?:workspace|codebase|repository|repo|project|framework|pipeline|architecture|class|method|function|module|testng|selenium|playwright|java\s+(?:code|class)|mcp|jira|confluence|deep\s*search|source\s*code|agents?|skills?|gap\s*analysis|failure\s*report|(?:implementation|execution|action)\s*plan|phase[ -]?wise|end.to.end|e2e)\b/i;
  const SOCIAL = /^(?:hi|hello|hey|good\s+(?:morning|afternoon|evening)|thanks?(?:\s+you)?|thank you|bye|goodbye|how are you)[!.?\s]*$/i;
  const GENERAL = /^(?:what is|what are|who is|when is|where is|define|meaning of|tell me about|explain)\b/i;
  const DOCUMENT = /\.(?:docx?|pdf|xlsx?|pptx?|java|ts|js|zip|json|md|txt)$/i;

  function decide({ text = '', attachments = [], previousAssistantMode = '', previousUserText = '', hasWorkspace = false } = {}) {
    const prompt = String(text || '').trim();
    const files = Array.isArray(attachments) ? attachments : [];
    if (!prompt && files.length) return 'agent';
    if (ACTION.test(prompt)) return 'agent';
    if (FOLLOWUP.test(prompt) && (previousAssistantMode === 'agent' || WORKSPACE.test(previousUserText))) return 'agent';
    if (WORKSPACE.test(prompt)) return 'agent';
    if (files.some(file => DOCUMENT.test(String(file?.name || '')))) return 'agent';
    if (SOCIAL.test(prompt)) return 'chat';
    if (GENERAL.test(prompt) && !hasWorkspace && previousAssistantMode !== 'agent') return 'chat';
    if (previousAssistantMode === 'agent') return 'agent';
    if (hasWorkspace && /\b(?:analy[sz]e|investigate|inspect|review|compare|trace|check|find|look|search|why|how|describe|explain)\b/i.test(prompt)) return 'agent';
    return 'chat';
  }
  return Object.freeze({ decide });
});
