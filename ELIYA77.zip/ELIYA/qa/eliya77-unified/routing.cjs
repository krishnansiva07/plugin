const assert=require('node:assert/strict');
const {decide}=require('../../src/main/resources/static/unified-routing.js');
const cases=[
  ['Hello','chat'],['Thank you','chat'],['What is polymorphism?','chat'],
  ['Can you tell me the E2E Deep Search working principle?','agent'],
  ['Analyze the complete Java Selenium framework architecture','agent'],
  ['Check any agents configured in workspace','agent'],
  ['Generate all possible tests based on the attached Word document','agent'],
  ['Create one code review agent and reusable skill','agent'],
  ['Analyze BMSA-1234 using Jira MCP','agent'],
  ['Implement the four-phase migration','agent'],
  ['Create a plan for my automation framework','agent'],
  ['Fix this flaky test','agent'],
  ['Rollback last operation','agent'],
];
for(const [text,wanted] of cases){const route=decide({text}); assert.equal(route,wanted,text);}
assert.equal(decide({text:'Please continue',previousAssistantMode:'chat',previousUserText:'Create a 4-phase implementation plan'}),'agent');
assert.equal(decide({text:'OK',previousAssistantMode:'agent'}),'agent');
assert.equal(decide({text:'Explain phase 2',previousAssistantMode:'agent'}),'agent');
assert.equal(decide({text:'',attachments:[{name:'report.docx'}]}),'agent');
assert.equal(decide({text:'Explain this',attachments:[{name:'report.pdf'}]}),'agent');
assert.equal(decide({text:'What is dependency injection?',previousAssistantMode:'agent'}),'agent'); // prior Agent context
assert.equal(decide({text:'hi',previousAssistantMode:'agent'}),'chat');
console.log('PASS ELIYA77 unified routing: 20 scenarios');
