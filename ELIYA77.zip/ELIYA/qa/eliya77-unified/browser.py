"""Mock Chromium validation for one-composer UI + actual routed send payloads."""
import asyncio,re
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parents[2]/'src/main/resources/static'
async def main():
 async with async_playwright() as pw:
  browser=await pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
  for width in (1440,390):
   page=await browser.new_page(viewport={'width':width,'height':850})
   errors=[]
   page.on('pageerror',lambda error:errors.append(str(error)))
   html=re.sub(r'<script src="[^"]+"></script>','',(ROOT/'index.html').read_text())
   html=re.sub(r'<link rel="stylesheet"[^>]+>','',html)
   await page.set_content(html)
   await page.add_style_tag(content=(ROOT/'app.css').read_text())
   await page.evaluate('''() => {window.__posted=[];window.fetch=async(url,opts={})=>{
      if(String(url).includes('/api/chat/stream')){
       window.__posted.push(JSON.parse(opts.body));
       return new Response('event: done\\ndata: {}\\n\\n',{status:200,headers:{'Content-Type':'text/event-stream'}});
      }
      return new Response(JSON.stringify([]),{status:200,headers:{'Content-Type':'application/json'}});
    };}''')
   for name in ['markdown.js','prompt-catalog.js','unified-routing.js','app.js','confluence-composer.js']:
    await page.add_script_tag(content=(ROOT/name).read_text())
   assert await page.locator('.mode-tab').count()==0,'Chat/Agent buttons still rendered'
   assert await page.locator('#messageInput').count()==1
   assert await page.get_by_text('ELIYA',exact=True).count()>0
   assert await page.locator('#chatModelPicker').is_hidden()
   assert await page.locator('#agentModelPicker').is_hidden()
   await page.evaluate('''() => {
     state.config.apiKey='local-test';state.config.baseUrl='http://fake-provider';
     state.config.model='agent-test-model';state.config.chatModel='chat-test-model';
     state.conversationId='conv-test';
     state.project={id:'proj-test',name:'Test project',localWorkspace:true};
     state.messages=[];
   }''')
   for prompt,expected in [('Hi','chat'),('Check any agents configured in the workspace','agent'),('Implement the plan we discussed','agent')]:
    await page.locator('#messageInput').fill(prompt)
    await page.locator('#sendBtn').click()
    await page.wait_for_function('(n) => window.__posted.length>=n',arg=(1 if prompt=='Hi' else 2 if prompt.startswith('Check') else 3))
    found=await page.evaluate('window.__posted[window.__posted.length-1]')
    assert found['mode']==expected,(prompt,found['mode'])
    assert found['conversationId']=='conv-test'
    await page.wait_for_function('() => !state.streaming')
   assert await page.evaluate('document.documentElement.scrollWidth<=window.innerWidth+2'),'Horizontal overflow'
   assert not errors,errors
   await page.close()
  await browser.close()
 print('PASS ELIYA77 unified UI: 1440/390 widths, no toggles, Chat→Agent→Agent routing in same conversation, no JS errors')
asyncio.run(main())
