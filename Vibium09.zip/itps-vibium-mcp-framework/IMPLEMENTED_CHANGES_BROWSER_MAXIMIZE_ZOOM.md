# Browser maximize and zoom

- Headed browsers now request maximized launch mode.
- If Vibium exposes browser launch arguments, the framework sends `--start-maximized`.
- For Vibium schemas that do not expose launch arguments, the framework uses a non-fatal browser-evaluate maximize fallback.
- Browser zoom can be selected in the UI from 50% to 200%; default is 100%.
- The zoom setting is passed through the run API into `RunConfig` and is used in shared, parallel-pool, and separate-browser-per-test execution.
- Zoom is re-applied after state-changing browser actions/navigation so page reloads do not silently reset it.
- The UI recorder uses the same maximize and zoom preference.
- Presentation-setting failures never fail a test scenario.
