@echo off
echo Building Astra Automation Quiz...
call mvn clean package -DskipTests
if errorlevel 1 (
  echo Build failed. Please check Java 17 and Maven installation.
  pause
  exit /b 1
)
echo Starting application on http://localhost:8090/index.html
java -jar target\astra-automation-quiz-1.0.0.jar
pause
