package com.astraquiz;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AstraAutomationQuizApplication {
    public static void main(String[] args) {
        SpringApplication.run(AstraAutomationQuizApplication.class, args);
    }
}
