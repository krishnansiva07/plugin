package com.astraquiz.config;

import dev.langchain4j.model.chat.ChatLanguageModel;
import dev.langchain4j.model.openai.OpenAiChatModel;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.time.Duration;

@Configuration
public class ChatConfig {

    @Value("${astra.llm.api-key:${llm.api-key:}}")
    private String apiKey;

    @Value("${astra.llm.model-name:${llm.model-name:gpt-oss-120b}}")
    private String modelName;

    /**
     * This value is used exactly as configured.
     * Example: astra.llm.base-url=https://ai4devs.group.echonet/api/v1
     * No /chat/completions or /completions is appended in Astra code.
     */
    @Value("${astra.llm.base-url:${llm.base-url:}}")
    private String baseUrl;

    @Value("${astra.llm.timeout-ms:${llm.timeout-ms:60000}}")
    private long timeoutMs;

    @Bean
    public ChatLanguageModel chatLanguageModel() {
        if (apiKey == null || apiKey.isBlank()) {
            throw new IllegalStateException("LLM API key is empty. Set astra.llm.api-key in application.properties");
        }
        if (baseUrl == null || baseUrl.isBlank()) {
            throw new IllegalStateException("LLM base URL is empty. Set astra.llm.base-url in application.properties");
        }

        System.out.println("[Astra Quiz] LangChain4j baseUrl configured as: " + baseUrl);
        System.out.println("[Astra Quiz] LangChain4j model configured as: " + modelName);

        return OpenAiChatModel.builder()
                .apiKey(apiKey)
                .modelName(modelName)
                .baseUrl(baseUrl)
                .temperature(0.9)
                .maxTokens(900)
                .timeout(Duration.ofMillis(timeoutMs))
                .build();
    }
}
