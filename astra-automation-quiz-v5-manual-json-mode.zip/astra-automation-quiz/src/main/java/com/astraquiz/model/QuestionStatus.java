package com.astraquiz.model;
public enum QuestionStatus { ACTIVE, PRIMARY_CORRECT, CENTRAL_POOL, STOLEN, CLOSED }
