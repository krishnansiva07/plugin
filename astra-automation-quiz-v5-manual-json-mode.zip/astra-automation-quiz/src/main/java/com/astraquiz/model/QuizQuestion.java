package com.astraquiz.model;

import java.util.LinkedHashMap;
import java.util.Map;

public class QuizQuestion {
    private String id;
    private String assignedTeam;
    private String technology;
    private Difficulty difficulty;
    private int points;
    private String questionText;
    private Map<String, String> options = new LinkedHashMap<>();
    private String correctOption;
    private String explanation;
    private QuestionStatus status = QuestionStatus.ACTIVE;
    private String winnerTeam;
    private String primaryAnswer;
    private String stealAnswer;

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getAssignedTeam() { return assignedTeam; }
    public void setAssignedTeam(String assignedTeam) { this.assignedTeam = assignedTeam; }
    public String getTechnology() { return technology; }
    public void setTechnology(String technology) { this.technology = technology; }
    public Difficulty getDifficulty() { return difficulty; }
    public void setDifficulty(Difficulty difficulty) { this.difficulty = difficulty; }
    public int getPoints() { return points; }
    public void setPoints(int points) { this.points = points; }
    public String getQuestionText() { return questionText; }
    public void setQuestionText(String questionText) { this.questionText = questionText; }
    public Map<String, String> getOptions() { return options; }
    public void setOptions(Map<String, String> options) { this.options = options; }
    public String getCorrectOption() { return correctOption; }
    public void setCorrectOption(String correctOption) { this.correctOption = correctOption; }
    public String getExplanation() { return explanation; }
    public void setExplanation(String explanation) { this.explanation = explanation; }
    public QuestionStatus getStatus() { return status; }
    public void setStatus(QuestionStatus status) { this.status = status; }
    public String getWinnerTeam() { return winnerTeam; }
    public void setWinnerTeam(String winnerTeam) { this.winnerTeam = winnerTeam; }
    public String getPrimaryAnswer() { return primaryAnswer; }
    public void setPrimaryAnswer(String primaryAnswer) { this.primaryAnswer = primaryAnswer; }
    public String getStealAnswer() { return stealAnswer; }
    public void setStealAnswer(String stealAnswer) { this.stealAnswer = stealAnswer; }
}
