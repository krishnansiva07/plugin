package com.astraquiz.model;
public enum Difficulty { SIMPLE, MEDIUM, COMPLEX }
