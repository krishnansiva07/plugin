package com.astraquiz.dto;
import java.util.List;

public class CreateQuizRequest {
    public boolean manualMode = false;
    public java.util.List<ManualQuestionDto> manualQuestions = new java.util.ArrayList<>();
    public String quizName;
    public List<String> teamNames;
    public List<String> technologies;
    public int simplePerTeam = 3;
    public int mediumPerTeam = 2;
    public int complexPerTeam = 1;
    public int simplePoints = 5;
    public int mediumPoints = 10;
    public int complexPoints = 20;
}
