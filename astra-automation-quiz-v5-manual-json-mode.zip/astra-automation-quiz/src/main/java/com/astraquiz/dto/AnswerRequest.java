package com.astraquiz.dto;
public class AnswerRequest {
    public String teamName;
    public String answer;
}
