package com.astraquiz.dto;

import java.util.LinkedHashMap;
import java.util.Map;

public class ManualQuestionDto {
    public String technology;
    public String difficulty;
    public String questionType;
    public int points;
    public String questionText;
    public Map<String, String> options = new LinkedHashMap<>();
    public String correctOption;
    public String explanation;
}
