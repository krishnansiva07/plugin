package com.astraquiz.dto;

public class ActionResponse {
    public boolean correct;
    public String message;
    public Object data;
    public ActionResponse() {}
    public ActionResponse(boolean correct, String message, Object data) {
        this.correct = correct; this.message = message; this.data = data;
    }
}
