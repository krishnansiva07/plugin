package com.astraquiz.controller;

import com.astraquiz.dto.*;
import com.astraquiz.model.QuizQuestion;
import com.astraquiz.model.QuizSession;
import com.astraquiz.service.QuizService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/quiz")
@CrossOrigin
public class QuizController {
    private final QuizService quizService;
    public QuizController(QuizService quizService) { this.quizService = quizService; }

    @PostMapping("/create")
    public QuizSession create(@RequestBody CreateQuizRequest request) { return quizService.create(request); }

    @GetMapping("/{quizId}")
    public Object get(@PathVariable String quizId) { return quizService.snapshot(quizService.get(quizId)); }

    @PostMapping("/{quizId}/next-question")
    public QuizQuestion next(@PathVariable String quizId) { return quizService.nextQuestion(quizId); }

    @PostMapping("/{quizId}/submit-primary")
    public ActionResponse submitPrimary(@PathVariable String quizId, @RequestBody AnswerRequest request) { return quizService.submitPrimary(quizId, request); }

    @PostMapping("/{quizId}/submit-steal")
    public ActionResponse submitSteal(@PathVariable String quizId, @RequestBody AnswerRequest request) { return quizService.submitSteal(quizId, request); }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<ActionResponse> handle(Exception ex) { return ResponseEntity.badRequest().body(new ActionResponse(false, ex.getMessage(), null)); }
}
