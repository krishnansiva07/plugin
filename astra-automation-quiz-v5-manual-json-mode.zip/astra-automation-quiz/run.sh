#!/usr/bin/env bash
set -e
echo "Building Astra Automation Quiz..."
mvn clean package -DskipTests
echo "Starting application on http://localhost:8090/index.html"
java -jar target/astra-automation-quiz-1.0.0.jar
