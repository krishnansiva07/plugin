# Astra Automation Quiz

LLM-powered live quiz host for automation teams.

## LLM connectivity

This build uses LangChain4j configuration like your working sample.

`astra.llm.base-url` is used as configured:

```properties
astra.llm.base-url=https://ai4devs.group.echonet/api/v1
```

Astra code does **not** append `/chat/completions` or `/completions`.

## Configure

Edit `src/main/resources/application.properties`:

```properties
astra.llm.demo-mode=false
astra.llm.base-url=https://ai4devs.group.echonet/api/v1
astra.llm.api-key=YOUR_API_KEY_HERE
astra.llm.model-name=gpt-oss-120b
astra.llm.timeout-ms=60000
```

Rotate any key that was shared in screenshots before using this in a real environment.

## Run

```bash
mvn clean package
java -jar target/astra-automation-quiz-1.0.0.jar
```

Open:

```text
http://localhost:8090/index.html
```

## Windows quick run

```bat
run.bat
```

## Console confirmation

When you click **Generate Next Question**, console should show:

```text
[Astra Quiz] Demo mode: false
[Astra Quiz] Calling LLM using LangChain4j baseUrl: https://ai4devs.group.echonet/api/v1
[Astra Quiz] Model: gpt-oss-120b
```

## Manual JSON Question Bank Mode

This version supports two question sources:

1. **LLM Dynamic Questions** - questions are generated using the configured LLM.
2. **Manual JSON Question Bank** - upload a JSON file containing your own questions, options, correct answer and explanation.

From the setup page, select **Manual JSON Question Bank**, upload your `.json` file, then create the quiz. The same quiz features are available:

- Team rotation
- Simple / Medium / Complex question count per team
- Hidden Quiz Master answer panel
- Reveal answer to audience
- Central Pool / steal points
- Leaderboard
- Winner screen

### Supported JSON format

You can upload either an array:

```json
[
  {
    "technology": "Selenium Java",
    "difficulty": "SIMPLE",
    "questionText": "Which wait is best for clickable button?",
    "options": {
      "A": "Thread.sleep()",
      "B": "WebDriverWait with elementToBeClickable",
      "C": "driver.close()",
      "D": "Implicit wait of 30 minutes"
    },
    "correctOption": "B",
    "explanation": "WebDriverWait waits for the actual clickable condition."
  }
]
```

Or wrapped format:

```json
{
  "questions": [
    {
      "technology": "API Automation",
      "difficulty": "MEDIUM",
      "questionText": "What is the best validation after POST?",
      "options": {
        "A": "Only response time",
        "B": "201 status plus body/schema and optional GET validation",
        "C": "Ignore body",
        "D": "Only logs"
      },
      "correctOption": "B",
      "explanation": "Strong API validation confirms status, content and persisted state."
    }
  ]
}
```

A sample file is included: `sample-questions.json`.
