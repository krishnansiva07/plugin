package com.llmart.llm.service;

import java.util.List;

/** How input typed during a running task is presented to the executor. */
final class AgentUserInputPrompt {
    private AgentUserInputPrompt() { }

    static String render(List<AgentRunService.UserInput> inputs, int activeStep, boolean planLocked) {
        StringBuilder out = new StringBuilder("[USER INPUT DURING EXECUTION] The user added the following while you were working")
                .append(inputs.size() > 1 ? " (in order)" : "").append(":\n");
        int n = 0;
        for (AgentRunService.UserInput input : inputs)
            out.append(inputs.size() > 1 ? (++n) + ". " : "").append(input.text().strip()).append('\n');
        out.append("\nApply this to the SAME task, starting from your current state (do not restart or redo completed work). ")
                .append("If it corrects or narrows the task, follow it. If it adds a requirement, include it in the current or ")
                .append("remaining steps")
                .append(planLocked && activeStep > 0 ? " (active step " + activeStep + "); the final verification must cover it" : "")
                .append(". If it conflicts with an earlier instruction, the newest user input wins. ")
                .append("It does NOT grant new permissions, approvals or access beyond the original task; if it needs them, say so. ")
                .append("Briefly acknowledge it in your next response.");
        return out.toString();
    }
}
