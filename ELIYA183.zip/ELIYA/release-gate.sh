#!/bin/bash
# ELIYA release gate (ELIYA180). Runs the full Maven build with tests and every acceptance suite from the CI workflow
# in strict mode: a suite that cannot run is a FAILURE, never a silent pass. Prints PASS / FAIL per step and exits
# non-zero if anything failed. Live acceptance (real model, browser, Windows) is a separate, manual checklist:
# docs/RELEASE-ACCEPTANCE.md — a release needs both.
#
# Usage: bash release-gate.sh            (from the project root; Git Bash on Windows works)
#        ELIYA_GATE_SKIP_MAVEN=1 bash release-gate.sh   (offline suites only — NOT a release)
set -uo pipefail
cd "$(dirname "$0")"
export ELIYA_REQUIRE_FULL_QA=1
LOG_DIR="target/release-gate"; mkdir -p "$LOG_DIR"
pass=0; fail=0; results=()
step() {
  local name="$1"; shift
  local log="$LOG_DIR/$(echo "$name" | tr -c 'A-Za-z0-9._-' '_').log"
  if "$@" >"$log" 2>&1; then pass=$((pass+1)); results+=("PASS  $name"); else fail=$((fail+1)); results+=("FAIL  $name  (log: $log)"); fi
  echo "${results[-1]}"
}
if [ "${ELIYA_GATE_SKIP_MAVEN:-}" != "1" ]; then
  MVN=mvn; [ -x ./mvnw ] && MVN=./mvnw
  step "maven full-tests verify" $MVN -B -Pfull-tests -Dmaven.test.skip=false clean verify
  step "executable jar present" bash -c 'ls target/*.jar >/dev/null 2>&1'
else
  results+=("SKIP  maven full-tests verify (ELIYA_GATE_SKIP_MAVEN=1 — this run cannot certify a release)"); echo "${results[-1]}"
fi
step "browser/JS contract tests" bash -c 'node --test src/test/js/*.test.js'
# Every qa command listed in the CI workflow.
while IFS= read -r cmd; do
  step "$cmd" bash -c "$cmd"
done < <(grep -E '^\s+(bash|python3|node) qa/' .github/workflows/verify-eliya.yml | sed -E 's/^\s+//' | sort -u)
echo
echo "Release gate: $pass passed, $fail failed."
printf '%s\n' "${results[@]}" > "$LOG_DIR/summary.txt"
if [ "$fail" -gt 0 ] || [ "${ELIYA_GATE_SKIP_MAVEN:-}" = "1" ]; then echo "NOT RELEASABLE"; exit 1; fi
echo "Automated gate passed. Complete docs/RELEASE-ACCEPTANCE.md on the target Windows host before releasing."
