# BNP-Green Native PowerPoint Charts

## Goal

Extend the predefined presentation engine so layout selection can choose an editable Microsoft PowerPoint chart when the source contains meaningful numeric data. The chart is not a screenshot: Apache POI creates a native OOXML chart and embedded chart workbook.

## Supported chart designs

- `COLUMN` — small discrete comparisons.
- `BAR` — rankings, many categories, or long category labels.
- `LINE` — time series and ordered trends.
- `AREA` — cumulative/volume/adoption trends where magnitude emphasis is useful.
- `PIE` — compact one-time part-to-whole.
- `DOUGHNUT` — compact composition/mix view.
- `SCATTER` — relationship/correlation between two numeric measures.
- `RADAR` — profile across 3-8 comparable dimensions.

The renderer deliberately avoids 3-D chart effects because they reduce readability and do not match the BNP-green professional design language.

## Content-first selection

The PowerPoint prompt selects `data-layout="CHART"` only when the source contains real numeric values and also supplies `data-chart`. The source-backed table remains the data contract. Java independently validates chartability and can conservatively infer a chart type if the LLM omitted metadata.

Selection examples:

- `Monthly pass-rate trend` -> `LINE`
- `Execution volume over time` -> `AREA`
- `Defects ranked by module` -> `BAR`
- `Pass count by suite` -> `COLUMN`
- `Automation mix` -> `DOUGHNUT`
- `Defect share` -> `PIE`
- `Execution time vs test count` -> `SCATTER`
- `Capability maturity profile` -> `RADAR`

If the numeric story is weak or data cannot be parsed safely, the exporter falls back to a native table instead of inventing a visualization.

## BNP-green chart styling

Charts use the existing BNP-green presentation palette, white/mint surfaces, restrained green series shades, thin borders, bottom legends where useful, and an optional `Key insights` panel. Chart slides use the same title, footer and slide-number system as every other predefined design.

## Lossless pagination

Chart layouts have category/series density limits. Overflow produces continuation chart slides rather than shrinking text or dropping values. Uncharted descriptive columns are preserved in follow-up `Data detail` table slides.

## Regression coverage added

`ExportServicePowerPointTest` now covers:

- all eight native chart families;
- chart-type selection metadata;
- conservative automatic LINE inference when metadata is absent;
- 15-category chart pagination and continuation slides;
- preservation of first/last chart categories;
- fallback from an invalid chart request without dropping subsection content.

`DocumentRendererTest` also verifies that both `data-layout` and `data-chart` survive sanitization.

## Build verification note

The project is Maven-based. In the current sandbox Maven and the project dependency cache are unavailable, and outbound dependency download is blocked. The modified Java files were parsed by `javac` with no syntax-level errors, and Apache POI API calls were checked against the official POI Javadocs. A complete dependency-resolved `mvn test` run must still be executed in a Maven-enabled environment before claiming a fully green suite.
