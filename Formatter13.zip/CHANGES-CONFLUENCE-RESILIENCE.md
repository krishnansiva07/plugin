# Confluence generation improvements

This build extends the presentation/LLM resilience work to Confluence generation.

## Canonical Confluence rendering

- Confluence preview and clipboard copy now reuse the same canonical HTML fragment.
- The canonical renderer normalizes one page title, heading hierarchy, adjacent lists, table sections and callouts.
- Repeated H1 titles created by large-document chunk boundaries are removed or demoted instead of appearing as duplicate page titles.
- No table row, list item or code line is intentionally truncated by the Confluence renderer.
- Confluence API HTML export can use the generated canonical HTML instead of rebuilding from an empty compatibility document.

## Native Confluence-safe structures

The LLM is now instructed and reviewed to prefer:

- one optional H1 page title;
- H2/H3 section hierarchy;
- native unordered/ordered lists;
- real HTML tables with header cells;
- pre/code blocks for technical content;
- blockquotes for note/warning/tip callouts.

It is explicitly instructed not to simulate tables, cards, columns or panels with divs, spacing or ASCII art.

## Markdown recovery

If the model unexpectedly returns Markdown instead of HTML, the deterministic recovery path now understands:

- headings;
- bullets and numbered lists;
- Markdown tables;
- blockquotes;
- fenced code blocks;
- bold and inline code;
- horizontal rules.

Markdown tables are recovered as real HTML tables before Confluence rendering.

## Content coverage checks

Confluence FORMAT review now checks for:

- multiple H1 page titles;
- broken heading-level jumps;
- header-less tables;
- pipe-delimited pseudo-tables;
- loss of representative technical identifiers and values.

These checks can trigger the existing bounded repair pass before finalization.

## LLM resilience

The existing `formatflow.llm.max-attempts=10` policy remains active. Transient LLM requests are retried by the client up to 10 total attempts. If the LLM is still unavailable, the local source-preserving fallback continues the Confluence flow and the UI explicitly reports:

`LLM issue: unavailable after 10 attempts.`

## Added regression coverage

Tests were added for:

- identical Confluence preview/copy canonical structure;
- repeated H1 normalization;
- adjacent list merging;
- real table header/body normalization;
- Markdown table/code/callout recovery;
- preservation of 14 table data rows;
- API Confluence HTML export using canonical content.
