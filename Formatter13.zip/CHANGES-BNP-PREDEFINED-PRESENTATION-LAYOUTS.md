# BNP-Green Predefined Presentation Layouts

## Goal

Move PowerPoint generation from generic shape drawing to a predefined BNP-green design catalog where the layout is selected before the slide wording is finalized.

## New presentation contract

For PowerPoint, the LLM is instructed to return one `h1` deck title and slide headings like:

```html
<h2 data-layout="THREE_CARDS">UI Guide – Key Configuration Areas</h2>
```

Supported layout values:

- `EXECUTIVE_OVERVIEW`
- `KEY_MESSAGE`
- `BULLETS`
- `TWO_COLUMN`
- `THREE_CARDS`
- `FOUR_CARDS`
- `PROCESS_5`
- `CHECKLIST`
- `TABLE`
- `CHART`
- `CODE`
- `COMPARISON`
- `TIMELINE`
- `NEXT_STEPS`

Java also supports internally generated `AGENDA` slides.

## Layout-aware content shaping

The CREATE prompt now selects the layout first and then changes the content structure to fit it:

- 3 cards -> exactly 3 H3 groups, each with 1-3 points.
- 4 cards -> exactly 4 H3 groups.
- 2 column / comparison -> exactly 2 H3 groups.
- 5-step process -> 3-5 ordered steps.
- Checklist -> compact readiness/setup items.
- Code -> `pre/code`, with JSON/code line structure preserved.
- Table -> true HTML table.
- Chart -> source-backed numeric table plus a native chart type selected for the numeric story.
- Key message -> one strong statement and only short supporting points.

Wording may be shortened, grouped or reorganized for slide fitness, but important technical facts, identifiers, values and constraints must remain represented. Overflow becomes a continuation slide.

## Java validation and fallback

- `data-layout` survives sanitization.
- REVIEW checks that PowerPoint slides use a valid predefined layout and that the body structure matches it.
- The exporter reads the layout metadata and renders the corresponding deterministic design.
- If the model omits layout metadata, Java infers a safe layout from the slide title and structure.
- Content is paginated before rendering; it is not silently truncated to satisfy a layout.
- If all 10 LLM attempts fail, the existing deterministic fallback remains available and layout inference still works.

## BNP-green visual system

The PowerPoint renderer now uses a consistent green/white design language:

- white canvas
- green top accent and dark-green edge accent
- larger green slide titles
- subtle green borders and mint highlight surfaces
- numbered green process badges
- 2+1 three-card composition inspired by the supplied reference deck
- 2x2 four-card layout
- bordered two-column/comparison layouts
- checklist square markers
- monospaced code/JSON panel
- horizontal timeline treatment
- native editable BNP-green charts when numeric content supports visualization
- consistent slide number/footer line

No external BNP logo or proprietary image is embedded; the implementation uses a BNP-green visual theme only.

## Regression coverage added

- `data-layout` is preserved by the HTML sanitizer.
- 3-card, process, checklist and code layouts are accepted by the PowerPoint exporter.
- JSON/code text remains present in the generated deck.
- Existing lossless bullet/table pagination tests remain in place.
