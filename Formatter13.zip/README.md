# FormatFlow AI — LangGraph Editorial Edition

FormatFlow AI is a Java 17 + Spring Boot application focused on four destinations:

- **Confluence**
- **Email / Outlook**
- **HTML**
- **PowerPoint / PPTX**

The configured model remains **`gpt-oss-120b`**. The application now uses **LangGraph4j** to orchestrate the model instead of sending every formatting request through one flat generation pass.

## Active workflow

The normal formatting path is now:

```text
Pasted text / uploaded document
        ↓
┌──────────────────────────┐
│ ANALYZE                   │
│ Build one global          │
│ editorial plan            │
└────────────┬─────────────┘
             ↓
┌──────────────────────────┐
│ CREATE                    │
│ Unrestricted editorial    │
│ formatting with the plan  │
└────────────┬─────────────┘
             ↓
┌──────────────────────────┐
│ REVIEW                    │
│ Quality + repetition +    │
│ destination fitness       │
└────────────┬─────────────┘
             │
       PASS  │  NEEDS REPAIR
        ┌────┘        │
        ↓             ↓
    FINALIZE       REPAIR
        ↑             │
        └──────── REVIEW
             ↓
       Java sanitizer
             ↓
 Confluence / Email / HTML / PowerPoint
```

The repair loop is deliberately bounded. By default the graph allows **one repair pass maximum**, so it cannot keep regenerating indefinitely.

The workflow is also **fail-open for model outages**. Each transient LLM request is attempted up to **10 times** first. If all 10 attempts fail during ANALYZE, CREATE or REVIEW, FormatFlow preserves the best content available and uses a deterministic local fallback for the failed stage. A confirmed outage then opens a request-scoped circuit so the remaining chunks do not keep calling the same unavailable service. The browser still receives a normal preview response and clearly shows that the LLM was unavailable after 10 attempts.

## PowerPoint generation

PowerPoint is now a first-class output destination. The LangGraph CREATE node produces a slide-ready semantic outline:

- `h1` becomes the deck title
- each `h2` becomes a slide title
- bullets are kept short and presentation-ready
- tables are used only when the source is genuinely comparative or tabular
- rich source content is encouraged to become multiple focused slides instead of one overloaded page

The backend converts the generated HTML into a native `.pptx` using Apache POI. PowerPoint now uses a **predefined BNP-green layout catalog** rather than drawing every slide as the same generic structure. Each generated `h2` can declare `data-layout`, and the model is instructed to select the layout before shaping the body content.

Supported predefined designs include:

- Executive overview / objectives
- Key message / statement
- Standard bullets
- Two-column
- Three cards (2 + 1 composition)
- Four cards (2 x 2)
- Five-step process
- Checklist / quick start
- Table
- Native chart (column, bar, line, area, pie, doughnut, scatter, radar)
- Code / JSON
- Comparison
- Timeline / roadmap
- Next steps

The selected design affects the requested content structure: for example `THREE_CARDS` asks the model for exactly three coherent H3 groups, `PROCESS_5` asks for 3-5 ordered steps, and `CODE` preserves `pre/code` line structure. Java validates the resulting structure, infers a safe layout if metadata is missing, and paginates overflow into continuation slides instead of dropping content. The design system uses green/white surfaces, green headings and accents, consistent slide numbering, card borders, process badges and safe typography. PowerPoint text boxes use autofit only as a final visual safety net.

Numeric content can now use the native `CHART` layout. The LLM selects a chart only from real source-backed numeric tables, and Java can safely infer a chart when metadata is missing. Supported editable PowerPoint chart designs are `COLUMN`, `BAR`, `LINE`, `AREA`, `PIE`, `DOUGHNUT`, `SCATTER` and `RADAR`. The renderer applies the BNP-green palette and paginates crowded categories/series into continuation slides; if the data is unsuitable for a chart it falls back to a table rather than inventing values.

## LangGraph4j

The project uses:

```xml
<dependency>
    <groupId>org.bsc.langgraph4j</groupId>
    <artifactId>langgraph4j-core</artifactId>
    <version>1.8.20</version>
</dependency>
```

No second AI model is required. `gpt-oss-120b` is used for ANALYZE, CREATE and REVIEW/REPAIR.

## What the model is allowed to do

The CREATE node has editorial freedom. It may:

- rewrite and correct grammar
- reorganize content by meaning
- split one paragraph into headings + bullets
- merge duplicated/repeated points
- condense verbose wording
- create headings and subheadings
- create bullets and numbered procedures
- create tables when information is genuinely tabular
- create simple callouts for important information
- use small indicative Unicode/emoji symbols where useful
- follow clear formatting/editing instructions included directly in the user's input

It is still instructed **not to invent facts** and to preserve literal technical identifiers, URLs, code, configuration values and API names unless the user explicitly asks to change them.

## Why ANALYZE first

For a small input, ANALYZE gives CREATE a clear editorial direction.

For a very large input, ANALYZE is more important: it receives a representative beginning/middle/end sample plus structure/instruction hints and produces **one shared editorial plan**. Every later chunk receives that same plan, which reduces the "several model answers stitched together" effect.

## Large content

Long documents are processed in bounded CREATE calls. Very large single-paragraph inputs are also hard-split.

Every CREATE chunk receives:

- the **global editorial plan** from ANALYZE
- a short opening excerpt from the original document
- the tail of the previous generated chunk
- the current source chunk
- reviewer repair guidance when a repair pass is active

The model is explicitly told not to repeat opening context or previous output.

Current chunk setting:

```properties
formatflow.llm.chunk-characters=9000
```

The editorial path uses a practical minimum target of about 14,000 characters per chunk.

## REVIEW node

After CREATE, the graph performs two types of checks.

### Java checks

The application detects obvious problems such as:

- duplicate headings across chunks
- exact repeated long paragraphs/list points
- unsupported/unsafe HTML
- H1-style document hierarchy in an email body
- empty/unreadable output

### LLM review

The reviewer checks:

- Confluence / Outlook / HTML destination fitness
- hierarchy and scanability
- unnecessary repetition
- inappropriate table/list usage
- preservation of factual and technical details

The reviewer returns small strict JSON used only for routing. It does **not** directly replace the draft.

Default graph settings:

```properties
formatflow.langgraph.max-repairs=1
formatflow.langgraph.review-threshold=80
formatflow.langgraph.plan-sample-characters=18000
formatflow.langgraph.review-sample-characters=28000
```

## Confluence

Confluence output remains deliberately simple and paste-friendly. The model can use:

```text
h1-h4
paragraphs
bullets / numbered lists
tables
blockquote callouts
pre/code
strong / emphasis
links
```

Model-generated CSS, scripts, forms, images, iframes and unsupported markup are removed before preview/copy.

**Copy for Confluence** writes both `text/html` and a structured plain-text fallback to the clipboard.

## Email / Outlook

Email uses the same graph but different destination guidance. The CREATE node is instructed to produce a concise email body rather than a document page. The Java renderer then applies conservative inline formatting suitable for Outlook-style editors.

The email subject remains separate from the copied body and can be entered manually or generated by a small additional model call. If that optional subject call fails, a deterministic subject is generated locally so the already-formatted email body is never lost.

## HTML

HTML uses the same semantic draft but receives the richer portable green/white web-document renderer after sanitization.

## LLM configuration

The API key is entered on the launch screen and stored only in the server-side HTTP session.

```properties
formatflow.llm.base-url=https://ai4devs.group.echonet/api/v1
formatflow.llm.model=gpt-oss-120b
formatflow.llm.chat-path=/chat/completions
```

The key is intentionally not stored in `application.properties`.

## Build and run

Requirements:

- Java 17+
- Maven 3.9+

```bash
mvn clean test
mvn clean package
java -jar target/formatflow-ai-0.0.1-SNAPSHOT.jar
```

Open:

```text
http://localhost:8090
```

## Suggested Confluence input

The main content box can contain content alone or content plus instructions, for example:

```text
I want this content neatly formatted for a new joiner. Use indicative bullets where helpful,
avoid repeating points and make it more reader friendly.

About me application allows employees to maintain their profiles, access appraisal reviews
and track the inventory of training programs...
```

ANALYZE is explicitly instructed to recognize that first paragraph as an editing instruction rather than page content, and CREATE is allowed to follow it.

## Reliability controls retained

Editorial freedom applies to **content editing**, not executable output. Java still:

- sanitizes all model HTML
- removes scripts and unsupported tags/attributes
- restricts link protocols to safe web/mail links
- keeps the LLM API key session-only
- does not intentionally log uploaded content or API keys
- provides a structured plain-text clipboard fallback
- bounds the LangGraph repair loop

## Tests added for the graph

`LlmOrchestratorLangGraphTest` covers:

- ANALYZE → CREATE → passing REVIEW → FINALIZE
- failed REVIEW → one REPAIR → second REVIEW → FINALIZE

The frontend JavaScript is syntax-checked during packaging work. Run `mvn clean test` in the development environment to resolve Maven Central dependencies and execute the full Java test suite.

## Rich Confluence clipboard and editorial coverage

The active LangGraph editorial path now separates **semantic generation** from **clipboard presentation**:

- The model keeps producing clean semantic HTML without CSS.
- Confluence copy adds deterministic inline heading colours, table borders, table-header colours and callout presentation after sanitization.
- The browser first attempts a normal rich DOM selection copy for Confluence, then falls back to `ClipboardItem` rich HTML and finally structured plain text.
- FORMAT mode explicitly preserves topic coverage rather than summarizing unique content.
- Long/rich content is reviewed for too-few topic headings.
- Confluence/HTML headings are prompted and reviewed for relevant, varied topic icons.

The styling is intentionally applied outside the model so visual consistency does not depend on model behaviour.

### PowerPoint generation

PowerPoint output uses a presentation-specific LangGraph path. The model creates a slide story with a deck title, slide titles, key takeaways, topic panels, process lists and tables where useful. Java then renders the result as a native `.pptx` using a consistent green/white design, automatic agenda slide, smart slide splitting, two-column topic slides, process slides and bordered table slides.

## Robust rich-DOCX / enterprise-gateway formatting

The current build preserves Word heading/list/code paragraph styles during DOCX import, which improves Confluence hierarchy and PowerPoint slide planning. The client defaults to a 4096 completion-token cap, can retry lower when an OpenAI-compatible gateway rejects a larger completion/context budget, and replays the exact same transiently failing request up to 10 total attempts before declaring the LLM unavailable; deterministic fallback then keeps the formatting flow alive and is labelled clearly as fallback. LangGraph runtime failures and LLM-stage failures are both handled without discarding the user's source content. PowerPoint pagination is lossless across bullets, table rows/columns, process steps and subsection cards.

## Confluence canonical rendering

Confluence output now uses one canonical editor-safe HTML tree for preview, rich clipboard copy and export. Large-content chunk boundaries are normalized, real tables/lists/code/callouts are preserved, Markdown tables are recovered when necessary, and the 10-attempt LLM retry/fallback policy applies without interrupting the formatting flow. See `CHANGES-CONFLUENCE-RESILIENCE.md`.

## BNP-green adaptive PowerPoint diagrams

PowerPoint now has a first-class `DIAGRAM` layout in addition to the existing predefined layouts and native editable charts. The LLM selects `data-diagram` based on source meaning, while Java validates the structure, applies conservative local inference when metadata is missing, paginates overflow and renders editable PowerPoint-native shapes in the BNP green/white design.

The Phase 1 + Phase 2 catalog includes linear and chevron processes, cycles, swimlanes, hierarchy, hub-and-spoke, pipeline, architecture flow, funnel, pyramid, 2x2 matrix, decision tree, feedback loop, converging/diverging flows, before/after, comparison flow and roadmap. See `CHANGES-BNP-NATIVE-POWERPOINT-DIAGRAMS.md` and `samples/bnp-presentation-diagram-demo.html`.
