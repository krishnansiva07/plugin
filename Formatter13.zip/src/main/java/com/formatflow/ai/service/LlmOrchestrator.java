package com.formatflow.ai.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.formatflow.ai.model.FormatModels.PlanItem;
import com.formatflow.ai.model.FormatModels.SourceBlock;
import org.bsc.langgraph4j.StateGraph;
import org.bsc.langgraph4j.state.AgentState;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

import static org.bsc.langgraph4j.StateGraph.END;
import static org.bsc.langgraph4j.StateGraph.START;
import static org.bsc.langgraph4j.action.AsyncEdgeAction.edge_async;
import static org.bsc.langgraph4j.action.AsyncNodeAction.node_async;

@Service
public class LlmOrchestrator {

    private final LlmClient llmClient;
    private final PromptFactory promptFactory;
    private final ContentParser contentParser;
    private final ObjectMapper objectMapper;
    private final IconCatalog iconCatalog;
    private final int chunkCharacters;
    private final int chunkBlocks;
    private final int maxGraphRepairs;
    private final int graphReviewThreshold;
    private final int graphPlanSampleCharacters;
    private final int graphReviewSampleCharacters;

    public LlmOrchestrator(LlmClient llmClient,
                           PromptFactory promptFactory,
                           ContentParser contentParser,
                           ObjectMapper objectMapper,
                           IconCatalog iconCatalog,
                           @Value("${formatflow.llm.chunk-characters:9000}") int chunkCharacters,
                           @Value("${formatflow.llm.chunk-blocks:40}") int chunkBlocks,
                           @Value("${formatflow.langgraph.max-repairs:1}") int maxGraphRepairs,
                           @Value("${formatflow.langgraph.review-threshold:80}") int graphReviewThreshold,
                           @Value("${formatflow.langgraph.plan-sample-characters:18000}") int graphPlanSampleCharacters,
                           @Value("${formatflow.langgraph.review-sample-characters:28000}") int graphReviewSampleCharacters) {
        this.llmClient = llmClient;
        this.promptFactory = promptFactory;
        this.contentParser = contentParser;
        this.objectMapper = objectMapper;
        this.iconCatalog = iconCatalog;
        this.chunkCharacters = chunkCharacters;
        this.chunkBlocks = chunkBlocks;
        this.maxGraphRepairs = Math.max(0, maxGraphRepairs);
        this.graphReviewThreshold = Math.max(0, Math.min(100, graphReviewThreshold));
        this.graphPlanSampleCharacters = Math.max(6000, graphPlanSampleCharacters);
        this.graphReviewSampleCharacters = Math.max(10000, graphReviewSampleCharacters);
    }

    public PlanOutcome buildFormattingPlan(String apiKey,
                                             List<SourceBlock> blocks,
                                             String audience,
                                             String purpose,
                                             String outputFormat,
                                             String iconLevel) {
        List<List<SourceBlock>> chunks = contentParser.chunks(blocks, chunkCharacters, chunkBlocks);
        Map<String, PlanItem> planned = new LinkedHashMap<>();
        int calls = 0;

        for (List<SourceBlock> chunk : chunks) {
            String prompt = promptFactory.formattingPlan(chunk, audience, purpose, outputFormat, iconLevel);
            String response = llmClient.chat(apiKey, prompt, 2400, 0.0);
            calls++;
            List<PlanItem> parsed;
            try {
                parsed = parsePlan(response, chunk);
            } catch (RuntimeException invalidStructuredOutput) {
                response = llmClient.chat(
                        apiKey,
                        prompt + "\n\nREPAIR REQUEST: Return ONLY valid strict JSON matching the requested schema. Preserve every source block id exactly once. Do not return or rewrite source text.",
                        2400,
                        0.0
                );
                calls++;
                parsed = parsePlan(response, chunk);
            }
            Map<String, SourceBlock> sourceById = chunk.stream().collect(Collectors.toMap(SourceBlock::id, b -> b));
            for (PlanItem item : parsed) {
                String iconKey = item.iconKey();
                if ("NONE".equalsIgnoreCase(iconLevel)) {
                    iconKey = "NONE";
                } else if ("NONE".equalsIgnoreCase(iconKey)
                        && ("TITLE".equalsIgnoreCase(item.type()) || "HEADING".equalsIgnoreCase(item.type()))) {
                    SourceBlock source = sourceById.get(item.id());
                    iconKey = iconCatalog.inferKey(source == null ? "" : source.text());
                }
                PlanItem effective = new PlanItem(item.id(), item.type(), iconKey, item.emphasis(), item.bulletStyle());
                planned.put(effective.id(), effective);
            }
        }

        List<PlanItem> ordered = new ArrayList<>();
        for (SourceBlock block : blocks) {
            if (block.blank()) continue;
            PlanItem item = planned.get(block.id());
            if (item == null) {
                throw new IllegalStateException("LLM formatting plan omitted source block " + block.id() + ". No content was changed.");
            }
            ordered.add(item);
        }
        return new PlanOutcome(ordered, calls, chunks.size());
    }

    public EnhancementOutcome enhance(String apiKey,
                                      List<SourceBlock> blocks,
                                      String audience,
                                      String purpose,
                                      String outputFormat) {
        List<List<SourceBlock>> chunks = contentParser.chunks(blocks, chunkCharacters, chunkBlocks);
        Map<String, String> enhanced = new LinkedHashMap<>();
        int calls = 0;

        for (List<SourceBlock> chunk : chunks) {
            String response = llmClient.chat(
                    apiKey,
                    promptFactory.enhanceBlocks(chunk, audience, purpose, outputFormat),
                    4096,
                    0.1
            );
            calls++;
            JsonNode root = readJson(response);
            JsonNode items = root.path("items");
            if (!items.isArray()) throw new IllegalStateException("LLM enhancement response did not contain an items array.");

            Set<String> allowed = chunk.stream().map(SourceBlock::id).collect(Collectors.toSet());
            for (JsonNode item : items) {
                String id = item.path("id").asText("");
                String text = item.path("text").asText(null);
                if (!allowed.contains(id) || text == null) continue;
                enhanced.put(id, text);
            }
        }

        List<SourceBlock> result = new ArrayList<>();
        for (SourceBlock source : blocks) {
            if (source.blank()) {
                result.add(source);
            } else {
                String text = enhanced.get(source.id());
                if (text == null) {
                    throw new IllegalStateException("LLM enhancement omitted source block " + source.id() + ".");
                }
                if (source.codeLike() && !text.equals(source.text())) {
                    throw new IllegalStateException("LLM attempted to modify code/configuration block " + source.id() + ". Request stopped to protect technical content.");
                }
                result.add(new SourceBlock(source.id(), text, source.codeLike(), source.bulletLike(), false));
            }
        }
        return new EnhancementOutcome(result, calls, chunks.size());
    }

    public SummaryOutcome summarize(String apiKey,
                                    String content,
                                    String audience,
                                    String purpose,
                                    String summaryLength,
                                    String outputFormat) {
        List<String> chunks = chunkText(content, Math.max(chunkCharacters * 2, 14000));
        List<String> partials = new ArrayList<>();
        int calls = 0;

        for (int i = 0; i < chunks.size(); i++) {
            String partial = llmClient.chat(
                    apiKey,
                    promptFactory.summarizeChunk(chunks.get(i), audience, purpose, summaryLength, i + 1, chunks.size()),
                    1800,
                    0.15
            );
            calls++;
            partials.add(partial.trim());
        }

        if (partials.size() == 1) {
            return new SummaryOutcome(partials.get(0), calls, chunks.size());
        }

        // Hierarchical reduction prevents very large documents from overflowing the final synthesis prompt.
        List<String> reduced = partials;
        while (combinedLength(reduced) > 26000 && reduced.size() > 2) {
            List<List<String>> groups = groupSummaries(reduced, 18000);
            List<String> next = new ArrayList<>();
            for (List<String> group : groups) {
                String intermediate = llmClient.chat(
                        apiKey,
                        promptFactory.synthesizeSummary(group, audience, purpose, "Detailed", outputFormat),
                        2200,
                        0.1
                );
                calls++;
                next.add(intermediate.trim());
            }
            reduced = next;
        }

        String finalSummary = llmClient.chat(
                apiKey,
                promptFactory.synthesizeSummary(reduced, audience, purpose, summaryLength, outputFormat),
                2600,
                0.15
        );
        calls++;
        return new SummaryOutcome(finalSummary.trim(), calls, chunks.size());
    }


    /**
     * Stateful editorial workflow implemented with LangGraph4j:
     * ANALYZE -> CREATE -> REVIEW -> (optional REPAIR -> REVIEW) -> FINALIZE.
     *
     * The graph deliberately keeps the model editorially unrestricted while a
     * reviewer node checks destination fitness, repetition and readability. The
     * repair loop is bounded by configuration so generation can never spin.
     */
    public FreeformOutcome freeform(String apiKey,
                                    String content,
                                    String audience,
                                    String purpose,
                                    String outputFormat,
                                    String operation,
                                    String summaryLength) {
        try {
            var workflow = new StateGraph<EditorialState>(EditorialState::new)
                    .addNode("analyze", node_async(state -> analyzeEditorialState(apiKey, state)))
                    .addNode("create", node_async(state -> createEditorialDraft(apiKey, state, "")))
                    .addNode("review", node_async(state -> reviewEditorialDraft(apiKey, state)))
                    .addNode("repair", node_async(state -> repairEditorialDraft(apiKey, state)))
                    .addNode("finalize", node_async(this::finalizeEditorialDraft))
                    .addEdge(START, "analyze")
                    .addEdge("analyze", "create")
                    .addEdge("create", "review")
                    .addConditionalEdges(
                            "review",
                            edge_async(state -> needsEditorialRepair(state) ? "repair" : "finalize"),
                            Map.of("repair", "repair", "finalize", "finalize")
                    )
                    .addEdge("repair", "review")
                    .addEdge("finalize", END)
                    .compile();

            Map<String, Object> input = new HashMap<>();
            input.put(EditorialState.CONTENT, content == null ? "" : content);
            input.put(EditorialState.AUDIENCE, audience == null ? "" : audience);
            input.put(EditorialState.PURPOSE, purpose == null ? "" : purpose);
            input.put(EditorialState.OUTPUT_FORMAT, outputFormat == null ? "" : outputFormat);
            input.put(EditorialState.OPERATION, operation == null ? "FORMAT" : operation);
            input.put(EditorialState.SUMMARY_LENGTH, summaryLength == null ? "" : summaryLength);
            input.put(EditorialState.LLM_CALLS, 0);
            input.put(EditorialState.REPAIR_COUNT, 0);
            input.put(EditorialState.REVIEW_SCORE, 100);
            input.put(EditorialState.REVIEW_PASSED, false);
            input.put(EditorialState.FALLBACK_NOTES, "");

            EditorialState finalState = workflow.invoke(input)
                    .orElseThrow(() -> new IllegalStateException("LangGraph editorial workflow returned no final state."));

            String html = finalState.finalHtml();
            if (html.isBlank()) {
                throw new IllegalStateException("LangGraph editorial workflow returned empty formatted content.");
            }
            return new FreeformOutcome(
                    html,
                    finalState.llmCalls(),
                    finalState.chunkCount(),
                    finalState.activity()
            );
        } catch (IllegalStateException ex) {
            // LLM/service failures are already converted to a user-readable state
            // error by LlmClient. Preserve that message instead of hiding it behind
            // a generic reference code.
            throw ex;
        } catch (RuntimeException graphRuntime) {
            // LangGraph4j itself can throw runtime exceptions that are unrelated to
            // the user's content/model. If a user-readable IllegalStateException is
            // already in the cause chain, surface it directly. Otherwise execute the
            // same bounded editorial stages sequentially so one graph-runtime issue
            // does not make formatting fail for an otherwise valid document.
            IllegalStateException stateFailure = findIllegalStateCause(graphRuntime);
            if (stateFailure != null) throw stateFailure;
            return freeformSequentialFallback(
                    apiKey, content, audience, purpose, outputFormat, operation, summaryLength, graphRuntime
            );
        } catch (Exception ex) {
            throw new IllegalStateException("LangGraph editorial workflow failed: " + safeExceptionMessage(ex), ex);
        }
    }

    private FreeformOutcome freeformSequentialFallback(String apiKey,
                                                       String content,
                                                       String audience,
                                                       String purpose,
                                                       String outputFormat,
                                                       String operation,
                                                       String summaryLength,
                                                       RuntimeException graphRuntime) {
        try {
            Map<String, Object> data = new HashMap<>();
            data.put(EditorialState.CONTENT, content == null ? "" : content);
            data.put(EditorialState.AUDIENCE, audience == null ? "" : audience);
            data.put(EditorialState.PURPOSE, purpose == null ? "" : purpose);
            data.put(EditorialState.OUTPUT_FORMAT, outputFormat == null ? "" : outputFormat);
            data.put(EditorialState.OPERATION, operation == null ? "FORMAT" : operation);
            data.put(EditorialState.SUMMARY_LENGTH, summaryLength == null ? "" : summaryLength);
            data.put(EditorialState.LLM_CALLS, 0);
            data.put(EditorialState.REPAIR_COUNT, 0);
            data.put(EditorialState.REVIEW_SCORE, 100);
            data.put(EditorialState.REVIEW_PASSED, false);
            data.put(EditorialState.FALLBACK_NOTES, "");

            EditorialState state = new EditorialState(data);
            data.putAll(analyzeEditorialState(apiKey, state));
            state = new EditorialState(data);

            data.putAll(createEditorialDraft(apiKey, state, ""));
            state = new EditorialState(data);

            data.putAll(reviewEditorialDraft(apiKey, state));
            state = new EditorialState(data);

            if (needsEditorialRepair(state)) {
                data.putAll(repairEditorialDraft(apiKey, state));
                state = new EditorialState(data);
                data.putAll(reviewEditorialDraft(apiKey, state));
                state = new EditorialState(data);
            }

            data.putAll(finalizeEditorialDraft(state));
            state = new EditorialState(data);

            String html = state.finalHtml();
            if (html.isBlank()) {
                throw new IllegalStateException("Editorial fallback returned empty formatted content.");
            }
            String activity = state.activity() + " • Safe graph-runtime fallback";
            return new FreeformOutcome(html, state.llmCalls(), state.chunkCount(), activity);
        } catch (IllegalStateException ex) {
            ex.addSuppressed(graphRuntime);
            throw ex;
        } catch (RuntimeException ex) {
            ex.addSuppressed(graphRuntime);
            throw new IllegalStateException("Editorial formatting failed after graph-runtime fallback: "
                    + safeExceptionMessage(ex), ex);
        }
    }

    private IllegalStateException findIllegalStateCause(Throwable error) {
        Throwable cursor = error;
        int depth = 0;
        while (cursor != null && depth++ < 12) {
            if (cursor instanceof IllegalStateException state) return state;
            cursor = cursor.getCause();
        }
        return null;
    }

    private String safeExceptionMessage(Throwable error) {
        if (error == null) return "Unknown error";
        String message = error.getMessage();
        if (message == null || message.isBlank()) message = error.getClass().getSimpleName();
        message = message.replace('\n', ' ').replace('\r', ' ').trim();
        return message.length() > 260 ? message.substring(0, 260) : message;
    }

    private Map<String, Object> analyzeEditorialState(String apiKey, EditorialState state) {
        try {
            String sample = buildRepresentativeSample(state.content(), graphPlanSampleCharacters);
            String structureHints = extractStructureHints(state.content(), 70);
            String response = llmClient.chat(
                    apiKey,
                    promptFactory.editorialPlan(
                            sample,
                            structureHints,
                            state.audience(),
                            state.purpose(),
                            state.outputFormat(),
                            state.operation(),
                            state.summaryLength(),
                            state.content().length()
                    ),
                    2200,
                    0.12
            );
            String plan = response == null ? "" : response.trim();
            if (plan.isBlank()) plan = deterministicEditorialPlan(state);
            return Map.of(
                    EditorialState.EDITORIAL_PLAN, plan,
                    EditorialState.LLM_CALLS, state.llmCalls() + 1
            );
        } catch (RuntimeException llmFailure) {
            Map<String, Object> update = new HashMap<>();
            update.put(EditorialState.EDITORIAL_PLAN, deterministicEditorialPlan(state));
            update.put(EditorialState.LLM_CALLS, state.llmCalls() + 1);
            String note = shouldOpenRequestCircuit(llmFailure)
                    ? llmUnavailableNote(llmFailure, "local plan used")
                    : "Analyze unavailable; local plan used";
            update.put(EditorialState.FALLBACK_NOTES, appendFallback(state.fallbackNotes(), note));
            return update;
        }
    }

    private Map<String, Object> createEditorialDraft(String apiKey, EditorialState state, String repairFeedback) {
        List<String> chunks = chunkText(state.content(), Math.max(chunkCharacters + 5000, 14000));
        List<String> outputs = new ArrayList<>();
        int calls = state.llmCalls();
        String opening = clip(state.content(), 2600);
        String previousTail = "";
        String fallbackNotes = state.fallbackNotes();
        boolean serviceCircuitOpen = hasOpenLlmCircuit(state.fallbackNotes());
        if (serviceCircuitOpen) {
            fallbackNotes = appendFallback(fallbackNotes, "Create used local fallback while LLM unavailable");
        }

        for (int i = 0; i < chunks.size(); i++) {
            String html;
            if (serviceCircuitOpen) {
                html = deterministicHtmlFallback(chunks.get(i), state.outputFormat(), i + 1, chunks.size());
            } else {
                try {
                    String prompt = promptFactory.freeformHtmlWithGraphContext(
                            chunks.get(i),
                            opening,
                            previousTail,
                            state.editorialPlan(),
                            repairFeedback,
                            state.audience(),
                            state.purpose(),
                            state.outputFormat(),
                            state.operation(),
                            state.summaryLength(),
                            i + 1,
                            chunks.size()
                    );
                    String response = llmClient.chat(apiKey, prompt, 5200, repairFeedback.isBlank() ? 0.20 : 0.12);
                    calls++;
                    html = cleanFreeformResponse(response);
                    if (html.isBlank()) throw new IllegalStateException("LLM returned empty content for chunk " + (i + 1) + ".");
                } catch (RuntimeException llmFailure) {
                    calls++;
                    html = deterministicHtmlFallback(chunks.get(i), state.outputFormat(), i + 1, chunks.size());
                    serviceCircuitOpen = shouldOpenRequestCircuit(llmFailure);
                    String createNote = serviceCircuitOpen
                            ? llmUnavailableNote(llmFailure, "Create chunk " + (i + 1) + " used local fallback")
                            : "Create chunk " + (i + 1) + " used local fallback";
                    fallbackNotes = appendFallback(fallbackNotes, createNote);
                    if (serviceCircuitOpen && i + 1 < chunks.size()) {
                        fallbackNotes = appendFallback(fallbackNotes, "Remaining chunks skipped unavailable LLM");
                    }
                }
            }
            if (!html.isBlank()) outputs.add(html);
            previousTail = clip(html, 2000, true);
        }

        if (outputs.isEmpty()) {
            String emergency = deterministicHtmlFallback(state.content(), state.outputFormat(), 1, 1);
            if (emergency.isBlank()) throw new IllegalStateException("Unable to create readable fallback content.");
            outputs.add(emergency);
            fallbackNotes = appendFallback(fallbackNotes, "Emergency local content fallback used");
        }
        String draft = String.join("\n", outputs);
        Map<String, Object> update = new HashMap<>();
        update.put(EditorialState.DRAFT_HTML, draft);
        update.put(EditorialState.LLM_CALLS, calls);
        update.put(EditorialState.CHUNK_COUNT, chunks.size());
        update.put(EditorialState.REVIEW_PASSED, false);
        update.put(EditorialState.FALLBACK_NOTES, fallbackNotes);
        return update;
    }

    private Map<String, Object> reviewEditorialDraft(String apiKey, EditorialState state) {
        List<String> deterministicIssues = deterministicEditorialIssues(
                state.content(), state.draftHtml(), state.outputFormat(), state.operation());
        ReviewDecision decision;
        String fallbackNotes = state.fallbackNotes();
        int calls = state.llmCalls();

        if (hasOpenLlmCircuit(fallbackNotes)) {
            boolean localPass = deterministicIssues.isEmpty();
            String feedback = localPass ? "" : String.join("; ", deterministicIssues);
            Map<String, Object> update = new HashMap<>();
            update.put(EditorialState.REVIEW_PASSED, localPass);
            update.put(EditorialState.REVIEW_SCORE, localPass ? 82 : 65);
            update.put(EditorialState.REVIEW_FEEDBACK, feedback);
            update.put(EditorialState.LLM_CALLS, calls);
            update.put(EditorialState.FALLBACK_NOTES,
                    appendFallback(fallbackNotes, "Review used deterministic checks while LLM unavailable"));
            return update;
        }

        try {
            String sourceSample = buildRepresentativeSample(state.content(), Math.min(graphReviewSampleCharacters, 22000));
            String draftSample = buildRepresentativeSample(state.draftHtml(), graphReviewSampleCharacters);
            String raw = llmClient.chat(
                    apiKey,
                    promptFactory.editorialReview(
                            sourceSample,
                            draftSample,
                            state.editorialPlan(),
                            deterministicIssues,
                            state.audience(),
                            state.purpose(),
                            state.outputFormat(),
                            state.operation()
                    ),
                    900,
                    0.0
            );
            calls++;
            decision = parseReviewDecision(raw, deterministicIssues);
        } catch (RuntimeException llmFailure) {
            calls++;
            boolean localPass = deterministicIssues.isEmpty();
            decision = new ReviewDecision(localPass, localPass ? 82 : 65,
                    localPass ? "" : String.join("; ", deterministicIssues));
            fallbackNotes = appendFallback(fallbackNotes, "Review unavailable; deterministic review used");
        }

        boolean passed = decision.pass() && decision.score() >= graphReviewThreshold && deterministicIssues.isEmpty();
        String feedback = decision.repairInstruction();
        if (!deterministicIssues.isEmpty()) {
            feedback = String.join("; ", deterministicIssues) + (feedback.isBlank() ? "" : "; " + feedback);
        }
        if (!passed && feedback.isBlank()) {
            feedback = "Improve hierarchy and scanability, remove unnecessary repetition, and keep every factual/technical detail grounded in the source.";
        }

        Map<String, Object> update = new HashMap<>();
        update.put(EditorialState.REVIEW_PASSED, passed);
        update.put(EditorialState.REVIEW_SCORE, decision.score());
        update.put(EditorialState.REVIEW_FEEDBACK, feedback);
        update.put(EditorialState.LLM_CALLS, calls);
        update.put(EditorialState.FALLBACK_NOTES, fallbackNotes);
        return update;
    }

    private Map<String, Object> repairEditorialDraft(String apiKey, EditorialState state) {
        Map<String, Object> recreated = createEditorialDraft(apiKey, state, state.reviewFeedback());
        Map<String, Object> update = new HashMap<>(recreated);
        update.put(EditorialState.REPAIR_COUNT, state.repairCount() + 1);
        return update;
    }

    private Map<String, Object> finalizeEditorialDraft(EditorialState state) {
        String html = cleanFreeformResponse(state.draftHtml());
        if (html.isBlank()) html = deterministicHtmlFallback(state.content(), state.outputFormat(), 1, 1);
        String activity = state.repairCount() > 0
                ? "LangGraph Editorial • Analyze → Create → Review → Repair → Review"
                : "LangGraph Editorial • Analyze → Create → Review";
        if (!state.fallbackNotes().isBlank()) {
            activity += " • Resilient fallback: " + state.fallbackNotes();
        }
        return Map.of(
                EditorialState.FINAL_HTML, html,
                EditorialState.ACTIVITY, activity
        );
    }

    private boolean needsEditorialRepair(EditorialState state) {
        // Once CREATE or REVIEW had to degrade locally, preserve the usable draft
        // instead of making another model call that can delay or break the flow.
        String notes = state.fallbackNotes();
        if (hasOpenLlmCircuit(notes) || notes.contains("Create chunk") || notes.contains("Review unavailable")
                || notes.contains("Remaining chunks skipped unavailable LLM")) return false;
        return !state.reviewPassed() && state.repairCount() < maxGraphRepairs;
    }

    private String deterministicEditorialPlan(EditorialState state) {
        return "Preserve all unique source facts and technical values; organize content into a clear hierarchy for "
                + state.outputFormat() + "; keep original sequence when no safer semantic grouping is obvious; "
                + "use headings for short topic-like lines, bullets for list items, code blocks for code/configuration, "
                + "and continuation sections instead of truncating content. Never invent facts.";
    }

    private String deterministicHtmlFallback(String source, String outputFormat, int part, int totalParts) {
        List<SourceBlock> blocks = contentParser.parse(source == null ? "" : source);
        StringBuilder html = new StringBuilder();
        String destination = outputFormat == null ? "" : outputFormat.toUpperCase(Locale.ROOT);
        String promotedTitle = "";
        if ("POWERPOINT".equals(destination)) {
            if (part == 1) {
                promotedTitle = blocks.stream()
                        .filter(b -> !b.blank() && !b.bulletLike() && !b.codeLike())
                        .map(SourceBlock::text)
                        .map(String::trim)
                        .filter(v -> !v.isBlank() && v.length() <= 120)
                        .findFirst()
                        .orElse("Formatted Presentation");
                html.append("<h1>").append(escapeHtml(promotedTitle.replaceFirst(":$", ""))).append("</h1>");
            }
            html.append("<h2>📌 ").append(totalParts > 1 ? "Source Content — Part " + part : "Overview").append("</h2>");
        }

        boolean listOpen = false;
        boolean promotedTitleConsumed = false;
        for (SourceBlock block : blocks) {
            if (block.blank()) {
                if (listOpen) { html.append("</ul>"); listOpen = false; }
                continue;
            }
            String text = block.text() == null ? "" : block.text().trim();
            if (text.isBlank()) continue;
            if ("POWERPOINT".equals(destination) && part == 1 && !promotedTitleConsumed && text.equals(promotedTitle)) {
                promotedTitleConsumed = true;
                continue;
            }

            if (block.bulletLike()) {
                if (!listOpen) { html.append("<ul>"); listOpen = true; }
                html.append("<li>").append(escapeHtml(stripFallbackBullet(text))).append("</li>");
                continue;
            }
            if (listOpen) { html.append("</ul>"); listOpen = false; }

            if (block.codeLike()) {
                html.append("<pre><code>").append(escapeHtml(text)).append("</code></pre>");
            } else if (looksLikeFallbackHeading(text)) {
                html.append("<h3>").append(escapeHtml(text.replaceFirst(":$", ""))).append("</h3>");
            } else {
                html.append("<p>").append(escapeHtml(text)).append("</p>");
            }
        }
        if (listOpen) html.append("</ul>");
        return html.toString();
    }

    private boolean looksLikeFallbackHeading(String text) {
        if (text == null) return false;
        String value = text.trim();
        if (value.length() < 3 || value.length() > 90) return false;
        if (value.endsWith(":")) return true;
        if (value.matches("^[A-Z][A-Za-z0-9 /&()_-]{2,70}$") && value.split("\\s+").length <= 9) return true;
        return value.matches("^[A-Z0-9][A-Z0-9 /&()_-]{2,70}$");
    }

    private String stripFallbackBullet(String text) {
        return text.replaceFirst("^\\s*(?:[-*•▪◦]|\\d+[.)])\\s+", "").trim();
    }

    private String escapeHtml(String value) {
        if (value == null) return "";
        return value.replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;")
                .replace("\"", "&quot;")
                .replace("'", "&#39;");
    }

    private boolean shouldOpenRequestCircuit(Throwable error) {
        String text = safeExceptionMessage(error).toLowerCase(Locale.ROOT);
        return text.contains("llm unavailable after") || text.contains("timed out") || text.contains("timeout") || text.contains("rate-limit")
                || text.contains("429") || text.contains("500") || text.contains("502") || text.contains("503")
                || text.contains("504") || text.contains("authentication") || text.contains("401")
                || text.contains("403") || text.contains("connection") || text.contains("connect");
    }

    private String llmUnavailableNote(Throwable error, String action) {
        String message = safeExceptionMessage(error);
        String prefix = "LLM unavailable after ";
        int start = message.indexOf(prefix);
        if (start >= 0) {
            int end = message.indexOf('.', start);
            String summary = end > start ? message.substring(start, end).trim() : message.substring(start).trim();
            return summary + "; " + action;
        }

        String lower = message.toLowerCase(Locale.ROOT);
        if (lower.contains("401") || lower.contains("403") || lower.contains("authentication")) {
            return "LLM authentication/configuration issue; " + action;
        }
        return "LLM service issue after configured retries; " + action;
    }

    private boolean hasOpenLlmCircuit(String notes) {
        String value = notes == null ? "" : notes;
        return value.contains("LLM unavailable")
                || value.contains("LLM authentication/configuration issue")
                || value.contains("LLM service issue after configured retries");
    }

    private String appendFallback(String existing, String note) {
        String base = existing == null ? "" : existing.trim();
        String next = note == null ? "" : note.trim();
        if (next.isBlank() || base.contains(next)) return base;
        return base.isBlank() ? next : base + "; " + next;
    }

    private ReviewDecision parseReviewDecision(String raw, List<String> deterministicIssues) {
        try {
            JsonNode root = readJson(raw);
            boolean pass = root.path("pass").asBoolean(true);
            int score = Math.max(0, Math.min(100, root.path("score").asInt(pass ? 90 : 70)));
            List<String> issues = new ArrayList<>();
            JsonNode issueNode = root.path("issues");
            if (issueNode.isArray()) {
                for (JsonNode item : issueNode) {
                    String text = item.asText("").trim();
                    if (!text.isBlank()) issues.add(text);
                }
            }
            String instruction = root.path("repairInstruction").asText("").trim();
            if (instruction.isBlank() && !issues.isEmpty()) instruction = String.join("; ", issues);
            return new ReviewDecision(pass, score, instruction);
        } catch (RuntimeException invalidReviewJson) {
            // A malformed reviewer response should not destroy a good create pass.
            // Deterministic issues still force repair; otherwise keep the draft.
            boolean pass = deterministicIssues.isEmpty();
            return new ReviewDecision(pass, pass ? 82 : 65,
                    deterministicIssues.isEmpty() ? "" : String.join("; ", deterministicIssues));
        }
    }

    private List<String> deterministicEditorialIssues(String sourceContent,
                                                       String html,
                                                       String outputFormat,
                                                       String operation) {
        List<String> issues = new ArrayList<>();
        Document doc = Jsoup.parseBodyFragment(html == null ? "" : html);
        if (doc.body().text().isBlank()) {
            issues.add("Generated output is empty or unreadable");
            return issues;
        }
        if (!doc.select("script,style,iframe,form,img").isEmpty()) {
            issues.add("Remove unsupported or unsafe HTML elements");
        }

        Map<String, Integer> headings = new LinkedHashMap<>();
        for (Element heading : doc.select("h1,h2,h3,h4")) {
            String normalized = normalizeComparableText(heading.text());
            if (normalized.length() >= 4) headings.merge(normalized, 1, Integer::sum);
        }
        headings.entrySet().stream()
                .filter(e -> e.getValue() > 1)
                .limit(4)
                .forEach(e -> issues.add("Avoid duplicate heading: " + e.getKey()));

        Map<String, Integer> longBlocks = new LinkedHashMap<>();
        for (Element block : doc.select("p,li")) {
            String normalized = normalizeComparableText(block.text());
            if (normalized.length() >= 90) longBlocks.merge(normalized, 1, Integer::sum);
        }
        if (longBlocks.values().stream().anyMatch(count -> count > 1)) {
            issues.add("Remove exact repeated body points created across chunks");
        }

        if ("EMAIL".equalsIgnoreCase(outputFormat) && !doc.select("h1").isEmpty()) {
            issues.add("Use a lighter email hierarchy instead of an H1 document title");
        }

        if ("FORMAT".equalsIgnoreCase(operation)) {
            int sourceWords = countWords(sourceContent);
            int topicHeadings = doc.select("h2,h3,h4").size();
            int expectedMinimum = minimumTopicHeadings(sourceWords);
            if (expectedMinimum > 0 && topicHeadings < expectedMinimum) {
                issues.add("Expand topic coverage: rich source content has only " + topicHeadings
                        + " topic heading(s); use at least about " + expectedMinimum
                        + " meaningful H2/H3 sections when supported by the source");
            }

            if (("CONFLUENCE".equalsIgnoreCase(outputFormat) || "HTML".equalsIgnoreCase(outputFormat) || "POWERPOINT".equalsIgnoreCase(outputFormat))
                    && sourceWords >= 350 && topicHeadings >= 2) {
                long iconHeadings = doc.select("h2,h3").stream()
                        .filter(h -> startsWithTopicIcon(h.text()))
                        .count();
                long majorHeadings = doc.select("h2,h3").size();
                if (majorHeadings > 0 && iconHeadings * 100 / majorHeadings < 60) {
                    issues.add("Add varied relevant icons to major topic headings/slide titles; most H2/H3 headings are currently icon-less");
                }
            }
        }
        if ("CONFLUENCE".equalsIgnoreCase(outputFormat)) {
            int h1Count = doc.select("h1").size();
            if (h1Count > 1) {
                issues.add("Use at most one H1 page title in Confluence; continuation chunks must use H2/H3 headings");
            }

            int previousHeadingLevel = 0;
            for (Element heading : doc.select("h1,h2,h3,h4")) {
                int level = Integer.parseInt(heading.tagName().substring(1));
                if (previousHeadingLevel > 0 && level > previousHeadingLevel + 1) {
                    issues.add("Fix Confluence heading hierarchy; do not jump from H" + previousHeadingLevel + " to H" + level);
                    break;
                }
                previousHeadingLevel = level;
            }

            boolean tableWithoutHeader = doc.select("table").stream()
                    .anyMatch(table -> !table.select("tr").isEmpty() && table.select("th").isEmpty());
            if (tableWithoutHeader) {
                issues.add("Use real Confluence tables with header cells (th) instead of header-less tabular markup");
            }

            long pipeParagraphs = doc.select("p").stream()
                    .filter(p -> p.text().chars().filter(ch -> ch == '|').count() >= 2)
                    .count();
            if (pipeParagraphs >= 2 && doc.select("table").isEmpty()) {
                issues.add("Convert pipe-delimited records into a real HTML table for Confluence");
            }

            if ("FORMAT".equalsIgnoreCase(operation)) {
                List<String> critical = criticalSourceTokens(sourceContent);
                String outputComparable = (html == null ? "" : html).toLowerCase(Locale.ROOT);
                List<String> missing = critical.stream()
                        .filter(token -> !outputComparable.contains(token.toLowerCase(Locale.ROOT)))
                        .limit(8)
                        .toList();
                int allowedMissing = Math.max(1, critical.size() / 12);
                if (missing.size() > allowedMissing) {
                    issues.add("Preserve source identifiers/values in Confluence FORMAT output; missing examples: "
                            + String.join(", ", missing));
                }
            }
        }

        if ("POWERPOINT".equalsIgnoreCase(outputFormat) && "FORMAT".equalsIgnoreCase(operation)) {
            int sourceWords = countWords(sourceContent);
            int slideHeadings = doc.select("h2").size();
            int expectedSlides = minimumSlideHeadings(sourceWords);
            if (doc.select("h1").isEmpty()) {
                issues.add("Add one clear h1 deck title before the slide h2 sections");
            }
            if (expectedSlides > 0 && slideHeadings < expectedSlides) {
                issues.add("Create more slide topics: source content supports about " + expectedSlides
                        + " slides but draft has only " + slideHeadings + " H2 slide title(s)");
            }
            boolean hasLongSlideText = doc.select("p,li").stream()
                    .anyMatch(e -> countWords(e.text()) > 28);
            if (hasLongSlideText) {
                issues.add("Shorten slide body text: use presentation bullets instead of long paragraphs");
            }
            if (sourceWords >= 750 && slideHeadings >= 5) {
                boolean hasAgenda = doc.select("h2").stream()
                        .anyMatch(h -> normalizeComparableText(h.text()).contains("agenda") || normalizeComparableText(h.text()).contains("contents"));
                if (!hasAgenda) issues.add("Add an agenda slide after the title for this multi-topic presentation");
            }
            boolean hasPresentationStructure = !doc.select("blockquote,h3,ol,table,pre").isEmpty();
            if (sourceWords >= 900 && !hasPresentationStructure) {
                issues.add("Use richer predefined slide structures where suitable: cards, process, code, table, comparison or timeline rather than generic bullets everywhere");
            }

            Set<String> allowedLayouts = Set.of(
                    "EXECUTIVE_OVERVIEW", "KEY_MESSAGE", "BULLETS", "TWO_COLUMN", "THREE_CARDS", "FOUR_CARDS",
                    "PROCESS_5", "CHECKLIST", "TABLE", "CHART", "DIAGRAM", "CODE", "COMPARISON", "TIMELINE", "NEXT_STEPS");
            Set<String> allowedChartTypes = Set.of(
                    "COLUMN", "BAR", "LINE", "AREA", "PIE", "DOUGHNUT", "SCATTER", "RADAR");
            Set<String> allowedDiagramTypes = Set.of(
                    "LINEAR_PROCESS", "CHEVRON_PROCESS", "CYCLE", "SWIMLANE", "HIERARCHY", "HUB_SPOKE",
                    "PIPELINE", "ARCHITECTURE_FLOW", "FUNNEL", "PYRAMID", "MATRIX_2X2", "DECISION_TREE",
                    "FEEDBACK_LOOP", "CONVERGING_FLOW", "DIVERGING_FLOW", "BEFORE_AFTER", "COMPARISON_FLOW", "ROADMAP");
            for (Element h2 : doc.select("h2")) {
                String layout = h2.attr("data-layout").trim().toUpperCase(Locale.ROOT).replace('-', '_');
                if (layout.isBlank() || !allowedLayouts.contains(layout)) {
                    issues.add("Assign a valid predefined BNP-green data-layout to slide: " + h2.text());
                    break;
                }

                List<Element> body = new ArrayList<>();
                Element bodyCursor = h2.nextElementSibling();
                while (bodyCursor != null && !"h2".equalsIgnoreCase(bodyCursor.tagName())) {
                    body.add(bodyCursor);
                    bodyCursor = bodyCursor.nextElementSibling();
                }
                long h3Count = body.stream().filter(e -> "h3".equalsIgnoreCase(e.tagName())).count();
                int liCount = body.stream().mapToInt(e -> e.select("li").size()).sum();
                boolean hasPre = body.stream().anyMatch(e -> "pre".equalsIgnoreCase(e.tagName()) || !e.select("pre").isEmpty());
                boolean hasTable = body.stream().anyMatch(e -> "table".equalsIgnoreCase(e.tagName()) || !e.select("table").isEmpty());
                boolean hasChartNumbers = hasNumericChartData(body);
                String chartType = h2.attr("data-chart").trim().toUpperCase(Locale.ROOT).replace('-', '_');
                boolean chartMetadataInvalid = "CHART".equals(layout)
                        && (chartType.isBlank() || !allowedChartTypes.contains(chartType));
                String diagramType = h2.attr("data-diagram").trim().toUpperCase(Locale.ROOT).replace('-', '_');
                boolean diagramMetadataInvalid = "DIAGRAM".equals(layout)
                        && (diagramType.isBlank() || !allowedDiagramTypes.contains(diagramType));
                boolean structureMismatch = switch (layout) {
                    case "TWO_COLUMN", "COMPARISON" -> h3Count != 2;
                    case "THREE_CARDS" -> h3Count != 3;
                    case "FOUR_CARDS" -> h3Count != 4;
                    case "PROCESS_5" -> liCount < 3 || liCount > 5;
                    case "CODE" -> !hasPre;
                    case "TABLE" -> !hasTable;
                    case "CHART" -> !hasTable || !hasChartNumbers || chartMetadataInvalid;
                    case "DIAGRAM" -> diagramMetadataInvalid || switch (diagramType) {
                        case "SWIMLANE" -> h3Count < 2 || h3Count > 4;
                        case "MATRIX_2X2" -> h3Count != 4;
                        case "BEFORE_AFTER", "COMPARISON_FLOW" -> h3Count != 2;
                        case "HIERARCHY", "DECISION_TREE" -> h3Count < 2 || h3Count > 4;
                        default -> liCount < 3 || liCount > 6;
                    };
                    default -> false;
                };
                if (structureMismatch) {
                    String metadataGuidance = "CHART".equals(layout)
                            ? " layout with valid data-chart and a real numeric table"
                            : "DIAGRAM".equals(layout)
                            ? " layout with valid data-diagram and matching list/group structure"
                            : " layout";
                    issues.add("Reshape slide content to match its selected " + layout
                            + metadataGuidance + ": " + h2.text());
                    break;
                }
            }
            for (Element h2 : doc.select("h2")) {
                int bulletCount = 0;
                int wordsInSlide = 0;
                Element cursor = h2.nextElementSibling();
                while (cursor != null && !"h2".equalsIgnoreCase(cursor.tagName())) {
                    bulletCount += cursor.select("li").size();
                    if (!cursor.tagName().matches("h3|h4")) wordsInSlide += countWords(cursor.text());
                    cursor = cursor.nextElementSibling();
                }
                if (bulletCount > 7 || wordsInSlide > 115) {
                    issues.add("Split or condense overloaded slide: " + h2.text());
                    break;
                }
            }
        }
        return issues;
    }

    private List<String> criticalSourceTokens(String sourceContent) {
        LinkedHashSet<String> values = new LinkedHashSet<>();
        String source = sourceContent == null ? "" : sourceContent;
        for (String raw : source.split("\\s+")) {
            String token = raw.replaceAll("^[^\\p{L}\\p{N}]+|[^\\p{L}\\p{N}._:/@#%+\\-]+$", "");
            if (token.length() < 2 || token.length() > 90) continue;
            boolean hasDigit = token.chars().anyMatch(Character::isDigit);
            boolean acronym = token.length() <= 16 && token.matches("[A-Z][A-Z0-9_-]{1,15}");
            boolean technical = token.contains("://") || token.contains("_") || token.contains("/")
                    || token.contains("@");
            boolean versionLike = token.matches("(?i).*[a-z]\\d.*|.*\\d[a-z].*") || token.matches("\\d+(?:\\.\\d+){1,4}");
            if (hasDigit || acronym || technical || versionLike) values.add(token);
            if (values.size() >= 120) break;
        }
        return new ArrayList<>(values);
    }

    private int minimumSlideHeadings(int sourceWords) {
        if (sourceWords < 250) return 0;
        if (sourceWords < 700) return 4;
        if (sourceWords < 1400) return 6;
        if (sourceWords < 2600) return 8;
        if (sourceWords < 4500) return 10;
        if (sourceWords < 7500) return 13;
        return 15;
    }

    private int countWords(String text) {
        String value = text == null ? "" : text.trim();
        return value.isBlank() ? 0 : value.split("\\s+").length;
    }

    private int minimumTopicHeadings(int sourceWords) {
        if (sourceWords < 500) return 0;
        if (sourceWords < 1200) return 2;
        if (sourceWords < 2500) return 4;
        if (sourceWords < 5000) return 6;
        if (sourceWords < 10000) return 8;
        return 10;
    }

    private boolean startsWithTopicIcon(String text) {
        if (text == null || text.isBlank()) return false;
        String trimmed = text.stripLeading();
        int cp = trimmed.codePointAt(0);
        int type = Character.getType(cp);
        return type == Character.OTHER_SYMBOL
                || type == Character.MODIFIER_SYMBOL
                || (cp >= 0x2600 && cp <= 0x27BF)
                || (cp >= 0x1F300 && cp <= 0x1FAFF);
    }

    private String normalizeComparableText(String text) {
        return text == null ? "" : text.toLowerCase(Locale.ROOT)
                .replaceAll("[^\\p{L}\\p{N}]+", " ")
                .trim()
                .replaceAll("\\s+", " ");
    }

    private String buildRepresentativeSample(String value, int maxChars) {
        String text = value == null ? "" : value;
        if (text.length() <= maxChars) return text;
        int first = Math.max(1, maxChars * 40 / 100);
        int middle = Math.max(1, maxChars * 25 / 100);
        int last = Math.max(1, maxChars - first - middle);
        int middleStart = Math.max(first, (text.length() - middle) / 2);
        int middleEnd = Math.min(text.length(), middleStart + middle);
        return text.substring(0, Math.min(first, text.length()))
                + "\n\n[... middle sample ...]\n\n"
                + text.substring(middleStart, middleEnd)
                + "\n\n[... final sample ...]\n\n"
                + text.substring(Math.max(0, text.length() - last));
    }

    private String extractStructureHints(String content, int maxLines) {
        if (content == null || content.isBlank()) return "No explicit structure detected.";
        List<String> hints = new ArrayList<>();
        for (String raw : content.split("\\R")) {
            String line = raw.trim();
            if (line.isBlank() || line.length() > 180) continue;
            boolean headingLike = line.matches("^(#{1,4}\\s+.+|[A-Z][A-Z0-9 /&:_-]{3,}|\\d+(?:\\.\\d+)*[.)]?\\s+.+)$");
            boolean instructionLike = line.toLowerCase(Locale.ROOT).matches(".*\\b(format|rewrite|make|avoid|use|organize|organise|summarize|summarise)\\b.*");
            if (headingLike || instructionLike) {
                hints.add(line);
                if (hints.size() >= maxLines) break;
            }
        }
        return hints.isEmpty() ? "No explicit headings/instructions detected in line structure." : String.join("\n", hints);
    }

    private String cleanFreeformResponse(String raw) {
        if (raw == null) return "";
        String value = raw.trim();
        if (value.startsWith("```")) {
            value = value.replaceFirst("^```(?:html|xml)?\\s*", "")
                    .replaceFirst("\\s*```$", "")
                    .trim();
        }
        return value;
    }

    private String clip(String value, int max) {
        return clip(value, max, false);
    }

    private String clip(String value, int max, boolean tail) {
        if (value == null || value.length() <= max) return value == null ? "" : value;
        return tail ? value.substring(value.length() - max) : value.substring(0, max);
    }

    public String generateEmailSubject(String apiKey, String content, String audience, String purpose) {
        String response = llmClient.chat(apiKey, promptFactory.emailSubject(content, audience, purpose), 64, 0.1);
        String subject = response.replace("\r", " ").replace("\n", " ").trim();
        if (subject.startsWith("\"") && subject.endsWith("\"") && subject.length() > 1) {
            subject = subject.substring(1, subject.length() - 1);
        }
        if (subject.length() > 160) subject = subject.substring(0, 160).trim();
        return subject;
    }

    private boolean hasNumericChartData(List<Element> body) {
        for (Element element : body) {
            List<Element> tables = new ArrayList<>();
            if ("table".equalsIgnoreCase(element.tagName())) tables.add(element);
            else tables.addAll(element.select("table"));
            for (Element table : tables) {
                for (Element row : table.select("tr")) {
                    Elements cells = row.select("td,th");
                    for (int i = 1; i < cells.size(); i++) {
                        String raw = cells.get(i).text();
                        if (raw == null || raw.isBlank()) continue;
                        String cleaned = raw.trim().replace(",", "")
                                .replace("₹", "").replace("$", "").replace("€", "")
                                .replace("£", "").replace("¥", "").replace("%", "");
                        if (cleaned.startsWith("(") && cleaned.endsWith(")") && cleaned.length() > 2) {
                            cleaned = "-" + cleaned.substring(1, cleaned.length() - 1);
                        }
                        if (cleaned.startsWith("+")) cleaned = cleaned.substring(1);
                        try {
                            Double.parseDouble(cleaned.trim());
                            return true;
                        } catch (NumberFormatException ignored) {
                            // keep looking for a real numeric series cell
                        }
                    }
                }
            }
        }
        return false;
    }

    private int combinedLength(List<String> values) {
        return values.stream().mapToInt(String::length).sum();
    }

    private List<List<String>> groupSummaries(List<String> summaries, int maxChars) {
        List<List<String>> groups = new ArrayList<>();
        List<String> current = new ArrayList<>();
        int chars = 0;
        for (String summary : summaries) {
            if (!current.isEmpty() && chars + summary.length() > maxChars) {
                groups.add(List.copyOf(current));
                current.clear();
                chars = 0;
            }
            current.add(summary);
            chars += summary.length();
        }
        if (!current.isEmpty()) groups.add(List.copyOf(current));
        return groups;
    }

    private List<PlanItem> parsePlan(String response, List<SourceBlock> chunk) {
        JsonNode root = readJson(response);
        JsonNode items = root.path("items");
        if (!items.isArray()) throw new IllegalStateException("LLM formatting response did not contain an items array.");

        Set<String> allowedIds = chunk.stream().map(SourceBlock::id).collect(Collectors.toSet());
        Set<String> seen = new HashSet<>();
        List<PlanItem> result = new ArrayList<>();

        for (JsonNode item : items) {
            String id = item.path("id").asText("");
            if (!allowedIds.contains(id) || !seen.add(id)) continue;
            String type = validType(item.path("type").asText("PARAGRAPH"));
            String icon = iconCatalog.normalize(item.path("iconKey").asText("NONE"));
            String emphasis = valid(item.path("emphasis").asText("NONE"), Set.of("NONE", "STRONG", "MUTED", "HIGHLIGHT"), "NONE");
            String bullet = valid(item.path("bulletStyle").asText("NONE"), Set.of("NONE", "CHECK", "ARROW", "DOT"), "NONE");
            result.add(new PlanItem(id, type, icon, emphasis, bullet));
        }
        return result;
    }

    private JsonNode readJson(String raw) {
        try {
            String cleaned = raw == null ? "" : raw.trim();
            if (cleaned.startsWith("```")) {
                cleaned = cleaned.replaceFirst("^```(?:json)?\\s*", "").replaceFirst("\\s*```$", "");
            }
            int first = cleaned.indexOf('{');
            int last = cleaned.lastIndexOf('}');
            if (first >= 0 && last > first) cleaned = cleaned.substring(first, last + 1);
            return objectMapper.readTree(cleaned);
        } catch (Exception ex) {
            throw new IllegalStateException("LLM returned invalid structured JSON. Try again or inspect the configured model compatibility.", ex);
        }
    }

    private String validType(String type) {
        return valid(type, Set.of("TITLE", "HEADING", "PARAGRAPH", "BULLET", "CODE", "CALLOUT", "QUOTE"), "PARAGRAPH");
    }

    private String valid(String value, Set<String> allowed, String fallback) {
        String normalized = value == null ? fallback : value.trim().toUpperCase(Locale.ROOT);
        return allowed.contains(normalized) ? normalized : fallback;
    }

    private List<String> chunkText(String content, int maxChars) {
        List<String> result = new ArrayList<>();
        String safeContent = content == null ? "" : content;
        String[] paragraphs = safeContent.split("(?m)(?<=\n)\\s*\n");
        StringBuilder current = new StringBuilder();

        for (String paragraph : paragraphs) {
            if (paragraph.length() > maxChars) {
                if (!current.isEmpty()) {
                    result.add(current.toString());
                    current.setLength(0);
                }
                int offset = 0;
                while (offset < paragraph.length()) {
                    int target = Math.min(paragraph.length(), offset + maxChars);
                    int cut = target;
                    if (target < paragraph.length()) {
                        int newline = paragraph.lastIndexOf('\n', target);
                        int space = paragraph.lastIndexOf(' ', target);
                        int candidate = Math.max(newline, space);
                        if (candidate > offset + maxChars / 2) cut = candidate;
                    }
                    result.add(paragraph.substring(offset, cut).trim());
                    offset = Math.max(cut, offset + 1);
                    while (offset < paragraph.length() && Character.isWhitespace(paragraph.charAt(offset))) offset++;
                }
                continue;
            }

            if (!current.isEmpty() && current.length() + paragraph.length() + 2 > maxChars) {
                result.add(current.toString());
                current.setLength(0);
            }
            if (!current.isEmpty()) current.append("\n\n");
            current.append(paragraph);
        }
        if (!current.isEmpty()) result.add(current.toString());
        result.removeIf(String::isBlank);
        if (result.isEmpty()) result.add(safeContent);
        return result;
    }

    public record PlanOutcome(List<PlanItem> items, int llmCalls, int chunks) {}
    public record EnhancementOutcome(List<SourceBlock> blocks, int llmCalls, int chunks) {}
    public record SummaryOutcome(String content, int llmCalls, int chunks) {}
    public record FreeformOutcome(String html, int llmCalls, int chunks, String workflowActivity) {
        public FreeformOutcome(String html, int llmCalls, int chunks) {
            this(html, llmCalls, chunks, "LangGraph Editorial • Analyze → Create → Review");
        }
    }

    private record ReviewDecision(boolean pass, int score, String repairInstruction) {}

    private static final class EditorialState extends AgentState {
        static final String CONTENT = "content";
        static final String AUDIENCE = "audience";
        static final String PURPOSE = "purpose";
        static final String OUTPUT_FORMAT = "outputFormat";
        static final String OPERATION = "operation";
        static final String SUMMARY_LENGTH = "summaryLength";
        static final String EDITORIAL_PLAN = "editorialPlan";
        static final String DRAFT_HTML = "draftHtml";
        static final String FINAL_HTML = "finalHtml";
        static final String REVIEW_PASSED = "reviewPassed";
        static final String REVIEW_SCORE = "reviewScore";
        static final String REVIEW_FEEDBACK = "reviewFeedback";
        static final String REPAIR_COUNT = "repairCount";
        static final String LLM_CALLS = "llmCalls";
        static final String CHUNK_COUNT = "chunkCount";
        static final String ACTIVITY = "activity";
        static final String FALLBACK_NOTES = "fallbackNotes";

        EditorialState(Map<String, Object> initData) { super(initData); }
        String content() { return this.<String>value(CONTENT).orElse(""); }
        String audience() { return this.<String>value(AUDIENCE).orElse(""); }
        String purpose() { return this.<String>value(PURPOSE).orElse(""); }
        String outputFormat() { return this.<String>value(OUTPUT_FORMAT).orElse("CONFLUENCE"); }
        String operation() { return this.<String>value(OPERATION).orElse("FORMAT"); }
        String summaryLength() { return this.<String>value(SUMMARY_LENGTH).orElse(""); }
        String editorialPlan() { return this.<String>value(EDITORIAL_PLAN).orElse(""); }
        String draftHtml() { return this.<String>value(DRAFT_HTML).orElse(""); }
        String finalHtml() { return this.<String>value(FINAL_HTML).orElse(draftHtml()); }
        boolean reviewPassed() { return this.<Boolean>value(REVIEW_PASSED).orElse(false); }
        int repairCount() { return this.<Integer>value(REPAIR_COUNT).orElse(0); }
        int llmCalls() { return this.<Integer>value(LLM_CALLS).orElse(0); }
        int chunkCount() { return this.<Integer>value(CHUNK_COUNT).orElse(1); }
        String reviewFeedback() { return this.<String>value(REVIEW_FEEDBACK).orElse(""); }
        String activity() { return this.<String>value(ACTIVITY).orElse("LangGraph Editorial"); }
        String fallbackNotes() { return this.<String>value(FALLBACK_NOTES).orElse(""); }
    }
}
