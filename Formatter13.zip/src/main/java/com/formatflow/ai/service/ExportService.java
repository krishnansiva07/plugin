package com.formatflow.ai.service;

import com.formatflow.ai.model.FormatModels.*;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.font.PDFont;
import org.apache.poi.sl.usermodel.ShapeType;
import org.apache.poi.sl.usermodel.TextShape;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xddf.usermodel.XDDFColor;
import org.apache.poi.xddf.usermodel.XDDFLineProperties;
import org.apache.poi.xddf.usermodel.XDDFSolidFillProperties;
import org.apache.poi.xddf.usermodel.chart.*;
import org.apache.poi.xslf.usermodel.*;
import org.apache.poi.xwpf.usermodel.*;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTShd;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.STShd;
import org.springframework.stereotype.Service;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.geom.Rectangle2D;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.List;
import java.util.function.Function;
import java.util.stream.Collectors;

@Service
public class ExportService {

    private static final String GREEN = "008542";
    private static final String GREEN_DARK = "006B36";
    private static final String GREEN_SOFT = "EEF8F2";

    // BNP-green presentation design system. The deck uses the familiar green/white
    // visual language without embedding any proprietary logo or external asset.
    private static final Color BNP_GREEN = new Color(0, 133, 66);
    private static final Color BNP_GREEN_DARK = new Color(0, 85, 45);
    private static final Color BNP_GREEN_TITLE = new Color(0, 107, 54);
    private static final Color BNP_MINT = new Color(238, 248, 242);
    private static final Color BNP_SURFACE = new Color(247, 251, 248);
    private static final Color BNP_BORDER = new Color(185, 223, 202);
    private static final Color BNP_TEXT = new Color(31, 45, 37);
    private static final Color BNP_MUTED = new Color(81, 103, 91);

    private final DocumentRenderer renderer;
    private final IconCatalog iconCatalog;
    private final PdfFontResolver pdfFontResolver;

    public ExportService(DocumentRenderer renderer, IconCatalog iconCatalog, PdfFontResolver pdfFontResolver) {
        this.renderer = renderer;
        this.iconCatalog = iconCatalog;
        this.pdfFontResolver = pdfFontResolver;
    }

    public ExportedFile export(ExportRequest request) {
        String format = request.format().toUpperCase(Locale.ROOT);
        String baseName = sanitizeFilename(request.filename() == null || request.filename().isBlank()
                ? "formatflow-output" : request.filename());
        FormattedDocument document = request.document();

        try {
            return switch (format) {
                case "WORD" -> new ExportedFile(baseName + ".docx",
                        "application/vnd.openxmlformats-officedocument.wordprocessingml.document", word(document));
                case "POWERPOINT" -> new ExportedFile(baseName + ".pptx",
                        "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                        powerpoint(request.htmlContent(), document));
                case "PDF" -> new ExportedFile(baseName + ".pdf", "application/pdf", pdf(document));
                case "CONFLUENCE" -> new ExportedFile(baseName + "-confluence.html", "text/html; charset=UTF-8",
                        confluenceExportHtml(request.htmlContent(), document).getBytes(StandardCharsets.UTF_8));
                case "EMAIL" -> new ExportedFile(baseName + "-email.html", "text/html; charset=UTF-8",
                        renderer.standaloneHtml(document, true).getBytes(StandardCharsets.UTF_8));
                case "MARKDOWN" -> new ExportedFile(baseName + ".md", "text/markdown; charset=UTF-8",
                        renderer.markdown(document).getBytes(StandardCharsets.UTF_8));
                case "HTML" -> new ExportedFile(baseName + ".html", "text/html; charset=UTF-8",
                        renderer.standaloneHtml(document, false).getBytes(StandardCharsets.UTF_8));
                default -> throw new IllegalArgumentException("Unsupported export format: " + request.format());
            };
        } catch (Exception ex) {
            throw new IllegalStateException("Export failed for " + format + ": " + ex.getMessage(), ex);
        }
    }

    private String confluenceExportHtml(String htmlContent, FormattedDocument document) {
        String body;
        if (htmlContent != null && !htmlContent.isBlank()) {
            String sanitized = renderer.sanitizeFreeformHtml(htmlContent);
            body = renderer.prepareDestinationHtml(sanitized, "CONFLUENCE");
        } else {
            body = renderer.confluenceHtml(document);
        }
        return "<!doctype html><html lang=\"en\"><head><meta charset=\"UTF-8\">"
                + "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">"
                + "<title>Confluence Content</title></head><body>" + body + "</body></html>";
    }

    private byte[] word(FormattedDocument document) throws Exception {
        try (XWPFDocument doc = new XWPFDocument(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            addWordAccent(doc);
            Map<String, DocumentBlock> blocks = blockMap(document);

            if (hasSemantic(document)) {
                for (SemanticSection section : document.semanticSections()) {
                    SemanticLayoutType sectionLayout = layout(section);
                    if (sectionLayout != SemanticLayoutType.TEXT && sectionLayout != SemanticLayoutType.CODE_GROUP) addWordSectionTitle(doc, section);
                    switch (sectionLayout) {
                        case TABLE, COMPARISON -> addWordTable(doc, section);
                        case WORKFLOW, ARCHITECTURE, HIERARCHY -> addWordFlow(doc, section);
                        case TIMELINE -> addWordTimeline(doc, section);
                        case STATUS, KPI -> addWordCardsTable(doc, section);
                        case CHECKLIST -> addWordChecklist(doc, section);
                        case CALLOUT -> addWordCallouts(doc, section);
                        case TEXT, CODE_GROUP -> addWordBlocks(doc, referencedBlocks(section, blocks));
                    }
                }
            } else {
                addWordBlocks(doc, document.blocks());
            }

            doc.write(out);
            return out.toByteArray();
        }
    }

    private void addWordAccent(XWPFDocument doc) {
        XWPFParagraph accentP = doc.createParagraph();
        XWPFRun accent = accentP.createRun();
        accent.setText(" ");
        accent.setFontSize(4);
        CTShd shading = accent.getCTR().addNewRPr().addNewShd();
        shading.setVal(STShd.CLEAR);
        shading.setFill(GREEN);
    }

    private void addWordSectionTitle(XWPFDocument doc, SemanticSection section) {
        if (section.title() == null || section.title().isBlank()) return;
        XWPFParagraph p = doc.createParagraph();
        p.setSpacingBefore(160); p.setSpacingAfter(80);
        XWPFRun run = p.createRun();
        String icon = iconCatalog.symbol(section.iconKey());
        run.setText((icon.isBlank() ? "" : icon + "  ") + section.title());
        run.setBold(true); run.setColor(GREEN_DARK); run.setFontSize(14); run.setFontFamily("Arial");
    }

    private void addWordTable(XWPFDocument doc, SemanticSection section) {
        int cols = safe(section.rows()).stream().mapToInt(r -> safe(r.cells()).size()).max().orElse(2);
        List<String> headers = paddedColumns(section.columns(), cols);
        XWPFTable table = doc.createTable(Math.max(1, section.rows().size()) + 1, cols);
        for (int c = 0; c < cols; c++) {
            XWPFTableCell cell = table.getRow(0).getCell(c);
            cell.setColor(GREEN_DARK);
            setCellText(cell, headers.get(c), true, "FFFFFF");
        }
        for (int r = 0; r < section.rows().size(); r++) {
            List<SemanticValue> cells = safe(section.rows().get(r).cells());
            for (int c = 0; c < cols; c++) {
                String value = c < cells.size() ? cells.get(c).text() : "";
                XWPFTableCell cell = table.getRow(r + 1).getCell(c);
                if (r % 2 == 1) cell.setColor("F7FBF8");
                setCellText(cell, value, false, "1F2D25");
            }
        }
        doc.createParagraph().setSpacingAfter(80);
    }

    private void addWordFlow(XWPFDocument doc, SemanticSection section) {
        XWPFParagraph p = doc.createParagraph();
        p.setSpacingAfter(100);
        List<SemanticNode> nodes = safe(section.nodes());
        Map<String, SemanticEdge> edgeMap = section.edges().stream().collect(Collectors.toMap(SemanticEdge::from, Function.identity(), (a, b) -> a));
        for (int i = 0; i < nodes.size(); i++) {
            SemanticNode node = nodes.get(i);
            XWPFRun nodeRun = p.createRun();
            String icon = iconCatalog.symbol(node.iconKey());
            nodeRun.setText((icon.isBlank() ? "" : icon + " ") + node.text());
            nodeRun.setBold(true); nodeRun.setColor(GREEN_DARK); nodeRun.setFontFamily("Arial"); nodeRun.setFontSize(10);
            if (i < nodes.size() - 1) {
                SemanticEdge edge = edgeMap.get(node.id());
                XWPFRun arrow = p.createRun();
                String label = edge == null || edge.label() == null || edge.label().isBlank() ? "" : "  " + edge.label() + "  ";
                arrow.setText(label + "  →  ");
                arrow.setColor(GREEN); arrow.setBold(true);
            }
        }
    }

    private void addWordTimeline(XWPFDocument doc, SemanticSection section) {
        for (SemanticItem item : safe(section.items())) {
            XWPFParagraph p = doc.createParagraph();
            p.setIndentationLeft(220);
            XWPFRun marker = p.createRun(); marker.setText("●  "); marker.setColor(GREEN); marker.setBold(true);
            XWPFRun text = p.createRun(); text.setText(joinItem(item)); text.setFontFamily("Arial"); text.setFontSize(10);
        }
    }

    private void addWordCardsTable(XWPFDocument doc, SemanticSection section) {
        XWPFTable table = doc.createTable(Math.max(1, section.items().size()), 3);
        int r = 0;
        for (SemanticItem item : safe(section.items())) {
            setCellText(table.getRow(r).getCell(0), item.label(), true, GREEN_DARK);
            setCellText(table.getRow(r).getCell(1), item.value(), false, "1F2D25");
            setCellText(table.getRow(r).getCell(2), item.status(), true, GREEN);
            if (r % 2 == 1) {
                for (XWPFTableCell cell : table.getRow(r).getTableCells()) cell.setColor("F7FBF8");
            }
            r++;
        }
    }

    private void addWordChecklist(XWPFDocument doc, SemanticSection section) {
        for (SemanticItem item : safe(section.items())) {
            XWPFParagraph p = doc.createParagraph();
            p.setIndentationLeft(220);
            XWPFRun tick = p.createRun(); tick.setText("✓  "); tick.setColor(GREEN); tick.setBold(true);
            XWPFRun text = p.createRun(); text.setText(joinItem(item)); text.setFontFamily("Arial"); text.setFontSize(10);
        }
    }

    private void addWordCallouts(XWPFDocument doc, SemanticSection section) {
        for (SemanticItem item : safe(section.items())) {
            XWPFParagraph p = doc.createParagraph();
            applyParagraphShading(p, GREEN_SOFT);
            XWPFRun run = p.createRun();
            String icon = iconCatalog.symbol(item.iconKey());
            run.setText((icon.isBlank() ? "" : icon + "  ") + joinItem(item));
            run.setFontFamily("Arial"); run.setFontSize(10);
        }
    }

    private void addWordBlocks(XWPFDocument doc, List<DocumentBlock> blocks) {
        for (DocumentBlock block : blocks) {
            if (block.type() == BlockType.SPACER) { doc.createParagraph(); continue; }
            XWPFParagraph p = doc.createParagraph();
            XWPFRun run = p.createRun();
            String icon = block.iconSymbol().isBlank() ? "" : block.iconSymbol() + "  ";
            switch (block.type()) {
                case TITLE -> { run.setText(icon + block.text()); run.setBold(true); run.setColor(GREEN); run.setFontSize(20); p.setSpacingAfter(180); }
                case HEADING -> { run.setText(icon + block.text()); run.setBold(true); run.setColor(GREEN); run.setFontSize(14); p.setSpacingBefore(160); p.setSpacingAfter(80); }
                case BULLET -> {
                    XWPFRun tick = p.createRun(); tick.setText("✓  "); tick.setBold(true); tick.setColor(GREEN);
                    run.setText(stripBullet(block.text())); run.setFontFamily("Arial"); run.setFontSize(10); p.setIndentationLeft(240);
                }
                case CODE -> { run.setText(block.text()); run.setFontFamily("Consolas"); run.setFontSize(9); applyParagraphShading(p, "F3F6F4"); }
                case CALLOUT -> { run.setText(icon + block.text()); run.setFontFamily("Arial"); run.setFontSize(10); applyParagraphShading(p, GREEN_SOFT); }
                default -> { run.setText(block.text()); run.setFontFamily("Arial"); run.setFontSize(10); }
            }
            applyEmphasis(run, block.emphasis());
        }
    }

    private void setCellText(XWPFTableCell cell, String text, boolean bold, String color) {
        XWPFParagraph p = cell.getParagraphs().isEmpty() ? cell.addParagraph() : cell.getParagraphs().get(0);
        p.setSpacingAfter(0);
        XWPFRun run = p.createRun();
        run.setText(text == null ? "" : text);
        run.setBold(bold); run.setColor(color); run.setFontFamily("Arial"); run.setFontSize(9);
    }


    private byte[] powerpoint(String htmlContent, FormattedDocument document) throws Exception {
        if (htmlContent != null && !htmlContent.isBlank()) {
            return powerpointFromHtml(htmlContent, document);
        }
        return powerpoint(document);
    }

    /**
     * Converts the LLM's slide-oriented semantic HTML fragment into a real .pptx.
     * The model decides the editorial slide structure; Java applies a stable
     * PowerPoint design system with professional slide splitting, agenda creation,
     * two-column topic layouts, process layouts, table slides and keynote-style
     * slides.  This keeps the LLM focused on story and coverage while Java owns
     * visual consistency and readability.
     */
    private byte[] powerpointFromHtml(String htmlContent, FormattedDocument document) throws Exception {
        List<PptSlideModel> models = preparePresentationSlides(htmlToSlides(htmlContent, document));
        try (XMLSlideShow ppt = new XMLSlideShow(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            ppt.setPageSize(new Dimension(960, 540));
            String deckTitle = models.isEmpty() ? "Formatted Presentation" : models.get(0).title();
            int contentSlideCount = Math.max(0, (int) models.stream().filter(s -> !s.titleSlide()).count());
            addGeneratedTitleSlide(ppt, deckTitle, document, contentSlideCount);
            int slideNumber = 1;
            for (int i = 1; i < models.size(); i++) {
                if (!models.get(i).titleSlide()) addGeneratedContentSlide(ppt, models.get(i), slideNumber++);
            }
            if (ppt.getSlides().size() == 1) {
                addGeneratedContentSlide(ppt,
                        new PptSlideModel("📌 Key Points", List.of(nonBlank(document.plainContent(), "Generated content is ready.")), List.of(), List.of(), false, "bullets"),
                        1);
            }
            ppt.write(out);
            return out.toByteArray();
        }
    }

    private List<PptSlideModel> htmlToSlides(String htmlContent, FormattedDocument document) {
        Document doc = Jsoup.parseBodyFragment(htmlContent == null ? "" : htmlContent);
        List<PptSlideModel> slides = new ArrayList<>();
        String deckTitle = firstText(doc.select("h1"));
        if (deckTitle.isBlank()) deckTitle = firstText(doc.select("h2"));
        if (deckTitle.isBlank()) deckTitle = nonBlank(document.emailSubject(), document.title(), "Formatted Presentation");
        slides.add(new PptSlideModel(cleanPptText(deckTitle, 86), List.of(), List.of(), List.of(), true, "title"));

        MutablePptSlide current = null;
        for (Element child : doc.body().children()) {
            String tag = child.tagName();
            if ("h1".equals(tag)) {
                if (slides.size() == 1 && slides.get(0).title().equals("Formatted Presentation")) {
                    slides.set(0, new PptSlideModel(cleanPptText(child.text(), 86), List.of(), List.of(), List.of(), true, "title"));
                }
                continue;
            }
            if ("h2".equals(tag)) {
                if (current != null) slides.add(current.freeze());
                String requestedLayout = child.hasAttr("data-layout") ? child.attr("data-layout") : "";
                String requestedChart = child.hasAttr("data-chart") ? child.attr("data-chart") : "";
                String requestedDiagram = child.hasAttr("data-diagram") ? child.attr("data-diagram") : "";
                if (!requestedChart.isBlank()) {
                    requestedLayout = (requestedLayout.isBlank() ? "CHART" : requestedLayout) + ":" + requestedChart;
                } else if (!requestedDiagram.isBlank()) {
                    requestedLayout = (requestedLayout.isBlank() ? "DIAGRAM" : requestedLayout) + ":" + requestedDiagram;
                }
                current = new MutablePptSlide(cleanPptText(child.text(), 86), requestedLayout);
                continue;
            }
            if (current == null) current = new MutablePptSlide("📌 Overview", "EXECUTIVE_OVERVIEW");

            switch (tag) {
                case "h3", "h4" -> current.startSubsection(cleanPptText(child.text(), 80));
                case "p" -> current.addBullet(cleanPptText(child.text(), 150));
                case "blockquote" -> current.addTakeaway(cleanPptText(child.text(), 150));
                case "pre" -> current.addCode(child.wholeText());
                case "ul", "ol" -> {
                    if ("ol".equals(tag) && current.layoutHint.isBlank()) current.layoutHint = "PROCESS_5";
                    for (Element li : child.select("li")) current.addBullet(cleanPptText(li.text(), 140));
                }
                case "table" -> current.addTable(extractTableRows(child));
                case "hr" -> current.layoutHint = "divider";
                default -> {
                    String text = child.text();
                    if (text != null && !text.isBlank()) current.addBullet(cleanPptText(text, 145));
                }
            }
        }
        if (current != null) slides.add(current.freeze());

        if (slides.size() == 1) {
            String plain = nonBlank(document.plainContent(), doc.body().text());
            slides.addAll(plainTextFallbackSlides(plain));
        }
        return slides;
    }

    private List<PptSlideModel> preparePresentationSlides(List<PptSlideModel> original) {
        List<PptSlideModel> slides = splitOverloadedSlides(original == null ? List.of() : original);
        if (slides.size() <= 1) return slides;
        long contentSlides = slides.stream().filter(s -> !s.titleSlide()).count();
        boolean hasAgenda = slides.stream().anyMatch(s -> normalizedTitle(s.title()).contains("agenda") || normalizedTitle(s.title()).contains("contents"));
        if (contentSlides >= 5 && !hasAgenda) {
            List<String> agenda = slides.stream()
                    .filter(s -> !s.titleSlide())
                    .map(s -> stripLeadingPresentationIcon(s.title()))
                    .filter(t -> !t.isBlank())
                    .toList();
            if (!agenda.isEmpty()) {
                List<PptSlideModel> withAgenda = new ArrayList<>();
                withAgenda.add(slides.get(0));
                for (int i = 0; i < agenda.size(); i += 7) {
                    withAgenda.add(new PptSlideModel(
                            i == 0 ? "📋 Agenda" : "📋 Agenda (continued)",
                            List.copyOf(agenda.subList(i, Math.min(i + 7, agenda.size()))),
                            List.of(), List.of(), false, "agenda"));
                }
                withAgenda.addAll(slides.subList(1, slides.size()));
                slides = withAgenda;
            }
        }
        return slides;
    }

    private List<PptSlideModel> splitOverloadedSlides(List<PptSlideModel> slides) {
        List<PptSlideModel> result = new ArrayList<>();
        for (PptSlideModel slide : slides) {
            if (slide.titleSlide()) {
                result.add(slide);
                continue;
            }

            BnpPresentationLayout layout = selectPresentationLayout(slide);

            if (layout == BnpPresentationLayout.CHART) {
                if (hasChartableData(slide)) {
                    result.addAll(paginateChartSlide(slide));
                } else if (!slide.tableRows().isEmpty()) {
                    // Do not emit an empty/broken chart when the model chose CHART
                    // for non-numeric data. Preserve the source as a native table.
                    result.addAll(paginateTableSlide(new PptSlideModel(
                            slide.title(), slide.bullets(), slide.tableRows(), slide.subSections(), false, BnpPresentationLayout.TABLE.name())));
                } else {
                    List<String> fallbackBullets = new ArrayList<>(slide.bullets() == null ? List.of() : slide.bullets());
                    for (PptSubsection subsection : slide.subSections()) {
                        String detail = String.join("; ", subsection.bullets() == null ? List.of() : subsection.bullets());
                        fallbackBullets.add(subsection.title() + (detail.isBlank() ? "" : ": " + detail));
                    }
                    result.addAll(paginateBulletSlide(new PptSlideModel(
                            slide.title(), fallbackBullets, List.of(), List.of(), false, BnpPresentationLayout.BULLETS.name())));
                }
                continue;
            }

            if (layout == BnpPresentationLayout.DIAGRAM) {
                result.addAll(paginateDiagramSlide(slide));
                continue;
            }

            if (!slide.tableRows().isEmpty()) {
                result.addAll(paginateTableSlide(new PptSlideModel(
                        slide.title(), slide.bullets(), slide.tableRows(), slide.subSections(), false, BnpPresentationLayout.TABLE.name())));
                continue;
            }

            if (layout == BnpPresentationLayout.CODE) {
                result.addAll(paginateCodeSlide(slide));
                continue;
            }

            if (!slide.subSections().isEmpty()) {
                List<String> topBullets = expandPptItems(slide.bullets(), 220);
                // A card layout can carry one short contextual line above the cards.
                if (topBullets.size() > 1) {
                    result.addAll(paginateBulletSlide(new PptSlideModel(
                            slide.title(), topBullets, List.of(), List.of(), false, BnpPresentationLayout.BULLETS.name())));
                    topBullets = List.of();
                }

                List<PptSubsection> cards = new ArrayList<>();
                for (PptSubsection subsection : slide.subSections()) {
                    List<String> points = expandPptItems(subsection.bullets(), 150);
                    if (points.isEmpty()) points = List.of("Key point captured from the source content.");
                    for (int i = 0; i < points.size(); i += 3) {
                        String subsectionTitle = i == 0 ? subsection.title() : subsection.title() + " (continued)";
                        cards.add(new PptSubsection(subsectionTitle,
                                List.copyOf(points.subList(i, Math.min(i + 3, points.size())))));
                    }
                }

                BnpPresentationLayout cardLayout = switch (layout) {
                    case COMPARISON -> BnpPresentationLayout.COMPARISON;
                    case TWO_COLUMN -> BnpPresentationLayout.TWO_COLUMN;
                    case THREE_CARDS -> BnpPresentationLayout.THREE_CARDS;
                    case FOUR_CARDS -> BnpPresentationLayout.FOUR_CARDS;
                    default -> cards.size() == 2 ? BnpPresentationLayout.TWO_COLUMN
                            : cards.size() == 3 ? BnpPresentationLayout.THREE_CARDS
                            : BnpPresentationLayout.FOUR_CARDS;
                };
                int cardsPerSlide = switch (cardLayout) {
                    case TWO_COLUMN, COMPARISON -> 2;
                    case THREE_CARDS -> 3;
                    default -> 4;
                };

                int part = 1;
                for (int i = 0; i < cards.size(); i += cardsPerSlide) {
                    String title = part == 1 ? slide.title() : slide.title() + " (continued)";
                    result.add(new PptSlideModel(title,
                            part == 1 ? topBullets : List.of(),
                            List.of(),
                            List.copyOf(cards.subList(i, Math.min(i + cardsPerSlide, cards.size()))),
                            false,
                            cardLayout.name()));
                    part++;
                }
                continue;
            }

            List<String> bullets = expandPptItems(slide.bullets(), 220);
            int pageSize = switch (layout) {
                case PROCESS_5, EXECUTIVE_OVERVIEW, TIMELINE -> 5;
                case CHECKLIST, NEXT_STEPS -> 6;
                case KEY_MESSAGE -> 3;
                default -> 5;
            };
            if (bullets.isEmpty()) bullets = List.of("Key information captured from the source content.");

            int part = 1;
            for (int i = 0; i < bullets.size(); i += pageSize) {
                String pageTitle = part == 1 ? slide.title() : slide.title() + " (continued)";
                result.add(new PptSlideModel(pageTitle,
                        List.copyOf(bullets.subList(i, Math.min(i + pageSize, bullets.size()))),
                        List.of(), List.of(), false, layout.name()));
                part++;
            }
        }
        return result;
    }

    private List<PptSlideModel> paginateDiagramSlide(PptSlideModel slide) {
        BnpPresentationDiagramType type = diagramTypeFor(slide);
        String hint = "DIAGRAM:" + type.name();
        List<PptSlideModel> result = new ArrayList<>();

        if (Set.of(BnpPresentationDiagramType.SWIMLANE, BnpPresentationDiagramType.HIERARCHY,
                BnpPresentationDiagramType.MATRIX_2X2, BnpPresentationDiagramType.DECISION_TREE,
                BnpPresentationDiagramType.BEFORE_AFTER, BnpPresentationDiagramType.COMPARISON_FLOW)
                .contains(type) && !slide.subSections().isEmpty()) {
            List<PptSubsection> expanded = new ArrayList<>();
            for (PptSubsection subsection : slide.subSections()) {
                List<String> points = expandPptItems(subsection.bullets(), 120);
                if (points.isEmpty()) {
                    expanded.add(new PptSubsection(subsection.title(), List.of()));
                    continue;
                }
                for (int i = 0; i < points.size(); i += 3) {
                    expanded.add(new PptSubsection(
                            i == 0 ? subsection.title() : subsection.title() + " (continued)",
                            List.copyOf(points.subList(i, Math.min(i + 3, points.size())))));
                }
            }
            int perSlide = switch (type) {
                case BEFORE_AFTER, COMPARISON_FLOW -> 2;
                case MATRIX_2X2 -> 4;
                case SWIMLANE -> 4;
                default -> 4;
            };
            int part = 1;
            for (int i = 0; i < expanded.size(); i += perSlide) {
                String title = part == 1 ? slide.title() : slide.title() + " (continued)";
                result.add(new PptSlideModel(title,
                        part == 1 ? expandPptItems(slide.bullets(), 150).stream().limit(1).toList() : List.of(),
                        List.of(),
                        List.copyOf(expanded.subList(i, Math.min(i + perSlide, expanded.size()))),
                        false, hint));
                part++;
            }
            return result.isEmpty() ? List.of(new PptSlideModel(slide.title(), slide.bullets(), List.of(), List.of(), false, hint)) : result;
        }

        List<String> items = new ArrayList<>(expandPptItems(slide.bullets(), 135));
        for (PptSubsection subsection : slide.subSections()) {
            if (subsection.bullets().isEmpty()) items.add(subsection.title());
            else for (String point : subsection.bullets()) items.add(subsection.title() + ": " + point);
        }
        if (items.isEmpty()) items = List.of(stripLeadingPresentationIcon(slide.title()));
        int perSlide = switch (type) {
            case FUNNEL, PYRAMID, CHEVRON_PROCESS, ARCHITECTURE_FLOW, PIPELINE -> 5;
            case HUB_SPOKE, CYCLE, FEEDBACK_LOOP, ROADMAP -> 6;
            case CONVERGING_FLOW, DIVERGING_FLOW -> 5;
            default -> 6;
        };
        int part = 1;
        for (int i = 0; i < items.size(); i += perSlide) {
            String title = part == 1 ? slide.title() : slide.title() + " (continued)";
            result.add(new PptSlideModel(title,
                    List.copyOf(items.subList(i, Math.min(i + perSlide, items.size()))),
                    List.of(), List.of(), false, hint));
            part++;
        }
        return result;
    }

    private List<PptSlideModel> paginateCodeSlide(PptSlideModel slide) {
        String raw = slide.bullets() == null ? "" : String.join("\n", slide.bullets());
        List<String> lines = Arrays.asList(raw.replace("\r", "").split("\n", -1));
        if (lines.isEmpty()) lines = List.of("");
        List<PptSlideModel> result = new ArrayList<>();
        int part = 1;
        for (int i = 0; i < lines.size(); i += 16) {
            String pageTitle = part == 1 ? slide.title() : slide.title() + " (continued)";
            String code = String.join("\n", lines.subList(i, Math.min(i + 16, lines.size())));
            result.add(new PptSlideModel(pageTitle, List.of(code), List.of(), List.of(), false, BnpPresentationLayout.CODE.name()));
            part++;
        }
        return result;
    }

    private BnpPresentationLayout selectPresentationLayout(PptSlideModel model) {
        String hint = model.layoutHint() == null ? "" : model.layoutHint().trim();
        if (!hint.isBlank()) {
            BnpPresentationLayout selected = BnpPresentationLayout.fromHint(hint);
            if (selected != BnpPresentationLayout.BULLETS || hint.equalsIgnoreCase("BULLETS")) return selected;
        }

        String title = normalizedTitle(model.title());
        if (title.contains("agenda") || title.contains("contents")) return BnpPresentationLayout.AGENDA;
        if (!model.tableRows().isEmpty()) {
            BnpPresentationChartType inferred = inferChartType(model);
            if (inferred != BnpPresentationChartType.NONE) return BnpPresentationLayout.CHART;
            return BnpPresentationLayout.TABLE;
        }
        BnpPresentationDiagramType inferredDiagram = inferDiagramType(model);
        if (inferredDiagram != BnpPresentationDiagramType.NONE) return BnpPresentationLayout.DIAGRAM;
        if (!model.subSections().isEmpty()) {
            if (title.contains("compar") || title.contains(" vs ") || title.contains("versus")) return BnpPresentationLayout.COMPARISON;
            if (model.subSections().size() == 2) return BnpPresentationLayout.TWO_COLUMN;
            if (model.subSections().size() == 3) return BnpPresentationLayout.THREE_CARDS;
            return BnpPresentationLayout.FOUR_CARDS;
        }
        if (title.contains("json") || title.contains("code") || title.contains("payload") || title.contains("request body")) return BnpPresentationLayout.CODE;
        if (title.contains("process") || title.contains("workflow") || title.contains("steps") || title.contains("flow")) return BnpPresentationLayout.PROCESS_5;
        if (title.contains("timeline") || title.contains("roadmap") || title.contains("milestone")) return BnpPresentationLayout.TIMELINE;
        if (title.contains("quick-start") || title.contains("quick start") || title.contains("checklist") || title.contains("readiness")) return BnpPresentationLayout.CHECKLIST;
        if (title.contains("next step") || title.contains("action")) return BnpPresentationLayout.NEXT_STEPS;
        if (title.contains("executive") || title.contains("overview") || title.contains("objective")) return BnpPresentationLayout.EXECUTIVE_OVERVIEW;
        int bulletCount = model.bullets() == null ? 0 : model.bullets().size();
        int chars = model.bullets() == null ? 0 : model.bullets().stream().mapToInt(v -> v == null ? 0 : v.length()).sum();
        if (bulletCount > 0 && bulletCount <= 3 && chars <= 300) return BnpPresentationLayout.KEY_MESSAGE;
        return BnpPresentationLayout.BULLETS;
    }


    private BnpPresentationDiagramType requestedDiagramType(PptSlideModel model) {
        String hint = model.layoutHint() == null ? "" : model.layoutHint().trim();
        if (BnpPresentationLayout.fromHint(hint) != BnpPresentationLayout.DIAGRAM) return BnpPresentationDiagramType.NONE;
        int separator = hint.indexOf(':');
        if (separator < 0 || separator == hint.length() - 1) return BnpPresentationDiagramType.NONE;
        return BnpPresentationDiagramType.fromHint(hint.substring(separator + 1));
    }

    private BnpPresentationDiagramType diagramTypeFor(PptSlideModel model) {
        BnpPresentationDiagramType requested = requestedDiagramType(model);
        BnpPresentationDiagramType inferred = inferDiagramType(model);
        if (requested == BnpPresentationDiagramType.NONE) return inferred == BnpPresentationDiagramType.NONE
                ? BnpPresentationDiagramType.LINEAR_PROCESS : inferred;
        // Java remains the source of truth. Correct the most obviously incompatible choices.
        if (requested == BnpPresentationDiagramType.MATRIX_2X2 && model.subSections().size() != 4) {
            return BnpPresentationDiagramType.LINEAR_PROCESS;
        }
        if ((requested == BnpPresentationDiagramType.BEFORE_AFTER || requested == BnpPresentationDiagramType.COMPARISON_FLOW)
                && !model.subSections().isEmpty() && model.subSections().size() != 2) {
            return BnpPresentationDiagramType.LINEAR_PROCESS;
        }
        if (requested == BnpPresentationDiagramType.SWIMLANE && model.subSections().size() < 2) {
            return BnpPresentationDiagramType.LINEAR_PROCESS;
        }
        if ((requested == BnpPresentationDiagramType.HIERARCHY || requested == BnpPresentationDiagramType.DECISION_TREE)
                && !model.subSections().isEmpty() && model.subSections().size() < 2) {
            return BnpPresentationDiagramType.LINEAR_PROCESS;
        }
        return requested;
    }

    /**
     * Conservative diagram inference used when model metadata is missing or structurally invalid.
     * The title carries most of the signal so ordinary bullet slides are not turned into diagrams.
     */
    private BnpPresentationDiagramType inferDiagramType(PptSlideModel model) {
        String title = normalizedTitle(model.title());
        String context = (title + " " + String.join(" ", model.bullets() == null ? List.of() : model.bullets())
                + " " + model.subSections().stream().map(PptSubsection::title).collect(Collectors.joining(" ")))
                .toLowerCase(Locale.ROOT);

        if (containsAny(title, "2x2", "2 x 2", "quadrant", "matrix")) return BnpPresentationDiagramType.MATRIX_2X2;
        if (containsAny(title, "swimlane", "swim lane", "handoff by", "responsibility flow", "role flow")) return BnpPresentationDiagramType.SWIMLANE;
        if (containsAny(title, "decision tree", "decision flow", "branching", "yes/no", "yes no")) return BnpPresentationDiagramType.DECISION_TREE;
        if (containsAny(title, "before and after", "before/after", "as-is to-be", "as is to be", "transformation")) return BnpPresentationDiagramType.BEFORE_AFTER;
        if (containsAny(title, "feedback loop", "closed loop", "self-healing loop", "retry loop")) return BnpPresentationDiagramType.FEEDBACK_LOOP;
        if (containsAny(title, "converging", "merge flow", "many to one", "aggregation flow")) return BnpPresentationDiagramType.CONVERGING_FLOW;
        if (containsAny(title, "diverging", "split flow", "fan-out", "fan out", "one to many")) return BnpPresentationDiagramType.DIVERGING_FLOW;
        if (containsAny(title, "hub and spoke", "hub-and-spoke", "ecosystem", "integration landscape")) return BnpPresentationDiagramType.HUB_SPOKE;
        if (containsAny(title, "hierarchy", "org chart", "organization structure", "reporting structure", "parent child")) return BnpPresentationDiagramType.HIERARCHY;
        if (containsAny(title, "funnel", "filtering stages", "conversion funnel")) return BnpPresentationDiagramType.FUNNEL;
        if (containsAny(title, "pyramid", "maturity levels", "priority levels")) return BnpPresentationDiagramType.PYRAMID;
        if (containsAny(title, "architecture", "system flow", "integration flow", "data flow", "component flow")) return BnpPresentationDiagramType.ARCHITECTURE_FLOW;
        if (containsAny(title, "pipeline", "input process output", "processing pipeline", "delivery pipeline")) return BnpPresentationDiagramType.PIPELINE;
        if (containsAny(title, "roadmap", "milestone journey")) return BnpPresentationDiagramType.ROADMAP;
        if (containsAny(title, "cycle", "lifecycle", "life cycle", "continuous improvement") || context.contains("repeat until")) return BnpPresentationDiagramType.CYCLE;
        if (containsAny(title, "comparison flow", "parallel flow")) return BnpPresentationDiagramType.COMPARISON_FLOW;
        if (containsAny(title, "phases", "stages") && model.bullets().size() >= 3) return BnpPresentationDiagramType.CHEVRON_PROCESS;
        if (containsAny(title, "process", "workflow", "sequence", "flow") && model.bullets().size() >= 3) return BnpPresentationDiagramType.LINEAR_PROCESS;
        return BnpPresentationDiagramType.NONE;
    }

    private boolean containsAny(String value, String... tokens) {
        if (value == null || value.isBlank()) return false;
        for (String token : tokens) if (value.contains(token)) return true;
        return false;
    }

    private BnpPresentationChartType requestedChartType(PptSlideModel model) {
        String hint = model.layoutHint() == null ? "" : model.layoutHint().trim();
        int separator = hint.indexOf(':');
        if (separator < 0 || separator == hint.length() - 1) return BnpPresentationChartType.NONE;
        return BnpPresentationChartType.fromHint(hint.substring(separator + 1));
    }

    private BnpPresentationChartType chartTypeFor(PptSlideModel model) {
        BnpPresentationChartType requested = requestedChartType(model);
        if (requested != BnpPresentationChartType.NONE) return requested;
        BnpPresentationChartType inferred = inferChartType(model);
        if (inferred != BnpPresentationChartType.NONE) return inferred;
        String hint = model.layoutHint() == null ? "" : model.layoutHint();
        return BnpPresentationLayout.fromHint(hint) == BnpPresentationLayout.CHART
                ? BnpPresentationChartType.COLUMN
                : BnpPresentationChartType.NONE;
    }

    /**
     * Conservative local inference. The LLM normally declares data-chart, but
     * Java can still choose a sensible native PowerPoint chart when metadata is
     * missing. It never creates a chart without source-backed numeric data.
     */
    private BnpPresentationChartType inferChartType(PptSlideModel model) {
        if (!hasBasicNumericSeries(model.tableRows())) return BnpPresentationChartType.NONE;
        String title = normalizedTitle(model.title());
        int dataRows = Math.max(0, model.tableRows().size() - 1);
        int numericSeries = numericSeriesColumns(model.tableRows()).size();

        if ((title.contains("relationship") || title.contains("correlation") || title.contains(" vs ")
                || title.contains("versus")) && numericColumns(model.tableRows()).size() >= 2) {
            return BnpPresentationChartType.SCATTER;
        }
        // Area is a more specific ordered-trend intent than generic line, so test it first.
        if (title.contains("cumulative") || title.contains("volume over") || title.contains("usage over")
                || title.contains("adoption over")) {
            return BnpPresentationChartType.AREA;
        }
        if (title.contains("trend") || title.contains("over time") || title.contains("monthly")
                || title.contains("quarter") || title.contains("year") || title.contains("history")
                || title.contains("growth")) {
            return BnpPresentationChartType.LINE;
        }
        if ((title.contains("share") || title.contains("mix") || title.contains("composition")
                || title.contains("proportion") || title.contains("distribution"))
                && numericSeries >= 1 && dataRows <= 6) {
            return title.contains("pie") ? BnpPresentationChartType.PIE : BnpPresentationChartType.DOUGHNUT;
        }
        if ((title.contains("maturity") || title.contains("profile") || title.contains("capability score")
                || title.contains("dimension")) && dataRows >= 3 && dataRows <= 8) {
            return BnpPresentationChartType.RADAR;
        }
        if (title.contains("rank") || title.contains("top ") || title.contains("bottom ")
                || title.contains("ranking") || dataRows > 6) {
            return BnpPresentationChartType.BAR;
        }
        if (title.contains("compare") || title.contains("comparison") || title.contains("performance")
                || title.contains("count") || title.contains("rate") || title.contains("score")
                || title.contains("result") || title.contains("by ")) {
            return BnpPresentationChartType.COLUMN;
        }
        return BnpPresentationChartType.NONE;
    }

    private boolean hasChartableData(PptSlideModel model) {
        BnpPresentationChartType type = chartTypeFor(model);
        if (type == BnpPresentationChartType.NONE || model.tableRows() == null || model.tableRows().size() < 2) return false;
        if (type == BnpPresentationChartType.SCATTER) return numericColumns(model.tableRows()).size() >= 2;
        return hasBasicNumericSeries(model.tableRows());
    }

    private boolean hasBasicNumericSeries(List<List<String>> rows) {
        return rows != null && rows.size() >= 2 && !numericSeriesColumns(rows).isEmpty();
    }

    private List<Integer> numericSeriesColumns(List<List<String>> rows) {
        List<Integer> numeric = numericColumns(rows);
        return numeric.stream().filter(i -> i > 0).toList();
    }

    private List<Integer> numericColumns(List<List<String>> rows) {
        if (rows == null || rows.size() < 2) return List.of();
        int maxCols = rows.stream().mapToInt(List::size).max().orElse(0);
        List<Integer> result = new ArrayList<>();
        for (int col = 0; col < maxCols; col++) {
            int populated = 0;
            int numeric = 0;
            for (int r = 1; r < rows.size(); r++) {
                String raw = col < rows.get(r).size() ? rows.get(r).get(col) : "";
                if (raw == null || raw.isBlank()) continue;
                populated++;
                if (parseChartNumber(raw).isPresent()) numeric++;
            }
            if (populated > 0 && numeric >= Math.max(1, (int) Math.ceil(populated * 0.80d))) result.add(col);
        }
        return List.copyOf(result);
    }

    private OptionalDouble parseChartNumber(String raw) {
        if (raw == null) return OptionalDouble.empty();
        String text = raw.trim();
        if (text.isBlank()) return OptionalDouble.empty();
        boolean negativeParentheses = text.startsWith("(") && text.endsWith(")");
        String cleaned = text.replace(",", "")
                .replace("₹", "").replace("$", "").replace("€", "").replace("£", "").replace("¥", "")
                .replace("%", "").trim();
        if (negativeParentheses && cleaned.length() > 2) cleaned = "-" + cleaned.substring(1, cleaned.length() - 1).trim();
        cleaned = cleaned.replaceFirst("^\\+", "");
        try {
            return OptionalDouble.of(Double.parseDouble(cleaned));
        } catch (NumberFormatException ex) {
            return OptionalDouble.empty();
        }
    }

    private boolean columnIsPercent(List<List<String>> rows, int col) {
        int values = 0;
        int percents = 0;
        for (int r = 1; r < rows.size(); r++) {
            String raw = col < rows.get(r).size() ? rows.get(r).get(col) : "";
            if (raw == null || raw.isBlank() || parseChartNumber(raw).isEmpty()) continue;
            values++;
            if (raw.contains("%")) percents++;
        }
        return values > 0 && percents == values;
    }

    private List<PptSlideModel> paginateChartSlide(PptSlideModel slide) {
        BnpPresentationChartType type = chartTypeFor(slide);
        if (type == BnpPresentationChartType.NONE || !hasChartableData(slide)) {
            return paginateTableSlide(new PptSlideModel(slide.title(), slide.bullets(), slide.tableRows(),
                    slide.subSections(), false, BnpPresentationLayout.TABLE.name()));
        }

        List<PptSlideModel> result = new ArrayList<>();
        List<String> insights = expandPptItems(slide.bullets(), 180);
        if (insights.size() > 2) {
            result.addAll(paginateBulletSlide(new PptSlideModel(slide.title() + " – Key insights", insights,
                    List.of(), List.of(), false, BnpPresentationLayout.BULLETS.name())));
            insights = List.of();
        }

        List<List<String>> rows = slide.tableRows();
        List<Integer> numericCols = numericColumns(rows);
        int maxCategories = switch (type) {
            case PIE, DOUGHNUT -> 6;
            case RADAR, COLUMN -> 8;
            case BAR -> 9;
            case LINE, AREA -> 12;
            case SCATTER -> 14;
            case NONE -> 8;
        };
        int part = 1;

        if (type == BnpPresentationChartType.SCATTER) {
            if (numericCols.size() < 2) {
                return paginateTableSlide(new PptSlideModel(slide.title(), slide.bullets(), rows,
                        slide.subSections(), false, BnpPresentationLayout.TABLE.name()));
            }
            int xCol = numericCols.get(0);
            int yCol = numericCols.get(1);
            List<List<String>> projected = projectTableRows(rows, new int[]{xCol, yCol});
            List<String> header = projected.get(0);
            List<List<String>> data = projected.subList(1, projected.size());
            for (int i = 0; i < data.size(); i += maxCategories) {
                List<List<String>> pageRows = new ArrayList<>();
                pageRows.add(header);
                pageRows.addAll(data.subList(i, Math.min(i + maxCategories, data.size())));
                String title = part == 1 ? slide.title() : slide.title() + " (continued)";
                result.add(new PptSlideModel(title, part == 1 ? insights : List.of(), List.copyOf(pageRows),
                        List.of(), false, "CHART:" + type.name()));
                part++;
            }
        } else {
            List<Integer> seriesCols = numericSeriesColumns(rows);
            if (seriesCols.isEmpty()) {
                return paginateTableSlide(new PptSlideModel(slide.title(), slide.bullets(), rows,
                        slide.subSections(), false, BnpPresentationLayout.TABLE.name()));
            }
            int seriesPerPage = (type == BnpPresentationChartType.PIE || type == BnpPresentationChartType.DOUGHNUT) ? 1 : 4;
            List<String> header = rows.get(0);
            List<List<String>> data = rows.subList(1, rows.size());
            for (int seriesStart = 0; seriesStart < seriesCols.size(); seriesStart += seriesPerPage) {
                List<Integer> seriesGroup = seriesCols.subList(seriesStart, Math.min(seriesStart + seriesPerPage, seriesCols.size()));
                int[] columns = new int[1 + seriesGroup.size()];
                columns[0] = 0;
                for (int j = 0; j < seriesGroup.size(); j++) columns[j + 1] = seriesGroup.get(j);
                for (int i = 0; i < data.size(); i += maxCategories) {
                    List<List<String>> pageRows = new ArrayList<>();
                    pageRows.add(projectTableRow(header, columns));
                    for (List<String> row : data.subList(i, Math.min(i + maxCategories, data.size()))) {
                        pageRows.add(projectTableRow(row, columns));
                    }
                    String title = part == 1 ? slide.title() : slide.title() + " (continued)";
                    result.add(new PptSlideModel(title, part == 1 ? insights : List.of(), List.copyOf(pageRows),
                            List.of(), false, "CHART:" + type.name()));
                    part++;
                }
            }
        }

        // A chart deliberately focuses on category + numeric series. If the source
        // table also contained descriptive/non-numeric columns, retain them in a
        // detail table so the visualization never causes factual data loss.
        int maxCols = rows.stream().mapToInt(List::size).max().orElse(0);
        Set<Integer> chartedColumns = new HashSet<>();
        if (type == BnpPresentationChartType.SCATTER) chartedColumns.addAll(numericCols.stream().limit(2).toList());
        else {
            chartedColumns.add(0);
            chartedColumns.addAll(numericSeriesColumns(rows));
        }
        boolean hasUnchartedColumns = java.util.stream.IntStream.range(0, maxCols).anyMatch(c -> !chartedColumns.contains(c));
        if (hasUnchartedColumns) {
            result.addAll(paginateTableSlide(new PptSlideModel(slide.title() + " – Data detail", List.of(), rows,
                    List.of(), false, BnpPresentationLayout.TABLE.name())));
        }
        return result;
    }

    private List<List<String>> projectTableRows(List<List<String>> rows, int[] columns) {
        List<List<String>> result = new ArrayList<>();
        for (List<String> row : rows) result.add(projectTableRow(row, columns));
        return List.copyOf(result);
    }

    private List<PptSlideModel> paginateBulletSlide(PptSlideModel slide) {
        List<String> bullets = expandPptItems(slide.bullets(), 220);
        if (bullets.isEmpty()) bullets = List.of("Key information captured from the source content.");
        List<PptSlideModel> result = new ArrayList<>();
        int part = 1;
        for (int i = 0; i < bullets.size(); i += 5) {
            String title = part == 1 ? slide.title() : slide.title() + " (continued)";
            result.add(new PptSlideModel(title,
                    List.copyOf(bullets.subList(i, Math.min(i + 5, bullets.size()))),
                    List.of(), List.of(), false, slide.layoutHint()));
            part++;
        }
        return result;
    }

    private List<PptSlideModel> paginateTableSlide(PptSlideModel slide) {
        List<PptSlideModel> result = new ArrayList<>();
        List<List<String>> rows = slide.tableRows();
        if (rows.isEmpty()) return List.of(slide);

        List<String> bullets = expandPptItems(slide.bullets(), 220);
        if (bullets.size() > 2) {
            result.addAll(paginateBulletSlide(new PptSlideModel(
                    slide.title(), bullets, List.of(), List.of(), false, "bullets")));
            bullets = List.of();
        }

        int maxCols = rows.stream().mapToInt(List::size).max().orElse(1);
        List<int[]> groups = new ArrayList<>();
        if (maxCols <= 5) {
            int[] all = new int[maxCols];
            for (int i = 0; i < maxCols; i++) all[i] = i;
            groups.add(all);
        } else {
            for (int start = 1; start < maxCols; start += 4) {
                int end = Math.min(maxCols, start + 4);
                int[] group = new int[1 + end - start];
                group[0] = 0;
                for (int c = start; c < end; c++) group[1 + c - start] = c;
                groups.add(group);
            }
        }

        List<String> header = rows.get(0);
        List<List<String>> data = rows.size() > 1 ? rows.subList(1, rows.size()) : List.of();
        int page = 1;
        for (int[] group : groups) {
            if (data.isEmpty()) {
                String title = page == 1 ? slide.title() : slide.title() + " (continued)";
                result.add(new PptSlideModel(title, page == 1 ? bullets : List.of(),
                        List.of(projectTableRow(header, group)), List.of(), false, "table"));
                page++;
                continue;
            }
            for (int i = 0; i < data.size(); i += 8) {
                List<List<String>> pageRows = new ArrayList<>();
                pageRows.add(projectTableRow(header, group));
                for (List<String> row : data.subList(i, Math.min(i + 8, data.size()))) {
                    pageRows.add(projectTableRow(row, group));
                }
                String title = page == 1 ? slide.title() : slide.title() + " (continued)";
                result.add(new PptSlideModel(title, page == 1 ? bullets : List.of(),
                        List.copyOf(pageRows), List.of(), false, "table"));
                page++;
            }
        }
        return result;
    }

    private List<String> projectTableRow(List<String> row, int[] columns) {
        List<String> projected = new ArrayList<>();
        for (int column : columns) projected.add(column < row.size() ? row.get(column) : "");
        return List.copyOf(projected);
    }

    private List<String> expandPptItems(List<String> items, int maxChars) {
        List<String> result = new ArrayList<>();
        if (items == null) return result;
        for (String item : items) result.addAll(splitPptText(item, maxChars));
        return result;
    }

    private List<String> splitPptText(String value, int maxChars) {
        String text = value == null ? "" : value.replaceAll("\\s+", " ").trim();
        if (text.isBlank()) return List.of();
        if (text.length() <= maxChars) return List.of(text);
        List<String> parts = new ArrayList<>();
        int offset = 0;
        while (offset < text.length()) {
            int target = Math.min(text.length(), offset + maxChars);
            int cut = target;
            if (target < text.length()) {
                int space = text.lastIndexOf(' ', target);
                if (space > offset + maxChars / 2) cut = space;
            }
            String part = text.substring(offset, cut).trim();
            if (!part.isBlank()) parts.add(part);
            offset = cut;
            while (offset < text.length() && Character.isWhitespace(text.charAt(offset))) offset++;
        }
        return parts;
    }

    private List<PptSlideModel> plainTextFallbackSlides(String plain) {
        List<PptSlideModel> slides = new ArrayList<>();
        List<String> items = Arrays.stream((plain == null ? "" : plain).split("\\R+"))
                .map(String::trim)
                .filter(v -> !v.isBlank())
                .map(v -> cleanPptText(v, 135))
                .toList();
        for (int i = 0; i < items.size(); i += 5) {
            slides.add(new PptSlideModel(i == 0 ? "📌 Overview" : "📌 Overview (continued)",
                    items.subList(i, Math.min(i + 5, items.size())), List.of(), List.of(), false, "bullets"));
        }
        if (slides.isEmpty()) slides.add(new PptSlideModel("📌 Overview", List.of("Generated content is ready."), List.of(), List.of(), false, "bullets"));
        return slides;
    }

    private List<List<String>> extractTableRows(Element table) {
        List<List<String>> rows = new ArrayList<>();
        for (Element tr : table.select("tr")) {
            List<String> cells = new ArrayList<>();
            for (Element cell : tr.select("th,td")) cells.add(cleanPptText(cell.text(), 84));
            if (!cells.isEmpty()) rows.add(cells);
        }
        return rows;
    }

    private void addGeneratedTitleSlide(XMLSlideShow ppt, String title, FormattedDocument document, int slideCount) {
        XSLFSlide slide = ppt.createSlide();
        addPptRect(slide, 0, 0, 960, 540, Color.WHITE, null);
        addPptRect(slide, 0, 0, 960, 18, BNP_GREEN, null);
        addPptRect(slide, 0, 512, 960, 28, BNP_GREEN_DARK, null);
        addPptRect(slide, 54, 92, 96, 8, BNP_GREEN, null);
        addPptText(slide, 54, 122, 760, 106, cleanPptText(title, 92), 36, true, BNP_GREEN_DARK, null);
        String subtitle = nonBlank(document.purpose(), "Professional Presentation") + " • " + nonBlank(document.audience(), "General audience");
        addPptText(slide, 58, 238, 760, 34, subtitle, 15, false, BNP_MUTED, null);
        if (slideCount > 0) addPptText(slide, 58, 296, 420, 28, slideCount + " focused slide" + (slideCount == 1 ? "" : "s"), 13, true, BNP_GREEN_TITLE, BNP_MINT);
        addPptRect(slide, 735, 300, 132, 132, BNP_MINT, BNP_BORDER);
        addPptText(slide, 766, 333, 70, 60, "✦", 44, true, BNP_GREEN, null);
        addPptText(slide, 58, 516, 340, 18, "Generated by FormatFlow AI", 9, false, Color.WHITE, null);
    }

    private void addGeneratedContentSlide(XMLSlideShow ppt, PptSlideModel model, int slideNumber) {
        XSLFSlide slide = newSlide(ppt, cleanPptText(model.title(), 84), "NONE");
        addPptText(slide, 852, 37, 52, 24, String.valueOf(slideNumber), 10.5, true, BNP_GREEN, null);
        BnpPresentationLayout layout = selectPresentationLayout(model);
        switch (layout) {
            case AGENDA -> addAgendaSlide(slide, model);
            case EXECUTIVE_OVERVIEW -> addExecutiveOverviewSlide(slide, model);
            case TABLE -> addTableContentSlide(slide, model);
            case CHART -> addNativeChartSlide(ppt, slide, model);
            case DIAGRAM -> addDiagramSlide(slide, model);
            case TWO_COLUMN -> addTwoColumnTopicSlide(slide, model);
            case THREE_CARDS -> addCardGridSlide(slide, model, 3);
            case FOUR_CARDS -> addCardGridSlide(slide, model, 4);
            case COMPARISON -> addComparisonSlide(slide, model);
            case PROCESS_5 -> addProcessSlide(slide, model);
            case CHECKLIST -> addChecklistSlide(slide, model, false);
            case NEXT_STEPS -> addChecklistSlide(slide, model, true);
            case CODE -> addCodeSlide(slide, model);
            case TIMELINE -> addTimelineLayoutSlide(slide, model);
            case KEY_MESSAGE -> addKeyMessageSlide(slide, model);
            default -> addBulletContentSlide(slide, model);
        }
        addPptRect(slide, 54, 501, 852, 1.5, new Color(207, 228, 215), null);
    }

    private void addAgendaSlide(XSLFSlide slide, PptSlideModel model) {
        List<String> bullets = model.bullets().isEmpty() ? List.of("Overview", "Key topics", "Next steps") : model.bullets();
        double y = 112;
        for (int i = 0; i < Math.min(7, bullets.size()); i++) {
            addPptText(slide, 76, y + i * 48, 34, 34, String.valueOf(i + 1), 13, true, Color.WHITE, BNP_GREEN);
            addPptText(slide, 122, y + i * 48, 722, 34, cleanPptText(bullets.get(i), 92), 16.5, false, BNP_TEXT, null);
        }
    }

    /** Screenshot-inspired executive overview: spacious bullets, no decorative card overload. */
    private void addExecutiveOverviewSlide(XSLFSlide slide, PptSlideModel model) {
        List<String> bullets = model.bullets().isEmpty() ? List.of("Key information captured from the source content.") : model.bullets();
        double y = 116;
        for (int i = 0; i < Math.min(5, bullets.size()); i++) {
            String text = cleanPptText(bullets.get(i), 180);
            addPptText(slide, 84, y + i * 58, 20, 28, "•", 18, true, BNP_TEXT, null);
            addPptText(slide, 112, y + i * 58, 742, 44, text, 16.5, false, BNP_TEXT, null);
        }
    }

    private void addTableContentSlide(XSLFSlide slide, PptSlideModel model) {
        List<String> bullets = model.bullets();
        if (!bullets.isEmpty()) addGeneratedBullets(slide, bullets.subList(0, Math.min(2, bullets.size())), 62, 88, 835, 72);
        addGeneratedTable(slide, model.tableRows(), 62, bullets.isEmpty() ? 104 : 176, 835, bullets.isEmpty() ? 358 : 285);
    }


    /**
     * Renders an editable OOXML chart rather than a screenshot. PowerPoint users
     * can open "Edit Data" on the generated chart because Apache POI writes the
     * chart data into the presentation's embedded workbook.
     */
    private void addNativeChartSlide(XMLSlideShow ppt, XSLFSlide slide, PptSlideModel model) {
        if (!hasChartableData(model)) {
            addTableContentSlide(slide, model);
            return;
        }

        BnpPresentationChartType type = chartTypeFor(model);
        boolean hasInsights = model.bullets() != null && !model.bullets().isEmpty();
        double chartX = 62;
        double chartY = 112;
        double chartW = hasInsights ? 610 : 835;
        double chartH = 342;

        addPptRect(slide, chartX - 3, chartY - 3, chartW + 6, chartH + 6, Color.WHITE, BNP_BORDER);
        XSLFChart chart = ppt.createChart();
        slide.addChart(chart, new Rectangle2D.Double(chartX, chartY, chartW, chartH));
        configureNativeChart(chart, model.tableRows(), type);

        if (hasInsights) {
            addPptRect(slide, 694, 112, 202, 342, BNP_MINT, BNP_BORDER);
            addPptText(slide, 712, 130, 166, 30, "Key insights", 14, true, BNP_GREEN_TITLE, null);
            List<String> insights = model.bullets().subList(0, Math.min(2, model.bullets().size()));
            for (int i = 0; i < insights.size(); i++) {
                addPptText(slide, 712, 178 + i * 112, 166, 90,
                        "• " + cleanPptText(insights.get(i), 150), 12.5, false, BNP_TEXT, null);
            }
        }
    }

    private void configureNativeChart(XSLFChart chart, List<List<String>> rows, BnpPresentationChartType type) {
        if (type == BnpPresentationChartType.PIE || type == BnpPresentationChartType.DOUGHNUT) {
            configurePieChart(chart, rows, type);
        } else if (type == BnpPresentationChartType.SCATTER) {
            configureScatterChart(chart, rows);
        } else {
            configureCategoryChart(chart, rows, type);
        }
        chart.setAutoTitleDeleted(true);
    }

    private void configureCategoryChart(XSLFChart chart, List<List<String>> rows, BnpPresentationChartType type) {
        int pointCount = rows.size() - 1;
        String[] categories = new String[pointCount];
        for (int i = 0; i < pointCount; i++) categories[i] = valueAt(rows.get(i + 1), 0);
        String categoryRange = chart.formatRange(new CellRangeAddress(1, pointCount, 0, 0));
        XDDFCategoryDataSource categoryData = XDDFDataSourcesFactory.fromArray(categories, categoryRange, 0);

        XDDFChartAxis bottomAxis = chart.createCategoryAxis(AxisPosition.BOTTOM);
        XDDFValueAxis leftAxis = chart.createValueAxis(AxisPosition.LEFT);
        leftAxis.setCrosses(AxisCrosses.AUTO_ZERO);
        XDDFChartData data = chart.createData(type.poiType(), bottomAxis, leftAxis);

        if (data instanceof XDDFBarChartData bar) {
            bar.setBarGrouping(BarGrouping.CLUSTERED);
            bar.setBarDirection(type == BnpPresentationChartType.BAR ? BarDirection.BAR : BarDirection.COL);
            bar.setVaryColors(false);
        } else if (data instanceof XDDFAreaChartData area) {
            area.setGrouping(Grouping.STANDARD);
            area.setVaryColors(false);
        } else if (data instanceof XDDFRadarChartData radar) {
            radar.setStyle(RadarStyle.MARKER);
            radar.setVaryColors(false);
        } else {
            data.setVaryColors(false);
        }

        List<String> header = rows.get(0);
        for (int col = 1; col < header.size(); col++) {
            if (!columnHasNumericData(rows, col)) continue;
            boolean percent = columnIsPercent(rows, col);
            Double[] values = chartValues(rows, col, percent);
            String valuesRange = chart.formatRange(new CellRangeAddress(1, pointCount, col, col));
            XDDFNumericalDataSource<Double> valuesData = XDDFDataSourcesFactory.fromArray(values, valuesRange, col);
            valuesData.setFormatCode(percent ? "0%" : "General");
            XDDFChartData.Series series = data.addSeries(categoryData, valuesData);
            series.setTitle(nonBlank(valueAt(header, col), "Series " + col), chart.setSheetTitle(nonBlank(valueAt(header, col), "Series " + col), col));
            applyBnpChartSeriesStyle(series, col - 1, type);
        }
        chart.plot(data);
        if (data.getSeriesCount() > 1) addChartLegend(chart);
    }

    private void configurePieChart(XSLFChart chart, List<List<String>> rows, BnpPresentationChartType type) {
        int pointCount = rows.size() - 1;
        String[] categories = new String[pointCount];
        for (int i = 0; i < pointCount; i++) categories[i] = valueAt(rows.get(i + 1), 0);
        String categoryRange = chart.formatRange(new CellRangeAddress(1, pointCount, 0, 0));
        XDDFCategoryDataSource categoryData = XDDFDataSourcesFactory.fromArray(categories, categoryRange, 0);

        int valueCol = firstNumericSeriesColumn(rows);
        boolean percent = columnIsPercent(rows, valueCol);
        Double[] values = chartValues(rows, valueCol, percent);
        String valuesRange = chart.formatRange(new CellRangeAddress(1, pointCount, valueCol, valueCol));
        XDDFNumericalDataSource<Double> valuesData = XDDFDataSourcesFactory.fromArray(values, valuesRange, valueCol);
        valuesData.setFormatCode(percent ? "0%" : "General");

        XDDFChartData data = chart.createData(type.poiType(), null, null);
        data.setVaryColors(true);
        if (data instanceof XDDFDoughnutChartData doughnut) doughnut.setHoleSize(62);
        XDDFChartData.Series series = data.addSeries(categoryData, valuesData);
        String title = nonBlank(valueAt(rows.get(0), valueCol), "Value");
        series.setTitle(title, chart.setSheetTitle(title, valueCol));
        chart.plot(data);
        for (int i = 0; i < pointCount; i++) {
            series.getDataPoint(i).setFillProperties(chartFill(chartPaletteColor(i)));
        }
        addChartLegend(chart);
    }

    private void configureScatterChart(XSLFChart chart, List<List<String>> rows) {
        int pointCount = rows.size() - 1;
        int xCol = 0;
        int yCol = 1;
        boolean xPercent = columnIsPercent(rows, xCol);
        boolean yPercent = columnIsPercent(rows, yCol);
        Double[] xValues = chartValues(rows, xCol, xPercent);
        Double[] yValues = chartValues(rows, yCol, yPercent);
        String xRange = chart.formatRange(new CellRangeAddress(1, pointCount, xCol, xCol));
        String yRange = chart.formatRange(new CellRangeAddress(1, pointCount, yCol, yCol));
        XDDFNumericalDataSource<Double> xData = XDDFDataSourcesFactory.fromArray(xValues, xRange, xCol);
        XDDFNumericalDataSource<Double> yData = XDDFDataSourcesFactory.fromArray(yValues, yRange, yCol);
        xData.setFormatCode(xPercent ? "0%" : "General");
        yData.setFormatCode(yPercent ? "0%" : "General");

        XDDFValueAxis bottomAxis = chart.createValueAxis(AxisPosition.BOTTOM);
        XDDFValueAxis leftAxis = chart.createValueAxis(AxisPosition.LEFT);
        bottomAxis.setCrosses(AxisCrosses.AUTO_ZERO);
        leftAxis.setCrosses(AxisCrosses.AUTO_ZERO);
        XDDFScatterChartData data = (XDDFScatterChartData) chart.createData(ChartTypes.SCATTER, bottomAxis, leftAxis);
        data.setStyle(ScatterStyle.MARKER);
        XDDFScatterChartData.Series series = (XDDFScatterChartData.Series) data.addSeries(xData, yData);
        String title = nonBlank(valueAt(rows.get(0), yCol), "Relationship");
        series.setTitle(title, chart.setSheetTitle(title, yCol));
        series.setMarkerStyle(MarkerStyle.CIRCLE);
        series.setMarkerSize((short) 7);
        applyBnpChartSeriesStyle(series, 0, BnpPresentationChartType.SCATTER);
        chart.plot(data);
    }

    private void addChartLegend(XSLFChart chart) {
        XDDFChartLegend legend = chart.getOrAddLegend();
        legend.setPosition(LegendPosition.BOTTOM);
        legend.setOverlay(false);
    }

    private void applyBnpChartSeriesStyle(XDDFChartData.Series series, int index, BnpPresentationChartType type) {
        XDDFSolidFillProperties fill = chartFill(chartPaletteColor(index));
        if (type == BnpPresentationChartType.LINE || type == BnpPresentationChartType.RADAR
                || type == BnpPresentationChartType.SCATTER) {
            series.setLineProperties(new XDDFLineProperties(fill));
        } else {
            series.setFillProperties(fill);
            series.setLineProperties(new XDDFLineProperties(fill));
        }
    }

    private XDDFSolidFillProperties chartFill(Color color) {
        return new XDDFSolidFillProperties(XDDFColor.from(new byte[]{
                (byte) color.getRed(), (byte) color.getGreen(), (byte) color.getBlue()}));
    }

    private Color chartPaletteColor(int index) {
        Color[] palette = new Color[]{
                BNP_GREEN,
                new Color(44, 164, 98),
                BNP_GREEN_DARK,
                new Color(111, 190, 145),
                new Color(151, 208, 177),
                new Color(77, 137, 107)
        };
        return palette[Math.floorMod(index, palette.length)];
    }

    private boolean columnHasNumericData(List<List<String>> rows, int col) {
        for (int r = 1; r < rows.size(); r++) {
            if (parseChartNumber(valueAt(rows.get(r), col)).isPresent()) return true;
        }
        return false;
    }

    private int firstNumericSeriesColumn(List<List<String>> rows) {
        return numericSeriesColumns(rows).stream().findFirst().orElse(1);
    }

    private Double[] chartValues(List<List<String>> rows, int col, boolean percent) {
        Double[] result = new Double[Math.max(0, rows.size() - 1)];
        for (int r = 1; r < rows.size(); r++) {
            double value = parseChartNumber(valueAt(rows.get(r), col)).orElse(0d);
            result[r - 1] = percent ? value / 100d : value;
        }
        return result;
    }

    private String valueAt(List<String> row, int col) {
        return row != null && col >= 0 && col < row.size() && row.get(col) != null ? row.get(col) : "";
    }

    private void addTwoColumnTopicSlide(XSLFSlide slide, PptSlideModel model) {
        if (!model.bullets().isEmpty()) {
            addPptText(slide, 64, 88, 830, 38, cleanPptText(model.bullets().get(0), 138), 13.5, true, BNP_GREEN_TITLE, BNP_MINT);
        }
        List<PptSubsection> sections = model.subSections();
        double cardW = 392, cardH = 248, gapX = 34;
        double startX = 64, startY = model.bullets().isEmpty() ? 112 : 146;
        for (int i = 0; i < Math.min(2, sections.size()); i++) {
            PptSubsection section = sections.get(i);
            double x = startX + i * (cardW + gapX);
            addPptRect(slide, x, startY, cardW, cardH, Color.WHITE, BNP_BORDER);
            addPptText(slide, x + 18, startY + 14, cardW - 36, 32, cleanPptText(section.title(), 68), 16, true, BNP_GREEN_TITLE, null);
            addCardPoints(slide, section, x + 20, startY + 58, cardW - 40, 3, 48);
        }
    }

    /**
     * Predefined BNP-green card layouts. Three cards intentionally use a 2+1
     * composition like the user's reference deck; four cards use a balanced 2x2.
     */
    private void addCardGridSlide(XSLFSlide slide, PptSlideModel model, int requestedCards) {
        if (!model.bullets().isEmpty()) {
            addPptText(slide, 64, 86, 830, 38, cleanPptText(model.bullets().get(0), 138), 13.5, true, BNP_GREEN_TITLE, BNP_MINT);
        }
        List<PptSubsection> sections = model.subSections();
        double top = model.bullets().isEmpty() ? 104 : 144;
        if (requestedCards == 3) {
            double w = 370, h = 142, gap = 38;
            for (int i = 0; i < Math.min(2, sections.size()); i++) {
                drawCard(slide, sections.get(i), 74 + i * (w + gap), top, w, h);
            }
            if (sections.size() > 2) drawCard(slide, sections.get(2), 250, top + 168, 460, 142);
            return;
        }
        double w = 372, h = 142, gapX = 38, gapY = 24;
        for (int i = 0; i < Math.min(4, sections.size()); i++) {
            int row = i / 2, col = i % 2;
            drawCard(slide, sections.get(i), 74 + col * (w + gapX), top + row * (h + gapY), w, h);
        }
    }

    private void drawCard(XSLFSlide slide, PptSubsection section, double x, double y, double w, double h) {
        addPptRect(slide, x, y, w, h, Color.WHITE, BNP_BORDER);
        addPptText(slide, x + 16, y + 12, w - 32, 28, cleanPptText(section.title(), 72), 15.5, true, BNP_GREEN_TITLE, null);
        addCardPoints(slide, section, x + 18, y + 49, w - 36, 3, 28);
    }

    private void addCardPoints(XSLFSlide slide, PptSubsection section, double x, double y, double w, int maxPoints, double lineGap) {
        List<String> points = section.bullets().isEmpty() ? List.of("Key point captured from the source content.") : section.bullets();
        for (int j = 0; j < Math.min(maxPoints, points.size()); j++) {
            addPptText(slide, x, y + j * lineGap, w, lineGap - 2, "• " + cleanPptText(points.get(j), 92), 11.5, false, BNP_TEXT, null);
        }
    }

    private void addComparisonSlide(XSLFSlide slide, PptSlideModel model) {
        List<PptSubsection> sections = model.subSections();
        if (sections.size() < 2) {
            addTwoColumnTopicSlide(slide, model);
            return;
        }
        double y = 122, w = 384, h = 284;
        for (int i = 0; i < 2; i++) {
            double x = 68 + i * 430;
            addPptRect(slide, x, y, w, h, Color.WHITE, BNP_BORDER);
            addPptText(slide, x, y, w, 46, cleanPptText(sections.get(i).title(), 72), 17, true, Color.WHITE,
                    i == 0 ? BNP_GREEN_DARK : BNP_GREEN);
            addCardPoints(slide, sections.get(i), x + 18, y + 64, w - 36, 5, 42);
        }
    }

    private void addProcessSlide(XSLFSlide slide, PptSlideModel model) {
        List<String> steps = model.bullets().isEmpty() ? List.of("Understand", "Prepare", "Execute", "Review") : model.bullets();
        int count = Math.min(5, steps.size());
        double startX = 54, y = 176, boxW = count <= 4 ? 176 : 154, gap = count <= 4 ? 40 : 24;
        for (int i = 0; i < count; i++) {
            double x = startX + i * (boxW + gap);
            addPptText(slide, x, y - 46, 40, 34, String.valueOf(i + 1), 14, true, Color.WHITE, BNP_GREEN);
            addPptRect(slide, x, y, boxW, 132, Color.WHITE, BNP_BORDER);
            addPptText(slide, x + 12, y + 18, boxW - 24, 94, cleanPptText(steps.get(i), 110), 12.5, true, BNP_TEXT, null);
            if (i < count - 1) addPptText(slide, x + boxW + 1, y + 43, gap - 2, 38, "→", 22, true, BNP_GREEN, null);
        }
    }

    private void addDiagramSlide(XSLFSlide slide, PptSlideModel model) {
        BnpPresentationDiagramType type = diagramTypeFor(model);
        switch (type) {
            case LINEAR_PROCESS -> addLinearProcessDiagram(slide, model, false);
            case CHEVRON_PROCESS -> addLinearProcessDiagram(slide, model, true);
            case CYCLE -> addCycleDiagram(slide, model, false);
            case SWIMLANE -> addSwimlaneDiagram(slide, model);
            case HIERARCHY -> addHierarchyDiagram(slide, model);
            case HUB_SPOKE -> addHubSpokeDiagram(slide, model);
            case PIPELINE -> addPipelineDiagram(slide, model);
            case ARCHITECTURE_FLOW -> addArchitectureDiagram(slide, model);
            case FUNNEL -> addFunnelDiagram(slide, model);
            case PYRAMID -> addPyramidDiagram(slide, model);
            case MATRIX_2X2 -> addMatrixDiagram(slide, model);
            case DECISION_TREE -> addDecisionTreeDiagram(slide, model);
            case FEEDBACK_LOOP -> addCycleDiagram(slide, model, true);
            case CONVERGING_FLOW -> addConvergingDiagram(slide, model);
            case DIVERGING_FLOW -> addDivergingDiagram(slide, model);
            case BEFORE_AFTER -> addBeforeAfterDiagram(slide, model);
            case COMPARISON_FLOW -> addComparisonFlowDiagram(slide, model);
            case ROADMAP -> addRoadmapDiagram(slide, model);
            case NONE -> addLinearProcessDiagram(slide, model, false);
        }
    }

    private List<String> diagramItems(PptSlideModel model) {
        List<String> items = new ArrayList<>();
        if (model.bullets() != null) items.addAll(model.bullets());
        for (PptSubsection subsection : model.subSections()) {
            if (subsection.bullets().isEmpty()) items.add(subsection.title());
            else for (String point : subsection.bullets()) items.add(subsection.title() + ": " + point);
        }
        return items.isEmpty() ? List.of(stripLeadingPresentationIcon(model.title())) : items;
    }

    private void addLinearProcessDiagram(XSLFSlide slide, PptSlideModel model, boolean chevrons) {
        List<String> items = diagramItems(model);
        int count = Math.min(6, items.size());
        double startX = 58, y = 190, totalW = 844, gap = chevrons ? 6 : 24;
        double nodeW = (totalW - gap * (count - 1)) / count;
        for (int i = 0; i < count; i++) {
            double x = startX + i * (nodeW + gap);
            if (chevrons) {
                addDiagramShape(slide, ShapeType.CHEVRON, x, y, nodeW, 112,
                        i % 2 == 0 ? BNP_GREEN : new Color(44, 164, 98), BNP_GREEN_DARK);
                addPptText(slide, x + 13, y + 24, nodeW - 28, 66, cleanPptText(items.get(i), 105),
                        count > 5 ? 10.5 : 11.5, true, Color.WHITE, null);
            } else {
                addDiagramShape(slide, ShapeType.RECT, x, y, nodeW, 112, Color.WHITE, BNP_BORDER);
                addPptText(slide, x + 12, y + 14, 30, 26, String.valueOf(i + 1), 11, true, Color.WHITE, BNP_GREEN);
                addPptText(slide, x + 12, y + 48, nodeW - 24, 50, cleanPptText(items.get(i), 105),
                        count > 5 ? 10.5 : 11.5, true, BNP_TEXT, null);
                if (i < count - 1) addDiagramShape(slide, ShapeType.RIGHT_ARROW,
                        x + nodeW + 3, y + 43, Math.max(16, gap - 6), 24, BNP_GREEN, BNP_GREEN);
            }
        }
    }

    private void addCycleDiagram(XSLFSlide slide, PptSlideModel model, boolean feedback) {
        List<String> items = diagramItems(model);
        if (items.size() < 3) {
            addBulletContentSlide(slide, model);
            return;
        }
        int count = Math.min(6, items.size());
        double cx = 480, cy = 284, rx = 270, ry = 145;
        for (int i = 0; i < count; i++) {
            double angle = -Math.PI / 2 + i * (2 * Math.PI / count);
            double x = cx + Math.cos(angle) * rx - 70;
            double y = cy + Math.sin(angle) * ry - 34;
            addDiagramShape(slide, ShapeType.ELLIPSE, x, y, 140, 68,
                    i % 2 == 0 ? BNP_MINT : Color.WHITE, BNP_GREEN);
            addPptText(slide, x + 10, y + 13, 120, 42, cleanPptText(items.get(Math.min(i, items.size() - 1)), 90),
                    10.8, true, BNP_TEXT, null);
        }
        addDiagramShape(slide, ShapeType.ELLIPSE, cx - 62, cy - 58, 124, 116, BNP_GREEN_DARK, BNP_GREEN_DARK);
        addPptText(slide, cx - 52, cy - 27, 104, 55, feedback ? "↻\nFeedback" : "↻\nCycle",
                16, true, Color.WHITE, null);
    }

    private void addSwimlaneDiagram(XSLFSlide slide, PptSlideModel model) {
        List<PptSubsection> lanes = model.subSections();
        if (lanes.isEmpty()) {
            addLinearProcessDiagram(slide, model, false);
            return;
        }
        int count = Math.min(4, lanes.size());
        double top = 112, laneH = 82;
        for (int i = 0; i < count; i++) {
            PptSubsection lane = lanes.get(i);
            double y = top + i * laneH;
            addPptRect(slide, 62, y, 140, laneH - 8, i % 2 == 0 ? BNP_GREEN_DARK : BNP_GREEN, null);
            addPptText(slide, 74, y + 17, 116, 42, cleanPptText(lane.title(), 56), 12, true, Color.WHITE, null);
            addPptRect(slide, 202, y, 688, laneH - 8, i % 2 == 0 ? BNP_SURFACE : Color.WHITE, BNP_BORDER);
            List<String> steps = lane.bullets();
            int n = Math.min(3, steps.size());
            if (n == 0) continue;
            double cellW = 640.0 / n;
            for (int j = 0; j < n; j++) {
                double x = 226 + j * cellW;
                addPptText(slide, x, y + 15, cellW - 20, 44, cleanPptText(steps.get(j), 84), 10.8, true, BNP_TEXT, null);
                if (j < n - 1) addPptText(slide, x + cellW - 18, y + 19, 22, 32, "→", 15, true, BNP_GREEN, null);
            }
        }
    }

    private void addHierarchyDiagram(XSLFSlide slide, PptSlideModel model) {
        List<PptSubsection> branches = model.subSections();
        String root = !model.bullets().isEmpty() ? model.bullets().get(0) : stripLeadingPresentationIcon(model.title());
        addPptRect(slide, 342, 116, 276, 62, BNP_GREEN_DARK, BNP_GREEN_DARK);
        addPptText(slide, 360, 132, 240, 34, cleanPptText(root, 100), 14, true, Color.WHITE, null);
        if (branches.isEmpty()) {
            List<String> items = diagramItems(model);
            if (items.size() <= 1) {
                addBulletContentSlide(slide, model);
                return;
            }
            branches = items.stream().skip(1).limit(4).map(v -> new PptSubsection(v, List.of())).toList();
        }
        int count = Math.min(4, branches.size());
        double startX = 70, y = 286, w = 190, gap = count <= 1 ? 0 : (820 - w * count) / (count - 1);
        addPptRect(slide, 478, 178, 4, 70, BNP_BORDER, null);
        if (count > 1) addPptRect(slide, startX + w / 2, 246, (count - 1) * (w + gap), 4, BNP_BORDER, null);
        for (int i = 0; i < count; i++) {
            double x = startX + i * (w + gap);
            addPptRect(slide, x + w / 2 - 2, 246, 4, 40, BNP_BORDER, null);
            PptSubsection branch = branches.get(i);
            addPptRect(slide, x, y, w, 112, Color.WHITE, BNP_GREEN);
            addPptText(slide, x + 12, y + 12, w - 24, 28, cleanPptText(branch.title(), 60), 12, true, BNP_GREEN_TITLE, null);
            if (!branch.bullets().isEmpty()) addPptText(slide, x + 12, y + 45, w - 24, 54,
                    cleanPptText(String.join(" • ", branch.bullets()), 110), 9.8, false, BNP_TEXT, null);
        }
    }

    private void addHubSpokeDiagram(XSLFSlide slide, PptSlideModel model) {
        List<String> items = diagramItems(model);
        String hub = !model.bullets().isEmpty() ? model.bullets().get(0) : stripLeadingPresentationIcon(model.title());
        List<String> spokes = items.size() > 1 ? items.subList(1, items.size()) : List.of();
        if (spokes.size() < 2) {
            addBulletContentSlide(slide, model);
            return;
        }
        int count = Math.min(6, spokes.size());
        double cx = 480, cy = 284, rx = 285, ry = 145;
        addDiagramShape(slide, ShapeType.ELLIPSE, cx - 88, cy - 52, 176, 104, BNP_GREEN_DARK, BNP_GREEN_DARK);
        addPptText(slide, cx - 72, cy - 24, 144, 50, cleanPptText(hub, 80), 13, true, Color.WHITE, null);
        for (int i = 0; i < count; i++) {
            double angle = -Math.PI / 2 + i * (2 * Math.PI / count);
            double x = cx + Math.cos(angle) * rx - 75;
            double y = cy + Math.sin(angle) * ry - 32;
            addDiagramShape(slide, ShapeType.ELLIPSE, x, y, 150, 64, i % 2 == 0 ? BNP_MINT : Color.WHITE, BNP_GREEN);
            addPptText(slide, x + 10, y + 12, 130, 40, cleanPptText(spokes.get(i), 76), 10.5, true, BNP_TEXT, null);
        }
    }

    private void addPipelineDiagram(XSLFSlide slide, PptSlideModel model) {
        List<String> items = diagramItems(model);
        if (items.size() < 3) {
            addBulletContentSlide(slide, model);
            return;
        }
        int count = Math.min(5, items.size());
        double x = 68, y = 180, w = 150, h = 126, gap = 22;
        for (int i = 0; i < count; i++) {
            addPptRect(slide, x + i * (w + gap), y, w, h,
                    i % 2 == 0 ? BNP_SURFACE : BNP_MINT, BNP_GREEN);
            addPptText(slide, x + i * (w + gap) + 12, y + 16, w - 24, 28, "Stage " + (i + 1), 10.5, true, BNP_GREEN_TITLE, null);
            addPptText(slide, x + i * (w + gap) + 12, y + 51, w - 24, 58, cleanPptText(items.get(i), 100), 11.2, true, BNP_TEXT, null);
            if (i < count - 1) addDiagramShape(slide, ShapeType.RIGHT_ARROW,
                    x + i * (w + gap) + w + 3, y + 48, Math.max(14, gap - 6), 22, BNP_GREEN, BNP_GREEN);
        }
    }

    private void addArchitectureDiagram(XSLFSlide slide, PptSlideModel model) {
        List<String> items = diagramItems(model);
        if (items.size() < 3) {
            addBulletContentSlide(slide, model);
            return;
        }
        int count = Math.min(5, items.size());
        double[][] positions = {{70,150},{275,150},{480,150},{685,150},{377,320}};
        for (int i = 0; i < count; i++) {
            double x = positions[i][0], y = positions[i][1];
            addPptRect(slide, x, y, 170, 84, i == count - 1 && count == 5 ? BNP_MINT : Color.WHITE, BNP_GREEN);
            addPptText(slide, x + 12, y + 20, 146, 46, cleanPptText(items.get(i), 88), 11.2, true, BNP_TEXT, null);
            if (i < Math.min(3, count - 1)) addDiagramShape(slide, ShapeType.RIGHT_ARROW,
                    x + 176, y + 30, 24, 22, BNP_GREEN, BNP_GREEN);
        }
        if (count == 5) {
            addPptText(slide, 458, 246, 42, 50, "↓", 22, true, BNP_GREEN, null);
        }
    }

    private void addFunnelDiagram(XSLFSlide slide, PptSlideModel model) {
        List<String> items = diagramItems(model);
        if (items.size() < 3) {
            addBulletContentSlide(slide, model);
            return;
        }
        int count = Math.min(5, items.size());
        double center = 480, y = 118, h = 62;
        for (int i = 0; i < count; i++) {
            double w = 690 - i * 105;
            double x = center - w / 2;
            addPptRect(slide, x, y + i * 68, w, h,
                    i % 2 == 0 ? BNP_GREEN : new Color(44, 164, 98), Color.WHITE);
            addPptText(slide, x + 20, y + i * 68 + 15, w - 40, 32, cleanPptText(items.get(i), 105),
                    11.5, true, Color.WHITE, null);
        }
    }

    private void addPyramidDiagram(XSLFSlide slide, PptSlideModel model) {
        List<String> items = diagramItems(model);
        if (items.size() < 3) {
            addBulletContentSlide(slide, model);
            return;
        }
        int count = Math.min(5, items.size());
        double center = 480, baseY = 410, h = 55;
        for (int i = 0; i < count; i++) {
            int sourceIndex = count - 1 - i;
            double w = 250 + i * 100;
            double x = center - w / 2;
            double y = baseY - i * 60;
            addPptRect(slide, x, y, w, h,
                    i % 2 == 0 ? BNP_MINT : BNP_SURFACE, BNP_GREEN);
            addPptText(slide, x + 18, y + 12, w - 36, 30, cleanPptText(items.get(sourceIndex), 100),
                    11, true, BNP_TEXT, null);
        }
    }

    private void addMatrixDiagram(XSLFSlide slide, PptSlideModel model) {
        List<PptSubsection> quadrants = model.subSections();
        if (quadrants.size() < 4) {
            List<String> items = diagramItems(model);
            quadrants = new ArrayList<>();
            for (int i = 0; i < Math.min(4, items.size()); i++) quadrants.add(new PptSubsection(items.get(i), List.of()));
        }
        double x0 = 170, y0 = 120, w = 300, h = 155, gap = 8;
        for (int i = 0; i < Math.min(4, quadrants.size()); i++) {
            int row = i / 2, col = i % 2;
            double x = x0 + col * (w + gap), y = y0 + row * (h + gap);
            addPptRect(slide, x, y, w, h, i % 2 == 0 ? BNP_MINT : Color.WHITE, BNP_GREEN);
            PptSubsection q = quadrants.get(i);
            addPptText(slide, x + 16, y + 14, w - 32, 30, cleanPptText(q.title(), 70), 13, true, BNP_GREEN_TITLE, null);
            if (!q.bullets().isEmpty()) addPptText(slide, x + 16, y + 52, w - 32, 82,
                    "• " + cleanPptText(String.join("\n• ", q.bullets()), 150), 10.5, false, BNP_TEXT, null);
        }
        addPptText(slide, 68, 245, 90, 28, "High ↑", 10, true, BNP_MUTED, null);
        addPptText(slide, 430, 446, 120, 28, "→ Higher", 10, true, BNP_MUTED, null);
    }

    private void addDecisionTreeDiagram(XSLFSlide slide, PptSlideModel model) {
        List<PptSubsection> nodes = model.subSections();
        String decision = !model.bullets().isEmpty() ? model.bullets().get(0)
                : !nodes.isEmpty() ? nodes.get(0).title() : "Decision";
        addDiagramShape(slide, ShapeType.DIAMOND, 390, 116, 180, 112, BNP_MINT, BNP_GREEN);
        addPptText(slide, 418, 148, 124, 48, cleanPptText(decision, 80), 11.5, true, BNP_TEXT, null);
        List<PptSubsection> outcomes = nodes.isEmpty()
                ? diagramItems(model).stream().skip(1).limit(4).map(v -> new PptSubsection(v, List.of())).toList()
                : nodes.stream().filter(n -> !n.title().equals(decision)).limit(4).toList();
        if (outcomes.isEmpty()) {
            addBulletContentSlide(slide, model);
            return;
        }
        int count = Math.min(4, outcomes.size());
        double startX = 76, y = 318, w = 190, gap = count <= 1 ? 0 : (808 - w * count) / (count - 1);
        for (int i = 0; i < count; i++) {
            double x = startX + i * (w + gap);
            PptSubsection out = outcomes.get(i);
            addPptText(slide, x + 70, 252, 50, 26, i % 2 == 0 ? "Yes" : "No", 9.5, true, BNP_GREEN_TITLE, BNP_MINT);
            addPptRect(slide, x, y, w, 94, Color.WHITE, BNP_GREEN);
            addPptText(slide, x + 12, y + 12, w - 24, 28, cleanPptText(out.title(), 60), 11.5, true, BNP_GREEN_TITLE, null);
            if (!out.bullets().isEmpty()) addPptText(slide, x + 12, y + 45, w - 24, 36,
                    cleanPptText(String.join("; ", out.bullets()), 90), 9.5, false, BNP_TEXT, null);
        }
    }

    private void addConvergingDiagram(XSLFSlide slide, PptSlideModel model) {
        List<String> items = diagramItems(model);
        if (items.size() < 3) {
            addBulletContentSlide(slide, model);
            return;
        }
        int sourceCount = Math.min(4, items.size() - 1);
        String outcome = items.get(items.size() - 1);
        for (int i = 0; i < sourceCount; i++) {
            double y = 118 + i * 82;
            addPptRect(slide, 78, y, 250, 58, i % 2 == 0 ? BNP_MINT : Color.WHITE, BNP_GREEN);
            addPptText(slide, 92, y + 12, 222, 34, cleanPptText(items.get(i), 78), 10.8, true, BNP_TEXT, null);
            addPptText(slide, 344, y + 8, 90, 40, "↘", 19, true, BNP_GREEN, null);
        }
        addPptRect(slide, 552, 205, 290, 116, BNP_GREEN_DARK, BNP_GREEN_DARK);
        addPptText(slide, 578, 238, 238, 52, cleanPptText(outcome, 90), 14, true, Color.WHITE, null);
    }

    private void addDivergingDiagram(XSLFSlide slide, PptSlideModel model) {
        List<String> items = diagramItems(model);
        String source = items.get(0);
        addPptRect(slide, 104, 205, 270, 116, BNP_GREEN_DARK, BNP_GREEN_DARK);
        addPptText(slide, 128, 238, 222, 52, cleanPptText(source, 90), 14, true, Color.WHITE, null);
        List<String> outputs = items.size() > 1 ? items.subList(1, items.size()) : List.of();
        if (outputs.size() < 2) {
            addBulletContentSlide(slide, model);
            return;
        }
        int count = Math.min(4, outputs.size());
        for (int i = 0; i < count; i++) {
            double y = 116 + i * 82;
            addPptText(slide, 400, y + 8, 80, 40, "↗", 19, true, BNP_GREEN, null);
            addPptRect(slide, 548, y, 290, 58, i % 2 == 0 ? BNP_MINT : Color.WHITE, BNP_GREEN);
            addPptText(slide, 566, y + 12, 254, 34, cleanPptText(outputs.get(i), 80), 10.8, true, BNP_TEXT, null);
        }
    }

    private void addBeforeAfterDiagram(XSLFSlide slide, PptSlideModel model) {
        List<PptSubsection> sides = model.subSections();
        if (sides.size() < 2) {
            List<String> items = diagramItems(model);
            if (items.size() < 2) {
                addBulletContentSlide(slide, model);
                return;
            }
            sides = List.of(new PptSubsection("Before", List.of(items.get(0))),
                    new PptSubsection("After", List.of(items.get(1))));
        }
        drawBeforeAfterPanel(slide, sides.get(0), 70, "Before", BNP_SURFACE);
        addPptText(slide, 447, 228, 66, 64, "→", 30, true, BNP_GREEN, null);
        drawBeforeAfterPanel(slide, sides.get(1), 535, "After", BNP_MINT);
    }

    private void drawBeforeAfterPanel(XSLFSlide slide, PptSubsection section, double x, String fallbackTitle, Color fill) {
        addPptRect(slide, x, 142, 350, 260, fill, BNP_GREEN);
        addPptText(slide, x + 20, 160, 310, 36, nonBlank(section.title(), fallbackTitle), 16, true, BNP_GREEN_TITLE, null);
        List<String> points = section.bullets().isEmpty() ? List.of(section.title()) : section.bullets();
        for (int i = 0; i < Math.min(4, points.size()); i++) {
            addPptText(slide, x + 24, 216 + i * 44, 300, 34, "• " + cleanPptText(points.get(i), 100), 11.2, false, BNP_TEXT, null);
        }
    }

    private void addComparisonFlowDiagram(XSLFSlide slide, PptSlideModel model) {
        List<PptSubsection> lanes = model.subSections();
        if (lanes.size() < 2) {
            addBeforeAfterDiagram(slide, model);
            return;
        }
        for (int i = 0; i < 2; i++) {
            PptSubsection lane = lanes.get(i);
            double y = 132 + i * 158;
            addPptRect(slide, 70, y, 170, 112, i == 0 ? BNP_GREEN_DARK : BNP_GREEN, null);
            addPptText(slide, 88, y + 35, 134, 42, cleanPptText(lane.title(), 60), 13, true, Color.WHITE, null);
            List<String> steps = lane.bullets();
            int n = Math.min(3, steps.size());
            double w = 180;
            for (int j = 0; j < n; j++) {
                double x = 282 + j * 202;
                addPptRect(slide, x, y + 12, w, 88, i == 0 ? BNP_SURFACE : BNP_MINT, BNP_GREEN);
                addPptText(slide, x + 12, y + 31, w - 24, 48, cleanPptText(steps.get(j), 80), 10.5, true, BNP_TEXT, null);
                if (j < n - 1) addDiagramShape(slide, ShapeType.RIGHT_ARROW,
                        x + w + 5, y + 43, 20, 20, BNP_GREEN, BNP_GREEN);
            }
        }
    }

    private void addRoadmapDiagram(XSLFSlide slide, PptSlideModel model) {
        List<String> items = diagramItems(model);
        if (items.size() < 3) {
            addBulletContentSlide(slide, model);
            return;
        }
        int count = Math.min(6, items.size());
        double startX = 86, endX = 874, y = 300;
        addPptRect(slide, startX, y, endX - startX, 5, BNP_BORDER, null);
        double step = count <= 1 ? 0 : (endX - startX) / (count - 1);
        for (int i = 0; i < count; i++) {
            double x = startX + i * step;
            addDiagramShape(slide, ShapeType.ELLIPSE, x - 14, y - 12, 29, 29, BNP_GREEN, BNP_GREEN);
            addPptText(slide, x - 62, i % 2 == 0 ? 156 : 330, 124, 92,
                    cleanPptText(items.get(i), 94), 10.5, true, BNP_TEXT, i % 2 == 0 ? BNP_MINT : BNP_SURFACE);
        }
    }

    private XSLFAutoShape addDiagramShape(XSLFSlide slide, ShapeType type, double x, double y, double w, double h,
                                           Color fill, Color line) {
        XSLFAutoShape shape = slide.createAutoShape();
        shape.setShapeType(type);
        shape.setAnchor(new Rectangle2D.Double(x, y, w, h));
        if (fill != null) shape.setFillColor(fill);
        if (line != null) shape.setLineColor(line);
        return shape;
    }

    private void addChecklistSlide(XSLFSlide slide, PptSlideModel model, boolean nextSteps) {
        List<String> items = model.bullets().isEmpty() ? List.of("Key information captured from the source content.") : model.bullets();
        double y = 112;
        for (int i = 0; i < Math.min(6, items.size()); i++) {
            addPptRect(slide, 78, y + i * 52, 24, 24, nextSteps ? BNP_GREEN : Color.WHITE, BNP_GREEN);
            if (nextSteps) addPptText(slide, 78, y + i * 52 - 1, 24, 24, "✓", 12, true, Color.WHITE, null);
            addPptText(slide, 118, y + i * 52 - 5, 736, 38, cleanPptText(items.get(i), 160), 15.5, false, BNP_TEXT, null);
        }
    }

    private void addCodeSlide(XSLFSlide slide, PptSlideModel model) {
        String code = model.bullets().isEmpty() ? "" : model.bullets().get(0);
        addPptRect(slide, 66, 105, 828, 342, new Color(249, 251, 250), BNP_BORDER);
        XSLFTextBox box = slide.createTextBox();
        box.setAnchor(new Rectangle2D.Double(82, 122, 796, 310));
        box.setTopInset(8); box.setBottomInset(8); box.setLeftInset(10); box.setRightInset(10);
        box.setTextAutofit(TextShape.TextAutofit.NORMAL);
        box.clearText();
        String[] lines = code.replace("\r", "").split("\n", -1);
        for (String line : lines) {
            XSLFTextParagraph paragraph = box.addNewTextParagraph();
            paragraph.setSpaceAfter(0d);
            XSLFTextRun run = paragraph.addNewTextRun();
            run.setText(line);
            run.setFontFamily("Consolas");
            run.setFontSize(12d);
            run.setFontColor(BNP_TEXT);
        }
    }

    private void addTimelineLayoutSlide(XSLFSlide slide, PptSlideModel model) {
        List<String> items = model.bullets().isEmpty() ? List.of("Milestone") : model.bullets();
        int count = Math.min(5, items.size());
        double startX = 92, endX = 866, y = 254;
        addPptRect(slide, startX, y, endX - startX, 3, BNP_BORDER, null);
        double step = count <= 1 ? 0 : (endX - startX) / (count - 1);
        for (int i = 0; i < count; i++) {
            double x = startX + i * step;
            XSLFAutoShape circle = slide.createAutoShape();
            circle.setShapeType(ShapeType.ELLIPSE);
            circle.setAnchor(new Rectangle2D.Double(x - 12, y - 11, 25, 25));
            circle.setFillColor(BNP_GREEN); circle.setLineColor(BNP_GREEN);
            addPptText(slide, x - 58, i % 2 == 0 ? y - 118 : y + 35, 116, 76,
                    cleanPptText(items.get(i), 95), 12, true, BNP_TEXT, null);
        }
    }

    private void addKeyMessageSlide(XSLFSlide slide, PptSlideModel model) {
        List<String> bullets = model.bullets().isEmpty() ? List.of("Key information captured from the source content.") : model.bullets();
        addPptText(slide, 72, 132, 790, 118, cleanPptText(bullets.get(0), 190), 28, true, BNP_GREEN_DARK, null);
        addPptRect(slide, 72, 262, 92, 5, BNP_GREEN, null);
        if (bullets.size() > 1) {
            List<String> secondary = bullets.subList(1, Math.min(4, bullets.size()));
            addGeneratedBullets(slide, secondary, 86, 292, 760, 120);
        }
    }

    private void addBulletContentSlide(XSLFSlide slide, PptSlideModel model) {
        addGeneratedBullets(slide, model.bullets(), 74, 112, 800, 338);
    }

    private void addGeneratedBullets(XSLFSlide slide, List<String> bullets, double x, double y, double w, double h) {
        XSLFTextBox box = slide.createTextBox();
        box.setAnchor(new Rectangle2D.Double(x, y, w, h));
        box.setTopInset(4); box.setBottomInset(4); box.setLeftInset(4); box.setRightInset(4);
        box.setTextAutofit(TextShape.TextAutofit.NORMAL);
        box.clearText();
        List<String> safeBullets = bullets == null || bullets.isEmpty() ? List.of("Key information captured from the source content.") : bullets;
        int shown = Math.min(6, safeBullets.size());
        double size = shown <= 3 ? 18 : shown <= 5 ? 15.5 : 14;
        for (int i = 0; i < shown; i++) {
            XSLFTextParagraph p = box.addNewTextParagraph();
            p.setSpaceAfter(8d);
            XSLFTextRun run = p.addNewTextRun();
            run.setText("• " + cleanPptText(safeBullets.get(i), 145));
            run.setFontFamily("Arial");
            run.setFontSize(size);
            run.setFontColor(new Color(31, 45, 37));
        }
    }

    private void addGeneratedTable(XSLFSlide slide, List<List<String>> rows, double x, double y, double w, double h) {
        if (rows == null || rows.isEmpty()) return;
        int cols = rows.stream().mapToInt(List::size).max().orElse(2);
        cols = Math.max(1, Math.min(cols, 5));
        int rowCount = Math.min(rows.size(), 9);
        double cellW = w / cols;
        double rowH = Math.min(39, h / Math.max(2, rowCount));
        for (int r = 0; r < rowCount; r++) {
            List<String> row = rows.get(r);
            for (int c = 0; c < cols; c++) {
                String value = c < row.size() ? row.get(c) : "";
                boolean header = r == 0;
                XSLFTextBox cell = addPptText(slide, x + c * cellW, y + r * rowH, cellW, rowH,
                        value, header ? 11.5 : 10.2, header, header ? Color.WHITE : new Color(31, 45, 37),
                        header ? new Color(0, 107, 54) : (r % 2 == 0 ? Color.WHITE : new Color(247, 251, 248)));
                cell.setLineColor(new Color(185, 215, 197));
            }
        }
    }

    private void addPptRect(XSLFSlide slide, double x, double y, double w, double h, Color fill, Color line) {
        XSLFAutoShape shape = slide.createAutoShape();
        shape.setShapeType(ShapeType.RECT);
        shape.setAnchor(new Rectangle2D.Double(x, y, w, h));
        if (fill != null) shape.setFillColor(fill);
        shape.setLineColor(line == null ? fill : line);
    }

    private String firstText(Elements elements) {
        for (Element element : elements) {
            String text = element.text();
            if (text != null && !text.isBlank()) return text.trim();
        }
        return "";
    }

    private String nonBlank(String... values) {
        for (String value : values) if (value != null && !value.isBlank()) return value.trim();
        return "";
    }

    private String cleanPptText(String value, int maxChars) {
        // Do not silently remove source content. Pagination happens before render
        // and text boxes use PowerPoint autofit as a final visual safety net.
        return value == null ? "" : value.replaceAll("\\s+", " ").trim();
    }

    private String normalizedTitle(String value) {
        return stripLeadingPresentationIcon(value).toLowerCase(Locale.ROOT);
    }

    private String stripLeadingPresentationIcon(String value) {
        String text = value == null ? "" : value.trim();
        return text.replaceFirst("^[\\p{So}\\p{Cn}\\p{Sk}\\p{Sm}\\uFE0F\\s]+", "").trim();
    }

    private boolean hasLeadingPresentationIcon(String value) {
        if (value == null || value.isBlank()) return false;
        int cp = value.trim().codePointAt(0);
        int type = Character.getType(cp);
        return type == Character.OTHER_SYMBOL || type == Character.MATH_SYMBOL || type == Character.MODIFIER_SYMBOL;
    }

    private record PptSubsection(String title, List<String> bullets) {}

    private record PptSlideModel(String title,
                                 List<String> bullets,
                                 List<List<String>> tableRows,
                                 List<PptSubsection> subSections,
                                 boolean titleSlide,
                                 String layoutHint) {}

    private static final class MutablePptSubsection {
        private final String title;
        private final List<String> bullets = new ArrayList<>();
        private MutablePptSubsection(String title) { this.title = title == null || title.isBlank() ? "Topic" : title; }
        private PptSubsection freeze() { return new PptSubsection(title, List.copyOf(bullets)); }
    }

    private static final class MutablePptSlide {
        private final String title;
        private final List<String> bullets = new ArrayList<>();
        private final List<MutablePptSubsection> subSections = new ArrayList<>();
        private MutablePptSubsection currentSubsection;
        private List<List<String>> tableRows = List.of();
        private String layoutHint = "";

        private MutablePptSlide(String title) { this(title, ""); }
        private MutablePptSlide(String title, String layoutHint) {
            this.title = title == null || title.isBlank() ? "📌 Topic" : title;
            this.layoutHint = layoutHint == null ? "" : layoutHint.trim();
        }
        private void startSubsection(String value) {
            currentSubsection = new MutablePptSubsection(value);
            subSections.add(currentSubsection);
            if (layoutHint.isBlank()) layoutHint = "two-column";
        }
        private void addBullet(String value) {
            if (value == null || value.isBlank()) return;
            if (currentSubsection != null) currentSubsection.bullets.add(value);
            else bullets.add(value);
        }
        private void addTakeaway(String value) {
            if (value == null || value.isBlank()) return;
            bullets.add(0, "💡 " + value);
            if (layoutHint.isBlank()) layoutHint = "KEY_MESSAGE";
        }
        private void addCode(String value) {
            if (value == null || value.isBlank()) return;
            bullets.add(value.strip());
            currentSubsection = null;
            layoutHint = "CODE";
        }
        private void addTable(List<List<String>> rows) {
            if (rows != null && !rows.isEmpty()) {
                tableRows = rows;
                currentSubsection = null;
                if (layoutHint.isBlank()) layoutHint = "TABLE";
            }
        }
        private PptSlideModel freeze() {
            return new PptSlideModel(title, List.copyOf(bullets), tableRows,
                    subSections.stream().map(MutablePptSubsection::freeze).toList(), false, layoutHint);
        }
    }

    private byte[] powerpoint(FormattedDocument document) throws Exception {
        try (XMLSlideShow ppt = new XMLSlideShow(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            ppt.setPageSize(new Dimension(960, 540));
            Map<String, DocumentBlock> blocks = blockMap(document);

            if (hasSemantic(document)) {
                for (SemanticSection section : document.semanticSections()) {
                    switch (layout(section)) {
                        case TABLE, COMPARISON -> pptTableSlide(ppt, section);
                        case WORKFLOW, ARCHITECTURE, HIERARCHY -> pptFlowSlide(ppt, section);
                        case STATUS, KPI -> pptCardsSlide(ppt, section);
                        case TIMELINE -> pptTimelineSlide(ppt, section);
                        case CHECKLIST, CALLOUT -> pptItemsSlide(ppt, section);
                        case TEXT, CODE_GROUP -> pptTextSlides(ppt, referencedBlocks(section, blocks), "");
                    }
                }
            } else {
                pptTextSlides(ppt, document.blocks(), document.title());
            }

            if (ppt.getSlides().isEmpty()) pptTextSlides(ppt, document.blocks(), document.title());
            ppt.write(out);
            return out.toByteArray();
        }
    }

    private XSLFSlide newSlide(XMLSlideShow ppt, String title, String iconKey) {
        XSLFSlide slide = ppt.createSlide();
        addPptRect(slide, 0, 0, 960, 540, Color.WHITE, null);
        addPptRect(slide, 0, 0, 960, 10, BNP_GREEN, null);
        addPptRect(slide, 950, 0, 10, 540, BNP_GREEN_DARK, null);
        if (title != null && !title.isBlank()) {
            String icon = hasLeadingPresentationIcon(title) ? "" : iconCatalog.symbol(iconKey);
            addPptText(slide, 54, 31, 790, 48, (icon.isBlank() ? "" : icon + "  ") + title,
                    28, true, BNP_GREEN_TITLE, null);
        }
        return slide;
    }

    private void pptTableSlide(XMLSlideShow ppt, SemanticSection section) {
        XSLFSlide slide = newSlide(ppt, section.title(), section.iconKey());
        int cols = safe(section.rows()).stream().mapToInt(r -> safe(r.cells()).size()).max().orElse(2);
        List<String> headers = paddedColumns(section.columns(), cols);
        int rows = Math.min(10, section.rows().size());
        double left = 55, top = section.title().isBlank() ? 48 : 92, width = 850;
        double cellW = width / cols;
        double rowH = Math.min(42, 360.0 / Math.max(2, rows + 1));

        for (int c = 0; c < cols; c++) {
            addPptText(slide, left + c * cellW, top, cellW, rowH, headers.get(c), 12, true, Color.WHITE, new Color(0, 107, 54));
        }
        for (int r = 0; r < rows; r++) {
            List<SemanticValue> cells = safe(section.rows().get(r).cells());
            for (int c = 0; c < cols; c++) {
                String text = c < cells.size() ? cells.get(c).text() : "";
                addPptText(slide, left + c * cellW, top + (r + 1) * rowH, cellW, rowH, text,
                        11, false, new Color(31, 45, 37), r % 2 == 0 ? Color.WHITE : new Color(247, 251, 248));
            }
        }
    }

    private void pptFlowSlide(XMLSlideShow ppt, SemanticSection section) {
        XSLFSlide slide = newSlide(ppt, section.title(), section.iconKey());
        List<SemanticNode> nodes = safe(section.nodes());
        Map<String, SemanticEdge> edgeMap = section.edges().stream().collect(Collectors.toMap(SemanticEdge::from, Function.identity(), (a, b) -> a));
        int perRow = Math.min(4, Math.max(2, nodes.size()));
        double nodeW = 165, nodeH = 70, gapX = 45, startX = 60, startY = section.title().isBlank() ? 80 : 125;

        for (int i = 0; i < nodes.size(); i++) {
            int row = i / perRow, col = i % perRow;
            double x = startX + col * (nodeW + gapX);
            double y = startY + row * 140;
            SemanticNode node = nodes.get(i);
            String icon = iconCatalog.symbol(node.iconKey());
            addPptText(slide, x, y, nodeW, nodeH, (icon.isBlank() ? "" : icon + "  ") + node.text(),
                    12, true, new Color(0, 107, 54), new Color(238, 248, 242));
            if (i < nodes.size() - 1 && (i + 1) % perRow != 0) {
                SemanticEdge edge = edgeMap.get(node.id());
                String label = edge == null || edge.label() == null ? "" : edge.label();
                addPptText(slide, x + nodeW + 4, y + 14, gapX - 8, 42, (label.isBlank() ? "" : label + "\n") + "→",
                        12, true, new Color(0, 133, 66), null);
            }
        }
    }

    private void pptCardsSlide(XMLSlideShow ppt, SemanticSection section) {
        XSLFSlide slide = newSlide(ppt, section.title(), section.iconKey());
        List<SemanticItem> items = safe(section.items());
        int cols = 3;
        double cardW = 250, cardH = 105, gapX = 28, gapY = 22, startX = 62, startY = section.title().isBlank() ? 75 : 118;
        for (int i = 0; i < Math.min(items.size(), 9); i++) {
            int row = i / cols, col = i % cols;
            SemanticItem item = items.get(i);
            String icon = iconCatalog.symbol(item.iconKey());
            addPptText(slide, startX + col * (cardW + gapX), startY + row * (cardH + gapY), cardW, cardH,
                    (icon.isBlank() ? "" : icon + "  ") + joinItem(item), 12, i < 3, new Color(31, 45, 37), new Color(247, 251, 248));
        }
    }

    private void pptTimelineSlide(XMLSlideShow ppt, SemanticSection section) {
        XSLFSlide slide = newSlide(ppt, section.title(), section.iconKey());
        double x = 105, y = section.title().isBlank() ? 75 : 118;
        for (int i = 0; i < Math.min(section.items().size(), 8); i++) {
            SemanticItem item = section.items().get(i);
            addPptText(slide, x, y + i * 48, 40, 35, "●", 16, true, new Color(0, 133, 66), null);
            addPptText(slide, x + 46, y + i * 48, 730, 40, joinItem(item), 12, false, new Color(31, 45, 37), null);
        }
    }

    private void pptItemsSlide(XMLSlideShow ppt, SemanticSection section) {
        XSLFSlide slide = newSlide(ppt, section.title(), section.iconKey());
        double y = section.title().isBlank() ? 70 : 112;
        for (int i = 0; i < Math.min(section.items().size(), 10); i++) {
            SemanticItem item = section.items().get(i);
            String prefix = layout(section) == SemanticLayoutType.CHECKLIST ? "✓  " : iconCatalog.symbol(item.iconKey()) + "  ";
            addPptText(slide, 78, y + i * 38, 800, 34, prefix + joinItem(item), 12, false,
                    new Color(31, 45, 37), layout(section) == SemanticLayoutType.CALLOUT ? new Color(238, 248, 242) : null);
        }
    }

    private void pptTextSlides(XMLSlideShow ppt, List<DocumentBlock> blocks, String sectionTitle) {
        List<List<DocumentBlock>> chunks = slides(blocks);
        for (int index = 0; index < chunks.size(); index++) {
            XSLFSlide slide = newSlide(ppt, index == 0 ? sectionTitle : "", "DOCUMENT");
            XSLFTextBox box = slide.createTextBox();
            box.setAnchor(new Rectangle2D.Double(58, sectionTitle != null && !sectionTitle.isBlank() && index == 0 ? 92 : 45, 845, 420));
            box.setTopInset(0); box.setBottomInset(0); box.setLeftInset(0); box.setRightInset(0); box.clearText();
            for (DocumentBlock block : chunks.get(index)) {
                if (block.type() == BlockType.SPACER) continue;
                XSLFTextParagraph p = box.addNewTextParagraph(); p.setSpaceAfter(5d);
                XSLFTextRun run = p.addNewTextRun();
                String icon = block.iconSymbol().isBlank() ? "" : block.iconSymbol() + "  ";
                String text = switch (block.type()) {
                    case BULLET -> "✓  " + stripBullet(block.text());
                    case TITLE, HEADING, CALLOUT -> icon + block.text();
                    default -> block.text();
                };
                run.setText(text); run.setFontFamily(block.type() == BlockType.CODE ? "Consolas" : "Arial");
                if (block.type() == BlockType.TITLE || block.type() == BlockType.HEADING) {
                    run.setFontSize(block.type() == BlockType.TITLE ? 22d : 17d); run.setBold(true); run.setFontColor(new Color(0, 110, 55));
                } else {
                    run.setFontSize(block.type() == BlockType.CODE ? 10d : 12d); run.setFontColor(new Color(32, 45, 38));
                }
            }
        }
    }

    private XSLFTextBox addPptText(XSLFSlide slide, double x, double y, double w, double h, String text,
                                   double size, boolean bold, Color textColor, Color fill) {
        XSLFTextBox box = slide.createTextBox();
        box.setAnchor(new Rectangle2D.Double(x, y, w, h));
        box.setTopInset(6); box.setBottomInset(4); box.setLeftInset(7); box.setRightInset(7);
        if (fill != null) box.setFillColor(fill);
        box.setTextAutofit(TextShape.TextAutofit.NORMAL);
        XSLFTextParagraph p = box.addNewTextParagraph();
        XSLFTextRun run = p.addNewTextRun();
        run.setText(text == null ? "" : text); run.setFontFamily("Arial"); run.setFontSize(size); run.setBold(bold); run.setFontColor(textColor);
        return box;
    }

    private byte[] pdf(FormattedDocument document) throws Exception {
        try (PDDocument doc = new PDDocument(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            PdfFontResolver.FontPair fonts = pdfFontResolver.resolve(doc);
            PdfCanvas canvas = new PdfCanvas(doc, fonts.regular(), fonts.bold());
            Map<String, DocumentBlock> blocks = blockMap(document);

            if (hasSemantic(document)) {
                for (SemanticSection section : document.semanticSections()) {
                    SemanticLayoutType sectionLayout = layout(section);
                    if (sectionLayout != SemanticLayoutType.TEXT && sectionLayout != SemanticLayoutType.CODE_GROUP) canvas.sectionTitle(section.title(), section.iconKey());
                    switch (sectionLayout) {
                        case TABLE, COMPARISON -> canvas.table(section);
                        case WORKFLOW, ARCHITECTURE, HIERARCHY -> canvas.flow(section);
                        case STATUS, KPI, TIMELINE, CHECKLIST, CALLOUT -> canvas.items(section);
                        case TEXT, CODE_GROUP -> canvas.blocks(referencedBlocks(section, blocks));
                    }
                    canvas.gap(8);
                }
            } else {
                canvas.blocks(document.blocks());
            }
            canvas.close();
            doc.save(out);
            return out.toByteArray();
        }
    }

    private final class PdfCanvas {
        private final PDDocument doc;
        private final PDFont regular;
        private final PDFont bold;
        private PDPage page;
        private PDPageContentStream stream;
        private final float margin = 48;
        private float y;

        private PdfCanvas(PDDocument doc, PDFont regular, PDFont bold) throws Exception {
            this.doc = doc; this.regular = regular; this.bold = bold; newPage();
        }

        private void newPage() throws Exception {
            if (stream != null) stream.close();
            page = new PDPage(PDRectangle.A4); doc.addPage(page); stream = new PDPageContentStream(doc, page);
            y = page.getMediaBox().getHeight() - 48;
            stream.setNonStrokingColor(new Color(0, 133, 66)); stream.addRect(0, page.getMediaBox().getHeight() - 10, page.getMediaBox().getWidth(), 10); stream.fill();
        }

        private void ensure(float height) throws Exception { if (y - height < margin) newPage(); }
        private void gap(float value) { y -= value; }

        private void sectionTitle(String title, String iconKey) throws Exception {
            if (title == null || title.isBlank()) return;
            ensure(30);
            String icon = iconCatalog.pdfSymbol(iconKey);
            line((icon.isBlank() ? "" : icon + "  ") + title, bold, 13, true, margin, 18);
            gap(5);
        }

        private void table(SemanticSection section) throws Exception {
            int cols = safe(section.rows()).stream().mapToInt(r -> safe(r.cells()).size()).max().orElse(2);
            List<String> headers = paddedColumns(section.columns(), cols);
            float totalW = page.getMediaBox().getWidth() - 2 * margin;
            float cellW = totalW / cols;
            float rowH = 25;
            ensure(rowH * 2);
            drawTableRow(headers, cols, cellW, rowH, true);
            for (SemanticRow row : safe(section.rows())) {
                ensure(rowH);
                List<String> values = safe(row.cells()).stream().map(SemanticValue::text).toList();
                drawTableRow(values, cols, cellW, rowH, false);
            }
            gap(6);
        }

        private void drawTableRow(List<String> values, int cols, float cellW, float rowH, boolean header) throws Exception {
            for (int c = 0; c < cols; c++) {
                float x = margin + c * cellW;
                if (header) {
                    stream.setNonStrokingColor(new Color(0, 107, 54)); stream.addRect(x, y - rowH, cellW, rowH); stream.fill();
                }
                stream.setStrokingColor(new Color(207, 228, 215)); stream.addRect(x, y - rowH, cellW, rowH); stream.stroke();
                String value = c < values.size() ? values.get(c) : "";
                drawAt(fit(value, header ? bold : regular, 9, cellW - 10), header ? bold : regular, 9,
                        header ? Color.WHITE : new Color(31, 45, 37), x + 5, y - 16);
            }
            y -= rowH;
        }

        private void flow(SemanticSection section) throws Exception {
            List<SemanticNode> nodes = safe(section.nodes());
            for (int i = 0; i < nodes.size(); i++) {
                if (i > 0) line("↓", bold, 12, true, margin + 35, 16);
                ensure(38);
                stream.setNonStrokingColor(new Color(238, 248, 242)); stream.addRect(margin, y - 28, 260, 28); stream.fill();
                stream.setStrokingColor(new Color(0, 133, 66)); stream.addRect(margin, y - 28, 260, 28); stream.stroke();
                String icon = iconCatalog.pdfSymbol(nodes.get(i).iconKey());
                drawAt(fit((icon.isBlank() ? "" : icon + "  ") + nodes.get(i).text(), bold, 10, 248), bold, 10,
                        new Color(0, 107, 54), margin + 6, y - 18);
                y -= 32;
            }
        }

        private void items(SemanticSection section) throws Exception {
            SemanticLayoutType type = layout(section);
            for (SemanticItem item : safe(section.items())) {
                String prefix = switch (type) {
                    case CHECKLIST -> "✓  ";
                    case TIMELINE -> "●  ";
                    default -> {
                        String symbol = iconCatalog.pdfSymbol(item.iconKey());
                        yield symbol.isBlank() ? "•  " : symbol + "  ";
                    }
                };
                line(prefix + joinItem(item), regular, 10, false, margin, 14);
            }
        }

        private void blocks(List<DocumentBlock> blocks) throws Exception {
            for (DocumentBlock block : blocks) {
                if (block.type() == BlockType.SPACER) { gap(7); continue; }
                boolean heading = block.type() == BlockType.TITLE || block.type() == BlockType.HEADING;
                PDFont font = heading ? bold : regular;
                float size = block.type() == BlockType.TITLE ? 17 : (block.type() == BlockType.HEADING ? 12 : 9.5f);
                String prefix = switch (block.type()) {
                    case BULLET -> "✓  ";
                    case TITLE, HEADING, CALLOUT -> {
                        String symbol = iconCatalog.pdfSymbol(block.iconKey()); yield symbol.isBlank() ? "" : symbol + "  ";
                    }
                    default -> "";
                };
                line(prefix + (block.type() == BlockType.BULLET ? stripBullet(block.text()) : block.text()), font, size, heading, margin, heading ? 18 : 13);
                if (heading) gap(4);
            }
        }

        private void line(String text, PDFont font, float size, boolean green, float x, float leading) throws Exception {
            List<String> lines = wrap(text, font, size, page.getMediaBox().getWidth() - x - margin);
            for (String value : lines) {
                ensure(leading + 2);
                drawAt(value, font, size, green ? new Color(0, 107, 54) : new Color(31, 45, 37), x, y);
                y -= leading;
            }
        }

        private void drawAt(String text, PDFont font, float size, Color color, float x, float yPos) throws Exception {
            stream.beginText(); stream.setFont(font, size); stream.setNonStrokingColor(color); stream.newLineAtOffset(x, yPos); stream.showText(safeForFont(font, text)); stream.endText();
        }

        private String fit(String value, PDFont font, float size, float maxWidth) throws Exception {
            String safe = safeForFont(font, value == null ? "" : value);
            if (font.getStringWidth(safe) / 1000f * size <= maxWidth) return safe;
            String suffix = "...";
            while (!safe.isEmpty() && font.getStringWidth(safe + suffix) / 1000f * size > maxWidth) safe = safe.substring(0, safe.length() - 1);
            return safe + suffix;
        }

        private void close() throws Exception { if (stream != null) stream.close(); }
    }

    private List<String> wrap(String text, PDFont font, float size, float width) throws Exception {
        List<String> result = new ArrayList<>();
        if (text == null || text.isEmpty()) { result.add(""); return result; }
        for (String hardLine : text.split("\\R", -1)) {
            String[] words = hardLine.split("\\s+");
            StringBuilder line = new StringBuilder();
            for (String word : words) {
                String candidate = line.isEmpty() ? word : line + " " + word;
                float w = font.getStringWidth(safeForFont(font, candidate)) / 1000f * size;
                if (!line.isEmpty() && w > width) { result.add(line.toString()); line = new StringBuilder(word); }
                else line = new StringBuilder(candidate);
            }
            result.add(line.toString());
        }
        return result;
    }

    private String safeForFont(PDFont font, String text) {
        StringBuilder out = new StringBuilder();
        text.codePoints().forEach(cp -> {
            String s = new String(Character.toChars(cp));
            try { font.getStringWidth(s); out.append(s); }
            catch (Exception ex) { out.append('?'); }
        });
        return out.toString();
    }

    private List<List<DocumentBlock>> slides(List<DocumentBlock> blocks) {
        List<List<DocumentBlock>> slides = new ArrayList<>();
        List<DocumentBlock> current = new ArrayList<>();
        int weight = 0;
        for (DocumentBlock block : blocks) {
            int blockWeight = Math.max(1, (block.text().length() / 85) + 1);
            boolean headingBreak = (block.type() == BlockType.TITLE || block.type() == BlockType.HEADING) && !current.isEmpty() && weight >= 7;
            if (headingBreak || weight + blockWeight > 13) { slides.add(List.copyOf(current)); current.clear(); weight = 0; }
            current.add(block); weight += blockWeight;
        }
        if (!current.isEmpty()) slides.add(List.copyOf(current));
        if (slides.isEmpty()) slides.add(List.of());
        return slides;
    }

    private boolean hasSemantic(FormattedDocument document) {
        return document.semanticSections() != null && !document.semanticSections().isEmpty();
    }

    private SemanticLayoutType layout(SemanticSection section) {
        try { return SemanticLayoutType.valueOf(section.layoutType().toUpperCase(Locale.ROOT)); }
        catch (Exception ex) { return SemanticLayoutType.TEXT; }
    }

    private Map<String, DocumentBlock> blockMap(FormattedDocument document) {
        return document.blocks().stream().collect(Collectors.toMap(DocumentBlock::id, Function.identity(), (a, b) -> a, LinkedHashMap::new));
    }

    private List<DocumentBlock> referencedBlocks(SemanticSection section, Map<String, DocumentBlock> blocks) {
        List<DocumentBlock> result = new ArrayList<>();
        for (String id : safe(section.sourceIds())) if (blocks.containsKey(id)) result.add(blocks.get(id));
        return result;
    }

    private List<String> paddedColumns(List<String> columns, int count) {
        List<String> result = new ArrayList<>(safe(columns));
        while (result.size() < count) result.add(result.isEmpty() ? "Item" : "Details");
        return result.subList(0, count);
    }

    private String joinItem(SemanticItem item) {
        LinkedHashSet<String> parts = new LinkedHashSet<>();
        if (item.label() != null && !item.label().isBlank()) parts.add(item.label());
        if (item.value() != null && !item.value().isBlank()) parts.add(item.value());
        if (item.status() != null && !item.status().isBlank()) parts.add(item.status());
        return String.join(" — ", parts);
    }

    private <T> List<T> safe(List<T> values) { return values == null ? List.of() : values; }

    private void applyParagraphShading(XWPFParagraph p, String fill) {
        CTShd shd = p.getCTP().getPPr() == null ? p.getCTP().addNewPPr().addNewShd() : p.getCTP().getPPr().addNewShd();
        shd.setVal(STShd.CLEAR); shd.setFill(fill);
    }

    private void applyEmphasis(XWPFRun run, String emphasis) {
        if ("STRONG".equalsIgnoreCase(emphasis)) run.setBold(true);
        if ("MUTED".equalsIgnoreCase(emphasis)) run.setColor("6F7F76");
    }

    private String stripBullet(String text) {
        return text == null ? "" : text.replaceFirst("^\\s*(?:[-*•▪◦]|\\d+[.)])\\s+", "");
    }

    private String sanitizeFilename(String value) {
        String sanitized = value.replaceAll("[^A-Za-z0-9._-]+", "-").replaceAll("^-+|-+$", "");
        return sanitized.isBlank() ? "formatflow-output" : sanitized;
    }

    public record ExportedFile(String filename, String contentType, byte[] bytes) {}
}
