package com.formatflow.ai.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.formatflow.ai.config.LlmProperties;
import org.springframework.stereotype.Service;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.atomic.AtomicReference;

@Service
public class LlmClient {

    private final HttpClient httpClient;
    private final ObjectMapper objectMapper;
    private final LlmProperties properties;

    /**
     * Authentication style is an endpoint-level concern, so once a working
     * header/prefix is discovered it is safe and efficient to reuse it for
     * subsequent requests. The API key itself is never stored here.
     */
    private final AtomicReference<AuthSpec> learnedAuth = new AtomicReference<>();

    public LlmClient(HttpClient httpClient, ObjectMapper objectMapper, LlmProperties properties) {
        this.httpClient = httpClient;
        this.objectMapper = objectMapper;
        this.properties = properties;
    }

    public ValidationResult validateKey(String rawApiKey) {
        String apiKey = normalizeApiKey(rawApiKey);
        if (apiKey.isBlank()) {
            return new ValidationResult(false, "Enter a valid LLM API key.");
        }

        try {
            String response = chat(apiKey, "Reply with exactly OK.", 24, 0.0);
            return response == null || response.isBlank()
                    ? new ValidationResult(false, "The AI service connected but returned an empty response.")
                    : new ValidationResult(true, "AI service connected.");
        } catch (LlmHttpException ex) {
            return new ValidationResult(false, validationMessage(ex));
        } catch (Exception ex) {
            return new ValidationResult(false, "Unable to connect to the configured LLM service: " + safeMessage(ex));
        }
    }

    /**
     * Executes a chat-completions request with exact-request replay before any
     * compatibility adjustment or local fallback can happen upstream.
     *
     * For transient transport/gateway failures (408/429/5xx, timeout, malformed
     * response, connection reset, etc.), the same serialized JSON payload is sent
     * again with the same model, prompt, temperature, token budget and auth shape.
     * Only a non-transient request-shape problem such as an explicit token-limit
     * response may create a second request variant with a smaller completion cap.
     */
    public String chat(String rawApiKey, String prompt, int maxTokens, double temperature) {
        String apiKey = normalizeApiKey(rawApiKey);
        if (apiKey.isBlank()) {
            throw new IllegalStateException("LLM API key is blank.");
        }

        int configuredCap = Math.max(256, properties.getMaxCompletionTokens());
        int effectiveMaxTokens = Math.max(24, Math.min(maxTokens, configuredCap));
        int compatibilityAdjustments = 0;

        while (true) {
            String requestBody = buildRequestBody(prompt, effectiveMaxTokens, temperature);
            try {
                return doChatWithAuthDiscovery(apiKey, requestBody);
            } catch (LlmHttpException ex) {
                int reduced = reducedTokenBudget(ex, effectiveMaxTokens);
                if (reduced < effectiveMaxTokens && compatibilityAdjustments < 4) {
                    effectiveMaxTokens = reduced;
                    compatibilityAdjustments++;
                    continue;
                }
                throw ex;
            }
        }
    }

    private String buildRequestBody(String prompt, int maxTokens, double temperature) {
        try {
            return objectMapper.writeValueAsString(Map.of(
                    "model", properties.getModel(),
                    "messages", List.of(Map.of("role", "user", "content", prompt)),
                    "temperature", temperature,
                    "max_tokens", maxTokens
            ));
        } catch (Exception ex) {
            throw new IllegalStateException("Unable to create LLM request payload: " + safeMessage(ex), ex);
        }
    }

    private String doChatWithAuthDiscovery(String apiKey, String requestBody) {
        List<AuthSpec> candidates = authCandidates();
        LlmHttpException lastAuthFailure = null;

        for (AuthSpec auth : candidates) {
            try {
                String response = sendIdenticalRequestWithRetry(apiKey, requestBody, auth);
                learnedAuth.set(auth);
                return response;
            } catch (LlmHttpException ex) {
                if ((ex.statusCode == 401 || ex.statusCode == 403) && properties.isAuthAutoDetect()) {
                    lastAuthFailure = ex;
                    continue;
                }
                throw ex;
            }
        }

        if (lastAuthFailure != null) throw lastAuthFailure;
        throw new IllegalStateException("No LLM authentication strategy is configured.");
    }

    private String sendIdenticalRequestWithRetry(String apiKey, String requestBody, AuthSpec auth) {
        int attempts = properties.getMaxAttempts();
        RuntimeException last = null;

        for (int attempt = 1; attempt <= attempts; attempt++) {
            try {
                return doChat(apiKey, requestBody, auth);
            } catch (LlmHttpException ex) {
                last = ex;
                if (!retryable(ex.statusCode)) throw ex;
                if (attempt == attempts) throw exhaustedAttempts(attempts, ex);
                sleep(attempt);
            } catch (IllegalStateException ex) {
                // A transport failure, timeout or malformed 2xx response may be
                // transient. Replay the exact serialized request before giving up.
                last = ex;
                if (attempt == attempts) throw exhaustedAttempts(attempts, ex);
                sleep(attempt);
            } catch (RuntimeException ex) {
                last = ex;
                if (attempt == attempts) throw exhaustedAttempts(attempts, ex);
                sleep(attempt);
            }
        }
        throw last == null ? new IllegalStateException("LLM request failed.") : last;
    }

    private String doChat(String apiKey,
                          String requestBody,
                          AuthSpec auth) {
        try {
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(chatUri())
                    .timeout(Duration.ofSeconds(properties.getRequestTimeoutSeconds()))
                    .header("Content-Type", "application/json")
                    .header("Accept", "application/json")
                    .header(auth.header(), auth.prefix() + apiKey)
                    .POST(HttpRequest.BodyPublishers.ofString(requestBody))
                    .build();

            HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
            if (response.statusCode() < 200 || response.statusCode() >= 300) {
                String detail = extractServiceError(response.body());
                throw new LlmHttpException(
                        response.statusCode(),
                        response.body(),
                        runtimeMessage(response.statusCode(), detail)
                );
            }

            JsonNode json = objectMapper.readTree(response.body());
            JsonNode content = json.at("/choices/0/message/content");
            if (content.isMissingNode() || content.isNull()) {
                throw new IllegalStateException("LLM response does not contain choices[0].message.content.");
            }
            if (!content.isValueNode()) {
                throw new IllegalStateException("LLM response content is not a text value. Check OpenAI-compatible response format.");
            }
            return content.asText();
        } catch (LlmHttpException ex) {
            throw ex;
        } catch (IllegalStateException ex) {
            throw ex;
        } catch (Exception ex) {
            throw new IllegalStateException("LLM request failed: " + safeMessage(ex), ex);
        }
    }

    private List<AuthSpec> authCandidates() {
        Set<AuthSpec> ordered = new LinkedHashSet<>();

        AuthSpec learned = learnedAuth.get();
        if (learned != null) ordered.add(learned);

        ordered.add(new AuthSpec(nonBlank(properties.getAuthHeader(), "Authorization"),
                properties.getAuthPrefix() == null ? "" : properties.getAuthPrefix()));

        if (properties.isAuthAutoDetect()) {
            // Common OpenAI-compatible enterprise gateways. All requests go to
            // the same configured endpoint; only the authentication header shape
            // is retried when the gateway returns 401/403.
            ordered.add(new AuthSpec("Authorization", "Bearer "));
            ordered.add(new AuthSpec("Authorization", ""));
            ordered.add(new AuthSpec("api-key", ""));
            ordered.add(new AuthSpec("x-api-key", ""));
        }

        return new ArrayList<>(ordered);
    }

    private URI chatUri() {
        String base = properties.getBaseUrl();
        if (base == null || base.isBlank()) {
            throw new IllegalStateException("formatflow.llm.base-url is not configured.");
        }
        base = base.endsWith("/") ? base.substring(0, base.length() - 1) : base;
        String path = properties.getChatPath() == null ? "/chat/completions" : properties.getChatPath();
        path = path.startsWith("/") ? path : "/" + path;
        return URI.create(base + path);
    }

    private int reducedTokenBudget(LlmHttpException ex, int current) {
        if (ex.statusCode != 400 && ex.statusCode != 422) return current;

        if (looksLikeTokenLimit(ex.responseBody)) {
            if (current > 4096) return 4096;
            if (current > 3072) return 3072;
            if (current > 2048) return 2048;
            if (current > 1024) return 1024;
            return current;
        }

        // Validation has already proven the endpoint/model/request schema with a
        // tiny request. If a later full formatting request gets a generic 400/422
        // and asks for a large completion, make one conservative 2048-token retry.
        // This covers gateways that enforce a completion/context limit without
        // returning a descriptive error body.
        if (current > 2048) return 2048;
        return current;
    }

    private boolean looksLikeTokenLimit(String body) {
        String text = body == null ? "" : body.toLowerCase();
        return text.contains("max_tokens")
                || text.contains("max tokens")
                || text.contains("maximum tokens")
                || text.contains("context length")
                || text.contains("context_length")
                || text.contains("context window")
                || text.contains("token limit")
                || text.contains("too many tokens")
                || text.contains("max completion")
                || text.contains("completion tokens");
    }

    private IllegalStateException exhaustedAttempts(int attempts, Throwable cause) {
        return new IllegalStateException(
                "LLM unavailable after " + attempts + " attempts. The configured LLM service did not recover. Last error: "
                        + safeMessage(cause),
                cause
        );
    }

    private boolean retryable(int status) {
        return status == 408 || status == 429 || status == 500 || status == 502 || status == 503 || status == 504;
    }

    private void sleep(int attempt) {
        try {
            Thread.sleep(Math.min(4000L, 500L * (1L << Math.min(attempt - 1, 3))));
        } catch (InterruptedException ex) {
            Thread.currentThread().interrupt();
            throw new IllegalStateException("LLM retry interrupted.", ex);
        }
    }

    /**
     * Accepts either a raw key or a value copied as "Bearer <key>". Quotes
     * accidentally copied from configuration files are also removed.
     */
    static String normalizeApiKey(String raw) {
        if (raw == null) return "";
        String key = raw.trim();
        if ((key.startsWith("\"") && key.endsWith("\"")) ||
                (key.startsWith("'") && key.endsWith("'"))) {
            if (key.length() > 1) key = key.substring(1, key.length() - 1).trim();
        }
        if (key.regionMatches(true, 0, "Bearer ", 0, 7)) {
            key = key.substring(7).trim();
        }
        return key;
    }

    private String validationMessage(LlmHttpException ex) {
        String detail = extractServiceError(ex.responseBody);
        return switch (ex.statusCode) {
            case 400, 422 -> "The LLM endpoint rejected the validation request (HTTP " + ex.statusCode + ")"
                    + suffix(detail) + ". Check the configured model and OpenAI-compatible request format.";
            case 401 -> "Authentication failed (HTTP 401). Check the API key. You may paste either the raw key or 'Bearer <key>'."
                    + suffix(detail);
            case 403 -> "The LLM gateway denied access (HTTP 403). This can mean model/endpoint permission rather than a bad API key."
                    + suffix(detail);
            case 404 -> "The configured LLM chat endpoint was not found (HTTP 404). Check base-url and chat-path."
                    + suffix(detail);
            case 429 -> "The LLM service is rate-limiting requests (HTTP 429). Please retry shortly."
                    + suffix(detail);
            default -> "LLM service returned HTTP " + ex.statusCode + suffix(detail) + ".";
        };
    }

    private String runtimeMessage(int status, String detail) {
        return switch (status) {
            case 400, 422 -> "The LLM endpoint rejected the formatting request (HTTP " + status + ")"
                    + suffix(detail) + ". The app will automatically lower max_tokens when the service reports a token/context limit.";
            case 401 -> "LLM authentication failed during formatting (HTTP 401). Reconnect the API key."
                    + suffix(detail);
            case 403 -> "The LLM gateway denied the formatting request (HTTP 403). Check model/endpoint permission."
                    + suffix(detail);
            case 404 -> "The configured LLM chat endpoint was not found (HTTP 404). Check base-url and chat-path."
                    + suffix(detail);
            case 408 -> "The LLM gateway timed out the request (HTTP 408)." + suffix(detail);
            case 413 -> "The LLM gateway rejected the request as too large (HTTP 413). Reduce the configured chunk size."
                    + suffix(detail);
            case 429 -> "The LLM service is rate-limiting formatting requests (HTTP 429). Retry shortly."
                    + suffix(detail);
            default -> "LLM service returned HTTP " + status + suffix(detail) + ".";
        };
    }

    private String extractServiceError(String body) {
        if (body == null || body.isBlank()) return "";
        try {
            JsonNode root = objectMapper.readTree(body);
            for (String pointer : List.of("/error/message", "/message", "/detail", "/error")) {
                JsonNode node = root.at(pointer);
                if (!node.isMissingNode() && !node.isNull() && node.isValueNode()) {
                    String text = node.asText().trim();
                    if (!text.isBlank()) return truncate(text, 220);
                }
            }
        } catch (Exception ignored) {
            // Fall through to a compact text version.
        }
        return truncate(body.replaceAll("\\s+", " ").trim(), 220);
    }

    private static String suffix(String detail) {
        return detail == null || detail.isBlank() ? "" : " Service message: " + detail;
    }

    private static String nonBlank(String value, String fallback) {
        return value == null || value.isBlank() ? fallback : value;
    }

    private static String truncate(String text, int max) {
        if (text == null) return "";
        return text.length() > max ? text.substring(0, max) : text;
    }

    private static String safeMessage(Throwable ex) {
        String msg = ex.getMessage();
        if (msg == null || msg.isBlank()) return ex.getClass().getSimpleName();
        return msg.length() > 220 ? msg.substring(0, 220) : msg;
    }

    public record ValidationResult(boolean valid, String message) {}

    private record AuthSpec(String header, String prefix) {}

    /**
     * Deliberately extends IllegalStateException so formatting-time LLM HTTP
     * failures are handled by ApiExceptionHandler.state instead of becoming an
     * opaque "Unexpected server error <reference>".
     */
    private static final class LlmHttpException extends IllegalStateException {
        private final int statusCode;
        private final String responseBody;

        private LlmHttpException(int statusCode, String responseBody, String message) {
            super(message);
            this.statusCode = statusCode;
            this.responseBody = responseBody;
        }
    }
}
