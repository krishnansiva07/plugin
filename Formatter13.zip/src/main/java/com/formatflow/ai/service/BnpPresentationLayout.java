package com.formatflow.ai.service;

import java.util.Locale;

/**
 * Predefined slide layouts for the BNP-green presentation design system.
 *
 * The LLM may recommend one of these layouts through the PowerPoint HTML
 * contract (h2[data-layout]). Java remains the source of truth for visual
 * rendering, pagination and overflow safety.
 */
public enum BnpPresentationLayout {
    TITLE,
    AGENDA,
    EXECUTIVE_OVERVIEW,
    KEY_MESSAGE,
    BULLETS,
    TWO_COLUMN,
    THREE_CARDS,
    FOUR_CARDS,
    PROCESS_5,
    CHECKLIST,
    TABLE,
    CHART,
    DIAGRAM,
    CODE,
    COMPARISON,
    TIMELINE,
    NEXT_STEPS;

    public static BnpPresentationLayout fromHint(String value) {
        if (value == null || value.isBlank()) return BULLETS;
        String raw = value.trim();
        int separator = raw.indexOf(':');
        if (separator >= 0) raw = raw.substring(0, separator);
        String normalized = raw
                .toUpperCase(Locale.ROOT)
                .replace('-', '_')
                .replace(' ', '_');
        return switch (normalized) {
            case "TITLE" -> TITLE;
            case "AGENDA", "CONTENTS" -> AGENDA;
            case "EXECUTIVE_OVERVIEW", "EXEC_OVERVIEW", "OVERVIEW" -> EXECUTIVE_OVERVIEW;
            case "KEY_MESSAGE", "KEYMESSAGE", "STATEMENT", "SECTION_MESSAGE" -> KEY_MESSAGE;
            case "TWO_COLUMN", "TWO_COLUMNS", "2_COLUMN", "2_COLUMNS" -> TWO_COLUMN;
            case "THREE_CARDS", "3_CARDS", "THREE_CARD" -> THREE_CARDS;
            case "FOUR_CARDS", "4_CARDS", "FOUR_CARD" -> FOUR_CARDS;
            case "PROCESS", "PROCESS_5", "WORKFLOW", "FLOW", "STEPS" -> PROCESS_5;
            case "CHECKLIST", "QUICK_START", "QUICKSTART" -> CHECKLIST;
            case "TABLE", "DATA_TABLE" -> TABLE;
            case "CHART", "NATIVE_CHART", "POWERPOINT_CHART" -> CHART;
            case "DIAGRAM", "FLOW_DIAGRAM", "POWERPOINT_DIAGRAM" -> DIAGRAM;
            case "CODE", "JSON", "CODE_BLOCK", "TECHNICAL_CONTENT" -> CODE;
            case "COMPARISON", "COMPARE" -> COMPARISON;
            case "TIMELINE", "ROADMAP" -> TIMELINE;
            case "NEXT_STEPS", "ACTIONS", "ACTION" -> NEXT_STEPS;
            default -> BULLETS;
        };
    }

    public String htmlHint() {
        return name().toLowerCase(Locale.ROOT).replace('_', '-');
    }
}
