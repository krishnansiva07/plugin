package com.formatflow.ai.service;

import java.util.Locale;

/**
 * Editable PowerPoint-native diagram designs used by the BNP-green renderer.
 * These are rendered with standard OOXML shapes/connectors rather than SmartArt,
 * which keeps the output editable and predictable through Apache POI.
 */
public enum BnpPresentationDiagramType {
    NONE,
    LINEAR_PROCESS,
    CHEVRON_PROCESS,
    CYCLE,
    SWIMLANE,
    HIERARCHY,
    HUB_SPOKE,
    PIPELINE,
    ARCHITECTURE_FLOW,
    FUNNEL,
    PYRAMID,
    MATRIX_2X2,
    DECISION_TREE,
    FEEDBACK_LOOP,
    CONVERGING_FLOW,
    DIVERGING_FLOW,
    BEFORE_AFTER,
    COMPARISON_FLOW,
    ROADMAP;

    public static BnpPresentationDiagramType fromHint(String value) {
        if (value == null || value.isBlank()) return NONE;
        String normalized = value.trim()
                .toUpperCase(Locale.ROOT)
                .replace('-', '_')
                .replace(' ', '_');
        return switch (normalized) {
            case "LINEAR", "LINEAR_PROCESS", "SEQUENTIAL", "SEQUENCE" -> LINEAR_PROCESS;
            case "CHEVRON", "CHEVRON_PROCESS" -> CHEVRON_PROCESS;
            case "CYCLE", "CIRCULAR", "CIRCULAR_FLOW" -> CYCLE;
            case "SWIMLANE", "SWIM_LANE", "LANES" -> SWIMLANE;
            case "HIERARCHY", "ORG", "ORG_CHART", "TREE" -> HIERARCHY;
            case "HUB_SPOKE", "HUB_AND_SPOKE", "RADIAL", "ECOSYSTEM" -> HUB_SPOKE;
            case "PIPELINE", "INPUT_PROCESS_OUTPUT", "IPO" -> PIPELINE;
            case "ARCHITECTURE", "ARCHITECTURE_FLOW", "SYSTEM_FLOW", "INTEGRATION_FLOW" -> ARCHITECTURE_FLOW;
            case "FUNNEL", "FILTER", "FILTERING" -> FUNNEL;
            case "PYRAMID", "LEVELS", "MATURITY" -> PYRAMID;
            case "MATRIX", "MATRIX_2X2", "QUADRANT", "QUADRANT_2X2" -> MATRIX_2X2;
            case "DECISION", "DECISION_TREE", "BRANCHING", "IF_ELSE" -> DECISION_TREE;
            case "FEEDBACK", "FEEDBACK_LOOP", "ITERATION_LOOP" -> FEEDBACK_LOOP;
            case "CONVERGING", "CONVERGING_FLOW", "MERGE_FLOW" -> CONVERGING_FLOW;
            case "DIVERGING", "DIVERGING_FLOW", "SPLIT_FLOW" -> DIVERGING_FLOW;
            case "BEFORE_AFTER", "TRANSFORMATION", "TRANSFORM" -> BEFORE_AFTER;
            case "COMPARISON_FLOW", "SIDE_BY_SIDE_FLOW" -> COMPARISON_FLOW;
            case "ROADMAP", "MILESTONE_ROADMAP" -> ROADMAP;
            default -> NONE;
        };
    }

    public String htmlHint() {
        return name();
    }
}
