package com.formatflow.ai.service;

import org.apache.poi.xddf.usermodel.chart.ChartTypes;

import java.util.Locale;

/**
 * Native editable chart types used by the BNP-green PowerPoint renderer.
 *
 * COLUMN is represented by the OOXML/Apache POI BAR chart family with a
 * column direction; BAR uses the same family with a horizontal direction.
 */
public enum BnpPresentationChartType {
    NONE,
    COLUMN,
    BAR,
    LINE,
    AREA,
    PIE,
    DOUGHNUT,
    SCATTER,
    RADAR;

    public static BnpPresentationChartType fromHint(String value) {
        if (value == null || value.isBlank()) return NONE;
        String normalized = value.trim()
                .toUpperCase(Locale.ROOT)
                .replace('-', '_')
                .replace(' ', '_');
        return switch (normalized) {
            case "COLUMN", "COLUMNS", "COLUMN_CHART", "CLUSTERED_COLUMN" -> COLUMN;
            case "BAR", "BARS", "BAR_CHART", "HORIZONTAL_BAR" -> BAR;
            case "LINE", "LINE_CHART", "TREND" -> LINE;
            case "AREA", "AREA_CHART" -> AREA;
            case "PIE", "PIE_CHART" -> PIE;
            case "DOUGHNUT", "DONUT", "DOUGHNUT_CHART", "DONUT_CHART" -> DOUGHNUT;
            case "SCATTER", "XY", "XY_SCATTER", "SCATTER_CHART" -> SCATTER;
            case "RADAR", "RADAR_CHART", "SPIDER" -> RADAR;
            default -> NONE;
        };
    }

    public ChartTypes poiType() {
        return switch (this) {
            case COLUMN, BAR -> ChartTypes.BAR;
            case LINE -> ChartTypes.LINE;
            case AREA -> ChartTypes.AREA;
            case PIE -> ChartTypes.PIE;
            case DOUGHNUT -> ChartTypes.DOUGHNUT;
            case SCATTER -> ChartTypes.SCATTER;
            case RADAR -> ChartTypes.RADAR;
            case NONE -> ChartTypes.BAR;
        };
    }
}
