package com.formatflow.ai.service;

import org.jsoup.Jsoup;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

class FreeformDocumentRendererTest {

    private final DocumentRenderer renderer = new DocumentRenderer(new IconCatalog());

    @Test
    void sanitizesExecutableMarkupButKeepsConfluenceStructure() {
        String raw = "<h2>About me</h2><script>alert(1)</script><ul><li>Maintain profiles</li></ul>";
        String html = renderer.sanitizeFreeformHtml(raw);

        assertThat(html).contains("<h2>About me</h2>", "<ul>", "Maintain profiles");
        assertThat(html).doesNotContain("<script", "alert(1)");
    }

    @Test
    void emailCopyAddsOnlyDeterministicInlinePresentation() {
        String safe = renderer.sanitizeFreeformHtml("<h2>Status</h2><p>Ready for review.</p><table><tr><th>Item</th><th>Status</th></tr><tr><td>API</td><td>Ready</td></tr></table>");
        String email = renderer.freeformCopyHtml(safe, "EMAIL");

        assertThat(email).contains("font-family:Arial", "border-collapse:collapse", "Ready for review.");
        assertThat(email).doesNotContain("<script", "<style");
    }

    @Test
    void plainTextFallbackKeepsBulletsAndTableRowsReadable() {
        String safe = renderer.sanitizeFreeformHtml("<h2>Actions</h2><ul><li>Review</li><li>Approve</li></ul><table><tr><th>Owner</th><th>Status</th></tr><tr><td>QA</td><td>Open</td></tr></table>");
        String text = renderer.freeformCopyText(safe);

        assertThat(text).contains("Actions", "• Review", "• Approve", "Owner | Status", "QA | Open");
    }

    @Test
    void confluenceCopyCarriesInlineColoursAndTableBorders() {
        String safe = renderer.sanitizeFreeformHtml(
                "<h2>🧪 Testing</h2><p>Coverage details.</p>" +
                "<table><thead><tr><th>Area</th><th>Status</th></tr></thead>" +
                "<tbody><tr><td>API</td><td>Ready</td></tr></tbody></table>");

        String confluence = renderer.freeformCopyHtml(safe, "CONFLUENCE");

        assertThat(confluence)
                .contains("color:#006b36", "border-collapse:collapse", "border=\"1\"",
                        "background-color:#006b36", "🧪 Testing", "API");
        assertThat(confluence).doesNotContain("<script", "<style");
    }

    @Test
    void confluencePreviewAndCopyReuseTheSameCanonicalTree() {
        String safe = renderer.sanitizeFreeformHtml(
                "<h1>Automation Guide</h1><h1>Automation Guide</h1>" +
                "<h1>Execution</h1><ul><li>One</li></ul><ul><li>Two</li></ul>" +
                "<table><tr><th>Step</th><th>Status</th></tr><tr><td>Run</td><td>Ready</td></tr></table>");

        String prepared = renderer.prepareDestinationHtml(safe, "CONFLUENCE");
        String copied = renderer.freeformCopyHtml(prepared, "CONFLUENCE");
        String preview = renderer.freeformPreviewHtml(prepared, "CONFLUENCE", "");
        var doc = Jsoup.parseBodyFragment(prepared);

        assertThat(copied).isEqualTo(prepared);
        assertThat(preview).contains(prepared);
        assertThat(doc.select("h1")).hasSize(1);
        assertThat(doc.select("h2")).extracting(org.jsoup.nodes.Element::text).contains("Execution");
        assertThat(doc.select("ul")).hasSize(1);
        assertThat(doc.select("ul > li")).extracting(org.jsoup.nodes.Element::text).containsExactly("One", "Two");
        assertThat(doc.select("table > thead > tr > th")).hasSize(2);
        assertThat(doc.select("table > tbody > tr")).hasSize(1);
    }

    @Test
    void markdownFallbackRecoversRealConfluenceTableAndCodeBlock() {
        String raw = """
                # Release Notes

                | Component | Version |
                | --- | --- |
                | API | 2.4.1 |
                | UI | 8.0 |

                > Warning: validate before deployment

                ```java
                System.out.println("ready");
                ```
                """;

        String safe = renderer.sanitizeFreeformHtml(raw);
        String confluence = renderer.prepareDestinationHtml(safe, "CONFLUENCE");
        var doc = Jsoup.parseBodyFragment(confluence);

        assertThat(doc.select("table thead th")).extracting(org.jsoup.nodes.Element::text)
                .containsExactly("Component", "Version");
        assertThat(doc.select("table tbody tr")).hasSize(2);
        assertThat(doc.selectFirst("blockquote").text()).startsWith("Warning:");
        assertThat(doc.selectFirst("blockquote strong")).isNotNull();
        assertThat(doc.selectFirst("pre code").text()).contains("System.out.println");
    }

    @Test
    void confluenceCanonicalizationNeverDropsLargeTableRows() {
        StringBuilder html = new StringBuilder("<h2>📋 Cases</h2><table><tr><th>ID</th><th>Status</th></tr>");
        for (int i = 1; i <= 14; i++) {
            html.append("<tr><td>CASE-").append(i).append("</td><td>Ready</td></tr>");
        }
        html.append("</table>");

        String safe = renderer.sanitizeFreeformHtml(html.toString());
        String confluence = renderer.prepareDestinationHtml(safe, "CONFLUENCE");
        var doc = Jsoup.parseBodyFragment(confluence);

        assertThat(doc.select("table tbody tr")).hasSize(14);
        assertThat(confluence).contains("CASE-1", "CASE-14");
    }
}
