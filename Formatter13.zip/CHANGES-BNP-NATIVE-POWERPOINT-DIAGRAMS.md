# BNP Green Native PowerPoint Diagram Engine

This build adds Phase 1 and Phase 2 of the adaptive diagram catalog to the existing BNP-green presentation renderer.

## Architecture

PowerPoint generation now supports a first-class `DIAGRAM` layout. The LLM selects semantic intent; Java validates the requested structure and renders the visual with native PowerPoint/OOXML shapes through Apache POI.

```html
<h2 data-layout="DIAGRAM" data-diagram="SWIMLANE">Test execution handoffs</h2>
<h3>Framework</h3><ul><li>Plan</li><li>Prepare</li></ul>
<h3>Browser</h3><ul><li>Execute</li></ul>
<h3>Validation</h3><ul><li>Compare</li><li>Report</li></ul>
```

No bitmap diagram is generated and no SmartArt dependency is required. The output remains editable in Microsoft PowerPoint because the renderer uses standard shapes and text objects.

## Supported diagram catalog

### Phase 1

- LINEAR_PROCESS
- CHEVRON_PROCESS
- CYCLE
- SWIMLANE
- HIERARCHY
- HUB_SPOKE
- PIPELINE
- ARCHITECTURE_FLOW
- FUNNEL
- PYRAMID
- MATRIX_2X2

### Phase 2

- DECISION_TREE
- FEEDBACK_LOOP
- CONVERGING_FLOW
- DIVERGING_FLOW
- BEFORE_AFTER
- COMPARISON_FLOW
- ROADMAP

## Content-aware selection

The model is instructed to choose a diagram only when the source relationship warrants it. Java also has conservative title/content inference when `data-diagram` is absent. Examples:

- workflow / sequence -> LINEAR_PROCESS
- phases / stages -> CHEVRON_PROCESS
- lifecycle / recurring process -> CYCLE
- role handoffs -> SWIMLANE
- parent-child/reporting structure -> HIERARCHY
- central system + integrations -> HUB_SPOKE
- input/process/output -> PIPELINE
- component/system integration -> ARCHITECTURE_FLOW
- filtering/narrowing -> FUNNEL
- levels/maturity -> PYRAMID
- 2x2 classification -> MATRIX_2X2
- branching decision -> DECISION_TREE
- retry/self-healing/iteration -> FEEDBACK_LOOP
- many inputs to one outcome -> CONVERGING_FLOW
- one input to many outputs -> DIVERGING_FLOW
- current vs future state -> BEFORE_AFTER
- two parallel alternatives -> COMPARISON_FLOW
- ordered delivery milestones -> ROADMAP

## Structure validation

The deterministic review stage validates both the diagram type and its expected body structure. Examples:

- SWIMLANE: 2-4 H3 lane groups
- MATRIX_2X2: exactly 4 H3 quadrant groups
- BEFORE_AFTER / COMPARISON_FLOW: exactly 2 H3 groups
- HIERARCHY / DECISION_TREE: 2-4 H3 branch groups
- sequence/cycle/pipeline/funnel/pyramid/roadmap families: 3-6 list items

Invalid or missing metadata does not crash export. Java falls back to a safe diagram or conventional slide layout while preserving source content.

## Overflow handling

Diagram content is paginated before rendering:

- linear/cycle/roadmap-style diagrams are split into continuation slides when node count is too large;
- swimlanes are limited to four lanes per slide;
- hierarchy/decision/matrix families are split by branch/group;
- long subsection content is split into continued groups instead of being truncated.

## Regression coverage

Added tests cover:

- `data-diagram` surviving sanitization;
- all 18 Phase 1/2 diagram types in generated PPTX;
- diagram overflow continuation slides;
- source text preservation through diagrams;
- local diagram inference when LLM metadata is absent;
- catalog consistency across prompt, review, parser and renderer.

The existing native chart engine, Confluence canonical renderer and 10-attempt LLM retry behavior remain unchanged.
