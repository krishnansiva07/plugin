import { test, expect } from '@playwright/test';
import { AI } from '../../src/framework/AI';
import { shouldRunSampleTest } from '../../src/core/execution/ExecutionFilter';

const meta = { testId: 'TC_AI_001', testName: 'Login using LLM prompts', suite: 'Execution Styles', tags: ['ai', 'prompt'] };

if (shouldRunSampleTest(meta)) {
  test.describe(meta.suite, () => {
    test(`[${meta.testId}] ${meta.testName} @ai @prompt`, async ({ page }) => {
      const ai = AI.on(page);
      await ai.prompt('Open the application');
      await ai.prompt('Enter standard_user into the Username field');
      await ai.prompt('Enter secret_sauce into the Password field');
      await ai.prompt('Click the Login button');
      await expect(page.getByTestId('title')).toHaveText('Products');
    });
  });
}
