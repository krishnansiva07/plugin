import { test, expect } from '@playwright/test';
import { AI } from '../../src/framework/AI';
import { shouldRunSampleTest } from '../../src/core/execution/ExecutionFilter';

const meta = {
  testId: 'TC_TS_FALLBACK_001',
  testName: 'TypeScript DSL with two fallback strategies for two elements',
  suite: 'Execution Styles',
  tags: ['typescript', 'fallback']
};

if (shouldRunSampleTest(meta)) {
  test.describe(meta.suite, () => {
    test(`[${meta.testId}] ${meta.testName} @typescript @fallback`, async ({ page }) => {
      const ai = AI.on(page);
      await page.goto('/');

      // Element 1: Username. Normal DSL resolution runs first, then these two fallbacks.
      await ai.fill('Username', 'standard_user', {
        fallback: [
          async ({ page }) => page.locator('input[name="user-name"]').fill('standard_user'),
          async ({ page }) => page.locator('#user-name').fill('standard_user')
        ],
        validate: async currentPage => {
          await expect(currentPage.getByTestId('username')).toHaveValue('standard_user');
        }
      });

      await ai.fill('Password', 'secret_sauce');

      // Element 2: Login. Both fallbacks use normal Playwright clicks; force is not used.
      await ai.click('Login', {
        fallback: [
          async ({ page }) => page.getByRole('button', { name: 'Login', exact: true }).click(),
          async ({ page }) => page.locator('input[type="submit"]').click()
        ],
        validate: async currentPage => {
          await expect(currentPage.getByTestId('title')).toHaveText('Products');
        },
        allowLlmHealing: true,
        allowForce: false
      });
    });
  });
}
