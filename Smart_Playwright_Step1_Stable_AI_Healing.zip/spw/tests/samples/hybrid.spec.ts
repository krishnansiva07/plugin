import { test, expect } from '@playwright/test';
import { AI } from '../../src/framework/AI';
import { shouldRunSampleTest } from '../../src/core/execution/ExecutionFilter';

const meta = { testId: 'TC_HYBRID_001', testName: 'Combine LLM prompt, DSL and native Playwright', suite: 'Execution Styles', tags: ['ai', 'hybrid'] };

if (shouldRunSampleTest(meta)) {
  test.describe(meta.suite, () => {
    test(`[${meta.testId}] ${meta.testName} @ai @hybrid`, async ({ page }) => {
      const ai = AI.on(page);

      await ai.prompt('Open the application');                       // Always goes to LLM
      await ai.fill('Username', 'standard_user');                    // Framework TypeScript DSL
      await ai.native('Fill password', async currentPage => {        // Native Playwright
        await currentPage.getByTestId('password').fill('secret_sauce');
      });
      await ai.prompt('Click the Login button');                     // Always goes to LLM

      await expect(page.getByTestId('title')).toHaveText('Products');
    });
  });
}
