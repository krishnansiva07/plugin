import { test, expect } from '@playwright/test';
import { AI } from '../../src/framework/AI';
import { shouldRunSampleTest } from '../../src/core/execution/ExecutionFilter';

const meta = { testId: 'TC_DSL_001', testName: 'Login using framework TypeScript DSL', suite: 'Execution Styles', tags: ['smoke', 'dsl'] };

if (shouldRunSampleTest(meta)) {
  test.describe(meta.suite, () => {
    test(`[${meta.testId}] ${meta.testName} @smoke @dsl`, async ({ page }) => {
      const ai = AI.on(page);
      await page.goto('/');
      await ai.fill('Username', 'standard_user');
      await ai.fill('Password', 'secret_sauce');
      await ai.click('Login');
      await expect(page.getByTestId('title')).toHaveText('Products');
    });
  });
}
