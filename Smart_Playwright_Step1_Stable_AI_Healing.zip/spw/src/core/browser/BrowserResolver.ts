import { existsSync, statSync } from 'node:fs';
import { execSync } from 'node:child_process';
import path from 'node:path';
import os from 'node:os';

export type BrowserName = 'chrome' | 'edge' | 'custom';
export type BrowserPreference = 'auto' | BrowserName;

export interface BrowserInstallation {
  name: BrowserName;
  displayName: string;
  executablePath: string;
  version: string;
  source: string;
}

function isExecutableFile(filePath: string): boolean {
  try {
    return existsSync(filePath) && statSync(filePath).isFile();
  } catch {
    return false;
  }
}

function unique(values: Array<string | undefined>): string[] {
  return [...new Set(values.filter((value): value is string => Boolean(value?.trim())).map(value => path.normalize(value.trim())))];
}

function safeVersion(executablePath: string): string {
  // Never execute the browser binary to detect its version. On managed Windows
  // machines, chrome.exe --version can launch a visible empty browser window.
  // Version detection is therefore opt-in and uses file metadata only.
  if ((process.env.BROWSER_VERSION_DETECTION ?? 'false').toLowerCase() !== 'true') {
    return 'Detection disabled';
  }

  if (process.platform === 'win32') {
    try {
      const escaped = executablePath.replace(/'/g, "''");
      const command = `(Get-Item -LiteralPath '${escaped}').VersionInfo.ProductVersion`;
      const output = execSync(`powershell -NoProfile -NonInteractive -Command "${command}"`, {
        encoding: 'utf8',
        windowsHide: true,
        timeout: 5000
      }).trim();
      return output || 'Unable to read';
    } catch {
      return 'Unable to read';
    }
  }

  return 'Detection disabled';
}

function windowsRegistryPath(executableName: string): string | undefined {
  if (process.platform !== 'win32') return undefined;
  const keys = [
    `HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\App Paths\\${executableName}`,
    `HKLM\\SOFTWARE\\WOW6432Node\\Microsoft\\Windows\\CurrentVersion\\App Paths\\${executableName}`,
    `HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\App Paths\\${executableName}`
  ];
  for (const key of keys) {
    try {
      const output = execSync(`reg query "${key}" /ve`, { encoding: 'utf8', windowsHide: true });
      const match = output.match(/REG_SZ\s+(.+)$/m);
      if (match && isExecutableFile(match[1].trim())) return match[1].trim();
    } catch {
      // Continue to the next registry key.
    }
  }
  return undefined;
}

function commandPath(command: string): string | undefined {
  try {
    const locator = process.platform === 'win32' ? `where ${command}` : `command -v ${command}`;
    const first = execSync(locator, { encoding: 'utf8', windowsHide: true })
      .split(/\r?\n/)
      .map(value => value.trim())
      .find(Boolean);
    return first && isExecutableFile(first) ? first : undefined;
  } catch {
    return undefined;
  }
}

function chromeCandidates(): string[] {
  const home = os.homedir();
  if (process.platform === 'win32') {
    return unique([
      process.env.PROGRAMFILES ? path.join(process.env.PROGRAMFILES, 'Google', 'Chrome', 'Application', 'chrome.exe') : undefined,
      process.env['PROGRAMFILES(X86)'] ? path.join(process.env['PROGRAMFILES(X86)'], 'Google', 'Chrome', 'Application', 'chrome.exe') : undefined,
      process.env.LOCALAPPDATA ? path.join(process.env.LOCALAPPDATA, 'Google', 'Chrome', 'Application', 'chrome.exe') : undefined,
      windowsRegistryPath('chrome.exe'),
      commandPath('chrome.exe')
    ]);
  }
  if (process.platform === 'darwin') {
    return ['/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'];
  }
  return unique([
    '/usr/bin/google-chrome',
    '/usr/bin/google-chrome-stable',
    '/usr/bin/chromium',
    '/usr/bin/chromium-browser',
    path.join(home, '.local/bin/google-chrome'),
    commandPath('google-chrome'),
    commandPath('chromium')
  ]);
}

function edgeCandidates(): string[] {
  if (process.platform === 'win32') {
    return unique([
      process.env.PROGRAMFILES ? path.join(process.env.PROGRAMFILES, 'Microsoft', 'Edge', 'Application', 'msedge.exe') : undefined,
      process.env['PROGRAMFILES(X86)'] ? path.join(process.env['PROGRAMFILES(X86)'], 'Microsoft', 'Edge', 'Application', 'msedge.exe') : undefined,
      process.env.LOCALAPPDATA ? path.join(process.env.LOCALAPPDATA, 'Microsoft', 'Edge', 'Application', 'msedge.exe') : undefined,
      windowsRegistryPath('msedge.exe'),
      commandPath('msedge.exe')
    ]);
  }
  if (process.platform === 'darwin') {
    return ['/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge'];
  }
  return unique(['/usr/bin/microsoft-edge', '/usr/bin/microsoft-edge-stable', commandPath('microsoft-edge')]);
}

function firstInstalled(candidates: string[]): string | undefined {
  return candidates.find(isExecutableFile);
}

export function detectInstalledBrowsers(): BrowserInstallation[] {
  const installations: BrowserInstallation[] = [];
  const chromePath = firstInstalled(chromeCandidates());
  if (chromePath) {
    installations.push({
      name: 'chrome',
      displayName: chromePath.toLowerCase().includes('chromium') ? 'Chromium' : 'Google Chrome',
      executablePath: chromePath,
      version: safeVersion(chromePath),
      source: 'installed-path'
    });
  }
  const edgePath = firstInstalled(edgeCandidates());
  if (edgePath) {
    installations.push({
      name: 'edge',
      displayName: 'Microsoft Edge',
      executablePath: edgePath,
      version: safeVersion(edgePath),
      source: 'installed-path'
    });
  }
  return installations;
}

export function resolveBrowser(
  preference: BrowserPreference,
  priority: Array<'chrome' | 'edge'>,
  customExecutablePath?: string
): BrowserInstallation {
  if (preference === 'custom') {
    const value = customExecutablePath?.trim();
    if (!value || !isExecutableFile(value)) {
      throw new Error(`BROWSER=custom requires a valid BROWSER_EXECUTABLE_PATH. Received: ${value || '<empty>'}`);
    }
    return {
      name: 'custom',
      displayName: 'Custom Chromium',
      executablePath: path.normalize(value),
      version: safeVersion(value),
      source: 'custom-path'
    };
  }

  const installed = detectInstalledBrowsers();
  if (preference === 'chrome' || preference === 'edge') {
    const selected = installed.find(browser => browser.name === preference);
    if (!selected) throw new Error(`Requested ${preference} browser is not installed or could not be detected.`);
    return selected;
  }

  for (const requested of priority) {
    const selected = installed.find(browser => browser.name === requested);
    if (selected) return selected;
  }
  throw new Error('No supported installed browser found. Install Chrome/Edge or configure BROWSER=custom with BROWSER_EXECUTABLE_PATH.');
}
