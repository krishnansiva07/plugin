import { test, type Locator, type Page } from '@playwright/test';
import { envBoolean } from '../../utils/Environment';
import { LocatorHealingService } from '../../healing/LocatorHealingService';

export interface LocatorCandidate {
  name: string;
  locator: () => Locator;
}

export interface SmartElement {
  description: string;
  target: string;
  primary: LocatorCandidate;
  fallbacks?: LocatorCandidate[];
}

export interface FallbackContext {
  page: Page;
  description: string;
  target: string;
  value?: string;
  originalError: Error;
  previousErrors: Error[];
}

export type CustomFallback = (context: FallbackContext) => Promise<void>;

export interface ActionOptions {
  fallback?: CustomFallback | CustomFallback[];
  validate?: (page: Page) => Promise<void>;
  allowLlmHealing?: boolean;
  allowForce?: boolean;
  timeout?: number;
}

export class SmartActions {
  private readonly healing: LocatorHealingService;
  private readonly forceGloballyAllowed = envBoolean('ALLOW_FORCE_ACTIONS', false);

  constructor(private readonly page: Page) {
    this.healing = new LocatorHealingService(page);
  }

  async fill(element: SmartElement, value: string, options: ActionOptions = {}): Promise<boolean> {
    return this.execute(element, 'fill', value, async locator => locator.fill(value, { timeout: options.timeout }), options);
  }

  async click(element: SmartElement, options: ActionOptions = {}): Promise<boolean> {
    return this.execute(element, 'click', undefined, async locator => locator.click({ timeout: options.timeout }), options);
  }

  async hover(element: SmartElement, options: ActionOptions = {}): Promise<boolean> {
    return this.execute(element, 'hover', undefined, async locator => locator.hover({ timeout: options.timeout }), options);
  }

  private async execute(
    element: SmartElement,
    action: string,
    value: string | undefined,
    operation: (locator: Locator) => Promise<void>,
    options: ActionOptions
  ): Promise<boolean> {
    const errors: Error[] = [];
    const attemptedStrategies: string[] = [];
    const candidates = [element.primary, ...(element.fallbacks ?? [])];

    for (let index = 0; index < candidates.length; index += 1) {
      const candidate = candidates[index];
      attemptedStrategies.push(candidate.name);
      try {
        const locator = candidate.locator();
        await this.requireUniqueVisible(locator, candidate.name);
        await operation(locator.first());
        await options.validate?.(this.page);
        if (index > 0) this.annotate('deterministic-healing', `${element.description} using ${candidate.name}`);
        return index > 0;
      } catch (error) {
        errors.push(this.wrapError(candidate.name, error));
      }
    }

    const customFallbacks = options.fallback
      ? (Array.isArray(options.fallback) ? options.fallback : [options.fallback])
      : [];

    for (let index = 0; index < customFallbacks.length; index += 1) {
      const strategy = `custom fallback ${index + 1}`;
      attemptedStrategies.push(strategy);
      try {
        await customFallbacks[index]({
          page: this.page,
          description: element.description,
          target: element.target,
          value,
          originalError: errors.at(-1) ?? new Error(`Unable to execute ${element.description}`),
          previousErrors: [...errors]
        });
        await options.validate?.(this.page);
        this.annotate('custom-fallback', `${element.description} using ${strategy}`);
        return true;
      } catch (error) {
        errors.push(this.wrapError(strategy, error));
      }
    }

    if (options.allowLlmHealing !== false && this.healing.enabled) {
      attemptedStrategies.push('LLM locator healing');
      try {
        const healed = await this.healing.heal({
          instruction: element.description,
          action,
          target: element.target,
          value,
          failedStrategies: attemptedStrategies,
          errors
        });
        await operation(healed.locator);
        await options.validate?.(this.page);
        console.log(`[LLM HEALING] SUCCESS strategy=${healed.suggestion.strategy} confidence=${healed.suggestion.confidence} reason=${healed.suggestion.reason}`);
        this.annotate('llm-healing', `${element.description}; ${healed.suggestion.strategy}; confidence=${healed.suggestion.confidence}`);
        return true;
      } catch (error) {
        errors.push(this.wrapError('LLM locator healing', error));
      }
    }

    if (options.allowForce) {
      if (!this.forceGloballyAllowed) {
        errors.push(new Error('Force action requested but ALLOW_FORCE_ACTIONS=false'));
      } else if (action !== 'click') {
        errors.push(new Error(`Force mode is supported only for click, not ${action}`));
      } else {
        try {
          await element.primary.locator().first().click({ force: true, timeout: options.timeout });
          await options.validate?.(this.page);
          this.annotate('force-action', element.description);
          return true;
        } catch (error) {
          errors.push(this.wrapError('force action', error));
        }
      }
    }

    throw new AggregateError(errors, `All strategies failed for ${element.description}`);
  }

  private async requireUniqueVisible(locator: Locator, strategy: string): Promise<void> {
    const count = await locator.count();
    if (count !== 1) throw new Error(`${strategy} matched ${count} elements; expected exactly one`);
    if (!await locator.isVisible()) throw new Error(`${strategy} matched an element that is not visible`);
  }

  private annotate(type: string, description: string): void {
    console.log(`[${type.toUpperCase()}] ${description}`);
    try { test.info().annotations.push({ type, description }); } catch { /* outside test context */ }
  }

  private wrapError(strategy: string, error: unknown): Error {
    const normalized = error instanceof Error ? error : new Error(String(error));
    return new Error(`${strategy}: ${normalized.message}`, { cause: normalized });
  }
}
