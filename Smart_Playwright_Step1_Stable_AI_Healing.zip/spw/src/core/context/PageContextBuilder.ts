import type { Page } from '@playwright/test';
import { envNumber } from '../../utils/Environment';

export interface PageHealingContext {
  pageTitle: string;
  pageUrl: string;
  accessibilityContext: string;
  relevantDom: string;
}

export class PageContextBuilder {
  constructor(private readonly page: Page) {}

  async build(): Promise<PageHealingContext> {
    const maxLength = envNumber('LLM_DOM_MAX_LENGTH', 20000);
    const [pageTitle, relevantDom, accessibilityContext] = await Promise.all([
      this.page.title().catch(() => ''),
      this.page.locator('body').innerHTML().catch(() => ''),
      this.buildAccessibleElements().catch(() => '')
    ]);

    return {
      pageTitle,
      pageUrl: this.page.url(),
      accessibilityContext: accessibilityContext.slice(0, maxLength),
      relevantDom: relevantDom.slice(0, maxLength)
    };
  }

  private async buildAccessibleElements(): Promise<string> {
    return this.page.locator('body').evaluate(() => {
      const selectors = [
        'button', 'a', 'input', 'select', 'textarea',
        '[role]', '[aria-label]', '[data-testid]', '[data-test]'
      ];
      const nodes = Array.from(document.querySelectorAll(selectors.join(','))).slice(0, 500);
      return nodes.map((node, index) => {
        const element = node as HTMLElement;
        const input = node as HTMLInputElement;
        const rect = element.getBoundingClientRect();
        const visible = rect.width > 0 && rect.height > 0;
        const role = element.getAttribute('role') || element.tagName.toLowerCase();
        const name = element.getAttribute('aria-label')
          || element.getAttribute('data-testid')
          || element.getAttribute('data-test')
          || input.placeholder
          || input.name
          || element.innerText?.trim()
          || input.value
          || '';
        return `${index + 1}. role=${role}; name=${JSON.stringify(name.slice(0, 180))}; visible=${visible}; box=${Math.round(rect.x)},${Math.round(rect.y)},${Math.round(rect.width)},${Math.round(rect.height)}`;
      }).join('\n');
    });
  }
}
