import { envBoolean } from '../../utils/Environment';

export interface FilterableTest {
  testId: string;
  testName: string;
  suite?: string;
  tags?: string[];
}

function values(name: string): string[] {
  return (process.env[name] ?? '')
    .split(',')
    .map(value => value.trim().toLowerCase())
    .filter(Boolean);
}

function anyContains(actual: string, requested: string[]): boolean {
  const normalized = actual.toLowerCase();
  return requested.length === 0 || requested.some(value => normalized.includes(value));
}

export function hasExecutionFilter(): boolean {
  return ['PW_FILTER_TEST_IDS', 'PW_FILTER_TEST_NAMES', 'PW_FILTER_SUITES', 'PW_FILTER_TAGS']
    .some(name => values(name).length > 0);
}

export function shouldRunTest(test: FilterableTest): boolean {
  const ids = values('PW_FILTER_TEST_IDS');
  const names = values('PW_FILTER_TEST_NAMES');
  const suites = values('PW_FILTER_SUITES');
  const tags = values('PW_FILTER_TAGS').map(tag => tag.replace(/^@/, ''));
  const actualTags = (test.tags ?? []).map(tag => tag.toLowerCase().replace(/^@/, ''));

  return anyContains(test.testId, ids)
    && anyContains(test.testName, names)
    && anyContains(test.suite ?? '', suites)
    && (tags.length === 0 || tags.some(tag => actualTags.includes(tag)));
}

/** Samples do not run during plain `npm test` unless RUN_SAMPLE_TESTS=true. They still run when explicitly selected by any filter. */
export function shouldRunSampleTest(test: FilterableTest): boolean {
  if (!hasExecutionFilter() && !envBoolean('RUN_SAMPLE_TESTS', false)) return false;
  return shouldRunTest(test);
}
