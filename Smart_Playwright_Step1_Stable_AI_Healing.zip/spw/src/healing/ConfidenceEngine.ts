import type { Locator } from '@playwright/test';
import { envBoolean, envNumber } from '../utils/Environment';
import type { HealingSuggestion } from '../llm/LlmClient';

export class ConfidenceEngine {
  private readonly minimumConfidence = envNumber('LLM_MIN_CONFIDENCE', 0.90);
  private readonly failOnAmbiguous = envBoolean('FAIL_ON_AMBIGUOUS_LOCATOR', true);

  async validate(suggestion: HealingSuggestion, locator: Locator): Promise<void> {
    if (suggestion.confidence < this.minimumConfidence) {
      throw new Error(`LLM confidence ${suggestion.confidence} is below LLM_MIN_CONFIDENCE=${this.minimumConfidence}`);
    }

    const count = await locator.count();
    if (this.failOnAmbiguous && count !== 1) {
      throw new Error(`LLM locator resolved to ${count} elements; expected exactly one`);
    }
    if (count < 1) throw new Error('LLM locator resolved to no elements');

    const candidate = locator.first();
    if (!await candidate.isVisible()) throw new Error('LLM-selected element is not visible');
    if (!await candidate.isEnabled().catch(() => true)) throw new Error('LLM-selected element is disabled');
  }
}
