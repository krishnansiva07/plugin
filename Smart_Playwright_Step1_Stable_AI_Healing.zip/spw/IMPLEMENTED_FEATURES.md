# Implemented features

- True LLM prompt execution through `AI.prompt()` and `AI.step()`.
- Structured, confidence-checked LLM action plans; no regex-based prompt parsing in `AI.ts`.
- Framework TypeScript DSL for click, fill, select, hover and assertions.
- Native Playwright support and a hybrid API mixing strings and Playwright functions.
- Multiple custom TypeScript fallback strategies per action.
- Post-action validation after deterministic, custom and LLM recovery paths.
- LLM locator healing after deterministic and custom fallback failure.
- Force-click safety gate disabled by default.
- Comma-separated test ID, tag, test-name and suite filters.
- Sample tests excluded from plain `npm test` unless explicitly enabled or filtered.
- Configurable headed/headless execution, workers, retries and sample execution.
- Automatic corporate PEM/CRT/CER discovery from `certificates/`.
