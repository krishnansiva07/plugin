# Step 1 implementation

## Included

- `ai.prompt()` always calls the configured LangChain LLM and accepts one natural-language action.
- `ai.click()`, `ai.fill()`, `ai.select()` and `ai.hover()` provide deterministic TypeScript DSL actions.
- Native Playwright remains available in the same test and can be mixed with prompts and DSL calls.
- Deterministic locator candidates run first.
- One or more custom TypeScript fallbacks run next.
- LLM locator healing runs after deterministic and custom fallbacks fail.
- LLM locator recommendations are structured and validated for confidence, uniqueness, visibility and enabled state.
- Post-action validation can be supplied for every action.
- Force click remains opt-in in both code and environment configuration.
- Test ID, tag, test name and suite filters support comma-separated values.
- Browser version detection no longer starts the browser executable. This removes the empty Chrome/Edge windows that could be opened by `chrome.exe --version` on Windows.

## Browser lifecycle configuration

```env
WORKERS=1
RETRIES=0
HEADLESS=false
BROWSER_VERSION_DETECTION=false
```

`npm test` runs every enabled project test. Each test gets an isolated browser context, but with `WORKERS=1` they run sequentially. Sample tests remain excluded unless explicitly selected or `RUN_SAMPLE_TESTS=true`.

## Commands

```bash
npm test
npm test -- --testid=TC_AI_001
npm test -- --testid=TC_DSL_001,TC_PW_001,TC_HYBRID_001
npm test -- --tag=smoke,regression
npm test -- --suite="Execution Styles,SauceDemo Login"
npm test -- --testname="LLM prompts,native Playwright"
```

## LLM prompt

```ts
const ai = AI.on(page);
await ai.prompt('Enter standard_user into the Username field');
await ai.prompt('Click the Login button');
```

## TypeScript DSL

```ts
await ai.fill('Username', 'standard_user');
await ai.fill('Password', 'secret_sauce');
await ai.click('Login');
```

## Native Playwright

```ts
await page.getByTestId('username').fill('standard_user');
await page.getByTestId('login-button').click();
```

## Hybrid

```ts
const ai = AI.on(page);
await ai.prompt('Open the application');
await ai.fill('Username', 'standard_user');
await page.getByTestId('password').fill('secret_sauce');
await ai.prompt('Click the Login button');
```

## Two custom fallback strategies

```ts
await ai.click('Login', {
  fallback: [
    async ({ page }) => {
      await page.getByRole('button', { name: 'Login', exact: true }).click();
    },
    async ({ page }) => {
      await page.locator('input[type="submit"]').click();
    }
  ],
  validate: async page => {
    await expect(page.getByTestId('title')).toHaveText('Products');
  },
  allowLlmHealing: true,
  allowForce: false
});
```

Execution order:

```text
primary locator
→ deterministic locators
→ custom fallback 1
→ custom fallback 2
→ LLM locator healing
→ optional force click
→ failure
```
