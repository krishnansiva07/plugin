$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $PSScriptRoot
$CertDir = Join-Path $Root 'certificates'
$Names = @('cacert','cacert.pem','cacerts','corporate-ca.pem','corporate-ca.crt','corporate-ca.cer')
$Cert = $null
foreach ($Name in $Names) {
  $Candidate = Join-Path $CertDir $Name
  if (Test-Path $Candidate -PathType Leaf) { $Cert = (Resolve-Path $Candidate).Path; break }
}
if (-not $Cert -and (Test-Path $CertDir -PathType Container)) {
  $Discovered = Get-ChildItem -Path $CertDir -File |
    Where-Object { $_.Extension -match '^\.(pem|crt|cer)$' } |
    Sort-Object Name |
    Select-Object -First 1
  if ($Discovered) { $Cert = $Discovered.FullName }
}
if ($Cert) {
  $Text = Get-Content -Raw -Path $Cert
  if ($Text -notmatch '-----BEGIN CERTIFICATE-----') {
    throw "Certificate file is not PEM text: $Cert"
  }
  $env:NODE_EXTRA_CA_CERTS = $Cert
  npm config set cafile "$Cert" --location=project
  Write-Host "[PASS] Corporate CA configured: $Cert" -ForegroundColor Green
} else {
  Write-Host '[WARN] No PEM/CRT/CER certificate found in certificates/. npm will use its default trust store.' -ForegroundColor Yellow
}
Set-Location $Root
npm ci
npm run typecheck
Write-Host ''
Write-Host '[PASS] Setup complete. Run: npm test' -ForegroundColor Green
