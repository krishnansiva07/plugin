import { existsSync, readFileSync, readdirSync } from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';

const root = path.resolve(__dirname, '..');
const certificateDir = path.join(root, 'certificates');
const preferredCertificateNames = [
  'cacert', 'cacert.pem', 'cacerts', 'corporate-ca.pem', 'corporate-ca.crt', 'corporate-ca.cer'
];

function resolveCertificate(): string | undefined {
  for (const name of preferredCertificateNames) {
    const candidate = path.join(certificateDir, name);
    if (existsSync(candidate)) return candidate;
  }

  if (!existsSync(certificateDir)) return undefined;
  const discovered = readdirSync(certificateDir)
    .filter(name => /\.(pem|crt|cer)$/i.test(name))
    .sort((a, b) => a.localeCompare(b));
  return discovered.length ? path.join(certificateDir, discovered[0]) : undefined;
}

function readOption(args: string[], names: string[], npmConfigName?: string): string | undefined {
  const collected: string[] = [];
  for (let index = 0; index < args.length; index += 1) {
    const current = args[index];
    for (const name of names) {
      if (current === `--${name}` && args[index + 1]) collected.push(args[index + 1]);
      if (current.startsWith(`--${name}=`)) collected.push(current.slice(name.length + 3));
    }
  }
  const npmValue = npmConfigName ? process.env[`npm_config_${npmConfigName}`] : undefined;
  if (npmValue) collected.push(npmValue);
  return collected.length ? collected.join(',') : undefined;
}

function removeFrameworkOptions(args: string[]): string[] {
  const supported = new Set([
    'testid', 'test-id', 'tag', 'tags', 'testname', 'test-name', 'suite', 'suite-name'
  ]);
  const result: string[] = [];
  for (let index = 0; index < args.length; index += 1) {
    const current = args[index];
    if (!current.startsWith('--')) { result.push(current); continue; }
    const optionName = current.slice(2).split('=')[0];
    if (!supported.has(optionName)) { result.push(current); continue; }
    if (!current.includes('=') && args[index + 1] && !args[index + 1].startsWith('--')) index += 1;
  }
  return result;
}

function normalizeList(value?: string): string {
  return (value ?? '').split(',').map(item => item.trim()).filter(Boolean).join(',');
}

function applyExecutionFilters(args: string[], targetEnv: NodeJS.ProcessEnv): void {
  const filters = {
    PW_FILTER_TEST_IDS: normalizeList(readOption(args, ['testid', 'test-id'], 'testid')),
    PW_FILTER_TAGS: normalizeList(readOption(args, ['tag', 'tags'], 'tag')),
    PW_FILTER_TEST_NAMES: normalizeList(readOption(args, ['testname', 'test-name'], 'testname')),
    PW_FILTER_SUITES: normalizeList(readOption(args, ['suite', 'suite-name'], 'suite'))
  };
  for (const [key, value] of Object.entries(filters)) {
    if (value) { targetEnv[key] = value; console.log(`[FILTER] ${key}=${value}`); }
  }
}

const certificate = resolveCertificate();
const mode = process.argv[2] ?? 'test';
const incomingArgs = process.argv.slice(3);
const env = { ...process.env };

if (certificate) {
  const content = readFileSync(certificate, 'utf8');
  if (!content.includes('-----BEGIN CERTIFICATE-----')) {
    console.error(`[CERTIFICATE] ${certificate} is not PEM text. It must contain -----BEGIN CERTIFICATE-----.`);
    process.exit(2);
  }
  env.NODE_EXTRA_CA_CERTS = certificate;
  console.log(`[CERTIFICATE] Using corporate CA: ${certificate}`);
} else {
  console.log('[CERTIFICATE] No PEM/CRT/CER file found in certificates/. Continuing with the default Node trust store.');
}

const playwrightCli = path.join(root, 'node_modules', '@playwright', 'test', 'cli.js');
const preflight = path.join(root, 'scripts', 'preflight.ts');
let command: string;
let args: string[];

if (mode === 'preflight') {
  command = process.execPath;
  args = [path.join(root, 'node_modules', 'tsx', 'dist', 'cli.mjs'), preflight];
} else {
  command = process.execPath;
  args = [playwrightCli, 'test'];
  if (mode === 'debug') args.push('--debug');

  applyExecutionFilters(incomingArgs, env);
  args.push(...removeFrameworkOptions(incomingArgs));
}

const result = spawnSync(command, args, { cwd: root, env, stdio: 'inherit', windowsHide: false });
if (result.error) {
  console.error(result.error);
  process.exit(1);
}
process.exit(result.status ?? 1);
