import { defineConfig } from '@playwright/test';
import { env, envBoolean, envNumber } from './src/utils/Environment';
import { resolveBrowser, type BrowserPreference } from './src/core/browser/BrowserResolver';

const preference = (env('BROWSER', 'auto').toLowerCase() || 'auto') as BrowserPreference;
const priority = env('BROWSER_PRIORITY', 'chrome,edge')
  .split(',')
  .map(value => value.trim().toLowerCase())
  .filter((value): value is 'chrome' | 'edge' => value === 'chrome' || value === 'edge');
const browser = resolveBrowser(preference, priority.length ? priority : ['chrome', 'edge'], env('BROWSER_EXECUTABLE_PATH'));

console.log('\n============================================================');
console.log(' SMART PLAYWRIGHT JSON FRAMEWORK');
console.log('============================================================');
console.log(` Environment      : ${env('ENVIRONMENT', 'QA')}`);
console.log(` Base URL         : ${env('BASE_URL', 'https://www.saucedemo.com/')}`);
console.log(` Browser request  : ${preference}`);
console.log(` Selected browser : ${browser.displayName}`);
console.log(` Browser version  : ${browser.version}`);
console.log(` Browser path     : ${browser.executablePath}`);
console.log(` Execution mode   : ${envBoolean('HEADLESS', false) ? 'Headless' : 'Headed'}`);
console.log(` Workers          : ${envNumber('WORKERS', 1)}`);
console.log(` AI prompts       : ${envBoolean('LLM_ENABLED', false) ? 'Enabled' : 'Disabled'}`);
console.log(` Self-healing     : ${envBoolean('LLM_ENABLED', false) ? 'Deterministic + custom fallback + LLM' : 'Deterministic + custom fallback'}`);
console.log(` Sample tests     : ${envBoolean('RUN_SAMPLE_TESTS', false) ? 'Included in npm test' : 'Only when filtered explicitly'}`);
console.log('============================================================\n');

export default defineConfig({
  testDir: './tests',
  timeout: 45_000,
  expect: { timeout: 10_000 },
  fullyParallel: false,
  workers: envNumber('WORKERS', 1),
  retries: envNumber('RETRIES', process.env.CI ? 1 : 0),
  forbidOnly: Boolean(process.env.CI),
  outputDir: 'test-results/artifacts',
  metadata: {
    projectName: 'Smart Playwright JSON Framework',
    environment: env('ENVIRONMENT', 'QA'),
    selectedBrowser: `${browser.displayName} ${browser.version}`.trim()
  },
  reporter: [
    ['line'],
    ['junit', { outputFile: 'test-results/junit.xml' }],
    ['./src/reporting/SmartHtmlReporter.ts']
  ],
  use: {
    baseURL: env('BASE_URL', 'https://www.saucedemo.com/'),
    browserName: 'chromium',
    headless: envBoolean('HEADLESS', false),
    viewport: { width: 1440, height: 900 },
    ignoreHTTPSErrors: true,
    testIdAttribute: 'data-test',
    screenshot: env('SCREENSHOT', 'only-on-failure') as 'off' | 'on' | 'only-on-failure',
    trace: env('TRACE', 'retain-on-failure') as 'off' | 'on' | 'retain-on-failure' | 'on-first-retry',
    video: envBoolean('RECORD_VIDEO', false) ? 'retain-on-failure' : 'off',
    launchOptions: {
      executablePath: browser.executablePath,
      slowMo: envNumber('SLOW_MO', 250),
      args: []
    }
  }
});
