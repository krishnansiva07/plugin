#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
JAR="target/eliya.jar"
if [ ! -f "$JAR" ]; then
  echo "JAR not found. Building application..."
  ./mvnw clean package
fi
exec java -jar "$JAR"
