package com.astra.mcp.service;

import com.astra.mcp.dto.AgentRequest;
import com.astra.mcp.dto.AgentResponse;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import dev.langchain4j.model.chat.ChatLanguageModel;
import org.springframework.stereotype.Service;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

@Service
public class AstraAgentService {

    private static final Set<String> ALLOWED_TOOLS = Set.of(
            "browser_click",
            "browser_type",
            "browser_select_option",
            "browser_press_key",
            "browser_wait_for",
            "browser_snapshot",
            "browser_handle_dialog"
    );

    private final ChatLanguageModel llm;
    private final McpProcessService processService;
    private final McpClientService mcpClient;
    private final CommandService commandService;
    private final ObjectMapper objectMapper = new ObjectMapper();

    public AstraAgentService(ChatLanguageModel llm,
                             McpProcessService processService,
                             McpClientService mcpClient,
                             CommandService commandService) {
        this.llm = llm;
        this.processService = processService;
        this.mcpClient = mcpClient;
        this.commandService = commandService;
    }

    public AgentResponse run(AgentRequest request) {
        AgentResponse response = new AgentResponse();

        try {
            mcpClient.start(request.ignoreHttpsErrors, request.userDataDir);
            mcpClient.initialize();

            Map<String, Object> navigateResult = mcpClient.tool("browser_navigate", Map.of("url", request.applicationUrl));
            if (mcpClient.isError(navigateResult)) {
                throw new RuntimeException("MCP browser_navigate failed: " + navigateResult);
            }

            sleep(request.liveActionDelayMs);

            String snapshot = mcpClient.snapshot();
            Map<String, Object> testData = parseJsonObject(request.testDataJson);
            for (int step = 1; step <= request.maxAgentSteps; step++) {
                String llmDecision = llm.generate(decisionPrompt(request, snapshot, testData, response.actionTrace));
                Map<String, Object> decision = parseJsonObject(llmDecision);

                if (asBoolean(decision.get("done"))) {
                    response.message = "Live execution completed: " + decision.getOrDefault("reason", "done");
                    break;
                }

                List<String> missingData = asStringList(decision.get("missingData"));
                if (!missingData.isEmpty()) {
                    response.missingData.addAll(missingData);
                    response.status = "MISSING_TEST_DATA";
                    response.message = "Required test data is missing. Agent stopped without guessing.";
                    return response;
                }

                String toolName = String.valueOf(decision.getOrDefault("toolName", "")).trim();
                if (!ALLOWED_TOOLS.contains(toolName)) {
                    response.status = "BLOCKED";
                    response.message = "Tool not allowed or missing from LLM decision: " + toolName;
                    return response;
                }

                Map<String, Object> toolArguments = asMap(decision.get("arguments"));
                Map<String, Object> toolResult = mcpClient.tool(toolName, toolArguments);

                if (mcpClient.isSessionNotFound(toolResult)) {
                    response.status = "ERROR";
                    response.message = "MCP session was lost during live execution. In V10 stdio mode this should not happen. Stop MCP and run again.";
                    return response;
                }

                Map<String, Object> trace = new LinkedHashMap<>();
                trace.put("step", step);
                trace.put("tool", toolName);
                trace.put("arguments", toolArguments);
                trace.put("reason", decision.get("reason"));
                trace.put("result", toolResult);
                response.actionTrace.add(trace);

                if (mcpClient.isError(toolResult)) {
                    response.status = "ERROR";
                    response.message = "MCP tool call failed: " + toolResult;
                    return response;
                }

                sleep(request.liveActionDelayMs);
                snapshot = mcpClient.snapshot();
            }

            response.finalSnapshot = snapshot;
            response.generatedCode = cleanCode(llm.generate(codePrompt(request, response.actionTrace, snapshot)));

            if (request.saveToProject && request.projectPath != null && !request.projectPath.isBlank()) {
                Path testDirectory = Paths.get(request.projectPath, "tests");
                Files.createDirectories(testDirectory);
                Path outputFile = testDirectory.resolve(request.testFileName);
                Files.writeString(outputFile, response.generatedCode);
                response.savedFilePath = outputFile.toString();
            }

            if (request.validateGeneratedCode && response.savedFilePath != null) {
                validateGeneratedCode(request, response);
            }

            if (request.closeBrowserAfterRun) {
                mcpClient.tool("browser_close", Map.of());
            }

            if (response.validationStatus != null && response.validationStatus.startsWith("PASSED")) {
                response.status = "SUCCESS";
            } else {
                response.status = "GENERATED";
            }

            return response;

        } catch (Exception e) {
            response.status = "ERROR";
            response.message = e.getMessage();
            return response;
        }
    }

    private void validateGeneratedCode(AgentRequest request, AgentResponse response) throws Exception {
        if (!"PLAYWRIGHT_TYPESCRIPT".equals(request.targetFramework)
                && !"PLAYWRIGHT_JAVASCRIPT".equals(request.targetFramework)) {
            response.validationStatus = "SKIPPED_UNSUPPORTED_RUNNER";
            return;
        }

        File projectDirectory = new File(request.projectPath);
        List<String> command = new ArrayList<>();
        command.add("cmd.exe");
        command.add("/c");
        command.add("npx.cmd");
        command.add("playwright");
        command.add("test");
        command.add(request.testFileName);
        if (request.headed) {
            command.add("--headed");
        }

        String output = commandService.run(command, projectDirectory, 180);
        response.validationOutput = output;

        if (output.contains("EXIT_CODE=0")) {
            response.validationStatus = "PASSED";
            return;
        }

        if (!request.autoRepair) {
            response.validationStatus = "FAILED";
            return;
        }

        for (int attempt = 1; attempt <= request.maxRepairAttempts; attempt++) {
            String repairedCode = cleanCode(llm.generate(repairPrompt(request, response.generatedCode, output, response.actionTrace)));
            Files.writeString(Paths.get(response.savedFilePath), repairedCode);
            response.generatedCode = repairedCode;

            output = commandService.run(command, projectDirectory, 180);
            response.validationOutput = output;

            if (output.contains("EXIT_CODE=0")) {
                response.validationStatus = "PASSED_AFTER_REPAIR_" + attempt;
                return;
            }
        }

        response.validationStatus = "FAILED_AFTER_REPAIR";
    }

    private String decisionPrompt(AgentRequest request,
                                  String snapshot,
                                  Map<String, Object> testData,
                                  List<Map<String, Object>> trace) throws Exception {
        return """
                You are controlling Playwright MCP through a Java Spring Boot application.
                Return ONLY valid JSON. Do not return markdown.

                Scenario:
                %s

                Expected Result:
                %s

                Test Data JSON:
                %s

                Pre-action Instructions:
                %s

                Already Executed Trace:
                %s

                Current MCP Snapshot:
                %s

                STRICT RULES:
                1. Allowed tools only: browser_click, browser_type, browser_select_option, browser_press_key, browser_wait_for, browser_snapshot, browser_handle_dialog.
                2. Playwright MCP uses the argument name "target" for element references, not "ref".
                   Example: {"element":"Username textbox","target":"e11","text":"standard_user"}
                3. Never invent username, password, account number, transaction id, amount, date, OTP, or business data.
                4. If required data is missing, return:
                   {"done":false,"missingData":["password"]}
                5. If expected result is achieved, return:
                   {"done":true,"reason":"Expected result is visible"}
                6. Otherwise return one next action only:
                   {"done":false,"toolName":"browser_type","arguments":{"element":"...","target":"e11","text":"..."},"reason":"..."}
                """.formatted(
                safe(request.scenario),
                safe(request.expectedResult),
                objectMapper.writeValueAsString(testData),
                safe(request.preActionInstructions),
                objectMapper.writeValueAsString(trace),
                safe(snapshot)
        );
    }

    private String codePrompt(AgentRequest request,
                              List<Map<String, Object>> trace,
                              String snapshot) throws Exception {
        return """
                Generate exact automation code for this target framework: %s
                Return ONLY code. Do not return markdown.

                Use only the executed MCP action trace, the final snapshot, and provided test data.
                Do not invent selectors. Prefer stable role/label/text locators when possible.

                Application URL: %s
                Scenario: %s
                Test Data JSON: %s
                Expected Result: %s

                Executed MCP Trace:
                %s

                Final MCP Snapshot:
                %s
                """.formatted(
                safe(request.targetFramework),
                safe(request.applicationUrl),
                safe(request.scenario),
                safe(request.testDataJson),
                safe(request.expectedResult),
                objectMapper.writeValueAsString(trace),
                safe(snapshot)
        );
    }

    private String repairPrompt(AgentRequest request,
                                String code,
                                String error,
                                List<Map<String, Object>> trace) throws Exception {
        return """
                Repair this %s automation code.
                Return ONLY the full corrected code. Do not return markdown.

                Failure output:
                %s

                Current code:
                %s

                Executed MCP trace:
                %s
                """.formatted(
                safe(request.targetFramework),
                safe(error),
                safe(code),
                objectMapper.writeValueAsString(trace)
        );
    }

    private Map<String, Object> parseJsonObject(String text) {
        try {
            if (text == null || text.isBlank()) {
                return new LinkedHashMap<>();
            }
            String cleaned = stripMarkdownCodeFence(text);
            return objectMapper.readValue(cleaned, new TypeReference<Map<String, Object>>() {});
        } catch (Exception e) {
            return new LinkedHashMap<>();
        }
    }

    @SuppressWarnings("unchecked")
    private Map<String, Object> asMap(Object value) {
        if (value instanceof Map<?, ?> map) {
            Map<String, Object> result = new LinkedHashMap<>();
            for (Map.Entry<?, ?> entry : map.entrySet()) {
                result.put(String.valueOf(entry.getKey()), entry.getValue());
            }
            return result;
        }
        return new LinkedHashMap<>();
    }

    private List<String> asStringList(Object value) {
        List<String> result = new ArrayList<>();
        if (value instanceof List<?> list) {
            for (Object item : list) {
                result.add(String.valueOf(item));
            }
        } else if (value instanceof String text && !text.isBlank()) {
            result.add(text);
        }
        return result;
    }

    private boolean asBoolean(Object value) {
        if (value instanceof Boolean b) {
            return b;
        }
        return Boolean.parseBoolean(String.valueOf(value));
    }

    private String cleanCode(String code) {
        return stripMarkdownCodeFence(code).trim();
    }

    private String stripMarkdownCodeFence(String text) {
        if (text == null) {
            return "";
        }
        return text
                .replace("```typescript", "")
                .replace("```ts", "")
                .replace("```javascript", "")
                .replace("```js", "")
                .replace("```java", "")
                .replace("```python", "")
                .replace("```csharp", "")
                .replace("```", "")
                .trim();
    }

    private void sleep(int milliseconds) {
        try {
            Thread.sleep(Math.max(milliseconds, 0));
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    private String safe(String value) {
        return value == null ? "" : value;
    }
}
