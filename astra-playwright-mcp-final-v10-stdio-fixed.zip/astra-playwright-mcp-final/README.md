# Astra Playwright MCP Final V10 - Stdio Fix

## Why V10 exists
V9 used Playwright MCP HTTP mode on port 8931. On some latest Playwright MCP builds, HTTP sessions can expire between tool calls. That causes this behaviour:

- browser launches
- username is typed
- browser/session closes
- next action starts from home page again
- password/submit are not executed in the same sequence

V10 fixes this by using MCP **stdio transport** instead of HTTP port mode. The same MCP process stays alive and all browser actions run in one continuous session.

## Run
```powershell
mvn clean spring-boot:run
```

Open:
```text
http://localhost:8090/index.html
```

## Important
Do not manually run:
```powershell
npx -y @playwright/mcp@latest --port 8931
```

V10 starts MCP internally using:
```powershell
npx.cmd -y @playwright/mcp@latest
```

## First test
URL:
```text
https://www.saucedemo.com/
```

Scenario:
```text
Login using the provided username and password and verify Products page is displayed.
```

Test Data JSON:
```json
{
  "username": "standard_user",
  "password": "secret_sauce"
}
```

Expected Result:
```text
Products page should be visible.
```

Recommended first-run settings:
- Validate generated code: unchecked
- Close browser after run: unchecked
- Live action delay: 1500
- Max agent steps: 8

After live execution works, enable validation.
