/* ELIYA132: A single, framework-free contract for prompts and user-downloadable artifacts.
 * Source content is never clipped or silently merged; a file is downloadable only
 * when its representation is complete enough to constitute a standalone file.
 */
(function(root,factory){
  const api=factory();
  if(typeof module==='object' && module.exports) module.exports=api;
  if(root) root.EliyaResponseArtifacts=api;
})(typeof window!=='undefined'?window:null,function(){
  'use strict';
  const clean = value=>String(value==null?'':value).replace(/\r\n/g,'\n').trim();
  const safeName = (name,fallback='artifact')=>clean(name).replace(/[^\w .-]+/g,'-').replace(/^\.+/,'').slice(0,80).trim()||fallback;
  const codeBlocks = text => {
    const result=[];
    const regex=/^(`{3,}|~{3,})([^\n]*)\n([\s\S]*?)\n\1\s*$/gm;
    let match;
    while((match=regex.exec(String(text||'')))!==null) result.push({language:clean(match[2]).toLowerCase(),text:match[3],start:match.index,end:regex.lastIndex});
    return result;
  };
  function fullHtml(src){
    const text=clean(src);
    // A fragment, an unfinished tag, or a placeholder is not a downloadable HTML document.
    return (/^<!doctype\s+html\b/i.test(text) || /^<html\b/i.test(text)) &&
      /<html\b[^>]*>[\s\S]*<\/html\s*>\s*$/i.test(text) &&
      /<head\b[^>]*>[\s\S]*<\/head\s*>/i.test(text) &&
      /<body\b[^>]*>[\s\S]*<\/body\s*>/i.test(text) &&
      !/\b(?:TODO|PLACEHOLDER)\b|\.\.\./i.test(text);
  }
  function fullJson(src){try{JSON.parse(clean(src));return true;}catch(_){return false;}}
  function requestedFormat(question){
    const q=String(question||'');
    const artifactIntent=/\b(?:download(?:able)?|file|artifact|export|save\s+as|standalone|self.contained|webpage|website|config(?:uration)?|document|source\s+code|output\s+file|send)\b/i.test(q);
    if (!artifactIntent) return '';
    if(/\b(?:html?|hyml|web\s*page|single.page\s+(?:site|website))\b/i.test(q))return 'html';
    if(/\b(?:yaml|yml)\b/i.test(q))return 'yaml';
    if(/\bjson\b/i.test(q))return 'json';
    if(/\b(?:markdown|\.md\b)\b/i.test(q))return 'md';
    return '';
  }
  function detect(question,answer){
    const format=requestedFormat(question);
    const src=clean(answer);
    if(!src || !format)return {requested:format,ready:false,reason:'Empty response'};
    if(/\[ELIYA:\s*response incomplete\]|Generation stopped/i.test(src))
      return {requested:format,ready:false,reason:'The response was interrupted. Generate a complete file before downloading.'};
    const fences=codeBlocks(src);
    let text='',ext=format;
    if(format==='html'){
      const candidates=[src,...fences.filter(b=>/^(?:html?|xml|)$/.test(b.language)).map(b=>b.text)];
      text=candidates.find(fullHtml)||'';
    }else if(format==='json'){
      const candidates=[src,...fences.filter(b=>/^(?:json|)$/.test(b.language)).map(b=>b.text)];
      text=candidates.find(fullJson)||'';
    }else if(format==='yaml'){
      // Multiple code blocks are separate snippets, never silently concatenated.
      const candidates=fences.filter(b=>/^(?:yaml|yml)$/.test(b.language));
      if(candidates.length===1 && !/\b(?:TODO|\.\.\.|PLACEHOLDER)\b/i.test(candidates[0].text))text=candidates[0].text;
      else if(fences.length===0 && !/^\s*```/m.test(src) && /^\s*[\w"'/-][^\n]*:\s*\S/m.test(src))text=src;
      ext='yml';
    }else if(format==='md'){
      text=src;
      if(fences.length===1 && fences[0].start===0 && fences[0].end===src.length && /^(?:md|markdown)$/.test(fences[0].language))text=fences[0].text;
    }
    const requestedName=String(question||'').match(/(?:^|[\s`'"(])([a-z0-9][a-z0-9_.-]{0,78}\.(?:html?|json|ya?ml|md))\b/i)?.[1];
    const fallback= format==='html'?'generated-page.html':format==='json'?'generated-data.json':format==='yaml'?'generated-config.yml':'generated-document.md';
    const filename=requestedName && (requestedName.toLowerCase().endsWith('.'+ext) || (ext==='yml' && requestedName.toLowerCase().endsWith('.yaml'))) ? safeName(requestedName) : fallback;
    return {requested:format,ready:!!text,extension:ext,content:text,filename,
      reason:text?'':'The response does not contain one complete '+format.toUpperCase()+' artifact.'};
  }
  function isPromptRequest(question){
    const q=clean(question);
    // A request to review or fix an EXISTING prompt is not a prompt-generation request.
    if(/^(?:check|verify|review|inspect|explain|fix|test|run)\b/i.test(q) &&
       !/\b(?:generate|create|write|draft|prepare|produce|give|share|provide)\b[\s\S]{0,180}\bprompts?\b/i.test(q))return false;
    if(/^(?:what|why|when|where|how|which)\b/i.test(q))return false;
    if(/\bprompts?\s*1\b[\s\S]*\bprompts?\s*2\b/i.test(q))return true;
    return /\b(?:generate|create|write|draft|prepare|produce|give|share|provide|build|make|export|download|convert|turn)\b[\s\S]{0,650}\bprompts?\b|\b(?:implementation|execution|agent|complete|reusable)\s+prompts?\b|^prompts?\s+(?:for|to|based on)\b/i.test(q);
  }
  // Count is a contract, not a display suggestion. Support both "four prompts" and
  // requests describing Prompt 1, Prompt 2, Prompt 3 and "4 reusable prompt".
  function expectedPromptCount(question){
    const q=clean(question);
    if(!isPromptRequest(q))return 0;
    const wordNumbers={one:1,two:2,three:3,four:4,five:5,six:6,seven:7,eight:8,nine:9,ten:10};
    const written=q.match(/\b(\d{1,2}|one|two|three|four|five|six|seven|eight|nine|ten)\s+(?:(?:separate|standalone|independent|reusable|detailed|implementation|migration|complete)\s+){0,3}prompts?\b/i);
    if(written){
      const n=Number(written[1])||wordNumbers[written[1].toLowerCase()];
      if(n>=1&&n<=20)return n;
    }
    const labels=[...q.matchAll(/\bprompts?\s*(?:number\s*|no\.?\s*|#\s*)?(\d{1,2})\b/gi)].map(m=>Number(m[1]));
    // Handles "1 for framework, 2 for utilities ... 4 reusable prompt".
    for(const m of q.matchAll(/\b(\d{1,2})\s+(?:(?:reusable|implementation|migration|framework|utility|utilities|final|last)\s+){0,3}prompts?\b/gi))labels.push(Number(m[1]));
    if(labels.includes(1)&&labels.length>=2)return Math.min(20,Math.max(...labels));
    return 0;
  }
  function promptReadiness(question,content){
    const text=clean(content), q=String(question||'');
    if(!text || /\[ELIYA:\s*response incomplete\]|Generation stopped/i.test(text))
      return {ready:false,reason:'Prompt generation was interrupted.'};
    if(/^(?:sure[,. ]+|okay[,. ]+)?(?:let me|i(?:'ll| will| can) (?:first )?(?:inspect|analyse|analyze|prepare|create|generate|write))/i.test(text))
      return {ready:false,reason:'Only a preamble was generated, not the requested prompt.'};
    if(/\b(?:TODO|PLACEHOLDER|same as above|the remaining steps|insert your details here)\b/i.test(text))
      return {ready:false,reason:'The prompt still contains omitted or placeholder instructions.'};
    // A selected card is never allowed to contain a second full prompt.
    // This catches model output that repeats the complete four-prompt bundle
    // INSIDE every labelled prompt (usually within a Markdown fence).
    const nested=[...text.matchAll(/^[ \t]*(?:#{1,6}[ \t]+)?(?:\*\*)?prompt[ \t]*#?[ \t]*\d{1,2}\b[^\n]*$/gim)];
    if(nested.length>1)return {ready:false,reason:'This section contains multiple complete prompts. Generate a distinct prompt rather than repeating the four-prompt bundle.'};
    const fences=[...text.matchAll(/^[ \t]*(`{3,}|~{3,})(?:[^\n]*)$/gm)];
    if(fences.length%2!==0)return {ready:false,reason:'The generated prompt has an unclosed code block; the output may be truncated.'};
    const abbreviated=/\b(?:short|brief|one.line|single.sentence|tiny|minimal)\s+prompts?\b/i.test(q);
    if (!abbreviated && text.length<180)
      return {ready:false,reason:'This is an outline, not an independently executable implementation prompt.'};
    if (!abbreviated && !/\b(?:verify|validate|test|acceptance|criteria|confirm|check|evidence|success condition|completion)\b/i.test(text))
      return {ready:false,reason:'The prompt lacks verification or acceptance instructions.'};
    return {ready:true,reason:''};
  }
  function unwrapPromptDocument(text){
    // Models often put an entire four-prompt answer inside one ```markdown fence.
    // This wrapper is presentation, NOT one executable prompt.
    let src=clean(text);
    const outer=src.match(/^(`{3,}|~{3,})(?:md|markdown|text|plaintext)?[ \t]*\n([\s\S]*?)\n\1\s*$/i);
    if(outer && !outer[2].split("\n").some(line=>line.trim().startsWith(outer[1])))src=clean(outer[2]);
    return src;
  }
  function promptSections(question,answer){
    if(!isPromptRequest(question))return [];
    const expected=expectedPromptCount(question);
    const original=clean(answer);
    if(!original || /\[ELIYA:\s*response incomplete\]|Generation stopped/i.test(original))return [];
    const src=unwrapPromptDocument(original);
    // Only full-line, explicitly labelled headings are reliable boundaries.
    // Skip headings inside ordinary code fences so instructions/examples cannot
    // produce phantom prompts. The outer Markdown-document fence is unwrapped.
    const header=/^[ \t]*(?:#{1,6}[ \t]+)?(?:\*\*)?(?:\d{1,2}[.)][ \t]+)?(?:prompt|step)[ \t]*#?[ \t]*(\d{1,2})\b[^\n]*$/gim;
    const fenceSpans=codeBlocks(src);
    const marks=[...src.matchAll(header)].filter(match=>!fenceSpans.some(f=>match.index>=f.start&&match.index<f.end));
    // Four individually fenced Markdown documents are also four separate
    // prompts, even though their internal headings are inside code fences.
    if(marks.length<2 && fenceSpans.length>=2){
      const fenced=fenceSpans.map(f=>{
        if(!/^(?:md|markdown|text|plaintext)$/.test(f.language))return null;
        const first=clean(f.text).match(/^(?:#{1,6}\s+)?(?:\*\*)?prompt\s*#?\s*(\d{1,2})\b[^\n]*/i);
        return first?{number:Number(first[1]),title:first[0],content:clean(f.text)}:null;
      });
      if(fenced.every(Boolean)){
        const numberSet=fenced.map(p=>p.number);
        const validOrder=fenced.length===(expected||fenced.length) && numberSet.every((n,i)=>n===i+1);
        return fenced.map(part=>({...part,...(validOrder?promptReadiness(question,part.content):
          {ready:false,reason:`Expected ${expected||'ordered'} distinct prompts; found labels ${numberSet.join(', ')}.`})}));
      }
    }
    if(marks.length<2){
      const body=src;
      if(expected>1)return [{title:`Combined response — expected ${expected} separate prompts`,content:body,
        number:0,ready:false,reason:`Expected ${expected} separately labelled prompts but found ${marks.length} distinct section${marks.length===1?'':'s'}. Regenerate the prompt set. Never send this combined answer to Agent.`}];
      return [{title:'Complete prompt',content:body,number:1,...promptReadiness(question,body)}];
    }
    const sections=[];
    for(let i=0;i<marks.length;i++){
      const start=marks[i].index, end=i+1<marks.length?marks[i+1].index:src.length;
      const body=src.slice(start,end).trim();
      if(body)sections.push({number:Number(marks[i][1]),title:clean(marks[i][0]).replace(/^\s*#{1,6}\s*/,'').replace(/^\*\*/,'').replace(/\*\*$/,'').slice(0,100),content:body});
    }
    const numbers=sections.map(s=>s.number);
    const exact=expected ? (sections.length===expected && numbers.every((n,i)=>n===i+1))
      : (new Set(numbers).size===sections.length && numbers.every((n,i)=>n===i+1));
    const normalized=sections.map(s=>s.content.replace(/^.*\n/,'').replace(/\s+/g,' ').trim().toLowerCase());
    const duplicates=new Set(normalized).size!==normalized.length;
    const invalidSet=!exact ? `Requested ${expected||'sequential'} prompts but found sections numbered ${numbers.join(', ')}. Generate one separately headed section for each requested prompt.`
      : duplicates ? 'Two or more prompts contain the same instructions. Generate distinct, independently executable prompts.' : '';
    return sections.map(section=>({...section,...(invalidSet ? {ready:false,reason:invalidSet} : promptReadiness(question,section.content))}));
  }
  function promptFileName(section,index){
    const n=Number(section?.number)||index+1;
    const label=clean(section?.title||'').replace(/^(?:prompt|step)\s*#?\s*\d+\s*[:.)—–-]?\s*/i,'')
      .replace(/[^a-z\d\s-]/gi,'').toLowerCase().replace(/\s+/g,'-').replace(/-+/g,'-').slice(0,45).replace(/-$/,'');
    return `prompt-${n}${label?'-'+label:''}.md`;
  }
  function handoffMessage(id,scope,title){
    if(!Number.isSafeInteger(Number(id))||Number(id)<=0)throw new Error('Saved Analyse response required');
    const selected=clean(scope);
    if(!selected)throw new Error('The selected prompt is empty');
    // ContextService accepts a scoped Agent prompt up to 80K chars when the
    // configured model has enough room. Do not arbitrarily reject a 32K prompt.
    if(selected.length>72000)throw new Error('Selected prompt is larger than the 72,000-character handoff safety limit. Split it into independently verifiable tasks or configure a larger context window.');
    return `Implement ONLY the selected prompt from conversation message #${Number(id)} in the currently selected workspace.\n`+
      `Selected scope: ${clean(title||'Prompt')}\n`+
      'This is an explicit scoped handoff. Do not execute unrelated sections, other prompts, or optional enhancements from the source response. ' +
      'Use the selected instructions below as the authoritative task, inspect relevant live files, and verify changes before declaring completion. '+
      'Ask only if a critical requirement prevents safe execution.\n\n'+
      '--- BEGIN SELECTED PROMPT ---\n'+selected+'\n--- END SELECTED PROMPT ---';
  }
  return Object.freeze({codeBlocks,fullHtml,requestedFormat,detect,isPromptRequest,expectedPromptCount,promptReadiness,promptSections,promptFileName,handoffMessage,safeName});
});
