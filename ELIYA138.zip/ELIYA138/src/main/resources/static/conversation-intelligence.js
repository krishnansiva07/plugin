/* ELIYA80: conversational continuation is a presentation/context concern, NOT a second LLM planner.
 * All facts still come from retrieval and the model. Suggestions do not assert unverified findings.
 */
(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  if (root) root.EliyaConversationIntelligence = api;
})(typeof window !== 'undefined' ? window : null, function () {
  'use strict';
  const accepted = /^(?:yes(?: please)?|sure|ok(?:ay)?|go ahead|continue|please continue|proceed|do it|yes[, ]+proceed)[.!\s]*$/i;
  const declined = /^(?:no(?: thanks| thank you)?|not now|that's all|nothing else)[.!\s]*$/i;
  const questionInAnswer = /(?:would you like|do you want|shall i|should i|want me to|need me to)[^?]{0,230}\?\s*$/i;
  const technical = /\b(?:workspace|source|project|repository|framework|architecture|module|class|method|api|flow|ticket|jira|regression|test|error|skill|agent|dependency|deep search)\b/i;
  const reliable = output => String(output || '').trim().length >= 80 && !/^(?:task (?:failed|stopped)|completed successfully|the agent could not|an error occurred)/i.test(String(output).trim());
  function suggest({prompt = '', answer = '', mode = 'analyse', success = true} = {}) {
    const p = String(prompt).trim(), a = String(answer).trim();
    if (!success || !reliable(a) || !technical.test(p) || questionInAnswer.test(a) || /\?\s*$/.test(a)) return '';
    if (/\b(?:jira|ticket|[A-Z][A-Z0-9]+-\d+)\b/i.test(p) && /\b(?:compare|gap|missing|analyse|analyze|review)\b/i.test(p))
      return 'Would you like me to investigate any finding further or implement the identified changes?';
    if (/\b(?:create|generate|fix|implement|modify|update|build|migrate|add)\b/i.test(p) && mode === 'execute')
      return 'Would you like me to improve or extend anything in the completed work?';
    if (/\b(?:workspace|repository|project|codebase)\b/i.test(p))
      return 'Would you like to explore a specific module or trace its end-to-end architecture?';
    if (/\b(?:architecture|flow|deep search|dependency)\b/i.test(p))
      return 'Would you like me to trace a specific component or investigate any architectural gaps?';
    if (/\b(?:test|failure|regression|error)\b/i.test(p))
      return 'Would you like a deeper root-cause analysis or a proposed implementation plan?';
    return '';
  }
  // A free-form answer is ALWAYS passed through unchanged. Do not assume an isolated "yes"
  // authorises an implementation after a multi-option suggestion.
  function resolve(text, suggestion) {
    const value = String(text || '').trim(), s = String(suggestion || '');
    if (!accepted.test(value) || !s) return {text:value, action:'original'};
    if (/implement .*\?\s*$/i.test(s) && !/ or /i.test(s)) return {text:'Please implement the changes we just discussed.', action:'execute'};
    if (/explore a specific module|trace its end-to-end architecture/i.test(s))
      return {text:'Please analyse the workspace architecture and suggest relevant modules for a deeper investigation.', action:'analyse'};
    if (/trace a specific component|architectural gaps/i.test(s))
      return {text:'Please investigate architecture gaps in more detail using the workspace index.', action:'analyse'};
    if (/improve or extend/i.test(s))
      return {text:'Please review the completed work and suggest useful enhancements. Do not change files yet.', action:'analyse'};
    return {text:value, action:'original'}; // ambiguous multi-option question
  }
  // Short follow-ups are real instructions, not an invitation to ask for a new prompt.
  // Resolve only unambiguous read-only commands. The source request stays in the
  // persistent conversation, and the explicit target makes compact-model behavior
  // consistent across Chat and the independent Terminal tab.
  function contextualize(value, {lastUser='',lastAssistant='',workspaceMapped=false}={}) {
    const input=String(value||'').trim();
    if(!/^(?:(?:please|can you|could you)\s+)?(?:check|verify|validate|review|inspect)(?:\s+(?:it|this|that|again|now|the result|the output|the changes))?[.!?\s]*$/i.test(input))
      return {text:input,action:'original'};
    const prior=String(lastUser||'').trim();
    const reply=String(lastAssistant||'').trim();
    if (!prior && !workspaceMapped) return {text:input,action:'original'};
    const target=prior ? `The most recent user task in this conversation was: ${prior.slice(0,3000)}. `
      : 'No previous user task is available. ';
    const evidence=reply ? 'Compare your findings with the previous assistant answer and verify its claims, not just the wording. ' : '';
    return {text:`${input}. ${target}${evidence}Inspect the currently mapped workspace and applicable reference folders using real available evidence. Report findings, what passed/failed, limitations, and exact next steps. Do not generate a prompt, demand that I paste the previous prompt, or claim execution without actual evidence. This is a read-only check unless I explicitly authorize changes.`, action:'contextual-check'};
  }
  return Object.freeze({contextualize,suggest,resolve,isDecline: value => declined.test(String(value||'').trim())});
});
