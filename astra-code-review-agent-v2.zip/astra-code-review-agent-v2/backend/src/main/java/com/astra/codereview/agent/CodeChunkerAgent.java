package com.astra.codereview.agent;

import com.astra.codereview.model.CodeChunk;
import com.astra.codereview.model.ReviewFile;
import org.springframework.stereotype.Component;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Component
public class CodeChunkerAgent {
    private static final int LARGE_FILE_LINE_THRESHOLD = 300;
    private static final int MAX_CHUNK_LINES = 180;

    private static final Pattern JAVA_METHOD_PATTERN = Pattern.compile(
            "(?m)^\\s*(public|private|protected|static|final|synchronized|native|abstract|default|\\s)+[\\w<>\\[\\], ?]+\\s+([a-zA-Z_$][\\w$]*)\\s*\\([^;{}]*\\)\\s*(throws\\s+[\\w.,\\s]+)?\\s*\\{");

    public boolean shouldChunk(ReviewFile file) {
        if (file == null || file.content == null) return false;
        int lineCount = lineCount(file.content);
        return lineCount > LARGE_FILE_LINE_THRESHOLD || (file.fileType != null && file.fileType.startsWith("JAVA"));
    }

    public int lineCount(String content) {
        if (content == null || content.isBlank()) return 0;
        return content.split("\\R", -1).length;
    }

    public List<CodeChunk> createChunks(ReviewFile file) {
        if (file.fileName != null && file.fileName.endsWith(".java")) {
            List<CodeChunk> javaChunks = createJavaMethodChunks(file.content);
            if (!javaChunks.isEmpty()) return javaChunks;
        }
        return createLineChunks(file.content);
    }

    private List<CodeChunk> createJavaMethodChunks(String content) {
        List<String> lines = Arrays.asList(content.split("\\R", -1));
        Matcher matcher = JAVA_METHOD_PATTERN.matcher(content);
        List<int[]> methodRanges = new ArrayList<>();
        List<String> names = new ArrayList<>();

        while (matcher.find()) {
            int startOffset = matcher.start();
            int startLine = offsetToLine(content, startOffset);
            int endLine = findBlockEndLine(lines, startLine);
            if (endLine <= startLine) continue;
            methodRanges.add(new int[]{startLine, endLine});
            names.add(matcher.group(2));
        }

        List<CodeChunk> chunks = new ArrayList<>();
        int chunkNo = 1;

        if (!methodRanges.isEmpty()) {
            int firstMethodStart = methodRanges.get(0)[0];
            if (firstMethodStart > 1) {
                String header = slice(lines, 1, firstMethodStart - 1);
                chunks.add(new CodeChunk("CHUNK-" + pad(chunkNo++), "CLASS_CONTEXT", "imports-fields-class-header", 1, firstMethodStart - 1, header, riskScore(header)));
            }
        }

        for (int i = 0; i < methodRanges.size(); i++) {
            int start = methodRanges.get(i)[0];
            int end = methodRanges.get(i)[1];
            String name = names.get(i);
            if ((end - start + 1) > MAX_CHUNK_LINES) {
                int part = 1;
                for (int s = start; s <= end; s += MAX_CHUNK_LINES) {
                    int e = Math.min(end, s + MAX_CHUNK_LINES - 1);
                    String body = slice(lines, s, e);
                    chunks.add(new CodeChunk("CHUNK-" + pad(chunkNo++), "METHOD_PART", name + " part " + part++, s, e, body, riskScore(body) + 3));
                }
            } else {
                String body = slice(lines, start, end);
                chunks.add(new CodeChunk("CHUNK-" + pad(chunkNo++), "METHOD", name, start, end, body, riskScore(body)));
            }
        }

        chunks.sort(Comparator.comparingInt((CodeChunk c) -> -c.riskScore).thenComparingInt(c -> c.startLine));
        return chunks;
    }

    private List<CodeChunk> createLineChunks(String content) {
        List<String> lines = Arrays.asList(content.split("\\R", -1));
        List<CodeChunk> chunks = new ArrayList<>();
        int chunkNo = 1;
        for (int start = 1; start <= lines.size(); start += MAX_CHUNK_LINES) {
            int end = Math.min(lines.size(), start + MAX_CHUNK_LINES - 1);
            String body = slice(lines, start, end);
            chunks.add(new CodeChunk("CHUNK-" + pad(chunkNo++), "LINE_BLOCK", "lines " + start + "-" + end, start, end, body, riskScore(body)));
        }
        chunks.sort(Comparator.comparingInt((CodeChunk c) -> -c.riskScore).thenComparingInt(c -> c.startLine));
        return chunks;
    }

    private int findBlockEndLine(List<String> lines, int startLine) {
        int braces = 0;
        boolean started = false;
        for (int i = startLine - 1; i < lines.size(); i++) {
            String line = stripStrings(lines.get(i));
            for (char ch : line.toCharArray()) {
                if (ch == '{') { braces++; started = true; }
                if (ch == '}') braces--;
            }
            if (started && braces <= 0) return i + 1;
        }
        return Math.min(lines.size(), startLine + MAX_CHUNK_LINES - 1);
    }

    private String stripStrings(String line) {
        return line.replaceAll("\\\"(?:\\\\.|[^\\\\\\\"])*\\\"", "\"\"").replaceAll("'(?:\\\\.|[^\\\\'])'", "''");
    }

    private int offsetToLine(String content, int offset) {
        int line = 1;
        for (int i = 0; i < Math.min(offset, content.length()); i++) if (content.charAt(i) == '\n') line++;
        return line;
    }

    private String slice(List<String> lines, int startLine, int endLine) {
        StringBuilder sb = new StringBuilder();
        for (int i = Math.max(1, startLine); i <= Math.min(lines.size(), endLine); i++) {
            sb.append(i).append(": ").append(lines.get(i - 1)).append('\n');
        }
        return sb.toString();
    }

    private int riskScore(String content) {
        String lower = content.toLowerCase(Locale.ROOT);
        int score = 0;
        score += count(lower, "try") * 2;
        score += count(lower, "catch") * 2;
        score += count(lower, "if ");
        score += count(lower, "for ");
        score += count(lower, "while ");
        score += count(lower, "http") * 3;
        score += count(lower, "save(") * 3;
        score += count(lower, "delete(") * 3;
        score += count(lower, "thread.sleep") * 5;
        score += count(lower, "system.out.println") * 2;
        score += count(lower, "password") * 4;
        score += count(lower, "api-key") * 5;
        int lines = lineCount(content);
        if (lines > 120) score += 4;
        if (lines > 180) score += 6;
        return Math.min(score, 25);
    }

    private int count(String text, String needle) {
        int idx = 0, c = 0;
        while ((idx = text.indexOf(needle, idx)) >= 0) { c++; idx += needle.length(); }
        return c;
    }

    private String pad(int n) { return String.format("%03d", n); }
}
