package com.astra.codereview.model;

import java.util.ArrayList;
import java.util.List;

public class ChunkReviewResult {
    public String chunkId;
    public String chunkType;
    public String chunkName;
    public int startLine;
    public int endLine;
    public int riskScore;
    public String severity;
    public int score;
    public String summary;
    public List<ReviewIssue> comments = new ArrayList<>();
}
