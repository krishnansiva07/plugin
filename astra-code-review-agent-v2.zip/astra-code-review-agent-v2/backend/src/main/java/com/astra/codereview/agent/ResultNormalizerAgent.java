package com.astra.codereview.agent;

import com.astra.codereview.model.*;
import org.springframework.stereotype.Component;

import java.util.*;

@Component
public class ResultNormalizerAgent {
    public List<ReviewIssue> mergeAndDedupe(List<ReviewIssue> issues) {
        Map<String, ReviewIssue> unique = new LinkedHashMap<>();
        for (ReviewIssue issue : issues) {
            if (issue == null || issue.whatIsWrong == null || issue.whatIsWrong.isBlank()) continue;
            String key = normalize(issue.category) + "|" + normalize(issue.whatIsWrong) + "|" + (issue.lineNumber == null ? "" : issue.lineNumber);
            ReviewIssue existing = unique.get(key);
            if (existing == null || severityRank(issue.severity) < severityRank(existing.severity)) unique.put(key, issue);
        }
        List<ReviewIssue> sorted = new ArrayList<>(unique.values());
        sorted.sort(Comparator.comparingInt((ReviewIssue i) -> severityRank(i.severity)).thenComparing(i -> i.lineNumber == null ? 999999 : i.lineNumber));
        return sorted;
    }

    public String highestSeverity(List<ReviewIssue> issues, String fallback) {
        String best = fallback == null || fallback.isBlank() ? "PASSED" : fallback;
        for (ReviewIssue issue : issues) if (severityRank(issue.severity) < severityRank(best)) best = issue.severity;
        return best;
    }

    public int calculateScore(String severity, int issueCount, int chunkCount) {
        int base = switch (severity == null ? "PASSED" : severity) {
            case "CRITICAL" -> 45;
            case "MAJOR" -> 65;
            case "MINOR" -> 78;
            case "GOOD_TO_HAVE" -> 86;
            default -> 95;
        };
        return Math.max(25, Math.min(98, base - Math.min(issueCount * 2, 20) - Math.max(0, chunkCount - 1)));
    }

    private int severityRank(String s) {
        return switch (s == null ? "PASSED" : s) {
            case "CRITICAL" -> 0;
            case "MAJOR" -> 1;
            case "MINOR" -> 2;
            case "GOOD_TO_HAVE" -> 3;
            default -> 4;
        };
    }

    private String normalize(String s) {
        if (s == null) return "";
        return s.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9 ]", "").replaceAll("\\s+", " ").trim();
    }
}
