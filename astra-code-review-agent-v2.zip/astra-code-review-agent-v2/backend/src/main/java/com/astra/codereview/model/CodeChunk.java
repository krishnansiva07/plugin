package com.astra.codereview.model;

public class CodeChunk {
    public String chunkId;
    public String chunkType;
    public String name;
    public int startLine;
    public int endLine;
    public String content;
    public int riskScore;

    public CodeChunk() {}

    public CodeChunk(String chunkId, String chunkType, String name, int startLine, int endLine, String content, int riskScore) {
        this.chunkId = chunkId;
        this.chunkType = chunkType;
        this.name = name;
        this.startLine = startLine;
        this.endLine = endLine;
        this.content = content;
        this.riskScore = riskScore;
    }
}
