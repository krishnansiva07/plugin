package com.astra.codereview.agent;

import com.astra.codereview.model.*;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class ReviewOrchestratorAgent {
    private final RuleAnalyzerAgent ruleAnalyzer;
    private final LlmReviewerAgent llmReviewer;
    private final ReviewProgressAgent progressAgent;
    private final CodeChunkerAgent chunker;
    private final ResultNormalizerAgent normalizer;

    public ReviewOrchestratorAgent(RuleAnalyzerAgent ruleAnalyzer, LlmReviewerAgent llmReviewer,
                                   ReviewProgressAgent progressAgent, CodeChunkerAgent chunker,
                                   ResultNormalizerAgent normalizer) {
        this.ruleAnalyzer = ruleAnalyzer;
        this.llmReviewer = llmReviewer;
        this.progressAgent = progressAgent;
        this.chunker = chunker;
        this.normalizer = normalizer;
    }

    @Async
    public void startReview(String reviewId, List<ReviewFile> files) {
        int total = files.size();
        progressAgent.publish(reviewId, ReviewProgressEvent.of("REVIEW_STARTED", reviewId, null, 0, total, 0, total, "STARTED", "Review started"));

        int completed = 0;
        for (int i = 0; i < files.size(); i++) {
            ReviewFile file = files.get(i);
            int index = i + 1;
            int queued = total - completed - 1;

            progressAgent.publish(reviewId, ReviewProgressEvent.of("FILE_STARTED", reviewId, file.fileName, index, total, completed, queued, "RUNNING", "Review started for " + file.fileName));
            sleepSmall();

            progressAgent.publish(reviewId, ReviewProgressEvent.of("RULE_CHECK_RUNNING", reviewId, file.fileName, index, total, completed, queued, "RUNNING", "Rule analyzer is checking deterministic issues"));
            List<ReviewIssue> ruleIssues = ruleAnalyzer.analyze(file);
            progressAgent.publish(reviewId, ReviewProgressEvent.of("RULE_CHECK_COMPLETED", reviewId, file.fileName, index, total, completed, queued, "RUNNING", "Rule check completed. Issues found: " + ruleIssues.size()));
            sleepSmall();

            FileReviewResult result;
            if (isLargeReviewCandidate(file)) {
                result = reviewLargeFile(reviewId, file, index, total, completed, queued, ruleIssues);
            } else {
                progressAgent.publish(reviewId, ReviewProgressEvent.of("LLM_REVIEW_RUNNING", reviewId, file.fileName, index, total, completed, queued, "RUNNING", "LLM reviewer is checking practical pre-PR comments"));
                LlmReviewerAgent.LlmResult llm = llmReviewer.review(file, ruleIssues);
                result = buildResult(file, index, total, completed + 1, total - completed - 1, ruleIssues, llm, Collections.emptyList());
            }

            completed++;
            result.completedFiles = completed;
            result.queuedFiles = total - completed;
            progressAgent.publish(reviewId, result);
        }

        progressAgent.publish(reviewId, ReviewProgressEvent.of("REVIEW_COMPLETED", reviewId, null, total, total, total, 0, "COMPLETED", "All files completed"));
        progressAgent.complete(reviewId);
    }

    private boolean isLargeReviewCandidate(ReviewFile file) {
        int lines = chunker.lineCount(file.content);
        return lines > 300 && file.fileName != null && (file.fileName.endsWith(".java") || file.fileName.endsWith(".ts") || file.fileName.endsWith(".js") || file.fileName.endsWith(".tsx") || file.fileName.endsWith(".jsx"));
    }

    private FileReviewResult reviewLargeFile(String reviewId, ReviewFile file, int index, int total, int completed, int queued, List<ReviewIssue> ruleIssues) {
        List<CodeChunk> chunks = chunker.createChunks(file);
        int totalChunks = chunks.size();
        List<ChunkReviewResult> chunkResults = new ArrayList<>();
        List<ReviewIssue> allIssues = new ArrayList<>(ruleIssues);
        List<String> chunkSummaries = new ArrayList<>();

        ReviewProgressEvent detected = ReviewProgressEvent.of("LARGE_FILE_DETECTED", reviewId, file.fileName, index, total, completed, queued, "RUNNING",
                "Large file detected. Creating method/chunk level review queue: " + totalChunks + " chunks");
        detected.filePath = file.relativePath;
        detected.largeFile = true;
        detected.totalChunks = totalChunks;
        detected.completedChunks = 0;
        progressAgent.publish(reviewId, detected);

        for (int c = 0; c < chunks.size(); c++) {
            CodeChunk chunk = chunks.get(c);
            progressAgent.publish(reviewId, ReviewProgressEvent.chunk("CHUNK_STARTED", reviewId, file, chunk, index, total, completed, queued, c, totalChunks,
                    "Analyzing chunk " + (c + 1) + "/" + totalChunks + ": " + chunk.name));

            LlmReviewerAgent.LlmResult llm = llmReviewer.reviewChunk(file, chunk, ruleIssues);
            ChunkReviewResult chunkResult = buildChunkResult(chunk, llm);
            chunkResults.add(chunkResult);
            allIssues.addAll(chunkResult.comments);
            chunkSummaries.add("- " + chunk.name + " lines " + chunk.startLine + "-" + chunk.endLine + ": " + llm.fileSummary);

            ReviewProgressEvent chunkDone = ReviewProgressEvent.chunk("CHUNK_COMPLETED", reviewId, file, chunk, index, total, completed, queued, c + 1, totalChunks,
                    "Chunk completed. Partial comments available for " + chunk.name);
            chunkDone.partialComments = chunkResult.comments;
            progressAgent.publish(reviewId, chunkDone);
            sleepSmall();
        }

        List<ReviewIssue> merged = normalizer.mergeAndDedupe(allIssues);
        progressAgent.publish(reviewId, ReviewProgressEvent.of("CLASS_SUMMARY_RUNNING", reviewId, file.fileName, index, total, completed, queued, "RUNNING",
                "Generating final class-level summary and removing duplicate comments"));
        LlmReviewerAgent.LlmResult summary = llmReviewer.summarizeLargeFile(file, merged, chunkSummaries);
        if (summary.comments != null && !summary.comments.isEmpty()) merged = normalizer.mergeAndDedupe(append(merged, summary.comments));

        FileReviewResult result = buildResult(file, index, total, completed + 1, total - completed - 1, merged, summary, chunkResults);
        result.largeFile = true;
        result.totalLines = chunker.lineCount(file.content);
        result.totalChunks = totalChunks;
        result.summary = "Large file reviewed using method/chunk-level analysis. " + (summary.fileSummary == null ? "" : summary.fileSummary);
        return result;
    }

    private List<ReviewIssue> append(List<ReviewIssue> base, List<ReviewIssue> extra) {
        List<ReviewIssue> all = new ArrayList<>(base);
        all.addAll(extra);
        return all;
    }

    private ChunkReviewResult buildChunkResult(CodeChunk chunk, LlmReviewerAgent.LlmResult llm) {
        ChunkReviewResult result = new ChunkReviewResult();
        result.chunkId = chunk.chunkId;
        result.chunkName = chunk.name;
        result.chunkType = chunk.chunkType;
        result.startLine = chunk.startLine;
        result.endLine = chunk.endLine;
        result.riskScore = chunk.riskScore;
        result.comments.addAll(llm.comments == null ? Collections.emptyList() : llm.comments);
        result.severity = normalizer.highestSeverity(result.comments, llm.highestSeverity);
        result.score = normalizer.calculateScore(result.severity, result.comments.size(), 1);
        result.summary = llm.fileSummary;
        return result;
    }

    private FileReviewResult buildResult(ReviewFile file, int index, int total, int completed, int queued,
                                         List<ReviewIssue> issues, LlmReviewerAgent.LlmResult llm,
                                         List<ChunkReviewResult> chunks) {
        List<ReviewIssue> merged = normalizer.mergeAndDedupe(append(issues, llm.comments == null ? Collections.emptyList() : llm.comments));
        FileReviewResult result = new FileReviewResult();
        result.fileName = file.fileName;
        result.filePath = file.relativePath;
        result.fileIndex = index;
        result.totalFiles = total;
        result.completedFiles = completed;
        result.queuedFiles = queued;
        result.reviewType = file.persona;
        result.comments.addAll(merged);
        result.chunks.addAll(chunks);
        result.severity = normalizer.highestSeverity(result.comments, llm.highestSeverity);
        result.score = result.severity.equals("PASSED") ? 95 : normalizer.calculateScore(result.severity, result.comments.size(), chunks.size());
        result.summary = llm.fileSummary == null || llm.fileSummary.isBlank()
                ? "Review completed for " + file.fileName : llm.fileSummary;
        return result;
    }

    private void sleepSmall() {
        try { Thread.sleep(250); } catch (InterruptedException ignored) { Thread.currentThread().interrupt(); }
    }
}
