package com.astra.codereview.agent;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

import java.io.IOException;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

@Component
public class ReviewProgressAgent {
    private final Map<String, SseEmitter> emitters = new ConcurrentHashMap<>();
    private final Map<String, List<Object>> eventBacklog = new ConcurrentHashMap<>();
    private final ObjectMapper mapper = new ObjectMapper();

    public SseEmitter register(String reviewId) {
        SseEmitter emitter = new SseEmitter(30 * 60 * 1000L);
        emitters.put(reviewId, emitter);
        emitter.onCompletion(() -> emitters.remove(reviewId));
        emitter.onTimeout(() -> emitters.remove(reviewId));
        emitter.onError(e -> emitters.remove(reviewId));

        List<Object> backlog = eventBacklog.remove(reviewId);
        if (backlog != null) backlog.forEach(event -> send(reviewId, emitter, event));
        return emitter;
    }

    public void publish(String reviewId, Object event) {
        SseEmitter emitter = emitters.get(reviewId);
        if (emitter == null) {
            eventBacklog.computeIfAbsent(reviewId, k -> Collections.synchronizedList(new ArrayList<>())).add(event);
            return;
        }
        send(reviewId, emitter, event);
    }

    private void send(String reviewId, SseEmitter emitter, Object event) {
        try {
            emitter.send(SseEmitter.event()
                    .name("review-event")
                    .data(mapper.writeValueAsString(event)));
        } catch (IOException e) {
            emitters.remove(reviewId);
        }
    }

    public void complete(String reviewId) {
        SseEmitter emitter = emitters.remove(reviewId);
        eventBacklog.remove(reviewId);
        if (emitter != null) emitter.complete();
    }
}
