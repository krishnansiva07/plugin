package com.astra.codereview.agent;

import com.astra.codereview.model.CodeChunk;
import com.astra.codereview.model.ReviewFile;
import com.astra.codereview.model.ReviewIssue;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class PromptBuilderAgent {
    public String buildPrompt(ReviewFile file, List<ReviewIssue> ruleIssues) {
        String clipped = file.content.length() > 16000 ? file.content.substring(0, 16000) + "\n// clipped for review" : file.content;
        return basePrompt(file, ruleIssues, "FULL_FILE", file.fileName, 1, lineCount(file.content), clipped,
                "Review the complete file and produce file-level review comments.");
    }

    public String buildChunkPrompt(ReviewFile file, CodeChunk chunk, List<ReviewIssue> fileRuleIssues) {
        String instruction = """
                This is a chunk-level review for a large file. Review only this chunk, but use the file context and deterministic findings to avoid generic comments.
                If the issue is specific to this method/block, include the exact chunk line number range.
                Do not comment about missing code outside this chunk unless it is clearly visible in the chunk.
                """;
        return basePrompt(file, fileRuleIssues, chunk.chunkType, chunk.name, chunk.startLine, chunk.endLine, chunk.content, instruction);
    }

    public String buildClassSummaryPrompt(ReviewFile file, List<ReviewIssue> mergedIssues, List<String> chunkSummaries) {
        StringBuilder issueText = new StringBuilder();
        for (ReviewIssue issue : mergedIssues) {
            issueText.append("- ").append(issue.severity).append(" | ").append(issue.category)
                    .append(" | line ").append(issue.lineNumber).append(" | ").append(issue.whatIsWrong).append("\n");
        }
        String summaries = String.join("\n", chunkSummaries);
        return """
                You are ASTRA CODE REVIEW AGENT.

                Review Persona: %s
                File Type: %s
                File Path: %s

                This file was reviewed chunk by chunk. Generate a final class/file level summary only.
                Do not create new detailed comments unless absolutely necessary.
                Focus on architecture, maintainability, single responsibility, testability, and PR readiness.

                Chunk summaries:
                %s

                Merged issue list:
                %s

                Return only valid JSON:
                {
                  "fileSummary": "short practical summary",
                  "score": 0,
                  "highestSeverity": "CRITICAL|MAJOR|MINOR|GOOD_TO_HAVE|PASSED",
                  "comments": []
                }
                """.formatted(file.persona, file.fileType, file.relativePath, summaries, issueText);
    }

    private String basePrompt(ReviewFile file, List<ReviewIssue> ruleIssues, String chunkType, String chunkName,
                              int startLine, int endLine, String content, String instruction) {
        StringBuilder ruleText = new StringBuilder();
        for (ReviewIssue issue : ruleIssues) {
            ruleText.append("- ").append(issue.severity).append(" | ").append(issue.category)
                    .append(" | line ").append(issue.lineNumber).append(" | ").append(issue.whatIsWrong).append("\n");
        }
        if (ruleText.isEmpty()) ruleText.append("None\n");

        return """
                You are ASTRA CODE REVIEW AGENT.

                Review Persona: %s
                File Type: %s
                File Path: %s
                Review Scope: %s
                Chunk Name: %s
                Chunk Lines: %d-%d

                Existing deterministic rule findings for this file:
                %s

                Review instructions:
                1. %s
                2. Focus on practical pre-PR review comments for developer/QA.
                3. Do not repeat deterministic findings unless you improve them.
                4. Classify severity as CRITICAL, MAJOR, MINOR, GOOD_TO_HAVE.
                5. Return only valid JSON. No markdown.

                Required JSON format:
                {
                  "fileSummary": "short practical summary",
                  "score": 0,
                  "highestSeverity": "CRITICAL|MAJOR|MINOR|GOOD_TO_HAVE|PASSED",
                  "comments": [
                    {
                      "severity": "MAJOR",
                      "category": "API Design",
                      "lineNumber": 12,
                      "whatIsWrong": "...",
                      "whyItMatters": "...",
                      "whatNeedsToBeChanged": "...",
                      "suggestedCode": "...",
                      "prComment": "..."
                    }
                  ]
                }

                Code content:
                ```
                %s
                ```
                """.formatted(file.persona, file.fileType, file.relativePath, chunkType, chunkName, startLine, endLine, ruleText, instruction, content);
    }

    private int lineCount(String content) {
        return content == null || content.isBlank() ? 0 : content.split("\\R", -1).length;
    }
}
