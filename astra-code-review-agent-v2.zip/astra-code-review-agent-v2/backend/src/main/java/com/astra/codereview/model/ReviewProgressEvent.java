package com.astra.codereview.model;

import java.util.ArrayList;
import java.util.List;

public class ReviewProgressEvent {
    public String eventType;
    public String reviewId;
    public String fileName;
    public int fileIndex;
    public int totalFiles;
    public int completedFiles;
    public int queuedFiles;
    public String status;
    public String message;

    // V2 large-file / chunk level progress
    public String filePath;
    public boolean largeFile;
    public int totalChunks;
    public int completedChunks;
    public String chunkId;
    public String chunkName;
    public String chunkType;
    public int chunkStartLine;
    public int chunkEndLine;
    public int riskScore;
    public List<ReviewIssue> partialComments = new ArrayList<>();

    public static ReviewProgressEvent of(String eventType, String reviewId, String fileName, int fileIndex,
                                         int totalFiles, int completedFiles, int queuedFiles, String status, String message) {
        ReviewProgressEvent event = new ReviewProgressEvent();
        event.eventType = eventType;
        event.reviewId = reviewId;
        event.fileName = fileName;
        event.fileIndex = fileIndex;
        event.totalFiles = totalFiles;
        event.completedFiles = completedFiles;
        event.queuedFiles = queuedFiles;
        event.status = status;
        event.message = message;
        return event;
    }

    public static ReviewProgressEvent chunk(String eventType, String reviewId, ReviewFile file, CodeChunk chunk,
                                            int fileIndex, int totalFiles, int completedFiles, int queuedFiles,
                                            int completedChunks, int totalChunks, String message) {
        ReviewProgressEvent event = of(eventType, reviewId, file.fileName, fileIndex, totalFiles, completedFiles, queuedFiles, "RUNNING", message);
        event.filePath = file.relativePath;
        event.largeFile = true;
        event.totalChunks = totalChunks;
        event.completedChunks = completedChunks;
        event.chunkId = chunk.chunkId;
        event.chunkName = chunk.name;
        event.chunkType = chunk.chunkType;
        event.chunkStartLine = chunk.startLine;
        event.chunkEndLine = chunk.endLine;
        event.riskScore = chunk.riskScore;
        return event;
    }
}
