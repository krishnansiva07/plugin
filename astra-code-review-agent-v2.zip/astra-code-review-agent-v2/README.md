# ASTRA Code Review Agent V2

Local AI-powered pre-PR code review tool for developers, QA automation engineers, and DevOps files.

## What is new in V2

- Large file detection for source files above 300 lines.
- Method/chunk-level review for large Java/JS/TS files.
- Risk-based chunk ordering so the risky methods are reviewed first.
- Real-time chunk events through SSE.
- Partial comments become visible while the same large file is still running.
- Final class-level summary after all chunks complete.
- Duplicate issue normalization before final file result.
- UI shows chunk progress, current chunk name, risk score, and partial comments.

## Current flow

1. Select full folder or selected files.
2. Click Start Review.
3. ASTRA creates a file queue.
4. For normal files, comments appear after file completion.
5. For large files, ASTRA creates chunks and streams chunk-level comments.
6. UI updates file cards immediately.
7. Final summary is generated at the end.

## Backend

```bash
cd backend
mvn spring-boot:run
```

Backend runs on:

```text
http://localhost:8090
```

## Frontend

```bash
cd frontend
npm install
npm run dev
```

Frontend runs on:

```text
http://localhost:5173
```

## Mock mode

Default configuration uses mock mode so you can demo without API cost.

```properties
llm.mock-mode=true
```

## Real LLM mode

Set environment variables:

```bash
set LLM_API_KEY=your-key
set LLM_BASE_URL=https://ai4devs.group.echonet/api/v1
set LLM_MODEL_NAME=gpt-oss-120b
set LLM_MOCK_MODE=false
```

## V2 event types

```text
REVIEW_STARTED
FILE_STARTED
RULE_CHECK_RUNNING
RULE_CHECK_COMPLETED
LARGE_FILE_DETECTED
CHUNK_STARTED
CHUNK_COMPLETED
CLASS_SUMMARY_RUNNING
FILE_COMPLETED
REVIEW_COMPLETED
```

## Important note

The app is a local review assistant. It is not meant to replace human PR approval. Use it to catch issues before sending code for formal review.
