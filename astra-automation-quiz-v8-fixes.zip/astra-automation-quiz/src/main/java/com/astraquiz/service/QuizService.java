package com.astraquiz.service;

import com.astraquiz.dto.*;
import com.astraquiz.model.*;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

@Service
public class QuizService {
    private final LlmQuizService llmQuizService;
    private final Map<String, QuizSession> sessions = new ConcurrentHashMap<>();

    public QuizService(LlmQuizService llmQuizService) { this.llmQuizService = llmQuizService; }

    public QuizSession create(CreateQuizRequest req) {
        if (req.teamNames == null || req.teamNames.isEmpty()) throw new IllegalArgumentException("At least one team is required");
        QuizSession s = new QuizSession();
        s.setQuizId("ASTRA-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase());
        s.setQuizName(req.quizName == null || req.quizName.isBlank() ? "Astra Automation Quiz" : req.quizName);
        s.setQuizCategory(req.quizCategory == null || req.quizCategory.isBlank() ? "Automation Testing" : req.quizCategory.trim());
        s.setAudience(req.audience == null || req.audience.isBlank() ? "Quiz participants" : req.audience.trim());
        s.setTeams(req.teamNames.stream().filter(x -> x != null && !x.isBlank()).map(String::trim).map(Team::new).toList());
        s.setTechnologies(req.technologies == null || req.technologies.isEmpty() ? List.of("Automation Testing") : req.technologies);
        s.setSimplePerTeam(req.simplePerTeam); s.setMediumPerTeam(req.mediumPerTeam); s.setComplexPerTeam(req.complexPerTeam);
        s.setSimplePoints(req.simplePoints); s.setMediumPoints(req.mediumPoints); s.setComplexPoints(req.complexPoints);
        s.setSimpleSeconds(req.simpleSeconds <= 0 ? 30 : req.simpleSeconds);
        s.setMediumSeconds(req.mediumSeconds <= 0 ? 45 : req.mediumSeconds);
        s.setComplexSeconds(req.complexSeconds <= 0 ? 60 : req.complexSeconds);
        s.setManualMode(req.manualMode);
        if (req.manualMode) {
            List<QuizQuestion> bank = toQuestionBank(req.manualQuestions);
            if (bank.isEmpty()) throw new IllegalArgumentException("Manual mode is enabled. Upload at least one valid JSON question.");
            s.setManualQuestionBank(bank);
            validateManualBankAvailability(s);
        }
        s.setStatus("LIVE"); sessions.put(s.getQuizId(), s); return s;
    }

    public QuizSession get(String id) { return Optional.ofNullable(sessions.get(id)).orElseThrow(() -> new IllegalArgumentException("Quiz not found: " + id)); }

    public QuizQuestion nextQuestion(String quizId) {
        QuizSession s = get(quizId);
        synchronized (s) {
            Optional<TeamDifficulty> next = findNextTurn(s);
            if (next.isEmpty()) { s.setStatus("ENDED"); throw new IllegalStateException("Quiz completed. No more questions."); }
            Team team = next.get().team;
            Difficulty difficulty = next.get().difficulty;
            int points = points(s, difficulty);
            String tech = s.getTechnologies().get(s.getQuestions().size() % s.getTechnologies().size());
            QuizQuestion q;
            if (s.isManualMode()) {
                q = pickManualQuestion(s, team.getName(), tech, difficulty, points);
            } else {
                List<String> asked = s.getQuestions().stream().map(QuizQuestion::getQuestionText).limit(20).toList();
                q = llmQuizService.generateQuestion(team.getName(), s.getQuizCategory(), s.getAudience(), tech, difficulty, points, asked);
            }
            team.increment(difficulty);
            s.getQuestions().add(q);
            return q;
        }
    }

    public ActionResponse skipCurrentQuestion(String quizId) {
        QuizSession s = get(quizId);
        synchronized (s) {
            QuizQuestion q = current(s);
            if (q.getStatus() != QuestionStatus.ACTIVE && q.getStatus() != QuestionStatus.CENTRAL_POOL) {
                throw new IllegalStateException("Only active or central pool questions can be skipped");
            }
            q.setStatus(QuestionStatus.SKIPPED);
            q.setWinnerTeam(null);
            q.setPrimaryAnswer(null);
            q.setStealAnswer(null);
            team(s, q.getAssignedTeam()).decrement(q.getDifficulty());
            // Restore turn so the replacement question is generated for the same assigned team.
            for (int i = 0; i < s.getTeams().size(); i++) {
                if (s.getTeams().get(i).getName().equalsIgnoreCase(q.getAssignedTeam())) {
                    s.setCurrentTeamIndex(i);
                    break;
                }
            }
            return new ActionResponse(true, "Question skipped. No points awarded. Generate a replacement question for the same team.", snapshot(s));
        }
    }

    public ActionResponse submitPrimary(String quizId, AnswerRequest req) {
        QuizSession s = get(quizId);
        synchronized (s) {
            QuizQuestion q = current(s);
            if (q.getStatus() != QuestionStatus.ACTIVE) {
                throw new IllegalStateException("This question is already submitted/closed. Click Generate Next Question.");
            }
            q.setPrimaryAnswer(normalize(req.answer));
            boolean correct = q.getCorrectOption().equalsIgnoreCase(q.getPrimaryAnswer());
            if (correct) {
                team(s, q.getAssignedTeam()).addScore(q.getPoints());
                q.setStatus(QuestionStatus.PRIMARY_CORRECT); q.setWinnerTeam(q.getAssignedTeam());
                return new ActionResponse(true, q.getAssignedTeam() + " correct. +" + q.getPoints(), snapshot(s));
            }
            q.setStatus(QuestionStatus.CENTRAL_POOL);
            return new ActionResponse(false, q.getAssignedTeam() + " wrong/no answer. Question moved to Central Pool.", snapshot(s));
        }
    }

    public ActionResponse submitSteal(String quizId, AnswerRequest req) {
        QuizSession s = get(quizId);
        synchronized (s) {
            QuizQuestion q = current(s);
            if (q.getStatus() != QuestionStatus.CENTRAL_POOL) throw new IllegalStateException("Central pool is not open for this question");
            String stealingTeam = req.teamName;
            if (stealingTeam == null || stealingTeam.isBlank()) throw new IllegalArgumentException("Select stealing team");
            if (stealingTeam.equalsIgnoreCase(q.getAssignedTeam())) throw new IllegalArgumentException("Assigned team cannot steal its own question");
            q.setStealAnswer(normalize(req.answer));
            if (q.getStealAnswer().isBlank()) {
                q.setStatus(QuestionStatus.CLOSED);
                return new ActionResponse(false, "No steal answer selected. No points awarded.", snapshot(s));
            }
            boolean correct = q.getCorrectOption().equalsIgnoreCase(q.getStealAnswer());
            if (correct) {
                team(s, stealingTeam).addScore(q.getPoints());
                q.setStatus(QuestionStatus.STOLEN); q.setWinnerTeam(stealingTeam);
                return new ActionResponse(true, stealingTeam + " stole the question. +" + q.getPoints(), snapshot(s));
            }
            q.setStatus(QuestionStatus.CLOSED);
            return new ActionResponse(false, "Steal answer wrong. No points awarded.", snapshot(s));
        }
    }

    public Object snapshot(QuizSession s) {
        Map<String, Object> out = new LinkedHashMap<>(); out.put("quiz", s); out.put("leaderboard", leaderboard(s)); return out;
    }
    public List<Team> leaderboard(QuizSession s) { return s.getTeams().stream().sorted(Comparator.comparingInt(Team::getScore).reversed()).toList(); }

    private List<QuizQuestion> toQuestionBank(List<ManualQuestionDto> manualQuestions) {
        if (manualQuestions == null) return new ArrayList<>();
        List<QuizQuestion> out = new ArrayList<>();
        int i = 1;
        for (ManualQuestionDto m : manualQuestions) {
            if (m == null || m.questionText == null || m.questionText.isBlank() || m.correctOption == null || m.correctOption.isBlank()) continue;
            QuizQuestion q = new QuizQuestion();
            q.setId("MANUAL-Q" + i++);
            q.setTechnology(m.technology == null || m.technology.isBlank() ? "Manual" : m.technology.trim());
            q.setDifficulty(parseDifficulty(m.difficulty));
            q.setPoints(m.points);
            q.setQuestionText(m.questionText.trim());
            q.setOptions(normalizeOptions(m.options));
            q.setCorrectOption(normalize(m.correctOption));
            q.setExplanation(m.explanation == null || m.explanation.isBlank() ? "No explanation provided." : m.explanation.trim());
            out.add(q);
        }
        return out;
    }

    private Map<String, String> normalizeOptions(Map<String, String> options) {
        Map<String, String> out = new LinkedHashMap<>();
        if (options != null) {
            for (String key : List.of("A", "B", "C", "D")) {
                String v = options.get(key);
                if (v == null) v = options.get(key.toLowerCase());
                if (v != null && !v.isBlank()) out.put(key, v.trim());
            }
        }
        if (out.isEmpty()) {
            out.put("A", "Option A"); out.put("B", "Option B"); out.put("C", "Option C"); out.put("D", "Option D");
        }
        return out;
    }

    private Difficulty parseDifficulty(String raw) {
        if (raw == null) return Difficulty.SIMPLE;
        try { return Difficulty.valueOf(raw.trim().toUpperCase()); }
        catch (Exception e) { return Difficulty.SIMPLE; }
    }

    private void validateManualBankAvailability(QuizSession s) {
        Map<Difficulty, Long> counts = s.getManualQuestionBank().stream().collect(Collectors.groupingBy(QuizQuestion::getDifficulty, Collectors.counting()));
        int teams = s.getTeams().size();
        List<String> warnings = new ArrayList<>();
        if (counts.getOrDefault(Difficulty.SIMPLE, 0L) < (long) teams * s.getSimplePerTeam()) warnings.add("SIMPLE");
        if (counts.getOrDefault(Difficulty.MEDIUM, 0L) < (long) teams * s.getMediumPerTeam()) warnings.add("MEDIUM");
        if (counts.getOrDefault(Difficulty.COMPLEX, 0L) < (long) teams * s.getComplexPerTeam()) warnings.add("COMPLEX");
        if (!warnings.isEmpty()) {
            System.out.println("[Astra Quiz] Manual question bank has fewer unique questions for: " + warnings + ". The app will reuse questions only if needed.");
        }
    }

    private QuizQuestion pickManualQuestion(QuizSession s, String teamName, String defaultTech, Difficulty difficulty, int points) {
        List<QuizQuestion> matching = s.getManualQuestionBank().stream()
                .filter(q -> q.getDifficulty() == difficulty)
                .toList();
        if (matching.isEmpty()) throw new IllegalStateException("No manual questions found for difficulty: " + difficulty);

        Optional<QuizQuestion> unused = matching.stream().filter(q -> !s.getUsedManualQuestionIds().contains(q.getId())).findFirst();
        QuizQuestion template = unused.orElse(matching.get(s.getQuestions().size() % matching.size()));
        s.getUsedManualQuestionIds().add(template.getId());

        QuizQuestion q = new QuizQuestion();
        q.setId(UUID.randomUUID().toString());
        q.setAssignedTeam(teamName);
        q.setTechnology(template.getTechnology() == null || template.getTechnology().isBlank() ? defaultTech : template.getTechnology());
        q.setDifficulty(difficulty);
        q.setPoints(points);
        q.setQuestionText(template.getQuestionText());
        q.setOptions(new LinkedHashMap<>(template.getOptions()));
        q.setCorrectOption(normalize(template.getCorrectOption()));
        q.setExplanation(template.getExplanation());
        q.setStatus(QuestionStatus.ACTIVE);
        return q;
    }

    private Optional<TeamDifficulty> findNextTurn(QuizSession s) {
        Difficulty[] order = {Difficulty.SIMPLE, Difficulty.MEDIUM, Difficulty.COMPLEX};
        for (Difficulty d : order) {
            for (int i = 0; i < s.getTeams().size(); i++) {
                int idx = (s.getCurrentTeamIndex() + i) % s.getTeams().size(); Team t = s.getTeams().get(idx);
                if (remaining(s, t, d)) { s.setCurrentTeamIndex((idx + 1) % s.getTeams().size()); return Optional.of(new TeamDifficulty(t, d)); }
            }
        }
        return Optional.empty();
    }
    private boolean remaining(QuizSession s, Team t, Difficulty d) {
        return switch (d) { case SIMPLE -> t.getSimpleAsked() < s.getSimplePerTeam(); case MEDIUM -> t.getMediumAsked() < s.getMediumPerTeam(); case COMPLEX -> t.getComplexAsked() < s.getComplexPerTeam(); };
    }
    private int points(QuizSession s, Difficulty d) { return switch (d) { case SIMPLE -> s.getSimplePoints(); case MEDIUM -> s.getMediumPoints(); case COMPLEX -> s.getComplexPoints(); }; }
    private Team team(QuizSession s, String name) { return s.getTeams().stream().filter(t -> t.getName().equalsIgnoreCase(name)).findFirst().orElseThrow(() -> new IllegalArgumentException("Team not found: " + name)); }
    private QuizQuestion current(QuizSession s) { if (s.getQuestions().isEmpty()) throw new IllegalStateException("Generate a question first"); return s.getQuestions().get(s.getQuestions().size() - 1); }
    private String normalize(String a) { return a == null ? "" : a.trim().toUpperCase().substring(0, Math.min(1, a.trim().length())); }
    private record TeamDifficulty(Team team, Difficulty difficulty) {}
}
