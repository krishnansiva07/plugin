# Astra Automation Quiz

A single-screen live quiz host application for Teams/forum sessions. Supports LLM-generated quizzes and Manual JSON question bank mode.

## Latest fixes included

- Option dropdowns load A/B/C/D values from the generated/uploaded question.
- Quiz Master answer panel is automatically hidden when a question moves to Central Pool.
- Timer configuration per difficulty:
  - Simple: default 30 seconds
  - Medium: default 45 seconds
  - Complex: default 60 seconds
- Timer starts automatically when `Generate Next Question` is clicked.
- Duplicate scoring prevented at UI and backend level.
- Skip Question option added. Skipped question gives no points and does not consume the team's quota; the replacement question goes to the same team.
- Version number removed from UI.

## Run

```bash
mvn clean package
java -jar target/astra-automation-quiz-1.0.0.jar
```

Open:

```text
http://localhost:8090/index.html
```

## LLM configuration

```properties
astra.llm.demo-mode=false
astra.llm.base-url=https://ai4devs.group.echonet/api/v1
astra.llm.api-key=YOUR_API_KEY
astra.llm.model-name=gpt-oss-120b
astra.llm.timeout-ms=60000
```

The app uses LangChain4j `chatModel.generate(prompt)` and does not manually append `/chat/completions` or `/completions` in application code.

## Manual JSON mode

Upload JSON in this format:

```json
{
  "questions": [
    {
      "topic": "Selenium Java",
      "difficulty": "SIMPLE",
      "questionType": "CHOOSE_BEST",
      "questionText": "Which Selenium wait is best for waiting until a button becomes clickable?",
      "options": {
        "A": "Thread.sleep()",
        "B": "WebDriverWait with elementToBeClickable",
        "C": "driver.close()",
        "D": "Implicit wait of 30 minutes"
      },
      "correctOption": "B",
      "explanation": "WebDriverWait waits for the condition and reduces flaky tests."
    }
  ]
}
```
