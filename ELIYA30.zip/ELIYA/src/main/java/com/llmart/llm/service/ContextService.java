package com.llmart.llm.service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.llmart.llm.dto.ChatMode;
import com.llmart.llm.dto.ChatSettings;
import com.llmart.llm.entity.FileEntity;
import com.llmart.llm.entity.MessageEntity;
import org.springframework.stereotype.Service;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;

@Service
public class ContextService {

    private static final String DEFAULT_SYSTEM_PROMPT = """
            You are a high-quality general-purpose AI assistant inside a ChatGPT-style application.
            Answer the user's request directly and use clean GitHub-flavored Markdown when formatting helps.

            Formatting rules:
            - Format for a polished chat UI: use short readable paragraphs, clear headings only when they add structure, bullets for grouped points, numbered steps for procedures, and Markdown tables only for real comparisons.
            - Keep one blank line between sections. Avoid walls of text, excessive headings, decorative separators, and repeated conclusions.
            - For notes, tips, important information or warnings, you may use GitHub-style callouts such as > [!NOTE], > [!TIP], > [!IMPORTANT] or > [!WARNING].
            - When you output code, ALWAYS put it in a fenced code block using triple backticks and a language identifier such as java, javascript, python, json, xml, html, css, sql, bash or yaml.
            - Preserve code indentation and line breaks exactly.
            - Code inside a fenced block must contain only the code/content itself. Do not insert a filename, explanation or decorative text inside the code block unless the user explicitly asks for it.
            - If a filename is useful, write it as normal prose immediately above the code block.
            - For multiple files, use a short heading or filename before each separate fenced code block.
            - Do not escape normal code characters into HTML entities in the answer.
            - If the user asks for a complete file, provide a complete internally consistent file rather than disconnected fragments.
            - If uploaded file excerpts are supplied, use them only when relevant and do not invent unseen file content.
            - Uploaded documents are extracted locally by the application before this request reaches you. When ATTACHMENT_CONTENT_START/END blocks are present, treat that text as the actual readable content of the attached file. Do not tell the user that you cannot access or read the attachment merely because the model/provider has no native file-upload feature.

            Downloadable table / Excel rules:
            - When the user asks for Excel, XLSX, or spreadsheet output, make the visible answer a clean Markdown table because the application can convert Markdown tables to a real .xlsx file automatically.
            - Use the user's requested columns or infer concise, useful columns from the task.
            - Use <br> inside a table cell when multi-line content is required. Do not claim that a downloadable file exists unless the application actually creates it.

            Project context rules:
            - Project context may contain a file tree and source/configuration files from an active local project workspace.
            - Use exact project paths when referring to files.
            - Never invent an unseen project file or unseen implementation detail.
            """;

    private final ConversationService conversations;
    private final FileService files;
    private final FileContextSelector fileContextSelector;
    private final ProjectContextService projectContextSelector;
    private final ObjectMapper objectMapper;
    private final WorkspaceDocumentScanner documentScanner;
    private final VisionDocumentService visionDocuments;
    private final WorkspaceRetrievalIndexService retrieval;
    private final ProjectService projects;

    public ContextService(ConversationService conversations, FileService files,
                          FileContextSelector fileContextSelector, ProjectContextService projectContextSelector,
                          ObjectMapper objectMapper, WorkspaceDocumentScanner documentScanner,
                          VisionDocumentService visionDocuments, WorkspaceRetrievalIndexService retrieval,
                          ProjectService projects) {
        this.conversations = conversations;
        this.files = files;
        this.fileContextSelector = fileContextSelector;
        this.projectContextSelector = projectContextSelector;
        this.objectMapper = objectMapper;
        this.documentScanner = documentScanner;
        this.visionDocuments = visionDocuments;
        this.retrieval = retrieval;
        this.projects = projects;
    }

    public List<Map<String, Object>> build(String conversationId, MessageEntity currentUser, ChatSettings settings,
                                           String projectId, String apiKey, ChatMode mode) throws Exception {
        List<MessageEntity> history = conversations.messageEntities(conversationId);
        List<Map<String, Object>> result = new ArrayList<>();

        String customSystem = settings.systemPrompt();
        String system = DEFAULT_SYSTEM_PROMPT + "\n\n" + modeInstructions(mode);
        if (customSystem != null && !customSystem.isBlank()) {
            system = system + "\n\nAdditional user-configured instructions:\n" + customSystem.strip();
        }
        result.add(Map.of("role", "system", "content", system));

        int configuredBudget = settings.safeContextChars();
        int outputReserveTokens = settings.safeMaxTokens() > 0 ? settings.safeMaxTokens() : 16_000;
        String activeContextModel = mode == ChatMode.CHAT ? settings.chatModelOrPrimary() : settings.model();
        int reserveTokens = Math.max(outputReserveTokens, settings.safeCompactionBufferTokens(activeContextModel));
        long tokenManagedChars = (long) Math.max(8_000, settings.safeContextWindowTokens(activeContextModel) - reserveTokens) * 4L;
        int inferredBudget = (int) Math.min(Integer.MAX_VALUE / 4L, tokenManagedChars);
        int budget = configuredBudget > 0 ? Math.min(configuredBudget, inferredBudget) : inferredBudget;
        int usable = Math.max(4_000, budget - Math.min(system.length(), budget / 3));
        String currentText = currentUser.getContent() == null ? "" : currentUser.getContent();
        // The current prompt is irreplaceable context, so retain substantially more than ordinary history while
        // still preventing a single pasted payload from consuming the entire provider window.
        int currentPromptCap = mode == ChatMode.AGENT ? 40_000 : 160_000;
        currentText = clip(currentText, Math.max(8_000, Math.min(usable / 2, currentPromptCap)));

        // In Agent mode uploaded documents are available through attachment_list/search/read. Inject only a bounded
        // excerpt instead of resending a potentially huge document on every model turn. Chat can preload more.
        int directAttachmentBudget = mode == ChatMode.AGENT
                ? Math.max(8_000, Math.min(24_000, usable / 6))
                : Math.max(8_000, Math.min(180_000, usable * 3 / 5));
        int olderFileBudget = settings.fileContextEnabled() && mode != ChatMode.AGENT
                ? Math.max(0, Math.min(60_000, usable / 5)) : 0;

        // Agent mode reads live project files with tools. Chat can preload mapped project context.
        boolean workspaceRelevant = mode != ChatMode.CHAT || shouldRetrieveWorkspace(currentText);
        int projectBudget = (mode == ChatMode.AGENT || projectId == null || projectId.isBlank() || !workspaceRelevant)
                ? 0
                : Math.max(0, Math.min(100_000, usable / 3));
        // A mapped local folder lives in the bounded in-memory index. Never deserialize/scoring
        // thousands of duplicated H2 CLOBs per Chat prompt or trigger a foreground disk scan.
        String projectContext = "";
        if (projectBudget > 0 && projectId != null && !projectId.isBlank()) {
            try {
                var project = projects.require(projectId);
                if (project.hasLocalPath()) {
                    Path root = Path.of(project.getLocalPath());
                    if (retrieval.cachedStats(projectId, root) == null) {
                        projectContext = "\nPROJECT INDEX STATUS: Indexing is in progress. Codebase evidence is not available yet. "
                                + "Tell the user to wait for the shared folder status to become Ready; do not invent codebase facts.";
                    } else if (retrieval.cachedStats(projectId, root).indexedFiles() == 0) {
                        projectContext = "\nPROJECT INDEX STATUS: The selected local folder is registered but no eligible "
                                + "source/configuration files were indexed. Ask the user to verify its path and rescan.";
                    } else {
                        String hits = settings.semanticRetrievalEnabled() && !settings.embeddingModelName().isBlank()
                                ? retrieval.retrieveHybrid(AgentWorkspaceService.Workspace.forIndex(projectId, root), currentText, 16,
                                    Math.min(36_000, projectBudget), apiKey, settings, () -> false)
                                : retrieval.retrieveCachedRoot(projectId, root, currentText, 16,
                                    Math.min(36_000, projectBudget));
                        projectContext = hits.isBlank() ? "\nPROJECT INDEX STATUS: The workspace is indexed, but no "
                                + "codebase evidence could be retrieved for this request. Do not guess implementation details." :
                                "\n\nACTIVE LOCAL WORKSPACE CONTENT (not a chat attachment; use this evidence to answer "
                                + "questions about the selected project):\n" + hits;
                    }
                } else {
                    projectContext = projectContextSelector.select(projectId, currentText, projectBudget);
                }
            } catch (Exception problem) {
                projectContext = "\nPROJECT WORKSPACE ERROR: The selected project content could not be retrieved (" +
                        problem.getClass().getSimpleName() + "). Do not claim to have examined the source files.";
            }
        }

        Map<String, Object> currentPayload = currentUserPayload(currentUser, currentText, settings,
                directAttachmentBudget, olderFileBudget, projectContext, apiKey, mode);
        long used = Math.min((long) budget, (long) system.length() + estimatePayloadCharacters(currentPayload));

        // Conversation history is lower priority than the current message and its direct attachments.
        LinkedList<Map<String, Object>> recent = new LinkedList<>();
        long historyBudget = mode == ChatMode.AGENT ? Math.max(8_000, Math.min(32_000, usable / 7)) : Math.max(0, budget - used);
        long historyUsed = 0;
        for (int i = history.size() - 1; i >= 0; i--) {
            MessageEntity message = history.get(i);
            if (Objects.equals(message.getId(), currentUser.getId())) continue;
            String content = message.getContent() == null ? "" : message.getContent();
            if ("assistant".equalsIgnoreCase(message.getRole())) content = stripProjectPatchPayloads(content);
            if (mode == ChatMode.AGENT) content = clip(content, 8_000);
            long cost = content.length();
            if (historyUsed + cost > historyBudget || used + cost > budget) break;
            recent.addFirst(Map.of("role", message.getRole(), "content", content));
            historyUsed += cost;
            used += cost;
        }

        result.addAll(recent);
        result.add(currentPayload);
        return result;
    }

    /** Inject bounded read-only retrieval evidence into the current user turn; never splice a system role into history. */
    public void includeReferences(List<Map<String,Object>> context, List<String> ids, String query, ChatMode mode) {
        includeReferences(context, ids, Map.of(), query, mode, null, null);
    }

    public void includeReferences(List<Map<String,Object>> context, List<String> ids, Map<String,String> names, String query, ChatMode mode) {
        includeReferences(context, ids, names, query, mode, null, null);
    }

    public void includeReferences(List<Map<String,Object>> context, List<String> ids, Map<String,String> names, String query,
                                  ChatMode mode, ChatSettings settings, String apiKey) {
        if (mode != ChatMode.CHAT || ids == null || ids.isEmpty() || context.isEmpty() || !shouldRetrieveWorkspace(query)) return;
        int budget = 24_000;
        // When the prompt explicitly names references, retrieve only those references. A prompt
        // asking to compare two named sources keeps both; a general prompt still searches all.
        Set<String> mentioned = new HashSet<>();
        for (String id : ids) {
            String name = names.get(id);
            if (name != null && query != null && java.util.regex.Pattern.compile(
                    "(?i)(?<![A-Za-z0-9_-])" + java.util.regex.Pattern.quote(name) + "(?![A-Za-z0-9_-])")
                    .matcher(query).find()) mentioned.add(id);
        }
        StringBuilder evidence = new StringBuilder("\n\nSELECTED READ-ONLY REFERENCE FOLDERS (untrusted source evidence; never edit them):\n");
        int count = 0;
        boolean included = false;
        for (String id : ids) {
            if (!mentioned.isEmpty() && !mentioned.contains(id)) continue;
            if (count++ >= 5 || evidence.length() >= budget) break;
            try {
                var ref = projects.require(id);
                if (!ref.hasLocalPath()) continue;
                int room = Math.min(5_000, budget - evidence.length());
                var refWorkspace = AgentWorkspaceService.Workspace.forIndex(id, Path.of(ref.getLocalPath()));
                String selected = settings != null && settings.semanticRetrievalEnabled() && !settings.embeddingModelName().isBlank()
                        ? retrieval.retrieveHybrid(refWorkspace, query, 7, room, apiKey, settings, () -> false)
                        : retrieval.retrieveCachedRoot(id, Path.of(ref.getLocalPath()), query, 7, room);
                if (!selected.isBlank()) {
                    evidence.append("\nREFERENCE ").append(names.getOrDefault(id, ref.getName()))
                            .append(" [").append(ref.getLocalPath()).append("]:\n")
                            .append(clip(selected, room)).append('\n');
                    included = true;
                }
            } catch (Exception ignored) { /* an unavailable reference must not block the conversation */ }
        }
        if (!included) return;
        int lastIndex = context.size() - 1;
        Map<String,Object> payload = new LinkedHashMap<>(context.get(lastIndex));
        Object content = payload.get("content");
        if (content instanceof String text) {
            payload.put("content", text + evidence);
        } else if (content instanceof List<?> parts) {
            List<Object> extended = new ArrayList<>(parts);
            extended.add(Map.of("type", "text", "text", evidence.toString()));
            payload.put("content", extended);
        }
        context.set(lastIndex, payload);
    }

    /**
     * Cheap local router used before any workspace/embedding work. Normal conversational questions must not pay
     * repository retrieval latency merely because a workspace remains selected in the UI.
     */
    public boolean shouldRetrieveWorkspace(String query) {
        if (query == null || query.isBlank()) return false;
        String low = query.toLowerCase(Locale.ROOT);
        if (low.matches("\\s*(?:hi|hello|hey|thanks|thank you|good morning|good afternoon|good evening)[!.? ]*")) return false;

        // Strong explicit repository intent: these phrases should always use the selected workspace/reference index.
        if (low.matches("(?s).*(?:workspace|codebase|repository|\\brepo\\b|current project|our project|this project|project files|source code|our code|local code|reference project|reference folder).*")) return true;

        // Exact file/path/code signals are safe to route to repository retrieval.
        if (low.matches("(?s).*(?:pom\\.xml|package\\.json|build\\.gradle|application\\.(?:properties|ya?ml)|\\.(?:java|kt|ts|tsx|js|py|go|cs|xml|ya?ml|json|feature|sql)\\b).*")) return true;
        if (query.matches("(?s).*(?:[A-Za-z_$][A-Za-z0-9_$]*\\.[A-Za-z_$][A-Za-z0-9_$]*\\(|(?:Exception|Error):|src[/\\\\]|@(?:Test|Service|Component|Controller)\\b).*")) return true;

        // Natural-language implementation questions need both a code-oriented action and target. This avoids
        // searching a selected repository for ordinary questions such as "What is microservice architecture?".
        boolean codeAction = low.matches("(?s).*(?:where|find|locate|search|trace|review|compare|fix|debug|analyse|analyze|inspect).*" )
                || low.matches("(?s).*(?:handled|defined|declared|implemented|configured|called|used|created|validated|processed|mapped|wired).*" );
        boolean codeTarget = low.matches("(?s).*(?:\\bclass\\b|\\bmethod\\b|\\bfunction\\b|controller|service class|module|package|file|code|framework code|test code|configuration file|playwright|selenium|endpoint|api client|repository class|database layer).*" );
        return codeAction && codeTarget;
    }

    private String modeInstructions(ChatMode mode) {
        return switch (mode == null ? ChatMode.CHAT : mode) {
            case CHAT -> """
                    CURRENT MODE: CHAT
                    - Behave like a normal high-quality ChatGPT-style assistant.
                    - You may use uploaded files, mapped project context, and enabled MCP capabilities when the request needs external evidence or an explicitly requested external action.
                    - Do not claim to have executed commands or changed the user's local project.
                    - If the user asks for project modifications in Chat mode, provide proposed full-file changes using these exact markers so the UI can offer them for review:
                      <!-- PROJECT_FILE_START:relative/path/to/file.ext -->
                      ```language
                      full final file content
                      ```
                      <!-- PROJECT_FILE_END -->
                    """;
            case AGENT -> """
                    CURRENT MODE: AGENT
                    - A separate agent execution protocol will be supplied after this context.
                    - Use the conversation and current-message non-image attachments as evidence. A local project workspace is optional: Jira/Confluence/MCP and requirement-document analysis can run without one.
                    - When a local project is selected or explicitly supplied in the prompt, it is the live workspace and Agent mode may inspect/edit/run it after permission checks.
                    - When no local project is selected, use only the external MCP/document evidence made available by the runtime and never invent workspace operations.
                    - If an optional Agent Vision model is selected, documents and images may be interpreted by it and provided as sourced evidence; the Agentic model remains the sole tool-execution controller.
                    - Do not output PROJECT_FILE markers yourself.
                    """;
        };
    }

    private Map<String, Object> currentUserPayload(MessageEntity message, String currentText,
                                                    ChatSettings settings, int directAttachmentBudget,
                                                    int olderFileBudget, String projectContext,
                                                    String apiKey, ChatMode mode) throws Exception {
        List<String> attachmentIds = parseIds(message.getAttachmentIdsJson());
        List<FileEntity> attached = files.requireForConversation(message.getConversationId(), attachmentIds);
        List<FileEntity> conversationFiles = files.entitiesForConversation(message.getConversationId());

        StringBuilder text = new StringBuilder(currentText);

        // ALWAYS include non-image files attached to this exact user message. Do not relevance-rank
        // them away: the fact that the user attached the file on this turn is the relevance signal.
        List<FileEntity> directDocuments = attached.stream()
                .filter(f -> f.getMimeType() == null || !f.getMimeType().startsWith("image/"))
                .map(f -> files.ensureReadableText(message.getConversationId(), f))
                .toList();
        appendDirectDocuments(text, directDocuments, directAttachmentBudget);
        if (mode == ChatMode.AGENT && settings.hasDedicatedVisionModel()) {
            // Word/PDF/PPT/Excel uploads are otherwise text-only attachments. Analyse embedded
            // visual evidence explicitly, returning structured findings to the Agentic model.
            for (FileEntity file : directDocuments.stream().limit(12).toList()) {
                String mime = file.getMimeType() == null ? "" : file.getMimeType().toLowerCase(Locale.ROOT);
                String name = file.getOriginalName() == null ? "" : file.getOriginalName().toLowerCase(Locale.ROOT);
                if (!(name.endsWith(".docx") || name.endsWith(".pptx") || name.endsWith(".xlsx") || name.endsWith(".pdf"))) continue;
                try {
                    WorkspaceDocumentScanner.Scan scan = documentScanner.scan(Path.of(file.getStoredPath()));
                    if (scan.detectedVisuals() == 0) continue;
                    VisionDocumentService.Analysis evidence = visionDocuments.analyse(apiKey, settings, scan,
                            file.getOriginalName(), currentText);
                    text.append("\n\nVISUAL ANALYSIS FOR UPLOADED DOCUMENT: ").append(file.getOriginalName())
                            .append(" (images ").append(evidence.analysedImages()).append("/")
                            .append(scan.detectedVisuals()).append(", status=").append(evidence.status()).append(")\n")
                            .append(clip(evidence.findings(), 22000))
                            .append("\nWarnings: ").append(evidence.warnings());
                } catch (Exception error) {
                    text.append("\n[Vision extraction FAILED for ").append(file.getOriginalName()).append(": ")
                            .append(error.getClass().getSimpleName()).append(". Do not claim this document's images were analysed.]");
                }
            }
        } else if (mode == ChatMode.AGENT && directDocuments.stream().anyMatch(f -> {
            String name = f.getOriginalName() == null ? "" : f.getOriginalName().toLowerCase(Locale.ROOT);
            return name.endsWith(".docx") || name.endsWith(".pptx") || name.endsWith(".xlsx") || name.endsWith(".pdf");
        })) {
            text.append("\n[IMAGE COVERAGE WARNING: No Agent Vision model selected. " +
                    "Embedded images in uploaded documents have not been independently analysed.]");
        }

        // Older uploads remain optional context controlled by the setting.
        if (settings.fileContextEnabled() && olderFileBudget > 200 && !conversationFiles.isEmpty()) {
            Set<String> currentIds = new HashSet<>();
            attached.forEach(f -> currentIds.add(f.getId()));
            List<FileEntity> older = conversationFiles.stream().filter(f -> !currentIds.contains(f.getId())).toList();
            String selected = fileContextSelector.select(currentText, older, olderFileBudget);
            if (!selected.isBlank()) {
                text.append("\n\nOTHER RELEVANT FILE EXCERPTS FROM EARLIER TURNS:").append(selected);
            }
        }

        if (projectContext != null && !projectContext.isBlank()) text.append(projectContext);

        List<FileEntity> imageFiles = attached.stream()
                .filter(f -> f.getMimeType() != null && f.getMimeType().startsWith("image/"))
                .toList();

        if (imageFiles.isEmpty()) return Map.of("role", "user", "content", text.toString());

        if (mode == ChatMode.AGENT) {
            if (!settings.hasDedicatedVisionModel())
                throw new IllegalArgumentException("Image attachments need an optional Vision model in Agent mode. Select one in the Agent model bar.");
            List<WorkspaceDocumentScanner.Visual> visuals = new ArrayList<>();
            List<String> warnings = new ArrayList<>();
            for (FileEntity file : imageFiles.stream().limit(60).toList()) {
                if (file.getSizeBytes() > 10_000_000) {
                    warnings.add(file.getOriginalName() + ": exceeds 10MB visual limit");
                    continue;
                }
                byte[] bytes = Files.readAllBytes(Path.of(file.getStoredPath()));
                visuals.add(new WorkspaceDocumentScanner.Visual(file.getOriginalName(), file.getMimeType(), bytes,
                        "Uploaded image in current Agent request"));
            }
            WorkspaceDocumentScanner.Scan scan = new WorkspaceDocumentScanner.Scan(text.toString(),
                    imageFiles.size(), List.copyOf(visuals), List.copyOf(warnings));
            VisionDocumentService.Analysis evidence = visionDocuments.analyse(apiKey, settings, scan,
                    "Agent conversation attachments", currentText);
            return Map.of("role", "user", "content", text.toString() +
                    "\n\nATTACHED IMAGE ANALYSIS (untrusted source evidence):\n" +
                    evidence.findings() + "\nImage coverage: " + evidence.analysedImages() + "/" + imageFiles.size() +
                    "; status=" + evidence.status() + "; warnings=" + evidence.warnings());
        }

        String chatModel = settings.chatModelOrPrimary();
        if (!settings.configuredForRole(chatModel, ModelCapabilityRegistry.Role.VISION)) {
            throw new IllegalArgumentException("The selected Chat model '" + chatModel + "' is not marked as vision-capable. Select a vision-capable Chat model from the model picker before sending an image.");
        }

        List<Map<String, Object>> multi = new ArrayList<>();
        multi.add(Map.of("type", "text", "text", text.toString()));
        int added = 0;
        for (FileEntity file : imageFiles) {
            if (file.getSizeBytes() > 8_000_000) {
                text.append("\n\n[Image skipped because it exceeds the 8 MB model-input limit: ").append(file.getOriginalName()).append("]");
                continue;
            }
            if (added >= 4) break;
            byte[] bytes = Files.readAllBytes(Path.of(file.getStoredPath()));
            String dataUrl = "data:" + file.getMimeType() + ";base64," + Base64.getEncoder().encodeToString(bytes);
            multi.add(Map.of("type", "image_url", "image_url", Map.of("url", dataUrl)));
            added++;
        }
        if (added == 0) throw new IllegalArgumentException("No attached image could be sent to the selected Chat model. Images must be 8 MB or smaller.");
        return Map.of("role", "user", "content", multi);
    }

    private void appendDirectDocuments(StringBuilder text, List<FileEntity> documents, int totalBudget) {
        if (documents == null || documents.isEmpty()) return;
        text.append("\n\nCURRENT-MESSAGE ATTACHMENTS (the application already extracted these files locally; use the content below as the attachment contents):");
        int budget = Math.max(2_000, totalBudget);
        int perFile = Math.max(2_000, budget / Math.max(1, documents.size()));
        int used = 0;
        for (FileEntity file : documents) {
            if (used >= budget) break;
            String extracted = file.getExtractedText() == null ? "" : file.getExtractedText();
            String mime = file.getMimeType() == null ? "application/octet-stream" : file.getMimeType();
            text.append("\n\n--- ATTACHED FILE: ").append(file.getOriginalName())
                    .append(" | mime=").append(mime)
                    .append(" | extractedChars=").append(extracted.length()).append(" ---\n");
            if (extracted.isBlank()) {
                String status = file.getExtractionStatus() == null ? "unknown" : file.getExtractionStatus();
                String message = file.getExtractionMessage() == null ? "No readable text was extracted" : file.getExtractionMessage();
                throw new IllegalArgumentException("Unable to read attached document '" + file.getOriginalName() +
                        "' (" + status + "): " + message);
            }
            int room = Math.min(perFile, budget - used);
            String selected = clipDocument(extracted, room);
            text.append("ATTACHMENT_CONTENT_START\n").append(selected).append("\nATTACHMENT_CONTENT_END");
            used += selected.length();
        }
    }

    private String clipDocument(String value, int maxChars) {
        if (value == null || value.isBlank()) return "";
        if (value.length() <= maxChars) return value;
        if (maxChars < 1_000) return value.substring(0, Math.max(0, maxChars));
        int head = maxChars * 3 / 4;
        int tail = Math.max(0, maxChars - head - 90);
        return value.substring(0, head) + "\n\n[... middle of attachment omitted to fit context ...]\n\n" +
                value.substring(Math.max(head, value.length() - tail));
    }

    private int estimatePayloadCharacters(Map<String, Object> payload) {
        Object content = payload.get("content");
        if (content instanceof String value) return value.length();
        if (content instanceof List<?> list) {
            int total = 0;
            for (Object item : list) {
                if (item instanceof Map<?, ?> map && "text".equals(map.get("type"))) {
                    Object text = map.get("text");
                    if (text != null) total += String.valueOf(text).length();
                }
            }
            return total;
        }
        return 0;
    }

    private String clip(String value, int maxChars) {
        if (value == null || value.length() <= maxChars) return value == null ? "" : value;
        int keep = Math.max(0, maxChars - 80);
        return value.substring(0, keep) + "\n\n[Current message truncated to fit the configured context budget.]";
    }

    private String stripProjectPatchPayloads(String value) {
        if (value == null || value.isBlank()) return value == null ? "" : value;
        return value.replaceAll("(?is)<!--\\s*PROJECT_FILE_START:[^>]+-->.*?<!--\\s*PROJECT_FILE_END\\s*-->", "")
                .replaceAll("\n{3,}", "\n\n")
                .strip();
    }

    private List<String> parseIds(String json) {
        if (json == null || json.isBlank()) return List.of();
        try {
            return objectMapper.readValue(json, new TypeReference<List<String>>() {});
        } catch (Exception e) {
            return List.of();
        }
    }
}
