# Astra AI Automation Agent

Spring Boot + LangChain4j + Playwright MCP stdio based automation agent.

## What this build focuses on

- Browser actions run live in one continuous MCP stdio session.
- The UI does not show internal version naming.
- A pre-execution plan is generated before browser actions.
- Missing test data is detected before execution where possible.
- The agent uses the current MCP snapshot + compact trace + plan for each next action.
- Generated code is created from the executed action trace, not from blind prompt guessing.
- Playwright TypeScript and JavaScript can be validated using `npx playwright test`.

## Run

```bash
mvn clean spring-boot:run
```

Open:

```text
http://localhost:8090/index.html
```

## LLM configuration

Edit:

```text
src/main/resources/application.properties
```

Set:

```properties
llm.api-key=YOUR_KEY
llm.base-url=YOUR_OPENAI_COMPATIBLE_BASE_URL
llm.model-name=YOUR_MODEL
```

## First test

Application URL:

```text
https://www.saucedemo.com/
```

Scenario:

```text
Login using the provided username and password and verify Products page is displayed.
```

Test Data JSON:

```json
{
  "username": "standard_user",
  "password": "secret_sauce"
}
```

Expected Result:

```text
Products page should be visible.
```

Recommended first run:

- Validate generated code: unchecked
- Close browser after run: unchecked
- Show browser live: checked
- Plan before execution: checked
- No guessing: checked

After live execution works, enable validation.

## Important notes

The application starts Playwright MCP using:

```bash
npx -y @playwright/mcp@latest
```

Do not manually run MCP on port 8931 for this build. This build uses stdio mode to preserve action sequence.
