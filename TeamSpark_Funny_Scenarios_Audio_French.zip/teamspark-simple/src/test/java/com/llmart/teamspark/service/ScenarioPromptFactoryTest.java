package com.llmart.teamspark.service;

import org.junit.jupiter.api.Test;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

class ScenarioPromptFactoryTest {

    @Test
    void promptContainsStrictFunnyScenarioRules() {
        String prompt = ScenarioPromptFactory.build("Forest", List.of("Siva", "Sara"));

        assertThat(prompt)
                .contains("Forest")
                .contains("Siva, Sara")
                .contains("25 to 30 words")
                .contains("very simple everyday English")
                .contains("physically possible")
                .contains("recognisable human comedy")
                .contains("Could this really happen?")
                .contains("No magic, fantasy")
                .contains("French")
                .contains("\"english\"")
                .contains("\"french\"");
    }

    @Test
    void comedyDirectionsStayFocusedOnHumanBehaviour() {
        for (int i = 0; i < 50; i++) {
            String prompt = ScenarioPromptFactory.build("Office", List.of("Siva", "Sara"));

            assertThat(prompt)
                    .doesNotContain("an animal behaving like a very serious human")
                    .doesNotContain("an everyday object doing something completely unexpected")
                    .doesNotContain("one absurd surprise");
        }
    }
}
