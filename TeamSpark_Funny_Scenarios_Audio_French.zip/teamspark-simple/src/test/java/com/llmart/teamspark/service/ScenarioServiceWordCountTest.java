package com.llmart.teamspark.service;

import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

class ScenarioServiceWordCountTest {

    @Test
    void countsWordsUsingWhitespace() {
        String text = "You enter the office and every chair starts rolling away whenever someone tries to sit down. Your manager declares standing illegal. What do you do?";
        assertThat(ScenarioService.countWords(text)).isEqualTo(25);
    }

    @Test
    void acceptsARealisticHumanComedyScenario() {
        String scenario = "You completed the entire group project alone. During the presentation, the teammate who disappeared all week says, 'As the team leader...' What do you do?";

        assertThat(ScenarioService.rejectionReason(scenario, "College")).isNull();
    }

    @Test
    void rejectsRandomAnimalsInUnrelatedPlaces() {
        String scenario = "You enter the campus library, but every book is replaced by squeaky rubber ducks that quack the chapter titles. Quickly, what do you do now?";

        assertThat(ScenarioService.rejectionReason(scenario, "College"))
                .contains("random animal");
    }

    @Test
    void rejectsImpossibleObjectActions() {
        String scenario = "You board the plane and the luggage compartment starts serving fresh croissants to passengers while everyone cheers loudly. How do you react in front of them?";

        assertThat(ScenarioService.rejectionReason(scenario, "Aeroplane"))
                .contains("object performed an impossible human action");
    }
}
