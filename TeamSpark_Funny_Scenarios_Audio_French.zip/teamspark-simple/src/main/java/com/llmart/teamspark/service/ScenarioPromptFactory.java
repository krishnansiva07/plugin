package com.llmart.teamspark.service;

import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

public final class ScenarioPromptFactory {

    private static final List<String> COMEDY_CUES = List.of(
            "a harmless lie or excuse being exposed immediately",
            "someone acting confident and then making an obvious mistake",
            "a private message, notification or microphone appearing at the worst time",
            "someone pretending to understand and then being asked to explain",
            "a believable mix-up involving a seat, name, queue, bill, order or bag",
            "a polite social situation becoming awkward because nobody tells the truth",
            "someone taking credit for work they clearly did not do",
            "an attempt to impress the group backfiring in a believable way",
            "two people confidently giving opposite instructions",
            "an everyday habit being noticed by everyone at the worst moment"
    );

    private ScenarioPromptFactory() {
    }

    public static String build(String category, List<String> selectedMembers) {
        String players = selectedMembers == null || selectedMembers.isEmpty()
                ? "the selected players"
                : String.join(", ", selectedMembers);

        String comedyCue = COMEDY_CUES.get(ThreadLocalRandom.current().nextInt(COMEDY_CUES.size()));

        return """
                You write VERY SHORT observational comedy for a live team game.
                The humour must feel like a real incident that ordinary people could face today.

                PLACE / CATEGORY: %s
                Players answering: %s
                Human comedy direction for this turn: %s

                Create ONE situation only.

                STRICT ENGLISH RULES:
                - English MUST contain 25 to 30 words TOTAL, including the final question.
                - Use very simple everyday English. A person should understand it in 5 seconds.
                - Maximum 2 short sentences.
                - Put the player immediately inside the situation using "You".
                - Set up a normal moment in the selected place, then add ONE believable comic problem.
                - The situation must be physically possible and could genuinely happen to a person.
                - Make players laugh because they recognise the behaviour, awkwardness or bad timing.
                - Finish with a short question such as "What do you do?" or "How do you react?"
                - Do NOT mention the players' names inside the situation.

                HUMOUR RULES:
                - Use recognisable human comedy: embarrassment, misunderstanding, accidental honesty,
                  playful teasing, overconfidence, social awkwardness, bad timing or technology mistakes.
                - Keep it playful, punchy and suitable for colleagues joking on a Teams call.
                - The comic problem must directly involve the player and invite a funny answer.
                - Quietly draft several ideas and return only the funniest realistic one.
                - Before returning, ask: "Could this really happen?" If not, discard and rewrite it.
                - Do NOT create generic motivational, philosophical or serious situations.
                - Avoid boring clichés such as simply being lost, stuck, late, alone,
                  having no signal, a normal power cut, or merely dropping/losing a phone.
                - No magic, fantasy, supernatural events, talking animals, human-like animals,
                  living objects, impossible actions, random creatures or meaningless chaos.
                - Animals may appear only when natural for the selected place, must behave normally,
                  and must never replace the human joke.
                - Never use "suddenly" as a substitute for a setup or punchline.
                - No politics, religion, sexual content, insults, violence, medical emergencies,
                  illegal acts, humiliation or jokes about personal characteristics.

                STYLE EXAMPLES — LEARN THE STYLE BUT DO NOT COPY:
                GOOD: You completed the entire group project alone. During the presentation, the teammate
                who disappeared all week says, "As the team leader..." What do you do?
                GOOD: At airport security, you confidently explain efficient packing. Your bag opens,
                revealing six shampoo bottles and no passport. How do you react?
                BAD: Library books are replaced by ducks. This is random and impossible, not human comedy.
                BAD: Luggage serves croissants or a hamster rides a dinosaur. These are meaningless AI jokes.

                FRENCH RULES:
                - Translate the SAME situation naturally into simple French.
                - Keep the same joke and meaning.
                - French does not need the exact same word count.

                Return ONLY valid JSON. No markdown. No explanation.
                {"english":"25-30 word English scenario","french":"French translation"}
                """.formatted(category, players, comedyCue);
    }

    public static String correctionPrompt(String originalPrompt, String previousEnglish, String rejectionReason) {
        return originalPrompt + """

                IMPORTANT CORRECTION:
                Your previous scenario was rejected because: %s
                "%s"

                Reject it completely. Create a DIFFERENT, FUNNIER situation about ordinary people.
                It must be realistic, physically possible and based on recognisable human behaviour.
                The new English scenario MUST be between 25 and 30 words inclusive.
                Count the English words before returning the JSON.
                """.formatted(
                rejectionReason == null ? "it did not meet the quality rules" : rejectionReason,
                previousEnglish == null ? "" : previousEnglish.replace("\"", "'")
        );
    }

    public static String connectionPrompt() {
        return "Reply with exactly: TeamSpark connection successful";
    }
}
