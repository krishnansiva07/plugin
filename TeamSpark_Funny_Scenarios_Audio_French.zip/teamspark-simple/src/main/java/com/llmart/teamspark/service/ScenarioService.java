package com.llmart.teamspark.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.llmart.teamspark.dto.ScenarioResponse;
import dev.langchain4j.model.chat.ChatLanguageModel;
import dev.langchain4j.model.openai.OpenAiChatModel;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.time.Duration;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Pattern;

@Service
public class ScenarioService {

    private static final int MIN_ENGLISH_WORDS = 25;
    private static final int MAX_ENGLISH_WORDS = 30;
    private static final int MAX_GENERATION_ATTEMPTS = 3;
    private static final Set<String> ANIMAL_FRIENDLY_CATEGORIES = Set.of(
            "forest", "zoo", "hills", "desert", "beach"
    );
    private static final Pattern RANDOM_ANIMAL = Pattern.compile(
            "\\b(duck|ducks|hamster|hamsters|crocodile|crocodiles|penguin|penguins|dinosaur|dinosaurs|"
                    + "unicorn|unicorns|giraffe|giraffes|elephant|elephants|monkey|monkeys|goat|goats|"
                    + "parrot|parrots|chicken|chickens|snake|snakes)\\b",
            Pattern.CASE_INSENSITIVE
    );
    private static final Pattern IMPOSSIBLE_OBJECT_ACTION = Pattern.compile(
            "\\b(book|books|luggage|baggage|suitcase|suitcases|statue|statues|painting|paintings|"
                    + "fossil|fossils|skeleton|skeletons|chair|chairs|table|tables|door|doors|"
                    + "elevator|elevators|microphone|microphones)\\b.{0,35}\\b("
                    + "talk(?:s|ing)?|speak(?:s|ing)?|sing(?:s|ing)?|danc(?:es|ing)|throw(?:s|ing)?|"
                    + "hand(?:s|ing)?|serv(?:es|ing)|demand(?:s|ing)?|order(?:s|ing)?|"
                    + "laugh(?:s|ing)?|cr(?:ies|ying)|wink(?:s|ing)?|juggl(?:es|ing)|"
                    + "driv(?:es|ing)|run(?:s|ning)?|walk(?:s|ing)?)\\b",
            Pattern.CASE_INSENSITIVE
    );
    private static final List<String> FANTASY_PHRASES = List.of(
            "comes alive", "come alive", "starts talking", "begins talking", "starts speaking",
            "begins speaking", "magically", "teleports", "turns into", "flying luggage",
            "secret portal", "time machine", "alien invasion"
    );

    private final ObjectMapper objectMapper;
    private final String baseUrl;
    private final String modelName;

    public ScenarioService(
            ObjectMapper objectMapper,
            @Value("${llm.base-url}") String baseUrl,
            @Value("${llm.model-name}") String modelName) {
        this.objectMapper = objectMapper;
        this.baseUrl = baseUrl;
        this.modelName = modelName;
    }

    public String testConnection(String apiKey) {
        validateKey(apiKey);
        return createModel(apiKey).generate(ScenarioPromptFactory.connectionPrompt());
    }

    public ScenarioResponse generate(String apiKey, String category, List<String> selectedMembers) {
        validateKey(apiKey);

        ChatLanguageModel model = createModel(apiKey);
        String basePrompt = ScenarioPromptFactory.build(category, selectedMembers);
        String prompt = basePrompt;
        ScenarioResponse lastResponse = null;

        for (int attempt = 1; attempt <= MAX_GENERATION_ATTEMPTS; attempt++) {
            String raw = model.generate(prompt);
            lastResponse = parseResponse(raw);

            String rejectionReason = rejectionReason(lastResponse.english(), category);
            if (rejectionReason == null) {
                return lastResponse;
            }

            prompt = ScenarioPromptFactory.correctionPrompt(
                    basePrompt,
                    lastResponse.english(),
                    rejectionReason
            );
        }

        throw new IllegalStateException(
                "The model could not create a 25-30 word realistic human comedy scenario after "
                        + MAX_GENERATION_ATTEMPTS + " attempts. Please generate again."
        );
    }

    private ChatLanguageModel createModel(String apiKey) {
        return OpenAiChatModel.builder()
                .apiKey(apiKey.trim())
                .baseUrl(baseUrl)
                .modelName(modelName)
                .temperature(0.85)
                .maxTokens(300)
                .timeout(Duration.ofSeconds(60))
                .build();
    }

    private ScenarioResponse parseResponse(String raw) {
        if (!StringUtils.hasText(raw)) {
            throw new IllegalStateException("The model returned an empty response.");
        }

        String cleaned = raw.trim();
        if (cleaned.startsWith("```")) {
            cleaned = cleaned.replaceFirst("^```(?:json)?\\s*", "")
                    .replaceFirst("\\s*```$", "")
                    .trim();
        }

        try {
            JsonNode root = objectMapper.readTree(cleaned);
            String english = root.path("english").asText("").trim();
            String french = root.path("french").asText("").trim();

            if (!StringUtils.hasText(english) || !StringUtils.hasText(french)) {
                throw new IllegalStateException("The model response did not contain both English and French scenarios.");
            }
            return new ScenarioResponse(english, french);
        } catch (JsonProcessingException ex) {
            throw new IllegalStateException("The model response was not valid JSON. Please generate again.", ex);
        }
    }

    static int countWords(String text) {
        if (!StringUtils.hasText(text)) {
            return 0;
        }
        return text.trim().split("\\s+").length;
    }

    static String rejectionReason(String english, String category) {
        int wordCount = countWords(english);
        if (wordCount < MIN_ENGLISH_WORDS || wordCount > MAX_ENGLISH_WORDS) {
            return "the English scenario had " + wordCount + " words instead of 25 to 30";
        }

        String lower = english.toLowerCase(Locale.ROOT);
        if (!lower.contains("you")) {
            return "it did not put the player inside the situation using 'You'";
        }
        if (!english.trim().endsWith("?")) {
            return "it did not finish with a direct question for the player";
        }

        for (String phrase : FANTASY_PHRASES) {
            if (lower.contains(phrase)) {
                return "it used fantasy or an impossible event instead of realistic human comedy";
            }
        }
        if (IMPOSSIBLE_OBJECT_ACTION.matcher(english).find()) {
            return "an object performed an impossible human action";
        }

        String normalizedCategory = category == null ? "" : category.trim().toLowerCase(Locale.ROOT);
        if (!ANIMAL_FRIENDLY_CATEGORIES.contains(normalizedCategory)
                && RANDOM_ANIMAL.matcher(english).find()) {
            return "it inserted a random animal into a place where it does not naturally belong";
        }

        return null;
    }

    private void validateKey(String apiKey) {
        if (!StringUtils.hasText(apiKey)) {
            throw new IllegalArgumentException("Enter your API key before continuing.");
        }
    }
}
