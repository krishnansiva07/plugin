const CATEGORIES = [
    "Forest", "School", "College", "Hills", "Dark Room", "Desert", "Aeroplane",
    "Office", "Cafeteria", "Hotel", "Airport", "Train", "Beach", "Shopping Mall",
    "Elevator", "Meeting Room", "Restaurant", "Museum", "Supermarket", "Cinema",
    "Zoo", "Wedding Hall", "Parking Lot", "Cruise Ship", "Library", "Gym",
    "Conference Room", "Coffee Shop", "Rainy Street", "Theme Park"
];

const state = {
    apiKey: "",
    teamCount: 2,
    teams: [],
    selectedByTeam: {},
    usedByTeam: {},
    turn: 1,
    scenarioGenerated: false,
    modalTeamId: null
};

const $ = id => document.getElementById(id);

function idForTeam(index) {
    return (crypto.randomUUID ? crypto.randomUUID() : `team-${Date.now()}-${index}`);
}

function initialTeam(index) {
    return { id: idForTeam(index), name: `Team ${index + 1}`, members: [] };
}

function escapeHtml(value) {
    return String(value ?? "")
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#039;");
}

function showScreen(id) {
    document.querySelectorAll(".screen").forEach(screen => screen.classList.remove("active"));
    $(id).classList.add("active");
    window.scrollTo({ top: 0, behavior: "smooth" });
}

function setMessage(id, text = "", type = "") {
    const el = $(id);
    el.textContent = text;
    el.className = `message${type ? ` ${type}` : ""}`;
}

function showToast(text, error = false) {
    const toast = $("toast");
    toast.textContent = text;
    toast.className = `toast show${error ? " error" : ""}`;
    clearTimeout(showToast.timer);
    showToast.timer = setTimeout(() => toast.className = "toast", 2600);
}

function ensureTeams(count) {
    while (state.teams.length < count) {
        state.teams.push(initialTeam(state.teams.length));
    }
    if (state.teams.length > count) {
        const removed = state.teams.slice(count);
        removed.forEach(team => {
            delete state.usedByTeam[team.id];
            delete state.selectedByTeam[team.id];
        });
        state.teams = state.teams.slice(0, count);
    }
    state.teamCount = count;
    renderSetupTeams();
}

function renderSetupTeams() {
    $("setupTeams").innerHTML = state.teams.map((team, index) => `
        <article class="team-setup-card" data-team-id="${team.id}">
            <div class="team-label">
                <span class="team-number">${index + 1}</span>
                <span class="team-name">Team ${index + 1}</span>
            </div>
            <label for="team-name-${team.id}">Team name</label>
            <input id="team-name-${team.id}" data-action="team-name" data-team-id="${team.id}"
                   value="${escapeHtml(team.name)}" maxlength="40" placeholder="Enter team name">
            <div class="member-entry">
                <input data-member-input="${team.id}" maxlength="50" placeholder="Add member">
                <button class="add-button" data-action="add-member" data-team-id="${team.id}" type="button">Add</button>
            </div>
            <div class="member-list">
                ${team.members.length
                    ? team.members.map((member, memberIndex) => `
                        <span class="member-chip">${escapeHtml(member)}
                            <button data-action="remove-member" data-team-id="${team.id}" data-member-index="${memberIndex}" type="button" aria-label="Remove ${escapeHtml(member)}">×</button>
                        </span>`).join("")
                    : '<span class="empty">No members yet</span>'}
            </div>
        </article>
    `).join("");
}

function addMember(teamId, name) {
    const team = state.teams.find(t => t.id === teamId);
    if (!team) return false;
    const clean = (name || "").trim();
    if (!clean) return false;
    if (team.members.some(member => member.toLowerCase() === clean.toLowerCase())) {
        showToast(`${clean} is already in ${team.name}.`, true);
        return false;
    }
    team.members.push(clean);
    return true;
}

function addMemberFromSetup(teamId, input) {
    if (!input || !input.value.trim()) return;
    if (addMember(teamId, input.value)) {
        input.value = "";
        renderSetupTeams();
    }
}

function removeMember(teamId, memberIndex) {
    const team = state.teams.find(t => t.id === teamId);
    if (!team) return;
    const removedName = team.members[memberIndex];
    team.members.splice(memberIndex, 1);
    state.usedByTeam[teamId] = (state.usedByTeam[teamId] || []).filter(name => name !== removedName);
    if (state.selectedByTeam[teamId] === removedName) delete state.selectedByTeam[teamId];
    renderSetupTeams();
}

function validateSetup() {
    for (let i = 0; i < state.teams.length; i++) {
        const team = state.teams[i];
        if (!team.name.trim()) return `Enter a name for Team ${i + 1}.`;
        if (team.members.length === 0) return `Add at least one member to ${team.name}.`;
    }
    return null;
}

async function continueWithKey() {
    const key = $("apiKey").value.trim();
    if (!key) {
        setMessage("accessMessage", "Enter your API key.", "error");
        return;
    }

    const button = $("continueButton");
    button.disabled = true;
    button.textContent = "Checking…";
    setMessage("accessMessage");

    try {
        const response = await fetch("/api/game/test-connection", {
            method: "POST",
            headers: { "X-LLM-API-Key": key }
        });
        const data = await response.json().catch(() => ({}));
        if (!response.ok || !data.success) {
            throw new Error(data.message || "Unable to validate the key.");
        }

        state.apiKey = key;
        $("apiKey").value = "";
        ensureTeams(state.teamCount);
        showScreen("setupScreen");
    } catch (error) {
        setMessage("accessMessage", error.message || "Connection failed.", "error");
    } finally {
        button.disabled = false;
        button.textContent = "Continue";
    }
}

function startGame() {
    const error = validateSetup();
    if (error) {
        showToast(error, true);
        return;
    }

    state.turn = 1;
    state.selectedByTeam = {};
    state.usedByTeam = {};
    state.scenarioGenerated = false;
    $("turnNumber").textContent = state.turn;
    $("turnBadge").classList.remove("hidden");
    resetChallenge();
    renderGameTeams();
    showScreen("gameScreen");
}

function renderGameTeams() {
    $("gameTeams").innerHTML = state.teams.map(team => {
        const selected = state.selectedByTeam[team.id];
        return `
            <article class="game-team-card">
                <div class="game-team-top">
                    <h3>${escapeHtml(team.name)}</h3>
                    <button class="add-live" data-action="live-add" data-team-id="${team.id}" type="button">+ Add member</button>
                </div>
                <div class="member-names">${team.members.map(escapeHtml).join(" · ")}</div>
                ${selected
                    ? `<div class="selected-box"><small>Selected member</small><strong>${escapeHtml(selected)}</strong></div>`
                    : `<div class="selected-box waiting">Waiting for selection</div>`}
            </article>`;
    }).join("");
}

function pickForTeam(team) {
    if (!team.members.length) return null;

    let used = state.usedByTeam[team.id] || [];
    let candidates = team.members.filter(member => !used.includes(member));

    if (!candidates.length) {
        used = [];
        candidates = [...team.members];
    }

    const selected = candidates[Math.floor(Math.random() * candidates.length)];
    used.push(selected);
    state.usedByTeam[team.id] = used;
    return selected;
}

function chooseMembers(options = {}) {
    const empty = state.teams.find(team => team.members.length === 0);
    if (empty) {
        showToast(`Add a member to ${empty.name} first.`, true);
        return false;
    }

    const selections = {};
    state.teams.forEach(team => selections[team.id] = pickForTeam(team));
    state.selectedByTeam = selections;
    state.scenarioGenerated = false;

    renderGameTeams();
    enableChallenge();
    resetScenarioOnly();

    if (!options.silent) showToast("Members selected. Choose a category.");
    return true;
}

function enableChallenge() {
    $("challengePanel").classList.remove("disabled-panel");
    $("categorySelect").disabled = false;
    $("generateScenario").disabled = false;
}

function resetChallenge() {
    $("challengePanel").classList.add("disabled-panel");
    $("categorySelect").disabled = true;
    $("generateScenario").disabled = true;
    $("categorySelect").value = "";
    resetScenarioOnly();
}

function resetScenarioOnly() {
    stopScenarioAudio();
    $("scenarioResult").classList.add("hidden");
    $("nextTurnRow").classList.add("hidden");
    $("englishScenario").textContent = "";
    $("frenchScenario").textContent = "";
    setMessage("scenarioMessage");
}

async function generateScenario() {
    const category = $("categorySelect").value;
    if (!category) {
        setMessage("scenarioMessage", "Select a category.", "error");
        return;
    }

    const selectedMembers = state.teams.map(team => state.selectedByTeam[team.id]).filter(Boolean);
    if (selectedMembers.length !== state.teams.length) {
        setMessage("scenarioMessage", "Choose members first.", "error");
        return;
    }

    const button = $("generateScenario");
    button.disabled = true;
    button.textContent = "Generating…";
    setMessage("scenarioMessage");

    try {
        const response = await fetch("/api/game/scenario", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "X-LLM-API-Key": state.apiKey
            },
            body: JSON.stringify({ category, selectedMembers })
        });
        const data = await response.json().catch(() => ({}));
        if (!response.ok) throw new Error(data.message || "Unable to generate the scenario.");

        $("englishScenario").textContent = data.english;
        $("frenchScenario").textContent = data.french;
        $("scenarioResult").classList.remove("hidden");
        $("nextTurnRow").classList.remove("hidden");
        state.scenarioGenerated = true;
    } catch (error) {
        setMessage("scenarioMessage", error.message || "Unable to generate the scenario.", "error");
    } finally {
        button.disabled = false;
        button.textContent = "Generate Scenario";
    }
}

let speechVoices = [];
let activeUtterance = null;
let speechStartTimer = null;
let speechRequestId = 0;

function refreshSpeechVoices() {
    if (!("speechSynthesis" in window)) return [];
    const loaded = window.speechSynthesis.getVoices();
    if (loaded.length) speechVoices = loaded;
    return speechVoices;
}

function initializeSpeechVoices() {
    if (!("speechSynthesis" in window)) return;
    refreshSpeechVoices();
    window.speechSynthesis.addEventListener?.("voiceschanged", refreshSpeechVoices);
    setTimeout(refreshSpeechVoices, 250);
    setTimeout(refreshSpeechVoices, 1000);
}

function stopScenarioAudio() {
    speechRequestId += 1;
    clearTimeout(speechStartTimer);
    speechStartTimer = null;
    activeUtterance = null;
    if ("speechSynthesis" in window) {
        window.speechSynthesis.cancel();
    }
    document.querySelectorAll(".audio-button").forEach(button => button.classList.remove("speaking"));
}

function findVoice(language) {
    const voices = refreshSpeechVoices();
    const normalized = language.toLowerCase().replace("_", "-");
    const prefix = normalized.split("-")[0];
    const normalizedLanguage = voice => (voice.lang || "").toLowerCase().replace("_", "-");

    return voices.find(voice => normalizedLanguage(voice) === normalized)
        || voices.find(voice => normalizedLanguage(voice).startsWith(`${prefix}-`))
        || voices.find(voice => normalizedLanguage(voice) === prefix)
        || null;
}

function findDefaultVoice() {
    const voices = refreshSpeechVoices();
    return voices.find(voice => voice.default) || voices[0] || null;
}

function finishSpeech(button, utterance) {
    if (activeUtterance !== utterance) return;
    clearTimeout(speechStartTimer);
    speechStartTimer = null;
    button.classList.remove("speaking");
    activeUtterance = null;
}

function startSpeechAttempt(text, language, button, requestId, useDefaultVoice = false) {
    if (requestId !== speechRequestId) return;

    const synthesizer = window.speechSynthesis;
    const utterance = new SpeechSynthesisUtterance(text);
    const selectedVoice = useDefaultVoice ? findDefaultVoice() : findVoice(language);
    let started = false;

    utterance.lang = useDefaultVoice && selectedVoice?.lang ? selectedVoice.lang : language;
    utterance.rate = language.toLowerCase().startsWith("fr") ? 0.88 : 0.92;
    utterance.pitch = 1;
    utterance.volume = 1;
    if (selectedVoice) utterance.voice = selectedVoice;

    utterance.onstart = () => {
        if (requestId !== speechRequestId) return;
        started = true;
        clearTimeout(speechStartTimer);
        button.classList.add("speaking");
    };
    utterance.onend = () => finishSpeech(button, utterance);
    utterance.onerror = event => {
        if (requestId !== speechRequestId || activeUtterance !== utterance) return;
        finishSpeech(button, utterance);

        const canFallback = language.toLowerCase().startsWith("fr") && !useDefaultVoice;
        if (canFallback) {
            showToast("French voice unavailable. Using the computer's default voice.");
            startSpeechAttempt(text, language, button, requestId, true);
            return;
        }
        const detail = event?.error && !["canceled", "interrupted"].includes(event.error)
            ? ` (${event.error})`
            : "";
        showToast(`Unable to read this scenario aloud${detail}.`, true);
    };

    activeUtterance = utterance;
    if (synthesizer.paused) synthesizer.resume();

    // Chromium can ignore speech started in the same instant as cancel().
    setTimeout(() => {
        if (requestId === speechRequestId && activeUtterance === utterance) {
            synthesizer.speak(utterance);
        }
    }, 60);

    // Retry French with the default installed voice when no audio engine starts.
    speechStartTimer = setTimeout(() => {
        if (started || requestId !== speechRequestId || activeUtterance !== utterance) return;
        activeUtterance = null;
        synthesizer.cancel();
        button.classList.remove("speaking");

        if (language.toLowerCase().startsWith("fr") && !useDefaultVoice) {
            showToast("French voice unavailable. Using the computer's default voice.");
            startSpeechAttempt(text, language, button, requestId, true);
        } else {
            showToast("The browser audio engine did not start.", true);
        }
    }, 3000);
}

function speakScenario(elementId, language, buttonId) {
    const text = $(elementId).textContent.trim();
    if (!text) {
        showToast("Generate a scenario first.", true);
        return;
    }

    if (!("speechSynthesis" in window)) {
        showToast("Audio reading is not supported by this browser.", true);
        return;
    }

    const button = $(buttonId);
    stopScenarioAudio();
    const requestId = speechRequestId;
    startSpeechAttempt(text, language, button, requestId);
}

function nextTurn() {
    if (!state.scenarioGenerated) {
        showToast("Generate the scenario before moving to the next turn.", true);
        return;
    }

    state.turn += 1;
    $("turnNumber").textContent = state.turn;
    $("categorySelect").value = "";
    state.scenarioGenerated = false;
    resetScenarioOnly();

    chooseMembers({ silent: true });
    showToast(`Turn ${state.turn}: new members selected.`);
    window.scrollTo({ top: 80, behavior: "smooth" });
}

function openMemberModal(teamId) {
    const team = state.teams.find(t => t.id === teamId);
    if (!team) return;
    state.modalTeamId = teamId;
    $("modalTeamName").textContent = team.name;
    $("modalMemberInput").value = "";
    $("memberModal").classList.remove("hidden");
    setTimeout(() => $("modalMemberInput").focus(), 50);
}

function closeMemberModal() {
    $("memberModal").classList.add("hidden");
    state.modalTeamId = null;
}

function saveLiveMember() {
    const teamId = state.modalTeamId;
    const name = $("modalMemberInput").value;
    if (!teamId || !name.trim()) return;
    if (addMember(teamId, name)) {
        const team = state.teams.find(t => t.id === teamId);
        renderGameTeams();
        showToast(`${name.trim()} added to ${team.name}.`);
        closeMemberModal();
    }
}

function editTeams() {
    $("turnBadge").classList.add("hidden");
    renderSetupTeams();
    showScreen("setupScreen");
}

function backToAccess() {
    state.apiKey = "";
    $("turnBadge").classList.add("hidden");
    showScreen("accessScreen");
}

function populateCategories() {
    CATEGORIES.forEach(category => {
        const option = document.createElement("option");
        option.value = category;
        option.textContent = category;
        $("categorySelect").appendChild(option);
    });
}

$("toggleKey").addEventListener("click", () => {
    const input = $("apiKey");
    const show = input.type === "password";
    input.type = show ? "text" : "password";
    $("toggleKey").textContent = show ? "Hide" : "Show";
});

$("apiKey").addEventListener("keydown", event => {
    if (event.key === "Enter") continueWithKey();
});
$("continueButton").addEventListener("click", continueWithKey);

$("teamCountSelector").addEventListener("click", event => {
    const button = event.target.closest("[data-count]");
    if (!button) return;
    document.querySelectorAll(".count").forEach(el => el.classList.remove("active"));
    button.classList.add("active");
    ensureTeams(Number(button.dataset.count));
});

$("setupTeams").addEventListener("input", event => {
    if (event.target.dataset.action !== "team-name") return;
    const team = state.teams.find(t => t.id === event.target.dataset.teamId);
    if (team) team.name = event.target.value;
});

$("setupTeams").addEventListener("click", event => {
    const target = event.target;
    const action = target.dataset.action;
    const teamId = target.dataset.teamId;
    if (!action || !teamId) return;

    if (action === "add-member") {
        const input = document.querySelector(`[data-member-input="${teamId}"]`);
        addMemberFromSetup(teamId, input);
    }
    if (action === "remove-member") removeMember(teamId, Number(target.dataset.memberIndex));
});

$("setupTeams").addEventListener("keydown", event => {
    const teamId = event.target.dataset.memberInput;
    if (event.key === "Enter" && teamId) {
        event.preventDefault();
        addMemberFromSetup(teamId, event.target);
    }
});

$("startGame").addEventListener("click", startGame);
$("backToAccess").addEventListener("click", backToAccess);
$("editTeams").addEventListener("click", editTeams);
$("chooseMembers").addEventListener("click", () => chooseMembers());
$("generateScenario").addEventListener("click", generateScenario);
$("speakEnglish").addEventListener("click", () => speakScenario("englishScenario", "en-US", "speakEnglish"));
$("speakFrench").addEventListener("click", () => speakScenario("frenchScenario", "fr-FR", "speakFrench"));
$("nextTurn").addEventListener("click", nextTurn);

$("gameTeams").addEventListener("click", event => {
    if (event.target.dataset.action === "live-add") openMemberModal(event.target.dataset.teamId);
});

$("cancelMember").addEventListener("click", closeMemberModal);
$("saveMember").addEventListener("click", saveLiveMember);
$("modalMemberInput").addEventListener("keydown", event => {
    if (event.key === "Enter") saveLiveMember();
    if (event.key === "Escape") closeMemberModal();
});
$("memberModal").addEventListener("click", event => {
    if (event.target === $("memberModal")) closeMemberModal();
});

populateCategories();
ensureTeams(2);
initializeSpeechVoices();
