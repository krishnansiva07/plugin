package com.astra.codereview.service;

import com.astra.codereview.model.ReviewIssue;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.regex.Pattern;

@Service
public class RuleAnalyzerService {
    public List<ReviewIssue> analyze(String fileName, String content) {
        List<ReviewIssue> issues = new ArrayList<>();
        String lower = fileName.toLowerCase();
        String[] lines = content.split("\\R", -1);
        for (int i = 0; i < lines.length; i++) {
            String line = lines[i];
            String trimmed = line.trim();
            if ((lower.endsWith(".properties") || lower.endsWith(".yml") || lower.endsWith(".yaml")) &&
                    Pattern.compile("(?i).*(api[-_.]?key|password|secret|token)\\s*[:=]\\s*(?!\\$\\{).{8,}.*").matcher(trimmed).matches()) {
                issues.add(new ReviewIssue("CRITICAL", "Security", i + 1,
                        "Possible hardcoded secret found.",
                        "Secrets can be leaked when committed or shared.",
                        "Move the value to environment variable or a secret manager.",
                        "llm.api-key=${LLM_API_KEY}",
                        "Please remove hardcoded secrets and use environment variables or a secret manager."));
            }
            if (trimmed.contains("System.out.println")) {
                issues.add(new ReviewIssue("MINOR", "Logging", i + 1, "System.out.println is used.", "Console prints are not suitable for production logging.", "Use a logger with proper levels.", "private static final Logger log = LoggerFactory.getLogger(CurrentClass.class);", "Replace System.out.println with proper logger."));
            }
            if (trimmed.contains("Thread.sleep")) {
                issues.add(new ReviewIssue("MAJOR", "Flaky Test Risk", i + 1, "Thread.sleep is used.", "Hard waits make automation slow and flaky.", "Use explicit wait or polling condition.", "new WebDriverWait(driver, Duration.ofSeconds(10)).until(...);", "Please replace Thread.sleep with explicit wait."));
            }
            if (trimmed.matches("(?i).*catch\\s*\\([^)]*\\)\\s*\\{\\s*\\}.*")) {
                issues.add(new ReviewIssue("MAJOR", "Error Handling", i + 1, "Empty catch block found.", "Exceptions are silently swallowed and failures become hard to debug.", "Log the exception or rethrow domain-specific exception.", "catch (Exception ex) { log.error(\"Operation failed\", ex); throw ex; }", "Please do not keep empty catch blocks."));
            }
            if (trimmed.matches(".*@RequestBody\s+String\s+\w+.*")) {
                issues.add(new ReviewIssue("MAJOR", "API Design", i + 1, "Controller accepts raw String request body.", "Raw body weakens validation and API contract.", "Use request/response DTOs with validation.", "public record ChatRequest(@NotBlank String message) {}", "Please replace raw String request body with a validated DTO."));
            }
        }
        if (lines.length > 300) {
            issues.add(new ReviewIssue("GOOD_TO_HAVE", "Maintainability", null, "Large file detected: " + lines.length + " lines.", "Large classes are harder to review and maintain.", "Review by chunks and consider splitting responsibilities if needed.", "", "Large file detected. Please check if class can be split by responsibility."));
        }
        return issues;
    }
}
