# ASTRA Code Review Agent V4 - Copy Properties Version

This version is a single Spring Boot app. No React/Vite needed.

## Run

```bash
cd backend
mvn spring-boot:run
```

Open:

```text
http://localhost:8090
```

Health check:

```text
http://localhost:8090/api/health
```

## Paste LLM URL, model, key directly

Open:

```text
backend/src/main/resources/application.properties
```

Paste values:

```properties
llm.mock-mode=false
llm.base-url=https://ai4devs.group.echonet/api/v1
llm.model-name=gpt-oss-120b
llm.api-key=YOUR_KEY_HERE
llm.append-chat-completions=true
```

Restart backend after editing.

For demo without real LLM:

```properties
llm.mock-mode=true
```

## Features

- Single app served from port 8090
- Clickable menu pages
- Add selected files
- Select full folder using browser folder upload
- Real-time SSE review progress
- File-by-file comments
- Large file chunk review above 300 lines
- Rule-based review + LLM review
- JSON report download
