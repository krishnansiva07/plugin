#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
JAR=eliya-ui-recorder-java17.jar
if [ ! -f "$JAR" ]; then JAR=dist/eliya-ui-recorder-java17.jar; fi
if [ ! -f "$JAR" ]; then echo "Recorder JAR not found. Download the application bundle or run ./build.sh." >&2; exit 1; fi
exec java -jar "$JAR"
