# Eliya UI Recorder — Standalone Java 17

A lightweight, entirely local browser-action recorder. Start one Java JAR, enter an HTTP(S) application URL into the dashboard, launch installed Chrome or Microsoft Edge, perform UI actions, then **Stop & Export JSON**.

**No LLM, Selenium, ChromeDriver, Node.js, Maven, network service, or browser download is needed to run the JAR.** The app uses Chrome DevTools Protocol directly, Java 17's built-in WebSocket client, and Java's built-in HTTP server.

## Requirements

- **Java 17 or later** installed (`java -version`). Java 17 bytecode is used in the built JAR.
- An already-installed **Google Chrome, Chromium, or Microsoft Edge** browser.
- Windows, macOS, or Linux desktop, with an environment where browser applications are permitted.
- Access to the target application from the same computer (VPN/proxy/SSO as normally required).

## Quick start

1. Download `eliya-ui-recorder-java17.jar`.
2. Open Command Prompt, PowerShell, or a terminal in its directory.
3. Run:

   ```bash
   java -jar eliya-ui-recorder-java17.jar
   ```

4. The default browser opens the recorder dashboard on `http://127.0.0.1:<random-port>/`. If it does not open automatically, copy the URL from the terminal.
5. Paste your **application URL**, e.g. `https://test.example.internal/`.
6. Select **Auto detect**, **Chrome / Chromium**, or **Edge** and click **Launch & Start Recording**.
7. A **separate browser window with its own temporary profile** opens the application. Log in if needed; cookies from the usual browser profile are deliberately not reused.
8. Interact with the application. Captured events appear live in the dashboard, with element locators.
9. Click **Stop & Export JSON**. The dashboard browser downloads `ui-actions-YYYYMMDD-HHmmss.json` to its standard download location (or asks where to save, per browser settings).
10. You can click **Export again** without repeating the recording.
11. Click **Close recorder browser** to shut down the launched browser, or close the Java process with Ctrl+C.

## Actions recorded

| Action | JSON type | Details |
| --- | --- | --- |
| Page load, history changes | `navigate` | Page URL, timestamp |
| Click, double click, context menu | `click`, `doubleClick`, `rightClick` | CSS locator and locator alternatives |
| Text entry | `fill` | Final typed value; pending text flushed on Stop |
| Checkbox / radio | `check` | Checked state |
| Dropdown | `select` | Selected value(s) |
| Keyboard Enter, Tab, Escape, modified keys | `key` | Key and modifiers |
| Form submit | `submit` | Form locator |
| Scroll | `scroll` | Element/viewport positions, rate limited |
| File choose | `fileSelected` | File **names only**, no bytes |
| Drop | `drop` | Target locator |

Locators include CSS, test ID, role, accessible name, associated label, name, placeholder, ID and basic shadow-path details where available. They are metadata, not a promise that every locator will be unique after the application changes.

## Sample output

```json
{
  "schemaVersion": "1.0",
  "format": "eliya-ui-actions",
  "sessionId": "<UUID>",
  "applicationUrl": "https://test.example.internal/",
  "browser": "Chrome / Chromium",
  "recordingStartedAt": "<ISO-8601 UTC timestamp>",
  "recordingStoppedAt": "<ISO-8601 UTC timestamp>",
  "exportedAt": "<ISO-8601 UTC timestamp>",
  "actionCount": 2,
  "actions": [
    {
      "type": "click",
      "timestamp": "<ISO-8601 timestamp>",
      "pageUrl": "https://test.example.internal/",
      "tag": "button",
      "selector": "[data-testid=\"save\"]",
      "locators": { "css": "[data-testid=\"save\"]", "testId": "save", "role": "button" },
      "sequence": 1
    },
    {
      "type": "fill",
      "pageUrl": "https://test.example.internal/",
      "tag": "input",
      "selector": "#customer-name",
      "value": "Example",
      "sequence": 2
    }
  ]
}
```

The real export additionally includes timestamps, tab IDs, and other locator fields.

## Autosave and data privacy

Every captured event is also appended immediately to a local JSONL journal for crash recovery:

- Windows: `%USERPROFILE%\.eliya-ui-recorder\sessions\<session-id>.jsonl`
- macOS / Linux: `~/.eliya-ui-recorder/sessions/<session-id>.jsonl`

A JSONL file is one JSON object per line. It is **not** the final array-style JSON export; use **Stop & Export JSON** for that. On Unix the recorder sets owner-only permissions on the autosave directory and files. On Windows it uses the normal user-profile ACLs.

Password, token, key, CVV, OTP and other recognizable sensitive input fields are masked. **Ordinary text-entry values are deliberately captured** so tests can be replayed; review exported data and local autosave files before sharing them. Only bind the dashboard to the local loopback address; it is never intended to be published as a network service.

## Optional browser path overrides

Usually no configuration is needed. If the recorder cannot find the installed browser, provide the absolute path before `-jar`:

**Windows Chrome:**

```powershell
java '-Drecorder.chromePath=C:\Program Files\Google\Chrome\Application\chrome.exe' -jar .\eliya-ui-recorder-java17.jar
```

**Windows Edge:**

```powershell
java '-Drecorder.edgePath=C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe' -jar .\eliya-ui-recorder-java17.jar
```

**macOS Chrome:**

```bash
java -Drecorder.chromePath="/Applications/Google Chrome.app/Contents/MacOS/Google Chrome" -jar eliya-ui-recorder-java17.jar
```

Other options:

- `-Drecorder.port=45678` — use a fixed loopback dashboard port.
- `-Drecorder.noAutoOpen=true` — print dashboard URL without opening a browser automatically.
- `-Drecorder.headless=true` — automated test use only; normal use opens a visible browser.
- `-Drecorder.disableSandbox=true` — **automated tests in restricted root containers only**; **do not use on desktop**.

## Browser launch and recording technical notes

- A new temporary browser profile avoids modifying or depending on any normal browser session.
- Chrome/Edge is launched with a loopback DevTools endpoint and a random debugging port. No `--remote-allow-origins=*` flag is used.
- Actions are injected via CDP `Runtime.addBinding` and `Page.addScriptToEvaluateOnNewDocument` and streamed to the Java process.
- New tabs within the launched browser are discovered and attached automatically.
- Listening on `127.0.0.1` means the control panel is available only on the same computer.
- HTTP API has same-origin checks on mutating operations.
- Download uses `Content-Disposition: attachment` to let the dashboard browser handle the JSON download.

## Known limitations

- This is **action recording and JSON export**, not a full test replay engine or Playwright/Cucumber code generator. Those can be added later.
- OS-native file picker dialogs, browser chrome/toolbars, browser permission popups, CAPTCHAs and unrelated windows are not reliably recorded. File input selections record names, not file content.
- Out-of-process cross-origin iframes (OOPIF), closed shadow roots, some canvas widgets, and highly customized controls may require dedicated support.
- Browser extensions and enterprise policies may interfere with launching or recording. If an enterprise browser blocks the target URL, the recorder cannot override that policy.
- Browser navigation/page history patching is intentionally lightweight, but very unusual applications can require app-specific hooks.
- The recorder currently runs one session at a time, though it can follow tabs opened inside its launched browser.
- No guarantee is made that sensitive values outside recognizable input fields are masked (for example, credentials pasted into ordinary text areas).

## Build from source (Java 17 JDK)

On Linux or macOS:

```bash
./build.sh
```

On Windows:

```cmd
build.bat
```

The result is `dist/eliya-ui-recorder-java17.jar`. The project has **zero runtime or build-time third-party dependencies**.

Source tree:

```text
src/main/java/com/eliya/recorder/
  RecorderApp.java       # HTTP UI, session state, persistence and JSON export
  BrowserRecorder.java   # Browser discovery, launch, CDP/WebSockets
  Json.java              # Dependency-free JSON parser / serializer
src/main/resources/
  recorder.js            # Browser event capture + locators + sensitive-value masking
  index.html             # Recorder dashboard
build.sh
build.bat
```

## Stopping the recorder

Stop the recording and export first. The JAR process can be terminated with Ctrl+C; the managed browser will be closed automatically. If you need to keep browsing, stop/export and make sure any work in the isolated browser window is complete before closing the recorder.
