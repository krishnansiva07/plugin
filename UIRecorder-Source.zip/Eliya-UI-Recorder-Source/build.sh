#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p build/classes dist
find src/main/java -name '*.java' -print > build/sources.list
javac --release 17 -encoding UTF-8 -d build/classes @build/sources.list
cp src/main/resources/* build/classes/
jar --create --file dist/eliya-ui-recorder-java17.jar --main-class com.eliya.recorder.RecorderApp -C build/classes .
echo "Created: $(pwd)/dist/eliya-ui-recorder-java17.jar"
