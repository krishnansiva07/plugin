@echo off
setlocal
cd /d "%~dp0"
if not exist build\classes mkdir build\classes
if not exist dist mkdir dist
javac --release 17 -encoding UTF-8 -d build\classes src\main\java\com\eliya\recorder\Json.java src\main\java\com\eliya\recorder\BrowserRecorder.java src\main\java\com\eliya\recorder\RecorderApp.java
if errorlevel 1 exit /b %errorlevel%
copy /y src\main\resources\* build\classes\ >nul
jar --create --file dist\eliya-ui-recorder-java17.jar --main-class com.eliya.recorder.RecorderApp -C build\classes .
if errorlevel 1 exit /b %errorlevel%
echo Created dist\eliya-ui-recorder-java17.jar
endlocal
