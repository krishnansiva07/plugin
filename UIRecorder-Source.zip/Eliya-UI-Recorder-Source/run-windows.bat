@echo off
cd /d "%~dp0"
java -version >nul 2>&1
if errorlevel 1 (
  echo Java 17 or later is required. Install Java and make sure java.exe is in PATH.
  pause
  exit /b 1
)
set "JAR=eliya-ui-recorder-java17.jar"
if not exist "%JAR%" set "JAR=dist\eliya-ui-recorder-java17.jar"
if not exist "%JAR%" (
  echo Recorder JAR not found. Download the application bundle, or run build.bat in the source project.
  pause
  exit /b 1
)
java -jar "%JAR%"
if errorlevel 1 pause
