# Apache POI dependency fix

## Root cause

TCGen used Apache Tika 3.3.0 together with a directly pinned Apache POI `poi-ooxml` 5.2.5 dependency. Tika 3.3.0's Microsoft parser stack uses Apache POI 5.5.1 modules. Maven can therefore resolve a mixed POI runtime, which can fail with errors such as `NoClassDefFoundError` or `NoSuchMethodError` depending on which POI jar is loaded first on a machine.

## Fix applied

- POI core/OOXML/scratchpad/full/lite modules are pinned to 5.5.1.
- Log4j API/bridge version is aligned to 2.25.3 for the POI 5.5.1 stack.
- POI core and OOXML are explicit application dependencies.
- A compatibility test exercises XLSX creation, DOCX initialization and Tika parsing together.
- A startup verifier checks the loaded POI runtime and fails early with a clear message if an older external POI jar shadows the packaged version.
- README now instructs users to run the Spring Boot fat JAR with `java -jar` and not add external POI jars.

## Build verification command

```bash
mvn clean package -U
```

Then start only the packaged JAR:

```bash
java -jar target/tcgen-service-0.0.7-SNAPSHOT.jar
```

Do not launch TCGen with a manually assembled classpath containing separate `poi*.jar` files.
