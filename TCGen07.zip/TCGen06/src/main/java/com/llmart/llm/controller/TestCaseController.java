package com.llmart.llm.controller;

import com.llmart.llm.dto.TestCaseGenerationResponse;
import com.llmart.llm.exception.TcgenException;
import com.llmart.llm.service.ColumnSelectionService;
import com.llmart.llm.service.ExcelExpectedColumnsService;
import com.llmart.llm.service.ExcelExportService;
import com.llmart.llm.service.PromptBuilder;
import com.llmart.llm.service.OcrService;
import com.llmart.llm.service.TestCaseGeneratorService;
import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/testcases")
@CrossOrigin(origins = "*")
public class TestCaseController {

    private final TestCaseGeneratorService testCaseGeneratorService;
    private final ExcelExportService excelExportService;
    private final ColumnSelectionService columnSelectionService;
    private final ExcelExpectedColumnsService excelExpectedColumnsService;
    private final PromptBuilder promptBuilder;
    private final OcrService ocrService;

    public TestCaseController(TestCaseGeneratorService testCaseGeneratorService,
                              ExcelExportService excelExportService,
                              ColumnSelectionService columnSelectionService,
                              ExcelExpectedColumnsService excelExpectedColumnsService,
                              PromptBuilder promptBuilder,
                              OcrService ocrService) {
        this.testCaseGeneratorService = testCaseGeneratorService;
        this.excelExportService = excelExportService;
        this.columnSelectionService = columnSelectionService;
        this.excelExpectedColumnsService = excelExpectedColumnsService;
        this.promptBuilder = promptBuilder;
        this.ocrService = ocrService;
    }

    @GetMapping("/health")
    public Map<String, Object> health() {
        return Map.of(
                "status", "UP",
                "service", "TCGen",
                "dynamicColumns", true,
                "excelColumnDetection", true,
                "separateColumnTemplateUpload", true,
                "llmProviders", List.of("AI4Dev", "LLM@CIB"),
                "openAiCompatible", true
        );
    }

    @GetMapping("/ocr/status")
    public Map<String, Object> ocrStatus() {
        return ocrService.status();
    }

    @GetMapping("/columns/defaults")
    public Map<String, List<String>> defaultColumns() {
        return Map.of("columns", columnSelectionService.defaultColumns());
    }

    @PostMapping(value = "/columns/from-excel", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public Map<String, Object> detectColumnsFromExcel(@RequestParam("file") MultipartFile file) {
        List<String> columns = excelExpectedColumnsService.detectExpectedColumnsFromSeparateExcel(file);
        String message = columns.isEmpty()
                ? "No expected output columns were detected. Upload an Excel template where the first row contains output column names, or add an Output_Schema sheet with a Column header."
                : "Detected " + columns.size() + " expected output columns from the column template Excel.";
        return Map.of("columns", columns, "message", message);
    }

    @PostMapping(value = "/prompt-preview", consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
    public Map<String, String> promptPreview(@RequestParam(value = "additionalPrompt", required = false) String additionalPrompt,
                                             @RequestParam(value = "selectedColumns", required = false) String selectedColumnsCsv,
                                             @RequestParam(value = "fileUnderstandingMode", required = false) String fileUnderstandingMode) {
        List<String> columns = columnSelectionService.resolveColumns(selectedColumnsCsv);
        return Map.of("prompt", promptBuilder.buildPreviewPrompt(additionalPrompt, columns, fileUnderstandingMode));
    }

    @PostMapping(value = "/generate", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public TestCaseGenerationResponse generate(@RequestParam(value = "file", required = false) MultipartFile legacyFile,
                                               @RequestParam(value = "requirementsFile", required = false) MultipartFile requirementsFile,
                                               @RequestParam(value = "expectedColumnsFile", required = false) MultipartFile expectedColumnsFile,
                                               @RequestParam(value = "additionalPrompt", required = false) String additionalPrompt,
                                               @RequestParam(value = "provider", required = false) String provider,
                                               @RequestParam(value = "apiKey", required = false) String apiKey,
                                               @RequestParam(value = "modelName", required = false) String modelName,
                                               @RequestParam(value = "baseUrl", required = false) String baseUrl,
                                               @RequestParam(value = "selectedColumns", required = false) String selectedColumnsCsv,
                                               @RequestParam(value = "fileUnderstandingMode", required = false) String fileUnderstandingMode,
                                               @RequestParam(value = "useUploadedExcelColumns", defaultValue = "false") boolean useUploadedExcelColumns) {
        MultipartFile actualRequirementsFile = hasFile(requirementsFile) ? requirementsFile : legacyFile;
        if (!hasFile(actualRequirementsFile)) {
            throw new TcgenException("Please upload a requirements / AC / design file before generating test cases.");
        }

        return testCaseGeneratorService.generate(actualRequirementsFile, expectedColumnsFile, additionalPrompt,
                provider, apiKey, modelName, baseUrl, selectedColumnsCsv, fileUnderstandingMode, useUploadedExcelColumns);
    }

    @PostMapping(value = "/export", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<byte[]> export(@RequestBody TestCaseGenerationResponse response) {
        byte[] excelBytes = excelExportService.export(response);
        String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss"));
        String fileName = "TCGen_TestCases_" + timestamp + ".xlsx";

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.parseMediaType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"));
        headers.setContentDisposition(ContentDisposition.attachment().filename(fileName).build());
        headers.setContentLength(excelBytes.length);

        return ResponseEntity.ok().headers(headers).body(excelBytes);
    }

    private boolean hasFile(MultipartFile file) {
        return file != null && !file.isEmpty();
    }
}
