# PROMPT 4 — RESUME EXISTING SELENIUM TO PLAYWRIGHT MIGRATION

## 1. Existing workspace

- **Playwright project root:** `C:\playwright_hybrid_fw\playwright`
- **Migration metadata directory:** `C:\playwright_hybrid_fw\playwright\migration`
- **Source package:** `testscript.banner`
- **Execution mode:** `RESUME_INCOMPLETE`

The first three migration prompts have already been executed. **Do not recreate the framework or restart the migration.**

## 2. Read existing migration state

Read these actual files:

- `migration/MIGRATION.md`
- `migration/migration-ledger.csv`
- `migration/PACKAGE_RUNBOOK.md`
- `migration/shared-component-registry.md`

Inspect the existing `migration/legacy` and `migration/target` directories to understand their purpose.

Resolve the actual legacy Java source and Playwright target directories from the configured workspace and reference mappings. **Do not assume the metadata directories are executable source roots.**

## 3. Validate previous work

- Identify previously migrated methods, test cases and business flows.
- Check existing Playwright implementations against Java source behavior.
- Verify package mappings, method IDs, assertions and data dependencies.
- Reconcile ledger entries against actual files.
- Preserve completed and verified work.
- Do not duplicate tests, page objects or shared utilities.

If an essential path or file is missing, report the exact problem. Do not silently recreate existing migration records.

## 4. Resume next incomplete batch

- Identify the next **3–5 eligible incomplete test methods** from `testscript.banner`.
- Reuse existing Playwright TypeScript/NX framework components.
- Preserve assertions, test-data variations, business flows and execution conditions.
- Do not modify legacy source code.
- Do not change unrelated packages.
- Avoid unnecessary refactoring.

Agent implementation is authorized for this non-destructive, selected migration batch. **Request explicit approval** before destructive changes, overwriting verified work, or changing unrelated components.

## 5. Verify

Run applicable TypeScript build, test discovery and focused Playwright checks using an **already installed Chrome or Edge browser**.

Compare migrated scenarios against their Java equivalents.

Record accurate `PASSED`, `FAILED`, `BLOCKED` or `UNVERIFIED` results. Never claim a test passed without execution evidence.

## 6. Update migration records

Update the existing ledger and relevant migration documents.

Do not create a second migration directory or overwrite historical records unnecessarily.

## 7. Completion report

Provide:

1. Source methods discovered
2. Methods selected and migrated
3. Files created or modified
4. Tests executed and actual results
5. Remaining migration methods
6. Failures and blockers
7. Exact next recommended batch

Declare **COMPLETE** only if every acceptance criterion for this batch is verified.

**Do not start another migration batch automatically.**
