# Browser Lifecycle Configuration

Use `.env`:

## Shared mode
`BROWSER_LIFECYCLE=shared`

- One worker is forced.
- One BrowserContext and one Page are reused across tests.
- Before each test the page goes to HOME_URL.
- After each PASS or FAIL the page goes to HOME_URL.
- If the page is closed by a failed test, a new page is created in the same context.

## Isolated mode
`BROWSER_LIFECYCLE=isolated`

- A new BrowserContext and Page are created for every test.
- WORKERS controls parallelism.
- Tests are fully session-isolated.

## Different implementation per JSON row
`src/core/execution/LoginTestImplementations.ts` maps every testId to its own async function.
Add a new JSON row, then add a matching implementation keyed by that testId.
