# Reporting Guide

Every Playwright execution generates all three outputs, regardless of browser lifecycle (`shared` or `isolated`) and regardless of whether the run is a full suite or filtered by testId/tag/test name/suite.

## Reports generated

- Smart Framework HTML: `reports/index.html`
- Smart Framework JSON: `reports/test-results.json`
- Native Playwright HTML: `playwright-report/index.html`
- JUnit XML: `test-results/junit.xml`

## Run examples

```bash
npm test
npm test -- --testid=TC_LOGIN_001
npm test -- --testid=TC_LOGIN_001,TC_LOGIN_003
npm test -- --tags=smoke
npm test -- --suite=login
npm test -- --testname="Locked User"
```

## Open reports

```bash
npm run report:framework
npm run report:playwright
```

`npm run report:open` remains available as an alias for the Smart Framework report.

## Browser lifecycle

Reporting does not change between modes:

```env
BROWSER_LIFECYCLE=shared
```

or

```env
BROWSER_LIFECYCLE=isolated
```

The lifecycle affects browser/context reuse only. The same reporters are invoked by Playwright in both modes.
