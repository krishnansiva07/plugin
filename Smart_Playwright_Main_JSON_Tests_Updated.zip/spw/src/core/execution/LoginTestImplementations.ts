import type { Page } from '@playwright/test';
import { LoginPage } from '../../pages/LoginPage';

export interface LoginTestData {
  run: boolean;
  testId: string;
  testName: string;
  suite?: string;
  tags?: string[];
  username: string;
  password: string;
  expectedType: 'products' | 'error';
  expectedValue: string;
}

type LoginImplementation = (page: Page, row: LoginTestData) => Promise<void>;

const implementations: Record<string, LoginImplementation> = {
  TC_LOGIN_001: async (page, row) => {
    const login = new LoginPage(page);
    await login.open();
    await login.login(row.username, row.password);
    await login.verifyProductsPage(row.expectedValue);
  },
  TC_LOGIN_002: async (page, row) => {
    const login = new LoginPage(page);
    await login.open();
    await login.login(row.username, row.password);
    await login.verifyError(row.expectedValue);
  },
  TC_LOGIN_003: async (page, row) => {
    const login = new LoginPage(page);
    await login.open();
    await login.login(row.username, row.password);
    await login.verifyError(row.expectedValue);
  },
  TC_LOGIN_004: async (page, row) => {
    const login = new LoginPage(page);
    await login.open();
    await login.login(row.username, row.password);
    await login.verifyError(row.expectedValue);
  },
  TC_LOGIN_005: async (page, row) => {
    const login = new LoginPage(page);
    await login.open();
    await login.login(row.username, row.password);
    await login.verifyError(row.expectedValue);
  }
};

export function getLoginImplementation(testId: string): LoginImplementation {
  const implementation = implementations[testId];
  if (!implementation) {
    throw new Error(`No implementation registered for testId: ${testId}`);
  }
  return implementation;
}
