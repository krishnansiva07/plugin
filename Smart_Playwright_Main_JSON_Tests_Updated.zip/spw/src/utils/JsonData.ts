import fs from 'node:fs';
import path from 'node:path';

export function readJsonFile<T>(filePath: string): T {
  const resolved = path.resolve(filePath);
  if (!fs.existsSync(resolved)) throw new Error(`JSON test-data file not found: ${resolved}`);
  try {
    return JSON.parse(fs.readFileSync(resolved, 'utf8')) as T;
  } catch (error) {
    throw new Error(`Unable to parse JSON file ${resolved}: ${(error as Error).message}`);
  }
}

export function getTestData<T extends { testId: string }>(rows: T[], testId: string): T {
  const row = rows.find(item => item.testId === testId);
  if (!row) throw new Error(`Test data not found for testId: ${testId}`);
  return row;
}

export function writeJsonFile(filePath: string, value: unknown): void {
  const resolved = path.resolve(filePath);
  fs.mkdirSync(path.dirname(resolved), { recursive: true });
  fs.writeFileSync(resolved, JSON.stringify(value, null, 2), 'utf8');
}
