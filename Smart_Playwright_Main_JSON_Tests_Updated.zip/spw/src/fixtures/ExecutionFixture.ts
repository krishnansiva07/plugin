import { test as base, expect, type BrowserContext, type Page } from '@playwright/test';
import { env, envBoolean, envNumber } from '../utils/Environment';

type WorkerFixtures = {
  sharedContext: BrowserContext | undefined;
};

const mode = env('BROWSER_LIFECYCLE', 'shared').trim().toLowerCase();
const sharedMode = mode === 'shared';
const homeUrl = env('HOME_URL', env('BASE_URL', 'https://www.saucedemo.com/'));
const navTimeout = envNumber('HOME_NAVIGATION_TIMEOUT_MS', 30000);
const clearStorage = envBoolean('CLEAR_STORAGE_BETWEEN_TESTS', false);
const navigateBefore = envBoolean('NAVIGATE_HOME_BEFORE_EACH_TEST', true);

async function goHome(page: Page): Promise<void> {
  if (page.isClosed()) return;
  try { await page.keyboard.press('Escape').catch(() => undefined); } catch {}
  if (clearStorage) {
    await page.context().clearCookies().catch(() => undefined);
    await page.evaluate(() => { localStorage.clear(); sessionStorage.clear(); }).catch(() => undefined);
  }
  await page.goto(homeUrl, { waitUntil: 'domcontentloaded', timeout: navTimeout });
}

export const test = base.extend<{ page: Page }, WorkerFixtures>({
  sharedContext: [async ({ browser }, use) => {
    if (!sharedMode) {
      await use(undefined);
      return;
    }
    const context = await browser.newContext({
      ignoreHTTPSErrors: true,
      viewport: { width: 1440, height: 900 }
    });
    await use(context);
    await context.close().catch(() => undefined);
  }, { scope: 'worker' }],

  page: async ({ browser, sharedContext }, use, testInfo) => {
    let context: BrowserContext;
    let page: Page;
    let ownsContext = false;

    if (sharedMode) {
      if (!sharedContext) throw new Error('Shared browser mode is enabled but shared context was not created.');
      context = sharedContext;
      page = context.pages()[0] ?? await context.newPage();
      if (navigateBefore) await goHome(page);
    } else {
      context = await browser.newContext({ ignoreHTTPSErrors: true, viewport: { width: 1440, height: 900 } });
      ownsContext = true;
      page = await context.newPage();
    }

    await use(page);

    if (sharedMode) {
      if (testInfo.status !== testInfo.expectedStatus && !page.isClosed()) {
        const safeName = testInfo.title.replace(/[^a-z0-9-_]+/gi, '_');
        await page.screenshot({ path: testInfo.outputPath(`${safeName}-failure.png`), fullPage: true }).catch(() => undefined);
      }
      if (page.isClosed()) page = await context.newPage();
      await goHome(page).catch(async () => {
        if (!page.isClosed()) await page.close().catch(() => undefined);
        page = await context.newPage();
        await goHome(page);
      });
    } else if (ownsContext) {
      await context.close().catch(() => undefined);
    }
  }
});

export { expect };
