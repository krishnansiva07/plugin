# Main Tests: Two Different Implementations Using One JSON File

The framework includes a real main-test example (not under `tests/samples`):

- `tests/inventory.spec.ts`
- `test-data/inventory-tests.json`

`TC_INVENTORY_001` and `TC_INVENTORY_002` are in the same spec file, read their data from the same JSON file, and execute different TypeScript implementations.

The link between JSON and implementation is `testId`:

- `TC_INVENTORY_001` -> open product details and verify the selected product.
- `TC_INVENTORY_002` -> add the configured product to cart and verify cart count.

Both tests use the framework execution fixture, so they work with:

- `BROWSER_LIFECYCLE=shared`
- `BROWSER_LIFECYCLE=isolated`

Both also participate in framework filters and both reports.

Examples:

```bash
npm test -- --testid=TC_INVENTORY_001
npm test -- --testid=TC_INVENTORY_002
npm test -- --testid=TC_INVENTORY_001,TC_INVENTORY_002
npm test -- --suite="SauceDemo Inventory"
npm test -- --tags=inventory
```

For new tests, add another JSON object with a unique `testId`, retrieve it with `getTestData(...)`, and add another independent `test(...)` block with its own implementation.
