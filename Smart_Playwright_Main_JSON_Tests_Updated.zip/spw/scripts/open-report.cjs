const { existsSync } = require('node:fs');
const path = require('node:path');
const { spawn } = require('node:child_process');

const root = path.resolve(__dirname, '..');
const mode = (process.argv[2] || 'framework').toLowerCase();
const report = mode === 'playwright'
  ? path.join(root, 'playwright-report', 'index.html')
  : path.join(root, 'reports', 'index.html');

if (!existsSync(report)) {
  console.error(`[REPORT] Report not found: ${report}`);
  console.error('[REPORT] Run tests first with: npm test');
  process.exit(1);
}

if (process.platform === 'win32') {
  spawn('cmd', ['/c', 'start', '', report], { detached: true, stdio: 'ignore' }).unref();
} else if (process.platform === 'darwin') {
  spawn('open', [report], { detached: true, stdio: 'ignore' }).unref();
} else {
  spawn('xdg-open', [report], { detached: true, stdio: 'ignore' }).unref();
}

console.log(`[REPORT] Opened ${mode} report: ${report}`);
