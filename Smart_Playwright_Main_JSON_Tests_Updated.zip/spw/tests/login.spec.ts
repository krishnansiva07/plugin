import { test } from '../src/fixtures/ExecutionFixture';
import { readJsonFile } from '../src/utils/JsonData';
import { shouldRunTest } from '../src/core/execution/ExecutionFilter';
import { getLoginImplementation, type LoginTestData } from '../src/core/execution/LoginTestImplementations';

const testData = readJsonFile<LoginTestData[]>('test-data/login-tests.json')
  .filter(row => row.run)
  .filter(row => shouldRunTest(row));

const suites = new Map<string, LoginTestData[]>();
for (const row of testData) {
  const suite = row.suite?.trim() || 'SauceDemo Login';
  const rows = suites.get(suite) ?? [];
  rows.push(row);
  suites.set(suite, rows);
}

for (const [suiteName, rows] of suites) {
  test.describe(suiteName, () => {
    for (const row of rows) {
      const normalizedTags = (row.tags ?? []).map(tag => tag.startsWith('@') ? tag : `@${tag}`);
      const tagText = normalizedTags.join(' ');
      const title = `[${row.testId}] ${row.testName}${tagText ? ` ${tagText}` : ''}`;

      test(title, async ({ page }, testInfo) => {
        testInfo.annotations.push({ type: 'testId', description: row.testId });
        testInfo.annotations.push({ type: 'suite', description: suiteName });
        for (const tag of normalizedTags) testInfo.annotations.push({ type: 'tag', description: tag });

        const implementation = getLoginImplementation(row.testId);
        await implementation(page, row);
      });
    }
  });
}
