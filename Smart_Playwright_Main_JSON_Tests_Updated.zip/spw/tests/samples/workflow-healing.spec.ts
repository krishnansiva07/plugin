import { test, expect } from '../../src/fixtures/ExecutionFixture';
import { AI } from '../../src/framework/AI';
import { shouldRunSampleTest } from '../../src/core/execution/ExecutionFilter';

const meta = {
  testId: 'TC_WORKFLOW_001',
  testName: 'LLM plans and executes a dependent login workflow',
  suite: 'Advanced AI Healing',
  tags: ['ai', 'workflow', 'step2']
};

if (shouldRunSampleTest(meta)) {
  test.describe(meta.suite, () => {
    test(`[${meta.testId}] ${meta.testName} @ai @workflow @step2`, async ({ page }) => {
      const ai = AI.on(page);
      await page.goto('/');
      await ai.workflow('Enter standard_user in Username, enter secret_sauce in Password, then click Login');
      await expect(page.getByTestId('title')).toHaveText('Products');
    });
  });
}
