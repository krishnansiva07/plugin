import { test, expect } from '../../src/fixtures/ExecutionFixture';
import { shouldRunSampleTest } from '../../src/core/execution/ExecutionFilter';

const meta = { testId: 'TC_PW_001', testName: 'Login using native Playwright', suite: 'Execution Styles', tags: ['regression', 'native'] };

if (shouldRunSampleTest(meta)) {
  test.describe(meta.suite, () => {
    test(`[${meta.testId}] ${meta.testName} @regression @native`, async ({ page }) => {
      await page.goto('/');
      await page.getByTestId('username').fill('standard_user');
      await page.getByTestId('password').fill('secret_sauce');
      await page.getByTestId('login-button').click();
      await expect(page.getByTestId('title')).toHaveText('Products');
    });
  });
}
