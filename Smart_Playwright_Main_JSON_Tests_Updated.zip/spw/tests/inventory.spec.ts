import { test, expect } from '../src/fixtures/ExecutionFixture';
import type { Page } from '@playwright/test';
import { LoginPage } from '../src/pages/LoginPage';
import { getTestData, readJsonFile } from '../src/utils/JsonData';
import { shouldRunTest } from '../src/core/execution/ExecutionFilter';

interface InventoryTestData {
  run: boolean;
  testId: string;
  testName: string;
  suite: string;
  tags: string[];
  username: string;
  password: string;
  productName: string;
  expectedUrlContains?: string;
  expectedCartCount?: string;
}

const inventoryData = readJsonFile<InventoryTestData[]>('test-data/inventory-tests.json');

async function loginFromCleanHome(page: Page, data: InventoryTestData): Promise<void> {
  // Keep these two main-test examples independent even when BROWSER_LIFECYCLE=shared.
  await page.context().clearCookies();
  await page.goto('/');
  await page.evaluate(() => {
    localStorage.clear();
    sessionStorage.clear();
  });
  await page.goto('/');

  const loginPage = new LoginPage(page);
  await loginPage.login(data.username, data.password);
  await loginPage.verifyProductsPage('Products');
}

function titleFor(data: InventoryTestData): string {
  const tags = data.tags.map(tag => tag.startsWith('@') ? tag : `@${tag}`).join(' ');
  return `[${data.testId}] ${data.testName}${tags ? ` ${tags}` : ''}`;
}

const productDetailsData = getTestData(inventoryData, 'TC_INVENTORY_001');
if (productDetailsData.run && shouldRunTest(productDetailsData)) {
  test.describe(productDetailsData.suite, () => {
    test(titleFor(productDetailsData), async ({ page }, testInfo) => {
      testInfo.annotations.push({ type: 'testId', description: productDetailsData.testId });
      testInfo.annotations.push({ type: 'suite', description: productDetailsData.suite });
      for (const tag of productDetailsData.tags) {
        testInfo.annotations.push({ type: 'tag', description: tag.startsWith('@') ? tag : `@${tag}` });
      }

      await loginFromCleanHome(page, productDetailsData);

      // TEST 1 IMPLEMENTATION: open a product details page.
      await page.getByText(productDetailsData.productName, { exact: true }).click();
      await expect(page).toHaveURL(new RegExp(productDetailsData.expectedUrlContains ?? 'inventory-item\\.html'));
      await expect(page.getByTestId('inventory-item-name')).toHaveText(productDetailsData.productName);
    });
  });
}

const addToCartData = getTestData(inventoryData, 'TC_INVENTORY_002');
if (addToCartData.run && shouldRunTest(addToCartData)) {
  test.describe(addToCartData.suite, () => {
    test(titleFor(addToCartData), async ({ page }, testInfo) => {
      testInfo.annotations.push({ type: 'testId', description: addToCartData.testId });
      testInfo.annotations.push({ type: 'suite', description: addToCartData.suite });
      for (const tag of addToCartData.tags) {
        testInfo.annotations.push({ type: 'tag', description: tag.startsWith('@') ? tag : `@${tag}` });
      }

      await loginFromCleanHome(page, addToCartData);

      // TEST 2 IMPLEMENTATION: add a specific product to the cart.
      const productSlug = addToCartData.productName
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, '-')
        .replace(/^-|-$/g, '');

      await page.getByTestId(`add-to-cart-${productSlug}`).click();
      await expect(page.getByTestId('shopping-cart-badge')).toHaveText(addToCartData.expectedCartCount ?? '1');
    });
  });
}
