# ITPS VIBIUM MCP Framework

This is a Spring Boot web application for recording browser actions, running Excel or JSON test scenarios through Vibium MCP, self-healing eligible failures, and producing auditable reports.

## Will it work?

Yes, with the required runtime dependencies installed and a compatible Vibium MCP server available.

The Java source builds on Java 17, the automated unit suite validates the deterministic executors and cookie transaction, and the application JAR starts as a Spring Boot service. The supplied local bridge supports up to four simultaneous isolated browser sessions.

The application cannot execute real browser tests by itself. Before an end-to-end run, provide:

- Java 17 or later.
- Node.js for the local TCP bridge.
- Vibium installed globally or under `tools/vibium-portable`.
- Network access to the application under test and, when enabled, the configured LLM endpoint.
- A Vibium build exposing the browser tools used by the selected steps.

The optional cookie workflow requires compatible native MCP cookie tools. Supported tool shapes include Vibium's `browser_storage_state`, `browser_set_cookie`, and `browser_clear_cookies`, as well as common `browser_get_cookies`, `browser_add_cookie`, and combined `browser_cookies` interfaces. If these tools are absent, normal testing still works with cookie replacement turned off.

## Feature inventory

| Area | Features | Runtime status |
|---|---|---|
| Scenario input | `.xlsx`, `.xls`, and `.json`; JSON array or `{ "scenarios": [...] }` | Implemented |
| Excel selection | Discover worksheets; select one, several, or all; combine selected sheets; make duplicate test IDs unique | Implemented |
| Row filtering | Optional `Run` column accepts `true`, `yes`, `y`, `1`, `run`, `execute`, or `enabled` | Implemented |
| Data-driven steps | `data.*` columns; JSON test-data columns; `{{key}}` and `${key}` substitution | Implemented |
| Browser discovery | Vibium-managed Chrome plus detected installed browsers when supported by the MCP start schema | Implemented; browser choice depends on Vibium capabilities |
| MCP transport | Manually started localhost TCP bridge by default; child-process stdio fallback | Implemented |
| Shared browser | One browser instance for the complete run; scenarios execute sequentially so cookies and session state continue | Implemented and default |
| Isolated browser | Fresh MCP connection and browser for every test | Implemented and optional |
| Parallel execution | Two to four tests at once, each in a separate browser | Implemented; requires isolated-browser mode |
| Cookie session setup | After the first successful home-page navigation: find the named cookie, preserve its scope/security attributes, remove all cookies, restore it with the new value, refresh, and verify | Implemented and optional; requires cookie-capable Vibium MCP |
| Cookie safety | Replacement value is masked in framework step reports and MCP diagnostics; original-value rollback is attempted if setting fails | Implemented |
| UI action recorder | Headed browser recording of click, typing, selection, checkbox, keyboard, and upload actions | Implemented; requires `browser_evaluate` and compatible action tools |
| Recorder export | Delete captured actions; copy steps; export recorded Excel and JSON | Implemented |
| Deterministic execution | Explicit XPath and CSS priority, current-DOM resolution, visible-text actions, focused input, custom dropdowns, data-table action areas | Implemented |
| Native-first actions | Prefer Vibium click/fill/select/press/upload tools and verify observable state after actions | Implemented; exact support depends on exposed MCP tools |
| LLM planning | Plan natural-language actions through an OpenAI-compatible `/chat/completions` endpoint | Implemented; requires configured reachable endpoint/token |
| Self-healing | Fresh DOM/page observation, ranked candidates, alternative plan, confidence threshold, bounded retries | Implemented and optional |
| Evidence | Strict action verification, current page map/text/DOM observations, healing history | Implemented |
| HTTPS handling | Optional controlled recovery from Chrome privacy interstitials for approved internal/self-signed test sites | Implemented; use only in authorized environments |
| Screenshots | Every passed step, failures only, or none; downloadable ZIP | Implemented when Vibium screenshot is available |
| Failure behavior | Continue or stop within a scenario; downstream steps can be marked dependency-skipped | Implemented |
| Reruns | Select failed or arbitrary tests and rerun them with the original configuration | Implemented while the application process retains the run snapshot |
| Reports | HTML execution report, technical log HTML, Excel, JSON, screenshot ZIP | Implemented |
| MCP diagnostics | Tool manifest, redacted JSON-RPC transcript, process/bridge logs, per-browser session diagnostics | Implemented |
| Web API | Run submission/status/rerun/artifacts, sheet discovery, browser discovery, recorder lifecycle and exports | Implemented |

## Execution modes

### Shared browser — default

- Starts one MCP client and one browser.
- Runs every test sequentially in spreadsheet/JSON order.
- Keeps login, cookies, storage, tabs, and application session state between tests.
- Applies optional cookie replacement once, after the first scenario reaches its resolved home URL.
- Ignores parallelism by validation: parallel execution cannot be enabled in this mode.

Use this when later tests depend on the same authenticated session or on state created by earlier tests.

### Separate browser per test

- Starts a new MCP client and browser for every scenario.
- Can run sequentially or in parallel.
- Applies optional cookie replacement independently in every test browser after that test reaches its home URL.
- Captures a failed browser startup against its own scenario instead of aborting unrelated tests.

Use this for independent tests and safe concurrency. Parallel capacity is intentionally limited to four browsers and must not exceed the bridge's `maxClients` value.

## Optional cookie workflow

When **Replace one session cookie after the home page opens** is selected:

1. The scenario navigates to its resolved URL.
2. The framework reads the current URL and all browser cookies through native MCP tools.
3. It finds the configured cookie name. If duplicate names exist, it selects the best domain/path match for the current page.
4. It copies the cookie's writable attributes, including domain, path, expiry, `HttpOnly`, `Secure`, `SameSite`, and any supported partition attributes.
5. It removes all cookies.
6. It restores only the selected cookie with the configured replacement value.
7. It reloads or re-navigates to the current URL.
8. It reads cookies again and verifies the new value.

If the named cookie does not exist, no cookie is removed. If the set operation fails after clearing, the framework attempts to restore the selected cookie with its original value and fails the setup step. The replacement value is intentionally not written to framework reports or transcript artifacts.

## Scenario formats

### JSON

```json
[
  {
    "id": "LOGIN-001",
    "name": "Open the dashboard",
    "url": "https://app.example.test/home",
    "steps": [
      "Click \"Sign in\"",
      "Type \"{{username}}\" into the username field"
    ],
    "expected": "Dashboard",
    "data": {
      "username": "test.user"
    }
  }
]
```

An object containing a `scenarios` array is also accepted.

### Excel

Row 1 contains headers. Supported core headers are:

| Header | Purpose |
|---|---|
| `Id` | Test identifier; generated when blank |
| `Name` | Display name; defaults to the ID |
| `Url` | Absolute URL or path resolved against the configured base URL |
| `Steps` | One step per line or separated with `|` |
| `Expected` | Appended as a final display verification |
| `Run` | Optional row enablement flag |
| `TestDataJson`, `TestData`, or `Data` | JSON object merged into scenario data |
| `data.someKey` | Adds `someKey` to scenario data |

## Execution and healing behavior

- Explicit JSON MCP calls are accepted as steps.
- An explicit XPath or CSS locator is resolved against the current DOM before semantic or LLM selection.
- Open shadow roots and same-origin frames are inspected where supported; cross-origin or closed contexts remain browser security boundaries.
- Custom Angular-style dropdowns are handled as a multi-phase transaction: resolve control, open once, re-read live DOM, select, and verify.
- A tool returning success is not sufficient for strict action validation; the framework checks the resulting URL, DOM, target state, visible content, or screenshot evidence.
- Self-healing never calls `browser_start` and must meet the configured confidence threshold.
- Closed shadow roots, canvas-only controls, CAPTCHA, native OS dialogs, inaccessible cross-origin frame internals, and application-specific anti-automation can still require custom support.

## Reports and generated artifacts

Run artifacts are written under `target/itps-vibium-runs/<RUN-ID>/`:

- `report.html`, `report.xlsx`, and `report.json`
- `logs.html`
- `screenshots/` and `screenshots.zip`
- `mcp-tools.json`
- `mcp-transcript.json`
- `mcp-process.log`
- `mcp-sessions/` for isolated-browser diagnostics
- element inventories and report-generation logs when applicable

Recorder exports are written under `target/itps-vibium-recordings/`.

## Configuration

Default runtime configuration is in `src/main/resources/application.properties`; JAR startup adds `config/application-local.properties`.

Key settings:

```properties
itps.vibium.mcp.mode=external-tcp
itps.vibium.mcp.host=127.0.0.1
itps.vibium.mcp.port=8765
itps.vibium.mcp.connect-timeout-seconds=10
itps.vibium.mcp.request-timeout-seconds=90
runner.output-dir=target/itps-vibium-runs
recorder.output-dir=target/itps-vibium-recordings
server.port=8090
```

Bridge configuration is in `tools/local-mcp-bridge/local-mcp-config.json`. `maxClients` defaults to `4`. The bridge binds to loopback only and launches one Vibium MCP child process per Java client.

## Build

Windows:

```bat
build-windows.cmd
```

macOS/Linux:

```bash
chmod +x build-mac.sh
./build-mac.sh
```

Or directly:

```bash
mvn clean package
```

The executable JAR is generated as `target/itps-vibium-mcp-framework-1.0.0.jar`. For the exact post-build run sequence, read [RUN_AFTER_JAR.md](RUN_AFTER_JAR.md).

## Operational limitations

- The archive does not embed a Vibium executable or browser; install/provide Vibium before real UI execution.
- Parallel tests consume one browser process each and may be limited by machine memory/CPU.
- Shared-browser tests are deliberately sequential to prevent state races.
- Cookie setup cannot safely emulate native cookie APIs with page JavaScript because that would lose `HttpOnly` and other protected attributes; it therefore fails clearly when native cookie tools are unavailable.
- Selecting an installed browser other than Vibium-managed Chrome works only if the exposed `browser_start` schema accepts an executable path, browser, or channel.
- Internal-certificate bypass must be enabled only for approved test systems.
- Rerun snapshots are held in application memory and do not survive a framework restart.
