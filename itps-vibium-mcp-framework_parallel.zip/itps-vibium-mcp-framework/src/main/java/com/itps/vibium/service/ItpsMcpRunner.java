package com.itps.vibium.service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.itps.vibium.model.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.time.Duration;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Service
public class ItpsMcpRunner {
    private static final String COOKIE_STEP_MARKER = "__ITPS_REPLACE_SESSION_COOKIE__";
    private final LlmClient llmClient;
    private final ReportService reportService;
    private final RunStore runStore;
    private final ObjectMapper mapper = new ObjectMapper();
    private final EnterpriseDropdownExecutor dropdownExecutor = new EnterpriseDropdownExecutor(mapper);
    private final LiveXPathActionExecutor liveXPathExecutor = new LiveXPathActionExecutor(mapper);
    private final LiveCssActionExecutor liveCssExecutor = new LiveCssActionExecutor(mapper);
    private final FocusedInputExecutor focusedInputExecutor = new FocusedInputExecutor(mapper);
    private final CookieSessionManager cookieSessionManager = new CookieSessionManager(mapper);
    private final Path outputRoot;
    private final int requestTimeoutSeconds;
    private final boolean skipBrowserDownload;

    public ItpsMcpRunner(LlmClient llmClient,
                         ReportService reportService,
                         RunStore runStore,
                         @Value("${runner.output-dir:target/itps-vibium-runs}") String outputDir,
                         @Value("${itps.vibium.mcp.request-timeout-seconds:90}") int requestTimeoutSeconds,
                         @Value("${itps.vibium.skip-browser-download:true}") boolean skipBrowserDownload) {
        this.llmClient = llmClient;
        this.reportService = reportService;
        this.runStore = runStore;
        this.outputRoot = Path.of(outputDir);
        this.requestTimeoutSeconds = requestTimeoutSeconds;
        this.skipBrowserDownload = skipBrowserDownload;
    }

    public void execute(List<TestScenario> scenarios, RunConfig config, RunStatus status) {
        Instant runStart = Instant.now();
        status.setStatus("RUNNING");
        status.setStartedAt(runStart);
        Path runDir = outputRoot.resolve(config.getRunId());
        Path screenshotDir = runDir.resolve("screenshots");
        try {
            Files.createDirectories(screenshotDir);
            validateExecutionMode(config);
            List<ScenarioResult> results = config.isSeparateBrowserPerTest()
                    ? executeWithSeparateBrowsers(scenarios, config, runDir, screenshotDir)
                    : executeWithSharedBrowser(scenarios, config, runDir, screenshotDir);

            status.setScenarios(results);
            status.setTotal(results.size());
            int passed = (int) results.stream().filter(s -> s.getStatus() != null && s.getStatus().startsWith("PASSED")).count();
            status.setPassed(passed);
            status.setFailed(results.size() - passed);
            status.setStatus(status.getFailed() == 0 ? "PASSED" : "COMPLETED_WITH_FAILURES");
            status.setMessage("");
        } catch (Exception e) {
            status.setStatus("FAILED");
            status.setMessage("Vibium MCP execution failed: " + e.getMessage());
        } finally {
            status.setFinishedAt(Instant.now());
            try { reportService.writeReports(status, runDir); }
            catch (Exception reportError) {
                status.setMessage((status.getMessage() == null ? "" : status.getMessage() + " | ") + "Report generation failed: " + reportError.getMessage());
                try { reportService.writeFallbackHtml(status, runDir, reportError); } catch (Exception ignored) {}
            }
        }
    }

    private void validateExecutionMode(RunConfig config) {
        if (config.isParallelExecution() && !config.isSeparateBrowserPerTest()) {
            throw new IllegalArgumentException("Parallel execution requires a separate browser for each test.");
        }
        if (config.isReplaceSessionCookie()
                && (!notBlank(config.getSessionCookieName()) || !notBlank(config.getSessionCookieValue()))) {
            throw new IllegalArgumentException("Cookie name and replacement value are required when cookie replacement is enabled.");
        }
    }

    private List<ScenarioResult> executeWithSharedBrowser(List<TestScenario> scenarios, RunConfig config,
                                                          Path runDir, Path screenshotDir) throws Exception {
        McpClient mcp = null;
        try {
            List<String> args = isExternalTcp(config)
                    ? splitArgs(config.getMcpArgs())
                    : mcpArgsWithScreenshotDir(config.getMcpArgs(), runDir.resolve("mcp-server-screenshots"));
            mcp = createMcpClient(config, args);
            mcp.start();
            List<McpTool> tools = mcp.initializeAndListTools();
            McpToolCatalog catalog = new McpToolCatalog(tools);
            writeToolsManifest(runDir, tools);
            startBrowserOnce(mcp, catalog, config);

            CookieApplicationState cookieState = new CookieApplicationState();
            List<ScenarioResult> results = new ArrayList<>();
            for (TestScenario scenario : scenarios) {
                results.add(executeScenario(mcp, catalog, scenario, config, screenshotDir, cookieState));
            }
            return results;
        } finally {
            if (mcp != null) {
                mcp.writeDiagnostics(runDir);
                try { mcp.close(); } catch (Exception ignored) { }
            }
        }
    }

    private List<ScenarioResult> executeWithSeparateBrowsers(List<TestScenario> scenarios, RunConfig config,
                                                             Path runDir, Path screenshotDir) throws Exception {
        int requested = config.isParallelExecution() ? config.getParallelThreads() : 1;
        int threadCount = Math.max(1, Math.min(Math.min(requested, 4), Math.max(1, scenarios.size())));
        ExecutorService pool = Executors.newFixedThreadPool(threadCount, runnable -> {
            Thread thread = new Thread(runnable, "itps-browser-worker");
            thread.setDaemon(true);
            return thread;
        });
        List<Future<SessionOutcome>> futures = new ArrayList<>();
        try {
            for (int index = 0; index < scenarios.size(); index++) {
                int scenarioIndex = index;
                TestScenario scenario = scenarios.get(index);
                futures.add(pool.submit(() -> executeInSeparateBrowser(
                        scenario, scenarioIndex, config, runDir, screenshotDir)));
            }

            List<ScenarioResult> results = new ArrayList<>();
            List<SessionOutcome> outcomes = new ArrayList<>();
            for (int index = 0; index < futures.size(); index++) {
                try {
                    SessionOutcome outcome = futures.get(index).get();
                    outcomes.add(outcome);
                    results.add(outcome.result());
                } catch (ExecutionException executionError) {
                    Throwable cause = executionError.getCause() == null ? executionError : executionError.getCause();
                    results.add(infrastructureFailure(scenarios.get(index), cause));
                }
            }
            writeAggregateDiagnostics(runDir, outcomes);
            return results;
        } finally {
            pool.shutdownNow();
        }
    }

    private SessionOutcome executeInSeparateBrowser(TestScenario scenario, int index, RunConfig config,
                                                    Path runDir, Path screenshotDir) {
        String sessionName = String.format(Locale.ROOT, "%03d-%s", index + 1, safeName(scenario.getId()));
        Path sessionDir = runDir.resolve("mcp-sessions").resolve(sessionName);
        McpClient mcp = null;
        List<McpTool> tools = List.of();
        ScenarioResult result;
        try {
            List<String> args = isExternalTcp(config)
                    ? splitArgs(config.getMcpArgs())
                    : mcpArgsWithScreenshotDir(config.getMcpArgs(), sessionDir.resolve("server-screenshots"));
            mcp = createMcpClient(config, args);
            mcp.start();
            tools = mcp.initializeAndListTools();
            McpToolCatalog catalog = new McpToolCatalog(tools);
            startBrowserOnce(mcp, catalog, config);
            result = executeScenario(mcp, catalog, scenario, config, screenshotDir, new CookieApplicationState());
        } catch (Exception error) {
            result = infrastructureFailure(scenario, error);
        } finally {
            if (mcp != null) mcp.writeDiagnostics(sessionDir);
        }

        List<String> logs = mcp == null ? List.of() : mcp.getLogs();
        List<Map<String, Object>> transcript = mcp == null ? List.of() : mcp.getTranscript();
        if (mcp != null) {
            try { mcp.close(); } catch (Exception ignored) { }
        }
        return new SessionOutcome(sessionName, result, tools, logs, transcript);
    }

    private ScenarioResult infrastructureFailure(TestScenario scenario, Throwable error) {
        ScenarioResult result = new ScenarioResult();
        result.setId(scenario.getId());
        result.setName(scenario.getName());
        result.setUrl(scenario.getUrl());
        result.setStatus("FAILED");
        String message = "Browser session could not be started or connected: "
                + (error == null || error.getMessage() == null ? "unknown error" : error.getMessage());
        result.setErrorMessage(message);
        StepResult step = new StepResult();
        step.setStepNo(1);
        step.setInstruction("Start isolated browser session");
        step.setPlanSource("INFRASTRUCTURE");
        step.setStatus("FAILED");
        step.setErrorMessage(message);
        step.setEvidence("No test action was executed in this browser session.");
        result.getSteps().add(step);
        return result;
    }

    private void writeAggregateDiagnostics(Path runDir, List<SessionOutcome> outcomes) {
        try {
            Map<String, McpTool> uniqueTools = new LinkedHashMap<>();
            List<Map<String, Object>> transcript = new ArrayList<>();
            List<String> logs = new ArrayList<>();
            for (SessionOutcome outcome : outcomes) {
                for (McpTool tool : outcome.tools()) uniqueTools.putIfAbsent(tool.getName(), tool);
                for (Map<String, Object> event : outcome.transcript()) {
                    Map<String, Object> tagged = new LinkedHashMap<>(event);
                    tagged.put("browserSession", outcome.sessionName());
                    transcript.add(tagged);
                }
                for (String line : outcome.logs()) logs.add("[" + outcome.sessionName() + "] " + line);
            }
            writeToolsManifest(runDir, new ArrayList<>(uniqueTools.values()));
            mapper.writerWithDefaultPrettyPrinter().writeValue(runDir.resolve("mcp-transcript.json").toFile(), transcript);
            Files.writeString(runDir.resolve("mcp-process.log"), String.join(System.lineSeparator(), logs), StandardCharsets.UTF_8);
        } catch (Exception ignored) { }
    }


    private McpClient createMcpClient(RunConfig config, List<String> processArgs) {
        if (isExternalTcp(config)) {
            return McpClient.externalTcp(
                    config.getMcpHost(),
                    config.getMcpPort(),
                    Duration.ofSeconds(Math.max(1, config.getMcpConnectTimeoutSeconds())),
                    Duration.ofSeconds(requestTimeoutSeconds));
        }
        return new McpClient(config.getMcpCommand(), processArgs, Duration.ofSeconds(requestTimeoutSeconds), skipBrowserDownload);
    }

    private boolean isExternalTcp(RunConfig config) {
        return config != null && "external-tcp".equalsIgnoreCase(config.getMcpMode());
    }

    private List<String> mcpArgsWithScreenshotDir(String rawArgs, Path screenshotDir) {
        List<String> args = new ArrayList<>(splitArgs(rawArgs));
        for (int index = 0; index < args.size(); index++) {
            if (args.get(index).equalsIgnoreCase("--screenshot-dir")) {
                if (index + 1 < args.size()) args.set(index + 1, screenshotDir.toAbsolutePath().toString());
                else args.add(screenshotDir.toAbsolutePath().toString());
                return args;
            }
        }
        args.add("--screenshot-dir");
        args.add(screenshotDir.toAbsolutePath().toString());
        return args;
    }

    private void startBrowserOnce(McpClient mcp, McpToolCatalog catalog, RunConfig config) throws Exception {
        Optional<McpTool> start = catalog.startTool();
        if (start.isEmpty()) return;
        Map<String, Object> args = new LinkedHashMap<>();
        if (schemaContains(start.get(), "headless")) args.put("headless", config.isHeadless());
        if (config.getBrowserId() != null && !"vibium-managed-chrome".equalsIgnoreCase(config.getBrowserId())) {
            String executable = config.getBrowserExecutable();
            boolean applied = false;
            for (String key : List.of("executablePath", "browserExecutable", "browserPath", "binary", "executable")) {
                if (schemaContains(start.get(), key) && executable != null && !executable.isBlank()) { args.put(key, executable); applied = true; break; }
            }
            if (!applied) {
                for (String key : List.of("browser", "channel", "browserName")) {
                    if (schemaContains(start.get(), key)) { args.put(key, config.getBrowserId()); applied = true; break; }
                }
            }
            if (!applied) throw new IllegalStateException("Selected browser '" + config.getBrowserName() + "' is installed, but this Vibium MCP version does not expose browser/channel/executablePath in browser_start. Select Vibium Managed Chrome for Testing.");
        }
        JsonNode result = mcp.callTool(start.get().getName(), args);
        assertMcpToolSuccess(start.get().getName(), result);
    }

    private ScenarioResult executeScenario(McpClient mcp, McpToolCatalog catalog, TestScenario scenario,
                                           RunConfig config, Path screenshotDir,
                                           CookieApplicationState cookieState) {
        long scenarioStart = System.currentTimeMillis();
        ScenarioResult out = new ScenarioResult();
        out.setId(scenario.getId());
        out.setName(scenario.getName());
        out.setUrl(resolveUrl(scenario.getUrl(), config.getAppBaseUrl()));
        out.setStatus("RUNNING");

        List<String> steps = new ArrayList<>();
        if (notBlank(out.getUrl())) {
            steps.add("Navigate to " + out.getUrl());
        }
        steps.addAll(scenario.getSteps());
        if (config.isReplaceSessionCookie() && !cookieState.applied) {
            for (int index = 0; index < steps.size(); index++) {
                if (isNavigate(steps.get(index))) {
                    steps.add(index + 1, COOKIE_STEP_MARKER);
                    break;
                }
            }
        }
        if (notBlank(scenario.getExpected())) steps.add("Verify " + applyData(scenario.getExpected(), scenario.getData()) + " is displayed");

        boolean failed = false;
        boolean dependencyFailed = false;
        int stepNo = 1;
        for (String raw : steps) {
            if (dependencyFailed) {
                StepResult skipped = new StepResult();
                skipped.setStepNo(stepNo);
                skipped.setInstruction(COOKIE_STEP_MARKER.equals(raw)
                        ? cookieInstruction(config)
                        : applyData(raw, scenario.getData()));
                skipped.setStatus("SKIPPED_DEPENDENCY_FAILURE");
                skipped.setErrorMessage("Skipped because a previous UI step failed and the browser state is no longer reliable.");
                skipped.setEvidence("Not executed. Fix the first failed step before evaluating downstream validations.");
                out.getSteps().add(skipped);
                stepNo++;
                continue;
            }
            StepResult sr;
            if (COOKIE_STEP_MARKER.equals(raw)) {
                sr = executeCookieStep(mcp, catalog, config, stepNo);
                if (sr.getStatus() != null && sr.getStatus().startsWith("PASSED")) cookieState.applied = true;
            } else {
                sr = executeStep(mcp, catalog, scenario, config, raw, stepNo, screenshotDir);
            }
            out.getSteps().add(sr);
            if (sr.getStatus() == null || !sr.getStatus().startsWith("PASSED")) {
                failed = true;
                dependencyFailed = true;
                out.setErrorMessage(sr.getErrorMessage());
                if (!config.isContinueOnFailure()) break;
            }
            stepNo++;
        }
        boolean healed = out.getSteps().stream().anyMatch(StepResult::isHealed);
        out.setStatus(failed ? "FAILED" : (healed ? "PASSED_HEALED" : "PASSED"));
        out.setDurationMs(System.currentTimeMillis() - scenarioStart);
        return out;
    }

    private StepResult executeCookieStep(McpClient mcp, McpToolCatalog catalog, RunConfig config, int stepNo) {
        long start = System.currentTimeMillis();
        StepResult step = new StepResult();
        step.setStepNo(stepNo);
        step.setInstruction(cookieInstruction(config));
        step.setPlanSource("MCP_COOKIE_TRANSACTION");
        step.setToolArguments("{\"cookieName\":" + jsonString(config.getSessionCookieName())
                + ",\"replacementValue\":\"[REDACTED]\"}");
        try {
            CookieSessionManager.Result result = cookieSessionManager.replaceCookie(
                    mcp, catalog, config.getSessionCookieName(), config.getSessionCookieValue());
            step.setToolName(String.join(" -> ", result.toolsUsed()));
            step.setActionJson(result.redactedAudit().toString());
            step.setMcpResult(result.redactedAudit().toString());
            step.setEvidence(result.evidence());
            step.setStatus("PASSED");
        } catch (Exception error) {
            step.setStatus("FAILED");
            step.setErrorMessage(error.getMessage());
            step.setEvidence("Cookie replacement is optional. Disable it to run without changing cookies, or expose compatible cookie tools in Vibium MCP.");
        } finally {
            step.setDurationMs(System.currentTimeMillis() - start);
        }
        return step;
    }

    private String cookieInstruction(RunConfig config) {
        return "Remove all cookies, restore '" + config.getSessionCookieName()
                + "' with its existing attributes and the configured replacement value, then refresh";
    }

    private String jsonString(String value) {
        try { return mapper.writeValueAsString(value == null ? "" : value); }
        catch (Exception ignored) { return "\"\""; }
    }

    private StepResult executeStep(McpClient mcp, McpToolCatalog catalog, TestScenario scenario, RunConfig config, String rawStep, int stepNo, Path screenshotDir) {
        StepResult sr = new StepResult();
        long start = System.currentTimeMillis();
        String instruction = applyData(rawStep, scenario.getData());
        sr.setStepNo(stepNo);
        sr.setInstruction(instruction);
        String beforeFingerprint = "";
        String beforeShot = "";
        List<String> healingHistory = new ArrayList<>();
        String suppliedXPath = extractXPathFromStep(instruction);
        String suppliedCss = extractCssFromStep(instruction);
        if (notBlank(suppliedXPath)) {
            healingHistory.add("Locator source: USER_XPATH");
            healingHistory.add("XPath: " + suppliedXPath);
            healingHistory.add("Selection rule: first visible match");
        } else if (notBlank(suppliedCss)) {
            healingHistory.add("Locator source: USER_CSS");
            healingHistory.add("CSS: " + suppliedCss);
            healingHistory.add("Selection rule: first visible match");
        }
        try {
            String actionIntent = expectedIntent(instruction);
            JsonNode freshPreActionObservation = observePage(mcp, catalog);
            beforeFingerprint = fingerprintFromObservation(freshPreActionObservation);
            healingHistory.add("DOM refresh before action: YES");
            healingHistory.add("Action classification: " + actionIntent);
            if (requiresPostEvidence(actionIntent)) {
                beforeShot = captureScreenshotQuietly(mcp, catalog, screenshotDir, scenario.getId(), stepNo + "_before");
            }
            boolean hasExplicitXPath = notBlank(suppliedXPath);
            boolean hasExplicitCss = notBlank(suppliedCss);
            boolean enterpriseDropdown = !hasExplicitXPath && !hasExplicitCss && dropdownExecutor.supports(instruction);
            // Absolute priority: a user/recorder supplied XPath or CSS is executed against the
            // current live DOM before visible-text, semantic, mapped-DOM or LLM locator selection.
            if (notBlank(suppliedXPath)) {
                LiveXPathActionExecutor.Execution execution = liveXPathExecutor.execute(mcp, catalog, instruction, suppliedXPath, config);
                sr.setPlanSource(execution.planSource());
                sr.setActionJson(execution.actionJson());
                sr.setToolName(execution.toolName());
                sr.setToolArguments(execution.toolArguments());
                sr.setMcpResult(execution.mcpResult());
                sr.setEvidence(execution.evidence());
                JsonNode postXPathObservation = observePage(mcp, catalog);
                ObjectNode xpathAudit = mapper.createObjectNode();
                xpathAudit.put("policy", "USER_XPATH_ABSOLUTE_FIRST_PRIORITY");
                xpathAudit.put("llmUsed", false);
                xpathAudit.put("nativeBrowserInputPreferred", true);
                xpathAudit.set("transaction", execution.audit());
                xpathAudit.set("postActionObservation", postXPathObservation);
                sr.setPageInventory(compact(xpathAudit.toString(), 60000));
                healingHistory.add("XPath result: SUCCESS");
                healingHistory.add("Fallback used: NO");
                healingHistory.add("Final strategy: USER_XPATH_NATIVE_FIRST");
                healingHistory.add("LLM healing used: NO");
                sr.setStatus("PASSED");
                return sr;
            }

            if (notBlank(suppliedCss)) {
                LiveCssActionExecutor.Execution execution = liveCssExecutor.execute(mcp, catalog, instruction, suppliedCss, config);
                sr.setPlanSource(execution.planSource());
                sr.setActionJson(execution.actionJson());
                sr.setToolName(execution.toolName());
                sr.setToolArguments(execution.toolArguments());
                sr.setMcpResult(execution.mcpResult());
                sr.setEvidence(execution.evidence());
                ObjectNode cssAudit = mapper.createObjectNode();
                cssAudit.put("policy", "USER_CSS_ABSOLUTE_FIRST_PRIORITY");
                cssAudit.put("llmUsed", false);
                cssAudit.put("nativeBrowserInputPreferred", true);
                cssAudit.set("transaction", execution.audit());
                cssAudit.set("postActionObservation", observePage(mcp, catalog));
                sr.setPageInventory(compact(cssAudit.toString(), 60000));
                healingHistory.add("CSS result: SUCCESS");
                healingHistory.add("Fallback used: NO");
                healingHistory.add("Final strategy: USER_CSS_NATIVE_FIRST");
                healingHistory.add("LLM healing used: NO");
                sr.setStatus("PASSED");
                return sr;
            }

            if (liveXPathExecutor.supportsVisibleText(instruction)) {
                LiveXPathActionExecutor.Execution execution = liveXPathExecutor.executeVisibleText(mcp, catalog, instruction, config);
                sr.setPlanSource(execution.planSource());
                sr.setActionJson(execution.actionJson());
                sr.setToolName(execution.toolName());
                sr.setToolArguments(execution.toolArguments());
                sr.setMcpResult(execution.mcpResult());
                sr.setEvidence(execution.evidence());
                ObjectNode audit = mapper.createObjectNode();
                audit.put("policy", "EXACT_VISIBLE_TEXT_NATIVE_FIRST");
                audit.put("llmUsed", false);
                audit.set("transaction", execution.audit());
                audit.set("postActionObservation", observePage(mcp, catalog));
                sr.setPageInventory(compact(audit.toString(), 60000));
                healingHistory.add("Locator source: EXACT_VISIBLE_TEXT");
                healingHistory.add("Final strategy: EXACT_VISIBLE_TEXT_NATIVE_FIRST");
                healingHistory.add("LLM healing used: NO");
                sr.setStatus("PASSED");
                return sr;
            }

            if (focusedInputExecutor.supports(instruction)) {
                FocusedInputExecutor.Execution execution = focusedInputExecutor.execute(mcp, catalog, instruction, config);
                sr.setPlanSource(execution.planSource());
                sr.setActionJson(execution.actionJson());
                sr.setToolName(execution.toolName());
                sr.setToolArguments(execution.toolArguments());
                sr.setMcpResult(execution.mcpResult());
                sr.setEvidence(execution.evidence());
                ObjectNode audit = mapper.createObjectNode();
                audit.put("policy", "FOCUSED_INPUT_NATIVE_FILL");
                audit.put("llmUsed", false);
                audit.set("transaction", execution.audit());
                audit.set("postActionObservation", observePage(mcp, catalog));
                sr.setPageInventory(compact(audit.toString(), 60000));
                healingHistory.add("Input strategy: focused/active combobox input");
                healingHistory.add("Final strategy: FOCUSED_INPUT_NATIVE_FILL");
                healingHistory.add("LLM healing used: NO");
                sr.setStatus("PASSED");
                return sr;
            }

            if (enterpriseDropdown) {
                EnterpriseDropdownExecutor.Execution execution = dropdownExecutor.execute(mcp, catalog, instruction, config);
                sr.setPlanSource(execution.planSource());
                sr.setActionJson(execution.actionJson());
                sr.setToolName(execution.toolName());
                sr.setToolArguments(execution.toolArguments());
                sr.setMcpResult(execution.mcpResult());
                sr.setEvidence(execution.evidence());
                JsonNode postDropdownObservation = observePage(mcp, catalog);
                ObjectNode refreshAudit = mapper.createObjectNode();
                refreshAudit.put("policy", "FRESH_DOM_BETWEEN_DROPDOWN_SUB_ACTIONS");
                refreshAudit.put("refreshedBeforeTrigger", true);
                refreshAudit.put("refreshedAfterTrigger", true);
                refreshAudit.put("refreshedAfterOption", true);
                refreshAudit.set("transaction", execution.audit());
                refreshAudit.set("postActionObservation", postDropdownObservation);
                sr.setPageInventory(compact(refreshAudit.toString(), 60000));
                sr.setStatus("PASSED");
                return sr;
            }

            PlannedStep plan = planStep(mcp, catalog, instruction, scenario, config, null, freshPreActionObservation);
            if (plan.observation() == null) plan = new PlannedStep(plan.source(), plan.plan(), freshPreActionObservation);
            applyPlanToStep(sr, plan, screenshotDir.getParent(), scenario.getId(), stepNo);
            executeValidatedPlan(mcp, catalog, plan.plan(), sr, instruction, config, plan.observation(), beforeFingerprint, beforeShot, screenshotDir, scenario.getId(), stepNo);
            sr.setStatus("PASSED");
        } catch (Exception first) {
            Exception finalError = first;
            if (notBlank(suppliedXPath)) {
                healingHistory.add("XPath result: FAILED - " + compact(first.getMessage(), 1400));
                try {
                    PlannedStep deterministic = deterministicHealingAfterUserXPath(catalog, instruction);
                    if (deterministic != null) {
                        applyPlanToStep(sr, deterministic, screenshotDir.getParent(), scenario.getId(), stepNo);
                        executeValidatedPlan(mcp, catalog, deterministic.plan(), sr, removeXPathClause(instruction), config,
                                deterministic.observation(), beforeFingerprint, beforeShot, screenshotDir, scenario.getId(), stepNo);
                        healingHistory.add("Fallback used: YES");
                        healingHistory.add("Final strategy: " + deterministic.source());
                        healingHistory.add("LLM healing used: NO");
                        sr.setHealed(true);
                        sr.setHealingAttempts(1);
                        sr.setStatus("PASSED_HEALED");
                        finalError = null;
                    }
                } catch (Exception deterministicError) {
                    healingHistory.add("Deterministic healing failed: " + compact(deterministicError.getMessage(), 1400));
                    finalError = deterministicError;
                }
            }
            if (finalError != null && notBlank(suppliedCss)) {
                healingHistory.add("CSS result: FAILED - " + compact(first.getMessage(), 1400));
            }
            int maxHealing = finalError == null || (!notBlank(suppliedXPath) && !notBlank(suppliedCss) && dropdownExecutor.supports(instruction)) ? 0
                    : (config.isEnableSelfHealing() ? Math.max(0, config.getRetryCount()) : 0);
            for (int attempt = 1; attempt <= maxHealing; attempt++) {
                try {
                    String failedShot = captureScreenshotQuietly(mcp, catalog, screenshotDir, scenario.getId(), stepNo + "_failed_" + attempt);
                    Thread.sleep(Math.max(200, config.getRetryDelayMs()));
                    String healingInstruction = notBlank(suppliedCss) ? removeCssClause(instruction) : instruction;
                    PlannedStep healedPlan = healStep(mcp, catalog, healingInstruction, scenario, config, finalError.getMessage(), sr.getActionJson(), attempt, failedShot);
                    applyPlanToStep(sr, healedPlan, screenshotDir.getParent(), scenario.getId(), stepNo);
                    executeValidatedPlan(mcp, catalog, healedPlan.plan(), sr, instruction, config, healedPlan.observation(), beforeFingerprint, beforeShot, screenshotDir, scenario.getId(), stepNo);
                    healingHistory.add("Attempt " + attempt + " succeeded. Strategy=" + healedPlan.source() + "; previousError=" + compact(finalError.getMessage(), 1200));
                    sr.setHealed(true);
                    sr.setHealingAttempts(attempt);
                    sr.setStatus("PASSED_HEALED");
                    finalError = null;
                    break;
                } catch (Exception healingError) {
                    healingHistory.add("Attempt " + attempt + " failed: " + compact(healingError.getMessage(), 1600));
                    finalError = healingError;
                }
            }
            if (finalError != null) {
                sr.setStatus("FAILED");
                sr.setErrorMessage(finalError.getMessage());
                if (shouldScreenshot(config, false)) sr.setScreenshot(captureScreenshotQuietly(mcp, catalog, screenshotDir, scenario.getId(), String.valueOf(stepNo)));
            }
        } finally {
            if (!healingHistory.isEmpty()) sr.setHealingHistory(String.join("\n", healingHistory));
            if (shouldScreenshot(config, true) && (sr.getScreenshot() == null || sr.getScreenshot().isBlank()) && sr.getStatus() != null && sr.getStatus().startsWith("PASSED")) {
                sr.setScreenshot(captureScreenshotQuietly(mcp, catalog, screenshotDir, scenario.getId(), String.valueOf(stepNo)));
            }
            sr.setDurationMs(System.currentTimeMillis() - start);
        }
        return sr;
    }

    private void applyPlanToStep(StepResult sr, PlannedStep plan, Path runDir, String scenarioId, int stepNo) {
        sr.setPlanSource(plan.source());
        sr.setActionJson(plan.plan().toString());
        sr.setPageInventory(plan.observation() == null ? "" : compact(plan.observation().toString(), 60000));
        writeElementInventory(runDir, scenarioId, stepNo, plan.observation());
    }

    private PlannedStep deterministicHealingAfterUserXPath(McpToolCatalog catalog, String instruction) throws Exception {
        String english = removeXPathClause(instruction);
        if (isCustomDropdownSelection(english)) {
            return new PlannedStep("DOM_CUSTOM_DROPDOWN_HEALING", directCustomDropdownPlan(catalog, english), null);
        }
        if (isFirstRowActionAreaClick(english)) {
            return new PlannedStep("DOM_FIRST_ROW_ACTION_HEALING", directFirstRowActionAreaPlan(catalog), null);
        }
        if (isWait(english)) return new PlannedStep("DIRECT_WAIT_HEALING", directWaitPlan(catalog), null);
        if (isNavigate(english)) return new PlannedStep("DIRECT_NAVIGATE_HEALING", directNavigatePlan(catalog, english), null);
        return null;
    }

    private PlannedStep healStep(McpClient mcp, McpToolCatalog catalog, String instruction, TestScenario scenario, RunConfig config,
                                 String failure, String previousPlan, int attempt, String failedScreenshot) throws Exception {
        if (!config.isUseLlm() || !llmClient.isConfigured(config)) {
            throw new IllegalStateException("Self-healing requires configured LLM. Original failure: " + failure);
        }
        JsonNode observation = observePage(mcp, catalog);
        if (observation instanceof ObjectNode objectObservation) {
            objectObservation.set("rankedCandidates", rankCandidates(observation, instruction, 150));
            objectObservation.put("healingAttempt", attempt);
            objectObservation.put("failedScreenshot", failedScreenshot == null ? "" : failedScreenshot);
        }
        String prompt = buildHealingPrompt(instruction, scenario, catalog, observation, failure, previousPlan, attempt);
        JsonNode root = mapper.readTree(llmClient.healMcpCall(prompt, config));
        double confidence = root.path("confidence").asDouble(0.0);
        if (confidence < config.getHealingConfidenceThreshold()) {
            throw new IllegalStateException("LLM healing confidence " + confidence + " is below threshold " + config.getHealingConfidenceThreshold() + ". Reason=" + root.path("why").asText());
        }
        JsonNode normalized = normalizePlan(root);
        return new PlannedStep("LLM_SELF_HEALING_" + attempt + "_" + root.path("strategy").asText("REPLAN"), normalized, observation);
    }

    private String buildHealingPrompt(String instruction, TestScenario scenario, McpToolCatalog catalog, JsonNode observation,
                                      String failure, String previousPlan, int attempt) throws Exception {
        return "Instruction: " + instruction + "\n" +
                "Scenario: " + scenario.getId() + " - " + scenario.getName() + "\n" +
                "Test data: " + mapper.writeValueAsString(scenario.getData()) + "\n" +
                "Healing attempt: " + attempt + "\n" +
                "Previous plan: " + compact(previousPlan, 12000) + "\n" +
                "Failure: " + compact(failure, 6000) + "\n" +
                "Rules: use a different strategy; inspect clickable ancestor, exact occurrence, section context, labels, SVG metadata, frame/shadow context, visibility and hit-test. " +
                "For validation failure, prove the expected label/value relationship using contentElements, formValues, tables and allVisibleText. " +
                "Never repeat the same failed selector. Never return browser_start. Return at least one executable Vibium MCP call.\n" +
                "Available tools:\n" + catalog.toPromptText() + "\n" +
                "Fresh deep page observation:\n" + compact(observation.toString(), 90000);
    }

    private PlannedStep planStep(McpClient mcp, McpToolCatalog catalog, String instruction, TestScenario scenario, RunConfig config, String failure) throws Exception {
        return planStep(mcp, catalog, instruction, scenario, config, failure, null);
    }

    private PlannedStep planStep(McpClient mcp, McpToolCatalog catalog, String instruction, TestScenario scenario, RunConfig config,
                                 String failure, JsonNode suppliedFreshObservation) throws Exception {
        JsonNode direct = parseDirectJson(instruction);
        if (direct != null) return new PlannedStep("EXPLICIT_JSON", normalizePlan(direct), null);
        String explicitXPath = extractXPathFromStep(instruction);
        if (notBlank(explicitXPath)) return new PlannedStep("USER_XPATH_PRIORITY", directXPathPlan(catalog, instruction, explicitXPath), null);
        String explicitCss = extractCssFromStep(instruction);
        if (notBlank(explicitCss)) throw new IllegalStateException("Explicit CSS should have been routed to the deterministic USER_CSS executor before planning.");
        if (isNavigate(instruction)) return new PlannedStep("DIRECT_NAVIGATE", directNavigatePlan(catalog, instruction), null);
        if (isWait(instruction)) return new PlannedStep("DIRECT_WAIT", directWaitPlan(catalog), null);
        if (isCustomDropdownSelection(instruction)) {
            return new PlannedStep("DIRECT_CUSTOM_DROPDOWN", directCustomDropdownPlan(catalog, instruction), null);
        }
        if (isFirstRowActionAreaClick(instruction)) {
            return new PlannedStep("DIRECT_FIRST_ROW_ACTION_AREA", directFirstRowActionAreaPlan(catalog), null);
        }
        if (isAssert(expectedIntent(instruction))) {
            JsonNode observation = suppliedFreshObservation == null ? observePage(mcp, catalog) : suppliedFreshObservation;
            return new PlannedStep("DIRECT_UNIFIED_VALIDATION", directAssertPlan(catalog), observation);
        }

        if (!config.isUseLlm()) {
            throw new IllegalStateException("Natural-language action step requires LLM planning. Enable Use LLM or provide explicit JSON MCP calls. Step: " + instruction);
        }
        if (!llmClient.isConfigured(config)) {
            throw new IllegalStateException("LLM Base URL/token/model are required for natural-language UI action planning. Step: " + instruction);
        }

        JsonNode observation = observePage(mcp, catalog);
        if (observation instanceof ObjectNode objectObservation) {
            objectObservation.set("rankedCandidates", rankCandidates(observation, instruction, 80));
        }
        String prompt = buildAgentPrompt(instruction, scenario, catalog, observation, failure);
        JsonNode planned = mapper.readTree(llmClient.planMcpCall(prompt, config));
        return new PlannedStep("LLM_MAP_DOM_CLOSED_LOOP", normalizePlan(planned), observation);
    }

    private JsonNode observePage(McpClient mcp, McpToolCatalog catalog) {
        ObjectNode out = mapper.createObjectNode();
        out.set("url", safeToolResult(mcp, catalog.urlTool(), Map.of()));
        out.set("title", safeToolResult(mcp, catalog.titleTool(), Map.of()));
        out.set("text", safeToolResult(mcp, catalog.textTool(), Map.of()));
        out.set("map", safeMap(mcp, catalog));
        out.set("pageModel", safeDomProbe(mcp, catalog));
        return out;
    }

    private void executeValidatedPlan(McpClient mcp, McpToolCatalog catalog, JsonNode originalPlan, StepResult sr,
                                      String instruction, RunConfig config, JsonNode observation, String beforeFingerprint,
                                      String beforeScreenshot, Path screenshotDir, String scenarioId, int stepNo) throws Exception {
        JsonNode plan = removeNoOpStart(originalPlan);
        if (plan == null || flattenCalls(plan).isEmpty()) throw new IllegalStateException("No executable MCP tool calls returned. Plan=" + originalPlan);
        String expectedIntent = expectedIntent(instruction);
        // Assertions are evidence-reading operations, not state-changing browser actions.
        // A browser_text/browser_map/browser_is_visible style call is valid evidence and must
        // never be rejected merely because it is not a click/fill/select operation.
        if (!isAssert(expectedIntent) && requiresRealAction(expectedIntent) && !containsRealAction(plan, expectedIntent)) {
            throw new IllegalStateException("Planner did not return a real MCP action for instruction='" + instruction + "'. Plan=" + originalPlan);
        }

        List<String> tools = new ArrayList<>();
        List<Map<String, Object>> argsList = new ArrayList<>();
        List<String> results = new ArrayList<>();
        boolean executedAction = false;
        boolean alreadySatisfied = false;
        boolean primaryActionCompleted = false;
        boolean atomicInstruction = isAtomicInstruction(instruction);
        boolean stopAfterPrimaryAction = atomicInstruction && !Set.of("SELECT", "COMPOSITE").contains(expectedIntent);

        for (JsonNode call : flattenCalls(plan)) {
            String toolName = firstText(call, "tool", "name", "mcpTool", "toolName");
            if (isBrowserStart(toolName)) continue;

            // A planner may return a chain such as find -> click -> find/click again. Once the
            // requested atomic action succeeds, continuing with stale locators can search for the
            // old menu on the newly navigated page and incorrectly fail the test.
            if (stopAfterPrimaryAction && primaryActionCompleted) break;

            McpTool tool = catalog.findByName(toolName).orElseThrow(() -> new IllegalArgumentException("MCP tool not found: " + toolName));
            Map<String, Object> args = normalizeArgsForTool(tool, call.path("arguments"));
            if (isActionTool(tool.getName())) validateSelectorUniqueness(mcp, catalog, tool.getName(), args);
            JsonNode result = callToolRobustly(mcp, catalog, tool, args, config, instruction);
            assertMcpToolSuccess(tool.getName(), result);
            tools.add(tool.getName());
            argsList.add(args);
            results.add(compact(result.toString(), 4000));
            if (result.toString().contains("alreadySatisfied") && result.toString().contains("true")) {
                alreadySatisfied = true;
            }

            if (isStateChangingTool(tool.getName())) {
                executedAction = true;
                primaryActionCompleted = true;
                waitForUiToSettle(mcp, catalog, Math.max(350, config.getRetryDelayMs()));
            }
        }

        sr.setToolName(String.join(" → ", tools));
        sr.setToolArguments(mapper.writeValueAsString(argsList));
        sr.setMcpResult(String.join("\n---\n", results));

        String afterScreenshot = (requiresPostEvidence(expectedIntent) || shouldScreenshot(config, true)) ? captureScreenshotQuietly(mcp, catalog, screenshotDir, scenarioId, String.valueOf(stepNo)) : "";
        if (notBlank(afterScreenshot)) sr.setScreenshot(afterScreenshot);

        JsonNode afterObservation = observePage(mcp, catalog);
        if (executedAction) {
            ObjectNode refreshAudit = mapper.createObjectNode();
            refreshAudit.put("policy", "FRESH_DOM_PER_ACTION");
            refreshAudit.put("actionIntent", expectedIntent);
            refreshAudit.put("refreshedBefore", true);
            refreshAudit.put("refreshedAfter", true);
            refreshAudit.set("postActionObservation", afterObservation);
            sr.setPageInventory(compact(refreshAudit.toString(), 60000));
        }
        if (isAssert(expectedIntent)) {
            AssertionEvidence assertionEvidence = assertInstructionWithRetry(mcp, catalog, instruction, afterObservation, 3, 500);
            sr.setEvidence("Assertion passed using " + assertionEvidence.strategy() +
                    ". Expected='" + assertionEvidence.expected() + "'. Matched='" + assertionEvidence.matchedText() + "'.");
        } else if (alreadySatisfied && requiresPostEvidence(expectedIntent)) {
            sr.setEvidence("User XPath resolved the first visible element. The expected value/state was already satisfied, so no duplicate action or LLM healing was required.");
        } else if (executedAction && requiresPostEvidence(expectedIntent)) {
            String afterFingerprint = pageFingerprint(mcp, catalog);
            boolean changed = !Objects.equals(beforeFingerprint, afterFingerprint);
            boolean screenshotChanged = screenshotsDifferent(screenshotDir, beforeScreenshot, afterScreenshot);
            if (!changed && !screenshotChanged) {
                throw new IllegalStateException("MCP tool returned success but no DOM/text/URL/screenshot evidence changed. This prevents fake pass. Step='" + instruction + "'. Tools=" + tools + ". Try a more descriptive step or check mcp-transcript.json and screenshots.");
            }
            sr.setEvidence("Closed-loop evidence passed: " + (changed ? "DOM/text/url changed" : "visual screenshot changed") + ".");
        } else if (requiresPostEvidence(expectedIntent)) {
            throw new IllegalStateException("Action step produced no executable state-changing MCP action. Step='" + instruction + "'. Tools=" + tools);
        } else {
            sr.setEvidence("Non-action MCP step completed without error.");
        }
    }

    private JsonNode callToolRobustly(McpClient mcp, McpToolCatalog catalog, McpTool tool,
                                      Map<String, Object> args, RunConfig config, String instruction) throws Exception {
        String toolName = tool.getName();

        if (containsAny(toolName, "navigate", "goto")) {
            String url = firstNonBlankArg(args, "url", "uri", "href", "target");
            try {
                JsonNode result = mcp.callTool(toolName, args);
                assertMcpToolSuccess(toolName, result);
                return result;
            } catch (Exception navigationFailure) {
                if (InsecureCertificateRecovery.canAttempt(url, config.isAllowInsecureCertificates())) {
                    InsecureCertificateRecovery.Outcome recovery = InsecureCertificateRecovery.recover(
                            mcp, catalog, url, mapper);
                    if (recovery.recovered()) return recovery.navigationResult();
                    throw new IllegalStateException(
                            "HTTPS navigation failed and automatic internal-certificate recovery was unsuccessful. Original error: "
                                    + compact(navigationFailure.getMessage(), 700) + ". Recovery evidence: "
                                    + compact(recovery.evidence(), 1000), navigationFailure);
                }
                throw navigationFailure;
            }
        }

        if (!containsAny(toolName, "click", "tap", "press")) {
            return mcp.callTool(toolName, args);
        }

        Object rawSelector = args.get("selector");
        if (rawSelector == null) rawSelector = args.get("text");
        if (rawSelector == null) rawSelector = args.get("name");
        if (rawSelector == null) rawSelector = args.get("label");
        if (rawSelector == null) rawSelector = args.get("target");
        String selector = rawSelector == null ? "" : String.valueOf(rawSelector).trim();
        String semanticTarget = extractSemanticClickTarget(instruction, selector);
        int attempts = Math.max(4, Math.min(7, config.getRetryCount() + 4));
        Exception last = null;
        for (int attempt = 1; attempt <= attempts; attempt++) {
            try {
                if (!selector.isBlank() && !selector.startsWith("@")) {
                    prepareElementForClick(mcp, catalog, selector, config.getStepTimeoutSeconds());
                }
                JsonNode result = mcp.callTool(toolName, args);
                assertMcpToolSuccess(toolName, result);
                return result;
            } catch (Exception e) {
                last = e;
                String message = String.valueOf(e.getMessage()).toLowerCase(Locale.ROOT);
                boolean obstruction = message.contains("obscured") || message.contains("intercept") ||
                        message.contains("not clickable") || message.contains("receives events") ||
                        message.contains("covered") || message.contains("detached") || message.contains("timeout");
                if (!obstruction) break;

                // Recover immediately while transient hover menus are still open. This is especially
                // important for menu items such as "New search", where the physical pointer click can
                // be intercepted by a child span, badge, animation layer, or transparent container.
                if (!selector.isBlank() || !semanticTarget.isBlank()) {
                    JsonNode recovered = safeDomClick(mcp, catalog, semanticTarget.isBlank() ? selector : semanticTarget);
                    if (recovered.path("clicked").asBoolean(false)) {
                        ObjectNode synthetic = mapper.createObjectNode();
                        synthetic.put("content", "Semantic click recovery executed after Vibium pointer click was intercepted");
                        synthetic.put("recoveryAttempt", attempt);
                        synthetic.set("details", recovered);
                        return synthetic;
                    }
                }
                if (attempt == attempts) break;
                sleep(Math.max(350, config.getRetryDelayMs()));
            }
        }

        if (!selector.isBlank() && last != null) {
            String failure = String.valueOf(last.getMessage()).toLowerCase(Locale.ROOT);
            if (failure.contains("obscured") || failure.contains("intercept") ||
                    failure.contains("not clickable") || failure.contains("receives events") ||
                    failure.contains("covered") || failure.contains("timeout")) {
                JsonNode fallback = safeDomClick(mcp, catalog, semanticTarget.isBlank() ? selector : semanticTarget);
                if (fallback.path("clicked").asBoolean(false)) {
                    ObjectNode synthetic = mapper.createObjectNode();
                    synthetic.put("content", "Enterprise DOM click fallback executed after Vibium pointer click failed");
                    synthetic.set("details", fallback);
                    return synthetic;
                }
            }
        }
        throw last == null ? new IllegalStateException("Click failed without a diagnostic") : last;
    }

    private String firstNonBlankArg(Map<String, Object> args, String... keys) {
        if (args == null || keys == null) return "";
        for (String key : keys) {
            Object value = args.get(key);
            if (value != null && !String.valueOf(value).isBlank()) return String.valueOf(value).trim();
        }
        return "";
    }

    private String extractSemanticClickTarget(String instruction, String selector) {
        String text = removeXPathClause(instruction == null ? "" : instruction).trim();
        java.util.regex.Matcher quoted = java.util.regex.Pattern.compile("[\"']([^\"']{2,120})[\"']").matcher(text);
        String lastQuoted = "";
        while (quoted.find()) lastQuoted = quoted.group(1).trim();
        if (!lastQuoted.isBlank()) return lastQuoted;

        // Vibium map references such as @e13 identify the mapped node, but the node may be a child SPAN.
        // Recover the human target from the step and use exact semantic matching against the live DOM.
        if (selector != null && selector.startsWith("@")) {
            String cleaned = text.replaceAll("(?i)\\b(click|tap|press|select|choose|find|open|menu|item|icon|button|the|a|an)\\b", " ")
                    .replaceAll("\\s+", " ").trim();
            if (!cleaned.isBlank()) return cleaned;
        }
        return selector == null ? "" : selector;
    }

    private void prepareElementForClick(McpClient mcp, McpToolCatalog catalog, String selector, int timeoutSeconds) {
        Optional<McpTool> eval = catalog.evaluateTool();
        if (eval.isEmpty()) return;
        try {
            String encoded = Base64.getEncoder().encodeToString(selector.getBytes(StandardCharsets.UTF_8));
            String script = """
                (() => {
                  const selector = atob('%s');
                  let element;
                  try { element = document.querySelector(selector); } catch (e) { return JSON.stringify({ready:false,error:e.message}); }
                  if (!element) return JSON.stringify({ready:false,error:'not-found'});
                  element.scrollIntoView({block:'center', inline:'center', behavior:'instant'});
                  const inspect = () => {
                    const r = element.getBoundingClientRect();
                    const style = getComputedStyle(element);
                    const x = Math.max(0, Math.min(innerWidth - 1, r.left + r.width / 2));
                    const y = Math.max(0, Math.min(innerHeight - 1, r.top + r.height / 2));
                    const top = document.elementFromPoint(x, y);
                    const receives = !!top && (top === element || element.contains(top) || top.contains(element));
                    return {ready:r.width>1&&r.height>1&&style.visibility!=='hidden'&&style.display!=='none'&&receives,
                            top:top ? (top.tagName + '#' + (top.id||'') + '.' + [...top.classList].slice(0,3).join('.')) : '',
                            disabled:!!element.disabled};
                  };
                  return JSON.stringify(inspect());
                })()
                """.formatted(encoded);
            Map<String,Object> evalArgs = new LinkedHashMap<>();
            if (schemaContains(eval.get(), "expression")) evalArgs.put("expression", script);
            else if (schemaContains(eval.get(), "script")) evalArgs.put("script", script);
            else evalArgs.put("code", script);
            mcp.callTool(eval.get().getName(), evalArgs);
        } catch (Exception ignored) { }
    }

    private JsonNode safeDomClick(McpClient mcp, McpToolCatalog catalog, String selector) {
        Optional<McpTool> eval = catalog.evaluateTool();
        if (eval.isEmpty()) return mapper.createObjectNode().put("clicked", false).put("reason", "evaluate-tool-unavailable");
        try {
            String encoded = Base64.getEncoder().encodeToString(selector.getBytes(StandardCharsets.UTF_8));
            String script = """
                (() => {
                  const raw = atob('%s').trim();
                  const norm = value => String(value || '').replace(/\\s+/g, ' ').trim();
                  const visible = element => {
                    if (!element || !(element instanceof Element)) return false;
                    const r = element.getBoundingClientRect();
                    const c = getComputedStyle(element);
                    return r.width > 2 && r.height > 2 && c.display !== 'none' &&
                           c.visibility !== 'hidden' && Number(c.opacity || 1) > 0;
                  };
                  const clickableAncestor = element => {
                    let current = element;
                    for (let depth = 0; current && depth < 7; depth++, current = current.parentElement) {
                      const tag = (current.tagName || '').toLowerCase();
                      const role = (current.getAttribute?.('role') || '').toLowerCase();
                      if (['button','a','input','summary','option','li'].includes(tag) ||
                          ['button','menuitem','option','link','tab'].includes(role) ||
                          current.hasAttribute?.('onclick') || current.tabIndex >= 0) return current;
                    }
                    return element;
                  };
                  const exactText = (() => {
                    let value = raw;
                    const textMatch = raw.match(/^(?:text|has-text)\\s*=\\s*['"]?(.*?)['"]?$/i);
                    if (textMatch) value = textMatch[1];
                    const roleName = raw.match(/name\\s*=\\s*['"](.*?)['"]/i);
                    if (roleName) value = roleName[1];
                    return norm(value.replace(/^['"]|['"]$/g, ''));
                  })();

                  let candidates = [];
                  try {
                    if (raw.startsWith('//')) {
                      const result = document.evaluate(raw, document, null, XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null);
                      for (let i = 0; i < result.snapshotLength; i++) candidates.push(result.snapshotItem(i));
                    } else if (!raw.startsWith('@') && !/^(text|role|has-text)\\s*=/i.test(raw)) {
                      candidates = [...document.querySelectorAll(raw)];
                    }
                  } catch (ignore) { }

                  if (!candidates.some(visible) && exactText) {
                    const all = [...document.querySelectorAll('button,a,[role="menuitem"],[role="option"],[role="button"],li,div,span')];
                    candidates = all.filter(element => {
                      if (!visible(element)) return false;
                      const values = [element.innerText, element.textContent, element.getAttribute('aria-label'),
                                      element.getAttribute('title'), element.getAttribute('data-testid')].map(norm);
                      return values.some(value => value === exactText);
                    });
                    if (!candidates.length) {
                      candidates = all.filter(element => visible(element) &&
                        [element.innerText, element.textContent, element.getAttribute('aria-label'), element.getAttribute('title')]
                          .map(norm).some(value => value && value.toLowerCase().includes(exactText.toLowerCase())));
                    }
                  }

                  candidates = candidates.filter(visible).map(clickableAncestor).filter(visible);
                  candidates = [...new Set(candidates)].sort((a,b) => {
                    const ar=a.getBoundingClientRect(), br=b.getBoundingClientRect();
                    const aExact = norm(a.innerText || a.textContent || a.getAttribute('aria-label')) === exactText ? 0 : 1;
                    const bExact = norm(b.innerText || b.textContent || b.getAttribute('aria-label')) === exactText ? 0 : 1;
                    return aExact-bExact || (ar.width*ar.height)-(br.width*br.height);
                  });
                  let element = candidates[0];
                  if (!element) return JSON.stringify({clicked:false,reason:'no-visible-semantic-match',selector:raw,text:exactText});
                  if (element.disabled || element.getAttribute('aria-disabled') === 'true')
                    return JSON.stringify({clicked:false,reason:'disabled'});

                  // Prefer the menu row/container over a nested text span. Many enterprise apps use delegated click handlers on LI.
                  const nestedTextNode = element.matches?.('span,small,strong,em,b') ? element : null;
                  if (nestedTextNode) {
                    const row = nestedTextNode.closest('li,[role="menuitem"],[role="option"],a,button');
                    if (row && visible(row)) element = row;
                  }
                  element.scrollIntoView({block:'center', inline:'center', behavior:'instant'});
                  element.focus?.({preventScroll:true});
                  const r = element.getBoundingClientRect();
                  const points = [[.5,.5],[.25,.5],[.75,.5],[.5,.25],[.5,.75]];
                  let hit = null;
                  for (const [px,py] of points) {
                    const x = Math.max(0, Math.min(innerWidth-1, r.left+r.width*px));
                    const y = Math.max(0, Math.min(innerHeight-1, r.top+r.height*py));
                    const top = document.elementFromPoint(x,y);
                    if (top && (top===element || element.contains(top))) { hit={x,y,top}; break; }
                  }

                  if (!hit) return JSON.stringify({clicked:false,reason:'hit-test-failed',selector:raw,candidateCount:candidates.length});
                  const options = {bubbles:true,cancelable:true,composed:true,view:window,
                                   clientX:hit.x, clientY:hit.y, button:0,buttons:1,
                                   pointerId:1,pointerType:'mouse',isPrimary:true};
                  const dispatchTarget = hit.top && element.contains(hit.top) ? hit.top : element;
                  for (const type of ['pointerover','mouseover','mouseenter','pointermove','mousemove','pointerdown','mousedown','pointerup','mouseup']) {
                    try { dispatchTarget.dispatchEvent(type.startsWith('pointer') ? new PointerEvent(type,options) : new MouseEvent(type,options)); } catch(ignore) { }
                  }
                  // Exactly one click. Multiple click dispatches toggle Angular controls or act on detached nodes.
                  try { dispatchTarget.click?.(); } catch(ignore) {
                    return JSON.stringify({clicked:false,reason:'single-click-threw',selector:raw});
                  }
                  return JSON.stringify({clicked:true,selector:raw,matchedText:norm(element.innerText || element.textContent || element.getAttribute('aria-label')).slice(0,160),
                    tag:element.tagName,role:element.getAttribute('role') || '',hitTestPassed:!!hit,candidateCount:candidates.length});
                })()
                """.formatted(encoded);
            Map<String,Object> evalArgs = new LinkedHashMap<>();
            if (schemaContains(eval.get(), "expression")) evalArgs.put("expression", script);
            else if (schemaContains(eval.get(), "script")) evalArgs.put("script", script);
            else evalArgs.put("code", script);
            return unwrapJsonString(mcp.callTool(eval.get().getName(), evalArgs));
        } catch (Exception e) {
            return mapper.createObjectNode().put("clicked", false).put("reason", e.getMessage());
        }
    }

    private void validateSelectorUniqueness(McpClient mcp, McpToolCatalog catalog, String toolName, Map<String, Object> args) {
        Object raw = args.get("selector");
        if (raw == null) return;
        String selector = String.valueOf(raw).trim();
        if (selector.isBlank() || selector.startsWith("@") || selector.startsWith("text=") || selector.startsWith("role=")) return;
        Optional<McpTool> eval = catalog.evaluateTool();
        if (eval.isEmpty()) return;
        try {
            String encoded = Base64.getEncoder().encodeToString(selector.getBytes(StandardCharsets.UTF_8));
            String script = "(() => {const s=atob('" + encoded + "');let all=[];try{if(s.startsWith('//')){const x=document.evaluate(s,document,null,XPathResult.ORDERED_NODE_SNAPSHOT_TYPE,null);for(let i=0;i<x.snapshotLength;i++)all.push(x.snapshotItem(i));}else all=[...document.querySelectorAll(s)];}catch(e){return JSON.stringify({selector:s,error:e.message,count:0,visible:0});}const vis=all.filter(e=>{try{const r=e.getBoundingClientRect(),c=getComputedStyle(e);return r.width>1&&r.height>1&&c.display!=='none'&&c.visibility!=='hidden'}catch(x){return false}});return JSON.stringify({selector:s,count:all.length,visible:vis.length,tags:vis.slice(0,10).map(e=>({tag:e.tagName,id:e.id||'',text:(e.innerText||e.value||e.getAttribute?.('aria-label')||'').trim().slice(0,80)}))});})()";
            Map<String,Object> evalArgs=new LinkedHashMap<>();
            if(schemaContains(eval.get(),"expression"))evalArgs.put("expression",script);else if(schemaContains(eval.get(),"script"))evalArgs.put("script",script);else evalArgs.put("code",script);
            JsonNode inspected=unwrapJsonString(mcp.callTool(eval.get().getName(),evalArgs));
            int count=inspected.path("count").asInt(-1), visible=inspected.path("visible").asInt(-1);
            if(count==0) throw new IllegalStateException("Selector matched no elements before " + toolName + ": " + selector);
            if(visible==0) throw new IllegalStateException("Selector matched only hidden elements before " + toolName + ": " + selector);
            if(visible>1) throw new IllegalStateException("Ambiguous selector matched " + visible + " visible elements before " + toolName + ": " + selector + ". Candidate evidence=" + compact(inspected.toString(),1200));
        } catch (IllegalStateException e) { throw e; }
        catch (Exception ignored) { }
    }

    private Map<String, Object> normalizeArgsForTool(McpTool tool, JsonNode argsNode) {
        Map<String, Object> args = toMap(argsNode);
        if (args.containsKey("selector") && args.get("selector") instanceof Collection<?> c && !c.isEmpty()) {
            args.put("selector", String.valueOf(c.iterator().next()));
        }
        if (!args.containsKey("selector")) {
            for (String k : List.of("ref", "target", "locator")) {
                if (args.containsKey(k) && schemaContains(tool, "selector")) {
                    args.put("selector", args.get(k));
                    break;
                }
            }
        }
        if (schemaContains(tool, "timeout")) {
            Object timeout = args.get("timeout");
            long value = 0L;
            if (timeout instanceof Number n) value = n.longValue();
            else if (timeout != null) {
                try { value = Long.parseLong(String.valueOf(timeout)); } catch (Exception ignored) { value = 0L; }
            }
            if (value < 1000L) args.put("timeout", 15000);
        }
        return args;
    }

    private String buildAgentPrompt(String instruction, TestScenario scenario, McpToolCatalog catalog, JsonNode observation, String failure) throws Exception {
        StringBuilder sb = new StringBuilder();
        sb.append("You are the execution brain for the ITPS VIBIUM MCP Framework. Plan browser actions using Vibium MCP only.\n");
        sb.append("The browser is already started. Never call browser_start.\n");
        sb.append("Instruction: ").append(instruction).append("\n");
        sb.append("Scenario: ").append(scenario.getId()).append(" - ").append(scenario.getName()).append("\n");
        sb.append("Test data: ").append(mapper.writeValueAsString(scenario.getData())).append("\n");
        sb.append("Selection policy:\n");
        sb.append("- Composite instructions such as hover-and-click MUST be returned as ordered calls: hover/open trigger, wait or fresh observation when available, then click the exact visible menu item. Do not collapse 'New Search' to 'New'.\n");
        sb.append("- A tool call completing is not proof of success. Choose actions that create an observable postcondition in URL, DOM, visible text, form value, menu state, or screenshot.\n");
        sb.append("- Use rankedCandidates first. Each candidate contains a stable candidateId, accessibleName, context, interactiveReason and a unique cssSelector.\n");
        sb.append("- Prefer Vibium @e refs when the map exposes the exact intended element. Otherwise use the candidate cssSelector.\n");
        sb.append("- Never reduce an icon instruction to visible text. Search/filter/calendar/menu icons must be identified by accessibleName, aria, title, test id, SVG metadata, surrounding context or unique position inside the correct container.\n");
        sb.append("- Never choose the first matching element when multiple candidates exist. Use containerContext, selectedValues, nearby text and occurrence evidence.\n");
        sb.append("- For repeated controls, select the element inside the container described by the instruction. Example: the Perimeter control containing BCEF and Monaco, not the first Perimeter control.\n");
        sb.append("- Do not use a generic selector that matches multiple elements. Return a unique selector or a precise @e ref.\n");
        sb.append("- For custom dropdowns, click the correct container/input, then type/fill, wait for options, re-map if required, and click the exact option.\n");
        sb.append("- For click/fill/select, return at least one real action tool. browser_map/browser_wait_for_load alone is not an action.\n");
        sb.append("- Return only minified JSON: {\"calls\":[{\"tool\":\"browser_click\",\"arguments\":{\"selector\":\"#unique-selector\"}}],\"why\":\"candidateId and evidence used\"}.\n");
        sb.append("Available MCP tools:\n").append(catalog.toPromptText()).append("\n");
        sb.append("Current unified page observation. pageModel.actionElements is for actions; pageModel.contentElements/formValues/tables/allVisibleText are for validation and context. rankedCandidates is intent-specific:\n")
                .append(compact(observation == null ? "" : observation.toString(), 60000)).append("\n");
        if (failure != null) sb.append("Previous attempt failed: ").append(failure).append("\nReturn a corrected plan using different evidence.\n");
        return sb.toString();
    }

    private JsonNode safeDomProbe(McpClient mcp, McpToolCatalog catalog) {
        Optional<McpTool> eval = catalog.evaluateTool();
        if (eval.isEmpty()) return mapper.createObjectNode().put("note", "No browser_evaluate/eval MCP tool available");
        String script = """
            (() => {
              const norm = value => (value ?? '').toString().replace(/\\s+/g, ' ').trim();
              const visible = element => {
                try {
                  const rect = element.getBoundingClientRect();
                  const style = getComputedStyle(element);
                  return rect.width > 0 && rect.height > 0 && style.display !== 'none' &&
                         style.visibility !== 'hidden' && style.opacity !== '0' &&
                         rect.bottom >= 0 && rect.right >= 0;
                } catch (_) { return false; }
              };
              const css = element => {
                try {
                  if (element.id) return '#' + CSS.escape(element.id);
                  for (const attr of ['data-testid','data-test','data-cy','name','aria-label']) {
                    const value = element.getAttribute?.(attr);
                    if (value) {
                      const selector = '[' + attr + '=\\"' + CSS.escape(value) + '\\"]';
                      if (document.querySelectorAll(selector).length === 1) return selector;
                    }
                  }
                  const path = [];
                  for (let node = element; node && node.nodeType === 1 && path.length < 10; node = node.parentElement) {
                    let part = node.tagName.toLowerCase();
                    const stableClasses = [...node.classList]
                      .filter(c => c && !/[0-9a-f]{8,}/i.test(c) && c.length < 60).slice(0, 2);
                    if (stableClasses.length) part += '.' + stableClasses.map(CSS.escape).join('.');
                    const siblings = node.parentElement ? [...node.parentElement.children].filter(x => x.tagName === node.tagName) : [];
                    if (siblings.length > 1) part += ':nth-of-type(' + (siblings.indexOf(node) + 1) + ')';
                    path.unshift(part);
                    const candidate = path.join(' > ');
                    try { if (document.querySelectorAll(candidate).length === 1) return candidate; } catch (_) {}
                  }
                  return path.join(' > ');
                } catch (_) { return ''; }
              };
              const accessibleName = element => {
                try {
                  const aria = norm(element.getAttribute?.('aria-label'));
                  if (aria) return aria;
                  const labelledBy = norm(element.getAttribute?.('aria-labelledby'));
                  if (labelledBy) {
                    const value = labelledBy.split(/\\s+/).map(id => {
                      const label = document.getElementById(id);
                      return norm(label?.innerText || label?.textContent);
                    }).filter(Boolean).join(' ');
                    if (value) return value;
                  }
                  if (element.labels?.length) {
                    const value = [...element.labels].map(x => norm(x.innerText || x.textContent)).filter(Boolean).join(' ');
                    if (value) return value;
                  }
                  if (element.id) {
                    const label = document.querySelector('label[for=\\"' + CSS.escape(element.id) + '\\"]');
                    const value = norm(label?.innerText || label?.textContent);
                    if (value) return value;
                  }
                  const wrappingLabel = element.closest?.('label');
                  if (wrappingLabel) return norm(wrappingLabel.innerText || wrappingLabel.textContent);
                  return norm(element.getAttribute?.('alt') || element.getAttribute?.('title') ||
                              element.getAttribute?.('placeholder') || element.value || '');
                } catch (_) { return ''; }
              };
              const directText = element => {
                try {
                  const parts = [];
                  for (const node of element.childNodes || []) {
                    if (node.nodeType === Node.TEXT_NODE) parts.push(node.textContent || '');
                  }
                  return norm(parts.join(' '));
                } catch (_) { return ''; }
              };
              const context = element => {
                const values = [];
                try {
                  let node = element;
                  for (let level = 0; node && level < 5; level++, node = node.parentElement) {
                    const heading = node.querySelector?.(':scope > label,:scope > legend,:scope > h1,:scope > h2,:scope > h3,:scope > h4,:scope > h5,:scope > [class*=label],:scope > [class*=title],:scope > [class*=header]');
                    const headingText = norm(heading?.innerText || heading?.textContent);
                    if (headingText && headingText.length < 220) values.push(headingText);
                    const own = norm(node.getAttribute?.('aria-label') || node.getAttribute?.('title'));
                    if (own) values.push(own);
                  }
                } catch (_) {}
                return [...new Set(values)].slice(0, 8).join(' | ');
              };
              const isInteractive = element => {
                const tag = (element.tagName || '').toLowerCase();
                const role = norm(element.getAttribute?.('role')).toLowerCase();
                let cursor = '';
                try { cursor = getComputedStyle(element).cursor; } catch (_) {}
                return ['button','input','select','textarea','a','summary','option'].includes(tag) ||
                  ['button','link','tab','menuitem','checkbox','radio','combobox','option','switch','textbox','searchbox','slider'].includes(role) ||
                  element.hasAttribute?.('onclick') || element.tabIndex >= 0 || element.isContentEditable ||
                  cursor === 'pointer' || element.hasAttribute?.('data-testid') || element.hasAttribute?.('data-test') ||
                  element.hasAttribute?.('aria-label');
              };
              const interactiveReason = element => {
                const values = [];
                const tag = (element.tagName || '').toLowerCase();
                const role = norm(element.getAttribute?.('role'));
                if (['button','input','select','textarea','a','summary','option'].includes(tag)) values.push(tag);
                if (role) values.push('role=' + role);
                if (element.hasAttribute?.('onclick')) values.push('onclick');
                if (element.tabIndex >= 0) values.push('tabindex');
                try { if (getComputedStyle(element).cursor === 'pointer') values.push('cursor:pointer'); } catch (_) {}
                if (element.isContentEditable) values.push('contenteditable');
                if (tag === 'svg' || tag === 'path' || element.closest?.('svg')) values.push('icon/svg');
                return values.join(',');
              };
              const selectedValues = element => {
                try {
                  const values = [];
                  if (element.tagName === 'SELECT') {
                    values.push(...[...element.selectedOptions].map(x => norm(x.textContent || x.value)));
                  }
                  values.push(...[...element.querySelectorAll?.('[class*=chip],[class*=tag],[class*=token],[role=option][aria-selected=true],[aria-checked=true]') || []]
                    .map(x => norm(x.innerText || x.textContent || x.getAttribute?.('aria-label'))));
                  return [...new Set(values.filter(Boolean))].slice(0, 50);
                } catch (_) { return []; }
              };
              const actionElements = [];
              const contentElements = [];
              const formValues = [];
              const tables = [];
              const frames = [];
              const seenAction = new Set();
              const seenContent = new Set();
              let actionSeq = 0, contentSeq = 0;

              const baseRecord = (element, scope) => {
                const rect = element.getBoundingClientRect();
                const tag = (element.tagName || '').toLowerCase();
                const text = norm(element.innerText || element.textContent).slice(0, 1200);
                const ownText = directText(element).slice(0, 500);
                const value = norm(element.value).slice(0, 500);
                return {
                  scope, tag, role: norm(element.getAttribute?.('role')), type: norm(element.getAttribute?.('type')),
                  accessibleName: accessibleName(element).slice(0, 500), text, ownText,
                  context: context(element), id: element.id || '', name: norm(element.getAttribute?.('name')),
                  placeholder: norm(element.getAttribute?.('placeholder')), ariaLabel: norm(element.getAttribute?.('aria-label')),
                  title: norm(element.getAttribute?.('title')),
                  testId: norm(element.getAttribute?.('data-testid') || element.getAttribute?.('data-test') || element.getAttribute?.('data-cy')),
                  value, selectedValues: selectedValues(element), checked: !!element.checked, disabled: !!element.disabled,
                  cssSelector: css(element), rect: {x: Math.round(rect.x), y: Math.round(rect.y), w: Math.round(rect.width), h: Math.round(rect.height)},
                  viewport: {w: innerWidth, h: innerHeight}
                };
              };

              const addAction = (element, scope) => {
                if (!visible(element) || !isInteractive(element) || seenAction.has(element)) return;
                seenAction.add(element);
                const record = baseRecord(element, scope);
                record.candidateId = 'action-' + (++actionSeq);
                record.kind = 'ACTION';
                record.interactiveReason = interactiveReason(element);
                actionElements.push(record);
              };

              const addContent = (element, scope) => {
                if (!visible(element) || seenContent.has(element)) return;
                const tag = (element.tagName || '').toLowerCase();
                if (['script','style','noscript','template','meta','link','path'].includes(tag)) return;
                const record = baseRecord(element, scope);
                const meaningful = record.ownText || record.accessibleName || record.value || record.selectedValues.length;
                const semantic = ['h1','h2','h3','h4','h5','h6','p','span','label','legend','li','td','th','dt','dd','strong','small','em','b','output','option','caption','div'].includes(tag);
                const childVisibleTextElements = [...(element.children || [])].filter(child => visible(child) && norm(child.innerText || child.textContent));
                const leafLike = childVisibleTextElements.length === 0 || !!record.ownText || ['td','th','label','option','output'].includes(tag);
                if (!meaningful || (!semantic && !leafLike)) return;
                if (!leafLike && record.text.length > 600) return; // avoid giant page containers
                seenContent.add(element);
                record.contentId = 'content-' + (++contentSeq);
                record.kind = 'CONTENT';
                record.text = (record.ownText || record.text).slice(0, 600);
                contentElements.push(record);
              };

              const addFormValue = (element, scope) => {
                const tag = (element.tagName || '').toLowerCase();
                if (!visible(element) || !['input','select','textarea','output'].includes(tag)) return;
                const record = baseRecord(element, scope);
                record.kind = 'FORM_VALUE';
                formValues.push(record);
              };

              const addTable = (table, scope) => {
                if (!visible(table)) return;
                try {
                  const rows = [...table.querySelectorAll('tr')].slice(0, 300).map(row =>
                    [...row.querySelectorAll(':scope > th,:scope > td')].map(cell => norm(cell.innerText || cell.textContent))
                  ).filter(row => row.some(Boolean));
                  tables.push({scope, selector: css(table), caption: norm(table.caption?.innerText || table.caption?.textContent), rows});
                } catch (_) {}
              };

              const walk = (root, scope) => {
                let elements = [];
                try { elements = [...root.querySelectorAll('*')]; } catch (_) {}
                for (const element of elements) {
                  addAction(element, scope);
                  addContent(element, scope);
                  addFormValue(element, scope);
                  if (element.tagName === 'TABLE') addTable(element, scope);
                  if (element.shadowRoot) walk(element.shadowRoot, scope + ' > shadow(' + (element.id || element.tagName || 'host') + ')');
                  if (element.tagName === 'IFRAME') {
                    try {
                      if (element.contentDocument) walk(element.contentDocument, scope + ' > iframe(' + (element.name || element.id || 'same-origin') + ')');
                    } catch (_) {
                      frames.push({scope, selector: css(element), type: 'cross-origin'});
                    }
                  }
                }
              };

              walk(document, 'document');
              const allVisibleText = [...new Set(contentElements.map(x => x.text).filter(Boolean))].join(' \\n ').slice(0, 250000);
              return JSON.stringify({
                version: 3,
                counts: {action: actionElements.length, content: contentElements.length, formValues: formValues.length, tables: tables.length},
                actionElements: actionElements.slice(0, 6000),
                contentElements: contentElements.slice(0, 12000),
                formValues: formValues.slice(0, 4000),
                tables: tables.slice(0, 500),
                frames,
                allVisibleText,
                truncated: actionElements.length > 6000 || contentElements.length > 12000
              });
            })()
            """;
        Map<String, Object> args = new LinkedHashMap<>();
        if (schemaContains(eval.get(), "expression")) args.put("expression", script);
        else if (schemaContains(eval.get(), "script")) args.put("script", script);
        else args.put("code", script);
        JsonNode raw = safeToolResult(mcp, eval, args);
        return unwrapJsonString(raw);
    }

    private JsonNode unwrapJsonString(JsonNode raw) {
        if (raw == null) return mapper.createObjectNode().put("error", "empty DOM probe result");
        List<String> texts = new ArrayList<>();
        collectTextValues(raw, texts);
        texts.sort(Comparator.comparingInt(String::length).reversed());
        for (String text : texts) {
            String t = text == null ? "" : text.trim();
            if (!(t.startsWith("{") || t.startsWith("["))) continue;
            try { return mapper.readTree(t); } catch (Exception ignored) {}
        }
        return raw;
    }

    private void collectTextValues(JsonNode node, List<String> out) {
        if (node == null) return;
        if (node.isTextual()) { out.add(node.asText()); return; }
        if (node.isArray()) for (JsonNode c : node) collectTextValues(c, out);
        else if (node.isObject()) node.fields().forEachRemaining(e -> collectTextValues(e.getValue(), out));
    }

    private ArrayNode rankCandidates(JsonNode observation, String instruction, int limit) {
        ArrayNode ranked = mapper.createArrayNode();
        String intent = expectedIntent(instruction);
        List<JsonNode> elements = collectCandidateElements(observation, intent);
        Set<String> tokens = instructionTokens(instruction);
        List<Map.Entry<Integer, JsonNode>> scored = new ArrayList<>();
        for (JsonNode element : elements) {
            int score = candidateScore(element, tokens, instruction);
            if (score > 0) scored.add(Map.entry(score, element));
        }
        scored.sort((a, b) -> Integer.compare(b.getKey(), a.getKey()));
        for (int i = 0; i < Math.min(limit, scored.size()); i++) {
            ObjectNode copy = scored.get(i).getValue().deepCopy();
            copy.put("matchScore", scored.get(i).getKey());
            ranked.add(copy);
        }
        return ranked;
    }

    private List<JsonNode> collectCandidateElements(JsonNode observation, String intent) {
        List<JsonNode> out = new ArrayList<>();
        JsonNode model = observation == null ? null : observation.path("pageModel");
        if (model == null || model.isMissingNode()) return out;
        if ("ASSERT".equals(intent)) {
            appendArray(out, model.path("contentElements"));
            appendArray(out, model.path("formValues"));
            // Action elements may also expose status text through accessible names.
            appendArray(out, model.path("actionElements"));
        } else {
            appendArray(out, model.path("actionElements"));
            // Content elements provide parent/nearby context for unlabeled controls.
            appendArray(out, model.path("contentElements"));
        }
        return out;
    }

    private void appendArray(List<JsonNode> target, JsonNode array) {
        if (array != null && array.isArray()) array.forEach(target::add);
    }

    private Set<String> instructionTokens(String instruction) {
        Set<String> stop = Set.of("click","select","type","enter","fill","the","a","an","in","on","from","to","and","button","icon","field","dropdown","element","with","of","is","that","same");
        Set<String> out = new LinkedHashSet<>();
        for (String t : (instruction == null ? "" : instruction.toLowerCase(Locale.ROOT)).split("[^a-z0-9_-]+")) if (t.length()>1 && !stop.contains(t)) out.add(t);
        return out;
    }

    private int candidateScore(JsonNode element, Set<String> tokens, String instruction) {
        String name = element.path("accessibleName").asText("").toLowerCase(Locale.ROOT);
        String text = element.path("text").asText("").toLowerCase(Locale.ROOT);
        String ownText = element.path("ownText").asText("").toLowerCase(Locale.ROOT);
        String context = element.path("context").asText("").toLowerCase(Locale.ROOT);
        String attrs = (element.path("id").asText("") + " " + element.path("name").asText("") + " " +
                element.path("ariaLabel").asText("") + " " + element.path("title").asText("") + " " +
                element.path("testId").asText("") + " " + element.path("placeholder").asText("") + " " +
                element.path("value").asText("")).toLowerCase(Locale.ROOT);
        String lower = instruction == null ? "" : instruction.toLowerCase(Locale.ROOT);
        String intent = expectedIntent(instruction);
        int score = 0;
        for (String token : tokens) {
            if (name.equals(token)) score += 55; else if (name.contains(token)) score += 28;
            if (ownText.equals(token)) score += 60; else if (ownText.contains(token)) score += 32;
            if (attrs.contains(token)) score += 24;
            if (text.equals(token)) score += 50; else if (text.contains(token)) score += 18;
            if (context.contains(token)) score += 20;
            if (element.path("selectedValues").toString().toLowerCase(Locale.ROOT).contains(token)) score += 35;
        }
        String kind = element.path("kind").asText("");
        if ("ASSERT".equals(intent)) {
            if ("CONTENT".equals(kind) || "FORM_VALUE".equals(kind)) score += 30;
            if (!text.isBlank() && lower.contains(text)) score += 45;
        } else if ("ACTION".equals(kind)) {
            score += 22;
        }
        String reason = element.path("interactiveReason").asText("").toLowerCase(Locale.ROOT);
        if (lower.contains("icon") && reason.contains("icon")) score += 25;
        if ((lower.contains("dropdown") || lower.contains("drop down")) &&
                (reason.contains("select") || "combobox".equalsIgnoreCase(element.path("role").asText()))) score += 25;
        if (lower.contains("status") && (context.contains("status") || text.contains("status"))) score += 18;
        if (element.path("disabled").asBoolean(false) && !"ASSERT".equals(intent)) score -= 100;
        return score;
    }

    private void writeElementInventory(Path runDir, String scenarioId, int stepNo, JsonNode observation) {
        if (observation == null) return;
        try {
            Path dir = runDir.resolve("elements");
            Files.createDirectories(dir);
            String safe = (scenarioId == null ? "scenario" : scenarioId).replaceAll("[^a-zA-Z0-9._-]", "_");
            mapper.writerWithDefaultPrettyPrinter().writeValue(dir.resolve(safe + "_step_" + stepNo + "_elements.json").toFile(), observation);
        } catch (Exception ignored) {}
    }

    private JsonNode safeMap(McpClient mcp, McpToolCatalog catalog) {
        Optional<McpTool> mapTool = catalog.mapTool();
        if (mapTool.isEmpty()) return mapper.createObjectNode().put("note", "No browser_map/snapshot tool available");
        Map<String, Object> args = new LinkedHashMap<>();
        if (schemaContains(mapTool.get(), "selector")) args.put("selector", "body");
        return safeToolResult(mcp, mapTool, args);
    }

    private JsonNode safeToolResult(McpClient mcp, Optional<McpTool> tool, Map<String, Object> args) {
        try {
            if (tool.isEmpty()) return mapper.createObjectNode().put("note", "tool not available");
            return mcp.callTool(tool.get().getName(), args == null ? Map.of() : args);
        } catch (Exception e) {
            return mapper.createObjectNode().put("error", e.getMessage());
        }
    }

    private String pageFingerprint(McpClient mcp, McpToolCatalog catalog) {
        return fingerprintFromObservation(observePage(mcp, catalog));
    }

    private String fingerprintFromObservation(JsonNode observation) {
        String text = compact(extractText(observation), 50000);
        return Integer.toHexString(Objects.hash(text));
    }

    private boolean screenshotsDifferent(Path screenshotDir, String before, String after) {
        if (!notBlank(before) || !notBlank(after)) return false;
        try {
            Path b = screenshotDir.resolve(before);
            Path a = screenshotDir.resolve(after);
            if (!Files.exists(b) || !Files.exists(a)) return false;
            byte[] bb = Files.readAllBytes(b);
            byte[] aa = Files.readAllBytes(a);
            return !Arrays.equals(bb, aa);
        } catch (Exception e) { return false; }
    }

    private AssertionEvidence assertInstructionWithRetry(McpClient mcp, McpToolCatalog catalog, String instruction,
                                                        JsonNode initialObservation, int attempts, long delayMs) {
        JsonNode observation = initialObservation;
        IllegalStateException last = null;
        for (int attempt = 1; attempt <= Math.max(1, attempts); attempt++) {
            try {
                return assertInstruction(instruction, observation);
            } catch (IllegalStateException e) {
                last = e;
                if (attempt < attempts) {
                    sleep(delayMs);
                    observation = observePage(mcp, catalog);
                }
            }
        }
        throw last == null ? new IllegalStateException("Assertion failed without diagnostic evidence") : last;
    }

    private AssertionEvidence assertInstruction(String instruction, JsonNode observation) {
        String normalizedInstruction = instruction == null ? "" : instruction.trim();
        String expected = normalizedInstruction.replaceFirst("(?i)^(verify|assert|check)\s+", "").trim();
        boolean negative = expected.matches("(?i).*(is not|not displayed|not visible|not present|does not contain|should not).*?");

        // Natural-language assertion suffixes are instructions, not part of expected text.
        // Examples: "Verify Message text available" -> "Message" and
        // "Verify Payment is visible" -> "Payment".
        expected = expected
                .replaceFirst("(?i)\s+(?:text|label|value|content)\s+(?:is\s+)?(?:available|displayed|visible|present|shown).*$", "")
                .replaceFirst("(?i)\s+(?:is|should be)\s+(?:available|displayed|visible|present|shown).*$", "")
                .trim();
        if (expected.isBlank()) return new AssertionEvidence("NO_EXPECTATION", "", "");

        JsonNode model = observation == null ? null : observation.path("pageModel");
        List<JsonNode> content = new ArrayList<>();
        if (model != null && !model.isMissingNode()) {
            appendArray(content, model.path("contentElements"));
            appendArray(content, model.path("formValues"));
            appendArray(content, model.path("actionElements"));
        }

        String expectedLower = normalizeAssertionText(expected);
        String allVisibleRaw = model == null ? "" : model.path("allVisibleText").asText("");
        String allVisible = normalizeAssertionText(allVisibleRaw);
        boolean found = containsTextTokenAware(allVisible, expectedLower);
        String matchedText = found ? bestVisibleMatch(allVisibleRaw, expected) : "";
        String strategy = found ? "DOM_ALL_VISIBLE_TEXT" : "";

        Matcher pair = Pattern.compile("(?i)^(.+?)\s+(?:is|equals|=|should be)\s+(.+)$").matcher(expected);
        if (pair.matches()) {
            String label = normalizeAssertionText(pair.group(1));
            String value = normalizeAssertionText(pair.group(2));
            found = false;
            for (JsonNode element : content) {
                String text = searchableElementText(element);
                String context = normalizeAssertionText(element.path("context").asText(""));
                String name = normalizeAssertionText(element.path("accessibleName").asText(""));
                if ((containsTextTokenAware(text, value) || containsTextTokenAware(normalizeAssertionText(element.path("value").asText("")), value)) &&
                        (containsTextTokenAware(text, label) || containsTextTokenAware(context, label) || containsTextTokenAware(name, label))) {
                    found = true;
                    matchedText = compact(searchableElementText(element), 500);
                    strategy = "DOM_LABEL_VALUE_RELATION";
                    break;
                }
            }
        } else if (!found) {
            for (JsonNode element : content) {
                String searchable = searchableElementText(element);
                if (containsTextTokenAware(searchable, expectedLower)) {
                    found = true;
                    matchedText = compact(searchable, 500);
                    strategy = "DOM_VISIBLE_ELEMENT_TEXT";
                    break;
                }
            }
        }

        if (negative ? found : !found) {
            throw new IllegalStateException("Assertion failed. Expected " + (negative ? "absence of visible text: " : "visible text containing: ") + expected +
                    ". Page model counts=" + (model == null ? "unavailable" : model.path("counts").toString()) +
                    ". Visible text sample='" + compact(allVisibleRaw, 1200) + "'.");
        }
        return new AssertionEvidence(strategy.isBlank() ? "DOM_ASSERTION" : strategy, expected,
                matchedText.isBlank() ? expected : matchedText);
    }

    private String normalizeAssertionText(String value) {
        return value == null ? "" : value.toLowerCase(Locale.ROOT).replaceAll("[^\\p{L}\\p{N}]+", " ").replaceAll("\\s+", " ").trim();
    }

    private boolean containsTextTokenAware(String haystack, String needle) {
        if (needle == null || needle.isBlank()) return true;
        if (haystack == null || haystack.isBlank()) return false;
        if (haystack.contains(needle)) return true;
        String[] tokens = needle.split("\s+");
        for (String token : tokens) if (!haystack.contains(token)) return false;
        return true;
    }

    private String bestVisibleMatch(String allVisibleText, String expected) {
        if (allVisibleText == null || allVisibleText.isBlank()) return expected;
        for (String line : allVisibleText.split("\\R")) {
            if (normalizeAssertionText(line).contains(normalizeAssertionText(expected))) return compact(line.trim(), 500);
        }
        return expected;
    }

    private record AssertionEvidence(String strategy, String expected, String matchedText) {}

    private String searchableElementText(JsonNode element) {
        return (element.path("accessibleName").asText("") + " " + element.path("text").asText("") + " " +
                element.path("ownText").asText("") + " " + element.path("value").asText("") + " " +
                element.path("context").asText("") + " " + element.path("selectedValues").toString())
                .toLowerCase(Locale.ROOT).replaceAll("\\s+", " ").trim();
    }

    private void assertMcpToolSuccess(String toolName, JsonNode result) {
        if (result == null || result.isMissingNode()) return;
        if (result.path("isError").asBoolean(false)) throw new IllegalStateException("MCP tool returned isError=true for " + toolName + ": " + compact(result.toString(), 2000));
        String text = extractText(result).toLowerCase(Locale.ROOT);
        String[] fatal = {"element not found", "not found", "timeout", "timed out", "failed", "error:", "exception", "unable to", "cannot", "invalid selector"};
        for (String f : fatal) if (text.contains(f)) throw new IllegalStateException("MCP tool result indicates failure for " + toolName + ": " + compact(text, 2000));
    }

    private boolean isCustomDropdownSelection(String instruction) {
        if (instruction == null) return false;
        String lower = instruction.toLowerCase(Locale.ROOT);
        return (lower.contains("select") || lower.contains("choose"))
                && (lower.contains("perimeter") || lower.contains("dropdown") || lower.contains("drop down"))
                && extractQuotedOrSelectionValue(instruction) != null;
    }

    private String extractQuotedOrSelectionValue(String instruction) {
        if (instruction == null) return null;
        Matcher quoted = Pattern.compile("[\\\"']([^\\\"']+)[\\\"']").matcher(instruction);
        if (quoted.find()) return quoted.group(1).trim();
        Matcher from = Pattern.compile("(?i)(?:select|choose)\\s+([A-Za-z0-9._/-]+)\\s+(?:from|in)\\s+").matcher(instruction);
        if (from.find()) return from.group(1).trim();
        return null;
    }

    private String extractDropdownLabel(String instruction) {
        if (instruction == null) return "Perimeter";
        Matcher from = Pattern.compile("(?i)(?:from|in)\\s+(?:the\\s+)?(?:field\\s+)?[\\\"']?([A-Za-z][A-Za-z0-9 _/-]{1,50})[\\\"']?(?:\\s+(?:dropdown|drop down|field))?\\s*$").matcher(instruction.trim());
        if (from.find()) return from.group(1).trim();
        return instruction.toLowerCase(Locale.ROOT).contains("perimeter") ? "Perimeter" : "";
    }

    private boolean isFirstRowActionAreaClick(String instruction) {
        if (instruction == null) return false;
        String lower = instruction.toLowerCase(Locale.ROOT);
        boolean firstRow = lower.contains("first row") || lower.contains("first visible data row") || lower.contains("row 1");
        boolean actionArea = lower.contains("white stripe") || lower.contains("action stripe") || lower.contains("action area")
                || lower.contains("row stripe") || lower.contains("menu trigger") || lower.contains("context menu trigger");
        return firstRow && actionArea && containsAny(lower, "click", "tap", "open");
    }


    /**
     * Extracts an optional user XPath from a plain-English step.
     *
     * Supported examples:
     *   Click Perimeter using xpath "//*[@id='entityCode']//input"
     *   Click Perimeter following xpath "//*[@id='entityCode']//input"
     *   Click Perimeter [xpath=//*[@id='entityCode']//input]
     *   Click Perimeter xpath=//*[@id='entityCode']//input
     *
     * This intentionally avoids a large regex because XPath commonly contains quotes,
     * brackets, parentheses and pipes. The English part continues to define the action;
     * the supplied XPath only becomes the highest-priority locator.
     */
    private String extractXPathFromStep(String instruction) {
        if (instruction == null || instruction.isBlank()) return "";
        String text = LiveXPathActionExecutor.normalizeSmartQuotes(instruction).trim();
        String lower = text.toLowerCase(Locale.ROOT);

        int marker = -1;
        int valueStart = -1;
        for (String token : List.of("[xpath=", "xpath=", "xpath:", "using xpath", "following xpath")) {
            int i = lower.indexOf(token);
            if (i >= 0 && (marker < 0 || i < marker)) {
                marker = i;
                valueStart = i + token.length();
            }
        }
        if (marker < 0) return "";

        while (valueStart < text.length() && Character.isWhitespace(text.charAt(valueStart))) valueStart++;
        if (valueStart >= text.length()) return "";

        char first = text.charAt(valueStart);
        if (first == '\"' || first == '\'') {
            int close = findClosingQuote(text, valueStart + 1, first);
            return close > valueStart ? text.substring(valueStart + 1, close).trim() : "";
        }

        // Bracket metadata: [xpath=...]
        if (text.charAt(marker) == '[') {
            int close = text.lastIndexOf(']');
            if (close > valueStart) return text.substring(valueStart, close).trim();
        }

        // Unquoted XPath consumes the remainder of this atomic step.
        return text.substring(valueStart).trim();
    }

    private int findClosingQuote(String text, int start, char quote) {
        for (int i = start; i < text.length(); i++) {
            if (text.charAt(i) == quote && (i == 0 || text.charAt(i - 1) != '\\')) return i;
        }
        return -1;
    }

    private String removeXPathClause(String instruction) {
        if (instruction == null || instruction.isBlank()) return "";
        String normalized = LiveXPathActionExecutor.normalizeSmartQuotes(instruction);
        String lower = normalized.toLowerCase(Locale.ROOT);
        int marker = -1;
        for (String token : List.of("[xpath=", "xpath=", "xpath:", "using xpath", "following xpath")) {
            int i = lower.indexOf(token);
            if (i >= 0 && (marker < 0 || i < marker)) marker = i;
        }
        return marker < 0 ? normalized.trim() : normalized.substring(0, marker).trim();
    }

    /** Extracts CSS metadata from recorder-generated or manually authored steps. */
    private String extractCssFromStep(String instruction) {
        if (instruction == null || instruction.isBlank()) return "";
        String text = LiveXPathActionExecutor.normalizeSmartQuotes(instruction).trim();
        String lower = text.toLowerCase(Locale.ROOT);
        int marker = -1;
        int valueStart = -1;
        for (String token : List.of("[css=", "css=", "css:", "using css", "following css")) {
            int i = lower.indexOf(token);
            if (i >= 0 && (marker < 0 || i < marker)) { marker = i; valueStart = i + token.length(); }
        }
        if (marker < 0) return "";
        while (valueStart < text.length() && Character.isWhitespace(text.charAt(valueStart))) valueStart++;
        if (valueStart >= text.length()) return "";
        char first = text.charAt(valueStart);
        if (first == '"' || first == '\'') {
            int close = findClosingQuote(text, valueStart + 1, first);
            return close > valueStart ? text.substring(valueStart + 1, close).trim() : "";
        }
        if (text.charAt(marker) == '[') {
            int close = text.lastIndexOf(']');
            if (close > valueStart) return text.substring(valueStart, close).trim();
        }
        return text.substring(valueStart).trim();
    }

    private String removeCssClause(String instruction) {
        if (instruction == null || instruction.isBlank()) return "";
        String normalized = LiveXPathActionExecutor.normalizeSmartQuotes(instruction);
        String lower = normalized.toLowerCase(Locale.ROOT);
        int marker = -1;
        for (String token : List.of("[css=", "css=", "css:", "using css", "following css")) {
            int i = lower.indexOf(token);
            if (i >= 0 && (marker < 0 || i < marker)) marker = i;
        }
        return marker < 0 ? normalized.trim() : normalized.substring(0, marker).trim();
    }

    private JsonNode directXPathPlan(McpToolCatalog catalog, String instruction, String xpath) {
        McpTool eval = catalog.evaluateTool().orElse(null);
        if (eval == null) {
            // Compatibility fallback for Vibium versions without browser_evaluate.
            McpTool tool;
            String englishInstruction = removeXPathClause(instruction);
            String lower = englishInstruction.toLowerCase(Locale.ROOT);
            if (containsAny(lower, "type", "enter", "fill")) {
                tool = catalog.fillTool().orElseThrow(() -> new IllegalArgumentException("No fill MCP tool found"));
            } else {
                tool = catalog.clickTool().orElseThrow(() -> new IllegalArgumentException("No click MCP tool found"));
            }
            Map<String,Object> args = new LinkedHashMap<>();
            args.put("selector", xpath);
            if (tool == catalog.fillTool().orElse(null)) {
                String value = Optional.ofNullable(extractQuotedOrSelectionValue(englishInstruction)).orElse("");
                args.put("text", value);
            }
            ObjectNode plan = mapper.createObjectNode();
            plan.putArray("calls").add(simpleCall(tool.getName(), args));
            return plan;
        }

        String englishInstruction = removeXPathClause(instruction);
        String lower = englishInstruction.toLowerCase(Locale.ROOT);
        String action = isAssert(expectedIntent(englishInstruction)) ? "verify"
                : containsAny(lower, "select", "choose", "pick") ? "select"
                : containsAny(lower, "type", "enter", "fill") ? "fill"
                : "click";
        String value = Optional.ofNullable(extractQuotedOrSelectionValue(englishInstruction)).orElse("");

        // For normal XPath click/fill actions, prefer Vibium's native pointer/keyboard implementation.
        // browser_evaluate remains the deterministic path for verification and complex state handling.
        if ("click".equals(action) && catalog.clickTool().isPresent()) {
            McpTool click = catalog.clickTool().get();
            Map<String,Object> args = new LinkedHashMap<>();
            args.put(schemaContains(click, "selector") ? "selector" : "target", xpath);
            if (schemaContains(click, "timeout")) args.put("timeout", 15000);
            ObjectNode plan = mapper.createObjectNode();
            plan.putArray("calls").add(simpleCall(click.getName(), args));
            return plan;
        }
        if ("fill".equals(action) && catalog.fillTool().isPresent()) {
            McpTool fill = catalog.fillTool().get();
            Map<String,Object> args = new LinkedHashMap<>();
            args.put(schemaContains(fill, "selector") ? "selector" : "target", xpath);
            if (schemaContains(fill, "text")) args.put("text", value);
            else if (schemaContains(fill, "value")) args.put("value", value);
            else args.put("text", value);
            if (schemaContains(fill, "timeout")) args.put("timeout", 15000);
            ObjectNode plan = mapper.createObjectNode();
            plan.putArray("calls").add(simpleCall(fill.getName(), args));
            return plan;
        }

        String script = """
            (async () => {
              const xpath = %s;
              const action = %s;
              const value = %s;
              const norm = v => (v || '').replace(/\\s+/g, ' ').trim().toLowerCase();
              const visible = e => {
                if (!e || !(e instanceof Element)) return false;
                const r=e.getBoundingClientRect(), s=getComputedStyle(e);
                return r.width>0 && r.height>0 && s.display!=='none' && s.visibility!=='hidden' && Number(s.opacity||1)>0;
              };
              const snapshot = document.evaluate(xpath, document, null, XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null);
              const matches=[];
              for(let i=0;i<snapshot.snapshotLength;i++) matches.push(snapshot.snapshotItem(i));
              const target = matches.find(visible);
              if (!target) throw new Error('USER_XPATH_NOT_FOUND_OR_NOT_VISIBLE: '+xpath+'; matches='+matches.length);
              target.scrollIntoView({block:'center',inline:'nearest'});

              const fireClick = e => {
                const r=e.getBoundingClientRect(), x=r.left+r.width/2, y=r.top+r.height/2;
                for(const t of ['pointerover','mouseover','mouseenter','pointerdown','mousedown','pointerup','mouseup']) {
                  e.dispatchEvent(new MouseEvent(t,{bubbles:true,cancelable:true,view:window,clientX:x,clientY:y}));
                }
                if (typeof e.click==='function') e.click();
              };

              if (action === 'verify') {
                return JSON.stringify({ok:true,locatorSource:'USER_XPATH',xpathResult:'success',matched:matches.length,chosen:'first-visible',tag:target.tagName});
              }

              if (action === 'fill') {
                const current = 'value' in target ? String(target.value || '') : String(target.textContent || '');
                if (norm(current) === norm(value)) {
                  return JSON.stringify({ok:true,locatorSource:'USER_XPATH',xpathResult:'success',action:'fill',value,currentValue:current,alreadySatisfied:true});
                }
                target.focus();
                const setter=Object.getOwnPropertyDescriptor(Object.getPrototypeOf(target),'value')?.set;
                if(setter) setter.call(target,value); else target.value=value;
                target.dispatchEvent(new Event('input',{bubbles:true}));
                target.dispatchEvent(new Event('change',{bubbles:true}));
                return JSON.stringify({ok:true,locatorSource:'USER_XPATH',xpathResult:'success',action:'fill',value});
              }

              if (action === 'select') {
                const current = 'value' in target ? String(target.value || '') : String(target.textContent || '');
                const containerText = String((target.closest('ng-select,.ng-select,[role=combobox],.form-group,[class*=field]') || target).textContent || '');
                if (norm(current) === norm(value) || norm(containerText).split(' ').includes(norm(value))) {
                  return JSON.stringify({ok:true,locatorSource:'USER_XPATH',xpathResult:'success',action:'select',value,currentValue:current || containerText,alreadySatisfied:true});
                }
              }

              fireClick(target);

              if (action === 'select') {
                await new Promise(r=>setTimeout(r,350));
                const options=[...document.querySelectorAll('[role=option],.ng-option,mat-option,option,li,[class*=option]')].filter(visible);
                const option=options.find(e=>norm(e.textContent)===norm(value)) || options.find(e=>norm(e.textContent).includes(norm(value)));
                if(!option) throw new Error('USER_XPATH_FIELD_FOUND_BUT_OPTION_NOT_FOUND: '+value);
                fireClick(option);
                await new Promise(r=>setTimeout(r,250));
                return JSON.stringify({ok:true,locatorSource:'USER_XPATH',xpathResult:'success',action:'select',value,optionText:(option.textContent||'').trim()});
              }

              return JSON.stringify({ok:true,locatorSource:'USER_XPATH',xpathResult:'success',action:'click',matched:matches.length,chosen:'first-visible'});
            })()
            """.formatted(jsString(xpath), jsString(action), jsString(value));

        ObjectNode plan = mapper.createObjectNode();
        plan.putArray("calls").add(simpleCall(eval.getName(), Map.of("script", script)));
        return plan;
    }

    private JsonNode directCustomDropdownPlan(McpToolCatalog catalog, String instruction) {
        McpTool eval = catalog.evaluateTool().orElseThrow(() -> new IllegalArgumentException("Vibium MCP does not expose browser_evaluate, which is required for custom Angular dropdown selection."));
        String label = Optional.ofNullable(extractDropdownLabel(instruction)).orElse("Perimeter");
        String value = Optional.ofNullable(extractQuotedOrSelectionValue(instruction)).orElseThrow(() -> new IllegalArgumentException("Unable to extract dropdown value from step: " + instruction));
        String script = """
            (async () => {
              const wantedLabel = %s;
              const wantedValue = %s;
              const norm = v => (v || '').replace(/\\s+/g, ' ').trim().toLowerCase();
              const visible = e => {
                if (!e) return false;
                const r = e.getBoundingClientRect();
                const s = getComputedStyle(e);
                return r.width > 1 && r.height > 1 && s.display !== 'none' && s.visibility !== 'hidden' && Number(s.opacity || 1) > 0;
              };
              const clickLikeUser = e => {
                e.scrollIntoView({block:'center', inline:'nearest'});
                const r=e.getBoundingClientRect(), x=r.left+r.width/2, y=r.top+r.height/2;
                for (const t of ['pointerover','mouseover','mouseenter','pointerdown','mousedown','pointerup','mouseup']) {
                  e.dispatchEvent(new MouseEvent(t,{bubbles:true,cancelable:true,view:window,clientX:x,clientY:y}));
                }
                if (typeof e.click === 'function') e.click();
              };
              const all = [...document.querySelectorAll('label, .form-label, [class*=label], span, div')].filter(visible);
              const labelNode = all.find(e => norm(e.textContent) === norm(wantedLabel));
              let scope = labelNode ? (labelNode.closest('.form-group,.row,[class*=field],[class*=form],div') || labelNode.parentElement) : document;
              let select = null;
              for (let i=0; i<6 && scope && !select; i++, scope=scope.parentElement) {
                select = scope.querySelector('ng-select,.ng-select,[role=combobox],select');
              }
              if (!select) {
                const candidates=[...document.querySelectorAll('ng-select,.ng-select,[role=combobox],select')].filter(visible);
                select=candidates.find(e => norm(e.closest('div')?.innerText || '').includes(norm(wantedLabel))) || candidates[0];
              }
              if (!select) throw new Error('CUSTOM_DROPDOWN_MISSING label=' + wantedLabel);
              if (select.tagName === 'SELECT') {
                const option=[...select.options].find(o => norm(o.textContent) === norm(wantedValue));
                if (!option) throw new Error('CUSTOM_OPTION_MISSING value=' + wantedValue);
                select.value=option.value;
                select.dispatchEvent(new Event('input',{bubbles:true}));
                select.dispatchEvent(new Event('change',{bubbles:true}));
                return JSON.stringify({ok:true,strategy:'native-select',label:wantedLabel,value:wantedValue});
              }
              const current=select.querySelector('.ng-value-label,.ng-value,[class*=value]');
              if (current && norm(current.textContent) === norm(wantedValue)) {
                return JSON.stringify({ok:true,strategy:'already-selected',label:wantedLabel,value:wantedValue});
              }
              const trigger=select.querySelector('.ng-select-container,[role=combobox],input') || select;
              clickLikeUser(trigger);
              const input=select.querySelector('input');
              if (input) {
                input.focus(); input.value=wantedValue;
                input.dispatchEvent(new Event('input',{bubbles:true}));
                input.dispatchEvent(new KeyboardEvent('keyup',{bubbles:true,key:wantedValue.slice(-1)}));
              }
              let option=null;
              for (let i=0; i<25 && !option; i++) {
                await new Promise(r=>setTimeout(r,120));
                const opts=[...document.querySelectorAll('[role=option],.ng-option,.dropdown-item,[class*=option]')].filter(visible);
                option=opts.find(e => norm(e.textContent) === norm(wantedValue));
              }
              if (!option) throw new Error('CUSTOM_OPTION_MISSING value=' + wantedValue);
              clickLikeUser(option);
              await new Promise(r=>setTimeout(r,250));
              const selectedText=norm(select.innerText || select.textContent);
              if (!selectedText.includes(norm(wantedValue))) throw new Error('CUSTOM_OPTION_NOT_APPLIED value=' + wantedValue);
              return JSON.stringify({ok:true,strategy:'angular-ng-select',label:wantedLabel,value:wantedValue,selectedText});
            })()
            """.formatted(jsString(label), jsString(value));
        return singleEvaluatePlan(eval, script);
    }

    private JsonNode directFirstRowActionAreaPlan(McpToolCatalog catalog) {
        McpTool eval = catalog.evaluateTool().orElseThrow(() -> new IllegalArgumentException("Vibium MCP does not expose browser_evaluate, which is required for row action-area clicking."));
        String script = """
            (async () => {
              const visible=e=>{if(!e)return false;const r=e.getBoundingClientRect(),s=getComputedStyle(e);return r.width>2&&r.height>2&&s.display!=='none'&&s.visibility!=='hidden'&&Number(s.opacity||1)>0};
              const norm=v=>(v||'').replace(/\\s+/g,' ').trim().toLowerCase();
              const rows=[...document.querySelectorAll('datatable-body-row,.datatable-body-row,[role=row],tbody tr')]
                .filter(visible)
                .filter(r=>!r.closest('thead,.datatable-header') && !r.classList.contains('datatable-header'))
                .filter(r=>r.querySelector('datatable-body-cell,.datatable-body-cell,[role=gridcell],td'));
              const row=rows[0];
              if(!row) throw new Error('FIRST_DATA_ROW_MISSING');
              const explicit=[...row.querySelectorAll('[aria-haspopup=menu],[aria-expanded],button,.dropdown-toggle,.menu-trigger,.action-cell,[class*=action],[class*=menu],[ngbtooltip],[ng-reflect-ngb-tooltip],[aria-describedby]')].filter(visible);
              const cells=[...row.querySelectorAll('datatable-body-cell,.datatable-body-cell,[role=gridcell],td')].filter(visible);
              const light=e=>{const c=getComputedStyle(e).backgroundColor.match(/\\d+/g);return c&&c.length>=3&&+c[0]>205&&+c[1]>205&&+c[2]>205};
              const scored=[...new Set([...explicit,...cells])].map(e=>{
                const r=e.getBoundingClientRect(),s=getComputedStyle(e),cls=(e.className||'').toString().toLowerCase();
                let score=0;
                if(e.matches('[aria-haspopup=menu],[aria-expanded],button,.dropdown-toggle,.menu-trigger,.action-cell'))score+=100;
                if(cls.includes('action')||cls.includes('menu')||cls.includes('tooltip'))score+=50;
                if(e.hasAttribute('ngbtooltip')||e.hasAttribute('ng-reflect-ngb-tooltip')||e.hasAttribute('aria-describedby'))score+=45;
                if(light(e))score+=35;
                if(r.width<=100)score+=25;
                if(s.cursor==='pointer')score+=20;
                return {e,score,r};
              }).sort((a,b)=>b.score-a.score || a.r.width-b.r.width);
              const target=scored[0]?.e;
              if(!target) throw new Error('ROW_ACTION_AREA_MISSING');
              target.scrollIntoView({block:'center',inline:'nearest'});
              const r=target.getBoundingClientRect(),x=r.left+Math.min(Math.max(8,r.width/2),r.width-8),y=r.top+r.height/2;
              const hit=document.elementFromPoint(x,y);
              const clickTarget=(hit&&row.contains(hit))?hit:target;
              for(const t of ['pointerover','mouseover','mouseenter','pointerdown','mousedown','pointerup','mouseup']) clickTarget.dispatchEvent(new MouseEvent(t,{bubbles:true,cancelable:true,view:window,clientX:x,clientY:y}));
              if(typeof clickTarget.click==='function')clickTarget.click();
              let menu=false;
              for(let i=0;i<20&&!menu;i++){
                await new Promise(r=>setTimeout(r,120));
                menu=[...document.querySelectorAll('[role=menu],.dropdown-menu,.popover,[class*=menu]')].filter(visible)
                  .some(e=>norm(e.innerText).includes('see track & trace')||norm(e.innerText).includes('see transaction'));
              }
              if(!menu) throw new Error('ROW_CONTEXT_MENU_DID_NOT_OPEN');
              return JSON.stringify({ok:true,strategy:'first-row-action-area',tag:target.tagName,className:(target.className||'').toString(),score:scored[0].score});
            })()
            """;
        return singleEvaluatePlan(eval, script);
    }

    private JsonNode singleEvaluatePlan(McpTool eval, String script) {
        ObjectNode plan = mapper.createObjectNode();
        ArrayNode calls = plan.putArray("calls");
        Map<String,Object> args = new LinkedHashMap<>();
        if (schemaContains(eval, "script")) args.put("script", script);
        else if (schemaContains(eval, "expression")) args.put("expression", script);
        else if (schemaContains(eval, "code")) args.put("code", script);
        else args.put("script", script);
        calls.add(simpleCall(eval.getName(), args));
        return plan;
    }

    private String jsString(String value) {
        try { return mapper.writeValueAsString(value == null ? "" : value); }
        catch (Exception e) { return "\\\"\\\""; }
    }

    private JsonNode directAssertPlan(McpToolCatalog catalog) {
        ObjectNode plan = mapper.createObjectNode();
        ArrayNode calls = plan.putArray("calls");
        Optional<McpTool> tool = catalog.textTool().or(catalog::mapTool).or(catalog::titleTool);
        tool.ifPresent(value -> calls.add(simpleCall(value.getName(), Map.of())));
        return plan;
    }

    private JsonNode directNavigatePlan(McpToolCatalog catalog, String step) throws Exception {
        McpTool navigate = catalog.navigateTool().orElseThrow(() -> new IllegalArgumentException("No navigation MCP tool found"));
        String url = step.replaceFirst("(?i)^navigate\\s+to\\s+", "").trim();
        ArrayNode calls = mapper.createArrayNode();
        calls.add(simpleCall(navigate.getName(), argBySchema(navigate, "url", url, "href")));
        catalog.waitTool().ifPresent(wait -> calls.add(simpleCall(wait.getName(), Map.of())));
        ObjectNode plan = mapper.createObjectNode();
        plan.set("calls", calls);
        return plan;
    }

    private JsonNode directWaitPlan(McpToolCatalog catalog) {
        ObjectNode plan = mapper.createObjectNode();
        ArrayNode calls = plan.putArray("calls");
        catalog.waitTool().ifPresent(tool -> calls.add(simpleCall(tool.getName(), Map.of())));
        return plan;
    }

    private JsonNode removeNoOpStart(JsonNode plan) {
        ObjectNode out = mapper.createObjectNode();
        ArrayNode calls = mapper.createArrayNode();
        for (JsonNode c : flattenCalls(plan)) {
            String tool = firstText(c, "tool", "name", "mcpTool", "toolName");
            if (!isBrowserStart(tool)) calls.add(c);
        }
        out.set("calls", calls);
        return out;
    }

    private List<JsonNode> flattenCalls(JsonNode plan) {
        List<JsonNode> out = new ArrayList<>();
        if (plan == null || plan.isMissingNode() || plan.isNull()) return out;
        if (plan.has("calls") && plan.path("calls").isArray()) plan.path("calls").forEach(out::add);
        else out.add(plan);
        return out;
    }

    private boolean containsRealAction(JsonNode plan, String intent) {
        for (JsonNode c : flattenCalls(plan)) {
            String t = Optional.ofNullable(firstText(c, "tool", "name", "mcpTool", "toolName")).orElse("").toLowerCase(Locale.ROOT);
            if (isNoOpTool(t)) continue;
            if ("NAVIGATE".equals(intent) && containsAny(t, "navigate", "goto", "go", "open")) return true;
            if ("CLICK".equals(intent) && containsAny(t, "click", "tap", "press", "hover", "mouse", "evaluate")) return true;
            if ("HOVER".equals(intent) && containsAny(t, "hover", "mouse", "move", "evaluate")) return true;
            if ("COMPOSITE".equals(intent) && containsAny(t, "click", "tap", "press", "hover", "mouse", "move", "evaluate")) return true;
            if ("FILL".equals(intent) && containsAny(t, "fill", "type", "input", "write", "press", "evaluate")) return true;
            if ("SELECT".equals(intent) && containsAny(t, "select", "click", "press", "fill", "type", "evaluate")) return true;
            if ("ASSERT".equals(intent) && containsAny(t, "map", "snapshot", "text", "assert", "evaluate")) return true;
            if ("OTHER".equals(intent)) return true;
        }
        return false;
    }

    private boolean requiresRealAction(String intent) { return Set.of("NAVIGATE", "CLICK", "HOVER", "COMPOSITE", "FILL", "SELECT", "OTHER").contains(intent); }
    private boolean requiresPostEvidence(String intent) { return Set.of("CLICK", "HOVER", "COMPOSITE", "SELECT", "FILL", "OTHER").contains(intent); }
    private boolean isActionTool(String tool) { return containsAny(tool, "click", "hover", "mouse", "move", "fill", "type", "select", "press", "navigate", "evaluate"); }

    private boolean isStateChangingTool(String tool) {
        return containsAny(tool, "click", "tap", "press", "fill", "type", "select", "navigate", "goto", "evaluate");
    }

    private boolean isNoOpTool(String tool) {
        return containsAny(tool, "start", "map", "snapshot", "screenshot", "wait", "text", "title", "url",
                "find", "locate", "visible", "enabled", "exists", "count")
                && !isStateChangingTool(tool);
    }

    private boolean isAtomicInstruction(String instruction) {
        String value = instruction == null ? "" : instruction.toLowerCase(Locale.ROOT);
        return !(value.contains("|") || value.contains(" then ") || value.contains(" and then ") ||
                value.contains(" followed by ") || value.contains(";"));
    }

    private void waitForUiToSettle(McpClient mcp, McpToolCatalog catalog, int delayMs) {
        sleep(Math.max(250, delayMs));
        Optional<McpTool> eval = catalog.evaluateTool();
        if (eval.isEmpty()) return;
        try {
            String script = """
                (() => new Promise(resolve => {
                  const started = Date.now();
                  let last = document.documentElement.innerText.length;
                  let stable = 0;
                  const timer = setInterval(() => {
                    const now = document.documentElement.innerText.length;
                    if (now === last) stable++; else stable = 0;
                    last = now;
                    if (stable >= 2 || Date.now() - started > 2500) {
                      clearInterval(timer);
                      resolve(JSON.stringify({settled:true,url:location.href,readyState:document.readyState}));
                    }
                  }, 200);
                }))()
                """;
            mcp.callTool(eval.get().getName(), Map.of("script", script));
        } catch (Exception ignored) {
            // Best-effort stabilization only. The closed-loop evidence check remains authoritative.
        }
    }
    private boolean isBrowserStart(String tool) { return tool != null && tool.toLowerCase(Locale.ROOT).contains("start"); }

    private String expectedIntent(String step) {
        String l = step == null ? "" : step.toLowerCase(Locale.ROOT).trim();
        if (isNavigate(step)) return "NAVIGATE";
        if (l.startsWith("verify") || l.startsWith("assert") || l.startsWith("check")) return "ASSERT";
        if (l.startsWith("wait")) return "WAIT";

        boolean hasHover = containsAny(l, "hover", "mouse over", "mouseover", "move mouse");
        boolean hasClick = containsAny(l, "click", "tap", "open", "choose");
        boolean hasFill = containsAny(l, "enter", "type", "fill", "search for");
        boolean hasSelect = containsAny(l, "select", "drop down", "dropdown");

        if ((hasHover && hasClick) || (hasClick && hasSelect) || (hasClick && hasFill)) return "COMPOSITE";
        if (hasHover) return "HOVER";
        if (hasClick) return "CLICK";
        if (hasFill) return "FILL";
        if (hasSelect) return "SELECT";
        return "OTHER";
    }

    private boolean isAssert(String intent) { return "ASSERT".equals(intent); }
    private boolean isNavigate(String step) { return step != null && step.trim().toLowerCase(Locale.ROOT).startsWith("navigate to "); }
    private boolean isWait(String step) { return step != null && step.trim().toLowerCase(Locale.ROOT).startsWith("wait"); }

    private String captureScreenshot(McpClient mcp, McpToolCatalog catalog, Path screenshotDir, String scenarioId, String stepNo) throws Exception {
        Optional<McpTool> tool = catalog.screenshotTool();
        if (tool.isEmpty()) return "";
        Files.createDirectories(screenshotDir);
        String safeScenario = scenarioId == null ? "scenario" : scenarioId.replaceAll("[^a-zA-Z0-9._-]", "_");
        String safeStep = stepNo == null ? "step" : stepNo.replaceAll("[^a-zA-Z0-9._-]", "_");
        String fileName = safeScenario + "_step_" + safeStep + ".png";
        Path out = screenshotDir.resolve(fileName).toAbsolutePath();
        long before = System.currentTimeMillis();
        Map<String, Object> args = new LinkedHashMap<>();
        if (schemaContains(tool.get(), "path")) args.put("path", out.toString());
        else if (schemaContains(tool.get(), "file")) args.put("file", out.toString());
        else if (schemaContains(tool.get(), "output")) args.put("output", out.toString());
        if (schemaContains(tool.get(), "annotate")) args.put("annotate", true);
        JsonNode result = mcp.callTool(tool.get().getName(), args);
        assertMcpToolSuccess(tool.get().getName(), result);
        if (Files.exists(out) && Files.size(out) > 0) return fileName;
        Optional<byte[]> png = findImageBytes(result);
        if (png.isPresent()) { Files.write(out, png.get()); return fileName; }
        Optional<Path> pathFromResult = findPngPath(result);
        if (pathFromResult.isPresent() && Files.exists(pathFromResult.get())) { Files.copy(pathFromResult.get(), out, StandardCopyOption.REPLACE_EXISTING); return fileName; }
        Optional<Path> newest = newestPng(screenshotDir, before - 1000);
        if (newest.isPresent()) { Files.copy(newest.get(), out, StandardCopyOption.REPLACE_EXISTING); return fileName; }
        return "";
    }

    private String captureScreenshotQuietly(McpClient mcp, McpToolCatalog catalog, Path screenshotDir, String scenarioId, String stepNo) {
        try { return captureScreenshot(mcp, catalog, screenshotDir, scenarioId, stepNo); }
        catch (Exception ignored) { return ""; }
    }

    private Optional<Path> newestPng(Path dir, long afterMs) {
        try (var stream = Files.list(dir)) {
            return stream.filter(p -> p.getFileName().toString().toLowerCase(Locale.ROOT).endsWith(".png"))
                    .filter(p -> {
                        try { return Files.getLastModifiedTime(p).toMillis() >= afterMs; } catch (Exception e) { return false; }
                    })
                    .max(Comparator.comparingLong(p -> {
                        try { return Files.getLastModifiedTime(p).toMillis(); } catch (Exception e) { return 0L; }
                    }));
        } catch (Exception e) { return Optional.empty(); }
    }

    private Optional<byte[]> findImageBytes(JsonNode node) {
        if (node == null || node.isNull() || node.isMissingNode()) return Optional.empty();
        if (node.isObject()) {
            String type = node.path("type").asText("");
            String mime = node.path("mimeType").asText("");
            String data = node.path("data").asText("");
            if ((("image".equalsIgnoreCase(type)) || mime.toLowerCase(Locale.ROOT).contains("png")) && notBlank(data)) {
                try { return Optional.of(Base64.getDecoder().decode(cleanBase64(data))); } catch (Exception ignored) {}
            }
            Iterator<Map.Entry<String, JsonNode>> it = node.fields();
            while (it.hasNext()) { Optional<byte[]> found = findImageBytes(it.next().getValue()); if (found.isPresent()) return found; }
        } else if (node.isArray()) {
            for (JsonNode c : node) { Optional<byte[]> found = findImageBytes(c); if (found.isPresent()) return found; }
        } else if (node.isTextual()) {
            String text = node.asText();
            if (text.startsWith("data:image/png;base64,")) text = text.substring("data:image/png;base64,".length());
            if (text.length() > 1000 && text.matches("^[A-Za-z0-9+/=\\r\\n]+$")) {
                try { return Optional.of(Base64.getDecoder().decode(cleanBase64(text))); } catch (Exception ignored) {}
            }
        }
        return Optional.empty();
    }

    private Optional<Path> findPngPath(JsonNode node) {
        String text = extractText(node);
        Matcher m = Pattern.compile("([A-Za-z]:\\\\[^\\n\"']+?\\.png)").matcher(text);
        if (m.find()) return Optional.of(Path.of(m.group(1)));
        m = Pattern.compile("(/[^\\n\"']+?\\.png)").matcher(text);
        if (m.find()) return Optional.of(Path.of(m.group(1)));
        return Optional.empty();
    }

    private String cleanBase64(String s) { return s == null ? "" : s.replace("data:image/png;base64,", "").replaceAll("\\s+", ""); }

    private Map<String, Object> toMap(JsonNode n) {
        if (n == null || n.isMissingNode() || n.isNull()) return new LinkedHashMap<>();
        return mapper.convertValue(n, new TypeReference<Map<String, Object>>() {});
    }

    private Map<String, Object> argBySchema(McpTool tool, String primary, String value, String fallback) {
        Map<String, Object> args = new LinkedHashMap<>();
        args.put(schemaContains(tool, primary) ? primary : fallback, value);
        return args;
    }

    private ObjectNode simpleCall(String tool, Map<String, Object> args) {
        ObjectNode c = mapper.createObjectNode();
        c.put("tool", tool);
        c.set("arguments", mapper.valueToTree(args == null ? Map.of() : args));
        return c;
    }

    private JsonNode normalizePlan(JsonNode plan) {
        if (plan == null) return mapper.createObjectNode();
        if (plan.isArray()) { ObjectNode p = mapper.createObjectNode(); p.set("calls", plan); return p; }
        if (plan.has("tool") || plan.has("calls") || plan.has("name") || plan.has("mcpTool")) return plan;
        return plan;
    }

    private JsonNode parseDirectJson(String step) throws Exception {
        String t = step == null ? "" : step.trim();
        if (!t.startsWith("{") && !t.startsWith("[")) return null;
        return mapper.readTree(t);
    }

    private String applyData(String input, Map<String, Object> data) {
        if (input == null || data == null) return input;
        String out = input;
        for (Map.Entry<String, Object> e : data.entrySet()) {
            String value = e.getValue() == null ? "" : String.valueOf(e.getValue());
            out = out.replace("{{" + e.getKey() + "}}", value);
            out = out.replace("${" + e.getKey() + "}", value);
        }
        return out;
    }

    private List<String> splitArgs(String args) {
        if (args == null || args.isBlank()) return List.of();
        List<String> out = new ArrayList<>();
        Matcher m = Pattern.compile("([^\\s\"]+)|\"([^\"]*)\"").matcher(args);
        while (m.find()) out.add(m.group(1) != null ? m.group(1) : m.group(2));
        return out;
    }

    private String resolveUrl(String url, String base) {
        if (!notBlank(url)) return "";
        String t = url.trim();
        if (t.startsWith("http://") || t.startsWith("https://")) return t;
        if (!notBlank(base)) return t;
        if (base.endsWith("/") && t.startsWith("/")) return base.substring(0, base.length() - 1) + t;
        if (!base.endsWith("/") && !t.startsWith("/")) return base + "/" + t;
        return base + t;
    }

    private boolean shouldScreenshot(RunConfig config, boolean pass) {
        String mode = config.getScreenshotMode() == null ? "ALL" : config.getScreenshotMode();
        if ("NONE".equalsIgnoreCase(mode)) return false;
        if ("ALL".equalsIgnoreCase(mode)) return true;
        return !pass;
    }

    private String firstText(JsonNode node, String... fields) {
        if (node == null) return null;
        for (String f : fields) {
            JsonNode v = node.path(f);
            if (v.isTextual() && !v.asText().isBlank()) return v.asText();
        }
        return null;
    }

    private boolean schemaContains(McpTool tool, String term) {
        return tool != null && tool.getInputSchema() != null && tool.getInputSchema().toString().toLowerCase(Locale.ROOT).contains(term.toLowerCase(Locale.ROOT));
    }

    private boolean containsAny(String text, String... terms) {
        if (text == null) return false;
        String l = text.toLowerCase(Locale.ROOT);
        for (String t : terms) if (l.contains(t.toLowerCase(Locale.ROOT))) return true;
        return false;
    }

    private boolean notBlank(String value) { return value != null && !value.trim().isEmpty(); }

    private String safeName(String value) {
        String safe = value == null ? "scenario" : value.replaceAll("[^a-zA-Z0-9._-]", "_");
        return safe.isBlank() ? "scenario" : safe;
    }

    private String compact(String text, int max) {
        if (text == null) return "";
        String s = text.replaceAll("\\s+", " ").trim();
        return s.length() <= max ? s : s.substring(0, max) + "...";
    }

    private String extractText(JsonNode node) {
        if (node == null) return "";
        if (node.isTextual()) return node.asText();
        if (node.isNumber() || node.isBoolean()) return node.asText();
        StringBuilder sb = new StringBuilder();
        if (node.isObject()) node.fields().forEachRemaining(e -> sb.append(' ').append(e.getKey()).append(' ').append(extractText(e.getValue())));
        else if (node.isArray()) for (JsonNode c : node) sb.append(' ').append(extractText(c));
        return sb.toString();
    }

    private void sleep(long ms) { try { Thread.sleep(ms); } catch (InterruptedException e) { Thread.currentThread().interrupt(); } }

    private void writeToolsManifest(Path runDir, List<McpTool> tools) {
        try {
            Files.createDirectories(runDir);
            Files.writeString(runDir.resolve("mcp-tools.json"), mapper.writerWithDefaultPrettyPrinter().writeValueAsString(tools), StandardCharsets.UTF_8);
        } catch (Exception ignored) {}
    }

    private static final class CookieApplicationState {
        private boolean applied;
    }

    private record SessionOutcome(String sessionName, ScenarioResult result, List<McpTool> tools,
                                  List<String> logs, List<Map<String, Object>> transcript) { }

    private record PlannedStep(String source, JsonNode plan, JsonNode observation) {}
}
