package com.itps.vibium.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.itps.vibium.model.McpTool;

import java.net.URI;
import java.util.*;

/** Performs the optional preserve-one-cookie transaction using native MCP cookie tools. */
final class CookieSessionManager {
    private static final Set<String> READ_ONLY_COOKIE_FIELDS = Set.of(
            "size", "session", "hostOnly", "storeId", "id");
    private final ObjectMapper mapper;

    CookieSessionManager(ObjectMapper mapper) {
        this.mapper = Objects.requireNonNull(mapper, "mapper");
    }

    Result replaceCookie(McpClient mcp, McpToolCatalog catalog, String cookieName,
                         String replacementValue) throws Exception {
        if (cookieName == null || cookieName.isBlank()) throw new IllegalArgumentException("Cookie name is required.");
        if (replacementValue == null || replacementValue.isBlank()) throw new IllegalArgumentException("Cookie replacement value is required.");

        McpTool getCookies = catalog.cookiesTool().orElseThrow(() -> new IllegalStateException(
                "Vibium MCP does not expose a supported cookie inspection tool (browser_get_cookies/browser_storage_state). " +
                        "Cookie replacement cannot safely preserve HttpOnly, domain, path and SameSite attributes."));
        McpTool setCookie = catalog.setCookieTool().orElseThrow(() -> new IllegalStateException(
                "Vibium MCP does not expose a supported cookie set tool (browser_set_cookie/browser_add_cookie)."));
        if (catalog.clearCookiesTool().isEmpty() && catalog.deleteCookieTool().isEmpty()) {
            throw new IllegalStateException("Vibium MCP does not expose a supported clear-all or delete-cookie tool.");
        }

        List<String> toolsUsed = new ArrayList<>();
        String currentUrl = readCurrentUrl(mcp, catalog, toolsUsed);
        JsonNode beforeRaw = mcp.callTool(getCookies.getName(), getArguments(getCookies, currentUrl));
        toolsUsed.add(getCookies.getName());
        assertSuccess(getCookies.getName(), beforeRaw);
        List<Map<String, Object>> cookies = extractCookies(beforeRaw);
        List<Map<String, Object>> matches = cookies.stream()
                .filter(cookie -> cookieName.equals(cookieField(cookie, "name")))
                .toList();
        if (matches.isEmpty()) {
            throw new IllegalStateException("Cookie '" + cookieName + "' was not present after the home page loaded. No cookies were changed.");
        }

        Map<String, Object> selected = selectCookie(matches, currentUrl);
        Map<String, Object> replacement = writableCookie(selected, setCookie, currentUrl);
        replacement.put("name", cookieName);
        replacement.put("value", replacementValue);

        Optional<McpTool> clear = catalog.clearCookiesTool();
        if (clear.isPresent()) {
            Map<String, Object> clearArguments = hasTopProperty(clear.get(), "action")
                    ? Map.of("action", "clear") : Map.of();
            JsonNode cleared = mcp.callTool(clear.get().getName(), clearArguments);
            toolsUsed.add(clear.get().getName());
            assertSuccess(clear.get().getName(), cleared);
        } else {
            McpTool delete = catalog.deleteCookieTool().orElseThrow();
            for (Map<String, Object> cookie : cookies) {
                JsonNode deleted = mcp.callTool(delete.getName(), deleteArguments(delete, cookie, currentUrl));
                toolsUsed.add(delete.getName());
                assertSuccess(delete.getName(), deleted);
            }
        }

        Map<String, Object> setArguments = setArguments(setCookie, replacement);
        try {
            JsonNode setResult = mcp.callTool(setCookie.getName(), setArguments);
            toolsUsed.add(setCookie.getName());
            assertSuccess(setCookie.getName(), setResult);
        } catch (Exception setError) {
            Map<String, Object> rollback = new LinkedHashMap<>(replacement);
            rollback.put("value", cookieField(selected, "value"));
            try {
                mcp.callTool(setCookie.getName(), setArguments(setCookie, rollback));
                toolsUsed.add(setCookie.getName());
            } catch (Exception ignored) { }
            throw new IllegalStateException("Cookie '" + cookieName
                    + "' could not be restored with the replacement value; an original-value rollback was attempted.", setError);
        }

        refresh(mcp, catalog, currentUrl, toolsUsed);

        JsonNode afterRaw = mcp.callTool(getCookies.getName(), getArguments(getCookies, currentUrl));
        toolsUsed.add(getCookies.getName());
        assertSuccess(getCookies.getName(), afterRaw);
        List<Map<String, Object>> after = extractCookies(afterRaw);
        boolean verified = after.stream().anyMatch(cookie -> cookieName.equals(cookieField(cookie, "name"))
                && replacementValue.equals(cookieField(cookie, "value")));
        if (!verified) {
            throw new IllegalStateException("Cookie '" + cookieName + "' was restored but its replacement value could not be verified after refresh.");
        }

        ObjectNode audit = mapper.createObjectNode();
        audit.put("transaction", "PRESERVE_ONE_REMOVE_ALL_RESTORE_REFRESH");
        audit.put("cookieName", cookieName);
        audit.put("replacementValue", "[REDACTED]");
        audit.put("cookiesFoundBefore", cookies.size());
        audit.put("cookiesRemainingAfter", after.size());
        audit.put("refreshUrl", currentUrl);
        audit.put("verified", true);
        ObjectNode attributes = audit.putObject("preservedAttributes");
        selected.forEach((key, value) -> {
            if (!"name".equalsIgnoreCase(key) && !"value".equalsIgnoreCase(key)) {
                attributes.set(key, mapper.valueToTree(value));
            }
        });
        return new Result(List.copyOf(toolsUsed), audit,
                "Removed all " + cookies.size() + " existing cookie(s), restored '" + cookieName
                        + "' with its original scope and security attributes, refreshed the page, and verified the replacement value.");
    }

    private String readCurrentUrl(McpClient mcp, McpToolCatalog catalog, List<String> toolsUsed) throws Exception {
        McpTool urlTool = catalog.urlTool().orElseThrow(() -> new IllegalStateException(
                "Vibium MCP must expose browser_get_url so the page can be refreshed after cookie replacement."));
        JsonNode raw = mcp.callTool(urlTool.getName(), Map.of());
        toolsUsed.add(urlTool.getName());
        assertSuccess(urlTool.getName(), raw);
        for (String text : textValues(raw)) {
            String value = text.trim();
            if (value.startsWith("http://") || value.startsWith("https://")) return value;
            int start = Math.max(value.indexOf("https://"), value.indexOf("http://"));
            if (start >= 0) {
                int end = value.indexOf(' ', start);
                return end < 0 ? value.substring(start) : value.substring(start, end);
            }
        }
        throw new IllegalStateException("Vibium MCP did not return the current page URL before cookie replacement.");
    }

    private void refresh(McpClient mcp, McpToolCatalog catalog, String currentUrl,
                         List<String> toolsUsed) throws Exception {
        Optional<McpTool> reload = catalog.reloadTool();
        if (reload.isPresent()) {
            JsonNode result = mcp.callTool(reload.get().getName(), Map.of());
            toolsUsed.add(reload.get().getName());
            assertSuccess(reload.get().getName(), result);
        } else {
            McpTool navigate = catalog.navigateTool().orElseThrow(() -> new IllegalStateException(
                    "Vibium MCP does not expose browser_reload or browser_navigate for the required refresh."));
            Map<String, Object> arguments = new LinkedHashMap<>();
            String key = hasTopProperty(navigate, "url") ? "url" : "target";
            arguments.put(key, currentUrl);
            JsonNode result = mcp.callTool(navigate.getName(), arguments);
            toolsUsed.add(navigate.getName());
            assertSuccess(navigate.getName(), result);
        }
        if (catalog.findByName("browser_wait_for_load").isPresent()) {
            McpTool wait = catalog.findByName("browser_wait_for_load").get();
            JsonNode waited = mcp.callTool(wait.getName(), Map.of());
            toolsUsed.add(wait.getName());
            assertSuccess(wait.getName(), waited);
        }
    }

    private Map<String, Object> writableCookie(Map<String, Object> source, McpTool setTool,
                                                String currentUrl) {
        Map<String, Object> cookie = new LinkedHashMap<>();
        Set<String> supported = nestedCookieProperties(setTool);
        for (Map.Entry<String, Object> entry : source.entrySet()) {
            if (READ_ONLY_COOKIE_FIELDS.contains(entry.getKey())) continue;
            if (!supported.isEmpty() && !supported.contains(entry.getKey())) continue;
            cookie.put(entry.getKey(), entry.getValue());
        }
        if (!cookie.containsKey("domain") && !cookie.containsKey("url") && currentUrl != null && !currentUrl.isBlank()) {
            cookie.put("url", currentUrl);
        }
        return cookie;
    }

    private Set<String> nestedCookieProperties(McpTool tool) {
        JsonNode properties = schemaProperties(tool);
        JsonNode cookieSchema = properties.path("cookie");
        if (cookieSchema.isMissingNode()) cookieSchema = properties.path("cookies").path("items");
        JsonNode nested = cookieSchema.path("properties");
        if (!nested.isObject()) return Set.of();
        Set<String> names = new LinkedHashSet<>();
        nested.fieldNames().forEachRemaining(names::add);
        return names;
    }

    private Map<String, Object> setArguments(McpTool tool, Map<String, Object> cookie) {
        JsonNode properties = schemaProperties(tool);
        Map<String, Object> result;
        if (properties.has("cookies")) result = new LinkedHashMap<>(Map.of("cookies", List.of(cookie)));
        else if (properties.has("cookie")) result = new LinkedHashMap<>(Map.of("cookie", cookie));
        else if (properties.has("name") || properties.has("value")) {
            Map<String, Object> flat = new LinkedHashMap<>();
            cookie.forEach((key, value) -> {
                if (properties.has(key)) flat.put(key, value);
            });
            result = flat.isEmpty() ? new LinkedHashMap<>(cookie) : flat;
        } else {
            result = new LinkedHashMap<>(cookie);
        }
        if (properties.has("action")) result.put("action", "set");
        return result;
    }

    private Map<String, Object> getArguments(McpTool tool, String currentUrl) {
        JsonNode properties = schemaProperties(tool);
        Map<String, Object> arguments = new LinkedHashMap<>();
        if (properties.has("action")) arguments.put("action", "get");
        if (properties.has("urls") && currentUrl != null && !currentUrl.isBlank()) {
            arguments.put("urls", List.of(currentUrl));
        }
        return arguments;
    }

    private Map<String, Object> deleteArguments(McpTool tool, Map<String, Object> cookie,
                                                 String currentUrl) {
        JsonNode properties = schemaProperties(tool);
        Map<String, Object> identity = new LinkedHashMap<>();
        for (String key : List.of("name", "domain", "path", "url")) {
            if (cookie.containsKey(key)) identity.put(key, cookie.get(key));
        }
        if (!identity.containsKey("url") && currentUrl != null && !currentUrl.isBlank()) identity.put("url", currentUrl);
        if (properties.has("cookies")) return Map.of("cookies", List.of(identity));
        if (properties.has("cookie")) return Map.of("cookie", identity);
        if (properties.isObject() && properties.size() > 0) {
            identity.entrySet().removeIf(entry -> !properties.has(entry.getKey()));
        }
        return identity;
    }

    private Map<String, Object> selectCookie(List<Map<String, Object>> matches, String currentUrl) {
        if (matches.size() == 1) return matches.get(0);
        String host = "";
        String path = "/";
        try {
            URI uri = URI.create(currentUrl);
            host = Optional.ofNullable(uri.getHost()).orElse("");
            path = Optional.ofNullable(uri.getPath()).filter(value -> !value.isBlank()).orElse("/");
        } catch (Exception ignored) { }
        String finalHost = host;
        String finalPath = path;
        return matches.stream().max(Comparator.comparingInt(cookie -> cookieScore(cookie, finalHost, finalPath)))
                .orElse(matches.get(0));
    }

    private int cookieScore(Map<String, Object> cookie, String host, String currentPath) {
        String domain = String.valueOf(cookie.getOrDefault("domain", "")).replaceFirst("^\\.", "");
        String path = String.valueOf(cookie.getOrDefault("path", "/"));
        int score = host.equalsIgnoreCase(domain) ? 10_000 : (host.endsWith("." + domain) ? 5_000 : 0);
        if (currentPath.startsWith(path)) score += Math.min(path.length(), 1_000);
        return score;
    }

    private List<Map<String, Object>> extractCookies(JsonNode raw) {
        List<JsonNode> roots = new ArrayList<>();
        roots.add(raw);
        for (String text : textValues(raw)) {
            String value = text.trim();
            if (!(value.startsWith("{") || value.startsWith("["))) continue;
            try { roots.add(mapper.readTree(value)); } catch (Exception ignored) { }
        }
        List<Map<String, Object>> cookies = new ArrayList<>();
        Set<String> seen = new LinkedHashSet<>();
        for (JsonNode root : roots) collectCookies(root, cookies, seen);
        return cookies;
    }

    private void collectCookies(JsonNode node, List<Map<String, Object>> out, Set<String> seen) {
        if (node == null || node.isNull() || node.isMissingNode()) return;
        if (node.isObject()) {
            if (node.path("name").isTextual() && node.has("value")) {
                @SuppressWarnings("unchecked")
                Map<String, Object> cookie = mapper.convertValue(node, LinkedHashMap.class);
                String identity = cookieField(cookie, "name") + "|" + cookie.get("domain") + "|" + cookie.get("path") + "|" + cookieField(cookie, "value");
                if (seen.add(identity)) out.add(cookie);
                return;
            }
            node.fields().forEachRemaining(entry -> collectCookies(entry.getValue(), out, seen));
        } else if (node.isArray()) {
            for (JsonNode child : node) collectCookies(child, out, seen);
        }
    }

    private List<String> textValues(JsonNode node) {
        List<String> values = new ArrayList<>();
        collectText(node, values);
        values.sort(Comparator.comparingInt(String::length).reversed());
        return values;
    }

    private void collectText(JsonNode node, List<String> values) {
        if (node == null) return;
        if (node.isTextual()) values.add(node.asText());
        else if (node.isArray()) for (JsonNode child : node) collectText(child, values);
        else if (node.isObject()) node.fields().forEachRemaining(entry -> collectText(entry.getValue(), values));
    }

    private JsonNode schemaProperties(McpTool tool) {
        if (tool == null || tool.getInputSchema() == null) return mapper.createObjectNode();
        JsonNode properties = tool.getInputSchema().path("properties");
        return properties.isObject() ? properties : mapper.createObjectNode();
    }

    private boolean hasTopProperty(McpTool tool, String name) {
        return schemaProperties(tool).has(name);
    }

    private String cookieField(Map<String, Object> cookie, String name) {
        Object raw = cookie.get(name);
        if (raw instanceof Map<?, ?> map && map.containsKey("value")) raw = map.get("value");
        return raw == null ? "" : String.valueOf(raw);
    }

    private void assertSuccess(String toolName, JsonNode result) {
        if (result == null || result.isMissingNode()) return;
        if (result.path("isError").asBoolean(false) || result.path("success").isBoolean() && !result.path("success").asBoolean()) {
            throw new IllegalStateException("MCP cookie operation failed in " + toolName + ".");
        }
        if (result.has("error") && !result.path("error").isNull() && !result.path("error").asText("").isBlank()) {
            throw new IllegalStateException("MCP cookie operation failed in " + toolName + ".");
        }
    }

    record Result(List<String> toolsUsed, ObjectNode redactedAudit, String evidence) { }
}
