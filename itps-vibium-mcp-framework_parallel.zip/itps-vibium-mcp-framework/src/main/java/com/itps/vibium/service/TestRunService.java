package com.itps.vibium.service;

import com.itps.vibium.model.RunConfig;
import com.itps.vibium.model.RunStatus;
import com.itps.vibium.model.TestScenario;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

@Service
public class TestRunService {
    private final ItpsMcpRunner runner;
    private final RunStore runStore;
    private final Map<String, RunSnapshot> snapshots = new ConcurrentHashMap<>();

    public TestRunService(ItpsMcpRunner runner, RunStore runStore) {
        this.runner = runner;
        this.runStore = runStore;
    }

    public RunStatus start(List<TestScenario> scenarios, RunConfig config) {
        return startInternal(copyScenarios(scenarios), copyConfig(config), null);
    }

    public RunStatus rerunSelected(String sourceRunId, List<String> testIds) {
        RunSnapshot source = snapshots.get(sourceRunId);
        if (source == null) throw new IllegalArgumentException("Original run is not available for rerun: " + sourceRunId);
        Set<String> requested = testIds == null ? Set.of() : testIds.stream()
                .filter(id -> id != null && !id.isBlank()).map(String::trim).collect(Collectors.toSet());
        if (requested.isEmpty()) throw new IllegalArgumentException("Select at least one test to rerun");

        List<TestScenario> selected = source.scenarios().stream()
                .filter(s -> requested.contains(s.getId()))
                .map(this::copyScenario)
                .toList();
        if (selected.isEmpty()) throw new IllegalArgumentException("None of the selected test IDs exist in run " + sourceRunId);
        return startInternal(selected, copyConfig(source.config()), sourceRunId);
    }

    private RunStatus startInternal(List<TestScenario> scenarios, RunConfig config, String sourceRunId) {
        String runId = "RUN-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();
        config.setRunId(runId);
        RunStatus status = new RunStatus();
        status.setRunId(runId);
        status.setStatus("QUEUED");
        status.setTotal(scenarios.size());
        status.setMessage(sourceRunId == null ? "Execution queued" : "Rerun queued from " + sourceRunId);
        runStore.put(status);
        snapshots.put(runId, new RunSnapshot(copyScenarios(scenarios), copyConfig(config)));
        CompletableFuture.runAsync(() -> {
            runner.execute(scenarios, config, status);
            runStore.put(status);
        });
        return status;
    }

    private List<TestScenario> copyScenarios(List<TestScenario> source) {
        List<TestScenario> out = new ArrayList<>();
        for (TestScenario scenario : source) out.add(copyScenario(scenario));
        return out;
    }

    private TestScenario copyScenario(TestScenario source) {
        TestScenario copy = new TestScenario();
        copy.setId(source.getId());
        copy.setName(source.getName());
        copy.setUrl(source.getUrl());
        copy.setExpected(source.getExpected());
        copy.setSteps(source.getSteps() == null ? new ArrayList<>() : new ArrayList<>(source.getSteps()));
        copy.setData(source.getData() == null ? new LinkedHashMap<>() : new LinkedHashMap<>(source.getData()));
        return copy;
    }

    private RunConfig copyConfig(RunConfig source) {
        RunConfig c = new RunConfig();
        c.setRunId(source.getRunId());
        c.setLlmBaseUrl(source.getLlmBaseUrl());
        c.setLlmApiKey(source.getLlmApiKey());
        c.setLlmModel(source.getLlmModel());
        c.setAppBaseUrl(source.getAppBaseUrl());
        c.setMcpCommand(source.getMcpCommand());
        c.setMcpArgs(source.getMcpArgs());
        c.setMcpMode(source.getMcpMode());
        c.setMcpHost(source.getMcpHost());
        c.setMcpPort(source.getMcpPort());
        c.setMcpConnectTimeoutSeconds(source.getMcpConnectTimeoutSeconds());
        c.setBrowserId(source.getBrowserId());
        c.setBrowserName(source.getBrowserName());
        c.setBrowserExecutable(source.getBrowserExecutable());
        c.setHeadless(source.isHeadless());
        c.setSeparateBrowserPerTest(source.isSeparateBrowserPerTest());
        c.setParallelExecution(source.isParallelExecution());
        c.setParallelThreads(source.getParallelThreads());
        c.setReplaceSessionCookie(source.isReplaceSessionCookie());
        c.setSessionCookieName(source.getSessionCookieName());
        c.setSessionCookieValue(source.getSessionCookieValue());
        c.setAllowInsecureCertificates(source.isAllowInsecureCertificates());
        c.setUseLlm(source.isUseLlm());
        c.setContinueOnFailure(source.isContinueOnFailure());
        c.setStrictEvidence(source.isStrictEvidence());
        c.setScreenshotMode(source.getScreenshotMode());
        c.setStepTimeoutSeconds(source.getStepTimeoutSeconds());
        c.setRetryCount(source.getRetryCount());
        c.setRetryDelayMs(source.getRetryDelayMs());
        c.setMaxAgentTurns(source.getMaxAgentTurns());
        c.setEnableSelfHealing(source.isEnableSelfHealing());
        c.setHealingConfidenceThreshold(source.getHealingConfidenceThreshold());
        return c;
    }

    private record RunSnapshot(List<TestScenario> scenarios, RunConfig config) {}
}
