'use strict';

const byId = id => document.getElementById(id);
const required = id => {
  const element = byId(id);
  if (!element) throw new Error(`UI element '${id}' is missing. Refresh the page with Ctrl+F5.`);
  return element;
};

let pollHandle = null;
let browsers = [];
let currentRunId = '';
let currentRun = null;
let pollFailures = 0;
let availableSheets = [];
let recorderSessionId = '';
let recorderPollHandle = null;
let recorderState = null;

function safeText(id, value){
  const element = byId(id);
  if (element) element.textContent = String(value ?? '');
}

function safeDisabled(id, value){
  const element = byId(id);
  if (element) element.disabled = Boolean(value);
}

function setStatus(text, isError = false){
  const line = byId('statusLine');
  if (!line) return;
  line.textContent = String(text || '');
  line.classList.toggle('error-line', isError);
}

async function readJson(response){
  const text = await response.text();
  if (!text) return {};
  try { return JSON.parse(text); }
  catch { throw new Error(`Server returned an invalid response (${response.status}).`); }
}

async function loadBrowsers(){
  try{
    const response = await fetch('/api/browsers', {cache:'no-store'});
    const data = await readJson(response);
    if(!response.ok) throw new Error(data.error || `HTTP ${response.status}`);
    browsers = Array.isArray(data) ? data : [];
    const available = browsers.filter(b => b.detected || b.id === 'vibium-managed-chrome');
    const browserSelect = required('browserId');
    browserSelect.innerHTML = available.length
      ? available.map(b => `<option value="${escAttr(b.id)}">${esc(b.name)}</option>`).join('')
      : '<option value="vibium-managed-chrome">Vibium managed Chrome</option>';
    updateBrowserSelection();
  }catch(error){
    safeText('browserNote', `Browser discovery failed: ${error.message}`);
  }
}

function updateBrowserSelection(){
  const select = byId('browserId');
  if(!select) return;
  const selected = browsers.find(b => b.id === select.value);
  if(!selected) return;
  const browserName = byId('browserName');
  const browserExecutable = byId('browserExecutable');
  if(browserName) browserName.value = selected.name || '';
  if(browserExecutable) browserExecutable.value = selected.executable || '';
  safeText('browserNote', selected.executable || selected.note || '');
}

function setArtifactButtons(enabled){
  document.querySelectorAll('[data-artifact]').forEach(button => button.disabled = !enabled);
}

function shortStatus(run){
  const raw = String(run?.status || '').toUpperCase();
  if(['CREATED','QUEUED','RUNNING'].includes(raw)) return raw === 'CREATED' ? 'QUEUED' : raw;
  if(Number(run?.failed || 0) > 0) return 'FAILED';
  if(Number(run?.total || 0) > 0 && Number(run?.passed || 0) === Number(run?.total || 0)) return 'PASSED';
  return raw || 'COMPLETED';
}

function renderRun(run){
  if(!run || typeof run !== 'object') throw new Error('Run status payload is empty.');
  currentRun = run;
  currentRunId = run.runId || currentRunId;

  const resultPanel = required('resultPanel');
  resultPanel.classList.remove('hidden');

  const status = shortStatus(run);
  safeText('runTitle', `${currentRunId || 'Run'} · ${status}`);
  safeText('total', run.total ?? 0);
  safeText('passed', run.passed ?? 0);
  safeText('failed', run.failed ?? 0);
  safeText('status', status);

  const body = required('scenarioResults');
  const scenarios = Array.isArray(run.scenarios) ? run.scenarios : [];
  body.innerHTML = scenarios.map(s => {
    const raw = String(s.status || '').toUpperCase();
    const scenarioStatus = raw.startsWith('PASSED') ? 'PASSED' : (raw || 'FAILED');
    return `<tr>
      <td><input class="test-select" type="checkbox" value="${escAttr(s.id)}" data-status="${escAttr(scenarioStatus)}" /></td>
      <td>${esc(s.id)}</td>
      <td>${esc(s.name)}</td>
      <td><span class="pill ${scenarioStatus === 'PASSED' ? 'pass' : 'fail'}">${esc(scenarioStatus)}</span></td>
      <td>${formatDuration(s.durationMs)}</td>
      <td class="err">${renderError(s.errorMessage || '')}</td>
    </tr>`;
  }).join('');

  bindSelectionEvents();
}

async function fetchRun(runId){
  const response = await fetch(`/api/runs/${encodeURIComponent(runId)}`, {cache:'no-store'});
  const data = await readJson(response);
  if(!response.ok) throw new Error(data.error || `HTTP ${response.status}`);
  return data;
}

async function pollOnce(runId){
  const data = await fetchRun(runId);
  renderRun(data);
  const running = ['CREATED','QUEUED','RUNNING'].includes(String(data.status || '').toUpperCase());
  if(!running){
    clearInterval(pollHandle);
    pollHandle = null;
    safeDisabled('runBtn', false);
    setArtifactButtons(true);
    updateRerunButton();
    setStatus(`Execution completed: ${shortStatus(data)}.`);
  }
}

function poll(runId){
  clearInterval(pollHandle);
  pollHandle = null;
  pollFailures = 0;

  pollOnce(runId).catch(error => {
    setStatus(`Waiting for run status: ${error.message}`, true);
  });

  pollHandle = setInterval(async () => {
    try{
      await pollOnce(runId);
      pollFailures = 0;
    }catch(error){
      pollFailures++;
      if(pollFailures >= 5){
        clearInterval(pollHandle);
        pollHandle = null;
        safeDisabled('runBtn', false);
        setStatus(`Unable to read run status: ${error.message}`, true);
      }
    }
  }, 1500);
}

async function startRun(){
  try{
    const fileInput = required('scenarioFile');
    const file = fileInput.files?.[0];
    if(!file){ setStatus('Choose a scenario file.', true); return; }
    if(!required('llmApiKey').value.trim()){ setStatus('Enter the LLM token.', true); return; }
    if(required('parallelExecution').checked && !required('separateBrowserPerTest').checked){
      setStatus('Parallel execution requires a separate browser for each test.', true); return;
    }
    if(required('replaceSessionCookie').checked && (!required('sessionCookieName').value.trim() || !required('sessionCookieValue').value.trim())){
      setStatus('Enter both the existing cookie name and replacement value.', true); return;
    }

    const form = new FormData();
    form.append('scenarioFile', file);
    const selectedSheets = getSelectedSheets();
    if (/\.xlsx?$/i.test(file.name) && selectedSheets.length === 0) { setStatus('Select at least one worksheet.', true); return; }
    selectedSheets.forEach(sheetName => form.append('sheetNames', sheetName));
    ['llmBaseUrl','llmApiKey','llmModel','appBaseUrl','browserId','browserName','browserExecutable','parallelThreads','screenshotMode','stepTimeoutSeconds','retryCount','healingConfidenceThreshold']
      .forEach(id => { const e = byId(id); form.append(id, e ? (e.value || '') : ''); });
    if(required('replaceSessionCookie').checked){
      form.append('sessionCookieName', required('sessionCookieName').value.trim());
      form.append('sessionCookieValue', required('sessionCookieValue').value);
    }
    ['useLlm','headless','separateBrowserPerTest','parallelExecution','replaceSessionCookie','allowInsecureCertificates','continueOnFailure','strictEvidence','enableSelfHealing']
      .forEach(id => { const e = byId(id); form.append(id, Boolean(e?.checked)); });

    safeDisabled('runBtn', true);
    setArtifactButtons(false);
    required('resultPanel').classList.remove('hidden');
    safeText('runTitle', 'Starting execution…');
    safeText('total', '0'); safeText('passed', '0'); safeText('failed', '0'); safeText('status', 'QUEUED');
    required('scenarioResults').innerHTML = '<tr><td colspan="6" class="empty-state">Uploading test data and starting Vibium execution…</td></tr>';
    setStatus('Starting execution...');

    const response = await fetch('/api/runs', {method:'POST', body:form, cache:'no-store'});
    const data = await readJson(response);
    if(!response.ok) throw new Error(data.error || 'Unable to start execution');
    if(!data.runId) throw new Error('The server started no run ID. Check backend logs.');

    renderRun(data);
    poll(data.runId);
  }catch(error){
    safeDisabled('runBtn', false);
    setStatus(error.message, true);
  }
}

async function openArtifact(name, download){
  if(!currentRunId){ setStatus('No completed run is available.', true); return; }
  const url = `/api/runs/${encodeURIComponent(currentRunId)}/${name}`;
  try{
    if(!download){
      // Never replace the framework home page. Open reports/logs only in a separate tab.
      const anchor = document.createElement('a');
      anchor.href = url;
      anchor.target = '_blank';
      anchor.rel = 'noopener noreferrer';
      anchor.style.display = 'none';
      document.body.appendChild(anchor);
      anchor.click();
      anchor.remove();
      setStatus(`${name} opened in a new tab. The framework page remains unchanged.`);
      return;
    }
    setStatus(`Preparing ${name}...`);
    const response = await fetch(url, {cache:'no-store'});
    if(!response.ok){
      const data = await readJson(response).catch(() => ({}));
      throw new Error(data.error || `HTTP ${response.status}`);
    }
    const blob = await response.blob();
    const objectUrl = URL.createObjectURL(blob);
    const anchor = document.createElement('a');
    anchor.href = objectUrl;
    anchor.download = name;
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
    setTimeout(() => URL.revokeObjectURL(objectUrl), 1000);
    setStatus(`${name} downloaded.`);
  }catch(error){
    setStatus(`Unable to open ${name}: ${error.message}`, true);
  }
}

function bindSelectionEvents(){
  document.querySelectorAll('.test-select').forEach(cb => cb.addEventListener('change', updateRerunButton));
  const all = byId('selectAllTests');
  if(all){
    all.checked = false;
    all.onchange = () => {
      document.querySelectorAll('.test-select').forEach(cb => cb.checked = all.checked);
      updateRerunButton();
    };
  }
  updateRerunButton();
}

function updateRerunButton(){
  const button = byId('rerunSelectedBtn');
  if(!button) return;
  const count = document.querySelectorAll('.test-select:checked').length;
  const running = ['CREATED','QUEUED','RUNNING'].includes(String(currentRun?.status || '').toUpperCase());
  button.disabled = count === 0 || !currentRunId || running;
  button.textContent = count ? `Rerun selected (${count})` : 'Rerun selected';
}

async function rerunSelected(){
  const testIds = [...document.querySelectorAll('.test-select:checked')].map(cb => cb.value);
  if(!testIds.length){ setStatus('Select at least one test.', true); return; }
  try{
    safeDisabled('rerunSelectedBtn', true);
    safeDisabled('runBtn', true);
    setArtifactButtons(false);
    setStatus(`Starting rerun for ${testIds.length} test(s)...`);
    const response = await fetch(`/api/runs/${encodeURIComponent(currentRunId)}/rerun`, {
      method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({testIds}), cache:'no-store'
    });
    const data = await readJson(response);
    if(!response.ok) throw new Error(data.error || 'Unable to start rerun');
    if(!data.runId) throw new Error('Rerun did not return a run ID.');
    renderRun(data);
    poll(data.runId);
  }catch(error){
    safeDisabled('runBtn', false);
    updateRerunButton();
    setStatus(error.message, true);
  }
}


function setRecorderStatus(text, isError = false, recording = false){
  const element = byId('recorderStatus');
  if(!element) return;
  element.innerHTML = `${recording ? '<span class="recording-dot"></span>' : ''}${esc(String(text || ''))}`;
  element.classList.toggle('error-line', isError);
}

function recorderActive(){
  return ['STARTING','RECORDING','STOPPING'].includes(String(recorderState?.state || '').toUpperCase());
}

function updateRecorderControls(){
  const active = recorderActive();
  const stopped = ['STOPPED','FAILED'].includes(String(recorderState?.state || '').toUpperCase());
  safeDisabled('startRecorderBtn', active);
  safeDisabled('stopRecorderBtn', !active || String(recorderState?.state || '').toUpperCase() === 'STOPPING');
  safeDisabled('copyRecordedStepsBtn', !(recorderState?.actions?.length));
  safeDisabled('downloadRecordedExcelBtn', !stopped || !(recorderState?.actions?.length));
  safeDisabled('downloadRecordedJsonBtn', !stopped || !(recorderState?.actions?.length));
  safeDisabled('browserId', active);
  safeDisabled('runBtn', active);
  const toggle = byId('enableRecorder'); if(toggle) toggle.disabled = active;
}

function renderRecorder(status){
  if(!status || typeof status !== 'object') return;
  recorderState = status;
  recorderSessionId = status.sessionId || recorderSessionId;
  const state = String(status.state || '').toUpperCase();
  const actions = Array.isArray(status.actions) ? status.actions : [];
  setRecorderStatus(status.message || state, state === 'FAILED', state === 'RECORDING');
  safeText('recorderCurrentPage', status.currentPageUrl ? `${status.currentPageTitle || 'Current page'} · ${status.currentPageUrl}` : '');
  const body = byId('recorderActions');
  if(body){
    body.innerHTML = actions.length ? actions.map(action => `<tr>
      <td>${esc(action.sequence)}</td>
      <td class="recorder-prompt">${esc(action.prompt || '')}${action.sensitive ? '<div class="muted">Sensitive value masked</div>' : ''}</td>
      <td><b>${esc(action.locatorType || '')}</b><div class="locator-code">${esc(action.locator || '')}</div>${action.fallbackLocator ? `<details><summary class="muted">Fallback</summary><div class="locator-code">${esc(action.fallbackLocator)}</div></details>` : ''}</td>
      <td>${esc(action.pageTitle || '')}<div class="muted">${esc(concise(action.pageUrl || ''))}</div></td>
      <td><button type="button" class="delete-recorded-action" data-sequence="${escAttr(action.sequence)}" ${state === 'STARTING' || state === 'STOPPING' ? 'disabled' : ''}>Delete</button></td>
    </tr>`).join('') : '<tr><td colspan="5" class="empty-state">No supported UI actions recorded yet.</td></tr>';
    body.querySelectorAll('.delete-recorded-action').forEach(button => button.addEventListener('click', () => deleteRecordedAction(Number(button.dataset.sequence))));
  }
  updateRecorderControls();
  if(['STOPPED','FAILED'].includes(state) && recorderPollHandle){ clearInterval(recorderPollHandle); recorderPollHandle = null; }
}

async function fetchRecorderStatus(){
  if(!recorderSessionId) return;
  const response = await fetch(`/api/recorder/${encodeURIComponent(recorderSessionId)}`, {cache:'no-store'});
  const data = await readJson(response);
  if(!response.ok) throw new Error(data.error || `HTTP ${response.status}`);
  renderRecorder(data);
}

function pollRecorder(){
  if(recorderPollHandle) clearInterval(recorderPollHandle);
  recorderPollHandle = setInterval(() => fetchRecorderStatus().catch(error => setRecorderStatus(`Unable to read recorder status: ${error.message}`, true)), 900);
}

async function startRecorder(){
  try{
    const url = required('recorderApplicationUrl').value.trim();
    if(!url){ setRecorderStatus('Application URL is mandatory to record UI actions.', true); return; }
    let parsed;
    try{ parsed = new URL(url); }catch(_){ setRecorderStatus('Enter a complete valid application URL.', true); return; }
    if(!['http:','https:'].includes(parsed.protocol)){ setRecorderStatus('Application URL must start with http:// or https://.', true); return; }
    const payload = {
      applicationUrl: url,
      browserId: byId('browserId')?.value || 'vibium-managed-chrome',
      browserName: byId('browserName')?.value || '',
      browserExecutable: byId('browserExecutable')?.value || '',
      allowInsecureCertificates: Boolean(byId('recorderAllowInsecureCertificates')?.checked)
    };
    recorderState = {state:'STARTING', actions:[]};
    updateRecorderControls();
    setRecorderStatus('Launching headed browser...', false, true);
    const response = await fetch('/api/recorder/start', {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(payload), cache:'no-store'});
    const data = await readJson(response);
    if(!response.ok) throw new Error(data.error || 'Unable to start recorder');
    renderRecorder(data);
    pollRecorder();
  }catch(error){
    recorderState = {state:'FAILED', actions:[]};
    updateRecorderControls();
    setRecorderStatus(error.message, true);
  }
}

async function stopRecorder(){
  if(!recorderSessionId) return;
  try{
    safeDisabled('stopRecorderBtn', true);
    setRecorderStatus('Stopping recording and generating Excel steps...', false, true);
    const response = await fetch(`/api/recorder/${encodeURIComponent(recorderSessionId)}/stop`, {method:'POST', cache:'no-store'});
    const data = await readJson(response);
    if(!response.ok) throw new Error(data.error || 'Unable to stop recorder');
    renderRecorder(data);
  }catch(error){ setRecorderStatus(error.message, true); updateRecorderControls(); }
}

async function deleteRecordedAction(sequence){
  if(!recorderSessionId || !sequence) return;
  try{
    const response = await fetch(`/api/recorder/${encodeURIComponent(recorderSessionId)}/actions/${sequence}`, {method:'DELETE', cache:'no-store'});
    const data = await readJson(response);
    if(!response.ok) throw new Error(data.error || 'Unable to delete step');
    renderRecorder(data);
  }catch(error){ setRecorderStatus(error.message, true); }
}

async function copyRecordedSteps(){
  const steps = (recorderState?.actions || []).map(action => action.prompt).filter(Boolean).join('\n');
  if(!steps){ setRecorderStatus('No recorded steps are available to copy.', true); return; }
  try{ await navigator.clipboard.writeText(steps); setRecorderStatus(`${recorderState.actions.length} step(s) copied. Paste them into the Excel Steps cell.`); }
  catch(_){
    const textarea = document.createElement('textarea'); textarea.value = steps; document.body.appendChild(textarea); textarea.select(); document.execCommand('copy'); textarea.remove();
    setRecorderStatus(`${recorderState.actions.length} step(s) copied. Paste them into the Excel Steps cell.`);
  }
}

function downloadRecorderArtifact(name){
  if(!recorderSessionId) return;
  const anchor = document.createElement('a');
  anchor.href = `/api/recorder/${encodeURIComponent(recorderSessionId)}/${name}`;
  anchor.download = name;
  document.body.appendChild(anchor); anchor.click(); anchor.remove();
}


function getSelectedSheets(){
  return [...document.querySelectorAll('.sheet-checkbox:checked')].map(input => input.value);
}

function updateSheetSelectionSummary(){
  const selected = getSelectedSheets();
  safeText('sheetSelectionSummary', selected.length
    ? `${selected.length} of ${availableSheets.length} worksheet(s) selected: ${selected.join(', ')}`
    : 'No worksheets selected.');
}

function renderSheetCheckboxes(sheets){
  const container = byId('sheetCheckboxes');
  if(!container) return;
  container.innerHTML = sheets.map((name, index) => `<label class="check sheet-check"><input class="sheet-checkbox" type="checkbox" value="${escAttr(name)}" ${index === 0 ? 'checked' : ''} /><span>${esc(name)}</span></label>`).join('');
  container.querySelectorAll('.sheet-checkbox').forEach(input => input.addEventListener('change', updateSheetSelectionSummary));
  updateSheetSelectionSummary();
}

function setAllSheets(checked){
  document.querySelectorAll('.sheet-checkbox').forEach(input => input.checked = checked);
  updateSheetSelectionSummary();
}

function concise(value){ const text = String(value || '').replace(/\s+/g,' ').trim(); return text.length > 180 ? `${text.slice(0,177)}...` : text; }
function renderError(value){ const raw = String(value || '').trim(); return raw ? `<details class="error-details"><summary>${esc(concise(raw))}</summary><pre>${esc(raw)}</pre></details>` : '<span class="muted">—</span>'; }
function formatDuration(ms){ const value = Number(ms || 0); return value < 1000 ? `${value} ms` : `${(value/1000).toFixed(1)} s`; }
function esc(value){ return String(value ?? '').replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m])); }
function escAttr(value){ return esc(value).replace(/`/g,'&#96;'); }

function updateExecutionMode(changed){
  const separate = required('separateBrowserPerTest');
  const parallel = required('parallelExecution');
  if(changed === 'parallel' && parallel.checked) separate.checked = true;
  if(changed === 'separate' && !separate.checked) parallel.checked = false;
  required('parallelThreadsField').classList.toggle('hidden', !parallel.checked);
}

function updateCookieSettings(){
  const enabled = required('replaceSessionCookie').checked;
  required('cookieSettingsPanel').classList.toggle('hidden', !enabled);
}

function initialize(){
  try{
    required('browserId').addEventListener('change', updateBrowserSelection);
    required('separateBrowserPerTest').addEventListener('change', () => updateExecutionMode('separate'));
    required('parallelExecution').addEventListener('change', () => updateExecutionMode('parallel'));
    required('replaceSessionCookie').addEventListener('change', updateCookieSettings);
    required('enableRecorder').addEventListener('change', event => {
      const enabled = Boolean(event.target.checked);
      required('recorderPanel').classList.toggle('hidden', !enabled);
      if(enabled) setRecorderStatus('Enter the mandatory application URL and click Start recording.');
    });
    required('startRecorderBtn').addEventListener('click', startRecorder);
    required('stopRecorderBtn').addEventListener('click', stopRecorder);
    required('copyRecordedStepsBtn').addEventListener('click', copyRecordedSteps);
    required('downloadRecordedExcelBtn').addEventListener('click', () => downloadRecorderArtifact('recorded-steps.xlsx'));
    required('downloadRecordedJsonBtn').addEventListener('click', () => downloadRecorderArtifact('recorded-actions.json'));
    required('scenarioFile').addEventListener('change', async () => {
      const file = required('scenarioFile').files?.[0];
      safeText('fileName', file ? `${file.name} · ${Math.max(1, Math.round(file.size/1024))} KB` : 'No file selected');
      const field = byId('sheetField');
      if(!file || !/\.xlsx?$/i.test(file.name)){ availableSheets = []; renderSheetCheckboxes([]); if(field) field.classList.add('hidden'); return; }
      try{
        const fd = new FormData(); fd.append('scenarioFile', file);
        const response = await fetch('/api/runs/sheets',{method:'POST',body:fd,cache:'no-store'});
        const data = await readJson(response); if(!response.ok) throw new Error(data.error || 'Unable to read worksheets');
        availableSheets = Array.isArray(data.sheets) ? data.sheets : [];
        renderSheetCheckboxes(availableSheets);
        if(field) field.classList.toggle('hidden', availableSheets.length === 0);
        setStatus(availableSheets.length ? `${availableSheets.length} worksheet(s) detected. Select one or more sheets to execute.` : 'No worksheets found.', availableSheets.length===0);
      }catch(error){ if(field) field.classList.add('hidden'); setStatus(`Unable to read worksheets: ${error.message}`, true); }
    });
    required('selectAllSheetsBtn').addEventListener('click', () => setAllSheets(true));
    required('clearAllSheetsBtn').addEventListener('click', () => setAllSheets(false));
    required('runBtn').addEventListener('click', startRun);
    required('selectFailedBtn').addEventListener('click', () => {
      document.querySelectorAll('.test-select').forEach(cb => cb.checked = cb.dataset.status === 'FAILED');
      updateRerunButton();
    });
    required('rerunSelectedBtn').addEventListener('click', rerunSelected);
    document.querySelectorAll('[data-artifact]').forEach(button => {
      button.addEventListener('click', () => openArtifact(button.dataset.artifact, button.hasAttribute('data-download')));
    });
    setArtifactButtons(false);
    updateRecorderControls();
    updateExecutionMode();
    updateCookieSettings();
    loadBrowsers();
  }catch(error){
    setStatus(`UI initialization failed: ${error.message}`, true);
    console.error(error);
  }
}

if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', initialize);
else initialize();
