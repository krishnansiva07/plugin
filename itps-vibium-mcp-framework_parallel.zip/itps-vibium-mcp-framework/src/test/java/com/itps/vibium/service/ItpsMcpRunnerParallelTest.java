package com.itps.vibium.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.itps.vibium.model.RunConfig;
import com.itps.vibium.model.RunStatus;
import com.itps.vibium.model.TestScenario;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

import static org.assertj.core.api.Assertions.assertThat;

class ItpsMcpRunnerParallelTest {
    @TempDir
    Path output;

    @Test
    void isolatedParallelModeUsesConcurrentMcpBrowserSessionsAndKeepsResultOrder() throws Exception {
        try (StubMcpServer server = new StubMcpServer()) {
            RunConfig config = config(server.port());
            RunStatus status = new RunStatus();
            status.setRunId(config.getRunId());
            List<TestScenario> scenarios = List.of(
                    scenario("ONE", "https://example.test/one"),
                    scenario("TWO", "https://example.test/two"),
                    scenario("THREE", "https://example.test/three"));

            ItpsMcpRunner runner = new ItpsMcpRunner(new LlmClient(), new ReportService(), new RunStore(),
                    output.toString(), 5, true);
            runner.execute(scenarios, config, status);

            assertThat(status.getStatus()).as(status.getMessage()).isEqualTo("PASSED");
            assertThat(status.getPassed()).isEqualTo(3);
            assertThat(status.getScenarios()).extracting(result -> result.getId())
                    .containsExactly("ONE", "TWO", "THREE");
            assertThat(server.acceptedSessions()).isEqualTo(3);
            assertThat(server.maxConcurrentSessions()).isGreaterThanOrEqualTo(2);
            assertThat(output.resolve(config.getRunId()).resolve("mcp-sessions")).isDirectory();
            assertThat(output.resolve(config.getRunId()).resolve("mcp-transcript.json")).isRegularFile();
        }
    }

    @Test
    void defaultModeRunsEveryScenarioThroughOneSharedBrowserSession() throws Exception {
        try (StubMcpServer server = new StubMcpServer()) {
            RunConfig config = config(server.port());
            config.setRunId("RUN-SHARED-TEST");
            config.setSeparateBrowserPerTest(false);
            config.setParallelExecution(false);
            RunStatus status = new RunStatus();
            status.setRunId(config.getRunId());

            ItpsMcpRunner runner = new ItpsMcpRunner(new LlmClient(), new ReportService(), new RunStore(),
                    output.toString(), 5, true);
            runner.execute(List.of(
                    scenario("ONE", "https://example.test/one"),
                    scenario("TWO", "https://example.test/two"),
                    scenario("THREE", "https://example.test/three")), config, status);

            assertThat(status.getStatus()).as(status.getMessage()).isEqualTo("PASSED");
            assertThat(status.getPassed()).isEqualTo(3);
            assertThat(server.acceptedSessions()).isEqualTo(1);
            assertThat(server.maxConcurrentSessions()).isEqualTo(1);
        }
    }

    private RunConfig config(int port) {
        RunConfig config = new RunConfig();
        config.setRunId("RUN-PARALLEL-TEST");
        config.setMcpMode("external-tcp");
        config.setMcpHost("127.0.0.1");
        config.setMcpPort(port);
        config.setMcpConnectTimeoutSeconds(2);
        config.setBrowserId("vibium-managed-chrome");
        config.setSeparateBrowserPerTest(true);
        config.setParallelExecution(true);
        config.setParallelThreads(3);
        config.setScreenshotMode("NONE");
        config.setUseLlm(false);
        config.setEnableSelfHealing(false);
        config.setRetryDelayMs(100);
        config.setAllowInsecureCertificates(false);
        return config;
    }

    private TestScenario scenario(String id, String url) {
        TestScenario scenario = new TestScenario();
        scenario.setId(id);
        scenario.setName(id);
        scenario.setUrl(url);
        return scenario;
    }

    private static final class StubMcpServer implements AutoCloseable {
        private final ObjectMapper mapper = new ObjectMapper();
        private final ServerSocket server;
        private final ExecutorService clients = Executors.newCachedThreadPool();
        private final Thread acceptThread;
        private final AtomicBoolean closed = new AtomicBoolean();
        private final AtomicInteger active = new AtomicInteger();
        private final AtomicInteger maximum = new AtomicInteger();
        private final AtomicInteger accepted = new AtomicInteger();
        private final List<Socket> sockets = new CopyOnWriteArrayList<>();

        StubMcpServer() throws IOException {
            server = new ServerSocket(0);
            acceptThread = new Thread(this::acceptLoop, "stub-mcp-accept");
            acceptThread.setDaemon(true);
            acceptThread.start();
        }

        int port() { return server.getLocalPort(); }
        int acceptedSessions() { return accepted.get(); }
        int maxConcurrentSessions() { return maximum.get(); }

        private void acceptLoop() {
            while (!closed.get()) {
                try {
                    Socket socket = server.accept();
                    sockets.add(socket);
                    accepted.incrementAndGet();
                    clients.submit(() -> handle(socket));
                } catch (IOException error) {
                    if (!closed.get()) throw new UncheckedIOException(error);
                }
            }
        }

        private void handle(Socket socket) {
            int now = active.incrementAndGet();
            maximum.accumulateAndGet(now, Math::max);
            String currentUrl = "about:blank";
            try (socket;
                 BufferedReader reader = new BufferedReader(new InputStreamReader(socket.getInputStream(), StandardCharsets.UTF_8));
                 BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream(), StandardCharsets.UTF_8))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    JsonNode request = mapper.readTree(line);
                    if (!request.has("id")) continue;
                    String method = request.path("method").asText();
                    ObjectNode result = mapper.createObjectNode();
                    if ("tools/list".equals(method)) {
                        addTool(result, "browser_navigate", "url");
                        addTool(result, "browser_get_url");
                    } else if ("tools/call".equals(method)) {
                        String tool = request.path("params").path("name").asText();
                        if ("browser_navigate".equals(tool)) {
                            currentUrl = request.path("params").path("arguments").path("url").asText();
                            Thread.sleep(250);
                            result = toolResult("Navigated to " + currentUrl);
                        } else if ("browser_get_url".equals(tool)) {
                            result = toolResult(currentUrl);
                        } else {
                            result = toolResult("OK");
                        }
                    }
                    ObjectNode response = mapper.createObjectNode();
                    response.put("jsonrpc", "2.0");
                    response.set("id", request.get("id"));
                    response.set("result", result);
                    writer.write(mapper.writeValueAsString(response));
                    writer.newLine();
                    writer.flush();
                }
            } catch (Exception ignored) {
            } finally {
                active.decrementAndGet();
                sockets.remove(socket);
            }
        }

        private void addTool(ObjectNode result, String name, String... properties) {
            ObjectNode tool = result.withArray("tools").addObject();
            tool.put("name", name);
            tool.put("description", name);
            ObjectNode schema = tool.putObject("inputSchema");
            schema.put("type", "object");
            ObjectNode fields = schema.putObject("properties");
            for (String property : properties) fields.putObject(property).put("type", "string");
        }

        private ObjectNode toolResult(String text) {
            ObjectNode result = mapper.createObjectNode();
            result.put("isError", false);
            result.putArray("content").addObject().put("type", "text").put("text", text);
            return result;
        }

        @Override
        public void close() throws Exception {
            if (!closed.compareAndSet(false, true)) return;
            server.close();
            for (Socket socket : new ArrayList<>(sockets)) {
                try { socket.close(); } catch (Exception ignored) { }
            }
            clients.shutdownNow();
            acceptThread.join(1_000);
        }
    }
}
