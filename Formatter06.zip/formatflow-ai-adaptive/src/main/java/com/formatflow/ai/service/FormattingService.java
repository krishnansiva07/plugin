package com.formatflow.ai.service;

import com.formatflow.ai.model.FormatModels.*;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * Primary formatting workflow.
 *
 * The previous implementation used a preserve-first metadata pipeline. That was
 * useful for strict source fidelity, but it prevented the model from producing
 * the reader-friendly Confluence output users get when prompting the model
 * directly. The active workflow now gives the model editorial freedom first and
 * then sanitizes/renders the result deterministically for the three supported
 * destinations: Confluence, Email and HTML.
 */
@Service
public class FormattingService {

    private static final Set<String> SUPPORTED_FORMATS = Set.of("CONFLUENCE", "EMAIL", "HTML");

    private final SessionKeyService sessionKeyService;
    private final ContentParser contentParser;
    private final LlmOrchestrator llmOrchestrator;
    private final AdaptiveSemanticOrchestrator adaptiveSemanticOrchestrator;
    private final SemanticPresentationPolicy semanticPresentationPolicy;
    private final DocumentAssemblyService documentAssemblyService;
    private final DocumentRenderer renderer;
    private final ContentDiffService diffService;

    public FormattingService(SessionKeyService sessionKeyService,
                             ContentParser contentParser,
                             LlmOrchestrator llmOrchestrator,
                             AdaptiveSemanticOrchestrator adaptiveSemanticOrchestrator,
                             SemanticPresentationPolicy semanticPresentationPolicy,
                             DocumentAssemblyService documentAssemblyService,
                             DocumentRenderer renderer,
                             ContentDiffService diffService) {
        this.sessionKeyService = sessionKeyService;
        this.contentParser = contentParser;
        this.llmOrchestrator = llmOrchestrator;
        // Kept as constructor dependencies for backward binary/source compatibility
        // with the existing project/tests. The new free-form path intentionally no
        // longer runs the old semantic validator after the model has edited content.
        this.adaptiveSemanticOrchestrator = adaptiveSemanticOrchestrator;
        this.semanticPresentationPolicy = semanticPresentationPolicy;
        this.documentAssemblyService = documentAssemblyService;
        this.renderer = renderer;
        this.diffService = diffService;
    }

    public FormatResult format(FormatRequest request, HttpSession session) {
        String apiKey = sessionKeyService.require(session);
        String format = normalizeFormat(request.format());
        String operation = normalizeOperation(request.operation());

        LlmOrchestrator.FreeformOutcome outcome = llmOrchestrator.freeform(
                apiKey,
                request.content(),
                request.audience(),
                request.purpose(),
                format,
                operation,
                request.summaryLength()
        );

        String sanitizedHtml = renderer.sanitizeFreeformHtml(outcome.html());
        String copyText = renderer.freeformCopyText(sanitizedHtml);
        if (copyText.isBlank()) {
            throw new IllegalStateException("The model response could not be converted into readable content.");
        }

        String subject = request.emailSubject() == null ? "" : request.emailSubject().trim();
        int llmCalls = outcome.llmCalls();
        if ("EMAIL".equals(format) && request.generateEmailSubject() && subject.isBlank()) {
            subject = llmOrchestrator.generateEmailSubject(
                    apiKey,
                    copyText,
                    request.audience(),
                    request.purpose()
            );
            llmCalls++;
        }

        String previewHtml = renderer.freeformPreviewHtml(sanitizedHtml, format, subject);
        String copyHtml = renderer.freeformCopyHtml(sanitizedHtml, format);
        ContentStats stats = diffService.compare(request.content(), copyText);

        // The browser now downloads/copies the exact generated HTML directly.
        // A lightweight document object is still returned for API compatibility.
        FormattedDocument document = new FormattedDocument(
                "",
                List.of(),
                List.of(),
                copyText,
                request.audience(),
                request.purpose() == null || request.purpose().isBlank() ? "General" : request.purpose(),
                format,
                operation,
                true,
                subject
        );

        int sourceBlocks = contentParser.parse(request.content()).size();
        ProcessingInfo processing = new ProcessingInfo(
                sourceBlocks,
                llmCalls,
                outcome.chunks(),
                outcome.chunks() > 1,
                outcome.workflowActivity(),
                0,
                List.of(),
                false
        );

        return new FormatResult(
                copyText,
                previewHtml,
                copyHtml,
                copyText,
                stats,
                document,
                processing
        );
    }

    private String normalizeFormat(String value) {
        String format = value == null ? "" : value.trim().toUpperCase(Locale.ROOT);
        if (!SUPPORTED_FORMATS.contains(format)) {
            throw new IllegalArgumentException("Supported outputs are Confluence, Email and HTML.");
        }
        return format;
    }

    private String normalizeOperation(String value) {
        String operation = value == null ? "FORMAT" : value.trim().toUpperCase(Locale.ROOT);
        return "SUMMARIZE".equals(operation) ? "SUMMARIZE" : "FORMAT";
    }
}
