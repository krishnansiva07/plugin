package com.formatflow.ai.service;

import com.formatflow.ai.model.FormatModels.*;
import jakarta.servlet.http.HttpSession;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

class FormattingServicePreserveTest {

    @Test
    void editorialModeUsesFreeformModelOutputAndSkipsLegacySemanticPipeline() {
        SessionKeyService keyService = mock(SessionKeyService.class);
        LlmOrchestrator orchestrator = mock(LlmOrchestrator.class);
        AdaptiveSemanticOrchestrator adaptive = mock(AdaptiveSemanticOrchestrator.class);
        ContentParser parser = new ContentParser();
        IconCatalog icons = new IconCatalog();
        DocumentRenderer renderer = new DocumentRenderer(icons);
        ContentDiffService diff = new ContentDiffService();
        FormattingService service = new FormattingService(
                keyService,
                parser,
                orchestrator,
                adaptive,
                new SemanticPresentationPolicy(),
                new DocumentAssemblyService(),
                renderer,
                diff
        );
        HttpSession session = mock(HttpSession.class);

        String source = "About me application lets employees maintain profiles, access appraisal reviews and track training programs.";
        when(keyService.require(session)).thenReturn("session-key");
        when(orchestrator.freeform(anyString(), anyString(), anyString(), anyString(), anyString(), anyString(), anyString()))
                .thenReturn(new LlmOrchestrator.FreeformOutcome(
                        "<h2>About me</h2><p>A simple employee self-service application.</p><ul><li>Maintain profiles</li><li>Access appraisal reviews</li><li>Track training programs</li></ul>",
                        1,
                        1
                ));

        FormatRequest request = new FormatRequest(
                source, "Co-worker", "Inform", "CONFLUENCE", "FORMAT", "ENHANCE",
                "Short", "Professional Green", "RICH", "", false, false
        );

        FormatResult result = service.format(request, session);
        assertThat(result.previewHtml()).contains("confluence-preview", "About me", "Maintain profiles");
        assertThat(result.copyHtml()).contains("<h2>About me</h2>", "<ul>");
        assertThat(result.finalContent()).contains("About me", "• Maintain profiles");
        assertThat(result.processing().activity()).contains("LangGraph Editorial", "Analyze", "Create", "Review");
        verify(adaptive, never()).analyze(anyString(), anyList(), anyString(), anyString(), anyString(), anyString(), anyBoolean());
    }
}
