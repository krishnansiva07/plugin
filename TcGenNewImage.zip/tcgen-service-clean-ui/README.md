# TCGen Service - Dynamic Excel Column Test Case Generator

TCGen generates test cases from Acceptance Criteria, requirement documents, screenshots/images, and Word documents that contain embedded images. The UI lets the user upload a file, select the file understanding mode, enter their LLM token, optionally override model/base URL, select required Excel columns, add custom columns, preview the dynamic prompt, generate test cases, and export the result to Excel.

## Main Features

- Upload AC/design file from UI using **Browse AC / Image File** button.
- Existing text-based support: TXT, PDF, DOC/DOCX, XLS/XLSX, CSV, JSON, XML, HTML, MD.
- New image upload support: PNG, JPG, JPEG, BMP, TIFF, WEBP.
- New DOCX embedded image support: normal Word text + tables are extracted, then embedded images are OCR-scanned and merged into the LLM prompt.
- File Understanding Mode dropdown:
  - Auto Detect
  - Document / Excel AC
  - Image with AC Text
  - UI Design / Figma Screenshot
  - Word Document with Images
- API key/user token field in UI.
- Model name field in UI.
- Base URL field in UI.
- If UI token/model/base URL is empty, backend falls back to `LLM_API_KEY`, `LLM_MODEL_NAME`, and `LLM_BASE_URL`.
- LangChain4j `OpenAiChatModel` configuration, matching the working setup.
- Dynamic column selection from UI.
- Custom column add option now supports comma/semicolon/newline separated values. Example: `Risk, Sprint, Jira ID`.
- Template buttons: Manual TC, API TC, BDD TC, Regression TC.
- Dynamic prompt preview based on selected columns, file understanding mode and Excel-column mode.
- Reads expected output columns from uploaded Excel files when an `Output_Schema`, `Expected_Columns`, `Columns` or similar sheet is present.
- New API endpoint to detect Excel expected columns before generation.
- LLM prompt uses only selected columns.
- Excel export uses only selected columns plus auto-generated `S.No`.
- Follow-up questions and assumptions are generated when AC/design details are incomplete.
- No hardcoded API key.
- UI preview does not show the temporary "Fix included" information box.


## Expected Columns from Uploaded Excel

TCGen can now use the expected output format directly from the uploaded Excel file.

Recommended Excel structure:

```text
Sheet name: Output_Schema

Column | Description | Example | Mandatory
Test ID | Unique generated test case ID | TC-PO-001 | Yes
Scenario | High-level scenario name | Place order success | Yes
Test Steps | Execution steps | Step 1... | Yes
Expected Result | Expected system behavior | Order created | Yes
Priority | High/Medium/Low | High | Yes
```

Detection rules:

- First preference: `Output_Schema`, `Expected_Columns`, `Output_Columns`, `Columns`, `TestCase_Format` sheet.
- If a sheet has a `Column` / `Expected Column` / `Output Column` header, values below that cell are treated as expected output columns.
- If no schema sheet exists, TCGen scans the first rows of Excel sheets for header-like rows containing known test case fields such as `Test ID`, `Scenario`, `Test Steps`, `Expected Result`, `Priority`.
- `S.No`, `Serial No`, and `Serial Number` are ignored because TCGen auto-generates `S.No` during Excel export.

UI behavior:

- Keep **Use expected columns from uploaded Excel when available** checked.
- Upload the Excel file.
- TCGen will auto-detect columns, or you can click **Load Excel Columns**.
- Detected columns are selected in the UI and used in both the LLM prompt and Excel export.

Custom column input now supports multiple columns in one shot:

```text
Risk, Sprint, Jira ID, Owner, Comments
```

Each value becomes a separate selectable Excel column.

## Image and Word-with-Image Flow

```text
Image / DOCX Upload
    ↓
Document text extraction using Apache Tika
    ↓
Embedded DOCX image extraction using Apache POI
    ↓
OCR extraction using Tess4J / Tesseract
    ↓
Merge normal text + OCR text + user prompt + selected columns
    ↓
LangChain4j OpenAiChatModel
    ↓
JSON test cases
    ↓
UI preview + Excel export
```

## LLM Configuration Used

This version uses LangChain4j directly:

```java
return OpenAiChatModel.builder()
        .apiKey(apiKey)
        .modelName(modelName)
        .baseUrl(baseUrl)
        .temperature(0.7)
        .maxTokens(512)
        .build();
```

The base URL should be the OpenAI-compatible base URL, for example:

```properties
llm.base-url=https://ai4devs.group.echonet/api/v1
```

Do not enter `/chat/completions` in the base URL. LangChain4j handles the chat completion endpoint internally.

## OCR Configuration

This project uses Tess4J/Tesseract for OCR. Install Tesseract OCR on the machine where the Spring Boot app runs.

Typical Windows setup:

```powershell
$env:TCGEN_OCR_TESSDATA_PATH="C:\Program Files\Tesseract-OCR\tessdata"
```

Typical Linux setup:

```bash
export TCGEN_OCR_TESSDATA_PATH=/usr/share/tesseract-ocr/5/tessdata
```

OCR properties:

```properties
tcgen.ocr.enabled=true
tcgen.ocr.language=eng
tcgen.ocr.tessdata-path=
tcgen.ocr.docx-images.enabled=true
tcgen.ocr.docx-images.max-count=20
```

For design screenshots, OCR reads visible text from the image. Pure visual layout understanding, color comparison and spacing validation need Vision AI; OCR alone cannot fully understand those visual aspects.

## Project Structure

```text
tcgen-service-dynamic-columns
├── pom.xml
├── README.md
├── samples
│   └── place_order_acceptance_criteria_sample.xlsx
└── src
    └── main
        ├── java/com/llmart/llm
        │   ├── LlmApplication.java
        │   ├── config/ChatConfig.java
        │   ├── controller/TestCaseController.java
        │   ├── dto/TestCaseGenerationResponse.java
        │   ├── exception
        │   └── service
        │       ├── FileTextExtractor.java
        │       ├── OcrService.java
        │       ├── DocxImageOcrExtractor.java
        │       └── other services
        └── resources
            ├── application.properties
            └── static/index.html
```

## Run Locally

```bash
mvn clean package
```

```bash
java -jar target/tcgen-service-0.0.5-SNAPSHOT.jar \
  --llm.api-key=your-key \
  --llm.model-name=gpt-oss-120b \
  --llm.base-url=https://ai4devs.group.echonet/api/v1
```

Open:

```text
http://localhost:8090
```

## Environment Variable Run

```bash
export LLM_API_KEY="your-key"
export LLM_MODEL_NAME="gpt-oss-120b"
export LLM_BASE_URL="https://ai4devs.group.echonet/api/v1"
export TCGEN_OCR_TESSDATA_PATH="/usr/share/tesseract-ocr/5/tessdata"
java -jar target/tcgen-service-0.0.5-SNAPSHOT.jar
```

For Windows PowerShell:

```powershell
$env:LLM_API_KEY="your-key"
$env:LLM_MODEL_NAME="gpt-oss-120b"
$env:LLM_BASE_URL="https://ai4devs.group.echonet/api/v1"
$env:TCGEN_OCR_TESSDATA_PATH="C:\Program Files\Tesseract-OCR\tessdata"
java -jar target/tcgen-service-0.0.5-SNAPSHOT.jar
```

## Curl Example - Excel/Document AC

```bash
curl -X POST http://localhost:8090/api/testcases/generate \
  -F "file=@samples/place_order_acceptance_criteria_sample.xlsx" \
  -F "apiKey=your-user-token" \
  -F "modelName=gpt-oss-120b" \
  -F "baseUrl=https://ai4devs.group.echonet/api/v1" \
  -F "fileUnderstandingMode=document-ac" \
  -F "useUploadedExcelColumns=true" \
  -F "selectedColumns=Test ID,Module,Requirement ID,Scenario,Precondition,Test Steps,Test Data,Expected Result,Priority,Test Type,Automation Candidate" \
  -F "additionalPrompt=Generate positive, negative, boundary, UI, API, DB, smoke and regression cases"
```

## Curl Example - Image Screenshot

```bash
curl -X POST http://localhost:8090/api/testcases/generate \
  -F "file=@place-order-screen.png" \
  -F "apiKey=your-user-token" \
  -F "modelName=gpt-oss-120b" \
  -F "baseUrl=https://ai4devs.group.echonet/api/v1" \
  -F "fileUnderstandingMode=ui-design" \
  -F "selectedColumns=Test ID,Scenario,Test Steps,Test Data,Expected Result,Priority,Test Type" \
  -F "additionalPrompt=This is Place Order screen. Generate UI validation, positive, negative, boundary and regression test cases."
```

## API Endpoints

### Health

```text
GET /api/testcases/health
```

### Default Columns

```text
GET /api/testcases/columns/defaults
```

### Detect Expected Columns from Uploaded Excel

```text
POST /api/testcases/columns/from-excel
Content-Type: multipart/form-data
```

Form fields:

| Field | Required | Description |
|---|---:|---|
| file | Yes | XLS/XLSX file containing expected columns |

Response:

```json
{
  "columns": ["Test ID", "Scenario", "Test Steps", "Expected Result", "Priority"],
  "message": "Detected 5 expected output columns from uploaded Excel."
}
```

### Generate Test Cases

```text
POST /api/testcases/generate
Content-Type: multipart/form-data
```

Form fields:

| Field | Required | Description |
|---|---:|---|
| file | Yes | AC document, screenshot image, design image or Word file with embedded images |
| apiKey | No | User token/API key. Falls back to configured key. |
| modelName | No | Model name. Falls back to configured model. |
| baseUrl | No | OpenAI-compatible base URL. Falls back to configured URL. |
| fileUnderstandingMode | No | auto, document-ac, image-ac, ui-design, docx-with-images |
| selectedColumns | No | Comma/semicolon/newline separated selected columns. Defaults to manual TC columns. |
| useUploadedExcelColumns | No | true/false. If true and uploaded Excel has expected columns, Excel-defined columns override UI selection. |
| additionalPrompt | No | Additional user instruction |

### Export Excel

```text
POST /api/testcases/export
Content-Type: application/json
```

Body: response JSON from `/generate`.

## Important Security Notes

- Do not hardcode real keys in `application.properties`.
- Do not commit API keys to Git.
- Do not share screenshots containing live tokens.
- If a token was exposed in screenshot/logs, rotate it immediately.
- UI token is sent only for the current request and is not exported to Excel.
