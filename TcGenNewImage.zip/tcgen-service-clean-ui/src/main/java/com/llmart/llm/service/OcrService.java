package com.llmart.llm.service;

import com.llmart.llm.exception.TcgenException;
import net.sourceforge.tess4j.ITesseract;
import net.sourceforge.tess4j.Tesseract;
import net.sourceforge.tess4j.TesseractException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import javax.imageio.ImageIO;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.IOException;

@Service
public class OcrService {

    @Value("${tcgen.ocr.enabled:true}")
    private boolean ocrEnabled;

    @Value("${tcgen.ocr.language:eng}")
    private String language;

    @Value("${tcgen.ocr.tessdata-path:}")
    private String tessDataPath;

    @Value("${tcgen.ocr.minimum-width:900}")
    private int minimumWidth;

    @Value("${tcgen.ocr.minimum-height:600}")
    private int minimumHeight;

    public String extractTextFromImage(byte[] imageBytes, String sourceName) {
        if (!ocrEnabled) {
            throw new TcgenException("OCR is disabled. Enable tcgen.ocr.enabled=true to read image screenshots.");
        }
        if (imageBytes == null || imageBytes.length == 0) {
            return "";
        }

        try {
            BufferedImage image = ImageIO.read(new ByteArrayInputStream(imageBytes));
            if (image == null) {
                return "";
            }

            BufferedImage preparedImage = upscaleIfRequired(image);

            ITesseract tesseract = new Tesseract();
            tesseract.setLanguage(StringUtils.hasText(language) ? language.trim() : "eng");
            if (StringUtils.hasText(tessDataPath)) {
                tesseract.setDatapath(tessDataPath.trim());
            }

            String text = tesseract.doOCR(preparedImage);
            return cleanup(text);
        } catch (TesseractException ex) {
            throw new TcgenException("OCR failed for " + safeName(sourceName) + ". Install Tesseract OCR and configure tcgen.ocr.tessdata-path if required.", ex);
        } catch (IOException ex) {
            throw new TcgenException("Unable to read image file " + safeName(sourceName) + ". Upload a clear PNG, JPG, JPEG, BMP, TIFF or WEBP image.", ex);
        }
    }

    private BufferedImage upscaleIfRequired(BufferedImage image) {
        int width = image.getWidth();
        int height = image.getHeight();
        if (width >= minimumWidth && height >= minimumHeight) {
            return image;
        }

        double widthScale = minimumWidth <= 0 ? 1.0 : (double) minimumWidth / Math.max(width, 1);
        double heightScale = minimumHeight <= 0 ? 1.0 : (double) minimumHeight / Math.max(height, 1);
        double scale = Math.max(1.0, Math.max(widthScale, heightScale));
        scale = Math.min(scale, 3.0);

        int scaledWidth = Math.max(width, (int) Math.round(width * scale));
        int scaledHeight = Math.max(height, (int) Math.round(height * scale));

        BufferedImage scaled = new BufferedImage(scaledWidth, scaledHeight, BufferedImage.TYPE_BYTE_GRAY);
        Graphics2D graphics = scaled.createGraphics();
        graphics.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
        graphics.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
        graphics.drawImage(image, 0, 0, scaledWidth, scaledHeight, null);
        graphics.dispose();
        return scaled;
    }

    private String cleanup(String text) {
        return text == null ? "" : text.replaceAll("\\r", "")
                .replaceAll("[ \\t]+", " ")
                .replaceAll("\\n{3,}", "\\n\\n")
                .trim();
    }

    private String safeName(String sourceName) {
        return StringUtils.hasText(sourceName) ? sourceName : "uploaded image";
    }
}
