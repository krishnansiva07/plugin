#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
ROOT="$PWD/src/main/java/com/llmart/llm"
D=$(mktemp -d)
trap 'rm -rf "$D"' EXIT
mkdir -p "$D/src/com/llmart/llm/service" "$D/src/com/llmart/llm/dto" "$D/src/com/llmart/llm/controller" "$D/src/org/springframework/stereotype" "$D/src/org/springframework/web/bind/annotation" "$D/src/com/fasterxml/jackson/databind" "$D/src/jakarta/validation" "$D/src/jakarta/annotation"
for file in service/TerminalSessionService.java service/AgentApprovalService.java service/AgentApprovalTimeoutException.java service/TerminalWorkspaceDiscoveryService.java controller/TerminalController.java; do cp "$ROOT/$file" "$D/src/com/llmart/llm/${file%/*}/"; done
cat > "$D/src/com/llmart/llm/service/ChatService.java" <<'EOF'
package com.llmart.llm.service;import com.llmart.llm.dto.*;import java.util.function.*;class ChatService {void runTerminal(String a, ChatRequest b, BiConsumer<String,Object> c) {}}
EOF
cat > "$D/src/com/llmart/llm/service/AgentService.java" <<'EOF'
package com.llmart.llm.service;import java.util.*;class AgentService {void stageTransferredPlan(String id,List<String> plan){} void discardTransferredPlan(String id) {}}
EOF
cat > "$D/src/com/llmart/llm/service/AgentRunService.java" <<'EOF'
package com.llmart.llm.service;import java.util.*;class AgentRunService {boolean cancel(String s){return true;} Map<String,Object> status(String s){return Map.of();} AgentRun require(String id){return new AgentRun();} static class AgentRun {String projectId(){return "p";} boolean finished(){return false;}boolean planLocked(){return false;}long mutationRevision(){return 0;}Map<String,Object> snapshot(){return Map.of("plan",List.of(Map.of("text","Do requested step")),"objective","Do requested step");}void checkCancelled(){}}}
EOF
cat > "$D/src/com/llmart/llm/service/AgentQuestionService.java" <<'EOF'
package com.llmart.llm.service;import java.util.*;class AgentQuestionService {boolean answer(String a,String b,String c,String d){return false;} void enable(String id){}void disable(String id){}void cancel(String id){}Map<String,Object> pending(String id){return Map.of();}}
EOF
cat > "$D/src/com/llmart/llm/service/ProjectService.java" <<'EOF'
package com.llmart.llm.service;import com.llmart.llm.dto.*;import java.util.*;class ProjectService {ProjectWorkspace require(String s){return new ProjectWorkspace();}List<ProjectDto> mappedLocalWorkspaces(){return List.of();}}class ProjectWorkspace {boolean hasLocalPath(){return true;}String getLocalPath(){return "/tmp/project";}}
EOF
cat > "$D/src/com/llmart/llm/service/TerminalGitService.java" <<'EOF'
package com.llmart.llm.service;import java.util.*;import java.io.*;public class TerminalGitService {public List<Map<String,Object>> repositories(String id)throws IOException{return List.of();}public Map<String,Object> createBranch(String a,String b,String c)throws IOException{return Map.of();} public Map<String,Object> createWorktree(String a,String b,String c,String d)throws IOException{return Map.of();}}
EOF
cat > "$D/src/com/llmart/llm/service/WorkspaceRootGuard.java" <<'EOF'
package com.llmart.llm.service;import java.nio.file.*;class WorkspaceRootGuard{static Path requireNarrow(Path p){return p;}}
EOF
cat > "$D/src/com/llmart/llm/dto/ProjectDto.java" <<'EOF'
package com.llmart.llm.dto;public record ProjectDto(){}
EOF
cat > "$D/src/com/llmart/llm/dto/ChatSettings.java" <<'EOF'
package com.llmart.llm.dto;public record ChatSettings(String model){}
EOF
cat > "$D/src/com/llmart/llm/dto/ChatRequest.java" <<'EOF'
package com.llmart.llm.dto;import java.util.*;public record ChatRequest(String conversationId,String message,List<String> attachmentIds,String projectId,String mode,Boolean regenerate,ChatSettings settings,List<String> referenceProjectIds,Map<String,String> referenceProjectNames, Boolean documentationTemplateSelected) {}
EOF
cat > "$D/src/com/llmart/llm/dto/MessageDto.java" <<'EOF'
package com.llmart.llm.dto;public record MessageDto(String content) {}
EOF
cat > "$D/src/com/fasterxml/jackson/databind/ObjectMapper.java" <<'EOF'
package com.fasterxml.jackson.databind;import java.io.*;public class ObjectMapper {public <T> T convertValue(Object a, Class<T> c){return null;} public <T> T readValue(File f,Class<T> c){return null;}public void writeValue(File f,Object v) throws IOException{}}
EOF
cat > "$D/src/org/springframework/stereotype/Service.java" <<'EOF'
package org.springframework.stereotype;public @interface Service {}
EOF
for name in RestController RequestMapping PostMapping GetMapping PathVariable RequestParam RequestHeader RequestBody; do cat > "$D/src/org/springframework/web/bind/annotation/$name.java" <<EOF
package org.springframework.web.bind.annotation;public @interface $name {String value() default ""; boolean required() default true;}
EOF
done
cat > "$D/src/jakarta/validation/Valid.java" <<'EOF'
package jakarta.validation;public @interface Valid {}
EOF
cat > "$D/src/jakarta/annotation/PreDestroy.java" <<'EOF'
package jakarta.annotation;public @interface PreDestroy {}
EOF
cat > "$D/src/ApprovalTransferSmoke.java" <<'EOF'
import com.llmart.llm.service.AgentApprovalService;
public class ApprovalTransferSmoke {
 public static void main(String[] args)throws Exception {
   var service=new AgentApprovalService();
   var plan=service.create("run-1","plan_approval","plan",true);
   if(service.transferPlan(plan.id(),"run-2"))throw new AssertionError("Wrong run transferred");
   if(!service.transferPlan(plan.id(),"run-1"))throw new AssertionError("Plan transfer refused");
   if(service.resolve(plan.id(), AgentApprovalService.Decision.ONCE))throw new AssertionError("Transferred approval executed twice");
   if(service.await(plan.id(),java.time.Duration.ofSeconds(1))!=AgentApprovalService.Decision.TRANSFER)throw new AssertionError("Bad transfer decision");
   var delete=service.create("run-1","file_deletion","delete",false);
   if(service.transferPlan(delete.id(),"run-1"))throw new AssertionError("Deletion approval transferred as a plan");
   System.out.println("PASS: approval handoff rejects wrong run, disallows double approval, protects deletion policy");
 }
}
EOF
mkdir -p "$D/classes"
javac --release 17 -d "$D/classes" $(find "$D/src" -name '*.java')
java -cp "$D/classes" ApprovalTransferSmoke
printf 'PASS: Terminal service, controller, workspace discovery and approval types compile under Java 17 stubs\n'
