const {test} = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const app = fs.readFileSync('src/main/resources/static/app.js','utf8');
const html = fs.readFileSync('src/main/resources/static/index.html','utf8');
const sessions = fs.readFileSync('src/main/java/com/llmart/llm/service/TerminalSessionService.java','utf8');
const approval = fs.readFileSync('src/main/java/com/llmart/llm/service/AgentApprovalService.java','utf8');
const agent = fs.readFileSync('src/main/java/com/llmart/llm/service/AgentService.java','utf8');
const controller = fs.readFileSync('src/main/java/com/llmart/llm/controller/TerminalController.java','utf8');
const discovery = fs.readFileSync('src/main/java/com/llmart/llm/service/TerminalWorkspaceDiscoveryService.java','utf8');
const projects = fs.readFileSync('src/main/java/com/llmart/llm/service/ProjectService.java','utf8');

test('Terminal task payload uses the draft workspace, reference paths and model without altering Chat workspace',()=>{
  const begin = app.indexOf('function terminalPayload(');
  const end = app.indexOf("$('launchTerminalBtn').addEventListener",begin);
  assert(begin>=0 && end>begin);
  const values = {
    terminalWorkspaceSelect:{value:'id-selected'}, terminalModelSelect:{value:'agent-ui'}
  };
  const currentProject = {id:'chat-primary'};
  const context = {
    state:{conversationId:'source-chat', project:currentProject, referenceProjects:[{id:'base-ref',name:'Base'}],
      config:{baseUrl:'https://example.invalid',model:'main-model',chatModel:'chat-model',temperature:0.2,maxTokens:0,agentAllowCommands:true}},
    terminalUi:{draft:{projectId:'isolated-project',referenceProjectIds:['ref-a','ref-b'],referenceProjectNames:{'ref-a':'A','ref-b':'B'},model:'agent-custom'},pendingProjectId:null},
    $: id => values[id] || {value:''},modelContextWindowsSetting:()=>'',modelTypesSetting:()=>'',currentFallbackModels:()=>[],
    Boolean, Object
  };
  vm.createContext(context);
  vm.runInContext(app.slice(begin,end),context);
  const payload=context.terminalPayload('Review code');
  assert.equal(payload.projectId,'isolated-project');
  assert.equal(payload.settings.model,'agent-custom');
  assert.deepEqual(Array.from(payload.referenceProjectIds),['ref-a','ref-b']);
  assert.equal(payload.referenceProjectNames['ref-b'],'B');
  assert.equal(payload.settings.agentPlanApproval,false);
  assert.equal(context.state.project,currentProject);
  const anchored=context.terminalPayload('Follow-up',{projectId:'worktree',referenceProjectIds:['legacy'],referenceProjectNames:{legacy:'Old'}});
  assert.equal(anchored.projectId,'worktree');
  assert.deepEqual(Array.from(anchored.referenceProjectIds),['legacy']);
});

test('Duplicate and Fork open a fresh independent, user-initiated session with captured configuration',()=>{
  assert.match(html,/id="terminalDuplicateTab"/);
  assert.match(html,/id="terminalForkTab"/);
  assert.match(html,/id="terminalModelSelect"/);
  assert.match(app,/terminalUi\.draft = \{projectId:prior\.projectId/);
  assert.match(app,/terminalUi\.selected = null; terminalUi\.detail = null;/);
  assert.match(app,/model:prior\.model \|\| state\.config\.model/);
  assert.match(app,/Previous result:/);
  assert.match(app,/No existing task or conversation is copied/);
  assert.match(sessions,/String conversationId = UUID\.randomUUID\(\).toString\(\)/);
  assert.match(sessions,/result\.put\("model",model\)/);
});

test('Agent plan transfer is a distinct atomic decision: no second plan approval or duplicate execution',()=>{
  assert.match(html,/id="launchTerminalBtn"/);
  assert.match(app,/data-agent-to-terminal/);
  assert.match(app,/await savePlanEditor\(editor, true\)/);
  assert.match(app,/\/api\/terminal\/transfer/);
  assert.match(controller,/@PostMapping\("\/transfer"\)/);
  assert.match(approval,/boolean transferPlan\(String approvalId, String runId\)/);
  assert.match(approval,/"plan_approval"\.equals\(item\.tool\(\)\)/);
  assert.match(agent,/Decision\.TRANSFER/);
  assert.match(agent,/transferredPlans\.remove\(request\.conversationId\(\)\)/);
  assert.match(sessions,/approvals\.transferPlan\(approvalId, sourceRunId\)/);
  assert.match(sessions,/agent\.stageTransferredPlan\(conversationId, copiedPlan\)/);
  assert.match(sessions,/source\.planLocked\(\) \|\| source\.mutationRevision\(\) != 0/);
});

test('Global execution monitor polls when dock hidden and exposes per-task step progress and attention requests',()=>{
  for (const id of ['executionMonitorBtn','executionMonitorCount','executionMonitorPanel','executionMonitorItems','executionMonitorClose'])
    assert(html.includes(`id="${id}"`));
  assert.match(app,/function pollExecutionMonitor\(/);
  assert.match(app,/setInterval\(\(\)=>void pollExecutionMonitor\(\), 2500\)/);
  assert.match(app,/session\.completedSteps/);
  assert.match(app,/execution-monitor-progress/);
  assert.match(app,/status === 'needs_input'/);
  assert.match(app,/Terminal \$\{s\.status\}/);
  assert.match(sessions,/"progressPercent", "progressPhase", "progressDetail", "activePlanIndex"/);
  assert.match(sessions,/"completedSteps"/);
});

test('Workspace choices are independent and capability discovery does not require selected Chat project',()=>{
  assert.match(html,/id="terminalWorkspaceSelect"/);
  assert.match(html,/id="terminalReferences"/);
  assert.match(app,/\/api\/terminal\/workspaces/);
  assert.match(controller,/@GetMapping\("\/workspaces"\)/);
  assert.match(discovery,/mappedWorkspaces\(\)/);
  assert.match(projects,/mappedLocalWorkspaces\(\)/);
  assert.match(app,/\$\('terminalWorkspaceSelect'\)\.value/);
  assert.match(sessions,/workspaceLanes\.computeIfAbsent/);
  assert.match(sessions,/newFixedThreadPool\(12/);
});
