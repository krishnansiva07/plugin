package com.llmart.llm.service;

import org.springframework.stereotype.Service;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.TimeUnit;

/** Explicit, bounded Git operations for a selected repository within a multi-repo workspace. */
@Service
public class TerminalGitService {
    private static final Set<String> SKIP = Set.of("node_modules","target","build","dist","vendor", ".venv",".gradle",".idea","coverage",".next",".cache");
    private final ProjectService projects;
    public TerminalGitService(ProjectService projects) { this.projects = projects; }

    public List<Map<String,Object>> repositories(String projectId) throws IOException {
        Path root = root(projectId);
        List<Path> candidates = new ArrayList<>();
        // WalkFileTree prunes huge dependency/Git directories instead of visiting their children.
        final int[] checked = {0};
        Files.walkFileTree(root, EnumSet.noneOf(FileVisitOption.class), 6, new SimpleFileVisitor<>() {
            @Override public FileVisitResult preVisitDirectory(Path dir, java.nio.file.attribute.BasicFileAttributes attrs) {
                if (++checked[0] > 25_000 || candidates.size() >= 80) return FileVisitResult.TERMINATE;
                if (!dir.equals(root)) {
                    String name = dir.getFileName().toString().toLowerCase(Locale.ROOT);
                    if (SKIP.contains(name) || name.equals(".git") || name.equals(".svn") || name.equals(".hg"))
                        return FileVisitResult.SKIP_SUBTREE;
                }
                if (Files.exists(dir.resolve(".git"), LinkOption.NOFOLLOW_LINKS)) candidates.add(dir);
                return FileVisitResult.CONTINUE;
            }
        });
        List<Map<String,Object>> found = new ArrayList<>();
        for (Path path : candidates) {
            try {
                Path real = path.toRealPath();
                Path reported = Path.of(git(real, 8, "rev-parse", "--show-toplevel").trim()).toRealPath();
                if (!real.startsWith(root) || !reported.equals(real)) continue;
                String branch = git(real, 8, "branch", "--show-current").trim();
                Map<String,Object> entry = new LinkedHashMap<>();
                entry.put("path", root.relativize(real).toString().replace('\\','/').isEmpty() ? "." : root.relativize(real).toString().replace('\\','/'));
                entry.put("branch", branch.isEmpty() ? "(detached)" : branch);
                entry.put("dirty", !git(real, 8, "status", "--porcelain", "--untracked-files=no").isBlank());
                found.add(entry);
            } catch (IOException ignored) { /* Ignore incomplete/broken repositories without losing other results. */ }
        }
        return found;
    }

    public Map<String,Object> createBranch(String projectId, String repository, String name) throws IOException {
        Path path = repo(projectId, repository);
        branchName(path, name);
        // git branch changes only repository metadata; it does NOT silently switch the user's checked-out files.
        git(path, 15, "branch", name);
        return Map.of("repository", repository, "branch", name, "action", "created", "checkedOut", false);
    }

    /** Create a distinct branch and an independent working tree, without changing the user's checkout. */
    public Map<String,Object> createWorktree(String projectId, String repository, String branch, String conversationId) throws IOException {
        Path repo = repo(projectId, repository);
        branchName(repo, branch);
        Path destinationRoot = Path.of(System.getProperty("eliya.terminal.worktrees", "./data/terminal-worktrees"))
                .toAbsolutePath().normalize();
        Files.createDirectories(destinationRoot);
        Path destination = destinationRoot.resolve(UUID.randomUUID().toString());
        try {
            git(repo, 45, "worktree", "add", "-b", branch, destination.toString(), "HEAD");
            // ProjectService creates the writable mapping so the existing Agent engine works unchanged.
            var mapped = projects.createLocal(conversationId, destination.toString(), "Terminal: " + branch);
            return Map.of("repository", repository, "branch", branch, "projectId", mapped.id(),
                    "path", destination.toString(), "action", "worktree_created");
        } catch (Exception ex) {
            // If Git created a worktree but project registration failed, remove its registration/files safely.
            if (Files.exists(destination)) {
                try { git(repo, 20, "worktree", "remove", "--force", destination.toString()); }
                catch (Exception ignored) { /* report the original error; manual cleanup may be needed */ }
            }
            if (ex instanceof IOException io) throw io;
            throw new IOException("Cannot register the new worktree: " + ex.getMessage(), ex);
        }
    }

    private Path repo(String projectId, String relative) throws IOException {
        Path root = root(projectId);
        if (relative == null || relative.isBlank() || relative.indexOf('\0') >= 0) throw new IllegalArgumentException("Select a repository");
        Path candidate = root.resolve(relative).normalize();
        if (!candidate.startsWith(root) || !Files.isDirectory(candidate, LinkOption.NOFOLLOW_LINKS))
            throw new SecurityException("Selected repository is outside workspace");
        Path real = candidate.toRealPath();
        if (!real.startsWith(root) || !Files.exists(real.resolve(".git"), LinkOption.NOFOLLOW_LINKS))
            throw new SecurityException("Select a discovered repository inside the workspace");
        if (!Path.of(git(real, 8, "rev-parse", "--show-toplevel").trim()).toRealPath().equals(real))
            throw new SecurityException("Path does not identify the selected repository root");
        return real;
    }
    private Path root(String id) throws IOException {
        if (id == null || id.isBlank()) throw new IllegalArgumentException("Select a local workspace");
        var project = projects.require(id);
        if (!project.hasLocalPath()) throw new IllegalArgumentException("Select a local workspace");
        Path root = WorkspaceRootGuard.requireNarrow(Path.of(project.getLocalPath()).toRealPath());
        if (!Files.isDirectory(root)) throw new IllegalArgumentException("Workspace is unavailable");
        return root;
    }
    private static void branchName(Path repo, String name) throws IOException {
        if (name == null || name.isBlank() || name.length() > 150 || name.startsWith("-") || name.contains(".."))
            throw new IllegalArgumentException("Enter a valid branch name");
        git(repo, 8, "check-ref-format", "--branch", name);
        try { git(repo, 8, "show-ref", "--verify", "--quiet", "refs/heads/" + name); }
        catch (IOException notFound) { return; }
        throw new IllegalArgumentException("Branch already exists: " + name);
    }
    private static String git(Path cwd, int seconds, String... args) throws IOException {
        List<String> command = new ArrayList<>(); command.add("git"); command.add("-C"); command.add(cwd.toString());
        command.addAll(List.of(args));
        ProcessBuilder builder = new ProcessBuilder(command).redirectErrorStream(true);
        builder.environment().put("GIT_TERMINAL_PROMPT", "0");
        Process process = builder.start();
        ByteArrayOutputStream output = new ByteArrayOutputStream();
        Thread capture = new Thread(() -> { try (InputStream in = process.getInputStream()) {
            byte[] buffer = new byte[4096]; int n; long total = 0;
            while ((n = in.read(buffer)) >= 0) { if (total < 32768) output.write(buffer, 0, (int)Math.min(n, 32768-total)); total += n; }
        } catch (IOException ignored) {} }, "eliya-git-capture");
        capture.setDaemon(true); capture.start();
        try {
            if (!process.waitFor(seconds, TimeUnit.SECONDS)) {
                process.destroyForcibly(); throw new IOException("Git command timed out after " + seconds + " seconds");
            }
            capture.join(1200);
        } catch (InterruptedException ex) {
            process.destroyForcibly(); Thread.currentThread().interrupt(); throw new IOException("Git operation interrupted", ex);
        }
        String text = output.toString(StandardCharsets.UTF_8);
        if (process.exitValue() != 0) throw new IOException("Git operation failed: " + text.strip());
        return text;
    }
}
