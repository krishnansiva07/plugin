package com.llmart.llm.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.llmart.llm.dto.ChatRequest;
import com.llmart.llm.dto.ChatSettings;
import org.springframework.stereotype.Service;
import java.io.IOException;
import java.nio.file.*;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.*;

/**
 * Independent, bounded Terminal Agent sessions. No second planner: each session uses the same
 * AgentService/AgentRunService via ChatService but explicitly disables only plan approval.
 * In-flight terminal sessions are detached from browser connections. On restart they are marked
 * interrupted; they are never falsely claimed to be resumed OS processes.
 */
@Service
public class TerminalSessionService {
    private static final int MAX_EVENTS = 400;
    private static final int MAX_SESSIONS = 500;
    private static final int MAX_RESULT_CHARS = 600_000;
    private final ConcurrentHashMap<String, Session> sessions = new ConcurrentHashMap<>();
    private final Object gitMutationLock = new Object();
    // Until worktree isolation is available, tasks targeting the same writable root are serialized.
    // Distinct local workspaces still execute concurrently; read-only shared references never lock.
    private final ConcurrentHashMap<String, java.util.concurrent.Semaphore> workspaceLanes = new ConcurrentHashMap<>();
    // At most 12 active sessions: blocked same-root lanes never monopolize the pool
    // and starve a new Terminal in a different workspace.
    private final ExecutorService workers = Executors.newFixedThreadPool(12, r -> {
        Thread t = new Thread(r, "eliya52-terminal-manager"); t.setDaemon(true); return t;
    });
    private final ChatService chat;
    private final AgentRunService agentRuns;
    private final AgentQuestionService questions;
    private final AgentService agent;
    private final AgentApprovalService approvals;
    private final ProjectService projects;
    private final ObjectMapper mapper;
    private final Path store;

    public TerminalSessionService(ChatService chat, AgentRunService agentRuns, ObjectMapper mapper,
                                  AgentQuestionService questions, ProjectService projects,
                                  AgentService agent, AgentApprovalService approvals) {
        this.chat = chat; this.agentRuns = agentRuns; this.mapper = mapper;
        this.questions = questions; this.projects = projects; this.agent = agent; this.approvals = approvals;
        store = Path.of(System.getProperty("eliya.terminal.store", "./data/terminal-sessions")).toAbsolutePath().normalize();
        try {
            Files.createDirectories(store);
            try (var files = Files.list(store)) {
                files.filter(f -> f.getFileName().toString().endsWith(".json")).limit(250).forEach(f -> {
                    try {
                        @SuppressWarnings("unchecked") Map<String,Object> saved = mapper.readValue(f.toFile(), Map.class);
                        Session recovered = Session.fromSaved(saved);
                        if (recovered != null) sessions.put(recovered.id, recovered);
                    } catch (Exception ignored) { /* corrupt history must not prevent application startup */ }
                });
            }
        } catch (IOException ignored) { /* transient sessions still work */ }
    }

    private String canonicalWorkspaceKey(String projectId) {
        try {
            var selected = projects.require(projectId);
            return selected.hasLocalPath() ? Path.of(selected.getLocalPath()).toRealPath().toString() : projectId;
        } catch (Exception e) { return projectId; }
    }
    /** Git metadata updates are disallowed while an Agent is operating on the selected workspace. */
    public void requireWorkspaceIdle(String projectId) {
        String key = canonicalWorkspaceKey(projectId);
        if (sessions.values().stream().anyMatch(s -> s.projectId != null
                && Set.of("queued", "waiting_workspace", "running", "needs_input", "cancelling").contains(s.status)
                && key.equals(canonicalWorkspaceKey(s.projectId))))
            throw new IllegalStateException("Stop running Terminal tasks before changing Git branches in this workspace");
    }
    public Map<String,Object> answer(String sessionId, String questionId, String choice, String detail) {
        Session s = require(sessionId);
        if (s.runId.isBlank() || !questions.answer(s.runId, questionId, choice, detail))
            throw new IllegalArgumentException("Question has expired or the response is invalid");
        if ("Cancel".equalsIgnoreCase(choice)) {
            s.cancelRequested = true;
            agentRuns.cancel(s.runId);
            s.status = "cancelling";
        } else s.status = "running";
        s.question = Map.of(); s.touch(); persist(s);
        return s.snapshot();
    }
    public <T> T withGitWorkspaceLock(String projectId, java.util.concurrent.Callable<T> operation) throws IOException {
        synchronized (gitMutationLock) {
            requireWorkspaceIdle(projectId);
            try { return operation.call(); }
            catch (IOException e) { throw e; }
            catch (Exception e) { throw new IOException("Git operation did not complete: " + e.getMessage(), e); }
        }
    }
    /** User explicitly chooses Terminal on the source Agent's pending plan screen. */
    public synchronized Map<String,Object> transfer(String key, String sourceRunId, String approvalId, ChatRequest request) {
        if (key == null || key.isBlank() || request == null || request.settings() == null)
            throw new IllegalArgumentException("Model configuration required");
        if (workers.isShutdown() || sessions.values().stream().filter(session ->
                Set.of("queued","waiting_workspace","running","cancelling").contains(session.status)).count() >= 12)
            throw new IllegalStateException("Terminal capacity unavailable; source approval remains active");
        AgentRunService.AgentRun source = agentRuns.require(sourceRunId);
        Map<String,Object> snapshot = source.snapshot();
        if (!Objects.equals(source.projectId(), request.projectId()))
            throw new IllegalArgumentException("Handoff workspace differs from source Agent workspace");
        if (source.finished() || source.planLocked() || source.mutationRevision() != 0)
            throw new IllegalStateException("Source Agent has already started or finished; plan cannot be transferred");
        List<String> plan = new ArrayList<>();
        Object rawPlan = snapshot.get("plan");
        if (rawPlan instanceof List<?> items) for (Object item : items) {
            if (item instanceof Map<?,?> row && row.get("text") instanceof String step && !step.isBlank()) plan.add(step);
        }
        if (plan.isEmpty()) throw new IllegalStateException("Source Agent has no executable plan");
        String objective = String.valueOf(snapshot.getOrDefault("objective", ""));
        if (objective.isBlank()) throw new IllegalStateException("Source Agent objective missing; transfer denied");
        ChatRequest preserved = new ChatRequest(request.conversationId(), objective, List.of(),
                request.projectId(), "agent", false, request.settings(), request.referenceProjectIds(),
                request.referenceProjectNames(), request.documentationTemplateSelected());
        if (!approvals.transferPlan(approvalId, sourceRunId))
            throw new IllegalStateException("Plan approval is no longer pending; nothing transferred");
        Map<String,Object> result = launchInternal(key, preserved, plan);
        result.put("sourceRunId", sourceRunId);
        return result;
    }

    public Map<String,Object> launch(String key, ChatRequest request) {
        return launchInternal(key, request, null);
    }

    private Map<String,Object> launchInternal(String key, ChatRequest request, List<String> copiedPlan) {
        if (key == null || key.isBlank()) throw new IllegalArgumentException("Model API key is required");
        if (request == null || request.settings() == null || request.message() == null || request.message().isBlank())
            throw new IllegalArgumentException("Terminal requires an instruction and configured model");
        if (sessions.values().stream().filter(s -> Set.of("queued","waiting_workspace","running","cancelling").contains(s.status)).count() >= 12)
            throw new IllegalStateException("Too many active terminal tasks; stop or finish a task before starting another");
        String id = UUID.randomUUID().toString();
        // A unique conversation prevents context/cancellation collision between simultaneous Terminal sessions.
        // Local workspace IDs remain explicitly reusable across conversations by ProjectService.
        String conversationId = UUID.randomUUID().toString();
        @SuppressWarnings("unchecked") Map<String,Object> settings = mapper.convertValue(request.settings(), Map.class);
        settings.put("agentPlanApproval", false);
        ChatSettings agentSettings = mapper.convertValue(settings, ChatSettings.class);
        ChatRequest agentRequest = new ChatRequest(conversationId, request.message(),
                // Attachments belong to the source conversation, so do not silently copy private attachment IDs.
                List.of(), request.projectId(), "agent", false, agentSettings,
                request.referenceProjectIds(), request.referenceProjectNames(), request.documentationTemplateSelected());
        Session session = new Session(id, conversationId, request.message(), request.projectId(),
                request.referenceProjectIds() == null ? List.of() : List.copyOf(request.referenceProjectIds()),
                request.referenceProjectNames() == null ? Map.of() : Map.copyOf(request.referenceProjectNames()),
                request.settings().model());
        synchronized (gitMutationLock) {
            sessions.put(id, session);
            pruneHistory();
            persist(session);
            if (copiedPlan != null) agent.stageTransferredPlan(conversationId, copiedPlan);
            workers.execute(() -> {
            java.util.concurrent.Semaphore lane = (session.projectId == null || session.projectId.isBlank()) ? null
                    : workspaceLanes.computeIfAbsent(canonicalWorkspaceKey(session.projectId), ignored -> new java.util.concurrent.Semaphore(1, true));
            boolean acquired = false;
            try {
                if (lane != null) {
                    if (!lane.tryAcquire()) {
                        session.status = "waiting_workspace"; session.touch(); persist(session);
                        lane.acquire();
                    }
                    acquired = true;
                }
                if (session.cancelRequested || "cancelled".equals(session.status)) return;
                session.status = "running"; session.touch(); persist(session);
                chat.runTerminal(key, agentRequest, (type, body) -> {
                    session.accept(type, body);
                    if ("meta".equals(type) && !session.runId.isBlank()) questions.enable(session.runId);
                    if (session.cancelRequested && !session.runId.isBlank()) agentRuns.cancel(session.runId);
                    if ("done".equals(type) && !session.runId.isBlank()) {
                        try {
                            String actual = String.valueOf(agentRuns.status(session.runId).get("status"));
                            if (Set.of("failed","cancelled","blocked","interrupted").contains(actual)) session.status=actual;
                            Map<String,Object> runState = agentRuns.status(session.runId);
                            boolean noChanges = runState.get("mutationRevision") instanceof Number n && n.longValue() == 0
                                    && runState.get("totalToolActions") instanceof Number actions && actions.longValue() == 0;
                            String validation = String.valueOf(runState.getOrDefault("planValidationStatus", "not_run"));
                            if (noChanges && Set.of("failed","blocked").contains(session.status)
                                    && !"approved".equals(validation)) {
                                String reason = String.valueOf(runState.getOrDefault("planValidationSummary", ""));
                                if (reason.isBlank()) reason = String.valueOf(runState.getOrDefault("lastRecoveryAnalysis", ""));
                                if (reason.isBlank()) reason = "The requested plan did not pass validation.";
                                session.status = "needs_input";
                                session.question = Map.of(
                                    "kind", "plan_correction", "reason", reason.length() > 1500 ? reason.substring(0,1500) : reason,
                                    "proposal", "Regenerate a task-relevant plan that explicitly addresses the validation findings, preserves all original requirements, and does not omit requested source evidence. Do not modify workspace files until the new plan passes validation.",
                                    "note", "The original plan failed before recorded workspace modifications. Continuing starts a new linked run rather than resuming the failed planner process.");
                            }
                        } catch (Exception ignored) { /* persisted event remains authoritative if status lookup failed */ }
                    }
                    if ("meta".equals(type) || "done".equals(type) || "error".equals(type) || "stopped".equals(type)
                            || ("agent_step".equals(type) && session.sequence % 15 == 0)
                            || ("token".equals(type) && session.sequence % 100 == 0)) persist(session);
                });
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                session.status = "interrupted"; session.error = "Terminal worker was interrupted";
                session.touch(); persist(session);
            } catch (Exception e) {
                session.status = "failed";
                session.error = e.getMessage() == null ? "Unable to launch Terminal" : e.getMessage();
                session.touch(); persist(session);
            } finally {
                agent.discardTransferredPlan(conversationId);
                if (!session.runId.isBlank()) questions.disable(session.runId);
                if (acquired) lane.release();
            }
            });
        }
        return session.snapshot();
    }

    public List<Map<String,Object>> list() {
        return sessions.values().stream().sorted(Comparator.comparing((Session s) -> s.createdAt).reversed())
                .limit(100).map(session -> {
                    Map<String,Object> summary = session.summary();
                    if (!session.runId.isBlank() && Set.of("queued", "waiting_workspace", "running", "needs_input", "cancelling")
                            .contains(session.status)) try {
                        Map<String,Object> run = agentRuns.status(session.runId);
                        for (String field : List.of("progressPercent", "progressPhase", "progressDetail", "activePlanIndex"))
                            if (run.containsKey(field)) summary.put(field, run.get(field));
                        if (run.get("plan") instanceof List<?> steps) {
                            summary.put("stepCount", steps.size());
                            summary.put("completedSteps", steps.stream().filter(step -> step instanceof Map<?,?> m
                                    && "completed".equals(m.get("status"))).count());
                        }
                    } catch (Exception ignored) { /* run initializing or history pruned */ }
                    return summary;
                }).toList();
    }

    public Map<String,Object> get(String id) {
        Session s = require(id);
        Map<String,Object> result = s.snapshot();
        if (!s.runId.isBlank()) {
            Map<String,Object> pending = questions.pending(s.runId);
            if (!pending.isEmpty()) {
                result.put("status", "needs_input"); result.put("question", pending);
            }
            try {
                Map<String,Object> state = agentRuns.status(s.runId);
                Map<String,Object> progress = new LinkedHashMap<>();
                for (String field : List.of("status","progressPercent","progressPhase","progressDetail",
                        "planValidationStatus","planValidationSummary","activePlanIndex","plan","tokenUsage"))
                    if (state.containsKey(field)) progress.put(field,state.get(field));
                result.put("progress",progress);
            } catch (Exception ignored) { /* may be pending initialization */ }
        }
        return result;
    }
    public Map<String,Object> cancel(String id) {
        Session s = require(id);
        s.cancelRequested = true;
        if (s.runId != null && !s.runId.isBlank()) { agentRuns.cancel(s.runId); questions.cancel(s.runId); }
        if (Set.of("needs_input", "queued", "waiting_workspace").contains(s.status)) {
            s.status = "cancelled"; s.touch(); persist(s);
        } else if ("running".equals(s.status)) {
            s.status = "cancelling"; s.touch(); persist(s);
        }
        return s.snapshot();
    }
    private Session require(String id) {
        Session s = sessions.get(id);
        if (s == null) throw new NoSuchElementException("Terminal session not found");
        return s;
    }
    private void persist(Session s) {
        synchronized (s) {
            try {
                Files.createDirectories(store);
                Path tmp = store.resolve(s.id + ".json.tmp");
                mapper.writeValue(tmp.toFile(), s.snapshot());
                try { Files.move(tmp, store.resolve(s.id + ".json"), StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
                catch (AtomicMoveNotSupportedException ex) { Files.move(tmp, store.resolve(s.id + ".json"), StandardCopyOption.REPLACE_EXISTING); }
            } catch (Exception ignored) { /* keep working even when logging cannot persist */ }
        }
    }

    private void pruneHistory() {
        if (sessions.size() <= MAX_SESSIONS) return;
        sessions.values().stream()
                .filter(s -> !Set.of("queued", "waiting_workspace", "running", "needs_input", "cancelling").contains(s.status))
                .sorted(Comparator.comparing(s -> s.createdAt))
                .limit(sessions.size() - MAX_SESSIONS)
                .forEach(s -> {
                    if (sessions.remove(s.id, s)) {
                        try { Files.deleteIfExists(store.resolve(s.id + ".json")); }
                        catch (IOException ignored) { /* bounded memory is more important than a failed cleanup */ }
                    }
                });
    }

    @jakarta.annotation.PreDestroy
    public void shutdown() {
        for (Session s : sessions.values()) {
            if (Set.of("queued", "waiting_workspace", "running", "needs_input", "cancelling").contains(s.status)) {
                s.cancelRequested = true;
                if (!s.runId.isBlank()) { agentRuns.cancel(s.runId); questions.disable(s.runId); }
                s.status = "interrupted"; s.touch(); persist(s);
            }
        }
        workers.shutdownNow();
    }

    private static final class Session {
        final String id, conversationId, prompt, projectId, createdAt, model;
        final List<String> referenceProjectIds;
        final Map<String,String> referenceProjectNames;
        final ArrayDeque<Map<String,Object>> events = new ArrayDeque<>();
        String status = "queued", error = "", runId = "", answer = "", updatedAt;
        volatile boolean cancelRequested;
        Map<String,String> question = Map.of();
        long sequence;
        Session(String id, String conversationId, String prompt, String projectId,
                List<String> refs, Map<String,String> names, String model) {
            this(id, conversationId, prompt, projectId, refs, names, model, Instant.now().toString());
        }
        Session(String id, String conversationId, String prompt, String projectId,
                List<String> refs, Map<String,String> names, String model, String originalCreatedAt) {
            this.id=id; this.conversationId=conversationId; this.prompt=prompt; this.projectId=projectId;
            this.model=model == null ? "" : model;
            this.referenceProjectIds=refs; this.referenceProjectNames=names;
            this.createdAt=originalCreatedAt == null || originalCreatedAt.isBlank()
                    ? Instant.now().toString() : originalCreatedAt;
            this.updatedAt=createdAt;
        }
        synchronized void touch() { updatedAt=Instant.now().toString(); }
        synchronized void accept(String type, Object body) {
            if ("meta".equals(type) && body instanceof Map<?,?> m) runId=String.valueOf(m.containsKey("agentRunId") ? m.get("agentRunId") : "");
            if ("token".equals(type) && body instanceof Map<?,?> m) {
                Object text = m.get("text");
                if (text != null) answer = truncate(answer + text);
            }
            if ("done".equals(type)) {
                if (body instanceof com.llmart.llm.dto.MessageDto dto && dto.content() != null) answer = truncate(dto.content());
                status = "completed";
            }
            if ("error".equals(type)) { status="failed"; error=String.valueOf(body); }
            if ("stopped".equals(type)) status="cancelled";
            sequence++;
            Map<String,Object> event=new LinkedHashMap<>();
            event.put("seq",sequence); event.put("type", type);
            if (!"token".equals(type)) event.put("data", body);
            events.addLast(event);
            while (events.size()>MAX_EVENTS) events.removeFirst();
            touch();
        }
        static String truncate(String text) {
            return text.length() > MAX_RESULT_CHARS ? text.substring(text.length()-MAX_RESULT_CHARS) : text;
        }
        synchronized Map<String,Object> summary() {
            Map<String,Object> result=new LinkedHashMap<>();
            result.put("id",id); result.put("status",status); result.put("runId",runId);
            result.put("prompt",prompt.length() > 180 ? prompt.substring(0,180) + "…" : prompt);
            result.put("projectId",projectId); result.put("model",model); result.put("createdAt",createdAt); result.put("updatedAt",updatedAt);
            return result;
        }
        synchronized Map<String,Object> snapshot() {
            Map<String,Object> result=new LinkedHashMap<>(summary());
            result.put("conversationId",conversationId);
            result.put("fullPrompt",prompt);
            result.put("referenceProjectIds",referenceProjectIds);
            result.put("referenceProjectNames",referenceProjectNames);
            result.put("answer",answer); result.put("error",error);
            result.put("question",question);
            result.put("sequence",sequence); result.put("events",List.copyOf(events));
            return result;
        }
        static Session fromSaved(Map<String,Object> saved) {
            if (saved == null || !(saved.get("id") instanceof String id) || !id.matches("[a-f0-9-]{36}")) return null;
            @SuppressWarnings("unchecked") List<String> refs=saved.get("referenceProjectIds") instanceof List<?> list
                    ? list.stream().filter(String.class::isInstance).map(String.class::cast).toList(): List.of();
            Map<String,String> aliases = new LinkedHashMap<>();
            if (saved.get("referenceProjectNames") instanceof Map<?,?> names) {
                for (var e : names.entrySet()) if (e.getKey() instanceof String && e.getValue() instanceof String)
                    aliases.put((String)e.getKey(), (String)e.getValue());
            }
            Session session=new Session(id, String.valueOf(saved.getOrDefault("conversationId", "")),
                    String.valueOf(saved.getOrDefault("fullPrompt", saved.getOrDefault("prompt", ""))),
                    (String)saved.get("projectId"),refs, Map.copyOf(aliases),
                    String.valueOf(saved.getOrDefault("model", "")),
                    String.valueOf(saved.getOrDefault("createdAt", Instant.now().toString())));
            session.runId=String.valueOf(saved.getOrDefault("runId", ""));
            session.answer=String.valueOf(saved.getOrDefault("answer", ""));
            session.error=String.valueOf(saved.getOrDefault("error", ""));
            if (saved.get("question") instanceof Map<?,?> q) {
                Map<String,String> restored = new LinkedHashMap<>();
                for (var e : q.entrySet()) if (e.getKey() instanceof String && e.getValue() instanceof String)
                    restored.put((String)e.getKey(),(String)e.getValue());
                session.question=Map.copyOf(restored);
            }
            session.status=String.valueOf(saved.getOrDefault("status", "interrupted"));
            if (Set.of("queued", "waiting_workspace", "running", "cancelling").contains(session.status)) session.status="interrupted";
            session.updatedAt=String.valueOf(saved.getOrDefault("updatedAt", session.createdAt));
            if (saved.get("events") instanceof List<?> list) for (Object item:list) if (item instanceof Map<?,?> m) {
                @SuppressWarnings("unchecked") Map<String,Object> map=(Map<String,Object>)m;
                session.events.addLast(map);
            }
            if (saved.get("sequence") instanceof Number n) session.sequence=n.longValue();
            return session;
        }
    }
}
