# ASTRA Visual Guardian

Takes a screenshot of every page of a web application before a migration or deployment. Afterwards, it shows you
which pages look different, in one HTML report.

1. **Capture** (before): enter the application's address. Guardian opens it in Chrome or Edge, you sign in if
   needed, and Guardian then opens every page it can reach through the application's links and menus, taking one
   screenshot of each page. Download the **package** (a ZIP file) and keep it.
2. **Compare** (after the migration or deployment): upload the package and enter the new address (or the same one,
   after a deployment). Guardian opens the same pages, takes screenshots the same way and writes the **report**:
   the pages that changed, are missing or are new, with before and after pictures and the differences marked in red.

Guardian does not test functionality. It never fills in forms, never submits anything, and never clicks buttons
other than menu buttons. No AI is used.

## Start

**Requirements:** Java 17 or newer, and Chrome or Edge installed. Nothing else is installed or downloaded.

- Windows: double-click `launch.cmd`. Linux or macOS: `./launch.sh`. Or run `java -jar visual-guardian.jar`.
- Open **http://127.0.0.1:8765** in your browser. Keep the console window open while a capture or comparison runs.
- Another port or data folder: `java -jar visual-guardian.jar --port 8766 --data D:\guardian-data`

**Spring Boot version (optional):** `mvn package` (needs Maven and access to Maven Central or a company mirror), then
`java -jar target/visual-guardian-spring.jar` with the same options. Same UI, same data folder, same answers.

## 1. Capture

1. Open **1. Capture** and enter the application's address, for example `https://myapp.example.com/app/`.
2. Leave **I will sign in myself first** ticked if the application needs a sign-in, SSO, a PIN, a smart card or a
   certificate. Press **Start capture**.
3. A browser window opens. Sign in there as you normally do, accept a certificate warning if you trust the site,
   then go back to Guardian and press **Continue**.
4. Guardian opens the pages one by one. You can watch the latest screenshots arrive, and press **Stop** at any time:
   the pages taken until then are kept and packaged.
5. When it has finished, press **Download package**. **View screenshots** shows every page it took.

If the session runs out during a capture, Guardian waits for you to sign in again, then opens the same page again.
When single sign-on signs you in again by itself, Guardian notices and simply reopens the page.

**What is never opened** (listed under "Links not opened" in the package instead):

- sign-out links (log out, sign off, exit)
- file downloads (PDF, Excel, ZIP, images; links named Download or Export)
- links that look like an action, by their address or text: delete, remove, approve, reject, cancel, reset,
  revoke, deactivate... For example `/orders/7/delete`, `/users/deleteUser.do?id=4`, `?action=remove`
- other sites (only the application's own host, plus any **Other host names** you add)
- anything matching **Pages to skip**

Menu buttons (buttons and menu items without a link, inside the page's navigation, header or side bar) are clicked
once each, to find pages of single-page applications. Buttons whose label starts with an action word (save, delete,
new, edit, export, print...) and switches (theme, language) are never clicked.

**Similar pages:** pages that differ only by a number or ID (`/invoices/1`, `/invoices/2`, ...) are the same page
with other data. Only the first 10 of each kind are captured; the gallery lists how many were left out.

### Capture settings (More settings)

| Setting | Default | What it does |
|---|---|---|
| Maximum pages | 500 | The capture stops after this many pages. |
| Maximum similar pages | 10 | Pages per kind (`/invoices/{id}`). 0 = all. |
| Window width and height | 1366 × 768 | The size of the page in every screenshot. A comparison uses the same size automatically. |
| Whole pages | on | Screenshots of the whole page, up to 16,000 pixels tall. Off: only the part that fits in the window. |
| Also click menu buttons that have no link | on | For single-page applications. |
| Areas to hide | (none) | CSS selectors, one per line, such as `#clock` or `.last-login`. Hidden in every screenshot and left out of the text, so clocks, dates, counters and adverts do not show up as changes. |
| Pages to skip | (none) | One rule per line (see below). |
| Other host names of the application | (none) | When the application uses more than one host name. |
| Seconds to wait for a page | 30 | The longest wait for a page to load. |
| Extra wait after a page loads | 500 ms | Guardian waits until the page stops changing, then this much longer. Raise it for pages that draw charts late. |
| Browser | Chrome or Edge found on this computer | Path to `chrome.exe` or `msedge.exe` when it is not found. |
| Proxy | (none) | Only if the browser needs a proxy that Windows does not set. |
| Hidden browser | off | Runs without a window. Only when nobody needs to sign in. |

**Pages to skip**, one rule per line:

```
/admin                skips /admin and /admin/users, not /administrator
/reports/*/export     * matches anything
#/settings            a single-page-app route
logout                any address containing the text
title: Audit log      pages whose title contains the text
label: Delete         links and menu buttons whose text contains the text
```

## 2. Compare

1. Open **2. Compare**. Choose the package: a capture made on this computer, or press **Upload a package (ZIP)**.
2. Enter the new address. After a deployment on the same server it can be the same address (Guardian suggests it).
3. Leave **I will sign in myself first** ticked if needed, press **Start comparison**, sign in, press **Continue**.
4. When it has finished, press **Open report** or **Download report**.

**How pages are matched.** Each page of the package is opened at the same address on the new system. When the
application moved to another server or another path (`https://old/app/...` is now `https://new/portal/...`),
Guardian works out the change from the two addresses you entered and the pages the applications open at. If
pages are matched wrongly (the report then says most pages are missing), enter **Old start path** (`/app`) and
**New start path** (`/portal`) under More settings.

| Result | Meaning |
|---|---|
| Changed | The screenshot, the visible text or the title differs, or the page now opens at another address. |
| Missing | The page cannot be opened, answers with an error (404, 500), or now opens another page of the package. |
| New | A page that the new system links to and the package does not have. |
| Unchanged | No difference. |
| Skipped | Matches Pages to skip. |

### Comparison settings (More settings)

| Setting | Default | What it does |
|---|---|---|
| Ignore differences up to (% of a page) | 0 | 0 reports every difference. Raise it (for example 0.5) to ignore tiny ones. |
| Look for new pages | on | Opens pages the new system links to that the package does not have, up to **Maximum new pages** (100). |
| More areas to hide | (none) | Added to the package's areas, which are hidden anyway. |
| Pages to skip | (none) | Added to the package's rules, which apply anyway. |
| Old start path, New start path | (automatic) | Only when pages are matched wrongly. |
| Other host names, seconds to wait, extra wait, browser, proxy, hidden browser | as for a capture | |

## The report

One HTML file with the pictures inside it and no scripts: open it in any browser, attach it to an e-mail, keep it
with the release. At the top: what was compared, when, and the number of changed, missing, new and unchanged
pages. For each page that differs:

- why it is listed (for example "2 areas of the screenshot changed (12,400 pixels, 0.82% of the page); text
  changed (1 line added, 1 removed)")
- the old and new addresses
- three pictures: **Changes** (the new page, faded, with what differs in red and boxed), **Before** and **After**.
  They show the part of the page around the changes; switch between Before and After to see the difference.
- the lines of text that were added and removed

New pages show their screenshot. Unchanged pages are listed at the end.

## Tips for a clean result

- Capture and compare on the **same computer with the same browser**. Different browser versions can draw text a
  little differently; the report warns when the versions differ.
- Hide areas that change by themselves with **Areas to hide**: clocks, today's date, "last signed in", counters,
  adverts, rotating banners.
- Use the same test data on both systems where you can. Different data (another customer list, other totals) shows
  as a change, which is correct but noisy.
- The window size is taken from the package, so both runs line up.

## Limits

- Pages are found through links and menu buttons. Screens without an address of their own (a tab or pop-up that
  does not change the address, a step of a wizard, a result after submitting a form) are not captured separately.
- Pages longer than 16,000 pixels are cut there.
- One capture or comparison runs at a time.
- Signing in needs a visible browser window.

## Where things are kept

```
guardian-data/
  jobs/<id>/            one folder per capture or comparison
    job.json            status, settings, pages and results
    shots/, text/       the screenshots and each page's visible text
    package.zip         capture: the package to download
    index.html          capture: the screenshot gallery (also inside the package)
    report.html         comparison: the report
  packages/<id>/        packages you uploaded
```

Delete captures, comparisons and uploaded packages in **History**, or delete their folders while Guardian is closed.

## Build from source

- Plain jar (no dependencies): `build.cmd` (Windows) or `./build.sh`, which writes `build/visual-guardian.jar`.
- Spring Boot jar: `mvn package`, which writes `target/visual-guardian-spring.jar`.

How it works inside: [ARCHITECTURE.md](ARCHITECTURE.md). What changed: [CHANGES.md](CHANGES.md). How it was tested:
[VALIDATION.md](VALIDATION.md).
