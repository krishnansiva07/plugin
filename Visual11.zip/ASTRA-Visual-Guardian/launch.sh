#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")"
command -v java >/dev/null 2>&1 || { echo 'Java 17 or newer is required.'; exit 1; }
echo 'Open http://127.0.0.1:8765 in your browser. Ctrl+C stops Guardian.'
exec java -jar visual-guardian.jar "$@"
