# How ASTRA Visual Guardian works

Two runs, one package in between:

```
 Capture (before)                          Compare (after)
 ────────────────                          ───────────────
 address ─► browser ─► sign in (you)       package + new address ─► browser ─► sign in (you)
        ─► open every page once                   ─► open each package page on the new system
        ─► screenshot + visible text              ─► screenshot + visible text, same way
        ─► package.zip ─────────────────────────► ─► compare pictures, text, title
                                                  ─► look for new pages
                                                  ─► report.html
```

Everything runs on your computer: a small web server on 127.0.0.1 (the UI), and Chrome or Edge driven over the
DevTools protocol. Plain Java 17, no libraries. The Spring Boot version only replaces the web server.

## 1. The source files

| File | What it does |
|---|---|
| `Main.java` | Built-in web server (Java's own `HttpServer`) on 127.0.0.1. Passes every request to `Api`. |
| `Api.java` | Every endpoint, the security checks, serving the UI and the files (packages, reports, screenshots). |
| `Jobs.java` | Starts captures and comparisons on their own thread; Continue and Stop; saving `job.json`; what the UI sees; packages (writing, uploading, checking); recovery after Guardian was closed. |
| `Capture.java` | The capture: which pages to open, in which order, and what is never opened. |
| `Comparison.java` | The comparison: opening each package page on the new system, deciding Changed, Missing, New or Unchanged. |
| `Session.java` | Opening a page with the pauses for you: sign in first, sign in again, certificate warnings. |
| `Browser.java` | Chrome or Edge: start it, open a page and wait until it is ready, read its links and text, click a menu button, take the screenshot. |
| `Site.java` | Page names (keys), similar-page patterns, links that are never opened, risky menu buttons, mapping old addresses to new ones. |
| `Diff.java` | Comparing two screenshots (changed pixels, changed areas, the red picture) and two texts. |
| `Report.java` | `report.html` (comparison) and `index.html` (the package's gallery). |
| `Skips.java` | The "Pages to skip" rules. |
| `Json.java`, `Util.java` | JSON reading and writing; small helpers (safe file writes, IDs, URL checks). |
| `resources/` | The UI: `index.html`, `app.js`, `style.css`. |
| `spring/guardian/boot/` | The Spring Boot front door: `GuardianApplication`, `GuardianController` (passes every request to `Api`), `LocalOnlyGuard` (same local-only checks). |

## 2. Capture

`Capture.run` starts the browser and calls `crawl()`:

1. **First page and sign-in** (`Session.begin`). With "I will sign in myself first", Guardian opens the address
   without waiting and pauses (status WAITING) until you press Continue. Without it, Guardian opens the address and
   still pauses if it sees a sign-in form (a password or one-time-code field), a sign-in service on another host
   (login., sso., adfs, Okta, Microsoft...), a certificate warning, or no answer within a minute. After Continue it
   checks twice more that the browser is not still on a sign-in or error page. The address the application opens
   at becomes the first page; its host counts as the application's host.
2. **Level by level** (breadth first). A queue starts with the first page. For each page: open it, read it, take its
   screenshot, then queue the links it has that were not seen before. So all pages linked from the first page come
   before the pages linked from those.
3. **Never twice.** Each page has a key (section 4). A key is queued, captured or set aside once; a link to a known
   key is ignored. When an address redirects to a page already taken, it is dropped.
4. **What a page gives** (`Browser.read`): its title; its visible text lines (not inside areas to hide); every link
   (`a[href]`, `area[href]`, also inside frames of the same site); and its menu buttons.
5. **Links are checked before they are queued**: other hosts are ignored; `Site.notOpened` sets aside sign-out links,
   downloads and action-like links; "Pages to skip" rules; then the similar-page limit (`/orders/{id}` at most 10).
   Set-aside links are listed in the package with the reason.
6. **Menu buttons** (`Capture.menus`): buttons, menu items, tabs and links without an address that sit inside
   `nav`, `header`, `aside` or a menu, are visible, not disabled, not in a form and not a switch. Each label is
   clicked once in the whole capture. If the address changes, that address is queued and the page is opened again
   for its other menu buttons; if not (a drop-down opened), the page is read again for new links and buttons.
   Labels starting with an action or settings word (`Site.risky`) are never clicked.
7. **Session runs out** (`Session.open`): the page opened at a sign-in page instead → pause, then open it again. The
   browser went through a sign-in page and ended elsewhere (single sign-on signed in again by itself and showed the
   home page) → open it again once, without a pause.
8. **End**: the queue is empty, the maximum number of pages is reached, you press Stop, or the browser window was
   closed. In every case the pages taken are packaged.

### Screenshots

`Browser.screenshot` makes every screenshot the same way, so two runs line up:

- The page size is fixed (window width × height, scale 1), whatever the screen.
- Animations and transitions jump to their end, the text cursor is hidden, scroll bars are hidden.
- Areas to hide get `visibility: hidden` (the space stays, the content disappears).
- Whole page: lazy images are loaded by scrolling through once. A page whose content scrolls inside a panel (the
  window itself does not scroll) has that panel opened to its full height first.
- The picture is taken beyond the window (`captureBeyondViewport`), up to 16,000 pixels.
- Afterwards everything is put back.

**Ready to screenshot** (`Browser.waitReady`): the document has loaded, then text length, element count, page
height, loading indicators, pending images and web fonts stay the same for three checks 250 ms apart (at most 10
seconds), then the extra wait (500 ms by default).

## 3. The package

`Jobs.writePackage` writes, and `package.zip` contains:

```
guardian-package.json   format "astra-visual-guardian-package/1", application address, address after sign-in,
                        capture time, browser version, settings, complete or not, and for every page:
                        n, key, open, url, title, HTTP status, parent page, depth, found by, shot, text, size;
                        plus links not opened, pages found but not opened (limit or Stop), similar pages left out
index.html              the gallery: every screenshot with its page
shots/0001.png ...      one screenshot per page
text/0001.txt ...       first line: the title; then the visible text, one line per text block
```

Uploading (`Jobs.importPackage`) streams the ZIP to disk (up to 8 GB), accepts only these file names (also when
the files sit in one folder, as after unzipping and zipping again), refuses paths outside the folder, checks every
screenshot is there, and writes the gallery again from the package's data.

## 4. Page keys and similar pages (`Site`)

- **Key** = path + query + single-page-app route. Query parameters are sorted; `utm_*` and `_` are left out;
  `;jsessionid=` is removed; `#/orders/5` and `#!/orders/5` count, `#top` does not; `#/` is the page itself.
- **Pattern** = the key with numbers, UUIDs and long hex IDs as `{id}`, and query values containing digits as `{v}`:
  `/orders/15` → `/orders/{id}`, `/list?page=7` → `/list?page={v}`.
- **Never opened** (`Site.notOpened`): file extensions (pdf, xlsx, zip, png...), and the words of the address and the
  link text, split at separators and camelCase (`deleteUser.do` → delete, user, do; `log-out` → log, out, logout):
  sign-out words, download words, action words. Whole words only, so `/removed-items` and `/approvals` are opened.

## 5. Compare

`Comparison.run` starts the browser and calls `compare()`:

1. **Sign in** on the new system, as for a capture.
2. **Mapping** (`Site.Mapping.of`): old context path → new context path. In order: the prefixes you entered; the
   common ending of the two start addresses (`/app/home` and `/portal/home` → `/app` becomes `/portal`); the common
   ending of the addresses both applications opened at after signing in; else the folder all package pages share
   (`/app`), taken at the same depth of the new start address. The same address on both sides maps every page to
   itself.
3. **Each package page, in package order** (`Comparison.page`): open `mapping.forward(open key)`. Then:
   - not opened, or on another site → **Missing**
   - HTTP 400 or higher (it was not before) → **Missing**
   - it opens another page of the package instead (mapped back) → **Missing**; it opens an address the package does
     not know → a reason on the page ("now opens /x")
   - screenshot and text the same way as the capture, with the package's areas to hide plus any added now. Areas
     to hide are also painted grey on both pictures before comparing, so an area hidden only now does not count.
   - `Diff.images`: a pixel differs when red, green or blue differ by more than 32 (font smoothing is not a change);
     changed pixels are grouped in 16 × 16 cells, and touching cells form areas (at most 30). Percent = changed
     pixels / (largest width × largest height). Above "ignore differences up to" → a reason.
   - `Diff.text`: lines added and removed (each line counted as often as it appears; spacing ignored).
   - title changed → a reason.
   - no reason → **Unchanged**; otherwise **Changed** (or Missing, above). For pages that differ, the report's
     pictures are written right away (`Report.pictures`), so screenshots are not kept in memory.
4. **New pages** (`Comparison.findNew`): links of the new pages, mapped back, that the package does not know (not a
   page, not a set-aside link, not a page left unvisited, not the same kind as a package page such as another
   `/orders/{id}`), under the new start path. Opened up to the maximum (100), with their links followed in turn.
5. **The report** is written at the end, also when the comparison was stopped (it then lists the pages not compared).

## 6. The report (`Report.comparison`)

One HTML file, no scripts (it is opened from Guardian's own address, where scripts in files are not allowed, and it
should open anywhere). Pictures are JPEG inside the file. Per page: Changes, Before and After pictures of the same
part of the page: the changed areas plus 160 pixels around them (at most 2,000 pixels tall), or the whole page,
smaller, when the changes are spread over more than that. Pictures are at most 1,100 × 2,600 pixels; when they add up
to more than 150 MB, they are made smaller. The Before/After switch is plain CSS (radio buttons).

## 7. Jobs and the data folder (`Jobs`)

- One capture or comparison runs at a time, on its own thread. Only that thread changes the job; the UI reads a
  copy that the thread refreshes (`Run.view`), so reading never collides with writing.
- `job.json` is written at most once a second while running (always on status changes), with a safe replace (write a
  temporary file, then move it), so a crash never leaves half a file.
- Statuses: STARTING, WAITING (for you), RUNNING, DONE, STOPPED, FAILED.
- When Guardian starts, a job that was running when it was closed becomes STOPPED, and its package (capture) or report
  (comparison) is written from what was taken.
- The data folder is locked (`.lock`), so two Guardians cannot use it at the same time.

## 8. Endpoints and security (`Api`)

| | |
|---|---|
| `GET /api/jobs` | History |
| `GET /api/jobs/{id}?since=` | One capture or comparison; a short answer when nothing changed since `since` (the UI asks every second while it runs) |
| `GET /api/baselines` | Packages to compare with |
| `POST /api/captures` | `{url, signIn, settings}` |
| `POST /api/compares` | `{package, url, signIn, settings}` |
| `POST /api/packages` | The ZIP file as the body |
| `POST /api/jobs/command` | `{id, command: continue \| stop}` |
| `POST /api/jobs/delete`, `POST /api/packages/delete` | `{id}` |
| `GET /files/{key}/{id}/{file}` | `package.zip`, `report.html` (`?download=1` to download), `index.html`, `shots/*.png` |

- Listens on 127.0.0.1 only. Every request must say `Host: 127.0.0.1:port` or `localhost:port` (stops other web
  pages reaching it through DNS tricks).
- API calls need the session token (`X-Guardian-Token`), which only the UI page carries, and, when a browser sends an
  `Origin`, Guardian's own. Files need the session's file key in their address. Both change at every start.
- Every answer: no caching, no framing, no sniffing, no referrer, and a content security policy that allows only
  Guardian's own script and pictures.
- File names are checked against a fixed list; paths can never leave their folder.

## 9. Spring Boot

`spring/guardian/boot`: `GuardianApplication` (listens on 127.0.0.1:8765, data folder `guardian-data`, accepts
`--port` and `--data`), `LocalOnlyGuard` (the same checks as above, plus local callers only) and `GuardianController`,
one method that passes every request to `Api.handle` and streams the answer. Both versions therefore behave the
same. `pom.xml` builds `target/visual-guardian-spring.jar` from `src/`, `spring/` and `resources/`.

## 10. Where to change things

| To change | Look at |
|---|---|
| Which links are never opened | `Site.notOpened`, the word lists `ACTIONS`, `SIGN_OUT`, `DOWNLOADS`, `FILES` |
| Which menu buttons are never clicked | `Site.risky`, `RISKY`; `Browser.TOGGLES`; `Browser.MENU_CONTROLS` (what counts as a menu button) |
| What makes two addresses the same page | `Site.key`; similar pages: `Site.pattern` |
| When a page is ready | `Browser.waitReady`, `Browser.STABLE` |
| How screenshots are prepared | `Browser.PREPARE`, `Browser.screenshot` |
| What counts as a change | `Diff.CHANNEL_TOLERANCE`, `Comparison.page` |
| How old addresses map to new ones | `Site.Mapping.of` |
| Sign-in detection | `Session` (`SIGN_IN_ADDRESS`, `SIGN_IN_PATH`, `signInAgain`, `throughSignIn`) |
| The report | `Report.comparison`, `Report.article`, `Report.CSS` |
| A new setting | `Jobs.settings` (limits and defaults), the form in `resources/index.html` (the UI sends every named field) |

## 11. Tests

- `tests/DiffChecks.java`: page keys, links never opened, risky buttons, address mapping, screenshot and text
  comparison, settings limits, file names, sign-in services. `tests/SkipChecks.java`: Pages to skip.
- `tests/simple_flow.py`: real Chrome, through the same API the UI uses. An old system (sign-in, menus, similar
  pages, links never opened, frames, a page that scrolls inside a panel) is captured; the package is downloaded and
  uploaded again; a new system on another path (one page changed, one missing, one new, a hidden clock) is compared;
  the statuses and the report are checked.
- `tests/resilience.py`: real Chrome: the session runs out (you sign in again; single sign-on signs in by itself),
  the browser window is closed, Guardian is closed during a capture, an untrusted certificate.
