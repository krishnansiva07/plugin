package guardian;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.WebSocket;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionStage;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

import static guardian.Json.*;
import static guardian.Util.*;

/**
 * One Chrome or Edge window, driven over the DevTools protocol: open a page, wait until it has finished loading,
 * read its links and text, take a screenshot. Uses the browser installed on this computer; nothing is downloaded.
 */
final class Browser implements AutoCloseable {
    /** Longest full-page screenshot, in pixels (taller pages are cut here). */
    static final int MAX_HEIGHT = 16000;
    static final String CLOSED = "The browser window was closed, so the run stopped. What was taken until then is kept.";

    final Process process;
    final Path profile;
    final HttpClient http = HttpClient.newBuilder().proxy(HttpClient.Builder.NO_PROXY).connectTimeout(Duration.ofSeconds(3)).build();
    final int width, height, pageSeconds, settleMs;
    final CDP cdp;
    String mainFrame = "";
    /** Browser name and version, for example "Chrome/131.0.6778.86" (shown in the report: different versions can draw text slightly differently). */
    String version = "";
    /** HTTP status of the last page (main document) that loaded; 0 when not known. */
    volatile int status;
    /** Every address the window went through since the last open(): redirects, sign-in pages and the page itself. */
    final List<String> trail = java.util.Collections.synchronizedList(new ArrayList<>());

    static String executable(String selected) {
        if (!selected.isBlank() && !selected.equals("auto")) {
            Path p = Path.of(selected);
            if (Files.isRegularFile(p)) return p.toAbsolutePath().toString();
            throw new IllegalArgumentException("Browser not found: " + selected);
        }
        var options = new ArrayList<>(List.of("/usr/bin/google-chrome", "/usr/bin/chromium", "/usr/bin/chromium-browser", "/usr/bin/microsoft-edge",
                "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome", "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge"));
        for (String env : List.of("PROGRAMFILES", "PROGRAMFILES(X86)", "LOCALAPPDATA")) {
            String v = System.getenv(env);
            if (v != null) {
                options.add(v + "/Google/Chrome/Application/chrome.exe");
                options.add(v + "/Microsoft/Edge/Application/msedge.exe");
            }
        }
        for (String p : options) if (Files.isRegularFile(Path.of(p))) return p;
        throw new IllegalArgumentException("Chrome or Edge was not found. Enter the browser's path under More settings.");
    }

    Browser(Path work, Map<String, Object> cfg) throws Exception {
        width = bound(cfg.get("width"), 1366, 800, 3840);
        height = bound(cfg.get("height"), 768, 500, 2160);
        pageSeconds = bound(cfg.get("pageSeconds"), 30, 5, 300);
        settleMs = bound(cfg.get("settleMs"), 500, 0, 10000);
        Files.createDirectories(work);
        profile = Files.createTempDirectory(work, "browser-");
        Process p = null;
        try {
            var args = new ArrayList<>(List.of(executable(s(cfg, "browser")), "--remote-debugging-port=0", "--remote-debugging-address=127.0.0.1",
                    "--user-data-dir=" + profile, "--no-first-run", "--no-default-browser-check", "--disable-sync",
                    // keep working at full speed when the window is minimised or covered by other windows
                    "--disable-background-timer-throttling", "--disable-backgrounding-occluded-windows", "--disable-renderer-backgrounding",
                    "--disable-features=Translate", "--window-size=" + width + "," + (height + 140), "about:blank"));
            if (b(cfg, "headless")) args.add("--headless=new");
            if ("1".equals(System.getenv("GUARDIAN_TEST_NO_SANDBOX"))) args.add("--no-sandbox");
            if (!s(cfg, "proxy").isBlank()) args.add("--proxy-server=" + s(cfg, "proxy"));
            p = new ProcessBuilder(args).redirectError(ProcessBuilder.Redirect.DISCARD).redirectOutput(ProcessBuilder.Redirect.DISCARD).start();
            Path info = profile.resolve("DevToolsActivePort");
            int port = -1;
            for (int i = 0; i < 150 && p.isAlive() && port < 0; i++) {
                port = devToolsPort(info);
                if (port < 0) sleep(100);
            }
            if (port < 0) throw new IOException("The browser did not start. Check that it is installed and allowed to run.");
            process = p;
            cdp = attach(port);
            cdp.call("Page.enable", obj());
            cdp.call("Runtime.enable", obj());
            cdp.call("Network.enable", obj());
            mainFrame = s(map(map(cdp.call("Page.getFrameTree", obj()).get("frameTree")).get("frame")), "id");
            version = s(cdp.call("Browser.getVersion", obj()), "product");
            // The same page size every time, whatever the screen, so screenshots of two runs line up.
            cdp.call("Emulation.setDeviceMetricsOverride", obj("width", width, "height", height, "deviceScaleFactor", 1, "mobile", false));
            for (var call : List.of(obj("method", "Page.setDownloadBehavior", "params", obj("behavior", "deny")),
                    obj("method", "Emulation.setScrollbarsHidden", "params", obj("hidden", true)),
                    obj("method", "Emulation.setFocusEmulationEnabled", "params", obj("enabled", true)))) {
                try {
                    cdp.call(s(call, "method"), map(call.get("params")));
                } catch (Exception ignored) {
                    // older browsers: not essential
                }
            }
        } catch (Exception e) {
            if (p != null) p.destroyForcibly();
            try {
                removeTree(profile);
            } catch (Exception ignored) {
                // best effort
            }
            throw e;
        }
    }

    /** Chrome creates DevToolsActivePort before writing the port into it; an empty or partial file means "not yet". */
    static int devToolsPort(Path info) {
        try {
            var lines = Files.readAllLines(info);
            return lines.isEmpty() || lines.get(0).isBlank() ? -1 : Integer.parseInt(lines.get(0).strip());
        } catch (Exception e) {
            return -1;
        }
    }

    CDP attach(int port) throws Exception {
        String raw = http.send(HttpRequest.newBuilder(URI.create("http://127.0.0.1:" + port + "/json/list")).timeout(Duration.ofSeconds(5)).build(),
                HttpResponse.BodyHandlers.ofString()).body();
        for (Object o : list(parse(raw))) {
            var m = map(o);
            if (s(m, "type").equals("page")) return new CDP(http, s(m, "webSocketDebuggerUrl"), this);
        }
        throw new IOException("The browser has no page open");
    }

    /** Browser events: the HTTP status of each page that loads, and pop-up dialogs (closed so they never block a run). */
    void onEvent(String method, Map<String, Object> params) {
        if (method.equals("Network.responseReceived") && s(params, "type").equals("Document") && s(params, "frameId").equals(mainFrame)) {
            status = num(map(params.get("response")).get("status"), 0);
        } else if (method.equals("Network.requestWillBeSent") && s(params, "type").equals("Document") && s(params, "frameId").equals(mainFrame)) {
            if (trail.size() < 50) trail.add(s(map(params.get("request")), "url"));
        } else if (method.equals("Page.javascriptDialogOpening")) {
            String type = s(params, "type");
            cdp.fire("Page.handleJavaScriptDialog", obj("accept", type.equals("alert") || type.equals("beforeunload")));
        }
    }

    Object eval(String js) throws Exception {
        var r = cdp.call("Runtime.evaluate", obj("expression", js, "returnByValue", true, "awaitPromise", true, "userGesture", true));
        if (r.containsKey("exceptionDetails")) throw new IOException("Page script failed");
        return map(r.get("result")).get("value");
    }

    String url() {
        try {
            return str(eval("location.href"));
        } catch (Exception e) {
            return "";
        }
    }

    /** Opens an address without waiting (used for the first page, where a sign-in may take over). */
    void start(String url) {
        cdp.fire("Page.navigate", obj("url", url));
    }

    /**
     * Opens an address and waits until the page has finished loading. Returns "" or the browser's error, such as
     * net::ERR_NAME_NOT_RESOLVED or net::ERR_CERT_AUTHORITY_INVALID. HTTP errors (404, 500) are not errors here:
     * the page loads and {@link #status} tells.
     */
    String open(String url) throws Exception {
        status = 0;
        trail.clear();
        var r = cdp.call("Page.navigate", obj("url", url));
        String error = s(r, "errorText");
        // ERR_ABORTED: the page replaced itself (a redirect or a download); ERR_HTTP_RESPONSE_CODE_FAILURE: an HTTP error without a page body
        if (error.contains("ERR_ABORTED") || error.contains("ERR_HTTP_RESPONSE_CODE_FAILURE")) error = "";
        waitReady();
        return error;
    }

    /** Whether a password or one-time-code field is showing (a sign-in form). */
    boolean signInForm() {
        try {
            return yes(eval("[...document.querySelectorAll('input[type=password],input[autocomplete=one-time-code]')].some(e=>{"
                    + "const r=e.getBoundingClientRect(),s=getComputedStyle(e);return r.width>0&&r.height>0&&s.visibility!=='hidden'&&s.display!=='none'})"));
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Waits until the page has loaded and stopped changing: text, element count, page height, pending images and
     * loading indicators stay the same for three checks in a row (at most 10 seconds), then the settle time.
     */
    void waitReady() throws Exception {
        long end = System.currentTimeMillis() + pageSeconds * 1000L;
        while (System.currentTimeMillis() < end) {
            try {
                if ("complete".equals(str(eval("document.readyState")))) break;
            } catch (Exception ignored) {
                // the page is still being replaced
            }
            sleep(150);
        }
        long quiet = Math.min(end, System.currentTimeMillis() + 10000);
        String last = "";
        int same = 0;
        while (System.currentTimeMillis() < quiet && same < 3) {
            String now;
            try {
                now = str(eval(STABLE));
            } catch (Exception e) {
                now = "";
            }
            same = !now.isEmpty() && now.equals(last) ? same + 1 : 0;
            last = now;
            sleep(250);
        }
        sleep(settleMs);
    }

    static final String STABLE = """
            (()=>{const b=document.body;if(!b)return '';
            const busy=document.querySelectorAll('[aria-busy=true],[role=progressbar],.spinner,.loading,.loader').length;
            const pending=[...document.images].filter(i=>!i.complete).length;
            return [b.innerText.length,document.getElementsByTagName('*').length,document.documentElement.scrollHeight,busy,pending,
            document.fonts?document.fonts.status:''].join('|')})()""";

    /**
     * Title, visible text lines, every link, and menu buttons without a link. Text inside the masked areas
     * ("areas to hide") is left out, as it is from the screenshot.
     */
    Map<String, Object> read(List<String> masks) throws Exception {
        return map(eval(READ.replace("MASKS_JSON", write(masks))));
    }

    static final String MENU_CONTROLS = "button,[role=button],[role=menuitem],[role=treeitem],[role=tab],[role=link],a:not([href]),[routerlink],[onclick]";

    /** Switches and check boxes are never clicked: they change settings (theme, language) rather than open pages. */
    static final String TOGGLES = "[aria-pressed],[aria-checked],[role=switch],[role=checkbox],[role=radio],[role=option],[type=checkbox],[type=radio]";

    static final String READ = """
            (()=>{const vis=e=>{const r=e.getBoundingClientRect(),s=getComputedStyle(e);return r.width>0&&r.height>0&&s.visibility!=='hidden'&&s.display!=='none'};
            const sel=MASKS_JSON;const masked=e=>sel.some(s=>{try{return !!e.closest(s)}catch{return false}});
            const text=e=>(e.innerText||e.textContent||'').replace(/\\s+/g,' ').trim();
            const name=e=>(e.getAttribute('aria-label')||text(e)||e.getAttribute('title')||'').slice(0,120);
            const docs=[document];for(const f of document.querySelectorAll('iframe,frame')){try{if(f.contentDocument&&f.contentDocument.body)docs.push(f.contentDocument)}catch{}}
            const links=[],seen=new Set();
            for(const d of docs)for(const a of d.querySelectorAll('a[href],area[href]')){let u;try{u=new URL(a.getAttribute('href'),d.baseURI)}catch{continue}
             if(!/^https?:$/.test(u.protocol)||seen.has(u.href)||links.length>=3000)continue;seen.add(u.href);
             links.push({href:u.href,text:name(a),download:a.hasAttribute('download')})}
            const menu=e=>!!e.closest('nav,header,aside,[role=navigation],[role=menubar],[role=menu],[role=tree],[role=banner]');
            const menus=[];[...document.querySelectorAll('MENU_CONTROLS')].forEach((e,i)=>{
             if(e.closest('a[href]')||e.hasAttribute('href')||!menu(e)||!vis(e)||e.disabled||e.getAttribute('aria-disabled')==='true'||e.closest('form')
              ||e.matches('TOGGLES'))return;
             const label=name(e);if(label)menus.push({index:i,label})});
            const lines=[];let total=0;
            for(const d of docs){const w=d.createTreeWalker(d.body||d.documentElement,NodeFilter.SHOW_TEXT);
             while(w.nextNode()&&total<60000){const n=w.currentNode,p=n.parentElement;
              if(!p||['SCRIPT','STYLE','NOSCRIPT','TEMPLATE'].includes(p.tagName)||!vis(p)||masked(p))continue;
              const t=n.textContent.replace(/\\s+/g,' ').trim();if(t){lines.push(t.slice(0,300));total+=t.length}}}
            return {title:document.title.replace(/\\s+/g,' ').trim().slice(0,200),lines:lines.slice(0,3000),links,menus:menus.slice(0,200)}})()"""
            .replace("MENU_CONTROLS", MENU_CONTROLS).replace("TOGGLES", TOGGLES);

    /** Clicks the menu control read() reported at this position, if it still has the same label. */
    boolean clickMenu(int index, String label) throws Exception {
        String js = "(()=>{const e=[...document.querySelectorAll('" + MENU_CONTROLS + "')][" + index + "];if(!e)return false;"
                + "const l=(e.getAttribute('aria-label')||(e.innerText||e.textContent||'').replace(/\\s+/g,' ').trim()||e.getAttribute('title')||'').slice(0,120);"
                + "if(l!==" + write(label) + ")return false;e.scrollIntoView({block:'center'});e.click();return true})()";
        return yes(eval(js));
    }

    /** A screenshot, and where the hidden areas ("areas to hide") are on it: {x, y, width, height} in pixels. */
    record Shot(byte[] png, List<int[]> hidden) {}

    /**
     * A PNG of the page: the whole page when fullPage (up to MAX_HEIGHT pixels; lazy images are loaded by scrolling
     * through once), otherwise the visible window. Areas matching the mask selectors are hidden first.
     */
    Shot screenshot(boolean fullPage, List<String> masks) throws Exception {
        eval(PREPARE.replace("EXPAND", fullPage ? "true" : "false").replace("MASKS_JSON", write(masks)));   // selectors last: they may contain any text
        try {
            sleep(100);
            if (fullPage && yes(eval("document.documentElement.scrollHeight>window.innerHeight+4"))) {
                eval("(async()=>{const max=Math.min(document.documentElement.scrollHeight," + MAX_HEIGHT + ");for(let y=0;y<max;y+=window.innerHeight)"
                        + "{window.scrollTo(0,y);await new Promise(r=>setTimeout(r,120))}window.scrollTo(0,0);await new Promise(r=>setTimeout(r,250));return true})()");
                long end = System.currentTimeMillis() + 3000;
                while (System.currentTimeMillis() < end && !yes(eval("[...document.images].every(i=>i.complete)"))) sleep(150);
            }
            var hidden = new ArrayList<int[]>();
            for (Object o : list(eval(HIDDEN.replace("FULL", fullPage ? "true" : "false").replace("MASKS_JSON", write(masks))))) {
                var r = list(o);
                if (r.size() == 4) hidden.add(new int[]{num(r.get(0), 0), num(r.get(1), 0), num(r.get(2), 0), num(r.get(3), 0)});
            }
            if (!fullPage) return new Shot(png(cdp.call("Page.captureScreenshot", obj("format", "png"))), hidden);
            var metrics = cdp.call("Page.getLayoutMetrics", obj());
            var size = map(metrics.containsKey("cssContentSize") ? metrics.get("cssContentSize") : metrics.get("contentSize"));
            double h = Math.max(height, Math.min(MAX_HEIGHT, dbl(size.get("height"), height)));
            return new Shot(png(cdp.call("Page.captureScreenshot", obj("format", "png", "captureBeyondViewport", true,
                    "clip", obj("x", 0, "y", 0, "width", width, "height", Math.ceil(h), "scale", 1)))), hidden);
        } finally {
            try {
                eval("window.__guardianRestore?.()");
            } catch (Exception ignored) {
                // the page may have navigated away
            }
        }
    }

    static final String HIDDEN = """
            (()=>{const out=[];for(const s of MASKS_JSON){let l=[];try{l=document.querySelectorAll(s)}catch{}
            for(const e of l){const r=e.getBoundingClientRect();if(r.width<1||r.height<1)continue;
            out.push([Math.floor(r.left+(FULL?scrollX:0)),Math.floor(r.top+(FULL?scrollY:0)),Math.ceil(r.width)+1,Math.ceil(r.height)+1]);
            if(out.length>=500)return out}}return out})()""";

    /**
     * Before a screenshot: animations and transitions jump to their end, the text cursor is hidden, the masked areas
     * are hidden, and (full page) a page whose content scrolls inside a panel rather than the window has that panel
     * opened to its full height, so the screenshot shows all of it. window.__guardianRestore() undoes all of it.
     */
    static final String PREPARE = """
            (()=>{const undo=[];const set=(e,p,v)=>{undo.push([e,p,e.style.getPropertyValue(p),e.style.getPropertyPriority(p)]);e.style.setProperty(p,v,'important')};
            const still=document.createElement('style');still.textContent='*,*::before,*::after{animation-duration:0s!important;animation-delay:0s!important;'
             +'animation-iteration-count:1!important;transition-duration:0s!important;transition-delay:0s!important;caret-color:transparent!important;'
             +'scroll-behavior:auto!important}';(document.head||document.documentElement).appendChild(still);
            for(const s of MASKS_JSON){let list=[];try{list=document.querySelectorAll(s)}catch{}for(const e of list)set(e,'visibility','hidden')}
            if(EXPAND&&document.documentElement.scrollHeight<=innerHeight+4){let best=null,area=0;
             for(const e of document.querySelectorAll('body *')){if(e.scrollHeight<=e.clientHeight+40)continue;
              if(!/(auto|scroll|overlay)/.test(getComputedStyle(e).overflowY))continue;const r=e.getBoundingClientRect(),a=r.width*r.height;
              if(a>area&&r.width>innerWidth*0.4&&r.height>innerHeight*0.3){best=e;area=a}}
             if(best){const h=best.getBoundingClientRect().height+best.scrollHeight-best.clientHeight;
              set(best,'height',h+'px');set(best,'max-height','none');set(best,'overflow-y','visible');
              for(let p=best.parentElement;p;p=p.parentElement){set(p,'height','auto');set(p,'max-height','none');set(p,'overflow-y','visible')}}}
            window.__guardianRestore=()=>{for(const [e,p,v,pr] of undo.reverse()){if(v)e.style.setProperty(p,v,pr);else e.style.removeProperty(p)}
             still.remove();delete window.__guardianRestore};return true})()""";

    static byte[] png(Map<String, Object> result) {
        return Base64.getDecoder().decode(s(result, "data"));
    }

    @Override
    public void close() {
        try {
            if (cdp != null) {
                cdp.fire("Browser.close", obj());
                cdp.close();
            }
        } catch (Exception ignored) {
            // closing anyway
        }
        try {
            if (process != null && !process.waitFor(4, TimeUnit.SECONDS)) {
                process.descendants().forEach(ProcessHandle::destroy);
                process.destroyForcibly();
            }
        } catch (Exception ignored) {
            // closing anyway
        }
        try {
            removeTree(profile);
        } catch (Exception ignored) {
            // a locked profile folder is left in the data folder's work area
        }
    }

    /** DevTools protocol connection over a WebSocket: numbered calls with answers, plus events. */
    static final class CDP implements WebSocket.Listener, AutoCloseable {
        final AtomicInteger seq = new AtomicInteger();
        final Map<Integer, CompletableFuture<Map<String, Object>>> pending = new ConcurrentHashMap<>();
        final StringBuilder buffer = new StringBuilder();
        final Browser owner;
        final WebSocket ws;

        CDP(HttpClient client, String address, Browser owner) throws Exception {
            this.owner = owner;
            ws = client.newWebSocketBuilder().connectTimeout(Duration.ofSeconds(5)).buildAsync(URI.create(address), this).get(8, TimeUnit.SECONDS);
        }

        @Override
        public void onOpen(WebSocket w) {
            w.request(1);
        }

        @Override
        public CompletionStage<?> onText(WebSocket w, CharSequence data, boolean last) {
            buffer.append(data);
            if (last) {
                String raw = buffer.toString();
                buffer.setLength(0);
                try {
                    var m = Json.read(raw);
                    if (m.containsKey("id")) {
                        var f = pending.remove(num(m.get("id"), 0));
                        if (f != null) f.complete(m);
                    } else {
                        owner.onEvent(s(m, "method"), map(m.get("params")));
                    }
                } catch (Exception ignored) {
                    // a malformed message is skipped
                }
            }
            w.request(1);
            return null;
        }

        @Override
        public void onError(WebSocket w, Throwable e) {
            closed = true;
            pending.values().forEach(f -> f.completeExceptionally(new IOException(CLOSED)));
        }

        @Override
        public CompletionStage<?> onClose(WebSocket w, int code, String reason) {
            closed = true;
            pending.values().forEach(f -> f.completeExceptionally(new IOException(CLOSED)));
            return null;
        }

        volatile boolean closed;

        synchronized void send(String json) throws IOException {
            if (closed || ws.isOutputClosed()) throw new IOException(CLOSED);
            try {
                ws.sendText(json, true).join();
            } catch (java.util.concurrent.CompletionException e) {
                throw new IOException(CLOSED);
            }
        }

        void fire(String method, Map<String, Object> params) {
            try {
                send(write(obj("id", seq.incrementAndGet(), "method", method, "params", params)));
            } catch (Exception ignored) {
                // the browser may be closing
            }
        }

        Map<String, Object> call(String method, Map<String, Object> params) throws Exception {
            int id = seq.incrementAndGet();
            var f = new CompletableFuture<Map<String, Object>>();
            pending.put(id, f);
            try {
                send(write(obj("id", id, "method", method, "params", params)));
                Map<String, Object> m;
                try {
                    m = f.get(60, TimeUnit.SECONDS);
                } catch (java.util.concurrent.ExecutionException e) {
                    throw e.getCause() instanceof IOException io ? io : new IOException(CLOSED);
                }
                if (m.containsKey("error")) throw new IOException("Browser " + method + ": " + s(map(m.get("error")), "message"));
                return map(m.get("result"));
            } finally {
                pending.remove(id);
            }
        }

        @Override
        public void close() {
            ws.abort();
        }
    }
}
