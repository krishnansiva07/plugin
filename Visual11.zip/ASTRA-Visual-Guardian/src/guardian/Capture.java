package guardian;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

import static guardian.Json.*;
import static guardian.Util.*;

/**
 * Capture: opens every page of the application that its links (and its menu buttons) lead to, once each, and takes
 * one screenshot of each page. Pages are visited level by level: the first page, then the pages it links to, then
 * the pages those link to. Nothing is typed or submitted; links that download files, sign out or look like an action
 * (delete, approve...) are never opened, and only menu buttons are clicked, never other buttons.
 */
final class Capture {
    record Item(String url, String key, int parent, int depth, String via) {}

    final Jobs jobs;
    final Jobs.Run run;
    final Map<String, Object> job, cfg;
    final Browser browser;
    final Site site;
    final Session session;
    final Skips skips;
    final List<String> masks;
    final boolean fullPage, menus;
    final int maxPages, maxSimilar;
    final Deque<Item> queue = new ArrayDeque<>();
    /** Pages already queued, taken or set aside: no page is opened twice. */
    final Set<String> seen = new HashSet<>();
    final Set<String> captured = new HashSet<>();
    final Set<String> triedMenus = new HashSet<>();
    final Map<String, Integer> perPattern = new HashMap<>();
    final List<Object> pages = new ArrayList<>(), notOpened = new ArrayList<>();
    final Map<String, Object> similar = new java.util.LinkedHashMap<>();

    Capture(Jobs jobs, Jobs.Run run, Browser browser) {
        this.jobs = jobs;
        this.run = run;
        this.browser = browser;
        job = run.job;
        cfg = map(job.get("settings"));
        site = new Site(s(job, "url"), strings(cfg.get("hosts")));
        session = new Session(jobs, run, browser, site, !b(cfg, "headless"));
        skips = new Skips(cfg.get("skipPages"));
        masks = strings(cfg.get("masks"));
        fullPage = b(cfg, "fullPage");
        menus = b(cfg, "menus");
        maxPages = num(cfg.get("maxPages"), 500);
        maxSimilar = num(cfg.get("maxSimilar"), 10);
        job.put("pages", pages);
        job.put("notOpened", notOpened);
        job.put("similar", similar);
    }

    static void run(Jobs jobs, Jobs.Run run) throws Exception {
        Files.createDirectories(run.dir.resolve("shots"));
        Files.createDirectories(run.dir.resolve("text"));
        Browser browser = new Browser(jobs.work, map(run.job.get("settings")));
        Exception failure = null;
        try {
            run.browser = browser;
            new Capture(jobs, run, browser).crawl();
        } catch (Jobs.Stopped e) {
            failure = e;
            throw e;
        } catch (Exception e) {
            failure = browser.process.isAlive() ? e : new java.io.IOException(Browser.CLOSED);
            throw failure;
        } finally {
            run.browser = null;
            browser.close();
            if (!list(run.job.get("pages")).isEmpty()) {
                String message = s(run.job, "message");
                try {
                    jobs.progress(run, "Writing the package");
                    Jobs.writePackage(run.dir, run.job);
                } catch (Exception e) {
                    if (failure == null) throw e;
                    failure.addSuppressed(e);
                }
                run.job.put("message", message);
            }
        }
    }

    void crawl() throws Exception {
        String landing = session.begin(s(job, "url"), b(cfg, "signIn"));
        job.put("status", "RUNNING");
        job.put("landing", landing);
        job.put("browserVersion", browser.version);
        jobs.event(run, "Taking screenshots, starting at " + landing);
        String key = Site.key(landing);
        seen.add(key);
        queue.add(new Item(landing, key, 0, 0, "first page"));
        boolean first = true;
        try {
            while (!queue.isEmpty()) {
                jobs.checkStop(run);
                if (pages.size() >= maxPages) {
                    job.put("limitReached", true);
                    break;
                }
                visit(queue.poll(), first);
                first = false;
            }
        } finally {
            var left = new ArrayList<Object>();
            for (Item i : queue) if (left.size() < 20000) left.add(i.key());
            job.put("notVisited", left);
            job.put("complete", queue.isEmpty());
        }
        jobs.event(run, "Finished: " + pages.size() + " pages" + (queue.isEmpty() ? ""
                : ". Stopped at the limit of " + maxPages + " pages; " + queue.size() + " more pages were found but not opened"));
    }

    void visit(Item item, boolean alreadyOpen) throws Exception {
        jobs.progress(run, "Page " + (pages.size() + 1) + ": " + item.key() + (queue.isEmpty() ? "" : "   (" + queue.size() + " more to open)"));
        Session.Opened o = alreadyOpen ? new Session.Opened(browser.url(), browser.status, "") : session.open(item.url());
        if (!o.error().isEmpty()) {
            setAside(item.url(), item.via(), "could not open: " + o.error(), item.parent());
            return;
        }
        if (!site.inside(o.url())) {
            setAside(item.url(), item.via(), "goes to another site (" + Session.host(o.url()) + ")", item.parent());
            return;
        }
        String key = Site.key(o.url());
        if (!key.equals(item.key())) {
            if (captured.contains(key)) return;   // a redirect to a page already taken
            String rule = skips.page(o.url(), "");
            if (!rule.isEmpty()) {
                setAside(item.url(), item.via(), Skips.reason(rule), item.parent());
                return;
            }
            seen.add(key);
        }
        var page = browser.read(masks);
        String title = s(page, "title");
        String rule = skips.match("title", title);
        if (!rule.isEmpty()) {
            setAside(o.url(), item.via(), Skips.reason(rule), item.parent());
            return;
        }
        var shot = browser.screenshot(fullPage, masks);
        int n = pages.size() + 1;
        String name = String.format(Locale.ROOT, "%04d", n), shotFile = "shots/" + name + ".png", textFile = "text/" + name + ".txt";
        Files.write(run.dir.resolve(shotFile), shot.png());
        Files.writeString(run.dir.resolve(textFile), title + "\n" + String.join("\n", strings(page.get("lines"))), StandardCharsets.UTF_8);
        int[] size = Diff.pngSize(shot.png());
        captured.add(key);
        captured.add(item.key());
        pages.add(obj("n", n, "key", key, "open", item.key(), "url", o.url(), "title", title, "status", o.status(), "parent", item.parent(),
                "depth", item.depth(), "via", item.via(), "shot", shotFile, "text", textFile, "width", size[0], "height", size[1]));
        jobs.save(run, false);
        links(page, n, item.depth());
        if (menus) menus(page, n, item.depth(), o.url());
    }

    /** Queues the application's pages this page links to; files, sign-out and action links are listed instead. */
    void links(Map<String, Object> page, int n, int depth) {
        for (Object o : list(page.get("links"))) {
            var l = map(o);
            String href = s(l, "href"), text = s(l, "text");
            if (!site.inside(href)) continue;   // other sites are not part of the application
            String key = Site.key(href);
            if (!seen.add(key)) continue;       // already queued, taken or set aside
            String reason = b(l, "download") ? "file download" : Site.notOpened(href, text);
            if (reason.isEmpty()) {
                String rule = skips.control(text, href);
                if (!rule.isEmpty()) reason = Skips.reason(rule);
            }
            if (!reason.isEmpty()) setAside(href, text, reason, n);
            else if (similarAllowed(key)) queue.add(new Item(href, key, n, depth + 1, "link \"" + clip(text, 80) + "\" on page " + n));
        }
    }

    /**
     * Menu buttons without a link (single-page apps): each label is clicked once in the whole capture. When the
     * click opens another address, that page is queued and this page is opened again for its other menu buttons.
     */
    void menus(Map<String, Object> page, int n, int depth, String pageUrl) throws Exception {
        var current = page;
        for (int clicks = 0; clicks < 40; clicks++) {
            jobs.checkStop(run);
            Map<String, Object> next = null;
            for (Object o : list(current.get("menus"))) {
                var m = map(o);
                String label = s(m, "label"), norm = Diff.normal(label).toLowerCase(Locale.ROOT);
                if (norm.isEmpty() || !triedMenus.add(norm)) continue;
                if (Site.risky(label) || !skips.control(label, "").isEmpty()) continue;
                next = m;
                break;
            }
            if (next == null) return;
            String before = browser.url(), label = s(next, "label");
            if (!browser.clickMenu(num(next.get("index"), -1), label)) {
                current = browser.read(masks);
                continue;
            }
            sleep(300);
            browser.waitReady();
            String after = browser.url();
            if (Site.key(after).equals(Site.key(before))) {
                // a drop-down or a panel opened: it may show more links and more menu buttons
                current = browser.read(masks);
                links(current, n, depth);
                continue;
            }
            if (site.inside(after)) {
                String key = Site.key(after);
                if (seen.add(key)) {
                    String rule = skips.page(after, "");
                    if (!rule.isEmpty()) setAside(after, label, Skips.reason(rule), n);
                    else if (similarAllowed(key)) queue.add(new Item(after, key, n, depth + 1, "menu \"" + clip(label, 80) + "\" on page " + n));
                }
            }
            var o = session.open(pageUrl);   // back, for the page's other menu buttons
            if (!o.error().isEmpty() || !Site.key(o.url()).equals(Site.key(pageUrl))) return;
            current = browser.read(masks);
        }
    }

    /** At most maxSimilar pages per address pattern (/invoices/{id}); the rest are counted. 0 means no limit. */
    boolean similarAllowed(String key) {
        String pattern = Site.pattern(key);
        if (pattern.equals(key) || maxSimilar == 0) return true;
        if (perPattern.merge(pattern, 1, Integer::sum) <= maxSimilar) return true;
        similar.put(pattern, num(similar.get(pattern), 0) + 1);
        return false;
    }

    void setAside(String url, String text, String reason, int page) {
        if (notOpened.size() < 5000) notOpened.add(obj("url", url, "key", Site.key(url), "text", clip(text, 120), "reason", reason, "page", page));
    }
}
