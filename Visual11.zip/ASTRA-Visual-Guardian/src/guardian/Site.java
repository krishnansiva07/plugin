package guardian;

import java.net.URI;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.TreeMap;

import static guardian.Json.*;

/** Which addresses are pages of the application, which links are never opened, and how pages are named and matched. */
final class Site {
    /** Host names (lower case) that belong to the application. */
    final Set<String> hosts = new LinkedHashSet<>();

    Site(String startUrl, List<String> extraHosts) {
        add(startUrl);
        for (String h : extraHosts) add(h.contains("://") ? h : "http://" + h);
    }

    void add(String url) {
        try {
            String h = URI.create(url.strip()).getHost();
            if (h == null) return;
            h = h.toLowerCase(Locale.ROOT);
            hosts.add(h);
            hosts.add(h.startsWith("www.") ? h.substring(4) : "www." + h);
        } catch (Exception ignored) {
            // not an address
        }
    }

    boolean inside(String url) {
        try {
            URI u = URI.create(url);
            return ("http".equals(u.getScheme()) || "https".equals(u.getScheme())) && u.getHost() != null
                    && hosts.contains(u.getHost().toLowerCase(Locale.ROOT));
        } catch (Exception e) {
            return false;
        }
    }

    // ---------------------------------------------------------------- page names

    /**
     * What identifies a page: its path, its query (parameters sorted, tracking parameters left out) and a
     * single-page-app route after "#/" or "#!/". Plain "#section" anchors and ";jsessionid=" are ignored.
     */
    static String key(String url) {
        try {
            URI u = URI.create(url);
            String path = Objects.toString(u.getRawPath(), "");
            path = path.replaceAll("(?i);jsessionid=[^/?#]*", "");
            if (path.isEmpty()) path = "/";
            String query = "";
            if (u.getRawQuery() != null && !u.getRawQuery().isBlank()) {
                var params = new TreeMap<String, List<String>>();
                for (String part : u.getRawQuery().split("&")) {
                    if (part.isBlank()) continue;
                    String name = part.contains("=") ? part.substring(0, part.indexOf('=')) : part;
                    if (name.equals("_") || name.toLowerCase(Locale.ROOT).startsWith("utm_")) continue;
                    params.computeIfAbsent(name, k -> new ArrayList<>()).add(part);
                }
                var parts = new ArrayList<String>();
                params.values().forEach(parts::addAll);
                if (!parts.isEmpty()) query = "?" + String.join("&", parts);
            }
            String fragment = Objects.toString(u.getRawFragment(), "");
            String route = fragment.startsWith("/") || fragment.startsWith("!/") ? "#" + fragment : "";
            if (route.equals("#/") || route.equals("#!/")) route = "";   // the app's first route is the page itself
            return path + query + route;
        } catch (Exception e) {
            return url;
        }
    }

    /** The address pattern of a page, so similar pages (/invoices/1, /invoices/2, ...) can be limited. */
    static String pattern(String key) {
        String p = key.replaceAll("(?i)/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}(?=[/?#]|$)", "/{id}");
        p = p.replaceAll("/\\d+(?=[/?#;.]|$)", "/{id}");
        p = p.replaceAll("(?i)/[0-9a-f]{16,}(?=[/?#]|$)", "/{id}");
        p = p.replaceAll("=([^&#]*\\d[^&#]*)", "={v}");
        return p;
    }

    // ---------------------------------------------------------------- links that are never opened

    static final Set<String> FILES = Set.of("pdf", "zip", "gz", "tgz", "rar", "7z", "doc", "docx", "xls", "xlsx", "xlsm", "csv", "ppt", "pptx",
            "txt", "xml", "json", "rtf", "odt", "ods", "png", "jpg", "jpeg", "gif", "bmp", "svg", "webp", "ico", "mp3", "mp4", "avi", "mov",
            "wav", "exe", "msi", "dmg", "apk", "iso", "jar", "eml", "msg");

    /** Words that make a link an action rather than a page (matched as whole words of the address and of the link text). */
    static final Set<String> ACTIONS = Set.of("delete", "remove", "destroy", "purge", "erase", "terminate", "deactivate", "disable", "unsubscribe",
            "approve", "reject", "decline", "cancel", "revoke", "reset", "wipe", "shutdown", "restart", "execute");
    static final Set<String> SIGN_OUT = Set.of("logout", "logoff", "signout", "signoff", "exit", "quit", "endsession");
    static final Set<String> DOWNLOADS = Set.of("download", "export");
    /** Menu buttons with these words are never clicked: they change data or settings instead of opening a page. */
    static final Set<String> RISKY = Set.of("save", "submit", "send", "pay", "buy", "order", "purchase", "create", "add", "new", "edit", "update", "upload",
            "import", "print", "close", "confirm", "theme", "dark", "light", "language", "lang", "locale", "font", "zoom", "density", "compact");

    /**
     * Why a link is not opened, or "" when it is a page: files and downloads, sign-out links, and links that look
     * like an action (such as /invoices/7/delete or ?action=deleteUser), which may do it just by being opened.
     */
    static String notOpened(String url, String text) {
        URI u;
        try {
            u = URI.create(url);
        } catch (Exception e) {
            return "not a valid address";
        }
        String path = Objects.toString(u.getPath(), ""), lower = path.toLowerCase(Locale.ROOT);
        int dot = lower.lastIndexOf('.');
        if (dot > lower.lastIndexOf('/') && FILES.contains(lower.substring(dot + 1))) return "file download";
        var address = words(path + " " + Objects.toString(u.getQuery(), ""));
        var label = words(text);
        boolean firstWordAction = !label.isEmpty() && ACTIONS.contains(label.get(0));
        if (any(address, SIGN_OUT) || any(label, SIGN_OUT)) return "sign-out link";
        if (any(address, DOWNLOADS) || !label.isEmpty() && DOWNLOADS.contains(label.get(0))) return "file download";
        if (any(address, ACTIONS) || firstWordAction) return "looks like an action, not a page";
        return "";
    }

    /** A menu button (without a link) that must not be clicked: its first word is an action or a setting. */
    static boolean risky(String label) {
        var w = words(label);
        return !w.isEmpty() && (ACTIONS.contains(w.get(0)) || RISKY.contains(w.get(0)) || DOWNLOADS.contains(w.get(0)) || any(w, SIGN_OUT));
    }

    /**
     * The words of an address or a label, lower case: "deleteUser.do?cmd=log-out" gives delete, user, do, cmd,
     * log, out, plus each word joined to the next (logout), so "log-out" and "sign out" are found too.
     */
    static List<String> words(String text) {
        var out = new ArrayList<String>();
        String spaced = text.replaceAll("([a-z0-9])([A-Z])", "$1 $2").toLowerCase(Locale.ROOT);
        String[] parts = spaced.split("[^\\p{L}\\p{N}]+");
        for (int i = 0; i < parts.length; i++) {
            if (parts[i].isEmpty()) continue;
            out.add(parts[i]);
            if (i + 1 < parts.length && !parts[i + 1].isEmpty()) out.add(parts[i] + parts[i + 1]);
        }
        return out;
    }

    static boolean any(List<String> words, Set<String> set) {
        for (String w : words) if (set.contains(w)) return true;
        return false;
    }

    // ---------------------------------------------------------------- old system -> new system

    /**
     * How addresses of the captured system map to the new one: the old context path is swapped for the new one.
     * Found from, in this order: the prefixes you gave; the common ending of the two start addresses
     * (https://old/app/home and https://new/portal/home: /app/... becomes /portal/...); the common ending of the
     * addresses the two applications opened at after signing in; and otherwise the folder all captured pages share
     * (/app), taken at the same depth of the new start address (https://new/portal/ gives /portal).
     */
    record Mapping(String fromOrigin, String fromPrefix, String toOrigin, String toPrefix) {
        static Mapping of(String fromStart, String toStart, String fromLanding, String toLanding, Collection<String> oldKeys,
                          String fromPrefix, String toPrefix) {
            URI a = URI.create(fromStart), b = URI.create(toLanding.isBlank() ? toStart : toLanding);
            if (!fromPrefix.isBlank() || !toPrefix.isBlank()) return new Mapping(origin(a), clean(fromPrefix), origin(b), clean(toPrefix));
            for (String[] pair : new String[][]{{fromStart, toStart}, {fromLanding, toLanding}}) {
                if (pair[0].isBlank() || pair[1].isBlank()) continue;
                List<String> pa = segments(URI.create(pair[0]).getRawPath()), pb = segments(URI.create(pair[1]).getRawPath());
                int common = 0;
                while (common < pa.size() && common < pb.size() && pa.get(pa.size() - 1 - common).equals(pb.get(pb.size() - 1 - common))) common++;
                if (common > 0) return new Mapping(origin(a), "/" + String.join("/", pa.subList(0, pa.size() - common)), origin(b),
                        "/" + String.join("/", pb.subList(0, pb.size() - common)));
            }
            List<String> root = folder(oldKeys), to = segments(URI.create(toStart).getRawPath());
            return new Mapping(origin(a), "/" + String.join("/", root), origin(b), "/" + String.join("/", to.subList(0, Math.min(root.size(), to.size()))));
        }

        /** The folder all these pages are in: /app for /app/home and /app/orders/1. */
        static List<String> folder(Collection<String> keys) {
            List<String> common = null;
            for (String k : keys) {
                String path = k.split("[?#]", 2)[0];
                List<String> seg = segments(path);
                if (!path.endsWith("/") && !seg.isEmpty()) seg = seg.subList(0, seg.size() - 1);
                if (common == null) common = new ArrayList<>(seg);
                else {
                    int i = 0;
                    while (i < common.size() && i < seg.size() && common.get(i).equals(seg.get(i))) i++;
                    common = new ArrayList<>(common.subList(0, i));
                }
            }
            return common == null ? List.of() : common;
        }

        static String clean(String prefix) {
            String p = prefix.strip();
            return p.startsWith("/") ? p : "/" + p;
        }

        static List<String> segments(String path) {
            var out = new ArrayList<String>();
            for (String s : Objects.toString(path, "").split("/")) if (!s.isEmpty()) out.add(s);
            return out;
        }

        static String origin(URI u) {
            return u.getScheme() + "://" + u.getRawAuthority();
        }

        /** The new-system address of a captured page key. */
        String forward(String key) {
            return toOrigin + swap(key, fromPrefix, toPrefix);
        }

        /** The captured-system key of a new-system address (to tell new pages from known ones). */
        String back(String url) {
            return swap(Site.key(url), toPrefix, fromPrefix);
        }

        static String swap(String key, String from, String to) {
            String f = from.replaceAll("/+$", ""), t = to.replaceAll("/+$", "");
            String rest;
            if (f.isEmpty()) rest = key;
            else if (key.equals(f) || key.startsWith(f + "/") || key.startsWith(f + "?") || key.startsWith(f + "#")) rest = key.substring(f.length());
            else return key;
            String out = t + rest;
            return out.isEmpty() ? "/" : out.startsWith("/") ? out : "/" + out;
        }
    }

    static Map<String, Object> describe(Mapping m) {
        return obj("from", m.fromOrigin() + m.fromPrefix(), "to", m.toOrigin() + m.toPrefix());
    }
}
