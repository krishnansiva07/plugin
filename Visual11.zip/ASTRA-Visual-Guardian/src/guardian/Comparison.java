package guardian;

import java.awt.image.BufferedImage;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

import static guardian.Json.*;
import static guardian.Util.*;

/**
 * Comparison: opens every page of a package on the new system (the same address, with the old system's start
 * address swapped for the new one), takes its screenshot the same way, and compares it with the package's
 * screenshot, text and title. Then it opens pages the new system links to that the package does not have.
 *
 * <pre>
 * SAME     no difference (or less than "ignore differences up to")
 * CHANGED  the screenshot, the visible text or the title differs, or the page now opens another address
 * MISSING  the page cannot be opened, answers with an HTTP error, or now opens another page of the package
 * NEW      a page the new system links to that the package does not have
 * SKIPPED  matches "pages to skip"
 * </pre>
 */
final class Comparison {
    final Jobs jobs;
    final Jobs.Run run;
    final Map<String, Object> job, cfg, manifest;
    final Path pkg;
    final Browser browser;
    final Site site;
    final Session session;
    final Skips skips;
    final List<String> masks;
    final boolean fullPage, findNew;
    final double tolerance;
    final int maxNew, maxSimilar;
    Site.Mapping mapping;
    final List<Object> results = new ArrayList<>();
    final Map<String, Object> summary = obj("same", 0, "changed", 0, "missing", 0, "new", 0, "skipped", 0);
    /** Package pages by address, and everything the package knew about (pages, links not opened, pages not visited). */
    final Map<String, Map<String, Object>> byKey = new HashMap<>();
    final Set<String> known = new HashSet<>(), knownPatterns = new HashSet<>();
    final Deque<String[]> newQueue = new ArrayDeque<>();
    final Set<String> newSeen = new HashSet<>();
    final Map<String, Integer> perPattern = new HashMap<>();

    Comparison(Jobs jobs, Jobs.Run run, Browser browser, Path pkg, Map<String, Object> manifest) {
        this.jobs = jobs;
        this.run = run;
        this.browser = browser;
        this.pkg = pkg;
        this.manifest = manifest;
        job = run.job;
        cfg = map(job.get("settings"));
        var captured = map(manifest.get("settings"));
        site = new Site(s(job, "url"), strings(cfg.get("hosts")));
        session = new Session(jobs, run, browser, site, !b(cfg, "headless"));
        // The capture's areas to hide and pages to skip apply too, plus any added for this comparison.
        var maskSet = new LinkedHashSet<String>(strings(captured.get("masks")));
        maskSet.addAll(strings(cfg.get("masks")));
        masks = List.copyOf(maskSet);
        var skipRules = new ArrayList<Object>(strings(captured.get("skipPages")));
        skipRules.addAll(strings(cfg.get("skipPages")));
        skips = new Skips(skipRules);
        fullPage = b(cfg, "fullPage");
        findNew = b(cfg, "findNew");
        tolerance = dbl(cfg.get("tolerance"), 0);
        maxNew = num(cfg.get("maxNew"), 100);
        maxSimilar = num(cfg.get("maxSimilar"), 10);
        for (Object o : list(manifest.get("pages"))) {
            var p = map(o);
            for (String k : List.of(s(p, "key"), s(p, "open"))) {
                if (k.isEmpty()) continue;
                byKey.putIfAbsent(k, p);
                known.add(k);
                if (!Site.pattern(k).equals(k)) knownPatterns.add(Site.pattern(k));
            }
        }
        for (Object o : list(manifest.get("notOpened"))) known.add(s(map(o), "key"));
        for (Object o : list(manifest.get("notVisited"))) known.add(str(o));
        knownPatterns.addAll(map(manifest.get("similar")).keySet());
        job.put("results", results);
        job.put("summary", summary);
    }

    static void run(Jobs jobs, Jobs.Run run) throws Exception {
        Path pkg = jobs.packageDir(s(map(run.job.get("package")), "id"));
        var manifest = load(pkg.resolve("guardian-package.json"));
        Files.createDirectories(run.dir.resolve("shots"));
        Files.createDirectories(run.dir.resolve("text"));
        Browser browser = new Browser(jobs.work, map(run.job.get("settings")));
        Exception failure = null;
        try {
            run.browser = browser;
            new Comparison(jobs, run, browser, pkg, manifest).compare();
        } catch (Jobs.Stopped e) {
            failure = e;
            throw e;
        } catch (Exception e) {
            failure = browser.process.isAlive() ? e : new java.io.IOException(Browser.CLOSED);
            throw failure;
        } finally {
            run.browser = null;
            browser.close();
            if (!list(run.job.get("results")).isEmpty()) {
                String message = s(run.job, "message");
                try {
                    jobs.progress(run, "Writing the report");
                    if (failure != null) {
                        run.job.put("status", failure instanceof Jobs.Stopped ? "STOPPED" : "FAILED");
                        run.job.put("message", failure instanceof Jobs.Stopped ? "You stopped it." : Util.message(failure));
                    }
                    Report.comparison(run.dir, run.job, manifest);
                } catch (Exception e) {
                    if (failure == null) throw e;
                    failure.addSuppressed(e);
                }
                run.job.put("message", message);
            }
        }
    }

    void compare() throws Exception {
        String landing = session.begin(s(job, "url"), b(cfg, "signIn"));
        job.put("status", "RUNNING");
        job.put("landing", landing);
        job.put("browserVersion", browser.version);
        var pages = list(manifest.get("pages"));
        var keys = new ArrayList<String>();
        for (Object o : pages) keys.add(s(map(o), "key"));
        mapping = Site.Mapping.of(s(manifest, "application"), s(job, "url"), s(manifest, "landing"), landing, keys, s(cfg, "fromPrefix"), s(cfg, "toPrefix"));
        job.put("mapping", Site.describe(mapping));
        jobs.event(run, "Comparing " + pages.size() + " pages: " + mapping.fromOrigin() + mapping.fromPrefix() + " is now "
                + mapping.toOrigin() + mapping.toPrefix());
        int i = 0;
        for (Object o : pages) {
            jobs.checkStop(run);
            var p = map(o);
            jobs.progress(run, "Page " + (++i) + " of " + pages.size() + ": " + s(p, "key"));
            page(p);
        }
        if (findNew) findNew();
        jobs.event(run, "Finished: " + summary.get("changed") + " changed, " + summary.get("missing") + " missing, " + summary.get("new")
                + " new, " + summary.get("same") + " unchanged");
    }

    void page(Map<String, Object> p) throws Exception {
        int n = num(p.get("n"), 0);
        String name = String.format(Locale.ROOT, "%04d", n);
        String key = s(p, "key"), open = s(p, "open").isEmpty() ? key : s(p, "open");
        String target = mapping.forward(open);
        var reasons = new ArrayList<Object>();
        var r = obj("n", n, "name", name, "status", "", "key", key, "title", s(p, "title"), "before", s(p, "url"), "url", target, "reasons", reasons);
        results.add(r);
        String rule = skips.page(target, s(p, "title"));
        if (!rule.isEmpty()) {
            finish(r, "SKIPPED", Skips.reason(rule));
            return;
        }
        BufferedImage before = Diff.png(Files.readAllBytes(under(pkg, s(p, "shot"))));
        Session.Opened o = session.open(target);
        r.put("after", o.url());
        r.put("httpStatus", o.status());
        if (!o.error().isEmpty() || !site.inside(o.url())) {
            Report.pictures(run.dir, name, before, null, null);
            finish(r, "MISSING", o.error().isEmpty() ? "goes to another site (" + Session.host(o.url()) + ")" : "could not open: " + o.error());
            return;
        }
        boolean missing = false;
        if (o.status() >= 400 && num(p.get("status"), 200) < 400) {
            missing = true;
            reasons.add("the new system answers HTTP " + o.status());
        }
        String back = mapping.back(o.url());
        if (!back.equals(key) && !back.equals(open)) {
            var other = byKey.get(back);
            if (other != null) {
                missing = true;
                reasons.add("opens another page of the package instead: " + label(other));
            } else {
                reasons.add("now opens " + Site.key(o.url()) + " (before: " + key + ")");
            }
        }
        var page = browser.read(masks);
        var shot = browser.screenshot(fullPage, masks);
        String newTitle = s(page, "title");
        List<String> newLines = strings(page.get("lines"));
        Files.write(run.dir.resolve("shots/" + name + ".png"), shot.png());
        Files.writeString(run.dir.resolve("text/" + name + ".txt"), newTitle + "\n" + String.join("\n", newLines), StandardCharsets.UTF_8);
        r.put("shot", "shots/" + name + ".png");
        r.put("newTitle", newTitle);

        BufferedImage after = Diff.png(shot.png());
        // Areas to hide are blanked on both pictures, so an area hidden only now does not count as a change.
        Diff.blank(before, shot.hidden());
        Diff.blank(after, shot.hidden());
        var d = Diff.images(before, after);
        r.put("percent", Math.round(d.percent() * 1000) / 1000.0);
        r.put("pixels", d.changedPixels());
        r.put("areas", d.areas().size());
        r.put("sizeBefore", d.widthBefore() + " × " + d.heightBefore());
        r.put("sizeAfter", d.widthAfter() + " × " + d.heightAfter());
        if (d.changedPixels() > 0 && d.percent() > tolerance) reasons.add(Report.describe(d));

        List<String> oldText = Files.exists(under(pkg, s(p, "text"))) ? Files.readAllLines(under(pkg, s(p, "text")), StandardCharsets.UTF_8) : List.of();
        String oldTitle = oldText.isEmpty() ? s(p, "title") : oldText.get(0);
        var text = Diff.text(oldText.size() > 1 ? oldText.subList(1, oldText.size()) : List.of(), newLines, 60);
        r.put("added", text.get("added"));
        r.put("removed", text.get("removed"));
        if (!text.get("added").isEmpty() || !text.get("removed").isEmpty())
            reasons.add("text changed (" + text.get("added").size() + (text.get("added").size() == 1 ? " line" : " lines") + " added, "
                    + text.get("removed").size() + " removed)");
        if (!Diff.normal(oldTitle).equals(Diff.normal(newTitle))) reasons.add("title changed: \"" + clip(oldTitle, 80) + "\" is now \"" + clip(newTitle, 80) + "\"");

        String status = missing ? "MISSING" : reasons.isEmpty() ? "SAME" : "CHANGED";
        if (!status.equals("SAME")) Report.pictures(run.dir, name, before, after, d);
        finish(r, status, null);
        if (findNew) candidates(page, String.valueOf(n));
    }

    /** Links of a new-system page that lead to pages the package does not have. */
    void candidates(Map<String, Object> page, String foundOn) {
        for (Object o : list(page.get("links"))) {
            var l = map(o);
            String href = s(l, "href"), text = s(l, "text");
            if (!site.inside(href) || b(l, "download") || !Site.notOpened(href, text).isEmpty() || !skips.control(text, href).isEmpty()) continue;
            String back = mapping.back(href);
            if (!underNewRoot(href) || isKnown(back) || !newSeen.add(back)) continue;
            if (!similarAllowed(back)) continue;
            newQueue.add(new String[]{href, foundOn, clip(text, 80)});
        }
    }

    void findNew() throws Exception {
        int found = 0;
        while (!newQueue.isEmpty() && found < maxNew) {
            jobs.checkStop(run);
            String[] c = newQueue.poll();
            jobs.progress(run, "Looking for new pages: " + Site.key(c[0]));
            var o = session.open(c[0]);
            if (!o.error().isEmpty() || !site.inside(o.url()) || o.status() >= 400) continue;
            String back = mapping.back(o.url());
            if (isKnown(back) || !back.equals(mapping.back(c[0])) && !newSeen.add(back)) continue;   // went to a known or already seen page
            var page = browser.read(masks);
            if (!skips.match("title", s(page, "title")).isEmpty()) continue;
            var shot = browser.screenshot(fullPage, masks);
            String name = "new-" + String.format(Locale.ROOT, "%04d", ++found);
            Files.write(run.dir.resolve("shots/" + name + ".png"), shot.png());
            var r = obj("n", 0, "name", name, "status", "", "key", Site.key(o.url()), "title", s(page, "title"), "url", o.url(), "after", o.url(),
                    "httpStatus", o.status(), "shot", "shots/" + name + ".png", "reasons", new ArrayList<>(List.of("not in the package: linked from "
                            + (c[1].startsWith("new-") ? "new page " + c[1].substring(4) : "page " + c[1]) + (c[2].isBlank() ? "" : " (\"" + c[2] + "\")"))));
            results.add(r);
            Report.pictures(run.dir, name, null, Diff.png(shot.png()), null);
            finish(r, "NEW", null);
            candidates(page, name);
        }
    }

    boolean isKnown(String key) {
        return known.contains(key) || knownPatterns.contains(Site.pattern(key));
    }

    /** New pages are looked for under the new system's start address (its context path), not elsewhere on the host. */
    boolean underNewRoot(String url) {
        String prefix = mapping.toPrefix().replaceAll("/+$", "");
        if (prefix.isEmpty()) return true;
        String k = Site.key(url);
        return k.equals(prefix) || k.startsWith(prefix + "/") || k.startsWith(prefix + "?") || k.startsWith(prefix + "#");
    }

    boolean similarAllowed(String key) {
        String pattern = Site.pattern(key);
        return pattern.equals(key) || maxSimilar == 0 || perPattern.merge(pattern, 1, Integer::sum) <= maxSimilar;
    }

    void finish(Map<String, Object> r, String status, String reason) throws Exception {
        r.put("status", status);
        if (reason != null) list(r.get("reasons")).add(reason);
        String k = status.toLowerCase(Locale.ROOT);
        summary.put(k, num(summary.get(k), 0) + 1);
        jobs.save(run, false);
    }

    static String label(Map<String, Object> p) {
        return (s(p, "title").isBlank() ? "" : "\"" + clip(s(p, "title"), 60) + "\" ") + "(" + s(p, "key") + ")";
    }
}
