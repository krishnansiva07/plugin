package guardian;

import java.awt.image.BufferedImage;
import java.io.BufferedWriter;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import javax.imageio.ImageIO;

import static guardian.Json.*;
import static guardian.Util.*;

/**
 * The two pages Guardian writes: the comparison report (report.html: one file with the pictures inside it and no
 * scripts, so it can be opened anywhere and sent on) and the screenshot gallery of a package (index.html, next to
 * the screenshots in the package).
 */
final class Report {
    /** Pictures of a page in the report: at most this wide and tall (pixels). */
    static final int PICTURE_WIDTH = 1100, PICTURE_HEIGHT = 2600, FOCUS_HEIGHT = 2000;
    /** When the report's pictures add up to more than this, they are made smaller so the report still opens quickly. */
    static final long PICTURE_BUDGET = 150L * 1024 * 1024;

    // ---------------------------------------------------------------- pictures for the comparison report

    /** How the screenshot differs, in words. */
    static String describe(Diff.Images d) {
        String s = (d.areas().size() == 1 ? "1 area" : d.areas().size() + " areas") + " of the screenshot changed ("
                + String.format(Locale.ROOT, "%,d", d.changedPixels()) + " pixels, " + percent(d.percent()) + " of the page)";
        if (d.heightBefore() != d.heightAfter()) {
            int diff = d.heightAfter() - d.heightBefore();
            s += "; the page is " + String.format(Locale.ROOT, "%,d", Math.abs(diff)) + " px " + (diff > 0 ? "taller" : "shorter");
        }
        return s;
    }

    static String percent(double p) {
        return p > 0 && p < 0.01 ? "less than 0.01%" : String.format(Locale.ROOT, "%.2f%%", p);
    }

    /**
     * Writes the pictures of one page for the report: report-images/NAME-before.jpg, -after.jpg and -changes.jpg
     * (any of them may be missing). They show the part of the page around the changes; when the changes are spread
     * over the whole page, the whole page, smaller.
     */
    static void pictures(Path dir, String name, BufferedImage before, BufferedImage after, Diff.Images d) throws IOException {
        Path folder = dir.resolve("report-images");
        Files.createDirectories(folder);
        int w = Math.max(before == null ? 0 : before.getWidth(), after == null ? 0 : after.getWidth());
        int h = Math.max(before == null ? 0 : before.getHeight(), after == null ? 0 : after.getHeight());
        if (w == 0 || h == 0) return;
        int[] box;
        if (d == null || d.areas().isEmpty()) {
            box = new int[]{0, 0, w, Math.min(h, PICTURE_HEIGHT)};
        } else {
            int top = Integer.MAX_VALUE, bottom = 0;
            for (int[] a : d.areas()) {
                top = Math.min(top, a[1]);
                bottom = Math.max(bottom, a[1] + a[3]);
            }
            box = bottom - top + 320 <= FOCUS_HEIGHT ? Diff.focus(d.areas(), w, h, FOCUS_HEIGHT) : new int[]{0, 0, w, h};
        }
        if (before != null) Files.write(folder.resolve(name + "-before.jpg"), Diff.jpeg(Diff.cut(before, box, PICTURE_WIDTH, PICTURE_HEIGHT), 0.82f));
        if (after != null) Files.write(folder.resolve(name + "-after.jpg"), Diff.jpeg(Diff.cut(after, box, PICTURE_WIDTH, PICTURE_HEIGHT), 0.82f));
        if (d != null) Files.write(folder.resolve(name + "-changes.jpg"), Diff.jpeg(Diff.cut(d.overlay(), box, PICTURE_WIDTH, PICTURE_HEIGHT), 0.82f));
        Util.save(folder.resolve(name + ".json"), obj("top", box[1], "height", box[3], "pageHeight", h, "whole", box[1] == 0 && box[3] >= h));
    }

    // ---------------------------------------------------------------- comparison report

    static final List<String> ORDER = List.of("CHANGED", "MISSING", "NEW", "SAME", "SKIPPED");

    /** Writes report.html for a comparison (also for one that was stopped: it then says which pages were not compared). */
    static void comparison(Path dir, Map<String, Object> job, Map<String, Object> manifest) throws IOException {
        var results = list(job.get("results"));
        var pkg = map(job.get("package"));
        var cfg = map(job.get("settings"));
        var captured = map(manifest.get("settings"));
        var summary = map(job.get("summary"));
        var images = new ArrayList<Path>();
        long total = 0;
        try (var files = Files.list(dir.resolve("report-images"))) {
            for (Path p : files.toList()) {
                if (p.toString().endsWith(".jpg")) {
                    images.add(p);
                    total += Files.size(p);
                }
            }
        } catch (IOException e) {
            // no pictures
        }
        double shrink = total > PICTURE_BUDGET ? Math.sqrt(PICTURE_BUDGET / (double) total) : 1;

        Path tmp = dir.resolve("report.html.tmp");
        try (BufferedWriter out = Files.newBufferedWriter(tmp, StandardCharsets.UTF_8)) {
            int changed = num(summary.get("changed"), 0), missing = num(summary.get("missing"), 0), added = num(summary.get("new"), 0);
            String verdict = changed + missing + added == 0 ? "No differences found"
                    : String.join(", ", nonZero(changed, "page changed", "pages changed", missing, "page missing", "pages missing", added, "new page", "new pages"));
            String host = Session.host(s(job, "url"));
            out.write("<!doctype html>\n<html lang=\"en\"><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">\n");
            out.write("<title>Comparison report: " + esc(host) + "</title>\n<style>" + CSS + "</style></head>\n<body>\n<header class=\"top\"><div class=\"wrap\">\n");
            out.write("<p class=\"brand\">ASTRA Visual Guardian &middot; comparison report</p>\n<h1>" + esc(verdict) + "</h1>\n<table class=\"meta\">\n");
            out.write(row("Before", link(s(manifest, "application")) + " &middot; captured " + esc(date(s(manifest, "captured")))));
            out.write(row("After", link(s(job, "url")) + " &middot; compared " + esc(date(s(job, "created")))));
            out.write(row("Pages", esc(list(manifest.get("pages")).size() + " pages in the package") + " &middot; window "
                    + esc(num(captured.get("width"), 0) + " × " + num(captured.get("height"), 0)) + " &middot; "
                    + (b(captured, "fullPage") ? "whole pages" : "the visible part of each page")));
            String vb = s(manifest, "browserVersion"), va = s(job, "browserVersion");
            out.write(row("Browser", esc(vb.isBlank() ? "unknown" : vb) + (vb.equals(va) ? " (both times)" : " / " + esc(va))));
            var settings = new ArrayList<String>();
            double tolerance = dbl(cfg.get("tolerance"), 0);
            settings.add(tolerance > 0 ? "differences up to " + percent(tolerance) + " of a page are ignored" : "every difference counts");
            var masks = new ArrayList<String>(strings(captured.get("masks")));
            for (String m : strings(cfg.get("masks"))) if (!masks.contains(m)) masks.add(m);
            if (!masks.isEmpty()) settings.add("areas hidden: " + String.join(", ", masks));
            var mapping = map(job.get("mapping"));
            if (!s(mapping, "from").isBlank()) settings.add("addresses " + s(mapping, "from") + "… opened as " + s(mapping, "to") + "…");
            out.write(row("Settings", esc(String.join(" · ", settings))));
            out.write("</table>\n");
            var notes = new ArrayList<String>();
            int compared = 0;
            var done = new HashSet<String>();
            for (Object o : results) if (num(map(o).get("n"), 0) > 0) {
                compared++;
                done.add(s(map(o), "key"));
            }
            int inPackage = list(manifest.get("pages")).size();
            if (!s(job, "status").equals("DONE") && !s(job, "status").equals("RUNNING"))
                notes.add("This comparison did not finish (" + s(job, "status").toLowerCase(Locale.ROOT) + "): " + compared + " of " + inPackage
                        + " pages were compared." + (s(job, "message").isBlank() ? "" : " " + s(job, "message")));
            if (!vb.isBlank() && !va.isBlank() && !vb.equals(va))
                notes.add("The browser version differs from the capture. That can draw text slightly differently; compare on the same computer and browser for the cleanest result.");
            if (!b(manifest, "complete"))
                notes.add("The package itself is incomplete: its capture stopped before every page was opened, so pages it never reached may show as new.");
            if (missing >= 3 && missing * 2 > compared)
                notes.add("Most pages were not found on the new system. If its pages live under another path (for example /portal instead of /app), "
                        + "enter the old and new start paths under More settings and compare again.");
            if (shrink < 1) notes.add("Many pages changed, so the pictures in this report are smaller than usual.");
            for (String n : notes) out.write("<p class=\"note\">" + esc(n) + "</p>\n");
            out.write("<nav class=\"cards\">\n");
            for (String status : ORDER) {
                int count = num(summary.get(status.toLowerCase(Locale.ROOT)), 0);
                if (count == 0 && (status.equals("SKIPPED") || status.equals("NEW") && !b(cfg, "findNew"))) continue;
                out.write("<a class=\"card " + status + "\" href=\"#" + status.toLowerCase(Locale.ROOT) + "\"><b>" + count + "</b>" + esc(heading(status, false)) + "</a>\n");
            }
            out.write("</nav>\n</div></header>\n<main class=\"wrap\">\n");

            for (String status : ORDER) {
                var group = new ArrayList<Map<String, Object>>();
                for (Object o : results) if (s(map(o), "status").equals(status)) group.add(map(o));
                if (group.isEmpty()) continue;
                out.write("<section id=\"" + status.toLowerCase(Locale.ROOT) + "\"><h2>" + esc(heading(status, true)) + " <span class=\"count\">" + group.size() + "</span></h2>\n");
                out.write("<p class=\"hint\">" + esc(hint(status)) + "</p>\n");
                if (status.equals("SAME") || status.equals("SKIPPED")) {
                    out.write("<details><summary>Show the list</summary>\n");
                    table(out, group, status.equals("SKIPPED"));
                    out.write("</details></section>\n");
                    continue;
                }
                table(out, group, true);
                for (var r : group) article(out, dir, r, shrink);
                out.write("</section>\n");
            }

            var left = new ArrayList<Map<String, Object>>();
            for (Object o : list(manifest.get("pages"))) if (!done.contains(s(map(o), "key"))) left.add(map(o));
            if (!left.isEmpty()) {
                out.write("<section id=\"notcompared\"><h2>Not compared <span class=\"count\">" + left.size() + "</span></h2>\n");
                out.write("<p class=\"hint\">The comparison stopped before these pages of the package.</p>\n<details><summary>Show the list</summary>\n");
                out.write("<table class=\"list\"><thead><tr><th>#</th><th>Page</th></tr></thead><tbody>\n");
                for (var p : left)
                    out.write("<tr><td>" + num(p.get("n"), 0) + "</td><td>" + esc(s(p, "title")) + "<div class=\"key\">" + esc(s(p, "key")) + "</div></td></tr>\n");
                out.write("</tbody></table></details></section>\n");
            }
            out.write("</main>\n<footer class=\"wrap\">Created by ASTRA Visual Guardian on " + esc(date(now())) + ". Pictures show the part of each page around its changes. "
                    + "Each screenshot is compared pixel by pixel (small colour differences from font smoothing are ignored), and the visible text and the title are compared too.</footer>\n</body></html>\n");
        }
        Files.move(tmp, dir.resolve("report.html"), StandardCopyOption.REPLACE_EXISTING);
    }

    static void table(Writer out, List<Map<String, Object>> group, boolean reasons) throws IOException {
        out.write("<table class=\"list\"><thead><tr><th>#</th><th>Page</th>" + (reasons ? "<th>What</th>" : "") + "</tr></thead><tbody>\n");
        for (var r : group) {
            String status = s(r, "status");
            boolean linked = !status.equals("SAME") && !status.equals("SKIPPED");
            String title = s(r, "title").isBlank() ? s(r, "key") : s(r, "title");
            out.write("<tr><td>" + esc(number(r)) + "</td><td>" + (linked ? "<a href=\"#p-" + esc(s(r, "name")) + "\">" + esc(title) + "</a>" : esc(title))
                    + "<div class=\"key\">" + esc(s(r, "key")) + "</div></td>" + (reasons ? "<td>" + esc(String.join("; ", strings(r.get("reasons")))) + "</td>" : "") + "</tr>\n");
        }
        out.write("</tbody></table>\n");
    }

    static void article(Writer out, Path dir, Map<String, Object> r, double shrink) throws IOException {
        String name = s(r, "name"), status = s(r, "status");
        out.write("<article class=\"page\" id=\"p-" + esc(name) + "\">\n<div class=\"head\"><span class=\"badge " + status + "\">" + esc(heading(status, false))
                + "</span><h3>" + esc(number(r)) + ". " + esc(s(r, "title").isBlank() ? s(r, "key") : s(r, "title")) + "</h3></div>\n");
        if (!s(r, "before").isBlank()) out.write("<div class=\"addr\"><span>Before</span>" + link(s(r, "before")) + "</div>\n");
        String after = s(r, "after").isBlank() ? s(r, "url") : s(r, "after");
        if (!after.isBlank()) out.write("<div class=\"addr\"><span>" + (status.equals("NEW") ? "Address" : "After") + "</span>" + link(after)
                + (num(r.get("httpStatus"), 0) >= 400 ? " <b class=\"http\">HTTP " + num(r.get("httpStatus"), 0) + "</b>" : "") + "</div>\n");
        out.write("<ul class=\"why\">");
        for (String reason : strings(r.get("reasons"))) out.write("<li>" + esc(reason) + "</li>");
        out.write("</ul>\n");
        var views = new ArrayList<String[]>();
        for (String[] v : new String[][]{{"changes", "Changes", "The new page, faded, with what differs in red"}, {"before", "Before", "The page in the package"},
                {"after", status.equals("NEW") ? "New page" : "After", "The page on the new system"}}) {
            Path f = dir.resolve("report-images").resolve(name + "-" + v[0] + ".jpg");
            if (Files.exists(f)) views.add(new String[]{picture(f, shrink), v[1], v[2]});
        }
        if (!views.isEmpty()) {
            out.write("<div class=\"tabs\">");
            for (int i = 0; i < views.size(); i++)
                out.write("<input type=\"radio\" name=\"v-" + esc(name) + "\" id=\"v-" + esc(name) + "-" + i + "\"" + (i == 0 ? " checked" : "") + "><label for=\"v-"
                        + esc(name) + "-" + i + "\">" + esc(views.get(i)[1]) + "</label>");
            for (String[] v : views) out.write("<div class=\"view\"><img src=\"" + v[0] + "\" alt=\"" + esc(v[2]) + "\"></div>");
            out.write("</div>\n");
            var crop = map(loadQuietly(dir.resolve("report-images").resolve(name + ".json")));
            if (!crop.isEmpty() && !b(crop, "whole") && views.size() > 1)
                out.write("<p class=\"crop\">Showing pixels " + String.format(Locale.ROOT, "%,d", num(crop.get("top"), 0)) + " to "
                        + String.format(Locale.ROOT, "%,d", num(crop.get("top"), 0) + num(crop.get("height"), 0)) + " of the page ("
                        + String.format(Locale.ROOT, "%,d", num(crop.get("pageHeight"), 0)) + " pixels tall), where the changes are.</p>\n");
        }
        List<String> added = strings(r.get("added")), removed = strings(r.get("removed"));
        if (!added.isEmpty() || !removed.isEmpty()) {
            out.write("<details class=\"text\"><summary>Text changes (" + added.size() + " added, " + removed.size() + " removed)</summary><div class=\"cols\">");
            out.write("<div><h4>Removed</h4><ul>");
            for (String l : removed) out.write("<li class=\"del\">" + esc(l) + "</li>");
            out.write("</ul></div><div><h4>Added</h4><ul>");
            for (String l : added) out.write("<li class=\"add\">" + esc(l) + "</li>");
            out.write("</ul></div></div></details>\n");
        }
        out.write("</article>\n");
    }

    /** A picture as a data: address, made smaller when the report would otherwise be too large. */
    static String picture(Path f, double shrink) throws IOException {
        byte[] bytes = Files.readAllBytes(f);
        if (shrink < 1) {
            BufferedImage img = ImageIO.read(new ByteArrayInputStream(bytes));
            if (img != null) {
                int w = Math.max(320, (int) (img.getWidth() * shrink));
                double scale = Math.min(1, w / (double) img.getWidth());
                int h = Math.max(1, (int) (img.getHeight() * scale));
                bytes = Diff.jpeg(Diff.cut(img, new int[]{0, 0, img.getWidth(), img.getHeight()}, w, h), 0.78f);
            }
        }
        return "data:image/jpeg;base64," + Base64.getEncoder().encodeToString(bytes);
    }

    static Object loadQuietly(Path p) {
        try {
            return Files.exists(p) ? load(p) : obj();
        } catch (Exception e) {
            return obj();
        }
    }

    static String number(Map<String, Object> r) {
        return s(r, "name").startsWith("new-") ? "N" + Integer.parseInt(s(r, "name").substring(4)) : String.valueOf(num(r.get("n"), 0));
    }

    static String heading(String status, boolean long_) {
        return switch (status) {
            case "CHANGED" -> long_ ? "Changed pages" : "Changed";
            case "MISSING" -> long_ ? "Missing pages" : "Missing";
            case "NEW" -> long_ ? "New pages" : "New";
            case "SAME" -> long_ ? "Unchanged pages" : "Unchanged";
            default -> long_ ? "Skipped pages" : "Skipped";
        };
    }

    static String hint(String status) {
        return switch (status) {
            case "CHANGED" -> "Red marks what differs. Switch between Before and After to see the change.";
            case "MISSING" -> "Pages of the package that the new system does not have: they could not be opened, answered with an error, or now open another page.";
            case "NEW" -> "Pages the new system links to that are not in the package.";
            case "SAME" -> "These pages look exactly as they did.";
            default -> "These pages match \"Pages to skip\" and were not compared.";
        };
    }

    static List<String> nonZero(Object... parts) {
        var out = new ArrayList<String>();
        for (int i = 0; i < parts.length; i += 3) {
            int n = (Integer) parts[i];
            if (n > 0) out.add(n + " " + (n == 1 ? parts[i + 1] : parts[i + 2]));
        }
        return out;
    }

    static String row(String name, String html) {
        return "<tr><th>" + esc(name) + "</th><td>" + html + "</td></tr>\n";
    }

    /** A link to a page of the application (opens in a new tab; only http and https). */
    static String link(String url) {
        if (!url.matches("(?i)https?://.*")) return esc(url);
        return "<a href=\"" + esc(url) + "\" target=\"_blank\" rel=\"noreferrer noopener\">" + esc(url) + "</a>";
    }

    static String date(String iso) {
        try {
            return DateTimeFormatter.ofPattern("d MMM yyyy, HH:mm", Locale.ENGLISH).format(Instant.parse(iso).atZone(ZoneId.systemDefault()));
        } catch (Exception e) {
            return iso;
        }
    }

    // ---------------------------------------------------------------- gallery of a package

    /** index.html of a package: every screenshot with its page, links that were not opened, and similar pages left out. */
    static String gallery(Map<String, Object> m) {
        var h = new StringBuilder();
        var cfg = map(m.get("settings"));
        var pages = list(m.get("pages"));
        String host = Session.host(s(m, "application"));
        h.append("<!doctype html>\n<html lang=\"en\"><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">\n");
        h.append("<title>Screenshots: ").append(esc(host)).append("</title>\n<style>").append(CSS).append("</style></head>\n<body>\n<header class=\"top\"><div class=\"wrap\">\n");
        h.append("<p class=\"brand\">ASTRA Visual Guardian &middot; package</p>\n<h1>").append(pages.size()).append(pages.size() == 1 ? " page of " : " pages of ")
                .append(esc(host)).append("</h1>\n<table class=\"meta\">\n");
        h.append(row("Application", link(s(m, "application"))));
        h.append(row("Captured", esc(date(s(m, "captured")))));
        h.append(row("Window", esc(num(cfg.get("width"), 0) + " × " + num(cfg.get("height"), 0) + " · " + (b(cfg, "fullPage") ? "whole pages" : "visible part only"))));
        if (!s(m, "browserVersion").isBlank()) h.append(row("Browser", esc(s(m, "browserVersion"))));
        h.append("</table>\n");
        if (!b(m, "complete")) {
            int left = list(m.get("notVisited")).size();
            h.append("<p class=\"note\">").append(esc("This capture stopped before every page was opened" + (b(m, "limitReached")
                    ? " (the limit of " + num(cfg.get("maxPages"), 0) + " pages was reached)" : "") + (left > 0 ? ": " + left + " more pages were found." : "."))).append("</p>\n");
        }
        h.append("<p class=\"hint\">To compare, open Guardian after the migration or deployment, choose Compare, upload this package (the ZIP file) and enter the new address.</p>\n");
        h.append("</div></header>\n<main class=\"wrap\">\n<section><h2>Pages <span class=\"count\">").append(pages.size()).append("</span></h2>\n<div class=\"grid\">\n");
        for (Object o : pages) {
            var p = map(o);
            String shot = s(p, "shot");
            h.append("<figure><a href=\"").append(esc(shot)).append("\" target=\"_blank\"><img src=\"").append(esc(shot)).append("\" loading=\"lazy\" alt=\"Screenshot of page ")
                    .append(num(p.get("n"), 0)).append("\"></a><figcaption><b>").append(num(p.get("n"), 0)).append(". ")
                    .append(esc(s(p, "title").isBlank() ? s(p, "key") : s(p, "title"))).append("</b><div class=\"key\">").append(esc(s(p, "key"))).append("</div><small>")
                    .append(esc(s(p, "via"))).append(num(p.get("status"), 0) >= 400 ? " · HTTP " + num(p.get("status"), 0) : "").append("</small></figcaption></figure>\n");
        }
        h.append("</div></section>\n");
        var notOpened = list(m.get("notOpened"));
        if (!notOpened.isEmpty()) {
            h.append("<section><h2>Links not opened <span class=\"count\">").append(notOpened.size()).append("</span></h2>\n")
                    .append("<p class=\"hint\">Downloads, sign-out links, links that look like actions, pages to skip, and pages that could not be opened.</p>\n")
                    .append("<details><summary>Show the list</summary><table class=\"list\"><thead><tr><th>Why</th><th>Link</th><th>On page</th></tr></thead><tbody>\n");
            for (Object o : notOpened) {
                var x = map(o);
                h.append("<tr><td>").append(esc(s(x, "reason"))).append("</td><td>").append(esc(s(x, "text"))).append("<div class=\"key\">").append(esc(s(x, "url")))
                        .append("</div></td><td>").append(num(x.get("page"), 0) > 0 ? num(x.get("page"), 0) : "").append("</td></tr>\n");
            }
            h.append("</tbody></table></details></section>\n");
        }
        var similar = map(m.get("similar"));
        if (!similar.isEmpty()) {
            h.append("<section><h2>Similar pages left out</h2>\n<p class=\"hint\">Only the first ").append(num(cfg.get("maxSimilar"), 0))
                    .append(" pages of each kind below were captured: the others are the same page with other data (another invoice, another customer).</p>\n")
                    .append("<table class=\"list\"><thead><tr><th>Address pattern</th><th>Left out</th></tr></thead><tbody>\n");
            for (var e : similar.entrySet())
                h.append("<tr><td class=\"key\">").append(esc(e.getKey())).append("</td><td>").append(num(e.getValue(), 0)).append("</td></tr>\n");
            h.append("</tbody></table></section>\n");
        }
        h.append("</main>\n<footer class=\"wrap\">Created by ASTRA Visual Guardian.</footer>\n</body></html>\n");
        return h.toString();
    }

    static final String CSS = """
            :root{--ink:#1c2433;--muted:#5b6475;--line:#dde2ea;--bg:#f5f6f8;--card:#fff;--CHANGED:#c2410c;--MISSING:#b91c1c;--NEW:#1d4ed8;--SAME:#15803d;--SKIPPED:#6b7280}
            *{box-sizing:border-box}body{margin:0;font:15px/1.5 system-ui,-apple-system,"Segoe UI",Roboto,Arial,sans-serif;color:var(--ink);background:var(--bg)}
            .wrap{max-width:1240px;margin:0 auto;padding:0 24px}.top{background:var(--card);border-bottom:1px solid var(--line);padding:20px 0 8px}
            .brand{margin:0;color:var(--muted);font-size:13px;letter-spacing:.03em;text-transform:uppercase}h1{font-size:28px;margin:4px 0 12px;line-height:1.2}
            h2{font-size:21px;margin:36px 0 6px}h3{font-size:17px;margin:0;line-height:1.3}h4{margin:0 0 6px;font-size:14px}a{color:#1d4ed8}
            .meta{border-collapse:collapse;margin:8px 0 12px}.meta th{text-align:left;padding:3px 18px 3px 0;color:var(--muted);font-weight:600;vertical-align:top;white-space:nowrap}
            .meta td{padding:3px 0;word-break:break-word}.note{background:#fff7e6;border:1px solid #f1d08a;padding:10px 14px;border-radius:8px;margin:10px 0}
            .cards{display:flex;gap:12px;flex-wrap:wrap;margin:16px 0 14px}.card{display:block;min-width:140px;padding:12px 16px;border-radius:10px;background:var(--bg);
            border:1px solid var(--line);text-decoration:none;color:var(--ink);font-weight:600}.card b{display:block;font-size:30px;line-height:1.1}
            .card.CHANGED b{color:var(--CHANGED)}.card.MISSING b{color:var(--MISSING)}.card.NEW b{color:var(--NEW)}.card.SAME b{color:var(--SAME)}.card.SKIPPED b{color:var(--SKIPPED)}
            .count{display:inline-block;min-width:28px;padding:0 8px;border-radius:999px;background:var(--line);font-size:14px;text-align:center;vertical-align:3px}
            .hint{color:var(--muted);margin:0 0 12px}.list{width:100%;border-collapse:collapse;background:var(--card);border:1px solid var(--line);margin:8px 0 18px}
            .list th,.list td{padding:8px 10px;border-bottom:1px solid var(--line);text-align:left;vertical-align:top}.list th{background:var(--bg);font-size:13px;color:var(--muted)}
            .key{font-family:ui-monospace,Consolas,"Courier New",monospace;font-size:12.5px;color:var(--muted);word-break:break-all}
            details summary{cursor:pointer;color:#1d4ed8;font-weight:600;margin:6px 0}
            .page{background:var(--card);border:1px solid var(--line);border-radius:12px;padding:18px 20px;margin:18px 0}
            .head{display:flex;align-items:center;gap:10px;margin-bottom:8px}.badge{font-size:12px;font-weight:700;letter-spacing:.03em;text-transform:uppercase;
            padding:3px 9px;border-radius:999px;color:#fff;white-space:nowrap}.badge.CHANGED{background:var(--CHANGED)}.badge.MISSING{background:var(--MISSING)}
            .badge.NEW{background:var(--NEW)}.badge.SAME{background:var(--SAME)}.badge.SKIPPED{background:var(--SKIPPED)}
            .addr{font-size:13.5px;word-break:break-all;margin:2px 0}.addr span{display:inline-block;width:64px;color:var(--muted);font-weight:600}.http{color:var(--MISSING)}
            .why{margin:8px 0 4px;padding-left:20px}.tabs{margin-top:12px}.tabs input{position:absolute;opacity:0;pointer-events:none}
            .tabs label{display:inline-block;padding:7px 16px;margin-right:4px;border:1px solid var(--line);border-bottom:none;border-radius:8px 8px 0 0;background:var(--bg);
            color:var(--muted);font-weight:600;cursor:pointer}.tabs input:checked+label{background:var(--card);color:var(--ink);box-shadow:inset 0 3px 0 #1d4ed8}
            .tabs input:focus-visible+label{outline:2px solid #1d4ed8;outline-offset:2px}.tabs .view{display:none;border:1px solid var(--line);padding:10px;background:#fafbfc;overflow:auto}
            .tabs input:nth-of-type(1):checked~.view:nth-of-type(1),.tabs input:nth-of-type(2):checked~.view:nth-of-type(2),
            .tabs input:nth-of-type(3):checked~.view:nth-of-type(3){display:block}.view img{display:block;max-width:100%;height:auto;margin:0 auto;border:1px solid var(--line)}
            .crop{color:var(--muted);font-size:13px;margin:6px 0 0}.text .cols{display:grid;grid-template-columns:1fr 1fr;gap:18px}.text ul{margin:0;padding-left:18px}
            .text li{word-break:break-word}.text li.add{color:#166534}.text li.del{color:#991b1b}
            .grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:16px}figure{margin:0;background:var(--card);border:1px solid var(--line);border-radius:10px;overflow:hidden}
            figure img{display:block;width:100%;height:200px;object-fit:cover;object-position:top;border-bottom:1px solid var(--line)}figcaption{padding:10px 12px;font-size:14px}
            figcaption small{color:var(--muted)}footer{color:var(--muted);font-size:13px;padding:30px 24px 40px}
            @media (max-width:700px){.text .cols{grid-template-columns:1fr}.card{min-width:110px}}
            """;
}
