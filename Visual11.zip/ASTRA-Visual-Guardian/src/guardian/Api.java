package guardian;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URLDecoder;
import java.nio.channels.FileChannel;
import java.nio.channels.FileLock;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.security.MessageDigest;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;

import static guardian.Json.*;
import static guardian.Util.*;

/**
 * Everything the UI can ask for, without any HTTP server. Two front doors use it: the built-in server
 * ({@link Main}, no dependencies) and Spring Boot (folder spring/), so both behave the same.
 *
 * <pre>
 * GET  /api/jobs                    captures and comparisons (History)
 * GET  /api/jobs/{id}?since=        one of them; a short answer when nothing changed since "since"
 * GET  /api/baselines               packages to compare against (captures made here, packages uploaded here)
 * POST /api/captures                start a capture       {url, signIn, settings}
 * POST /api/compares                start a comparison    {package, url, signIn, settings}
 * POST /api/packages                upload a package (the ZIP file is the request body)
 * POST /api/jobs/command            {id, command: continue | stop}
 * POST /api/jobs/delete             {id}
 * POST /api/packages/delete         {id}
 * GET  /files/{key}/{id}/{file}     package.zip, report.html, index.html (screenshots) and shots/*.png
 * </pre>
 * API calls need the X-Guardian-Token header; files need the file key in their address. Both come with the UI
 * page, so other web pages cannot use Guardian.
 */
public final class Api implements AutoCloseable {
    public static final int JSON_LIMIT = 2 * 1024 * 1024;

    /** Security headers sent with every answer. */
    public static final Map<String, String> HEADERS = Map.of(
            "Cache-Control", "no-store",
            "X-Content-Type-Options", "nosniff",
            "X-Frame-Options", "DENY",
            "Referrer-Policy", "no-referrer",
            "Content-Security-Policy", "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; "
                    + "connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'none'");

    static final Pattern FILE = Pattern.compile("package\\.zip|report\\.html|index\\.html|shots/[A-Za-z0-9-]{1,20}\\.png");

    /** An answer: status, content type, and either bytes or a file to send; a file name makes it a download. */
    public record Reply(int status, String type, byte[] body, Path file, String filename) {
        public static Reply json(int status, Object value) {
            return new Reply(status, "application/json;charset=utf-8", write(value).getBytes(StandardCharsets.UTF_8), null, "");
        }

        public static Reply json(Object value) {
            return json(200, value);
        }

        public long length() throws IOException {
            return file == null ? body.length : Files.size(file);
        }

        /** Sends the body (copying the file, for files). */
        public void writeTo(OutputStream out) throws IOException {
            if (file == null) out.write(body);
            else Files.copy(file, out);
        }
    }

    final Path root;
    final Jobs jobs;
    /** Session token for API calls: the UI page carries it, every API call must send it back. */
    public final String token = id() + id();
    /** Session key for opening reports, screenshots and packages in the browser (part of their address). */
    public final String fileKey = (id() + id()).replace("-", "");
    private final FileChannel lockChannel;
    private final FileLock lock;

    private Api(Path root, Jobs jobs, FileChannel lockChannel, FileLock lock) {
        this.root = root;
        this.jobs = jobs;
        this.lockChannel = lockChannel;
        this.lock = lock;
    }

    /** Opens a data folder; only one Guardian may use it at a time. */
    public static Api open(Path folder) throws Exception {
        Path dir = folder.toAbsolutePath();
        Files.createDirectories(dir);
        FileChannel channel = FileChannel.open(dir.resolve(".lock"), StandardOpenOption.CREATE, StandardOpenOption.WRITE);
        FileLock lock;
        try {
            lock = channel.tryLock();
        } catch (Exception e) {
            channel.close();
            throw e;
        }
        if (lock == null) {
            channel.close();
            throw new IOException("Another Guardian is using this data folder: " + dir);
        }
        try {
            return new Api(dir, new Jobs(dir), channel, lock);
        } catch (Exception e) {
            lock.release();
            channel.close();
            throw e;
        }
    }

    public Path root() {
        return root;
    }

    /** Stops what is running, closes its browser and frees the data folder. */
    @Override
    public void close() {
        jobs.close();
        try {
            lock.release();
            lockChannel.close();
        } catch (Exception ignored) {
            // shutting down anyway
        }
    }

    // ---------------------------------------------------------------- checks

    /**
     * Local-only checks; null when the request may go on. Every request must name this computer in its Host
     * header (stops DNS-rebinding pages). API calls also need the session token and, when a browser sends an
     * Origin, this app's own origin.
     */
    public Reply refuse(String path, String host, String origin, String tokenHeader, int port) {
        if (!Set.of("127.0.0.1:" + port, "localhost:" + port).contains(host)) return Reply.json(403, obj("error", "Invalid host"));
        if (!path.startsWith("/api/")) return null;
        if (tokenHeader == null || !MessageDigest.isEqual(token.getBytes(StandardCharsets.UTF_8), tokenHeader.getBytes(StandardCharsets.UTF_8)))
            return Reply.json(403, obj("error", "Local session token required"));
        if (origin != null && !Set.of("http://127.0.0.1:" + port, "http://localhost:" + port).contains(origin))
            return Reply.json(403, obj("error", "Invalid origin"));
        return null;
    }

    // ---------------------------------------------------------------- requests

    /** Answers one request (after {@link #refuse}). Exceptions become answers through {@link #error}. */
    public Reply handle(String method, String path, String query, InputStream body) throws Exception {
        if (path.startsWith("/files/")) return method.equals("GET") ? file(path, query) : methodNotAllowed();
        if (!path.startsWith("/api/")) return method.equals("GET") ? page(path) : methodNotAllowed();
        if (method.equals("GET")) {
            if (path.equals("/api/jobs")) return Reply.json(jobs.history());
            if (path.equals("/api/baselines")) return Reply.json(jobs.baselines());
            if (path.startsWith("/api/jobs/")) return Reply.json(jobs.get(path.substring("/api/jobs/".length()), param(query, "since")));
            return unknown();
        }
        if (!method.equals("POST")) return methodNotAllowed();
        if (path.equals("/api/packages")) return Reply.json(jobs.importPackage(body));
        var in = read(new String(readLimited(body, JSON_LIMIT), StandardCharsets.UTF_8));
        switch (path) {
            case "/api/captures":
                return Reply.json(jobs.startCapture(in));
            case "/api/compares":
                return Reply.json(jobs.startCompare(in));
            case "/api/jobs/command":
                jobs.command(s(in, "id"), s(in, "command"));
                return Reply.json(obj("ok", true));
            case "/api/jobs/delete":
                jobs.delete(s(in, "id"));
                return Reply.json(obj("ok", true));
            case "/api/packages/delete":
                jobs.deletePackage(s(in, "id"));
                return Reply.json(obj("ok", true));
            default:
                return unknown();
        }
    }

    /** The UI: one page (carrying this session's token and file key), its script and its style sheet. */
    Reply page(String path) throws IOException {
        String file = switch (path) {
            case "/", "/index.html" -> "index.html";
            case "/app.js" -> "app.js";
            case "/style.css" -> "style.css";
            default -> "";
        };
        if (file.isEmpty()) return Reply.json(404, obj("error", "Not found"));
        try (InputStream in = Api.class.getResourceAsStream("/" + file)) {
            if (in == null) throw new NoSuchFileException(file);
            byte[] b = in.readAllBytes();
            if (file.equals("index.html"))
                b = new String(b, StandardCharsets.UTF_8).replace("__GUARDIAN_TOKEN__", token).replace("__GUARDIAN_FILES__", fileKey).getBytes(StandardCharsets.UTF_8);
            String type = file.endsWith(".js") ? "application/javascript;charset=utf-8" : file.endsWith(".css") ? "text/css;charset=utf-8" : "text/html;charset=utf-8";
            return new Reply(200, type, b, null, "");
        }
    }

    /** A file of a capture, comparison or uploaded package: /files/{key}/{id}/{file}. "?download" makes it a download. */
    Reply file(String path, String query) throws IOException {
        String[] seg = path.substring("/files/".length()).split("/", 3);
        if (seg.length < 3 || !MessageDigest.isEqual(fileKey.getBytes(StandardCharsets.UTF_8), seg[0].getBytes(StandardCharsets.UTF_8))
                || !seg[1].matches("[a-zA-Z0-9_-]{1,80}") || !FILE.matcher(seg[2]).matches())
            return Reply.json(404, obj("error", "Not found"));
        Path dir = jobs.dir(seg[1]);
        if (!Files.exists(dir.resolve("job.json"))) dir = jobs.packages.resolve(seg[1]);
        Path f = under(dir, seg[2]);
        if (!Files.isRegularFile(f)) return Reply.json(404, obj("error", "Not found (it may not be ready yet)"));
        String name = seg[2];
        String type = name.endsWith(".png") ? "image/png" : name.endsWith(".zip") ? "application/zip" : "text/html;charset=utf-8";
        String download = "";
        if (name.equals("package.zip") || query != null && query.matches("(^|.*&)download(=[^&]*)?(&.*|$)")) download = downloadName(dir, name);
        return new Reply(200, type, null, f, download);
    }

    /** guardian-package-HOST-DATE.zip, guardian-report-HOST-DATE.html */
    static String downloadName(Path dir, String name) {
        String host = "app", date = "";
        try {
            Path f = Files.exists(dir.resolve("job.json")) ? dir.resolve("job.json") : dir.resolve("guardian-package.json");
            var m = load(f);
            host = Session.host(s(m, m.containsKey("application") ? "application" : "url"));
            date = s(m, m.containsKey("captured") ? "captured" : "created");
        } catch (Exception ignored) {
            // a plain name then
        }
        String stamp = date.length() >= 16 ? date.substring(0, 16).replace(":", "").replace("T", "-") : "";
        String base = (name.equals("package.zip") ? "guardian-package-" : name.equals("report.html") ? "guardian-report-" : "guardian-")
                + host.replaceAll("[^A-Za-z0-9.-]", "_") + (stamp.isEmpty() ? "" : "-" + stamp);
        return base + (name.endsWith(".zip") ? ".zip" : name.endsWith(".png") ? ".png" : ".html");
    }

    static String param(String query, String name) {
        if (query == null) return "";
        for (String part : query.split("&")) {
            int i = part.indexOf('=');
            if ((i < 0 ? part : part.substring(0, i)).equals(name)) return i < 0 ? "" : URLDecoder.decode(part.substring(i + 1), StandardCharsets.UTF_8);
        }
        return "";
    }

    /** The answer for a failed request: 404 for something that does not exist, otherwise 400 with the reason. */
    public static Reply error(Exception ex) {
        if (ex instanceof NoSuchFileException) return Reply.json(404, obj("error", "Not found"));
        return Reply.json(400, obj("error", message(ex)));
    }

    public static Reply methodNotAllowed() {
        return Reply.json(405, obj("error", "Method not allowed"));
    }

    public static Reply unknown() {
        return Reply.json(404, obj("error", "Unknown endpoint"));
    }

    /** Reads a request body, refusing more than max bytes. */
    public static byte[] readLimited(InputStream in, int max) throws IOException {
        byte[] b = in.readNBytes(max + 1);
        if (b.length > max) throw new IOException("Request exceeds size limit");
        return b;
    }
}
