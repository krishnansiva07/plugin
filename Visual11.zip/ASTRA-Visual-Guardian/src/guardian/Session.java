package guardian;

import java.io.IOException;
import java.net.URI;
import java.util.Locale;
import java.util.Objects;
import java.util.concurrent.TimeoutException;
import java.util.regex.Pattern;

import static guardian.Util.*;

/**
 * Opening the application's pages, with pauses for you: signing in (SSO, PIN, one-time code), accepting a
 * certificate, or signing in again when the session runs out. Used by both capture and comparison.
 */
final class Session {
    static final String SIGN_IN_FIRST = "Sign in to the application in the browser window (SSO, PIN, certificate...). "
            + "When you see the application, press Continue.";
    static final String SIGN_IN = "The application shows a sign-in page. Sign in in the browser window, then press Continue.";
    static final String SIGN_IN_AGAIN = "The application asked you to sign in again. Sign in in the browser window, then press Continue.";
    static final String CERTIFICATE = "The browser does not trust this site's certificate. If you trust it, accept it in the browser window "
            + "(Advanced, then Proceed), sign in if asked, then press Continue.";
    static final String NO_ANSWER = "The application did not answer within a minute. If the browser asks for a certificate, PIN or sign-in, "
            + "complete it, then press Continue.";

    /** Sign-in services on another host: login.example.com, sso.example.com, adfs, Okta, Microsoft, Keycloak... */
    static final Pattern SIGN_IN_ADDRESS = Pattern.compile("(?i)(^|[./_-])(login|logon|signin|sign-in|sso|auth|oauth2?|saml2?|adfs|idp|cas|openid"
            + "|okta|onelogin|pingone|auth0|keycloak|microsoftonline|duosecurity)([./_?=-]|$)");

    /** Addresses of sign-in pages on the application's own host: /login, /sso/..., /saml2/... */
    static final Pattern SIGN_IN_PATH = Pattern.compile("(?i)(^|[/_.-])(login|logon|signin|sign-in|sso|saml2?|oauth2?|cas)([/_.?=#-]|$)");

    record Opened(String url, int status, String error) {}

    final Jobs jobs;
    final Jobs.Run run;
    final Browser browser;
    final Site site;
    final boolean visible;
    /** The application's own sign-in page, when one was seen at the start. */
    String signInKey = "";

    Session(Jobs jobs, Jobs.Run run, Browser browser, Site site, boolean visible) {
        this.jobs = jobs;
        this.run = run;
        this.browser = browser;
        this.site = site;
        this.visible = visible;
    }

    /**
     * Opens the first page. Waits for you when you asked to sign in first, or when the application shows a sign-in
     * page or a certificate warning. Returns the address the application opened at.
     */
    String begin(String start, boolean signInFirst) throws Exception {
        jobs.event(run, "Opening " + start);
        if (signInFirst) {
            needVisible();
            browser.start(start);
            jobs.waitForYou(run, SIGN_IN_FIRST);
            browser.waitReady();
        } else {
            String error;
            try {
                error = browser.open(start);
            } catch (TimeoutException e) {
                error = "no answer";
            }
            String now = browser.url();
            boolean certificate = certificate(error), noAnswer = error.equals("no answer");
            if (!error.isEmpty() && !certificate && !noAnswer)
                throw new IOException("Could not open " + start + " (" + error + "). Check the address, the network, or the proxy under More settings.");
            boolean signIn = error.isEmpty() && (browser.signInForm() || signInSite(now));
            if (certificate || noAnswer || signIn) {
                needVisible();
                if (signIn && site.inside(now)) signInKey = Site.key(now);
                jobs.waitForYou(run, certificate ? CERTIFICATE : noAnswer ? NO_ANSWER : SIGN_IN);
                browser.waitReady();
            }
        }
        // Continue pressed too early, or a second step (PIN, one-time code): ask again, twice at most.
        for (int i = 0; i < 2; i++) {
            String now = browser.url();
            boolean form = browser.signInForm();
            if (!now.startsWith("chrome-error:") && !form && !signInSite(now)) break;
            if (!visible) break;
            if (form && signInKey.isEmpty() && site.inside(now)) signInKey = Site.key(now);
            jobs.waitForYou(run, "The browser still shows a sign-in or error page. Finish signing in, then press Continue.");
            browser.waitReady();
        }
        String landing = browser.url();
        if (!landing.startsWith("http"))
            throw new IOException("The application did not open in the browser. Check the address, the network, or the proxy under More settings.");
        if (!site.inside(landing)) site.add(landing);   // for example http://app redirected to https://app-prod
        return landing;
    }

    /**
     * Opens a page. When it asks to sign in again, or shows a certificate warning, waits once for you and tries
     * again. The error is "" when the page opened (HTTP errors such as 404 are in the status, not the error).
     */
    Opened open(String url) throws Exception {
        boolean asked = false, retried = false;
        while (true) {
            String error;
            try {
                error = browser.open(url);
            } catch (TimeoutException e) {
                error = "the page did not answer within a minute";
            }
            String now = browser.url();
            int status = browser.status;
            boolean certificate = certificate(error);
            boolean signIn = error.isEmpty() && signInAgain(url, now);
            // Went through a sign-in page and ended on another page: the session ran out and single sign-on signed in
            // again by itself, but the application then showed its first page. Open the page again.
            boolean detour = error.isEmpty() && !signIn && !Site.key(now).equals(Site.key(url)) && throughSignIn(url);
            if (detour && !retried) {
                retried = true;
                continue;
            }
            if ((certificate || signIn || detour) && visible && !asked) {
                asked = true;
                jobs.waitForYou(run, certificate ? CERTIFICATE : SIGN_IN_AGAIN);
                continue;
            }
            if (signIn || detour) return new Opened(now, status, "it asks to sign in");
            return new Opened(now, status, error);
        }
    }

    /** Whether the window went through a sign-in page on the way (other than the requested address itself). */
    boolean throughSignIn(String requested) {
        String key = Site.key(requested);
        synchronized (browser.trail) {
            for (String u : browser.trail) {
                if (Site.key(u).equals(key) && site.inside(u)) continue;
                if (site.inside(u) ? Site.key(u).equals(signInKey) || SIGN_IN_PATH.matcher(Site.key(u)).find() : signInSite(u)) return true;
            }
        }
        return false;
    }

    /** Whether opening "requested" ended on a sign-in page instead (the session ran out). */
    boolean signInAgain(String requested, String now) {
        if (!site.inside(now)) return signInSite(now) || browser.signInForm();
        if (Site.key(now).equals(Site.key(requested))) return false;   // the page itself, for example "Change password"
        return Site.key(now).equals(signInKey) || browser.signInForm();
    }

    /** A sign-in service on another host. */
    boolean signInSite(String url) {
        if (site.inside(url)) return false;
        try {
            URI u = URI.create(url);
            return u.getHost() != null && SIGN_IN_ADDRESS.matcher(u.getHost() + Objects.toString(u.getRawPath(), "")).find();
        } catch (Exception e) {
            return false;
        }
    }

    static boolean certificate(String error) {
        String e = error.toUpperCase(Locale.ROOT);
        return e.contains("ERR_CERT") || e.contains("ERR_SSL") || e.contains("CLIENT_AUTH");
    }

    void needVisible() {
        if (!visible)
            throw new IllegalArgumentException("The application needs you to sign in (or accept a certificate), which needs a visible browser window. "
                    + "Untick \"Hidden browser\" under More settings and start again.");
    }

    static String host(String url) {
        try {
            return Objects.toString(URI.create(url).getHost(), url);
        } catch (Exception e) {
            return url;
        }
    }
}
