package guardian;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Pattern;
import java.util.stream.Stream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;

import static guardian.Json.*;
import static guardian.Util.*;

/**
 * Captures and comparisons ("jobs"): starting them, waiting for you (sign-in), stopping, and their files.
 *
 * <pre>
 * guardian-data/jobs/ID/job.json          status, settings, pages and results
 * guardian-data/jobs/ID/shots/0001.png    screenshots taken by this job
 * guardian-data/jobs/ID/text/0001.txt     the page's title (first line) and its visible text
 * guardian-data/jobs/ID/package.zip       capture: the package to keep and compare against later
 * guardian-data/jobs/ID/report.html       comparison: the report
 * guardian-data/packages/ID/              a package you uploaded
 * </pre>
 */
final class Jobs implements AutoCloseable {
    static final String PACKAGE_FORMAT = "astra-visual-guardian-package/1";
    static final long MAX_PACKAGE = 8L * 1024 * 1024 * 1024, MAX_ENTRY = 512L * 1024 * 1024;
    static final Pattern PACKAGE_ENTRY = Pattern.compile("guardian-package\\.json|index\\.html|shots/\\d{4,6}\\.png|text/\\d{4,6}\\.txt");
    static final Set<String> ACTIVE = Set.of("STARTING", "WAITING", "RUNNING");

    final Path root, jobs, packages, work;
    final Map<String, Run> running = new ConcurrentHashMap<>();
    /** History rows, kept until job.json changes. */
    final Map<Path, Object[]> rows = new ConcurrentHashMap<>();

    /** A job that is running, with the controls the UI uses. Only the job's own thread changes the job map. */
    static final class Run {
        final Map<String, Object> job;
        final Path dir;
        final Object gate = new Object();
        volatile boolean stop, proceed;
        volatile Browser browser;
        /** What the UI shows, refreshed by the job's thread (so the UI never reads the map while it changes). */
        volatile String view = "{}", updated = "";
        long savedAt;

        Run(Map<String, Object> job, Path dir) {
            this.job = job;
            this.dir = dir;
        }
    }

    /** Thrown inside a job when you press Stop. */
    static final class Stopped extends Exception {
    }

    Jobs(Path root) throws IOException {
        this.root = root;
        jobs = root.resolve("jobs");
        packages = root.resolve("packages");
        work = root.resolve("work");
        Files.createDirectories(jobs);
        Files.createDirectories(packages);
        removeTree(work);
        Files.createDirectories(work);
        // Jobs that were running when Guardian was closed: keep what they took, and finish their package or report.
        try (Stream<Path> dirs = Files.list(jobs)) {
            for (Path d : dirs.toList()) {
                Path f = d.resolve("job.json");
                if (!Files.exists(f)) continue;
                Map<String, Object> job;
                try {
                    job = load(f);
                    if (!ACTIVE.contains(s(job, "status"))) continue;
                    job.put("status", "STOPPED");
                    job.put("message", "Guardian was closed while this was running. What was taken until then is kept.");
                    Util.save(f, job);
                } catch (Exception e) {
                    continue;   // unreadable: it can still be deleted from History
                }
                try {
                    if (s(job, "type").equals("CAPTURE") && !list(job.get("pages")).isEmpty()) writePackage(d, job);
                    if (s(job, "type").equals("COMPARE") && !list(job.get("results")).isEmpty()) {
                        var manifest = load(packageDir(s(map(job.get("package")), "id")).resolve("guardian-package.json"));
                        Report.comparison(d, job, manifest);
                    }
                } catch (Exception e) {
                    // the package or report cannot be written (for example the package was deleted): the pages stay
                }
            }
        }
    }

    // ---------------------------------------------------------------- reading

    /** History: every capture and comparison, newest first. */
    List<Object> history() throws IOException {
        var out = new ArrayList<Object>();
        try (Stream<Path> dirs = Files.list(jobs)) {
            for (Path d : dirs.toList()) {
                Path f = d.resolve("job.json");
                if (!Files.exists(f)) continue;
                Run run = running.get(d.getFileName().toString());
                if (run != null) {
                    out.add(row(read(run.view), true));
                    continue;
                }
                long modified = Files.getLastModifiedTime(f).toMillis();
                Object[] cached = rows.get(f);
                if (cached == null || (long) cached[0] != modified) {
                    cached = new Object[]{modified, row(view(load(f), d, false), false)};
                    rows.put(f, cached);
                }
                out.add(cached[1]);
            }
        }
        out.sort(Comparator.comparing((Object o) -> s(map(o), "created")).reversed());
        return out;
    }

    static Map<String, Object> row(Map<String, Object> v, boolean active) {
        var r = new LinkedHashMap<String, Object>();
        for (String k : List.of("id", "type", "status", "message", "url", "created", "updated", "pageCount", "total", "summary", "package", "files"))
            if (v.containsKey(k)) r.put(k, v.get(k));
        r.put("active", active);
        return r;
    }

    /** One job as the UI shows it; "unchanged" when it has not changed since the UI last looked. */
    Map<String, Object> get(String id, String since) throws IOException {
        Run run = running.get(checkedId(id));
        if (run != null) return !since.isBlank() && since.equals(run.updated) ? obj("unchanged", true, "active", true) : read(run.view);
        Path f = dir(id).resolve("job.json");
        if (!Files.exists(f)) throw new NoSuchFileException(id);
        var job = load(f);
        if (!since.isBlank() && since.equals(s(job, "updated"))) return obj("unchanged", true, "active", false);
        return view(job, dir(id), false);
    }

    /**
     * What the UI needs of a job: its status and settings, the last pages it took, its recent events and, when a
     * comparison has finished, the pages that differ. (The full list of pages stays in job.json.)
     */
    static Map<String, Object> view(Map<String, Object> job, Path dir, boolean active) {
        var v = new LinkedHashMap<String, Object>();
        for (String k : List.of("id", "type", "status", "message", "url", "landing", "created", "updated", "settings", "package", "summary",
                "browserVersion", "mapping", "complete", "limitReached"))
            if (job.containsKey(k)) v.put(k, job.get(k));
        boolean capture = s(job, "type").equals("CAPTURE");
        var items = list(job.get(capture ? "pages" : "results"));
        v.put("pageCount", items.size());
        v.put("total", capture ? items.size() : num(map(job.get("package")).get("pages"), 0));
        var recent = new ArrayList<Object>();
        for (int i = Math.max(0, items.size() - 8); i < items.size(); i++) recent.add(light(map(items.get(i))));
        java.util.Collections.reverse(recent);
        v.put("recent", recent);
        if (capture) {
            v.put("notOpened", list(job.get("notOpened")).size());
            v.put("similar", map(job.get("similar")).values().stream().mapToInt(x -> num(x, 0)).sum());
        } else if (!active) {
            var differences = new ArrayList<Object>();
            for (Object o : items) if (!s(map(o), "status").equals("SAME") && differences.size() < 2000) differences.add(light(map(o)));
            v.put("differences", differences);
        }
        var events = list(job.get("events"));
        v.put("events", new ArrayList<>(events.subList(Math.max(0, events.size() - 40), events.size())));
        v.put("files", obj("package", Files.exists(dir.resolve("package.zip")), "gallery", Files.exists(dir.resolve("index.html")),
                "report", Files.exists(dir.resolve("report.html"))));
        v.put("active", active);
        return v;
    }

    static Map<String, Object> light(Map<String, Object> p) {
        var out = new LinkedHashMap<String, Object>();
        for (String k : List.of("n", "name", "status", "key", "title", "url", "shot", "via", "percent", "reasons")) if (p.containsKey(k)) out.put(k, p.get(k));
        return out;
    }

    Path dir(String id) {
        return jobs.resolve(checkedId(id));
    }

    /** Packages to compare against: finished captures made here and packages uploaded here, newest first. */
    List<Object> baselines() throws IOException {
        var out = new ArrayList<Object>();
        for (Object o : history()) {
            var r = map(o);
            if (s(r, "type").equals("CAPTURE") && b(map(r.get("files")), "package") && !b(r, "active"))
                out.add(obj("id", s(r, "id"), "source", "capture", "url", s(r, "url"), "captured", s(r, "created"), "pages", num(r.get("pageCount"), 0),
                        "complete", !s(r, "status").equals("STOPPED") && !s(r, "status").equals("FAILED")));
        }
        try (Stream<Path> dirs = Files.list(packages)) {
            for (Path d : dirs.toList()) {
                Path f = d.resolve("guardian-package.json");
                if (!Files.exists(f)) continue;
                try {
                    var m = load(f);
                    out.add(obj("id", d.getFileName().toString(), "source", "upload", "url", s(m, "application"), "captured", s(m, "captured"),
                            "pages", list(m.get("pages")).size(), "complete", b(m, "complete"), "uploaded", Files.getLastModifiedTime(f).toString()));
                } catch (Exception e) {
                    // not readable: left out
                }
            }
        }
        out.sort(Comparator.comparing((Object o) -> s(map(o), "captured")).reversed());
        return out;
    }

    // ---------------------------------------------------------------- starting

    Map<String, Object> startCapture(Map<String, Object> in) throws Exception {
        String url = launchUrl(s(in, "url")).toString();
        var settings = settings(map(in.get("settings")), !in.containsKey("signIn") || b(in, "signIn"));
        return launch(newJob("CAPTURE", url, settings), run -> Capture.run(this, run));
    }

    Map<String, Object> startCompare(Map<String, Object> in) throws Exception {
        String url = launchUrl(s(in, "url")).toString();
        String packageId = checkedId(s(in, "package"));
        var manifest = load(packageDir(packageId).resolve("guardian-package.json"));
        if (list(manifest.get("pages")).isEmpty()) throw new IllegalArgumentException("The package has no pages");
        var captured = map(manifest.get("settings"));
        var settings = settings(map(in.get("settings")), !in.containsKey("signIn") || b(in, "signIn"));
        // The same window size and kind of screenshot as the capture, or every page would differ.
        for (String k : List.of("width", "height", "fullPage", "maxSimilar")) if (captured.containsKey(k)) settings.put(k, captured.get(k));
        var job = newJob("COMPARE", url, settings);
        job.put("package", obj("id", packageId, "url", s(manifest, "application"), "captured", s(manifest, "captured"), "pages", list(manifest.get("pages")).size(),
                "complete", b(manifest, "complete")));
        return launch(job, run -> Comparison.run(this, run));
    }

    /** Settings for a job, within safe limits. */
    static Map<String, Object> settings(Map<String, Object> in, boolean signIn) {
        return obj("signIn", signIn,
                "browser", clip(s(in, "browser"), 500), "headless", b(in, "headless"), "proxy", clip(s(in, "proxy"), 200),
                "width", bound(in.get("width"), 1366, 800, 3840), "height", bound(in.get("height"), 768, 500, 2160),
                "fullPage", !in.containsKey("fullPage") || b(in, "fullPage"),
                "maxPages", bound(in.get("maxPages"), 500, 1, 20000), "maxSimilar", bound(in.get("maxSimilar"), 10, 0, 100000),
                "menus", !in.containsKey("menus") || b(in, "menus"),
                "pageSeconds", bound(in.get("pageSeconds"), 30, 5, 300), "settleMs", bound(in.get("settleMs"), 500, 0, 10000),
                "masks", lines(in.get("masks"), 100, 300),
                "skipPages", lines(in.get("skipPages"), Skips.MAX_RULES, Skips.MAX_RULE_LENGTH),
                "hosts", lines(in.get("hosts"), 50, 200),
                "tolerance", Math.max(0, Math.min(100, dbl(in.get("tolerance"), 0))),
                "findNew", !in.containsKey("findNew") || b(in, "findNew"), "maxNew", bound(in.get("maxNew"), 100, 0, 5000),
                "fromPrefix", clip(s(in, "fromPrefix"), 300), "toPrefix", clip(s(in, "toPrefix"), 300));
    }

    /** A list setting: from a JSON list or from text with one entry per line. */
    static List<String> lines(Object value, int max, int length) {
        List<String> raw = value instanceof List ? strings(value) : List.of(str(value).split("\\R"));
        return raw.stream().map(String::strip).filter(x -> !x.isEmpty()).limit(max).map(x -> clip(x, length)).toList();
    }

    Map<String, Object> newJob(String type, String url, Map<String, Object> settings) {
        String now = now();
        return obj("id", id(), "type", type, "status", "STARTING", "message", "Starting the browser", "url", url, "created", now, "updated", now,
                "settings", settings, "events", new ArrayList<>());
    }

    interface Work {
        void run(Run run) throws Exception;
    }

    synchronized Map<String, Object> launch(Map<String, Object> job, Work work) throws Exception {
        if (!running.isEmpty()) throw new IllegalArgumentException("A capture or comparison is already running. Wait for it to finish or stop it.");
        Path dir = dir(s(job, "id"));
        Files.createDirectories(dir);
        var run = new Run(job, dir);
        save(run, true);
        running.put(s(job, "id"), run);
        Thread t = new Thread(() -> {
            try {
                work.run(run);
                job.put("status", "DONE");
            } catch (Stopped e) {
                job.put("status", "STOPPED");
                job.put("message", "Stopped. What was taken until then is kept.");
            } catch (Throwable e) {
                job.put("status", "FAILED");
                job.put("message", message(e instanceof Exception ? e : new Exception(e.toString())));
            } finally {
                running.remove(s(job, "id"));
                try {
                    var events = list(job.get("events"));
                    String last = events.isEmpty() ? "" : s(map(events.get(events.size() - 1)), "message");
                    if (last.equals(s(job, "message"))) save(run, true);
                    else event(run, s(job, "message"));
                } catch (Exception ignored) {
                    // nothing more to record
                }
            }
        }, "guardian-" + s(job, "type").toLowerCase());
        t.setDaemon(true);
        t.start();
        return read(run.view);
    }

    // ---------------------------------------------------------------- inside a job (called by the job's thread)

    /** Refreshes what the UI shows; writes job.json at most once a second unless now is true. */
    void save(Run run, boolean now) throws IOException {
        String time = now();
        run.job.put("updated", time);
        long t = System.currentTimeMillis();
        if (now || t - run.savedAt >= 1000) {
            Util.save(run.dir.resolve("job.json"), run.job);
            run.savedAt = t;
        }
        run.view = write(view(run.job, run.dir, ACTIVE.contains(s(run.job, "status")) || running.containsKey(s(run.job, "id"))));
        run.updated = time;
    }

    /** Shows a message and records it in the job's events. */
    void event(Run run, String message) throws IOException {
        run.job.put("message", clip(message, 400));
        var events = list(run.job.get("events"));
        events.add(obj("time", now(), "message", clip(message, 400)));
        while (events.size() > 300) events.remove(0);
        run.job.put("events", events);
        save(run, true);
    }

    /** Shows what the job is doing now, without recording it. */
    void progress(Run run, String message) throws IOException {
        run.job.put("message", clip(message, 400));
        save(run, false);
    }

    void checkStop(Run run) throws Stopped {
        if (run.stop) throw new Stopped();
    }

    /** Waits until you press Continue (or Stop) in the UI, for example after signing in. */
    void waitForYou(Run run, String message) throws Exception {
        run.job.put("status", "WAITING");
        synchronized (run.gate) {
            run.proceed = false;
        }
        event(run, message);
        synchronized (run.gate) {
            while (!run.proceed && !run.stop) {
                run.gate.wait(1000);
                Browser b = run.browser;
                if (b != null && !b.process.isAlive()) throw new IOException(Browser.CLOSED);
            }
        }
        checkStop(run);
        run.job.put("status", "RUNNING");
        event(run, "Continuing");
    }

    void command(String id, String command) {
        Run run = running.get(checkedId(id));
        if (run == null) throw new IllegalArgumentException("This capture or comparison is not running");
        synchronized (run.gate) {
            switch (command) {
                case "continue" -> run.proceed = true;
                case "stop" -> run.stop = true;
                default -> throw new IllegalArgumentException("Unknown command");
            }
            run.gate.notifyAll();
        }
    }

    void delete(String id) throws IOException {
        if (running.containsKey(checkedId(id))) throw new IllegalArgumentException("Stop it first");
        Path d = dir(id);
        if (!Files.exists(d.resolve("job.json"))) throw new NoSuchFileException(id);
        removeTree(d);
        rows.remove(d.resolve("job.json"));
    }

    void deletePackage(String id) throws IOException {
        Path d = packages.resolve(checkedId(id));
        if (!Files.exists(d.resolve("guardian-package.json"))) throw new NoSuchFileException(id);
        for (Run r : running.values()) if (s(map(r.job.get("package")), "id").equals(id)) throw new IllegalArgumentException("A comparison is using it");
        removeTree(d);
    }

    // ---------------------------------------------------------------- packages

    /** A package to compare against: a capture made here (its ID) or an uploaded package. */
    Path packageDir(String id) throws IOException {
        Path captured = dir(id);
        if (Files.exists(captured.resolve("guardian-package.json"))) return captured;
        Path uploaded = packages.resolve(checkedId(id));
        if (Files.exists(uploaded.resolve("guardian-package.json"))) return uploaded;
        throw new IllegalArgumentException("Package not found. Choose a finished capture, or upload the package again.");
    }

    /** Writes a capture's guardian-package.json, its gallery (index.html) and package.zip. */
    static void writePackage(Path dir, Map<String, Object> job) throws IOException {
        var manifest = obj("format", PACKAGE_FORMAT, "application", s(job, "url"), "landing", s(job, "landing"), "captured", s(job, "created"),
                "finished", now(), "complete", b(job, "complete"), "limitReached", b(job, "limitReached"), "browserVersion", s(job, "browserVersion"),
                "settings", map(job.get("settings")), "pages", list(job.get("pages")), "notOpened", list(job.get("notOpened")),
                "notVisited", list(job.get("notVisited")), "similar", map(job.get("similar")));
        Util.save(dir.resolve("guardian-package.json"), manifest);
        Files.writeString(dir.resolve("index.html"), Report.gallery(manifest), StandardCharsets.UTF_8);
        Path tmp = dir.resolve("package.zip.tmp");
        try (var zip = new ZipOutputStream(Files.newOutputStream(tmp))) {
            zip.setLevel(1);   // screenshots are already compressed
            put(zip, dir, "guardian-package.json");
            put(zip, dir, "index.html");
            for (Object o : list(job.get("pages"))) {
                put(zip, dir, s(map(o), "shot"));
                put(zip, dir, s(map(o), "text"));
            }
        }
        Files.move(tmp, dir.resolve("package.zip"), StandardCopyOption.REPLACE_EXISTING);
    }

    static void put(ZipOutputStream zip, Path dir, String rel) throws IOException {
        if (rel.isBlank()) return;
        Path f = under(dir, rel);
        if (!Files.exists(f)) return;
        zip.putNextEntry(new ZipEntry(rel));
        Files.copy(f, zip);
        zip.closeEntry();
    }

    /** Stores an uploaded package (streamed to disk, then checked file by file) and says what is in it. */
    Map<String, Object> importPackage(InputStream in) throws IOException {
        Path tmp = Files.createTempFile(work, "upload-", ".zip");
        String id = id();
        Path dest = packages.resolve(id);
        try {
            long size = 0;
            try (OutputStream out = Files.newOutputStream(tmp)) {
                byte[] buf = new byte[1 << 16];
                int n;
                while ((n = in.read(buf)) > 0) {
                    size += n;
                    if (size > MAX_PACKAGE) throw new IOException("The package is larger than 8 GB");
                    out.write(buf, 0, n);
                }
            }
            if (size == 0) throw new IOException("No file was received");
            Files.createDirectories(dest);
            try (var zip = new ZipFile(tmp.toFile())) {
                // The package's files, also when it was unzipped and zipped again (inside a folder, with extra system files).
                String prefix = null;
                for (var e : java.util.Collections.list(zip.entries())) {
                    String n = e.getName();
                    if (!e.isDirectory() && (n.equals("guardian-package.json") || n.endsWith("/guardian-package.json")) && !n.startsWith("__MACOSX/")) {
                        String p = n.substring(0, n.length() - "guardian-package.json".length());
                        if (prefix == null || p.length() < prefix.length()) prefix = p;
                    }
                }
                if (prefix == null) throw new IOException("This is not a Guardian package (guardian-package.json is missing)");
                int count = 0;
                for (var e : java.util.Collections.list(zip.entries())) {
                    String n = e.getName();
                    if (e.isDirectory() || !n.startsWith(prefix) || !PACKAGE_ENTRY.matcher(n.substring(prefix.length())).matches()) continue;
                    if (++count > 50000) throw new IOException("The package has too many files");
                    Path target = under(dest, n.substring(prefix.length()));
                    Files.createDirectories(target.getParent());
                    try (InputStream src = zip.getInputStream(e)) {
                        if (Files.copy(new Limited(src, MAX_ENTRY), target, StandardCopyOption.REPLACE_EXISTING) > MAX_ENTRY)
                            throw new IOException("A file in the package is too large");
                    }
                }
            }
            if (!Files.exists(dest.resolve("guardian-package.json"))) throw new IOException("This is not a Guardian package (guardian-package.json is missing)");
            var manifest = load(dest.resolve("guardian-package.json"));
            if (!PACKAGE_FORMAT.equals(s(manifest, "format"))) throw new IOException("This is not a Guardian package of this version");
            for (Object o : list(manifest.get("pages"))) {
                String shot = s(map(o), "shot"), text = s(map(o), "text");
                if (!PACKAGE_ENTRY.matcher(shot).matches() || !Files.exists(under(dest, shot)))
                    throw new IOException("The package is incomplete (" + clip(shot, 60) + " is missing)");
                if (!text.isEmpty() && !PACKAGE_ENTRY.matcher(text).matches()) throw new IOException("This is not a Guardian package (" + clip(text, 60) + ")");
            }
            // The gallery is written again from the package's data: an uploaded page is never shown as it came.
            Files.writeString(dest.resolve("index.html"), Report.gallery(manifest), StandardCharsets.UTF_8);
            return obj("id", id, "source", "upload", "url", s(manifest, "application"), "captured", s(manifest, "captured"),
                    "pages", list(manifest.get("pages")).size(), "complete", b(manifest, "complete"));
        } catch (IOException | RuntimeException e) {
            removeTree(dest);
            if (e instanceof java.util.zip.ZipException) throw new IOException("This is not a ZIP file");
            throw e instanceof IOException io ? io : new IOException("This is not a Guardian package (" + message(e) + ")");
        } finally {
            Files.deleteIfExists(tmp);
        }
    }

    /** Reads at most one byte past a limit, so an oversized entry is noticed without reading all of it. */
    static final class Limited extends InputStream {
        final InputStream in;
        long left;

        Limited(InputStream in, long limit) {
            this.in = in;
            this.left = limit + 1;
        }

        @Override
        public int read() throws IOException {
            if (left <= 0) return -1;
            int b = in.read();
            if (b >= 0) left--;
            return b;
        }

        @Override
        public int read(byte[] b, int off, int len) throws IOException {
            if (left <= 0) return -1;
            int n = in.read(b, off, (int) Math.min(len, left));
            if (n > 0) left -= n;
            return n;
        }
    }

    /** Stops running jobs and closes their browsers (Guardian is shutting down). */
    @Override
    public void close() {
        for (Run run : running.values()) {
            run.stop = true;
            synchronized (run.gate) {
                run.gate.notifyAll();
            }
            Browser b = run.browser;
            if (b != null) b.close();
        }
    }
}
