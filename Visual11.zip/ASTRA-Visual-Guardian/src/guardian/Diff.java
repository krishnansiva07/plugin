package guardian;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.imageio.IIOImage;
import javax.imageio.ImageIO;
import javax.imageio.ImageWriteParam;
import javax.imageio.ImageWriter;
import javax.imageio.stream.MemoryCacheImageOutputStream;

/** Compares two screenshots (which pixels and which areas changed) and two page texts (which lines were added or removed). */
final class Diff {
    /** Colour differences up to this much per channel (0-255) are ignored, so font smoothing does not count as a change. */
    static final int CHANNEL_TOLERANCE = 32;
    /** Changed pixels are grouped in cells of this size to find the changed areas. */
    static final int CELL = 16;

    /** Result of comparing two screenshots. Areas are {x, y, width, height} in pixels. */
    record Images(double percent, long changedPixels, List<int[]> areas, BufferedImage overlay, int widthBefore, int heightBefore,
                  int widthAfter, int heightAfter) {}

    static Images images(BufferedImage before, BufferedImage after) {
        int wb = before.getWidth(), hb = before.getHeight(), wa = after.getWidth(), ha = after.getHeight();
        int w = Math.max(wb, wa), h = Math.max(hb, ha), cw = (w + CELL - 1) / CELL, ch = (h + CELL - 1) / CELL;
        boolean[][] cells = new boolean[ch][cw];
        BufferedImage overlay = new BufferedImage(w, h, BufferedImage.TYPE_INT_RGB);
        int[] rowB = new int[wb], rowA = new int[wa], out = new int[w];
        long changed = 0;
        for (int y = 0; y < h; y++) {
            boolean inB = y < hb, inA = y < ha;
            if (inB) before.getRGB(0, y, wb, 1, rowB, 0, wb);
            if (inA) after.getRGB(0, y, wa, 1, rowA, 0, wa);
            for (int x = 0; x < w; x++) {
                boolean hasB = inB && x < wb, hasA = inA && x < wa;
                int pa = hasA ? rowA[x] : 0, pb = hasB ? rowB[x] : 0;
                boolean diff = hasA != hasB || hasA && differs(pa, pb);
                if (diff) {
                    changed++;
                    cells[y / CELL][x / CELL] = true;
                    out[x] = tint(hasA ? pa : hasB ? pb : 0xFFFFFF);
                } else {
                    out[x] = hasA ? faded(pa) : 0xF2F2F2;
                }
            }
            overlay.setRGB(0, y, w, 1, out, 0, w);
        }
        List<int[]> areas = areas(cells, w, h);
        Graphics2D g = overlay.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.setColor(new Color(0xE0, 0x20, 0x1B));
        g.setStroke(new BasicStroke(3));
        for (int[] a : areas) g.drawRect(Math.max(1, a[0] - 3), Math.max(1, a[1] - 3), Math.min(w - 3, a[2] + 6), Math.min(h - 3, a[3] + 6));
        g.dispose();
        double percent = w == 0 || h == 0 ? 0 : changed * 100.0 / ((double) w * h);
        return new Images(percent, changed, areas, overlay, wb, hb, wa, ha);
    }

    static boolean differs(int a, int b) {
        return Math.abs((a >> 16 & 255) - (b >> 16 & 255)) > CHANNEL_TOLERANCE || Math.abs((a >> 8 & 255) - (b >> 8 & 255)) > CHANNEL_TOLERANCE
                || Math.abs((a & 255) - (b & 255)) > CHANNEL_TOLERANCE;
    }

    /** A changed pixel: red over the new page, so the changed text can still be read. */
    static int tint(int rgb) {
        int r = rgb >> 16 & 255, g = rgb >> 8 & 255, b = rgb & 255;
        return (0xE0 * 62 + r * 38) / 100 << 16 | (0x20 * 62 + g * 38) / 100 << 8 | (0x1B * 62 + b * 38) / 100;
    }

    /** The new screenshot washed out, so the red changes stand out. */
    static int faded(int rgb) {
        int r = rgb >> 16 & 255, g = rgb >> 8 & 255, b = rgb & 255;
        int grey = (r * 30 + g * 59 + b * 11) / 100;
        int v = 255 - (255 - grey) * 35 / 100;
        return v << 16 | v << 8 | v;
    }

    /** Groups changed cells that touch (or nearly touch) into rectangles, largest first, at most 30. */
    static List<int[]> areas(boolean[][] cells, int w, int h) {
        int rows = cells.length, cols = rows == 0 ? 0 : cells[0].length;
        boolean[][] seen = new boolean[rows][cols];
        var out = new ArrayList<int[]>();
        int[] stack = new int[rows * cols * 2 + 2];
        for (int r = 0; r < rows; r++) {
            for (int c = 0; c < cols; c++) {
                if (!cells[r][c] || seen[r][c]) continue;
                int top = r, bottom = r, left = c, right = c, sp = 0;
                stack[sp++] = r;
                stack[sp++] = c;
                seen[r][c] = true;
                while (sp > 0) {
                    int cc = stack[--sp], rr = stack[--sp];
                    top = Math.min(top, rr);
                    bottom = Math.max(bottom, rr);
                    left = Math.min(left, cc);
                    right = Math.max(right, cc);
                    for (int dr = -2; dr <= 2; dr++) {
                        for (int dc = -2; dc <= 2; dc++) {
                            int nr = rr + dr, nc = cc + dc;
                            if (nr < 0 || nc < 0 || nr >= rows || nc >= cols || seen[nr][nc] || !cells[nr][nc]) continue;
                            seen[nr][nc] = true;
                            stack[sp++] = nr;
                            stack[sp++] = nc;
                        }
                    }
                }
                int x = left * CELL, y = top * CELL;
                out.add(new int[]{x, y, Math.min(w, (right + 1) * CELL) - x, Math.min(h, (bottom + 1) * CELL) - y});
            }
        }
        out.sort((a, b) -> Long.compare((long) b[2] * b[3], (long) a[2] * a[3]));
        return out.size() > 30 ? new ArrayList<>(out.subList(0, 30)) : out;
    }

    // ---------------------------------------------------------------- text

    /** Lines of the new page that the old page did not have, and the other way round (each line counted as often as it appears). */
    static Map<String, List<String>> text(List<String> before, List<String> after, int limit) {
        var counts = new HashMap<String, Integer>();
        for (String l : before) counts.merge(normal(l), 1, Integer::sum);
        var added = new ArrayList<String>();
        for (String l : after) {
            String k = normal(l);
            if (k.isEmpty()) continue;
            Integer n = counts.get(k);
            if (n != null && n > 0) counts.put(k, n - 1);
            else if (added.size() < limit) added.add(l.strip());
        }
        var left = new HashMap<String, Integer>();
        for (String l : after) left.merge(normal(l), 1, Integer::sum);
        var removed = new ArrayList<String>();
        for (String l : before) {
            String k = normal(l);
            if (k.isEmpty()) continue;
            Integer n = left.get(k);
            if (n != null && n > 0) left.put(k, n - 1);
            else if (removed.size() < limit) removed.add(l.strip());
        }
        return Map.of("added", added, "removed", removed);
    }

    static String normal(String line) {
        return line == null ? "" : line.strip().replaceAll("\\s+", " ");
    }

    // ---------------------------------------------------------------- pictures for the report

    static BufferedImage png(byte[] bytes) throws IOException {
        BufferedImage img = ImageIO.read(new ByteArrayInputStream(bytes));
        if (img == null) throw new IOException("Not a picture");
        return img;
    }

    static byte[] png(BufferedImage img) throws IOException {
        var out = new ByteArrayOutputStream();
        ImageIO.write(img, "png", out);
        return out.toByteArray();
    }

    /** The part of a picture to show for a page: the changed areas with some space around, at most maxHeight tall. */
    static int[] focus(List<int[]> areas, int w, int h, int maxHeight) {
        if (areas.isEmpty()) return new int[]{0, 0, w, Math.min(h, maxHeight)};
        int top = Integer.MAX_VALUE, bottom = 0;
        for (int[] a : areas) {
            top = Math.min(top, a[1]);
            bottom = Math.max(bottom, a[1] + a[3]);
        }
        top = Math.max(0, top - 160);
        bottom = Math.min(h, bottom + 160);
        if (bottom - top > maxHeight) bottom = top + maxHeight;
        return new int[]{0, top, w, Math.max(1, bottom - top)};
    }

    /** A cut-out of a picture (filled with light grey where the picture is smaller), scaled down to fit maxWidth and maxHeight. */
    static BufferedImage cut(BufferedImage img, int[] box, int maxWidth, int maxHeight) {
        double scale = Math.min(1.0, Math.min(maxWidth / (double) box[2], maxHeight / (double) box[3]));
        int w = Math.max(1, (int) Math.round(box[2] * scale)), h = Math.max(1, (int) Math.round(box[3] * scale));
        BufferedImage out = new BufferedImage(w, h, BufferedImage.TYPE_INT_RGB);
        Graphics2D g = out.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
        g.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
        g.setColor(new Color(0xF2F2F2));
        g.fillRect(0, 0, w, h);
        // only the part of the box the picture has, so a shorter picture is not stretched
        int sw = Math.min(box[2], img.getWidth() - box[0]), sh = Math.min(box[3], img.getHeight() - box[1]);
        if (sw > 0 && sh > 0) {
            int dw = Math.max(1, (int) Math.round(sw * scale)), dh = Math.max(1, (int) Math.round(sh * scale));
            g.drawImage(img, 0, 0, dw, dh, box[0], box[1], box[0] + sw, box[1] + sh, null);
        }
        g.dispose();
        return out;
    }

    /** Paints areas (x, y, width, height) light grey: the areas to hide, so they never count as a change. */
    static void blank(BufferedImage img, List<int[]> areas) {
        if (areas.isEmpty()) return;
        Graphics2D g = img.createGraphics();
        g.setColor(new Color(0xE6E6E6));
        for (int[] a : areas) g.fillRect(a[0], a[1], a[2], a[3]);
        g.dispose();
    }

    /** Width and height of a PNG, read from its header. */
    static int[] pngSize(byte[] png) {
        if (png.length < 24) return new int[]{0, 0};
        return new int[]{(png[16] & 255) << 24 | (png[17] & 255) << 16 | (png[18] & 255) << 8 | png[19] & 255,
                (png[20] & 255) << 24 | (png[21] & 255) << 16 | (png[22] & 255) << 8 | png[23] & 255};
    }

    static byte[] jpeg(BufferedImage img, float quality) throws IOException {
        ImageWriter writer = ImageIO.getImageWritersByFormatName("jpeg").next();
        var out = new ByteArrayOutputStream();
        try (var stream = new MemoryCacheImageOutputStream(out)) {
            writer.setOutput(stream);
            ImageWriteParam param = writer.getDefaultWriteParam();
            param.setCompressionMode(ImageWriteParam.MODE_EXPLICIT);
            param.setCompressionQuality(quality);
            writer.write(null, new IIOImage(img, null, null), param);
        } finally {
            writer.dispose();
        }
        return out.toByteArray();
    }
}
