package guardian;
import java.io.*;import java.nio.file.*;import java.nio.charset.StandardCharsets;import java.security.*;import java.time.*;import java.net.*;import java.util.*;import java.util.regex.*;
import static guardian.Json.*;
final class Util {
 static String id(){return UUID.randomUUID().toString();} static String now(){return Instant.now().toString();}
 static String sha(byte[] a){try{return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(a));}catch(Exception e){throw new IllegalStateException(e);}}
 static String hash(Object a){return sha(write(a).getBytes(StandardCharsets.UTF_8));} static String sha(Path p)throws IOException{try(var in=Files.newInputStream(p)){var md=MessageDigest.getInstance("SHA-256");byte[] b=new byte[65536];int n;while((n=in.read(b))!=-1)md.update(b,0,n);return HexFormat.of().formatHex(md.digest());}catch(NoSuchAlgorithmException e){throw new IOException(e);}}
 // Retry transient Windows sharing violations without deleting the last good checkpoint.
 static void atomic(Path p,byte[] bytes)throws IOException{Files.createDirectories(p.getParent());Path tmp=Files.createTempFile(p.getParent(),".write-",".tmp");try{try(var ch=java.nio.channels.FileChannel.open(tmp,StandardOpenOption.WRITE)){var buf=java.nio.ByteBuffer.wrap(bytes);while(buf.hasRemaining())ch.write(buf);ch.force(true);}IOException last=null;for(int i=0;i<12;i++){try{try{Files.move(tmp,p,StandardCopyOption.ATOMIC_MOVE,StandardCopyOption.REPLACE_EXISTING);}catch(AtomicMoveNotSupportedException e){Files.move(tmp,p,StandardCopyOption.REPLACE_EXISTING);}return;}catch(FileSystemException e){last=e;if(i==11)break;try{Thread.sleep(Math.min(1000,80L*(i+1)));}catch(InterruptedException ex){Thread.currentThread().interrupt();throw new IOException("Checkpoint write interrupted",ex);}}}throw new IOException("Cannot replace "+p.getFileName()+"; close editors or sync tools locking the file and resume. Last durable checkpoint preserved.",last);}finally{try{Files.deleteIfExists(tmp);}catch(IOException ignored){}}}
 static void save(Path p,Object x)throws IOException{atomic(p,write(x).getBytes(StandardCharsets.UTF_8));} static Map<String,Object> load(Path p)throws IOException{return read(Files.readString(p));}
 static String clean(String s){if(s==null)return "";return s.replaceAll("[\\p{Cntrl}&&[^\\n\\t]]","").strip();} static String clip(String s,int max){s=clean(s);return s.length()>max?s.substring(0,max):s;}
 static String message(Throwable t){return clip(t.getMessage()==null?t.getClass().getSimpleName():t.getMessage(),350).replaceAll("(?i)(bearer |api[_-]?key[=:] ?|token[=:] ?)[^ ,;]+","$1[redacted]");}
 static String esc(Object o){return str(o).replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("\"","&quot;").replace("'","&#39;");}
 static URI url(String s){URI u=URI.create(s);if(!Set.of("http","https").contains(u.getScheme())||u.getHost()==null||u.getUserInfo()!=null)throw new IllegalArgumentException("Enter an HTTP(S) URL without embedded credentials");return u;}
 static URI launchUrl(String s){URI u=url(s);String query=Objects.toString(u.getRawQuery(),"")+"&"+Objects.toString(u.getRawFragment(),"");if(query.toLowerCase(Locale.ROOT).matches(".*(?:^|[?&#;])(?:access_token|id_token|refresh_token|token|password|passwd|secret|session|ticket|otp|pin|code|api_key)=.*"))throw new IllegalArgumentException("Do not include authentication secrets in the application URL");return u;}
 static String origin(String s){URI u=url(s);int port=u.getPort();return u.getScheme()+"://"+u.getHost().toLowerCase(Locale.ROOT)+(port<0||port==80&&u.getScheme().equals("http")||port==443&&u.getScheme().equals("https")?"":":"+port);}
 static String route(String s){try{URI u=url(s);return (u.getRawPath()==null||u.getRawPath().isBlank()?"/":u.getRawPath())+(u.getRawFragment()!=null&&u.getRawFragment().startsWith("/")?"#"+u.getRawFragment().split("\\?",2)[0]:"");}catch(Exception e){return "";}}
 static String safeUrl(String s){try{return origin(s)+route(s);}catch(Exception e){return "";}}
 static String norm(String s){return clean(s).toLowerCase(Locale.ROOT).replaceAll("\\b[0-9a-f]{8}-[0-9a-f-]{27,}\\b","#").replaceAll("\\b\\d+[\\d:.,/-]*\\b","#").replaceAll("\\s+"," ");}
 static String checkedId(String s){if(!s.matches("[a-zA-Z0-9_-]{1,80}"))throw new IllegalArgumentException("Invalid ID");return s;}
 static Path under(Path root,String rel)throws IOException{if(rel.contains("\\")||rel.startsWith("/")||rel.contains(":"))throw new IOException("Unsafe path");Path p=root.resolve(rel).normalize();if(!p.startsWith(root.normalize())||p.equals(root))throw new IOException("Unsafe path");return p;}
 static void removeTree(Path p)throws IOException{if(Files.exists(p))try(var stream=Files.walk(p)){for(Path f:stream.sorted(Comparator.reverseOrder()).toList())Files.deleteIfExists(f);}}
 static List<String> strings(Object a){return list(a).stream().map(Json::str).filter(s->!s.isBlank()).toList();}
 static int bound(Object o,int def,int min,int max){return Math.max(min,Math.min(max,num(o,def)));}
 static void sleep(long ms)throws InterruptedException{Thread.sleep(ms);}
}
