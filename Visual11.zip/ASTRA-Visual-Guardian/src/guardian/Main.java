package guardian;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.file.Path;
import java.util.concurrent.Executors;

/**
 * The built-in front door: Java's own small HTTP server on 127.0.0.1, no other dependencies. It only moves bytes;
 * every request is answered by {@link Api}. The Spring Boot version (folder spring/) uses the same Api.
 * Usage: java -jar visual-guardian.jar [--port 8765] [--data guardian-data]
 */
public class Main {
    final Api api;
    final HttpServer server;
    final int port;

    Main(int port, Path root) throws Exception {
        api = Api.open(root);
        server = HttpServer.create(new InetSocketAddress("127.0.0.1", port), 0);
        this.port = server.getAddress().getPort();
        server.setExecutor(Executors.newCachedThreadPool());
        server.createContext("/", this::handle);
    }

    public static void main(String[] args) throws Exception {
        System.setProperty("java.awt.headless", "true");
        int port = 8765;
        Path root = Path.of("guardian-data");
        for (int i = 0; i < args.length; i++) {
            if (args[i].equals("--port")) port = Integer.parseInt(args[++i]);
            else if (args[i].equals("--data")) root = Path.of(args[++i]);
            else throw new IllegalArgumentException("Unknown argument: " + args[i]);
        }
        var m = new Main(port, root);
        m.server.start();
        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            m.api.close();
            m.server.stop(0);
        }));
        System.out.println("ASTRA Visual Guardian: open http://127.0.0.1:" + m.port + " in your browser");
        System.out.println("Data folder: " + m.api.root());
    }

    void handle(HttpExchange e) throws IOException {
        try {
            String path = e.getRequestURI().getPath(), method = e.getRequestMethod();
            var headers = e.getRequestHeaders();
            Api.Reply refusal = api.refuse(path, headers.getFirst("Host"), headers.getFirst("Origin"), headers.getFirst("X-Guardian-Token"), port);
            send(e, refusal != null ? refusal : api.handle(method, path, e.getRequestURI().getRawQuery(), e.getRequestBody()));
        } catch (Exception ex) {
            try {
                send(e, Api.error(ex));
            } catch (IOException ignored) {
                // the browser has gone
            }
        } finally {
            e.close();
        }
    }

    static void send(HttpExchange e, Api.Reply reply) throws IOException {
        var h = e.getResponseHeaders();
        h.set("Content-Type", reply.type());
        Api.HEADERS.forEach(h::set);
        if (!reply.filename().isBlank()) h.set("Content-Disposition", "attachment; filename=\"" + reply.filename() + "\"");
        e.sendResponseHeaders(reply.status(), reply.length());
        try (var out = e.getResponseBody()) {
            reply.writeTo(out);
        }
    }
}
