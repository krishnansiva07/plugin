'use strict';
// ASTRA Visual Guardian UI: Capture, Compare, History. Talks to the local Guardian only.

const token = document.querySelector('meta[name="guardian-token"]').content;
const filesKey = document.querySelector('meta[name="guardian-files"]').content;
const ACTIVE = ['STARTING', 'WAITING', 'RUNNING'];
const STATUS = {STARTING: 'Starting', WAITING: 'Waiting for you', RUNNING: 'Running', DONE: 'Finished', STOPPED: 'Stopped', FAILED: 'Failed'};
const RESULT = {CHANGED: 'Changed', MISSING: 'Missing', NEW: 'New', SAME: 'Unchanged', SKIPPED: 'Skipped'};
const $ = (selector, root = document) => root.querySelector(selector);

/** Builds an element: h('a', {href: x, class: 'button'}, 'text', child...). Text is never parsed as HTML. */
function h(tag, attrs, ...children) {
  const e = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs || {})) {
    if (v === null || v === undefined || v === false) continue;
    if (k === 'class') e.className = v;
    else if (k.startsWith('on')) e.addEventListener(k.slice(2), v);
    else e.setAttribute(k, v === true ? '' : String(v));
  }
  for (const c of children.flat()) if (c !== null && c !== undefined && c !== false) e.append(c instanceof Node ? c : document.createTextNode(String(c)));
  return e;
}

async function api(path, body) {
  const options = {headers: {'X-Guardian-Token': token}};
  if (body !== undefined) {
    options.method = 'POST';
    if (body instanceof Blob) {
      options.body = body;
      options.headers['Content-Type'] = 'application/zip';
    } else {
      options.body = JSON.stringify(body);
      options.headers['Content-Type'] = 'application/json';
    }
  }
  const res = await fetch('/api/' + path, options);
  let data = null;
  try { data = await res.json(); } catch { /* not JSON */ }
  if (!res.ok) throw new Error((data && data.error) || 'Guardian did not answer (' + res.status + ')');
  return data;
}

const fileUrl = (id, name) => '/files/' + filesKey + '/' + encodeURIComponent(id) + '/' + name;
const when = iso => { const d = new Date(iso); return isNaN(d) ? '' : d.toLocaleString(); };
const host = url => { try { return new URL(url).host; } catch { return url || ''; } };
const plural = (n, one, many) => n + ' ' + (n === 1 ? one : many);

function notice(text, kind) {
  const n = $('#notice');
  n.textContent = text || '';
  n.className = kind || 'error';
  n.hidden = !text;
  if (text) n.scrollIntoView({block: 'nearest'});
}

// ------------------------------------------------------------------ tabs

function show(tab) {
  for (const b of document.querySelectorAll('[data-tab]')) b.classList.toggle('on', b.dataset.tab === tab);
  for (const s of document.querySelectorAll('.tab')) s.hidden = s.id !== tab;
  if (tab === 'history') loadHistory();
  if (tab === 'compare') loadBaselines();
}
for (const b of document.querySelectorAll('[data-tab]')) b.addEventListener('click', () => show(b.dataset.tab));

// ------------------------------------------------------------------ forms (settings are remembered on this computer)

function settings(form) {
  const out = {};
  for (const el of form.elements) {
    if (!el.name || ['url', 'signIn', 'package'].includes(el.name)) continue;
    if (el.type === 'checkbox') out[el.name] = el.checked;
    else if (el.type === 'number') { if (el.value !== '') out[el.name] = Number(el.value); }
    else if (el.tagName === 'TEXTAREA') out[el.name] = el.value.split('\n').map(s => s.trim()).filter(Boolean);
    else if (el.value.trim()) out[el.name] = el.value.trim();
  }
  return out;
}

function remember(form) {
  const values = {};
  for (const el of form.elements) if (el.name && el.name !== 'package') values[el.name] = el.type === 'checkbox' ? el.checked : el.value;
  try { localStorage.setItem('guardian.' + form.id, JSON.stringify(values)); } catch { /* storage unavailable */ }
}

function restore(form) {
  let values = null;
  try { values = JSON.parse(localStorage.getItem('guardian.' + form.id) || 'null'); } catch { /* storage unavailable */ }
  if (!values) return;
  for (const el of form.elements) {
    if (!el.name || !(el.name in values) || el.name === 'package') continue;
    if (el.type === 'checkbox') el.checked = !!values[el.name]; else el.value = values[el.name];
  }
}

const captureForm = $('#captureForm'), compareForm = $('#compareForm');
restore(captureForm);
restore(compareForm);

captureForm.addEventListener('submit', async e => {
  e.preventDefault();
  notice('');
  const f = captureForm.elements;
  try {
    remember(captureForm);
    const job = await api('captures', {url: f.url.value.trim(), signIn: f.signIn.checked, settings: settings(captureForm)});
    follow(job);
  } catch (err) { notice(err.message); }
});

compareForm.addEventListener('submit', async e => {
  e.preventDefault();
  notice('');
  const f = compareForm.elements;
  if (!f.package.value) return notice('Choose a package, or upload one.');
  try {
    remember(compareForm);
    const job = await api('compares', {package: f.package.value, url: f.url.value.trim(), signIn: f.signIn.checked, settings: settings(compareForm)});
    follow(job);
  } catch (err) { notice(err.message); }
});

// ------------------------------------------------------------------ packages to compare with

let baselines = [];

async function loadBaselines(select) {
  const s = compareForm.elements.package;
  const keep = select || s.value;
  try { baselines = await api('baselines'); } catch (err) { return notice(err.message); }
  s.replaceChildren(...(baselines.length ? [] : [h('option', {value: ''}, 'No packages yet: make a capture first, or upload a package')]),
    ...baselines.map(b => h('option', {value: b.id}, host(b.url) + ' · captured ' + when(b.captured) + ' · ' + plural(b.pages, 'page', 'pages')
      + (b.source === 'upload' ? ' · uploaded' : '') + (b.complete ? '' : ' · incomplete'))));
  if (keep && baselines.some(b => b.id === keep)) s.value = keep;
  suggestUrl();
}

/** Suggests the package's own address (as for a deployment on the same server) until you type another one. */
function suggestUrl() {
  const url = compareForm.elements.url, b = baselines.find(x => x.id === compareForm.elements.package.value);
  if (b && (!url.value || url.dataset.suggested === url.value)) { url.value = b.url; url.dataset.suggested = b.url; }
}
compareForm.elements.package.addEventListener('change', suggestUrl);

$('#packageFile').addEventListener('change', async e => {
  const file = e.target.files[0];
  e.target.value = '';
  if (!file) return;
  const state = $('#uploadState');
  state.textContent = 'Uploading ' + file.name + '…';
  notice('');
  try {
    const p = await api('packages', file);
    state.textContent = 'Uploaded: ' + plural(p.pages, 'page', 'pages') + ' of ' + host(p.url) + '.';
    await loadBaselines(p.id);
  } catch (err) {
    state.textContent = '';
    notice('Upload failed: ' + err.message);
  }
});

// ------------------------------------------------------------------ the running (or last) capture or comparison

let current = null, timer = null;

function follow(job) {
  const full = Array.isArray(job.events);   // a History row is only a summary: fetch the rest
  current = {id: job.id, view: full ? job : {}};
  show(job.type === 'CAPTURE' ? 'capture' : 'compare');
  if (full) render(job);
  poll();
}

async function poll() {
  clearTimeout(timer);
  if (!current) return;
  const c = current;
  try {
    const v = await api('jobs/' + encodeURIComponent(c.id) + (c.view && c.view.updated ? '?since=' + encodeURIComponent(c.view.updated) : ''));
    if (c !== current) return;
    if (!v.unchanged) {
      c.view = v;
      render(v);
      if (!v.active && !ACTIVE.includes(v.status) && $('#notice').className === 'info') notice('');
    }
    else if (!v.active && c.view.active) { c.view = {}; return poll(); }   // it has just finished: fetch the final state
  } catch (err) { notice(err.message); }
  if (c === current && (c.view.active || ACTIVE.includes(c.view.status))) timer = setTimeout(poll, 1000);
  else if (c === current && c.view.type === 'CAPTURE') loadBaselines();
}

async function command(id, name) {
  try {
    await api('jobs/command', {id, command: name});
    if (name === 'stop') notice('Stopping after the current page. What was taken until then is kept.', 'info');
    poll();
  } catch (err) { notice(err.message); }
}

function render(v) {
  const place = v.type === 'CAPTURE' ? $('#captureJob') : $('#compareJob');
  const active = v.active || ACTIVE.includes(v.status);
  const capture = v.type === 'CAPTURE';
  const card = h('div', {class: 'panel job'},
    h('div', {class: 'jobhead'},
      h('span', {class: 'badge ' + v.status}, STATUS[v.status] || v.status),
      h('strong', {}, capture ? 'Capture of ' + host(v.url) : 'Comparison of ' + host(v.url) + ' with the package of ' + host((v.package || {}).url)),
      h('span', {class: 'muted'}, when(v.created))),
    h('p', {class: 'message'}, v.message || ''),
    v.status === 'WAITING' ? h('div', {class: 'waiting'},
      h('p', {}, 'Do this in the browser window that Guardian opened, then come back here and press Continue.'),
      h('button', {type: 'button', class: 'primary big', onclick: () => command(v.id, 'continue')}, 'Continue')) : null,
    capture ? captureStats(v) : compareStats(v),
    h('div', {class: 'buttons'},
      active ? h('button', {type: 'button', onclick: () => command(v.id, 'stop')}, 'Stop') : null,
      ...fileButtons(v)),
    capture ? thumbnails(v) : results(v, active),
    events(v));
  place.replaceChildren(card);
}

function captureStats(v) {
  return h('div', {class: 'stats'},
    stat(v.pageCount || 0, 'pages taken'),
    stat(v.notOpened || 0, 'links not opened'),
    v.similar ? stat(v.similar, 'similar pages left out') : null);
}

function compareStats(v) {
  const s = v.summary || {};
  return h('div', {class: 'stats'},
    stat((v.pageCount || 0) - (s.new || 0) + ' / ' + (v.total || 0), 'pages compared'),
    stat(s.changed || 0, 'changed', 'CHANGED'), stat(s.missing || 0, 'missing', 'MISSING'), stat(s.new || 0, 'new', 'NEW'),
    stat(s.same || 0, 'unchanged', 'SAME'), s.skipped ? stat(s.skipped, 'skipped', 'SKIPPED') : null);
}

const stat = (value, label, kind) => h('div', {class: 'stat ' + (kind || '')}, h('b', {}, value), h('span', {}, label));

function fileButtons(v) {
  const f = v.files || {}, out = [];
  if (f.package) {
    out.push(h('a', {class: 'button primary', href: fileUrl(v.id, 'package.zip'), download: ''}, 'Download package'));
    out.push(h('a', {class: 'button', href: fileUrl(v.id, 'index.html'), target: '_blank', rel: 'noopener'}, 'View screenshots'));
    out.push(h('button', {type: 'button', onclick: async () => { show('compare'); await loadBaselines(v.id); }}, 'Compare with this…'));
  }
  if (f.report) {
    out.push(h('a', {class: 'button primary', href: fileUrl(v.id, 'report.html'), target: '_blank', rel: 'noopener'}, 'Open report'));
    out.push(h('a', {class: 'button', href: fileUrl(v.id, 'report.html') + '?download=1', download: ''}, 'Download report'));
  }
  return out;
}

function thumbnails(v) {
  const pages = v.recent || [];
  if (!pages.length) return null;
  return h('div', {},
    h('h3', {}, (v.active || ACTIVE.includes(v.status)) ? 'Latest pages' : 'Last pages taken'),
    h('div', {class: 'thumbs'}, pages.map(p => h('a', {class: 'thumb', href: fileUrl(v.id, p.shot), target: '_blank', rel: 'noopener'},
      h('img', {src: fileUrl(v.id, p.shot), alt: '', loading: 'lazy'}),
      h('span', {class: 'title'}, p.n + '. ' + (p.title || p.key)),
      h('span', {class: 'key'}, p.key)))));
}

function results(v, active) {
  const list = active ? (v.recent || []) : (v.differences || []);
  if (!list.length) return active ? null : h('p', {class: 'good'}, v.status === 'DONE' ? 'No differences: every page looks as it did.' : '');
  return h('div', {},
    h('h3', {}, active ? 'Latest pages' : 'Pages that differ'),
    h('table', {class: 'list'}, h('tbody', {}, list.map(r => h('tr', {},
      h('td', {}, h('span', {class: 'badge ' + r.status}, RESULT[r.status] || r.status || '…')),
      h('td', {}, active || !v.files || !v.files.report ? (r.title || r.key)
        : h('a', {href: fileUrl(v.id, 'report.html') + '#p-' + encodeURIComponent(r.name), target: '_blank', rel: 'noopener'}, r.title || r.key),
        h('div', {class: 'key'}, r.key)),
      h('td', {class: 'muted'}, (r.reasons || []).join('; ')))))));
}

function events(v) {
  const list = v.events || [];
  if (!list.length) return null;
  return h('details', {class: 'events'}, h('summary', {}, 'Activity'),
    h('ul', {}, list.slice().reverse().map(e => h('li', {}, h('span', {class: 'muted'}, new Date(e.time).toLocaleTimeString() + ' '), e.message))));
}

// ------------------------------------------------------------------ history

async function loadHistory() {
  const place = $('#historyList');
  let rows;
  try { rows = await api('jobs'); } catch (err) { return notice(err.message); }
  if (!rows.length) return place.replaceChildren(h('p', {class: 'muted'}, 'Nothing yet. Start with a capture.'));
  place.replaceChildren(h('table', {class: 'list'},
    h('thead', {}, h('tr', {}, h('th', {}, 'What'), h('th', {}, 'Application'), h('th', {}, 'Started'), h('th', {}, 'Status'), h('th', {}, 'Result'), h('th', {}, ''))),
    h('tbody', {}, rows.map(r => {
      const s = r.summary || {}, capture = r.type === 'CAPTURE';
      const result = capture ? plural(r.pageCount || 0, 'page', 'pages')
        : [s.changed ? s.changed + ' changed' : '', s.missing ? s.missing + ' missing' : '', s.new ? s.new + ' new' : '', (s.same || 0) + ' unchanged'].filter(Boolean).join(', ');
      return h('tr', {},
        h('td', {}, capture ? 'Capture' : 'Comparison'),
        h('td', {}, host(r.url), capture ? null : h('div', {class: 'muted'}, 'with ' + host((r.package || {}).url))),
        h('td', {}, when(r.created)),
        h('td', {}, h('span', {class: 'badge ' + r.status}, STATUS[r.status] || r.status)),
        h('td', {}, result),
        h('td', {class: 'buttons'},
          h('button', {type: 'button', onclick: () => follow(r)}, 'Show'),
          ...((r.files || {}).package ? [h('a', {class: 'button', href: fileUrl(r.id, 'package.zip'), download: ''}, 'Package')] : []),
          ...((r.files || {}).report ? [h('a', {class: 'button', href: fileUrl(r.id, 'report.html'), target: '_blank', rel: 'noopener'}, 'Report')] : []),
          r.active ? null : h('button', {type: 'button', class: 'quiet', onclick: () => remove(r)}, 'Delete')));
    }))));
}

async function remove(r) {
  if (!confirm('Delete this ' + (r.type === 'CAPTURE' ? 'capture and its package' : 'comparison and its report') + '? This cannot be undone.')) return;
  try {
    await api('jobs/delete', {id: r.id});
    if (current && current.id === r.id) { current = null; $(r.type === 'CAPTURE' ? '#captureJob' : '#compareJob').replaceChildren(); }
    loadHistory();
  } catch (err) { notice(err.message); }
}

// ------------------------------------------------------------------ start: pick up a capture or comparison that is still running

(async () => {
  try {
    const rows = await api('jobs');
    const running = rows.find(r => r.active);
    if (running) follow(running);
  } catch (err) { notice(err.message); }
})();
