package guardian.boot;

import guardian.Api;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.net.InetAddress;
import java.util.Map;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/**
 * The same local-only rules as the built-in server, for every request: the caller must be on this computer,
 * the Host header must name it, and API calls need the session token and this app's own Origin.
 * Also adds the security headers (no caching, no framing, strict content security policy).
 */
@Configuration(proxyBeanMethods = false)
public class LocalOnlyGuard implements WebMvcConfigurer, HandlerInterceptor {
    private final Api api;

    public LocalOnlyGuard(Api api) {
        this.api = api;
    }

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(this).addPathPatterns("/**");
    }

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        Api.HEADERS.forEach(response::setHeader);
        Api.Reply refusal = loopback(request.getRemoteAddr())
                ? api.refuse(request.getRequestURI(), request.getHeader("Host"), request.getHeader("Origin"),
                        request.getHeader("X-Guardian-Token"), request.getLocalPort())
                : Api.Reply.json(403, Map.of("error", "Local connections only"));
        if (refusal == null) return true;
        response.setStatus(refusal.status());
        response.setContentType(refusal.type());
        response.getOutputStream().write(refusal.body());
        return false;
    }

    static boolean loopback(String address) {
        try {
            return InetAddress.getByName(address).isLoopbackAddress();   // an IP literal: no name lookup
        } catch (Exception e) {
            return false;
        }
    }
}
