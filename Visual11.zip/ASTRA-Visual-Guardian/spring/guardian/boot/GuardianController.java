package guardian.boot;

import guardian.Api;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Every request (the UI, /api/... and /files/...) is answered by the same {@link Api} as in the plain jar, so both
 * behave the same. Files (packages, reports, screenshots) are streamed from disk; package uploads are streamed to
 * disk. LocalOnlyGuard has already checked the caller, the Host header and the session token.
 */
@RestController
public class GuardianController {
    private final Api api;

    public GuardianController(Api api) {
        this.api = api;
    }

    @RequestMapping("/**")
    public void handle(HttpServletRequest request, HttpServletResponse response) throws IOException {
        Api.Reply reply;
        try {
            reply = api.handle(request.getMethod(), request.getRequestURI(), request.getQueryString(), request.getInputStream());
        } catch (Exception e) {
            reply = Api.error(e);
        }
        response.setStatus(reply.status());
        response.setContentType(reply.type());
        if (!reply.filename().isBlank()) response.setHeader("Content-Disposition", "attachment; filename=\"" + reply.filename() + "\"");
        response.setContentLengthLong(reply.length());
        reply.writeTo(response.getOutputStream());
    }
}
