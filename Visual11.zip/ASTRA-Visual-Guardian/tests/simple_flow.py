#!/usr/bin/env python3
"""
End-to-end check with a real Chrome, through the same API the UI uses:
capture an "old" system (sign-in, menus, similar pages, links that must never be opened, a page that scrolls
inside a panel), download its package, upload it again, compare it with a "new" system on another context path
(one page changed, one missing, one new, a masked clock), and check the statuses and the HTML report.
Usage: simple_flow.py path/to/visual-guardian.jar   (run under xvfb-run when there is no display)
"""
import io, json, os, re, socket, subprocess, sys, tempfile, threading, time, urllib.error, urllib.request, zipfile
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

JAR = Path(sys.argv[1]).resolve()
BROWSER = os.environ.get('GUARDIAN_TEST_BROWSER', '/usr/bin/google-chrome')
passed = []
seen = {'old': [], 'new': []}


def check(name, ok, detail=''):
    if not ok:
        raise AssertionError(name + (': ' + str(detail)[:3000] if detail else ''))
    passed.append(name)
    print('PASS', name, flush=True)


LOGIN = '''<!doctype html><html><head><title>Sign in</title></head><body><form><label>User <input name="user"></label>
<label>Password <input type="password" name="pw"></label><button type="button">Sign in</button></form>
<script>setTimeout(()=>{document.cookie='sid=ok; path=/';location.href='ROOT/home'},700)</script></body></html>'''

SPA = '''<!doctype html><html><head><title>SPA</title></head><body><nav><a href="#/">Start</a> <a href="#/a">Alpha</a> <a href="#/b">Beta</a></nav>
<main id="view"></main><script>function show(){const v=location.hash.replace('#','')||'/';document.title='SPA '+v;
document.getElementById('view').innerHTML='<h1>View '+v+'</h1><p>'+'Text of the view. '.repeat(20)+'</p>'}addEventListener('hashchange',show);show()</script></body></html>'''


def page(root, title, body, box='#eef2f7', extra_nav=''):
    nav = (f'<a href="{root}/home">Home</a><a href="{root}/orders">Orders</a><a href="{root}/customers">Customers</a>'
           f'<a href="{root}/reports">Reports</a><a href="{root}/status">Status</a><a href="{root}/long">Long page</a>'
           f'<button type="button" id="settings">Settings</button><a class="nolink" onclick="location.href=\'{root}/help\'">Help</a>'
           f'<a href="{root}/framed">Framed</a>{extra_nav}<a href="{root}/logout">Log out</a>')
    return (f'<!doctype html><html><head><title>{title}</title><style>body{{margin:0;font:16px Arial,sans-serif;color:#222;background:#fff}}'
            f'nav{{background:#203a5c;padding:12px}}nav a,nav button{{color:#fff;margin-right:14px;font:inherit;background:none;border:0;cursor:pointer}}'
            f'main{{padding:20px}}.box{{background:{box};padding:16px;margin:10px 0}}</style></head><body><nav>{nav}</nav>'
            f'<main><h1>{title}</h1>{body}</main><script>document.getElementById("settings").onclick=()=>{{location.href="{root}/settings"}}</script></body></html>')


def pages(system, root):
    new = system == 'new'
    p = {
        '/home': page(root, 'Home', f'<div class="box">Welcome to the application.</div>'
                      f'<p><a href="{root}/orders/7/delete">Delete order 7</a> <a href="{root}/files/report.pdf">Report (PDF)</a> '
                      f'<a href="https://example.invalid/help">Help site</a> <a href="{root}/old-only">Old feature</a> '
                      f'<a href="{root}/users/deleteUser.do?id=4">Remove user</a></p>'),
        '/orders': page(root, 'Orders', '<ul>' + ''.join(f'<li><a href="{root}/orders/{i}">Order {i}</a></li>' for i in range(1, 16)) + '</ul>'),
        '/customers': page(root, 'Customers', f'<div class="box">{"Customer directory" if new else "Customer list"}</div>'
                           + (f'<p><a href="{root}/brand-new">Brand new feature</a></p>' if new else ''), box='#fde7c8' if new else '#eef2f7'),
        '/reports': page(root, 'Reports', f'<p><a href="{root}/reports/annual">Annual report</a> <a href="{root}/admin/users">Users (admin)</a></p>'),
        '/reports/annual': page(root, 'Annual report', '<div class="box">Revenue grew.</div>'),
        '/status': page(root, 'Status', f'<div class="box">All systems normal.</div><div id="clock">{time.strftime("%H:%M:%S")} {time.time()}</div>'),
        '/settings': page(root, 'Settings', '<div class="box">Your settings.</div>'),
        '/help': page(root, 'Help', '<div class="box">How to use the application.</div>'),
        '/framed': page(root, 'Framed', f'<iframe src="{root}/frame-menu" style="width:600px;height:120px;border:1px solid #ccc"></iframe>'),
        '/frame-menu': f'<!doctype html><title>Frame menu</title><a href="{root}/frame-target">Only inside the frame</a>',
        '/frame-target': page(root, 'Frame target', '<div class="box">Reached through a frame.</div>'),
        '/admin/users': page(root, 'Users', 'admin'),
        '/logout': page(root, 'Signed out', 'bye'),
        '/long': ('<!doctype html><html><head><title>Long page</title><style>html,body{height:100%;margin:0;overflow:hidden;font:16px Arial}'
                  '.shell{display:flex;flex-direction:column;height:100%}header{background:#203a5c;color:#fff;padding:12px}'
                  '.scroller{flex:1;overflow:auto;padding:20px}.tall{height:2600px;background:linear-gradient(#fff,#cde)}</style></head>'
                  f'<body><div class="shell"><header>Long page</header><div class="scroller"><div class="tall">Top</div><p id="end">End of the long page</p></div></div></body></html>'),
    }
    for i in range(1, 16):
        total = 250 if new and i == 2 else i * 100
        p[f'/orders/{i}'] = page(root, f'Order {i}', f'<div class="box">Order number {i}. Total: {total}</div>')
    if new:
        p['/brand-new'] = page(root, 'Brand new', '<div class="box">Only on the new system.</div>')
    else:
        p['/old-only'] = page(root, 'Old feature', '<div class="box">Only on the old system.</div>')
    return p


def server(system, root):
    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *a):
            pass

        def send(self, code, body, headers=()):
            b = body.encode() if isinstance(body, str) else body
            self.send_response(code)
            self.send_header('Content-Type', 'text/html; charset=utf-8')
            self.send_header('Content-Length', str(len(b)))
            for k, v in headers:
                self.send_header(k, v)
            self.end_headers()
            try:
                self.wfile.write(b)
            except (BrokenPipeError, ConnectionResetError):
                pass   # the browser went away

        def do_GET(self):
            seen[system].append(self.path)
            path = self.path.split('?')[0]
            if path.startswith('/spa'):
                return self.send(200, SPA)
            if path == root + '/login':
                return self.send(200, LOGIN.replace('ROOT', root))
            if not path.startswith(root + '/'):
                return self.send(404, '<h1>Not found</h1>')
            if 'sid=ok' not in (self.headers.get('Cookie') or ''):
                return self.send(302, '', [('Location', root + '/login')])
            if path == root + '/':
                return self.send(302, '', [('Location', root + '/home')])
            body = pages(system, root).get(path[len(root):])
            return self.send(404, '<!doctype html><title>Not found</title><h1>404 Not found</h1>') if body is None else self.send(200, body)

    s = ThreadingHTTPServer(('127.0.0.1', 0), Handler)
    threading.Thread(target=s.serve_forever, daemon=True).start()
    return f'http://127.0.0.1:{s.server_port}'


OLD, NEW = server('old', '/app'), server('new', '/portal')

with tempfile.TemporaryDirectory() as td:
    data = Path(td) / 'data'
    sock = socket.socket()
    sock.bind(('127.0.0.1', 0))
    port = sock.getsockname()[1]
    sock.close()
    base = f'http://127.0.0.1:{port}'
    env = dict(os.environ)
    if hasattr(os, 'geteuid') and os.geteuid() == 0:
        env['GUARDIAN_TEST_NO_SANDBOX'] = '1'
    log = open(Path(td) / 'guardian.log', 'w')
    proc = subprocess.Popen(['java', '-jar', str(JAR), '--port', str(port), '--data', str(data)], stdout=log, stderr=subprocess.STDOUT, env=env)
    try:
        for _ in range(100):
            try:
                html = urllib.request.urlopen(base, timeout=1).read().decode()
                break
            except Exception:
                time.sleep(0.2)
        else:
            raise RuntimeError('Guardian did not start')
        token = re.search('name="guardian-token" content="([^"]+)"', html).group(1)
        files = re.search('name="guardian-files" content="([^"]+)"', html).group(1)
        check('the UI page is served with its session token and file key', 'ASTRA Visual Guardian' in html and len(token) > 30 and len(files) > 30)

        def request(path, body=None, headers=None, expect=200, raw=False):
            h = dict(headers or {})
            if body is not None and not isinstance(body, bytes):
                body = json.dumps(body).encode()
                h['Content-Type'] = 'application/json'
            req = urllib.request.Request(base + path, data=body, headers=h)
            try:
                res = urllib.request.urlopen(req, timeout=60)
                code, out, hdrs = res.status, res.read(), res.headers
            except urllib.error.HTTPError as e:
                code, out, hdrs = e.code, e.read(), e.headers
            assert code == expect, (path, code, out[:600])
            return (out, hdrs) if raw else json.loads(out)

        def api(path, body=None, expect=200):
            return request('/api/' + path, body, {'X-Guardian-Token': token}, expect)

        check('API calls without the token are refused', request('/api/jobs', expect=403)['error'])
        check('API calls from another web page (Origin) are refused', request('/api/jobs', headers={'X-Guardian-Token': token, 'Origin': 'https://evil.example'}, expect=403))
        check('files need the file key', request(f'/files/wrong/x/report.html', expect=404))
        for asset in ['/app.js', '/style.css']:
            out, hdrs = request(asset, raw=True)
            check(f'{asset} is served with a strict content security policy', len(out) > 1000 and "script-src 'self'" in hdrs['Content-Security-Policy'])

        def wait(job_id, until, timeout=240):
            end = time.time() + timeout
            while time.time() < end:
                j = api('jobs/' + job_id)
                if until(j):
                    return j
                time.sleep(0.4)
            raise AssertionError('timed out waiting: ' + json.dumps(j)[:3000])

        def finished(j):
            return not j['active'] and j['status'] not in ('STARTING', 'WAITING', 'RUNNING')

        base_settings = {'browser': BROWSER, 'width': 1200, 'height': 800, 'settleMs': 150}
        # ---------------------------------------------------------------- capture
        cap = api('captures', {'url': OLD + '/app/home', 'signIn': True, 'settings': dict(base_settings, maxSimilar=3, masks=['#clock'],
                                                                                         skipPages=['/admin'])})
        j = wait(cap['id'], lambda j: j['status'] == 'WAITING')
        check('capture waits for you to sign in first', 'Sign in' in j['message'] and j['active'])
        time.sleep(2.5)   # the fixture's sign-in page signs in by itself, as a person would
        api('jobs/command', {'id': cap['id'], 'command': 'continue'})
        j = wait(cap['id'], finished)
        full = json.loads((data / 'jobs' / cap['id'] / 'job.json').read_text())
        keys = [p['key'] for p in full['pages']]
        print('CAPTURE', j['status'], j['message'], keys, flush=True)
        check('capture finished', j['status'] == 'DONE' and j['files']['package'] and j['files']['gallery'], j)
        expected = ['/app/home', '/app/orders', '/app/customers', '/app/reports', '/app/status', '/app/long', '/app/settings', '/app/old-only',
                    '/app/reports/annual', '/app/orders/1', '/app/orders/2', '/app/orders/3', '/app/help', '/app/framed', '/app/frame-target']
        check('every page reachable by links and the menu button was captured once', sorted(keys) == sorted(expected) and len(keys) == len(set(keys)), keys)
        check('pages are captured level by level, starting with the first page', keys[0] == '/app/home' and keys.index('/app/reports/annual') > keys.index('/app/old-only'))
        check('the Settings menu button (no link) led to its page', any(p['key'] == '/app/settings' and p['via'].startswith('menu') for p in full['pages']))
        check('a menu item without an address (a link with a click handler) led to its page', any(p['key'] == '/app/help' and p['via'].startswith('menu') for p in full['pages']))
        check('a link that is only inside a frame was followed', '/app/frame-target' in keys and '/app/frame-menu' not in keys)
        check('similar pages are limited (3 of 15 orders)', full['similar'] == {'/app/orders/{id}': 12}, full['similar'])
        reasons = {x['key']: x['reason'] for x in full['notOpened']}
        check('sign-out, delete, Struts-style delete and file links were listed, not opened',
              reasons.get('/app/logout') == 'sign-out link' and 'action' in reasons.get('/app/orders/7/delete', '') and
              'action' in reasons.get('/app/users/deleteUser.do?id=4', '') and reasons.get('/app/files/report.pdf') == 'file download', reasons)
        check('the skip rule kept /admin out', reasons.get('/app/admin/users', '').startswith('Pages to skip'), reasons)
        never = [p for p in seen['old'] if any(x in p for x in ['/logout', '/delete', 'deleteUser', '.pdf', '/admin'])]
        check('the old system never received a request for those links', not never, never)
        heights = {p['key']: p['height'] for p in full['pages']}
        check('a page that scrolls inside a panel is captured in full', heights['/app/long'] > 2500 and heights['/app/home'] == 800, heights)
        check('the sign-in page is not part of the capture', '/app/login' not in keys)

        out, hdrs = request(f'/files/{files}/{cap["id"]}/package.zip', raw=True)
        z = zipfile.ZipFile(io.BytesIO(out))
        names = z.namelist()
        manifest = json.loads(z.read('guardian-package.json'))
        check('the package downloads as a ZIP with a clear file name', 'attachment' in hdrs['Content-Disposition'] and
              re.search(r'guardian-package-127\.0\.0\.1-\d{4}-\d{2}-\d{2}-\d{4}\.zip', hdrs['Content-Disposition']), hdrs['Content-Disposition'])
        check('the package holds the manifest, the gallery, one screenshot and one text file per page',
              'guardian-package.json' in names and 'index.html' in names and len([n for n in names if n.startswith('shots/')]) == len(keys)
              and len([n for n in names if n.startswith('text/')]) == len(keys))
        check('the manifest records the browser and that the capture is complete', manifest['complete'] and manifest['browserVersion'].startswith(('Chrome', 'HeadlessChrome')))
        status_text = z.read([p['text'] for p in manifest['pages'] if p['key'] == '/app/status'][0]).decode()
        check('text inside areas to hide is left out', 'All systems normal' in status_text and ':' not in status_text.split('\n', 1)[1].replace('All systems normal.', ''), status_text)
        gallery, _ = request(f'/files/{files}/{cap["id"]}/index.html', raw=True)
        gallery = gallery.decode()
        check('the gallery shows every page and the links not opened', 'Annual report' in gallery and 'shots/0001.png' in gallery and 'sign-out link' in gallery
              and '<script' not in gallery)
        shot, hdrs = request(f'/files/{files}/{cap["id"]}/shots/0001.png', raw=True)
        check('screenshots open in the browser', shot[:8] == b'\x89PNG\r\n\x1a\n' and hdrs['Content-Type'] == 'image/png')

        # ---------------------------------------------------------------- upload
        up = request('/api/packages', out, {'X-Guardian-Token': token, 'Content-Type': 'application/zip'})
        check('the package uploads again', up['pages'] == len(keys) and up['url'] == OLD + '/app/home')
        rezipped = io.BytesIO()
        with zipfile.ZipFile(rezipped, 'w') as w:
            for n in names:
                w.writestr('guardian-package-copy/' + n, z.read(n))
            w.writestr('__MACOSX/._x', b'junk')
            w.writestr('guardian-package-copy/Thumbs.db', b'junk')
        up2 = request('/api/packages', rezipped.getvalue(), {'X-Guardian-Token': token, 'Content-Type': 'application/zip'})
        check('a package that was unzipped and zipped again is accepted', up2['pages'] == len(keys))
        evil = io.BytesIO()
        with zipfile.ZipFile(evil, 'w') as w:
            w.writestr('guardian-package.json', json.dumps(dict(manifest, pages=[dict(manifest['pages'][0], shot='../../evil.png')])))
            w.writestr('../evil.png', b'x')
        bad = request('/api/packages', evil.getvalue(), {'X-Guardian-Token': token, 'Content-Type': 'application/zip'}, expect=400)
        check('a package with paths outside its folder is refused', 'incomplete' in bad['error'] or 'not' in bad['error'], bad)
        check('no file escaped the data folder', not (data.parent / 'evil.png').exists() and not (data / 'evil.png').exists())
        check('a file that is not a ZIP is refused', 'ZIP' in request('/api/packages', b'hello', {'X-Guardian-Token': token}, expect=400)['error'])
        bases = api('baselines')
        check('packages to compare with: the capture and the uploads', {b['id'] for b in bases} >= {cap['id'], up['id'], up2['id']})

        # ---------------------------------------------------------------- compare
        # the new address is typed as the bare root this time: the pages are matched through the addresses both applications opened at
        cmp_ = api('compares', {'package': up['id'], 'url': NEW + '/portal/', 'signIn': True, 'settings': dict(base_settings, width=1600)})
        wait(cmp_['id'], lambda j: j['status'] == 'WAITING')
        time.sleep(2.5)
        api('jobs/command', {'id': cmp_['id'], 'command': 'continue'})
        j = wait(cmp_['id'], finished)
        full = json.loads((data / 'jobs' / cmp_['id'] / 'job.json').read_text())
        st = {r['key']: r['status'] for r in full['results']}
        print('COMPARE', j['status'], j['summary'], st, flush=True)
        check('comparison finished with a report', j['status'] == 'DONE' and j['files']['report'], j)
        check('the window size comes from the package, not the comparison settings', full['settings']['width'] == 1200)
        check('the old context path was mapped to the new one', full['mapping'] == {'from': OLD + '/app', 'to': NEW + '/portal'}, full['mapping'])
        check('changed pages are found (text and colour; a changed amount)', st['/app/customers'] == 'CHANGED' and st['/app/orders/2'] == 'CHANGED', st)
        check('a page the new system does not have is missing', st['/app/old-only'] == 'MISSING', st)
        check('a new page is found', st.get('/portal/brand-new') == 'NEW', st)
        same = ['/app/home', '/app/orders', '/app/reports', '/app/reports/annual', '/app/status', '/app/long', '/app/settings', '/app/orders/1', '/app/orders/3',
                '/app/help', '/app/framed', '/app/frame-target']
        check('unchanged pages are the same (the clock is hidden; menus and layout identical)', all(st[k] == 'SAME' for k in same), {k: st[k] for k in same})
        check('the summary adds up', j['summary'] == {'same': 12, 'changed': 2, 'missing': 1, 'new': 1, 'skipped': 0}, j['summary'])
        cust = [r for r in full['results'] if r['key'] == '/app/customers'][0]
        check('a changed page says what changed', any('areas of the screenshot changed' in x or 'area of the screenshot changed' in x for x in cust['reasons'])
              and 'Customer directory' in cust['added'] and 'Customer list' in cust['removed'], cust)
        check('the similar orders left out of the package are not reported as new', not any(k.startswith('/portal/orders/') for k, v in st.items() if v == 'NEW'))
        never = [p for p in seen['new'] if any(x in p for x in ['/logout', '/delete', 'deleteUser', '.pdf', '/admin'])]
        check('the new system never received a request for links that are never opened', not never, never)
        report, hdrs = request(f'/files/{files}/{cmp_["id"]}/report.html', raw=True)
        report = report.decode()
        check('the report opens in the browser', hdrs['Content-Type'].startswith('text/html') and 'Content-Disposition' not in hdrs)
        check('the report is one file with its pictures inside and no scripts', report.count('data:image/jpeg;base64,') >= 7 and '<script' not in report.lower())
        check('the report lists changed, missing and new pages with their reasons', all(x in report for x in [
            '2 pages changed, 1 page missing, 1 new page', 'Changed pages', 'Missing pages', 'New pages', 'Unchanged pages', 'Customer directory',
            'the new system answers HTTP 404', 'id="p-0003"', 'Brand new']), report[:2000])
        _, hdrs = request(f'/files/{files}/{cmp_["id"]}/report.html?download=1', raw=True)
        check('the report downloads with a clear file name', re.search(r'guardian-report-127\.0\.0\.1-[\d-]+\.html', hdrs['Content-Disposition']), hdrs['Content-Disposition'])
        diffs = j['differences']
        check('the UI gets the list of differences', {d['status'] for d in diffs} == {'CHANGED', 'MISSING', 'NEW'} and len(diffs) == 4, diffs)

        # ---------------------------------------------------------------- a single-page app (hash routes), hidden browser, no sign-in
        spa = api('captures', {'url': OLD + '/spa/', 'signIn': False, 'settings': dict(base_settings, headless=True)})
        j = wait(spa['id'], finished)
        spa_keys = [p['key'] for p in json.loads((data / 'jobs' / spa['id'] / 'job.json').read_text())['pages']]
        check('a single-page app: every route captured once (the first route is the page itself)', sorted(spa_keys) == ['/spa/', '/spa/#/a', '/spa/#/b'], spa_keys)
        refused = api('captures', {'url': OLD + '/app/home', 'signIn': True, 'settings': dict(base_settings, headless=True)})
        j = wait(refused['id'], finished)
        check('signing in with a hidden browser is refused with a clear message', j['status'] == 'FAILED' and 'Hidden browser' in j['message'], j['message'])

        # ---------------------------------------------------------------- stop, history, delete
        stop = api('captures', {'url': OLD + '/app/home', 'signIn': True, 'settings': base_settings})
        wait(stop['id'], lambda j: j['status'] == 'WAITING')
        busy = api('captures', {'url': OLD + '/app/home', 'settings': base_settings}, expect=400)
        check('only one capture or comparison runs at a time', 'already running' in busy['error'])
        api('jobs/command', {'id': stop['id'], 'command': 'stop'})
        j = wait(stop['id'], finished, 30)
        check('Stop ends a capture that waits for sign-in', j['status'] == 'STOPPED')
        hist = api('jobs')
        check('History lists every capture and comparison, newest first', len(hist) == 5 and hist[0]['id'] == stop['id'] and
              {h['type'] for h in hist} == {'CAPTURE', 'COMPARE'})
        api('jobs/delete', {'id': stop['id']})
        check('a job can be deleted', all(h['id'] != stop['id'] for h in api('jobs')) and not (data / 'jobs' / stop['id']).exists())
        api('packages/delete', {'id': up2['id']})
        check('an uploaded package can be deleted', all(b['id'] != up2['id'] for b in api('baselines')))
        print('TOTAL', len(passed), 'checks passed')
        if os.environ.get('KEEP_DIR'):
            import shutil
            shutil.copytree(data / 'jobs', Path(os.environ['KEEP_DIR']) / 'jobs', dirs_exist_ok=True)
    finally:
        proc.terminate()
        try:
            proc.wait(10)
        except Exception:
            proc.kill()
        log.close()
        if os.environ.get('SHOW_LOG'):
            print((Path(td) / 'guardian.log').read_text())
