package guardian;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.util.List;
import java.util.Map;

import static guardian.Json.*;

/**
 * Page names, links that are never opened, old-to-new address mapping, screenshot and text comparison, settings.
 * Usage: java -cp classes:test-classes guardian.DiffChecks
 */
public class DiffChecks {
    static int passed = 0;

    static void check(String name, boolean ok) {
        if (!ok) throw new AssertionError(name);
        passed++;
        System.out.println("PASS " + name);
    }

    static BufferedImage image(int w, int h, Color fill) {
        var img = new BufferedImage(w, h, BufferedImage.TYPE_INT_RGB);
        Graphics2D g = img.createGraphics();
        g.setColor(fill);
        g.fillRect(0, 0, w, h);
        g.dispose();
        return img;
    }

    public static void main(String[] args) throws Exception {
        // ---------------------------------------------------------------- page names
        check("a page is its path and query", Site.key("https://a.example/app/orders?b=2&a=1").equals("/app/orders?a=1&b=2"));
        check("tracking parameters and cache busters are ignored", Site.key("https://a.example/x?utm_source=m&_=123&id=4").equals("/x?id=4"));
        check("jsessionid in the path is ignored", Site.key("https://a.example/app/home;jsessionid=AB12?x=1").equals("/app/home?x=1"));
        check("single-page-app routes count, plain anchors do not",
                Site.key("https://a.example/app/#/orders/5").equals("/app/#/orders/5") && Site.key("https://a.example/app/page#top").equals("/app/page")
                        && Site.key("https://a.example/app/#!/x").equals("/app/#!/x"));
        check("the first route (#/) is the page itself", Site.key("https://a.example/spa/#/").equals("/spa/") && Site.key("https://a.example/spa/#!/").equals("/spa/"));
        check("an empty path is /", Site.key("https://a.example").equals("/"));
        check("similar pages share a pattern", Site.pattern("/app/orders/15").equals("/app/orders/{id}")
                && Site.pattern("/app/x/3f2504e0-4f89-11d3-9a0c-0305e82c3301/view").equals("/app/x/{id}/view")
                && Site.pattern("/list?page=7&sort=name").equals("/list?page={v}&sort=name") && Site.pattern("/app/home").equals("/app/home"));

        // ---------------------------------------------------------------- links that are never opened
        check("sign-out links are never opened", Site.notOpened("https://a/app/logout", "Bye").equals("sign-out link")
                && Site.notOpened("https://a/app/log-out", "").equals("sign-out link") && Site.notOpened("https://a/app/x", "Sign out").equals("sign-out link")
                && Site.notOpened("https://a/app/session?cmd=signOff", "").equals("sign-out link") && Site.notOpened("https://a/app/LogOff.aspx", "").equals("sign-out link"));
        check("links that look like actions are never opened", Site.notOpened("https://a/app/orders/7/delete", "").contains("action")
                && Site.notOpened("https://a/app/users/deleteUser.do?id=4", "").contains("action")
                && Site.notOpened("https://a/app/servlet?action=remove&id=3", "").contains("action")
                && Site.notOpened("https://a/app/item/5", "Approve request").contains("action")
                && Site.notOpened("https://a/app/x", "Delete").contains("action"));
        check("files and downloads are never opened", Site.notOpened("https://a/files/report.PDF", "").equals("file download")
                && Site.notOpened("https://a/app/export?id=1", "").equals("file download") && Site.notOpened("https://a/app/x", "Download CSV").equals("file download"));
        check("ordinary pages are opened, even with similar words", Site.notOpened("https://a/app/orders", "Orders").isEmpty()
                && Site.notOpened("https://a/app/removed-items", "Removed items").isEmpty() && Site.notOpened("https://a/app/cancellations", "").isEmpty()
                && Site.notOpened("https://a/app/downloads", "Downloads").isEmpty() && Site.notOpened("https://a/app/approvals", "Approvals").isEmpty()
                && Site.notOpened("https://a/blog/logging", "Logging").isEmpty());
        check("menu buttons that change things are never clicked", Site.risky("Delete") && Site.risky("Save changes") && Site.risky("Dark mode")
                && Site.risky("Log out") && Site.risky("Export") && Site.risky("New order"));
        check("menu buttons that open pages are clicked", !Site.risky("Settings") && !Site.risky("Orders") && !Site.risky("Reports overview")
                && !Site.risky("Customer list"));

        // ---------------------------------------------------------------- old address -> new address
        var keys = List.of("/app/home", "/app/orders", "/app/orders/1", "/app/reports/annual");
        var m = Site.Mapping.of("https://old.example/app/home", "https://new.example/portal/home", "", "", keys, "", "");
        check("a common ending of the start addresses maps the context path", m.forward("/app/orders/1").equals("https://new.example/portal/orders/1")
                && m.back("https://new.example/portal/orders/1?x=1").equals("/app/orders/1?x=1"));
        var same = Site.Mapping.of("https://app.example/app/home", "https://app.example/app/home", "", "", keys, "", "");
        check("the same address (a deployment) maps every page to itself", same.forward("/app/orders").equals("https://app.example/app/orders")
                && same.back("https://app.example/app/orders").equals("/app/orders"));
        var host = Site.Mapping.of("https://old.example/app/", "https://new.example/app/", "", "", keys, "", "");
        check("a new host with the same paths", host.forward("/app/reports/annual").equals("https://new.example/app/reports/annual"));
        var root = Site.Mapping.of("https://old.example/app/home", "https://new.example/portal/", "", "", keys, "", "");
        check("a root address on one side and a page on the other still maps (/app becomes /portal)",
                root.fromPrefix().equals("/app") && root.toPrefix().equals("/portal") && root.forward("/app/orders").equals("https://new.example/portal/orders"));
        var landing = Site.Mapping.of("https://old.example/", "https://new.example/next/", "https://old.example/home", "https://new.example/next/home",
                List.of("/home", "/orders"), "", "");
        check("the addresses the applications opened at decide when the start addresses do not", landing.forward("/orders").equals("https://new.example/next/orders"));
        var given = Site.Mapping.of("https://old.example/a/b", "https://new.example/c", "", "", keys, "/app", "/web/ui");
        check("prefixes you give win", given.forward("/app/orders").equals("https://new.example/web/ui/orders") && given.back("https://new.example/web/ui").equals("/app"));
        check("pages outside the context path are kept as they are", m.forward("/other/x").equals("https://new.example/other/x"));
        check("the context path is not matched inside a longer name", Site.Mapping.swap("/application/x", "/app", "/portal").equals("/application/x")
                && Site.Mapping.swap("/app?x=1", "/app", "/portal").equals("/portal?x=1") && Site.Mapping.swap("/app", "/app", "").equals("/"));
        check("the folder all pages share", Site.Mapping.folder(keys).equals(List.of("app")) && Site.Mapping.folder(List.of("/app/home")).equals(List.of("app"))
                && Site.Mapping.folder(List.of("/home", "/orders")).isEmpty() && Site.Mapping.folder(List.of("/app/", "/app/x/y")).equals(List.of("app")));

        // ---------------------------------------------------------------- screenshots
        var a = image(200, 100, Color.WHITE);
        var b = image(200, 100, Color.WHITE);
        check("identical screenshots have no difference", Diff.images(a, b).changedPixels() == 0 && Diff.images(a, b).areas().isEmpty());
        var g = b.createGraphics();
        g.setColor(Color.BLUE);
        g.fillRect(20, 30, 40, 10);
        g.dispose();
        var d = Diff.images(a, b);
        check("a changed block is one area with its pixels counted", d.changedPixels() == 400 && d.areas().size() == 1 && Math.abs(d.percent() - 2.0) < 1e-9);
        int[] area = d.areas().get(0);
        check("the area covers the change", area[0] <= 20 && area[1] <= 30 && area[0] + area[2] >= 60 && area[1] + area[3] >= 40);
        int marked = d.overlay().getRGB(30, 35) & 0xFFFFFF;
        check("the changes picture marks changed pixels red but keeps them visible", (marked >> 16 & 255) > 130 && (marked & 255) > 80 && (marked & 255) < 255);
        var c = image(200, 100, new Color(250, 250, 250));
        check("tiny colour differences (font smoothing) are ignored", Diff.images(a, c).changedPixels() == 0);
        var tall = image(200, 150, Color.WHITE);
        var dt = Diff.images(a, tall);
        check("a taller page counts its extra part as changed", dt.changedPixels() == 200 * 50 && dt.heightBefore() == 100 && dt.heightAfter() == 150
                && Report.describe(dt).contains("50 px taller"));
        var masked = image(200, 100, Color.WHITE);
        var g2 = masked.createGraphics();
        g2.setColor(Color.RED);
        g2.fillRect(0, 0, 50, 20);
        g2.dispose();
        Diff.blank(masked, List.of(new int[]{0, 0, 50, 20}));
        var a2 = image(200, 100, Color.WHITE);
        Diff.blank(a2, List.of(new int[]{0, 0, 50, 20}));
        check("hidden areas are blanked on both pictures and do not count", Diff.images(a2, masked).changedPixels() == 0);
        var cut = Diff.cut(image(100, 50, Color.BLACK), new int[]{0, 0, 100, 100}, 1000, 1000);
        check("a cut-out of a shorter picture is not stretched", cut.getHeight() == 100 && (cut.getRGB(50, 25) & 0xFFFFFF) == 0 && (cut.getRGB(50, 75) & 0xFFFFFF) == 0xF2F2F2);
        var small = Diff.cut(image(2000, 4000, Color.WHITE), new int[]{0, 0, 2000, 4000}, 1000, 1000);
        check("a cut-out fits the largest size", small.getWidth() == 500 && small.getHeight() == 1000);
        check("the size of a PNG is read from its header", java.util.Arrays.equals(Diff.pngSize(Diff.png(image(321, 123, Color.WHITE))), new int[]{321, 123}));
        check("very small differences are described", Report.percent(0.004).equals("less than 0.01%") && Report.percent(1.234).equals("1.23%"));

        // ---------------------------------------------------------------- text
        var t = Diff.text(List.of("Orders", "Total: 100", "Total: 100", "Help"), List.of("Orders", "Total: 100", "Total: 250", "Help", "New  link"), 10);
        check("text changes: added and removed lines (repeated lines counted)", t.get("added").equals(List.of("Total: 250", "New  link"))
                && t.get("removed").equals(List.of("Total: 100")));
        check("spacing differences are not text changes", Diff.text(List.of("a  b"), List.of(" a b "), 10).get("added").isEmpty());

        // ---------------------------------------------------------------- settings
        Map<String, Object> s = Jobs.settings(obj(), true);
        check("default settings", s.get("width").equals(1366) && s.get("height").equals(768) && s.get("maxPages").equals(500) && s.get("maxSimilar").equals(10)
                && yes(s.get("fullPage")) && yes(s.get("menus")) && yes(s.get("findNew")) && dbl(s.get("tolerance"), -1) == 0 && yes(s.get("signIn")));
        Map<String, Object> wild = Jobs.settings(obj("width", 99999, "height", 1, "maxPages", -5, "tolerance", 500, "masks", "#a\n\n .b \n"), false);
        check("settings are kept within limits", wild.get("width").equals(3840) && wild.get("height").equals(500) && wild.get("maxPages").equals(1)
                && dbl(wild.get("tolerance"), -1) == 100 && wild.get("masks").equals(List.of("#a", ".b")) && !yes(wild.get("signIn")));

        // ---------------------------------------------------------------- report, files, sign-in services
        String gallery = Report.gallery(obj("application", "https://a.example/app", "captured", "2026-11-26T10:00:00Z", "complete", true,
                "settings", obj("width", 1366, "height", 768, "fullPage", true), "pages", List.of(obj("n", 1, "key", "/app/<x>", "title", "<script>alert(1)</script>",
                        "shot", "shots/0001.png", "via", "first page")), "notOpened", List.of(), "similar", obj()));
        check("the gallery escapes page titles and addresses", !gallery.contains("<script>") && gallery.contains("&lt;script&gt;") && gallery.contains("/app/&lt;x&gt;"));
        check("only Guardian's own files are served", Api.FILE.matcher("report.html").matches() && Api.FILE.matcher("shots/0001.png").matches()
                && Api.FILE.matcher("shots/new-0001.png").matches() && !Api.FILE.matcher("../job.json").matches() && !Api.FILE.matcher("job.json").matches()
                && !Api.FILE.matcher("shots/../../x.png").matches());
        check("query parameters are read", Api.param("since=2026-11-26T10%3A00%3A00Z&x=1", "since").equals("2026-11-26T10:00:00Z") && Api.param(null, "x").isEmpty());
        check("sign-in services on other hosts are recognised", Session.SIGN_IN_ADDRESS.matcher("login.microsoftonline.com/common/oauth2/authorize").find()
                && Session.SIGN_IN_ADDRESS.matcher("sso.corp.example/idp/SSO.saml2").find() && Session.SIGN_IN_ADDRESS.matcher("corp.okta.com/app/x").find()
                && Session.SIGN_IN_ADDRESS.matcher("adfs.corp.example/adfs/ls/").find());
        check("other hosts are not taken for sign-in services", !Session.SIGN_IN_ADDRESS.matcher("blog.example.com/posts/authoring-tips").find()
                && !Session.SIGN_IN_ADDRESS.matcher("cdn.example.com/static/app.js").find());
        check("certificate errors are recognised", Session.certificate("net::ERR_CERT_AUTHORITY_INVALID") && Session.certificate("net::ERR_SSL_PROTOCOL_ERROR")
                && Session.certificate("net::ERR_BAD_SSL_CLIENT_AUTH_CERT") && !Session.certificate("net::ERR_NAME_NOT_RESOLVED"));
        System.out.println("TOTAL " + passed + " checks passed");
    }
}
