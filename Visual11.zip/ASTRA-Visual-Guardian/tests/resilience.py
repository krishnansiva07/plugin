#!/usr/bin/env python3
"""
What happens on the way, with a real Chrome: the session runs out during a capture (Guardian waits for you to sign
in again, then carries on), the browser window is closed, Guardian itself is closed during a capture (the pages
taken so far are kept and packaged), and a site whose certificate the browser does not trust (Guardian waits for
you to accept it).
Usage: resilience.py path/to/visual-guardian.jar   (under xvfb-run when there is no display)
"""
import json, os, re, signal, socket, ssl, subprocess, sys, tempfile, threading, time, urllib.error, urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

JAR = Path(sys.argv[1]).resolve()
BROWSER = os.environ.get('GUARDIAN_TEST_BROWSER', '/usr/bin/google-chrome')
passed = []


def check(name, ok, detail=''):
    if not ok:
        raise AssertionError(name + (': ' + str(detail)[:3000] if detail else ''))
    passed.append(name)
    print('PASS', name, flush=True)


class App:
    """A small application with a sign-in page; its session can be made to run out after some pages."""

    def __init__(self, pages=12, expire_after=None, slow=0.0, auto=True):
        self.valid, self.next_sid, self.served, self.expire_after, self.slow, self.pages = set(), 1, 0, expire_after, slow, pages
        # auto: signing in again happens by itself (single sign-on); otherwise only when the test says so (a person signing in)
        self.auto, self.allow = auto, True
        self.lock = threading.Lock()

    def handler(self):
        app = self

        class H(BaseHTTPRequestHandler):
            def log_message(self, *a):
                pass

            def send(self, code, body, headers=()):
                b = body.encode()
                self.send_response(code)
                self.send_header('Content-Type', 'text/html; charset=utf-8')
                self.send_header('Content-Length', str(len(b)))
                for k, v in headers:
                    self.send_header(k, v)
                self.end_headers()
                try:
                    self.wfile.write(b)
                except (BrokenPipeError, ConnectionResetError):
                    pass   # the browser went away

            def do_GET(self):
                path = self.path.split('?')[0]
                if path == '/login':
                    return self.send(200, '<!doctype html><title>Sign in</title><input type="password"><script>setInterval(async()=>{'
                                     'if((await (await fetch("/may-sign-in")).text())==="yes")location.href="/signed-in"},300)</script>')
                if path == '/may-sign-in':
                    return self.send(200, 'yes' if app.allow else 'no')
                if path == '/signed-in':
                    with app.lock:
                        sid = str(app.next_sid)
                        app.next_sid += 1
                        app.valid.add(sid)
                        app.allow = app.auto
                    return self.send(302, '', [('Set-Cookie', f'sid={sid}; Path=/'), ('Location', '/p/0')])
                m = re.search(r'sid=(\d+)', self.headers.get('Cookie') or '')
                with app.lock:
                    ok = m is not None and m.group(1) in app.valid
                    if ok:
                        app.served += 1
                        if app.expire_after and app.served == app.expire_after:
                            app.valid.clear()   # the session runs out from the next page on
                if not ok:
                    return self.send(302, '', [('Location', '/login')])
                if app.slow:
                    time.sleep(app.slow)
                n = int(path.rsplit('/', 1)[-1]) if path.startswith('/p/') else 0
                links = ''.join(f'<a href="/p/{i}">Page {i}</a> ' for i in range(app.pages))
                return self.send(200, f'<!doctype html><title>Page {n}</title><nav>{links}</nav><h1>Page {n}</h1><p>{"Text. " * 30}</p>')
        return H


def serve(app, tls=None):
    s = ThreadingHTTPServer(('127.0.0.1', 0), app.handler())
    if tls:
        ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        ctx.load_cert_chain(*tls)
        s.socket = ctx.wrap_socket(s.socket, server_side=True)
    threading.Thread(target=s.serve_forever, daemon=True).start()
    return f'{"https" if tls else "http"}://127.0.0.1:{s.server_port}'


class Guardian:
    def __init__(self, data):
        self.data = data
        sock = socket.socket()
        sock.bind(('127.0.0.1', 0))
        self.port = sock.getsockname()[1]
        sock.close()
        self.base = f'http://127.0.0.1:{self.port}'
        env = dict(os.environ)
        if hasattr(os, 'geteuid') and os.geteuid() == 0:
            env['GUARDIAN_TEST_NO_SANDBOX'] = '1'
        self.proc = subprocess.Popen(['java', '-jar', str(JAR), '--port', str(self.port), '--data', str(data)],
                                     stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, env=env)
        for _ in range(100):
            try:
                html = urllib.request.urlopen(self.base, timeout=1).read().decode()
                break
            except Exception:
                time.sleep(0.2)
        else:
            raise RuntimeError('Guardian did not start')
        self.token = re.search('name="guardian-token" content="([^"]+)"', html).group(1)

    def api(self, path, body=None, expect=200):
        req = urllib.request.Request(self.base + '/api/' + path, data=None if body is None else json.dumps(body).encode(),
                                     headers={'X-Guardian-Token': self.token, 'Content-Type': 'application/json'})
        try:
            res = urllib.request.urlopen(req, timeout=60)
            code, out = res.status, res.read()
        except urllib.error.HTTPError as e:
            code, out = e.code, e.read()
        assert code == expect, (path, code, out[:500])
        return json.loads(out)

    def wait(self, job, until, timeout=180):
        end = time.time() + timeout
        while time.time() < end:
            j = self.api('jobs/' + job)
            if until(j):
                return j
            time.sleep(0.3)
        raise AssertionError('timed out: ' + json.dumps(j)[:2000])

    def stop(self, kill=False):
        if kill:
            self.proc.send_signal(signal.SIGKILL)
        else:
            self.proc.terminate()
        self.proc.wait(15)


def finished(j):
    return not j['active'] and j['status'] not in ('STARTING', 'WAITING', 'RUNNING')


def browsers_of(data):
    out = subprocess.run(['pgrep', '-f', f'user-data-dir={data}'], capture_output=True, text=True).stdout.split()
    return [int(x) for x in out]


settings = {'browser': BROWSER, 'settleMs': 100, 'width': 1000, 'height': 700, 'maxSimilar': 0}
with tempfile.TemporaryDirectory() as td:
    data = Path(td) / 'data'
    g = Guardian(data)
    try:
        # ---------------------------------------------------------------- the session runs out during the capture: you sign in again
        app = App(pages=12, expire_after=6, auto=False)
        url = serve(app)
        job = g.api('captures', {'url': url + '/p/0', 'signIn': True, 'settings': settings})['id']
        g.wait(job, lambda j: j['status'] == 'WAITING')
        time.sleep(2)
        g.api('jobs/command', {'id': job, 'command': 'continue'})
        g.wait(job, lambda j: j['status'] != 'WAITING')
        j = g.wait(job, lambda j: j['status'] == 'WAITING' or finished(j))
        check('when the session runs out, the capture waits for you to sign in again', j['status'] == 'WAITING' and 'sign in again' in j['message'], j['message'])
        app.allow = True   # the person signs in
        time.sleep(1.5)
        g.api('jobs/command', {'id': job, 'command': 'continue'})
        j = g.wait(job, finished)
        keys = sorted(p['key'] for p in json.loads((data / 'jobs' / job / 'job.json').read_text())['pages'])
        full = json.loads((data / 'jobs' / job / 'job.json').read_text())
        check('after signing in again the capture carries on and misses no page', j['status'] == 'DONE' and keys == sorted(f'/p/{i}' for i in range(12)),
              (keys, full['notOpened'], [e['message'] for e in full['events']]))
        check('the sign-in page never became a page of the capture', all('login' not in k and 'signed-in' not in k for k in keys))

        # ---------------------------------------------------------------- the session runs out and single sign-on signs in again by itself
        sso = App(pages=12, expire_after=5, auto=True)
        url = serve(sso)
        job = g.api('captures', {'url': url + '/p/0', 'signIn': True, 'settings': settings})['id']
        g.wait(job, lambda j: j['status'] == 'WAITING')
        time.sleep(2)
        g.api('jobs/command', {'id': job, 'command': 'continue'})
        j = g.wait(job, finished)
        full = json.loads((data / 'jobs' / job / 'job.json').read_text())
        keys = sorted(p['key'] for p in full['pages'])
        waits = [e for e in full['events'] if 'sign in again' in e['message']]
        check('when single sign-on signs in again by itself, the page is opened again and none is missed',
              j['status'] == 'DONE' and keys == sorted(f'/p/{i}' for i in range(12)) and not waits and sso.next_sid >= 3, (keys, waits, sso.next_sid))

        # ---------------------------------------------------------------- the browser window is closed during a capture
        slow = App(pages=30, slow=0.4)
        url = serve(slow)
        job = g.api('captures', {'url': url + '/p/0', 'signIn': False, 'settings': settings})['id']
        g.wait(job, lambda j: j.get('pageCount', 0) >= 3)
        for pid in browsers_of(data):
            try:
                os.kill(pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
        j = g.wait(job, finished, 120)
        check('closing the browser window ends the capture with a clear message', j['status'] == 'FAILED' and 'browser window was closed' in j['message'], j['message'])
        check('the pages taken until then are kept in a package', j['files']['package'] and j['pageCount'] >= 3)

        # ---------------------------------------------------------------- Guardian is closed during a capture
        job = g.api('captures', {'url': url + '/p/0', 'signIn': False, 'settings': settings})['id']
        g.wait(job, lambda j: j.get('pageCount', 0) >= 3)
        g.stop(kill=True)
        for pid in browsers_of(data):
            try:
                os.kill(pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
        g = Guardian(data)
        j = g.api('jobs/' + job)
        check('after Guardian is closed and opened again, the capture is stopped and its pages are packaged',
              j['status'] == 'STOPPED' and j['files']['package'] and j['pageCount'] >= 3 and 'closed' in j['message'], j)
        check('nothing is reported as running', not any(r['active'] for r in g.api('jobs')))
        manifest_ok = (data / 'jobs' / job / 'guardian-package.json').exists()
        check('the package of an interrupted capture says it is incomplete', manifest_ok and
              not json.loads((data / 'jobs' / job / 'guardian-package.json').read_text())['complete'])

        # ---------------------------------------------------------------- a certificate the browser does not trust
        cert, key = Path(td) / 'c.pem', Path(td) / 'k.pem'
        subprocess.run(['openssl', 'req', '-x509', '-newkey', 'rsa:2048', '-nodes', '-keyout', str(key), '-out', str(cert), '-days', '2',
                        '-subj', '/CN=127.0.0.1'], check=True, capture_output=True)
        secure = serve(App(pages=3), tls=(str(cert), str(key)))
        job = g.api('captures', {'url': secure + '/p/0', 'signIn': False, 'settings': settings})['id']
        j = g.wait(job, lambda j: j['status'] == 'WAITING' or finished(j), 60)
        check('a certificate the browser does not trust: Guardian waits for you to accept it', j['status'] == 'WAITING' and 'certificate' in j['message'], j['message'])
        g.api('jobs/command', {'id': job, 'command': 'stop'})
        check('and can be stopped there', g.wait(job, finished, 30)['status'] == 'STOPPED')
        print('TOTAL', len(passed), 'checks passed')
    finally:
        try:
            g.stop()
        except Exception:
            pass
