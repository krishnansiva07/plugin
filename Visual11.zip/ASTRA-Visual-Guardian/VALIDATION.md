# Validation: release 5 (27 November 2026)

Tested from a clean unpack of the release package: `build.sh` built the sources, and the shipped `visual-guardian.jar`
ran the browser tests. The logs are in `validation/2026-11-27-r5/`.

**Environment:** Linux, OpenJDK 21 (the jar is compiled for Java 17), Google Chrome for Testing 153 in a visible
window on a virtual display (Xvfb), plus a hidden-browser run. `visual-guardian.jar` SHA-256:
`7187c969ac176168bbc9b1c0b93ffa1073eda3efc728bcd3734240c669c196ce`.

| Suite | Checks | Result |
|---|---|---|
| `tests/DiffChecks.java`: page keys, links never opened, risky menu buttons, address mapping, screenshot and text comparison, settings limits, file names, sign-in services | 43 | all passed |
| `tests/SkipChecks.java`: Pages to skip | 24 | all passed |
| `tests/simple_flow.py`: capture, package, upload, compare, report (real Chrome) | 54 | all passed |
| `tests/resilience.py`: session runs out, browser closed, Guardian closed, untrusted certificate (real Chrome) | 11 | all passed |
| Spring Boot sources: compile against the Servlet and Spring API signatures | | compiled |

## What the browser tests do

**`simple_flow.py`** runs two small web applications. The "old" one lives under `/app`; the "new" one lives under
`/portal` on another port. Both have a sign-in page, a navigation bar with links, a menu button without a link, and
a link without an address that has a click handler. They also have:

- 15 orders, of which only 3 are captured as similar pages
- links to sign out, to delete an order, to `deleteUser.do`, to a PDF and to another site
- an `/admin` page excluded by a skip rule
- a link that exists only inside a frame
- a page whose content scrolls inside a panel
- a clock hidden as an area to hide

The new system differs on purpose:

- one page has a new text and colour
- one order has a new total
- one page is gone (404)
- one page is new

Checked: every reachable page is captured exactly once, level by level. The menu button, the link inside the frame
and the scrolling panel are captured in full. None of the never-open links are requested from either system. The
package downloads with a clear name and uploads again, also after unzipping and zipping again. A package with paths
outside its folder, and a file that is not a ZIP, are refused.

In the comparison, started with the new address as a bare root:

- `/app` is matched to `/portal`
- the window size comes from the package
- the results are exactly 2 changed, 1 missing, 1 new and 12 unchanged
- the hidden clock causes no change
- the report is one HTML file with pictures and no scripts, listing the reasons and the text changes

A single-page application with `#/` routes is captured route by route. Signing in with a hidden browser is refused
with a clear message, and only one run is allowed at a time. Stop works while Guardian waits for sign-in. History and
deleting runs and packages also work.

**`resilience.py`:**

- **Session runs out:** Guardian pauses with "asked you to sign in again", then carries on without missing a page.
- **Single sign-on signs in again by itself:** no pause; the page is reopened and none is missed.
- **Browser window killed:** clear message, and the pages taken so far are packaged.
- **Guardian killed during a capture:** after a restart the job shows as stopped, its pages are packaged, the package
  says it is incomplete, and nothing shows as running.
- **Untrusted certificate:** Guardian pauses with the certificate message and can be stopped there.

## Not tested here

- **Your application.** Run a small capture first, for example with Maximum pages at 20, and look through **View
  screenshots**. Check that sign-in works, that the important menus are reached, and which areas need hiding.
- **Windows and Edge.** The Windows browser paths and `launch.cmd` are unchanged from earlier releases, but were not
  run here.
- **The Spring Boot jar.** Maven Central cannot be reached from the test machine, so `mvn package` was not run. The
  Spring sources were compiled against the API signatures only. Both versions pass every request to the same `Api`
  code, which the tests above cover through the plain jar.

## Running the tests yourself

```
build.sh                                          (or build.cmd)
javac --release 17 -cp build/classes -d build/test-classes tests/*.java
java -cp build/classes:build/test-classes guardian.DiffChecks
java -cp build/classes:build/test-classes guardian.SkipChecks
python3 tests/simple_flow.py build/visual-guardian.jar   (needs Python 3 and Chrome; on a server without a screen: xvfb-run -a python3 ...)
python3 tests/resilience.py build/visual-guardian.jar    (Linux or macOS: it uses pgrep; also needs openssl)
```

On Windows, use `;` instead of `:` between class paths. Set `GUARDIAN_TEST_BROWSER` to the path of `chrome.exe`
or `msedge.exe` when it is not at `/usr/bin/google-chrome`.
