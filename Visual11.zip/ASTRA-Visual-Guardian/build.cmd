@echo off
setlocal
cd /d "%~dp0"
where javac >nul 2>nul || (echo Java JDK 17 or newer is required. & exit /b 1)
if exist build\classes rmdir /s /q build\classes
mkdir build\classes
(for %%f in (src\guardian\*.java) do @echo src/guardian/%%~nxf) > build\sources.txt
javac --release 17 -encoding UTF-8 -d build\classes @build\sources.txt
if errorlevel 1 exit /b 1
copy /Y resources\* build\classes\ >nul
jar --create --file build\visual-guardian.jar --main-class guardian.Main -C build\classes .
if errorlevel 1 exit /b 1
echo Built build\visual-guardian.jar
