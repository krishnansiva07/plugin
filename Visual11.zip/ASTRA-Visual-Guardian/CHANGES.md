# Changes

## Release 5 (27 November 2026): screenshots of every page, a package, and a comparison report

Guardian is now what it was meant to be, and nothing more:

1. **Capture:** open every page of the application once and take a screenshot of each, then download the package.
2. **Compare:** after the migration or deployment, open the same pages on the new system and get an HTML report of
   the pages that changed, are missing or are new.

**Removed**, because they made Guardian a functional-testing tool:

- clicking every control and replaying recorded click paths
- locators and "states"
- coverage review and approval of baselines
- AI models (Agent, Vision, Reviewer) and their settings
- exploration orders
- suites
- the Excel report

The Engine, Exploration, Coverage, Store and Models classes are gone, along with their tests.

**New:**

- A capture opens pages by their address, level by level, each page once. It follows links (also inside frames) and
  clicks menu buttons only. Links that sign out, download files or look like actions are never opened, including
  Struts-style `deleteUser.do` and `?action=remove`. Only 10 pages of each kind (`/invoices/{id}`) are captured.
- Steadier screenshots: fixed page size, animations finished, text cursor and scroll bars hidden, lazy images loaded,
  and pages that scroll inside a panel captured in full.
- The package: a ZIP with one screenshot and one text file per page, a manifest, and a gallery (`index.html`) to look
  through. A package that was unzipped and zipped again is accepted.
- The comparison matches pages when the application moved to another server or path (`/app` → `/portal`). It
  compares pictures, visible text and titles, and finds missing pages (errors, redirects to other pages) and new
  pages.
- The report is one HTML file with the pictures inside it and no scripts. For each page it shows why it is listed,
  the old and new addresses, Changes, Before and After pictures, and the text that was added and removed.
- Sign-in: Guardian pauses for you at the start (SSO, PIN, smart card, certificate). It pauses again when the session
  runs out, and simply reopens the page when single sign-on signs you in again by itself. It also pauses for an
  untrusted certificate.
- A closed browser window or a closed Guardian keeps what was taken: the package or report is still written.
- The UI has three tabs (Capture, Compare, History), a status card with Continue and Stop, the latest screenshots, and
  buttons to download the package or open the report. It remembers your settings.
- Spring Boot: one controller passes every request to the same API as the plain jar.

**Also fixed:** whole numbers in saved files were read back as decimals (a Java ternary turned `Long` into `Double`).

**Compatibility:** baselines and runs from releases 1 to 4 cannot be compared with this release: capture again. The
data folder can stay; old runs are not shown.

## Earlier releases (summary)

- **Release 4 (26 November 2026):** page-by-page exploration that went back instead of starting over, and fewer
  repeated navigations.
- **Release 3 (26 November 2026):**
  - AI connection test with clearer errors
  - Pages to skip
  - Spring Boot front door
  - ARCHITECTURE.md
- **Releases 1 and 2 (25 and 26 November 2026):**
  - sign-in detection that no longer misfired
  - redirects within the same application accepted
  - a limit on sign-in retries
  - faster saving
  - more reliable locators for controls that share a label

Pages to skip and the Spring Boot front door carry on in release 5.
