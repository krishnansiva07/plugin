package com.formatflow.ai.service;

import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Service;

@Service
public class SessionKeyService {

    private static final String SESSION_KEY = "FORMATFLOW_LLM_API_KEY";
    private static final String SESSION_ENDPOINT = "FORMATFLOW_LLM_ENDPOINT";
    private static final String SESSION_MODEL = "FORMATFLOW_LLM_MODEL";

    public void store(HttpSession session, String apiKey, String endpoint, String model) {
        session.setAttribute(SESSION_KEY, apiKey);
        session.setAttribute(SESSION_ENDPOINT, endpoint);
        session.setAttribute(SESSION_MODEL, model);
    }

    public String require(HttpSession session) {
        return requireConnection(session).apiKey();
    }

    public ConnectionSettings requireConnection(HttpSession session) {
        if (session == null) {
            throw new IllegalStateException("LLM session is not connected.");
        }
        Object keyValue = session.getAttribute(SESSION_KEY);
        Object endpointValue = session.getAttribute(SESSION_ENDPOINT);
        Object modelValue = session.getAttribute(SESSION_MODEL);
        if (!(keyValue instanceof String key) || key.isBlank()
                || !(endpointValue instanceof String endpoint) || endpoint.isBlank()
                || !(modelValue instanceof String model) || model.isBlank()) {
            throw new IllegalStateException("LLM session is not connected.");
        }
        return new ConnectionSettings(key, endpoint, model);
    }

    public boolean isConnected(HttpSession session) {
        if (session == null) return false;
        Object key = session.getAttribute(SESSION_KEY);
        Object endpoint = session.getAttribute(SESSION_ENDPOINT);
        Object model = session.getAttribute(SESSION_MODEL);
        return key instanceof String k && !k.isBlank()
                && endpoint instanceof String e && !e.isBlank()
                && model instanceof String m && !m.isBlank();
    }

    public void clear(HttpSession session) {
        if (session != null) {
            session.removeAttribute(SESSION_KEY);
            session.removeAttribute(SESSION_ENDPOINT);
            session.removeAttribute(SESSION_MODEL);
        }
    }

    public record ConnectionSettings(String apiKey, String endpoint, String model) {}
}
