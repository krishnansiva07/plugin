package com.formatflow.ai.web;

import com.formatflow.ai.config.LlmProperties;
import com.formatflow.ai.model.SessionModels.SessionStatus;
import com.formatflow.ai.model.SessionModels.ValidateKeyRequest;
import com.formatflow.ai.model.SessionModels.ValidateKeyResponse;
import com.formatflow.ai.service.LlmClient;
import com.formatflow.ai.service.SessionKeyService;
import com.formatflow.ai.service.SessionKeyService.ConnectionSettings;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/session")
public class SessionController {

    private final LlmClient llmClient;
    private final SessionKeyService sessionKeyService;
    private final LlmProperties properties;

    public SessionController(LlmClient llmClient,
                             SessionKeyService sessionKeyService,
                             LlmProperties properties) {
        this.llmClient = llmClient;
        this.sessionKeyService = sessionKeyService;
        this.properties = properties;
    }

    @GetMapping("/status")
    public SessionStatus status(HttpServletRequest request) {
        return statusOf(request.getSession(false));
    }

    @PostMapping("/validate")
    public ValidateKeyResponse validate(@Valid @RequestBody ValidateKeyRequest request,
                                        HttpServletRequest servletRequest) {
        String model = request.model() == null ? "" : request.model().trim();
        LlmClient.ValidationResult validation = llmClient.validateConnection(
                request.apiKey(), request.endpoint(), model
        );

        if (!validation.valid()) {
            return new ValidateKeyResponse(false, validation.message(), statusOf(servletRequest.getSession(false)));
        }

        String endpoint = LlmClient.normalizeEndpoint(request.endpoint());
        HttpSession session = servletRequest.getSession(true);
        sessionKeyService.store(session, request.apiKey(), endpoint, model);
        return new ValidateKeyResponse(true, validation.message(), statusOf(session));
    }

    @PostMapping("/disconnect")
    public SessionStatus disconnect(HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        if (session != null) {
            sessionKeyService.clear(session);
            session.invalidate();
        }
        return defaultStatus(false);
    }

    private SessionStatus statusOf(HttpSession session) {
        if (sessionKeyService.isConnected(session)) {
            ConnectionSettings settings = sessionKeyService.requireConnection(session);
            return new SessionStatus(true, settings.model(), settings.endpoint());
        }
        return defaultStatus(false);
    }

    private SessionStatus defaultStatus(boolean connected) {
        return new SessionStatus(
                connected,
                properties.getModel() == null ? "" : properties.getModel(),
                properties.getBaseUrl() == null ? "" : properties.getBaseUrl()
        );
    }
}
