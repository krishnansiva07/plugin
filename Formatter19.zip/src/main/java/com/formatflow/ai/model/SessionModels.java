package com.formatflow.ai.model;

import jakarta.validation.constraints.NotBlank;

public final class SessionModels {

    private SessionModels() {}

    public record ValidateKeyRequest(
            @NotBlank String endpoint,
            @NotBlank String model,
            @NotBlank String apiKey
    ) {}

    public record SessionStatus(
            boolean connected,
            String model,
            String endpoint
    ) {}

    public record ValidateKeyResponse(
            boolean valid,
            String message,
            SessionStatus session
    ) {}
}
