package com.astra.mcp.service;

import com.astra.mcp.dto.AgentRequest;
import com.astra.mcp.dto.AgentResponse;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import dev.langchain4j.model.chat.ChatLanguageModel;
import org.springframework.stereotype.Service;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

@Service
public class AstraAgentService {

    private static final Set<String> ALLOWED_TOOLS = Set.of(
            "browser_click",
            "browser_double_click",
            "browser_type",
            "browser_select_option",
            "browser_press_key",
            "browser_wait_for",
            "browser_handle_dialog",
            "browser_evaluate"
    );

    private final ChatLanguageModel llm;
    private final McpClientService mcpClient;
    private final CommandService commandService;
    private final ObjectMapper objectMapper = new ObjectMapper();

    public AstraAgentService(ChatLanguageModel llm,
                             McpProcessService ignored,
                             McpClientService mcpClient,
                             CommandService commandService) {
        this.llm = llm;
        this.mcpClient = mcpClient;
        this.commandService = commandService;
    }

    public synchronized AgentResponse run(AgentRequest request) {
        AgentResponse response = new AgentResponse();
        response.status = "RUNNING";

        try {
            applyDefaults(request);
            Map<String, Object> testData = parseJsonObject(request.testDataJson);

            List<String> heuristicMissing = detectObviousMissingData(request, testData);
            if (!heuristicMissing.isEmpty()) {
                return missingDataResponse(response, "Required test data is missing before browser execution.", heuristicMissing);
            }

            if (request.generatePlan) {
                Map<String, Object> plan = createExecutionPlan(request, testData);
                response.planStatus = stringValue(plan.getOrDefault("planStatus", "CREATED"));
                response.executionPlan = asMapList(plan.get("steps"));
                List<String> planMissing = asStringList(plan.get("missingData"));
                if (!planMissing.isEmpty()) {
                    return missingDataResponse(response, "Required test data is missing from the execution plan.", planMissing);
                }
            } else {
                response.planStatus = "SKIPPED";
            }

            mcpClient.start(request.ignoreHttpsErrors, request.userDataDir);
            mcpClient.initialize();

            Map<String, Object> navigateResult = callToolAndFailFast("browser_navigate", Map.of("url", request.applicationUrl));
            addTrace(response, 0, "browser_navigate", Map.of("url", request.applicationUrl), "Open application", 100, navigateResult);
            sleep(request.liveActionDelayMs);

            if (request.manualAssistBeforeRun && request.manualAssistWaitSeconds > 0) {
                sleep(request.manualAssistWaitSeconds * 1000);
            }

            String snapshot = snapshotWithRetry();
            boolean goalReached = false;

            for (int step = 1; step <= request.maxAgentSteps; step++) {
                if (expectedLooksVisible(request.expectedResult, snapshot, response.actionTrace)) {
                    goalReached = true;
                    response.message = "Expected result appears to be visible.";
                    break;
                }

                String llmDecision = llm.generate(decisionPrompt(request, snapshot, testData, compactTrace(response.actionTrace), response.executionPlan));
                Map<String, Object> decision = parseJsonObject(llmDecision);

                List<String> missingData = asStringList(decision.get("missingData"));
                if (!missingData.isEmpty()) {
                    response.finalSnapshot = compactSnapshot(snapshot);
                    return missingDataResponse(response, "Required test data is missing. Agent stopped without guessing.", missingData);
                }

                if (asBoolean(decision.get("done"))) {
                    goalReached = true;
                    response.message = stringValue(decision.getOrDefault("reason", "LLM marked scenario as done."));
                    break;
                }

                String toolName = stringValue(decision.get("toolName"));
                if (!ALLOWED_TOOLS.contains(toolName)) {
                    response.status = "BLOCKED";
                    response.message = "LLM returned unsupported tool: " + toolName;
                    response.finalSnapshot = compactSnapshot(snapshot);
                    return response;
                }

                int confidence = asInt(decision.get("confidence"), 100);
                if (confidence < request.minActionConfidence) {
                    response.status = "BLOCKED_LOW_CONFIDENCE";
                    response.message = "Agent stopped because action confidence was " + confidence + " below threshold " + request.minActionConfidence + ".";
                    response.finalSnapshot = compactSnapshot(snapshot);
                    return response;
                }

                Map<String, Object> toolArguments = sanitizeToolArguments(asMap(decision.get("arguments")), testData);
                if (requiresTarget(toolName) && isBlank(stringValue(toolArguments.get("target")))) {
                    response.status = "BLOCKED";
                    response.message = "Missing MCP target/ref for tool: " + toolName + ". Agent stopped instead of guessing.";
                    response.finalSnapshot = compactSnapshot(snapshot);
                    return response;
                }

                Map<String, Object> toolResult = executeToolWithRecovery(toolName, toolArguments, request.liveActionDelayMs);
                addTrace(response, step, toolName, toolArguments, stringValue(decision.get("reason")), confidence, toolResult);

                if (mcpClient.isError(toolResult)) {
                    response.status = "ERROR";
                    response.message = "MCP tool call failed at step " + step + ": " + toolResult;
                    response.finalSnapshot = compactSnapshot(snapshot);
                    return response;
                }

                sleep(request.liveActionDelayMs);
                String newSnapshot = snapshotWithRetry();
                if (looksSameSnapshot(snapshot, newSnapshot) && toolName.startsWith("browser_click")) {
                    Map<String, Object> replanned = replanAfterNoChange(request, newSnapshot, testData, compactTrace(response.actionTrace));
                    response.rawLog = "Replan after no visible page change: " + replanned;
                }
                snapshot = newSnapshot;
            }

            response.finalSnapshot = compactSnapshot(snapshot);
            if (!goalReached) {
                response.message = "Max agent steps reached. Code generated from executed trace; live goal was not conclusively reached.";
            }

            response.generatedCode = cleanCode(llm.generate(codePrompt(request, response.actionTrace, response.finalSnapshot)));

            if (request.saveToProject) {
                response.savedFilePath = saveGeneratedCode(request, response.generatedCode);
            }

            if (request.validateGeneratedCode && response.savedFilePath != null) {
                validateGeneratedCode(request, response);
            } else {
                response.validationStatus = "NOT_REQUESTED";
            }

            if (request.closeBrowserAfterRun) {
                mcpClient.tool("browser_close", Map.of());
            }

            if (response.validationStatus != null && response.validationStatus.startsWith("PASSED")) {
                response.status = "SUCCESS";
            } else if (goalReached) {
                response.status = "LIVE_FLOW_COMPLETED";
            } else {
                response.status = "GENERATED_REVIEW_REQUIRED";
            }

            return response;
        } catch (Exception e) {
            response.status = "ERROR";
            response.message = e.getMessage();
            return response;
        }
    }

    private Map<String, Object> createExecutionPlan(AgentRequest request, Map<String, Object> testData) throws Exception {
        String raw = llm.generate(planPrompt(request, testData));
        Map<String, Object> plan = parseJsonObject(raw);
        if (plan.isEmpty()) {
            plan.put("planStatus", "FALLBACK_HEURISTIC_PLAN");
            plan.put("missingData", List.of());
            plan.put("steps", List.of(Map.of("step", 1, "goal", request.scenario == null ? "Execute scenario" : request.scenario)));
        }
        return plan;
    }

    private String planPrompt(AgentRequest request, Map<String, Object> testData) throws Exception {
        return """
                You are a senior test automation architect.
                Create a safe execution plan before browser automation starts.
                Return ONLY valid JSON. No markdown.

                Scenario:
                %s

                Expected Result:
                %s

                Test Data JSON:
                %s

                Pre-action Instructions:
                %s

                Rules:
                1. Do not invent data.
                2. If required data is missing, add keys to missingData.
                3. Keep steps high-level, short, and ordered.
                4. Include assertion step at the end.

                JSON shape:
                {"planStatus":"CREATED","missingData":[],"steps":[{"step":1,"goal":"...","dataKeys":["username"]}]}
                """.formatted(
                safe(request.scenario),
                safe(request.expectedResult),
                objectMapper.writeValueAsString(testData),
                safe(request.preActionInstructions)
        );
    }

    private String decisionPrompt(AgentRequest request,
                                  String snapshot,
                                  Map<String, Object> testData,
                                  List<Map<String, Object>> compactTrace,
                                  List<Map<String, Object>> plan) throws Exception {
        return """
                You are an AI browser automation controller using Playwright MCP.
                Return ONLY valid JSON. No markdown. No explanation outside JSON.

                Goal:
                %s

                Expected Result:
                %s

                Test Data JSON:
                %s

                Pre-action Instructions:
                %s

                Execution Plan:
                %s

                Compact trace already executed in the SAME browser session:
                %s

                Current visible MCP snapshot, trimmed:
                %s

                CRITICAL RULES:
                1. Return only ONE next browser action.
                2. Follow the execution plan in order unless the current page clearly requires re-planning.
                3. Do not restart browser. Do not navigate again unless current page is wrong.
                4. Do not use browser_close.
                5. Use only tools: browser_click, browser_double_click, browser_type, browser_select_option, browser_press_key, browser_wait_for, browser_handle_dialog. Do not use browser_evaluate yourself; Java uses it only for controlled recovery.
                6. For clickable/typeable elements use argument name "target" with the MCP ref value, example:
                   {"element":"Username textbox","target":"e11","text":"standard_user"}
                7. Never invent username, password, amount, date, OTP, transaction id, account number, or business data.
                8. Prefer text values from test data. If using a test-data value, use actual value in the text argument.
                9. If needed data is missing, return exactly: {"done":false,"missingData":["password"]}
                10. If expected result is visible in snapshot, return exactly: {"done":true,"reason":"Expected result is visible","confidence":100}
                11. For login flows, keep sequence in the same page: username -> password -> login/sign in -> verify landing page.
                12. Choose the most specific visible element. Add confidence 0-100.
                13. If a table/grid row needs selection, prefer clicking the exact cell/text/link inside the row when visible, not the broad row container.
                14. If a toast, loading overlay, modal, or spinner is visible, wait for it to disappear before clicking the target.
                15. If the correct action is uncertain, return a low confidence value instead of guessing.

                JSON response shape for action:
                {"done":false,"toolName":"browser_type","arguments":{"element":"...","target":"e11","text":"..."},"confidence":95,"reason":"..."}
                """.formatted(
                safe(request.scenario),
                safe(request.expectedResult),
                objectMapper.writeValueAsString(testData),
                safe(request.preActionInstructions),
                objectMapper.writeValueAsString(plan),
                objectMapper.writeValueAsString(compactTrace),
                compactSnapshot(snapshot)
        );
    }

    private Map<String, Object> replanAfterNoChange(AgentRequest request, String snapshot, Map<String, Object> testData, List<Map<String, Object>> trace) throws Exception {
        String raw = llm.generate("""
                The last browser action did not visibly change the page.
                Return ONLY JSON with either an alternateActionSummary or stopReason.
                Scenario: %s
                Expected: %s
                Test Data: %s
                Trace: %s
                Snapshot: %s
                JSON shape: {"alternateActionSummary":"...","stopReason":""}
                """.formatted(
                safe(request.scenario),
                safe(request.expectedResult),
                objectMapper.writeValueAsString(testData),
                objectMapper.writeValueAsString(trace),
                compactSnapshot(snapshot)
        ));
        return parseJsonObject(raw);
    }

    private void validateGeneratedCode(AgentRequest request, AgentResponse response) throws Exception {
        if (!"PLAYWRIGHT_TYPESCRIPT".equals(request.targetFramework)
                && !"PLAYWRIGHT_JAVASCRIPT".equals(request.targetFramework)) {
            response.validationStatus = "SKIPPED_UNSUPPORTED_RUNNER";
            return;
        }

        File projectDirectory = new File(request.projectPath);
        List<String> command = new ArrayList<>();
        command.add("cmd.exe");
        command.add("/c");
        command.add("npx.cmd");
        command.add("playwright");
        command.add("test");
        command.add(request.testFileName);
        if (request.headed) {
            command.add("--headed");
        }

        String output = commandService.run(command, projectDirectory, 240);
        response.validationOutput = output;

        if (output.contains("EXIT_CODE=0")) {
            response.validationStatus = "PASSED";
            return;
        }

        if (!request.autoRepair) {
            response.validationStatus = "FAILED";
            return;
        }

        for (int attempt = 1; attempt <= Math.max(1, request.maxRepairAttempts); attempt++) {
            String repairedCode = cleanCode(llm.generate(repairPrompt(request, response.generatedCode, output, response.actionTrace)));
            Files.writeString(Paths.get(response.savedFilePath), repairedCode);
            response.generatedCode = repairedCode;

            Map<String, Object> repair = new LinkedHashMap<>();
            repair.put("attempt", attempt);
            repair.put("previousOutput", output);
            response.repairHistory.add(repair);

            output = commandService.run(command, projectDirectory, 240);
            response.validationOutput = output;

            if (output.contains("EXIT_CODE=0")) {
                response.validationStatus = "PASSED_AFTER_REPAIR_" + attempt;
                return;
            }
        }

        response.validationStatus = "FAILED_AFTER_REPAIR";
    }

    private String codePrompt(AgentRequest request,
                              List<Map<String, Object>> trace,
                              String snapshot) throws Exception {
        return """
                Generate production-ready automation code for target framework: %s
                Return ONLY code. No markdown.

                Use ONLY this executed action trace and final snapshot. Do not invent selectors.
                Prefer stable locators: role, label, placeholder, text, test id. Avoid brittle XPath unless no option.
                Add meaningful assertions from expected result and final snapshot.

                Application URL: %s
                Scenario: %s
                Test Data JSON: %s
                Expected Result: %s

                Executed trace:
                %s

                Final snapshot summary:
                %s
                """.formatted(
                safe(request.targetFramework),
                safe(request.applicationUrl),
                safe(request.scenario),
                safe(request.testDataJson),
                safe(request.expectedResult),
                objectMapper.writeValueAsString(trace),
                safe(snapshot)
        );
    }

    private String repairPrompt(AgentRequest request,
                                String code,
                                String error,
                                List<Map<String, Object>> trace) throws Exception {
        return """
                Repair this automation code for framework: %s
                Return ONLY the full corrected code. No markdown.

                Validation failure output:
                %s

                Current code:
                %s

                Executed MCP trace:
                %s
                """.formatted(
                safe(request.targetFramework),
                safe(error),
                safe(code),
                objectMapper.writeValueAsString(trace)
        );
    }

    private AgentResponse missingDataResponse(AgentResponse response, String message, List<String> missing) {
        response.status = "MISSING_TEST_DATA";
        response.message = message;
        response.missingData.addAll(missing);
        return response;
    }

    private Map<String, Object> callToolAndFailFast(String tool, Map<String, Object> args) {
        Map<String, Object> result = mcpClient.tool(tool, args);
        if (mcpClient.isError(result)) {
            throw new RuntimeException("MCP tool failed: " + tool + " -> " + result);
        }
        return result;
    }


    private Map<String, Object> executeToolWithRecovery(String toolName, Map<String, Object> toolArguments, int actionDelayMs) {
        Map<String, Object> result = mcpClient.tool(toolName, toolArguments);
        if (!mcpClient.isError(result)) {
            return result;
        }

        if (!isRecoverableClickProblem(toolName, result)) {
            return result;
        }

        List<Map<String, Object>> recoveryAttempts = new ArrayList<>();
        recoveryAttempts.add(Map.of("attempt", "initial", "result", result));

        // Many enterprise apps keep a temporary overlay/toast/spinner above the target.
        // First try the safest recovery: Escape + wait + retry same MCP click.
        Map<String, Object> escapeResult = mcpClient.tool("browser_press_key", Map.of("key", "Escape"));
        recoveryAttempts.add(Map.of("attempt", "press_escape", "result", escapeResult));
        sleep(Math.max(800, actionDelayMs));

        Map<String, Object> waitResult = mcpClient.tool("browser_wait_for", Map.of("time", 1));
        recoveryAttempts.add(Map.of("attempt", "short_wait", "result", waitResult));

        result = mcpClient.tool(toolName, toolArguments);
        if (!mcpClient.isError(result)) {
            Map<String, Object> recovered = new LinkedHashMap<>(result);
            recovered.put("astraRecovery", recoveryAttempts);
            recovered.put("astraRecoveryStatus", "RECOVERED_AFTER_ESCAPE_AND_WAIT");
            return recovered;
        }
        recoveryAttempts.add(Map.of("attempt", "retry_after_escape", "result", result));

        // Last resort for known invisible overlay interception issues.
        // This is intentionally limited to common overlay containers and does not change the app data.
        Map<String, Object> overlayPatch = mcpClient.tool("browser_evaluate", Map.of(
                "function", "() => { const selectors = ['.v-overlay-container', '.v-overlay', '[id$=\\'-overlays\\']', '[id*=\\'overlays\\']', '.modal-backdrop', '.cdk-overlay-container', '.cdk-overlay-backdrop', '.toast', '.slds-backdrop']; let changed = 0; for (const sel of selectors) { document.querySelectorAll(sel).forEach(el => { const rect = el.getBoundingClientRect(); const style = window.getComputedStyle(el); if (style.pointerEvents !== 'none' && rect.width > 0 && rect.height > 0) { el.setAttribute('data-astra-pointer-events-original', style.pointerEvents); el.style.pointerEvents = 'none'; changed++; } }); } return {changed}; }"
        ));
        recoveryAttempts.add(Map.of("attempt", "disable_known_overlay_pointer_events", "result", overlayPatch));
        sleep(300);

        result = mcpClient.tool(toolName, toolArguments);
        if (!mcpClient.isError(result)) {
            Map<String, Object> recovered = new LinkedHashMap<>(result);
            recovered.put("astraRecovery", recoveryAttempts);
            recovered.put("astraRecoveryStatus", "RECOVERED_AFTER_OVERLAY_POINTER_EVENTS_PATCH");
            return recovered;
        }

        Map<String, Object> failed = new LinkedHashMap<>(result);
        failed.put("astraRecovery", recoveryAttempts);
        failed.put("astraRecoveryStatus", "FAILED_AFTER_RECOVERY_ATTEMPTS");
        return failed;
    }

    private boolean isRecoverableClickProblem(String toolName, Map<String, Object> result) {
        if (!"browser_click".equals(toolName) && !"browser_double_click".equals(toolName)) {
            return false;
        }
        String text = stripAnsi(String.valueOf(result)).toLowerCase();
        return text.contains("timeout")
                || text.contains("intercepts pointer events")
                || text.contains("element is not visible")
                || text.contains("not stable")
                || text.contains("not enabled")
                || text.contains("receives pointer events");
    }

    private String stripAnsi(String value) {
        if (value == null) {
            return "";
        }
        return value.replaceAll("\\u001B\\[[;\\d]*m", "")
                .replace("\\u001b", "")
                .replace("\\033", "");
    }

    private String snapshotWithRetry() {
        Map<String, Object> result = mcpClient.tool("browser_snapshot", Map.of());
        if (mcpClient.isError(result)) {
            sleep(500);
            result = mcpClient.tool("browser_snapshot", Map.of());
        }
        return String.valueOf(result);
    }

    private String saveGeneratedCode(AgentRequest request, String code) throws Exception {
        if (isBlank(request.projectPath)) {
            throw new RuntimeException("Project path is required when Save to project is enabled.");
        }
        String fileName = isBlank(request.testFileName) ? defaultFileName(request.targetFramework) : request.testFileName;
        Path testDirectory = Paths.get(request.projectPath, "tests");
        Files.createDirectories(testDirectory);
        Path outputFile = testDirectory.resolve(fileName);
        Files.writeString(outputFile, code);
        return outputFile.toString();
    }

    private String defaultFileName(String framework) {
        if ("PLAYWRIGHT_JAVASCRIPT".equals(framework) || "CYPRESS_JAVASCRIPT".equals(framework)) {
            return "astra-generated.spec.js";
        }
        if ("PLAYWRIGHT_PYTHON_PYTEST".equals(framework)) {
            return "test_astra_generated.py";
        }
        if ("PLAYWRIGHT_JAVA_JUNIT".equals(framework) || "PLAYWRIGHT_JAVA_TESTNG".equals(framework)
                || "SELENIUM_JAVA_TESTNG".equals(framework) || "SELENIUM_JAVA_CUCUMBER".equals(framework)) {
            return "AstraGeneratedTest.java";
        }
        if ("PLAYWRIGHT_DOTNET_NUNIT".equals(framework)) {
            return "AstraGeneratedTest.cs";
        }
        return "astra-generated.spec.ts";
    }

    private List<String> detectObviousMissingData(AgentRequest request, Map<String, Object> data) {
        List<String> missing = new ArrayList<>();
        String scenario = (safe(request.scenario) + " " + safe(request.expectedResult)).toLowerCase();
        if (scenario.contains("login") || scenario.contains("sign in") || scenario.contains("signin")) {
            if (!hasAnyKey(data, "username", "user", "userName", "userid", "userId", "email")) {
                missing.add("username");
            }
            if (!hasAnyKey(data, "password", "passcode")) {
                missing.add("password");
            }
        }
        if ((scenario.contains("otp") || scenario.contains("one time password")) && !hasAnyKey(data, "otp", "oneTimePassword")) {
            missing.add("otp");
        }
        if (scenario.contains("transaction") && scenario.contains("id") && !hasAnyKey(data, "transactionId", "txnId", "paymentId")) {
            missing.add("transactionId");
        }
        return missing;
    }

    private boolean hasAnyKey(Map<String, Object> data, String... keys) {
        for (String key : keys) {
            if (data.containsKey(key)) {
                return true;
            }
        }
        return false;
    }

    private boolean expectedLooksVisible(String expectedResult, String snapshot, List<Map<String, Object>> trace) {
        if (isBlank(expectedResult) || isBlank(snapshot)) {
            return false;
        }
        String lowerSnapshot = snapshot.toLowerCase();
        String[] tokens = expectedResult.toLowerCase().replaceAll("[^a-z0-9 ]", " ").split("\\s+");
        int useful = 0;
        int matched = 0;
        for (String token : tokens) {
            if (token.length() < 4 || Set.of("should", "visible", "displayed", "verify", "page", "shown").contains(token)) {
                continue;
            }
            useful++;
            if (lowerSnapshot.contains(token)) {
                matched++;
            }
        }
        return useful > 0 && matched >= Math.min(useful, 2) && trace.size() > 1;
    }

    private boolean looksSameSnapshot(String before, String after) {
        String b = compactSnapshot(before).replaceAll("\\s+", " ");
        String a = compactSnapshot(after).replaceAll("\\s+", " ");
        if (b.isBlank() || a.isBlank()) {
            return false;
        }
        int max = Math.max(b.length(), a.length());
        int min = Math.min(b.length(), a.length());
        return max > 0 && ((double) min / (double) max) > 0.95 && b.substring(0, Math.min(500, b.length())).equals(a.substring(0, Math.min(500, a.length())));
    }

    private List<Map<String, Object>> compactTrace(List<Map<String, Object>> trace) {
        int from = Math.max(0, trace.size() - 6);
        List<Map<String, Object>> compact = new ArrayList<>();
        for (Map<String, Object> item : trace.subList(from, trace.size())) {
            Map<String, Object> small = new LinkedHashMap<>();
            small.put("step", item.get("step"));
            small.put("tool", item.get("tool"));
            small.put("arguments", item.get("arguments"));
            small.put("reason", item.get("reason"));
            small.put("confidence", item.get("confidence"));
            compact.add(small);
        }
        return compact;
    }

    private String compactSnapshot(String snapshot) {
        if (snapshot == null) {
            return "";
        }
        String[] lines = snapshot.split("\\R");
        StringBuilder out = new StringBuilder();
        int count = 0;
        for (String line : lines) {
            String l = line.toLowerCase();
            if (l.contains("button") || l.contains("textbox") || l.contains("input") || l.contains("combobox")
                    || l.contains("checkbox") || l.contains("radio") || l.contains("link") || l.contains("heading")
                    || l.contains("ref=") || l.contains("products") || l.contains("dashboard") || l.contains("error")
                    || l.contains("alert") || l.contains("dialog") || l.contains("table") || l.contains("row")) {
                out.append(line).append('\n');
                count++;
            }
            if (count > 180) {
                out.append("...snapshot trimmed...");
                break;
            }
        }
        if (out.length() == 0) {
            return snapshot.length() > 9000 ? snapshot.substring(0, 9000) + "...trimmed..." : snapshot;
        }
        return out.toString();
    }

    private void addTrace(AgentResponse response, int step, String tool, Map<String, Object> args, String reason, int confidence, Map<String, Object> result) {
        Map<String, Object> trace = new LinkedHashMap<>();
        trace.put("step", step);
        trace.put("tool", tool);
        trace.put("arguments", args);
        trace.put("reason", reason);
        trace.put("confidence", confidence);
        trace.put("result", result);
        response.actionTrace.add(trace);
    }

    private Map<String, Object> sanitizeToolArguments(Map<String, Object> args, Map<String, Object> testData) {
        Map<String, Object> out = new LinkedHashMap<>(args);
        if (!out.containsKey("target") && out.containsKey("ref")) {
            out.put("target", out.remove("ref"));
        }
        Object text = out.get("text");
        if (text instanceof String s && s.startsWith("testData.")) {
            String key = s.substring("testData.".length());
            if (!testData.containsKey(key)) {
                throw new RuntimeException("LLM requested missing test data key: " + key);
            }
            out.put("text", String.valueOf(testData.get(key)));
        }
        if (out.containsKey("value") && !out.containsKey("values")) {
            out.put("values", List.of(String.valueOf(out.remove("value"))));
        }
        return out;
    }

    private boolean requiresTarget(String toolName) {
        return toolName.equals("browser_click") || toolName.equals("browser_type")
                || toolName.equals("browser_select_option");
    }

    private Map<String, Object> parseJsonObject(String text) {
        try {
            if (isBlank(text)) {
                return new LinkedHashMap<>();
            }
            String cleaned = stripMarkdownCodeFence(text);
            int start = cleaned.indexOf('{');
            int end = cleaned.lastIndexOf('}');
            if (start >= 0 && end > start) {
                cleaned = cleaned.substring(start, end + 1);
            }
            return objectMapper.readValue(cleaned, new TypeReference<Map<String, Object>>() {});
        } catch (Exception e) {
            return new LinkedHashMap<>();
        }
    }

    private Map<String, Object> asMap(Object value) {
        if (value instanceof Map<?, ?> map) {
            Map<String, Object> result = new LinkedHashMap<>();
            for (Map.Entry<?, ?> entry : map.entrySet()) {
                result.put(String.valueOf(entry.getKey()), entry.getValue());
            }
            return result;
        }
        return new LinkedHashMap<>();
    }

    private List<Map<String, Object>> asMapList(Object value) {
        List<Map<String, Object>> result = new ArrayList<>();
        if (value instanceof List<?> list) {
            for (Object item : list) {
                result.add(asMap(item));
            }
        }
        return result;
    }

    private List<String> asStringList(Object value) {
        List<String> result = new ArrayList<>();
        if (value instanceof List<?> list) {
            for (Object item : list) {
                result.add(String.valueOf(item));
            }
        } else if (value instanceof String text && !text.isBlank()) {
            result.add(text);
        }
        return result;
    }

    private boolean asBoolean(Object value) {
        if (value instanceof Boolean b) {
            return b;
        }
        return Boolean.parseBoolean(String.valueOf(value));
    }

    private int asInt(Object value, int defaultValue) {
        if (value instanceof Number number) {
            return number.intValue();
        }
        try {
            return Integer.parseInt(String.valueOf(value));
        } catch (Exception e) {
            return defaultValue;
        }
    }

    private String cleanCode(String code) {
        return stripMarkdownCodeFence(code).trim();
    }

    private String stripMarkdownCodeFence(String text) {
        if (text == null) {
            return "";
        }
        return text
                .replace("```typescript", "")
                .replace("```ts", "")
                .replace("```javascript", "")
                .replace("```js", "")
                .replace("```java", "")
                .replace("```python", "")
                .replace("```csharp", "")
                .replace("```", "")
                .trim();
    }

    private void applyDefaults(AgentRequest request) {
        if (request.maxAgentSteps <= 0) request.maxAgentSteps = 12;
        if (request.liveActionDelayMs < 0) request.liveActionDelayMs = 1200;
        if (request.minActionConfidence <= 0) request.minActionConfidence = 60;
        if (isBlank(request.targetFramework)) request.targetFramework = "PLAYWRIGHT_TYPESCRIPT";
        if (isBlank(request.testFileName)) request.testFileName = defaultFileName(request.targetFramework);
        if (isBlank(request.userDataDir)) request.userDataDir = "C:/Temp/astra-mcp-profile";
    }

    private void sleep(int milliseconds) {
        try {
            Thread.sleep(Math.max(milliseconds, 0));
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    private String safe(String value) {
        return value == null ? "" : value;
    }

    private String stringValue(Object value) {
        return value == null ? "" : String.valueOf(value).trim();
    }

    private boolean isBlank(String value) {
        return value == null || value.trim().isEmpty();
    }
}
