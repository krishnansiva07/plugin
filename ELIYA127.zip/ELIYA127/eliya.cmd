@echo off
setlocal EnableExtensions
rem Do not CD to this script's directory. Map the calling terminal's project instead.
set "JAR=%~dp0target\eliya.jar"
if defined ELIYA_JAR set "JAR=%ELIYA_JAR%"
if not exist "%JAR%" if not defined ELIYA_JAR set "JAR=%~dp0eliya.jar"
if not exist "%JAR%" (
  echo ELIYA JAR not found: "%JAR%" 1>&2
  echo Build with mvnw.cmd clean package or set ELIYA_JAR. 1>&2
  exit /b 1
)
java -jar "%JAR%" --eliya-cli %*
exit /b %errorlevel%
