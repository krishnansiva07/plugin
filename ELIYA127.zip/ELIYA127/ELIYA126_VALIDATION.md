# ELIYA126 validation summary

Executed in the authoring environment:
- Java 17 stub compile and smoke tests for `EliyaCliBridge`, `EliyaCliLauncher`, and project-directory detection: passed.
- Terminal shell launcher test (including spaces in paths and preserved working directory): passed.
- Browser `app.js` JavaScript syntax: passed.
- Existing ELIYA125 suite: 112 JavaScript tests passed, 0 failed; 20 Java builder/memory checks and 10 registry checks passed.
- Existing ELIYA120 handoff smoke: passed.

**Not validated:** production Maven/Spring Boot compilation, runnable shaded JAR boot, live LLM response, Agent tool execution, Windows/IntelliJ GUI terminal integration. Those require a local environment with Java 17, Maven dependency access and configured model credentials. The release ZIP is a source project and launcher, not a tested precompiled JAR.

Suggested acceptance sequence:
1. Build with `mvnw.cmd clean package` (Windows) or `./mvnw clean package` (macOS/Linux).
2. Start the JAR and verify automatic browser open.
3. Save Settings in the browser, then run `eliya status` from a fresh IDE terminal; model readiness should be `true`.
4. Run `eliya` from project A, then `eliya analyse "List modules"` and verify analysis in the browser history.
5. Use `eliya implement`; verify Agent run appears, approvals remain enforced, and modified files/tests are correctly reported.
6. Open terminal B in project B, run `eliya`, switch A's interactive mode back to Agent and verify it **does not** write into B.
7. Clear the browser API key and verify AI commands reject requests until valid settings are saved.
