# ELIYA124 — UI, Agent analysis, completion evidence and OpenCode JSON import

**Release type:** Modified Java 17 / Spring Boot **source** based on the attached ELIYA123 archive. No production environment or LLM was contacted during these checks.

## Implemented

1. **Generated code / prompt layout:** Assistant code blocks and the composer preview use one bounded scrollable code body; preformatted text no longer introduces an independent vertical scrolling area alongside line numbers. An incomplete streamed code fence with no actual code does not display a blank dark card. This limits the large black gap associated with generated code, flow or prompt output.
2. **Agent analysis displayed as readable Markdown:** Read-only investigations explicitly request a substantive, evidence-backed, structured answer in the conversation. Analysis requests that also produce artifacts request the same detailed content in the chat and the specified output file. Existing assistant message controls let users download the response as Markdown or PDF, preview content continuously, and inspect saved artifacts. Requests for **PDF, Word, Excel, Markdown files** are routed to the normal Agent artifact tools, rather than the read-only investigation shortcut.
3. **Completion truthfulness:** A closed SSE stream is no longer interpreted by the UI as proof of a verified 100%-complete run. The frontend reads the persisted server-run status and shows `unknown` if it cannot be verified. Read-only Agent investigations no longer treat failed tool attempts as evidence. For explicitly named HTML outputs, the last-mile gate verifies the **requested file** exists among tracked changed files, rather than accepting any unrelated valid HTML file.
4. **OpenCode JSON configuration import:** Settings now include **Import OpenCode JSON**. A local REST endpoint validates and atomically stores imported configuration in `~/.eliya/opencode-import.json` (outside the mapped project), with restricted permissions when supported. It accepts OpenCode `provider`/`providers`, `model`, and `mcp` server definitions, including multiple local and remote MCP tools. The UI pre-fills the selected model and provider base URL/key if they are plain values; users **must review and Save settings** before model changes take effect. Environment placeholders `{env:NAME}` are supported for MCP headers/environment; unresolved API key placeholders are not copied into live Settings. The import summary never echoes secrets. Imported MCP servers remain behind Eliya's global MCP switch and prompt-specific MCP opt-in.
5. **Regression test and CI integration:** Added `qa/eliya124-smoke.sh`, dependency-free Java proof-of-evidence tests, JavaScript UI-contract tests and JUnit importer tests for the full Maven CI build. The GitHub Actions verification workflow now invokes the new smoke script before the Maven build.

## What this release does NOT claim

- This package does **not** prove the large-code visual fix in all Chrome/Edge browsers: automated DOM/screenshot testing was unavailable. Visually test several long code and streaming scenarios on your computer.
- Importing OpenCode JSON does **not** re-enable the paused OpenCode execution engine or start OpenCode. Native Eliya remains the default. OpenCode multi-provider switching is not the same as Eliya's single selected-model settings; the import safely retains all definitions but only preselects the default model for Eliya Settings.
- Imported MCP definitions are consumed by Eliya's MCP discovery only when MCP is explicitly enabled/used. Nothing connects or executes as a side effect of import.
- No complete Java 17 Maven/Spring Boot compile, executable JAR build, networked model call, or live MCP server invocation could be performed in this sandbox; Maven and downloadable dependencies are unavailable.
- Specialized HTML output checks prove filename, tracked change, existence and minimum document structure. They do not prove the semantic accuracy or full coverage of report content. Other artifact formats continue through their existing verification flows.

## Validation executed in this environment

From the source root run `bash qa/eliya124-smoke.sh`. Latest result:

- JavaScript unit/UI contracts: **109 passed, 0 failed**.
- ELIYA124 Java completion/evidence/analysis-routing smoke: **11 assertions passed**.
- ELIYA123 spec-flow regression: **8 assertions passed**.
- ELIYA123 output-contract regression: **16 scenarios passed**.
- `node --check` on modified `app.js` and `markdown.js`: **passed**.
- OpenCode importer JUnit tests: **added for Maven CI, not run locally** (Jackson/Spring dependencies unavailable).
- Full Maven build/test: **not run**, environment lacks Maven/dependencies.

## Build the executable JAR locally

Requirements: **Java 17+**, **Maven 3.9+**, access to your Maven dependencies (via your configured corporate repository / JFrog if required).

```bash
mvn -B -Pfull-tests -Dmaven.test.skip=false clean verify
```

On success, the executable is `target/eliya.jar`. On Windows use `build-jar-windows.cmd`; on macOS/Linux use `./build-jar.sh` (the shell script may skip tests by default, so prefer the full test command above for acceptance).

## Recommended acceptance tests

1. Run the JAR, generate 500+ lines of Java in Chat and Agent, then a Markdown flowchart or long prompt. Observe streamed content and finalized output; verify no tall empty black gutter, aligned line numbers and readable code scrolling.
2. In Agent, ask `Analyse the current workspace architecture and explain UI/API flow`. Confirm a full Markdown answer with evidence and no writes. Download via **Markdown** button.
3. Ask Agent `Analyze the module and save findings.md`, then `Review module and create a PDF report`. Confirm corresponding files exist, are valid and the full findings are shown in the conversation.
4. Ask Agent `Create coverage-report.html` but make the generation fail or create only `unrelated.html`. Confirm it is **not** marked successfully complete.
5. Import sample OpenCode JSON with `provider`, `model` and several `mcp` definitions. Check the settings summary, no secret leaks, no automatic MCP invocation, and that the model/base URL field updates only once reviewed/saved. Enable MCP deliberately and use an explicit `MCP` request to test a permitted tool.
6. Terminate or interrupt a task during execution and confirm the UI never labels a closed event stream as verified completion without the persisted server-run state.
