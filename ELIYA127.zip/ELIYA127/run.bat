@echo off
setlocal EnableExtensions
rem Preserve the current working directory so the JAR detects the calling project.
set "JAR=%~dp0target\eliya.jar"
if not exist "%JAR%" (
  echo ELIYA JAR not found. Building from source...
  pushd "%~dp0"
  call mvnw.cmd clean package
  if errorlevel 1 (
    popd
    exit /b 1
  )
  popd
)
java -jar "%JAR%" %*
exit /b %errorlevel%
