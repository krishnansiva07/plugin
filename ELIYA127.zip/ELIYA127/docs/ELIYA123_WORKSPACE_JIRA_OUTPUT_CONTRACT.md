# ELIYA123 — Mapped Workspace, Jira MCP and Output Contract

## Why this update exists

A request to retrieve Jira issues through **Jira MCP**, compare those issues against the selected project's files, and generate an **HTML report** previously could show **Completed** when the final report step failed. A separate routing path looked for the word `workspace` and could exclude a mapped project from an external/Jira discussion if the user did not type that word.

This update fixes identifiable code-level causes. It is **not** a claim that the previously reported real environment failure has been reproduced: its runtime trace was not supplied.

## Changes

### 1. Selected project is the default workspace

- Chat keeps the selected project ID for Jira, Confluence and other external evidence questions. It no longer suppresses workspace context just because the prompt omits `workspace`.
- The context system tells Chat that the active project is mapped and available for project-specific questions.
- Targeted workspace evidence retrieval is enabled for combined external-source comparison and reporting requests, not just prompts that literally contain `workspace`.
- Native Agent continues to prepare the selected project root and makes tools operate against that root.
- MCP remains opt-in: **do not call MCP unless the actual user task or an exact selected Analyse→Agent handoff explicitly mentions MCP**. Ordinary requests to compare project files do not grant MCP access.

### 2. Last-mile completion verification

For an Agent task requesting HTML output, completion requires:

1. The run has an active mapped writable workspace.
2. If Jira MCP is explicitly requested, at least one successful Jira MCP tool completion is recorded.
3. If Jira-to-workspace comparison is requested, at least one successful relevant workspace read/search is recorded.
4. No unresolved relevant tool/validation failure remains (a successful retry may clear a failure).
5. A **new/changed** `.html` deliverable is reported by the native workspace tracker, remains within the workspace root, is a readable regular file, and passes a bounded HTML structural read-back.

Failure changes the final run status to **Failed**, emits a `deliverable_verification` or `final_outcome_gate` error event, and retains the failure reason. A verifier/step failure does not count as success merely because earlier steps were completed.

This is **structural/output evidence**, not a semantic assertion that every Jira issue was compared correctly. The HTML file still needs source-to-report sampling and browser validation in a real integration test.

### 3. Reduce redundant execution work

For the specific combination **explicit Jira MCP + workspace comparison + HTML report**, use a fixed three-step contract:

1. Retrieve the relevant Jira issues with Jira MCP and retain source identifiers.
2. Inspect pertinent files in the **currently selected** project and identify matches/gaps.
3. Write the HTML report, read it back, verify it, and report the path or an explicit failure.

This avoids an additional plan-generation model request for a familiar deterministic workflow. Other Agent tasks keep their existing planner and runtime checks. No fabricated performance percentage is claimed; benchmark real workloads before drawing speed/token conclusions.

### 4. Lightweight spec-driven flow

Complex native Agent runs generate `spec.md`, `plan.md`, `tasks.md` and `state.txt` under:

`<Eliya working directory>/data/spec-flows/<run-id>/`

They record the original objective, acceptance criteria, native plan, current checklist and final run outcome. Updates use atomic local file replacement when supported. This is **inspired by GitHub Spec Kit**, not a full `specify` CLI installation or its complete feature lifecycle. The journal is deliberately placed outside the mapped project so it does not add unrelated repository files. Checkpoints are preserved for review; full process-resume from checkpoints is **not** implemented by this change.

## How to validate on your machine

1. Open the updated Eliya JAR. Select/map your actual source-code project. Keep that mapping active.
2. Select **Agent** and enter (notice that the prompt deliberately does not say `workspace`):

   `Using Jira MCP, pull the issues for <your JQL or project key>, compare each relevant requirement against the currently selected project's implementation, and generate an HTML traceability/gap report with Jira IDs, source files, evidence, gaps, and a summary.`

3. Confirm **Jira MCP retrieval succeeds**; verify the actual MCP tool name, arguments and response instead of accepting a text-only claim.
4. Confirm targeted `read` / `grep` / `inspect_workspace` calls are operating inside the mapped project and the report uses actual evidence.
5. Confirm the HTML report has been created or changed inside the project, opens in a browser, and cites the correct Jira issues and source files.
6. Negative test: deliberately cause HTML output validation or write to fail, using a safe throwaway workspace. **Expected:** final status `Failed`, a visible failure event, and a report-verification explanation. It must **not** say Completed.
7. Negative test: disable/misconfigure Jira MCP. **Expected:** no successful Jira evidence => Failed; no fabricated comparison or successful report claim.
8. Positive retry test: trigger a tool error then correct it in the same run. **Expected:** a successful retry clears its relevant error and the run can finish only after deliverable validation.
9. Analyse→Agent: explicitly mention `Jira MCP` in the saved Analyse request, click Implement in Agent, review the carried original requirement and execute. MCP authorization should carry over from that **specific** saved user requirement, not from unrelated conversation messages.
10. Check `data/spec-flows/<run-id>/state.txt`, `tasks.md`, `spec.md` and `plan.md` to see the contract and final status.

## Checks run in the packaging environment

- `bash qa/eliya123-output-contract-smoke.sh`: 16 scenarios passed.
- `bash qa/eliya123-spec-flow-smoke.sh`: 8 assertions passed.
- `node --test src/test/js/*.test.js`: 105 JavaScript tests passed.
- `bash qa/native-agent-policy-smoke.sh`: 10 profiles passed.
- `bash qa/eliya65-verification-smoke.sh`: 9 scenarios passed.
- The historical `qa/offline-smoke/chat-mcp-routing.sh` test uses obsolete ChatService mocks and fails to compile the current ChatService API (`finishReason`, `continuePartialAnswer`, `streamContinuously`); this test is **not a pass** and should be updated separately.

## Not verified here

- Complete Maven/Spring Boot JAR build (Maven unavailable in this environment).
- A real call to your Jira MCP server and any Jira permission/authentication issues.
- Browser rendering and a real code-to-Jira comparison.
- Fully automatic retry/resume after a terminated JVM, or complete Spec Kit CLI integration.

Build from `ELIYA` with `build-jar-windows.cmd` on your machine and use the acceptance steps above before applying this version to production work.
