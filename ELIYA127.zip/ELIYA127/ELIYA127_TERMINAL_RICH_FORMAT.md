# ELIYA127 — Rich Terminal Rendering (Analyse + Agent)

This release extends ELIYA126. It updates the **OS/IDE terminal command renderer**, not the embedded web terminal, and does not replace the native Eliya analysis or Agent execution engine.

## Run

Build Java 17 source as described in `ELIYA126_TERMINAL_ANALYSE_AGENT.md`, start the built JAR, then install the `eliya` launcher. Configure a model and API key in Eliya's browser Settings.

```powershell
cd "D:\Automation\SeleniumFramework"
eliya analyse
# enter a prompt: Analyse Java Selenium framework architecture, show code examples and a flow diagram.
# /agent changes to Agent, /implement hands off the saved analysis.
```

One-shot commands also use rich rendering:

```powershell
eliya analyse "Review my Java Selenium framework and draw its execution flow"
eliya agent "Implement the approved Page Object refactoring and verify tests"
eliya analyse --color "Show a code example and a Mermaid diagram"
eliya analyse --no-color "Explain the framework"  # pipe or legacy terminal
```

## Styles

| Content | Rendering |
| --- | --- |
| `#`/`##` headings | Bold blue |
| Inline code | Green |
| Bold Markdown | Bold |
| Fenced Java / TS / JS / Python / JSON / YAML / SQL / shell | Lightweight syntax coloring; keywords purple, strings green, numbers yellow, comments gray |
| `diff`/`patch` | Added lines green, removed lines red, hunk headers cyan |
| `mermaid`/`flow` | Cyan text flow, readable Unicode directional arrows |
| Markdown tables | Aligned terminal columns with separators |
| Lists, links, quotes, rules | Terminal-native readable layouts |
| Agent status: warning / approval | Amber |
| Agent status: error / failure | Red |
| Agent status: success | Green |
| Analyse/Agent prompt | Blue / green |
| Completed stream | Shows **Saved to Eliya conversation**, NOT an unverified success claim |

The terminal deliberately **does not render HTML or images**. Mermaid is a readable text rendering, not a graphical diagram. Very complex diagrams and elaborate nested Markdown may retain their textual notation.

## Color compatibility

- Auto color-detection supports Windows Terminal, VS Code's integrated terminal, JetBrains/IntelliJ terminals and standard ANSI-aware POSIX terminals.
- Legacy Windows CMD without declared ANSI support uses plain text rather than displaying raw escape codes.
- `--color` forces ANSI colors when your terminal supports them; `--no-color` disables colors anywhere.
- `NO_COLOR` or `TERM=dumb` disables automatic coloring; `CLICOLOR_FORCE=1` or `FORCE_COLOR=1` enables it (unless `--no-color` is passed).
- Windows Powershell color detection varies with its host terminal. `--color` is available if your host supports ANSI.
- Text is UTF-8; a terminal whose font/encoding lacks box drawing characters may display plain placeholders. Source text content is still preserved.

## Streaming and security

- The renderer is incremental and retains parsing state across SSE tokens, so a fenced code block split across multiple network events is rendered correctly.
- Long unbroken lines are emitted in bounded chunks rather than buffered indefinitely. Table buffering is capped at 100 rows or 12,000 characters.
- Model/tool output is treated as untrusted data: escape/control characters (including ANSI and OSC introductions, C1 controls, and bidirectional overrides) are removed before printing. Only Eliya-generated formatting codes are emitted.
- Ctrl+C disconnects the terminal stream. It is **not proof** that a server-side Agent run was stopped. Use the browser Stop action when cancellation is required.
- Browser/terminal conversation synchronization, workspace selection and Agent tools remain as delivered in v126, with the same integration/build limitations.

## Validation

```bash
bash qa/eliya127/run-rich-renderer-smoke.sh
bash qa/eliya126/run-java-cli-smoke.sh
bash qa/eliya126/run-terminal-smoke.sh
node --test src/test/js/*.test.js
```

These are source-level Java tests and JavaScript regression tests. A full Spring Boot Maven build, packaged JAR launch, Windows Console interaction, and a live configured model/Agent run **were not validated** in the authoring environment. Before shipping to end users, build on a networked Java 17 development machine and exercise real CMD, PowerShell, VS Code, and IntelliJ terminals.
