#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../.."
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
mkdir -p "$TMP/src" "$TMP/classes"
make() { local f="$TMP/src/$1"; mkdir -p "$(dirname "$f")"; cat > "$f"; }
make org/springframework/stereotype/Component.java <<'JAVA'
package org.springframework.stereotype;
public @interface Component {}
JAVA
make org/springframework/web/bind/annotation/RestController.java <<'JAVA'
package org.springframework.web.bind.annotation;
public @interface RestController {}
JAVA
make org/springframework/web/bind/annotation/RequestMapping.java <<'JAVA'
package org.springframework.web.bind.annotation;
public @interface RequestMapping { String value() default ""; }
JAVA
make org/springframework/web/bind/annotation/GetMapping.java <<'JAVA'
package org.springframework.web.bind.annotation;
public @interface GetMapping { String value() default ""; }
JAVA
make org/springframework/web/bind/annotation/PostMapping.java <<'JAVA'
package org.springframework.web.bind.annotation;
public @interface PostMapping { String value() default ""; String path() default ""; String[] produces() default {}; }
JAVA
make org/springframework/web/bind/annotation/RequestBody.java <<'JAVA'
package org.springframework.web.bind.annotation;
public @interface RequestBody {}
JAVA
make org/springframework/web/bind/annotation/RequestHeader.java <<'JAVA'
package org.springframework.web.bind.annotation;
public @interface RequestHeader { String value(); boolean required() default true; }
JAVA
make jakarta/annotation/PreDestroy.java <<'JAVA'
package jakarta.annotation;
public @interface PreDestroy {}
JAVA
make jakarta/servlet/http/HttpServletRequest.java <<'JAVA'
package jakarta.servlet.http;
public interface HttpServletRequest { String getRemoteAddr(); }
JAVA
make org/springframework/context/event/EventListener.java <<'JAVA'
package org.springframework.context.event;
public @interface EventListener { Class<?>[] value() default {}; }
JAVA
make org/springframework/boot/context/event/ApplicationReadyEvent.java <<'JAVA'
package org.springframework.boot.context.event;
public class ApplicationReadyEvent {}
JAVA
make org/springframework/boot/web/servlet/context/ServletWebServerApplicationContext.java <<'JAVA'
package org.springframework.boot.web.servlet.context;
public class ServletWebServerApplicationContext {
  public Server getWebServer() { return new Server(); }
  public static class Server { public int getPort() { return 8090; } }
}
JAVA
make org/springframework/http/HttpStatus.java <<'JAVA'
package org.springframework.http;
public enum HttpStatus { FORBIDDEN, CONFLICT, BAD_REQUEST }
JAVA
make org/springframework/web/server/ResponseStatusException.java <<'JAVA'
package org.springframework.web.server;
public class ResponseStatusException extends RuntimeException {
  public ResponseStatusException(org.springframework.http.HttpStatus status, String message) {super(status+": "+message);}
}
JAVA
make org/springframework/http/ResponseEntity.java <<'JAVA'
package org.springframework.http;
public class ResponseEntity<T> {
  private final int status; private final T value;
  public ResponseEntity(int status,T value){this.status=status;this.value=value;}
  public int getStatusCodeValue(){return status;}
  public T getBody(){return value;}
  public static <T> ResponseEntity<T> ok(T value){return new ResponseEntity<>(200,value);}
  public static BodyBuilder status(HttpStatus code){return new BodyBuilder(code==HttpStatus.CONFLICT?409:403);}
  public static BodyBuilder badRequest(){return new BodyBuilder(400);}
  public static class BodyBuilder {
    private final int status;
    BodyBuilder(int status){this.status=status;}
    public <T> ResponseEntity<T> body(T value){return new ResponseEntity<>(status,value);}
    public <T> ResponseEntity<T> build(){return new ResponseEntity<>(status,null);}
  }
}
JAVA
make com/fasterxml/jackson/databind/ObjectMapper.java <<'JAVA'
package com.fasterxml.jackson.databind;
public class ObjectMapper {
  public String writeValueAsString(Object object) { return "{}"; }
  public JsonNode readTree(String value) { return new JsonNode(); }
  public com.fasterxml.jackson.databind.node.JsonNodeFactory getNodeFactory() { return new com.fasterxml.jackson.databind.node.JsonNodeFactory(); }
}
JAVA
make com/fasterxml/jackson/databind/JsonNode.java <<'JAVA'
package com.fasterxml.jackson.databind;
public class JsonNode {
  public JsonNode path(String name){return this;}
  public String asText(){return "";}
  public String asText(String other){return other;}
  public boolean asBoolean(){return false;}
  public boolean hasNonNull(String key){return false;}
}
JAVA
make com/fasterxml/jackson/databind/node/JsonNodeFactory.java <<'JAVA'
package com.fasterxml.jackson.databind.node;
public class JsonNodeFactory {
 public com.fasterxml.jackson.databind.JsonNode textNode(String val) {return new com.fasterxml.jackson.databind.JsonNode();}
}
JAVA
make org/springframework/http/MediaType.java <<'JAVA'
package org.springframework.http;
public class MediaType { public static final String TEXT_EVENT_STREAM_VALUE="text/event-stream"; }
JAVA
make org/springframework/web/servlet/mvc/method/annotation/SseEmitter.java <<'JAVA'
package org.springframework.web.servlet.mvc.method.annotation;
public class SseEmitter {}
JAVA
make com/llmart/llm/dto/ChatSettings.java <<'JAVA'
package com.llmart.llm.dto;
public record ChatSettings(String baseUrl, String model) {}
JAVA
make com/llmart/llm/dto/ChatRequest.java <<'JAVA'
package com.llmart.llm.dto;
import java.util.List;
public record ChatRequest(String conversationId, String message, List<String> attachmentIds, String projectId,
                          String mode, boolean regenerate, ChatSettings settings) {}
JAVA
make com/llmart/llm/dto/MessageDto.java <<'JAVA'
package com.llmart.llm.dto;
public record MessageDto(String role, String mode, String content) {}
JAVA
make com/llmart/llm/service/ChatService.java <<'JAVA'
package com.llmart.llm.service;
import com.llmart.llm.dto.ChatRequest;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;
public class ChatService {
  public ChatRequest last;
  public SseEmitter stream(String key, ChatRequest request){this.last=request;return new SseEmitter();}
}
JAVA
make org/springframework/boot/SpringApplication.java <<'JAVA'
package org.springframework.boot;
public class SpringApplication { public static void run(Class<?> cls,String... args) {} }
JAVA
make com/llmart/llm/LlmApplication.java <<'JAVA'
package com.llmart.llm;
public class LlmApplication {}
JAVA
make com/llmart/llm/entity/ConversationEntity.java <<'JAVA'
package com.llmart.llm.entity;
public class ConversationEntity { public String getId(){return "test-conversation";} }
JAVA
make com/llmart/llm/service/ConversationService.java <<'JAVA'
package com.llmart.llm.service;
import java.util.*;
import com.llmart.llm.dto.ConversationDto;
import com.llmart.llm.entity.ConversationEntity;
public class ConversationService {
  public List<ConversationDto> list(){return List.of();}
  public ConversationEntity create(){return new ConversationEntity();}
  public List<com.llmart.llm.dto.MessageDto> listMessages(String id){return List.of(new com.llmart.llm.dto.MessageDto("assistant","chat","review"));}
}
JAVA
make com/llmart/llm/service/ProjectService.java <<'JAVA'
package com.llmart.llm.service;
import com.llmart.llm.dto.ProjectDto;
import java.nio.file.*;
public class ProjectService {
  public java.util.List<ProjectDto> mappedLocalWorkspaces(){return java.util.List.of();}
  public ProjectDto createLocal(String conversation,String raw,String name){
    Path p=Path.of(raw).toAbsolutePath().normalize();
    if(!Files.isDirectory(p)) throw new IllegalArgumentException("Project path is not a directory");
    return new ProjectDto(p.toString(),conversation,p.getFileName().toString(),0,0,0,p.toString(),true,null,null);
  }
}
JAVA
make com/llmart/llm/service/LocalProjectIndexService.java <<'JAVA'
package com.llmart.llm.service;
import com.llmart.llm.dto.ProjectDto;
public class LocalProjectIndexService { public void request(ProjectDto dto, boolean refresh) {} }
JAVA
cat > "$TMP/src/CliSmoke.java" <<'JAVA'
import com.llmart.llm.cli.*;
import com.llmart.llm.service.*;
import org.springframework.boot.web.servlet.context.ServletWebServerApplicationContext;
import java.nio.file.*;
import java.lang.reflect.*;
import java.util.*;
public class CliSmoke {
  private static void check(boolean value, String reason) { if(!value)throw new AssertionError(reason); }
  public static void main(String[] args) throws Exception {
    Path data=Files.createTempDirectory("eliya-cli-test-");
    Path project=Files.createDirectories(data.resolve("my java project"));
    System.setProperty("app.data-dir",data.toString());
    System.setProperty("eliya.browser.enabled","false");
    System.setProperty("eliya.startup.workspace",project.toString());
    ChatService chat = new ChatService();
    EliyaCliBridge bridge=new EliyaCliBridge(new ProjectService(),new ConversationService(),
        new LocalProjectIndexService(),new ServletWebServerApplicationContext(),chat);
    bridge.ready();
    Path credentials=EliyaCliBridge.bridgeFile();
    check(Files.exists(credentials),"credential file was not created");
    List<String> lines=Files.readAllLines(credentials);
    check("8090".equals(lines.get(0)),"wrong port");
    check(lines.get(1).length()==64,"token not random 256-bit hex");
    check(project.toString().equals(bridge.selection(()->"127.0.0.1").getBody().project().localPath()),"startup selection");
    check(bridge.selection(()->"8.8.8.8").getStatusCodeValue()==403,"remote selection allowed");
    check(bridge.activate(new EliyaCliBridge.ActivationRequest(project.toString()),"invalid",()->"127.0.0.1").getStatusCodeValue()==403,"invalid credential allowed");
    Path second=Files.createDirectories(data.resolve("typescript"));
    String first=bridge.selection(()->"127.0.0.1").getBody().version();
    check(bridge.activate(new EliyaCliBridge.ActivationRequest(second.toString()),lines.get(1),()->"127.0.0.1").getStatusCodeValue()==200,"valid CLI activation failed");
    var after=bridge.selection(()->"127.0.0.1").getBody();
    check(second.toString().equals(after.project().localPath()),"workspace was not changed");
    check(!first.equals(after.version()),"UI revision was not updated");
    check(bridge.activate(new EliyaCliBridge.ActivationRequest(null),lines.get(1),()->"127.0.0.1").getStatusCodeValue()==200,"open command failed");
    check(after.version().equals(bridge.selection(()->"127.0.0.1").getBody().version()),"open command changed selection");
    check(bridge.activate(new EliyaCliBridge.ActivationRequest(data.resolve("missing").toString()),lines.get(1),()->"127.0.0.1").getStatusCodeValue()==400,"invalid path accepted");
    check(bridge.mode(new EliyaCliBridge.ModeRequest("agent",second.toString()),"bad",()->"127.0.0.1").getStatusCodeValue()==403,"mode was unauthenticated");
    check(bridge.mode(new EliyaCliBridge.ModeRequest("agent",second.toString()),lines.get(1),()->"127.0.0.1").getStatusCodeValue()==200,"mode switch rejected");
    check("agent".equals(bridge.selection(()->"127.0.0.1").getBody().mode()),"Agent mode not selected");
    try {
      bridge.run(new EliyaCliBridge.TerminalPrompt("agent","edit",second.toString()),lines.get(1),()->"127.0.0.1");
      throw new AssertionError("unconfigured AI credentials should reject request");
    } catch (org.springframework.web.server.ResponseStatusException expected) { /* no credentials */ }
    check(bridge.browserSettings(new EliyaCliBridge.BrowserSettings("test-key",new com.llmart.llm.dto.ChatSettings("http://example.com","model")),
            "wrong","http://example.com",()->"127.0.0.1").getStatusCodeValue()==403,"cross-site settings accepted");
    check(bridge.browserSettings(new EliyaCliBridge.BrowserSettings("test-key",new com.llmart.llm.dto.ChatSettings("http://example.com","model")),
            "settings-sync","http://127.0.0.1:8090",()->"127.0.0.1").getStatusCodeValue()==200,"browser settings not synced");
    check(bridge.run(new EliyaCliBridge.TerminalPrompt("analyse","inspect",second.toString()),lines.get(1),()->"127.0.0.1") instanceof
            org.springframework.web.servlet.mvc.method.annotation.SseEmitter,"Analyse did not use ChatService");
    check("chat".equals(chat.last.mode()) && "inspect".equals(chat.last.message()),"Analyse routing wrong");
    String sharedConversation=chat.last.conversationId();
    check(bridge.run(new EliyaCliBridge.TerminalPrompt("implement","",second.toString()),lines.get(1),()->"127.0.0.1") instanceof
            org.springframework.web.servlet.mvc.method.annotation.SseEmitter,"implement handoff failed");
    check("agent".equals(chat.last.mode()) && sharedConversation.equals(chat.last.conversationId()),"implement lost session");
    check(bridge.refresh(lines.get(1),()->"127.0.0.1").getStatusCodeValue()==200,"refresh failed");
    check(bridge.status(lines.get(1),()->"127.0.0.1").getStatusCodeValue()==200,"status failed");
    Path nested=Files.createDirectories(data.resolve("ide-project").resolve("src").resolve("test").resolve("java"));
    Files.writeString(data.resolve("ide-project").resolve("pom.xml"),"<project />");
    check(ProjectDirectoryLocator.fromWorkingDirectory(nested).equals(data.resolve("ide-project")),
            "nested IDE terminal did not resolve Maven project root");
    check(ProjectDirectoryLocator.detectedProject(nested).equals(data.resolve("ide-project")),
            "plain java -jar project auto-detection failed");
    Method parse=EliyaCliLauncher.class.getDeclaredMethod("parseWorkspace",String[].class);
    parse.setAccessible(true);
    String result=(String)parse.invoke(null,(Object)new String[]{"change","workspace",second.toString()});
    check(result.equals(second.toString()),"change workspace parsing failed");
    result=(String)parse.invoke(null,(Object)new String[]{"workspace",project.toString()});
    check(result.equals(project.toString()),"workspace parsing failed");
    check(parse.invoke(null,(Object)new String[]{"open"})==null,"open should not remap");
    bridge.shutdown();
    check(!Files.exists(credentials),"bridge secret was not removed on shutdown");
    System.out.println("ELIYA CLI Java smoke: startup, auth, workspace switching, syntax and teardown passed");
  }
}
JAVA
mapfile -t sources < <(find "$TMP/src" -name '*.java' | sort)
javac --release 17 -encoding UTF-8 -d "$TMP/classes" \
  "${sources[@]}" \
  src/main/java/com/llmart/llm/dto/ProjectDto.java \
  src/main/java/com/llmart/llm/dto/ConversationDto.java \
  src/main/java/com/llmart/llm/cli/ProjectDirectoryLocator.java \
  src/main/java/com/llmart/llm/cli/EliyaCliLauncher.java \
  src/main/java/com/llmart/llm/cli/EliyaTerminalRenderer.java \
  src/main/java/com/llmart/llm/cli/EliyaCliBridge.java
java -cp "$TMP/classes" CliSmoke
