#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../.."
build="$(mktemp -d)"
trap 'rm -rf "$build"' EXIT
mkdir -p "$build/bin" "$build/sample project"
printf 'fake-jar' > "$build/fake eliya.jar"
cat > "$build/bin/java" <<'JAVA'
#!/usr/bin/env bash
printf 'cwd=%s\n' "$PWD"
printf 'arg=%s\n' "$@"
JAVA
chmod +x "$build/bin/java"
# Call from an unrelated workspace; the launcher must preserve the caller's CWD.
source_root="$PWD"
output=$(cd "$build/sample project" && PATH="$build/bin:$PATH" ELIYA_JAR="$build/fake eliya.jar" \
  "$source_root/eliya" change workspace "../sample project")
[[ "$output" == *"cwd=$build/sample project"* ]]
[[ "$output" == *"arg=--eliya-cli"* ]]
[[ "$output" == *"arg=change"* ]]
[[ "$output" == *"arg=workspace"* ]]
[[ "$output" == *"arg=../sample project"* ]]
# Source contract: browser selection revision follows the activation API response.
node --check src/main/resources/static/app.js
node <<'JS'
const fs=require('fs');
const js=fs.readFileSync('src/main/resources/static/app.js','utf8');
const api=fs.readFileSync('src/main/java/com/llmart/llm/cli/EliyaCliBridge.java','utf8');
const launcher=fs.readFileSync('src/main/java/com/llmart/llm/cli/EliyaCliLauncher.java','utf8');
for(const needle of ['/api/cli/selection','rememberActiveLocalWorkspace(project)','eliya.cli.appliedVersion'])
  if(!js.includes(needle))throw Error('Missing browser activation: '+needle);
for(const needle of ['@PostMapping("/activate")','MessageDigest.isEqual','activateWorkspace(workspace)','openBrowser(url)'])
  if(!api.includes(needle))throw Error('Missing secure bridge: '+needle);
for(const needle of ['--workspace','change','parseWorkspace','SpringApplication.run'])
  if(!launcher.includes(needle))throw Error('Missing launcher: '+needle);
JS
echo 'ELIYA terminal launcher and browser handshake smoke: passed'
