#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
mkdir -p "$TMP/src/com/llmart/llm/service" "$TMP/classes"
cat > "$TMP/src/com/llmart/llm/service/AgentRunService.java" <<'JAVA'
package com.llmart.llm.service;
import java.util.*;
final class AgentRunService {
  static final class AgentRun {
    String id(){return "test-123";}
    String conversationId(){return "conversation-x";}
    String projectId(){return "project-y";}
    String objective(){return "Retrieve Jira MCP and compare workspace, then generate the HTML report";}
    int planSize(){return 2;}
    String planText(){return "1. Retrieve evidence\n2. Generate verified HTML";}
    int progressPercent(){return 50;}
    List<Map<String,Object>> planSnapshot(){return List.of(Map.of("text","Retrieve evidence","status","completed"),Map.of("text","Generate verified HTML","status","in_progress"));}
  }
}
JAVA
cat > "$TMP/src/com/llmart/llm/service/SpecFlowJournalSmoke.java" <<'JAVA'
package com.llmart.llm.service;
import java.nio.file.*;
public class SpecFlowJournalSmoke {
  public static void main(String[] args) throws Exception {
    Path base=Path.of(args[0]);
    System.setProperty("eliya.specFlowDir",base.toString());
    AgentRunService.AgentRun run=new AgentRunService.AgentRun();
    SpecFlowJournal journal=new SpecFlowJournal(run.id());
    if(!SpecFlowJournal.enabled(run.objective(),run.planSize())) throw new AssertionError("complex task should have spec");
    if(SpecFlowJournal.enabled("Hello",1)) throw new AssertionError("small talk must skip spec");
    journal.begin(run);
    if(!journal.started()) throw new AssertionError("journal not started");
    for(String path:new String[]{"spec.md","plan.md","tasks.md","state.txt"})
       if(!Files.isRegularFile(base.resolve("test-123").resolve(path))) throw new AssertionError("Missing "+path);
    journal.checkpoint(run,"failed","missing final HTML output");
    if(!Files.readString(base.resolve("test-123/state.txt")).contains("status=failed"))
       throw new AssertionError("Failure checkpoint absent");
    if(!Files.readString(base.resolve("test-123/tasks.md")).contains("in_progress"))
       throw new AssertionError("Task checkpoint absent");
    System.out.println("ELIYA123 spec flow smoke: 8 assertions passed");
  }
}
JAVA
javac --release 17 -d "$TMP/classes" \
  "$TMP/src/com/llmart/llm/service/AgentRunService.java" \
  src/main/java/com/llmart/llm/service/SpecFlowJournal.java \
  "$TMP/src/com/llmart/llm/service/SpecFlowJournalSmoke.java"
java -cp "$TMP/classes" com.llmart.llm.service.SpecFlowJournalSmoke "$TMP/runtime"
