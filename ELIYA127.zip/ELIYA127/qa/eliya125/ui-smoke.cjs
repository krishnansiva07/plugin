const fs = require('node:fs');
const assert = require('node:assert/strict');
const html = fs.readFileSync('src/main/resources/static/index.html', 'utf8');
const js = fs.readFileSync('src/main/resources/static/app.js', 'utf8');
const css = fs.readFileSync('src/main/resources/static/app.css', 'utf8');
const ids = ['refreshLearning', 'learningCandidate', 'learningSummary', 'learningSources',
             'learningCategory', 'learningApproved', 'approveLearning', 'learningStatus', 'learningLessons'];
for (const id of ids) assert.match(html, new RegExp(`id="${id}"`), `Missing UI input: ${id}`);
assert.match(js, /\/api\/learning\/candidates\?projectId=/);
assert.match(js, /\/api\/learning\/lessons/);
assert.match(js, /\/api\/learning\/lessons\/\$\{encodeURIComponent\(lesson\.id\)\}/);
assert.match(js, /loadVerifiedLearning\(\)/);
assert.match(js, /approveVerifiedLearning\(\)/);
assert.match(css, /\.learning-lesson-row/);
assert.match(js, /\.textContent = String\(lesson\.summary \|\| ''\)/,
             'Lesson content must use textContent to avoid HTML injection');
console.log('ELIYA125 learning UI smoke: 16 wiring / rendering checks passed');
