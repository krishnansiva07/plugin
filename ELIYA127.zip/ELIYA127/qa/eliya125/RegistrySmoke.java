package com.llmart.llm.service;
public class RegistrySmoke {
  static void check(boolean ok,String msg){if(!ok)throw new AssertionError(msg);}
  public static void main(String[] args) {
    AgentToolRegistry registry = new AgentToolRegistry();
    check(registry.isKnownBuiltIn("mcp_scaffold"),"MCP builder tool must be registered");
    check(registry.isKnownBuiltIn("rag_scaffold"),"RAG builder tool must be registered");
    check(registry.isKnownBuiltIn("learning_recall"),"Learning recall must be registered");
    check(!registry.isParallelReadOnly("mcp_scaffold"),"MCP scaffold is a mutation");
    check(!registry.isParallelReadOnly("rag_scaffold"),"RAG scaffold is a mutation");
    check(registry.isParallelReadOnly("learning_recall"),"Learning recall must be read-only");
    check("edit".equals(AgentToolPolicy.category("mcp_scaffold",registry)),"MCP must require edit permissions");
    check("edit".equals(AgentToolPolicy.category("rag_scaffold",registry)),"RAG must require edit permissions");
    check("read".equals(AgentToolPolicy.category("learning_recall",registry)),"Learning recall must be read-only");
    check(!registry.searchDefinitions(registry.builtInDefinitions(),"rag scaffold",10).isEmpty(),"Builder must be discoverable");
    System.out.println("ELIYA125 Agent registry: 10 checks passed");
  }
}
