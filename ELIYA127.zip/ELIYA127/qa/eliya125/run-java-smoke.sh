#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../.."
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
mkdir -p "$TMP/src/org/springframework/beans/factory/annotation" "$TMP/src/org/springframework/stereotype" "$TMP/src/com/fasterxml/jackson/core/type" "$TMP/src/com/fasterxml/jackson/databind" "$TMP/src/com/llmart/llm/service" "$TMP/classes"
cat > "$TMP/src/org/springframework/beans/factory/annotation/Autowired.java" <<'JAVA'
package org.springframework.beans.factory.annotation;
public @interface Autowired { boolean required() default true; }
JAVA
cat > "$TMP/src/org/springframework/stereotype/Service.java" <<'JAVA'
package org.springframework.stereotype;
public @interface Service { }
JAVA
cat > "$TMP/src/com/fasterxml/jackson/core/type/TypeReference.java" <<'JAVA'
package com.fasterxml.jackson.core.type;
public abstract class TypeReference<T> { }
JAVA
cat > "$TMP/src/com/fasterxml/jackson/databind/ObjectMapper.java" <<'JAVA'
package com.fasterxml.jackson.databind;
import com.fasterxml.jackson.core.type.TypeReference;
public class ObjectMapper {
  private static Object saved;
  public <T> T readValue(String text,TypeReference<T> type) { return (T)saved; }
  public String writeValueAsString(Object object) { saved=object; return "stub-json"; }
}
JAVA
cat > "$TMP/src/com/llmart/llm/service/AgentWorkspaceService.java" <<'JAVA'
package com.llmart.llm.service;
import java.io.*;
import java.nio.file.*;
public class AgentWorkspaceService {
  public record Workspace(Path root) {}
  public String writeFile(Workspace ws,String relative,String content) throws IOException {
    Path file=ws.root().resolve(relative); Files.createDirectories(file.getParent());Files.writeString(file,content);return "workspaceChanged=true";
  }
}
JAVA
cat > "$TMP/src/com/llmart/llm/service/AgentRunService.java" <<'JAVA'
package com.llmart.llm.service;
import java.util.*;
public class AgentRunService {
  public record AgentRun(String id,String projectId,String status,long mutationRevision,long verificationAttemptCount,
                         boolean lastVerificationSuccessful) {
    public boolean verifiedCurrentRevision() {return lastVerificationSuccessful;}
    public boolean hasVerificationFailures() {return !lastVerificationSuccessful;}
    public java.util.List<String> touchedPaths() { return java.util.List.of("eliya-generated/sample-mcp-mcp/server.py"); }
  }
  private final Map<String,AgentRun> runs=new HashMap<>();
  public AgentRun add(String id,String project,String status,int changes,int verifications,boolean successful){
    AgentRun run=new AgentRun(id,project,status,changes,verifications,successful);runs.put(id,run);return run;
  }
  public AgentRun require(String id){return runs.get(id);}
  public List<AgentRun> verifiedCandidates(String project) {
    return runs.values().stream().filter(r->r.projectId.equals(project)&&"completed".equals(r.status)&&r.lastVerificationSuccessful).toList();
  }
}
JAVA
javac --release 17 -d "$TMP/classes" \
  "$TMP/src/org/springframework/stereotype/Service.java" \
  "$TMP/src/org/springframework/beans/factory/annotation/Autowired.java" \
  "$TMP/src/com/fasterxml/jackson/core/type/TypeReference.java" \
  "$TMP/src/com/fasterxml/jackson/databind/ObjectMapper.java" \
  "$TMP/src/com/llmart/llm/service/AgentWorkspaceService.java" \
  "$TMP/src/com/llmart/llm/service/AgentRunService.java" \
  src/main/java/com/llmart/llm/service/AgentBuilderService.java \
  src/main/java/com/llmart/llm/service/VerifiedLearningMemoryService.java \
  qa/eliya125/BuilderMemorySmoke.java
java -cp "$TMP/classes:src/main/resources" com.llmart.llm.service.BuilderMemorySmoke
cat > "$TMP/src/com/llmart/llm/service/AgentProfileService.java" <<'JAVA'
package com.llmart.llm.service;
import java.util.*;
public class AgentProfileService {
  public record AgentProfile(String id, Map<String,String> permissions) {}
}
JAVA
javac --release 17 -cp "$TMP/classes" -d "$TMP/classes" \
  "$TMP/src/com/llmart/llm/service/AgentProfileService.java" \
  src/main/java/com/llmart/llm/service/AgentToolRegistry.java \
  src/main/java/com/llmart/llm/service/AgentToolPolicy.java \
  qa/eliya125/RegistrySmoke.java
java -cp "$TMP/classes" com.llmart.llm.service.RegistrySmoke
