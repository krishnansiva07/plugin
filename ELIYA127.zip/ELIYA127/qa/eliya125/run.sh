#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../.."
echo '[ELIYA125] Java builder and verified learning smoke'
bash qa/eliya125/run-java-smoke.sh
echo '[ELIYA125] Source JavaScript syntax and regressions'
node --check src/main/resources/static/app.js
node qa/eliya125/ui-smoke.cjs
node --test src/test/js/*.test.js
echo '[ELIYA125] Standalone generated template Python tests'
(cd src/main/resources/eliya125-templates/mcp-python && python3 -m unittest discover -v)
(cd src/main/resources/eliya125-templates/rag-python && python3 -m unittest discover -v)
echo '[ELIYA125] v124 completion and handoff regressions'
bash qa/eliya124-smoke.sh
echo 'ELIYA125 source-level smoke checks passed. Full Maven build still required.'
