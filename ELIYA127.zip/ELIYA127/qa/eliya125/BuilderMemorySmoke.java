package com.llmart.llm.service;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.TimeUnit;

public class BuilderMemorySmoke {
  static void check(boolean yes, String failure) { if (!yes) throw new AssertionError(failure); }
  public static void main(String[] args) throws Exception {
    Path root = Files.createTempDirectory("eliya125-builders");
    try {
      AgentBuilderService builders = new AgentBuilderService(new AgentWorkspaceService());
      AgentWorkspaceService.Workspace ws = new AgentWorkspaceService.Workspace(root);
      AgentBuilderService.BuildResult mcp=builders.generate(ws,"mcp-python","Sample MCP", "");
      check(mcp.verified(),"MCP files must be read back");
      check(Files.exists(root.resolve("eliya-generated/sample-mcp-mcp/server.py")),"missing server");
      check(mcp.files().size()==6,"MCP file count");
      AgentBuilderService.BuildResult rag=builders.generate(ws,"rag-python","Sample RAG", "");
      check(rag.verified(),"RAG files must be read back");
      check(Files.exists(root.resolve("eliya-generated/sample-rag-rag/rag.py")),"missing RAG implementation");
      check(rag.files().size()==7,"RAG file count");
      // Exercise the CREATED files, not only the bundled resources. This catches
      // incorrect template substitutions and missing packaged resources.
      for (String project : List.of(mcp.directory(),rag.directory())) {
        Path generated = root.resolve(project);
        Process process = new ProcessBuilder("python3","-m","unittest","discover","-v")
                .directory(generated.toFile()).redirectErrorStream(true).start();
        if (!process.waitFor(20, TimeUnit.SECONDS)) {
          process.destroyForcibly();
          throw new AssertionError("Generated project tests timed out: " + project);
        }
        String output = new String(process.getInputStream().readAllBytes());
        check(process.exitValue()==0,"Generated project tests failed: " + project + "\n" + output);
      }

      try { builders.generate(ws,"mcp-python","Sample MCP", ""); throw new AssertionError("must reject overwrite"); }
      catch (FileAlreadyExistsException expected) {}
      try { builders.generate(ws,"mcp-python","escape", "../escape"); throw new AssertionError("must reject parent traverse"); }
      catch (IllegalArgumentException expected) {}
      try { builders.generate(ws,"mcp-python","escape", root.toString()); throw new AssertionError("must reject absolute path"); }
      catch (IllegalArgumentException expected) {}
      Path outer=Files.createTempDirectory("eliya125-outside");
      try {
        Files.createSymbolicLink(root.resolve("linked"),outer);
        try { builders.generate(ws,"mcp-python","escape", "linked/mcp"); throw new AssertionError("must reject symlink"); }
        catch (IllegalArgumentException expected) {}
      } finally { Files.deleteIfExists(root.resolve("linked")); Files.deleteIfExists(outer); }

      AgentRunService runs = new AgentRunService();
      VerifiedLearningMemoryService memory = new VerifiedLearningMemoryService(new com.fasterxml.jackson.databind.ObjectMapper(), runs, root.resolve("private-memory"));
      AgentRunService.AgentRun completed = runs.add("verified", "project-1", "completed", 1, 1, true);
      AgentRunService.AgentRun failed = runs.add("failed", "project-1", "failed", 1, 1, true);
      check(memory.candidates("project-1").size()==1,"must only suggest completed verified run");
      String source="eliya-generated/sample-mcp-mcp/server.py";
      try { memory.approve(root,"project-1","failed","fix","A meaningful verified fix is represented by this lesson",List.of(source),true); throw new AssertionError("bad run must reject"); }
      catch (IllegalArgumentException expected) {}
      try { memory.approve(root,"project-1","verified","fix","A meaningful verified fix is represented by this lesson",List.of(source),false); throw new AssertionError("no approval must reject"); }
      catch (IllegalArgumentException expected) {}
      try { memory.approve(root,"project-1","verified","fix","API key: TOP_SECRET_TOKEN_12345678",List.of(source),true); throw new AssertionError("secret must reject"); }
      catch (IllegalArgumentException expected) {}
      var lesson=memory.approve(root,"project-1","verified","fix",
          "The MCP server responds to verified JSON-RPC initialization and rejects unknown tools.",List.of(source),true);
      check(memory.list(root).size()==1,"memory persisted");
      check(!Boolean.TRUE.equals(memory.list(root).get(0).get("stale")),"new source must be current");
      check(memory.recall(root,"MCP JSON-RPC initialization",800).contains("JSON-RPC"),"approved lesson should be retrieved");
      Files.writeString(root.resolve(source),"changed source to invalidate old memory");
      check(Boolean.TRUE.equals(memory.list(root).get(0).get("stale")),"drifted source must be stale");
      check(memory.recall(root,"MCP JSON-RPC initialization",800).isEmpty(),"stale lessons cannot be injected");
      check(memory.revoke(root,lesson.id()),"lesson should be revocable");
      check(memory.list(root).isEmpty(),"revoked memory no longer present");
      System.out.println("ELIYA125 builder + memory smoke: 20 checks passed");
    } finally {
      try (var walk=Files.walk(root)) {
        for (Path p:walk.sorted(Comparator.reverseOrder()).toList()) Files.deleteIfExists(p);
      }
    }
  }
}
