#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
mkdir -p "$TMP/classes" "$TMP/src/com/llmart/llm/service"
cat > "$TMP/src/com/llmart/llm/service/AgentCompletionEvidenceSmoke.java" <<'JAVA'
package com.llmart.llm.service;
import com.llmart.llm.dto.ProjectPatchRequest;
import java.nio.file.*;
import java.util.*;
public final class AgentCompletionEvidenceSmoke {
    private static final String TASK="Pull Jira using Jira MCP, compare acceptance criteria against the mapped code and generate an HTML report";
    private static void check(boolean value, String msg){ if(!value) throw new AssertionError(msg); }
    static Map<String,Object> event(String tool,String status){return Map.of("tool",tool,"status",status,"detail",tool+" " +status);}
    public static void main(String[] args) throws Exception {
        Path root=Files.createTempDirectory("eliya-report-smoke-");
        try {
            AgentCompletionEvidence e=new AgentCompletionEvidence(TASK);
            check(e.requiresHtml(),"expected html contract");
            check(e.requiresJiraMcp(),"expected explicit Jira MCP contract");
            check(!e.verify(root,List.of()).passed(),"missing report must fail");
            Path file=root.resolve("jira-gap-report.html");
            Files.writeString(file,"<!doctype html><html><head><title>Jira gap report</title></head><body><main><h1>Jira issue comparison</h1><p>Acceptance criteria checked against source evidence and unverified items explicitly noted.</p></main></body></html>");
            var changes=List.of(new ProjectPatchRequest.ProjectPatchFile("jira-gap-report.html","",null,"write"));
            check(!e.verify(root,changes).passed(),"missing Jira MCP result must fail");
            e.observe(event("mcp__jira__search","success"));
            check(!e.verify(root,changes).passed(),"missing workspace reads must fail");
            e.observe(event("read_many","success"));
            check(e.verify(root,changes).passed(),"complete verified report should pass");
            e.observe(event("confluence_validate","error"));
            check(!e.verify(root,changes).passed(),"last-step HTML validation error must fail");
            e.observe(event("confluence_validate","success"));
            check(e.verify(root,changes).passed(),"successful validation retry should recover");
            e.observe(event("mcp__jira__search","error"));
            check(!e.verify(root,changes).passed(),"unresolved Jira MCP retrieval failure must fail");
            e.observe(event("mcp__jira__search","success"));
            check(e.verify(root,changes).passed(),"successful Jira retry should recover");
            e.observe(event("build","error"));
            check(e.hasUnresolvedCriticalFailures(),"verification failure must be tracked");
            e.observe(event("test","success"));
            check(!e.hasUnresolvedCriticalFailures(),"passing new verification should clear failure");
            Files.writeString(file,"<html><body>short</body></html>");
            check(!e.verify(root,changes).passed(),"short/partial HTML must fail");
            check(!new AgentCompletionEvidence("Explain HTML rendering").requiresHtml(),"learning-only prompt should not demand file");
            check(MappedWorkspaceEvidencePolicy.shouldRetrieve("Using Jira MCP, compare stories against implemented test cases and generate HTML report"),
                    "Jira comparison without workspace word must load mapped project");
            check(MappedWorkspaceEvidencePolicy.shouldRetrieve("Review missing scenarios"),"project-related follow-up must read mapped project");
            check(!MappedWorkspaceEvidencePolicy.shouldRetrieve("What is the capital of Spain?"),"generic question must keep fast path");
            System.out.println("ELIYA123 output-contract smoke: 16 scenarios passed");
        } finally { try(var walk=Files.walk(root)){walk.sorted(Comparator.reverseOrder()).forEach(p->{try{Files.deleteIfExists(p);}catch(Exception ignored){}});} }
    }
}
JAVA
javac --release 17 -d "$TMP/classes" \
  src/main/java/com/llmart/llm/dto/ProjectPatchRequest.java \
  src/main/java/com/llmart/llm/service/McpPromptGate.java \
  src/main/java/com/llmart/llm/service/MappedWorkspaceEvidencePolicy.java \
  src/main/java/com/llmart/llm/service/AgentCompletionEvidence.java \
  "$TMP/src/com/llmart/llm/service/AgentCompletionEvidenceSmoke.java"
java -cp "$TMP/classes" com.llmart.llm.service.AgentCompletionEvidenceSmoke
