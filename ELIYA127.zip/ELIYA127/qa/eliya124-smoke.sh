#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
node --check src/main/resources/static/app.js
node --check src/main/resources/static/markdown.js
node --test src/test/js/*.test.js
work=$(mktemp -d)
trap 'rm -rf "$work"' EXIT
javac -encoding UTF-8 -d "$work" \
 src/main/java/com/llmart/llm/dto/ProjectPatchRequest.java \
 src/main/java/com/llmart/llm/service/McpPromptGate.java \
 src/main/java/com/llmart/llm/service/AgentPlanRelevance.java \
 src/main/java/com/llmart/llm/service/AgentConversationIntent.java \
 src/main/java/com/llmart/llm/service/AgentCompletionEvidence.java \
 qa/eliya124/CompletionGateSmoke.java
java -cp "$work" com.llmart.llm.service.CompletionGateSmoke
bash qa/eliya123-spec-flow-smoke.sh
bash qa/eliya123-output-contract-smoke.sh
