import com.llmart.llm.cli.EliyaTerminalRenderer;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.nio.charset.StandardCharsets;
import java.util.Map;

/** Dependency-free renderer tests: no Maven, no JAR, no live LLM. */
public final class TerminalRendererSmoke {
    private static void yes(boolean value, String reason) {
        if (!value) throw new AssertionError(reason);
    }
    private static String render(boolean colors, String... tokens) {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        EliyaTerminalRenderer renderer = new EliyaTerminalRenderer(new PrintStream(bytes, true, StandardCharsets.UTF_8), colors);
        for (String token : tokens) renderer.text(token);
        renderer.endResponse();
        return bytes.toString(StandardCharsets.UTF_8);
    }
    public static void main(String[] args) {
        String formatted = render(true,
                "## Arch", "itecture\nFound **fla", "ky tests** in `DriverManager.java`.\n", 
                "```ja", "va\nprivate static final int COUNT = 42;\n", "```\n",
                "| Item | Action |\n", "|---|---|\n| Framework | Improve |\n",
                "```mermaid\nflowchart TD\nA[Start] --> B{Done?}\n```\n");
        yes(formatted.contains("\033[1;94mArchitecture"), "heading was not blue");
        yes(formatted.contains("\033[1mflaky tests"), "inline emphasis not bold");
        yes(formatted.contains("\033[92mDriverManager.java"), "inline code was not green");
        yes(formatted.contains("── JAVA ──"), "streamed code fence/language not parsed");
        yes(formatted.contains("\033[95mprivate"), "Java keyword syntax highlighting missing");
        yes(formatted.contains("\033[93m42"), "number syntax highlighting missing");
        yes(formatted.contains("Item") && formatted.contains("Framework") && formatted.contains("┼"), "table not rendered");
        yes(formatted.contains("Flowchart") && formatted.contains("──▶"), "Mermaid flow not rendered");
        yes(!formatted.contains("```"), "raw Markdown fences leaked into rendered output");
        String diff = render(true, "```diff\n--- a/Test.java\n+++ b/Test.java\n-old\n+new\n```\n");
        yes(diff.contains("\033[91m-old"), "removed diff lines not red");
        yes(diff.contains("\033[92m+new"), "added diff lines not green");
        String uncolored = render(false,
                "# Analyse\r", "\n", "```json\n{\"ok\": true, \"count\": 2}\n```\n",
                "| A | B |\n| --- | --- |\n| x | y |\n");
        yes(!uncolored.contains("\033"), "plain-text fallback emitted ANSI");
        yes(uncolored.contains("Analyse\n"), "Heading missing in plain-text mode");
        yes(!uncolored.contains("Analyse\n\n"), "CRLF split generated extra blank line");
        yes(uncolored.contains("{\"ok\": true, \"count\": 2}"), "JSON content was altered");
        String hostile = render(false, "safe\033[31mRED\033]52;c;c3RlYWw=\007\u202eEND\b\n");
        yes(!hostile.contains("\033") && !hostile.contains("\007") && !hostile.contains("\u202e"), "unsanitized terminal escape/control");
        String quoted = render(true, "```java\nString url = \"https://example.com\"; // comment\n```\n");
        yes(quoted.contains("\033[92m\"https://example.com\""), "url inside string incorrectly parsed as comment");
        StringBuilder huge = new StringBuilder();
        for (int i = 0; i < 20000; i++) huge.append("a");
        yes(render(false, huge.toString()).length() >= 20000, "large partial line lost data");
        yes(EliyaTerminalRenderer.supportsColor(Map.of("WT_SESSION", "abc"), false, "Windows 11", null), "Windows terminal detection");
        yes(!EliyaTerminalRenderer.supportsColor(Map.of(), true, "Windows 10", null), "legacy CMD must fall back safely");
        yes(EliyaTerminalRenderer.supportsColor(Map.of("VSCODE_PID", "123"), false, "Linux", null), "VS Code terminal detection");
        yes(EliyaTerminalRenderer.supportsColor(Map.of("IDEA_INITIAL_DIRECTORY", "project"), false, "Windows 11", null), "IDE terminal detection");
        yes(!EliyaTerminalRenderer.supportsColor(Map.of("NO_COLOR", "1", "WT_SESSION", "abc"), true, "Windows", null), "NO_COLOR ignored");
        yes(!EliyaTerminalRenderer.supportsColor(Map.of("TERM", "dumb"), true, "Linux", null), "dumb terminal should disable ANSI");
        yes(EliyaTerminalRenderer.supportsColor(Map.of("TERM", "dumb"), false, "Linux", true), "explicit --color not respected");
        yes(!EliyaTerminalRenderer.supportsColor(Map.of("WT_SESSION", "abc"), true, "Windows", false), "--no-color not respected");
        ByteArrayOutputStream events = new ByteArrayOutputStream();
        EliyaTerminalRenderer renderer = new EliyaTerminalRenderer(new PrintStream(events, true, StandardCharsets.UTF_8), true);
        renderer.activity("agent", "running", "Reading file");
        renderer.activity("agent", "running", "Reading file");
        renderer.activity("tests", "failed", "12 tests failed");
        renderer.text("Final answer");
        renderer.completion(true);
        String log = events.toString(StandardCharsets.UTF_8);
        yes(log.split("Reading file", -1).length == 2, "duplicate progress not suppressed");
        yes(log.contains("\033[91m"), "failure not red");
        yes(log.contains("Saved to Eliya conversation"), "completion notice missing");
        System.out.println("ELIYA127 renderer smoke: colors, Markdown, Java/JSON, tables, flow, streaming, CRLF, fallback and safety passed");
    }
}
