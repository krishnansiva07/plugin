#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../.."
TEMP_DIR="$(mktemp -d)"
trap 'rm -rf "$TEMP_DIR"' EXIT
javac --release 17 -encoding UTF-8 -d "$TEMP_DIR" \
  src/main/java/com/llmart/llm/cli/EliyaTerminalRenderer.java \
  qa/eliya127/TerminalRendererSmoke.java
java -cp "$TEMP_DIR" TerminalRendererSmoke
