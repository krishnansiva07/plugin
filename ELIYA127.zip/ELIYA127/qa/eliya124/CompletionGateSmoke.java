package com.llmart.llm.service;

import com.llmart.llm.dto.ProjectPatchRequest;
import java.nio.file.*;
import java.util.*;

public class CompletionGateSmoke {
    static void require(boolean yes, String error) { if (!yes) throw new AssertionError(error); }
    public static void main(String[] args) throws Exception {
        Path root = Files.createTempDirectory("eliya124-gate");
        try {
            String html = "<!doctype html><html><body><main><h1>Coverage Report</h1><p>" +
                "Evidence-backed content and a sufficiently long coverage summary for verification.".repeat(3) +
                "</p></main></body></html>";
            Files.writeString(root.resolve("unrelated.html"), html);
            Files.writeString(root.resolve("coverage-report.html"), html);
            AgentCompletionEvidence gate = new AgentCompletionEvidence("Create the final coverage-report.html HTML report");
            require(!gate.verify(root, List.of(new ProjectPatchRequest.ProjectPatchFile("unrelated.html",html))).passed(),
                    "Wrong HTML filename must never be accepted");
            require(gate.verify(root, List.of(new ProjectPatchRequest.ProjectPatchFile("coverage-report.html",html))).passed(),
                    "Correct HTML filename must be accepted when valid");
            require(!gate.hasSuccessfulInvestigationEvidence(), "No read evidence at start");
            gate.observe(Map.of("tool","read","status","error","detail","no permission"));
            require(!gate.hasSuccessfulInvestigationEvidence(), "Failed read must not count");
            gate.observe(Map.of("tool","read","status","success","detail","file evidence retrieved"));
            require(gate.hasSuccessfulInvestigationEvidence(), "Successful read must count");
            AgentCompletionEvidence source = new AgentCompletionEvidence("Read source.html and generate result.html HTML report");
            Files.writeString(root.resolve("result.html"), html);
            require(source.verify(root, List.of(new ProjectPatchRequest.ProjectPatchFile("result.html",html))).passed(),
                    "Source input HTML must not become an output contract");
            require(McpPromptGate.explicitlyRequested("compare using Jira MCP"), "Explicit MCP should work");
            require(!McpPromptGate.explicitlyRequested("compare Jira files"), "Non-explicit MCP must stay disabled");
            require(AgentConversationIntent.isFastReadOnly("Analyze the mapped workspace architecture and explain the flow"),
                    "Analysis without deliverable should remain a fast read-only task");
            require(!AgentConversationIntent.isFastReadOnly("Analyze this project and give the findings as a PDF file"),
                    "Explicit PDF output must use Agent artifact tools");
            require(!AgentConversationIntent.isFastReadOnly("Review code and save findings.md"),
                    "Explicit Markdown output must use Agent artifact tools");
            require(AgentConversationIntent.isFastReadOnly("How do I create a PDF file?"),
                    "Tutorial about a file should remain read-only");
            System.out.println("ELIYA124 completion/evidence smoke: 11 assertions passed");
        } finally {
            try (var stream = Files.list(root)) { stream.forEach(path -> { try { Files.deleteIfExists(path); } catch (Exception ignored) { } }); }
            Files.deleteIfExists(root);
        }
    }
}
