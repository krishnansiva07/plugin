# ELIYA v125 — MCP/RAG project builders and verified workspace learning

**Base:** ELIYA v124 (retains Analyse → Agent handoff, workspace references, vision, OpenCode JSON importer, UI code/Markdown fix, and completion evidence hardening).

**Deliverable:** Complete Java 17 / Spring Boot Maven source project. **Not a compiled or runtime-tested Spring Boot JAR.** Maven and its dependency cache were unavailable in the packaging environment. Do not represent this as a fully verified production release until the full Maven and live application integration tests have passed on your machine.

## What's new

### Native Agent tool: `mcp_scaffold`

- Generates a runnable **Python 3.10+ MCP stdio starter** in a new directory under the selected *writable* workspace (`eliya-generated/<name>-mcp` by default).
- Includes a JSON-RPC server, `initialize`, `ping`, `tools/list`, `tools/call`, a safe sample read-only `search_catalog` tool, `catalog.json`, independent Python tests, documentation, `AGENTS.md`, and an **disabled-by-default** OpenCode MCP sample configuration.
- The Agent can then customize the actual server and tools with normal editing tools. Generation **does not** connect to or enable external MCP servers; remote MCP use continues to require the existing explicit user request and master switch.
- Creation is **new-directory-only**. Existing destinations, absolute paths, parent escapes and symlinked ancestors are rejected. Generated files are read back and compared before returning success; the caller must still run and report tests.

### Native Agent tool: `rag_scaffold`

- Generates a standalone **Python 3.10+ RAG starter** under `eliya-generated/<name>-rag`, including tests and docs.
- Incremental document ingestion with changed/unchanged/deleted-file tracking; SQLite FTS5/BM25 lexical retrieval combined with an **offline hashed lexical vector** baseline.
- Optional *real* semantic embeddings and answer synthesis via an explicitly configured OpenAI-compatible HTTPS API. Offline hashed vectors **are not semantic embeddings**; without a chat model, `ask` returns source evidence instead of a generated answer.
- CLI + local-only HTTP API (`127.0.0.1`) with bounded requests. Document type support is text and source code; additional PDF/Office parsing is a future customization task.
- Local-first behavior; no network calls unless the user configures the provider environment variables.

### Verified workspace learning

- `VerifiedLearningMemoryService` persists lessons outside the workspace in the app's data directory, keyed by canonical workspace path (with case preserved).
- Only successfully completed, verified, mutating Agent runs are eligible learning candidates. A reviewer must **explicitly approve** a short reusable lesson and at least one source file actually modified by that run.
- SHA-256 fingerprints of evidence source files prevent **stale/deleted** facts from being included in later Agent context. The user can review or revoke any saved lesson in Settings.
- Existing Agent tool `learning_recall` exposes current lessons for manual use; relevant approved lessons are inserted as clearly labeled *advisory data*, never as automatic instruction overrides.
- **This is persistence and verified retrieval, not model fine-tuning or automatic learning of new model weights.** Promotion from execution to a durable lesson requires user approval.

### UX, safety and pipeline

- Learning section in Settings: refresh verified runs, choose run, category, summary, evidence paths, explicit approval, saved lesson list/stale flag and revoke button. Content is rendered as text, not raw HTML.
- Registered tools participate in the existing Agent permissions, mutation auditing, workspace index refresh, verifier-required revisions, progress and terminal event flow.
- Linux CI runs source-level v125 tests in addition to existing v124 and Maven tests. The original Windows/macOS Java build matrix is preserved.

## Build Eliya executable locally

From the extracted `ELIYA125` root folder, use JDK 17 and an internet-accessible Maven repository / approved enterprise mirror:

```bash
mvn -B -Pfull-tests -Dmaven.test.skip=false clean verify
java -jar target/eliya.jar
```

On Windows, use the equivalent Maven command in PowerShell or `build-jar-windows.cmd`. If Maven isn't installed, `mvnw` and `mvnw.cmd` try to download Maven first, subject to your enterprise network and artifact repository policy.

## Source-level verification on Linux/macOS

```bash
bash qa/eliya125/run.sh
```

Requires JDK 17+, Node 22+, Python 3.10+ with SQLite FTS5. The test runner compiles the isolated builder, tool registry and learning implementation with local Spring/Jackson stubs; it is **not a substitute for a full dependency compilation**. It also executes the new Python starter tests and the existing frontend/completion/handoff checks.

## Sample user prompts inside Eliya

**MCP builder** (select writable workspace → Agent):

> Create a custom MCP server named `jira-coverage` that exposes a read-only `find_missing_test_cases` tool. Use the native MCP starter if suitable, adapt the sample catalog logic for our real Jira mapping (do not connect to Jira unless I explicitly authorize Jira MCP or the network), run tests, and deliver README plus example OpenCode JSON. Do not mark complete unless tool invocation is verified.

**RAG builder** (select writable workspace → Agent):

> Create a RAG application named `selenium-knowledge` for our Java Selenium framework. Ingest Java source, Cucumber feature files and Markdown; provide relevant source references, incremental reindexing and a clear retrieval evaluation. Only use embeddings if the provider is configured, run tests, and do not call a remote model without my approval.

**Learning review** (after a successfully verified Agent run):

> Open Settings → Verified learning → Refresh verified runs → select the run → enter a reviewed lesson and one or more modified evidence file paths → explicitly approve and save. Later Agent runs may retrieve the non-stale lesson.

## Known gaps and acceptance criteria

1. **Full Spring Boot compilation and executable-JAR launch not verified** here. Run Maven and the app on JDK 17 locally, with real LLM credentials as appropriate.
2. Builders produce **functional starter projects**, not arbitrary production-certified integrations. The Agent must customize the connectors, permissions, domain behavior, documentation and real integration tests to the user's requirements. A Java MCP starter is not bundled; Java-specific MCP generation still uses normal Agent code generation.
3. Live Jira/GitLab/Confluence MCP connectivity, deployment, external providers, enterprise authentication, performance under load, Windows/macOS runtime behavior and RAG retrieval precision are **not tested** in this release.
4. Generated Python RAG local API is **not** ready to expose publicly; provide authentication, rate limiting, tenancy separation, safe untrusted-source parsing and deployment controls before doing so.
5. Self-learning is **human-approved and evidence-bound**, not fully autonomous skill rewriting; it does not change LLM model parameters.
6. If agent execution appears complete without a verified build/integration step, the task must report the incomplete or unverified status instead of claiming full success. Recheck in the live UI.
