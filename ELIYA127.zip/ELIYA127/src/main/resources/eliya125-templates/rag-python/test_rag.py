import json
import tempfile
import unittest
from pathlib import Path
from rag import RagIndex, local_vector, chunk_document


class RagTests(unittest.TestCase):
    def test_incremental_ingestion_search_delete(self):
        with tempfile.TemporaryDirectory() as tmp:
            base = Path(tmp)
            docs = base / "docs"
            docs.mkdir()
            (docs / "alpha.md").write_text("Selenium framework supports Java automated browser testing.")
            (docs / "beta.md").write_text("Python REST API tests use requests.")
            index = RagIndex(base / "state" / "knowledge.sqlite3")
            try:
                result = index.ingest(docs)
                self.assertEqual(2, result["indexed"])
                self.assertEqual(0, index.ingest(docs)["indexed"])
                matches = index.search("Selenium browser Java")
                self.assertEqual("alpha.md", matches[0]["source"])
                self.assertTrue(index.ask("Selenium")["sources"])
                (docs / "alpha.md").unlink()
                self.assertEqual(1, index.ingest(docs)["deleted"])
                self.assertTrue(all(entry["source"] != "alpha.md" for entry in index.search("Selenium")))
                (docs / "beta.md").write_text("Updated Python regression testing docs")
                self.assertEqual(1, index.ingest(docs)["indexed"])
            finally:
                index.close()

    def test_limits(self):
        self.assertEqual(256, len(local_vector("alpha beta")))
        self.assertEqual([], chunk_document(""))
        with tempfile.TemporaryDirectory() as tmp:
            idx = RagIndex(Path(tmp) / "knowledge.sqlite3")
            try:
                with self.assertRaises(ValueError):
                    idx.search("")
            finally:
                idx.close()


if __name__ == "__main__":
    unittest.main()
