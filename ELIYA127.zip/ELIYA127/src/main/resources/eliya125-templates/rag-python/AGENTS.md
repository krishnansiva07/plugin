# RAG implementation instructions

- Preserve document ACLs; never expose data to an embeddings or LLM provider unless configured and authorized.
- Every answer must cite real indexed chunks and say when evidence is insufficient.
- Evaluate retrieval on a labeled query set before claiming semantic accuracy.
- Do not silently reuse embeddings after changing models; re-index and validate deletion propagation.
- Keep the local HTTP server on loopback. Add authentication and security review before any network deployment.
