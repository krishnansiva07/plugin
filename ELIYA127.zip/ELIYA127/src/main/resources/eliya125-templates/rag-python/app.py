"""Local-only HTTP + CLI entrypoint for generated RAG application (Python 3.10+)."""
import argparse
import json
import os
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from rag import RagIndex

BASE = Path(__file__).resolve().parent
DB = BASE / "state" / "knowledge.sqlite3"
DOCS = BASE / "docs"


def run(operation, question=""):
    db = RagIndex(DB)
    try:
        if operation == "ingest":
            return db.ingest(DOCS)
        if operation == "ask":
            return db.ask(question)
        raise ValueError("Unknown operation")
    finally:
        db.close()


class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path == "/health":
            self.respond(200, {"status": "ok"})
        else:
            self.respond(404, {"error": "Not found"})

    def do_POST(self):
        if self.path not in {"/ingest", "/ask"}:
            return self.respond(404, {"error": "Not found"})
        try:
            size = int(self.headers.get("Content-Length", "0"))
            if size < 0:
                return self.respond(400, {"error": "Invalid request length"})
            if size > 8192:
                return self.respond(413, {"error": "Request too large"})
            body = json.loads(self.rfile.read(size)) if size else {}
            if not isinstance(body, dict):
                raise ValueError("Body must be a JSON object")
            return self.respond(200, run("ingest" if self.path == "/ingest" else "ask", body.get("question", "")))
        except (ValueError, RuntimeError) as exc:
            return self.respond(400, {"error": str(exc)[:200]})
        except Exception:
            return self.respond(500, {"error": "Request failed"})

    def respond(self, status, body):
        payload = json.dumps(body, ensure_ascii=False).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(payload)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(payload)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("operation", choices=["ingest", "ask", "serve"])
    parser.add_argument("question", nargs="?", default="")
    args = parser.parse_args()
    if args.operation == "serve":
        port = int(os.environ.get("ELIYA_RAG_PORT", "8765"))
        print("Local RAG API listening at http://127.0.0.1:" + str(port), flush=True)
        ThreadingHTTPServer(("127.0.0.1", port), Handler).serve_forever()
    else:
        print(json.dumps(run(args.operation, args.question), indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
