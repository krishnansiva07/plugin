# __PROJECT_NAME__: RAG starter

Python 3.10+ standalone Retrieval-Augmented Generation application. Zero runtime dependencies for text/source documents and offline hybrid **FTS5/BM25 + hashed lexical vector** retrieval. It offers **real semantic embeddings** only when an OpenAI-compatible embedding API is explicitly configured. LLM synthesis is optional. **Do not describe offline hashed vectors as semantic embeddings.**

1. `python app.py ingest` — build or incrementally update the SQLite index from `docs/`, detect changed and deleted documents.
2. `python app.py ask "What is in the knowledge base?"` — return evidence with source/row IDs; without a configured LLM this is retrieval, not generation.
3. `python app.py serve` — optional local-only HTTP API, `POST /ask` (`{"question":"..."}`) or `POST /ingest` (`{}`), plus `GET /health`.
4. `python -m unittest discover -v` — run ingestion/deletion/hybrid search tests.

For semantic retrieval and generated answers, set `ELIYA_RAG_BASE_URL` (HTTPS OpenAI-compatible API endpoint ending at `/v1`), `ELIYA_RAG_API_KEY`, `ELIYA_RAG_EMBED_MODEL`, and optionally `ELIYA_RAG_CHAT_MODEL`. Tokens and document excerpts will be sent to the configured service, so obtain data-owner approval first. Embedding model changes trigger incremental re-indexing. Do not commit credentials. Document types supported without dependencies: Markdown, TXT, source code, JSON, YAML, CSV, HTML. PDF/Office ingestion requires a vetted additional parser and tests. FTS5 must be enabled in your Python SQLite build.

**Production gaps**: authentication, access control, multiuser isolation, provider retry/rate limits, parser sanitization for untrusted documents, proper semantic evaluation sets, deployment hardening, and enterprise-scale vector database. The local HTTP API intentionally binds to `127.0.0.1` and is not suitable for public exposure.
