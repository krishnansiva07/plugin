"""Run: python -m unittest discover -v"""
import json
import subprocess
import sys
import unittest
from pathlib import Path
import server


class ServerTests(unittest.TestCase):
    def test_initialize(self):
        response = server.dispatch({"jsonrpc": "2.0", "id": 1, "method": "initialize",
                                    "params": {"protocolVersion": "2025-06-18", "capabilities": {}, "clientInfo": {"name": "test", "version": "1"}}})
        self.assertEqual("2025-06-18", response["result"]["protocolVersion"])
        self.assertEqual("__PROJECT_NAME__", response["result"]["serverInfo"]["name"])

    def test_tool(self):
        response = server.dispatch({"jsonrpc": "2.0", "id": 2, "method": "tools/call",
                                    "params": {"name": "search_catalog", "arguments": {"query": "alpha"}}})
        self.assertIn("alpha", response["result"]["content"][0]["text"])
        self.assertNotIn("beta", response["result"]["content"][0]["text"])

    def test_invalid_tool(self):
        response = server.dispatch({"jsonrpc": "2.0", "id": 2, "method": "tools/call",
                                    "params": {"name": "unknown", "arguments": {"query": "a"}}})
        self.assertTrue(response["result"]["isError"])

    def test_notification(self):
        self.assertIsNone(server.dispatch({"jsonrpc": "2.0", "method": "notifications/initialized"}))

    def test_stdio_process(self):
        reqs = [
            {"jsonrpc": "2.0", "id": 1, "method": "initialize", "params": {"protocolVersion": "2025-06-18"}},
            {"jsonrpc": "2.0", "id": 2, "method": "tools/list"},
            {"jsonrpc": "2.0", "method": "notifications/initialized"},
            {"jsonrpc": "2.0", "id": 3, "method": "tools/call", "params": {"name": "search_catalog", "arguments": {"query": "beta"}}},
        ]
        proc = subprocess.run([sys.executable, "-u", str(Path(__file__).with_name("server.py"))],
                              input="\n".join(json.dumps(r) for r in reqs)+"\n",
                              capture_output=True, text=True, timeout=5)
        self.assertEqual(0, proc.returncode, proc.stderr)
        responses = [json.loads(line) for line in proc.stdout.splitlines()]
        self.assertEqual([1, 2, 3], [r["id"] for r in responses])
        self.assertEqual("search_catalog", responses[1]["result"]["tools"][0]["name"])


if __name__ == "__main__":
    unittest.main()
