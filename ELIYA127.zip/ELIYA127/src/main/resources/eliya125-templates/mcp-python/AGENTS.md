# MCP server instructions

- Keep stdout exclusively for MCP JSON-RPC. Keep all filesystem and remote access allowlisted.
- Add the exact requested MCP tools and validate argument schemas, errors, permissions, and disconnected behavior.
- Prefer stdio for local use; adding HTTP requires authentication, origin checking and a deployment review.
- Run `python -m unittest discover -v` and a real MCP Inspector handshake before claiming production readiness.
- Do not implicitly connect or enable any MCP tool when the prompt doesn't explicitly authorize its use.
