package com.llmart.llm;

import com.llmart.llm.config.AppPathResolver;
import com.llmart.llm.cli.EliyaCliLauncher;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LlmApplication {
    public static void main(String[] args) {
        AppPathResolver.initializeSystemProperties(LlmApplication.class);
        if (args.length > 0 && "--eliya-cli".equals(args[0])) {
            EliyaCliLauncher.run(args);
            return;
        }
        SpringApplication.run(LlmApplication.class, args);
    }
}
