package com.llmart.llm.service;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.time.Instant;
import java.util.List;
import java.util.Map;

/**
 * Zero-LLM-call, Spec Kit-inspired persistent task contract for Eliya's existing plan.
 * Does not install the Specify CLI or modify the user's project/repository. It persists
 * artifacts in Eliya runtime data and checkpoint updates only on plan transitions.
 */
final class SpecFlowJournal {
    private final Path parent;
    private final String runId;
    private String objective = "";
    private boolean started;

    SpecFlowJournal(String runId) {
        this.runId = runId == null ? "unknown" : runId.replaceAll("[^A-Za-z0-9_-]", "_");
        this.parent = Path.of(System.getProperty("eliya.specFlowDir", "./data/spec-flows"))
                .toAbsolutePath().normalize().resolve(this.runId);
    }

    static boolean enabled(String objective, int planSize) {
        String task = objective == null ? "" : objective.toLowerCase(java.util.Locale.ROOT);
        return planSize >= 2 || task.contains("spec flow") || task.contains("spec-driven") ||
                ((task.contains("jira") || task.contains("mcp")) && task.contains("report"));
    }

    void begin(AgentRunService.AgentRun run) throws IOException {
        if (!enabled(run.objective(), run.planSize())) return;
        objective = run.objective();
        Files.createDirectories(parent);
        write("spec.md", "# Task specification\n\n" +
                "Source: user request in conversation " + run.conversationId() + ".\n\n" +
                "## Requested outcome\n\n" + objective.strip() + "\n\n" +
                "## Acceptance criteria\n\n" +
                "- [ ] Every requested external source has successful retrieval evidence.\n" +
                "- [ ] Mapped workspace is used for project-specific comparisons.\n" +
                "- [ ] Every requested artifact exists and can be independently read.\n" +
                "- [ ] Final status reflects verified output and unresolved tool errors.\n\n" +
                "Clarifications and explicit user decisions remain in the originating conversation.\n");
        write("plan.md", "# Execution plan\n\n" + run.planText() + "\n\n" +
                "Plan source: Eliya approved native plan, not an additional LLM planning call.\n");
        started = true;
        checkpoint(run, "running", "Plan initialized");
    }

    void checkpoint(AgentRunService.AgentRun run, String status, String detail) throws IOException {
        if (!started) return;
        StringBuilder tasks = new StringBuilder("# Task execution checklist\n\n");
        for (Map<String,Object> step : run.planSnapshot()) {
            String stepStatus = String.valueOf(step.getOrDefault("status", "pending"));
            tasks.append("- [").append("completed".equals(stepStatus) ? 'x' : ' ').append("] ")
                    .append(sanitizeLine(String.valueOf(step.getOrDefault("text", "Task")), 600))
                    .append(" — ").append(stepStatus).append('\n');
        }
        tasks.append("\nThe [x] marker reflects the native agent's recorded step status; it is NOT independent deliverable verification.\n");
        write("tasks.md", tasks.toString());
        write("state.txt", "runId=" + runId + "\nstatus=" + sanitizeLine(status, 50) +
                "\nat=" + Instant.now() + "\nprogress=" + run.progressPercent() +
                "\nlastMessage=" + sanitizeLine(detail, 400) +
                "\nworkspaceProjectId=" + sanitizeLine(run.projectId(), 150) + "\n");
    }

    boolean started() { return started; }
    String location() { return parent.toString(); }

    private static String sanitizeLine(String text, int max) {
        if (text == null) return "";
        String value = text.replaceAll("[\\r\\n\\t]+", " ").strip();
        return value.length() > max ? value.substring(0, max) : value;
    }

    private void write(String name, String content) throws IOException {
        Path target = parent.resolve(name);
        Path tmp = Files.createTempFile(parent, "spec-flow-", ".tmp");
        try {
            Files.writeString(tmp, content, StandardCharsets.UTF_8);
            try { Files.move(tmp, target, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (AtomicMoveNotSupportedException unsupported) { Files.move(tmp, target, StandardCopyOption.REPLACE_EXISTING); }
        } finally { Files.deleteIfExists(tmp); }
    }
}
