package com.llmart.llm.cli;

import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Dependency-free ANSI/Markdown renderer for the OS terminal CLI (not the browser terminal).
 * Keeps Markdown state across independently streamed SSE tokens, limits buffering, and never
 * relays terminal escape sequences supplied by a model or tool.  Not a terminal emulator.
 */
public final class EliyaTerminalRenderer {
    private static final String RESET = "\033[0m";
    private static final String BLUE = "\033[1;94m";
    private static final String CYAN = "\033[96m";
    private static final String GREEN = "\033[92m";
    private static final String YELLOW = "\033[93m";
    private static final String RED = "\033[91m";
    private static final String PURPLE = "\033[95m";
    private static final String GRAY = "\033[90m";
    private static final String BOLD = "\033[1m";
    private static final Pattern HEADING = Pattern.compile("^(#{1,6})\\s+(.+)$");
    private static final Pattern FENCE = Pattern.compile("^\\s*(`{3,}|~{3,})([^`~]*)$");
    private static final Pattern BULLET = Pattern.compile("^(\\s*)([-*+] |\\d+[.)] )(.+)$");
    private static final Pattern RULE = Pattern.compile("^\\s*(?:-{3,}|\\*{3,}|_{3,})\\s*$");
    private static final Pattern TABLE_SEPARATOR = Pattern.compile("^\\s*\\|?\\s*:?-{3,}:?\\s*(?:\\|\\s*:?-{3,}:?\\s*)+\\|?\\s*$");
    private static final Pattern FLOW_DIRECTION = Pattern.compile("^\\s*(?:graph|flowchart)\\s+(TB|TD|BT|LR|RL)\\s*$", Pattern.CASE_INSENSITIVE);
    private static final Pattern INLINE = Pattern.compile("(`[^`\\n]+`|\\*\\*[^*\\n]+\\*\\*|__[^_\\n]+__|(?<!\\*)\\*[^*\\n]+\\*(?!\\*)|\\[[^\\]\\n]+\\]\\([^)\\n]+\\))");
    private static final Set<String> KEYWORDS = new HashSet<>(Arrays.asList((
            "abstract as assert async await break boolean byte case catch char class const continue " +
            "def default delete do double elif else enum except export extends false final finally float " +
            "for from function global if implements import in instanceof int interface is lambda let long " +
            "module native new null package pass private protected public raise record return sealed self " +
            "short static strictfp super switch synchronized this throw throws transient true try type " +
            "typeof var void volatile while with yield String List Map Set Path Files WebDriver ThreadLocal " +
            "SELECT FROM WHERE JOIN LEFT RIGHT INNER OUTER GROUP BY ORDER LIMIT INSERT UPDATE DELETE " +
            "CREATE TABLE AND OR NOT NULL AS DISTINCT VALUES INTO SET ON HAVING WITH UNION END THEN " +
            "flowchart graph subgraph end stateDiagram sequenceDiagram participant actor classDiagram"
    ).split("\\s+")));

    private final PrintStream out;
    private final boolean color;
    private final StringBuilder incomplete = new StringBuilder();
    private final List<String> table = new ArrayList<>();
    private boolean fenced;
    private char fenceMarker;
    private int fenceLength;
    private String language = "text";
    private boolean blockComment;
    private boolean previousCarriageReturn;
    private boolean lastNewline = true;
    private String previousStatus = "";

    public EliyaTerminalRenderer(PrintStream out, boolean color) {
        this.out = out;
        this.color = color;
    }

    public static EliyaTerminalRenderer system(Boolean override) {
        return new EliyaTerminalRenderer(System.out, supportsColor(System.getenv(), System.console() != null,
                System.getProperty("os.name", ""), override));
    }

    /** --color and --no-color override auto-detection. NO_COLOR and TERM=dumb disable auto. */
    public static boolean supportsColor(Map<String,String> env, boolean hasConsole, String os, Boolean override) {
        if (override != null) return override;
        if (env.containsKey("NO_COLOR")) return false;
        if ("0".equals(env.get("CLICOLOR"))) return false;
        if ("dumb".equalsIgnoreCase(env.getOrDefault("TERM", ""))) return false;
        if ("1".equals(env.get("CLICOLOR_FORCE")) || "1".equals(env.get("FORCE_COLOR"))) return true;
        boolean modernTerminal = hasValue(env, "WT_SESSION") || hasValue(env, "ANSICON") ||
                "ON".equalsIgnoreCase(env.get("ConEmuANSI")) || hasValue(env, "VSCODE_PID") ||
                hasValue(env, "TERM_PROGRAM") || hasValue(env, "COLORTERM") ||
                hasValue(env, "JETBRAINS_IDE") || hasValue(env, "IDEA_INITIAL_DIRECTORY") ||
                env.getOrDefault("TERMINAL_EMULATOR", "").toLowerCase(Locale.ROOT).contains("jetbrains");
        // Old Windows cmd.exe may not enable VT processing. Prefer safe plain-text
        // unless the environment advertises an ANSI-aware terminal; --color forces it.
        if (os.toLowerCase(Locale.ROOT).contains("win")) return modernTerminal;
        return modernTerminal || (hasConsole && !env.getOrDefault("TERM", "").isBlank());
    }

    private static boolean hasValue(Map<String,String> env, String key) {
        return env.containsKey(key) && !env.get(key).isBlank();
    }

    /** Stream tokens without discarding Markdown boundaries across token chunks. */
    public void text(String token) {
        if (token == null || token.isEmpty()) return;
        String safe = safe(token);
        for (int i = 0; i < safe.length(); i++) {
            char ch = safe.charAt(i);
            if (ch == '\n' && previousCarriageReturn) {
                previousCarriageReturn = false;
                continue;
            }
            previousCarriageReturn = ch == '\r';
            if (ch == '\n' || ch == '\r') {
                renderLine(incomplete.toString());
                incomplete.setLength(0);
            } else {
                incomplete.append(ch);
                // Limit memory and make very long unbroken model paragraphs visible quickly.
                // Leave Markdown/code tokens intact for ordinary-sized lines.
                if (incomplete.length() >= 512) {
                    flushTable();
                    String chunk = incomplete.toString();
                    incomplete.setLength(0);
                    print(fenced ? syntax(chunk, language) : inline(chunk));
                }
            }
        }
        out.flush();
    }

    /** Print a separate execution event without running into the middle of a streamed line. */
    public void activity(String mode, String status, String detail) {
        String clean = safe(detail == null ? "" : detail).strip();
        if (clean.isEmpty()) return;
        String kind = (status == null ? "running" : status.toLowerCase(Locale.ROOT));
        String identity = mode + ":" + kind + ":" + clean;
        if (identity.equals(previousStatus)) return;
        previousStatus = identity;
        flushPartial();
        flushTable();
        String label = mode == null ? "ELIYA" : mode.toUpperCase(Locale.ROOT);
        String tone = kind.matches(".*(fail|error|reject|stop|cancel).*?") ? RED :
                kind.matches(".*(warn|approval|pending|wait).*?") ? YELLOW :
                kind.matches(".*(success|complete|done|pass).*?") ? GREEN : CYAN;
        String icon = tone.equals(RED) ? "!" : tone.equals(YELLOW) ? "!" : tone.equals(GREEN) ? "+" : ">";
        print(ansi(tone, "[" + icon + " " + label + "]") + " " + clean + "\n");
    }

    public void prompt(String mode) {
        String color = "agent".equalsIgnoreCase(mode) ? GREEN : BLUE;
        print(ansi(color, "eliya:" + safe(mode) + "> "));
        out.flush();
    }

    public void banner(String mode, String workspace) {
        flushPartial();
        flushTable();
        print(ansi(GREEN, "ELIYA") + "  " + ansi(BLUE, safe(mode.toUpperCase(Locale.ROOT))) +
                "\n" + ansi(GRAY, "Workspace: ") + ansi(CYAN, safe(workspace)) + "\n\n");
    }

    public void completion(boolean saved) {
        endResponse();
        if (saved) print(ansi(GREEN, "[+ Saved to Eliya conversation]") + "\n");
    }

    public void error(String message) {
        endResponse();
        print(ansi(RED, "[! ERROR]") + " " + safe(message) + "\n");
    }

    /** Complete or interrupted response: flush the tail exactly once and restore plain terminal state. */
    public void endResponse() {
        flushPartial();
        flushTable();
        if (fenced) {
            fenced = false;
            blockComment = false;
        }
        if (!lastNewline) print("\n");
        out.flush();
    }

    private void flushPartial() {
        if (!incomplete.isEmpty()) {
            String line = incomplete.toString();
            incomplete.setLength(0);
            // End-of-stream is allowed to contain a complete Markdown line without final LF.
            renderLine(line);
        }
    }

    private void renderLine(String line) {
        Matcher fence = FENCE.matcher(line);
        if (fence.matches()) {
            String marker = fence.group(1);
            if (!fenced) {
                flushTable();
                fenced = true;
                fenceMarker = marker.charAt(0);
                fenceLength = marker.length();
                blockComment = false;
                language = fence.group(2).strip().split("\\s+", 2)[0].toLowerCase(Locale.ROOT);
                if (language.isEmpty()) language = "text";
                print(ansi(PURPLE, "── " + language.toUpperCase(Locale.ROOT) + " ──") + "\n");
                return;
            }
            if (marker.charAt(0) == fenceMarker && marker.length() >= fenceLength && fence.group(2).isBlank()) {
                fenced = false;
                blockComment = false;
                return;
            }
        }
        if (fenced) {
            print("  " + syntax(line, language) + "\n");
            return;
        }
        if (looksLikeTable(line)) {
            table.add(line);
            if (table.size() >= 100 || table.stream().mapToInt(String::length).sum() > 12000) flushTable();
            return;
        }
        flushTable();
        Matcher heading = HEADING.matcher(line);
        if (heading.matches()) {
            print(ansi(BLUE, heading.group(2).strip()) + "\n");
        } else if (RULE.matcher(line).matches()) {
            print(ansi(GRAY, "────────────────────────────────────") + "\n");
        } else if (line.startsWith("> ")) {
            print(ansi(GRAY, "│ ") + inline(line.substring(2)) + "\n");
        } else if (line.matches("(?i)^\\s*(?:warning|error|failed|failure|danger|\\u26a0).*")) {
            print(ansi(RED, line) + "\n");
        } else if (line.matches("(?i)^\\s*(?:success|passed|completed|\\u2713).*")) {
            print(ansi(GREEN, line) + "\n");
        } else {
            Matcher bullet = BULLET.matcher(line);
            if (bullet.matches()) {
                print(bullet.group(1) + ansi(CYAN, bullet.group(2).strip()) + " " + inline(bullet.group(3)) + "\n");
            } else {
                print(inline(line) + "\n");
            }
        }
    }

    private boolean looksLikeTable(String line) {
        if (TABLE_SEPARATOR.matcher(line).matches()) return true;
        if (!line.contains("|")) return false;
        // Markdown table line: at least two explicit cells, delimited on both ends or inside.
        String normalized = line.strip();
        return (normalized.startsWith("|") && normalized.indexOf('|', 1) >= 0) ||
                (normalized.chars().filter(c -> c == '|').count() >= 2);
    }

    private void flushTable() {
        if (table.isEmpty()) return;
        if (table.size() == 1 && !table.get(0).strip().startsWith("|")) {
            String line = table.get(0);
            table.clear();
            print(inline(line) + "\n");
            return;
        }
        List<List<String>> rows = new ArrayList<>();
        int columns = 0;
        for (String line : table) {
            if (TABLE_SEPARATOR.matcher(line).matches()) continue;
            List<String> cells = splitCells(line);
            columns = Math.max(columns, cells.size());
            rows.add(cells);
        }
        table.clear();
        if (rows.isEmpty()) return;
        columns = Math.min(columns, 8);
        int[] widths = new int[columns];
        for (List<String> row : rows) for (int col = 0; col < Math.min(columns, row.size()); col++) {
            widths[col] = Math.max(widths[col], Math.min(38, width(row.get(col))));
        }
        for (int r = 0; r < rows.size(); r++) {
            List<String> cells = rows.get(r);
            StringBuilder line = new StringBuilder();
            for (int c = 0; c < columns; c++) {
                String cell = c < cells.size() ? cells.get(c) : "";
                String clipped = clip(cell, 38);
                String padded = clipped + " ".repeat(Math.max(0, widths[c] - width(clipped)));
                line.append(r == 0 ? ansi(BOLD, padded) : inline(padded));
                if (c < columns - 1) line.append(ansi(GRAY, " │ "));
            }
            print(line.toString() + "\n");
            if (r == 0 && rows.size() > 1) {
                StringBuilder divider = new StringBuilder();
                for (int c = 0; c < columns; c++) {
                    divider.append("─".repeat(Math.max(1, widths[c])));
                    if (c < columns - 1) divider.append("─┼─");
                }
                print(ansi(GRAY, divider.toString()) + "\n");
            }
        }
    }

    private static List<String> splitCells(String raw) {
        String line = raw.strip();
        if (line.startsWith("|")) line = line.substring(1);
        if (line.endsWith("|")) line = line.substring(0, line.length() - 1);
        List<String> result = new ArrayList<>();
        for (String part : line.split("(?<!\\\\)\\|", -1)) result.add(part.replace("\\\\|", "|").strip());
        return result;
    }

    private static int width(String text) { return text.codePointCount(0, text.length()); }

    private static String clip(String text, int max) {
        if (width(text) <= max) return text;
        return text.substring(0, text.offsetByCodePoints(0, Math.max(1, max - 1))) + "…";
    }

    private String inline(String content) {
        Matcher m = INLINE.matcher(content);
        StringBuilder result = new StringBuilder();
        int index = 0;
        while (m.find()) {
            result.append(content, index, m.start());
            String t = m.group();
            if (t.startsWith("`")) result.append(ansi(GREEN, t.substring(1, t.length() - 1)));
            else if (t.startsWith("**") || t.startsWith("__"))
                result.append(ansi(BOLD, t.substring(2, t.length() - 2)));
            else if (t.startsWith("*")) result.append(ansi(BOLD, t.substring(1, t.length() - 1)));
            else if (t.startsWith("[")) {
                int pivot = t.indexOf("](");
                result.append(ansi(CYAN, t.substring(1, pivot))).append(" (")
                        .append(ansi(GRAY, t.substring(pivot + 2, t.length() - 1))).append(")");
            } else result.append(t);
            index = m.end();
        }
        result.append(content.substring(index));
        return result.toString();
    }

    /** Basic lexical coloring for common source formats; no external highlighter or subprocess. */
    private String syntax(String code, String lang) {
        if ("text".equals(lang) || "plain".equals(lang) || "output".equals(lang)) return code;
        if ("mermaid".equals(lang) || "flow".equals(lang)) return flow(code);
        if ("diff".equals(lang) || "patch".equals(lang)) {
            if (code.startsWith("+++ ") || code.startsWith("--- ") || code.startsWith("@@")) return ansi(CYAN, code);
            if (code.startsWith("+")) return ansi(GREEN, code);
            if (code.startsWith("-")) return ansi(RED, code);
            return code;
        }
        StringBuilder result = new StringBuilder();
        boolean shell = Set.of("bash", "sh", "shell", "zsh", "powershell", "ps1", "python", "py", "yaml", "yml", "toml").contains(lang);
        boolean sql = "sql".equals(lang);
        boolean json = Set.of("json", "jsonc").contains(lang);
        for (int i = 0; i < code.length();) {
            char ch = code.charAt(i);
            if (blockComment) {
                int end = code.indexOf("*/", i);
                if (end < 0) { result.append(ansi(GRAY, code.substring(i))); break; }
                result.append(ansi(GRAY, code.substring(i, end + 2)));
                i = end + 2; blockComment = false; continue;
            }
            if (code.startsWith("/*", i)) { blockComment = true; continue; }
            if (code.startsWith("//", i) && !json || shell && ch == '#' || sql && code.startsWith("--", i)) {
                result.append(ansi(GRAY, code.substring(i))); break;
            }
            if (ch == '"' || ch == '\'' || ch == '`') {
                int start = i++;
                while (i < code.length()) {
                    if (code.charAt(i) == '\\' && i + 1 < code.length()) { i += 2; continue; }
                    if (code.charAt(i++) == ch) break;
                }
                String literal = code.substring(start, i);
                boolean isKey = json && code.substring(i).stripLeading().startsWith(":");
                result.append(ansi(isKey ? PURPLE : GREEN, literal));
                continue;
            }
            if (Character.isDigit(ch) && (i == 0 || !Character.isLetterOrDigit(code.charAt(i - 1)))) {
                int end = i + 1;
                while (end < code.length() && (Character.isLetterOrDigit(code.charAt(end)) || code.charAt(end) == '.')) end++;
                result.append(ansi(YELLOW, code.substring(i, end)));
                i = end; continue;
            }
            if (Character.isLetter(ch) || ch == '_') {
                int end = i + 1;
                while (end < code.length() && (Character.isLetterOrDigit(code.charAt(end)) || code.charAt(end) == '_')) end++;
                String word = code.substring(i, end);
                result.append(KEYWORDS.contains(word) || KEYWORDS.contains(word.toUpperCase(Locale.ROOT))
                        ? ansi(PURPLE, word) : word);
                i = end; continue;
            }
            result.append(ch); i++;
        }
        return result.toString();
    }

    private String flow(String line) {
        Matcher direction = FLOW_DIRECTION.matcher(line);
        if (direction.matches()) {
            String label = switch (direction.group(1).toUpperCase(Locale.ROOT)) {
                case "TD", "TB" -> "top to bottom";
                case "BT" -> "bottom to top";
                case "LR" -> "left to right";
                default -> "right to left";
            };
            return ansi(BLUE, "Flowchart") + ansi(GRAY, " (" + label + ")");
        }
        // Preserve actual Mermaid syntax; replace arrow glyphs only where syntax is unambiguous.
        String text = line.replaceAll("--?>\\|([^|]+)\\|", " ──($1)──▶ ")
                .replace("-->", "──▶").replace("==>", "══▶").replace("-.->", "┄▶");
        return ansi(CYAN, text);
    }

    /** Remove escape/OSC/CSI bytes, C0/C1 controls and bidi overrides from untrusted output. */
    public static String safe(String input) {
        if (input == null || input.isEmpty()) return "";
        StringBuilder result = new StringBuilder(input.length());
        for (int i = 0; i < input.length();) {
            int ch = input.codePointAt(i);
            i += Character.charCount(ch);
            if (ch == '\n') { result.append('\n'); continue; }
            if (ch == '\r') { result.append('\r'); continue; }
            if (ch == '\t') { result.append("    "); continue; }
            if (ch < 0x20 || ch == 0x7f || ch >= 0x80 && ch <= 0x9f ||
                    ch == 0x202a || ch == 0x202b || ch == 0x202c || ch == 0x202d || ch == 0x202e ||
                    ch >= 0x2066 && ch <= 0x2069) continue;
            result.appendCodePoint(ch);
        }
        return result.toString();
    }

    private String ansi(String style, String text) { return color && !text.isEmpty() ? style + text + RESET : text; }

    private void print(String text) {
        if (text == null || text.isEmpty()) return;
        out.print(text);
        lastNewline = text.endsWith("\n");
    }
}
