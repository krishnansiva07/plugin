package com.llmart.llm.controller;

import com.llmart.llm.service.ProjectService;
import com.llmart.llm.service.VerifiedLearningMemoryService;
import org.springframework.web.bind.annotation.*;
import java.io.IOException;
import java.nio.file.Path;
import java.util.*;

/** Workspace-scoped learning is opt-in; no raw prompts, tool output or credentials are exported. */
@RestController
@RequestMapping("/api/learning")
public final class AgentLearningController {
    private final VerifiedLearningMemoryService learning;
    private final ProjectService projects;
    public AgentLearningController(VerifiedLearningMemoryService learning,ProjectService projects) {
        this.learning=learning;this.projects=projects;
    }
    private Path root(String projectId) {
        var project=projects.require(projectId);
        if (!project.hasLocalPath()) throw new IllegalArgumentException("A local workspace is required for learning");
        return Path.of(project.getLocalPath()).toAbsolutePath().normalize();
    }
    public record ApproveRequest(String projectId,String runId,String category,String summary,
                                 List<String> sourcePaths,boolean approved) { }
    @GetMapping("/candidates")
    public List<VerifiedLearningMemoryService.Candidate> candidates(@RequestParam String projectId) {
        root(projectId); return learning.candidates(projectId);
    }
    @GetMapping("/lessons")
    public List<Map<String,Object>> list(@RequestParam String projectId) throws IOException {
        return learning.list(root(projectId));
    }
    @PostMapping("/lessons")
    public VerifiedLearningMemoryService.Lesson approve(@RequestBody ApproveRequest req) throws IOException {
        if (req==null) throw new IllegalArgumentException("Lesson request required");
        return learning.approve(root(req.projectId()),req.projectId(),req.runId(),req.category(),req.summary(),
                req.sourcePaths(),req.approved());
    }
    @DeleteMapping("/lessons/{id}")
    public Map<String,Boolean> revoke(@PathVariable String id,@RequestParam String projectId) throws IOException {
        return Map.of("removed",learning.revoke(root(projectId),id));
    }
}
