package com.llmart.llm.service;

import java.util.Locale;

/**
 * Cheap, pure routing for a selected project that needs workspace evidence without
 * asking the user to repeat the words "workspace", "repo" or "project".
 * Called only when a selected workspace is already mapped. MCP access is NOT implied.
 */
final class MappedWorkspaceEvidencePolicy {
    private MappedWorkspaceEvidencePolicy() { }

    static boolean shouldRetrieve(String prompt) {
        if (prompt == null || prompt.isBlank()) return false;
        String low = prompt.toLowerCase(Locale.ROOT);
        boolean externalComparison = low.matches("(?s).*(?:jira|confluence|mcp|issue|story|ticket|acceptance criteria).*") &&
                low.matches("(?s).*(?:compare|match|gap|coverage|against|html report|report|traceability|implemented|missing).*");
        boolean currentImplementation = low.matches("(?s).*(?:analy[sz]e|review|inspect|compare|validate|verify|check|identify|find).*") &&
                low.matches("(?s).*(?:what (?:we|have)|what is (?:done|missing)|feature|functionality|implementation|test cases|tests|scenarios|coverage|requirements).*");
        return externalComparison || currentImplementation;
    }
}
