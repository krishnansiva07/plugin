package com.llmart.llm.service;

import com.llmart.llm.dto.ProjectPatchRequest;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.util.*;
import java.util.regex.Pattern;

/**
 * Independent last-mile proof for multi-source HTML report jobs. Neither a model's final
 * text nor a completed plan step proves that the user's actual deliverable exists.
 * Deliberately bounded: inspects only files already reported as changed by the workspace
 * tracker; does not recursively rescan projects or send report bodies to another LLM.
 */
final class AgentCompletionEvidence {
    record Verdict(boolean passed, String detail, List<String> verifiedFiles) {
        static Verdict fail(String why) { return new Verdict(false, why, List.of()); }
        static Verdict pass(String why, List<String> files) { return new Verdict(true, why, List.copyOf(files)); }
    }

    private static final Pattern HTML_REQUEST = Pattern.compile(
            "(?is)(?:\\b(?:create|generate|produce|export|write|save|build|prepare)\\b.{0,160}\\b(?:html|\\.html)\\b|" +
            "\\b(?:html|\\.html)\\b.{0,100}\\b(?:report|output|artifact)\\b)");
    private static final Pattern JIRA_REQUEST = Pattern.compile("(?i)\\bjira\\b");
    private static final Pattern COMPARE_REQUEST = Pattern.compile("(?i)\\b(?:compare|match|map|cross.check|gap|coverage|against|validate)\\b");
    private static final Pattern HTML_DOCUMENT = Pattern.compile("(?is)<(?:!doctype\\s+html|html\\b)");
    private static final Pattern HTML_BODY = Pattern.compile("(?is)<(?:body|main|section|article|table|div)\\b");
    private String objective = "";
    private int jiraSuccess;
    private int workspaceReadSuccess;
    private int externalMcpSuccess;
    private final Map<String, String> unresolvedFailures = new LinkedHashMap<>();

    AgentCompletionEvidence() { }
    AgentCompletionEvidence(String objective) { setObjective(objective); }
    void setObjective(String text) { objective = text == null ? "" : text; }
    boolean requiresHtml() { return HTML_REQUEST.matcher(objective).find(); }
    boolean hasUnresolvedCriticalFailures() { return !unresolvedFailures.isEmpty(); }
    /** A failed attempt is never sufficient proof for a read-only investigation. */
    boolean hasSuccessfulInvestigationEvidence() { return workspaceReadSuccess > 0 || externalMcpSuccess > 0; }
    // Only output-designating clauses define artifact names. HTML source files being
    // inspected must not accidentally become mandatory deliverables.
    private static final Pattern NAMED_HTML_OUTPUT = Pattern.compile(
            "(?is)\\b(?:create|generate|produce|export|write|save|deliver|output|named|called|as)\\b[^.\\n]{0,120}?\\b([a-z0-9_./-]+\\.html?)\\b");
    private Set<String> expectedHtmlNames() {
        LinkedHashSet<String> expected = new LinkedHashSet<>();
        var matches = NAMED_HTML_OUTPUT.matcher(objective.replace('\\', '/'));
        while (matches.find()) {
            String name = matches.group(1);
            // A URL being inspected is not an output contract.
            if (!name.contains("://") && !name.startsWith("//") && !name.startsWith("../") && !name.contains("/../"))
                expected.add(name);
        }
        return expected;
    }
    String unresolvedFailureSummary() { return unresolvedFailures.toString(); }
    boolean requiresJiraMcp() { return requiresHtml() && JIRA_REQUEST.matcher(objective).find()
            && McpPromptGate.explicitlyRequested(objective); }
    boolean requiresComparison() { return requiresHtml() && JIRA_REQUEST.matcher(objective).find()
            && COMPARE_REQUEST.matcher(objective).find(); }

    /** Only tool completion events count: running, plan commentary, and model claims do not. */
    void observe(Map<String, Object> event) {
        if (event == null) return;
        String tool = String.valueOf(event.getOrDefault("tool", "")).toLowerCase(Locale.ROOT);
        String status = String.valueOf(event.getOrDefault("status", "")).toLowerCase(Locale.ROOT);
        boolean actualTool = tool.startsWith("mcp__") || Set.of("read", "read_many", "grep", "glob",
                "inspect_workspace", "knowledge_read", "knowledge_search", "code_impact", "file_info", "list",
                "resource_read", "resource_grep", "write", "edit", "apply_patch", "bash", "confluence_compose",
                "confluence_validate", "build", "test", "check", "resource_build", "resource_test",
                "resource_check", "documentation_validate", "presentation_validate").contains(tool);
        if (!actualTool || (!"success".equals(status) && !"error".equals(status))) return;
        String category = category(tool);
        if ("error".equals(status)) {
            if (category != null) unresolvedFailures.put(category, safeDetail(event));
            return;
        }
        if (category != null) unresolvedFailures.remove(category);
        if (tool.startsWith("mcp__")) externalMcpSuccess++;
        if (tool.startsWith("mcp__") && tool.contains("jira")) jiraSuccess++;
        if (Set.of("read", "read_many", "grep", "glob", "inspect_workspace", "knowledge_read",
                "knowledge_search", "code_impact", "file_info", "list").contains(tool)) workspaceReadSuccess++;
    }

    private static String category(String tool) {
        if (tool.startsWith("mcp__") && tool.contains("jira")) return "jira MCP";
        if (Set.of("confluence_compose", "write", "edit", "apply_patch").contains(tool)) return "artifact generation";
        if ("confluence_validate".equals(tool)) return "HTML validation";
        if (Set.of("build", "test", "check", "resource_build", "resource_test", "resource_check",
                "documentation_validate", "presentation_validate").contains(tool)) return "final verification";
        // A failed exploratory grep is not in itself proof that final report generation failed.
        return null;
    }

    private static String safeDetail(Map<String,Object> event) {
        String detail = String.valueOf(event.getOrDefault("detail", "tool failed"));
        return detail.length() > 260 ? detail.substring(0, 260) : detail;
    }

    Verdict verify(Path workspaceRoot, List<ProjectPatchRequest.ProjectPatchFile> changed) {
        if (!requiresHtml()) return Verdict.pass("No HTML deliverable requested; standard Agent verification applies", List.of());
        if (workspaceRoot == null) return Verdict.fail("HTML report requested, but no mapped writable workspace is available");
        if (requiresJiraMcp() && jiraSuccess == 0)
            return Verdict.fail("Jira MCP evidence was explicitly requested but no successful Jira MCP tool result was recorded");
        if (requiresComparison() && workspaceReadSuccess == 0)
            return Verdict.fail("Jira-to-workspace comparison requested but no successful local workspace read/search was recorded");
        if (!unresolvedFailures.isEmpty()) return Verdict.fail("Unresolved report workflow errors: " + unresolvedFailures);
        if (changed == null || changed.isEmpty())
            return Verdict.fail("HTML report requested but no changed workspace artifacts were recorded");
        try {
            Path root = workspaceRoot.toRealPath();
            List<String> valid = new ArrayList<>();
            List<String> invalid = new ArrayList<>();
            Set<String> expectedNames = expectedHtmlNames();
            for (ProjectPatchRequest.ProjectPatchFile candidate : changed) {
                if (candidate == null || candidate.path() == null || !candidate.path().toLowerCase(Locale.ROOT).endsWith(".html")) continue;
                String relative = candidate.path().replace('\\', '/');
                if (!expectedNames.isEmpty() && expectedNames.stream().noneMatch(name ->
                        name.contains("/") ? name.equals(relative) : name.equals(Path.of(relative).getFileName().toString()))) continue;
                if ("delete".equalsIgnoreCase(candidate.operation())) continue;
                Path target = root.resolve(candidate.path()).normalize();
                if (!target.startsWith(root) || !Files.isRegularFile(target, LinkOption.NOFOLLOW_LINKS)) {
                    invalid.add(candidate.path() + " missing or not regular"); continue;
                }
                // No symlink traversal, including parent directories.
                boolean link = false;
                for (Path p = target; p != null && p.startsWith(root); p = p.getParent()) {
                    if (Files.isSymbolicLink(p)) { link = true; break; }
                    if (p.equals(root)) break;
                }
                if (link || !target.toRealPath().startsWith(root)) { invalid.add(candidate.path() + " escapes workspace"); continue; }
                long size = Files.size(target);
                if (size < 120 || size > 10_000_000L) { invalid.add(candidate.path() + " invalid size " + size); continue; }
                String content = Files.readString(target, StandardCharsets.UTF_8);
                if (!HTML_DOCUMENT.matcher(content).find() || !HTML_BODY.matcher(content).find()) {
                    invalid.add(candidate.path() + " is not a complete HTML document"); continue;
                }
                valid.add(candidate.path());
            }
            if (valid.isEmpty()) return Verdict.fail("Requested HTML output missing or unverified" +
                    (expectedNames.isEmpty() ? "" : ": " + expectedNames) + ". " + String.join("; ", invalid));
            for (String expected : expectedNames) {
                boolean present = valid.stream().anyMatch(path -> expected.contains("/")
                        ? path.replace('\\', '/').equals(expected)
                        : Path.of(path).getFileName().toString().equals(expected));
                if (!present) return Verdict.fail("Explicitly requested HTML artifact missing: " + expected +
                        "; verified instead: " + String.join(", ", valid));
            }
            return Verdict.pass("Read-back verified HTML file(s): " + String.join(", ", valid) +
                    "; content/requirement correctness still requires source-to-report validation", valid);
        } catch (Exception failure) {
            return Verdict.fail("Could not independently read HTML artifact: " + failure.getClass().getSimpleName());
        }
    }
}
