package com.llmart.llm.controller;

import com.llmart.llm.service.OpenCodeConfigImportService;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

/** Local settings import; deliberately exposes only metadata, never secrets. */
@RestController
@RequestMapping("/api/opencode/config")
public class OpenCodeConfigImportController {
    private final OpenCodeConfigImportService importer;
    public OpenCodeConfigImportController(OpenCodeConfigImportService importer) { this.importer = importer; }
    @GetMapping public OpenCodeConfigImportService.ImportSummary summary() { return importer.summary(); }
    @PostMapping(value = "/import", consumes = MediaType.APPLICATION_JSON_VALUE)
    public OpenCodeConfigImportService.ImportSummary upload(@RequestBody String json) { return importer.importJson(json); }
}
