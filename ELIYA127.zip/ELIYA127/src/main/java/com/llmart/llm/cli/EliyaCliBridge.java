package com.llmart.llm.cli;

import com.llmart.llm.dto.ProjectDto;
import com.llmart.llm.dto.ChatRequest;
import com.llmart.llm.dto.ChatSettings;
import com.llmart.llm.dto.MessageDto;
import com.llmart.llm.service.ChatService;
import org.springframework.http.MediaType;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;
import org.springframework.web.server.ResponseStatusException;
import com.llmart.llm.service.ConversationService;
import com.llmart.llm.service.LocalProjectIndexService;
import com.llmart.llm.service.ProjectService;
import jakarta.annotation.PreDestroy;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.boot.web.servlet.context.ServletWebServerApplicationContext;
import org.springframework.context.event.EventListener;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.awt.Desktop;
import java.awt.GraphicsEnvironment;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.nio.file.attribute.PosixFilePermission;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.*;
import java.util.concurrent.atomic.AtomicLong;

/** Loopback-only CLI-to-browser bridge. CLI mutations require a per-process random bearer secret.
 * The ordinary browser polls a read-only selection revision to adopt terminal workspace changes.
 */
@RestController
@RequestMapping("/api/cli")
public class EliyaCliBridge {
    public record ActivationRequest(String workspace) { }
    public record Selection(String version, ProjectDto project, String conversationId, String mode) { }
    public record BrowserSettings(String apiKey, ChatSettings settings) { }
    public record TerminalPrompt(String mode, String prompt, String workspace) { }
    public record ModeRequest(String mode, String workspace) { }

    private final ProjectService projects;
    private final ConversationService conversations;
    private final LocalProjectIndexService indexJobs;
    private final ChatService chat;
    private final Map<String, String> conversationByWorkspace = new java.util.concurrent.ConcurrentHashMap<>();
    private volatile BrowserSettings browserSettings;
    private final ServletWebServerApplicationContext webServer;
    private final String token;
    private final String instance = UUID.randomUUID().toString();
    private final AtomicLong revision = new AtomicLong();
    private volatile Selection current = new Selection("", null, null, "analyse");
    private volatile boolean published;

    public EliyaCliBridge(ProjectService projects, ConversationService conversations,
                          LocalProjectIndexService indexJobs, ServletWebServerApplicationContext webServer,
                          ChatService chat) {
        this.projects = projects;
        this.conversations = conversations;
        this.indexJobs = indexJobs;
        this.webServer = webServer;
        this.chat = chat;
        byte[] random = new byte[32];
        new SecureRandom().nextBytes(random);
        this.token = HexFormat.of().formatHex(random);
    }

    public static Path bridgeFile() {
        String data = System.getProperty("app.data-dir");
        if (data == null || data.isBlank()) throw new IllegalStateException("Eliya data path not initialized");
        return Path.of(data).resolve("eliya-cli-bridge.txt");
    }

    @EventListener(ApplicationReadyEvent.class)
    public void ready() {
        int port = webServer.getWebServer().getPort();
        try {
            Path target = bridgeFile();
            Files.createDirectories(target.getParent());
            Path tmp = Files.createTempFile(target.getParent(), ".eliya-cli-", ".tmp");
            restrictFile(tmp);
            Files.writeString(tmp, port + "\n" + token + "\n", StandardCharsets.UTF_8,
                    StandardOpenOption.TRUNCATE_EXISTING);
            try { Files.move(tmp, target, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING); }
            catch (AtomicMoveNotSupportedException ex) { Files.move(tmp, target, StandardCopyOption.REPLACE_EXISTING); }
            restrictFile(target);
            published = true;
        } catch (Exception ex) {
            System.err.println("ELIYA CLI bridge unavailable: " + ex.getMessage());
        }

        String workspace = System.getProperty("eliya.startup.workspace", "").trim();
        if (workspace.isEmpty()) {
            // `java -jar` may be invoked from an IDE project; don't index arbitrary home/drive folders.
            Path detected = ProjectDirectoryLocator.detectedProject(Path.of(""));
            if (detected != null) workspace = detected.toString();
        }
        if (!workspace.isEmpty()) {
            try { activateWorkspace(workspace); }
            catch (Exception ex) { System.err.println("ELIYA workspace was not mapped: " + ex.getMessage()); }
        }
        String url = "http://127.0.0.1:" + port + "/";
        System.out.println("ELIYA ready: " + url);
        if (!"false".equalsIgnoreCase(System.getProperty("eliya.browser.enabled", "true")) &&
                !"true".equalsIgnoreCase(System.getenv("ELIYA_NO_BROWSER"))) openBrowser(url);
    }

    private synchronized ProjectDto activateWorkspace(String workspace) {
        if (workspace == null) return current.project(); // `eliya open` must preserve selection.
        Path path = Path.of(workspace).toAbsolutePath().normalize();
        String key = path.toString();
        String conversationId = conversationByWorkspace.computeIfAbsent(key, ignored -> {
            // Reopen the same workspace conversation after an application restart,
            // but never reuse a deleted conversation ID.
            Set<String> existing = new HashSet<>();
            conversations.list().forEach(conversation -> existing.add(conversation.id()));
            return projects.mappedLocalWorkspaces().stream()
                    .filter(project -> key.equals(project.localPath()))
                    .map(ProjectDto::conversationId)
                    .filter(existing::contains)
                    .findFirst()
                    .orElseGet(() -> conversations.create().getId());
        });
        ProjectDto project = projects.createLocal(conversationId, key, null);
        indexJobs.request(project, false);
        current = new Selection(instance + ":" + revision.incrementAndGet(), project, conversationId, "analyse");
        System.out.println("ELIYA workspace: " + project.localPath() + " (background indexing enabled)");
        return project;
    }

    private synchronized Selection chooseMode(String mode, String workspace) {
        // Never allow one terminal to execute against another terminal's globally
        // selected project. The calling terminal pins its canonical workspace.
        if (workspace != null && !workspace.isBlank() &&
                (current.project() == null || !Path.of(current.project().localPath()).equals(
                        Path.of(workspace).toAbsolutePath().normalize()))) {
            activateWorkspace(workspace);
        }
        if (current.project() == null || current.conversationId() == null)
            throw new IllegalArgumentException("No workspace selected. Run `eliya` from a project folder or `eliya workspace <path>`.");
        String normalized = mode == null ? "" : mode.toLowerCase(Locale.ROOT).trim();
        if (!Set.of("analyse", "agent").contains(normalized))
            throw new IllegalArgumentException("Mode must be analyse or agent");
        current = new Selection(instance + ":" + revision.incrementAndGet(),
                current.project(), current.conversationId(), normalized);
        return current;
    }

    private boolean authorized(String credential, HttpServletRequest request) {
        return isLoopback(request.getRemoteAddr()) && credential != null &&
                MessageDigest.isEqual(credential.getBytes(StandardCharsets.UTF_8), token.getBytes(StandardCharsets.UTF_8));
    }

    /** Browser settings never go into the bridge file, logs, or terminal JSON response.
     * Same-origin application JavaScript alone can supply these settings (custom header blocks cross-origin forms).
     */
    @PostMapping("/browser-settings")
    public ResponseEntity<?> browserSettings(@RequestBody BrowserSettings supplied,
            @RequestHeader(value = "X-Eliya-Local-UI", required = false) String marker,
            @RequestHeader(value = "Origin", required = false) String origin,
            HttpServletRequest request) {
        String expected = "http://127.0.0.1:" + webServer.getWebServer().getPort();
        String altExpected = "http://localhost:" + webServer.getWebServer().getPort();
        if (!isLoopback(request.getRemoteAddr()) || !"settings-sync".equals(marker) ||
                (origin != null && !origin.equals(expected) && !origin.equals(altExpected))) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        }
        if (supplied == null || supplied.settings() == null || supplied.apiKey() == null ||
                supplied.apiKey().isBlank() || supplied.settings().baseUrl() == null ||
                supplied.settings().baseUrl().isBlank() || supplied.settings().model() == null ||
                supplied.settings().model().isBlank()) {
            browserSettings = null;
            return ResponseEntity.ok(Map.of("configured", false));
        }
        browserSettings = supplied; // process memory only; never disclose credential to the CLI.
        return ResponseEntity.ok(Map.of("configured", true));
    }

    @GetMapping("/status")
    public ResponseEntity<?> status(@RequestHeader(value = "X-Eliya-CLI-Token", required = false) String credential,
                                    HttpServletRequest request) {
        if (!authorized(credential, request)) return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        return ResponseEntity.ok(Map.of("selection", current,
                "modelConfigured", browserSettings != null,
                "url", "http://127.0.0.1:" + webServer.getWebServer().getPort() + "/"));
    }

    @PostMapping("/mode")
    public ResponseEntity<?> mode(@RequestBody ModeRequest body,
            @RequestHeader(value = "X-Eliya-CLI-Token", required = false) String credential,
            HttpServletRequest request) {
        if (!authorized(credential, request)) return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        try { return ResponseEntity.ok(chooseMode(body == null ? null : body.mode(),
                body == null ? null : body.workspace())); }
        catch (IllegalArgumentException e) { return ResponseEntity.badRequest().body(Map.of("error", e.getMessage())); }
    }

    /** Runs exactly the same native Chat/Agent pipeline as the browser, using the
     * current mapped workspace and a workspace-scoped persistent conversation.
     * This endpoint is callable only by the token-bearing local launcher.
     */
    @PostMapping(path = "/run", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
    public SseEmitter run(@RequestBody TerminalPrompt body,
            @RequestHeader(value = "X-Eliya-CLI-Token", required = false) String credential,
            HttpServletRequest request) {
        if (!authorized(credential, request)) throw new ResponseStatusException(HttpStatus.FORBIDDEN,
                "Not an authorized local Eliya terminal");
        BrowserSettings configuration = browserSettings;
        if (configuration == null) throw new ResponseStatusException(HttpStatus.CONFLICT,
                "Configure the API key, Base URL and models in Eliya browser Settings first.");
        if (body == null) throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Prompt is required");
        String mode = body == null ? null : body.mode();
        if (mode == null || !Set.of("analyse", "agent", "implement").contains(mode))
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Mode must be analyse, agent or implement");
        Selection selection;
        try { selection = chooseMode("implement".equals(mode) ? "agent" : mode,
                body.workspace()); }
        catch (IllegalArgumentException ex) { throw new ResponseStatusException(HttpStatus.BAD_REQUEST, ex.getMessage()); }
        String prompt = body.prompt() == null ? "" : body.prompt().strip();
        if ("implement".equals(mode)) {
            java.util.List<MessageDto> history = conversations.listMessages(selection.conversationId());
            boolean hasAnalysis = history.stream().anyMatch(m -> "assistant".equals(m.role()) &&
                    ("chat".equals(m.mode()) || m.mode() == null) && m.content() != null && !m.content().isBlank());
            if (!hasAnalysis) throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                    "No completed Analyse response in this workspace conversation. Run `eliya analyse` first.");
            prompt = "Implement the last agreed Analyse plan from this conversation in the selected workspace. " +
                    "Read its findings and constraints, apply the requested changes, run appropriate verification, " +
                    "and report evidence of success or failure.";
            mode = "agent";
        }
        if (prompt.isBlank()) throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Prompt cannot be empty");
        // The request retains its own immutable workspace snapshot even if another terminal switches.
        ChatRequest chatRequest = new ChatRequest(selection.conversationId(), prompt, List.of(),
                selection.project().id(), "agent".equals(mode) ? "agent" : "chat", false, configuration.settings());
        return chat.stream(configuration.apiKey(), chatRequest);
    }

    @PostMapping("/refresh")
    public ResponseEntity<?> refresh(
            @RequestHeader(value = "X-Eliya-CLI-Token", required = false) String credential,
            HttpServletRequest request) {
        if (!authorized(credential, request)) return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        synchronized (this) {
            current = new Selection(instance + ":" + revision.incrementAndGet(),
                    current.project(), current.conversationId(), current.mode());
        }
        return ResponseEntity.ok(Map.of("refreshed", true));
    }

    @GetMapping("/selection")
    public ResponseEntity<Selection> selection(HttpServletRequest servletRequest) {
        if (!isLoopback(servletRequest.getRemoteAddr())) return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        return ResponseEntity.ok(current);
    }

    @PostMapping("/activate")
    public ResponseEntity<?> activate(@RequestBody ActivationRequest request,
                                      @RequestHeader(value = "X-Eliya-CLI-Token", required = false) String credential,
                                      HttpServletRequest servletRequest) {
        if (!authorized(credential, servletRequest)) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(Map.of("error", "Not an authorized local Eliya CLI"));
        }
        try {
            activateWorkspace(request == null ? null : request.workspace());
            return ResponseEntity.ok(Map.of("selection", current,
                    "url", "http://127.0.0.1:" + webServer.getWebServer().getPort() + "/"));
        }
        catch (IllegalArgumentException exception) { return ResponseEntity.badRequest().body(Map.of("error", exception.getMessage())); }
    }

    private static boolean isLoopback(String host) {
        try { return java.net.InetAddress.getByName(host).isLoopbackAddress(); }
        catch (Exception ex) { return false; }
    }

    private static void restrictFile(Path file) {
        try { Files.setPosixFilePermissions(file, Set.of(PosixFilePermission.OWNER_READ, PosixFilePermission.OWNER_WRITE)); }
        catch (UnsupportedOperationException | java.io.IOException ignored) { /* Windows inherits user-profile ACLs. */ }
    }

    @PreDestroy
    public void shutdown() {
        if (!published) return;
        try {
            Path file = bridgeFile();
            List<String> lines = Files.readAllLines(file, StandardCharsets.UTF_8);
            if (lines.size() > 1 && token.equals(lines.get(1))) Files.deleteIfExists(file);
        } catch (Exception ignored) { }
    }

    /** Open only a fixed localhost Eliya URL. A closed/headless desktop is non-fatal. */
    public static void openBrowser(String baseUrl) {
        try {
            URI address = URI.create(baseUrl);
            if (!address.getHost().equals("127.0.0.1") || !"http".equals(address.getScheme())) return;
            if (!GraphicsEnvironment.isHeadless() && Desktop.isDesktopSupported() &&
                    Desktop.getDesktop().isSupported(Desktop.Action.BROWSE)) {
                Desktop.getDesktop().browse(address);
                return;
            }
            String os = System.getProperty("os.name", "").toLowerCase(Locale.ROOT);
            String[] command = os.contains("win")
                    ? new String[]{"rundll32", "url.dll,FileProtocolHandler", address.toString()}
                    : os.contains("mac") ? new String[]{"open", address.toString()}
                    : new String[]{"xdg-open", address.toString()};
            new ProcessBuilder(command).start();
        } catch (Exception ex) {
            System.out.println("Open Eliya in your browser: " + baseUrl);
        }
    }
}
