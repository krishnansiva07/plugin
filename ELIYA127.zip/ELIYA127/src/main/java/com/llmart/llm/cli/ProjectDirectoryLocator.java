package com.llmart.llm.cli;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

/** Detect an editor/terminal project root without walking repository contents or scanning files. */
public final class ProjectDirectoryLocator {
    private static final List<String> MARKERS = List.of(
            ".git", "pom.xml", "build.gradle", "build.gradle.kts", "settings.gradle", "settings.gradle.kts",
            "package.json", "pyproject.toml", "Cargo.toml", "go.mod", "Gemfile", "composer.json", ".code-workspace");

    private ProjectDirectoryLocator() { }

    public static Path fromWorkingDirectory(Path cwd) {
        Path current = cwd.toAbsolutePath().normalize();
        Path home = Path.of(System.getProperty("user.home", ".")).toAbsolutePath().normalize();
        // Never auto-map the home directory, drive/filesystem root, or an ancestor of home.
        if (current.getParent() == null || current.equals(home) || home.startsWith(current)) return null;
        for (Path candidate = current; candidate != null && candidate.getParent() != null; candidate = candidate.getParent()) {
            if (candidate.equals(home) || home.startsWith(candidate)) break;
            if (hasProjectMarker(candidate)) return candidate;
        }
        // The shell location may be a new/empty project with no build manifest yet.
        return current;
    }

    public static Path detectedProject(Path cwd) {
        Path selected = fromWorkingDirectory(cwd);
        if (selected == null) return null;
        for (Path candidate = cwd.toAbsolutePath().normalize(); candidate != null && candidate.getParent() != null;
             candidate = candidate.getParent()) {
            if (candidate.equals(selected) || candidate.startsWith(selected)) {
                if (hasProjectMarker(candidate)) return candidate;
                if (candidate.equals(selected)) break;
            }
        }
        return null;
    }

    private static boolean hasProjectMarker(Path root) {
        for (String marker : MARKERS) if (Files.exists(root.resolve(marker))) return true;
        return Files.isDirectory(root.resolve("src")) || Files.isDirectory(root.resolve(".idea")) ||
                Files.isDirectory(root.resolve(".vscode"));
    }
}
