package com.llmart.llm.service;

import org.springframework.stereotype.Service;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.regex.Pattern;

/** Native, deterministic starter generation. No MCP process, LLM or shell is launched here. */
@Service
public final class AgentBuilderService {
    private static final Pattern SAFE_NAME = Pattern.compile("[a-z][a-z0-9-]{1,50}");
    private static final Map<String,List<String>> FILES = Map.of(
            "mcp-python", List.of("server.py","catalog.json","test_server.py","README.md","AGENTS.md","opencode.sample.json"),
            "rag-python", List.of("rag.py","app.py","test_rag.py","README.md","AGENTS.md","docs/example.md",".gitignore"));
    private final AgentWorkspaceService workspaceService;

    public AgentBuilderService(AgentWorkspaceService workspaceService) { this.workspaceService = workspaceService; }

    public record BuildResult(String kind, String directory, List<String> files, boolean verified) {
        public String toolText() {
            return "workspaceChanged=true; generated " + kind + " starter in " + directory +
                    "\ncreatedFiles:\n" + String.join("\n",files) +
                    "\nREADBACK VERIFIED: " + verified +
                    "\nRun the generated Python unittest suite and then an MCP client or RAG integration test before marking the request completed. " +
                    "This starter is not a production-certified deployment.";
        }
    }

    public static String normalizedName(String name) {
        String slug = name == null ? "" : name.strip().toLowerCase(Locale.ROOT)
                .replaceAll("[^a-z0-9]+", "-").replaceAll("^-+|-+$", "");
        if (!SAFE_NAME.matcher(slug).matches())
            throw new IllegalArgumentException("Use a project name of 2..51 lowercase alphanumeric/hyphen characters");
        return slug;
    }

    public static String outputDirectory(String kind, String name, String requested) {
        if (!FILES.containsKey(kind)) throw new IllegalArgumentException("Supported builders: mcp-python, rag-python");
        String defaultDir = "eliya-generated/" + normalizedName(name) + (kind.equals("mcp-python") ? "-mcp" : "-rag");
        String input = requested == null || requested.isBlank() ? defaultDir : requested.trim().replace('\\','/');
        Path relative = Path.of(input).normalize();
        if (relative.isAbsolute() || relative.toString().equals(".") || relative.startsWith("..") ||
                input.startsWith("/") || input.contains(":") || input.indexOf('\0') >= 0 ||
                input.split("/").length > 12) {
            throw new IllegalArgumentException("Builder output directory must be a safe relative path within the active workspace");
        }
        return relative.toString().replace('\\','/');
    }

    public static List<String> expectedPaths(String kind, String name, String requested) {
        String folder = outputDirectory(kind,name,requested);
        return FILES.get(kind).stream().map(file -> folder+"/"+file).toList();
    }

    public BuildResult generate(AgentWorkspaceService.Workspace ws, String kind, String name, String requested)
            throws IOException {
        if (ws == null) throw new IllegalArgumentException("Select a live local workspace");
        String slug = normalizedName(name);
        String folder = outputDirectory(kind,name,requested);
        Path root = ws.root().toRealPath();
        Path target = root.resolve(folder).normalize();
        if (!target.startsWith(root) || target.equals(root))
            throw new IllegalArgumentException("Cannot generate files outside the selected workspace");
        // The builder is create-only. An existing directory (including an empty one) is never silently replaced.
        if (Files.exists(target, LinkOption.NOFOLLOW_LINKS))
            throw new FileAlreadyExistsException("Builder destination exists: " + folder + ". Choose a new path.");
        Path cursor = target.getParent();
        while (cursor != null && cursor.startsWith(root)) {
            if (Files.isSymbolicLink(cursor)) throw new IllegalArgumentException("Builder cannot traverse symlink directories");
            cursor = cursor.getParent();
        }
        List<String> relativeFiles = expectedPaths(kind, slug, folder);
        // Validate/read all resources before creating any file: don't leave a partial template from missing resources.
        LinkedHashMap<String,String> contents = new LinkedHashMap<>();
        for (String file : FILES.get(kind)) {
            String resource = "/eliya125-templates/"+kind+"/"+
                    (file.equals(".gitignore") ? "gitignore.template" : file);
            try (InputStream stream = AgentBuilderService.class.getResourceAsStream(resource)) {
                if (stream == null) throw new IOException("Builder resource missing: " + resource);
                String body = new String(stream.readAllBytes(), StandardCharsets.UTF_8)
                        .replace("__PROJECT_NAME__", slug).replace("__PROJECT_SLUG__", slug);
                contents.put(folder+"/"+file,body);
            }
        }
        List<String> written = new ArrayList<>();
        // Reserve a fresh destination atomically. Never overwrite an existing project.
        Files.createDirectories(target.getParent());
        Files.createDirectory(target);
        try {
            for (var entry : contents.entrySet()) {
                workspaceService.writeFile(ws,entry.getKey(),entry.getValue());
                written.add(entry.getKey());
            }
            for (var entry : contents.entrySet()) {
                Path path = root.resolve(entry.getKey()).normalize();
                if (!Files.isRegularFile(path,LinkOption.NOFOLLOW_LINKS) ||
                        !Objects.equals(Files.readString(path,StandardCharsets.UTF_8),entry.getValue()))
                    throw new IOException("Generated file did not match expected content: " + entry.getKey());
            }
        } catch (IOException | RuntimeException failure) {
            // Only our own newly created template directory is removed. Never roll back parent paths or preexisting files.
            for (int i=written.size()-1; i>=0; i--) {
                try { Files.deleteIfExists(root.resolve(written.get(i))); } catch (IOException ignored) { }
            }
            try (var walk=Files.walk(target)) {
                for (Path file : walk.sorted(Comparator.reverseOrder()).toList()) {
                    try { Files.deleteIfExists(file); } catch (IOException ignored) { }
                }
            } catch (IOException ignored) { }
            throw failure;
        }
        return new BuildResult(kind,folder,List.copyOf(relativeFiles),true);
    }
}
