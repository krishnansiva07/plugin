package com.llmart.llm.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

/** Imports OpenCode's JSON config without executing arbitrary commands or connecting MCP.
 * MCP remains subject to ELIYA's master switch and explicit-prompt opt-in. */
@Service
public class OpenCodeConfigImportService {
    private static final int MAX_BYTES = 1_048_576;
    private final ObjectMapper mapper;

    public OpenCodeConfigImportService(ObjectMapper mapper) { this.mapper = mapper; }

    Path location() {
        return Path.of(System.getProperty("user.home", "."), ".eliya", "opencode-import.json")
                .toAbsolutePath().normalize();
    }

    public record ImportSummary(String selectedModel, int providers, int mcpServers, List<String> serverNames,
                                String message) { }

    public synchronized ImportSummary importJson(String json) {
        if (json == null || json.isBlank() || json.getBytes(StandardCharsets.UTF_8).length > MAX_BYTES)
            throw new IllegalArgumentException("OpenCode configuration must be a nonempty JSON file under 1 MB");
        try {
            JsonNode root = mapper.readTree(json);
            if (root == null || !root.isObject()) throw new IllegalArgumentException("OpenCode configuration must be a JSON object");
            JsonNode mcp = servers(root);
            if (root.has("mcp") && !mcp.isObject()) throw new IllegalArgumentException("OpenCode mcp must be an object");
            JsonNode providers = root.path("provider");
            if (!providers.isObject()) providers = root.path("providers");
            if (root.has("provider") && !root.path("provider").isObject())
                throw new IllegalArgumentException("OpenCode provider must be a JSON object");
            int serverCount = 0;
            List<String> names = new ArrayList<>();
            if (mcp.isObject()) {
                var iter = mcp.fields();
                while (iter.hasNext()) {
                    var entry = iter.next();
                    JsonNode server = entry.getValue();
                    if (!server.isObject()) throw new IllegalArgumentException("MCP server " + entry.getKey() + " must be an object");
                    String type = server.path("type").asText(server.has("command") ? "local" : "remote");
                    if (!Set.of("local", "stdio", "remote", "http").contains(type))
                        throw new IllegalArgumentException("Unsupported MCP type for " + entry.getKey());
                    if (type.equals("local") || type.equals("stdio")) {
                        JsonNode command = server.path("command");
                        if (!(command.isArray() && command.size() > 0) && !command.isTextual())
                            throw new IllegalArgumentException("Local MCP " + entry.getKey() + " needs a command");
                    } else {
                        String url = server.path("url").asText("");
                        java.net.URI uri = java.net.URI.create(url);
                        if (!Set.of("http", "https").contains(String.valueOf(uri.getScheme())) || uri.getHost() == null || uri.getRawUserInfo() != null)
                            throw new IllegalArgumentException("Invalid remote MCP URL for " + entry.getKey());
                    }
                    serverCount++;
                    names.add(entry.getKey());
                }
            }
            if (serverCount == 0 && (!providers.isObject() || providers.isEmpty()) && root.path("model").asText("").isBlank())
                throw new IllegalArgumentException("No OpenCode MCP servers, provider definitions, or model found");
            Path file = location();
            Files.createDirectories(file.getParent());
            if (Files.isSymbolicLink(file) || Files.isSymbolicLink(file.getParent()))
                throw new IllegalArgumentException("Imported configuration path must not be a symbolic link");
            // Never copy imports into the mapped project or the web-static directory.
            Path temporary = Files.createTempFile(file.getParent(), "opencode-import-", ".tmp");
            try {
                try { Files.setPosixFilePermissions(temporary, java.nio.file.attribute.PosixFilePermissions.fromString("rw-------")); }
                catch (UnsupportedOperationException ignored) { }
                Files.writeString(temporary, mapper.writeValueAsString(root), StandardCharsets.UTF_8);
                try { Files.move(temporary, file, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
                catch (AtomicMoveNotSupportedException ignored) { Files.move(temporary, file, StandardCopyOption.REPLACE_EXISTING); }
            } finally { Files.deleteIfExists(temporary); }
            return new ImportSummary(root.path("model").asText(""), providers.isObject() ? providers.size() : 0,
                    serverCount, List.copyOf(names), "Imported. MCP connections remain disabled until enabled and explicitly requested.");
        } catch (IllegalArgumentException e) { throw e; }
        catch (Exception e) { throw new IllegalArgumentException("Could not import OpenCode JSON: " + e.getClass().getSimpleName()); }
    }

    public ImportSummary summary() {
        Path file = location();
        if (!Files.isRegularFile(file) || Files.isSymbolicLink(file))
            return new ImportSummary("",0,0,List.of(),"No OpenCode configuration imported");
        try {
            JsonNode root = mapper.readTree(Files.readString(file));
            JsonNode mcp = servers(root);
            List<String> names = new ArrayList<>();
            if (mcp.isObject()) mcp.fieldNames().forEachRemaining(names::add);
            JsonNode providers = root.path("provider");
            if (!providers.isObject()) providers = root.path("providers");
            return new ImportSummary(root.path("model").asText(""), providers.isObject()?providers.size():0,
                    names.size(), List.copyOf(names), "Imported configuration available");
        } catch (IOException e) { return new ImportSummary("",0,0,List.of(),"Imported configuration could not be read"); }
    }

    static JsonNode servers(JsonNode root) {
        JsonNode mcp = root.path("mcp");
        return mcp.path("servers").isObject() ? mcp.path("servers") : mcp;
    }
}
