package com.llmart.llm.service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.stereotype.Service;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.security.MessageDigest;
import java.time.Instant;
import java.util.*;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

/** Durable, approved, workspace-scoped verified lessons. Never modifies model weights. */
@Service
public final class VerifiedLearningMemoryService {
    private static final int MAX_LESSONS = 200;
    private static final Pattern SECRET = Pattern.compile("(?i)(?:sk-[a-z0-9_-]{12,}|(?:password|secret|api[-_ ]?key|bearer|access[-_ ]?token)\\s*[:=]\\s*\\S+)");
    private final ObjectMapper mapper;
    private final AgentRunService runs;
    private final Path directory;

    @org.springframework.beans.factory.annotation.Autowired
    public VerifiedLearningMemoryService(ObjectMapper mapper, AgentRunService runs) {
        this(mapper,runs,Path.of(System.getProperty("app.data-dir",
                Path.of(System.getProperty("user.home", "."), ".advanced-ai-workbench", "data").toString())).resolve("verified-learning"));
    }
    VerifiedLearningMemoryService(ObjectMapper mapper,AgentRunService runs,Path directory) {
        this.mapper=mapper;this.runs=runs;this.directory=directory.toAbsolutePath().normalize();
    }

    public record Lesson(String id, String runId, String category, String summary, Map<String,String> sourceHashes,
                         String approvedAt) { }
    public record Candidate(String runId,String projectId,long mutationRevision,long verificationAttempts,
                            String status) { }

    public List<Candidate> candidates(String projectId) {
        return runs.verifiedCandidates(projectId).stream()
                .map(run -> new Candidate(run.id(),run.projectId(),run.mutationRevision(),run.verificationAttemptCount(),run.status()))
                .toList();
    }

    private Path storage(Path workspace) {
        Path root=workspace.toAbsolutePath().normalize();
        // Preserve case: distinct workspaces on case-sensitive filesystems must not share memory.
        // The caller canonicalizes the workspace root via toRealPath() before storage operations.
        return directory.resolve(digest(root.toString()) + ".json");
    }
    private static String digest(String text) {
        try {
            byte[] bytes=MessageDigest.getInstance("SHA-256").digest(text.getBytes(StandardCharsets.UTF_8));
            return HexFormat.of().formatHex(bytes);
        } catch (Exception failure) { throw new IllegalStateException(failure); }
    }

    private List<Lesson> load(Path root) throws IOException {
        Path file=storage(root);
        if (!Files.isRegularFile(file,LinkOption.NOFOLLOW_LINKS)) return List.of();
        if (Files.size(file)>1_048_576) throw new IOException("Learning database too large");
        return mapper.readValue(Files.readString(file,StandardCharsets.UTF_8),new TypeReference<List<Lesson>>(){});
    }

    private void save(Path root,List<Lesson> lessons) throws IOException {
        Files.createDirectories(directory);
        if (Files.isSymbolicLink(directory) || Files.isSymbolicLink(storage(root)))
            throw new IOException("Learning storage must not be a symlink");
        Path tmp=Files.createTempFile(directory,"learning-",".tmp");
        try {
            try { Files.setPosixFilePermissions(tmp,java.nio.file.attribute.PosixFilePermissions.fromString("rw-------")); }
            catch (UnsupportedOperationException ignored) { }
            Files.writeString(tmp,mapper.writeValueAsString(lessons),StandardCharsets.UTF_8);
            try { Files.move(tmp,storage(root),StandardCopyOption.REPLACE_EXISTING,StandardCopyOption.ATOMIC_MOVE); }
            catch (AtomicMoveNotSupportedException ignored) { Files.move(tmp,storage(root),StandardCopyOption.REPLACE_EXISTING); }
        } finally { Files.deleteIfExists(tmp); }
    }

    private static Path safeSource(Path root,String relative) throws IOException {
        if (relative==null || relative.isBlank() || relative.indexOf('\0')>=0) throw new IllegalArgumentException("Source path required");
        Path path=root.resolve(relative).normalize();
        if (!path.startsWith(root) || path.equals(root) || !Files.isRegularFile(path,LinkOption.NOFOLLOW_LINKS))
            throw new IllegalArgumentException("Source must be an existing regular file inside workspace");
        for (Path dir=path.getParent();dir!=null && dir.startsWith(root);dir=dir.getParent()) {
            if (Files.isSymbolicLink(dir)) throw new IllegalArgumentException("Linked directories cannot be trusted as learning evidence");
        }
        if (Files.size(path)>2_000_000) throw new IllegalArgumentException("Source too large to fingerprint");
        return path;
    }

    public synchronized Lesson approve(Path workspace,String projectId,String runId,String category,String summary,
                                       List<String> sourcePaths,boolean userApproved) throws IOException {
        if (!userApproved) throw new IllegalArgumentException("Explicit user approval is required to store a learning lesson");
        AgentRunService.AgentRun run=runs.require(runId);
        if (!Objects.equals(run.projectId(),projectId) || !"completed".equals(run.status()) ||
                run.verificationAttemptCount()==0 || !run.lastVerificationSuccessful() ||
                !run.verifiedCurrentRevision() || run.mutationRevision()==0 || run.hasVerificationFailures())
            throw new IllegalArgumentException("Learning requires a completed, successfully verified mutating run of this project");
        String clean=summary==null?"":summary.strip().replaceAll("[\\r\\n]+"," ").replaceAll("\\s+"," ");
        if (clean.length()<20 || clean.length()>600 || SECRET.matcher(clean).find())
            throw new IllegalArgumentException("Lesson must be 20..600 characters and contain no obvious credentials");
        String type=category==null?"general":category.strip().toLowerCase(Locale.ROOT);
        if (!Set.of("fix","architecture","test","tooling","general").contains(type))
            throw new IllegalArgumentException("Invalid lesson category");
        Path root=workspace.toRealPath();
        LinkedHashMap<String,String> hashes=new LinkedHashMap<>();
        for (String item:sourcePaths==null?List.<String>of():sourcePaths) {
            if (hashes.size()>=20) throw new IllegalArgumentException("Maximum 20 evidence files per lesson");
            Path actual=safeSource(root,item);
            hashes.put(root.relativize(actual).toString().replace('\\','/'),
                    digest(Files.readString(actual,StandardCharsets.UTF_8)));
        }
        if (hashes.isEmpty()) throw new IllegalArgumentException("At least one verified source file required");
        if (hashes.keySet().stream().noneMatch(run.touchedPaths()::contains))
            throw new IllegalArgumentException("At least one evidence file must have been modified by this verified run");
        List<Lesson> saved=new ArrayList<>(load(root));
        boolean duplicate=saved.stream().anyMatch(e -> e.runId().equals(runId) && e.summary().equals(clean));
        if (duplicate) throw new IllegalArgumentException("Lesson already approved for this run");
        if (saved.size()>=MAX_LESSONS) throw new IllegalArgumentException("Learning limit reached; revoke obsolete lessons first");
        Lesson lesson=new Lesson(UUID.randomUUID().toString(),runId,type,clean,Map.copyOf(hashes),Instant.now().toString());
        saved.add(lesson);
        save(root,saved);
        return lesson;
    }

    public synchronized List<Map<String,Object>> list(Path workspace) throws IOException {
        Path root=workspace.toRealPath();
        List<Map<String,Object>> out=new ArrayList<>();
        for (Lesson lesson:load(root)) {
            List<String> stale=new ArrayList<>();
            for (var entry:lesson.sourceHashes().entrySet()) {
                try {
                    Path source=safeSource(root,entry.getKey());
                    if (!digest(Files.readString(source,StandardCharsets.UTF_8)).equals(entry.getValue())) stale.add(entry.getKey());
                } catch (Exception e) { stale.add(entry.getKey()); }
            }
            out.add(Map.of("id",lesson.id(),"category",lesson.category(),"summary",lesson.summary(),
                    "runId",lesson.runId(),"approvedAt",lesson.approvedAt(),"sources",lesson.sourceHashes().keySet(),
                    "stale",!stale.isEmpty(),"stalePaths",stale));
        }
        return out;
    }

    public synchronized boolean revoke(Path workspace,String id) throws IOException {
        Path root=workspace.toRealPath();
        List<Lesson> saved=new ArrayList<>(load(root));
        boolean removed=saved.removeIf(e -> e.id().equals(id));
        if (removed) save(root,saved);
        return removed;
    }

    /** Inject approved, relevant, non-stale learning as advisory evidence, never as instructions. */
    public String recall(Path workspace,String query,int maxChars) {
        try {
            List<Map<String,Object>> valid=list(workspace).stream().filter(e -> !Boolean.TRUE.equals(e.get("stale"))).toList();
            Set<String> q=words(query);
            StringBuilder out=new StringBuilder();
            valid.stream().sorted((a,b) -> Integer.compare(score(b,q),score(a,q))).limit(5).forEach(e -> {
                if (score(e,q)==0 || out.length()>=maxChars) return;
                String snippet="- [" + e.get("category") + "] " + e.get("summary") +
                        " (evidence: " + e.get("sources") + ")\n";
                if (out.length()+snippet.length()<=maxChars) out.append(snippet);
            });
            return out.toString();
        } catch (Exception ignored) { return ""; }
    }
    private static Set<String> words(String sentence) {
        if (sentence==null) return Set.of();
        return Arrays.stream(sentence.toLowerCase(Locale.ROOT).split("[^a-z0-9]+"))
                .filter(t->t.length()>3).collect(Collectors.toSet());
    }
    private static int score(Map<String,Object> e,Set<String> q) {
        Set<String> w=words(String.valueOf(e.get("summary")));
        w.retainAll(q);
        return w.size();
    }
}
