package com.llmart.llm.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Files;
import java.nio.file.Path;

import static org.junit.jupiter.api.Assertions.*;

class OpenCodeConfigImportServiceTest {
    @TempDir Path temp;

    private OpenCodeConfigImportService importer() {
        return new OpenCodeConfigImportService(new ObjectMapper()) {
            @Override Path location() { return temp.resolve("opencode-import.json"); }
        };
    }

    @Test void importsMultipleMcpServersAndProviderWithoutLeakingSecretInSummary() throws Exception {
        var service = importer();
        var imported = service.importJson("""
                {"model":"corp/gpt-test","provider":{"corp":{"options":{"baseURL":"https://gateway.example/v1", "apiKey":"PRIVATE_SECRET"}}},
                "mcp":{"jira":{"type":"remote","url":"https://mcp.example/jira","headers":{"Authorization":"Bearer {env:JIRA_TOKEN}"}},
                       "filesystem":{"type":"local","command":["java","-jar","mcp.jar"],"enabled":false}}}
                """);
        assertEquals("corp/gpt-test", imported.selectedModel());
        assertEquals(1, imported.providers());
        assertEquals(2, imported.mcpServers());
        assertTrue(imported.serverNames().contains("jira"));
        assertTrue(Files.isRegularFile(temp.resolve("opencode-import.json")));
        assertFalse(imported.toString().contains("PRIVATE_SECRET"));
        assertFalse(service.summary().toString().contains("PRIVATE_SECRET"));
        assertEquals(2, service.summary().mcpServers());
    }

    @Test void rejectsInvalidServerWithoutOverwritingPreviousImport() throws Exception {
        var service = importer();
        service.importJson("""{"model":"corp/gpt-test"}""");
        String before = Files.readString(temp.resolve("opencode-import.json"));
        assertThrows(IllegalArgumentException.class,
                () -> service.importJson("""{"mcp":{"bad":{"type":"local"}}}"""));
        assertEquals(before, Files.readString(temp.resolve("opencode-import.json")));
    }

    @Test void rejectsRemoteNonHttpUrlsAndInvalidJson() {
        var service = importer();
        assertThrows(IllegalArgumentException.class,
                () -> service.importJson("""{"mcp":{"bad":{"type":"remote","url":"file:///etc/passwd"}}}"""));
        assertThrows(IllegalArgumentException.class, () -> service.importJson("not json"));
        assertFalse(Files.exists(temp.resolve("opencode-import.json")));
    }
}
