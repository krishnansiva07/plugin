'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const root = path.join(__dirname, '../../main/resources/static');
const app = fs.readFileSync(path.join(root, 'app.js'), 'utf8');
const css = fs.readFileSync(path.join(root, 'app.css'), 'utf8');
const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
const scope = {window:{}};
vm.runInNewContext(fs.readFileSync(path.join(root, 'markdown.js'), 'utf8'), scope);
const render = scope.window.MarkdownRenderer.render;

test('open unfilled fenced block does not render an empty black code card', () => {
  assert.equal(render('```java\n', {streaming:true}).trim(), '');
  assert.match(render('```java\npublic class A {}', {streaming:true}), /code-body/);
});
test('long generated code has a single bounded scrolling container', () => {
  assert.match(css, /v124: one scroll container for code/);
  assert.match(css, /\.message\.assistant \.code-block \.code-body,[\s\S]*?max-height: min\(520px, 65vh\);[\s\S]*?overflow-y: auto/);
  assert.match(css, /\.message\.assistant \.code-block \.code-body pre,[\s\S]*?max-height: none/);
  const generated = '```java\n' + 'var x=1;\n'.repeat(2000) + '```';
  const output = render(generated);
  assert.match(output, /code-block/);
  assert.ok(output.length > 15000);
});
test('settings exposes upload and never starts MCP just by selecting the JSON', () => {
  assert.match(html, /id="importOpenCodeConfig"/);
  assert.match(html, /id="openCodeConfigFile"/);
  assert.match(app, /api\/opencode\/config\/import/);
  assert.match(app, /MCP stays off until explicitly enabled and requested/);
});
test('agent done event defers to durable run verification', () => {
  assert.match(app, /SSE 'done' means the transport finished, not that verification passed/);
  assert.match(app, /api\/agent\/runs\/\$\{encodeURIComponent\(ownedRun\)\}/);
  assert.doesNotMatch(app, /if \(assistant\.mode === 'agent' &&[\s\S]{0,200}percent:100,\s*phase:'completed'/);
});
