'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const read = (path) => fs.readFileSync(path, 'utf8');
const app = read('src/main/resources/static/app.js');
const html = read('src/main/resources/static/index.html');
const agent = read('src/main/java/com/llmart/llm/service/AgentService.java');
const policy = read('src/main/java/com/llmart/llm/service/AgentToolPolicy.java');
const controller = read('src/main/java/com/llmart/llm/controller/AgentLearningController.java');

test('v125 MCP and RAG builders use the existing Agent tool approval and verification flow', () => {
  assert.match(agent,/case "mcp_scaffold"/);
  assert.match(agent,/case "rag_scaffold"/);
  assert.match(agent,/agentBuilders\.generate\(ws,"mcp-python"/);
  assert.match(agent,/agentBuilders\.generate\(ws,"rag-python"/);
  assert.match(agent,/"mcp_scaffold", "rag_scaffold"\)\.contains\(tool\)/);
  assert.match(policy,/"mcp_scaffold", "rag_scaffold"/);
  assert.match(agent, /"mcp_scaffold", "rag_scaffold"\)\.contains\(tool\)\) return settings\.editPermission\(\)/);

  assert.match(agent,/return AgentBuilderService\.expectedPaths\(/);
  assert.match(agent,/"mcp_scaffold"\.equals\(tool\) \|\| "rag_scaffold"\.equals\(tool\)\) return true/);
});

test('v125 learning keeps control in Settings and never autopromotes an unapproved lesson', () => {
  for (const id of ['learningCandidate','learningSummary','learningSources','learningCategory','learningApproved',
                    'approveLearning','refreshLearning','learningLessons'])
    assert.match(html,new RegExp(`id="${id}"`));
  assert.match(app,/loadVerifiedLearning\(/);
  assert.match(app,/approveVerifiedLearning\(/);
  assert.match(app,/approved: Boolean\(\$\('learningApproved'\)\?\.checked\)/);
  assert.match(controller,/@PostMapping\("\/lessons"\)/);
  assert.match(controller,/@DeleteMapping\("\/lessons\/\{id\}"\)/);
  assert.match(agent,/verifiedLearning\.recall\(ws\.root\(\), request\.message\(\), 2200\)/);
});

test('v125 builder prompts are visible in standard Agent prompt library', () => {
  assert.match(app,/title: 'Create Custom MCP Server'/);
  assert.match(app,/title: 'Create Custom RAG Application'/);
  assert.match(app,/\.\.\.ELIYA125_BUILDER_PROMPTS/);
});
