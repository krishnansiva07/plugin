#!/usr/bin/env bash
set -euo pipefail
script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
mkdir -p "$HOME/.local/bin"
ln -sfn "$script_dir/eliya" "$HOME/.local/bin/eliya"
echo "Installed launcher: $HOME/.local/bin/eliya"
case ":$PATH:" in
  *":$HOME/.local/bin:"*) echo "Run 'eliya' inside any project directory." ;;
  *) echo 'Add to your shell profile: export PATH="$HOME/.local/bin:$PATH"' ;;
esac
