# Run once in PowerShell (as the current user): .\install-eliya-windows.ps1
# Append the folder containing eliya.cmd to the user's PATH; no administrator rights needed.
$root = (Resolve-Path $PSScriptRoot).Path
$existing = [Environment]::GetEnvironmentVariable('Path', 'User')
$entries = @($existing -split ';' | Where-Object { $_ })
if (-not ($entries | Where-Object { $_.TrimEnd('\') -ieq $root.TrimEnd('\') })) {
    [Environment]::SetEnvironmentVariable('Path', (($entries + $root) -join ';'), 'User')
    Write-Host "Registered Eliya on user PATH: $root"
} else { Write-Host "Eliya already on user PATH: $root" }
if (-not (($env:Path -split ';') | Where-Object { $_.TrimEnd('\') -ieq $root.TrimEnd('\') })) {
    $env:Path += ';' + $root
}
Write-Host 'Open a NEW Command Prompt, PowerShell, VS Code, or IntelliJ terminal and run: eliya'
