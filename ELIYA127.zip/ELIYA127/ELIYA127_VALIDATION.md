# ELIYA127 Validation Report

**Scope:** Terminal Analyse/Agent output formatting added to ELIYA126 source code.

| Check | Result | Method |
| --- | --- | --- |
| Java 17 renderer compilation | PASS | `javac --release 17` |
| Rich rendering smoke: chunked Markdown / code fences | PASS | `qa/eliya127/run-rich-renderer-smoke.sh` |
| Rich rendering smoke: Java syntax, JSON, Mermaid, Markdown table | PASS | Same |
| Rich rendering smoke: diff addition/removal, ANSI, CRLF, fallback | PASS | Same |
| Rich rendering smoke: malicious terminal controls removed | PASS | Same |
| Java 17 CLI bridge smoke (stub harness) | PASS | `qa/eliya126/run-java-cli-smoke.sh` |
| Terminal launcher/browser source smoke | PASS | `qa/eliya126/run-terminal-smoke.sh` |
| Existing JavaScript regressions | PASS (112/112) | `node --test src/test/js/*.test.js` |
| Full Maven compile / executable JAR launch | NOT RUN | Maven/dependencies unavailable in this environment |
| Real LLM SSE stream / Agent tools | NOT RUN | Requires configured credentials and running JAR |
| Real Windows CMD / VS Code / IntelliJ terminal tests | NOT RUN | Requires host-specific validation |

The ZIP is **source code**, not a built or verified executable JAR. Tests cover rendering and source-level bridge behavior; they do not establish complete end-to-end application functionality.
