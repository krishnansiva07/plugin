# ELIYA126 — Terminal Analyse & Agent

## What changed

ELIYA126 extends the ELIYA125 terminal launcher to support **actual AI prompts** from Windows CMD/PowerShell, VS Code, IntelliJ, macOS and Linux terminals. All commands call the **native Eliya** service in the already-running JAR; there is no separate AI engine or model implementation.

The browser still starts automatically when the JAR starts (unless disabled). An `eliya` command from a project folder maps that local project, starts background indexing and opens the running app. `eliya analyse` and `eliya agent` enter prompt mode in the terminal; quoted one-shot prompts work too.

## Getting started

1. Build the Java 17 Maven project: `./mvnw clean package` on Unix or `mvnw.cmd clean package` on Windows. The Maven build **has not been verified in this delivery environment**.
2. Register the CLI using `install-eliya-windows.ps1` (Windows) or `./install-eliya.sh` (macOS/Linux). Reopen IDE terminals after PATH changes.
3. Start the server once: `java -jar target/eliya.jar`. Browser opens automatically at `http://127.0.0.1:8090` (unless another port is configured).
4. In browser **Settings**, configure a valid API key, Base URL, chat model and agent model. The browser syncs settings to **process memory** over its same-origin localhost endpoint; API keys are **not written** to the CLI bridge file or an extra CLI settings file. If browser settings are missing, AI commands return an actionable error instead of trying to run with empty credentials.
5. In CMD, PowerShell, VS Code or IntelliJ terminal opened in your project, run:

```shell
eliya                       # map current project + open browser
eliya analyse               # interactive read-only prompt mode
eliya analyse "Explain the framework's architecture"
eliya agent                 # interactive implementation / execution
eliya agent "Add integration tests for this module"
eliya implement             # execute the most recent completed analysis
eliya workspace             # show workspace, mode and model readiness
eliya workspace "D:\Work\New Project"
eliya change workspace "D:\Work\New Project"
eliya status
```

Interactive mode accepts `/analyse`, `/agent`, `/implement`, `/workspace <path>`, `/status`, `/help` and `/exit`. Paths containing spaces must be quoted where the shell requires it. Do not include the shell prompt (`PS ...>`) in commands. Note that `eliya workspace` without a path shows the current selection, while `eliya workspace <path>` changes it.

## Execution details

- **Analyse**: `ChatRequest.mode=chat`. Reads mapped project context, generates a response, persists the history, and does not invoke mutating agent tools.
- **Agent**: `ChatRequest.mode=agent`. Executes the existing native AgentService tools within the mapped workspace subject to the configured tool approval and deletion safeguards. An LLM call, command, or test can still fail; a saved result does not imply successful verification.
- **Implement**: Checks for an earlier saved Analyse response in the **same workspace-scoped conversation**, and routes a continuation instruction to Agent. It does **not** execute untrusted text in a shell directly. Review the plan before invoking `eliya implement`.
- Terminal and browser use a **shared conversation ID** for the currently mapped workspace. The browser follows terminal selection revisions, opens the corresponding chat history, and refreshes after terminal completion.
- Requests pin their workspace path so changing the global browser selection from a second terminal does not redirect the first terminal's execution to another directory. Separate terminal processes are still operating against the same local Eliya server; concurrent commands may compete for resources.
- The terminal sends the same SSE request path as browser Chat/Agent; analysis tokens and agent action text are streamed to stdout. All responses, runs, and reports remain accessible from the browser. The terminal does not currently implement an independent interactive approval/clarification dialog for an Agent run; respond to pending questions or approval requests in the browser.

## Security and reliability

The bridge binds only to loopback requests and CLI mutations require the random per-process 256-bit token in the user's data directory. Browser settings sync requires a same-origin request plus a custom UI header. No API key is returned by CLI status/selection calls. Clearing the browser API key explicitly clears the memory-only terminal configuration. Browser auto-opening uses the fixed 127.0.0.1 scheme/host check from v125.

`/implement` does not silently approve external tool permissions. If the model does not provide a completed analysis or if Agent verification fails, use the browser's run report to investigate. Ctrl+C closes a terminal stream but should not be treated as a verified server-side Agent cancellation; use the browser Stop command to cancel the persisted run.

## Limitations of this delivery

The source change was compile-checked with a Java 17 stub harness, and JavaScript regressions passed. A **full Spring Boot Maven build/JAR launch against a live configured model** could not be performed because Maven and Maven Central were unavailable in the authoring environment. Build the source on the target Java 17 machine to validate the full integration before production use.
