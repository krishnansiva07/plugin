#!/usr/bin/env bash
set -euo pipefail
# Preserve the caller's working directory so java -jar detects the user's project.
app_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
jar="$app_dir/target/eliya.jar"
if [ ! -f "$jar" ]; then
  echo "ELIYA JAR not found. Building in $app_dir ..."
  (cd "$app_dir" && ./mvnw clean package)
fi
exec java -jar "$jar" "$@"
