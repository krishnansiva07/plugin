# ELIYA v125 — Validation report

Source package was built from the provided ELIYA v123 source through v124 changes plus the v125 changes listed in `ELIYA125_RELEASE_NOTES.md`.

## Executed checks

| Check | Result |
|---|---|
| Node frontend regression suite | PASS, 112/112 tests |
| Node source syntax (`app.js`) | PASS |
| v125 learning UI wiring and safe text rendering | PASS, 16 checks |
| Java 17-compatible isolated MCP/RAG builder and learning smoke | PASS, 20 checks (using test dependency stubs) |
| Java tool registry and mutation permission smoke | PASS, 10 checks (using test dependency stubs) |
| Generated MCP starter Python unit tests | PASS |
| Generated RAG starter Python unit tests | PASS |
| Tests executed from genuinely generated MCP/RAG workspace folders | PASS |
| Existing v124 completion/output assertions | PASS, 11 assertions |
| Existing v123 spec flow | PASS, 8 assertions |
| Existing v123 output contracts | PASS, 16 scenarios |
| Maven dependency-resolving build | NOT RUN (Maven and dependencies unavailable) |
| Spring Boot executable JAR | NOT PRODUCED / NOT VERIFIED |
| Live MCP provider and LLM integration | NOT TESTED |

`qa/eliya125/run.sh` produced a zero exit code in this environment. Complete raw output: `ELIYA125-validation-final.log` (provided with the packaged source under `validation/` for convenience).

## Release gate on user's system

```bash
mvn -B -Pfull-tests -Dmaven.test.skip=false clean verify
java -jar target/eliya.jar
```

Perform these acceptance tests in the actual UI: generate MCP/RAG projects in a writable workspace and run their tests; verify remote MCP still requires explicit opt-in; verify a current lesson is recalled, a modified/deleted source invalidates it, and a failed Agent run cannot be approved; verify v124 analysis-rich Markdown rendering and final completion state.

**Decision:** Source-level tested package; do not label fully end-to-end validated until the local Maven build and live UI tests succeed.
