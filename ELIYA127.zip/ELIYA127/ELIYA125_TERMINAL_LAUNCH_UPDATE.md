# ELIYA125 — Automatic browser launch and IDE/terminal workspace mapping

**Source enhancement:** This update is based on the user-supplied `ELIYA125.zip`, and retains the existing v125 MCP/RAG tools, Analyse → Agent workflow, indexing, and preferences. This deliverable is source code, **not a compiled JAR**, because Maven and network access to Maven Central were unavailable in the packaging environment.

## Features implemented

1. **Start from a JAR:** `java -jar target/eliya.jar` opens the locally hosted UI in the default browser after Spring Boot startup, using `http://127.0.0.1:8090/` by default. If the terminal is located inside a recognizable source project, the project is mapped automatically. On headless machines or if launching a browser fails, the UI URL is printed.
2. **Run `eliya` in any terminal:** `eliya` (Unix/macOS), `eliya.cmd` (Windows) capture the calling terminal's directory. Java walks only parent directories for common Maven/Gradle/Git/Node/Python/Go/Rust project markers and maps the nearest project root. This works in Command Prompt, PowerShell, integrated VS Code and IntelliJ IDEA terminals, and ordinary Unix terminal emulators. For a new project without a build manifest, the current directory is used.
3. **Change workspace:** `eliya workspace "C:\\projects\\another-app"`, `eliya change workspace "C:\\projects\\another-app"`, or `eliya --workspace "/path/to/app"`. Relative paths work from the calling shell's directory; paths containing spaces must be quoted.
4. **Reuse the running server:** A second `eliya` command talks to the already-running local server through `/api/cli/activate` instead of starting a duplicate process. Workspace changes are applied to the browser through a lightweight `/api/cli/selection` poll (3.5-second interval). Eliya queues indexing in the existing background indexing service. The selected workspace is shared by Analyse and Agent; current conversations and reference projects are not erased.
5. **Safer CLI bridge:** The bridge is accessible only over the loopback interface, workspace-changing calls require a randomly generated per-process 256-bit secret, stored under the existing per-user Eliya data directory with POSIX owner-only permissions where supported. The file is removed during normal shutdown. The bridge rejects invalid paths and unauthorized callers. Home and filesystem/drive root are never implicitly selected as workspaces.

## One-time setup — Windows (Command Prompt, PowerShell, VS Code, IntelliJ)

Build from the unzipped project with JDK 17 and Maven:

```bat
cd C:\tools\ELIYA125
mvnw.cmd clean package
```

In PowerShell, register the launcher in your current **user** PATH (no administrator privileges):

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\install-eliya-windows.ps1
```

Open a **new** terminal in VS Code, IntelliJ, PowerShell, or Command Prompt after PATH is refreshed:

```bat
cd C:\work\selenium-framework
eliya
```

This terminal remains occupied by Eliya's application logs while running. You can stop the server with Ctrl+C. Use another terminal or the UI to switch workspaces while it is running:

```bat
eliya change workspace "D:\Automation Projects\playwright-framework"
eliya open
```

The IDE terminal must run on the **same machine** as the Eliya Java server. Terminals inside a remote SSH container or WSL have distinct filesystem paths and may not be able to see a Windows-only workspace path.

## One-time setup — Linux/macOS

```bash
cd /path/to/ELIYA125
./mvnw clean package
./install-eliya.sh
# If ~/.local/bin is not already in PATH, add it to your shell startup file.
cd /path/to/my-project
eliya
```

To switch from a second terminal:

```bash
eliya change workspace "/path/to/my-other-project"
```

You can also run directly from any working directory without installing the `eliya` PATH alias:

```bash
java -jar /path/to/ELIYA125/target/eliya.jar
```

## Validation performed in this packaging environment

- `bash qa/eliya126/run-java-cli-smoke.sh`: **passed** Java 17 source compilation using isolated Spring/Jackson test stubs; tested startup workspace selection, local loopback access checks, token gating, workspace switching, version updates, `open` without switching, invalid path responses, IDE nested-project detection, and token-file removal.
- `bash qa/eliya126/run-terminal-smoke.sh`: **passed** source launcher working-directory preservation, path-with-spaces handling, CLI arguments, JS syntax, and browser bridge integration contract.
- `bash qa/eliya125/run.sh`: **passed** 112 existing JavaScript tests, existing v123–v125 source-level regressions, and generated MCP/RAG Python tests.
- `bash mvnw -B -DskipTests package`: **blocked**. No Maven installation or Maven dependency cache was available; the bootstrap attempt failed because `repo.maven.apache.org` could not be resolved. **A runnable JAR, live Spring Boot startup, browser opening, Windows/macOS execution, and real LLM behavior have therefore not been fully verified in this environment.**

## End-to-end acceptance checks on your machine

1. Build with `mvnw.cmd -Pfull-tests -Dmaven.test.skip=false clean verify` or `./mvnw -Pfull-tests -Dmaven.test.skip=false clean verify` on JDK 17 (or use an enterprise-approved Maven repository mirror).
2. Start `java -jar target/eliya.jar`. Confirm the browser opens at `http://127.0.0.1:8090/` and Eliya starts normally.
3. In a fresh VS Code or IntelliJ terminal within a sample workspace, run `eliya`. Confirm its project root appears in the browser Workspace bar and indexing runs in the background.
4. In a second terminal, run `eliya change workspace "<another valid folder>"`; verify the current browser tab updates and Chat/Agent use the new path without losing messages.
5. Check `eliya workspace "<nonexistent folder>"` fails visibly. Check attempting to map the drive/home root is safely rejected. Ensure `eliya open` does not change workspace.
6. Stop the primary Eliya process with Ctrl+C, then run `eliya` again and verify the new instance starts without a stale-token problem.

**Scope note:** This feature launches and maps projects from a system terminal; it does *not* add a separate interactive natural-language CLI agent. Use the Eliya browser's Analyse/Agent modes for prompts and editing.
