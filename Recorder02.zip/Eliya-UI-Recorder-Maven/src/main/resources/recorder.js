/* Eliya UI Recorder v1.1: injected into each Chromium document via DevTools.
   No external libraries and no modification of the tested application's requests. */
(() => {
  'use strict';
  if (window.__eliyaRecorderInit) return;
  Object.defineProperty(window, '__eliyaRecorderInit', {value: true, configurable: false});

  const options = Object.assign({domMaxNodes: 1000, domMaxDepth: 24, domMaxSiblings: 40,
    maxAttributeChars: 4096, maxTextChars: 700, captureMotion: false}, window.__eliyaRecorderSettings || {});
  const clamp = (value, min, max) => Math.min(max, Math.max(min, Number(value) || min));
  options.domMaxNodes = clamp(options.domMaxNodes, 1, 10000);
  options.domMaxDepth = clamp(options.domMaxDepth, 1, 80);
  options.domMaxSiblings = clamp(options.domMaxSiblings, 0, 100);
  options.maxAttributeChars = clamp(options.maxAttributeChars, 64, 12000);
  options.maxTextChars = clamp(options.maxTextChars, 0, 4000);

  const REDACTED = '[REDACTED]';
  const secretName = /pass(?:word|wd)?|secret|token|auth(?:oriz|enticat)?|api[_-]?key|session|cookie|bearer|credit.?card|card.?number|cvv|cvc|pin.?code|one.?time.?pass|otp|ssn|social.?security|private.?key|access[_-]?key|csrf/i;
  const sensitive = el => {
    if (!(el instanceof Element)) return false;
    const source = [el.getAttribute('type'), el.getAttribute('id'), el.getAttribute('name'),
      el.getAttribute('autocomplete'), el.getAttribute('aria-label'), el.getAttribute('placeholder')].join(' ');
    if (secretName.test(source)) return true;
    return !!el.closest('[data-sensitive="true"],[data-private="true"],[data-recorder-redact="true"]');
  };
  const text = (x, max = options.maxTextChars) => String(x ?? '').slice(0, max);
  const safeUrl = value => {
    try {
      const url = new URL(String(value), document.baseURI);
      if (!['http:', 'https:'].includes(url.protocol)) return url.protocol + '[OMITTED]';
      url.username = ''; url.password = '';
      for (const key of [...url.searchParams.keys()]) {
        if (secretName.test(key)) url.searchParams.set(key, REDACTED);
      }
      return text(url.href, 4096);
    } catch (_) { return text(value, 2048); }
  };
  const redactValue = (name, value, el) => {
    if (secretName.test(name) || sensitive(el)) return REDACTED;
    if (/^(href|src|action|formaction|cite|poster)$/i.test(name)) return safeUrl(value);
    return text(value, options.maxAttributeChars);
  };
  const attributes = el => {
    const result = {};
    for (const a of [...el.attributes]) result[a.name] = redactValue(a.name, a.value, el);
    return result;
  };
  const isVisible = el => {
    try {
      const css = getComputedStyle(el);
      const rect = el.getBoundingClientRect();
      return css.display !== 'none' && css.visibility !== 'hidden' && css.visibility !== 'collapse' &&
        Number(css.opacity) > 0 && (rect.width > 0 || rect.height > 0);
    } catch (_) { return null; }
  };
  const rectOf = el => {
    try {
      const r = el.getBoundingClientRect();
      return {x: Math.round(r.x), y: Math.round(r.y), width: Math.round(r.width),
        height: Math.round(r.height), top: Math.round(r.top), left: Math.round(r.left),
        bottom: Math.round(r.bottom), right: Math.round(r.right)};
    } catch (_) { return null; }
  };
  const propsOf = el => {
    const x = {id: text(el.id, 256), className: typeof el.className === 'string' ? text(el.className, 1000) : '',
      visible: isVisible(el), boundingBox: rectOf(el),
      disabled: !!el.disabled, readOnly: !!el.readOnly, required: !!el.required,
      checked: typeof el.checked === 'boolean' ? !!el.checked : null,
      selected: typeof el.selected === 'boolean' ? !!el.selected : null,
      multiple: !!el.multiple, contentEditable: !!el.isContentEditable,
      tabIndex: typeof el.tabIndex === 'number' ? el.tabIndex : null,
      scrollLeft: el.scrollLeft || 0, scrollTop: el.scrollTop || 0};
    if (el instanceof HTMLInputElement || el instanceof HTMLTextAreaElement || el instanceof HTMLSelectElement) {
      x.value = sensitive(el) ? REDACTED : (el.type === 'file' ? '[FILE_INPUT]' : text(el.value, 3000));
      if (el instanceof HTMLSelectElement) x.selectedIndex = el.selectedIndex;
    }
    return x;
  };
  const containsSensitive = el => sensitive(el) || !!el.querySelector?.(
    'input[type="password"],[data-sensitive="true"],[data-private="true"],[data-recorder-redact="true"]');
  const safeText = el => {
    if (containsSensitive(el)) return REDACTED;
    // Only direct text nodes: descendant text is captured in the children tree.
    return text([...el.childNodes].filter(n => n.nodeType === Node.TEXT_NODE)
      .map(n => n.textContent).join(' ').replace(/\s+/g, ' ').trim());
  };
  const summary = el => ({tag: el.localName, id: text(el.id, 256),
    role: text(el.getAttribute('role'), 128), testId: text(el.getAttribute('data-testid'), 256),
    attributes: attributes(el)});

  const escapeCss = value => (window.CSS?.escape ? CSS.escape(String(value)) : String(value).replace(/[^\w-]/g, x => '\\' + x));
  const selectorAttr = (name, value) => '[' + name + '="' + String(value).replaceAll('\\', '\\\\').replaceAll('"', '\\"') + '"]';
  const unique = (root, s) => { try { return root.querySelectorAll(s).length === 1; } catch (_) { return false; } };
  const localCss = (el, root) => {
    for (const name of ['data-testid', 'data-test', 'data-qa', 'data-cy']) {
      const val = el.getAttribute(name);
      if (val && !secretName.test(name) && !secretName.test(val)) {
        const s = selectorAttr(name, val); if (unique(root, s)) return s;
      }
    }
    if (el.id && !secretName.test(el.id)) { const s = '#' + escapeCss(el.id); if (unique(root, s)) return s; }
    const tag = el.localName;
    for (const name of ['name', 'aria-label', 'placeholder']) {
      const val = el.getAttribute(name);
      if (val && !secretName.test(name) && !secretName.test(val)) {
        const s = tag + selectorAttr(name, val); if (unique(root, s)) return s;
      }
    }
    const parts = [];
    let current = el;
    for (let n = 0; n < 50 && current instanceof Element; n++) {
      const name = current.localName;
      const parent = current.parentElement;
      if (current.id && !secretName.test(current.id)) { parts.unshift('#' + escapeCss(current.id)); break; }
      let piece = name;
      if (parent) {
        const siblings = [...parent.children].filter(x => x.localName === name);
        if (siblings.length > 1) piece += ':nth-of-type(' + (siblings.indexOf(current) + 1) + ')';
      }
      parts.unshift(piece);
      if (unique(root, parts.join(' > '))) break;
      current = parent;
    }
    return parts.join(' > ');
  };
  const cssPath = el => {
    const parts = [];
    let current = el;
    for (let n = 0; n < 20; n++) {
      const root = current.getRootNode();
      parts.unshift(localCss(current, root));
      if (!(root instanceof ShadowRoot)) break;
      current = root.host;
    }
    return parts;
  };
  const xpath = el => {
    if (el.getRootNode() instanceof ShadowRoot) return null; // XPath does not pierce shadow roots.
    const parts = [];
    for (let curr = el, i = 0; curr && curr.nodeType === 1 && i < 80; curr = curr.parentElement, i++) {
      if (curr.id && !secretName.test(curr.id) && !curr.id.includes('"')) {
        parts.unshift('//*[@id="' + curr.id + '"]'); break;
      }
      const siblings = curr.parentElement ? [...curr.parentElement.children].filter(x => x.localName === curr.localName) : [];
      parts.unshift(curr.localName + '[' + (Math.max(0, siblings.indexOf(curr)) + 1) + ']');
    }
    return parts.join('/').replace(/^\//, parts[0]?.startsWith('//*') ? '' : '/');
  };
  const frameContext = () => {
    const path = [];
    try {
      let win = window;
      while (win !== win.parent && path.length < 16) {
        const frame = win.frameElement;
        if (!(frame instanceof Element)) break;
        path.unshift({tag: frame.localName, id: text(frame.id, 200),
          name: text(frame.getAttribute('name'), 200), src: safeUrl(frame.getAttribute('src') || win.location.href)});
        win = win.parent;
      }
    } catch (_) { /* Cross-origin boundaries are not directly traversable. */ }
    return {isIframe: window !== window.top, framePath: path, frameUrl: safeUrl(location.href)};
  };
  const locators = el => {
    const parts = cssPath(el);
    const labels = el.labels ? [...el.labels].map(x => text(x.innerText, 200)).filter(Boolean) : [];
    const role = el.getAttribute('role') || ({BUTTON:'button', A:'link', SELECT:'combobox', TEXTAREA:'textbox'}[el.tagName] || '');
    const accessibleName = el.getAttribute('aria-label') || el.getAttribute('title') ||
      (el.matches('button,a,[role="button"],[role="link"]') ? text(el.innerText, 180) : '');
    return {css: parts.join(' >>> '), shadowPath: parts.length > 1 ? parts : [], xpath: xpath(el),
      testId: text(el.getAttribute('data-testid') || el.getAttribute('data-test') || el.getAttribute('data-qa'), 200),
      role: text(role, 100), accessibleName: containsSensitive(el) ? REDACTED : text(accessibleName, 200),
      label: containsSensitive(el) ? REDACTED : text(labels[0], 200),
      name: text(el.getAttribute('name'), 200), id: text(el.id, 200),
      placeholder: sensitive(el) ? REDACTED : text(el.getAttribute('placeholder'), 200)};
  };
  const domTree = (el, event) => {
    const budget = {count: 0, omitted: 0};
    const walk = (node, depth) => {
      if (budget.count >= options.domMaxNodes || depth > options.domMaxDepth) {
        budget.omitted++; return null;
      }
      budget.count++;
      const out = {tag: node.localName, nodeType: 'element', attributes: attributes(node),
        properties: propsOf(node), directText: safeText(node), children: []};
      for (const child of node.children) {
        const data = walk(child, depth + 1);
        if (data) out.children.push(data);
        else { out.truncated = true; break; }
      }
      // Open shadow roots are included as nested trees. Closed roots cannot be inspected later.
      if (node.shadowRoot) {
        const shadow = [];
        for (const child of node.shadowRoot.children) {
          const data = walk(child, depth + 1);
          if (data) shadow.push(data);
          else { out.truncated = true; break; }
        }
        out.shadowRoot = {mode: 'open', children: shadow};
      }
      return out;
    };
    const ancestors = [];
    let parent = el;
    for (let i = 0; i < 80 && parent; i++) {
      if (parent instanceof Element) ancestors.push(summary(parent));
      const root = parent.getRootNode();
      parent = parent.parentElement || (root instanceof ShadowRoot ? root.host : null);
    }
    const siblings = [];
    const children = el.parentElement?.children || [];
    let skipped = 0;
    for (const child of children) {
      if (child === el) continue;
      if (siblings.length < options.domMaxSiblings) siblings.push(summary(child));
      else skipped++;
    }
    const path = event?.composedPath?.().filter(x => x instanceof Element).slice(0, 50).map(summary) || [];
    return {targetTree: walk(el, 0), ancestorChain: ancestors,
      siblings, omittedSiblings: skipped, composedEventPath: path,
      capturedNodeCount: budget.count, omittedNodeBranches: budget.omitted,
      truncated: budget.omitted > 0 || skipped > 0,
      limits: {maxNodes: options.domMaxNodes, maxDepth: options.domMaxDepth, maxSiblings: options.domMaxSiblings}};
  };
  const details = (el, event, includeTree = true) => {
    if (!(el instanceof Element)) return {};
    const locator = locators(el);
    return {tag: el.localName, inputType: text(el.type, 80), selector: locator.css,
      locators: locator, text: containsSensitive(el) ? REDACTED : text(el.innerText || el.textContent, 400),
      attributes: attributes(el), properties: propsOf(el), sensitive: sensitive(el),
      ...(includeTree ? {dom: domTree(el, event)} : {})};
  };
  const getElement = event => event?.composedPath?.().find(node => node instanceof Element) ||
    (event?.target instanceof Element ? event.target : null);
  const actionEl = event => {
    const el = getElement(event);
    if (!el) return null;
    return el.closest('button,a,input,textarea,select,summary,option,label,[role],[contenteditable],[onclick]') || el;
  };
  const eventDetails = (e, el) => {
    if (!e) return null;
    const x = {name: e.type, isTrusted: !!e.isTrusted, bubbles: !!e.bubbles,
      cancelable: !!e.cancelable, composed: !!e.composed, timeStamp: Math.round(e.timeStamp),
      targetTag: getElement(e)?.localName || null, currentTargetTag: e.currentTarget?.localName || null};
    if (e instanceof MouseEvent) Object.assign(x, {button: e.button, buttons: e.buttons,
      clientX: e.clientX, clientY: e.clientY, ctrlKey: e.ctrlKey, altKey: e.altKey,
      shiftKey: e.shiftKey, metaKey: e.metaKey, detail: e.detail});
    if (window.PointerEvent && e instanceof PointerEvent) Object.assign(x, {pointerId: e.pointerId,
      pointerType: e.pointerType, pressure: e.pressure, tiltX: e.tiltX, tiltY: e.tiltY,
      isPrimary: e.isPrimary});
    if (e instanceof KeyboardEvent) Object.assign(x, {key: sensitive(el) ? REDACTED : text(e.key, 60),
      code: sensitive(el) ? REDACTED : text(e.code, 60), repeat: e.repeat, location: e.location,
      ctrlKey: e.ctrlKey, altKey: e.altKey, shiftKey: e.shiftKey, metaKey: e.metaKey});
    if (e instanceof InputEvent) Object.assign(x, {inputType: e.inputType,
      data: sensitive(el) ? REDACTED : text(e.data, 150), isComposing: e.isComposing});
    if (e instanceof WheelEvent) Object.assign(x, {deltaX: e.deltaX, deltaY: e.deltaY, deltaMode: e.deltaMode});
    if (e instanceof DragEvent) Object.assign(x, {dataTransferTypes: [...(e.dataTransfer?.types || [])]});
    if (e instanceof FocusEvent) x.relatedTarget = e.relatedTarget instanceof Element ? summary(e.relatedTarget) : null;
    return x;
  };
  const send = (type, properties = {}) => {
    try {
      if (typeof window.__eliyaRecorderSend !== 'function') return;
      window.__eliyaRecorderSend(JSON.stringify({type, timestamp: new Date().toISOString(),
        pageUrl: safeUrl(location.href), title: text(document.title, 300),
        frame: frameContext(), ...properties}));
    } catch (_) { /* Never break user application interaction. */ }
  };
  const emit = (type, event, includeTree = true, extra = {}) => {
    const el = actionEl(event);
    const target = el ? details(el, event, includeTree) : {};
    send(type, {event: eventDetails(event, el), ...target, ...extra});
  };
  const timeouts = new Map();
  const lastValue = new WeakMap();
  const inputEl = e => {
    const el = getElement(e);
    return el?.matches?.('input,textarea,select,[contenteditable=""],[contenteditable="true"],[role="textbox"]') ? el : null;
  };
  const saveInput = (el, event) => {
    if (!el) return;
    let type = 'fill';
    const values = {};
    if (el.type === 'checkbox' || el.type === 'radio') { type = 'check'; values.checked = !!el.checked; }
    else if (el.tagName === 'SELECT') {
      type = 'select'; values.value = sensitive(el) ? REDACTED : text(el.value, 3000);
      if (el.multiple) values.selected = sensitive(el) ? [REDACTED] :
        [...el.selectedOptions].map(o => text(o.value, 1000));
    } else if (el.type === 'file') {
      type = 'fileSelected'; values.files = [...(el.files || [])].map(f => text(f.name, 200));
    } else values.value = sensitive(el) ? REDACTED : text(el.isContentEditable ? el.innerText : el.value, 3000);
    const signature = JSON.stringify({type, values});
    if (lastValue.get(el) === signature) return;
    lastValue.set(el, signature);
    send(type, {event: eventDetails(event, el), ...details(el, event, true), ...values});
  };
  const flushOne = el => {
    const item = timeouts.get(el);
    if (item) {clearTimeout(item.timer); timeouts.delete(el); saveInput(el, item.event);}
  };
  const flushAll = () => {
    for (const el of [...timeouts.keys()]) flushOne(el);
    if (inputEl({target: document.activeElement})) saveInput(document.activeElement, null);
  };
  window.__eliyaRecorderFlush = flushAll;
  window.addEventListener('blur', flushAll);
  document.addEventListener('input', e => {
    const el = inputEl(e);
    if (!el) return;
    const old = timeouts.get(el);
    if (old) clearTimeout(old.timer);
    timeouts.set(el, {event: e, timer: setTimeout(() => flushOne(el), 400)});
  }, true);
  document.addEventListener('change', e => {
    const el = inputEl(e);
    if (el) { flushOne(el); saveInput(el, e); }
    else emit('change', e);
  }, true);
  document.addEventListener('focusout', e => flushOne(inputEl(e)), true);

  // High-level events and most of the discrete browser event stream.
  const full = ['click','dblclick','auxclick','contextmenu','submit','reset','invalid',
    'dragstart','dragenter','dragleave','drop','dragend','focusin','focusout',
    'copy','cut','paste','compositionstart','compositionend','select'];
  const light = ['pointerdown','pointerup','pointercancel','mousedown','mouseup',
    'keydown','keyup','touchstart','touchend','touchcancel'];
  const throttled = new Map();
  const captureEvent = (e, tree) => {
    // Data from the clipboard, drag payload, and password key presses are never collected.
    const mapped = ({dblclick:'doubleClick',contextmenu:'rightClick',keydown:'keyDown',keyup:'keyUp'})[e.type] || e.type;
    emit(mapped, e, tree);
  };
  for (const name of full) document.addEventListener(name, e => captureEvent(e, true), true);
  for (const name of light) document.addEventListener(name, e => captureEvent(e, false), true);
  for (const name of ['mouseover','mouseout','pointerover','pointerout','dragover','wheel']) {
    document.addEventListener(name, e => {
      const el = actionEl(e);
      const key = name + ':' + (el ? cssPath(el).join('>>>') : 'document');
      const now = Date.now();
      if (now - (throttled.get(key) || 0) < 400) return;
      throttled.set(key, now);
      if (throttled.size > 3000) throttled.clear();
      captureEvent(e, false);
    }, {capture:true, passive:true});
  }
  if (options.captureMotion) {
    for (const name of ['mousemove','pointermove','touchmove']) document.addEventListener(name, e => {
      const now = Date.now();
      if (now - (throttled.get(name) || 0) < 350) return;
      throttled.set(name, now);
      captureEvent(e, false);
    }, {capture:true, passive:true});
  }
  document.addEventListener('scroll', e => {
    const now = Date.now(), el = e.target instanceof Element ? e.target : document.scrollingElement;
    if (!el) return;
    const key = 'scroll:' + cssPath(el).join('>>>');
    if (now - (throttled.get(key) || 0) < 350) return;
    throttled.set(key, now);
    send('scroll', {event: eventDetails(e, el), ...details(el, e, false),
      scrollX: el.scrollLeft, scrollY: el.scrollTop});
  }, {capture:true, passive:true});
  document.addEventListener('selectionchange', e => {
    const now = Date.now();
    if (now - (throttled.get('selection') || 0) < 500) return;
    throttled.set('selection', now);
    const selected = window.getSelection();
    // Text selections might include secrets: save only selection length.
    send('selectionchange', {event: eventDetails(e, null), selectionLength: selected ? selected.toString().length : 0});
  }, true);

  const navigation = source => send('navigate', {url: safeUrl(location.href), navigationSource: source});
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', () => navigation('DOMContentLoaded'), {once:true});
  else navigation('existingDocument');
  window.addEventListener('popstate', () => navigation('popstate'));
  window.addEventListener('hashchange', () => navigation('hashchange'));
  for (const name of ['pushState', 'replaceState']) {
    try {
      const original = history[name];
      history[name] = function(...args) {const result = original.apply(this, args); navigation(name); return result;};
    } catch (_) { /* Some environments disallow patching. */ }
  }
})();
