package com.eliya.recorder;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;
import java.awt.Desktop;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.nio.file.attribute.PosixFilePermission;
import java.time.Instant;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.*;

/** Standalone Java 17 application: local UI, Chrome / Edge recording, JSON export. */
public final class RecorderApp {
    private static final int MAX_ACTIONS = 100_000;
    private static final DateTimeFormatter FILE_TIME = DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss").withZone(ZoneOffset.UTC);
    private final Object lock = new Object();
    private final List<Map<String, Object>> actions = new ArrayList<>();
    private final ExecutorService background = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "recorder-launch"); t.setDaemon(true); return t;
    });
    private final String script;
    private HttpServer server;
    private BrowserRecorder browserRecorder;
    private String status = "idle";
    private String statusMessage = "Enter an application URL and select Launch.";
    private String appUrl = "";
    private String browserName = "";
    private String sessionId = "";
    private Instant startedAt;
    private Instant stoppedAt;
    private Path autosave;

    private RecorderApp() throws IOException {
        try (InputStream input = Objects.requireNonNull(
            RecorderApp.class.getResourceAsStream("/recorder.js"), "recorder.js missing")) {
            Map<String, Object> settings = Json.map(
                "domMaxNodes", Integer.getInteger("recorder.domMaxNodes", 1000),
                "domMaxDepth", Integer.getInteger("recorder.domMaxDepth", 24),
                "domMaxSiblings", Integer.getInteger("recorder.domMaxSiblings", 40),
                "maxAttributeChars", Integer.getInteger("recorder.maxAttributeChars", 4096),
                "maxTextChars", Integer.getInteger("recorder.maxTextChars", 700),
                "captureMotion", Boolean.getBoolean("recorder.captureMotion"));
            script = "window.__eliyaRecorderSettings = " + Json.stringify(settings) + ";\n" +
                new String(input.readAllBytes(), StandardCharsets.UTF_8);
        }
    }

    public static void main(String[] args) throws Exception {
        RecorderApp recorder = new RecorderApp();
        recorder.start();
        Runtime.getRuntime().addShutdownHook(new Thread(recorder::shutdown, "recorder-cleanup"));
    }

    private void start() throws IOException {
        server = HttpServer.create(new InetSocketAddress(InetAddress.getByName("127.0.0.1"),
            Integer.getInteger("recorder.port", 0)), 0);
        server.setExecutor(Executors.newFixedThreadPool(6, r -> {
            Thread thread = new Thread(r, "recorder-http"); thread.setDaemon(true); return thread;
        }));
        server.createContext("/", this::router);
        server.start();
        int port = server.getAddress().getPort();
        String ui = "http://127.0.0.1:" + port + "/";
        System.out.println("Eliya Standalone UI Recorder - Java 17+");
        System.out.println("Open the recorder dashboard: " + ui);
        System.out.println("Press Ctrl+C to quit the recorder.");
        if (!Boolean.getBoolean("recorder.noAutoOpen")) {
            try { if (Desktop.isDesktopSupported() && Desktop.getDesktop().isSupported(Desktop.Action.BROWSE))
                Desktop.getDesktop().browse(URI.create(ui)); }
            catch (Exception e) { System.out.println("Open the dashboard manually: " + ui); }
        }
    }

    private void router(HttpExchange exchange) throws IOException {
        try {
            String path = exchange.getRequestURI().getPath();
            String method = exchange.getRequestMethod();
            if (!validHost(exchange)) { reply(exchange, 403, "text/plain", "Invalid host."); return; }
            if (path.startsWith("/api/") && !"GET".equals(method) && !validOrigin(exchange)) {
                reply(exchange, 403, "application/json", Json.stringify(Json.map("error", "Invalid request origin")));
                return;
            }
            switch (path) {
                case "/" -> {
                    if (!"GET".equals(method)) { methodNotAllowed(exchange); return; }
                    try (InputStream input = Objects.requireNonNull(RecorderApp.class.getResourceAsStream("/index.html"))) {
                        reply(exchange, 200, "text/html; charset=utf-8", input.readAllBytes());
                    }
                }
                case "/favicon.ico" -> reply(exchange, 204, "image/x-icon", new byte[0]);
                case "/api/state" -> {
                    if (!"GET".equals(method)) { methodNotAllowed(exchange); return; }
                    reply(exchange, 200, "application/json", Json.stringify(state()));
                }
                case "/api/launch" -> {
                    if (!"POST".equals(method)) { methodNotAllowed(exchange); return; }
                    Map<String, String> data = readForm(exchange);
                    launch(exchange, data.getOrDefault("url", ""), data.getOrDefault("browser", "auto"));
                }
                case "/api/stop" -> {
                    if (!"POST".equals(method)) { methodNotAllowed(exchange); return; }
                    BrowserRecorder active;
                    synchronized (lock) { active = (status.equals("recording") || status.equals("starting")) ? browserRecorder : null; }
                    if (active != null) active.flushPendingInputs();
                    synchronized (lock) {
                        if (status.equals("recording") || status.equals("starting")) {
                            status = "stopped";
                            stoppedAt = Instant.now();
                            statusMessage = "Recording stopped. Your actions are ready for export.";
                        }
                    }
                    reply(exchange, 200, "application/json", Json.stringify(state()));
                }
                case "/api/action" -> {
                    if (!"GET".equals(method)) { methodNotAllowed(exchange); return; }
                    Map<String, String> query = parseQuery(exchange.getRequestURI().getRawQuery());
                    int number;
                    try { number = Integer.parseInt(query.getOrDefault("sequence", "-1")); }
                    catch (NumberFormatException e) { number = -1; }
                    Map<String, Object> selected;
                    synchronized (lock) {
                        selected = number >= 1 && number <= actions.size() ? actions.get(number - 1) : null;
                    }
                    if (selected == null) reply(exchange, 404, "application/json", Json.stringify(Json.map("error", "Action not found")));
                    else reply(exchange, 200, "application/json; charset=utf-8", Json.pretty(selected));
                }
                case "/api/export" -> {
                    if (!"GET".equals(method)) { methodNotAllowed(exchange); return; }
                    export(exchange);
                }
                case "/api/close-browser" -> {
                    if (!"POST".equals(method)) { methodNotAllowed(exchange); return; }
                    BrowserRecorder old;
                    synchronized (lock) {
                        status = "stopped";
                        if (stoppedAt == null) stoppedAt = Instant.now();
                        statusMessage = "Browser closed. Existing actions remain available for export.";
                        old = browserRecorder; browserRecorder = null;
                    }
                    if (old != null) background.execute(old::close);
                    reply(exchange, 200, "application/json", Json.stringify(state()));
                }
                default -> reply(exchange, 404, "application/json", Json.stringify(Json.map("error", "Not found")));
            }
        } catch (Exception e) {
            System.err.println("Recorder HTTP error: " + e);
            try { reply(exchange, 500, "application/json", Json.stringify(Json.map("error", e.getMessage()))); }
            catch (Exception ignored) { }
        } finally { exchange.close(); }
    }

    private boolean validHost(HttpExchange exchange) {
        String host = exchange.getRequestHeaders().getFirst("Host");
        if (host == null) return false;
        String hostname = host.split(":", 2)[0].toLowerCase(Locale.ROOT);
        return hostname.equals("127.0.0.1") || hostname.equals("localhost") || hostname.equals("[::1]");
    }

    private boolean validOrigin(HttpExchange exchange) {
        String origin = exchange.getRequestHeaders().getFirst("Origin");
        if (origin == null) return false;
        try {
            URI uri = URI.create(origin);
            String host = uri.getHost();
            return ("http".equals(uri.getScheme())) && host != null &&
                (host.equals("127.0.0.1") || host.equals("localhost") || host.equals("::1")) &&
                uri.getPort() == server.getAddress().getPort();
        } catch (Exception e) { return false; }
    }

    private static Map<String, String> parseQuery(String query) {
        Map<String, String> result = new LinkedHashMap<>();
        if (query == null || query.length() > 2048) return result;
        for (String item : query.split("&")) {
            String[] parts = item.split("=", 2);
            result.put(URLDecoder.decode(parts[0], StandardCharsets.UTF_8),
                parts.length > 1 ? URLDecoder.decode(parts[1], StandardCharsets.UTF_8) : "");
        }
        return result;
    }

    private static Map<String, String> readForm(HttpExchange exchange) throws IOException {
        byte[] bytes = exchange.getRequestBody().readNBytes(16_385);
        if (bytes.length > 16_384) throw new IllegalArgumentException("Request exceeds 16 KB");
        String payload = new String(bytes, StandardCharsets.UTF_8);
        Map<String, String> values = new LinkedHashMap<>();
        for (String pair : payload.split("&")) {
            String[] parts = pair.split("=", 2);
            values.put(URLDecoder.decode(parts[0], StandardCharsets.UTF_8),
                parts.length > 1 ? URLDecoder.decode(parts[1], StandardCharsets.UTF_8) : "");
        }
        return values;
    }

    private void launch(HttpExchange exchange, String requestedUrl, String requestedBrowser) throws IOException {
        String url = requestedUrl.trim();
        URI uri;
        try {
            uri = URI.create(url);
            if (!("http".equalsIgnoreCase(uri.getScheme()) || "https".equalsIgnoreCase(uri.getScheme())) ||
                uri.getHost() == null || uri.getUserInfo() != null || url.length() > 4096)
                throw new IllegalArgumentException("Enter a valid http:// or https:// application URL.");
        } catch (Exception e) {
            reply(exchange, 400, "application/json", Json.stringify(Json.map("error", "Enter a valid http:// or https:// application URL.")));
            return;
        }
        if (!List.of("auto", "chrome", "edge").contains(requestedBrowser)) {
            reply(exchange, 400, "application/json", Json.stringify(Json.map("error", "Invalid browser selection")));
            return;
        }
        BrowserRecorder previous;
        BrowserRecorder current;
        String launchedId;
        synchronized (lock) {
            if (status.equals("starting") || status.equals("recording")) {
                reply(exchange, 409, "application/json", Json.stringify(Json.map("error", "Stop the active recording before launching another.")));
                return;
            }
            previous = browserRecorder;
            actions.clear();
            sessionId = UUID.randomUUID().toString();
            launchedId = sessionId;
            appUrl = url;
            browserName = "";
            status = "starting";
            statusMessage = "Launching your installed browser and connecting the recorder…";
            startedAt = Instant.now(); stoppedAt = null;
            autosave = createAutosave(sessionId);
            current = new BrowserRecorder(script, (tab, action) -> receiveAction(launchedId, tab, action));
            browserRecorder = current;
        }
        background.execute(() -> {
            if (previous != null) previous.close();
            try {
                String detected = current.launch(url, requestedBrowser);
                synchronized (lock) {
                    if (!launchedId.equals(sessionId)) { current.close(); return; }
                    browserName = detected;
                    if (status.equals("starting")) {
                        status = "recording";
                        statusMessage = "Recording actions in " + detected + ". Switch to the application tab.";
                    }
                }
            } catch (Exception e) {
                synchronized (lock) {
                    if (launchedId.equals(sessionId) && status.equals("starting")) {
                        status = "error";
                        statusMessage = e.getMessage();
                    }
                }
                current.close();
            }
        });
        reply(exchange, 202, "application/json", Json.stringify(state()));
    }

    private static Path createAutosave(String id) throws IOException {
        Path directory = Path.of(System.getProperty("user.home"), ".eliya-ui-recorder", "sessions");
        Files.createDirectories(directory);
        try {
            Files.setPosixFilePermissions(directory, EnumSet.of(PosixFilePermission.OWNER_READ,
                PosixFilePermission.OWNER_WRITE, PosixFilePermission.OWNER_EXECUTE));
        } catch (UnsupportedOperationException ignored) { /* Windows ACL managed by OS */ }
        Path file = directory.resolve(id + ".jsonl");
        Files.createFile(file);
        try { Files.setPosixFilePermissions(file, EnumSet.of(PosixFilePermission.OWNER_READ, PosixFilePermission.OWNER_WRITE)); }
        catch (UnsupportedOperationException ignored) { }
        return file;
    }

    private void receiveAction(String id, String tab, Map<String, Object> incoming) {
        synchronized (lock) {
            if (!id.equals(sessionId) || !(status.equals("starting") || status.equals("recording")) || actions.size() >= MAX_ACTIONS) return;
            String type = Json.str(incoming.get("type"));
            if (!Set.of("navigate", "click", "doubleClick", "rightClick", "fill", "select", "check",
                "fileSelected", "keyDown", "keyUp", "submit", "scroll", "drop", "pointerdown",
                "pointerup", "pointercancel", "mousedown", "mouseup", "touchstart", "touchend",
                "touchcancel", "mouseover", "mouseout", "pointerover", "pointerout", "mousemove",
                "pointermove", "touchmove", "wheel", "auxclick", "reset", "invalid", "dragstart",
                "dragenter", "dragleave", "dragover", "dragend", "focusin", "focusout", "copy",
                "cut", "paste", "compositionstart", "compositionend", "selectionchange", "change",
                "keypress").contains(type)) return;
            String pageUrl = Json.str(incoming.get("pageUrl"));
            if (type.equals("navigate") && (pageUrl.equals("about:blank") || pageUrl.startsWith("chrome-error://"))) return;
            if (type.equals("navigate") && !actions.isEmpty()) {
                Map<String, Object> last = actions.get(actions.size() - 1);
                if ("navigate".equals(last.get("type")) && pageUrl.equals(last.get("pageUrl")) &&
                    tab.equals(last.get("tabId"))) return;
            }
            Map<String, Object> entry = new LinkedHashMap<>(incoming);
            entry.put("sequence", actions.size() + 1);
            entry.put("tabId", tab);
            entry.put("recordedAt", Instant.now().toString());
            if (Boolean.TRUE.equals(incoming.get("sensitive"))) {
                if (entry.containsKey("value")) entry.put("value", "[REDACTED]");
                if (entry.containsKey("text")) entry.put("text", "[REDACTED]");
                entry.remove("selected");
            }
            // Never persist entire page HTML, cookies, headers, or input password values.
            actions.add(entry);
            try { Files.writeString(autosave, Json.stringify(entry) + "\n", StandardCharsets.UTF_8,
                StandardOpenOption.APPEND); }
            catch (IOException e) { statusMessage = "Recording, but local autosave failed: " + e.getMessage(); }
        }
    }

    private Map<String, Object> state() {
        synchronized (lock) {
            int from = Math.max(0, actions.size() - 100);
            // Never send large DOM snapshots to the dashboard on every 900 ms poll.
            // Full-fidelity actions remain in the autosave journal and JSON export.
            List<Map<String, Object>> preview = new ArrayList<>();
            for (int i = from; i < actions.size(); i++) {
                Map<String, Object> action = actions.get(i);
                Map<String, Object> item = new LinkedHashMap<>();
                for (String key : List.of("sequence", "type", "selector", "locators", "value", "checked",
                    "files", "key", "event", "scrollX", "scrollY", "url", "pageUrl", "recordedAt")) {
                    if (action.containsKey(key)) item.put(key, action.get(key));
                }
                preview.add(item);
            }
            return Json.map("status", status, "message", statusMessage, "url", appUrl, "browser", browserName,
                "startedAt", startedAt == null ? null : startedAt.toString(),
                "stoppedAt", stoppedAt == null ? null : stoppedAt.toString(),
                "actionCount", actions.size(), "actions", preview,
                "sessionId", sessionId, "autosavePath", autosave == null ? "" : autosave.toString());
        }
    }

    private void export(HttpExchange exchange) throws IOException {
        Map<String, Object> document;
        synchronized (lock) {
            document = Json.map("schemaVersion", "1.1", "format", "eliya-ui-actions", "sessionId", sessionId,
                "captureConfig", Json.map("domMaxNodes", Integer.getInteger("recorder.domMaxNodes", 1000),
                    "domMaxDepth", Integer.getInteger("recorder.domMaxDepth", 24),
                    "domMaxSiblings", Integer.getInteger("recorder.domMaxSiblings", 40),
                    "captureMotion", Boolean.getBoolean("recorder.captureMotion")),
                "applicationUrl", appUrl, "browser", browserName,
                "recordingStartedAt", startedAt == null ? null : startedAt.toString(),
                "recordingStoppedAt", stoppedAt == null ? null : stoppedAt.toString(),
                "exportedAt", Instant.now().toString(), "actionCount", actions.size(),
                "actions", new ArrayList<>(actions));
        }
        if (Json.str(document.get("sessionId")).isBlank()) {
            reply(exchange, 409, "application/json", Json.stringify(Json.map("error", "No recording exists yet")));
            return;
        }
        String filename = "ui-actions-" + FILE_TIME.format(startedAt) + ".json";
        exchange.getResponseHeaders().set("Content-Disposition", "attachment; filename=\"" + filename + "\"");
        reply(exchange, 200, "application/json; charset=utf-8", Json.pretty(document) + "\n");
    }

    private static void methodNotAllowed(HttpExchange e) throws IOException {
        reply(e, 405, "application/json", Json.stringify(Json.map("error", "Method not allowed")));
    }

    private static void reply(HttpExchange exchange, int code, String contentType, String message) throws IOException {
        reply(exchange, code, contentType, message.getBytes(StandardCharsets.UTF_8));
    }

    private static void reply(HttpExchange exchange, int code, String contentType, byte[] bytes) throws IOException {
        exchange.getResponseHeaders().set("Content-Type", contentType);
        exchange.getResponseHeaders().set("Cache-Control", "no-store");
        exchange.getResponseHeaders().set("X-Content-Type-Options", "nosniff");
        exchange.getResponseHeaders().set("X-Frame-Options", "DENY");
        exchange.getResponseHeaders().set("Content-Security-Policy",
            "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; " +
            "connect-src 'self'; img-src 'self' data:; object-src 'none'; frame-ancestors 'none'");
        if (code == 204) { exchange.sendResponseHeaders(code, -1); return; }
        exchange.sendResponseHeaders(code, bytes.length);
        try (OutputStream out = exchange.getResponseBody()) { out.write(bytes); }
    }

    private void shutdown() {
        BrowserRecorder current;
        synchronized (lock) { current = browserRecorder; browserRecorder = null; }
        if (current != null) current.close();
        if (server != null) server.stop(0);
        background.shutdownNow();
    }
}
