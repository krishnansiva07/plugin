# Eliya UI Recorder 1.1 — Java 17 Maven source project

A standalone browser interaction recorder. Run a single Java JAR, open its local web dashboard, paste an application URL, select **Launch & Start Recording**, interact with the application in installed Chrome or Edge, then press **Stop & Export JSON**.

- **No LLM, Selenium server, ChromeDriver, Node.js, or browser download is required to run it.**
- It uses the Java 17 HTTP server and WebSocket client with Chromium DevTools Protocol (CDP).
- A dedicated temporary browser profile is used so existing browser sessions are not modified.
- Windows / macOS / Linux are supported where Chrome/Chromium or Edge is installed; browser discovery can vary with custom installations.

## Build with Maven

**Requirements:** JDK 17 or newer and Apache Maven 3.8+ (Maven may need access to your organization's approved artifact repository to download build plugins the first time).

```sh
mvn clean package
```

Run the generated JAR:

```sh
java -jar target/eliya-ui-recorder-1.1.0.jar
```

Then open the dashboard address shown in the console (normally `http://127.0.0.1:<random-port>/`). The dashboard is normally opened automatically on desktop systems.

**Alternative offline build:** `build-with-jdk.bat` (Windows) or `bash build-with-jdk.sh` (macOS/Linux). These use only `javac` and `jar` from JDK 17+, producing the same executable JAR under `target/`.

**Eclipse:** File → Import → Maven → Existing Maven Projects → choose the folder containing `pom.xml`; right-click the project → Run As → Maven build → enter `clean package`.

## Recording workflow

1. Start the JAR and open the local recorder dashboard.
2. Enter the `http://` or `https://` application URL and select Chrome, Edge, or Auto.
3. Choose **Launch & Start Recording**.
4. Perform UI actions in the launched browser window; use **Inspect** next to an event to view its full payload.
5. Choose **Stop & Export JSON**; the dashboard browser downloads the JSON file.
6. Click **Close recorder browser** when finished. Recorded data remains available to export until a new session starts or the process exits.

Each session is also journaled to `~/.eliya-ui-recorder/sessions/<session-id>.jsonl` for recovery. Those files can contain non-password application data; treat them as test artifacts with appropriate access controls.

## What changed in 1.1

The old recorder captured only a small set of actions and several locator fields. This version adds:

- Click, double-click, right-click, auxiliary click; pointer and mouse down/up; sampled hover/mouseover/out and wheel; keyboard down/up; focus in/out; copy/cut/paste without clipboard data; selection changes; drag-and-drop lifecycle; touch start/end/cancel; change, fill, select, check, submit, reset, invalid, navigation, scroll; composition start/end. Optional sampled movement events are available.
- Each recorded event includes an `event` object with event name, modifiers and available pointer/keyboard metadata, without raw clipboard content.
- Action elements include **all inspected HTML attributes** (with sensitive names/values redacted), key DOM properties (including bounding rectangle, checked/selected/disabled/visible state), and CSS/XPath/test-ID/role/label locator candidates.
- Full structured **target-element descendant tree** up to configured bounds (`dom.targetTree`), an `ancestorChain` (target to root), immediate `siblings`, and the composed event path. Each tree reports `capturedNodeCount`, `omittedNodeBranches`, `truncated`, and actual limits.
- Open shadow DOM traversal for locator and subtree capture; JavaScript is injected in the main page and discovered frame contexts. An out-of-process iframe attach path is included but requires testing against your browser policy and real app.
- **Inspect** in the dashboard opens full event JSON without transferring all DOM snapshots on every live dashboard refresh.
- Export format is `schemaVersion: "1.1"`.

### Example exported action (abbreviated)

```json
{
  "type": "click",
  "selector": "[data-qa=\"save\"]",
  "attributes": { "id": "save", "data-qa": "save", "aria-label": "Save" },
  "properties": { "disabled": false, "visible": true, "boundingBox": {"x": 80, "y": 100, "width": 92, "height": 37} },
  "event": { "name": "click", "button": 0, "isTrusted": true },
  "locators": { "css": "[data-qa=\"save\"]", "xpath": "//*[@id=\"save\"]" },
  "dom": {
    "targetTree": {
      "tag": "button",
      "attributes": { "id": "save", "data-qa": "save" },
      "children": [{ "tag": "span", "attributes": {}, "children": [] }]
    },
    "ancestorChain": [],
    "siblings": [],
    "capturedNodeCount": 2,
    "omittedNodeBranches": 0,
    "truncated": false
  }
}
```

The abbreviated sample illustrates key names and nesting, not an exact full export.

## Capture-size controls

A full DOM subtree can be very large on modern applications, so each action has explicit, configurable bounds. The defaults are 1000 descendant elements, depth 24, 40 sibling summaries, 4096 characters per attribute, and 700 characters per direct text node. The JSON records truncation rather than pretending the snapshot is complete.

To raise the DOM limit and record sampled motion events:

```sh
java -Drecorder.domMaxNodes=5000 -Drecorder.domMaxDepth=60 -Drecorder.domMaxSiblings=80 -Drecorder.captureMotion=true -jar target/eliya-ui-recorder-1.1.0.jar
```

DOM node limit is capped at 10,000 and depth at 80. Increasing limits can dramatically enlarge recordings or slow down the target page. Keypress-driven **text values** are emitted as grouped `fill` records rather than one full DOM snapshot for each character; frequent hover/wheel/scroll/move events are sampled. There is no safe way to guarantee every event emitted by any web application.

## Browser settings

Chrome discovery is automatic when installed in standard locations. To specify custom executables:

```sh
java -Drecorder.chromePath=/path/to/chrome -jar target/eliya-ui-recorder-1.1.0.jar
```

On Windows:

```bat
java "-Drecorder.edgePath=C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe" -jar target\eliya-ui-recorder-1.1.0.jar
```

For a site that should be accessed *without the system's browser proxy* (only when appropriate): add `-Drecorder.browserNoProxy=true`. Corporate Chrome/Edge device policies may override browser flags or block applications. Debug-only settings `-Drecorder.headless=true` and `-Drecorder.disableSandbox=true` are for controlled CI environments; do not disable the browser sandbox on user desktops.

## Privacy and coverage limitations

- Password-like fields, secrets indicated by attribute names, and `data-sensitive="true"`, `data-private="true"`, or `data-recorder-redact="true"` elements are masked. Clipboard contents and cookie/header data are not intentionally captured.
- **No masking approach can identify every secret in arbitrary DOM text or custom attributes.** The export still contains ordinary input values, visible text and element attributes. Use test accounts and review JSON files before sharing them externally.
- Shadow DOM is traversed for open roots; inaccessible closed-shadow internals cannot be reconstructed after creation.
- Browser-native UI (file chooser dialog controls, browser toolbars, certificate popups, permission prompts), operating-system gestures, and events blocked by browser security policy cannot be captured as page DOM events.
- Cross-origin and out-of-process iframe support is **best effort** and needs validation on the target app/browser; a frame may be inaccessible or restricted by administrator policy. The `frame` and (when known) `frameId` fields identify where an event originated.
- This is a **recording + JSON export** application. It does not replay, synthesize assertions, or generate Selenium/Playwright tests yet.

## Project structure

```text
pom.xml
src/main/java/com/eliya/recorder/RecorderApp.java
src/main/java/com/eliya/recorder/BrowserRecorder.java
src/main/java/com/eliya/recorder/Json.java
src/main/resources/index.html
src/main/resources/recorder.js
build-with-jdk.bat
build-with-jdk.sh
```

## Manual validation checklist

Record and inspect each of: clicking nested elements, typing and blurring a textbox, changing a select/checkbox, password input masking, keyboard/hover events, browser scrolling, SPA navigation, clicking inside an open shadow root, interactions inside each iframe type used by the real application, and Stop & Export JSON. Check that sensitive values are absent from the downloaded file and that `dom.truncated` is accurate for large subtrees.
