package com.llmart.llm.service;

import com.llmart.llm.dto.TestCaseGenerationResponse;
import com.llmart.llm.exception.TcgenException;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@Service
public class TestCaseGeneratorService {

    private final FileTextExtractor fileTextExtractor;
    private final PromptBuilder promptBuilder;
    private final JsonResponseParser jsonResponseParser;
    private final LlmClient llmClient;
    private final ColumnSelectionService columnSelectionService;

    public TestCaseGeneratorService(FileTextExtractor fileTextExtractor,
                                    PromptBuilder promptBuilder,
                                    JsonResponseParser jsonResponseParser,
                                    LlmClient llmClient,
                                    ColumnSelectionService columnSelectionService) {
        this.fileTextExtractor = fileTextExtractor;
        this.promptBuilder = promptBuilder;
        this.jsonResponseParser = jsonResponseParser;
        this.llmClient = llmClient;
        this.columnSelectionService = columnSelectionService;
    }

    public TestCaseGenerationResponse generate(MultipartFile file,
                                               String additionalPrompt,
                                               String apiKey,
                                               String modelName,
                                               String baseUrl,
                                               String selectedColumnsCsv) {
        List<String> selectedColumns = columnSelectionService.resolveColumns(selectedColumnsCsv);
        String acceptanceCriteriaText = fileTextExtractor.extract(file);
        String prompt = promptBuilder.buildPrompt(acceptanceCriteriaText, additionalPrompt, selectedColumns);

        try {
            String llmResponse = llmClient.generate(prompt, apiKey, modelName, baseUrl);
            TestCaseGenerationResponse response = jsonResponseParser.parse(llmResponse, selectedColumns);
            response.setSourceFileName(file.getOriginalFilename());
            return response;
        } catch (TcgenException ex) {
            throw ex;
        } catch (Exception ex) {
            throw new TcgenException("Failed to generate test cases from LLM.", ex);
        }
    }
}
