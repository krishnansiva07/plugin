# TCGen Service - Dynamic Excel Column Test Case Generator

TCGen generates test cases from Acceptance Criteria documents. The UI lets the user upload an AC file, enter their LLM token, optionally override model/base URL, select required Excel columns, add custom columns, preview the dynamic prompt, generate test cases, and export the result to Excel.

## Main Features

- Upload AC file from UI using **Browse AC File** button.
- Supports text-based files: TXT, PDF, DOCX, XLSX, CSV, JSON, XML, HTML, MD.
- API key/user token field in UI.
- Model name field in UI.
- Base URL field in UI.
- If UI token/model/base URL is empty, backend falls back to `LLM_API_KEY`, `LLM_MODEL_NAME`, and `LLM_BASE_URL`.
- LangChain4j `OpenAiChatModel` configuration, matching the working setup.
- Dynamic column selection from UI.
- Custom column add option.
- Template buttons: Manual TC, API TC, BDD TC, Regression TC.
- Dynamic prompt preview based on selected columns.
- LLM prompt uses only selected columns.
- Excel export uses only selected columns plus auto-generated `S.No`.
- Follow-up questions and assumptions are generated when AC is incomplete.
- No hardcoded API key.

## LLM Configuration Used

This version uses LangChain4j directly:

```java
return OpenAiChatModel.builder()
        .apiKey(apiKey)
        .modelName(modelName)
        .baseUrl(baseUrl)
        .temperature(0.7)
        .maxTokens(512)
        .build();
```

The base URL should be the OpenAI-compatible base URL, for example:

```properties
llm.base-url=https://ai4devs.group.echonet/api/v1
```

Do not enter `/chat/completions` in the base URL. LangChain4j handles the chat completion endpoint internally.

## Project Structure

```text
tcgen-service-dynamic-columns
├── pom.xml
├── README.md
├── samples
│   └── place_order_acceptance_criteria_sample.xlsx
└── src
    └── main
        ├── java/com/llmart/llm
        │   ├── LlmApplication.java
        │   ├── config/ChatConfig.java
        │   ├── controller/TestCaseController.java
        │   ├── dto/TestCaseGenerationResponse.java
        │   ├── exception
        │   └── service
        └── resources
            ├── application.properties
            └── static/index.html
```

## Run Locally

```bash
mvn clean package
```

```bash
java -jar target/tcgen-service-0.0.3-SNAPSHOT.jar \
  --llm.api-key=your-key \
  --llm.model-name=gpt-oss-120b \
  --llm.base-url=https://ai4devs.group.echonet/api/v1
```

Open:

```text
http://localhost:8090
```

## Environment Variable Run

```bash
export LLM_API_KEY="your-key"
export LLM_MODEL_NAME="gpt-oss-120b"
export LLM_BASE_URL="https://ai4devs.group.echonet/api/v1"
java -jar target/tcgen-service-0.0.3-SNAPSHOT.jar
```

For Windows PowerShell:

```powershell
$env:LLM_API_KEY="your-key"
$env:LLM_MODEL_NAME="gpt-oss-120b"
$env:LLM_BASE_URL="https://ai4devs.group.echonet/api/v1"
java -jar target/tcgen-service-0.0.3-SNAPSHOT.jar
```

## Curl Example

```bash
curl -X POST http://localhost:8090/api/testcases/generate \
  -F "file=@samples/place_order_acceptance_criteria_sample.xlsx" \
  -F "apiKey=your-user-token" \
  -F "modelName=gpt-oss-120b" \
  -F "baseUrl=https://ai4devs.group.echonet/api/v1" \
  -F "selectedColumns=Test ID,Module,Requirement ID,Scenario,Precondition,Test Steps,Test Data,Expected Result,Priority,Test Type,Automation Candidate" \
  -F "additionalPrompt=Generate positive, negative, boundary, UI, API, DB, smoke and regression cases"
```

## API Endpoints

### Health

```text
GET /api/testcases/health
```

### Default Columns

```text
GET /api/testcases/columns/defaults
```

### Generate Test Cases

```text
POST /api/testcases/generate
Content-Type: multipart/form-data
```

Form fields:

| Field | Required | Description |
|---|---:|---|
| file | Yes | AC file |
| apiKey | No | User token/API key. Falls back to configured key. |
| modelName | No | Model name. Falls back to configured model. |
| baseUrl | No | OpenAI-compatible base URL. Falls back to configured URL. |
| selectedColumns | No | Comma separated selected columns. Defaults to manual TC columns. |
| additionalPrompt | No | Additional user instruction |

### Export Excel

```text
POST /api/testcases/export
Content-Type: application/json
```

Body: response JSON from `/generate`.

## Important Security Notes

- Do not hardcode real keys in `application.properties`.
- Do not commit API keys to Git.
- Do not share screenshots containing live tokens.
- If a token was exposed in screenshot/logs, rotate it immediately.
- UI token is sent only for the current request and is not exported to Excel.
