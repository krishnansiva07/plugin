# Test Selection and Execution

The framework filters JSON records before Playwright registers tests. The test ID does not need to be hard-coded in `test.describe`; it comes from the JSON row and is used in the generated title: `[TC_ORDER_001] Place order...`.

## Commands

```powershell
# All enabled JSON records
npm test

# One test
npm test -- --testId=TC_ORDER_001
npm test -- --testId TC_ORDER_001

# Multiple tests
npm test -- --testIds=TC_LOGIN_001,TC_ORDER_001

# A suite
npm test -- --suite=order

# A tag
npm test -- --tag=smoke

# A priority
npm test -- --priority=P1

# Select browser without changing .env
npm test -- --browser=edge

# Combine filters and list without execution
npm test -- --suite=order --priority=P1 --list
```

Custom arguments are consumed by `scripts/run-with-cacert.ts`, converted into environment variables, and removed before Playwright starts. Therefore Playwright never receives unknown options such as `--testId`.

## Add a new test

1. Add a JSON row with a unique `testId`.
2. Create or reuse a spec that loads the file using `TestDataService.load()`.
3. Generate the Playwright title with `${row.testId}` and `${row.testName}`.
4. Keep the business flow in the spec and element handling in page objects using `SmartActions`.
