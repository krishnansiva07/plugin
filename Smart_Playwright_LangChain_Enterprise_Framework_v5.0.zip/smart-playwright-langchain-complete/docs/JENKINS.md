# Jenkins Execution

## Requirements

- Windows agent running in an interactive logged-in desktop session for visible headed execution
- Node.js 20/22 LTS
- Installed Chrome/Edge or approved Chromium
- PEM CA bundle available in `certificates`
- LLM token stored as a Jenkins secret

## Pipeline flow

```text
Checkout → npm ci → typecheck → npm test → publish JUnit → archive reports
```

The included `Jenkinsfile` runs `npm test`, which configures the CA bundle before starting Playwright.

## Artifacts

Archive:

```text
reports/**
playwright-report/**
test-results/**
healing-data/**
```

Publish:

```text
test-results/junit.xml
```

Do not run a separate browser preflight before `npm test`; that is unnecessary.
