# Configuration and Usage

## Prerequisites

- Windows with installed Google Chrome, Microsoft Edge, or approved Chromium
- Node.js 20/22 LTS
- npm
- Corporate PEM CA bundle when the LLM endpoint uses an internal certificate
- Access to the OpenAI-compatible corporate LLM endpoint

Python, Selenium WebDriver, ChromeDriver and EdgeDriver are not required.

## Installation

```powershell
npm ci
Copy-Item .env.example .env
```

## Certificate

Preferred file:

```text
certificates\generated-ca-bundle.pem
```

The runner also checks `corporate-ca.pem`, `cacert.pem`, `cacert`, and `cacerts`, but the content must be PEM text containing `-----BEGIN CERTIFICATE-----`.

`npm test` starts a child Node process with `NODE_EXTRA_CA_CERTS` already configured.

## Browser settings

```env
BROWSER=auto
BROWSER_PRIORITY=chrome,edge
```

Values:

| Value | Behaviour |
|---|---|
| `auto` | Selects the first installed browser in `BROWSER_PRIORITY` |
| `chrome` | Requires installed Chrome |
| `edge` | Requires installed Edge |
| `custom` | Uses `BROWSER_EXECUTABLE_PATH` |

Custom Chromium:

```env
BROWSER=custom
BROWSER_EXECUTABLE_PATH=C:\Tools\Chromium\chrome.exe
```

Execution is always headed/UI. Browser detection checks files and registry entries only and does not execute browser binaries.

## LLM settings

The mapping matches the Java setup:

| Java setting | TypeScript setting |
|---|---|
| `apiKey` | `LLM_API_KEY` |
| `baseUrl` | `LLM_BASE_URL` |
| `modelName` | `LLM_MODEL_NAME` |

```env
LLM_ENABLED=true
LLM_API_KEY=token
LLM_BASE_URL=https://corporate-llm.example/v1
LLM_MODEL_NAME=model-name
LLM_TEMPERATURE=0
LLM_MAX_TOKENS=500
LLM_TIMEOUT_MS=30000
LLM_MAX_RETRIES=1
```

The base URL must be the OpenAI-compatible API root, not the full `/chat/completions` URL.

## Healing modes

```env
HEALING_MODE=persist
USE_SAVED_HEALED_LOCATORS=true
SAVE_HEALED_LOCATORS=true
LLM_MIN_CONFIDENCE=0.85
```

| Mode | Behaviour |
|---|---|
| `runtime` | Uses the validated LLM locator only for the current run |
| `persist` | Uses it and stores it in `healing-data/healed-locators.json` |
| `suggest` | Records the suggestion but deliberately fails without executing it |

List persisted locators:

```powershell
npm run healing:list
```

Clear persisted locators:

```powershell
npm run healing:clear
```

## Test data

Edit:

```text
test-data\login-tests.json
```

Each enabled object creates one Playwright test. Set `"run": false` to exclude a case.

## Commands

```powershell
npm test
npm run test:debug
npm run typecheck
npm run report:open
npm run report:playwright
npm run healing:list
npm run healing:clear
```

Playwright CLI arguments can be forwarded:

```powershell
npm test -- --grep "valid credentials"
npm test -- tests/login.spec.ts
```

## Output

```text
reports/index.html
reports/test-results.json
playwright-report/index.html
test-results/junit.xml
test-results/artifacts/
healing-data/healed-locators.json
```
