# Framework Architecture

## Component architecture

```mermaid
flowchart TB
    JSON[Test data JSON] --> TEST[Playwright test]
    TEST --> POM[Page Objects]
    POM --> ACTION[SmartActions]
    ACTION --> SAVED[Saved locator repository]
    ACTION --> PRIMARY[Primary Playwright locator]
    ACTION --> FALLBACK[Deterministic fallbacks]
    ACTION --> LLM[LangChain ChatOpenAI]
    LLM --> VALIDATE[Unique and visible validation]
    VALIDATE --> PERSIST[Optional persistence]
    ACTION --> PW[Playwright browser action]
    PW --> APP[Application under test]
    TEST --> CUSTOM[Custom HTML reporter]
    TEST --> DEFAULT[Default Playwright HTML reporter]
    TEST --> JUNIT[JUnit XML]
```

## Project structure

```text
src/core/browser       Installed browser discovery
src/core/actions       Smart UI actions
src/core/healing       Persisted locator repository
src/llm                LangChain/OpenAI-compatible client
src/pages              Page Object Model
src/reporting          Colourful management report
src/utils              Environment and JSON utilities
tests                  Playwright specifications
test-data              Input JSON
healing-data           Persisted validated locators
certificates           Corporate PEM CA bundle
reports                Consolidated report
playwright-report       Default Playwright report
test-results            JUnit, screenshots and traces
```

## Design principles

- Tests describe business flows.
- Page objects own page-specific behaviour.
- SmartActions centralises locator recovery.
- LLM is called only after deterministic strategies fail.
- An LLM selector is never executed until it resolves to exactly one visible element.
- Source files are not automatically rewritten.
- Persisted locators are external, reviewable and removable.
- Browser discovery never launches a browser.
- Playwright owns the single real browser launch.
- Reporting is independent of ExcelJS/JSZip.
