# V5 Architecture

```text
npm test + optional filters
  -> certificate-aware runner
  -> custom arguments mapped to environment variables
  -> Playwright configuration and installed-browser resolver
  -> spec discovery
  -> TestDataService reads and filters JSON
  -> only selected tests are registered
  -> Page Objects execute business flows
  -> SmartActions: saved locator -> primary -> fallback -> LangChain LLM
  -> validated locator optionally persisted
  -> assertions
  -> custom HTML + Playwright HTML + JUnit XML
```

## Responsibilities

- `scripts/run-with-cacert.ts`: certificate setup and CLI option parsing.
- `src/core/execution/TestDataService.ts`: centralized JSON filtering.
- `src/core/execution/ExecutionFilters.ts`: reads normalized execution filters.
- `src/utils/JsonData.ts`: pure JSON read/write only.
- `tests/*.spec.ts`: business workflows and dynamic test registration.
- `src/pages/*.ts`: Page Object Model and smart element definitions.
- `src/core/actions/SmartActions.ts`: locator resolution and healing.
- `src/core/healing/HealingRepository.ts`: saved working locators.
- `src/reporting/SmartHtmlReporter.ts`: consolidated management report.
