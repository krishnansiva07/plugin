# Execution Flow: Browser Launch to Reports

```mermaid
sequenceDiagram
    participant U as User/Jenkins
    participant R as Certificate Runner
    participant C as Playwright Config
    participant B as Browser Resolver
    participant T as Playwright Test
    participant P as Page Object
    participant S as SmartActions
    participant L as LangChain LLM
    participant A as Application
    participant RP as Reporters

    U->>R: npm test
    R->>R: Locate PEM CA bundle
    R->>T: Start one child Node/Playwright process
    T->>C: Load configuration
    C->>B: Resolve installed browser path
    B-->>C: Chrome/Edge/custom executable path
    Note over B: File/registry checks only; no browser launch
    T->>A: Playwright launches one headed browser
    T->>P: Execute JSON-driven test
    P->>S: fill/click smart element
    S->>S: Try saved locator
    S->>S: Try primary locator
    S->>S: Try deterministic fallbacks
    alt all deterministic locators fail
        S->>L: Send sanitised relevant DOM and context
        L-->>S: CSS selector, confidence, reason
        S->>S: Validate one visible match
        opt HEALING_MODE=persist
            S->>S: Save selector repository
        end
    end
    S->>A: Perform browser action
    T->>RP: Test result, annotations, attachments
    RP->>RP: Generate custom HTML
    RP->>RP: Generate Playwright HTML
    RP->>RP: Generate JUnit XML
```

## Why multiple browser windows are no longer opened

The resolver does not run `chrome.exe --version`, `msedge.exe --version`, `chromium.launch()`, or any browser validation during preflight. It only checks executable files and registry locations. The real browser is started once by Playwright Test.
