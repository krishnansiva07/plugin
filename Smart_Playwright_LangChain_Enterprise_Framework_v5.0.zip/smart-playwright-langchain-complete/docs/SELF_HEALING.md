# Self-Healing Architecture

## Resolution order

```mermaid
flowchart TD
    START[Smart action] --> USE{Use saved locators?}
    USE -->|Yes| SAVED[Try saved locator]
    SAVED -->|Valid| EXEC[Execute and report SAVED]
    SAVED -->|Invalid| REMOVE[Remove stale saved locator]
    USE -->|No| PRIMARY
    REMOVE --> PRIMARY[Try primary locator]
    PRIMARY -->|Valid| EXECNORMAL[Execute normally]
    PRIMARY -->|Invalid| FALLBACK[Try deterministic fallbacks]
    FALLBACK -->|Valid| EXECDET[Execute and report DETERMINISTIC]
    FALLBACK -->|Invalid| ENABLED{LLM enabled?}
    ENABLED -->|No| FAIL[Fail test]
    ENABLED -->|Yes| CALL[LangChain ChatOpenAI request]
    CALL --> CONF{Confidence threshold met?}
    CONF -->|No| FAIL
    CONF -->|Yes| UNIQUE{Exactly one visible element?}
    UNIQUE -->|No| FAIL
    UNIQUE -->|Yes| MODE{Healing mode}
    MODE -->|runtime| EXECLLM[Execute for current run]
    MODE -->|persist| SAVE[Save repository and execute]
    MODE -->|suggest| REPORTONLY[Report suggestion and fail]
```

## Persistence

Validated LLM selectors are stored in:

```text
healing-data/healed-locators.json
```

Example:

```json
{
  "version": 1,
  "locators": {
    "SauceDemo.LoginPage.usernameInput": {
      "key": "SauceDemo.LoginPage.usernameInput",
      "selector": "input[data-test='username']",
      "confidence": 0.97,
      "reason": "Unique stable data-test attribute",
      "source": "LLM",
      "createdAt": "2026-07-14T10:30:00.000Z",
      "lastValidatedAt": "2026-07-14T10:35:00.000Z",
      "validatedCount": 2
    }
  }
}
```

The repository does not modify TypeScript source code. Review a saved selector and manually promote it into the page object when appropriate.

## Report status

A passing test that uses deterministic, LLM, or saved recovery is shown as:

```text
PASSED – HEALED
```

The healing table shows source, original locator, working locator, confidence and persistence status.

## Testing healing

Break the primary and fallback locators for one element, enable:

```env
LLM_ENABLED=true
HEALING_MODE=persist
```

Run once. The report should show `LLM` and `Persisted: Yes`. Run again. It should show `SAVED`, proving the persisted working locator was reused without another LLM call.
