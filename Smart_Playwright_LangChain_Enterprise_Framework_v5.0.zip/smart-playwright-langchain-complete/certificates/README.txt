Place the corporate CA certificate bundle in this folder using one of these names:

  cacert
  cacert.pem
  cacerts
  corporate-ca.pem
  corporate-ca.crt
  corporate-ca.cer

The file must be PEM text and contain one or more blocks like:
-----BEGIN CERTIFICATE-----
...
-----END CERTIFICATE-----

The framework automatically sets NODE_EXTRA_CA_CERTS before Playwright starts.
For the first npm install, run:  powershell -ExecutionPolicy Bypass -File scripts/setup.ps1
