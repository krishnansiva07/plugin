import { ChatOpenAI } from '@langchain/openai';
import { HumanMessage, SystemMessage } from '@langchain/core/messages';
import { env, envBoolean, envNumber } from '../utils/Environment';

export interface HealingRequest {
  elementDescription: string;
  failedLocator: string;
  action: string;
  error: string;
  pageTitle: string;
  pageUrl: string;
  relevantDom: string;
}
export interface HealingSuggestion { selector: string; confidence: number; reason: string; }

export class LlmClient {
  readonly enabled = envBoolean('LLM_ENABLED', false);
  private readonly model: ChatOpenAI | null;

  constructor() {
    if (!this.enabled) { this.model = null; return; }
    const apiKey = this.requireValue('LLM_API_KEY');
    const baseURL = this.requireValue('LLM_BASE_URL').replace(/\/+$/, '');
    const modelName = this.requireValue('LLM_MODEL_NAME');
    this.model = new ChatOpenAI({
      apiKey,
      model: modelName,
      temperature: envNumber('LLM_TEMPERATURE', 0),
      maxTokens: envNumber('LLM_MAX_TOKENS', 500),
      timeout: envNumber('LLM_TIMEOUT_MS', 30000),
      maxRetries: envNumber('LLM_MAX_RETRIES', 1),
      configuration: { baseURL }
    });
  }

  async suggestLocator(request: HealingRequest): Promise<HealingSuggestion | null> {
    if (!this.enabled || !this.model) return null;
    const system = `You are a Playwright locator-healing engine. Return strict JSON only: {"selector":"...","confidence":0.0,"reason":"..."}. Return one safe CSS selector. Prefer id, name, data-test, aria-label or stable attributes. Never return XPath, JavaScript, markdown, or explanation outside JSON.`;
    console.log(`[LLM HEALING] Calling LangChain for: ${request.elementDescription}`);
    try {
      const response = await this.model.invoke([
        new SystemMessage(system),
        new HumanMessage(JSON.stringify(request))
      ]);
      const raw = this.text(response.content).replace(/^```json\s*/i, '').replace(/^```\s*/i, '').replace(/\s*```$/i, '').trim();
      const parsed = JSON.parse(raw) as Partial<HealingSuggestion>;
      if (!parsed.selector || typeof parsed.confidence !== 'number' || !parsed.reason) {
        throw new Error(`Unexpected LLM response: ${raw}`);
      }
      if (parsed.confidence < 0 || parsed.confidence > 1) throw new Error(`Invalid confidence: ${parsed.confidence}`);
      return { selector: parsed.selector.trim(), confidence: parsed.confidence, reason: parsed.reason.trim() };
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error);
      console.error(`[LLM HEALING] Request failed: ${message}`);
      throw new Error(`LangChain LLM request failed: ${message}`, { cause: error });
    }
  }

  private text(content: unknown): string {
    if (typeof content === 'string') return content;
    if (Array.isArray(content)) return content.map(item => typeof item === 'object' && item && 'text' in item ? String(item.text) : '').join('');
    return '';
  }
  private requireValue(name: string): string {
    const value = env(name);
    if (!value) throw new Error(`${name} must be supplied and non-blank`);
    return value;
  }
}
