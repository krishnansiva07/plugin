import fs from 'node:fs';
import path from 'node:path';

/** Pure JSON utility. Test filtering belongs to TestDataService. */
export function readJsonFile<T>(filePath: string): T {
  const resolved = path.resolve(filePath);
  if (!fs.existsSync(resolved)) throw new Error(`JSON file not found: ${resolved}`);
  try {
    return JSON.parse(fs.readFileSync(resolved, 'utf8')) as T;
  } catch (error) {
    throw new Error(`Unable to parse JSON file ${resolved}: ${(error as Error).message}`);
  }
}

export function writeJsonFile(filePath: string, value: unknown): void {
  const resolved = path.resolve(filePath);
  fs.mkdirSync(path.dirname(resolved), { recursive: true });
  fs.writeFileSync(resolved, JSON.stringify(value, null, 2), 'utf8');
}
