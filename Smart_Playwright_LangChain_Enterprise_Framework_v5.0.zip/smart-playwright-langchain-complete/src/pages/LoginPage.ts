import { expect, type Page } from '@playwright/test';
import { SmartActions, type SmartElement } from '../core/actions/SmartActions';

export class LoginPage {
  private readonly actions: SmartActions;

  private readonly username: SmartElement;
  private readonly password: SmartElement;
  private readonly loginButton: SmartElement;

  constructor(private readonly page: Page) {
    this.actions = new SmartActions(page);
    this.username = {
      key: 'SauceDemo.LoginPage.usernameInput',
      description: 'SauceDemo username input',
      primary: () => page.getByTestId('username'),
      fallbacks: [() => page.getByPlaceholder(/username/i), () => page.locator('input[name="user-name"]')]
    };
    this.password = {
      key: 'SauceDemo.LoginPage.passwordInput',
      description: 'SauceDemo password input',
      primary: () => page.getByTestId('password'),
      fallbacks: [() => page.getByPlaceholder(/password/i), () => page.locator('input[name="password"]')]
    };
    this.loginButton = {
      key: 'SauceDemo.LoginPage.loginButton',
      description: 'SauceDemo login button',
      primary: () => page.getByTestId('login-button'),
      fallbacks: [() => page.getByRole('button', { name: /login/i }), () => page.locator('input[type="submit"]')]
    };
  }

  async open(): Promise<void> {
    await this.page.goto('/');
    await expect(this.page).toHaveTitle(/Swag Labs/i);
  }

  async login(username: string, password: string): Promise<void> {
    await this.actions.fill(this.username, username);
    await this.actions.fill(this.password, password);
    await this.actions.click(this.loginButton);
  }

  async verifyProductsPage(expectedText: string): Promise<void> {
    await expect(this.page.getByTestId('title')).toContainText(expectedText);
    await expect(this.page).toHaveURL(/inventory\.html/);
  }

  async verifyError(expectedText: string): Promise<void> {
    await expect(this.page.getByTestId('error')).toContainText(expectedText, { ignoreCase: true });
  }
}
