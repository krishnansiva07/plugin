import { expect, type Page } from '@playwright/test';
import { SmartActions, type SmartElement } from '../core/actions/SmartActions';
export class CheckoutPage {
  private readonly actions: SmartActions;
  constructor(private readonly page: Page){ this.actions=new SmartActions(page); }
  private input(key:string, description:string, testId:string, name:string):SmartElement{return{
    key,description,primary:()=>this.page.getByTestId(testId),
    fallbacks:[()=>this.page.locator(`input[name="${name}"]`),()=>this.page.getByPlaceholder(new RegExp(description,'i'))]
  };}
  private readonly first=this.input('SauceDemo.Checkout.firstName','first name','firstName','firstName');
  private readonly last=this.input('SauceDemo.Checkout.lastName','last name','lastName','lastName');
  private readonly postal=this.input('SauceDemo.Checkout.postalCode','postal code','postalCode','postalCode');
  private readonly continueButton:SmartElement={key:'SauceDemo.Checkout.continue',description:'Continue button',primary:()=>this.page.getByTestId('continue'),fallbacks:[()=>this.page.getByRole('button',{name:/continue/i}),()=>this.page.locator('input[type="submit"]')]};
  private readonly finishButton:SmartElement={key:'SauceDemo.Checkout.finish',description:'Finish button',primary:()=>this.page.getByTestId('finish'),fallbacks:[()=>this.page.getByRole('button',{name:/finish/i}),()=>this.page.locator('#finish')]};
  async enterDetails(first:string,last:string,postal:string):Promise<void>{await this.actions.fill(this.first,first);await this.actions.fill(this.last,last);await this.actions.fill(this.postal,postal);}
  async continue():Promise<void>{await this.actions.click(this.continueButton);}
  async verifyOverview(product:string):Promise<void>{await expect(this.page.getByText(product,{exact:true})).toBeVisible();}
  async finish():Promise<void>{await this.actions.click(this.finishButton);}
  async verifyConfirmation(message:string):Promise<void>{await expect(this.page.getByTestId('complete-header')).toHaveText(message);}
}
