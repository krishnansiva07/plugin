import { expect, type Page } from '@playwright/test';
import { SmartActions, type SmartElement } from '../core/actions/SmartActions';

const slug = (v:string) => v.toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'');

export class InventoryPage {
  private readonly actions: SmartActions;
  constructor(private readonly page: Page) { this.actions = new SmartActions(page); }

  private addButton(productName: string): SmartElement {
    const id = slug(productName);
    return {
      key: `SauceDemo.InventoryPage.addToCart.${id}`,
      description: `Add to cart button for ${productName}`,
      primary: () => this.page.getByTestId(`add-to-cart-${id}`),
      fallbacks: [
        () => this.page.locator('.inventory_item').filter({ hasText: productName }).getByRole('button', { name: /add to cart/i }),
        () => this.page.locator('[data-test="inventory-item"]').filter({ hasText: productName }).locator('button')
      ]
    };
  }

  private readonly cart: SmartElement = {
    key: 'SauceDemo.InventoryPage.cartLink', description: 'Shopping cart link',
    primary: () => this.page.getByTestId('shopping-cart-link'),
    fallbacks: [() => this.page.locator('.shopping_cart_link')]
  };

  async verifyLoaded(): Promise<void> { await expect(this.page).toHaveURL(/inventory\.html/); }
  async addProduct(productName: string): Promise<void> { await this.actions.click(this.addButton(productName)); }
  async openCart(): Promise<void> { await this.actions.click(this.cart); }
}
