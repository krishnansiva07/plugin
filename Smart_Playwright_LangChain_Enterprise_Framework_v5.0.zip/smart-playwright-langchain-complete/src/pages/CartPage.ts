import { expect, type Page } from '@playwright/test';
import { SmartActions, type SmartElement } from '../core/actions/SmartActions';
export class CartPage {
  private readonly actions: SmartActions;
  constructor(private readonly page: Page) { this.actions = new SmartActions(page); }
  private readonly checkout: SmartElement = {
    key:'SauceDemo.CartPage.checkoutButton', description:'Checkout button',
    primary:()=>this.page.getByTestId('checkout'),
    fallbacks:[()=>this.page.getByRole('button',{name:/checkout/i}),()=>this.page.locator('#checkout')]
  };
  async verifyProduct(productName:string):Promise<void>{ await expect(this.page.getByText(productName,{exact:true})).toBeVisible(); }
  async checkoutOrder():Promise<void>{ await this.actions.click(this.checkout); }
}
