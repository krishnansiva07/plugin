import fs from 'node:fs';
import path from 'node:path';

export type HealingSource = 'LLM' | 'SAVED' | 'DETERMINISTIC';

export interface SavedLocator {
  key: string;
  selector: string;
  confidence: number;
  reason: string;
  source: 'LLM';
  createdAt: string;
  lastValidatedAt: string;
  validatedCount: number;
}

interface RepositoryFile {
  version: 1;
  locators: Record<string, SavedLocator>;
}

const repositoryPath = path.resolve('healing-data', 'healed-locators.json');

function emptyRepository(): RepositoryFile {
  return { version: 1, locators: {} };
}

function readRepository(): RepositoryFile {
  if (!fs.existsSync(repositoryPath)) return emptyRepository();
  try {
    const parsed = JSON.parse(fs.readFileSync(repositoryPath, 'utf8')) as RepositoryFile;
    return parsed?.version === 1 && parsed.locators ? parsed : emptyRepository();
  } catch {
    return emptyRepository();
  }
}

function writeRepository(repository: RepositoryFile): void {
  fs.mkdirSync(path.dirname(repositoryPath), { recursive: true });
  const temporary = `${repositoryPath}.tmp`;
  fs.writeFileSync(temporary, JSON.stringify(repository, null, 2), 'utf8');
  fs.renameSync(temporary, repositoryPath);
}

export class HealingRepository {
  get(key: string): SavedLocator | undefined {
    return readRepository().locators[key];
  }

  save(input: Omit<SavedLocator, 'createdAt' | 'lastValidatedAt' | 'validatedCount' | 'source'>): SavedLocator {
    const repository = readRepository();
    const now = new Date().toISOString();
    const existing = repository.locators[input.key];
    const saved: SavedLocator = {
      ...input,
      source: 'LLM',
      createdAt: existing?.createdAt ?? now,
      lastValidatedAt: now,
      validatedCount: (existing?.validatedCount ?? 0) + 1
    };
    repository.locators[input.key] = saved;
    writeRepository(repository);
    return saved;
  }

  markValidated(key: string): void {
    const repository = readRepository();
    const existing = repository.locators[key];
    if (!existing) return;
    existing.lastValidatedAt = new Date().toISOString();
    existing.validatedCount += 1;
    writeRepository(repository);
  }

  remove(key: string): void {
    const repository = readRepository();
    delete repository.locators[key];
    writeRepository(repository);
  }

  static path(): string {
    return repositoryPath;
  }
}
