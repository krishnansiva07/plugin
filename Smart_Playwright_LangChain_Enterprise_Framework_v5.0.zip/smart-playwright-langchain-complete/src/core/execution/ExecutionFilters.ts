export interface ExecutionFilters {
  testIds: string[];
  suite?: string;
  tags: string[];
  priority?: string;
}

const csv = (value?: string): string[] =>
  (value ?? '').split(',').map(v => v.trim()).filter(Boolean);

export function getExecutionFilters(): ExecutionFilters {
  return {
    testIds: csv(process.env.TEST_IDS ?? process.env.TEST_ID),
    suite: process.env.TEST_SUITE?.trim() || undefined,
    tags: csv(process.env.TEST_TAGS),
    priority: process.env.TEST_PRIORITY?.trim() || undefined
  };
}
