import fs from 'node:fs';
import path from 'node:path';
import { getExecutionFilters } from './ExecutionFilters';

export interface BaseTestData {
  run?: boolean;
  testId: string;
  testName: string;
  suite?: string;
  priority?: string;
  tags?: string[];
}

export class TestDataService {
  static load<T extends BaseTestData>(filePath: string, defaultSuite?: string): T[] {
    const resolved = path.resolve(filePath);
    if (!fs.existsSync(resolved)) {
      throw new Error(`JSON test-data file not found: ${resolved}`);
    }

    let parsed: unknown;
    try {
      parsed = JSON.parse(fs.readFileSync(resolved, 'utf8'));
    } catch (error) {
      throw new Error(`Unable to parse JSON file ${resolved}: ${(error as Error).message}`);
    }

    if (!Array.isArray(parsed)) {
      throw new Error(`JSON test-data must contain an array: ${resolved}`);
    }

    const filters = getExecutionFilters();
    const rows = parsed as T[];

    const selected = rows.filter(row => {
      if (row.run === false) return false;
      if (filters.testIds.length && !filters.testIds.includes(row.testId)) return false;

      const rowSuite = row.suite ?? defaultSuite;
      if (filters.suite && rowSuite?.toLowerCase() !== filters.suite.toLowerCase()) return false;

      if (filters.priority && row.priority?.toLowerCase() !== filters.priority.toLowerCase()) return false;

      if (filters.tags.length) {
        const rowTags = (row.tags ?? []).map(tag => tag.toLowerCase());
        if (!filters.tags.every(tag => rowTags.includes(tag.toLowerCase()))) return false;
      }
      return true;
    });

    console.log(`[TEST DATA] ${path.basename(filePath)}: ${selected.length}/${rows.length} selected`);
    return selected;
  }
}
