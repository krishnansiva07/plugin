# Smart Playwright LangChain Enterprise Framework v5

Playwright TypeScript framework with installed Chrome/Edge, headed execution, central JSON-driven test selection, Page Object Model, LangChain LLM self-healing, locator persistence, corporate CA support, custom HTML reporting, Playwright HTML reporting and JUnit output.

## Setup

```powershell
npm ci
Copy-Item .env.example .env
```

Place the corporate PEM bundle at:

```text
certificates/generated-ca-bundle.pem
```

Configure `.env`, then run:

```powershell
npm test
```

## Select tests

```powershell
npm test -- --testId=TC_ORDER_001
npm test -- --testIds=TC_LOGIN_001,TC_ORDER_001
npm test -- --suite=order
npm test -- --tag=smoke
npm test -- --priority=P1
npm test -- --suite=order --priority=P1 --list
```

## Reports

- Custom report: `reports/index.html`
- Default Playwright report: `playwright-report/index.html`
- JUnit: `test-results/junit.xml`

Open the Playwright report:

```powershell
npm run report:playwright
```

See `docs/TEST_SELECTION.md` and `docs/V5_ARCHITECTURE.md`.
