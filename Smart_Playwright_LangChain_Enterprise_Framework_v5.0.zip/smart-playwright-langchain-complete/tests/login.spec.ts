import { test } from '@playwright/test';
import { LoginPage } from '../src/pages/LoginPage';
import { TestDataService, type BaseTestData } from '../src/core/execution/TestDataService';
interface LoginTestData extends BaseTestData { username:string;password:string;expectedType:'products'|'error';expectedValue:string; }
const testData=TestDataService.load<LoginTestData>('test-data/login-tests.json','login');
test.describe('SauceDemo Login',()=>{for(const row of testData){test(`[${row.testId}] ${row.testName}`,async({page},testInfo)=>{testInfo.annotations.push({type:'testId',description:row.testId});const p=new LoginPage(page);await p.open();await p.login(row.username,row.password);if(row.expectedType==='products')await p.verifyProductsPage(row.expectedValue);else await p.verifyError(row.expectedValue);});}});
