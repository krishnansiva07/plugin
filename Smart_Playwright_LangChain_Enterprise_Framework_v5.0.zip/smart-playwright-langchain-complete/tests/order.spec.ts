import { test } from '@playwright/test';
import { TestDataService, type BaseTestData } from '../src/core/execution/TestDataService';
import { LoginPage } from '../src/pages/LoginPage';
import { InventoryPage } from '../src/pages/InventoryPage';
import { CartPage } from '../src/pages/CartPage';
import { CheckoutPage } from '../src/pages/CheckoutPage';
interface OrderTestData extends BaseTestData {username:string;password:string;productName:string;firstName:string;lastName:string;postalCode:string;expectedResult:string;}
const data=TestDataService.load<OrderTestData>('test-data/order.json','order');
test.describe('SauceDemo Order',()=>{for(const row of data){test(`[${row.testId}] ${row.testName}`,async({page},testInfo)=>{testInfo.annotations.push({type:'testId',description:row.testId});const login=new LoginPage(page),inventory=new InventoryPage(page),cart=new CartPage(page),checkout=new CheckoutPage(page);await login.open();await login.login(row.username,row.password);await inventory.verifyLoaded();await inventory.addProduct(row.productName);await inventory.openCart();await cart.verifyProduct(row.productName);await cart.checkoutOrder();await checkout.enterDetails(row.firstName,row.lastName,row.postalCode);await checkout.continue();await checkout.verifyOverview(row.productName);await checkout.finish();await checkout.verifyConfirmation(row.expectedResult);});}});
