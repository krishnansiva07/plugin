import fs from 'node:fs';
import { env } from '../src/utils/Environment';
import { detectInstalledBrowsers, resolveBrowser, type BrowserPreference } from '../src/core/browser/BrowserResolver';
import { readJsonFile } from '../src/utils/JsonData';

const preference = env('BROWSER', 'auto').toLowerCase() as BrowserPreference;
const priority = env('BROWSER_PRIORITY', 'chrome,edge').split(',').map(v => v.trim()).filter((v): v is 'chrome' | 'edge' => v === 'chrome' || v === 'edge');
const installed = detectInstalledBrowsers();
const selected = resolveBrowser(preference, priority.length ? priority : ['chrome', 'edge'], env('BROWSER_EXECUTABLE_PATH'));
const rows = readJsonFile<Array<{ run?: boolean; testId?: string }>>('test-data/login-tests.json');

console.log('\nSMART PLAYWRIGHT PREFLIGHT');
console.log('------------------------------------------------------------');
console.log(`[PASS] Node.js             ${process.version}`);
console.log(`[INFO] Installed browsers  ${installed.map(b => b.displayName).join(', ') || 'None'}`);
console.log(`[PASS] Selected browser    ${selected.displayName}`);
console.log(`[INFO] Browser path        ${selected.executablePath}`);
console.log('[PASS] Execution mode      Headed / UI');
console.log(`[PASS] JSON test data      ${rows.filter(r => r.run).length} enabled case(s)`);
console.log(`[PASS] Reporter source     ${fs.existsSync('src/reporting/SmartHtmlReporter.ts') ? 'Available' : 'Missing'}`);
console.log('------------------------------------------------------------');
console.log('Preflight passed. Run: npm test\n');
