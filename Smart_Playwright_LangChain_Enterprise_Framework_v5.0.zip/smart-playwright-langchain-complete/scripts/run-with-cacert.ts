import { existsSync, readFileSync } from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';

const root = path.resolve(__dirname, '..');
const candidates = ['generated-ca-bundle.pem','corporate-ca.pem','cacert.pem','cacert','cacerts']
  .map(name => path.join(root, 'certificates', name));
const certificate = candidates.find(existsSync);
const childEnvironment: NodeJS.ProcessEnv = { ...process.env };

if (certificate) {
  const content = readFileSync(certificate, 'utf8');
  if (!content.includes('-----BEGIN CERTIFICATE-----')) {
    console.error(`[CERTIFICATE] ${certificate} is not a PEM certificate bundle.`);
    process.exit(2);
  }
  childEnvironment.NODE_EXTRA_CA_CERTS = certificate;
  console.log(`[CERTIFICATE] Corporate CA configured: ${certificate}`);
}

type CustomKey = 'TEST_IDS'|'TEST_SUITE'|'TEST_TAGS'|'TEST_PRIORITY'|'BROWSER';
const customMap: Record<string, CustomKey> = {
  '--testid':'TEST_IDS', '--testids':'TEST_IDS', '--suite':'TEST_SUITE',
  '--tag':'TEST_TAGS', '--tags':'TEST_TAGS', '--priority':'TEST_PRIORITY', '--browser':'BROWSER'
};
const input = process.argv.slice(2);
const playwrightArgs: string[] = [];

for (let i = 0; i < input.length; i++) {
  const raw = input[i];
  const eq = raw.indexOf('=');
  const keyPart = (eq >= 0 ? raw.slice(0, eq) : raw).toLowerCase();
  const envKey = customMap[keyPart];
  if (!envKey) { playwrightArgs.push(raw); continue; }

  const value = eq >= 0 ? raw.slice(eq + 1).trim() : input[++i]?.trim();
  if (!value || value.startsWith('--')) {
    throw new Error(`Missing value for ${keyPart}`);
  }
  childEnvironment[envKey] = value;
}

console.log('\nSMART PLAYWRIGHT EXECUTION');
console.log(`Test IDs : ${childEnvironment.TEST_IDS ?? 'All enabled tests'}`);
console.log(`Suite    : ${childEnvironment.TEST_SUITE ?? 'All'}`);
console.log(`Tags     : ${childEnvironment.TEST_TAGS ?? 'All'}`);
console.log(`Priority : ${childEnvironment.TEST_PRIORITY ?? 'All'}`);
console.log(`Browser  : ${childEnvironment.BROWSER ?? 'From .env'}`);
console.log(`PW Args  : ${playwrightArgs.join(' ') || 'None'}\n`);

const cli = path.join(root, 'node_modules', '@playwright', 'test', 'cli.js');
const result = spawnSync(process.execPath, [cli, 'test', ...playwrightArgs], {
  cwd: root, env: childEnvironment, stdio: 'inherit', windowsHide: false
});
if (result.error) { console.error(result.error); process.exit(1); }
process.exit(result.status ?? 1);
