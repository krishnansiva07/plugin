const { execFile } = require('node:child_process');
const path = require('node:path');
const fs = require('node:fs');
const report = path.resolve('reports/index.html');
if (!fs.existsSync(report)) {
  console.error('Report not found. Run npm test first.');
  process.exit(1);
}
const command = process.platform === 'win32' ? 'cmd' : process.platform === 'darwin' ? 'open' : 'xdg-open';
const args = process.platform === 'win32' ? ['/c', 'start', '', report] : [report];
execFile(command, args, error => { if (error) console.error(error.message); });
