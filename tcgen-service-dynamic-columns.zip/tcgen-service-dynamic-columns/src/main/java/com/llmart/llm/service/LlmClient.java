package com.llmart.llm.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.llmart.llm.exception.TcgenException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.client.RestClient;
import org.springframework.web.client.RestClientException;

@Service
public class LlmClient {

    private final RestClient restClient;
    private final ObjectMapper objectMapper;

    @Value("${llm.api-key:}")
    private String defaultApiKey;

    @Value("${llm.model-name}")
    private String modelName;

    @Value("${llm.base-url}")
    private String baseUrl;

    @Value("${llm.temperature:0.2}")
    private Double temperature;

    @Value("${llm.max-tokens:4096}")
    private Integer maxTokens;

    @Value("${llm.auth-header:Authorization}")
    private String authHeader;

    @Value("${llm.auth-prefix:Bearer}")
    private String authPrefix;

    public LlmClient(RestClient restClient, ObjectMapper objectMapper) {
        this.restClient = restClient;
        this.objectMapper = objectMapper;
    }

    public String generate(String prompt, String userApiKey) {
        String resolvedApiKey = StringUtils.hasText(userApiKey) ? userApiKey.trim() : defaultApiKey;
        if (!StringUtils.hasText(resolvedApiKey) || "change-me".equalsIgnoreCase(resolvedApiKey.trim())) {
            throw new TcgenException("API key is required. Enter your user token in the UI or configure LLM_API_KEY.");
        }

        try {
            ObjectNode payload = objectMapper.createObjectNode();
            payload.put("model", modelName);
            payload.put("temperature", temperature);
            payload.put("max_tokens", maxTokens);

            ArrayNode messages = payload.putArray("messages");
            ObjectNode systemMessage = messages.addObject();
            systemMessage.put("role", "system");
            systemMessage.put("content", "You are a precise Senior QA Architect. Return valid JSON only.");

            ObjectNode userMessage = messages.addObject();
            userMessage.put("role", "user");
            userMessage.put("content", prompt);

            String responseBody = restClient.post()
                    .uri(resolveChatCompletionsUrl(baseUrl))
                    .headers(headers -> headers.set(authHeader, buildAuthValue(resolvedApiKey)))
                    .contentType(MediaType.APPLICATION_JSON)
                    .body(payload.toString())
                    .retrieve()
                    .body(String.class);

            return extractAssistantContent(responseBody);
        } catch (RestClientException ex) {
            throw new TcgenException("LLM request failed. Check base URL, model name, API key and network connectivity.", ex);
        } catch (TcgenException ex) {
            throw ex;
        } catch (Exception ex) {
            throw new TcgenException("Unable to parse LLM response.", ex);
        }
    }

    private String resolveChatCompletionsUrl(String configuredBaseUrl) {
        if (!StringUtils.hasText(configuredBaseUrl)) {
            throw new TcgenException("LLM base URL is required.");
        }
        String cleaned = configuredBaseUrl.trim();
        if (cleaned.endsWith("/chat/completions")) {
            return cleaned;
        }
        if (cleaned.endsWith("/")) {
            return cleaned + "chat/completions";
        }
        return cleaned + "/chat/completions";
    }

    private String buildAuthValue(String apiKey) {
        if (!StringUtils.hasText(authPrefix)) {
            return apiKey;
        }
        return authPrefix.trim() + " " + apiKey;
    }

    private String extractAssistantContent(String responseBody) throws Exception {
        if (!StringUtils.hasText(responseBody)) {
            throw new TcgenException("LLM returned empty response.");
        }

        JsonNode root = objectMapper.readTree(responseBody);
        JsonNode choices = root.path("choices");
        if (choices.isArray() && choices.size() > 0) {
            JsonNode firstChoice = choices.get(0);
            String chatContent = firstChoice.path("message").path("content").asText(null);
            if (StringUtils.hasText(chatContent)) {
                return chatContent;
            }
            String textContent = firstChoice.path("text").asText(null);
            if (StringUtils.hasText(textContent)) {
                return textContent;
            }
        }

        String outputText = root.path("output_text").asText(null);
        if (StringUtils.hasText(outputText)) {
            return outputText;
        }

        throw new TcgenException("LLM response does not contain assistant content.");
    }
}
