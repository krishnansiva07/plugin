package com.llmart.llm.exception;

public class TcgenException extends RuntimeException {

    public TcgenException(String message) {
        super(message);
    }

    public TcgenException(String message, Throwable cause) {
        super(message, cause);
    }
}
