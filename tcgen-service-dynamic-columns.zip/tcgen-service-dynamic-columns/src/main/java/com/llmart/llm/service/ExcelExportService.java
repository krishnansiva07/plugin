package com.llmart.llm.service;

import com.llmart.llm.dto.TestCaseGenerationResponse;
import com.llmart.llm.exception.TcgenException;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class ExcelExportService {

    private static final String SERIAL_NO = "S.No";

    public byte[] export(TestCaseGenerationResponse response) {
        if (response == null || response.getTestCases() == null || response.getTestCases().isEmpty()) {
            throw new TcgenException("No test cases available for export.");
        }

        try (Workbook workbook = new XSSFWorkbook(); ByteArrayOutputStream outputStream = new ByteArrayOutputStream()) {
            CellStyle headerStyle = createHeaderStyle(workbook);
            CellStyle wrapStyle = createWrapStyle(workbook);

            createTestCaseSheet(workbook, response, headerStyle, wrapStyle);
            createInfoSheet(workbook, "Follow Up Questions", response.getFollowUpQuestions(), headerStyle, wrapStyle);
            createInfoSheet(workbook, "Assumptions", response.getAssumptions(), headerStyle, wrapStyle);

            workbook.write(outputStream);
            return outputStream.toByteArray();
        } catch (Exception ex) {
            throw new TcgenException("Failed to export test cases to Excel.", ex);
        }
    }

    private void createTestCaseSheet(Workbook workbook, TestCaseGenerationResponse response, CellStyle headerStyle, CellStyle wrapStyle) {
        Sheet sheet = workbook.createSheet("Test Cases");
        List<String> headers = resolveHeaders(response);

        Row headerRow = sheet.createRow(0);
        for (int i = 0; i < headers.size(); i++) {
            Cell cell = headerRow.createCell(i);
            cell.setCellValue(headers.get(i));
            cell.setCellStyle(headerStyle);
        }

        int rowIndex = 1;
        for (Map<String, Object> testCase : response.getTestCases()) {
            Row row = sheet.createRow(rowIndex);
            for (int colIndex = 0; colIndex < headers.size(); colIndex++) {
                String header = headers.get(colIndex);
                Cell cell = row.createCell(colIndex);
                if (SERIAL_NO.equals(header)) {
                    cell.setCellValue(rowIndex);
                } else {
                    cell.setCellValue(asCellText(testCase.get(header)));
                }
                cell.setCellStyle(wrapStyle);
            }
            rowIndex++;
        }

        for (int i = 0; i < headers.size(); i++) {
            sheet.autoSizeColumn(i);
            if (sheet.getColumnWidth(i) > 14000) {
                sheet.setColumnWidth(i, 14000);
            }
        }
        sheet.createFreezePane(0, 1);
    }

    private List<String> resolveHeaders(TestCaseGenerationResponse response) {
        List<String> selectedColumns = response.getSelectedColumns();
        if (selectedColumns == null || selectedColumns.isEmpty()) {
            selectedColumns = response.getTestCases().stream()
                    .flatMap(row -> row.keySet().stream())
                    .distinct()
                    .collect(Collectors.toList());
        }

        List<String> headers = new ArrayList<>();
        headers.add(SERIAL_NO);
        for (String selectedColumn : selectedColumns) {
            if (!SERIAL_NO.equalsIgnoreCase(selectedColumn)) {
                headers.add(selectedColumn);
            }
        }
        return headers;
    }

    private String asCellText(Object value) {
        if (value == null) {
            return "";
        }
        if (value instanceof List<?> list) {
            return list.stream().map(this::asCellText).collect(Collectors.joining("\n"));
        }
        if (value instanceof Map<?, ?> map) {
            return map.entrySet().stream()
                    .map(entry -> asCellText(entry.getKey()) + ": " + asCellText(entry.getValue()))
                    .collect(Collectors.joining("\n"));
        }
        return String.valueOf(value);
    }

    private void createInfoSheet(Workbook workbook, String sheetName, List<String> values, CellStyle headerStyle, CellStyle wrapStyle) {
        Sheet sheet = workbook.createSheet(sheetName);
        Row header = sheet.createRow(0);
        Cell cell = header.createCell(0);
        cell.setCellValue(sheetName);
        cell.setCellStyle(headerStyle);

        int rowIndex = 1;
        if (values != null) {
            for (String value : values) {
                Row row = sheet.createRow(rowIndex++);
                Cell valueCell = row.createCell(0);
                valueCell.setCellValue(value == null ? "" : value);
                valueCell.setCellStyle(wrapStyle);
            }
        }
        sheet.setColumnWidth(0, 22000);
    }

    private CellStyle createHeaderStyle(Workbook workbook) {
        CellStyle style = workbook.createCellStyle();
        Font font = workbook.createFont();
        font.setBold(true);
        style.setFont(font);
        style.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
        style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        style.setBorderBottom(BorderStyle.THIN);
        style.setBorderTop(BorderStyle.THIN);
        style.setBorderLeft(BorderStyle.THIN);
        style.setBorderRight(BorderStyle.THIN);
        style.setVerticalAlignment(VerticalAlignment.CENTER);
        return style;
    }

    private CellStyle createWrapStyle(Workbook workbook) {
        CellStyle style = workbook.createCellStyle();
        style.setWrapText(true);
        style.setVerticalAlignment(VerticalAlignment.TOP);
        style.setBorderBottom(BorderStyle.THIN);
        style.setBorderTop(BorderStyle.THIN);
        style.setBorderLeft(BorderStyle.THIN);
        style.setBorderRight(BorderStyle.THIN);
        return style;
    }
}
