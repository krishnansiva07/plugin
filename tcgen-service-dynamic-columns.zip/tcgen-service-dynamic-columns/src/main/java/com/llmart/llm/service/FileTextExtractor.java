package com.llmart.llm.service;

import com.llmart.llm.exception.TcgenException;
import org.apache.tika.exception.TikaException;
import org.apache.tika.metadata.Metadata;
import org.apache.tika.parser.AutoDetectParser;
import org.apache.tika.parser.ParseContext;
import org.apache.tika.sax.BodyContentHandler;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.xml.sax.SAXException;

import java.io.IOException;
import java.io.InputStream;

@Service
public class FileTextExtractor {

    private static final long MAX_FILE_SIZE_BYTES = 20L * 1024L * 1024L;

    @Value("${tcgen.max-extracted-characters:60000}")
    private int maxExtractedCharacters;

    public String extract(MultipartFile file) {
        validateFile(file);

        try (InputStream inputStream = file.getInputStream()) {
            BodyContentHandler handler = new BodyContentHandler(-1);
            Metadata metadata = new Metadata();
            AutoDetectParser parser = new AutoDetectParser();
            ParseContext context = new ParseContext();

            parser.parse(inputStream, handler, metadata, context);
            String extractedText = cleanup(handler.toString());

            if (extractedText.isBlank()) {
                throw new TcgenException("No readable Acceptance Criteria text found in the uploaded file. For image screenshots, add OCR or paste text into a txt/docx/xlsx file.");
            }

            if (extractedText.length() > maxExtractedCharacters) {
                return extractedText.substring(0, maxExtractedCharacters)
                        + "\n\n[Content truncated because file text is too large.]";
            }

            return extractedText;
        } catch (IOException | TikaException | SAXException ex) {
            throw new TcgenException("Unable to read uploaded file. Upload txt, pdf, docx, xlsx, csv, json, xml, html, or md file.", ex);
        }
    }

    private void validateFile(MultipartFile file) {
        if (file == null || file.isEmpty()) {
            throw new TcgenException("Please upload a file containing Acceptance Criteria.");
        }

        if (file.getSize() > MAX_FILE_SIZE_BYTES) {
            throw new TcgenException("File size should be less than 20MB.");
        }
    }

    private String cleanup(String text) {
        return text == null ? "" : text.replaceAll("\\r", "")
                .replaceAll("[ \\t]+", " ")
                .replaceAll("\\n{3,}", "\\n\\n")
                .trim();
    }
}
