package com.llmart.llm.dto;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class TestCaseGenerationResponse {

    private String sourceFileName;
    private String requirementSummary;
    private List<String> followUpQuestions = new ArrayList<>();
    private List<String> assumptions = new ArrayList<>();
    private List<String> selectedColumns = new ArrayList<>();
    private List<Map<String, Object>> testCases = new ArrayList<>();
    private String rawResponse;

    public String getSourceFileName() {
        return sourceFileName;
    }

    public void setSourceFileName(String sourceFileName) {
        this.sourceFileName = sourceFileName;
    }

    public String getRequirementSummary() {
        return requirementSummary;
    }

    public void setRequirementSummary(String requirementSummary) {
        this.requirementSummary = requirementSummary;
    }

    public List<String> getFollowUpQuestions() {
        return followUpQuestions;
    }

    public void setFollowUpQuestions(List<String> followUpQuestions) {
        this.followUpQuestions = followUpQuestions == null ? new ArrayList<>() : followUpQuestions;
    }

    public List<String> getAssumptions() {
        return assumptions;
    }

    public void setAssumptions(List<String> assumptions) {
        this.assumptions = assumptions == null ? new ArrayList<>() : assumptions;
    }

    public List<String> getSelectedColumns() {
        return selectedColumns;
    }

    public void setSelectedColumns(List<String> selectedColumns) {
        this.selectedColumns = selectedColumns == null ? new ArrayList<>() : selectedColumns;
    }

    public List<Map<String, Object>> getTestCases() {
        return testCases;
    }

    public void setTestCases(List<Map<String, Object>> testCases) {
        this.testCases = testCases == null ? new ArrayList<>() : testCases;
    }

    public String getRawResponse() {
        return rawResponse;
    }

    public void setRawResponse(String rawResponse) {
        this.rawResponse = rawResponse;
    }

    public void normalizeTestCasesToSelectedColumns() {
        if (selectedColumns == null || selectedColumns.isEmpty() || testCases == null) {
            return;
        }

        List<Map<String, Object>> normalized = new ArrayList<>();
        for (Map<String, Object> row : testCases) {
            Map<String, Object> normalizedRow = new LinkedHashMap<>();
            for (String column : selectedColumns) {
                normalizedRow.put(column, findValue(row, column));
            }
            normalized.add(normalizedRow);
        }
        this.testCases = normalized;
    }

    private Object findValue(Map<String, Object> row, String expectedColumn) {
        if (row == null || row.isEmpty()) {
            return "";
        }
        if (row.containsKey(expectedColumn)) {
            Object value = row.get(expectedColumn);
            return value == null ? "" : value;
        }

        String expectedKey = normalizeKey(expectedColumn);
        for (Map.Entry<String, Object> entry : row.entrySet()) {
            if (normalizeKey(entry.getKey()).equals(expectedKey)) {
                return entry.getValue() == null ? "" : entry.getValue();
            }
        }
        return "";
    }

    private String normalizeKey(String value) {
        return value == null ? "" : value.replaceAll("[^A-Za-z0-9]", "").toLowerCase();
    }
}
