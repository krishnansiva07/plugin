package com.llmart.llm.controller;

import com.llmart.llm.dto.TestCaseGenerationResponse;
import com.llmart.llm.service.ColumnSelectionService;
import com.llmart.llm.service.ExcelExportService;
import com.llmart.llm.service.PromptBuilder;
import com.llmart.llm.service.TestCaseGeneratorService;
import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/testcases")
@CrossOrigin(origins = "*")
public class TestCaseController {

    private final TestCaseGeneratorService testCaseGeneratorService;
    private final ExcelExportService excelExportService;
    private final ColumnSelectionService columnSelectionService;
    private final PromptBuilder promptBuilder;

    public TestCaseController(TestCaseGeneratorService testCaseGeneratorService,
                              ExcelExportService excelExportService,
                              ColumnSelectionService columnSelectionService,
                              PromptBuilder promptBuilder) {
        this.testCaseGeneratorService = testCaseGeneratorService;
        this.excelExportService = excelExportService;
        this.columnSelectionService = columnSelectionService;
        this.promptBuilder = promptBuilder;
    }

    @GetMapping("/health")
    public Map<String, Object> health() {
        return Map.of("status", "UP", "service", "TCGen", "dynamicColumns", true);
    }

    @GetMapping("/columns/defaults")
    public Map<String, List<String>> defaultColumns() {
        return Map.of("columns", columnSelectionService.defaultColumns());
    }

    @PostMapping(value = "/prompt-preview", consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
    public Map<String, String> promptPreview(@RequestParam(value = "additionalPrompt", required = false) String additionalPrompt,
                                             @RequestParam(value = "selectedColumns", required = false) String selectedColumnsCsv) {
        List<String> columns = columnSelectionService.resolveColumns(selectedColumnsCsv);
        return Map.of("prompt", promptBuilder.buildPreviewPrompt(additionalPrompt, columns));
    }

    @PostMapping(value = "/generate", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public TestCaseGenerationResponse generate(@RequestParam("file") MultipartFile file,
                                               @RequestParam(value = "additionalPrompt", required = false) String additionalPrompt,
                                               @RequestParam(value = "apiKey", required = false) String apiKey,
                                               @RequestParam(value = "selectedColumns", required = false) String selectedColumnsCsv) {
        return testCaseGeneratorService.generate(file, additionalPrompt, apiKey, selectedColumnsCsv);
    }

    @PostMapping(value = "/export", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<byte[]> export(@RequestBody TestCaseGenerationResponse response) {
        byte[] excelBytes = excelExportService.export(response);
        String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss"));
        String fileName = "TCGen_TestCases_" + timestamp + ".xlsx";

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.parseMediaType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"));
        headers.setContentDisposition(ContentDisposition.attachment().filename(fileName).build());
        headers.setContentLength(excelBytes.length);

        return ResponseEntity.ok().headers(headers).body(excelBytes);
    }
}
