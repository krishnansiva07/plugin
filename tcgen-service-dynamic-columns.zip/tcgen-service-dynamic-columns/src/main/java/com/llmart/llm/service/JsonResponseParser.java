package com.llmart.llm.service;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.llmart.llm.dto.TestCaseGenerationResponse;
import com.llmart.llm.exception.TcgenException;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class JsonResponseParser {

    private final ObjectMapper objectMapper;

    public JsonResponseParser() {
        this.objectMapper = new ObjectMapper()
                .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
    }

    public TestCaseGenerationResponse parse(String llmResponse, List<String> selectedColumns) {
        try {
            String json = extractJson(llmResponse);
            TestCaseGenerationResponse response = objectMapper.readValue(json, TestCaseGenerationResponse.class);
            response.setRawResponse(llmResponse);
            response.setSelectedColumns(new ArrayList<>(selectedColumns));
            response.normalizeTestCasesToSelectedColumns();
            validate(response);
            return response;
        } catch (TcgenException ex) {
            throw ex;
        } catch (Exception ex) {
            throw new TcgenException("LLM response was not valid JSON. Please retry with a smaller file or clearer prompt.", ex);
        }
    }

    private void validate(TestCaseGenerationResponse response) {
        if (response.getTestCases() == null || response.getTestCases().isEmpty()) {
            throw new TcgenException("LLM did not return any test cases. Try adding more Acceptance Criteria details.");
        }
    }

    private String extractJson(String response) {
        if (response == null || response.isBlank()) {
            throw new TcgenException("LLM returned empty response.");
        }

        String cleaned = response.trim()
                .replace("```json", "")
                .replace("```JSON", "")
                .replace("```", "")
                .trim();

        int firstBrace = cleaned.indexOf('{');
        int lastBrace = cleaned.lastIndexOf('}');

        if (firstBrace < 0 || lastBrace <= firstBrace) {
            throw new TcgenException("No JSON object found in LLM response.");
        }

        return cleaned.substring(firstBrace, lastBrace + 1);
    }
}
