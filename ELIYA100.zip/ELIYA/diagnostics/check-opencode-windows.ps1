# OpenCode v2 outbound connectivity check. Read-only; prints no credentials or proxy URLs.
# Execute: powershell -NoProfile -File .\diagnostics\check-opencode-windows.ps1
$ErrorActionPreference = 'Continue'
Write-Host 'ELIYA / OpenCode 2 Network Diagnostics (read-only)' -ForegroundColor Cyan
$hasHttpsProxy = [bool]($env:HTTPS_PROXY -or $env:https_proxy)
$hasHttpProxy = [bool]($env:HTTP_PROXY -or $env:http_proxy)
Write-Host ("HTTPS_PROXY configured for this process: {0}" -f $hasHttpsProxy)
Write-Host ("HTTP_PROXY configured for this process: {0}" -f $hasHttpProxy)
Write-Host 'Note: A browser may use a Windows PAC/system proxy that the OpenCode server does not inherit.'
$opencode = Get-Command opencode -ErrorAction SilentlyContinue
if ($opencode) {
    try { Write-Host ("OpenCode executable version: {0}" -f (& opencode --version)) }
    catch { Write-Host ("Unable to query OpenCode version: {0}" -f $_.Exception.GetType().Name) }
} else { Write-Host 'opencode not found in this PowerShell PATH' -ForegroundColor Yellow }
foreach ($hostName in @('opencode.ai', 'models.opencode.ai')) {
    Write-Host ("Checking {0}" -f $hostName)
    try {
        $dnsResult = @(Resolve-DnsName -Name $hostName -ErrorAction Stop | Where-Object { $_.Type -eq 'A' -or $_.Type -eq 'AAAA' })
        Write-Host ("  DNS lookup: {0}" -f $(if($dnsResult.Count -gt 0){'OK'}else{'no A/AAAA address'}))
    } catch { Write-Host ("  DNS lookup failed: {0}" -f $_.Exception.Message) -ForegroundColor Yellow }
    try {
        # Curl exit code and HTTP status only. No request secrets or headers are printed.
        $code = & curl.exe -sS -I --max-time 10 -o NUL -w '%{http_code}' "https://$hostName/" 2>$null
        if ($LASTEXITCODE -eq 0) { Write-Host ("  HTTPS: reachable (HTTP {0})" -f $code) }
        else { Write-Host ("  HTTPS failed (curl exit {0})" -f $LASTEXITCODE) -ForegroundColor Yellow }
    } catch { Write-Host '  HTTPS test unavailable' -ForegroundColor Yellow }
}
Write-Host 'If DNS/HTTPS fails on your corporate network, ask IT about allowed domains, proxy and trusted CA.'
Write-Host 'If a LOCAL model was selected, check whether OpenCode is still fetching remote model catalogs.'
Write-Host 'This script does not change the Windows DNS, firewall, proxy, certificates, or OpenCode configuration.'
