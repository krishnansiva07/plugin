package com.llmart.llm.service;

import java.util.Map;

public class OpenCodeNetworkSmoke {
    public static void main(String[] args) {
        String msg = OpenCodeNetworkDiagnostics.explain("getaddrinfo ENOTFOUND opencode.ai",
                "opencode/qwen-coder", Map.of());
        check(msg.contains("Selected model: opencode/qwen-coder"), "selected model displayed");
        check(msg.contains("HTTPS_PROXY"), "network repair guidance");
        check(msg.contains("Resolve-DnsName"), "Windows diagnostics");
        check(msg.contains("Do not change system DNS or disable TLS verification"), "safe TLS advice");
        check(OpenCodeNetworkDiagnostics.explain("getaddrinfo ENOTFOUND opencode.ai", "local/qwen",
                Map.of("HTTPS_PROXY", "http://secret:password@corp.example:8080")).contains("proxy environment variable"),
                "proxy flag without secrets");
        String ca = OpenCodeNetworkDiagnostics.explain("self signed certificate", "local/qwen", Map.of());
        check(ca.contains("NODE_EXTRA_CA_CERTS"), "company CA guidance");
        String bypass = OpenCodeLocalRuntime.mergeNoProxy("internal.corp,localhost,.bnp.local");
        check(bypass.contains("internal.corp") && bypass.contains(".bnp.local") &&
                bypass.contains("127.0.0.1") && bypass.contains("::1"), "preserve corporate bypass");
        check("anthropic/claude".equals(OpenCodeNetworkDiagnostics.modelName("old", "anthropic", "claude")),
                "correct selected provider name");
        System.out.println("PASS: 8 OpenCode DNS/proxy/model diagnostics checks");
    }
    private static void check(boolean ok, String description) {
        if (!ok) throw new AssertionError(description);
    }
}
