package com.llmart.llm.service;

import java.util.Locale;
import java.util.Map;

/** Pure, zero-network, no-secrets provider failure classification for OpenCode 2.
 * The local server's successful health check does not verify outbound model traffic.
 */
public final class OpenCodeNetworkDiagnostics {
    private OpenCodeNetworkDiagnostics() {}

    public static String modelName(String id, String providerID, String modelID) {
        if (providerID != null && !providerID.isBlank() && modelID != null && !modelID.isBlank())
            return providerID + "/" + modelID;
        return id == null || id.isBlank() ? "unknown" : id;
    }

    public static String explain(String failure, String model, Map<String,String> env) {
        if (failure == null) return "Unknown OpenCode provider error";
        String lower = failure.toLowerCase(Locale.ROOT);
        String selected = model == null || model.isBlank() ? "not reported" : model;
        boolean proxy = has(env, "HTTPS_PROXY") || has(env, "https_proxy") ||
                has(env, "HTTP_PROXY") || has(env, "http_proxy");
        if (lower.contains("enotfound") || lower.contains("eai_again") || lower.contains("getaddrinfo")) {
            boolean openCodeHost = lower.contains("opencode.ai") || lower.contains("models.opencode.ai");
            return failure + ". DNS/network failure " + (openCodeHost ? "reaching OpenCode services" : "resolving a provider host")
                    + ". Selected model: " + selected + ". "
                    + (proxy ? "A proxy environment variable is present on ELIYA's Java process; verify it is reachable and allowed for OpenCode. "
                             : "No HTTP(S)_PROXY environment variable was inherited by ELIYA; a browser's Windows/PAC proxy is not necessarily inherited by OpenCode. ")
                    + "In PowerShell run: Resolve-DnsName opencode.ai; curl.exe -I https://opencode.ai. "
                    + "If your company requires a proxy, set approved HTTPS_PROXY for the JAR process, then restart. "
                    + "Do not change system DNS or disable TLS verification. With an offline/local model, explicitly select it "
                    + "in OpenCode and consider OPENCODE_DISABLE_MODELS_FETCH=1; that flag cannot make an OpenCode-hosted model work offline.";
        }
        if (lower.contains("self signed certificate") || lower.contains("unable to verify") ||
                lower.contains("certificate verify failed")) {
            return failure + ". OpenCode cannot verify the outbound HTTPS certificate. "
                    + "Ask IT for the trusted company CA bundle and configure NODE_EXTRA_CA_CERTS; do not disable certificate validation.";
        }
        if (lower.contains("407") && lower.contains("proxy")) {
            return failure + ". Enterprise proxy authentication is required. Use IT-approved proxy authentication or gateway settings.";
        }
        return failure;
    }

    private static boolean has(Map<String,String> env, String key) {
        String value = env == null ? null : env.get(key);
        return value != null && !value.isBlank();
    }
}
