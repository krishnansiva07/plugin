'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const source = fs.readFileSync(path.resolve(__dirname, '../../main/resources/static/app.js'), 'utf8');
test('OpenCode terminal error remains available in UI snapshot and replaces generic failed response', () => {
  assert.match(source, /error:\s*raw\.error\s*\|\|\s*''/);
  assert.match(source, /const remoteFailureReason = String\(snapshot\.error \|\| snapshot\.lastRemoteStatus/);
  assert.match(source, /else if \(remoteFailure\)\s*\{/);
  assert.match(source, /No workspace changes have been confirmed/);
  const when = source.indexOf('else if (remoteFailure)');
  const generic = source.indexOf('Agent run ended with backend status', when);
  assert.ok(when >= 0 && generic > when, 'generic terminal message must be fallback after OpenCode error');
});
