# Advanced AI Workbench Agent — V11

Java 17 local autonomous workspace agent with **Chat**, **Analyze**, and **Agent** modes.

This build is intentionally general-purpose. Dedicated test-case generation has been removed. Git operations are intentionally out of scope.

## Agent execution model

Agent mode requires a user-mapped local directory. That directory is the **live workspace**:

```text
User maps local path once
        ↓
Persistent active workspace
        ↓
Model turn (native tools first)
        ↓
One or many tool calls
        ↓
Read / search / edit / shell / build / run / verify
        ↓
Real tool observations returned to model
        ↓
Fix and repeat until verified complete or genuinely blocked
```

There is **no temporary project mirror, staging workspace, later Apply step, fixed model-step ceiling, fixed tool-action ceiling, fixed build/fix retry count, or default shell timeout** in Agent mode.

`Max output tokens = 0` means the application does not set `max_tokens`; the selected provider/model controls its own maximum. `Context budget = 0` means the application uses the provider window first and only compacts old tool observations after the provider reports a real context-window overflow.

Unavoidable limits still come from the selected model/provider, operating system, disk, RAM, process limits, network availability and third-party tools.

## Main Agent tools

Workspace/navigation:

- `inspect_workspace`
- `list`
- `glob`
- `grep`
- `file_info`
- `read`
- `read_many`

Mutation, direct to the mapped path:

- `edit`
- `write`
- `copy`
- `move`
- `delete`
- `apply_patch`

Execution and runtime verification:

- `build`
- `test`
- `check`
- `bash` — normal workspace shell with pipes/redirection/chaining; no default application timeout
- `process_start`
- `process_status`
- `process_output`
- `process_stop`
- `http_request` — inspect a running web/API application using real HTTP responses

Context/helpers:

- `attachment_list`
- `attachment_read`
- `skill`
- `workspace_status`
- `workspace_diff`
- `todowrite`
- `todoread`

Native OpenAI-compatible tool/function calling is the primary transport. If a provider does not support native tools, the runtime automatically falls back to JSON compatibility mode instead of aborting on a normal prose response.

## Build → run → inspect → fix loop

For code/configuration mutations the runtime prevents a normal `completed` response while the current revision still requires verification. The model is instructed to:

1. inspect the actual workspace;
2. make the requested change directly;
3. build/check/test as appropriate;
4. start a long-running application with `process_start` when needed;
5. inspect stdout/stderr with `process_output` and process state with `process_status`;
6. verify HTTP applications with `http_request` or custom `bash` checks;
7. diagnose real errors;
8. edit and rerun until the current revision passes or a genuine external blocker is established.

A custom `bash` or `http_request` verifier can set `verification=true`.

## Documents and attachments

The file picker no longer restricts extensions and the application no longer imposes a fixed upload-size limit. Actual practical limits are the browser/server/machine resources.

At upload time, textual content is extracted eagerly. Supported paths include:

- DOCX through direct WordprocessingML extraction with Tika fallback;
- XLSX/PPTX through Apache POI with Tika fallback;
- PDF, legacy Office, RTF, OpenDocument, HTML and other Tika-supported formats;
- plain text/source/configuration files.

Documents attached to the **current message** are always first-class context in both Chat and Analyze modes. In Agent mode, the same extracted content is available in the message and through `attachment_list` / `attachment_read`.

Extraction status is explicit: `ready`, `empty`, `failed`, or `not_applicable`.

## Persistent local workspace

Map the local path once under **Open workspace → Local workspace path**. The workspace ID is persisted and the same canonical path is reusable across actions, new chats and page reloads until explicitly disconnected.

Agent mode always works directly in this path. There is no copy-back/apply operation.

## Permissions

Edit and shell execution can be configured as **Allow / Ask / Deny**. Ask supports:

- Deny
- Approve once
- Allow this run

Approval waiting has no application timeout. Stop/cancel remains available to the user.

## Running

Requirements: Java 17+ and Maven.

```bash
mvn clean test
mvn clean package
java -jar target/advanced-ai-chat-2.1.0-SNAPSHOT.jar
```

Or use `run.sh` / `run.bat`.

Open `http://localhost:8090`. The server binds to `127.0.0.1` by default because the application has direct local-filesystem capabilities.

## V11 generic-agent modules

V11 adds the architecture modules that were missing from V10:

- persistent workspace profiling;
- root/nested project instructions;
- lazy reusable skills;
- fresh-context subagent delegation;
- generic MCP discovery and dynamically namespaced MCP tools;
- generic LSP diagnostics/navigation;
- attachment list/read/search resources;
- native multi-tool turns with eligible read-only parallelism.

Git remains intentionally out of scope. A PTY-style fully interactive terminal is not yet implemented; normal workspace shell and managed background processes are available.
