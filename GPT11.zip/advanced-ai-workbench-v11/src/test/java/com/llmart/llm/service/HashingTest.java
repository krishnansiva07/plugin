package com.llmart.llm.service;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class HashingTest {
    @Test
    void sha256IsStableAndUsesUtf8Text() {
        assertEquals("ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad", Hashing.sha256("abc"));
        assertEquals(Hashing.sha256("hello"), Hashing.sha256("hello"));
        assertNotEquals(Hashing.sha256("hello"), Hashing.sha256("Hello"));
    }
}
