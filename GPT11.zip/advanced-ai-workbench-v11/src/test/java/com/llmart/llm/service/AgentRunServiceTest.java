package com.llmart.llm.service;

import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class AgentRunServiceTest {

    @Test
    void tracksPlanMutationDiffAndVerificationRevision() {
        AgentRunService service = new AgentRunService();
        AgentRunService.AgentRun run = service.start("conversation", "project");

        run.setPlan(List.of("Inspect", "Edit", "Verify"));
        assertTrue(run.hasPlan());
        assertTrue(run.hasOpenPlanItems());

        run.updatePlan(1, "completed", "inspected");
        run.updatePlan(2, "completed", "changed");
        run.markMutation();
        assertFalse(run.diffReviewedCurrentRevision());
        run.markDiffReview();
        assertTrue(run.diffReviewedCurrentRevision());

        run.markVerificationAttempt(true, "build passed");
        assertTrue(run.verifiedCurrentRevision());
        run.updatePlan(3, "completed", "passed");
        assertFalse(run.hasOpenPlanItems());
    }

    @Test
    void cancellationIsIdempotentAndFinishedRunCannotBeCancelled() {
        AgentRunService service = new AgentRunService();
        AgentRunService.AgentRun running = service.start("conversation", null);
        assertTrue(service.cancel(running.id()));
        assertFalse(service.cancel(running.id()));
        assertThrows(AgentCancelledException.class, running::checkCancelled);

        AgentRunService.AgentRun completed = service.start("conversation", null);
        completed.finish("completed");
        assertFalse(service.cancel(completed.id()));
        assertEquals("completed", completed.snapshot().get("status"));
    }
}
