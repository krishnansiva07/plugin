package com.llmart.llm.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.llmart.llm.dto.ProjectPatchRequest;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayInputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import static org.junit.jupiter.api.Assertions.*;

class ProjectPatchServiceTest {

    @Test
    void zipContainsWritesAndStructuredManifestForDeletesAndBaselines() throws Exception {
        ObjectMapper mapper = new ObjectMapper();
        ProjectPatchService service = new ProjectPatchService(mapper);
        ProjectPatchRequest request = new ProjectPatchRequest("demo", List.of(
                new ProjectPatchRequest.ProjectPatchFile("src/New.java", "class New {}", "ABSENT", "write"),
                new ProjectPatchRequest.ProjectPatchFile("src/Old.java", null, "abc", "delete")
        ));

        byte[] bytes = service.zip(request);
        List<String> names = new ArrayList<>();
        String manifest = "";
        try (ZipInputStream zip = new ZipInputStream(new ByteArrayInputStream(bytes), StandardCharsets.UTF_8)) {
            ZipEntry entry;
            while ((entry = zip.getNextEntry()) != null) {
                names.add(entry.getName());
                byte[] content = zip.readAllBytes();
                if ("_AGENT_PATCH_MANIFEST.json".equals(entry.getName())) {
                    manifest = new String(content, StandardCharsets.UTF_8);
                }
            }
        }

        assertTrue(names.contains("src/New.java"));
        assertTrue(names.contains("_AGENT_PATCH_MANIFEST.json"));
        assertFalse(names.contains("src/Old.java"));
        JsonNode json = mapper.readTree(manifest);
        assertEquals("advanced-ai-workbench-agent-patch/v1", json.path("format").asText());
        assertEquals(2, json.path("files").size());
        assertTrue(manifest.contains("src/Old.java"));
        assertTrue(manifest.contains("baselineHash"));
    }
}
