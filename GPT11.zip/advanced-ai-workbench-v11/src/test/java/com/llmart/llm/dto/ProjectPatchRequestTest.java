package com.llmart.llm.dto;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

class ProjectPatchRequestTest {
    @Test
    void operationDefaultsToWriteAndNormalizesDelete() {
        assertEquals("write", new ProjectPatchRequest.ProjectPatchFile("a.txt", "x").safeOperation());
        assertEquals("delete", new ProjectPatchRequest.ProjectPatchFile("a.txt", null, "hash", "DELETE").safeOperation());
        assertEquals("write", new ProjectPatchRequest.ProjectPatchFile("a.txt", "x", "hash", "other").safeOperation());
    }
}
