package com.llmart.llm.service;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class AgentToolRegistryTest {

    @Test
    void exposesWorkspaceAgentToolsWithoutGitOperations() {
        AgentToolRegistry registry = new AgentToolRegistry();

        assertTrue(registry.isKnown("inspect_workspace"));
        assertTrue(registry.isKnown("read_file"));
        assertTrue(registry.isKnown("write_file"));
        assertTrue(registry.isKnown("apply_patch"));
        assertTrue(registry.isKnown("workspace_status"));
        assertTrue(registry.isKnown("workspace_diff"));
        assertTrue(registry.isKnown("run_build"));
        assertTrue(registry.isKnown("run_tests"));
        assertTrue(registry.isKnown("run_command"));
        assertTrue(registry.isKnown("attachment_list"));
        assertTrue(registry.isKnown("attachment_read"));
        assertTrue(registry.isKnown("skill"));
        assertFalse(registry.isKnown("finish")); // normal assistant text ends the run

        assertFalse(registry.isKnown("git_status"));
        assertFalse(registry.isKnown("git_diff"));
        assertFalse(registry.names().stream().anyMatch(name -> name.startsWith("git_")));
        assertEquals(registry.names().size(), registry.nativeDefinitions().size());
    }
}
