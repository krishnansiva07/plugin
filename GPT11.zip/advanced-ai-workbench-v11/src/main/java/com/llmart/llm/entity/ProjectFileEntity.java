package com.llmart.llm.entity;

import jakarta.persistence.*;
import java.time.Instant;

@Entity
@Table(name = "project_files",
        uniqueConstraints = @UniqueConstraint(name = "uk_project_path", columnNames = {"project_id", "relative_path"}),
        indexes = @Index(name = "idx_project_file_project", columnList = "project_id"))
public class ProjectFileEntity {
    @Id
    @Column(length = 40)
    private String id;

    @Column(name = "project_id", nullable = false, length = 40)
    private String projectId;

    @Column(name = "relative_path", nullable = false, length = 1200)
    private String relativePath;

    @Column(length = 200)
    private String mimeType;

    private long sizeBytes;

    @Lob
    @Column(columnDefinition = "CLOB")
    private String textContent;

    @Column(nullable = false)
    private Instant updatedAt;

    public ProjectFileEntity() {}

    public ProjectFileEntity(String id, String projectId, String relativePath, String mimeType,
                             long sizeBytes, String textContent) {
        this.id = id;
        this.projectId = projectId;
        this.relativePath = relativePath;
        this.mimeType = mimeType;
        this.sizeBytes = sizeBytes;
        this.textContent = textContent;
        this.updatedAt = Instant.now();
    }

    public void update(String mimeType, long sizeBytes, String textContent) {
        this.mimeType = mimeType;
        this.sizeBytes = sizeBytes;
        this.textContent = textContent;
        this.updatedAt = Instant.now();
    }

    public String getId() { return id; }
    public String getProjectId() { return projectId; }
    public String getRelativePath() { return relativePath; }
    public String getMimeType() { return mimeType; }
    public long getSizeBytes() { return sizeBytes; }
    public String getTextContent() { return textContent; }
    public Instant getUpdatedAt() { return updatedAt; }
}
