package com.llmart.llm.dto;

import java.time.Instant;
import java.util.List;

public record MessageDto(Long id, String role, String content, List<String> attachmentIds, Instant createdAt) {}
