package com.llmart.llm.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.llmart.llm.dto.ProjectPatchRequest;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

@Service
public class ProjectPatchService {
    private final ObjectMapper objectMapper;

    public ProjectPatchService(ObjectMapper objectMapper) {
        this.objectMapper = objectMapper;
    }

    public byte[] zip(ProjectPatchRequest request) throws Exception {
        if (request == null || request.files() == null || request.files().isEmpty()) {
            throw new IllegalArgumentException("No project changes were provided");
        }
        try (ByteArrayOutputStream out = new ByteArrayOutputStream();
             ZipOutputStream zip = new ZipOutputStream(out, StandardCharsets.UTF_8)) {
            Set<String> used = new HashSet<>();
            List<Map<String,Object>> manifestFiles = new ArrayList<>();
            for (ProjectPatchRequest.ProjectPatchFile file : request.files()) {
                if (file == null || file.path() == null || file.path().isBlank()) continue;
                String path = normalize(file.path());
                if (!used.add(path)) continue;
                Map<String,Object> manifestFile = new LinkedHashMap<>();
                manifestFile.put("path", path);
                manifestFile.put("operation", file.safeOperation());
                if (file.baselineHash() != null && !file.baselineHash().isBlank()) {
                    manifestFile.put("baselineHash", file.baselineHash());
                }
                manifestFiles.add(manifestFile);

                if ("delete".equals(file.safeOperation())) continue;
                ZipEntry entry = new ZipEntry(path);
                zip.putNextEntry(entry);
                zip.write((file.content() == null ? "" : file.content()).getBytes(StandardCharsets.UTF_8));
                zip.closeEntry();
            }

            Map<String,Object> manifest = new LinkedHashMap<>();
            manifest.put("format", "advanced-ai-workbench-agent-patch/v1");
            manifest.put("projectName", request.projectName() == null ? "project" : request.projectName());
            manifest.put("files", manifestFiles);
            ZipEntry metadata = new ZipEntry("_AGENT_PATCH_MANIFEST.json");
            zip.putNextEntry(metadata);
            zip.write(objectMapper.writerWithDefaultPrettyPrinter().writeValueAsBytes(manifest));
            zip.closeEntry();
            zip.finish();
            return out.toByteArray();
        }
    }

    private String normalize(String raw) {
        String p = raw.replace('\\', '/').replaceAll("^/+", "");
        if (p.isBlank() || p.startsWith("../") || p.contains("/../") || p.endsWith("/..") || p.contains("\u0000")) {
            throw new SecurityException("Invalid patch path: " + raw);
        }
        return p;
    }
}
