package com.llmart.llm.dto;

import java.util.List;

public record ProjectUploadBatch(List<ProjectFileUpload> files) {}
