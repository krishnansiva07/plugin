package com.llmart.llm.dto;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;

import java.util.List;

public record ChatRequest(
        String conversationId,
        String message,
        List<String> attachmentIds,
        String projectId,
        String mode,
        Boolean regenerate,
        @Valid @NotNull ChatSettings settings
) {
    public boolean isRegenerate() { return Boolean.TRUE.equals(regenerate); }
    public ChatMode chatMode() { return ChatMode.from(mode); }
}
