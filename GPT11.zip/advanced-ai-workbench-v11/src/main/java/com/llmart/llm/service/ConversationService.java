package com.llmart.llm.service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.llmart.llm.dto.ConversationDto;
import com.llmart.llm.dto.MessageDto;
import com.llmart.llm.entity.ConversationEntity;
import com.llmart.llm.entity.MessageEntity;
import com.llmart.llm.repository.ConversationRepository;
import com.llmart.llm.repository.FileRepository;
import com.llmart.llm.repository.MessageRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;

@Service
public class ConversationService {
    private final ConversationRepository conversations;
    private final MessageRepository messages;
    private final FileRepository files;
    private final ObjectMapper objectMapper;

    public ConversationService(ConversationRepository conversations, MessageRepository messages,
                               FileRepository files, ObjectMapper objectMapper) {
        this.conversations = conversations;
        this.messages = messages;
        this.files = files;
        this.objectMapper = objectMapper;
    }

    public List<ConversationDto> list() {
        return conversations.findAllByOrderByUpdatedAtDesc().stream().map(this::dto).toList();
    }

    public ConversationEntity create() {
        return conversations.save(new ConversationEntity(UUID.randomUUID().toString(), "New chat"));
    }

    public ConversationEntity getOrCreate(String id) {
        if (id == null || id.isBlank()) return create();
        return conversations.findById(id).orElseGet(this::create);
    }

    public ConversationEntity require(String id) {
        return conversations.findById(id).orElseThrow(() -> new NoSuchElementException("Conversation not found"));
    }

    public List<MessageDto> listMessages(String conversationId) {
        require(conversationId);
        return messages.findByConversationIdOrderByCreatedAtAsc(conversationId).stream().map(this::messageDto).toList();
    }

    public List<MessageEntity> messageEntities(String conversationId) {
        return messages.findByConversationIdOrderByCreatedAtAsc(conversationId);
    }

    public MessageEntity addMessage(String conversationId, String role, String content, List<String> attachmentIds) {
        String json = null;
        try { json = objectMapper.writeValueAsString(attachmentIds == null ? List.of() : attachmentIds); }
        catch (Exception ignored) { json = "[]"; }
        MessageEntity saved = messages.save(new MessageEntity(conversationId, role, content, json));
        ConversationEntity c = require(conversationId);
        if ("New chat".equals(c.getTitle()) && "user".equals(role)) c.setTitle(makeTitle(content));
        c.touch();
        conversations.save(c);
        return saved;
    }

    public MessageEntity lastUserMessage(String conversationId) {
        List<MessageEntity> all = messageEntities(conversationId);
        for (int i = all.size() - 1; i >= 0; i--) {
            if ("user".equals(all.get(i).getRole())) return all.get(i);
        }
        throw new IllegalStateException("No user message to regenerate");
    }

    @Transactional
    public void removeMessagesAfter(String conversationId, Long keepThroughId) {
        List<MessageEntity> all = messageEntities(conversationId);
        List<MessageEntity> doomed = all.stream().filter(m -> m.getId() > keepThroughId).toList();
        messages.deleteAll(doomed);
        ConversationEntity c = require(conversationId);
        c.touch();
        conversations.save(c);
    }

    @Transactional
    public void rewindFrom(String conversationId, Long messageId) {
        List<MessageEntity> all = messageEntities(conversationId);
        List<MessageEntity> doomed = all.stream().filter(m -> m.getId() >= messageId).toList();
        messages.deleteAll(doomed);
        ConversationEntity c = require(conversationId);
        c.touch();
        conversations.save(c);
    }

    public ConversationDto rename(String id, String title) {
        ConversationEntity c = require(id);
        c.setTitle((title == null || title.isBlank()) ? "New chat" : title.trim().substring(0, Math.min(180, title.trim().length())));
        c.touch();
        return dto(conversations.save(c));
    }

    @Transactional
    public void delete(String id) {
        require(id);
        messages.deleteByConversationId(id);
        files.deleteByConversationId(id);
        conversations.deleteById(id);
    }

    public MessageDto messageDto(MessageEntity m) {
        List<String> ids = List.of();
        if (m.getAttachmentIdsJson() != null) {
            try { ids = objectMapper.readValue(m.getAttachmentIdsJson(), new TypeReference<>() {}); }
            catch (Exception ignored) {}
        }
        return new MessageDto(m.getId(), m.getRole(), m.getContent(), ids, m.getCreatedAt());
    }

    private ConversationDto dto(ConversationEntity c) {
        return new ConversationDto(c.getId(), c.getTitle(), c.getCreatedAt(), c.getUpdatedAt());
    }

    private String makeTitle(String text) {
        String t = text == null ? "New chat" : text.replaceAll("\\s+", " ").trim();
        if (t.isEmpty()) return "New chat";
        return t.length() <= 58 ? t : t.substring(0, 58) + "…";
    }
}
