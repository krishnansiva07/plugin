package com.llmart.llm.dto;

import java.util.Locale;

public enum ChatMode {
    CHAT,
    ANALYZE,
    AGENT;

    public static ChatMode from(String raw) {
        if (raw == null || raw.isBlank()) return CHAT;
        try {
            return valueOf(raw.trim().toUpperCase(Locale.ROOT));
        } catch (IllegalArgumentException ignored) {
            return CHAT;
        }
    }

    public String wireName() {
        return name().toLowerCase(Locale.ROOT);
    }
}
