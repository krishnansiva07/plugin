package com.llmart.llm.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Durable, cheap workspace profile used to avoid re-discovering the same project on every prompt.
 * The cache lives in application data, never in a temporary copy of the user's project.
 */
@Service
public class WorkspaceProfileService {
    private static final Set<String> SKIP_DIRS = Set.of(
            ".git", ".svn", ".hg", "node_modules", "target", "build", "dist", "out", ".gradle", ".idea",
            ".next", "coverage", ".venv", "venv", "vendor", ".terraform", ".dart_tool", ".cache", "bin", "obj"
    );
    private final ObjectMapper mapper;
    private final Path cacheRoot;
    private final Map<String, WorkspaceProfile> memory = new ConcurrentHashMap<>();

    public WorkspaceProfileService(ObjectMapper mapper,
                                   @Value("${app.agent-cache-dir:./data/agent-cache}") String cacheDir) {
        this.mapper = mapper;
        this.cacheRoot = Path.of(cacheDir).toAbsolutePath().normalize();
    }

    public WorkspaceProfile profile(AgentWorkspaceService.Workspace ws, boolean forceRefresh) {
        String key = ws.projectId();
        if (!forceRefresh) {
            WorkspaceProfile cached = memory.get(key);
            if (cached != null && Objects.equals(cached.root(), ws.root().toString())) return cached;
            WorkspaceProfile disk = readDisk(key);
            if (disk != null && Objects.equals(disk.root(), ws.root().toString())) {
                memory.put(key, disk);
                return disk;
            }
        }
        WorkspaceProfile fresh = scan(ws);
        memory.put(key, fresh);
        writeDisk(key, fresh);
        return fresh;
    }

    public String profileText(AgentWorkspaceService.Workspace ws) {
        WorkspaceProfile p = profile(ws, false);
        StringBuilder out = new StringBuilder();
        out.append("WORKSPACE PROFILE\n");
        out.append("root: ").append(p.root()).append('\n');
        out.append("detected: ").append(p.detectedTechnologies().isEmpty() ? "unknown/mixed" : String.join(", ", p.detectedTechnologies())).append('\n');
        out.append("descriptors: ").append(p.descriptors().isEmpty() ? "none" : String.join(", ", p.descriptors())).append('\n');
        out.append("languages: ").append(p.languages().isEmpty() ? "unknown" : String.join(", ", p.languages())).append('\n');
        out.append("instructionFiles: ").append(p.instructionFiles().isEmpty() ? "none" : String.join(", ", p.instructionFiles())).append('\n');
        out.append("skillFiles: ").append(p.skillFiles().isEmpty() ? "none" : String.join(", ", p.skillFiles())).append('\n');
        out.append("mcpConfigFiles: ").append(p.mcpConfigFiles().isEmpty() ? "none" : String.join(", ", p.mcpConfigFiles())).append('\n');
        out.append("profileGeneratedAt: ").append(p.generatedAt());
        return out.toString();
    }

    public String refresh(AgentWorkspaceService.Workspace ws) {
        return profileTextFrom(profile(ws, true));
    }

    private String profileTextFrom(WorkspaceProfile p) {
        return "Workspace profile refreshed\n" +
                "detected=" + String.join(", ", p.detectedTechnologies()) + "\n" +
                "languages=" + String.join(", ", p.languages()) + "\n" +
                "descriptors=" + String.join(", ", p.descriptors()) + "\n" +
                "instructions=" + String.join(", ", p.instructionFiles()) + "\n" +
                "skills=" + String.join(", ", p.skillFiles());
    }

    private WorkspaceProfile scan(AgentWorkspaceService.Workspace ws) {
        Path root = ws.root();
        LinkedHashSet<String> descriptors = new LinkedHashSet<>();
        LinkedHashSet<String> technologies = new LinkedHashSet<>();
        LinkedHashSet<String> languages = new LinkedHashSet<>();
        LinkedHashSet<String> instructions = new LinkedHashSet<>();
        LinkedHashSet<String> skills = new LinkedHashSet<>();
        LinkedHashSet<String> mcp = new LinkedHashSet<>();
        Map<String,Integer> extCounts = new HashMap<>();
        final int[] visited = {0};
        try {
            Files.walkFileTree(root, EnumSet.noneOf(FileVisitOption.class), 8, new SimpleFileVisitor<>() {
                @Override public FileVisitResult preVisitDirectory(Path dir, BasicFileAttributes attrs) {
                    if (!dir.equals(root)) {
                        String name = dir.getFileName().toString().toLowerCase(Locale.ROOT);
                        if (SKIP_DIRS.contains(name)) return FileVisitResult.SKIP_SUBTREE;
                    }
                    return visited[0] > 12_000 ? FileVisitResult.TERMINATE : FileVisitResult.CONTINUE;
                }
                @Override public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) {
                    if (++visited[0] > 12_000) return FileVisitResult.TERMINATE;
                    String rel = root.relativize(file).toString().replace('\\','/');
                    String low = rel.toLowerCase(Locale.ROOT);
                    String name = file.getFileName().toString().toLowerCase(Locale.ROOT);
                    if (isDescriptor(name, low)) descriptors.add(rel);
                    if (name.equals("agents.md") || name.equals("claude.md") || low.endsWith("/.github/copilot-instructions.md") || low.endsWith("/.opencode/instructions.md")) instructions.add(rel);
                    if (name.equals("skill.md") && (low.contains("/.agents/skills/") || low.startsWith(".agents/skills/") || low.contains("/.opencode/skills/") || low.startsWith(".opencode/skills/") || low.contains("/.claude/skills/") || low.startsWith(".claude/skills/"))) skills.add(rel);
                    if (low.equals(".agents/mcp.json") || low.equals(".opencode/mcp.json")) mcp.add(rel);
                    int dot = name.lastIndexOf('.');
                    if (dot > 0) extCounts.merge(name.substring(dot+1), 1, Integer::sum);
                    return FileVisitResult.CONTINUE;
                }
            });
        } catch (IOException ignored) { }

        for (String d : descriptors) technologyFor(d).ifPresent(technologies::add);
        extCounts.entrySet().stream().sorted(Map.Entry.<String,Integer>comparingByValue().reversed()).limit(12)
                .map(Map.Entry::getKey).map(this::languageForExtension).filter(Objects::nonNull).forEach(languages::add);
        return new WorkspaceProfile(root.toString(), List.copyOf(technologies), List.copyOf(descriptors), List.copyOf(languages),
                List.copyOf(instructions), List.copyOf(skills), List.copyOf(mcp), visited[0], Instant.now().toString());
    }

    private boolean isDescriptor(String name, String rel) {
        return Set.of("pom.xml","build.gradle","build.gradle.kts","settings.gradle","settings.gradle.kts","package.json","pyproject.toml","requirements.txt","setup.py",
                "go.mod","cargo.toml","composer.json","gemfile","package.swift","pubspec.yaml","build.sbt","mix.exs","project.clj","build.zig","stack.yaml","cabal.project",
                "dockerfile","compose.yml","compose.yaml","makefile","cmakelists.txt","build.xml","workspace","workspace.bazel","module.bazel","jenkinsfile").contains(name)
                || name.endsWith(".sln") || name.endsWith(".csproj") || name.endsWith(".fsproj") || rel.endsWith(".tf");
    }

    private Optional<String> technologyFor(String rel) {
        String n = Path.of(rel).getFileName().toString().toLowerCase(Locale.ROOT);
        if (n.equals("pom.xml")) return Optional.of("Maven/JVM");
        if (n.startsWith("build.gradle") || n.startsWith("settings.gradle")) return Optional.of("Gradle/JVM");
        if (n.equals("package.json")) return Optional.of("Node/JavaScript/TypeScript");
        if (Set.of("pyproject.toml","requirements.txt","setup.py").contains(n)) return Optional.of("Python");
        if (n.equals("go.mod")) return Optional.of("Go");
        if (n.equals("cargo.toml")) return Optional.of("Rust/Cargo");
        if (n.endsWith(".sln") || n.endsWith(".csproj") || n.endsWith(".fsproj")) return Optional.of(".NET");
        if (n.equals("pubspec.yaml")) return Optional.of("Dart/Flutter");
        if (n.equals("package.swift")) return Optional.of("Swift");
        if (n.equals("composer.json")) return Optional.of("PHP/Composer");
        if (n.equals("gemfile")) return Optional.of("Ruby/Bundler");
        if (n.equals("build.sbt")) return Optional.of("Scala/sbt");
        if (n.equals("mix.exs")) return Optional.of("Elixir/Mix");
        if (n.equals("project.clj")) return Optional.of("Clojure");
        if (n.equals("dockerfile") || n.startsWith("compose.")) return Optional.of("Containers");
        if (rel.toLowerCase(Locale.ROOT).endsWith(".tf")) return Optional.of("Terraform/OpenTofu");
        return Optional.empty();
    }

    private String languageForExtension(String ext) {
        return switch (ext.toLowerCase(Locale.ROOT)) {
            case "java" -> "Java"; case "kt","kts" -> "Kotlin"; case "groovy" -> "Groovy";
            case "js","jsx","mjs","cjs" -> "JavaScript"; case "ts","tsx" -> "TypeScript";
            case "py" -> "Python"; case "go" -> "Go"; case "rs" -> "Rust"; case "rb" -> "Ruby";
            case "php" -> "PHP"; case "cs" -> "C#"; case "fs","fsx" -> "F#"; case "swift" -> "Swift";
            case "dart" -> "Dart"; case "c","h" -> "C"; case "cc","cpp","cxx","hpp" -> "C++";
            case "scala" -> "Scala"; case "ex","exs" -> "Elixir"; case "clj","cljs" -> "Clojure";
            case "tf","hcl" -> "HCL/Terraform"; case "sql" -> "SQL"; case "sh","bash","zsh" -> "Shell";
            case "ps1" -> "PowerShell"; default -> null;
        };
    }

    private WorkspaceProfile readDisk(String id) {
        try {
            Path file = cacheRoot.resolve(id + ".json").normalize();
            if (!file.startsWith(cacheRoot) || !Files.isRegularFile(file)) return null;
            return mapper.readValue(Files.readString(file, StandardCharsets.UTF_8), WorkspaceProfile.class);
        } catch (Exception ignored) { return null; }
    }

    private void writeDisk(String id, WorkspaceProfile profile) {
        try {
            Files.createDirectories(cacheRoot);
            Path file = cacheRoot.resolve(id + ".json").normalize();
            if (!file.startsWith(cacheRoot)) return;
            Files.writeString(file, mapper.writerWithDefaultPrettyPrinter().writeValueAsString(profile), StandardCharsets.UTF_8,
                    StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
        } catch (Exception ignored) { }
    }

    public record WorkspaceProfile(String root, List<String> detectedTechnologies, List<String> descriptors,
                                   List<String> languages, List<String> instructionFiles, List<String> skillFiles,
                                   List<String> mcpConfigFiles, int sampledFiles, String generatedAt) { }
}
