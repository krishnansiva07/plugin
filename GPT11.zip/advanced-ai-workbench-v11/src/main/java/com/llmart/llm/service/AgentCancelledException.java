package com.llmart.llm.service;

public class AgentCancelledException extends RuntimeException {
    public AgentCancelledException(String message) {
        super(message);
    }
}
