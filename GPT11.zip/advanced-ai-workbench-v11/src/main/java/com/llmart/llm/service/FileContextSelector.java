package com.llmart.llm.service;

import com.llmart.llm.entity.FileEntity;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.regex.Pattern;

@Service
public class FileContextSelector {
    private static final Pattern WORD = Pattern.compile("[^a-zA-Z0-9_]+");
    private static final Set<String> STOP_WORDS = Set.of(
            "the", "and", "for", "that", "this", "with", "from", "have", "what", "when", "where",
            "which", "will", "would", "could", "should", "into", "about", "your", "you", "are", "was",
            "were", "how", "can", "use", "using", "file", "files"
    );

    public String select(String query, List<FileEntity> files, int maxChars) {
        if (files == null || files.isEmpty() || maxChars <= 0) return "";
        Set<String> terms = terms(query);
        List<Chunk> chunks = new ArrayList<>();

        for (FileEntity file : files) {
            String text = file.getExtractedText();
            if (text == null || text.isBlank()) continue;
            int ordinal = 0;
            for (String part : chunk(text, 2600, 260)) {
                double score = score(part, file.getOriginalName(), terms) - (ordinal * 0.0001);
                chunks.add(new Chunk(file.getOriginalName(), part, score));
                ordinal++;
            }
        }

        chunks.sort(Comparator.comparingDouble(Chunk::score).reversed());
        StringBuilder out = new StringBuilder();
        Map<String, Integer> perFile = new HashMap<>();

        for (Chunk chunk : chunks) {
            // Avoid spending the entire context budget on one large document when several were attached.
            if (perFile.getOrDefault(chunk.fileName(), 0) >= 4 && files.size() > 1) continue;

            String header = "\n--- Uploaded file excerpt: " + chunk.fileName() + " ---\n";
            int remaining = maxChars - out.length();
            if (remaining <= header.length() + 20) break;

            out.append(header);
            remaining = maxChars - out.length();
            String text = chunk.text();
            if (text.length() > remaining) {
                out.append(text, 0, Math.max(0, remaining));
                break;
            }
            out.append(text).append('\n');
            perFile.merge(chunk.fileName(), 1, Integer::sum);
            if (out.length() >= maxChars) break;
        }
        return out.toString();
    }

    private Set<String> terms(String query) {
        Set<String> result = new LinkedHashSet<>();
        if (query == null) return result;
        for (String word : WORD.split(query.toLowerCase(Locale.ROOT))) {
            if (word.length() > 2 && !STOP_WORDS.contains(word)) result.add(word);
        }
        return result;
    }

    private double score(String text, String fileName, Set<String> terms) {
        if (terms.isEmpty()) return 0.1;
        String low = text.toLowerCase(Locale.ROOT);
        String fileLow = fileName == null ? "" : fileName.toLowerCase(Locale.ROOT);
        double score = 0;
        for (String term : terms) {
            if (fileLow.contains(term)) score += 3.0;
            int index = 0;
            int count = 0;
            while ((index = low.indexOf(term, index)) >= 0 && count < 10) {
                count++;
                index += term.length();
            }
            score += count;
        }
        return score;
    }

    private List<String> chunk(String text, int size, int overlap) {
        List<String> result = new ArrayList<>();
        int start = 0;
        while (start < text.length()) {
            int end = Math.min(text.length(), start + size);
            // Prefer ending at a paragraph/newline boundary when one exists near the chunk end.
            if (end < text.length()) {
                int boundary = text.lastIndexOf('\n', end);
                if (boundary > start + (size / 2)) end = boundary + 1;
            }
            result.add(text.substring(start, end));
            if (end >= text.length()) break;
            start = Math.max(start + 1, end - overlap);
        }
        return result;
    }

    private record Chunk(String fileName, String text, double score) {}
}
