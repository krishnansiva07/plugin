package com.llmart.llm.repository;

import com.llmart.llm.entity.ProjectWorkspaceEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;

public interface ProjectWorkspaceRepository extends JpaRepository<ProjectWorkspaceEntity, String> {
    List<ProjectWorkspaceEntity> findByConversationIdOrderByUpdatedAtDesc(String conversationId);
    Optional<ProjectWorkspaceEntity> findFirstByLocalPath(String localPath);
}
