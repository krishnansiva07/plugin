package com.llmart.llm.service;

import java.util.List;

public class PatchConflictException extends RuntimeException {
    private final List<String> conflicts;

    public PatchConflictException(List<String> conflicts) {
        super("Workspace changed after the agent started: " + String.join(", ", conflicts));
        this.conflicts = List.copyOf(conflicts);
    }

    public List<String> conflicts() {
        return conflicts;
    }
}
