package com.llmart.llm.dto;

public record FileDto(
        String id,
        String name,
        String mimeType,
        long size,
        int extractedCharacters,
        String extractionStatus,
        String extractionMessage
) {}
