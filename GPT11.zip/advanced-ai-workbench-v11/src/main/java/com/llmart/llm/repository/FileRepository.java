package com.llmart.llm.repository;

import com.llmart.llm.entity.FileEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface FileRepository extends JpaRepository<FileEntity, String> {
    List<FileEntity> findByConversationId(String conversationId);
    void deleteByConversationId(String conversationId);
}
