package com.llmart.llm.dto;

public record ProjectFileUpload(String relativePath, String mimeType, Long size, String content) {}
