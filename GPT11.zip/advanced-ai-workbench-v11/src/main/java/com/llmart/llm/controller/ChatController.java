package com.llmart.llm.controller;

import com.llmart.llm.dto.ChatRequest;
import com.llmart.llm.service.ChatService;
import jakarta.validation.Valid;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

@RestController
@RequestMapping("/api/chat")
public class ChatController {
    private final ChatService chatService;

    public ChatController(ChatService chatService) { this.chatService = chatService; }

    @PostMapping(value = "/stream", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
    public SseEmitter stream(@RequestHeader(value = "Authorization", required = false) String authorization,
                             @Valid @RequestBody ChatRequest request) {
        String key = authorization != null && authorization.startsWith("Bearer ") ? authorization.substring(7) : null;
        return chatService.stream(key, request);
    }
}
