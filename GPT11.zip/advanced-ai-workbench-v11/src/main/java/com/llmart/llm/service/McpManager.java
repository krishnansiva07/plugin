package com.llmart.llm.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import jakarta.annotation.PreDestroy;
import org.springframework.stereotype.Service;

import java.io.*;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.time.Duration;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Generic Model Context Protocol client/registry.  The agent core does not know Playwright,
 * Vibium, databases, browsers, or any other MCP-specific semantics.  Enabled servers describe
 * their tools through tools/list and those schemas are surfaced to the model dynamically.
 *
 * Supported transports:
 *  - stdio (the common local MCP transport used by Playwright/Vibium and many developer servers)
 *  - Streamable HTTP for ordinary JSON or SSE responses
 *
 * Configuration is merged from ~/.agents/mcp.json and <workspace>/.agents/mcp.json.
 */
@Service
public class McpManager {
    private static final String PROTOCOL_VERSION = "2025-06-18";
    private final ObjectMapper mapper;
    private final HttpClient http;
    private final Map<String, McpSession> sessions = new ConcurrentHashMap<>();

    public McpManager(ObjectMapper mapper, HttpClient http) {
        this.mapper = mapper;
        this.http = http;
    }

    public Catalog catalog(Path workspaceRoot) {
        LinkedHashMap<String, ServerConfig> configs = discoverConfigs(workspaceRoot);
        List<Map<String,Object>> definitions = new ArrayList<>();
        Map<String, ToolRef> byFunction = new LinkedHashMap<>();
        List<String> diagnostics = new ArrayList<>();
        for (ServerConfig cfg : configs.values()) {
            if (!cfg.enabled()) continue;
            try {
                McpSession session = sessions.computeIfAbsent(sessionKey(workspaceRoot, cfg), k -> createSession(workspaceRoot, cfg));
                List<McpTool> tools = session.listTools();
                for (McpTool tool : tools) {
                    String function = uniqueFunctionName(cfg.name(), tool.name(), byFunction.keySet());
                    Map<String,Object> schema = normalizeSchema(tool.inputSchema());
                    String description = "MCP " + cfg.name() + " / " + tool.name() + ": " +
                            (tool.description() == null || tool.description().isBlank() ? "External MCP tool" : tool.description());
                    definitions.add(Map.of("type", "function", "function", Map.of(
                            "name", function,
                            "description", description,
                            "parameters", schema
                    )));
                    byFunction.put(function, new ToolRef(cfg.name(), tool.name(), tool.readOnlyHint()));
                }
                diagnostics.add(cfg.name() + ": connected; tools=" + tools.size());
            } catch (Exception e) {
                diagnostics.add(cfg.name() + ": unavailable: " + safe(e.getMessage()));
            }
        }
        return new Catalog(List.copyOf(definitions), Map.copyOf(byFunction), List.copyOf(diagnostics));
    }

    public String call(Path workspaceRoot, Catalog catalog, String functionName, JsonNode arguments) throws Exception {
        ToolRef ref = catalog.byFunction().get(functionName);
        if (ref == null) throw new IllegalArgumentException("Unknown MCP tool: " + functionName);
        ServerConfig cfg = discoverConfigs(workspaceRoot).get(ref.server());
        if (cfg == null || !cfg.enabled()) throw new IllegalStateException("MCP server is no longer enabled: " + ref.server());
        McpSession session = sessions.computeIfAbsent(sessionKey(workspaceRoot, cfg), k -> createSession(workspaceRoot, cfg));
        JsonNode result = session.callTool(ref.tool(), arguments == null || !arguments.isObject() ? mapper.createObjectNode() : arguments);
        return renderToolResult(ref, result);
    }

    public String status(Path workspaceRoot) {
        Catalog catalog = catalog(workspaceRoot);
        if (catalog.diagnostics().isEmpty()) return "[No MCP servers configured]";
        StringBuilder out = new StringBuilder(String.join("\n", catalog.diagnostics()));
        if (!catalog.definitions().isEmpty()) {
            out.append("\nAvailable MCP functions:");
            for (Map<String,Object> def : catalog.definitions()) {
                Object f = def.get("function");
                if (f instanceof Map<?,?> fn) {
                    out.append("\n- ").append(fn.get("name")).append(": ").append(fn.get("description"));
                    Object params = fn.get("parameters");
                    if (params != null) out.append("; parameters=").append(params);
                }
            }
        }
        return out.toString();
    }

    public boolean isMcpTool(Catalog catalog, String name) {
        return catalog != null && catalog.byFunction().containsKey(name);
    }

    public boolean isReadOnly(Catalog catalog, String name) {
        ToolRef ref = catalog == null ? null : catalog.byFunction().get(name);
        return ref != null && ref.readOnlyHint();
    }

    public List<String> configuredServerNames(Path workspaceRoot) {
        return discoverConfigs(workspaceRoot).values().stream().filter(ServerConfig::enabled).map(ServerConfig::name).toList();
    }

    @PreDestroy
    public void shutdown() {
        for (McpSession session : sessions.values()) {
            try { session.close(); } catch (Exception ignored) { }
        }
        sessions.clear();
    }

    private McpSession createSession(Path root, ServerConfig cfg) {
        try {
            return switch (cfg.type()) {
                case "http", "streamable-http", "streamable_http" -> new HttpMcpSession(cfg);
                default -> new StdioMcpSession(root, cfg);
            };
        } catch (Exception e) {
            throw new IllegalStateException("Unable to start MCP server " + cfg.name() + ": " + safe(e.getMessage()), e);
        }
    }

    private LinkedHashMap<String, ServerConfig> discoverConfigs(Path workspaceRoot) {
        LinkedHashMap<String, ServerConfig> merged = new LinkedHashMap<>();
        Path home = Path.of(System.getProperty("user.home", ".")).toAbsolutePath().normalize();
        for (Path file : List.of(home.resolve(".agents/mcp.json"), workspaceRoot.resolve(".agents/mcp.json"), workspaceRoot.resolve(".opencode/mcp.json"))) {
            if (!Files.isRegularFile(file) || Files.isSymbolicLink(file)) continue;
            try {
                JsonNode root = mapper.readTree(Files.readString(file, StandardCharsets.UTF_8));
                JsonNode servers = root.path("servers");
                if (!servers.isObject()) servers = root.path("mcp");
                if (!servers.isObject()) continue;
                Iterator<Map.Entry<String,JsonNode>> fields = servers.fields();
                while (fields.hasNext()) {
                    Map.Entry<String,JsonNode> entry = fields.next();
                    ServerConfig cfg = parseConfig(entry.getKey(), entry.getValue());
                    if (cfg != null) merged.put(cfg.name(), cfg);
                }
            } catch (Exception ignored) { }
        }
        return merged;
    }

    private ServerConfig parseConfig(String rawName, JsonNode node) {
        String name = sanitizeId(rawName);
        if (name.isBlank() || node == null || !node.isObject()) return null;
        boolean enabled = !node.has("enabled") || node.path("enabled").asBoolean(true);
        String type = node.path("type").asText("stdio").trim().toLowerCase(Locale.ROOT);
        if ("local".equals(type)) type = "stdio";
        if ("remote".equals(type)) type = "http";
        String command = node.path("command").isTextual() ? node.path("command").asText("") : "";
        List<String> args = new ArrayList<>();
        if (node.path("command").isArray()) {
            JsonNode arr = node.path("command");
            if (!arr.isEmpty()) command = arr.get(0).asText("");
            for (int i=1;i<arr.size();i++) args.add(arr.get(i).asText(""));
        }
        if (node.path("args").isArray()) for (JsonNode a : node.path("args")) args.add(a.asText(""));
        Map<String,String> env = new LinkedHashMap<>();
        if (node.path("env").isObject()) node.path("env").fields().forEachRemaining(e -> env.put(e.getKey(), e.getValue().asText("")));
        String url = node.path("url").asText("").trim();
        String cwd = node.path("cwd").asText("").trim();
        long timeoutSeconds = Math.max(0, node.path("timeoutSeconds").asLong(0));
        return new ServerConfig(name, enabled, type, command, List.copyOf(args), Map.copyOf(env), url, cwd, timeoutSeconds);
    }

    private Map<String,Object> normalizeSchema(JsonNode inputSchema) {
        try {
            JsonNode schema = inputSchema == null || !inputSchema.isObject() ? mapper.readTree("{\"type\":\"object\",\"properties\":{}}") : inputSchema;
            @SuppressWarnings("unchecked") Map<String,Object> map = mapper.convertValue(schema, Map.class);
            LinkedHashMap<String,Object> result = new LinkedHashMap<>(map == null ? Map.of() : map);
            result.putIfAbsent("type", "object");
            result.putIfAbsent("properties", Map.of());
            return result;
        } catch (Exception e) {
            return Map.of("type","object","properties",Map.of());
        }
    }

    private String renderToolResult(ToolRef ref, JsonNode response) {
        if (response == null || response.isNull()) return "MCP " + ref.server() + "/" + ref.tool() + " returned no content";
        JsonNode result = response.path("result");
        if (response.has("error")) return "MCP PROTOCOL ERROR " + ref.server() + "/" + ref.tool() + ": " + response.path("error").toString();
        boolean isError = result.path("isError").asBoolean(false);
        StringBuilder out = new StringBuilder();
        out.append("mcpServer=").append(ref.server()).append("; tool=").append(ref.tool()).append("; isError=").append(isError).append('\n');
        JsonNode content = result.path("content");
        if (content.isArray()) {
            for (JsonNode item : content) {
                String type = item.path("type").asText("");
                if ("text".equals(type)) out.append(item.path("text").asText("")).append('\n');
                else out.append(item.toString()).append('\n');
            }
        }
        if (result.has("structuredContent")) out.append("structuredContent=").append(result.path("structuredContent")).append('\n');
        if (out.toString().trim().equals("mcpServer=" + ref.server() + "; tool=" + ref.tool() + "; isError=" + isError)) out.append(result.toString());
        return out.toString().stripTrailing();
    }

    private String sessionKey(Path root, ServerConfig cfg) {
        return root.toAbsolutePath().normalize() + "|" + cfg.name() + "|" + cfg.type() + "|" + cfg.command() + "|" + cfg.url();
    }

    private String uniqueFunctionName(String server, String tool, Set<String> used) {
        String base = "mcp__" + sanitizeFunction(server) + "__" + sanitizeFunction(tool);
        if (base.length() > 60) base = base.substring(0, 48) + "__" + Integer.toHexString(base.hashCode());
        String value = base;
        int i = 2;
        while (used.contains(value)) value = (base.length() > 56 ? base.substring(0,56) : base) + "_" + i++;
        return value;
    }

    private String sanitizeFunction(String value) {
        String s = value == null ? "tool" : value.replaceAll("[^A-Za-z0-9_-]", "_");
        return s.isBlank() ? "tool" : s;
    }

    private String sanitizeId(String value) {
        String s = value == null ? "" : value.trim().replaceAll("[^A-Za-z0-9._-]", "_");
        return s.length() > 100 ? s.substring(0,100) : s;
    }

    private String safe(String value) {
        if (value == null || value.isBlank()) return "unknown error";
        String s = value.replace('\n',' ').replace('\r',' ').replaceAll("\\s+", " ").trim();
        return s.length() > 800 ? s.substring(0,800) : s;
    }

    public record Catalog(List<Map<String,Object>> definitions, Map<String,ToolRef> byFunction, List<String> diagnostics) {
        public static Catalog empty() { return new Catalog(List.of(), Map.of(), List.of()); }
    }
    public record ToolRef(String server, String tool, boolean readOnlyHint) {}
    private record McpTool(String name, String description, JsonNode inputSchema, boolean readOnlyHint) {}
    private record ServerConfig(String name, boolean enabled, String type, String command, List<String> args,
                                Map<String,String> env, String url, String cwd, long timeoutSeconds) {}

    private interface McpSession extends AutoCloseable {
        List<McpTool> listTools() throws Exception;
        JsonNode callTool(String name, JsonNode arguments) throws Exception;
        @Override void close();
    }

    private final class StdioMcpSession implements McpSession {
        private final ServerConfig cfg;
        private final Process process;
        private final BufferedWriter stdin;
        private final AtomicLong ids = new AtomicLong(1);
        private final Map<Long, CompletableFuture<JsonNode>> pending = new ConcurrentHashMap<>();
        private volatile List<McpTool> cachedTools;

        StdioMcpSession(Path workspaceRoot, ServerConfig cfg) throws Exception {
            this.cfg = cfg;
            if (cfg.command() == null || cfg.command().isBlank()) throw new IllegalArgumentException("stdio MCP command is required");
            List<String> command = new ArrayList<>(); command.add(cfg.command()); command.addAll(cfg.args());
            ProcessBuilder pb = new ProcessBuilder(command);
            Path cwd = cfg.cwd().isBlank() ? workspaceRoot : workspaceRoot.resolve(cfg.cwd()).normalize();
            if (!cwd.startsWith(workspaceRoot) || !Files.isDirectory(cwd)) throw new SecurityException("Invalid MCP cwd: " + cfg.cwd());
            pb.directory(cwd.toFile());
            pb.environment().putAll(cfg.env());
            process = pb.start();
            stdin = new BufferedWriter(new OutputStreamWriter(process.getOutputStream(), StandardCharsets.UTF_8));
            Thread stdoutThread = new Thread(() -> readStdout(process.getInputStream()), "mcp-stdout-" + cfg.name());
            stdoutThread.setDaemon(true);
            stdoutThread.start();
            Thread stderrThread = new Thread(() -> drain(process.getErrorStream()), "mcp-stderr-" + cfg.name());
            stderrThread.setDaemon(true);
            stderrThread.start();
            initialize();
        }

        private void initialize() throws Exception {
            ObjectNode params = mapper.createObjectNode();
            params.put("protocolVersion", PROTOCOL_VERSION);
            params.set("capabilities", mapper.createObjectNode());
            params.set("clientInfo", mapper.valueToTree(Map.of("name","advanced-ai-workbench-v11","version","3.0.0")));
            request("initialize", params);
            notify("notifications/initialized", mapper.createObjectNode());
        }

        @Override public List<McpTool> listTools() throws Exception {
            if (cachedTools != null) return cachedTools;
            List<McpTool> all = new ArrayList<>();
            String cursor = null;
            do {
                ObjectNode params = mapper.createObjectNode(); if (cursor != null) params.put("cursor", cursor);
                JsonNode response = request("tools/list", params);
                JsonNode result = response.path("result");
                for (JsonNode t : result.path("tools")) all.add(parseTool(t));
                cursor = result.path("nextCursor").asText("").trim(); if (cursor.isBlank()) cursor = null;
            } while (cursor != null);
            cachedTools = List.copyOf(all);
            return cachedTools;
        }

        @Override public JsonNode callTool(String name, JsonNode arguments) throws Exception {
            ObjectNode params = mapper.createObjectNode(); params.put("name", name); params.set("arguments", arguments);
            return request("tools/call", params);
        }

        private JsonNode request(String method, JsonNode params) throws Exception {
            if (!process.isAlive()) throw new IllegalStateException("MCP process exited with code " + process.exitValue());
            long id = ids.getAndIncrement();
            CompletableFuture<JsonNode> future = new CompletableFuture<>(); pending.put(id, future);
            ObjectNode msg = mapper.createObjectNode(); msg.put("jsonrpc","2.0"); msg.put("id",id); msg.put("method",method); msg.set("params",params);
            send(msg);
            try {
                if (cfg.timeoutSeconds() > 0) return future.get(cfg.timeoutSeconds(), TimeUnit.SECONDS);
                while (true) {
                    if (!process.isAlive()) throw new IllegalStateException("MCP process exited with code " + process.exitValue());
                    try { return future.get(250, TimeUnit.MILLISECONDS); } catch (TimeoutException ignored) { }
                }
            } finally { pending.remove(id); }
        }

        private void notify(String method, JsonNode params) throws Exception {
            ObjectNode msg = mapper.createObjectNode(); msg.put("jsonrpc","2.0"); msg.put("method",method); msg.set("params",params); send(msg);
        }

        private synchronized void send(JsonNode node) throws Exception { stdin.write(mapper.writeValueAsString(node)); stdin.newLine(); stdin.flush(); }

        private void readStdout(InputStream in) {
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    try {
                        JsonNode json = mapper.readTree(line);
                        if (json.has("id")) {
                            long id = json.path("id").asLong(Long.MIN_VALUE);
                            CompletableFuture<JsonNode> future = pending.get(id);
                            if (future != null) future.complete(json);
                        } else if ("notifications/tools/list_changed".equals(json.path("method").asText(""))) {
                            cachedTools = null;
                        }
                    } catch (Exception ignored) { }
                }
            } catch (Exception ignored) { }
            IllegalStateException failure = new IllegalStateException("MCP server stopped: " + cfg.name());
            pending.values().forEach(f -> f.completeExceptionally(failure));
        }

        private void drain(InputStream in) { try { in.transferTo(OutputStream.nullOutputStream()); } catch (Exception ignored) { } }

        @Override public void close() {
            try { stdin.close(); } catch (Exception ignored) { }
            if (process.isAlive()) { process.destroy(); if (process.isAlive()) process.destroyForcibly(); }
        }
    }

    private final class HttpMcpSession implements McpSession {
        private final ServerConfig cfg;
        private String sessionId;
        private volatile List<McpTool> cachedTools;
        private final AtomicLong ids = new AtomicLong(1);
        HttpMcpSession(ServerConfig cfg) throws Exception {
            this.cfg = cfg;
            if (cfg.url() == null || cfg.url().isBlank()) throw new IllegalArgumentException("HTTP MCP url is required");
            ObjectNode params = mapper.createObjectNode(); params.put("protocolVersion", PROTOCOL_VERSION);
            params.set("capabilities", mapper.createObjectNode());
            params.set("clientInfo", mapper.valueToTree(Map.of("name","advanced-ai-workbench-v11","version","3.0.0")));
            post(requestNode("initialize", params, ids.getAndIncrement()), "initialize");
            post(notificationNode("notifications/initialized", mapper.createObjectNode()), "notifications/initialized");
        }
        @Override public List<McpTool> listTools() throws Exception {
            if (cachedTools != null) return cachedTools;
            List<McpTool> all = new ArrayList<>(); String cursor = null;
            do {
                ObjectNode p = mapper.createObjectNode(); if (cursor != null) p.put("cursor", cursor);
                JsonNode response = post(requestNode("tools/list", p, ids.getAndIncrement()), "tools/list");
                JsonNode result = response.path("result");
                for (JsonNode t : result.path("tools")) all.add(parseTool(t));
                cursor = result.path("nextCursor").asText("").trim(); if (cursor.isBlank()) cursor = null;
            } while (cursor != null);
            cachedTools = List.copyOf(all); return cachedTools;
        }
        @Override public JsonNode callTool(String name, JsonNode arguments) throws Exception {
            ObjectNode p = mapper.createObjectNode(); p.put("name",name); p.set("arguments",arguments);
            return post(requestNode("tools/call",p,ids.getAndIncrement()), "tools/call");
        }
        private JsonNode post(JsonNode body, String method) throws Exception {
            HttpRequest.Builder b = HttpRequest.newBuilder(URI.create(cfg.url())).header("Content-Type","application/json").header("Accept","application/json, text/event-stream").header("MCP-Protocol-Version",PROTOCOL_VERSION).header("Mcp-Method", method);
            if (sessionId != null && !sessionId.isBlank()) b.header("Mcp-Session-Id", sessionId);
            if (cfg.timeoutSeconds() > 0) b.timeout(Duration.ofSeconds(cfg.timeoutSeconds()));
            HttpResponse<String> response = http.send(b.POST(HttpRequest.BodyPublishers.ofString(mapper.writeValueAsString(body))).build(), HttpResponse.BodyHandlers.ofString());
            response.headers().firstValue("Mcp-Session-Id").ifPresent(v -> sessionId = v);
            if (response.statusCode() == 202 || response.statusCode() == 204) return mapper.createObjectNode();
            if (response.statusCode() < 200 || response.statusCode() >= 300) throw new IllegalStateException("HTTP MCP " + response.statusCode() + ": " + response.body());
            String text = response.body() == null ? "" : response.body().trim();
            if (text.startsWith("data:" ) || text.contains("\ndata:")) {
                for (String line : text.split("\\R")) if (line.startsWith("data:")) { String data=line.substring(5).trim(); if (!data.isBlank()) return mapper.readTree(data); }
            }
            return text.isBlank() ? mapper.createObjectNode() : mapper.readTree(text);
        }
        @Override public void close() { }
    }

    private McpTool parseTool(JsonNode t) {
        String name = t.path("name").asText("").trim();
        String description = t.path("description").asText("");
        JsonNode schema = t.path("inputSchema");
        boolean readOnly = t.path("annotations").path("readOnlyHint").asBoolean(false);
        return new McpTool(name, description, schema, readOnly);
    }

    private ObjectNode requestNode(String method, JsonNode params, long id) {
        ObjectNode n=mapper.createObjectNode(); n.put("jsonrpc","2.0"); n.put("id",id); n.put("method",method); n.set("params",params); return n;
    }
    private ObjectNode notificationNode(String method, JsonNode params) {
        ObjectNode n=mapper.createObjectNode(); n.put("jsonrpc","2.0"); n.put("method",method); n.set("params",params); return n;
    }
}
