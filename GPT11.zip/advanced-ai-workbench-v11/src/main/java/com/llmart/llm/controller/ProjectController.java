package com.llmart.llm.controller;

import com.llmart.llm.dto.*;
import com.llmart.llm.service.ProjectService;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/projects")
public class ProjectController {
    private final ProjectService service;
    public ProjectController(ProjectService service) { this.service = service; }

    @PostMapping public ProjectDto create(@RequestBody Map<String, String> body) { return service.create(body.get("conversationId"), body.get("name")); }

    @PostMapping("/local")
    public ProjectDto createLocal(@RequestBody Map<String,String> body) {
        return service.createLocal(body.get("conversationId"), body.get("path"), body.get("name"));
    }

    @PostMapping("/{id}/rescan-local") public ProjectDto rescanLocal(@PathVariable String id) { return service.rescanLocal(id); }

    @PostMapping("/{id}/apply")
    public Map<String,Object> apply(@PathVariable String id, @RequestBody ProjectPatchRequest request) throws IOException {
        return service.applyLocalPatch(id, request);
    }

    @GetMapping public List<ProjectDto> list(@RequestParam String conversationId) { return service.listForConversation(conversationId); }
    @GetMapping("/{id}") public ProjectDto get(@PathVariable String id) { return service.get(id); }
    @PostMapping("/{id}/files/batch") public ProjectDto uploadBatch(@PathVariable String id, @RequestBody ProjectUploadBatch batch) { return service.upsertFiles(id, batch); }
    @DeleteMapping("/{id}/file") public ProjectDto removeFile(@PathVariable String id, @RequestParam String path) { return service.removeIndexedFile(id, path); }
    @DeleteMapping("/{id}/files") public ProjectDto clearFiles(@PathVariable String id) { return service.clearFiles(id); }
    @DeleteMapping("/{id}") public void delete(@PathVariable String id) { service.delete(id); }
}
