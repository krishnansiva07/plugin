package com.llmart.llm.dto;

import com.fasterxml.jackson.annotation.JsonAlias;

import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.Locale;
import java.util.Set;
import java.util.stream.Collectors;

public record ChatSettings(
        String baseUrl,
        String model,
        String visionModel,
        Double temperature,
        Integer maxTokens,
        Integer contextChars,
        String systemPrompt,
        Boolean useFileContext,
        Integer agentMaxSteps,
        Boolean agentAllowCommands,
        String agentEditPermission,
        String agentShellPermission,
        @JsonAlias("agentGitPermission") String agentReviewPermission,
        Boolean agentAutoApprove,
        String agentExtraCommands,
        String agentMcpPermission,
        String agentTaskPermission,
        String agentLspPermission,
        Boolean agentParallelReadTools
) {
    public double safeTemperature() { return temperature == null ? 0.7 : Math.max(0.0, Math.min(2.0, temperature)); }
    /**
     * 0 means provider-managed maximum. Positive values are passed through without an application-side cap.
     */
    public int safeMaxTokens() { return maxTokens == null || maxTokens <= 0 ? 0 : maxTokens; }
    /**
     * 0 means use the full provider context and compact only after the provider reports context overflow.
     */
    public int safeContextChars() { return contextChars == null || contextChars <= 0 ? 0 : contextChars; }
    public boolean fileContextEnabled() { return useFileContext == null || useFileContext; }
    public boolean hasDedicatedVisionModel() { return visionModel != null && !visionModel.isBlank(); }
    /**
     * Kept only for backward-compatible JSON/settings loading. Agent runs no longer use a fixed step ceiling.
     */
    public int safeAgentMaxSteps() { return 0; }
    public boolean agentCommandsAllowed() { return agentAllowCommands == null || Boolean.TRUE.equals(agentAllowCommands); }
    public String editPermission() { return normalizePermission(agentEditPermission, "allow"); }
    public String shellPermission() {
        if (!agentCommandsAllowed()) return "deny";
        return normalizePermission(agentShellPermission, "allow");
    }
    public String reviewPermission() { return normalizePermission(agentReviewPermission, "allow"); }
    public String mcpPermission() { return normalizePermission(agentMcpPermission, "allow"); }
    public String taskPermission() { return normalizePermission(agentTaskPermission, "allow"); }
    public String lspPermission() { return normalizePermission(agentLspPermission, "allow"); }
    public boolean parallelReadTools() { return agentParallelReadTools == null || Boolean.TRUE.equals(agentParallelReadTools); }
    public boolean autoApproveAgent() { return Boolean.TRUE.equals(agentAutoApprove); }

    public Set<String> extraAgentCommands() {
        if (agentExtraCommands == null || agentExtraCommands.isBlank()) return Set.of();
        LinkedHashSet<String> result = Arrays.stream(agentExtraCommands.split("[,\\n]"))
                .map(String::trim)
                .filter(s -> s.matches("[A-Za-z0-9._+-]{1,80}"))
                .map(s -> s.toLowerCase(Locale.ROOT))
                .collect(Collectors.toCollection(LinkedHashSet::new));
        return Set.copyOf(result);
    }

    private String normalizePermission(String value, String fallback) {
        if (value == null) return fallback;
        String p = value.trim().toLowerCase(Locale.ROOT);
        return (p.equals("allow") || p.equals("ask") || p.equals("deny")) ? p : fallback;
    }
}
