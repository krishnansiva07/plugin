package com.llmart.llm.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import jakarta.annotation.PreDestroy;
import org.springframework.stereotype.Service;

import java.io.*;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Generic Language Server Protocol client. Language servers are configured, not hard-coded.
 * The agent can therefore use JDT LS, pyright, typescript-language-server, rust-analyzer, etc.
 * through the same `lsp` tool when those servers are installed on the user's machine.
 */
@Service
public class LspManager {
    private final ObjectMapper mapper;
    private final Map<String,LspSession> sessions = new ConcurrentHashMap<>();

    public LspManager(ObjectMapper mapper) { this.mapper = mapper; }

    public String status(Path workspace) {
        Map<String,ServerConfig> configs = configs(workspace);
        if (configs.isEmpty()) return "[No LSP servers configured. Add .agents/lsp.json to enable semantic code intelligence.]";
        StringBuilder out=new StringBuilder();
        for(ServerConfig c:configs.values()) out.append(c.name()).append("; enabled=").append(c.enabled()).append("; extensions=").append(c.extensions()).append("; command=").append(c.command()).append('\n');
        return out.toString().stripTrailing();
    }

    public String call(Path workspace, String operation, String relativePath, int line, int character,
                       String query, String requestedServer) throws Exception {
        Map<String,ServerConfig> cfgs=configs(workspace);
        ServerConfig cfg=select(cfgs,relativePath,requestedServer);
        if(cfg==null) throw new IllegalArgumentException("No matching LSP server configured. "+status(workspace));
        LspSession session=sessions.computeIfAbsent(workspace.toAbsolutePath().normalize()+"|"+cfg.name(),k -> {
            try { return new LspSession(workspace,cfg); } catch(Exception e){ throw new CompletionException(e); }
        });
        String op=operation==null?"":operation.trim().toLowerCase(Locale.ROOT);
        return session.call(op,relativePath,line,character,query);
    }

    @PreDestroy public void shutdown(){ sessions.values().forEach(LspSession::close); sessions.clear(); }

    private Map<String,ServerConfig> configs(Path workspace){
        LinkedHashMap<String,ServerConfig> out=new LinkedHashMap<>();
        Path home=Path.of(System.getProperty("user.home",".")).toAbsolutePath().normalize();
        for(Path f:List.of(home.resolve(".agents/lsp.json"),workspace.resolve(".agents/lsp.json"))){
            if(!Files.isRegularFile(f)||Files.isSymbolicLink(f)) continue;
            try{
                JsonNode root=mapper.readTree(Files.readString(f,StandardCharsets.UTF_8)); JsonNode servers=root.path("servers"); if(!servers.isObject()) continue;
                servers.fields().forEachRemaining(e->{ ServerConfig c=parse(e.getKey(),e.getValue()); if(c!=null) out.put(c.name(),c); });
            }catch(Exception ignored){}
        }
        return Map.copyOf(out);
    }

    private ServerConfig parse(String rawName,JsonNode n){
        if(n==null||!n.isObject()) return null;
        String name=rawName.replaceAll("[^A-Za-z0-9._-]","_"); boolean enabled=!n.has("enabled")||n.path("enabled").asBoolean(true);
        String command=n.path("command").isTextual()?n.path("command").asText(""):""; List<String> args=new ArrayList<>();
        if(n.path("command").isArray()){ JsonNode a=n.path("command"); if(!a.isEmpty()) command=a.get(0).asText(""); for(int i=1;i<a.size();i++) args.add(a.get(i).asText("")); }
        if(n.path("args").isArray()) for(JsonNode a:n.path("args")) args.add(a.asText(""));
        LinkedHashSet<String> ext=new LinkedHashSet<>(); if(n.path("extensions").isArray()) for(JsonNode e:n.path("extensions")){String v=e.asText("").toLowerCase(Locale.ROOT).replaceFirst("^\\.",""); if(!v.isBlank()) ext.add(v);}
        String languageId=n.path("languageId").asText(""); String cwd=n.path("cwd").asText("");
        return new ServerConfig(name,enabled,command,List.copyOf(args),Set.copyOf(ext),languageId,cwd);
    }

    private ServerConfig select(Map<String,ServerConfig> configs,String path,String requested){
        if(requested!=null&&!requested.isBlank()){ ServerConfig c=configs.get(requested); return c!=null&&c.enabled()?c:null; }
        String ext=""; if(path!=null){String n=Path.of(path.replace('\\','/')).getFileName().toString(); int dot=n.lastIndexOf('.'); if(dot>=0)ext=n.substring(dot+1).toLowerCase(Locale.ROOT);}
        for(ServerConfig c:configs.values()) if(c.enabled()&&(c.extensions().isEmpty()||c.extensions().contains(ext))) return c;
        return null;
    }

    private record ServerConfig(String name,boolean enabled,String command,List<String> args,Set<String> extensions,String languageId,String cwd){}

    private final class LspSession {
        private final Path root; private final ServerConfig cfg; private final Process process; private final OutputStream out;
        private final AtomicLong ids=new AtomicLong(1); private final Map<Long,CompletableFuture<JsonNode>> pending=new ConcurrentHashMap<>();
        private final Map<String,JsonNode> diagnostics=new ConcurrentHashMap<>(); private final Set<String> opened=ConcurrentHashMap.newKeySet();

        LspSession(Path root,ServerConfig cfg)throws Exception{
            this.root=root.toRealPath(); this.cfg=cfg;
            if(cfg.command().isBlank()) throw new IllegalArgumentException("LSP command is required for "+cfg.name());
            List<String> cmd=new ArrayList<>();cmd.add(cfg.command());cmd.addAll(cfg.args()); ProcessBuilder pb=new ProcessBuilder(cmd);
            Path cwd=cfg.cwd().isBlank()?this.root:this.root.resolve(cfg.cwd()).normalize(); if(!cwd.startsWith(this.root)||!Files.isDirectory(cwd))throw new SecurityException("Invalid LSP cwd");
            pb.directory(cwd.toFile()); process=pb.start(); out=process.getOutputStream();
            Thread reader=new Thread(()->readLoop(process.getInputStream()),"lsp-reader-"+cfg.name());reader.setDaemon(true);reader.start();
            Thread err=new Thread(()->{try{process.getErrorStream().transferTo(OutputStream.nullOutputStream());}catch(Exception ignored){}},"lsp-stderr-"+cfg.name());err.setDaemon(true);err.start();
            ObjectNode params=mapper.createObjectNode();params.put("processId",ProcessHandle.current().pid());params.put("rootUri",this.root.toUri().toString());params.set("capabilities",mapper.createObjectNode());
            request("initialize",params); notify("initialized",mapper.createObjectNode());
        }

        String call(String op,String rel,int line,int ch,String query)throws Exception{
            return switch(op){
                case "definition" -> render(request("textDocument/definition",positionParams(rel,line,ch)));
                case "references" -> {ObjectNode p=positionParams(rel,line,ch);p.set("context",mapper.valueToTree(Map.of("includeDeclaration",true)));yield render(request("textDocument/references",p));}
                case "hover" -> render(request("textDocument/hover",positionParams(rel,line,ch)));
                case "document_symbols","symbols" -> {ensureOpen(rel);ObjectNode p=mapper.createObjectNode();p.set("textDocument",mapper.valueToTree(Map.of("uri",uri(rel))));yield render(request("textDocument/documentSymbol",p));}
                case "workspace_symbols" -> {ObjectNode p=mapper.createObjectNode();p.put("query",query==null?"":query);yield render(request("workspace/symbol",p));}
                case "diagnostics" -> diagnostics(rel);
                default -> throw new IllegalArgumentException("Unsupported LSP operation: "+op+". Use diagnostics, definition, references, hover, document_symbols, workspace_symbols.");
            };
        }

        private ObjectNode positionParams(String rel,int line,int ch)throws Exception{ ensureOpen(rel);ObjectNode p=mapper.createObjectNode();p.set("textDocument",mapper.valueToTree(Map.of("uri",uri(rel))));p.set("position",mapper.valueToTree(Map.of("line",Math.max(0,line),"character",Math.max(0,ch))));return p; }
        private String diagnostics(String rel)throws Exception{
            ensureOpen(rel); String u=uri(rel);
            // Prefer pull diagnostics when supported; fall back to recent publishDiagnostics notification.
            try{ObjectNode p=mapper.createObjectNode();p.set("textDocument",mapper.valueToTree(Map.of("uri",u)));JsonNode r=request("textDocument/diagnostic",p);if(!r.has("error"))return render(r);}catch(Exception ignored){}
            long until=System.nanoTime()+TimeUnit.MILLISECONDS.toNanos(700);while(System.nanoTime()<until&&!diagnostics.containsKey(u))Thread.sleep(25);
            JsonNode d=diagnostics.get(u);return d==null?"[No published diagnostics received for "+rel+"]":d.toPrettyString();
        }
        private void ensureOpen(String rel)throws Exception{String u=uri(rel);if(opened.add(u)){Path f=resolve(rel);String text=Files.readString(f,StandardCharsets.UTF_8);String lang=cfg.languageId().isBlank()?languageId(f):cfg.languageId();ObjectNode p=mapper.createObjectNode();p.set("textDocument",mapper.valueToTree(Map.of("uri",u,"languageId",lang,"version",1,"text",text)));notify("textDocument/didOpen",p);}}
        private String languageId(Path f){String n=f.getFileName().toString().toLowerCase(Locale.ROOT);int d=n.lastIndexOf('.');String e=d<0?"":n.substring(d+1);return switch(e){case"java"->"java";case"ts"->"typescript";case"tsx"->"typescriptreact";case"js"->"javascript";case"jsx"->"javascriptreact";case"py"->"python";case"rs"->"rust";case"go"->"go";case"cs"->"csharp";default->e;};}
        private Path resolve(String rel)throws Exception{if(rel==null||rel.isBlank())throw new IllegalArgumentException("path is required");Path p=root.resolve(rel).normalize();if(!p.startsWith(root)||!Files.isRegularFile(p)||Files.isSymbolicLink(p))throw new SecurityException("Invalid LSP path: "+rel);return p;}
        private String uri(String rel)throws Exception{return resolve(rel).toUri().toString();}

        private JsonNode request(String method,JsonNode params)throws Exception{if(!process.isAlive())throw new IllegalStateException("LSP process exited");long id=ids.getAndIncrement();CompletableFuture<JsonNode> f=new CompletableFuture<>();pending.put(id,f);ObjectNode n=mapper.createObjectNode();n.put("jsonrpc","2.0");n.put("id",id);n.put("method",method);n.set("params",params);send(n);try{while(true){if(!process.isAlive())throw new IllegalStateException("LSP process exited");try{return f.get(250,TimeUnit.MILLISECONDS);}catch(TimeoutException ignored){}}}finally{pending.remove(id);}}
        private void notify(String method,JsonNode params)throws Exception{ObjectNode n=mapper.createObjectNode();n.put("jsonrpc","2.0");n.put("method",method);n.set("params",params);send(n);}
        private synchronized void send(JsonNode n)throws Exception{byte[] body=mapper.writeValueAsBytes(n);String head="Content-Length: "+body.length+"\r\n\r\n";out.write(head.getBytes(StandardCharsets.US_ASCII));out.write(body);out.flush();}
        private void readLoop(InputStream in){try{BufferedInputStream bin=new BufferedInputStream(in);while(true){int len=readContentLength(bin);if(len<0)break;byte[] body=bin.readNBytes(len);if(body.length!=len)break;JsonNode n=mapper.readTree(body);if(n.has("id")){CompletableFuture<JsonNode> f=pending.get(n.path("id").asLong());if(f!=null)f.complete(n);}else if("textDocument/publishDiagnostics".equals(n.path("method").asText(""))){JsonNode p=n.path("params");diagnostics.put(p.path("uri").asText(""),p.path("diagnostics"));}}}catch(Exception ignored){}IllegalStateException x=new IllegalStateException("LSP server stopped: "+cfg.name());pending.values().forEach(f->f.completeExceptionally(x));}
        private int readContentLength(BufferedInputStream in)throws IOException{int len=-1;StringBuilder line=new StringBuilder();while(true){int b=in.read();if(b<0)return -1;if(b=='\r'){int n=in.read();if(n!='\n')continue;String l=line.toString();line.setLength(0);if(l.isEmpty())return len;if(l.toLowerCase(Locale.ROOT).startsWith("content-length:"))len=Integer.parseInt(l.substring("content-length:".length()).trim());}else line.append((char)b);}}
        private String render(JsonNode response){if(response==null)return"[No LSP response]";if(response.has("error"))return"LSP ERROR: "+response.path("error").toString();JsonNode r=response.path("result");return r.isMissingNode()?response.toPrettyString():r.toPrettyString();}
        void close(){try{notify("exit",mapper.createObjectNode());}catch(Exception ignored){}if(process.isAlive()){process.destroy();if(process.isAlive())process.destroyForcibly();}}
    }
}
