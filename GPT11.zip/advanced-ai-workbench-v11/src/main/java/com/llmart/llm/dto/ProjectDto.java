package com.llmart.llm.dto;

import java.time.Instant;

public record ProjectDto(String id, String conversationId, String name, long fileCount,
                         long totalBytes, long indexedCharacters, String localPath, boolean localWorkspace,
                         Instant createdAt, Instant updatedAt) {}
