package com.llmart.llm.controller;

import com.llmart.llm.service.PatchConflictException;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.NoSuchElementException;

@RestControllerAdvice
public class ApiExceptionHandler {
    @ExceptionHandler(PatchConflictException.class)
    @ResponseStatus(HttpStatus.CONFLICT)
    public Map<String, Object> conflict(PatchConflictException e) {
        Map<String,Object> body = new LinkedHashMap<>();
        body.put("message", e.getMessage());
        body.put("conflicts", e.conflicts());
        return body;
    }

    @ExceptionHandler({IllegalArgumentException.class, NoSuchElementException.class, SecurityException.class})
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public Map<String, String> badRequest(Exception e) { return Map.of("message", e.getMessage()); }
}
