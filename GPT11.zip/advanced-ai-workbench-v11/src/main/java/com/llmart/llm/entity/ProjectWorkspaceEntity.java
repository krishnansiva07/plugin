package com.llmart.llm.entity;

import jakarta.persistence.*;
import java.time.Instant;

@Entity
@Table(name = "project_workspaces", indexes = @Index(name = "idx_project_conversation", columnList = "conversation_id"))
public class ProjectWorkspaceEntity {
    @Id
    @Column(length = 40)
    private String id;

    @Column(name = "conversation_id", nullable = false, length = 40)
    private String conversationId;

    @Column(nullable = false, length = 300)
    private String name;

    @Column(name = "local_path", length = 2000)
    private String localPath;

    @Column(nullable = false)
    private Instant createdAt;

    @Column(nullable = false)
    private Instant updatedAt;

    public ProjectWorkspaceEntity() {}

    public ProjectWorkspaceEntity(String id, String conversationId, String name) {
        this(id, conversationId, name, null);
    }

    public ProjectWorkspaceEntity(String id, String conversationId, String name, String localPath) {
        this.id = id;
        this.conversationId = conversationId;
        this.name = name;
        this.localPath = localPath;
        this.createdAt = Instant.now();
        this.updatedAt = this.createdAt;
    }

    public String getId() { return id; }
    public String getConversationId() { return conversationId; }
    public String getName() { return name; }
    public String getLocalPath() { return localPath; }
    public Instant getCreatedAt() { return createdAt; }
    public Instant getUpdatedAt() { return updatedAt; }
    public boolean hasLocalPath() { return localPath != null && !localPath.isBlank(); }
    public void setLocalPath(String localPath) { this.localPath = localPath; touch(); }
    public void touch() { this.updatedAt = Instant.now(); }
}
