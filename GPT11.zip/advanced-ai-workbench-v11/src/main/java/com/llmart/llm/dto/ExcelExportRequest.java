package com.llmart.llm.dto;

public record ExcelExportRequest(String title, String markdown) {}
