package com.llmart.llm.service;

import com.llmart.llm.entity.ProjectFileEntity;
import com.llmart.llm.entity.ProjectWorkspaceEntity;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.regex.Pattern;

@Service
public class ProjectContextService {
    private static final Pattern WORD = Pattern.compile("[^a-zA-Z0-9_.$/-]+");
    private static final Set<String> STOP = Set.of("the","and","for","with","this","that","from","into","file","project","issue","fix","please","can","you","are","was","have","has","any","whole","analyze","analyse");

    private final ProjectService projects;

    public ProjectContextService(ProjectService projects) { this.projects = projects; }

    public String select(String projectId, String query, int maxChars) {
        if (projectId == null || projectId.isBlank() || maxChars <= 0) return "";
        ProjectWorkspaceEntity project = projects.require(projectId);
        List<ProjectFileEntity> all = projects.fileEntities(projectId);
        if (all.isEmpty()) return "";

        int totalChars = all.stream().mapToInt(f -> safe(f.getTextContent()).length()).sum();
        StringBuilder out = new StringBuilder();
        out.append("\n\nACTIVE PROJECT WORKSPACE: ").append(project.getName()).append('\n');
        out.append("Files indexed: ").append(all.size()).append("; indexed text characters: ").append(totalChars).append(".\n");
        out.append("Project file tree:\n");
        for (ProjectFileEntity f : all) {
            if (out.length() > Math.min(maxChars / 5, 12_000)) { out.append("... [tree truncated]\n"); break; }
            out.append("- ").append(f.getRelativePath()).append('\n');
        }

        int remaining = Math.max(0, maxChars - out.length());
        if (remaining < 1000) return clip(out.toString(), maxChars);

        // If the project fits the available context, include it all. Otherwise retrieve the best files/chunks.
        if (totalChars <= remaining) {
            for (ProjectFileEntity f : all) appendFile(out, f.getRelativePath(), modelContent(f), maxChars);
            return clip(out.toString(), maxChars);
        }

        Set<String> terms = terms(query);
        List<ScoredFile> scored = new ArrayList<>();
        for (ProjectFileEntity f : all) scored.add(new ScoredFile(f, score(f, terms, query)));
        scored.sort(Comparator.comparingDouble(ScoredFile::score).reversed()
                .thenComparing(sf -> sf.file().getRelativePath(), String.CASE_INSENSITIVE_ORDER));

        out.append("\nRelevant project files selected for this request (the project is larger than the context budget):\n");
        int perFileCap = Math.max(2500, Math.min(18_000, remaining / Math.max(1, Math.min(12, scored.size()))));
        int included = 0;
        for (ScoredFile sf : scored) {
            if (out.length() >= maxChars - 500) break;
            String content = modelContent(sf.file());
            if (content.isBlank()) continue;
            String selected = selectChunk(content, terms, perFileCap);
            appendFile(out, sf.file().getRelativePath(), selected, maxChars);
            included++;
            if (included >= 24) break;
        }
        out.append("\n[The workspace indexes all eligible source/config files. Only the most relevant content is injected when the complete project exceeds the configured context budget.]\n");
        return clip(out.toString(), maxChars);
    }

    private void appendFile(StringBuilder out, String path, String content, int maxChars) {
        if (out.length() >= maxChars) return;
        String prefix = "\n--- PROJECT FILE: " + path + " ---\n";
        int room = maxChars - out.length() - prefix.length() - 32;
        if (room <= 0) return;
        out.append(prefix);
        if (content.length() <= room) out.append(content);
        else out.append(content, 0, Math.max(0, room)).append("\n[...truncated]");
        out.append('\n');
    }

    private String selectChunk(String content, Set<String> terms, int cap) {
        if (content.length() <= cap) return content;
        if (terms.isEmpty()) return content.substring(0, cap);
        String low = content.toLowerCase(Locale.ROOT);
        int best = -1;
        for (String term : terms) {
            int idx = low.indexOf(term.toLowerCase(Locale.ROOT));
            if (idx >= 0 && (best < 0 || idx < best)) best = idx;
        }
        if (best < 0) return content.substring(0, cap);
        int start = Math.max(0, best - cap / 3);
        int end = Math.min(content.length(), start + cap);
        return content.substring(start, end);
    }

    private double score(ProjectFileEntity f, Set<String> terms, String query) {
        String path = f.getRelativePath().toLowerCase(Locale.ROOT);
        String content = safe(f.getTextContent()).toLowerCase(Locale.ROOT);
        double score = 0;
        for (String term : terms) {
            if (path.contains(term)) score += 8;
            int idx = 0, count = 0;
            while ((idx = content.indexOf(term, idx)) >= 0 && count < 20) { count++; idx += term.length(); }
            score += count;
        }
        if (isImportant(path)) score += 2.5;
        String q = query == null ? "" : query.toLowerCase(Locale.ROOT);
        if ((q.contains("build") || q.contains("dependency")) && (path.endsWith("pom.xml") || path.endsWith("build.gradle") || path.endsWith("package.json"))) score += 12;
        if ((q.contains("config") || q.contains("property")) && (path.contains("config") || path.endsWith(".properties") || path.endsWith(".yml") || path.endsWith(".yaml"))) score += 10;
        return score;
    }

    private boolean isImportant(String path) {
        return path.endsWith("pom.xml") || path.endsWith("build.gradle") || path.endsWith("settings.gradle") ||
                path.endsWith("package.json") || path.endsWith("readme.md") || path.endsWith("application.properties") ||
                path.endsWith("application.yml") || path.endsWith("application.yaml");
    }

    private Set<String> terms(String query) {
        LinkedHashSet<String> result = new LinkedHashSet<>();
        if (query == null) return result;
        for (String word : WORD.split(query.toLowerCase(Locale.ROOT))) {
            if (word.length() > 2 && !STOP.contains(word)) result.add(word);
        }
        return result;
    }


    private String modelContent(ProjectFileEntity file) {
        String text = safe(file.getTextContent());
        // Avoid sending common committed credentials to the model while preserving the configuration key names.
        text = text.replaceAll("(?im)^(\\s*[A-Za-z0-9_.-]*(?:password|passwd|secret|api[-_.]?key|token|client[-_.]?secret)[A-Za-z0-9_.-]*\\s*[:=]\\s*).*$", "$1[REDACTED]");
        text = text.replaceAll("(?i)(\"(?:password|passwd|secret|api[-_.]?key|token|client[-_.]?secret)\"\\s*:\\s*\")[^\"]*(\")", "$1[REDACTED]$2");
        return text;
    }

    private String safe(String s) { return s == null ? "" : s; }
    private String clip(String s, int max) { return s.length() <= max ? s : s.substring(0, Math.max(0, max - 30)) + "\n[...truncated]"; }
    private record ScoredFile(ProjectFileEntity file, double score) {}
}
