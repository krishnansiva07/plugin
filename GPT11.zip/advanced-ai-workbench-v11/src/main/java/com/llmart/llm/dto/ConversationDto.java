package com.llmart.llm.dto;

import java.time.Instant;

public record ConversationDto(String id, String title, Instant createdAt, Instant updatedAt) {}
