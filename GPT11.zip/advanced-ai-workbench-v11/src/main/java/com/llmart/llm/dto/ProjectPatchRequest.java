package com.llmart.llm.dto;

import java.util.List;

public record ProjectPatchRequest(String projectName, List<ProjectPatchFile> files) {
    public record ProjectPatchFile(String path, String content, String baselineHash, String operation) {
        public ProjectPatchFile(String path, String content) {
            this(path, content, null, "write");
        }

        public ProjectPatchFile(String path, String content, String baselineHash) {
            this(path, content, baselineHash, "write");
        }

        public String safeOperation() {
            return "delete".equalsIgnoreCase(operation) ? "delete" : "write";
        }
    }
}
