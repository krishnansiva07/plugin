package com.llmart.llm.repository;

import com.llmart.llm.entity.ProjectFileEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.*;

public interface ProjectFileRepository extends JpaRepository<ProjectFileEntity, String> {
    List<ProjectFileEntity> findByProjectId(String projectId);
    Optional<ProjectFileEntity> findByProjectIdAndRelativePath(String projectId, String relativePath);
    long countByProjectId(String projectId);
    void deleteByProjectId(String projectId);
}
