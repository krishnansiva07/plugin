#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

echo "[1/4] Java"
java -version

echo "[2/4] Frontend syntax"
if command -v node >/dev/null 2>&1; then
  node --check src/main/resources/static/app.js
  node --check src/main/resources/static/markdown.js
else
  echo "Node is not installed; skipping JavaScript syntax checks."
fi

echo "[3/4] Maven tests"
mvn clean test

echo "[4/4] Package"
mvn package -DskipTests

echo "Validation complete. JAR: target/advanced-ai-chat-2.1.0-SNAPSHOT.jar"
