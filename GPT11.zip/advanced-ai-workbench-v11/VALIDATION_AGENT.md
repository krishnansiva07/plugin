# GPT11 validation report

Validation performed on the V11 generic-agent working tree before packaging on 2026-09-05.

## Passed in this packaging environment

- `src/main/resources/static/app.js`: `node --check` passed.
- `src/main/resources/static/markdown.js`: `node --check` passed.
- `pom.xml`: XML parse passed.
- Full Java source tree was parsed by `javac --release 17 -proc:none`; no syntax-style diagnostics such as malformed string literals, illegal starts, missing delimiters, or unexpected end-of-file were found. Remaining compiler diagnostics are unresolved Spring/Jackson/POI/Tika/JPA classes because Maven dependencies are not installed in this environment.
- `AgentToolRegistry` compiled and executed under Java 17 using a minimal Spring annotation stub:
  - 40 built-in tool definitions.
  - 40 unique built-in tool names.
  - `task` subagent tool present.
  - `lsp` tool present.
  - `attachment_search` present.
  - no Git tool is exposed.
- Attachment search source defect found during V11 development was corrected; the Java parser reports no remaining malformed string literal diagnostics.
- Native multi-tool agent loop, parallel read-only execution paths, direct live-workspace operations, MCP manager, LSP manager, subagent runtime, reusable skills/instructions, managed processes, HTTP verification, and attachment resource tools are present in source.
- No fixed model-step or build/fix retry ceiling was found in the Agent runtime.
- Frontend identifies the build as V11 and exposes separate MCP, LSP and subagent permissions.
- Git remains intentionally out of scope.
- Dedicated test-case generation UI/prompts remain removed.

## V11 architecture included

- Direct user-selected live workspace; no agent project mirror or delayed apply phase.
- Native tool/function calling first, compatibility fallback second.
- Multiple tools per model turn and parallel execution for eligible read-only tools.
- Persistent workspace profile and project instruction discovery (`AGENTS.md`, nested instructions, compatible Claude/OpenCode instruction locations).
- Lazy `SKILL.md` discovery from `.agents`, `.opencode`, and `.claude` compatible locations.
- Fresh-context `explore` and `general` subagents plus project-defined subagents.
- Generic MCP client with dynamic tool discovery and namespaced MCP tools.
- Generic LSP client for diagnostics, definition, references, hover, document symbols and workspace symbols.
- Attachment resource tools: list/read/search.
- Build/test/check, unrestricted workspace shell subject to permissions, managed background processes, and HTTP verification.

## Environment limitation

Maven is not installed in this execution environment and there is no usable local Maven dependency cache. Therefore a truthful full `mvn clean test` / Spring Boot package run could not be executed here.

Run `validate-local.sh` (Linux/macOS) or `validate-local.bat` (Windows) on the target machine. Those scripts run the available frontend checks plus `mvn clean test` and package the JAR.

## Important note

V11 is intended as a test build of the new OpenCode/Claude-style generic runtime. It should be tested with a copy of a real workspace first because Agent mode writes directly to the mapped path when edit permission is Allow.
