# V11 configuration examples

These files are optional. V11 remains usable without them.

## Project instructions

Place at the selected workspace root:

```text
AGENTS.md
```

Example:

```md
# Project

## Build
Use the build system already configured in this workspace.

## Agent rules
- Inspect relevant code/configuration before editing.
- Make the smallest correct change.
- Build and execute the affected functionality after changes.
- Continue fixing until the requested behavior is verified.
- Do not disable tests merely to get a successful build.
```

Nested modules can contain their own `AGENTS.md`.

## Reusable skill

```text
.agents/skills/debugging/SKILL.md
```

```md
---
name: debugging
description: Reproduce, diagnose, repair and verify build/runtime/test failures.
---

1. Read the complete failure evidence.
2. Reproduce the smallest relevant failure.
3. Inspect related source/configuration.
4. Determine the root cause rather than masking the symptom.
5. Make the smallest correct change.
6. Build/run/test the affected functionality.
7. Inspect the new result and repeat until verified.
```

## Project-defined subagent

```text
.agents/agents/reviewer.md
```

```md
---
description: Read-only architecture and implementation reviewer
mode: subagent
tools: [inspect_workspace, workspace_profile, glob, grep, read, read_many, lsp, lsp_status]
---

Review the delegated area using concrete workspace evidence. Do not modify files. Return concise findings, risks and exact file locations to the parent agent.
```

## MCP

```text
.agents/mcp.json
```

STDIO example:

```json
{
  "servers": {
    "browser": {
      "type": "stdio",
      "command": "your-mcp-command",
      "args": ["mcp"]
    }
  }
}
```

HTTP example:

```json
{
  "servers": {
    "internal": {
      "type": "http",
      "url": "http://127.0.0.1:9001/mcp"
    }
  }
}
```

The runtime discovers each server's tools dynamically and exposes them as namespaced model tools such as `mcp__browser__navigate`.

## LSP

```text
.agents/lsp.json
```

```json
{
  "servers": {
    "example-language": {
      "command": "your-language-server",
      "args": ["--stdio"],
      "extensions": ["java"],
      "languageId": "java"
    }
  }
}
```

V11 does not hard-code a language server. Configure the server installed on the user's machine.
