# OpenCode / Claude Code style capability comparison

Git is intentionally excluded from this product and is not counted as a parity gap.

| Capability | V11 |
|---|---|
| Persistent conversation/session UI | Yes |
| Chat / Analyze / Agent modes | Yes |
| Direct user-selected live workspace | Yes |
| Native OpenAI-compatible tool calling | Yes, primary |
| Compatibility fallback when native tools are unsupported | Yes |
| Multiple tool calls in one model turn | Yes |
| Parallel eligible read-only tool execution | Yes |
| No fixed model-step/action/build-loop ceiling | Yes |
| Provider-max output/context mode | Yes (`0`) |
| Read/list/glob/grep/file metadata | Yes |
| Edit/write/copy/move/delete/apply-patch | Yes |
| Full workspace shell with pipes/chaining/redirection | Yes |
| Build/test/check auto-detection | Yes |
| Long-running managed processes | Yes |
| Runtime logs/status | Yes |
| HTTP runtime verification | Yes |
| Build/run/failure/fix/retry completion guard | Yes |
| Allow / Ask / Deny + approve once / allow run | Yes |
| Root and nested project instructions | Yes |
| Lazy `SKILL.md` loading | Yes |
| Attachment list/read/search tools | Yes |
| Persistent workspace profile | Yes |
| Fresh-context subagent delegation | Yes |
| Built-in Explore and General subagents | Yes |
| Project-defined subagents | Yes |
| Generic MCP discovery/client | Yes |
| STDIO MCP transport | Yes |
| HTTP/streamable MCP transport | Yes |
| Dynamic namespaced MCP tools | Yes |
| Generic LSP client | Yes |
| LSP diagnostics/definition/references/hover/symbols | Yes |
| Workspace status/diff without Git | Yes |
| User cancellation | Yes |
| Git operations | No — explicitly out of scope |
| PTY-style fully interactive terminal | Not yet |

The goal is behavioral and architectural similarity, not source-code duplication. Actual throughput depends on the selected model/provider, local machine, network, build system, MCP servers and language servers.
