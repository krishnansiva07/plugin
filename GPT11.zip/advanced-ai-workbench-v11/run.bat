@echo off
setlocal
set JAR=target\advanced-ai-chat-2.1.0-SNAPSHOT.jar
if not exist "%JAR%" (
  echo JAR not found. Building...
  call mvn clean package
  if errorlevel 1 exit /b 1
)
java -jar "%JAR%"
