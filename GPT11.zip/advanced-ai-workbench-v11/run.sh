#!/usr/bin/env bash
set -e
JAR="target/advanced-ai-chat-2.1.0-SNAPSHOT.jar"
if [ ! -f "$JAR" ]; then
  mvn clean package
fi
java -jar "$JAR"
