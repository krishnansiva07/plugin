# LangChain self-healing patch

This patch replaces the direct `fetch()` LLM call with LangChain JavaScript `ChatOpenAI` while retaining the same configuration pattern as the shared Java LangChain4j client:

- API key
- Base URL
- Model name
- Temperature
- Maximum tokens
- Request timeout

## 1. Extract and apply

Extract this ZIP. Open PowerShell and run:

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\apply-langchain-patch.ps1 -ProjectPath "C:\Playwright\smart-playwright-json-framework"
```

The script:

1. Verifies `package.json` exists.
2. Backs up the old `LlmClient.ts` and `SmartActions.ts`.
3. Copies the LangChain files.
4. Adds the certificate helper script.
5. Installs `@langchain/openai` and `@langchain/core`.
6. Runs TypeScript validation.

## 2. Configure `.env`

Copy these entries from `.env.langchain.example` into the framework `.env`:

```env
LLM_ENABLED=true
LLM_API_KEY=your-token
LLM_BASE_URL=https://your-corporate-llm-host/openai/v1
LLM_MODEL_NAME=your-model-name
LLM_TEMPERATURE=0
LLM_MAX_TOKENS=500
LLM_TIMEOUT_MS=30000
LLM_MAX_RETRIES=1
LLM_MIN_CONFIDENCE=0.85
```

`LLM_BASE_URL` must normally be the API root ending in `/v1`. Do not add `/chat/completions`; LangChain adds that path.

## 3. Add the corporate CA file

Copy your existing `cacert` file to:

```text
smart-playwright-json-framework\certificates\cacert
```

Open it in Notepad. It must contain one or more certificate blocks:

```text
-----BEGIN CERTIFICATE-----
...
-----END CERTIFICATE-----
```

The filename does not require a `.pem` extension.

## 4. Run with the certificate

From the framework root:

```powershell
.\scripts\run-with-cacert.ps1
```

The script sets `NODE_EXTRA_CA_CERTS` before Node starts and then executes `npm test`.

You may also run manually:

```powershell
$env:NODE_EXTRA_CA_CERTS="$PWD\certificates\cacert"
npm test
```

Verify the file exists:

```powershell
Test-Path $env:NODE_EXTRA_CA_CERTS
```

It must return `True`.

## 5. Check LLM self-healing

Temporarily make every username locator wrong in `src/pages/LoginPage.ts`, for example:

```typescript
primary: () => page.getByTestId('wrong-username'),
fallbacks: [
  () => page.getByPlaceholder('wrong-username'),
  () => page.locator('input[name="wrong-username"]')
]
```

Run:

```powershell
.\scripts\run-with-cacert.ps1
```

Expected terminal output:

```text
[SELF-HEALING] Normal locators failed for SauceDemo username input
[LLM HEALING] Calling LangChain for: SauceDemo username input
[LLM HEALING] Suggested selector: input[data-test="username"]
[LLM HEALING] Confidence: 0.96
[SELF-HEALING] LLM healing succeeded
```

Restore the original locators after validation.

## 6. Troubleshooting

### Self-signed certificate error

Confirm:

```powershell
$env:NODE_EXTRA_CA_CERTS
Test-Path $env:NODE_EXTRA_CA_CERTS
```

Close and reopen VS Code if you configured the environment variable permanently. Node reads `NODE_EXTRA_CA_CERTS` when the Node process starts.

### HTTP 404

The base URL is probably incorrect. Use the API root, commonly ending in `/v1`, not the full `/chat/completions` endpoint.

### HTTP 401 or 403

Check the token and model access.

### Empty or invalid JSON response

The corporate model may not follow OpenAI-compatible chat completion output. Confirm the endpoint is compatible with the OpenAI chat-completions contract.

### LLM is not called

Make sure all primary and deterministic fallback locators are invalid and `LLM_ENABLED=true`.
