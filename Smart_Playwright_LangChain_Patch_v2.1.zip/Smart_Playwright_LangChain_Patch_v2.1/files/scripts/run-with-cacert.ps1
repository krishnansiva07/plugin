param(
  [string]$CertificatePath = "$PSScriptRoot\..\certificates\cacert"
)

$resolvedCertificate = Resolve-Path $CertificatePath -ErrorAction Stop
$env:NODE_EXTRA_CA_CERTS = $resolvedCertificate.Path

Write-Host "NODE_EXTRA_CA_CERTS=$env:NODE_EXTRA_CA_CERTS" -ForegroundColor Cyan
Write-Host "Starting Playwright tests..." -ForegroundColor Green

npm test
exit $LASTEXITCODE
