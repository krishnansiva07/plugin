import type { Locator, Page } from '@playwright/test';
import { envNumber } from '../../utils/Environment';
import { LlmClient } from '../../llm/LlmClient';

export interface SmartElement {
  description: string;
  primary: () => Locator;
  fallbacks?: Array<() => Locator>;
}

interface ResolvedLocator {
  locator: Locator;
  healed: boolean;
}

export class SmartActions {
  private readonly llm = new LlmClient();
  private readonly minimumConfidence = envNumber('LLM_MIN_CONFIDENCE', 0.85);

  constructor(private readonly page: Page) {}

  async fill(element: SmartElement, value: string): Promise<boolean> {
    const resolved = await this.resolve(element, 'fill');
    await resolved.locator.fill(value);
    return resolved.healed;
  }

  async click(element: SmartElement): Promise<boolean> {
    const resolved = await this.resolve(element, 'click');
    await resolved.locator.click();
    return resolved.healed;
  }

  private async isUsable(locator: Locator): Promise<boolean> {
    try {
      return (await locator.count()) === 1 && (await locator.isVisible());
    } catch {
      return false;
    }
  }

  private async resolve(element: SmartElement, action: string): Promise<ResolvedLocator> {
    const candidates = [element.primary, ...(element.fallbacks ?? [])];

    for (let index = 0; index < candidates.length; index += 1) {
      const locator = candidates[index]();
      if (await this.isUsable(locator)) {
        if (index > 0) {
          console.log(`[SELF-HEALING] Deterministic fallback ${index} used for ${element.description}`);
        }
        return { locator, healed: index > 0 };
      }
    }

    const failedLocator = element.primary().toString();
    const error = `Unable to find a unique visible element for ${element.description}`;

    console.log(`[SELF-HEALING] Normal locators failed for ${element.description}`);

    const suggestion = await this.llm.suggestLocator({
      elementDescription: element.description,
      failedLocator,
      action,
      error,
      pageTitle: await this.page.title(),
      pageUrl: this.page.url(),
      relevantDom: (await this.page.locator('body').innerHTML()).slice(0, 20000)
    });

    if (suggestion && suggestion.confidence >= this.minimumConfidence) {
      const healed = this.page.locator(suggestion.selector);
      if (await this.isUsable(healed)) {
        console.log('============================================================');
        console.log('[SELF-HEALING] LLM healing succeeded');
        console.log(`[SELF-HEALING] Element    : ${element.description}`);
        console.log(`[SELF-HEALING] Selector   : ${suggestion.selector}`);
        console.log(`[SELF-HEALING] Confidence : ${suggestion.confidence}`);
        console.log(`[SELF-HEALING] Reason     : ${suggestion.reason}`);
        console.log('============================================================');
        return { locator: healed, healed: true };
      }

      console.warn(`[SELF-HEALING] Suggested selector was not unique and visible: ${suggestion.selector}`);
    }

    throw new Error(error);
  }
}
