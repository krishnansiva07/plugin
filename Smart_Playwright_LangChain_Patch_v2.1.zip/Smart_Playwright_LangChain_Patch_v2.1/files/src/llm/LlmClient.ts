import { HumanMessage, SystemMessage } from '@langchain/core/messages';
import { ChatOpenAI } from '@langchain/openai';
import { env, envBoolean, envNumber } from '../utils/Environment';

export interface HealingRequest {
  elementDescription: string;
  failedLocator: string;
  action: string;
  error: string;
  pageTitle: string;
  pageUrl: string;
  relevantDom: string;
}

export interface HealingSuggestion {
  selector: string;
  confidence: number;
  reason: string;
}

export class LlmClient {
  readonly enabled = envBoolean('LLM_ENABLED', false);
  private readonly model: ChatOpenAI | null;

  constructor() {
    if (!this.enabled) {
      this.model = null;
      return;
    }

    const apiKey = this.requireNonBlank(env('LLM_API_KEY'), 'LLM_API_KEY');
    const baseUrl = this.requireNonBlank(env('LLM_BASE_URL'), 'LLM_BASE_URL');
    const modelName = this.requireNonBlank(env('LLM_MODEL_NAME'), 'LLM_MODEL_NAME');

    this.model = new ChatOpenAI({
      apiKey,
      model: modelName,
      temperature: envNumber('LLM_TEMPERATURE', 0),
      maxTokens: envNumber('LLM_MAX_TOKENS', 500),
      timeout: envNumber('LLM_TIMEOUT_MS', 30000),
      maxRetries: envNumber('LLM_MAX_RETRIES', 1),
      configuration: {
        // Use the API root, normally ending in /v1. Do not add /chat/completions.
        baseURL: baseUrl.replace(/\/+$/, '')
      }
    });
  }

  async suggestLocator(request: HealingRequest): Promise<HealingSuggestion | null> {
    if (!this.enabled || !this.model) return null;

    const systemPrompt = [
      'You are a UI automation locator-healing engine.',
      'Return strict JSON only in this exact shape:',
      '{"selector":"one safe CSS selector","confidence":0.0,"reason":"short explanation"}',
      'Return one CSS selector only. Do not return XPath or JavaScript.',
      'Prefer stable id, name, data-test, aria-label, placeholder, role, or type attributes.',
      'Avoid positional selectors such as nth-child.',
      'Confidence must be between 0 and 1.'
    ].join('\n');

    try {
      console.log(`[LLM HEALING] Calling LangChain for: ${request.elementDescription}`);

      const response = await this.model.invoke([
        new SystemMessage(systemPrompt),
        new HumanMessage(JSON.stringify(request))
      ]);

      const raw = this.extractText(response.content);
      if (!raw) {
        console.warn('[LLM HEALING] Empty response received.');
        return null;
      }

      const suggestion = this.parseSuggestion(raw);
      console.log(`[LLM HEALING] Suggested selector: ${suggestion.selector}`);
      console.log(`[LLM HEALING] Confidence: ${suggestion.confidence}`);
      console.log(`[LLM HEALING] Reason: ${suggestion.reason}`);
      return suggestion;
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error);
      console.error(`[LLM HEALING] LangChain request failed: ${message}`);
      throw new Error(`LangChain LLM request failed: ${message}`, { cause: error });
    }
  }

  private extractText(content: unknown): string {
    if (typeof content === 'string') return content.trim();
    if (!Array.isArray(content)) return '';

    return content
      .map((part) => {
        if (typeof part === 'string') return part;
        if (
          typeof part === 'object' &&
          part !== null &&
          'text' in part &&
          typeof (part as { text?: unknown }).text === 'string'
        ) {
          return (part as { text: string }).text;
        }
        return '';
      })
      .join('')
      .trim();
  }

  private parseSuggestion(raw: string): HealingSuggestion {
    const clean = raw
      .replace(/^```json\s*/i, '')
      .replace(/^```\s*/i, '')
      .replace(/\s*```$/i, '')
      .trim();

    const parsed = JSON.parse(clean) as Partial<HealingSuggestion>;
    if (
      typeof parsed.selector !== 'string' ||
      !parsed.selector.trim() ||
      typeof parsed.confidence !== 'number' ||
      !Number.isFinite(parsed.confidence) ||
      parsed.confidence < 0 ||
      parsed.confidence > 1 ||
      typeof parsed.reason !== 'string'
    ) {
      throw new Error(`Invalid healing response: ${clean}`);
    }

    return {
      selector: parsed.selector.trim(),
      confidence: parsed.confidence,
      reason: parsed.reason.trim()
    };
  }

  private requireNonBlank(value: string, name: string): string {
    if (!value.trim()) throw new Error(`${name} must be supplied and non-blank.`);
    return value.trim();
  }
}
