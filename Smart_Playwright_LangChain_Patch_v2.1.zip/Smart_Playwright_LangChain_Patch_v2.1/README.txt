Smart Playwright JSON Framework - LangChain Integration Patch

Main files:
- apply-langchain-patch.ps1       Automated installer and backup
- LANGCHAIN_SETUP.md              Full setup and self-healing test steps
- files/src/llm/LlmClient.ts      LangChain ChatOpenAI implementation
- files/src/core/actions/SmartActions.ts  Healing validation and terminal logs
- files/scripts/run-with-cacert.ps1       Starts Node with corporate CA
- files/certificates/             Place your cacert file here after applying

Recommended command:
  .\apply-langchain-patch.ps1 -ProjectPath "C:\Playwright\smart-playwright-json-framework"
