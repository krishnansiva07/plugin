param(
  [Parameter(Mandatory = $false)]
  [string]$ProjectPath = (Get-Location).Path
)

$ErrorActionPreference = 'Stop'
$patchRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$filesRoot = Join-Path $patchRoot 'files'
$projectRoot = (Resolve-Path $ProjectPath).Path

if (-not (Test-Path (Join-Path $projectRoot 'package.json'))) {
  throw "package.json was not found in: $projectRoot. Run this script with -ProjectPath pointing to the smart-playwright-json-framework folder."
}

Write-Host "Applying LangChain patch to: $projectRoot" -ForegroundColor Cyan

$backupRoot = Join-Path $projectRoot ("backup-before-langchain-" + (Get-Date -Format 'yyyyMMdd-HHmmss'))
New-Item -ItemType Directory -Path $backupRoot -Force | Out-Null

$targets = @(
  'src\llm\LlmClient.ts',
  'src\core\actions\SmartActions.ts'
)

foreach ($relative in $targets) {
  $existing = Join-Path $projectRoot $relative
  if (Test-Path $existing) {
    $backupFile = Join-Path $backupRoot $relative
    New-Item -ItemType Directory -Path (Split-Path $backupFile -Parent) -Force | Out-Null
    Copy-Item $existing $backupFile -Force
  }
}

Copy-Item (Join-Path $filesRoot 'src') (Join-Path $projectRoot 'src') -Recurse -Force
Copy-Item (Join-Path $filesRoot 'certificates') (Join-Path $projectRoot 'certificates') -Recurse -Force
Copy-Item (Join-Path $filesRoot 'scripts\run-with-cacert.ps1') (Join-Path $projectRoot 'scripts\run-with-cacert.ps1') -Force
Copy-Item (Join-Path $filesRoot '.env.langchain.example') (Join-Path $projectRoot '.env.langchain.example') -Force

Push-Location $projectRoot
try {
  Write-Host 'Installing LangChain packages...' -ForegroundColor Yellow
  npm install @langchain/openai @langchain/core
  if ($LASTEXITCODE -ne 0) { throw 'npm install failed.' }

  Write-Host 'Running TypeScript validation...' -ForegroundColor Yellow
  npm run typecheck
  if ($LASTEXITCODE -ne 0) { throw 'TypeScript validation failed.' }
}
finally {
  Pop-Location
}

Write-Host ''
Write-Host 'LangChain patch applied successfully.' -ForegroundColor Green
Write-Host "Backup created at: $backupRoot"
Write-Host 'Next: copy the LLM values from .env.langchain.example into .env, place cacert in certificates, and run scripts\run-with-cacert.ps1.'
