package com.llmart.vibium.model;

public class CommandResult {
    private final int exitCode;
    private final String command;
    private final String stdout;
    private final String stderr;
    private final long durationMs;

    public CommandResult(int exitCode, String command, String stdout, String stderr, long durationMs) {
        this.exitCode = exitCode;
        this.command = command;
        this.stdout = stdout;
        this.stderr = stderr;
        this.durationMs = durationMs;
    }

    public int getExitCode() { return exitCode; }
    public String getCommand() { return command; }
    public String getStdout() { return stdout; }
    public String getStderr() { return stderr; }
    public long getDurationMs() { return durationMs; }
    public boolean isSuccess() { return exitCode == 0; }
}
