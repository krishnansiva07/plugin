package com.llmart.vibium.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties(prefix = "framework")
public class FrameworkProperties {
    private String reportDir = "reports";
    private boolean failFast = true;
    private boolean llmPlanningEnabled = true;
    private String baseUrlAllowlist = "";

    public String getReportDir() { return reportDir; }
    public void setReportDir(String reportDir) { this.reportDir = reportDir; }
    public boolean isFailFast() { return failFast; }
    public void setFailFast(boolean failFast) { this.failFast = failFast; }
    public boolean isLlmPlanningEnabled() { return llmPlanningEnabled; }
    public void setLlmPlanningEnabled(boolean llmPlanningEnabled) { this.llmPlanningEnabled = llmPlanningEnabled; }
    public String getBaseUrlAllowlist() { return baseUrlAllowlist; }
    public void setBaseUrlAllowlist(String baseUrlAllowlist) { this.baseUrlAllowlist = baseUrlAllowlist; }
}
