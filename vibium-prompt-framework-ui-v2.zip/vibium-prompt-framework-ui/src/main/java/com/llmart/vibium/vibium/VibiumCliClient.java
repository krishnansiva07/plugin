package com.llmart.vibium.vibium;

import com.llmart.vibium.model.CommandResult;
import org.springframework.stereotype.Component;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

@Component
public class VibiumCliClient {
    private final CommandRunner commandRunner;

    public VibiumCliClient(CommandRunner commandRunner) {
        this.commandRunner = commandRunner;
    }

    public void configureForRun(String browser, Boolean headless) {
        commandRunner.setRunBrowserOptions(browser, headless);
    }

    public void clearRunConfiguration() {
        commandRunner.clearRunBrowserOptions();
    }

    public CommandResult go(String url) {
        return commandRunner.run(List.of("go", url));
    }

    public CommandResult map() {
        return commandRunner.run(List.of("map"));
    }

    public CommandResult find(String strategy, String target) {
        String finalStrategy = normalizeStrategy(strategy);
        return commandRunner.run(List.of("find", finalStrategy, target));
    }

    public CommandResult click(String refOrSelector) {
        return commandRunner.run(List.of("click", refOrSelector));
    }

    public CommandResult fill(String refOrSelector, String value) {
        return commandRunner.run(List.of("fill", refOrSelector, value));
    }

    public CommandResult select(String refOrSelector, String value) {
        return commandRunner.run(List.of("select", refOrSelector, value));
    }

    public CommandResult check(String refOrSelector) {
        return commandRunner.run(List.of("check", refOrSelector));
    }

    public CommandResult press(String key) {
        return commandRunner.run(List.of("press", key));
    }

    public CommandResult waitText(String text) {
        return commandRunner.run(List.of("wait", "text", text));
    }

    public CommandResult waitUrl(String partialUrl) {
        return commandRunner.run(List.of("wait", "url", partialUrl));
    }

    public CommandResult waitSelector(String selector) {
        return commandRunner.run(List.of("wait", selector));
    }

    public CommandResult text() {
        return commandRunner.run(List.of("text"));
    }

    public CommandResult eval(String js) {
        return commandRunner.run(List.of("eval", js));
    }

    public CommandResult screenshot(Path outputPath, boolean annotate) {
        List<String> args = new ArrayList<>();
        args.add("screenshot");
        if (annotate) args.add("--annotate");
        args.add("-o");
        args.add(outputPath.toString());
        return commandRunner.run(args);
    }

    public CommandResult quit() {
        return commandRunner.run(List.of("quit"));
    }

    private String normalizeStrategy(String strategy) {
        if (strategy == null || strategy.isBlank()) return "text";
        return strategy.trim().toLowerCase();
    }
}
