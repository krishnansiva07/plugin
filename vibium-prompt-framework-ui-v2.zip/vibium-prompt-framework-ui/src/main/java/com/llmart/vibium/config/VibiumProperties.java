package com.llmart.vibium.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties(prefix = "vibium")
public class VibiumProperties {
    private String command = "vibium";
    private int commandTimeoutSeconds = 60;
    private String screenshotDir = "reports/screenshots";
    private boolean autoMapAfterAction = false;

    // Default runtime browser option used when UI/request does not specify it.
    private String defaultBrowser = "chrome";
    private boolean defaultHeadless = false;

    // If true, CommandRunner appends browser/mode arguments to each Vibium CLI call.
    // Keep templates configurable because Vibium CLI flags can differ between versions.
    private boolean runtimeBrowserOptionsEnabled = true;
    private boolean alwaysPassBrowserArg = false;
    private String browserArgTemplate = "--browser=%s";
    private String headedArg = "--headed";
    private String headlessArg = "--headless";

    public String getCommand() { return command; }
    public void setCommand(String command) { this.command = command; }
    public int getCommandTimeoutSeconds() { return commandTimeoutSeconds; }
    public void setCommandTimeoutSeconds(int commandTimeoutSeconds) { this.commandTimeoutSeconds = commandTimeoutSeconds; }
    public String getScreenshotDir() { return screenshotDir; }
    public void setScreenshotDir(String screenshotDir) { this.screenshotDir = screenshotDir; }
    public boolean isAutoMapAfterAction() { return autoMapAfterAction; }
    public void setAutoMapAfterAction(boolean autoMapAfterAction) { this.autoMapAfterAction = autoMapAfterAction; }
    public String getDefaultBrowser() { return defaultBrowser; }
    public void setDefaultBrowser(String defaultBrowser) { this.defaultBrowser = defaultBrowser; }
    public boolean isDefaultHeadless() { return defaultHeadless; }
    public void setDefaultHeadless(boolean defaultHeadless) { this.defaultHeadless = defaultHeadless; }
    public boolean isRuntimeBrowserOptionsEnabled() { return runtimeBrowserOptionsEnabled; }
    public void setRuntimeBrowserOptionsEnabled(boolean runtimeBrowserOptionsEnabled) { this.runtimeBrowserOptionsEnabled = runtimeBrowserOptionsEnabled; }
    public boolean isAlwaysPassBrowserArg() { return alwaysPassBrowserArg; }
    public void setAlwaysPassBrowserArg(boolean alwaysPassBrowserArg) { this.alwaysPassBrowserArg = alwaysPassBrowserArg; }
    public String getBrowserArgTemplate() { return browserArgTemplate; }
    public void setBrowserArgTemplate(String browserArgTemplate) { this.browserArgTemplate = browserArgTemplate; }
    public String getHeadedArg() { return headedArg; }
    public void setHeadedArg(String headedArg) { this.headedArg = headedArg; }
    public String getHeadlessArg() { return headlessArg; }
    public void setHeadlessArg(String headlessArg) { this.headlessArg = headlessArg; }
}
