package com.llmart.vibium.engine;

import com.llmart.vibium.model.ExecutionReport;
import com.llmart.vibium.model.StepStatus;
import com.llmart.vibium.model.TestCaseRequest;
import com.llmart.vibium.model.TestSuiteReport;
import com.llmart.vibium.model.TestSuiteRequest;
import com.llmart.vibium.report.SuiteHtmlReportWriter;
import com.llmart.vibium.report.SuiteJsonReportWriter;
import com.llmart.vibium.util.Slug;
import org.springframework.stereotype.Service;

import java.nio.file.Path;
import java.time.Duration;
import java.time.Instant;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;

@Service
public class SuiteExecutionEngine {
    private final PromptExecutionEngine promptExecutionEngine;
    private final SuiteHtmlReportWriter suiteHtmlReportWriter;
    private final SuiteJsonReportWriter suiteJsonReportWriter;

    public SuiteExecutionEngine(PromptExecutionEngine promptExecutionEngine,
                                SuiteHtmlReportWriter suiteHtmlReportWriter,
                                SuiteJsonReportWriter suiteJsonReportWriter) {
        this.promptExecutionEngine = promptExecutionEngine;
        this.suiteHtmlReportWriter = suiteHtmlReportWriter;
        this.suiteJsonReportWriter = suiteJsonReportWriter;
    }

    public TestSuiteReport execute(TestSuiteRequest request) {
        Instant suiteStart = Instant.now();
        TestSuiteReport suiteReport = new TestSuiteReport();
        suiteReport.setSuiteId(Slug.of(request.getSuiteName()) + "-" + UUID.randomUUID().toString().substring(0, 8));
        suiteReport.setSuiteName(request.getSuiteName());
        suiteReport.setBrowser(request.getBrowser());
        suiteReport.setHeadless(request.getHeadless());
        suiteReport.setStartedAt(suiteStart);

        for (int i = 0; i < request.getCases().size(); i++) {
            TestCaseRequest originalCase = request.getCases().get(i);
            TestCaseRequest mergedCase = mergeSuiteDefaults(request, originalCase, i + 1);
            ExecutionReport caseReport = promptExecutionEngine.execute(mergedCase);
            suiteReport.getCaseReports().add(caseReport);

            if (caseReport.getStatus() == StepStatus.FAILED && request.isStopOnFailure()) {
                suiteReport.setSkippedCases(request.getCases().size() - i - 1);
                break;
            }
        }

        suiteReport.setEndedAt(Instant.now());
        suiteReport.setDurationMs(Duration.between(suiteStart, suiteReport.getEndedAt()).toMillis());
        summarize(suiteReport, request.getCases().size());
        Path json = suiteJsonReportWriter.write(suiteReport);
        suiteReport.setJsonReportPath(json.toString());
        Path html = suiteHtmlReportWriter.write(suiteReport);
        suiteReport.setHtmlReportPath(html.toString());
        return suiteReport;
    }

    private TestCaseRequest mergeSuiteDefaults(TestSuiteRequest suite, TestCaseRequest testCase, int order) {
        TestCaseRequest merged = new TestCaseRequest();
        merged.setTestName(firstNonBlank(testCase.getTestName(), "TC" + String.format("%02d", order)));
        merged.setBaseUrl(firstNonBlank(testCase.getBaseUrl(), suite.getBaseUrl()));
        if (testCase.getPrompt() == null || testCase.getPrompt().isBlank()) {
            throw new IllegalArgumentException("Prompt is mandatory for suite case " + merged.getTestName());
        }
        merged.setPrompt(testCase.getPrompt());
        merged.setPlan(testCase.getPlan());
        merged.setTags(testCase.getTags());
        merged.setBrowser(firstNonBlank(testCase.getBrowser(), suite.getBrowser()));
        merged.setHeadless(testCase.getHeadless() != null ? testCase.getHeadless() : suite.getHeadless());

        Map<String, Object> mergedData = new LinkedHashMap<>();
        if (suite.getData() != null) mergedData.putAll(suite.getData());
        if (testCase.getData() != null) mergedData.putAll(testCase.getData());
        merged.setData(mergedData);
        return merged;
    }

    private void summarize(TestSuiteReport suiteReport, int requestedCaseCount) {
        int passed = (int) suiteReport.getCaseReports().stream().filter(r -> r.getStatus() == StepStatus.PASSED).count();
        int failed = (int) suiteReport.getCaseReports().stream().filter(r -> r.getStatus() == StepStatus.FAILED).count();
        int executed = suiteReport.getCaseReports().size();
        int skipped = Math.max(0, requestedCaseCount - executed);
        suiteReport.setTotalCases(requestedCaseCount);
        suiteReport.setPassedCases(passed);
        suiteReport.setFailedCases(failed);
        suiteReport.setSkippedCases(Math.max(suiteReport.getSkippedCases(), skipped));
        suiteReport.setStatus(failed > 0 ? StepStatus.FAILED : StepStatus.PASSED);
    }

    private String firstNonBlank(String first, String second) {
        return first != null && !first.isBlank() ? first : second;
    }
}
