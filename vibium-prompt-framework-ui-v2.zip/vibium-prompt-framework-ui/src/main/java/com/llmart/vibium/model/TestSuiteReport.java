package com.llmart.vibium.model;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

public class TestSuiteReport {
    private String suiteId;
    private String suiteName;
    private StepStatus status;
    private int totalCases;
    private int passedCases;
    private int failedCases;
    private int skippedCases;
    private long durationMs;
    private Instant startedAt;
    private Instant endedAt;
    private String htmlReportPath;
    private String jsonReportPath;
    private String browser;
    private Boolean headless;
    private List<ExecutionReport> caseReports = new ArrayList<>();

    public String getSuiteId() { return suiteId; }
    public void setSuiteId(String suiteId) { this.suiteId = suiteId; }
    public String getSuiteName() { return suiteName; }
    public void setSuiteName(String suiteName) { this.suiteName = suiteName; }
    public StepStatus getStatus() { return status; }
    public void setStatus(StepStatus status) { this.status = status; }
    public int getTotalCases() { return totalCases; }
    public void setTotalCases(int totalCases) { this.totalCases = totalCases; }
    public int getPassedCases() { return passedCases; }
    public void setPassedCases(int passedCases) { this.passedCases = passedCases; }
    public int getFailedCases() { return failedCases; }
    public void setFailedCases(int failedCases) { this.failedCases = failedCases; }
    public int getSkippedCases() { return skippedCases; }
    public void setSkippedCases(int skippedCases) { this.skippedCases = skippedCases; }
    public long getDurationMs() { return durationMs; }
    public void setDurationMs(long durationMs) { this.durationMs = durationMs; }
    public Instant getStartedAt() { return startedAt; }
    public void setStartedAt(Instant startedAt) { this.startedAt = startedAt; }
    public Instant getEndedAt() { return endedAt; }
    public void setEndedAt(Instant endedAt) { this.endedAt = endedAt; }
    public String getHtmlReportPath() { return htmlReportPath; }
    public void setHtmlReportPath(String htmlReportPath) { this.htmlReportPath = htmlReportPath; }
    public String getJsonReportPath() { return jsonReportPath; }
    public void setJsonReportPath(String jsonReportPath) { this.jsonReportPath = jsonReportPath; }
    public String getBrowser() { return browser; }
    public void setBrowser(String browser) { this.browser = browser; }
    public Boolean getHeadless() { return headless; }
    public void setHeadless(Boolean headless) { this.headless = headless; }
    public List<ExecutionReport> getCaseReports() { return caseReports; }
    public void setCaseReports(List<ExecutionReport> caseReports) { this.caseReports = caseReports; }
}
