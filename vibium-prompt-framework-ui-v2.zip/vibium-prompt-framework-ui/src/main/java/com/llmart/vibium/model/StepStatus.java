package com.llmart.vibium.model;

public enum StepStatus {
    PASSED, FAILED, SKIPPED
}
