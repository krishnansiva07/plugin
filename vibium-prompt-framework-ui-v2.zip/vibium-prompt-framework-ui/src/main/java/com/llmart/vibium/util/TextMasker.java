package com.llmart.vibium.util;

import java.util.Map;

public final class TextMasker {
    private TextMasker() {}

    public static String maskSecrets(String input, Map<String, Object> data) {
        if (input == null) return null;
        String masked = input;
        if (data != null) {
            for (Map.Entry<String, Object> entry : data.entrySet()) {
                String key = entry.getKey() == null ? "" : entry.getKey().toLowerCase();
                Object value = entry.getValue();
                if (value != null && (key.contains("password") || key.contains("token") || key.contains("secret") || key.contains("key"))) {
                    String plain = String.valueOf(value);
                    if (!plain.isBlank()) masked = masked.replace(plain, "****");
                }
            }
        }
        return masked;
    }
}
