package com.llmart.vibium.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ActionStep {
    private int order;
    private String name;
    private ActionType action;
    private String strategy;   // text, label, placeholder, role, css, ref
    private String target;     // Login, Email, .btn-primary, @e1
    private String value;      // value to type/select/url/key/js
    private String saveAs;     // variable name to store @e ref
    private boolean optional;

    public int getOrder() { return order; }
    public void setOrder(int order) { this.order = order; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public ActionType getAction() { return action; }
    public void setAction(ActionType action) { this.action = action; }
    public String getStrategy() { return strategy; }
    public void setStrategy(String strategy) { this.strategy = strategy; }
    public String getTarget() { return target; }
    public void setTarget(String target) { this.target = target; }
    public String getValue() { return value; }
    public void setValue(String value) { this.value = value; }
    public String getSaveAs() { return saveAs; }
    public void setSaveAs(String saveAs) { this.saveAs = saveAs; }
    public boolean isOptional() { return optional; }
    public void setOptional(boolean optional) { this.optional = optional; }
}
