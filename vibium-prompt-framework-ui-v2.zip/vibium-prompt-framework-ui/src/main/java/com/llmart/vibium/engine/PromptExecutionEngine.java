package com.llmart.vibium.engine;

import com.llmart.vibium.config.FrameworkProperties;
import com.llmart.vibium.config.VibiumProperties;
import com.llmart.vibium.model.*;
import com.llmart.vibium.planner.PromptPlanner;
import com.llmart.vibium.report.HtmlReportWriter;
import com.llmart.vibium.report.JsonReportWriter;
import com.llmart.vibium.util.RefParser;
import com.llmart.vibium.util.Slug;
import com.llmart.vibium.util.TextMasker;
import com.llmart.vibium.vibium.VibiumCliClient;
import org.springframework.stereotype.Service;

import java.net.URI;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.time.Instant;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@Service
public class PromptExecutionEngine {
    private final PromptPlanner planner;
    private final VibiumCliClient vibium;
    private final VibiumProperties vibiumProperties;
    private final FrameworkProperties frameworkProperties;
    private final HtmlReportWriter htmlReportWriter;
    private final JsonReportWriter jsonReportWriter;

    public PromptExecutionEngine(PromptPlanner planner,
                                 VibiumCliClient vibium,
                                 VibiumProperties vibiumProperties,
                                 FrameworkProperties frameworkProperties,
                                 HtmlReportWriter htmlReportWriter,
                                 JsonReportWriter jsonReportWriter) {
        this.planner = planner;
        this.vibium = vibium;
        this.vibiumProperties = vibiumProperties;
        this.frameworkProperties = frameworkProperties;
        this.htmlReportWriter = htmlReportWriter;
        this.jsonReportWriter = jsonReportWriter;
    }

    public ExecutionReport execute(TestCaseRequest request) {
        validateAllowlist(request.getBaseUrl());

        Instant runStart = Instant.now();
        String runId = Slug.of(request.getTestName()) + "-" + UUID.randomUUID().toString().substring(0, 8);
        ExecutionReport report = new ExecutionReport();
        report.setRunId(runId);
        report.setTestName(request.getTestName());
        report.setBaseUrl(request.getBaseUrl());
        report.setOriginalPrompt(request.getPrompt());
        report.setTestData(request.getData());
        report.setStartedAt(runStart);

        String browser = firstNonBlank(request.getBrowser(), vibiumProperties.getDefaultBrowser());
        Boolean headless = request.getHeadless() != null ? request.getHeadless() : vibiumProperties.isDefaultHeadless();
        report.setBrowser(browser);
        report.setHeadless(headless);

        ActionPlan plan = planner.createPlan(request);
        report.setPlan(plan);
        vibium.configureForRun(browser, headless);

        Map<String, String> variables = new HashMap<>();
        if (request.getBaseUrl() != null) variables.put("baseUrl", request.getBaseUrl());
        if (request.getData() != null) {
            request.getData().forEach((k, v) -> variables.put(k, v == null ? "" : String.valueOf(v)));
        }

        try {
            for (ActionStep step : plan.getSteps()) {
                StepResult result = executeStep(step, variables, request.getData(), runId);
                report.getStepResults().add(result);
                if (result.getStatus() == StepStatus.FAILED && frameworkProperties.isFailFast() && !step.isOptional()) {
                    break;
                }
            }
        } finally {
            try {
                vibium.quit();
            } catch (Exception ignored) {
                // Not a test failure. Some Vibium versions keep sessions open for inspection.
            } finally {
                vibium.clearRunConfiguration();
            }
            report.setEndedAt(Instant.now());
            report.setDurationMs(Duration.between(runStart, report.getEndedAt()).toMillis());
            summarize(report);
            Path json = jsonReportWriter.write(report);
            report.setJsonReportPath(json.toString());
            Path html = htmlReportWriter.write(report);
            report.setHtmlReportPath(html.toString());
        }
        return report;
    }

    private StepResult executeStep(ActionStep step, Map<String, String> variables, Map<String, Object> testData, String runId) {
        StepResult result = new StepResult();
        result.setOrder(step.getOrder());
        result.setName(step.getName());
        result.setAction(step.getAction());
        result.setStartedAt(Instant.now());

        try {
            CommandResult commandResult = switch (step.getAction()) {
                case GO -> vibium.go(resolve(step.getValue(), variables));
                case MAP -> vibium.map();
                case FIND -> handleFind(step, variables);
                case CLICK -> vibium.click(resolveTarget(step, variables));
                case FILL -> vibium.fill(resolveTarget(step, variables), resolve(step.getValue(), variables));
                case SELECT -> vibium.select(resolveTarget(step, variables), resolve(step.getValue(), variables));
                case CHECK -> vibium.check(resolveTarget(step, variables));
                case PRESS -> vibium.press(resolve(step.getValue(), variables));
                case WAIT_TEXT -> vibium.waitText(resolve(firstNonBlank(step.getValue(), step.getTarget()), variables));
                case WAIT_URL -> vibium.waitUrl(resolve(firstNonBlank(step.getValue(), step.getTarget()), variables));
                case WAIT_SELECTOR -> vibium.waitSelector(resolve(firstNonBlank(step.getValue(), step.getTarget()), variables));
                case VERIFY_TEXT -> verifyText(resolve(firstNonBlank(step.getValue(), step.getTarget()), variables));
                case VERIFY_URL_CONTAINS -> verifyUrlContains(resolve(firstNonBlank(step.getValue(), step.getTarget()), variables));
                case SCREENSHOT -> captureScreenshot(step, runId, result, variables);
                case TEXT -> vibium.text();
                case EVAL -> vibium.eval(resolve(step.getValue(), variables));
                case QUIT -> vibium.quit();
            };

            result.setCommand(TextMasker.maskSecrets(commandResult.getCommand(), testData));
            result.setOutput(TextMasker.maskSecrets(commandResult.getStdout(), testData));
            result.setError(TextMasker.maskSecrets(commandResult.getStderr(), testData));
            result.setDurationMs(commandResult.getDurationMs());

            if (commandResult.isSuccess() || step.isOptional()) {
                result.setStatus(commandResult.isSuccess() ? StepStatus.PASSED : StepStatus.SKIPPED);
            } else {
                result.setStatus(StepStatus.FAILED);
            }

            if (vibiumProperties.isAutoMapAfterAction()
                    && result.getStatus() == StepStatus.PASSED
                    && step.getAction() != ActionType.MAP
                    && step.getAction() != ActionType.SCREENSHOT) {
                vibium.map();
            }
        } catch (Exception e) {
            result.setStatus(step.isOptional() ? StepStatus.SKIPPED : StepStatus.FAILED);
            result.setError(e.getMessage());
        } finally {
            result.setEndedAt(Instant.now());
            if (result.getDurationMs() == 0) {
                result.setDurationMs(Duration.between(result.getStartedAt(), result.getEndedAt()).toMillis());
            }
        }
        return result;
    }

    private CommandResult handleFind(ActionStep step, Map<String, String> variables) {
        CommandResult result = vibium.find(step.getStrategy(), resolve(step.getTarget(), variables));
        if (result.isSuccess() && step.getSaveAs() != null && !step.getSaveAs().isBlank()) {
            RefParser.firstElementRef(result.getStdout()).ifPresent(ref -> variables.put(step.getSaveAs(), ref));
        }
        return result;
    }

    private CommandResult verifyText(String expectedText) {
        CommandResult text = vibium.text();
        if (!text.isSuccess()) return text;
        boolean contains = text.getStdout() != null && text.getStdout().toLowerCase().contains(expectedText.toLowerCase());
        if (contains) return text;
        return new CommandResult(10, text.getCommand(), text.getStdout(), "Expected text not found: " + expectedText, text.getDurationMs());
    }

    private CommandResult verifyUrlContains(String partialUrl) {
        CommandResult url = vibium.eval("window.location.href");
        if (!url.isSuccess()) return url;
        boolean contains = url.getStdout() != null && url.getStdout().contains(partialUrl);
        if (contains) return url;
        return new CommandResult(11, url.getCommand(), url.getStdout(), "URL does not contain: " + partialUrl, url.getDurationMs());
    }

    private CommandResult captureScreenshot(ActionStep step, String runId, StepResult result, Map<String, String> variables) throws Exception {
        Files.createDirectories(Path.of(vibiumProperties.getScreenshotDir(), runId));
        String name = Slug.of(resolve(firstNonBlank(step.getValue(), step.getName()), variables));
        Path output = Path.of(vibiumProperties.getScreenshotDir(), runId, name + ".png");
        CommandResult commandResult = vibium.screenshot(output, true);
        if (commandResult.isSuccess()) {
            result.setScreenshotPath(output.toString());
        }
        return commandResult;
    }

    private String resolveTarget(ActionStep step, Map<String, String> variables) {
        String target = resolve(step.getTarget(), variables);
        if (target != null && target.startsWith("@e")) return target;
        if ("ref".equalsIgnoreCase(step.getStrategy())) return target;
        if (target == null || target.isBlank()) throw new IllegalArgumentException("Missing target for step " + step.getName());
        CommandResult find = vibium.find(step.getStrategy(), target);
        if (!find.isSuccess()) throw new IllegalStateException("Unable to find target: " + target + " -> " + find.getStderr());
        return RefParser.firstElementRef(find.getStdout()).orElse(target);
    }

    private String resolve(String input, Map<String, String> variables) {
        if (input == null) return "";
        String value = input;
        for (Map.Entry<String, String> entry : variables.entrySet()) {
            value = value.replace("${" + entry.getKey() + "}", entry.getValue());
        }
        return value;
    }

    private String firstNonBlank(String first, String second) {
        return first != null && !first.isBlank() ? first : second;
    }

    private void summarize(ExecutionReport report) {
        int total = report.getStepResults().size();
        int passed = (int) report.getStepResults().stream().filter(s -> s.getStatus() == StepStatus.PASSED).count();
        int failed = (int) report.getStepResults().stream().filter(s -> s.getStatus() == StepStatus.FAILED).count();
        report.setTotalSteps(total);
        report.setPassedSteps(passed);
        report.setFailedSteps(failed);
        report.setStatus(failed > 0 ? StepStatus.FAILED : StepStatus.PASSED);
    }

    private void validateAllowlist(String baseUrl) {
        String allowlist = frameworkProperties.getBaseUrlAllowlist();
        if (allowlist == null || allowlist.isBlank() || baseUrl == null || baseUrl.isBlank()) return;
        String host = URI.create(baseUrl).getHost();
        boolean allowed = java.util.Arrays.stream(allowlist.split(","))
                .map(String::trim)
                .filter(s -> !s.isBlank())
                .anyMatch(host::endsWith);
        if (!allowed) throw new IllegalArgumentException("Base URL host is not allowlisted: " + host);
    }
}
