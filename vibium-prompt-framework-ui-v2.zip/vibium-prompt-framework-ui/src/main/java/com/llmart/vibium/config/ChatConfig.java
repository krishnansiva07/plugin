package com.llmart.vibium.config;

import dev.langchain4j.model.chat.ChatLanguageModel;
import dev.langchain4j.model.openai.OpenAiChatModel;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.time.Duration;

@Configuration
public class ChatConfig {

    @Bean
    public ChatLanguageModel chatLanguageModel(LlmProperties props) {
        if (props.getApiKey() == null || props.getApiKey().isBlank()) {
            throw new IllegalStateException("LLM_API_KEY is missing. Set it as an environment variable, not in application.properties.");
        }
        return OpenAiChatModel.builder()
                .apiKey(props.getApiKey())
                .modelName(props.getModelName())
                .baseUrl(props.getBaseUrl())
                .temperature(props.getTemperature())
                .maxTokens(props.getMaxTokens())
                .timeout(Duration.ofSeconds(props.getTimeoutSeconds()))
                .build();
    }
}
