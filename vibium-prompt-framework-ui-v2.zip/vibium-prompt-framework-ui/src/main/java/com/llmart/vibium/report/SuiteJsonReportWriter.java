package com.llmart.vibium.report;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.llmart.vibium.config.FrameworkProperties;
import com.llmart.vibium.model.TestSuiteReport;
import org.springframework.stereotype.Component;

import java.nio.file.Files;
import java.nio.file.Path;

@Component
public class SuiteJsonReportWriter {
    private final ObjectMapper objectMapper;
    private final FrameworkProperties properties;

    public SuiteJsonReportWriter(ObjectMapper objectMapper, FrameworkProperties properties) {
        this.objectMapper = objectMapper;
        this.properties = properties;
    }

    public Path write(TestSuiteReport report) {
        try {
            Path reportDir = Path.of(properties.getReportDir(), "suites", report.getSuiteId());
            Files.createDirectories(reportDir);
            Path file = reportDir.resolve("suite-report.json");
            objectMapper.writerWithDefaultPrettyPrinter().writeValue(file.toFile(), report);
            return file;
        } catch (Exception e) {
            throw new IllegalStateException("Unable to write suite JSON report", e);
        }
    }
}
