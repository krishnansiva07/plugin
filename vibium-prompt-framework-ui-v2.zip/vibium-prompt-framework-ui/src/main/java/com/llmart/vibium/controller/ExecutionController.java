package com.llmart.vibium.controller;

import com.llmart.vibium.config.FrameworkProperties;
import com.llmart.vibium.config.VibiumProperties;
import com.llmart.vibium.engine.PromptExecutionEngine;
import com.llmart.vibium.engine.SuiteExecutionEngine;
import com.llmart.vibium.model.ExecutionReport;
import com.llmart.vibium.model.TestCaseRequest;
import com.llmart.vibium.model.TestSuiteReport;
import com.llmart.vibium.model.TestSuiteRequest;
import com.llmart.vibium.upload.SuiteFileParser;
import jakarta.validation.Valid;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.regex.Pattern;

@RestController
@RequestMapping("/api/v1/vibium")
public class ExecutionController {
    private static final Pattern SAFE_NAME = Pattern.compile("^[a-zA-Z0-9._-]+$");

    private final PromptExecutionEngine engine;
    private final SuiteExecutionEngine suiteEngine;
    private final FrameworkProperties frameworkProperties;
    private final VibiumProperties vibiumProperties;
    private final SuiteFileParser suiteFileParser;

    public ExecutionController(PromptExecutionEngine engine,
                               SuiteExecutionEngine suiteEngine,
                               FrameworkProperties frameworkProperties,
                               VibiumProperties vibiumProperties,
                               SuiteFileParser suiteFileParser) {
        this.engine = engine;
        this.suiteEngine = suiteEngine;
        this.frameworkProperties = frameworkProperties;
        this.vibiumProperties = vibiumProperties;
        this.suiteFileParser = suiteFileParser;
    }

    @PostMapping("/execute")
    public ResponseEntity<ExecutionReport> execute(@Valid @RequestBody TestCaseRequest request) {
        return ResponseEntity.ok(engine.execute(request));
    }

    @PostMapping("/execute-suite")
    public ResponseEntity<TestSuiteReport> executeSuite(@Valid @RequestBody TestSuiteRequest request) {
        return ResponseEntity.ok(suiteEngine.execute(request));
    }

    @PostMapping(value = "/execute-suite-file", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<TestSuiteReport> executeSuiteFile(@RequestPart("file") MultipartFile file,
                                                            @RequestParam(required = false) String suiteName,
                                                            @RequestParam(required = false) String baseUrl,
                                                            @RequestParam(required = false) String browser,
                                                            @RequestParam(required = false) Boolean headless,
                                                            @RequestParam(required = false) Boolean stopOnFailure) throws Exception {
        if (file == null || file.isEmpty()) {
            throw new IllegalArgumentException("Please upload a non-empty JSON file.");
        }
        TestSuiteRequest request = suiteFileParser.parse(file.getOriginalFilename(), file.getBytes());
        if (suiteName != null && !suiteName.isBlank()) request.setSuiteName(suiteName);
        if (baseUrl != null && !baseUrl.isBlank()) request.setBaseUrl(baseUrl);
        if (browser != null && !browser.isBlank()) request.setBrowser(browser);
        if (headless != null) request.setHeadless(headless);
        if (stopOnFailure != null) request.setStopOnFailure(stopOnFailure);
        return ResponseEntity.ok(suiteEngine.execute(request));
    }

    @GetMapping(value = "/reports/{runId}/html", produces = MediaType.TEXT_HTML_VALUE)
    public ResponseEntity<String> caseHtmlReport(@PathVariable String runId) throws Exception {
        validateSafe(runId);
        Path path = Path.of(frameworkProperties.getReportDir(), runId, "execution-report.html").normalize();
        return ResponseEntity.ok(Files.readString(path));
    }

    @GetMapping(value = "/reports/{runId}/json", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<String> caseJsonReport(@PathVariable String runId) throws Exception {
        validateSafe(runId);
        Path path = Path.of(frameworkProperties.getReportDir(), runId, "execution-report.json").normalize();
        return ResponseEntity.ok(Files.readString(path));
    }

    @GetMapping(value = "/reports/suites/{suiteId}/html", produces = MediaType.TEXT_HTML_VALUE)
    public ResponseEntity<String> suiteHtmlReport(@PathVariable String suiteId) throws Exception {
        validateSafe(suiteId);
        Path path = Path.of(frameworkProperties.getReportDir(), "suites", suiteId, "suite-report.html").normalize();
        return ResponseEntity.ok(Files.readString(path));
    }

    @GetMapping(value = "/reports/suites/{suiteId}/json", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<String> suiteJsonReport(@PathVariable String suiteId) throws Exception {
        validateSafe(suiteId);
        Path path = Path.of(frameworkProperties.getReportDir(), "suites", suiteId, "suite-report.json").normalize();
        return ResponseEntity.ok(Files.readString(path));
    }

    @GetMapping(value = "/reports/{runId}/screenshots/{fileName:.+}", produces = MediaType.IMAGE_PNG_VALUE)
    public ResponseEntity<Resource> screenshot(@PathVariable String runId, @PathVariable String fileName) {
        validateSafe(runId);
        validateSafe(fileName);
        Path path = Path.of(vibiumProperties.getScreenshotDir(), runId, fileName).normalize();
        return ResponseEntity.ok(new FileSystemResource(path));
    }

    @GetMapping("/health")
    public ResponseEntity<String> health() {
        return ResponseEntity.ok("Vibium Prompt Framework UI is running");
    }

    private void validateSafe(String value) {
        if (value == null || !SAFE_NAME.matcher(value).matches()) {
            throw new IllegalArgumentException("Invalid report identifier");
        }
    }
}
