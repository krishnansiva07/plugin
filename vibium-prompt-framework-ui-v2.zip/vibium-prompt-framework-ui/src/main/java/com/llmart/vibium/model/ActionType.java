package com.llmart.vibium.model;

public enum ActionType {
    GO,
    MAP,
    FIND,
    CLICK,
    FILL,
    SELECT,
    CHECK,
    PRESS,
    WAIT_TEXT,
    WAIT_URL,
    WAIT_SELECTOR,
    VERIFY_TEXT,
    VERIFY_URL_CONTAINS,
    SCREENSHOT,
    TEXT,
    EVAL,
    QUIT
}
