package com.llmart.vibium.report;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.llmart.vibium.config.FrameworkProperties;
import com.llmart.vibium.model.ExecutionReport;
import org.springframework.stereotype.Component;

import java.nio.file.Files;
import java.nio.file.Path;

@Component
public class JsonReportWriter {
    private final ObjectMapper objectMapper;
    private final FrameworkProperties properties;

    public JsonReportWriter(ObjectMapper objectMapper, FrameworkProperties properties) {
        this.objectMapper = objectMapper;
        this.properties = properties;
    }

    public Path write(ExecutionReport report) {
        try {
            Path reportDir = Path.of(properties.getReportDir(), report.getRunId());
            Files.createDirectories(reportDir);
            Path file = reportDir.resolve("execution-report.json");
            objectMapper.writerWithDefaultPrettyPrinter().writeValue(file.toFile(), report);
            return file;
        } catch (Exception e) {
            throw new IllegalStateException("Unable to write JSON report", e);
        }
    }
}
