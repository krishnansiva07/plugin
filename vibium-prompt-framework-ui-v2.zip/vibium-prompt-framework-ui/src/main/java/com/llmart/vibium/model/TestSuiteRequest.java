package com.llmart.vibium.model;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class TestSuiteRequest {
    @NotBlank
    private String suiteName;
    private String baseUrl;
    private Map<String, Object> data = new LinkedHashMap<>();
    private boolean stopOnFailure;

    // Suite-level runtime browser options. Individual cases can override these values.
    private String browser;
    private Boolean headless;

    @NotEmpty
    private List<TestCaseRequest> cases = new ArrayList<>();

    public String getSuiteName() { return suiteName; }
    public void setSuiteName(String suiteName) { this.suiteName = suiteName; }
    public String getBaseUrl() { return baseUrl; }
    public void setBaseUrl(String baseUrl) { this.baseUrl = baseUrl; }
    public Map<String, Object> getData() { return data; }
    public void setData(Map<String, Object> data) { this.data = data; }
    public boolean isStopOnFailure() { return stopOnFailure; }
    public void setStopOnFailure(boolean stopOnFailure) { this.stopOnFailure = stopOnFailure; }
    public String getBrowser() { return browser; }
    public void setBrowser(String browser) { this.browser = browser; }
    public Boolean getHeadless() { return headless; }
    public void setHeadless(Boolean headless) { this.headless = headless; }
    public List<TestCaseRequest> getCases() { return cases; }
    public void setCases(List<TestCaseRequest> cases) { this.cases = cases; }
}
