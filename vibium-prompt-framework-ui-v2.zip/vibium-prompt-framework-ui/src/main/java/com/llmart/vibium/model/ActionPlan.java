package com.llmart.vibium.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.util.ArrayList;
import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ActionPlan {
    private String testName;
    private String description;
    private List<ActionStep> steps = new ArrayList<>();

    public String getTestName() { return testName; }
    public void setTestName(String testName) { this.testName = testName; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public List<ActionStep> getSteps() { return steps; }
    public void setSteps(List<ActionStep> steps) { this.steps = steps; }
}
