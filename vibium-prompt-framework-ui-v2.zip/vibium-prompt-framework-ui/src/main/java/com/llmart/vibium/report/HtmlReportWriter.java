package com.llmart.vibium.report;

import com.llmart.vibium.config.FrameworkProperties;
import com.llmart.vibium.model.ExecutionReport;
import com.llmart.vibium.model.StepResult;
import com.llmart.vibium.model.StepStatus;
import org.springframework.stereotype.Component;

import java.nio.file.Files;
import java.nio.file.Path;

@Component
public class HtmlReportWriter {
    private final FrameworkProperties properties;

    public HtmlReportWriter(FrameworkProperties properties) {
        this.properties = properties;
    }

    public Path write(ExecutionReport report) {
        try {
            Path reportDir = Path.of(properties.getReportDir(), report.getRunId());
            Files.createDirectories(reportDir);
            Path file = reportDir.resolve("execution-report.html");
            Files.writeString(file, html(report));
            return file;
        } catch (Exception e) {
            throw new IllegalStateException("Unable to write HTML report", e);
        }
    }

    private String html(ExecutionReport report) {
        StringBuilder rows = new StringBuilder();
        for (StepResult s : report.getStepResults()) {
            rows.append("<tr class='").append(css(s.getStatus())).append("'>")
                    .append("<td>").append(s.getOrder()).append("</td>")
                    .append("<td>").append(esc(s.getName())).append("</td>")
                    .append("<td>").append(s.getAction()).append("</td>")
                    .append("<td><span class='badge ").append(css(s.getStatus())).append("'>").append(s.getStatus()).append("</span></td>")
                    .append("<td>").append(s.getDurationMs()).append(" ms</td>")
                    .append("<td><pre>").append(esc(s.getCommand())).append("</pre></td>")
                    .append("<td><details><summary>Output</summary><pre>").append(esc(limit(s.getOutput()))).append("</pre></details></td>")
                    .append("<td><pre>").append(esc(limit(s.getError()))).append("</pre></td>")
                    .append("<td>").append(screenshotLink(report, s)).append("</td>")
                    .append("</tr>");
        }

        return """
                <!DOCTYPE html>
                <html>
                <head>
                    <meta charset="UTF-8">
                    <title>Vibium Execution Report</title>
                    <style>
                        body { font-family: Arial, sans-serif; margin: 24px; background: #f7f8fa; color: #1f2937; }
                        .card { background: white; border-radius: 12px; padding: 18px; margin-bottom: 18px; box-shadow: 0 2px 8px rgba(0,0,0,.08); }
                        h1 { margin: 0 0 8px 0; }
                        .summary { display: flex; gap: 12px; flex-wrap: wrap; }
                        .metric { padding: 12px 16px; border-radius: 10px; background: #f3f4f6; min-width: 120px; }
                        .metric strong { display:block; font-size: 22px; }
                        table { width: 100%%; border-collapse: collapse; background: white; }
                        th, td { border-bottom: 1px solid #e5e7eb; padding: 10px; vertical-align: top; text-align: left; }
                        th { background: #111827; color: white; position: sticky; top: 0; }
                        pre { white-space: pre-wrap; word-break: break-word; max-width: 320px; margin: 0; }
                        .badge { padding: 5px 9px; border-radius: 999px; color: white; font-size: 12px; }
                        .passed { background: #16a34a; color: white; }
                        .failed { background: #dc2626; color: white; }
                        .skipped { background: #ca8a04; color: white; }
                        .status-passed { color: #16a34a; }
                        .status-failed { color: #dc2626; }
                        a { color: #2563eb; }
                    </style>
                </head>
                <body>
                  <div class="card">
                    <h1>Vibium Prompt Execution Report</h1>
                    <h2 class="status-%s">%s</h2>
                    <p><b>Run ID:</b> %s</p>
                    <p><b>Test:</b> %s</p>
                    <p><b>Base URL:</b> %s</p>
                    <p><b>Browser:</b> %s</p>
                    <p><b>Mode:</b> %s</p>
                    <p><b>Duration:</b> %d ms</p>
                  </div>
                  <div class="card summary">
                    <div class="metric"><strong>%d</strong>Total Steps</div>
                    <div class="metric"><strong>%d</strong>Passed</div>
                    <div class="metric"><strong>%d</strong>Failed</div>
                  </div>
                  <div class="card">
                    <h3>Original Prompt</h3>
                    <pre>%s</pre>
                  </div>
                  <div class="card">
                    <h3>Step Details</h3>
                    <table>
                      <thead><tr><th>#</th><th>Step</th><th>Action</th><th>Status</th><th>Time</th><th>Command</th><th>Output</th><th>Error</th><th>Evidence</th></tr></thead>
                      <tbody>%s</tbody>
                    </table>
                  </div>
                </body>
                </html>
                """.formatted(
                report.getStatus().name().toLowerCase(),
                report.getStatus(),
                esc(report.getRunId()),
                esc(report.getTestName()),
                esc(report.getBaseUrl()),
                esc(report.getBrowser()),
                Boolean.TRUE.equals(report.getHeadless()) ? "Headless" : "Headed",
                report.getDurationMs(),
                report.getTotalSteps(),
                report.getPassedSteps(),
                report.getFailedSteps(),
                esc(report.getOriginalPrompt()),
                rows
        );
    }

    private String screenshotLink(ExecutionReport report, StepResult s) {
        if (s.getScreenshotPath() == null || s.getScreenshotPath().isBlank()) return "";
        String fileName = Path.of(s.getScreenshotPath()).getFileName().toString();
        String href = "/api/v1/vibium/reports/" + esc(report.getRunId()) + "/screenshots/" + esc(fileName);
        return "<a href='" + href + "' target='_blank'>Open screenshot</a>";
    }

    private String css(StepStatus status) {
        if (status == null) return "skipped";
        return status.name().toLowerCase();
    }

    private String limit(String s) {
        if (s == null) return "";
        return s.length() > 5000 ? s.substring(0, 5000) + "\n...truncated..." : s;
    }

    private String esc(String s) {
        if (s == null) return "";
        return s.replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;")
                .replace("\"", "&quot;")
                .replace("'", "&#39;");
    }
}
