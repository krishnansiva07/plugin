package com.llmart.vibium.model;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class ExecutionReport {
    private String runId;
    private String testName;
    private String baseUrl;
    private String originalPrompt;
    private Map<String, Object> testData;
    private ActionPlan plan;
    private StepStatus status;
    private int totalSteps;
    private int passedSteps;
    private int failedSteps;
    private long durationMs;
    private Instant startedAt;
    private Instant endedAt;
    private String htmlReportPath;
    private String jsonReportPath;
    private String browser;
    private Boolean headless;
    private List<StepResult> stepResults = new ArrayList<>();

    public String getRunId() { return runId; }
    public void setRunId(String runId) { this.runId = runId; }
    public String getTestName() { return testName; }
    public void setTestName(String testName) { this.testName = testName; }
    public String getBaseUrl() { return baseUrl; }
    public void setBaseUrl(String baseUrl) { this.baseUrl = baseUrl; }
    public String getOriginalPrompt() { return originalPrompt; }
    public void setOriginalPrompt(String originalPrompt) { this.originalPrompt = originalPrompt; }
    public Map<String, Object> getTestData() { return testData; }
    public void setTestData(Map<String, Object> testData) { this.testData = testData; }
    public ActionPlan getPlan() { return plan; }
    public void setPlan(ActionPlan plan) { this.plan = plan; }
    public StepStatus getStatus() { return status; }
    public void setStatus(StepStatus status) { this.status = status; }
    public int getTotalSteps() { return totalSteps; }
    public void setTotalSteps(int totalSteps) { this.totalSteps = totalSteps; }
    public int getPassedSteps() { return passedSteps; }
    public void setPassedSteps(int passedSteps) { this.passedSteps = passedSteps; }
    public int getFailedSteps() { return failedSteps; }
    public void setFailedSteps(int failedSteps) { this.failedSteps = failedSteps; }
    public long getDurationMs() { return durationMs; }
    public void setDurationMs(long durationMs) { this.durationMs = durationMs; }
    public Instant getStartedAt() { return startedAt; }
    public void setStartedAt(Instant startedAt) { this.startedAt = startedAt; }
    public Instant getEndedAt() { return endedAt; }
    public void setEndedAt(Instant endedAt) { this.endedAt = endedAt; }
    public String getHtmlReportPath() { return htmlReportPath; }
    public void setHtmlReportPath(String htmlReportPath) { this.htmlReportPath = htmlReportPath; }
    public String getJsonReportPath() { return jsonReportPath; }
    public void setJsonReportPath(String jsonReportPath) { this.jsonReportPath = jsonReportPath; }
    public String getBrowser() { return browser; }
    public void setBrowser(String browser) { this.browser = browser; }
    public Boolean getHeadless() { return headless; }
    public void setHeadless(Boolean headless) { this.headless = headless; }
    public List<StepResult> getStepResults() { return stepResults; }
    public void setStepResults(List<StepResult> stepResults) { this.stepResults = stepResults; }
}
