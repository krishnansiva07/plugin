package com.llmart.vibium.upload;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.llmart.vibium.model.TestCaseRequest;
import com.llmart.vibium.model.TestSuiteRequest;
import com.llmart.vibium.util.Slug;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Component
public class SuiteFileParser {
    private final ObjectMapper objectMapper;

    public SuiteFileParser(ObjectMapper objectMapper) {
        this.objectMapper = objectMapper;
    }

    public TestSuiteRequest parse(String fileName, byte[] bytes) {
        try {
            JsonNode root = objectMapper.readTree(bytes);
            TestSuiteRequest suite = new TestSuiteRequest();
            suite.setSuiteName(defaultSuiteName(fileName));
            suite.setData(new LinkedHashMap<>());

            if (root == null || root.isNull()) {
                throw new IllegalArgumentException("Uploaded JSON file is empty.");
            }

            if (root.isArray()) {
                suite.setCases(parseCases(root));
                return suite;
            }

            if (!root.isObject()) {
                throw new IllegalArgumentException("JSON must be either an object or an array of test cases/prompts.");
            }

            suite.setSuiteName(firstText(root, suite.getSuiteName(), "suiteName", "name", "title"));
            suite.setBaseUrl(firstText(root, null, "baseUrl", "url", "applicationUrl"));
            suite.setBrowser(firstText(root, null, "browser", "browserName"));
            suite.setHeadless(firstBoolean(root, null, "headless"));
            suite.setStopOnFailure(firstBoolean(root, false, "stopOnFailure", "failFast"));
            suite.setData(asMap(root.get("data")));

            JsonNode casesNode = firstNode(root, "cases", "testCases", "tests", "scenarios");
            if (casesNode != null) {
                suite.setCases(parseCases(casesNode));
                return suite;
            }

            JsonNode promptsNode = firstNode(root, "prompts", "promptList");
            if (promptsNode != null) {
                suite.setCases(parseCases(promptsNode));
                return suite;
            }

            String singlePrompt = firstText(root, null, "prompt", "testCase", "scenario", "steps");
            if (singlePrompt != null && !singlePrompt.isBlank()) {
                TestCaseRequest single = new TestCaseRequest();
                single.setTestName(firstText(root, "TC01", "testName", "name", "id", "title"));
                single.setBaseUrl(firstText(root, null, "baseUrl", "url", "applicationUrl"));
                single.setPrompt(singlePrompt);
                single.setData(asMap(root.get("data")));
                single.setBrowser(firstText(root, null, "browser", "browserName"));
                single.setHeadless(firstBoolean(root, null, "headless"));
                suite.setCases(List.of(single));
                return suite;
            }

            throw new IllegalArgumentException("JSON should contain 'cases', 'testCases', 'prompts', or a single 'prompt'.");
        } catch (Exception e) {
            if (e instanceof IllegalArgumentException) throw (IllegalArgumentException) e;
            throw new IllegalArgumentException("Unable to parse uploaded JSON file: " + e.getMessage(), e);
        }
    }

    private List<TestCaseRequest> parseCases(JsonNode node) {
        if (node == null || !node.isArray()) {
            throw new IllegalArgumentException("Cases/prompts must be a JSON array.");
        }
        List<TestCaseRequest> cases = new ArrayList<>();
        int index = 1;
        for (JsonNode child : node) {
            cases.add(toCase(child, index++));
        }
        if (cases.isEmpty()) throw new IllegalArgumentException("No prompts found inside the uploaded file.");
        return cases;
    }

    private TestCaseRequest toCase(JsonNode node, int index) {
        TestCaseRequest testCase = new TestCaseRequest();
        String defaultName = "TC" + String.format("%02d", index);

        if (node.isTextual()) {
            testCase.setTestName(defaultName);
            testCase.setPrompt(node.asText());
            testCase.setData(new LinkedHashMap<>());
            return testCase;
        }

        if (!node.isObject()) {
            throw new IllegalArgumentException("Case " + index + " must be either a prompt string or an object.");
        }

        testCase.setTestName(firstText(node, defaultName, "testName", "name", "id", "title"));
        testCase.setBaseUrl(firstText(node, null, "baseUrl", "url", "applicationUrl"));
        testCase.setPrompt(firstText(node, null, "prompt", "testCase", "scenario", "steps"));
        if (testCase.getPrompt() == null || testCase.getPrompt().isBlank()) {
            throw new IllegalArgumentException("Prompt is missing for case " + testCase.getTestName());
        }
        testCase.setData(asMap(node.get("data")));
        testCase.setBrowser(firstText(node, null, "browser", "browserName"));
        testCase.setHeadless(firstBoolean(node, null, "headless"));
        JsonNode tags = node.get("tags");
        if (tags != null && tags.isArray()) {
            testCase.setTags(objectMapper.convertValue(tags, new TypeReference<List<String>>() {}));
        }
        return testCase;
    }

    private Map<String, Object> asMap(JsonNode node) {
        if (node == null || node.isNull()) return new LinkedHashMap<>();
        if (!node.isObject()) throw new IllegalArgumentException("data must be a JSON object.");
        return objectMapper.convertValue(node, new TypeReference<Map<String, Object>>() {});
    }

    private JsonNode firstNode(JsonNode node, String... names) {
        for (String name : names) {
            JsonNode value = node.get(name);
            if (value != null && !value.isNull()) return value;
        }
        return null;
    }

    private String firstText(JsonNode node, String defaultValue, String... names) {
        for (String name : names) {
            JsonNode value = node.get(name);
            if (value != null && value.isValueNode()) {
                String text = value.asText();
                if (text != null && !text.isBlank()) return text;
            }
        }
        return defaultValue;
    }

    private Boolean firstBoolean(JsonNode node, Boolean defaultValue, String... names) {
        for (String name : names) {
            JsonNode value = node.get(name);
            if (value != null && value.isBoolean()) return value.asBoolean();
            if (value != null && value.isTextual()) return Boolean.parseBoolean(value.asText());
        }
        return defaultValue;
    }

    private String defaultSuiteName(String fileName) {
        if (fileName == null || fileName.isBlank()) return "Uploaded_Suite";
        int dot = fileName.lastIndexOf('.');
        String base = dot > 0 ? fileName.substring(0, dot) : fileName;
        String slug = Slug.of(base);
        return slug.isBlank() ? "Uploaded_Suite" : slug;
    }
}
