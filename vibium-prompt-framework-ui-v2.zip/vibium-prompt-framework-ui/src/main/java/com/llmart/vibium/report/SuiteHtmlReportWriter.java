package com.llmart.vibium.report;

import com.llmart.vibium.config.FrameworkProperties;
import com.llmart.vibium.model.ExecutionReport;
import com.llmart.vibium.model.StepStatus;
import com.llmart.vibium.model.TestSuiteReport;
import org.springframework.stereotype.Component;

import java.nio.file.Files;
import java.nio.file.Path;

@Component
public class SuiteHtmlReportWriter {
    private final FrameworkProperties properties;

    public SuiteHtmlReportWriter(FrameworkProperties properties) {
        this.properties = properties;
    }

    public Path write(TestSuiteReport report) {
        try {
            Path reportDir = Path.of(properties.getReportDir(), "suites", report.getSuiteId());
            Files.createDirectories(reportDir);
            Path file = reportDir.resolve("suite-report.html");
            Files.writeString(file, html(report));
            return file;
        } catch (Exception e) {
            throw new IllegalStateException("Unable to write suite HTML report", e);
        }
    }

    private String html(TestSuiteReport suite) {
        StringBuilder rows = new StringBuilder();
        int index = 1;
        for (ExecutionReport report : suite.getCaseReports()) {
            String reportLink = "/api/v1/vibium/reports/" + safeUrl(report.getRunId()) + "/html";
            rows.append("<tr class='").append(css(report.getStatus())).append("'>")
                    .append("<td>").append(index++).append("</td>")
                    .append("<td>").append(esc(report.getTestName())).append("</td>")
                    .append("<td><span class='badge ").append(css(report.getStatus())).append("'>").append(report.getStatus()).append("</span></td>")
                    .append("<td>").append(report.getTotalSteps()).append("</td>")
                    .append("<td>").append(report.getPassedSteps()).append("</td>")
                    .append("<td>").append(report.getFailedSteps()).append("</td>")
                    .append("<td>").append(report.getDurationMs()).append(" ms</td>")
                    .append("<td><a href='").append(reportLink).append("' target='_blank'>Open case report</a></td>")
                    .append("</tr>");
        }

        return """
                <!DOCTYPE html>
                <html>
                <head>
                  <meta charset="UTF-8">
                  <title>Vibium Suite Report</title>
                  <style>
                    body { font-family: Arial, sans-serif; margin: 24px; background: #f7f8fa; color: #111827; }
                    .card { background: white; border-radius: 14px; padding: 18px; margin-bottom: 18px; box-shadow: 0 2px 8px rgba(0,0,0,.08); }
                    .summary { display: flex; gap: 12px; flex-wrap: wrap; }
                    .metric { padding: 12px 16px; border-radius: 10px; background: #f3f4f6; min-width: 130px; }
                    .metric strong { display:block; font-size: 24px; }
                    table { width: 100%%; border-collapse: collapse; }
                    th, td { border-bottom: 1px solid #e5e7eb; padding: 12px; text-align: left; vertical-align: top; }
                    th { background: #111827; color: white; }
                    .badge { padding: 5px 9px; border-radius: 999px; color: white; font-size: 12px; }
                    .passed { background: #16a34a; color: white; }
                    .failed { background: #dc2626; color: white; }
                    .skipped { background: #ca8a04; color: white; }
                    .status-passed { color: #16a34a; }
                    .status-failed { color: #dc2626; }
                    a { color: #2563eb; }
                  </style>
                </head>
                <body>
                  <div class="card">
                    <h1>Vibium Suite Execution Report</h1>
                    <h2 class="status-%s">%s</h2>
                    <p><b>Suite ID:</b> %s</p>
                    <p><b>Suite:</b> %s</p>
                    <p><b>Browser:</b> %s</p>
                    <p><b>Mode:</b> %s</p>
                    <p><b>Duration:</b> %d ms</p>
                  </div>
                  <div class="card summary">
                    <div class="metric"><strong>%d</strong>Total Cases</div>
                    <div class="metric"><strong>%d</strong>Passed</div>
                    <div class="metric"><strong>%d</strong>Failed</div>
                    <div class="metric"><strong>%d</strong>Skipped</div>
                  </div>
                  <div class="card">
                    <h3>Case Results</h3>
                    <table>
                      <thead><tr><th>#</th><th>Test Case</th><th>Status</th><th>Total Steps</th><th>Passed Steps</th><th>Failed Steps</th><th>Time</th><th>Report</th></tr></thead>
                      <tbody>%s</tbody>
                    </table>
                  </div>
                </body>
                </html>
                """.formatted(
                suite.getStatus().name().toLowerCase(),
                suite.getStatus(),
                esc(suite.getSuiteId()),
                esc(suite.getSuiteName()),
                esc(suite.getBrowser()),
                Boolean.TRUE.equals(suite.getHeadless()) ? "Headless" : "Headed",
                suite.getDurationMs(),
                suite.getTotalCases(),
                suite.getPassedCases(),
                suite.getFailedCases(),
                suite.getSkippedCases(),
                rows
        );
    }

    private String css(StepStatus status) {
        if (status == null) return "skipped";
        return status.name().toLowerCase();
    }

    private String safeUrl(String value) {
        if (value == null) return "";
        return value.replaceAll("[^a-zA-Z0-9._-]", "");
    }

    private String esc(String s) {
        if (s == null) return "";
        return s.replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;")
                .replace("\"", "&quot;")
                .replace("'", "&#39;");
    }
}
