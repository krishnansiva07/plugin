package com.llmart.vibium.util;

import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class RefParser {
    private static final Pattern REF_PATTERN = Pattern.compile("@e\\d+");
    private RefParser() {}

    public static Optional<String> firstElementRef(String text) {
        if (text == null) return Optional.empty();
        Matcher matcher = REF_PATTERN.matcher(text);
        return matcher.find() ? Optional.of(matcher.group()) : Optional.empty();
    }
}
