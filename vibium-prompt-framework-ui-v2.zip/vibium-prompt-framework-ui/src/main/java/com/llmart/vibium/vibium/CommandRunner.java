package com.llmart.vibium.vibium;

import com.llmart.vibium.config.VibiumProperties;
import com.llmart.vibium.model.CommandResult;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

@Component
public class CommandRunner {
    private final VibiumProperties properties;
    private final ThreadLocal<RunBrowserOptions> runOptions = new ThreadLocal<>();

    public CommandRunner(VibiumProperties properties) {
        this.properties = properties;
    }

    public void setRunBrowserOptions(String browser, Boolean headless) {
        runOptions.set(new RunBrowserOptions(browser, headless));
    }

    public void clearRunBrowserOptions() {
        runOptions.remove();
    }

    public CommandResult run(List<String> args) {
        List<String> command = new ArrayList<>(baseCommand());
        command.addAll(runtimeBrowserArgs());
        command.addAll(args);
        String printable = String.join(" ", command);
        Instant start = Instant.now();
        try {
            Process process = new ProcessBuilder(command)
                    .redirectErrorStream(false)
                    .start();

            boolean completed = process.waitFor(properties.getCommandTimeoutSeconds(), TimeUnit.SECONDS);
            if (!completed) {
                process.destroyForcibly();
                long duration = Duration.between(start, Instant.now()).toMillis();
                return new CommandResult(-1, printable, "", "Timed out after " + properties.getCommandTimeoutSeconds() + " seconds", duration);
            }
            String stdout = new String(process.getInputStream().readAllBytes(), StandardCharsets.UTF_8);
            String stderr = new String(process.getErrorStream().readAllBytes(), StandardCharsets.UTF_8);
            long duration = Duration.between(start, Instant.now()).toMillis();
            return new CommandResult(process.exitValue(), printable, stdout, stderr, duration);
        } catch (IOException e) {
            long duration = Duration.between(start, Instant.now()).toMillis();
            return new CommandResult(-2, printable, "", e.getMessage(), duration);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            long duration = Duration.between(start, Instant.now()).toMillis();
            return new CommandResult(-3, printable, "", "Interrupted", duration);
        }
    }

    private List<String> baseCommand() {
        String configured = properties.getCommand();
        if (configured == null || configured.isBlank()) return List.of("vibium");
        return splitArgs(configured);
    }

    private List<String> runtimeBrowserArgs() {
        if (!properties.isRuntimeBrowserOptionsEnabled()) return List.of();

        RunBrowserOptions options = runOptions.get();
        String browser = normalize(firstNonBlank(options == null ? null : options.browser(), properties.getDefaultBrowser()));
        boolean headless = options != null && options.headless() != null
                ? options.headless()
                : properties.isDefaultHeadless();

        List<String> args = new ArrayList<>();

        if (browser != null && !browser.isBlank()
                && (properties.isAlwaysPassBrowserArg() || !"chrome".equals(browser))) {
            args.addAll(formatTemplateArgs(properties.getBrowserArgTemplate(), browser));
        }

        String modeArg = headless ? properties.getHeadlessArg() : properties.getHeadedArg();
        args.addAll(splitArgs(modeArg));
        return args;
    }

    private List<String> formatTemplateArgs(String template, String browser) {
        if (template == null || template.isBlank()) return List.of();
        String formatted = template.contains("%s") ? String.format(template, browser) : template;
        return splitArgs(formatted);
    }

    private List<String> splitArgs(String configured) {
        if (configured == null || configured.isBlank()) return List.of();
        return Arrays.stream(configured.split("\\|"))
                .map(String::trim)
                .filter(s -> !s.isBlank())
                .toList();
    }

    private String firstNonBlank(String first, String second) {
        return first != null && !first.isBlank() ? first : second;
    }

    private String normalize(String browser) {
        if (browser == null) return null;
        return browser.trim().toLowerCase(Locale.ROOT);
    }

    private record RunBrowserOptions(String browser, Boolean headless) { }
}
