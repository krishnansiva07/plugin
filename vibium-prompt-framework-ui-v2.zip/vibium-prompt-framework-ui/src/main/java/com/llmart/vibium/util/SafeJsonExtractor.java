package com.llmart.vibium.util;

public final class SafeJsonExtractor {
    private SafeJsonExtractor() {}

    public static String extractJsonObject(String raw) {
        if (raw == null || raw.isBlank()) {
            throw new IllegalArgumentException("LLM returned empty response");
        }
        String cleaned = raw.trim();
        if (cleaned.startsWith("```")) {
            cleaned = cleaned.replaceFirst("^```(?:json)?", "").replaceFirst("```$", "").trim();
        }
        int start = cleaned.indexOf('{');
        int end = cleaned.lastIndexOf('}');
        if (start < 0 || end <= start) {
            throw new IllegalArgumentException("No JSON object found in LLM response: " + raw);
        }
        return cleaned.substring(start, end + 1);
    }
}
