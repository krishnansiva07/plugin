package com.llmart.vibium.planner;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.llmart.vibium.llm.LlmChatClient;
import com.llmart.vibium.model.ActionPlan;
import com.llmart.vibium.model.TestCaseRequest;
import com.llmart.vibium.util.SafeJsonExtractor;
import org.springframework.stereotype.Service;

@Service
public class PromptPlanner {
    private final LlmChatClient llm;
    private final ObjectMapper objectMapper;

    public PromptPlanner(LlmChatClient llm, ObjectMapper objectMapper) {
        this.llm = llm;
        this.objectMapper = objectMapper;
    }

    public ActionPlan createPlan(TestCaseRequest request) {
        if (request.getPlan() != null && request.getPlan().getSteps() != null && !request.getPlan().getSteps().isEmpty()) {
            return request.getPlan();
        }
        String prompt = buildPlannerPrompt(request);
        String raw = llm.generate(prompt);
        String json = SafeJsonExtractor.extractJsonObject(raw);
        try {
            ActionPlan plan = objectMapper.readValue(json, ActionPlan.class);
            if (plan.getTestName() == null || plan.getTestName().isBlank()) {
                plan.setTestName(request.getTestName());
            }
            return plan;
        } catch (JsonProcessingException e) {
            throw new IllegalStateException("LLM returned invalid action-plan JSON: " + json, e);
        }
    }

    private String buildPlannerPrompt(TestCaseRequest request) {
        String dataJson;
        try {
            dataJson = objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(request.getData());
        } catch (JsonProcessingException e) {
            dataJson = "{}";
        }

        return """
                You are a senior test automation architect. Convert the user's natural language test case into a strict Vibium browser action plan.

                IMPORTANT RULES:
                1. Return ONLY valid JSON. No markdown. No explanation.
                2. Use only these actions: GO, MAP, FIND, CLICK, FILL, SELECT, CHECK, PRESS, WAIT_TEXT, WAIT_URL, WAIT_SELECTOR, VERIFY_TEXT, VERIFY_URL_CONTAINS, SCREENSHOT, TEXT, EVAL, QUIT.
                3. Prefer semantic locators first: label, text, placeholder, role. Use css only when the prompt gives a clear selector.
                4. For form inputs, first FIND the element with saveAs, then FILL using target as ${variableName}.
                5. For buttons/links, FIND by visible text/role, then CLICK using target as ${variableName}.
                6. Always include one SCREENSHOT after important verification.
                7. Do not invent credentials. Use testData keys exactly when needed, using placeholders like ${username} or ${password}.
                8. When baseUrl is present, first step should be GO with value as baseUrl unless prompt gives a different full URL.
                9. Keep the plan small and executable.

                JSON SCHEMA:
                {
                  "testName": "string",
                  "description": "string",
                  "steps": [
                    {
                      "order": 1,
                      "name": "short step name",
                      "action": "GO",
                      "strategy": "text|label|placeholder|role|css|ref",
                      "target": "visible text, label, css, role, @ref or ${savedVariable}",
                      "value": "url, input text, expected text, key, js, screenshot name",
                      "saveAs": "optionalVariableName",
                      "optional": false
                    }
                  ]
                }

                TEST NAME:
                %s

                BASE URL:
                %s

                TEST DATA JSON:
                %s

                USER TEST CASE PROMPT:
                %s
                """.formatted(request.getTestName(), nullToBlank(request.getBaseUrl()), dataJson, request.getPrompt());
    }

    private String nullToBlank(String value) {
        return value == null ? "" : value;
    }
}
