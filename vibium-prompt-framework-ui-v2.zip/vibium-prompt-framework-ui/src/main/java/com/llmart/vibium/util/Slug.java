package com.llmart.vibium.util;

public final class Slug {
    private Slug() {}

    public static String of(String input) {
        if (input == null || input.isBlank()) return "test";
        return input.toLowerCase().replaceAll("[^a-z0-9]+", "-").replaceAll("(^-|-$)", "");
    }
}
