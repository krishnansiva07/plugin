package com.llmart.vibium.llm;

import dev.langchain4j.model.chat.ChatLanguageModel;
import org.springframework.stereotype.Service;

@Service
public class LlmChatClient {
    private final ChatLanguageModel chatModel;

    public LlmChatClient(ChatLanguageModel chatModel) {
        this.chatModel = chatModel;
    }

    public String generate(String prompt) {
        return chatModel.generate(prompt);
    }
}
