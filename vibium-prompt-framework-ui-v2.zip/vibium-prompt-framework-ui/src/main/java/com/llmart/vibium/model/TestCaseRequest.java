package com.llmart.vibium.model;

import jakarta.validation.constraints.NotBlank;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class TestCaseRequest {
    @NotBlank
    private String testName;
    private String baseUrl;
    @NotBlank
    private String prompt;
    private Map<String, Object> data = new LinkedHashMap<>();
    private List<String> tags;
    private ActionPlan plan; // optional: directly execute JSON plan without LLM

    // Runtime browser options. If omitted, values from application.properties are used.
    private String browser;
    private Boolean headless;

    public String getTestName() { return testName; }
    public void setTestName(String testName) { this.testName = testName; }
    public String getBaseUrl() { return baseUrl; }
    public void setBaseUrl(String baseUrl) { this.baseUrl = baseUrl; }
    public String getPrompt() { return prompt; }
    public void setPrompt(String prompt) { this.prompt = prompt; }
    public Map<String, Object> getData() { return data; }
    public void setData(Map<String, Object> data) { this.data = data; }
    public List<String> getTags() { return tags; }
    public void setTags(List<String> tags) { this.tags = tags; }
    public ActionPlan getPlan() { return plan; }
    public void setPlan(ActionPlan plan) { this.plan = plan; }
    public String getBrowser() { return browser; }
    public void setBrowser(String browser) { this.browser = browser; }
    public Boolean getHeadless() { return headless; }
    public void setHeadless(Boolean headless) { this.headless = headless; }
}
