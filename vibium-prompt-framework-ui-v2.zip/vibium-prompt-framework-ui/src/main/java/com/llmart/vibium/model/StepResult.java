package com.llmart.vibium.model;

import java.time.Instant;

public class StepResult {
    private int order;
    private String name;
    private ActionType action;
    private StepStatus status;
    private String command;
    private String output;
    private String error;
    private String screenshotPath;
    private long durationMs;
    private Instant startedAt;
    private Instant endedAt;

    public int getOrder() { return order; }
    public void setOrder(int order) { this.order = order; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public ActionType getAction() { return action; }
    public void setAction(ActionType action) { this.action = action; }
    public StepStatus getStatus() { return status; }
    public void setStatus(StepStatus status) { this.status = status; }
    public String getCommand() { return command; }
    public void setCommand(String command) { this.command = command; }
    public String getOutput() { return output; }
    public void setOutput(String output) { this.output = output; }
    public String getError() { return error; }
    public void setError(String error) { this.error = error; }
    public String getScreenshotPath() { return screenshotPath; }
    public void setScreenshotPath(String screenshotPath) { this.screenshotPath = screenshotPath; }
    public long getDurationMs() { return durationMs; }
    public void setDurationMs(long durationMs) { this.durationMs = durationMs; }
    public Instant getStartedAt() { return startedAt; }
    public void setStartedAt(Instant startedAt) { this.startedAt = startedAt; }
    public Instant getEndedAt() { return endedAt; }
    public void setEndedAt(Instant endedAt) { this.endedAt = endedAt; }
}
