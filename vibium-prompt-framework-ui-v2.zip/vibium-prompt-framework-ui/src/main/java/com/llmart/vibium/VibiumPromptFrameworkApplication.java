package com.llmart.vibium;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VibiumPromptFrameworkApplication {
    public static void main(String[] args) {
        SpringApplication.run(VibiumPromptFrameworkApplication.class, args);
    }
}
