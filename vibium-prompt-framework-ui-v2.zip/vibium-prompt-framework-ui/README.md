# Vibium Prompt Framework UI

Java + Spring Boot + LangChain4j + Vibium CLI framework for prompt-driven browser automation.

## Latest UI features

- Single prompt test execution
- Suite Builder for any number of prompts
- JSON file upload from UI
- Chrome / Edge selection from UI
- Headed / Headless selection from UI
- Sequential execution: TC01 -> TC02 -> TC03 -> ...
- Individual HTML/JSON case reports
- Consolidated HTML/JSON suite report
- Screenshot evidence per case

## Run locally

### 1. Install Vibium

```bash
npm install -g vibium
vibium --version
```

Windows fallback if `vibium` is not detected:

```powershell
$env:VIBIUM_COMMAND="cmd|/c|npx.cmd|-y|vibium"
```

### 2. Configure LLM

Do not keep API keys in `application.properties`.

Windows PowerShell:

```powershell
$env:LLM_API_KEY="your-key"
$env:LLM_MODEL_NAME="gpt-oss-120b"
$env:LLM_BASE_URL="https://ai4devs.group.echonet/api/v1"
```

Linux/macOS:

```bash
export LLM_API_KEY="your-key"
export LLM_MODEL_NAME="gpt-oss-120b"
export LLM_BASE_URL="https://ai4devs.group.echonet/api/v1"
```

### 3. Optional browser flag configuration

The UI sends `browser` and `headless` values to backend. The backend converts them to Vibium CLI runtime args.

Defaults:

```properties
VIBIUM_BROWSER_ARG_TEMPLATE=--browser=%s
VIBIUM_HEADED_ARG=--headed
VIBIUM_HEADLESS_ARG=--headless
```

If your installed Vibium version uses different flags, change these environment variables only. No Java code change required.

To disable browser/mode CLI args temporarily:

```powershell
$env:VIBIUM_RUNTIME_BROWSER_OPTIONS_ENABLED="false"
```

### 4. Start app

```bash
mvn spring-boot:run
```

Open:

```text
http://localhost:8090
```

## JSON upload format

Use **Upload JSON Suite** tab and select a JSON file.

### Full suite format

```json
{
  "suiteName": "Place_Order_Smoke",
  "baseUrl": "https://your-application-url",
  "browser": "chrome",
  "headless": false,
  "stopOnFailure": false,
  "data": {
    "username": "automation_user",
    "password": "change_me",
    "product": "mobile"
  },
  "cases": [
    {
      "testName": "TC01_Login",
      "prompt": "Open the application. Login using ${username} and ${password}. Verify dashboard page is displayed. Take screenshot."
    },
    {
      "testName": "TC02_Search_Product",
      "prompt": "Search for ${product}. Verify search result is displayed. Take screenshot."
    }
  ]
}
```

### Prompts-only format

```json
{
  "suiteName": "Quick_Smoke",
  "baseUrl": "https://your-application-url",
  "browser": "edge",
  "headless": true,
  "prompts": [
    "Open the app and verify login page is displayed. Take screenshot.",
    "Login using valid credentials and verify dashboard page is displayed. Take screenshot.",
    "Logout and verify login page is displayed. Take screenshot."
  ]
}
```

## How to run any number of cases

1. Open `http://localhost:8090`
2. Click **Upload JSON Suite**
3. Select your JSON file
4. Select **Chrome** or **Edge**
5. Select **Headed** or **Headless**
6. Click **Run Uploaded Suite**

Execution order:

```text
TC01 -> LLM plan -> Vibium browser execution -> report
TC02 -> LLM plan -> Vibium browser execution -> report
TC03 -> LLM plan -> Vibium browser execution -> report
...
```

## Reports

```text
reports/suites/<suite-id>/suite-report.html
reports/suites/<suite-id>/suite-report.json
reports/<run-id>/execution-report.html
reports/<run-id>/execution-report.json
reports/screenshots/<run-id>/*.png
```

## Backend APIs

```text
POST /api/v1/vibium/execute
POST /api/v1/vibium/execute-suite
POST /api/v1/vibium/execute-suite-file
GET  /api/v1/vibium/reports/{runId}/html
GET  /api/v1/vibium/reports/suites/{suiteId}/html
```
