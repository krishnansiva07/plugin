# UI Usage Guide

## Single test

1. Open `http://localhost:8090`
2. Click **Single Test Case**
3. Enter test name and base URL
4. Select browser: Chrome or Edge
5. Select mode: Headed or Headless
6. Enter test data JSON
7. Enter prompt
8. Click **Run Test Case**

## Run many prompts using UI builder

1. Click **Suite Builder**
2. Enter suite name and common base URL
3. Select browser and mode
4. Enter common test data JSON
5. Click **Add Case** for each test, or **Add 10 Cases**
6. Fill all prompts
7. Click **Run Suite**

## Run many prompts using JSON upload

1. Click **Upload JSON Suite**
2. Select a JSON file
3. Review detected prompt count
4. Select Chrome or Edge
5. Select Headed or Headless
6. Click **Run Uploaded Suite**

The framework executes all prompts one by one and creates suite + case reports.

## JSON keys supported

Suite-level keys:

```text
suiteName, name, title
baseUrl, url, applicationUrl
browser, browserName
headless
stopOnFailure, failFast
data
cases, testCases, tests, scenarios, prompts
```

Case-level keys:

```text
testName, name, id, title
prompt, testCase, scenario, steps
baseUrl, url, applicationUrl
data
browser, browserName
headless
tags
```

## Browser configuration notes

The UI selection is converted to Vibium CLI args using these environment variables:

```text
VIBIUM_BROWSER_ARG_TEMPLATE=--browser=%s
VIBIUM_HEADED_ARG=--headed
VIBIUM_HEADLESS_ARG=--headless
```

If your Vibium CLI version does not support a flag, override it to blank or change it to the right syntax.
