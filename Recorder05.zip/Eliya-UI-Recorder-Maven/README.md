# Eliya UI Recorder 2.0 — Java 17 · Maven · Automation-ready exports

Self-contained Java 17 Chrome / Microsoft Edge UI recorder. **The browser must be installed already**. The tool does not need a Selenium driver, LLM, API key, Python, Node.js, or third-party Java dependencies.

## Build and run

```bash
mvn clean package
java -jar target/eliya-ui-recorder-2.0.0.jar
```

For restricted networks/offline builds, use `build-with-jdk.bat` on Windows or `sh build-with-jdk.sh` on Linux/macOS. Both compile via the JDK and create the same executable JAR without Maven dependencies. In Eclipse, import as an existing Maven project and run `clean package`.

The JAR opens the local dashboard at `http://127.0.0.1:<random-port>/`. Enter your application URL, choose Chrome, Edge, or Auto, and start recording. The recorder launches your already-installed browser with a separate temporary profile.

**Stop & Export JSON + Excel (ZIP)** downloads a ZIP containing both structured exports. Alternatively use **JSON only**, **Excel only**, or **Debug raw JSON**. You can export repeatedly after stopping the recording; close the browser when finished.

## What version 2 changes

Raw debug captures are available in the raw export and local journal (`-Drecorder.captureDiagnostics=true` enables extra pointer/focus/clipboard-metadata events); **the default JSON is filtered to genuine test steps**. The default DOM capture is reduced to 80 nodes, depth 5, 16 siblings (configurable) to reduce performance overhead. Export strips bulk event metadata, coordinates, and full target DOM snapshots.

### JSON schema (`schemaVersion: "2.0"`)

- `summary`: raw event count, meaningful test steps, unique elements, filtered noise breakdown.
- `steps`: ordered actions with description, action value/state, page URL, tab, frame and time. Each step has an `elementId` and a compact self-contained `element` including `tag`, `attributes`, key `properties`, recommended and top locator alternatives, `parent`, immediate `children`, and actual event target when different from the actionable ancestor. Full ancestors, siblings, nearby controls, and additional candidates live once in `elements[]`.
- `elements`: full deduplicated element repository (including nearby interacting controls) with stable session-scoped identifiers (`E0001`, etc.), candidates, context and the test steps that used each element.
- `limitations`: conditions testers must account for when generating actual scripts.

**Locator candidates**: `strategy`, `value`, `score`, `unique`, `matchCount`, `verifiedAtCapture`, `scope`, `reason`, and where possible `selenium` and `playwright` suggestions. The recorder checks CSS/XPath uniqueness in the *current element's document or shadow root at recording time*. Test IDs, stable IDs, names, ARIA labels, placeholders, semantic role/name, form labels, structural CSS and XPath are considered. Semantic role/label candidates have `unique: null` because browser CSS uniqueness does not validate the automation framework's accessibility API. IDs resembling UUIDs or generated indexes are penalized/excluded from some candidates. Always validate before usage.

For shadow DOM, `shadowPath` stores each open-root segment. **The human-readable `>>>` separator is not a portable CSS selector** and needs traversal (e.g., Selenium `getShadowRoot()` or Playwright open-shadow queries). For iframes, locate and switch to the frame before resolving the element. Browser context and cross-origin iframe support remain best effort.

The **event journal is not deleted**: a raw JSON export preserves low-level events and configurable DOM detail for debugging when the concise automation model is insufficient.

### Excel workbook (seven filtered, frozen-header sheets)

1. **Test Steps** — sequence, action, details, values/states, best locator, URL, frame, timestamp.
2. **Element Repository** — unique interacted elements, all safe attributes as JSON, selector, parent/child/sibling counts and step reuse.
3. **Locator Candidates** — *every ranked option*, uniqueness, score, match counts and Selenium/Playwright hints.
4. **Attribute Catalog** — one attribute per row across the target, parent, children and siblings, searchable by element ID.
5. **DOM Context** — target, parent, ancestors, children, siblings and nearby form controls/elements.
6. **Flow Overview** — concise execution flow for manual review/test-design.
7. **Session Summary** — recording metadata, noise filtering and limitations.

**Warnings:** the recorder is not a test generator or replay engine; it does not know the expected assertion for a business scenario. No application-specific locator has a permanent uniqueness guarantee. Review the source evidence and add waits, assertions, data fixtures, and negative paths in your test framework.

## Capture tuning

```bash
java -Drecorder.domMaxNodes=200 -Drecorder.domMaxDepth=6 -Drecorder.domMaxSiblings=24 -jar target/eliya-ui-recorder-2.0.0.jar
```

Large values create large on-disk debug journals; the automation-ready exports remain curated. `-Drecorder.captureDiagnostics=true` enables pointer/focus/keyboard/mouse diagnostics in the raw journal, and `-Drecorder.captureMotion=true` adds sampled pointer movement. Neither increases the actionable JSON step count.

Explicit executable paths are supported:

```bat
java "-Drecorder.edgePath=C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe" -jar target\eliya-ui-recorder-2.0.0.jar
```

For Chrome, set `-Drecorder.chromePath=...`. Corporate browser restrictions and proxies may affect CDP. `-Drecorder.browserNoProxy=true` bypasses the browser proxy only when requested. Keep desktop browser sandbox enabled; `recorder.disableSandbox=true` is for disposable CI containers only.

## Privacy and behavior constraints

- Password/secret-like attributes and field values are masked with `[REDACTED]`; clipboard content, cookies and raw HTTP headers are not intentionally captured. Ordinary user-input values and page text can still be personal/confidential. **Use synthetic accounts and review exports before sharing**. No automatic masking can guarantee every secret is detected.
- OS file chooser dialogs, browser chrome, native app dialogs, closed shadow roots and security-restricted frames cannot be fully reconstructed using DOM listeners.
- Each session is journaled in `~/.eliya-ui-recorder/sessions/<session-id>.jsonl` (raw details can be large and sensitive). Files must be secured or deleted according to your test-data policy.
- The local web dashboard listens only on `127.0.0.1`. Each newly launched recording resets the preceding session.

## Source structure

```text
pom.xml
build-with-jdk.bat
build-with-jdk.sh
src/main/java/com/eliya/recorder/RecorderApp.java
src/main/java/com/eliya/recorder/BrowserRecorder.java
src/main/java/com/eliya/recorder/AutomationExport.java
src/main/java/com/eliya/recorder/XlsxWriter.java
src/main/java/com/eliya/recorder/Json.java
src/main/resources/index.html
src/main/resources/recorder.js
```

## Suggested manual functional verification

- Perform navigation → input field fill → checkbox → dropdown → button click → form submit. Verify 2.0 JSON has concise actions in order, element IDs, parent/children, and ranked candidates. Export Excel and check all seven worksheets.
- Click a nested `span` within a button and check that `eventTarget` identifies the inner element while the actionable target is the button.
- Test duplicate IDs, dynamic IDs, changing CSS class names, an input in an iframe, an open shadow root, a password field, and an autocompleting input. Mark unverified semantic locators as such.
- Check *Debug raw JSON* continues to include verbose events, and compare noise counts.
