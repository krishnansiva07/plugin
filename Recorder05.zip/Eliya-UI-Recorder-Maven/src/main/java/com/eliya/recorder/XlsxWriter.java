package com.eliya.recorder;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/** Dependency-free OOXML spreadsheet writer (Java 17, no external JARs required). */
final class XlsxWriter {
    private XlsxWriter() { }

    static byte[] write(Map<String, Object> flow) throws IOException {
        List<Sheet> sheets = new ArrayList<>();
        Sheet steps = sheet("Test Steps", "Step", "Action", "Description", "Value / State", "Element ID",
            "Element", "Best Strategy", "Best Locator", "Score", "Unique?", "Replay?", "URL", "Page Title", "Tab", "Frame", "Frame ID", "Parent", "Observed Effects", "Timestamp");
        Sheet elements = sheet("Element Repository", "Element ID", "Tag", "Type", "Text", "Role", "Accessible Name",
            "Best Strategy", "Best Locator", "Locator Count", "Attributes (JSON)", "Parent", "Children", "Siblings", "Used In Steps", "Visible", "Disabled");
        Sheet attributes = sheet("Attribute Catalog", "Element ID", "Relation", "Attribute", "Value", "Tag", "Element Selector");
        Sheet locators = sheet("Locator Candidates", "Element ID", "Rank", "Strategy", "Value", "Score", "Unique?",
            "Match Count", "Validated", "Reason", "Selenium By", "Playwright", "Scope");
        Sheet context = sheet("DOM Context", "Element ID", "Relation", "Depth / Order", "Tag", "Text", "Attributes (JSON)", "Selector / ID");
        Sheet flowSheet = sheet("Flow Overview", "Step", "Action", "Description", "Replay?", "URL", "Element ID", "Locator", "Frame", "Recorded At");
        Sheet summary = sheet("Session Summary", "Metric", "Value");
        sheets.addAll(List.of(steps, elements, locators, attributes, context, flowSheet, summary));

        for (Object it : Json.array(flow.get("steps"))) {
            Map<String, Object> st = Json.object(it);
            Map<String, Object> el = Json.object(st.get("element"));
            Map<String, Object> ls = Json.object(el.get("locators"));
            Map<String, Object> best = Json.object(ls.get("recommended"));
            Map<String, Object> fr = Json.object(st.get("frame"));
            String state = stepState(st);
            String parent = compactNode(Json.object(el.get("parent")));
            steps.add(st.get("step"), st.get("action"), st.get("description"), state, st.get("elementId"),
                compactNode(el), best.get("strategy"), best.get("value"), best.get("score"), best.get("unique"), st.get("replaySuggested"),
                st.get("pageUrl"), st.get("pageTitle"), st.get("tabId"), frameText(fr), st.get("frameId"), parent,
                Json.stringify(st.getOrDefault("observedEffects", List.of())), st.get("recordedAt"));
            flowSheet.add(st.get("step"), st.get("action"), st.get("description"), st.get("replaySuggested"), st.get("pageUrl"),
                st.get("elementId"), best.get("value"), frameText(fr), st.get("recordedAt"));
        }
        for (Object it : Json.array(flow.get("elements"))) {
            Map<String, Object> el = Json.object(it);
            Map<String, Object> ls = Json.object(el.get("locators"));
            Map<String, Object> best = Json.object(ls.get("recommended"));
            Map<String, Object> attrs = Json.object(el.get("attributes"));
            Map<String, Object> props = Json.object(el.get("properties"));
            elements.add(el.get("elementId"), el.get("tag"), el.get("inputType"), el.get("text"),
                ls.getOrDefault("role", attrs.getOrDefault("role", "")),
                ls.getOrDefault("accessibleName", attrs.getOrDefault("aria-label", "")),
                best.get("strategy"), best.get("value"), Json.array(ls.get("candidates")).size(),
                Json.stringify(attrs), compactNode(Json.object(el.get("parent"))),
                Json.array(el.get("children")).size(), Json.array(el.get("siblings")).size(),
                Json.stringify(el.get("usedInSteps")), props.get("visible"), props.get("disabled"));
            List<Object> candidates = Json.array(ls.get("candidates"));
            for (int i = 0; i < candidates.size(); i++) {
                Map<String, Object> c = Json.object(candidates.get(i));
                locators.add(el.get("elementId"), i + 1, c.get("strategy"), c.get("value"), c.get("score"),
                    c.get("unique"), c.get("matchCount"), c.get("verifiedAtCapture"), c.get("reason"),
                    c.get("selenium"), c.get("playwright"), c.get("scope"));
            }
            addAttributes(attributes, el.get("elementId"), "Target", el);
            addAttributes(attributes, el.get("elementId"), "Parent", Json.object(el.get("parent")));
            for (Object item : Json.array(el.get("children")))
                addAttributes(attributes, el.get("elementId"), "Child", Json.object(item));
            for (Object item : Json.array(el.get("siblings")))
                addAttributes(attributes, el.get("elementId"), "Sibling", Json.object(item));
            addContext(context, el.get("elementId"), "Target", 0, el);
            addContext(context, el.get("elementId"), "Parent", 1, Json.object(el.get("parent")));
            int n = 2;
            for (Object item : Json.array(el.get("ancestors"))) addContext(context, el.get("elementId"), "Ancestor", n++, Json.object(item));
            n = 1;
            for (Object item : Json.array(el.get("children"))) addContext(context, el.get("elementId"), "Child", n++, Json.object(item));
            n = 1;
            for (Object item : Json.array(el.get("siblings"))) addContext(context, el.get("elementId"), "Sibling", n++, Json.object(item));
            n = 1;
            for (Object item : Json.array(el.get("nearbyInteractiveElements")))
                addContext(context, el.get("elementId"), "Related interactive", n++, Json.object(item));
        }
        for (String key : List.of("sessionId", "applicationUrl", "browser", "recordingStartedAt", "recordingStoppedAt", "exportedAt"))
            summary.add(key, flow.get(key));
        for (var entry : Json.object(flow.get("summary")).entrySet())
            summary.add(entry.getKey(), entry.getValue() instanceof Map ? Json.stringify(entry.getValue()) : entry.getValue());
        summary.add("Important", "Locators are tested at record time only; always re-validate against the live AUT.");
        summary.add("Security", "Review non-secret page text and attributes before sharing exported files.");
        summary.add("Browser", "No browser installation/download is performed by this application.");
        return encode(sheets);
    }

    private static String stepState(Map<String, Object> step) {
        if (step.containsKey("checked")) return "checked=" + safe(step.get("checked"));
        if (step.containsKey("selectedOptions")) return "value=" + safe(step.get("value")) +
            "; options=" + Json.stringify(step.get("selectedOptions"));
        if (step.containsKey("selected")) return Json.stringify(step.get("selected"));
        if (step.containsKey("value")) return safe(step.get("value"));
        if (step.containsKey("files")) return Json.stringify(step.get("files"));
        if (step.containsKey("key")) return "key=" + safe(step.get("key"));
        if (step.containsKey("scrollY")) return "x=" + safe(step.get("scrollX")) + ", y=" + safe(step.get("scrollY"));
        return "";
    }

    private static void addAttributes(Sheet dest, Object id, String relation, Map<String, Object> item) {
        if (item.isEmpty()) return;
        String tag = Json.str(item.get("tag"));
        String selector = Json.str(Json.object(item.get("locators")).get("css"));
        for (Map.Entry<String, Object> entry : Json.object(item.get("attributes")).entrySet())
            dest.add(id, relation, entry.getKey(), entry.getValue(), tag, selector);
    }

    private static void addContext(Sheet dest, Object id, String relation, int depth, Map<String, Object> item) {
        if (item.isEmpty()) return;
        Map<String, Object> attrs = Json.object(item.get("attributes"));
        dest.add(id, relation, depth, item.get("tag"), item.getOrDefault("text", item.get("directText")),
            Json.stringify(attrs), Json.object(item.get("locator")).getOrDefault("value", Json.object(item.get("locators")).getOrDefault("css", item.getOrDefault("css", item.getOrDefault("id", attrs.get("id"))))));
    }

    private static String compactNode(Map<String, Object> n) {
        if (n.isEmpty()) return "";
        Map<String, Object> attrs = Json.object(n.get("attributes"));
        String tag = Json.str(n.get("tag"));
        String id = Json.str(n.getOrDefault("id", attrs.get("id")));
        String cls = Json.str(attrs.get("class"));
        return tag + (id.isEmpty() ? "" : "#" + id) + (cls.isEmpty() ? "" : " ." + cls);
    }

    private static String frameText(Map<String, Object> fr) {
        if (fr.isEmpty() || !Boolean.TRUE.equals(fr.get("isIframe"))) return "top";
        return "iframe: " + Json.str(fr.getOrDefault("frameUrl", ""));
    }

    private static String safe(Object value) { return value == null ? "" : String.valueOf(value); }

    private static Sheet sheet(String name, String... headers) {
        Sheet s = new Sheet(name);
        s.add((Object[]) headers);
        return s;
    }

    private record Sheet(String name, List<List<Object>> rows) {
        Sheet(String name) { this(name, new ArrayList<>()); }
        void add(Object... values) { rows.add(Arrays.asList(values)); }
    }

    private static byte[] encode(List<Sheet> sheets) throws IOException {
        ByteArrayOutputStream buffer = new ByteArrayOutputStream();
        try (ZipOutputStream zip = new ZipOutputStream(buffer, StandardCharsets.UTF_8)) {
            put(zip, "[Content_Types].xml", contentTypes(sheets.size()));
            put(zip, "_rels/.rels", "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"xl/workbook.xml\"/></Relationships>");
            put(zip, "xl/workbook.xml", workbook(sheets));
            put(zip, "xl/_rels/workbook.xml.rels", workbookRels(sheets.size()));
            put(zip, "xl/styles.xml", styles());
            for (int i = 0; i < sheets.size(); i++) put(zip, "xl/worksheets/sheet" + (i+1) + ".xml", sheetXml(sheets.get(i)));
        }
        return buffer.toByteArray();
    }

    private static void put(ZipOutputStream zip, String path, String xml) throws IOException {
        zip.putNextEntry(new ZipEntry(path));
        zip.write(xml.getBytes(StandardCharsets.UTF_8));
        zip.closeEntry();
    }

    private static String contentTypes(int count) {
        StringBuilder s = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\"?><Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\"><Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/><Default Extension=\"xml\" ContentType=\"application/xml\"/><Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/><Override PartName=\"/xl/styles.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml\"/>");
        for (int i = 1; i <= count; i++) s.append("<Override PartName=\"/xl/worksheets/sheet").append(i).append(".xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>");
        return s.append("</Types>").toString();
    }

    private static String workbook(List<Sheet> sheets) {
        StringBuilder s = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\"?><workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\"><sheets>");
        for (int i = 0; i < sheets.size(); i++) s.append("<sheet name=\"").append(esc(sheets.get(i).name())).append("\" sheetId=\"").append(i+1).append("\" r:id=\"rId").append(i+1).append("\"/>");
        return s.append("</sheets></workbook>").toString();
    }

    private static String workbookRels(int count) {
        StringBuilder s = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">");
        for (int i = 1; i <= count; i++) s.append("<Relationship Id=\"rId").append(i).append("\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet").append(i).append(".xml\"/>");
        s.append("<Relationship Id=\"rId").append(count+1).append("\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles\" Target=\"styles.xml\"/></Relationships>");
        return s.toString();
    }

    private static String styles() {
        return "<?xml version=\"1.0\" encoding=\"UTF-8\"?><styleSheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\">" +
            "<fonts count=\"2\"><font><sz val=\"10\"/><name val=\"Aptos\"/></font><font><b/><color rgb=\"FFFFFFFF\"/><sz val=\"11\"/><name val=\"Aptos\"/></font></fonts>" +
            "<fills count=\"3\"><fill><patternFill patternType=\"none\"/></fill><fill><patternFill patternType=\"gray125\"/></fill><fill><patternFill patternType=\"solid\"><fgColor rgb=\"FF175E49\"/><bgColor indexed=\"64\"/></patternFill></fill></fills>" +
            "<borders count=\"1\"><border><left/><right/><top/><bottom/><diagonal/></border></borders>" +
            "<cellStyleXfs count=\"1\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\"/></cellStyleXfs>" +
            "<cellXfs count=\"2\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\"/><xf numFmtId=\"0\" fontId=\"1\" fillId=\"2\" borderId=\"0\" xfId=\"0\" applyFill=\"1\" applyFont=\"1\"/></cellXfs>" +
            "<cellStyles count=\"1\"><cellStyle name=\"Normal\" xfId=\"0\" builtinId=\"0\"/></cellStyles></styleSheet>";
    }

    private static String sheetXml(Sheet sheet) {
        StringBuilder s = new StringBuilder(10_000);
        s.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?><worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\">" +
            "<sheetViews><sheetView workbookViewId=\"0\"><pane ySplit=\"1\" topLeftCell=\"A2\" activePane=\"bottomLeft\" state=\"frozen\"/></sheetView></sheetViews><sheetFormatPr defaultRowHeight=\"16\"/><cols>");
        int ncol = sheet.rows.get(0).size();
        for (int c=1; c<=ncol; c++) {
            int width = c == 3 || c == 4 || c == 8 || c == 9 || c == 11 ? 38 : 23;
            s.append("<col min=\"").append(c).append("\" max=\"").append(c).append("\" width=\"").append(width).append("\" customWidth=\"1\"/>");
        }
        s.append("</cols><sheetData>");
        for (int i = 0; i < sheet.rows.size(); i++) {
            List<Object> row = sheet.rows.get(i);
            s.append("<row r=\"").append(i+1).append("\" ht=\"").append(i==0 ? 28 : 18).append("\" customHeight=\"1\">");
            for (int j=0; j<row.size(); j++) {
                Object val = row.get(j);
                if (val == null) continue;
                String ref = column(j+1) + (i+1);
                if (val instanceof Number num && Double.isFinite(num.doubleValue()))
                    s.append("<c r=\"").append(ref).append("\" s=\"").append(i==0?1:0).append("\"><v>").append(num).append("</v></c>");
                else if (val instanceof Boolean b)
                    s.append("<c r=\"").append(ref).append("\" t=\"b\"><v>").append(b?1:0).append("</v></c>");
                else {
                    // inlineStr means untrusted values beginning with '=' are never executed as formulas.
                    String txt = val instanceof Map || val instanceof List ? Json.stringify(val) : String.valueOf(val);
                    if (txt.length() > 32767) txt = txt.substring(0, 32740) + "... [EXCEL CELL TRUNCATED]";
                    s.append("<c r=\"").append(ref).append("\" s=\"").append(i==0?1:0).append("\" t=\"inlineStr\"><is><t xml:space=\"preserve\">").append(esc(txt)).append("</t></is></c>");
                }
            }
            s.append("</row>");
        }
        s.append("</sheetData><autoFilter ref=\"A1:").append(column(ncol)).append(Math.max(1,sheet.rows.size())).append("\"/></worksheet>");
        return s.toString();
    }

    private static String column(int n) {
        StringBuilder s = new StringBuilder();
        while (n>0) {n--; s.insert(0, (char)('A'+n%26)); n/=26;}
        return s.toString();
    }

    private static String esc(String v) {
        StringBuilder s = new StringBuilder(v.length());
        for (int i=0; i<v.length(); i++) {
            char c=v.charAt(i);
            if (c == '&') s.append("&amp;"); else if (c == '<') s.append("&lt;");
            else if (c == '>') s.append("&gt;"); else if (c == '\"') s.append("&quot;");
            else if (c == '\'') s.append("&apos;");
            else if (c == 9 || c == 10 || c == 13 || c >= 32 && !(c >= 0xD800 && c <= 0xDFFF)) s.append(c);
            else if (Character.isHighSurrogate(c) && i+1<v.length() && Character.isLowSurrogate(v.charAt(i+1))) s.append(c).append(v.charAt(++i));
        }
        return s.toString();
    }
}
