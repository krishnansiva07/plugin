package com.eliya.recorder;

import java.util.*;
import java.time.Instant;
import java.time.Duration;

/** Converts the detailed event journal into concise, automation-oriented test data. */
final class AutomationExport {
    private static final Set<String> ACTIONS = Set.of(
        "navigate", "click", "doubleClick", "rightClick", "auxclick", "fill", "select", "check",
        "fileSelected", "submit", "drop", "scroll", "keyDown");

    private AutomationExport() { }

    static boolean isMeaningful(Map<String, Object> event) {
        String kind = Json.str(event.get("type"));
        return ACTIONS.contains(kind) && (!"keyDown".equals(kind) || importantKey(event));
    }

    static Map<String, Object> build(Map<String, Object> session, List<Map<String, Object>> raw) {
        List<Map<String, Object>> steps = new ArrayList<>();
        LinkedHashMap<String, Map<String, Object>> elements = new LinkedHashMap<>();
        Map<String, Integer> filtered = new TreeMap<>();
        String lastPage = "";
        for (int sourceIndex = 0; sourceIndex < raw.size(); sourceIndex++) {
            Map<String, Object> action = raw.get(sourceIndex);
            String kind = str(action, "type");
            if (!isMeaningful(action)) {
                filtered.merge(kind, 1, Integer::sum); continue;
            }
            if (kind.equals("click") && supersededByFollowingInteraction(raw, sourceIndex, action)) {
                filtered.merge("clickSupersededByHighLevelAction", 1, Integer::sum); continue;
            }
            if (kind.equals("scroll") && !steps.isEmpty()) {
                Map<String, Object> previous = steps.get(steps.size() - 1);
                if ("scroll".equals(str(previous, "action")) &&
                    Objects.equals(str(previous,"pageUrl"), str(action,"pageUrl")) &&
                    Objects.equals(str(previous,"tabId"), str(action,"tabId")) &&
                    withinMillis(str(previous,"recordedAt"), str(action,"recordedAt"), 1200)) {
                    // Scroll samples of the same short gesture should be one final position.
                    steps.remove(steps.size() - 1);
                }
            }
            // A browser form submit following a recorded submit-button click is an effect,
            // not another action to replay. Keep Enter-triggered submissions as steps.
            if (kind.equals("submit") && mergeSubmitEffect(steps, elements, action)) {
                filtered.merge("submitEffectAfterClick", 1, Integer::sum); continue;
            }
            String page = str(action, "pageUrl");
            if (kind.equals("navigate")) {
                if (page.isBlank()) page = str(action, "url");
                if (page.equals(lastPage) && !steps.isEmpty() && "navigate".equals(str(steps.get(steps.size()-1), "action")) &&
                    Objects.equals(str(action,"tabId"), str(steps.get(steps.size()-1),"tabId"))) {
                    filtered.merge("duplicateNavigate", 1, Integer::sum); continue;
                }
                lastPage = page;
            }
            String tab = str(action, "tabId");
            Map<String, Object> step = Json.map("step", steps.size() + 1, "sourceSequence", action.get("sequence"),
                "action", kind, "recordedAt", action.get("recordedAt"), "tabId", tab,
                "pageUrl", page, "pageTitle", action.get("title"), "frame", action.getOrDefault("frame", Map.of()),
                "frameId", action.get("frameId"));
            if (kind.equals("navigate")) {
                step.put("url", action.getOrDefault("url", page));
                step.put("description", "Navigate to " + str(step, "url"));
                step.put("navigationSource", action.get("navigationSource"));
                step.put("replaySuggested", steps.isEmpty());
                if (!steps.isEmpty()) step.put("observationReason", "Navigation caused by earlier app action; do not replay as an additional browser.get() without review.");
            } else {
                String identity = identity(action);
                Map<String, Object> element = elements.get(identity);
                if (element == null) {
                    String id = String.format(Locale.ROOT, "E%04d", elements.size() + 1);
                    element = elementDetails(action, id);
                    element.put("usedInSteps", new ArrayList<Integer>());
                    elements.put(identity, element);
                }
                String elementId = str(element, "elementId");
                // Focus/click before typing or changing a control is normally redundant.
                if (Set.of("fill", "check", "select", "fileSelected").contains(kind) && !steps.isEmpty()) {
                    Map<String, Object> previous = steps.get(steps.size() - 1);
                    if ("click".equals(str(previous, "action")) && elementId.equals(str(previous, "elementId")))
                        steps.remove(steps.size() - 1);
                }
                // A double-click emits two click events before dblclick. Keep one action.
                if (kind.equals("doubleClick")) {
                    for (int i = 0; i < 2 && !steps.isEmpty(); i++) {
                        Map<String, Object> previous = steps.get(steps.size() - 1);
                        if ("click".equals(str(previous, "action")) && elementId.equals(str(previous, "elementId")))
                            steps.remove(steps.size() - 1);
                        else break;
                    }
                }
                step.put("elementId", elementId);
                // Self-contained, compact action target. Full context and ALL candidates live
                // once in the element repository, referenced by the same elementId.
                step.put("element", compactStepElement(element));
                if (action.containsKey("value")) step.put("value", action.get("value"));
                if (action.containsKey("checked")) step.put("checked", action.get("checked"));
                if (action.containsKey("selected")) step.put("selected", action.get("selected"));
                if (action.containsKey("selectedOptions")) step.put("selectedOptions", action.get("selectedOptions"));
                if (action.containsKey("files")) step.put("files", action.get("files"));
                if (action.containsKey("scrollX")) step.put("scrollX", action.get("scrollX"));
                if (action.containsKey("scrollY")) step.put("scrollY", action.get("scrollY"));
                if (kind.equals("keyDown")) step.put("key", Json.object(action.get("event")).get("key"));
                step.put("description", describe(kind, action));
                step.put("replaySuggested", !"submit".equals(kind));
                if ("submit".equals(kind)) step.put("observationReason", "Submit DOM event; often caused by preceding click or Enter key.");
                if (kind.equals("fill") && !steps.isEmpty()) {
                    Map<String, Object> previous = steps.get(steps.size() - 1);
                    if ("fill".equals(str(previous, "action")) && elementId.equals(str(previous, "elementId"))) {
                        // Text typed in multiple bursts is one set-value step until another action intervenes.
                        steps.remove(steps.size() - 1);
                    }
                }
            }
            steps.add(step);
        }
        // Re-number after gesture collapsing. Rebuild the used-in-steps index consistently.
        for (Map<String, Object> el : elements.values()) el.put("usedInSteps", new ArrayList<Integer>());
        for (int i = 0; i < steps.size(); i++) {
            Map<String, Object> step = steps.get(i);
            step.put("step", i + 1);
            Object id = step.get("elementId");
            if (id != null) for (Map<String, Object> el : elements.values()) if (id.equals(el.get("elementId"))) {
                @SuppressWarnings("unchecked") List<Integer> used = (List<Integer>) el.get("usedInSteps");
                used.add(i + 1); break;
            }
        }
        elements.entrySet().removeIf(entry -> Json.array(entry.getValue().get("usedInSteps")).isEmpty());
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("schemaVersion", "2.0");
        result.put("format", "eliya-automation-flow");
        for (String k : List.of("sessionId","applicationUrl","browser","recordingStartedAt","recordingStoppedAt","exportedAt"))
            result.put(k, session.get(k));
        result.put("summary", Json.map("rawEventCount", raw.size(), "testStepCount", steps.size(),
            "uniqueElementCount", elements.size(), "filteredNoiseCount", raw.size() - steps.size(),
            "filteredByType", filtered,
            "note", "Locator uniqueness is verified only at capture time within its DOM root. Re-validate at playback; role and label are Playwright strategies, not native Selenium By strategies."));
        result.put("steps", steps);
        result.put("elements", new ArrayList<>(elements.values()));
        result.put("limitations", List.of(
            "DOM/locator information is a snapshot at interaction time; app state may change.",
            "Selectors in iframes must be resolved in the recorded frame, not the top document.",
            "Open shadow-root locator paths require shadow-aware playback. Closed shadow DOM cannot be inspected.",
            "Only recorded interactions are exported; assertions and expected test outcomes require tester input.",
            "Values, text and attributes can contain business data: inspect exports before sharing."));
        return result;
    }

    private static boolean withinMillis(String prior, String next, long maximum) {
        try {
            long delta = Duration.between(Instant.parse(prior), Instant.parse(next)).toMillis();
            return delta >= 0 && delta <= maximum;
        } catch (Exception ignored) { return false; }
    }

    private static boolean supersededByFollowingInteraction(List<Map<String, Object>> raw, int from, Map<String, Object> click) {
        String target = identity(click);
        for (int i = from + 1; i < raw.size() && i <= from + 12; i++) {
            Map<String, Object> next = raw.get(i);
            if (!withinMillis(str(click, "recordedAt"), str(next, "recordedAt"), 1250)) break;
            String type = str(next, "type");
            if ("navigate".equals(type)) break;
            if (Set.of("doubleClick", "fill", "check", "select").contains(type) && target.equals(identity(next))) return true;
            if (isMeaningful(next) && !"click".equals(type)) break;
        }
        return false;
    }

    /** Keep browser-observed form submission without creating a duplicate replay step. */
    private static boolean mergeSubmitEffect(List<Map<String, Object>> steps,
        Map<String, Map<String, Object>> elements, Map<String, Object> submitted) {
        Map<String, Object> formAttributes = Json.object(submitted.get("attributes"));
        String formId = str(formAttributes, "id");
        for (int i = steps.size() - 1; i >= Math.max(0, steps.size() - 2); i--) {
            Map<String, Object> candidate = steps.get(i);
            if (!"click".equals(str(candidate, "action"))) continue;
            if (!Objects.equals(str(candidate,"tabId"), str(submitted,"tabId")) ||
                !Objects.equals(Json.stringify(candidate.get("frame")), Json.stringify(submitted.get("frame")))) continue;
            Map<String, Object> element = Json.object(candidate.get("element"));
            // Step payload is intentionally small; full ancestry is in the repository.
            for (Map<String, Object> stored : elements.values())
                if (Objects.equals(stored.get("elementId"), candidate.get("elementId"))) {
                    element = stored; break;
                }
            Map<String, Object> attrs = Json.object(element.get("attributes"));
            String tag = str(element, "tag"), type = str(element, "inputType");
            if (!("button".equals(tag) && !"button".equals(type) && !"reset".equals(type)) &&
                !("input".equals(tag) && Set.of("submit", "image").contains(type))) continue;
            boolean inForm = false;
            if (formId.equals(str(attrs, "form")) && !formId.isEmpty()) inForm = true;
            for (Object item : Json.array(element.get("ancestors"))) {
                Map<String, Object> ancestor = Json.object(item);
                if ("form".equals(str(ancestor,"tag"))) {
                    if (formId.isEmpty() || formId.equals(str(Json.object(ancestor.get("attributes")), "id"))) inForm = true;
                }
            }
            if (!inForm) continue;
            candidate.put("observedEffects", List.of("formSubmitted"));
            return true;
        }
        return false;
    }

    private static boolean importantKey(Map<String, Object> action) {
        Map<String, Object> ev = Json.object(action.get("event"));
        String key = str(ev, "key");
        return Set.of("Enter", "Escape", "Tab", "F2", "F4", "ArrowDown", "ArrowUp", "ArrowLeft", "ArrowRight", "Delete", "Backspace", "Home", "End", "PageUp", "PageDown", " ", "Spacebar").contains(key) ||
            (Boolean.TRUE.equals(ev.get("ctrlKey")) || Boolean.TRUE.equals(ev.get("metaKey"))) &&
                Set.of("a", "A", "s", "S", "f", "F").contains(key);
    }

    private static String identity(Map<String, Object> action) {
        Map<String, Object> loc = Json.object(action.get("locators"));
        String sel = str(loc, "css");
        if (sel.isEmpty()) sel = str(action, "selector");
        if (sel.isEmpty()) sel = str(loc, "xpath");
        if (sel.isEmpty()) sel = str(action, "tag") + ":" + str(action, "text");
        return str(action,"tabId") + "|" + str(action,"frameId") + "|" +
            Json.stringify(action.get("frame")) + "|" + sel;
    }

    private static Map<String, Object> elementDetails(Map<String, Object> action, String id) {
        Map<String, Object> dom = Json.object(action.get("dom"));
        List<Object> ancestors = Json.array(dom.get("ancestorChain"));
        List<Object> chain = ancestors.isEmpty() ? List.of() : ancestors.subList(1, Math.min(ancestors.size(), 8));
        Map<String, Object> tree = Json.object(dom.get("targetTree"));
        Map<String, Object> context = Json.object(action.get("context"));
        Map<String, Object> parent = Json.object(context.get("parent"));
        if (parent.isEmpty() && ancestors.size() > 1) parent = Json.object(ancestors.get(1));
        List<Object> children = Json.array(context.get("children"));
        if (children.isEmpty() && !tree.isEmpty()) {
            children = new ArrayList<>();
            for (Object child : Json.array(tree.get("children"))) {
                if (children.size() >= 20) break;
                children.add(compactTree(Json.object(child), 1));
            }
        }
        Map<String, Object> locator = Json.object(action.get("locators"));
        List<Object> candidates = Json.array(locator.get("candidates"));
        if (candidates.isEmpty()) candidates = fallbackCandidates(locator);
        Map<String, Object> preferred = candidates.isEmpty() ? Map.of() : Json.object(candidates.get(0));
        Map<String, Object> element = Json.map("elementId", id,
            "tag", action.get("tag"), "inputType", action.get("inputType"),
            "text", action.get("text"), "attributes", action.getOrDefault("attributes", Map.of()),
            "properties", compactProperties(Json.object(action.get("properties"))),
            "locators", Json.map("recommended", preferred, "candidates", candidates,
                "shadowPath", locator.getOrDefault("shadowPath", List.of()),
                "css", locator.get("css"), "xpath", locator.get("xpath"),
                "testId", locator.get("testId"), "role", locator.get("role"),
                "accessibleName", locator.get("accessibleName"), "label", locator.get("label")),
            "parent", compactContextNode(parent), "ancestors", compactContextNodes(chain, 7),
            "children", compactContextNodes(children, 14), "siblings", compactContextNodes(Json.array(dom.get("siblings")), 12),
            "nearbyInteractiveElements", compactContextNodes(Json.array(context.get("relatedInteractiveElements")), 12),
            "eventTarget", compactContextNode(Json.object(context.get("eventTarget"))),
            "contextChildrenTruncated", context.getOrDefault("childrenTruncated", false),
            "domCaptureTruncated", dom.getOrDefault("truncated", false));
        return element;
    }

    /** The target is present on each step, but detailed nearby-element candidate lists are not duplicated. */
    private static Map<String, Object> compactStepElement(Map<String, Object> element) {
        Map<String, Object> locators = Json.object(element.get("locators"));
        List<Object> candidateSummary = new ArrayList<>();
        for (Object item : limited(Json.array(locators.get("candidates")), 3)) {
            Map<String, Object> c = Json.object(item);
            candidateSummary.add(Json.map("strategy", c.get("strategy"), "value", c.get("value"),
                "score", c.get("score"), "unique", c.get("unique")));
        }
        return Json.map("elementId", element.get("elementId"), "tag", element.get("tag"),
            "inputType", element.get("inputType"), "text", element.get("text"),
            "attributes", element.get("attributes"), "properties", element.get("properties"),
            "locators", Json.map("recommended", locators.get("recommended"), "topCandidates", candidateSummary),
            "parent", element.get("parent"), "children", limited(Json.array(element.get("children")), 8),
            "eventTarget", element.get("eventTarget"),
            "contextReference", "Full ancestors, siblings, related elements and locators are in elements[] for this elementId.");
    }

    /** Context nodes contain attributes and a compact usable locator, not many nested candidates. */
    private static Map<String, Object> compactContextNode(Map<String, Object> src) {
        if (src.isEmpty()) return Map.of();
        Map<String, Object> out = Json.map("tag", src.get("tag"),
            "attributes", src.getOrDefault("attributes", Map.of()));
        for (String key : List.of("id", "role", "text", "relation"))
            if (src.containsKey(key) && src.get(key) != null && !Json.str(src.get(key)).isBlank())
                out.put(key, src.get(key));
        Map<String, Object> locs = Json.object(src.get("locators"));
        Map<String, Object> best = Json.array(locs.get("candidates")).isEmpty() ? Map.of() :
            Json.object(Json.array(locs.get("candidates")).get(0));
        if (!best.isEmpty()) out.put("locator", Json.map("strategy", best.get("strategy"),
            "value", best.get("value"), "unique", best.get("unique")));
        else if (!str(locs, "css").isBlank()) out.put("locator", Json.map("strategy", "css", "value", locs.get("css")));
        return out;
    }

    private static List<Object> compactContextNodes(List<Object> nodes, int max) {
        List<Object> result = new ArrayList<>();
        for (Object item : limited(nodes, max)) {
            Map<String, Object> compact = compactContextNode(Json.object(item));
            if (!compact.isEmpty()) result.add(compact);
        }
        return result;
    }

    private static Map<String, Object> compactProperties(Map<String, Object> props) {
        Map<String, Object> out = new LinkedHashMap<>();
        for (String k : List.of("id", "className", "visible", "disabled", "readOnly", "required", "checked",
            "selected", "multiple", "contentEditable", "tabIndex", "value", "selectedIndex"))
            if (props.containsKey(k)) out.put(k, props.get(k));
        return out;
    }

    private static List<Object> limited(List<Object> items, int max) {
        return new ArrayList<>(items.subList(0, Math.min(items.size(), max)));
    }

    private static Map<String, Object> compactTree(Map<String, Object> node, int depth) {
        Map<String, Object> result = Json.map("tag", node.get("tag"), "attributes", node.getOrDefault("attributes", Map.of()),
            "text", node.getOrDefault("directText", ""));
        if (depth < 2) {
            List<Object> children = new ArrayList<>();
            for (Object item : Json.array(node.get("children"))) {
                if (children.size() >= 8) break;
                children.add(compactTree(Json.object(item), depth + 1));
            }
            if (!children.isEmpty()) result.put("children", children);
        }
        return result;
    }

    private static List<Object> fallbackCandidates(Map<String, Object> old) {
        List<Object> result = new ArrayList<>();
        for (String type : List.of("testId", "id", "css", "xpath", "name", "label", "role", "placeholder")) {
            String value = str(old, type);
            if (value.isBlank() || value.equals("[REDACTED]")) continue;
            String strategy = switch (type) { case "testId" -> "test-id"; default -> type; };
            result.add(Json.map("strategy", strategy, "value", value, "score", 0,
                "unique", null, "matchCount", null, "verifiedAtCapture", false,
                "reason", "Legacy recording: uniqueness not measured; validate before use."));
        }
        return result;
    }

    private static String describe(String action, Map<String, Object> raw) {
        Map<String, Object> loc = Json.object(raw.get("locators"));
        String label = str(loc, "accessibleName");
        if (label.isBlank()) label = str(loc, "label");
        if (label.isBlank()) label = str(loc, "testId");
        if (label.isBlank()) label = str(loc, "placeholder");
        if (label.isBlank()) label = str(raw, "tag") + " " + str(loc, "css");
        if (label.length() > 110) label = label.substring(0, 107) + "...";
        String prefix = switch (action) {
            case "fill" -> "Enter text in "; case "check" -> "Set check state on ";
            case "select" -> "Select option in "; case "fileSelected" -> "Choose file in ";
            case "doubleClick" -> "Double-click "; case "rightClick" -> "Right-click ";
            case "keyDown" -> "Press key on "; case "scroll" -> "Scroll ";
            case "submit" -> "Submit "; case "drop" -> "Drop onto ";
            default -> "Click ";
        };
        return prefix + label;
    }

    private static String str(Map<String, Object> map, String name) { return Json.str(map.get(name)); }
}
