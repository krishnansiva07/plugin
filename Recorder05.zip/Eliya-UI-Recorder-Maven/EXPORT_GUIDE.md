# Automation export guide — example workflow

This recorder produces **test-design data**, not runnable or complete test cases. Create assertions, data fixtures and waits in your framework.

## Example user journey

1. Navigate to the checkout page.
2. Enter a customer name.
3. Click Submit order.
4. Observe the submit event (do not replay it as an extra action).

`steps` maintains the observed order and provides `sourceSequence` to trace a step back to its original debug event. A `replaySuggested` flag distinguishes likely automation actions from observed browser events. `elements` de-duplicates interacted elements by recorded frame/tab/selector and tracks `usedInSteps`.

## Choosing a locator

Prefer **verified unique `data-testid`** (or the site's designated test attribute), then verified stable IDs and meaningful element attributes. Semantic `role+name`/`label` locators are provided as accessibility-aware choices but marked as **unverified** for uniqueness; validate through the automation framework. Use positional CSS/XPath only as a fallback. Revalidate selectors after UI changes. The score is a *heuristic ranking*, **not an accuracy probability**.

`scope` identifies the query root. `document` means the page or active iframe document. `open-shadow-root` means the selector only applies after resolving its shadow root. A `shadow-css` locator's displayed `>>>` separator is a human-readable path, not valid Java/Selenium CSS.

## Selenium Java example

```java
// Requires Selenium Java dependency in YOUR test framework, not in the recorder.
WebElement customer = driver.findElement(By.cssSelector("[data-testid='customer-input']"));
customer.clear();
customer.sendKeys("Alice Test");

WebElement submit = driver.findElement(By.cssSelector("[data-testid='submit-order']"));
new WebDriverWait(driver, Duration.ofSeconds(10))
    .until(ExpectedConditions.elementToBeClickable(submit)).click();
// Add a business assertion; do not automatically call submit() again.
```

For frame interactions:

```java
// Locate frame using its captured id/name/src; then find the child element.
driver.switchTo().frame(driver.findElement(By.cssSelector("iframe[name='checkout']")));
// ... perform element interactions ...
driver.switchTo().defaultContent();
```

For open shadow roots, use Selenium 4's `WebElement.getShadowRoot()` / `SearchContext`; do not pass a `>>>` string to `By.cssSelector`.

## Playwright TypeScript example

```ts
await page.getByTestId('customer-input').fill('Alice Test');
await page.getByRole('button', { name: 'Submit order', exact: true }).click();
// Verify expected outcome using expect(...).
```

`getByTestId` assumes the attribute `data-testid` unless configured otherwise. For `data-qa` and similar attributes, use an appropriate CSS selector or configure the test-ID attribute.

## Excel workbook

The recorder writes seven sheets: **Test Steps**, **Element Repository**, **Locator Candidates**, **Attribute Catalog**, **DOM Context**, **Flow Overview**, and **Session Summary**. Each row is searchable/filterable in Excel. `Locator Candidates` is one row per alternative, suitable for test-maintenance review. `Attribute Catalog` has searchable rows for target and nearby HTML attributes. `DOM Context` helps locate surrounding fields, labels, table rows and containers.

The **raw event journal and raw debug export** still exist, but are intended for troubleshooting, not direct code generation. Debug and automation exports may include ordinary on-screen business content. Review before sharing.
