# ELIYA — 41-change implementation and validation status

**Package classification:** updated Java 17 source package, **NOT** a production-approved or executable-JAR release.

This package extends the existing ELIYA application in place. The 41 IDs below refer to the
agreed requirements. "Code present" means an implementation can be inspected in this source,
not that a complete Spring Boot build or end-to-end provider test succeeded. "Partial" flags a
material limitation. Do not interpret this table as a claim that the entire roadmap is complete.

| ID | Requirement | Code status | Evidence / outstanding limitation |
|---:|---|---|---|
| 1 | Agentic + Vision roles | Code present | Agent mode has independent optional vision model setting. |
| 2 | Preserve normal Chat model | Code present | Existing Chat settings retained; regression suite pending. |
| 3 | Optional Vision | Code present | Text-only flow does not require a configured Vision model. |
| 4 | Dynamic model capabilities | Partial | User-editable models and runtime gateway attempt; automatic provider-specific capability discovery is not universal. |
| 5 | Independent providers/endpoints | Code present | Separate Vision endpoint/key, falling back to Agent connection. |
| 6 | Workspace document discovery | Code present | Local source discovery with limits. |
| 7 | Visual content detection | Partial | PDF raster/vector heuristics and modern Office embedded media; unsupported embedded shapes/charts may need conversion. |
| 8 | Text/vision routing | Code present | Java scanner and Vision adapter. |
| 9 | Multiple formats | Partial | DOCX/XLSX/PPTX/PDF/images/text; legacy binary Office and exotic formats not guaranteed. |
| 10 | Complete-document multimodal analysis | Partial | Bounded context plus related images in multimodal batches; arbitrary gateway native full-DOCX/PDF upload not implemented. |
| 11 | Jira/Confluence images | Partial | MCP image result blocks are analysed; actual attachments depend on the MCP server exposing their bytes. |
| 12 | Persistent local knowledge | Code present | Source-hashed durable workspace records on local disk. |
| 13 | Unified workspace/MCP/code evidence | Partial | Workspace knowledge and code retrieval cooperate; remote MCP evidence is returned to Agent but not fully versioned as persistent remote index. |
| 14 | Changed-document reanalysis | Code present | Content hashing and per-source replacement. |
| 15 | Context retrieval | Code present | Budgeted lexical retrieval and exact-source chunk reads; no embedding/vector reranking. |
| 16 | Source references and history | Code present | Local source locators, warnings, model signatures, persistent run journal. |
| 17 | Task-complexity recognition | Partial | Existing large-task heuristics; no measured difficulty predictor. |
| 18 | Phase-based plans | Code present | Existing plan-first runtime, durable work ledger, user approval. |
| 19 | Nested workspace path handling | Code present | Existing validated path/resolved workspace interfaces; Windows integration not tested here. |
| 20 | Progressive workspace exploration | Code present | Existing profile/retrieval, targeted read and deferred tool discovery. |
| 21 | Checkpoints and recovery | Code present | Existing durable steps, revision-aware retries and checkpoints. |
| 22 | Explicit constraint verification | Partial | Prompt + final verifier and diff tools; arbitrary natural-language constraints cannot be proven automatically. |
| 23 | Task-aware context | Code present | Existing token-aware context plus new source knowledge. |
| 24 | Batching and caching | Code present | Vision batches, source hashes, active-step cache. |
| 25 | Long-running optimisations | Partial | Existing checkpoints/batching; no benchmark on target hardware/provider. |
| 26 | Agent dual-model controls | Code present | Agent Vision and Agentic inputs. |
| 27 | Knowledge view | Code present | Workspace Knowledge panel and API. |
| 28 | Image/analysis progress | Code present | Per-source counts, status, warnings and job polling. |
| 29 | Progress/recovery controls | Code present | Existing agent execution progress and backend run tracking. |
| 30 | Document completeness verification | Partial | Counts per-image locator acknowledgement and reports gaps; model acknowledgement is not proof of semantic accuracy. |
| 31 | Execution verification | Partial | Existing compile/run/test verification loops; full user-constraint proof not implemented. |
| 32 | Regression testing | Partial | JUnit tests added but full Maven/Spring suite not executable here. |
| 33 | Existing architecture integration | Code present | Changes use existing services/controller/API architecture; integration build pending. |
| 34 | Backward compatibility | Partial | Legacy settings/controllers retained; MCP tools without readOnlyHint are intentionally blocked in protected mode. |
| 35 | Fully validated executable package | NOT COMPLETE | JavaScript, Java grammar and isolated Java smoke tests passed; Maven missing, dependency download blocked. |
| 36 | Deletion approval setting | Code present | Separate confirm-file-deletion flag (enabled by default). |
| 37 | Full-path approval popup | Code present | Per-operation UI dialog, full resolved file paths, exact-file hashes. |
| 38 | Suspend for approval | Code present | Backend awaits a one-operation decision; no run-wide deletion grant. |
| 39 | 60-second expiration | Code present | Backend expires decisions, frontend shows countdown. |
| 40 | Automatic rollback | Partial | Local source-tree baseline snapshots; dependency/build folders, external MCP actions and arbitrary child processes are not fully transactional. |
| 41 | Deletion bypass prevention | Partial | Built-in file tools have preflight, risky shell syntax is denied, writable/unannotated MCP tools are denied in protected mode. An application-level checker is not an OS sandbox and cannot intercept every destructive script. |

## What was actually validated in this environment

- **PASS**: `node --check` for the application and Markdown renderer JavaScript.
- **PASS**: CSS stylesheet parsed without syntax errors.
- **PASS**: `javac` parser accepted all Java source/test files at the Java 17 grammar level. This is *not* symbol resolution or dependency compilation.
- **PASS**: Actual `AgentApprovalService`, `ProtectedRunSnapshotService` and shell guard passed isolated Java 17 smoke checks using minimal framework stubs.
- **PASS**: Actual `VisionDocumentService` and image encoding adapter passed isolated Java 17 smoke checks with a simulated model response.
- **PASS**: 11 frontend-to-backend source-contract checks for model selectors, knowledge routes, deletion popup, backend deadline and rollback wiring.
- **NOT RUN**: Full Maven build, Spring Boot start, JUnit integration, real Windows workspace test, live Vision provider test and Jira/Confluence MCP integration; the container lacks Maven/dependencies and cannot reach Maven Central.

## Safety and release blockers

1. **Do not deploy as a trusted deletion-proof product yet.** For a strict guarantee, execute *all* shell/build/test/MCP activity under OS-level confinement or prohibit it in protected mode. Merely detecting suspicious command names cannot provide full file-system isolation.
2. Ensure snapshot storage (`app.data-dir`) is **outside all writable project/reference directories**. The code fails closed on an overlap. The protected snapshot tracks selected source trees and has an explicit 750 MB / 35,000-file limit.
3. Protected rollback can affect concurrent external edits in the same workspace; avoid working on the same source tree from another editor/process during a protected run.
4. Test the selected Vision endpoint with representative DOCX/PDF screenshots. Endpoints vary: this package uses text-plus-image messages rather than assuming universal native document upload support.
5. To produce an executable Java 17 JAR, push this source package to a GitHub repository and run **Verify and package ELIYA** manually, or run `validate-local.bat` on a Windows machine with working Maven Central access. Do not use the JAR until the full workflow is green and protection gaps are assessed.
