# AgentService.java targeted repair (source candidate)

## Confirmed Java 17 compilation defect

In `AgentService.run`, the `onStep` parameter was reassigned to wrap the original event handler, and then the newly introduced document-analysis progress lambda captured `onStep`. Java requires captured local variables to be final or effectively final. The former source could therefore fail with:

`local variables referenced from a lambda expression must be final or effectively final`

**Repair:** Capture a final alias, `documentProgress`, immediately before invoking `workspaceKnowledge.analyse(...)` and use that alias from the callback. Existing logging and UI forwarding are preserved; no execution logic was changed.

## Completed limited checks

- JDK compiler API parsed all project Java files with `--release 17` (syntax check only).
- `bash qa/offline-smoke/run.sh` passed: isolated approval and rollback tests.
- `bash qa/offline-smoke/vision.sh` passed: isolated Vision adapter tests.
- `python3 qa/offline-smoke/ui-contract.py` passed 11 static UI/API contracts.
- JavaScript source syntax checks passed.

**Release status: NOT VERIFIED.** Full Maven compilation/type checking, full JUnit regression, live MCP/LLM calls, full protected Agent run and executable JAR generation have not been performed. The environment does not contain Maven/dependency cache. Other integration defects may remain. Keep deletion approval enabled only for disposable test workspaces until end-to-end security validation is complete.
