# Named reference folders — implementation and validation

## User flow

1. Choose **Browse reference** or **Reference path**, then enter a unique prompt name such as `LegacySelenium`.
2. The selected folder is indexed using the existing local indexing mechanism. The name is saved with the read-only reference in browser storage shared by Chat and Agent and preserved across conversations.
3. Click the pencil icon on a reference chip to rename it. Renaming does not recreate the index or change the folder path.
4. Prompt by name, e.g. `Use LegacySelenium for migration patterns and Requirements for missing cases. Apply changes only to the active project.`

## Runtime behavior

- The UI sends both the selected project IDs and a project-ID-to-name mapping. Server validation ensures referenced IDs are selected, names are unique simple identifiers, and a reference cannot be named `workspace`.
- Chat retrieves the named sources when the user names one or more references, and includes the name in the evidence heading. If none are named, selected reference retrieval retains previous broad-search behavior.
- Agent appends the named reference-to-physical-path mapping to the effective run prompt. Resource resolution preserves the explicit read-only role and assigns the lowercase prompt name as its resource alias, e.g. `@legacyselenium`.
- The selected reference label takes precedence over a less restrictive label for the same physical path, preventing promotion to a writable secondary project through a duplicate path line. This does not sandbox arbitrary shell commands.
- Existing unnamed references loaded from previous browser storage receive a sanitized folder-based default. User-specified aliases do not change the underlying project/index ID.

## Validation

- Node UI test suite: project selection, named reference persistence, rename without reindex, duplicate-name protection, reference separation and existing deletion-approval controls.
- Java 17 isolated compilation: `ChatRequest` and `PromptResourceResolver`; isolated execution: named alias resolution, read-only status, physical path matching, and priority of the read-only named label over an earlier differently labelled path.
- Full Maven/Spring Boot compilation and application integration tests **not completed** in this environment because Maven/dependencies were unavailable. Do not treat this source ZIP as a verified executable JAR.
