# ELIYA portable database fix (Windows / macOS / Linux)

## Root cause

Spring Boot's default datasource configuration can be overridden by host environment
variables such as `SPRING_DATASOURCE_DRIVER_CLASS_NAME=oracle.jdbc.OracleDriver`.
A developer running the very same JAR on another machine can therefore get
`Cannot load driver class: oracle.jdbc.OracleDriver`, followed by a Hibernate
`Unable to determine Dialect without JDBC metadata` error if only the driver
property is overridden.

## Fix

- `PortableDatabaseConfiguration` defines an **application-owned**, primary H2
  datasource. Spring Boot backs off from creating its generic datasource, and
  host `SPRING_DATASOURCE_*` settings cannot silently change the driver, URL,
  username or password.
- Hibernate dialect is pinned to H2 in both app configuration and a Hibernate
  properties customizer.
- Database files remain at the existing `app.database.path`, which normally
  resolves to `<user-home>/.advanced-ai-workbench/data/chatdb` on all supported
  operating systems. This preserves the user's local history across JAR upgrades.
- The database parent folder is created when needed. Directory permission
  problems fail with an actionable message instead of a generic JDBC error.
- H2 is packaged as a runtime dependency in `pom.xml`, unchanged.
- No UI, chat, agent, workspace or file-deletion behavior was modified.

## Developer instructions

With Java 17+ available, run **the same built JAR** on any of the three OSes:

```sh
java -jar eliya.jar
```

No JDBC drivers, database server or per-machine datasource arguments are needed.

A user who intentionally needs a different *H2 storage path* can set the
application-specific JVM option `-Dapp.database.path=/path/to/chatdb` before
`-jar` (do not use `SPRING_DATASOURCE_URL`). Do not delete existing database
files when upgrading. Avoid starting multiple concurrent ELIYA copies against
one profile without coordinating access.

## Verification

`PortableDatabaseConfigurationTest` injects Oracle URL/driver/username and
Oracle JPA dialect into an isolated Spring application context, then confirms
that ELIYA still connects to H2, uses the H2 dialect, and persists the DB.

To run on a machine with Maven/Java and dependency access:

```sh
./mvnw clean package
./mvnw -Pfull-tests test
java -jar target/eliya.jar
```
