# Browse path error fix (October 1, 2026)

## Cause in the preceding source
`POST /api/local-folders/browse` used only Swing `JFileChooser` and let `IllegalStateException`, `HeadlessException`, dialog startup failures and OS/desktop errors propagate to Spring as HTTP 500. A rejected origin also propagated as an unhandled `SecurityException` and could show the same generic error.

## Changes
- Browse uses macOS `osascript` native folder selection first; Windows and Linux retain Swing and have native fallback via PowerShell or `zenity` (when available) if Swing is unavailable. This still requires a graphical user session on the ELIYA backend machine.
- Expected desktop failures return HTTP 503 `{ "code":"PICKER_UNAVAILABLE", "message":"..." }` instead of HTTP 500. Browser UI automatically opens the existing `Enter path` / `Reference path` prompt. Cancellation does not invoke a fallback prompt.
- Non-local and origin-mismatched requests return structured HTTP 403 messages. No remote user may open the local system's native dialog.
- Selected folders are canonicalized and validated before being passed to the existing project-indexing pipeline. The project/references and indexing behavior are unchanged.

## Run and verify
1. Build with JDK 17 and Maven: `./mvnw -Pfull-tests clean verify` (if the machine has Maven/network access).
2. Start the newly built `target/eliya.jar` on the same computer as the browser. Open ELIYA at its local address, e.g. `http://localhost:8080`.
3. Click `Browse project` or `Browse reference`, choose a folder, and confirm indexing and named-reference selection work.
4. In a non-graphical environment, Browse now explains why it cannot open and prompts for `Enter path` instead. Use an absolute path on the **machine running ELIYA**.
5. If the folder dialog opens but registering/indexing the selected project still returns an error, consult the ELIYA process log; this is a different endpoint, `/api/projects/local`.

## Validation in this environment
- `javac --release 17` isolated compile of the picker and request/response contract, plus Java headless/loopback/origin smoke checks.
- `node --check` of the browser JavaScript and `node --test` of UI tests, including 503 fallback/cancellation and existing named references, workspace and deletion-approval tests.
- Full Maven build and graphical Windows/macOS dialog tests are not possible in the current Linux/headless environment. No prebuilt JAR is included; the ZIP is updated source.
