# ELIYA — folder-picker, project-indexing, and Chat responsiveness fix

## Issues traced in the preceding source

1. `/api/local-folders/browse` tried synchronous Swing `JFileChooser` from a servlet request on Windows/Linux. Swing file-system enumeration, inaccessible network mounts, modal focus and a 5-minute native fallback could leave the request running and prevent the next chooser from opening.
2. `POST /api/projects/local` invoked `ProjectService.createLocal` (transactional recursive file walk, H2 insert/update for as many as 3,000 full source files), then `WorkspaceRetrievalIndexService.warmRoot` (a *second* recursive scan) **before returning** to the UI.
3. Chat selected its project context by deserializing all H2 `ProjectFileEntity` contents, scoring each, then retrieving a second copy from the filesystem index. This work was performed before answering each question.
4. Agent startup independently called `workspaceRetrieval.warm(ws)`, which could start another full scan while initial indexing was in progress.

## Implemented changes

- On Windows use Windows Forms folder picker through PowerShell; on macOS use `osascript`; on Linux use `zenity` or `kdialog`. No blocking Swing fallback. Only one desktop dialog is allowed at a time; a second call returns HTTP 409 `PICKER_BUSY`. A picker that cannot launch returns an actionable HTTP 503 and the UI switches to **Enter path**. The OS dialog process is bounded to 90 seconds; the browser fetch is bounded to 95 seconds.
- Local project/reference registration only validates and saves the canonical local path. `LocalProjectIndexService` queues a single bounded background indexing worker. Folder addition returns immediately instead of waiting for the file scan. The index has a status endpoint: `GET /api/projects/{id}/index-status` with `queued`, `indexing`, `completed`, or `failed`, file counts and a detail message. Rescan is background work as well.
- Local source files are **not copied a second time into H2**. Chat uses a bounded, cached local retrieval index. For browser-uploaded (nonlocal) projects, the original database-backed project context is preserved. Existing H2 records and conversation history are not deleted by this change.
- On every new JVM startup, previously selected projects and reference folders are re-indexed in the background; selected names and paths remain shared by Chat and Agent. Querying a project while its index is pending tells the user that code evidence is not ready, rather than blocking the request or inventing source-code details.
- Agent startup uses any completed cached retrieval index and otherwise continues with its live workspace tools. It no longer duplicates the initial scan. Agent write operations retain their existing safety checks and run-start baseline hashing; the latter still has a cost on very large projects.
- The UI does not disable Chat while folder indexing runs. Folder buttons re-enable after registration, independent of the indexing job. Read-only reference names are preserved.

## Known limitations and boundaries

- Native OS graphical folder pickers **must** run in an interactive logged-in desktop session of the machine hosting ELIYA. Headless/remote/browser-on-different-machine environments must use **Enter path**. Native Windows and macOS graphical behaviour still needs manual testing on those operating systems.
- The code index is bounded and based on lexical retrieval with limited samples. It cannot guarantee an answer to every question about arbitrarily large files or unindexed images; Agent can inspect live source files and optional document/vision analysis remains separate.
- H2 still stores conversations and other application data. Old locally indexed source rows are deliberately left untouched for data preservation, but are no longer loaded on every Chat question.
- A network filesystem that stalls during I/O can keep the *single background index worker* occupied. It will not block folder registration or ordinary UI calls, but jobs may remain queued behind it.

## Validation run in this environment

- `node --check src/main/resources/static/app.js`
- `node --test src/test/js/*.test.js` — eight UI tests pass.
- Java 17 isolated compile/test: actual `WorkspaceRetrievalIndexService` and `LocalProjectIndexService`, with minimal Spring/client stubs, successfully indexed a synthetic 1,000-file project in the background; registration completed quickly, cached retrieval found the requested file, duplicate registration did not rescan.
- Java 17 isolated compile/test: actual `LocalFolderPickerController`, with minimal Spring/servlet stubs, rejected concurrent picker requests, handled a headless environment gracefully and checked same-origin requests.

**Not yet validated:** complete Maven/Spring Boot compilation, H2 integration under the real application, actual LLM provider response, and native macOS/Windows desktop dialogs. Maven and the required cached dependencies are not installed in the current environment. On a development machine with Java 17 and Maven, run `mvn -Pfull-tests clean verify` and manually exercise Browse twice, Chat during indexing and Chat after indexing with a representative repository before distributing the JAR.
