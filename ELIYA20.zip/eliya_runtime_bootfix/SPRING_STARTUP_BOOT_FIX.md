# ELIYA Documentation Intelligence - Spring Startup Boot Fix

## Reported failure
Application startup failed while Spring created the bean chain:
`ChatController -> AgentService -> DocumentationIntelligenceService`.
The root cause shown in the startup stack trace was:
`Failed to instantiate DocumentationIntelligenceService: No default constructor found`.

## Root cause
`DocumentationIntelligenceService` intentionally has two constructors:
1. the production constructor accepting Spring's `ObjectMapper`, and
2. a package-private constructor accepting `ObjectMapper + storePath` for deterministic tests/custom storage.

With more than one constructor and no explicitly selected injection constructor, Spring did not know which constructor should be used and fell back to looking for a default constructor, which does not exist.

## Fix
The production constructor is now explicitly marked with Spring `@Autowired`:

```java
@Autowired
public DocumentationIntelligenceService(ObjectMapper objectMapper) {
    this(objectMapper, System.getProperty("advanced.ai.documentationStore", "./data/documentation-runs"));
}
```

The package-private constructor remains available for tests and does not participate in Spring injection.

## Regression protection
`DocumentationIntelligenceServiceTest` now contains a regression test asserting that the public `ObjectMapper` constructor is explicitly annotated with `@Autowired`.

## Validation performed here
- Java 17 isolated compile of `DocumentationIntelligenceService` with minimal dependency stubs: PASS.
- Reflection boot-wiring check: PASS; exactly one constructor is marked for Spring injection.
- Source diff confirms the production change is limited to constructor wiring plus the regression test.

## Environment limitation
A complete Maven/Spring Boot build cannot be executed in this sandbox because Maven is not installed and Maven Central DNS/bootstrap access is unavailable. On a normal development machine, run:

```bash
./mvnw clean package
./mvnw -Pfull-tests test
java -jar target/eliya.jar
```

The original failure occurs during Spring bean construction, so successful application startup is the most important verification after rebuilding the JAR.
