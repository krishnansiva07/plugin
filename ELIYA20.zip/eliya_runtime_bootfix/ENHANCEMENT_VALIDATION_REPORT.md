# Validation report — ELIYA source enhancement candidate

## Executed in this packaging environment

| Check | Result | Method |
| --- | --- | --- |
| Java 17 parsing | **PASS (syntax only)** | JDK Compiler API parsed 96 production/test Java files with `--release 17`; 0 syntax errors. Parsing does NOT establish type correctness or runtime compatibility. |
| Java safety component compilation | **PASS (isolated)** | Real `ProtectedRunSnapshotService`, `AgentApprovalService`, exception and image normalizer compiled with Java 17 using minimal framework stubs. Does NOT compile the Spring application. |
| Isolated rollback behavior | **PASS** | Modified text + deleted binary + newly created nested file restored/removed by actual snapshot service; baseline disposed after success. |
| Isolated approval TTL | **PASS** | Actual approval service rejected `RUN` grant for deletion; unanswered short-TTL request threw timeout; token could not be reused. Test uses milliseconds solely for speed; application config uses 60 seconds. |
| JS source syntax | **PASS** | `node --check` for both `app.js` and `markdown.js`. |
| Deletion approval modal | **PASS (isolated UI logic)** | `node src/test/js/deletion_approval_ui.test.js` verified popup contents/countdown, one-click REST action, closure and expiration disabled state. |
| Static HTML ID wiring | **PASS for new controls** | 11 additional UI/API source checks passed, including full-path confirmation and backend 60-second TTL wiring. Existing dynamic IDs are created at runtime. |
| Application Maven build / full JUnit | **BLOCKED — NOT EXECUTED** | `./mvnw -Pfull-tests clean package` attempted; Maven not installed and DNS for `repo.maven.apache.org` unavailable (`curl: (6) Could not resolve host`). |
| Live vision endpoint, Jira/Confluence, protected full Agent run | **NOT EXECUTED** | Requires real configured endpoints, eligible MCP access and integration test environment. |

## Added regression test sources

- `WorkspaceDocumentScannerTest.java`: DOCX embedded picture and context, text-only PDF, vector flow PDF, text/image mixed selection.
- `AgentApprovalExpiryTest.java`: exclusive one-time deletion grant, TTL expiry and nonreuse.
- `ProtectedRunSnapshotServiceTest.java`: binary/text/nested-file rollback and duplicate snapshot protection.
- `src/test/js/deletion_approval_ui.test.js`: isolated modal state and actions.

Additional isolated validation: `bash qa/offline-smoke/run.sh` (real safety classes), `bash qa/offline-smoke/vision.sh` (real Vision adapter with simulated model), and `python3 qa/offline-smoke/ui-contract.py` (11 checks) all passed.

**Release decision: NOT YET PRODUCTION-VALIDATED.** The ZIP contains buildable-intent source and tests, not a verified JAR. Run full Maven compilation/tests; resolve any integration failures and address arbitrary-shell sandboxing before describing file-deletion protection as impossible to bypass.
