# Shared folder selection and automatic code indexing

## What changed

- Both **Chat** and **Agent** now display the same **SHARED FOLDERS** controls above the composer.
- **Browse project** opens the operating system's native directory picker using Java Swing on the same desktop on which the ELIYA JVM runs. **Enter path** is available when ELIYA runs headlessly or the system cannot show a chooser. Paths must refer to the Java process's own filesystem; browser security prevents an ordinary web directory upload from revealing a reliable absolute path.
- **Browse reference** / **Reference path** can add up to five reference folders. Reference selection is persisted separately from the active writable project, survives conversation and mode changes, and can be removed with ×. In Agent mode reference folders are exposed through resolver-issued **read-only** resource aliases; this does not turn them into writable workspaces. Local program/shell access is not an OS sandbox: users should enable appropriate permissions for untrusted commands.
- Project and reference folder selection calls the existing project indexing pipeline and also builds/refres​hes the in-memory lexical code-retrieval index. Chat receives query-relevant code snippets from the selected project and reference projects. Agent continues to use its full workspace tools and now also receives selected reference paths as explicit read-only resources. If no project is selected, Agent's pre-existing MCP/document-only mode remains available.
- The selected project is shared across existing/new chats and both modes, as before. Selections are browser-specific; project file indexes live in the pre-existing H2 database, while the fast retrieval index is in process memory and rebuilt on selection or first retrieval after restarting ELIYA. **Rescan** refreshes both primary-project indexes after external changes.
- Built-in secret filenames (`.env`, private keys and keystores) and build/vendor/cache folders are excluded from the new lexical code index. Retrieved snippets get basic key/token/password/Bearer redaction. Existing project-index redaction remains in place.

## Using it

1. Start ELIYA on your computer with Java 17; open its local application in a browser.
2. Select **Browse project** and choose your source code folder. Leave the picker open until you have selected a directory and the UI displays the indexed-file count. If the native picker is unavailable, use **Enter path** with a local absolute directory path.
3. Optionally add one or more **Browse reference** paths. A chip under the buttons lists each read-only reference. Ask Chat about code, architecture or tests, or switch to Agent and ask for analysis or permitted changes. No need to paste the project path again.
4. Press **Rescan** for source changes performed outside ELIYA's agent or after selecting different branches. For images and documents requiring visual interpretation, use the separate **Analyse Workspace** workflow with a configured vision model.

## Boundaries

- Local project DB indexing currently caps at 3,000 text files / 30 million extracted text characters. The separate lexical retrieval index defaults to 16,000 supported code/config/text files (50,000 scanned files, maximum directory depth 12 and 192 KB per source file); Java system properties can tune the lexical limits. A repository can be larger than either index. Retrieval sends only a bounded selection of relevant evidence to the model; it cannot guarantee answers to every question about unseen files. Agent's live read/search tools can inspect files outside the bounded preloaded Chat context.
- References are read-only through ELIYA's managed resource tools; unrestricted external shell/scripts are **not** fully sandboxed. Use OS permissions and the existing deletion/command approvals where applicable.
- Swing desktop picker requires a graphical desktop session and local ELIYA backend. Remote/headless deployments must use **Enter path** with a path that exists on the backend machine.

## Validation performed here

- `node --check src/main/resources/static/app.js` — passed.
- `node --test src/test/js/*.js` — passed (shared folder project/reference flows plus existing deletion-approval UI).
- Java 17 **isolated** source compilation passed for `WorkspaceRetrievalIndexService`, `PromptResourceResolver`, `LocalFolderPickerController` and `ChatRequest` with narrowly scoped framework stubs. Isolated execution validated retrieval, refreshed indexing, hidden-secret exclusion and read-only Agent resource routing.
- Full Maven/Spring Boot compile and Java unit suite were **not run**: Maven is not preinstalled in this sandbox and `./mvnw` could not resolve `repo.maven.apache.org` to install Maven. **No runnable JAR is claimed or included.** On a machine with Maven/dependency access, run `./mvnw -Pfull-tests clean verify`; the executable JAR is generated at `target/eliya.jar` if all checks pass.
