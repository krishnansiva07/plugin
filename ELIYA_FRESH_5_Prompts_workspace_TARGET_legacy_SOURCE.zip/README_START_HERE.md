# START HERE — Eliya Selenium → Playwright/Cucumber Migration

## The ONLY two project roles

| Eliya path or alias | Role | Contains | Write behavior |
|---|---|---|---|
| `workspace` | **TARGET** | TypeScript + Playwright + Cucumber.js automation | Write framework, migration code, docs, tests and reports here |
| `legacy` | **SOURCE reference** | Existing Java + Selenium + TestNG + Cucumber + Maven automation | Read source. Optionally write only `AGENTS.md` and `SKILLS.md` in task 02 **if reference is explicitly writable**. Never modify Java source/tests. |

**You must select the Java Selenium project as the Eliya reference with alias exactly `legacy`; select your target folder as the primary Eliya workspace (`workspace`).** Do not create the target inside the reference. Do not add an MCP dependency.

## Execute in order, one task at a time

1. `01_BUILD_PLAYWRIGHT_TYPESCRIPT_CUCUMBER_IN_WORKSPACE.md` — build a real runnable Cucumber.js + TypeScript + Playwright target directly in `workspace`. No source business-feature migration.
2. `02_ANALYZE_LEGACY_SELENIUM_CUCUMBER_SOURCE.md` — analyze the Java source, document `AGENTS.md`/`SKILLS.md` and capture the scenario inventory.
3. `03_DOCUMENT_TARGET_WORKSPACE_FRAMEWORK.md` — document `workspace` architecture, skills, agent rules and actual capabilities.
4. `04_DEFINE_MIGRATION_STRATEGY_AND_COVERAGE_BASELINE.md` — create `MIGRATION.md`, module plan, dependency map and scenario-level baseline.
5. `05_MIGRATE_SINGLE_LEGACY_MODULE_INTO_WORKSPACE.md` — replace `<EXACT_LEGACY_MODULE_NAME_OR_FEATURE_PATH>` with a real name/path, execute the migration of **one module**, and reuse this prompt separately for each later module.

## Mandatory conditions
- Cucumber.js is the target BDD runner; TypeScript step definitions and Playwright automation.
- Only an **already installed** Chrome or Edge. Do not download browser binaries or use Playwright-managed Chromium.
- Source business coverage, Scenario Outline example rows, assertions, test-data and integrations must be accounted for; incomplete coverage is a blocker, not success.
- Preserve unrelated code and stop at each prompt's completion report. Do not let Eliya automatically continue to another stage.

If `legacy` is not writable, task 02 will put source agent/skill documents in `workspace/docs/legacy` rather than modifying reference permissions. Other tasks never need write access to `legacy`.
