# ELIYA EXECUTE — Migrate ONE Java Selenium Cucumber feature/module from `legacy` into `workspace`

## Required selection — replace before executing
`MODULE_OR_FEATURE_PATH = <EXACT_LEGACY_MODULE_NAME_OR_FEATURE_PATH>`

## Exact project mapping
- **SOURCE = `legacy`**: reference containing the existing Java + Selenium + TestNG + Cucumber + Maven implementation. Read-only for migration; do not modify it.
- **TARGET = `workspace`**: primary writable **TypeScript + Playwright + Cucumber.js** framework. All migrated code, feature files, test data adapters, reports and progress trackers must live here.
- Migrate the **selected module only**. Do not invent the module selection if the placeholder is still present. Do not invoke MCP tools unless explicitly requested.

## Goal
Reproduce the selected Selenium module's observable business behavior and coverage using **Cucumber Gherkin + TypeScript step definitions + Playwright** in the target framework, reusing shared target infrastructure.

## Phase 1 — Precisely scope the source module
1. Resolve and display both workspace paths, selection and matching `.feature` files in `legacy`. If selection matches multiple unrelated modules, list ambiguity and stop without modifying code.
2. Count **every** selected Feature/Background/Scenario/Scenario Outline/Examples row, tag, step and major assertion. Trace each scenario to Java glue, page objects, locators, helper methods, wait behavior, hooks, datasets, Excel/CSV/JSON files, API/database clients, auth/setup/cleanup and environment prerequisites. Record indirect utility dependencies too.
3. Produce or update `workspace/migration/modules/<MODULE_SLUG>/source-analysis.md` with a concrete source-to-target trace and missing/unresolved dependencies. Do not change `legacy` Java or Selenium files.

## Phase 2 — Inspect the target and map dependencies
4. Read the actual `workspace` framework and its `AGENTS.md`, `SKILLS.md`, `MIGRATION.md` when available. Confirm Cucumber runner, support loading, hooks/World, Playwright browser factory, config, POM, data/API helpers and test reporting.
5. For each source dependency choose **REUSE / EXTEND / CREATE / NOT_REQUIRED**, giving the reason and concrete target location. Reuse first; do not duplicate the browser lifecycle, hooks, page classes, utils or environment handling.
6. Write `workspace/migration/modules/<MODULE_SLUG>/coverage-map.csv` with `source_id`, source path/line, scenario/row, steps/assertions, target feature/scenario/steps, test-data mapping, status and verification evidence. Initialize unknown items as `BLOCKED`/`PENDING`, not `PASSED`.

## Phase 3 — Implement only selected behavior in `workspace`
7. Create or adapt target `.feature` files preserving Gherkin semantics, scenarios, Scenario Outlines, example data, Background, tags, Data Tables, Doc Strings and expected positive/negative cases. Minor wording improvements are acceptable only if behavior and ID mapping remain explicit.
8. Implement typed TypeScript Cucumber steps using Playwright-native `Locator`, auto-waiting, assertions and accessible selectors. Add/reuse POMs, Custom World data, hooks, auth setup, API requests, data readers and DB integrations only when needed. Preserve source behavior, not Selenium driver syntax.
9. Copy **only necessary permitted non-secret test data** into `workspace`; use adapters/config for secrets, environments, external APIs and databases. Never store credentials in repo and never write migrated code into `legacy`.
10. Keep changes confined to this module and minimal shared target components. Avoid large refactors and changing unrelated Cucumber scenarios.

## Browser and test execution rules
- Only installed stable **Chrome or Edge**. Respect explicit `BROWSER_CHANNEL=chrome|msedge`, otherwise preflight installed Chrome then Edge. Never use Playwright bundled browsers or download/install any browser.
- First run TypeScript typecheck and Cucumber feature/step discovery; report undefined/ambiguous steps rather than skipping.
- Run only the selected module/scenarios using a scoped feature path or tag expression; do not execute the entire legacy or target suites. Record exact command, selected browser and scenario counts.
- Make at most **one focused fix-and-rerun** for a migration-related failure. If app, credentials, browser, network or test data prevent execution, report `BLOCKED` with error evidence; do not fabricate passes or run indefinitely.
- Capture screenshots/report artifacts for failures when available. Verify contexts/pages close; avoid cross-scenario shared mutable state.

## Acceptance and stop conditions
- Reconcile source vs target at **scenario AND Scenario Outline example-row** granularity. Every source validation must have a mapped target assertion or a justified documented exception.
- Identify exactly which migrated scenarios passed, failed, were skipped, or could not execute; include evidence paths and anything not migrated.
- Update `workspace/migration/migration-status.csv` if present, and write `workspace/migration/modules/<MODULE_SLUG>/completion-report.md` with:
  - source files/scenarios/outline rows analysed;
  - target feature/steps/pages/utilities changed;
  - REUSE / EXTEND / CREATE / NOT_REQUIRED decisions;
  - data/API/DB/auth handling;
  - test commands, browser, results and artifact paths;
  - mapping coverage percentage with numerator/denominator, unmapped IDs and blockers;
  - exact readiness: `COMPLETE`, `PARTIAL`, or `BLOCKED` based on evidence.
- Verify modified files exist and are nonempty. **Stop immediately after this one module report. Do not migrate another module.**
