# ELIYA EXECUTE — Document the Java Selenium + Cucumber source in reference `legacy`

## Exact project mapping
- **SOURCE = `legacy`**, the reference containing the existing Java + Selenium + TestNG + Cucumber + Maven automation framework.
- **TARGET = `workspace`**, the primary writable Playwright + TypeScript + Cucumber project and the location for migration evidence.
- This task documents source behavior only. Do not migrate scenarios or modify any Java source files. Do not invoke MCP tools unless explicitly requested.

## Mission
Produce a **repository-specific, complete source inventory** that future migration work can trust. Identify the actual code and files; do not invent architecture or copy generic documentation.

## Scan the real source efficiently
1. Resolve and state the absolute paths of `legacy` and `workspace`. Confirm `legacy` is the Selenium source; if not, fail with an explicit path/alias error.
2. Enumerate all feature files and locate `pom.xml`, Cucumber runners and TestNG XML, step definitions, Page Objects, base classes, hooks, Selenium driver factories, config and environment files, locators and waits, assertions, shared utilities, data providers, Excel/CSV/JSON resources, API/REST clients, database queries, authentication/setup flows, reporting, retries, screenshots, tagging, CI scripts and test execution instructions.
3. For every feature/scenario, record a stable ID formed from the **relative feature path + scenario name/line**, tags, Scenario Outline example rows, step definitions used, page objects/utilities, test data and environment prerequisites. Record **unresolved** mappings rather than guessing.
4. Trace dependency chains for representative complex flows; avoid reading all files repeatedly. Include cross-feature shared steps, hooks and thread-safety state. Distinguish concrete findings from unknowns.
5. Enumerate all `.feature` files even if the project is large. If tracing cannot finish in one run, provide the exact coverage completed, unprocessed paths and blockers; never label incomplete inventory as complete.

## Create documentation
When `legacy` reference is **explicitly writable**, create/update only documentation in its root:
- `legacy/AGENTS.md` — rules for an agent inspecting the Selenium source; protect business behavior and forbid unrelated Java modifications.
- `legacy/SKILLS.md` — actual Java/Selenium/Cucumber/TestNG/Maven structure, commands, coding/testing/data-handling knowledge.

Do not overwrite existing source documentation without merging relevant content or making a safe backup. **If `legacy` is read-only or write access is denied**, DO NOT change permissions automatically or attempt write bypasses; put both documents in `workspace/docs/legacy/AGENTS.md` and `workspace/docs/legacy/SKILLS.md`, and clearly record their effective location.

Always produce in `workspace`:
- `migration/legacy-source-inventory.md`: full capability and architectural inventory with referenced paths;
- `migration/legacy-scenarios.csv`: one row per Gherkin scenario / Scenario Outline example row, with `source_feature`, `line`, `scenario`, `example_row`, `tags`, `steps_mapped`, `test_data`, `prerequisites`, `notes` (use empty or UNRESOLVED for unknown fields);
- `migration/legacy-dependencies.md`: source-wide shared dependencies, runner/hook behavior, external integrations, known risks and gaps.

## Evidence and exit gate
- Confirm number of features, scenarios, outlines, example rows and mapped/unmapped step definitions using actual files; explicitly separate numbers if not determinable.
- Verify all output files exist and are nonempty; validate CSV parses and its row count reconciles with the inventory.
- Do not modify `workspace` automation code or `legacy` production/test code. Do not start migration or repeat scans indefinitely.
- End with a report: paths written, numbers inventoried, docs location, unknowns, and whether source inventory is COMPLETE/PARTIAL/BLOCKED. **Stop.**
