# ELIYA EXECUTE — Document and verify target `workspace` Playwright + Cucumber architecture

## Exact project mapping
- **TARGET = `workspace`**: Eliya's main writable workspace, containing the intended **TypeScript + Playwright + Cucumber.js** framework.
- **SOURCE = `legacy`**: reference with Java Selenium + TestNG + Cucumber; use only to check source compatibility requirements. Never write application code into `legacy`.
- Do not invoke MCP tools unless explicitly requested. This task is target framework documentation and bounded health checking, not business-feature migration.

## Objective
Produce precise agent instructions and implementation skills specific to the **actual framework in `workspace`**. No duplicate frameworks, no new runner, no reinstallation of browsers, and no broad refactoring.

## Work steps
1. Read the actual `workspace/package.json`, lockfile, `tsconfig.json`, `cucumber.js`, Gherkin feature, steps, support code, hooks, Custom World, browser factory, page objects, config, data/API utilities, and reporting. Identify existing entry points and capabilities **from source**, not assumptions.
2. Validate that `@cucumber/cucumber` is the scenario runner and that Playwright operates the **already-installed Chrome or Edge**. Check that support-code import configuration finds every step/hook under expected directories and that step patterns do not collide.
3. Inspect `legacy` read-only to compare important integration requirements: Selenium page model, hooks, scenario tags/outline structure, test-data types, API/database integrations, environment switching, authentication, reporting and CI behavior. Distinguish implemented target capabilities from future migration requirements.
4. Write/update in the root of `workspace`:
   - `AGENTS.md`: concrete rules for an Eliya AI agent editing this target repository; source reference boundaries; reusing code; Cucumber feature/step design; scenario isolation; browser restrictions; verification and stop criteria.
   - `SKILLS.md`: TypeScript/Cucumber.js/Playwright patterns, CLI commands, browser configuration, page objects, Custom World/hooks, Gherkin outline/data tables, test data, API helpers, assertions, errors, screenshots/reporting/debugging and CI guidance.
   - `docs/TARGET_ARCHITECTURE.md`: actual directory tree, execution sequence, browser lifecycle, configuration precedence and shared dependency boundaries.
   - `docs/TARGET_CAPABILITY_MATRIX.md`: a factual table of capabilities `IMPLEMENTED / PARTIAL / MISSING / NOT VERIFIED`, with file evidence and migration relevance.
5. Preserve any existing documentation and incorporate useful content; do not replace working files with generic templates.

## Verification
- Check `package.json` scripts and run a **single** bounded `typecheck` plus the local offline Cucumber smoke scenario if dependencies are available and the installed Chrome/Edge can be launched.
- If compilation/smoke cannot run (missing packages, browser, proxy, credentials), mark them **NOT VERIFIED**, record exact errors, and do not attempt downloads or endless repairs.
- If a tiny **critical** framework defect blocks document truthfulness, make the smallest safe edit and test once; otherwise only change documentation.
- Never execute `playwright install` or any browser installer. Do not launch business suites or begin migration.

## Completion contract
Report exact documentation files and targeted verification results, plus framework readiness for feature-by-feature Cucumber migration. Stop after documentation and one validation pass.
