# ELIYA EXECUTE — Create Selenium-to-Playwright Cucumber migration contract in `workspace`

## Exact project mapping
- **SOURCE = `legacy`**: Java + Selenium + TestNG + Cucumber + Maven framework (reference).
- **TARGET = `workspace`**: TypeScript + Playwright + Cucumber.js framework (primary writable workspace).
- All migration strategy, coverage and tracking documents belong in **`workspace`**. Treat `legacy` automation implementation as read-only; no code changes there. Do not invoke MCP tools unless explicitly requested.

## Objective
Create a permanent, evidence-based **module-by-module migration plan**. This is a planning and tracking task, not permission to migrate tests. The target architecture is Cucumber.js with TypeScript step definitions and Playwright browser automation—not a standalone Playwright Test `.spec.ts` conversion.

## Required source and target analysis
1. Read source evidence from `legacy` and any available source inventories/docs, including `.feature` files, glue, hooks, test data, business assertions, Java services and dependencies. Reconcile generated inventory entries against actual files; never blindly trust old metadata.
2. Read target `workspace` implementation and its configuration, Custom World, hooks, page objects, data/API abstractions and browser factory.
3. Establish the standard dependency trace for every business feature:
   **Feature/Scenario/Example row → steps → Page Objects/locators → validations → hooks → test data → authentication/prerequisites → API/DB/external systems → environment/config → reporting/retry.**
4. Define `REUSE`, `EXTEND`, `CREATE`, or `NOT_REQUIRED` decisions for each target dependency. Preserve business behavior and meaningful assertions exactly; do not translate Java syntax mechanically.
5. Specify scenario mapping rules: source feature/scenario and outline rows to target feature/scenario/rows; source step to TypeScript step; exact tags, Background, Data Tables, Doc Strings, negative flows, conditional validations, retry implications and test-data variants.
6. Identify migration priorities and module boundaries from source structure; do not assume an ordering without evidence. Document blockers (credentials, data, API/DB access, feature flags, browser policy).

## Deliverables in `workspace`
- `MIGRATION.md`: permanent instructions, boundaries, policies, execution workflow, prerequisites, module selection, acceptance checks, rollback/defect handling and explicit STOP after each module.
- `migration/coverage-baseline.csv`: **all identified source scenarios** including outline example rows with stable source IDs, source file/line, tags, business checks and status `NOT_STARTED`; mark inaccessible source entries `UNVERIFIED` instead of inventing them.
- `migration/dependency-map.md`: framework shared dependencies and guidance to reuse/extend/create/not-required.
- `migration/module-plan.md`: list of concrete source modules/features, complexity, dependencies and proposed batch order.
- `migration/migration-status.csv`: schema for tracking each module, scenario ID, target feature/step location, verification status, blockers and proof of test execution; initialize without fabricated completions.

## Contract for every future module migration
- Touch only source data **for reading**; create/modify target automation files **only under `workspace`**.
- Preserve Gherkin coverage: all relevant scenarios, example rows, steps, assertions, expected errors, tags and data variants must map explicitly. `SKIPPED` / `BLOCKED` must be visible, never silently dropped.
- Reuse shared target components before adding new ones. No duplicate hooks/browser factories/page objects; maintain per-scenario isolation for Cucumber parallel support.
- Use only locally installed Chrome (`chrome`) or Edge (`msedge`) via Playwright; never install/download browsers or fall back to bundled Chromium.
- Validate typecheck, Cucumber discovery, targeted scenario execution and scenario-level coverage evidence, but do not claim live application validation if credentials/environment are unavailable.
- Stop after the selected module, do not automatically start another.

## Completion gate
Verify deliverables exist, count all source features/scenarios/example rows in the coverage baseline, reconcile with the source inventory, and list any unresolved IDs. Provide a compact readiness report. **Do not implement or run a business feature migration during this task. Stop.**
