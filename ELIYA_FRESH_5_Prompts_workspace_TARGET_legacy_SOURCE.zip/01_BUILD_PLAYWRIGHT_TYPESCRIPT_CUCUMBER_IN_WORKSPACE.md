# ELIYA EXECUTE — Build the Playwright + TypeScript + Cucumber framework in `workspace`

## Exact project mapping (mandatory)
- **TARGET = `workspace`**: Eliya's **primary writable workspace**. Every new Playwright framework file must be created directly in this workspace, NOT under a new nested project and NOT in `legacy`.
- **SOURCE = `legacy`**: Eliya's reference workspace with the working **Java + Selenium + TestNG + Cucumber + Maven** framework. Read this repository to understand its automation needs; do **not** migrate business modules now.
- Do not invoke MCP tools unless explicitly requested. Do not modify or delete source code, test data, or configuration in `legacy`.

## Single bounded task
Build a clean, runnable **Cucumber.js + TypeScript + Playwright** BDD automation framework in `workspace`. Cucumber is the **primary and only required test runner**. Do not build a separate `@playwright/test` test suite or ask for another framework task. If `workspace` contains some incomplete framework files, inspect and complete them *in place* without deleting unrelated user files, duplicating frameworks, or overwriting valid content blindly.

## Step A — Inspect before editing
1. Confirm the resolved absolute paths of `workspace` and reference alias `legacy`; print both, and verify they differ.
2. Quickly inspect `legacy`'s `pom.xml`, `.feature` files, steps, pages, hooks, runners, drivers, configuration, data readers, REST/database helpers, tags and reporting. Record the **actual capabilities** that the new framework must eventually support. Do not migrate any module.
3. Inventory existing files under `workspace`; create a short creation/reuse plan and proceed immediately. Avoid repeated whole-repository scans.

## Step B — Implement the framework directly in `workspace`
Use current, mutually compatible stable npm dependencies, pinned via a generated lockfile, centered on:
- `typescript` with `strict` checking, `@types/node`;
- `@cucumber/cucumber` as BDD runner;
- `playwright-core` as the browser automation library (no browser package installation);
- a single compatible TypeScript runtime approach, preferably Cucumber CommonJS with `tsx/cjs` registered using `requireModule`, or another *documented and verified* Cucumber-compatible loader;
- minimal logging/configuration and assertion dependencies as needed; do not introduce a second test runner.

Create a maintainable project structure, adapted to actual needs:

```text
workspace/
  features/smoke/browser.feature
  src/steps/smoke.steps.ts
  src/support/world.ts
  src/support/hooks.ts
  src/core/browser-factory.ts
  src/config/env.ts
  src/pages/                 # reusable page objects
  src/utils/                 # locator/wait/logging/data helpers as needed
  src/api/                   # shared API clients only where justified
  src/data/                  # data readers / schemas as needed
  cucumber.js               # configured profiles and explicit TS support discovery
  package.json
  package-lock.json
  tsconfig.json
  .env.example
  .gitignore
  README.md
  reports/                   # generated, ignored by git
```

Functional requirements:
1. Cucumber Gherkin: Feature, Background, Given/When/Then, Scenario Outline/Examples, Data Tables, Doc Strings, tags, scoped hooks and scenario isolation.
2. Custom typed Cucumber World exposing per-scenario `BrowserContext`, `Page`, and state. Use a browser instance per worker where sensible; fresh context + page per scenario; always clean up in `After`, close browser in `AfterAll`, and handle failures safely.
3. Reusable POM and clear locator conventions (`getByRole`, `getByTestId`, accessible selectors first), Playwright auto-waiting, native assertions/error handling, configurable timeouts.
4. Typed environment config (base URL, optional credentials via environment variables only), no secrets committed; basic logging and screenshots on failure; Cucumber HTML + JSON reports. Optional traces only if correctly bounded/configured.
5. Scripts for `typecheck`, `test:smoke`, `test:cucumber`, `test:tag`, `test:headed`, plus a browser preflight; include equivalent Windows/macOS/Linux command examples in README. Start with **parallel disabled**; enable configurable Cucumber parallelism with isolated scenarios, not by sharing pages.
6. Add API, database, Excel/CSV/JSON extension points only where justified by findings in `legacy`; do not create fake implementations or install unrelated packages.

## Browser policy — non-negotiable
- Run tests using only **Google Chrome** (`chromium.launch({ channel: 'chrome', ... })`) or **Microsoft Edge** (`channel: 'msedge'`) that are **already installed** on the executing machine.
- Prefer an explicitly configured `BROWSER_CHANNEL=chrome|msedge`. If not specified, test Chrome availability then Edge; fail clearly if neither works. Never fall back to bundled `chromium`, Firefox or WebKit.
- **No browser downloads or installs:** do not run `playwright install`, `npx playwright install`, `npm exec playwright install`, an install script that fetches browsers, or OS browser installers. When npm installation is necessary, ensure `PLAYWRIGHT_SKIP_BROWSER_DOWNLOAD=1` in the child process environment and prefer `playwright-core`. Installing npm libraries is allowed; installing browsers is not.
- Use one preflight launch on the actual machine, and report chosen channel/path when discoverable. If enterprise policies prevent launch, show the exact failure rather than silently changing to a managed browser.
- The smoke scenario must be self-contained/offline, using `page.setContent` with test HTML and a real Playwright click/assertion, not an external public site or a migrated business scenario.

## Step C — Validate exactly once per gate
1. Inspect `package.json` scripts, TypeScript compiler settings, Cucumber support-code loading and Node compatibility.
2. Install npm dependencies **at most once**; if install is blocked by proxy/network/cert issues, stop and report the exact command and error (no installation loops).
3. Run `npm run typecheck` and fix any clear framework defect; rerun at most once after a focused fix.
4. Run Cucumber feature discovery and the single offline browser smoke scenario on installed Chrome or Edge. Rerun at most once after a focused fix. Preserve failure logs and artifacts.
5. Verify Cucumber reports, scenario cleanup, and that no browser was installed/downloaded.

## Completion contract — stop here
Produce `workspace/docs/FRAMEWORK_SETUP_STATUS.md` containing actual files created/modified, npm/Node versions detected, selected browser, exact executed commands/results, what was VERIFIED vs NOT VERIFIED, and blockers. Answer with a concise summary. **Do not migrate business features, modify `legacy`, execute a full suite, or continue working after this report.**
