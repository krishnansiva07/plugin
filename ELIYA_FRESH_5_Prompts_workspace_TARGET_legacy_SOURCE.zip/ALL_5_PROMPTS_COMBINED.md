# Selenium (legacy) → TypeScript Playwright Cucumber (workspace)

# START HERE — Eliya Selenium → Playwright/Cucumber Migration

## The ONLY two project roles

| Eliya path or alias | Role | Contains | Write behavior |
|---|---|---|---|
| `workspace` | **TARGET** | TypeScript + Playwright + Cucumber.js automation | Write framework, migration code, docs, tests and reports here |
| `legacy` | **SOURCE reference** | Existing Java + Selenium + TestNG + Cucumber + Maven automation | Read source. Optionally write only `AGENTS.md` and `SKILLS.md` in task 02 **if reference is explicitly writable**. Never modify Java source/tests. |

**You must select the Java Selenium project as the Eliya reference with alias exactly `legacy`; select your target folder as the primary Eliya workspace (`workspace`).** Do not create the target inside the reference. Do not add an MCP dependency.

## Execute in order, one task at a time

1. `01_BUILD_PLAYWRIGHT_TYPESCRIPT_CUCUMBER_IN_WORKSPACE.md` — build a real runnable Cucumber.js + TypeScript + Playwright target directly in `workspace`. No source business-feature migration.
2. `02_ANALYZE_LEGACY_SELENIUM_CUCUMBER_SOURCE.md` — analyze the Java source, document `AGENTS.md`/`SKILLS.md` and capture the scenario inventory.
3. `03_DOCUMENT_TARGET_WORKSPACE_FRAMEWORK.md` — document `workspace` architecture, skills, agent rules and actual capabilities.
4. `04_DEFINE_MIGRATION_STRATEGY_AND_COVERAGE_BASELINE.md` — create `MIGRATION.md`, module plan, dependency map and scenario-level baseline.
5. `05_MIGRATE_SINGLE_LEGACY_MODULE_INTO_WORKSPACE.md` — replace `<EXACT_LEGACY_MODULE_NAME_OR_FEATURE_PATH>` with a real name/path, execute the migration of **one module**, and reuse this prompt separately for each later module.

## Mandatory conditions
- Cucumber.js is the target BDD runner; TypeScript step definitions and Playwright automation.
- Only an **already installed** Chrome or Edge. Do not download browser binaries or use Playwright-managed Chromium.
- Source business coverage, Scenario Outline example rows, assertions, test-data and integrations must be accounted for; incomplete coverage is a blocker, not success.
- Preserve unrelated code and stop at each prompt's completion report. Do not let Eliya automatically continue to another stage.

If `legacy` is not writable, task 02 will put source agent/skill documents in `workspace/docs/legacy` rather than modifying reference permissions. Other tasks never need write access to `legacy`.


---

# ELIYA EXECUTE — Build the Playwright + TypeScript + Cucumber framework in `workspace`

## Exact project mapping (mandatory)
- **TARGET = `workspace`**: Eliya's **primary writable workspace**. Every new Playwright framework file must be created directly in this workspace, NOT under a new nested project and NOT in `legacy`.
- **SOURCE = `legacy`**: Eliya's reference workspace with the working **Java + Selenium + TestNG + Cucumber + Maven** framework. Read this repository to understand its automation needs; do **not** migrate business modules now.
- Do not invoke MCP tools unless explicitly requested. Do not modify or delete source code, test data, or configuration in `legacy`.

## Single bounded task
Build a clean, runnable **Cucumber.js + TypeScript + Playwright** BDD automation framework in `workspace`. Cucumber is the **primary and only required test runner**. Do not build a separate `@playwright/test` test suite or ask for another framework task. If `workspace` contains some incomplete framework files, inspect and complete them *in place* without deleting unrelated user files, duplicating frameworks, or overwriting valid content blindly.

## Step A — Inspect before editing
1. Confirm the resolved absolute paths of `workspace` and reference alias `legacy`; print both, and verify they differ.
2. Quickly inspect `legacy`'s `pom.xml`, `.feature` files, steps, pages, hooks, runners, drivers, configuration, data readers, REST/database helpers, tags and reporting. Record the **actual capabilities** that the new framework must eventually support. Do not migrate any module.
3. Inventory existing files under `workspace`; create a short creation/reuse plan and proceed immediately. Avoid repeated whole-repository scans.

## Step B — Implement the framework directly in `workspace`
Use current, mutually compatible stable npm dependencies, pinned via a generated lockfile, centered on:
- `typescript` with `strict` checking, `@types/node`;
- `@cucumber/cucumber` as BDD runner;
- `playwright-core` as the browser automation library (no browser package installation);
- a single compatible TypeScript runtime approach, preferably Cucumber CommonJS with `tsx/cjs` registered using `requireModule`, or another *documented and verified* Cucumber-compatible loader;
- minimal logging/configuration and assertion dependencies as needed; do not introduce a second test runner.

Create a maintainable project structure, adapted to actual needs:

```text
workspace/
  features/smoke/browser.feature
  src/steps/smoke.steps.ts
  src/support/world.ts
  src/support/hooks.ts
  src/core/browser-factory.ts
  src/config/env.ts
  src/pages/                 # reusable page objects
  src/utils/                 # locator/wait/logging/data helpers as needed
  src/api/                   # shared API clients only where justified
  src/data/                  # data readers / schemas as needed
  cucumber.js               # configured profiles and explicit TS support discovery
  package.json
  package-lock.json
  tsconfig.json
  .env.example
  .gitignore
  README.md
  reports/                   # generated, ignored by git
```

Functional requirements:
1. Cucumber Gherkin: Feature, Background, Given/When/Then, Scenario Outline/Examples, Data Tables, Doc Strings, tags, scoped hooks and scenario isolation.
2. Custom typed Cucumber World exposing per-scenario `BrowserContext`, `Page`, and state. Use a browser instance per worker where sensible; fresh context + page per scenario; always clean up in `After`, close browser in `AfterAll`, and handle failures safely.
3. Reusable POM and clear locator conventions (`getByRole`, `getByTestId`, accessible selectors first), Playwright auto-waiting, native assertions/error handling, configurable timeouts.
4. Typed environment config (base URL, optional credentials via environment variables only), no secrets committed; basic logging and screenshots on failure; Cucumber HTML + JSON reports. Optional traces only if correctly bounded/configured.
5. Scripts for `typecheck`, `test:smoke`, `test:cucumber`, `test:tag`, `test:headed`, plus a browser preflight; include equivalent Windows/macOS/Linux command examples in README. Start with **parallel disabled**; enable configurable Cucumber parallelism with isolated scenarios, not by sharing pages.
6. Add API, database, Excel/CSV/JSON extension points only where justified by findings in `legacy`; do not create fake implementations or install unrelated packages.

## Browser policy — non-negotiable
- Run tests using only **Google Chrome** (`chromium.launch({ channel: 'chrome', ... })`) or **Microsoft Edge** (`channel: 'msedge'`) that are **already installed** on the executing machine.
- Prefer an explicitly configured `BROWSER_CHANNEL=chrome|msedge`. If not specified, test Chrome availability then Edge; fail clearly if neither works. Never fall back to bundled `chromium`, Firefox or WebKit.
- **No browser downloads or installs:** do not run `playwright install`, `npx playwright install`, `npm exec playwright install`, an install script that fetches browsers, or OS browser installers. When npm installation is necessary, ensure `PLAYWRIGHT_SKIP_BROWSER_DOWNLOAD=1` in the child process environment and prefer `playwright-core`. Installing npm libraries is allowed; installing browsers is not.
- Use one preflight launch on the actual machine, and report chosen channel/path when discoverable. If enterprise policies prevent launch, show the exact failure rather than silently changing to a managed browser.
- The smoke scenario must be self-contained/offline, using `page.setContent` with test HTML and a real Playwright click/assertion, not an external public site or a migrated business scenario.

## Step C — Validate exactly once per gate
1. Inspect `package.json` scripts, TypeScript compiler settings, Cucumber support-code loading and Node compatibility.
2. Install npm dependencies **at most once**; if install is blocked by proxy/network/cert issues, stop and report the exact command and error (no installation loops).
3. Run `npm run typecheck` and fix any clear framework defect; rerun at most once after a focused fix.
4. Run Cucumber feature discovery and the single offline browser smoke scenario on installed Chrome or Edge. Rerun at most once after a focused fix. Preserve failure logs and artifacts.
5. Verify Cucumber reports, scenario cleanup, and that no browser was installed/downloaded.

## Completion contract — stop here
Produce `workspace/docs/FRAMEWORK_SETUP_STATUS.md` containing actual files created/modified, npm/Node versions detected, selected browser, exact executed commands/results, what was VERIFIED vs NOT VERIFIED, and blockers. Answer with a concise summary. **Do not migrate business features, modify `legacy`, execute a full suite, or continue working after this report.**

---

# ELIYA EXECUTE — Document the Java Selenium + Cucumber source in reference `legacy`

## Exact project mapping
- **SOURCE = `legacy`**, the reference containing the existing Java + Selenium + TestNG + Cucumber + Maven automation framework.
- **TARGET = `workspace`**, the primary writable Playwright + TypeScript + Cucumber project and the location for migration evidence.
- This task documents source behavior only. Do not migrate scenarios or modify any Java source files. Do not invoke MCP tools unless explicitly requested.

## Mission
Produce a **repository-specific, complete source inventory** that future migration work can trust. Identify the actual code and files; do not invent architecture or copy generic documentation.

## Scan the real source efficiently
1. Resolve and state the absolute paths of `legacy` and `workspace`. Confirm `legacy` is the Selenium source; if not, fail with an explicit path/alias error.
2. Enumerate all feature files and locate `pom.xml`, Cucumber runners and TestNG XML, step definitions, Page Objects, base classes, hooks, Selenium driver factories, config and environment files, locators and waits, assertions, shared utilities, data providers, Excel/CSV/JSON resources, API/REST clients, database queries, authentication/setup flows, reporting, retries, screenshots, tagging, CI scripts and test execution instructions.
3. For every feature/scenario, record a stable ID formed from the **relative feature path + scenario name/line**, tags, Scenario Outline example rows, step definitions used, page objects/utilities, test data and environment prerequisites. Record **unresolved** mappings rather than guessing.
4. Trace dependency chains for representative complex flows; avoid reading all files repeatedly. Include cross-feature shared steps, hooks and thread-safety state. Distinguish concrete findings from unknowns.
5. Enumerate all `.feature` files even if the project is large. If tracing cannot finish in one run, provide the exact coverage completed, unprocessed paths and blockers; never label incomplete inventory as complete.

## Create documentation
When `legacy` reference is **explicitly writable**, create/update only documentation in its root:
- `legacy/AGENTS.md` — rules for an agent inspecting the Selenium source; protect business behavior and forbid unrelated Java modifications.
- `legacy/SKILLS.md` — actual Java/Selenium/Cucumber/TestNG/Maven structure, commands, coding/testing/data-handling knowledge.

Do not overwrite existing source documentation without merging relevant content or making a safe backup. **If `legacy` is read-only or write access is denied**, DO NOT change permissions automatically or attempt write bypasses; put both documents in `workspace/docs/legacy/AGENTS.md` and `workspace/docs/legacy/SKILLS.md`, and clearly record their effective location.

Always produce in `workspace`:
- `migration/legacy-source-inventory.md`: full capability and architectural inventory with referenced paths;
- `migration/legacy-scenarios.csv`: one row per Gherkin scenario / Scenario Outline example row, with `source_feature`, `line`, `scenario`, `example_row`, `tags`, `steps_mapped`, `test_data`, `prerequisites`, `notes` (use empty or UNRESOLVED for unknown fields);
- `migration/legacy-dependencies.md`: source-wide shared dependencies, runner/hook behavior, external integrations, known risks and gaps.

## Evidence and exit gate
- Confirm number of features, scenarios, outlines, example rows and mapped/unmapped step definitions using actual files; explicitly separate numbers if not determinable.
- Verify all output files exist and are nonempty; validate CSV parses and its row count reconciles with the inventory.
- Do not modify `workspace` automation code or `legacy` production/test code. Do not start migration or repeat scans indefinitely.
- End with a report: paths written, numbers inventoried, docs location, unknowns, and whether source inventory is COMPLETE/PARTIAL/BLOCKED. **Stop.**

---

# ELIYA EXECUTE — Document and verify target `workspace` Playwright + Cucumber architecture

## Exact project mapping
- **TARGET = `workspace`**: Eliya's main writable workspace, containing the intended **TypeScript + Playwright + Cucumber.js** framework.
- **SOURCE = `legacy`**: reference with Java Selenium + TestNG + Cucumber; use only to check source compatibility requirements. Never write application code into `legacy`.
- Do not invoke MCP tools unless explicitly requested. This task is target framework documentation and bounded health checking, not business-feature migration.

## Objective
Produce precise agent instructions and implementation skills specific to the **actual framework in `workspace`**. No duplicate frameworks, no new runner, no reinstallation of browsers, and no broad refactoring.

## Work steps
1. Read the actual `workspace/package.json`, lockfile, `tsconfig.json`, `cucumber.js`, Gherkin feature, steps, support code, hooks, Custom World, browser factory, page objects, config, data/API utilities, and reporting. Identify existing entry points and capabilities **from source**, not assumptions.
2. Validate that `@cucumber/cucumber` is the scenario runner and that Playwright operates the **already-installed Chrome or Edge**. Check that support-code import configuration finds every step/hook under expected directories and that step patterns do not collide.
3. Inspect `legacy` read-only to compare important integration requirements: Selenium page model, hooks, scenario tags/outline structure, test-data types, API/database integrations, environment switching, authentication, reporting and CI behavior. Distinguish implemented target capabilities from future migration requirements.
4. Write/update in the root of `workspace`:
   - `AGENTS.md`: concrete rules for an Eliya AI agent editing this target repository; source reference boundaries; reusing code; Cucumber feature/step design; scenario isolation; browser restrictions; verification and stop criteria.
   - `SKILLS.md`: TypeScript/Cucumber.js/Playwright patterns, CLI commands, browser configuration, page objects, Custom World/hooks, Gherkin outline/data tables, test data, API helpers, assertions, errors, screenshots/reporting/debugging and CI guidance.
   - `docs/TARGET_ARCHITECTURE.md`: actual directory tree, execution sequence, browser lifecycle, configuration precedence and shared dependency boundaries.
   - `docs/TARGET_CAPABILITY_MATRIX.md`: a factual table of capabilities `IMPLEMENTED / PARTIAL / MISSING / NOT VERIFIED`, with file evidence and migration relevance.
5. Preserve any existing documentation and incorporate useful content; do not replace working files with generic templates.

## Verification
- Check `package.json` scripts and run a **single** bounded `typecheck` plus the local offline Cucumber smoke scenario if dependencies are available and the installed Chrome/Edge can be launched.
- If compilation/smoke cannot run (missing packages, browser, proxy, credentials), mark them **NOT VERIFIED**, record exact errors, and do not attempt downloads or endless repairs.
- If a tiny **critical** framework defect blocks document truthfulness, make the smallest safe edit and test once; otherwise only change documentation.
- Never execute `playwright install` or any browser installer. Do not launch business suites or begin migration.

## Completion contract
Report exact documentation files and targeted verification results, plus framework readiness for feature-by-feature Cucumber migration. Stop after documentation and one validation pass.

---

# ELIYA EXECUTE — Create Selenium-to-Playwright Cucumber migration contract in `workspace`

## Exact project mapping
- **SOURCE = `legacy`**: Java + Selenium + TestNG + Cucumber + Maven framework (reference).
- **TARGET = `workspace`**: TypeScript + Playwright + Cucumber.js framework (primary writable workspace).
- All migration strategy, coverage and tracking documents belong in **`workspace`**. Treat `legacy` automation implementation as read-only; no code changes there. Do not invoke MCP tools unless explicitly requested.

## Objective
Create a permanent, evidence-based **module-by-module migration plan**. This is a planning and tracking task, not permission to migrate tests. The target architecture is Cucumber.js with TypeScript step definitions and Playwright browser automation—not a standalone Playwright Test `.spec.ts` conversion.

## Required source and target analysis
1. Read source evidence from `legacy` and any available source inventories/docs, including `.feature` files, glue, hooks, test data, business assertions, Java services and dependencies. Reconcile generated inventory entries against actual files; never blindly trust old metadata.
2. Read target `workspace` implementation and its configuration, Custom World, hooks, page objects, data/API abstractions and browser factory.
3. Establish the standard dependency trace for every business feature:
   **Feature/Scenario/Example row → steps → Page Objects/locators → validations → hooks → test data → authentication/prerequisites → API/DB/external systems → environment/config → reporting/retry.**
4. Define `REUSE`, `EXTEND`, `CREATE`, or `NOT_REQUIRED` decisions for each target dependency. Preserve business behavior and meaningful assertions exactly; do not translate Java syntax mechanically.
5. Specify scenario mapping rules: source feature/scenario and outline rows to target feature/scenario/rows; source step to TypeScript step; exact tags, Background, Data Tables, Doc Strings, negative flows, conditional validations, retry implications and test-data variants.
6. Identify migration priorities and module boundaries from source structure; do not assume an ordering without evidence. Document blockers (credentials, data, API/DB access, feature flags, browser policy).

## Deliverables in `workspace`
- `MIGRATION.md`: permanent instructions, boundaries, policies, execution workflow, prerequisites, module selection, acceptance checks, rollback/defect handling and explicit STOP after each module.
- `migration/coverage-baseline.csv`: **all identified source scenarios** including outline example rows with stable source IDs, source file/line, tags, business checks and status `NOT_STARTED`; mark inaccessible source entries `UNVERIFIED` instead of inventing them.
- `migration/dependency-map.md`: framework shared dependencies and guidance to reuse/extend/create/not-required.
- `migration/module-plan.md`: list of concrete source modules/features, complexity, dependencies and proposed batch order.
- `migration/migration-status.csv`: schema for tracking each module, scenario ID, target feature/step location, verification status, blockers and proof of test execution; initialize without fabricated completions.

## Contract for every future module migration
- Touch only source data **for reading**; create/modify target automation files **only under `workspace`**.
- Preserve Gherkin coverage: all relevant scenarios, example rows, steps, assertions, expected errors, tags and data variants must map explicitly. `SKIPPED` / `BLOCKED` must be visible, never silently dropped.
- Reuse shared target components before adding new ones. No duplicate hooks/browser factories/page objects; maintain per-scenario isolation for Cucumber parallel support.
- Use only locally installed Chrome (`chrome`) or Edge (`msedge`) via Playwright; never install/download browsers or fall back to bundled Chromium.
- Validate typecheck, Cucumber discovery, targeted scenario execution and scenario-level coverage evidence, but do not claim live application validation if credentials/environment are unavailable.
- Stop after the selected module, do not automatically start another.

## Completion gate
Verify deliverables exist, count all source features/scenarios/example rows in the coverage baseline, reconcile with the source inventory, and list any unresolved IDs. Provide a compact readiness report. **Do not implement or run a business feature migration during this task. Stop.**

---

# ELIYA EXECUTE — Migrate ONE Java Selenium Cucumber feature/module from `legacy` into `workspace`

## Required selection — replace before executing
`MODULE_OR_FEATURE_PATH = <EXACT_LEGACY_MODULE_NAME_OR_FEATURE_PATH>`

## Exact project mapping
- **SOURCE = `legacy`**: reference containing the existing Java + Selenium + TestNG + Cucumber + Maven implementation. Read-only for migration; do not modify it.
- **TARGET = `workspace`**: primary writable **TypeScript + Playwright + Cucumber.js** framework. All migrated code, feature files, test data adapters, reports and progress trackers must live here.
- Migrate the **selected module only**. Do not invent the module selection if the placeholder is still present. Do not invoke MCP tools unless explicitly requested.

## Goal
Reproduce the selected Selenium module's observable business behavior and coverage using **Cucumber Gherkin + TypeScript step definitions + Playwright** in the target framework, reusing shared target infrastructure.

## Phase 1 — Precisely scope the source module
1. Resolve and display both workspace paths, selection and matching `.feature` files in `legacy`. If selection matches multiple unrelated modules, list ambiguity and stop without modifying code.
2. Count **every** selected Feature/Background/Scenario/Scenario Outline/Examples row, tag, step and major assertion. Trace each scenario to Java glue, page objects, locators, helper methods, wait behavior, hooks, datasets, Excel/CSV/JSON files, API/database clients, auth/setup/cleanup and environment prerequisites. Record indirect utility dependencies too.
3. Produce or update `workspace/migration/modules/<MODULE_SLUG>/source-analysis.md` with a concrete source-to-target trace and missing/unresolved dependencies. Do not change `legacy` Java or Selenium files.

## Phase 2 — Inspect the target and map dependencies
4. Read the actual `workspace` framework and its `AGENTS.md`, `SKILLS.md`, `MIGRATION.md` when available. Confirm Cucumber runner, support loading, hooks/World, Playwright browser factory, config, POM, data/API helpers and test reporting.
5. For each source dependency choose **REUSE / EXTEND / CREATE / NOT_REQUIRED**, giving the reason and concrete target location. Reuse first; do not duplicate the browser lifecycle, hooks, page classes, utils or environment handling.
6. Write `workspace/migration/modules/<MODULE_SLUG>/coverage-map.csv` with `source_id`, source path/line, scenario/row, steps/assertions, target feature/scenario/steps, test-data mapping, status and verification evidence. Initialize unknown items as `BLOCKED`/`PENDING`, not `PASSED`.

## Phase 3 — Implement only selected behavior in `workspace`
7. Create or adapt target `.feature` files preserving Gherkin semantics, scenarios, Scenario Outlines, example data, Background, tags, Data Tables, Doc Strings and expected positive/negative cases. Minor wording improvements are acceptable only if behavior and ID mapping remain explicit.
8. Implement typed TypeScript Cucumber steps using Playwright-native `Locator`, auto-waiting, assertions and accessible selectors. Add/reuse POMs, Custom World data, hooks, auth setup, API requests, data readers and DB integrations only when needed. Preserve source behavior, not Selenium driver syntax.
9. Copy **only necessary permitted non-secret test data** into `workspace`; use adapters/config for secrets, environments, external APIs and databases. Never store credentials in repo and never write migrated code into `legacy`.
10. Keep changes confined to this module and minimal shared target components. Avoid large refactors and changing unrelated Cucumber scenarios.

## Browser and test execution rules
- Only installed stable **Chrome or Edge**. Respect explicit `BROWSER_CHANNEL=chrome|msedge`, otherwise preflight installed Chrome then Edge. Never use Playwright bundled browsers or download/install any browser.
- First run TypeScript typecheck and Cucumber feature/step discovery; report undefined/ambiguous steps rather than skipping.
- Run only the selected module/scenarios using a scoped feature path or tag expression; do not execute the entire legacy or target suites. Record exact command, selected browser and scenario counts.
- Make at most **one focused fix-and-rerun** for a migration-related failure. If app, credentials, browser, network or test data prevent execution, report `BLOCKED` with error evidence; do not fabricate passes or run indefinitely.
- Capture screenshots/report artifacts for failures when available. Verify contexts/pages close; avoid cross-scenario shared mutable state.

## Acceptance and stop conditions
- Reconcile source vs target at **scenario AND Scenario Outline example-row** granularity. Every source validation must have a mapped target assertion or a justified documented exception.
- Identify exactly which migrated scenarios passed, failed, were skipped, or could not execute; include evidence paths and anything not migrated.
- Update `workspace/migration/migration-status.csv` if present, and write `workspace/migration/modules/<MODULE_SLUG>/completion-report.md` with:
  - source files/scenarios/outline rows analysed;
  - target feature/steps/pages/utilities changed;
  - REUSE / EXTEND / CREATE / NOT_REQUIRED decisions;
  - data/API/DB/auth handling;
  - test commands, browser, results and artifact paths;
  - mapping coverage percentage with numerator/denominator, unmapped IDs and blockers;
  - exact readiness: `COMPLETE`, `PARTIAL`, or `BLOCKED` based on evidence.
- Verify modified files exist and are nonempty. **Stop immediately after this one module report. Do not migrate another module.**
