# Startup AI Connection Gate

The application now requires a validated AI connection before the workspace is shown.

## Startup flow

1. Launch the Spring Boot application.
2. The browser shows the AI connection screen first.
3. Enter:
   - Endpoint (OpenAI-compatible base URL or full `/chat/completions` URL)
   - Model
   - API Key
4. Select **Validate & Continue**.
5. The server sends a minimal validation request using exactly those values.
6. Only after validation succeeds are the normalized Endpoint + Model + Key stored in the server-side HTTP session and the workspace displayed.

## Runtime behavior

- Every active editorial/formatting LLM call uses the validated session Endpoint + Model + Key.
- The API key is not returned by `/api/session/status` and is not stored in browser local/session storage or `application.properties`.
- Endpoint/model defaults in `application.properties` are only startup convenience values and can be edited on the connection screen.
- A full URL ending in `/chat/completions` is used as-is. Otherwise the configured `formatflow.llm.chat-path` is appended to the entered base URL.
- Existing auth auto-detection is retained (`Authorization: Bearer`, raw Authorization, `api-key`, `x-api-key`).
- **Change AI Connection** reopens the gate with endpoint/model retained and the key blank.
- **Disconnect** clears the server session and returns to the connection gate.

## Security / isolation

The LLM connection is session-scoped rather than written into singleton configuration at runtime. This prevents one browser user's endpoint/model/key selection from changing another user's active connection.
