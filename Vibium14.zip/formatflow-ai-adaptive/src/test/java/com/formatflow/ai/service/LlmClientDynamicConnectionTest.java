package com.formatflow.ai.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.formatflow.ai.config.LlmProperties;
import com.formatflow.ai.model.SessionModels.LlmConnection;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.http.HttpClient;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.atomic.AtomicReference;

import static org.assertj.core.api.Assertions.assertThat;

class LlmClientDynamicConnectionTest {

    private HttpServer server;

    @AfterEach
    void stopServer() {
        if (server != null) server.stop(0);
    }

    @Test
    void validatesAndUsesUserEnteredEndpointModelAndKey() throws Exception {
        ObjectMapper mapper = new ObjectMapper();
        AtomicReference<JsonNode> requestBody = new AtomicReference<>();
        AtomicReference<String> authHeader = new AtomicReference<>();

        server = HttpServer.create(new InetSocketAddress("127.0.0.1", 0), 0);
        server.createContext("/custom/chat/completions", exchange -> {
            requestBody.set(mapper.readTree(exchange.getRequestBody()));
            authHeader.set(exchange.getRequestHeaders().getFirst("Authorization"));
            respond(exchange, 200, "{\"choices\":[{\"message\":{\"content\":\"OK\"}}]}");
        });
        server.start();

        LlmProperties properties = new LlmProperties();
        properties.setBaseUrl("http://unused.invalid/v1");
        properties.setModel("unused-default-model");
        properties.setChatPath("/chat/completions");
        properties.setAuthHeader("Authorization");
        properties.setAuthPrefix("Bearer ");
        properties.setAuthAutoDetect(false);
        properties.setRequestTimeoutSeconds(5);

        LlmClient client = new LlmClient(HttpClient.newHttpClient(), mapper, properties);
        String endpoint = "http://127.0.0.1:" + server.getAddress().getPort() + "/custom/chat/completions";

        LlmClient.ValidationResult validation = client.validateConnection(
                endpoint,
                "user-selected-model",
                "Bearer secret-key"
        );

        assertThat(validation.valid()).isTrue();
        assertThat(requestBody.get().path("model").asText()).isEqualTo("user-selected-model");
        assertThat(authHeader.get()).isEqualTo("Bearer secret-key");

        LlmConnection normalized = client.normalizedConnection(endpoint, " user-selected-model ", "Bearer secret-key");
        assertThat(normalized.endpoint()).isEqualTo(endpoint);
        assertThat(normalized.model()).isEqualTo("user-selected-model");
        assertThat(normalized.apiKey()).isEqualTo("secret-key");
    }

    @Test
    void rejectsMissingOrNonHttpEndpointBeforeCallingTheService() {
        LlmProperties properties = new LlmProperties();
        properties.setBaseUrl("https://default.example/v1");
        properties.setModel("default-model");
        LlmClient client = new LlmClient(HttpClient.newHttpClient(), new ObjectMapper(), properties);

        assertThat(client.validateConnection("", "model", "key").valid()).isFalse();
        assertThat(client.validateConnection("file:///tmp/model", "model", "key").valid()).isFalse();
        assertThat(client.validateConnection("https://example.test/v1", "", "key").valid()).isFalse();
        assertThat(client.validateConnection("https://example.test/v1", "model", "").valid()).isFalse();
    }

    private static void respond(HttpExchange exchange, int status, String body) throws IOException {
        byte[] bytes = body.getBytes(StandardCharsets.UTF_8);
        exchange.getResponseHeaders().set("Content-Type", "application/json");
        exchange.sendResponseHeaders(status, bytes.length);
        exchange.getResponseBody().write(bytes);
        exchange.close();
    }
}
