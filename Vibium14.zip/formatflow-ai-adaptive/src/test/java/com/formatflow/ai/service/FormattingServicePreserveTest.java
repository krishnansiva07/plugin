package com.formatflow.ai.service;

import com.formatflow.ai.model.FormatModels.*;
import com.formatflow.ai.model.SessionModels.LlmConnection;
import jakarta.servlet.http.HttpSession;
import org.jsoup.Jsoup;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

class FormattingServicePreserveTest {

    @Test
    void editorialModeUsesFreeformModelOutputAndSkipsLegacySemanticPipeline() {
        SessionKeyService keyService = mock(SessionKeyService.class);
        LlmOrchestrator orchestrator = mock(LlmOrchestrator.class);
        AdaptiveSemanticOrchestrator adaptive = mock(AdaptiveSemanticOrchestrator.class);
        ContentParser parser = new ContentParser();
        IconCatalog icons = new IconCatalog();
        DocumentRenderer renderer = new DocumentRenderer(icons);
        ContentDiffService diff = new ContentDiffService();
        FormattingService service = new FormattingService(
                keyService,
                parser,
                orchestrator,
                adaptive,
                new SemanticPresentationPolicy(),
                new DocumentAssemblyService(),
                renderer,
                diff
        );
        HttpSession session = mock(HttpSession.class);

        String source = "About me application lets employees maintain profiles, access appraisal reviews and track training programs.";
        LlmConnection connection = new LlmConnection("https://example.test/v1", "test-model", "session-key");
        when(keyService.requireConnection(session)).thenReturn(connection);
        when(orchestrator.freeform(any(LlmConnection.class), anyString(), anyString(), anyString(), anyString(), anyString(), anyString()))
                .thenReturn(new LlmOrchestrator.FreeformOutcome(
                        "<h2>About me</h2><p>A simple employee self-service application.</p><ul><li>Maintain profiles</li><li>Access appraisal reviews</li><li>Track training programs</li></ul>",
                        1,
                        1
                ));

        FormatRequest request = new FormatRequest(
                source, "Co-worker", "Inform", "CONFLUENCE", "FORMAT", "ENHANCE",
                "Short", "Professional Green", "RICH", "", false, false
        );

        FormatResult result = service.format(request, session);
        assertThat(result.previewHtml()).contains("confluence-preview", "About me", "Maintain profiles");

        // Confluence clipboard HTML is intentionally decorated with inline styles
        // so colours, table borders and typography have a better chance of
        // surviving browser -> Confluence paste. Assert semantic structure rather
        // than brittle exact unstyled markup such as <h2>About me</h2> or <ul>.
        var copied = Jsoup.parseBodyFragment(result.copyHtml());
        assertThat(copied.selectFirst("h2")).isNotNull();
        assertThat(copied.selectFirst("h2").text()).isEqualTo("About me");
        assertThat(copied.selectFirst("h2").attr("style")).contains("color:#006b36");
        assertThat(copied.select("ul > li")).extracting(org.jsoup.nodes.Element::text)
                .containsExactly("Maintain profiles", "Access appraisal reviews", "Track training programs");

        assertThat(result.finalContent()).contains("About me", "• Maintain profiles");
        assertThat(result.processing().activity()).contains("LangGraph Editorial", "Analyze", "Create", "Review");
        verify(adaptive, never()).analyze(anyString(), anyList(), anyString(), anyString(), anyString(), anyString(), anyBoolean());
    }
}
