package com.formatflow.ai.service;

import com.formatflow.ai.model.SessionModels.LlmConnection;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Service;

@Service
public class SessionKeyService {

    private static final String SESSION_CONNECTION = "FORMATFLOW_LLM_CONNECTION";

    public void store(HttpSession session, String endpoint, String model, String apiKey) {
        session.setAttribute(SESSION_CONNECTION, new LlmConnection(endpoint, model, apiKey));
    }

    public LlmConnection requireConnection(HttpSession session) {
        if (session == null) {
            throw new IllegalStateException("LLM session is not connected.");
        }
        Object value = session.getAttribute(SESSION_CONNECTION);
        if (!(value instanceof LlmConnection connection)
                || blank(connection.endpoint())
                || blank(connection.model())
                || blank(connection.apiKey())) {
            throw new IllegalStateException("LLM session is not connected.");
        }
        return connection;
    }

    /**
     * Backward-compatible helper retained for older callers/tests that only need
     * the key. New runtime code should use requireConnection().
     */
    public String require(HttpSession session) {
        return requireConnection(session).apiKey();
    }

    public boolean isConnected(HttpSession session) {
        if (session == null) return false;
        Object value = session.getAttribute(SESSION_CONNECTION);
        return value instanceof LlmConnection connection
                && !blank(connection.endpoint())
                && !blank(connection.model())
                && !blank(connection.apiKey());
    }

    public LlmConnection find(HttpSession session) {
        if (!isConnected(session)) return null;
        return (LlmConnection) session.getAttribute(SESSION_CONNECTION);
    }

    public void clear(HttpSession session) {
        if (session != null) {
            session.removeAttribute(SESSION_CONNECTION);
        }
    }

    private static boolean blank(String value) {
        return value == null || value.isBlank();
    }
}
