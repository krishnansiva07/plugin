package com.formatflow.ai.model;

import jakarta.validation.constraints.NotBlank;

public final class SessionModels {

    private SessionModels() {}

    /**
     * Complete per-browser-session LLM connection. The API key remains server-side
     * in HttpSession and is never returned by the session status API.
     */
    public record LlmConnection(
            String endpoint,
            String model,
            String apiKey
    ) implements java.io.Serializable {}

    public record ValidateConnectionRequest(
            @NotBlank String endpoint,
            @NotBlank String model,
            @NotBlank String apiKey
    ) {}

    public record SessionStatus(
            boolean connected,
            String endpoint,
            String model
    ) {}

    public record ValidateConnectionResponse(
            boolean valid,
            String message,
            SessionStatus session
    ) {}
}
