package com.formatflow.ai.web;

import com.formatflow.ai.config.LlmProperties;
import com.formatflow.ai.model.SessionModels.LlmConnection;
import com.formatflow.ai.model.SessionModels.SessionStatus;
import com.formatflow.ai.model.SessionModels.ValidateConnectionRequest;
import com.formatflow.ai.model.SessionModels.ValidateConnectionResponse;
import com.formatflow.ai.service.LlmClient;
import com.formatflow.ai.service.SessionKeyService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/session")
public class SessionController {

    private final LlmClient llmClient;
    private final SessionKeyService sessionKeyService;
    private final LlmProperties properties;

    public SessionController(LlmClient llmClient,
                             SessionKeyService sessionKeyService,
                             LlmProperties properties) {
        this.llmClient = llmClient;
        this.sessionKeyService = sessionKeyService;
        this.properties = properties;
    }

    @GetMapping("/status")
    public SessionStatus status(HttpServletRequest request) {
        return statusOf(request.getSession(false));
    }

    @PostMapping("/validate")
    public ValidateConnectionResponse validate(@Valid @RequestBody ValidateConnectionRequest request,
                                               HttpServletRequest servletRequest) {
        LlmClient.ValidationResult validation = llmClient.validateConnection(
                request.endpoint(), request.model(), request.apiKey());

        if (!validation.valid()) {
            return new ValidateConnectionResponse(false, validation.message(), statusOf(servletRequest.getSession(false)));
        }

        LlmConnection normalized = llmClient.normalizedConnection(
                request.endpoint(), request.model(), request.apiKey());
        HttpSession session = servletRequest.getSession(true);
        sessionKeyService.store(session, normalized.endpoint(), normalized.model(), normalized.apiKey());
        return new ValidateConnectionResponse(true, validation.message(), statusOf(session));
    }

    @PostMapping("/disconnect")
    public SessionStatus disconnect(HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        if (session != null) {
            sessionKeyService.clear(session);
            session.invalidate();
        }
        return defaultStatus(false);
    }

    private SessionStatus statusOf(HttpSession session) {
        LlmConnection connection = sessionKeyService.find(session);
        if (connection != null) {
            return new SessionStatus(true, connection.endpoint(), connection.model());
        }
        return defaultStatus(false);
    }

    private SessionStatus defaultStatus(boolean connected) {
        return new SessionStatus(
                connected,
                properties.getBaseUrl() == null ? "" : properties.getBaseUrl(),
                properties.getModel() == null ? "" : properties.getModel()
        );
    }
}
