package com.formatflow.ai.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.formatflow.ai.config.LlmProperties;
import com.formatflow.ai.model.SessionModels.LlmConnection;
import org.springframework.stereotype.Service;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

@Service
public class LlmClient {

    private final HttpClient httpClient;
    private final ObjectMapper objectMapper;
    private final LlmProperties properties;

    /**
     * Authentication style is endpoint-specific. Remember the successful header
     * per endpoint, but never retain the API key in this singleton service.
     */
    private final ConcurrentMap<String, AuthSpec> learnedAuthByEndpoint = new ConcurrentHashMap<>();

    public LlmClient(HttpClient httpClient, ObjectMapper objectMapper, LlmProperties properties) {
        this.httpClient = httpClient;
        this.objectMapper = objectMapper;
        this.properties = properties;
    }

    /** Backward-compatible validation against configured defaults. */
    public ValidationResult validateKey(String rawApiKey) {
        return validateConnection(properties.getBaseUrl(), properties.getModel(), rawApiKey);
    }

    /**
     * Validates the exact Endpoint + Model + Key entered on the startup screen.
     * Nothing is persisted here; SessionController stores the normalized values
     * only after this method succeeds.
     */
    public ValidationResult validateConnection(String endpoint, String model, String rawApiKey) {
        final LlmConnection connection;
        try {
            connection = normalizedConnection(endpoint, model, rawApiKey);
        } catch (IllegalArgumentException ex) {
            return new ValidationResult(false, ex.getMessage());
        }

        try {
            String response = chat(connection, "Reply with exactly OK.", 24, 0.0);
            return response == null || response.isBlank()
                    ? new ValidationResult(false, "The AI service connected but returned an empty response.")
                    : new ValidationResult(true, "Endpoint, model and API key validated successfully.");
        } catch (LlmHttpException ex) {
            return new ValidationResult(false, validationMessage(ex));
        } catch (Exception ex) {
            return new ValidationResult(false, "Unable to connect to the LLM service: " + safeMessage(ex));
        }
    }

    public LlmConnection normalizedConnection(String endpoint, String model, String rawApiKey) {
        String normalizedEndpoint = normalizeEndpoint(endpoint);
        String normalizedModel = model == null ? "" : model.trim();
        String normalizedApiKey = normalizeApiKey(rawApiKey);

        if (normalizedModel.isBlank()) {
            throw new IllegalArgumentException("Enter the model name.");
        }
        if (normalizedApiKey.isBlank()) {
            throw new IllegalArgumentException("Enter a valid LLM API key.");
        }
        return new LlmConnection(normalizedEndpoint, normalizedModel, normalizedApiKey);
    }

    public LlmConnection defaultConnection(String rawApiKey) {
        return normalizedConnection(properties.getBaseUrl(), properties.getModel(), rawApiKey);
    }

    /** Backward-compatible runtime call using application.properties defaults. */
    public String chat(String rawApiKey, String prompt, int maxTokens, double temperature) {
        return chat(defaultConnection(rawApiKey), prompt, maxTokens, temperature);
    }

    /**
     * Executes a chat-completions request with bounded retry using the connection
     * that was validated for the current browser session.
     */
    public String chat(LlmConnection rawConnection, String prompt, int maxTokens, double temperature) {
        LlmConnection connection = normalizedConnection(
                rawConnection == null ? null : rawConnection.endpoint(),
                rawConnection == null ? null : rawConnection.model(),
                rawConnection == null ? null : rawConnection.apiKey());

        int attempts = 5;
        int configuredCap = Math.max(256, properties.getMaxCompletionTokens());
        int effectiveMaxTokens = Math.max(24, Math.min(maxTokens, configuredCap));
        RuntimeException last = null;

        for (int attempt = 1; attempt <= attempts; attempt++) {
            try {
                return doChatWithAuthDiscovery(connection, prompt, effectiveMaxTokens, temperature);
            } catch (LlmHttpException ex) {
                last = ex;

                int reduced = reducedTokenBudget(ex, effectiveMaxTokens);
                if (reduced < effectiveMaxTokens && attempt < attempts) {
                    effectiveMaxTokens = reduced;
                    continue;
                }

                if (!retryable(ex.statusCode) || attempt == attempts) throw ex;
                sleep(attempt);
            } catch (IllegalStateException ex) {
                last = ex;
                if (attempt == attempts) throw ex;
                sleep(attempt);
            } catch (RuntimeException ex) {
                last = ex;
                if (attempt == attempts) {
                    throw new IllegalStateException("LLM request failed: " + safeMessage(ex), ex);
                }
                sleep(attempt);
            }
        }
        throw last == null ? new IllegalStateException("LLM request failed.") : last;
    }

    private String doChatWithAuthDiscovery(LlmConnection connection,
                                           String prompt,
                                           int maxTokens,
                                           double temperature) {
        List<AuthSpec> candidates = authCandidates(connection.endpoint());
        LlmHttpException lastAuthFailure = null;

        for (AuthSpec auth : candidates) {
            try {
                String response = doChat(connection, prompt, maxTokens, temperature, auth);
                learnedAuthByEndpoint.put(connection.endpoint(), auth);
                return response;
            } catch (LlmHttpException ex) {
                if ((ex.statusCode == 401 || ex.statusCode == 403) && properties.isAuthAutoDetect()) {
                    lastAuthFailure = ex;
                    continue;
                }
                throw ex;
            }
        }

        if (lastAuthFailure != null) throw lastAuthFailure;
        throw new IllegalStateException("No LLM authentication strategy is configured.");
    }

    private String doChat(LlmConnection connection,
                          String prompt,
                          int maxTokens,
                          double temperature,
                          AuthSpec auth) {
        try {
            String body = objectMapper.writeValueAsString(Map.of(
                    "model", connection.model(),
                    "messages", List.of(Map.of("role", "user", "content", prompt)),
                    "temperature", temperature,
                    "max_tokens", maxTokens
            ));

            HttpRequest request = HttpRequest.newBuilder()
                    .uri(chatUri(connection.endpoint()))
                    .timeout(Duration.ofSeconds(properties.getRequestTimeoutSeconds()))
                    .header("Content-Type", "application/json")
                    .header("Accept", "application/json")
                    .header(auth.header(), auth.prefix() + connection.apiKey())
                    .POST(HttpRequest.BodyPublishers.ofString(body))
                    .build();

            HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
            if (response.statusCode() < 200 || response.statusCode() >= 300) {
                String detail = extractServiceError(response.body());
                throw new LlmHttpException(
                        response.statusCode(),
                        response.body(),
                        runtimeMessage(response.statusCode(), detail)
                );
            }

            JsonNode json = objectMapper.readTree(response.body());
            JsonNode content = json.at("/choices/0/message/content");
            if (content.isMissingNode() || content.isNull()) {
                throw new IllegalStateException("LLM response does not contain choices[0].message.content.");
            }
            if (!content.isValueNode()) {
                throw new IllegalStateException("LLM response content is not a text value. Check OpenAI-compatible response format.");
            }
            return content.asText();
        } catch (LlmHttpException ex) {
            throw ex;
        } catch (IllegalStateException ex) {
            throw ex;
        } catch (Exception ex) {
            throw new IllegalStateException("LLM request failed: " + safeMessage(ex), ex);
        }
    }

    private List<AuthSpec> authCandidates(String endpoint) {
        Set<AuthSpec> ordered = new LinkedHashSet<>();

        AuthSpec learned = learnedAuthByEndpoint.get(endpoint);
        if (learned != null) ordered.add(learned);

        ordered.add(new AuthSpec(nonBlank(properties.getAuthHeader(), "Authorization"),
                properties.getAuthPrefix() == null ? "" : properties.getAuthPrefix()));

        if (properties.isAuthAutoDetect()) {
            ordered.add(new AuthSpec("Authorization", "Bearer "));
            ordered.add(new AuthSpec("Authorization", ""));
            ordered.add(new AuthSpec("api-key", ""));
            ordered.add(new AuthSpec("x-api-key", ""));
        }

        return new ArrayList<>(ordered);
    }

    private URI chatUri(String endpoint) {
        URI base = URI.create(normalizeEndpoint(endpoint));
        String path = base.getPath() == null ? "" : base.getPath().toLowerCase();
        if (path.endsWith("/chat/completions")) {
            return base;
        }
        if (base.getQuery() != null || base.getFragment() != null) {
            throw new IllegalStateException("If the endpoint contains query parameters, enter the full /chat/completions URL.");
        }

        String value = base.toString();
        value = value.endsWith("/") ? value.substring(0, value.length() - 1) : value;
        String chatPath = properties.getChatPath() == null ? "/chat/completions" : properties.getChatPath();
        chatPath = chatPath.startsWith("/") ? chatPath : "/" + chatPath;
        return URI.create(value + chatPath);
    }

    static String normalizeEndpoint(String raw) {
        String endpoint = raw == null ? "" : raw.trim();
        if (endpoint.isBlank()) {
            throw new IllegalArgumentException("Enter the LLM endpoint.");
        }
        final URI uri;
        try {
            uri = URI.create(endpoint);
        } catch (IllegalArgumentException ex) {
            throw new IllegalArgumentException("Enter a valid LLM endpoint URL.");
        }
        String scheme = uri.getScheme();
        if (scheme == null || !(scheme.equalsIgnoreCase("http") || scheme.equalsIgnoreCase("https"))) {
            throw new IllegalArgumentException("LLM endpoint must start with http:// or https://.");
        }
        if (uri.getRawAuthority() == null || uri.getRawAuthority().isBlank()) {
            throw new IllegalArgumentException("LLM endpoint must include a host name.");
        }
        while (endpoint.endsWith("/") && !endpoint.endsWith("://")) {
            endpoint = endpoint.substring(0, endpoint.length() - 1);
        }
        return endpoint;
    }

    private int reducedTokenBudget(LlmHttpException ex, int current) {
        if (ex.statusCode != 400 && ex.statusCode != 422) return current;

        if (looksLikeTokenLimit(ex.responseBody)) {
            if (current > 4096) return 4096;
            if (current > 3072) return 3072;
            if (current > 2048) return 2048;
            if (current > 1024) return 1024;
            return current;
        }

        if (current > 2048) return 2048;
        return current;
    }

    private boolean looksLikeTokenLimit(String body) {
        String text = body == null ? "" : body.toLowerCase();
        return text.contains("max_tokens")
                || text.contains("max tokens")
                || text.contains("maximum tokens")
                || text.contains("context length")
                || text.contains("context_length")
                || text.contains("context window")
                || text.contains("token limit")
                || text.contains("too many tokens")
                || text.contains("max completion")
                || text.contains("completion tokens");
    }

    private boolean retryable(int status) {
        return status == 408 || status == 429 || status == 500 || status == 502 || status == 503 || status == 504;
    }

    private void sleep(int attempt) {
        try {
            Thread.sleep(Math.min(4000L, 500L * (1L << Math.min(attempt - 1, 3))));
        } catch (InterruptedException ex) {
            Thread.currentThread().interrupt();
            throw new IllegalStateException("LLM retry interrupted.", ex);
        }
    }

    /**
     * Accepts either a raw key or a value copied as "Bearer <key>". Quotes
     * accidentally copied from configuration files are also removed.
     */
    static String normalizeApiKey(String raw) {
        if (raw == null) return "";
        String key = raw.trim();
        if ((key.startsWith("\"") && key.endsWith("\"")) ||
                (key.startsWith("'") && key.endsWith("'"))) {
            if (key.length() > 1) key = key.substring(1, key.length() - 1).trim();
        }
        if (key.regionMatches(true, 0, "Bearer ", 0, 7)) {
            key = key.substring(7).trim();
        }
        return key;
    }

    private String validationMessage(LlmHttpException ex) {
        String detail = extractServiceError(ex.responseBody);
        return switch (ex.statusCode) {
            case 400, 422 -> "The LLM endpoint rejected the validation request (HTTP " + ex.statusCode + ")"
                    + suffix(detail) + ". Check the model name and OpenAI-compatible request format.";
            case 401 -> "Authentication failed (HTTP 401). Check the API key. You may paste either the raw key or 'Bearer <key>'."
                    + suffix(detail);
            case 403 -> "The LLM gateway denied access (HTTP 403). Check endpoint, model permission and API key access."
                    + suffix(detail);
            case 404 -> "The LLM chat endpoint was not found (HTTP 404). Check the endpoint URL."
                    + suffix(detail);
            case 429 -> "The LLM service is rate-limiting requests (HTTP 429). Please retry shortly."
                    + suffix(detail);
            default -> "LLM service returned HTTP " + ex.statusCode + suffix(detail) + ".";
        };
    }

    private String runtimeMessage(int status, String detail) {
        return switch (status) {
            case 400, 422 -> "The LLM endpoint rejected the formatting request (HTTP " + status + ")"
                    + suffix(detail) + ". The app will automatically lower max_tokens when the service reports a token/context limit.";
            case 401 -> "LLM authentication failed during formatting (HTTP 401). Reconnect the AI service."
                    + suffix(detail);
            case 403 -> "The LLM gateway denied the formatting request (HTTP 403). Check model/endpoint permission."
                    + suffix(detail);
            case 404 -> "The LLM chat endpoint was not found (HTTP 404). Check the endpoint URL."
                    + suffix(detail);
            case 408 -> "The LLM gateway timed out the request (HTTP 408)." + suffix(detail);
            case 413 -> "The LLM gateway rejected the request as too large (HTTP 413). Reduce the configured chunk size."
                    + suffix(detail);
            case 429 -> "The LLM service is rate-limiting formatting requests (HTTP 429). Retry shortly."
                    + suffix(detail);
            default -> "LLM service returned HTTP " + status + suffix(detail) + ".";
        };
    }

    private String extractServiceError(String body) {
        if (body == null || body.isBlank()) return "";
        try {
            JsonNode root = objectMapper.readTree(body);
            for (String pointer : List.of("/error/message", "/message", "/detail", "/error")) {
                JsonNode node = root.at(pointer);
                if (!node.isMissingNode() && !node.isNull() && node.isValueNode()) {
                    String text = node.asText().trim();
                    if (!text.isBlank()) return truncate(text, 220);
                }
            }
        } catch (Exception ignored) {
            // Fall through to a compact text version.
        }
        return truncate(body.replaceAll("\\s+", " ").trim(), 220);
    }

    private static String suffix(String detail) {
        return detail == null || detail.isBlank() ? "" : " Service message: " + detail;
    }

    private static String nonBlank(String value, String fallback) {
        return value == null || value.isBlank() ? fallback : value;
    }

    private static String truncate(String text, int max) {
        if (text == null) return "";
        return text.length() > max ? text.substring(0, max) : text;
    }

    private static String safeMessage(Exception ex) {
        String msg = ex.getMessage();
        if (msg == null || msg.isBlank()) return ex.getClass().getSimpleName();
        return msg.length() > 220 ? msg.substring(0, 220) : msg;
    }

    public record ValidationResult(boolean valid, String message) {}

    private record AuthSpec(String header, String prefix) {}

    private static final class LlmHttpException extends IllegalStateException {
        private final int statusCode;
        private final String responseBody;

        private LlmHttpException(int statusCode, String responseBody, String message) {
            super(message);
            this.statusCode = statusCode;
            this.responseBody = responseBody;
        }
    }
}
