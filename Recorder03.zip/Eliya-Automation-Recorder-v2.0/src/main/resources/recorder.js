/* Eliya Automation Recorder v2: browser signals -> intentional, replayable test steps.
   DOM evidence is kept separately; it is NOT part of the default export. */
(() => {
  'use strict';
  if (window.__eliyaRecorderInit) return;
  Object.defineProperty(window, '__eliyaRecorderInit', {value:true});
  const opts = Object.assign({captureScroll:false, captureHover:false, deepDom:false, debugMaxNodes:400},
    window.__eliyaRecorderSettings || {});
  const SECRET = /pass(?:word|wd)?|secret|token|auth(?:orization|entication)?|api.?key|session|cookie|bearer|credit.?card|card.?number|cvv|cvc|pin.?code|one.?time.?pass|otp|ssn|private.?key|access.?key|csrf/i;
  const REDACTED = '[REDACTED]';
  const trim = (v,n=220) => String(v ?? '').replace(/\s+/g,' ').trim().slice(0,n);
  const valueText = (v,n=3000) => String(v ?? '').slice(0,n);
  const sensitive = el => {
    if (!(el instanceof Element)) return false;
    if (el.closest('[data-sensitive="true"],[data-private="true"],[data-recorder-redact="true"]')) return true;
    return SECRET.test([el.getAttribute('type'), el.id, el.getAttribute('name'), el.getAttribute('autocomplete'),
      el.getAttribute('aria-label'), el.getAttribute('placeholder')].join(' '));
  };
  const scrub = (name, value, el) => SECRET.test(name) || sensitive(el) ? REDACTED : trim(value,700);
  const safeUrl = v => {
    try {
      const u = new URL(v, document.baseURI);
      if (u.protocol !== 'http:' && u.protocol !== 'https:') return u.protocol + '[OMITTED]';
      u.username = ''; u.password = '';
      for (const key of [...u.searchParams.keys()]) if (SECRET.test(key)) u.searchParams.set(key, REDACTED);
      if (/[#?&](?:access_token|id_token|token|secret|password|code|session|api_key)=/i.test(u.hash))
        u.hash = '#[REDACTED_FRAGMENT]';
      return trim(u.href,2048);
    } catch (_) { return '[INVALID_URL]'; }
  };
  const getEl = ev => ev?.composedPath?.().find(n => n instanceof Element) ||
    (ev?.target instanceof Element ? ev.target : null);
  const actionable = ev => {
    const el = getEl(ev); if (!el) return null;
    const closest = el.closest('button,a,input,textarea,select,option,summary,label,[role],[contenteditable],[onclick]') || el;
    return closest.localName === 'label' && closest.control ? closest.control : closest;
  };
  const cssEscape = s => window.CSS?.escape ? CSS.escape(String(s)) : String(s).replace(/[^\w-]/g, v=>'\\'+v);
  const cssAttr = (k,v) => '[' + k + '="' + String(v).replaceAll('\\','\\\\').replaceAll('"','\\"') + '"]';
  const countCss = (root, css) => {try{return root.querySelectorAll(css).length;}catch(_){return 0;}};
  const stableId = id => !!id && !SECRET.test(id) && !/^[0-9]|\d{5,}|[a-f0-9]{8}-[a-f0-9]{4}|^(:r\d+:|ember\d+|react-select-\d+)/i.test(id);
  const cssPath = el => {
    const parts=[]; let node=el;
    for(let shadow=0;shadow<12;shadow++) {
      const root=node.getRootNode();
      let part='';
      for(const k of ['data-testid','data-qa','data-test','data-cy']) {
        const v=node.getAttribute(k); if(v && !SECRET.test(v) && countCss(root,cssAttr(k,v))===1){part=cssAttr(k,v);break;}
      }
      if(!part && stableId(node.id) && countCss(root,'#'+cssEscape(node.id))===1) part='#'+cssEscape(node.id);
      if(!part) {
        const crumbs=[];let x=node;
        for(let depth=0;x instanceof Element && depth<20;depth++){
          let c=x.localName;
          if(stableId(x.id)){c='#'+cssEscape(x.id);crumbs.unshift(c);break;}
          const p=x.parentElement;
          if(p){const same=[...p.children].filter(y=>y.localName===x.localName);
            if(same.length>1)c+=':nth-of-type('+(same.indexOf(x)+1)+')';}
          crumbs.unshift(c);
          if(countCss(root,crumbs.join(' > '))===1)break;
          x=p;
        }
        part=crumbs.join(' > ');
      }
      parts.unshift(part);
      if(!(root instanceof ShadowRoot))break;
      node=root.host;
    }
    return parts;
  };
  const xpath = el => {
    if(el.getRootNode() instanceof ShadowRoot) return '';
    const path=[];let x=el;
    for(let i=0;x instanceof Element&&i<50;i++){
      if(stableId(x.id) && !x.id.includes('"')){path.unshift('//*[@id="'+x.id+'"]');break;}
      const same=x.parentElement?[...x.parentElement.children].filter(y=>y.localName===x.localName):[];
      path.unshift(x.localName+'['+(Math.max(0,same.indexOf(x))+1)+']');x=x.parentElement;
    }
    return path.join('/').replace(/^\/(?!\/)/,'/');
  };
  const roleOf = el => el.getAttribute('role') || ({BUTTON:'button',A:'link',SELECT:'combobox',
    TEXTAREA:'textbox',OPTION:'option',IMG:'img'}[el.tagName]) || (el.matches('input[type="checkbox"]')?'checkbox':
      el.matches('input[type="radio"]')?'radio':el.matches('input')?'textbox':'');
  const accessibleName = el => {
    if(sensitive(el))return '';
    let label=el.getAttribute('aria-label') || '';
    if(!label){const by=el.getAttribute('aria-labelledby');if(by)label=by.split(/\s+/).map(id=>document.getElementById(id)?.textContent||'').join(' ');}
    if(!label && el.labels?.length)label=[...el.labels].map(x=>x.textContent).join(' ');
    if(!label && el.matches('button,a,[role="button"],[role="link"],option'))label=el.innerText||el.textContent;
    return trim(label || el.getAttribute('title') || el.getAttribute('placeholder'),140);
  };
  const frameOf = () => {
    const path=[];
    try {let w=window;
      while(w!==w.parent && path.length<12){const f=w.frameElement;if(!f)break;
        path.unshift({id:trim(f.id,120),name:trim(f.getAttribute('name'),120),src:safeUrl(f.getAttribute('src')||w.location.href)});
        w=w.parent;
      }
    } catch(_) {}
    return {isIframe:window!==window.top,url:safeUrl(location.href),path};
  };
  const getTarget = el => {
    if(!(el instanceof Element))return null;
    const root=el.getRootNode(), pieces=cssPath(el), css=pieces.join(' >>> ');
    const name=accessibleName(el), role=roleOf(el), candidates=[];
    const add=(strategy,value,score,unique=true,extra={})=>{
      if(!value||SECRET.test(value))return;
      if(candidates.some(x=>x.strategy===strategy&&x.value===value))return;
      candidates.push({strategy,value,unique,score,...extra});
    };
    if(pieces.length>1)add('shadowCss',css,120,true,{segments:pieces});
    for(const k of ['data-testid','data-qa','data-test','data-cy']){
      const v=el.getAttribute(k);
      if(v&&!SECRET.test(v))add('testId',v,100,countCss(root,cssAttr(k,v))===1,{attribute:k});
    }
    if(role&&name)add('role',role+'[name="'+name.replaceAll('"','\\"')+'"]',92,false,{role,name});
    if(el.labels?.length){const label=trim(el.labels[0].textContent,140);
      if(label)add('label',label,90,false);}
    if(stableId(el.id))add('css','#'+cssEscape(el.id),88,countCss(root,'#'+cssEscape(el.id))===1);
    const nameAttr=el.getAttribute('name');
    if(nameAttr&&!SECRET.test(nameAttr))add('css',el.localName+cssAttr('name',nameAttr),80,countCss(root,el.localName+cssAttr('name',nameAttr))===1);
    const place=el.getAttribute('placeholder');
    if(place&&!SECRET.test(place))add('placeholder',trim(place,120),72,false);
    if(pieces.length===1)add('css',css,60,countCss(root,css)===1);
    const xp=xpath(el);if(xp)add('xpath',xp,30,true);
    candidates.sort((a,b)=>(b.unique?15:0)+b.score-((a.unique?15:0)+a.score));
    const best=candidates[0]||{strategy:'css',value:css,unique:false,score:0};
    return {tag:el.localName, name:name||trim(el.id,100)||el.localName,
      inputType:trim(el.getAttribute('type'),30), role, locator:best,
      alternatives:candidates.filter(x=>x!==best).slice(0,4),
      frame:frameOf()};
  };
  const inspection = (el, ev) => {
    if(!(el instanceof Element))return {};
    const attr={};for(const a of el.attributes)attr[a.name]=scrub(a.name,a.value,el);
    const breadcrumbs=[];let p=el;
    while(p instanceof Element&&breadcrumbs.length<15){breadcrumbs.push({tag:p.localName,id:scrub('id',p.id,p),role:trim(p.getAttribute('role'),50)});
      p=p.parentElement || (p.getRootNode() instanceof ShadowRoot ? p.getRootNode().host : null);}
    const limit=opts.deepDom?Math.min(1500,opts.debugMaxNodes||400):40;
    let nodes=0,omitted=0;
    const tree=(node,depth)=>{
      if(nodes>=limit || depth>(opts.deepDom?12:2)){omitted++;return null;}
      nodes++;
      const item={tag:node.localName};
      if(node.id)item.id=scrub('id',node.id,node);
      if(node.hasAttribute('data-testid'))item.testId=scrub('data-testid',node.getAttribute('data-testid'),node);
      if(node.children.length){item.children=[];
        for(const child of node.children){const data=tree(child,depth+1);if(data)item.children.push(data);else break;}}
      if(node.shadowRoot){item.shadowRoot=[];
        for(const child of node.shadowRoot.children){const data=tree(child,depth+1);if(data)item.shadowRoot.push(data);else break;}}
      return item;
    };
    const siblings=[];
    for(const s of [...(el.parentElement?.children||[])].slice(0,12))
      siblings.push({tag:s.localName,id:scrub('id',s.id,s),name:accessibleName(s)});
    return {attributes:attr,ancestors:breadcrumbs,siblings,subtree:tree(el,0),subtreeNodes:nodes,
      subtreeTruncated:omitted>0,fullTreeMode:!!opts.deepDom};
  };
  const send=(type,params={})=>{
    try{if(typeof window.__eliyaRecorderSend==='function')window.__eliyaRecorderSend(JSON.stringify({
      type,pageUrl:safeUrl(location.href),...params}));}catch(_){}
  };
  const emit=(type,el,data={})=>send(type,{target:getTarget(el),inspection:inspection(el),sensitive:sensitive(el),...data});
  const activeInputs=new Map(),lastValues=new WeakMap();
  const inputElement=el=>el instanceof Element &&
    el.matches('input,textarea,select,[contenteditable="true"],[contenteditable=""],[role="textbox"]');
  const saveInput=el=>{
    if(!inputElement(el)||!el.isConnected||el.type==='hidden')return;
    let action='fill',payload={};
    if(el.type==='checkbox'||el.type==='radio'){action='check';payload.checked=!!el.checked;}
    else if(el.localName==='select'){
      action='select';payload.value=sensitive(el)?'${PASSWORD}':valueText(el.value,1500);
      if(el.multiple)payload.values=sensitive(el)?['${PASSWORD}']:[...el.selectedOptions].map(x=>valueText(x.value,300));
    } else if(el.type==='file'){action='fileUpload';payload.files=['${FILE_PATH}'];}
    else payload.value=sensitive(el)?'${PASSWORD}':valueText(el.isContentEditable?el.innerText:el.value,3000);
    const signature=JSON.stringify([action,payload]);if(lastValues.get(el)===signature)return;
    lastValues.set(el,signature);emit(action,el,payload);
  };
  const flushEl=el=>{const timer=activeInputs.get(el);if(timer)clearTimeout(timer);activeInputs.delete(el);saveInput(el);};
  const flush=()=>{for(const el of [...activeInputs.keys()])flushEl(el);
    if(inputElement(document.activeElement))saveInput(document.activeElement);};
  window.__eliyaRecorderFlush=flush;
  window.addEventListener('blur',flush);
  document.addEventListener('input',e=>{
    const el=getEl(e);if(!inputElement(el))return;
    const old=activeInputs.get(el);if(old)clearTimeout(old);
    activeInputs.set(el,setTimeout(()=>flushEl(el),650));
  },true);
  document.addEventListener('change',e=>{const el=getEl(e);if(inputElement(el))flushEl(el);},true);
  document.addEventListener('focusout',e=>{const el=getEl(e);if(inputElement(el))flushEl(el);},true);

  // A single user interaction should not generate pointerdown/mousedown/up/focus/click noise.
  document.addEventListener('click',e=>{
    if(pickMode)return;
    flush();const el=actionable(e);if(!el)return;
    if(el.matches('input[type="checkbox"],input[type="radio"],select'))return;
    emit(e.detail>=2?'doubleClick':'click',el);
  },true);
  document.addEventListener('dblclick',e=>{if(!pickMode){const el=actionable(e);if(el)emit('doubleClick',el);}},true);
  document.addEventListener('contextmenu',e=>{const el=actionable(e);if(el)emit('rightClick',el);},true);
  document.addEventListener('keydown',e=>{
    if(pickMode)return;
    if(e.repeat)return;
    if(!['Enter','Escape','Tab','ArrowDown','ArrowUp','F2','F5'].includes(e.key) &&
      !(e.ctrlKey||e.metaKey||e.altKey))return;
    flush();const el=actionable(e);
    const key=sensitive(el)?'[REDACTED]':trim(e.key,45);
    emit('keyPress',el,{key,modifiers:[e.ctrlKey?'Ctrl':'',e.altKey?'Alt':'',e.shiftKey?'Shift':'',e.metaKey?'Meta':''].filter(Boolean)});
  },true);
  let dragSource=null;
  document.addEventListener('dragstart',e=>{dragSource=getTarget(actionable(e));},true);
  document.addEventListener('drop',e=>{const el=actionable(e);if(el&&dragSource)
    emit('dragDrop',el,{source:dragSource,destination:getTarget(el)});dragSource=null;},true);
  document.addEventListener('dragend',()=>{dragSource=null;},true);

  let hoverTimer=null, hoverTarget=null;
  if(opts.captureHover)document.addEventListener('mouseover',e=>{
    const el=actionable(e);if(el===hoverTarget)return;
    if(hoverTimer)clearTimeout(hoverTimer);
    hoverTarget=el;
    if(el&&el.matches('button,a,[role="menuitem"],[aria-haspopup],nav *,[title]'))
      hoverTimer=setTimeout(()=>{if(hoverTarget===el)emit('hover',el);},900);
  },true);
  if(opts.captureScroll) {
    const scrollTimers=new Map();
    document.addEventListener('scroll',e=>{
      const el=e.target instanceof Element?e.target:document.scrollingElement;
      if(!el)return;
      const key=el===document.scrollingElement?'page':el;
      if(scrollTimers.has(key))clearTimeout(scrollTimers.get(key));
      scrollTimers.set(key,setTimeout(()=>{
        emit('scroll',el,{x:Math.round(el.scrollLeft),y:Math.round(el.scrollTop)});
        scrollTimers.delete(key);
      },600));
    },{capture:true,passive:true});
  }
  const navigate=source=>{if(window===window.top)send('navigate',{url:safeUrl(location.href),navigationSource:source});};
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',()=>navigate('load'),{once:true});
  else navigate('existing');
  window.addEventListener('popstate',()=>navigate('history'));
  window.addEventListener('hashchange',()=>navigate('hash'));
  for(const name of ['pushState','replaceState'])try{
    const old=history[name];history[name]=function(...args){const result=old.apply(this,args);navigate(name);return result;};
  }catch(_){}

  let pickMode=null,outline=null;
  const clearPick=()=>{pickMode=null;if(outline){outline.remove();outline=null;}};
  const pickerMove=e=>{
    if(!pickMode)return;
    const el=actionable(e);if(!el)return;
    const r=el.getBoundingClientRect();
    if(!outline){outline=document.createElement('div');outline.setAttribute('data-eliya-ui-picker','');
      outline.style.cssText='position:fixed;pointer-events:none;z-index:2147483647;border:3px solid #2563eb;background:#2563eb1b;';
      document.documentElement.appendChild(outline);}
    Object.assign(outline.style,{left:r.x+'px',top:r.y+'px',width:r.width+'px',height:r.height+'px'});
  };
  const pickerClick=e=>{
    if(!pickMode)return;
    e.preventDefault();e.stopPropagation();e.stopImmediatePropagation();
    const el=actionable(e);const type=pickMode;clearPick();
    if(!el)return;
    const safe=sensitive(el);
    let expected;
    if(type==='textContains'||type==='textEquals')expected=safe?'${EXPECTED_TEXT}':trim(el.innerText||el.textContent,500);
    else if(type==='valueEquals')expected=safe?'${PASSWORD}':trim(el.value,1200);
    else if(type==='checked')expected=!!el.checked;
    else if(type==='enabled')expected=!el.disabled;
    else expected=true;
    if(type==='waitForVisible'||type==='waitForHidden')
      emit('waitFor',el,{condition:type==='waitForVisible'?'visible':'hidden',timeoutMs:10000});
    else emit('assert',el,{assertion:{type,expected}});
  };
  window.__eliyaRecorderPickAssertion=kind=>{
    if(!['visible','textContains','textEquals','valueEquals','enabled','checked','waitForVisible','waitForHidden'].includes(kind))return false;
    flush();clearPick();pickMode=kind;return true;
  };
  window.addEventListener('pointermove',pickerMove,true);
  window.addEventListener('click',pickerClick,true);
  window.addEventListener('keydown',e=>{if(pickMode&&e.key==='Escape'){clearPick();e.preventDefault();}},true);
})();
