package com.eliya.recorder;

import java.time.Instant;
import java.util.*;

/** Reduces browser signals into editable, framework-independent automation steps. */
final class ActionBook {
    private static final Set<String> ALLOWED = Set.of("navigate", "click", "doubleClick", "rightClick",
        "fill", "check", "select", "fileUpload", "keyPress", "hover", "scroll", "dragDrop", "assert", "waitFor", "handleDialog");
    private static final int MAX_STEPS = 20_000;
    private final List<Map<String, Object>> steps = new ArrayList<>();
    private int next = 1;
    private final Map<String,String> tabNames = new LinkedHashMap<>();

    List<Map<String, Object>> all() { return steps; }
    int size() { return steps.size(); }
    void clear() { steps.clear(); tabNames.clear(); next = 1; }
    Map<String, Object> at(int position) {
        return position > 0 && position <= steps.size() ? steps.get(position - 1) : null;
    }

    boolean accept(String tab, Map<String, Object> raw) {
        String type = Json.str(raw.get("type"));
        if (!ALLOWED.contains(type) || steps.size() >= MAX_STEPS) return false;
        String url = Json.str(raw.get("pageUrl"));
        if (type.equals("navigate") && (url.startsWith("chrome-error:") || url.startsWith("about:"))) return false;
        Map<String, Object> target = Json.object(raw.get("target"));
        if (type.equals("click") && ("checkbox".equals(target.get("inputType")) ||
            "radio".equals(target.get("inputType")) || "select".equals(target.get("tag")))) return false;
        Map<String, Object> step = new LinkedHashMap<>();
        step.put("id", String.format(Locale.ROOT, "S%04d", next++));
        step.put("action", type);
        if (!url.isBlank()) step.put("page", url);
        if (raw.containsKey("target")) step.put("target", target);
        for (String key : List.of("value", "values", "checked", "key", "modifiers", "files",
            "source", "destination", "x", "y", "assertion", "expected", "waitMs", "condition",
            "timeoutMs", "dialogType", "accepted", "message", "promptResponse")) {
            if (raw.containsKey(key)) step.put(key, raw.get(key));
        }
        step.put("description", describe(type, step));
        step.put("tabId", tab);
        step.put("recordedAt", Instant.now().toString());
        if (raw.containsKey("inspection")) step.put("inspection", raw.get("inspection"));
        if (Boolean.TRUE.equals(raw.get("sensitive"))) {
            if (step.containsKey("value")) step.put("value", "${PASSWORD}");
            step.remove("values");
        }
        if (type.equals("navigate")) {
            String destination = Json.str(raw.get("url"));
            if (destination.isBlank() || destination.equals("about:blank")) return false;
            step.put("url", destination);
        }
        Map<String, Object> last = steps.isEmpty() ? null : steps.get(steps.size() - 1);
        if (last != null) {
            String lastType = Json.str(last.get("action"));
            if (type.equals("navigate") && lastType.equals("navigate") && Objects.equals(step.get("url"), last.get("url")) &&
                Objects.equals(tab, last.get("tabId"))) return false;
            if (type.equals("fill") && lastType.equals("click") && sameTarget(last, step)) {
                steps.remove(steps.size() - 1); // Clicking into a field before typing is usually not a separate test step.
            } else if ((type.equals("fill") || type.equals("select") || type.equals("check") || type.equals("scroll")) &&
                lastType.equals(type) && sameTarget(last, step)) {
                // In-place updates collapse typing bursts, repeated change events and transient scroll positions.
                step.put("id", last.get("id"));
                steps.set(steps.size() - 1, step);
                return true;
            } else if (type.equals("click") && lastType.equals("click") && sameTarget(last, step) &&
                within(last, 300)) return false;
            else if (type.equals("doubleClick") && lastType.equals("click") && sameTarget(last, step)) {
                steps.remove(steps.size() - 1);
                if (!steps.isEmpty() && "click".equals(steps.get(steps.size() - 1).get("action")) &&
                    sameTarget(steps.get(steps.size() - 1), step)) steps.remove(steps.size() - 1);
            }
        }
        String alias = tabNames.computeIfAbsent(tab, key -> "tab" + (tabNames.size() + 1));
        if (last != null && !Objects.equals(last.get("tabId"), tab) && !"manual".equals(tab)) {
            Map<String, Object> switched = new LinkedHashMap<>();
            switched.put("id", String.format(Locale.ROOT, "S%04d", next++));
            switched.put("action", "switchTab");
            switched.put("tab", alias);
            switched.put("description", "Switch to " + alias);
            switched.put("tabId", tab);
            switched.put("recordedAt", Instant.now().toString());
            steps.add(switched);
        }
        steps.add(step);
        return true;
    }

    private static boolean within(Map<String, Object> last, long ms) {
        try { return Math.abs(Instant.now().toEpochMilli() - Instant.parse(Json.str(last.get("recordedAt"))).toEpochMilli()) < ms; }
        catch (Exception e) { return false; }
    }
    private static boolean sameTarget(Map<String, Object> a, Map<String, Object> b) {
        Map<String, Object> x = Json.object(a.get("target")), y = Json.object(b.get("target"));
        if (x.isEmpty() || y.isEmpty()) return false;
        Map<String, Object> aLocator = Json.object(x.get("locator"));
        Map<String, Object> bLocator = Json.object(y.get("locator"));
        return !Json.str(aLocator.get("value")).isBlank() &&
            Objects.equals(aLocator.get("value"), bLocator.get("value")) &&
            Objects.equals(a.get("tabId"), b.get("tabId")) &&
            Objects.equals(Json.object(x.get("frame")).get("frameId"), Json.object(y.get("frame")).get("frameId"));
    }

    static String describe(String type, Map<String, Object> step) {
        Map<String, Object> target = Json.object(step.get("target"));
        String name = Json.str(target.get("name"));
        if (name.isBlank()) name = Json.str(target.get("tag"));
        if (name.isBlank()) name = "element";
        if (name.length() > 85) name = name.substring(0, 85) + "…";
        return switch (type) {
            case "navigate" -> "Open " + Json.str(step.getOrDefault("url", step.get("page")));
            case "click" -> "Click " + name;
            case "doubleClick" -> "Double-click " + name;
            case "rightClick" -> "Right-click " + name;
            case "fill" -> "Enter text in " + name;
            case "check" -> (Boolean.TRUE.equals(step.get("checked")) ? "Check " : "Uncheck ") + name;
            case "select" -> "Select option in " + name;
            case "fileUpload" -> "Upload file to " + name;
            case "keyPress" -> "Press " + Json.str(step.get("key")) + " on " + name;
            case "hover" -> "Hover over " + name;
            case "scroll" -> "Scroll " + name;
            case "switchTab" -> "Switch to " + Json.str(step.get("tab"));
            case "dragDrop" -> "Drag " + name + " to destination";
            case "waitFor" -> "Wait for " + Json.str(step.get("condition")) + " on " + name;
            case "handleDialog" -> "Handle " + Json.str(step.get("dialogType")) + " dialog";
            case "assert" -> "Verify " + Json.str(Json.object(step.get("assertion")).get("type")) + " on " + name;
            case "wait" -> "Wait " + Json.str(step.get("waitMs")) + " ms";
            case "assertUrlContains" -> "Verify URL contains " + Json.str(step.get("expected"));
            case "assertTitleContains" -> "Verify title contains " + Json.str(step.get("expected"));
            default -> type + " " + name;
        };
    }

    Map<String, Object> addManual(String type, String expected, String tab) {
        if (!Set.of("wait", "assertUrlContains", "assertTitleContains").contains(type)) throw new IllegalArgumentException("Unsupported manual step");
        if (steps.size() >= MAX_STEPS) throw new IllegalArgumentException("Step limit reached");
        Map<String, Object> step = new LinkedHashMap<>();
        step.put("id", String.format(Locale.ROOT, "S%04d", next++));
        step.put("action", type);
        if (type.equals("wait")) {
            int ms;
            try { ms = Integer.parseInt(expected.trim()); }
            catch (Exception e) { throw new IllegalArgumentException("Wait must be milliseconds (100–30000)"); }
            if (ms < 100 || ms > 30_000) throw new IllegalArgumentException("Wait must be 100–30000 ms");
            step.put("waitMs", ms);
        } else {
            if (expected.isBlank() || expected.length() > 1000) throw new IllegalArgumentException("Expected text must be 1–1000 characters");
            step.put("expected", expected);
        }
        step.put("tabId", tab);
        step.put("recordedAt", Instant.now().toString());
        step.put("description", describe(type, step));
        steps.add(step);
        return step;
    }

    boolean edit(int position, String label, String locatorStrategy, String locatorValue, String updatedValue) {
        Map<String, Object> step = at(position);
        if (step == null) return false;
        if (label.length() > 250 || locatorValue.length() > 1500 || updatedValue.length() > 3000)
            throw new IllegalArgumentException("Edit exceeds allowed length");
        if (!label.isBlank()) step.put("description", label.trim());
        if (!locatorValue.isBlank()) {
            if (!Set.of("css", "xpath", "testId", "role", "label", "placeholder", "name", "shadowCss").contains(locatorStrategy))
                throw new IllegalArgumentException("Unsupported locator strategy");
            Map<String, Object> target = Json.object(step.get("target"));
            if (target.isEmpty()) throw new IllegalArgumentException("This step has no target element");
            Map<String, Object> patched = new LinkedHashMap<>(target);
            patched.put("locator", Json.map("strategy", locatorStrategy, "value", locatorValue.trim(), "unique", false, "source", "manual"));
            step.put("target", patched);
        }
        if (!updatedValue.isBlank()) {
            String action = Json.str(step.get("action"));
            if (action.equals("assert")) {
                Map<String, Object> updated = new LinkedHashMap<>(Json.object(step.get("assertion")));
                Object previous = updated.get("expected");
                updated.put("expected", previous instanceof Boolean ? Boolean.parseBoolean(updatedValue) : updatedValue);
                step.put("assertion", updated);
            } else if (action.equals("fill") || action.equals("select")) {
                Map<String, Object> target = Json.object(step.get("target"));
                if ("password".equals(target.get("inputType")) && !updatedValue.startsWith("${"))
                    throw new IllegalArgumentException("Password must remain a variable placeholder, e.g. ${PASSWORD}");
                step.put("value", updatedValue);
            } else if (action.equals("assertUrlContains") || action.equals("assertTitleContains"))
                step.put("expected", updatedValue);
            else throw new IllegalArgumentException("This step has no editable data value");
        }
        return true;
    }

    boolean delete(int position) {
        if (at(position) == null) return false;
        steps.remove(position - 1);
        return true;
    }
    boolean move(int position, int direction) {
        int nextPos = position + direction;
        if (direction != 1 && direction != -1) return false;
        if (at(position) == null || at(nextPos) == null) return false;
        Collections.swap(steps, position - 1, nextPos - 1);
        return true;
    }
    private static Map<String, Object> minimalTarget(Map<String, Object> raw) {
        Map<String, Object> result = new LinkedHashMap<>();
        for (String key : List.of("tag", "name", "role", "inputType")) {
            if (raw.containsKey(key) && !Json.str(raw.get(key)).isBlank()) result.put(key, raw.get(key));
        }
        Map<String, Object> locator = Json.object(raw.get("locator"));
        if (!locator.isEmpty()) {
            Map<String, Object> best = new LinkedHashMap<>();
            for (String key : List.of("strategy", "value", "attribute", "role", "name", "segments", "unique"))
                if (locator.containsKey(key)) best.put(key, locator.get(key));
            result.put("locator", best);
        }
        List<Map<String, Object>> alternate = new ArrayList<>();
        for (Object item : Json.array(raw.get("alternatives"))) {
            Map<String, Object> loc = Json.object(item);
            if (alternate.size() >= 2) break;
            Map<String, Object> slim = new LinkedHashMap<>();
            for (String key : List.of("strategy", "value", "attribute"))
                if (loc.containsKey(key)) slim.put(key, loc.get(key));
            alternate.add(slim);
        }
        if (!alternate.isEmpty()) result.put("alternatives", alternate);
        Map<String, Object> frame = Json.object(raw.get("frame"));
        if (Boolean.TRUE.equals(frame.get("isIframe"))) {
            Map<String, Object> context = new LinkedHashMap<>();
            for (String key : List.of("url", "path", "frameId"))
                if (frame.containsKey(key)) context.put(key, frame.get(key));
            result.put("frame", context);
        }
        return result;
    }

    List<Map<String, Object>> exportSteps(boolean diagnostics) {
        List<Map<String, Object>> list = new ArrayList<>();
        for (int i = 0; i < steps.size(); i++) {
            Map<String, Object> raw = steps.get(i);
            Map<String, Object> entry = new LinkedHashMap<>();
            entry.put("step", i + 1);
            entry.put("id", raw.get("id"));
            entry.put("action", raw.get("action"));
            entry.put("description", raw.get("description"));
            for (String key : List.of("url", "tab", "target", "value", "values", "checked", "key", "modifiers",
                "files", "source", "destination", "x", "y", "assertion", "expected", "waitMs",
                "condition", "timeoutMs", "dialogType", "accepted", "message", "promptResponse", "condition",
            "timeoutMs", "dialogType", "accepted", "message", "promptResponse")) {
                if (raw.containsKey(key)) entry.put(key, (key.equals("target") || key.equals("source") || key.equals("destination")) && !diagnostics ?
                        minimalTarget(Json.object(raw.get(key))) : raw.get(key));
            }
            if (diagnostics) {
                for (String key : List.of("page", "tabId", "recordedAt", "inspection"))
                    if (raw.containsKey(key)) entry.put(key, raw.get(key));
            }
            list.add(entry);
        }
        return list;
    }
}
