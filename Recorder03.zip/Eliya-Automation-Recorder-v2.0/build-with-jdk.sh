#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")"
mkdir -p target/classes
find src/main/java -name '*.java' -exec javac --release 17 -encoding UTF-8 -d target/classes {} +
cp src/main/resources/* target/classes/
jar --create --file target/eliya-ui-recorder-2.0.0.jar --main-class com.eliya.recorder.RecorderApp -C target/classes .
echo "Built target/eliya-ui-recorder-2.0.0.jar"
