# Eliya Automation Recorder v2.0 — Java 17 / Maven

**Standalone browser recorder designed for automation testers.** It converts a real browser journey into a concise, editable JSON test case rather than exporting every DOM event, mouse movement, and element tree.

No LLM, Playwright runtime, Selenium server, ChromeDriver, Node.js, or downloaded browser is needed to run the recorder. It uses JDK 17's HTTP/WebSocket APIs and the DevTools protocol exposed by your **already-installed Chrome, Chromium, or Edge**.

## 1. Build the executable JAR

Prerequisites: **JDK 17+**, **Apache Maven**, and installed **Chrome / Edge**.

```sh
mvn clean package
java -jar target/eliya-ui-recorder-2.0.0.jar
```

The Maven project has a standard `pom.xml`, `src/main/java`, and `src/main/resources` layout. It uses no third-party runtime dependencies. Maven must be able to resolve the compiler/JAR build plugins from your approved repository on first build.

**Eclipse:** File → Import → Maven → Existing Maven Projects → select this folder (the directory containing `pom.xml`) → Finish → right-click project → Run As → Maven build → Goals: `clean package`.

**Offline fallback when Maven plugins are unavailable:** run `build-with-jdk.bat` on Windows, or `bash build-with-jdk.sh` on Mac/Linux. These scripts use only `javac` and `jar`, and generate the same JAR path.

## 2. Record an automation scenario

1. Start the JAR. The dashboard should open automatically. Otherwise open the localhost URL printed in the terminal.
2. Enter the **test case name** and **application URL**. Choose Chrome/Edge (or Auto).
3. Keep **scrolling, hover, and deep DOM capture unchecked** initially; you can enable them for a specific scenario.
4. Click **Launch & Start Recording**. The browser opens with its own temporary profile, installs its recorder hooks, and navigates to the URL.
5. Perform the test journey: click, type, choose dropdown options, toggle checkboxes, use keyboard shortcuts, work with shadow components, etc.
6. Add validations: choose **Element assertion picker** → **Pick in browser** → click the target element. The click is captured as an assertion, not a regular click. Element wait conditions can be picked similarly.
7. Use **Pause / Resume** when completing non-test setup steps.
8. Review each step. **Inspect** allows editing the business description, preferred locator, and input/expected value. **↑ / ↓** reorders; **×** removes a step.
9. Click **Stop & Export Clean JSON** to download the small, framework-independent test-case JSON. Use **Diagnostic JSON** only when you need full inspected element evidence.

Autosave (clean JSON snapshot after every saved step) is stored in `~/.eliya-ui-recorder/sessions/`. A separate clean download is always available while the recorder is running.

## 3. What is and isn't recorded

| Recorded as clean automation steps | Not recorded by default |
|---|---|
| Page navigation and tab switching | Mouse down/up/pointer noise |
| Click, double-click, right-click | Mouse movement and incidental focus |
| One `fill` after a typing sequence | Individual keystrokes for ordinary text |
| Dropdown single/multiple selections | Native select open/close noise |
| Checkbox/radio checked state | Duplicate click + change records |
| Relevant keyboard shortcuts, Enter, Escape | Routine unmodified letters/typing key events |
| File input intent (`${FILE_PATH}`) | Local file content or absolute path |
| Drag/drop action with source and destination | Intermediate drag events |
| Hover (opt-in, 900 ms dwell) | Every hover/mouseover event |
| Scroll (opt-in, debounced) | Every wheel event |
| Element assertions & wait conditions | Automatic AI-generated assertions |
| JS dialog handling (CDP best effort) | HTTP body, cookies, network traffic |

Each element step contains a **preferred locator**, up to **two alternatives**, its semantic name, and relevant context. The recorder prioritizes unique test IDs, stable IDs and meaningful semantic locators over long positional CSS/XPath paths. Open shadow roots are supported using a `shadowCss` locator path. Cross-origin iframe event capture depends on CDP attach permissions and requires application-specific testing.

### Assertions and waits

Element assertions: `visible`, `textContains`, `textEquals`, `valueEquals`, `enabled`, `checked`.

Element waits: `waitFor` with `condition: visible|hidden` and default `timeoutMs: 10000`. Manual steps: `assertUrlContains`, `assertTitleContains`, or fixed `wait` (100–30,000 ms). Prefer element waits to fixed timing delays.

## 4. JSON contract

See [`examples/login-test.json`](examples/login-test.json) for a small, representative automation test. A clean export has this general shape:

```json
{
  "schemaVersion": "2.0",
  "format": "eliya-automation-test",
  "testCase": {
    "name": "Login and verify dashboard",
    "startUrl": "https://example.test/login",
    "browser": "Chrome / Chromium",
    "recordedAt": "2026-11-04T08:00:00Z"
  },
  "summary": { "stepCount": 4, "assertionCount": 1 },
  "steps": [
    { "step": 1, "id": "S0001", "action": "navigate", "description": "Open login page", "url": "https://example.test/login" },
    { "step": 2, "id": "S0002", "action": "fill", "description": "Enter username", "target": { "tag": "input", "name": "Username", "locator": { "strategy": "testId", "value": "username", "unique": true } }, "value": "qa.user" }
  ]
}
```

`id` remains stable when steps are edited/reordered; `step` is their current sequence. `tab` appears on `switchTab`. For iframe elements a `frame` context is included. For open shadow DOM, `locator.strategy: shadowCss` has `segments` representing successive hosts and target.

**Diagnostic export** adds `tabId`, timestamps, page URLs, selected attributes, ancestor path, sibling summaries, and a bounded descendant subtree. Deep DOM mode captures more nodes but can slow a complex application. Never leave it enabled unnecessarily.

These JSON files are **automation-ready inputs** for a future Selenium/Playwright/Cucumber generator. This version does **not** generate source tests or execute/replay JSON directly. Locator uniqueness is a browser-time heuristic, not a guarantee of long-term stability.

## 5. Privacy and operational limitations

- Password/sensitive inputs are replaced with `${PASSWORD}`. File inputs use `${FILE_PATH}`. Prompt responses are `${DIALOG_INPUT}`. The recorder intentionally avoids collecting cookies, clipboard contents, headers and request bodies.
- Sensitivity is inferred from input type, name, label, autocomplete and explicit `data-sensitive`, `data-private`, or `data-recorder-redact` attributes. **This is best-effort**: arbitrary page text and custom attribute values may still contain secrets. Use test users, synthetic test data, and inspect exports before sharing.
- Browser-native permission prompts, certificate dialogs, operating-system file pickers, closed shadow roots, and some policy-restricted cross-origin frames are not observable as ordinary page events. JS alert/confirm/prompt support uses DevTools and is best effort.
- Browser plugin popups, inaccessible system UI, and unusual custom components may need additional application-specific instrumentation. The recorder does not guarantee capture of every conceivable browser interaction.
- Installed Chrome/Edge policies may disable remote debugging, instrumentation or external downloads. The recorder does not bypass those protections. No downloaded browser is required.
- Recording runs on `127.0.0.1` only, uses same-origin checks for modifying API requests, and launches a dedicated temporary browser profile. Closing the launched browser only affects the recorder's own process.

## 6. Advanced configuration

```sh
# Custom browser path on Windows (quote the system property):
java "-Drecorder.chromePath=C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe" -jar target/eliya-ui-recorder-2.0.0.jar

# Custom browser executable on Linux/Mac:
java -Drecorder.chromePath=/path/to/chrome -jar target/eliya-ui-recorder-2.0.0.jar

# Larger bounded debug DOM captures:
java -Drecorder.debugMaxNodes=1000 -jar target/eliya-ui-recorder-2.0.0.jar
```

For isolated container QA only (not desktop production), `-Drecorder.headless=true` and `-Drecorder.disableSandbox=true` are available. Never disable the browser sandbox on a user workstation.

## 7. Project structure

```text
Eliya-UI-Recorder-v2.0/
├── pom.xml
├── README.md
├── build-with-jdk.bat
├── build-with-jdk.sh
├── examples/
│   └── login-test.json
├── qa/
│   ├── fixture.html
│   └── test_e2e.py          # Optional container QA harness
└── src/main/
    ├── java/com/eliya/recorder/
    │   ├── ActionBook.java    # Normalization, dedupe, editing, clean JSON
    │   ├── BrowserRecorder.java # Chrome/Edge DevTools integration
    │   ├── Json.java          # Dependency-free JSON parser/writer
    │   └── RecorderApp.java   # Local REST dashboard and session lifecycle
    └── resources/
        ├── recorder.js       # Injected browser event-to-action capture
        └── index.html        # User interface
```

### Validation performed

- Java sources compiled successfully with `javac --release 17`; runnable JAR created and started with Java 21 (Java 17 bytecode target).
- The bundled optional CDP smoke harness passed for event deduplication, fill, checkbox/select, ordinary click, open shadow DOM click, keyboard shortcut, assertion picker, wait condition, pause/resume, manual assertion, step edit, password masking, and clean vs diagnostic JSON export.
- The test container blocks some loopback browser navigation. The automated test therefore loaded its fixture into a local `about:blank` page through DevTools; this is **not** a production-site connectivity test.
- Maven itself is not installed in the container. Its `pom.xml` is provided, but the `mvn clean package` lifecycle needs validation on a machine with Maven. Cross-origin iframe and browser-native dialog handling also require real-app testing.
