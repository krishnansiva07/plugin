@echo off
setlocal
cd /d "%~dp0"
if not exist "target\classes" mkdir "target\classes"
javac --release 17 -encoding UTF-8 -d "target\classes" src\main\java\com\eliya\recorder\*.java
if errorlevel 1 exit /b %errorlevel%
copy /y "src\main\resources\index.html" "target\classes\index.html" >nul
copy /y "src\main\resources\recorder.js" "target\classes\recorder.js" >nul
jar --create --file "target\eliya-ui-recorder-2.0.0.jar" --main-class com.eliya.recorder.RecorderApp -C "target\classes" .
if errorlevel 1 exit /b %errorlevel%
echo Built target\eliya-ui-recorder-2.0.0.jar
