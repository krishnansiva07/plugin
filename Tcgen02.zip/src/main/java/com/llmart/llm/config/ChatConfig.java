package com.llmart.llm.config;

import com.llmart.llm.exception.TcgenException;
import dev.langchain4j.model.chat.ChatLanguageModel;
import dev.langchain4j.model.openai.OpenAiChatModel;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.util.StringUtils;

@Configuration
public class ChatConfig {

    public static final String PROVIDER_AI4DEV = "AI4DEV";
    public static final String PROVIDER_LLM_CIB = "LLM_CIB";

    @Value("${llm.api-key:}")
    private String defaultApiKey;

    // Legacy defaults are intentionally retained so existing API clients and environment variables keep working.
    @Value("${llm.model-name:gpt-oss-120b}")
    private String defaultModelName;

    @Value("${llm.base-url:https://ai4devs.group.echonet/api/v1}")
    private String defaultBaseUrl;

    @Value("${llm.ai4dev.api-key:}")
    private String ai4DevApiKey;

    @Value("${llm.ai4dev.model-name:gpt-oss-120b}")
    private String ai4DevModelName;

    @Value("${llm.ai4dev.base-url:https://ai4devs.group.echonet/api/v1}")
    private String ai4DevBaseUrl;

    @Value("${llm.llm-cib.api-key:}")
    private String llmCibApiKey;

    @Value("${llm.llm-cib.model-name:gpt-oss-120b-ITG}")
    private String llmCibModelName;

    @Value("${llm.llm-cib.base-url:https://api.llm.cib.echonet/v1/openai}")
    private String llmCibBaseUrl;

    @Value("${llm.temperature:0.7}")
    private Double temperature;

    @Value("${llm.max-tokens:512}")
    private Integer maxTokens;

    /**
     * Backward compatible overload for callers that do not send a provider.
     */
    public ChatLanguageModel chatLanguageModel(String requestApiKey,
                                               String requestModelName,
                                               String requestBaseUrl) {
        return chatLanguageModel(null, requestApiKey, requestModelName, requestBaseUrl);
    }

    public ChatLanguageModel chatLanguageModel(String provider,
                                               String requestApiKey,
                                               String requestModelName,
                                               String requestBaseUrl) {
        ProviderDefaults providerDefaults = resolveProviderDefaults(provider);

        String apiKey = resolve(requestApiKey, providerDefaults.apiKey());
        String modelName = resolve(requestModelName, providerDefaults.modelName());
        String baseUrl = normalizeBaseUrl(resolve(requestBaseUrl, providerDefaults.baseUrl()));

        if (!StringUtils.hasText(apiKey)) {
            throw new TcgenException("API key is required for " + providerDefaults.displayName()
                    + ". Enter a user token in the UI or configure the matching environment variable.");
        }
        if (!StringUtils.hasText(modelName)) {
            throw new TcgenException("Model name is required for " + providerDefaults.displayName() + ".");
        }
        if (!StringUtils.hasText(baseUrl)) {
            throw new TcgenException("Base URL is required for " + providerDefaults.displayName() + ".");
        }

        return OpenAiChatModel.builder()
                .apiKey(apiKey)
                .modelName(modelName)
                .baseUrl(baseUrl)
                .temperature(temperature)
                .maxTokens(maxTokens)
                .build();
    }

    private ProviderDefaults resolveProviderDefaults(String provider) {
        // No provider means old behavior: use the original llm.* settings unchanged.
        if (!StringUtils.hasText(provider)) {
            return new ProviderDefaults("Legacy / AI4Dev", defaultApiKey, defaultModelName, defaultBaseUrl);
        }

        String normalized = provider.trim().toUpperCase().replace('-', '_').replace('@', '_');
        if (PROVIDER_AI4DEV.equals(normalized) || "AI4DEV".equals(normalized)) {
            return new ProviderDefaults("AI4Dev",
                    firstNonBlank(ai4DevApiKey, defaultApiKey),
                    firstNonBlank(ai4DevModelName, defaultModelName),
                    firstNonBlank(ai4DevBaseUrl, defaultBaseUrl));
        }
        if (PROVIDER_LLM_CIB.equals(normalized) || "LLM_CIB".equals(normalized) || "LLMCIB".equals(normalized)) {
            return new ProviderDefaults("LLM@CIB",
                    firstNonBlank(llmCibApiKey, defaultApiKey),
                    llmCibModelName,
                    llmCibBaseUrl);
        }

        throw new TcgenException("Unsupported LLM provider: " + provider + ". Choose AI4Dev or LLM@CIB.");
    }

    private String resolve(String requestValue, String defaultValue) {
        return StringUtils.hasText(requestValue) ? requestValue.trim() : defaultValue == null ? "" : defaultValue.trim();
    }

    private String firstNonBlank(String first, String fallback) {
        return StringUtils.hasText(first) ? first.trim() : fallback == null ? "" : fallback.trim();
    }

    private String normalizeBaseUrl(String baseUrl) {
        if (!StringUtils.hasText(baseUrl)) {
            return "";
        }
        String cleaned = baseUrl.trim();
        while (cleaned.endsWith("/")) {
            cleaned = cleaned.substring(0, cleaned.length() - 1);
        }
        if (cleaned.endsWith("/chat/completions")) {
            cleaned = cleaned.substring(0, cleaned.length() - "/chat/completions".length());
        }
        return cleaned;
    }

    private record ProviderDefaults(String displayName, String apiKey, String modelName, String baseUrl) {
    }
}
