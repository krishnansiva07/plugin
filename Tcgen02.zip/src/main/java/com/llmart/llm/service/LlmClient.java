package com.llmart.llm.service;

import com.llmart.llm.config.ChatConfig;
import com.llmart.llm.exception.TcgenException;
import dev.langchain4j.model.chat.ChatLanguageModel;
import org.springframework.stereotype.Service;

@Service
public class LlmClient {

    private final ChatConfig chatConfig;

    public LlmClient(ChatConfig chatConfig) {
        this.chatConfig = chatConfig;
    }

    public String generate(String prompt,
                           String provider,
                           String userApiKey,
                           String userModelName,
                           String userBaseUrl) {
        try {
            ChatLanguageModel chatModel = chatConfig.chatLanguageModel(provider, userApiKey, userModelName, userBaseUrl);
            return chatModel.generate(prompt);
        } catch (TcgenException ex) {
            throw ex;
        } catch (Exception ex) {
            throw new TcgenException("LLM request failed. Check provider, API key, model name, base URL and network connectivity.", ex);
        }
    }
}
