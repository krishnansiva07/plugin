# Astra Automation Quiz v7 - Generic Quiz Mode

Astra Automation Quiz is a single-screen live quiz host for Teams screen sharing.

v7 adds **Generic Quiz Mode** so the same application can run:

- Automation Testing quiz
- Banking Functional quiz
- Agile / Scrum quiz
- DevOps quiz
- Cloud quiz
- Security quiz
- General Knowledge quiz
- Custom topic quiz

The app still supports:

- LLM Dynamic Questions
- Manual JSON Question Bank
- Team rotation
- Simple / Medium / Complex question counts per team
- Central Pool / steal mechanism
- Hidden Quiz Master answer panel
- Reveal answer to audience
- Live leaderboard
- Winner screen
- Randomized answer options so the correct answer is not always A

## Run

```bash
mvn clean package
java -jar target/astra-automation-quiz-1.0.0.jar
```

Open:

```text
http://localhost:8090/index.html
```

Windows:

```bat
run.bat
```

Linux/Mac:

```bash
chmod +x run.sh
./run.sh
```

## LLM configuration

Edit `src/main/resources/application.properties` before building, or externalize using your deployment process.

```properties
spring.application.name=Astra Automation Quiz
server.port=8090

astra.llm.demo-mode=false
astra.llm.base-url=https://ai4devs.group.echonet/api/v1
astra.llm.api-key=YOUR_API_KEY
astra.llm.model-name=gpt-oss-120b
astra.llm.timeout-ms=60000
```

This version uses LangChain4j `chatModel.generate(prompt)` and does not manually append `/chat/completions` or `/completions` in application code.

## How to use Generic Mode

In the setup screen:

1. Select **Quiz Category**.
2. Confirm or edit **Audience**.
3. Confirm or edit **Topics / Domains**.
4. Select LLM mode or Manual JSON mode.
5. Configure simple / medium / complex counts per team.
6. Create quiz and generate questions.

Examples:

### Banking Functional

Category: `Banking Functional`

Topics:

```text
Retail Banking
Payments
Fund Transfer
Cards
Loans
KYC
AML
Core Banking
Reconciliation
SWIFT / ISO 20022
```

### Automation Testing

Category: `Automation Testing`

Topics:

```text
Selenium Java
Cucumber
API Automation
TestNG
Framework Design
```

### Custom

Category: `Custom`

Topics can be anything, for example:

```text
BNP Application Knowledge
Internal Process
Release Management
Production Support
```

## Manual JSON format

Manual JSON can use either `topic` or `technology` field.

```json
{
  "questions": [
    {
      "topic": "Fund Transfer",
      "difficulty": "MEDIUM",
      "questionType": "CHOOSE_BEST",
      "questionText": "A customer initiates a fund transfer but the beneficiary account is closed. What is the best expected system behavior?",
      "options": {
        "A": "Debit the customer and mark transaction successful",
        "B": "Reject before debit or reverse if already debited",
        "C": "Keep the transaction pending forever",
        "D": "Ignore beneficiary status"
      },
      "correctOption": "B",
      "explanation": "A transfer to a closed beneficiary account should not complete; the system should reject or reverse safely."
    }
  ]
}
```

