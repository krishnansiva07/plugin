package com.astraquiz.dto;
import java.util.List;

public class CreateQuizRequest {
    public boolean manualMode = false;
    public java.util.List<ManualQuestionDto> manualQuestions = new java.util.ArrayList<>();
    public String quizName;
    public String quizCategory = "Automation Testing";
    public String audience = "Automation testers";
    public List<String> teamNames;
    // Kept as technologies internally for backward compatibility; UI now treats this as Topic / Domain.
    public List<String> technologies;
    public int simplePerTeam = 3;
    public int mediumPerTeam = 2;
    public int complexPerTeam = 1;
    public int simplePoints = 5;
    public int mediumPoints = 10;
    public int complexPoints = 20;
}
