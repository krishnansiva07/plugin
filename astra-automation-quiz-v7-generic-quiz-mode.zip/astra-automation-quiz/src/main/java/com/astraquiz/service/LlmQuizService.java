package com.astraquiz.service;

import com.astraquiz.model.Difficulty;
import com.astraquiz.model.QuizQuestion;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import dev.langchain4j.model.chat.ChatLanguageModel;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class LlmQuizService {

    @Value("${astra.llm.demo-mode:false}")
    private boolean demoMode;

    @Value("${astra.llm.base-url:${llm.base-url:}}")
    private String baseUrl;

    @Value("${astra.llm.model-name:${llm.model-name:gpt-oss-120b}}")
    private String modelName;

    private final ChatLanguageModel chatModel;
    private final ObjectMapper mapper = new ObjectMapper();
    private int demoCounter = 0;

    public LlmQuizService(ChatLanguageModel chatModel) {
        this.chatModel = chatModel;
    }

    public QuizQuestion generateQuestion(String team, String quizCategory, String audience, String technology, Difficulty difficulty, int points, List<String> asked) {
        if (demoMode) {
            System.out.println("[Astra Quiz] Demo mode is ON. LLM will not be called.");
            return demoQuestion(team, technology, difficulty, points);
        }

        try {
            String prompt = buildPrompt(quizCategory, audience, technology, difficulty, points, asked);

            System.out.println("[Astra Quiz] Demo mode: " + demoMode);
            System.out.println("[Astra Quiz] Calling LLM using LangChain4j baseUrl: " + baseUrl);
            System.out.println("[Astra Quiz] Model: " + modelName);

            String llmResponse = chatModel.generate(prompt);
            return parseQuestion(llmResponse, team, technology, difficulty, points);
        } catch (Exception ex) {
            System.err.println("[Astra Quiz] LLM call failed. Error: " + ex.getMessage());
            throw new IllegalStateException("LLM call failed. Check base-url, API key, model and network. Details: " + ex.getMessage(), ex);
        }
    }

    private String buildPrompt(String quizCategory, String audience, String technology, Difficulty difficulty, int points, List<String> asked) {
        String category = quizCategory == null || quizCategory.isBlank() ? "Custom" : quizCategory.trim();
        String targetAudience = audience == null || audience.isBlank() ? "Quiz participants" : audience.trim();
        String topic = technology == null || technology.isBlank() ? category : technology.trim();

        return """
                You are Astra Quiz Master, an expert live quiz creator.

                Generate one fresh live quiz question for the selected category and topic.

                Quiz Category: %s
                Topic / Domain: %s
                Audience: %s
                Difficulty: %s
                Question Type: CHOOSE_BEST
                Points: %d

                Rules:
                - Create only one question.
                - The question must strictly match the Quiz Category and Topic / Domain.
                - If category is Banking Functional, generate practical banking functional/domain questions, not automation questions.
                - If category is Automation Testing, generate practical automation/testing questions.
                - If category is Custom, follow the given topic/domain exactly.
                - It must have exactly 4 options: A, B, C, D.
                - Only one option should be the best answer.
                - Do not make the correct answer always A. Distribute correct answers across A, B, C, and D.
                - Avoid repeated or generic questions.
                - Do not repeat these already asked concepts/questions: %s
                - Return JSON only. No markdown. No explanation outside JSON.

                JSON format:
                {
                  "questionText": "",
                  "options": {
                    "A": "",
                    "B": "",
                    "C": "",
                    "D": ""
                  },
                  "correctOption": "B",
                  "explanation": ""
                }
                """.formatted(
                category,
                topic,
                targetAudience,
                difficulty,
                points,
                String.join(" | ", asked == null ? List.of() : asked)
        );
    }

    private QuizQuestion parseQuestion(String content, String team, String technology, Difficulty difficulty, int points) throws Exception {
        String json = extractJson(content);
        JsonNode n = mapper.readTree(json);

        QuizQuestion q = base(team, technology, difficulty, points);
        q.setQuestionText(n.path("questionText").asText());

        LinkedHashMap<String, String> options = new LinkedHashMap<>();
        options.put("A", n.path("options").path("A").asText());
        options.put("B", n.path("options").path("B").asText());
        options.put("C", n.path("options").path("C").asText());
        options.put("D", n.path("options").path("D").asText());
        q.setOptions(options);

        q.setCorrectOption(n.path("correctOption").asText().trim().toUpperCase());
        q.setExplanation(n.path("explanation").asText());

        if (q.getQuestionText().isBlank() || q.getCorrectOption().isBlank()) {
            throw new IllegalStateException("LLM returned incomplete question JSON: " + json);
        }

        // Important for live quiz fairness:
        // LLMs often place the right answer in the first option or follow the sample JSON pattern.
        // We always shuffle options after generation and recalculate the correct option.
        return randomizeOptions(q);
    }

    private String extractJson(String text) {
        if (text == null || text.isBlank()) {
            throw new IllegalStateException("LLM returned empty content");
        }
        int start = text.indexOf('{');
        int end = text.lastIndexOf('}');
        if (start < 0 || end < start) {
            throw new IllegalStateException("LLM response does not contain JSON object: " + text);
        }
        return text.substring(start, end + 1);
    }

    private QuizQuestion demoQuestion(String team, String technology, Difficulty difficulty, int points) {
        demoCounter++;
        String tech = technology == null || technology.isBlank() ? "Automation" : technology;
        List<QuizQuestion> bank = new ArrayList<>();
        bank.add(make(team, tech, difficulty, points, "A Selenium test fails randomly because a button is not clickable immediately after page load. What is the best solution?", "Use Thread.sleep(10000)", "Use WebDriverWait with elementToBeClickable", "Refresh the page every time", "Increase implicit wait to 5 minutes", "B", "WebDriverWait waits for the exact clickable condition and reduces flaky timing failures."));
        bank.add(make(team, tech, difficulty, points, "In Cucumber automation, what is the best reason to keep step definitions reusable and business-readable?", "To make feature files longer", "To avoid duplicate automation code and improve maintainability", "To remove all assertions", "To replace page objects", "B", "Reusable steps reduce duplication and keep BDD scenarios maintainable."));
        bank.add(make(team, tech, difficulty, points, "For API automation using RestAssured, which validation gives the fastest confidence that the API request succeeded?", "Only print response body", "Validate HTTP status code and key response fields", "Add Thread.sleep after request", "Check browser title", "B", "Status code plus key fields confirms contract and business response basics."));
        bank.add(make(team, tech, difficulty, points, "A test passes locally but fails in Jenkins due to timing issues. What is the best first improvement?", "Increase global implicit wait to 5 minutes", "Use condition-based waits and capture failure evidence", "Disable Jenkins execution", "Run only one test forever", "B", "Condition-based waits and evidence help fix CI instability properly."));
        bank.add(make(team, tech, difficulty, points, "Which approach is best for Page Object Model design?", "Keep locators and actions inside page classes", "Put all locators in test class", "Duplicate login code in every test", "Avoid methods and use raw XPath everywhere", "A", "Page objects encapsulate locators and page actions, making tests cleaner."));
        return randomizeOptions(bank.get(demoCounter % bank.size()));
    }


    private QuizQuestion randomizeOptions(QuizQuestion q) {
        if (q == null || q.getOptions() == null || q.getOptions().isEmpty()) {
            return q;
        }

        String oldCorrectKey = q.getCorrectOption() == null ? "" : q.getCorrectOption().trim().toUpperCase();
        String correctText = q.getOptions().get(oldCorrectKey);

        if (correctText == null || correctText.isBlank()) {
            throw new IllegalStateException("Correct option does not match available options. correctOption=" + oldCorrectKey);
        }

        List<String> optionTexts = new ArrayList<>(q.getOptions().values());
        Collections.shuffle(optionTexts, new Random(System.nanoTime()));

        LinkedHashMap<String, String> shuffled = new LinkedHashMap<>();
        String[] keys = {"A", "B", "C", "D"};
        String newCorrectKey = "";

        for (int i = 0; i < keys.length && i < optionTexts.size(); i++) {
            String key = keys[i];
            String value = optionTexts.get(i);
            shuffled.put(key, value);
            if (value.equals(correctText)) {
                newCorrectKey = key;
            }
        }

        q.setOptions(shuffled);
        q.setCorrectOption(newCorrectKey);
        System.out.println("[Astra Quiz] Correct option randomized to: " + newCorrectKey);
        return q;
    }

    private QuizQuestion make(String team, String tech, Difficulty d, int p, String text, String a, String b, String c, String dd, String correct, String exp) {
        QuizQuestion q = base(team, tech, d, p);
        q.setQuestionText(text);
        LinkedHashMap<String, String> opts = new LinkedHashMap<>();
        opts.put("A", a);
        opts.put("B", b);
        opts.put("C", c);
        opts.put("D", dd);
        q.setOptions(opts);
        q.setCorrectOption(correct);
        q.setExplanation(exp);
        return q;
    }

    private QuizQuestion base(String team, String tech, Difficulty d, int p) {
        QuizQuestion q = new QuizQuestion();
        q.setId(UUID.randomUUID().toString());
        q.setAssignedTeam(team);
        q.setTechnology(tech);
        q.setDifficulty(d);
        q.setPoints(p);
        return q;
    }
}
