let quizId = null;
let currentQuestion = null;
let currentQuiz = null;
let answerVisible = false;
let audienceAnswerVisible = false;
let quizMasterVisible = true;
let manualQuestions = [];

const api = async (url, method='GET', body=null) => {
  const res = await fetch(url, {method, headers:{'Content-Type':'application/json'}, body: body ? JSON.stringify(body) : null});
  const data = await res.json();
  if(!res.ok) throw new Error(data.message || 'Request failed');
  return data;
};

function lines(id){ return document.getElementById(id).value.split('\n').map(x=>x.trim()).filter(Boolean); }
function toast(msg){ const t=document.getElementById('toast'); t.innerText=msg; t.style.display='block'; setTimeout(()=>t.style.display='none',3500); }

async function createQuiz(){
  try{
    const source = document.querySelector('input[name="questionSource"]:checked').value;
    if(source === 'manual' && (!manualQuestions || manualQuestions.length === 0)){
      return toast('Manual mode selected. Please upload a valid JSON question file first.');
    }
    const req = {
      manualMode: source === 'manual',
      manualQuestions: source === 'manual' ? manualQuestions : [],
      quizName: document.getElementById('quizName').value,
      quizCategory: document.getElementById('quizCategory').value,
      audience: document.getElementById('audience').value,
      teamNames: lines('teamNames'),
      technologies: lines('technologies'),
      simplePerTeam: +document.getElementById('simplePerTeam').value,
      mediumPerTeam: +document.getElementById('mediumPerTeam').value,
      complexPerTeam: +document.getElementById('complexPerTeam').value,
      simplePoints: +document.getElementById('simplePoints').value,
      mediumPoints: +document.getElementById('mediumPoints').value,
      complexPoints: +document.getElementById('complexPoints').value
    };
    currentQuiz = await api('/api/quiz/create','POST',req);
    quizId = currentQuiz.quizId;
    document.getElementById('setupPanel').classList.add('hidden');
    document.getElementById('quizPanel').classList.remove('hidden');
    document.getElementById('liveTitle').innerText = currentQuiz.quizName;
    renderMeta(); renderLeaderboard(currentQuiz.teams); fillStealTeams();
    toast('Quiz created: ' + quizId);
  }catch(e){ toast(e.message); }
}

function renderMeta(){
  const qCount = currentQuiz.teams.length * (currentQuiz.simplePerTeam + currentQuiz.mediumPerTeam + currentQuiz.complexPerTeam);
  const mode = currentQuiz.manualMode ? 'Manual JSON Mode' : 'LLM Mode';
  document.getElementById('modeBadge').innerText = mode;
  document.getElementById('quizMeta').innerHTML = `Quiz ID: <b>${currentQuiz.quizId}</b> | Mode: <b>${mode}</b> | Category: <b>${currentQuiz.quizCategory || 'Custom'}</b> | Teams: ${currentQuiz.teams.length} | Total Questions: ${qCount} | Topics: ${currentQuiz.technologies.join(', ')}`;
}

async function nextQuestion(){
  try{
    audienceAnswerVisible = false;
    currentQuestion = await api(`/api/quiz/${quizId}/next-question`,'POST',{});
    renderQuestion(); fillStealTeams(); answerVisible=false; renderAnswerPanel(); toast('Question generated for ' + currentQuestion.assignedTeam);
  }catch(e){
    if(e.message && e.message.toLowerCase().includes('quiz completed')) showWinnerScreen(); else toast(e.message);
  }
}

function renderQuestion(){
  const q = currentQuestion;
  document.getElementById('questionBox').classList.remove('empty');
  document.getElementById('questionBox').innerHTML = `
    <div class="meta">
      <span class="pill">Turn: ${q.assignedTeam}</span>
      <span class="pill">${q.difficulty}</span>
      <span class="pill">${q.technology}</span>
      <span class="pill">${q.points} Points</span>
    </div>
    <h2>${q.questionText}</h2>
    ${Object.entries(q.options).map(([k,v])=>`<div class="option"><b>${k}.</b> ${v}</div>`).join('')}
    ${audienceAnswerVisible ? `<div class="audienceAnswer"><b>Correct Answer: ${q.correctOption}</b><br>${q.explanation}</div>` : ''}
  `;
  document.getElementById('assignedTeamLabel').innerHTML = `<b>${q.assignedTeam}</b> should answer this question.`;
}

function toggleQuizMasterMode(){
  quizMasterVisible = !quizMasterVisible;
  document.getElementById('quizMasterCard').classList.toggle('hidden', !quizMasterVisible);
  toast(quizMasterVisible ? 'Quiz Master Mode visible' : 'Quiz Master Mode hidden for audience view');
}
function toggleAnswer(){ answerVisible = !answerVisible; renderAnswerPanel(); }
function revealAudienceAnswer(){
  if(!currentQuestion) return toast('Generate a question first');
  audienceAnswerVisible = !audienceAnswerVisible;
  renderQuestion();
}
function renderAnswerPanel(){
  const panel=document.getElementById('answerPanel');
  if(!currentQuestion || !answerVisible){ panel.classList.add('hidden'); panel.innerHTML=''; return; }
  panel.classList.remove('hidden');
  panel.innerHTML = `<h3>Correct Answer: ${currentQuestion.correctOption}</h3><p>${currentQuestion.explanation}</p><p><b>Status:</b> ${currentQuestion.status}</p>`;
}

async function submitPrimary(answer){
  if(!currentQuestion) return toast('Generate a question first');
  try{
    const res = await api(`/api/quiz/${quizId}/submit-primary`,'POST',{teamName:currentQuestion.assignedTeam, answer});
    toast(res.message); refreshFromSnapshot(res.data);
  }catch(e){ toast(e.message); }
}

async function submitSteal(answer){
  if(!currentQuestion) return toast('Generate a question first');
  const teamName=document.getElementById('stealTeam').value;
  if(!teamName) return toast('Select stealing team');
  try{
    const res = await api(`/api/quiz/${quizId}/submit-steal`,'POST',{teamName, answer});
    toast(res.message); refreshFromSnapshot(res.data);
  }catch(e){ toast(e.message); }
}

function refreshFromSnapshot(snapshot){
  currentQuiz = snapshot.quiz;
  currentQuestion = currentQuiz.questions[currentQuiz.questions.length-1];
  renderLeaderboard(snapshot.leaderboard); renderHistory(); fillStealTeams(); renderQuestion(); renderAnswerPanel();
}
function renderLeaderboard(teams){
  const sorted=[...teams].sort((a,b)=>b.score-a.score);
  document.getElementById('leaderboard').innerHTML = sorted.map((t,i)=>`<li>${i===0?'🏆 ':''}<b>${t.name}</b> — ${t.score} pts</li>`).join('');
}
function renderHistory(){
  document.getElementById('history').innerHTML = currentQuiz.questions.slice().reverse().map((q,i)=>`
    <div class="historyItem">
      <b>${currentQuiz.questions.length-i}. ${q.assignedTeam}</b> | ${q.difficulty} | ${q.points} pts<br>
      Status: ${q.status}${q.winnerTeam ? ' | Winner: '+q.winnerTeam : ''}<br>
      Correct Answer: ${q.correctOption}
    </div>`).join('');
}
function fillStealTeams(){
  const sel=document.getElementById('stealTeam');
  if(!currentQuiz) return;
  const assigned = currentQuestion ? currentQuestion.assignedTeam : '';
  sel.innerHTML = currentQuiz.teams.filter(t=>t.name!==assigned).map(t=>`<option>${t.name}</option>`).join('');
}
function showWinnerScreen(){
  if(!currentQuiz) return toast('Create quiz first');
  const sorted=[...currentQuiz.teams].sort((a,b)=>b.score-a.score);
  const winner=sorted[0];
  document.getElementById('winnerName').innerText = winner ? winner.name : 'No Winner';
  document.getElementById('winnerScore').innerText = winner ? `${winner.score} points` : '';
  document.getElementById('finalLeaderboard').innerHTML = sorted.map((t,i)=>`<div class="finalRow"><b>${i+1}. ${t.name}</b><span>${t.score} pts</span></div>`).join('');
  document.getElementById('winnerOverlay').classList.remove('hidden');
}
function hideWinnerScreen(){ document.getElementById('winnerOverlay').classList.add('hidden'); }


function toggleQuestionSource(){
  const source = document.querySelector('input[name="questionSource"]:checked').value;
  document.getElementById('manualUploadPanel').classList.toggle('hidden', source !== 'manual');
  document.getElementById('modeBadge').innerText = source === 'manual' ? 'Manual JSON Mode' : 'LLM Mode';
}

async function loadManualQuestionFile(event){
  try{
    const file = event.target.files[0];
    if(!file){ return; }
    const text = await file.text();
    const parsed = JSON.parse(text);
    const list = Array.isArray(parsed) ? parsed : (Array.isArray(parsed.questions) ? parsed.questions : []);
    manualQuestions = list.map(normalizeManualQuestion).filter(q => q.questionText && q.correctOption && q.options);
    const counts = manualQuestions.reduce((acc,q)=>{ acc[q.difficulty]=(acc[q.difficulty]||0)+1; return acc; },{});
    document.getElementById('manualQuestionSummary').innerHTML = `Loaded <b>${manualQuestions.length}</b> questions from <b>${file.name}</b><br>SIMPLE: ${counts.SIMPLE||0}, MEDIUM: ${counts.MEDIUM||0}, COMPLEX: ${counts.COMPLEX||0}`;
    toast('Manual JSON loaded successfully');
  }catch(e){
    manualQuestions = [];
    document.getElementById('manualQuestionSummary').innerText = 'Invalid JSON file. Please check format.';
    toast('Invalid JSON: ' + e.message);
  }
}

function normalizeManualQuestion(q){
  const options = q.options || {};
  return {
    technology: q.topic || q.domain || q.technology || 'Manual',
    difficulty: (q.difficulty || 'SIMPLE').toString().toUpperCase(),
    questionType: q.questionType || 'CHOOSE_BEST',
    points: Number(q.points || 0),
    questionText: q.questionText || q.question || '',
    options: {
      A: options.A || options.a || q.optionA || '',
      B: options.B || options.b || q.optionB || '',
      C: options.C || options.c || q.optionC || '',
      D: options.D || options.d || q.optionD || ''
    },
    correctOption: (q.correctOption || q.correctAnswer || q.answer || '').toString().trim().substring(0,1).toUpperCase(),
    explanation: q.explanation || 'No explanation provided.'
  };
}

function applyCategoryTemplate(){
  const category = document.getElementById('quizCategory').value;
  const topicBox = document.getElementById('technologies');
  const audience = document.getElementById('audience');
  const templates = {
    'Automation Testing': {audience:'Automation testers', topics:['Selenium Java','Cucumber','API Automation','TestNG','Framework Design']},
    'Banking Functional': {audience:'Banking application functional testers', topics:['Retail Banking','Payments','Fund Transfer','Cards','Loans','KYC','AML','Core Banking','Reconciliation','SWIFT / ISO 20022']},
    'Agile / Scrum': {audience:'Scrum team members', topics:['Scrum Events','Product Backlog','Sprint Planning','Definition of Done','Agile Metrics']},
    'DevOps': {audience:'Engineering teams', topics:['CI/CD','GitHub Actions','Jenkins','Release Management','Monitoring']},
    'Cloud': {audience:'Cloud engineers and testers', topics:['Azure','AWS Basics','Networking','Identity and Access','Monitoring']},
    'Security': {audience:'Technology teams', topics:['Authentication','Authorization','OWASP Basics','Secrets Management','Vulnerability Management']},
    'General Knowledge': {audience:'General participants', topics:['India','Science','Technology','Sports','Current Affairs']},
    'Custom': {audience:'Quiz participants', topics:['Custom Topic 1','Custom Topic 2','Custom Topic 3']}
  };
  const t = templates[category] || templates['Custom'];
  audience.value = t.audience;
  topicBox.value = t.topics.join('\n');
}

function downloadSampleJson(){
  const sample = {
    questions: [
      {
        topic: 'Selenium Java',
        difficulty: 'SIMPLE',
        questionType: 'CHOOSE_BEST',
        questionText: 'Which Selenium wait is best for waiting until a button becomes clickable?',
        options: {
          A: 'Thread.sleep()',
          B: 'WebDriverWait with elementToBeClickable',
          C: 'driver.close()',
          D: 'Implicit wait of 30 minutes'
        },
        correctOption: 'B',
        explanation: 'WebDriverWait with elementToBeClickable waits for the actual condition and reduces flaky tests.'
      },
      {
        topic: 'Fund Transfer',
        difficulty: 'MEDIUM',
        questionType: 'CHOOSE_BEST',
        questionText: 'A customer initiates a fund transfer but the beneficiary account is closed. What is the best expected system behavior?',
        options: {
          A: 'Debit the customer and mark transaction successful',
          B: 'Reject before debit or reverse if already debited',
          C: 'Keep the transaction pending forever',
          D: 'Ignore beneficiary status'
        },
        correctOption: 'B',
        explanation: 'A transfer to a closed beneficiary account should not complete; the system should reject or reverse safely.'
      },
      {
        topic: 'Agile Scrum',
        difficulty: 'COMPLEX',
        questionType: 'CHOOSE_BEST',
        questionText: 'During Sprint Planning, the team finds a story is too large and unclear. What is the best action?',
        options: {
          A: 'Accept it as-is to save time',
          B: 'Split/refine the story, clarify acceptance criteria, and estimate again',
          C: 'Move it directly to Done',
          D: 'Ignore risks until production'
        },
        correctOption: 'B',
        explanation: 'Large unclear stories should be refined into testable pieces with clear acceptance criteria before commitment.'
      }
    ]
  };
  const blob = new Blob([JSON.stringify(sample, null, 2)], {type:'application/json'});
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = 'astra-sample-questions.json'; a.click();
  URL.revokeObjectURL(url);
}
