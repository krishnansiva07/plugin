# Smart Playwright LangChain Enterprise Framework V6

A Playwright TypeScript framework using installed Chrome/Edge, JSON test data, Page Objects, smart locators, optional LangChain LLM healing, persisted healed locators, and three report formats.

## Setup

```powershell
npm ci
Copy-Item .env.example .env
```

Place the corporate PEM bundle at:

```text
certificates/generated-ca-bundle.pem
```

Run one mapped test:

```powershell
npm test -- --testId=TC_ORDER_001
```

Verify before execution:

```powershell
npm test -- --testId=TC_ORDER_001 --list
```

## Reports

- `reports/index.html`: consolidated colourful report.
- `reports/execution-selection.json`: exact mapped selection.
- `reports/test-results.json`: raw consolidated results.
- `playwright-report/index.html`: standard Playwright report.
- `test-results/junit.xml`: Jenkins JUnit report.

See `docs/TEST_SELECTION.md` and the other documents under `docs/`.
