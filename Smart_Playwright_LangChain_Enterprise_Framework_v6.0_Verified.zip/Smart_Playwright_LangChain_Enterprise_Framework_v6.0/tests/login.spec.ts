import { test } from '@playwright/test';
import { LoginPage } from '../src/pages/LoginPage';
import { TestDataService, type BaseTestData } from '../src/core/execution/TestDataService';

interface LoginTestData extends BaseTestData {
  username: string;
  password: string;
  expectedType: 'products' | 'error';
  expectedValue: string;
}

const testData = TestDataService.load<LoginTestData>(
  'test-data/login-tests.json',
  'login'
);

test.describe('LOGIN_SauceDemoLogin', () => {
  for (const row of testData) {
    test(`[${row.testId}] ${row.testName}`, async ({ page }, testInfo) => {
      testInfo.annotations.push({ type: 'testId', description: row.testId });
      testInfo.annotations.push({ type: 'tags', description: (row.tags ?? []).join(',') });

      const loginPage = new LoginPage(page);
      await loginPage.open();
      await loginPage.login(row.username, row.password);

      if (row.expectedType === 'products') {
        await loginPage.verifyProductsPage(row.expectedValue);
      } else {
        await loginPage.verifyError(row.expectedValue);
      }
    });
  }
});
