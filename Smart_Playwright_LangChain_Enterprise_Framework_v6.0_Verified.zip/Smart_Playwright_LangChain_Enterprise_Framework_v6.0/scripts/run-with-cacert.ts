import { existsSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { TestCatalog, type CatalogFilter } from '../src/core/execution/TestCatalog';

const root = path.resolve(process.cwd());

const certificateCandidates = [
  'generated-ca-bundle.pem',
  'corporate-ca.pem',
  'cacert.pem',
  'cacert',
  'cacerts'
].map(name => path.join(root, 'certificates', name));

const certificate = certificateCandidates.find(existsSync);
const childEnvironment: NodeJS.ProcessEnv = { ...process.env };

if (certificate) {
  const content = readFileSync(certificate, 'utf8');
  if (!content.includes('-----BEGIN CERTIFICATE-----')) {
    throw new Error(
      `Certificate file is not PEM formatted: ${certificate}. ` +
      'Use certificates/generated-ca-bundle.pem.'
    );
  }
  childEnvironment.NODE_EXTRA_CA_CERTS = certificate;
}

interface ParsedArguments {
  filter: CatalogFilter;
  browser?: string;
  playwrightArguments: string[];
}

const aliases: Record<string, keyof CatalogFilter | 'browser'> = {
  '--testid': 'testIds',
  '--testids': 'testIds',
  '--tag': 'tags',
  '--tags': 'tags',
  '--testname': 'testName',
  '--name': 'testName',
  '--suite': 'suite',
  '--priority': 'priority',
  '--browser': 'browser'
};

function parseArguments(argumentsToParse: string[]): ParsedArguments {
  const filter: CatalogFilter = {};
  const playwrightArguments: string[] = [];
  let browser: string | undefined;

  for (let index = 0; index < argumentsToParse.length; index++) {
    const raw = argumentsToParse[index];
    const equalsIndex = raw.indexOf('=');
    const option = (equalsIndex >= 0 ? raw.slice(0, equalsIndex) : raw).toLowerCase();
    const key = aliases[option];

    if (!key) {
      playwrightArguments.push(raw);
      continue;
    }

    const value = equalsIndex >= 0
      ? raw.slice(equalsIndex + 1).trim()
      : argumentsToParse[++index]?.trim();

    if (!value || value.startsWith('--')) {
      throw new Error(`Missing value for ${option}`);
    }

    if (key === 'browser') browser = value;
    else filter[key] = value;
  }

  return { filter, browser, playwrightArguments };
}

const parsed = parseArguments(process.argv.slice(2));
const catalog = new TestCatalog();
const hasCustomFilter = Object.values(parsed.filter).some(value => Boolean(value?.trim()));
const selection = hasCustomFilter ? catalog.select(parsed.filter) : catalog.all();

if (!selection.entries.length) {
  console.error('\n[TEST MAPPER] No test matched the supplied selection.');
  console.error(`Selection: ${JSON.stringify(parsed.filter)}`);
  process.exit(3);
}

// The mapper explicitly passes only the selected spec files to Playwright.
// TEST_IDS then ensures that each selected spec registers only its mapped rows.
childEnvironment.TEST_IDS = selection.testIds.join(',');
if (parsed.browser) childEnvironment.BROWSER = parsed.browser;

const selectionFile = path.join(root, 'reports', 'execution-selection.json');
mkdirSync(path.dirname(selectionFile), { recursive: true });
writeFileSync(selectionFile, JSON.stringify({
  generatedAt: new Date().toISOString(),
  requested: parsed.filter,
  selectedTestIds: selection.testIds,
  selectedSpecs: selection.specs,
  selectedEntries: selection.entries
}, null, 2));

console.log('\n============================================================');
console.log(' SMART PLAYWRIGHT V6 EXECUTION MAPPER');
console.log('============================================================');
console.log(` Test IDs        : ${selection.testIds.join(', ')}`);
console.log(` Spec files      : ${selection.specs.join(', ')}`);
console.log(` Tag filter      : ${parsed.filter.tags ?? 'All'}`);
console.log(` Test name       : ${parsed.filter.testName ?? 'All'}`);
console.log(` Suite           : ${parsed.filter.suite ?? 'All'}`);
console.log(` Priority        : ${parsed.filter.priority ?? 'All'}`);
console.log(` Browser         : ${childEnvironment.BROWSER ?? 'From .env'}`);
console.log(` Certificate     : ${certificate ?? 'Not configured'}`);
console.log(` Playwright args : ${parsed.playwrightArguments.join(' ') || 'None'}`);
console.log('============================================================\n');

const cli = path.join(root, 'node_modules', '@playwright', 'test', 'cli.js');
if (!existsSync(cli)) {
  throw new Error(`Playwright CLI not found: ${cli}. Run npm ci first.`);
}

const result = spawnSync(
  process.execPath,
  [cli, 'test', ...selection.specs, ...parsed.playwrightArguments],
  {
    cwd: root,
    env: childEnvironment,
    stdio: 'inherit',
    windowsHide: false
  }
);

if (result.error) throw result.error;
process.exit(result.status ?? 1);
