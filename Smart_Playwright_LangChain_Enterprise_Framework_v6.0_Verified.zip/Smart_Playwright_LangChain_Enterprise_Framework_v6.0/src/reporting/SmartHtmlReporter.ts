import type { FullConfig, FullResult, Reporter, TestCase, TestResult } from '@playwright/test/reporter';
import fs from 'node:fs';
import path from 'node:path';

interface HealingEvent {
  elementKey: string;
  elementDescription: string;
  action: string;
  source: 'LLM' | 'SAVED' | 'DETERMINISTIC';
  originalLocator: string;
  healedLocator: string;
  confidence: number;
  reason: string;
  persisted: boolean;
}
interface Row {
  serialNo: number;
  testId: string;
  testName: string;
  status: string;
  durationMs: number;
  error: string;
  healing: HealingEvent[];
}
const esc=(v:string)=>v.replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]??c));
const parseTitle=(title:string)=>{const m=title.match(/^\[([^\]]+)]\s*(.+)$/);return m?{testId:m[1],testName:m[2]}:{testId:'N/A',testName:title};};
const basicStatus=(r:TestResult)=>r.status==='passed'?'PASSED':r.status==='skipped'?'SKIPPED':r.status==='timedOut'?'TIMED OUT':r.status==='interrupted'?'INTERRUPTED':'FAILED';

export default class SmartHtmlReporter implements Reporter {
  private rows:Row[]=[]; private outputDir=path.resolve('reports'); private startedAt=new Date(); private config?:FullConfig;
  onBegin(config:FullConfig){this.config=config;this.startedAt=new Date();this.rows=[];}
  onTestEnd(test:TestCase,result:TestResult){
    const parsed=parseTitle(test.title);
    const healing=test.annotations.filter(a=>a.type==='healing').flatMap(a=>{try{return [JSON.parse(a.description??'') as HealingEvent];}catch{return [];}});
    this.rows.push({serialNo:this.rows.length+1,testId:parsed.testId,testName:parsed.testName,status:result.status==='passed'&&healing.length?'PASSED – HEALED':basicStatus(result),durationMs:result.duration,error:result.error?.message??'',healing});
  }
  onEnd(result:FullResult){
    fs.mkdirSync(this.outputDir,{recursive:true});
    fs.writeFileSync(path.join(this.outputDir,'test-results.json'),JSON.stringify(this.rows,null,2));
    const total=this.rows.length, passed=this.rows.filter(r=>r.status==='PASSED').length, healed=this.rows.filter(r=>r.status==='PASSED – HEALED').length, failed=this.rows.filter(r=>['FAILED','TIMED OUT','INTERRUPTED'].includes(r.status)).length, skipped=this.rows.filter(r=>r.status==='SKIPPED').length;
    const executed=total-skipped, pct=executed?((passed+healed)/executed)*100:0;
    const md=(this.config?.metadata??{}) as Record<string,unknown>;
    const healRows=this.rows.flatMap(r=>r.healing.map(h=>`<tr><td>${esc(r.testId)}</td><td>${esc(h.elementDescription)}</td><td>${esc(h.source)}</td><td><code>${esc(h.originalLocator)}</code></td><td><code>${esc(h.healedLocator)}</code></td><td>${(h.confidence*100).toFixed(0)}%</td><td>${h.persisted?'Yes':'No'}</td></tr>`)).join('');
    const resultRows=this.rows.map(r=>`<tr data-status="${esc(r.status)}"><td>${r.serialNo}</td><td>${esc(r.testId)}</td><td>${esc(r.testName)}${r.error?`<details><summary>Error</summary><pre>${esc(r.error)}</pre></details>`:''}</td><td><span class="status ${r.status.includes('HEALED')?'healed':r.status.toLowerCase().replace(/\s+/g,'-')}">${esc(r.status)}</span></td></tr>`).join('');
    const html=`<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>Smart Playwright Report</title><style>
body{margin:0;background:#f4f7fb;font-family:Segoe UI,Arial;color:#172033}.c{max-width:1250px;margin:28px auto;padding:0 18px}.hero{background:linear-gradient(135deg,#102a56,#3764bf);color:#fff;padding:28px;border-radius:18px}.hero h1{margin:0 0 10px}.meta{display:flex;gap:18px;flex-wrap:wrap}.score{font-size:36px;font-weight:800;margin-top:18px}.p{background:#fff;margin-top:20px;padding:20px;border-radius:16px;box-shadow:0 8px 24px #102a5614}table{width:100%;border-collapse:collapse}th,td{padding:13px;border-bottom:1px solid #e5e7eb;text-align:left}th{background:#f8fafc}.status{padding:6px 11px;border-radius:999px;font-size:12px;font-weight:800}.passed{background:#dcfae6;color:#067647}.healed{background:#ffead5;color:#b54708}.failed,.timed-out,.interrupted{background:#fee4e2;color:#b42318}.skipped{background:#eaecf0;color:#475467}input,select{padding:10px;border:1px solid #ccd3df;border-radius:9px;margin:0 8px 12px 0}code{white-space:pre-wrap}pre{white-space:pre-wrap;background:#101828;color:white;padding:12px;border-radius:8px}
</style></head><body><main class="c"><section class="hero"><h1>Smart Playwright Automation Report</h1><div class="meta"><span>Environment: <b>${esc(String(md.environment??'QA'))}</b></span><span>Browser: <b>${esc(String(md.selectedBrowser??'Unknown'))}</b></span><span>Run: <b>${esc(result.status)}</b></span><span>Duration: <b>${((Date.now()-this.startedAt.getTime())/1000).toFixed(1)}s</b></span></div><div class="score">${pct.toFixed(2)}%</div></section>
<section class="p"><h2>Execution Summary</h2><table><thead><tr><th>Tests Executed</th><th>Passed</th><th>Failed</th><th>Pass %</th></tr></thead><tbody><tr><td>${executed}</td><td>${passed+healed}</td><td>${failed}</td><td>${pct.toFixed(2)}%</td></tr></tbody></table>${skipped?`<p><b>Skipped:</b> ${skipped}</p>`:''}${healed?`<p><b>Passed with healing:</b> ${healed}</p>`:''}</section>
<section class="p"><input id="q" placeholder="Search Test ID or Test Name" oninput="f()"><select id="s" onchange="f()"><option value="">All statuses</option><option>PASSED</option><option>PASSED – HEALED</option><option>FAILED</option><option>SKIPPED</option></select><table><thead><tr><th>Serial No.</th><th>Test ID</th><th>Test Name</th><th>Status</th></tr></thead><tbody id="rows">${resultRows}</tbody></table></section>
<section class="p"><h2>Self-Healing Details</h2>${healRows?`<div style="overflow:auto"><table><tr><th>Test ID</th><th>Element</th><th>Source</th><th>Original Locator</th><th>Working Locator</th><th>Confidence</th><th>Persisted</th></tr>${healRows}</table></div>`:'<p>No healing was used in this execution.</p>'}</section>
</main><script>function f(){const q=document.getElementById('q').value.toLowerCase(),s=document.getElementById('s').value;document.querySelectorAll('#rows tr').forEach(r=>r.style.display=(!q||r.innerText.toLowerCase().includes(q))&&(!s||r.dataset.status===s)?'':'none')}</script></body></html>`;
    fs.writeFileSync(path.join(this.outputDir,'index.html'),html);
  }
}
