import fs from 'node:fs';
import path from 'node:path';

export interface TestCatalogEntry {
  testId: string;
  testName: string;
  suite: string;
  tags: string[];
  priority?: string;
  spec: string;
  dataFile: string;
}

export interface CatalogSelection {
  entries: TestCatalogEntry[];
  specs: string[];
  testIds: string[];
}

export interface CatalogFilter {
  testIds?: string;
  tags?: string;
  testName?: string;
  suite?: string;
  priority?: string;
}

interface DataRow {
  testId?: string;
  testName?: string;
}

const csv = (value?: string): string[] =>
  (value ?? '')
    .split(',')
    .map(item => item.trim())
    .filter(Boolean);

const normalized = (value: string): string => value.trim().toLowerCase();

export class TestCatalog {
  private readonly entries: TestCatalogEntry[];

  constructor(catalogPath = 'config/test-catalog.json') {
    const resolved = path.resolve(catalogPath);
    if (!fs.existsSync(resolved)) {
      throw new Error(`Test catalog not found: ${resolved}`);
    }

    const parsed: unknown = JSON.parse(fs.readFileSync(resolved, 'utf8'));
    if (!Array.isArray(parsed)) {
      throw new Error(`Test catalog must contain an array: ${resolved}`);
    }

    this.entries = parsed as TestCatalogEntry[];
    this.validate();
  }

  select(options: CatalogFilter): CatalogSelection {
    const requestedIds = csv(options.testIds).map(normalized);
    const requestedTags = csv(options.tags).map(normalized);
    const requestedName = options.testName?.trim().toLowerCase();
    const requestedSuite = options.suite?.trim().toLowerCase();
    const requestedPriority = options.priority?.trim().toLowerCase();

    const entries = this.entries.filter(entry => {
      if (requestedIds.length && !requestedIds.includes(normalized(entry.testId))) return false;
      if (requestedName && !entry.testName.toLowerCase().includes(requestedName)) return false;
      if (requestedSuite && normalized(entry.suite) !== requestedSuite) return false;
      if (requestedPriority && normalized(entry.priority ?? '') !== requestedPriority) return false;

      if (requestedTags.length) {
        const entryTags = entry.tags.map(normalized);
        // OR behaviour: a test is selected when it contains any requested tag.
        if (!requestedTags.some(tag => entryTags.includes(tag))) return false;
      }
      return true;
    });

    return {
      entries,
      specs: [...new Set(entries.map(entry => path.normalize(entry.spec)))],
      testIds: entries.map(entry => entry.testId)
    };
  }

  all(): CatalogSelection {
    return {
      entries: [...this.entries],
      specs: [...new Set(this.entries.map(entry => path.normalize(entry.spec)))],
      testIds: this.entries.map(entry => entry.testId)
    };
  }

  private validate(): void {
    const seen = new Set<string>();
    const dataCache = new Map<string, DataRow[]>();

    for (const entry of this.entries) {
      if (!entry.testId?.trim()) throw new Error('Catalog entry is missing testId');
      if (!entry.testName?.trim()) throw new Error(`Catalog entry ${entry.testId} is missing testName`);
      if (!entry.suite?.trim()) throw new Error(`Catalog entry ${entry.testId} is missing suite`);
      if (!Array.isArray(entry.tags)) throw new Error(`Catalog entry ${entry.testId} must contain tags[]`);
      if (!entry.spec?.trim()) throw new Error(`Catalog entry ${entry.testId} is missing spec`);
      if (!entry.dataFile?.trim()) throw new Error(`Catalog entry ${entry.testId} is missing dataFile`);

      const key = normalized(entry.testId);
      if (seen.has(key)) throw new Error(`Duplicate testId in catalog: ${entry.testId}`);
      seen.add(key);

      const specPath = path.resolve(entry.spec);
      const dataPath = path.resolve(entry.dataFile);
      if (!fs.existsSync(specPath)) throw new Error(`Spec mapped for ${entry.testId} does not exist: ${entry.spec}`);
      if (!fs.existsSync(dataPath)) throw new Error(`Data file mapped for ${entry.testId} does not exist: ${entry.dataFile}`);

      let rows = dataCache.get(dataPath);
      if (!rows) {
        const parsed: unknown = JSON.parse(fs.readFileSync(dataPath, 'utf8'));
        if (!Array.isArray(parsed)) throw new Error(`Mapped data file must contain an array: ${entry.dataFile}`);
        rows = parsed as DataRow[];
        dataCache.set(dataPath, rows);
      }

      const row = rows.find(item => normalized(item.testId ?? '') === key);
      if (!row) {
        throw new Error(`Catalog mapping error: ${entry.testId} is not present in ${entry.dataFile}`);
      }
      if ((row.testName ?? '').trim() !== entry.testName.trim()) {
        throw new Error(
          `Catalog mapping error for ${entry.testId}: testName differs between catalog and ${entry.dataFile}`
        );
      }
    }
  }
}
