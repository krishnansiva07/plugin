export interface ExecutionFilters {
  testIds: Set<string>;
}

const csv = (value?: string): string[] =>
  (value ?? '')
    .split(',')
    .map(value => value.trim().toLowerCase())
    .filter(Boolean);

export function getExecutionFilters(): ExecutionFilters {
  return {
    testIds: new Set(csv(process.env.TEST_IDS))
  };
}
