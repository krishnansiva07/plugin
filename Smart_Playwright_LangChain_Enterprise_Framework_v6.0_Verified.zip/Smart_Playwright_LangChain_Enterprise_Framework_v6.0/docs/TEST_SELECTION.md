# Verified Test Selection

V6 uses an explicit mapper. It does not depend on Playwright `--grep`.

## Mapping

`config/test-catalog.json` maps each Test ID to:

- the Playwright spec file;
- the JSON data file;
- test name;
- suite;
- tags;
- priority.

The runner validates that the Test ID and test name are present in the mapped JSON file before Playwright starts.

## Commands

```powershell
# All mapped and enabled tests
npm test

# One Test ID
npm test -- --testId=TC_ORDER_001

# Multiple Test IDs
npm test -- --testIds=TC_LOGIN_001,TC_ORDER_001

# Any test containing the tag
npm test -- --tag=smoke

# Partial, case-insensitive test-name match
npm test -- --testName="Place order"

# Suite
npm test -- --suite=order

# Priority
npm test -- --priority=P1

# Verify selection without executing
npm test -- --testId=TC_ORDER_001 --list
```

## Selection flow

1. `run-with-cacert.ts` parses the custom option.
2. `TestCatalog` finds matching catalog rows.
3. The mapper obtains the exact spec files and Test IDs.
4. Only those spec paths are sent to Playwright.
5. `TEST_IDS` is passed to the Playwright child process.
6. `TestDataService` registers only matching JSON rows.

`reports/execution-selection.json` records exactly what was selected.
