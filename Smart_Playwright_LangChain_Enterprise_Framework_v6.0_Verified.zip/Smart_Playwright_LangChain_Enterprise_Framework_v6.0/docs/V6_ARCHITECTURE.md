# V6 Architecture

## Main components

```text
Command line
   ↓
scripts/run-with-cacert.ts
   ↓
config/test-catalog.json
   ↓
TestCatalog validates Test ID ↔ spec ↔ JSON row
   ↓
Selected spec files + TEST_IDS
   ↓
Playwright Test
   ↓
TestDataService registers only selected rows
   ↓
Page Objects → SmartActions
   ↓
Saved locator → Primary → Fallback → LangChain LLM
   ↓
Business assertions
   ↓
Custom HTML + Playwright HTML + JUnit XML
```

## Test mapping

Every catalog entry maps one Test ID to one script and one data file. Startup validation fails when:

- the Test ID is duplicated;
- the spec does not exist;
- the JSON file does not exist;
- the Test ID is absent from the JSON file;
- the test name differs between catalog and JSON.

This prevents a Test ID from silently running the wrong script.

## Reports

The custom report contains:

1. An execution summary table with Tests Executed, Passed, Failed and Pass %.
2. An overall table with Serial No., Test ID, Test Name and Status.
3. A healing table when saved, deterministic or LLM healing was used.

The standard Playwright report and JUnit XML are generated in the same execution.
