'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs');
const vm=require('node:vm');
const test=require('node:test');
const path=require('node:path');
const root=path.resolve(__dirname,'../..');
const read=p=>fs.readFileSync(path.join(root,p),'utf8');
const props=read('src/main/resources/application.properties');
const chat=read('src/main/java/com/llmart/llm/controller/ChatController.java');
const terminal=read('src/main/java/com/llmart/llm/controller/TerminalController.java');
const startup=read('src/main/java/com/llmart/llm/service/OpenCodeStartupInitializer.java');
const script=read('src/main/resources/static/app.js');
const html=read('src/main/resources/static/index.html');

test('OpenCode is disabled at configuration defaults and does not autostart',()=>{
 assert.match(props,/eliya\.opencode\.integration-enabled=\$\{ELIYA_OPENCODE_INTEGRATION_ENABLED:false\}/);
 assert.match(props,/eliya\.execution\.engine=\$\{ELIYA_EXECUTION_ENGINE:legacy\}/);
 assert.match(props,/eliya\.opencode\.auto-start=\$\{ELIYA_OPENCODE_AUTO_START:false\}/);
 assert.match(startup,/if \(allowOpenCode\) service\.initializeOnStartup\(\)/);
});
test('Old OpenCode headers cannot route Chat or Terminal when feature gate is false',()=>{
 assert.match(chat,/if \(allowOpenCode && !"legacy"\.equals\(preference\)/);
 assert.match(terminal,/if \(allowOpenCode && !"legacy"\.equalsIgnoreCase\(engineChoice\)/);
 assert.match(terminal,/if \(allowOpenCode && openCode != null && openCode\.accepts\(request\)/);
 assert.match(terminal,/boolean keepOpenCode = allowOpenCode &&/);
 assert.match(terminal,/!allowOpenCode \|\| openCode == null/);
});
test('Stale browser OpenCode selections resolve to native Eliya',()=>{
 const fn=script.match(/function currentExecutionEngine\(\)\s*\{[^}]*\}/)[0];
 assert.equal(vm.runInNewContext(fn+';currentExecutionEngine()'), 'legacy');
 const terminalFn=script.match(/function terminalExecutionChoice\(\)\s*\{[^}]*\}/)[0];
 assert.equal(vm.runInNewContext(terminalFn+';terminalExecutionChoice()'), 'legacy');
});
test('OpenCode picker hidden; native interactive terminal remains',()=>{
 assert.doesNotMatch(html,/<option value="opencode">/);
 assert.doesNotMatch(html,/id="terminalExecutionEngine"/);
 assert.match(html,/id="terminalDock"/);
 assert.match(html,/id="terminalOutput"/);
 assert.match(html,/id="terminalDecisionDock"/);
 assert.match(html,/id="terminalNewTab"/);
 assert.match(html,/Agent engine: Eliya/);
});
test('Prewarm and polling functions cannot contact OpenCode',()=>{
 const a=script.indexOf('async function prewarmOpenCode()');
 const b=script.indexOf('function terminalSelectWorkflow(mode)',a);
 const segment=script.slice(a,b);
 assert.doesNotMatch(segment,/api\(/);
 assert.doesNotMatch(segment,/fetch\(/);
 assert.match(segment,/terminalEngineInfo=\{engine:'legacy'/);
});
