#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../.."
node --check src/main/resources/static/app.js
node --test qa/eliya119-native-only/native_only.test.cjs
node --test src/test/js/*.test.js
