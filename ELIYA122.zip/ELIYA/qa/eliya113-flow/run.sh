#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../.."
TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT
javac --release 17 -d "$TMP" $(find qa/eliya87-opencode/stubs -name '*.java') \
  src/main/java/com/llmart/llm/service/OpenCodeUiProviderConfig.java \
  src/main/java/com/llmart/llm/service/OpenCodeLocalRuntime.java \
  src/main/java/com/llmart/llm/service/OpenCodeProxyConfig.java \
  src/main/java/com/llmart/llm/service/OpenCodeNetworkDiagnostics.java \
  src/main/java/com/llmart/llm/service/OpenCodeTokenLedger.java \
  src/main/java/com/llmart/llm/service/OpenCodeExecutionService.java \
  qa/eliya101-ui-provider/MockOpenCodeV2.java \
  qa/eliya113-flow/OpenCodeTaskLifecycleSmoke.java
cat > "$TMP/opencode-mock" <<'MOCK'
#!/bin/sh
if [ "${1:-}" = '--version' ]; then echo '2.2.3'; exit 0; fi
exec "$ELIYA_QA_JAVA" -cp "$ELIYA_QA_CLASSPATH" MockOpenCodeV2 "$@"
MOCK
chmod +x "$TMP/opencode-mock"
export ELIYA_QA_JAVA="$(command -v java)" ELIYA_QA_CLASSPATH="$TMP" \
  ELIYA_QA_MOCK_BINARY="$TMP/opencode-mock" ELIYA_QA_WORKSPACE="$TMP/workspace"
java -cp "$TMP" OpenCodeTaskLifecycleSmoke
