import com.fasterxml.jackson.databind.ObjectMapper;
import com.llmart.llm.dto.ChatMode;
import com.llmart.llm.dto.ChatRequest;
import com.llmart.llm.service.OpenCodeExecutionService;
import com.llmart.llm.service.OpenCodeLocalRuntime;
import com.llmart.llm.service.ProjectService;
import java.lang.reflect.*;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.TimeUnit;

/** One complete simulated agentic task: warm -> admit -> file edit -> completion -> tokens -> cleanup. */
public final class OpenCodeTaskLifecycleSmoke {
    static void check(boolean ok, String error) { if (!ok) throw new AssertionError(error); }
    public static void main(String[] args) throws Exception {
        for (String valid : List.of("2.2.0", "2.2.3", "v2.2.2", "opencode 2.3.0", "2.10.1"))
            check(OpenCodeLocalRuntime.isSupportedVersion(valid), "Rejected supported version " + valid);
        for (String invalid : List.of("1.18.16", "2.0.2", "2.1.99", "2.0", "3.0.0", "unknown", ""))
            check(!OpenCodeLocalRuntime.isSupportedVersion(invalid), "Accepted unsupported version " + invalid);
        System.out.println("PASS: OpenCode 2.2+ minimum gate, older 2.x and invalid releases excluded");
        // The local binary check and /api/info check must use the SAME minimum version.
        var parser=OpenCodeExecutionService.class.getDeclaredMethod("requireVersion",com.fasterxml.jackson.databind.JsonNode.class);
        parser.setAccessible(true);
        ObjectMapper versionJson=new ObjectMapper();
        for (String v : List.of("2.0.2","2.1.99")) {
            try {
                parser.invoke(null,versionJson.readTree("{\"data\":{\"version\":\""+v+"\"}}"));
                throw new AssertionError("Server API incorrectly allowed OpenCode " + v);
            } catch (InvocationTargetException expected) {
                check(expected.getCause().getMessage().contains("2.2"),"Missing minimum version explanation");
            }
        }
        parser.invoke(null,versionJson.readTree("{\"data\":{\"version\":\"2.2.3\"}}"));
        System.out.println("PASS: /api/info rejects unsupported external servers before any task admission");
        Path olderBinary=Files.createTempFile("eliya-older-opencode-", ".sh");
        try {
            Files.writeString(olderBinary,"#!/bin/sh\necho 2.1.99\n");
            olderBinary.toFile().setExecutable(true);
            try {
                new OpenCodeLocalRuntime().findV2(olderBinary.toString());
                throw new AssertionError("Old installed OpenCode 2.1 CLI was permitted");
            } catch (java.io.IOException expected) {
                check(expected.getMessage().contains("2.2"),"CLI rejection should explain upgrade requirement");
            }
        } finally { Files.deleteIfExists(olderBinary); }
        System.out.println("PASS: installed OpenCode 2.1 binary is rejected before process startup");
        Path sandbox=Path.of(System.getenv("ELIYA_QA_WORKSPACE"));
        Files.createDirectories(sandbox);
        System.setProperty("eliya.qa.workspace",sandbox.toString());
        System.setProperty("eliya.opencode.sessionStore",sandbox.resolve("sessions").toString());
        OpenCodeExecutionService service=new OpenCodeExecutionService(new ObjectMapper(),new ProjectService(),
                "opencode","http://127.0.0.1:4096","",System.getenv("ELIYA_QA_MOCK_BINARY"),true);
        try {
            service.initializeOnStartup();
            service.prewarm("https://company.example/v1","agent-model-v1","top-secret-do-not-log");
            long deadline=System.nanoTime()+TimeUnit.SECONDS.toNanos(20);
            while (System.nanoTime()<deadline && !Boolean.TRUE.equals(service.engineInfo().get("autoEligible"))) {
                check(!"unsupported".equals(service.engineInfo().get("status")),"OpenCode unexpectedly unsupported");
                Thread.sleep(100);
            }
            check(Boolean.TRUE.equals(service.engineInfo().get("autoEligible")),"Background initialization never became eligible");
            ChatRequest request=new ChatRequest("demo", "MAKE_FOLDER_AND_FILE create demo folder and hello.txt",
                    List.of(), ChatMode.AGENT,new ChatRequest.Settings("https://company.example/v1","agent-model-v1"));
            Map<String,Object> launched=service.launch(request,null,"top-secret-do-not-log");
            String task=(String)launched.get("id");
            check(task!=null && task.startsWith("oc-"),"OpenCode did not accept task");
            check(Files.readString(sandbox.resolve("demo/hello.txt")).equals("HELLO_ELIYA\n"),"File not actually created");
            String status="running";
            deadline=System.nanoTime()+TimeUnit.SECONDS.toNanos(22);
            while (System.nanoTime()<deadline) {
                Thread.sleep(300);
                status=String.valueOf(service.get(task).get("status"));
                if (!Set.of("running","queued").contains(status)) break;
            }
            Map<String,Object> result=service.get(task);
            check("completed".equals(status),"Task did not close automatically: " + status + " " + result.get("error"));
            check(String.valueOf(result.get("answer")).contains("hello.txt"),"Final answer missing");
            @SuppressWarnings("unchecked") Map<String,Object> report=(Map<String,Object>)result.get("changeReport");
            check(Boolean.TRUE.equals(report.get("filesVerified")),"OpenCode diff not retrieved");
            check(Boolean.TRUE.equals(report.get("workspaceFilesVerified")),"Workspace content not verified");
            check(((Number)report.get("created")).intValue()==1,"Created file not counted");
            @SuppressWarnings("unchecked") Map<String,Object> usage=(Map<String,Object>)result.get("usage");
            check(Boolean.TRUE.equals(usage.get("providerReported")),"Provider token reporting absent");
            check(((Number)usage.get("providerTotalTokens")).intValue()>0,"Token total did not populate");
            check(result.get("finishedAt")!=null && !String.valueOf(result.get("finishedAt")).isBlank(),
                    "No completion timestamp");
            System.out.println("PASS: real local file produced by mock -> verified diff -> status completed -> provider usage visible");
            Process owned=serviceManagedProcess(service);
            deadline=System.nanoTime()+TimeUnit.SECONDS.toNanos(8);
            while (System.nanoTime()<deadline && owned!=null && owned.isAlive()) Thread.sleep(150);
            check(owned!=null && !owned.isAlive(),"OpenCode's completed child kept running with workspace handles");
            // The prewarm replacement is allowed to run, but the previous workspace-holding child must be gone.
            check(Files.deleteIfExists(sandbox.resolve("demo/hello.txt")),"Created file was locked after completion");
            check(Files.deleteIfExists(sandbox.resolve("demo")),"Created folder was locked after completion");
            System.out.println("PASS: completed task releases original managed process and workspace directory is removable");
        } finally { service.shutdown(); }
    }
    static Process serviceManagedProcess(OpenCodeExecutionService service) throws Exception {
        Field f=OpenCodeExecutionService.class.getDeclaredField("managedProcess");f.setAccessible(true);
        return (Process)f.get(service);
    }
}
