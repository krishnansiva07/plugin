import java.nio.file.*;
import java.util.*;
import java.lang.reflect.*;
import com.llmart.llm.service.*;
import com.llmart.llm.dto.*;
import com.fasterxml.jackson.databind.*;

public final class ReferenceAccessSmoke {
    static void expect(boolean value, String message) { if (!value) throw new AssertionError(message); }
    @SuppressWarnings("unchecked")
    static List<Map<String,String>> permissions(Object access) throws Exception {
        Method method=access.getClass().getDeclaredMethod("permissions");
        method.setAccessible(true);
        return (List<Map<String,String>>)method.invoke(access);
    }
    static String value(Object access,String name) throws Exception {
        Method method=access.getClass().getDeclaredMethod(name);method.setAccessible(true);
        return String.valueOf(method.invoke(access));
    }
    static boolean contains(List<Map<String,String>> permissions,String action,String effect) {
        return permissions.stream().anyMatch(p -> action.equals(p.get("action")) && effect.equals(p.get("effect")));
    }
    public static void main(String[] args) throws Exception {
        Path target=Files.createTempDirectory("eliya118-target-");
        Path ref=Files.createTempDirectory("eliya118-ref-");
        Files.writeString(target.resolve("pom.xml"),"<project />");
        Files.writeString(ref.resolve("pom.xml"),"<project />");
        System.setProperty("eliya.qa.workspace.target",target.toString());
        System.setProperty("eliya.qa.workspace.ref",ref.toString());
        String readOnly="Reference [Legacy] (read-only): "+ref;
        String writable="Reference [Legacy] (writable): "+ref;
        PromptResourceResolver resolver=new PromptResourceResolver();
        var ro=resolver.resolve(readOnly,target).resources().stream().filter(r->r.role()==PromptResourceResolver.ResourceRole.REFERENCE).findFirst().orElseThrow();
        var rw=resolver.resolve(writable,target).resources().stream().filter(r->r.role()==PromptResourceResolver.ResourceRole.REFERENCE).findFirst().orElseThrow();
        expect(!ro.writable(),"Default reference incorrectly writable");
        expect(rw.writable() && rw.alias().equals("legacy"),"Named writable reference not resolved");
        expect(resolver.resolve("Reference [Legacy] (writable): "+ref+"\nReference [Legacy] (read-only): "+ref,target).resources().stream().noneMatch(r->r.role()==PromptResourceResolver.ResourceRole.REFERENCE && r.writable()),
            "Later explicit read-only reference must revoke earlier writable label");
        OpenCodeExecutionService service=new OpenCodeExecutionService(new ObjectMapper(),new ProjectService(),
            "legacy","http://127.0.0.1:4096","","opencode",false);
        try {
            Method access=OpenCodeExecutionService.class.getDeclaredMethod("referenceAccess",ChatRequest.class,Path.class);
            access.setAccessible(true);
            ChatRequest.Settings settings=new ChatRequest.Settings("test-model");
            ChatRequest readonlyRequest=new ChatRequest("target","Inspect reference",List.of(),ChatMode.AGENT,settings,
                "conv",List.of("ref"),Map.of("ref","Legacy"),Map.of());
            ChatRequest writableRequest=new ChatRequest("target","Create skills in reference",List.of(),ChatMode.AGENT,settings,
                "conv",List.of("ref"),Map.of("ref","Legacy"),Map.of("ref",true));
            Object read=access.invoke(service,readonlyRequest,target.toRealPath());
            Object write=access.invoke(service,writableRequest,target.toRealPath());
            expect(contains(permissions(read),"external_directory","allow"),"Read-only reference not readable by OpenCode");
            expect(contains(permissions(read),"edit","deny"),"Read-only reference permits edit");
            expect(contains(permissions(write),"edit","allow"),"Writable reference edit not permitted");
            expect(!value(read,"signature").equals(value(write,"signature")),"Reference changes must create a fresh execution session");
            expect(value(write,"promptGuidance").contains(ref.toString()),"Reference path not conveyed to agent");
            expect(value(write,"promptGuidance").contains("writable"),"Write authorization missing from agent context");
            Method snapshot=OpenCodeExecutionService.class.getDeclaredMethod("referenceFileSnapshot",List.class);
            snapshot.setAccessible(true);
            Method changes=OpenCodeExecutionService.class.getDeclaredMethod("referenceFileChanges",Map.class,Map.class);
            changes.setAccessible(true);
            @SuppressWarnings("unchecked") Map<String,?> before=(Map<String,?>)snapshot.invoke(null,List.of(ref.toString()));
            Files.createDirectories(ref.resolve(".agents/skills/migrate"));
            Files.writeString(ref.resolve(".agents/skills/migrate/SKILL.md"),"# Migrated skill\n");
            Files.writeString(ref.resolve("AGENTS.md"),"# Migration agents\n");
            @SuppressWarnings("unchecked") Map<String,?> after=(Map<String,?>)snapshot.invoke(null,List.of(ref.toString()));
            @SuppressWarnings("unchecked") List<?> modified=(List<?>)changes.invoke(null,before,after);
            expect(modified.size()==2,"Writable reference skill/agent edits missing from independent file verification");
            System.out.println("PASS: writable reference skill and agent files detected by bounded filesystem verification");
            System.out.println("PASS: per-reference read/write opt-in, selected aliases, guarded external path grants, permission refresh signature");
        } finally {service.shutdown();}
    }
}
