#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../.."
D="$(mktemp -d)"; trap 'rm -rf "$D"' EXIT
javac --release 17 -d "$D" $(find qa/eliya87-opencode/stubs -name '*.java') \
  src/main/java/com/llmart/llm/service/PromptResourceResolver.java \
  src/main/java/com/llmart/llm/service/WorkspaceRootGuard.java \
  src/main/java/com/llmart/llm/service/ConversationHandoffSelection.java \
  src/main/java/com/llmart/llm/service/OpenCodeUiProviderConfig.java \
  src/main/java/com/llmart/llm/service/OpenCodeLocalRuntime.java \
  src/main/java/com/llmart/llm/service/OpenCodeProxyConfig.java \
  src/main/java/com/llmart/llm/service/OpenCodeNetworkDiagnostics.java \
  src/main/java/com/llmart/llm/service/OpenCodeTokenLedger.java \
  src/main/java/com/llmart/llm/service/OpenCodeExecutionService.java \
  qa/eliya118-reference-access/ReferenceAccessSmoke.java
java -cp "$D" ReferenceAccessSmoke
node --check src/main/resources/static/app.js
