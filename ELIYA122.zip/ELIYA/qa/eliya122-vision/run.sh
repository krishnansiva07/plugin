#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../.."
node --check src/main/resources/static/app.js
python3 - <<'PY'
from pathlib import Path
app=Path('src/main/resources/static/app.js').read_text()
css=Path('src/main/resources/static/app.css').read_text()
context=Path('src/main/java/com/llmart/llm/service/ContextService.java').read_text()
assert "['agentVisionPicker', state.workflowMode === 'execute']" in app
assert "['chatVisionPicker', state.workflowMode === 'analyse']" in app
assert '.mode-bar #agentVisionPicker:not(.hidden)' in css
assert '.mode-bar #chatVisionPicker:not(.hidden)' in css
assert "state.mode === 'chat' ? (state.config.chatVisionModel || '') : (state.config.visionModel || '')" in app
assert "state.mode === 'agent' && images.length && !state.config.visionModel" in app
assert "files = files.filter(file => !String(file.type || '').startsWith('image/'))" not in app
assert 'if (settings.hasDedicatedVisionModel())' in context
assert 'if (evidence.analysedImages() == 0)' in context
assert 'if (imageFiles.isEmpty() && refersToPriorVisual(currentText))' in context
assert 'settings.visionEndpoint()' in Path('src/main/java/com/llmart/llm/service/VisionDocumentService.java').read_text()
print('PASS: UI exposes independent vision fields, image upload/send guard, routed Chat/Agent vision and explicit follow-up')
PY
T="$(mktemp -d)"; trap 'rm -rf "$T"' EXIT
mkdir -p "$T/src/org/springframework/stereotype" "$T/src/com/llmart/llm/service"
cat > "$T/src/org/springframework/stereotype/Service.java" <<'JAVA'
package org.springframework.stereotype; public @interface Service {}
JAVA
cat > "$T/src/com/llmart/llm/service/OpenAiCompatibleClient.java" <<'JAVA'
package com.llmart.llm.service;
import java.util.*;
public class OpenAiCompatibleClient {
 public boolean imageSent=false, incorrectAnswer=false;
 public List<double[]> embed(String k, String u, String m, List<String> s, java.util.function.BooleanSupplier cancel) {return List.of(new double[]{1});}
 public String complete(String k, String u, String m, int t, List<Map<String,Object>> req) {
  if (!(req.get(0).get("content") instanceof List<?> content)) return "OK";
  imageSent=content.stream().anyMatch(part -> part instanceof Map<?,?> p && "image_url".equals(p.get("type")));
  if (!imageSent) throw new AssertionError("Multimodal request missing image_url");
  return incorrectAnswer ? "blue" : "red";
 }
}
JAVA
cat > "$T/src/com/llmart/llm/service/VisionProbeSmoke.java" <<'JAVA'
package com.llmart.llm.service;
public class VisionProbeSmoke {
 public static void main(String[] args) throws Exception {
  var stub = new OpenAiCompatibleClient(); var probe=new ModelProbeService(stub);
  var result=probe.probe("key","https://provider","vision-id","vision");
  if (!stub.imageSent || !result.get("capability").toString().contains("red square")) throw new AssertionError(result);
  stub.incorrectAnswer=true;
  try {probe.probe("key","https://provider","vision-id","vision");throw new AssertionError("wrong image answer was accepted");}
  catch (IllegalStateException expected) {if(!expected.getMessage().contains("unexpected answer"))throw expected;}
  System.out.println("PASS: vision probe actually sends image content, checks visual answer and fails closed");
 }
}
JAVA
javac --release 17 -d "$T/out" "$T/src/org/springframework/stereotype/Service.java" \
  "$T/src/com/llmart/llm/service/OpenAiCompatibleClient.java" \
  "$T/src/com/llmart/llm/service/VisionProbeSmoke.java" \
  src/main/java/com/llmart/llm/service/ModelProbeService.java
java -Djava.awt.headless=true -cp "$T/out" com.llmart.llm.service.VisionProbeSmoke
