package com.llmart.llm.service;

import com.llmart.llm.dto.ProjectDto;
import java.nio.file.*;
import java.time.Instant;
import java.util.Map;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;

/** A running scan races with external folder deletion and an explicit Rescan. */
public class RescanQueueSmoke {
    static void check(boolean condition, String detail) {
        if (!condition) throw new AssertionError(detail);
    }
    static class PausedIndex extends WorkspaceRetrievalIndexService {
        final CountDownLatch firstSnapshot = new CountDownLatch(1);
        final CountDownLatch releaseFirst = new CountDownLatch(1);
        final AtomicInteger calls = new AtomicInteger();
        PausedIndex() { super(new OpenAiCompatibleClient()); }
        @Override public IndexStats warmRoot(String id, Path path) {
            IndexStats stats = super.warmRoot(id, path);
            if (calls.incrementAndGet() == 1) {
                firstSnapshot.countDown();
                try {
                    if (!releaseFirst.await(8, TimeUnit.SECONDS)) throw new IllegalStateException("test timeout");
                } catch (InterruptedException interruption) {
                    Thread.currentThread().interrupt();
                    throw new IllegalStateException(interruption);
                }
            }
            return stats;
        }
    }
    public static void main(String[] ignored) throws Exception {
        Path root = Files.createTempDirectory("eliya-rescan-queue-");
        Path original = root.resolve("old-agent/LegacyAgent.java");
        Files.createDirectories(original.getParent());
        Files.writeString(original, "public class LegacyAgent { void legacyWork() {} }");
        ProjectDto project = new ProjectDto("queue-test", "conversation", "app", 0, 0, 0,
                root.toString(), true, Instant.now(), Instant.now());
        PausedIndex retrieval = new PausedIndex();
        LocalProjectIndexService jobs = new LocalProjectIndexService(retrieval);
        try {
            jobs.request(project, false);
            check(retrieval.firstSnapshot.await(8, TimeUnit.SECONDS), "first scan should begin");
            // First scan has completed its filesystem traversal but cannot publish job completion.
            Files.delete(original);
            Files.delete(original.getParent());
            Files.createDirectories(root.resolve("new-agent"));
            Files.writeString(root.resolve("new-agent/NewAgent.java"),
                    "public class NewAgent { void currentWork() {} }");
            Map<String,Object> queued = jobs.request(project, true);
            check("queued".equals(queued.get("phase")), "force Rescan while indexing must enqueue another pass");
            check(retrieval.isRescanPending(project.id(), root), "new snapshot must fence old evidence");
            check(retrieval.retrieveCachedRoot(project.id(), root, "LegacyAgent", 6, 4000)
                    .contains("RESCAN IN PROGRESS"), "Chat must not see stale files while queued");
            retrieval.releaseFirst.countDown();
            long until = System.nanoTime() + TimeUnit.SECONDS.toNanos(12);
            while (!"completed".equals(jobs.status(project).get("phase")) && System.nanoTime() < until)
                Thread.sleep(30);
            Map<String,Object> done = jobs.status(project);
            check("completed".equals(done.get("phase")), "second scan finishes: " + done);
            check(retrieval.calls.get() == 2, "both initial and follow-up scans must run");
            check(!retrieval.isRescanPending(project.id(), root), "fresh index is accessible after scan completion");
            String overview = retrieval.retrieveCachedRoot(project.id(), root,
                    "show me the current workspace structure", 8, 6_000);
            check(overview.contains("new-agent/NewAgent.java"), "new folder must appear: " + overview);
            check(!overview.contains("old-agent/LegacyAgent.java"), "deleted folder must not be resurrected");
            check(Integer.valueOf(1).equals(done.get("fileCount")), "fresh count must be one: " + done);
            System.out.println("PASS: Rescan queued during active scan, freshness fence, deletion eviction and new-file discovery");
        } finally {
            retrieval.releaseFirst.countDown();
            jobs.shutdown();
        }
    }
}
