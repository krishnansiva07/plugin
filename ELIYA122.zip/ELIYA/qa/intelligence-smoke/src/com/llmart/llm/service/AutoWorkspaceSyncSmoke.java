package com.llmart.llm.service;

import com.llmart.llm.dto.ProjectDto;
import java.nio.file.*;
import java.time.Instant;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.BooleanSupplier;

/** End-to-end OS WatchService -> queued incremental index -> fresh Chat retrieval. */
public class AutoWorkspaceSyncSmoke {
    static void check(boolean pass, String message) { if (!pass) throw new AssertionError(message); }
    static void until(BooleanSupplier done, String description) throws InterruptedException {
        long deadline = System.nanoTime() + TimeUnit.SECONDS.toNanos(12);
        while (System.nanoTime() < deadline) {
            if (done.getAsBoolean()) return;
            Thread.sleep(90);
        }
        throw new AssertionError("Timed out: " + description);
    }
    static String inventory(WorkspaceRetrievalIndexService index, ProjectDto project, Path root) {
        return index.retrieveCachedRoot(project.id(), root, "show current workspace structure", 20, 20_000);
    }
    public static void main(String[] ignored) throws Exception {
        Path root = Files.createTempDirectory("eliya-auto-sync-");
        ProjectDto project = new ProjectDto("auto-sync-test", "conversation-1", "app", 0, 0, 0,
                root.toString(), true, Instant.now(), Instant.now());
        WorkspaceRetrievalIndexService index = new WorkspaceRetrievalIndexService(new OpenAiCompatibleClient());
        LocalProjectIndexService jobs = new LocalProjectIndexService(index);
        AtomicInteger retireCalls = new AtomicInteger();
        jobs.setSessionRetirer(id -> { if (project.id().equals(id)) retireCalls.incrementAndGet(); });
        try {
            jobs.request(project, false);
            until(() -> "completed".equals(jobs.status(project).get("phase")), "initial index");
            until(() -> "watching".equals(jobs.status(project).get("watchState")), "watch registered");

            // Newly created folder populated immediately, perhaps before a subdirectory watch is installed.
            Path created = root.resolve("manual/new-agent/NewAgent.java");
            Files.createDirectories(created.getParent());
            Files.writeString(created, "public class NewAgent { void brandNewAction() {} }");
            until(() -> inventory(index, project, root).contains("manual/new-agent/NewAgent.java"), "manual created file discovered");
            check(Integer.valueOf(1).equals(jobs.status(project).get("fileCount")), "file count syncs after create");
            until(() -> retireCalls.get() > 0, "OpenCode historical session retired");

            Files.writeString(created, "public class NewAgent { void updatedAction() {} }");
            until(() -> index.retrieveCachedRoot(project.id(), root, "updatedAction", 5, 6000)
                    .contains("updatedAction"), "modified contents updated without Rescan");

            // Folder rename: the old directory must vanish; the new tree must become indexed.
            Files.move(root.resolve("manual/new-agent"), root.resolve("manual/renamed-agent"));
            until(() -> inventory(index, project, root).contains("manual/renamed-agent/NewAgent.java"), "renamed directory discovered");
            until(() -> !inventory(index, project, root).contains("manual/new-agent/NewAgent.java"), "renamed old path evicted");

            Files.delete(root.resolve("manual/renamed-agent/NewAgent.java"));
            Files.delete(root.resolve("manual/renamed-agent"));
            until(() -> Integer.valueOf(0).equals(jobs.status(project).get("fileCount")), "deleted file evicted");
            check(!inventory(index, project, root).contains("manual/renamed-agent/NewAgent.java"), "deleted folder not present in retrieval");
            check(!index.isRescanPending(project.id(), root), "automatic refresh releases freshness fence");
            Map<String,Object> finalStatus = jobs.status(project);
            check(finalStatus.containsKey("lastAutoSyncAt"), "auto-index timestamp available");
            check("watching".equals(finalStatus.get("watchState")), "watch remains active");
            // Reconciliation without filesystem changes MUST NOT retire an otherwise valid model session.
            int beforeReconcile = retireCalls.get();
            String oldSnapshotDate = index.cachedStats(project.id(), root).generatedAt();
            java.lang.reflect.Method reconcile = LocalProjectIndexService.class.getDeclaredMethod("reconcile", ProjectDto.class);
            reconcile.setAccessible(true);
            Thread.sleep(50);
            reconcile.invoke(jobs, project);
            until(() -> !index.cachedStats(project.id(), root).generatedAt().equals(oldSnapshotDate), "periodic reconciliation ran");
            check(beforeReconcile == retireCalls.get(), "unchanged workspace must preserve existing OpenCode session");
            System.out.println("PASS: OS create/modify/rename/delete, fresh Chat retrieval, auto-session retirement, unchanged reconciliation");
        } finally { jobs.shutdown(); }

        // Simulates providers/network mounts which do not supply WatchService events.
        // A reconciliation still picks up the change and only retires old provider
        // context if the actual indexed file manifest changed.
        System.setProperty("eliya.index.watch.enabled", "false");
        Path fallbackRoot = Files.createTempDirectory("eliya-polling-fallback-");
        ProjectDto fallbackProject = new ProjectDto("fallback-test", "conversation-2", "network share", 0, 0, 0,
                fallbackRoot.toString(), true, Instant.now(), Instant.now());
        WorkspaceRetrievalIndexService fallbackIndex = new WorkspaceRetrievalIndexService(new OpenAiCompatibleClient());
        LocalProjectIndexService fallbackJobs = new LocalProjectIndexService(fallbackIndex);
        AtomicInteger fallbackRetires = new AtomicInteger();
        fallbackJobs.setSessionRetirer(id -> fallbackRetires.incrementAndGet());
        try {
            fallbackJobs.request(fallbackProject, false);
            until(() -> "completed".equals(fallbackJobs.status(fallbackProject).get("phase")), "fallback initial index");
            check("disabled".equals(fallbackJobs.status(fallbackProject).get("watchState")), "watcher disabled for fallback test");
            Files.writeString(fallbackRoot.resolve("Recovered.java"), "class Recovered { void liveMethod() {} }");
            check(!inventory(fallbackIndex, fallbackProject, fallbackRoot).contains("Recovered.java"),
                    "file absent before missed event is reconciled");
            java.lang.reflect.Method reconcile = LocalProjectIndexService.class.getDeclaredMethod("reconcile", ProjectDto.class);
            reconcile.setAccessible(true);
            reconcile.invoke(fallbackJobs, fallbackProject);
            until(() -> inventory(fallbackIndex, fallbackProject, fallbackRoot).contains("Recovered.java"),
                    "missed file recovered by reconciliation");
            check(fallbackRetires.get() == 1, "newly recovered file should retire stale OpenCode context once");
            reconcile.invoke(fallbackJobs, fallbackProject);
            String last = fallbackIndex.cachedStats(fallbackProject.id(), fallbackRoot).generatedAt();
            until(() -> !fallbackIndex.cachedStats(fallbackProject.id(), fallbackRoot).generatedAt().equals(last),
                    "unchanged second fallback scan completes");
            check(fallbackRetires.get() == 1, "unchanged fallback pass must not retire provider context");
            System.out.println("PASS: polling fallback recovers missed filesystem events without unnecessary session retirement");
        } finally { fallbackJobs.shutdown(); System.clearProperty("eliya.index.watch.enabled"); }
    }
}
