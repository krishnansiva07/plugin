package com.llmart.llm.service;
import java.nio.file.*;
import java.util.*;
import com.llmart.llm.dto.ChatSettings;
public class IntelligenceSmoke {
 private static void check(boolean pass, String message) { if (!pass) throw new AssertionError(message); }
 public static void main(String[] argv) throws Exception {
  Path home = Files.createTempDirectory("eliya-intelligence-home-");
  Path root = Files.createTempDirectory("eliya-intelligence-project-");
  System.setProperty("app.data-dir", home.toString());
  Files.createDirectories(root.resolve("src/pages"));
  Files.createDirectories(root.resolve("src/tests"));
  Files.writeString(root.resolve("src/pages/LoginPage.java"),
      "package pages; public class LoginPage { private String apiKey = \"SUPERSECRET123\"; public boolean verifyCredentials(String user) { return user != null; } }");
  Files.writeString(root.resolve("src/tests/LoginTest.java"),
      "package tests; import pages.LoginPage; public class LoginTest { LoginPage page = new LoginPage(); }");
  Files.writeString(root.resolve("src/pages/login.page.ts"),
      "export class LoginPage {\n  async login(user: string) { return user; }\n}");
  Files.writeString(root.resolve("src/tests/login.spec.ts"),
      "import {LoginPage} from '../pages/login.page'; test('login', async () => {});");
  Files.writeString(root.resolve("src/tests/login.feature"),
      "Feature: Login\n Scenario: Valid login\n Given I enter valid credentials\n When I click login\n Then I reach the dashboard");
  Files.writeString(root.resolve("src/tests/LoginSteps.java"),
      "package tests; import io.cucumber.java.en.Given; import io.cucumber.java.en.When;" +
      "public class LoginSteps { @Given(\"I enter valid credentials\") public void credentials() {} " +
      "@When(\"I click login\") public void clickLogin() {} }");
  OpenAiCompatibleClient llm = new OpenAiCompatibleClient();
  WorkspaceRetrievalIndexService index = new WorkspaceRetrievalIndexService(llm);
  var ws = AgentWorkspaceService.Workspace.forIndex("smoke", root);
  check(index.refresh(ws).indexedFiles() == 6, "six code and feature files indexed");
  String overview = index.retrieveCachedRoot("smoke", root, "Can you check what is there in the workspace?", 8, 10_000);
  check(overview.contains("Indexed top-level modules") && overview.contains("src: 6 files")
          && overview.contains("LoginPage.java") && overview.contains("Index coverage:"),
          "natural-language workspace inventory uses cached index and shows module/source evidence");
  String symbols = index.retrieve(ws, "verifyCredentials", 5, 6000);
  check(symbols.contains("LoginPage.java") && symbols.contains("method:verifyCredentials"), "Java AST method indexed and searchable");
  check(index.retrieve(ws, "login(user", 5, 6000).contains("method:login"), "TypeScript method declared and indexed");
  String impact = index.impactReport(ws, "LoginPage.java verifyCredentials", 5000);
  check(impact.contains("LoginTest.java") && impact.contains("open the CURRENT"), "Java import graph and evidence requirement");
  String tsImpact = index.impactReport(ws, "login.page.ts", 5000);
  check(tsImpact.contains("login.spec.ts"), "TypeScript relative import graph");
  String steps = index.impactReport(ws, "LoginSteps.java", 5000);
  check(steps.contains("login.feature"), "Cucumber feature maps to annotated Java step definitions");
  var settings = new ChatSettings("http://example.invalid", "stub-embedding", true);
  check(index.retrieveHybrid(ws, "verifyCredentials", 5, 6_000, "key", settings, () -> false).contains("LoginPage.java"), "hybrid retrieves code");
  check(llm.mostRecentInputs.stream().noneMatch(v -> v.contains("SUPERSECRET123")),
          "credential-shaped values redacted before embedding");
  int first = llm.embeddedInputs;
  index.retrieveHybrid(ws, "verifyCredentials?", 5, 6_000, "key", settings, () -> false);
  check(llm.embeddedInputs - first == 1, "only new query embedded: candidate vectors reused");
  llm.fail = true;
  check(index.retrieveHybrid(ws, "verifyCredentials fallback", 5, 6000, "key", settings, () -> false).contains("LoginPage.java"),
      "embedding provider failure falls back to local retrieval");
  var restarted = new WorkspaceRetrievalIndexService(new OpenAiCompatibleClient());
  check(restarted.refresh(ws).indexedFiles() == 6, "index checkpoint reused after restart");
  var secondLlm = new OpenAiCompatibleClient();
  var second = new WorkspaceRetrievalIndexService(secondLlm);
  second.refresh(ws);
  second.retrieveHybrid(ws, "verifyCredentials after restart", 5, 6_000, "key", settings, () -> false);
  check(secondLlm.embeddedInputs == 1, "document vectors persisted after restart");
  check(second.retrieveHybrid(ws, "authentication", 5, 6_000, "key", settings, () -> false).contains("LoginPage.java"),
      "persisted semantic neighbors can be retrieved without keyword matches");
  Files.writeString(root.resolve("src/pages/LoginPage.java"),
      "package pages; public class LoginPage { public boolean checkNewCredentials(String user) { return user != null; } }");
  second.refreshPaths(ws, List.of("src/pages/LoginPage.java"));
  check(second.retrieve(ws, "checkNewCredentials", 5, 6_000).contains("method:checkNewCredentials"), "incremental symbol updates");
  check(!second.impactReport(ws, "checkNewCredentials", 3_000).contains("method:verifyCredentials"), "old symbols evicted");
  second.retrieveHybrid(ws, "checkNewCredentials", 5, 6_000, "key", settings, () -> false);
  check(secondLlm.embeddedInputs > 1, "changed file gets a fresh vector");
  Files.delete(root.resolve("src/tests/LoginTest.java"));
  second.refreshPaths(ws, List.of("src/tests/LoginTest.java"));
  check(!second.impactReport(ws, "LoginTest.java", 3_000).contains("Candidate: src/tests/LoginTest.java"), "deleted file removed from graph/index");
  Files.writeString(root.resolve(".env"), "API_KEY=should-never-leak");
  check(second.refresh(ws).indexedFiles() == 5, "secrets excluded from index");
  check(!second.retrieve(ws, "should-never-leak", 5, 6000).contains("should-never-leak"), "no secret retrieval");
  // External deletion must not remain visible in a cached workspace overview,
  // even before a manual rescan. A manual rescan must evict indexed evidence.
  Path obsolete = root.resolve("src/obsolete/OldAgent.java");
  Files.createDirectories(obsolete.getParent());
  Files.writeString(obsolete, "public class OldAgent { void obsoleteAction() {} }");
  second.refresh(ws);
  check(second.retrieveCachedRoot("smoke", root, "show me the workspace structure", 8, 10_000)
          .contains("src/obsolete/OldAgent.java"), "folder is initially indexed");
  second.retrieveHybrid(ws, "obsoleteAction", 6, 6_000, "key", settings, () -> false);
  Files.delete(obsolete);
  Files.delete(obsolete.getParent());
  String liveView = second.retrieveCachedRoot("smoke", root, "show me the workspace structure", 8, 10_000);
  check(!liveView.contains("src/obsolete/OldAgent.java"), "deleted folder absent from live overview before rescan");
  check(!second.retrieveHybrid(ws, "obsoleteAction", 6, 6_000, "key", settings, () -> false)
          .contains("src/obsolete/OldAgent.java"), "semantic cached answer must not resurrect a deleted file");
  second.markRescanPending("smoke", root);
  check(second.retrieveCachedRoot("smoke", root, "OldAgent", 6, 6000)
          .contains("RESCAN IN PROGRESS"), "while reindexing, previous evidence is fenced");
  second.refresh(ws);
  second.finishRescan("smoke", root);
  check(!second.retrieveCachedRoot("smoke", root, "show me the workspace structure", 8, 10_000)
          .contains("src/obsolete/OldAgent.java"), "rescan removes obsolete folder permanently");
  check(!second.impactReport(ws, "OldAgent.java", 3000)
          .contains("Candidate: src/obsolete/OldAgent.java"), "removed file not suggested as impact candidate");
  Path agentFolder = root.resolve("src/byAgent/DeletedClass.java");
  Files.createDirectories(agentFolder.getParent());
  Files.writeString(agentFolder, "public class DeletedClass { void removedByAgent() {} }");
  second.refreshPaths(ws, List.of("src/byAgent/DeletedClass.java"));
  check(second.retrieve(ws, "removedByAgent", 5, 4000).contains("DeletedClass.java"),
          "agent created file is visible by incremental update");
  Files.delete(agentFolder);
  Files.delete(agentFolder.getParent());
  second.refreshPaths(ws, List.of("src/byAgent"));
  check(!second.impactReport(ws, "DeletedClass.java", 3000)
          .contains("Candidate: src/byAgent/DeletedClass.java"),
          "folder-level delete evicts indexed descendants without walking workspace");
  Files.writeString(root.resolve("src/NewAgent.java"), "public class NewAgent { void latestAction() {} }");
  second.refresh(ws);
  check(second.retrieve(ws, "latestAction", 5, 4000).contains("NewAgent.java"),
          "rescan discovers newly created files");
  Files.delete(root.resolve("src/NewAgent.java"));
  second.refresh(ws);
  Files.createDirectories(root.resolve("src/fixtures"));
  for (int i = 0; i < 1094; i++) Files.writeString(root.resolve("src/fixtures/sample" + i + ".txt"),
          "Test fixture " + i);
  check(second.refresh(ws).indexedFiles() == 1099, "1099 file incremental workspace scenario");
  System.out.println("PASS: 1099-file workspace, Java AST, TS imports, Cucumber steps, impact checks, Fallback retrieval, vector persistence, incremental updates, secret exclusions");
 }
}
