#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../.."
T="$(mktemp -d)"
trap 'rm -rf "$T"' EXIT
javac -d "$T" src/main/java/com/llmart/llm/service/ConversationHandoffSelection.java \
  qa/eliya121-handoff-hardening/HandoffHardeningSmoke.java
java -cp "$T" com.llmart.llm.service.HandoffHardeningSmoke
