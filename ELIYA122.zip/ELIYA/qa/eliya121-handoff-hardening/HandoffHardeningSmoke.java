package com.llmart.llm.service;

import java.util.List;

/** Standalone Java 17 contract checks; intentionally no Maven or network required. */
public final class HandoffHardeningSmoke {
    private static void check(boolean ok, String message) { if (!ok) throw new AssertionError(message); }
    public static void main(String[] args) {
        String plan = "# Migration plan\n1. Create Playwright Cucumber TypeScript.\n" +
                "2. Reuse feature files.\n3. Configure parallel browser execution.";
        var messages = List.of(
                new ConversationHandoffSelection.Turn(101, "user", "Migrate our Java Selenium Cucumber project", List.of("initial.zip"), null),
                new ConversationHandoffSelection.Turn(102, "assistant", plan, List.of(), "chat"),
                new ConversationHandoffSelection.Turn(103, "user", "Use installed Chrome, never download browsers", List.of(), null),
                new ConversationHandoffSelection.Turn(104, "assistant", "Chrome executable path should be configurable.", List.of(), "chat"),
                new ConversationHandoffSelection.Turn(105, "user", "Also take this specification", List.of("later-spec.docx"), null),
                new ConversationHandoffSelection.Turn(106, "assistant", "Agent execution completed.", List.of(), "agent"),
                new ConversationHandoffSelection.Turn(107, "user", "Implement the agreed analysis from conversation message #102 in the currently selected workspace.", List.of(), null)
        );
        var selected = ConversationHandoffSelection.select(messages, 107, messages.get(6).content()).orElseThrow();
        check(selected.answerId() == 102, "must select the pinned analysis, not the more recent agent response");
        check(selected.attachments().containsAll(List.of("initial.zip", "later-spec.docx")),
                "original AND follow-up attachments must survive");
        check(selected.nearby().stream().anyMatch(x -> x.id() == 103), "later browser constraint must be retained");
        check(selected.nearby().stream().anyMatch(x -> x.id() == 105), "later document requirement must be retained");
        check(selected.plan(), "selected proposal must still be recognized as an implementation plan");
        check(ConversationHandoffSelection.select(messages,107,
                "Implement the agreed analysis from conversation message #106").isEmpty(),
                "must not treat previous agent result as a new analysis source");
        check(ConversationHandoffSelection.select(messages,107,
                "Implement the agreed analysis from conversation message #999").isEmpty(),
                "nonexistent/foreign source must be rejected");
        check(ConversationHandoffSelection.select(messages,107,"Build an unrelated API").isEmpty(),
                "independent task must not import an old plan");
        System.out.println("PASS: pinned Analyse source, newest user constraints and attachments, Agent-source protection");
    }
}
