package com.llmart.llm.service;
import java.util.List;

public final class ExplicitHandoffSmoke {
    private static void check(boolean ok, String why) {
        if (!ok) throw new AssertionError(why);
    }
    public static void main(String[] args) {
        var turns = List.of(
                new ConversationHandoffSelection.Turn(11,"user","Investigate the existing Selenium framework",List.of("spec-doc")),
                new ConversationHandoffSelection.Turn(12,"assistant","### Proposed approach\n1. Build TypeScript Playwright Cucumber framework.\n2. Migrate the existing feature files without changing scenarios.\n3. Verify browser launch and run tests.",List.of()),
                new ConversationHandoffSelection.Turn(13,"user","What about parallel execution?",List.of()),
                new ConversationHandoffSelection.Turn(14,"assistant","Parallel execution should use isolated contexts; this follow-up is not the original proposal.",List.of()),
                new ConversationHandoffSelection.Turn(15,"user","Implement the agreed analysis from conversation message #12 in the currently selected workspace.",List.of())
        );
        String handoff="Implement the agreed analysis from conversation message #12 in the currently selected workspace.";
        var packet=ConversationHandoffSelection.select(turns,15,handoff).orElseThrow();
        check(packet.answerId()==12,"must select exact source, not most recent assistant");
        check(packet.requirementId()==11,"must keep original initiating requirement");
        check(packet.attachments().contains("spec-doc"),"must retain original attachment references");
        check(packet.answer().contains("Migrate the existing feature"),"must preserve precise source content");
        check(packet.nearby().stream().anyMatch(t -> t.id()==13),"later user refinements must be retained");
        check(ConversationHandoffSelection.explicitSourceId(handoff).orElseThrow()==12,"source ID must be parsed");
        check(ConversationHandoffSelection.select(turns,15,handoff.replace("#12","#99")).isEmpty(),
                "missing or foreign conversation message must not use latest source");
        check(ConversationHandoffSelection.select(turns,15,handoff.replace("#12","#15")).isEmpty(),
                "current user cannot be an assistant source");
        check(ConversationHandoffSelection.select(turns,15,handoff.replace("#12","#14")).orElseThrow().answerId()==14,
                "explicitly selected follow-up source may be used");
        check(ConversationHandoffSelection.select(turns,15,"Create an unrelated API").isEmpty(),
                "independent instruction must not inherit source");
        System.out.println("PASS ELIYA120: exact saved-source handoff, original requirement, references, no cross-message fallback");
    }
}
