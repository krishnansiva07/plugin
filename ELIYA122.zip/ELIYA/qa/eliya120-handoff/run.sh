#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../.."
T=$(mktemp -d)
trap 'rm -rf "$T"' EXIT
javac --release 17 -d "$T" \
  src/main/java/com/llmart/llm/service/ConversationHandoffSelection.java \
  qa/eliya120-handoff/ExplicitHandoffSmoke.java
java -cp "$T" com.llmart.llm.service.ExplicitHandoffSmoke
