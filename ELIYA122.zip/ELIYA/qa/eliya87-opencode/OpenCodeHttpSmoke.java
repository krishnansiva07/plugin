import com.llmart.llm.service.OpenCodeExecutionService;
import com.llmart.llm.service.ProjectService;
import com.llmart.llm.dto.ChatMode;
import com.llmart.llm.dto.ChatRequest;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sun.net.httpserver.HttpServer;
import java.net.*;import java.nio.file.*;import java.util.*;import java.util.concurrent.*;import java.util.concurrent.atomic.*;

public class OpenCodeHttpSmoke {
 static void check(boolean value,String message){if(!value)throw new AssertionError(message);}
 static void reply(com.sun.net.httpserver.HttpExchange e, int code,String response) throws java.io.IOException {
   byte[] bytes=response.getBytes(java.nio.charset.StandardCharsets.UTF_8);
   e.getResponseHeaders().set("Content-Type", "application/json");e.sendResponseHeaders(code,bytes.length);
   try(var out=e.getResponseBody()){out.write(bytes);}
 }
 public static void main(String[] args)throws Exception {
   Path temp=Files.createTempDirectory("eliya87-mock-");
   System.setProperty("eliya.opencode.sessionStore",temp.toString());
   Path workspace = Files.createTempDirectory("eliya87-project-");
   System.setProperty("eliya.qa.workspace", workspace.toString());
   Files.writeString(workspace.resolve("README.md"), "Task completed\n");
   HttpServer server=HttpServer.create(new InetSocketAddress("127.0.0.1",0),0);
   AtomicReference<String> createBody=new AtomicReference<>("");
   AtomicReference<String> promptBody=new AtomicReference<>("");
   AtomicInteger interruptions=new AtomicInteger();
   CountDownLatch submitted=new CountDownLatch(1);
   String auth="Basic "+Base64.getEncoder().encodeToString("opencode:local-secret-for-tests".getBytes());
   server.createContext("/api/", e->{
     try{
       check(auth.equals(e.getRequestHeaders().getFirst("Authorization")),"basic authentication missing");
       String path=e.getRequestURI().getPath();
       if("/api/info".equals(path))reply(e,200,"{\"data\":{\"version\":\"2.2.2\"}}");
       else if("/api/model/default".equals(path)) reply(e,200,"{\"data\":{\"id\":\"model_ready\"}}");
       else if("/api/session".equals(path)) {
         createBody.set(new String(e.getRequestBody().readAllBytes()));
         reply(e,200,"{\"data\":{\"id\":\"ses_mock_17\"}}");
       } else if(path.endsWith("/prompt")){
         promptBody.set(new String(e.getRequestBody().readAllBytes()));
         reply(e,200,"{\"data\":{\"id\":\"user_1\"}}");submitted.countDown();
       } else if(path.endsWith("/log")){
         e.getResponseHeaders().set("Content-Type","text/event-stream");
         e.sendResponseHeaders(200,0);
         try(var output=e.getResponseBody()){
           if(submitted.await(3,TimeUnit.SECONDS)){
             output.write(("event: session.tool.success\ndata: {\"type\":\"session.tool.success\",\"properties\":{}}\n\n"+
                      "event: session.execution.succeeded\ndata: {\"type\":\"session.execution.succeeded\",\"properties\":{}}\n\n").getBytes());
             output.flush();
           }
         }
       } else if(path.endsWith("/interrupt")) {interruptions.incrementAndGet();reply(e,200,"{\"interrupted\":true}");}
       else if(path.endsWith("/message"))reply(e,200,"{\"data\":[{\"id\":\"asst_1\",\"type\":\"assistant\",\"content\":[{\"type\":\"text\",\"text\":\"Task completed\"}]},{\"id\":\"user_1\",\"type\":\"user\",\"text\":\"Create README.md\"}]}");
       else if(path.endsWith("/diff"))reply(e,200,"{\"data\":[{\"file\":\"README.md\",\"status\":\"added\",\"additions\":1,\"deletions\":0,\"patch\":\"+Task completed\"}]}");
       else reply(e,404,"{}");
     }catch(Throwable t){t.printStackTrace();try{reply(e,500,"{}");}catch(Exception ignored){}}
   });
   ExecutorService mockPool=Executors.newCachedThreadPool(r -> { Thread t=new Thread(r,"opencode-mock");t.setDaemon(true);return t; });
   server.setExecutor(mockPool); server.start();
   try{
     OpenCodeExecutionService service=new OpenCodeExecutionService(new ObjectMapper(),new ProjectService(),
       "opencode","http://127.0.0.1:"+server.getAddress().getPort(),"local-secret-for-tests","opencode",false);
     check(Boolean.TRUE.equals(service.engineInfo().get("connected")),"health check failed");
     ChatRequest request=new ChatRequest("proj1","Create README.md",List.of(),ChatMode.AGENT,
           new ChatRequest.Settings("user-selected-model"));
     check(service.accepts(request),"execute should be routed to OpenCode");
     check(!service.accepts(new ChatRequest("proj1","Use Jira MCP",List.of(),ChatMode.AGENT,request.settings())),"MCP must retain ELIYA routing");
     check(!service.accepts(new ChatRequest("proj1","test",List.of("file1"),ChatMode.AGENT,request.settings())),"attachments must retain ELIYA routing");
     Map<String,Object> started=service.launch(request,null);
     String id=String.valueOf(started.get("id"));
     check(id.startsWith("oc-"),"locally namespaced session");
     check(createBody.get().contains(workspace.toString()),"workspace not sent to remote engine");
     check(createBody.get().contains("\"external_directory\""),"external workspace permission gate absent");
     check(createBody.get().contains("\"agent\":\"build\""),"Execute must select writable Build agent even if Plan is default");
     check(promptBody.get().contains("Create README.md"),"prompt not submitted");
     boolean done=false;
     for(int i=0;i<100;i++) {
       if("completed".equals(service.get(id).get("status"))) {done=true;break;}
       Thread.sleep(20);
     }
     check(done,"OpenCode SSE success not relayed");
     check(service.activity(id,null,50).get("events") instanceof java.util.List,"activity history unavailable");
     service.cancel(id);
     check(interruptions.get()==0,"Completed execution must not be interrupted or changed after success");
     check(Files.exists(temp.resolve(id+".json")),"session reference was not persisted");
     service.shutdown();
     System.out.println("PASS: OpenCode 2 mock HTTP health, launch, workspace policy, MCP/attachment routing, event relay, persistence and interrupt");
   } finally {server.stop(0);mockPool.shutdownNow();}
 }
}
