package com.llmart.llm.service;
public class ProjectService {
 public void requireConversation(String id,String conversationId){}
 public Project require(String id){return new Project(id);}
 public static class Project {
  private final String id;
  public Project(String id){this.id=id;}
  public boolean hasLocalPath(){return true;}
  public String getLocalPath(){return System.getProperty("eliya.qa.workspace."+id,
    System.getProperty("eliya.qa.workspace", "/tmp"));}
 }
}
