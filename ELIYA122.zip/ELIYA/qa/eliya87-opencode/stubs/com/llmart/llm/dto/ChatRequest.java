package com.llmart.llm.dto;
import java.util.*;
public record ChatRequest(String projectId, String message, List<String> attachmentIds,
                          ChatMode chatMode, Settings settings, String conversationId,
                          List<String> referenceProjectIds, Map<String,String> referenceProjectNames,
                          Map<String,Boolean> referenceProjectWriteAccess) {
  public ChatRequest(String projectId, String message, List<String> attachments, ChatMode mode, Settings settings) {
    this(projectId,message,attachments,mode,settings,null,List.of(),Map.of(),Map.of());
  }
  public boolean isRegenerate(){return false;}
  public boolean referenceWritable(String id){return referenceProjectIds != null && referenceProjectIds.contains(id)
    && referenceProjectWriteAccess != null && Boolean.TRUE.equals(referenceProjectWriteAccess.get(id));}
  public record Settings(String baseUrl,String model) {
    public Settings(String model){this("https://company.example/v1",model);}
  }
}
