package com.llmart.llm.service;
import java.util.Optional;
/** Test-only fixture; production uses the real conversation-bound handoff service. */
public class ConversationHandoffService {
  public Optional<ConversationHandoffSelection.Packet> select(String conversationId,String prompt) {
    return Optional.empty();
  }
}
