import com.fasterxml.jackson.databind.ObjectMapper;
import com.llmart.llm.service.OpenCodeExecutionService;
import com.llmart.llm.service.OpenCodeTokenLedger;
import com.sun.net.httpserver.HttpServer;
import java.lang.reflect.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.*;

/** Actual localhost HTTP event-stream integration without any model credentials. */
public class OpenCode117LiveStreamSmoke {
  static void verify(boolean p,String why) {if(!p)throw new AssertionError(why);}
  @SuppressWarnings("unchecked") public static void main(String[] args) throws Exception {
    HttpServer server=HttpServer.create(new InetSocketAddress("127.0.0.1",0),0);
    CountDownLatch received=new CountDownLatch(1);
    server.createContext("/api/event", exchange -> {
      verify("GET".equals(exchange.getRequestMethod()),"Event source must be GET");
      verify(exchange.getRequestURI().getRawQuery().contains("session.usage.updated"),"Usage stream was not subscribed");
      exchange.getResponseHeaders().set("Content-Type","text/event-stream");
      exchange.sendResponseHeaders(200,0);
      try(var out=exchange.getResponseBody()) {
        String other="data: {\"id\":\"other-usage\",\"type\":\"session.usage.updated\",\"data\":{\"sessionID\":\"remote-not-ours\",\"tokens\":{\"input\":999,\"output\":0,\"cache\":{\"read\":0,\"write\":0}}}}\n\n";
        String ours="data: {\"id\":\"live-usage\",\"type\":\"session.usage.updated\",\"data\":{\"sessionID\":\"remote-ours\",\"tokens\":{\"input\":32,\"output\":5,\"reasoning\":1,\"cache\":{\"read\":3,\"write\":2}}}}\n\n";
        out.write((other+ours).getBytes(StandardCharsets.UTF_8)); out.flush();received.countDown();
      }
    });
    ExecutorService executor=Executors.newCachedThreadPool(r->{Thread t=new Thread(r);t.setDaemon(true);return t;});
    server.setExecutor(executor);server.start();
    System.setProperty("eliya.opencode.sessionStore",Files.createTempDirectory("eliya117-live-").toString());
    OpenCodeExecutionService service=new OpenCodeExecutionService(new ObjectMapper(),null,"opencode",
      "http://127.0.0.1:"+server.getAddress().getPort(),"","opencode",false);
    try {
      Class<?> kind=Class.forName("com.llmart.llm.service.OpenCodeExecutionService$Session");
      Constructor<?> ctor=kind.getDeclaredConstructor(String.class,String.class,String.class,String.class,String.class,String.class);
      ctor.setAccessible(true);
      String id="oc-11722222-1111-1111-1111-111111111111";
      Object session=ctor.newInstance(id,"remote-ours","conv","project","model","task");
      Field status=kind.getDeclaredField("status");status.setAccessible(true);status.set(session,"running");
      Field ledgerField=kind.getDeclaredField("tokenLedger");ledgerField.setAccessible(true);
      ((OpenCodeTokenLedger)ledgerField.get(session)).nextTask(null,true);
      Field sessions=OpenCodeExecutionService.class.getDeclaredField("sessions");sessions.setAccessible(true);
      ((Map<String,Object>)sessions.get(service)).put(id,session);
      Method reader=OpenCodeExecutionService.class.getDeclaredMethod("beginLiveUsageReader",kind);reader.setAccessible(true);
      reader.invoke(service,session);
      verify(received.await(5,TimeUnit.SECONDS),"Live SSE request not sent");
      long deadline=System.nanoTime()+TimeUnit.SECONDS.toNanos(5);
      long tokens=0;
      while(System.nanoTime()<deadline) {
        Map<String,Object> usage=(Map<String,Object>)service.get(id).get("usage");
        tokens=((Number)usage.get("providerTotalTokens")).longValue();
        if(tokens>0)break;
        Thread.sleep(25);
      }
      verify(tokens==42,"SSE parser/owner filter wrong: "+tokens);
      Field cursor=kind.getDeclaredField("lastLogEventId");cursor.setAccessible(true);
      verify("".equals(cursor.get(session)),"Volatile events must not change durable cursor");
      System.out.println("PASS: localhost OpenCode live SSE delivers exact task usage; other session excluded");
    } finally {service.shutdown();server.stop(0);executor.shutdownNow();}
  }
}
