#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../.."
D=$(mktemp -d)
trap 'rm -rf "$D"' EXIT
javac --release 17 -d "$D" $(find qa/eliya87-opencode/stubs -name '*.java') \
  src/main/java/com/llmart/llm/service/ConversationHandoffSelection.java \
  src/main/java/com/llmart/llm/service/OpenCodeUiProviderConfig.java \
  src/main/java/com/llmart/llm/service/OpenCodeNetworkDiagnostics.java \
  src/main/java/com/llmart/llm/service/OpenCodeLocalRuntime.java \
  src/main/java/com/llmart/llm/service/OpenCodeProxyConfig.java \
  src/main/java/com/llmart/llm/service/OpenCodeTokenLedger.java \
  src/main/java/com/llmart/llm/service/OpenCodeExecutionService.java \
  qa/eliya117-usage-e2e/OpenCode117UsageFlowSmoke.java \
  qa/eliya117-usage-e2e/OpenCode117LiveStreamSmoke.java
java -cp "$D" OpenCode117UsageFlowSmoke

java -cp "$D" OpenCode117LiveStreamSmoke
