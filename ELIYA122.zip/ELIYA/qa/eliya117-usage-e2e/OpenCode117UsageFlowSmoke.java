import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.llmart.llm.service.OpenCodeExecutionService;
import com.llmart.llm.service.OpenCodeTokenLedger;
import java.lang.reflect.*;
import java.nio.file.*;
import java.util.*;

/** Verify both v2 event streams, task boundaries, replay cursor and unknown usage.
 * Tests operate without credentials, model calls or mutations to user workspaces. */
public class OpenCode117UsageFlowSmoke {
  static void check(boolean truth, String explanation) {
    if (!truth) throw new AssertionError(explanation);
  }
  @SuppressWarnings("unchecked")
  public static void main(String[] args) throws Exception {
    Path state = Files.createTempDirectory("eliya117-usage-");
    System.setProperty("eliya.opencode.sessionStore",state.toString());
    OpenCodeExecutionService service = new OpenCodeExecutionService(
      new ObjectMapper(), null, "legacy", "http://127.0.0.1:4096", "", "opencode", false);
    Class<?> kind=Class.forName("com.llmart.llm.service.OpenCodeExecutionService$Session");
    Constructor<?> maker=kind.getDeclaredConstructor(String.class,String.class,String.class,String.class,String.class,String.class);
    maker.setAccessible(true);
    String id="oc-11711111-1111-1111-1111-111111111111";
    Object session=maker.newInstance(id,"remote-a","conv","project","model","implement task");
    Field tokenLedger=kind.getDeclaredField("tokenLedger"); tokenLedger.setAccessible(true);
    OpenCodeTokenLedger ledger=(OpenCodeTokenLedger) tokenLedger.get(session);
    ledger.nextTask(null,true);
    Field sessions=OpenCodeExecutionService.class.getDeclaredField("sessions");sessions.setAccessible(true);
    ((Map<String,Object>)sessions.get(service)).put(id,session);
    Method live=OpenCodeExecutionService.class.getDeclaredMethod("readEvent",kind,String.class,String.class,String.class,boolean.class);
    live.setAccessible(true);
    Field cursor=kind.getDeclaredField("lastLogEventId");cursor.setAccessible(true);
    Field evidence=kind.getDeclaredField("lastEvidenceNanos");evidence.setAccessible(true);
    String wrong="{\"id\":\"ev-other\",\"type\":\"session.usage.updated\",\"data\":{\"sessionID\":\"remote-b\",\"tokens\":{\"input\":999,\"output\":1,\"reasoning\":0,\"cache\":{\"read\":0,\"write\":0}}}}";
    live.invoke(service,session,"","",wrong,false);
    check(!Boolean.TRUE.equals(((Map<String,Object>)service.get(id).get("usage")).get("providerReported")),
      "Other session usage leaked into this session");
    String own="{\"id\":\"ev-own\",\"type\":\"session.usage.updated\",\"data\":{\"sessionID\":\"remote-a\",\"tokens\":{\"input\":40,\"output\":10,\"reasoning\":3,\"cache\":{\"read\":8,\"write\":2}}}}";
    live.invoke(service,session,"","",own,false);
    Map<String,Object> first=(Map<String,Object>)service.get(id).get("usage");
    check(((Number)first.get("providerTotalTokens")).longValue()==60,"Live aggregate not displayed");
    check("aggregate_delta".equals(first.get("usageStatus")),"Aggregate source isn't explicit");
    check("".equals(cursor.get(session)),"Live cursor replaced durable session cursor");
    long activity=(long)evidence.get(session);
    Thread.sleep(8);
    String duplicate=own.replace("ev-own","ev-own-duplicate");
    live.invoke(service,session,"","",duplicate,false);
    check((long)evidence.get(session)==activity,"Duplicate token totals incorrectly treated as progress");
    // A durable duplicate event must still advance the durable replay cursor.
    live.invoke(service,session,"","",own,true);
    check("ev-own".equals(cursor.get(session)),"Durable cursor not advanced on live duplicate");
    check(((Number)((Map<String,Object>)service.get(id).get("usage")).get("providerTotalTokens")).longValue()==60,
      "Live/durable delivery double-counted tokens");
    // Prefer authoritative per-step totals once available, deduped by message ID.
    String step="{\"id\":\"ev-step\",\"type\":\"session.step.ended\",\"data\":{\"sessionID\":\"remote-a\",\"assistantMessageID\":\"assistant-117\",\"tokens\":{\"input\":40,\"output\":10,\"reasoning\":3,\"cache\":{\"read\":8,\"write\":2}}}}";
    live.invoke(service,session,"","",step,false);
    Map<String,Object> reconciled=(Map<String,Object>)service.get(id).get("usage");
    check(((Number)reconciled.get("providerTotalTokens")).longValue()==60,"Message+aggregate doubled");
    check(((Number)reconciled.get("reportedCalls")).longValue()==1,"Assistant step missed");
    ledger.nextTask(new JsonNode(Map.of("input",40,"output",10,"reasoning",3,"cache",Map.of("read",8,"write",2))),false);
    // An old assistant usage update can arrive after a new prompt was admitted.
    // Update lifetime totals if needed, but NEVER charge the new task.
    ledger.record("assistant-117","model","OpenCode model call",new JsonNode(Map.of(
      "input",41,"output",10,"reasoning",3,"cache",Map.of("read",8,"write",2))));
    check(((Number)ledger.taskSnapshot(100,"opencode","model").get("providerTotalTokens")).longValue()==0,
      "Late previous-turn usage counted against the current task");
    check(!Boolean.TRUE.equals(((Map<String,Object>)service.get(id).get("usage")).get("providerReported")),
      "Previous turn usage must not leak into next turn");
    String step2="{\"id\":\"ev-step2\",\"type\":\"session.step.ended\",\"data\":{\"sessionID\":\"remote-a\",\"assistantMessageID\":\"assistant-118\",\"tokens\":{\"input\":9,\"output\":4,\"reasoning\":1,\"cache\":{\"read\":1,\"write\":0}}}}";
    live.invoke(service,session,"","",step2,false);
    check(((Number)((Map<String,Object>)service.get(id).get("usage")).get("providerTotalTokens")).longValue()==14,
      "Second turn should contain only its tokens");
    service.shutdown();
    System.out.println("PASS: separate session, live aggregate, no false progress, replay cursor, dedupe, exact step and task boundary");
  }
}
