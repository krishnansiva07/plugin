import com.fasterxml.jackson.databind.ObjectMapper;
import com.llmart.llm.service.OpenCodeExecutionService;
import com.llmart.llm.service.ProjectService;
import java.lang.reflect.Field;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.TimeUnit;

/** Tests startup detection, zero-token prewarming, reuse, idle recycling and unsupported installs. */
public final class OpenCodePrewarmSmoke {
    private static void check(boolean yes, String why) { if (!yes) throw new AssertionError(why); }
    private static Process currentProcess(OpenCodeExecutionService service) throws Exception {
        Field field=OpenCodeExecutionService.class.getDeclaredField("managedProcess");
        field.setAccessible(true); return (Process)field.get(service);
    }
    private static Map<String,Object> ready(OpenCodeExecutionService service) throws Exception {
        Map<String,Object> current = Map.of();
        long deadline=System.nanoTime()+TimeUnit.SECONDS.toNanos(14);
        while(System.nanoTime()<deadline) {
            current=service.engineInfo();
            if ("ready".equals(current.get("status")) && Boolean.TRUE.equals(current.get("connected"))) return current;
            if (Set.of("failed","unsupported").contains(current.get("status")))
                throw new AssertionError("Background prewarm failed: " + current);
            Thread.sleep(100);
        }
        throw new AssertionError("Prewarm exceeded deadline: " + current);
    }
    public static void main(String[] args) throws Exception {
        Path sandbox=Files.createTempDirectory("eliya112-prewarm-");
        System.setProperty("eliya.opencode.sessionStore",sandbox.resolve("sessions").toString());
        String binary=System.getenv("ELIYA_QA_MOCK_BINARY");
        check(binary!=null && Files.isExecutable(Path.of(binary)),"Mock OpenCode executable is missing");
        String apiKey="top-secret-do-not-log";
        var service=new OpenCodeExecutionService(new ObjectMapper(),new ProjectService(),
                "opencode","http://127.0.0.1:4096","",binary,true);
        try {
            long t0=System.nanoTime();
            service.initializeOnStartup();
            check(TimeUnit.NANOSECONDS.toMillis(System.nanoTime()-t0)<500,
                    "Startup must queue detection without blocking the Java application");
            check(!Boolean.TRUE.equals(service.engineInfo().get("connected")),
                    "OpenCode cannot start before browser provides its selected Agent model");
            long t1=System.nanoTime();
            Map<String,Object> accepted=service.prewarm("https://company.example/v1", "agent-model-v1", apiKey);
            check("starting".equals(accepted.get("status")),"Prewarm must be asynchronous");
            check(TimeUnit.NANOSECONDS.toMillis(System.nanoTime()-t1)<500,
                    "Prewarm API should return immediately, not wait for the server");
            Map<String,Object> state=ready(service);
            check(Boolean.TRUE.equals(state.get("autoEligible")),
                    "The selected Agent model was validated without model-token usage");
            check("supported".equals(state.get("installationStatus")),"Installed status must be explicit");
            check(service.list().isEmpty(),"Prewarming may not send hidden prompts or create tasks");
            Process first=currentProcess(service);
            check(first!=null && first.isAlive(),"A warm private OpenCode process should exist");
            check("true".equals(Files.readString(Path.of(System.getenv("ELIYA_QA_ENV_FILE"))).trim()),
                    "OpenCode must disable workspace file watching across platforms");
            service.prewarm("https://company.example/v1","agent-model-v1",apiKey);
            ready(service);
            // Allow asynchronous validation to finish; same settings must not bounce the process.
            Thread.sleep(400);
            check(currentProcess(service)==first && first.isAlive(),
                    "Same model and credentials should reuse the already warm service");
            System.out.println("PASS: asynchronous startup, zero-token prewarm, ready Auto and warm process reuse");

            // Every completed task releases old workspace handles, then primes a clean server.
            var release=OpenCodeExecutionService.class.getDeclaredMethod("releaseManagedProcessWhenIdle");
            release.setAccessible(true); release.invoke(service);
            Thread.sleep(2500);
            Map<String,Object> fresh=ready(service);
            Process after=currentProcess(service);
            check(!first.isAlive() && after!=null && after.isAlive() && after.pid()!=first.pid(),
                    "Idle completion must retire the old workspace-holding process");
            check(Boolean.TRUE.equals(fresh.get("autoEligible")),
                    "The clean server must be primed automatically for the next task");
            System.out.println("PASS: idle workspace handles released and next run automatically re-prewarmed");

            service.prewarm("https://company.example/v1", "qwen3.8-27b", apiKey);
            Map<String,Object> newer=ready(service);
            // During async model handoff the old ready server could appear briefly.
            long deadline=System.nanoTime()+TimeUnit.SECONDS.toNanos(10);
            while (!"qwen3.8-27b".equals(newer.get("defaultModel")) && System.nanoTime()<deadline) {
                Thread.sleep(100); newer=ready(service);
            }
            check("qwen3.8-27b".equals(newer.get("defaultModel")),"Changed UI Agent model not applied");
            check(!after.isAlive(),"Model change must not leave previous child holding handles");
            System.out.println("PASS: model change safely invalidates and prewarms provider");
        } finally {
            Process process=currentProcess(service);
            service.shutdown();
            if(process!=null) check(!process.isAlive(),"ELIYA shutdown left its child process behind");
        }
        var absent=new OpenCodeExecutionService(new ObjectMapper(),new ProjectService(),
                "opencode","http://127.0.0.1:4096","",sandbox.resolve("does-not-exist").toString(),true);
        try {
            absent.initializeOnStartup();
            long end=System.nanoTime()+TimeUnit.SECONDS.toNanos(4);
            while (!"unsupported".equals(absent.engineInfo().get("status")) && System.nanoTime()<end) Thread.sleep(60);
            Map<String,Object> result=absent.engineInfo();
            check("unsupported".equals(result.get("status")),"Missing OpenCode must report unsupported");
            check(!Boolean.TRUE.equals(result.get("autoEligible")),"Missing executable cannot enable Auto");
            check(String.valueOf(result.get("reason")).contains("2.2"),"Missing binary needs a minimum-version explanation");
            System.out.println("PASS: missing CLI reports OpenCode not supported and never starts a process");
        } finally {absent.shutdown();}
    }
}
