package com.llmart.llm.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sun.net.httpserver.HttpServer;
import java.lang.reflect.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;

/** Provider stays busy but never sends model or tool evidence. No paid model needed. */
public final class HandoffWatchdogSmoke {
    static void check(boolean condition,String message) {if(!condition)throw new AssertionError(message);}
    public static void main(String[] args) throws Exception {
        check(ConversationHandoffSelection.isPlanExecutionReply("can you implement"),
                "Short Analyse -> Execute consent must be recognized");
        check(ConversationHandoffSelection.isPlanExecutionReply("Can you please implement?"),
                "Polite handoff must be recognized");
        check(!ConversationHandoffSelection.isPlanExecutionReply("Can you implement a different module?"),
                "Unrelated concrete work must not inherit an old answer");
        var turns=List.of(
                new ConversationHandoffSelection.Turn(1,"user","Please suggest OpenCode agent and skill improvements",List.of()),
                new ConversationHandoffSelection.Turn(2,"assistant","Implement an agent plus reusable skill registry",List.of()),
                new ConversationHandoffSelection.Turn(3,"user","can you implement",List.of()));
        var handoff=ConversationHandoffSelection.select(turns,3,"can you implement").orElseThrow();
        check(handoff.answerId()==2 && handoff.requirementId()==1,
                "Implementation must inherit immediately preceding Analyse response");
        check(ConversationHandoffSelection.select(turns,3,"create an unrelated service").isEmpty(),
                "An unrelated request must not inherit Analyze context");
        System.out.println("PASS: conversational Analyse -> Execute handoff carries exact prior requirement and answer");

        AtomicBoolean interrupted=new AtomicBoolean(false);
        HttpServer server=HttpServer.create(new InetSocketAddress("127.0.0.1",0),0);
        server.createContext("/api/session/active", req -> {
            reply(req,200,interrupted.get()?"{\"data\":{}}":"{\"data\":{\"ses_silent\":{\"status\":\"busy\"}}}");
        });
        server.createContext("/api/session/ses_silent/interrupt", req -> {
            interrupted.set(true);reply(req,200,"{\"data\":{\"interrupted\":true}}");
        });
        server.createContext("/api/session/ses_silent", req -> reply(req,200,"{\"data\":{}}"));
        server.setExecutor(Executors.newCachedThreadPool(r->{Thread t=new Thread(r);t.setDaemon(true);return t;}));
        server.start();
        Path store=Files.createTempDirectory("eliya115-watchdog-");
        System.setProperty("eliya.opencode.sessionStore",store.toString());
        System.setProperty("eliya.opencode.noProgressTimeoutSeconds","120");
        OpenCodeExecutionService service=new OpenCodeExecutionService(new ObjectMapper(), null,"opencode",
                "http://127.0.0.1:"+server.getAddress().getPort(),"","opencode",false);
        try {
            Class<?> sessionType=Class.forName("com.llmart.llm.service.OpenCodeExecutionService$Session");
            Constructor<?> ctor=sessionType.getDeclaredConstructor(String.class,String.class,String.class,
                    String.class,String.class,String.class);
            ctor.setAccessible(true);
            String id="oc-12345678-1234-1234-1234-123456789123";
            Object session=ctor.newInstance(id,"ses_silent","conv","project","qwen","create a file");
            Field running=sessionType.getDeclaredField("status");running.setAccessible(true);
            running.set(session,"running");
            Field evidence=sessionType.getDeclaredField("lastEvidenceNanos");evidence.setAccessible(true);
            evidence.setLong(session,System.nanoTime()-TimeUnit.SECONDS.toNanos(180));
            Field remotePrompt=sessionType.getDeclaredField("lastPromptId");remotePrompt.setAccessible(true);
            remotePrompt.set(session,"usr_current");
            Field sessions=OpenCodeExecutionService.class.getDeclaredField("sessions");sessions.setAccessible(true);
            @SuppressWarnings("unchecked") var stored=(Map<String,Object>)sessions.get(service);
            stored.put(id,session);
            String oldId = "oc-22345678-1234-1234-1234-123456789123";
            Object oldSession = ctor.newInstance(oldId,"ses_old","conv","project","qwen","old file");
            running.set(oldSession,"completed");
            stored.put(oldId,oldSession);
            check(service.latestSession("conv","project").isPresent(),
                    "completed historical session is initially reusable");
            service.retireWorkspaceSessions("project");
            check(service.latestSession("conv","project").isEmpty(),
                    "after Rescan, an earlier OpenCode session must never be reused");
            Field retired = sessionType.getDeclaredField("retiredFromRescan");
            retired.setAccessible(true);
            check(retired.getBoolean(oldSession),"session retirement is recorded for restart");
            @SuppressWarnings("unchecked") var before=(Map<String,Object>)service.get(id).get("progress");
            check(Boolean.TRUE.equals(before.get("indeterminate")),"No-progress execution must not display fake percentage");
            Method begin=sessionType.getEnclosingClass().getDeclaredMethod("beginMonitor",sessionType);
            begin.setAccessible(true);begin.invoke(service,session);
            long deadline=System.nanoTime()+TimeUnit.SECONDS.toNanos(15);
            String status="running";
            while(System.nanoTime()<deadline && ("running".equals(status) || "cancelling".equals(status))) {
                Thread.sleep(200);status=String.valueOf(service.get(id).get("status"));
            }
            check(interrupted.get(),"Silent busy provider must receive interrupt after inactivity cutoff");
            check("cancelled".equals(status),"Idle-confirmed process should stop, got "+status);
            check(((List<?>)service.get(id).get("events")).stream().map(Object::toString)
                    .anyMatch(item ->item.contains("no verified model/tool progress") || item.contains("No verified model/tool progress")),
                    "Watchdog must disclose the lack of verified progress");
            System.out.println("PASS: silent provider -> warning -> bounded interrupt -> confirmed stopped; no false completion");
        } finally {service.shutdown();server.stop(0);}
    }
    private static void reply(com.sun.net.httpserver.HttpExchange req,int code,String body) throws java.io.IOException {
        byte[] bytes=body.getBytes(StandardCharsets.UTF_8);
        req.getResponseHeaders().set("Content-Type","application/json");
        req.sendResponseHeaders(code,bytes.length);
        try(var output=req.getResponseBody()){output.write(bytes);}
    }
}
