#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../.."
T=$(mktemp -d); trap 'rm -rf "$T"' EXIT
javac --release 17 -d "$T" $(find qa/eliya87-opencode/stubs -name '*.java') \
  src/main/java/com/llmart/llm/service/ConversationHandoffSelection.java \
  src/main/java/com/llmart/llm/service/OpenCodeUiProviderConfig.java \
  src/main/java/com/llmart/llm/service/OpenCodeNetworkDiagnostics.java \
  src/main/java/com/llmart/llm/service/OpenCodeLocalRuntime.java \
  src/main/java/com/llmart/llm/service/OpenCodeProxyConfig.java \
  src/main/java/com/llmart/llm/service/OpenCodeTokenLedger.java \
  src/main/java/com/llmart/llm/service/OpenCodeExecutionService.java \
  qa/eliya115-handoff-watchdog/HandoffWatchdogSmoke.java
java -cp "$T" com.llmart.llm.service.HandoffWatchdogSmoke
javac --release 17 -cp "$T" -d "$T" \
  qa/eliya115-handoff-watchdog/stubs/com/llmart/llm/service/ConversationService.java \
  qa/eliya76-handoff/stubs/com/llmart/llm/entity/MessageEntity.java \
  src/main/java/com/llmart/llm/service/ConversationHandoffService.java \
  src/main/java/com/llmart/llm/service/UnifiedOpenCodeChatBridge.java \
  qa/eliya115-handoff-watchdog/BridgeHandoffSmoke.java
java -cp "$T" com.llmart.llm.service.BridgeHandoffSmoke
