package com.llmart.llm.service;
import com.llmart.llm.entity.MessageEntity;
import java.util.*;
public class ConversationService {
    final Map<String,List<MessageEntity>> data = new HashMap<>();
    public void seed(String id,List<MessageEntity> values) { data.put(id,new ArrayList<>(values)); }
    public void require(String id) { if (!data.containsKey(id)) throw new IllegalArgumentException("Missing conversation"); }
    public MessageEntity addMessage(String id,String role,String message,List<String> attachments) {
        List<MessageEntity> history=data.computeIfAbsent(id,k->new ArrayList<>());
        var entity = new MessageEntity(history.size()+1,role,message);history.add(entity);return entity;
    }
    public List<MessageEntity> messageEntities(String id) {return data.getOrDefault(id,List.of());}
    public Optional<MessageEntity> messageInConversation(String id,long messageId) {
        return messageEntities(id).stream().filter(m->m.getId()==messageId).findFirst();
    }
    public MessageDto messageDto(MessageEntity message){return new MessageDto(List.of());}
    public record MessageDto(List<String> attachmentIds){}
}
