package com.llmart.llm.service;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.llmart.llm.entity.MessageEntity;
import java.lang.reflect.Method;
import java.util.*;

/** Compile the production bridge and verify the context actually passed to OpenCode. */
public class BridgeHandoffSmoke {
    static void check(boolean condition, String message) { if (!condition) throw new AssertionError(message); }
    public static void main(String[] args) throws Exception {
        var conversations=new ConversationService();
        conversations.seed("conv",List.of(new MessageEntity(1,"user","Propose :opencode agents and skills"),
                new MessageEntity(2,"assistant","Create a reusable skills registry and scoped agent catalog"),
                new MessageEntity(3,"user","can you implement")));
        var handoffs=new ConversationHandoffService(conversations);
        var engine=new OpenCodeExecutionService(new ObjectMapper(),null,"legacy",
                "http://127.0.0.1:4096","","opencode",false);
        try {
            var bridge=new UnifiedOpenCodeChatBridge(engine,conversations,handoffs);
            Method build=UnifiedOpenCodeChatBridge.class.getDeclaredMethod("executionHandoff",String.class,String.class);
            build.setAccessible(true);
            String context=(String)build.invoke(bridge,"conv","can you implement");
            check(context.contains("Propose :opencode agents and skills"),"Lost initial user requirement");
            check(context.contains("Create a reusable skills registry"),"Lost Analyse response");
            check(build.invoke(bridge,"conv","create unrelated module")==null,"Leaked unrelated answer");
            Method instruction=OpenCodeExecutionService.class.getDeclaredMethod("instructionWithHandoff",String.class,String.class);
            instruction.setAccessible(true);
            String prompt=(String)instruction.invoke(null,"can you implement",context);
            check(prompt.endsWith("Current user instruction (authoritative):\ncan you implement"),
                    "Current instruction must remain authoritative");
            // Both new sessions and resumed sessions use the same instruction builder.
            Method message=OpenCodeExecutionService.class.getDeclaredMethod("message",String.class,
                    com.llmart.llm.dto.ChatRequest.class,String.class,String.class);
            check(message!=null,"Reused OpenCode session lacks handoff overload");
            System.out.println("PASS: production bridge compiles, carries Analyse context, scopes it and supports resumed sessions");
        } finally {engine.shutdown();}
    }
}
