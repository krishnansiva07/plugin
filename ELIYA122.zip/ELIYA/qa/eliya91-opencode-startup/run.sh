#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../.."
TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT
javac --release 17 -d "$TMP" \
  $(find qa/eliya87-opencode/stubs -name '*.java') \
  $(find qa/eliya91-opencode-startup/stubs -name '*.java') \
  src/main/java/com/llmart/llm/service/OpenCodeUiProviderConfig.java \
  src/main/java/com/llmart/llm/service/OpenCodeNetworkDiagnostics.java \
  src/main/java/com/llmart/llm/service/OpenCodeLocalRuntime.java \
  src/main/java/com/llmart/llm/service/OpenCodeProxyConfig.java \
  src/main/java/com/llmart/llm/service/OpenCodeTokenLedger.java \
  src/main/java/com/llmart/llm/service/OpenCodeExecutionService.java \
  src/main/java/com/llmart/llm/service/ConversationHandoffSelection.java \
  qa/eliya107-opencode-performance/stubs/com/llmart/llm/service/ConversationHandoffService.java \
  src/main/java/com/llmart/llm/service/UnifiedOpenCodeChatBridge.java \
  qa/eliya91-opencode-startup/BootstrapFailureSmoke.java
java -cp "$TMP" BootstrapFailureSmoke
