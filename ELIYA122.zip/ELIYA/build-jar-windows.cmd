@echo off
setlocal
cd /d "%~dp0"
where mvn >nul 2>nul
if errorlevel 1 (
  echo Maven was not found. Install Maven or build with IntelliJ Maven ^> Lifecycle ^> package.
  exit /b 1
)
call mvn -DskipTests clean package
if errorlevel 1 (
  echo ELIYA JAR build failed. Review the Maven output.
  exit /b 1
)
if not exist "target\eliya.jar" (
  echo Expected target\eliya.jar not found. Inspect pom.xml package configuration.
  exit /b 1
)
echo.
echo JAR ready: %CD%\target\eliya.jar
echo Native Eliya Agent is active. OpenCode is disabled and not required.
echo Start with: java -jar target\eliya.jar
endlocal
