'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const handoff=require('../../main/resources/static/workflow-handoff.js');
const app=fs.readFileSync('src/main/resources/static/app.js','utf8');
const agent=fs.readFileSync('src/main/java/com/llmart/llm/service/AgentService.java','utf8');
const html=fs.readFileSync('src/main/resources/static/index.html','utf8');

test('selected Analyse handoff allows user refinements without changing source',()=>{
  const draft={messageId:102,conversationId:'c1',projectId:'p1'};
  const args={draft,conversationId:'c1',projectId:'p1',mode:'agent',message:handoff.makePrompt(102)};
  assert.equal(handoff.validDraft(args),true);
  assert.equal(handoff.validDraft({...args,message:args.message+'\n\nUse installed Chrome; do not download browsers.'}),true);
  assert.equal(handoff.validDraft({...args,message:args.message.replace('#102','#103')}),false);
  assert.equal(handoff.validDraft({...args,message:args.message+'\nAlso use analysis from conversation message #103'}),false);
  assert.equal(handoff.validDraft({...args,message:args.message.replace('analysis from conversation message #102','something else')}),false);
  assert.equal(handoff.validDraft({...args,conversationId:'c2'}),false);
  assert.equal(handoff.validDraft({...args,projectId:'p2'}),false);
  assert.equal(handoff.validDraft({...args,mode:'chat'}),false);
});

test('partial or interrupted Analyse answers cannot become execution sources',()=>{
  const source={id:102,role:'assistant',mode:'chat',content:'Proposed code changes',streaming:false};
  assert.equal(handoff.canHandoff(source),true);
  assert.equal(handoff.canHandoff({...source,content:'[ELIYA: response incomplete] The plan was interrupted.'}),false);
  assert.equal(handoff.canHandoff({...source,content:'Partial plan\n\n*Generation stopped.*'}),false);
});

test('preparing handoff is user controlled and original draft is recoverable',()=>{
  assert.match(app,/confirm\('You have an unsent draft/);
  assert.match(app,/previousDraft:originalDraft/);
  assert.match(app,/clearHandoffNotice\(\{restoreDraft:true\}\)/);
  assert.match(html,/Cancel handoff/);
  const segment=app.slice(app.indexOf('function prepareAnalysisHandoff('),app.indexOf('\n}\n\nconst esc',app.indexOf('function prepareAnalysisHandoff('))+2);
  assert.doesNotMatch(segment,/sendMessage\(/);
});

test('backend executes explicit plan and stops on missing original source',()=>{
  assert.match(agent,/ConversationHandoffSelection\.explicitSourceId\(request\.message\(\)\)\.isPresent\(\)/);
  assert.match(agent,/ConversationHandoffSelection\.isPlanExecutionReply\(request\.message\(\)\) \|\| explicitAnalysis/);
  assert.match(agent,/The selected analysis was not found in this conversation/);
  assert.match(agent,/active\.finish\("blocked"\)/);
  assert.match(agent,/CURRENT USER HANDOFF INSTRUCTION \(may contain final constraints\)/);
});
