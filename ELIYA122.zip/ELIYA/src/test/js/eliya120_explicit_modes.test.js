'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const w=require('../../main/resources/static/workflow-handoff.js');
const staticDir='src/main/resources/static/';
const app=fs.readFileSync(staticDir+'app.js','utf8');
const html=fs.readFileSync(staticDir+'index.html','utf8');
const server=fs.readFileSync('src/main/java/com/llmart/llm/service/AgentService.java','utf8');

test('visible Analyse and Agent buttons are explicit controls',()=>{
  assert.match(html, /id="workflowModes"[^>]*aria-label="Choose Analyse or Agent mode"/);
  assert.match(html, /data-workflow="analyse"/);
  assert.match(html, /data-workflow="execute"[^>]*>⚡ Agent/);
  assert.doesNotMatch(html,/id="workflowModes"[^>]* hidden/);
});
test('pure workflow resolver does not infer an action from a user prompt',()=>{
  assert.equal(w.resolveMode({workflowMode:'analyse',previousAssistantMode:'agent'}),'chat');
  assert.equal(w.resolveMode({workflowMode:'execute'}),'agent');
  assert.equal(w.resolveMode({workflowMode:'analyse',regenerate:true,previousAssistantMode:'agent'}),'agent');
  assert.equal(w.resolveMode({workflowMode:'execute',regenerate:true,previousAssistantMode:'chat'}),'chat');
  const send=app.slice(app.indexOf('async function sendMessage('),app.indexOf('async function recoverChatAfterStreamFailure('));
  assert.doesNotMatch(send,/decideWithModel|selectedMode: 'auto'|continuation\.text/);
  assert.match(send,/EliyaWorkflowHandoff\.resolveMode/);
});
test('source handoff requires persisted analysis, same conversation, same project and exact source marker',()=>{
  const source={id:42,role:'assistant',mode:'chat',content:'Analysed the relevant files.',streaming:false};
  assert.equal(w.canHandoff(source),true);
  assert.equal(w.canHandoff({...source,id:null}),false);
  assert.equal(w.canHandoff({...source,streaming:true}),false);
  assert.equal(w.canHandoff({...source,mode:'agent'}),false);
  assert.equal(w.canHandoff({...source,mode:undefined}),false);
  const draft={messageId:42,conversationId:'conv-A',projectId:'workspace-A'};
  const basic={draft,conversationId:'conv-A',projectId:'workspace-A',mode:'agent',message:w.makePrompt(42)};
  assert.equal(w.validDraft(basic),true);
  assert.equal(w.validDraft({...basic,conversationId:'conv-B'}),false);
  assert.equal(w.validDraft({...basic,projectId:'workspace-B'}),false);
  assert.equal(w.validDraft({...basic,mode:'chat'}),false);
  assert.equal(w.validDraft({...basic,message:w.makePrompt(43)}),false);
  assert.throws(()=>w.makePrompt(0),/saved analysis/);
  assert.match(server,/The selected analysis was not found in this conversation/);
});
test('preparing a handoff does not auto-submit, and OpenCode remains paused',()=>{
  const preparing=app.slice(app.indexOf('function prepareAnalysisHandoff('),app.indexOf('\n}\n\nconst esc',app.indexOf('function prepareAnalysisHandoff('))+2);
  assert.match(preparing,/chooseWorkflowMode\('execute'\)/);
  assert.match(preparing,/EliyaWorkflowHandoff\.makePrompt/);
  assert.doesNotMatch(preparing,/sendMessage\(/);
  assert.match(app,/return 'legacy';/);
});
