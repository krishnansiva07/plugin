'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const vm=require('node:vm');
const source=fs.readFileSync('src/main/resources/static/app.js','utf8');
const start=source.indexOf('function executionUsageNumbers(');
const end=source.indexOf('/** End-of-activity provider accounting',start);
assert.ok(start>0 && end>start);
const esc=v=>String(v).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
const context=vm.createContext({Number,Math,String,Array,esc});
vm.runInContext(source.slice(start,end)+'\nthis.tokenStrip=executionTokenStripHtml;',context);
test('live OpenCode usage displays exact provider aggregate and recovery diagnostic',()=>{
  const html=context.tokenStrip({engine:'opencode',providerReported:true,usageStatus:'aggregate_delta',
    usageDiagnostic:'Provider counters received',providerTotalTokens:42,providerInputTokens:32,
    providerOutputTokens:5,cachedInputTokens:3,cacheWriteTokens:2,inputExcludesCache:true});
  assert.match(html,/>42<\/span>/);
  assert.match(html,/Provider counters received/);
  assert.match(html,/Cache read 3/);
});
test('missing OpenCode usage is visible, never silently rendered as zero',()=>{
  const html=context.tokenStrip({engine:'opencode',providerReported:false,
    usageDiagnostic:'Awaiting first completed OpenCode model step or live session usage event',modelCalls:1});
  assert.match(html,/>Not reported<\/span>/);
  assert.doesNotMatch(html,/>0<\/span>/);
  assert.match(html,/Awaiting first completed OpenCode model step/);
  assert.match(source,/Awaiting provider token counters/);
  assert.match(source,/Provider tokens not reported/);
});
test('OpenCode requires both session-scoped live usage and REST message recovery',()=>{
  const backend=fs.readFileSync('src/main/java/com/llmart/llm/service/OpenCodeExecutionService.java','utf8');
  assert.match(backend,/\/api\/event\?types=session\.usage\.updated/);
  assert.match(backend,/recoverUsageHistory\(s\)/);
  assert.match(backend,/readEvent\(s, type, id, data\.toString\(\), false\)/);
  assert.match(backend,/!owner\.equals\(s\.remoteId\)/);
});

test('aggregate-only recovery table displays provider values rather than Not reported',()=>{
  const end=source.indexOf('function agentStepsHtml(');
  const begin=source.indexOf('function tokenActivityReportHtml(');
  assert.ok(end>begin);
  const tableCtx=vm.createContext({Number,String,Array,esc});
  vm.runInContext(source.slice(begin,end)+'\nthis.report=tokenActivityReportHtml;',tableCtx);
  const html=tableCtx.report({engine:'opencode',providerReported:true,modelCalls:0,
    activities:[{activity:'OpenCode session aggregate (authoritative)',reported:true,calls:0,
      reportedCalls:0,inputTokens:32,outputTokens:5,cachedInputTokens:3,cacheWriteTokens:2,totalTokens:42}]},true);
  assert.match(html,/42 reported tokens/);
  assert.match(html,/aggregate \(authoritative\)/);
  assert.doesNotMatch(html,/Not reported/);
});
