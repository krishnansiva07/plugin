'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const source = fs.readFileSync(path.join(__dirname, '../../main/resources/static/app.js'), 'utf8');
const start = source.indexOf('const activeFolderIndexWatches = new Set();');
const stop = source.indexOf('async function registerFolder(', start);
assert.ok(start >= 0 && stop > start);

// A Rescan while an older watcher is about to finish must cause another status read.
test('overlapping Rescan waits for a fresh index-status result instead of losing watcher', async () => {
  let releaseFirst;
  const firstResult = new Promise(resolve => { releaseFirst = resolve; });
  let polls = 0;
  const project = {id:'live', localWorkspace:true, fileCount:3};
  const statusMessages = [];
  const scope = {
    state: {project, referenceProjects:[]},
    api: async () => { polls++; return polls === 1 ? firstResult : {
      phase:'completed', fileCount:1, indexedCharacters:60,
      detail:'Ready for Chat and Agent', fresh:true
    }; },
    sharedFolderStatus: msg => statusMessages.push(msg),
    renderProjectBar() {}, saveReferenceFolders() {},
    setTimeout, clearTimeout, Promise, Number, String, Boolean
  };
  vm.runInNewContext(source.slice(start, stop), scope);
  const first = scope.watchFolderIndex(project, false);
  await new Promise(setImmediate);
  await scope.watchFolderIndex(project, false);
  releaseFirst({phase:'completed', fileCount:3, indexedCharacters:90, detail:'Old snapshot'});
  await first;
  for (let i = 0; i < 25 && (polls < 2 || project.fileCount !== 1); i++)
    await new Promise(setImmediate);
  assert.equal(polls, 2, 'a second watch must run after the old watch completes');
  assert.equal(project.fileCount, 1, 'fresh count must overwrite the old snapshot');
  assert.match(statusMessages.at(-1), /1 files indexed/);
});
