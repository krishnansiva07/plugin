'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const src = fs.readFileSync(path.join(__dirname, '../../main/resources/static/app.js'), 'utf8');
const start = src.indexOf('let workspaceFreshnessPollActive = false;');
const stop = src.indexOf('async function registerFolder(', start);
assert.ok(start >= 0 && stop > start, 'periodic UI freshness function is present');

test('automatic index status updates file count and watcher state without forcing a rescan', async () => {
  const status = [];
  let calls = 0;
  let bars = 0;
  const project = {id:'workspace', localWorkspace:true, fileCount:2, indexedCharacters:100};
  const scope = {
    state:{project}, activeFolderIndexWatches:new Set(),
    api:async () => {
      calls++;
      return {phase:'completed', fileCount:1, indexedCharacters:50, watchState:'watching',
              autoSyncEnabled:true, lastAutoSyncAt:'2026-11-01T01:00:00Z', rescanPending:false};
    },
    sharedFolderStatus:message => status.push(message),
    renderProjectBar:() => {bars++;}, watchFolderIndex:() => {},
    window:{setInterval:() => {}}, encodeURIComponent, Number, Date, Boolean, String
  };
  vm.runInNewContext(src.slice(start, stop), scope);
  await scope.pollWorkspaceAutoSync();
  assert.equal(project.fileCount, 1);
  assert.equal(project.indexedCharacters, 50);
  assert.equal(bars, 1);
  assert.equal(calls, 1);
  assert.match(status.at(-1), /Automatic sync active/);
  assert.match(status.at(-1), /1 files indexed/);
});
