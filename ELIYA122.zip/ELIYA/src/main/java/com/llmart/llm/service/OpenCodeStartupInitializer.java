package com.llmart.llm.service;

import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

/** Platform-neutral, nonblocking OpenCode discovery on application startup. */
@Component
public final class OpenCodeStartupInitializer {
    @org.springframework.beans.factory.annotation.Value("${eliya.opencode.integration-enabled:false}")
    private boolean allowOpenCode;
    private final OpenCodeExecutionService service;
    public OpenCodeStartupInitializer(OpenCodeExecutionService service) { this.service = service; }
    @EventListener(ApplicationReadyEvent.class)
    public void onReady() { if (allowOpenCode) service.initializeOnStartup(); }
}
