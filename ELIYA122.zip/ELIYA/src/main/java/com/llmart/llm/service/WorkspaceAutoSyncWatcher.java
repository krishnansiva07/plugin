package com.llmart.llm.service;

import com.llmart.llm.dto.ProjectDto;
import java.io.IOException;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.*;
import java.util.function.Consumer;

/**
 * Cross-platform, bounded, recursive WatchService with debounced incremental changes.
 * No file contents are read or indexed on the watch thread or HTTP request thread.
 * WatchService events are hints (not a guaranteed log); overflow, unavailable mounts,
 * newly registered roots and periodically missed events are covered by reconciliation.
 */
final class WorkspaceAutoSyncWatcher implements AutoCloseable {
    record Changes(ProjectDto project, Set<String> paths, boolean fullScan) {}

    private static final Set<String> EXCLUDED = Set.of(
            ".git", ".svn", ".hg", ".idea", ".vscode", "node_modules", "target", "build", "dist", "out",
            ".gradle", ".next", "coverage", ".venv", "venv", "env", "vendor", ".terraform", ".dart_tool",
            ".cache", "bin", "obj", ".advanced-ai-chat-backup", ".agent-build", ".agent-home", ".eliya-presentation-previews",
            "__pycache__", ".pytest_cache", ".tox", ".mypy_cache", ".ruff_cache", "pods", "deriveddata", ".build"
    );
    private static final int MAX_TOTAL_DIRECTORIES = intProp("eliya.index.watch.maxTotalDirectories", 16000, 256, 100000);
    private static final int MAX_DIRECTORIES = intProp("eliya.index.watch.maxDirectories", 8192, 32, 50000);
    private static final int MAX_EVENTS_PER_BATCH = intProp("eliya.index.watch.maxBatchPaths", 1500, 50, 10000);
    private static final int DEBOUNCE_MS = intProp("eliya.index.watch.debounceMs", 700, 100, 10000);
    private static final int RECONCILE_SECONDS = intProp("eliya.index.watch.reconcileSeconds", 300, 30, 86400);
    private static final WatchEvent.Kind<?>[] KINDS = {
            StandardWatchEventKinds.ENTRY_CREATE,
            StandardWatchEventKinds.ENTRY_MODIFY,
            StandardWatchEventKinds.ENTRY_DELETE
    };

    private final ConcurrentHashMap<String, Monitor> roots = new ConcurrentHashMap<>();
    private final ConcurrentHashMap<WatchKey, Registration> watches = new ConcurrentHashMap<>();
    private final ExecutorService registrar = Executors.newSingleThreadExecutor(r -> daemon(r, "eliya-watch-register"));
    private final ScheduledExecutorService scheduler = Executors.newSingleThreadScheduledExecutor(r -> daemon(r, "eliya-watch-schedule"));
    private final Consumer<Changes> onChanges;
    private final Consumer<ProjectDto> onReconcile;
    private final WatchService watchService;
    private final boolean enabled;
    private volatile boolean closed;

    WorkspaceAutoSyncWatcher(Consumer<Changes> onChanges, Consumer<ProjectDto> onReconcile) {
        this.onChanges = onChanges;
        this.onReconcile = onReconcile;
        this.enabled = !"false".equalsIgnoreCase(System.getProperty("eliya.index.watch.enabled", "true"));
        WatchService service = null;
        if (enabled) {
            try { service = FileSystems.getDefault().newWatchService(); }
            catch (Exception ignored) { /* Polling/reconciliation still works. */ }
        }
        watchService = service;
        if (service != null) {
            Thread loop = daemon(this::watchLoop, "eliya-workspace-watch");
            loop.start();
        }
        // Portable fallback for network drives, polling providers and missing/overflowed events.
        scheduler.scheduleWithFixedDelay(this::reconcileAll, RECONCILE_SECONDS, RECONCILE_SECONDS, TimeUnit.SECONDS);
        scheduler.scheduleWithFixedDelay(this::flushReady, 250, 250, TimeUnit.MILLISECONDS);
    }

    void track(ProjectDto project) {
        if (closed || project == null || !project.localWorkspace() || project.localPath() == null) return;
        final Path root;
        try { root = Path.of(project.localPath()).toAbsolutePath().normalize(); }
        catch (Exception invalid) { return; }
        Monitor monitor = roots.compute(project.id(), (id, existing) -> {
            if (existing != null && existing.root.equals(root)) {
                existing.project = project;
                return existing;
            }
            if (existing != null) removeRegistrations(existing);
            return new Monitor(project, root);
        });
        if (monitor.registered || monitor.registering || watchService == null) return;
        synchronized (monitor) {
            if (monitor.registered || monitor.registering) return;
            monitor.registering = true;
        }
        registrar.execute(() -> {
            try {
                registerTree(monitor, root);
                monitor.registered = !monitor.keys.isEmpty() && Files.isDirectory(root);
                if (!monitor.registered) {
                    monitor.degraded = true;
                    monitor.lastError = "Workspace path unavailable; periodic reconciliation will retry";
                } else if (monitor.degraded)
                    monitor.lastError = "Some folders cannot be watched; periodic reconciliation enabled";
                else monitor.lastError = "";
            } catch (Exception failure) {
                monitor.degraded = true;
                monitor.lastError = String.valueOf(failure.getMessage());
            } finally {
                monitor.registering = false;
            }
        });
    }

    void forget(String projectId) {
        Monitor monitor = roots.remove(projectId);
        if (monitor != null) removeRegistrations(monitor);
    }

    Map<String,Object> status(String id) {
        Monitor m = roots.get(id);
        Map<String,Object> data = new LinkedHashMap<>();
        data.put("autoSyncEnabled", enabled);
        data.put("watchState", !enabled ? "disabled" : watchService == null ? "polling_fallback"
                : m == null ? "not_registered" : m.degraded ? "degraded_reconciling"
                : m.registered ? "watching" : "registering");
        data.put("reconcileSeconds", RECONCILE_SECONDS);
        data.put("monitoredDirectories", m == null ? 0 : m.keys.size());
        data.put("pendingChanges", m == null ? 0 : m.pending.size());
        if (m != null) {
            if (m.lastChangeAt != null) data.put("lastChangeAt", m.lastChangeAt);
            if (m.lastSyncAt != null) data.put("lastAutoSyncAt", m.lastSyncAt);
            if (!m.lastError.isBlank()) data.put("watchError", m.lastError);
        }
        return data;
    }

    void synced(String id, String error) {
        Monitor m = roots.get(id);
        if (m != null) {
            if (error == null) m.lastSyncAt = Instant.now().toString();
            else m.lastError = error;
        }
    }

    private void registerTree(Monitor m, Path start) throws IOException {
        if (closed || watchService == null || !Files.isDirectory(start) || Files.isSymbolicLink(start)) return;
        Files.walkFileTree(start, EnumSet.noneOf(FileVisitOption.class), 48, new SimpleFileVisitor<>() {
            @Override public FileVisitResult preVisitDirectory(Path dir, BasicFileAttributes attrs) throws IOException {
                if (closed || roots.get(m.project.id()) != m) return FileVisitResult.TERMINATE;
                if (attrs.isSymbolicLink() || attrs.isOther() || Files.isSymbolicLink(dir)) return FileVisitResult.SKIP_SUBTREE;
                if (!dir.equals(m.root) && EXCLUDED.contains(dir.getFileName().toString().toLowerCase(Locale.ROOT)))
                    return FileVisitResult.SKIP_SUBTREE;
                if (m.keys.size() >= MAX_DIRECTORIES || watches.size() >= MAX_TOTAL_DIRECTORIES) {
                    m.degraded = true;
                    return FileVisitResult.TERMINATE;
                }
                if (m.directories.contains(dir)) return FileVisitResult.CONTINUE;
                try {
                    WatchKey key = dir.register(watchService, KINDS);
                    m.keys.put(key, dir);
                    m.directories.add(dir);
                    watches.put(key, new Registration(m, dir));
                } catch (IOException | UnsupportedOperationException unsupported) {
                    m.degraded = true;
                    m.lastError = "Cannot watch " + dir + ": " + unsupported.getMessage();
                    return FileVisitResult.SKIP_SUBTREE;
                }
                return FileVisitResult.CONTINUE;
            }
        });
    }

    private void watchLoop() {
        while (!closed) {
            try {
                WatchKey key = watchService.poll(800, TimeUnit.MILLISECONDS);
                if (key == null) continue;
                Registration reg = watches.get(key);
                if (reg != null && roots.get(reg.root.project.id()) == reg.root) {
                    Monitor m = reg.root;
                    for (WatchEvent<?> event : key.pollEvents()) {
                        if (event.kind() == StandardWatchEventKinds.OVERFLOW) {
                            synchronized (m) { m.overflow = true; m.lastChangeAt = Instant.now().toString(); m.changedNanos = System.nanoTime(); }
                            continue;
                        }
                        if (!(event.context() instanceof Path name)) continue;
                        Path absolute = reg.directory.resolve(name).normalize();
                        if (!absolute.startsWith(m.root) || EXCLUDED.contains(name.toString().toLowerCase(Locale.ROOT))) continue;
                        String rel = m.root.relativize(absolute).toString().replace('\\', '/');
                        if (rel.isBlank()) continue;
                        synchronized (m) {
                            if (m.pending.size() < MAX_EVENTS_PER_BATCH) m.pending.add(rel);
                            else m.overflow = true;
                            m.lastChangeAt = Instant.now().toString();
                            m.changedNanos = System.nanoTime();
                        }
                        if (event.kind() == StandardWatchEventKinds.ENTRY_CREATE && Files.isDirectory(absolute)
                                && !Files.isSymbolicLink(absolute))
                            registrar.execute(() -> {
                                try { registerTree(m, absolute); }
                                catch (Exception failure) { m.degraded = true; m.lastError = "New directory watch failed: " + failure.getMessage(); }
                            });
                    }
                } else key.pollEvents();
                if (!key.reset()) {
                    Registration removed = watches.remove(key);
                    if (removed != null) {
                        removed.root.keys.remove(key);
                        removed.root.directories.remove(removed.directory);
                        if (removed.directory.equals(removed.root.root)) {
                            removed.root.degraded = true;
                            removed.root.registered = false;
                            removed.root.lastError = "Workspace watch was lost; periodic reconciliation will retry";
                        }
                    }
                }
            } catch (InterruptedException interrupted) {
                Thread.currentThread().interrupt(); return;
            } catch (ClosedWatchServiceException closedNow) { return;
            } catch (Exception unexpected) {
                for (Monitor m : roots.values()) { m.degraded = true; m.lastError = "Watcher error: " + unexpected.getMessage(); }
            }
        }
    }

    private void flushReady() {
        if (closed) return;
        for (Monitor m : roots.values()) {
            Set<String> changed;
            boolean full;
            synchronized (m) {
                if ((!m.overflow && m.pending.isEmpty()) ||
                        System.nanoTime() - m.changedNanos < TimeUnit.MILLISECONDS.toNanos(DEBOUNCE_MS)) continue;
                changed = Set.copyOf(m.pending);
                full = m.overflow;
                m.pending.clear(); m.overflow = false;
            }
            try { onChanges.accept(new Changes(m.project, changed, full)); }
            catch (Exception failure) { m.degraded = true; m.lastError = "Index change queue failed: " + failure.getMessage(); }
        }
    }

    private void reconcileAll() {
        if (closed || !enabled) return;
        for (Monitor m : roots.values()) {
            try {
                // Repair unavailable roots and watch keys after network mounts reconnect.
                if (watchService != null && !m.registered && !m.registering) trackAgain(m);
                onReconcile.accept(m.project);
            } catch (Exception failure) { m.lastError = "Reconciliation failed: " + failure.getMessage(); }
        }
    }

    private void trackAgain(Monitor m) {
        if (m.registering) return;
        m.registered = false;
        removeRegistrations(m);
        track(m.project);
    }

    private void removeRegistrations(Monitor m) {
        for (WatchKey key : m.keys.keySet()) {
            watches.remove(key);
            key.cancel();
        }
        m.keys.clear();
        m.directories.clear();
    }

    private static int intProp(String property, int fallback, int min, int max) {
        try { return Math.max(min, Math.min(max, Integer.parseInt(System.getProperty(property, "" + fallback)))); }
        catch (Exception ignored) { return fallback; }
    }
    private static Thread daemon(Runnable runnable, String name) {
        Thread t = new Thread(runnable, name);
        t.setDaemon(true);
        return t;
    }
    private static final class Monitor {
        volatile ProjectDto project;
        final Path root;
        final Map<WatchKey,Path> keys = new ConcurrentHashMap<>();
        final Set<Path> directories = ConcurrentHashMap.newKeySet();
        final Set<String> pending = new LinkedHashSet<>();
        volatile boolean registered, registering, degraded;
        boolean overflow;
        long changedNanos;
        volatile String lastChangeAt, lastSyncAt, lastError = "";
        Monitor(ProjectDto project, Path root) { this.project = project; this.root = root; }
    }
    private record Registration(Monitor root, Path directory) {}

    @Override public void close() {
        closed = true;
        for (String id : List.copyOf(roots.keySet())) forget(id);
        scheduler.shutdownNow();
        registrar.shutdownNow();
        if (watchService != null) try { watchService.close(); } catch (IOException ignored) {}
    }
}
