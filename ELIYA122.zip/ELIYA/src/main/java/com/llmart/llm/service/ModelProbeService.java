package com.llmart.llm.service;

import org.springframework.stereotype.Service;

import java.util.Base64;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import javax.imageio.ImageIO;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Lightweight, stateless probe for editable user-defined model entries. */
@Service
public class ModelProbeService {
    private final OpenAiCompatibleClient llm;

    public ModelProbeService(OpenAiCompatibleClient llm) { this.llm = llm; }

    private static String sampleImageDataUrl() throws Exception {
        BufferedImage img = new BufferedImage(64, 64, BufferedImage.TYPE_INT_RGB);
        Graphics2D g = img.createGraphics();
        try {
            g.setColor(Color.WHITE); g.fillRect(0, 0, 64, 64);
            g.setColor(Color.RED); g.fillRect(8, 8, 48, 48);
        } finally { g.dispose(); }
        ByteArrayOutputStream output = new ByteArrayOutputStream();
        if (!ImageIO.write(img, "png", output)) throw new IllegalStateException("PNG encoder unavailable");
        return "data:image/png;base64," + Base64.getEncoder().encodeToString(output.toByteArray());
    }

    public Map<String,Object> probe(String apiKey, String baseUrl, String model, String rawType) throws Exception {
        if (apiKey == null || apiKey.isBlank()) throw new IllegalArgumentException("API key is required to test a model");
        if (baseUrl == null || baseUrl.isBlank()) throw new IllegalArgumentException("Base URL is required to test a model");
        if (model == null || model.isBlank()) throw new IllegalArgumentException("Model ID is required");
        String type = rawType == null ? "chat" : rawType.trim().toLowerCase(Locale.ROOT);
        long started = System.nanoTime();
        String capability;
        if ("embedding".equals(type)) {
            List<double[]> vectors = llm.embed(apiKey, baseUrl, model.trim(), List.of("model connectivity probe"), () -> false);
            if (vectors.isEmpty() || vectors.get(0).length == 0) throw new IllegalStateException("Embedding model returned no vector");
            capability = "embedding";
        } else if ("vision".equals(type) || "ocr".equals(type)) {
            // Test the actual multimodal API contract, not a text-only completion that falsely
            // reports success for providers which reject image_url content.
            String dataUrl = sampleImageDataUrl();
            List<Map<String,Object>> content = List.of(
                    Map.of("type", "text", "text", "What is the color of the filled square? Reply with only its color name."),
                    Map.of("type", "image_url", "image_url", Map.of("url", dataUrl)));
            String reply = llm.complete(apiKey, baseUrl, model.trim(), 100,
                    List.of(Map.of("role", "user", "content", content)));
            if (reply == null || reply.isBlank()) throw new IllegalStateException("Vision model returned an empty response to an image request");
            if (!reply.trim().toLowerCase(Locale.ROOT).contains("red"))
                throw new IllegalStateException("Vision image probe returned an unexpected answer: " + reply.substring(0, Math.min(80, reply.length())));
            capability = "image understanding (red square verified)";
        } else {
            String reply = llm.complete(apiKey, baseUrl, model.trim(), 24,
                    List.of(Map.of("role", "user", "content", "Connection probe. Reply with OK only.")));
            if (reply == null || reply.isBlank()) throw new IllegalStateException("Model returned an empty response");
            capability = "chat completion";
        }
        long elapsedMs = Math.max(1L, (System.nanoTime() - started) / 1_000_000L);
        Map<String,Object> out = new LinkedHashMap<>();
        out.put("ok", true);
        out.put("model", model.trim());
        out.put("type", type);
        out.put("capability", capability);
        out.put("elapsedMs", elapsedMs);
        return out;
    }
}
