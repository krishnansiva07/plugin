package com.llmart.llm.service;

import com.llmart.llm.dto.ProjectDto;
import jakarta.annotation.PreDestroy;
import org.springframework.stereotype.Service;

import java.nio.file.Path;
import java.nio.file.Files;
import java.time.Instant;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.function.Consumer;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * One bounded background worker for project/reference indexing. Registering a folder never
 * performs a full filesystem traversal or bulk H2 writes on a servlet/chat thread.
 */
@Service
public class LocalProjectIndexService {
    private final WorkspaceRetrievalIndexService retrieval;
    private final Map<String, Job> jobs = new ConcurrentHashMap<>();
    private final WorkspaceAutoSyncWatcher watcher;
    private final Map<String, PendingChanges> changeQueue = new ConcurrentHashMap<>();
    private volatile Consumer<String> retireSessions = id -> {};

    /** The already-existing OpenCode service is wired from the controller to avoid a DI cycle. */
    public void setSessionRetirer(Consumer<String> callback) {
        retireSessions = callback == null ? id -> {} : callback;
    }

    private final ExecutorService worker = Executors.newSingleThreadExecutor(r -> {
        Thread thread = new Thread(r, "eliya-project-index");
        thread.setDaemon(true);
        return thread;
    });

    public LocalProjectIndexService(WorkspaceRetrievalIndexService retrieval) {
        this.retrieval = retrieval;
        watcher = new WorkspaceAutoSyncWatcher(this::onWorkspaceChanges, this::reconcile);
    }

    /** Coalesce overlapping filesystem batches into one bounded queue job per workspace. */
    private void onWorkspaceChanges(WorkspaceAutoSyncWatcher.Changes changes) {
        ProjectDto project = changes.project();
        PendingChanges buffer = changeQueue.computeIfAbsent(project.id(), ignored -> new PendingChanges());
        synchronized (buffer) {
            buffer.project = project;
            if (changes.fullScan()) { buffer.full = true; buffer.paths.clear(); }
            else if (!buffer.full) {
                buffer.paths.addAll(changes.paths());
                if (buffer.paths.size() > 2_000) { buffer.full = true; buffer.paths.clear(); }
            }
            if (buffer.submitted) return;
            buffer.submitted = true;
            retrieval.markIncrementalPending(project.id(), Path.of(project.localPath()));
        }
        worker.execute(() -> processChanges(project.id(), buffer));
    }

    private void processChanges(String id, PendingChanges buffer) {
        ProjectDto project = buffer.project;
        Path root = Path.of(project.localPath());
        try {
            for (;;) {
                Set<String> paths;
                boolean full;
                synchronized (buffer) {
                    if (!buffer.full && buffer.paths.isEmpty()) {
                        buffer.submitted = false;
                        changeQueue.remove(id, buffer);
                        break;
                    }
                    project = buffer.project;
                    paths = Set.copyOf(buffer.paths);
                    full = buffer.full;
                    buffer.paths.clear();
                    buffer.full = false;
                }
                try {
                    if (!Files.isDirectory(root)) throw new IllegalStateException("Workspace path is missing: " + root);
                    WorkspaceRetrievalIndexService.IndexStats stats;
                    if (full) {
                        stats = retrieval.warmRoot(project.id(), root);
                        updateSnapshot(project, stats, "Automatically reconciled workspace");
                    } else {
                        retrieval.refreshPaths(AgentWorkspaceService.Workspace.forIndex(project.id(), root), paths);
                        stats = retrieval.cachedStats(project.id(), root);
                        if (stats == null) stats = retrieval.warmRoot(project.id(), root);
                        updateSnapshot(project, stats, "Auto-synced " + paths.size() + " changed paths");
                    }
                    // Retire only future reuse, not in-progress OpenCode executions.
                    retireSessions.accept(project.id());
                    watcher.synced(project.id(), null);
                } catch (Exception failure) {
                    watcher.synced(project.id(), failure.getMessage());
                    retrieval.markRescanPending(project.id(), root);
                    Job job = jobs.get(project.id());
                    if (job != null) { job.phase = "failed"; job.detail = "Auto-index failed: " + failure.getMessage(); }
                }
            }
        } finally {
            retrieval.finishIncrementalPending(id, root);
        }
    }

    private static final class PendingChanges {
        volatile ProjectDto project;
        final Set<String> paths = new java.util.LinkedHashSet<>();
        boolean full, submitted;
    }

    private void reconcile(ProjectDto project) {
        if (project == null) return;
        // Reconciliation bypasses servlet threads and shares the single bounded index worker.
        // Retire old provider context only when the file manifest actually changed.
        Path root = Path.of(project.localPath());
        worker.execute(() -> {
            long before = retrieval.cachedFingerprint(project.id(), root);
            retrieval.markIncrementalPending(project.id(), root);
            try {
                if (!Files.isDirectory(root)) throw new IllegalStateException("Workspace path is missing: " + root);
                WorkspaceRetrievalIndexService.IndexStats stats = retrieval.warmRoot(project.id(), root);
                updateSnapshot(project, stats, "Periodic workspace reconciliation");
                if (before != retrieval.cachedFingerprint(project.id(), root)) retireSessions.accept(project.id());
                watcher.synced(project.id(), null);
            } catch (Exception failure) {
                watcher.synced(project.id(), failure.getMessage());
                retrieval.markRescanPending(project.id(), root);
                Job job = jobs.get(project.id());
                if (job != null) {
                    job.phase = "failed";
                    job.detail = "Workspace reconciliation failed: " + failure.getMessage() + ". Check the path or click Rescan.";
                }
            } finally { retrieval.finishIncrementalPending(project.id(), root); }
        });
    }

    private void updateSnapshot(ProjectDto project, WorkspaceRetrievalIndexService.IndexStats stats, String note) {
        Job job = jobs.get(project.id());
        if (job == null || !job.path.equals(project.localPath()) || !"completed".equals(job.phase)) return;
        job.files = stats.indexedFiles();
        job.scanned = stats.visitedFiles();
        job.detail = note + " · " + detail(stats);
        job.finishedAt = Instant.now().toString();
    }


    public synchronized Map<String, Object> request(ProjectDto project, boolean force) {
        if (project == null || !project.localWorkspace()) throw new IllegalArgumentException("A local project is required");
        watcher.track(project);
        Job previous = jobs.get(project.id());
        if (previous != null && previous.path.equals(project.localPath())
                && "queued".equals(previous.phase)) return result(previous);
        if (!force && previous != null && previous.path.equals(project.localPath())
                && "indexing".equals(previous.phase)) return result(previous);
        // A force request while a scan is RUNNING must queue another pass. The
        // currently running scan may have visited the directory before it was deleted.
        if (!force) {
            WorkspaceRetrievalIndexService.IndexStats cached = retrieval.cachedStats(project.id(), Path.of(project.localPath()));
            // Light-touch refresh after a configurable age; never scan on the servlet/Chat thread.
            // The index builder reuses the unchanged file fingerprints, so this is incremental.
            // Set -Deliya.index.autoRefreshMinutes=0 to retain v46's manual-rescan-only behaviour.
            if (cached != null && !refreshDue(cached.generatedAt())) return status(project);
        }
        Job job = new Job(project.id(), project.localPath());
        jobs.put(project.id(), job);
        // Do not serve pre-rescan evidence while the worker is queued or running.
        retrieval.markRescanPending(job.id, Path.of(job.path));
        worker.execute(() -> {
            job.phase = "indexing";
            job.detail = "Scanning source files in the background";
            boolean succeeded = false;
            try {
                // The retrieval index already has bounded file/size/count limits and skips build folders.
                // Do not do the old second walk to copy every source file into the H2 database.
                WorkspaceRetrievalIndexService.IndexStats stats = retrieval.warmRoot(job.id, Path.of(job.path));
                job.files = stats.indexedFiles();
                job.scanned = stats.visitedFiles();
                job.detail = detail(stats);
                watcher.synced(job.id, null);
                succeeded = true;
            } catch (Exception exception) {
                job.detail = exception.getMessage() == null ? exception.getClass().getSimpleName() : exception.getMessage();
                job.phase = "failed";
            } finally {
                job.finishedAt = Instant.now().toString();
                // A newer rescan may already be queued. Only that newest job
                // can release the freshness fence.
                // A failed scan must not re-enable a stale previous index.
                if (jobs.get(job.id) == job && succeeded)
                    retrieval.finishRescan(job.id, Path.of(job.path));
                // Publish completed only after the fresh index is visible to readers.
                job.phase = succeeded ? "completed" : "failed";
            }
        });
        return result(job);
    }

    private static boolean refreshDue(String indexedAt) {
        long minutes;
        try { minutes = Long.parseLong(System.getProperty("eliya.index.autoRefreshMinutes", "0")); }
        catch (NumberFormatException invalid) { minutes = 0; }
        if (minutes <= 0) return false;
        minutes = Math.max(10, Math.min(minutes, 24 * 60));
        try { return Instant.parse(indexedAt).isBefore(Instant.now().minusSeconds(minutes * 60)); }
        catch (Exception invalidTimestamp) { return false; }
    }

    public Map<String, Object> status(ProjectDto project) {
        Job job = jobs.get(project.id());
        if (job != null && job.path.equals(project.localPath())) return result(job);
        WorkspaceRetrievalIndexService.IndexStats cached = retrieval.cachedStats(project.id(), Path.of(project.localPath()));
        if (cached == null) return Map.of("phase", "not_started", "fileCount", 0, "detail", "Index not started");
        Map<String, Object> data = new LinkedHashMap<>();
        data.put("phase", "completed");
        data.put("fileCount", cached.indexedFiles());
        data.put("scannedCount", cached.visitedFiles());
        data.put("indexedCharacters", cached.indexedCharacters());
        data.put("skippedTooLarge", cached.skippedTooLarge());
        data.put("skippedUnsupported", cached.skippedUnsupported());
        data.put("skippedUnreadable", cached.skippedUnreadable());
        data.put("skippedDirectories", cached.skippedDirectories());
        data.put("scanIncomplete", cached.scanIncomplete());
        data.put("detail", detail(cached));
        data.put("finishedAt", cached.generatedAt());
        data.putAll(watcher.status(project.id()));
        return data;
    }

    private Map<String, Object> result(Job job) {
        Map<String, Object> data = new LinkedHashMap<>();
        data.put("phase", job.phase);
        data.put("fileCount", job.files);
        data.put("scannedCount", job.scanned);
        var cached = retrieval.cachedStats(job.id, Path.of(job.path));
        data.put("indexedCharacters", cached == null ? 0L : cached.indexedCharacters());
        data.put("skippedTooLarge", cached == null ? 0 : cached.skippedTooLarge());
        data.put("skippedUnsupported", cached == null ? 0 : cached.skippedUnsupported());
        data.put("skippedUnreadable", cached == null ? 0 : cached.skippedUnreadable());
        data.put("skippedDirectories", cached == null ? 0 : cached.skippedDirectories());
        data.put("scanIncomplete", cached != null && cached.scanIncomplete());
        data.put("detail", cached != null && "completed".equals(job.phase) ? detail(cached) : job.detail);
        data.put("fresh", "completed".equals(job.phase) && !retrieval.isRescanPending(job.id, Path.of(job.path)));
        data.put("rescanPending", retrieval.isRescanPending(job.id, Path.of(job.path)));
        if (job.finishedAt != null) data.put("finishedAt", job.finishedAt);
        data.putAll(watcher.status(job.id));
        return data;
    }

    private String detail(WorkspaceRetrievalIndexService.IndexStats stats) {
        String base = stats.indexedFiles() == 0
                ? "No supported files indexed; scanned " + stats.visitedFiles() + " visible files"
                : stats.indexedCharacters() == 0 ? "Files indexed, but no readable text extracted"
                : "Ready for Chat and Agent";
        String skips = " (" + stats.skippedTooLarge() + " oversized, " + stats.skippedUnsupported()
                + " unsupported/secret, " + stats.skippedUnreadable() + " unreadable, "
                + stats.skippedDirectories() + " excluded folders)";
        return base + skips + (stats.scanIncomplete() ? " — incomplete scan: file/depth limit or filesystem error" : "");
    }

    private static final class Job {
        final String id;
        final String path;
        volatile String phase = "queued";
        volatile String detail = "Waiting for background index worker";
        volatile int files;
        volatile int scanned;
        volatile String finishedAt;
        Job(String id, String path) { this.id = id; this.path = path; }
    }

    public void untrack(String projectId) { watcher.forget(projectId); }
    @PreDestroy public void shutdown() { watcher.close(); worker.shutdownNow(); }
}
