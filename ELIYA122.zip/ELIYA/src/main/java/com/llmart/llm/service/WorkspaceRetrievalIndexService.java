package com.llmart.llm.service;

import com.llmart.llm.dto.ChatSettings;

import org.apache.tika.Tika;
import org.springframework.stereotype.Service;

import java.io.InputStream;
import java.io.OutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;
import java.security.MessageDigest;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Pattern;

/**
 * Hybrid workspace retrieval for Agent mode.
 *
 * A deterministic local lexical index is always available as the zero-dependency baseline. When semantic retrieval
 * is enabled and an embedding model is configured, the strongest lexical candidates are reranked semantically.
 * Provider/embedding failures never block the agent: retrieval falls back to lexical results automatically.
 * The live filesystem remains authoritative; returned snippets are retrieval hints only.
 */
@Service
public class WorkspaceRetrievalIndexService {
    private static final int MAX_FILES = positiveIntProperty("eliya.index.maxFiles", 40_000, 2_000, 200_000);
    private static final int MAX_SCANNED_FILES = positiveIntProperty("eliya.index.maxScannedFiles", 150_000, 5_000, 500_000);
    private static final int MAX_INDEXED_FILE_BYTES = positiveIntProperty("eliya.index.maxFileBytes", 1_500_000, 32_000, 8_000_000);
    // Office/PDF files are compressed containers, not UTF-8 text. Keep a separate, bounded
    // binary document limit rather than excluding legitimate requirements documents.
    private static final int MAX_INDEXED_DOCUMENT_BYTES = positiveIntProperty("eliya.index.maxDocumentBytes", 8_000_000, 192_000, 32_000_000);
    private static final int MAX_SAMPLED_CHARS_PER_FILE = 48_000;
    private static final int MAX_TERMS_PER_FILE = positiveIntProperty("eliya.index.maxTermsPerFile", 1_100, 300, 6_000);
    private static final int DEFAULT_RESULT_LIMIT = 8;
    private static final int DEFAULT_MAX_CHARS = 8_000;
    private static final Pattern SPLIT = Pattern.compile("[^A-Za-z0-9_.$-]+");
    private static int positiveIntProperty(String name, int fallback, int min, int max) {
        try {
            int value = Integer.parseInt(System.getProperty(name, Integer.toString(fallback)));
            return Math.max(min, Math.min(max, value));
        } catch (Exception ignored) {
            return fallback;
        }
    }

    private static final Set<String> SKIP_DIRS = Set.of(
            ".git", ".idea", ".vscode", "node_modules", "target", "build", "dist", "out", ".gradle",
            ".next", "coverage", ".venv", "venv", "env", "vendor", ".terraform", ".dart_tool", ".cache", "bin", "obj",
            ".advanced-ai-chat-backup", ".agent-build", ".agent-home", "__pycache__", ".pytest_cache", ".tox",
            ".mypy_cache", ".ruff_cache", ".svn", ".hg", ".build", "pods", "deriveddata"
    );
    private static final Set<String> INDEX_EXTENSIONS = Set.of(
            "java", "kt", "kts", "groovy", "scala", "xml", "properties", "yml", "yaml", "json", "jsonc",
            "js", "jsx", "ts", "tsx", "mjs", "cjs", "py", "go", "rs", "rb", "php", "cs", "fs", "fsx",
            "swift", "dart", "c", "h", "cc", "cpp", "cxx", "hpp", "sql", "sh", "bash", "zsh", "ps1",
            "md", "adoc", "rst", "txt", "html", "htm", "css", "scss", "sass", "less", "vue", "svelte", "tf", "tfvars", "hcl", "toml",
            "feature", "robot", "csv", "tsv", "jsonl", "ini", "conf", "config", "gradle", "mvn", "bat", "cmd",
            "graphql", "gql", "proto", "thrift", "jsp", "ftl", "mustache", "bzl", "sbt", "r", "lua", "pl",
            "pm", "ex", "exs", "clj", "cljs", "vb", "zig", "nim", "jl", "hs", "lhs", "erl", "hrl", "elm", "sol", "cabal"
    );
    private static final Set<String> DOCUMENT_EXTENSIONS = Set.of("docx", "pdf", "xlsx", "pptx");
    private static final Set<String> IMPORTANT_NAMES = Set.of(
            "pom.xml", "build.gradle", "build.gradle.kts", "settings.gradle", "settings.gradle.kts", "package.json",
            "pyproject.toml", "requirements.txt", "go.mod", "cargo.toml", "composer.json", "gemfile", "makefile",
            "cmakelists.txt", "build.xml", "jenkinsfile", "dockerfile", "compose.yml", "compose.yaml", "agents.md",
            "claude.md", "readme.md", ".gitignore", ".dockerignore", ".editorconfig",
            "yarn.lock", "gradlew", "mvnw", "workspace", "workspace.bazel", "module.bazel", "cabal.project",
            "application.properties", "application.yml", "application.yaml"
    );
    private static final Set<String> STOP = Set.of(
            "the", "and", "for", "that", "this", "with", "from", "have", "will", "would", "could", "should",
            "into", "about", "your", "you", "are", "was", "were", "how", "can", "use", "using", "file", "files",
            "project", "agent", "step", "plan", "task", "work", "working", "issue", "issues", "test", "tests",
            "then", "when", "where", "what", "which", "there", "their", "them", "need", "needs", "make"
    );

    private static final Set<String> SECRET_NAMES = Set.of(".env", "credentials", "secrets", "id_rsa", "id_ed25519");
    private final Map<String, WorkspaceIndex> cache = new ConcurrentHashMap<>();
    // An explicit Rescan fences old indexed evidence until the newest queued scan finishes.
    // The active filesystem, never a cached index or Chat history, is authoritative.
    private final Set<String> rescanPending = ConcurrentHashMap.newKeySet();
    private final Map<String, java.util.concurrent.atomic.AtomicInteger> incrementalPending = new ConcurrentHashMap<>();
    private final Map<String, String> semanticResultCache = new ConcurrentHashMap<>();
    private final Map<String,List<IndexedFile>> semanticCachedSources = new ConcurrentHashMap<>();
    private final Map<String, Long> semanticFailureUntil = new ConcurrentHashMap<>();
    private final Map<String,Set<String>> embeddingScopes = new ConcurrentHashMap<>();
    private final Map<String,GraphSnapshot> dependencyCache = new ConcurrentHashMap<>();
    private final Map<String,CallGraphSnapshot> callGraphCache = new ConcurrentHashMap<>();
    private final WorkspaceChunkIntelligence passageIndex = new WorkspaceChunkIntelligence();
    private final OpenAiCompatibleClient llm;
    private final Path indexHome = Path.of(System.getProperty("app.data-dir", "./data"), "indexes").toAbsolutePath().normalize();
    private final WorkspaceEmbeddingStore vectors = new WorkspaceEmbeddingStore(indexHome);

    public WorkspaceRetrievalIndexService(OpenAiCompatibleClient llm) {
        this.llm = llm;
    }

    /** Index a user-selected folder immediately, without starting an Agent run. */
    public IndexStats warmRoot(String projectId, Path root) {
        return refresh(AgentWorkspaceService.Workspace.forIndex(projectId, root));
    }

    public void markRescanPending(String projectId, Path root) {
        rescanPending.add(projectId + "|" + root.toAbsolutePath().normalize());
    }

    public void finishRescan(String projectId, Path root) {
        rescanPending.remove(projectId + "|" + root.toAbsolutePath().normalize());
    }

    public void markIncrementalPending(String projectId, Path root) {
        String key = projectId + "|" + root.toAbsolutePath().normalize();
        incrementalPending.computeIfAbsent(key, unused -> new java.util.concurrent.atomic.AtomicInteger()).incrementAndGet();
    }

    public void finishIncrementalPending(String projectId, Path root) {
        String key = projectId + "|" + root.toAbsolutePath().normalize();
        incrementalPending.computeIfPresent(key, (unused, count) -> count.decrementAndGet() <= 0 ? null : count);
    }

    public boolean isRescanPending(String projectId, Path root) {
        String key = projectId + "|" + root.toAbsolutePath().normalize();
        return rescanPending.contains(key) || incrementalPending.containsKey(key);
    }

    private static final String RESCAN_PENDING_EVIDENCE =
            "WORKSPACE RESCAN IN PROGRESS: previous indexed paths, symbols and source excerpts are invalid until the newest rescan completes. " +
            "Do not claim an old folder exists based on earlier Chat or Agent messages. " +
            "Verify against the current filesystem or report that the fresh index is not ready.";

    /** Never trigger a filesystem walk from a user-facing Chat or status request. */
    public IndexStats cachedStats(String projectId, Path root) {
        WorkspaceIndex cached = cache.get(projectId + "|" + root.toAbsolutePath().normalize());
        return cached == null ? null : cached.stats();
    }

    /** In-memory snapshot identity for lightweight periodic reconciliation checks.
     * Does not scan source folders or expose file content. */
    public long cachedFingerprint(String projectId, Path root) {
        WorkspaceIndex cached = cache.get(projectId + "|" + root.toAbsolutePath().normalize());
        if (cached == null) return 0L;
        long value = 1125899906842597L;
        List<IndexedFile> ordered = new ArrayList<>(cached.files());
        ordered.sort(Comparator.comparing(IndexedFile::path));
        for (IndexedFile file : ordered) {
            value = value * 31 + file.path().hashCode();
            value = value * 31 + file.size();
            value = value * 31 + file.modifiedAt();
        }
        return value;
    }


    public String retrieveCachedRoot(String projectId, Path root, String query, int limit, int maxChars) {
        if (query == null || query.isBlank()) return "";
        if (isRescanPending(projectId, root)) return RESCAN_PENDING_EVIDENCE;
        WorkspaceIndex idx = cache.get(projectId + "|" + root.toAbsolutePath().normalize());
        if (idx == null) return "";
        var ws = AgentWorkspaceService.Workspace.forIndex(projectId, root);
        Set<String> queryTerms = terms(query);
        List<ScoredFile> matched = expandDependencies(idx, score(idx, query), query);
        // A question like "how does the attached project work?" is NOT a request for a file
        // whose contents contain "attached". Always supply a real manifest and useful entry
        // points for overview/no-match requests instead of claiming that no project was provided.
        if ((isOverviewRequest(query) && !WorkspaceFlowIntelligence.flowQuestion(query))
                || queryTerms.isEmpty() || matched.isEmpty())
            return projectOverview(ws, idx, maxChars, !matched.isEmpty() ? matched : List.of());
        return render(ws, query, queryTerms, matched, limit, maxChars, "local cached lexical index");
    }

    private boolean isOverviewRequest(String query) {
        String q = query.toLowerCase(Locale.ROOT);
        boolean workspace = q.matches("(?s).*\\b(project|codebase|repository|repo|workspace|application|app)\\b.*");
        boolean overview = q.matches("(?s).*\\b(overview|architecture|structure|walkthrough|explain|describe|understand|check|inspect|list|show|contents|contains|inside)\\b.*")
                || q.matches("(?s).*\\b(how|what)\\b.*\\b(works|work|does|built)\\b.*");
        boolean inventory = q.matches("(?s).*\\b(what|which|everything|all)\\b.*\\b(there|inside|contains|available|present|files|folders|modules)\\b.*");
        return workspace && (overview || inventory);
    }

    private String projectOverview(AgentWorkspaceService.Workspace ws, WorkspaceIndex idx, int maxChars, List<ScoredFile> matches) {
        int budget = Math.max(1_000, Math.min(maxChars, 24_000));
        // The overview is the one path that displays a full file tree. Confirm candidates
        // still exist before naming them; the check is bounded by the index size and
        // does not walk a directory or contact a provider.
        List<IndexedFile> liveFiles = idx.files().stream().filter(file -> {
            Path candidate = ws.root().resolve(file.path()).normalize();
            return candidate.startsWith(ws.root()) && Files.isRegularFile(candidate)
                    && !Files.isSymbolicLink(candidate);
        }).toList();
        StringBuilder out = new StringBuilder("ACTIVE LOCAL PROJECT: indexed codebase evidence (not a chat attachment).\n");
        out.append("Existing indexed source/config files: ").append(liveFiles.size()).append(".\n");
        if (liveFiles.size() != idx.files().size()) out.append("WARNING: ")
                .append(idx.files().size() - liveFiles.size())
                .append(" indexed file(s) have been deleted or moved since the last scan. Rescan to discover new files.\n");
        out.append("Index coverage: visited=").append(idx.stats().visitedFiles())
                .append(", skippedLarge=").append(idx.stats().skippedTooLarge())
                .append(", skippedUnsupported=").append(idx.stats().skippedUnsupported())
                .append(", skippedUnreadable=").append(idx.stats().skippedUnreadable()).append(".\n");
        if (idx.stats().scanIncomplete())
            out.append("WARNING: INDEX SCAN INCOMPLETE; this overview cannot establish full application coverage.\n");
        // A compact module inventory gives the model a useful architecture map before the
        // bounded file tree. This is O(indexed files), entirely in-memory and stable.
        Map<String,Integer> modules = new TreeMap<>();
        for (IndexedFile file : liveFiles) {
            String path = file.path().replace('\\', '/');
            String segment = path.contains("/") ? path.substring(0, path.indexOf('/')) : "(root)";
            modules.merge(segment, 1, Integer::sum);
        }
        out.append("Indexed top-level modules/folders (file counts, not runtime components):\n");
        modules.entrySet().stream().sorted(Map.Entry.<String,Integer>comparingByValue().reversed()
                .thenComparing(Map.Entry::getKey)).limit(24)
                .forEach(entry -> out.append("- ").append(entry.getKey()).append(": ")
                        .append(entry.getValue()).append(" files\n"));
        if (modules.size() > 24) out.append("... [additional folders omitted]\n");
        out.append("File tree:\n");
        List<IndexedFile> sorted = new ArrayList<>(liveFiles);
        sorted.sort(Comparator.comparing(IndexedFile::path, String.CASE_INSENSITIVE_ORDER));
        int treeLimit = Math.min(6_000, budget / 3 + 750);
        for (IndexedFile file : sorted) {
            String line = "- " + file.path() + "\n";
            if (out.length() + line.length() > treeLimit) { out.append("... [file tree truncated]\n"); break; }
            out.append(line);
        }

        // Use only already-cached, bounded samples. No directory walk, network call or DB load
        // is allowed during Chat context construction. Prioritise documented entry points.
        LinkedHashMap<String, IndexedFile> selected = new LinkedHashMap<>();
        sorted.sort(Comparator.comparingInt((IndexedFile file) -> overviewPriority(file.path()))
                .thenComparing(IndexedFile::path, String.CASE_INSENSITIVE_ORDER));
        for (IndexedFile file : sorted) if (overviewPriority(file.path()) <= 3)
            selected.putIfAbsent(file.path(), file);
        for (ScoredFile match : matches)
            if (matchesCurrentFile(ws, match.file()))
                selected.putIfAbsent(match.file().path(), match.file());
        for (IndexedFile file : sorted) selected.putIfAbsent(file.path(), file);
        out.append("\nRelevant project entry points / cached source excerpts:\n");
        int included = 0;
        for (IndexedFile file : selected.values()) {
            if (included >= 10 || out.length() >= budget - 300) break;
            if (file.sample().isBlank()) continue;
            int room = Math.min(1_700, budget - out.length() - file.path().length() - 100);
            if (room < 120) break;
            String snippet = redact(clip(file.sample().replace("\r", ""), room));
            out.append("\n--- ").append(file.path()).append(" ---\n").append(snippet).append('\n');
            included++;
        }
        out.append("\nThis is a bounded overview. For detailed implementation questions, retrieve matching files; ")
                .append("do not infer behavior unsupported by the excerpts.\n");
        return clip(out.toString(), budget);
    }

    private int overviewPriority(String path) {
        String name = Path.of(path).getFileName().toString().toLowerCase(Locale.ROOT);
        if (name.equals("readme.md") || name.equals("agents.md")) return 0;
        if (name.equals("pom.xml") || name.equals("package.json") || name.equals("build.gradle") || name.equals("pyproject.toml")) return 1;
        if (name.equals("application.yml") || name.equals("application.yaml") || name.equals("application.properties")) return 2;
        if (name.equals("app.java") || name.equals("main.java") || name.equals("main.py") || name.equals("index.ts")
                || name.equals("index.js") || name.equals("app.ts") || name.equals("app.js") || name.equals("server.js")) return 3;
        if (name.endsWith("application.java") || name.endsWith("controller.java") || name.endsWith("service.java")) return 4;
        if (isImportant(path)) return 5;
        return 6;
    }

    public String retrieveRoot(String projectId, Path root, String query, int limit, int maxChars) {
        return retrieve(AgentWorkspaceService.Workspace.forIndex(projectId, root), query, limit, maxChars);
    }

    public IndexStats warm(AgentWorkspaceService.Workspace ws) {
        WorkspaceIndex idx = cache.get(cacheKey(ws));
        // Agent can inspect live files with its tools while the independent background
        // worker builds the index. Never run a duplicate directory walk in Agent startup.
        return idx == null ? new IndexStats(0, 0, "pending") : idx.stats();
    }

    public IndexStats refresh(AgentWorkspaceService.Workspace ws) {
        WorkspaceIndex idx = index(ws, true);
        return idx.stats();
    }

    public String retrieve(AgentWorkspaceService.Workspace ws, String query) {
        return retrieve(ws, query, DEFAULT_RESULT_LIMIT, DEFAULT_MAX_CHARS);
    }

    public String retrieve(AgentWorkspaceService.Workspace ws, String query, int limit, int maxChars) {
        return retrieveInternal(ws, query, limit, maxChars, null);
    }

    /**
     * Hybrid retrieval: keep the deterministic lexical index as the safety baseline, then semantically rerank
     * the strongest live candidates with the configured embedding model. Any embedding/provider failure silently
     * falls back to lexical retrieval so repository work never depends on a secondary model.
     */
    public String retrieveHybrid(AgentWorkspaceService.Workspace ws, String query, int limit, int maxChars,
                                 String apiKey, ChatSettings settings, java.util.function.BooleanSupplier cancelled) {
        if (ws != null && isRescanPending(ws.projectId(), ws.root())) return RESCAN_PENDING_EVIDENCE;
        if (ws == null || query == null || query.isBlank() || settings == null || !settings.semanticRetrievalEnabled())
            return retrieve(ws, query, limit, maxChars);
        String embeddingModel = settings.embeddingModelName();
        if (embeddingModel.isBlank() || apiKey == null || apiKey.isBlank()) return retrieve(ws, query, limit, maxChars);
        String failureKey = settings.baseUrl() + "|" + embeddingModel;
        Long blockedUntil = semanticFailureUntil.get(failureKey);
        if (blockedUntil != null && blockedUntil > System.nanoTime()) return retrieve(ws, query, limit, maxChars);

        WorkspaceIndex idx = cache.get(cacheKey(ws));
        if (idx == null) return "";
        String cacheKey = cacheKey(ws) + "|" + idx.stats().generatedAt() + "|" + embeddingModel + "|" +
                Integer.toHexString(query.strip().toLowerCase(Locale.ROOT).hashCode()) + "|" + limit + "|" + maxChars;
        String cached = semanticResultCache.get(cacheKey);
        if (cached != null) {
            List<IndexedFile> evidence = semanticCachedSources.get(cacheKey);
            if (evidence != null && evidence.stream().allMatch(file -> matchesCurrentFile(ws, file)))
                return cached;
            semanticResultCache.remove(cacheKey);
            semanticCachedSources.remove(cacheKey);
        }

        try {
            List<ScoredFile> lexical = expandDependencies(idx, score(idx, query), query).stream()
                    .filter(hit -> matchesCurrentFile(ws, hit.file())).toList();
            int candidateCount = Math.min(48, lexical.size());
            List<ScoredFile> candidates = new ArrayList<>(lexical.subList(0, candidateCount));
            String scope = WorkspaceEmbeddingStore.scope(cacheKey(ws), settings.baseUrl(), embeddingModel);
            embeddingScopes.computeIfAbsent(cacheKey(ws), key -> ConcurrentHashMap.newKeySet()).add(scope);
            Map<String,WorkspaceEmbeddingStore.Entry> fresh = new LinkedHashMap<>();
            List<String> missing = new ArrayList<>();
            List<Integer> missingIndexes = new ArrayList<>();
            List<double[]> candidateVectors = new ArrayList<>(Collections.nCopies(candidateCount, null));
            for (int i = 0; i < candidates.size(); i++) {
                IndexedFile file = candidates.get(i).file();
                String fingerprint = WorkspaceEmbeddingStore.fingerprint(file.sample(), file.size(), file.modifiedAt());
                double[] stored = vectors.get(scope, file.path(), fingerprint);
                if (stored == null) {
                    missingIndexes.add(i);
                    missing.add("path: " + file.path() + "\n" + redact(clip(file.sample(), 5_000)));
                } else candidateVectors.set(i, stored);
            }
            // Optional passage-level vectors: a small number of the strongest lexical
            // candidates receive a precise symbol/line-aligned vector. Persist by passage
            // fingerprint so unchanged chunks are reused across requests.
            record ChunkCandidate(int fileIndex, String key, String fingerprint, String text, double[] cached) { }
            List<ChunkCandidate> chunkCandidates = new ArrayList<>();
            int chunkFiles = positiveIntProperty("eliya.semantic.chunkCandidates", 8, 1, 16);
            Set<String> searchTerms = terms(query);
            for (int i = 0; i < Math.min(chunkFiles, candidates.size()); i++) {
                IndexedFile file = candidates.get(i).file();
                Path path = ws.root().resolve(file.path()).normalize();
                List<WorkspaceChunkIntelligence.Passage> parts = isDocument(path)
                        ? WorkspaceChunkIntelligence.rankText(file.path(), file.sample(), searchTerms, 1)
                        : passageIndex.find(ws.root(), file.path(), searchTerms, 1);
                for (WorkspaceChunkIntelligence.Passage passage : parts) {
                    String id = "#chunk#" + file.path() + ":" + passage.startLine();
                    String fingerprint = WorkspaceEmbeddingStore.fingerprint(passage.text(), file.size(), file.modifiedAt());
                    chunkCandidates.add(new ChunkCandidate(i, id, fingerprint, passage.text(), vectors.get(scope, id, fingerprint)));
                }
            }
            // Files and passages share a single batched embedding request, avoiding an
            // extra provider round trip. Missing provider -> lexical evidence fallback.
            List<String> inputs = new ArrayList<>(missing.size() + chunkCandidates.size() + 1);
            inputs.add(query); inputs.addAll(missing);
            for (ChunkCandidate part : chunkCandidates) if (part.cached() == null)
                inputs.add("path: " + candidates.get(part.fileIndex()).file().path() + "\n" + redact(part.text()));
            List<double[]> resultVectors = llm.embed(apiKey, settings.baseUrl(), embeddingModel, inputs,
                    cancelled == null ? () -> false : cancelled);
            if (resultVectors.size() != inputs.size()) return retrieve(ws, query, limit, maxChars);
            double[] queryVector = resultVectors.get(0);
            for (int i = 0; i < missingIndexes.size(); i++) {
                int index = missingIndexes.get(i);
                double[] vector = resultVectors.get(i + 1);
                if (vector == null || vector.length != queryVector.length) return retrieve(ws, query, limit, maxChars);
                IndexedFile file = candidates.get(index).file();
                candidateVectors.set(index, vector);
                fresh.put(file.path(), WorkspaceEmbeddingStore.entry(
                        WorkspaceEmbeddingStore.fingerprint(file.sample(), file.size(), file.modifiedAt()), vector));
            }
            Map<Integer,List<double[]>> chunkVectors = new HashMap<>();
            int vectorOffset = 1 + missing.size();
            for (ChunkCandidate part : chunkCandidates) {
                double[] vector = part.cached() == null ? resultVectors.get(vectorOffset++) : part.cached();
                if (vector == null || vector.length != queryVector.length) continue;
                chunkVectors.computeIfAbsent(part.fileIndex(), ignored -> new ArrayList<>()).add(vector);
                if (part.cached() == null) fresh.put(part.key(), WorkspaceEmbeddingStore.entry(part.fingerprint(), vector));
            }
            vectors.putAll(scope, fresh);
            semanticFailureUntil.remove(failureKey);
            double maxLexical = candidates.stream().mapToDouble(ScoredFile::score).max().orElse(1.0);
            LinkedHashMap<String,ScoredFile> fusedByPath = new LinkedHashMap<>();
            for (int i = 0; i < candidates.size(); i++) {
                ScoredFile candidate = candidates.get(i);
                double semantic = Math.max(-1.0, Math.min(1.0, cosine(queryVector, candidateVectors.get(i))));
                for (double[] passageVector : chunkVectors.getOrDefault(i, List.of()))
                    semantic = Math.max(semantic, cosine(queryVector, passageVector));
                double semantic01 = (semantic + 1.0) / 2.0;
                double lexical01 = Math.min(1.0, candidate.score() / Math.max(1.0, maxLexical));
                double fused = (lexical01 * 0.48) + (semantic01 * 0.52);
                fusedByPath.put(candidate.file().path(), new ScoredFile(candidate.file(), fused * 100.0));
            }
            // Previously indexed semantic neighbors can surface even when none of the query's
            // words appear in a file. Only live, fingerprint-matching cache entries qualify.
            Map<String,IndexedFile> live = new HashMap<>();
            for (IndexedFile file : idx.files()) live.put(file.path(), file);
            for (var stored : vectors.snapshot(scope).entrySet()) {
                IndexedFile file = live.get(stored.getKey());
                if (file == null || fusedByPath.containsKey(file.path())) continue;
                WorkspaceEmbeddingStore.Entry vector = stored.getValue();
                if (!WorkspaceEmbeddingStore.fingerprint(file.sample(), file.size(), file.modifiedAt()).equals(vector.fingerprint())) continue;
                if (vector.vector().length != queryVector.length) continue;
                double proximity = cosine(queryVector, vector.vector());
                if (proximity >= 0.38) fusedByPath.put(file.path(), new ScoredFile(file, proximity * 52.0));
            }
            List<ScoredFile> reranked = new ArrayList<>(fusedByPath.values());
            reranked.sort(Comparator.comparingDouble(ScoredFile::score).reversed().thenComparing(v -> v.file().path()));
            String result = render(ws, query, terms(query), reranked, limit, maxChars,
                    "hybrid lexical + semantic reranking via " + embeddingModel);
            if (!result.isBlank()) {
                if (semanticResultCache.size() > 400) {
                    semanticResultCache.clear();
                    semanticCachedSources.clear();
                }
                // Guard provider-backed cached answers against external deletions and edits,
                // even when the user has not pressed Rescan yet.
                semanticCachedSources.put(cacheKey, reranked.stream().limit(Math.max(1, Math.min(limit, 20)))
                        .map(ScoredFile::file).toList());
                semanticResultCache.put(cacheKey, result);
            }
            return result;
        } catch (Exception ignored) {
            // A missing/unsupported embedding endpoint must not add latency to every subsequent request.
            semanticFailureUntil.put(failureKey, System.nanoTime() + java.util.concurrent.TimeUnit.MINUTES.toNanos(2));
            return retrieve(ws, query, limit, maxChars);
        }
    }

    private String retrieveInternal(AgentWorkspaceService.Workspace ws, String query, int limit, int maxChars, String mode) {
        if (ws == null || query == null || query.isBlank()) return "";
        if (isRescanPending(ws.projectId(), ws.root())) return RESCAN_PENDING_EVIDENCE;
        WorkspaceIndex idx = cache.get(cacheKey(ws));
        if (idx == null) return "";
        Set<String> terms = terms(query);
        if (terms.isEmpty()) return "";
        return render(ws, query, terms, expandDependencies(idx, score(idx, query), query), limit, maxChars, mode == null ? "local structural + lexical index" : mode);
    }

    private List<ScoredFile> score(WorkspaceIndex idx, String query) {
        Set<String> terms = terms(query);
        if (terms.isEmpty()) return List.of();
        // BM25 rewards rare matching symbols and normalises repetitive large files. Filename and
        // exact-symbol boosts keep entry points discoverable without relying on a remote model.
        Map<String,Integer> df = new HashMap<>();
        Map<String,Integer> lengths = new HashMap<>();
        double totalLength = 0;
        for (IndexedFile file : idx.files()) {
            int fileLength = file.termFrequency().values().stream().mapToInt(Integer::intValue).sum();
            lengths.put(file.path(), fileLength);
            totalLength += fileLength;
            for (String term : terms) if (file.termFrequency().containsKey(term)) df.merge(term, 1, Integer::sum);
        }
        double avgLength = Math.max(1.0, totalLength / Math.max(1, idx.files().size()));
        String queryLower = query == null ? "" : query.strip().toLowerCase(Locale.ROOT);
        List<ScoredFile> scored = new ArrayList<>();
        for (IndexedFile file : idx.files()) {
            double score = 0.0;
            int hits = 0;
            int length = lengths.getOrDefault(file.path(), 0);
            String lowPath = file.path().toLowerCase(Locale.ROOT);
            String baseName = Path.of(file.path()).getFileName().toString().toLowerCase(Locale.ROOT);
            for (String term : terms) {
                if (lowPath.contains(term)) { score += baseName.contains(term) ? 8.0 : 3.0; hits++; }
                int tf = file.termFrequency().getOrDefault(term, 0);
                if (tf <= 0) continue;
                hits++;
                double idf = Math.log(1.0 + (idx.files().size() - df.getOrDefault(term, 0) + 0.5) /
                        (df.getOrDefault(term, 0) + 0.5));
                score += 2.0 * idf * tf * 2.2 / (tf + 1.2 * (0.25 + 0.75 * length / avgLength));
            }
            // Exact symbol matching is stronger than an incidental token occurrence in a large file.
            for (String symbol : file.structure().symbols().keySet()) {
                String name = symbol.substring(symbol.indexOf(':') + 1).toLowerCase(Locale.ROOT);
                if (exactSymbolMention(queryLower, name)) score += 14.0;
                else if (terms.contains(name)) score += 9.0;
            }
            if (score > 0) {
                score *= (1.0 + Math.min(0.6, 0.6 * hits / Math.max(1, terms.size() * 2)));
                if (isImportant(file.path())) score += 1.5;
                if (queryLower.length() > 4 && file.sample().toLowerCase(Locale.ROOT).contains(queryLower)) score += 12.0;
                scored.add(new ScoredFile(file, score));
            }
        }
        scored.sort(Comparator.comparingDouble(ScoredFile::score).reversed().thenComparing(v -> v.file().path()));
        return scored;
    }

    /**
     * Lightweight maximal-marginal-relevance selection after lexical/semantic ranking.
     * Keep the highest-ranked evidence first, then avoid flooding a bounded context with
     * near-duplicate paths in one subdirectory. Fully deterministic, bounded at 48 candidates,
     * and contains no provider calls or filesystem reads.
     */
    private List<ScoredFile> diversifyEvidence(List<ScoredFile> ranked, int wanted) {
        if (ranked.size() <= 2 || wanted <= 2) return ranked;
        int poolSize = Math.min(48, ranked.size());
        List<ScoredFile> pool = new ArrayList<>(ranked.subList(0, poolSize));
        List<ScoredFile> selected = new ArrayList<>(poolSize);
        // Never demote the strongest exact/semantic hit.
        selected.add(pool.remove(0));
        double maxScore = Math.max(1.0, selected.get(0).score());
        while (!pool.isEmpty() && selected.size() < Math.min(wanted, poolSize)) {
            ScoredFile best = null;
            double bestValue = -Double.MAX_VALUE;
            for (ScoredFile candidate : pool) {
                String path = candidate.file().path().toLowerCase(Locale.ROOT).replace('\\', '/');
                String folder = path.contains("/") ? path.substring(0,path.lastIndexOf('/')) : "";
                double redundancy = 0;
                for (ScoredFile previous : selected) {
                    String prior = previous.file().path().toLowerCase(Locale.ROOT).replace('\\', '/');
                    String priorFolder = prior.contains("/") ? prior.substring(0,prior.lastIndexOf('/')) : "";
                    if (folder.equals(priorFolder)) redundancy = Math.max(redundancy, 1.0);
                    else if (!folder.isEmpty() && !priorFolder.isEmpty() &&
                            folder.split("/")[0].equals(priorFolder.split("/")[0])) redundancy = Math.max(redundancy, 0.32);
                }
                double value = 0.86 * (candidate.score() / maxScore) - 0.14 * redundancy;
                if (value > bestValue || (value == bestValue && best != null &&
                        candidate.file().path().compareTo(best.file().path()) < 0)) {
                    bestValue = value;
                    best = candidate;
                }
            }
            selected.add(best);
            pool.remove(best);
        }
        // Add remaining results in original ranking order for absent/stale files.
        Set<String> used = new HashSet<>();
        for (ScoredFile file : selected) used.add(file.file().path());
        for (ScoredFile file : ranked) if (used.add(file.file().path())) selected.add(file);
        return selected;
    }

    private String render(AgentWorkspaceService.Workspace ws, String query, Set<String> terms, List<ScoredFile> scored,
                          int limit, int maxChars, String mode) {
        int wanted = Math.max(1, Math.min(limit, 20));
        int budget = Math.max(1_000, Math.min(maxChars, 48_000));
        StringBuilder out = new StringBuilder();
        out.append("WORKSPACE RETRIEVAL HINTS — ").append(mode).append("; live files/tools are authoritative.\n");
        WorkspaceIndex evidenceIndex = idxFor(ws);
        if (evidenceIndex != null) {
            IndexStats coverage = evidenceIndex.stats();
            out.append("Index coverage: indexed=").append(coverage.indexedFiles())
                    .append(", visited=").append(coverage.visitedFiles())
                    .append(", skippedLarge=").append(coverage.skippedTooLarge())
                    .append(", skippedUnsupported=").append(coverage.skippedUnsupported())
                    .append(", skippedUnreadable=").append(coverage.skippedUnreadable()).append('\n');
            if (coverage.scanIncomplete()) out.append("WARNING: INDEX SCAN INCOMPLETE; hits are partial. " +
                    "Do not conclude that an unmatched requirement or symbol is absent; use live reads.\n");
        }
        out.append("Evidence is ranked and bounded, NOT an exhaustive proof of requirements coverage. " +
                "Identify exact source references and explicitly mark unverified claims.\n");
        out.append("queryTerms: ").append(String.join(", ", terms)).append('\n');
        if (WorkspaceFlowIntelligence.flowQuestion(query))
            out.append(flowEvidence(idxFor(ws), query, Math.min(2_600, budget / 4), scored));
        int emitted = 0;
        for (ScoredFile match : diversifyEvidence(scored, wanted)) {
            if (emitted >= wanted || out.length() >= budget) break;
            Path file = ws.root().resolve(match.file().path()).normalize();
            if (!file.startsWith(ws.root()) || !Files.isRegularFile(file) || Files.isSymbolicLink(file)) continue;
            // File changes during an asynchronous refresh are possible; flag any mismatch instead of
            // treating old symbols/dependencies as verified current-source evidence.
            boolean stale = true;
            try {
                stale = Files.size(file) != match.file().size()
                        || Files.getLastModifiedTime(file).toMillis() != match.file().modifiedAt();
            } catch (IOException ignored) { /* stale remains true */ }
            // Files.readAllLines on Office/PDF containers yields binary garbage or a
            // decoding error. Use the text extracted into the bounded cache instead.
            String snippet = isDocument(file) ? excerptAroundTerms(match.file().sample(), terms, 1_700) : currentSnippet(file, terms, 1_700);
            // Prefer precise, on-demand chunk evidence with source line ranges. This avoids
            // sending whole file excerpts and does not require an embedding provider.
            List<WorkspaceChunkIntelligence.Passage> passages = isDocument(file)
                    ? WorkspaceChunkIntelligence.rankText(match.file().path(), match.file().sample(), terms, 2)
                    : passageIndex.find(ws.root(), match.file().path(), terms, 2);
            if (!passages.isEmpty()) {
                StringBuilder pinpoint = new StringBuilder();
                for (WorkspaceChunkIntelligence.Passage passage : passages) {
                    if (!pinpoint.isEmpty()) pinpoint.append("\n");
                    pinpoint.append(isDocument(file) ? "Extracted-text lines " : "Source lines ")
                            .append(passage.startLine()).append("-").append(passage.endLine())
                            .append(":\n").append(clip(passage.text(), 1_350));
                    if (pinpoint.length() > 2_500) break;
                }
                snippet = pinpoint.toString();
            }
            if (snippet.isBlank()) snippet = clip(match.file().sample().replace("\r", "").strip(), 1_300);
            snippet = redact(snippet);
            WorkspaceCodeIntelligence.Structure structure = match.file().structure();
            String symbols = structure.symbols().entrySet().stream().limit(12)
                    .map(entry -> entry.getKey() + "@" + entry.getValue()).reduce((a, b) -> a + ", " + b).orElse("");
            if (!symbols.isBlank()) snippet = "Symbols (type:name@line): " + symbols + "\n" + snippet;
            if (!structure.references().isEmpty()) snippet = "Direct references: " + clip(String.join(", ", structure.references()), 360) + "\n" + snippet;
            String block = "\n- " + match.file().path() + " (score=" + String.format(Locale.ROOT, "%.1f", match.score()) + ")" +
                    (stale ? " [STALE_INDEX: file modified since indexing; re-index before relying on symbols]" : "") +
                    (snippet.isBlank() ? "" : "\n  " + snippet.replace("\n", "\n  "));
            if (out.length() + block.length() > budget) break;
            out.append(block);
            emitted++;
        }
        return emitted == 0 ? "" : out.toString();
    }

    private boolean codeFile(String rel) {
        return rel.matches("(?i).*\\.(java|js|jsx|ts|tsx|mjs|cjs|feature|py|go|cs)$");
    }

    private WorkspaceCodeIntelligence.Structure structure(Path file, String rel, String sample) {
        if (!codeFile(rel)) return WorkspaceCodeIntelligence.Structure.EMPTY;
        try {
            // Parse the entire small/medium source file, not a truncated prefix/suffix.
            String text = Files.size(file) <= 350_000 ? Files.readString(file, StandardCharsets.UTF_8) : sample;
            return WorkspaceCodeIntelligence.analyse(rel, text);
        } catch (Exception ignored) { return WorkspaceCodeIntelligence.analyse(rel, sample); }
    }

    private boolean exactSymbolMention(String query, String symbol) {
        if (symbol.length() < 3) return false;
        int offset = query.indexOf(symbol);
        while (offset >= 0) {
            int end = offset + symbol.length();
            if ((offset == 0 || !Character.isLetterOrDigit(query.charAt(offset - 1))) &&
                    (end == query.length() || !Character.isLetterOrDigit(query.charAt(end)))) return true;
            offset = query.indexOf(symbol, offset + 1);
        }
        return false;
    }

    private Map<String,Set<String>> dependencies(WorkspaceIndex idx) {
        GraphSnapshot previous = dependencyCache.get(idx.root());
        if (previous != null && previous.index() == idx) return previous.graph();
        synchronized (dependencyCache) {
            previous = dependencyCache.get(idx.root());
            if (previous != null && previous.index() == idx) return previous.graph();
            Map<String,Set<String>> built = buildDependencies(idx);
            WorkspaceFlowIntelligence.Graph flow = WorkspaceFlowIntelligence.build(idx.files().stream()
                    .map(file -> new WorkspaceFlowIntelligence.Source(file.path(), file.sample())).toList());
            for (WorkspaceFlowIntelligence.Link link : flow.links()) {
                built.computeIfAbsent(link.caller(), k -> new LinkedHashSet<>()).add(link.controller());
                built.computeIfAbsent(link.controller(), k -> new LinkedHashSet<>()).add(link.caller());
            }
            if (dependencyCache.size() > 32) dependencyCache.clear();
            dependencyCache.put(idx.root(), new GraphSnapshot(idx, built, flow.links()));
            return built;
        }
    }

    /** Infer first-order imports and reverse dependents. Ambiguous names are deliberately ignored. */
    private Map<String,Set<String>> buildDependencies(WorkspaceIndex idx) {
        Map<String,Set<String>> byName = new HashMap<>();
        Map<String,Set<String>> byQualified = new HashMap<>();
        Map<String,Set<String>> byStep = new HashMap<>();
        for (IndexedFile file : idx.files()) {
            String qualified = file.path().replace('\\', '/').toLowerCase(Locale.ROOT);
            byQualified.computeIfAbsent(qualified, key -> new LinkedHashSet<>()).add(file.path());
            for (int slash = qualified.indexOf('/'); slash >= 0; slash = qualified.indexOf('/', slash + 1))
                byQualified.computeIfAbsent(qualified.substring(slash + 1), key -> new LinkedHashSet<>()).add(file.path());
            String base = file.path().replace('\\', '/');
            base = base.substring(base.lastIndexOf('/') + 1).replaceFirst("\\.[^.]+$", "").toLowerCase(Locale.ROOT);
            byName.computeIfAbsent(base, key -> new LinkedHashSet<>()).add(file.path());
            for (String symbol : file.structure().symbols().keySet()) {
                String name = symbol.substring(symbol.indexOf(':') + 1).toLowerCase(Locale.ROOT);
                byName.computeIfAbsent(name, key -> new LinkedHashSet<>()).add(file.path());
            }
            for (String step : file.structure().steps())
                byStep.computeIfAbsent(step, key -> new LinkedHashSet<>()).add(file.path());
        }
        Map<String,Set<String>> graph = new HashMap<>();
        for (IndexedFile file : idx.files()) {
            if (file.path().toLowerCase(Locale.ROOT).endsWith(".feature")) {
                for (String step : file.structure().steps()) {
                    for (String matching : byStep.getOrDefault(step, Set.of())) {
                        if (!matching.equals(file.path())) {
                            graph.computeIfAbsent(file.path(), k -> new LinkedHashSet<>()).add(matching);
                            graph.computeIfAbsent(matching, k -> new LinkedHashSet<>()).add(file.path());
                        }
                    }
                }
            }
            for (String ref : file.structure().references()) {
                String clean = ref.replace('\\', '/').replaceFirst("\\.(?:java|ts|tsx|js|jsx)$", "");
                String base = clean.substring(clean.lastIndexOf('/') + 1).toLowerCase(Locale.ROOT);
                Set<String> matches = Set.of();
                if (!ref.startsWith(".") && !ref.startsWith("/") && ref.contains(".")) {
                    String qualified = ref.replace('.', '/').toLowerCase(Locale.ROOT);
                    for (String suffix : List.of(".java", ".py", "/__init__.py", ".cs", ".go")) {
                        Set<String> found = byQualified.getOrDefault(qualified + suffix, Set.of());
                        if (found.size() == 1) { matches = found; break; }
                    }
                }
                if (matches.isEmpty() && ref.startsWith(".")) {
                    try {
                        String sourcePath = file.path().replace('\\', '/');
                        Path parent = Path.of(sourcePath).getParent();
                        Path resolved = (parent == null ? Path.of("") : parent).resolve(ref).normalize();
                        if (!resolved.isAbsolute() && !resolved.startsWith("..")) {
                            String target = resolved.toString().replace('\\','/').toLowerCase(Locale.ROOT);
                            for (String suffix : List.of(".ts", ".tsx", ".js", ".jsx", ".mjs", ".cjs", "/index.ts", "/index.js", "/index.tsx")) {
                                Set<String> found = byQualified.getOrDefault(target + suffix, Set.of());
                                if (found.size() == 1) { matches = found; break; }
                            }
                        }
                    } catch (Exception ignored) { /* invalid paths must not break indexing */ }
                }
                if (matches.isEmpty()) matches = byName.getOrDefault(base, Set.of());
                if (matches.isEmpty()) {
                    String simple = base.substring(base.lastIndexOf('.') + 1);
                    matches = byName.getOrDefault(simple, Set.of());
                }
                if (matches.size() == 1) {
                    String target = matches.iterator().next();
                    if (!target.equals(file.path())) {
                        graph.computeIfAbsent(file.path(), k -> new LinkedHashSet<>()).add(target);
                        graph.computeIfAbsent(target, k -> new LinkedHashSet<>()).add(file.path());
                    }
                }
            }
        }
        return graph;
    }

    private List<ScoredFile> expandDependencies(WorkspaceIndex idx, List<ScoredFile> ranking, String query) {
        if (ranking.isEmpty()) return ranking;
        Map<String,IndexedFile> lookup = new HashMap<>();
        for (IndexedFile file : idx.files()) lookup.put(file.path(), file);
        Map<String,Set<String>> graph = dependencies(idx);
        LinkedHashMap<String,ScoredFile> selected = new LinkedHashMap<>();
        for (ScoredFile match : ranking) selected.put(match.file().path(), match);
        boolean flow = WorkspaceFlowIntelligence.flowQuestion(query);
        int n = 0;
        for (ScoredFile match : ranking) {
            if (++n > (flow ? 5 : 3)) break;
            // Flow questions get two bounded hops (e.g. UI -> API -> imported service),
            // ordinary Chat/Agent requests keep the existing inexpensive first-hop behavior.
            LinkedHashMap<String,Double> frontier = new LinkedHashMap<>();
            frontier.put(match.file().path(), match.score());
            for (int depth = 0; depth < (flow ? 2 : 1); depth++) {
                LinkedHashMap<String,Double> next = new LinkedHashMap<>();
                for (Map.Entry<String,Double> parent : frontier.entrySet()) {
                    int neighbors = 0;
                    for (String related : graph.getOrDefault(parent.getKey(), Set.of())) {
                        if (++neighbors > 4) break;
                        if (!lookup.containsKey(related)) continue;
                        double propagated = Math.max(0.1, parent.getValue() * 0.70);
                        selected.putIfAbsent(related, new ScoredFile(lookup.get(related), propagated));
                        if (!related.equals(match.file().path()) && next.size() < 12)
                            next.putIfAbsent(related, propagated);
                    }
                }
                frontier = next;
                if (frontier.isEmpty()) break;
            }
        }
        ArrayList<ScoredFile> result = new ArrayList<>(selected.values());
        result.sort(Comparator.comparingDouble(ScoredFile::score).reversed().thenComparing(v -> v.file().path()));
        return result;
    }

    /** Deterministic read-only task-scope gate: hints do not constitute proof of implementation. */
    public String impactReport(AgentWorkspaceService.Workspace ws, String task, int maxChars) {
        if (ws == null || task == null || task.isBlank()) return "";
        WorkspaceIndex idx = cache.get(cacheKey(ws));
        if (isRescanPending(ws.projectId(), ws.root())) return RESCAN_PENDING_EVIDENCE;
        if (idx == null) return "INDEX NOT READY: inspect actual files using glob, grep and read before editing.";
        List<ScoredFile> ranked = score(idx, task).stream()
                .filter(hit -> matchesCurrentFile(ws, hit.file())).toList();
        StringBuilder out = new StringBuilder("TASK EVIDENCE / IMPACT CHECK (index hints, not permission to edit):\n");
        if (idx.stats().scanIncomplete()) out.append("WARNING: scan incomplete; use live discovery tools for missing files.\n");
        if (ranked.isEmpty()) out.append("No matching indexed symbols or files. Use glob/grep/read before editing; do not invent filenames or APIs.\n");
        else {
            Map<String,Set<String>> graph = dependencies(idx);
            for (int i = 0; i < Math.min(5, ranked.size()); i++) {
                ScoredFile candidate = ranked.get(i);
                out.append("- Candidate: ").append(candidate.file().path());
                if (!candidate.file().structure().symbols().isEmpty())
                    out.append("; symbols ").append(clip(String.join(", ", candidate.file().structure().symbols().keySet()), 250));
                out.append("; inferred related files ")
                        .append(clip(graph.getOrDefault(candidate.file().path(), Set.of()).stream()
                                .filter(relative -> Files.isRegularFile(ws.root().resolve(relative)))
                                .collect(java.util.stream.Collectors.joining(", ")), 250)).append('\n');
            }
        }
        out.append("REQUIRED: open the CURRENT source of each file to change; confirm called methods, imports, dependent tests and configuration; " +
                "expand discovery if evidence is insufficient; compile/run targeted tests and report actual results. " +
                "Do not modify a file solely on the basis of a cached excerpt.\n");
        return clip(out.toString(), Math.max(600, Math.min(maxChars, 7_000)));
    }


    /** Conservative source-location pointers for flow questions; never state that other layers were verified. */
    private String flowEvidence(WorkspaceIndex idx, String query, int budget, List<ScoredFile> ranking) {
        if (idx == null || budget < 350) return "";
        dependencies(idx); // lazily build once per index generation, including uniquely matched HTTP routes
        GraphSnapshot snapshot = dependencyCache.get(idx.root());
        if (snapshot == null || snapshot.index() != idx) return "";
        Set<String> seeds = new LinkedHashSet<>();
        for (int i = 0; i < Math.min(18, ranking.size()); i++) seeds.add(ranking.get(i).file().path());
        StringBuilder result = new StringBuilder();
        int count = 0;
        for (WorkspaceFlowIntelligence.Link link : snapshot.httpLinks()) {
            if (!seeds.contains(link.caller()) && !seeds.contains(link.controller())) continue;
            if (!Files.isRegularFile(Path.of(idx.root()).resolve(link.caller()))
                    || !Files.isRegularFile(Path.of(idx.root()).resolve(link.controller()))) continue;
            String next = "- " + link.verb() + " " + link.route() + ": " + link.caller() + ":L" +
                    link.callerLine() + " -> " + link.controller() + ":L" + link.controllerLine() + "\n";
            if (result.length() + next.length() + 160 > budget || count >= 10) break;
            if (count == 0) result.append("MATCHED HTTP FLOW EDGES (literal URL + method):\n");
            result.append(next);
            count++;
        }
        WorkspaceCallGraphService.Graph callGraph = callGraph(idx);
        int inspected = 0;
        for (WorkspaceCallGraphService.Edge edge : callGraph.edges()) {
            if (!seeds.contains(edge.from()) && !seeds.contains(edge.to())) continue;
            if (!Files.isRegularFile(Path.of(idx.root()).resolve(edge.from()))
                    || !Files.isRegularFile(Path.of(idx.root()).resolve(edge.to()))) continue;
            String next = "- [" + edge.kind() + "] " + edge.from() + ":L" + edge.fromLine() +
                    " (" + edge.caller() + ") -> " + edge.to() + ":L" + edge.toLine() +
                    " (" + edge.callee() + ")\n";
            if (result.length() + next.length() + 190 > budget || inspected >= 12) break;
            if (inspected == 0) result.append("STATIC CODE RELATIONSHIPS (unique target resolution; unverified at runtime):\n");
            result.append(next); inspected++;
        }
        if (count == 0 && inspected == 0) return "";
        result.append("Edges are bounded static evidence, not proof of runtime behavior. " +
                "Dynamic dispatch, reflection, generated clients and ambiguous imports are excluded. Verify with live source and tests.\n");
        if (callGraph.truncated()) result.append("WARNING: graph construction was bounded; results may be incomplete.\n");
        return result.toString();
    }

    private WorkspaceCallGraphService.Graph callGraph(WorkspaceIndex idx) {
        CallGraphSnapshot previous = callGraphCache.get(idx.root());
        if (previous != null && previous.index() == idx) return previous.graph();
        synchronized (callGraphCache) {
            previous = callGraphCache.get(idx.root());
            if (previous != null && previous.index() == idx) return previous.graph();
            WorkspaceCallGraphService.Graph graph = WorkspaceCallGraphService.build(idx.files().stream()
                    .map(file -> new WorkspaceCallGraphService.Source(file.path(), file.sample(), file.structure())).toList());
            if (callGraphCache.size() > 24) callGraphCache.clear();
            callGraphCache.put(idx.root(), new CallGraphSnapshot(idx, graph));
            return graph;
        }
    }

    private record CallGraphSnapshot(WorkspaceIndex index, WorkspaceCallGraphService.Graph graph) {}

    private WorkspaceIndex idxFor(AgentWorkspaceService.Workspace ws) {
        return cache.get(cacheKey(ws));
    }

    /** Small, read-only plan primer. No network, filesystem scanning or additional LLM calls. */
    public String flowPlanHints(AgentWorkspaceService.Workspace ws, String task, int maxChars) {
        if (ws == null || !WorkspaceFlowIntelligence.flowQuestion(task)) return "";
        WorkspaceIndex idx = cache.get(cacheKey(ws));
        if (isRescanPending(ws.projectId(), ws.root())) return RESCAN_PENDING_EVIDENCE;
        return idx == null ? "" : flowEvidence(idx, task, Math.max(350, Math.min(3_000, maxChars)),
                score(idx, task).stream().filter(hit -> matchesCurrentFile(ws, hit.file())).toList());
    }

    private double cosine(double[] a, double[] b) {
        if (a == null || b == null || a.length == 0 || a.length != b.length) return 0.0;
        double dot = 0.0, aa = 0.0, bb = 0.0;
        for (int i = 0; i < a.length; i++) { dot += a[i] * b[i]; aa += a[i] * a[i]; bb += b[i] * b[i]; }
        if (aa <= 0.0 || bb <= 0.0) return 0.0;
        return dot / (Math.sqrt(aa) * Math.sqrt(bb));
    }

    public void invalidate(AgentWorkspaceService.Workspace ws) {
        if (ws != null) {
            String prefix = cacheKey(ws);
            WorkspaceIndex removed = cache.remove(prefix);
            if (removed != null) { dependencyCache.remove(removed.root()); callGraphCache.remove(removed.root()); }
            clearSemanticCache(prefix);
        }
    }

    /**
     * Refresh only files the runtime already knows were changed. This keeps the local retrieval index hot across
     * normal edit/write/patch operations instead of walking the whole repository again after every mutation.
     * If the index has not been built yet, this is intentionally a no-op; the first retrieval will build it once.
     */
    public void refreshPaths(AgentWorkspaceService.Workspace ws, Collection<String> changedPaths) {
        if (ws == null || changedPaths == null || changedPaths.isEmpty()) return;
        String key = cacheKey(ws);
        WorkspaceIndex existing = cache.get(key);
        if (existing == null) return;

        LinkedHashSet<String> normalized = new LinkedHashSet<>();
        for (String raw : changedPaths) {
            if (raw == null || raw.isBlank()) continue;
            try {
                Path supplied = Path.of(raw.strip());
                Path resolved = supplied.isAbsolute() ? supplied.normalize() : ws.root().resolve(supplied).normalize();
                if (!resolved.startsWith(ws.root())) continue;
                String rel = ws.root().relativize(resolved).toString().replace('\\', '/');
                if (!rel.isBlank()) normalized.add(rel);
            } catch (Exception ignored) { }
        }
        if (normalized.isEmpty()) return;
        // A directory created with files already inside may emit only the parent CREATE event.
        // Expand that directory without following symlinks. Cap per-event work, falling back to
        // a fingerprint-reusing full scan for large batch renames/extractions.
        LinkedHashSet<String> expanded = new LinkedHashSet<>(normalized);
        final boolean[] overflow = {false};
        for (String rel : normalized) {
            Path candidate = ws.root().resolve(rel).normalize();
            if (!candidate.startsWith(ws.root()) || !Files.isDirectory(candidate) || Files.isSymbolicLink(candidate)) continue;
            try {
                Files.walkFileTree(candidate, EnumSet.noneOf(FileVisitOption.class), 48, new SimpleFileVisitor<>() {
                    @Override public FileVisitResult preVisitDirectory(Path dir, BasicFileAttributes attrs) {
                        if (Files.isSymbolicLink(dir) || attrs.isSymbolicLink()) return FileVisitResult.SKIP_SUBTREE;
                        if (!dir.equals(candidate) && SKIP_DIRS.contains(dir.getFileName().toString().toLowerCase(Locale.ROOT)))
                            return FileVisitResult.SKIP_SUBTREE;
                        return FileVisitResult.CONTINUE;
                    }
                    @Override public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) {
                        if (expanded.size() >= 2_000) { overflow[0] = true; return FileVisitResult.TERMINATE; }
                        if (attrs.isRegularFile() && !attrs.isSymbolicLink())
                            expanded.add(ws.root().relativize(file).toString().replace('\\', '/'));
                        return FileVisitResult.CONTINUE;
                    }
                });
            } catch (IOException incomplete) { overflow[0] = true; }
            if (overflow[0]) break;
        }
        if (overflow[0]) { refresh(ws); return; }
        final Set<String> changedNormalized = expanded;

        Set<String> invalidated = new LinkedHashSet<>(changedNormalized);
        cache.computeIfPresent(key, (ignored, current) -> {
            LinkedHashMap<String, IndexedFile> byPath = new LinkedHashMap<>();
            for (IndexedFile file : current.files()) byPath.put(file.path(), file);
            // A deleted DIRECTORY is not itself indexed; evict its known descendants.
            // No recursive walk is needed and existing directories are preserved.
            for (String rel : changedNormalized) {
                if (Files.isDirectory(ws.root().resolve(rel))) continue;
                String prefix = rel + "/";
                for (String indexedPath : byPath.keySet())
                    if (indexedPath.startsWith(prefix)) invalidated.add(indexedPath);
            }
            for (String rel : invalidated) {
                byPath.remove(rel);
                Path file = ws.root().resolve(rel).normalize();
                try {
                    if (!file.startsWith(ws.root()) || !Files.isRegularFile(file) || Files.isSymbolicLink(file)) continue;
                    long size = Files.size(file);
                    if (!indexable(file, size)) continue;
                    String sample = sample(file);
                    byPath.put(rel, new IndexedFile(rel, indexTerms(file, rel, sample), cachedExcerpt(sample), size, Files.getLastModifiedTime(file).toMillis(), structure(file, rel, sample)));
                } catch (Exception ignoredFailure) {
                    if (Files.isRegularFile(file) && !Files.isSymbolicLink(file) && supportedAndSafe(file)) {
                        try { byPath.put(rel, new IndexedFile(rel, frequencies(rel), "", Files.size(file),
                                Files.getLastModifiedTime(file).toMillis())); }
                        catch (IOException missing) { /* File changed while indexing; retry on rescan. */ }
                    }
                }
            }
            List<IndexedFile> files = new ArrayList<>(byPath.values());
            if (files.size() > MAX_FILES) files = new ArrayList<>(files.subList(0, MAX_FILES));
            return new WorkspaceIndex(current.root(), List.copyOf(files),
                    new IndexStats(files.size(), current.stats().visitedFiles(), Instant.now().toString(),
                            files.stream().mapToLong(f -> f.sample().length()).sum(),
                            current.stats().skippedTooLarge(), current.stats().skippedUnsupported(),
                            current.stats().skippedUnreadable(), current.stats().skippedDirectories(),
                            current.stats().scanIncomplete()));
        });
        dependencyCache.remove(ws.root().toString());
        callGraphCache.remove(ws.root().toString());
        clearSemanticCache(key);
        embeddingScopes.getOrDefault(key, Set.of()).forEach(scope -> vectors.invalidate(scope, invalidated));
        WorkspaceIndex updated = cache.get(key);
        if (updated != null) persist(ws, updated);
    }

    private void clearSemanticCache(String prefix) {
        semanticResultCache.keySet().removeIf(key -> key.startsWith(prefix + "|"));
        semanticCachedSources.keySet().removeIf(key -> key.startsWith(prefix + "|"));
    }

    private static boolean matchesCurrentFile(AgentWorkspaceService.Workspace ws, IndexedFile indexed) {
        Path file = ws.root().resolve(indexed.path()).normalize();
        if (!file.startsWith(ws.root()) || !Files.isRegularFile(file) || Files.isSymbolicLink(file)) return false;
        try {
            return Files.size(file) == indexed.size()
                    && Files.getLastModifiedTime(file).toMillis() == indexed.modifiedAt();
        } catch (IOException unavailable) { return false; }
    }

    private WorkspaceIndex index(AgentWorkspaceService.Workspace ws, boolean force) {
        String key = cacheKey(ws);
        if (!force) {
            WorkspaceIndex existing = cache.get(key);
            if (existing != null && Objects.equals(existing.root(), ws.root().toString())) return existing;
        }
        WorkspaceIndex previous = cache.get(key);
        if (previous == null) previous = load(ws);
        if (!force && previous != null) {
            cache.put(key, previous);
            return previous;
        }
        WorkspaceIndex built = build(ws, previous);
        // Deleted files must not survive in semantic result caches or persisted vectors.
        // Embeddings for unchanged files remain reusable; only removed/changed paths are evicted.
        if (previous != null) {
            Map<String,IndexedFile> current = new HashMap<>();
            for (IndexedFile file : built.files()) current.put(file.path(), file);
            Set<String> invalidated = new LinkedHashSet<>();
            for (IndexedFile file : previous.files()) {
                IndexedFile next = current.get(file.path());
                if (next == null || next.size() != file.size() || next.modifiedAt() != file.modifiedAt())
                    invalidated.add(file.path());
            }
            if (!invalidated.isEmpty()) embeddingScopes.getOrDefault(key, Set.of())
                    .forEach(scope -> vectors.invalidate(scope, invalidated));
        }
        cache.put(key, built);
        clearSemanticCache(key);
        dependencyCache.remove(built.root());
        callGraphCache.remove(built.root());
        persist(ws, built);
        // Background warm-up avoids a cold graph scan on the first Chat question in a 3,000-file project.
        // Larger workspaces remain lazy to limit indexing memory/CPU overhead.
        if (built.files().size() <= 5_000) dependencies(built);
        return built;
    }

    private WorkspaceIndex build(AgentWorkspaceService.Workspace ws, WorkspaceIndex previous) {
        Map<String, IndexedFile> old = new HashMap<>();
        if (previous != null && Objects.equals(previous.root(), ws.root().toString()))
            for (IndexedFile f : previous.files()) old.put(f.path(), f);
        List<IndexedFile> files = new ArrayList<>();
        int[] scanned = {0};
        int[] indexed = {0};
        int[] oversized = {0}, unsupported = {0}, unreadable = {0}, excludedDirectories = {0};
        boolean[] incomplete = {false};
        try {
            Files.walkFileTree(ws.root(), EnumSet.noneOf(FileVisitOption.class), 48, new SimpleFileVisitor<>() {
                @Override public FileVisitResult preVisitDirectory(Path dir, BasicFileAttributes attrs) {
                    if (!dir.equals(ws.root()) && (attrs.isSymbolicLink() || attrs.isOther() || Files.isSymbolicLink(dir))) {
                        excludedDirectories[0]++;
                        return FileVisitResult.SKIP_SUBTREE;
                    }
                    if (!dir.equals(ws.root())) {
                        String name = dir.getFileName().toString().toLowerCase(Locale.ROOT);
                        if (SKIP_DIRS.contains(name)) {
                            excludedDirectories[0]++;
                            return FileVisitResult.SKIP_SUBTREE;
                        }
                    }
                    if (scanned[0] >= MAX_SCANNED_FILES || indexed[0] >= MAX_FILES) {
                        incomplete[0] = true;
                        return FileVisitResult.TERMINATE;
                    }
                    return FileVisitResult.CONTINUE;
                }

                @Override public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) {
                    if (++scanned[0] > MAX_SCANNED_FILES || indexed[0] >= MAX_FILES) {
                        incomplete[0] = true;
                        return FileVisitResult.TERMINATE;
                    }
                    if (!attrs.isRegularFile() || Files.isSymbolicLink(file)) return FileVisitResult.CONTINUE;
                    if (!supportedAndSafe(file)) { unsupported[0]++; return FileVisitResult.CONTINUE; }
                    if (attrs.size() > maxSize(file)) { oversized[0]++; return FileVisitResult.CONTINUE; }
                    indexed[0]++;
                    String rel = ws.root().relativize(file).toString().replace('\\', '/');
                    IndexedFile cached = old.get(rel);
                    if (cached != null && cached.size() == attrs.size() &&
                            cached.modifiedAt() == attrs.lastModifiedTime().toMillis() &&
                            (!codeFile(rel) || !cached.structure().equals(WorkspaceCodeIntelligence.Structure.EMPTY))) {
                        files.add(cached); return FileVisitResult.CONTINUE;
                    }
                    try {
                        String sample = sample(file);
                        files.add(new IndexedFile(rel, indexTerms(file, rel, sample), cachedExcerpt(sample),
                                attrs.size(), attrs.lastModifiedTime().toMillis(), structure(file, rel, sample)));
                    } catch (Exception ignored) {
                        unreadable[0]++;
                        files.add(new IndexedFile(rel, frequencies(rel), "", attrs.size(), attrs.lastModifiedTime().toMillis()));
                    }
                    return FileVisitResult.CONTINUE;
                }
                @Override public FileVisitResult visitFileFailed(Path file, IOException error) {
                    unreadable[0]++;
                    return FileVisitResult.CONTINUE;
                }
            });
        } catch (IOException failure) {
            incomplete[0] = true;
        }
        return new WorkspaceIndex(ws.root().toString(), List.copyOf(files),
                new IndexStats(files.size(), scanned[0], Instant.now().toString(),
                        files.stream().mapToLong(f -> f.sample().length()).sum(),
                        oversized[0], unsupported[0], unreadable[0], excludedDirectories[0], incomplete[0]));
    }

    private boolean indexable(Path file, long size) {
        return size >= 0 && size <= maxSize(file) && supportedAndSafe(file);
    }

    private long maxSize(Path file) {
        return isDocument(file) ? MAX_INDEXED_DOCUMENT_BYTES : MAX_INDEXED_FILE_BYTES;
    }

    private boolean supportedAndSafe(Path file) {
        String name = file.getFileName().toString().toLowerCase(Locale.ROOT);
        if (SECRET_NAMES.contains(name) || name.startsWith(".env.") ||
                name.matches(".*\\.(pem|p12|pfx|jks|keystore|key|crt|cer)$")) return false;
        if (IMPORTANT_NAMES.contains(name)) return true;
        int dot = name.lastIndexOf('.');
        return dot > 0 && (INDEX_EXTENSIONS.contains(name.substring(dot + 1))
                || DOCUMENT_EXTENSIONS.contains(name.substring(dot + 1)));
    }

    private String sample(Path file) throws IOException {
        if (isDocument(file)) {
            // Reuse the application's already-bundled Tika parsers. This is text-only
            // background indexing: visual evidence remains the Agent's responsibility.
            Tika parser = new Tika();
            // Allow Tika to finish parsing normal documents before clipping the
            // indexed excerpt. Too low a parser limit can reject longer DOCX.
            parser.setMaxStringLength(600_000);
            try (InputStream input = Files.newInputStream(file)) {
                return clip(parser.parseToString(input).replace('\u0000', ' '), MAX_SAMPLED_CHARS_PER_FILE);
            } catch (Exception error) {
                throw new IOException("Cannot extract text from " + file.getFileName() + ": " + error.getMessage(), error);
            }
        }
        byte[] bytes = Files.readAllBytes(file);
        if (bytes.length == 0) return "";
        int n = Math.min(bytes.length, MAX_SAMPLED_CHARS_PER_FILE);
        String head = new String(bytes, 0, n, StandardCharsets.UTF_8);
        if (bytes.length <= n) return head;
        int tailBytes = Math.min(8_000, bytes.length - n);
        String tail = new String(bytes, bytes.length - tailBytes, tailBytes, StandardCharsets.UTF_8);
        return head + "\n" + tail;
    }

    private boolean isDocument(Path file) {
        String name = file.getFileName().toString().toLowerCase(Locale.ROOT);
        int dot = name.lastIndexOf('.');
        return dot > 0 && DOCUMENT_EXTENSIONS.contains(name.substring(dot + 1));
    }

    // Score complete supported text files, not just cached excerpts, so a symbol located
    // far from the first page of a large source file remains discoverable in Chat.
    // Keep the LLM-bound excerpt bounded independently of the searchable term index.
    private Map<String,Integer> indexTerms(Path file, String rel, String sample) throws IOException {
        if (!isDocument(file) && Files.size(file) > MAX_SAMPLED_CHARS_PER_FILE)
            return frequencies(rel + "\n" + Files.readString(file, StandardCharsets.UTF_8));
        return frequencies(rel + "\n" + sample);
    }

    private Map<String,Integer> frequencies(String text) {
        Map<String,Integer> frequency = new HashMap<>();
        if (text == null) return Map.of();
        for (String raw : SPLIT.split(splitIdentifiers(text).toLowerCase(Locale.ROOT))) {
            String term = raw.trim();
            if (term.length() < 3 || term.length() > 80 || STOP.contains(term) || term.matches("\\d+")) continue;
            if (!frequency.containsKey(term) && frequency.size() >= MAX_TERMS_PER_FILE) continue;
            frequency.merge(term, 1, Integer::sum);
        }
        return Map.copyOf(frequency);
    }

    private Set<String> terms(String text) {
        LinkedHashSet<String> out = new LinkedHashSet<>();
        if (text == null) return out;
        for (String raw : SPLIT.split(splitIdentifiers(text).toLowerCase(Locale.ROOT))) {
            String term = raw.trim();
            if (term.length() < 3 || term.length() > 80 || STOP.contains(term) || term.matches("\\d+")) continue;
            out.add(term);
            if (out.size() >= 80) break;
        }
        return out;
    }

    // Index snake_case and camelCase symbols as both full identifiers and searchable words.
    private String splitIdentifiers(String text) {
        return text.replaceAll("([a-z0-9])([A-Z])", "$1 $2").replace('_', ' ');
    }

    // Keep evidence from the beginning and end of large files instead of dropping the end.
    private String cachedExcerpt(String sample) {
        if (sample.length() <= 24_000) return sample;
        return sample.substring(0, 16_000) + "\n...[middle omitted from cache]...\n"
                + sample.substring(sample.length() - 8_000);
    }

    private static String excerptAroundTerms(String text, Set<String> terms, int limit) {
        if (text == null || text.isBlank()) return "";
        String lower = text.toLowerCase(Locale.ROOT);
        int position = -1;
        for (String term : terms) {
            int match = lower.indexOf(term);
            if (match >= 0 && (position < 0 || match < position)) position = match;
        }
        int start = position < 0 ? 0 : Math.max(0, position - 350);
        return clip(text.substring(start, Math.min(text.length(), start + limit)), limit);
    }

    private String currentSnippet(Path file, Set<String> terms, int maxChars) {
        try {
            List<String> lines = Files.readAllLines(file, StandardCharsets.UTF_8);
            StringBuilder matches = new StringBuilder();
            int last = -1;
            int blocks = 0;
            for (int i = 0; i < lines.size() && blocks < 3; i++) {
                String low = lines.get(i).toLowerCase(Locale.ROOT);
                boolean hit = false;
                for (String term : terms) if (low.contains(term)) { hit = true; break; }
                if (!hit || i <= last) continue;
                int start = Math.max(last + 1, i - 3);
                int end = Math.min(lines.size(), i + 5);
                if (!matches.isEmpty()) matches.append("\n...\n");
                for (int line = start; line < end; line++) {
                    String value = lines.get(line).strip();
                if (value.length() > 240) {
                    int offset = -1;
                    String lowerValue = value.toLowerCase(Locale.ROOT);
                    for (String term : terms) {
                        int found = lowerValue.indexOf(term);
                        if (found >= 0 && (offset < 0 || found < offset)) offset = found;
                    }
                    int from = offset < 0 ? 0 : Math.max(0, offset - 60);
                    value = clip(value.substring(from), 240);
                }
                matches.append(line + 1).append(": ").append(value).append('\n');
                }
                last = end - 1;
                blocks++;
            }
            return clip(matches.toString(), maxChars);
        } catch (Exception ignored) { return ""; }
    }

    private String redact(String text) {
        if (text == null || text.isBlank()) return "";
        return text.replaceAll("(?im)(\\b[\\w.-]*(?:api[_-]?key|token|password|secret)[\\w.-]*\\s*[=:]\\s*[\"']?)([^\\s#;\"']{4,})", "$1[REDACTED]")
                .replaceAll("(?i)(Bearer\\s+)[A-Za-z0-9._~+/-]{16,}", "$1[REDACTED]");
    }

    private boolean isImportant(String path) {
        return IMPORTANT_NAMES.contains(Path.of(path).getFileName().toString().toLowerCase(Locale.ROOT));
    }

    /** Versioned compressed checkpoint outside source folders. A rescan stats changed files only. */
    private Path checkpoint(AgentWorkspaceService.Workspace ws) {
        try {
            byte[] digest = MessageDigest.getInstance("SHA-256").digest(cacheKey(ws).getBytes(StandardCharsets.UTF_8));
            return indexHome.resolve(HexFormat.of().formatHex(digest) + ".idx.gz");
        } catch (Exception failure) { throw new IllegalStateException(failure); }
    }
    private static void writeText(DataOutputStream out, String value) throws IOException {
        byte[] data = value.getBytes(StandardCharsets.UTF_8);
        out.writeInt(data.length); out.write(data);
    }
    private static String readText(DataInputStream in, int maxBytes) throws IOException {
        int length = in.readInt();
        if (length < 0 || length > maxBytes) throw new IOException("Invalid index string length: " + length);
        return new String(in.readNBytes(length), StandardCharsets.UTF_8);
    }
    private void persist(AgentWorkspaceService.Workspace ws, WorkspaceIndex idx) {
        try {
            Files.createDirectories(indexHome);
            Path target = checkpoint(ws), temp = target.resolveSibling(target.getFileName() + ".tmp");
            try (DataOutputStream out = new DataOutputStream(new GZIPOutputStream(Files.newOutputStream(temp)))) {
                out.writeInt(3);
                writeText(out, idx.root());
                out.writeInt(idx.files().size());
                for (IndexedFile file : idx.files()) {
                    writeText(out, file.path()); writeText(out, file.sample());
                    out.writeLong(file.size()); out.writeLong(file.modifiedAt());
                    out.writeInt(file.termFrequency().size());
                    for (var term : file.termFrequency().entrySet()) { writeText(out, term.getKey()); out.writeInt(term.getValue()); }
                    out.writeInt(file.structure().symbols().size());
                    for (var symbol : file.structure().symbols().entrySet()) { writeText(out, symbol.getKey()); out.writeInt(symbol.getValue()); }
                    out.writeInt(file.structure().references().size());
                    for (String ref : file.structure().references()) writeText(out, ref);
                    out.writeInt(file.structure().steps().size());
                    for (String step : file.structure().steps()) writeText(out, step);
                }
                IndexStats st = idx.stats();
                out.writeInt(st.visitedFiles()); out.writeLong(st.indexedCharacters());
                out.writeInt(st.skippedTooLarge()); out.writeInt(st.skippedUnsupported());
                out.writeInt(st.skippedUnreadable()); out.writeInt(st.skippedDirectories());
                out.writeBoolean(st.scanIncomplete());
            }
            try { Files.move(temp, target, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (AtomicMoveNotSupportedException unavailable) { Files.move(temp, target, StandardCopyOption.REPLACE_EXISTING); }
        } catch (Exception ignored) { /* Index is an optimisation; live files remain authoritative. */ }
    }
    private WorkspaceIndex load(AgentWorkspaceService.Workspace ws) {
        Path path = checkpoint(ws);
        if (!Files.isRegularFile(path)) return null;
        try (DataInputStream in = new DataInputStream(new GZIPInputStream(Files.newInputStream(path)))) {
            int version = in.readInt();
            if (version != 2 && version != 3) return null;
            String root = readText(in, 16_384);
            if (!root.equals(ws.root().toString())) return null;
            int count = in.readInt();
            if (count < 0 || count > MAX_FILES) return null;
            List<IndexedFile> files = new ArrayList<>(count);
            for (int i = 0; i < count; i++) {
                String relative = readText(in, 16_384), sample = readText(in, 150_000);
                long size = in.readLong(), modified = in.readLong();
                int termCount = in.readInt();
                if (termCount < 0 || termCount > MAX_TERMS_PER_FILE) return null;
                Map<String,Integer> frequency = new HashMap<>();
                for (int t = 0; t < termCount; t++) frequency.put(readText(in, 1_024), in.readInt());
                WorkspaceCodeIntelligence.Structure structure = WorkspaceCodeIntelligence.Structure.EMPTY;
                if (version >= 3) {
                    int symbolCount = in.readInt();
                    if (symbolCount < 0 || symbolCount > 240) return null;
                    Map<String,Integer> symbols = new LinkedHashMap<>();
                    for (int n = 0; n < symbolCount; n++) symbols.put(readText(in, 512), in.readInt());
                    int refCount = in.readInt();
                    if (refCount < 0 || refCount > 180) return null;
                    Set<String> refs = new LinkedHashSet<>();
                    for (int n = 0; n < refCount; n++) refs.add(readText(in, 512));
                    int stepCount = in.readInt();
                    if (stepCount < 0 || stepCount > 180) return null;
                    Set<String> steps = new LinkedHashSet<>();
                    for (int n = 0; n < stepCount; n++) steps.add(readText(in, 512));
                    structure = new WorkspaceCodeIntelligence.Structure(symbols, refs, steps);
                }
                files.add(new IndexedFile(relative, Map.copyOf(frequency), sample, size, modified, structure));
            }
            IndexStats st = new IndexStats(files.size(), in.readInt(), Instant.now().toString(), in.readLong(),
                    in.readInt(), in.readInt(), in.readInt(), in.readInt(), in.readBoolean());
            return new WorkspaceIndex(root, List.copyOf(files), st);
        } catch (Exception invalid) { return null; }
    }

    private String cacheKey(AgentWorkspaceService.Workspace ws) {
        return ws.projectId() + "|" + ws.root().toAbsolutePath().normalize();
    }

    private static String clip(String value, int max) {
        if (value == null || value.length() <= max) return value == null ? "" : value;
        return value.substring(0, Math.max(0, max - 18)) + " …[clipped]";
    }

    private record IndexedFile(String path, Map<String,Integer> termFrequency, String sample, long size, long modifiedAt,
                               WorkspaceCodeIntelligence.Structure structure) {
        IndexedFile(String path, Map<String,Integer> frequency, String sample, long size, long modifiedAt) {
            this(path, frequency, sample, size, modifiedAt, WorkspaceCodeIntelligence.Structure.EMPTY);
        }
    }
    private record ScoredFile(IndexedFile file, double score) { }
    private record GraphSnapshot(WorkspaceIndex index, Map<String,Set<String>> graph,
                                 List<WorkspaceFlowIntelligence.Link> httpLinks) { }
    private record WorkspaceIndex(String root, List<IndexedFile> files, IndexStats stats) { }
    public record IndexStats(int indexedFiles, int visitedFiles, String generatedAt, long indexedCharacters,
                             int skippedTooLarge, int skippedUnsupported, int skippedUnreadable,
                             int skippedDirectories, boolean scanIncomplete) {
        public IndexStats(int indexedFiles, int visitedFiles, String generatedAt) {
            this(indexedFiles, visitedFiles, generatedAt, 0L);
        }
        public IndexStats(int indexedFiles, int visitedFiles, String generatedAt, long indexedCharacters) {
            this(indexedFiles, visitedFiles, generatedAt, indexedCharacters, 0, 0, 0, 0, false);
        }
    }
}
