package com.llmart.llm.entity;

import jakarta.persistence.*;
import java.time.Instant;

@Entity
@Table(name = "chat_messages", indexes = @Index(name = "idx_msg_conversation", columnList = "conversation_id"))
public class MessageEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "conversation_id", nullable = false, length = 40)
    private String conversationId;

    @Column(nullable = false, length = 20)
    private String role;

    @Lob
    @Column(nullable = false)
    private String content;

    @Lob
    private String attachmentIdsJson;

    @Column(name = "execution_mode", length = 10)
    private String mode; // "chat" (Analyse) or "agent"; nullable for pre-120 history.

    @Column(nullable = false)
    private Instant createdAt;

    public MessageEntity() {}

    public MessageEntity(String conversationId, String role, String content, String attachmentIdsJson) {
        this.conversationId = conversationId;
        this.role = role;
        this.content = content;
        this.attachmentIdsJson = attachmentIdsJson;
        this.createdAt = Instant.now();
    }

    public Long getId() { return id; }
    public String getConversationId() { return conversationId; }
    public String getRole() { return role; }
    public String getContent() { return content; }
    public String getMode() { return mode; }
    public void setMode(String mode) {
        if (mode != null && !mode.equals("chat") && !mode.equals("agent"))
            throw new IllegalArgumentException("Invalid message mode");
        this.mode = mode;
    }
    public String getAttachmentIdsJson() { return attachmentIdsJson; }
    public Instant getCreatedAt() { return createdAt; }
}
