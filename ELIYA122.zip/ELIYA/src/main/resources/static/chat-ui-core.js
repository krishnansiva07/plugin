(function (root) {
  'use strict';
  const PREFIX = 'eliya.chat.draft121.';
  const MAX_DRAFT_LENGTH = 120000;
  function key(conversationId) { return PREFIX + (conversationId == null ? 'new' : String(conversationId)); }
  function readDraft(storage, conversationId) {
    if (!storage) return '';
    try { return String(storage.getItem(key(conversationId)) || '').slice(0, MAX_DRAFT_LENGTH); } catch (_) { return ''; }
  }
  function saveDraft(storage, conversationId, value) {
    if (!storage) return false;
    try {
      const text = String(value || '').slice(0, MAX_DRAFT_LENGTH);
      if (text) storage.setItem(key(conversationId), text);
      else storage.removeItem(key(conversationId));
      return true;
    } catch (_) { return false; }
  }
  function transferDraft(storage, fromId, toId) {
    const value = readDraft(storage, fromId);
    if (!value) return false;
    const existing = readDraft(storage, toId);
    if (!existing) saveDraft(storage, toId, value);
    saveDraft(storage, fromId, '');
    return true;
  }
  function insertFencedCode(text, start, end, language) {
    const src = String(text || '');
    const begin = Math.max(0, Math.min(src.length, Number(start) || 0));
    const finish = Math.max(begin, Math.min(src.length, Number(end) || begin));
    const selected = src.slice(begin, finish);
    // If a selection contains triple backticks, use a longer fence to avoid closing early.
    const matches = selected.match(/`{3,}/g) || [];
    const length = Math.max(3, ...matches.map(item => item.length + 1));
    const fence = '`'.repeat(length);
    const lang = /^[a-z0-9+_-]{0,20}$/i.test(String(language || '')) ? String(language || '') : '';
    const prefix = fence + lang + '\n';
    const middle = selected || '\n';
    const block = prefix + middle + (selected && !selected.endsWith('\n') ? '\n' : '') + fence;
    const before = src.slice(0, begin);
    const after = src.slice(finish);
    const spacerBefore = before && !before.endsWith('\n') ? '\n' : '';
    const spacerAfter = after && !after.startsWith('\n') ? '\n' : '';
    return {text:before + spacerBefore + block + spacerAfter + after,
      cursor:before.length + spacerBefore.length + prefix.length + (selected ? selected.length : 0)};
  }
  function safeFilename(language) {
    const ext = String(language || 'txt').replace(/[^A-Za-z0-9]/g, '').slice(0, 12) || 'txt';
    return ext === 'Dockerfile' ? 'Dockerfile' : 'snippet.' + ext;
  }
  root.EliyaChatUiCore = {key, readDraft, saveDraft, transferDraft, insertFencedCode, safeFilename, MAX_DRAFT_LENGTH};
})(typeof window === 'undefined' ? globalThis : window);
