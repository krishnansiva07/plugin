Runtime indexes are regenerated locally; no stale cached workspace content is shipped.
