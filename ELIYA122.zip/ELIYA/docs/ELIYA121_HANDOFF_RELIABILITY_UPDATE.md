# ELIYA121 — Analyse → Agent handoff reliability update

Base: `ELIYA121_Chat_UI_Revamp.zip`. This is an in-place **ELIYA121** update, not a new agent engine. OpenCode remains disabled.

## What is implemented

1. **Analyse** and **Agent** remain separate manual buttons. Analyse remains a read-only, conversational mode with a visible explanation, a proposed plan and an invitation to implement; it does not automatically promote the user's message into Agent execution.
2. A saved and complete Analyse answer exposes **Implement in Agent**. The click prepares a request (it does not send). The user reviews/edits it and presses **Send** to authorize execution.
3. **Precise source binding**: the handoff must identify exactly one saved source message, in the active conversation, in the same workspace selected when preparing the handoff. Editing the prompt to add constraints is supported; deleting/replacing the source reference or inserting a second source fails validation before send.
4. **Draft safety**: before preparing a handoff over existing unsent text, the UI asks permission. **Cancel handoff** restores that earlier draft in the same open conversation. Switching away from a conversation does not auto-execute.
5. **Plan continuity**: the native Agent now recognizes explicitly selected saved-source plans as user-authorized execution requests, even when the handoff text is longer than “implement it.” A stale pending plan from an earlier Agent session does not replace the selected Analyse plan.
6. **Long discussion context**: original requirement, saved analysis, later user refinements and later uploaded specification attachments are included in Agent's handoff context. At most 24 user decision summaries are preloaded and extra turns can be opened through saved conversation tools. Latest explicit user requirements override earlier ones.
7. **Fail closed**: selected source missing from this conversation, or a source known to be a previous Agent answer, is rejected; a missing saved Analyse source marks the run blocked rather than completed. Interrupted or incomplete Analyse answers are not offered for one-click handoff.
8. **Native Agent** execution and ELIYA121 code/Markdown/prompt UI are retained; no OpenCode startup is re-enabled.

## How to use

1. Select **Analyse** and provide a technical question linked to a workspace or document.
2. Continue discussing constraints until the resulting analysis is complete and you agree with the plan.
3. On that saved Analyse response select **Implement in Agent**.
4. If there is a different unsent draft, approve replacing it, or decline. You can cancel the handoff to restore the earlier draft.
5. Add any final constraints to the prepared prompt **without changing the saved source reference**.
6. Press **Send**. Agent should retrieve the saved source and current project files, execute the approved scope, verify and report changes.
7. Return to **Analyse** for review and repeat as necessary.

## Local tests

```bash
node --check src/main/resources/static/app.js
node --check src/main/resources/static/workflow-handoff.js
node --test src/test/js/*.test.js
bash qa/eliya120-handoff/run.sh
bash qa/eliya121-handoff-hardening/run.sh
node qa/eliya121-chat-ux/run.cjs
```

Java 17 and Node.js are enough for these tests. For the application JAR, run `build-jar-windows.cmd` from the ELIYA folder (requires Maven).

### Not yet verified

- Maven package/build against complete dependencies (Maven is not available in the execution environment).
- Live model-driven analysis, real Agent filesystem modifications and recovery from an interrupted network connection.
- Browser visual/interactivity test against the running JAR; this environment's Chromium refuses local file navigation with `ERR_BLOCKED_BY_ADMINISTRATOR`.
- Strong binding of the original analysis **creation-time** workspace across machine restarts (the current validation protects the workspace between preparing and sending the handoff; it is not a durable workspace fingerprint). For safety, review the workspace banner before Send.

Do not consider this production-validated without those acceptance tests. Complete the small real-workspace validation before attempting a full migration.
