# ELIYA116 — Automatic Workspace Synchronization

This release extends **ELIYA115 Workspace Freshness + Handoff/Watchdog**. The selected local workspace and its read-only references now receive continuous filesystem change detection, rather than depending solely on the Rescan button.

## Changes

1. **Incremental filesystem watch**: `WorkspaceAutoSyncWatcher` recursively registers local directories using the JDK `WatchService`, on Windows, macOS and Linux where supported. Creates, writes, deletions and renames are batched with a short debounce and dispatched to the existing single background indexing worker. HTTP request threads never index files.
2. **New folders and bulk copies**: the incremental refresh expands directory-creation events to index supported files already present under the new directory. It skips symlinks, excluded/build/cache folders and maintains count and depth bounds. Very large directory events fall back to a normal fingerprint-reusing scan.
3. **Deleted and renamed folders**: when a subtree disappears, all previously indexed descendants are evicted, and cached semantic results, embeddings and dependency graphs are invalidated for changed paths. Existing filesystem existence checks remain active for immediate queries.
4. **Coalesced change queue**: overlapping file events for the same workspace share one queued worker task rather than flooding the agent or blocking model streaming. A freshness fence prevents old index evidence from being presented as current during updates.
5. **Conversation vs actual workspace**: after a *changed* workspace has been indexed, old OpenCode sessions for that workspace are retired for **future task reuse**, without deleting the visible ELIYA conversation or terminating already running executions. An unchanged periodic reconciliation preserves the OpenCode session.
6. **Missed-event recovery**: every five minutes by default, a non-blocking reconciliation scan verifies the selected workspace. `WatchService` overflow, unsupported filesystem mounts and resource limits are covered by this fallback. Fingerprints allow unchanged source files to be reused.
7. **Clear UI telemetry**: index status now reports `autoSyncEnabled`, `watchState`, `pendingChanges`, `monitoredDirectories`, `lastChangeAt`, `lastAutoSyncAt`, `watchError`, and `reconcileSeconds`. The selected workspace status refreshes in the UI every 12 seconds, without triggering a scan.
8. **Failure handling**: missing workspace paths or scanning failures show a failed state, rather than claiming an index is current. Manual Rescan remains available and reliably schedules a follow-up pass while a scan is active.

## Settings (optional Java -D flags)

| Property | Default | Purpose |
|---|---|---|
| `eliya.index.watch.enabled` | `true` | Enable automatic directory watching and reconciliation |
| `eliya.index.watch.debounceMs` | `700` | Batch nearby file events (clamped 100–10000 ms) |
| `eliya.index.watch.maxDirectories` | `8192` | Max watched directories per selected workspace |
| `eliya.index.watch.maxTotalDirectories` | `16000` | Global directory-watch resource cap |
| `eliya.index.watch.maxBatchPaths` | `1500` | Max queued path events before full reconciliation |
| `eliya.index.watch.reconcileSeconds` | `300` | Missed-event reconciliation interval (clamped 30–86400 seconds) |
| `eliya.index.autoRefreshMinutes` | `0` | Existing age-based index behavior; independent of the new watcher |

Normal users do **not** need to modify these defaults. Excluded folders include `.git`, `node_modules`, `target`, `build`, `.agent-home`, virtual environments and caches. Path safety and original file size/extension limits remain in effect.

## Acceptance steps

1. Unzip and build a new JAR using `build-jar-windows.cmd`; restart ELIYA.
2. Select a writable workspace; wait for indexing to complete and confirm **Automatic sync active**.
3. Create a folder and Java file through OpenCode. Without pressing Rescan, verify that the folder appears in Analyse and the indexed file count updates.
4. Delete the folder manually in File Explorer/Finder; within the normal watcher/index delay verify the count and Analyse inventory no longer contain it.
5. Create and rename a nested directory with files, edit an existing file and verify the index and analysis use the latest paths and content.
6. Ask `Can you implement?` in the same ELIYA chat after a change; verify the new OpenCode execution uses fresh workspace context rather than old session state.
7. Repeat with reference workspaces, a non-indexed/large file, excluded directories and while an Agent is running. The agent must not be cancelled merely because the watcher detected a file change.
8. On unreliable/network-mounted filesystems, inspect `watchState` for `degraded_reconciling`/`polling_fallback`. The scheduled reconciliation will catch events that the mount did not deliver; manual Rescan remains the fastest guaranteed fallback.

## Offline validations performed

- `bash qa/intelligence-smoke/run.sh` — PASS. Includes OS CREATE/MODIFY/MOVE/DELETE, nested directory discovery, stale-path eviction, fresh retrieval, session retirement, unchanged reconciliation and a mocked missed-events fallback.
- `node --test src/test/js/*.test.js` — **93/93 PASS**, including the new live freshness indicator test.
- `qa/eliya115-handoff-watchdog`, `qa/eliya95-progress-tabs`, `qa/eliya109-tokens`, `qa/eliya111-stop-usage`, `qa/eliya113-flow`, `qa/eliya76-handoff` — PASS.

### Build and verification limits

The source-level regression harness compiles the modified Java services with local test stubs. This environment does not have `mvn` installed and could not produce or verify a full Spring Boot executable JAR. Live testing against your corporate OpenCode/model gateway and OS-specific Windows/macOS watcher behavior has not been performed. Please build the JAR on your target machine and run the acceptance steps above.

The watcher provides **eventual** freshness. Notification delivery times depend on the filesystem and OS; a request issued immediately during a file change may show a temporary *synchronizing* status rather than the newly indexed contents. Reconciliation is a periodic fallback rather than a sub-second guarantee for network shares.
