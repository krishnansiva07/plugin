# ELIYA115 — Live Workspace Freshness Fix

This patch extends **ELIYA115** with fixes for deleted/generated folders being incorrectly reported by Analyse or Execute after file deletion, particularly within the same conversation.

## Verified fixes

1. **Explicit Rescan is reliable during indexing.** When a user requests Rescan while a scan is running, one follow-up scan is queued. The earlier in-flight traversal cannot stand in for that requested refresh. Queued requests share a single pending pass.
2. **Old evidence is fenced during Rescan.** Chat and Agent retrieval avoid presenting obsolete index content as current until the newest scan completes. A failed scan does not re-enable known-stale evidence.
3. **Workspace overview verifies file existence.** Deleted paths are filtered from cached inventory, example source snippets, impact candidates, and call-flow edges even before manual Rescan; none of these claims should be inferred from previous chat history.
4. **Deleted source and embeddings are evicted.** A rescan drops deleted files from the indexed source list, clears semantic result caches, and invalidates vectors for deleted/changed indexed files. A folder-level deletion from the Agent refresh path also removes known descendants.
5. **OpenCode session freshness.** Explicit Rescan retires old OpenCode sessions for **future execution turns**. They remain visible for audit and rollback; running tasks are not silently cancelled. The next action creates a fresh OpenCode model session. Session retirement persists across app restart.
6. **Current filesystem outranks conversation.** Analyse and OpenCode instructions distinguish historical descriptions from present filesystem evidence. The same visible ELIYA conversation is retained for requirements and history.
7. **Rescan UI watcher.** Overlapping Rescan requests do not lose the follow-up index-status polling when the preceding watcher finishes.

## Practical acceptance test

1. Select a local workspace and run `Create folder trial-agent with a Java file` in Execute.
2. Delete `trial-agent` manually or through the approved Agent workflow.
3. In the **same** conversation ask Analyse `Which folders are currently present in the workspace?` — it must not report `trial-agent` as an existing folder merely from earlier chat history.
4. Click **Rescan**; while it is running, click Rescan again if required. The status must show queued/indexing before fresh completion, not reuse the earlier scan as the result.
5. After Rescan has completed, ask Analyse `Does trial-agent exist now?` — deleted folder must not appear as present. Any relevant historical mention must be clearly historical.
6. Switch to Execute and ask a different task; the new OpenCode execution must not continue the old model session retired by Rescan.
7. Confirm OpenCode activity/token reporting and the ELIYA fallback still work.

## Offline checks performed

- `bash qa/intelligence-smoke/run.sh`: **PASS**, including new Rescan-race and deleted-folder checks.
- `bash qa/eliya115-handoff-watchdog/run.sh`: **PASS**, including OpenCode retirement and previously fixed watchdog/handoff tests.
- `node --test src/test/js/*.test.js`: **92/92 passed**, including new overlapping-watcher UI regression.
- `bash qa/eliya95-progress-tabs/run.sh`: **PASS**.
- `bash qa/eliya109-tokens/run.sh`: **PASS**.
- `bash qa/eliya111-stop-usage/run.sh`: **PASS**.
- `bash qa/eliya113-flow/run.sh`: **PASS**.
- `bash qa/eliya76-handoff/run.sh`: **PASS**.

**Verification limit:** An actual Spring Boot/Maven package and corporate OpenCode/model integration were **not** verified in this environment; the local Maven wrapper could not fetch dependencies because networking was unavailable. Run `build-jar-windows.cmd` on the deployment host, restart ELIYA, and run the above manual scenario for end-to-end acceptance.
