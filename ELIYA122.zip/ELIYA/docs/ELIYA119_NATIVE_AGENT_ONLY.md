# ELIYA119 — Native execution only (OpenCode paused)

## Change summary

- **Native Eliya is the only default execution backend** in Chat and Terminal.
- OpenCode startup and prewarming are disabled; the UI no longer polls its readiness or exposes engine selection.
- The backend blocks new OpenCode routing even if a browser persists an old engine selection or sends `X-ELIYA-Execution-Engine: opencode`.
- Terminal tabs, native agent actions, queues, workspace management, file indexing, chat modes, stop/cancel, and native run reports remain intact.
- OpenCode adapter source and historical run rendering remain in the codebase; this is a reversible pause, not deletion.
- An independent OpenCode process that was started outside this build is **not** automatically terminated. Close or stop it manually if necessary.

## Locate the terminal

The Terminal dock in `static/index.html` is labelled **ELIYA Agent Execution** (`#terminalDock`); output appears in `#terminalOutput`. The old OpenCode `opencode-live-console` was an inline *tool activity panel*, not an interactive OpenCode shell terminal. It stays in source only to render historical records.

## Settings

```properties
eliya.opencode.integration-enabled=${ELIYA_OPENCODE_INTEGRATION_ENABLED:false}
eliya.execution.engine=${ELIYA_EXECUTION_ENGINE:legacy}
eliya.opencode.auto-start=${ELIYA_OPENCODE_AUTO_START:false}
```

To re-enable OpenCode later requires intentional configuration and restoring UI controls/polling. Do not turn on OpenCode for ELIYA119 testing.

## Validation

Run `node --check src/main/resources/static/app.js`, `node --test src/test/js/*.test.js`, and `bash qa/eliya119-native-only/run.sh`. Full Maven build and Windows browser testing are still required on the target machine.
