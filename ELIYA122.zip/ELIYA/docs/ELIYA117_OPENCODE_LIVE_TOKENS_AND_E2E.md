# ELIYA117 — OpenCode token telemetry and end-to-end execution reliability

Built from ELIYA116 (automatic workspace synchronization) and retaining the ELIYA115 handoff, no-progress watchdog, and workspace freshness changes.

## Root cause

The OpenCode bridge forwarded usage already present in its backend snapshots. However, the backend relied on `GET /api/experimental/session/{sessionID}/log?follow=true`, which follows the **durable** session log. OpenCode v2's `session.usage.updated` belongs to the **volatile** `/api/event` stream, so the backend could miss the live aggregate. It could also defer message-history usage reconciliation until a tool-recovery or completion path, leaving the UI with no reported numbers during an otherwise active task.

The Chat progress line also omitted the token status entirely when the provider reported no numeric total. This made *unknown* usage look like a broken/empty counter.

## Corrections

1. Subscribe to the OpenCode v2 `/api/event` stream for `session.usage.updated`, `session.step.ended`, and `session.step.failed`. This stream is optional; unsupported servers fall back to existing sources without repeated 404/400 requests.
2. Scope every volatile event to its exact `sessionID` before accounting; another session on the same local server can never inflate the selected task.
3. Keep volatile event IDs out of the **durable log cursor**. Advance the durable cursor even when the same event was already received live, preventing replay/reconnect loops.
4. Reconcile assistant-message usage for the **current admitted user prompt** every 12 seconds while active. The existing per-turn history pagination and message-ID deduplication prevent double counting and prior-turn contamination.
5. Refresh remote session aggregates on the existing monitor cycle. Only **changed counters** count as verified model activity for the no-progress watchdog; repeated usage heartbeats do not indefinitely suppress timeouts.
6. Reconnect live-usage capture when a pending permission/clarification is answered, not only when starting a new prompt.
7. Fix the per-task ledger to keep delayed corrections to a **previous turn** in the lifetime total without charging them to the new turn.
8. Add `usageDiagnostic` to the snapshot, and show **Awaiting provider token counters** while active / **Provider tokens not reported** after completion instead of leaving a blank token line.
9. Fix the token detail table to show exact aggregate-recovered counts rather than calling those counts "Not reported" merely because the assistant call rows are unavailable.
10. Preserve ELIYA116 automatic indexing, separate parallel tabs, Analyse→Execute context, stop confirmation, recovery, terminal action reporting, and exact provider accounting (cached reads/writes are included once; reasoning isn't counted twice).

## Validation performed (offline, no paid model calls)

- `bash qa/eliya117-usage-e2e/run.sh`: **PASS**, including an actual localhost Java HTTP/SSE server test (session isolation, live usage, durable cursor, repeated events, no misleading zeroes, previous-task usage boundary).
- `bash qa/eliya113-flow/run.sh`: **PASS** OpenCode mock command lifecycle, file creation, diff verification, token counts, managed-process release.
- `bash qa/eliya115-handoff-watchdog/run.sh`: **PASS** Analyse→Execute context, no-progress timeout and bridge behavior.
- `bash qa/eliya109-tokens/run.sh`: **PASS** raw token events, caches, deduplication and task boundaries.
- `bash qa/eliya111-stop-usage/run.sh`: **PASS** stop confirmation, rollback-related and usage persistence checks.
- `bash qa/eliya108-live-actions/run.sh`: **PASS** background tool action stream, safe output and journal.
- `bash qa/intelligence-smoke/run.sh`: **PASS** workspace create/modify/rename/delete, incremental indexing, missed-event recovery, stale-context eviction and syntax checks.
- `node --test src/test/js/*.test.js`: **97 JavaScript tests passing**, including four new token display tests.

Legacy harness `qa/eliya98-opencode-contract/run.sh` predates the managed-local provider integration and uses an obsolete method signature. The repository already contained this mismatch in ELIYA116; it is not a valid 117 pass/fail signal. Current e2e lifecycle coverage is in `qa/eliya113-flow` and `qa/eliya115-handoff-watchdog`.

## Windows acceptance checklist

1. Unpack the ZIP and run `build-jar-windows.cmd`; start the freshly compiled JAR rather than the previous JAR.
2. Confirm **OpenCode 2.2+ ready** and that the **same ELIYA UI model / Base URL / API key** are selected; do not install extra LLM credentials separately for OpenCode.
3. In Chat/Analyse request a specific change, say **implement**, and verify the previous analysis is handed off. In OpenCode Execute, watch **Live provider tokens**; totals should appear as soon as OpenCode reports assistant step or session usage data, including midway through a longer task.
4. Run the same task in Terminal; compare final counts (not estimates) for the *same prompt* across engines. OpenCode input excludes cache reads/writes; those are separate and added once to the total.
5. Use two OpenCode tabs with different sessions; ensure their usage totals stay isolated. Resume a permission/clarification and confirm token updates continue.
6. Stop a task and confirm it does not falsely say completed; check the run report and that the workspace is no longer held by a managed process.
7. Delete or rename an agent-generated folder manually and ask Analyse in the **same chat**; current filesystem/index facts must prevail without pressing Rescan.
8. If usage remains "Provider tokens not reported," collect `/api/terminal/sessions/{id}` from ELIYA (remove sensitive paths, model information and credentials before sharing). Check `usage.usageStatus`, `usage.usageDiagnostic`, `usage.modelCalls`, and `usage.remoteSessionCumulative` for evidence. Do **not** interpret a missing value as zero.

## Limits

- Accurate usage depends on OpenCode/provider emitting token counters through events, assistant messages, or session aggregates. ELIYA will not invent counts when these sources are absent or delayed. A single long provider call may only report usage when it completes.
- Java source services compile and are covered by stub-based regression harnesses, but full Spring Boot Maven packaging and a live corporate model/OpenCode session were **not** available in this environment. The supplied ZIP contains complete **source** and the Windows build script, not a prebuilt executable JAR.
- Automatic filesystem watchers provide eventual consistency; on network-mounted or unusual filesystems the periodic reconciliation remains the fallback.
