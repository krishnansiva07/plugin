# ELIYA120 — explicit Analyse → Agent handoff

## What changed
- Restored visible **Analyse** and **Agent** mode buttons. The selection is authoritative: no automatic model intent routing, and a natural “yes” is never rewritten as an execution instruction.
- Analyse is read-only. Responses use indexed evidence, actionable summaries, assumptions, scoped proposals, and a focused clarification question when needed. This is an observable analysis summary, not a model's private chain of thought.
- An Analyse response that was saved by the server displays **Implement in Agent**. This switches to Agent and prepares (but does **not** send) an explicit message-ID handoff. Review, edit if necessary, and click Send.
- Agent retrieves the exact persisted analysis and initiating user request by scoped conversation message IDs using `conversation_handoff_read`, rather than relying on clipped chat history. The server fails closed if the explicit source ID cannot be found in the active conversation.
- Current workspace is visible in the handoff notice. Changing workspace or conversation before sending requires preparing a fresh handoff.
- Chat and Agent remain in the SAME conversation so user refinements, documents, and earlier requirements are available; conversation tabs retain their selected mode. The database migration adds an optional `execution_mode` column to `chat_messages` (Hibernate DDL update).
- OpenCode remains disabled; native Eliya performs all agent tool calls.

## Workflow
1. Select a workspace and click **Analyse**. Ask e.g. “Inspect our Selenium/Cucumber framework and propose a phased migration to Playwright. No modifications.”
2. Discuss findings, ask follow-up questions, and refine the scope as needed.
3. From the final saved analysis response, click **Implement in Agent** (or manually switch to **Agent** and type “implement it”). The button specifically references that source message ID.
4. Inspect the prepared Agent request and selected workspace. Press **Send** to authorize implementation.
5. Agent reads the saved analysis, inspects live files, implements the agreed scope and verifies results. It must ask one clarification if a material requirement is missing and should never silently write to a different workspace.
6. Switch back to Analyse for review or new questions; the same conversation is preserved.

## Scope and limitations
- Saving an answer is required before exact message-ID handoff; a streamed partial answer is not enough.
- Chat's indexed context is bounded, not an exhaustive repository inspection. Agent must validate live workspace state before edits.
- If a user manually types “implement it” instead of using the button, the existing latest-answer handoff remains heuristic; **Implement in Agent** is recommended for deterministic source selection.
- Source selection is conversation-bound, but it does not persist a cryptographically bound workspace fingerprint for each analysis. Review the currently selected workspace. New saved assistant messages persist mode (`chat` or `agent`); legacy messages without a stored mode do not expose the one-click handoff action, but manual Agent continuation remains available.
- Unit/source tests do not replace a full live LLM + filesystem E2E run.
