# ELIYA121 — Chat workspace redesign and stability checks

Baseline: **ELIYA120 Analyse / Agent handoff**. The **native Eliya agent** remains the only active execution engine; OpenCode stays disabled. This release changes chat presentation and browser interaction rather than replacing agent execution or changing backend schemas.

## What changed

| Area | ELIYA121 behavior |
| --- | --- |
| Chat layout | Unified visual hierarchy for sidebar, tabs, message content, status bar and composer. Responsive CSS at desktop and narrow widths, including dark mode. |
| Code output | Bounded-height code blocks with language labels, highlighting, horizontal scrolling, wrap, copy, download and **Expand** into a full-screen read-only inspector. |
| Very large code | Rendering avoids thousands of line-number DOM nodes or expensive syntax colouring above 1,800 lines / 120,000 characters. Content remains available for copy/download. |
| Markdown | Readable formatted answer is the default, including prompt responses. A continuous raw prompt view is still opt-in per message. Fenced code with variable-length triple-or-longer backticks or tildes is supported. Unsafe HTML remains escaped. |
| Composer | Quick Prompt Factory button, code-block insertion (preserves selection), Markdown preview, character count, Clear, keyboard hints and live mode caption. |
| Drafts | Unsent text saved in the **current browser tab's sessionStorage**, isolated by conversation. Drafts survive reload and chat switching in that tab. A new conversation's draft transfers to its saved conversation ID. No new backend storage of drafts. Drafts are capped at 120,000 characters. |
| Prompt Factory | More legible template previews, search/filter; warns before replacing a nonempty draft. Using a new template clears a stale Analyse → Agent handoff selection. |
| Actions in previews | Code actions also work in composer Markdown previews and saved Markdown/artifact previews, not just message bubbles. |
| Safety and usability | Esc closes expanded code view; focus returns to the originating button; Tab stays within the code viewer. Clipboard fallback now reports failure rather than falsely saying code was copied. |
| Analyse → Agent | Explicit buttons, saved-source handoff and native Eliya execution from ELIYA120 are preserved. No automatic switching. |
| Conversations | Opening a chat no longer makes an unnecessary OpenCode session-list request. |

## How to use

1. Select **Analyse** to inspect a problem or develop a plan without changing files.
2. In **Prompt Factory**, search a template, choose **Use prompt**, adjust workspace/reference placeholders, and review the editable draft.
3. Use **⌘ Code block** to wrap selected code, **Preview** to inspect formatted Markdown, and **Send** to submit. `Enter` sends; `Shift+Enter` adds a line break. `Ctrl/⌘+Enter` also sends; `Alt+P` opens Prompt Factory.
4. In answers, use **Expand** for a full code viewer, **Copy**, **Download**, or **Wrap** for ordinary code blocks.
5. On a saved Analyse answer, choose **Implement in Agent**. It prepares an exact-source instruction; review it, then press **Send**. This is not automatic execution.

## Validation

- `node --check` for `app.js`, `markdown.js`, `chat-ui-core.js`: syntactic checks.
- `node --test src/test/js/*.test.js`: original JavaScript tests.
- `node qa/eliya121-chat-ux/run.cjs`: new code, Markdown, safety, draft, and UI-contract tests.
- `node qa/markdown-ui-smoke/run.cjs`, `node qa/completion-report-smoke/ui.cjs`: UI smoke harnesses (updated missing mocks only).
- `bash qa/eliya120-handoff/run.sh`: Java 17 exact saved-source handoff.

**Limitations:** The full Spring Boot Maven build, browser screenshot verification, keyboard/screen-reader audit, and live SSE / LLM-driven execution cannot be confirmed from source-level tests alone. In the current test environment, headless Chromium navigation to both localhost and local files was blocked by the environment policy. A real browser test against the built JAR is required before calling this production-validated.

## Recommended local acceptance checklist

- [ ] Launch JAR; confirm the UI loads without a JavaScript console error at 1440px and 390px widths in light/dark mode.
- [ ] Type a draft, change conversations, return and reload. Confirm each draft remains separate and nothing is sent automatically.
- [ ] Compose Java, TypeScript, JSON, a table, a 10,000-line code block, a long prompt, and HTML special characters. Verify formatting and exact copied/downloaded bytes.
- [ ] Check Prompt Factory use/copy, overwrite warning, filtered search, and mode selection.
- [ ] Check Analyse → Agent saved-source handoff in the same conversation and workspace, including refusal if workspace changes.
- [ ] Check attachments, streaming, stop, scroll position, errors, code expand/wrap/copy/download, and reopening completed answers.
- [ ] Confirm Stop/Cancel affects only the intended task and other conversation tabs remain usable.

Legacy OpenCode-selectors tests under `qa/eliya92-engine-selection` were written for the removed 2026 engine selector. They are no longer current acceptance criteria for the deliberately native-only UI.
