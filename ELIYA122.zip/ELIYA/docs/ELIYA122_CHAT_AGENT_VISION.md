# ELIYA122 — Vision in Analyse and Agent

## What changed
- Restored separate **Chat Vision** and **Agent Vision** fields beside each mode's language model. ELIYA121 was hiding them in the composer.
- Both models are independently configurable in **Settings → Model routing**. Vision endpoint and API key are optional overrides; otherwise Eliya reuses the primary provider.
- Analyse/Chat now extracts embedded visuals from attached PDF/DOCX/PPTX/XLSX files using its selected Chat Vision model (Agent already did this).
- Screenshots can be attached before configuring the Vision model; **Send** blocks with a clear message until a compatible model is selected.
- Chat and Agent both allow explicit follow-ups referring to a previously attached screenshot in the same conversation.
- An image request with zero successfully processed images fails with a visible error instead of allowing an unsupported claim of image understanding.
- Model Library → Test on a `vision`/`ocr` model or any model assigned to Chat Vision/Agent Vision now submits a real red-square image and checks the visual response rather than declaring vision ready from a text-only probe. For a separate Vision endpoint/key, the test uses that connection.

## How to configure
1. Open Settings. Keep your normal **Chat model** and **Agentic model**.
2. Add a vision-capable model ID to the Model Library with type `Vision`, if it is not already listed.
3. Set **Chat Vision model** and **Agent Vision model**, independently. They can be the same model if desired.
4. If the Vision model is hosted separately, set **Vision endpoint** and **Vision API key**; otherwise leave these blank.
5. Save. In Analyse, the Chat and Chat Vision fields appear; in Agent, the Agentic and Agent Vision fields appear.
6. In Model Library, click Test for the vision model to verify the provider accepts actual image content.
7. Attach a screenshot and ask Analyse to explain it; switch to Agent and use the Analyse → Agent handoff to implement fixes.

## Supported inputs and limitations
- Image uploads (subject to file limits): independently interpreted using Chat Vision/Agent Vision.
- PDF, Word, PowerPoint and Excel: images and diagrams may be extracted with image counts/status, alongside original document text.
- Partial image extraction is disclosed; image context remains untrusted evidence and must not be treated as instructions.
- These settings do not enable live webcam, browser video, real-time screen capture, or continuous visual observation.
- Model availability/format compatibility depends on your provider (OpenAI-compatible multimodal chat completions required).
- Vision adds provider calls and latency on large image-heavy documents.
- Run a real end-to-end JAR/UI test in your environment before relying on it for production automation.
