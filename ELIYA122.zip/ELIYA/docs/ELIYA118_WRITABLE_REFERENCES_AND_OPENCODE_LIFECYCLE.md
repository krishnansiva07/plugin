# ELIYA118 — Writable references and long-running OpenCode execution

## Why this release

In ELIYA117, selected references were always treated as read-only, including migration targets containing project-specific agent instructions and skills. OpenCode also denied all external directories, initialized permissions inside session creation rather than through the v2 update endpoint, and a silence watchdog could interrupt a genuinely active, long-running migration task. In some versions of OpenCode, the session diff only covers the primary project, so changing files under an authorized reference was not enough to satisfy ELIYA's completion verification.

## Selective writable references

1. Add your primary workspace and up to five local reference workspaces, with unique aliases.
2. References start **read-only** by default. A closed-lock icon is shown beside each reference in both the primary workspace reference list and the Terminal reference selector.
3. Unlock only the reference that should receive migration changes. ELIYA asks for confirmation and shows the directory being authorized. An unlocked reference is **read/write**; a locked reference stays **read-only**.
4. In **Execute** mode, specify the alias and path for agent or skill changes, e.g.:

   > Compare the selected legacy reference with Workspace [workspace]. Migrate the requested capabilities into the target framework. In writable Reference [legacy], also create or update `.agents/skills/selenium-to-playwright/SKILL.md` and `AGENTS.md` only when required for the migration. Read back the actual files and show the changes.

5. OpenCode sessions receive scoped `external_directory`, `read`, and `edit` rules for only the selected mapped reference roots. They do not get general write access outside the authorized workspaces. The selected access flags are recorded with terminal tasks and preserved across queued instructions and conversational handoffs. Changing grants between turns opens a new OpenCode session to avoid stale permissions. Grants cannot be changed for a running task in the existing session; stopping it or starting a separate tab is required.
6. Turning the lock back on affects new execution sessions. Already-running external processes cannot be assumed to lose their previously issued permissions mid-task; use **Stop** and verify remote interruption if immediate revocation is needed.

The primary workspace is writable according to the established Agent permissions. **Analyse** remains read-only. Prompt text alone does not authorize an unselected folder for OpenCode execution.

## OpenCode running jobs

- **OpenCode 2.2+** is required for the v2 API contract used by this adapter. Create via `POST /api/session`, then apply the selected workspace permissions via `PATCH /api/session/{id}` before submitting the task. The API returns success only after the permission request is accepted.
- OpenCode's runtime and model are taken from ELIYA Settings. API/model errors and connection drops surface an actionable error rather than falsely reporting completion. A failed task does not automatically rerun on Eliya, because mutation may have occurred before the error.
- The watchdog continues to warn about silence and recover activity, but by default **does not automatically interrupt a session still reported ACTIVE**. This accommodates slow corporate gateways and lengthy migrations. Operators may opt into a hard timeout with `-Deliya.opencode.noProgressTimeoutSeconds=600` (seconds); use only when an automatic interruption policy is desired. A task can still fail because of a real provider error, tool failure, or explicitly stopped execution.
- For changes to writable references, the completion check compares bounded file metadata snapshots (maximum 8,000 files across writable references, directory depth 12, no symlink traversal or build caches) before and after the task. This can verify new `SKILL.md` and `AGENTS.md` files even when OpenCode's own diff only covers the primary workspace. Changes still require independent content review, and scans exceeding the limit are reported as unverified rather than claimed successful.
- Existing logging, token usage, queue, stop/resume and lifecycle safeguards are retained.

## Verification

These are offline validations against source and mocked endpoints, **not** a live production migration against the user's installed OpenCode and provider:

```sh
bash qa/eliya118-reference-access/run.sh
bash qa/eliya52-terminal-typecheck.sh
bash qa/eliya101-ui-provider/run.sh
bash qa/eliya113-flow/run.sh
bash qa/eliya115-handoff-watchdog/run.sh
bash qa/eliya117-usage-e2e/run.sh
bash qa/workspace-boundaries/run.sh
node --test src/test/js/*.test.js
```

An end-to-end Windows validation should use two disposable local projects and verify: (1) a locked reference rejects edits, (2) an unlocked reference can receive a skill and agent file, (3) a long task continues reporting activity while OpenCode remains ACTIVE, (4) tool errors are visible, (5) Stop confirms remote state, (6) the final file report includes verified reference changes, and (7) task tokens come from real OpenCode usage, not estimates.

## Build and limitation

This archive contains source changes, not a verified runnable JAR. On an environment with Java 17+ and Maven installed, run `build-jar-windows.cmd` (Windows) or `./build-jar.sh` (macOS/Linux). The build and real OpenCode migration must be exercised on the target workstation; Maven Central was unreachable in the implementation environment, so no complete Maven/Spring Boot build is claimed.
