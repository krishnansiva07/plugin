# AGENTS.md and Skills Guide

The runtime discovers repository instructions automatically. Use `AGENTS.md` for stable repository-wide rules and `.agents/skills/<skill-name>/SKILL.md` for focused repeatable workflows.

## What belongs in AGENTS.md

Keep it short and durable: architecture boundaries, validated build/test commands, required conventions, source-of-truth locations, and non-negotiable safety/quality rules. Avoid incident logs, temporary file names, secrets, and lengthy tutorials.

## What belongs in a skill

A skill should describe one repeatable workflow such as Playwright MCP diagnosis, Selenium-to-Playwright migration, API testing, or release validation. Include when to use it, evidence to inspect, steps, verification, and stop conditions.

## Recommended structure

```text
project/
├── AGENTS.md
└── .agents/
    └── skills/
        ├── playwright-mcp-testing/
        │   └── SKILL.md
        ├── selenium-to-playwright/
        │   └── SKILL.md
        └── framework-quality/
            └── SKILL.md
```

See `examples/agent-resources/` for starter templates. Adapt them to real project evidence rather than copying them blindly.
