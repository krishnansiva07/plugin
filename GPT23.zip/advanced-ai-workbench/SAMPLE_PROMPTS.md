# Sample Prompts

These prompts are written for the Agent's plan-first workflow. Replace paths, tags, URLs, and business names with your real values. The Agent automatically reads relevant `AGENTS.md` files and `.agents/skills/<name>/SKILL.md` resources when they exist.

## Playwright MCP + Java Selenium/TestNG/Cucumber — Diagnose and Self-Heal a Failing Test

```text
Project path: C:\work\selenium-framework

This is an existing Java + Selenium + TestNG + Cucumber framework. Keep Selenium as the test runner. Use Playwright MCP only as a live-browser diagnostic tool when browser evidence is needed.

First inspect AGENTS.md, relevant .agents/skills/*/SKILL.md files, pom.xml, the Cucumber/TestNG runner, hooks, page objects, step definitions, and workspace MCP configuration. Determine the active Cucumber tag expression from the runner/configuration instead of asking me to repeat it.

Run only the active/affected test scope. If it fails, use the real failure output to identify the first actionable cause. When UI evidence is needed, use Playwright MCP to inspect the live page, DOM/accessibility tree, visibility, frames, overlays, redirects, or locator state. Do not convert the framework to Playwright and do not add Playwright to pom.xml just to use MCP.

Apply the smallest maintainable Selenium/framework fix, rerun the affected tests, and continue the fix-run-verify loop until the current revision passes or a genuine external blocker is proven. Review the final diff.

If this task reveals reusable project conventions that are not already documented, create or update a concise AGENTS.md rule or a focused .agents/skills/<skill-name>/SKILL.md resource for future runs. Do not duplicate temporary debugging facts or secrets.
```

## Java Selenium/TestNG/Cucumber — Add Tests from an Existing Feature or Requirement

```text
Project path: C:\work\selenium-framework

Inspect AGENTS.md and relevant skills first. Understand the existing Cucumber runner, feature organization, glue, hooks, driver lifecycle, page-object/component pattern, test-data pattern, reporting, and Maven execution commands.

Implement automated coverage for this requirement: <paste requirement>.

Reuse the existing framework instead of creating a parallel architecture. Add or update feature scenarios, step definitions, page objects/components, test data, and utilities only where needed. Prefer stable locators and existing abstractions. Keep scenarios business-readable and avoid duplicate steps.

Run the smallest relevant Cucumber/TestNG scope, fix compile/runtime/test failures, then run the appropriate higher-level validation if reasonable. Review the final diff and summarize exactly what was added and verified.

If you discover a reusable testing convention, document it in AGENTS.md or a focused .agents/skills/<name>/SKILL.md only when it will help future tasks.
```

## Playwright MCP — Live Browser Investigation Without Changing the Test Runner

```text
Project path: C:\work\existing-framework
Application URL: <url>

Read AGENTS.md, relevant skills, and .agents/mcp.json first. Confirm the configured Playwright MCP server and use it only for browser investigation.

Reproduce the failing user flow in the live application. Inspect the accessibility/DOM state before and after the failure, including frames, dialogs, overlays, disabled controls, redirects, network-visible error states, and candidate stable locators. Correlate that evidence with the existing test/framework code.

Do not guess selectors from screenshots. Do not migrate or replace the existing runner unless I explicitly ask. Make only evidence-backed code/config changes, run the affected test, and verify the fix on the current workspace revision.

Capture any reusable Playwright MCP investigation procedure as a focused .agents/skills/playwright-mcp-testing/SKILL.md if the project does not already have one.
```

## Playwright — Build or Improve an Existing Playwright Framework

```text
Project path: C:\work\playwright-framework

Inspect AGENTS.md, .agents/skills, package.json, playwright.config.*, fixtures, page/component objects, test-data utilities, reporters, and CI configuration before changing anything.

Improve the framework for this goal: <goal>.

Preserve existing conventions that are sound. Prefer Playwright-native auto-waiting, role/test-id locators, fixtures, isolated test state, trace/video/screenshot artifacts on failure, and parallel-safe test data. Remove redundant sleeps/retries rather than layering more retries on top.

Implement the smallest coherent change set, run lint/typecheck if configured, run the targeted Playwright tests, diagnose real failures, and continue until verified. Review the final diff.

When a pattern will be reused, create/update AGENTS.md or a focused .agents/skills/<name>/SKILL.md with stable rules, commands, and examples—not task-specific history.
```

## Migration — Java Selenium to Playwright TypeScript

```text
Target project: C:\work\playwright-framework
Source reference: C:\work\selenium-framework

Treat the Selenium project as read-only unless I explicitly say otherwise. Inspect AGENTS.md and skills in both projects, then map the source runner, features/tests, page objects, waits, data, authentication/session handling, utilities, tags, reports, and CI behavior to the target Playwright architecture.

Migrate this scope: <feature/module/tag>.

Preserve business behavior and assertions; do not mechanically translate Selenium APIs line by line. Use Playwright-native fixtures, locators, waits, storage/auth state, and parallel-safe design. Reuse existing target conventions before introducing new abstractions.

Migrate incrementally, run the smallest target test scope after each meaningful batch, fix failures, and compare coverage against the source. Do not mark migration complete until the requested source scenarios have an explicit target mapping and the target tests pass or a genuine blocker is documented.

Create/update migration guidance in AGENTS.md and, if useful, .agents/skills/selenium-to-playwright/SKILL.md so later migration batches follow the same rules.
```

## Migration — Java Selenium to Playwright Java

```text
Target project: C:\work\playwright-java
Source reference: C:\work\selenium-framework

Inspect both frameworks and their AGENTS.md / skills before planning. Migrate <scope> from Selenium to Playwright Java while preserving business intent, data, assertions, tags/categories, and CI entry points.

Do not perform API-for-API translation. Replace manual Selenium waits with Playwright waiting semantics, use resilient locators, centralize browser/context lifecycle appropriately, and keep tests parallel-safe. Reuse the target project's patterns.

Run compile plus the targeted migrated tests, fix failures using actual output, review the diff, and provide a source-to-target coverage mapping.

Persist only reusable migration rules in AGENTS.md or .agents/skills/selenium-to-playwright/SKILL.md.
```

## Development — Implement a Feature in an Existing Application

```text
Project path: <path>

Inspect AGENTS.md, relevant skills, project structure, build configuration, and the nearest implementation/tests before planning.

Implement this feature: <requirement>.

Trace the existing architecture and data flow first. Reuse established patterns and public contracts. Keep the change focused, add/update tests for the requested behavior and important edge cases, and avoid unrelated refactoring.

Run the smallest high-signal build/test/check, fix failures caused by the change, then review the final diff. Do not claim completion without real verification.

If the work establishes a stable convention future developers/agents should follow, update AGENTS.md or add a focused skill. Keep those resources concise and reusable.
```

## Development — Diagnose and Fix a Bug

```text
Project path: <path>
Failure/error: <paste error or reproduction>

Read AGENTS.md and relevant skills. Reproduce or trace the failure using the smallest relevant command/test. Identify the first actionable root cause from code and runtime evidence; do not patch symptoms blindly.

Implement the smallest correct fix, add or update a regression test when practical, rerun the failing scope, and review the final diff. Continue until the current revision passes or a proven external blocker remains.

Record only a reusable diagnostic/fix convention in AGENTS.md or a skill if it will prevent repeated future work.
```

## Testing — API Contract and Regression Coverage

```text
Project path: <path>
API/requirement: <details>

Inspect AGENTS.md, relevant skills, existing API client/test utilities, schemas, authentication setup, test-data builders, and CI test commands.

Add focused automated coverage for happy paths, validation, authorization, important boundary values, error contracts, and backward-compatible response fields appropriate to this API. Reuse the existing framework and data patterns.

Execute the targeted suite, fix test or framework issues exposed by the new coverage, and summarize what behavior is now verified. Do not weaken assertions merely to make tests pass.

If reusable API-testing rules emerge, capture them in .agents/skills/api-testing/SKILL.md or AGENTS.md.
```

## Testing — Stabilize a Flaky UI Regression Suite

```text
Project path: <path>
Scope/tag: <scope>

Inspect AGENTS.md, skills, runner configuration, retries, waits, locators, fixtures/hooks, test data, parallel execution, and recent failure artifacts.

Run the smallest representative failing scope and classify each failure by evidence: product defect, locator instability, synchronization, shared state/test data, environment, or framework defect. Fix root causes; do not simply increase sleeps or global retries.

Rerun the affected tests enough to prove the current revision is stable within the available environment, then review the final diff and remaining external risks.

Capture stable anti-flakiness conventions in AGENTS.md or a focused UI-testing skill for future work.
```

## CI/CD — Repair or Optimize the Existing Pipeline

```text
Project path: <path>
Pipeline goal/failure: <details>

Inspect AGENTS.md, skills, build scripts, CI configuration, caching, test splitting, artifacts, environment variables, and the commands developers run locally.

Diagnose the current pipeline from configuration and real logs. Make focused changes that preserve security and reproducibility. Improve speed through safe caching, parallelism, scope selection, and elimination of duplicate work without skipping required quality gates.

Validate configuration syntax and run the closest local checks available. Clearly distinguish verified behavior from CI-only behavior that cannot be executed locally.

Document stable pipeline commands/conventions in AGENTS.md or a CI skill if useful for future agent runs.
```

## Code Review — Refactor Without Behavioral Drift

```text
Project path: <path>
Scope: <files/module>

Inspect AGENTS.md, relevant skills, tests, and callers before editing. Review the scope for correctness risks, duplication, overly complex control flow, error handling, concurrency/resource issues, and maintainability.

Refactor only where the benefit is concrete. Preserve external behavior and public contracts. Add/adjust tests for any behavior that was previously implicit or risky.

Run targeted build/tests/checks and review the final diff. Explain the measurable improvement and any deliberate non-changes.

Update AGENTS.md or a skill only for stable architectural/testing conventions, not opinions specific to this one refactor.
```

## Generic — Analyze a Framework and Create Future Agent Guidance

```text
Project path: <path>

Analyze the repository deeply but make no product-code changes unless needed to validate your findings. Read existing AGENTS.md, CLAUDE.md, .agents/skills, build/test configuration, architecture docs, and representative implementation/tests.

Identify the commands, architecture boundaries, coding/testing conventions, safety constraints, common workflows, and recurring failure patterns that a future coding agent must know.

Create or improve a concise root AGENTS.md and only the focused .agents/skills/<name>/SKILL.md files that materially improve future work. Keep instructions stable, evidence-based, non-duplicative, and free of secrets. Include exact validated commands where available.

Validate that the resources match the repository and do not conflict with existing instructions. Summarize what future tasks these resources improve.
```
