# Repository Agent Instructions

## Purpose
Use this file for stable repository-wide rules. Keep task-specific notes, secrets, incident logs, and temporary paths out of it.

## Before changing code
1. Read the build configuration, nearest implementation, nearest tests, and relevant `.agents/skills/*/SKILL.md` files.
2. Reuse the current architecture and framework conventions before introducing a new abstraction.
3. Derive execution scope (tags, suites, modules, commands) from repository configuration when possible instead of asking the user to repeat it.

## Execution rules
- Work only inside the mapped project/resource paths.
- Prefer the smallest high-signal command/test first, then broaden validation when justified.
- Do not mark a planned step complete without real tool evidence.
- Code/config mutations must be verified on the current revision before the related plan step is completed.
- Do not hide failures with arbitrary sleeps, blanket retries, weaker assertions, or skipped tests.

## Quality
- Keep changes focused and review the final diff.
- Preserve public behavior outside the requested scope.
- Add/update focused tests when behavior changes or a regression is being fixed.
- Stop and report a blocker only when it is supported by concrete evidence.

## Commands
Replace these placeholders with commands validated for this repository:
- Build: `<build command>`
- Targeted test: `<targeted test command>`
- Full verification: `<full verification command>`

## Reusable knowledge
When a task reveals a stable repeatable workflow, update this file or create a focused skill. Do not duplicate the same instruction in multiple resources.
