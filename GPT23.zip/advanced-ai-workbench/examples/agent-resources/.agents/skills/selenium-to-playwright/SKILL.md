# Selenium to Playwright Migration

## Use when
Migrating an existing Java Selenium framework or selected modules/features to Playwright.

## Principles
- Preserve business behavior and coverage, not Selenium API shape.
- Treat the source framework as read-only unless explicitly authorized.
- Reuse the target framework's fixtures, page/component patterns, reporting, data, and CI conventions.
- Prefer Playwright-native locators, auto-waiting, browser-context isolation, and parallel-safe state.

## Workflow
1. Map source runner/tags, scenarios/tests, page objects, waits, data, auth/session state, assertions, reports, and CI entry points.
2. Define an explicit source-to-target coverage mapping for the requested scope.
3. Migrate one coherent slice at a time.
4. Run the smallest target validation after each meaningful slice.
5. Fix target failures using actual runtime evidence; do not copy brittle Selenium waits/retries.
6. Run the requested final target scope and review the diff.
7. Update the coverage mapping and reusable migration rules.

## Completion
Do not call migration complete while requested source behavior lacks a target mapping or the target verification is failing without a proven external blocker.
