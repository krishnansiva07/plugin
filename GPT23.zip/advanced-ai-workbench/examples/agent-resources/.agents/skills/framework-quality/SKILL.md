# Framework Quality and Stability

## Use when
Improving an existing development or test framework for maintainability, speed, reliability, or CI quality.

## Inspect
- Build/test configuration and validated commands
- Lifecycle/fixtures/hooks and shared state
- Wait/retry policy and locator strategy for UI automation
- Test data and parallel execution
- Error handling, logging, reporting, failure artifacts, and CI behavior
- Duplicate utilities and unnecessary abstraction layers

## Workflow
1. Establish a measurable problem from code, logs, timings, or failures.
2. Identify the smallest root-cause change with the best expected impact.
3. Preserve existing external behavior and framework entry points unless the task requires otherwise.
4. Implement focused changes and targeted tests/checks.
5. Compare before/after evidence where practical.
6. Review the final diff for accidental complexity or behavior drift.

## Anti-patterns
Do not improve apparent stability by adding arbitrary sleeps, unlimited retries, broad exception swallowing, disabled tests, or weaker assertions.
