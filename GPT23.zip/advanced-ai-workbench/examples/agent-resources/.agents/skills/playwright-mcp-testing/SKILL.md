# Playwright MCP Browser Diagnosis

## Use when
An existing Selenium/TestNG/Cucumber or other non-Playwright runner needs live-browser evidence to diagnose a UI failure.

## Rules
- Keep the existing framework as the test runner unless migration is explicitly requested.
- Use Playwright MCP for live DOM/accessibility, frames, dialogs, overlays, redirects, visibility, and stable locator evidence.
- Do not add Playwright as a Java test dependency merely to use MCP.
- Prefer structured browser evidence over screenshot-coordinate guessing.

## Workflow
1. Read runner/tag configuration, hooks, affected page/component code, failure output, and `.agents/mcp.json`.
2. Derive the active test scope from repository configuration.
3. Run the smallest failing scope and capture the first actionable failure.
4. If browser evidence is needed, reproduce the flow with Playwright MCP and inspect the relevant live state.
5. Correlate browser evidence with the existing automation code.
6. Apply the smallest maintainable framework/test fix.
7. Rerun the affected scope and verify the current revision.
8. Review the final diff and report evidence.

## Stop conditions
Finish only when the affected scope passes on the current revision or a genuine external blocker is proven.
