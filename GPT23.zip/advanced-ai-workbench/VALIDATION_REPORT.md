# Validation Report — GPT22 Improved Package

Validation date: 2026-09-11

## Release status

**Package status: READY FOR USER VALIDATION.**

The dependency-independent checks and executable core harnesses below pass. A complete Spring Boot Maven build could not be executed inside this sandbox because `repo.maven.apache.org` cannot be resolved from the environment. This limitation is external to the project. Run `validate-local.bat` (Windows) or `./validate-local.sh` (Linux/macOS) on a machine with Maven/dependency access before production use.

## Passed checks

- Frontend JavaScript syntax: PASS
  - `node --check src/main/resources/static/app.js`
  - `node --check src/main/resources/static/markdown.js`
- Shell syntax: PASS
  - `run.sh`
  - `validate-local.sh`
  - Maven wrapper shell script
- `pom.xml` XML parse: PASS
- `index.html` parser check: PASS
- Java 17 source compatibility/syntax scan: PASS for syntax/language level
  - full source was parsed with `javac --release 17 -proc:none`
  - no syntax errors or Java >17 language-feature diagnostics were found
  - unresolved external Spring/Jackson/JPA/Tika symbols are expected because dependencies are unavailable in this sandbox
- Compiled-artifact hygiene: PASS
  - no `.class` files are included in the source tree
- Basic secret-literal scan: PASS
  - no OpenAI/GitHub/Google-style credential literals detected
- Hard-coded Windows path scan in Java production sources: PASS
  - no `C:\...` production-source dependency
- Prompt resources: PASS
  - 13 titled sample-prompt sections
  - built-in UI Prompt library
  - 4 real starter files under `examples/agent-resources/`

## Executable Java 17 core harnesses

### Sequential plan + progress + history

PASS:

- symbol-only decorations such as `✅` and `→` are not accepted as planned steps
- tool/activity updates do not advance plan-derived progress
- approved planned steps cannot be skipped
- execution cannot jump over the active planned step
- mutation steps cannot complete without current-revision verification
- exactly the next planned step unlocks after successful completion
- completed-step evidence persists across Agent-run reload
- retained conversation Agent runs are restorable
- a run cannot report `completed` while approved plan items remain incomplete; it becomes `blocked`

### Durable application/history path

PASS:

- default data is resolved beneath the per-user durable home rather than the extracted/JAR directory
- conversation DB, uploads, cache metadata, and Agent-run state share the durable data root
- application-folder replacement therefore does not intentionally create a fresh history location
- legacy beside-JAR data migration remains best-effort and non-overwriting

### Long-command memory protection

PASS:

- small command output is retained exactly
- very large output is bounded in memory
- retained output preserves the beginning and latest tail
- truncation is explicit and includes an omitted-character count
- production command loop contains periodic activity heartbeats (first after ~5 seconds, then ~10-second intervals) without moving the plan-derived percentage

## UI/runtime improvements verified by source inspection

- approved plan and activity events are rendered separately
- browser Agent activity retention is bounded (`MAX_AGENT_EVENTS_RETAINED`)
- high-volume Agent rendering is throttled and updates the Agent card instead of rebuilding the full conversation per event
- completed planned steps expose expandable `Completed details`
- progress summary uses completed approved-plan count
- history reopening requests all retained Agent runs for the conversation and maps them back to their persisted assistant messages
- UI has no visible product version label and no `BNP green design` text
- Prompt library includes Playwright MCP/Selenium, Playwright, migration, development, testing, CI/CD and framework-analysis workflows

## Added release-hardening change

Foreground command execution now uses a bounded output collector (160k retained characters with head/tail preservation) and periodic activity heartbeats. This specifically reduces memory pressure and improves visible movement during long Maven, Playwright, Java test, npm, or similar foreground commands.

## Maven build limitation in this environment

Attempted:

```text
./mvnw -version
```

Result:

```text
Maven was not found. Bootstrapping Apache Maven 3.9.11...
curl: (6) Could not resolve host: repo.maven.apache.org
```

Therefore this report does **not** claim a dependency-backed Spring Boot `clean install` in the sandbox.

## Required full validation on your machine

Windows:

```bat
validate-local.bat
mvnw.cmd -Pfull-tests test
```

Linux/macOS:

```bash
./validate-local.sh
./mvnw -Pfull-tests test
```

A successful normal build should produce:

```text
target/advanced-ai-workbench.jar
```
