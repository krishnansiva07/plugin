package com.llmart.llm.service;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class BoundedCommandOutputTest {
    @Test
    void keepsSmallOutputExactly() {
        BoundedCommandOutput output = new BoundedCommandOutput(8_192, 1_024);
        output.append("hello\nworld");
        assertEquals(11, output.totalChars());
        assertEquals("hello\nworld", output.text());
    }

    @Test
    void boundsLargeOutputAndKeepsHeadAndTail() {
        BoundedCommandOutput output = new BoundedCommandOutput(8_192, 1_024);
        String input = "HEAD" + "x".repeat(12_000) + "TAIL";
        output.append(input);
        String shown = output.text();
        assertEquals(input.length(), output.totalChars());
        assertTrue(shown.startsWith("HEAD"));
        assertTrue(shown.endsWith("TAIL"));
        assertTrue(shown.contains("command output truncated"));
        assertTrue(shown.length() < input.length());
    }
}
