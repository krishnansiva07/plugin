package com.llmart.llm.service;

/**
 * Keeps complete small command output and bounded head/tail evidence for very large command transcripts.
 * Package-private so command-execution behavior can be validated independently of Spring/tool dependencies.
 */
final class BoundedCommandOutput {
    private final int maxChars;
    private final int headChars;
    private final int tailChars;
    private final StringBuilder head;
    private final StringBuilder tail;
    private long totalChars;
    private boolean truncated;

    BoundedCommandOutput(int maxChars, int headChars) {
        this.maxChars = Math.max(8_192, maxChars);
        this.headChars = Math.max(1_024, Math.min(headChars, this.maxChars / 2));
        this.tailChars = this.maxChars - this.headChars;
        this.head = new StringBuilder(this.headChars);
        this.tail = new StringBuilder(this.tailChars);
    }

    synchronized void append(char[] chars, int offset, int length) {
        if (chars == null || length <= 0) return;
        totalChars += length;
        int index = offset;
        int remaining = length;
        if (head.length() < headChars) {
            int take = Math.min(remaining, headChars - head.length());
            head.append(chars, index, take);
            index += take;
            remaining -= take;
        }
        if (remaining > 0) {
            truncated = true;
            tail.append(chars, index, remaining);
            trimTail();
        }
    }

    synchronized void append(String value) {
        if (value == null || value.isEmpty()) return;
        append(value.toCharArray(), 0, value.length());
    }

    synchronized long totalChars() { return totalChars; }

    synchronized String text() {
        if (!truncated) return head.toString();
        long omitted = Math.max(0L, totalChars - head.length() - tail.length());
        return head + "\n...[command output truncated; " + omitted + " chars omitted]...\n" + tail;
    }

    private void trimTail() {
        int overflow = tail.length() - tailChars;
        if (overflow > 0) tail.delete(0, overflow);
    }
}
