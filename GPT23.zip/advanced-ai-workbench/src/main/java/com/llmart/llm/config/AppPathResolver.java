package com.llmart.llm.config;

import java.net.URISyntaxException;
import java.net.URL;
import java.nio.file.*;
import java.util.Comparator;

/** Resolves application-owned paths with a durable per-user data location. */
public final class AppPathResolver {

    private AppPathResolver() { }

    public static Path resolveApplicationRoot(Class<?> applicationClass) {
        try {
            URL location = applicationClass.getProtectionDomain().getCodeSource().getLocation();
            if (location != null) {
                Path codeSourcePath = Paths.get(location.toURI()).toAbsolutePath().normalize();
                if (Files.isRegularFile(codeSourcePath)) return safeCreateDirectories(codeSourcePath.getParent());
                String normalized = codeSourcePath.toString().replace('\\', '/');
                if (normalized.endsWith("/target/classes") || normalized.endsWith("/build/classes/java/main")) {
                    Path parent = codeSourcePath.getParent();
                    if (parent != null && parent.getParent() != null) {
                        return safeCreateDirectories(parent.getParent().toAbsolutePath().normalize());
                    }
                }
                return safeCreateDirectories(codeSourcePath);
            }
        } catch (URISyntaxException | RuntimeException ignored) { }
        return safeCreateDirectories(Paths.get("").toAbsolutePath().normalize());
    }

    public static void initializeSystemProperties(Class<?> applicationClass) {
        Path appRoot = resolveApplicationRoot(applicationClass);

        // Keep user history independent from the extracted/build/JAR directory. Replacing the application folder
        // must not create a fresh chat database or hide previous agent-run state.
        Path durableHome = configuredPath("advanced.ai.home",
                Paths.get(System.getProperty("user.home", "."), ".advanced-ai-workbench"));
        Path dataDir = configuredPath("app.data-dir", durableHome.resolve("data"));
        Path logsDir = configuredPath("app.logs-dir", durableHome.resolve("logs"));
        Path cacheDir = configuredPath("app.cache-dir", durableHome.resolve("cache"));

        safeCreateDirectories(dataDir);
        safeCreateDirectories(logsDir);
        safeCreateDirectories(cacheDir);
        migrateLegacyData(appRoot.resolve("data"), dataDir);

        Path uploadsDir = safeCreateDirectories(configuredPath("app.upload-dir", dataDir.resolve("uploads")));
        Path agentCacheDir = safeCreateDirectories(configuredPath("app.agent-cache-dir", dataDir.resolve("agent-cache")));
        Path agentRunStoreDir = safeCreateDirectories(configuredPath("advanced.ai.agentRunStore", dataDir.resolve("agent-runs")));

        setIfMissing("app.root", appRoot.toString());
        setIfMissing("advanced.ai.home", durableHome.toString());
        setIfMissing("app.data-dir", dataDir.toString());
        setIfMissing("app.logs-dir", logsDir.toString());
        setIfMissing("app.cache-dir", cacheDir.toString());
        setIfMissing("app.database.path", dataDir.resolve("chatdb").toString());
        setIfMissing("app.upload-dir", uploadsDir.toString());
        setIfMissing("app.agent-cache-dir", agentCacheDir.toString());
        setIfMissing("advanced.ai.agentRunStore", agentRunStoreDir.toString());
    }

    private static Path configuredPath(String key, Path fallback) {
        String value = System.getProperty(key);
        Path path = value == null || value.isBlank() ? fallback : Paths.get(value.trim());
        return path.toAbsolutePath().normalize();
    }

    /** One-time best-effort migration from the historical beside-JAR data directory. Never overwrites durable data. */
    private static void migrateLegacyData(Path legacy, Path target) {
        try {
            legacy = legacy.toAbsolutePath().normalize();
            target = target.toAbsolutePath().normalize();
            if (legacy.equals(target) || !Files.isDirectory(legacy)) return;
            if (Files.exists(target.resolve("chatdb.mv.db")) || Files.exists(target.resolve("chatdb.trace.db"))) return;
            Files.createDirectories(target);
            try (var paths = Files.walk(legacy)) {
                for (Path source : paths.sorted(Comparator.comparingInt(Path::getNameCount)).toList()) {
                    Path relative = legacy.relativize(source);
                    Path destination = target.resolve(relative).normalize();
                    if (!destination.startsWith(target)) continue;
                    if (Files.isDirectory(source)) Files.createDirectories(destination);
                    else if (!Files.exists(destination)) Files.copy(source, destination, StandardCopyOption.COPY_ATTRIBUTES);
                }
            }
        } catch (Exception ignored) {
            // Migration is best effort. Existing configured storage is never deleted or overwritten.
        }
    }

    private static void setIfMissing(String key, String value) {
        String existing = System.getProperty(key);
        if (existing == null || existing.isBlank()) System.setProperty(key, value);
    }

    private static Path safeCreateDirectories(Path path) {
        try { Files.createDirectories(path); } catch (Exception ignored) { }
        return path.toAbsolutePath().normalize();
    }
}
