package com.llmart.llm.controller;

import com.llmart.llm.service.AgentApprovalService;
import com.llmart.llm.service.AgentRunService;
import org.springframework.web.bind.annotation.*;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/agent")
public class AgentController {
    private final AgentApprovalService approvals;
    private final AgentRunService runs;

    public AgentController(AgentApprovalService approvals, AgentRunService runs) {
        this.approvals = approvals;
        this.runs = runs;
    }

    @PostMapping("/approvals/{id}")
    public Map<String, Object> resolve(@PathVariable String id, @RequestBody Map<String, Object> body) {
        String action = String.valueOf(body.getOrDefault("action", "")).trim().toLowerCase();
        AgentApprovalService.Decision decision;
        if ("run".equals(action) || "always".equals(action)) decision = AgentApprovalService.Decision.RUN;
        else if ("once".equals(action) || Boolean.TRUE.equals(body.get("approved"))) decision = AgentApprovalService.Decision.ONCE;
        else decision = AgentApprovalService.Decision.DENY;
        boolean resolved = approvals.resolve(id, decision);
        return Map.of("resolved", resolved, "decision", decision.name().toLowerCase());
    }


    @PutMapping("/runs/{id}/plan")
    public Map<String, Object> updatePlan(@PathVariable String id, @RequestBody Map<String, Object> body) {
        Object raw = body.get("items");
        java.util.List<String> items = new java.util.ArrayList<>();
        if (raw instanceof java.util.Collection<?> values) {
            for (Object value : values) {
                String text = value == null ? "" : String.valueOf(value).trim();
                if (!text.isBlank()) items.add(text);
            }
        }
        AgentRunService.AgentRun run = runs.require(id);
        run.replaceDraftPlan(items);
        return run.snapshot();
    }

    @PostMapping("/runs/{id}/cancel")
    public Map<String, Object> cancel(@PathVariable String id) {
        boolean cancelled = runs.cancel(id);
        int approvalsReleased = approvals.cancelRun(id);
        Map<String,Object> result = new LinkedHashMap<>();
        result.put("cancelled", cancelled);
        result.put("approvalsReleased", approvalsReleased);
        return result;
    }

    @GetMapping("/runs/{id}")
    public Map<String, Object> status(@PathVariable String id) {
        return runs.status(id);
    }

    @GetMapping("/conversations/{conversationId}/latest-run")
    public Map<String, Object> latestRun(@PathVariable String conversationId) {
        return runs.latestForConversation(conversationId).orElseGet(Map::of);
    }

    @GetMapping("/conversations/{conversationId}/runs")
    public List<Map<String, Object>> conversationRuns(@PathVariable String conversationId) {
        return runs.forConversation(conversationId);
    }
}
