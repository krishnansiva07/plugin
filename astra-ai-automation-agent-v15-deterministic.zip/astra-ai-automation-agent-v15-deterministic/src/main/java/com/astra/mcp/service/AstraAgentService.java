package com.astra.mcp.service;

import com.astra.mcp.dto.AgentRequest;
import com.astra.mcp.dto.AgentResponse;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import dev.langchain4j.model.chat.ChatLanguageModel;
import org.springframework.stereotype.Service;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Service
public class AstraAgentService {

    private static final Pattern REF_PATTERN = Pattern.compile("(?:\\[ref=|ref=)(e\\d+)");
    private static final Pattern QUOTED_TEXT_PATTERN = Pattern.compile("\\\"([^\\\"]+)\\\"");

    private final ChatLanguageModel llm;
    private final McpClientService mcpClient;
    private final CommandService commandService;
    private final ObjectMapper objectMapper = new ObjectMapper();

    public AstraAgentService(ChatLanguageModel llm,
                             McpProcessService ignored,
                             McpClientService mcpClient,
                             CommandService commandService) {
        this.llm = llm;
        this.mcpClient = mcpClient;
        this.commandService = commandService;
    }

    public synchronized AgentResponse run(AgentRequest request) {
        AgentResponse response = new AgentResponse();
        response.status = "RUNNING";

        try {
            applyDefaults(request);
            Map<String, Object> testData = parseJsonObject(request.testDataJson);

            List<String> missingBeforeBrowser = detectObviousMissingData(request, testData);
            if (!missingBeforeBrowser.isEmpty()) {
                return missingDataResponse(response, "Required test data is missing before browser execution.", missingBeforeBrowser);
            }

            if (request.generatePlan) {
                Map<String, Object> plan = createExecutionPlan(request, testData);
                response.planStatus = stringValue(plan.getOrDefault("planStatus", "CREATED"));
                response.executionPlan = asMapList(plan.get("steps"));
                List<String> planMissing = asStringList(plan.get("missingData"));
                if (!planMissing.isEmpty()) {
                    return missingDataResponse(response, "Required test data is missing from the execution plan.", planMissing);
                }
            } else {
                response.planStatus = "SKIPPED";
            }

            mcpClient.start(request.ignoreHttpsErrors, request.userDataDir);
            mcpClient.initialize();

            Map<String, Object> navigateResult = callToolAndFailFast("browser_navigate", Map.of("url", request.applicationUrl));
            addTrace(response, 0, "NAVIGATE", "browser_navigate", Map.of("url", request.applicationUrl),
                    "Open application", 100, navigateResult, "PASSED");
            sleep(request.liveActionDelayMs);

            if (request.manualAssistBeforeRun && request.manualAssistWaitSeconds > 0) {
                addTrace(response, 0, "MANUAL_ASSIST_WAIT", "browser_wait_for", Map.of("time", request.manualAssistWaitSeconds),
                        "Manual assist wait before agent starts", 100,
                        mcpClient.tool("browser_wait_for", Map.of("time", Math.max(1, request.manualAssistWaitSeconds))), "PASSED");
            }

            String snapshot = snapshotWithRetry();
            boolean goalReached = false;

            for (int step = 1; step <= request.maxAgentSteps; step++) {
                if (expectedLooksVisible(request.expectedResult, snapshot, response.actionTrace)) {
                    goalReached = true;
                    response.message = "Expected result appears to be visible.";
                    break;
                }

                List<UiElement> elements = parseElements(snapshot);
                Map<String, Object> action = decideSafeAction(request, snapshot, testData, compactTrace(response.actionTrace), response.executionPlan, elements);

                List<String> missingData = asStringList(action.get("missingData"));
                if (!missingData.isEmpty()) {
                    response.finalSnapshot = compactSnapshot(snapshot);
                    return missingDataResponse(response, "Required test data is missing. Agent stopped without guessing.", missingData);
                }

                if (asBoolean(action.get("done"))) {
                    goalReached = true;
                    response.message = stringValue(action.getOrDefault("reason", "Agent marked scenario as done."));
                    break;
                }

                int confidence = asInt(action.get("confidence"), 100);
                if (confidence < request.minActionConfidence) {
                    response.status = "BLOCKED_LOW_CONFIDENCE";
                    response.message = "Agent stopped because action confidence was " + confidence + " below threshold " + request.minActionConfidence + ". Action: " + action;
                    response.finalSnapshot = compactSnapshot(snapshot);
                    return response;
                }

                SafeMcpCall call = buildMcpCall(action, elements, testData);
                if (!call.isExecutable()) {
                    // Take a short wait and a fresh snapshot once before failing. Many enterprise screens update late.
                    mcpClient.tool("browser_wait_for", Map.of("time", 1));
                    sleep(Math.min(1000, Math.max(200, request.liveActionDelayMs / 2)));
                    snapshot = snapshotWithRetry();
                    elements = parseElements(snapshot);
                    call = buildMcpCall(action, elements, testData);
                }

                if (!call.isExecutable()) {
                    response.status = "BLOCKED_UNRESOLVED_ACTION";
                    response.message = "Could not safely resolve action to a visible MCP element. No raw LLM tool call was sent. Action=" + action + ", reason=" + call.error;
                    response.finalSnapshot = compactSnapshot(snapshot);
                    return response;
                }

                Map<String, Object> toolResult = executeToolWithRecovery(call.toolName, call.arguments, request.liveActionDelayMs);
                addTrace(response, step, stringValue(action.get("action")), call.toolName, call.arguments,
                        stringValue(action.get("reason")), confidence, toolResult, mcpClient.isError(toolResult) ? "FAILED" : "PASSED");

                if (mcpClient.isError(toolResult)) {
                    response.status = "ERROR";
                    response.message = "MCP tool call failed at step " + step + " after deterministic recovery. " + summarizeMcpError(toolResult);
                    response.finalSnapshot = compactSnapshot(snapshot);
                    return response;
                }

                sleep(request.liveActionDelayMs);
                snapshot = snapshotWithRetry();
            }

            response.finalSnapshot = compactSnapshot(snapshot);
            if (!goalReached) {
                response.message = "Max agent steps reached. Code generated only from successful executed trace; review may be required.";
            }

            response.generatedCode = cleanCode(llm.generate(codePrompt(request, response.actionTrace, response.finalSnapshot)));

            if (request.saveToProject) {
                response.savedFilePath = saveGeneratedCode(request, response.generatedCode);
            }

            if (request.validateGeneratedCode && response.savedFilePath != null) {
                validateGeneratedCode(request, response);
            } else {
                response.validationStatus = "NOT_REQUESTED";
            }

            if (request.closeBrowserAfterRun) {
                mcpClient.tool("browser_close", Map.of());
            }

            if (response.validationStatus != null && response.validationStatus.startsWith("PASSED")) {
                response.status = "SUCCESS";
            } else if (goalReached) {
                response.status = "LIVE_FLOW_COMPLETED";
            } else {
                response.status = "GENERATED_REVIEW_REQUIRED";
            }

            return response;
        } catch (Exception e) {
            response.status = "ERROR";
            response.message = e.getMessage();
            return response;
        }
    }

    private Map<String, Object> decideSafeAction(AgentRequest request,
                                                 String snapshot,
                                                 Map<String, Object> testData,
                                                 List<Map<String, Object>> compactTrace,
                                                 List<Map<String, Object>> plan,
                                                 List<UiElement> elements) throws Exception {
        String raw = llm.generate(actionIntentPrompt(request, snapshot, testData, compactTrace, plan, elements));
        Map<String, Object> action = parseJsonObject(raw);
        if (!action.containsKey("action") && !asBoolean(action.get("done"))) {
            return heuristicAction(request, testData, compactTrace, elements);
        }
        return normalizeAction(action);
    }

    private String actionIntentPrompt(AgentRequest request,
                                      String snapshot,
                                      Map<String, Object> testData,
                                      List<Map<String, Object>> compactTrace,
                                      List<Map<String, Object>> plan,
                                      List<UiElement> elements) throws Exception {
        return """
                You are not allowed to call Playwright MCP tools directly.
                Return ONLY a safe high-level action intent as JSON. Java will resolve it to MCP safely.

                Goal:
                %s

                Expected Result:
                %s

                Test Data JSON:
                %s

                Pre-action Instructions:
                %s

                Execution Plan:
                %s

                Executed trace summary:
                %s

                Visible actionable element summary:
                %s

                Current snapshot summary:
                %s

                Allowed JSON actions ONLY:
                1. {"done":true,"reason":"expected result visible","confidence":100}
                2. {"done":false,"action":"TYPE","field":"username/password/search/reference/etc","valueKey":"username","confidence":90,"reason":"..."}
                3. {"done":false,"action":"CLICK","field":"login/save/search/next/etc","confidence":90,"reason":"..."}
                4. {"done":false,"action":"CLICK_TEXT","text":"visible exact text","confidence":90,"reason":"..."}
                5. {"done":false,"action":"CLICK_TEXT","textKey":"agreementReference","confidence":90,"reason":"..."}
                6. {"done":false,"action":"WAIT","seconds":2,"confidence":90,"reason":"..."}
                7. {"done":false,"action":"WAIT_FOR_TEXT","text":"Products","confidence":90,"reason":"..."}
                8. {"done":false,"action":"PRESS_KEY","key":"Escape","confidence":90,"reason":"..."}
                9. {"done":false,"missingData":["password"]}

                Hard rules:
                - Never return browser_click, browser_type, browser_wait_for, target, ref, selector, XPath, or raw MCP arguments.
                - Never invent business data. Use valueKey/textKey from Test Data JSON when typing/clicking dynamic values.
                - For table/grid results, prefer CLICK_TEXT using the exact visible reference/cell text from test data.
                - For overlay/toast/loading screens, use WAIT with seconds 2 before click.
                - If expected result is already visible, return done true.
                - If unsure, return confidence below threshold; do not guess.
                """.formatted(
                safe(request.scenario),
                safe(request.expectedResult),
                objectMapper.writeValueAsString(testData),
                safe(request.preActionInstructions),
                objectMapper.writeValueAsString(plan),
                objectMapper.writeValueAsString(compactTrace),
                summarizeElements(elements),
                compactSnapshot(snapshot)
        );
    }

    private Map<String, Object> normalizeAction(Map<String, Object> action) {
        Map<String, Object> normalized = new LinkedHashMap<>();
        normalized.putAll(action);
        String actionName = stringValue(normalized.get("action")).toUpperCase(Locale.ROOT);
        if (!actionName.isBlank()) {
            normalized.put("action", actionName);
        }
        if ("WAIT".equals(actionName)) {
            if (!normalized.containsKey("seconds")) normalized.put("seconds", 2);
            int seconds = asInt(normalized.get("seconds"), 2);
            normalized.put("seconds", Math.max(1, Math.min(seconds, 10)));
        }
        if ("PRESS_KEY".equals(actionName) && isBlank(stringValue(normalized.get("key")))) {
            normalized.put("key", "Escape");
        }
        if (!normalized.containsKey("confidence")) {
            normalized.put("confidence", 80);
        }
        return normalized;
    }

    private Map<String, Object> heuristicAction(AgentRequest request,
                                                Map<String, Object> testData,
                                                List<Map<String, Object>> trace,
                                                List<UiElement> elements) {
        String scenario = safe(request.scenario).toLowerCase(Locale.ROOT);
        Set<String> doneFields = fieldsAlreadyTyped(trace);

        if ((scenario.contains("login") || scenario.contains("sign in") || scenario.contains("signin"))) {
            if (!doneFields.contains("username") && hasAnyKey(testData, "username", "user", "userName", "userid", "userId", "email")) {
                return mapAction("TYPE", "username", firstExistingKey(testData, "username", "user", "userName", "userid", "userId", "email"), null, null, 85, "Heuristic login: type username");
            }
            if (!doneFields.contains("password") && hasAnyKey(testData, "password", "passcode")) {
                return mapAction("TYPE", "password", firstExistingKey(testData, "password", "passcode"), null, null, 85, "Heuristic login: type password");
            }
            if (findBestElement(elements, "login sign in submit", "button link", false) != null) {
                return mapAction("CLICK", "login sign in submit", null, null, null, 85, "Heuristic login: click login/sign in");
            }
        }

        for (String key : testData.keySet()) {
            String value = String.valueOf(testData.get(key));
            if (value.length() > 2 && containsVisibleText(elements, value)) {
                return mapAction("CLICK_TEXT", null, null, value, null, 75, "Heuristic: click visible test-data text " + key);
            }
        }

        return mapAction("WAIT", null, null, null, null, 65, "Fallback safe wait");
    }

    private Map<String, Object> mapAction(String action, String field, String valueKey, String text, String textKey, int confidence, String reason) {
        Map<String, Object> map = new LinkedHashMap<>();
        map.put("done", false);
        map.put("action", action);
        if (field != null) map.put("field", field);
        if (valueKey != null) map.put("valueKey", valueKey);
        if (text != null) map.put("text", text);
        if (textKey != null) map.put("textKey", textKey);
        map.put("confidence", confidence);
        map.put("reason", reason);
        return map;
    }

    private SafeMcpCall buildMcpCall(Map<String, Object> action, List<UiElement> elements, Map<String, Object> testData) {
        String actionName = stringValue(action.get("action")).toUpperCase(Locale.ROOT);
        SafeMcpCall call = new SafeMcpCall();
        call.intent = actionName;

        try {
            switch (actionName) {
                case "TYPE" -> {
                    String field = stringValue(action.get("field"));
                    String valueKey = stringValue(action.get("valueKey"));
                    if (isBlank(valueKey)) return call.fail("TYPE action requires valueKey.");
                    if (!testData.containsKey(valueKey)) return call.fail("Missing test data key: " + valueKey);
                    UiElement element = findBestTypeElement(elements, field, valueKey);
                    if (element == null) return call.fail("No visible textbox/input resolved for field: " + field);
                    call.toolName = "browser_type";
                    call.arguments = new LinkedHashMap<>();
                    call.arguments.put("element", element.displayName());
                    call.arguments.put("target", element.ref);
                    call.arguments.put("text", String.valueOf(testData.get(valueKey)));
                    call.resolvedElement = element;
                    return call;
                }
                case "CLICK" -> {
                    String field = stringValue(action.get("field"));
                    UiElement element = findBestElement(elements, field, "button link checkbox radio tab row cell text", false);
                    if (element == null) return call.fail("No visible clickable element resolved for field: " + field);
                    call.toolName = "browser_click";
                    call.arguments = Map.of("element", element.displayName(), "target", element.ref);
                    call.resolvedElement = element;
                    return call;
                }
                case "CLICK_TEXT" -> {
                    String text = resolveTextFromAction(action, testData);
                    if (isBlank(text)) return call.fail("CLICK_TEXT requires text or textKey.");
                    UiElement element = findBestElementByVisibleText(elements, text);
                    if (element == null) return call.fail("No visible element found containing exact text: " + text);
                    call.toolName = "browser_click";
                    call.arguments = Map.of("element", element.displayName(), "target", element.ref);
                    call.resolvedElement = element;
                    return call;
                }
                case "WAIT" -> {
                    int seconds = Math.max(1, Math.min(asInt(action.get("seconds"), 2), 10));
                    call.toolName = "browser_wait_for";
                    call.arguments = Map.of("time", seconds);
                    return call;
                }
                case "WAIT_FOR_TEXT" -> {
                    String text = resolveTextFromAction(action, testData);
                    if (isBlank(text)) text = stringValue(action.get("text"));
                    if (isBlank(text)) return call.fail("WAIT_FOR_TEXT requires text or textKey.");
                    call.toolName = "browser_wait_for";
                    call.arguments = Map.of("text", text);
                    return call;
                }
                case "PRESS_KEY" -> {
                    String key = stringValue(action.get("key"));
                    if (isBlank(key)) key = "Escape";
                    call.toolName = "browser_press_key";
                    call.arguments = Map.of("key", key);
                    return call;
                }
                case "ASSERT_TEXT_VISIBLE" -> {
                    String text = resolveTextFromAction(action, testData);
                    if (isBlank(text)) return call.fail("ASSERT_TEXT_VISIBLE requires text or textKey.");
                    call.toolName = "browser_wait_for";
                    call.arguments = Map.of("text", text);
                    return call;
                }
                default -> {
                    return call.fail("Unsupported safe action: " + actionName);
                }
            }
        } catch (Exception e) {
            return call.fail(e.getMessage());
        }
    }

    private String resolveTextFromAction(Map<String, Object> action, Map<String, Object> testData) {
        String text = stringValue(action.get("text"));
        if (!isBlank(text)) return text;
        String textKey = stringValue(action.get("textKey"));
        if (!isBlank(textKey)) {
            if (!testData.containsKey(textKey)) throw new RuntimeException("Missing test data key: " + textKey);
            return String.valueOf(testData.get(textKey));
        }
        return "";
    }

    private List<UiElement> parseElements(String snapshot) {
        List<UiElement> elements = new ArrayList<>();
        if (snapshot == null) return elements;
        String[] lines = snapshot.split("\\R");
        for (String rawLine : lines) {
            Matcher refMatcher = REF_PATTERN.matcher(rawLine);
            if (!refMatcher.find()) continue;
            String ref = refMatcher.group(1);
            String line = rawLine.trim();
            String lower = line.toLowerCase(Locale.ROOT);
            String role = inferRole(lower);
            String name = extractName(line);
            elements.add(new UiElement(ref, role, name, line));
        }
        return elements;
    }

    private String inferRole(String lowerLine) {
        if (lowerLine.contains("textbox") || lowerLine.contains("input") || lowerLine.contains("searchbox")) return "textbox";
        if (lowerLine.contains("button")) return "button";
        if (lowerLine.contains("link")) return "link";
        if (lowerLine.contains("combobox") || lowerLine.contains("select")) return "combobox";
        if (lowerLine.contains("checkbox")) return "checkbox";
        if (lowerLine.contains("radio")) return "radio";
        if (lowerLine.contains("tab")) return "tab";
        if (lowerLine.contains("row")) return "row";
        if (lowerLine.contains("cell") || lowerLine.contains("gridcell")) return "cell";
        if (lowerLine.contains("heading")) return "heading";
        return "text";
    }

    private String extractName(String line) {
        Matcher quoted = QUOTED_TEXT_PATTERN.matcher(line);
        if (quoted.find()) return quoted.group(1);
        String withoutRef = REF_PATTERN.matcher(line).replaceAll("");
        return withoutRef.replaceAll("^[\\-\\*\\s]+", "").trim();
    }

    private UiElement findBestTypeElement(List<UiElement> elements, String field, String valueKey) {
        String query = (safe(field) + " " + safe(valueKey)).trim();
        UiElement direct = findBestElement(elements, query, "textbox combobox", true);
        if (direct != null) return direct;
        if (valueKey.toLowerCase(Locale.ROOT).contains("password")) {
            direct = findBestElement(elements, "password", "textbox", true);
            if (direct != null) return direct;
        }
        List<UiElement> inputs = elements.stream()
                .filter(e -> e.role.equals("textbox") || e.role.equals("combobox"))
                .toList();
        if (inputs.size() == 1) return inputs.get(0);
        return null;
    }

    private UiElement findBestElement(List<UiElement> elements, String query, String allowedRoles, boolean typeOnly) {
        if (elements.isEmpty()) return null;
        String normalizedQuery = normalize(query);
        Set<String> roleSet = Set.of(allowedRoles.toLowerCase(Locale.ROOT).split("\\s+"));
        return elements.stream()
                .filter(e -> roleSet.contains(e.role) || (!typeOnly && roleSet.contains("text")))
                .map(e -> Map.entry(e, scoreElement(e, normalizedQuery)))
                .filter(entry -> entry.getValue() >= 25)
                .max(Comparator.comparingInt(Map.Entry::getValue))
                .map(Map.Entry::getKey)
                .orElse(null);
    }

    private UiElement findBestElementByVisibleText(List<UiElement> elements, String text) {
        String target = normalize(text);
        if (target.isBlank()) return null;
        return elements.stream()
                .map(e -> Map.entry(e, scoreTextMatch(e, target)))
                .filter(entry -> entry.getValue() >= 45)
                .max(Comparator.comparingInt(Map.Entry::getValue))
                .map(Map.Entry::getKey)
                .orElse(null);
    }

    private int scoreTextMatch(UiElement e, String target) {
        String hay = normalize(e.name + " " + e.line);
        int score = 0;
        if (hay.equals(target)) score += 100;
        if (hay.contains(target)) score += 80;
        if (target.contains(hay) && hay.length() > 3) score += 50;
        if (Set.of("cell", "link", "button", "row", "text").contains(e.role)) score += 20;
        if (e.role.equals("row")) score -= 10;
        return score;
    }

    private int scoreElement(UiElement e, String query) {
        String hay = normalize(e.name + " " + e.line + " " + e.role);
        int score = 0;
        if (hay.equals(query)) score += 100;
        if (!query.isBlank() && hay.contains(query)) score += 70;
        for (String token : query.split(" ")) {
            if (token.length() > 2 && hay.contains(token)) score += 18;
        }
        if (query.contains("username") && (hay.contains("user") || hay.contains("login") || hay.contains("email"))) score += 45;
        if (query.contains("password") && hay.contains("password")) score += 60;
        if (query.contains("search") && (hay.contains("search") || hay.contains("filter") || hay.contains("reference"))) score += 50;
        if ((query.contains("login") || query.contains("sign") || query.contains("submit")) &&
                (hay.contains("login") || hay.contains("sign in") || hay.contains("submit"))) score += 60;
        if (e.role.equals("button") || e.role.equals("link")) score += 15;
        if (e.role.equals("row")) score -= 10;
        return score;
    }

    private boolean containsVisibleText(List<UiElement> elements, String value) {
        String v = normalize(value);
        return elements.stream().anyMatch(e -> normalize(e.name + " " + e.line).contains(v));
    }

    private String summarizeElements(List<UiElement> elements) throws Exception {
        List<Map<String, Object>> summary = new ArrayList<>();
        int limit = Math.min(120, elements.size());
        for (int i = 0; i < limit; i++) {
            UiElement e = elements.get(i);
            summary.add(Map.of("role", e.role, "name", e.name, "ref", e.ref));
        }
        return objectMapper.writeValueAsString(summary);
    }

    private Set<String> fieldsAlreadyTyped(List<Map<String, Object>> trace) {
        Set<String> fields = new java.util.HashSet<>();
        for (Map<String, Object> item : trace) {
            if (!"browser_type".equals(stringValue(item.get("mcpTool")))) continue;
            Map<String, Object> args = asMap(item.get("arguments"));
            String element = stringValue(args.get("element")).toLowerCase(Locale.ROOT);
            if (element.contains("user")) fields.add("username");
            if (element.contains("password")) fields.add("password");
        }
        return fields;
    }

    private Map<String, Object> createExecutionPlan(AgentRequest request, Map<String, Object> testData) throws Exception {
        String raw = llm.generate(planPrompt(request, testData));
        Map<String, Object> plan = parseJsonObject(raw);
        if (plan.isEmpty()) {
            plan.put("planStatus", "FALLBACK_HEURISTIC_PLAN");
            plan.put("missingData", List.of());
            plan.put("steps", List.of(Map.of("step", 1, "goal", request.scenario == null ? "Execute scenario" : request.scenario)));
        }
        return plan;
    }

    private String planPrompt(AgentRequest request, Map<String, Object> testData) throws Exception {
        return """
                You are a senior test automation architect.
                Create a safe execution plan before browser automation starts.
                Return ONLY valid JSON. No markdown.

                Scenario:
                %s

                Expected Result:
                %s

                Test Data JSON:
                %s

                Pre-action Instructions:
                %s

                Rules:
                1. Do not invent data.
                2. If required data is missing, add keys to missingData.
                3. Keep steps high-level, short, and ordered.
                4. Use safe action words only: TYPE, CLICK, CLICK_TEXT, WAIT, WAIT_FOR_TEXT, PRESS_KEY, ASSERT_TEXT_VISIBLE.
                5. For table/grid row selection, plan CLICK_TEXT on exact business value, not row container.

                JSON shape:
                {"planStatus":"CREATED","missingData":[],"steps":[{"step":1,"goal":"...","safeAction":"TYPE","dataKeys":["username"]}]}
                """.formatted(safe(request.scenario), safe(request.expectedResult), objectMapper.writeValueAsString(testData), safe(request.preActionInstructions));
    }

    private void validateGeneratedCode(AgentRequest request, AgentResponse response) throws Exception {
        if (!"PLAYWRIGHT_TYPESCRIPT".equals(request.targetFramework) && !"PLAYWRIGHT_JAVASCRIPT".equals(request.targetFramework)) {
            response.validationStatus = "SKIPPED_UNSUPPORTED_RUNNER";
            return;
        }
        File projectDirectory = new File(request.projectPath);
        List<String> command = new ArrayList<>();
        command.add("cmd.exe"); command.add("/c"); command.add("npx.cmd"); command.add("playwright"); command.add("test"); command.add(request.testFileName);
        if (request.headed) command.add("--headed");
        String output = commandService.run(command, projectDirectory, 240);
        response.validationOutput = output;
        if (output.contains("EXIT_CODE=0")) { response.validationStatus = "PASSED"; return; }
        if (!request.autoRepair) { response.validationStatus = "FAILED"; return; }
        for (int attempt = 1; attempt <= Math.max(1, request.maxRepairAttempts); attempt++) {
            String repairedCode = cleanCode(llm.generate(repairPrompt(request, response.generatedCode, output, response.actionTrace)));
            Files.writeString(Paths.get(response.savedFilePath), repairedCode);
            response.generatedCode = repairedCode;
            Map<String, Object> repair = new LinkedHashMap<>();
            repair.put("attempt", attempt); repair.put("previousOutput", output);
            response.repairHistory.add(repair);
            output = commandService.run(command, projectDirectory, 240);
            response.validationOutput = output;
            if (output.contains("EXIT_CODE=0")) { response.validationStatus = "PASSED_AFTER_REPAIR_" + attempt; return; }
        }
        response.validationStatus = "FAILED_AFTER_REPAIR";
    }

    private String codePrompt(AgentRequest request, List<Map<String, Object>> trace, String snapshot) throws Exception {
        return """
                Generate production-ready automation code for target framework: %s
                Return ONLY code. No markdown.
                Generate code only from this successful deterministic execution trace. Do not invent selectors.
                Prefer stable locators: role, label, placeholder, text, test id. Avoid brittle XPath unless no option.
                Include waits for enterprise loading/overlays where trace used WAIT. Add assertions from expected result.

                Application URL: %s
                Scenario: %s
                Test Data JSON: %s
                Expected Result: %s
                Trace: %s
                Final snapshot summary: %s
                """.formatted(safe(request.targetFramework), safe(request.applicationUrl), safe(request.scenario), safe(request.testDataJson), safe(request.expectedResult), objectMapper.writeValueAsString(trace), safe(snapshot));
    }

    private String repairPrompt(AgentRequest request, String code, String error, List<Map<String, Object>> trace) throws Exception {
        return """
                Repair this automation code for framework: %s
                Return ONLY the full corrected code. No markdown.
                Validation failure output: %s
                Current code: %s
                Deterministic execution trace: %s
                """.formatted(safe(request.targetFramework), safe(error), safe(code), objectMapper.writeValueAsString(trace));
    }

    private Map<String, Object> callToolAndFailFast(String tool, Map<String, Object> args) {
        Map<String, Object> result = mcpClient.tool(tool, args);
        if (mcpClient.isError(result)) throw new RuntimeException("MCP tool failed: " + tool + " -> " + result);
        return result;
    }

    private Map<String, Object> executeToolWithRecovery(String toolName, Map<String, Object> toolArguments, int actionDelayMs) {
        Map<String, Object> result = mcpClient.tool(toolName, normalizeMcpArgs(toolName, toolArguments));
        if (!mcpClient.isError(result)) return result;
        if (!isRecoverableClickProblem(toolName, result)) return result;

        List<Map<String, Object>> recoveryAttempts = new ArrayList<>();
        recoveryAttempts.add(Map.of("attempt", "initial", "result", result));
        recoveryAttempts.add(Map.of("attempt", "press_escape", "result", mcpClient.tool("browser_press_key", Map.of("key", "Escape"))));
        sleep(Math.max(800, actionDelayMs));
        recoveryAttempts.add(Map.of("attempt", "wait", "result", mcpClient.tool("browser_wait_for", Map.of("time", 2))));

        result = mcpClient.tool(toolName, normalizeMcpArgs(toolName, toolArguments));
        if (!mcpClient.isError(result)) return recovered(result, recoveryAttempts, "RECOVERED_AFTER_ESCAPE_AND_WAIT");
        recoveryAttempts.add(Map.of("attempt", "retry_after_escape", "result", result));

        // Controlled internal recovery only. LLM cannot request this.
        Map<String, Object> overlayPatch = mcpClient.tool("browser_evaluate", Map.of(
                "function", "() => { const selectors = ['.v-overlay-container','.v-overlay','[id$=\\'-overlays\\']','[id*=\\'overlays\\']','.modal-backdrop','.cdk-overlay-container','.cdk-overlay-backdrop','.toast','.slds-backdrop']; let changed = 0; for (const sel of selectors) { document.querySelectorAll(sel).forEach(el => { const rect = el.getBoundingClientRect(); const style = window.getComputedStyle(el); if (style.pointerEvents !== 'none' && rect.width > 0 && rect.height > 0) { el.setAttribute('data-astra-pointer-events-original', style.pointerEvents); el.style.pointerEvents = 'none'; changed++; } }); } return {changed}; }"
        ));
        recoveryAttempts.add(Map.of("attempt", "controlled_overlay_recovery", "result", overlayPatch));
        sleep(300);

        result = mcpClient.tool(toolName, normalizeMcpArgs(toolName, toolArguments));
        if (!mcpClient.isError(result)) return recovered(result, recoveryAttempts, "RECOVERED_AFTER_OVERLAY_POINTER_EVENTS_PATCH");

        Map<String, Object> failed = new LinkedHashMap<>(result);
        failed.put("astraRecovery", recoveryAttempts);
        failed.put("astraRecoveryStatus", "FAILED_AFTER_RECOVERY_ATTEMPTS");
        return failed;
    }

    private Map<String, Object> normalizeMcpArgs(String toolName, Map<String, Object> args) {
        Map<String, Object> out = new LinkedHashMap<>(args == null ? Map.of() : args);
        if (!out.containsKey("target") && out.containsKey("ref")) out.put("target", out.remove("ref"));
        if ("browser_wait_for".equals(toolName)) {
            String text = stringValue(out.get("text"));
            String textGone = stringValue(out.get("textGone"));
            if (!text.isBlank()) { out.clear(); out.put("text", text); return out; }
            if (!textGone.isBlank()) { out.clear(); out.put("textGone", textGone); return out; }
            int time = Math.max(1, Math.min(asInt(out.get("time"), 2), 10));
            out.clear(); out.put("time", time);
        }
        return out;
    }

    private Map<String, Object> recovered(Map<String, Object> result, List<Map<String, Object>> attempts, String status) {
        Map<String, Object> recovered = new LinkedHashMap<>(result);
        recovered.put("astraRecovery", attempts);
        recovered.put("astraRecoveryStatus", status);
        return recovered;
    }

    private boolean isRecoverableClickProblem(String toolName, Map<String, Object> result) {
        if (!"browser_click".equals(toolName) && !"browser_double_click".equals(toolName)) return false;
        String text = stripAnsi(String.valueOf(result)).toLowerCase(Locale.ROOT);
        return text.contains("timeout") || text.contains("intercepts pointer events") || text.contains("element is not visible")
                || text.contains("not stable") || text.contains("not enabled") || text.contains("receives pointer events");
    }

    private String summarizeMcpError(Map<String, Object> result) {
        String text = stripAnsi(String.valueOf(result));
        return text.length() > 1200 ? text.substring(0, 1200) + "..." : text;
    }

    private String stripAnsi(String value) {
        if (value == null) return "";
        return value.replaceAll("\\u001B\\[[;\\d]*m", "").replace("\\u001b", "").replace("\\033", "");
    }

    private String snapshotWithRetry() {
        Map<String, Object> result = mcpClient.tool("browser_snapshot", Map.of());
        if (mcpClient.isError(result)) { sleep(500); result = mcpClient.tool("browser_snapshot", Map.of()); }
        return String.valueOf(result);
    }

    private String saveGeneratedCode(AgentRequest request, String code) throws Exception {
        if (isBlank(request.projectPath)) throw new RuntimeException("Project path is required when Save to project is enabled.");
        String fileName = isBlank(request.testFileName) ? defaultFileName(request.targetFramework) : request.testFileName;
        Path testDirectory = Paths.get(request.projectPath, "tests");
        Files.createDirectories(testDirectory);
        Path outputFile = testDirectory.resolve(fileName);
        Files.writeString(outputFile, code);
        return outputFile.toString();
    }

    private String defaultFileName(String framework) {
        if ("PLAYWRIGHT_JAVASCRIPT".equals(framework) || "CYPRESS_JAVASCRIPT".equals(framework)) return "astra-generated.spec.js";
        if ("PLAYWRIGHT_PYTHON_PYTEST".equals(framework)) return "test_astra_generated.py";
        if ("PLAYWRIGHT_JAVA_JUNIT".equals(framework) || "PLAYWRIGHT_JAVA_TESTNG".equals(framework) || "SELENIUM_JAVA_TESTNG".equals(framework) || "SELENIUM_JAVA_CUCUMBER".equals(framework)) return "AstraGeneratedTest.java";
        if ("PLAYWRIGHT_DOTNET_NUNIT".equals(framework)) return "AstraGeneratedTest.cs";
        return "astra-generated.spec.ts";
    }

    private List<String> detectObviousMissingData(AgentRequest request, Map<String, Object> data) {
        List<String> missing = new ArrayList<>();
        String scenario = (safe(request.scenario) + " " + safe(request.expectedResult)).toLowerCase(Locale.ROOT);
        if (scenario.contains("login") || scenario.contains("sign in") || scenario.contains("signin")) {
            if (!hasAnyKey(data, "username", "user", "userName", "userid", "userId", "email")) missing.add("username");
            if (!hasAnyKey(data, "password", "passcode")) missing.add("password");
        }
        if ((scenario.contains("otp") || scenario.contains("one time password")) && !hasAnyKey(data, "otp", "oneTimePassword")) missing.add("otp");
        if (scenario.contains("transaction") && scenario.contains("id") && !hasAnyKey(data, "transactionId", "txnId", "paymentId")) missing.add("transactionId");
        return missing;
    }

    private boolean expectedLooksVisible(String expectedResult, String snapshot, List<Map<String, Object>> trace) {
        if (isBlank(expectedResult) || isBlank(snapshot)) return false;
        String lowerSnapshot = snapshot.toLowerCase(Locale.ROOT);
        String[] tokens = expectedResult.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9 ]", " ").split("\\s+");
        int useful = 0; int matched = 0;
        for (String token : tokens) {
            if (token.length() < 4 || Set.of("should", "visible", "displayed", "verify", "page", "shown").contains(token)) continue;
            useful++; if (lowerSnapshot.contains(token)) matched++;
        }
        return useful > 0 && matched >= Math.min(useful, 2) && trace.size() > 1;
    }

    private List<Map<String, Object>> compactTrace(List<Map<String, Object>> trace) {
        int from = Math.max(0, trace.size() - 8);
        List<Map<String, Object>> compact = new ArrayList<>();
        for (Map<String, Object> item : trace.subList(from, trace.size())) {
            Map<String, Object> small = new LinkedHashMap<>();
            small.put("step", item.get("step"));
            small.put("action", item.get("action"));
            small.put("mcpTool", item.get("mcpTool"));
            small.put("arguments", item.get("arguments"));
            small.put("reason", item.get("reason"));
            small.put("status", item.get("status"));
            compact.add(small);
        }
        return compact;
    }

    private String compactSnapshot(String snapshot) {
        if (snapshot == null) return "";
        String[] lines = snapshot.split("\\R");
        StringBuilder out = new StringBuilder();
        int count = 0;
        for (String line : lines) {
            String l = line.toLowerCase(Locale.ROOT);
            if (l.contains("button") || l.contains("textbox") || l.contains("input") || l.contains("combobox") || l.contains("checkbox")
                    || l.contains("radio") || l.contains("link") || l.contains("heading") || l.contains("ref=") || l.contains("error")
                    || l.contains("alert") || l.contains("dialog") || l.contains("table") || l.contains("row") || l.contains("cell")
                    || l.contains("tab") || l.contains("search")) {
                out.append(line).append('\n'); count++;
            }
            if (count > 220) { out.append("...snapshot trimmed..."); break; }
        }
        if (out.length() == 0) return snapshot.length() > 9000 ? snapshot.substring(0, 9000) + "...trimmed..." : snapshot;
        return out.toString();
    }

    private void addTrace(AgentResponse response, int step, String action, String mcpTool, Map<String, Object> args, String reason, int confidence, Map<String, Object> result, String status) {
        Map<String, Object> trace = new LinkedHashMap<>();
        trace.put("step", step);
        trace.put("action", action);
        trace.put("mcpTool", mcpTool);
        trace.put("arguments", args);
        trace.put("reason", reason);
        trace.put("confidence", confidence);
        trace.put("status", status);
        trace.put("result", result);
        response.actionTrace.add(trace);
    }

    private AgentResponse missingDataResponse(AgentResponse response, String message, List<String> missing) {
        response.status = "MISSING_TEST_DATA";
        response.message = message;
        response.missingData.addAll(missing);
        return response;
    }

    private Map<String, Object> parseJsonObject(String text) {
        try {
            if (isBlank(text)) return new LinkedHashMap<>();
            String cleaned = stripMarkdownCodeFence(text);
            int start = cleaned.indexOf('{'); int end = cleaned.lastIndexOf('}');
            if (start >= 0 && end > start) cleaned = cleaned.substring(start, end + 1);
            return objectMapper.readValue(cleaned, new TypeReference<Map<String, Object>>() {});
        } catch (Exception e) { return new LinkedHashMap<>(); }
    }

    private Map<String, Object> asMap(Object value) {
        if (value instanceof Map<?, ?> map) {
            Map<String, Object> result = new LinkedHashMap<>();
            for (Map.Entry<?, ?> entry : map.entrySet()) result.put(String.valueOf(entry.getKey()), entry.getValue());
            return result;
        }
        return new LinkedHashMap<>();
    }

    private List<Map<String, Object>> asMapList(Object value) {
        List<Map<String, Object>> result = new ArrayList<>();
        if (value instanceof List<?> list) for (Object item : list) result.add(asMap(item));
        return result;
    }

    private List<String> asStringList(Object value) {
        List<String> result = new ArrayList<>();
        if (value instanceof List<?> list) for (Object item : list) result.add(String.valueOf(item));
        else if (value instanceof String text && !text.isBlank()) result.add(text);
        return result;
    }

    private boolean asBoolean(Object value) {
        if (value instanceof Boolean b) return b;
        return Boolean.parseBoolean(String.valueOf(value));
    }

    private int asInt(Object value, int defaultValue) {
        if (value instanceof Number number) return number.intValue();
        try { return Integer.parseInt(String.valueOf(value)); } catch (Exception e) { return defaultValue; }
    }

    private String cleanCode(String code) { return stripMarkdownCodeFence(code).trim(); }

    private String stripMarkdownCodeFence(String text) {
        if (text == null) return "";
        return text.replace("```typescript", "").replace("```ts", "").replace("```javascript", "").replace("```js", "")
                .replace("```java", "").replace("```python", "").replace("```csharp", "").replace("```", "").trim();
    }

    private boolean hasAnyKey(Map<String, Object> data, String... keys) {
        for (String key : keys) if (data.containsKey(key)) return true;
        return false;
    }

    private String firstExistingKey(Map<String, Object> data, String... keys) {
        for (String key : keys) if (data.containsKey(key)) return key;
        return keys.length == 0 ? "" : keys[0];
    }

    private String normalize(String value) {
        return safe(value).toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9/ ]", " ").replaceAll("\\s+", " ").trim();
    }

    private void applyDefaults(AgentRequest request) {
        if (request.maxAgentSteps <= 0) request.maxAgentSteps = 12;
        if (request.liveActionDelayMs < 0) request.liveActionDelayMs = 1200;
        if (request.minActionConfidence <= 0) request.minActionConfidence = 60;
        if (isBlank(request.targetFramework)) request.targetFramework = "PLAYWRIGHT_TYPESCRIPT";
        if (isBlank(request.testFileName)) request.testFileName = defaultFileName(request.targetFramework);
        if (isBlank(request.userDataDir)) request.userDataDir = "C:/Temp/astra-mcp-profile";
    }

    private void sleep(int milliseconds) {
        try { Thread.sleep(Math.max(milliseconds, 0)); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
    }

    private String safe(String value) { return value == null ? "" : value; }
    private String stringValue(Object value) { return value == null ? "" : String.valueOf(value).trim(); }
    private boolean isBlank(String value) { return value == null || value.trim().isEmpty(); }

    private static class UiElement {
        final String ref;
        final String role;
        final String name;
        final String line;
        UiElement(String ref, String role, String name, String line) { this.ref = ref; this.role = role; this.name = name; this.line = line; }
        String displayName() { return (isStaticBlank(name) ? role : role + " " + name) + " [" + ref + "]"; }
        private static boolean isStaticBlank(String s) { return s == null || s.trim().isEmpty(); }
    }

    private static class SafeMcpCall {
        String intent;
        String toolName;
        Map<String, Object> arguments = new LinkedHashMap<>();
        UiElement resolvedElement;
        String error;
        boolean isExecutable() { return toolName != null && error == null; }
        SafeMcpCall fail(String message) { this.error = message; return this; }
    }
}
