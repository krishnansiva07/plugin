import com.llmart.llm.service.OpenCodeExecutionService;
import com.llmart.llm.service.ProjectService;
import com.llmart.llm.dto.ChatMode;
import com.llmart.llm.dto.ChatRequest;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sun.net.httpserver.HttpServer;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.*;

public class EngineSelectionSmoke {
    static void check(boolean condition, String message) { if (!condition) throw new AssertionError(message); }
    static void reply(com.sun.net.httpserver.HttpExchange e, int code, String body) throws Exception {
        byte[] data = body.getBytes(StandardCharsets.UTF_8);
        e.getResponseHeaders().set("Content-Type", "application/json");
        e.sendResponseHeaders(code, data.length);
        try(var stream=e.getResponseBody()) { stream.write(data); }
    }
    public static void main(String[] args) throws Exception {
        System.setProperty("eliya.opencode.stallSeconds", "3");
        Path base = Files.createTempDirectory("eliya92-monitor-");
        System.setProperty("eliya.opencode.sessionStore", base.toString());
        HttpServer mock = HttpServer.create(new InetSocketAddress("127.0.0.1", 0), 0);
        mock.createContext("/api/", e -> {
            try {
                String path = e.getRequestURI().getPath();
                if (path.equals("/api/info")) reply(e, 200, "{\"data\":{\"version\":\"2.2.2\"}}");
                else if (path.equals("/api/session")) reply(e, 200, "{\"data\":{\"id\":\"ses_no_events\"}}");
                else if (path.endsWith("/prompt")) reply(e, 200, "{\"data\":{\"id\":\"user_1\"}}");
                else if (path.equals("/api/session/active")) reply(e, 200, "{\"data\":{\"ses_no_events\":{\"state\":\"running\"}}}");
                else if (path.endsWith("/log")) {
                    e.getResponseHeaders().set("Content-Type", "text/event-stream");
                    e.sendResponseHeaders(200, 0);
                    e.getResponseBody().close();
                } else if (path.endsWith("/interrupt")) reply(e,200,"{\"interrupted\":true}");
                else reply(e, 404,"{}");
            } catch (Exception ex) { throw new RuntimeException(ex); }
        });
        ExecutorService workers = Executors.newCachedThreadPool(r -> {Thread t = new Thread(r); t.setDaemon(true);return t;});
        mock.setExecutor(workers); mock.start();
        OpenCodeExecutionService service = new OpenCodeExecutionService(new ObjectMapper(), new ProjectService(),
            "opencode", "http://127.0.0.1:"+mock.getAddress().getPort(),"local-secret-for-tests", "opencode",false);
        try {
            check(service.availableForAuto(), "Auto must detect the available engine");
            var req = new ChatRequest("proj1", "Create sample.txt", List.of(), ChatMode.AGENT, new ChatRequest.Settings("test-model"));
            String id = String.valueOf(service.launch(req,null).get("id"));
            boolean stalled = false;
            for (int i=0;i<32;i++) {
                if ("stalled".equals(service.get(id).get("status"))) {stalled=true;break;}
                Thread.sleep(250);
            }
            check(stalled, "Missed OpenCode activity must become an explicit unverified stall, not run indefinitely");
            var response = service.get(id);
            check(String.valueOf(response.get("error")).contains("may still be running"), "Do not claim failure/success without proof: " + response);
            check(!"completed".equals(response.get("status")),"Must not report success");
            check("cancelled".equals(service.cancel(id).get("status")),"A stalled session must remain cancellable");
            System.out.println("PASS: OpenCode eventless session diagnosed, no false completion, cancellation preserved");
        } finally { service.shutdown();mock.stop(0);workers.shutdownNow(); }
    }
}
