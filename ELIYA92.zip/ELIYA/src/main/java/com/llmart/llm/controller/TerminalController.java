package com.llmart.llm.controller;

import com.llmart.llm.dto.ChatRequest;
import com.llmart.llm.service.TerminalSessionService;
import jakarta.validation.Valid;
import org.springframework.http.MediaType;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;
import org.springframework.web.bind.annotation.*;
import java.util.*;

/** Terminal Agent sessions are detached from the browser and do not ask for plan approval. */
@RestController
@RequestMapping("/api/terminal")
public class TerminalController {
    private final TerminalSessionService sessions;
    @org.springframework.beans.factory.annotation.Autowired(required = false)
    private com.llmart.llm.service.OpenCodeExecutionService openCode;
    private boolean openCodeOwns(String id) { return openCode != null && openCode.owns(id); }
    @GetMapping("/engine")
    public Map<String,Object> engine() { return openCode == null ? Map.of("engine", "legacy", "connected", false) : openCode.engineInfo(); }
    private final com.llmart.llm.service.TerminalGitService git;
    private final com.llmart.llm.service.TerminalWorkspaceDiscoveryService discovery;
    @org.springframework.beans.factory.annotation.Autowired(required = false)
    private com.llmart.llm.service.TerminalSkillStudioService skillStudio;
    public TerminalController(TerminalSessionService sessions,
                              com.llmart.llm.service.TerminalWorkspaceDiscoveryService discovery,
                              com.llmart.llm.service.TerminalGitService git) {
        this.sessions = sessions; this.git = git;
        this.discovery = discovery;
    }
    @PostMapping("/definitions")
    public Map<String,Object> createDefinition(@RequestBody com.llmart.llm.service.TerminalSkillStudioService.DefinitionRequest request)
            throws java.io.IOException {
        if (skillStudio == null) throw new IllegalStateException("Skill Studio unavailable");
        return sessions.withGitWorkspaceLock(request.projectId(), () -> skillStudio.create(request));
    }
    @GetMapping("/workspaces")
    public List<com.llmart.llm.dto.ProjectDto> workspaces() {
        return discovery.mappedWorkspaces();
    }
    @GetMapping("/capabilities")
    public Map<String,Object> capabilities(@RequestParam(required=false) String projectId) throws java.io.IOException {
        return discovery.discover(projectId);
    }

    @GetMapping("/repositories")
    public List<Map<String,Object>> repositories(@RequestParam String projectId) throws java.io.IOException {
        return git.repositories(projectId);
    }
    @GetMapping("/git/review")
    public Map<String,Object> gitReview(@RequestParam String projectId, @RequestParam String repository)
            throws java.io.IOException {
        return git.review(projectId, repository);
    }
    public record GitBranchRequest(String projectId, String repository, String branch) {}
    public record GitWorktreeRequest(String projectId, String repository, String branch, String conversationId) {}
    @PostMapping("/git/branch")
    public Map<String,Object> createBranch(@RequestBody GitBranchRequest request) throws java.io.IOException {
        return sessions.withGitWorkspaceLock(request.projectId(),
                () -> git.createBranch(request.projectId(), request.repository(), request.branch()));
    }
    @PostMapping("/git/worktree")
    public Map<String,Object> createWorktree(@RequestBody GitWorktreeRequest request) throws java.io.IOException {
        return sessions.withGitWorkspaceLock(request.projectId(),
                () -> git.createWorktree(request.projectId(), request.repository(), request.branch(), request.conversationId()));
    }
    public record ClarificationRequest(String questionId, String choice, String detail) {}
    @PostMapping("/sessions/{id}/answer")
    public Map<String,Object> answer(@PathVariable String id, @RequestBody ClarificationRequest response) {
        if (openCodeOwns(id)) return openCode.answer(id, response.questionId(), response.choice(), response.detail());
        return sessions.answer(id, response.questionId(), response.choice(), response.detail());
    }

    public record TransferRequest(String runId, String approvalId, ChatRequest request) {}
    @PostMapping("/transfer")
    public Map<String,Object> transfer(@RequestHeader(value="Authorization", required=false) String authorization,
                                       @RequestBody TransferRequest transfer) {
        String key = authorization != null && authorization.startsWith("Bearer ") ? authorization.substring(7) : null;
        return sessions.transfer(key, transfer.runId(), transfer.approvalId(), transfer.request());
    }

    @PostMapping("/sessions")
    public Map<String,Object> launch(@RequestHeader(value="Authorization", required=false) String authorization,
                                     @RequestHeader(value="X-ELIYA-Execution-Engine", required=false) String engineChoice,
                                     @Valid @RequestBody ChatRequest request) {
        String key = authorization != null && authorization.startsWith("Bearer ") ? authorization.substring(7) : null;
        if (!"legacy".equalsIgnoreCase(engineChoice) && openCode != null && openCode.accepts(request)
                && ("opencode".equalsIgnoreCase(engineChoice) || openCode.availableForAuto())) return openCode.launch(request, null);
        return sessions.launch(key, request);
    }
    @PostMapping("/sessions/{id}/message")
    public Map<String,Object> message(@PathVariable String id,
            @RequestHeader(value="Authorization", required=false) String authorization,
            @Valid @RequestBody ChatRequest request) {
        String key = authorization != null && authorization.startsWith("Bearer ") ? authorization.substring(7) : null;
        if (openCodeOwns(id)) {
            if (openCode.accepts(request)) return openCode.message(id, request);
            return sessions.launch(key, request); // analyse, attachments or MCP use ELIYA in a new session
        }
        if (openCode != null && openCode.accepts(request)) {
            Map<String,Object> prior = sessions.get(id);
            String context = String.valueOf(prior.getOrDefault("answer", ""));
            return openCode.launch(request, context);
        }
        return sessions.message(key, id, request);
    }
    public record QueueEditRequest(String prompt) {}
    public record QueueMoveRequest(String direction) {}
    @PatchMapping("/sessions/{id}/queue/{itemId}")
    public Map<String,Object> editQueue(@PathVariable String id, @PathVariable String itemId,
            @RequestBody QueueEditRequest request) {
        return sessions.editQueued(id, itemId, request.prompt());
    }
    @PostMapping("/sessions/{id}/queue/{itemId}/move")
    public Map<String,Object> moveQueue(@PathVariable String id, @PathVariable String itemId,
            @RequestBody QueueMoveRequest request) {
        return sessions.moveQueued(id, itemId, request.direction());
    }
    @DeleteMapping("/sessions/{id}/queue/{itemId}")
    public Map<String,Object> removeQueue(@PathVariable String id, @PathVariable String itemId) {
        return sessions.removeQueued(id, itemId);
    }
    @PostMapping("/sessions/{id}/queue/resume")
    public Map<String,Object> resumeQueue(@PathVariable String id,
            @RequestHeader(value="Authorization", required=false) String authorization,
            @Valid @RequestBody ChatRequest configuration) {
        String key = authorization != null && authorization.startsWith("Bearer ") ? authorization.substring(7) : null;
        return sessions.resumeQueued(key, id, configuration);
    }
    @PostMapping("/sessions/{id}/interrupt-next")
    public Map<String,Object> interruptNext(@PathVariable String id) {
        return sessions.interruptAndNext(id);
    }
    @GetMapping("/sessions")
    public List<Map<String,Object>> list() {
        if (openCode == null || !openCode.enabled()) return sessions.list();
        List<Map<String,Object>> all = new ArrayList<>(sessions.list());
        all.addAll(openCode.list());
        all.sort(Comparator.comparing((Map<String,Object> s) -> String.valueOf(s.getOrDefault("updatedAt", ""))).reversed());
        return all;
    }
    @GetMapping(path="/sessions/{id}/events", produces=MediaType.TEXT_EVENT_STREAM_VALUE)
    public SseEmitter events(@PathVariable String id) { return openCodeOwns(id) ? openCode.stream(id) : sessions.stream(id); }
    @GetMapping("/sessions/{id}")
    public Map<String,Object> status(@PathVariable String id) { return openCodeOwns(id) ? openCode.get(id) : sessions.get(id); }
    @GetMapping("/sessions/{id}/activity")
    public Map<String,Object> activity(@PathVariable String id,
            @RequestParam(required=false) Long before, @RequestParam(required=false) Integer limit) {
        return openCodeOwns(id) ? openCode.activity(id, before, limit) : sessions.activity(id, before, limit);
    }
    @PostMapping("/sessions/{id}/cancel")
    public Map<String,Object> cancel(@PathVariable String id) { return openCodeOwns(id) ? openCode.cancel(id) : sessions.cancel(id); }
}
