package com.formatflow.ai.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.formatflow.ai.model.FormatModels.PlanItem;
import com.formatflow.ai.model.FormatModels.SourceBlock;
import org.bsc.langgraph4j.StateGraph;
import org.bsc.langgraph4j.state.AgentState;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

import static org.bsc.langgraph4j.StateGraph.END;
import static org.bsc.langgraph4j.StateGraph.START;
import static org.bsc.langgraph4j.action.AsyncEdgeAction.edge_async;
import static org.bsc.langgraph4j.action.AsyncNodeAction.node_async;

@Service
public class LlmOrchestrator {

    private final LlmClient llmClient;
    private final PromptFactory promptFactory;
    private final ContentParser contentParser;
    private final ObjectMapper objectMapper;
    private final IconCatalog iconCatalog;
    private final int chunkCharacters;
    private final int chunkBlocks;
    private final int maxGraphRepairs;
    private final int graphReviewThreshold;
    private final int graphPlanSampleCharacters;
    private final int graphReviewSampleCharacters;

    public LlmOrchestrator(LlmClient llmClient,
                           PromptFactory promptFactory,
                           ContentParser contentParser,
                           ObjectMapper objectMapper,
                           IconCatalog iconCatalog,
                           @Value("${formatflow.llm.chunk-characters:9000}") int chunkCharacters,
                           @Value("${formatflow.llm.chunk-blocks:40}") int chunkBlocks,
                           @Value("${formatflow.langgraph.max-repairs:1}") int maxGraphRepairs,
                           @Value("${formatflow.langgraph.review-threshold:80}") int graphReviewThreshold,
                           @Value("${formatflow.langgraph.plan-sample-characters:18000}") int graphPlanSampleCharacters,
                           @Value("${formatflow.langgraph.review-sample-characters:28000}") int graphReviewSampleCharacters) {
        this.llmClient = llmClient;
        this.promptFactory = promptFactory;
        this.contentParser = contentParser;
        this.objectMapper = objectMapper;
        this.iconCatalog = iconCatalog;
        this.chunkCharacters = chunkCharacters;
        this.chunkBlocks = chunkBlocks;
        this.maxGraphRepairs = Math.max(0, maxGraphRepairs);
        this.graphReviewThreshold = Math.max(0, Math.min(100, graphReviewThreshold));
        this.graphPlanSampleCharacters = Math.max(6000, graphPlanSampleCharacters);
        this.graphReviewSampleCharacters = Math.max(10000, graphReviewSampleCharacters);
    }

    public PlanOutcome buildFormattingPlan(String apiKey,
                                             List<SourceBlock> blocks,
                                             String audience,
                                             String purpose,
                                             String outputFormat,
                                             String iconLevel) {
        List<List<SourceBlock>> chunks = contentParser.chunks(blocks, chunkCharacters, chunkBlocks);
        Map<String, PlanItem> planned = new LinkedHashMap<>();
        int calls = 0;

        for (List<SourceBlock> chunk : chunks) {
            String prompt = promptFactory.formattingPlan(chunk, audience, purpose, outputFormat, iconLevel);
            String response = llmClient.chat(apiKey, prompt, 2400, 0.0);
            calls++;
            List<PlanItem> parsed;
            try {
                parsed = parsePlan(response, chunk);
            } catch (RuntimeException invalidStructuredOutput) {
                response = llmClient.chat(
                        apiKey,
                        prompt + "\n\nREPAIR REQUEST: Return ONLY valid strict JSON matching the requested schema. Preserve every source block id exactly once. Do not return or rewrite source text.",
                        2400,
                        0.0
                );
                calls++;
                parsed = parsePlan(response, chunk);
            }
            Map<String, SourceBlock> sourceById = chunk.stream().collect(Collectors.toMap(SourceBlock::id, b -> b));
            for (PlanItem item : parsed) {
                String iconKey = item.iconKey();
                if ("NONE".equalsIgnoreCase(iconLevel)) {
                    iconKey = "NONE";
                } else if ("NONE".equalsIgnoreCase(iconKey)
                        && ("TITLE".equalsIgnoreCase(item.type()) || "HEADING".equalsIgnoreCase(item.type()))) {
                    SourceBlock source = sourceById.get(item.id());
                    iconKey = iconCatalog.inferKey(source == null ? "" : source.text());
                }
                PlanItem effective = new PlanItem(item.id(), item.type(), iconKey, item.emphasis(), item.bulletStyle());
                planned.put(effective.id(), effective);
            }
        }

        List<PlanItem> ordered = new ArrayList<>();
        for (SourceBlock block : blocks) {
            if (block.blank()) continue;
            PlanItem item = planned.get(block.id());
            if (item == null) {
                throw new IllegalStateException("LLM formatting plan omitted source block " + block.id() + ". No content was changed.");
            }
            ordered.add(item);
        }
        return new PlanOutcome(ordered, calls, chunks.size());
    }

    public EnhancementOutcome enhance(String apiKey,
                                      List<SourceBlock> blocks,
                                      String audience,
                                      String purpose,
                                      String outputFormat) {
        List<List<SourceBlock>> chunks = contentParser.chunks(blocks, chunkCharacters, chunkBlocks);
        Map<String, String> enhanced = new LinkedHashMap<>();
        int calls = 0;

        for (List<SourceBlock> chunk : chunks) {
            String response = llmClient.chat(
                    apiKey,
                    promptFactory.enhanceBlocks(chunk, audience, purpose, outputFormat),
                    4096,
                    0.1
            );
            calls++;
            JsonNode root = readJson(response);
            JsonNode items = root.path("items");
            if (!items.isArray()) throw new IllegalStateException("LLM enhancement response did not contain an items array.");

            Set<String> allowed = chunk.stream().map(SourceBlock::id).collect(Collectors.toSet());
            for (JsonNode item : items) {
                String id = item.path("id").asText("");
                String text = item.path("text").asText(null);
                if (!allowed.contains(id) || text == null) continue;
                enhanced.put(id, text);
            }
        }

        List<SourceBlock> result = new ArrayList<>();
        for (SourceBlock source : blocks) {
            if (source.blank()) {
                result.add(source);
            } else {
                String text = enhanced.get(source.id());
                if (text == null) {
                    throw new IllegalStateException("LLM enhancement omitted source block " + source.id() + ".");
                }
                if (source.codeLike() && !text.equals(source.text())) {
                    throw new IllegalStateException("LLM attempted to modify code/configuration block " + source.id() + ". Request stopped to protect technical content.");
                }
                result.add(new SourceBlock(source.id(), text, source.codeLike(), source.bulletLike(), false));
            }
        }
        return new EnhancementOutcome(result, calls, chunks.size());
    }

    public SummaryOutcome summarize(String apiKey,
                                    String content,
                                    String audience,
                                    String purpose,
                                    String summaryLength,
                                    String outputFormat) {
        List<String> chunks = chunkText(content, Math.max(chunkCharacters * 2, 14000));
        List<String> partials = new ArrayList<>();
        int calls = 0;

        for (int i = 0; i < chunks.size(); i++) {
            String partial = llmClient.chat(
                    apiKey,
                    promptFactory.summarizeChunk(chunks.get(i), audience, purpose, summaryLength, i + 1, chunks.size()),
                    1800,
                    0.15
            );
            calls++;
            partials.add(partial.trim());
        }

        if (partials.size() == 1) {
            return new SummaryOutcome(partials.get(0), calls, chunks.size());
        }

        // Hierarchical reduction prevents very large documents from overflowing the final synthesis prompt.
        List<String> reduced = partials;
        while (combinedLength(reduced) > 26000 && reduced.size() > 2) {
            List<List<String>> groups = groupSummaries(reduced, 18000);
            List<String> next = new ArrayList<>();
            for (List<String> group : groups) {
                String intermediate = llmClient.chat(
                        apiKey,
                        promptFactory.synthesizeSummary(group, audience, purpose, "Detailed", outputFormat),
                        2200,
                        0.1
                );
                calls++;
                next.add(intermediate.trim());
            }
            reduced = next;
        }

        String finalSummary = llmClient.chat(
                apiKey,
                promptFactory.synthesizeSummary(reduced, audience, purpose, summaryLength, outputFormat),
                2600,
                0.15
        );
        calls++;
        return new SummaryOutcome(finalSummary.trim(), calls, chunks.size());
    }


    /**
     * Stateful editorial workflow implemented with LangGraph4j:
     * ANALYZE -> CREATE -> REVIEW -> (optional REPAIR -> REVIEW) -> FINALIZE.
     *
     * The graph deliberately keeps the model editorially unrestricted while a
     * reviewer node checks destination fitness, repetition and readability. The
     * repair loop is bounded by configuration so generation can never spin.
     */
    public FreeformOutcome freeform(String apiKey,
                                    String content,
                                    String audience,
                                    String purpose,
                                    String outputFormat,
                                    String operation,
                                    String summaryLength) {
        try {
            var workflow = new StateGraph<EditorialState>(EditorialState::new)
                    .addNode("analyze", node_async(state -> analyzeEditorialState(apiKey, state)))
                    .addNode("create", node_async(state -> createEditorialDraft(apiKey, state, "")))
                    .addNode("review", node_async(state -> reviewEditorialDraft(apiKey, state)))
                    .addNode("repair", node_async(state -> repairEditorialDraft(apiKey, state)))
                    .addNode("finalize", node_async(this::finalizeEditorialDraft))
                    .addEdge(START, "analyze")
                    .addEdge("analyze", "create")
                    .addEdge("create", "review")
                    .addConditionalEdges(
                            "review",
                            edge_async(state -> needsEditorialRepair(state) ? "repair" : "finalize"),
                            Map.of("repair", "repair", "finalize", "finalize")
                    )
                    .addEdge("repair", "review")
                    .addEdge("finalize", END)
                    .compile();

            Map<String, Object> input = new HashMap<>();
            input.put(EditorialState.CONTENT, content == null ? "" : content);
            input.put(EditorialState.AUDIENCE, audience == null ? "" : audience);
            input.put(EditorialState.PURPOSE, purpose == null ? "" : purpose);
            input.put(EditorialState.OUTPUT_FORMAT, outputFormat == null ? "" : outputFormat);
            input.put(EditorialState.OPERATION, operation == null ? "FORMAT" : operation);
            input.put(EditorialState.SUMMARY_LENGTH, summaryLength == null ? "" : summaryLength);
            input.put(EditorialState.LLM_CALLS, 0);
            input.put(EditorialState.REPAIR_COUNT, 0);
            input.put(EditorialState.REVIEW_SCORE, 100);
            input.put(EditorialState.REVIEW_PASSED, false);

            EditorialState finalState = workflow.invoke(input)
                    .orElseThrow(() -> new IllegalStateException("LangGraph editorial workflow returned no final state."));

            String html = finalState.finalHtml();
            if (html.isBlank()) {
                throw new IllegalStateException("LangGraph editorial workflow returned empty formatted content.");
            }
            return new FreeformOutcome(
                    html,
                    finalState.llmCalls(),
                    finalState.chunkCount(),
                    finalState.activity()
            );
        } catch (RuntimeException ex) {
            throw ex;
        } catch (Exception ex) {
            throw new IllegalStateException("LangGraph editorial workflow failed: " + ex.getMessage(), ex);
        }
    }

    private Map<String, Object> analyzeEditorialState(String apiKey, EditorialState state) {
        String sample = buildRepresentativeSample(state.content(), graphPlanSampleCharacters);
        String structureHints = extractStructureHints(state.content(), 70);
        String response = llmClient.chat(
                apiKey,
                promptFactory.editorialPlan(
                        sample,
                        structureHints,
                        state.audience(),
                        state.purpose(),
                        state.outputFormat(),
                        state.operation(),
                        state.summaryLength(),
                        state.content().length()
                ),
                2200,
                0.12
        );
        String plan = response == null ? "" : response.trim();
        if (plan.isBlank()) {
            plan = "Use a clear professional hierarchy, remove repetition, preserve factual and technical details, and optimize for "
                    + state.outputFormat() + ".";
        }
        return Map.of(
                EditorialState.EDITORIAL_PLAN, plan,
                EditorialState.LLM_CALLS, state.llmCalls() + 1
        );
    }

    private Map<String, Object> createEditorialDraft(String apiKey, EditorialState state, String repairFeedback) {
        List<String> chunks = chunkText(state.content(), Math.max(chunkCharacters + 5000, 14000));
        List<String> outputs = new ArrayList<>();
        int calls = state.llmCalls();
        String opening = clip(state.content(), 2600);
        String previousTail = "";

        for (int i = 0; i < chunks.size(); i++) {
            String prompt = promptFactory.freeformHtmlWithGraphContext(
                    chunks.get(i),
                    opening,
                    previousTail,
                    state.editorialPlan(),
                    repairFeedback,
                    state.audience(),
                    state.purpose(),
                    state.outputFormat(),
                    state.operation(),
                    state.summaryLength(),
                    i + 1,
                    chunks.size()
            );
            String response = llmClient.chat(apiKey, prompt, 5200, repairFeedback.isBlank() ? 0.20 : 0.12);
            calls++;
            String html = cleanFreeformResponse(response);
            if (!html.isBlank()) outputs.add(html);
            previousTail = clip(html, 2000, true);
        }

        if (outputs.isEmpty()) {
            throw new IllegalStateException("LLM returned empty formatted content during the create node.");
        }
        String draft = String.join("\n", outputs);
        return Map.of(
                EditorialState.DRAFT_HTML, draft,
                EditorialState.LLM_CALLS, calls,
                EditorialState.CHUNK_COUNT, chunks.size(),
                EditorialState.REVIEW_PASSED, false
        );
    }

    private Map<String, Object> reviewEditorialDraft(String apiKey, EditorialState state) {
        List<String> deterministicIssues = deterministicEditorialIssues(
                state.content(), state.draftHtml(), state.outputFormat(), state.operation());
        String sourceSample = buildRepresentativeSample(state.content(), Math.min(graphReviewSampleCharacters, 22000));
        String draftSample = buildRepresentativeSample(state.draftHtml(), graphReviewSampleCharacters);

        String raw = llmClient.chat(
                apiKey,
                promptFactory.editorialReview(
                        sourceSample,
                        draftSample,
                        state.editorialPlan(),
                        deterministicIssues,
                        state.audience(),
                        state.purpose(),
                        state.outputFormat(),
                        state.operation()
                ),
                900,
                0.0
        );

        ReviewDecision decision = parseReviewDecision(raw, deterministicIssues);
        boolean passed = decision.pass() && decision.score() >= graphReviewThreshold && deterministicIssues.isEmpty();
        String feedback = decision.repairInstruction();
        if (!deterministicIssues.isEmpty()) {
            feedback = String.join("; ", deterministicIssues) + (feedback.isBlank() ? "" : "; " + feedback);
        }
        if (!passed && feedback.isBlank()) {
            feedback = "Improve hierarchy and scanability, remove unnecessary repetition, and keep every factual/technical detail grounded in the source.";
        }

        Map<String, Object> update = new HashMap<>();
        update.put(EditorialState.REVIEW_PASSED, passed);
        update.put(EditorialState.REVIEW_SCORE, decision.score());
        update.put(EditorialState.REVIEW_FEEDBACK, feedback);
        update.put(EditorialState.LLM_CALLS, state.llmCalls() + 1);
        return update;
    }

    private Map<String, Object> repairEditorialDraft(String apiKey, EditorialState state) {
        Map<String, Object> recreated = createEditorialDraft(apiKey, state, state.reviewFeedback());
        Map<String, Object> update = new HashMap<>(recreated);
        update.put(EditorialState.REPAIR_COUNT, state.repairCount() + 1);
        return update;
    }

    private Map<String, Object> finalizeEditorialDraft(EditorialState state) {
        String html = cleanFreeformResponse(state.draftHtml());
        String activity = state.repairCount() > 0
                ? "LangGraph Editorial • Analyze → Create → Review → Repair → Review"
                : "LangGraph Editorial • Analyze → Create → Review";
        return Map.of(
                EditorialState.FINAL_HTML, html,
                EditorialState.ACTIVITY, activity
        );
    }

    private boolean needsEditorialRepair(EditorialState state) {
        return !state.reviewPassed() && state.repairCount() < maxGraphRepairs;
    }

    private ReviewDecision parseReviewDecision(String raw, List<String> deterministicIssues) {
        try {
            JsonNode root = readJson(raw);
            boolean pass = root.path("pass").asBoolean(true);
            int score = Math.max(0, Math.min(100, root.path("score").asInt(pass ? 90 : 70)));
            List<String> issues = new ArrayList<>();
            JsonNode issueNode = root.path("issues");
            if (issueNode.isArray()) {
                for (JsonNode item : issueNode) {
                    String text = item.asText("").trim();
                    if (!text.isBlank()) issues.add(text);
                }
            }
            String instruction = root.path("repairInstruction").asText("").trim();
            if (instruction.isBlank() && !issues.isEmpty()) instruction = String.join("; ", issues);
            return new ReviewDecision(pass, score, instruction);
        } catch (RuntimeException invalidReviewJson) {
            // A malformed reviewer response should not destroy a good create pass.
            // Deterministic issues still force repair; otherwise keep the draft.
            boolean pass = deterministicIssues.isEmpty();
            return new ReviewDecision(pass, pass ? 82 : 65,
                    deterministicIssues.isEmpty() ? "" : String.join("; ", deterministicIssues));
        }
    }

    private List<String> deterministicEditorialIssues(String sourceContent,
                                                       String html,
                                                       String outputFormat,
                                                       String operation) {
        List<String> issues = new ArrayList<>();
        Document doc = Jsoup.parseBodyFragment(html == null ? "" : html);
        if (doc.body().text().isBlank()) {
            issues.add("Generated output is empty or unreadable");
            return issues;
        }
        if (!doc.select("script,style,iframe,form,img").isEmpty()) {
            issues.add("Remove unsupported or unsafe HTML elements");
        }

        Map<String, Integer> headings = new LinkedHashMap<>();
        for (Element heading : doc.select("h1,h2,h3,h4")) {
            String normalized = normalizeComparableText(heading.text());
            if (normalized.length() >= 4) headings.merge(normalized, 1, Integer::sum);
        }
        headings.entrySet().stream()
                .filter(e -> e.getValue() > 1)
                .limit(4)
                .forEach(e -> issues.add("Avoid duplicate heading: " + e.getKey()));

        Map<String, Integer> longBlocks = new LinkedHashMap<>();
        for (Element block : doc.select("p,li")) {
            String normalized = normalizeComparableText(block.text());
            if (normalized.length() >= 90) longBlocks.merge(normalized, 1, Integer::sum);
        }
        if (longBlocks.values().stream().anyMatch(count -> count > 1)) {
            issues.add("Remove exact repeated body points created across chunks");
        }

        if ("EMAIL".equalsIgnoreCase(outputFormat) && !doc.select("h1").isEmpty()) {
            issues.add("Use a lighter email hierarchy instead of an H1 document title");
        }

        if ("FORMAT".equalsIgnoreCase(operation)) {
            int sourceWords = countWords(sourceContent);
            int topicHeadings = doc.select("h2,h3,h4").size();
            int expectedMinimum = minimumTopicHeadings(sourceWords);
            if (expectedMinimum > 0 && topicHeadings < expectedMinimum) {
                issues.add("Expand topic coverage: rich source content has only " + topicHeadings
                        + " topic heading(s); use at least about " + expectedMinimum
                        + " meaningful H2/H3 sections when supported by the source");
            }

            if (("CONFLUENCE".equalsIgnoreCase(outputFormat) || "HTML".equalsIgnoreCase(outputFormat) || "POWERPOINT".equalsIgnoreCase(outputFormat))
                    && sourceWords >= 350 && topicHeadings >= 2) {
                long iconHeadings = doc.select("h2,h3").stream()
                        .filter(h -> startsWithTopicIcon(h.text()))
                        .count();
                long majorHeadings = doc.select("h2,h3").size();
                if (majorHeadings > 0 && iconHeadings * 100 / majorHeadings < 60) {
                    issues.add("Add varied relevant icons to major topic headings/slide titles; most H2/H3 headings are currently icon-less");
                }
            }
        }
        if ("POWERPOINT".equalsIgnoreCase(outputFormat) && "FORMAT".equalsIgnoreCase(operation)) {
            int sourceWords = countWords(sourceContent);
            int slideHeadings = doc.select("h2").size();
            int expectedSlides = minimumSlideHeadings(sourceWords);
            if (doc.select("h1").isEmpty()) {
                issues.add("Add one clear h1 deck title before the slide h2 sections");
            }
            if (expectedSlides > 0 && slideHeadings < expectedSlides) {
                issues.add("Create more slide topics: source content supports about " + expectedSlides
                        + " slides but draft has only " + slideHeadings + " H2 slide title(s)");
            }
            boolean hasLongSlideText = doc.select("p,li").stream()
                    .anyMatch(e -> countWords(e.text()) > 28);
            if (hasLongSlideText) {
                issues.add("Shorten slide body text: use presentation bullets instead of long paragraphs");
            }
            if (sourceWords >= 750 && slideHeadings >= 5) {
                boolean hasAgenda = doc.select("h2").stream()
                        .anyMatch(h -> normalizeComparableText(h.text()).contains("agenda") || normalizeComparableText(h.text()).contains("contents"));
                if (!hasAgenda) issues.add("Add an agenda slide after the title for this multi-topic presentation");
            }
            boolean hasPresentationStructure = !doc.select("blockquote,h3,ol,table").isEmpty();
            if (sourceWords >= 900 && !hasPresentationStructure) {
                issues.add("Use richer slide structures where suitable: blockquote for key message, h3 for two-column topic panels, ol for processes, or table for comparisons/data");
            }
            for (Element h2 : doc.select("h2")) {
                int bulletCount = 0;
                int wordsInSlide = 0;
                Element cursor = h2.nextElementSibling();
                while (cursor != null && !"h2".equalsIgnoreCase(cursor.tagName())) {
                    bulletCount += cursor.select("li").size();
                    if (!cursor.tagName().matches("h3|h4")) wordsInSlide += countWords(cursor.text());
                    cursor = cursor.nextElementSibling();
                }
                if (bulletCount > 7 || wordsInSlide > 115) {
                    issues.add("Split or condense overloaded slide: " + h2.text());
                    break;
                }
            }
        }
        return issues;
    }

    private int minimumSlideHeadings(int sourceWords) {
        if (sourceWords < 250) return 0;
        if (sourceWords < 700) return 4;
        if (sourceWords < 1400) return 6;
        if (sourceWords < 2600) return 8;
        if (sourceWords < 4500) return 10;
        if (sourceWords < 7500) return 13;
        return 15;
    }

    private int countWords(String text) {
        String value = text == null ? "" : text.trim();
        return value.isBlank() ? 0 : value.split("\\s+").length;
    }

    private int minimumTopicHeadings(int sourceWords) {
        if (sourceWords < 500) return 0;
        if (sourceWords < 1200) return 2;
        if (sourceWords < 2500) return 4;
        if (sourceWords < 5000) return 6;
        if (sourceWords < 10000) return 8;
        return 10;
    }

    private boolean startsWithTopicIcon(String text) {
        if (text == null || text.isBlank()) return false;
        String trimmed = text.stripLeading();
        int cp = trimmed.codePointAt(0);
        int type = Character.getType(cp);
        return type == Character.OTHER_SYMBOL
                || type == Character.MODIFIER_SYMBOL
                || (cp >= 0x2600 && cp <= 0x27BF)
                || (cp >= 0x1F300 && cp <= 0x1FAFF);
    }

    private String normalizeComparableText(String text) {
        return text == null ? "" : text.toLowerCase(Locale.ROOT)
                .replaceAll("[^\\p{L}\\p{N}]+", " ")
                .trim()
                .replaceAll("\\s+", " ");
    }

    private String buildRepresentativeSample(String value, int maxChars) {
        String text = value == null ? "" : value;
        if (text.length() <= maxChars) return text;
        int first = Math.max(1, maxChars * 40 / 100);
        int middle = Math.max(1, maxChars * 25 / 100);
        int last = Math.max(1, maxChars - first - middle);
        int middleStart = Math.max(first, (text.length() - middle) / 2);
        int middleEnd = Math.min(text.length(), middleStart + middle);
        return text.substring(0, Math.min(first, text.length()))
                + "\n\n[... middle sample ...]\n\n"
                + text.substring(middleStart, middleEnd)
                + "\n\n[... final sample ...]\n\n"
                + text.substring(Math.max(0, text.length() - last));
    }

    private String extractStructureHints(String content, int maxLines) {
        if (content == null || content.isBlank()) return "No explicit structure detected.";
        List<String> hints = new ArrayList<>();
        for (String raw : content.split("\\R")) {
            String line = raw.trim();
            if (line.isBlank() || line.length() > 180) continue;
            boolean headingLike = line.matches("^(#{1,4}\\s+.+|[A-Z][A-Z0-9 /&:_-]{3,}|\\d+(?:\\.\\d+)*[.)]?\\s+.+)$");
            boolean instructionLike = line.toLowerCase(Locale.ROOT).matches(".*\\b(format|rewrite|make|avoid|use|organize|organise|summarize|summarise)\\b.*");
            if (headingLike || instructionLike) {
                hints.add(line);
                if (hints.size() >= maxLines) break;
            }
        }
        return hints.isEmpty() ? "No explicit headings/instructions detected in line structure." : String.join("\n", hints);
    }

    private String cleanFreeformResponse(String raw) {
        if (raw == null) return "";
        String value = raw.trim();
        if (value.startsWith("```")) {
            value = value.replaceFirst("^```(?:html|xml)?\\s*", "")
                    .replaceFirst("\\s*```$", "")
                    .trim();
        }
        return value;
    }

    private String clip(String value, int max) {
        return clip(value, max, false);
    }

    private String clip(String value, int max, boolean tail) {
        if (value == null || value.length() <= max) return value == null ? "" : value;
        return tail ? value.substring(value.length() - max) : value.substring(0, max);
    }

    public String generateEmailSubject(String apiKey, String content, String audience, String purpose) {
        String response = llmClient.chat(apiKey, promptFactory.emailSubject(content, audience, purpose), 64, 0.1);
        String subject = response.replace("\r", " ").replace("\n", " ").trim();
        if (subject.startsWith("\"") && subject.endsWith("\"") && subject.length() > 1) {
            subject = subject.substring(1, subject.length() - 1);
        }
        if (subject.length() > 160) subject = subject.substring(0, 160).trim();
        return subject;
    }

    private int combinedLength(List<String> values) {
        return values.stream().mapToInt(String::length).sum();
    }

    private List<List<String>> groupSummaries(List<String> summaries, int maxChars) {
        List<List<String>> groups = new ArrayList<>();
        List<String> current = new ArrayList<>();
        int chars = 0;
        for (String summary : summaries) {
            if (!current.isEmpty() && chars + summary.length() > maxChars) {
                groups.add(List.copyOf(current));
                current.clear();
                chars = 0;
            }
            current.add(summary);
            chars += summary.length();
        }
        if (!current.isEmpty()) groups.add(List.copyOf(current));
        return groups;
    }

    private List<PlanItem> parsePlan(String response, List<SourceBlock> chunk) {
        JsonNode root = readJson(response);
        JsonNode items = root.path("items");
        if (!items.isArray()) throw new IllegalStateException("LLM formatting response did not contain an items array.");

        Set<String> allowedIds = chunk.stream().map(SourceBlock::id).collect(Collectors.toSet());
        Set<String> seen = new HashSet<>();
        List<PlanItem> result = new ArrayList<>();

        for (JsonNode item : items) {
            String id = item.path("id").asText("");
            if (!allowedIds.contains(id) || !seen.add(id)) continue;
            String type = validType(item.path("type").asText("PARAGRAPH"));
            String icon = iconCatalog.normalize(item.path("iconKey").asText("NONE"));
            String emphasis = valid(item.path("emphasis").asText("NONE"), Set.of("NONE", "STRONG", "MUTED", "HIGHLIGHT"), "NONE");
            String bullet = valid(item.path("bulletStyle").asText("NONE"), Set.of("NONE", "CHECK", "ARROW", "DOT"), "NONE");
            result.add(new PlanItem(id, type, icon, emphasis, bullet));
        }
        return result;
    }

    private JsonNode readJson(String raw) {
        try {
            String cleaned = raw == null ? "" : raw.trim();
            if (cleaned.startsWith("```")) {
                cleaned = cleaned.replaceFirst("^```(?:json)?\\s*", "").replaceFirst("\\s*```$", "");
            }
            int first = cleaned.indexOf('{');
            int last = cleaned.lastIndexOf('}');
            if (first >= 0 && last > first) cleaned = cleaned.substring(first, last + 1);
            return objectMapper.readTree(cleaned);
        } catch (Exception ex) {
            throw new IllegalStateException("LLM returned invalid structured JSON. Try again or inspect the configured model compatibility.", ex);
        }
    }

    private String validType(String type) {
        return valid(type, Set.of("TITLE", "HEADING", "PARAGRAPH", "BULLET", "CODE", "CALLOUT", "QUOTE"), "PARAGRAPH");
    }

    private String valid(String value, Set<String> allowed, String fallback) {
        String normalized = value == null ? fallback : value.trim().toUpperCase(Locale.ROOT);
        return allowed.contains(normalized) ? normalized : fallback;
    }

    private List<String> chunkText(String content, int maxChars) {
        List<String> result = new ArrayList<>();
        String safeContent = content == null ? "" : content;
        String[] paragraphs = safeContent.split("(?m)(?<=\n)\s*\n");
        StringBuilder current = new StringBuilder();

        for (String paragraph : paragraphs) {
            if (paragraph.length() > maxChars) {
                if (!current.isEmpty()) {
                    result.add(current.toString());
                    current.setLength(0);
                }
                int offset = 0;
                while (offset < paragraph.length()) {
                    int target = Math.min(paragraph.length(), offset + maxChars);
                    int cut = target;
                    if (target < paragraph.length()) {
                        int newline = paragraph.lastIndexOf('\n', target);
                        int space = paragraph.lastIndexOf(' ', target);
                        int candidate = Math.max(newline, space);
                        if (candidate > offset + maxChars / 2) cut = candidate;
                    }
                    result.add(paragraph.substring(offset, cut).trim());
                    offset = Math.max(cut, offset + 1);
                    while (offset < paragraph.length() && Character.isWhitespace(paragraph.charAt(offset))) offset++;
                }
                continue;
            }

            if (!current.isEmpty() && current.length() + paragraph.length() + 2 > maxChars) {
                result.add(current.toString());
                current.setLength(0);
            }
            if (!current.isEmpty()) current.append("\n\n");
            current.append(paragraph);
        }
        if (!current.isEmpty()) result.add(current.toString());
        result.removeIf(String::isBlank);
        if (result.isEmpty()) result.add(safeContent);
        return result;
    }

    public record PlanOutcome(List<PlanItem> items, int llmCalls, int chunks) {}
    public record EnhancementOutcome(List<SourceBlock> blocks, int llmCalls, int chunks) {}
    public record SummaryOutcome(String content, int llmCalls, int chunks) {}
    public record FreeformOutcome(String html, int llmCalls, int chunks, String workflowActivity) {
        public FreeformOutcome(String html, int llmCalls, int chunks) {
            this(html, llmCalls, chunks, "LangGraph Editorial • Analyze → Create → Review");
        }
    }

    private record ReviewDecision(boolean pass, int score, String repairInstruction) {}

    private static final class EditorialState extends AgentState {
        static final String CONTENT = "content";
        static final String AUDIENCE = "audience";
        static final String PURPOSE = "purpose";
        static final String OUTPUT_FORMAT = "outputFormat";
        static final String OPERATION = "operation";
        static final String SUMMARY_LENGTH = "summaryLength";
        static final String EDITORIAL_PLAN = "editorialPlan";
        static final String DRAFT_HTML = "draftHtml";
        static final String FINAL_HTML = "finalHtml";
        static final String REVIEW_PASSED = "reviewPassed";
        static final String REVIEW_SCORE = "reviewScore";
        static final String REVIEW_FEEDBACK = "reviewFeedback";
        static final String REPAIR_COUNT = "repairCount";
        static final String LLM_CALLS = "llmCalls";
        static final String CHUNK_COUNT = "chunkCount";
        static final String ACTIVITY = "activity";

        EditorialState(Map<String, Object> initData) { super(initData); }
        String content() { return this.<String>value(CONTENT).orElse(""); }
        String audience() { return this.<String>value(AUDIENCE).orElse(""); }
        String purpose() { return this.<String>value(PURPOSE).orElse(""); }
        String outputFormat() { return this.<String>value(OUTPUT_FORMAT).orElse("CONFLUENCE"); }
        String operation() { return this.<String>value(OPERATION).orElse("FORMAT"); }
        String summaryLength() { return this.<String>value(SUMMARY_LENGTH).orElse(""); }
        String editorialPlan() { return this.<String>value(EDITORIAL_PLAN).orElse(""); }
        String draftHtml() { return this.<String>value(DRAFT_HTML).orElse(""); }
        String finalHtml() { return this.<String>value(FINAL_HTML).orElse(draftHtml()); }
        boolean reviewPassed() { return this.<Boolean>value(REVIEW_PASSED).orElse(false); }
        int repairCount() { return this.<Integer>value(REPAIR_COUNT).orElse(0); }
        int llmCalls() { return this.<Integer>value(LLM_CALLS).orElse(0); }
        int chunkCount() { return this.<Integer>value(CHUNK_COUNT).orElse(1); }
        String reviewFeedback() { return this.<String>value(REVIEW_FEEDBACK).orElse(""); }
        String activity() { return this.<String>value(ACTIVITY).orElse("LangGraph Editorial"); }
    }
}
