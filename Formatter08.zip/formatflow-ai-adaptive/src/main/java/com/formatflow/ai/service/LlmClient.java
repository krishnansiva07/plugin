package com.formatflow.ai.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.formatflow.ai.config.LlmProperties;
import org.springframework.stereotype.Service;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.atomic.AtomicReference;

@Service
public class LlmClient {

    private final HttpClient httpClient;
    private final ObjectMapper objectMapper;
    private final LlmProperties properties;

    /**
     * Authentication style is an endpoint-level concern, so once a working
     * header/prefix is discovered it is safe and efficient to reuse it for
     * subsequent requests.  The API key itself is never stored here.
     */
    private final AtomicReference<AuthSpec> learnedAuth = new AtomicReference<>();

    public LlmClient(HttpClient httpClient, ObjectMapper objectMapper, LlmProperties properties) {
        this.httpClient = httpClient;
        this.objectMapper = objectMapper;
        this.properties = properties;
    }

    public ValidationResult validateKey(String rawApiKey) {
        String apiKey = normalizeApiKey(rawApiKey);
        if (apiKey.isBlank()) {
            return new ValidationResult(false, "Enter a valid LLM API key.");
        }

        try {
            String response = chat(apiKey, "Reply with exactly OK.", 24, 0.0);
            return response == null || response.isBlank()
                    ? new ValidationResult(false, "The AI service connected but returned an empty response.")
                    : new ValidationResult(true, "AI service connected.");
        } catch (LlmHttpException ex) {
            return new ValidationResult(false, validationMessage(ex));
        } catch (Exception ex) {
            return new ValidationResult(false, "Unable to connect to the configured LLM service: " + safeMessage(ex));
        }
    }

    public String chat(String rawApiKey, String prompt, int maxTokens, double temperature) {
        String apiKey = normalizeApiKey(rawApiKey);
        if (apiKey.isBlank()) {
            throw new IllegalStateException("LLM API key is blank.");
        }

        int attempts = 3;
        RuntimeException last = null;

        for (int attempt = 1; attempt <= attempts; attempt++) {
            try {
                return doChatWithAuthDiscovery(apiKey, prompt, maxTokens, temperature);
            } catch (LlmHttpException ex) {
                last = ex;
                if (!retryable(ex.statusCode) || attempt == attempts) throw ex;
                sleep(attempt);
            } catch (RuntimeException ex) {
                last = ex;
                if (attempt == attempts) throw ex;
                sleep(attempt);
            }
        }
        throw last == null ? new IllegalStateException("LLM request failed.") : last;
    }

    private String doChatWithAuthDiscovery(String apiKey, String prompt, int maxTokens, double temperature) {
        List<AuthSpec> candidates = authCandidates();
        LlmHttpException lastAuthFailure = null;

        for (AuthSpec auth : candidates) {
            try {
                String response = doChat(apiKey, prompt, maxTokens, temperature, auth);
                learnedAuth.set(auth);
                return response;
            } catch (LlmHttpException ex) {
                if ((ex.statusCode == 401 || ex.statusCode == 403) && properties.isAuthAutoDetect()) {
                    lastAuthFailure = ex;
                    continue;
                }
                throw ex;
            }
        }

        if (lastAuthFailure != null) throw lastAuthFailure;
        throw new IllegalStateException("No LLM authentication strategy is configured.");
    }

    private String doChat(String apiKey,
                          String prompt,
                          int maxTokens,
                          double temperature,
                          AuthSpec auth) {
        try {
            String body = objectMapper.writeValueAsString(Map.of(
                    "model", properties.getModel(),
                    "messages", List.of(Map.of("role", "user", "content", prompt)),
                    "temperature", temperature,
                    "max_tokens", maxTokens
            ));

            HttpRequest request = HttpRequest.newBuilder()
                    .uri(chatUri())
                    .timeout(Duration.ofSeconds(properties.getRequestTimeoutSeconds()))
                    .header("Content-Type", "application/json")
                    .header("Accept", "application/json")
                    .header(auth.header(), auth.prefix() + apiKey)
                    .POST(HttpRequest.BodyPublishers.ofString(body))
                    .build();

            HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
            if (response.statusCode() < 200 || response.statusCode() >= 300) {
                throw new LlmHttpException(response.statusCode(), response.body());
            }

            JsonNode json = objectMapper.readTree(response.body());
            JsonNode content = json.at("/choices/0/message/content");
            if (content.isMissingNode() || content.isNull()) {
                throw new IllegalStateException("LLM response does not contain choices[0].message.content.");
            }
            return content.asText();
        } catch (LlmHttpException ex) {
            throw ex;
        } catch (Exception ex) {
            throw new IllegalStateException("LLM request failed: " + safeMessage(ex), ex);
        }
    }

    private List<AuthSpec> authCandidates() {
        Set<AuthSpec> ordered = new LinkedHashSet<>();

        AuthSpec learned = learnedAuth.get();
        if (learned != null) ordered.add(learned);

        ordered.add(new AuthSpec(nonBlank(properties.getAuthHeader(), "Authorization"),
                properties.getAuthPrefix() == null ? "" : properties.getAuthPrefix()));

        if (properties.isAuthAutoDetect()) {
            // Common OpenAI-compatible enterprise gateways.  All requests go to
            // the same configured endpoint; only the authentication header shape
            // is retried when the gateway returns 401/403.
            ordered.add(new AuthSpec("Authorization", "Bearer "));
            ordered.add(new AuthSpec("Authorization", ""));
            ordered.add(new AuthSpec("api-key", ""));
            ordered.add(new AuthSpec("x-api-key", ""));
        }

        return new ArrayList<>(ordered);
    }

    private URI chatUri() {
        String base = properties.getBaseUrl();
        if (base == null || base.isBlank()) {
            throw new IllegalStateException("formatflow.llm.base-url is not configured.");
        }
        base = base.endsWith("/") ? base.substring(0, base.length() - 1) : base;
        String path = properties.getChatPath() == null ? "/chat/completions" : properties.getChatPath();
        path = path.startsWith("/") ? path : "/" + path;
        return URI.create(base + path);
    }

    private boolean retryable(int status) {
        return status == 408 || status == 429 || status == 500 || status == 502 || status == 503 || status == 504;
    }

    private void sleep(int attempt) {
        try {
            Thread.sleep(Math.min(4000L, 500L * (1L << (attempt - 1))));
        } catch (InterruptedException ex) {
            Thread.currentThread().interrupt();
            throw new IllegalStateException("LLM retry interrupted.", ex);
        }
    }

    /**
     * Accepts either a raw key or a value copied as "Bearer <key>".  Quotes
     * accidentally copied from configuration files are also removed.
     */
    static String normalizeApiKey(String raw) {
        if (raw == null) return "";
        String key = raw.trim();
        if ((key.startsWith("\"") && key.endsWith("\"")) ||
                (key.startsWith("'") && key.endsWith("'"))) {
            if (key.length() > 1) key = key.substring(1, key.length() - 1).trim();
        }
        if (key.regionMatches(true, 0, "Bearer ", 0, 7)) {
            key = key.substring(7).trim();
        }
        return key;
    }

    private String validationMessage(LlmHttpException ex) {
        String detail = extractServiceError(ex.responseBody);
        return switch (ex.statusCode) {
            case 400, 422 -> "The LLM endpoint rejected the validation request (HTTP " + ex.statusCode + ")"
                    + suffix(detail) + ". Check the configured model and OpenAI-compatible request format.";
            case 401 -> "Authentication failed (HTTP 401). Check the API key. You may paste either the raw key or 'Bearer <key>'."
                    + suffix(detail);
            case 403 -> "The LLM gateway denied access (HTTP 403). This can mean model/endpoint permission rather than a bad API key."
                    + suffix(detail);
            case 404 -> "The configured LLM chat endpoint was not found (HTTP 404). Check base-url and chat-path."
                    + suffix(detail);
            case 429 -> "The LLM service is rate-limiting requests (HTTP 429). Please retry shortly."
                    + suffix(detail);
            default -> "LLM service returned HTTP " + ex.statusCode + suffix(detail) + ".";
        };
    }

    private String extractServiceError(String body) {
        if (body == null || body.isBlank()) return "";
        try {
            JsonNode root = objectMapper.readTree(body);
            for (String pointer : List.of("/error/message", "/message", "/detail", "/error")) {
                JsonNode node = root.at(pointer);
                if (!node.isMissingNode() && !node.isNull() && node.isValueNode()) {
                    String text = node.asText().trim();
                    if (!text.isBlank()) return truncate(text, 180);
                }
            }
        } catch (Exception ignored) {
            // Fall through to a compact text version.
        }
        return truncate(body.replaceAll("\\s+", " ").trim(), 180);
    }

    private static String suffix(String detail) {
        return detail == null || detail.isBlank() ? "" : " Service message: " + detail;
    }

    private static String nonBlank(String value, String fallback) {
        return value == null || value.isBlank() ? fallback : value;
    }

    private static String truncate(String text, int max) {
        if (text == null) return "";
        return text.length() > max ? text.substring(0, max) : text;
    }

    private static String safeMessage(Exception ex) {
        String msg = ex.getMessage();
        if (msg == null || msg.isBlank()) return ex.getClass().getSimpleName();
        return msg.length() > 180 ? msg.substring(0, 180) : msg;
    }

    public record ValidationResult(boolean valid, String message) {}

    private record AuthSpec(String header, String prefix) {}

    private static final class LlmHttpException extends RuntimeException {
        private final int statusCode;
        private final String responseBody;

        private LlmHttpException(int statusCode, String responseBody) {
            super("LLM HTTP " + statusCode);
            this.statusCode = statusCode;
            this.responseBody = responseBody;
        }
    }
}
