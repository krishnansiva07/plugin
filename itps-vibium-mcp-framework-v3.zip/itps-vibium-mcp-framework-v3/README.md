# ITPS VIBIUM Framework - MCP Edition V3

Production-style Java Spring Boot UI test runner that executes browser actions through **Vibium MCP**.

## What V3 fixes

The earlier V2 could show false positives because it allowed deterministic heuristic selectors such as `text=NEW-IP capsule`. The MCP tool call could return without a hard error even though the page did not visibly move.

V3 changes the execution model:

- No Selenium dependency and no Selenium fallback.
- Vibium MCP is the browser execution engine.
- Browser starts once per run.
- Natural-language UI action steps use **LLM + Vibium MCP page map**.
- Heuristic fake-pass mode is disabled.
- `browser_start`, `browser_map`, and `browser_wait_for_load` alone cannot pass an action step.
- Strict evidence validation is enabled by default.
- Screenshot mode defaults to **ALL**.
- HTML report includes plan source, MCP tool, arguments, evidence, screenshots, and errors.

## Prerequisite

Your machine already confirmed Vibium MCP works:

```powershell
cd C:\tools\vibium-portable\node_modules\.bin
.\vibium.cmd --version
.\vibium.cmd paths
.\vibium.cmd is-installed
.\vibium.cmd mcp
```

When MCP shows `Waiting for client connection on stdin`, it is ready.

## Configuration

`src/main/resources/application.properties`

```properties
itps.vibium.mcp.command=C:\\tools\\vibium-portable\\node_modules\\.bin\\vibium.cmd
itps.vibium.mcp.args=mcp
itps.vibium.skip-browser-download=true
```

## Run

```cmd
mvn clean spring-boot:run
```

Open:

```text
http://localhost:8090
```

## UI fields

The UI intentionally does not ask for Chrome, ChromeDriver, or browser paths.

Required for natural-language steps:

- LLM Base URL
- Model
- Token
- Excel/JSON scenario file

Recommended while debugging:

- Headless: unchecked
- Screenshot mode: ALL
- Strict evidence validation: checked

## Test data guidance

Your previous sheet had only:

```text
click NEW-IP capsule | click Alert | click Flow | click CAM
```

That is not enough if `NEW-IP` is not already visible on the landing page and must be selected through search.

Use this flow:

```text
Click search icon | Enter {{searchText}} in search field | Click {{searchText}} from search results | Click {{alertTab}} | Click {{flowTab}} | Click {{camTab}}
```

With columns:

```text
data.searchText = NEW-IP
data.alertTab = Alert
data.flowTab = Flow
data.camTab = CAM
```

Sample files are in `samples/`.

## Output

After execution:

```text
target/itps-vibium-runs/<run-id>/
  report.html
  report.json
  report.xlsx
  screenshots.zip
  mcp-tools.json
  screenshots/
```

## Important behaviour

If LLM is not configured and the step is natural language, V3 fails clearly instead of guessing. This is intentional because the product needs reliable MCP/DOM-based behaviour, not hidden selector assumptions.
