package com.itps.vibium.service;

import com.itps.vibium.model.McpTool;

import java.util.*;
import java.util.stream.Collectors;

public class McpToolCatalog {
    private final List<McpTool> tools;

    public McpToolCatalog(List<McpTool> tools) {
        this.tools = tools == null ? List.of() : tools;
    }

    public List<McpTool> getTools() { return tools; }

    public Optional<McpTool> findByName(String name) {
        if (name == null) return Optional.empty();
        return tools.stream().filter(t -> t.getName().equalsIgnoreCase(name.trim())).findFirst();
    }

    public Optional<McpTool> findFirstContaining(String... keywords) {
        List<String> keys = Arrays.stream(keywords).filter(Objects::nonNull).map(String::toLowerCase).toList();
        return tools.stream().filter(t -> keys.stream().anyMatch(k -> normalize(t).contains(k))).findFirst();
    }

    public Optional<McpTool> startTool() { return exactOrContaining("browser_start", "start", "launch"); }
    public Optional<McpTool> mapTool() { return exactOrContaining("browser_map", "map", "snapshot", "elements", "accessibility"); }
    public Optional<McpTool> screenshotTool() { return exactOrContaining("browser_screenshot", "screenshot", "capture"); }
    public Optional<McpTool> navigateTool() { return exactOrContaining("browser_navigate", "navigate", "goto", "go", "open"); }
    public Optional<McpTool> waitTool() { return exactOrContaining("browser_wait_for_load", "wait_for_load", "wait", "load"); }
    public Optional<McpTool> clickTool() { return exactOrContaining("browser_click", "click", "tap"); }
    public Optional<McpTool> fillTool() { return exactOrContaining("browser_fill", "fill", "type", "input", "write"); }
    public Optional<McpTool> pressTool() { return exactOrContaining("browser_press", "press", "key"); }
    public Optional<McpTool> selectTool() { return exactOrContaining("browser_select", "select", "option"); }

    private Optional<McpTool> exactOrContaining(String exact, String... keywords) {
        Optional<McpTool> exactMatch = findByName(exact);
        return exactMatch.isPresent() ? exactMatch : findFirstContaining(keywords);
    }

    public String toPromptText() {
        return tools.stream().map(t -> {
            String schema = t.getInputSchema() == null || t.getInputSchema().isMissingNode() ? "{}" : compact(t.getInputSchema().toString(), 1600);
            return "- name: " + t.getName() + "\n  description: " + nullSafe(t.getDescription()) + "\n  inputSchema: " + schema;
        }).collect(Collectors.joining("\n"));
    }

    private String normalize(McpTool t) {
        return (nullSafe(t.getName()) + " " + nullSafe(t.getDescription()) + " " + (t.getInputSchema() == null ? "" : t.getInputSchema().toString())).toLowerCase(Locale.ROOT);
    }

    private String nullSafe(String s) { return s == null ? "" : s; }

    private String compact(String s, int max) {
        if (s == null) return "";
        String oneLine = s.replaceAll("\\s+", " ").trim();
        return oneLine.length() <= max ? oneLine : oneLine.substring(0, max) + "...";
    }
}
