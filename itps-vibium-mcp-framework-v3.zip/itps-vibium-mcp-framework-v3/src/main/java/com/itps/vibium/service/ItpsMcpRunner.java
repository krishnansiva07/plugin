package com.itps.vibium.service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.itps.vibium.model.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.time.Duration;
import java.time.Instant;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Service
public class ItpsMcpRunner {
    private final LlmClient llmClient;
    private final ReportService reportService;
    private final RunStore runStore;
    private final ObjectMapper mapper = new ObjectMapper();
    private final Path outputRoot;
    private final int requestTimeoutSeconds;
    private final boolean skipBrowserDownload;

    public ItpsMcpRunner(LlmClient llmClient,
                         ReportService reportService,
                         RunStore runStore,
                         @Value("${runner.output-dir:target/itps-vibium-runs}") String outputDir,
                         @Value("${itps.vibium.mcp.request-timeout-seconds:90}") int requestTimeoutSeconds,
                         @Value("${itps.vibium.skip-browser-download:true}") boolean skipBrowserDownload) {
        this.llmClient = llmClient;
        this.reportService = reportService;
        this.runStore = runStore;
        this.outputRoot = Path.of(outputDir);
        this.requestTimeoutSeconds = requestTimeoutSeconds;
        this.skipBrowserDownload = skipBrowserDownload;
    }

    public void execute(List<TestScenario> scenarios, RunConfig config, RunStatus status) {
        Instant runStart = Instant.now();
        status.setStatus("RUNNING");
        status.setStartedAt(runStart);
        Path runDir = outputRoot.resolve(config.getRunId());
        Path screenshotDir = runDir.resolve("screenshots");
        try { Files.createDirectories(screenshotDir); }
        catch (Exception e) {
            status.setStatus("FAILED");
            status.setMessage("Unable to create output directory: " + e.getMessage());
            return;
        }

        try (McpClient mcp = new McpClient(config.getMcpCommand(), splitArgs(config.getMcpArgs()), Duration.ofSeconds(requestTimeoutSeconds), skipBrowserDownload)) {
            mcp.start();
            List<McpTool> tools = mcp.initializeAndListTools();
            McpToolCatalog catalog = new McpToolCatalog(tools);
            writeToolsManifest(runDir, tools);
            startBrowserOnce(mcp, catalog, config);

            List<ScenarioResult> results = new ArrayList<>();
            for (TestScenario scenario : scenarios) {
                results.add(executeScenario(mcp, catalog, scenario, config, screenshotDir));
            }

            status.setScenarios(results);
            status.setTotal(results.size());
            int passed = (int) results.stream().filter(s -> "PASSED".equals(s.getStatus())).count();
            status.setPassed(passed);
            status.setFailed(results.size() - passed);
            status.setStatus(status.getFailed() == 0 ? "PASSED" : "COMPLETED_WITH_FAILURES");
            status.setMessage("V3 MCP agent execution completed. Natural language actions are planned using LLM + Vibium page map; heuristic fake-pass mode is disabled.");
        } catch (Exception e) {
            status.setStatus("FAILED");
            status.setMessage("Vibium MCP execution failed: " + e.getMessage());
        } finally {
            status.setFinishedAt(Instant.now());
            try { reportService.writeReports(status, runDir); }
            catch (Exception reportError) {
                status.setMessage((status.getMessage() == null ? "" : status.getMessage() + " | ") + "Report generation failed: " + reportError.getMessage());
            }
        }
    }

    private void startBrowserOnce(McpClient mcp, McpToolCatalog catalog, RunConfig config) throws Exception {
        Optional<McpTool> start = catalog.startTool();
        if (start.isEmpty()) return;
        Map<String, Object> args = new LinkedHashMap<>();
        if (schemaContains(start.get(), "headless")) args.put("headless", config.isHeadless());
        JsonNode result = mcp.callTool(start.get().getName(), args);
        assertMcpToolSuccess(start.get().getName(), result);
    }

    private ScenarioResult executeScenario(McpClient mcp, McpToolCatalog catalog, TestScenario scenario, RunConfig config, Path screenshotDir) {
        long scenarioStart = System.currentTimeMillis();
        ScenarioResult out = new ScenarioResult();
        out.setId(scenario.getId());
        out.setName(scenario.getName());
        out.setUrl(resolveUrl(scenario.getUrl(), config.getAppBaseUrl()));
        out.setStatus("RUNNING");

        List<String> steps = new ArrayList<>();
        if (notBlank(out.getUrl())) steps.add("Navigate to " + out.getUrl());
        steps.addAll(scenario.getSteps());
        if (notBlank(scenario.getExpected())) steps.add("Verify " + scenario.getExpected());

        boolean failed = false;
        int stepNo = 1;
        for (String raw : steps) {
            StepResult sr = executeStep(mcp, catalog, scenario, config, raw, stepNo, screenshotDir);
            out.getSteps().add(sr);
            if (!"PASSED".equals(sr.getStatus())) {
                failed = true;
                out.setErrorMessage(sr.getErrorMessage());
                if (!config.isContinueOnFailure()) break;
            }
            stepNo++;
        }
        out.setStatus(failed ? "FAILED" : "PASSED");
        out.setDurationMs(System.currentTimeMillis() - scenarioStart);
        return out;
    }

    private StepResult executeStep(McpClient mcp, McpToolCatalog catalog, TestScenario scenario, RunConfig config, String rawStep, int stepNo, Path screenshotDir) {
        StepResult sr = new StepResult();
        long start = System.currentTimeMillis();
        String instruction = applyData(rawStep, scenario.getData());
        sr.setStepNo(stepNo);
        sr.setInstruction(instruction);

        try {
            PlannedStep plan = planStep(mcp, catalog, instruction, scenario, config, null);
            sr.setPlanSource(plan.source());
            sr.setActionJson(plan.plan().toString());
            executeValidatedPlan(mcp, catalog, plan.plan(), sr, instruction, config, plan.preMap());
            sr.setStatus("PASSED");
            if (shouldScreenshot(config, true)) sr.setScreenshot(captureScreenshot(mcp, catalog, screenshotDir, scenario.getId(), stepNo));
        } catch (Exception first) {
            Exception finalError = first;
            for (int retry = 0; retry < config.getRetryCount(); retry++) {
                try {
                    Thread.sleep(config.getRetryDelayMs());
                    PlannedStep replan = planStep(mcp, catalog, instruction, scenario, config, finalError.getMessage());
                    sr.setPlanSource(replan.source());
                    sr.setActionJson(replan.plan().toString());
                    executeValidatedPlan(mcp, catalog, replan.plan(), sr, instruction, config, replan.preMap());
                    sr.setStatus("PASSED");
                    finalError = null;
                    break;
                } catch (Exception retryError) {
                    finalError = retryError;
                }
            }
            if (finalError != null) {
                sr.setStatus("FAILED");
                sr.setErrorMessage(finalError.getMessage());
                if (shouldScreenshot(config, false)) sr.setScreenshot(captureScreenshotQuietly(mcp, catalog, screenshotDir, scenario.getId(), stepNo));
            }
        } finally {
            sr.setDurationMs(System.currentTimeMillis() - start);
        }
        return sr;
    }

    private PlannedStep planStep(McpClient mcp, McpToolCatalog catalog, String instruction, TestScenario scenario, RunConfig config, String failure) throws Exception {
        JsonNode direct = parseDirectJson(instruction);
        if (direct != null) return new PlannedStep("EXPLICIT_JSON", normalizePlan(direct), null);

        if (isNavigate(instruction)) return new PlannedStep("DIRECT_NAVIGATE", directNavigatePlan(catalog, instruction), null);
        if (isWait(instruction)) return new PlannedStep("DIRECT_WAIT", directWaitPlan(catalog), null);

        if (!config.isUseLlm()) {
            throw new IllegalStateException("Natural-language step requires LLM planning in V3 MCP mode. Enable Use LLM or provide explicit JSON MCP calls. Step: " + instruction);
        }
        if (!llmClient.isConfigured(config)) {
            throw new IllegalStateException("LLM Base URL/token/model are required for natural-language UI action planning. Step: " + instruction);
        }

        JsonNode map = safeMap(mcp, catalog);
        String prompt = buildAgentPrompt(instruction, scenario, catalog, map, failure, config);
        JsonNode planned = mapper.readTree(llmClient.planMcpCall(prompt, config));
        return new PlannedStep("LLM_DOM_MCP", normalizePlan(planned), map);
    }

    private void executeValidatedPlan(McpClient mcp, McpToolCatalog catalog, JsonNode originalPlan, StepResult sr, String instruction, RunConfig config, JsonNode preMap) throws Exception {
        JsonNode plan = removeNoOpStart(originalPlan);
        if (plan == null || flattenCalls(plan).isEmpty()) throw new IllegalStateException("No executable MCP tool calls returned. Plan=" + originalPlan);
        String expectedIntent = expectedIntent(instruction);
        if (requiresRealAction(expectedIntent) && !containsRealAction(plan, expectedIntent)) {
            throw new IllegalStateException("Planner did not return a real MCP action for instruction='" + instruction + "'. Plan=" + originalPlan);
        }

        List<String> tools = new ArrayList<>();
        List<Map<String, Object>> argsList = new ArrayList<>();
        List<String> results = new ArrayList<>();
        boolean executedMutatingAction = false;

        for (JsonNode call : flattenCalls(plan)) {
            String toolName = firstText(call, "tool", "name", "mcpTool", "toolName");
            if (isBrowserStart(toolName)) continue;
            McpTool tool = catalog.findByName(toolName).orElseThrow(() -> new IllegalArgumentException("MCP tool not found: " + toolName));
            Map<String, Object> args = toMap(call.path("arguments"));
            JsonNode result = mcp.callTool(tool.getName(), args);
            assertMcpToolSuccess(tool.getName(), result);
            tools.add(tool.getName());
            argsList.add(args);
            results.add(compact(result.toString(), 3000));
            if (!isNoOpTool(tool.getName())) executedMutatingAction = true;
        }

        sr.setToolName(String.join(" → ", tools));
        sr.setToolArguments(mapper.writeValueAsString(argsList));
        sr.setMcpResult(String.join("\n---\n", results));

        JsonNode postMap = safeMap(mcp, catalog);
        if (isAssert(expectedIntent)) {
            assertInstruction(instruction, sr.getMcpResult(), postMap);
            sr.setEvidence("Assertion validated against Vibium MCP map/result.");
        } else if (config.isStrictEvidence() && executedMutatingAction && requiresPostEvidence(expectedIntent)) {
            String before = mapText(preMap);
            String after = mapText(postMap);
            boolean changed = preMap == null || !Objects.equals(hashText(before), hashText(after));
            if (!changed) {
                throw new IllegalStateException("MCP tool executed but page map did not change. This usually means selector/action was not effective. Step='" + instruction + "'. Tool(s)=" + String.join(",", tools));
            }
            sr.setEvidence("Post-action Vibium map changed, so the action produced visible DOM evidence.");
        } else {
            sr.setEvidence("MCP tool completed without error.");
        }
    }

    private JsonNode directNavigatePlan(McpToolCatalog catalog, String step) throws Exception {
        McpTool navigate = catalog.navigateTool().orElseThrow(() -> new IllegalArgumentException("No navigation MCP tool found"));
        String url = step.replaceFirst("(?i)^navigate\\s+to\\s+", "").trim();
        ArrayNode calls = mapper.createArrayNode();
        calls.add(simpleCall(navigate.getName(), argBySchema(navigate, "url", url, "href")));
        catalog.waitTool().ifPresent(wait -> calls.add(simpleCall(wait.getName(), Map.of())));
        ObjectNode plan = mapper.createObjectNode();
        plan.set("calls", calls);
        return plan;
    }

    private JsonNode directWaitPlan(McpToolCatalog catalog) {
        Optional<McpTool> wait = catalog.waitTool();
        ObjectNode plan = mapper.createObjectNode();
        ArrayNode calls = plan.putArray("calls");
        wait.ifPresent(tool -> calls.add(simpleCall(tool.getName(), Map.of())));
        return plan;
    }

    private String buildAgentPrompt(String instruction, TestScenario scenario, McpToolCatalog catalog, JsonNode map, String failure, RunConfig config) throws Exception {
        StringBuilder sb = new StringBuilder();
        sb.append("You are the execution brain for ITPS VIBIUM Framework. You must plan real browser actions using Vibium MCP only.\n");
        sb.append("The browser is already started. Do not call browser_start.\n");
        sb.append("Instruction: ").append(instruction).append("\n");
        sb.append("Scenario: ").append(scenario.getId()).append(" - ").append(scenario.getName()).append("\n");
        sb.append("Test data: ").append(mapper.writeValueAsString(scenario.getData())).append("\n");
        sb.append("Rules:\n");
        sb.append("- Use the current page map below to choose selectors/refs. Do not guess text selectors if that text is not in the map.\n");
        sb.append("- For icons such as search/calendar/filter/export, prefer accessible name, title, aria-label, data-testid, SVG/button ref, or nearby map reference.\n");
        sb.append("- For 'select X by search', include the full action chain in one plan: click search icon/input, fill X, click X from results, wait if needed.\n");
        sb.append("- For click/fill/select you must return at least one real action tool such as browser_click/browser_fill/browser_press/browser_select.\n");
        sb.append("- Return only minified JSON in this shape: {\"calls\":[{\"tool\":\"browser_click\",\"arguments\":{...}}],\"why\":\"...\"}.\n");
        sb.append("- If the map does not show the required element, first use a real action that reveals it, not only browser_map.\n");
        sb.append("Available MCP tools:\n").append(catalog.toPromptText()).append("\n");
        sb.append("Current Vibium MCP page map/result:\n").append(compact(map == null ? "" : map.toString(), 22000)).append("\n");
        if (failure != null) sb.append("Previous attempt failed: ").append(failure).append("\nReturn a corrected plan.\n");
        return sb.toString();
    }

    private JsonNode safeMap(McpClient mcp, McpToolCatalog catalog) {
        try {
            Optional<McpTool> mapTool = catalog.mapTool();
            if (mapTool.isEmpty()) return mapper.createObjectNode().put("note", "No browser_map/snapshot tool available");
            Map<String, Object> args = new LinkedHashMap<>();
            if (schemaContains(mapTool.get(), "selector")) args.put("selector", "body");
            JsonNode result = mcp.callTool(mapTool.get().getName(), args);
            return result;
        } catch (Exception e) {
            return mapper.createObjectNode().put("mapError", e.getMessage());
        }
    }

    private void assertInstruction(String instruction, String mcpResult, JsonNode map) {
        String expected = instruction.replaceFirst("(?i)^(verify|assert|check)\\s+", "").trim();
        expected = expected.replaceFirst("(?i)\\s+(is|should be)\\s+(displayed|visible|present).*$", "").trim();
        if (expected.isBlank()) return;
        String haystack = ((mcpResult == null ? "" : mcpResult) + "\n" + (map == null ? "" : map.toString())).toLowerCase(Locale.ROOT);
        if (!haystack.contains(expected.toLowerCase(Locale.ROOT))) {
            throw new IllegalStateException("Assertion failed. Expected Vibium map/result to contain: " + expected);
        }
    }

    private void assertMcpToolSuccess(String toolName, JsonNode result) {
        if (result == null || result.isMissingNode()) return;
        if (result.path("isError").asBoolean(false)) throw new IllegalStateException("MCP tool returned isError=true for " + toolName + ": " + compact(result.toString(), 1500));
        String text = extractText(result).toLowerCase(Locale.ROOT);
        String[] fatal = {"element not found", "not found", "timeout", "timed out", "failed", "error:", "exception", "unable to", "cannot"};
        for (String f : fatal) {
            if (text.contains(f)) throw new IllegalStateException("MCP tool result indicates failure for " + toolName + ": " + compact(text, 1500));
        }
    }

    private JsonNode removeNoOpStart(JsonNode plan) {
        ObjectNode out = mapper.createObjectNode();
        ArrayNode calls = mapper.createArrayNode();
        for (JsonNode c : flattenCalls(plan)) {
            String tool = firstText(c, "tool", "name", "mcpTool", "toolName");
            if (!isBrowserStart(tool)) calls.add(c);
        }
        out.set("calls", calls);
        if (plan != null && plan.has("assert")) out.set("assert", plan.path("assert"));
        return out;
    }

    private List<JsonNode> flattenCalls(JsonNode plan) {
        List<JsonNode> out = new ArrayList<>();
        if (plan == null || plan.isMissingNode() || plan.isNull()) return out;
        if (plan.has("calls") && plan.path("calls").isArray()) {
            for (JsonNode c : plan.path("calls")) out.add(c);
        } else {
            out.add(plan);
        }
        return out;
    }

    private boolean containsRealAction(JsonNode plan, String intent) {
        for (JsonNode c : flattenCalls(plan)) {
            String t = Optional.ofNullable(firstText(c, "tool", "name", "mcpTool", "toolName")).orElse("").toLowerCase(Locale.ROOT);
            if (isNoOpTool(t)) continue;
            if ("NAVIGATE".equals(intent) && containsAny(t, "navigate", "goto", "go", "open")) return true;
            if ("CLICK".equals(intent) && containsAny(t, "click", "tap", "press")) return true;
            if ("FILL".equals(intent) && containsAny(t, "fill", "type", "input", "write", "press")) return true;
            if ("SELECT".equals(intent) && containsAny(t, "select", "click", "press", "fill", "type")) return true;
            if ("ASSERT".equals(intent) && containsAny(t, "map", "snapshot", "text", "assert", "evaluate")) return true;
            if ("OTHER".equals(intent)) return true;
        }
        return false;
    }

    private boolean requiresRealAction(String intent) { return Set.of("NAVIGATE", "CLICK", "FILL", "SELECT", "ASSERT", "OTHER").contains(intent); }
    private boolean requiresPostEvidence(String intent) { return Set.of("CLICK", "SELECT", "FILL").contains(intent); }
    private boolean isNoOpTool(String tool) { return containsAny(tool, "start", "map", "snapshot", "screenshot", "wait") && !containsAny(tool, "click", "fill", "type", "navigate", "select", "press"); }
    private boolean isBrowserStart(String tool) { return tool != null && tool.toLowerCase(Locale.ROOT).contains("start"); }

    private String expectedIntent(String step) {
        String l = step == null ? "" : step.toLowerCase(Locale.ROOT).trim();
        if (isNavigate(step)) return "NAVIGATE";
        if (l.startsWith("click") || l.startsWith("tap") || l.startsWith("open")) return "CLICK";
        if (l.startsWith("enter") || l.startsWith("type") || l.startsWith("fill") || l.startsWith("search for")) return "FILL";
        if (l.startsWith("select") || l.contains("drop down") || l.contains("dropdown")) return "SELECT";
        if (l.startsWith("verify") || l.startsWith("assert") || l.startsWith("check")) return "ASSERT";
        if (l.startsWith("wait")) return "WAIT";
        return "OTHER";
    }

    private boolean isAssert(String intent) { return "ASSERT".equals(intent); }
    private boolean isNavigate(String step) { return step != null && step.trim().toLowerCase(Locale.ROOT).startsWith("navigate to "); }
    private boolean isWait(String step) { return step != null && step.trim().toLowerCase(Locale.ROOT).startsWith("wait"); }

    private String captureScreenshot(McpClient mcp, McpToolCatalog catalog, Path screenshotDir, String scenarioId, int stepNo) throws Exception {
        Optional<McpTool> tool = catalog.screenshotTool();
        if (tool.isEmpty()) return "";
        Files.createDirectories(screenshotDir);
        String safeScenario = scenarioId == null ? "scenario" : scenarioId.replaceAll("[^a-zA-Z0-9._-]", "_");
        String fileName = safeScenario + "_step_" + stepNo + ".png";
        Path out = screenshotDir.resolve(fileName).toAbsolutePath();
        Map<String, Object> args = new LinkedHashMap<>();
        if (schemaContains(tool.get(), "path")) args.put("path", out.toString());
        else if (schemaContains(tool.get(), "file")) args.put("file", out.toString());
        JsonNode result = mcp.callTool(tool.get().getName(), args);
        assertMcpToolSuccess(tool.get().getName(), result);
        if (Files.exists(out) && Files.size(out) > 0) return fileName;
        Optional<byte[]> png = findImageBytes(result);
        if (png.isPresent()) {
            Files.write(out, png.get());
            return fileName;
        }
        Optional<Path> pathFromResult = findPngPath(result);
        if (pathFromResult.isPresent() && Files.exists(pathFromResult.get())) {
            Files.copy(pathFromResult.get(), out, StandardCopyOption.REPLACE_EXISTING);
            return fileName;
        }
        return "";
    }

    private String captureScreenshotQuietly(McpClient mcp, McpToolCatalog catalog, Path screenshotDir, String scenarioId, int stepNo) {
        try { return captureScreenshot(mcp, catalog, screenshotDir, scenarioId, stepNo); }
        catch (Exception ignored) { return ""; }
    }

    private Optional<byte[]> findImageBytes(JsonNode node) {
        if (node == null || node.isNull() || node.isMissingNode()) return Optional.empty();
        if (node.isObject()) {
            String type = node.path("type").asText("");
            String mime = node.path("mimeType").asText("");
            String data = node.path("data").asText("");
            if ((("image".equalsIgnoreCase(type)) || mime.toLowerCase(Locale.ROOT).contains("png")) && notBlank(data)) {
                try { return Optional.of(Base64.getDecoder().decode(cleanBase64(data))); } catch (Exception ignored) {}
            }
            Iterator<Map.Entry<String, JsonNode>> it = node.fields();
            while (it.hasNext()) {
                Optional<byte[]> found = findImageBytes(it.next().getValue());
                if (found.isPresent()) return found;
            }
        } else if (node.isArray()) {
            for (JsonNode c : node) {
                Optional<byte[]> found = findImageBytes(c);
                if (found.isPresent()) return found;
            }
        } else if (node.isTextual()) {
            String text = node.asText();
            if (text.startsWith("data:image/png;base64,")) text = text.substring("data:image/png;base64,".length());
            if (text.length() > 1000 && text.matches("^[A-Za-z0-9+/=\\r\\n]+$")) {
                try { return Optional.of(Base64.getDecoder().decode(cleanBase64(text))); } catch (Exception ignored) {}
            }
        }
        return Optional.empty();
    }

    private Optional<Path> findPngPath(JsonNode node) {
        String text = extractText(node);
        Matcher m = Pattern.compile("([A-Za-z]:\\\\[^\\n\"']+?\\.png)").matcher(text);
        if (m.find()) return Optional.of(Path.of(m.group(1)));
        return Optional.empty();
    }

    private String cleanBase64(String s) { return s == null ? "" : s.replace("data:image/png;base64,", "").replaceAll("\\s+", ""); }

    private Map<String, Object> toMap(JsonNode n) {
        if (n == null || n.isMissingNode() || n.isNull()) return Map.of();
        return mapper.convertValue(n, new TypeReference<Map<String, Object>>() {});
    }

    private Map<String, Object> argBySchema(McpTool tool, String primary, String value, String fallback) {
        Map<String, Object> args = new LinkedHashMap<>();
        args.put(schemaContains(tool, primary) ? primary : fallback, value);
        return args;
    }

    private ObjectNode simpleCall(String tool, Map<String, Object> args) {
        ObjectNode c = mapper.createObjectNode();
        c.put("tool", tool);
        c.set("arguments", mapper.valueToTree(args == null ? Map.of() : args));
        return c;
    }

    private JsonNode normalizePlan(JsonNode plan) {
        if (plan == null) return mapper.createObjectNode();
        if (plan.isArray()) {
            ObjectNode p = mapper.createObjectNode();
            p.set("calls", plan);
            return p;
        }
        if (plan.has("tool") || plan.has("calls") || plan.has("name") || plan.has("mcpTool")) return plan;
        return plan;
    }

    private JsonNode parseDirectJson(String step) throws Exception {
        String t = step == null ? "" : step.trim();
        if (!t.startsWith("{") && !t.startsWith("[")) return null;
        return mapper.readTree(t);
    }

    private Optional<McpTool> mapTool(McpToolCatalog catalog) { return catalog.mapTool(); }

    private String applyData(String input, Map<String, Object> data) {
        if (input == null || data == null) return input;
        String out = input;
        for (Map.Entry<String, Object> e : data.entrySet()) {
            String value = e.getValue() == null ? "" : String.valueOf(e.getValue());
            out = out.replace("{{" + e.getKey() + "}}", value);
            out = out.replace("${" + e.getKey() + "}", value);
        }
        return out;
    }

    private List<String> splitArgs(String args) {
        if (args == null || args.isBlank()) return List.of();
        List<String> out = new ArrayList<>();
        Matcher m = Pattern.compile("([^\\s\"]+)|\"([^\"]*)\"").matcher(args);
        while (m.find()) out.add(m.group(1) != null ? m.group(1) : m.group(2));
        return out;
    }

    private String resolveUrl(String url, String base) {
        if (!notBlank(url)) return "";
        String t = url.trim();
        if (t.startsWith("http://") || t.startsWith("https://")) return t;
        if (!notBlank(base)) return t;
        if (base.endsWith("/") && t.startsWith("/")) return base.substring(0, base.length() - 1) + t;
        if (!base.endsWith("/") && !t.startsWith("/")) return base + "/" + t;
        return base + t;
    }

    private boolean shouldScreenshot(RunConfig config, boolean pass) {
        String mode = config.getScreenshotMode() == null ? "ALL" : config.getScreenshotMode();
        if ("NONE".equalsIgnoreCase(mode)) return false;
        if ("ALL".equalsIgnoreCase(mode)) return true;
        return !pass;
    }

    private String firstText(JsonNode node, String... fields) {
        if (node == null) return null;
        for (String f : fields) {
            JsonNode v = node.path(f);
            if (v.isTextual() && !v.asText().isBlank()) return v.asText();
        }
        return null;
    }

    private boolean schemaContains(McpTool tool, String term) {
        return tool != null && tool.getInputSchema() != null && tool.getInputSchema().toString().toLowerCase(Locale.ROOT).contains(term.toLowerCase(Locale.ROOT));
    }

    private boolean containsAny(String text, String... terms) {
        if (text == null) return false;
        String l = text.toLowerCase(Locale.ROOT);
        for (String t : terms) if (l.contains(t.toLowerCase(Locale.ROOT))) return true;
        return false;
    }

    private boolean notBlank(String value) { return value != null && !value.trim().isEmpty(); }

    private String compact(String text, int max) {
        if (text == null) return "";
        String s = text.replaceAll("\\s+", " ").trim();
        return s.length() <= max ? s : s.substring(0, max) + "...";
    }

    private String extractText(JsonNode node) {
        if (node == null) return "";
        if (node.isTextual()) return node.asText();
        if (node.isNumber() || node.isBoolean()) return node.asText();
        StringBuilder sb = new StringBuilder();
        if (node.isObject()) {
            node.fields().forEachRemaining(e -> sb.append(' ').append(e.getKey()).append(' ').append(extractText(e.getValue())));
        } else if (node.isArray()) {
            for (JsonNode c : node) sb.append(' ').append(extractText(c));
        }
        return sb.toString();
    }

    private String mapText(JsonNode node) { return compact(extractText(node), 25000); }
    private String hashText(String text) { return Integer.toHexString(Objects.hashCode(text)); }

    private void writeToolsManifest(Path runDir, List<McpTool> tools) {
        try {
            Files.createDirectories(runDir);
            Files.writeString(runDir.resolve("mcp-tools.json"), mapper.writerWithDefaultPrettyPrinter().writeValueAsString(tools), StandardCharsets.UTF_8);
        } catch (Exception ignored) {}
    }

    private record PlannedStep(String source, JsonNode plan, JsonNode preMap) {}
}
