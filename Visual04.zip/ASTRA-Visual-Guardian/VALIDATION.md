# ASTRA Visual Guardian — coverage and exploration validation

## Scope and build

This independent Java application is updated from `ASTRA_Visual_Guardian_Recovery.zip`. Eliya is a read-only architectural reference; neither its source nor its runtime is required. No new external Java runtime dependency was added. The JAR was rebuilt with `javac --release 17` (JDK 21 in the validation environment); class major version 61. JavaScript syntax validation, JAR archive validation and ZIP verification were performed. The package includes complete Java and frontend source, launch/build scripts and the test fixtures.

## Implemented changes

| Area | Result |
|---|---|
| Exploration capacity | UI starting budgets 500 states, 2,000 paths, depth 12; optional adaptive growth within 10,000 states, 20,000 paths and depth 30. Existing run budgets can be revised on resume. |
| Action classification | Navigation semantics distinguish payment module links from transaction actions; mutating controls remain restricted. Explicitly approved search-like submissions and exact read-only API paths supported. |
| Recovery | Re-evaluate eligible skipped actions using saved DOM evidence, retain prior screenshots and action journal, deduplicate completed and pending paths; increase bounded depth as necessary. |
| Model intelligence | User-selected Agent model ranks candidates and can advise on uncertain actions, only with data-sharing authorization. Advice never overrides policy. |
| Coverage | Group by first navigation action; show captured, pending, failed, duplicate, review and exclusion counts; reconcile optional expected exact route list. |
| Quality gate | REVIEW_REQUIRED status until exclusions reviewed; approval checks pending paths, failures, expected routes, screenshot hashes and DOM/path evidence. Exclusions never count as passed tests. |
| Browser | New visible-browser captures attempt native viewport fitting, lock dimensions and device scale; existing runs preserve their prior geometry. Bounded vertical scroll actions are captured and replayable. |
| Reports | Grouped exception review and coverage tables, readable journey descriptions, pending paths, screenshot evidence and Excel exception rows. |
| Replay | Preserve baseline capture geometry; explicit opt-in to reuse approved read-only path/label settings for equivalent target scope. |

## Validation method

The automated browser integration uses a **mock CDP browser protocol** and deterministic local model fixture. This verifies the actual application orchestration, HTTP API, persistence, package handling, comparison and report generation, not a real corporate browser. The JS locator and scroll checks execute the generated scripts against small synthetic DOM fixtures. The filesystem check provokes a real transient replacement error on Linux, not a Windows file lock. The final JAR is tested by the focused coverage lifecycle fixture; broader regression tests were also run on earlier candidates of this update. Detailed logs distinguish these runs.

## Final-artifact checks

- `coverage-unit.log`: 20 passed, including payment navigation, mutation restrictions, approved search, adaptive budgets and depth, expected route reconciliation, legacy skipped-action recovery, explicit exclusion review, scroll matching and execution.
- `coverage-flow.log`: 6 passed on the final JAR: partial capture, preserved screenshot and recovered legacy skip, review gate, explicit exclusion review, HTML report, replay with approved read settings and fixed viewport.
- `checkpoint-coverage.log`: 8 passed (persistent journal, deduplication, issue cleanup, filesystem retry).
- `locator-coverage.log`: 9 passed (Java locator recovery and synthetic DOM action tests).
- `coverage-resume-final.log`: 3 passed on the final build (legacy queue deduplication, preserved screenshots, journal continuity).
- Total final-artifact targeted checks: 46 passed, with zero Java compilation errors. No claim is made that all possible application flows are covered.

## Broader regression

`coverage-integration.log`: all 34 checks passed on an earlier candidate of this update. It exercised model discovery and Vision payload, baseline capture and approval review, portable ZIP integrity and import, unchanged-app replay, injected regressions, selective reruns, offline comparison, HTML/Excel, authentication waiting, manual handover, stop and resume. The final build additionally introduces explicit REVIEW_REQUIRED status and approved read-only policy reuse, covered by the final focused tests. Older Recovery release logs are retained only as historical evidence, not added to the final check count.

## Release qualification and remaining limits

The application is a launchable, locally validated functional implementation, **not production-certified**. A previous real Chromium navigation attempt was blocked by administrator policy (`net::ERR_BLOCKED_BY_ADMINISTRATOR`), documented in `real-browser-blocked.log`; corporate Chrome/Edge, native SSO/certificate/PIN, actual Windows DPI fitting and the deployed Qwen/Vision endpoint still require local verification. The model classifies uncertain actions for review; it does not autonomously approve data-changing requests or provide a generalized live question/approval queue. Nested scrolling is bounded and does not guarantee coverage of virtualized content, iframes, shadow DOM or canvas. Existing screenshots retain their original geometry. If corrected viewport sizing or new scroll discovery is required on already-captured pages, create a separate fresh baseline; never mix screenshot geometries. Some old skipped entries lacking a state or path reference may still need manual review. Exact expected routes are optional; a complete business-flow inventory must be supplied and independently verified. No enterprise-scale capacity or archive-size expansion has been demonstrated; use scoped suites for large evidence sets.

## Upgrade

Back up `guardian-data`; stop the previous installation and close editors holding run.json. Extract into a separate folder; copy the saved data folder or point the launcher at it using `--data`. Existing data formats are retained. For the incomplete BMS capture, use Resume / recover coverage, choose initial budgets (e.g. 2,000 states, 10,000 paths, depth 12), enable adaptive growth, and enter only application-owner-approved read-only API paths and labels. Authorize model data only when allowed. Authenticate again if required. Review remaining exclusions before approving the baseline. Original captured screenshots remain unchanged, and prerequisite navigation may be repeated to re-establish browser state.
