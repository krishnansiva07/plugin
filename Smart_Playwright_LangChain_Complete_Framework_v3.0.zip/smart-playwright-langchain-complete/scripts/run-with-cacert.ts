import { existsSync, readFileSync } from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';

const root = path.resolve(__dirname, '..');
const candidates = [
  'cacert', 'cacert.pem', 'cacerts', 'corporate-ca.pem', 'corporate-ca.crt', 'corporate-ca.cer'
].map(name => path.join(root, 'certificates', name));
const certificate = candidates.find(existsSync);

const mode = process.argv[2] ?? 'test';
const env = { ...process.env };
if (certificate) {
  const content = readFileSync(certificate, 'utf8');
  if (!content.includes('-----BEGIN CERTIFICATE-----')) {
    console.error(`[CERTIFICATE] ${certificate} is not PEM text. It must contain -----BEGIN CERTIFICATE-----.`);
    process.exit(2);
  }
  env.NODE_EXTRA_CA_CERTS = certificate;
  console.log(`[CERTIFICATE] Using corporate CA: ${certificate}`);
} else {
  console.log('[CERTIFICATE] No cacert file found. Continuing with the default Node trust store.');
}

const playwrightCli = path.join(root, 'node_modules', '@playwright', 'test', 'cli.js');
const preflight = path.join(root, 'scripts', 'preflight.ts');
let command: string;
let args: string[];
if (mode === 'preflight') {
  command = process.execPath;
  args = [path.join(root, 'node_modules', 'tsx', 'dist', 'cli.mjs'), preflight];
} else {
  command = process.execPath;
  args = [playwrightCli, 'test'];
  if (mode === 'debug') args.push('--debug');
}
const result = spawnSync(command, args, { cwd: root, env, stdio: 'inherit', windowsHide: false });
if (result.error) {
  console.error(result.error);
  process.exit(1);
}
process.exit(result.status ?? 1);
