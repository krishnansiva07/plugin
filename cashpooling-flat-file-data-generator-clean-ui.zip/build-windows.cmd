@echo off
setlocal
cd /d "%~dp0backend"
echo Building one executable JAR with the UI included...
call mvn clean test package
if errorlevel 1 exit /b 1
echo.
echo Build completed successfully.
echo JAR: backend\target\cashpooling-flat-file-generator.jar
endlocal
