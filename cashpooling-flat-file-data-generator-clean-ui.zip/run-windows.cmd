@echo off
setlocal
cd /d "%~dp0"
if not exist "backend\target\cashpooling-flat-file-generator.jar" (
  echo JAR not found. Run build-windows.cmd first.
  pause
  exit /b 1
)
start "" http://localhost:8080
java -jar "backend\target\cashpooling-flat-file-generator.jar"
endlocal
