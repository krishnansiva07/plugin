# CASHPOOLING FLAT FILE DATA GENERATOR

The web UI is packaged inside the Spring Boot executable JAR. The frontend and backend do not need to be started separately.

## Requirements

- Java 17
- Maven 3.9 or later

## Build on Windows

Run:

```text
build-windows.cmd
```

This creates:

```text
backend\target\cashpooling-flat-file-generator.jar
```

## Start

Run:

```text
run-windows.cmd
```

The browser opens at:

```text
http://localhost:8080
```

You can also run the JAR directly:

```text
java -jar backend\target\cashpooling-flat-file-generator.jar
```

The application serves `index.html`, `app.js`, and `styles.css` directly from the JAR.
