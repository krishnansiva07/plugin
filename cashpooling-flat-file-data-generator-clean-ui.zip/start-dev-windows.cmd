@echo off
cd /d "%~dp0"
start "Cashpooling Backend" cmd /k "cd backend && mvn spring-boot:run"
start "Cashpooling Frontend" cmd /k "cd frontend && npm install && npm run dev"
