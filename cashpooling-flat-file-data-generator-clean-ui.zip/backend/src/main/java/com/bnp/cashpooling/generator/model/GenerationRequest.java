package com.bnp.cashpooling.generator.model;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public class GenerationRequest {
    @NotBlank
    private String fileName = "CASHPOOLING_FILE";
    @Min(1)
    @Max(1000000)
    private int recordCount = 1;
    @NotNull
    private String lineSeparator = "CRLF";
    @NotNull
    private String encoding = "UTF-8";
    @Valid
    private SectionConfig header = new SectionConfig();
    @Valid
    @NotNull
    private SectionConfig detail = new SectionConfig();
    @Valid
    private SectionConfig footer = new SectionConfig();

    public String getFileName() { return fileName; }
    public void setFileName(String fileName) { this.fileName = fileName; }
    public int getRecordCount() { return recordCount; }
    public void setRecordCount(int recordCount) { this.recordCount = recordCount; }
    public String getLineSeparator() { return lineSeparator; }
    public void setLineSeparator(String lineSeparator) { this.lineSeparator = lineSeparator; }
    public String getEncoding() { return encoding; }
    public void setEncoding(String encoding) { this.encoding = encoding; }
    public SectionConfig getHeader() { return header; }
    public void setHeader(SectionConfig header) { this.header = header; }
    public SectionConfig getDetail() { return detail; }
    public void setDetail(SectionConfig detail) { this.detail = detail; }
    public SectionConfig getFooter() { return footer; }
    public void setFooter(SectionConfig footer) { this.footer = footer; }
}
