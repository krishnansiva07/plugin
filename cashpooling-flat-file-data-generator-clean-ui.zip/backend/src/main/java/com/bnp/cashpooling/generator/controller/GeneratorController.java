package com.bnp.cashpooling.generator.controller;

import com.bnp.cashpooling.generator.exception.InvalidConfigurationException;
import com.bnp.cashpooling.generator.model.*;
import com.bnp.cashpooling.generator.service.FlatFileGeneratorService;
import com.bnp.cashpooling.generator.service.LlmService;
import jakarta.validation.Valid;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

import java.nio.charset.Charset;
import java.util.Map;

@RestController
@RequestMapping("/api")
public class GeneratorController {
    private final FlatFileGeneratorService generatorService;
    private final LlmService llmService;

    public GeneratorController(FlatFileGeneratorService generatorService, LlmService llmService) {
        this.generatorService = generatorService;
        this.llmService = llmService;
    }

    @PostMapping("/validate")
    public ValidationResponse validate(@Valid @RequestBody GenerationRequest request) {
        var errors = generatorService.validate(request);
        return new ValidationResponse(errors.isEmpty(), errors, generatorService.preview(request, 3));
    }

    @PostMapping("/generate")
    public ResponseEntity<byte[]> generate(@Valid @RequestBody GenerationRequest request) {
        byte[] content = generatorService.generate(request);
        String safeName = request.getFileName().replaceAll("[^A-Za-z0-9._-]", "_");
        MediaType mediaType = new MediaType("text", "plain", Charset.forName(request.getEncoding()));
        return ResponseEntity.ok()
            .contentType(mediaType)
            .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + safeName + "\"")
            .contentLength(content.length)
            .body(content);
    }

    @PostMapping("/llm/interpret")
    public GenerationRequest interpret(@Valid @RequestBody LlmInterpretRequest request) throws Exception {
        GenerationRequest result = llmService.interpret(request);
        var errors = generatorService.validate(result);
        if (!errors.isEmpty()) throw new InvalidConfigurationException(errors);
        return result;
    }

    @GetMapping("/llm/defaults")
    public Map<String, String> defaults() { return llmService.defaults(); }

    @ExceptionHandler(InvalidConfigurationException.class)
    public ResponseEntity<Map<String, Object>> handleInvalid(InvalidConfigurationException ex) {
        return ResponseEntity.badRequest().body(Map.of("message", ex.getMessage(), "errors", ex.getErrors()));
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<Map<String, Object>> handleGeneral(Exception ex) {
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(Map.of("message", ex.getMessage() == null ? "Request failed" : ex.getMessage()));
    }
}
