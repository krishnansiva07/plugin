package com.bnp.cashpooling.generator;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CashpoolingFlatFileGeneratorApplication {
    public static void main(String[] args) {
        SpringApplication.run(CashpoolingFlatFileGeneratorApplication.class, args);
    }
}
