package com.bnp.cashpooling.generator.model;

public enum ConditionalAction {
    KEEP_GENERATED,
    EMPTY,
    STATIC_VALUE,
    COPY_FIELD,
    POSSIBLE_VALUES
}
