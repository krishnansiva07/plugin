package com.bnp.cashpooling.generator.model;

import jakarta.validation.constraints.NotBlank;

public class LlmInterpretRequest {
    @NotBlank
    private String token;
    @NotBlank
    private String prompt;
    private String baseUrl;
    private String modelName;

    public String getToken() { return token; }
    public void setToken(String token) { this.token = token; }
    public String getPrompt() { return prompt; }
    public void setPrompt(String prompt) { this.prompt = prompt; }
    public String getBaseUrl() { return baseUrl; }
    public void setBaseUrl(String baseUrl) { this.baseUrl = baseUrl; }
    public String getModelName() { return modelName; }
    public void setModelName(String modelName) { this.modelName = modelName; }
}
