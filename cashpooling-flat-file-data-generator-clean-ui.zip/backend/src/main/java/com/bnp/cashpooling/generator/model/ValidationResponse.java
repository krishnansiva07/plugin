package com.bnp.cashpooling.generator.model;

import java.util.List;

public record ValidationResponse(boolean valid, List<String> errors, String preview) {}
