package com.bnp.cashpooling.generator.model;

public enum RuleType {
    STATIC,
    EMPTY,
    RANDOM_NUMERIC,
    RANDOM_ALPHA,
    RANDOM_ALPHANUMERIC,
    SEQUENCE,
    DATE_TIME,
    RANDOM_DATE_TIME,
    DATE_SEQUENCE,
    DEPENDENT_DATE,
    RECORD_COUNT,
    COPY_FIELD,
    SUBSTRING,
    CONDITIONAL,
    EXPRESSION
}
