package com.bnp.cashpooling.generator.model;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

import java.util.LinkedHashMap;
import java.util.Map;

public class FieldConfig {
    @NotBlank
    private String name;
    @Min(1)
    private int width = 1;
    @NotNull
    private RuleType ruleType = RuleType.STATIC;
    private String value = "";
    private String prefix = "";
    private String suffix = "";
    private String format = "yyyyMMddHHmmss";
    private String startDate;
    private String endDate;
    private String inputDateFormat = "yyyy-MM-dd\'T\'HH:mm:ss";
    private Long dateStep = 1L;
    private String dateStepUnit = "DAYS";
    private Long dateOffset = 0L;
    private String dateOffsetUnit = "DAYS";
    private Integer randomLength;
    private Long sequenceStart = 1L;
    private Long sequenceStep = 1L;
    private String sourceField;
    private Integer substringStart;
    private Integer substringLength;
    private String conditionField;
    private Map<String, String> conditionMap = new LinkedHashMap<>();
    private String defaultValue = "";
    @NotNull
    private Alignment alignment = Alignment.LEFT;
    private String padCharacter = " ";
    private boolean truncate;
    // Optional comma-separated values. When supplied, one value is selected for each record.
    private String possibleValues = "";
    // Optional condition overlay. It is evaluated after the field's normal generation rule.
    private boolean conditionalEnabled;
    private String conditionalSourceField = "";
    private String conditionalOperator = "EQUALS";
    private String conditionalCompareValue = "";
    private ConditionalAction conditionalTrueAction = ConditionalAction.KEEP_GENERATED;
    private String conditionalTrueValue = "";
    private ConditionalAction conditionalFalseAction = ConditionalAction.KEEP_GENERATED;
    private String conditionalFalseValue = "";

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public int getWidth() { return width; }
    public void setWidth(int width) { this.width = width; }
    public RuleType getRuleType() { return ruleType; }
    public void setRuleType(RuleType ruleType) { this.ruleType = ruleType; }
    public String getValue() { return value; }
    public void setValue(String value) { this.value = value; }
    public String getPrefix() { return prefix; }
    public void setPrefix(String prefix) { this.prefix = prefix; }
    public String getSuffix() { return suffix; }
    public void setSuffix(String suffix) { this.suffix = suffix; }
    public String getFormat() { return format; }
    public void setFormat(String format) { this.format = format; }
    public String getStartDate() { return startDate; }
    public void setStartDate(String startDate) { this.startDate = startDate; }
    public String getEndDate() { return endDate; }
    public void setEndDate(String endDate) { this.endDate = endDate; }
    public String getInputDateFormat() { return inputDateFormat; }
    public void setInputDateFormat(String inputDateFormat) { this.inputDateFormat = inputDateFormat; }
    public Long getDateStep() { return dateStep; }
    public void setDateStep(Long dateStep) { this.dateStep = dateStep; }
    public String getDateStepUnit() { return dateStepUnit; }
    public void setDateStepUnit(String dateStepUnit) { this.dateStepUnit = dateStepUnit; }
    public Long getDateOffset() { return dateOffset; }
    public void setDateOffset(Long dateOffset) { this.dateOffset = dateOffset; }
    public String getDateOffsetUnit() { return dateOffsetUnit; }
    public void setDateOffsetUnit(String dateOffsetUnit) { this.dateOffsetUnit = dateOffsetUnit; }
    public Integer getRandomLength() { return randomLength; }
    public void setRandomLength(Integer randomLength) { this.randomLength = randomLength; }
    public Long getSequenceStart() { return sequenceStart; }
    public void setSequenceStart(Long sequenceStart) { this.sequenceStart = sequenceStart; }
    public Long getSequenceStep() { return sequenceStep; }
    public void setSequenceStep(Long sequenceStep) { this.sequenceStep = sequenceStep; }
    public String getSourceField() { return sourceField; }
    public void setSourceField(String sourceField) { this.sourceField = sourceField; }
    public Integer getSubstringStart() { return substringStart; }
    public void setSubstringStart(Integer substringStart) { this.substringStart = substringStart; }
    public Integer getSubstringLength() { return substringLength; }
    public void setSubstringLength(Integer substringLength) { this.substringLength = substringLength; }
    public String getConditionField() { return conditionField; }
    public void setConditionField(String conditionField) { this.conditionField = conditionField; }
    public Map<String, String> getConditionMap() { return conditionMap; }
    public void setConditionMap(Map<String, String> conditionMap) { this.conditionMap = conditionMap == null ? new LinkedHashMap<>() : conditionMap; }
    public String getDefaultValue() { return defaultValue; }
    public void setDefaultValue(String defaultValue) { this.defaultValue = defaultValue; }
    public Alignment getAlignment() { return alignment; }
    public void setAlignment(Alignment alignment) { this.alignment = alignment; }
    public String getPadCharacter() { return padCharacter; }
    public void setPadCharacter(String padCharacter) { this.padCharacter = padCharacter; }
    public boolean isTruncate() { return truncate; }
    public void setTruncate(boolean truncate) { this.truncate = truncate; }
    public String getPossibleValues() { return possibleValues; }
    public void setPossibleValues(String possibleValues) { this.possibleValues = possibleValues; }
    public boolean isConditionalEnabled() { return conditionalEnabled; }
    public void setConditionalEnabled(boolean conditionalEnabled) { this.conditionalEnabled = conditionalEnabled; }
    public String getConditionalSourceField() { return conditionalSourceField; }
    public void setConditionalSourceField(String conditionalSourceField) { this.conditionalSourceField = conditionalSourceField; }
    public String getConditionalOperator() { return conditionalOperator; }
    public void setConditionalOperator(String conditionalOperator) { this.conditionalOperator = conditionalOperator; }
    public String getConditionalCompareValue() { return conditionalCompareValue; }
    public void setConditionalCompareValue(String conditionalCompareValue) { this.conditionalCompareValue = conditionalCompareValue; }
    public ConditionalAction getConditionalTrueAction() { return conditionalTrueAction; }
    public void setConditionalTrueAction(ConditionalAction conditionalTrueAction) { this.conditionalTrueAction = conditionalTrueAction; }
    public String getConditionalTrueValue() { return conditionalTrueValue; }
    public void setConditionalTrueValue(String conditionalTrueValue) { this.conditionalTrueValue = conditionalTrueValue; }
    public ConditionalAction getConditionalFalseAction() { return conditionalFalseAction; }
    public void setConditionalFalseAction(ConditionalAction conditionalFalseAction) { this.conditionalFalseAction = conditionalFalseAction; }
    public String getConditionalFalseValue() { return conditionalFalseValue; }
    public void setConditionalFalseValue(String conditionalFalseValue) { this.conditionalFalseValue = conditionalFalseValue; }
}
