package com.bnp.cashpooling.generator.model;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Min;

import java.util.ArrayList;
import java.util.List;

public class SectionConfig {
    private boolean enabled = true;
    @Min(1)
    private int lineWidth = 1;
    @Valid
    private List<FieldConfig> fields = new ArrayList<>();

    public boolean isEnabled() { return enabled; }
    public void setEnabled(boolean enabled) { this.enabled = enabled; }
    public int getLineWidth() { return lineWidth; }
    public void setLineWidth(int lineWidth) { this.lineWidth = lineWidth; }
    public List<FieldConfig> getFields() { return fields; }
    public void setFields(List<FieldConfig> fields) { this.fields = fields == null ? new ArrayList<>() : fields; }
}
