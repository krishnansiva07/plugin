package com.bnp.cashpooling.generator.model;

public enum Alignment {
    LEFT, RIGHT
}
