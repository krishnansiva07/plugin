package com.bnp.cashpooling.generator.service;

import com.bnp.cashpooling.generator.exception.InvalidConfigurationException;
import com.bnp.cashpooling.generator.model.*;
import org.springframework.stereotype.Service;

import java.nio.charset.Charset;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.temporal.ChronoUnit;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Service
public class FlatFileGeneratorService {
    private static final String NUMERIC = "0123456789";
    private static final String ALPHA = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    private static final String ALPHANUMERIC = ALPHA + NUMERIC;
    private static final Pattern PLACEHOLDER = Pattern.compile("\\$\\{([^{}]+)}");
    private final Random random = new Random();

    public List<String> validate(GenerationRequest request) {
        List<String> errors = new ArrayList<>();
        if (request.getFileName() == null || request.getFileName().isBlank()) errors.add("File name is required.");
        if (request.getFileName() != null && (request.getFileName().contains("/") || request.getFileName().contains("\\"))) errors.add("File name cannot contain path separators.");
        if (request.getRecordCount() < 1) errors.add("Record count must be at least 1.");
        try { Charset.forName(request.getEncoding()); } catch (Exception e) { errors.add("Unsupported encoding: " + request.getEncoding()); }
        validateSection("Header", request.getHeader(), errors);
        validateSection("Detail", request.getDetail(), errors);
        validateSection("Footer", request.getFooter(), errors);
        if (request.getDetail() == null || !request.getDetail().isEnabled()) errors.add("Detail section must be enabled.");
        return errors;
    }

    private void validateSection(String sectionName, SectionConfig section, List<String> errors) {
        if (section == null || !section.isEnabled()) return;
        if (section.getLineWidth() < 1) errors.add(sectionName + " line width must be at least 1.");
        if (section.getFields() == null || section.getFields().isEmpty()) errors.add(sectionName + " must have at least one field.");
        if (section.getFields() == null) return;
        int total = 0;
        Set<String> names = new HashSet<>();
        Set<String> availableEarlier = new HashSet<>();
        for (int i = 0; i < section.getFields().size(); i++) {
            FieldConfig field = section.getFields().get(i);
            String label = sectionName + " field " + (i + 1);
            if (field.getName() == null || field.getName().isBlank()) errors.add(label + " name is required.");
            else if (!names.add(field.getName())) errors.add(sectionName + " contains duplicate field name: " + field.getName());
            if (field.getWidth() < 1) errors.add(label + " width must be at least 1.");
            total += Math.max(field.getWidth(), 0);
            if (field.getPadCharacter() == null || field.getPadCharacter().length() != 1) errors.add(label + " pad character must contain exactly one character.");

            RuleType type = field.getRuleType();
            if (EnumSet.of(RuleType.DATE_TIME, RuleType.RANDOM_DATE_TIME, RuleType.DATE_SEQUENCE, RuleType.DEPENDENT_DATE).contains(type)) {
                validateDateFormat(label + " output", field.getFormat(), errors);
            }
            if (type == RuleType.RANDOM_DATE_TIME || type == RuleType.DATE_SEQUENCE) {
                validateDateRangeField(label, field, type == RuleType.RANDOM_DATE_TIME, errors);
            }
            if (type == RuleType.DEPENDENT_DATE) {
                validateDateFormat(label + " source", field.getInputDateFormat(), errors);
                if (field.getSourceField() == null || !availableEarlier.contains(field.getSourceField())) errors.add(label + " must reference an earlier date field.");
            }
            if (type == RuleType.COPY_FIELD || type == RuleType.SUBSTRING) {
                if (field.getSourceField() == null || !availableEarlier.contains(field.getSourceField())) errors.add(label + " must reference an earlier field in the same section.");
            }
            if (type == RuleType.CONDITIONAL) {
                if (field.getConditionField() == null || !availableEarlier.contains(field.getConditionField())) errors.add(label + " condition must reference an earlier field in the same section.");
            }
            if (type == RuleType.RECORD_COUNT && !sectionName.equals("Footer")) errors.add(label + " RECORD_COUNT is intended for the footer.");
            if (field.isConditionalEnabled()) {
                if (field.getConditionalSourceField() == null || !availableEarlier.contains(field.getConditionalSourceField())) {
                    errors.add(label + " conditional rule must reference an earlier field in the same section.");
                }
                try { ConditionalAction.valueOf(String.valueOf(field.getConditionalTrueAction())); } catch (Exception e) { errors.add(label + " has invalid true conditional action."); }
                try { ConditionalAction.valueOf(String.valueOf(field.getConditionalFalseAction())); } catch (Exception e) { errors.add(label + " has invalid false conditional action."); }
            }
            if (field.getName() != null) availableEarlier.add(field.getName());
        }
        if (total > section.getLineWidth()) errors.add(sectionName + " fields total width " + total + " exceeds line width " + section.getLineWidth() + ".");
    }

    private void validateDateRangeField(String label, FieldConfig field, boolean endRequired, List<String> errors) {
        validateDateFormat(label + " input", field.getInputDateFormat(), errors);
        try {
            LocalDateTime start = parseDateTime(field.getStartDate(), field.getInputDateFormat());
            if (endRequired) {
                LocalDateTime end = parseDateTime(field.getEndDate(), field.getInputDateFormat());
                if (end.isBefore(start)) errors.add(label + " end date/time must be on or after start date/time.");
            }
        } catch (Exception e) {
            errors.add(label + " has an invalid start/end date or input format.");
        }
    }

    private void validateDateFormat(String label, String format, List<String> errors) {
        try { DateTimeFormatter.ofPattern(blankDefault(format, "yyyyMMddHHmmss")); }
        catch (IllegalArgumentException e) { errors.add(label + " has invalid date/time format: " + format); }
    }

    public byte[] generate(GenerationRequest request) {
        List<String> errors = validate(request);
        if (!errors.isEmpty()) throw new InvalidConfigurationException(errors);
        String separator = "LF".equalsIgnoreCase(request.getLineSeparator()) ? "\n" : "\r\n";
        StringBuilder output = new StringBuilder();
        if (request.getHeader() != null && request.getHeader().isEnabled()) output.append(buildLine(request.getHeader(), 0, request.getRecordCount())).append(separator);
        for (int row = 1; row <= request.getRecordCount(); row++) output.append(buildLine(request.getDetail(), row, request.getRecordCount())).append(separator);
        if (request.getFooter() != null && request.getFooter().isEnabled()) output.append(buildLine(request.getFooter(), request.getRecordCount(), request.getRecordCount()));
        else if (output.length() >= separator.length()) output.setLength(output.length() - separator.length());
        return output.toString().getBytes(Charset.forName(request.getEncoding()));
    }

    public String preview(GenerationRequest request, int maxDetails) {
        List<String> errors = validate(request);
        if (!errors.isEmpty()) return "Validation errors:\n- " + String.join("\n- ", errors);
        StringBuilder result = new StringBuilder();
        if (request.getHeader() != null && request.getHeader().isEnabled()) result.append(buildLine(request.getHeader(), 0, request.getRecordCount())).append("\n");
        int count = Math.min(request.getRecordCount(), Math.max(1, maxDetails));
        for (int row = 1; row <= count; row++) result.append(buildLine(request.getDetail(), row, request.getRecordCount())).append("\n");
        if (request.getRecordCount() > count) result.append("... ").append(request.getRecordCount() - count).append(" more detail records ...\n");
        if (request.getFooter() != null && request.getFooter().isEnabled()) result.append(buildLine(request.getFooter(), request.getRecordCount(), request.getRecordCount()));
        return result.toString();
    }

    private String buildLine(SectionConfig section, int rowNumber, int recordCount) {
        Map<String, String> values = new LinkedHashMap<>();
        StringBuilder line = new StringBuilder();
        for (FieldConfig field : section.getFields()) {
            String raw = evaluate(field, values, rowNumber, recordCount);
            line.append(fit(raw, field));
            values.put(field.getName(), nullToEmpty(raw));
        }
        if (line.length() < section.getLineWidth()) line.append(" ".repeat(section.getLineWidth() - line.length()));
        if (line.length() != section.getLineWidth()) throw new IllegalStateException("Generated line width mismatch.");
        return line.toString();
    }

    private String evaluate(FieldConfig field, Map<String, String> values, int rowNumber, int recordCount) {
        String core = switch (field.getRuleType()) {
            case STATIC -> nullToEmpty(field.getValue());
            case EMPTY -> "";
            case RANDOM_NUMERIC -> randomChars(NUMERIC, effectiveLength(field));
            case RANDOM_ALPHA -> randomChars(ALPHA, effectiveLength(field));
            case RANDOM_ALPHANUMERIC -> randomChars(ALPHANUMERIC, effectiveLength(field));
            case SEQUENCE -> String.valueOf(nullTo(field.getSequenceStart(), 1L) + (long) Math.max(0, rowNumber - 1) * nullTo(field.getSequenceStep(), 1L));
            case DATE_TIME -> LocalDateTime.now().format(outputFormatter(field));
            case RANDOM_DATE_TIME -> randomDateTime(field).format(outputFormatter(field));
            case DATE_SEQUENCE -> steppedDateTime(field, rowNumber).format(outputFormatter(field));
            case DEPENDENT_DATE -> offsetDateTime(field, values).format(outputFormatter(field));
            case RECORD_COUNT -> String.valueOf(recordCount);
            case COPY_FIELD -> nullToEmpty(values.get(field.getSourceField()));
            case SUBSTRING -> substring(nullToEmpty(values.get(field.getSourceField())), field.getSubstringStart(), field.getSubstringLength());
            case CONDITIONAL -> field.getConditionMap().getOrDefault(nullToEmpty(values.get(field.getConditionField())), nullToEmpty(field.getDefaultValue()));
            case EXPRESSION -> resolveExpression(nullToEmpty(field.getValue()), values, rowNumber, recordCount);
        };
        String generated = nullToEmpty(field.getPrefix()) + core + nullToEmpty(field.getSuffix());
        // Possible values are intentionally evaluated on every request/record; no generated value is cached.
        List<String> choices = parsePossibleValues(field.getPossibleValues());
        if (!choices.isEmpty()) generated = choices.get(random.nextInt(choices.size()));
        if (field.isConditionalEnabled()) generated = applyConditional(field, values, generated);
        return generated;
    }

    private String applyConditional(FieldConfig field, Map<String, String> values, String generated) {
        String source = nullToEmpty(values.get(field.getConditionalSourceField()));
        boolean matched = conditionMatches(source, field.getConditionalOperator(), field.getConditionalCompareValue());
        ConditionalAction action = matched ? field.getConditionalTrueAction() : field.getConditionalFalseAction();
        String actionValue = matched ? field.getConditionalTrueValue() : field.getConditionalFalseValue();
        if (action == null || action == ConditionalAction.KEEP_GENERATED) return generated;
        return switch (action) {
            case EMPTY -> "";
            case STATIC_VALUE -> nullToEmpty(actionValue);
            case COPY_FIELD -> nullToEmpty(values.get(actionValue));
            case POSSIBLE_VALUES -> {
                List<String> choices = parsePossibleValues(actionValue);
                yield choices.isEmpty() ? "" : choices.get(random.nextInt(choices.size()));
            }
            default -> generated;
        };
    }

    private boolean conditionMatches(String source, String operator, String compare) {
        String op = blankDefault(operator, "EQUALS").toUpperCase(Locale.ROOT);
        String expected = nullToEmpty(compare);
        return switch (op) {
            case "NOT_EQUALS" -> !source.equals(expected);
            case "IN" -> parsePossibleValues(expected).contains(source);
            case "NOT_IN" -> !parsePossibleValues(expected).contains(source);
            case "CONTAINS" -> source.contains(expected);
            case "STARTS_WITH" -> source.startsWith(expected);
            case "ENDS_WITH" -> source.endsWith(expected);
            case "EMPTY" -> source.isEmpty();
            case "NOT_EMPTY" -> !source.isEmpty();
            default -> source.equals(expected);
        };
    }

    private List<String> parsePossibleValues(String csv) {
        if (csv == null || csv.isBlank()) return List.of();
        return Arrays.stream(csv.split(",", -1)).map(String::trim).filter(v -> !v.isEmpty()).toList();
    }

    private LocalDateTime randomDateTime(FieldConfig field) {
        LocalDateTime start = parseDateTime(field.getStartDate(), field.getInputDateFormat());
        LocalDateTime end = parseDateTime(field.getEndDate(), field.getInputDateFormat());
        long seconds = ChronoUnit.SECONDS.between(start, end);
        return seconds <= 0 ? start : start.plusSeconds(Math.floorMod(random.nextLong(), seconds + 1));
    }

    private LocalDateTime steppedDateTime(FieldConfig field, int rowNumber) {
        LocalDateTime start = parseDateTime(field.getStartDate(), field.getInputDateFormat());
        long amount = Math.max(0, rowNumber - 1L) * nullTo(field.getDateStep(), 1L);
        return addUnit(start, amount, field.getDateStepUnit());
    }

    private LocalDateTime offsetDateTime(FieldConfig field, Map<String, String> values) {
        String source = nullToEmpty(values.get(field.getSourceField()));
        LocalDateTime parsed = parseDateTime(source, field.getInputDateFormat());
        return addUnit(parsed, nullTo(field.getDateOffset(), 0L), field.getDateOffsetUnit());
    }

    private LocalDateTime addUnit(LocalDateTime value, long amount, String unit) {
        return switch (blankDefault(unit, "DAYS").toUpperCase(Locale.ROOT)) {
            case "SECONDS" -> value.plusSeconds(amount);
            case "MINUTES" -> value.plusMinutes(amount);
            case "HOURS" -> value.plusHours(amount);
            case "WEEKS" -> value.plusWeeks(amount);
            case "MONTHS" -> value.plusMonths(amount);
            case "YEARS" -> value.plusYears(amount);
            default -> value.plusDays(amount);
        };
    }

    private LocalDateTime parseDateTime(String value, String pattern) {
        if (value == null || value.isBlank()) throw new IllegalArgumentException("Date/time value is required");
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(blankDefault(pattern, "yyyy-MM-dd'T'HH:mm"));
        try { return LocalDateTime.parse(value, formatter); }
        catch (Exception ignored) { return LocalDate.parse(value, formatter).atStartOfDay(); }
    }

    private DateTimeFormatter outputFormatter(FieldConfig field) { return DateTimeFormatter.ofPattern(blankDefault(field.getFormat(), "yyyyMMddHHmmss")); }
    private int effectiveLength(FieldConfig field) {
        int occupied = nullToEmpty(field.getPrefix()).length() + nullToEmpty(field.getSuffix()).length();
        return field.getRandomLength() == null ? Math.max(0, field.getWidth() - occupied) : Math.max(0, field.getRandomLength());
    }

    private String resolveExpression(String expression, Map<String, String> values, int rowNumber, int recordCount) {
        Matcher matcher = PLACEHOLDER.matcher(expression);
        StringBuffer result = new StringBuffer();
        while (matcher.find()) {
            String token = matcher.group(1);
            String replacement;
            if (token.equals("recordNumber")) replacement = String.valueOf(rowNumber);
            else if (token.equals("recordCount")) replacement = String.valueOf(recordCount);
            else if (token.startsWith("timestamp:")) replacement = LocalDateTime.now().format(DateTimeFormatter.ofPattern(token.substring(10)));
            else if (token.startsWith("date:")) replacement = LocalDateTime.now().format(DateTimeFormatter.ofPattern(token.substring(5)));
            else if (token.startsWith("randomNumeric:")) replacement = randomChars(NUMERIC, parsePositive(token.substring(14)));
            else if (token.startsWith("randomAlpha:")) replacement = randomChars(ALPHA, parsePositive(token.substring(12)));
            else if (token.startsWith("randomAlphanumeric:")) replacement = randomChars(ALPHANUMERIC, parsePositive(token.substring(19)));
            else if (token.startsWith("field:")) replacement = nullToEmpty(values.get(token.substring(6)));
            else replacement = "";
            matcher.appendReplacement(result, Matcher.quoteReplacement(replacement));
        }
        matcher.appendTail(result);
        return result.toString();
    }

    private int parsePositive(String value) { try { return Math.max(0, Integer.parseInt(value)); } catch (NumberFormatException e) { return 0; } }
    private String substring(String value, Integer start, Integer length) {
        int s = start == null ? 0 : Math.max(0, start);
        if (s >= value.length()) return "";
        int e = length == null ? value.length() : Math.min(value.length(), s + Math.max(0, length));
        return value.substring(s, e);
    }
    private String fit(String value, FieldConfig field) {
        String safe = nullToEmpty(value);
        if (safe.length() > field.getWidth()) {
            if (!field.isTruncate()) throw new InvalidConfigurationException(List.of("Generated value for field '" + field.getName() + "' exceeds width " + field.getWidth() + ": " + safe));
            safe = safe.substring(0, field.getWidth());
        }
        int missing = field.getWidth() - safe.length();
        String pad = blankDefault(field.getPadCharacter(), " ").substring(0, 1).repeat(missing);
        return field.getAlignment() == Alignment.RIGHT ? pad + safe : safe + pad;
    }
    private String randomChars(String alphabet, int length) {
        StringBuilder value = new StringBuilder(length);
        for (int i = 0; i < length; i++) value.append(alphabet.charAt(random.nextInt(alphabet.length())));
        return value.toString();
    }
    private String nullToEmpty(String value) { return value == null ? "" : value; }
    private String blankDefault(String value, String fallback) { return value == null || value.isBlank() ? fallback : value; }
    private long nullTo(Long value, long fallback) { return value == null ? fallback : value; }
}
