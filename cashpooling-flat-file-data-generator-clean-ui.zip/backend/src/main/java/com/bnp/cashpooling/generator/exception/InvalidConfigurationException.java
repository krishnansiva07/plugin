package com.bnp.cashpooling.generator.exception;

import java.util.List;

public class InvalidConfigurationException extends RuntimeException {
    private final List<String> errors;

    public InvalidConfigurationException(List<String> errors) {
        super("Flat-file configuration is invalid");
        this.errors = List.copyOf(errors);
    }

    public List<String> getErrors() { return errors; }
}
