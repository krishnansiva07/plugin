package com.llmart.llm.controller;

import com.llmart.llm.dto.ChatRequest;
import com.llmart.llm.dto.ChatResponse;
import com.llmart.llm.service.ChatService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/chat")
public class ChatController {
    private final ChatService chatService;
    public ChatController(ChatService chatService) { this.chatService = chatService; }

    @PostMapping
    public ChatResponse chat(@RequestBody ChatRequest request) {
        return new ChatResponse(chatService.chat(request.getMessage()));
    }
}
