package com.llmart.llm.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.llmart.llm.config.PlaywrightMcpProperties;
import org.springframework.stereotype.Service;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

@Service
public class McpJsonRpcClientService {
    private final PlaywrightMcpProperties properties;
    private final ObjectMapper objectMapper;
    private final HttpClient httpClient;
    private final AtomicInteger requestId = new AtomicInteger(1);
    private volatile String sessionId;

    public McpJsonRpcClientService(PlaywrightMcpProperties properties, ObjectMapper objectMapper) {
        this.properties = properties;
        this.objectMapper = objectMapper;
        this.httpClient = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(30)).build();
    }

    public synchronized void resetClientSession() {
        sessionId = null;
        requestId.set(1);
    }

    public String initialize() {
        Map<String, Object> params = new HashMap<>();
        params.put("protocolVersion", "2024-11-05");
        params.put("capabilities", Map.of("tools", Map.of()));
        params.put("clientInfo", Map.of("name", "spring-boot-playwright-mcp-client", "version", "3.0.0"));
        String response = jsonRpc("initialize", params);
        // Some MCP servers expect an initialized notification after initialize.
        jsonRpcNotification("notifications/initialized", Map.of());
        return response;
    }

    public String listTools() {
        return jsonRpc("tools/list", Map.of());
    }

    public String callTool(String toolName, Map<String, Object> arguments) {
        Map<String, Object> params = new HashMap<>();
        params.put("name", toolName);
        params.put("arguments", arguments == null ? Map.of() : arguments);
        return jsonRpc("tools/call", params);
    }

    public String navigate(String url) {
        return callTool("browser_navigate", Map.of("url", url));
    }

    public String snapshot() {
        return callTool("browser_snapshot", Map.of());
    }

    public String closeBrowser() {
        return callTool("browser_close", Map.of());
    }

    public String click(String element, String target) {
        return callTool("browser_click", Map.of("element", element, "target", target));
    }

    public String type(String element, String target, String text) {
        return callTool("browser_type", Map.of("element", element, "target", target, "text", text));
    }

    public String pressKey(String key) {
        return callTool("browser_press_key", Map.of("key", key));
    }

    public String waitForText(String text) {
        return callTool("browser_wait_for", Map.of("text", text));
    }

    public String waitSeconds(int seconds) {
        return callTool("browser_wait_for", Map.of("time", seconds));
    }

    private String jsonRpc(String method, Map<String, Object> params) {
        try {
            Map<String, Object> body = new HashMap<>();
            body.put("jsonrpc", "2.0");
            body.put("id", requestId.getAndIncrement());
            body.put("method", method);
            body.put("params", params);
            return send(body, true);
        } catch (Exception e) {
            return "MCP_CALL_FAILED: " + e.getMessage();
        }
    }

    private String jsonRpcNotification(String method, Map<String, Object> params) {
        try {
            Map<String, Object> body = new HashMap<>();
            body.put("jsonrpc", "2.0");
            body.put("method", method);
            body.put("params", params);
            return send(body, false);
        } catch (Exception e) {
            return "MCP_NOTIFICATION_FAILED: " + e.getMessage();
        }
    }

    private String send(Map<String, Object> body, boolean responseExpected) throws Exception {
        String json = objectMapper.writeValueAsString(body);
        HttpRequest.Builder requestBuilder = HttpRequest.newBuilder()
                .uri(URI.create(properties.getUrl()))
                .timeout(Duration.ofSeconds(120))
                .header("Content-Type", "application/json")
                .header("Accept", "application/json, text/event-stream")
                .POST(HttpRequest.BodyPublishers.ofString(json));

        if (sessionId != null && !sessionId.isBlank()) {
            requestBuilder.header("Mcp-Session-Id", sessionId);
        }

        HttpResponse<String> response = httpClient.send(requestBuilder.build(), HttpResponse.BodyHandlers.ofString());
        response.headers().firstValue("Mcp-Session-Id").ifPresent(value -> sessionId = value);

        String rawBody = response.body();
        String normalized = normalizeSseIfNeeded(rawBody);
        return "HTTP " + response.statusCode() + System.lineSeparator() + normalized;
    }

    private String normalizeSseIfNeeded(String raw) {
        if (raw == null) return "";
        if (!raw.contains("data:")) return raw;
        StringBuilder sb = new StringBuilder();
        for (String line : raw.split("\\R")) {
            String trimmed = line.trim();
            if (trimmed.startsWith("data:")) {
                sb.append(trimmed.substring(5).trim()).append(System.lineSeparator());
            }
        }
        return sb.toString().isBlank() ? raw : sb.toString();
    }

    public JsonNode parseJsonFromMcpResponse(String response) {
        try {
            int start = response.indexOf('{');
            int end = response.lastIndexOf('}');
            if (start >= 0 && end > start) {
                return objectMapper.readTree(response.substring(start, end + 1));
            }
        } catch (Exception ignored) {}
        return objectMapper.createObjectNode();
    }
}
