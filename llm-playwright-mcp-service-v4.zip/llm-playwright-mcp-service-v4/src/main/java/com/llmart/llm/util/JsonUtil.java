package com.llmart.llm.util;

public class JsonUtil {
    public static String extractJsonObject(String text) {
        if (text == null) return "{}";
        String cleaned = text.trim();
        cleaned = cleaned.replace("```json", "").replace("```", "").trim();
        int start = cleaned.indexOf('{');
        int end = cleaned.lastIndexOf('}');
        if (start >= 0 && end > start) {
            return cleaned.substring(start, end + 1);
        }
        return cleaned;
    }

    public static String stripCodeFence(String text) {
        if (text == null) return "";
        return text.replace("```typescript", "")
                .replace("```ts", "")
                .replace("```javascript", "")
                .replace("```", "")
                .trim();
    }
}
