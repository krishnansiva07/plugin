package com.llmart.llm.dto;

import java.util.ArrayList;
import java.util.List;

public class PlaywrightRunResponse {
    private String status;
    private String message;
    private String generatedTestCode;
    private String savedFilePath;
    private String runOutput;
    private String mcpStatus;
    private String snapshot;
    private List<String> agentTrace = new ArrayList<>();

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }
    public String getGeneratedTestCode() { return generatedTestCode; }
    public void setGeneratedTestCode(String generatedTestCode) { this.generatedTestCode = generatedTestCode; }
    public String getSavedFilePath() { return savedFilePath; }
    public void setSavedFilePath(String savedFilePath) { this.savedFilePath = savedFilePath; }
    public String getRunOutput() { return runOutput; }
    public void setRunOutput(String runOutput) { this.runOutput = runOutput; }
    public String getMcpStatus() { return mcpStatus; }
    public void setMcpStatus(String mcpStatus) { this.mcpStatus = mcpStatus; }
    public String getSnapshot() { return snapshot; }
    public void setSnapshot(String snapshot) { this.snapshot = snapshot; }
    public List<String> getAgentTrace() { return agentTrace; }
    public void setAgentTrace(List<String> agentTrace) { this.agentTrace = agentTrace; }
}
