package com.llmart.llm.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties(prefix = "playwright.mcp")
public class PlaywrightMcpProperties {
    private boolean autoStart = true;
    private int port = 8931;
    private String url = "http://localhost:8931/mcp";
    private String packageName = "@playwright/mcp@latest";
    private boolean headless = false;
    private int startupTimeoutSeconds = 90;
    private boolean ignoreHttpsErrors = false;
    private boolean isolated = true;
    private String userDataDir = "";
    private int actionTimeoutMs = 10000;
    private int navigationTimeoutMs = 90000;

    public boolean isAutoStart() { return autoStart; }
    public void setAutoStart(boolean autoStart) { this.autoStart = autoStart; }
    public int getPort() { return port; }
    public void setPort(int port) { this.port = port; }
    public String getUrl() { return url; }
    public void setUrl(String url) { this.url = url; }
    public String getPackageName() { return packageName; }
    public void setPackageName(String packageName) { this.packageName = packageName; }
    public boolean isHeadless() { return headless; }
    public void setHeadless(boolean headless) { this.headless = headless; }
    public int getStartupTimeoutSeconds() { return startupTimeoutSeconds; }
    public void setStartupTimeoutSeconds(int startupTimeoutSeconds) { this.startupTimeoutSeconds = startupTimeoutSeconds; }
    public boolean isIgnoreHttpsErrors() { return ignoreHttpsErrors; }
    public void setIgnoreHttpsErrors(boolean ignoreHttpsErrors) { this.ignoreHttpsErrors = ignoreHttpsErrors; }
    public boolean isIsolated() { return isolated; }
    public void setIsolated(boolean isolated) { this.isolated = isolated; }
    public String getUserDataDir() { return userDataDir; }
    public void setUserDataDir(String userDataDir) { this.userDataDir = userDataDir; }
    public int getActionTimeoutMs() { return actionTimeoutMs; }
    public void setActionTimeoutMs(int actionTimeoutMs) { this.actionTimeoutMs = actionTimeoutMs; }
    public int getNavigationTimeoutMs() { return navigationTimeoutMs; }
    public void setNavigationTimeoutMs(int navigationTimeoutMs) { this.navigationTimeoutMs = navigationTimeoutMs; }
}
