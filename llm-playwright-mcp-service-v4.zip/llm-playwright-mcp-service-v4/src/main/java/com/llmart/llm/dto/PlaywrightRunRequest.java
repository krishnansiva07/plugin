package com.llmart.llm.dto;

public class PlaywrightRunRequest {
    private String applicationUrl;
    private String scenario;
    private String projectPath;
    private String testFileName = "generated.spec.ts";
    private boolean saveToProject;
    private boolean executeInBrowser;
    private boolean headed = true;
    private int maxAgentSteps = 8;
    private boolean closeBrowserAfterRun = true;
    private boolean ignoreHttpsErrors = false;
    private boolean isolatedBrowser = true;
    private String userDataDir;
    private String preActionInstructions;

    public String getApplicationUrl() { return applicationUrl; }
    public void setApplicationUrl(String applicationUrl) { this.applicationUrl = applicationUrl; }
    public String getScenario() { return scenario; }
    public void setScenario(String scenario) { this.scenario = scenario; }
    public String getProjectPath() { return projectPath; }
    public void setProjectPath(String projectPath) { this.projectPath = projectPath; }
    public String getTestFileName() { return testFileName; }
    public void setTestFileName(String testFileName) { this.testFileName = testFileName; }
    public boolean isSaveToProject() { return saveToProject; }
    public void setSaveToProject(boolean saveToProject) { this.saveToProject = saveToProject; }
    public boolean isExecuteInBrowser() { return executeInBrowser; }
    public void setExecuteInBrowser(boolean executeInBrowser) { this.executeInBrowser = executeInBrowser; }
    public boolean isHeaded() { return headed; }
    public void setHeaded(boolean headed) { this.headed = headed; }
    public int getMaxAgentSteps() { return maxAgentSteps; }
    public void setMaxAgentSteps(int maxAgentSteps) { this.maxAgentSteps = maxAgentSteps; }
    public boolean isCloseBrowserAfterRun() { return closeBrowserAfterRun; }
    public void setCloseBrowserAfterRun(boolean closeBrowserAfterRun) { this.closeBrowserAfterRun = closeBrowserAfterRun; }
    public boolean isIgnoreHttpsErrors() { return ignoreHttpsErrors; }
    public void setIgnoreHttpsErrors(boolean ignoreHttpsErrors) { this.ignoreHttpsErrors = ignoreHttpsErrors; }
    public boolean isIsolatedBrowser() { return isolatedBrowser; }
    public void setIsolatedBrowser(boolean isolatedBrowser) { this.isolatedBrowser = isolatedBrowser; }
    public String getUserDataDir() { return userDataDir; }
    public void setUserDataDir(String userDataDir) { this.userDataDir = userDataDir; }
    public String getPreActionInstructions() { return preActionInstructions; }
    public void setPreActionInstructions(String preActionInstructions) { this.preActionInstructions = preActionInstructions; }
}
