package com.llmart.llm.dto;

import java.util.Map;

public class McpToolCallRequest {
    private String toolName;
    private Map<String, Object> arguments;

    public String getToolName() { return toolName; }
    public void setToolName(String toolName) { this.toolName = toolName; }
    public Map<String, Object> getArguments() { return arguments; }
    public void setArguments(Map<String, Object> arguments) { this.arguments = arguments; }
}
