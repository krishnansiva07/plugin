package com.llmart.llm.service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.llmart.llm.dto.PlaywrightRunRequest;
import com.llmart.llm.dto.PlaywrightRunResponse;
import com.llmart.llm.dto.RunTestRequest;
import com.llmart.llm.util.JsonUtil;
import dev.langchain4j.model.chat.ChatLanguageModel;
import org.springframework.stereotype.Service;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Service
public class PlaywrightAgentService {
    private final ChatLanguageModel chatModel;
    private final McpJsonRpcClientService mcpClient;
    private final PlaywrightMcpProcessService mcpProcessService;
    private final CommandExecutorService commandExecutor;
    private final ObjectMapper objectMapper;

    public PlaywrightAgentService(ChatLanguageModel chatModel,
                                  McpJsonRpcClientService mcpClient,
                                  PlaywrightMcpProcessService mcpProcessService,
                                  CommandExecutorService commandExecutor,
                                  ObjectMapper objectMapper) {
        this.chatModel = chatModel;
        this.mcpClient = mcpClient;
        this.mcpProcessService = mcpProcessService;
        this.commandExecutor = commandExecutor;
        this.objectMapper = objectMapper;
    }

    public PlaywrightRunResponse generateOnly(PlaywrightRunRequest request) {
        PlaywrightRunResponse response = new PlaywrightRunResponse();
        String code = generateCode(request, "No live browser snapshot was used.", "No MCP actions were executed.", List.of());
        response.setStatus("SUCCESS");
        response.setMessage("Generated Playwright test code using LLM only.");
        response.setGeneratedTestCode(code);
        return response;
    }

    /**
     * V3 behavior change:
     * explore-and-generate now actually performs actions in the UI through MCP before generating code.
     * V2 only navigated + took snapshot; that is why the browser launched but no UI action happened.
     */
    public PlaywrightRunResponse exploreAndGenerate(PlaywrightRunRequest request) {
        return performActionsAndGenerate(request, "explore-and-generate");
    }

    public PlaywrightRunResponse agentRun(PlaywrightRunRequest request) {
        return performActionsAndGenerate(request, "agent-run");
    }

    private PlaywrightRunResponse performActionsAndGenerate(PlaywrightRunRequest request, String mode) {
        PlaywrightRunResponse response = new PlaywrightRunResponse();
        List<String> trace = new ArrayList<>();
        List<String> executedActions = new ArrayList<>();
        String tools = "";
        String lastObservation = "";

        try {
            trace.add("MCP start: " + mcpProcessService.startForRequest(request));

            // Important fix: create a fresh MCP client session per request.
            // This avoids the issue where the second execution works only after server restart.
            mcpClient.resetClientSession();
            trace.add("MCP initialize: " + limit(mcpClient.initialize(), 1200));
            tools = mcpClient.listTools();
            trace.add("MCP tools/list: " + limit(tools, 3000));

            // Clean old browser/page state if any. Ignore failures because there may be nothing open.
            trace.add("Pre-run browser_close cleanup: " + limit(mcpClient.closeBrowser(), 1000));

            if (request.getApplicationUrl() != null && !request.getApplicationUrl().isBlank()) {
                lastObservation = mcpClient.navigate(request.getApplicationUrl());
                trace.add("browser_navigate: " + limit(lastObservation, 2000));
                lastObservation = mcpClient.snapshot();
                trace.add("Initial browser_snapshot: " + limit(lastObservation, 4000));
            }

            int maxSteps = Math.max(1, Math.min(request.getMaxAgentSteps(), 15));
            for (int i = 1; i <= maxSteps; i++) {
                String decisionPrompt = buildDecisionPrompt(request, tools, lastObservation, executedActions);
                String llmDecision = chatModel.generate(decisionPrompt);
                trace.add("LLM decision step " + i + ": " + limit(llmDecision, 1500));

                Map<String, Object> decision;
                try {
                    decision = objectMapper.readValue(JsonUtil.extractJsonObject(llmDecision), new TypeReference<>() {});
                } catch (Exception e) {
                    trace.add("Decision parse failed. Stopping action loop: " + e.getMessage());
                    break;
                }

                if (Boolean.TRUE.equals(decision.get("done"))) {
                    trace.add("Agent marked UI execution as done at step " + i);
                    break;
                }

                String toolName = String.valueOf(decision.get("toolName"));
                Map<String, Object> args = (Map<String, Object>) decision.getOrDefault("arguments", Map.of());

                if (!isAllowedTool(toolName)) {
                    trace.add("Blocked unsupported/unsafe tool from LLM: " + toolName);
                    break;
                }

                String toolResult = mcpClient.callTool(toolName, args);
                executedActions.add(toolName + " " + args);
                trace.add("MCP call " + toolName + ": " + limit(toolResult, 3000));

                // Always re-snapshot after each action so the next step has fresh refs.
                lastObservation = mcpClient.snapshot();
                trace.add("Post-action browser_snapshot: " + limit(lastObservation, 4000));
            }

            String finalSnapshot = mcpClient.snapshot();
            trace.add("Final browser_snapshot: " + limit(finalSnapshot, 4000));
            String code = generateCode(request, finalSnapshot, tools, executedActions);

            response.setStatus("SUCCESS");
            response.setMessage("UI actions completed through Playwright MCP and Playwright test code generated. Mode=" + mode);
            response.setAgentTrace(trace);
            response.setSnapshot(finalSnapshot);
            response.setGeneratedTestCode(code);
            response.setMcpStatus(mcpProcessService.status());

            if (request.isSaveToProject()) {
                response.setSavedFilePath(saveTest(request.getProjectPath(), request.getTestFileName(), code));
            }
            if (request.isExecuteInBrowser() && request.getProjectPath() != null) {
                RunTestRequest run = new RunTestRequest();
                run.setProjectPath(request.getProjectPath());
                run.setTestFileName(request.getTestFileName());
                run.setHeaded(request.isHeaded());
                response.setRunOutput(runPlaywrightTest(run));
            }
            return response;
        } finally {
            if (request.isCloseBrowserAfterRun()) {
                try {
                    String close = mcpClient.closeBrowser();
                    trace.add("Post-run browser_close: " + limit(close, 1000));
                } catch (Exception ignored) {}
            }
            // Important: reset Java side session so the next request starts cleanly without restarting Spring Boot.
            mcpClient.resetClientSession();
        }
    }

    private String buildDecisionPrompt(PlaywrightRunRequest request, String tools, String lastObservation, List<String> executedActions) {
        return """
                You are a browser automation agent controlling Playwright MCP.
                Your goal is to perform the user's scenario in the already opened browser.

                Scenario:
                %s

                Additional pre-action instructions, certificate notes, login hints, or popup handling rules:
                %s

                Already executed actions:
                %s

                Current browser snapshot / observation:
                %s

                You must return JSON only, no markdown, no explanation.

                Return exactly this shape:
                {"toolName":"browser_type","arguments":{"element":"todo input","target":"e5","text":"Buy milk"},"reason":"type todo item","done":false}

                Allowed toolName values only:
                - browser_snapshot
                - browser_click
                - browser_type
                - browser_press_key
                - browser_wait_for
                - browser_select_option
                - browser_hover

                Parameter rules based on current Playwright MCP:
                - browser_click requires target, not ref. Use exact target/ref from snapshot such as "e5".
                - browser_type requires target and text.
                - browser_select_option requires target and values array.
                - browser_press_key requires key, e.g. "Enter", "Tab".
                - browser_wait_for can use text, textGone, or time.
                - Do not invent target values. Use only target/ref values visible in the snapshot.
                - After typing into a todo/search/input where Enter is required, either set submit=true in browser_type or use browser_press_key with Enter.
                - Set done=true only after all scenario actions are actually performed or the goal is impossible from the snapshot.

                Examples:
                {"toolName":"browser_type","arguments":{"element":"todo textbox","target":"e5","text":"Buy milk","submit":true},"reason":"add todo","done":false}
                {"toolName":"browser_click","arguments":{"element":"Login button","target":"e12"},"reason":"click login","done":false}
                {"toolName":"browser_wait_for","arguments":{"text":"Dashboard"},"reason":"wait for dashboard","done":false}
                {"toolName":"browser_snapshot","arguments":{},"reason":"read current page","done":false}
                {"toolName":"browser_snapshot","arguments":{},"reason":"scenario completed","done":true}
                """.formatted(
                request.getScenario(),
                request.getPreActionInstructions(),
                executedActions,
                limit(lastObservation, 12000)
        );
    }

    private boolean isAllowedTool(String toolName) {
        return List.of(
                "browser_snapshot",
                "browser_click",
                "browser_type",
                "browser_press_key",
                "browser_wait_for",
                "browser_select_option",
                "browser_hover"
        ).contains(toolName);
    }

    private String generateCode(PlaywrightRunRequest request, String snapshot, String tools, List<String> executedActions) {
        String prompt = """
                You are a senior Playwright TypeScript automation architect.
                Generate production-ready Playwright TypeScript test code based on the performed browser actions.

                Application URL:
                %s

                Scenario:
                %s

                Additional instructions / popup handling:
                %s

                Actions actually executed by MCP:
                %s

                Final browser snapshot:
                %s

                Rules:
                1. Use @playwright/test.
                2. Use test() and expect().
                3. Prefer getByRole, getByLabel, getByText when available.
                4. Use locator only when role/label/text is not reliable.
                5. Avoid hard waits.
                6. Add meaningful assertions based on scenario and final snapshot.
                7. Return only TypeScript code. No markdown. No explanation.
                """.formatted(request.getApplicationUrl(), request.getScenario(), request.getPreActionInstructions(), executedActions, limit(snapshot, 12000));
        return JsonUtil.stripCodeFence(chatModel.generate(prompt));
    }

    public String saveTest(String projectPath, String testFileName, String code) {
        if (projectPath == null || projectPath.isBlank()) {
            return "FAILED: projectPath is required.";
        }
        try {
            String safeName = (testFileName == null || testFileName.isBlank()) ? "generated.spec.ts" : testFileName;
            Path testsDir = Path.of(projectPath, "tests");
            Files.createDirectories(testsDir);
            Path file = testsDir.resolve(safeName);
            Files.writeString(file, JsonUtil.stripCodeFence(code), StandardCharsets.UTF_8);
            return file.toAbsolutePath().toString();
        } catch (Exception e) {
            return "FAILED: " + e.getMessage();
        }
    }

    public String runPlaywrightTest(RunTestRequest request) {
        boolean isWindows = System.getProperty("os.name").toLowerCase().contains("win");
        List<String> command = new ArrayList<>();
        if (isWindows) {
            command.add("cmd.exe"); command.add("/c"); command.add("npx.cmd");
        } else {
            command.add("npx");
        }
        command.add("playwright"); command.add("test");
        if (request.getTestFileName() != null && !request.getTestFileName().isBlank()) {
            command.add(request.getTestFileName());
        }
        if (request.isHeaded()) command.add("--headed");
        return commandExecutor.execute(command, request.getProjectPath(), Duration.ofMinutes(10));
    }

    private String limit(String text, int max) {
        if (text == null) return "";
        return text.length() <= max ? text : text.substring(0, max) + "\n...[trimmed]";
    }
}
