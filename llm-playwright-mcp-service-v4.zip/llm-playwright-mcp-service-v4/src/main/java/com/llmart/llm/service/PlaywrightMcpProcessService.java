package com.llmart.llm.service;

import com.llmart.llm.config.PlaywrightMcpProperties;
import com.llmart.llm.dto.PlaywrightRunRequest;
import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;
import org.springframework.stereotype.Service;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

@Service
public class PlaywrightMcpProcessService {
    private final PlaywrightMcpProperties properties;
    private Process mcpProcess;
    private boolean currentIgnoreHttpsErrors;
    private boolean currentIsolated;
    private String currentUserDataDir = "";

    public PlaywrightMcpProcessService(PlaywrightMcpProperties properties) {
        this.properties = properties;
        this.currentIgnoreHttpsErrors = properties.isIgnoreHttpsErrors();
        this.currentIsolated = properties.isIsolated();
        this.currentUserDataDir = properties.getUserDataDir();
    }

    @PostConstruct
    public void autoStart() {
        if (properties.isAutoStart()) {
            start();
        }
    }

    public synchronized String start() {
        return startWithOptions(properties.isIgnoreHttpsErrors(), properties.isIsolated(), properties.getUserDataDir());
    }

    public synchronized String startForRequest(PlaywrightRunRequest request) {
        boolean ignore = request != null && request.isIgnoreHttpsErrors() || properties.isIgnoreHttpsErrors();
        boolean isolated = request == null ? properties.isIsolated() : request.isIsolatedBrowser();
        String userDataDir = request != null && request.getUserDataDir() != null && !request.getUserDataDir().isBlank()
                ? request.getUserDataDir()
                : properties.getUserDataDir();

        if (isRunning() && (ignore != currentIgnoreHttpsErrors || isolated != currentIsolated || !safe(userDataDir).equals(safe(currentUserDataDir)))) {
            stop();
            waitUntilPortClosed(properties.getPort(), 15);
        }
        return startWithOptions(ignore, isolated, userDataDir);
    }

    public synchronized String restartWithDefaultOptions() {
        stop();
        waitUntilPortClosed(properties.getPort(), 15);
        return start();
    }

    private String startWithOptions(boolean ignoreHttpsErrors, boolean isolated, String userDataDir) {
        if (isPortOpen("localhost", properties.getPort())) {
            return "RUNNING at " + properties.getUrl() + " | ignoreHttpsErrors=" + currentIgnoreHttpsErrors + " | isolated=" + currentIsolated;
        }
        if (!isCommandAvailable("node", "-v")) {
            return "FAILED: Node.js is not available in PATH.";
        }
        if (!isCommandAvailable("npx", "-v") && !isCommandAvailable("npx.cmd", "-v")) {
            return "FAILED: npx is not available in PATH.";
        }
        try {
            boolean isWindows = System.getProperty("os.name").toLowerCase().contains("win");
            List<String> command = new ArrayList<>();
            if (isWindows) {
                command.add("cmd.exe");
                command.add("/c");
                command.add("npx.cmd");
            } else {
                command.add("npx");
            }
            command.add("-y");
            command.add(properties.getPackageName());
            command.add("--port");
            command.add(String.valueOf(properties.getPort()));
            command.add("--timeout-action");
            command.add(String.valueOf(properties.getActionTimeoutMs()));
            command.add("--timeout-navigation");
            command.add(String.valueOf(properties.getNavigationTimeoutMs()));
            if (properties.isHeadless()) command.add("--headless");
            if (ignoreHttpsErrors) command.add("--ignore-https-errors");
            if (isolated) command.add("--isolated");
            if (userDataDir != null && !userDataDir.isBlank()) {
                command.add("--user-data-dir");
                command.add(userDataDir);
            }

            ProcessBuilder builder = new ProcessBuilder(command);
            builder.redirectErrorStream(true);
            mcpProcess = builder.start();

            Thread logThread = new Thread(() -> readLogs(mcpProcess));
            logThread.setDaemon(true);
            logThread.start();

            boolean started = waitForPort(properties.getPort(), properties.getStartupTimeoutSeconds());
            if (!started) {
                return "FAILED: Playwright MCP did not open port " + properties.getPort() + " within timeout.";
            }
            currentIgnoreHttpsErrors = ignoreHttpsErrors;
            currentIsolated = isolated;
            currentUserDataDir = userDataDir;
            return "STARTED at " + properties.getUrl() + " | ignoreHttpsErrors=" + ignoreHttpsErrors + " | isolated=" + isolated;
        } catch (Exception e) {
            return "FAILED: " + e.getMessage();
        }
    }

    public String status() {
        return isPortOpen("localhost", properties.getPort())
                ? "RUNNING at " + properties.getUrl() + " | ignoreHttpsErrors=" + currentIgnoreHttpsErrors + " | isolated=" + currentIsolated
                : "STOPPED";
    }

    public synchronized String stop() {
        if (mcpProcess != null && mcpProcess.isAlive()) {
            mcpProcess.destroy();
            return "STOPPED";
        }
        return "NO_LOCAL_PROCESS_TO_STOP. Port status: " + status();
    }

    private boolean isRunning() { return isPortOpen("localhost", properties.getPort()); }

    private void readLogs(Process process) {
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()))) {
            String line;
            while ((line = reader.readLine()) != null) {
                System.out.println("[PLAYWRIGHT-MCP] " + line);
            }
        } catch (Exception e) {
            System.out.println("[PLAYWRIGHT-MCP] log reader stopped: " + e.getMessage());
        }
    }

    private boolean waitForPort(int port, int timeoutSeconds) {
        long end = System.currentTimeMillis() + TimeUnit.SECONDS.toMillis(timeoutSeconds);
        while (System.currentTimeMillis() < end) {
            if (isPortOpen("localhost", port)) return true;
            try { Thread.sleep(1000); } catch (InterruptedException e) { Thread.currentThread().interrupt(); return false; }
        }
        return false;
    }

    private void waitUntilPortClosed(int port, int timeoutSeconds) {
        long end = System.currentTimeMillis() + TimeUnit.SECONDS.toMillis(timeoutSeconds);
        while (System.currentTimeMillis() < end && isPortOpen("localhost", port)) {
            try { Thread.sleep(500); } catch (InterruptedException e) { Thread.currentThread().interrupt(); return; }
        }
    }

    private boolean isPortOpen(String host, int port) {
        try (Socket socket = new Socket(host, port)) { return true; }
        catch (Exception e) { return false; }
    }

    private boolean isCommandAvailable(String command, String arg) {
        try {
            Process process = new ProcessBuilder(command, arg).redirectErrorStream(true).start();
            boolean finished = process.waitFor(10, TimeUnit.SECONDS);
            return finished && process.exitValue() == 0;
        } catch (Exception e) {
            return false;
        }
    }

    private String safe(String value) { return value == null ? "" : value; }

    @PreDestroy
    public void destroy() {
        if (mcpProcess != null && mcpProcess.isAlive()) {
            mcpProcess.destroy();
        }
    }
}
