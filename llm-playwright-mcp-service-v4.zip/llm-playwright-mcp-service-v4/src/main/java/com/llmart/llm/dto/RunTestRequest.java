package com.llmart.llm.dto;

public class RunTestRequest {
    private String projectPath;
    private String testFileName;
    private boolean headed = true;

    public String getProjectPath() { return projectPath; }
    public void setProjectPath(String projectPath) { this.projectPath = projectPath; }
    public String getTestFileName() { return testFileName; }
    public void setTestFileName(String testFileName) { this.testFileName = testFileName; }
    public boolean isHeaded() { return headed; }
    public void setHeaded(boolean headed) { this.headed = headed; }
}
