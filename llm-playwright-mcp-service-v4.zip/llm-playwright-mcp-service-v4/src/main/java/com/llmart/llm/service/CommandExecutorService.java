package com.llmart.llm.service;

import org.springframework.stereotype.Service;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;
import java.time.Duration;
import java.util.List;
import java.util.concurrent.TimeUnit;

@Service
public class CommandExecutorService {

    public String execute(List<String> command, String workingDirectory, Duration timeout) {
        StringBuilder output = new StringBuilder();
        try {
            ProcessBuilder builder = new ProcessBuilder(command);
            if (workingDirectory != null && !workingDirectory.isBlank()) {
                builder.directory(new File(workingDirectory));
            }
            builder.redirectErrorStream(true);
            Process process = builder.start();
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    output.append(line).append(System.lineSeparator());
                }
            }
            boolean finished = process.waitFor(timeout.toSeconds(), TimeUnit.SECONDS);
            if (!finished) {
                process.destroyForcibly();
                output.append(System.lineSeparator()).append("Command timed out.");
            } else {
                output.append(System.lineSeparator()).append("Exit code: ").append(process.exitValue());
            }
        } catch (Exception e) {
            output.append("Command failed: ").append(e.getMessage());
        }
        return output.toString();
    }
}
