package com.llmart.llm.controller;

import com.llmart.llm.dto.McpToolCallRequest;
import com.llmart.llm.dto.PlaywrightRunRequest;
import com.llmart.llm.dto.PlaywrightRunResponse;
import com.llmart.llm.dto.RunTestRequest;
import com.llmart.llm.service.McpJsonRpcClientService;
import com.llmart.llm.service.PlaywrightAgentService;
import com.llmart.llm.service.PlaywrightMcpProcessService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/playwright-mcp")
public class PlaywrightMcpController {
    private final PlaywrightMcpProcessService processService;
    private final McpJsonRpcClientService mcpClient;
    private final PlaywrightAgentService agentService;

    public PlaywrightMcpController(PlaywrightMcpProcessService processService,
                                   McpJsonRpcClientService mcpClient,
                                   PlaywrightAgentService agentService) {
        this.processService = processService;
        this.mcpClient = mcpClient;
        this.agentService = agentService;
    }

    @PostMapping("/start")
    public String start() { return processService.start(); }

    @PostMapping("/stop")
    public String stop() { return processService.stop(); }

    @PostMapping("/restart")
    public String restart() { return processService.restartWithDefaultOptions(); }

    @GetMapping("/status")
    public String status() { return processService.status(); }

    @PostMapping("/initialize")
    public String initialize() { return mcpClient.initialize(); }

    @GetMapping("/tools")
    public String tools() { return mcpClient.listTools(); }

    @PostMapping("/tool-call")
    public String callTool(@RequestBody McpToolCallRequest request) {
        return mcpClient.callTool(request.getToolName(), request.getArguments());
    }

    @PostMapping("/navigate")
    public String navigate(@RequestParam String url) { return mcpClient.navigate(url); }

    @GetMapping("/snapshot")
    public String snapshot() { return mcpClient.snapshot(); }

    @PostMapping("/close-browser")
    public String closeBrowser() { return mcpClient.closeBrowser(); }

    @PostMapping("/reset-session")
    public String resetSession() {
        mcpClient.resetClientSession();
        return "MCP client session reset. Next call will initialize a fresh session.";
    }

    @PostMapping("/generate-test")
    public PlaywrightRunResponse generateTest(@RequestBody PlaywrightRunRequest request) {
        return agentService.generateOnly(request);
    }

    @PostMapping("/explore-and-generate")
    public PlaywrightRunResponse exploreAndGenerate(@RequestBody PlaywrightRunRequest request) {
        return agentService.exploreAndGenerate(request);
    }

    @PostMapping("/agent-run")
    public PlaywrightRunResponse agentRun(@RequestBody PlaywrightRunRequest request) {
        return agentService.agentRun(request);
    }

    @PostMapping("/save-test")
    public String saveTest(@RequestBody PlaywrightRunRequest request) {
        PlaywrightRunResponse generated = agentService.generateOnly(request);
        return agentService.saveTest(request.getProjectPath(), request.getTestFileName(), generated.getGeneratedTestCode());
    }

    @PostMapping("/run-test")
    public String runTest(@RequestBody RunTestRequest request) {
        return agentService.runPlaywrightTest(request);
    }
}
