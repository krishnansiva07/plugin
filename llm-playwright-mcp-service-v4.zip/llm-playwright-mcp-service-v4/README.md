# LLM Playwright MCP Service V4 - UI + SSL Handling

This version adds a browser-based UI and SSL/certificate options on top of V3.

## What V4 does

- Starts Playwright MCP automatically using `npx -y @playwright/mcp@latest`
- Supports `--ignore-https-errors` for applications with invalid/self-signed SSL certificates
- Supports `--isolated` browser profile
- Optional `--user-data-dir` for persistent Chrome/Chromium profile
- Provides a web UI instead of only Postman
- Performs MCP browser actions before generating Playwright TypeScript code
- Saves generated tests into an existing Playwright project
- Runs generated Playwright test from the UI/API

## Run the Spring Boot app

```bash
mvn clean spring-boot:run
```

Open UI:

```text
http://localhost:8090/index.html
```

## Configure LLM

Update `src/main/resources/application.properties`:

```properties
llm.api-key=PASTE_YOUR_KEY_HERE
llm.model-name=gpt-oss-120b
llm.base-url=https://ai4devs.group.echonet/api/v1
```

## SSL / certificate handling

For most internal applications with self-signed or invalid certificate chains, enable this in the UI:

```text
Ignore SSL/HTTPS errors = checked
```

This starts MCP with:

```bash
--ignore-https-errors
```

For native Windows certificate chooser dialogs, automation is usually not reliable because it is an OS/browser native dialog, not part of the DOM/accessibility snapshot. Use one of these approaches:

1. Install/trust the certificate in Windows/browser first.
2. Use `userDataDir` with a persistent browser profile where the certificate choice is already saved.
3. Manually accept the cert once in that profile, then run automation again.

## UI fields

- Application URL: target app URL
- Scenario: business flow to perform
- Pre-action instructions: login, certificate popup, menu, assertion guidance
- Project Path: existing Playwright project root
- Test File Name: spec file name under `/tests`
- Ignore SSL/HTTPS errors: starts MCP with `--ignore-https-errors`
- Isolated browser profile: starts MCP with `--isolated`
- User Data Dir: optional persistent profile folder
- Save to project: writes generated spec into your Playwright project
- Run generated test: executes `npx playwright test <file> --headed`

## API examples

### Explore and generate

```http
POST http://localhost:8090/api/playwright-mcp/explore-and-generate
Content-Type: application/json
```

```json
{
  "applicationUrl": "https://your-internal-app",
  "scenario": "Login and verify dashboard is displayed",
  "preActionInstructions": "Ignore certificate warning if shown. If a Continue/Advanced option appears, proceed to site.",
  "projectPath": "C:/Automation/my-playwright-project",
  "testFileName": "login.spec.ts",
  "ignoreHttpsErrors": true,
  "isolatedBrowser": true,
  "saveToProject": true,
  "executeInBrowser": false,
  "headed": true,
  "maxAgentSteps": 10,
  "closeBrowserAfterRun": false
}
```

### Run saved test

```http
POST http://localhost:8090/api/playwright-mcp/run-test
Content-Type: application/json
```

```json
{
  "projectPath": "C:/Automation/my-playwright-project",
  "testFileName": "login.spec.ts",
  "headed": true
}
```

## Where LLM is used

LLM is used in two places:

1. During MCP action loop: after each browser snapshot, LLM decides the next allowed MCP action such as click, type, press key, wait, or done.
2. During code generation: after the UI flow is explored, LLM generates the final Playwright TypeScript test using the executed actions and final snapshot.

The LLM does not directly control the browser. It only returns structured JSON decisions. Java validates the decision and then calls Playwright MCP.
