package com.formatflow.ai.service;

import com.formatflow.ai.model.FormatModels.SourceBlock;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

@Service
public class ContentParser {

    private static final Pattern BULLET = Pattern.compile("^\\s*(?:[-*•▪◦]|\\d+[.)])\\s+.+$");
    private static final Pattern JAVAISH = Pattern.compile(
            "^\\s*(package\\s+|import\\s+|@\\w+|public\\s+|private\\s+|protected\\s+|class\\s+|interface\\s+|record\\s+|return\\s+|if\\s*\\(|for\\s*\\(|while\\s*\\(|try\\s*\\{|catch\\s*\\(|\\}|\\{).*"
    );
    private static final Pattern PROPERTY = Pattern.compile("^[A-Za-z0-9_.-]+\\s*=.*$");

    public List<SourceBlock> parse(String content) {
        String safe = content == null ? "" : content;
        String[] lines = safe.split("\\R", -1);
        List<SourceBlock> result = new ArrayList<>();
        boolean fenced = false;
        int sequence = 1;

        for (String line : lines) {
            String trimmed = line.trim();
            boolean fenceMarker = trimmed.startsWith("```");
            boolean blank = trimmed.isEmpty();
            boolean bullet = !blank && !fenced && BULLET.matcher(line).matches();
            boolean codeLike = !blank && (
                    fenced
                    || fenceMarker
                    || JAVAISH.matcher(line).matches()
                    || PROPERTY.matcher(trimmed).matches()
                    || trimmed.endsWith(";")
                    || trimmed.startsWith("//")
                    || trimmed.startsWith("/*")
                    || trimmed.startsWith("*")
                    || trimmed.matches("^</?[A-Za-z][^>]*>$")
                    || trimmed.matches("^[A-Za-z_$][A-Za-z0-9_$.]*\\s*\\(.*\\)\\s*;?$")
                    || trimmed.matches("^[{}\\[\\],]+$")
                    || (trimmed.startsWith("\"") && trimmed.contains("\":"))
            );
            result.add(new SourceBlock(id(sequence++), line, codeLike, bullet, blank));
            if (fenceMarker) fenced = !fenced;
        }
        return result;
    }

    public List<List<SourceBlock>> chunks(List<SourceBlock> blocks, int maxCharacters, int maxBlocks) {
        List<List<SourceBlock>> chunks = new ArrayList<>();
        List<SourceBlock> current = new ArrayList<>();
        int chars = 0;

        for (SourceBlock block : blocks) {
            if (block.blank()) continue;
            int next = block.text().length() + 80;
            if (!current.isEmpty() && (chars + next > maxCharacters || current.size() >= maxBlocks)) {
                chunks.add(List.copyOf(current));
                current.clear();
                chars = 0;
            }
            current.add(block);
            chars += next;
        }

        if (!current.isEmpty()) chunks.add(List.copyOf(current));
        return chunks;
    }

    private String id(int sequence) {
        return "B%05d".formatted(sequence);
    }
}
