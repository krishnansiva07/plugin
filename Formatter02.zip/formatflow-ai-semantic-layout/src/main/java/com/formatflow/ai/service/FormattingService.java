package com.formatflow.ai.service;

import com.formatflow.ai.model.FormatModels.*;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class FormattingService {

    private final SessionKeyService sessionKeyService;
    private final ContentParser contentParser;
    private final LlmOrchestrator llmOrchestrator;
    private final SemanticLayoutService semanticLayoutService;
    private final DocumentRenderer renderer;
    private final ContentDiffService diffService;

    public FormattingService(SessionKeyService sessionKeyService,
                             ContentParser contentParser,
                             LlmOrchestrator llmOrchestrator,
                             SemanticLayoutService semanticLayoutService,
                             DocumentRenderer renderer,
                             ContentDiffService diffService) {
        this.sessionKeyService = sessionKeyService;
        this.contentParser = contentParser;
        this.llmOrchestrator = llmOrchestrator;
        this.semanticLayoutService = semanticLayoutService;
        this.renderer = renderer;
        this.diffService = diffService;
    }

    public FormatResult format(FormatRequest request, HttpSession session) {
        String apiKey = sessionKeyService.require(session);
        Operation operation = parseOperation(request.operation());
        ContentMode mode = parseMode(request.mode());

        String original = request.content();
        String working = original;
        int llmCalls = 0;
        int contentChunks = 0;
        boolean enhanced = false;

        if (operation == Operation.SUMMARIZE) {
            LlmOrchestrator.SummaryOutcome summary = llmOrchestrator.summarize(
                    apiKey, original, request.audience(), request.purpose(), request.summaryLength(), request.format()
            );
            working = summary.content();
            llmCalls += summary.llmCalls();
            contentChunks = summary.chunks();
            enhanced = true;
        } else if (mode == ContentMode.ENHANCE) {
            List<SourceBlock> source = contentParser.parse(original);
            LlmOrchestrator.EnhancementOutcome outcome = llmOrchestrator.enhance(
                    apiKey, source, request.audience(), request.purpose(), request.format()
            );
            working = joinBlocks(outcome.blocks());
            llmCalls += outcome.llmCalls();
            contentChunks = outcome.chunks();
            enhanced = true;
        }

        List<SourceBlock> formattedSource = contentParser.parse(working);

        // Pass 1: line-level formatting metadata. The LLM cannot rewrite text here.
        LlmOrchestrator.PlanOutcome plan = llmOrchestrator.buildFormattingPlan(
                apiKey, formattedSource, request.audience(), request.purpose(), request.format(), request.iconLevel()
        );
        llmCalls += plan.llmCalls();

        // Pass 2: semantic document understanding. Rich structures contain only validated
        // exact excerpts from source blocks in FORMAT/PRESERVE mode.
        List<SemanticSection> semanticSections = List.of();
        boolean semanticFallback = false;
        List<String> detectedLayouts = List.of();
        int semanticChunks = 0;
        if (request.smartLayout()) {
            SemanticLayoutService.SemanticOutcome semantic = semanticLayoutService.analyze(
                    apiKey, formattedSource, request.audience(), request.purpose(), request.format(), request.iconLevel()
            );
            semanticSections = semantic.sections();
            llmCalls += semantic.llmCalls();
            semanticChunks = semantic.chunks();
            semanticFallback = semantic.fallbackUsed();
            detectedLayouts = semantic.detectedLayouts();
        }

        String subject = request.emailSubject() == null ? "" : request.emailSubject().trim();
        if ("EMAIL".equalsIgnoreCase(request.format()) && request.generateEmailSubject() && subject.isBlank()) {
            subject = llmOrchestrator.generateEmailSubject(apiKey, working, request.audience(), request.purpose());
            llmCalls++;
        }

        FormattedDocument document = renderer.compose(
                formattedSource,
                plan.items(),
                semanticSections,
                working,
                request.audience(),
                request.purpose() == null || request.purpose().isBlank() ? "General" : request.purpose(),
                request.format(),
                operation.name(),
                enhanced,
                subject
        );

        ContentStats stats = diffService.compare(original, working);
        int maxChunks = Math.max(Math.max(plan.chunks(), contentChunks), semanticChunks);
        ProcessingInfo processing = new ProcessingInfo(
                formattedSource.size(),
                llmCalls,
                plan.chunks(),
                maxChunks > 1,
                operation == Operation.SUMMARIZE ? "Summarize + Semantic Format"
                        : (enhanced ? "Enhance + Semantic Format" : "Semantic Format"),
                semanticSections.size(),
                detectedLayouts,
                semanticFallback
        );

        return new FormatResult(working, renderer.previewHtml(document), stats, document, processing);
    }

    private String joinBlocks(List<SourceBlock> blocks) {
        StringBuilder out = new StringBuilder();
        for (int i = 0; i < blocks.size(); i++) {
            if (i > 0) out.append('\n');
            out.append(blocks.get(i).text());
        }
        return out.toString();
    }

    private Operation parseOperation(String value) {
        try { return Operation.valueOf(value.trim().toUpperCase()); }
        catch (Exception ex) { throw new IllegalArgumentException("Unsupported operation: " + value); }
    }

    private ContentMode parseMode(String value) {
        try { return ContentMode.valueOf(value.trim().toUpperCase()); }
        catch (Exception ex) { throw new IllegalArgumentException("Unsupported content mode: " + value); }
    }
}
