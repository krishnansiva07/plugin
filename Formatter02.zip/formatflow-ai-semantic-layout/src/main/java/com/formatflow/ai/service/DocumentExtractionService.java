package com.formatflow.ai.service;

import com.formatflow.ai.model.ImportModels.ImportResult;
import org.apache.pdfbox.Loader;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import org.apache.poi.xslf.usermodel.XMLSlideShow;
import org.apache.poi.xslf.usermodel.XSLFShape;
import org.apache.poi.xslf.usermodel.XSLFTextShape;
import org.apache.poi.xwpf.usermodel.*;
import org.jsoup.Jsoup;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.ByteArrayInputStream;
import java.nio.charset.StandardCharsets;
import java.util.Locale;

@Service
public class DocumentExtractionService {

    private final ContentDiffService contentDiffService;

    public DocumentExtractionService(ContentDiffService contentDiffService) {
        this.contentDiffService = contentDiffService;
    }

    public ImportResult extract(MultipartFile file) {
        if (file == null || file.isEmpty()) {
            throw new IllegalArgumentException("Select a file first.");
        }

        String name = file.getOriginalFilename() == null ? "upload" : file.getOriginalFilename();
        String extension = extension(name);

        try {
            byte[] bytes = file.getBytes();
            String content = switch (extension) {
                case "txt", "md", "csv", "json", "xml", "properties", "java" ->
                        new String(bytes, StandardCharsets.UTF_8);
                case "html", "htm" ->
                        Jsoup.parse(new String(bytes, StandardCharsets.UTF_8)).wholeText();
                case "docx" -> extractDocx(bytes);
                case "pdf" -> extractPdf(bytes);
                case "pptx" -> extractPptx(bytes);
                default -> throw new IllegalArgumentException(
                        "Unsupported file type. Supported: TXT, MD, HTML, DOCX, PDF, PPTX, JSON, XML, properties and Java."
                );
            };

            return new ImportResult(
                    name,
                    content,
                    contentDiffService.wordCount(content),
                    content.length()
            );
        } catch (IllegalArgumentException ex) {
            throw ex;
        } catch (Exception ex) {
            throw new IllegalArgumentException("Unable to read " + name + ": " + ex.getMessage(), ex);
        }
    }

    private String extractDocx(byte[] bytes) throws Exception {
        StringBuilder out = new StringBuilder();
        try (XWPFDocument doc = new XWPFDocument(new ByteArrayInputStream(bytes))) {
            for (IBodyElement element : doc.getBodyElements()) {
                if (element instanceof XWPFParagraph paragraph) {
                    appendBlock(out, paragraph.getText());
                } else if (element instanceof XWPFTable table) {
                    for (XWPFTableRow row : table.getRows()) {
                        StringBuilder line = new StringBuilder();
                        for (XWPFTableCell cell : row.getTableCells()) {
                            if (!line.isEmpty()) line.append('\t');
                            line.append(cell.getText());
                        }
                        appendBlock(out, line.toString());
                    }
                }
            }
        }
        return out.toString();
    }

    private String extractPdf(byte[] bytes) throws Exception {
        try (PDDocument doc = Loader.loadPDF(bytes)) {
            return new PDFTextStripper().getText(doc).trim();
        }
    }

    private String extractPptx(byte[] bytes) throws Exception {
        StringBuilder out = new StringBuilder();
        try (XMLSlideShow ppt = new XMLSlideShow(new ByteArrayInputStream(bytes))) {
            for (var slide : ppt.getSlides()) {
                for (XSLFShape shape : slide.getShapes()) {
                    if (shape instanceof XSLFTextShape textShape) {
                        appendBlock(out, textShape.getText());
                    }
                }
            }
        }
        return out.toString();
    }

    private void appendBlock(StringBuilder out, String value) {
        if (value == null || value.isBlank()) return;
        if (!out.isEmpty()) out.append("\n\n");
        out.append(value.trim());
    }

    private String extension(String name) {
        String lower = name.toLowerCase(Locale.ROOT);
        int dot = lower.lastIndexOf('.');
        return dot < 0 ? "" : lower.substring(dot + 1);
    }
}
