package com.formatflow.ai.model;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

import java.util.List;

public final class FormatModels {

    private FormatModels() {}

    public enum Operation {
        FORMAT,
        SUMMARIZE
    }

    public enum ContentMode {
        PRESERVE,
        ENHANCE
    }

    public enum BlockType {
        TITLE,
        HEADING,
        PARAGRAPH,
        BULLET,
        CODE,
        CALLOUT,
        QUOTE,
        SPACER
    }

    /**
     * Semantic layouts are presentation structures. They do not grant permission
     * to rewrite source content. In PRESERVE mode every visible semantic value
     * must be traceable to an exact excerpt of a source block.
     */
    public enum SemanticLayoutType {
        TEXT,
        TABLE,
        WORKFLOW,
        TIMELINE,
        COMPARISON,
        STATUS,
        CHECKLIST,
        KPI,
        HIERARCHY,
        ARCHITECTURE,
        CODE_GROUP,
        CALLOUT
    }

    public record SourceBlock(
            String id,
            String text,
            boolean codeLike,
            boolean bulletLike,
            boolean blank
    ) {}

    public record PlanItem(
            String id,
            String type,
            String iconKey,
            String emphasis,
            String bulletStyle
    ) {}

    public record DocumentBlock(
            String id,
            String text,
            BlockType type,
            String iconKey,
            String iconSymbol,
            String emphasis,
            String bulletStyle
    ) {}

    /** A value copied from a specific source block. */
    public record SemanticValue(
            String sourceId,
            String text,
            String role,
            String iconKey
    ) {}

    public record SemanticRow(
            List<SemanticValue> cells
    ) {}

    public record SemanticNode(
            String id,
            String sourceId,
            String text,
            String iconKey
    ) {}

    public record SemanticEdge(
            String from,
            String to,
            String sourceId,
            String label
    ) {}

    public record SemanticItem(
            String sourceId,
            String label,
            String value,
            String status,
            String iconKey
    ) {}

    /**
     * A semantic section references the immutable source block ids that it
     * represents. Structural labels such as table column names are presentation
     * metadata, while title/cell/node/item text must be sourced excerpts.
     */
    public record SemanticSection(
            String id,
            String layoutType,
            String titleSourceId,
            String title,
            String iconKey,
            List<String> sourceIds,
            List<String> columns,
            List<SemanticRow> rows,
            List<SemanticNode> nodes,
            List<SemanticEdge> edges,
            List<SemanticItem> items
    ) {}

    public record FormattedDocument(
            String title,
            List<DocumentBlock> blocks,
            List<SemanticSection> semanticSections,
            String plainContent,
            String audience,
            String purpose,
            String outputFormat,
            String operation,
            boolean enhanced,
            String emailSubject
    ) {}

    public record FormatRequest(
            @NotBlank String content,
            @NotBlank String audience,
            String purpose,
            @NotBlank String format,
            @NotBlank String operation,
            @NotBlank String mode,
            String summaryLength,
            String visualStyle,
            String iconLevel,
            String emailSubject,
            boolean generateEmailSubject,
            boolean smartLayout
    ) {}

    public record ContentStats(
            int originalWords,
            int formattedWords,
            int addedWords,
            int removedWords,
            boolean exactContentPreserved,
            int originalCharacters,
            int formattedCharacters
    ) {}

    public record ProcessingInfo(
            int sourceBlocks,
            int llmCalls,
            int formattingChunks,
            boolean chunked,
            String activity,
            int semanticSections,
            List<String> detectedLayouts,
            boolean semanticFallback
    ) {}

    public record FormatResult(
            String finalContent,
            String previewHtml,
            ContentStats stats,
            FormattedDocument document,
            ProcessingInfo processing
    ) {}

    public record ExportRequest(
            @NotNull FormattedDocument document,
            @NotBlank String format,
            String filename
    ) {}
}
