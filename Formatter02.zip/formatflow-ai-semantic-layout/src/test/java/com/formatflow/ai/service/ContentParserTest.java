package com.formatflow.ai.service;

import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

class ContentParserTest {
    private final ContentParser parser = new ContentParser();

    @Test
    void identifiesBulletAndCodeWithoutChangingText() {
        var blocks = parser.parse("Network\n- Check endpoint\nserver.port=8090");
        assertThat(blocks).hasSize(3);
        assertThat(blocks.get(1).bulletLike()).isTrue();
        assertThat(blocks.get(2).codeLike()).isTrue();
        assertThat(blocks.get(2).text()).isEqualTo("server.port=8090");
    }
}
