package com.formatflow.ai.service;

import com.formatflow.ai.model.FormatModels.*;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

class DocumentRendererTest {

    private final IconCatalog icons = new IconCatalog();
    private final DocumentRenderer renderer = new DocumentRenderer(icons);

    @Test
    void rendersSemanticNetworkIconAndCheckBullet() {
        var source = List.of(
                new SourceBlock("B00001", "Network Configuration", false, false, false),
                new SourceBlock("B00002", "- Validate connection", false, true, false)
        );
        var plan = List.of(
                new PlanItem("B00001", "HEADING", "NETWORK", "STRONG", "NONE"),
                new PlanItem("B00002", "BULLET", "NONE", "NONE", "CHECK")
        );
        var doc = renderer.compose(source, plan, List.of(), "Network Configuration\n- Validate connection",
                "Technical Team", "General", "HTML", "FORMAT", false, "");
        String html = renderer.standaloneHtml(doc, false);
        assertThat(html).contains("🌐").contains("✓").contains("Validate connection");
        assertThat(html).contains("<!doctype html>");
    }

    @Test
    void rendersSemanticTable() {
        var source = List.of(
                new SourceBlock("B00001", "Configuration", false, false, false),
                new SourceBlock("B00002", "Java version is 17.", false, false, false)
        );
        var plan = List.of(
                new PlanItem("B00001", "HEADING", "CONFIG", "STRONG", "NONE"),
                new PlanItem("B00002", "PARAGRAPH", "NONE", "NONE", "NONE")
        );
        var semantic = List.of(new SemanticSection(
                "S0001", "TABLE", "B00001", "Configuration", "CONFIG",
                List.of("B00001", "B00002"),
                List.of("Property", "Value"),
                List.of(new SemanticRow(List.of(
                        new SemanticValue("B00002", "Java version", "KEY", "NONE"),
                        new SemanticValue("B00002", "17", "VALUE", "NONE")
                ))), List.of(), List.of(), List.of()
        ));
        var doc = renderer.compose(source, plan, semantic, "Configuration\nJava version is 17.",
                "Technical Team", "General", "HTML", "FORMAT", false, "");
        String html = renderer.standaloneHtml(doc, false);
        assertThat(html).contains("semantic-table").contains("Java version").contains("17");
    }

    @Test
    void iconCatalogInfersNetworkSemantic() {
        assertThat(icons.inferKey("Network Connectivity")).isEqualTo("NETWORK");
        assertThat(icons.symbol("NETWORK")).isEqualTo("🌐");
    }
}
