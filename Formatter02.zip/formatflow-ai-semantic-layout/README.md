# FormatFlow AI — Semantic Layout Edition

**One Content. Any Audience. Any Format.**

FormatFlow AI is a Java 17 + Spring Boot application that uses an OpenAI-compatible LLM for **document understanding and presentation planning**, while keeping content transformation permissions explicit.

## Core purpose

The tool is not just a text beautifier. It analyzes the meaning and relationships in supplied content and can select a richer representation when the source supports it:

- key/value facts → table
- sequential interactions → workflow
- dates/milestones → timeline
- option A vs B → comparison
- progress/state → status cards
- actions → checklist
- metrics → KPI cards
- parent/child relationships → hierarchy
- components/relationships → architecture flow
- code/configuration → protected code groups
- warnings/important items → callouts
- otherwise → professional text layout

## Content modes

### Format + Preserve

The original logical content string is never rewritten. The LLM is allowed to return only formatting metadata and semantic structures. Any visible value in a semantic table/workflow/timeline/card must be validated by Java as an **exact excerpt of the referenced source block**. If validation fails, FormatFlow falls back to normal text for that source instead of inventing content.

Semantic transformation may split an original sentence into exact excerpts for presentation. Example:

`Java version is 17.`

may be shown as:

| Property | Value |
|---|---|
| Java version | 17 |

The immutable source remains available in Original / Side-by-Side views and is retained as `plainContent` in the document model.

### Enhance + Format

The user explicitly permits grammar/clarity changes. Code/configuration blocks are still protected from LLM changes.

### Summarize + Format

The user explicitly permits summarization. Large documents are summarized hierarchically in bounded chunks and then semantically formatted for the selected stakeholder.

## LLM pipeline

```text
Input
  ↓
Extraction / parsing
  ↓
Optional enhancement or stakeholder summarization
  ↓
LLM pass 1: line-level formatting metadata
  ↓
LLM pass 2: semantic layout analysis
  ↓
Java semantic validation / source-excerpt enforcement
  ↓
FormattedDocument
  ↓
HTML / Confluence / Word / PowerPoint / PDF / Email / Markdown
```

Large content is sent in bounded chunks controlled by:

```properties
formatflow.llm.chunk-characters=9000
formatflow.llm.chunk-blocks=40
```

Each chunk is validated independently. Unsupported or invalid semantic output degrades safely to TEXT so source content is not lost.

## Semantic document model

Important classes:

- `SemanticLayoutService` — invokes the LLM for structural understanding
- `SemanticLayoutValidator` — rejects invented/non-source semantic values
- `PromptFactory` — separate prompts for formatting, semantic analysis, enhancement, summaries and email subjects
- `DocumentRenderer` — HTML/Confluence/Markdown semantic renderer
- `ExportService` — Word/PPT/PDF semantic renderers
- `FormattingService` — orchestration

Supported semantic section types:

```text
TEXT
TABLE
WORKFLOW
TIMELINE
COMPARISON
STATUS
CHECKLIST
KPI
HIERARCHY
ARCHITECTURE
CODE_GROUP
CALLOUT
```

## Stakeholder audiences

- General
- Co-worker
- Manager
- Management / Executive
- Business Analyst
- Product Owner
- Scrum Master
- Technical Team
- Client / Stakeholder

Audience selection influences hierarchy and visual emphasis. It does not permit rewriting in Preserve mode.

## Outputs

- Confluence-ready HTML
- Word `.docx`
- PowerPoint `.pptx`
- PDF
- Email HTML
- Markdown
- HTML

Semantic HTML includes actual tables, workflow nodes/arrows, timelines, cards, checklists and callouts. PowerPoint creates actual positioned node/card shapes for semantic sections rather than copying all content into one text box.

## LLM access

The first screen requires a valid LLM API key. The key is kept only in the server-side HTTP session.

The key is intentionally not stored in source code or `application.properties`.

Configure only the static endpoint/model:

```properties
formatflow.llm.base-url=https://your-openai-compatible-endpoint/api/v1
formatflow.llm.model=your-model
formatflow.llm.chat-path=/chat/completions
```

Bearer-token gateway:

```properties
formatflow.llm.auth-header=Authorization
formatflow.llm.auth-prefix=Bearer 
```

Header-key gateway:

```properties
formatflow.llm.auth-header=api-key
formatflow.llm.auth-prefix=
```

## Build and run

Requirements:

- Java 17+
- Maven 3.9+

```bash
mvn clean test
mvn clean package
java -jar target/formatflow-ai-0.0.1-SNAPSHOT.jar
```

Open:

```text
http://localhost:8090
```

## Semantic demo

Paste `samples/semantic-layout-demo.txt`, select:

```text
Audience: Technical Team
Activity: Format
Content Handling: Preserve Source Content
Smart Semantic Layout: ON
Symbols: Rich & Semantic
Format: HTML or PowerPoint
```

The configured LLM should identify the configuration facts, request workflow and delivery status as separate semantic structures when its analysis is valid. Exact layout selection remains model-driven; unsafe/invented values are rejected by the Java validator.

## Security controls

- API key is session-only
- prompt-injection boundary: imported content is treated as data
- structured semantic values must come from referenced source excerpts
- code/configuration blocks are protected in enhancement mode
- URL importer blocks private/local network targets by default
- uploaded content and API keys are not intentionally written to logs
- security response headers are included
- invalid semantic LLM output fails safely to text

## Validation included

Tests cover:

- preserve-mode logical content integrity
- semantic network symbols and tick bullets
- HTML full-document export
- semantic table rendering
- semantic exact-excerpt validation
- rejection of an invented semantic table value
- workflow excerpt validation
- code detection
- content-difference measurement

## Note about local build verification

This source tree has been syntax-checked for the newly added semantic classes and frontend JavaScript in the generation environment. The environment does not have Maven dependencies cached and cannot reach Maven Central, so the full Maven dependency build must be run in your normal development environment with `mvn clean test`.
