package com.llmart.llm.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.llmart.llm.dto.ChatRequest;
import jakarta.annotation.PreDestroy;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URI;
import java.net.ProxySelector;
import java.io.IOException;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.time.Duration;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.*;

/**
 * OpenCode 2 HTTP execution adapter. No OpenCode classes or OS-specific shell commands enter ELIYA's core.
 * Remote tool/model work is performed by OpenCode, not reimplemented in this service.
 * The adapter is opt-in, and the existing ELIYA executor remains available for rollback.
 *
 * OpenCode 2 contract: POST /api/session, POST /api/session/{id}/prompt,
 * GET /api/experimental/session/{id}/log?follow=true, POST /api/session/{id}/interrupt.
 */
@Service
public class OpenCodeExecutionService {
    private static final int MAX_EVENTS = 450, MAX_TURNS = 30, MAX_TEXT = 80_000;
    private final ObjectMapper mapper;
    private final ProjectService projects;
    // Connect directly to the managed loopback server. Do not inherit proxy settings
    // from the desktop or corporate Java process. Pin HTTP/1.1 for this local API.
    private final HttpClient http = localHttpClient();
    private static HttpClient localHttpClient() {
        return HttpClient.newBuilder().version(HttpClient.Version.HTTP_1_1)
                .proxy(ProxySelector.of(null))
                .connectTimeout(Duration.ofSeconds(3)).build();
    }
    private final ExecutorService readers = Executors.newCachedThreadPool(r -> {
        Thread t = new Thread(r, "eliya-opencode-event"); t.setDaemon(true); return t;
    });
    private final ConcurrentHashMap<String, Session> sessions = new ConcurrentHashMap<>();
    private final Path store = Path.of(System.getProperty("eliya.opencode.sessionStore", "./data/opencode-sessions"))
            .toAbsolutePath().normalize();
    private volatile URI base;
    private volatile String authorization;
    private final String executable;
    private final boolean autoStart;
    private volatile int port;
    private final boolean enabled;
    private final boolean managedLocal;
    private final OpenCodeLocalRuntime localRuntime = new OpenCodeLocalRuntime();
    private volatile String connectionStatus = "not-started";
    private volatile Process managedProcess;
    private final Object startLock = new Object();

    public OpenCodeExecutionService(ObjectMapper mapper, ProjectService projects,
            @Value("${eliya.execution.engine:legacy}") String engine,
            @Value("${eliya.opencode.url:http://127.0.0.1:4096}") String url,
            @Value("${eliya.opencode.password:}") String password,
            @Value("${eliya.opencode.executable:opencode}") String executable,
            @Value("${eliya.opencode.auto-start:false}") boolean autoStart) {
        this.mapper = mapper;
        this.projects = projects;
        this.enabled = "opencode".equalsIgnoreCase(engine);
        URI parsed = URI.create(this.enabled ? url : "http://127.0.0.1:4096");
        String host = parsed.getHost();
        if (!"http".equals(parsed.getScheme()) || host == null || parsed.getUserInfo() != null ||
                parsed.getRawQuery() != null || parsed.getRawFragment() != null ||
                !Set.of("localhost", "127.0.0.1", "[::1]", "::1").contains(host.toLowerCase(Locale.ROOT))) {
            throw new IllegalArgumentException("OpenCode server must use loopback HTTP. Remote tool execution is disabled.");
        }
        this.port = parsed.getPort() < 0 ? 80 : parsed.getPort();
        this.base = URI.create("http://127.0.0.1:" + port);
        this.authorization = basicAuth(password);
        this.executable = executable;
        this.autoStart = autoStart;
        this.managedLocal = this.enabled && autoStart && (password == null || password.isBlank());
        try {
            Files.createDirectories(store);
            try (var files = Files.list(store)) {
                files.filter(p -> p.getFileName().toString().endsWith(".json")).limit(300).forEach(p -> {
                    try {
                        JsonNode obj = mapper.readTree(p.toFile());
                        String id = obj.path("id").asText();
                        String remote = obj.path("remoteId").asText();
                        if (!id.matches("oc-[0-9a-f-]{36}") || remote.isBlank()) return;
                        Session session = new Session(id, remote, obj.path("conversationId").asText(),
                                obj.path("projectId").asText(), obj.path("model").asText(),
                                obj.path("fullPrompt").asText());
                        String savedStatus = obj.path("status").asText("interrupted");
                        session.status = Set.of("completed", "failed", "cancelled").contains(savedStatus)
                                ? savedStatus : "interrupted"; // running tasks cannot be assumed complete after restart
                        session.createdAt = obj.path("createdAt").asText(session.createdAt);
                        session.startedAt = obj.path("startedAt").asText(session.createdAt);
                        session.finishedAt = obj.path("finishedAt").asText("");
                        session.updatedAt = obj.path("updatedAt").asText(Instant.now().toString());
                        if (obj.path("changeReport").isObject()) {
                            @SuppressWarnings("unchecked") Map<String,Object> persistedReport =
                                    mapper.convertValue(obj.path("changeReport"), Map.class);
                            session.changeReport = persistedReport;
                        }
                        sessions.put(id, session);
                    } catch (Exception ignored) { /* corrupt history cannot disable the app */ }
                });
            }
        } catch (Exception ignored) { /* in-memory sessions still supported */ }
    }

    private static String basicAuth(String password) {
        return "Basic " + Base64.getEncoder().encodeToString(
                ("opencode:" + (password == null ? "" : password)).getBytes(StandardCharsets.UTF_8));
    }

    // Auto does not consume hidden model tokens or mistake a launchable binary for a working provider.
    // A launchable binary is not proof that its configured model can do any work.
    // Auto only opts in after an explicit OpenCode 2 run has actually completed.
    // This never spends the user's tokens on hidden "health test" prompts.
    private volatile boolean executionProven;
    public boolean availableForAuto() {
        // Without a previously successful execution there is no way to distinguish
        // working provider credentials from a server that merely accepts prompts.
        // Keep Auto deterministic and safe: it uses Legacy until OpenCode proves itself.
        return enabled && executionProven && (!managedLocal || (managedProcess != null && managedProcess.isAlive()));
    }

    /** Diagnostic only. This must not launch a model or consume tokens. */
    public String automaticSelectionReason() {
        if (!enabled) return "OpenCode integration disabled";
        if (!executionProven) return "Auto uses ELIYA Legacy until an explicit OpenCode 2 task succeeds";
        return availableForAuto()
                ? "OpenCode 2 execution confirmed" : "OpenCode service not running; Auto uses Legacy";
    }

    public boolean enabled() { return enabled; }
    public boolean owns(String id) { return id != null && id.startsWith("oc-") && sessions.containsKey(id); }
    public Map<String,Object> engineInfo() {
        Map<String,Object> info = new LinkedHashMap<>();
        info.put("engine", enabled ? "opencode" : "legacy");
        info.put("platform", System.getProperty("os.name"));
        info.put("configured", enabled);
        info.put("connected", false);
        info.put("autoEligible", availableForAuto());
        info.put("autoReason", automaticSelectionReason());
        if (!enabled) return info;
        info.put("startupMode", managedLocal ? "automatic-local" : "configured-service");
        try {
            if (managedLocal) ensureServer();
            JsonNode data = request("GET", "/api/info", null);
            requireVersion(data);
            requireDefaultModel();
            info.put("connected", true);
            info.put("server", data);
            info.put("endpoint", base.toString());
            info.put("connection", managedLocal ? "managed" : "external");
        } catch (Exception e) { info.put("reason", safeError(e)); }
        return info;
    }

    /** We deliberately keep ELIYA's attachment/MCP workflow on its existing backend until mapped natively. */
    public boolean accepts(ChatRequest request) {
        return enabled && request != null && request.chatMode() == com.llmart.llm.dto.ChatMode.AGENT
                && (request.attachmentIds() == null || request.attachmentIds().isEmpty())
                && (request.message() == null || !request.message().toLowerCase(Locale.ROOT).matches("(?s).*\\bmcp\\b.*"));
    }

    private static void progress(java.util.function.Consumer<String> notice, String detail) {
        if (notice != null) notice.accept(detail);
    }

    private void ensureServer() throws Exception { ensureServer(null); }

    private void ensureServer(java.util.function.Consumer<String> notice) throws Exception {
        if (managedLocal) {
            synchronized (startLock) {
                if (managedProcess != null && managedProcess.isAlive()) {
                    try { requireVersion(request("GET", "/api/info", null)); return; }
                    catch (Exception e) { stopManagedProcess(); }
                }
                // Always use a private process/port instead of accidentally taking over another
                // user's OpenCode server on 4096. The password never needs to be typed.
                progress(notice, "Checking the installed OpenCode 2 executable");
                OpenCodeLocalRuntime.Command installed = localRuntime.findV2(executable);
                Exception last = null;
                for (int retry=0;retry<2;retry++) {
                    port = localRuntime.availableLoopbackPort();
                    base = URI.create("http://127.0.0.1:" + port);
                    String generated = localRuntime.randomPassword();
                    authorization = basicAuth(generated);
                    progress(notice, "Starting authenticated local OpenCode server" + (retry > 0 ? " (retry)" : ""));
                    managedProcess = localRuntime.start(installed, port, generated);
                    long readyDeadline = System.nanoTime() + TimeUnit.SECONDS.toNanos(9);
                    for (int i=0;i<25 && System.nanoTime()<readyDeadline;i++) {
                        Thread.sleep(240);
                        if (i == 10) progress(notice, "Waiting for OpenCode server readiness");
                        try {
                            requireVersion(request("GET", "/api/info", null));
                            connectionStatus = "connected";
                            progress(notice, "OpenCode server authenticated and ready");
                            return;
                        } catch (Exception e) {
                            last = e;
                            if (!managedProcess.isAlive()) {
                                int exit = managedProcess.exitValue();
                                last = new IllegalStateException("OpenCode process exited during startup (code " + exit + ")", e);
                                break;
                            }
                        }
                    }
                    stopManagedProcess();
                }
                connectionStatus = "unavailable";
                progress(notice, "OpenCode startup failed");
                throw new IllegalStateException("OpenCode 2 failed to start its local API: " + safeError(last)
                        + ". Local OpenCode output: " + localRuntime.lastOutput()
                        + ". Check that 'opencode --version' works in the environment launching ELIYA", last);
            }
        }
        // Explicitly configured external server: preserve the ELIYA89 integration behavior.
        try { requireVersion(request("GET", "/api/info", null)); return; }
        catch (Exception e) { if (!autoStart) throw e; }
        synchronized (startLock) {
            try { requireVersion(request("GET", "/api/info", null)); return; }
            catch (Exception ignored) { /* optional manually configured server startup */ }
            if (managedProcess != null && managedProcess.isAlive())
                throw new IllegalStateException("OpenCode started but is not responding on " + base);
            String pass = configuredPassword();
            OpenCodeLocalRuntime.Command installed = localRuntime.findV2(executable);
            managedProcess = localRuntime.start(installed, port, pass);
            for (int i=0;i<35;i++) {
                Thread.sleep(200);
                try { requireVersion(request("GET", "/api/info", null)); return; }
                catch (Exception ignored) { if (!managedProcess.isAlive()) break; }
            }
            throw new IllegalStateException("OpenCode 2 could not start with the configured settings. "
                    + localRuntime.lastOutput());
        }
    }

    private void stopManagedProcess() {
        Process process = managedProcess;
        managedProcess = null;
        if (process == null) return;
        try {
            process.descendants().forEach(ProcessHandle::destroy);
            process.destroy();
            if (!process.waitFor(1500, TimeUnit.MILLISECONDS)) {
                process.descendants().forEach(ProcessHandle::destroyForcibly);
                process.destroyForcibly();
            }
        } catch (Exception ignored) { process.destroyForcibly(); }
    }

    private String configuredPassword() {
        // Only auto-start with a nonempty configured secret. Avoid launching an exposed unauthenticated executor.
        String raw = new String(Base64.getDecoder().decode(authorization.substring(6)), StandardCharsets.UTF_8);
        String pass = raw.substring("opencode:".length());
        if (pass.length() < 16) throw new IllegalStateException("Set ELIYA_OPENCODE_PASSWORD (16+ characters) before auto-starting OpenCode");
        return pass;
    }

    /** A local HTTP process is not useful without an OpenCode-configured chat model.
     * ELIYA's legacy model selection does not automatically configure OpenCode.
     * Fail before submitting anything (never automatically duplicate a task). */
    private void requireDefaultModel() throws Exception {
        JsonNode model = unwrap(request("GET", "/api/model/default", null));
        if (model.isMissingNode() || "null".equals(model.toString()) ||
                (model.isObject() && model.path("id").asText("").isBlank()
                        && model.path("modelID").asText("").isBlank())) {
            throw new IllegalStateException("OpenCode 2 has no configured default model. Configure its model/provider "
                    + "in OpenCode, or select ELIYA Legacy (which uses ELIYA's model settings)");
        }
    }

    private static void requireVersion(JsonNode response) {
        JsonNode data = response.path("data").isMissingNode() ? response : response.path("data");
        String version = data.path("version").asText("");
        if (version.isBlank() || !version.startsWith("2."))
            throw new IllegalStateException("OpenCode 2 required, found " + version);
    }

    private JsonNode request(String method, String path, Object body) throws Exception {
        HttpRequest.Builder b = HttpRequest.newBuilder(base.resolve(path))
                .timeout(Duration.ofSeconds("/api/info".equals(path) ? 2 : "/api/model/default".equals(path) ? 6 : 30))
                .header("Authorization", authorization)
                .header("Accept", "application/json");
        if (body != null) b.header("Content-Type", "application/json");
        if ("GET".equals(method)) b.GET();
        else b.method(method, body == null ? HttpRequest.BodyPublishers.noBody() :
                HttpRequest.BodyPublishers.ofString(mapper.writeValueAsString(body)));
        HttpRequest call = b.build();
        HttpResponse<String> result;
        try {
            result = http.send(call, HttpResponse.BodyHandlers.ofString());
        } catch (IOException closed) {
            // Java HttpClient can reuse a socket that OpenCode closed between health and
            // model checks. Retry read-only GET on a fresh connection; never automatically
            // retry POST because OpenCode may have accepted a mutating instruction.
            if (!"GET".equals(method)) throw new IOException(
                    "Connection ended during OpenCode " + method + " " + path
                    + "; task acceptance is unknown. Do not resubmit automatically.", closed);
            try {
                Thread.sleep(180);
                result = localHttpClient().send(call, HttpResponse.BodyHandlers.ofString());
            } catch (IOException again) {
                throw new IOException("OpenCode API " + path
                        + " closed the connection without an HTTP response (retried once). "
                        + "The OpenCode server may have crashed or restarted; use Legacy for the demo.", again);
            }
        }
        if (result.statusCode() >= 300 || result.statusCode() < 200) {
            String reason = "";
            try {
                JsonNode problem = mapper.readTree(result.body());
                JsonNode issue = problem.path("error").isObject() ? problem.path("error") : problem;
                reason = issue.path("data").path("message").asText(
                        issue.path("message").asText(issue.path("name").asText("")));
            } catch (Exception ignored) { /* HTTP status remains authoritative */ }
            throw new IllegalStateException("OpenCode HTTP " + result.statusCode() + " on " + path
                    + (reason.isBlank() ? "" : ": " + shortText(reason.replaceAll(
                    "(?i)(password|token|secret)=\\S+", "$1=[REDACTED]"), 250)));
        }
        if (result.body() == null || result.body().isBlank()) return mapper.createObjectNode();
        return mapper.readTree(result.body());
    }

    private static JsonNode unwrap(JsonNode result) { return result.has("data") ? result.path("data") : result; }
    private static String safeError(Exception e) {
        if (e == null) return "No response from the OpenCode server";
        String message = e.getClass().getSimpleName();
        if (e instanceof java.net.ConnectException) return "OpenCode 2 is not running on loopback";
        if (e instanceof java.net.http.HttpTimeoutException) return "OpenCode connection timed out";
        if (String.valueOf(e.getMessage()).contains("HTTP/1.1 header parser received no bytes"))
            return "OpenCode closed its HTTP connection before responding. Restart OpenCode or select Legacy; no execution was confirmed";
        return shortText(message + ": " + String.valueOf(e.getMessage())
                .replaceAll("(?i)(password|token|secret)=\\S+", "$1=[REDACTED]"), 700);
    }

    public Map<String,Object> launch(ChatRequest request, String handoff) {
        return launch(request, handoff, null);
    }

    public Map<String,Object> launch(ChatRequest request, String handoff,
            java.util.function.Consumer<String> notice) {
        if (!accepts(request)) throw new IllegalArgumentException("This instruction requires the ELIYA execution engine");
        if (request.message() == null || request.message().isBlank()) throw new IllegalArgumentException("Instruction is required");
        if (request.projectId() == null || request.projectId().isBlank())
            throw new IllegalArgumentException("Choose a mapped workspace");
        try {
            var project = projects.require(request.projectId());
            if (!project.hasLocalPath()) throw new IllegalArgumentException("Local workspace required");
            Path root = Path.of(project.getLocalPath()).toRealPath();
            if (!Files.isDirectory(root)) throw new IllegalArgumentException("Workspace is not a directory");
            ensureServer(notice);
            progress(notice, "Checking that OpenCode has a configured model");
            requireDefaultModel();
            progress(notice, "Opening an OpenCode session for the selected workspace");
            // Enforce project-only access at OpenCode's tool boundary, not merely by prompt instruction.
            List<Map<String,String>> permissions = new ArrayList<>();
            permissions.add(rule("*", "*", "allow"));
            permissions.add(rule("external_directory", "*", "deny"));
            permissions.add(rule("*mcp*", "*", "deny")); // gate MCP tools without blocking unrelated underscore-named tools
            permissions.add(rule("opencode_list_mcp_resources", "*", "deny"));
            permissions.add(rule("opencode_read_mcp_resource", "*", "deny"));
            for (String cmd : List.of("rm *", "rmdir *", "del *", "Remove-Item *", "git push *",
                    "git reset --hard *", "git clean *", "sudo *"))
                permissions.add(rule("shell", cmd, "deny"));
            JsonNode created = unwrap(request("POST", "/api/session", Map.of(
                    "title", shortText(request.message(), 90),
                    "agent", "build", // Execute must not inherit a user's read-only default Plan agent
                    "location", Map.of("directory", root.toString()), "permissions", permissions)));
            String remoteId = created.path("id").asText();
            if (!remoteId.matches("[A-Za-z0-9_-]{3,128}")) throw new IllegalStateException("Missing OpenCode session ID");
            // OpenCode must not silently substitute a read-only Plan agent for Execute.
            String selectedAgent = created.path("agent").asText("");
            if (!selectedAgent.isBlank() && !"build".equals(selectedAgent))
                throw new IllegalStateException("OpenCode selected agent '" + selectedAgent
                    + "' instead of executable 'build' agent. Check its workspace agent configuration.");
            String localId = "oc-" + UUID.randomUUID();
            Session session = new Session(localId, remoteId,
                    request.conversationId() == null ? UUID.randomUUID().toString() : request.conversationId(), request.projectId(),
                    "OpenCode configured default model", request.message());
            sessions.put(localId, session);
            persist(session);
            progress(notice, "Submitting the instruction to OpenCode");
            String instruction = (handoff == null || handoff.isBlank()) ? request.message()
                    : "Context from the preceding ELIYA analysis (for reference only):\n" + shortText(handoff, 4000)
                    + "\n\nCurrent user instruction (authoritative):\n" + request.message();
            submit(session, instruction);
            return session.snapshot();
        } catch (Exception e) {
            connectionStatus = "failed";
            throw new IllegalStateException("OpenCode launch failed: " + safeError(e)
                    + ". Select Legacy to continue safely; no new OpenCode task should be presumed completed.", e);
        }
    }

    private static Map<String,String> rule(String action, String resource, String effect) {
        return Map.of("action", action, "resource", resource, "effect", effect);
    }

    private void submit(Session session, String prompt) throws Exception {
        synchronized (session) {
            if (session.turnCount > 0 && Set.of("running", "queued", "needs_input").contains(session.status)) {
                throw new IllegalStateException("This OpenCode tab already has an active instruction. "
                        + "Open a separate Terminal tab for parallel work, or wait for this turn to finish. "
                        + "The running task has not been replaced or duplicated.");
            }
            session.status = "running";
            session.startedAt = Instant.now().toString();
            session.finishedAt = "";
            session.changeReport = Map.of();
            session.currentPrompt = prompt;
            session.events.clear(); // displayed action counts/reports belong to the new turn only
            session.lastPromptId = "";
            session.turnCount++;
            session.lastRemoteStatus = "Submitting prompt to OpenCode";
            session.answer = "";
            session.turns.addLast(Map.of("role", "user", "content", shortText(prompt, MAX_TEXT)));
            while (session.turns.size() > MAX_TURNS) session.turns.removeFirst();
            session.push("turn_start", Map.of("detail", "Submitting task to OpenCode"));
        }
        persist(session);
        try {
            JsonNode admission = unwrap(request("POST", "/api/session/" + session.remoteId + "/prompt", Map.of("text", prompt)));
            session.lastPromptId = admission.path("id").asText("");
            if (session.lastPromptId.isBlank())
                throw new IllegalStateException("OpenCode returned no admitted message ID; execution cannot be tracked safely");
            session.lastActivityNanos = System.nanoTime();
            session.lastRemoteStatus = "accepted; awaiting execution evidence";
            session.push("agent_step", Map.of("tool", "OpenCode", "step", "admission", "status", "success",
                    "detail", "OpenCode accepted the instruction and returned its message ID"));
            beginReader(session);
            beginMonitor(session); // reconnect if a previous event stream closed while the tab was idle
        } catch (IOException unknownAcceptance) {
            // A dropped POST connection does NOT establish whether the remote server
            // admitted the prompt. Keep the session/remote ID recoverable and offer
            // interrupt, rather than letting a user accidentally duplicate edits.
            session.status = "stalled";
            executionProven = false;
            session.error = "OpenCode prompt acceptance is unknown because its HTTP connection closed. "
                    + "The remote process may be executing. Stop this OpenCode session before retrying. "
                    + safeError(unknownAcceptance);
            session.lastRemoteStatus = "Prompt acceptance unknown; remote interruption recommended";
            session.push("agent_step", Map.of("tool", "connection", "step", "admission", "status", "warning",
                    "detail", session.error));
            persist(session);
        } catch (Exception e) {
            session.status = "failed";
            executionProven = false;
            session.error = safeError(e);
            session.push("error", Map.of("detail", session.error));
            persist(session);
            throw e;
        }
    }
    public Map<String,Object> message(String id, ChatRequest request) {
        Session session = require(id);
        if (request == null || request.message() == null || request.message().isBlank())
            throw new IllegalArgumentException("Message required");
        if (!Objects.equals(session.projectId, request.projectId()))
            throw new IllegalArgumentException("OpenCode session belongs to another workspace. Open a new tab.");
        if (!accepts(request)) throw new IllegalArgumentException("Use ELIYA Analyse or MCP workflow in a separate tab");
        try { submit(session, request.message()); return session.snapshot(); }
        catch (IllegalStateException e) { throw e; }
        catch (Exception e) { throw new IllegalStateException("Could not send instruction to OpenCode: " + safeError(e), e); }
    }

    public Map<String,Object> cancel(String id) {
        Session s = require(id);
        if ("completed".equals(s.status) || "cancelled".equals(s.status)) return s.snapshot();
        try {
            JsonNode interrupted = unwrap(request("POST", "/api/session/" + s.remoteId + "/interrupt?resume=false", null));
            // Only report cancellation after OpenCode acknowledges the interrupt request.
            boolean didInterrupt = !interrupted.isObject() || !interrupted.has("interrupted")
                    || !"false".equals(interrupted.path("interrupted").asText());
            if (!didInterrupt && remoteState(s) != RemoteState.IDLE)
                throw new IllegalStateException("OpenCode has not confirmed this task stopped; do not resubmit yet");
            s.status = "cancelled";
            executionProven = false;
            s.lastRemoteStatus = didInterrupt ? "OpenCode execution interrupted" : "Remote session already idle; local run closed";
            s.push("stopped", Map.of("detail", s.lastRemoteStatus));
            persist(s);
        } catch (Exception e) { s.error = safeError(e); persist(s); }
        return s.snapshot();
    }

    /** Independent remote-state reconciler. A quiet SSE stream is NOT a stalled task:
     * model calls can legitimately take minutes and the durable log can be unavailable.
     * Active sessions remain running until OpenCode reports a terminal event or the
     * session is confirmed idle with an attributable completed reply.
     */
    private void beginMonitor(Session s) {
        synchronized (s) {
            if (s.monitoring) return;
            s.monitoring = true;
        }
        readers.execute(() -> {
            final long inactiveSeconds = Math.max(20L, Long.getLong("eliya.opencode.stallSeconds", 90L));
            long lastCheckNanos = 0, lastNoticeNanos = 0, lastReconnectNanos = 0;
            try {
                while (!Thread.currentThread().isInterrupted() && "running".equals(s.status)) {
                    Thread.sleep(2000);
                    if (!"running".equals(s.status)) break;
                    long now = System.nanoTime();
                    if (!s.reading && now-lastReconnectNanos >= TimeUnit.SECONDS.toNanos(12)) {
                        lastReconnectNanos = now;
                        beginReader(s); // transient disconnects must not permanently blind the UI
                    }
                    if (now-lastCheckNanos < TimeUnit.SECONDS.toNanos(5)) continue;
                    lastCheckNanos = now;
                    // This is a best-effort source of live tool events, NOT a success oracle.
                    if (now-s.lastActivityNanos > TimeUnit.SECONDS.toNanos(5)) {
                        try { recoverLog(s); } catch (Exception ignored) { /* optional endpoint */ }
                    }
                    if (!"running".equals(s.status)) break;
                    RemoteState state = remoteState(s);
                    if (state != RemoteState.UNKNOWN) s.lastRemoteContactNanos = now;
                    if (state == RemoteState.ACTIVE) {
                        // Even a busy OpenCode task may expose tools in projected message history
                        // while the experimental event stream remains silent.
                        if (now-s.lastActivityNanos > TimeUnit.SECONDS.toNanos(5)) {
                            try { recoverMessages(s); } catch (Exception ignored) { /* optional projection */ }
                        }
                        s.lastRemoteStatus = "OpenCode confirms execution is active";
                        // A busy provider can be silent for arbitrarily long. Keep it running,
                        // show a heartbeat, and never mark it stalled solely by elapsed time.
                        if (now-lastNoticeNanos >= TimeUnit.SECONDS.toNanos(15)) {
                            lastNoticeNanos = now;
                            s.push("agent_step", Map.of("tool", "OpenCode", "step", "heartbeat", "status", "running",
                                    "detail", "OpenCode still executing; waiting for model/tool updates"));
                        }
                        continue;
                    }
                    // If SSE was lost, reconcile actual assistant tool steps and answer.
                    if (now-s.lastActivityNanos > TimeUnit.SECONDS.toNanos(5)) {
                        try { recoverMessages(s); } catch (Exception ignored) { /* try again later */ }
                    }
                    if (!"running".equals(s.status)) break;
                    if (state != RemoteState.ACTIVE && reconcileRemoteOutcome(s)) break;
                    if (state == RemoteState.IDLE) {
                        reconcileCompletion(s);
                        if (!"running".equals(s.status)) break;
                    }
                    long quiet = now-s.lastActivityNanos;
                    if (state == RemoteState.IDLE && quiet >= TimeUnit.SECONDS.toNanos(inactiveSeconds)) {
                        // Distinguish a proven idle session with no assistant completion from
                        // an active or unreachable session. Do not pretend it succeeded.
                        String remoteError = remoteErrorForCurrentTurn(s);
                        synchronized (s) {
                            if (!"running".equals(s.status)) break;
                            s.status = "stalled";
                            executionProven = false;
                            s.error = remoteError.isBlank()
                                    ? "OpenCode is idle but no reply for the admitted instruction was found. "
                                      + "No tool work was confirmed. Check the selected OpenCode model/provider and "
                                      + "the session error log; do not assume the edits occurred. "
                                      + "Local server: " + shortText(localRuntime.lastOutput(), 220)
                                    : remoteError;
                            s.lastRemoteStatus = "OpenCode idle without verified completion";
                            s.push("agent_step", Map.of("tool", "OpenCode", "step", "watchdog", "status", "warning", "detail", s.error));
                        }
                        persist(s); break;
                    }
                    if (state == RemoteState.UNKNOWN) {
                        long disconnectSeconds = Math.max(45L, Long.getLong("eliya.opencode.disconnectSeconds", 90L));
                        if (now - s.lastRemoteContactNanos >= TimeUnit.SECONDS.toNanos(disconnectSeconds)) {
                            s.status = "stalled";
                            s.error = "OpenCode has been unreachable for " + disconnectSeconds + " seconds. "
                                    + "The remote task may still be executing; ELIYA will not resubmit it automatically. "
                                    + "Reconnect or interrupt the original session before retrying.";
                            s.lastRemoteStatus = "Connection lost; remote execution unverified";
                            s.push("agent_step", Map.of("tool", "connection", "step", "watchdog",
                                    "status", "warning", "detail", s.error));
                            persist(s);
                            break;
                        }
                        s.lastRemoteStatus = "OpenCode status temporarily unavailable; reconnecting without resubmission";
                        if (now-lastNoticeNanos >= TimeUnit.SECONDS.toNanos(20)) {
                            lastNoticeNanos = now;
                            s.push("agent_step", Map.of("tool", "connection", "status", "warning", "step", "reconnecting",
                                    "detail", "Could not confirm remote status; original task may still be running. No duplicate prompt sent."));
                        }
                    } else {
                        s.lastRemoteStatus = "OpenCode idle; checking message history for current prompt";
                    }
                }
            } catch (InterruptedException interrupted) { Thread.currentThread().interrupt(); }
            finally {
                s.monitoring = false;
                // A following turn can arrive while the previous monitor is exiting.
                // Never leave the new turn without its own reconciler.
                if ("running".equals(s.status) && !readers.isShutdown()) beginMonitor(s);
            }
        });
    }

    /** Completion requires a reply tied to this specific user prompt, not merely an
     * execution.succeeded event replayed from an earlier turn. An implementation
     * request also requires independently observed file changes. */
    private void reconcileCompletion(Session s) {
        if (!"running".equals(s.status) || !remoteHasAssistant(s)) return;
        synchronized (s) {
            if (!"running".equals(s.status) || s.verificationInProgress) return;
            s.verificationInProgress = true;
            s.lastRemoteStatus = "Verifying OpenCode completion and workspace changes";
            s.finishTurn();
        }
        captureChangeReport(s);
        boolean mutation = requestsFileChanges(s.currentPrompt);
        boolean verifiedDiff = Boolean.TRUE.equals(s.changeReport.get("filesVerified"))
                && Boolean.TRUE.equals(s.changeReport.get("workspaceFilesVerified"));
        int changes = ((Number)s.changeReport.getOrDefault("created", 0)).intValue()
                + ((Number)s.changeReport.getOrDefault("modified", 0)).intValue()
                + ((Number)s.changeReport.getOrDefault("deleted", 0)).intValue();
        synchronized (s) {
            s.verificationInProgress = false;
            if (!"running".equals(s.status)) return;
            if (mutation && (!verifiedDiff || changes == 0)) {
                s.status = "stalled";
                executionProven = false;
                s.error = !verifiedDiff
                        ? "OpenCode returned a response, but its file diff could not be verified. "
                          + "No implementation success is claimed. Inspect the workspace before retrying."
                        : "OpenCode returned a response without any observed changed files for a requested implementation. "
                          + "The requested edits are not verified; inspect its response and workspace.";
                s.lastRemoteStatus = "Implementation not verified";
                Map<String,Object> incompleteReport = new LinkedHashMap<>(s.changeReport);
                incompleteReport.put("status", "stalled");
                incompleteReport.put("verificationWarning", s.error);
                s.changeReport = incompleteReport;
                s.push("agent_step", Map.of("tool", "verification", "step", "file-evidence",
                        "status", "warning", "detail", s.error));
            } else {
                s.status = "completed";
                s.lastRemoteStatus = "OpenCode response and workspace verification completed";
                executionProven = executionProven || (verifiedDiff && changes > 0)
                        || !((List<?>)s.changeReport.getOrDefault("steps", List.of())).isEmpty();
                s.push("done", Map.of("status", "completed", "detail", s.lastRemoteStatus));
            }
            Map<String,Object> finalReport = new LinkedHashMap<>(s.changeReport);
            finalReport.put("status", s.status);
            s.changeReport = finalReport;
        }
        persist(s);
    }

    private static boolean requestsFileChanges(String prompt) {
        return prompt != null && java.util.regex.Pattern.compile(
                "(?i)\\b(implement|create|write|fix|update|modify|refactor|generate|add|remove|"
                + "migrate|repair|patch|build|develop|edit|integrate|install|replace)\\b")
                .matcher(prompt).find();
    }

    /** OpenCode v2 persists the terminal outcome on the session itself. An idle server
     * with zero streamed events is not enough information to diagnose a failed task. */
    private boolean reconcileRemoteOutcome(Session s) {
        if (!"running".equals(s.status)) return false;
        try {
            JsonNode remote = unwrap(request("GET", "/api/session/" + s.remoteId, null));
            String outcome = remote.path("outcome").asText("");
            if (!Set.of("failed", "interrupted").contains(outcome)) return false;
            String reason = remoteErrorForCurrentTurn(s);
            if (reason.isBlank()) reason = "failed".equals(outcome)
                    ? "OpenCode reported a failed model/agent execution without a detailed response. "
                      + "Check its provider credentials, selected model, and local OpenCode logs."
                    : "OpenCode interrupted the execution.";
            synchronized (s) {
                if (!"running".equals(s.status)) return false;
                s.status = "failed".equals(outcome) ? "failed" : "cancelled";
                s.error = shortText(reason, 700);
                s.lastRemoteStatus = "OpenCode session outcome: " + outcome;
                executionProven = false;
                s.push("error", Map.of("detail", s.error, "source", "OpenCode session outcome"));
            }
            persist(s);
            return true;
        } catch (Exception unavailable) {
            // This diagnostic is supplemental; a network error is not a failed run.
            return false;
        }
    }

    /** Read only this turn's assistant errors; never attribute a previous prompt's
     * provider failure to the current prompt. */
    private String remoteErrorForCurrentTurn(Session s) {
        try {
            TurnHistory history = historyForPrompt(s);
            if (!history.found()) return "";
            for (JsonNode message : history.messages()) {
                JsonNode meta = message.path("info").isObject() ? message.path("info") : message;
                if (!"assistant".equals(meta.path("type").asText(meta.path("role").asText()))) continue;
                JsonNode error = meta.path("error");
                if (!error.isMissingNode() && !"null".equals(error.toString())) {
                    String detail = error.path("data").path("message").asText(
                            error.path("message").asText(error.path("name").asText(
                            error.path("type").asText(error.asText("")))));
                    if (!detail.isBlank()) return "OpenCode provider/agent error: " + detail;
                }
                String finish = meta.path("finish").asText("");
                if ("error".equals(finish)) return "OpenCode finished the assistant turn with an error";
            }
        } catch (Exception ignored) { /* best-effort diagnostic; not a success signal */ }
        return "";
    }

    private enum RemoteState { ACTIVE, IDLE, UNKNOWN }

    private RemoteState remoteState(Session s) {
        try {
            // OpenCode 2 explicitly defines /session/active as foreground drains.
            // If this API succeeds and the ID is absent, execution is not active.
            JsonNode active = unwrap(request("GET", "/api/session/active", null));
            if (active.isObject()) return active.has(s.remoteId) ? RemoteState.ACTIVE : RemoteState.IDLE;
            if (active.isArray()) {
                for (JsonNode item : active) {
                    if (s.remoteId.equals(item.asText(item.path("id").asText()))) return RemoteState.ACTIVE;
                }
                return RemoteState.IDLE;
            }
        } catch (Exception ignored) { /* do not infer idle on errors */ }
        return RemoteState.UNKNOWN;
    }

    /** Read OpenCode 2's cursor-based message history until the admitted user message.
     * A multi-step execution can generate hundreds of assistant/tool messages; a
     * single fixed-size page is not sufficient to prove completion or recover progress.
     * Bounded pagination prevents runaway requests against a damaged server. */
    private record TurnHistory(boolean found, List<JsonNode> messages) {}
    private TurnHistory historyForPrompt(Session s) throws Exception {
        if (s.lastPromptId.isBlank()) return new TurnHistory(false, List.of());
        List<JsonNode> currentTurn = new ArrayList<>();
        Set<String> usedCursors = new HashSet<>();
        String next = "";
        for (int page=0; page<8; page++) {
            String path = "/api/session/" + s.remoteId + "/message?limit=100";
            if (next.isBlank()) path += "&order=desc";
            else path += "&cursor=" + java.net.URLEncoder.encode(next, StandardCharsets.UTF_8);
            JsonNode response = request("GET", path, null);
            JsonNode body = unwrap(response);
            JsonNode items = body.isArray() ? body : body.path("items");
            if (!items.isArray()) items = body.path("messages");
            if (!items.isArray()) return new TurnHistory(false, currentTurn);
            for (JsonNode item : items) {
                JsonNode meta = item.path("info").isObject() ? item.path("info") : item;
                if (s.lastPromptId.equals(meta.path("id").asText()))
                    return new TurnHistory(true, currentTurn);
                currentTurn.add(item);
            }
            JsonNode cursor = response.path("cursor");
            if (!cursor.isObject()) cursor = response.path("data").path("cursor");
            next = cursor.path("next").asText("");
            if (next.isBlank() || !usedCursors.add(next) || items.size() == 0) break;
        }
        return new TurnHistory(false, currentTurn);
    }

    /** Recovers tool activity from projected messages when the SSE endpoint is absent,
     * and makes report details observable without fabricating steps or mutations. */
    private void recoverMessages(Session s) throws Exception {
        TurnHistory history = historyForPrompt(s);
        if (!history.found()) return; // Never attach an older task's actions.
        List<JsonNode> currentTurn = new ArrayList<>(history.messages());
        Collections.reverse(currentTurn);
        for (JsonNode item : currentTurn) {
            JsonNode meta = item.path("info").isObject() ? item.path("info") : item;
            if (!"assistant".equals(meta.path("role").asText(meta.path("type").asText()))) continue;
            String msgId = meta.path("id").asText("");
            JsonNode parts = item.path("content").isArray() ? item.path("content") : item.path("parts");
            if (!parts.isArray()) continue;
            for (JsonNode part : parts) {
                if (!"tool".equals(part.path("type").asText())) continue;
                String toolName = part.path("name").asText(part.path("tool").asText("tool"));
                String phase = part.path("state").path("status").asText("running");
                String partId = part.path("id").asText(Integer.toHexString(part.toString().hashCode()));
                String key = "history:" + msgId + ":" + partId + ":" + phase;
                synchronized (s) {
                    if (!s.seenIds.add(key)) continue;
                    s.lastActivityNanos = System.nanoTime();
                    String detail = part.path("state").path("title").asText("");
                    if (detail.isBlank()) detail = part.path("state").path("error").path("message").asText("");
                    if (detail.isBlank()) detail = "OpenCode " + toolName + ": " + phase;
                    s.push("agent_step", Map.of("tool", shortText(toolName,80), "step", "tool",
                            "status", phase, "detail", shortText(detail,350)));
                }
            }
        }
    }

    private boolean remoteHasAssistant(Session s) {
        // A previous assistant reply in a reused session is NOT evidence for
        // this task. Walk the OpenCode 2 paged, newest-first message history
        // back to the exact user message admitted for this turn.
        if (s.lastPromptId.isBlank()) return false;
        try {
            TurnHistory history = historyForPrompt(s);
            if (!history.found()) return false;
            String candidate = "";
            String candidateError = "";
            for (JsonNode item : history.messages()) {
                JsonNode meta = item.path("info").isObject() ? item.path("info") : item;
                if (!"assistant".equals(meta.path("type").asText(meta.path("role").asText()))) continue;
                JsonNode problem = meta.path("error");
                if (problem.isObject()) {
                    candidateError = problem.path("message").asText(
                            problem.path("data").path("message").asText(
                            problem.path("data").path("error").asText(
                            problem.path("name").asText(problem.path("type").asText("Model request failed")))));
                    break;
                } else if (problem.isTextual()) {
                    candidateError = problem.asText();
                    break;
                }
                JsonNode content = item.path("content").isArray() ? item.path("content") : item.path("parts");
                StringBuilder output = new StringBuilder();
                if (content.isArray()) for (JsonNode part : content) {
                    if ("text".equals(part.path("type").asText())) output.append(part.path("text").asText());
                }
                if (!output.isEmpty()) { candidate = output.toString(); break; }
            }
            if (!candidateError.isBlank()) {
                s.status = "failed";
                executionProven = false;
                s.error = shortText("OpenCode model/provider error: " + candidateError, 700);
                s.push("error", Map.of("detail", s.error));
                persist(s);
                return false;
            }
            if (candidate.isBlank()) return false;
            if (!candidate.equals(s.answer)) {
                s.answer = shortText(candidate, MAX_TEXT);
                s.push("agent_step", Map.of("tool", "OpenCode", "step", "answer", "status", "success",
                        "detail", "Assistant response retrieved from OpenCode message history"));
            }
            s.finishTurn();
            return true;
        } catch (Exception ignored) { /* no remote completion evidence */ }
        return false;
    }

    private void recoverLog(Session s) throws Exception {
        String cursor = s.lastLogEventId.isBlank() ? "" : "&after=" + java.net.URLEncoder.encode(s.lastLogEventId, StandardCharsets.UTF_8);
        HttpRequest req = HttpRequest.newBuilder(base.resolve("/api/experimental/session/" + s.remoteId + "/log?follow=false" + cursor))
                .timeout(Duration.ofSeconds(6)).header("Authorization", authorization)
                .header("Accept", "text/event-stream").GET().build();
        HttpResponse<String> res = http.send(req, HttpResponse.BodyHandlers.ofString());
        if (res.statusCode() != 200) return;
        String type = "", id = "";
        StringBuilder data = new StringBuilder();
        int count = 0;
        for (String line : res.body().split("\\r?\\n", -1)) {
            if (++count > 12000) break;
            if (line.isBlank()) {
                if (!data.isEmpty()) readEvent(s, type, id, data.toString());
                type = ""; id = ""; data.setLength(0);
            } else if (line.startsWith("event:")) type = line.substring(6).trim();
            else if (line.startsWith("id:")) id = line.substring(3).trim();
            else if (line.startsWith("data:") && data.length() < 500_000) {
                if (!data.isEmpty()) data.append('\n');
                data.append(line.substring(5).trim());
            }
            if (!"running".equals(s.status)) break;
        }
        if (!data.isEmpty() && "running".equals(s.status)) readEvent(s,type,id,data.toString());
    }

    private void beginReader(Session s) {
        if (s.reading) return;
        s.reading = true;
        readers.execute(() -> {
            try {
                // This experimental endpoint replays durable history then follows new events.
                String cursor = s.lastLogEventId.isBlank() ? "" : "&after=" + java.net.URLEncoder.encode(s.lastLogEventId, StandardCharsets.UTF_8);
                HttpRequest req = HttpRequest.newBuilder(base.resolve("/api/experimental/session/" + s.remoteId + "/log?follow=true" + cursor))
                        .timeout(Duration.ofHours(12)).header("Authorization", authorization)
                        .header("Accept", "text/event-stream").GET().build();
                HttpResponse<InputStream> response = http.send(req, HttpResponse.BodyHandlers.ofInputStream());
                if (response.statusCode() != 200) throw new IllegalStateException("OpenCode events HTTP " + response.statusCode());
                try (BufferedReader in = new BufferedReader(new InputStreamReader(response.body(), StandardCharsets.UTF_8))) {
                    String line, type = "", id = "";
                    StringBuilder data = new StringBuilder();
                    while (!Thread.currentThread().isInterrupted() && (line=in.readLine()) != null) {
                        if (line.isEmpty()) {
                            if (!data.isEmpty()) readEvent(s, type, id, data.toString());
                            type = ""; id = ""; data.setLength(0);
                        } else if (line.startsWith("event:")) type=line.substring(6).trim();
                        else if (line.startsWith("id:")) id=line.substring(3).trim();
                        else if (line.startsWith("data:") && data.length() < 2_000_000) {
                            if (!data.isEmpty()) data.append('\n'); data.append(line.substring(5).trim());
                        }
                    }
                }
            } catch (Exception e) {
                if ("running".equals(s.status)) {
                    s.push("agent_step", Map.of("tool", "connection", "status", "warning",
                            "detail", "Event stream disconnected; OpenCode execution may still be running"));
                    persist(s);
                }
            } finally { s.reading = false; }
        });
    }

    private void readEvent(Session s, String eventType, String eventId, String raw) {
        try {
            JsonNode outer = mapper.readTree(raw);
            // OpenCode 2 SessionLogItemEncoded is a JSON string (not a JSON object).
            if (outer.isTextual()) outer = mapper.readTree(outer.asText());
            JsonNode node = outer.has("properties") ? outer.path("properties") :
                    outer.has("data") ? outer.path("data") : outer;
            String type = outer.path("type").asText(outer.path("event").asText(eventType));
            if (type.equals("message") || type.equals("log") || type.isBlank())
                type = node.path("type").asText(node.path("event").asText(eventType));
            // Durable log envelopes can carry the actual event inside an `event` object.
            if (node.path("event").isObject()) {
                JsonNode nested = node.path("event");
                type = nested.path("type").asText(type);
                node = nested.path("properties").isObject() ? nested.path("properties") : nested;
            }
            if (eventId.isBlank()) eventId = outer.path("id").asText("");
            synchronized (s) {
                if (eventId.isBlank() && !type.endsWith("text.delta"))
                    eventId = "hash:" + Integer.toHexString(raw.hashCode()) + ":" + raw.length();
                if (!eventId.isBlank() && !s.seenIds.add(eventId)) return;
                if (s.seenIds.size() > 20000) s.seenIds.clear();
                if (!eventId.isBlank() && !eventId.startsWith("hash:")) s.lastLogEventId = eventId;
                // A server heartbeat must not reset the no-progress watchdog.
                if (type.contains("execution.") || type.contains("step.") ||
                    type.contains("tool.") || type.contains("text.delta") ||
                    type.contains("message.") || type.contains("part.") ||
                    type.contains("permission.") || type.contains("form.")) {
                    s.lastActivityNanos = System.nanoTime();
                    s.lastRemoteStatus = "Last verified activity: " + shortText(type, 80);
                }
                if (type.endsWith("text.delta")) {
                    String delta = node.path("text").asText(node.path("delta").asText(""));
                    if (delta.isBlank()) delta = node.path("content").asText("");
                    if (!delta.isEmpty()) {
                        s.answer = shortText(s.answer + delta, MAX_TEXT);
                        s.push("token", Map.of("text", shortText(delta, 8000)));
                    }
                } else if (type.endsWith("message.part.updated") || type.endsWith("part.updated")) {
                    JsonNode part = node.path("part").isObject() ? node.path("part") : node;
                    String partType = part.path("type").asText("");
                    if ("text".equals(partType) && part.path("text").isTextual()) {
                        String full = shortText(part.path("text").asText(), MAX_TEXT);
                        if (!full.isBlank() && !full.equals(s.answer)) {
                            s.answer = full;
                            s.push("agent_step", Map.of("tool", "OpenCode", "step", "response", "status", "running",
                                    "detail", "Receiving assistant response"));
                        }
                    } else if ("tool".equals(partType)) {
                        String toolName = part.path("tool").asText("tool");
                        String state = part.path("state").path("status").asText("running");
                        s.push("agent_step", Map.of("tool", shortText(toolName, 80), "step", "tool",
                                "status", state, "detail", "OpenCode tool " + shortText(state, 70)));
                    }
                } else if (type.endsWith("message.updated") || type.endsWith("session.status")) {
                    s.push("agent_step", Map.of("tool", "OpenCode", "step", "state", "status", "running",
                            "detail", shortText(type, 100)));
                } else if (type.endsWith("session.error")) {
                    s.status = "failed";
                    executionProven = false;
                    JsonNode issue = node.path("error");
                    s.error = shortText(node.path("message").asText(issue.path("data").path("message")
                            .asText(issue.path("message").asText(issue.path("type")
                            .asText(issue.asText("OpenCode provider execution failed"))))), 700);
                    s.push("error", Map.of("detail", s.error));
                } else if (type.contains("usage.updated")) {
                    s.usage = node;
                } else if (type.endsWith("execution.succeeded")) {
                    // Durable logs replay earlier turns. The success event is a hint,
                    // never proof of this instruction's completion or edits.
                    s.lastRemoteStatus = "OpenCode reported execution success; verifying current prompt and files";
                    s.push("agent_step", Map.of("tool", "OpenCode", "step", "verification", "status", "running",
                            "detail", "Checking the current reply and workspace changes"));
                } else if (type.endsWith("execution.failed")) {
                    // Do not let a delayed event change an already verified turn.
                    if (!"running".equals(s.status) || s.lastPromptId.isBlank()) return;
                    if (s.turnCount > 1 && !s.lastPromptId.equals(node.path("promptID")
                            .asText(node.path("userMessageID").asText("")))) return;
                    s.status = "failed";
                    executionProven = false;
                    JsonNode failure = node.path("error");
                    s.error = shortText(node.path("message").asText(failure.path("data").path("message")
                            .asText(failure.path("message").asText(failure.path("type")
                            .asText("OpenCode reported execution.failed; inspect the selected provider/model")))), 700);
                    s.push("error", Map.of("detail", s.error));
                } else if (type.endsWith("execution.interrupted")) {
                    s.status = "cancelled";
                    executionProven = false;
                    s.push("stopped", Map.of("detail", "Execution interrupted"));
                } else if (type.contains("tool.") || type.contains("step.")) {
                    String tool = node.path("tool").asText(node.path("name").asText(type));
                    String state = type.endsWith("failed") ? "error" : type.endsWith("success") ? "success" : "running";
                    s.push("agent_step", Map.of("tool", shortText(tool, 80), "step", "tool", "status", state,
                            "detail", shortText(type, 120)));
                } else if (type.equals("form.created") || type.equals("permission.asked")) {
                    s.status = "needs_input";
                    s.question = Map.of("kind", "clarification", "source", type.equals("permission.asked") ? "permission" : "form",
                            "id", node.path("id").asText(),
                            "reason", node.path("title").asText("OpenCode requires your input"));
                    s.push("agent_step", Map.of("tool", "question", "status", "approval",
                            "detail", "OpenCode needs a response"));
                }
            }
            if (type.endsWith("execution.succeeded")) {
                // An event may arrive ahead of the projected message history;
                // the monitor retries reconciliation without resubmitting work.
                reconcileCompletion(s);
            } else if (type.endsWith("execution.failed")) {
                captureChangeReport(s);
            }
            // Do not synchronously write a session JSON file for every streamed token.
            // The file stores only resumable references, not token-level transcripts.
            if (type.endsWith("execution.succeeded") || type.endsWith("execution.failed") ||
                type.endsWith("session.error") || type.endsWith("execution.interrupted") || type.equals("form.created") ||
                type.equals("permission.asked")) persist(s);
        } catch (Exception ignored) { /* invalid/non-session events never break activity rendering */ }
    }

    private void refreshAnswer(Session s) {
        try {
            JsonNode response = unwrap(request("GET", "/api/session/" + s.remoteId + "/message?type=assistant&order=desc&limit=5", null));
            JsonNode items = response.isArray() ? response : response.path("items");
            if (!items.isArray()) items = response.path("messages");
            for (JsonNode item : items) {
                JsonNode message = item.path("info").isObject() ? item.path("info") : item;
                if (!"assistant".equals(message.path("role").asText(message.path("type").asText()))) continue;
                JsonNode parts = item.path("content").isArray() ? item.path("content") : item.path("parts");
                StringBuilder answer = new StringBuilder();
                if (parts.isArray()) for (JsonNode part : parts) {
                    if ("text".equals(part.path("type").asText())) answer.append(part.path("text").asText());
                }
                if (answer.length()>0) { s.answer = shortText(answer.toString(), MAX_TEXT); s.finishTurn(); }
                break;
            }
        } catch (Exception ignored) { /* live text stream remains available */ }
    }

    /** Use OpenCode's recorded per-turn file diffs rather than inventing files from a model narrative.
     * Diff retrieval failures do not change the execution result, but remain visible to the user. */
    private void captureChangeReport(Session s) {
        Map<String,Object> result = new LinkedHashMap<>();
        result.put("status", s.status);
        result.put("objective", shortText(s.originalPrompt, 1200));
        result.put("verification", "File-change evidence from OpenCode session diff; on-disk content and build/test verification are separate");
        List<Map<String,Object>> evidenceSteps = new ArrayList<>();
        synchronized (s) {
            for (Map<String,Object> event : s.events) {
                if (evidenceSteps.size() >= 60) break;
                if (!"agent_step".equals(event.get("type"))) continue;
                Object raw = event.get("data");
                if (!(raw instanceof Map<?,?> entry)) continue;
                String stepType = String.valueOf(entry.get("step"));
                if (!"tool".equals(stepType)) continue;
                String status = String.valueOf(entry.get("status"));
                String tool = String.valueOf(entry.get("tool"));
                String detail = String.valueOf(entry.get("detail"));
                evidenceSteps.add(Map.of("status", Set.of("completed", "success").contains(status) ? "completed" : status,
                        "text", shortText(tool + " · " + detail, 300), "note", "Observed from OpenCode activity"));
            }
        }
        result.put("steps", evidenceSteps);
        result.put("planType", "opencode-observed-actions");
        List<Map<String,Object>> files = new ArrayList<>();
        int created=0, modified=0, deleted=0;
        boolean onDiskVerified = true;
        List<String> onDiskWarnings = new ArrayList<>();
        try {
            Path workspace = Path.of(projects.require(s.projectId).getLocalPath()).toRealPath();
            // Bind diffs explicitly to this prompt ID so a different turn's changes
            // cannot be presented as evidence for the current instruction.
            String from = java.net.URLEncoder.encode(s.lastPromptId, StandardCharsets.UTF_8);
            JsonNode diffs = unwrap(request("GET", "/api/session/" + s.remoteId
                    + "/diff?from=" + from + "&context=3", null));
            if (!diffs.isArray()) throw new IllegalStateException("OpenCode returned no per-file diff list");
            for (JsonNode diff : diffs) {
                if (files.size() >= 100) break;
                String action = diff.path("status").asText("modified");
                String relative = diff.path("file").asText("");
                // Verify OpenCode's claimed changes against the actual, mapped
                // workspace; never traverse outside it or follow escaping symlinks.
                try {
                    if (relative.isBlank()) throw new IOException("Diff file path is empty");
                    Path candidate = workspace.resolve(relative).normalize();
                    if (!candidate.startsWith(workspace)) throw new IOException("Diff path is outside workspace");
                    if ("deleted".equals(action)) {
                        if (Files.exists(candidate, LinkOption.NOFOLLOW_LINKS))
                            throw new IOException("Deleted file remains on disk");
                    } else {
                        if (!Files.isRegularFile(candidate, LinkOption.NOFOLLOW_LINKS))
                            throw new IOException("Changed file missing on disk");
                        Path real = candidate.toRealPath();
                        if (!real.startsWith(workspace)) throw new IOException("Changed file points outside workspace");
                        if (diff.path("additions").asInt(0) > 0 && Files.size(real) == 0)
                            throw new IOException("Changed file has no content");
                    }
                } catch (Exception fileProblem) {
                    onDiskVerified = false;
                    onDiskWarnings.add(shortText(relative + ": " + fileProblem.getMessage(), 350));
                }
                if ("added".equals(action)) created++;
                else if ("deleted".equals(action)) deleted++;
                else modified++;
                Map<String,Object> file = new LinkedHashMap<>();
                file.put("action", action);
                file.put("relativePath", shortText(relative, 450));
                file.put("detail", "+" + diff.path("additions").asInt(0) + " / -" + diff.path("deletions").asInt(0) + " lines");
                file.put("reason", "Modified during execution of the requested task; specific intent must be confirmed against the diff");
                file.put("excerpt", shortText(diff.path("patch").asText(""), 2000));
                files.add(file);
            }
            result.put("filesVerified", true);
            if (diffs.size() > files.size()) {
                onDiskVerified = false;
                result.put("fileReportWarning", "Showing first 100 changed files only; inspect the repository for the full diff");
            }
        } catch (Exception e) {
            result.put("filesVerified", false);
            onDiskVerified = false;
            result.put("fileReportWarning", "OpenCode per-file diff could not be retrieved: " + safeError(e));
        }
        result.put("workspaceFilesVerified", onDiskVerified);
        if (!onDiskWarnings.isEmpty()) result.put("workspaceWarnings", onDiskWarnings);
        result.put("created", created); result.put("modified", modified); result.put("deleted", deleted);
        result.put("files", files);
        s.changeReport = result;
        synchronized (s) { s.push("change_report", Map.of("files", files.size(), "verified", Boolean.TRUE.equals(result.get("filesVerified")))); }
    }

    public Map<String,Object> answer(String id, String questionId, String choice, String detail) {
        Session s = require(id);
        if (questionId == null || !questionId.equals(s.question.get("id")))
            throw new IllegalArgumentException("Question has expired");
        try {
            String remote = s.remoteId;
            String answer = detail == null || detail.isBlank() ? choice : detail;
            if (answer == null || answer.isBlank()) throw new IllegalArgumentException("Answer is required");
            // Form replies and permission responses use different documented endpoints.
            if ("permission".equals(s.question.get("source")) ||
                    "once".equalsIgnoreCase(choice) || "always".equalsIgnoreCase(choice) || "reject".equalsIgnoreCase(choice)) {
                // A natural-language yes/no reply to ELIYA's question maps to a one-time
                // permission decision, never blanket future approval.
                String normalized = answer.trim().toLowerCase(Locale.ROOT);
                String decision = Set.of("reject", "no", "n", "deny", "cancel").contains(normalized) ? "reject"
                        : "always".equalsIgnoreCase(choice) ? "always" : "once";
                request("POST", "/api/session/" + remote + "/permission/" + questionId + "/reply",
                        Map.of("decision", decision));
            } else {
                JsonNode info = unwrap(request("GET", "/api/session/" + remote + "/form/" + questionId, null));
                String fieldKey = "answer";
                JsonNode fields = info.path("fields");
                if (fields.isArray()) for (JsonNode field : fields) {
                    if ("string".equals(field.path("type").asText())) {
                        fieldKey = field.path("key").asText("answer"); break;
                    }
                }
                request("POST", "/api/session/" + remote + "/form/" + questionId + "/reply",
                        Map.of("answer", Map.of(fieldKey, answer)));
            }
            s.status = "running"; s.question = Map.of();
            s.lastActivityNanos = System.nanoTime();
            s.push("agent_step", Map.of("tool", "OpenCode", "step", "clarification", "status", "success",
                    "detail", "User response delivered to OpenCode; resuming execution"));
            persist(s);
            beginReader(s);
            beginMonitor(s);
            return Map.of("answered", true);
        } catch (Exception e) { throw new IllegalStateException("OpenCode question response failed: " + safeError(e), e); }
    }

    /** A question stays bound to the same session. The next natural-language response
     * must answer it rather than accidentally start another remote execution. */
    public Optional<String> pendingQuestionSession(String conversationId, String projectId) {
        if (conversationId == null || projectId == null) return Optional.empty();
        return sessions.values().stream().filter(s -> conversationId.equals(s.conversationId)
                && projectId.equals(s.projectId) && "needs_input".equals(s.status)
                && !s.question.getOrDefault("id", "").isBlank())
                .max(Comparator.comparing(s -> s.updatedAt)).map(s -> s.id);
    }

    /** Resume a conversation's own OpenCode session; never cross workspace boundaries. */
    public Optional<String> latestSession(String conversationId, String projectId) {
        if (conversationId == null || projectId == null) return Optional.empty();
        return sessions.values().stream().filter(s -> conversationId.equals(s.conversationId)
                && projectId.equals(s.projectId) && !Set.of("running","queued","needs_input","stalled").contains(s.status))
                .max(Comparator.comparing(s -> s.updatedAt)).map(s -> s.id);
    }

    public Map<String,Object> get(String id) { return require(id).snapshot(); }
    public List<Map<String,Object>> list() {
        return sessions.values().stream().sorted(Comparator.comparing((Session s)->s.updatedAt).reversed())
                .map(Session::snapshot).toList();
    }
    public Map<String,Object> activity(String id, Long before, Integer limit) {
        Session s = require(id);
        List<Map<String,Object>> events;
        synchronized (s) {
            events = s.events.stream().filter(e -> before == null || ((Number)e.get("seq")).longValue() < before).toList();
        }
        int count = Math.min(Math.max(limit == null ? 150 : limit, 1), 500);
        boolean more = events.size()>count;
        return Map.of("events", more ? events.subList(events.size()-count,events.size()) : events,
                "hasMore", more, "truncated", false, "journalError", false);
    }
    public SseEmitter stream(String id) {
        Session s = require(id);
        SseEmitter emitter = new SseEmitter(0L);
        if (s.viewers.size() >= 6) throw new IllegalStateException("Too many OpenCode viewers");
        s.viewers.add(emitter);
        emitter.onCompletion(() -> s.viewers.remove(emitter));
        emitter.onTimeout(() -> s.viewers.remove(emitter));
        emitter.onError(err -> s.viewers.remove(emitter));
        try { emitter.send(SseEmitter.event().name("terminal").data(Map.of("type", "resync"))); }
        catch (Exception ignored) { s.viewers.remove(emitter); }
        return emitter;
    }
    private Session require(String id) {
        Session s = sessions.get(id);
        if (s == null) throw new NoSuchElementException("OpenCode session not found");
        return s;
    }
    private void persist(Session s) {
        try {
            Files.createDirectories(store);
            Path temp = store.resolve(s.id + ".json.tmp");
            synchronized (s) { mapper.writeValue(temp.toFile(), s.snapshotForDisk()); }
            try { Files.move(temp, store.resolve(s.id + ".json"), StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (AtomicMoveNotSupportedException e) { Files.move(temp, store.resolve(s.id + ".json"), StandardCopyOption.REPLACE_EXISTING); }
        } catch (Exception ignored) { /* log failure must not interrupt OpenCode */ }
    }
    private static String shortText(String value,int max) { return value == null ? "" : value.length() <= max ? value : value.substring(value.length()-max); }

    private static final class Session {
        final String id, remoteId, conversationId, projectId, model, originalPrompt;
        String createdAt=Instant.now().toString();
        String startedAt=createdAt, finishedAt="";
        final Deque<Map<String,String>> turns = new ArrayDeque<>();
        final Deque<Map<String,Object>> events = new ArrayDeque<>();
        final Set<String> seenIds = new HashSet<>();
        final CopyOnWriteArrayList<SseEmitter> viewers = new CopyOnWriteArrayList<>();
        volatile String status="queued", error="", answer="", updatedAt=createdAt;
        volatile String lastPromptId = "";
        volatile String currentPrompt;
        volatile String lastRemoteStatus = "Request submitted, awaiting first model/tool event";
        volatile boolean reading, monitoring, verificationInProgress;
        volatile long lastActivityNanos = System.nanoTime();
        volatile long lastRemoteContactNanos = System.nanoTime();
        volatile Map<String,String> question=Map.of();
        volatile JsonNode usage;
        volatile Map<String,Object> changeReport = Map.of();
        long sequence;
        int turnCount;
        volatile String lastLogEventId = "";
        Session(String id, String remoteId, String conversationId, String projectId, String model, String prompt) {
            this.id=id;this.remoteId=remoteId;this.conversationId=conversationId;
            this.projectId=projectId;this.model=model;this.originalPrompt=prompt;this.currentPrompt=prompt;
        }
        synchronized void finishTurn() {
            if (!answer.isBlank() && (turns.isEmpty() || !"assistant".equals(turns.peekLast().get("role")))) {
                turns.addLast(Map.of("role","assistant","content",shortText(answer,MAX_TEXT)));
                while(turns.size()>MAX_TURNS) turns.removeFirst();
            }
        }
        synchronized void push(String type, Map<String,Object> data) {
            sequence++; updatedAt=Instant.now().toString();
            Map<String,Object> event = new LinkedHashMap<>();
            event.put("seq",sequence);event.put("type",type);
            if ("token".equals(type)) event.put("text",data.getOrDefault("text",""));
            else event.put("data",data);
            if (!"token".equals(type)) {
                events.addLast(event);
                while(events.size()>MAX_EVENTS) events.removeFirst();
            }
            // Only sanitized activity is sent to ELIYA, no provider headers or raw tool arguments.
            for (SseEmitter emitter : viewers) {
                try { emitter.send(SseEmitter.event().name("terminal").data(event)); }
                catch (Exception ignored) { viewers.remove(emitter); emitter.complete(); }
            }
        }
        synchronized Map<String,Object> snapshotForDisk() {
            Map<String,Object> disk = new LinkedHashMap<>(Map.of("id",id,"remoteId",remoteId,"conversationId",conversationId,"projectId",projectId,
                    "model",model==null?"":model,"fullPrompt",shortText(originalPrompt,MAX_TEXT),"updatedAt",updatedAt));
            disk.put("status", status);
            disk.put("createdAt",createdAt);
            disk.put("startedAt",startedAt);
            disk.put("finishedAt",finishedAt);
            disk.put("changeReport",changeReport);
            return disk;
        }
        synchronized Map<String,Object> snapshot() {
            Map<String,Object> result=new LinkedHashMap<>();
            boolean running = Set.of("queued", "running", "cancelling", "needs_input").contains(status);
            if (!running && finishedAt.isBlank()) finishedAt = Instant.now().toString();
            long elapsedMs=0;
            try {
                elapsedMs=Math.max(0,Duration.between(Instant.parse(startedAt),
                        running ? Instant.now() : Instant.parse(finishedAt)).toMillis());
            } catch (Exception ignored) { /* old session timestamps may be malformed */ }
            int observedActions=0;
            for (Map<String,Object> event : events) {
                if (!"agent_step".equals(event.get("type"))) continue;
                Object raw=event.get("data");
                if (raw instanceof Map<?,?> data
                        && !Set.of("connection", "OpenCode").contains(String.valueOf(data.get("tool")))
                        && !Set.of("heartbeat", "admission", "state", "watchdog", "reconnecting").contains(String.valueOf(data.get("step")))) {
                    observedActions++;
                }
            }
            // OpenCode does not expose total work units. This estimate uses observed
            // activity milestones, never an invented percent of a known plan.
            int progressPercent="completed".equals(status) ? 100
                    : observedActions <= 0 ? 0
                    : Math.min(90, 10 + (int)Math.round(80 * (1 - Math.exp(-observedActions / 12.0))));
            boolean indeterminate=running && observedActions==0;
            result.put("id",id); result.put("engine","opencode"); result.put("remoteId",remoteId);
            result.put("conversationId",conversationId); result.put("projectId",projectId);
            result.put("mode","agent");result.put("model",model);result.put("prompt",shortText(originalPrompt,120));
            result.put("fullPrompt",originalPrompt);result.put("createdAt",createdAt);result.put("updatedAt",updatedAt);
            result.put("startedAt",startedAt); result.put("finishedAt",finishedAt.isBlank()?null:finishedAt);
            result.put("elapsedMs",elapsedMs); result.put("progressPercent",progressPercent);
            result.put("progressEstimated",running && !indeterminate); result.put("progressPhase",status);
            result.put("status",status);result.put("error",error);result.put("answer",answer);
            result.put("lastRemoteStatus", lastRemoteStatus);
            result.put("turns",List.copyOf(turns));result.put("events",List.copyOf(events));
            result.put("sequence",sequence);result.put("question",question);result.put("queue",List.of());
            result.put("queueCount",0);result.put("queuePaused",false);result.put("runId","");
            result.put("referenceProjectIds",List.of());result.put("referenceProjectNames",Map.of());
            result.put("progress",Map.of("progressPhase",status,
                    "progressDetail",running ? (lastRemoteStatus + " · " + observedActions + " observed events · progress is estimated, not verified")
                            : (status.equals("stalled") ? error : status),
                    "progressPercent",progressPercent,
                    "indeterminate",indeterminate,
                    "estimated",running && !indeterminate,
                    "observedActions",observedActions));
            result.put("usage", usage == null ? Map.of() : usage);
            result.put("changeReport", changeReport);
            return result;
        }
    }

    @PreDestroy public void shutdown() {
        readers.shutdownNow();
        stopManagedProcess();
        for (Session s : sessions.values()) for (SseEmitter e : s.viewers) e.complete();
    }
}
