#!/usr/bin/env python3
"""
Browser check of the Guardian UI changes (CHANGES.md, "AI model connection" and "Pages to skip"):
  * Model settings: "Test connection" shows success, notes and failures (reason + fix) inside the role's card;
    "Key header" is saved; "Discover models" fills the list.
  * Suites: "Pages to skip" is saved with the suite and pre-filled in the Start execution form.

Usage:  GUARDIAN_TEST_BROWSER=/path/to/chrome python tests/ui_check.py visual-guardian.jar
Needs the Python Playwright package (it drives the installed Chrome; no browser download).
"""
import json, os, re, socket, subprocess, sys, tempfile, threading, time, urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from playwright.sync_api import sync_playwright

JAR = Path(sys.argv[1]).resolve()
BROWSER = os.environ.get('GUARDIAN_TEST_BROWSER', '/usr/bin/google-chrome')
passed = []


def check(name, ok, detail=''):
    if not ok:
        raise AssertionError(f'{name} -- {detail}')
    passed.append(name)
    print('PASS', name, flush=True)


class FakeLLM(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass

    def send(self, code, obj):
        data = json.dumps(obj).encode()
        self.send_response(code)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Content-Length', str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        if self.path == '/v1/models':
            return self.send(200, {'data': [{'id': 'local-small'}, {'id': 'local-large'}]})
        return self.send(404, {'detail': 'Not Found'})

    def do_POST(self):
        self.rfile.read(int(self.headers.get('Content-Length', 0)))
        if self.path == '/v1/chat/completions':
            return self.send(200, {'choices': [{'message': {'role': 'assistant', 'content': 'OK'}, 'finish_reason': 'stop'}]})
        return self.send(404, {'detail': 'Not Found'})


llm = ThreadingHTTPServer(('127.0.0.1', 0), FakeLLM)
threading.Thread(target=llm.serve_forever, daemon=True).start()

with tempfile.TemporaryDirectory() as td:
    sock = socket.socket(); sock.bind(('127.0.0.1', 0)); port = sock.getsockname()[1]; sock.close()
    base = f'http://127.0.0.1:{port}'
    proc = subprocess.Popen(['java', '-jar', str(JAR), '--port', str(port), '--data', str(Path(td) / 'data')],
                            stdout=subprocess.DEVNULL, stderr=subprocess.STDOUT)
    try:
        for _ in range(100):
            try:
                urllib.request.urlopen(base, timeout=1).read(); break
            except Exception:
                time.sleep(.2)
        args = ['--no-sandbox'] if hasattr(os, 'geteuid') and os.geteuid() == 0 else []
        with sync_playwright() as p:
            browser = p.chromium.launch(executable_path=BROWSER, headless=True, args=args)
            page = browser.new_page(viewport={'width': 1300, 'height': 900})
            page.goto(base)

            # ---- Model settings
            page.click('nav button[data-tab=models]')
            page.wait_for_selector('input[name=agent_endpoint]')
            agent = page.locator('#modelCards .card').first
            page.fill('input[name=agent_endpoint]', f'http://127.0.0.1:{llm.server_port}')   # no /v1: corrected automatically
            page.fill('input[name=agent_model]', 'local-small')
            page.fill('input[name=agent_keyHeader]', 'x-api-key')
            agent.get_by_role('button', name='Test connection').click()
            page.wait_for_selector('#modelCards .card >> nth=0 >> .modelResult.ok', timeout=20000)
            ok_text = agent.locator('.modelResult').inner_text()
            print('   agent card:', ok_text.replace('\n', ' | '), flush=True)
            check('a working connection is shown in the role card, with the answer and time', ok_text.startswith('Connected. local-small answered "OK" in'), ok_text)
            check('the card says the address needed /v1 and what to enter', f'http://127.0.0.1:{llm.server_port}/v1' in ok_text, ok_text)

            page.fill('input[name=agent_endpoint]', 'http://127.0.0.1:9/v1')
            agent.get_by_role('button', name='Test connection').click()
            page.wait_for_selector('#modelCards .card >> nth=0 >> .modelResult.error', timeout=20000)
            err_text = agent.locator('.modelResult').inner_text()
            notice = page.locator('#notice').inner_text()
            print('   agent card:', err_text.replace('\n', ' | '), flush=True)
            check('a failure shows the reason and the fix in the role card', 'connection refused' in err_text and 'model server is running' in err_text, err_text)
            check('the page notice shows the fix too', 'model server is running' in notice, notice)

            page.fill('input[name=agent_endpoint]', f'http://127.0.0.1:{llm.server_port}/v1')
            agent.get_by_role('button', name='Discover models').click()
            page.wait_for_selector('#modelCards .card >> nth=0 >> .discovered select', timeout=20000)
            options = agent.locator('.discovered select option').all_inner_texts()
            check('Discover models lists the server\'s models and says how many', 'local-large' in options and '2 models found' in agent.locator('.modelResult').inner_text(), str(options))

            page.reload()
            page.click('nav button[data-tab=models]')
            page.wait_for_selector('input[name=agent_keyHeader]')
            page.wait_for_function("document.querySelector('input[name=agent_endpoint]').value !== ''")
            check('Key header is saved with the settings', page.input_value('input[name=agent_keyHeader]') == 'x-api-key', page.input_value('input[name=agent_keyHeader]'))

            # ---- Pages to skip
            page.click('nav button[data-tab=suites]')
            page.click('#newSuite')
            page.fill('#createForm input[name=name]', 'UI skip suite')
            page.fill('#createForm input[name=url]', 'http://127.0.0.1:1/')
            page.fill('#createForm textarea[name=skipPages]', '/admin\ntitle: Audit log\n\nlabel: Delete')
            page.click('#createForm button[type=submit]')
            page.wait_for_selector('#suiteList article.card h3:has-text("UI skip suite")', timeout=10000)
            token = page.locator('meta[name=guardian-token]').get_attribute('content')
            req = urllib.request.Request(base + '/api/suites', headers={'X-Guardian-Token': token})
            suites = json.loads(urllib.request.urlopen(req).read())
            saved = next(s for s in suites if s['name'] == 'UI skip suite')['config'].get('skipPages')
            check('Pages to skip is saved with the suite (blank lines dropped)', saved == ['/admin', 'title: Audit log', 'label: Delete'], str(saved))
            page.locator('#suiteList article.card', has_text='UI skip suite').get_by_role('button', name='Capture baseline').click()
            page.wait_for_selector('#launchPanel:not([hidden])')
            prefilled = page.input_value('#launchForm textarea[name=skipPages]')
            check('the Start execution form is pre-filled with the suite\'s rules', prefilled == '/admin\ntitle: Audit log\nlabel: Delete', repr(prefilled))
            browser.close()
        print('TOTAL', len(passed), 'UI checks passed', flush=True)
    finally:
        proc.terminate()
        try:
            proc.wait(timeout=10)
        except subprocess.TimeoutExpired:
            proc.kill()
        llm.shutdown()
