# ASTRA Visual Guardian — validation

## 26 November 2026, release 3: AI connection, Pages to skip, Spring Boot front door (CHANGES.md, items 6–8)

Real Chrome for Testing 153 (headless, Linux), JDK 21 compiling with `--release 17`. Logs: `validation/2026-11-26-r3/`.
All earlier checks were repeated on the final build.

| Check | Previous version | This release |
|---|---|---|
| `tests/model_test_check.py`: Test connection / Discover models against 33 stand-in server situations (missing `/v1`, wrong or missing key, `x-api-key` gateway, Azure, newer-model parameters, thinking models, streamed or multi-part answers, sign-in page, redirect, timeout, refused connection, unknown host, HTTP/HTTPS mix-ups, company certificate authority, host-name mismatch) | 6 connected (2 of them returned junk as the answer); every failure was a bare "HTTP nnn" or an exception name | 33/33 |
| `tests/skip_pages.py`: path, title and label rules in capture; address and click-path exclusions in replay; never-requested pages checked on the server side; report and verdict | — | 16/16 |
| `tests/ui_check.py`: Model settings result line, Key header saved, Discover list, Pages to skip saved and pre-filled | — | 8/8 |
| Java and JS unit checks, now including `ModelChecks` (27) and `SkipChecks` (29) | 59/59 | 115/115 |
| Original end-to-end suite `tests/e2e.py` (built-in server now delegates to `Api`) | 33/33 | 33/33 |
| Sign-in, redirect, retry-limit and storage `tests/signin_fixes.py` | 15/15 | 15/15 |
| Controls that share a label `tests/locator_fixes.py` | 6/6 | 6/6 |
| Coverage lifecycle `tests/coverage_flow.py` (real Chrome) | 6/6 | 6/6, three more times 6/6 after the race fix below |
| Upgrade from data written by the original jar `tests/upgrade_check.py` | 12/12 | 12/12 |

Notes:

- During the first full run of this release, `coverage_flow.py` failed once with HTTP 400 "ConcurrentModificationException"
  on resume. Cause: start and resume answered with the run object that the new run thread was already changing (present
  since the original version). Fixed (CHANGES.md, "Also fixed"); the coverage flow then passed 4 times out of 4, including
  the final full run. The failing log is kept as `coverage-flow-first-run-race.log`.
- **Spring Boot front door: compiled, not run.** Package downloads were turned off in this environment, so Spring Boot
  could not be downloaded, built or started. The `spring/` classes were compiled with `-Xlint:all` (no warnings) against
  small stand-ins for the Spring and Servlet types they use; that checks the code against the expected method signatures
  but not Spring's runtime behaviour. Every endpoint goes through `Api`, which all tests above exercise through the plain
  jar. To verify: `mvn package`, then run the same tests with `target/visual-guardian-spring.jar` in place of
  `visual-guardian.jar` (it accepts the same `--port` and `--data` options).
- Not verified here: Windows certificate store and Windows proxy settings (the HTTPS check used `GUARDIAN_CA_FILE` with a
  private test authority), real model providers, Edge, native certificate/PIN dialogs, corporate SSO/MFA.


## 26 November 2026 update: controls that share a label (CHANGES.md, item 5)

Same setup as below: real Chrome for Testing 153 (headless, Linux) and `javac --release 17`. Logs are in `validation/2026-11-26/`. The 25 November checks were all repeated on this build.

| Check | Before this fix | After |
|---|---|---|
| `tests/locator_fixes.py`: repeated header/footer links, "Details"/"View" on every row, a changing "Alerts (N)" count, replay with rows reordered | 2 of 10 pages captured; 15 paths failed with "Ambiguous element" or "Element missing" | 6/6: all 10 pages, no locator failures; after the reorder every "View" opened the same person |
| Original end-to-end suite `tests/e2e.py` | — | 33/33 |
| Sign-in, redirect, retry-limit and storage fixes `tests/signin_fixes.py` | — | 15/15 |
| Coverage lifecycle `tests/coverage_flow.py` | — | 6/6 |
| Upgrade from data written by the original jar `tests/upgrade_check.py` | — | 12/12 |
| Java and JS unit checks (now including `LocatorEvidenceChecks` and `locator_context_dom.js`) | — | 59/59 |

The original safety checks still pass: "ambiguous locator rejected" and "ambiguous live elements never clicked".

## 25 November 2026 update: blocker fixes (see CHANGES.md)

Built with `javac --release 17` (JDK 21; class version 61, runs on Java 17). Browser tests used **real Chrome for Testing 153** (headless, Linux), not the mock CDP browser. Logs are in `validation/2026-11-25/`.

| Check | Original jar | Updated jar | Log |
|---|---|---|---|
| Original end-to-end suite `tests/e2e.py` (real Chrome) | 33/33 | 33/33 | `e2e-ORIGINAL-jar-real-chrome.log`, `e2e-real-chrome.log` |
| Sign-in, redirect, retry-limit and storage fixes `tests/signin_fixes.py` | Stuck in AWAITING_INPUT on the first capture (timed out after 120 s) | 15/15 | `signin-fixes-ORIGINAL-jar-real-chrome.log`, `signin-fixes-real-chrome.log` |
| Coverage lifecycle `tests/coverage_flow.py` (pointed at real Chrome) | — | 6/6 | `coverage-flow-real-chrome.log` |
| Upgrade: runs made by the original jar resumed, migrated, approved, replayed and exported by the updated jar `tests/upgrade_check.py` | — | 12/12 | `upgrade-from-original-real-chrome.log` |
| Java and JS unit checks (Locator, Coverage, Checkpoint, new Storage) | — | 47/47 | `unit-checks.log` |
| Checkpoint cost, synthetic 500 pages × 200 controls | run.json 41.9 MB, one save 449 ms | run.json 2.6 MB, one save 25 ms | `storage-timing.log` |

Notes:

- `tests/resume_checkpoint.py` was written for the mock browser. Pointed at real Chrome, the resumed run completed in 5 of 5 runs with the updated jar (`resume-checkpoint-5-runs-real-chrome.log`). Its final "at least 4 states" assertion depends on mock-only button behaviour (the fixture buttons change nothing in a real browser), and it fails the same way for the original jar.
- During testing, one resumed run failed at browser start with "Index 0 out of bounds for length 0". This was a race in reading `DevToolsActivePort`, present in the original code, and is now fixed. Once, before that fix, a status request returned HTTP 400 during browser start-up. It did not recur in 9 later runs or in a concurrency stress test of about 16,000 reads during 4,700 saves.
- Not verified here: Windows, Edge, native certificate/PIN dialogs, corporate SSO/MFA, Windows DPI fitting and real model endpoints. Verify these on your desktop.

---

## Earlier release: coverage and exploration validation

## Scope and build

This independent Java application is updated from `ASTRA_Visual_Guardian_Recovery.zip`. Eliya is a read-only architectural reference; neither its source nor its runtime is required. No new external Java runtime dependency was added. The JAR was rebuilt with `javac --release 17` (JDK 21 in the validation environment); class major version 61. JavaScript syntax validation, JAR archive validation and ZIP verification were performed. The package includes complete Java and frontend source, launch/build scripts and the test fixtures.

## Implemented changes

| Area | Result |
|---|---|
| Exploration capacity | UI starting budgets 500 states, 2,000 paths, depth 12; optional adaptive growth within 10,000 states, 20,000 paths and depth 30. Existing run budgets can be revised on resume. |
| Action classification | Navigation semantics distinguish payment module links from transaction actions; mutating controls remain restricted. Explicitly approved search-like submissions and exact read-only API paths supported. |
| Recovery | Re-evaluate eligible skipped actions using saved DOM evidence, retain prior screenshots and action journal, deduplicate completed and pending paths; increase bounded depth as necessary. |
| Model intelligence | User-selected Agent model ranks candidates and can advise on uncertain actions, only with data-sharing authorization. Advice never overrides policy. |
| Coverage | Group by first navigation action; show captured, pending, failed, duplicate, review and exclusion counts; reconcile optional expected exact route list. |
| Quality gate | REVIEW_REQUIRED status until exclusions reviewed; approval checks pending paths, failures, expected routes, screenshot hashes and DOM/path evidence. Exclusions never count as passed tests. |
| Browser | New visible-browser captures attempt native viewport fitting, lock dimensions and device scale; existing runs preserve their prior geometry. Bounded vertical scroll actions are captured and replayable. |
| Reports | Grouped exception review and coverage tables, readable journey descriptions, pending paths, screenshot evidence and Excel exception rows. |
| Replay | Preserve baseline capture geometry; explicit opt-in to reuse approved read-only path/label settings for equivalent target scope. |

## Validation method

The automated browser integration uses a **mock CDP browser protocol** and deterministic local model fixture. This verifies the actual application orchestration, HTTP API, persistence, package handling, comparison and report generation, not a real corporate browser. The JS locator and scroll checks execute the generated scripts against small synthetic DOM fixtures. The filesystem check provokes a real transient replacement error on Linux, not a Windows file lock. The final JAR is tested by the focused coverage lifecycle fixture; broader regression tests were also run on earlier candidates of this update. Detailed logs distinguish these runs.

## Final-artifact checks

- `coverage-unit.log`: 20 passed, including payment navigation, mutation restrictions, approved search, adaptive budgets and depth, expected route reconciliation, legacy skipped-action recovery, explicit exclusion review, scroll matching and execution.
- `coverage-flow.log`: 6 passed on the final JAR: partial capture, preserved screenshot and recovered legacy skip, review gate, explicit exclusion review, HTML report, replay with approved read settings and fixed viewport.
- `checkpoint-coverage.log`: 8 passed (persistent journal, deduplication, issue cleanup, filesystem retry).
- `locator-coverage.log`: 9 passed (Java locator recovery and synthetic DOM action tests).
- `coverage-resume-final.log`: 3 passed on the final build (legacy queue deduplication, preserved screenshots, journal continuity).
- Total final-artifact targeted checks: 46 passed, with zero Java compilation errors. No claim is made that all possible application flows are covered.

## Broader regression

`coverage-integration.log`: all 34 checks passed on an earlier candidate of this update. It exercised model discovery and Vision payload, baseline capture and approval review, portable ZIP integrity and import, unchanged-app replay, injected regressions, selective reruns, offline comparison, HTML/Excel, authentication waiting, manual handover, stop and resume. The final build additionally introduces explicit REVIEW_REQUIRED status and approved read-only policy reuse, covered by the final focused tests. Older Recovery release logs are retained only as historical evidence, not added to the final check count.

## Release qualification and remaining limits

The application is a launchable, locally validated functional implementation, **not production-certified**. A previous real Chromium navigation attempt was blocked by administrator policy (`net::ERR_BLOCKED_BY_ADMINISTRATOR`), documented in `real-browser-blocked.log`; corporate Chrome/Edge, native SSO/certificate/PIN, actual Windows DPI fitting and the deployed Qwen/Vision endpoint still require local verification. The model classifies uncertain actions for review; it does not autonomously approve data-changing requests or provide a generalized live question/approval queue. Nested scrolling is bounded and does not guarantee coverage of virtualized content, iframes, shadow DOM or canvas. Existing screenshots retain their original geometry. If corrected viewport sizing or new scroll discovery is required on already-captured pages, create a separate fresh baseline; never mix screenshot geometries. Some old skipped entries lacking a state or path reference may still need manual review. Exact expected routes are optional; a complete business-flow inventory must be supplied and independently verified. No enterprise-scale capacity or archive-size expansion has been demonstrated; use scoped suites for large evidence sets.

## Upgrade

Back up `guardian-data`; stop the previous installation and close editors holding run.json. Extract into a separate folder; copy the saved data folder or point the launcher at it using `--data`. Existing data formats are retained. For the incomplete BMS capture, use Resume / recover coverage, choose initial budgets (e.g. 2,000 states, 10,000 paths, depth 12), enable adaptive growth, and enter only application-owner-approved read-only API paths and labels. Authorize model data only when allowed. Authenticate again if required. Review remaining exclusions before approving the baseline. Original captured screenshots remain unchanged, and prerequisite navigation may be repeated to re-establish browser state.
