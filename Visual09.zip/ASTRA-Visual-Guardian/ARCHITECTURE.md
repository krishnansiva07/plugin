# How ASTRA Visual Guardian works

This is the map of the current implementation, so you can decide which features to keep, change or remove.
Section 9 is a checklist for exactly that. Section 10 covers the Spring Boot version.

## 1. What it does, in one paragraph

You give it an application URL. It opens an installed Chrome or Edge, lets you sign in by hand (SSO, PIN,
certificate prompts), then clicks through the application on its own, read-only, and records every distinct
screen: a screenshot plus a text outline of the page. You review and approve that recording as the **baseline**.
After the migration or deployment you run it again against the new system: it replays the same click paths,
records the same screens and compares each one with the baseline (pixels, page outline, address). The report
lists every page that changed, with before/after/difference images. No AI is needed; three optional AI roles can
help (section 7).

## 2. The pieces

```
 Browser UI (resources/index.html, app.js, style.css)
        │  HTTP on 127.0.0.1 only, session token on every call
        ▼
 Front door ── Main.java (built-in Java HTTP server, no dependencies)
            └─ spring/guardian/boot/* (Spring Boot controllers)   ← same endpoints, same answers
        │
        ▼
 Api.java ── every endpoint, without any web server
        │
        ├── Engine.java ── runs executions: explore, sign-in pauses, replay, compare
        │      ├── Browser.java  ── drives Chrome/Edge over the DevTools protocol (CDP)
        │      ├── Skips.java    ── "Pages to skip" rules
        │      ├── Coverage.java ── what was not explored and why; review gate before approval
        │      └── Models.java   ── optional AI roles (OpenAI-compatible API)
        ├── Store.java  ── files under guardian-data/ (suites, runs, screenshots, exports)
        └── Report.java ── report.html and report.xlsx
 Json.java, Util.java ── small helpers (JSON reader/writer, hashing, safe paths, atomic file writes)
```

| File | Size | What it owns |
|---|---|---|
| `Engine.java` | largest | Run lifecycle, exploration loop, replay loop, sign-in handling, locator matching, comparison |
| `Browser.java` | large | Starting the browser, page readiness, reading a page (`INSPECT` script), clicking (`actionScript`), screenshots, network policy |
| `Store.java` | medium | Data folder layout, run and state files, locking, export/import ZIPs, summaries cache |
| `Coverage.java` | medium | Coverage exceptions, review, approval checks, resume recovery, adaptive limits |
| `Report.java` | medium | Verdict, HTML report, Excel report |
| `Models.java` | medium | AI settings, connection test, discovery, calls, error explanations, proxy and certificates |
| `Api.java` | medium | Endpoints, request checks, UI pages, error answers |
| `Skips.java` | small | Parsing and matching "Pages to skip" rules |
| `Main.java` | small | Built-in HTTP server and command-line options |

The engine code is dense (long single lines); the files changed in this release are formatted normally.

## 3. A run from start to finish

```
 Suite (URL + settings)
   │
   ├─► CAPTURE ─► explore ─► REVIEW_REQUIRED or COMPLETED ─► review exceptions ─► Approve = baseline
   │
   └─► REPLAY (against the new URL, using an approved baseline) ─► per page: PASSED / FAILED / … ─► report
```

Run statuses: `QUEUED`, `RUNNING`, `AUTHENTICATING`, `AWAITING_INPUT` (waiting for you, e.g. sign-in),
`PAUSED`, `COMPLETED`, `REVIEW_REQUIRED` (capture finished but some skipped actions need your review),
`INCOMPLETE`, `STOPPED`, `INTERRUPTED` (app closed mid-run; can be resumed), `ERROR`, `IMPORTED`.

Commands while running: pause, continue, manual (hand the browser to you), skip (the current step), stop.
Every run checkpoints to disk continuously, so it can be **resumed** after a crash or restart.

## 4. Exploration (capture)

1. Open the start URL. If the page asks for sign-in, pause in `AWAITING_INPUT` and let you sign in (section 5).
2. Read the page with the `INSPECT` script: title, headings, visible text, dialogs and every visible control
   (links, buttons, tabs, menus, selects, inputs) with its label, role, link address, row text and a CSS path.
3. Fingerprint the page: address route + title + page outline. A fingerprint seen before is a duplicate and is not
   recorded again.
4. Record the state: screenshot + outline, saved to `runs/<id>/states/<state>.json` and `images/<state>.png`.
5. Choose controls to try next (`Engine.candidates`):
   - **clicked**: navigation links, tabs, menu items, expanders, read-like buttons (View, Details, Search, Next…),
     options of selects outside forms, scroll regions;
   - **set aside** (each listed as a coverage exception with its reason): disabled controls, external or new-tab
     links, links with query strings, anything that looks like it changes data (Delete, Save, Submit, Pay, Order,
     Export, Logout…), inputs and forms (they need approved test data), unclassified controls;
   - **skipped by your rules**: links and controls matching "Pages to skip" (section 6).
6. Optionally ask the Agent model to order the candidates (it can only reorder; it cannot add actions).
7. Queue one new click path per candidate: "path to this page + this click". The queue is breadth-first.
8. Take the next path: reuse the live page if possible, otherwise start from the home page and replay the clicks.
   Stop at the depth, state or action limits (adaptive growth is optional).

**Read-only network policy** (`Browser.intercept`): during automatic exploration every request is checked. Allowed:
page loads on the application's own hosts; GET/HEAD/OPTIONS that do not look destructive; POST only to paths you
approved as read-only. Anything else is blocked and the path is set aside. While you are signing in, nothing is
blocked.

## 5. Sign-in and manual steps

- Sign-in is detected from strong signals: a password field, a one-time-code field, a login form, a sign-in button,
  configured sign-in addresses, or a learned sign-in route. Optional "logged-in marker" CSS selector confirms you are in.
- Guardian pauses in `AWAITING_INPUT`; you complete SSO, PIN, MFA or certificate prompts in the visible browser and
  press **Return control / Start agent** in the UI. Pressing it twice on the same page tells Guardian "this is not a
  sign-in page" and it remembers that.
- A path that keeps asking for sign-in is retried twice with a fresh sign-in, then set aside (capture) or failed (replay).
- Redirects to the same host on another port or scheme, and the hosts you list as "Other application hosts", count
  as the application, not as leaving it.

## 6. Pages to skip (new)

One rule per line in the suite (or per execution). Matching ignores case.

| Rule | Skips |
|---|---|
| `/admin` | `/admin`, `/admin/users`, `/admin?tab=x`; not `/administrator` |
| `/reports/*/export` | `*` matches anything |
| `#/settings` | single-page-app routes after `#` |
| `https://host/legacy` | that address and everything below it |
| `logout` | any address containing the text |
| `title: Audit log` | pages whose title contains the text |
| `label: Delete` | links and buttons whose text contains the text |

Capture never clicks a matching link or control. A page reached some other way (e.g. by a button) that matches is
not recorded or explored; for `title:` rules the page has to open once to read its title. Replay marks matching
baseline pages `EXCLUDED` without opening them, including pages whose recorded click path passes through a skipped
control. Skips are listed in the report as "Skipped by suite setting: rule", need no coverage review, and an
execution with exclusions can still PASS ("PASS — …; 3 excluded by suite setting").

## 7. Replay and comparison

For each baseline page: replay its click path on the target, then compare (`Engine.compareState`):

- **pixels**: a pixel differs when any colour channel differs by more than 20 (`pixelChannelDelta`); the page fails
  when more than 0.5 % of pixels differ (`pixelTolerance`). Mask selectors hide dynamic areas (dates, names).
- **outline**: visible text, headings, dialogs and each control's role, label and state; any line added or removed fails.
- **address**: the route must match (can be turned off with `compareRoutes`).

Result statuses: `PASSED`, `FAILED` (difference found; diff image saved), `INCONCLUSIVE` (e.g. blocked by policy or
an ambiguous control), `ENVIRONMENT_ERROR`, `NOT_EXECUTED`, `EXCLUDED` (your skip rules).
Verdict: any FAILED → "FAIL — regressions detected"; anything not PASSED/EXCLUDED → "INCONCLUSIVE / PARTIAL";
otherwise "PASS — selected captured states only".

**Finding the same control on the new system** (`Engine.match`), in this order: stable id/test id; a single control
with the same role and label; same label and link address; same-address links; the text of its table row or list
item; (capture only) exact position; label ignoring counters like "(3)". If none of these single it out, the step
fails as "Ambiguous element" instead of guessing.

## 8. AI roles (optional)

| Role | Used for | Sent to the model |
|---|---|---|
| Agent | ordering candidate controls; advice on uncertain set-aside controls | control labels and roles |
| Vision | describing differences on FAILED pages | the baseline and target screenshots |
| Reviewer | a plain-language summary of a failure | the comparison numbers and the Vision text |

Nothing is sent unless the execution has "Permit sanitized labels and masked screenshots to be sent…" ticked. Models never override a verdict or a safety
rule. After 3 failed requests a role is switched off for the rest of the execution, so a broken model server
cannot add a timeout to every page. Connection problems are explained in the UI (see README, "AI models").

## 9. Feature checklist — mark what to keep, change or remove

| # | Feature | Where | Note if removed |
|---|---|---|---|
| 1 | Built-in server (no dependencies) | `Main.java` | Spring Boot would be the only way to run |
| 2 | Spring Boot front door | `spring/`, `pom.xml` | |
| 3 | Manual sign-in pause (SSO, PIN, certificates) | `Engine.authenticate`, UI | |
| 4 | Automatic sign-in detection + "Return twice" override | `Engine.signInReasons` | You would press Return every time |
| 5 | Read-only network policy | `Browser.intercept` | Exploration could trigger real changes |
| 6 | Mutation-word safety list (Delete, Save, Order…) | `Engine.mutationVerb/dangerous` | Could be made configurable |
| 7 | Approved read-only POST/GET paths and labels | suite settings | Search forms would be skipped |
| 8 | Pages to skip | `Skips.java` | |
| 9 | Adaptive exploration limits | `Coverage.extend` | Fixed limits only |
| 10 | Scroll-region capture | `Engine.candidates`, `Browser` | |
| 11 | Coverage review gate before approval | `Coverage` | Baselines could be approved with unexplained gaps |
| 12 | Expected routes check | suite setting `expectedRoutes` | |
| 13 | Pixel comparison with masks | `compareState` | |
| 14 | Page-outline comparison | `structure` | Text-only changes would be missed |
| 15 | Route comparison | `compareRoutes` | |
| 16 | Rerun failed / incomplete pages only | `Engine.start` | |
| 17 | Resume after crash (checkpoints) | `Engine`, `Store` | |
| 18 | Export/import baseline ZIPs (move baselines between machines) | `Store.exportRun/importZip` | |
| 19 | HTML report | `Report` | |
| 20 | Excel report | `Report.xlsx` | |
| 21 | Compare any two runs | `Engine.compareRuns` | |
| 22 | AI Agent ordering + advice | `Models`, `Engine.rank`, `Coverage.advise` | |
| 23 | AI Vision description of differences | `Engine.vision` | |
| 24 | AI Reviewer summary | `Engine.vision` | |
| 25 | Viewport fitting / locked device scale | `Browser.applyViewport` | |

Ideas not built yet, if useful: scheduled runs, comparing against a URL list instead of exploring, ignoring
regions by drawing on a screenshot, email/Teams notification, a CI command-line mode, Playwright instead of CDP
(adds Firefox/WebKit; needs a driver download), test data for forms.

## 10. Spring Boot

**Now:** `pom.xml` + `spring/guardian/boot/` add a Spring Boot 4.1 front door around the same engine:

| Plain jar | Spring Boot |
|---|---|
| `Main.handle` (Java HTTP server) | `PageController`, `SuiteController`, `RunController`, `ModelController`, `FallbackController` |
| Host / token / Origin checks in `Main` | `LocalOnlyGuard` (HandlerInterceptor), plus a non-local caller check |
| `catch` in `Main.handle` | `ApiErrors` (`@RestControllerAdvice`) |
| `--port`, `--data` | same options, or `--server.port=`, `--guardian.data=` |
| `Main` locks the data folder | `Api` bean (`destroyMethod = close`) |

Both call `Api`, so answers are identical. Build: `mvn package` → `target/visual-guardian-spring.jar`.
The plain build (`build.cmd` / `build.sh`) is unchanged and needs no downloads.

**Full conversion (next step, once you have chosen features):** move to the standard Maven layout
(`src/main/java/com/astra/guardian/...`), split `Engine` into services (`ExplorationService`, `ReplayService`,
`SignInService`, `ComparisonService`), make settings typed `@ConfigurationProperties` records, replace the hand-written
JSON with Jackson, add `@SpringBootTest` + MockMvc tests and run the real-browser tests in CI, and optionally swap
CDP for Playwright Java.

## 11. Data on disk (`guardian-data/`)

```
guardian-data/
  .lock                      only one Guardian per folder
  models.json                AI settings (never the keys)
  suites/<suite>.json        URL, settings, approved baselines
  runs/<run>/run.json        status, queue, journal, results, events (light; checkpointed)
  runs/<run>/states/*.json   page detail (outline, controls) per state
  runs/<run>/images/*.png    screenshots      diffs/*.png   difference images
  runs/<run>/report.html     report.xlsx
```

## 12. Where to make common changes

- **New suite setting**: `Store.config` (sanitise it), `index.html` + `app.js` (form field), use it in `Engine`;
  add it to the resume list in `Engine.resume` if it may change on resume.
- **New endpoint**: a method in `Api` + a case in `Api.get/post` (plain jar) + a controller method (Spring Boot).
- **Change what gets clicked**: `Engine.candidates` (classification) and `Engine.mutationVerb/dangerous` (word lists).
- **Change the comparison**: `Engine.compareState` and `Engine.structure`.
- **Change the report**: `Report.write` (HTML) and `Report.xlsx`.
- **Tests**: `tests/` — Java unit checks and real-browser Python checks (see VALIDATION.md for commands).
