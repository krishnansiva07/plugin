let roadmap=null,currentIndex=0,currentTopic='',currentCategory='CUSTOM',quiz=null;
const $=id=>document.getElementById(id);

async function post(url, body){
  const res=await fetch(url,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
  return await res.json();
}

async function generateRoadmap(){
  const prompt=$('search').value.trim()||'SEPA Payment';
  roadmap=await post('/api/learning/roadmap',{userPrompt:prompt,level:'Beginner',purpose:'General Learning'});
  currentCategory=roadmap.category||'CUSTOM';
  $('courseTitle').innerText=roadmap.title||'Learning Path';
  renderModules();
  openModule(0);
}

function renderModules(){
  const box=$('modules'); box.innerHTML='';
  (roadmap.modules||[]).forEach((m,i)=>{
    const div=document.createElement('div');
    div.className='module '+(i===currentIndex?'active ':'')+(m.status==='GENERATED'?'done':'');
    div.innerText=(i+1)+'. '+m.title;
    div.onclick=()=>openModule(i);
    box.appendChild(div);
  });
  updateProgress();
}

async function openModule(i){
  currentIndex=i; renderModules();
  const m=roadmap.modules[i]; currentTopic=m.title;
  if(m.title.toLowerCase().includes('quiz')){ await startQuiz(); return; }
  const data=await post('/api/learning/content',{topic:roadmap.title,subTopic:m.title,category:roadmap.category,level:roadmap.level,purpose:roadmap.purpose});
  m.status='GENERATED'; renderContent(data); renderModules();
}

function renderContent(data){
  $('topicTitle').innerText=data.title||currentTopic;
  $('summary').innerText=data.shortSummary||'';
  $('tabs').innerHTML=(data.tabs||[]).map((t,i)=>`<div class="tab ${i===0?'active':''}">${t}</div>`).join('');
  $('sections').innerHTML=''; $('onPage').innerHTML='';
  (data.sections||[]).forEach((s,i)=>{
    $('onPage').innerHTML+=`<li>${s.heading}</li>`;
    const div=document.createElement('div'); div.className='section';
    let body='';
    if(s.type==='code') body=`<pre class="code">${escapeHtml(s.content||'')}</pre>`;
    else if(s.type==='steps') body=`<ol>${(s.items||[]).map(x=>`<li>${x}</li>`).join('')}</ol>`;
    else if(s.type==='keyValue') body=(s.items||[]).map(x=>`<div class="kv"><b>${x.key}</b><span>${x.value}</span></div>`).join('');
    else body=`<p>${s.content||''}</p>`;
    div.innerHTML=`<h3>${i+1}. ${s.heading}</h3>${body}`;
    $('sections').appendChild(div);
  });
  renderDiagram(data.diagram);
  $('related').innerHTML=(data.relatedTopics||[]).map(x=>`<span class="relatedItem" onclick="deepDive('${x}')">↗ ${x}</span>`).join('');
  $('quizBox').classList.add('hidden'); $('certificateBox').classList.add('hidden');
}

function renderDiagram(d){
  if(!d||!d.nodes){$('diagram').innerHTML='';return;}
  let html='';
  d.nodes.forEach((n,i)=>{html+=`<div class="node">${icon(n.icon)}<br>${n.label}</div>`; if(i<d.nodes.length-1) html+='<div class="arrow">→</div>';});
  $('diagram').innerHTML=html;
}
function icon(i){return i==='bank'?'🏦':i==='user'?'👤':i==='network'?'🌐':i==='box'?'📦':'●'}
async function deepDive(topic){const data=await post('/api/learning/content',{topic:roadmap.title,subTopic:topic,category:roadmap.category,level:roadmap.level,purpose:roadmap.purpose});renderContent(data)}
function nextTopic(){if(roadmap&&currentIndex<roadmap.modules.length-1)openModule(currentIndex+1)}
function previousTopic(){if(roadmap&&currentIndex>0)openModule(currentIndex-1)}
async function explainSimpler(){await deepDive('Explain '+currentTopic+' in very simple English')}
function addNote(){alert('Note saved locally for demo. Connect DB later.')}

async function startQuiz(){
  quiz=await post('/api/learning/quiz',{topic:roadmap?roadmap.title:($('search').value||'Topic'),level:'Beginner',purpose:'General Learning'});
  $('quizBox').classList.remove('hidden'); $('certificateBox').classList.add('hidden');
  $('topicTitle').innerText=quiz.title||'Quiz'; $('summary').innerText='Pass mark: 80%. Answer the questions and submit.';
  let html='<h2>Live Quiz / Assessment</h2>';
  (quiz.questions||[]).forEach((q,idx)=>{
    html+=`<div class="q"><b>${idx+1}. ${q.question}</b>`;
    (q.options||[]).forEach(o=>{html+=`<label><input type="radio" name="${q.questionId}" value="${escapeHtml(o)}"> ${o}</label>`});
    html+='</div>';
  });
  html+='<input id="learnerName" placeholder="Learner name" value="Siva Kumar" style="padding:12px;border:1px solid #ddd;border-radius:10px;margin-right:10px"><button onclick="submitQuiz()">Submit Quiz</button>';
  $('quizBox').innerHTML=html;
}

function submitQuiz(){
  let correct=0,total=(quiz.questions||[]).length;
  quiz.questions.forEach(q=>{const selected=document.querySelector(`input[name="${q.questionId}"]:checked`); if(selected&&selected.value===q.correctAnswer)correct++;});
  const score=Math.round((correct/total)*100);
  if(score>=80) showCertificate(score); else alert(`Score: ${score}%. Retake required. Revise weak topics and try again.`);
}

async function showCertificate(score){
 const name=$('learnerName')?.value||'Learner';
 const cert=await fetch(`/api/learning/certificate?learnerName=${encodeURIComponent(name)}&courseTitle=${encodeURIComponent(roadmap.title)}&courseType=${encodeURIComponent(roadmap.category)}&level=Beginner&score=${score}`).then(r=>r.json());
 $('certificateBox').classList.remove('hidden');
 $('certificateBox').innerHTML=`<h2>ITPS</h2><h1>ITPS Live Certification</h1><h3>Certificate of Successful Completion</h3><p>This certificate is proudly presented to</p><h1>${cert.learnerName}</h1><p>for successfully completing the live learning assessment on</p><h2>${cert.courseTitle}</h2><p>with a score of</p><div class="score">${cert.score}%</div><p>The learner has successfully passed the assessment by meeting the required passing score of 80%.</p><div class="certGrid"><div class="certItem"><b>Course Type</b><br>${cert.courseType}</div><div class="certItem"><b>Level</b><br>${cert.level}</div><div class="certItem"><b>Assessment Mode</b><br>${cert.assessmentMode}</div><div class="certItem"><b>Date</b><br>${cert.completionDate}</div></div><p><b>Certificate ID:</b> ${cert.certificateId}</p><button onclick="window.print()">Download / Print Certificate</button>`;
}
function updateProgress(){if(!roadmap)return;const total=roadmap.modules.length,done=roadmap.modules.filter(m=>m.status==='GENERATED').length,p=Math.round(done/total*100);$('progressBar').style.width=p+'%';$('progressText').innerText=p+'%';}
function escapeHtml(s){return String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]))}
