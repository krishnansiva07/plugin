# ITPS Live Learning Platform

Generic live learning app for technical and functional topics.

## Features
- Generate roadmap only first
- Lazy-generate topic content when clicked
- Supports technical topics like Java 17 and functional topics like SEPA Payment
- Generic quiz module instead of interview preparation
- 80% pass logic
- Live certificate generation without share/verify
- Simple frontend included at `/index.html`

## Configure
Edit `src/main/resources/application.properties` or set environment variables:

```properties
llm.api-key=YOUR_KEY
llm.model-name=devstral-medium-2512
llm.base-url=https://your-llm-endpoint/v1
```

## Run
```bash
mvn clean spring-boot:run
```

Open:
```text
http://localhost:8090/index.html
```

## API examples

Generate roadmap:
```bash
curl -X POST http://localhost:8090/api/learning/roadmap -H "Content-Type: application/json" -d "{\"userPrompt\":\"I want to learn SEPA Payment\"}"
```

Generate topic content:
```bash
curl -X POST http://localhost:8090/api/learning/content -H "Content-Type: application/json" -d "{\"topic\":\"SEPA Payment\",\"subTopic\":\"SEPA Credit Transfer\",\"category\":\"FUNCTIONAL\"}"
```
