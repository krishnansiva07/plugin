'use strict';

const byId = id => document.getElementById(id);
const required = id => {
  const element = byId(id);
  if (!element) throw new Error(`UI element '${id}' is missing. Refresh the page with Ctrl+F5.`);
  return element;
};

let pollHandle = null;
let browsers = [];
let currentRunId = '';
let currentRun = null;
let pollFailures = 0;
let availableSheets = [];

function safeText(id, value){
  const element = byId(id);
  if (element) element.textContent = String(value ?? '');
}

function safeDisabled(id, value){
  const element = byId(id);
  if (element) element.disabled = Boolean(value);
}

function setStatus(text, isError = false){
  const line = byId('statusLine');
  if (!line) return;
  line.textContent = String(text || '');
  line.classList.toggle('error-line', isError);
}

async function readJson(response){
  const text = await response.text();
  if (!text) return {};
  try { return JSON.parse(text); }
  catch { throw new Error(`Server returned an invalid response (${response.status}).`); }
}

async function loadBrowsers(){
  try{
    const response = await fetch('/api/browsers', {cache:'no-store'});
    const data = await readJson(response);
    if(!response.ok) throw new Error(data.error || `HTTP ${response.status}`);
    browsers = Array.isArray(data) ? data : [];
    const available = browsers.filter(b => b.detected || b.id === 'vibium-managed-chrome');
    const browserSelect = required('browserId');
    browserSelect.innerHTML = available.length
      ? available.map(b => `<option value="${escAttr(b.id)}">${esc(b.name)}</option>`).join('')
      : '<option value="vibium-managed-chrome">Vibium managed Chrome</option>';
    updateBrowserSelection();
  }catch(error){
    safeText('browserNote', `Browser discovery failed: ${error.message}`);
  }
}

function updateBrowserSelection(){
  const select = byId('browserId');
  if(!select) return;
  const selected = browsers.find(b => b.id === select.value);
  if(!selected) return;
  const browserName = byId('browserName');
  const browserExecutable = byId('browserExecutable');
  if(browserName) browserName.value = selected.name || '';
  if(browserExecutable) browserExecutable.value = selected.executable || '';
  safeText('browserNote', selected.executable || selected.note || '');
}

function setArtifactButtons(enabled){
  document.querySelectorAll('[data-artifact]').forEach(button => button.disabled = !enabled);
}

function shortStatus(run){
  const raw = String(run?.status || '').toUpperCase();
  if(['CREATED','QUEUED','RUNNING'].includes(raw)) return raw === 'CREATED' ? 'QUEUED' : raw;
  if(Number(run?.failed || 0) > 0) return 'FAILED';
  if(Number(run?.total || 0) > 0 && Number(run?.passed || 0) === Number(run?.total || 0)) return 'PASSED';
  return raw || 'COMPLETED';
}

function renderRun(run){
  if(!run || typeof run !== 'object') throw new Error('Run status payload is empty.');
  currentRun = run;
  currentRunId = run.runId || currentRunId;

  const resultPanel = required('resultPanel');
  resultPanel.classList.remove('hidden');

  const status = shortStatus(run);
  safeText('runTitle', `${currentRunId || 'Run'} · ${status}`);
  safeText('total', run.total ?? 0);
  safeText('passed', run.passed ?? 0);
  safeText('failed', run.failed ?? 0);
  safeText('status', status);

  const body = required('scenarioResults');
  const scenarios = Array.isArray(run.scenarios) ? run.scenarios : [];
  body.innerHTML = scenarios.map(s => {
    const raw = String(s.status || '').toUpperCase();
    const scenarioStatus = raw.startsWith('PASSED') ? 'PASSED' : (raw || 'FAILED');
    return `<tr>
      <td><input class="test-select" type="checkbox" value="${escAttr(s.id)}" data-status="${escAttr(scenarioStatus)}" /></td>
      <td>${esc(s.id)}</td>
      <td>${esc(s.name)}</td>
      <td><span class="pill ${scenarioStatus === 'PASSED' ? 'pass' : 'fail'}">${esc(scenarioStatus)}</span></td>
      <td>${formatDuration(s.durationMs)}</td>
      <td class="err">${renderError(s.errorMessage || '')}</td>
    </tr>`;
  }).join('');

  bindSelectionEvents();
}

async function fetchRun(runId){
  const response = await fetch(`/api/runs/${encodeURIComponent(runId)}`, {cache:'no-store'});
  const data = await readJson(response);
  if(!response.ok) throw new Error(data.error || `HTTP ${response.status}`);
  return data;
}

async function pollOnce(runId){
  const data = await fetchRun(runId);
  renderRun(data);
  const running = ['CREATED','QUEUED','RUNNING'].includes(String(data.status || '').toUpperCase());
  if(!running){
    clearInterval(pollHandle);
    pollHandle = null;
    safeDisabled('runBtn', false);
    setArtifactButtons(true);
    updateRerunButton();
    setStatus(`Execution completed: ${shortStatus(data)}.`);
  }
}

function poll(runId){
  clearInterval(pollHandle);
  pollHandle = null;
  pollFailures = 0;

  pollOnce(runId).catch(error => {
    setStatus(`Waiting for run status: ${error.message}`, true);
  });

  pollHandle = setInterval(async () => {
    try{
      await pollOnce(runId);
      pollFailures = 0;
    }catch(error){
      pollFailures++;
      if(pollFailures >= 5){
        clearInterval(pollHandle);
        pollHandle = null;
        safeDisabled('runBtn', false);
        setStatus(`Unable to read run status: ${error.message}`, true);
      }
    }
  }, 1500);
}

async function startRun(){
  try{
    const fileInput = required('scenarioFile');
    const file = fileInput.files?.[0];
    if(!file){ setStatus('Choose a scenario file.', true); return; }
    if(!required('llmApiKey').value.trim()){ setStatus('Enter the LLM token.', true); return; }

    const form = new FormData();
    form.append('scenarioFile', file);
    const sheet = byId('sheetName'); if(sheet && sheet.value) form.append('sheetName', sheet.value);
    ['llmBaseUrl','llmApiKey','llmModel','appBaseUrl','browserId','browserName','browserExecutable','screenshotMode','stepTimeoutSeconds','retryCount','healingConfidenceThreshold']
      .forEach(id => { const e = byId(id); form.append(id, e ? (e.value || '') : ''); });
    ['useLlm','headless','continueOnFailure','strictEvidence','enableSelfHealing']
      .forEach(id => { const e = byId(id); form.append(id, Boolean(e?.checked)); });

    safeDisabled('runBtn', true);
    setArtifactButtons(false);
    required('resultPanel').classList.remove('hidden');
    safeText('runTitle', 'Starting execution…');
    safeText('total', '0'); safeText('passed', '0'); safeText('failed', '0'); safeText('status', 'QUEUED');
    required('scenarioResults').innerHTML = '<tr><td colspan="6" class="empty-state">Uploading test data and starting Vibium execution…</td></tr>';
    setStatus('Starting execution...');

    const response = await fetch('/api/runs', {method:'POST', body:form, cache:'no-store'});
    const data = await readJson(response);
    if(!response.ok) throw new Error(data.error || 'Unable to start execution');
    if(!data.runId) throw new Error('The server started no run ID. Check backend logs.');

    renderRun(data);
    poll(data.runId);
  }catch(error){
    safeDisabled('runBtn', false);
    setStatus(error.message, true);
  }
}

async function openArtifact(name, download){
  if(!currentRunId){ setStatus('No completed run is available.', true); return; }
  const url = `/api/runs/${encodeURIComponent(currentRunId)}/${name}`;
  try{
    if(!download){
      const tab = window.open(url, '_blank', 'noopener');
      if(!tab) window.location.href = url;
      return;
    }
    setStatus(`Preparing ${name}...`);
    const response = await fetch(url, {cache:'no-store'});
    if(!response.ok){
      const data = await readJson(response).catch(() => ({}));
      throw new Error(data.error || `HTTP ${response.status}`);
    }
    const blob = await response.blob();
    const objectUrl = URL.createObjectURL(blob);
    const anchor = document.createElement('a');
    anchor.href = objectUrl;
    anchor.download = name;
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
    setTimeout(() => URL.revokeObjectURL(objectUrl), 1000);
    setStatus(`${name} downloaded.`);
  }catch(error){
    setStatus(`Unable to open ${name}: ${error.message}`, true);
  }
}

function bindSelectionEvents(){
  document.querySelectorAll('.test-select').forEach(cb => cb.addEventListener('change', updateRerunButton));
  const all = byId('selectAllTests');
  if(all){
    all.checked = false;
    all.onchange = () => {
      document.querySelectorAll('.test-select').forEach(cb => cb.checked = all.checked);
      updateRerunButton();
    };
  }
  updateRerunButton();
}

function updateRerunButton(){
  const button = byId('rerunSelectedBtn');
  if(!button) return;
  const count = document.querySelectorAll('.test-select:checked').length;
  const running = ['CREATED','QUEUED','RUNNING'].includes(String(currentRun?.status || '').toUpperCase());
  button.disabled = count === 0 || !currentRunId || running;
  button.textContent = count ? `Rerun selected (${count})` : 'Rerun selected';
}

async function rerunSelected(){
  const testIds = [...document.querySelectorAll('.test-select:checked')].map(cb => cb.value);
  if(!testIds.length){ setStatus('Select at least one test.', true); return; }
  try{
    safeDisabled('rerunSelectedBtn', true);
    safeDisabled('runBtn', true);
    setArtifactButtons(false);
    setStatus(`Starting rerun for ${testIds.length} test(s)...`);
    const response = await fetch(`/api/runs/${encodeURIComponent(currentRunId)}/rerun`, {
      method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({testIds}), cache:'no-store'
    });
    const data = await readJson(response);
    if(!response.ok) throw new Error(data.error || 'Unable to start rerun');
    if(!data.runId) throw new Error('Rerun did not return a run ID.');
    renderRun(data);
    poll(data.runId);
  }catch(error){
    safeDisabled('runBtn', false);
    updateRerunButton();
    setStatus(error.message, true);
  }
}

function concise(value){ const text = String(value || '').replace(/\s+/g,' ').trim(); return text.length > 180 ? `${text.slice(0,177)}...` : text; }
function renderError(value){ const raw = String(value || '').trim(); return raw ? `<details class="error-details"><summary>${esc(concise(raw))}</summary><pre>${esc(raw)}</pre></details>` : '<span class="muted">—</span>'; }
function formatDuration(ms){ const value = Number(ms || 0); return value < 1000 ? `${value} ms` : `${(value/1000).toFixed(1)} s`; }
function esc(value){ return String(value ?? '').replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m])); }
function escAttr(value){ return esc(value).replace(/`/g,'&#96;'); }

function initialize(){
  try{
    required('browserId').addEventListener('change', updateBrowserSelection);
    required('scenarioFile').addEventListener('change', async () => {
      const file = required('scenarioFile').files?.[0];
      safeText('fileName', file ? `${file.name} · ${Math.max(1, Math.round(file.size/1024))} KB` : 'No file selected');
      const field = byId('sheetField'), select = byId('sheetName');
      if(!file || !/\.xlsx?$/i.test(file.name)){ if(field) field.classList.add('hidden'); return; }
      try{
        const fd = new FormData(); fd.append('scenarioFile', file);
        const response = await fetch('/api/runs/sheets',{method:'POST',body:fd,cache:'no-store'});
        const data = await readJson(response); if(!response.ok) throw new Error(data.error || 'Unable to read worksheets');
        availableSheets = Array.isArray(data.sheets) ? data.sheets : [];
        if(select) select.innerHTML = availableSheets.map(x=>`<option value="${escAttr(x)}">${esc(x)}</option>`).join('');
        if(field) field.classList.toggle('hidden', availableSheets.length === 0);
        setStatus(availableSheets.length ? `${availableSheets.length} worksheet(s) detected. Select the sheet to execute.` : 'No worksheets found.', availableSheets.length===0);
      }catch(error){ if(field) field.classList.add('hidden'); setStatus(`Unable to read worksheets: ${error.message}`, true); }
    });
    required('runBtn').addEventListener('click', startRun);
    required('selectFailedBtn').addEventListener('click', () => {
      document.querySelectorAll('.test-select').forEach(cb => cb.checked = cb.dataset.status === 'FAILED');
      updateRerunButton();
    });
    required('rerunSelectedBtn').addEventListener('click', rerunSelected);
    document.querySelectorAll('[data-artifact]').forEach(button => {
      button.addEventListener('click', () => openArtifact(button.dataset.artifact, button.hasAttribute('data-download')));
    });
    setArtifactButtons(false);
    loadBrowsers();
  }catch(error){
    setStatus(`UI initialization failed: ${error.message}`, true);
    console.error(error);
  }
}

if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', initialize);
else initialize();
