package com.itps.vibium.service;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;

import static org.junit.jupiter.api.Assertions.*;

class LlmClientConnectionValidationTest {
    private HttpServer server;

    @AfterEach
    void stopServer() {
        if (server != null) server.stop(0);
    }

    @Test
    void validatesOpenAiCompatibleEndpointModelAndKey() throws Exception {
        server = HttpServer.create(new InetSocketAddress(0), 0);
        server.createContext("/v1/chat/completions", exchange -> {
            assertEquals("Bearer secret-key", exchange.getRequestHeaders().getFirst("Authorization"));
            respond(exchange, 200, "{\"choices\":[{\"message\":{\"content\":\"OK\"}}]}");
        });
        server.start();

        String baseUrl = "http://127.0.0.1:" + server.getAddress().getPort() + "/v1";
        LlmClient.ConnectionValidation result = new LlmClient().validateConnection(baseUrl, "secret-key", "test-model");

        assertEquals(baseUrl, result.endpoint());
        assertEquals("test-model", result.model());
    }

    @Test
    void rejectsUnauthorizedApiKeyWithSafeMessage() throws Exception {
        server = HttpServer.create(new InetSocketAddress(0), 0);
        server.createContext("/v1/chat/completions", exchange -> respond(exchange, 401, "{\"error\":\"unauthorized\"}"));
        server.start();

        String baseUrl = "http://127.0.0.1:" + server.getAddress().getPort() + "/v1";
        IllegalArgumentException error = assertThrows(IllegalArgumentException.class,
                () -> new LlmClient().validateConnection(baseUrl, "bad-key", "test-model"));

        assertEquals("API key was rejected by the endpoint", error.getMessage());
        assertFalse(error.getMessage().contains("bad-key"));
    }

    @Test
    void rejectsInvalidEndpointBeforeNetworkCall() {
        IllegalArgumentException error = assertThrows(IllegalArgumentException.class,
                () -> new LlmClient().validateConnection("file:///tmp/model", "key", "model"));
        assertTrue(error.getMessage().contains("http:// or https://"));
    }

    private static void respond(HttpExchange exchange, int status, String body) throws IOException {
        byte[] bytes = body.getBytes(StandardCharsets.UTF_8);
        exchange.getResponseHeaders().set("Content-Type", "application/json");
        exchange.sendResponseHeaders(status, bytes.length);
        exchange.getResponseBody().write(bytes);
        exchange.close();
    }
}
