'use strict';

const byId = id => document.getElementById(id);
const required = id => {
  const element = byId(id);
  if (!element) throw new Error(`UI element '${id}' is missing. Refresh the page with Ctrl+F5.`);
  return element;
};

let pollHandle = null;
let browsers = [];
let currentRunId = '';
let currentRun = null;
let pollFailures = 0;
let availableSheets = [];
let recorderSessionId = '';
let recorderPollHandle = null;
let recorderState = null;
let aiConnectionValidated = false;

function safeText(id, value){
  const element = byId(id);
  if (element) element.textContent = String(value ?? '');
}

function safeDisabled(id, value){
  const element = byId(id);
  if (element) element.disabled = Boolean(value);
}

function setStatus(text, isError = false){
  const line = byId('statusLine');
  if (!line) return;
  line.textContent = String(text || '');
  line.classList.toggle('error-line', isError);
}

async function readJson(response){
  const text = await response.text();
  if (!text) return {};
  try { return JSON.parse(text); }
  catch { throw new Error(`Server returned an invalid response (${response.status}).`); }
}

async function loadBrowsers(){
  try{
    const response = await fetch('/api/browsers', {cache:'no-store'});
    const data = await readJson(response);
    if(!response.ok) throw new Error(data.error || `HTTP ${response.status}`);
    browsers = Array.isArray(data) ? data : [];
    const available = browsers.filter(b => b.detected || b.id === 'vibium-managed-chrome');
    const browserSelect = required('browserId');
    browserSelect.innerHTML = available.length
      ? available.map(b => `<option value="${escAttr(b.id)}">${esc(b.name)}</option>`).join('')
      : '<option value="vibium-managed-chrome">Vibium managed Chrome</option>';
    updateBrowserSelection();
  }catch(error){
    safeText('browserNote', `Browser discovery failed: ${error.message}`);
  }
}

function updateBrowserSelection(){
  const select = byId('browserId');
  if(!select) return;
  const selected = browsers.find(b => b.id === select.value);
  if(!selected) return;
  const browserName = byId('browserName');
  const browserExecutable = byId('browserExecutable');
  if(browserName) browserName.value = selected.name || '';
  if(browserExecutable) browserExecutable.value = selected.executable || '';
  safeText('browserNote', selected.executable || selected.note || '');
}

function setArtifactButtons(enabled){
  document.querySelectorAll('[data-artifact]').forEach(button => button.disabled = !enabled);
}

function shortStatus(run){
  const raw = String(run?.status || '').toUpperCase();
  if(['CREATED','QUEUED','RUNNING','REPORTING'].includes(raw)) return raw === 'CREATED' ? 'QUEUED' : raw;
  if(Number(run?.failed || 0) > 0) return 'FAILED';
  if(Number(run?.total || 0) > 0 && Number(run?.passed || 0) === Number(run?.total || 0)) return 'PASSED';
  return raw || 'COMPLETED';
}

function scenarioPillClass(status){
  const raw = String(status || '').toUpperCase();
  if(raw.startsWith('PASSED')) return 'pass';
  if(raw === 'FAILED' || raw.startsWith('SKIPPED')) return 'fail';
  if(raw === 'RUNNING' || raw === 'RERUNNING') return 'live';
  return 'pending';
}

function renderRun(run){
  if(!run || typeof run !== 'object') throw new Error('Run status payload is empty.');
  currentRun = run;
  currentRunId = run.runId || currentRunId;

  const resultPanel = required('resultPanel');
  resultPanel.classList.remove('hidden');

  const status = shortStatus(run);
  safeText('runTitle', `${currentRunId || 'Run'} · ${status}`);
  const total = Number(run.total || 0);
  const executed = Number(run.executed || 0);
  const passed = Number(run.passed || 0);
  const failed = Number(run.failed || 0);
  const running = Number(run.running || 0);
  const pending = Number(run.pending ?? Math.max(0, total - executed - running));
  const passPercentage = Number(run.passPercentage ?? (executed ? passed * 100 / executed : 0));
  safeText('total', total);
  safeText('executed', executed);
  safeText('passed', passed);
  safeText('failed', failed);
  safeText('running', running);
  safeText('pending', pending);
  safeText('passPercentage', `${passPercentage.toFixed(2)}%`);
  const progress = total ? Math.min(100, Math.max(0, executed * 100 / total)) : 0;
  const progressBar = byId('progressBar'); if(progressBar) progressBar.style.width = `${progress}%`;
  safeText('progressText', `${executed} / ${total} executed · ${running} running · ${pending} pending`);

  const body = required('scenarioResults');
  const scenarios = Array.isArray(run.scenarios) ? run.scenarios : [];
  body.innerHTML = scenarios.length ? scenarios.map(s => {
    const raw = String(s.status || 'PENDING').toUpperCase();
    const attempt = Number(s.attemptCount || 0);
    const maxAttempts = Math.max(1, Number(s.maxAttempts || 1));
    const active = ['PENDING','QUEUED','RUNNING','RERUNNING'].includes(raw);
    return `<tr data-live-status="${escAttr(raw)}">
      <td><input class="test-select" type="checkbox" value="${escAttr(s.id)}" data-status="${escAttr(raw)}" /></td>
      <td>${esc(s.id)}</td>
      <td>${esc(s.name)}</td>
      <td><span class="pill ${scenarioPillClass(raw)}">${esc(raw)}</span></td>
      <td>${attempt ? `${attempt} / ${maxAttempts}` : '—'}</td>
      <td>${active ? '<span class="muted">—</span>' : formatDuration(s.durationMs)}</td>
      <td class="err">${renderError(s.errorMessage || '')}</td>
    </tr>`;
  }).join('') : '<tr><td colspan="7" class="empty-state">No scenarios loaded.</td></tr>';

  bindSelectionEvents();
}

async function fetchRun(runId){
  const response = await fetch(`/api/runs/${encodeURIComponent(runId)}`, {cache:'no-store'});
  const data = await readJson(response);
  if(!response.ok) throw new Error(data.error || `HTTP ${response.status}`);
  return data;
}

async function pollOnce(runId){
  const data = await fetchRun(runId);
  renderRun(data);
  const running = ['CREATED','QUEUED','RUNNING','REPORTING'].includes(String(data.status || '').toUpperCase());
  if(!running){
    clearInterval(pollHandle);
    pollHandle = null;
    safeDisabled('runBtn', false);
    setArtifactButtons(true);
    updateRerunButton();
    setStatus(`Execution completed: ${shortStatus(data)}.`);
  }
}

function poll(runId){
  clearInterval(pollHandle);
  pollHandle = null;
  pollFailures = 0;

  pollOnce(runId).catch(error => {
    setStatus(`Waiting for run status: ${error.message}`, true);
  });

  pollHandle = setInterval(async () => {
    try{
      await pollOnce(runId);
      pollFailures = 0;
    }catch(error){
      pollFailures++;
      if(pollFailures >= 5){
        clearInterval(pollHandle);
        pollHandle = null;
        safeDisabled('runBtn', false);
        setStatus(`Unable to read run status: ${error.message}`, true);
      }
    }
  }, 800);
}

async function startRun(){
  try{
    if(!aiConnectionValidated){ showConnectionScreen(); return; }
    const fileInput = required('scenarioFile');
    const file = fileInput.files?.[0];
    if(!file){ setStatus('Choose a scenario file.', true); return; }
    if(!required('llmApiKey').value.trim()){ setStatus('Enter the LLM token.', true); return; }
    if(required('replaceSessionCookie').checked && (!required('sessionCookieName').value.trim() || !required('sessionCookieValue').value.trim())){
      setStatus('Enter both the existing cookie name and replacement value.', true); return;
    }
    const additionalCookies = collectAdditionalCookies();

    const form = new FormData();
    form.append('scenarioFile', file);
    const selectedSheets = getSelectedSheets();
    if (/\.xlsx?$/i.test(file.name) && selectedSheets.length === 0) { setStatus('Select at least one worksheet.', true); return; }
    selectedSheets.forEach(sheetName => form.append('sheetNames', sheetName));
    ['llmBaseUrl','llmApiKey','llmModel','appBaseUrl','browserId','browserName','browserExecutable','browserZoomPercent','parallelThreads','screenshotMode','stepTimeoutSeconds','retryCount','healingConfidenceThreshold','maxAgentTurns','failedScenarioRerunCount']
      .forEach(id => { const e = byId(id); form.append(id, e ? (e.value || '') : ''); });
    if(required('replaceSessionCookie').checked){
      form.append('sessionCookieName', required('sessionCookieName').value.trim());
      form.append('sessionCookieValue', required('sessionCookieValue').value);
    }
    if(additionalCookies.length) form.append('additionalCookiesJson', JSON.stringify(additionalCookies));
    ['useLlm','headless','browserZoomEnabled','separateBrowserPerTest','parallelExecution','replaceSessionCookie','allowInsecureCertificates','continueOnFailure','strictEvidence','enableSelfHealing']
      .forEach(id => { const e = byId(id); form.append(id, Boolean(e?.checked)); });

    safeDisabled('runBtn', true);
    setArtifactButtons(false);
    required('resultPanel').classList.remove('hidden');
    safeText('runTitle', 'Starting execution…');
    safeText('total', '0'); safeText('executed', '0'); safeText('passed', '0'); safeText('failed', '0'); safeText('running', '0'); safeText('pending', '0'); safeText('passPercentage', '0.00%');
    required('scenarioResults').innerHTML = '<tr><td colspan="7" class="empty-state">Uploading test data and starting Vibium execution…</td></tr>';
    setStatus('Starting execution...');

    const response = await fetch('/api/runs', {method:'POST', body:form, cache:'no-store'});
    const data = await readJson(response);
    if(!response.ok) throw new Error(data.error || 'Unable to start execution');
    if(!data.runId) throw new Error('The server started no run ID. Check backend logs.');

    renderRun(data);
    poll(data.runId);
  }catch(error){
    safeDisabled('runBtn', false);
    setStatus(error.message, true);
  }
}

async function openArtifact(name, download){
  if(!currentRunId){ setStatus('No completed run is available.', true); return; }
  const url = `/api/runs/${encodeURIComponent(currentRunId)}/${name}`;
  try{
    if(!download){
      // Never replace the framework home page. Open reports/logs only in a separate tab.
      const anchor = document.createElement('a');
      anchor.href = url;
      anchor.target = '_blank';
      anchor.rel = 'noopener noreferrer';
      anchor.style.display = 'none';
      document.body.appendChild(anchor);
      anchor.click();
      anchor.remove();
      setStatus(`${name} opened in a new tab. The framework page remains unchanged.`);
      return;
    }
    setStatus(`Preparing ${name}...`);
    const response = await fetch(url, {cache:'no-store'});
    if(!response.ok){
      const data = await readJson(response).catch(() => ({}));
      throw new Error(data.error || `HTTP ${response.status}`);
    }
    const blob = await response.blob();
    const objectUrl = URL.createObjectURL(blob);
    const anchor = document.createElement('a');
    anchor.href = objectUrl;
    anchor.download = name;
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
    setTimeout(() => URL.revokeObjectURL(objectUrl), 1000);
    setStatus(`${name} downloaded.`);
  }catch(error){
    setStatus(`Unable to open ${name}: ${error.message}`, true);
  }
}

function bindSelectionEvents(){
  document.querySelectorAll('.test-select').forEach(cb => cb.addEventListener('change', updateRerunButton));
  const all = byId('selectAllTests');
  if(all){
    all.checked = false;
    all.onchange = () => {
      document.querySelectorAll('.test-select').forEach(cb => cb.checked = all.checked);
      updateRerunButton();
    };
  }
  updateRerunButton();
}

function updateRerunButton(){
  const button = byId('rerunSelectedBtn');
  if(!button) return;
  const count = document.querySelectorAll('.test-select:checked').length;
  const running = ['CREATED','QUEUED','RUNNING','REPORTING'].includes(String(currentRun?.status || '').toUpperCase());
  button.disabled = count === 0 || !currentRunId || running;
  button.textContent = count ? `Rerun selected (${count})` : 'Rerun selected';
}

async function rerunSelected(){
  const testIds = [...document.querySelectorAll('.test-select:checked')].map(cb => cb.value);
  if(!testIds.length){ setStatus('Select at least one test.', true); return; }
  try{
    safeDisabled('rerunSelectedBtn', true);
    safeDisabled('runBtn', true);
    setArtifactButtons(false);
    setStatus(`Starting rerun for ${testIds.length} test(s)...`);
    const response = await fetch(`/api/runs/${encodeURIComponent(currentRunId)}/rerun`, {
      method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({testIds}), cache:'no-store'
    });
    const data = await readJson(response);
    if(!response.ok) throw new Error(data.error || 'Unable to start rerun');
    if(!data.runId) throw new Error('Rerun did not return a run ID.');
    renderRun(data);
    poll(data.runId);
  }catch(error){
    safeDisabled('runBtn', false);
    updateRerunButton();
    setStatus(error.message, true);
  }
}


function setRecorderStatus(text, isError = false, recording = false){
  const element = byId('recorderStatus');
  if(!element) return;
  element.innerHTML = `${recording ? '<span class="recording-dot"></span>' : ''}${esc(String(text || ''))}`;
  element.classList.toggle('error-line', isError);
}

function recorderActive(){
  return ['STARTING','RECORDING','STOPPING'].includes(String(recorderState?.state || '').toUpperCase());
}

function updateRecorderControls(){
  const active = recorderActive();
  const stopped = ['STOPPED','FAILED'].includes(String(recorderState?.state || '').toUpperCase());
  safeDisabled('startRecorderBtn', active);
  safeDisabled('stopRecorderBtn', !active || String(recorderState?.state || '').toUpperCase() === 'STOPPING');
  safeDisabled('copyRecordedStepsBtn', !(recorderState?.actions?.length));
  safeDisabled('downloadRecordedExcelBtn', !stopped || !(recorderState?.actions?.length));
  safeDisabled('downloadRecordedJsonBtn', !stopped || !(recorderState?.actions?.length));
  safeDisabled('browserId', active);
  safeDisabled('browserZoomEnabled', active);
  updateBrowserZoomControls(active);
  safeDisabled('runBtn', active);
  const toggle = byId('enableRecorder'); if(toggle) toggle.disabled = active;
}

function renderRecorder(status){
  if(!status || typeof status !== 'object') return;
  recorderState = status;
  recorderSessionId = status.sessionId || recorderSessionId;
  const state = String(status.state || '').toUpperCase();
  const actions = Array.isArray(status.actions) ? status.actions : [];
  setRecorderStatus(status.message || state, state === 'FAILED', state === 'RECORDING');
  safeText('recorderCurrentPage', status.currentPageUrl ? `${status.currentPageTitle || 'Current page'} · ${status.currentPageUrl}` : '');
  const body = byId('recorderActions');
  if(body){
    body.innerHTML = actions.length ? actions.map(action => `<tr>
      <td>${esc(action.sequence)}</td>
      <td class="recorder-prompt">${esc(action.prompt || '')}${action.sensitive ? '<div class="muted">Sensitive value masked</div>' : ''}</td>
      <td><b>${esc(action.locatorType || '')}</b><div class="locator-code">${esc(action.locator || '')}</div>${action.fallbackLocator ? `<details><summary class="muted">Fallback</summary><div class="locator-code">${esc(action.fallbackLocator)}</div></details>` : ''}</td>
      <td>${esc(action.pageTitle || '')}<div class="muted">${esc(concise(action.pageUrl || ''))}</div></td>
      <td><button type="button" class="delete-recorded-action" data-sequence="${escAttr(action.sequence)}" ${state === 'STARTING' || state === 'STOPPING' ? 'disabled' : ''}>Delete</button></td>
    </tr>`).join('') : '<tr><td colspan="5" class="empty-state">No supported UI actions recorded yet.</td></tr>';
    body.querySelectorAll('.delete-recorded-action').forEach(button => button.addEventListener('click', () => deleteRecordedAction(Number(button.dataset.sequence))));
  }
  updateRecorderControls();
  if(['STOPPED','FAILED'].includes(state) && recorderPollHandle){ clearInterval(recorderPollHandle); recorderPollHandle = null; }
}

async function fetchRecorderStatus(){
  if(!recorderSessionId) return;
  const response = await fetch(`/api/recorder/${encodeURIComponent(recorderSessionId)}`, {cache:'no-store'});
  const data = await readJson(response);
  if(!response.ok) throw new Error(data.error || `HTTP ${response.status}`);
  renderRecorder(data);
}

function pollRecorder(){
  if(recorderPollHandle) clearInterval(recorderPollHandle);
  recorderPollHandle = setInterval(() => fetchRecorderStatus().catch(error => setRecorderStatus(`Unable to read recorder status: ${error.message}`, true)), 900);
}

async function startRecorder(){
  try{
    const url = required('recorderApplicationUrl').value.trim();
    if(!url){ setRecorderStatus('Application URL is mandatory to record UI actions.', true); return; }
    let parsed;
    try{ parsed = new URL(url); }catch(_){ setRecorderStatus('Enter a complete valid application URL.', true); return; }
    if(!['http:','https:'].includes(parsed.protocol)){ setRecorderStatus('Application URL must start with http:// or https://.', true); return; }
    const payload = {
      applicationUrl: url,
      browserId: byId('browserId')?.value || 'vibium-managed-chrome',
      browserName: byId('browserName')?.value || '',
      browserExecutable: byId('browserExecutable')?.value || '',
      browserZoomEnabled: Boolean(byId('browserZoomEnabled')?.checked),
      browserZoomPercent: Number(byId('browserZoomPercent')?.value || 100),
      allowInsecureCertificates: Boolean(byId('recorderAllowInsecureCertificates')?.checked)
    };
    recorderState = {state:'STARTING', actions:[]};
    updateRecorderControls();
    setRecorderStatus('Launching headed browser...', false, true);
    const response = await fetch('/api/recorder/start', {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(payload), cache:'no-store'});
    const data = await readJson(response);
    if(!response.ok) throw new Error(data.error || 'Unable to start recorder');
    renderRecorder(data);
    pollRecorder();
  }catch(error){
    recorderState = {state:'FAILED', actions:[]};
    updateRecorderControls();
    setRecorderStatus(error.message, true);
  }
}

async function stopRecorder(){
  if(!recorderSessionId) return;
  try{
    safeDisabled('stopRecorderBtn', true);
    setRecorderStatus('Stopping recording and generating Excel steps...', false, true);
    const response = await fetch(`/api/recorder/${encodeURIComponent(recorderSessionId)}/stop`, {method:'POST', cache:'no-store'});
    const data = await readJson(response);
    if(!response.ok) throw new Error(data.error || 'Unable to stop recorder');
    renderRecorder(data);
  }catch(error){ setRecorderStatus(error.message, true); updateRecorderControls(); }
}

async function deleteRecordedAction(sequence){
  if(!recorderSessionId || !sequence) return;
  try{
    const response = await fetch(`/api/recorder/${encodeURIComponent(recorderSessionId)}/actions/${sequence}`, {method:'DELETE', cache:'no-store'});
    const data = await readJson(response);
    if(!response.ok) throw new Error(data.error || 'Unable to delete step');
    renderRecorder(data);
  }catch(error){ setRecorderStatus(error.message, true); }
}

async function copyRecordedSteps(){
  const steps = (recorderState?.actions || []).map(action => action.prompt).filter(Boolean).join('\n');
  if(!steps){ setRecorderStatus('No recorded steps are available to copy.', true); return; }
  try{ await navigator.clipboard.writeText(steps); setRecorderStatus(`${recorderState.actions.length} step(s) copied. Paste them into the Excel Steps cell.`); }
  catch(_){
    const textarea = document.createElement('textarea'); textarea.value = steps; document.body.appendChild(textarea); textarea.select(); document.execCommand('copy'); textarea.remove();
    setRecorderStatus(`${recorderState.actions.length} step(s) copied. Paste them into the Excel Steps cell.`);
  }
}

function downloadRecorderArtifact(name){
  if(!recorderSessionId) return;
  const anchor = document.createElement('a');
  anchor.href = `/api/recorder/${encodeURIComponent(recorderSessionId)}/${name}`;
  anchor.download = name;
  document.body.appendChild(anchor); anchor.click(); anchor.remove();
}


function getSelectedSheets(){
  return [...document.querySelectorAll('.sheet-checkbox:checked')].map(input => input.value);
}

function updateSheetSelectionSummary(){
  const selected = getSelectedSheets();
  safeText('sheetSelectionSummary', selected.length
    ? `${selected.length} of ${availableSheets.length} worksheet(s) selected: ${selected.join(', ')}`
    : 'No worksheets selected.');
}

function renderSheetCheckboxes(sheets){
  const container = byId('sheetCheckboxes');
  if(!container) return;
  container.innerHTML = sheets.map((name, index) => `<label class="check sheet-check"><input class="sheet-checkbox" type="checkbox" value="${escAttr(name)}" ${index === 0 ? 'checked' : ''} /><span>${esc(name)}</span></label>`).join('');
  container.querySelectorAll('.sheet-checkbox').forEach(input => input.addEventListener('change', updateSheetSelectionSummary));
  updateSheetSelectionSummary();
}

function setAllSheets(checked){
  document.querySelectorAll('.sheet-checkbox').forEach(input => input.checked = checked);
  updateSheetSelectionSummary();
}

function concise(value){ const text = String(value || '').replace(/\s+/g,' ').trim(); return text.length > 180 ? `${text.slice(0,177)}...` : text; }
function renderError(value){ const raw = String(value || '').trim(); return raw ? `<details class="error-details"><summary>${esc(concise(raw))}</summary><pre>${esc(raw)}</pre></details>` : '<span class="muted">—</span>'; }
function formatDuration(ms){ const value = Number(ms || 0); return value < 1000 ? `${value} ms` : `${(value/1000).toFixed(1)} s`; }
function esc(value){ return String(value ?? '').replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m])); }
function escAttr(value){ return esc(value).replace(/`/g,'&#96;'); }


function setConnectionStatus(text, kind = ''){
  const element = byId('connectionStatus');
  if(!element) return;
  element.textContent = String(text || '');
  element.classList.toggle('success', kind === 'success');
  element.classList.toggle('error', kind === 'error');
}

function showConnectionScreen(){
  aiConnectionValidated = false;
  required('homeScreen').classList.add('hidden');
  required('connectionScreen').classList.remove('hidden');
  required('llmBaseUrl').value = '';
  required('llmModel').value = '';
  required('llmApiKey').value = '';
  safeText('connectedEndpoint', '—');
  safeText('connectedModel', '—');
  required('connectionApiKey').value = '';
  required('connectionApiKey').type = 'password';
  required('toggleConnectionKeyBtn').textContent = 'Show';
  setConnectionStatus('Enter Endpoint, Model and API key, then validate the connection.');
  setTimeout(() => required('connectionEndpoint').focus(), 0);
}

function showHomeScreen(endpoint, model, apiKey){
  required('llmBaseUrl').value = endpoint;
  required('llmModel').value = model;
  required('llmApiKey').value = apiKey;
  safeText('connectedEndpoint', endpoint);
  safeText('connectedModel', model);
  aiConnectionValidated = true;
  required('connectionScreen').classList.add('hidden');
  required('homeScreen').classList.remove('hidden');
  required('connectionApiKey').value = '';
  loadBrowsers();
}

async function validateAiConnection(){
  const endpoint = required('connectionEndpoint').value.trim();
  const model = required('connectionModel').value.trim();
  const apiKey = required('connectionApiKey').value.trim();
  if(!endpoint){ setConnectionStatus('Enter the endpoint.', 'error'); return; }
  if(!model){ setConnectionStatus('Enter the model.', 'error'); return; }
  if(!apiKey){ setConnectionStatus('Enter the API key.', 'error'); return; }

  const button = required('validateConnectionBtn');
  button.disabled = true;
  button.textContent = 'Validating…';
  setConnectionStatus('Validating endpoint, model and API key…');
  try{
    const response = await fetch('/api/connection/validate', {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body:JSON.stringify({endpoint, model, apiKey}),
      cache:'no-store'
    });
    const data = await readJson(response);
    if(!response.ok || !data.valid) throw new Error(data.error || 'Connection validation failed');
    setConnectionStatus('Connection validated. Opening Home…', 'success');
    showHomeScreen(String(data.endpoint || endpoint), String(data.model || model), apiKey);
  }catch(error){
    aiConnectionValidated = false;
    setConnectionStatus(error.message || 'Unable to validate the AI connection.', 'error');
  }finally{
    button.disabled = false;
    button.textContent = 'Validate & Continue';
  }
}

function changeAiConnection(){
  const endpoint = required('llmBaseUrl').value;
  const model = required('llmModel').value;
  showConnectionScreen();
  required('connectionEndpoint').value = endpoint;
  required('connectionModel').value = model;
  required('connectionApiKey').focus();
}

function updateBrowserZoomControls(forceDisabled = false){
  const enabled = Boolean(byId('browserZoomEnabled')?.checked);
  safeDisabled('browserZoomPercent', forceDisabled || !enabled);
}

function updateBrowserExecutionMode(changed){
  const separate = required('separateBrowserPerTest');
  const parallel = required('parallelExecution');
  // Parallel execution owns a fixed browser pool. It must not turn on
  // "separate browser for each test", because that would create a new browser per scenario.
  if(parallel.checked){
    separate.checked = false;
    separate.disabled = true;
  }else{
    separate.disabled = false;
  }
  required('parallelThreadsField').classList.toggle('hidden', !parallel.checked);
  const note = byId('parallelPoolNote');
  if(note) note.classList.toggle('hidden', !parallel.checked);
}

function updateCookieSettings(){
  const enabled = required('replaceSessionCookie').checked;
  required('cookieSettingsPanel').classList.toggle('hidden', !enabled);
}

function addAdditionalCookieRow(){
  const list = required('additionalCookiesList');
  if(list.querySelectorAll('.additional-cookie-row').length >= 10){
    setStatus('A maximum of 10 additional cookies can be added.', true);
    return;
  }
  const row = document.createElement('div');
  row.className = 'additional-cookie-row';
  row.innerHTML = `
    <label>Cookie name
      <input class="additional-cookie-name" autocomplete="off" placeholder="New cookie name" />
    </label>
    <label>Cookie value
      <input class="additional-cookie-value" type="password" autocomplete="off" placeholder="Cookie value" />
    </label>
    <button type="button" class="remove-cookie-button" aria-label="Remove additional cookie">Remove</button>`;
  row.querySelector('.remove-cookie-button').addEventListener('click', () => row.remove());
  list.appendChild(row);
  row.querySelector('.additional-cookie-name').focus();
}

function collectAdditionalCookies(){
  const rows = [...required('additionalCookiesList').querySelectorAll('.additional-cookie-row')];
  const cookies = rows.map(row => ({
    name: row.querySelector('.additional-cookie-name').value.trim(),
    value: row.querySelector('.additional-cookie-value').value
  }));
  const incomplete = cookies.find(cookie => !cookie.name || !cookie.value.trim());
  if(incomplete) throw new Error('Enter both name and value for every additional cookie, or remove the empty row.');
  const names = new Set();
  for(const cookie of cookies){
    if(names.has(cookie.name)) throw new Error(`Additional cookie names must be unique: ${cookie.name}`);
    names.add(cookie.name);
  }
  if(required('replaceSessionCookie').checked){
    const replacementName = required('sessionCookieName').value.trim();
    if(cookies.some(cookie => cookie.name === replacementName)){
      throw new Error(`Additional cookie '${replacementName}' duplicates the cookie selected for replacement.`);
    }
  }
  return cookies;
}

function initialize(){
  try{
    required('validateConnectionBtn').addEventListener('click', validateAiConnection);
    required('toggleConnectionKeyBtn').addEventListener('click', () => {
      const input = required('connectionApiKey');
      const reveal = input.type === 'password';
      input.type = reveal ? 'text' : 'password';
      required('toggleConnectionKeyBtn').textContent = reveal ? 'Hide' : 'Show';
    });
    ['connectionEndpoint','connectionModel','connectionApiKey'].forEach(id => required(id).addEventListener('keydown', event => {
      if(event.key === 'Enter'){ event.preventDefault(); validateAiConnection(); }
    }));
    required('changeConnectionBtn').addEventListener('click', changeAiConnection);
    required('browserId').addEventListener('change', updateBrowserSelection);
    required('browserZoomEnabled').addEventListener('change', () => updateBrowserZoomControls(recorderActive()));
    required('separateBrowserPerTest').addEventListener('change', () => updateBrowserExecutionMode('separate'));
    required('parallelExecution').addEventListener('change', () => updateBrowserExecutionMode('parallel'));
    required('replaceSessionCookie').addEventListener('change', updateCookieSettings);
    required('addCookieBtn').addEventListener('click', addAdditionalCookieRow);
    required('enableRecorder').addEventListener('change', event => {
      const enabled = Boolean(event.target.checked);
      required('recorderPanel').classList.toggle('hidden', !enabled);
      if(enabled) setRecorderStatus('Enter the mandatory application URL and click Start recording.');
    });
    required('startRecorderBtn').addEventListener('click', startRecorder);
    required('stopRecorderBtn').addEventListener('click', stopRecorder);
    required('copyRecordedStepsBtn').addEventListener('click', copyRecordedSteps);
    required('downloadRecordedExcelBtn').addEventListener('click', () => downloadRecorderArtifact('recorded-steps.xlsx'));
    required('downloadRecordedJsonBtn').addEventListener('click', () => downloadRecorderArtifact('recorded-actions.json'));
    required('scenarioFile').addEventListener('change', async () => {
      const file = required('scenarioFile').files?.[0];
      safeText('fileName', file ? `${file.name} · ${Math.max(1, Math.round(file.size/1024))} KB` : 'No file selected');
      const field = byId('sheetField');
      if(!file || !/\.xlsx?$/i.test(file.name)){ availableSheets = []; renderSheetCheckboxes([]); if(field) field.classList.add('hidden'); return; }
      try{
        const fd = new FormData(); fd.append('scenarioFile', file);
        const response = await fetch('/api/runs/sheets',{method:'POST',body:fd,cache:'no-store'});
        const data = await readJson(response); if(!response.ok) throw new Error(data.error || 'Unable to read worksheets');
        availableSheets = Array.isArray(data.sheets) ? data.sheets : [];
        renderSheetCheckboxes(availableSheets);
        if(field) field.classList.toggle('hidden', availableSheets.length === 0);
        setStatus(availableSheets.length ? `${availableSheets.length} worksheet(s) detected. Select one or more sheets to execute.` : 'No worksheets found.', availableSheets.length===0);
      }catch(error){ if(field) field.classList.add('hidden'); setStatus(`Unable to read worksheets: ${error.message}`, true); }
    });
    required('selectAllSheetsBtn').addEventListener('click', () => setAllSheets(true));
    required('clearAllSheetsBtn').addEventListener('click', () => setAllSheets(false));
    required('runBtn').addEventListener('click', startRun);
    required('selectFailedBtn').addEventListener('click', () => {
      document.querySelectorAll('.test-select').forEach(cb => cb.checked = cb.dataset.status === 'FAILED');
      updateRerunButton();
    });
    required('rerunSelectedBtn').addEventListener('click', rerunSelected);
    document.querySelectorAll('[data-artifact]').forEach(button => {
      button.addEventListener('click', () => openArtifact(button.dataset.artifact, button.hasAttribute('data-download')));
    });
    setArtifactButtons(false);
    updateRecorderControls();
    updateBrowserZoomControls(false);
    updateBrowserExecutionMode();
    updateCookieSettings();
    showConnectionScreen();
  }catch(error){
    setStatus(`UI initialization failed: ${error.message}`, true);
    console.error(error);
  }
}

if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', initialize);
else initialize();
