package com.itps.vibium.controller;

import com.itps.vibium.service.LlmClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.LinkedHashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/connection")
public class ConnectionController {
    private final LlmClient llmClient;

    public ConnectionController(LlmClient llmClient) {
        this.llmClient = llmClient;
    }

    @PostMapping("/validate")
    public ResponseEntity<?> validate(@RequestBody Map<String, String> request) {
        try {
            String endpoint = request.get("endpoint");
            String apiKey = request.get("apiKey");
            String model = request.get("model");
            LlmClient.ConnectionValidation validation = llmClient.validateConnection(endpoint, apiKey, model);
            Map<String, Object> response = new LinkedHashMap<>();
            response.put("valid", true);
            response.put("endpoint", validation.endpoint());
            response.put("model", validation.model());
            response.put("message", "Connection validated successfully");
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            String message = e.getMessage();
            if (message == null || message.isBlank()) message = "Unable to validate the AI connection";
            return ResponseEntity.badRequest().body(Map.of("valid", false, "error", message));
        }
    }
}
