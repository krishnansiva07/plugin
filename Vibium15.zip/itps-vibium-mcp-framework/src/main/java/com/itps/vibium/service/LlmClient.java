package com.itps.vibium.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.itps.vibium.model.RunConfig;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.web.client.RestClientResponseException;
import org.springframework.web.client.RestTemplate;

import java.util.*;

@Service
public class LlmClient {
    private final ObjectMapper mapper = new ObjectMapper();
    private final RestTemplate restTemplate = new RestTemplate();

    public boolean isConfigured(RunConfig config) {
        return config != null && config.getLlmBaseUrl() != null && !config.getLlmBaseUrl().isBlank();
    }


    public ConnectionValidation validateConnection(String baseUrl, String apiKey, String model) throws Exception {
        String normalizedBase = requireHttpUrl(baseUrl);
        String normalizedModel = model == null ? "" : model.trim();
        String normalizedKey = apiKey == null ? "" : apiKey.trim();
        if (normalizedModel.isBlank()) throw new IllegalArgumentException("Model is required");
        if (normalizedKey.isBlank()) throw new IllegalArgumentException("API key is required");

        String endpoint = normalizeEndpoint(normalizedBase);
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("model", normalizedModel);
        body.put("temperature", 0);
        body.put("max_tokens", 8);
        body.put("messages", List.of(Map.of("role", "user", "content", "Reply with OK only.")));

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setBearerAuth(normalizedKey);

        SimpleClientHttpRequestFactory factory = new SimpleClientHttpRequestFactory();
        factory.setConnectTimeout(10_000);
        factory.setReadTimeout(30_000);
        RestTemplate validationClient = new RestTemplate(factory);
        String raw;
        try {
            raw = validationClient.postForObject(endpoint, new HttpEntity<>(body, headers), String.class);
        } catch (RestClientResponseException e) {
            int status = e.getStatusCode().value();
            if (status == 401 || status == 403) throw new IllegalArgumentException("API key was rejected by the endpoint");
            if (status == 404) throw new IllegalArgumentException("Endpoint or model route was not found");
            if (status == 400) throw new IllegalArgumentException("Endpoint rejected the model or request format");
            throw new IllegalArgumentException("Connection validation failed with HTTP " + status);
        }
        JsonNode root = mapper.readTree(raw == null ? "{}" : raw);
        JsonNode message = root.path("choices").path(0).path("message").path("content");
        if (message.isMissingNode() || message.asText().isBlank()) {
            throw new IllegalArgumentException("Endpoint responded, but no OpenAI-compatible chat completion was returned");
        }
        return new ConnectionValidation(normalizedBase, normalizedModel);
    }

    private String requireHttpUrl(String baseUrl) {
        if (baseUrl == null || baseUrl.isBlank()) throw new IllegalArgumentException("Endpoint is required");
        String value = baseUrl.trim();
        try {
            java.net.URI uri = java.net.URI.create(value);
            String scheme = uri.getScheme();
            if (scheme == null || !(scheme.equalsIgnoreCase("http") || scheme.equalsIgnoreCase("https")) || uri.getHost() == null) {
                throw new IllegalArgumentException("Endpoint must be a valid http:// or https:// URL");
            }
            return value;
        } catch (IllegalArgumentException e) {
            if (e.getMessage() != null && e.getMessage().startsWith("Endpoint")) throw e;
            throw new IllegalArgumentException("Endpoint must be a valid http:// or https:// URL");
        }
    }

    public record ConnectionValidation(String endpoint, String model) {}

    public String complete(String systemPrompt, String userPrompt, RunConfig config, int maxTokens) throws Exception {
        if (!isConfigured(config)) {
            throw new IllegalArgumentException("LLM base URL is required when Use LLM is ON");
        }
        String endpoint = normalizeEndpoint(config.getLlmBaseUrl());
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("model", defaultIfBlank(config.getLlmModel(), "gpt-oss-120b"));
        body.put("temperature", 0.05);
        body.put("max_tokens", Math.max(300, maxTokens));
        body.put("messages", List.of(
                Map.of("role", "system", "content", systemPrompt),
                Map.of("role", "user", "content", userPrompt)
        ));

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        if (config.getLlmApiKey() != null && !config.getLlmApiKey().isBlank()) {
            headers.setBearerAuth(config.getLlmApiKey().trim());
        }
        String raw = restTemplate.postForObject(endpoint, new HttpEntity<>(body, headers), String.class);
        JsonNode root = mapper.readTree(raw == null ? "{}" : raw);
        String content = root.path("choices").path(0).path("message").path("content").asText();
        return extractJson(content);
    }

    public String planMcpCall(String userPrompt, RunConfig config) throws Exception {
        return complete(agentSystemPrompt(), userPrompt, config, 1300);
    }


    public String healMcpCall(String userPrompt, RunConfig config) throws Exception {
        String system = "You are the self-healing brain for the ITPS VIBIUM MCP Framework. " +
                "Return only valid minified JSON. Use Vibium MCP tools only. Never use Selenium or Playwright. " +
                "Analyse the failed instruction, MCP error, complete current DOM/page model, ranked candidates, clickable ancestors, visibility, hit-test and previous plan. " +
                "Do not repeat the same failed selector or strategy. Choose a materially different safe strategy. " +
                "Prefer exact @e references or unique selectors from the supplied page model. Never invent an element not present in the observation. " +
                "Return {\"confidence\":0.0,\"strategy\":\"short name\",\"calls\":[{\"tool\":\"browser_click\",\"arguments\":{}}],\"why\":\"evidence\"}.";
        return complete(system, userPrompt, config, 1800);
    }

    private String agentSystemPrompt() {
        return "You are an MCP browser automation agent for the ITPS VIBIUM MCP Framework. " +
                "Return only valid minified JSON, no markdown. " +
                "Use Vibium MCP tools only; never invent Selenium/Playwright code. " +
                "The browser is already started. Never call browser_start. " +
                "Use the supplied Vibium page map, text, and DOM probe to choose selectors or element references. Prefer @e refs from browser_map when present. " +
                "For icons like search/calendar/filter/export, do not use text selectors unless the exact visible text exists in the map; prefer aria-label, title, role, data-testid, SVG/button ref, or nearby accessible name. " +
                "For search/select flows, return the complete action chain in calls, for example click search icon, fill search text, click result, wait for load. " +
                "For click/fill/select instructions, return at least one real action tool, not only map/wait/screenshot. " +
                "Return this shape only: {\"calls\":[{\"tool\":\"browser_click\",\"arguments\":{...}}],\"why\":\"short reason\"}. " +
                "Use test data values exactly when placeholders are resolved.";
    }

    private String normalizeEndpoint(String base) {
        String trimmed = base.trim();
        if (trimmed.endsWith("/chat/completions")) return trimmed;
        if (trimmed.endsWith("/")) return trimmed + "chat/completions";
        return trimmed + "/chat/completions";
    }

    private String extractJson(String content) {
        if (content == null) return "{}";
        String trimmed = content.trim();
        if (trimmed.startsWith("```")) {
            trimmed = trimmed.replaceFirst("^```(?:json)?", "").replaceFirst("```$", "").trim();
        }
        int objectStart = trimmed.indexOf('{');
        int objectEnd = trimmed.lastIndexOf('}');
        int arrayStart = trimmed.indexOf('[');
        int arrayEnd = trimmed.lastIndexOf(']');
        if (objectStart >= 0 && objectEnd >= objectStart && (arrayStart < 0 || objectStart < arrayStart)) {
            return trimmed.substring(objectStart, objectEnd + 1);
        }
        if (arrayStart >= 0 && arrayEnd >= arrayStart) {
            return trimmed.substring(arrayStart, arrayEnd + 1);
        }
        return trimmed;
    }

    private String defaultIfBlank(String value, String fallback) {
        return value == null || value.isBlank() ? fallback : value;
    }
}
