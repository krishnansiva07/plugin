# AI Connection Gate

The application now starts on an AI connection screen instead of exposing the Home screen immediately.

## Startup flow

1. Enter an OpenAI-compatible endpoint.
2. Enter the model name.
3. Enter the API key.
4. Click **Validate & Continue**.
5. The backend performs a small `/chat/completions` request using the supplied model and Bearer key.
6. Only a successful OpenAI-compatible response opens the existing Home screen.

## Failure behavior

Invalid URLs, rejected keys, unavailable model routes, incompatible responses, and network errors keep the user on the connection screen. Home is never opened on validation failure.

## Home screen

The old editable LLM configuration card is replaced by a connection summary showing only status, endpoint and model. The API key is not displayed. **Change connection** returns to the gate and requires validation again.

## Security

The API key is not written to `application.properties`, reports, or UI status messages. It remains only in the current browser page state and the in-memory `RunConfig` used by execution/reruns.

## Validation timeouts

Connection timeout: 10 seconds. Read timeout: 30 seconds.
