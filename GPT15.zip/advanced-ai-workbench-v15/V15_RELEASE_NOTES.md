# GPT15 / Advanced AI Workbench V15 Release Notes

## Why V15

V14 fixed the Windows temporary-log sharing failure, but long autonomous sessions could still repeatedly resend a large accumulated conversation. A run with a ~100k-token active context repeated many times can consume millions of billed input tokens even though the model's context window is much smaller than the cumulative billable usage.

V15 changes the runtime so long work continues through compact active contexts rather than carrying the full historical transcript into every model call.

## Context manager

- Added `ContextWindowManager`.
- Estimates message tokens and model tool-schema tokens before every agent request.
- Uses the configured context window, or conservative model-name defaults when the UI value is `0`.
- Reserves the larger of the output allowance and the configured safety buffer.
- Triggers automatic compaction before the estimated usable input limit is crossed.
- Dynamically reduces the recent tail when system instructions/tool schemas consume more of the window.

## Checkpoint compaction

- Older non-system history is replaced by one structured continuation checkpoint.
- A no-tools semantic summarization request is preferred so objectives, decisions, completed work, blockers, files and the next action survive compaction.
- Deterministic runtime checkpointing is always available if the summary request fails, is rejected, is empty, or is unavailable.
- The live workspace, attachments and persisted conversation remain authoritative and are not deleted.
- Recent context remains in the active prompt so the agent can continue naturally rather than restarting the task.

## Tool-output pruning

- The six newest tool observations remain high fidelity under normal output sizes.
- Older tool observations are clipped to the configured cap (default 2,000 characters).
- A single oversized fresh tool result is capped at 50,000 characters in active context so a huge build log/minified file cannot overflow the model by itself.
- Both native `role=tool` messages and JSON-compatibility `TOOL RESULT for ...` messages are handled.

## Overflow recovery

- Provider context-length errors no longer act as the normal compaction trigger.
- If an unexpected real overflow still occurs, the runtime forces one additional compaction and retries the model call once with the smaller context.
- Context-length HTTP 400/422 responses are recognized before tool-compatibility fallback, so an overflow can no longer incorrectly mark a model as "native tools unsupported" or cause redundant JSON/plain retries.

## Token telemetry

Agent runs now track:

- model-call count;
- provider input, output and total tokens when returned;
- cached-input and cache-write tokens when exposed by compatible providers;
- cumulative estimated input when the provider omits usage;
- current estimated active context and configured/detected context window;
- compaction count and estimated active tokens removed;
- repeated calls prevented.

The agent console emits periodic token-usage events and the final response includes a compact token-management summary.

## Loop protection without limiting useful work

V15 still has **no fixed model-step/tool-action/build-repair ceiling**. Instead it blocks token-waste patterns tied to the same workspace revision:

- the same read/verifier/tool call producing the same normalized outcome three times on the same workspace revision (third result warns; the next identical outcome blocks);
- six consecutive non-actionable parent-model turns with no tool/workspace progress;
- repeated attempts to finish the same unverified revision without a new verifier/fix;
- identical non-actionable prose turns without workspace progress;
- repeated empty child/subagent turns and same-call/same-result child loops.

Any real workspace mutation creates a new revision and naturally resets the duplicate fingerprint.

## UI/settings

Added settings for:

- exact model context window (`0` = conservative auto-detect);
- proactive automatic compaction;
- recent context retained (default 8,000 tokens);
- safety buffer (default 20,000 tokens);
- old tool-output cap (default 2,000 characters).

## Inherited V14 fix

Foreground Windows `bash` / build / test / check continues to use process pipes rather than temporary log redirection, preventing the Windows sharing-violation failure that previously caused repeated `verification_required` loops.
