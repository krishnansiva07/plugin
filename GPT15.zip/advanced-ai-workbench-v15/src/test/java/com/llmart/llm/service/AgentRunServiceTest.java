package com.llmart.llm.service;

import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class AgentRunServiceTest {

    @Test
    void tracksPlanMutationDiffAndVerificationRevision() {
        AgentRunService service = new AgentRunService();
        AgentRunService.AgentRun run = service.start("conversation", "project");

        run.setPlan(List.of("Inspect", "Edit", "Verify"));
        assertTrue(run.hasPlan());
        assertTrue(run.hasOpenPlanItems());

        run.updatePlan(1, "completed", "inspected");
        run.updatePlan(2, "completed", "changed");
        run.markMutation();
        assertFalse(run.diffReviewedCurrentRevision());
        run.markDiffReview();
        assertTrue(run.diffReviewedCurrentRevision());

        run.markVerificationAttempt(true, "build passed");
        assertTrue(run.verifiedCurrentRevision());
        run.updatePlan(3, "completed", "passed");
        assertFalse(run.hasOpenPlanItems());
    }

    @Test
    void cancellationIsIdempotentAndFinishedRunCannotBeCancelled() {
        AgentRunService service = new AgentRunService();
        AgentRunService.AgentRun running = service.start("conversation", null);
        assertTrue(service.cancel(running.id()));
        assertFalse(service.cancel(running.id()));
        assertThrows(AgentCancelledException.class, running::checkCancelled);

        AgentRunService.AgentRun completed = service.start("conversation", null);
        completed.finish("completed");
        assertFalse(service.cancel(completed.id()));
        assertEquals("completed", completed.snapshot().get("status"));
    }
    @Test
    void tracksProviderAndCompactionTokenTelemetry() {
        AgentRunService service = new AgentRunService();
        AgentRunService.AgentRun run = service.start("conversation", "project");

        run.recordContextEstimate(42_000, 131_072);
        run.recordModelUsage(new OpenAiCompatibleClient.Usage(40_000, 1_500, 41_500, 20_000, 0, true), 42_000);
        run.recordCompaction(25_000, "Proactive checkpoint");
        run.markRepeatedCallPrevented();

        assertEquals(1, run.modelCalls());
        assertEquals(41_500, run.providerTotalTokens());
        assertEquals(20_000, run.cachedInputTokens());
        assertEquals(1, run.compactions());
        var usage = (java.util.Map<?,?>) run.snapshot().get("tokenUsage");
        assertEquals(42_000L, usage.get("currentContextTokens"));
        assertEquals(25_000L, usage.get("estimatedTokensSavedByCompaction"));
        assertEquals(1L, usage.get("repeatedCallsPrevented"));
    }

}
