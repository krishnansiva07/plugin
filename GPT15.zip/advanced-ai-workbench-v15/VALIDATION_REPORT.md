# V15 Validation Report

See `V15_RELEASE_NOTES.md` for the V15 feature summary and `V14_RELEASE_NOTES.md` / `V13_RELEASE_NOTES.md` for inherited fixes.

## Passed in the packaging environment

- Full Java 17 parser scan: **64 Java main/test source files, 0 syntax errors**.
- Frontend syntax: `node --check` passed for `app.js` and `markdown.js`.
- Standalone `ContextWindowManager` Java harness passed:
  - proactive pre-overflow compaction;
  - semantic checkpoint selection;
  - deterministic checkpoint fallback path;
  - recent-tail retention;
  - oversized fresh tool-output bounding;
  - old native-tool output pruning;
  - JSON-compatibility tool-result pruning.
- Standalone `AgentRunService` Java harness passed:
  - provider input/output/total-token accounting;
  - cache-read/cache-write accounting;
  - current context/window telemetry;
  - compaction accounting and estimated saved tokens;
  - repeated-call prevention accounting.
- Existing V13/V14 multi-resource, direct-workspace and Windows pipe-execution source is retained.
- `pom.xml` parses as valid XML.

## Maven limitation in this packaging environment

The sandbox has Java 21 (the project targets Java 17) but no installed Maven, and outbound DNS to `repo.maven.apache.org` is unavailable. `./mvnw` correctly attempted its Maven 3.9.11 bootstrap but could not download it. Therefore I cannot truthfully claim a dependency-resolved `mvn clean test` or executable-JAR build here.

Run the included validation on the Windows target machine:

```bat
validate-local.bat
```

It runs Java/JS checks, Maven tests, then packages:

`target\advanced-ai-chat-2.3.0-SNAPSHOT.jar`

## V15 token-management behavior validated at source/harness level

- Context is estimated before each physical agent model request.
- Tool schemas count toward the active-context budget.
- Old tool observations are pruned before compaction; a single oversized new tool result is capped to avoid consuming a whole context window.
- Compaction keeps a dynamically sized recent tail that leaves room for system instructions, tool schemas, request overhead and the checkpoint.
- Semantic checkpoint generation is optional and cannot strand the run because deterministic checkpointing is the fallback.
- Real provider context errors trigger one forced compaction/retry rather than an endless overflow loop.
- Provider usage is recorded when returned; estimates remain available when providers omit usage.
- Duplicate verifier/tool/non-action loops are stopped without introducing a fixed ceiling on useful autonomous work.
