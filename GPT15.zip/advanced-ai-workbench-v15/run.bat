@echo off
setlocal
cd /d "%~dp0"
set JAR=target\advanced-ai-chat-2.3.0-SNAPSHOT.jar
if not exist "%JAR%" (
  echo JAR not found. Building V15...
  call mvnw.cmd clean package
  if errorlevel 1 exit /b 1
)
java -jar "%JAR%"
