# Advanced AI Workbench Agent — V15

Java 17 local autonomous workspace agent with **Chat**, **Analyze**, and **Agent** modes.

This build is intentionally general-purpose. Dedicated test-case generation has been removed. Git operations are intentionally out of scope.


## V15 token-management upgrade

V15 changes long-running Agent sessions from overflow-driven history retention to **proactive context management**, using the same core ideas used by modern coding agents such as OpenCode and Claude-style harnesses:

- estimates the active request before every model call, including messages and advertised tool schemas;
- reserves output/safety headroom and compacts **before** the request reaches the provider context limit;
- keeps a recent working tail while replacing older history with a structured continuation checkpoint;
- prefers a semantic model-generated checkpoint, with a deterministic runtime checkpoint as a fail-safe if summarization is unavailable;
- prunes old tool observations and also caps a single oversized fresh tool result so logs/minified files cannot consume the entire window;
- preserves the live workspace, attachments, todo state, verification state and durable conversation outside the compacted active prompt;
- performs one forced compaction/retry if the provider still reports a real context overflow;
- records provider input/output/cache usage when the provider returns it, plus estimated active-context usage and compaction savings;
- prevents same-call/same-result tool loops, repeated verification-finish loops, and consecutive non-actionable model turns from spending tokens indefinitely while retaining **no fixed useful-work/action ceiling**.

Default auto-detected behavior is conservative: GPT-OSS models use a 131,072-token context hint, Claude-named models use 200,000, and unknown models fall back to 128,000 unless you set the exact model window in Settings. The default recent tail is 8,000 tokens with a 20,000-token safety buffer. Set the exact context window for the provider/model when you know it.

## V14 Windows execution fix

V14 executes foreground build/test/check/bash commands through process pipes instead of temporary output files. This avoids intermittent Windows Temp-file sharing violations that could prevent `npm`, `npx`, `node`, Maven, and similar commands from starting and could leave an edited workspace waiting indefinitely for verification.


## Agent execution model

Agent mode can use either a previously mapped directory **or an existing project/file path explicitly supplied in the prompt**. V13 can also resolve multiple paths in the same request. The primary project is the live workspace and additional prompt resources are exposed through safe aliases:

```text
User maps a path OR supplies existing path(s) in the prompt
        ↓
Resolve primary workspace + additional resource aliases
        ↓
Model turn (native tools first)
        ↓
One or many tool calls
        ↓
Read / search / edit / shell / build / run / verify
        ↓
Real tool observations returned to model
        ↓
Fix and repeat until verified complete or genuinely blocked
```

There is **no temporary project mirror, staging workspace, later Apply step, fixed model-step ceiling, fixed tool-action ceiling, fixed build/fix retry count, or default shell timeout** in Agent mode.

`Max output tokens = 0` means the application does not set `max_tokens`; the selected provider/model controls its own output maximum. `Model context window = 0` now means **conservative auto-detect**, not "wait for overflow". Agent mode estimates the request and proactively compacts before the usable input budget is exceeded. A real provider overflow still triggers one forced compaction/retry as a safety net.

Unavoidable limits still come from the selected model/provider, operating system, disk, RAM, process limits, network availability and third-party tools.


## V13 highlights

V13 keeps the core **generic**. It does not hardcode Selenium, Playwright, Cucumber, recorder formats, or any other domain workflow. Domain behavior belongs in skills/MCPs; the core provides reusable engineering primitives.

- **Intent-aware resource roles:** `primary_workspace`, `secondary_workspace`, `reference`, `input`, and `diagnostic`.
- **User intent beats project inference:** a labelled input/log remains read-only even if its parent is another valid project.
- **Context-safe large files:** full reads above 256 KiB are guarded instead of flooding the model context.
- **Generic indexing/chunking:** `file_index`, `resource_index`, `read_chunk`, and `resource_chunk` support large JSON/XML/CSV/log/generated/minified text without assuming a particular format.
- **Bounded long-line output:** line reads and grep excerpts are clipped around useful context, with chunk tools available for exact data.
- **58 built-in tools**, plus dynamically discovered MCP tools.

## Prompt paths and multiple workspaces

V13 resolves explicit filesystem paths before Agent execution. If Agent mode has no active workspace, an existing project directory or source/config file in the prompt can establish the primary workspace automatically. A supplied source file is walked upward to locate its owning project root.

When several paths are supplied, the runtime keeps one primary `@workspace` and exposes the others through `resource_catalog`. Each resource receives a generic role: primary workspace, secondary workspace, reference, input, or diagnostic. Reference/input/diagnostic resources are read-only; secondary workspaces can be writable. User labels take precedence over parent-project inference. All writes and commands remain subject to the normal Edit/Shell permission settings.

Example:

```text
Project: D:\Work\PaymentUI
Backend: D:\Work\PaymentAPI
Issue log: C:\Temp\failure.log
Reference: D:\Archive\PaymentUI-working
```

The model receives canonical aliases rather than unrestricted filesystem access. A path invented by the model is **not** automatically trusted; it must have been resolved from a path the user explicitly supplied.

Secondary-resource tools include `resource_catalog`, `resource_list`, `resource_info`, `resource_index`, `resource_read`, `resource_chunk`, `resource_grep`, `resource_edit`, `resource_write`, `resource_delete`, `resource_copy`, `resource_move`, `resource_build`, `resource_test`, `resource_check`, and `resource_bash`.

## Main Agent tools

Workspace/navigation:

- `inspect_workspace`
- `list`
- `glob`
- `grep`
- `file_info`
- `file_index`
- `read`
- `read_chunk`
- `read_many`

Mutation, direct to the mapped path:

- `edit`
- `write`
- `copy`
- `move`
- `delete`
- `apply_patch`

Execution and runtime verification:

- `build`
- `test`
- `check`
- `bash` — normal workspace shell with pipes/redirection/chaining; no default application timeout
- `process_start`
- `process_status`
- `process_output`
- `process_stop`
- `http_request` — inspect a running web/API application using real HTTP responses

Context/helpers:

- `attachment_list`
- `attachment_read`
- `skill`
- `workspace_status`
- `workspace_diff`
- `todowrite`
- `todoread`

Native OpenAI-compatible tool/function calling is the primary transport. If a provider does not support native tools, the runtime automatically falls back to JSON compatibility mode instead of aborting on a normal prose response.

## Build → run → inspect → fix loop

For code/configuration mutations the runtime prevents a normal `completed` response while the current revision still requires verification. The model is instructed to:

1. inspect the actual workspace;
2. make the requested change directly;
3. build/check/test as appropriate;
4. start a long-running application with `process_start` when needed;
5. inspect stdout/stderr with `process_output` and process state with `process_status`;
6. verify HTTP applications with `http_request` or custom `bash` checks;
7. diagnose real errors;
8. edit and rerun until the current revision passes or a genuine external blocker is established.

A custom `bash` or `http_request` verifier can set `verification=true`.

## Documents and attachments

The file picker no longer restricts extensions and the application no longer imposes a fixed upload-size limit. Actual practical limits are the browser/server/machine resources.

At upload time, textual content is extracted eagerly. Supported paths include:

- DOCX through direct WordprocessingML extraction with Tika fallback;
- XLSX/PPTX through Apache POI with Tika fallback;
- PDF, legacy Office, RTF, OpenDocument, HTML and other Tika-supported formats;
- plain text/source/configuration files.

Documents attached to the **current message** are always first-class context in both Chat and Analyze modes. In Agent mode, the same extracted content is available in the message and through `attachment_list` / `attachment_read`.

Extraction status is explicit: `ready`, `empty`, `failed`, or `not_applicable`.

## Persistent local workspace

You can still map a local path once under **Open workspace → Local workspace path**. The workspace ID is persisted and reusable across actions, new chats and page reloads until explicitly disconnected. In Agent mode, V13 can alternatively create the active workspace from an existing explicit project/file path in the prompt.

Agent mode always works directly in this path. There is no copy-back/apply operation.

## Permissions

Edit and shell execution can be configured as **Allow / Ask / Deny**. Ask supports:

- Deny
- Approve once
- Allow this run

Approval waiting has no application timeout. Stop/cancel remains available to the user.

## Running

Requirement: Java 17+. Maven is used when already installed; otherwise `mvnw` / `mvnw.cmd` can bootstrap Maven 3.9.11 on first use (network required for that first bootstrap).

```bash
./mvnw clean test
./mvnw clean package
java -jar target/advanced-ai-chat-2.3.0-SNAPSHOT.jar
```

Or use `run.sh` / `run.bat`.

Open `http://localhost:8090`. The server binds to `127.0.0.1` by default because the application has direct local-filesystem capabilities.

## V13 generic-agent modules

V13 retains the V11 generic-agent modules and adds prompt path resolution plus multi-resource execution:

- persistent workspace profiling;
- root/nested project instructions;
- lazy reusable skills;
- fresh-context subagent delegation;
- generic MCP discovery and dynamically namespaced MCP tools;
- generic LSP diagnostics/navigation;
- attachment list/read/search resources;
- native multi-tool turns with eligible read-only parallelism.
- prompt path/project-root resolution;
- multiple writable projects and read-only diagnostic/reference files in one run;
- cross-resource read/edit/copy/build/test/check/shell tools;
- subtree-skipping workspace snapshots for large repositories;
- Maven bootstrap scripts for simpler packaging.

Git remains intentionally out of scope. A PTY-style fully interactive terminal is not yet implemented; normal workspace shell and managed background processes are available.
