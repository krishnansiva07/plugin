# V14 Release Notes

## Windows command execution reliability

- Foreground `bash`, `build`, `test`, and `check` execution no longer redirects stdout/stderr through a temporary `advanced-ai-agent-command-*.log` file.
- Output is drained from the child process pipe concurrently, avoiding Windows `ERROR_SHARING_VIOLATION` / `The process cannot access the file because it is being used by another process` failures seen with npm, npx, node and other commands.
- Large command output is consumed while the process is running, preventing pipe-buffer deadlocks.
- Command start failures are returned as verifier results instead of being masked by temporary-log cleanup errors.

## Verification loop behavior

- The underlying cause of the repeated `verification_required` cycle shown in the V13 screenshots is removed: verification commands can now start without the temporary log-file lock.
- V14 keeps the existing no-artificial-step-budget design; it still continues build/run/fix loops when progress is possible.
