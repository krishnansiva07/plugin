package com.llmart.llm.service;

import com.llmart.llm.exception.TcgenException;
import org.apache.tika.exception.TikaException;
import org.apache.tika.metadata.Metadata;
import org.apache.tika.parser.AutoDetectParser;
import org.apache.tika.parser.ParseContext;
import org.apache.tika.sax.BodyContentHandler;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.xml.sax.SAXException;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.Set;

@Service
public class FileTextExtractor {

    private static final long MAX_FILE_SIZE_BYTES = 25L * 1024L * 1024L;
    private static final Set<String> IMAGE_EXTENSIONS = Set.of("png", "jpg", "jpeg", "bmp", "tif", "tiff", "webp");

    private final OcrService ocrService;
    private final DocxImageOcrExtractor docxImageOcrExtractor;

    @Value("${tcgen.max-extracted-characters:60000}")
    private int maxExtractedCharacters;

    public FileTextExtractor(OcrService ocrService, DocxImageOcrExtractor docxImageOcrExtractor) {
        this.ocrService = ocrService;
        this.docxImageOcrExtractor = docxImageOcrExtractor;
    }

    public String extract(MultipartFile file) {
        validateFile(file);

        String fileName = file.getOriginalFilename() == null ? "uploaded-file" : file.getOriginalFilename();
        String extension = extension(fileName);

        try {
            byte[] bytes = file.getBytes();
            String extractedText;

            if (isImage(extension, file.getContentType())) {
                extractedText = extractImageText(bytes, fileName);
            } else {
                extractedText = extractDocumentText(bytes);
                if ("docx".equals(extension)) {
                    String embeddedImageText = docxImageOcrExtractor.extractTextFromEmbeddedImages(bytes, fileName);
                    if (!embeddedImageText.isBlank()) {
                        extractedText = merge(extractedText, embeddedImageText);
                    }
                }
            }

            extractedText = cleanup(extractedText);

            if (extractedText.isBlank()) {
                throw new TcgenException("No readable Acceptance Criteria or design text found in the uploaded file. For design-only screenshots without readable text, Vision AI support is required.");
            }

            if (extractedText.length() > maxExtractedCharacters) {
                return extractedText.substring(0, maxExtractedCharacters)
                        + "\n\n[Content truncated because file text is too large.]";
            }

            return extractedText;
        } catch (TcgenException ex) {
            throw ex;
        } catch (IOException ex) {
            throw new TcgenException("Unable to read uploaded file. Upload txt, pdf, docx, xlsx, csv, json, xml, html, md, png, jpg, jpeg, bmp, tif, tiff or webp file.", ex);
        }
    }

    private String extractImageText(byte[] bytes, String fileName) {
        String ocrText = ocrService.extractTextFromImage(bytes, fileName);
        if (ocrText.isBlank()) {
            throw new TcgenException("OCR completed, but no readable text was found in the image. Upload a clearer screenshot or add more context in Additional Prompt.");
        }
        return "--- OCR TEXT FROM UPLOADED IMAGE ---\n" + ocrText;
    }

    private String extractDocumentText(byte[] bytes) {
        try {
            BodyContentHandler handler = new BodyContentHandler(-1);
            Metadata metadata = new Metadata();
            AutoDetectParser parser = new AutoDetectParser();
            ParseContext context = new ParseContext();

            parser.parse(new ByteArrayInputStream(bytes), handler, metadata, context);
            return cleanup(handler.toString());
        } catch (IOException | TikaException | SAXException ex) {
            throw new TcgenException("Unable to extract readable text from uploaded document.", ex);
        }
    }

    private void validateFile(MultipartFile file) {
        if (file == null || file.isEmpty()) {
            throw new TcgenException("Please upload a file containing Acceptance Criteria, design screenshot or requirement details.");
        }

        if (file.getSize() > MAX_FILE_SIZE_BYTES) {
            throw new TcgenException("File size should be less than 25MB.");
        }
    }

    private String merge(String documentText, String imageText) {
        StringBuilder merged = new StringBuilder();
        if (documentText != null && !documentText.isBlank()) {
            merged.append(documentText.trim());
        }
        if (imageText != null && !imageText.isBlank()) {
            if (!merged.isEmpty()) {
                merged.append("\n\n");
            }
            merged.append(imageText.trim());
        }
        return merged.toString();
    }

    private boolean isImage(String extension, String contentType) {
        if (IMAGE_EXTENSIONS.contains(extension)) {
            return true;
        }
        return contentType != null && contentType.toLowerCase().startsWith("image/");
    }

    private String extension(String fileName) {
        int index = fileName == null ? -1 : fileName.lastIndexOf('.');
        if (index < 0 || index == fileName.length() - 1) {
            return "";
        }
        return fileName.substring(index + 1).toLowerCase();
    }

    private String cleanup(String text) {
        return text == null ? "" : text.replaceAll("\\r", "")
                .replaceAll("[ \\t]+", " ")
                .replaceAll("\\n{3,}", "\\n\\n")
                .trim();
    }
}
