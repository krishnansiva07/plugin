package com.llmart.llm.service;

import com.llmart.llm.exception.TcgenException;
import net.sourceforge.tess4j.ITesseract;
import net.sourceforge.tess4j.Tesseract;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.core.io.ClassPathResource;

import javax.imageio.ImageIO;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Service
public class OcrService {

    @Value("${tcgen.ocr.enabled:true}")
    private boolean ocrEnabled;

    @Value("${tcgen.ocr.language:eng}")
    private String language;

    @Value("${tcgen.ocr.tessdata-path:}")
    private String tessDataPath;

    @Value("${tcgen.ocr.bundle-tessdata.enabled:true}")
    private boolean bundledTessdataEnabled;

    @Value("${tcgen.ocr.minimum-width:900}")
    private int minimumWidth;

    @Value("${tcgen.ocr.minimum-height:600}")
    private int minimumHeight;

    public String extractTextFromImage(byte[] imageBytes, String sourceName) {
        if (!ocrEnabled) {
            throw new TcgenException("OCR is disabled. Enable tcgen.ocr.enabled=true to read image screenshots.");
        }
        if (imageBytes == null || imageBytes.length == 0) {
            return "";
        }

        Path resolvedTessDataPath = resolveTessDataPath()
                .orElseThrow(() -> new TcgenException(buildTessdataNotFoundMessage()));
        validateTrainedData(resolvedTessDataPath);

        try {
            BufferedImage image = ImageIO.read(new ByteArrayInputStream(imageBytes));
            if (image == null) {
                return "";
            }

            BufferedImage preparedImage = upscaleIfRequired(image);

            ITesseract tesseract = new Tesseract();
            tesseract.setDatapath(resolvedTessDataPath.toString());
            tesseract.setLanguage(resolveLanguage());

            String text = tesseract.doOCR(preparedImage);
            return cleanup(text);
        } catch (IOException ex) {
            throw new TcgenException("Unable to read image file " + safeName(sourceName) + ". Upload a clear PNG, JPG, JPEG, BMP, TIFF or WEBP image.", ex);
        } catch (Throwable ex) {
            if (ex instanceof VirtualMachineError) {
                throw (VirtualMachineError) ex;
            }
            if (ex instanceof ThreadDeath) {
                throw (ThreadDeath) ex;
            }
            throw new TcgenException(buildOcrFailureMessage(safeName(sourceName), resolvedTessDataPath, ex), ex);
        }
    }

    public Map<String, Object> status() {
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("enabled", ocrEnabled);
        result.put("language", resolveLanguage());
        result.put("configuredTessdataPath", blankToEmpty(tessDataPath));
        result.put("TESSDATA_PREFIX", blankToEmpty(System.getenv("TESSDATA_PREFIX")));
        result.put("TCGEN_OCR_TESSDATA_PATH", blankToEmpty(System.getenv("TCGEN_OCR_TESSDATA_PATH")));

        Optional<Path> path = resolveTessDataPath();
        result.put("resolvedTessdataPath", path.map(Path::toString).orElse(""));
        result.put("tessdataFound", path.isPresent());
        result.put("trainedDataFound", path.map(this::allLanguageFilesExist).orElse(false));
        result.put("bundledTessdataEnabled", bundledTessdataEnabled);
        result.put("bundledTessdataAvailable", bundledTessdataAvailable());
        result.put("requiredFiles", requiredTrainedDataFiles(path.orElse(null)));
        result.put("message", buildStatusMessage(path));
        return result;
    }

    private Optional<Path> resolveTessDataPath() {
        List<String> candidates = new ArrayList<>();
        addIfPresent(candidates, tessDataPath);
        addIfPresent(candidates, System.getenv("TCGEN_OCR_TESSDATA_PATH"));
        addIfPresent(candidates, System.getenv("TESSDATA_PREFIX"));

        candidates.add("./tessdata");
        candidates.add("tessdata");
        candidates.add("src/main/resources/tessdata");
        candidates.add("target/classes/tessdata");
        candidates.add("C:/Program Files/Tesseract-OCR/tessdata");
        candidates.add("C:/Program Files/Tesseract-OCR");
        candidates.add("C:/Program Files (x86)/Tesseract-OCR/tessdata");
        candidates.add("C:/Program Files (x86)/Tesseract-OCR");
        candidates.add("/usr/share/tesseract-ocr/5/tessdata");
        candidates.add("/usr/share/tesseract-ocr/4.00/tessdata");
        candidates.add("/usr/share/tesseract-ocr/tessdata");
        candidates.add("/usr/share/tessdata");
        candidates.add("/usr/local/share/tessdata");
        candidates.add("/opt/homebrew/share/tessdata");

        Optional<Path> externalOrProjectPath = candidates.stream()
                .filter(StringUtils::hasText)
                .map(String::trim)
                .map(Paths::get)
                .map(this::normalizeTessdataPath)
                .filter(this::isUsableTessdataDirectory)
                .findFirst();

        return externalOrProjectPath.or(this::resolveBundledTessdataPath);
    }

    private Optional<Path> resolveBundledTessdataPath() {
        if (!bundledTessdataEnabled) {
            return Optional.empty();
        }

        try {
            Path tempTessdataPath = Paths.get(System.getProperty("java.io.tmpdir"), "tcgen-tessdata")
                    .toAbsolutePath()
                    .normalize();
            Files.createDirectories(tempTessdataPath);

            boolean allCopied = true;
            for (String lang : languages()) {
                String fileName = lang + ".traineddata";
                ClassPathResource resource = new ClassPathResource("tessdata/" + fileName);
                if (!resource.exists()) {
                    allCopied = false;
                    break;
                }

                Path target = tempTessdataPath.resolve(fileName);
                boolean copyRequired = !Files.isRegularFile(target) || Files.size(target) != resource.contentLength();
                if (copyRequired) {
                    try (InputStream inputStream = resource.getInputStream()) {
                        Files.copy(inputStream, target, java.nio.file.StandardCopyOption.REPLACE_EXISTING);
                    }
                }
            }

            if (allCopied && allLanguageFilesExist(tempTessdataPath)) {
                return Optional.of(tempTessdataPath);
            }
        } catch (IOException ex) {
            return Optional.empty();
        }

        return Optional.empty();
    }

    private boolean bundledTessdataAvailable() {
        for (String lang : languages()) {
            if (!new ClassPathResource("tessdata/" + lang + ".traineddata").exists()) {
                return false;
            }
        }
        return true;
    }

    private Path normalizeTessdataPath(Path path) {
        if (path == null) {
            return null;
        }
        Path normalized = path.toAbsolutePath().normalize();
        if (isUsableTessdataDirectory(normalized)) {
            return normalized;
        }
        Path childTessdata = normalized.resolve("tessdata");
        if (isUsableTessdataDirectory(childTessdata)) {
            return childTessdata;
        }
        return normalized;
    }

    private boolean isUsableTessdataDirectory(Path path) {
        return path != null && Files.isDirectory(path) && Files.isReadable(path);
    }

    private void validateTrainedData(Path tessdataPath) {
        if (!allLanguageFilesExist(tessdataPath)) {
            throw new TcgenException("OCR language data is missing. " + String.join("; ", requiredTrainedDataFiles(tessdataPath))
                    + ". Install the Tesseract language data or set TCGEN_OCR_TESSDATA_PATH to the folder that contains eng.traineddata.");
        }
    }

    private boolean allLanguageFilesExist(Path tessdataPath) {
        if (tessdataPath == null) {
            return false;
        }
        for (String lang : languages()) {
            Path trainedData = tessdataPath.resolve(lang + ".traineddata");
            if (!Files.isRegularFile(trainedData) || !Files.isReadable(trainedData)) {
                return false;
            }
        }
        return true;
    }

    private List<String> requiredTrainedDataFiles(Path tessdataPath) {
        List<String> files = new ArrayList<>();
        for (String lang : languages()) {
            String file = lang + ".traineddata";
            files.add(tessdataPath == null ? file : tessdataPath.resolve(file).toString());
        }
        return files;
    }

    private List<String> languages() {
        String value = resolveLanguage();
        List<String> result = new ArrayList<>();
        for (String lang : value.split("\\+")) {
            String cleaned = lang.trim();
            if (StringUtils.hasText(cleaned)) {
                result.add(cleaned);
            }
        }
        if (result.isEmpty()) {
            result.add("eng");
        }
        return result;
    }

    private String resolveLanguage() {
        return StringUtils.hasText(language) ? language.trim() : "eng";
    }

    private BufferedImage upscaleIfRequired(BufferedImage image) {
        int width = image.getWidth();
        int height = image.getHeight();
        if (width >= minimumWidth && height >= minimumHeight) {
            return image;
        }

        double widthScale = minimumWidth <= 0 ? 1.0 : (double) minimumWidth / Math.max(width, 1);
        double heightScale = minimumHeight <= 0 ? 1.0 : (double) minimumHeight / Math.max(height, 1);
        double scale = Math.max(1.0, Math.max(widthScale, heightScale));
        scale = Math.min(scale, 3.0);

        int scaledWidth = Math.max(width, (int) Math.round(width * scale));
        int scaledHeight = Math.max(height, (int) Math.round(height * scale));

        BufferedImage scaled = new BufferedImage(scaledWidth, scaledHeight, BufferedImage.TYPE_BYTE_GRAY);
        Graphics2D graphics = scaled.createGraphics();
        graphics.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
        graphics.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
        graphics.drawImage(image, 0, 0, scaledWidth, scaledHeight, null);
        graphics.dispose();
        return scaled;
    }

    private String cleanup(String text) {
        return text == null ? "" : text.replaceAll("\\r", "")
                .replaceAll("[ \\t]+", " ")
                .replaceAll("\\n{3,}", "\\n\\n")
                .trim();
    }

    private String safeName(String sourceName) {
        return StringUtils.hasText(sourceName) ? sourceName : "uploaded image";
    }

    private void addIfPresent(List<String> list, String value) {
        if (StringUtils.hasText(value)) {
            list.add(value.trim());
        }
    }

    private String blankToEmpty(String value) {
        return StringUtils.hasText(value) ? value.trim() : "";
    }

    private String buildTessdataNotFoundMessage() {
        return "OCR setup issue: Tesseract tessdata folder was not found. The project now supports bundled English tessdata under src/main/resources/tessdata/eng.traineddata. If you removed it, restore that file or set TCGEN_OCR_TESSDATA_PATH to a tessdata folder. For non-image files, choose Document / Excel AC or disable OCR using tcgen.ocr.enabled=false.";
    }

    private String buildOcrFailureMessage(String sourceName, Path resolvedTessDataPath, Throwable ex) {
        return "OCR failed for " + sourceName + ". Resolved tessdata path: " + resolvedTessDataPath
                + ". Language: " + resolveLanguage()
                + ". Please verify that eng.traineddata exists in the tessdata folder. Original error: " + ex.getMessage();
    }

    private String buildStatusMessage(Optional<Path> path) {
        if (!ocrEnabled) {
            return "OCR is disabled.";
        }
        if (path.isEmpty()) {
            return buildTessdataNotFoundMessage();
        }
        if (!allLanguageFilesExist(path.get())) {
            return "Tessdata folder found, but required traineddata file is missing: " + String.join(", ", requiredTrainedDataFiles(path.get()));
        }
        return "OCR configuration looks valid. Resolved tessdata path: " + path.get();
    }
}
