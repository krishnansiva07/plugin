package com.llmart.llm.service;

import com.llmart.llm.dto.TestCaseGenerationResponse;
import com.llmart.llm.exception.TcgenException;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@Service
public class TestCaseGeneratorService {

    private final FileTextExtractor fileTextExtractor;
    private final PromptBuilder promptBuilder;
    private final JsonResponseParser jsonResponseParser;
    private final LlmClient llmClient;
    private final ColumnSelectionService columnSelectionService;
    private final ExcelExpectedColumnsService excelExpectedColumnsService;

    public TestCaseGeneratorService(FileTextExtractor fileTextExtractor,
                                    PromptBuilder promptBuilder,
                                    JsonResponseParser jsonResponseParser,
                                    LlmClient llmClient,
                                    ColumnSelectionService columnSelectionService,
                                    ExcelExpectedColumnsService excelExpectedColumnsService) {
        this.fileTextExtractor = fileTextExtractor;
        this.promptBuilder = promptBuilder;
        this.jsonResponseParser = jsonResponseParser;
        this.llmClient = llmClient;
        this.columnSelectionService = columnSelectionService;
        this.excelExpectedColumnsService = excelExpectedColumnsService;
    }

    public TestCaseGenerationResponse generate(MultipartFile file,
                                               String additionalPrompt,
                                               String apiKey,
                                               String modelName,
                                               String baseUrl,
                                               String selectedColumnsCsv,
                                               String fileUnderstandingMode,
                                               boolean useUploadedExcelColumns) {
        List<String> selectedColumns = resolveOutputColumns(file, selectedColumnsCsv, useUploadedExcelColumns);
        String acceptanceCriteriaText = fileTextExtractor.extract(file);
        String prompt = promptBuilder.buildPrompt(acceptanceCriteriaText, additionalPrompt, selectedColumns, fileUnderstandingMode);

        try {
            String llmResponse = llmClient.generate(prompt, apiKey, modelName, baseUrl);
            TestCaseGenerationResponse response = jsonResponseParser.parse(llmResponse, selectedColumns);
            response.setSourceFileName(file.getOriginalFilename());
            return response;
        } catch (TcgenException ex) {
            throw ex;
        } catch (Exception ex) {
            throw new TcgenException("Failed to generate test cases from LLM.", ex);
        }
    }

    private List<String> resolveOutputColumns(MultipartFile file, String selectedColumnsCsv, boolean useUploadedExcelColumns) {
        if (useUploadedExcelColumns) {
            List<String> excelColumns = excelExpectedColumnsService.detectExpectedColumns(file);
            if (!excelColumns.isEmpty()) {
                return excelColumns;
            }
        }

        if (StringUtils.hasText(selectedColumnsCsv)) {
            return columnSelectionService.resolveColumns(selectedColumnsCsv);
        }
        return columnSelectionService.defaultColumns();
    }
}
