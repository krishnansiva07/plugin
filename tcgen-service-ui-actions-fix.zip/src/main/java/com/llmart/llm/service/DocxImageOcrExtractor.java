package com.llmart.llm.service;

import com.llmart.llm.exception.TcgenException;
import org.apache.poi.xwpf.usermodel.XWPFPictureData;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.List;

@Service
public class DocxImageOcrExtractor {

    private final OcrService ocrService;

    @Value("${tcgen.ocr.docx-images.enabled:true}")
    private boolean docxImageOcrEnabled;

    @Value("${tcgen.ocr.docx-images.max-count:20}")
    private int maxImageCount;

    public DocxImageOcrExtractor(OcrService ocrService) {
        this.ocrService = ocrService;
    }

    public String extractTextFromEmbeddedImages(byte[] docxBytes, String sourceFileName) {
        if (!docxImageOcrEnabled || docxBytes == null || docxBytes.length == 0) {
            return "";
        }

        try (XWPFDocument document = new XWPFDocument(new ByteArrayInputStream(docxBytes))) {
            List<XWPFPictureData> pictures = document.getAllPictures();
            if (pictures == null || pictures.isEmpty()) {
                return "";
            }

            StringBuilder imageText = new StringBuilder();
            int imageNumber = 0;
            int processedCount = 0;

            for (XWPFPictureData picture : pictures) {
                imageNumber++;
                if (processedCount >= maxImageCount) {
                    imageText.append("\n[Skipped remaining DOCX images because tcgen.ocr.docx-images.max-count is ")
                            .append(maxImageCount)
                            .append("]\n");
                    break;
                }

                try {
                    String text = ocrService.extractTextFromImage(picture.getData(), sourceFileName + " image " + imageNumber);
                    if (!text.isBlank()) {
                        processedCount++;
                        imageText.append("\n\n--- OCR TEXT FROM IMAGE ")
                                .append(imageNumber)
                                .append(" INSIDE WORD DOCUMENT ---\n")
                                .append(text)
                                .append("\n");
                    }
                } catch (TcgenException ex) {
                    imageText.append("\n\n--- OCR WARNING FOR IMAGE ")
                            .append(imageNumber)
                            .append(" INSIDE WORD DOCUMENT ---\n")
                            .append(ex.getMessage())
                            .append("\n");
                }
            }
            return imageText.toString().trim();
        } catch (IOException ex) {
            return "";
        }
    }
}
