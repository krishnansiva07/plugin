package com.llmart.llm.service;

import com.llmart.llm.exception.TcgenException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

@Service
public class ColumnSelectionService {

    private static final List<String> DEFAULT_COLUMNS = List.of(
            "Test ID", "Module", "Requirement ID", "Scenario", "Precondition", "Test Steps",
            "Test Data", "Expected Result", "Priority", "Test Type", "Automation Candidate"
    );

    @Value("${tcgen.min-selected-columns:4}")
    private int minSelectedColumns;

    public List<String> resolveColumns(String selectedColumnsCsv) {
        if (!StringUtils.hasText(selectedColumnsCsv)) {
            return new ArrayList<>(DEFAULT_COLUMNS);
        }

        Set<String> columns = new LinkedHashSet<>();
        for (String column : selectedColumnsCsv.split("[,;\n]+")) {
            String trimmed = column == null ? "" : column.trim();
            if (!trimmed.isBlank() && !isSerialNumberColumn(trimmed)) {
                columns.add(trimmed);
            }
        }

        if (columns.size() < minSelectedColumns) {
            throw new TcgenException("Select at least " + minSelectedColumns + " output columns.");
        }
        return new ArrayList<>(columns);
    }

    public List<String> defaultColumns() {
        return new ArrayList<>(DEFAULT_COLUMNS);
    }

    private boolean isSerialNumberColumn(String value) {
        String normalized = value.replaceAll("[^A-Za-z0-9]", "").toLowerCase();
        return "sno".equals(normalized) || "serialno".equals(normalized) || "serialnumber".equals(normalized);
    }
}
