package com.llmart.llm.config;

import com.llmart.llm.exception.TcgenException;
import dev.langchain4j.model.chat.ChatLanguageModel;
import dev.langchain4j.model.openai.OpenAiChatModel;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.util.StringUtils;

@Configuration
public class ChatConfig {

    @Value("${llm.api-key:}")
    private String defaultApiKey;

    @Value("${llm.model-name:gpt-oss-120b}")
    private String defaultModelName;

    @Value("${llm.base-url:https://ai4devs.group.echonet/api/v1}")
    private String defaultBaseUrl;

    @Value("${llm.temperature:0.7}")
    private Double temperature;

    @Value("${llm.max-tokens:512}")
    private Integer maxTokens;

    public ChatLanguageModel chatLanguageModel(String requestApiKey,
                                               String requestModelName,
                                               String requestBaseUrl) {
        String apiKey = resolve(requestApiKey, defaultApiKey);
        String modelName = resolve(requestModelName, defaultModelName);
        String baseUrl = normalizeBaseUrl(resolve(requestBaseUrl, defaultBaseUrl));

        if (!StringUtils.hasText(apiKey)) {
            throw new TcgenException("API key is required. Enter user token in the UI or configure LLM_API_KEY.");
        }
        if (!StringUtils.hasText(modelName)) {
            throw new TcgenException("Model name is required. Enter model name in the UI or configure LLM_MODEL_NAME.");
        }
        if (!StringUtils.hasText(baseUrl)) {
            throw new TcgenException("Base URL is required. Enter base URL in the UI or configure LLM_BASE_URL.");
        }

        return OpenAiChatModel.builder()
                .apiKey(apiKey)
                .modelName(modelName)
                .baseUrl(baseUrl)
                .temperature(temperature)
                .maxTokens(maxTokens)
                .build();
    }

    private String resolve(String requestValue, String defaultValue) {
        return StringUtils.hasText(requestValue) ? requestValue.trim() : defaultValue == null ? "" : defaultValue.trim();
    }

    private String normalizeBaseUrl(String baseUrl) {
        if (!StringUtils.hasText(baseUrl)) {
            return "";
        }
        String cleaned = baseUrl.trim();
        while (cleaned.endsWith("/")) {
            cleaned = cleaned.substring(0, cleaned.length() - 1);
        }
        if (cleaned.endsWith("/chat/completions")) {
            cleaned = cleaned.substring(0, cleaned.length() - "/chat/completions".length());
        }
        return cleaned;
    }
}
