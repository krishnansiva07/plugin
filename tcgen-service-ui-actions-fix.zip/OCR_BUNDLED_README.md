# TCGen Bundled OCR Notes

This version bundles English Tesseract language data at:

```text
src/main/resources/tessdata/eng.traineddata
```

For normal English OCR, users do not need to install or configure `eng.traineddata` separately.

How it works:

1. TCGen first checks configured paths such as `TCGEN_OCR_TESSDATA_PATH`, `./tessdata`, `src/main/resources/tessdata`, and system Tesseract paths.
2. If none is found, TCGen extracts the bundled `eng.traineddata` from the application classpath into:

```text
<system-temp>/tcgen-tessdata
```

3. Tess4J uses that extracted folder for OCR.

Check OCR setup:

```text
http://localhost:8090/api/testcases/ocr/status
```

Expected successful values:

```json
{
  "enabled": true,
  "language": "eng",
  "tessdataFound": true,
  "trainedDataFound": true,
  "bundledTessdataAvailable": true
}
```

Note:

- Tess4J provides the Java wrapper and native OCR integration through Maven dependencies.
- On some Windows machines, Microsoft Visual C++ Redistributable may still be required for native DLL loading.
- For other languages, add the corresponding `<language>.traineddata` file under `src/main/resources/tessdata` and set `tcgen.ocr.language` accordingly.
