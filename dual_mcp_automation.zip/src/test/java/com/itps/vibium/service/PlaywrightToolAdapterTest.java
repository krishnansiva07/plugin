package com.itps.vibium.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.itps.vibium.model.McpTool;
import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

class PlaywrightToolAdapterTest {
    private final ObjectMapper mapper = new ObjectMapper();

    @Test
    void currentMcpUsesRealRefNotSelectorSyntax() throws Exception {
        McpTool click = new McpTool("browser_click", "", mapper.readTree("""
          {"type":"object","properties":{"element":{"type":"string"},"ref":{"type":"string"}},"required":["element","ref"]}
        """));
        PlaywrightToolAdapter adapter = new PlaywrightToolAdapter(List.of(click));
        Map<String,Object> args = adapter.click("BCEF", "e42", false);
        assertEquals("e42", args.get("ref"));
        assertFalse(args.containsKey("target"));
    }

    @Test
    void legacyTargetSchemaStillWorks() throws Exception {
        McpTool click = new McpTool("browser_click", "", mapper.readTree("""
          {"type":"object","properties":{"element":{"type":"string"},"target":{"type":"string"}},"required":["element","target"]}
        """));
        PlaywrightToolAdapter adapter = new PlaywrightToolAdapter(List.of(click));
        Map<String,Object> args = adapter.click("BCEF", "text=BCEF", false);
        assertEquals("text=BCEF", args.get("target"));
    }

    @Test
    void browserTypeUsesSingleFieldSchema() throws Exception {
        McpTool type = new McpTool("browser_type", "", mapper.readTree("""
          {"type":"object","properties":{"element":{"type":"string"},"ref":{"type":"string"},"text":{"type":"string"}},"required":["element","ref","text"]}
        """));
        PlaywrightToolAdapter adapter = new PlaywrightToolAdapter(List.of(type));
        Map<String,Object> args = adapter.type("Start date", "e9", "01/07/2026");
        assertEquals("01/07/2026", args.get("text"));
        assertFalse(args.containsKey("fields"));
    }

    @Test
    void mcpSchemaRequiringTargetAndRefGetsBoth() throws Exception {
        McpTool click = new McpTool("browser_click", "", mapper.readTree("""
          {"type":"object","properties":{"target":{"type":"string"},"ref":{"type":"string"}},"required":["target","ref"]}
        """));
        PlaywrightToolAdapter adapter = new PlaywrightToolAdapter(List.of(click));
        Map<String,Object> args = adapter.click("New search", "f2e20", false);
        assertEquals("New search", args.get("target"));
        assertEquals("f2e20", args.get("ref"));
    }

    @Test
    void screenshotSuppliesRequiredScaleFromLiveSchema() throws Exception {
        McpTool screenshot = new McpTool("browser_take_screenshot", "", mapper.readTree("""
          {"type":"object","properties":{"filename":{"type":"string"},"type":{"type":"string"},"scale":{"type":"string"}},"required":["scale"]}
        """));
        PlaywrightToolAdapter adapter = new PlaywrightToolAdapter(List.of(screenshot));
        Map<String,Object> args = adapter.screenshot("TC001-step-1.png");
        assertEquals("css", args.get("scale"));
        assertEquals("png", args.get("type"));
    }

    @Test
    void generatedVisibleTextIsNeverConvertedIntoSnapshotRef() throws Exception {
        McpTool click = new McpTool("browser_click", "", mapper.readTree("""
          {"type":"object","properties":{"target":{"type":"string"},"ref":{"type":"string"}},"required":["target","ref"]}
        """));
        PlaywrightToolAdapter adapter = new PlaywrightToolAdapter(List.of(click));
        IllegalArgumentException error = assertThrows(IllegalArgumentException.class,
                () -> adapter.normalizeGenerated("browser_click", Map.of("target", "BCEF", "ref", "ref='BCEF'")));
        assertTrue(error.getMessage().contains("requires argument 'ref'"));
    }

    @Test
    void nestedOneOfSchemaKeepsWaitTextArgument() throws Exception {
        McpTool wait = new McpTool("browser_wait_for", "", mapper.readTree("""
          {"type":"object","oneOf":[
            {"properties":{"time":{"type":"number"}},"required":["time"]},
            {"properties":{"text":{"type":"string"}},"required":["text"]},
            {"properties":{"textGone":{"type":"string"}},"required":["textGone"]}
          ]}
        """));
        PlaywrightToolAdapter adapter = new PlaywrightToolAdapter(List.of(wait));
        Map<String,Object> args = adapter.waitForText("New search");
        assertEquals("New search", args.get("text"));
    }

    @Test
    void nestedAllOfSchemaKeepsRunCodeArgument() throws Exception {
        McpTool runCode = new McpTool("browser_run_code", "", mapper.readTree("""
          {"type":"object","allOf":[
            {"properties":{"code":{"type":"string"}},"required":["code"]}
          ]}
        """));
        PlaywrightToolAdapter adapter = new PlaywrightToolAdapter(List.of(runCode));
        Map<String,Object> args = adapter.runCode("async (page) => page.url()");
        assertTrue(String.valueOf(args.get("code")).contains("page.url"));
    }
}
