#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
TEMP="$(mktemp -d)"
trap 'rm -rf "$TEMP"' EXIT
mkdir -p "$TEMP/com/llmart/llm/service"
cat > "$TEMP/com/llmart/llm/service/AgentPlanRelevance.java" <<'JAVA'
package com.llmart.llm.service;
final class AgentPlanRelevance {
 static boolean isReadOnlyAnalysisRequest(String text) { return false; }
}
JAVA
cat > "$TEMP/com/llmart/llm/service/ContinuationSmoke.java" <<'JAVA'
package com.llmart.llm.service;
public final class ContinuationSmoke {
 public static void main(String[] args) {
  String[] continuations = {"carry on", "keep going", "resume the task", "continue with the plan", "sounds good, proceed"};
  for (String input : continuations) {
   if (AgentConversationIntent.classify(input) != AgentConversationIntent.Kind.CONTINUE_PLAN)
    throw new AssertionError("Not a continuation: " + input);
  }
  String[] independent = {"fix the build", "explain the code", "create a test", "stop the agent"};
  for (String input : independent) {
   if (!AgentConversationIntent.looksLikeIndependentInstruction(input))
    throw new AssertionError("Not an independent instruction: " + input);
  }
  if (AgentConversationIntent.classify("Please create an implementation plan") != AgentConversationIntent.Kind.PLAN_PREVIEW)
   throw new AssertionError("Plan preview gate regressed");
  if (AgentConversationIntent.classify("implement it now") != AgentConversationIntent.Kind.DIRECT)
   throw new AssertionError("Explicit execution gate regressed");
  System.out.println("PASS: continuation, independent instruction, plan gate, execution gate");
 }
}
JAVA
javac -d "$TEMP/classes" "$TEMP/com/llmart/llm/service/AgentPlanRelevance.java" "$ROOT/src/main/java/com/llmart/llm/service/AgentConversationIntent.java" "$TEMP/com/llmart/llm/service/ContinuationSmoke.java"
java -cp "$TEMP/classes" com.llmart.llm.service.ContinuationSmoke
