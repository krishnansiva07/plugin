#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../.."
classes="$(mktemp -d)"
trap 'rm -rf "$classes"' EXIT
javac -d "$classes" \
  qa/prompt-deliverable/{AgentPlanRelevance,AgentResultPresentation,ProjectPatchRequest,ContractSmoke}.java \
  src/main/java/com/llmart/llm/service/{AgentConversationIntent,AgentCompletionContract,AgentAnalysisOutcome,AgentPromptDeliveryGate,ChatAnswerContinuation}.java
java -cp "$classes" com.llmart.llm.service.ContractSmoke
node --test qa/prompt-deliverable/prompt-deliverable.test.js
