# ELIYA43 – selected-workspace and plan-generation reliability update

Base input: ELIYA42.zip. This archive is the updated complete **Java 17 source package**; it does not include a built JAR.

## Addressed defects

1. **Agent executes against the wrong workspace after mapping a folder.** Agent ChatService now honors the already-selected project ID and only infers a project path from a prompt when NO UI project was selected. Explicit additional paths remain available through the existing resource-alias resolver. The browser no longer replaces a user-mapped workspace in response to stale/inconsistent SSE project metadata. In-workspace relative AND absolute command `cwd` values are supported, but paths outside the selected root and symlink traversal are rejected. The canonical selected root is immutable for the request.
2. **Plan generation intermittently aborts.** Top-level JSON plan arrays, JSON objects, fenced JSON, and prose-wrapped JSON are parsed correctly; requested task scope no longer inflates to a large-task workflow merely because 24k characters of repository evidence were found. The plan output budget now scales to the requested task profile (subject to the user's explicit `maxTokens` cap). Invalid/missing plans get up to three feedback-guided drafts. Optional hybrid-retrieval/impact-index outages no longer abort planning; the Agent may inspect live files during execution. The task-relevance, per-step evidence, final verification, and human plan-approval gates are retained: invalid plans are NOT executed.

## Files modified

- `src/main/java/com/llmart/llm/service/ChatService.java`
- `src/main/java/com/llmart/llm/service/AgentService.java`
- `src/main/java/com/llmart/llm/service/AgentWorkspaceService.java`
- `src/main/resources/static/app.js`
- `.github/workflows/verify-eliya.yml`

## Files added

- `src/main/java/com/llmart/llm/service/AgentWorkspaceSelection.java`
- `src/main/java/com/llmart/llm/service/WorkspaceCommandPaths.java`
- `src/main/java/com/llmart/llm/service/AgentPlanJsonEnvelope.java`
- `src/test/java/com/llmart/llm/service/WorkspacePlanningRegressionTest.java`
- `qa/workspace-planning/WorkspacePlanningSmoke.java`
- `qa/workspace-planning/run.sh`
- this release note

## Validation actually performed

PASS: `bash qa/workspace-planning/run.sh` (Java 17 target)

PASS: `bash qa/plan-relevance/run.sh`

PASS: `bash qa/offline-smoke/run.sh`

PASS: `bash qa/context-v35-smoke/run.sh`

PASS: `bash qa/context-v35-smoke/single-engine.sh`

PASS: `bash qa/context-v35-smoke/run-state.sh`

PASS: `bash qa/intelligence-smoke/run.sh` (including 3,000-file flow, caching, lexical/semantic fallback, and Java syntax scan)

PASS: `bash qa/completion-report-smoke/run.sh`

PASS: `bash qa/confluence-smoke/run.sh`

PASS: `bash qa/offline-smoke/vision.sh`

PASS: `bash qa/offline-smoke/chat-mcp-routing.sh`

PASS: `bash qa/offline-smoke/agent-image-routing.sh`

PASS: `node --check src/main/resources/static/*.js` (each JS file)

PASS: `node --test src/test/js/shared_folders_ui.test.js src/test/js/prompt_library.test.js src/test/js/deletion_approval_ui.test.js` (13 passing)

NOT RUN: Maven/Spring Boot dependency compilation, JUnit/Spring integration suite and executable JAR packaging. The execution environment has no installed Maven/dependency cache, and `repo.maven.apache.org` DNS is blocked, so Maven bootstrap could not run. No claim of a validated JAR or live provider end-to-end test is made.

## JAR build on a machine with Maven/network access

`./mvnw -Pfull-tests -Dmaven.test.skip=false clean verify`

Expected JAR after successful build: `target/eliya.jar`.

## Manual runtime acceptance checks

- Select a workspace in the UI. Ask Agent to analyze/fix something mentioning another existing path. The active project shown in the UI and the active agent workspace must remain the selected workspace.
- With commands enabled, run `pwd` (Linux) / `cd` (Windows) and a command using `cwd` set to an existing subfolder (relative or absolute). Both must run within the selected workspace. A `cwd` outside it must fail before starting a process.
- Submit a focused change in a large repository. The plan must remain focused (no unsolicited work-item ledger). Review and approve the plan before tools edit the workspace.
- Confirm existing Chat, Agent, MCP enable/explicit-trigger gate, reference paths, indexing, rollback, deletion approvals, and UI behavior against the pre-existing QA suites.

Notes: these protections govern built-in command `cwd` scoping. A user-approved arbitrary shell command containing `cd`, an external tool, or a separately authorized secondary writable resource can still operate elsewhere according to the OS permissions. A Java process is not an OS security sandbox.
