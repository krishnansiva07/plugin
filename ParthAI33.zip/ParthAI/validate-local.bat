@echo off
setlocal
cd /d "%~dp0"
echo [1/5] Java
java -version || exit /b 1
echo [2/5] Frontend syntax
where node >nul 2>nul
if %errorlevel%==0 (
  node --check src\main\resources\static\app.js || exit /b 1
  node --check src\main\resources\static\markdown.js || exit /b 1
) else (
  echo Node is not installed; skipping JavaScript syntax checks.
)
echo [3/5] Maven availability/bootstrap
call mvnw.cmd -version || exit /b 1
echo [4/5] Clean package
call mvnw.cmd clean package || exit /b 1
echo [5/5] Full test suite
if "%FAST_VALIDATION%"=="1" (
  echo FAST_VALIDATION=1: full tests explicitly skipped.
) else (
  call mvnw.cmd -Pfull-tests test || exit /b 1
)
echo Validation complete. JAR: target\parthai.jar
