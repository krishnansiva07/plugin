package com.llmart.llm.controller;

import com.llmart.llm.dto.FileDto;
import com.llmart.llm.entity.FileEntity;
import com.llmart.llm.service.FileService;
import org.springframework.core.io.Resource;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@RestController
@RequestMapping("/api/files")
public class FileController {
    private final FileService service;

    public FileController(FileService service) { this.service = service; }

    @PostMapping(consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public FileDto upload(@RequestParam String conversationId, @RequestPart("file") MultipartFile file) throws Exception {
        return service.save(conversationId, file);
    }

    @GetMapping
    public List<FileDto> list(@RequestParam String conversationId) {
        return service.listForConversation(conversationId);
    }

    @PostMapping("/{id}/reextract")
    public FileDto reextract(@PathVariable String id, @RequestParam String conversationId) {
        return service.reextract(conversationId, id);
    }


    @GetMapping("/{id}/text")
    public java.util.Map<String,Object> extractedText(@PathVariable String id,
                                                      @RequestParam(defaultValue = "0") int offset,
                                                      @RequestParam(defaultValue = "0") int maxChars) {
        FileEntity f = service.require(id);
        String text = f.getExtractedText() == null ? "" : f.getExtractedText();
        int start = Math.max(0, Math.min(offset, text.length()));
        int cap = maxChars <= 0 ? text.length() - start : Math.max(1, maxChars);
        int end = Math.min(text.length(), start + cap);
        java.util.Map<String,Object> out = new java.util.LinkedHashMap<>();
        out.put("id", f.getId());
        out.put("name", f.getOriginalName());
        out.put("mimeType", f.getMimeType());
        out.put("extractionStatus", f.getExtractionStatus() == null ? "unknown" : f.getExtractionStatus());
        out.put("extractionMessage", f.getExtractionMessage() == null ? "" : f.getExtractionMessage());
        out.put("extractedCharacters", text.length());
        out.put("offset", start);
        out.put("nextOffset", end < text.length() ? end : -1);
        out.put("text", text.substring(start, end));
        return out;
    }

    @GetMapping("/{id}/view")
    public ResponseEntity<Resource> view(@PathVariable String id) {
        FileEntity f = service.require(id);
        Resource resource = service.resource(id);
        MediaType type;
        try { type = MediaType.parseMediaType(f.getMimeType()); }
        catch (Exception e) { type = MediaType.APPLICATION_OCTET_STREAM; }
        return ResponseEntity.ok()
                .contentType(type)
                .header(HttpHeaders.CONTENT_DISPOSITION, "inline; filename=\"" + f.getOriginalName().replace("\"", "_") + "\"")
                .body(resource);
    }

    @GetMapping("/{id}/download")
    public ResponseEntity<Resource> download(@PathVariable String id) {
        FileEntity f = service.require(id);
        Resource resource = service.resource(id);
        MediaType type;
        try { type = MediaType.parseMediaType(f.getMimeType()); }
        catch (Exception e) { type = MediaType.APPLICATION_OCTET_STREAM; }
        return ResponseEntity.ok()
                .contentType(type)
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + f.getOriginalName().replace("\"", "_") + "\"")
                .body(resource);
    }
}
