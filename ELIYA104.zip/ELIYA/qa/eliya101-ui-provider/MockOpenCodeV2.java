import com.sun.net.httpserver.HttpServer;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.Executors;

/** External fake executable, intentionally mimics ONLY the contract used by ELIYA, not a real provider. */
public class MockOpenCodeV2 {
    private static void send(com.sun.net.httpserver.HttpExchange x, int status, String body) throws java.io.IOException {
        byte[] data = body.getBytes(StandardCharsets.UTF_8);
        x.getResponseHeaders().set("Content-Type","application/json");
        x.sendResponseHeaders(status,data.length);
        try(var out=x.getResponseBody()){out.write(data);}
    }
    public static void main(String[] args) throws Exception {
        int port=-1;
        for(int i=0;i<args.length-1;i++) if("--port".equals(args[i])) port=Integer.parseInt(args[i+1]);
        if(port<0) throw new IllegalArgumentException("Missing --port");
        String json=Files.readString(Path.of(System.getenv("OPENCODE_CONFIG")));
        String key=System.getenv("ELIYA_OPENCODE_MODEL_API_KEY");
        String selectedModel = json.contains("qwen3.8-27b") ? "qwen3.8-27b" :
                json.contains("agent-model-v1") ? "agent-model-v1" : "force-mismatch";
        boolean configured = key!=null && key.equals("top-secret-do-not-log") &&
                !json.contains(key) && json.contains("eliya-ui/"+selectedModel) &&
                json.contains("@opencode/ai/providers/openai-compatible") &&
                json.contains("https://company.example/v1") &&
                json.contains("{env:ELIYA_OPENCODE_MODEL_API_KEY}");
        boolean wrongDefault=json.contains("force-mismatch");
        var selected=new java.util.concurrent.atomic.AtomicBoolean();
        HttpServer server=HttpServer.create(new InetSocketAddress("127.0.0.1",port),0);
        server.createContext("/api/",x->{
            try {
                String path=x.getRequestURI().getPath();
                String body=new String(x.getRequestBody().readAllBytes(),StandardCharsets.UTF_8);
                if(path.equals("/api/info")) send(x,200,"{\"data\":{\"version\":\"2.2.2\"}}");
                else if(path.equals("/api/model/default")) send(x,200,
                        configured && !wrongDefault ? "{\"data\":{\"providerID\":\"eliya-ui\",\"modelID\":\"" + selectedModel + "\"}}" :
                                "{\"data\":{\"providerID\":\"opencode\",\"modelID\":\"flint-40b-free\"}}");
                else if(path.equals("/api/session") && x.getRequestMethod().equals("POST"))
                    send(x,200,"{\"data\":{\"id\":\"ses_mock\",\"agent\":\"build\"}}");
                else if(path.equals("/api/session/ses_mock/model")){
                    boolean valid=body.contains("\"providerID\":\"eliya-ui\"") &&
                            body.contains("\"model\":\""+selectedModel+"\"");
                    selected.set(valid);
                    send(x,valid?200:400,valid?"{}":"{\"error\":{\"message\":\"Wrong model selection\"}}");
                } else if(path.equals("/api/session/ses_mock/prompt")) {
                    send(x,selected.get()?200:400, selected.get()?"{\"data\":{\"id\":\"usr_mock\"}}":"{}");
                } else if(path.equals("/api/session/active")) send(x,200,"{\"data\":{\"ses_mock\":{\"status\":\"busy\"}}}");
                else if(path.equals("/api/session/ses_mock/interrupt")) send(x,200,"{\"data\":{\"interrupted\":true}}");
                else if(path.equals("/api/session/ses_mock")) send(x,200,"{\"data\":{\"outcome\":null}}");
                else send(x,404,"{}");
            }catch(Exception e){try{send(x,500,"{}");}catch(Exception ignored){}}
        });
        server.setExecutor(Executors.newCachedThreadPool());
        server.start();
        System.out.println("ELIYA OpenCode mock server started");
    }
}
