# ELIYA40 — Task-Aligned Agent Planning Fix

Base: user-supplied ELIYA39 source archive. Scope: Agent planning only, with focused offline regression coverage.

## Root cause corrected

The Agent previously interpreted large numbers in Jira issue keys such as `BMSA-7895` as the scale of a large code/migration task. Failed/invalid planner output could also be replaced silently by a hard-coded five-step migration ledger plan. Structural checks did not establish task relevance.

## Changes

1. Extract task scale from explicit quantities (`1200 files`, `50 tests`) instead of arbitrary two- to five-digit numbers in Jira keys/dates.
2. Route Jira-to-BRD/Word/Markdown requests to an external-document profile: ticket evidence, comments, attachments, screenshots, requirement consolidation, exact requested output formats, artifact validation. No code compilation, repository inventory, work ledger or forced documentation template.
3. Route clear read-only analysis requests (e.g., UI/API/data flow tracing, Jira comparison) to evidence and traceability verification rather than code mutation or compilation. Tasks requesting fixes or tests still use the existing coding/execution path.
4. Add a lightweight deterministic plan relevance gate, checking explicitly named MCP sources, requested artifacts/evidence, and rejection of unrelated migration/documentation inventory steps. The existing model validation for broad tasks remains; its second attempt is now independently validated too.
5. Permit one model corrective retry after relevance/structure failures. Reject planning safely before approval and filesystem mutations if no task-relevant plan can be generated; never silently swap in generic code-migration fallback steps.
6. Preserve document template opt-in, MCP opt-in/gating, Agent step approval, protected rollback, large-task ledger for genuine migrations, Java 17 compatibility, and Chat indexing/retrieval pipelines.

## Offline verification carried out

- PASS: new `qa/plan-relevance/run.sh` (Jira keys, appropriate plan, reject screenshot's five-step plan, missing attachments/screenshots, both output formats, large migration quantity, analysis-only scope, explicit MCP source, full repo documentation requirements).
- PASS: `qa/intelligence-smoke/run.sh` (1,099/3,000-file indexing, UI-API flow, 1,200-file fast Chat, syntax parse of all 93 production Java sources, tool contracts).
- PASS: `qa/offline-smoke/run.sh` (deletion approvals, rollback, snapshots).
- PASS: `qa/offline-smoke/chat-mcp-routing.sh` (MCP opt-in and explicit-prompt routing).
- PASS: `qa/offline-smoke/jira-jql.sh`, `qa/offline-smoke/agent-image-routing.sh`, `qa/offline-smoke/vision.sh`.
- PASS: `qa/context-v35-smoke/single-engine.sh`, `qa/context-v35-smoke/run.sh`, `qa/context-v35-smoke/run-state.sh`.
- PASS: static UI contract and JavaScript syntax; 13 Node UI tests.

## Build limits and required final checks

A full `./mvnw -Pfull-tests clean verify` / executable JAR could **not** be produced in the isolated environment: Maven is not preinstalled, and DNS to repo.maven.apache.org failed while the Maven wrapper attempted its bootstrap. A full integration test against a running Jira MCP server and configured LLM is likewise not possible here. The archive therefore contains source code, not a build-verified JAR.

For the final build in a connected Java 17 environment:

```bash
bash qa/plan-relevance/run.sh
./mvnw -Pfull-tests -Dmaven.test.skip=false clean verify
```

The GitHub Actions `verify-eliya.yml` workflow now runs the new plan-relevance regression script before the full Maven build and only uploads a JAR on success.
