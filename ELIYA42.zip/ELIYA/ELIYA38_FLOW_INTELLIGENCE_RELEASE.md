# ELIYA38 — Flow-aware retrieval and Agent planning update

## Scope

This is a **source distribution**, based on the ELIYA38(1).zip baseline. It is not an executable JAR: this environment does not have Maven or a dependency cache and could not reach Maven Central. No end-to-end model/provider run or full Spring Boot packaging has been performed in this environment.

## Implemented

1. **Cross-layer HTTP hints:** a bounded local parser matches frontend `fetch`, `axios`, common TypeScript clients including Angular-style `http.get<T>`, and annotated Spring Boot HTTP routes where both method and literal URL match uniquely. Supports controller-level `@RequestMapping` prefixes, GET/POST/PUT/PATCH/DELETE, and source line pointers. Rejects dynamic/nonliteral routes and conflicting controller matches; ignores JavaScript/Java comments. It is deliberately **not** a full semantic call graph.
2. **Indexed dependency propagation:** HTTP edges are included in existing import/Cucumber dependency neighborhoods. Flow-related questions get two *bounded* hops, whereas ordinary queries keep the original first-hop path; no extra model call is introduced.
3. **Fast Chat routing:** functional questions such as “explain how the Alert KPI is calculated from UI to API” activate the selected workspace index even when the user omits words such as “codebase” or “method.” General greetings retain the fast path. Cached-first behavior and the bounded 650 ms optional semantic wait are unchanged.
4. **Agent plan primer:** where the index is ready, the same source-linked HTTP matches can be provided *before* the Agent creates its plan. The approved-plan gate, file protection, checkpoints, rollback and final validation policy remain unchanged.
5. **Warm index graph:** on index refresh, workspaces of at most 5,000 files precompute their structural/HTTP graph alongside existing background indexing. Chat never performs an added directory scan for these lookups. Larger workspaces keep lazy graph construction. Changed-file refresh invalidates the graph and the next request rebuilds it from the updated cached source.
6. **Continuous check:** adds a self-contained 3,000-file flow smoke to the existing `qa/intelligence-smoke/run.sh` script and the GitHub Actions verification job.

## Evidence and limitations

- Every displayed HTTP link is a candidate from indexed source text and includes the caller/controller path and indexed line number. Edges should be rechecked against *current live source* before edits. Mappings inside dynamically generated URLs, gateway rewrites, interceptors, feature flags, runtime logs, GraphQL, and non-Spring backend routers are not yet traced automatically.
- Import edges and two-hop neighborhoods are **inferred dependencies**, not proof that an endpoint invokes a particular service or database query. Final business logic / KPI calculations require live file reading and tests.
- HTTP hints can be incomplete when the relevant route is beyond the cached excerpt of a very large file. An absent edge is **not** proof that a flow does not exist.
- Only the **selected user workspace** and already-prepared local index are analyzed. This update does not make MCP calls. The baseline strict *explicit MCP prompt token + enabled flag* gating remains unchanged.
- Documentation templates still activate **only when explicitly selected in the UI**. Chat remains analysis-oriented; users manually review/copy their implementation prompts into Agent. Nothing is automatically edited in Chat.
- Faster task completion is a hypothesis requiring controlled baseline/updated Agent benchmarks. The smoke timing below measures only local indexing/retrieval, **not** LLM latency, tool execution or end-to-end task completion.

## Local validation performed

- `bash qa/intelligence-smoke/run.sh`: PASS (1,099-file existing intelligence smoke, 3,000-file flow and ambiguity test, 1,200-file cached retrieval/fallback/cancellation smoke, 92 Java sources syntax-parsed, tool contracts).
- `bash qa/context-v35-smoke/single-engine.sh`, `run.sh`, `run-state.sh`: PASS.
- `bash qa/offline-smoke/run.sh`, `vision.sh`, `chat-mcp-routing.sh`, `agent-image-routing.sh`: PASS.
- `python3 qa/offline-smoke/ui-contract.py`: 11 PASS.
- `node --check` for the 3 main JS assets: PASS.
- `node --test src/test/js/shared_folders_ui.test.js src/test/js/prompt_library.test.js src/test/js/deletion_approval_ui.test.js`: 13 PASS.
- Synthetic 3,000-file example in this environment: index build **427 ms**, first cached flow query **58 ms**. This small-file test is not representative of arbitrary enterprise repositories, and the timing varies by hardware.
- Maven JAR packaging: **NOT VERIFIED**. `./mvnw -q -DskipTests package` could not bootstrap Maven because DNS resolution for `repo.maven.apache.org` was unavailable. Do not distribute this source zip as if it contained a built runnable JAR.

## Build in an environment with Maven/dependencies

Use **Java 17** and Maven access:

```bash
cd ELIYA
bash qa/intelligence-smoke/run.sh
./mvnw -B -Pfull-tests -Dmaven.test.skip=false clean verify
```

If the build succeeds, the configured output is `target/eliya.jar` (Spring Boot executable). The GitHub Actions `Verify and package ELIYA` workflow now runs the new flow test before full Maven `verify` and uploads the JAR on success.

## Next work for true end-to-end flow accuracy

- Add framework-specific routers for the application's actual frontend/back-end stacks.
- Follow controller-to-service-to-repository calls with AST-backed resolution, evidence provenance and confidence levels.
- Run representative real-world tasks on baseline ELIYA38 versus this update, comparing total completion duration, model/tool calls, tokens, reruns and correctness; retain only measured improvements.
