package com.llmart.llm.service;

import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Cheap, deterministic task-contract guard. This does not replace the model's semantic review;
 * it prevents a code/migration fallback from being approved for evidence/document tasks.
 * No network, MCP calls or workspace mutations are made here.
 */
final class AgentPlanRelevance {
    private static final Pattern ISSUE_KEY = Pattern.compile("(?i)\\b[A-Z][A-Z0-9]{1,15}-\\d+\\b");
    private static final Pattern SIZED_WORK = Pattern.compile(
            "(?i)\\b(\\d{1,3}(?:,\\d{3})+|\\d{2,6})\\s*(?:(?:source|selenium|playwright|java|testng)\\s+)?(?:files?|tests?|testcases?|cases?|scenarios?|modules?|features?|classes?|components?|records?|items?|tickets?|stories?|endpoints?|pages?)\\b");

    private AgentPlanRelevance() { }

    static boolean isExternalDocumentRequest(String task) {
        String low = lower(task);
        boolean creating = containsAny(low, "create", "generate", "prepare", "produce", "write", "draft", "consolidate", "compile", "build", "export");
        // A reference to AGENTS.md / SKILLS.md / MIGRATION.md is an INPUT, not an output contract.
        // In particular, "create the migration plan" + "read AGENTS.md" must remain a migration task.
        // An explicitly scoped feature migration also stays code work if its completion includes a report.
        if (isSingleFeatureMigrationRequest(task)) return false;
        boolean artifact = containsAny(low, "brd", "business requirements document", "requirements document", "word document",
                "word file", "docx", "markdown file", "markdown document", "functional specification", "requirements specification");
        return creating && (artifact || isMarkdownOutputRequest(task));
    }

    /** A Markdown reference/instruction file is not automatically an output artifact. */
    static boolean isMarkdownOutputRequest(String task) {
        String low = lower(task);
        boolean namedOutput = Pattern.compile(
                "(?i)\\b(?:create|generate|write|produce|save|export|deliver)\\s+(?:(?:an?|the|new|updated|final)\\s+){0,3}[a-z0-9_.-]+\\.md\\b")
                .matcher(low).find()
                || Pattern.compile("(?i)\\b(?:as|named|called)\\s+[a-z0-9_.-]+\\.md\\b").matcher(low).find();
        return namedOutput || containsAny(low, "markdown file", "markdown document", "markdown (.md)",
                "markdown output", "output as markdown", "output in markdown", "in markdown format",
                "and markdown", "plus markdown", "as markdown", "save as .md", "output as .md",
                "output in .md", "generate .md", "create .md");
    }

    /** Detailed instructions for a named feature are not evidence of a large, whole-repository migration. */
    static boolean isSingleFeatureMigrationRequest(String task) {
        String low = lower(task);
        boolean migration = Pattern.compile("\\b(?:migrate|migration|migrating|port|conversion)\\b").matcher(low).find();
        boolean namedFeature = Pattern.compile("\\b[a-z0-9_.-]+\\.feature\\b").matcher(low).find();
        boolean scoped = containsAny(low, "this feature", "following feature", "selected module", "this module", "single module", "one module");
        boolean globalScope = containsAny(low, "entire project", "whole project", "all modules", "all features", "every module",
                "full migration", "large migration", "multiple modules", "across modules", "across the project",
                "entire repository", "whole repository");
        // "All tests for this feature" is local coverage; "all tests" without that qualification is broad.
        boolean localizedTests = Pattern.compile(
                "(?i)\\ball\\s+(?:relevant\\s+)?(?:tests|test\\s+cases|cases)\\s+(?:for|of|in|within)\\s+(?:(?:this|the|selected|specified|following|one)\\s+)?(?:feature|module)\\b")
                .matcher(low).find();
        boolean broadTests = containsAny(low, "all tests", "all cases") && !localizedTests;
        return migration && namedFeature && scoped && !globalScope && !broadTests;
    }

    /** Query/explanation jobs are read-only unless the user also requests an edit or execution. */
    static boolean isReadOnlyAnalysisRequest(String task) {
        String low = lower(task);
        boolean analysis = Pattern.compile("(?i)\\b(?:analy[sz]e|analysis|explain|review|compare|investigate|inspect|trace|understand|summari[sz]e|assess|evaluate|identify|find|check|describe)\\b").matcher(low).find()
                || low.startsWith("how does ") || low.startsWith("how is ") || low.startsWith("how are ")
                || low.startsWith("what is ") || low.startsWith("what are ");
        boolean mutation = Pattern.compile("(?i)\\b(?:implement|fix|modify|change|update|edit|delete|remove|add|create|generate|produce|prepare|build|compile|migrate|refactor|develop|automate|execute|run|write|repair|patch)\\b").matcher(low).find();
        return analysis && !mutation;
    }

    /** Numbers inside issue keys, dates and file paths cannot be interpreted as batch sizes. */
    static int explicitWorkItemCount(String task) {
        if (task == null || task.isBlank()) return 0;
        String stripped = ISSUE_KEY.matcher(task).replaceAll(" ");
        Matcher match = SIZED_WORK.matcher(stripped);
        int max = 0;
        while (match.find()) {
            try { max = Math.max(max, Integer.parseInt(match.group(1).replace(",", ""))); }
            catch (NumberFormatException ignored) { }
        }
        return max;
    }

    /** Empty result means no deterministic task-contract mismatch was detected. */
    static String validate(String task, String profile, List<String> steps) {
        if (steps == null || steps.isEmpty()) return "Plan has no actionable steps.";
        String low = lower(task);
        String plan = lower(String.join("\n", steps));
        // A short inspection or a normal code fix must not acquire large-migration ledger steps.
        if (!"large".equals(profile) && !"documentation".equals(profile)
                && !containsAny(low, "work-item ledger", "work item ledger")
                && containsAny(plan, "work-item ledger", "work item ledger", "work_items_discover", "work_items_init")) {
            return "An unrelated large-migration work-item ledger was inserted into a task that does not request it.";
        }
        // Explicit MCP evidence sources must remain visible in the plan for every task category.
        for (String source : List.of("jira", "confluence", "gitlab", "sonarqube", "playwright")) {
            if (low.contains(source + " mcp") && !plan.contains(source)) {
                return "The requested " + source + " MCP source/tool is missing from the plan.";
            }
        }
        if ("analysis".equals(profile)) {
            if (containsAny(plan, "implement the change", "implement requested", "modify source", "edit files", "create feature",
                    "compile project", "project compilation", "full regression", "migrate the", "work-item ledger")) {
                return "This is read-only analysis: inspect the requested evidence and verify the findings, without editing or compiling.";
            }
            String last = lower(steps.get(steps.size() - 1));
            if (!containsAny(last, "verif", "validat", "review", "check", "trace", "cross-check")) {
                return "Finish a read-only analysis with evidence/traceability validation, not a project build.";
            }
        }
        if ("external_document".equals(profile)) {
            if (containsAny(plan, "work-item ledger", "work item ledger", "work_items_", "batch regression",
                    "compile/type/static", "project compilation", "full regression suite", "source-code inventory",
                    "documentation_inventory", "documentation_record_module", "documentation_validate")) {
                return "The task requests a document, not a source-code migration or durable work-item ledger. Remove coding/batching/compilation steps.";
            }
            if ((low.contains("jira") || ISSUE_KEY.matcher(task == null ? "" : task).find()) && !plan.contains("jira")) {
                return "Explicitly retrieve the requested Jira tickets as the source evidence; do not inventory source code instead.";
            }
            if (low.contains("mcp") && !plan.contains("mcp")) {
                return "Preserve the user-requested MCP retrieval route; do not silently use unrelated workspace searches.";
            }
            if (containsAny(low, "comment", "comments") && !containsAny(plan, "comment", "discussion")) {
                return "Cover Jira comments/discussions as requested source evidence.";
            }
            if (containsAny(low, "attachment", "attachments") && !containsAny(plan, "attachment", "attached file")) {
                return "Explicitly collect and inspect the requested attachments.";
            }
            if (containsAny(low, "screenshot", "screenshots", "images", "image") && !containsAny(plan, "screenshot", "image", "visual", "diagram")) {
                return "Explicitly analyze the requested screenshot/image evidence, including unreadable items.";
            }
            if (containsAny(low, "consolidat", "merge", "unified") && !containsAny(plan, "consolidat", "merge", "unif", "synthesi", "deduplicat")) {
                return "Combine the requested source requirements into one cohesive output; merely retrieving tickets is insufficient.";
            }
            if (containsAny(low, "docx", "word document", "word file") && !containsAny(plan, "docx", "word document", ".docx")) {
                return "Include the user's Word (.docx) output deliverable.";
            }
            if (isMarkdownOutputRequest(task) && !containsAny(plan, "markdown", ".md")) {
                return "Include the user's Markdown (.md) output deliverable.";
            }
            String finalStep = lower(steps.get(steps.size() - 1));
            if (!containsAny(finalStep, "verif", "validat", "review", "check", "quality")) {
                return "The last step must check the requested outputs and their source-evidence coverage; compilation is not the correct document verifier.";
            }
        } else if ("documentation".equals(profile)) {
            if (!plan.contains("documentation_inventory") || !plan.contains("documentation_validate")) {
                return "Broad repository documentation requires documentation_inventory and final documentation_validate, without changing the user's document structure.";
            }
        }
        return "";
    }

    private static boolean containsAny(String haystack, String... needles) {
        for (String needle : needles) if (haystack.contains(needle)) return true;
        return false;
    }

    private static String lower(String text) {
        return text == null ? "" : text.toLowerCase(Locale.ROOT);
    }
}
