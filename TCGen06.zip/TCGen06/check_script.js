
    window.addEventListener('error', function(event) {
        const error = document.getElementById('error');
        if (error) error.innerText = 'UI JavaScript error: ' + event.message;
    });

    const providerConfigs = {
        AI4DEV: {
            label: 'AI4Dev',
            baseUrl: 'https://ai4devs.group.echonet/api/v1',
            defaultModel: 'gpt-oss-120b',
            models: [
                { id: 'gpt-oss-120b', label: 'gpt-oss-120b' }
            ],
            help: 'AI4Dev default model. You can type another model supported by your gateway.'
        },
        LLM_CIB: {
            label: 'LLM@CIB',
            baseUrl: 'https://api.llm.cib.echonet/v1/openai',
            defaultModel: 'gpt-oss-120b-ITG',
            models: [
                { id: 'gpt-oss-120b-ITG', label: 'gpt-oss-120b-ITG (131K context)' },
                { id: 'mistral-small-2506-ITG', label: 'mistral-small-2506-ITG (128K context)' },
                { id: 'mistral-medium-2508-ITG', label: 'mistral-medium-2508-ITG (128K context)' },
                { id: 'mistral-small-4-ITG', label: 'mistral-small-4-ITG (262K context)' },
                { id: 'mistral-ocr-2512-ITG', label: 'mistral-ocr-2512-ITG' },
                { id: 'mistral-ocr-4-ITG', label: 'mistral-ocr-4-ITG' },
                { id: 'gemma-4-31b-ITG', label: 'gemma-4-31b-ITG (256K context)' },
                { id: 'qwen3.6-35b-a3b', label: 'qwen3.6-35b-a3b (256K context)' },
                { id: 'qwen3.8-27b', label: 'qwen3.8-27b (262K context)' },
                { id: 'qwen-latest', label: 'qwen-latest (262K context)' },
                { id: 'qwen3.6-27b', label: 'qwen3.6-27b (262K context)' }
            ],
            help: 'Supported LLM@CIB chat/agent models. You can also type a newly supported model name.'
        }
    };

    const templates = {
        manual: ['Test ID', 'Module', 'Requirement ID', 'Scenario', 'Precondition', 'Test Steps', 'Test Data', 'Expected Result', 'Priority', 'Test Type', 'Automation Candidate'],
        api: ['Test ID', 'Module', 'Requirement ID', 'API Method', 'API Endpoint', 'Request Payload', 'Test Data', 'Expected Result', 'Status Code', 'DB Validation', 'Priority', 'Test Type', 'Automation Candidate'],
        bdd: ['Feature', 'Scenario', 'Given', 'When', 'Then', 'Examples', 'Tags', 'Priority', 'Automation Candidate'],
        regression: ['Test ID', 'Module', 'Scenario', 'Regression Scope', 'Impact Area', 'Test Steps', 'Expected Result', 'Priority', 'Test Type', 'Automation Candidate', 'Remarks']
    };

    const allColumns = [
        'Test ID', 'Module', 'Requirement ID', 'AC Mapping', 'Scenario', 'Precondition', 'Test Steps', 'Test Data',
        'Expected Result', 'Priority', 'Test Type', 'Automation Candidate', 'API Method', 'API Endpoint', 'Request Payload',
        'Status Code', 'DB Validation', 'UI Validation', 'Security Validation', 'Feature', 'Given', 'When', 'Then',
        'Examples', 'Tags', 'Regression Scope', 'Impact Area', 'Negative Scenario Reason', 'Remarks'
    ];

    let customColumns = [];
    let lastResponse = null;

    document.addEventListener('DOMContentLoaded', () => {
        renderColumnList();
        applyTemplate('manual');
        changeProvider('AI4DEV');
        document.getElementById('file').addEventListener('change', () => updateFileName('file', 'fileName', 'No file selected'));
        document.getElementById('columnsFile').addEventListener('change', () => {
            updateFileName('columnsFile', 'columnsFileName', 'No column Excel selected');
            if (document.getElementById('useExcelColumns').checked) loadExcelColumns();
        });
        document.getElementById('useExcelColumns').addEventListener('change', renderPromptPreview);
        document.getElementById('prompt').addEventListener('input', renderPromptPreview);
        document.getElementById('fileUnderstandingMode').addEventListener('change', renderPromptPreview);
        document.getElementById('modelName').addEventListener('input', updateConnectionSummary);
        document.getElementById('baseUrl').addEventListener('input', updateConnectionSummary);
        const params = new URLSearchParams(window.location.search);
        if (params.get('preview') === '1') setTimeout(renderSampleResult, 100);
    });

    function currentProvider() {
        return document.querySelector('input[name="provider"]:checked')?.value || 'AI4DEV';
    }

    function changeProvider(provider) {
        const config = providerConfigs[provider] || providerConfigs.AI4DEV;
        const radio = document.querySelector(`input[name="provider"][value="${provider}"]`);
        if (radio) radio.checked = true;
        document.getElementById('providerBadge').innerText = config.label;
        document.getElementById('baseUrl').value = config.baseUrl;
        document.getElementById('modelName').value = config.defaultModel;
        document.getElementById('modelHelp').innerText = config.help;
        const endpointHelp = document.getElementById('endpointHelp');
        if (endpointHelp) {
            endpointHelp.innerText = provider === 'LLM_CIB'
                ? 'Use the LLM@CIB base URL. TCGen automatically calls /chat/completions, matching the working Chat implementation in the reference project.'
                : 'Use the AI4Dev base URL. TCGen automatically calls /chat/completions using the same chat-client flow.';
        }
        const datalist = document.getElementById('modelOptions');
        datalist.innerHTML = config.models.map(model => `<option value="${escapeAttr(model.id)}">${escapeHtml(model.label)}</option>`).join('');
        updateConnectionSummary();
    }

    function updateConnectionSummary() {
        const config = providerConfigs[currentProvider()] || providerConfigs.AI4DEV;
        const model = document.getElementById('modelName')?.value?.trim() || config.defaultModel;
        const baseUrl = document.getElementById('baseUrl')?.value?.trim() || config.baseUrl;
        document.getElementById('connectionSummary').innerText = `${config.label} · ${baseUrl} · ${model}`;
    }

    function renderColumnList() {
        const container = document.getElementById('columnList');
        container.innerHTML = '';
        [...allColumns, ...customColumns].forEach(column => {
            const id = 'col_' + normalizeId(column);
            const label = document.createElement('label');
            label.className = 'check';
            label.innerHTML = `<input class="col-check" id="${id}" type="checkbox" value="${escapeAttr(column)}" onchange="renderPromptPreview()"> <span>${escapeHtml(column)}</span>`;
            container.appendChild(label);
        });
    }

    function applyTemplate(name) {
        document.querySelectorAll('.template-btn').forEach(btn => btn.classList.remove('active'));
        const buttonId = 'tpl' + name.charAt(0).toUpperCase() + name.slice(1);
        const button = document.getElementById(buttonId);
        if (button) button.classList.add('active');
        const selected = new Set(templates[name] || templates.manual);
        ensureColumnsExist([...selected]);
        document.querySelectorAll('.col-check').forEach(input => input.checked = selected.has(input.value));
        renderPromptPreview();
    }

    function ensureColumnsExist(columns) {
        let changed = false;
        columns.forEach(column => {
            if (!allColumns.includes(column) && !customColumns.includes(column)) {
                customColumns.push(column);
                changed = true;
            }
        });
        if (changed) renderColumnList();
    }

    function selectAllColumns() {
        document.querySelectorAll('.col-check').forEach(input => input.checked = true);
        renderPromptPreview();
    }

    function clearOptionalColumns() {
        const minimum = new Set(['Test ID', 'Scenario', 'Test Steps', 'Expected Result', 'Priority']);
        document.querySelectorAll('.col-check').forEach(input => input.checked = minimum.has(input.value));
        renderPromptPreview();
    }

    function addCustomColumn() {
        const input = document.getElementById('customColumn');
        const values = parseColumnInput(input.value);
        if (values.length === 0) return;
        const selected = new Set(getSelectedColumns());
        values.forEach(value => {
            if (!allColumns.includes(value) && !customColumns.includes(value)) customColumns.push(value);
            selected.add(value);
        });
        renderColumnList();
        selected.forEach(column => {
            const checkbox = document.getElementById('col_' + normalizeId(column));
            if (checkbox) checkbox.checked = true;
        });
        input.value = '';
        setExcelStatus(`${values.length} custom column(s) added: ${values.join(', ')}`, 'good');
        renderPromptPreview();
    }

    function parseColumnInput(value) {
        if (!value) return [];
        const seen = new Set();
        return value.split(/[,;\n]+/).map(v => v.trim()).filter(v => v.length > 0).filter(v => !isSerialColumn(v)).filter(v => {
            const key = normalizeId(v).toLowerCase();
            if (seen.has(key)) return false;
            seen.add(key);
            return true;
        });
    }

    function getSelectedColumns() {
        return Array.from(document.querySelectorAll('.col-check:checked')).map(input => input.value);
    }

    function renderPromptPreview() {
        const columns = getSelectedColumns();
        const prompt = document.getElementById('prompt')?.value?.trim() || '';
        const mode = document.getElementById('fileUnderstandingMode')?.value || 'auto';
        const useExcelColumns = document.getElementById('useExcelColumns')?.checked;
        const excelRule = useExcelColumns
            ? 'If a separate column Excel is uploaded, read its first non-empty row and use those columns as the generation format. Otherwise use UI selected/default/custom columns.'
            : 'Use the columns selected in the UI.';
        const preview = `File understanding mode: ${modeLabel(mode)}\nExcel column rule: ${excelRule}\n\nGenerate test cases using ONLY these selected columns:\n${columns.map(c => '- ' + c).join('\n')}\n\nReturn valid JSON with requirementSummary, followUpQuestions, assumptions, selectedColumns and testCases.\n\nAdditional instruction:\n${prompt || 'Generate complete manual and automation-ready test cases.'}`;
        const previewNode = document.getElementById('promptPreview');
        if (previewNode) previewNode.innerText = preview;
        renderSelectedSummary(columns);
    }

    function renderSelectedSummary(columns) {
        const summary = document.getElementById('selectedSummary');
        if (!summary) return;
        summary.innerHTML = `<span class="chip">S.No auto</span>` + columns.map(c => `<span class="chip">${escapeHtml(c)}</span>`).join('');
    }

    function modeLabel(mode) {
        const labels = {
            'auto': 'Auto Detect',
            'document-ac': 'Document / Excel AC',
            'image-ac': 'Image with AC Text',
            'ui-design': 'UI Design / Figma Screenshot',
            'docx-with-images': 'Word Document with Images'
        };
        return labels[mode] || 'Auto Detect';
    }

    function updateFileName(inputId, labelId, emptyText) {
        const fileInput = document.getElementById(inputId);
        const fileName = fileInput.files && fileInput.files.length > 0 ? fileInput.files[0].name : emptyText;
        document.getElementById(labelId).innerText = fileName;
        if (inputId === 'file') setExcelStatus('');
    }

    async function loadExcelColumns() {
        const columnInput = document.getElementById('columnsFile');
        const requirementInput = document.getElementById('file');
        let selectedFile = null;
        let selectedSource = '';
        if (columnInput.files && columnInput.files.length > 0) {
            selectedFile = columnInput.files[0];
            selectedSource = 'separate column Excel';
        } else if (requirementInput.files && requirementInput.files.length > 0 && isExcelFile(requirementInput.files[0].name)) {
            selectedFile = requirementInput.files[0];
            selectedSource = 'requirements Excel fallback';
        }
        if (!selectedFile) {
            setExcelStatus('Upload a separate expected column Excel first, then click Load Column Template. You can still use UI checkbox/custom columns without uploading this file.', 'warn');
            return;
        }
        if (!isExcelFile(selectedFile.name)) {
            setExcelStatus('Column template must be .xls or .xlsx. For other formats, use UI checkboxes or custom columns.', 'warn');
            return;
        }
        setExcelStatus('Reading expected columns from ' + selectedSource + '...', 'warn');
        const formData = new FormData();
        formData.append('file', selectedFile);
        try {
            const response = await fetch('/api/testcases/columns/from-excel', { method: 'POST', body: formData });
            const data = await response.json();
            if (!response.ok) throw new Error(data.message || 'Unable to read Excel columns');
            const columns = data.columns || [];
            if (columns.length === 0) {
                setExcelStatus(data.message || 'No expected columns found. Keep output column names in the first row of the column Excel.', 'warn');
                return;
            }
            applyColumnsToUi(columns);
            setExcelStatus((data.message || `Detected ${columns.length} columns from Excel.`) + ' Source: ' + selectedFile.name, 'good');
        } catch (e) {
            setExcelStatus(e.message, 'warn');
        }
    }

    function applyColumnsToUi(columns) {
        ensureColumnsExist(columns);
        document.querySelectorAll('.col-check').forEach(input => input.checked = false);
        columns.forEach(column => {
            const checkbox = document.getElementById('col_' + normalizeId(column));
            if (checkbox) checkbox.checked = true;
        });
        renderPromptPreview();
    }

    function isExcelFile(fileName) { return /\.(xls|xlsx)$/i.test(fileName || ''); }

    function isSerialColumn(value) {
        const key = normalizeId(value || '').toLowerCase().replaceAll('_', '');
        return key === 'sno' || key === 'serialno' || key === 'serialnumber';
    }

    function setExcelStatus(message, type) {
        const status = document.getElementById('excelColumnStatus');
        if (!status) return;
        status.className = 'excel-status' + (type ? ' ' + type : '');
        status.innerText = message || 'If no column Excel is uploaded, the selected/default/custom columns below are used.';
    }

    async function checkOcrStatus() {
        const status = document.getElementById('ocrStatus');
        status.className = 'ocr-status warn';
        status.innerText = 'Checking OCR setup...';
        try {
            const response = await fetch('/api/testcases/ocr/status');
            const data = await response.json();
            const lines = [
                data.message || 'OCR status checked.',
                'Language: ' + (data.language || ''),
                'Resolved tessdata path: ' + (data.resolvedTessdataPath || 'Not found'),
                'traineddata found: ' + (data.trainedDataFound ? 'Yes' : 'No')
            ];
            status.className = 'ocr-status ' + (data.trainedDataFound ? 'good' : 'warn');
            status.innerText = lines.join('\n');
        } catch (e) {
            status.className = 'ocr-status warn';
            status.innerText = 'Unable to check OCR setup: ' + e.message;
        }
    }

    function toggleToken() {
        const input = document.getElementById('apiKey');
        const visible = input.type === 'text';
        input.type = visible ? 'password' : 'text';
        document.getElementById('tokenToggle').innerText = visible ? 'Show' : 'Hide';
    }

    async function generateTestCases() {
        const fileInput = document.getElementById('file');
        const error = document.getElementById('error');
        const loader = document.getElementById('loader');
        const result = document.getElementById('result');
        const exportBtn = document.getElementById('exportBtn');
        const generateBtn = document.getElementById('generateBtn');
        const selectedColumns = getSelectedColumns();

        error.innerText = '';
        exportBtn.disabled = true;
        document.getElementById('caseCount').innerText = '0 cases';
        lastResponse = null;
        if (!fileInput.files || fileInput.files.length === 0) {
            error.innerText = 'Please upload the main requirements / AC / design file.';
            return;
        }
        if (selectedColumns.length < 4) {
            error.innerText = 'Please select at least 4 columns.';
            return;
        }

        const provider = currentProvider();
        const apiKey = document.getElementById('apiKey').value.trim();
        const modelName = document.getElementById('modelName').value.trim();
        const baseUrl = document.getElementById('baseUrl').value.trim();
        if (!modelName) {
            error.innerText = 'Please choose or enter a model name.';
            return;
        }
        if (!baseUrl) {
            error.innerText = 'Please enter the base URL.';
            return;
        }

        const formData = new FormData();
        formData.append('requirementsFile', fileInput.files[0]);
        const columnFileInput = document.getElementById('columnsFile');
        if (columnFileInput.files && columnFileInput.files.length > 0) formData.append('expectedColumnsFile', columnFileInput.files[0]);
        formData.append('additionalPrompt', document.getElementById('prompt').value);
        formData.append('selectedColumns', selectedColumns.join(','));
        formData.append('fileUnderstandingMode', document.getElementById('fileUnderstandingMode').value);
        formData.append('useUploadedExcelColumns', document.getElementById('useExcelColumns').checked ? 'true' : 'false');
        formData.append('provider', provider);
        if (apiKey) formData.append('apiKey', apiKey);
        formData.append('modelName', modelName);
        formData.append('baseUrl', baseUrl);

        loader.style.display = 'block';
        generateBtn.disabled = true;
        result.innerHTML = '<div class="empty-state"><div><div class="icon">…</div><h3>Generating test cases</h3><p>Reading the requirement source and sending the optimized prompt to ' + escapeHtml(providerConfigs[provider].label) + '.</p></div></div>';
        try {
            const response = await fetch('/api/testcases/generate', { method: 'POST', body: formData });
            const data = await response.json();
            if (!response.ok) throw new Error(data.message || 'Failed to generate test cases');
            lastResponse = data;
            renderResult(data);
            exportBtn.disabled = false;
        } catch (e) {
            error.innerText = e.message;
            result.innerHTML = `<div class="empty-state"><div><div class="icon">!</div><h3>Generation failed</h3><p>${escapeHtml(e.message)}</p></div></div>`;
        } finally {
            loader.style.display = 'none';
            generateBtn.disabled = false;
        }
    }

    function renderResult(data) {
        const result = document.getElementById('result');
        const testCases = data.testCases || [];
        const columns = data.selectedColumns && data.selectedColumns.length ? data.selectedColumns : getSelectedColumns();
        document.getElementById('caseCount').innerText = `${testCases.length} cases`;
        let html = '<div class="result-top">';
        html += `<div class="info-box"><b>Requirement Summary</b>${escapeHtml(data.requirementSummary || '')}</div>`;
        html += `<div class="info-box"><b>Follow-up Questions</b>${renderList(data.followUpQuestions)}</div>`;
        html += `<div class="info-box"><b>Assumptions</b>${renderList(data.assumptions)}</div>`;
        html += '</div>';
        html += '<div class="table-wrap"><table><thead><tr>';
        ['S.No', ...columns].forEach(h => html += `<th>${escapeHtml(h)}</th>`);
        html += '</tr></thead><tbody>';
        testCases.forEach((tc, index) => {
            html += '<tr><td>' + (index + 1) + '</td>';
            columns.forEach(column => html += `<td>${escapeHtml(valueAsText(tc[column]))}</td>`);
            html += '</tr>';
        });
        html += '</tbody></table></div>';
        result.innerHTML = html;
    }

    function renderList(items) {
        if (!items || items.length === 0) return '<span class="help">None</span>';
        return '<ol>' + items.map(item => `<li>${escapeHtml(item)}</li>`).join('') + '</ol>';
    }

    async function exportExcel() {
        if (!lastResponse) return;
        const response = await fetch('/api/testcases/export', {
            method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify(lastResponse)
        });
        if (!response.ok) {
            let message = 'Export failed';
            try { const errorData = await response.json(); message = errorData.message || message; } catch (_) {}
            alert(message);
            return;
        }
        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'TCGen_TestCases.xlsx';
        document.body.appendChild(a);
        a.click();
        a.remove();
        window.URL.revokeObjectURL(url);
    }

    function renderSampleResult() {
        document.getElementById('fileName').innerText = 'place_order_acceptance_criteria_sample.xlsx';
        document.getElementById('columnsFileName').innerText = 'expected_columns_first_row_template.xlsx';
        lastResponse = {
            requirementSummary: 'Place order flow validates product selection, cart review, address, payment and final order confirmation. The input may come from a normal document, image screenshot or Word file containing embedded images.',
            followUpQuestions: ['Should COD be allowed for all pincodes?', 'What is the retry limit for payment failure?', 'If the input is a design screenshot, what validations are mandatory for each field?'],
            assumptions: ['User is already logged in.', 'Inventory is available for the selected product.', 'Readable screenshot text is extracted through OCR before LLM generation.'],
            selectedColumns: getSelectedColumns(),
            testCases: [
                buildSampleRow('TC_PO_001', 'Order', 'AC-001', 'Place order with valid card payment', 'User has product in cart', 'Open cart\nSelect address\nChoose card payment\nConfirm order', 'Product: Mobile, Qty: 1', 'Order is created and confirmation page is displayed', 'High', 'Positive', 'Yes'),
                buildSampleRow('TC_PO_002', 'Order', 'AC-002', 'Payment failure during order placement', 'User has product in cart', 'Open cart\nSelect address\nUse failed payment card\nConfirm payment', 'Card: declined test card', 'Payment failure message is shown and order is not created', 'High', 'Negative', 'Yes'),
                buildSampleRow('TC_PO_003', 'Order', 'AC-003', 'Quantity boundary validation', 'User has product in cart', 'Increase quantity to maximum allowed\nTry one more quantity', 'Qty: max + 1', 'System prevents quantity above allowed limit', 'Medium', 'Boundary', 'Yes')
            ]
        };
        renderResult(lastResponse);
        document.getElementById('exportBtn').disabled = false;
    }

    function buildSampleRow(testId, module, req, scenario, precondition, steps, testData, expected, priority, type, automation) {
        const row = {};
        getSelectedColumns().forEach(column => row[column] = '');
        row['Test ID'] = testId; row['Module'] = module; row['Requirement ID'] = req; row['Scenario'] = scenario;
        row['Precondition'] = precondition; row['Test Steps'] = steps; row['Test Data'] = testData; row['Expected Result'] = expected;
        row['Priority'] = priority; row['Test Type'] = type; row['Automation Candidate'] = automation; row['AC Mapping'] = req;
        row['API Method'] = 'POST'; row['API Endpoint'] = '/api/orders'; row['Status Code'] = type === 'Positive' ? '201' : '400';
        row['DB Validation'] = type === 'Positive' ? 'Order row created in orders table' : 'No confirmed order row created';
        row['Remarks'] = 'Sample preview row';
        return row;
    }

    function valueAsText(value) {
        if (value === null || value === undefined) return '';
        if (Array.isArray(value)) return value.map(valueAsText).join('\n');
        if (typeof value === 'object') return Object.entries(value).map(([k, v]) => `${k}: ${valueAsText(v)}`).join('\n');
        return String(value);
    }

    function normalizeId(value) { return value.replace(/[^A-Za-z0-9]/g, '_'); }

    function escapeHtml(value) {
        if (value === null || value === undefined) return '';
        return String(value)
            .replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;')
            .replaceAll('"', '&quot;').replaceAll("'", '&#039;').replaceAll('\n', '<br>');
    }

    function escapeAttr(value) { return escapeHtml(value).replaceAll('`', '&#096;'); }
