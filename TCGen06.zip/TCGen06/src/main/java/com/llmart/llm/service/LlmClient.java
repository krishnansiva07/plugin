package com.llmart.llm.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.llmart.llm.config.ChatConfig;
import com.llmart.llm.exception.TcgenException;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.Locale;

/**
 * Unified OpenAI-compatible chat client for both AI4Dev and LLM@CIB.
 *
 * This intentionally mirrors the working chat implementation from the reference project:
 * - the UI provides a base URL, model and bearer token;
 * - the client appends /chat/completions only when needed;
 * - requests use messages + stream=false;
 * - max_tokens is omitted when configured as 0 so the provider can manage the output budget.
 *
 * TCGen additionally asks for JSON mode first because its downstream response is structured.
 * If a provider explicitly rejects response_format=json_object, the same chat request is retried
 * without that field instead of switching APIs or providers.
 */
@Service
public class LlmClient {

    private final ChatConfig chatConfig;
    private final ObjectMapper objectMapper;
    private final HttpClient httpClient;

    public LlmClient(ChatConfig chatConfig, ObjectMapper objectMapper) {
        this.chatConfig = chatConfig;
        this.objectMapper = objectMapper;
        this.httpClient = HttpClient.newBuilder()
                .connectTimeout(Duration.ofSeconds(30))
                .build();
    }

    public String generate(String prompt,
                           String provider,
                           String userApiKey,
                           String userModelName,
                           String userBaseUrl) {
        ChatConfig.ResolvedConnection connection = chatConfig.resolveConnection(
                provider, userApiKey, userModelName, userBaseUrl);

        try {
            // First use OpenAI JSON mode. This is the most reliable path for TCGen's expected object output.
            HttpResult first = requestChat(connection, prompt, true);
            if (first.success()) {
                String content = extractGeneratedText(first.body());
                if (StringUtils.hasText(content)) return content;
                throw new TcgenException(connection.displayName() + " returned HTTP 200 but generated content was empty.");
            }

            if (indicatesUnsupportedJsonFormat(first.statusCode(), first.body())) {
                // Match the reference chat client's compatibility strategy: stay on chat/completions,
                // remove only the unsupported capability, and retry once.
                HttpResult fallback = requestChat(connection, prompt, false);
                if (!fallback.success()) throw httpFailure(connection, fallback);
                String content = extractGeneratedText(fallback.body());
                if (!StringUtils.hasText(content)) {
                    throw new TcgenException(connection.displayName() + " returned HTTP 200 but generated content was empty.");
                }
                return content;
            }

            throw httpFailure(connection, first);
        } catch (TcgenException ex) {
            throw ex;
        } catch (InterruptedException ex) {
            Thread.currentThread().interrupt();
            throw new TcgenException(connection.displayName() + " request was interrupted.", ex);
        } catch (Exception ex) {
            throw new TcgenException(connection.displayName()
                    + " chat request failed. Check API key, model, base URL and network access.", ex);
        }
    }

    private HttpResult requestChat(ChatConfig.ResolvedConnection connection,
                                   String prompt,
                                   boolean jsonMode) throws Exception {
        ObjectNode payload = objectMapper.createObjectNode();
        payload.put("model", connection.modelName());

        ArrayNode messages = payload.putArray("messages");
        ObjectNode system = messages.addObject();
        system.put("role", "system");
        system.put("content", "You are a senior test architect. Follow the user's instructions exactly. Return only the requested final answer without commentary.");
        ObjectNode user = messages.addObject();
        user.put("role", "user");
        user.put("content", prompt);

        // Same behavior as the reference chat project: provider-managed output budget by default.
        if (connection.maxTokens() > 0) payload.put("max_tokens", connection.maxTokens());
        payload.put("stream", false);
        if (jsonMode) {
            ObjectNode responseFormat = payload.putObject("response_format");
            responseFormat.put("type", "json_object");
        }

        String endpoint = chatCompletionsUrl(connection.baseUrl());
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(endpoint))
                .header("Authorization", "Bearer " + connection.apiKey())
                .header("Content-Type", "application/json")
                .header("Accept", "application/json")
                .timeout(Duration.ofMinutes(4))
                .POST(HttpRequest.BodyPublishers.ofString(objectMapper.writeValueAsString(payload)))
                .build();

        HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
        return new HttpResult(response.statusCode(), response.body(), endpoint);
    }

    private String extractGeneratedText(String responseBody) {
        try {
            JsonNode root = objectMapper.readTree(responseBody);
            JsonNode choices = root.path("choices");
            if (!choices.isArray() || choices.isEmpty()) {
                throw new TcgenException("LLM returned HTTP 200 but no choices were present in the response.");
            }

            JsonNode firstChoice = choices.get(0);
            JsonNode message = firstChoice.path("message");
            String content = nodeToText(message.path("content"));

            // A few OpenAI-compatible gateways expose a text field even for chat responses.
            if (!StringUtils.hasText(content)) content = nodeToText(firstChoice.path("text"));

            // Reasoning-capable gateways sometimes separate reasoning from final content. We do not
            // normally use reasoning as the answer, but if final content is empty and reasoning itself
            // contains a JSON object, returning it is better than surfacing a misleading empty-response error.
            if (!StringUtils.hasText(content)) {
                String reasoning = nodeToText(message.path("reasoning_content"));
                if (looksLikeJsonObject(reasoning)) content = reasoning;
            }

            return content == null ? "" : content.trim();
        } catch (TcgenException ex) {
            throw ex;
        } catch (Exception ex) {
            throw new TcgenException("Unable to parse the OpenAI-compatible chat response.", ex);
        }
    }

    private String nodeToText(JsonNode node) {
        if (node == null || node.isMissingNode() || node.isNull()) return "";
        if (node.isTextual()) return node.asText();
        if (node.isArray()) {
            StringBuilder out = new StringBuilder();
            for (JsonNode item : node) {
                String text = item.isTextual() ? item.asText() : item.path("text").asText("");
                if (StringUtils.hasText(text)) {
                    if (!out.isEmpty()) out.append('\n');
                    out.append(text);
                }
            }
            return out.toString();
        }
        return node.asText("");
    }

    private boolean looksLikeJsonObject(String value) {
        if (!StringUtils.hasText(value)) return false;
        String text = value.trim();
        return text.indexOf('{') >= 0 && text.lastIndexOf('}') > text.indexOf('{');
    }

    private TcgenException httpFailure(ChatConfig.ResolvedConnection connection, HttpResult result) {
        String body = clip(result.body());
        String reason;
        if (result.statusCode() == 401 || result.statusCode() == 403) reason = "Authentication/authorization was rejected";
        else if (result.statusCode() == 404) reason = "Chat endpoint was not found";
        else if (result.statusCode() == 429) reason = "Rate limit or quota was reached";
        else if (result.statusCode() >= 500) reason = "Provider returned a server error";
        else reason = "Chat request was rejected";
        return new TcgenException(reason + " for " + connection.displayName() + " (HTTP " + result.statusCode()
                + ") at " + result.endpoint() + (StringUtils.hasText(body) ? ". Response: " + body : "."));
    }

    private boolean indicatesUnsupportedJsonFormat(int status, String body) {
        if (status != 400 && status != 404 && status != 422) return false;
        String text = body == null ? "" : body.toLowerCase(Locale.ROOT);
        boolean formatTerm = text.contains("response_format") || text.contains("json_object") || text.contains("json mode");
        boolean unsupported = text.contains("not support") || text.contains("unsupported")
                || text.contains("unknown field") || text.contains("unknown parameter")
                || text.contains("unrecognized") || text.contains("not available")
                || text.contains("not allowed");
        return formatTerm && unsupported;
    }

    private String chatCompletionsUrl(String baseUrl) {
        String base = baseUrl == null ? "" : baseUrl.trim();
        while (base.endsWith("/")) base = base.substring(0, base.length() - 1);
        if (base.endsWith("/chat/completions")) return base;
        return base + "/chat/completions";
    }

    private String clip(String body) {
        if (body == null) return "";
        String cleaned = body.trim();
        return cleaned.length() > 1600 ? cleaned.substring(0, 1600) + "..." : cleaned;
    }

    private record HttpResult(int statusCode, String body, String endpoint) {
        boolean success() { return statusCode >= 200 && statusCode < 300; }
    }
}
