package com.llmart.llm.service;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.llmart.llm.dto.TestCaseGenerationResponse;
import com.llmart.llm.exception.TcgenException;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class JsonResponseParser {

    private final ObjectMapper objectMapper;

    public JsonResponseParser() {
        this.objectMapper = new ObjectMapper()
                .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
    }

    public TestCaseGenerationResponse parse(String llmResponse, List<String> selectedColumns) {
        try {
            String json = extractJsonObject(llmResponse);
            TestCaseGenerationResponse response = objectMapper.readValue(json, TestCaseGenerationResponse.class);
            response.setRawResponse(llmResponse);
            response.setSelectedColumns(new ArrayList<>(selectedColumns));
            response.normalizeTestCasesToSelectedColumns();
            validate(response);
            return response;
        } catch (TcgenException ex) {
            throw ex;
        } catch (Exception ex) {
            throw new TcgenException("LLM response was not valid JSON. TCGen will retry once using strict JSON mode.", ex);
        }
    }

    private void validate(TestCaseGenerationResponse response) {
        if (response.getTestCases() == null || response.getTestCases().isEmpty()) {
            throw new TcgenException("LLM returned JSON but did not include any test cases.");
        }
    }

    /**
     * Extract the first syntactically valid JSON object instead of assuming the first and last braces
     * belong to the same object. This tolerates provider prefixes, code fences and short commentary.
     */
    private String extractJsonObject(String response) {
        if (response == null || response.isBlank()) {
            throw new TcgenException("LLM returned an empty response.");
        }

        String cleaned = stripCodeFences(response.trim());

        // Fast path: the entire response is already one JSON object.
        if (isObjectJson(cleaned)) return cleaned;

        for (int start = cleaned.indexOf('{'); start >= 0; start = cleaned.indexOf('{', start + 1)) {
            String candidate = balancedObject(cleaned, start);
            if (candidate != null && isObjectJson(candidate)) return candidate;
        }

        throw new TcgenException("No valid JSON object was present in the model response. TCGen will retry once using strict JSON mode.");
    }

    private String stripCodeFences(String value) {
        String cleaned = value
                .replace("```json", "")
                .replace("```JSON", "")
                .replace("```Json", "")
                .replace("```", "")
                .trim();
        return cleaned;
    }

    private boolean isObjectJson(String value) {
        if (value == null || value.isBlank()) return false;
        try {
            JsonNode node = objectMapper.readTree(value);
            return node != null && node.isObject();
        } catch (Exception ignored) {
            return false;
        }
    }

    /** Finds a brace-balanced object while respecting quoted strings and escaped quotes. */
    private String balancedObject(String text, int start) {
        int depth = 0;
        boolean inString = false;
        boolean escaped = false;
        for (int i = start; i < text.length(); i++) {
            char c = text.charAt(i);
            if (inString) {
                if (escaped) {
                    escaped = false;
                } else if (c == '\\') {
                    escaped = true;
                } else if (c == '"') {
                    inString = false;
                }
                continue;
            }
            if (c == '"') {
                inString = true;
                continue;
            }
            if (c == '{') depth++;
            else if (c == '}') {
                depth--;
                if (depth == 0) return text.substring(start, i + 1);
                if (depth < 0) return null;
            }
        }
        return null;
    }
}
