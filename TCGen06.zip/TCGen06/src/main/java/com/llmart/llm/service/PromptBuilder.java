package com.llmart.llm.service;

import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class PromptBuilder {

    public String buildPrompt(String acceptanceCriteriaText, String additionalPrompt, List<String> selectedColumns, String fileUnderstandingMode) {
        String safeAdditionalPrompt = additionalPrompt == null || additionalPrompt.isBlank()
                ? "Generate complete manual and automation-ready test cases."
                : additionalPrompt.trim();

        String columnList = selectedColumns.stream()
                .map(column -> "- " + column)
                .collect(Collectors.joining("\n"));

        String jsonColumnTemplate = selectedColumns.stream()
                .map(column -> "      \"" + escapeJson(column) + "\": \"value\"")
                .collect(Collectors.joining(",\n"));

        String modeInstruction = modeInstruction(fileUnderstandingMode);

        return """
                You are a Senior Test Architect and SDET.
                Generate high quality test cases from the Acceptance Criteria document.

                Important output-column rule:
                - The user selected the required Excel/test-case columns from the UI.
                - Generate test case objects using ONLY these selected column names.
                - Use the exact spelling, spaces and casing shown below.
                - Do not add extra columns inside testCases.
                - Do not remove any selected column.
                - Every test case object must contain all selected columns.
                - If a value is not applicable, return an empty string or "N/A".

                Selected output columns:
                %s

                Test design rules:
                1. Understand the Acceptance Criteria carefully.
                2. If information is missing, add clear follow-up questions.
                3. Still generate test cases using practical assumptions.
                4. Cover positive, negative, boundary, validation, integration, UI, API, database, smoke and regression cases wherever applicable.
                5. Prefer business readable scenarios.
                6. Mention test data clearly.
                7. Priority must be High, Medium or Low when Priority column is selected.
                8. Test Type should use values like Positive, Negative, Boundary, UI, API, DB, Security, Accessibility, Regression, Smoke or Integration when Test Type column is selected.
                9. Automation Candidate should be Yes, No or Partial when Automation Candidate column is selected.
                10. Return only valid JSON. Do not return markdown. Do not wrap with ```json.

                File understanding mode:
                %s

                Additional user instruction:
                %s

                JSON response format:
                {
                  "requirementSummary": "short summary of requirement",
                  "followUpQuestions": ["question 1"],
                  "assumptions": ["assumption 1"],
                  "selectedColumns": [%s],
                  "testCases": [
                    {
                %s
                    }
                  ]
                }

                Acceptance Criteria document text:
                ------------------------------
                %s
                ------------------------------
                """.formatted(
                columnList,
                modeInstruction,
                safeAdditionalPrompt,
                selectedColumns.stream().map(column -> "\"" + escapeJson(column) + "\"").collect(Collectors.joining(", ")),
                jsonColumnTemplate,
                acceptanceCriteriaText
        );
    }

    public String buildPreviewPrompt(String additionalPrompt, List<String> selectedColumns, String fileUnderstandingMode) {
        String safeAdditionalPrompt = additionalPrompt == null || additionalPrompt.isBlank()
                ? "Generate complete manual and automation-ready test cases."
                : additionalPrompt.trim();
        return "Generate test cases using ONLY these columns: "
                + String.join(", ", selectedColumns)
                + ". File understanding mode: "
                + modeInstruction(fileUnderstandingMode)
                + ". Return valid JSON with requirementSummary, followUpQuestions, assumptions, selectedColumns and testCases. Additional instruction: "
                + safeAdditionalPrompt;
    }

    public String buildStrictJsonRetryPrompt(String originalPrompt) {
        return originalPrompt + """

                STRICT RETRY REQUIREMENT:
                Your previous answer could not be parsed by the application.
                Return exactly one complete JSON object and nothing else.
                Do not include reasoning, explanations, headings, markdown, code fences, or text before/after JSON.
                Ensure the JSON is complete and includes a non-empty testCases array.
                """;
    }

    private String modeInstruction(String fileUnderstandingMode) {
        String mode = fileUnderstandingMode == null ? "auto" : fileUnderstandingMode.trim().toLowerCase();
        return switch (mode) {
            case "image-ac" -> "The uploaded file is an image/screenshot containing Acceptance Criteria or requirement text. Use OCR text as source requirement content. Ask follow-up questions for unclear OCR sections.";
            case "ui-design" -> "The uploaded file is a UI design or screen screenshot. Use OCR text as visible screen elements and infer UI, validation, field-level, navigation, error, success, accessibility and regression test cases. If visual layout details are missing, add assumptions and follow-up questions.";
            case "docx-with-images" -> "The uploaded file is a Word document that may contain normal text, tables and embedded images. Use both document text and OCR text extracted from embedded images.";
            case "document-ac" -> "The uploaded file is a normal AC/business requirement document. Generate test cases from the extracted document text.";
            default -> "Auto-detect the uploaded content. If OCR markers are present, treat them as text extracted from uploaded images or embedded Word images. Generate practical test cases and list unclear parts as follow-up questions.";
        };
    }

    private String escapeJson(String value) {
        return value == null ? "" : value.replace("\\", "\\\\").replace("\"", "\\\"");
    }
}
