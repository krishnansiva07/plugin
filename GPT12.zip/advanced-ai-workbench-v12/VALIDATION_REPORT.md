# V12 validation report

Package validation date: 2026-09-05

## Passed in the packaging environment

- `pom.xml` XML parse.
- JavaScript syntax: `app.js` and `markdown.js` with `node --check`.
- Shell syntax: `run.sh` and `validate-local.sh` with `bash -n`.
- Full Java source parse with `javac --release 17 -proc:none`: no Java syntax/parser errors were detected. External dependency symbols are unavailable in this sandbox, as expected without Maven dependencies.
- `PromptResourceResolver` compiled with Java 17 against a minimal Spring annotation stub and passed a standalone behavior harness covering:
  - multiple prompt paths;
  - primary/broken-project preference over an earlier reference project;
  - read-only reference classification;
  - writable secondary project classification;
  - standalone diagnostic/log read-only classification;
  - paths containing spaces;
  - case-safe project markers such as `Cargo.toml`;
  - `.git`-root project inference.
- `AgentWorkspaceService` compiled with Java 17 against minimal dependency stubs and passed a standalone multi-resource behavior harness covering:
  - primary workspace + writable secondary project + read-only reference + diagnostic log;
  - resource read;
  - secondary-project edit;
  - reference-to-secondary cross-resource copy;
  - read-only reference write rejection;
  - cross-resource status and diff tracking.
- `AgentToolRegistry` compiled with Java 17 and reports exactly 54 unique built-in tool definitions with matching native tool definitions.
- Added Maven/JUnit integration coverage in `AgentWorkspaceServiceMultiResourceTest` and expanded resolver/tool registry tests.

## Environment limitation

A complete `./mvnw clean test` could not run inside this packaging sandbox because Maven is not installed and outbound DNS/download access to Maven Central is blocked. The included `mvnw` / `mvnw.cmd` scripts use an installed Maven when available, or bootstrap Apache Maven 3.9.11 on the first run when the machine has network access.

Run on the target machine:

```bash
./validate-local.sh
```

or on Windows:

```bat
validate-local.bat
```

The validation scripts run Java checks, frontend syntax checks when Node is available, Maven tests, and package creation.

## Recommended first functional tests

1. Project + issue log path in one prompt.
2. Two writable projects + one failure log.
3. Broken project + working/reference project + error log.
4. Exact source-file path with no workspace pre-mapped.
5. Verify read-only reference protection by explicitly asking the agent to compare but not modify the reference.
6. Verify both modified projects are independently built/tested when a task changes both.
