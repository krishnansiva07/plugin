@echo off
setlocal EnableExtensions
cd /d "%~dp0"

where mvn >nul 2>nul
if not errorlevel 1 (
  call mvn %*
  exit /b %errorlevel%
)

if "%MAVEN_VERSION%"=="" set MAVEN_VERSION=3.9.11
set "MAVEN_HOME_LOCAL=%CD%\.mvn\apache-maven-%MAVEN_VERSION%"
set "MAVEN_BIN=%MAVEN_HOME_LOCAL%\bin\mvn.cmd"
set "ARCHIVE=%CD%\.mvn\apache-maven-%MAVEN_VERSION%-bin.zip"
set "URL=https://repo.maven.apache.org/maven2/org/apache/maven/apache-maven/%MAVEN_VERSION%/apache-maven-%MAVEN_VERSION%-bin.zip"

if not exist "%MAVEN_BIN%" (
  if not exist ".mvn" mkdir ".mvn"
  echo Maven was not found. Bootstrapping Apache Maven %MAVEN_VERSION%...
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; Invoke-WebRequest -UseBasicParsing -Uri '%URL%' -OutFile '%ARCHIVE%'; Expand-Archive -LiteralPath '%ARCHIVE%' -DestinationPath '%CD%\.mvn' -Force; Remove-Item -LiteralPath '%ARCHIVE%' -Force" || exit /b 1
)

call "%MAVEN_BIN%" %*
exit /b %errorlevel%
