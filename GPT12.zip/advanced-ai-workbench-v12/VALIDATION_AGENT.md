# GPT12 validation report

Validation date: 2026-09-05.

## Passed in the packaging environment

- `pom.xml` parses as valid XML.
- Java 17 source compilation check passed for the new/modified core resource runtime:
  - `PromptResourceResolver`
  - `AgentWorkspaceService`
  - `AgentToolRegistry`
- Java 17 source compilation check passed for the modified `AgentService` against dependency stubs plus the compiled real resource/workspace classes.
- Java 17 source compilation check passed for the modified `ChatService` against dependency stubs plus the real resolver.
- New `PromptResourceResolverTest` and updated `AgentToolRegistryTest` compile as Java 17 test sources against JUnit API stubs.
- Multi-resource workspace harness passed: read standalone log, edit secondary project, copy from read-only reference into writable project, block reference write, and report cross-resource diff.
- Resolver behavior harness passed with:
  - a broken primary project;
  - an earlier working/reference project kept read-only;
  - a standalone failure log kept read-only.
- Agent tool registry harness passed with **54 unique tools** and a 1:1 native-definition count.
- `app.js` and `markdown.js` pass `node --check`.
- `mvnw`, `run.sh`, and `validate-local.sh` pass Bash syntax validation.

## Environment limitation

The packaging sandbox contains Java but does not contain Maven and outbound DNS/download access is unavailable. Therefore a real dependency-resolved `mvn clean test` / Spring Boot executable-JAR build cannot be completed inside this sandbox.

To remove the user's need to install Maven manually, V12 includes `mvnw` and `mvnw.cmd`. They use an installed Maven when available or bootstrap Apache Maven 3.9.11 on first use when network access is available.

Run the full project validation locally with:

Linux/macOS:
```bash
./validate-local.sh
```

Windows:
```bat
validate-local.bat
```

The expected V12 JAR is:

`target/advanced-ai-chat-2.2.0-SNAPSHOT.jar`

## V12 scope validated

- Existing mapped workspace remains supported.
- Agent mode can infer the primary workspace from an explicit existing project/source/config path when no workspace is active.
- Multiple prompt paths are resolved into aliases.
- Clearly labelled reference/baseline/known-good projects are read-only.
- Secondary writable projects can be read, edited, copied/moved into, built, tested, checked, and used as shell working directories.
- Standalone prompt files are read-only resources.
- User-resolved aliases, not arbitrary model-invented paths, control secondary filesystem access.
- Secondary resource mutations participate in change tracking and verification state.
- Large-workspace snapshots skip ignored subtrees rather than traversing them first.
