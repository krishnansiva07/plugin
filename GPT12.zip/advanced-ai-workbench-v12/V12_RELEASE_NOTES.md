# GPT12 / Advanced AI Workbench V12

V12 turns the V11 single-workspace runtime into a prompt-aware **multi-resource / multi-workspace agent** while keeping the original generic Java 17 architecture.

## Major changes

### Prompt path resolver
Agent mode can start without manually mapping a workspace when the prompt contains an existing project or source/configuration file path. The resolver:

- supports quoted/backtick paths, Windows drive paths, UNC paths, POSIX paths, `~/...`, relative paths and paths containing spaces;
- verifies that a candidate exists before granting it to the agent;
- walks upward from a supplied source/configuration file to find a project root;
- recognizes common Java, Node, Python, Go, Rust, .NET, C/C++, Swift, Dart, PHP, Ruby, Bazel, Scala, Elixir and other build markers;
- canonicalizes resolved paths before use.

### Multiple paths in one prompt
The runtime creates named resource aliases. The existing mapped/inferred project remains `@workspace`; additional paths receive aliases such as `@backend`, `@reference`, or `@failure`.

- Explicit project/directory paths: writable resources for the run, still governed by Edit/Shell permissions. Paths clearly labelled `reference`, `baseline`, or `known good` remain read-only.
- Standalone files such as logs, screenshots, Office/PDF documents and traces: read-only resources.
- A source/configuration file in another project: the owning project is exposed as a writable resource and the supplied file is recorded as the focus path.

The model cannot create external access merely by inventing a path. Secondary filesystem access must come from the prompt resolver and an issued resource alias.

### Cross-resource tools
V12 adds structured tools for secondary resources:

- `resource_catalog`, `resource_list`, `resource_info`, `resource_read`, `resource_grep`
- `resource_edit`, `resource_write`, `resource_delete`
- `resource_copy`, `resource_move`
- `resource_build`, `resource_test`, `resource_check`, `resource_bash`

Cross-resource copy allows a read-only reference as the source while enforcing a writable destination.

### Verification remains revision-aware
Changes made through secondary writable projects participate in the same run mutation tracking. Build/test/check on a secondary project can satisfy verification for that resource. The final response reports changes across prompt-resolved resources instead of pretending every edit was under the primary root.

### Large-workspace performance
Filesystem snapshots now skip ignored directory subtrees such as `target`, `node_modules`, `.git`, build outputs and caches instead of walking into them and filtering afterward.

### Packaging
`run.sh`, `run.bat`, `validate-local.sh`, and `validate-local.bat` now use `mvnw` / `mvnw.cmd`. If Maven is already installed it is used directly. Otherwise the bootstrap downloads Maven 3.9.11 on first use, removing the need for a separate manual Maven installation when network access is available.

## Suggested validation prompts

### One project + issue log
```text
Fix the compilation problem.

Project:
D:\\Work\\PaymentAutomation

Issue log:
C:\\Temp\\jenkins-console.log

Build and test the project after the fix. Do not stop at code changes.
```

### Two writable projects + log
```text
The UI and API belong to the same application. Diagnose and fix the failure in whichever project is responsible.

Frontend:
D:\\Work\\PaymentUI

Backend:
D:\\Work\\PaymentAPI

Failure log:
C:\\Temp\\failure.log

Build/test every project you modify and report the verification evidence.
```

### Broken project + working reference
```text
Fix the broken implementation by comparing with the working reference where useful.

Broken project:
D:\\Projects\\FrameworkV2

Working reference:
D:\\Projects\\FrameworkV1

Error:
C:\\Logs\\compile.log

Modify FrameworkV2 only unless FrameworkV1 genuinely also needs a requested change.
```

### Exact source file without pre-mapping
```text
Fix this file and verify its owning project:
D:\\Automation\\Framework\\src\\test\\java\\steps\\LoginSteps.java
```

## Security model

V12 intentionally distinguishes explicit user resources from model-created strings:

1. the user includes a path in the prompt;
2. the resolver verifies and canonicalizes it;
3. the runtime issues an alias;
4. resource tools accept that alias;
5. edit/shell permission rules still apply to writable resources.

This prevents an LLM from silently turning an arbitrary guessed filesystem path into trusted access.
