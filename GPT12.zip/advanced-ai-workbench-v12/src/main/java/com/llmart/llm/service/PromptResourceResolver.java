package com.llmart.llm.service;

import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.file.*;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Resolves filesystem paths explicitly supplied by the user in a prompt.
 *
 * Security model:
 * - only paths that actually exist are accepted;
 * - the active workspace is supplied separately and is always trusted;
 * - an explicit source/config file inside a recognizable project promotes that project root as a project resource;
 * - standalone files are read-only contextual resources;
 * - directories/projects explicitly labelled as references/baselines are kept read-only;
 * - other explicit directories/projects may be writable for the run, still subject to runtime permissions;
 * - model-invented paths never become resources because tools address resources by resolver-issued aliases.
 */
@Service
public class PromptResourceResolver {
    private static final Set<String> PROJECT_MARKERS = Set.of(
            "pom.xml", "build.gradle", "build.gradle.kts", "settings.gradle", "settings.gradle.kts",
            "package.json", "pyproject.toml", "setup.py", "requirements.txt", "go.mod", "cargo.toml",
            "cmakelists.txt", "makefile", "build.xml", "package.swift", "pubspec.yaml", "composer.json",
            "gemfile", "workspace", "workspace.bazel", "module.bazel", "build.sbt", "mix.exs",
            "project.clj", "build.zig", "stack.yaml", "cabal.project"
    );
    private static final Set<String> DIAGNOSTIC_EXTENSIONS = Set.of(
            "log", "txt", "out", "err", "png", "jpg", "jpeg", "gif", "webp", "bmp", "pdf",
            "doc", "docx", "xls", "xlsx", "ppt", "pptx", "har", "trace", "zip"
    );

    private static final Pattern BACKTICK = Pattern.compile("`([^`]+)`");
    private static final Pattern QUOTED = Pattern.compile("[\"']([^\"'\\r\\n]+)[\"']");
    private static final Pattern WINDOWS = Pattern.compile("(?i)([A-Z]:[\\\\/][^\\r\\n`\"<>|?*]+)");
    private static final Pattern UNC = Pattern.compile("(\\\\\\\\[^\\r\\n`\"<>|?*]+)");
    private static final Pattern POSIX = Pattern.compile("(?<![A-Za-z0-9:])(/(?:[^\\s`\"'<>|]+/?)+)");

    public Optional<Path> primaryProjectPath(String prompt) {
        Path best = null;
        int bestScore = Integer.MIN_VALUE;
        int order = 0;
        for (Path path : explicitExistingPaths(prompt)) {
            try {
                Path candidate = null;
                if (Files.isDirectory(path)) {
                    Path project = findProjectRoot(path);
                    candidate = project != null ? project : path.toRealPath();
                } else if (Files.isRegularFile(path) && !isStandaloneDiagnostic(path)) {
                    // A source/config file strongly implies that its owning project should be the workspace.
                    Path project = findProjectRoot(path.getParent());
                    if (project != null && isLikelyProjectFile(path)) candidate = project;
                }
                if (candidate == null) { order++; continue; }

                int score = primaryPreference(prompt, path) - order++;
                if (score > bestScore) {
                    best = candidate;
                    bestScore = score;
                }
            } catch (Exception ignored) { order++; }
        }
        return Optional.ofNullable(best);
    }

    public Resolution resolve(String prompt, Path primaryRoot) {
        LinkedHashMap<String, ResolvedResource> byKey = new LinkedHashMap<>();
        Path canonicalPrimary = canonical(primaryRoot);
        if (canonicalPrimary != null) {
            byKey.put("workspace", new ResolvedResource("workspace", canonicalPrimary, null,
                    ResourceKind.PROJECT, true, true, "active workspace"));
        }

        int sequence = 1;
        for (Path explicit : explicitExistingPaths(prompt)) {
            try {
                Path canonical = explicit.toRealPath();
                if (canonicalPrimary != null && canonical.startsWith(canonicalPrimary)) continue;

                if (Files.isDirectory(canonical)) {
                    Path projectRoot = findProjectRoot(canonical);
                    Path root = projectRoot != null ? projectRoot : canonical;
                    if (canonicalPrimary != null && root.equals(canonicalPrimary)) continue;
                    String key = resourceIdentity(root, null);
                    if (byKey.values().stream().anyMatch(r -> resourceIdentity(r.root(), r.focus()) .equals(key))) continue;
                    boolean writable = !isExplicitReference(prompt, canonical);
                    ResourceKind kind = projectRoot != null ? ResourceKind.PROJECT : ResourceKind.DIRECTORY;
                    String alias = uniqueAlias(aliasBase(root, sequence++), byKey.keySet());
                    byKey.put(alias, new ResolvedResource(alias, root, null, kind, writable, false,
                            writable
                                    ? (projectRoot != null ? "explicit project path" : "explicit writable directory path")
                                    : "explicit read-only reference path"));
                } else if (Files.isRegularFile(canonical)) {
                    Path projectRoot = findProjectRoot(canonical.getParent());
                    if (projectRoot != null && !isStandaloneDiagnostic(canonical)) {
                        if (canonicalPrimary != null && projectRoot.equals(canonicalPrimary)) continue;
                        Path focus = projectRoot.relativize(canonical);
                        String existingAlias = findAliasForRoot(byKey, projectRoot);
                        if (existingAlias != null) {
                            ResolvedResource old = byKey.get(existingAlias);
                            if (old.focus() == null) byKey.put(existingAlias, old.withFocus(focus));
                        } else {
                            String alias = uniqueAlias(aliasBase(projectRoot, sequence++), byKey.keySet());
                            boolean writable = !isExplicitReference(prompt, canonical);
                            byKey.put(alias, new ResolvedResource(alias, projectRoot, focus,
                                    ResourceKind.PROJECT, writable, false,
                                    writable ? "project inferred from explicit file" : "read-only reference project inferred from explicit file"));
                        }
                    } else {
                        String alias = uniqueAlias(aliasBase(canonical, sequence++), byKey.keySet());
                        byKey.put(alias, new ResolvedResource(alias, canonical, null,
                                ResourceKind.FILE, false, false, "explicit read-only file resource"));
                    }
                }
            } catch (Exception ignored) { }
        }
        return new Resolution(List.copyOf(byKey.values()));
    }

    public List<Path> explicitExistingPaths(String prompt) {
        if (prompt == null || prompt.isBlank()) return List.of();
        LinkedHashSet<String> candidates = new LinkedHashSet<>();

        collect(BACKTICK, prompt, candidates);
        collect(QUOTED, prompt, candidates);

        for (String line : prompt.split("\\R")) {
            String trimmed = line.trim().replaceFirst("^[\\-*•]+\\s*", "");
            if (trimmed.isBlank()) continue;
            int colon = trimmed.indexOf(':');
            if (colon > 1 && colon + 1 < trimmed.length()) {
                String after = trimmed.substring(colon + 1).trim();
                if (looksPathLike(after)) candidates.add(after);
            }
            if (looksPathLike(trimmed)) candidates.add(trimmed);
        }
        collect(WINDOWS, prompt, candidates);
        collect(UNC, prompt, candidates);
        collect(POSIX, prompt, candidates);

        LinkedHashSet<Path> found = new LinkedHashSet<>();
        for (String raw : candidates) {
            Path path = existingPathFromCandidate(raw);
            if (path != null) found.add(path);
        }
        return List.copyOf(found);
    }

    private int primaryPreference(String prompt, Path path) {
        String label = labelForPath(prompt, path).toLowerCase(Locale.ROOT);
        if (containsAny(label, "reference", "baseline", "known good", "known-good", "comparison source", "compare source")) return -1000;
        if (containsAny(label, "broken", "target", "primary", "main", "workspace", "project to fix", "application to fix")) return 500;
        if (containsAny(label, "project", "frontend", "backend", "service", "application", "app")) return 200;
        if (containsAny(label, "issue file", "source file", "file")) return 100;
        return 0;
    }

    private boolean isExplicitReference(String prompt, Path path) {
        String label = labelForPath(prompt, path).toLowerCase(Locale.ROOT);
        return containsAny(label, "reference", "baseline", "known good", "known-good", "comparison source", "compare source");
    }

    private String labelForPath(String prompt, Path target) {
        if (prompt == null || prompt.isBlank() || target == null) return "";
        Path canonicalTarget = canonical(target);
        for (String line : prompt.split("\\R")) {
            String trimmed = line.trim().replaceFirst("^[\\-*•]+\\s*", "");
            int colon = trimmed.indexOf(':');
            if (colon <= 0 || colon + 1 >= trimmed.length()) continue;
            String label = trimmed.substring(0, colon).trim();
            Path candidate = existingPathFromCandidate(trimmed.substring(colon + 1).trim());
            if (candidate != null && canonical(candidate).equals(canonicalTarget)) return label;
        }
        return "";
    }

    private boolean containsAny(String value, String... needles) {
        for (String needle : needles) if (value.contains(needle)) return true;
        return false;
    }

    private void collect(Pattern pattern, String text, Set<String> out) {
        Matcher matcher = pattern.matcher(text);
        while (matcher.find()) out.add(matcher.group(1));
    }

    private boolean looksPathLike(String value) {
        if (value == null || value.isBlank()) return false;
        String v = stripWrapping(value.trim());
        if (v.matches("(?i)^[A-Z]:[\\\\/].+")) return true;
        if (v.startsWith("\\\\")) return true;
        if (v.startsWith("/") || v.startsWith("~/") || v.startsWith("./") || v.startsWith("../")) return true;
        return false;
    }

    private Path existingPathFromCandidate(String raw) {
        if (raw == null) return null;
        String candidate = stripWrapping(raw.trim());
        candidate = candidate.replaceFirst("[;,]+$", "").trim();
        if (candidate.isBlank() || candidate.startsWith("http://") || candidate.startsWith("https://")) return null;

        // Try the complete candidate first. If prose followed an unquoted path on the same line,
        // progressively remove trailing words until an existing path is found.
        String current = candidate;
        for (int attempt = 0; attempt < 30 && !current.isBlank(); attempt++) {
            Path p = toPath(current);
            if (p != null && Files.exists(p, LinkOption.NOFOLLOW_LINKS)) {
                try { return p.toRealPath(); }
                catch (IOException ignored) { return p.toAbsolutePath().normalize(); }
            }
            int cut = lastDelimiter(current);
            if (cut <= 0) break;
            current = current.substring(0, cut).replaceFirst("[.,;:]+$", "").trim();
        }
        return null;
    }

    private Path toPath(String value) {
        try {
            String expanded = value;
            if (expanded.startsWith("~/") || expanded.startsWith("~\\")) {
                expanded = System.getProperty("user.home", "") + expanded.substring(1);
            }
            return Path.of(expanded).toAbsolutePath().normalize();
        } catch (Exception ignored) { return null; }
    }

    private int lastDelimiter(String value) {
        int space = Math.max(value.lastIndexOf(' '), value.lastIndexOf('\t'));
        int comma = value.lastIndexOf(',');
        int semi = value.lastIndexOf(';');
        return Math.max(space, Math.max(comma, semi));
    }

    private String stripWrapping(String value) {
        String v = value == null ? "" : value.trim();
        while (v.length() >= 2 && ((v.startsWith("`") && v.endsWith("`")) ||
                (v.startsWith("\"") && v.endsWith("\"")) || (v.startsWith("'") && v.endsWith("'")) ||
                (v.startsWith("(") && v.endsWith(")")) || (v.startsWith("[") && v.endsWith("]")))) {
            v = v.substring(1, v.length() - 1).trim();
        }
        return v;
    }

    private Path findProjectRoot(Path start) {
        Path current = canonical(start);
        int depth = 0;
        while (current != null && depth++ < 30) {
            if (looksLikeProjectRoot(current)) return current;
            current = current.getParent();
        }
        return null;
    }

    private boolean looksLikeProjectRoot(Path dir) {
        if (dir == null || !Files.isDirectory(dir)) return false;
        // Project markers are matched case-insensitively so Linux/macOS correctly recognize
        // canonical names such as Cargo.toml, Gemfile, CMakeLists.txt and Package.swift.
        try (DirectoryStream<Path> stream = Files.newDirectoryStream(dir)) {
            for (Path p : stream) {
                String n = p.getFileName().toString().toLowerCase(Locale.ROOT);
                if (PROJECT_MARKERS.contains(n)) return true;
                if (n.equals(".git") && Files.isDirectory(p)) return true;
                if (Files.isRegularFile(p) && (n.endsWith(".sln") || n.endsWith(".csproj") || n.endsWith(".fsproj") || n.endsWith(".vbproj"))) return true;
            }
        } catch (Exception ignored) { }
        return false;
    }

    private boolean isStandaloneDiagnostic(Path file) {
        String name = file.getFileName().toString().toLowerCase(Locale.ROOT);
        int dot = name.lastIndexOf('.');
        return dot >= 0 && DIAGNOSTIC_EXTENSIONS.contains(name.substring(dot + 1));
    }

    private boolean isLikelyProjectFile(Path file) {
        String name = file.getFileName().toString().toLowerCase(Locale.ROOT);
        if (PROJECT_MARKERS.contains(name)) return true;
        int dot = name.lastIndexOf('.');
        if (dot < 0) return false;
        return Set.of("java","kt","kts","groovy","scala","js","jsx","ts","tsx","py","rb","php","go","rs","c","cc","cpp","cxx","h","hpp","cs","fs","swift","dart","vue","svelte","xml","json","yaml","yml","toml","properties","gradle","sql","graphql","proto","sh","ps1","bat","cmd","tf","hcl").contains(name.substring(dot + 1));
    }

    private Path canonical(Path path) {
        if (path == null) return null;
        try { return path.toRealPath(); }
        catch (Exception ignored) { return path.toAbsolutePath().normalize(); }
    }

    private String aliasBase(Path path, int fallback) {
        Path namePath = Files.isDirectory(path) ? path.getFileName() : path.getFileName();
        String name = namePath == null ? "resource" + fallback : namePath.toString();
        int dot = name.lastIndexOf('.');
        if (!Files.isDirectory(path) && dot > 0) name = name.substring(0, dot);
        String alias = name.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9_-]+", "-").replaceAll("^-+|-+$", "");
        return alias.isBlank() ? "resource" + fallback : alias;
    }

    private String uniqueAlias(String base, Set<String> used) {
        String alias = base;
        int i = 2;
        while (used.contains(alias)) alias = base + "-" + i++;
        return alias;
    }

    private String findAliasForRoot(Map<String, ResolvedResource> resources, Path root) {
        for (Map.Entry<String, ResolvedResource> e : resources.entrySet()) {
            if (e.getValue().root().equals(root)) return e.getKey();
        }
        return null;
    }

    private String resourceIdentity(Path root, Path focus) {
        return root.toAbsolutePath().normalize() + "|" + (focus == null ? "" : focus.normalize());
    }

    public enum ResourceKind { PROJECT, DIRECTORY, FILE }

    public record ResolvedResource(String alias, Path root, Path focus, ResourceKind kind,
                                   boolean writable, boolean primary, String reason) {
        public ResolvedResource withFocus(Path next) {
            return new ResolvedResource(alias, root, next, kind, writable, primary, reason);
        }
    }

    public record Resolution(List<ResolvedResource> resources) {
        public int externalCount() { return (int) resources.stream().filter(r -> !r.primary()).count(); }
        public String catalogText() {
            StringBuilder out = new StringBuilder();
            for (ResolvedResource r : resources) {
                out.append('@').append(r.alias()).append(" -> ").append(r.root());
                if (r.focus() != null) out.append(" (focus: ").append(r.focus().toString().replace('\\','/')).append(')');
                out.append(" [").append(r.kind().name().toLowerCase(Locale.ROOT)).append(", ")
                        .append(r.writable() ? "read/write" : "read-only").append(']');
                if (!r.reason().isBlank()) out.append(" — ").append(r.reason());
                out.append('\n');
            }
            return out.toString().stripTrailing();
        }
    }
}
