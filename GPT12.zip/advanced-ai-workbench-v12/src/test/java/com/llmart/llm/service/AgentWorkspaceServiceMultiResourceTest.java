package com.llmart.llm.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.llmart.llm.entity.ProjectWorkspaceEntity;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Files;
import java.nio.file.Path;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class AgentWorkspaceServiceMultiResourceTest {

    @TempDir
    Path temp;

    @Test
    void supportsWritableSecondaryProjectReadOnlyReferenceAndDiagnosticFile() throws Exception {
        Path primary = createMavenProject("primary", "class Main {}\n");
        Path secondary = createMavenProject("secondary", "class Secondary { int value = 1; }\n");
        Path reference = createMavenProject("reference", "class Reference { int value = 7; }\n");
        Path log = temp.resolve("failure.log");
        Files.writeString(log, "Compilation failed in Secondary.java\n");

        ProjectService projects = mock(ProjectService.class);
        ProjectWorkspaceEntity entity = mock(ProjectWorkspaceEntity.class);
        when(projects.require("p1")).thenReturn(entity);
        when(entity.hasLocalPath()).thenReturn(true);
        when(entity.getLocalPath()).thenReturn(primary.toString());

        AgentWorkspaceService service = new AgentWorkspaceService(projects, new ObjectMapper(), new PromptResourceResolver());
        String prompt = "Main project: \"" + primary + "\"\n" +
                "Secondary project: \"" + secondary + "\"\n" +
                "Working reference: \"" + reference + "\"\n" +
                "Issue log: \"" + log + "\"";

        AgentWorkspaceService.Workspace ws = service.prepare("p1", prompt);
        assertEquals(4, ws.resources().size());
        assertTrue(ws.resources().get("secondary").writable());
        assertFalse(ws.resources().get("reference").writable());
        assertFalse(ws.resources().get("failure").writable());

        assertTrue(service.resourceRead(ws, "failure", "", 1, 20).contains("Compilation failed"));
        service.resourceEdit(ws, "secondary", "src/App.java", "value = 1", "value = 2", false);
        assertTrue(Files.readString(secondary.resolve("src/App.java")).contains("value = 2"));

        service.resourceCopy(ws, "reference", "src/App.java", "secondary", "src/ReferenceCopy.java", false);
        assertTrue(Files.exists(secondary.resolve("src/ReferenceCopy.java")));
        assertThrows(SecurityException.class,
                () -> service.resourceWrite(ws, "reference", "src/ShouldNotWrite.java", "class X {}"));

        String status = service.workspaceStatus(ws);
        assertTrue(status.contains("@secondary/src/App.java"));
        assertTrue(status.contains("@secondary/src/ReferenceCopy.java"));
    }

    @Test
    void projectRootDetectionIsCaseSafeAndRecognizesGitRoot() throws Exception {
        Path rust = temp.resolve("rust-project");
        Files.createDirectories(rust.resolve("src"));
        Files.writeString(rust.resolve("Cargo.toml"), "[package]\nname='demo'\n");
        Path source = rust.resolve("src/main.rs");
        Files.writeString(source, "fn main() {}\n");

        PromptResourceResolver resolver = new PromptResourceResolver();
        assertEquals(rust.toRealPath(), resolver.primaryProjectPath("Fix: \"" + source + "\"").orElseThrow());

        Path gitOnly = temp.resolve("git-only");
        Files.createDirectories(gitOnly.resolve(".git"));
        Files.createDirectories(gitOnly.resolve("src"));
        Path genericSource = gitOnly.resolve("src/tool.py");
        Files.writeString(genericSource, "print('x')\n");
        assertEquals(gitOnly.toRealPath(), resolver.primaryProjectPath("Project file: \"" + genericSource + "\"").orElseThrow());
    }

    private Path createMavenProject(String name, String source) throws Exception {
        Path project = temp.resolve(name);
        Files.createDirectories(project.resolve("src"));
        Files.writeString(project.resolve("pom.xml"), "<project/>\n");
        Files.writeString(project.resolve("src/App.java"), source);
        return project;
    }
}
