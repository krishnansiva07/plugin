package com.llmart.llm.service;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Files;
import java.nio.file.Path;

import static org.junit.jupiter.api.Assertions.*;

class PromptResourceResolverTest {

    @TempDir
    Path temp;

    @Test
    void resolvesPrimaryProjectAndStandaloneIssueFile() throws Exception {
        Path project = temp.resolve("main project");
        Files.createDirectories(project.resolve("src"));
        Files.writeString(project.resolve("pom.xml"), "<project/>\n");
        Path source = project.resolve("src/App.java");
        Files.writeString(source, "class App {}\n");
        Path log = temp.resolve("jenkins-error.log");
        Files.writeString(log, "Compilation failed\n");

        PromptResourceResolver resolver = new PromptResourceResolver();
        String prompt = "Project: \"" + project + "\"\nIssue log: \"" + log + "\"";

        assertEquals(project.toRealPath(), resolver.primaryProjectPath(prompt).orElseThrow());
        var resolution = resolver.resolve(prompt, project);
        assertEquals(2, resolution.resources().size());
        var issue = resolution.resources().stream().filter(r -> !r.primary()).findFirst().orElseThrow();
        assertEquals(PromptResourceResolver.ResourceKind.FILE, issue.kind());
        assertFalse(issue.writable());
        assertEquals(log.toRealPath(), issue.root());
    }

    @Test
    void resolvesSecondProjectAsWritableResource() throws Exception {
        Path frontend = temp.resolve("frontend");
        Path backend = temp.resolve("backend");
        Files.createDirectories(frontend);
        Files.createDirectories(backend);
        Files.writeString(frontend.resolve("package.json"), "{}\n");
        Files.writeString(backend.resolve("pom.xml"), "<project/>\n");

        PromptResourceResolver resolver = new PromptResourceResolver();
        String prompt = "Frontend: \"" + frontend + "\"\nBackend: \"" + backend + "\"\nFix both projects";
        var resolution = resolver.resolve(prompt, frontend);

        var secondary = resolution.resources().stream().filter(r -> !r.primary()).findFirst().orElseThrow();
        assertEquals(backend.toRealPath(), secondary.root());
        assertEquals(PromptResourceResolver.ResourceKind.PROJECT, secondary.kind());
        assertTrue(secondary.writable());
    }

    @Test
    void filePathInfersOwningProjectAndFocusedFile() throws Exception {
        Path project = temp.resolve("service");
        Path source = project.resolve("src/main/java/example/App.java");
        Files.createDirectories(source.getParent());
        Files.writeString(project.resolve("pom.xml"), "<project/>\n");
        Files.writeString(source, "class App {}\n");
        Path primary = temp.resolve("primary");
        Files.createDirectories(primary);
        Files.writeString(primary.resolve("package.json"), "{}\n");

        PromptResourceResolver resolver = new PromptResourceResolver();
        var resolution = resolver.resolve("Issue file: \"" + source + "\"", primary);
        var resource = resolution.resources().stream().filter(r -> !r.primary()).findFirst().orElseThrow();

        assertEquals(project.toRealPath(), resource.root());
        assertEquals(Path.of("src/main/java/example/App.java"), resource.focus());
        assertTrue(resource.writable());
    }

    @Test
    void arbitraryExplicitDirectoryCanBeWritableEvenWithoutBuildDescriptor() throws Exception {
        Path primary = temp.resolve("primary");
        Path other = temp.resolve("plain-folder");
        Files.createDirectories(primary);
        Files.createDirectories(other);

        PromptResourceResolver resolver = new PromptResourceResolver();
        var resolution = resolver.resolve("Other path: \"" + other + "\"", primary);
        var resource = resolution.resources().stream().filter(r -> !r.primary()).findFirst().orElseThrow();

        assertEquals(PromptResourceResolver.ResourceKind.DIRECTORY, resource.kind());
        assertTrue(resource.writable());
    }

    @Test
    void ignoresNonexistentAndUrlCandidates() {
        PromptResourceResolver resolver = new PromptResourceResolver();
        String prompt = "Check https://example.com/a/b and /definitely/not/here/project";
        assertTrue(resolver.explicitExistingPaths(prompt).isEmpty());
    }
    @Test
    void prefersBrokenProjectOverEarlierReferenceAndKeepsReferenceReadOnly() throws Exception {
        Path reference = temp.resolve("working-reference");
        Path broken = temp.resolve("broken-project");
        Files.createDirectories(reference);
        Files.createDirectories(broken);
        Files.writeString(reference.resolve("pom.xml"), "<project/>\n");
        Files.writeString(broken.resolve("pom.xml"), "<project/>\n");

        PromptResourceResolver resolver = new PromptResourceResolver();
        String prompt = "Reference project: \"" + reference + "\"\nBroken project: \"" + broken + "\"";

        assertEquals(broken.toRealPath(), resolver.primaryProjectPath(prompt).orElseThrow());
        var resolution = resolver.resolve(prompt, broken);
        var ref = resolution.resources().stream().filter(r -> !r.primary()).findFirst().orElseThrow();
        assertEquals(reference.toRealPath(), ref.root());
        assertFalse(ref.writable());
    }

}
