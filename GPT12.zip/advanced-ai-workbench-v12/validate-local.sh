#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

echo "[1/5] Java"
java -version

echo "[2/5] Frontend syntax"
if command -v node >/dev/null 2>&1; then
  node --check src/main/resources/static/app.js
  node --check src/main/resources/static/markdown.js
else
  echo "Node is not installed; skipping JavaScript syntax checks."
fi

echo "[3/5] Maven availability/bootstrap"
./mvnw -version

echo "[4/5] Maven tests"
./mvnw clean test

echo "[5/5] Package"
./mvnw package -DskipTests

echo "Validation complete. JAR: target/advanced-ai-chat-2.2.0-SNAPSHOT.jar"
