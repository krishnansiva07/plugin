#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
JAR="target/advanced-ai-chat-2.2.0-SNAPSHOT.jar"
if [ ! -f "$JAR" ]; then
  echo "JAR not found. Building V12..."
  ./mvnw clean package
fi
exec java -jar "$JAR"
