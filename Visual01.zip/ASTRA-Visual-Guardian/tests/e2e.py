#!/usr/bin/env python3
import io,json,os,re,subprocess,tempfile,threading,time,urllib.request,urllib.error,zipfile,sys,socket
from pathlib import Path
from http.server import ThreadingHTTPServer,BaseHTTPRequestHandler
ROOT=Path(__file__).resolve().parents[1]; JAR=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else ROOT/'build/visual-guardian.jar'
passed=[]; model_calls=[]; mutation_calls=[]
def check(name,value):
    assert value,name
    passed.append(name);print('PASS',name,flush=True)
class Site(BaseHTTPRequestHandler):
    changed=False
    def log_message(self,*a):pass
    def send(self,body,kind='text/html',code=200):
        if not isinstance(body,bytes):body=body.encode()
        self.send_response(code);self.send_header('Content-Type',kind);self.send_header('Content-Length',str(len(body)));self.end_headers();self.wfile.write(body)
    def do_GET(self):
        if self.path=='/v1/models':return self.send(json.dumps({'data':[{'id':'user-agent'},{'id':'user-vision'},{'id':'user-reviewer'}]}),'application/json')
        if self.path=='/login':return self.send('<html><title>Sign in</title><form action="/home" method="get"><input name="username"><input type="password" name="password"><button>Sign in</button></form></html>')
        if self.path=='/home':return self.send('<html><title>Authenticated</title><main><h1>Authenticated home</h1><a href="/home">Home</a></main></html>')
        if self.path.startswith('/delete'):mutation_calls.append(self.path);return self.send('bad')
        if self.path not in ['/','/details']:return self.send('not found',code=404)
        detail=self.path=='/details';title='Details' if detail else 'Dashboard';links='<a href="/details">Details</a>' if not detail else ''
        extra='' if self.changed else '<button id="view" onclick="document.getElementById(\'viewpanel\').hidden=false">View report</button><div id="viewpanel" hidden><h2>Report preview</h2></div>'
        self.send(f'''<!doctype html><html><title>{title}</title><style>body{{font:18px Arial;background:#fff;margin:24px}}main{{padding:20px;background:{'#e1ebfd' if self.changed else '#f2f4f8'};width:700px}}button,a{{padding:6px;margin:4px}}</style><main><h1>{title}</h1>{links}<button id="filter" onclick="document.getElementById('panel').hidden=!document.getElementById('panel').hidden">Filter</button><div id="panel" hidden><h2>Filter panel</h2></div>{extra}<a href="/delete">Delete record</a><span class="dynamic">{time.time()}</span><input type="password" style="display:none" value="secret"></main></html>''')
    def do_POST(self):
        if self.path=='/v1/chat/completions':
            req=json.loads(self.rfile.read(int(self.headers['Content-Length'])));model_calls.append(req);model=req['model'];content='{"order":[1,0]}' if model=='user-agent' else 'Observable change; verify impact.'
            return self.send(json.dumps({'choices':[{'message':{'content':content}}],'usage':{'total_tokens':25}}),'application/json')
        mutation_calls.append(self.path);self.send('unexpected',code=403)
class Changed(Site):changed=True
def serve(cls):
    s=ThreadingHTTPServer(('127.0.0.1',0),cls);threading.Thread(target=s.serve_forever,daemon=True).start();return s,'http://127.0.0.1:'+str(s.server_port)
old,oldurl=serve(Site);new,newurl=serve(Changed)
with tempfile.TemporaryDirectory() as td:
    data=Path(td)/'data';log=Path(td)/'server.log';sock=socket.socket();sock.bind(('127.0.0.1',0));port=sock.getsockname()[1];sock.close();base=f'http://127.0.0.1:{port}';env=dict(os.environ)
    if hasattr(os,'geteuid') and os.geteuid()==0:env['GUARDIAN_TEST_NO_SANDBOX']='1'
    logf=log.open('w');p=subprocess.Popen(['java','-jar',str(JAR),'--port',str(port),'--data',str(data)],stdout=logf,stderr=subprocess.STDOUT,env=env)
    try:
        for _ in range(80):
            try:html=urllib.request.urlopen(base,timeout=1).read().decode();break
            except Exception:time.sleep(.2)
        else:raise RuntimeError('server failed to start')
        token=re.search('name="guardian-token" content="([^"]+)"',html).group(1)
        check('executable JAR serves local UI','ASTRA Visual Guardian' in html)
        def api(path,body=None,raw=False,expected=200,auth=True):
            headers={'X-Guardian-Token':token} if auth else {};payload=None
            if body is not None:
                payload=body if isinstance(body,bytes) else json.dumps(body).encode();headers['Content-Type']='application/zip' if isinstance(body,bytes) else 'application/json'
            req=urllib.request.Request(base+'/api/'+path,data=payload,headers=headers)
            try:res=urllib.request.urlopen(req,timeout=35);code=res.status;out=res.read()
            except urllib.error.HTTPError as e:code=e.code;out=e.read()
            assert code==expected,(path,code,out[:500]);return out if raw else json.loads(out)
        check('unauthenticated API rejected',api('suites',expected=403,auth=False)['error'])
        roles={r:{'endpoint':oldurl+'/v1','model':'user-'+r,'key':'fixture-key','timeout':8} for r in ['agent','vision','reviewer']};api('models',roles)
        check('user-defined model discovery',len(api('models/discover',{'role':'agent'})['models'])==3)
        check('Vision probe sends actual image',api('models/test',{'role':'vision'})['text'] and isinstance(model_calls[-1]['messages'][1]['content'],list))
        check('API keys not returned or persisted','fixture-key' not in (data/'models.json').read_text() and 'fixture-key' not in str(api('models')))
        cfg={'headless':True,'browser':os.environ.get('GUARDIAN_TEST_BROWSER','/usr/bin/chromium'),'width':800,'height':600,'settleMs':100,'maxStates':25,'maxDepth':3,'maxActions':70,'authSeconds':20,'masks':['.dynamic'],'pixelTolerance':0.005,'captureConsent':True,'allowModelData':True}
        suite=api('suites',{'name':'Migration fixture','url':oldurl,'config':cfg});sid=suite['id']
        def run(mode,target,**kwargs):return api('runs',dict(suiteId=sid,mode=mode,target=target,config=cfg,**kwargs))['id']
        def wait(rid,timeout=120):
            until=time.time()+timeout
            while time.time()<until:
                r=api('runs/'+rid)
                if not r['active']:return r
                time.sleep(.35)
            raise RuntimeError('timeout '+str(r)[:1400])
        rid=run('CAPTURE',oldurl);cap=wait(rid);print('CAPTURE',cap['status'],len(cap['states']),cap['message'],cap['issues'][:2],flush=True)
        check('autonomous capture via configured browser protocol',cap['status']=='COMPLETED' and len(cap['states'])>=4)
        check('read-only mutation action skipped',not mutation_calls and any('Delete record'==x.get('label') for x in cap['skipped']))
        check('selected agent model ranks eligible actions',cap['modelCalls']>0 and any(x['model']=='user-agent' for x in model_calls))
        api('approve',{'id':rid});baseline=api('runs/'+rid+'/baseline.zip',raw=True)
        check('approved portable baseline contains checksums','manifest.json' in zipfile.ZipFile(io.BytesIO(baseline)).namelist())
        imported=api('import',baseline);check('baseline import creates independent suite',imported['suite']['id']!=sid and len(imported['run']['states'])==len(cap['states']))
        tampered=io.BytesIO();z=zipfile.ZipFile(io.BytesIO(baseline))
        with zipfile.ZipFile(tampered,'w') as out:
            for name in z.namelist():out.writestr(name,z.read(name)+(b' ' if name=='suite.json' else b''))
        check('tampered ZIP rejected','Checksum' in api('import',tampered.getvalue(),expected=400)['error'])
        bad=io.BytesIO()
        with zipfile.ZipFile(bad,'w') as out:out.writestr('../escape','x')
        check('ZIP traversal rejected','unsafe' in api('import',bad.getvalue(),expected=400)['error'])
        sameid=run('REPLAY',oldurl,referenceId=rid);same=wait(sameid);print('SAME',same['status'],[(x['status'],x.get('reason')) for x in same['results']],flush=True)
        check('identical application passes captured states',same['status']=='COMPLETED' and all(x['status']=='PASSED' for x in same['results']))
        changedid=run('REPLAY',newurl,referenceId=rid);changed=wait(changedid);print('CHANGED',changed['status'],[(x['status'],x.get('reason')) for x in changed['results']],flush=True)
        check('migration regression detected',any(x['status']=='FAILED' for x in changed['results']))
        check('before and after screenshots sent to selected Vision model',any(x.get('visionStatus')=='COMPLETE' for x in changed['results']) and any(x['model']=='user-vision' and len(x['messages'][1]['content'])==3 for x in model_calls))
        check('reviewer model used',any(x.get('review') for x in changed['results']))
        check('immutable baseline retained',api('runs/'+rid)['states']==cap['states'])
        failed=run('REPLAY',oldurl,referenceId=rid,parentId=changedid,selection='FAILED');rerun=wait(failed)
        check('failed-only rerun linked and independent',rerun['parentId']==changedid and len(rerun['results'])==sum(x['status']=='FAILED' for x in changed['results']) and all(x['status']=='PASSED' for x in rerun['results']))
        comparison=api('compare',{'left':sameid,'right':changedid});check('historical comparison detects differences',any(x['status']=='FAILED' for x in comparison['results']))
        compzip=api('runs/'+comparison['id']+'/execution.zip',raw=True); imported_comp=api('import',compzip);check('offline comparison portable evidence',imported_comp['run']['status']=='IMPORTED' and 'reference-images/' in ' '.join(zipfile.ZipFile(io.BytesIO(compzip)).namelist()))
        html=api('runs/'+changedid+'/report.html',raw=True);xlsx=api('runs/'+changedid+'/report.xlsx',raw=True)
        check('HTML contains visual evidence and verdict',b'data:image/png;base64' in html and b'FAIL' in html)
        import xml.etree.ElementTree as ET
        with zipfile.ZipFile(io.BytesIO(xlsx)) as z:
            for n in z.namelist():ET.fromstring(z.read(n))
        check('Excel report valid OOXML XML',True)
        execution=api('runs/'+changedid+'/execution.zip',raw=True);imported_execution=api('import',execution);check('execution export and import',imported_execution['run']['status']=='IMPORTED' and 'reference-images/' in ' '.join(zipfile.ZipFile(io.BytesIO(execution)).namelist()))
        check('failed path retains last reachable evidence',any(x.get('imageKind')=='LAST_REACHABLE_STATE' for x in changed['results']))
        manualcfg=dict(cfg,autoAuth=False,allowModelData=False,headless=True,authSeconds=30,maxDepth=1)
        authsuite=api('suites',{'name':'Authentication fixture','url':oldurl+'/login','config':manualcfg})
        authid=api('runs',{'suiteId':authsuite['id'],'mode':'CAPTURE','target':oldurl+'/login','config':manualcfg})['id']
        for _ in range(80):
            auth=api('runs/'+authid)
            if auth['status']=='AWAITING_INPUT':break
            time.sleep(.2)
        check('login waits without capturing authentication screen',auth['status']=='AWAITING_INPUT' and not auth['states'])
        profile=next(x for x in data.glob('browser-*') if (x/'DevToolsActivePort').exists());dp=(profile/'DevToolsActivePort').read_text().splitlines()[0]
        if os.environ.get('GUARDIAN_TEST_MOCK')=='1':
            import urllib.parse
            urllib.request.urlopen('http://127.0.0.1:'+dp+'/mock/home?url='+urllib.parse.quote(oldurl+'/home',safe='')).read()
            api('runs/command',{'id':authid,'command':'continue'});auth=wait(authid)
        else:
            from playwright.sync_api import sync_playwright
            with sync_playwright() as pw:
                browser=pw.chromium.connect_over_cdp('http://127.0.0.1:'+dp);page=browser.contexts[0].pages[0];page.goto(oldurl+'/home');api('runs/command',{'id':authid,'command':'continue'});auth=wait(authid)
        check('manual handover resumes same browser',auth['status']=='COMPLETED' and all(x['route']=='/home' for x in auth['states']))
        stopcfg=dict(cfg,autoAuth=False,allowModelData=False,authSeconds=30)
        stopid=api('runs',{'suiteId':sid,'mode':'CAPTURE','target':oldurl,'config':stopcfg})['id']
        for _ in range(60):
            ss=api('runs/'+stopid)
            if ss['status']=='AWAITING_INPUT':break
            time.sleep(.2)
        api('runs/command',{'id':stopid,'command':'stop'});stopped=wait(stopid);check('stopped run retains pending work',stopped['status']=='STOPPED' and stopped['queue'])
        api('runs/resume',{'id':stopid})
        for _ in range(60):
            ss=api('runs/'+stopid)
            if ss['status']=='AWAITING_INPUT':break
            time.sleep(.2)
        api('runs/command',{'id':stopid,'command':'continue'});resumed=wait(stopid);check('resume same run ID and completes queue',resumed['id']==stopid and resumed['status']=='COMPLETED')
        print('TOTAL',len(passed),'checks passed',flush=True)
    finally:
        p.terminate()
        try:p.wait(timeout=12)
        except subprocess.TimeoutExpired:p.kill()
        logf.close();print(log.read_text(),flush=True)
