# V20 fixes

## User XPath execution order
- Plain English remains the action definition.
- An XPath included in the same step is attempted first.
- The first visible XPath match is selected.
- Current field/selection state is checked before duplicate fill/select actions.
- If the expected value is already present, the step passes as `already satisfied` without invoking healing.
- If XPath fails, deterministic framework healing is attempted for supported complex controls before LLM healing.
- Technical logs record locator source, XPath outcome, fallback use, final strategy, and whether LLM healing was used.

## Technical logs navigation
- Technical logs and execution report always open in a separate tab.
- The framework home page is never redirected or replaced.
