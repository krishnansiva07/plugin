# V10 Responsible Fix Notes

This release fixes the observed false pass on the `New Search` hover-and-click step.

1. Intent classification scans the complete instruction and recognizes HOVER and COMPOSITE operations.
2. HOVER, COMPOSITE, CLICK, SELECT, FILL and OTHER action steps require DOM/text/URL or screenshot evidence.
3. An MCP success response without a visible state change is treated as failure and may enter self-healing.
4. MCP timeout values below one second, including `0`, are replaced with 15000 ms.
5. Hover/mouse tools are recognized as real action tools.
6. The LLM planner is explicitly instructed to preserve exact labels such as `New Search` and generate ordered menu interactions.
7. Downstream steps are skipped after a failed state-changing action to avoid misleading secondary failures.
