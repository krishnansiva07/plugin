# V12 Resilient Click Update

## Changes

- Removed the descriptive sentence shown below the run ID/status on the UI.
- Increased click recovery attempts while keeping retries bounded.
- Treats click timeout, pointer interception, obscured elements, detached elements and covered elements as recoverable interaction failures.
- Performs semantic DOM recovery immediately after an intercepted Vibium pointer click, while transient hover menus are still visible.
- Preserves closed-loop post-action validation. A recovered click is not treated as passed unless the page/DOM/text/URL or screenshot provides evidence of state change.
- Existing failed-test selection and rerun workflow remains available.

## Recommended Excel instruction

`Click NEW-IP capsule | Click Search Icon | Find Menu Item "New search" | Click Menu Item "New search" | Perform Search | Verify Message text available | Verify Payment text available | Verify Transaction text available`

No automation framework can guarantee that every action will always succeed when the application is unavailable, the element is disabled, permissions differ, or the expected UI is not rendered. V12 is designed to prevent failures caused only by normal locator ambiguity, overlays, child-element interception, hover menus and transient click timing.
