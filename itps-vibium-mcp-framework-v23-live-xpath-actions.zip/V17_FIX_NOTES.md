# V17 – Custom Dropdown and Row Action Area Fix

## Corrections

1. Added a deterministic Angular/ng-select handler for instructions such as:
   - `Select "BCEF" from Perimeter dropdown`
   - `Choose BCEF in Perimeter field`

   The handler locates the field through its visible label and DOM relationship rather than requiring an XPath. It opens the custom dropdown, filters options when an input exists, selects the exact visible option, and confirms that the value was applied.

2. Added a deterministic first-row action-area handler for:
   - `Click the white action stripe in the first visible data row`
   - `Click action area of first row`

   The handler locates the first real data row, scores likely action/menu triggers, performs a pointer-event click at the actual hit-tested location, and verifies that the menu containing `See Track & Trace` or `See Transaction` opens.

3. Retains all V14–V16 corrections: verification fallback, UI polling/runtime safety, exact menu-click healing, atomic action stopping, rerun selected, reporting and screenshots.

## Recommended Excel steps

```text
Select "BCEF" from Perimeter dropdown | Click Search | Click the white action stripe in the first visible data row | Verify "See Track & Trace" menu is visible | Verify "See Transaction" menu is visible
```

To open a menu item:

```text
Click the white action stripe in the first visible data row | Click menu item "See Transaction"
```
