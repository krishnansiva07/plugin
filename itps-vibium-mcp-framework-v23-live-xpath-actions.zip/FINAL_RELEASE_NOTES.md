# ITPS VIBIUM Framework V9 — Final Release

## Core execution contract
- All browser interaction is executed through Vibium MCP tools.
- No Selenium or Playwright browser fallback is included.
- Natural-language actions are planned from Vibium page map plus the unified DOM page model.

## Deep DOM intelligence
The page model captures actionable controls, all visible text/content, labels, values, tables, SVG/icon metadata, clickable ancestors, context, coordinates, visibility and generated unique selectors. Same-origin frames and open shadow roots are included where the browser permits access.

## Failure handling and self-healing
- UI setting: **Failure healing attempts** = 0, 1 or 2.
- On an action or validation failure, V9 captures a fresh page model, ranked candidates, screenshot, previous plan and MCP error.
- The LLM must return a materially different Vibium MCP strategy with a confidence score.
- Healing below the configured confidence threshold is rejected.
- A successful healed step is reported as `PASSED_HEALED`; otherwise it remains `FAILED`.

## Reports
- Consolidated HTML report
- Technical HTML report with healing history
- Excel report with healing details
- JSON report
- Screenshots ZIP
- MCP tools/transcript/process diagnostics
