# V16 Complete Fix

This version combines the V14 verification corrections and V16 UI runtime corrections, and fixes the stale-action sequence reported after clicking **New search**.

## Root cause fixed

The planner could return a chain such as `browser_find(New search) -> click(New search) -> browser_find/click(New search)` for one atomic instruction. After the first click navigated successfully, the remaining stale call searched for **New search** on the destination page and timed out. In addition, `browser_find` was incorrectly treated as an executed state-changing action.

## Corrections

- `browser_find`, locate, visible, enabled, exists and count tools are now observation/no-op tools.
- One atomic instruction stops immediately after its first successful state-changing action.
- Composite instructions containing `|`, `then`, `and then`, `followed by`, or `;` can still execute multiple actions.
- UI settling is performed after a successful click/type/select/navigation.
- Existing closed-loop DOM/text/URL/screenshot validation remains enabled.
- V14 assertion handling and V16 UI polling/cache/runtime fixes are retained.
