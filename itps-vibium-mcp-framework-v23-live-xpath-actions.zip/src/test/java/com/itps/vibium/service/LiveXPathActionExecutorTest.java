package com.itps.vibium.service;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

class LiveXPathActionExecutorTest {
    @Test
    void convertsCurlyQuotesToXpathSafeQuotes() {
        assertEquals("Click using xpath=\"//*[text()='BCEF']\"",
                LiveXPathActionExecutor.normalizeSmartQuotes(
                        "Click using xpath=“//*[text()=‘BCEF’]”"));
    }
}
