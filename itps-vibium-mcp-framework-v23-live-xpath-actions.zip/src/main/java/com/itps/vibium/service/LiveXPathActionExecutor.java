package com.itps.vibium.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.itps.vibium.model.McpTool;
import com.itps.vibium.model.RunConfig;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Executes an explicit user XPath without asking the LLM to choose a locator.
 *
 * <p>The XPath is resolved against the live DOM and the action is performed in the same
 * browser_evaluate call. This removes the Angular race where a result node is located,
 * Angular replaces it, and a later click targets a stale marker.</p>
 */
final class LiveXPathActionExecutor {
    private static final Pattern QUOTED = Pattern.compile("[\\\"']([^\\\"']+)[\\\"']");
    private final ObjectMapper mapper;

    LiveXPathActionExecutor(ObjectMapper mapper) {
        this.mapper = Objects.requireNonNull(mapper, "mapper");
    }

    Execution execute(McpClient mcp, McpToolCatalog catalog, String instruction,
                      String suppliedXPath, RunConfig config) throws Exception {
        McpTool evaluate = catalog.evaluateTool().orElseThrow(() ->
                new IllegalStateException("User XPath priority requires Vibium browser_evaluate."));

        String normalizedInstruction = normalizeSmartQuotes(instruction);
        String xpath = normalizeSmartQuotes(suppliedXPath).trim();
        String english = removeXPathClause(normalizedInstruction);
        String action = classifyAction(english);
        String value = extractValue(english, action);
        int timeoutMs = Math.max(5_000, Math.max(1, config.getStepTimeoutSeconds()) * 1_000);

        ObjectNode audit = mapper.createObjectNode();
        audit.put("strategy", "USER_XPATH_LIVE_PRIORITY");
        audit.put("xpath", xpath);
        audit.put("action", action);
        audit.put("value", value);
        audit.put("timeoutMs", timeoutMs);
        audit.put("llmUsed", false);
        audit.put("resolveAndActSameBrowserCall", true);

        String script = liveXPathScript(xpath, action, value, timeoutMs);
        Map<String, Object> args = evaluateArgs(evaluate, script);
        JsonNode raw = mcp.callTool(evaluate.getName(), args);
        assertToolSuccess(evaluate.getName(), raw);
        JsonNode result = unwrapJsonString(raw);
        audit.set("result", result);

        if (!result.path("ok").asBoolean(false)) {
            throw new IllegalStateException("USER_XPATH_LIVE_ACTION_FAILED: " + compact(result.toString(), 5_000));
        }
        if ("click".equals(action) && result.path("optionLike").asBoolean(false)
                && !result.path("interactionConfirmed").asBoolean(false)) {
            throw new IllegalStateException("XPath found the dropdown result and dispatched a click, but Angular selection was not confirmed. Details="
                    + compact(result.toString(), 5_000));
        }

        ObjectNode actionJson = mapper.createObjectNode();
        actionJson.put("type", "USER_XPATH_LIVE_ACTION");
        actionJson.put("action", action);
        actionJson.put("xpath", xpath);
        actionJson.put("value", value);

        String evidence;
        if ("fill".equals(action)) {
            evidence = "User XPath was used as first priority. The live element was filled and input/change events were dispatched. Final value='"
                    + result.path("finalValue").asText(value) + "'.";
        } else if ("verify".equals(action)) {
            evidence = "User XPath was used as first priority and resolved a visible live element. No LLM locator was used.";
        } else if (result.path("optionLike").asBoolean(false)) {
            evidence = "User XPath was used as first priority. The current Angular option node was resolved and clicked in one browser operation; confirmation="
                    + result.path("confirmationStrategy").asText("option-state") + ".";
        } else {
            evidence = "User XPath was used as first priority and the live element was clicked in the same browser operation. No LLM locator was used.";
        }

        return new Execution("USER_XPATH_LIVE_PRIORITY", actionJson.toString(), evaluate.getName(),
                mapper.writeValueAsString(args), compact(result.toString(), 20_000), evidence, audit);
    }

    private String liveXPathScript(String xpath, String action, String value, int timeoutMs) {
        return """
                (async () => {
                  const xpath=%s, action=%s, value=%s, timeoutMs=%d;
                  const started=Date.now();
                  const norm=v=>String(v??'').replace(/\\s+/g,' ').trim().toLowerCase();
                  const sleep=ms=>new Promise(r=>setTimeout(r,ms));
                  const raf=()=>new Promise(r=>requestAnimationFrame(()=>r()));
                  const visible=e=>{
                    if(!e||!(e instanceof Element)||!e.isConnected)return false;
                    const r=e.getBoundingClientRect(), w=e.ownerDocument.defaultView, s=w.getComputedStyle(e);
                    return r.width>1&&r.height>1&&s.display!=='none'&&s.visibility!=='hidden'&&Number(s.opacity||1)>0;
                  };
                  const enabled=e=>!(e.disabled||e.getAttribute?.('aria-disabled')==='true'||e.classList?.contains('disabled')||e.classList?.contains('mat-mdc-option-disabled'));
                  const docs=()=>{
                    const out=[document];
                    for(let i=0;i<out.length;i++) for(const f of out[i].querySelectorAll('iframe,frame')) {
                      try{if(f.contentDocument&&!out.includes(f.contentDocument))out.push(f.contentDocument);}catch(ignore){}
                    }
                    return out;
                  };
                  const roots=d=>{
                    const out=[d];
                    for(let i=0;i<out.length;i++) for(const e of out[i].querySelectorAll?.('*')||[]) if(e.shadowRoot) out.push(e.shadowRoot);
                    return out;
                  };
                  const xpathAll=()=>{
                    const out=[];
                    for(const d of docs()) for(const root of roots(d)) {
                      try{
                        const evaluator=d.evaluate(xpath,root,null,XPathResult.ORDERED_NODE_SNAPSHOT_TYPE,null);
                        for(let i=0;i<evaluator.snapshotLength;i++){
                          const n=evaluator.snapshotItem(i);
                          const e=n instanceof Element?n:n?.parentElement;
                          if(e&&!out.includes(e))out.push(e);
                        }
                      }catch(e){return {error:e.message,nodes:out};}
                    }
                    return {nodes:out};
                  };
                  const optionSelector='[role="option"],mat-option,.mat-mdc-option,.mat-option,.ng-option,.p-dropdown-item,.p-select-option,.p-autocomplete-option,.ant-select-item-option,.select2-results__option,li[role="option"],option';
                  const interactiveSelector=optionSelector+',button,a,[role="button"],[role="menuitem"],[role="tab"],label,input,textarea,select,[contenteditable="true"]';
                  const promote=e=>{
                    if(action!=='click')return e;
                    if(e.matches?.(interactiveSelector))return e;
                    const option=e.closest?.(optionSelector); if(option)return option;
                    const interactive=e.closest?.(interactiveSelector); return interactive||e;
                  };
                  const overlaySelector='[role="listbox"],.cdk-overlay-pane,.mat-mdc-select-panel,.mat-select-panel,.ng-dropdown-panel,.p-dropdown-panel,.p-select-overlay,.p-autocomplete-panel,.ant-select-dropdown,.select2-dropdown,.dropdown-menu,[class*="dropdown-panel"]';
                  const optionLike=e=>!!e?.matches?.(optionSelector)||!!e?.closest?.(optionSelector);
                  const overlayOf=e=>e?.closest?.(overlaySelector)||null;
                  const listboxOf=e=>e?.closest?.('[role="listbox"]')||overlayOf(e);
                  const linkedControl=(e,root)=>{
                    const d=e?.ownerDocument||document;
                    const ids=[];
                    if(root?.id)ids.push(root.id);
                    const list=root?.querySelector?.('[role="listbox"][id]'); if(list?.id)ids.push(list.id);
                    for(const id of ids){
                      try{
                        const escaped=(globalThis.CSS&&CSS.escape)?CSS.escape(id):id.replace(/(["'\\\\.#:[\\]()])/g,'\\\\$1');
                        const c=d.querySelector(`[aria-controls~="${escaped}"],[aria-owns~="${escaped}"]`);
                        if(c)return c;
                      }catch(ignore){}
                    }
                    const active=d.activeElement;
                    if(active?.matches?.('[role="combobox"],input[aria-autocomplete="list"],[aria-haspopup="listbox"]'))return active;
                    return null;
                  };
                  const hitInfo=e=>{
                    const r=e.getBoundingClientRect(), x=Math.max(r.left+1,Math.min(r.right-1,r.left+r.width/2)), y=Math.max(r.top+1,Math.min(r.bottom-1,r.top+r.height/2));
                    const top=e.ownerDocument.elementFromPoint(x,y);
                    return {x,y,top,passed:!!top&&(top===e||e.contains(top))};
                  };
                  const rank=(a,b)=>{
                    const ao=optionLike(a)?0:1,bo=optionLike(b)?0:1;if(ao!==bo)return ao-bo;
                    const aa=overlayOf(a)?0:1,ba=overlayOf(b)?0:1;if(aa!==ba)return aa-ba;
                    const ah=hitInfo(a).passed?0:1,bh=hitInfo(b).passed?0:1;if(ah!==bh)return ah-bh;
                    const ar=a.getBoundingClientRect(),br=b.getBoundingClientRect();return ar.width*ar.height-br.width*br.height;
                  };
                  const resolve=()=>{
                    const x=xpathAll();
                    if(x.error)return {error:x.error,matches:x.nodes.length,candidates:[]};
                    const candidates=[...new Set(x.nodes.map(promote).filter(visible).filter(enabled))].sort(rank);
                    return {matches:x.nodes.length,candidates};
                  };
                  let last={matches:0,candidates:[]};
                  while(Date.now()-started<timeoutMs){
                    last=resolve();
                    if(last.error)return JSON.stringify({ok:false,reason:'INVALID_XPATH',xpath,error:last.error,matches:last.matches||0});
                    if(last.candidates.length){
                      // Let Angular finish one render cycle, then resolve again and act on the new live node.
                      await raf(); await raf(); await sleep(50);
                      const fresh=resolve();
                      if(fresh.error)return JSON.stringify({ok:false,reason:'INVALID_XPATH',xpath,error:fresh.error,matches:fresh.matches||0});
                      const target=fresh.candidates[0];
                      if(!target){await sleep(100);continue;}
                      target.scrollIntoView({block:'center',inline:'nearest',behavior:'instant'});
                      await raf();
                      const finalResolve=resolve();
                      const current=finalResolve.candidates[0];
                      if(!current){await sleep(100);continue;}
                      if(action==='verify'){
                        return JSON.stringify({ok:true,action,locatorSource:'USER_XPATH',xpath,matches:finalResolve.matches,visibleCandidates:finalResolve.candidates.length,tag:current.tagName,role:current.getAttribute?.('role')||'',text:(current.innerText||current.textContent||'').trim().slice(0,300)});
                      }
                      if(action==='fill'){
                        const before='value' in current?String(current.value||''):String(current.textContent||'');
                        current.focus?.({preventScroll:true});
                        if(current.isContentEditable){current.textContent=value;}
                        else if('value' in current){
                          const proto=current instanceof HTMLTextAreaElement?HTMLTextAreaElement.prototype:HTMLInputElement.prototype;
                          const setter=Object.getOwnPropertyDescriptor(proto,'value')?.set;
                          if(setter)setter.call(current,value);else current.value=value;
                        } else current.textContent=value;
                        try{current.dispatchEvent(new InputEvent('input',{bubbles:true,composed:true,inputType:'insertText',data:value}));}catch(ignore){current.dispatchEvent(new Event('input',{bubbles:true,composed:true}));}
                        current.dispatchEvent(new Event('change',{bubbles:true,composed:true}));
                        await sleep(100);
                        const finalValue='value' in current?String(current.value||''):String(current.textContent||'');
                        return JSON.stringify({ok:norm(finalValue)===norm(value),action,locatorSource:'USER_XPATH',xpath,matches:finalResolve.matches,before,finalValue,tag:current.tagName});
                      }

                      const isOption=optionLike(current);
                      const root=listboxOf(current);
                      const control=linkedControl(current,root);
                      const beforeExpanded=control?.getAttribute?.('aria-expanded')||'';
                      const rootWasVisible=visible(root);
                      const hit=hitInfo(current);
                      if(!hit.passed){
                        await sleep(100);continue;
                      }
                      current.focus?.({preventScroll:true});
                      const common={bubbles:true,cancelable:true,composed:true,view:current.ownerDocument.defaultView,clientX:hit.x,clientY:hit.y,button:0,buttons:1};
                      try{current.dispatchEvent(new PointerEvent('pointerdown',{...common,pointerId:1,pointerType:'mouse',isPrimary:true}));}catch(ignore){}
                      current.dispatchEvent(new MouseEvent('mousedown',common));
                      try{current.dispatchEvent(new PointerEvent('pointerup',{...common,buttons:0,pointerId:1,pointerType:'mouse',isPrimary:true}));}catch(ignore){}
                      current.dispatchEvent(new MouseEvent('mouseup',{...common,buttons:0}));
                      // Exactly one click event. The target is resolved immediately before this call.
                      current.click();

                      let selected=false,controlCollapsed=false,overlayClosed=false;
                      const confirmationDeadline=Date.now()+Math.min(2500,Math.max(800,timeoutMs/4));
                      while(Date.now()<confirmationDeadline){
                        selected=current.isConnected&&(current.getAttribute?.('aria-selected')==='true'||current.classList?.contains('selected')||current.classList?.contains('ng-option-selected')||current.classList?.contains('p-highlight')||current.classList?.contains('mat-mdc-option-active'));
                        controlCollapsed=!!control&&control.getAttribute?.('aria-expanded')==='false';
                        overlayClosed=!!rootWasVisible&&(!root?.isConnected||!visible(root));
                        if(!isOption||selected||controlCollapsed||overlayClosed)break;
                        await sleep(100);
                      }
                      const confirmed=!isOption||selected||controlCollapsed||overlayClosed;
                      const strategy=!isOption?'CLICK_DISPATCHED':selected?'OPTION_SELECTED_STATE':controlCollapsed?'COMBOBOX_COLLAPSED':'ACTIVE_OVERLAY_CLOSED';
                      return JSON.stringify({ok:true,clicked:true,action,locatorSource:'USER_XPATH',xpath,matches:finalResolve.matches,visibleCandidates:finalResolve.candidates.length,tag:current.tagName,role:current.getAttribute?.('role')||'',text:(current.innerText||current.textContent||'').trim().slice(0,300),hitTestPassed:true,optionLike:isOption,interactionConfirmed:confirmed,confirmationStrategy:strategy,beforeExpanded,selected,controlCollapsed,overlayClosed,targetConnectedAfterClick:current.isConnected});
                    }
                    await sleep(100);
                  }
                  return JSON.stringify({ok:false,reason:'USER_XPATH_NOT_FOUND_OR_NOT_INTERACTABLE',xpath,matches:last.matches||0,visibleCandidates:last.candidates?.length||0,elapsedMs:Date.now()-started});
                })()
                """.formatted(js(xpath), js(action), js(value), timeoutMs);
    }

    private Map<String, Object> evaluateArgs(McpTool evaluate, String script) {
        Map<String, Object> args = new LinkedHashMap<>();
        if (schemaContains(evaluate, "expression")) args.put("expression", script);
        else if (schemaContains(evaluate, "script")) args.put("script", script);
        else args.put("code", script);
        return args;
    }

    private String classifyAction(String english) {
        String lower = english == null ? "" : english.toLowerCase(Locale.ROOT);
        if (containsAny(lower, "verify", "validate", "assert", "check", "ensure")) return "verify";
        if (containsAny(lower, "type", "enter", "fill", "input")) return "fill";
        return "click";
    }

    private String extractValue(String english, String action) {
        if (!"fill".equals(action) || english == null) return "";
        Matcher quoted = QUOTED.matcher(english);
        if (quoted.find()) return quoted.group(1).trim();
        Matcher plain = Pattern.compile("(?i)\\b(?:type|enter|fill|input)\\s+(.+?)(?:\\s+(?:in|into|using|following)\\b|$)").matcher(english.trim());
        return plain.find() ? plain.group(1).trim() : "";
    }

    private String removeXPathClause(String instruction) {
        if (instruction == null) return "";
        String text = normalizeSmartQuotes(instruction);
        String lower = text.toLowerCase(Locale.ROOT);
        int marker = -1;
        for (String token : List.of("[xpath=", "xpath=", "xpath:", "using xpath", "following xpath")) {
            int i = lower.indexOf(token);
            if (i >= 0 && (marker < 0 || i < marker)) marker = i;
        }
        return marker < 0 ? text.trim() : text.substring(0, marker).trim();
    }

    static String normalizeSmartQuotes(String value) {
        if (value == null) return "";
        return value.replace('\u2018', '\'').replace('\u2019', '\'')
                .replace('\u201A', '\'').replace('\u201B', '\'')
                .replace('\u201C', '"').replace('\u201D', '"')
                .replace('\u201E', '"').replace('\u201F', '"')
                .replace('\u00AB', '"').replace('\u00BB', '"');
    }

    private JsonNode unwrapJsonString(JsonNode raw) {
        if (raw == null) return mapper.createObjectNode().put("error", "empty result");
        List<String> texts = new ArrayList<>();
        collectText(raw, texts);
        texts.sort(Comparator.comparingInt(String::length).reversed());
        for (String text : texts) {
            String trimmed = text == null ? "" : text.trim();
            if (!(trimmed.startsWith("{") || trimmed.startsWith("["))) continue;
            try { return mapper.readTree(trimmed); } catch (Exception ignored) {}
        }
        return raw;
    }

    private void collectText(JsonNode node, List<String> output) {
        if (node == null) return;
        if (node.isTextual()) output.add(node.asText());
        else if (node.isArray()) for (JsonNode child : node) collectText(child, output);
        else if (node.isObject()) node.fields().forEachRemaining(e -> collectText(e.getValue(), output));
    }

    private void assertToolSuccess(String tool, JsonNode result) {
        if (result == null || result.isMissingNode()) return;
        if (result.path("isError").asBoolean(false))
            throw new IllegalStateException("MCP tool returned isError=true for " + tool + ": " + compact(result.toString(), 2_000));
        String text = extractText(result).toLowerCase(Locale.ROOT);
        for (String fatal : List.of("invalid selector", "timed out", "timeout", "element not found", "unable to click", "exception"))
            if (text.contains(fatal)) throw new IllegalStateException("MCP tool failed for " + tool + ": " + compact(text, 2_000));
    }

    private String extractText(JsonNode node) {
        if (node == null) return "";
        if (node.isValueNode()) return node.asText("");
        StringBuilder out = new StringBuilder();
        if (node.isArray()) for (JsonNode child : node) out.append(' ').append(extractText(child));
        else node.fields().forEachRemaining(e -> out.append(' ').append(extractText(e.getValue())));
        return out.toString();
    }

    private boolean schemaContains(McpTool tool, String term) {
        return tool != null && tool.getInputSchema() != null &&
                tool.getInputSchema().toString().toLowerCase(Locale.ROOT).contains(term.toLowerCase(Locale.ROOT));
    }

    private boolean containsAny(String text, String... terms) {
        String lower = text == null ? "" : text.toLowerCase(Locale.ROOT);
        for (String term : terms) if (lower.contains(term.toLowerCase(Locale.ROOT))) return true;
        return false;
    }

    private String js(String value) {
        try { return mapper.writeValueAsString(value == null ? "" : value); }
        catch (Exception e) { return "\"\""; }
    }

    private String compact(String text, int max) {
        if (text == null) return "";
        String compact = text.replaceAll("\\s+", " ").trim();
        return compact.length() <= max ? compact : compact.substring(0, max) + "...";
    }

    record Execution(String planSource, String actionJson, String toolName, String toolArguments,
                     String mcpResult, String evidence, JsonNode audit) {}
}
