# V23 – Live XPath Priority and Angular Result Selection

## Reason for the release

Typing into the searchable Angular input was reliable, but clicking `BCEF` from the rendered result
was intermittent. The option could be located by XPath and still fail because Angular replaced the
result node before the later native click was executed.

## Framework-level corrections

1. **Absolute user XPath priority**
   - Explicit XPath steps bypass LLM locator planning.
   - Report source: `USER_XPATH_LIVE_PRIORITY`.

2. **Locate and act in one browser operation**
   - The XPath is evaluated against the live DOM.
   - Angular is allowed to complete two animation frames.
   - The XPath is evaluated again and the fresh node is clicked immediately.

3. **Smart quote normalization**
   - `“ ”`, `‘ ’`, `« »` are converted to normal XPath quotation characters.
   - This supports XPath copied through Excel, Word, Teams and Outlook.

4. **Clickable-parent promotion**
   - XPath matches such as `<span>BCEF</span>` are promoted to the closest clickable
     `[role=option]`, `mat-option`, `ng-option`, PrimeNG/Ant/Select2 option, button or menu item.

5. **Single-click guarantee**
   - Pointer/mouse down and up events are emitted once.
   - Exactly one click event is generated.
   - The framework never retries the same option after an unconfirmed dispatched click.

6. **Angular confirmation**
   - A dropdown option click is accepted only when one of these is proven:
     - option selected state;
     - associated combobox collapsed;
     - active dropdown/listbox overlay closed.
   - Element detachment alone is not treated as success.

7. **Overlay correctness**
   - The general `.cdk-overlay-container` is no longer treated as the active option panel.
   - Controlled listbox IDs and visible/highest overlay panes receive priority.

8. **Marker lifecycle**
   - Temporary `data-itps-action-id` attributes are cleaned in `finally`, including failed transactions.

9. **Runner compilation correction**
   - `deterministicHealingAfterUserXPath` now declares its checked exception correctly.

## Recommended input

The original line is supported:

```text
Click the element using following Xpath “//*[text()=‘BCEF’]”
```

The preferred exact-option form remains:

```text
Click element using xpath="//*[@role='option' and normalize-space(.)='BCEF']"
```

For a complete one-step dropdown transaction:

```text
Select "BCEF" from "MF" dropdown \
triggerXPath="//*[@id='mf-trigger']" \
optionXPath="//*[@role='option' and normalize-space(.)='BCEF']" \
verifyXPath="//*[@id='mf-selected-value']"
```

## Validation performed in the build workspace

- Java 21 syntax/type compilation of `LiveXPathActionExecutor` and `EnterpriseDropdownExecutor`
  using dependency stubs.
- Java syntax/type compilation of the modified `ItpsMcpRunner` integration using dependency stubs.
- Smart-quote and XPath-extraction parser harness.
- Node.js syntax validation of generated live-XPath and live-option JavaScript.
- ZIP integrity and SHA-256 generation.

A live run against the private Angular application was not possible in this environment.
