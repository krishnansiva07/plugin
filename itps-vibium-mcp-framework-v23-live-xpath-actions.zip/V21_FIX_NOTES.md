# V21 – Fresh DOM Action Policy and Execution Date Reporting

## Runtime changes
- Captures a fresh deep DOM/map observation before every test action or verification.
- Classifies every instruction through the existing intent engine.
- Discards cross-step element-map assumptions; each step starts from the current live page state.
- After a state-changing MCP action, waits for UI settlement and captures a second fresh DOM observation before validation.
- Technical logs record the fresh-DOM policy, action classification, and post-action observation.
- LLM planning, user XPath priority, deterministic healing, and LLM healing order remain unchanged.

## Report changes
- Added Execution Date to the HTML execution report.
- Added Execution Date to HTML technical logs.
- Added Execution Date to Excel Results and Technical Logs worksheets.
- JSON already includes startedAt/finishedAt and remains unchanged.
