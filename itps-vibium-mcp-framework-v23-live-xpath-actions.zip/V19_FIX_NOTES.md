# V19 – Plain English + User XPath Priority

## Confirmed execution rules

1. Test steps remain plain English.
2. When a step contains an XPath, that XPath is the highest-priority locator for that atomic step.
3. If multiple nodes match, the first visible node is selected.
4. If the XPath is invalid, absent, hidden, or the intended action fails, normal LLM self-healing is triggered.
5. For dropdown instructions, XPath identifies the field; the framework still interprets the English, opens the field, selects the requested value, and validates the action.
6. Reports and technical logs show `USER_XPATH_PRIORITY`, XPath success/failure, healing usage, and final strategy.

## Supported step examples

- `Select BCEF from Perimeter using xpath "//*[@id='entityCode']//input"`
- `Click the white action stripe using xpath "(//datatable-body-row)[1]//datatable-body-cell[1]"`
- `Click See Transaction [xpath=//*[normalize-space()='See Transaction']]`

XPath is optional. Plain-English-only steps continue through normal LLM/Vibium planning.
