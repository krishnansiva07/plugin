# V22 – Enterprise Action and Angular Dropdown Transaction

## Problem corrected

V21 could locate normal elements with XPath but failed on Angular dropdown options because options are created only after the trigger click, frequently inside CDK/portal overlays. The older implementation also dispatched more than one click and accepted generic DOM or screenshot changes as proof of selection.

## Implemented flow

A new `EnterpriseDropdownExecutor` performs:

1. Semantic or XPath-based trigger resolution.
2. Recognition of whether a generic XPath points to a trigger or directly to an option.
3. Native Vibium pointer click exactly once.
4. Fresh live-DOM option resolution after the overlay opens.
5. Active overlay/listbox scoping using `aria-controls`, `aria-owns`, visibility and z-index.
6. Exact option-text matching with disabled-option rejection.
7. Filtering support for searchable dropdowns.
8. Scrolling support for CDK/PrimeNG/ng-select virtualized lists and lazy-loaded batches.
9. Reacquisition of the field after Angular re-rendering.
10. Exact selected-value verification through control value, selected option, framework value label, `aria-valuetext`, or an optional verification XPath.

## Supported locator forms

```text
xpath=...
using xpath "..."
triggerXPath=...
optionXPath=...
verifyXPath=...
selectedXPath=...
```

A generic XPath containing option semantics such as `role='option'`, `mat-option`, `ng-option`, or option-list classes is automatically treated as an option locator.

## Click safety

- Native Vibium clicks are preferred.
- DOM fallback requires a successful hit test.
- Fallback emits pointer/mouse down and up followed by exactly one `click()`.
- Duplicate `dispatchEvent('click')` plus `element.click()` behavior was removed from generic, XPath, custom-dropdown, and row-action fallbacks.

## Composite actions

Atomic-plan early termination is disabled for `SELECT` and `COMPOSITE` intents, allowing ordered open/wait/select chains to complete.

## False-pass prevention

Dropdown selection never passes merely because the overlay opened, closed, focus changed, or the screenshot changed. It must prove the requested value is selected.

## Added tests

`EnterpriseDropdownExecutorTest` covers:

- Semantic Angular dropdown parsing.
- `Set field to value` parsing.
- Direct option XPath recognition.
- Separate trigger/option/verification XPath parsing.
- Protection against hijacking ordinary XPath button clicks.
