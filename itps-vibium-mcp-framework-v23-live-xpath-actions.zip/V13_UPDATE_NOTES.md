# V13 - Map Reference and Menu Click Healing

## Root cause corrected
Vibium correctly mapped **New search** as a numbered element such as `@e13`, but the mapped reference could resolve to a nested `span`. The application handles the action on its surrounding menu row (`li`) through delegated JavaScript events. A physical click on the nested span was therefore reported as obscured or timed out.

## V13 behavior
1. Try the original Vibium `@e` click.
2. On interception/timeout, extract the exact target from the Excel instruction, for example `New search`.
3. Re-locate the visible element in the live DOM using exact text/accessibility attributes.
4. Promote a nested span to its nearest `li`, `role=menuitem`, link, or button.
5. Hit-test the element and dispatch pointer/mouse events to the actual visible child and the menu container.
6. Execute native click on both the hit node and delegated container.
7. Validate that the page/menu state changed before passing the step.

This remains bounded healing. A genuinely disabled or absent menu item is still reported as failed with evidence.
