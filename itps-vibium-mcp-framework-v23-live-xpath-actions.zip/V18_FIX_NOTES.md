# V18 enterprise execution updates

- Excel worksheet discovery endpoint and UI worksheet dropdown.
- Selected worksheet is executed; first sheet remains the default for compatibility.
- Optional `Run` column filtering. Accepted enabled values: true, yes, y, 1, run, execute, enabled.
- Failed-test checkbox rerun retained.
- XPath supplied inside a step receives first priority before LLM/Vibium map healing.
- Supported step examples:
  - `Click BCEF option | xpath=//div[@role='option' and normalize-space()='BCEF']`
  - `Click action stripe | xpath=(//datatable-body-row)[1]//datatable-body-cell[1]`
- User XPath is validated for uniqueness and visibility by the existing selector validation before action execution.
- Healing is attempted only after the supplied XPath fails.
