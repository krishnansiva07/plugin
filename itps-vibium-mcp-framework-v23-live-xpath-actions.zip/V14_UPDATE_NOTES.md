# V14 Verification Engine Fix

## Root cause fixed
Verification steps such as `Verify Message text available` were incorrectly required to return a state-changing MCP action. Read-only Vibium evidence tools were therefore rejected even when the expected text was visible.

## Corrections
- Assertions no longer require click/fill/select style MCP actions.
- `text available`, `text visible`, `is displayed`, `is present`, and similar suffixes are removed before matching.
- `Verify Message text available` now searches for `Message`, including UI text such as `7 Message`.
- Assertions retry with fresh Vibium map/text/DOM observations to handle rendering delays.
- Exact assertion evidence is written to the report, including strategy, expected text, and matched text.
- Failures now include a useful visible-text sample rather than the misleading `Planner did not return a real MCP action` message.
- The same deterministic behavior applies to `Payment`, `Transaction`, and other visible-text validations.

## No Excel change required
Existing steps remain valid:
- `Verify Message text available`
- `Verify Payment text available`
- `Verify Transaction text available`
