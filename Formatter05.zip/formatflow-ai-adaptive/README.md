# FormatFlow AI — LangGraph Editorial Edition

FormatFlow AI is a Java 17 + Spring Boot application focused on three destinations:

- **Confluence**
- **Email / Outlook**
- **HTML**

The configured model remains **`gpt-oss-120b`**. The application now uses **LangGraph4j** to orchestrate the model instead of sending every formatting request through one flat generation pass.

## Active workflow

The normal formatting path is now:

```text
Input / uploaded document / web content
        ↓
┌──────────────────────────┐
│ ANALYZE                   │
│ Build one global          │
│ editorial plan            │
└────────────┬─────────────┘
             ↓
┌──────────────────────────┐
│ CREATE                    │
│ Unrestricted editorial    │
│ formatting with the plan  │
└────────────┬─────────────┘
             ↓
┌──────────────────────────┐
│ REVIEW                    │
│ Quality + repetition +    │
│ destination fitness       │
└────────────┬─────────────┘
             │
       PASS  │  NEEDS REPAIR
        ┌────┘        │
        ↓             ↓
    FINALIZE       REPAIR
        ↑             │
        └──────── REVIEW
             ↓
       Java sanitizer
             ↓
 Confluence / Email / HTML
```

The repair loop is deliberately bounded. By default the graph allows **one repair pass maximum**, so it cannot keep regenerating indefinitely.

## LangGraph4j

The project uses:

```xml
<dependency>
    <groupId>org.bsc.langgraph4j</groupId>
    <artifactId>langgraph4j-core</artifactId>
    <version>1.8.20</version>
</dependency>
```

No second AI model is required. `gpt-oss-120b` is used for ANALYZE, CREATE and REVIEW/REPAIR.

## What the model is allowed to do

The CREATE node has editorial freedom. It may:

- rewrite and correct grammar
- reorganize content by meaning
- split one paragraph into headings + bullets
- merge duplicated/repeated points
- condense verbose wording
- create headings and subheadings
- create bullets and numbered procedures
- create tables when information is genuinely tabular
- create simple callouts for important information
- use small indicative Unicode/emoji symbols where useful
- follow clear formatting/editing instructions included directly in the user's input

It is still instructed **not to invent facts** and to preserve literal technical identifiers, URLs, code, configuration values and API names unless the user explicitly asks to change them.

## Why ANALYZE first

For a small input, ANALYZE gives CREATE a clear editorial direction.

For a very large input, ANALYZE is more important: it receives a representative beginning/middle/end sample plus structure/instruction hints and produces **one shared editorial plan**. Every later chunk receives that same plan, which reduces the "several model answers stitched together" effect.

## Large content

Long documents are processed in bounded CREATE calls. Very large single-paragraph inputs are also hard-split.

Every CREATE chunk receives:

- the **global editorial plan** from ANALYZE
- a short opening excerpt from the original document
- the tail of the previous generated chunk
- the current source chunk
- reviewer repair guidance when a repair pass is active

The model is explicitly told not to repeat opening context or previous output.

Current chunk setting:

```properties
formatflow.llm.chunk-characters=9000
```

The editorial path uses a practical minimum target of about 14,000 characters per chunk.

## REVIEW node

After CREATE, the graph performs two types of checks.

### Java checks

The application detects obvious problems such as:

- duplicate headings across chunks
- exact repeated long paragraphs/list points
- unsupported/unsafe HTML
- H1-style document hierarchy in an email body
- empty/unreadable output

### LLM review

The reviewer checks:

- Confluence / Outlook / HTML destination fitness
- hierarchy and scanability
- unnecessary repetition
- inappropriate table/list usage
- preservation of factual and technical details

The reviewer returns small strict JSON used only for routing. It does **not** directly replace the draft.

Default graph settings:

```properties
formatflow.langgraph.max-repairs=1
formatflow.langgraph.review-threshold=80
formatflow.langgraph.plan-sample-characters=18000
formatflow.langgraph.review-sample-characters=28000
```

## Confluence

Confluence output remains deliberately simple and paste-friendly. The model can use:

```text
h1-h4
paragraphs
bullets / numbered lists
tables
blockquote callouts
pre/code
strong / emphasis
links
```

Model-generated CSS, scripts, forms, images, iframes and unsupported markup are removed before preview/copy.

**Copy for Confluence** writes both `text/html` and a structured plain-text fallback to the clipboard.

## Email / Outlook

Email uses the same graph but different destination guidance. The CREATE node is instructed to produce a concise email body rather than a document page. The Java renderer then applies conservative inline formatting suitable for Outlook-style editors.

The email subject remains separate from the copied body and can be entered manually or generated by a small additional model call.

## HTML

HTML uses the same semantic draft but receives the richer portable green/white web-document renderer after sanitization.

## LLM configuration

The API key is entered on the launch screen and stored only in the server-side HTTP session.

```properties
formatflow.llm.base-url=https://ai4devs.group.echonet/api/v1
formatflow.llm.model=gpt-oss-120b
formatflow.llm.chat-path=/chat/completions
```

The key is intentionally not stored in `application.properties`.

## Build and run

Requirements:

- Java 17+
- Maven 3.9+

```bash
mvn clean test
mvn clean package
java -jar target/formatflow-ai-0.0.1-SNAPSHOT.jar
```

Open:

```text
http://localhost:8090
```

## Suggested Confluence input

The main content box can contain content alone or content plus instructions, for example:

```text
I want this content neatly formatted for a new joiner. Use indicative bullets where helpful,
avoid repeating points and make it more reader friendly.

About me application allows employees to maintain their profiles, access appraisal reviews
and track the inventory of training programs...
```

ANALYZE is explicitly instructed to recognize that first paragraph as an editing instruction rather than page content, and CREATE is allowed to follow it.

## Reliability controls retained

Editorial freedom applies to **content editing**, not executable output. Java still:

- sanitizes all model HTML
- removes scripts and unsupported tags/attributes
- restricts link protocols to safe web/mail links
- keeps the LLM API key session-only
- blocks private/local targets in the generic URL importer
- does not intentionally log uploaded content or API keys
- provides a structured plain-text clipboard fallback
- bounds the LangGraph repair loop

## Tests added for the graph

`LlmOrchestratorLangGraphTest` covers:

- ANALYZE → CREATE → passing REVIEW → FINALIZE
- failed REVIEW → one REPAIR → second REVIEW → FINALIZE

The frontend JavaScript is syntax-checked during packaging work. Run `mvn clean test` in the development environment to resolve Maven Central dependencies and execute the full Java test suite.
