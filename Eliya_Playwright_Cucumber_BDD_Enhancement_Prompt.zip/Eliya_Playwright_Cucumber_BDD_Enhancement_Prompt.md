# ELIYA — Enhance Existing Playwright Framework with Cucumber BDD

> **Use in Eliya Execute mode, after the currently running framework-creation job finishes.** This prompt enhances the generated TypeScript + Playwright framework. It does **not** rebuild it or begin Selenium module migration.

## Objective

Enhance the existing **TypeScript + Playwright** automation framework to additionally support **Cucumber BDD (`@cucumber/cucumber`) with TypeScript**, while retaining all current **Playwright Test (`@playwright/test`)** functionality.

**Mandatory constraints**

- **Enhancement only:** Do not delete, overwrite wholesale, or recreate the framework. Preserve all completed work, configurations, page objects, utilities, fixtures, test data, and working tests.
- **Do not interrupt the current job:** First confirm that the initial framework-creation task has completed and its changes are saved. If the job is still running, queue this as a separate follow-up task instead of running concurrently against the same files.
- **No browser downloads:** Use **Google Chrome or Microsoft Edge already installed locally**. Never run `npx playwright install`, `npx playwright install chromium`, `playwright install`, or any equivalent browser-download command. Do not fall back to Playwright's bundled browsers.
- **No Selenium business-module migration yet:** This task only adds and validates Cucumber support.
- **No MCP:** Do not invoke any MCP tools unless I explicitly request them.
- **Protect references:** Use writable references only when explicitly enabled. Do not change the Selenium source code or delete source files.

## 1. Analyse the Existing Framework Before Changing Anything

Inspect the entire generated target framework and record:

- Project structure and dependency versions in `package.json` / lockfile.
- TypeScript configuration and `playwright.config.*`.
- Existing Playwright Test specs and fixtures.
- Browser management and installed-browser selection.
- Page objects, locators, shared utilities, and assertions.
- Authentication/session-state handling.
- Configuration, environments, secrets and test-data handling (Excel, CSV, JSON, etc., if present).
- API/database clients, logging, retries, reporting, screenshots and tracing.
- CI configuration and execution scripts (if present).

Produce a brief **reuse / adapt / create** map. Preserve working conventions and avoid duplicate implementations.

## 2. Add Cucumber BDD Without Replacing Playwright Test

Integrate `@cucumber/cucumber` as a **separate BDD runner** and use `playwright` for browser interaction. Configure a compatible TypeScript loader for the repository's actual module system and installed dependency versions.

Support:

- `.feature` files and Gherkin `Feature`, `Background`, `Scenario`, `Scenario Outline`, `Examples`.
- `Given`, `When`, `Then`, `And`, `But` steps.
- Data Tables and Doc Strings.
- Cucumber tags / tag expressions, hooks, execution profiles, configurable timeouts and retries.
- Parallel execution with scenario isolation.
- JSON and HTML reporting, failure screenshots, and optional Playwright traces.
- Clear error handling and resource cleanup on pass, fail, timeout, interruption or cancellation.

Keep existing Playwright Test specs and command-line workflows intact. **Do not run Cucumber scenarios inside the Playwright Test runner or vice versa.**

## 3. Share Infrastructure, Not Runner-Specific Fixtures

Both runners should reuse, as appropriate:

- Page Object classes and locator conventions.
- Browser/context/page **factory functions** and browser launch options.
- Environment configuration and secure credential loading.
- Test-data readers and fixture data.
- API clients, DB utilities, logging, screenshots and trace helpers.
- Authentication utilities and reusable assertion helpers.

**Important:** Playwright Test's built-in `test` fixtures, worker state, `testInfo`, and `expect` integrations are runner-specific. Do **not** attempt to use them directly as Cucumber fixtures. Extract reusable code where necessary and create a small adapter for each runner. Maintain independent lifecycle handling.

## 4. Mandatory Browser Policy — Installed Chrome / Edge Only

Apply the following to **both** runners:

1. Allow a configuration value such as `BROWSER=chrome|msedge` and `HEADLESS=true|false`.
2. Prefer an **already installed** Google Chrome; use installed Microsoft Edge if Chrome is unavailable, unless the user explicitly selects one.
3. Use Playwright's supported `channel: 'chrome'` or `channel: 'msedge'`, with `executablePath` only where an environment-specific installed-browser location makes that necessary.
4. Provide OS-aware validation for Windows, macOS and Linux. A browser is considered available only if it can actually be launched; a file-path guess is not enough.
5. Set `PLAYWRIGHT_SKIP_BROWSER_DOWNLOAD=1` for installation/setup commands and avoid browser-install scripts or download-triggering setup steps. Ensure CI/setup documentation follows this rule.
6. **Never** fall back to Playwright-managed Chromium, Firefox or WebKit. If neither installed browser launches, fail with a clear actionable message; report the browser check as blocked, not passed.
7. Preserve headed and headless execution and support enterprise proxy/certificate settings where the existing framework already has them. Do not hardcode credentials or bypass certificate validation without explicit authorization.

## 5. Cucumber World, Hooks, and Parallel Isolation

Implement a typed Cucumber **Custom World** that supplies the current scenario's:

- BrowserContext and Page.
- Shared Page Object instances / factories.
- Scenario-specific test data and configuration.
- Optional API state and attachments / artifacts.

Use suitable `Before`, `After`, `BeforeAll` and `AfterAll` hooks. Scope browser resources appropriately: a reusable browser per worker is acceptable if scenario state is strictly isolated, but each scenario must receive a **fresh BrowserContext and Page** unless a documented exception is justified. Avoid shared mutable data between concurrently executing scenarios.

Capture failure screenshots and, when enabled, traces; attach artifacts to the report where supported. Always close pages, contexts and browser resources properly.

## 6. Create a Self-Contained Cucumber Smoke Test

Create **one small sample `.feature` file** and its TypeScript step definitions to demonstrate:

- Browser launch through the configured installed Chrome/Edge channel.
- Navigating to **locally controlled test content** (for example, a minimal local fixture page or `data:` URL), not an external website.
- Finding and interacting with a page element.
- Asserting the expected result.
- Running under Cucumber with clean setup/teardown and report output.

Do not convert real Selenium business scenarios in this task.

## 7. Provide Working Commands and Profiles

Add or update npm scripts / Cucumber configuration for:

- Existing Playwright Test execution.
- Cucumber BDD execution.
- Cucumber tag filtering.
- Cucumber headed/headless execution.
- Chrome/Edge selection.
- TypeScript type-checking.
- HTML/JSON reporting.
- Targeted feature or scenario execution and debugging.

Prefer commands that work across Windows, macOS and Linux; if environment-setting syntax differs, use a portable approach or document the alternatives. Reuse the existing package manager and lockfile; do not install incompatible or duplicate packages.

## 8. Update Agent and Framework Documentation

Update `README.md`, `AGENTS.md`, and relevant skills guidance (`SKILLS.md` or existing skill locations) to document:

- Why both runners exist and which to use.
- How the shared components are structured.
- How to create `.feature` files, step definitions and Custom World state.
- How to run Playwright Test and Cucumber tests independently.
- Tagging, data tables, reporting, retries, hooks, parallel execution and browser selection.
- Installed-browser-only setup, troubleshooting and CI considerations.
- **Migration rule:** For future Java Selenium + TestNG + Cucumber migrations, keep source Gherkin behavior and make **Cucumber BDD the default target** for existing `.feature` scenarios. Use standalone Playwright Test for suitable non-BDD automation.

Document the target project's actual commands and file paths; avoid generic placeholders in the final repository documentation.

## 9. Mandatory Regression and Acceptance Checks

Validate in this order:

1. Existing Playwright Test smoke tests still work (no regression).
2. Cucumber discovers the sample feature and step definitions.
3. TypeScript compile/type-check passes.
4. Cucumber smoke scenario launches the **installed** Chrome or Edge and passes.
5. Tag filtering selects the intended scenarios.
6. Scenario isolation and browser/context cleanup work.
7. Reports and failure artifacts are generated correctly.
8. No duplicate Page Objects or browser-management implementations were introduced.
9. No browser binaries were downloaded during this work.
10. Existing Playwright Test configuration, package scripts and tests remain functional.

If a required command fails, fix only enhancement-related defects and rerun affected checks. If a step cannot run because of environment limitations, mark it **NOT VERIFIED** or **BLOCKED** with the reason. **Do not claim full success without execution evidence.**

## 10. Completion Report (Required)

At completion report:

- Summary of enhancements.
- Files created and modified (exact paths).
- Components reused, adapted and newly created.
- Browser chosen, installed executable/channel verification, and whether launch passed.
- Playwright Test results and Cucumber results (pass/fail/blocked counts).
- TypeScript type-check results.
- Report/artifact paths.
- Exact working commands for each runner.
- Any errors, remaining risks and unverified checks.
- Confirmation whether the framework is **ready for feature/module-wise Selenium-to-Playwright Cucumber migration**.

**Stop after this enhancement. Do not automatically migrate a Selenium module.**

## Final Acceptance Criterion

Both **Playwright Test** and **TypeScript Cucumber BDD** must execute independently against the same shared automation foundation, using **only locally installed Chrome or Edge**, with no loss of existing functionality, no duplicated framework and no browser downloads.
