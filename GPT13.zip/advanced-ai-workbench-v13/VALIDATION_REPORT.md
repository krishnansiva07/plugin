# V13 Validation Report

See `V13_RELEASE_NOTES.md` for the feature-level summary.

## Passed in packaging environment

- Prompt path extraction and primary project selection
- Generic roles: primary workspace, secondary workspace, reference, input, diagnostic
- Regression: labelled input file inside another valid project remains exact read-only file
- Regression: diagnostic file inside another project does not promote its parent
- Multi-resource read/write permission enforcement
- Large text full-read guard (>256 KiB)
- Structured text index with frequent key counts
- Bounded grep for minified/very-long lines
- Character chunk reads for large/minified inputs
- 58 unique built-in agent tools
- Java 17 core compile harness
- Full main-source Java parse scan: no syntax-like errors found
- `node --check` for `app.js` and `markdown.js`

## Environment limitation

The packaging sandbox has Java but no installed Maven and cannot resolve `repo.maven.apache.org`, so a real dependency-backed `mvn clean test` cannot be completed here. The package includes Maven bootstrap scripts and local validation scripts for the target machine.
