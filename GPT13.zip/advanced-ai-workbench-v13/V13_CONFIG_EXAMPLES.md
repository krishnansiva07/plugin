# V13 resource examples

## Target project + read-only input + diagnostic evidence

```text
Project: "D:\Work\Application"
Input file: "C:\Inputs\requirements.json"
Issue log: "C:\Logs\build.log"

Implement the requirement, run the relevant verification, and continue fixing until verified.
```

Expected roles:
- `@workspace` -> `primary_workspace`, read/write
- requirements -> `input`, read-only
- build log -> `diagnostic`, read-only

## Target + secondary writable project + reference

```text
Main project: "D:\Work\Frontend"
Backend project: "D:\Work\Backend"
Working reference: "D:\Archive\KnownGood"

Fix the integration. Modify frontend/backend as needed; do not modify the reference.
```

Expected roles:
- main -> `primary_workspace`
- backend -> `secondary_workspace`
- reference -> `reference`, read-only

## Large/minified input

For a large JSON/XML/CSV/log/generated file, the agent should use:
1. `resource_info`
2. `resource_index`
3. `resource_grep` or bounded `resource_read`
4. `resource_chunk` when the useful data is on a very long/minified line

Full reads above the context-safety threshold are intentionally guarded.
