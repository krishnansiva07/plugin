# GPT13 / Advanced AI Workbench V13

V13 hardens the generic multi-resource agent introduced in V12. It deliberately avoids baking test-automation semantics into the core.

## Fixed from V12 testing

### Explicit input files no longer promote their parent project
If a user writes:

```text
Recorded JSON: C:\RecorderProject\recordings\flow.json
Project: D:\Automation\Target
```

and `RecorderProject` contains `package.json`, V13 keeps `flow.json` as an exact read-only `input` resource. It does not expose the recorder project as an unintended writable project.

The same rule applies generically to input and diagnostic resources.

## Generic resource roles

Every prompt-resolved path now has one role:
- `PRIMARY_WORKSPACE` — primary writable workspace
- `SECONDARY_WORKSPACE` — additional explicitly supplied writable workspace
- `REFERENCE` — read-only comparison/reference material
- `INPUT` — read-only source material
- `DIAGNOSTIC` — read-only evidence such as logs/traces/screenshots

User intent labels take priority over project-root inference.

## Large-file context protection

V13 adds:
- `file_index`
- `read_chunk`
- `resource_index`
- `resource_chunk`

Full text reads above 256 KiB are guarded instead of injecting the entire file into the model context. Indexing reports size, line counts, long-line characteristics, structural shape, and frequent JSON-style keys. Character chunks handle minified/very-long-line files.

Grep and line-range outputs are bounded so a single huge line cannot flood the context.

## Tool count

V13 exposes **58 built-in tools**, plus dynamically discovered MCP tools.

## Validation performed in this package

- Java 17 compilation of the resolver/workspace/tool-registry core against dependency stubs
- prompt resource-role behavior harness
- exact regression for input-file-inside-another-project
- read-only reference/input/diagnostic enforcement
- large minified JSON full-read guard
- generic structured-file indexing
- bounded grep around a match near the end of a huge line
- character chunk reads
- tool registry uniqueness/count
- full source Java parse pass (external dependency symbols are unavailable in the packaging sandbox)
- frontend JavaScript syntax checks

A full Maven build still requires Maven/dependency access on the target machine. Run `validate-local.bat` or `validate-local.sh`.
