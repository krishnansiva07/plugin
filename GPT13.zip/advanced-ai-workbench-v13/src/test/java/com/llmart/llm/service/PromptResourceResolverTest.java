package com.llmart.llm.service;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Files;
import java.nio.file.Path;

import static org.junit.jupiter.api.Assertions.*;

class PromptResourceResolverTest {

    @TempDir
    Path temp;

    @Test
    void resolvesPrimaryProjectAndStandaloneIssueFile() throws Exception {
        Path project = temp.resolve("main project");
        Files.createDirectories(project.resolve("src"));
        Files.writeString(project.resolve("pom.xml"), "<project/>\n");
        Path source = project.resolve("src/App.java");
        Files.writeString(source, "class App {}\n");
        Path log = temp.resolve("jenkins-error.log");
        Files.writeString(log, "Compilation failed\n");

        PromptResourceResolver resolver = new PromptResourceResolver();
        String prompt = "Project: \"" + project + "\"\nIssue log: \"" + log + "\"";

        assertEquals(project.toRealPath(), resolver.primaryProjectPath(prompt).orElseThrow());
        var resolution = resolver.resolve(prompt, project);
        assertEquals(2, resolution.resources().size());
        var issue = resolution.resources().stream().filter(r -> !r.primary()).findFirst().orElseThrow();
        assertEquals(PromptResourceResolver.ResourceKind.FILE, issue.kind());
        assertEquals(PromptResourceResolver.ResourceRole.DIAGNOSTIC, issue.role());
        assertFalse(issue.writable());
        assertEquals(log.toRealPath(), issue.root());
    }

    @Test
    void resolvesSecondProjectAsWritableResource() throws Exception {
        Path frontend = temp.resolve("frontend");
        Path backend = temp.resolve("backend");
        Files.createDirectories(frontend);
        Files.createDirectories(backend);
        Files.writeString(frontend.resolve("package.json"), "{}\n");
        Files.writeString(backend.resolve("pom.xml"), "<project/>\n");

        PromptResourceResolver resolver = new PromptResourceResolver();
        String prompt = "Frontend: \"" + frontend + "\"\nBackend: \"" + backend + "\"\nFix both projects";
        var resolution = resolver.resolve(prompt, frontend);

        var secondary = resolution.resources().stream().filter(r -> !r.primary()).findFirst().orElseThrow();
        assertEquals(backend.toRealPath(), secondary.root());
        assertEquals(PromptResourceResolver.ResourceKind.PROJECT, secondary.kind());
        assertEquals(PromptResourceResolver.ResourceRole.SECONDARY_WORKSPACE, secondary.role());
        assertTrue(secondary.writable());
    }

    @Test
    void filePathInfersOwningProjectAndFocusedFile() throws Exception {
        Path project = temp.resolve("service");
        Path source = project.resolve("src/main/java/example/App.java");
        Files.createDirectories(source.getParent());
        Files.writeString(project.resolve("pom.xml"), "<project/>\n");
        Files.writeString(source, "class App {}\n");
        Path primary = temp.resolve("primary");
        Files.createDirectories(primary);
        Files.writeString(primary.resolve("package.json"), "{}\n");

        PromptResourceResolver resolver = new PromptResourceResolver();
        var resolution = resolver.resolve("Issue file: \"" + source + "\"", primary);
        var resource = resolution.resources().stream().filter(r -> !r.primary()).findFirst().orElseThrow();

        assertEquals(project.toRealPath(), resource.root());
        assertEquals(Path.of("src/main/java/example/App.java"), resource.focus());
        assertEquals(PromptResourceResolver.ResourceRole.SECONDARY_WORKSPACE, resource.role());
        assertTrue(resource.writable());
    }

    @Test
    void arbitraryExplicitDirectoryCanBeWritableEvenWithoutBuildDescriptor() throws Exception {
        Path primary = temp.resolve("primary");
        Path other = temp.resolve("plain-folder");
        Files.createDirectories(primary);
        Files.createDirectories(other);

        PromptResourceResolver resolver = new PromptResourceResolver();
        var resolution = resolver.resolve("Other path: \"" + other + "\"", primary);
        var resource = resolution.resources().stream().filter(r -> !r.primary()).findFirst().orElseThrow();

        assertEquals(PromptResourceResolver.ResourceKind.DIRECTORY, resource.kind());
        assertEquals(PromptResourceResolver.ResourceRole.SECONDARY_WORKSPACE, resource.role());
        assertTrue(resource.writable());
    }

    @Test
    void ignoresNonexistentAndUrlCandidates() {
        PromptResourceResolver resolver = new PromptResourceResolver();
        String prompt = "Check https://example.com/a/b and /definitely/not/here/project";
        assertTrue(resolver.explicitExistingPaths(prompt).isEmpty());
    }
    @Test
    void prefersBrokenProjectOverEarlierReferenceAndKeepsReferenceReadOnly() throws Exception {
        Path reference = temp.resolve("working-reference");
        Path broken = temp.resolve("broken-project");
        Files.createDirectories(reference);
        Files.createDirectories(broken);
        Files.writeString(reference.resolve("pom.xml"), "<project/>\n");
        Files.writeString(broken.resolve("pom.xml"), "<project/>\n");

        PromptResourceResolver resolver = new PromptResourceResolver();
        String prompt = "Reference project: \"" + reference + "\"\nBroken project: \"" + broken + "\"";

        assertEquals(broken.toRealPath(), resolver.primaryProjectPath(prompt).orElseThrow());
        var resolution = resolver.resolve(prompt, broken);
        var ref = resolution.resources().stream().filter(r -> !r.primary()).findFirst().orElseThrow();
        assertEquals(reference.toRealPath(), ref.root());
        assertEquals(PromptResourceResolver.ResourceRole.REFERENCE, ref.role());
        assertFalse(ref.writable());
    }

    @Test
    void explicitlyLabelledInputFileStaysReadOnlyEvenInsideAnotherProject() throws Exception {
        Path recorderProject = temp.resolve("recorder-project");
        Path recording = recorderProject.resolve("recordings/flow.json");
        Files.createDirectories(recording.getParent());
        Files.writeString(recorderProject.resolve("package.json"), "{}\n");
        Files.writeString(recording, "{\"steps\":[]}\n");

        Path target = temp.resolve("target-project");
        Files.createDirectories(target);
        Files.writeString(target.resolve("pom.xml"), "<project/>\n");

        PromptResourceResolver resolver = new PromptResourceResolver();
        String prompt = "Recorded JSON: \"" + recording + "\"\nProject: \"" + target + "\"";

        assertEquals(target.toRealPath(), resolver.primaryProjectPath(prompt).orElseThrow());
        var resolution = resolver.resolve(prompt, target);
        var input = resolution.resources().stream().filter(r -> r.role() == PromptResourceResolver.ResourceRole.INPUT).findFirst().orElseThrow();
        assertEquals(PromptResourceResolver.ResourceKind.FILE, input.kind());
        assertEquals(recording.toRealPath(), input.root());
        assertNull(input.focus());
        assertFalse(input.writable());
        assertTrue(resolution.resources().stream().noneMatch(r -> r.root().equals(recorderProject.toRealPath())));
    }

    @Test
    void diagnosticFileInsideProjectDoesNotPromoteOwningProject() throws Exception {
        Path diagnosticsProject = temp.resolve("diagnostics-project");
        Path log = diagnosticsProject.resolve("logs/build.log");
        Files.createDirectories(log.getParent());
        Files.writeString(diagnosticsProject.resolve("pom.xml"), "<project/>\n");
        Files.writeString(log, "failure\n");

        Path target = temp.resolve("target");
        Files.createDirectories(target);
        Files.writeString(target.resolve("package.json"), "{}\n");

        PromptResourceResolver resolver = new PromptResourceResolver();
        String prompt = "Project: \"" + target + "\"\nBuild log: \"" + log + "\"";
        var resolution = resolver.resolve(prompt, target);
        var diagnostic = resolution.resources().stream().filter(r -> !r.primary()).findFirst().orElseThrow();
        assertEquals(PromptResourceResolver.ResourceRole.DIAGNOSTIC, diagnostic.role());
        assertEquals(PromptResourceResolver.ResourceKind.FILE, diagnostic.kind());
        assertEquals(log.toRealPath(), diagnostic.root());
        assertFalse(diagnostic.writable());
    }

}
