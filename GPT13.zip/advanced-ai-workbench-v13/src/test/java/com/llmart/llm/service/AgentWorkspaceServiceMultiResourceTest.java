package com.llmart.llm.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.llmart.llm.entity.ProjectWorkspaceEntity;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Files;
import java.nio.file.Path;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class AgentWorkspaceServiceMultiResourceTest {

    @TempDir
    Path temp;

    @Test
    void supportsWritableSecondaryProjectReadOnlyReferenceAndDiagnosticFile() throws Exception {
        Path primary = createMavenProject("primary", "class Main {}\n");
        Path secondary = createMavenProject("secondary", "class Secondary { int value = 1; }\n");
        Path reference = createMavenProject("reference", "class Reference { int value = 7; }\n");
        Path log = temp.resolve("failure.log");
        Files.writeString(log, "Compilation failed in Secondary.java\n");

        ProjectService projects = mock(ProjectService.class);
        ProjectWorkspaceEntity entity = mock(ProjectWorkspaceEntity.class);
        when(projects.require("p1")).thenReturn(entity);
        when(entity.hasLocalPath()).thenReturn(true);
        when(entity.getLocalPath()).thenReturn(primary.toString());

        AgentWorkspaceService service = new AgentWorkspaceService(projects, new ObjectMapper(), new PromptResourceResolver());
        String prompt = "Main project: \"" + primary + "\"\n" +
                "Secondary project: \"" + secondary + "\"\n" +
                "Working reference: \"" + reference + "\"\n" +
                "Issue log: \"" + log + "\"";

        AgentWorkspaceService.Workspace ws = service.prepare("p1", prompt);
        assertEquals(4, ws.resources().size());
        assertTrue(ws.resources().get("secondary").writable());
        assertFalse(ws.resources().get("reference").writable());
        assertFalse(ws.resources().get("failure").writable());

        assertTrue(service.resourceRead(ws, "failure", "", 1, 20).contains("Compilation failed"));
        service.resourceEdit(ws, "secondary", "src/App.java", "value = 1", "value = 2", false);
        assertTrue(Files.readString(secondary.resolve("src/App.java")).contains("value = 2"));

        service.resourceCopy(ws, "reference", "src/App.java", "secondary", "src/ReferenceCopy.java", false);
        assertTrue(Files.exists(secondary.resolve("src/ReferenceCopy.java")));
        assertThrows(SecurityException.class,
                () -> service.resourceWrite(ws, "reference", "src/ShouldNotWrite.java", "class X {}"));

        String status = service.workspaceStatus(ws);
        assertTrue(status.contains("@secondary/src/App.java"));
        assertTrue(status.contains("@secondary/src/ReferenceCopy.java"));
    }

    @Test
    void projectRootDetectionIsCaseSafeAndRecognizesGitRoot() throws Exception {
        Path rust = temp.resolve("rust-project");
        Files.createDirectories(rust.resolve("src"));
        Files.writeString(rust.resolve("Cargo.toml"), "[package]\nname='demo'\n");
        Path source = rust.resolve("src/main.rs");
        Files.writeString(source, "fn main() {}\n");

        PromptResourceResolver resolver = new PromptResourceResolver();
        assertEquals(rust.toRealPath(), resolver.primaryProjectPath("Fix: \"" + source + "\"").orElseThrow());

        Path gitOnly = temp.resolve("git-only");
        Files.createDirectories(gitOnly.resolve(".git"));
        Files.createDirectories(gitOnly.resolve("src"));
        Path genericSource = gitOnly.resolve("src/tool.py");
        Files.writeString(genericSource, "print('x')\n");
        assertEquals(gitOnly.toRealPath(), resolver.primaryProjectPath("Project file: \"" + genericSource + "\"").orElseThrow());
    }

    @Test
    void guardsLargeInputAndSupportsIndexGrepAndCharacterChunks() throws Exception {
        Path primary = createMavenProject("large-primary", "class Main {}\n");
        Path inputDir = temp.resolve("input-project");
        Files.createDirectories(inputDir.resolve("data"));
        Files.writeString(inputDir.resolve("package.json"), "{}\n");
        Path large = inputDir.resolve("data/large.json");
        StringBuilder json = new StringBuilder("{\"records\":[");
        for (int i = 0; i < 12000; i++) {
            if (i > 0) json.append(',');
            json.append("{\"id\":").append(i).append(",\"action\":\"step-").append(i).append("\",\"value\":\"abcdefghijklmnopqrstuvwxyz\"}");
        }
        json.append("]}");
        Files.writeString(large, json.toString());
        assertTrue(Files.size(large) > 256 * 1024);

        ProjectService projects = mock(ProjectService.class);
        ProjectWorkspaceEntity entity = mock(ProjectWorkspaceEntity.class);
        when(projects.require("p-large")).thenReturn(entity);
        when(entity.hasLocalPath()).thenReturn(true);
        when(entity.getLocalPath()).thenReturn(primary.toString());

        AgentWorkspaceService service = new AgentWorkspaceService(projects, new ObjectMapper(), new PromptResourceResolver());
        AgentWorkspaceService.Workspace ws = service.prepare("p-large", "Input file: \"" + large + "\"\nProject: \"" + primary + "\"");
        var input = ws.resources().values().stream().filter(r -> r.role() == PromptResourceResolver.ResourceRole.INPUT).findFirst().orElseThrow();

        String guarded = service.resourceRead(ws, input.alias(), "", 1, Integer.MAX_VALUE);
        assertTrue(guarded.contains("Large text resource"));
        assertFalse(guarded.contains("step-11999"));

        String index = service.resourceIndex(ws, input.alias(), "");
        assertTrue(index.contains("largeText=true"));
        assertTrue(index.contains("action="));

        String grep = service.resourceGrep(ws, input.alias(), "step-11999", false, 1);
        assertTrue(grep.contains("step-11999"));
        assertTrue(grep.length() < 10000, "grep output should be context bounded for minified input");

        String chunk = service.resourceReadChunk(ws, input.alias(), "", 1000, 2000);
        assertTrue(chunk.contains("offsetChars=1000"));
        assertTrue(chunk.length() < 2500);
    }

    private Path createMavenProject(String name, String source) throws Exception {
        Path project = temp.resolve(name);
        Files.createDirectories(project.resolve("src"));
        Files.writeString(project.resolve("pom.xml"), "<project/>\n");
        Files.writeString(project.resolve("src/App.java"), source);
        return project;
    }
}
