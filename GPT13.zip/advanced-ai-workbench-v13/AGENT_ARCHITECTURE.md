# V13 generic agent architecture

## Runtime first

```text
UI (Chat / Analyze / Agent)
          |
          v
Persistent session + active workspace
          |
          v
Generic Agent Runtime
          |
          +-- project instructions (AGENTS.md / compatible files)
          +-- lazy skills (SKILL.md)
          +-- subagents
          +-- native built-in tools
          +-- dynamic MCP tools
          +-- generic LSP
          |
          v
Native model turn
          |
          +-- one or many tool calls
          +-- independent read-only calls may run in parallel
          |
          v
Exact user-selected live workspace
          |
          +-- read/search/edit/write
          +-- build/test/check/bash
          +-- managed processes
          +-- HTTP verification
          +-- attachment resources
          +-- MCP servers
          +-- language servers
          |
          v
Real observations returned to the model
          |
          v
Diagnose -> change -> execute -> observe -> repeat until verified
```

Agent mode does not use a copied project, staging mirror, Git index, or delayed apply phase. File mutations and shell operations are performed against the canonical mapped path subject to permissions.

## Project instructions

V13 discovers root and nested project guidance such as `AGENTS.md` and compatible Claude/OpenCode instruction locations. Nested instructions can be loaded for the specific file/module being changed rather than injecting every instruction file into every turn.

## Skills

Reusable skills are discovered from `.agents/skills`, `.opencode/skills`, and `.claude/skills` compatible directories. The model receives a compact catalog and loads the full `SKILL.md` only when needed.

## Subagents

The primary agent can delegate focused work with `task`. Built-in `explore` uses read-only investigation tools. Built-in `general` can perform broader delegated work. Project-defined subagents can be placed under `.agents/agents`, `.opencode/agents`, or `.claude/agents`.

## MCP

`McpManager` is generic. It discovers configured servers, performs MCP initialization/tool discovery, converts discovered schemas into model tools, namespaces them as `mcp__<server>__<tool>`, and routes calls back to the correct server. The core runtime contains no Playwright- or Vibium-specific logic.

Configuration is read from global and workspace agent configuration, including `.agents/mcp.json`. Only configured/enabled servers expose tools to the model.

## LSP

`LspManager` starts configured language servers generically from `.agents/lsp.json` and provides diagnostics, definition, references, hover, document symbols and workspace symbols. Language-specific logic remains in the configured language server rather than the core agent.

## Long-running tasks

There is no fixed application-side model-turn count, tool-call count, build retry count, or default shell timeout. The runtime continues productive work until verified completion, cancellation, permission denial, provider refusal/limits, or a genuine unrecoverable blocker. Repeated identical calls are still guarded so unlimited work does not become an infinite no-progress loop.

## Verification

Code/configuration mutations mark the run as requiring verification. Build/test/check are built-in verifiers. Shell and HTTP calls can also be marked as verification. Managed processes allow the agent to start an application, inspect output, call it, modify code, restart, and repeat.
