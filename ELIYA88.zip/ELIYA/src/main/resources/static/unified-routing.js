/* ELIYA79: explicit Analyse / Execute modes with an opt-in execution handoff.
 * Analyse is the indexed, read-only Chat engine. Execute is the action-capable Agent.
 * This function never infers execution merely because a question mentions a workspace.
 */
(function (root, factory) {
  const router = factory();
  if (typeof module === 'object' && module.exports) module.exports = router;
  if (root) root.EliyaUnifiedRouting = router;
})(typeof window !== 'undefined' ? window : null, function () {
  'use strict';
  // Important: a request to *describe* how something is implemented is not a request to implement it.
  const EXECUTION = /\b(?:implement|apply|execute|fix|refactor|migrate|deploy|build|modify|edit|update|delete|remove|rollback|run|compile|install|commit|push|merge|develop|configure|set up|setup|generate|create|write|save|export|add)\b/i;
  const NON_ACTION = /\b(?:explain|describe|analyse|analyze|investigate|inspect|check|review|compare|assess|audit|find|search|trace|show|suggest|recommend|draft|propose|design|plan|outline|tell me|what|how|why)\b/i;
  const ARTIFACT = /\b(?:tests?|test cases?|scripts?|source files?|code|documentation|markdown|\.md|\.html|excel|spreadsheet|xlsx|files?|folders?|directory|agents?|skills?|feature|module|migration|application|service)\b/i;
  const PLAN_OR_PROMPT = /\b(?:prompt|plan|proposal|approach|strategy|suggestions?|recommendations?|ideas?|architecture diagram|design proposal)\b/i;
  const CONSENT = /^(?:ok(?:ay)?|yes(?: please)?|please continue|continue|go ahead|proceed|do it|implement it|execute it|apply it|start|yes[,.]? (?:do it|proceed|continue|implement|create|add|fix))[.!?\s]*$/i;
  const EXPLICIT_EXECUTION = /^(?:please\s+)?(?:implement|apply|execute|fix|refactor|migrate|deploy|build|modify|edit|update|delete|remove|rollback|run|compile|install|commit|push|merge|develop|configure|set up|setup|generate|create|write|save|export|add)\b/i;

  // A downloadable document is not a repository mutation. Keep Office artifact
  // creation on a purpose-built artifact lane, even if the user writes "create".
  // If an actual workspace destination is supplied, ordinary agent execution wins.
  function documentArtifactIntent(prompt, attachments = [], hasWorkspace = false) {
    const input = String(prompt || '');
    const hasDoc = (attachments || []).some(file => /\.(docx?|pdf|pptx?|txt|md)$/i.test(file?.name || file?.originalName || '')
      || /(?:wordprocessingml|pdf|presentationml)/i.test(file?.mimeType || ''));
    const target = /\b(?:test\s*cases?|testcases?|test\s*scenarios?)\b/i.test(input);
    const excel = /\b(?:excel|spreadsheet|xlsx)\b/i.test(input);
    const writeRepo = /(?:\b(?:in|into|inside|under|to)\s+(?:the\s+)?(?:workspace|repository|repo|project\s+folder)\b|[A-Z]:[\\/]|\/Users\/|\/home\/)/i.test(input);
    return hasDoc && target && excel && !writeRepo;
  }

  function isExecutionRequest(prompt) {
    const value = String(prompt || '').trim();
    if (!value) return false;
    // 'Create a prompt / phase-wise plan' and 'explain how to fix' are Analyse tasks.
    if (/^(?:please\s+)?(?:create|generate|write|draft|produce|build|design)\b.*\b(?:prompt|plan|proposal|strategy|design proposal)\b/i.test(value)) return false;
    // Composite requests explicitly permit action even if the first verb is "check" or "analyse".
    if (/\b(?:and(?: then| also)?|then|after that)\s+(?:implement|execute|fix|apply|create|generate|modify|update|run)\b/i.test(value)) return true;
    if (/^(?:can you |could you |please |i need |i want (?:to )?)?(?:explain|describe|analyse|analyze|investigate|inspect|review|compare|assess|audit|find|search|trace|suggest|recommend|outline|tell me|what|how|why)\b/i.test(value)) {
      if (!/\b(?:and(?: then| also)?|then|after that)\s+(?:implement|execute|fix|apply|create|generate|modify|update|run)\b/i.test(value)) return false;
    }
    if (EXPLICIT_EXECUTION.test(value)) return true;
    // Contextual action followups are still explicit authorization, even without a
    // leading imperative (e.g. "yes, add both" / "go ahead and implement").
    if (/^(?:yes[, ]+|sure[, ]+|ok(?:ay)?[, ]+)?(?:please\s+)?(?:create|add|implement|fix|execute|apply|generate|update|modify|run|build|write|save|migrate)\b/i.test(value)) return true;
    if (/^(?:go ahead|proceed|continue)\s+(?:and|with)\s+(?:the\s+)?(?:implementation|changes|fix|creation|migration|execution)\b/i.test(value)) return true;
    // 'Can you create an agent?', 'I want you to fix this' are direct work requests.
    if (/\b(?:can you|could you|please|i want you to|i need you to)\s+(?:implement|execute|fix|migrate|run|create|generate|write|modify|update|add|remove|delete|deploy|build|configure|refactor)\b/i.test(value)) return true;
    // Only implicit action forms with a concrete deliverable can escalate from Analyse.
    if (/\b(?:need to|want to|have to)\s+(?:implement|fix|create|generate|execute|write|modify|update|run)\b/i.test(value) && ARTIFACT.test(value) && !PLAN_OR_PROMPT.test(value)) return true;
    return false;
  }

  // ELIYA81: bounded contextual intent interpretation. Explicit actions win, but
  // complex questions and quoted actions never imply permission to mutate files.
  // Ambiguous consent must stay on the read-only path until clarified.
  function interpret({text = '', selectedMode = 'analyse', previousAssistantMode = '', previousAssistantText = '', attachments = []} = {}) {
    const prompt = String(text || '').trim();
    const prior = String(previousAssistantText || '').trim();
    const yes = CONSENT.test(prompt);
    const lastQuestion = (prior.match(/(?:[^.!?\n]*\?)[^?]*$/) || [prior])[0];
    const multipleOptions = /\b(?:or|either|which)\b/i.test(lastQuestion) && /\?/.test(lastQuestion);
    const priorExplicitAction = /\b(?:would you like (?:me )?to|shall i|do you want (?:me )?to)\s+(?:now\s+)?(?:implement|execute|fix|apply|create|generate|add|update|modify|run)\b/i.test(prior);
    if (documentArtifactIntent(prompt, attachments))
      return {engine:'chat',intent:'document-artifact',confidence:1,clarification:false,depth:'artifact',reason:'document-to-Excel generation does not require repository execution'};
    if (selectedMode === 'execute') return {engine:'agent',intent:'execute',confidence:1,clarification:false,depth:'agent',reason:'user explicitly selected Execute'};
    if (yes && multipleOptions) return {engine:'chat',intent:'clarify',confidence:1,clarification:true,depth:'quick',reason:'multiple choices require user selection'};
    if (isExecutionRequest(prompt) || (yes && priorExplicitAction))
      return {engine:'agent',intent:'execute',confidence:isExecutionRequest(prompt)?1:0.93,clarification:false,depth:'agent',reason:'explicit action or contextual consent'};
    const needsDeep = /\b(?:deep|end.to.end|e2e|complete|comprehensive|detailed|full|entire|trace|root cause|all gaps|architecture)\b/i.test(prompt);
    const isPlan = /\b(?:plan|prompt|proposal|approach|phases?|roadmap|strategy)\b/i.test(prompt);
    if (isPlan) return {engine:'chat',intent:'plan',confidence:.92,clarification:false,depth:needsDeep?'deep':'quick',reason:'plan or prompt requested without file changes'};
    if (yes && !priorExplicitAction) return {engine:'chat',intent:'follow-up',confidence:.7,clarification:false,depth:'quick',reason:'no action authorized by prior question'};
    return {engine:'chat',intent:needsDeep?'deep-analysis':'analysis',confidence:needsDeep?.93:.85,clarification:false,depth:needsDeep?'deep':'quick',reason:'read-only indexed investigation'};
  }

  function decide(args = {}) { return interpret(args).engine; }
  // Only genuinely ambiguous turns pay for the optional model call. Direct actions,
  // read-only questions, plans, and short contextual consent remain deterministic.
  function shouldModelAssist(args = {}) {
    const input = String(args.text || '').trim();
    if (args.selectedMode === 'execute' || !input || CONSENT.test(input) || isExecutionRequest(input)) return false;
    if (/^(?:can you|could you|please)?\s*(?:explain|analyse|analyze|check|describe|compare|find|show|create a plan|draft a prompt)\b/i.test(input)) return false;
    return /\b(?:take care of|handle (?:this|these|the)|get (?:this|it) done|sort (?:this|it) out|work on (?:this|the)|do the needful|what should we do with|need some help with|see to it|deal with (?:this|the))\b/i.test(input);
  }
  async function decideWithModel(args = {}, classifier = null) {
    const fallback = decide(args);
    if (!shouldModelAssist(args) || typeof classifier !== 'function') return fallback;
    try {
      const result = await classifier(args);
      // A provider response is advisory. The server enforces explicit action signals too.
      return result && (result.engine === 'chat' || result.engine === 'agent') ? result.engine : fallback;
    } catch (_) { return fallback; }
  }
  return Object.freeze({decide, isExecutionRequest, documentArtifactIntent, interpret, shouldModelAssist, decideWithModel});
});
