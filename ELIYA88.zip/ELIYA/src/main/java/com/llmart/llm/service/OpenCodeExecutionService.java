package com.llmart.llm.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.llmart.llm.dto.ChatRequest;
import jakarta.annotation.PreDestroy;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.time.Duration;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.*;

/**
 * OpenCode 2 HTTP execution adapter. No OpenCode classes or OS-specific shell commands enter ELIYA's core.
 * Remote tool/model work is performed by OpenCode, not reimplemented in this service.
 * The adapter is opt-in, and the existing ELIYA executor remains available for rollback.
 *
 * OpenCode 2 contract: POST /api/session, POST /api/session/{id}/prompt,
 * GET /api/experimental/session/{id}/log?follow=true, POST /api/session/{id}/interrupt.
 */
@Service
public class OpenCodeExecutionService {
    private static final int MAX_EVENTS = 450, MAX_TURNS = 30, MAX_TEXT = 80_000;
    private final ObjectMapper mapper;
    private final ProjectService projects;
    private final HttpClient http = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(3)).build();
    private final ExecutorService readers = Executors.newCachedThreadPool(r -> {
        Thread t = new Thread(r, "eliya-opencode-event"); t.setDaemon(true); return t;
    });
    private final ConcurrentHashMap<String, Session> sessions = new ConcurrentHashMap<>();
    private final Path store = Path.of(System.getProperty("eliya.opencode.sessionStore", "./data/opencode-sessions"))
            .toAbsolutePath().normalize();
    private final URI base;
    private final String authorization;
    private final String executable;
    private final boolean autoStart;
    private final int port;
    private final boolean enabled;
    private volatile Process managedProcess;
    private final Object startLock = new Object();

    public OpenCodeExecutionService(ObjectMapper mapper, ProjectService projects,
            @Value("${eliya.execution.engine:legacy}") String engine,
            @Value("${eliya.opencode.url:http://127.0.0.1:4096}") String url,
            @Value("${eliya.opencode.password:}") String password,
            @Value("${eliya.opencode.executable:opencode}") String executable,
            @Value("${eliya.opencode.auto-start:false}") boolean autoStart) {
        this.mapper = mapper;
        this.projects = projects;
        this.enabled = "opencode".equalsIgnoreCase(engine);
        URI parsed = URI.create(this.enabled ? url : "http://127.0.0.1:4096");
        String host = parsed.getHost();
        if (!"http".equals(parsed.getScheme()) || host == null || parsed.getUserInfo() != null ||
                parsed.getRawQuery() != null || parsed.getRawFragment() != null ||
                !Set.of("localhost", "127.0.0.1", "[::1]", "::1").contains(host.toLowerCase(Locale.ROOT))) {
            throw new IllegalArgumentException("OpenCode server must use loopback HTTP. Remote tool execution is disabled.");
        }
        this.port = parsed.getPort() < 0 ? 80 : parsed.getPort();
        this.base = URI.create("http://127.0.0.1:" + port);
        this.authorization = "Basic " + Base64.getEncoder().encodeToString(
                ("opencode:" + password).getBytes(StandardCharsets.UTF_8));
        this.executable = executable;
        this.autoStart = autoStart;
        try {
            Files.createDirectories(store);
            try (var files = Files.list(store)) {
                files.filter(p -> p.getFileName().toString().endsWith(".json")).limit(300).forEach(p -> {
                    try {
                        JsonNode obj = mapper.readTree(p.toFile());
                        String id = obj.path("id").asText();
                        String remote = obj.path("remoteId").asText();
                        if (!id.matches("oc-[0-9a-f-]{36}") || remote.isBlank()) return;
                        Session session = new Session(id, remote, obj.path("conversationId").asText(),
                                obj.path("projectId").asText(), obj.path("model").asText(),
                                obj.path("fullPrompt").asText());
                        String savedStatus = obj.path("status").asText("interrupted");
                        session.status = Set.of("completed", "failed", "cancelled").contains(savedStatus)
                                ? savedStatus : "interrupted"; // running tasks cannot be assumed complete after restart
                        session.updatedAt = obj.path("updatedAt").asText(Instant.now().toString());
                        if (obj.path("changeReport").isObject()) {
                            @SuppressWarnings("unchecked") Map<String,Object> persistedReport =
                                    mapper.convertValue(obj.path("changeReport"), Map.class);
                            session.changeReport = persistedReport;
                        }
                        sessions.put(id, session);
                    } catch (Exception ignored) { /* corrupt history cannot disable the app */ }
                });
            }
        } catch (Exception ignored) { /* in-memory sessions still supported */ }
    }

    public boolean enabled() { return enabled; }
    public boolean owns(String id) { return id != null && id.startsWith("oc-") && sessions.containsKey(id); }
    public Map<String,Object> engineInfo() {
        Map<String,Object> info = new LinkedHashMap<>();
        info.put("engine", enabled ? "opencode" : "legacy");
        info.put("platform", System.getProperty("os.name"));
        info.put("configured", enabled);
        info.put("connected", false);
        if (!enabled) return info;
        try {
            JsonNode data = request("GET", "/api/info", null);
            requireVersion(data);
            info.put("connected", true);
            info.put("server", data);
        } catch (Exception e) { info.put("reason", safeError(e)); }
        return info;
    }

    /** We deliberately keep ELIYA's attachment/MCP workflow on its existing backend until mapped natively. */
    public boolean accepts(ChatRequest request) {
        return enabled && request != null && request.chatMode() == com.llmart.llm.dto.ChatMode.AGENT
                && (request.attachmentIds() == null || request.attachmentIds().isEmpty())
                && (request.message() == null || !request.message().toLowerCase(Locale.ROOT).matches("(?s).*\\bmcp\\b.*"));
    }

    private void ensureServer() throws Exception {
        try { requireVersion(request("GET", "/api/info", null)); return; }
        catch (Exception e) { if (!autoStart) throw e; }
        synchronized (startLock) {
            try { requireVersion(request("GET", "/api/info", null)); return; }
            catch (Exception ignored) { /* start a managed process once */ }
            if (managedProcess != null && managedProcess.isAlive())
                throw new IllegalStateException("OpenCode started but is not responding on " + base);
            // A separate binary for the current OS/architecture; no WSL and no shell-specific syntax.
            ProcessBuilder pb = new ProcessBuilder(executable, "serve", "--hostname", "127.0.0.1",
                    "--port", String.valueOf(port));
            pb.environment().put("NO_PROXY", "localhost,127.0.0.1,::1");
            pb.environment().put("OPENCODE_PASSWORD", configuredPassword());
            pb.redirectOutput(ProcessBuilder.Redirect.DISCARD);
            pb.redirectError(ProcessBuilder.Redirect.DISCARD);
            managedProcess = pb.start();
            for (int i = 0; i < 30; i++) {
                Thread.sleep(200);
                try { requireVersion(request("GET", "/api/info", null)); return; }
                catch (Exception ignored) { if (!managedProcess.isAlive()) break; }
            }
            throw new IllegalStateException("OpenCode 2 could not start. Check the installed binary and provider configuration.");
        }
    }

    private String configuredPassword() {
        // Only auto-start with a nonempty configured secret. Avoid launching an exposed unauthenticated executor.
        String raw = new String(Base64.getDecoder().decode(authorization.substring(6)), StandardCharsets.UTF_8);
        String pass = raw.substring("opencode:".length());
        if (pass.length() < 16) throw new IllegalStateException("Set ELIYA_OPENCODE_PASSWORD (16+ characters) before auto-starting OpenCode");
        return pass;
    }

    private static void requireVersion(JsonNode response) {
        JsonNode data = response.path("data").isMissingNode() ? response : response.path("data");
        String version = data.path("version").asText("");
        if (!version.isBlank() && !version.startsWith("2."))
            throw new IllegalStateException("OpenCode 2 required, found " + version);
    }

    private JsonNode request(String method, String path, Object body) throws Exception {
        HttpRequest.Builder b = HttpRequest.newBuilder(base.resolve(path))
                .timeout(Duration.ofSeconds(30))
                .header("Authorization", authorization)
                .header("Accept", "application/json");
        if (body != null) b.header("Content-Type", "application/json");
        if ("GET".equals(method)) b.GET();
        else b.method(method, body == null ? HttpRequest.BodyPublishers.noBody() :
                HttpRequest.BodyPublishers.ofString(mapper.writeValueAsString(body)));
        HttpResponse<String> result = http.send(b.build(), HttpResponse.BodyHandlers.ofString());
        if (result.statusCode() >= 300 || result.statusCode() < 200)
            throw new IllegalStateException("OpenCode HTTP " + result.statusCode() + " on " + path);
        if (result.body() == null || result.body().isBlank()) return mapper.createObjectNode();
        return mapper.readTree(result.body());
    }

    private static JsonNode unwrap(JsonNode result) { return result.has("data") ? result.path("data") : result; }
    private static String safeError(Exception e) {
        String message = e.getClass().getSimpleName();
        if (e instanceof java.net.ConnectException) return "OpenCode 2 is not running on loopback";
        if (e instanceof java.net.http.HttpTimeoutException) return "OpenCode connection timed out";
        return message + ": " + String.valueOf(e.getMessage()).replaceAll("(?i)(password|token|secret)=\\S+", "$1=[REDACTED]");
    }

    public Map<String,Object> launch(ChatRequest request, String handoff) {
        if (!accepts(request)) throw new IllegalArgumentException("This instruction requires the ELIYA execution engine");
        if (request.message() == null || request.message().isBlank()) throw new IllegalArgumentException("Instruction is required");
        if (request.projectId() == null || request.projectId().isBlank())
            throw new IllegalArgumentException("Choose a mapped workspace");
        try {
            var project = projects.require(request.projectId());
            if (!project.hasLocalPath()) throw new IllegalArgumentException("Local workspace required");
            Path root = Path.of(project.getLocalPath()).toRealPath();
            if (!Files.isDirectory(root)) throw new IllegalArgumentException("Workspace is not a directory");
            ensureServer();
            // Enforce project-only access at OpenCode's tool boundary, not merely by prompt instruction.
            List<Map<String,String>> permissions = new ArrayList<>();
            permissions.add(rule("*", "*", "allow"));
            permissions.add(rule("external_directory", "*", "deny"));
            permissions.add(rule("*mcp*", "*", "deny")); // gate MCP tools without blocking unrelated underscore-named tools
            permissions.add(rule("opencode_list_mcp_resources", "*", "deny"));
            permissions.add(rule("opencode_read_mcp_resource", "*", "deny"));
            for (String cmd : List.of("rm *", "rmdir *", "del *", "Remove-Item *", "git push *",
                    "git reset --hard *", "git clean *", "sudo *"))
                permissions.add(rule("shell", cmd, "deny"));
            JsonNode created = unwrap(request("POST", "/api/session", Map.of(
                    "title", shortText(request.message(), 90),
                    "location", Map.of("directory", root.toString()), "permissions", permissions)));
            String remoteId = created.path("id").asText();
            if (!remoteId.matches("[A-Za-z0-9_-]{3,128}")) throw new IllegalStateException("Missing OpenCode session ID");
            String localId = "oc-" + UUID.randomUUID();
            Session session = new Session(localId, remoteId,
                    UUID.randomUUID().toString(), request.projectId(),
                    request.settings() == null ? "OpenCode configured model" : request.settings().model(), request.message());
            sessions.put(localId, session);
            persist(session);
            beginReader(session);
            String instruction = (handoff == null || handoff.isBlank()) ? request.message()
                    : "Context from the preceding ELIYA analysis (for reference only):\n" + shortText(handoff, 4000)
                    + "\n\nCurrent user instruction (authoritative):\n" + request.message();
            submit(session, instruction);
            return session.snapshot();
        } catch (Exception e) { throw new IllegalStateException("OpenCode launch failed: " + safeError(e), e); }
    }

    private static Map<String,String> rule(String action, String resource, String effect) {
        return Map.of("action", action, "resource", resource, "effect", effect);
    }

    private void submit(Session session, String prompt) throws Exception {
        synchronized (session) {
            session.status = "running";
            session.changeReport = Map.of();
            session.answer = "";
            session.turns.addLast(Map.of("role", "user", "content", shortText(prompt, MAX_TEXT)));
            while (session.turns.size() > MAX_TURNS) session.turns.removeFirst();
            session.push("turn_start", Map.of("detail", "OpenCode accepted the task"));
        }
        persist(session);
        try {
            request("POST", "/api/session/" + session.remoteId + "/prompt", Map.of("text", prompt));
            beginReader(session); // reconnect if a previous event stream closed while the tab was idle
        } catch (Exception e) {
            session.status = "failed";
            session.error = safeError(e);
            session.push("error", Map.of("detail", session.error));
            persist(session);
            throw e;
        }
    }
    public Map<String,Object> message(String id, ChatRequest request) {
        Session session = require(id);
        if (request == null || request.message() == null || request.message().isBlank())
            throw new IllegalArgumentException("Message required");
        if (!Objects.equals(session.projectId, request.projectId()))
            throw new IllegalArgumentException("OpenCode session belongs to another workspace. Open a new tab.");
        if (!accepts(request)) throw new IllegalArgumentException("Use ELIYA Analyse or MCP workflow in a separate tab");
        try { submit(session, request.message()); return session.snapshot(); }
        catch (Exception e) { throw new IllegalStateException("Could not send instruction to OpenCode", e); }
    }

    public Map<String,Object> cancel(String id) {
        Session s = require(id);
        try {
            request("POST", "/api/session/" + s.remoteId + "/interrupt?resume=false", null);
            s.status = "cancelled";
            s.push("stopped", Map.of("detail", "OpenCode execution interrupted"));
            persist(s);
        } catch (Exception e) { s.error = safeError(e); persist(s); }
        return s.snapshot();
    }

    private void beginReader(Session s) {
        if (s.reading) return;
        s.reading = true;
        readers.execute(() -> {
            try {
                // This experimental endpoint replays durable history then follows new events.
                HttpRequest req = HttpRequest.newBuilder(base.resolve("/api/experimental/session/" + s.remoteId + "/log?follow=true"))
                        .timeout(Duration.ofHours(12)).header("Authorization", authorization)
                        .header("Accept", "text/event-stream").GET().build();
                HttpResponse<InputStream> response = http.send(req, HttpResponse.BodyHandlers.ofInputStream());
                if (response.statusCode() != 200) throw new IllegalStateException("OpenCode events HTTP " + response.statusCode());
                try (BufferedReader in = new BufferedReader(new InputStreamReader(response.body(), StandardCharsets.UTF_8))) {
                    String line, type = "", id = "";
                    StringBuilder data = new StringBuilder();
                    while (!Thread.currentThread().isInterrupted() && (line=in.readLine()) != null) {
                        if (line.isEmpty()) {
                            if (!data.isEmpty()) readEvent(s, type, id, data.toString());
                            type = ""; id = ""; data.setLength(0);
                        } else if (line.startsWith("event:")) type=line.substring(6).trim();
                        else if (line.startsWith("id:")) id=line.substring(3).trim();
                        else if (line.startsWith("data:") && data.length() < 2_000_000) {
                            if (!data.isEmpty()) data.append('\n'); data.append(line.substring(5).trim());
                        }
                    }
                }
            } catch (Exception e) {
                if ("running".equals(s.status)) {
                    s.push("agent_step", Map.of("tool", "connection", "status", "warning",
                            "detail", "Event stream disconnected; OpenCode execution may still be running"));
                    persist(s);
                }
            } finally { s.reading = false; }
        });
    }

    private void readEvent(Session s, String eventType, String eventId, String raw) {
        try {
            JsonNode outer = mapper.readTree(raw);
            // OpenCode 2 SessionLogItemEncoded is a JSON string (not a JSON object).
            if (outer.isTextual()) outer = mapper.readTree(outer.asText());
            JsonNode node = outer.has("properties") ? outer.path("properties") :
                    outer.has("data") ? outer.path("data") : outer;
            String type = outer.path("type").asText(outer.path("event").asText(eventType));
            if (type.equals("message") || type.equals("log"))
                type = node.path("event").asText(node.path("type").asText(type));
            if (eventId.isBlank()) eventId = outer.path("id").asText("");
            synchronized (s) {
                if (!eventId.isBlank() && !s.seenIds.add(eventId)) return;
                if (s.seenIds.size() > 20000) s.seenIds.clear();
                if (type.endsWith("text.delta")) {
                    String delta = node.path("text").asText(node.path("delta").asText(""));
                    if (delta.isBlank()) delta = node.path("content").asText("");
                    if (!delta.isEmpty()) {
                        s.answer = shortText(s.answer + delta, MAX_TEXT);
                        s.push("token", Map.of("text", shortText(delta, 8000)));
                    }
                } else if (type.contains("tool.") || type.contains("step.")) {
                    String tool = node.path("tool").asText(node.path("name").asText(type));
                    String state = type.endsWith("failed") ? "error" : type.endsWith("success") ? "success" : "running";
                    s.push("agent_step", Map.of("tool", shortText(tool, 80), "status", state,
                            "detail", shortText(type, 120)));
                } else if (type.contains("usage.updated")) {
                    s.usage = node;
                } else if (type.endsWith("execution.succeeded")) {
                    s.status = "completed";
                    s.finishTurn();
                    s.push("done", Map.of("status", "completed"));
                } else if (type.endsWith("execution.failed")) {
                    s.status = "failed";
                    s.error = shortText(node.path("message").asText("OpenCode execution failed"), 700);
                    s.push("error", Map.of("detail", s.error));
                } else if (type.endsWith("execution.interrupted")) {
                    s.status = "cancelled";
                    s.push("stopped", Map.of("detail", "Execution interrupted"));
                } else if (type.equals("form.created") || type.equals("permission.asked")) {
                    s.status = "needs_input";
                    s.question = Map.of("kind", "clarification", "id", node.path("id").asText(),
                            "reason", node.path("title").asText("OpenCode requires your input"));
                    s.push("agent_step", Map.of("tool", "question", "status", "approval",
                            "detail", "OpenCode needs a response"));
                }
            }
            if (type.endsWith("execution.succeeded") || type.endsWith("execution.failed")) {
                refreshAnswer(s);
                captureChangeReport(s);
            }
            // Do not synchronously write a session JSON file for every streamed token.
            // The file stores only resumable references, not token-level transcripts.
            if (type.endsWith("execution.succeeded") || type.endsWith("execution.failed") ||
                type.endsWith("execution.interrupted") || type.equals("form.created") ||
                type.equals("permission.asked")) persist(s);
        } catch (Exception ignored) { /* invalid/non-session events never break activity rendering */ }
    }

    private void refreshAnswer(Session s) {
        try {
            JsonNode response = unwrap(request("GET", "/api/session/" + s.remoteId + "/message?type=assistant&order=desc&limit=5", null));
            JsonNode items = response.isArray() ? response : response.path("items");
            if (!items.isArray()) items = response.path("messages");
            for (JsonNode item : items) {
                JsonNode message = item.path("info").isObject() ? item.path("info") : item;
                if (!"assistant".equals(message.path("role").asText(message.path("type").asText()))) continue;
                JsonNode parts = item.path("parts");
                StringBuilder answer = new StringBuilder();
                if (parts.isArray()) for (JsonNode part : parts) {
                    if ("text".equals(part.path("type").asText())) answer.append(part.path("text").asText());
                }
                if (answer.length()>0) { s.answer = shortText(answer.toString(), MAX_TEXT); s.finishTurn(); }
                break;
            }
        } catch (Exception ignored) { /* live text stream remains available */ }
    }

    /** Use OpenCode's recorded per-turn file diffs rather than inventing files from a model narrative.
     * Diff retrieval failures do not change the execution result, but remain visible to the user. */
    private void captureChangeReport(Session s) {
        Map<String,Object> result = new LinkedHashMap<>();
        result.put("status", s.status);
        result.put("objective", shortText(s.originalPrompt, 1200));
        result.put("verification", "File list from OpenCode's session diff; build/test verification is separate");
        List<Map<String,Object>> files = new ArrayList<>();
        int created=0, modified=0, deleted=0;
        try {
            // OpenCode v2 defaults to the most recent turn, avoiding old-session diffs.
            JsonNode diffs = unwrap(request("GET", "/api/session/" + s.remoteId + "/diff?context=3", null));
            if (!diffs.isArray()) throw new IllegalStateException("OpenCode returned no per-file diff list");
            for (JsonNode diff : diffs) {
                if (files.size() >= 100) break;
                String action = diff.path("status").asText("modified");
                if ("added".equals(action)) created++;
                else if ("deleted".equals(action)) deleted++;
                else modified++;
                Map<String,Object> file = new LinkedHashMap<>();
                file.put("action", action);
                file.put("relativePath", shortText(diff.path("file").asText(""), 450));
                file.put("detail", "+" + diff.path("additions").asInt(0) + " / -" + diff.path("deletions").asInt(0) + " lines");
                file.put("reason", "Modified during execution of the requested task; specific intent must be confirmed against the diff");
                file.put("excerpt", shortText(diff.path("patch").asText(""), 2000));
                files.add(file);
            }
            result.put("filesVerified", true);
            if (diffs.size() > files.size()) result.put("fileReportWarning", "Showing first 100 changed files only; inspect the repository for the full diff");
        } catch (Exception e) {
            result.put("filesVerified", false);
            result.put("fileReportWarning", "OpenCode per-file diff could not be retrieved: " + safeError(e));
        }
        result.put("created", created); result.put("modified", modified); result.put("deleted", deleted);
        result.put("files", files);
        s.changeReport = result;
        synchronized (s) { s.push("change_report", Map.of("files", files.size(), "verified", Boolean.TRUE.equals(result.get("filesVerified")))); }
    }

    public Map<String,Object> answer(String id, String questionId, String choice, String detail) {
        Session s = require(id);
        if (questionId == null || !questionId.equals(s.question.get("id")))
            throw new IllegalArgumentException("Question has expired");
        try {
            String remote = s.remoteId;
            String answer = detail == null || detail.isBlank() ? choice : detail;
            if (answer == null || answer.isBlank()) throw new IllegalArgumentException("Answer is required");
            // Form replies and permission responses use different documented endpoints.
            if ("once".equalsIgnoreCase(choice) || "always".equalsIgnoreCase(choice) || "reject".equalsIgnoreCase(choice)) {
                request("POST", "/api/session/" + remote + "/permission/" + questionId + "/reply",
                        Map.of("decision", choice.toLowerCase(Locale.ROOT)));
            } else {
                JsonNode info = unwrap(request("GET", "/api/session/" + remote + "/form/" + questionId, null));
                String fieldKey = "answer";
                JsonNode fields = info.path("fields");
                if (fields.isArray()) for (JsonNode field : fields) {
                    if ("string".equals(field.path("type").asText())) {
                        fieldKey = field.path("key").asText("answer"); break;
                    }
                }
                request("POST", "/api/session/" + remote + "/form/" + questionId + "/reply",
                        Map.of("answer", Map.of(fieldKey, answer)));
            }
            s.status = "running"; s.question = Map.of(); persist(s);
            return Map.of("answered", true);
        } catch (Exception e) { throw new IllegalStateException("OpenCode question response failed: " + safeError(e), e); }
    }

    public Map<String,Object> get(String id) { return require(id).snapshot(); }
    public List<Map<String,Object>> list() {
        return sessions.values().stream().sorted(Comparator.comparing((Session s)->s.updatedAt).reversed())
                .map(Session::snapshot).toList();
    }
    public Map<String,Object> activity(String id, Long before, Integer limit) {
        Session s = require(id);
        List<Map<String,Object>> events;
        synchronized (s) {
            events = s.events.stream().filter(e -> before == null || ((Number)e.get("seq")).longValue() < before).toList();
        }
        int count = Math.min(Math.max(limit == null ? 150 : limit, 1), 500);
        boolean more = events.size()>count;
        return Map.of("events", more ? events.subList(events.size()-count,events.size()) : events,
                "hasMore", more, "truncated", false, "journalError", false);
    }
    public SseEmitter stream(String id) {
        Session s = require(id);
        SseEmitter emitter = new SseEmitter(0L);
        if (s.viewers.size() >= 6) throw new IllegalStateException("Too many OpenCode viewers");
        s.viewers.add(emitter);
        emitter.onCompletion(() -> s.viewers.remove(emitter));
        emitter.onTimeout(() -> s.viewers.remove(emitter));
        emitter.onError(err -> s.viewers.remove(emitter));
        try { emitter.send(SseEmitter.event().name("terminal").data(Map.of("type", "resync"))); }
        catch (Exception ignored) { s.viewers.remove(emitter); }
        return emitter;
    }
    private Session require(String id) {
        Session s = sessions.get(id);
        if (s == null) throw new NoSuchElementException("OpenCode session not found");
        return s;
    }
    private void persist(Session s) {
        try {
            Files.createDirectories(store);
            Path temp = store.resolve(s.id + ".json.tmp");
            synchronized (s) { mapper.writeValue(temp.toFile(), s.snapshotForDisk()); }
            try { Files.move(temp, store.resolve(s.id + ".json"), StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (AtomicMoveNotSupportedException e) { Files.move(temp, store.resolve(s.id + ".json"), StandardCopyOption.REPLACE_EXISTING); }
        } catch (Exception ignored) { /* log failure must not interrupt OpenCode */ }
    }
    private static String shortText(String value,int max) { return value == null ? "" : value.length() <= max ? value : value.substring(value.length()-max); }

    private static final class Session {
        final String id, remoteId, conversationId, projectId, model, originalPrompt, createdAt=Instant.now().toString();
        final Deque<Map<String,String>> turns = new ArrayDeque<>();
        final Deque<Map<String,Object>> events = new ArrayDeque<>();
        final Set<String> seenIds = new HashSet<>();
        final CopyOnWriteArrayList<SseEmitter> viewers = new CopyOnWriteArrayList<>();
        volatile String status="queued", error="", answer="", updatedAt=createdAt;
        volatile boolean reading;
        volatile Map<String,String> question=Map.of();
        volatile JsonNode usage;
        volatile Map<String,Object> changeReport = Map.of();
        long sequence;
        Session(String id, String remoteId, String conversationId, String projectId, String model, String prompt) {
            this.id=id;this.remoteId=remoteId;this.conversationId=conversationId;
            this.projectId=projectId;this.model=model;this.originalPrompt=prompt;
        }
        synchronized void finishTurn() {
            if (!answer.isBlank() && (turns.isEmpty() || !"assistant".equals(turns.peekLast().get("role")))) {
                turns.addLast(Map.of("role","assistant","content",shortText(answer,MAX_TEXT)));
                while(turns.size()>MAX_TURNS) turns.removeFirst();
            }
        }
        synchronized void push(String type, Map<String,Object> data) {
            sequence++; updatedAt=Instant.now().toString();
            Map<String,Object> event = new LinkedHashMap<>();
            event.put("seq",sequence);event.put("type",type);
            if ("token".equals(type)) event.put("text",data.getOrDefault("text",""));
            else event.put("data",data);
            if (!"token".equals(type)) {
                events.addLast(event);
                while(events.size()>MAX_EVENTS) events.removeFirst();
            }
            // Only sanitized activity is sent to ELIYA, no provider headers or raw tool arguments.
            for (SseEmitter emitter : viewers) {
                try { emitter.send(SseEmitter.event().name("terminal").data(event)); }
                catch (Exception ignored) { viewers.remove(emitter); emitter.complete(); }
            }
        }
        synchronized Map<String,Object> snapshotForDisk() {
            Map<String,Object> disk = new LinkedHashMap<>(Map.of("id",id,"remoteId",remoteId,"conversationId",conversationId,"projectId",projectId,
                    "model",model==null?"":model,"fullPrompt",shortText(originalPrompt,MAX_TEXT),"updatedAt",updatedAt));
            disk.put("status", status);
            disk.put("changeReport",changeReport);
            return disk;
        }
        synchronized Map<String,Object> snapshot() {
            Map<String,Object> result=new LinkedHashMap<>();
            result.put("id",id); result.put("engine","opencode"); result.put("remoteId",remoteId);
            result.put("conversationId",conversationId); result.put("projectId",projectId);
            result.put("mode","agent");result.put("model",model);result.put("prompt",shortText(originalPrompt,120));
            result.put("fullPrompt",originalPrompt);result.put("createdAt",createdAt);result.put("updatedAt",updatedAt);
            result.put("status",status);result.put("error",error);result.put("answer",answer);
            result.put("turns",List.copyOf(turns));result.put("events",List.copyOf(events));
            result.put("sequence",sequence);result.put("question",question);result.put("queue",List.of());
            result.put("queueCount",0);result.put("queuePaused",false);result.put("runId","");
            result.put("referenceProjectIds",List.of());result.put("referenceProjectNames",Map.of());
            result.put("progress",Map.of("progressPhase",status,"progressDetail",status.equals("running") ? "OpenCode is executing the task" : status,
                    "progressPercent",status.equals("completed")?100:status.equals("running")?50:0));
            result.put("usage", usage == null ? Map.of() : usage);
            result.put("changeReport", changeReport);
            return result;
        }
    }

    @PreDestroy public void shutdown() {
        readers.shutdownNow();
        if (managedProcess != null && managedProcess.isAlive()) managedProcess.destroy();
        for (Session s : sessions.values()) for (SseEmitter e : s.viewers) e.complete();
    }
}
