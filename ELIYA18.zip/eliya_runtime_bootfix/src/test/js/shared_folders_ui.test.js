'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const script = fs.readFileSync(path.join(__dirname, '../../main/resources/static/app.js'), 'utf8');
const helpersFrom = script.indexOf('function validReferenceName(');
const helpersTo = script.indexOf('const state =', helpersFrom);
const from = script.indexOf('const ACTIVE_LOCAL_WORKSPACE_KEY =');
const to = script.indexOf('function rememberActiveLocalWorkspace(', from);
assert.ok(from > 0 && to > from, 'Shared folder functions must be present');
const sharedFolderFunctions = script.slice(helpersFrom, helpersTo) + '\n' + script.slice(from, to);

function setup() {
  const saved = {};
  const nodes = new Map();
  const $ = id => {
    if (!nodes.has(id)) nodes.set(id, {disabled: false, textContent: '', innerHTML: '',
      classList: {toggle() {} }});
    return nodes.get(id);
  };
  const project = { id:'primary', name:'app', localPath:'/src/app', localWorkspace:true, fileCount:1002 };
  const reference = { id:'ref1', name:'library', localPath:'/src/library', localWorkspace:true, fileCount:300 };
  const scope = {
    state: {conversationId: null, streaming:false, project:null, referenceProjects:[]},
    $, window: {prompt: () => null}, toast: () => {},
    storageSet: (_, key, value) => { saved[key] = value; },
    storageGet: (_, key) => saved[key] || null,
    esc: text => String(text),
    async ensureConversation() { scope.state.conversationId='conversation-1'; },
    async api(url, options) {
      assert.equal(url, '/api/projects/local');
      assert.equal(options.method, 'POST');
      assert.equal(JSON.parse(options.body).conversationId, 'conversation-1');
      const inputPath = JSON.parse(options.body).path;
      return inputPath === '/src/app' ? project : inputPath === '/src/library' ? reference :
        Promise.reject(Error('Invalid directory'));
    },
    rememberActiveLocalWorkspace: () => {}, renderProjectBar: () => {}
  };
  vm.runInNewContext(sharedFolderFunctions, scope);
  return {scope, saved, $, project, reference};
}

test('project selection persists the writable workspace for Chat and Agent', async () => {
  const {scope, $} = setup();
  await vm.runInNewContext('registerFolder("/src/app", false)', scope);
  assert.equal(scope.state.project.id, 'primary');
  assert.match($('sharedFolderStatus').textContent, /1002 files indexed/);
  assert.equal($('browseProjectBtn').disabled, false);
});

test('reference selection stays separate and persists as shared read-only context', async () => {
  const {scope, saved, $} = setup();
  await vm.runInNewContext('registerFolder("/src/app", false)', scope);
  await vm.runInNewContext('registerFolder("/src/library", true)', scope);
  assert.equal(scope.state.project.id, 'primary');
  assert.equal(scope.state.referenceProjects[0].id, 'ref1');
  assert.match($('referenceFolderList').innerHTML, /read-only/);
  assert.match(saved['llm.sharedReferenceProjects'], /ref1/);
  await assert.rejects(() => vm.runInNewContext('registerFolder("/src/app", true)', scope), /active project/);
});


test('custom reference names are persisted, shown and validated for prompt use', async () => {
  const {scope, saved, $} = setup();
  await vm.runInNewContext('registerFolder("/src/library", true, "LegacySelenium")', scope);
  assert.equal(scope.state.referenceProjects[0].name, 'LegacySelenium');
  assert.match($('referenceFolderList').innerHTML, /LegacySelenium/);
  assert.match($('referenceFolderList').innerHTML, /data-rename-reference/);
  assert.match(saved['llm.sharedReferenceProjects'], /LegacySelenium/);
  await assert.rejects(() => vm.runInNewContext('registerFolder("/src/library", true, "bad name!")', scope), /Invalid or duplicate/);
});

test('reference name can be changed without reindexing or changing its path', async () => {
  const {scope, $, saved} = setup();
  await vm.runInNewContext('registerFolder("/src/library", true, "Before")', scope);
  const originalId = scope.state.referenceProjects[0].id;
  const originalPath = scope.state.referenceProjects[0].path;
  scope.window.prompt = () => 'After';
  const newName = vm.runInNewContext('chooseReferenceName("/src/library", "ref1", "Before")', scope);
  scope.state.referenceProjects[0].name = newName;
  vm.runInNewContext('saveReferenceFolders()', scope);
  assert.equal(scope.state.referenceProjects[0].id, originalId);
  assert.equal(scope.state.referenceProjects[0].path, originalPath);
  assert.match($('referenceFolderList').innerHTML, /After/);
  assert.match(saved['llm.sharedReferenceProjects'], /After/);
});

test('duplicate reference names are rejected but the same folder may be reselected', async () => {
  const {scope} = setup();
  await vm.runInNewContext('registerFolder("/src/library", true, "LegacySelenium")', scope);
  assert.equal(vm.runInNewContext('referenceNameInUse("legacyselenium", null, "/src/app")', scope), true);
  assert.equal(vm.runInNewContext('referenceNameInUse("legacyselenium", null, "/src/library")', scope), false);
  await vm.runInNewContext('registerFolder("/src/library", true, "LegacySelenium")', scope);
  assert.equal(scope.state.referenceProjects.length, 1);
});
