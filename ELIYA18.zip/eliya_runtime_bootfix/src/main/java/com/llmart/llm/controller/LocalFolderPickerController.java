package com.llmart.llm.controller;

import jakarta.servlet.http.HttpServletRequest;
import org.springframework.web.bind.annotation.*;

import javax.swing.JFileChooser;
import javax.swing.SwingUtilities;
import java.awt.GraphicsEnvironment;
import java.net.InetAddress;
import java.nio.file.Path;
import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;

/** Native folder chooser on the SAME desktop where the ELIYA Java process is running. */
@RestController
@RequestMapping("/api/local-folders")
public class LocalFolderPickerController {
    @PostMapping("/browse")
    public Map<String, Object> browse(HttpServletRequest request) throws Exception {
        String host = request.getRemoteAddr();
        if (!InetAddress.getByName(host).isLoopbackAddress())
            throw new SecurityException("Local folder selection is available only on the machine running ELIYA");
        String origin = request.getHeader("Origin");
        if (origin != null && !origin.isBlank() && !origin.equals(request.getScheme() + "://" + request.getHeader("Host")))
            throw new SecurityException("Cross-origin folder selection is not allowed");
        if (GraphicsEnvironment.isHeadless())
            throw new IllegalStateException("No desktop folder picker is available in headless mode. Use Enter path.");
        AtomicReference<Path> selected = new AtomicReference<>();
        Runnable open = () -> {
            JFileChooser chooser = new JFileChooser();
            chooser.setDialogTitle("Select ELIYA folder");
            chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
            chooser.setMultiSelectionEnabled(false);
            if (chooser.showOpenDialog(null) == JFileChooser.APPROVE_OPTION)
                selected.set(chooser.getSelectedFile().toPath().toAbsolutePath().normalize());
        };
        if (SwingUtilities.isEventDispatchThread()) open.run();
        else SwingUtilities.invokeAndWait(open);
        return selected.get() == null ? Map.of("cancelled", true) : Map.of("path", selected.get().toRealPath().toString());
    }
}
