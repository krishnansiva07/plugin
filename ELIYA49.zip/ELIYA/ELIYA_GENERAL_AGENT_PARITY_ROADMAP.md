# Eliya — General-Purpose Agent Roadmap and OpenCode Comparison Contract

**Vision:** An independent, secure, fast and reliable Java 17 agent for analysis, development, testing, reviews, documents and enterprise work. Eliya should aim to outperform OpenCode in measurable user workflows **without relying on OpenCode at runtime**. Dominance in every area is a product objective, not a status we can claim without tests.

## Preserve as product differentiators

- Explicit user-editable plan approval and controlled execution.
- Fast responsive Chat analysis -> manually reviewed task prompt -> Agent implementation workflow.
- Strongly bounded selected workspaces and read-only reference projects.
- Explicit MCP token gating and disabled-means-disabled semantics.
- Per-file deletion authorization, 60-second stop-and-rollback behaviour, last-operation undo.
- Multi-file code-flow retrieval and indexed evidence from UI, API and data layers.
- Prompt-first documentation with selected template only when the user chooses one.
- Word, PDF, spreadsheet and presentation output where requested.
- Java 17 single-JAR distribution suitable for restricted enterprise desktops.

## Phase 1 — Security, agent protocol, reliability (P0)

- Complete the role-policy parser with validation of nested action/resource globs (never silently widen scope).
- Add an explicit `SubagentJob` domain: job ID, parent run, role, status, activity, tool budget, timeout, cancellation, result and error.
- Durable persisted child handoff contract: requirement/evidence/allowed tools/target paths/acceptance criteria/results/changed paths.
- Enforce one owner for each writable path and reserve mutation locks across agents.
- Keep role constraints effective for **every** tool, including aliases, dynamic tool discovery, MCP and shell operations.
- Write negative-security and adversarial prompt tests; exercise user denial, timeout, cancellation and rollback.
- Split `AgentService` into runner, planner, verifier, permission enforcer, context manager, and subagent job coordinator behind stable interfaces.

**Exit gate:** no read-only role can modify workspace or external resources through any supported tool; every job has durable terminal outcome; no user permission is bypassed.

## Phase 2 — Long-task persistence and speed (P0/P1)

- Isolate subagent sessions with independent history, compaction, checkpoints, cancellation and per-agent token limits.
- Resume after process restart from task/step evidence rather than replaying entire context.
- Incremental lexical+symbol+embedding indexing; hybrid retrieval by file, symbol and cross-module call/data flow.
- Bounded/background indexing; Chat remains responsive while Agent scans repositories.
- Parallelize read-only retrieval/subagent analysis only; serialize colliding file writes.
- Streaming progress events and structured diagnostics at child and parent levels.
- Implement repair/rerun focused on failing tests and changed modules, not all repository tests.

**Exit gate:** on test repositories of 1k, 3k, 10k+ files, reproduce correct evidence, bounded latency and reliable cancellation without expanding the workspace root.

## Phase 3 — Developer experience and interoperability (P1)

- Optional disposable Git worktrees and feature branches with an explicit merge/accept review gate.
- Git/GitLab/GitHub change previews, code review evidence, checkpoints and reversible diffs.
- Plugin/skill interface with narrow permissions and a signed/trusted catalog; compatible with existing MCP permission semantics.
- Language-server integration improvements, terminal lifecycle, PTY sessions on Windows, long-running command output streaming.
- Per-role model routing only from configured approved models, credentials never copied into agent files.
- Multi-agent UI: job lineage, status, role, relevant evidence, diff, costs and replayable handoff trail.

**Exit gate:** a feature can be developed, verified, inspected and accepted without invisible edits or duplicate shared-file writes.

## Phase 4 — Broad general-purpose workflows (P2)

- Developer, researcher, analyst, tester, reviewer, architect and documentation agents as selectable *capabilities*, not mandatory steps.
- Better multimodal input grounding (images, PDFs, scans), source-cited reports and editable Office outputs.
- Enterprise connector adapters and policy-based read/write separation.
- Context-sensitive planning: simple requests get direct execution; complicated ones get explicit staged plan review.
- Policy/audit export suitable for enterprise usage without leaking tokens, credentials or private data.
- Cross-platform single-JAR install, update and compatibility matrix for Java 17/Windows/Linux.

**Exit gate:** all supported workflows pass a documented capability and security matrix.

## Objective benchmark harness (necessary before saying Eliya beats OpenCode)

| Workload | Measurements | Pass / comparative goal |
|---|---|---|
| Small code fix | correctness, elapsed time, model tokens | correct patch; compare time/cost under same model |
| Multi-file feature | functional acceptance and regression tests | passing tests with evidence, no unrelated changes |
| Large codebase Q&A | answer accuracy, source grounding, latency | better/at least equal accuracy; no UI freezes |
| Cross-layer flow tracing | precision of UI/API/data dependency map | correct end-to-end links and KPI/alert logic |
| MCP integration | latency, full result capture, gating | no calls when disabled; accurate read-only classification |
| Long-running task | recovery after injected provider failures | resumes without duplicate mutation or lost context |
| Security | adversarial approval, deletion, shell, path traversal | zero unauthorized writes or permission escalation |
| Documents | user prompt compliance and output validation | all requested outputs, no imposed templates |
| Windows operation | startup/installation/PTY/shell handling | Java 17 single JAR works on restricted machines |
| Multi-agent lifecycle | cancellation, read/write contention, handoff evidence | deterministic job status, no concurrent write conflicts |

**Benchmark fairness:** use the same model/provider and budgets, matching codebases, equal tools/permissions and an identical acceptance harness. Run repeated trials with p50/p95 latency and failure rates; publish unresolved defects. One pass is not a superiority claim.

## Compatibility regression checklist

1. Chat remains fast, Chat never performs user-unapproved code edits.
2. Agent planning and user-modified plan approval still work.
3. `.agents` roles do not require OpenCode or any other external CLI.
4. MCP unchecked or prompt lacking explicit MCP reference results in no MCP use.
5. Document templates remain user-select only.
6. Rollback, deletion approvals and snapshot restore continue to work.
7. Reference roots remain read-only; accidental C:\\ indexing is rejected.
8. Builds, tests, verification and failure summaries cite actual tool results.
9. Java 17 compilation, packaging and Windows launch must pass before distribution.
