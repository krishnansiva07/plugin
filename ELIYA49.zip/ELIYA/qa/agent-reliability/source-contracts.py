import sys
from pathlib import Path
base=Path(sys.argv[1]); w=(base/'AgentWorkspaceService.java').read_text(); a=(base/'AgentService.java').read_text(); p=(base/'ProtectedRunSnapshotService.java').read_text()
assert 'createChangeJournal(root, file -> {' in w and 'baselineHashes.putIfAbsent(key, sha256File(file, guard))' in w
assert 'snapshotBaselineTree(ws, root, "", guard)' in w
assert 'guard.directory()' in w and 'guard.file(attrs.size())' in w
assert 'makeWrappersExecutable(root)' in w
assert 'Long.getLong("eliya.agent.commandTimeoutSeconds", 900L)' in w
assert 'run::checkCancelled, detail -> {' in a
assert 'stageProgress.accept(stepEvent(0, "workspace_resolution"' in a
assert 'stageProgress.accept(stepEvent(0, "protected_snapshot"' in a
assert 'futures.get(k).cancel(true)' in a
assert 'boundedPlanningEvidence(() -> workspaceRetrieval.retrieveHybrid(' in a
assert 'stopRequested.set(true)' in a
assert 'if (failure instanceof AgentCancelledException cancelled) throw cancelled;' in p
assert 'guard.file(attrs.size())' in p
assert 'if (totals[0] > MAX_FILES || totals[1] > MAX_BYTES)' in p
print('PASS: startup, safe snapshot, timeout, cancellation, retrieval and parallel-tool source contracts')
