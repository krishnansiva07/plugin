# Eliya vs OpenCode — evidence-based acceptance benchmarks

**No performance or accuracy wins are claimed by this suite itself.** To compare products, use the same model, temperature, task input, workspace snapshot, network, tools and permissions. Run at least 3 repetitions for each pair. The evaluator rejects unpaired/nonidentical-model records.

Required workloads and evaluation evidence:

| task_id | Category | Objective evidence |
|---|---|---|
| chat_long | Long Chat analysis | Complete coverage of an agreed rubric; no lost paragraphs / unsolicited prompt; output-limit continuations visible and persisted |
| workspace_3000 | 3,000-file codebase analysis | Human-reviewed source path/symbol/line precision, facts correct, p95 response time, indexing impact |
| cross_layer | UI → API → data flow | Correctly links UI route, API handler, service, query and KPI/alert formula; flags unknown branches |
| feature | New feature development | Acceptance tests pass, no unrelated changes, reproducible build |
| migration | Existing framework migration | Behaviour parity, target architecture conventions, passing tests |
| fault_resume | Forced network/provider interruption | Partial answer saved and continuation works; no duplicate modifications |
| mcp_gate | MCP permission and retrieval | Disabled/unrequested means zero MCP calls, enabled explicit data is accurate |
| documents | Documentation from code | User prompt followed, generated artifacts open, sources verified, no forced template |

Output one row **per repetition** to `results.csv` based on `results_template.csv`. Set `passed` only if the category's objective pass criteria are met. Accuracy is a 0..1 blinded rubric score determined using independent source inspection, never by the agent scoring itself. Wall time and token usage should be instrumented; leave unknown values blank rather than inventing them. Do not upload confidential user code or secrets to public comparison providers.

Run:

```sh
python3 qa/comparative/compare.py qa/comparative/results.csv
```

The report compares only verified paired tasks using the same model and identical task ID. Any result reported as an advantage must show sample count, paired completion, mean accuracy, and measured latency. Do not call Eliya better overall without representative wins and no safety regressions.
