# ELIYA44 — Agent Reliability and Startup Hang Fix

## Reported defect

A task copied from Eliya Chat into Eliya Agent remained at ~4% for over 12 minutes, displaying `Resolving workspace and task context`. Earlier Agent requests in the same workspace completed normally. The visible step occurs before execution-plan generation, so this symptom is not proof that the prompt itself is invalid.

## Changes implemented

1. **Preparation pass:** AgentWorkspaceService now registers recursive watchers and captures run-start SHA-256 hashes in one traversal where native watching works. It continues to skip generated/vendor directories and symbolic links. When native watching is unavailable it falls back to baseline hashing before any approved execution.
2. **Bounded and observable startup:** per-file/directory cancellation checks, byte/file counters, monotonic deadline, progress callbacks. Default 120-second preparation safety deadline. On exceeded deadline, fail with a diagnostic instead of presenting a frozen 4% state. An OS filesystem call that cannot be interrupted is an inherent limitation.
3. **Writable prompt resources:** preserve independent hashing and permission behavior for explicitly writable paths. No change to selected-workspace authority or MCP gating.
4. **Planning evidence:** optional impact search is bounded to 30 seconds and hybrid/semantic retrieval is bounded to 45 seconds. Failures fall back to live workspace tools and lexical/local evidence; hard cancellations propagate.
5. **Read tool batches:** shared 120-second deadline with cancellation polling for a parallel read-only tool batch, and cancellation of overdue futures.
6. **Foreground commands:** unspecified timeout no longer means an unlimited build/test/check/bash wait; default 900 seconds, configurable. Existing explicit timeouts are preserved. Commands still emit periodic output/elapsed activity.
7. **Protected pre-execution snapshot:** full byte-exact file copy and deletion-approval safety retained; now reports file/byte progress and has a default 180-second deadline. No file edits begin until snapshot completes; failures discard partial snapshots and do not claim rollback coverage. Agent cancellations are not converted to generic failures.
8. **Java 17 smoke tests:** new deterministic tests for stage expiry, cancellation, progress and source integration wiring. Existing offline regression suite updated for new component and cancellation of partial snapshot.

## Configurable Java system properties

| Property | Default | Purpose |
|---|---:|---|
| `eliya.agent.preparationTimeoutSeconds` | 120 | Startup filesystem preparation safety deadline |
| `eliya.agent.snapshotTimeoutSeconds` | 180 | Protected rollback snapshot safety deadline |
| `eliya.agent.parallelReadTimeoutSeconds` | 120 | Parallel read-only tool batch deadline |
| `eliya.agent.commandTimeoutSeconds` | 900 | Default for foreground command, build, test, check |

Optional impact/semantic retrieval limits are 30 and 45 seconds respectively. Provider HTTP timeouts, model fallback policy and approval waiting continue to use existing runtime settings and behavior.

## Verification performed in this environment

All eight `qa/*/run.sh` offline suites passed:
- `agent-reliability`: monotonic stage deadline, cancellation, progress; parsing 98 Java 17 production sources; source wiring checks.
- `workspace-planning`: path stability, command working-directory boundaries, plan JSON envelope.
- `plan-relevance`: task contract and verification requirements.
- `intelligence-smoke`: synthetic 1,099-file and 3,000-file indexing/flow tests; cache/semantic cancellation.
- `offline-smoke`: binary/text rollback, deletion approval TTL, partial snapshot cancellation cleanup.
- `completion-report-smoke`: completion reporting, frontend/backend source contracts.
- `context-v35-smoke`: Chat/Agent context and token-bounded evidence.
- `confluence-smoke`: 12 focused formatting checks.

### Validation limits

**Full Maven dependency resolution and executable JAR build were not possible.** Maven was not installed and the environment could not resolve the Maven repository host. Java source parsing tests do not establish full type-checking or Spring application startup. Live Windows workspace, remote provider and Jira/Confluence/MCP integration tests were not run. This ZIP is an updated **source package**, not a tested binary release. Do not assume every possible Agent failure is eliminated. Run the existing `validate-local.bat` or Maven verify in an environment with dependencies, then run a short Agent regression followed by the originally affected prompt.

## Suggested reproduction/regression sequence

1. Use the same selected local project and Agent model as the affected case.
2. Ask Agent for a simple read-only task; observe progress past 4% into analysis and plan.
3. Repeat the Chat-generated monotonic timestamp/Guava rate limiter task; verify it reaches plan approval without selecting a different workspace.
4. Approve only after reviewing the plan. Confirm the protected snapshot and tool steps emit activity, rather than remaining silent.
5. Confirm compile/test verification and final modified-file report; test cancellation and rollback on a disposable project first.

Note: safety deadlines deliberately fail closed instead of silently skipping baseline creation. Slow disks, antivirus, inaccessible shares and unusually large workspaces may require adjusting properties or excluding generated artifacts.
