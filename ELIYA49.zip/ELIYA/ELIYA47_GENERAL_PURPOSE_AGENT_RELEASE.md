# ELIYA 47 — Native General-Purpose Agent Foundation

**Base:** user-provided ELIYA 46 source archive (`ELIYA46(1).zip`)  
**Goal:** continue developing Eliya as an independent, Java 17 general-purpose AI agent. OpenCode is a reference implementation, **not a runtime, dependency, or integration requirement**.

## Included code changes

1. **Native role catalog:** `researcher`, `analyst`, `architect`, `developer`, `tester`, `reviewer`, and `documentation`, in addition to the existing `explore` and `general`. These work in any selected workspace without an `.opencode` folder or a separately installed OpenCode CLI.
2. **Runtime-enforced role policy:** new `AgentToolPolicy` class categorizes operations conservatively (read, edit, bash/shell, MCP, etc.) and prevents subagents from widening the permissions granted by the parent run. Reviewer/Architect deny edits, shell execution and MCP operations. Researcher/Analyst deny edits and shell execution, and may use annotated **read-only** MCP operations only when existing MCP gating permits them. Unknown actions are classified as mutating, not read-only.
3. **Markdown agent permissions:** `AgentProfileService` understands `permission: edit: deny/ask/allow`, nested `tools: read: true`/`write: false`, simple tool lists, and inline tool-flag maps. An agent `ask` requires explicit approval, even when the parent is configured to auto-approve actions; deny wins over allow. Resource-specific nested permission patterns that cannot be safely enforced are **rejected instead of being silently widened**.
4. **Read-only built-in override protection:** custom workspace profiles may override built-in reviewer/architect prompts, but cannot bypass their edit/shell/MCP denials.
5. **Profile discovery hardening:** normalized roots must remain inside the workspace, symlink escapes are blocked, agent file size is capped at 128 KiB, traversal depth remains bounded and at most 256 profiles are inspected per source directory. Catalog order is deterministic.
6. **Bounded subagent execution:** default maximum 160 child model turns per delegated task; configuration `-Deliya.agents.subagent.maxTurns=N` (clamped to 16–2000). This prevents unlimited nested runs; if work remains, the parent should delegate a new scoped task.
7. **Subagent activity reports:** start, success and expected blocked events are added to the existing run's recorded event stream. A successful report includes child model turn count, tool actions and elapsed milliseconds.

## Compatibility / deliberate non-changes

- **Java 17 and current application entry point** are unchanged.
- **Existing Chat and Agent flows** and human-reviewed plan approval remain unchanged.
- **User documentation prompts** remain authoritative; templates are used only when explicitly selected in the UI.
- **MCP opt-in and explicit prompt gating** remain unchanged. The new role rules apply an *additional restriction*, never a new permission.
- **Deletion approval, protected snapshots, rollback, command safety, workspace scope and reference resources** are unchanged.
- **Existing custom profiles without `permission`** continue to inherit the user's configured tool permissions; only declarative explicit policies add restrictions.
- **Agent profile `model:`** still inherits the parent run model pool (a known limitation, not silently emulated).
- No integration with OpenCode is used or introduced.

## Example `.agents/agents/code-auditor.md`

```md
---
description: Read-only code reviewer
mode: subagent
tools: [read, read_many, grep, glob, code_impact, workspace_diff, workspace_status]
permission:
  edit: deny
  bash: deny
  mcp: deny
---
Review the selected code for correctness, security and regression risks. Cite source paths and evidence.
Never modify code. Report unknowns explicitly.
```

## Example `.agents/agents/feature-builder.md`

```md
---
description: Developer with additional per-operation approvals
mode: subagent
permission:
  edit: ask
  bash: ask
  mcp: deny
---
Implement the user's delegated feature using the selected workspace's conventions.
Verify each completed change and report actual results. Do not delete files without explicit approval.
```

## Usage

1. Choose the existing Eliya workspace. No OpenCode executable or configuration is required.
2. In **Agent** mode: `Call agent_catalog and list the available agents. Do not modify files.`
3. Ask Eliya to complete your actual task, using specialized roles when useful, for example: `Analyse this bug with researcher, implement a fix with developer, verify with tester, then have reviewer inspect the changed code. Preserve the existing architecture.`
4. Review and approve Eliya's plan as usual. All approvals, MCP gating and rollback behaviour remain in effect.
5. Verify the reported results. Do not interpret a role report as proof of successful tests unless test execution evidence is present.

## Validation performed in this packaging environment

- Java 17-targeted isolated compilation and smoke test of `AgentToolRegistry`, `AgentProfileService`, `AgentToolPolicy`: **PASS**.
- Profile discovery, policy deny/ask and fail-closed parser checks: **PASS**.
- Node `--check` for existing `app.js` and `markdown.js`: **PASS**.
- `javac` parse/syntax scan for edited `AgentService`: **no Java syntax diagnostics**; missing third-party classes prevent complete compilation.
- **Maven full compile, integration/JUnit suite, Windows runtime and live provider tests: NOT RUN.** Maven is not installed and dependency download fails due to no network/DNS in the packaging environment.

## Known remaining gaps

This is a high-impact incremental release, **not a claim of OpenCode parity or superiority in every area**:

- Durable independent child-agent jobs, pause/resume across process restart and resource ownership are not implemented.
- Parallel subagent execution and optional per-task worktrees remain future work.
- Full YAML schema/resource-pattern enforcement is not implemented; nested conditional allow/ask patterns are intentionally rejected.
- Native per-subagent model/provider selection is not implemented.
- Context retrieval quality and performance have not been benchmarked head-to-head against OpenCode.
- UI role picker, diff approval, plugin SDK and richer observability dashboards remain future work.

Use `ELIYA_GENERAL_AGENT_PARITY_ROADMAP.md` for the measurable implementation plan.
