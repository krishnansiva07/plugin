# ELIYA45 — Selected-Workspace Boundary and C:\ Drive Indexing Fix

## Reported defect

User selected one local project folder, but later Agent runs could attempt to process about 30,000 files across `C:\` and then stop. Previous Agent prompts with the same intended workspace worked. Source inspection found two ways for this to occur:

1. `PromptResourceResolver.existingPathFromCandidate` previously shortened a malformed/nonexistent path until it found a parent folder; a Windows path could potentially resolve to `C:\`. `resolve` then could register that folder as another **writable** resource. `AgentWorkspaceService.prepareTrackedWorkspace` hashes every writable resource, independent of the selected project root.
2. The UI `ensurePersistentActiveWorkspace` restoration failure previously fell through to prompt-inferred mapping. Backend auto-inference also accepted incidental paths from prose rather than requiring clear project intent.

These are code-level failure mechanisms consistent with the observed symptom, not a claim that Windows runtime logs definitively identify the exact trigger.

## Implemented fixes

- **Selected-project root remains authoritative:** unmapped incidental paths in prompts are ignored when a project is selected. Only explicitly labelled external reference/input/diagnostic folders, or deliberate `Secondary workspace:` mappings, are registered.
- **No parent-folder guessing:** if the path is not an exact existing path, ignore it rather than walking back through parent segments to a larger folder.
- **Drive/home/system guards:** reject filesystem roots, the user-home folder or its ancestor folders, and Windows system folders. Apply these checks when creating local workspace records, preparing Agent workspaces, and creating index views; also prevent unsafe external resources and auto-inferred paths.
- **Safe auto-detection when NO project selected:** a path becomes a primary project only if explicitly declared (`Project path:`, `Workspace:`, etc.) or entered as a standalone path. Incidental text references cannot silently create project workspaces.
- **Fail closed on failed UI restoration:** if a saved folder exists but the backend cannot restore it, display an actionable error and DO NOT start an Agent run by inferring a different folder.
- **Visible root:** show the actual current path on the workspace bar and emit the selected project root in Agent activity events.
- **Junction/symlink scope defense:** skip non-root symbolic-link/reparse-point directories in workspace watcher/hash and retrieval-index traversals (without following links).
- **Existing deliberate integrations preserved:** up to five named shared references remain read-only; `Secondary workspace:` retains explicit writable opt-in; command CWD protections, plan relevance, MCP gating, approval, and rollback implementation are not removed.

## Automated checks run

The following **nine offline suites passed**:

- `qa/workspace-boundaries/run.sh`: compiled and ran live `WorkspaceRootGuard` and `PromptResourceResolver` logic using Java 17 with a local Spring annotation stub. Cases: root/home rejection, unchanged selected root, benign prompt path ignored, no ancestor fallback, explicitly labelled references read-only, deliberate secondary opt-in and explicit project inference.
- `qa/agent-reliability/run.sh`: safety deadlines, cancellation, progress, Java parser/source contracts.
- `qa/workspace-planning/run.sh`: selected root and command CWD rules, symlink/traversal rejection, plan JSON envelope.
- `qa/plan-relevance/run.sh`: task relevance and plan validation.
- `qa/context-v35-smoke/run.sh`: Chat/Agent context and token/evidence controls.
- `qa/intelligence-smoke/run.sh`: synthetic 1,099-/3,000-file indexing and retrieval, semantic fallback, incremental indexing, routing.
- `qa/completion-report-smoke/run.sh`: completion UI, approved deletions, diff/rollback and frontend source checks.
- `qa/confluence-smoke/run.sh`: safe Confluence formatting.
- `qa/offline-smoke/run.sh`: Agent approvals, rollback, external-root snapshot and command guards.

Also passed `node --check` for main UI JavaScript and Markdown JavaScript.

### Important validation limitations

This environment does not have Maven or the dependencies required to run a complete Maven type-checked compile, the integration suite, or a runnable Windows JAR. The Java 17 parser is a **syntax-only** check. A live Windows drive/junction test and end-to-end UI-to-Agent test are **not verified here**. ELIYA45 is a patched **source ZIP**, not a fully verified production binary. Preserve backups and run `validate-local.bat` in your network-enabled developer/build machine before adopting it.

## Recovery steps for the reported incident

1. Cancel the current 30,000-file Agent/index job. If cancellation fails, restart the Eliya backend after saving work.
2. Disconnect any unintended `C:\` workspace mapping in the UI (if one is visible).
3. Map the exact project directory using Workspace path field (e.g. `C:\Projects\MyApp`).
4. Confirm Workspace bar displays that exact root, then request indexing of just that project.
5. First run a read-only Agent prompt and observe the `workspace_root` event. Then retry the previously affected feature prompt. Verify no unrelated paths are traversed.
6. Check `validate-local.bat`, command execution, rollback, Chat, and Agent in the actual Windows environment.

Unspecified or broad Windows system/drive paths are deliberately refused. Users who really need to compare code outside the selected project should map it as a named shared reference or explicitly label the external input. Do not map `C:\` as a project.
