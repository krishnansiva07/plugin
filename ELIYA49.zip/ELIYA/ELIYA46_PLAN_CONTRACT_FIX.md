# ELIYA46 — Repository Guidance Planning Fix

Baseline: user-provided ELIYA45.zip (2026-10-14).

## Reported blocker

Plan creation failed with:
`TASK CONTRACT MISMATCH: Broad repository documentation requires documentation_inventory and final documentation_validate...`
when running Prompt 1 of the Selenium -> Playwright migration setup pack. No implementation or repository content was changed in the failed run.

## Cause

`AgentService.classifyTask` previously routed broad-looking instructions/documentation requests to the repository-wide `documentation` task profile. That automatically required `documentation_inventory` and `documentation_validate`, even for an explicitly bounded task to create only AGENTS.md / SKILLS.md / SOURCE_MAP.md in the selected Playwright workspace.

## Changes

- **AgentPlanRelevance.java**: Added narrowly scoped recognition of explicit repository-guidance/migration-setup file-authoring tasks. Markdown files merely mentioned as inputs are not enough to activate this route; package migration execution remains a code task. Recognizes requested output artifacts from CREATE/OUTPUT sections and refuses plans that omit an output, bypass read-only legacy scope, or introduce forced full-documentation tools.
- **AgentService.java**: Classifies guidance creation **before** broad documentation. Uses a bounded 3–8 step `repository_guidance` plan profile; turns off full repository-documentation/large-task workflow, keeps the model's specific requested output contract, and ends with file/evidence verification rather than arbitrary build or full-documentation validation. Other documentation profiles, ordinary coding/migration, MCP and Chat behavior are unchanged.
- **qa/plan-relevance/RepositoryGuidanceSmoke.java**, **fixtures/selenium-playwright-4-prompts.txt**, **run.sh**: Regression tests exercise the exact previously supplied four-prompt pack, verify the distinct routes for prompts 1–3 versus 4, check output-file completeness and protect true full-repository documentation.

## Validated here

- PASS `bash qa/plan-relevance/run.sh` (all original tests and real four-prompt migration regression)
- PASS `bash qa/workspace-planning/run.sh` (selected workspace stable, command path containment, plan envelopes)
- PASS: Java 17 source parser across 99 production Java files and agent-preparation guard smoke (run.sh components); PASS: source-contract assertions independently. The complete combined script exceeded this environment’s allotted runtime, so its whole-script result is NOT reported as a pass.
- PASS `qa/workspace-boundaries/WorkspaceBoundarySmoke.java` (narrow selected root and read-only external reference)
- PASS `node --check src/main/resources/static/app.js`

## Not validated here

The Maven dependency repository and `mvn` executable are not available in this runtime. Thus no full Maven/JUnit test suite, executable JAR, or live LLM/Windows end-to-end Agent execution was verified. Some broader offline shell suites did not finish inside the available execution budget; do not mark them passed. Use the repository's `validate-local.bat` and `mvn -Pfull-tests clean verify` on a configured machine.

## Deployment/retry

1. Back up ELIYA45 and use this complete ELIYA46 source package as replacement.
2. Compile and run full Maven verification on the target Java 17 machine; do not run an old ELIYA45 JAR alongside the new source.
3. Keep the NX/Playwright target as `workspace` and the Java/Selenium reference as `legacy` (read-only).
4. Re-run Prompt 1 with the same wording. Expected Agent task profile: `repository_guidance`; it should **not** ask for `documentation_inventory` or `documentation_validate`.
5. Review and approve a plan that creates exactly the requested `migration/legacy/{AGENTS.md,SKILLS.md,SOURCE_MAP.md}`.
6. Run Prompts 2 and 3, then use Prompt 4 only for an approved package migration batch.

The patch addresses the reproduced deterministic task-classification mismatch; model/provider timeouts, inaccessible references or actual runtime failures remain possible and must be reported rather than silently bypassed.
