# Eliya 48 — Chat Continuity, Evidence Accuracy, and Comparative Validation (Candidate)

**Base:** user-provided Eliya 46, through the Eliya 47 source package. The earlier native-agent changes remain intact. **Status: source candidate, not a fully integration-tested JAR.** Java 17 and existing application launch/run modes are unchanged.

## What the user reproduced

Chat can produce a long response that silently stops. When prompted again to continue, the model produces the rest. Investigation identified two relevant code paths:

- `OpenAiCompatibleClient.stream()` was ignoring OpenAI-compatible `choices[].finish_reason`. The model's `finish_reason: "length"` was treated like a normal completed response.
- Browser Chat re-rendered the **entire growing Markdown document every 45ms** during streaming, adding avoidable browser cost for long analyses.
- MCP-backed Chat had two final-answer paths; both required length handling. Mid-stream network failures could discard the partial answer instead of saving it.

## Phase 1 — Guard the already-working Eliya 46 baseline

- No existing files removed (8 modified, 7 added before adding this release note).
- Existing Chat vs Agent separation, planning, approvals, rollback, explicit MCP gating, user documentation prompt priority and workspace path selection are retained.
- `qa/native-agent-policy-smoke.sh` passes: runtime role grants remain fail-closed.
- All existing Node UI tests passed in this environment (18 tests), including MCP settings, shared folders, prompt library and deletion approvals.
- Full Maven/JUnit/Windows execution is **not verified**: Maven binaries/dependencies are not available in this container.

## Phase 2 — More truthful, useful analysis and indexing

- `ContextService` now explicitly requires separation of **verified source**, **reasonable inference** and **unverified/missing** evidence. It prevents falsely equating no search match with proof that a feature is absent.
- Workspace retrieval includes index-coverage counters and warns when the scan is incomplete.
- Live indexed evidence now warns when a matched file's size or mtime has changed since indexing (`STALE_INDEX`), rather than representing stale structural metadata as current truth.
- New optional `LocalProjectIndexService` on-demand **background** refresh from cached index age: `-Deliya.index.autoRefreshMinutes=60` (range 10–1440; **default 0/off** to avoid disrupting the proven large-workspace Chat speed). The existing index builder reuses unchanged file fingerprints. Explicit manual rescan is still available.
- No changes to semantic model selection, retrieval ranking weights, workspace root, MCP gating or retrieval index limits were made without comparative quality tests.

## Phase 3 — Long-answer continuity and recovery

- `OpenAiCompatibleClient.StreamResult` exposes model `finish_reason` and `[DONE]` metadata.
- Chat requests with an explicit output-limit reason (`length`, `max_tokens`, `max_output_tokens`, `token_limit`) **automatically continue**, adding internal continuation context (the last 8,000 generated characters) without altering the original user prompt or retrieved evidence.
- Bounded automatic continuation: `-Deliya.chat.autoContinue.enabled=true` (default) and `-Deliya.chat.autoContinue.maxParts=8` (default, range 1–20). The model may still finish after the maximum; the UI then saves an explicit `[ELIYA: response incomplete]` annotation rather than falsely claiming completion.
- Stream-merging removes exact repeated continuation prefixes at section boundaries. Both **ordinary Chat and MCP final Chat** use continuation. Agent/model tool execution logic is unchanged.
- When Chat generation fails **after some text was streamed**, Eliya persists and presents the partial message with an explicit warning rather than losing it. It does not automatically replay potentially mutating MCP actions.
- Browser shows visible continuation progress after answer text already exists, and reduces repeated full-Markdown re-renders for very large responses (45ms small, 140ms after 12k, 320ms after 32k, 650ms after 80k characters).

## Phase 4 — Objective evidence before claiming OpenCode superiority

- Added `qa/comparative/README.md`, `results_template.csv`, and `compare.py` for **same-model, paired-run** comparison.
- Benchmark workloads: long Chat, 3000-file indexing/analysis, cross-layer flow, feature development, migration, provider interruption, MCP policy and documentation quality.
- Required outputs: task completion, independently checked accuracy, elapsed time, tokens where available, unauthorized writes, and reproducibility.
- **No head-to-head result is provided or implied.** Comparative performance and reliability advantages over OpenCode remain unproven until this suite is run against real comparable tasks.

## Validation evidence

| Check | Status |
|---|---|
| `qa/chat-continuation-smoke.sh` pure Java 17 behaviour | PASS |
| `qa/native-agent-policy-smoke.sh` (Eliya 47 compatibility) | PASS |
| Node frontend syntax (`app.js`, `markdown.js`) | PASS |
| Existing Node regression suite (18 tests) | PASS |
| Added HTTP/SSE provider mock integration tests | WRITTEN, **NOT EXECUTED** (Maven unavailable) |
| Workspace stale-index JUnit test | WRITTEN, **NOT EXECUTED** (Maven unavailable) |
| Maven full build + Java unit suite | NOT VERIFIED |
| Windows Java 17 runnable JAR and corporate LLM gateway | NOT VERIFIED |
| Agent end-to-end regression, benchmark against OpenCode | NOT VERIFIED |

## Known limitations / next engineering work

1. Some providers terminate without `finish_reason`; these are not blindly retried, because doing so can create duplicate or fabricated content. Unknown completion remains visible for normal manual follow-up.
2. The new continuation makes extra model requests (potential additional latency/cost) and uses bounded reply history; extremely long answers can still hit context limits.
3. This release does not add durable subagent jobs, parallel writes, full git worktree isolation, or a replacement search/reranking engine.
4. True answer accuracy requires source-grounded human/integration evaluation; new prompt guidance is not proof of correctness.
5. On large workspaces, the optional periodic on-demand background refresh should be load-tested before enabling.

## Build and verify on Windows

Using an environment where Maven/dependencies are already available:

```bat
mvnw.cmd -Pfull-tests clean test
mvnw.cmd -DskipTests package
java -jar target\eliya.jar
```

Then test actual Chat model limits (e.g. `maxTokens=512` with a long requested analysis), network disconnect/recovery, a 3,000-file workspace, Jira/Confluence MCP prompts with explicit MCP, and Agent work with plan approvals. Keep a copy of Eliya 46 as the rollback baseline. **Do not replace the tested production JAR until these checks pass.**
