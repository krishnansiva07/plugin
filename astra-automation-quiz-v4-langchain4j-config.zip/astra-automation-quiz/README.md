# Astra Automation Quiz

LLM-powered live quiz host for automation teams.

## LLM connectivity

This build uses LangChain4j configuration like your working sample.

`astra.llm.base-url` is used as configured:

```properties
astra.llm.base-url=https://ai4devs.group.echonet/api/v1
```

Astra code does **not** append `/chat/completions` or `/completions`.

## Configure

Edit `src/main/resources/application.properties`:

```properties
astra.llm.demo-mode=false
astra.llm.base-url=https://ai4devs.group.echonet/api/v1
astra.llm.api-key=YOUR_API_KEY_HERE
astra.llm.model-name=gpt-oss-120b
astra.llm.timeout-ms=60000
```

Rotate any key that was shared in screenshots before using this in a real environment.

## Run

```bash
mvn clean package
java -jar target/astra-automation-quiz-1.0.0.jar
```

Open:

```text
http://localhost:8090/index.html
```

## Windows quick run

```bat
run.bat
```

## Console confirmation

When you click **Generate Next Question**, console should show:

```text
[Astra Quiz] Demo mode: false
[Astra Quiz] Calling LLM using LangChain4j baseUrl: https://ai4devs.group.echonet/api/v1
[Astra Quiz] Model: gpt-oss-120b
```
