#!/usr/bin/env bash
# Offline compile + behavioral tests for the modified Chat MCP router and streaming service.
set -euo pipefail
cd "$(dirname "$0")/../.."
DIR=$(mktemp -d); trap 'rm -rf "$DIR"' EXIT
ROOT="$DIR/src"
mkdir -p "$ROOT/com/llmart/llm/service" "$ROOT/com/llmart/llm/dto" "$ROOT/com/fasterxml/jackson/databind" "$ROOT/org/springframework/stereotype" "$DIR/classes"
cp src/main/java/com/llmart/llm/service/ChatMcpService.java "$ROOT/com/llmart/llm/service/"
cat > "$ROOT/org/springframework/stereotype/Service.java" <<'JAVA'
package org.springframework.stereotype; public @interface Service {}
JAVA
cat > "$ROOT/com/fasterxml/jackson/databind/JsonNode.java" <<'JAVA'
package com.fasterxml.jackson.databind;
import java.util.*;
public class JsonNode implements Iterable<JsonNode> {
 public JsonNode path(String name){return this;} public String asText(String fallback){return fallback;}
 public String asText(){return "";} public boolean isObject(){return false;} public boolean isArray(){return false;}
 public boolean isNull(){return false;} public Iterator<JsonNode> iterator(){return Collections.emptyIterator();}
}
JAVA
cat > "$ROOT/com/fasterxml/jackson/databind/ObjectMapper.java" <<'JAVA'
package com.fasterxml.jackson.databind;
public class ObjectMapper {
 public String writeValueAsString(Object value){return "{}";}
 public JsonNode readTree(String text){return new JsonNode();}
 public JsonNode createObjectNode(){return new JsonNode();}
}
JAVA
cat > "$ROOT/com/llmart/llm/dto/ChatSettings.java" <<'JAVA'
package com.llmart.llm.dto;
public class ChatSettings {
 public String chatModelOrPrimary(){return "mock-chat";}
 public String baseUrl(){return "http://localhost";}
 public int safeMaxTokens(){return 1024;}
}
JAVA
cat > "$ROOT/com/llmart/llm/dto/ChatRequest.java" <<'JAVA'
package com.llmart.llm.dto;
public class ChatRequest { public ChatSettings settings(){return new ChatSettings();} }
JAVA
cat > "$ROOT/com/llmart/llm/service/AgentCancelledException.java" <<'JAVA'
package com.llmart.llm.service;
public class AgentCancelledException extends RuntimeException {public AgentCancelledException(String s){super(s);}}
JAVA
cat > "$ROOT/com/llmart/llm/service/OpenAiCompatibleClient.java" <<'JAVA'
package com.llmart.llm.service;
import java.util.*;import java.util.function.*;import com.fasterxml.jackson.databind.JsonNode;
import com.llmart.llm.dto.ChatSettings;
public class OpenAiCompatibleClient {
 public record AgentToolCall(String id,String name,JsonNode arguments) {}
 public record AgentCompletion(String content,List<AgentToolCall> toolCalls,boolean hasToolCall) {}
 public Queue<AgentCompletion> turns=new ArrayDeque<>(); public int streamCalls=0; public List<Map<String,Object>> finalMessages=List.of();
 public AgentCompletion completeAgent(String key,String url,String model,int max,List<Map<String,Object>> context,List<Map<String,Object>> tools,boolean json,BooleanSupplier cancelled){return turns.remove();}
 public String stream(String key,ChatSettings settings,List<Map<String,Object>> messages,Consumer<String> onToken,BooleanSupplier cancelled){
   streamCalls++;finalMessages=messages;onToken.accept("Answer ");onToken.accept("streamed.");return "Answer streamed.";
 }
}
JAVA
cat > "$ROOT/com/llmart/llm/service/McpManager.java" <<'JAVA'
package com.llmart.llm.service;
import java.util.*; import java.nio.file.Path;import java.util.function.BooleanSupplier;import com.fasterxml.jackson.databind.JsonNode;
public class McpManager {
 public record Catalog(List<Map<String,Object>> definitions,Map<String,String> byFunction,List<String> diagnostics){}
 public int catalogCalls=0, readCalls=0;
 private final Catalog catalog=new Catalog(List.of(
  Map.of("function",Map.of("name","jira_get_issue","description","MCP jira / get_issue")),
  Map.of("function",Map.of("name","confluence_search","description","MCP confluence / search")),
  Map.of("function",Map.of("name","jira_delete_issue","description","MCP jira / delete_issue"))
 ),Map.of(),List.of());
 public List<String> configuredServerNames(Path root){return List.of("jira","confluence");}
 public Catalog catalogCachedForChat(){catalogCalls++;return catalog;}
 public boolean isChatReadOnly(Catalog cat,String name){return !name.contains("delete");}
 public String call(Path root,Catalog cat,String name,JsonNode args,BooleanSupplier cancel){readCalls++;return "Issue exists";}
}
JAVA
cat > "$ROOT/com/llmart/llm/service/ChatMcpOfflineTest.java" <<'JAVA'
package com.llmart.llm.service;
import java.util.*;import com.llmart.llm.dto.ChatRequest;
public class ChatMcpOfflineTest {
 static void check(boolean ok,String msg){if(!ok)throw new AssertionError(msg);}
 public static void main(String[] args)throws Exception{
  McpManager mcp=new McpManager();OpenAiCompatibleClient llm=new OpenAiCompatibleClient();
  ChatMcpService chat=new ChatMcpService(llm,mcp,new com.fasterxml.jackson.databind.ObjectMapper());
  String[] local={"How is Deep Search implemented?","How is Jira integration implemented?", "How is Confluence configured in source code?", "Explain Java inheritance"};
  for(String query:local)check(!chat.shouldHandle(query),"Unexpected MCP request: "+query);
  String[] external={"Read Jira PAY-123 and explain acceptance criteria", "What is the status of ABC-42?", "Search Confluence for SEPA architecture", "Check SonarQube quality gate"};
  for(String query:external)check(chat.shouldHandle(query),"MCP routing missed "+query);
  var projectContext=List.<Map<String,Object>>of(Map.of("role","user","content","How is Deep Search implemented? Retrieved: Jira PAY-123"));
  check(chat.answer("key",new ChatRequest(),"How is Deep Search implemented?",projectContext,()->false,a->{},t->{}).isEmpty(),"Retrieved code incorrectly activated MCP");
  check(mcp.catalogCalls==0,"Local prompt attempted catalog discovery");
  llm.turns.add(new OpenAiCompatibleClient.AgentCompletion("",List.of(new OpenAiCompatibleClient.AgentToolCall("c1","jira_get_issue",null)),true));
  List<String> progress=new ArrayList<>(),tokens=new ArrayList<>();
  String answer=chat.answer("key",new ChatRequest(),"Read Jira PAY-123",List.of(Map.of("role","user","content","Read Jira PAY-123")),()->false,
     a->progress.add(a.status()),tokens::add).orElseThrow();
  check(mcp.catalogCalls==1 && mcp.readCalls==1,"Expected exactly one discovery and external read");
  check(llm.streamCalls==1,"MCP answer was not streamed");
  check(answer.equals("Answer streamed.") && tokens.equals(List.of("Answer ","streamed.")),"Wrong streamed output");
  check(progress.contains("discovering") && progress.contains("running") && progress.contains("generating"),"Missing loading statuses: "+progress);
  check(llm.finalMessages.stream().anyMatch(msg->"tool".equals(msg.get("role"))),"Missing MCP evidence in final response context");
  System.out.println("PASS: local prompt bypass even with retrieved Jira text; explicit MCP routing; read-only tools; MCP status events; true streamed response");
 }
}
JAVA
javac --release 17 -d "$DIR/classes" $(find "$ROOT" -name '*.java')
java -cp "$DIR/classes" com.llmart.llm.service.ChatMcpOfflineTest
