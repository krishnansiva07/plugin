# ELIYA21 – MCP Chat routing, performance and loader changes

## Changed components

- `ChatService.java`: routes MCP decisions using the **original user message**, not enlarged source-code or attachment context. Emits `chat_status` before context building, during MCP operations and before regular LLM streaming. For MCP responses, forwards token callbacks to the same buffered SSE transport and persists the completed assistant response.
- `ChatMcpService.java`: uses explicit user intent, selects relevant **read-only** tools (up to 24 definitions per request), allows bounded tool calls (16) and model iterations (7), avoids an unnecessary second evidence-retrieval prompt after a successful tool call, and streams the final synthesis using the configured Chat model after the initial successful tool round. Tool errors, timeouts and exhausted budgets produce visible text instead of an indefinitely waiting Chat.
- `McpManager.java`: caches Chat discovery for 60 seconds (8 seconds after unavailable-server diagnostics), invalidates the cache when managed configuration changes or stdio tools change, and bounds foreground discovery to 15 seconds. Discovery that takes longer continues on the daemon discovery thread so a subsequent request may reuse its result. Chat read calls are bounded separately to 25 seconds. The existing Agent-side tool-discovery interface remains unchanged.
- `app.js` / `app.css`: displays a spinner, animated dots and live activity text until the first Chat token arrives. Status changes do not clear the loader. First token replaces the loader, streaming continues in the normal Markdown view. Agent UI is unchanged.

## Expected behavior

| Request | Execution |
|---|---|
| How is Deep Search implemented? | Indexed project + Chat model; MCP is not invoked. |
| How is Jira integration implemented in our source code? | Indexed project + Chat model. |
| Read Jira PAY-123 | Jira MCP read tool(s), then streaming answer. |
| Search Confluence for the SEPA design | Confluence MCP read tool(s), then streaming answer. |
| Compare project code to Jira acceptance criteria | Indexed project + Jira MCP + Chat model. |

The current fast path synthesizes its final answer after the first successful MCP tool round. If a search result does not include enough detail for a complete answer, the model is instructed to state what evidence remains missing. A request may invoke multiple independent tools in one model round, but calls within that round are executed sequentially to avoid overloading servers. MCP discovery timing and actual model latency remain dependent on the connected servers and provider.

## Adjustable Java system properties (optional)

- `-Deliya.chat.mcp.discoveryTimeoutMillis=15000` – foreground discovery limit in milliseconds, clamped to 2000–60000.
- `-Deliya.chat.mcp.toolTimeoutMillis=25000` – each Chat MCP read limit in milliseconds, clamped to 2000–120000.

Server configuration and Agent mode retain their existing behaviors. When a foreground discovery limit is reached, the tool list is not fabricated: Chat reports a discovery-in-progress diagnostic and the user can retry.

## Validation performed here

1. Offline Java 17 isolated compile + behavior test of modified `ChatMcpService`, with controlled MCP and LLM doubles: **PASS** (local routing, external routing, read-only exposure, loading events, first tool round, genuine streaming token callbacks).
2. Node JavaScript parser: **PASS** (`node --check` on `app.js`).
3. Node Chat loader behavior test: **PASS** (spinner survives progress events and disappears on the first token).
4. Existing standalone deletion-approval / protected-snapshot smoke test: **PASS**.
5. Existing UI/API source contracts: **11 PASS**.
6. Existing Spring constructor source contract: **PASS**.
7. Existing vision-adapter standalone smoke test: **PASS**.
8. `javac` parser checks of modified `McpManager` and `ChatService`: no Java syntax errors detected; their full type-check/build cannot be completed here because Maven, Spring, Jackson and the other runtime dependencies are not installed or cached.

### Build on a machine with Maven dependency access

```bash
mvn -B -DskipTests package
# To run the optional full test profile:
mvn -B -Pfull-tests test
java -jar target/eliya.jar
```

**Delivery scope:** updated source project and offline test scripts. A compiled, fully integration-tested runnable JAR is *not* included, because the required Maven dependency artifacts are unavailable in this execution environment. Live verification against your Jira/Confluence MCP endpoint and model must be performed in the deployment environment. The code does not claim to guarantee a response-time SLA for inaccessible or slow external providers.
