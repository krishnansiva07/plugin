package com.llmart.llm.controller;

import com.llmart.llm.dto.ChatRequest;
import com.llmart.llm.service.ChatService;
import com.llmart.llm.service.ModelProbeService;
import jakarta.validation.Valid;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

@RestController
@RequestMapping("/api/chat")
public class ChatController {
    private final ChatService chatService;
    private final ModelProbeService modelProbeService;
    private final com.llmart.llm.service.ModelIntentClassifier intentClassifier;

    public ChatController(ChatService chatService, ModelProbeService modelProbeService,
                          com.llmart.llm.service.ModelIntentClassifier intentClassifier) {
        this.chatService = chatService;
        this.modelProbeService = modelProbeService;
        this.intentClassifier = intentClassifier;
    }

    @PostMapping(value = "/stream", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
    public SseEmitter stream(@RequestHeader(value = "Authorization", required = false) String authorization,
                             @Valid @RequestBody ChatRequest request) {
        String key = authorization != null && authorization.startsWith("Bearer ") ? authorization.substring(7) : null;
        return chatService.stream(key, request);
    }

    /** Advisory classification only. Actual mutation permissions remain with AgentService. */
    @PostMapping(value = "/intent", produces = MediaType.APPLICATION_JSON_VALUE)
    public java.util.Map<String,Object> classifyIntent(
            @RequestHeader(value = "Authorization", required = false) String authorization,
            @RequestBody java.util.Map<String,Object> body) {
        String key = authorization != null && authorization.startsWith("Bearer ") ? authorization.substring(7) : null;
        var result = intentClassifier.classify(key, String.valueOf(body.getOrDefault("baseUrl", "")),
                String.valueOf(body.getOrDefault("model", "")),
                String.valueOf(body.getOrDefault("message", "")),
                String.valueOf(body.getOrDefault("previousAssistant", "")),
                String.valueOf(body.getOrDefault("selectedMode", "analyse")));
        return java.util.Map.of("engine", result.engine(), "intent", result.intent(),
                "modelUsed", result.modelUsed(), "reason", result.reason());
    }

    @PostMapping(value = "/cancel", produces = MediaType.APPLICATION_JSON_VALUE)
    public java.util.Map<String,Object> cancel(@RequestParam String conversationId) {
        return java.util.Map.of("cancelled", chatService.cancelChat(conversationId));
    }

    @PostMapping(value = "/model-probe", produces = MediaType.APPLICATION_JSON_VALUE)
    public java.util.Map<String,Object> probeModel(@RequestHeader(value = "Authorization", required = false) String authorization,
                                                   @RequestBody java.util.Map<String,Object> body) throws Exception {
        String key = authorization != null && authorization.startsWith("Bearer ") ? authorization.substring(7) : null;
        String baseUrl = String.valueOf(body.getOrDefault("baseUrl", "")).trim();
        String model = String.valueOf(body.getOrDefault("model", "")).trim();
        String type = String.valueOf(body.getOrDefault("type", "chat")).trim();
        return modelProbeService.probe(key, baseUrl, model, type);
    }
}
