package com.llmart.llm.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.llmart.llm.dto.ChatRequest;
import com.llmart.llm.dto.ChatSettings;
import org.springframework.stereotype.Service;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;
import java.util.concurrent.atomic.AtomicInteger;
import java.io.IOException;
import java.nio.file.*;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.*;

/**
 * Independent, bounded Terminal Agent sessions. No second planner: each session uses the same
 * AgentService/AgentRunService via ChatService but explicitly disables only plan approval.
 * In-flight terminal sessions are detached from browser connections. On restart they are marked
 * interrupted; they are never falsely claimed to be resumed OS processes.
 */
@Service
public class TerminalSessionService {
    private static final int MAX_EVENTS = 400;
    private static final long MAX_ACTIVITY_JOURNAL_BYTES = 64L * 1024 * 1024;
    private static final int MAX_ACTIVITY_TEXT = 24_000;
    private static final Set<String> JOURNAL_TYPES = Set.of(
            "agent_step", "agent_changes", "error", "stopped", "attachment_transfer", "turn_start");
    private static final int MAX_PENDING_PER_SESSION = 25;
    private static final int MAX_PENDING_TOTAL = 100;
    private static final int MAX_SESSIONS = 500;
    private static final int MAX_RESULT_CHARS = 600_000;
    private final ConcurrentHashMap<String, Session> sessions = new ConcurrentHashMap<>();
    private final Object gitMutationLock = new Object();
    // A nonblocking admission queue prevents same-root waiters from occupying the worker pool.
    // Canonical parent/child roots also conflict; isolated worktrees have separate roots.
    private final LinkedHashMap<String,Runnable> pendingJobs = new LinkedHashMap<>();
    private final Map<String,String> activeWorkspaces = new HashMap<>();
    // Credentials and full provider settings exist only in RAM; NEVER save them in session JSON.
    private final Map<String, PreparedInstruction> preparedInstructions = new HashMap<>();
    private record PreparedInstruction(String key, ChatRequest request) {}
    // At most 12 active sessions; queued jobs consume no worker threads.
    private final ExecutorService workers = Executors.newFixedThreadPool(12, r -> {
        Thread t = new Thread(r, "eliya52-terminal-manager"); t.setDaemon(true); return t;
    });
    // Delivery of live events must never block the Agent's tool/execution thread.
    // A bounded queue per viewer provides backpressure; overflow forces snapshot reconciliation.
    private static final int MAX_STREAM_VIEWERS = 8;
    private final AtomicInteger streamViewerCount = new AtomicInteger();
    private final ConcurrentHashMap<String, CopyOnWriteArrayList<LiveViewer>> liveViewers = new ConcurrentHashMap<>();
    private final ExecutorService streamWriters = Executors.newFixedThreadPool(MAX_STREAM_VIEWERS, r -> {
        Thread t = new Thread(r, "eliya64-terminal-stream"); t.setDaemon(true); return t;
    });
    private static final class LiveViewer {
        final SseEmitter emitter = new SseEmitter(0L);
        final ArrayBlockingQueue<Map<String,Object>> pending = new ArrayBlockingQueue<>(256);
        volatile boolean closed;
        void offer(Map<String,Object> event) {
            if (!pending.offer(event)) {
                pending.clear();
                pending.offer(Map.of("type", "resync"));
            }
        }
    }
    /** Stream sanitized deltas. The client reconciles its snapshot after reconnect/overflow. */
    public SseEmitter stream(String sessionId) {
        Session session = require(sessionId);
        if (streamViewerCount.incrementAndGet() > MAX_STREAM_VIEWERS) {
            streamViewerCount.decrementAndGet();
            throw new IllegalStateException("Too many live Terminal viewers; use polling fallback");
        }
        LiveViewer viewer = new LiveViewer();
        liveViewers.computeIfAbsent(sessionId, ignored -> new CopyOnWriteArrayList<>()).add(viewer);
        viewer.emitter.onCompletion(() -> viewer.closed = true);
        viewer.emitter.onTimeout(() -> viewer.closed = true);
        viewer.emitter.onError(ignored -> viewer.closed = true);
        viewer.offer(Map.of("type", "resync"));
        streamWriters.execute(() -> {
            try {
                while (!viewer.closed && !Thread.currentThread().isInterrupted()) {
                    Map<String,Object> next = viewer.pending.poll(12, TimeUnit.SECONDS);
                    if (next == null) viewer.emitter.send(SseEmitter.event().comment("heartbeat"));
                    else viewer.emitter.send(SseEmitter.event().name("terminal").data(next));
                }
            } catch (Exception ignored) { /* disconnects and blocked clients recover via snapshot */ }
            finally {
                viewer.closed = true;
                liveViewers.computeIfPresent(sessionId, (ignored, viewers) -> {
                    viewers.remove(viewer); return viewers.isEmpty() ? null : viewers;
                });
                streamViewerCount.decrementAndGet();
                viewer.emitter.complete();
            }
        });
        return viewer.emitter;
    }
    private void publish(Session session, String type, Object body) {
        var viewers = liveViewers.get(session.id);
        if (viewers == null || viewers.isEmpty()) return;
        Map<String,Object> item = new LinkedHashMap<>();
        item.put("type", type);
        item.put("seq", session.sequence);
        // Provider response tokens belong to this conversation; tool details must be redacted.
        if ("token".equals(type) && body instanceof Map<?,?> token) {
            Object text = token.get("text");
            item.put("text", text == null ? "" : String.valueOf(text));
        } else if ("agent_step".equals(type) || "agent_changes".equals(type) || "error".equals(type)) {
            item.put("data", redactActivity(body));
        }
        Map<String,Object> safe = Map.copyOf(item);
        for (LiveViewer viewer : viewers) if (!viewer.closed) viewer.offer(safe);
    }
    private final ChatService chat;
    private final AgentRunService agentRuns;
    private final AgentQuestionService questions;
    private final AgentService agent;
    private final AgentApprovalService approvals;
    private final ProjectService projects;
    private final ObjectMapper mapper;
    private final Path store;
    @org.springframework.beans.factory.annotation.Autowired(required = false)
    private FileService attachedFiles;
    @org.springframework.beans.factory.annotation.Autowired(required = false)
    private ConversationService conversationArchive;

    public TerminalSessionService(ChatService chat, AgentRunService agentRuns, ObjectMapper mapper,
                                  AgentQuestionService questions, ProjectService projects,
                                  AgentService agent, AgentApprovalService approvals) {
        this.chat = chat; this.agentRuns = agentRuns; this.mapper = mapper;
        this.questions = questions; this.projects = projects; this.agent = agent; this.approvals = approvals;
        store = Path.of(System.getProperty("eliya.terminal.store", "./data/terminal-sessions")).toAbsolutePath().normalize();
        try {
            Files.createDirectories(store);
            try (var files = Files.list(store)) {
                files.filter(f -> f.getFileName().toString().endsWith(".json")).limit(250).forEach(f -> {
                    try {
                        @SuppressWarnings("unchecked") Map<String,Object> saved = mapper.readValue(f.toFile(), Map.class);
                        Session recovered = Session.fromSaved(saved);
                        if (recovered != null) sessions.put(recovered.id, recovered);
                    } catch (Exception ignored) { /* corrupt history must not prevent application startup */ }
                });
            }
        } catch (IOException ignored) { /* transient sessions still work */ }
    }

    private String canonicalWorkspaceKey(String projectId) {
        if (projectId == null || projectId.isBlank()) return "project:unmapped";
        try {
            var selected = projects.require(projectId);
            if (selected.hasLocalPath()) return Path.of(selected.getLocalPath()).toRealPath().toString();
        } catch (Exception ignored) { /* Missing root remains uniquely identified. */ }
        return "project:" + projectId;
    }
    static boolean rootsOverlap(String left, String right) {
        if (left.equals(right)) return true;
        if (left.startsWith("project:") || right.startsWith("project:")) return false;
        Path a = Path.of(left).normalize(), b = Path.of(right).normalize();
        return a.startsWith(b) || b.startsWith(a);
    }
    private boolean overlapsActive(String root) {
        return activeWorkspaces.values().stream().anyMatch(active -> rootsOverlap(root, active));
    }
    /** Only idle, nonoverlapping workspaces can have Git metadata changed. */
    public void requireWorkspaceIdle(String projectId) {
        String key = canonicalWorkspaceKey(projectId);
        synchronized (gitMutationLock) {
            if (overlapsActive(key) || sessions.values().stream().anyMatch(s -> s.projectId != null
                    && Set.of("queued", "waiting_workspace", "running", "needs_input", "cancelling").contains(s.status)
                    && rootsOverlap(key, canonicalWorkspaceKey(s.projectId))))
                throw new IllegalStateException("Stop Terminal tasks operating in this workspace or its parent/child before changing Git metadata");
        }
    }
    /** Called only with gitMutationLock held; pending jobs do not tie up threads. */
    private void dispatchPending() {
        Iterator<Map.Entry<String,Runnable>> cursor = pendingJobs.entrySet().iterator();
        while (cursor.hasNext() && activeWorkspaces.size() < 12) {
            Map.Entry<String,Runnable> entry = cursor.next();
            Session session = sessions.get(entry.getKey());
            if (session == null || session.cancelRequested || "cancelled".equals(session.status)) {
                cursor.remove();
                continue;
            }
            String root = canonicalWorkspaceKey(session.projectId);
            if (overlapsActive(root)) {
                if (!"waiting_workspace".equals(session.status)) {
                    session.status = "waiting_workspace"; session.touch(); persist(session);
                }
                continue;
            }
            activeWorkspaces.put(session.id, root);
            Runnable body = entry.getValue();
            cursor.remove();
            workers.execute(() -> {
                try { body.run(); }
                finally {
                    synchronized (gitMutationLock) {
                        activeWorkspaces.remove(session.id);
                        // Failed, cancelled and blocked turns pause their queue; no blind follow-on edits.
                        if (!session.queue.isEmpty()) {
                            if (session.runNextAfterInterrupt) {
                                session.runNextAfterInterrupt = false;
                                session.queuePaused = false;
                            } else if (!"completed".equals(session.status)) session.queuePaused = true;
                            startNextQueued(session);
                        }
                        dispatchPending();
                    }
                }
            });
        }
    }
    public Map<String,Object> answer(String sessionId, String questionId, String choice, String detail) {
        Session s = require(sessionId);
        if (s.runId.isBlank() || !questions.answer(s.runId, questionId, choice, detail))
            throw new IllegalArgumentException("Question has expired or the response is invalid");
        if ("Cancel".equalsIgnoreCase(choice)) {
            s.queuePaused = true;
            s.cancelRequested = true;
            agentRuns.cancel(s.runId);
            s.status = "cancelling";
        } else s.status = "running";
        s.question = Map.of(); s.touch(); persist(s);
        publish(s, "question_answered", Map.of());
        return s.snapshot();
    }
    public <T> T withGitWorkspaceLock(String projectId, java.util.concurrent.Callable<T> operation) throws IOException {
        synchronized (gitMutationLock) {
            requireWorkspaceIdle(projectId);
            try { return operation.call(); }
            catch (IOException e) { throw e; }
            catch (Exception e) { throw new IOException("Git operation did not complete: " + e.getMessage(), e); }
        }
    }
    /** User explicitly chooses Terminal on the source Agent's pending plan screen. */
    public synchronized Map<String,Object> transfer(String key, String sourceRunId, String approvalId, ChatRequest request) {
        if (key == null || key.isBlank() || request == null || request.settings() == null)
            throw new IllegalArgumentException("Model configuration required");
        if (workers.isShutdown() || sessions.values().stream().filter(session ->
                Set.of("queued","waiting_workspace","running","needs_input","cancelling").contains(session.status)).count() >= 100)
            throw new IllegalStateException("Terminal queue unavailable; source approval remains active");
        AgentRunService.AgentRun source = agentRuns.require(sourceRunId);
        Map<String,Object> snapshot = source.snapshot();
        if (!Objects.equals(source.conversationId(), request.conversationId()))
            throw new IllegalArgumentException("Handoff conversation differs from pending Agent run");
        if (!Objects.equals(source.projectId(), request.projectId()))
            throw new IllegalArgumentException("Handoff workspace differs from source Agent workspace");
        if (source.projectId() == null || source.projectId().isBlank() ||
                !projects.require(source.projectId()).hasLocalPath())
            throw new IllegalStateException("Choose a mapped local workspace before transferring Agent execution to Terminal. The original plan remains pending.");
        if (source.finished() || source.planLocked() || source.mutationRevision() != 0)
            throw new IllegalStateException("Source Agent has already started or finished; plan cannot be transferred");
        List<String> plan = new ArrayList<>();
        Object rawPlan = snapshot.get("plan");
        if (rawPlan instanceof List<?> items) for (Object item : items) {
            if (item instanceof Map<?,?> row && row.get("text") instanceof String step && !step.isBlank()) plan.add(step);
        }
        if (plan.isEmpty()) throw new IllegalStateException("Source Agent has no executable plan");
        String objective = String.valueOf(snapshot.getOrDefault("objective", ""));
        if (objective.isBlank()) throw new IllegalStateException("Source Agent objective missing; transfer denied");
        ChatRequest preserved = new ChatRequest(request.conversationId(), objective, List.of(),
                request.projectId(), "agent", false, request.settings(), request.referenceProjectIds(),
                request.referenceProjectNames(), request.documentationTemplateSelected());
        if (!approvals.transferPlan(approvalId, sourceRunId))
            throw new IllegalStateException("Plan approval is no longer pending; nothing transferred");
        Map<String,Object> result = launchInternal(key, preserved, plan);
        result.put("sourceRunId", sourceRunId);
        return result;
    }

    public Map<String,Object> launch(String key, ChatRequest request) {
        return launchInternal(key, request, null, null);
    }

    /** Queue new instructions while the agent works. Clarification answers use /answer instead. */
    public Map<String,Object> message(String key, String sessionId, ChatRequest request) {
        Session session = require(sessionId);
        synchronized (gitMutationLock) {
            validateInstruction(key, request);
            if (request.chatMode() == com.llmart.llm.dto.ChatMode.AGENT) requireMappedWorkspace(request.projectId());
            // A done event may arrive before the worker releases the mutation lock: never overlap.
            boolean occupied = activeWorkspaces.containsKey(session.id) || pendingJobs.containsKey(session.id)
                    || Set.of("queued", "waiting_workspace", "running", "cancelling").contains(session.status);
            // A recoverable task has finished its worker and released workspace locks.
            // An explicit user correction must start a new linked turn, NOT sit forever
            // behind the session's own paused queue. Existing pending work stays paused.
            if (!occupied && (session.queue.isEmpty() || "needs_input".equals(session.status))) {
                session.queuePaused = !session.queue.isEmpty();
                return launchInternal(key, request, null, session);
            }
            if (session.queue.size() >= MAX_PENDING_PER_SESSION || pendingCount() >= MAX_PENDING_TOTAL)
                throw new IllegalStateException("Instruction queue full. Complete or remove queued instructions first.");
            QueuedInstruction item = QueuedInstruction.from(request);
            session.queue.addLast(item);
            preparedInstructions.put(item.id, new PreparedInstruction(key, request));
            session.touch(); persist(session);
            return session.snapshot();
        }
    }

    private void validateInstruction(String key, ChatRequest request) {
        if (key == null || key.isBlank()) throw new IllegalArgumentException("Model API key is required");
        if (request == null || request.settings() == null || request.message() == null || request.message().isBlank())
            throw new IllegalArgumentException("Terminal requires an instruction and configured model");
    }
    private void requireMappedWorkspace(String projectId) {
        if (projectId == null || projectId.isBlank() || !projects.require(projectId).hasLocalPath())
            throw new IllegalArgumentException("Choose a mapped local workspace before starting a terminal instruction");
    }
    private long pendingCount() { return sessions.values().stream().mapToLong(s -> s.queue.size()).sum(); }

    /** Reorder or edit pending instructions without ever changing a running instruction. */
    public Map<String,Object> editQueued(String sessionId, String itemId, String newPrompt) {
        synchronized (gitMutationLock) {
            Session session = require(sessionId);
            if (newPrompt == null || newPrompt.isBlank() || newPrompt.length() > 100_000)
                throw new IllegalArgumentException("Instruction must contain 1–100000 characters");
            QueuedInstruction original = session.queue.stream().filter(e -> e.id.equals(itemId)).findFirst()
                    .orElseThrow(() -> new NoSuchElementException("Queued instruction not found"));
            QueuedInstruction modified = original.withPrompt(newPrompt);
            replaceQueueItem(session, original, modified);
            PreparedInstruction prepared = preparedInstructions.get(itemId);
            if (prepared != null) preparedInstructions.put(itemId,
                    new PreparedInstruction(prepared.key, rebuildRequest(prepared.request, modified)));
            session.touch(); persist(session); return session.snapshot();
        }
    }
    private void replaceQueueItem(Session session, QueuedInstruction original, QueuedInstruction replacement) {
        List<QueuedInstruction> updated = new ArrayList<>(session.queue);
        int index = updated.indexOf(original);
        updated.set(index, replacement);
        session.queue.clear(); session.queue.addAll(updated);
    }
    public Map<String,Object> moveQueued(String sessionId, String itemId, String direction) {
        synchronized (gitMutationLock) {
            Session session = require(sessionId);
            List<QueuedInstruction> updated = new ArrayList<>(session.queue);
            int index = -1;
            for (int i=0; i<updated.size(); i++) if (updated.get(i).id.equals(itemId)) { index=i; break; }
            if (index < 0) throw new NoSuchElementException("Queued instruction not found");
            int destination = switch (direction == null ? "" : direction) {
                case "up" -> index-1; case "down" -> index+1;
                default -> throw new IllegalArgumentException("Direction must be up or down");
            };
            if (destination >= 0 && destination < updated.size()) {
                Collections.swap(updated, index, destination);
                session.queue.clear(); session.queue.addAll(updated);
                session.touch(); persist(session);
            }
            return session.snapshot();
        }
    }
    public Map<String,Object> removeQueued(String sessionId, String itemId) {
        synchronized (gitMutationLock) {
            Session session = require(sessionId);
            boolean removed = session.queue.removeIf(e -> e.id.equals(itemId));
            if (!removed) throw new NoSuchElementException("Queued instruction not found");
            preparedInstructions.remove(itemId);
            if (session.queue.isEmpty()) session.queuePaused = false;
            session.touch(); persist(session); return session.snapshot();
        }
    }
    /** Explicitly resume after a failure, stop, restart or lost in-memory credentials. */
    public Map<String,Object> resumeQueued(String key, String sessionId, ChatRequest configuration) {
        synchronized (gitMutationLock) {
            validateInstruction(key, configuration);
            Session session = require(sessionId);
            if (session.queue.isEmpty()) throw new IllegalStateException("No queued instructions to resume");
            for (QueuedInstruction item : session.queue) {
                requireMappedWorkspace(item.projectId);
                preparedInstructions.put(item.id, new PreparedInstruction(key, requestFromQueue(session, item, configuration)));
            }
            // An actual pending clarification must be answered before a queued task can start.
            if ("needs_input".equals(session.status) && "clarification".equals(session.question.get("kind"))
                    && !activeWorkspaces.containsKey(session.id))
                throw new IllegalStateException("Answer the Agent clarification before continuing");
            session.queuePaused = false;
            if (!activeWorkspaces.containsKey(session.id) && !pendingJobs.containsKey(session.id)
                    && !Set.of("running", "queued", "waiting_workspace", "cancelling").contains(session.status))
                startNextQueued(session);
            session.touch(); persist(session);
            return session.snapshot();
        }
    }
    /** User chooses to stop current work and run the next queued instruction, safely and sequentially. */
    public Map<String,Object> interruptAndNext(String sessionId) {
        synchronized (gitMutationLock) {
            Session session = require(sessionId);
            if (session.queue.isEmpty()) throw new IllegalStateException("No queued instruction to run next");
            if (!activeWorkspaces.containsKey(session.id) && !pendingJobs.containsKey(session.id))
                throw new IllegalStateException("There is no active task to interrupt; use Resume queue");
            session.runNextAfterInterrupt = true;
            session.queuePaused = false;
            Map<String,Object> result = cancelCurrent(session, false);
            // If the task never reached a worker there is nothing to await.
            if (!activeWorkspaces.containsKey(session.id) && !pendingJobs.containsKey(session.id)) {
                session.runNextAfterInterrupt = false;
                startNextQueued(session);
                result = session.snapshot();
            }
            return result;
        }
    }
    private ChatRequest rebuildRequest(ChatRequest source, QueuedInstruction item) {
        return new ChatRequest(item.attachmentIds.isEmpty() ? source.conversationId() : item.attachmentSourceId,
                item.prompt, item.attachmentIds, item.projectId,
                item.mode, false, source.settings(), item.referenceProjectIds, item.referenceProjectNames,
                source.documentationTemplateSelected());
    }
    private ChatRequest requestFromQueue(Session session, QueuedInstruction item, ChatRequest configuration) {
        @SuppressWarnings("unchecked") Map<String,Object> settings = mapper.convertValue(configuration.settings(), Map.class);
        settings.put("model", item.model);
        ChatSettings restored = mapper.convertValue(settings, ChatSettings.class);
        return new ChatRequest(item.attachmentIds.isEmpty() ? session.conversationId : item.attachmentSourceId,
                item.prompt, item.attachmentIds, item.projectId,
                item.mode, false, restored, item.referenceProjectIds, item.referenceProjectNames,
                item.documentationTemplateSelected);
    }
    /** Runs only after the previous worker has released the active session slot. */
    private void startNextQueued(Session session) {
        if (session.queuePaused || session.queue.isEmpty() || activeWorkspaces.containsKey(session.id)
                || pendingJobs.containsKey(session.id)) return;
        QueuedInstruction next = session.queue.peekFirst();
        PreparedInstruction prepared = preparedInstructions.get(next.id);
        if (prepared == null) { session.queuePaused=true; session.touch(); persist(session); return; }
        session.queue.removeFirst();
        preparedInstructions.remove(next.id);
        try { launchInternal(prepared.key, prepared.request, null, session); }
        catch (RuntimeException e) {
            session.queue.addFirst(next);
            preparedInstructions.put(next.id, prepared);
            session.queuePaused = true; session.error = "Unable to start queued instruction: " + e.getMessage();
            session.touch(); persist(session);
        }
    }

    private Map<String,Object> launchInternal(String key, ChatRequest request, List<String> copiedPlan) {
        return launchInternal(key, request, copiedPlan, null);
    }

    private Map<String,Object> launchInternal(String key, ChatRequest request, List<String> copiedPlan, Session continuing) {
        validateInstruction(key, request);
        if (sessions.values().stream().filter(s -> Set.of("queued","waiting_workspace","running","needs_input","cancelling").contains(s.status)).count() >= 100)
            throw new IllegalStateException("Terminal queue limit reached (100); stop or finish tasks before starting more");
        String id = continuing == null ? UUID.randomUUID().toString() : continuing.id;
        // A unique conversation prevents context/cancellation collision between simultaneous Terminal sessions.
        // Local workspace IDs remain explicitly reusable across conversations by ProjectService.
        // ChatService.getOrCreate() creates a different ID for unknown conversations. Reserve
        // the actual database conversation before the Terminal starts or attached evidence
        // and staged plans will silently target different conversation IDs.
        String conversationId = continuing != null ? continuing.conversationId : conversationArchive != null
                ? conversationArchive.create().getId() : UUID.randomUUID().toString();
        @SuppressWarnings("unchecked") Map<String,Object> settings = mapper.convertValue(request.settings(), Map.class);
        settings.put("agentPlanApproval", false);
        ChatSettings agentSettings = mapper.convertValue(settings, ChatSettings.class);
        ChatRequest agentRequest = new ChatRequest(conversationId, request.message(),
                List.of(), request.projectId(), request.chatMode().wireName(), false, agentSettings,
                request.referenceProjectIds(), request.referenceProjectNames(), request.documentationTemplateSelected());
        Session session = continuing == null
                ? new Session(id, conversationId, request.message(), request.projectId(),
                  request.referenceProjectIds() == null ? List.of() : List.copyOf(request.referenceProjectIds()),
                  request.referenceProjectNames() == null ? Map.of() : Map.copyOf(request.referenceProjectNames()),
                  request.settings().model()) : continuing;
        synchronized (gitMutationLock) {
            if (continuing != null) session.nextTurn(request);
            else session.mode = request.chatMode().wireName();
            // A single tab retains its complete tool trace across linked instructions.
            session.accept("turn_start", Map.of("detail", "New terminal instruction accepted", "projectId", request.projectId()));
            appendActivity(session);
            sessions.put(id, session);
            pruneHistory();
            persist(session);
            if (copiedPlan != null && request.chatMode() == com.llmart.llm.dto.ChatMode.AGENT) agent.stageTransferredPlan(conversationId, copiedPlan);
            pendingJobs.put(id, () -> {
            try {
                if (session.cancelRequested || "cancelled".equals(session.status)) return;
                session.status = "running"; session.touch(); persist(session);
                // Copy only explicitly attached evidence; never copy a whole Chat history.
                // A new terminal turn can attach new documents, even in an existing session.
                ChatRequest effective = agentRequest;
                if (attachedFiles != null && conversationArchive != null
                        && request.attachmentIds() != null && !request.attachmentIds().isEmpty()) {
                    if (request.conversationId() == null || request.conversationId().isBlank())
                        throw new IllegalArgumentException("Attachment source conversation is required");
                    List<String> selected = request.conversationId().equals(conversationId)
                            ? request.attachmentIds()
                            : attachedFiles.copySelectedForTerminal(request.conversationId(), conversationId,
                                    request.attachmentIds());
                    effective = new ChatRequest(conversationId, request.message(), selected,
                            request.projectId(), request.chatMode().wireName(), false, agentSettings,
                            request.referenceProjectIds(), request.referenceProjectNames(),
                            request.documentationTemplateSelected());
                    session.accept("attachment_transfer", Map.of("count", selected.size()));
                    appendActivity(session);
                } else if (continuing == null && copiedPlan != null && attachedFiles != null
                        && request.conversationId() != null && !request.conversationId().isBlank()
                        && !request.conversationId().equals(conversationId)) {
                    // Legacy Chat-to-Terminal handoff retains its original document context.
                    List<String> transferred = attachedFiles.copyForTerminal(request.conversationId(), conversationId);
                    if (!transferred.isEmpty())
                        effective = new ChatRequest(conversationId, request.message(), transferred,
                                request.projectId(), request.chatMode().wireName(), false, agentSettings,
                                request.referenceProjectIds(), request.referenceProjectNames(),
                                request.documentationTemplateSelected());
                }
                chat.runTerminal(key, effective, (type, body) -> {
                    session.accept(type, body, redactActivity(body));
                    publish(session, type, body);
                    if (JOURNAL_TYPES.contains(type)) appendActivity(session);
                    if ("meta".equals(type) && !session.runId.isBlank()) {
                        questions.enable(session.runId);
                        questions.observe(session.runId, pending -> {
                            session.accept("question", pending, redactActivity(pending));
                            publish(session, "question", pending);
                            persist(session);
                        });
                    }
                    if (session.cancelRequested && !session.runId.isBlank()) agentRuns.cancel(session.runId);
                    if ("done".equals(type) && !session.runId.isBlank()) {
                        try {
                            String actual = String.valueOf(agentRuns.status(session.runId).get("status"));
                            if (Set.of("failed","cancelled","blocked","interrupted").contains(actual)) session.status=actual;
                            Map<String,Object> runState = agentRuns.status(session.runId);
                            boolean noChanges = runState.get("mutationRevision") instanceof Number n && n.longValue() == 0
                                    && runState.get("totalToolActions") instanceof Number actions && actions.longValue() == 0;
                            String validation = String.valueOf(runState.getOrDefault("planValidationStatus", "not_run"));
                            if (noChanges && Set.of("failed","blocked").contains(session.status)
                                    && !"approved".equals(validation)) {
                                String reason = String.valueOf(runState.getOrDefault("planValidationSummary", ""));
                                if (reason.isBlank()) reason = String.valueOf(runState.getOrDefault("lastRecoveryAnalysis", ""));
                                if (reason.isBlank()) reason = "The requested plan did not pass validation.";
                                session.status = "needs_input";
                                session.question = Map.of(
                                    "kind", "plan_correction", "reason", reason.length() > 1500 ? reason.substring(0,1500) : reason,
                                    "proposal", "Regenerate a task-relevant plan that explicitly addresses the validation findings, preserves all original requirements, and does not omit requested source evidence. Do not modify workspace files until the new plan passes validation.",
                                    "note", "The original plan failed before recorded workspace modifications. Continuing starts a new linked run rather than resuming the failed planner process.");
                            }
                        } catch (Exception ignored) { /* persisted event remains authoritative if status lookup failed */ }
                    }
                    if ("meta".equals(type) || "done".equals(type) || "error".equals(type) || "stopped".equals(type)
                            || ("agent_step".equals(type) && session.sequence % 15 == 0)
                            || ("token".equals(type) && session.sequence % 100 == 0
                                    && System.nanoTime() - session.lastPersistNanos > TimeUnit.SECONDS.toNanos(2))) persist(session);
                });
            } catch (Exception e) {
                session.status = "failed";
                session.error = e.getMessage() == null ? "Unable to launch Terminal" : e.getMessage();
                session.touch(); persist(session);
            } finally {
                // ELIYA70: A failed model/verification run is a RESULT, not a user question.
                // Converting every such run to needs_input made a completed-looking Markdown
                // task display the misleading "Continue with guidance / Retry / Close task" popup.
                // Preserve the real failed/blocked status and the original Agent report.
                // Only an explicit ask_user clarification or genuine plan-correction gate
                // may put a terminal into needs_input. Never auto-retry or claim success.
                if (!session.cancelRequested && Set.of("failed", "blocked").contains(session.status)) {
                    session.queuePaused = !session.queue.isEmpty();
                    session.question = Map.of();
                    session.touch(); persist(session);
                }
                agent.discardTransferredPlan(conversationId);
                if (!session.runId.isBlank()) questions.disable(session.runId);
            }
            });
            dispatchPending();
        }
        return session.snapshot();
    }

    /** Durable, ordered tool history; token fragments and credentials are never journaled. */
    private Path activityPath(String sessionId) { return store.resolve(sessionId + ".actions.jsonl"); }

    private void appendActivity(Session session) {
        Map<String,Object> latest;
        synchronized (session) {
            latest = session.events.peekLast();
            if (latest == null || !JOURNAL_TYPES.contains(String.valueOf(latest.get("type")))) return;
        }
        try {
            Files.createDirectories(store);
            Path path = activityPath(session.id);
            if (Files.exists(path) && Files.size(path) > MAX_ACTIVITY_JOURNAL_BYTES) {
                session.activityTruncated = true;
                return;
            }
            Files.writeString(path, mapper.writeValueAsString(latest) + "\n", java.nio.charset.StandardCharsets.UTF_8,
                    StandardOpenOption.CREATE, StandardOpenOption.APPEND);
        } catch (Exception e) {
            session.activityJournalError = true;
        }
    }

    /** Load the most recent events before a sequence number, for explicit history pagination. */
    public Map<String,Object> activity(String sessionId, Long before, Integer requestedLimit) {
        Session session = require(sessionId);
        int limit = Math.max(1, Math.min(200, requestedLimit == null ? 100 : requestedLimit));
        long ceiling = before == null || before <= 0 ? Long.MAX_VALUE : before;
        ArrayDeque<Map<String,Object>> page = new ArrayDeque<>();
        long eligible = 0;
        try {
            Path path = activityPath(session.id);
            if (Files.isRegularFile(path)) {
                try (var lines = Files.lines(path, java.nio.charset.StandardCharsets.UTF_8)) {
                    var iterator = lines.iterator();
                    while (iterator.hasNext()) {
                        String line = iterator.next();
                        try {
                            @SuppressWarnings("unchecked") Map<String,Object> event = mapper.readValue(line, Map.class);
                            Object seqValue = event.get("seq");
                            if (!(seqValue instanceof Number n) || n.longValue() >= ceiling) continue;
                            eligible++;
                            page.addLast(event);
                            if (page.size() > limit) page.removeFirst();
                        } catch (Exception ignored) { /* ignore an incomplete last line */ }
                    }
                }
            } else { // Sessions written before this feature have only their in-memory event window.
                synchronized (session) {
                    for (Map<String,Object> event : session.events) {
                        if (!JOURNAL_TYPES.contains(String.valueOf(event.get("type")))) continue;
                        if (!(event.get("seq") instanceof Number n) || n.longValue() >= ceiling) continue;
                        eligible++; page.addLast(event);
                        if (page.size() > limit) page.removeFirst();
                    }
                }
            }
        } catch (IOException e) { throw new IllegalStateException("Cannot read terminal action history", e); }
        return Map.of("events", List.copyOf(page), "hasMore", eligible > page.size(),
                "truncated", session.activityTruncated, "journalError", session.activityJournalError);
    }

    /** Redact sensitive keys in all persisted actions, including nested command arguments. */
    private Object redactActivity(Object body) {
        if (body == null) return Map.of();
        try { return redactTree(mapper.convertValue(body, Object.class), "", 0); }
        catch (IllegalArgumentException ignored) { return Map.of("detail", "[Unserializable tool event]"); }
    }
    private static Object redactTree(Object value, String key, int depth) {
        if (depth > 12) return "[Nested tool details omitted]";
        if (key.matches("(?i).*(?:api.?key|access.?token|refresh.?token|authorization|password|secret|private.?key|credential|cookie).*")) return "[REDACTED]";
        if (value instanceof Map<?,?> map) {
            Map<String,Object> safe = new LinkedHashMap<>();
            for (var entry : map.entrySet()) {
                if (safe.size() >= 100) break;
                String name = String.valueOf(entry.getKey());
                safe.put(name, redactTree(entry.getValue(), name, depth+1));
            }
            return safe;
        }
        if (value instanceof List<?> items) {
            List<Object> safe = new ArrayList<>();
            for (Object item : items) { if (safe.size() >= 100) break; safe.add(redactTree(item, "", depth+1)); }
            return safe;
        }
        if (value instanceof String text) {
            String redacted = text.replaceAll("(?i)bearer\\s+[a-z0-9._~+/-]{12,}", "Bearer [REDACTED]")
                    .replaceAll("(?i)(?:sk-|ghp_|github_pat_)[a-z0-9_-]{16,}", "[REDACTED]");
            return redacted.length() > MAX_ACTIVITY_TEXT
                    ? redacted.substring(0, MAX_ACTIVITY_TEXT) + "\n[Tool detail truncated for display]" : redacted;
        }
        return value;
    }

    public List<Map<String,Object>> list() {
        return sessions.values().stream().sorted(Comparator.comparing((Session s) -> s.createdAt).reversed())
                .limit(100).map(session -> {
                    Map<String,Object> summary = session.summary();
                    if (!session.runId.isBlank() && Set.of("queued", "waiting_workspace", "running", "needs_input", "cancelling")
                            .contains(session.status)) try {
                        Map<String,Object> run = agentRuns.status(session.runId);
                        for (String field : List.of("progressPercent", "progressPhase", "progressDetail", "activePlanIndex"))
                            if (run.containsKey(field)) summary.put(field, run.get(field));
                        if (run.get("plan") instanceof List<?> steps) {
                            summary.put("stepCount", steps.size());
                            summary.put("completedSteps", steps.stream().filter(step -> step instanceof Map<?,?> m
                                    && "completed".equals(m.get("status"))).count());
                        }
                    } catch (Exception ignored) { /* run initializing or history pruned */ }
                    return summary;
                }).toList();
    }

    public Map<String,Object> get(String id) {
        Session s = require(id);
        Map<String,Object> result = s.snapshot();
        if ("waiting_workspace".equals(s.status)) result.put("queueReason", "Another Terminal is using this workspace or a parent folder. This task will start when the earlier task finishes; the selected workspace is not missing.");
        if (!s.runId.isBlank()) {
            Map<String,Object> pending = questions.pending(s.runId);
            if (!pending.isEmpty()) {
                result.put("status", "needs_input"); result.put("question", pending);
            }
            try {
                Map<String,Object> state = agentRuns.status(s.runId);
                Map<String,Object> progress = new LinkedHashMap<>();
                for (String field : List.of("status","progressPercent","progressPhase","progressDetail",
                        "planValidationStatus","planValidationSummary","activePlanIndex","plan","tokenUsage"))
                    if (state.containsKey(field)) progress.put(field,state.get(field));
                result.put("progress",progress);
            } catch (Exception ignored) { /* may be pending initialization */ }
        }
        return result;
    }
    public Map<String,Object> cancel(String id) {
        synchronized (gitMutationLock) {
            Session s = require(id);
            s.queuePaused = true;
            s.runNextAfterInterrupt = false;
            return cancelCurrent(s, true);
        }
    }
    private Map<String,Object> cancelCurrent(Session s, boolean pause) {
        if (pause) s.queuePaused = true;
        s.cancelRequested = true;
        if (s.runId != null && !s.runId.isBlank()) { agentRuns.cancel(s.runId); questions.cancel(s.runId); }
        if (Set.of("needs_input", "queued", "waiting_workspace").contains(s.status)) {
            s.status = "cancelled"; s.touch(); persist(s);
            synchronized (gitMutationLock) {
                Runnable discarded = pendingJobs.remove(s.id);
                if (discarded != null) agent.discardTransferredPlan(s.conversationId);
                dispatchPending();
            }
        } else if ("running".equals(s.status)) {
            s.status = "cancelling"; s.touch(); persist(s);
        }
        s.touch(); persist(s);
        return s.snapshot();
    }
    private Session require(String id) {
        Session s = sessions.get(id);
        if (s == null) throw new NoSuchElementException("Terminal session not found");
        return s;
    }
    private void persist(Session s) {
        synchronized (s) {
            try {
                Files.createDirectories(store);
                Path tmp = store.resolve(s.id + ".json.tmp");
                mapper.writeValue(tmp.toFile(), s.snapshotForPersistence());
                s.lastPersistNanos = System.nanoTime();
                try { Files.move(tmp, store.resolve(s.id + ".json"), StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
                catch (AtomicMoveNotSupportedException ex) { Files.move(tmp, store.resolve(s.id + ".json"), StandardCopyOption.REPLACE_EXISTING); }
            } catch (Exception ignored) { /* keep working even when logging cannot persist */ }
        }
    }

    private void pruneHistory() {
        if (sessions.size() <= MAX_SESSIONS) return;
        sessions.values().stream()
                .filter(s -> s.queue.isEmpty() && !Set.of("queued", "waiting_workspace", "running", "needs_input", "cancelling").contains(s.status))
                .sorted(Comparator.comparing(s -> s.createdAt))
                .limit(sessions.size() - MAX_SESSIONS)
                .forEach(s -> {
                    if (sessions.remove(s.id, s)) {
                        try { Files.deleteIfExists(store.resolve(s.id + ".json")); Files.deleteIfExists(activityPath(s.id)); }
                        catch (IOException ignored) { /* bounded memory is more important than a failed cleanup */ }
                    }
                });
    }

    @jakarta.annotation.PreDestroy
    public void shutdown() {
        for (Session s : sessions.values()) {
            if (Set.of("queued", "waiting_workspace", "running", "needs_input", "cancelling").contains(s.status)) {
                s.cancelRequested = true;
                if (!s.runId.isBlank()) { agentRuns.cancel(s.runId); questions.disable(s.runId); }
                s.status = "interrupted"; s.touch(); persist(s);
            }
        }
        synchronized (gitMutationLock) {
            for (Session s : sessions.values()) if (!s.queue.isEmpty()) {
                s.queuePaused = true; s.touch(); persist(s);
            }
            pendingJobs.clear();
            activeWorkspaces.clear();
            preparedInstructions.clear();
        }
        workers.shutdownNow();
        liveViewers.values().forEach(viewers -> viewers.forEach(viewer -> {
            viewer.closed = true;
            viewer.emitter.complete();
        }));
        streamWriters.shutdownNow();
    }

    private static final class QueuedInstruction {
        final String id, prompt, projectId, model, createdAt, attachmentSourceId, mode;
        final List<String> attachmentIds;
        final Boolean documentationTemplateSelected;
        final List<String> referenceProjectIds;
        final Map<String,String> referenceProjectNames;
        QueuedInstruction(String id, String prompt, String projectId, String model, String createdAt,
                          List<String> refs, Map<String,String> names, Boolean documentationTemplateSelected,
                          String attachmentSourceId, List<String> attachmentIds, String mode) {
            this.mode = com.llmart.llm.dto.ChatMode.from(mode).wireName();
            this.id=id; this.prompt=prompt; this.projectId=projectId; this.model=model;
            this.createdAt=createdAt; this.referenceProjectIds=List.copyOf(refs);
            this.documentationTemplateSelected=Boolean.TRUE.equals(documentationTemplateSelected);
            this.referenceProjectNames=Map.copyOf(names);
            this.attachmentSourceId=attachmentSourceId == null ? "" : attachmentSourceId;
            this.attachmentIds=attachmentIds == null ? List.of() : List.copyOf(attachmentIds);
        }
        static QueuedInstruction from(ChatRequest request) {
            return new QueuedInstruction(UUID.randomUUID().toString(), request.message(), request.projectId(),
                    request.settings().model(), Instant.now().toString(),
                    request.referenceProjectIds() == null ? List.of() : request.referenceProjectIds(),
                    request.referenceProjectNames() == null ? Map.of() : request.referenceProjectNames(),
                    request.documentationTemplateSelected(),request.conversationId(),request.attachmentIds(),request.chatMode().wireName());
        }
        QueuedInstruction withPrompt(String newPrompt) {
            return new QueuedInstruction(id,newPrompt,projectId,model,createdAt,referenceProjectIds,referenceProjectNames,documentationTemplateSelected,attachmentSourceId,attachmentIds,mode);
        }
        Map<String,Object> snapshot() {
            Map<String,Object> result=new LinkedHashMap<>();
            result.put("id",id); result.put("prompt",prompt); result.put("mode",mode); result.put("projectId",projectId);
            result.put("model",model); result.put("createdAt",createdAt);
            result.put("referenceProjectIds",referenceProjectIds); result.put("referenceProjectNames",referenceProjectNames);
            result.put("documentationTemplateSelected",documentationTemplateSelected);
            // Do not include attachment IDs in browser-visible activity logs.
            result.put("attachmentCount",attachmentIds.size());
            result.put("attachmentSourceId",attachmentSourceId);
            result.put("attachmentIds",attachmentIds);
            return result;
        }
        static QueuedInstruction restore(Object saved) {
            if (!(saved instanceof Map<?,?> map) || !(map.get("id") instanceof String id)
                    || !id.matches("[a-f0-9-]{36}") || !(map.get("prompt") instanceof String prompt)
                    || prompt.isBlank() || !(map.get("projectId") instanceof String projectId)) return null;
            List<String> refs=new ArrayList<>();
            if (map.get("referenceProjectIds") instanceof List<?> ids) for (Object ref : ids)
                if (ref instanceof String value) refs.add(value);
            Map<String,String> names=new LinkedHashMap<>();
            if (map.get("referenceProjectNames") instanceof Map<?,?> aliases) for (var e : aliases.entrySet())
                if (e.getKey() instanceof String k && e.getValue() instanceof String v) names.put(k,v);
            List<String> attachments=new ArrayList<>();
            if(map.get("attachmentIds") instanceof List<?> values) for(Object value:values)
                if(value instanceof String s) attachments.add(s);
            return new QueuedInstruction(id,prompt,projectId,
                    String.valueOf(map.containsKey("model") ? map.get("model") : ""),
                    String.valueOf(map.containsKey("createdAt") ? map.get("createdAt") : ""),refs,names,
                    Boolean.TRUE.equals(map.get("documentationTemplateSelected")),
                    String.valueOf(map.containsKey("attachmentSourceId") ? map.get("attachmentSourceId") : ""), attachments,
                    String.valueOf(map.containsKey("mode") ? map.get("mode") : "agent"));
        }
    }

    private static final class Session {
        final String id, conversationId, prompt, createdAt;
        String projectId, model, currentPrompt;
        List<String> referenceProjectIds;
        Map<String,String> referenceProjectNames;
        final ArrayDeque<Map<String,String>> turns = new ArrayDeque<>();
        final ConcurrentLinkedDeque<QueuedInstruction> queue = new ConcurrentLinkedDeque<>();
        boolean queuePaused, runNextAfterInterrupt;
        final ArrayDeque<Map<String,Object>> events = new ArrayDeque<>();
        volatile boolean activityTruncated, activityJournalError;
        String status = "queued", error = "", runId = "", answer = "", updatedAt, mode = "agent";
        volatile boolean cancelRequested;
        Map<String,String> question = Map.of();
        long sequence;
        volatile long lastPersistNanos;
        Session(String id, String conversationId, String prompt, String projectId,
                List<String> refs, Map<String,String> names, String model) {
            this(id, conversationId, prompt, projectId, refs, names, model, Instant.now().toString());
        }
        Session(String id, String conversationId, String prompt, String projectId,
                List<String> refs, Map<String,String> names, String model, String originalCreatedAt) {
            this.id=id; this.conversationId=conversationId; this.prompt=prompt; this.projectId=projectId;
            this.model=model == null ? "" : model;
            this.currentPrompt = prompt;
            this.referenceProjectIds=refs; this.referenceProjectNames=names;
            turns.addLast(Map.of("role", "user", "content", truncateTurn(prompt)));
            this.createdAt=originalCreatedAt == null || originalCreatedAt.isBlank()
                    ? Instant.now().toString() : originalCreatedAt;
            this.updatedAt=createdAt;
        }
        private static String truncateTurn(String content) {
            return content == null ? "" : content.length() > 35000 ? content.substring(0,35000) + "\n[Older content truncated in terminal display]" : content;
        }
        synchronized void nextTurn(ChatRequest request) {
            this.projectId = request.projectId();
            this.currentPrompt = request.message();
            this.mode = request.chatMode().wireName();
            this.model = request.settings().model();
            this.referenceProjectIds = request.referenceProjectIds() == null ? List.of() : List.copyOf(request.referenceProjectIds());
            this.referenceProjectNames = request.referenceProjectNames() == null ? Map.of() : Map.copyOf(request.referenceProjectNames());
            this.status = "queued"; this.error = ""; this.answer = ""; this.runId = "";
            this.question = Map.of(); this.cancelRequested = false; this.events.clear();
            turns.addLast(Map.of("role", "user", "content", truncateTurn(request.message())));
            while (turns.size() > 30) turns.removeFirst();
            touch();
        }
        synchronized void touch() { updatedAt=Instant.now().toString(); }
        synchronized void accept(String type, Object body) { accept(type, body, body); }
        synchronized void accept(String type, Object body, Object safeEventData) {
            if ("meta".equals(type) && body instanceof Map<?,?> m) runId=String.valueOf(m.containsKey("agentRunId") ? m.get("agentRunId") : "");
            if ("token".equals(type) && body instanceof Map<?,?> m) {
                Object text = m.get("text");
                if (text != null) answer = truncate(answer + text);
            }
            if ("done".equals(type)) {
                if (body instanceof com.llmart.llm.dto.MessageDto dto && dto.content() != null) answer = truncate(dto.content());
                // A late provider 'done' must never convert a user's Stop into success.
                status = cancelRequested ? "cancelled" : "completed";
                turns.addLast(Map.of("role", "assistant", "content", truncateTurn(answer)));
                while (turns.size() > 30) turns.removeFirst();
            }
            if ("error".equals(type)) {
                status="failed";
                error=body instanceof Map<?,?> report
                        ? String.valueOf((report.containsKey("message") ? report.get("message") : "Terminal request failed"))
                        : String.valueOf(body);
            }
            if ("stopped".equals(type)) status="cancelled";
            sequence++;
            Map<String,Object> event=new LinkedHashMap<>();
            event.put("seq",sequence); event.put("type", type);
            if (!"token".equals(type)) event.put("data", safeEventData);
            events.addLast(event);
            while (events.size()>MAX_EVENTS) events.removeFirst();
            touch();
        }
        static String truncate(String text) {
            return text.length() > MAX_RESULT_CHARS ? text.substring(text.length()-MAX_RESULT_CHARS) : text;
        }
        synchronized Map<String,Object> summary() {
            Map<String,Object> result=new LinkedHashMap<>();
            result.put("id",id); result.put("status",status); result.put("mode",mode); result.put("runId",runId);
            result.put("prompt",currentPrompt.length() > 180 ? currentPrompt.substring(0,180) + "…" : currentPrompt);
            result.put("projectId",projectId); result.put("model",model); result.put("createdAt",createdAt); result.put("updatedAt",updatedAt);
            result.put("queueCount",queue.size()); result.put("queuePaused",queuePaused);
            return result;
        }
        synchronized Map<String,Object> snapshotForPersistence() {
            Map<String,Object> saved=snapshot();
            // The durable JSON is a lightweight restart checkpoint, not the action archive.
            // Older actions stay in the separately paginated, redacted .actions.jsonl journal.
            List<Map<String,Object>> tail=new ArrayList<>(events);
            if(tail.size()>80) tail=tail.subList(tail.size()-80,tail.size());
            saved.put("events",List.copyOf(tail));
            return saved;
        }
        synchronized Map<String,Object> snapshot() {
            Map<String,Object> result=new LinkedHashMap<>(summary());
            result.put("conversationId",conversationId);
            result.put("fullPrompt",currentPrompt);
            result.put("turns",List.copyOf(turns));
            result.put("referenceProjectIds",referenceProjectIds);
            result.put("referenceProjectNames",referenceProjectNames);
            result.put("answer",answer); result.put("error",error);
            result.put("question",question);
            result.put("sequence",sequence); result.put("events",List.copyOf(events));
            result.put("activityTruncated",activityTruncated);
            result.put("activityJournalError",activityJournalError);
            result.put("queue", queue.stream().map(QueuedInstruction::snapshot).toList());
            return result;
        }
        static Session fromSaved(Map<String,Object> saved) {
            if (saved == null || !(saved.get("id") instanceof String id) || !id.matches("[a-f0-9-]{36}")) return null;
            @SuppressWarnings("unchecked") List<String> refs=saved.get("referenceProjectIds") instanceof List<?> list
                    ? list.stream().filter(String.class::isInstance).map(String.class::cast).toList(): List.of();
            Map<String,String> aliases = new LinkedHashMap<>();
            if (saved.get("referenceProjectNames") instanceof Map<?,?> names) {
                for (var e : names.entrySet()) if (e.getKey() instanceof String && e.getValue() instanceof String)
                    aliases.put((String)e.getKey(), (String)e.getValue());
            }
            Session session=new Session(id, String.valueOf(saved.getOrDefault("conversationId", "")),
                    String.valueOf(saved.getOrDefault("fullPrompt", saved.getOrDefault("prompt", ""))),
                    (String)saved.get("projectId"),refs, Map.copyOf(aliases),
                    String.valueOf(saved.getOrDefault("model", "")),
                    String.valueOf(saved.getOrDefault("createdAt", Instant.now().toString())));
            session.currentPrompt=String.valueOf(saved.getOrDefault("fullPrompt", session.prompt));
            session.mode = com.llmart.llm.dto.ChatMode.from(String.valueOf(saved.getOrDefault("mode", "agent"))).wireName();
            if (saved.get("turns") instanceof List<?> savedTurns) {
                session.turns.clear();
                for (Object turn : savedTurns) if (turn instanceof Map<?,?> m
                        && m.get("role") instanceof String role && m.get("content") instanceof String content
                        && ("user".equals(role) || "assistant".equals(role)))
                    session.turns.addLast(Map.of("role",role,"content",truncateTurn(content)));
                while (session.turns.size() > 30) session.turns.removeFirst();
            }
            if (saved.get("queue") instanceof List<?> savedQueue) for (Object obj : savedQueue) {
                QueuedInstruction entry = QueuedInstruction.restore(obj);
                if (entry != null && session.queue.size() < MAX_PENDING_PER_SESSION) session.queue.addLast(entry);
            }
            // Never run persisted instructions without the user reauthorizing provider credentials.
            session.queuePaused = !session.queue.isEmpty();
            session.runId=String.valueOf(saved.getOrDefault("runId", ""));
            session.answer=String.valueOf(saved.getOrDefault("answer", ""));
            session.error=String.valueOf(saved.getOrDefault("error", ""));
            if (saved.get("question") instanceof Map<?,?> q) {
                Map<String,String> restored = new LinkedHashMap<>();
                for (var e : q.entrySet()) if (e.getKey() instanceof String && e.getValue() instanceof String)
                    restored.put((String)e.getKey(),(String)e.getValue());
                session.question=Map.copyOf(restored);
            }
            session.activityTruncated=Boolean.TRUE.equals(saved.get("activityTruncated"));
            session.activityJournalError=Boolean.TRUE.equals(saved.get("activityJournalError"));
            session.status=String.valueOf(saved.getOrDefault("status", "interrupted"));
            // Upgrade ELIYA69 persisted false-positive recovery dialogs in-place. They
            // were generated by the generic FAILED -> needs_input mapping, not ask_user.
            // Real clarification and plan-correction questions stay interactive.
            if ("needs_input".equals(session.status) &&
                    "execution_followup".equals(session.question.get("kind"))) {
                session.status = "failed";
                session.question = Map.of();
            }
            if (Set.of("queued", "waiting_workspace", "running", "cancelling").contains(session.status)) session.status="interrupted";
            session.updatedAt=String.valueOf(saved.getOrDefault("updatedAt", session.createdAt));
            if (saved.get("events") instanceof List<?> list) for (Object item:list) if (item instanceof Map<?,?> m) {
                @SuppressWarnings("unchecked") Map<String,Object> map=(Map<String,Object>)m;
                session.events.addLast(map);
            }
            if (saved.get("sequence") instanceof Number n) session.sequence=n.longValue();
            return session;
        }
    }
}
