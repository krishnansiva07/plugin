package com.llmart.llm.service;

import java.util.regex.Pattern;

/**
 * Single routing rule for MCP across Chat and Agent.
 * MCP is an explicit opt-in: only the current user prompt can enable MCP and it must contain
 * the standalone token "MCP" (case-insensitive). Integration names, issue keys, URLs, server
 * names, attachments and conversation history are intentionally ignored by this gate.
 */
final class McpPromptGate {
    private static final Pattern EXPLICIT_MCP = Pattern.compile("(?i)(?<![a-z0-9])mcp(?![a-z0-9])");

    private McpPromptGate() { }

    static boolean explicitlyRequested(String prompt) {
        return prompt != null && !prompt.isBlank() && EXPLICIT_MCP.matcher(prompt).find();
    }
}
