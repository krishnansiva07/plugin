package com.llmart.llm.dto;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;

import java.util.List;

public record ChatRequest(
        String conversationId,
        String message,
        List<String> attachmentIds,
        String projectId,
        String mode,
        Boolean regenerate,
        @Valid @NotNull ChatSettings settings,
        List<String> referenceProjectIds,
        java.util.Map<String, String> referenceProjectNames,
        Boolean documentationTemplateSelected
) {
    public ChatRequest(String conversationId, String message, List<String> attachmentIds, String projectId,
                       String mode, Boolean regenerate, ChatSettings settings) {
        this(conversationId, message, attachmentIds, projectId, mode, regenerate, settings, List.of(), java.util.Map.of(), false);
    }
    public ChatRequest(String conversationId, String message, List<String> attachmentIds, String projectId,
                       String mode, Boolean regenerate, ChatSettings settings, List<String> referenceProjectIds) {
        this(conversationId, message, attachmentIds, projectId, mode, regenerate, settings, referenceProjectIds, java.util.Map.of(), false);
    }

    public ChatRequest(String conversationId, String message, List<String> attachmentIds, String projectId,
                       String mode, Boolean regenerate, ChatSettings settings, List<String> referenceProjectIds,
                       java.util.Map<String, String> referenceProjectNames) {
        this(conversationId, message, attachmentIds, projectId, mode, regenerate, settings, referenceProjectIds,
                referenceProjectNames, false);
    }

    /**
     * Built-in documentation structure is opt-in only. The UI must explicitly mark a documentation template as
     * selected; free-form documentation prompts never enable the ELIYA template implicitly.
     */
    public boolean useDocumentationTemplate() { return Boolean.TRUE.equals(documentationTemplateSelected); }

    public boolean isRegenerate() { return Boolean.TRUE.equals(regenerate); }
    public ChatMode chatMode() { return ChatMode.from(mode); }
}
