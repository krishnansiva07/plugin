package com.llmart.llm.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;

import java.net.http.HttpClient;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

class McpToolAliasResolutionTest {

    private McpManager manager() {
        return new McpManager(new ObjectMapper(), HttpClient.newHttpClient());
    }

    @Test
    void resolvesGatewayPipeAliasesToAdvertisedFunctionNames() {
        McpManager manager = manager();
        try {
            String confluence = "mcp__Myworkspace__getconfluencecontent";
            String search = "mcp__Myworkspace__searchconfluencepages";
            Map<String, McpManager.ToolRef> refs = new LinkedHashMap<>();
            refs.put(confluence, new McpManager.ToolRef("Myworkspace", "getConfluenceContent", true));
            refs.put(search, new McpManager.ToolRef("Myworkspace", "searchConfluencePages", true));
            McpManager.Catalog catalog = new McpManager.Catalog(List.of(), Map.copyOf(refs), List.of());

            assertEquals(confluence, manager.resolveFunctionName(catalog, "mcp|Myworkspace|getconfluencecontent").orElseThrow());
            assertEquals(search, manager.resolveFunctionName(catalog, "MCP/MyWorkspace/SearchConfluencePages").orElseThrow());
            assertEquals(confluence, manager.resolveFunctionName(catalog, "getConfluenceContent").orElseThrow());
            assertEquals(search, manager.resolveFunctionName(catalog, search.toUpperCase()).orElseThrow());
        } finally {
            manager.shutdown();
        }
    }

    @Test
    void refusesAmbiguousNativeToolAliases() {
        McpManager manager = manager();
        try {
            Map<String, McpManager.ToolRef> refs = new LinkedHashMap<>();
            refs.put("mcp__jira__search", new McpManager.ToolRef("jira", "search", true));
            refs.put("mcp__gitlab__search", new McpManager.ToolRef("gitlab", "search", true));
            McpManager.Catalog catalog = new McpManager.Catalog(List.of(), Map.copyOf(refs), List.of());

            assertTrue(manager.resolveFunctionName(catalog, "search").isEmpty());
            assertEquals("mcp__jira__search", manager.resolveFunctionName(catalog, "mcp|jira|search").orElseThrow());
        } finally {
            manager.shutdown();
        }
    }

    @Test
    void compactGatewayDiscoverAndExecuteReadStayAvailableToChat() {
        McpManager manager = manager();
        try {
            Map<String, McpManager.ToolRef> refs = Map.of(
                    "mcp__atlassian__discover", new McpManager.ToolRef("atlassian", "discover", false),
                    "mcp__atlassian__executeRead", new McpManager.ToolRef("atlassian", "executeRead", false),
                    "mcp__atlassian__executeWrite", new McpManager.ToolRef("atlassian", "executeWrite", false));
            McpManager.Catalog catalog = new McpManager.Catalog(List.of(), refs, List.of());

            assertTrue(manager.isChatReadOnly(catalog, "mcp__atlassian__discover"));
            assertTrue(manager.isChatReadOnly(catalog, "mcp__atlassian__executeRead"));
            assertFalse(manager.isChatReadOnly(catalog, "mcp__atlassian__executeWrite"));
        } finally {
            manager.shutdown();
        }
    }
}
