package com.llmart.llm.service;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class AgentDocumentationPromptPriorityTest {

    @Test
    void wholeRepositoryDocumentationUsesCoverageWorkflowButScopedDocumentationIsNotBroadened() {
        assertTrue(AgentService.isDocumentationTask(
                "Create complete documentation by analysing the entire source code for this project."));
        assertFalse(AgentService.isDocumentationTask(
                "Create API documentation for the payment module only."));
        assertFalse(AgentService.isDocumentationTask(
                "Document this class only and keep exactly my requested headings."));
    }
}
