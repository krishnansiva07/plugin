package com.llmart.llm.dto;

import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

class ChatRequestDocumentationTemplateTest {

    @Test
    void documentationTemplateIsOffUnlessTheUiExplicitlySelectsIt() {
        ChatRequest normalPrompt = new ChatRequest("c1", "Create the documentation exactly as requested", List.of(),
                "p1", "agent", false, null, List.of(), Map.of());
        assertFalse(normalPrompt.useDocumentationTemplate());

        ChatRequest uiSelectedTemplate = new ChatRequest("c1", "Use this template but keep my explicit changes", List.of(),
                "p1", "agent", false, null, List.of(), Map.of(), true);
        assertTrue(uiSelectedTemplate.useDocumentationTemplate());
    }
}
