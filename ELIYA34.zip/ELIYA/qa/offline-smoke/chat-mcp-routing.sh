#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../.."
DIR=$(mktemp -d); trap 'rm -rf "$DIR"' EXIT
ROOT="$DIR/src"
mkdir -p "$ROOT/com/llmart/llm/service" "$ROOT/com/llmart/llm/dto" "$ROOT/com/fasterxml/jackson/databind/node" "$ROOT/com/fasterxml/jackson/databind" "$ROOT/org/springframework/stereotype" "$DIR/classes"
cp src/main/java/com/llmart/llm/service/ChatMcpService.java \
   src/main/java/com/llmart/llm/service/McpPromptGate.java \
   src/main/java/com/llmart/llm/service/JiraJqlRecovery.java \
   src/main/java/com/llmart/llm/service/McpEvidenceStore.java "$ROOT/com/llmart/llm/service/"
cat > "$ROOT/org/springframework/stereotype/Service.java" <<'JAVA'
package org.springframework.stereotype; public @interface Service {}
JAVA
cat > "$ROOT/com/fasterxml/jackson/databind/JsonNode.java" <<'JAVA'
package com.fasterxml.jackson.databind;
import java.util.*;
public class JsonNode implements Iterable<JsonNode> {
 protected String value; public JsonNode(){} public JsonNode(String value){this.value=value;}
 public JsonNode path(String name){return this;} public String asText(String fallback){return value==null?fallback:value;}
 public String asText(){return asText("");} public int asInt(int fallback){try{return value==null?fallback:Integer.parseInt(value);}catch(Exception e){return fallback;}}
 public boolean isObject(){return false;} public boolean isArray(){return false;} public boolean isNull(){return false;}
 public Iterator<JsonNode> iterator(){return Collections.emptyIterator();} @Override public String toString(){return value==null?"null":value;}
}
JAVA
cat > "$ROOT/com/fasterxml/jackson/databind/ObjectMapper.java" <<'JAVA'
package com.fasterxml.jackson.databind;
public class ObjectMapper {
 public String writeValueAsString(Object value){return value==null?"null":value.toString();}
 public JsonNode readTree(String text){return new JsonNode();}
 public com.fasterxml.jackson.databind.node.ObjectNode createObjectNode(){return new com.fasterxml.jackson.databind.node.ObjectNode();}
}
JAVA
cat > "$ROOT/com/fasterxml/jackson/databind/node/ObjectNode.java" <<'JAVA'
package com.fasterxml.jackson.databind.node;
import com.fasterxml.jackson.databind.JsonNode; import java.util.*;
public class ObjectNode extends JsonNode {
 private final Map<String,JsonNode> fields=new LinkedHashMap<>();
 public ObjectNode put(String key,String value){fields.put(key,new JsonNode(value));return this;}
 public ObjectNode put(String key,int value){fields.put(key,new JsonNode(String.valueOf(value)));return this;}
 @Override public JsonNode path(String key){return fields.getOrDefault(key,new JsonNode());}
 @Override public boolean isObject(){return true;} public ObjectNode deepCopy(){ObjectNode c=new ObjectNode();c.fields.putAll(fields);return c;}
 @Override public String toString(){return fields.toString();}
}
JAVA
cat > "$ROOT/com/llmart/llm/dto/ChatSettings.java" <<'JAVA'
package com.llmart.llm.dto;
public class ChatSettings { public String chatModelOrPrimary(){return "mock-chat";} public String baseUrl(){return "http://localhost";} public int safeMaxTokens(){return 1024;} }
JAVA
cat > "$ROOT/com/llmart/llm/dto/ChatRequest.java" <<'JAVA'
package com.llmart.llm.dto; public class ChatRequest {private final ChatSettings s=new ChatSettings(); public ChatSettings settings(){return s;} }
JAVA
cat > "$ROOT/com/llmart/llm/service/AgentCancelledException.java" <<'JAVA'
package com.llmart.llm.service; public class AgentCancelledException extends RuntimeException {public AgentCancelledException(String s){super(s);}}
JAVA
cat > "$ROOT/com/llmart/llm/service/OpenAiCompatibleClient.java" <<'JAVA'
package com.llmart.llm.service;
import java.util.*;import java.util.function.*;import com.fasterxml.jackson.databind.JsonNode;import com.llmart.llm.dto.ChatSettings;
public class OpenAiCompatibleClient {
 public record AgentToolCall(String id,String name,JsonNode arguments) {}
 public record AgentCompletion(String content,List<AgentToolCall> toolCalls,boolean hasToolCall) {}
 public Queue<AgentCompletion> turns=new ArrayDeque<>(); public final List<List<Map<String,Object>>> snapshots=new ArrayList<>(); public List<Map<String,Object>> lastTools=List.of();
 public AgentCompletion completeAgent(String key,String url,String model,int max,List<Map<String,Object>> context,List<Map<String,Object>> tools,boolean json,BooleanSupplier cancelled){lastTools=tools;snapshots.add(new ArrayList<>(context));return turns.remove();}
 public String stream(String key,ChatSettings settings,List<Map<String,Object>> messages,Consumer<String> onToken,BooleanSupplier cancelled){onToken.accept("streamed");return "streamed";}
}
JAVA
cat > "$ROOT/com/llmart/llm/service/McpManager.java" <<'JAVA'
package com.llmart.llm.service;
import java.util.*;import java.nio.file.Path;import java.util.function.BooleanSupplier;import com.fasterxml.jackson.databind.JsonNode;
public class McpManager {
 public record ToolRef(String server,String tool,boolean readOnlyHint){}
 public record Catalog(List<Map<String,Object>> definitions,Map<String,ToolRef> byFunction,List<String> diagnostics){}
 public boolean enabled=true; public int calls=0, catalogs=0, prefetches=0;
 private static Map<String,Object> d(String name,String desc){return Map.of("type","function","function",Map.of("name",name,"description",desc,"parameters",Map.of("type","object","properties",Map.of())));}
 private final Map<String,ToolRef> refs=Map.of(
   "mcp__atlassian__searchConfluence",new ToolRef("atlassian","searchConfluence",true),
   "mcp__atlassian__getConfluenceContent",new ToolRef("atlassian","getConfluenceContent",true),
   "mcp__atlassian__discover",new ToolRef("atlassian","discover",true),
   "mcp__atlassian__executeWrite",new ToolRef("atlassian","executeWrite",false));
 private final Catalog cat=new Catalog(List.of(
   d("mcp__atlassian__searchConfluence","Search Confluence pages"),d("mcp__atlassian__getConfluenceContent","Read full Confluence content"),
   d("mcp__atlassian__discover","Discover Atlassian operation"),d("mcp__atlassian__executeWrite","Write Atlassian content")),refs,List.of("atlassian: connected; tools=4"));
 public boolean globallyEnabled(){return enabled;} public List<String> configuredServerNames(Path root){return enabled?List.of("atlassian","confluence"):List.of();}
 public void prefetchChatCatalog(Path root){prefetches++;} public Catalog catalogCachedForChat(Path root){catalogs++;return cat;}
 public boolean isChatReadOnly(Catalog c,String name){ToolRef r=c.byFunction().get(name);return r==null||r.readOnlyHint();}
 public Optional<String> resolveFunctionName(Catalog c,String requested){return c!=null&&c.byFunction().containsKey(requested)?Optional.of(requested):Optional.empty();}
 public String call(Path root,Catalog c,String name,JsonNode args,BooleanSupplier cancelled){calls++; if(name.contains("searchConfluence")) return "mcpServer=atlassian; tool=searchConfluence; isError=false\nPayment Architecture | id=123 | short snippet only"; if(name.contains("getConfluenceContent")){StringBuilder b=new StringBuilder("mcpServer=atlassian; tool=getConfluenceContent; isError=false\n");for(int i=0;i<900;i++)b.append("Section ").append(i).append(" payment retry failure handling details and table values.\n");return b.toString();} return "ok";}
}
JAVA
cat > "$ROOT/com/llmart/llm/service/ChatMcpOfflineTest.java" <<'JAVA'
package com.llmart.llm.service;
import java.util.*;import com.llmart.llm.dto.ChatRequest;import com.fasterxml.jackson.databind.node.ObjectNode;
public class ChatMcpOfflineTest {
 static void check(boolean ok,String msg){if(!ok)throw new AssertionError(msg);} static OpenAiCompatibleClient.AgentToolCall tc(String id,String name){return new OpenAiCompatibleClient.AgentToolCall(id,name,new ObjectNode().put("pageId","123"));}
 public static void main(String[] args)throws Exception{
  McpManager mcp=new McpManager(); OpenAiCompatibleClient llm=new OpenAiCompatibleClient(); ChatMcpService chat=new ChatMcpService(llm,mcp,new com.fasterxml.jackson.databind.ObjectMapper()); ChatRequest req=new ChatRequest();
  check(!chat.shouldHandle("Explain Java inheritance"),"ordinary chat hijacked");
  check(!chat.shouldHandle("Search Confluence for payment architecture"),"Confluence without MCP hijacked Chat");
  check(!chat.shouldHandle("Get ABC-123 status from Jira"),"Jira key without MCP hijacked Chat");
  check(!chat.shouldHandle("Run /jdk-11.0.22/bin/java -jar Wero.v1.jar"),"JDK version falsely routed to MCP");
  check(!chat.shouldHandle("MCPServer health"),"MCP substring should not route");
  check(chat.shouldHandle("Search Confluence MCP for payment architecture"),"explicit Confluence MCP route missed");
  check(chat.shouldHandle("use mcp to read Jira ABC-123"),"lowercase explicit MCP route missed");
  chat.prefetchIfNeeded("Search Confluence for payment architecture"); check(mcp.prefetches==0,"normal Chat started MCP prefetch");
  chat.prefetchIfNeeded("Search Confluence MCP for payment architecture"); check(mcp.prefetches==1,"explicit MCP did not prefetch");
  llm.turns.add(new OpenAiCompatibleClient.AgentCompletion("",List.of(tc("1","mcp__atlassian__searchConfluence")),true));
  llm.turns.add(new OpenAiCompatibleClient.AgentCompletion("Premature snippet answer",List.of(),false));
  llm.turns.add(new OpenAiCompatibleClient.AgentCompletion("",List.of(tc("2","mcp__atlassian__getConfluenceContent")),true));
  llm.turns.add(new OpenAiCompatibleClient.AgentCompletion("Complete grounded answer",List.of(),false));
  String prompt="Search Confluence MCP for Payment Architecture and give complete details";
  String answer=chat.answer("k",req,prompt,List.of(Map.of("role","user","content",prompt)),()->false,a->{},t->{}).orElseThrow();
  check(answer.equals("Complete grounded answer"),"search snippet incorrectly satisfied content request: "+answer); check(mcp.calls==2,"expected search + full page read");
  boolean retained=llm.snapshots.stream().flatMap(List::stream).map(m->String.valueOf(m.get("content"))).anyMatch(x->x.contains("MCP_EVIDENCE")&&x.contains("retained=complete"));
  check(retained,"large page was not retained as complete evidence"); check(llm.lastTools.stream().anyMatch(t->t.toString().contains("eliya_mcp_evidence_read")),"evidence read tool not exposed");
  int before=mcp.calls; llm.turns.add(new OpenAiCompatibleClient.AgentCompletion("",List.of(tc("3","mcp__atlassian__getConfluenceContent")),true)); llm.turns.add(new OpenAiCompatibleClient.AgentCompletion("Cached answer",List.of(),false));
  chat.answer("k",req,"Read complete details from Confluence MCP Payment Architecture",List.of(Map.of("role","user","content","Read complete details from Confluence MCP Payment Architecture")),()->false,a->{},t->{}).orElseThrow();
  check(mcp.calls==before,"repeated page read did not use short-lived cache");
  var noMcpFollow=chat.answer("k",req,"what about failure handling?",List.of(Map.of("role","assistant","content","From the Confluence MCP Payment Architecture page..."),Map.of("role","user","content","what about failure handling?")),()->false,a->{},t->{});
  check(noMcpFollow.isEmpty(),"prior MCP history incorrectly forced MCP without MCP in current prompt"); check(mcp.calls==before,"non-MCP follow-up called MCP");
  llm.turns.add(new OpenAiCompatibleClient.AgentCompletion("",List.of(tc("4","mcp__atlassian__getConfluenceContent")),true)); llm.turns.add(new OpenAiCompatibleClient.AgentCompletion("Failure handling answer",List.of(),false));
  String follow=chat.answer("k",req,"Using MCP, what about failure handling?",List.of(Map.of("role","assistant","content","From the Confluence MCP Payment Architecture page..."),Map.of("role","user","content","Using MCP, what about failure handling?")),()->false,a->{},t->{}).orElseThrow();
  check(follow.equals("Failure handling answer"),"explicit MCP follow-up did not stay on MCP route"); check(mcp.calls==before,"explicit follow-up should reuse cached page evidence");
  mcp.enabled=false; String disabled=chat.answer("k",req,"Read Confluence MCP Payment Architecture",List.of(),()->false,a->{},t->{}).orElseThrow(); check(disabled.contains("MCP is disabled"),"master-off did not block explicit MCP");
  var normalWhenDisabled=chat.answer("k",req,"Read Confluence Payment Architecture",List.of(),()->false,a->{},t->{}); check(normalWhenDisabled.isEmpty(),"MCP-off normal Chat was incorrectly blocked by MCP");
  System.out.println("PASS: strict explicit-MCP routing, no accidental Jira/JDK/Confluence routing, prefetch gating, evidence retention/cache, explicit follow-up, hard MCP-off");
 }
}
JAVA
javac --release 17 -d "$DIR/classes" $(find "$ROOT" -name '*.java')
java -cp "$DIR/classes" com.llmart.llm.service.ChatMcpOfflineTest
