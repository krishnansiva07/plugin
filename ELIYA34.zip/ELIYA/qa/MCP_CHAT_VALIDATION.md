# ELIYA32 Chat MCP routing validation

## Implemented
- **Strict explicit MCP routing:** Chat and Agent discover/use MCP only when the current user prompt contains the standalone word `MCP` (case-insensitive). Jira, Confluence, GitLab, SonarQube, issue keys such as `ABC-123`, JDK versions such as `jdk-11.0.22`, configured server names, and previous MCP turns do not activate MCP on their own.
- MCP follow-up routing is not inherited from conversation history. A follow-up must contain `MCP` again if MCP should be used.
- Chat normalizes common MCP tool aliases such as `mcp|server|tool` back to the exact advertised `mcp__server__tool` function.
- Alias resolution is case-insensitive and can resolve a unique native MCP tool name, but refuses ambiguous native names shared by multiple servers.
- Chat still exposes only a compact ranked MCP tool list initially. If the model requests a valid safe tool from the full discovered catalog, ELIYA adds only that resolved tool on demand instead of failing the request.
- Jira, Confluence, GitLab and SonarQube receive source-specific ranking boosts so their relevant tools are more likely to be in the initial compact set.
- Compact gateway tools such as `discover` and `executeRead` are treated as read capabilities; `executeWrite` and other mutating operations remain action-gated.
- Confluence search results are not treated as full page evidence when the request asks for details/content; Chat must continue to the content/read capability.
- MCP master switch behavior is unchanged: MCP disabled means no MCP discovery or calls.

## Offline validation completed
- Parsed all 121 Java main/test source files with the JDK compiler parser: 0 syntax errors.
- Focused MCP alias/safety Java harness: 10 assertions passed.
- Front-end JavaScript test suite: 18 passed, 0 failed.
- `node --check` passed for app.js, markdown.js, confluence-composer.js and prompt-catalog.js.

## Maven limitation in this environment
The build runtime does not have Maven installed and outbound Maven Central access is unavailable, so a full dependency-resolved Maven compile/test could not be executed here. The added JUnit regression test is included at:
`src/test/java/com/llmart/llm/service/McpToolAliasResolutionTest.java`.

Run on the target machine:
`./mvnw -Pfull-tests clean test`
then
`./mvnw -DskipTests package`

## Manual regression tests
1. Chat + MCP ON: `can you get maternity leave details from Confluence MCP`
   - Expect Confluence search followed by content/read retrieval and a grounded answer.
   - Must not show `MCP TOOL NOT AVAILABLE` for `mcp|...|searchconfluencepages` / `getconfluencecontent` aliases.
2. Chat + MCP ON: `can you get maternity leave details from Confluence` (no `MCP`)
   - Must stay on normal Chat. No MCP discovery, connection, catalog lookup, or tool call is allowed.
3. Chat + MCP ON: `Get ABC-123 status from Jira` (no `MCP`)
   - Must stay on normal Chat.
4. Chat + MCP ON: a Linux command containing `jdk-11.0.22`
   - Must stay on normal Chat; the JDK version must never be interpreted as a Jira/MCP key.
5. Agent + MCP ON: `use Jira MCP to get ABC-123`
   - MCP discovery is allowed. The same request without the word `MCP` must not load the MCP catalog.
6. GitLab: `Use GitLab MCP to read MR 123` and verify the appropriate read tool is selected.
7. SonarQube: `Use SonarQube MCP to read the quality gate` and verify retrieval.
8. MCP OFF: an explicit request such as `Use Confluence MCP ...` must report MCP disabled in Chat. A normal prompt without `MCP` must continue through normal Chat rather than being blocked by the MCP switch.
