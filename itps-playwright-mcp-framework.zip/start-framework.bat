@echo off
setlocal
cd /d "%~dp0"
where java >nul 2>&1 || (echo Java 17+ is required.& pause & exit /b 1)
where mvn >nul 2>&1 || (echo Maven 3.9+ is required.& pause & exit /b 1)
where node >nul 2>&1 || (echo Node.js 20+ is required.& pause & exit /b 1)
where npx >nul 2>&1 || (echo npx is required.& pause & exit /b 1)
echo Starting ITPS Playwright MCP Framework at http://localhost:8090
mvn clean spring-boot:run
pause
