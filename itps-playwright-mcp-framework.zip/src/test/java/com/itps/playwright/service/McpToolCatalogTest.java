package com.itps.playwright.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.itps.playwright.model.McpTool;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

class McpToolCatalogTest {
    private final ObjectMapper mapper = new ObjectMapper();

    @Test
    void startAndStopNeverMistakeTraceRecordingToolsForBrowserLifecycle() {
        McpToolCatalog catalog = new McpToolCatalog(List.of(
                tool("browser_record_start", "Start trace recording"),
                tool("browser_record_stop", "Stop trace recording"),
                tool("launch_browser", "Launch browser"),
                tool("close_browser", "Close browser")
        ));

        assertThat(catalog.startTool()).isPresent();
        assertThat(catalog.stopTool()).isPresent();
        assertThat(catalog.startTool().orElseThrow().getName()).isEqualTo("launch_browser");
        assertThat(catalog.stopTool().orElseThrow().getName()).isEqualTo("close_browser");
    }

    @Test
    void exactLifecycleToolsRemainFirstPriority() {
        McpToolCatalog catalog = new McpToolCatalog(List.of(
                tool("browser_record_start", "trace"),
                tool("browser_start", "real start"),
                tool("browser_stop", "real stop")
        ));

        assertThat(catalog.startTool().orElseThrow().getName()).isEqualTo("browser_start");
        assertThat(catalog.stopTool().orElseThrow().getName()).isEqualTo("browser_stop");
    }

    private McpTool tool(String name, String description) {
        return new McpTool(name, description, mapper.createObjectNode());
    }
}
