package com.itps.playwright.service;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class PlaywrightSemanticActionTest {
    @Test void parsesExactCapsuleWithoutSiblingText() {
        var spec = PlaywrightSemanticAction.parse("Click \"NEW-IP\" capsule");
        assertEquals(PlaywrightSemanticAction.Kind.CLICK, spec.kind());
        assertEquals("NEW-IP", spec.target());
        assertEquals("capsule", spec.hint());
        String script = PlaywrightSemanticAction.buildScript(spec);
        assertTrue(script.contains("norm(ownName(e))===norm(wanted)"));
        assertFalse(script.contains("exact:false"));
        assertFalse(script.contains("getByText"));
        assertTrue(script.contains("matchedText"));
    }

    @Test void parsesFillValueAndFieldSeparately() {
        var spec = PlaywrightSemanticAction.parse("Type \"BCEF\" into \"MF\" field");
        assertEquals(PlaywrightSemanticAction.Kind.FILL, spec.kind());
        assertEquals("MF", spec.target());
        assertEquals("BCEF", spec.value());
        assertTrue(PlaywrightSemanticAction.buildScript(spec).contains("Fill verification failed"));
    }

    @Test void parsesUnquotedNaturalLanguageTargetsExactly() {
        assertEquals("NEW-IP", PlaywrightSemanticAction.parse("Click the capsule or card named NEW-IP").target());
        assertEquals("New search", PlaywrightSemanticAction.parse("Click Menu Item New search").target());
        assertEquals("Search", PlaywrightSemanticAction.parse("Click Search Icon").target());
        assertEquals("Payment", PlaywrightSemanticAction.parse("Click Payment button").target());
    }

    @Test void neverUsesRegeneratedCandidateIds() {
        String script = PlaywrightSemanticAction.buildScript(PlaywrightSemanticAction.parse("Click \"NEW-IP\" capsule"));
        assertFalse(script.contains("candidateId"));
        assertTrue(script.contains("data-itps-selected-target"));
    }
}
