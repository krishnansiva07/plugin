package com.itps.playwright.service;

import com.itps.playwright.model.RunStatus;
import org.springframework.stereotype.Service;

import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

@Service
public class RunStore {
    private final Map<String, RunStatus> runs = new ConcurrentHashMap<>();
    public void put(RunStatus status) { runs.put(status.getRunId(), status); }
    public Optional<RunStatus> get(String runId) { return Optional.ofNullable(runs.get(runId)); }
}
