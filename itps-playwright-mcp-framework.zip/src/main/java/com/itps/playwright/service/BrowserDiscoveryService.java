package com.itps.playwright.service;

import com.itps.playwright.model.BrowserOption;
import org.springframework.stereotype.Service;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

@Service
public class BrowserDiscoveryService {
    public List<BrowserOption> discover() {
        List<BrowserOption> out = new ArrayList<>();
        add(out, "chrome", "Google Chrome", List.of(
                System.getenv("PROGRAMFILES") + "\\Google\\Chrome\\Application\\chrome.exe",
                System.getenv("PROGRAMFILES(X86)") + "\\Google\\Chrome\\Application\\chrome.exe",
                System.getenv("LOCALAPPDATA") + "\\Google\\Chrome\\Application\\chrome.exe"));
        add(out, "edge", "Microsoft Edge", List.of(
                System.getenv("PROGRAMFILES(X86)") + "\\Microsoft\\Edge\\Application\\msedge.exe",
                System.getenv("PROGRAMFILES") + "\\Microsoft\\Edge\\Application\\msedge.exe"));
        return out;
    }
    private void add(List<BrowserOption> out, String id, String name, List<String> paths) {
        String found = paths.stream().filter(p -> p != null && !p.startsWith("null") && Files.isRegularFile(Path.of(p))).findFirst().orElse("");
        out.add(new BrowserOption(id, name, found, !found.isBlank(), false, found.isBlank() ? "Not detected; Playwright can use its managed browser if installed." : "Detected."));
    }
}
