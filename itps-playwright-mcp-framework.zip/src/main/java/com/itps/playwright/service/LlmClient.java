package com.itps.playwright.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.itps.playwright.model.RunConfig;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.*;

@Service
public class LlmClient {
    private final ObjectMapper mapper = new ObjectMapper();
    private final RestTemplate restTemplate = new RestTemplate();

    public boolean isConfigured(RunConfig config) {
        return config != null && config.getLlmBaseUrl() != null && !config.getLlmBaseUrl().isBlank();
    }

    public String complete(String systemPrompt, String userPrompt, RunConfig config, int maxTokens) throws Exception {
        if (!isConfigured(config)) {
            throw new IllegalArgumentException("LLM base URL is required when Use LLM is ON");
        }
        String endpoint = normalizeEndpoint(config.getLlmBaseUrl());
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("model", defaultIfBlank(config.getLlmModel(), "gpt-oss-120b"));
        body.put("temperature", 0.05);
        body.put("max_tokens", Math.max(300, maxTokens));
        body.put("messages", List.of(
                Map.of("role", "system", "content", systemPrompt),
                Map.of("role", "user", "content", userPrompt)
        ));

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        if (config.getLlmApiKey() != null && !config.getLlmApiKey().isBlank()) {
            headers.setBearerAuth(config.getLlmApiKey().trim());
        }
        String raw = restTemplate.postForObject(endpoint, new HttpEntity<>(body, headers), String.class);
        JsonNode root = mapper.readTree(raw == null ? "{}" : raw);
        String content = root.path("choices").path(0).path("message").path("content").asText();
        return extractJson(content);
    }

    public String planPlaywrightSnapshotAction(String userPrompt, RunConfig config) throws Exception {
        String system = "You are controlling Microsoft Playwright MCP through the ITPS Java framework. " +
                "Return only valid minified JSON and exactly one next browser action. " +
                "Use only a tool listed by the caller and only element references that are present in the current browser_snapshot. " +
                "Playwright MCP builds may use ref or target; preserve the exact reference shown in the snapshot and never invent one. " +
                "Read the test instruction literally. For NEW-IP choose NEW-IP only, never MONEXT, BCEF, a shared card, row, or parent container. " +
                "Prefer exact accessible name and exact visible text. For menu items choose the smallest actionable menuitem/button/link matching the requested name. " +
                "For typing use the supplied value exactly. Never guess business data. " +
                "Return {\"done\":false,\"confidence\":0.0,\"toolName\":\"browser_click\",\"arguments\":{},\"reason\":\"snapshot evidence\"}. " +
                "If the requested outcome is already visible return {\"done\":true,\"confidence\":1.0,\"reason\":\"already satisfied\"}.";
        return complete(system, userPrompt, config, 1600);
    }

    public String planPlaywrightDomAction(String userPrompt, RunConfig config) throws Exception {
        String system = "You are the primary DOM-grounded planner for ITPS Playwright MCP execution. " +
                "Return only valid minified JSON. Analyse the exact instruction and the supplied live interactive DOM inventory. " +
                "Choose only one candidate that is present in the inventory. Never invent selectors, refs, text, roles or elements. " +
                "Prefer exact accessible-name and exact visible-text matches, then use container/context evidence. " +
                "Never choose a parent/container when a smaller clickable descendant represents the requested control. " +
                "For names such as NEW-IP, do not choose MONEXT, BCEF or a shared parent. " +
                "Return {\"confidence\":0.0,\"candidateId\":\"c1\",\"action\":\"click|hover|fill|select|press\",\"value\":\"\",\"expected\":\"short postcondition\",\"why\":\"DOM evidence\"}.";
        return complete(system, userPrompt, config, 1600);
    }

    public String healPlaywrightMcpCall(String userPrompt, RunConfig config) throws Exception {
        String system = "You are the self-healing brain for ITPS Playwright MCP execution. " +
                "Return only valid minified JSON. Use only Playwright MCP tools listed by the caller. " +
                "Never return Java, Selenium, raw Playwright code, browser_run_code_unsafe, shell commands, or invented element refs. " +
                "Use the fresh accessibility snapshot. Prefer exact snapshot refs or unique safe selectors. " +
                "Return {\"confidence\":0.0,\"strategy\":\"short name\",\"calls\":[{\"tool\":\"browser_click\",\"arguments\":{}}],\"why\":\"evidence\"}.";
        return complete(system, userPrompt, config, 1800);
    }

    private String normalizeEndpoint(String base) {
        String trimmed = base.trim();
        if (trimmed.endsWith("/chat/completions")) return trimmed;
        if (trimmed.endsWith("/")) return trimmed + "chat/completions";
        return trimmed + "/chat/completions";
    }

    private String extractJson(String content) {
        if (content == null) return "{}";
        String trimmed = content.trim();
        if (trimmed.startsWith("```")) {
            trimmed = trimmed.replaceFirst("^```(?:json)?", "").replaceFirst("```$", "").trim();
        }
        int objectStart = trimmed.indexOf('{');
        int objectEnd = trimmed.lastIndexOf('}');
        int arrayStart = trimmed.indexOf('[');
        int arrayEnd = trimmed.lastIndexOf(']');
        if (objectStart >= 0 && objectEnd >= objectStart && (arrayStart < 0 || objectStart < arrayStart)) {
            return trimmed.substring(objectStart, objectEnd + 1);
        }
        if (arrayStart >= 0 && arrayEnd >= arrayStart) {
            return trimmed.substring(arrayStart, arrayEnd + 1);
        }
        return trimmed;
    }

    private String defaultIfBlank(String value, String fallback) {
        return value == null || value.isBlank() ? fallback : value;
    }
}
