package com.itps.playwright.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.itps.playwright.model.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.nio.file.*;
import java.time.Duration;
import java.time.Instant;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Service
public class PlaywrightMcpExecutionEngine implements ExecutionEngine {
    private static final Pattern XPATH = Pattern.compile("(?i)xpath\\s*=\\s*[\\\"']([^\\\"']+)[\\\"']|using\\s+xpath\\s+[\\\"']([^\\\"']+)[\\\"']");
    private static final Pattern CSS = Pattern.compile("(?i)css\\s*=\\s*[\\\"']([^\\\"']+)[\\\"']|using\\s+css\\s+[\\\"']([^\\\"']+)[\\\"']");
    private static final Pattern QUOTED = Pattern.compile("[\\\"']([^\\\"']+)[\\\"']");

    private final LlmClient llmClient;
    private final ReportService reportService;
    private final RunStore runStore;
    private final ObjectMapper mapper = new ObjectMapper();
    private final Path outputRoot;
    private final int requestTimeoutSeconds;

    public PlaywrightMcpExecutionEngine(LlmClient llmClient,
                                        ReportService reportService,
                                        RunStore runStore,
                                        @Value("${runner.output-dir:target/itps-playwright-runs}") String outputDir,
                                        @Value("${itps.playwright.mcp.request-timeout-seconds:90}") int requestTimeoutSeconds) {
        this.llmClient = llmClient;
        this.reportService = reportService;
        this.runStore = runStore;
        this.outputRoot = Path.of(outputDir);
        this.requestTimeoutSeconds = requestTimeoutSeconds;
    }

    @Override public String name() { return "PLAYWRIGHT_MCP"; }

    @Override
    public void execute(List<TestScenario> scenarios, RunConfig config, RunStatus status) {
        status.setStatus("RUNNING");
        status.setStartedAt(Instant.now());
        Path runDir = outputRoot.resolve(config.getRunId());
        Path screenshotDir = runDir.resolve("screenshots");
        McpClient mcp = null;
        try {
            Files.createDirectories(screenshotDir);
            List<String> args = buildArgs(config, runDir);
            mcp = new McpClient(config.getMcpCommand(), args, Duration.ofSeconds(requestTimeoutSeconds), false);
            mcp.start();
            List<McpTool> tools = mcp.initializeAndListTools();
            PlaywrightToolAdapter adapter = new PlaywrightToolAdapter(tools);
            Set<String> toolNames = adapter.names();
            requireTools(toolNames, "browser_navigate", "browser_snapshot", "browser_click", "browser_type", "browser_wait_for");
            mapper.writerWithDefaultPrettyPrinter().writeValue(runDir.resolve("mcp-tools.json").toFile(), tools);

            List<ScenarioResult> results = new ArrayList<>();
            for (TestScenario scenario : scenarios) results.add(executeScenario(mcp, adapter, scenario, config, screenshotDir));
            completeStatus(status, results);
        } catch (Exception e) {
            status.setStatus("FAILED");
            status.setMessage("Playwright MCP execution failed: " + rootMessage(e));
        } finally {
            if (mcp != null) {
                mcp.writeDiagnostics(runDir);
                try { mcp.callTool("browser_close", Map.of()); } catch (Exception ignored) { }
                try { mcp.close(); } catch (Exception ignored) { }
            }
            status.setFinishedAt(Instant.now());
            runStore.put(status);
            try { reportService.writeReports(status, runDir); }
            catch (Exception reportError) {
                status.setMessage(join(status.getMessage(), "Report generation failed: " + reportError.getMessage()));
                try { reportService.writeFallbackHtml(status, runDir, reportError); } catch (Exception ignored) { }
            }
        }
    }

    private List<String> buildArgs(RunConfig config, Path runDir) {
        List<String> args = new ArrayList<>(splitArgs(config.getMcpArgs()));
        // Keep the proven Playwright MCP startup mode. Removing --isolated caused
        // the server to stall before replying to the initialize request on Windows.
        addIfMissing(args, "--isolated");
        addOptionIfMissing(args, "--output-dir", runDir.toAbsolutePath().toString());
        addOptionIfMissing(args, "--timeout-action", String.valueOf(config.getStepTimeoutSeconds() * 1000));
        addOptionIfMissing(args, "--timeout-navigation", String.valueOf(Math.max(60000, config.getStepTimeoutSeconds() * 3000)));
        if (config.isHeadless()) addIfMissing(args, "--headless");
        String browser = browserChannel(config);
        if (!browser.isBlank()) addOptionIfMissing(args, "--browser", browser);
        return args;
    }

    private String browserChannel(RunConfig config) {
        String id = Optional.ofNullable(config.getBrowserId()).orElse("").toLowerCase(Locale.ROOT);
        String name = Optional.ofNullable(config.getBrowserName()).orElse("").toLowerCase(Locale.ROOT);
        if (id.contains("edge") || name.contains("edge")) return "msedge";
        if (id.contains("firefox") || name.contains("firefox")) return "firefox";
        if (id.contains("webkit") || name.contains("webkit")) return "webkit";
        return "chrome";
    }

    private ScenarioResult executeScenario(McpClient mcp, PlaywrightToolAdapter adapter, TestScenario scenario,
                                           RunConfig config, Path screenshotDir) {
        long started = System.currentTimeMillis();
        ScenarioResult result = new ScenarioResult();
        result.setId(scenario.getId());
        result.setName(scenario.getName());
        result.setUrl(resolveUrl(scenario.getUrl(), config.getAppBaseUrl()));
        result.setStatus("RUNNING");

        List<String> steps = new ArrayList<>();
        if (!blank(result.getUrl())) steps.add("Navigate to " + result.getUrl());
        if (scenario.getSteps() != null) steps.addAll(scenario.getSteps());
        if (!blank(scenario.getExpected())) steps.add("Verify \"" + substitute(scenario.getExpected(), scenario.getData()) + "\" is displayed");

        boolean failed = false;
        int stepNo = 1;
        for (String raw : steps) {
            StepResult step = executeStep(mcp, adapter, substitute(raw, scenario.getData()), scenario.getId(), stepNo, config, screenshotDir);
            result.getSteps().add(step);
            if (!String.valueOf(step.getStatus()).startsWith("PASSED")) {
                failed = true;
                result.setErrorMessage(step.getErrorMessage());
                if (!config.isContinueOnFailure()) break;
            }
            stepNo++;
        }
        boolean healed = result.getSteps().stream().anyMatch(StepResult::isHealed);
        result.setStatus(failed ? "FAILED" : (healed ? "PASSED_HEALED" : "PASSED"));
        result.setDurationMs(System.currentTimeMillis() - started);
        return result;
    }

    private StepResult executeStep(McpClient mcp, PlaywrightToolAdapter adapter, String instruction, String scenarioId,
                                   int stepNo, RunConfig config, Path screenshotDir) {
        long started = System.currentTimeMillis();
        StepResult out = new StepResult();
        out.setStepNo(stepNo);
        out.setInstruction(instruction);
        out.setPlanSource("PLAYWRIGHT_MCP_DETERMINISTIC");
        Exception last = null;
        int attempts = Math.max(1, config.getRetryCount() + 1);

        for (int attempt = 1; attempt <= attempts; attempt++) {
            try {
                ToolCall call;
                if (shouldUseSnapshotLlm(instruction, config, adapter)) {
                    try {
                        call = snapshotLlmCall(mcp, adapter, instruction, config);
                        out.setPlanSource("PLAYWRIGHT_MCP_LLM_SNAPSHOT_PRIMARY");
                    } catch (Exception planningError) {
                        // Keep execution resilient: the reference application uses LLM + snapshot
                        // as the primary path, while deterministic execution remains a safe fallback.
                        call = deterministicCall(mcp, instruction, adapter);
                        out.setPlanSource("PLAYWRIGHT_MCP_DETERMINISTIC_FALLBACK");
                    }
                } else if (shouldUseDomPlanner(instruction, config, adapter)) {
                    call = domPlannedCall(mcp, adapter, instruction, config);
                    out.setPlanSource("PLAYWRIGHT_MCP_EXACT_DOM_PRIMARY");
                } else {
                    call = deterministicCall(mcp, instruction, adapter);
                }
                JsonNode response = mcp.callTool(call.tool(), call.arguments());
                assertToolSuccess(call.tool(), response);
                populate(out, call, response);
                out.setStatus("PASSED");
                last = null;
                break;
            } catch (Exception e) {
                last = e;
                if (attempt < attempts) {
                    try { mcp.callTool("browser_wait_for", adapter.waitSeconds(config.getRetryDelayMs() / 1000.0)); }
                    catch (Exception ignored) { }
                }
            }
        }

        if (last != null && !isExactSemanticInstruction(instruction) && config.isEnableSelfHealing() && config.isUseLlm() && llmClient.isConfigured(config)) {
            try {
                JsonNode snapshot = mcp.callTool("browser_snapshot", Map.of());
                String plan = llmClient.healPlaywrightMcpCall(
                        "Instruction: " + instruction + "\nFailure: " + rootMessage(last) +
                                "\nAvailable tools: " + String.join(",", adapter.names()) +
                                "\nCurrent accessibility snapshot/tool result: " + compact(snapshot.toString(), 18000), config);
                JsonNode root = mapper.readTree(plan);
                double confidence = root.path("confidence").asDouble(0.0);
                if (confidence < config.getHealingConfidenceThreshold())
                    throw new IllegalStateException("Healing confidence " + confidence + " is below threshold " + config.getHealingConfidenceThreshold());
                JsonNode calls = root.path("calls");
                if (!calls.isArray() || calls.isEmpty()) throw new IllegalStateException("LLM returned no Playwright MCP healing calls");
                List<String> history = new ArrayList<>();
                for (JsonNode callNode : calls) {
                    String tool = callNode.path("tool").asText();
                    if (!adapter.names().contains(tool)) throw new IllegalStateException("LLM selected unavailable Playwright MCP tool: " + tool);
                    Map<String,Object> rawArgs = mapper.convertValue(callNode.path("arguments"), Map.class);
                    Map<String,Object> args = normalizeHealingArguments(mcp, adapter, tool, rawArgs);
                    JsonNode response = mcp.callTool(tool, args);
                    assertToolSuccess(tool, response);
                    history.add(tool + " " + compact(args.toString(), 600));
                    out.setToolName(tool);
                    out.setToolArguments(args.toString());
                    out.setMcpResult(compact(response.toString(), 4000));
                }
                out.setHealed(true);
                out.setHealingAttempts(1);
                out.setHealingHistory(String.join("\n", history));
                out.setPlanSource("PLAYWRIGHT_MCP_LLM_HEALING");
                out.setStatus("PASSED_HEALED");
                out.setEvidence("Recovered using fresh Playwright accessibility snapshot and MCP tool retry.");
                last = null;
            } catch (Exception healError) {
                last = new IllegalStateException(rootMessage(last) + " | Playwright MCP healing failed: " + rootMessage(healError), healError);
            }
        }

        if (last != null) {
            out.setStatus("FAILED");
            out.setErrorMessage(rootMessage(last));
            try {
                JsonNode snapshot = mcp.callTool("browser_snapshot", Map.of());
                out.setPageInventory(compact(snapshot.toString(), 10000));
            } catch (Exception ignored) { }
        }
        if (shouldScreenshot(config, out)) {
            captureScreenshot(mcp, adapter, out, scenarioId, stepNo, screenshotDir);
        }
        out.setDurationMs(System.currentTimeMillis() - started);
        return out;
    }


    private void captureScreenshot(McpClient mcp, PlaywrightToolAdapter adapter, StepResult out,
                                   String scenarioId, int stepNo, Path screenshotDir) {
        String basename = safeName(scenarioId) + "-step-" + stepNo + ".png";
        Path expected = screenshotDir.resolve(basename).toAbsolutePath().normalize();
        List<String> failures = new ArrayList<>();
        try { Files.createDirectories(screenshotDir); } catch (Exception e) { failures.add("create screenshot directory: " + rootMessage(e)); }

        // The active Playwright page writes directly to the report folder. This avoids
        // screenshot-tool schema differences such as mandatory scale/filename fields.
        if (adapter.has("browser_run_code")) {
            try {
                String path = expected.toString().replace("\\", "/");
                String code = "async (page) => { await page.screenshot({path:" + jsString(path) + ", fullPage:true, animations:'disabled'}); return {saved:true,path:" + jsString(path) + "}; }";
                JsonNode response = mcp.callTool("browser_run_code", adapter.runCode(code));
                assertToolSuccess("browser_run_code screenshot", response);
            } catch (Exception e) {
                failures.add("browser_run_code screenshot: " + rootMessage(e));
            }
        }

        if (!Files.isRegularFile(expected) && adapter.has("browser_take_screenshot")) {
            try {
                JsonNode response = mcp.callTool("browser_take_screenshot", adapter.screenshot(basename));
                assertToolSuccess("browser_take_screenshot", response);
                writeEmbeddedScreenshot(response, expected);
                locateAndCopyScreenshot(screenshotDir.getParent(), basename, expected);
            } catch (Exception e) {
                failures.add("browser_take_screenshot: " + rootMessage(e));
            }
        }

        if (Files.isRegularFile(expected) && fileLooksLikePng(expected)) {
            out.setScreenshot(basename);
            out.setEvidence(join(nullSafe(out.getEvidence()), "Screenshot: screenshots/" + basename));
        } else {
            try { Files.deleteIfExists(expected); } catch (Exception ignored) { }
            String note = "Screenshot capture failed" + (failures.isEmpty() ? "" : ": " + String.join(" | ", failures));
            out.setEvidence(join(out.getEvidence(), note));
            if (!String.valueOf(out.getStatus()).startsWith("PASSED")) out.setErrorMessage(join(out.getErrorMessage(), note));
        }
    }

    private boolean fileLooksLikePng(Path file) {
        try {
            if (!Files.isRegularFile(file) || Files.size(file) < 100) return false;
            byte[] h = Files.readAllBytes(file);
            return h.length > 8 && (h[0] & 0xff) == 0x89 && h[1] == 0x50 && h[2] == 0x4e && h[3] == 0x47;
        } catch (Exception e) { return false; }
    }

    private void locateAndCopyScreenshot(Path runDir, String basename, Path expected) {
        if (Files.isRegularFile(expected) || runDir == null || !Files.isDirectory(runDir)) return;
        try (java.util.stream.Stream<Path> paths = Files.walk(runDir, 4)) {
            Optional<Path> found = paths
                    .filter(Files::isRegularFile)
                    .filter(p -> p.getFileName().toString().equalsIgnoreCase(basename))
                    .filter(p -> !p.toAbsolutePath().normalize().equals(expected))
                    .findFirst();
            if (found.isPresent()) Files.copy(found.get(), expected, StandardCopyOption.REPLACE_EXISTING);
        } catch (Exception ignored) { }
    }

    private void writeEmbeddedScreenshot(JsonNode node, Path destination) throws Exception {
        String base64 = findImageBase64(node);
        if (blank(base64)) return;
        int comma = base64.indexOf(',');
        if (comma >= 0 && base64.substring(0, comma).toLowerCase(Locale.ROOT).contains("base64")) base64 = base64.substring(comma + 1);
        byte[] bytes = Base64.getDecoder().decode(base64.replaceAll("\\s+", ""));
        if (bytes.length > 8) Files.write(destination, bytes, StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
    }

    private String findImageBase64(JsonNode node) {
        if (node == null || node.isNull() || node.isMissingNode()) return "";
        if (node.isObject()) {
            String type = node.path("type").asText("");
            String mime = firstNonBlank(node.path("mimeType").asText(""), node.path("mime_type").asText(""));
            if ("image".equalsIgnoreCase(type) || mime.toLowerCase(Locale.ROOT).startsWith("image/")) {
                String data = firstNonBlank(node.path("data").asText(""), node.path("base64").asText(""), node.path("content").asText(""));
                if (!blank(data)) return data;
            }
            Iterator<Map.Entry<String,JsonNode>> fields = node.fields();
            while (fields.hasNext()) {
                String found = findImageBase64(fields.next().getValue());
                if (!blank(found)) return found;
            }
        } else if (node.isArray()) {
            for (JsonNode child : node) {
                String found = findImageBase64(child);
                if (!blank(found)) return found;
            }
        } else if (node.isTextual()) {
            String value = node.asText();
            if (value.startsWith("data:image/") && value.contains("base64,")) return value;
        }
        return "";
    }

    private Map<String,Object> normalizeHealingArguments(McpClient mcp, PlaywrightToolAdapter adapter,
                                                         String tool, Map<String,Object> rawArgs) throws Exception {
        Map<String,Object> args = rawArgs == null ? new LinkedHashMap<>() : new LinkedHashMap<>(rawArgs);
        if ("browser_fill_form".equals(tool)) {
            Object fields = args.get("fields");
            if (!(fields instanceof List<?> list) || list.isEmpty()) {
                String label = firstNonBlank(String.valueOf(args.getOrDefault("element", "")), String.valueOf(args.getOrDefault("name", "input field")));
                String value = firstNonBlank(String.valueOf(args.getOrDefault("text", "")), String.valueOf(args.getOrDefault("value", "")));
                String ref = resolveRef(mcp, label, "textbox", "combobox");
                return adapter.type(label, ref, value);
            }
        }
        if (adapter.usesRef(tool)) {
            String existingRef = String.valueOf(args.getOrDefault("ref", ""));
            String label = firstNonBlank(String.valueOf(args.getOrDefault("element", "")),
                    String.valueOf(args.getOrDefault("target", "")),
                    String.valueOf(args.getOrDefault("name", "")),
                    String.valueOf(args.getOrDefault("selector", "")));
            if (!PlaywrightToolAdapter.isSnapshotRef(existingRef)) {
                args.put("ref", resolveRef(mcp, label, "button", "link", "textbox", "combobox", "option", "menuitem", "row", "generic"));
            }
            if (adapter.supportsProperty(tool, "target")) args.put("target", blank(label) ? "target element" : label);
            if (adapter.supportsProperty(tool, "element")) args.put("element", blank(label) ? "target element" : label);
            args.remove("selector");
            args.remove("locator");
        }
        return adapter.normalizeGenerated(tool, args);
    }


    private boolean isExactSemanticInstruction(String instruction) {
        if (instruction == null || !explicitTarget(instruction).isBlank()) return false;
        String lower = instruction.trim().toLowerCase(Locale.ROOT);
        boolean action = lower.startsWith("click ") || lower.startsWith("click on ") || lower.startsWith("double-click") ||
                lower.startsWith("double click") || lower.startsWith("hover ") || lower.startsWith("type ") ||
                lower.startsWith("fill ") || lower.startsWith("enter ") || lower.startsWith("set ") ||
                lower.startsWith("select ") || lower.startsWith("choose ") || lower.startsWith("check ") ||
                lower.startsWith("uncheck ") || lower.startsWith("press ");
        return action && !PlaywrightSemanticAction.parse(instruction).target().isBlank();
    }
    private boolean shouldUseSnapshotLlm(String instruction, RunConfig config, PlaywrightToolAdapter adapter) {
        if (!config.isUseLlm() || !llmClient.isConfigured(config) || !adapter.has("browser_snapshot")) return false;
        if (!blank(explicitTarget(instruction))) return false; // explicit XPath/CSS remains exact and deterministic
        String lower = instruction == null ? "" : instruction.trim().toLowerCase(Locale.ROOT);
        if (lower.startsWith("navigate to ") || lower.startsWith("open ") || lower.startsWith("go to ")) return false;
        if (lower.startsWith("verify ") || lower.startsWith("assert ") || lower.startsWith("validate ") || lower.startsWith("wait for ")) return false;
        return lower.startsWith("click ") || lower.startsWith("click on ") || lower.startsWith("double-click") ||
                lower.startsWith("double click") || lower.startsWith("hover ") || lower.startsWith("type ") ||
                lower.startsWith("fill ") || lower.startsWith("enter ") || lower.startsWith("set ") ||
                lower.startsWith("select ") || lower.startsWith("choose ") || lower.startsWith("press ");
    }

    private ToolCall snapshotLlmCall(McpClient mcp, PlaywrightToolAdapter adapter, String instruction, RunConfig config) throws Exception {
        JsonNode snapshot = mcp.callTool("browser_snapshot", Map.of());
        assertToolSuccess("browser_snapshot", snapshot);
        String prompt = "Instruction:\n" + instruction +
                "\nAvailable Playwright MCP tools:\n" + String.join(",", adapter.names()) +
                "\nCurrent browser snapshot:\n" + compact(snapshot.toString(), 24000) +
                "\nReturn one next action only.";
        String decision = llmClient.planPlaywrightSnapshotAction(prompt, config);
        JsonNode root = mapper.readTree(decision);
        if (root.path("done").asBoolean(false)) {
            return new ToolCall("browser_wait_for", adapter.waitSeconds(0.1));
        }
        double confidence = root.path("confidence").asDouble(0.0);
        if (confidence < config.getHealingConfidenceThreshold()) {
            throw new IllegalStateException("LLM snapshot confidence " + confidence + " is below threshold " + config.getHealingConfidenceThreshold());
        }
        String tool = root.path("toolName").asText("").trim();
        if (tool.isBlank() || !adapter.names().contains(tool)) {
            throw new IllegalStateException("LLM selected unavailable Playwright MCP tool: " + tool);
        }
        Map<String,Object> rawArgs = mapper.convertValue(root.path("arguments"), Map.class);
        Map<String,Object> args = normalizeHealingArguments(mcp, adapter, tool, rawArgs);
        return new ToolCall(tool, args);
    }

    private boolean shouldUseDomPlanner(String instruction, RunConfig config, PlaywrightToolAdapter adapter) {
        if (!config.isUseLlm() || !llmClient.isConfigured(config) || !adapter.has("browser_run_code")) return false;
        if (!blank(explicitTarget(instruction))) return false;
        String lower = instruction.trim().toLowerCase(Locale.ROOT);
        return lower.startsWith("click ") || lower.startsWith("click on ") || lower.startsWith("double-click") ||
                lower.startsWith("double click") || lower.startsWith("hover ") || lower.startsWith("type ") ||
                lower.startsWith("fill ") || lower.startsWith("enter ") || lower.startsWith("set ") || lower.startsWith("select ");
    }

    private ToolCall domPlannedCall(McpClient mcp, PlaywrightToolAdapter adapter, String instruction, RunConfig config) throws Exception {
        PlaywrightSemanticAction.Spec spec = PlaywrightSemanticAction.parse(instruction);
        if (blank(spec.target())) throw new IllegalArgumentException("Unable to determine exact target from step: " + instruction);
        String code = PlaywrightSemanticAction.buildScript(spec);
        return new ToolCall("browser_run_code", adapter.runCode(code));
    }

    private String domInventoryCode() {
        return "async (page) => {" +
                "const esc=s=>String(s||'').replace(/\\s+/g,' ').trim();" +
                "const cssPath=(el)=>{if(el.id)return '#'+CSS.escape(el.id);const parts=[];let n=el;while(n&&n.nodeType===1&&n!==document.body){let p=n.tagName.toLowerCase();if(n.getAttribute('data-testid')){p+='[data-testid=\\\"'+CSS.escape(n.getAttribute('data-testid'))+'\\\"]';parts.unshift(p);break;}if(n.getAttribute('aria-label'))p+='[aria-label=\\\"'+CSS.escape(n.getAttribute('aria-label'))+'\\\"]';else if(n.getAttribute('name'))p+='[name=\\\"'+CSS.escape(n.getAttribute('name'))+'\\\"]';else{let i=1,x=n;while((x=x.previousElementSibling))if(x.tagName===n.tagName)i++;p+=':nth-of-type('+i+')';}parts.unshift(p);n=n.parentElement;}return parts.join(' > ');};" +
                "const roleOf=e=>e.getAttribute('role')||({BUTTON:'button',A:'link',INPUT:(e.type==='checkbox'?'checkbox':e.type==='radio'?'radio':'textbox'),SELECT:'combobox',TEXTAREA:'textbox',OPTION:'option'}[e.tagName]||'generic');" +
                "const nodes=[...document.querySelectorAll('button,a,input,textarea,select,option,[role],[tabindex],[contenteditable=true],[aria-label],[data-testid]')];" +
                "const items=[];for(const e of nodes){const st=getComputedStyle(e),r=e.getBoundingClientRect();if(st.visibility==='hidden'||st.display==='none'||r.width<1||r.height<1)continue;" +
                "const name=esc(e.getAttribute('aria-label')||e.getAttribute('title')||e.innerText||e.value||e.getAttribute('placeholder')||e.getAttribute('name'));" +
                "const text=esc(e.innerText||e.textContent);const context=esc(e.parentElement?.innerText).slice(0,300);const selector=cssPath(e);if(!selector)continue;" +
                "items.push({candidateId:'c'+(items.length+1),selector,tag:e.tagName.toLowerCase(),role:roleOf(e),accessibleName:name,text:text.slice(0,250),context,enabled:!e.disabled,selected:e.getAttribute('aria-selected'),checked:e.checked===true,value:e.value||'',placeholder:e.getAttribute('placeholder')||'',testId:e.getAttribute('data-testid')||''});if(items.length>=500)break;}" +
                "return {url:page.url(),title:await page.title(),candidates:items};}";
    }

    private String exactCandidateActionCode(String candidateId, String action, String value, String instruction) {
        return "async (page) => { const wanted=" + jsString(candidateId) + "; const requested=" + jsString(instruction) + ";" +
                "const esc=s=>String(s||'').replace(/\\s+/g,' ').trim();" +
                "const cssPath=(el)=>{if(el.id)return '#'+CSS.escape(el.id);const parts=[];let n=el;while(n&&n.nodeType===1&&n!==document.body){let p=n.tagName.toLowerCase();if(n.getAttribute('data-testid')){p+='[data-testid=\\\"'+CSS.escape(n.getAttribute('data-testid'))+'\\\"]';parts.unshift(p);break;}if(n.getAttribute('aria-label'))p+='[aria-label=\\\"'+CSS.escape(n.getAttribute('aria-label'))+'\\\"]';else if(n.getAttribute('name'))p+='[name=\\\"'+CSS.escape(n.getAttribute('name'))+'\\\"]';else{let i=1,x=n;while((x=x.previousElementSibling))if(x.tagName===n.tagName)i++;p+=':nth-of-type('+i+')';}parts.unshift(p);n=n.parentElement;}return parts.join(' > ');};" +
                "const nodes=[...document.querySelectorAll('button,a,input,textarea,select,option,[role],[tabindex],[contenteditable=true],[aria-label],[data-testid]')].filter(e=>{const s=getComputedStyle(e),r=e.getBoundingClientRect();return s.visibility!=='hidden'&&s.display!=='none'&&r.width>0&&r.height>0;});" +
                "const mapped=nodes.map((e,i)=>({id:'c'+(i+1),e,selector:cssPath(e)}));const hit=mapped.find(x=>x.id===wanted);if(!hit)throw new Error('Candidate '+wanted+' is not present in fresh DOM for '+requested);" +
                "const loc=page.locator(hit.selector);const count=await loc.count();if(count!==1)throw new Error('Candidate selector is not unique: '+hit.selector+' count='+count);const el=loc.first();if(!await el.isVisible())throw new Error('Candidate is not visible: '+hit.selector);if(!await el.isEnabled().catch(()=>true))throw new Error('Candidate is disabled: '+hit.selector);" +
                ("fill".equals(action) || "type".equals(action) || "set".equals(action) ?
                "await el.fill(" + jsString(value) + ");const actual=await el.inputValue().catch(()=>null);if(actual!==null&&actual!==" + jsString(value) + ")throw new Error('Post-fill verification failed: '+actual);" :
                "select".equals(action) ?
                "if((await el.evaluate(e=>e.tagName))==='SELECT'){await el.selectOption({label:" + jsString(value) + "});}else{await el.click();}" :
                "hover".equals(action) ? "await el.hover();" :
                "press".equals(action) ? "await el.press(" + jsString(value) + ");" :
                "await el.click();") +
                "return {candidateId:wanted,selector:hit.selector,action:" + jsString(action) + ",requested}; }";
    }

    private ToolCall deterministicCall(McpClient mcp, String instruction, PlaywrightToolAdapter adapter) throws Exception {
        String text = instruction.trim();
        String lower = text.toLowerCase(Locale.ROOT);
        List<String> q = quotedValues(text);
        String target = explicitTarget(text);

        if (lower.startsWith("navigate to ") || lower.startsWith("open ") || lower.startsWith("go to ")) {
            String url = text.replaceFirst("(?i)^(navigate to|open|go to)\\s+", "").trim();
            return new ToolCall("browser_navigate", adapter.navigate(stripQuotes(url)));
        }
        if (lower.startsWith("wait for ")) {
            String expected = q.isEmpty() ? text.replaceFirst("(?i)^wait for\\s+", "").replaceFirst("(?i)\\s+to be visible.*$", "").trim() : q.get(0);
            return new ToolCall("browser_wait_for", adapter.waitForText(expected));
        }
        if (lower.startsWith("verify ") || lower.startsWith("assert ") || lower.startsWith("validate ")) {
            String expected = q.isEmpty() ? text.replaceFirst("(?i)^(verify|assert|validate)\\s+", "").replaceFirst("(?i)\\s+is displayed.*$", "").trim() : q.get(0);
            return new ToolCall("browser_wait_for", adapter.waitForText(expected));
        }

        // Exact CSS/XPath steps bypass accessibility ref ambiguity through Playwright code.
        if (!blank(target) && adapter.has("browser_run_code")) {
            return selectorCodeCall(text, lower, q, target, adapter);
        }

        if (adapter.has("browser_run_code") && (
                lower.startsWith("type ") || lower.startsWith("fill ") || lower.startsWith("enter ") || lower.startsWith("set ") ||
                lower.startsWith("select ") || lower.startsWith("choose ") || lower.startsWith("hover ") ||
                lower.startsWith("check ") || lower.startsWith("uncheck ") || lower.startsWith("press ") ||
                lower.startsWith("double-click") || lower.startsWith("double click") || lower.startsWith("click ") || lower.startsWith("click on "))) {
            PlaywrightSemanticAction.Spec spec = PlaywrightSemanticAction.parse(instruction);
            if (blank(spec.target())) throw new IllegalArgumentException("Unable to determine exact target from step: " + instruction);
            return new ToolCall("browser_run_code", adapter.runCode(PlaywrightSemanticAction.buildScript(spec)));
        }

        if (lower.startsWith("type ") || lower.startsWith("fill ") || lower.startsWith("enter ") || lower.startsWith("set ")) {
            String value = q.isEmpty() ? semanticInputValue(text) : q.get(0);
            if (blank(value)) throw new IllegalArgumentException("Type step needs a quoted or resolvable value");
            String field = q.size() > 1 ? q.get(1) : inferFieldName(text, value);
            String ref = resolveRef(mcp, field, "textbox", "combobox");
            return new ToolCall("browser_type", adapter.type(field, ref, value));
        }
        if (lower.startsWith("select ")) {
            String value = q.isEmpty() ? semanticInputValue(text) : q.get(0);
            if (blank(value)) throw new IllegalArgumentException("Select step needs a quoted or resolvable option");
            String field = q.size() > 1 ? q.get(1) : inferFieldName(text, value);
            if (adapter.has("browser_select_option") && looksLikeNativeSelect(text)) {
                String ref = resolveRef(mcp, field, "combobox", "textbox", "button");
                return new ToolCall("browser_select_option", adapter.select(field, ref, value));
            }
            // Angular/autocomplete options are clicks, not native select elements.
            String optionRef = resolveRef(mcp, value, "option", "listitem", "button", "generic");
            return new ToolCall("browser_click", adapter.click(value, optionRef, false));
        }
        if (lower.startsWith("press ")) {
            String key = q.isEmpty() ? text.replaceFirst("(?i)^press\\s+", "").split("\\s+on\\s+")[0].trim() : q.get(0);
            return new ToolCall("browser_press_key", adapter.pressKey(key));
        }
        if (lower.startsWith("upload ")) {
            if (q.isEmpty()) throw new IllegalArgumentException("Upload step needs a quoted absolute file path");
            return new ToolCall("browser_file_upload", adapter.upload(q.get(0)));
        }
        if (lower.startsWith("hover ")) {
            String label = q.isEmpty() ? text.replaceFirst("(?i)^hover(?: over)?\\s+", "").trim() : q.get(0);
            String ref = resolveRef(mcp, label, "button", "link", "menuitem", "generic");
            return new ToolCall("browser_hover", adapter.hover(label, ref));
        }
        if (lower.startsWith("double-click") || lower.startsWith("double click") || lower.startsWith("click ") || lower.startsWith("click on ")) {
            String label = q.isEmpty() ? text.replaceFirst("(?i)^(double[- ]click|click)(?: on)?\\s+", "").trim() : q.get(0);
            String ref = resolveRef(mcp, label, "button", "link", "menuitem", "option", "row", "generic");
            return new ToolCall("browser_click", adapter.click(label, ref, lower.startsWith("double")));
        }
        throw new IllegalArgumentException("Unsupported Playwright MCP step: " + instruction);
    }

    private ToolCall semanticCodeCall(String instruction, PlaywrightToolAdapter adapter) {
        String text = instruction.trim();
        String lower = text.toLowerCase(Locale.ROOT);
        List<String> q = quotedValues(text);
        String code;

        if (lower.startsWith("click ") || lower.startsWith("click on ") || lower.startsWith("double-click") || lower.startsWith("double click") || lower.startsWith("hover ")) {
            String label = q.isEmpty() ? text.replaceFirst("(?i)^(double[- ]click|click)(?: on)?\\s+|^hover(?: over)?\\s+", "").trim() : q.get(0);
            String action = lower.startsWith("hover") ? "hover" : "click";
            int clickCount = lower.startsWith("double") ? 2 : 1;
            code = "async (page) => { const name=" + jsString(label) + "; const candidates=[" +
                    "page.getByRole('button',{name,exact:true}),page.getByRole('link',{name,exact:true})," +
                    "page.getByRole('menuitem',{name,exact:true}),page.getByRole('option',{name,exact:true})," +
                    "page.getByText(name,{exact:true})];" +
                    "for(const c of candidates){const n=await c.count();for(let i=0;i<n;i++){const e=c.nth(i);if(await e.isVisible().catch(()=>false)){" +
                    ("hover".equals(action) ? "await e.hover();" : "await e.click({clickCount:" + clickCount + "});") +
                    "return '" + action + "ed '+name;}}} throw new Error('Visible element not found: '+name); }";
            return new ToolCall("browser_run_code", adapter.runCode(code));
        }

        if (lower.startsWith("type ") || lower.startsWith("fill ") || lower.startsWith("enter ") || lower.startsWith("set ")) {
            String value = q.isEmpty() ? semanticInputValue(text) : q.get(0);
            String field = q.size() > 1 ? q.get(1) : inferFieldName(text, value);
            code = "async (page) => { const name=" + jsString(field) + "; const value=" + jsString(value) + "; const candidates=[" +
                    "page.getByLabel(name,{exact:false}),page.getByPlaceholder(name,{exact:false})," +
                    "page.getByRole('textbox',{name,exact:false}),page.getByRole('combobox',{name,exact:false})];" +
                    "for(const c of candidates){const n=await c.count();for(let i=0;i<n;i++){const e=c.nth(i);if(await e.isVisible().catch(()=>false)){await e.fill(value);return 'filled '+name;}}}" +
                    "const focused=page.locator('input:focus,textarea:focus,[contenteditable=true]:focus').first();if(await focused.count()){await focused.fill(value);return 'filled focused input';}" +
                    "throw new Error('Visible input not found: '+name); }";
            return new ToolCall("browser_run_code", adapter.runCode(code));
        }

        if (lower.startsWith("select ")) {
            String value = q.isEmpty() ? semanticInputValue(text) : q.get(0);
            code = "async (page) => { const value=" + jsString(value) + "; const candidates=[page.getByRole('option',{name:value,exact:true}),page.getByText(value,{exact:true})];" +
                    "for(const c of candidates){const n=await c.count();for(let i=0;i<n;i++){const e=c.nth(i);if(await e.isVisible().catch(()=>false)){await e.click();return 'selected '+value;}}}" +
                    "throw new Error('Visible option not found: '+value); }";
            return new ToolCall("browser_run_code", adapter.runCode(code));
        }

        throw new IllegalArgumentException("No deterministic Playwright fallback for: " + instruction);
    }

    private ToolCall selectorCodeCall(String text, String lower, List<String> q, String target, PlaywrightToolAdapter adapter) {
        String selector = target.startsWith("xpath=") ? target.substring(6) : target;
        String locator = target.startsWith("xpath=") ? "page.locator('xpath=' + " + jsString(selector) + ")" : "page.locator(" + jsString(selector) + ")";
        String action;
        if (lower.startsWith("type ") || lower.startsWith("fill ") || lower.startsWith("enter ") || lower.startsWith("set ")) {
            if (q.isEmpty()) throw new IllegalArgumentException("Type step needs a quoted value");
            action = "const el=" + locator + ".first(); await el.waitFor({state:'visible'}); await el.fill(" + jsString(q.get(0)) + "); return 'filled';";
        } else if (lower.startsWith("hover ")) {
            action = "const el=" + locator + ".first(); await el.waitFor({state:'visible'}); await el.hover(); return 'hovered';";
        } else if (lower.startsWith("select ") && looksLikeNativeSelect(text)) {
            if (q.isEmpty()) throw new IllegalArgumentException("Select step needs a quoted option");
            action = "const el=" + locator + ".first(); await el.waitFor({state:'visible'}); await el.selectOption({label:" + jsString(q.get(0)) + "}); return 'selected';";
        } else {
            action = "const el=" + locator + ".first(); await el.waitFor({state:'visible'}); await el.click(); return 'clicked';";
        }
        return new ToolCall("browser_run_code", adapter.runCode("async (page) => { " + action + " }"));
    }

    private String resolveRef(McpClient mcp, String label, String... preferredRoles) throws Exception {
        JsonNode snapshot = mcp.callTool("browser_snapshot", Map.of());
        assertToolSuccess("browser_snapshot", snapshot);
        String text = snapshotText(snapshot);
        String wanted = normalizeWords(label);
        List<String> lines = Arrays.asList(text.split("\\R"));
        Pattern refPattern = Pattern.compile("(?:\\[ref=|\\bref[=:]\\s*)([A-Za-z0-9_-]+)\\]?", Pattern.CASE_INSENSITIVE);
        String bestRef = null;
        int bestScore = Integer.MIN_VALUE;

        for (int i = 0; i < lines.size(); i++) {
            Matcher matcher = refPattern.matcher(lines.get(i));
            while (matcher.find()) {
                String ref = matcher.group(1);
                if (!PlaywrightToolAdapter.isSnapshotRef(ref)) continue;
                StringBuilder context = new StringBuilder();
                for (int j = Math.max(0, i - 2); j <= Math.min(lines.size() - 1, i + 2); j++) context.append(' ').append(lines.get(j));
                String norm = normalizeWords(context.toString());
                int score = 0;
                if (!wanted.isBlank() && norm.contains(wanted)) score += 160;
                for (String token : wanted.split(" ")) if (token.length() > 1 && norm.contains(token)) score += 12;
                for (int r = 0; r < preferredRoles.length; r++) {
                    String role = preferredRoles[r].toLowerCase(Locale.ROOT);
                    if (norm.matches(".*\\b" + Pattern.quote(role) + "\\b.*")) score += 40 - Math.min(r, 20);
                }
                if (norm.contains("hidden") || norm.contains("disabled")) score -= 100;
                if (score > bestScore) { bestScore = score; bestRef = ref; }
            }
        }
        if (bestRef == null || bestScore < 20) {
            throw new IllegalStateException("Unable to resolve a current Playwright snapshot ref for '" + label + "'. Snapshot: " + compact(text, 3500));
        }
        return bestRef;
    }

    private String snapshotText(JsonNode node) {
        StringBuilder out = new StringBuilder();
        collectText(node, out);
        return out.toString();
    }

    private void collectText(JsonNode node, StringBuilder out) {
        if (node == null || node.isNull() || node.isMissingNode()) return;
        if (node.isTextual()) { out.append(node.asText()).append('\n'); return; }
        if (node.isArray()) { for (JsonNode child : node) collectText(child, out); return; }
        if (node.isObject()) node.fields().forEachRemaining(e -> collectText(e.getValue(), out));
    }

    private String semanticInputValue(String text) {
        String lower = text.toLowerCase(Locale.ROOT);
        java.time.LocalDate now = java.time.LocalDate.now();
        if (lower.contains("1st of current month") || lower.contains("first of current month")) {
            return now.withDayOfMonth(1).format(java.time.format.DateTimeFormatter.ofPattern("dd/MM/yyyy"));
        }
        Matcher time = Pattern.compile("(?i)(\\d{1,2})\\s*(AM|PM)").matcher(text);
        if (time.find()) return String.format("%02d:00 %s", Integer.parseInt(time.group(1)), time.group(2).toUpperCase(Locale.ROOT));
        return "";
    }

    private String inferFieldName(String text, String value) {
        String cleaned = text.replace(value, "").replaceAll("(?i)^(type|fill|enter|set|select)\\s+", "").replaceAll("(?i)\\s+(as|to|in|into|using).*$", "").trim();
        if (cleaned.toLowerCase(Locale.ROOT).contains("start date")) return "Start date";
        if (cleaned.toLowerCase(Locale.ROOT).contains("start time")) return "Start time";
        return cleaned.isBlank() ? "focused input" : cleaned;
    }

    private boolean looksLikeNativeSelect(String text) {
        String lower = text.toLowerCase(Locale.ROOT);
        return lower.contains("native select") || lower.contains("select option") || lower.contains("dropdown using select");
    }

    private String normalizeWords(String value) {
        return Optional.ofNullable(value).orElse("").toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]+", " ").trim();
    }

    private String jsString(String value) {
        String escaped = Optional.ofNullable(value).orElse("")
                .replace("\\", "\\\\")
                .replace("'", "\\'")
                .replace("\r", "\\r")
                .replace("\n", "\\n");
        return "'" + escaped + "'";
    }

    private String explicitTarget(String text) {
        Matcher x = XPATH.matcher(text);
        if (x.find()) return "xpath=" + firstNonBlank(x.group(1), x.group(2));
        Matcher c = CSS.matcher(text);
        if (c.find()) return firstNonBlank(c.group(1), c.group(2));
        return "";
    }

    private String selectorForText(String text) {
        String escaped = stripQuotes(text).replace("\\", "\\\\").replace("\"", "\\\"");
        return "text=\"" + escaped + "\"";
    }

    private void populate(StepResult out, ToolCall call, JsonNode response) {
        out.setToolName(call.tool());
        out.setToolArguments(call.arguments().toString());
        out.setActionJson("{\"tool\":\"" + call.tool() + "\",\"arguments\":" + call.arguments() + "}");
        out.setMcpResult(compact(response.toString(), 4000));
        out.setEvidence("Playwright MCP tool completed successfully.");
    }

    private void assertToolSuccess(String tool, JsonNode result) {
        if (result == null || result.isMissingNode()) throw new IllegalStateException(tool + " returned no result");
        if (result.path("isError").asBoolean(false)) throw new IllegalStateException(tool + " failed: " + compact(result.toString(), 3000));
    }

    private void requireTools(Set<String> tools, String... required) {
        for (String tool : required) if (!tools.contains(tool)) throw new IllegalStateException("Playwright MCP tool not available: " + tool);
    }

    private List<String> splitArgs(String raw) {
        if (blank(raw)) return new ArrayList<>();
        List<String> out = new ArrayList<>();
        Matcher m = Pattern.compile("\\\"([^\\\"]*)\\\"|'([^']*)'|(\\S+)").matcher(raw);
        while (m.find()) out.add(firstNonBlank(m.group(1), m.group(2), m.group(3)));
        return out;
    }
    private void addIfMissing(List<String> args, String flag) { if (!args.contains(flag)) args.add(flag); }
    private void addOptionIfMissing(List<String> args, String option, String value) {
        if (!args.contains(option)) { args.add(option); args.add(value); }
    }
    private List<String> quotedValues(String text) { List<String> out = new ArrayList<>(); Matcher m = QUOTED.matcher(text); while (m.find()) out.add(m.group(1)); return out; }
    private String substitute(String value, Map<String,Object> data) { String out = value == null ? "" : value; if (data != null) for (var e : data.entrySet()) out = out.replace("${" + e.getKey() + "}", String.valueOf(e.getValue())); return out; }
    private String resolveUrl(String url, String base) { return !blank(url) ? url.trim() : (blank(base) ? "" : base.trim()); }
    private void completeStatus(RunStatus status, List<ScenarioResult> results) { status.setScenarios(results); status.setTotal(results.size()); int p=(int)results.stream().filter(r->String.valueOf(r.getStatus()).startsWith("PASSED")).count(); status.setPassed(p); status.setFailed(results.size()-p); status.setStatus(status.getFailed()==0?"PASSED":"COMPLETED_WITH_FAILURES"); status.setMessage(""); }
    private boolean shouldScreenshot(RunConfig c, StepResult r) { String mode=Optional.ofNullable(c.getScreenshotMode()).orElse("ALL").toUpperCase(Locale.ROOT); return "ALL".equals(mode)||("FAILURE_ONLY".equals(mode)&&!String.valueOf(r.getStatus()).startsWith("PASSED")); }
    private String safeName(String s) { return Optional.ofNullable(s).orElse("test").replaceAll("[^A-Za-z0-9._-]", "_"); }
    private String stripQuotes(String s) { return s == null ? "" : s.trim().replaceAll("^[\\\"']|[\\\"']$", ""); }
    private String firstNonBlank(String... values) { for (String v: values) if (!blank(v)) return v; return ""; }
    private String rootMessage(Throwable e) { Throwable t=e; while(t.getCause()!=null)t=t.getCause(); return t.getMessage()==null?t.getClass().getSimpleName():t.getMessage(); }
    private String compact(String s,int max){ if(s==null)return""; String one=s.replaceAll("\\s+"," ").trim(); return one.length()<=max?one:one.substring(0,max)+"..."; }
    private String join(String a,String b){ return blank(a)?b:a+" | "+b; }
    private String nullSafe(String value){ return value==null?"":value; }
    private boolean blank(String s){ return s==null||s.trim().isEmpty(); }
    private record ToolCall(String tool, Map<String,Object> arguments) { }
}
