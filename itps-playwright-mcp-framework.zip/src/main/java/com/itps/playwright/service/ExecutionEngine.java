package com.itps.playwright.service;

import com.itps.playwright.model.RunConfig;
import com.itps.playwright.model.RunStatus;
import com.itps.playwright.model.TestScenario;
import java.util.List;

public interface ExecutionEngine {
    String name();
    void execute(List<TestScenario> scenarios, RunConfig config, RunStatus status);
}
