package com.itps.playwright.model;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class TestScenario {
    private String id;
    private String name;
    private String url;
    private List<String> steps = new ArrayList<>();
    private Map<String, Object> data = new LinkedHashMap<>();
    private String expected;

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getUrl() { return url; }
    public void setUrl(String url) { this.url = url; }
    public List<String> getSteps() { return steps; }
    public void setSteps(List<String> steps) { this.steps = steps; }
    public Map<String, Object> getData() { return data; }
    public void setData(Map<String, Object> data) { this.data = data; }
    public String getExpected() { return expected; }
    public void setExpected(String expected) { this.expected = expected; }
}
