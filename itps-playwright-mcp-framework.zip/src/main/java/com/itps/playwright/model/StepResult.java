package com.itps.playwright.model;

public class StepResult {
    private int stepNo;
    private String instruction;
    private String planSource;
    private String toolName;
    private String toolArguments;
    private String actionJson;
    private String mcpResult;
    private String evidence;
    private String pageInventory;
    private String status;
    private long durationMs;
    private String screenshot;
    private String errorMessage;
    private boolean healed;
    private int healingAttempts;
    private String healingHistory;

    public int getStepNo() { return stepNo; }
    public void setStepNo(int stepNo) { this.stepNo = stepNo; }
    public String getInstruction() { return instruction; }
    public void setInstruction(String instruction) { this.instruction = instruction; }
    public String getPlanSource() { return planSource; }
    public void setPlanSource(String planSource) { this.planSource = planSource; }
    public String getToolName() { return toolName; }
    public void setToolName(String toolName) { this.toolName = toolName; }
    public String getToolArguments() { return toolArguments; }
    public void setToolArguments(String toolArguments) { this.toolArguments = toolArguments; }
    public String getActionJson() { return actionJson; }
    public void setActionJson(String actionJson) { this.actionJson = actionJson; }
    public String getMcpResult() { return mcpResult; }
    public void setMcpResult(String mcpResult) { this.mcpResult = mcpResult; }
    public String getEvidence() { return evidence; }
    public void setEvidence(String evidence) { this.evidence = evidence; }
    public String getPageInventory() { return pageInventory; }
    public void setPageInventory(String pageInventory) { this.pageInventory = pageInventory; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public long getDurationMs() { return durationMs; }
    public void setDurationMs(long durationMs) { this.durationMs = durationMs; }
    public String getScreenshot() { return screenshot; }
    public void setScreenshot(String screenshot) { this.screenshot = screenshot; }
    public String getErrorMessage() { return errorMessage; }
    public void setErrorMessage(String errorMessage) { this.errorMessage = errorMessage; }
    public boolean isHealed() { return healed; }
    public void setHealed(boolean healed) { this.healed = healed; }
    public int getHealingAttempts() { return healingAttempts; }
    public void setHealingAttempts(int healingAttempts) { this.healingAttempts = healingAttempts; }
    public String getHealingHistory() { return healingHistory; }
    public void setHealingHistory(String healingHistory) { this.healingHistory = healingHistory; }
}
