package com.itps.playwright.model;

public record BrowserOption(String id, String name, String executable, boolean detected, boolean directlySupported, String note) {}
