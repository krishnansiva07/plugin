package com.itps.playwright;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ItpsPlaywrightApplication {
    public static void main(String[] args) {
        SpringApplication.run(ItpsPlaywrightApplication.class, args);
    }
}
