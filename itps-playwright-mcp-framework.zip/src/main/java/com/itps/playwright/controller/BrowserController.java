package com.itps.playwright.controller;

import com.itps.playwright.service.BrowserDiscoveryService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/browsers")
public class BrowserController {
    private final BrowserDiscoveryService service;
    public BrowserController(BrowserDiscoveryService service) { this.service = service; }
    @GetMapping public Object list() { return service.discover(); }
}
