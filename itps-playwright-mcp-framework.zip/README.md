# ITPS Playwright MCP Framework

Independent Playwright-only UI automation framework. Vibium and its execution classes have been removed.

## Prerequisites (Windows)
- JDK 17 or later (`java -version`)
- Maven 3.9+ (`mvn -version`)
- Node.js 20+ with npm/npx (`node -v`, `npx -v`)
- Chrome or Microsoft Edge
- Access to `@playwright/mcp` through network or npm cache

## Start
Run `start-framework.bat`, or:

```bat
mvn clean spring-boot:run
```

Open `http://localhost:8090`.

## Execution flow
1. Upload Excel/JSON and select worksheets.
2. UI always starts Playwright MCP; there is no engine dropdown.
3. Explicit XPath/CSS steps execute deterministically.
4. Plain-English actions use a fresh Playwright accessibility snapshot with exact-target planning.
5. LLM healing is used when enabled and normal execution fails.
6. Screenshots follow the UI mode: All, Failures only, or None.
7. Execution report, technical logs, Excel, JSON and screenshot ZIP are attached to each run.

## Important target-selection rule
For requests such as `Click NEW-IP`, exact visible/accessibility-name matching is preferred. Broad parent containers and unrelated values such as `Monext` are rejected. A fresh snapshot is used for dynamic menus.
