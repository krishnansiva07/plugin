# ASTRA Code Review Agent V5 - Clickable Tabs Working Build

Single Spring Boot app. UI is served from backend.

## Run
```bash
cd backend
mvn spring-boot:run
```
Open:
```text
http://localhost:8090/index.html
```

## LLM Configuration
Edit `backend/src/main/resources/application.properties`:
```properties
llm.mock-mode=false
llm.base-url=https://ai4devs.group.echonet/api/v1
llm.model-name=gpt-oss-120b
llm.api-key=YOUR_KEY_HERE
llm.append-chat-completions=true
```
Restart backend after editing.

## Fixed in V5
- Summary, Comments, Report tabs are clickable.
- Details, Issues, Chunks, PR Comment tabs are clickable.
- Download JSON report works from Report tab.
- Copy PR comments works.
- Fixed Java regex compile error in RuleAnalyzerService.
- Still supports file upload, folder upload, SSE progress, chunk review, rule checks and LLM review.


## V6 folder filtering fix

When Full Project Folder is selected, ASTRA now loads only supported code/config text files and skips generated/binary/non-code files.

Reviewed extensions: .java, .kt, .groovy, .js, .jsx, .ts, .tsx, .html, .css, .scss, .sass, .py, .cs, .feature, .xml, .gradle, .tf, .ps1, .sh, .bat, .sql, .yml, .yaml, .properties, plus Jenkinsfile, Dockerfile, Makefile, pom.xml, build.gradle and settings.gradle.

Skipped by design: .class, .json, .xls, .xlsx, images, PDFs, binaries, target, node_modules, .git, .idea, .vscode, build, dist, coverage, bin, obj and out.

This avoids folder-review failures caused by generated files, binary files or unsupported formats.
