'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const route = require('../../main/resources/static/unified-routing.js');
const java = fs.readFileSync('src/main/java/com/llmart/llm/service/TestCaseWorkbookService.java','utf8');
const oc = fs.readFileSync('src/main/java/com/llmart/llm/service/OpenCodeExecutionService.java','utf8');
const ui = fs.readFileSync('src/main/resources/static/app.js','utf8');
const html = fs.readFileSync('src/main/resources/static/index.html','utf8');
const css = fs.readFileSync('src/main/resources/static/app.css','utf8');
const doc = [{id:'doc',name:'UserGuide.docx'}];
test('Document-to-Excel request routes to artifact even with no workspace', () => {
  assert.equal(route.documentArtifactIntent('create test cases from attachments in Excel',doc),true);
  assert.equal(route.interpret({text:'create testcases for these documents in excel format',attachments:doc}).intent,'document-artifact');
  assert.equal(route.interpret({text:'create testcases for these documents in excel format',attachments:doc}).engine,'chat');
});
test('Repo mutation still goes to agent',()=>{
  assert.equal(route.documentArtifactIntent('create testcases in the repo in Excel',doc),false);
  assert.equal(route.interpret({text:'implement test cases in the repo'}).engine,'agent');
});
test('Read-only investigations do not enable mutating execution',()=>{
  assert.equal(route.interpret({text:'analyse tests failing in repository'}).engine,'chat');
});
test('Workbook pipeline has source coverage, format-safety, and bounded chunks',()=>{
  assert.match(java,/newFixedThreadPool\(4/);
  assert.match(java,/final int max = 14_000/);
  assert.match(java,/createSheet\("Test Cases"\)/);
  assert.match(java,/createSheet\("Coverage"\)/);
  assert.match(java,/formula injection/);
  assert.match(java,/partial/);
});
test('Unified browser tabs and edit action are wired',()=>{
  assert.match(html,/id="unifiedTabs"/);
  assert.match(html,/id="unifiedNewTab"/);
  assert.match(css,/\.eliya-unified-tabs/);
  assert.match(ui,/function renderUnifiedTabs/);
  assert.match(ui,/function beginEditMessage/);
  assert.match(ui,/async function saveEditedMessage/);
  assert.match(ui,/\/rewind\//);
});
test('OpenCode output includes actual diff-based report and captures errors honestly',()=>{
  assert.match(oc,/\/api\/session\/" \+ s\.remoteId \+ "\/diff\?context=3/);
  assert.match(oc,/captureChangeReport\(s\)/);
  assert.match(oc,/"filesVerified"/);
  assert.match(oc,/"changeReport", changeReport/);
  assert.match(ui,/eliyaWhyChangedHtml/);
  assert.match(ui,/detail\.changeReport/);
});
