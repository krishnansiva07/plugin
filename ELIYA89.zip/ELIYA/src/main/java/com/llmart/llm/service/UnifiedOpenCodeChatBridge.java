package com.llmart.llm.service;

import com.llmart.llm.dto.ChatMode;
import com.llmart.llm.dto.ChatRequest;
import org.springframework.stereotype.Service;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

import java.util.*;
import java.util.concurrent.*;

/**
 * The single ELIYA conversation UI is the presentation layer for OpenCode work.
 * Conversation history remains ELIYA-owned; execution stays OpenCode-owned.
 * A network disconnect does not cancel the engine or silently report success.
 */
@Service
public class UnifiedOpenCodeChatBridge {
    private final OpenCodeExecutionService engine;
    private final ConversationService conversations;
    private final ExecutorService relay = Executors.newCachedThreadPool(r -> {
        Thread t = new Thread(r, "eliya-unified-opencode"); t.setDaemon(true); return t;
    });
    private final ConcurrentMap<String,String> active = new ConcurrentHashMap<>();

    public UnifiedOpenCodeChatBridge(OpenCodeExecutionService engine, ConversationService conversations) {
        this.engine = engine; this.conversations = conversations;
    }
    public boolean accepts(ChatRequest request) {
        return engine.accepts(request) && request.chatMode() == ChatMode.AGENT
                && request.projectId() != null && !request.projectId().isBlank() && !request.isRegenerate();
    }
    public boolean cancel(String conversationId) {
        String sessionId = active.get(conversationId);
        if (sessionId == null) return false;
        engine.cancel(sessionId); return true;
    }
    private static void send(SseEmitter emitter,String event,Object payload) {
        try { emitter.send(SseEmitter.event().name(event).data(payload)); }
        catch (Exception ignored) { /* engine continues when browser disconnects */ }
    }
    public SseEmitter stream(ChatRequest request) {
        SseEmitter emitter = new SseEmitter(0L);
        relay.execute(() -> {
            String conversationId = request.conversationId();
            String sessionId = null;
            boolean done = false;
            try {
                conversations.require(conversationId);
                var user = conversations.addMessage(conversationId,"user",request.message(),List.of());
                send(emitter,"meta",Map.of("conversationId",conversationId,"userMessageId",user.getId(),"mode","agent","engine","opencode"));
                send(emitter,"agent_step",Map.of("tool","OpenCode","status","running","detail","Starting OpenCode execution"));
                Optional<String> existing = engine.latestSession(conversationId,request.projectId());
                Map<String,Object> current = existing.isPresent()
                        ? engine.message(existing.get(),request) : engine.launch(request,null);
                sessionId = String.valueOf(current.get("id"));
                active.put(conversationId,sessionId);
                int previousLength = 0;
                long lastSeq = 0;
                long deadline = System.nanoTime() + TimeUnit.HOURS.toNanos(2);
                while (System.nanoTime() < deadline) {
                    current = engine.get(sessionId);
                    String answer = String.valueOf(current.getOrDefault("answer",""));
                    if (answer.length() < previousLength) previousLength = 0;
                    if (answer.length() > previousLength) {
                        send(emitter,"token",Map.of("text",answer.substring(previousLength)));
                        previousLength = answer.length();
                    }
                    Object rawEvents = current.get("events");
                    if (rawEvents instanceof List<?> events) {
                        for (Object raw : events) {
                            if (!(raw instanceof Map<?,?> event)) continue;
                            long seq = event.get("seq") instanceof Number n ? n.longValue() : 0;
                            if (seq <= lastSeq) continue;
                            lastSeq = seq;
                            if ("agent_step".equals(event.get("type"))) {
                                Object data = event.get("data");
                                if (data instanceof Map<?,?>) send(emitter,"agent_step",data);
                            }
                        }
                    }
                    String status = String.valueOf(current.getOrDefault("status","running"));
                    if (Set.of("completed","failed","cancelled","interrupted","needs_input").contains(status)) {
                        // Allow OpenCode's post-completion diff collection to finish
                        // before issuing a final report, but never wait indefinitely.
                        if (Set.of("completed","failed").contains(status) &&
                            !(current.get("changeReport") instanceof Map<?,?> report && report.containsKey("filesVerified"))) {
                            for (int retry=0; retry<5;retry++) {
                                Thread.sleep(250);
                                current=engine.get(sessionId);
                                if (current.get("changeReport") instanceof Map<?,?> report && report.containsKey("filesVerified")) break;
                            }
                        }
                        // Only completed execution is successful. Questions/errors are not silently closed.
                        String report = formatReport(current.get("changeReport"),status);
                        String finalAnswer = answer + (report.isBlank()?"":"\n\n"+report);
                        if (!"completed".equals(status)) finalAnswer += "\n\n**Execution status:** " + status
                                + ". The task is not confirmed complete. " + String.valueOf(current.getOrDefault("error",""));
                        var saved = conversations.addMessage(conversationId,"assistant",finalAnswer,List.of());
                        send(emitter,"done",conversations.messageDto(saved));
                        done=true; break;
                    }
                    Thread.sleep(900);
                }
                if (!done) send(emitter,"error",Map.of("message","OpenCode execution exceeded the bridge watch deadline; task status is unverified"));
            } catch (Exception failure) {
                send(emitter,"error",Map.of("message","OpenCode execution could not complete: " + failure.getMessage()));
            } finally {
                if (sessionId != null) active.remove(conversationId,sessionId);
                try { emitter.complete(); } catch (Exception ignored) {}
            }
        });
        return emitter;
    }
    private static String formatReport(Object raw, String status) {
        if (!(raw instanceof Map<?,?> report)) return "";
        Object rawFiles = report.get("files");
        boolean verified = Boolean.TRUE.equals(report.get("filesVerified"));
        StringBuilder result = new StringBuilder("### Execution change report\n");
        result.append("**Verification:** ").append(verified ? "OpenCode session diff retrieved" :
                "File diff unavailable; manual verification required").append("\n");
        result.append("**Why:** Changes were requested by the current instruction; file-specific intent must be confirmed against its diff.\n");
        if (rawFiles instanceof List<?> files) for (Object file : files) {
            if (file instanceof Map<?,?> item) result.append("- ")
                    .append(String.valueOf(item.containsKey("action") ? item.get("action") : "modified")).append(" `")
                    .append(String.valueOf(item.containsKey("relativePath") ? item.get("relativePath") : "unknown")).append("`: ")
                    .append(String.valueOf(item.containsKey("detail") ? item.get("detail") : "")).append("\n");
        }
        Object warning = report.get("fileReportWarning");
        if (warning != null) result.append("**Warning:** ").append(warning).append("\n");
        return result.toString();
    }
}
