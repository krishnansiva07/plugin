# ASTRA Visual Guardian — checkpoint and navigation recovery validation

## Changes

This maintenance build starts from the previously delivered `ASTRA_Visual_Guardian_Updated.zip`. It adds a persisted exploration path journal and last-action checkpoint, verified live-prefix reuse, deduplicated resume of legacy checkpoints, bounded polling of application readiness, and retryable durable checkpoint replacement. The UI separates unresolved paths from policy/coverage skips and explains whether model-assisted ranking is available. No Eliya source was modified. The existing direct Chromium DevTools Protocol and local JSON storage architecture is retained; no external Java dependencies added.

The last action is saved before interaction, after dispatch, and after readiness verification. A persisted checkpoint cannot prove the browser completed an action if the process crashed between dispatch and verification. The tool never claims exactly-once browser actions across a crash; prerequisite navigation may have to be replayed from a verified starting state. Captured states are not recaptured merely to reconstruct a completed path. Independent regression executions deliberately replay the baseline journeys.

## Validation environment and limits

- Linux, JDK 21 compiler targeting Java 17 (`javac --release 17`); class major version 61 confirmed. Node.js 22 JavaScript syntax check. JAR archive integrity checked.
- Browser integration uses the explicitly labelled mock CDP protocol fixture and local deterministic model endpoint. The mock delays readiness after clicks and injects a transient stale locator. It does not simulate real corporate browser rendering, native PIN dialogs, or Windows file locking.
- A prior real Chromium navigation attempt was blocked by administrator URL policy (`net::ERR_BLOCKED_BY_ADMINISTRATOR`); no change to that policy was made. See `validation/real-browser-blocked.log`. Corporate SSO, real model quality, actual Windows sharing violations and enterprise scale remain unverified.
- The filesystem retry check creates a temporary conflicting directory and releases it to provoke a real Linux file-replacement error; this verifies the retry path, not Windows-specific locking behavior.

## Targeted checks on the final build

- 8/8 Java checkpoint checks passed: distinct numeric identities, path prefix, pending queue deduplication, issue consolidation and clearing, persisted journal, resumed pending queue, transient filesystem replacement retry.
- 9/9 locator checks passed (Java and generated JavaScript against synthetic DOM).
- 3/3 focused simulated-browser resume checks passed: capture limit retains completed states and pending paths; legacy checkpoint with intentionally duplicated pending paths resumes and completes without changing earlier screenshot hashes; journal contains only remaining non-root paths.
- An earlier intermediate build passed all 30 simulated integration checks. This is historical intermediate evidence, not a claim about the exact packaged final JAR.

## Final build full integration

The final JAR passed **32/32** simulated integration checks, including live-prefix reuse, last action readiness verification, delayed readiness, identical application replay (8/8 states passed), injected migration regressions (8/8 detected), model selection, evidence import/export, reports, failed-only rerun, manual authentication handover, authentication reminder, stop and resume. Exact log: `validation/integration-final.log`. The final targeted and integration checks total **52 passed** (32 + 8 + 9 + 3). Build and ZIP integrity are separate checks. No corporate-browser or Windows-specific certification is claimed.

## Upgrade and acceptance

1. Stop the previous application, close editors on its run.json files and back up guardian-data.
2. Extract the new package separately; copy the backed-up data folder into the new directory. Launch using launch.cmd. Re-enter model API keys if needed.
3. Open the existing incomplete/error capture and choose Resume pending work. The engine will preserve captured states, deduplicate the queue and retry unresolved paths. Reauthenticate if requested. Old successful states should not be recaptured; prerequisites may need replay.
4. Use 120 seconds page readiness and 30 seconds locator recovery when launching new runs against slow applications. Enable model-data consent only if authorized. If a blocked request is reported, review the specific approved read-only endpoint with the application owner; never bypass the safety policy indiscriminately.
5. Verify actual BMS screenshots and coverage, inspect the last-action checkpoint, and confirm the full run is completed before approving a baseline.
