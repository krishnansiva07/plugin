# ASTRA Visual Guardian

Standalone local application for agent-assisted web UI discovery, portable visual baselines, repeatable migration comparisons and independent execution history. Eliya is a **read-only architectural reference**; this application does not modify, embed or require a running Eliya instance.

## Start the application

**Requirements:** Java 17 or newer and installed Chrome, Edge or Chromium. No Maven, Node, Python or downloaded browser driver is required to launch the application. A visible desktop is required for interactive authentication. Corporate browser policy must permit a dedicated profile and local DevTools automation. Run as an ordinary user, not an administrator or root.

1. Extract the entire package to a local folder you control.
2. Windows: double-click `launch.cmd`. Linux/macOS: `./launch.sh` (or `sh launch.sh`). Alternatively: `java -jar visual-guardian.jar`.
3. Open **http://127.0.0.1:8765**. Keep the console open. Default data directory: `guardian-data` in the launch folder.
4. To use another port or data directory: `java -jar visual-guardian.jar --port 8766 --data /path/to/guardian-data`.

If the browser is not detected automatically, supply its executable path in the suite or launch configuration. Windows examples: `C:\Program Files\Google\Chrome\Application\chrome.exe` or `C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe`. Actual paths depend on installation. Do not disable certificate verification or enterprise browser policies to make a run succeed.

## Model configuration

Open **Model settings**. Each of the Agent, Vision and Reviewer roles accepts a user-defined API base URL and exact model ID, with independent API keys, timeouts and output-token limits. The API contract is OpenAI-compatible `/models` and `/chat/completions`; use the provider's compatible base URL (commonly ending in `/v1`). Save settings, discover model IDs when supported, and test each connection. A Vision test submits a small generated image. A successful response verifies transport, not model accuracy.

The app does not require any specific model. The Agent prioritizes eligible browser actions using a constrained list of IDs. Vision receives before/after screenshots for detected differences when explicitly authorized. Reviewer can interpret the comparison evidence. Models cannot execute arbitrary scripts and cannot override deterministic findings. Model requests use opt-in per execution; deterministic discovery and comparisons can run without configured models. A failed Agent request falls back to deterministic action ordering; failed Vision is recorded without converting a regression into a pass.

API keys are retained in process memory, not the settings file or ZIP. To avoid re-entering keys after restart, provision them through approved environment-variable mechanisms: `GUARDIAN_AGENT_API_KEY`, `GUARDIAN_VISION_API_KEY`, `GUARDIAN_REVIEWER_API_KEY`. Do not put keys in launch scripts. Native non-compatible provider APIs, provider-specific Azure deployment authentication, embeddings and automatic alternate-model failover are not implemented.

## Before migration: capture a baseline

1. Go to **Applications & suites → New suite** and enter an authorized test application URL, browser settings and scope limits. Configure masks for changing timestamps and sensitive regions. Approve any genuinely read-only POST paths or extra read-only control labels only after reviewing application behavior.
2. Choose **Capture baseline**. Confirm local screenshot/DOM storage permission. Enable model data sharing only if your organization's approved endpoint may receive these materials.
3. Use the visible browser. SSO can complete automatically where the browser allows it. Initial navigation is asynchronous so authentication is not bounded by the normal page readiness timeout. If authentication is detected or readiness is uncertain, the run waits. Select a client certificate, enter a smart-card PIN, username/password or MFA yourself, directly in the browser. For guaranteed manual handover, choose the manual-authentication option before starting. Keep the original browser tab active and return to the application landing page. Click **Return control / Start agent** in Guardian. The app requires a same-origin, apparently ready, non-login screen. It cannot directly inspect native OS security dialogs. The authentication reminder defaults to 1,800 seconds (30 minutes); expiration leaves the run awaiting input in the same browser, not failed. Stop explicitly to end the wait. Automatic handover requires a same-origin, apparently authenticated landing page stable for at least five seconds. For slow or multi-step SSO, select manual authentication before launch.
4. Monitor discovered states, pending paths, skips, event history and model usage. The agent explores eligible links, menus, tabs, expandable controls, selects and recognized read-only buttons; it deduplicates UI states using route and normalized visible structure. It captures viewport PNGs and sanitized DOM-derived metadata. It builds replayable action paths with semantic locator information. Review coverage exclusions; unknown interactions and depth limits are recorded rather than silently counted as passed.
5. On a completed capture, review evidence and coverage exceptions, then choose **Approve baseline**. Approved captures cannot be resumed or overwritten. Download **baseline.zip**. Baseline approval is an explicit acceptance of captured scope, not proof that the complete application was discovered.

## After migration: import and replay

1. In the same installation select the existing suite, or choose **Import ZIP** in a fresh installation. Import only packages from trusted sources. Inspect `suite.json` if necessary: checksums detect accidental modification but are not a digital signature. Browser paths and proxy settings are removed from exported suite settings; supply the local browser path if needed. Imported suite capture consent and model-sharing permissions default to off.
2. Choose **Replay baseline**, select the approved reference and enter the migrated URL. The captured viewport and masks are reused. URL path differences are compared by default; configure path comparison off when a context-path change is intentional. Use the same browser family, fonts, language, role, test data and environmental conditions to reduce false positives.
3. Complete authentication if required and hand back control. The engine replays each captured path from the authenticated landing page, matches live candidates using exact and semantic locators, and compares masked PNGs, DOM-derived structure and route. The engine refreshes the live DOM and retries locator resolution within the configurable recovery interval (default 15 seconds). It matches stable IDs, test attributes, names, role/label and link destination. Invalid CSS is caught and a unique live matching element can be used; ambiguous or non-actionable elements are inconclusive. An actually missing element may still fail the affected comparison. Recovered attempts are recorded, and independent paths continue. For missing controls, the report can retain the last reachable screen as evidence, explicitly not an equivalent target screenshot.
4. Review results, download `report.html`, `report.xlsx` and `execution.zip`. A completed execution may have a failing verdict. A pass refers only to selected captured states, not every function in the application. A separate capture on the migrated environment can discover new states; automatic post-replay exploration is not implemented.

## Run history and recovery

- Every capture, replay and offline comparison receives a separate UUID. A run records its baseline, parent rerun, model settings, configuration, state results, attempt metadata and events.
- **Run status** describes the execution lifecycle; **verdict** describes the validation outcome. Incomplete, stopped, environment-error and inconclusive states must not be interpreted as passing. Missing recorded UI elements and structural/pixel differences produce failures; visual differences alone do not prove functional impact.
- Rerun all, failed only, incomplete only or selected state IDs. A rerun is a new execution with its parent reference. It never overwrites a prior run or the approved baseline. Selective reruns are not aggregated into a fictitious full-suite pass.
- Pause, take manual browser control or stop at a safe checkpoint. A browser or model request in flight may take its bounded timeout to return. Resume uses saved pending work and may require a new browser login. Stop/resume preserves the run ID; failed attempts have metadata, but there is not a separate screenshot for every retry.
- For interrupted captures, resume pending paths. For limit-related incomplete captures, raise limits in the resume dialog. Previously failed capture paths can be retried. Independent replay states retry bounded errors; a new run can rerun incomplete states.
- **Compare runs** matches stable captured state IDs and generates a new offline comparison artifact. Meaningful cross-run comparisons should originate from the same baseline; different independent captures can have different state IDs. Trend history separates potential intermittent failures, persistent failures, and status transitions for comparable suite/baseline/target combinations.
- The portable execution ZIP contains observed and available reference screenshots, differences, metadata, checksums and reports. ZIP imports are independent copies. They exclude browser session state, API keys, and endpoint configuration. The ZIP limits are 128 MiB compressed input, 256 MiB expanded import and 200 MiB expanded export, with per-entry and image dimension limits. Smaller suites are recommended for large applications. Reports and archives currently use local in-memory generation and are not validated at enterprise scale.

## Security and scope

Run only against applications and environments you are authorized to test, preferably with restricted test accounts and synthetic data. Automation uses conservative candidate filtering and an attached-page request filter (non-read methods denied unless explicitly allowed). This is defense-in-depth, **not a guarantee of read-only behavior**: applications may mutate via GET, service workers, JavaScript, background tasks or other browser targets. Do not automate production banking applications without formal approval and suitable server-side authorization. Manual control allows normal browser actions and is the user's responsibility.

The app never asks for or intentionally records application passwords/PINs/OTPs. Screenshots and DOM capture begin only after readiness checks. Form inputs, editable regions, marked sensitive nodes and iframes are masked in screenshots by default; use additional CSS selectors for business data and verify the masks before sharing. Masking cannot guarantee every confidential value is found. Authentication screen detection is heuristic; use explicit manual handover if uncertain. Temporary browser profiles may contain session data while running; do not share them, and remove any orphaned temporary profile after a crash in accordance with local policy. The application stores data locally without at-rest encryption; secure the data directory using OS permissions and organization-approved encrypted storage. Local HTTP service binds to loopback with a session token and origin checks; it is not a multi-user service. Do not expose it through a public proxy.

### Scope that still needs implementation or environment validation

- Actual Chrome/Edge application navigation, real screenshot masking/rendering, native certificate/PIN, corporate SSO/MFA and actual model endpoints are not end-to-end certified in the build environment. Chromium started and answered DevTools commands but an administrator URL-block policy prevented navigation. The integration suite uses a separately labelled simulated CDP browser and local model fixture, not a real corporate application.
- Direct Chromium DevTools Protocol is used instead of Playwright Java/Spring Boot/H2 because Maven and external dependency access were unavailable. The source is dependency-free Java, with atomic local JSON persistence. This is an intentional architecture adjustment for a directly runnable JAR.
- Supported exploration is the primary tab's ordinary DOM, with controlled clicks and dropdown selection. Cross-origin iframe automation, shadow-DOM traversal, automatic new-tab switching, canvas-based control, complex input/test-data workflows, a generalized question engine, business assertions, arbitrary workflows, fully autonomous new-screen discovery after replay, enterprise-scale performance, persistent encrypted browser profiles, Playwright script export, CI/CD integrations, and full provider-specific SDKs are not implemented. Manual control is available; unsupported automated coverage must be reviewed.
- The desktop browser is visible when launched in non-headless mode; an embedded live remote-browser stream is not included. Screenshot evidence is available in the UI and HTML report.

## Build and tests

Source: `src/guardian/` and `resources/`. Build: `build.cmd` or `./build.sh` with a JDK 17+. Output `build/visual-guardian.jar`. The shipped `visual-guardian.jar` is already compiled; building is not required to launch.

The optional Python integration tests in `tests/` are separate from runtime. On a machine that permits Chrome navigation, run `python tests/e2e.py visual-guardian.jar`; set `GUARDIAN_TEST_BROWSER` to the local executable and install Python Playwright for the automated test-only handover. On Linux, the explicit simulated fixture is `GUARDIAN_TEST_MOCK=1 GUARDIAN_TEST_BROWSER="$PWD/tests/mock_browser.py" python tests/e2e.py visual-guardian.jar` (requires Python `websockets` and `Pillow`). The mock tests exercise Java orchestration, comparison, local HTTP API, model request protocol, state/history, archives and report generation, but do not establish true browser rendering or enterprise authentication behavior.

See `VALIDATION.md` and the separate logs for exact validation evidence and the release qualification. No Maven tests were silently skipped; no Maven build was used.

## Updating an existing installation

Stop Guardian completely and back up the `guardian-data` directory. Extract the updated ZIP into a separate folder. Copy the backed-up data directory to the new folder, or launch with `--data` pointing to your existing data directory (only one instance at a time). Existing baseline and execution formats are unchanged. Model keys may need to be entered again. Old suite timeout values are preserved; you may override them when launching a run.

### Execution timing controls

| Setting | Default for new suites | Purpose |
|---|---:|---|
| Authentication reminder | 1,800 seconds | Reminder only; keep waiting for user authentication until stopped or browser closes. |
| Page readiness timeout | 60 seconds | Wait for document readiness after normal navigation or action. Individual DevTools commands have their own bounded timeout. |
| Locator recovery timeout | 15 seconds | Refresh DOM and retry a missing, ambiguous or stale candidate before reporting the affected path. |

For SSO, select manual authentication, complete certificate selection/PIN/MFA in the opened browser, navigate to the target application home page, then click Return control / Start agent. No credentials should be entered in Guardian.

### Targeted locator regression tests

From the project root after building, run `javac --release 17 -cp build/classes -d build/test-classes tests/LocatorChecks.java`, then `java -cp build/classes:build/test-classes guardian.LocatorChecks /tmp/guardian-action.js`, then `node tests/locator_dom.js /tmp/guardian-action.js` (Linux classpath syntax). The Java tests cover matching and timing defaults; the JS tests execute the actual generated action script against a small synthetic DOM, not Chromium.

### Action-level checkpoints and Windows persistence recovery

The capture engine now keeps an action journal, deduplicates pending paths against previously captured states, and records the latest action phase (`BEFORE_ACTION`, `ACTION_SENT`, `VERIFIED_READY`, or `UNRESOLVED`). During live capture it preferentially explores a child of the current verified browser state; a matching fingerprint is required before skipping its already-executed navigation prefix. If the browser is reopened or the current state cannot be verified, navigation prerequisites may be replayed. The journal does not guarantee exactly-once interactions across browser or OS crashes. Only approved non-mutating exploration is supported. Completed screenshots and approved baselines remain unchanged during capture resume.

If an existing run has status ERROR or INCOMPLETE, choose **Resume pending work**; old runs without an action journal are deduplicated using their captured paths. Unresolved failures are requeued, and repeated failures are consolidated. The current run's existing limits apply unless raised in the resume dialog. Authentication may be required again. The browser remains open during authentication. The page-readiness check polls transient loading states instead of failing immediately after a click. Blocked requests are distinguished from readiness timeouts; do not relax network safeguards unless the application owner approves the specific read-only request paths.

Checkpoint replacement retries transient file-system errors; the previous durable run.json is not deleted first. If the write remains blocked, close editors or other processes that hold the file, check disk space and permissions, and resume. Keep data outside synchronized folders if your corporate policy permits. The live error is separately surfaced even if the disk cannot accept a new checkpoint. The dashboard displays last action, reused prefixes, actual verified browser actions, unresolved paths and policy skips. AI ranking is used only when configured and expressly authorized for model data submission; otherwise deterministic discovery continues.
