package com.llmart.llm.cli;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

public class AutoCliSetupSmoke {
    private static int checks;
    private static void ok(boolean actual, String reason) {
        checks++;
        if (!actual) throw new AssertionError(reason);
    }

    public static void main(String[] args) throws Exception {
        if (args.length > 0 && args[0].equals("--jar-classpath-check")) {
            Path self = EliyaCliAutoSetup.launchedJar(AutoCliSetupSmoke.class);
            ok(self != null && self.getFileName().toString().equals("setup-smoke.jar"),
                    "Java -jar must resolve exact executable archive");
            System.out.println("ELIYA128 executable JAR path detection: passed");
            return;
        }
        ok(EliyaCliAutoSetup.launchedJar(AutoCliSetupSmoke.class) == null,
                "IDE/class directory must not be auto-registered");
        Path temp = Files.createTempDirectory("eliya128 auto setup with spaces ");
        Path jar = temp.resolve("ELIYA Release 128.jar");
        Files.writeString(jar, "mock jar");
        ok(EliyaCliAutoSetup.detectPlatform("Windows 11") == EliyaCliAutoSetup.Platform.WINDOWS, "windows");
        ok(EliyaCliAutoSetup.detectPlatform("Mac OS X") == EliyaCliAutoSetup.Platform.MAC, "mac");
        ok(EliyaCliAutoSetup.detectPlatform("Linux") == EliyaCliAutoSetup.Platform.LINUX, "linux");
        ok(EliyaCliAutoSetup.detectPlatform("Solaris") == EliyaCliAutoSetup.Platform.UNSUPPORTED, "unknown OS");

        // An explicit fake Java runtime proves the generated launcher preserves working
        // directory, arguments and spaces without executing the real Eliya application.
        Path fakeJava = Files.createDirectories(temp.resolve("mock java runtime/bin")).resolve("java");
        Files.writeString(fakeJava, "#!/bin/sh\nprintf 'cwd=%s\\n' \"$PWD\"\nprintf 'arg=%s\\n' \"$@\"\n");
        fakeJava.toFile().setExecutable(true);
        Path linux = Files.createDirectories(temp.resolve("linux home"));
        var posix = EliyaCliAutoSetup.installPosix(jar, linux, EliyaCliAutoSetup.Platform.LINUX, "/bin/bash", fakeJava);
        ok(posix.installed(), "Linux setup failed");
        ok(Files.isExecutable(posix.launcher()), "Linux launcher is not executable");
        String posixSource = Files.readString(posix.launcher());
        ok(posixSource.contains("--eliya-cli \"$@\""), "shell arguments missing");
        ok(posixSource.contains("'" + jar + "'"), "jar with spaces not quoted");
        Process syntax = new ProcessBuilder("sh", "-n", posix.launcher().toString()).start();
        ok(syntax.waitFor() == 0, "POSIX launcher shell syntax invalid");
        Path project = Files.createDirectories(temp.resolve("automation project"));
        Process cli = new ProcessBuilder(posix.launcher().toString(), "analyse", "inspect my Java project")
                .directory(project.toFile()).redirectErrorStream(true).start();
        String cliOutput = new String(cli.getInputStream().readAllBytes());
        ok(cli.waitFor() == 0, "generated POSIX launcher did not execute");
        ok(cliOutput.contains("cwd=" + project), "shell working directory changed");
        ok(cliOutput.contains("arg=--eliya-cli") && cliOutput.contains("arg=analyse") &&
                cliOutput.contains("arg=inspect my Java project"), "launcher did not preserve prompt as one argument");
        ok(Files.readString(linux.resolve(".bashrc")).contains("ELIYA AUTO-CLI"), "bashrc not registered");
        ok(Files.readString(linux.resolve(".profile")).contains(".local/bin"), "login shell not registered");
        EliyaCliAutoSetup.installPosix(jar, linux, EliyaCliAutoSetup.Platform.LINUX, "/bin/bash");
        ok(Files.readString(linux.resolve(".bashrc")).split("ELIYA AUTO-CLI V128 >>>", -1).length == 2,
                "launcher setup not idempotent");
        Path unrelated = Files.createDirectories(temp.resolve("unrelated"));
        Files.createDirectories(unrelated.resolve(".local/bin"));
        Files.writeString(unrelated.resolve(".local/bin/eliya"), "#!/bin/sh\necho existing\n");
        boolean preserved = false;
        try { EliyaCliAutoSetup.installPosix(jar, unrelated, EliyaCliAutoSetup.Platform.LINUX, ""); }
        catch (java.io.IOException e) { preserved = e.getMessage().contains("unrelated launcher"); }
        ok(preserved, "existing unrelated launcher overwritten");
        ok(Files.readString(unrelated.resolve(".local/bin/eliya")).contains("existing"), "existing launcher was modified");
        // Migration from ELIYA127's symlink installer replaces the symlink itself,
        // never editing the old source-tree script.
        Path legacy = Files.createDirectories(temp.resolve("legacy"));
        Path legacyScript = legacy.resolve("eliya");
        Files.writeString(legacyScript, "#!/bin/bash\necho 'ELIYA JAR not found'\n");
        Path migrated = Files.createDirectories(temp.resolve("migrated"));
        Files.createDirectories(migrated.resolve(".local/bin"));
        Files.createSymbolicLink(migrated.resolve(".local/bin/eliya"), legacyScript);
        var migration = EliyaCliAutoSetup.installPosix(jar, migrated, EliyaCliAutoSetup.Platform.LINUX,
                "/bin/bash", fakeJava);
        ok(migration.installed() && !Files.isSymbolicLink(migration.launcher()), "legacy launcher migration failed");
        ok(Files.readString(legacyScript).contains("ELIYA JAR not found"), "legacy source was unexpectedly edited");

        Path mac = Files.createDirectories(temp.resolve("mac home"));
        var macResult = EliyaCliAutoSetup.installPosix(jar, mac, EliyaCliAutoSetup.Platform.MAC, "/bin/zsh");
        ok(macResult.installed(), "macOS setup failed");
        ok(Files.exists(mac.resolve(".zprofile")) && Files.exists(mac.resolve(".zshrc")), "zsh profiles missing");
        ok(!Files.exists(mac.resolve(".bash_profile")), "new bash_profile would suppress existing profile");

        var requested = new ArrayList<List<String>>();
        EliyaCliAutoSetup.CommandRunner reg = command -> {
            requested.add(List.of(command));
            if (command.length == 3) return new EliyaCliAutoSetup.RunResult(0, "HKEY_CURRENT_USER\\Environment\n");
            if (command.length == 5) return new EliyaCliAutoSetup.RunResult(0,
                    "HKEY_CURRENT_USER\\Environment\n    Path    REG_EXPAND_SZ    %USERPROFILE%\\Tools;C:\\Program Files\\Java\n");
            return new EliyaCliAutoSetup.RunResult(0, "The operation completed successfully.");
        };
        Path winHome = Files.createDirectories(temp.resolve("windows home"));
        Path winLocal = Files.createDirectories(winHome.resolve("AppData/Local"));
        var win = EliyaCliAutoSetup.installWindows(jar, winHome, winLocal, reg);
        ok(win.installed(), "Windows registry registration failed");
        String windowsCmd = Files.readString(win.launcher());
        ok(windowsCmd.contains("--eliya-cli %*"), "batch arguments not forwarded");
        ok(windowsCmd.contains("\"" + jar + "\""), "batch path with spaces not quoted");
        ok(requested.stream().anyMatch(cmd -> cmd.contains("add") &&
                cmd.contains("REG_EXPAND_SZ") && cmd.stream().anyMatch(arg -> arg.contains("%USERPROFILE%\\Tools;C:\\Program Files\\Java"))),
                "old PATH entries or REG_EXPAND_SZ type not retained");
        ok(requested.stream().noneMatch(cmd -> cmd.contains("HKLM")), "system environment unexpectedly changed");
        var secondCalls = new ArrayList<List<String>>();
        String bin = winLocal.resolve("Eliya/bin").toString();
        String already = EliyaCliAutoSetup.registerWindowsPath(Path.of(bin), cmd -> {
            secondCalls.add(List.of(cmd));
            if (cmd.length == 3) return new EliyaCliAutoSetup.RunResult(0, "HKEY_CURRENT_USER\\Environment");
            return new EliyaCliAutoSetup.RunResult(0, "    Path    REG_EXPAND_SZ    " + bin + ";C:\\Other\n");
        });
        ok(already.startsWith("Already"), "Windows idempotent PATH detection failed");
        ok(secondCalls.stream().noneMatch(cmd -> cmd.contains("add")), "duplicate registry writes");
        String blocked = EliyaCliAutoSetup.registerWindowsPath(Path.of(bin), cmd ->
                new EliyaCliAutoSetup.RunResult(1, "Access denied"));
        ok(blocked.contains("Could not read"), "managed policy failure must be reported without throwing");
        System.out.println("ELIYA128 OS auto-setup Java smoke passed (" + checks + " assertions)");
    }
}
