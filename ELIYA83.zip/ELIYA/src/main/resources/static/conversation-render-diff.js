/* ELIYA81: keyed conversation DOM reconciliation, no framework dependency.
 * Kept separate so main conversation, Agent, and Terminal can share predictable updates.
 */
(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  if (root) root.EliyaRenderDiff = api;
})(typeof window !== 'undefined' ? window : null, function () {
  'use strict';
  const weak = new WeakMap();
  function memo(message, index, render) {
    if (!message || message.role !== 'user' || message.streaming || message.agentProgress) return render(message, index);
    const fingerprint = [message.content, message.mode, message.id, message.role,
      message.chatCompletionWarning, message.archivedFiles?.length].join('\u0001');
    const prior = weak.get(message);
    if (prior && prior.key === fingerprint && prior.index === index) return prior.html;
    const html = render(message, index);
    weak.set(message, {key:fingerprint,index,html});
    return html;
  }
  // Edit is local UI state, not message content. Explicit invalidation protects the
  // memoization win for unchanged turns while always opening/closing the editor.
  function invalidate(message) { if (message) weak.delete(message); }
  function reconcile(root, items, render) {
    if (!root) return {added:0, changed:0, removed:0, unchanged:0};
    const existing = [...root.children].filter(n => n.classList?.contains('message'));
    const nextHtml = items.map((message, i) => memo(message, i, render));
    const stats = {added:0, changed:0, removed:0, unchanged:0};
    for (let i=0;i<nextHtml.length;i++) {
      const current = existing[i];
      const html = nextHtml[i];
      if (current && current.__eliyaRenderedHtml === html) {stats.unchanged++;continue;}
      const template = document.createElement('template');
      template.innerHTML = html;
      const replacement = template.content.firstElementChild;
      if (!replacement) continue;
      replacement.__eliyaRenderedHtml = html;
      if (current) {
        // A changed Agent card preserves a user's expanded disclosures.
        const open = [...current.querySelectorAll('details')].map(d => ({open:d.open,cls:d.className}));
        replacement.querySelectorAll('details').forEach((node, j) => {
          if (open[j]?.cls === node.className) node.open = open[j].open;
        });
        current.replaceWith(replacement);stats.changed++;
      } else {root.appendChild(replacement);stats.added++;}
    }
    for (let i=nextHtml.length;i<existing.length;i++) {existing[i].remove();stats.removed++;}
    return stats;
  }
  return Object.freeze({reconcile,memo,invalidate});
});
