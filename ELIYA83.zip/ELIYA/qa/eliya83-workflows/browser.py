"""ELIYA83 regression: Edit, green UI, terminal density, bounded concurrent documents."""
import asyncio,re,shutil
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parents[2]/'src/main/resources/static'
async def main():
 async with async_playwright() as pw:
  binary=shutil.which('chromium') or shutil.which('google-chrome') or shutil.which('chrome')
  launch={'headless':True,'args':['--no-sandbox','--disable-dev-shm-usage']}
  if binary: launch['executable_path']=binary
  browser=await pw.chromium.launch(**launch)
  page=await browser.new_page(viewport={'width':1440,'height':900})
  errors=[];page.on('pageerror',lambda exc:errors.append(str(exc)))
  html=re.sub(r'<script src="[^"]+"></script>','',(ROOT/'index.html').read_text())
  html=re.sub(r'<link rel="stylesheet"[^>]+>','',html)
  await page.set_content(html);await page.add_style_tag(content=(ROOT/'app.css').read_text())
  for name in ['architecture-diagrams.js','markdown.js','prompt-catalog.js','unified-routing.js','conversation-intelligence.js','conversation-render-diff.js','app.js','confluence-composer.js']:
   await page.add_script_tag(content=(ROOT/name).read_text())
  await page.evaluate('''() => {
    window.__rewinds=[]; window.__activeUploads=0; window.__maxUploads=0;
    window.fetch=async(url,opts={})=>{
      const path=String(url);
      if(path.includes('/rewind/')){window.__rewinds.push(path);return new Response(null,{status:204});}
      if(path==='/api/files'&&opts.method==='POST'){
        window.__activeUploads++;window.__maxUploads=Math.max(window.__maxUploads,window.__activeUploads);
        await new Promise(resolve=>setTimeout(resolve,55));window.__activeUploads--;
        const name=opts.body.get('file').name;
        return new Response(JSON.stringify({id:'id-'+name,name,mimeType:'text/plain',size:100,extractedCharacters:80,extractionStatus:'ready'}),{headers:{'content-type':'application/json'}});
      }
      if(path.includes('/api/chat/stream'))return new Response('event: meta\\ndata: {"userMessageId":8,"conversationId":"conv"}\\n\\nevent: done\\ndata: {"role":"assistant","content":"Revised result"}\\n\\n',{headers:{'content-type':'text/event-stream'}});
      if(path==='/api/conversations'&&opts.method==='POST')return new Response(JSON.stringify({id:'terminal-upload-conv'}),{headers:{'content-type':'application/json'}});
      if(path.includes('/api/conversations'))return new Response(JSON.stringify([]),{headers:{'content-type':'application/json'}});
      return new Response(JSON.stringify({}),{headers:{'content-type':'application/json'}});
    };
    state.config.apiKey='key';state.config.baseUrl='http://localhost';state.config.model='agent';state.config.chatModel='chat';
    state.conversationId='conv';state.messages=[{id:1,role:'user',content:'Original investigation'}, {id:2,role:'assistant',mode:'chat',content:'Original result'}];
    state.workflowMode='analyse';state.mode='chat';renderMessages();updateModeUi();
  }''')
  assert await page.locator('#messages [data-edit-msg="0"]').count()==1
  await page.locator('#messages [data-edit-msg="0"]').click()
  assert await page.locator('#editMessageInput').count()==1,'Edit must show editable input'
  await page.locator('#editMessageInput').fill('Explain the revised investigation')
  await page.locator('[data-edit-save="0"]').click()
  await page.wait_for_function('()=>window.__rewinds.length===1 && !state.streaming',timeout=9000)
  assert await page.evaluate('state.messages[0].content')=='Explain the revised investigation'
  assert await page.locator('#editMessageInput').count()==0
  assert await page.evaluate('window.__rewinds.length')==1
  assert await page.evaluate("getComputedStyle(document.documentElement).getPropertyValue('--accent').trim()")=='#087e50'
  await page.evaluate("document.getElementById('layoutHeaderToggle').click()")
  assert await page.locator('main.header-compact').count()==1
  await page.evaluate("document.getElementById('composerLayoutToggle').click()")
  assert await page.locator('.composer-zone.composer-compact').count()==1
  await page.evaluate("document.getElementById('terminalLayoutToggle').click()")
  assert await page.locator('.terminal-dock.terminal-focus-view').count()==1
  await page.evaluate("document.getElementById('terminalComposerToggle').click()")
  assert await page.locator('.terminal-dock.terminal-composer-collapsed').count()==1
  await page.evaluate("document.getElementById('terminalComposerToggle').click()")
  assert await page.locator('.terminal-dock.terminal-composer-collapsed').count()==0
  await page.evaluate('''async()=>{
    state.messages=[];state.attachments=[];state.filesById.clear();renderMessages();
    const files=['a.txt','b.txt','c.txt'].map(name=>new File(['Requirements'],name,{type:'text/plain'}));
    await uploadFiles(files);
  }''')
  assert await page.evaluate('window.__maxUploads')==2
  assert await page.evaluate('state.uploadingCount')==0
  assert await page.evaluate('state.attachments.length')==3
  assert await page.locator('#attachmentTray .chip-ready').count()==3
  await page.evaluate('''async()=>{
    terminalUi.attachments=[];terminalUi.attachmentsUploading=0;terminalUi.attachmentConversationId=null;
    await uploadTerminalFiles(['req-one.txt','req-two.txt'].map(name=>new File(['Validation requirements'],name,{type:'text/plain'})));
  }''')
  assert await page.evaluate('terminalUi.attachments.length')==2
  assert await page.evaluate('terminalUi.attachmentsUploading')==0
  assert 'Ask, follow up' in await page.locator('#terminalInputHint').inner_text()
  await page.evaluate('''()=>{
    state.messages=[{role:'user',id:1,content:'Implement tests'},
      {role:'assistant',content:'Created tests',mode:'agent',streaming:false,
       agentRunId:'r1',agentSteps:[
        {tool:'read_file',detail:'Inspected input requirements',status:'success'},
        {tool:'write_file',detail:'Generated scenarios',status:'success'},
        {tool:'test_run',detail:'Validated generated tests',status:'success'}],
       agentProgress:{status:'completed',phase:'completed',percent:100,detail:'All tests generated'}}];
    renderMessages();
  }''')
  assert await page.locator('.agent-operation-spotlight').count()==1
  assert await page.locator('.agent-operation-list li').count()==3
  assert 'Generated scenarios' in await page.locator('.agent-operation-spotlight').inner_text()
  assert not errors,errors
  await browser.close()
 print('PASS ELIYA83 Chromium: message editing/rewind, emerald UI, density switches, parallel Analyse and Terminal uploads, operation timeline')
asyncio.run(main())
