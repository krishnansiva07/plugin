"""Offline compile and basic TXT/DOCX/size/timeout smoke for the real FileService.
Apache Tika/POI/Spring classes are stubbed; this does not replace Maven integration tests.
"""
from pathlib import Path
import subprocess, tempfile, textwrap

ROOT=Path(__file__).resolve().parents[2]
SOURCES={
 'org/springframework/stereotype/Service.java':'package org.springframework.stereotype; public @interface Service {}',
 'org/springframework/beans/factory/annotation/Value.java':'package org.springframework.beans.factory.annotation; public @interface Value { String value(); }',
 'org/springframework/core/io/FileSystemResource.java':'package org.springframework.core.io; public class FileSystemResource { public FileSystemResource(String f){} }',
 'org/springframework/web/multipart/MultipartFile.java':'''package org.springframework.web.multipart;
 import java.nio.file.Path; public interface MultipartFile {boolean isEmpty();long getSize();String getOriginalFilename();
 String getContentType();void transferTo(Path p) throws java.io.IOException;}''',
 'org/apache/tika/Tika.java':'''package org.apache.tika;
 import java.nio.file.Path; import java.io.*; public class Tika {
 public void setMaxStringLength(int v) {} public String detect(Path p) {return p.toString().endsWith(".docx") ? "application/vnd.openxmlformats-officedocument.wordprocessingml.document" : "text/plain";}
 public String parseToString(InputStream in) throws Exception {return new String(in.readAllBytes());}}''',
 'org/apache/poi/ss/usermodel/Cell.java':'package org.apache.poi.ss.usermodel; public interface Cell {}',
 'org/apache/poi/ss/usermodel/Row.java':'package org.apache.poi.ss.usermodel; public interface Row extends Iterable<Cell> {}',
 'org/apache/poi/ss/usermodel/Sheet.java':'package org.apache.poi.ss.usermodel; public interface Sheet extends Iterable<Row> { String getSheetName(); }',
 'org/apache/poi/ss/usermodel/Workbook.java':'package org.apache.poi.ss.usermodel; public interface Workbook extends AutoCloseable {int getNumberOfSheets(); Sheet getSheetAt(int i); void close();}',
 'org/apache/poi/ss/usermodel/WorkbookFactory.java':'package org.apache.poi.ss.usermodel; public class WorkbookFactory { public static Workbook create(java.io.InputStream s){throw new UnsupportedOperationException();} }',
 'org/apache/poi/ss/usermodel/DataFormatter.java':'package org.apache.poi.ss.usermodel; public class DataFormatter { public String formatCellValue(Cell c){return "";} }',
 'org/apache/poi/xslf/usermodel/XSLFShape.java':'package org.apache.poi.xslf.usermodel; public interface XSLFShape {}',
 'org/apache/poi/xslf/usermodel/XSLFTextShape.java':'package org.apache.poi.xslf.usermodel; public interface XSLFTextShape extends XSLFShape {String getText();}',
 'org/apache/poi/xslf/usermodel/XSLFSlide.java':'package org.apache.poi.xslf.usermodel; public class XSLFSlide {public java.util.List<XSLFShape> getShapes(){return java.util.List.of();}}',
 'org/apache/poi/xslf/usermodel/XMLSlideShow.java':'package org.apache.poi.xslf.usermodel; public class XMLSlideShow implements AutoCloseable {public XMLSlideShow(java.io.InputStream s){} public java.util.List<XSLFSlide> getSlides(){return java.util.List.of();} public void close(){}}',
 'com/llmart/llm/dto/FileDto.java':'''package com.llmart.llm.dto; public record FileDto(String id,String name,String mimeType,long size,long extractedCharacters,String extractionStatus,String extractionMessage) {}''',
 'com/llmart/llm/entity/FileEntity.java':'''package com.llmart.llm.entity;
 import java.time.Instant;
 public class FileEntity {
 String id,conversationId,name,path,mime,text,status,message;long size;
 public FileEntity(String id,String cid,String name,String path,String mime,long size,String text,String status,String message) {this.id=id;this.conversationId=cid;this.name=name;this.path=path;this.mime=mime;this.size=size;this.text=text;this.status=status;this.message=message;}
 public String getId(){return id;} public String getConversationId(){return conversationId;} public String getOriginalName(){return name;} public String getStoredPath(){return path;} public String getMimeType(){return mime;} public long getSizeBytes(){return size;}
 public String getExtractedText(){return text;} public String getExtractionStatus(){return status;} public String getExtractionMessage(){return message;} public Instant getCreatedAt(){return Instant.EPOCH;}
 public void updateExtractedText(String text){this.text=text;} public void updateExtractionResult(String t,String s,String m){text=t;status=s;message=m;}
 }''',
 'com/llmart/llm/repository/FileRepository.java':'''package com.llmart.llm.repository; import com.llmart.llm.entity.FileEntity;import java.util.*;
 public class FileRepository {public Map<String,FileEntity> rows=new HashMap<>();public FileEntity save(FileEntity f){rows.put(f.getId(),f);return f;}
 public Optional<FileEntity> findById(String id){return Optional.ofNullable(rows.get(id));} public List<FileEntity> findByConversationId(String id){return rows.values().stream().filter(f->f.getConversationId().equals(id)).toList();}
 public void deleteById(String id){rows.remove(id);}}''',
 'com/llmart/llm/service/ConversationService.java':'package com.llmart.llm.service; public class ConversationService {public void require(String id) {}}',
 'com/llmart/llm/service/FileServiceSmoke.java':'''package com.llmart.llm.service;
 import com.llmart.llm.dto.FileDto;import com.llmart.llm.entity.FileEntity;import com.llmart.llm.repository.FileRepository;
 import org.springframework.web.multipart.MultipartFile;import java.nio.file.*;import java.util.zip.*;import java.io.*;
 public class FileServiceSmoke {
 static void check(boolean condition,String what){if(!condition)throw new AssertionError(what);}
 static MultipartFile upload(byte[] bytes,String name,String mime) {return new MultipartFile(){
 public boolean isEmpty(){return bytes.length==0;}public long getSize(){return bytes.length;}public String getOriginalFilename(){return name;}
 public String getContentType(){return mime;}public void transferTo(Path dest)throws IOException{Files.write(dest,bytes);}};}
 static byte[] docx(String body)throws Exception{
 ByteArrayOutputStream b=new ByteArrayOutputStream();try(ZipOutputStream out=new ZipOutputStream(b)){
 out.putNextEntry(new ZipEntry("word/document.xml"));out.write(("<w:document xmlns:w='http://schemas.openxmlformats.org/wordprocessingml/2006/main'><w:body><w:p><w:r><w:t>"+body+"</w:t></w:r></w:p></w:body></w:document>").getBytes());out.closeEntry();}
 return b.toByteArray();}
 public static void main(String[] a)throws Exception{
 FileRepository repo=new FileRepository();FileService svc=new FileService(repo,new ConversationService(),Files.createTempDirectory("eliya-83-files").toString());
 FileDto text=svc.save("session",upload("Requirement A: generate tests".getBytes(),"requirements.txt","text/plain"));
 check("ready".equals(text.extractionStatus()),"text status");check(text.extractedCharacters()>15,"text extraction");
 FileDto word=svc.save("session",upload(docx("As a user I want login test cases"),"requirements.docx","application/vnd.openxmlformats-officedocument.wordprocessingml.document"));
 check("ready".equals(word.extractionStatus()),"docx status " +word.extractionStatus()+" " +word.extractionMessage());
 check(word.extractedCharacters()>25,"docx extraction");
 FileDto huge=svc.save("session",upload(docx("a".repeat(700000)),"large.docx","application/vnd.openxmlformats-officedocument.wordprocessingml.document"));
 check(huge.extractedCharacters()<610000,"document extracted char cap");
 check("ready".equals(huge.extractionStatus()),"large valid docx stays usable");
 System.out.println("PASS ELIYA83 Java: actual FileService compiles; text/DOCX extraction works; extracted content capped");
 }
 }'''
}
with tempfile.TemporaryDirectory(prefix='eliya83-java-') as td:
    base=Path(td)
    paths=[]
    for rel,src in SOURCES.items():
        p=base/'src'/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(textwrap.dedent(src));paths.append(str(p))
    prod=ROOT/'src/main/java/com/llmart/llm/service/FileService.java'
    p=subprocess.run(['javac','-encoding','UTF-8','-d',str(base/'out'),str(prod),*paths],capture_output=True,text=True)
    if p.returncode:raise RuntimeError('FileService Java compile failed:\n'+p.stderr)
    p=subprocess.run(['java','-cp',str(base/'out'),'com.llmart.llm.service.FileServiceSmoke'],capture_output=True,text=True)
    if p.returncode:raise RuntimeError('FileService smoke failed:\n'+p.stderr)
    print(p.stdout.strip())
