package com.formatflow.ai.service;

import org.junit.jupiter.api.Test;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import static org.assertj.core.api.Assertions.assertThat;

class DocxStreamingTextExtractorTest {

    @Test
    void extractsParagraphsAndTableRowsWithoutLoadingXwpfModel() throws Exception {
        Path file = Files.createTempFile("ff-docx-stream-", ".docx");
        try {
            String xml = """
                    <?xml version="1.0" encoding="UTF-8"?>
                    <w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
                      <w:body>
                        <w:p><w:r><w:t>Network Configuration</w:t></w:r></w:p>
                        <w:tbl>
                          <w:tr>
                            <w:tc><w:p><w:r><w:t>Port</w:t></w:r></w:p></w:tc>
                            <w:tc><w:p><w:r><w:t>8090</w:t></w:r></w:p></w:tc>
                          </w:tr>
                        </w:tbl>
                      </w:body>
                    </w:document>
                    """;
            try (ZipOutputStream zip = new ZipOutputStream(Files.newOutputStream(file))) {
                zip.putNextEntry(new ZipEntry("word/document.xml"));
                zip.write(xml.getBytes(StandardCharsets.UTF_8));
                zip.closeEntry();
            }

            String content = new DocxStreamingTextExtractor().extract(file);
            assertThat(content).contains("Network Configuration");
            assertThat(content).contains("Port\t8090");
        } finally {
            Files.deleteIfExists(file);
        }
    }
}
