package com.formatflow.ai.service;

import com.formatflow.ai.model.FormatModels.*;
import jakarta.servlet.http.HttpSession;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

class FormattingServicePreserveTest {

    @Test
    void preserveModeNeverReplacesSourceText() {
        SessionKeyService keyService = mock(SessionKeyService.class);
        LlmOrchestrator orchestrator = mock(LlmOrchestrator.class);
        AdaptiveSemanticOrchestrator adaptive = mock(AdaptiveSemanticOrchestrator.class);
        ContentParser parser = new ContentParser();
        IconCatalog icons = new IconCatalog();
        DocumentRenderer renderer = new DocumentRenderer(icons);
        ContentDiffService diff = new ContentDiffService();
        FormattingService service = new FormattingService(
                keyService,
                parser,
                orchestrator,
                adaptive,
                new SemanticPresentationPolicy(),
                new DocumentAssemblyService(),
                renderer,
                diff
        );
        HttpSession session = mock(HttpSession.class);

        String source = "Network Configuration\n- Validate endpoint\nserver.port=8090";
        when(keyService.require(session)).thenReturn("session-key");
        when(adaptive.analyze(anyString(), anyList(), anyString(), anyString(), anyString(), anyString(), anyBoolean()))
                .thenReturn(new AdaptiveSemanticOrchestrator.AnalysisOutcome(
                        List.of(
                                new PlanItem("B00001", "HEADING", "NETWORK", "STRONG", "NONE"),
                                new PlanItem("B00002", "BULLET", "NONE", "NONE", "CHECK"),
                                new PlanItem("B00003", "CODE", "CONFIG", "NONE", "NONE")
                        ),
                        List.of(),
                        1,
                        1,
                        false,
                        List.of()
                ));

        FormatRequest request = new FormatRequest(
                source, "Technical Team", "Inform", "HTML", "FORMAT", "PRESERVE",
                "Short", "Professional Green", "RICH", "", false, true
        );

        FormatResult result = service.format(request, session);
        assertThat(result.finalContent()).isEqualTo(source);
        assertThat(result.stats().exactContentPreserved()).isTrue();
        verify(orchestrator, never()).enhance(anyString(), anyList(), anyString(), anyString(), anyString());
        verify(orchestrator, never()).summarize(anyString(), anyString(), anyString(), anyString(), anyString(), anyString());
    }
}
