package com.formatflow.ai.service;

import com.formatflow.ai.model.FormatModels.*;
import org.jsoup.Jsoup;
import org.jsoup.safety.Safelist;
import org.springframework.stereotype.Service;
import org.springframework.web.util.HtmlUtils;

import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

@Service
public class DocumentRenderer {

    private final IconCatalog iconCatalog;

    public DocumentRenderer(IconCatalog iconCatalog) {
        this.iconCatalog = iconCatalog;
    }

    public FormattedDocument compose(List<SourceBlock> blocks,
                                     List<PlanItem> plan,
                                     List<SemanticSection> semanticSections,
                                     String plainContent,
                                     String audience,
                                     String purpose,
                                     String outputFormat,
                                     String operation,
                                     boolean enhanced,
                                     String emailSubject) {
        Map<String, PlanItem> byId = plan.stream().collect(Collectors.toMap(PlanItem::id, Function.identity()));
        List<DocumentBlock> output = new ArrayList<>();
        String title = "";

        for (SourceBlock source : blocks) {
            if (source.blank()) {
                output.add(new DocumentBlock(source.id(), "", BlockType.SPACER, "NONE", "", "NONE", "NONE"));
                continue;
            }

            PlanItem p = byId.get(source.id());
            if (p == null) throw new IllegalStateException("Missing formatting metadata for " + source.id());

            BlockType type = safeType(p.type());
            if (source.codeLike()) type = BlockType.CODE;
            if (source.bulletLike() && type == BlockType.PARAGRAPH) type = BlockType.BULLET;

            String iconKey = iconCatalog.normalize(p.iconKey());
            String icon = iconCatalog.symbol(iconKey);
            String bullet = type == BlockType.BULLET && "NONE".equalsIgnoreCase(p.bulletStyle()) ? "CHECK" : p.bulletStyle();

            DocumentBlock block = new DocumentBlock(
                    source.id(), source.text(), type, iconKey, icon,
                    p.emphasis() == null ? "NONE" : p.emphasis(),
                    bullet == null ? "NONE" : bullet
            );
            output.add(block);
            if (title.isBlank() && type == BlockType.TITLE) title = source.text();
        }

        if (title.isBlank()) {
            title = output.stream()
                    .filter(b -> b.type() == BlockType.HEADING)
                    .map(DocumentBlock::text)
                    .findFirst()
                    .orElse("");
        }

        return new FormattedDocument(
                title,
                output,
                semanticSections == null ? List.of() : semanticSections,
                plainContent,
                audience,
                purpose,
                outputFormat,
                operation,
                enhanced,
                emailSubject
        );
    }

    public String previewHtml(FormattedDocument document) {
        String format = safeUpper(document.outputFormat());

        // The preview must reflect the selected destination. In particular,
        // Confluence preview uses the same portable structures that Copy uses,
        // and Markdown preview shows the exact Markdown text that will be copied.
        if ("CONFLUENCE".equals(format)) {
            return """
                    <section class="document-preview target-preview">
                      <div class="preview-meta"><span>CONFLUENCE</span><span>Copy-safe native layout</span></div>
                      <div class="confluence-preview">%s</div>
                    </section>
                    """.formatted(confluencePortableHtml(document));
        }

        if ("MARKDOWN".equals(format)) {
            return """
                    <section class="document-preview target-preview">
                      <div class="preview-meta"><span>MARKDOWN</span><span>Raw output</span></div>
                      <pre class="raw-markdown">%s</pre>
                    </section>
                    """.formatted(esc(markdown(document)));
        }

        String meta = """
                <div class="preview-meta">
                  <span>%s</span><span>%s</span><span>%s</span><span>%s</span>
                </div>
                """.formatted(
                esc(document.outputFormat()), esc(document.audience()), esc(document.purpose()), esc(document.operation())
        );

        String body = bodyFragment(document);
        if ("EMAIL".equals(format)) {
            String subject = document.emailSubject() == null || document.emailSubject().isBlank()
                    ? "<span class=\"subject-placeholder\">Subject not added</span>"
                    : esc(document.emailSubject());
            return """
                    <section class="email-preview">%s
                      <div class="email-header"><strong>Subject:</strong> %s</div>
                      <div class="email-body">%s</div>
                    </section>
                    """.formatted(meta, subject, body);
        }
        return "<section class=\"document-preview\">" + meta + body + "</section>";
    }

    /**
     * HTML written to the clipboard. This is intentionally target-specific and
     * is NOT the styled preview fragment.
     */
    public String copyHtml(FormattedDocument document) {
        return switch (safeUpper(document.outputFormat())) {
            case "CONFLUENCE" -> confluencePortableHtml(document);
            case "MARKDOWN" -> "";
            case "EMAIL" -> emailPortableHtml(document);
            case "HTML" -> bodyFragment(document);
            default -> portableRichHtml(document);
        };
    }

    /**
     * Plain-text clipboard fallback. Markdown gets actual Markdown, not the
     * original source string.
     */
    public String copyText(FormattedDocument document) {
        return switch (safeUpper(document.outputFormat())) {
            case "MARKDOWN" -> markdown(document);
            case "HTML" -> standaloneHtml(document, false);
            default -> document.plainContent() == null ? "" : document.plainContent();
        };
    }

    public String standaloneHtml(FormattedDocument document, boolean email) {
        String body = bodyFragment(document);
        String title = document.title() == null || document.title().isBlank() ? "FormatFlow AI" : document.title();
        String subject = document.emailSubject() == null ? "" : document.emailSubject();
        String emailHeader = email
                ? "<div class=\"email-export-head\"><strong>Subject:</strong> " + esc(subject) + "</div>"
                : "";

        return """
                <!doctype html>
                <html lang="en">
                <head>
                  <meta charset="UTF-8">
                  <meta name="viewport" content="width=device-width, initial-scale=1.0">
                  <title>%s</title>
                  <style>
                    :root{--g:#008542;--gd:#006b36;--soft:#eef8f2;--soft2:#f7fbf8;--border:#cfe4d7;--text:#1f2d25;--muted:#687a70}
                    *{box-sizing:border-box}body{margin:0;background:#f5f8f6;color:var(--text);font-family:Arial,Helvetica,sans-serif;line-height:1.55}
                    .page{max-width:1080px;margin:28px auto;background:#fff;border:1px solid #dde8e1;border-radius:14px;overflow:hidden;box-shadow:0 8px 30px rgba(0,80,40,.08)}
                    .top-accent{height:8px;background:var(--g)}.content{padding:34px 42px}.ff-title,.ff-heading,.semantic-title{color:var(--gd);font-weight:750}.ff-title{font-size:28px;margin:4px 0 22px}.ff-heading{font-size:18px;margin:22px 0 9px}
                    .ff-paragraph{margin:7px 0}.ff-bullet{display:flex;gap:9px;margin:7px 0;padding-left:5px}.ff-bullet .bullet{color:var(--g);font-weight:800;min-width:18px}
                    .ff-code{font-family:Consolas,monospace;background:#f3f6f4;border-left:4px solid var(--g);padding:8px 11px;white-space:pre-wrap;overflow-wrap:anywhere;margin:4px 0}
                    .ff-callout{background:var(--soft);border:1px solid var(--border);border-left:4px solid var(--g);padding:11px 13px;border-radius:7px;margin:10px 0}.ff-quote{border-left:3px solid #8ebaa1;margin:10px 0;padding:8px 12px;color:#50675a;font-style:italic}
                    .icon{display:inline-block;min-width:28px;margin-right:5px}.ff-spacer{height:10px}.strong{font-weight:700}.muted{color:var(--muted)}.highlight{background:#f3fbf6;border-radius:4px;padding:1px 3px}
                    .email-export-head{background:var(--soft);border-bottom:1px solid var(--border);padding:16px 42px;color:var(--gd)}
                    .semantic-section{margin:20px 0 26px}.semantic-title{font-size:18px;margin:0 0 12px;display:flex;align-items:center;gap:7px}.layout-badge{font-size:9px;color:var(--gd);background:var(--soft);border:1px solid var(--border);padding:3px 6px;border-radius:999px;margin-left:auto;text-transform:uppercase;letter-spacing:.04em}
                    .semantic-table{width:100%%;border-collapse:collapse;margin:8px 0}.semantic-table th{background:var(--gd);color:#fff;text-align:left;padding:9px 11px;font-size:12px}.semantic-table td{border:1px solid #dce8e1;padding:9px 11px;vertical-align:top;font-size:12px}.semantic-table tr:nth-child(even) td{background:#fbfdfc}
                    .flow{display:flex;align-items:center;gap:8px;flex-wrap:wrap;padding:10px 0}.flow-node{min-width:120px;max-width:210px;padding:12px 14px;background:#fff;border:1.5px solid var(--g);border-radius:10px;text-align:center;font-weight:700;color:var(--gd);box-shadow:0 3px 10px rgba(0,100,50,.06)}.flow-arrow{display:flex;flex-direction:column;align-items:center;color:var(--g);font-weight:800}.flow-label{font-size:9px;color:var(--muted);font-weight:500;max-width:120px;text-align:center}.flow-arrow-symbol{font-size:22px}
                    .timeline{border-left:3px solid var(--g);padding-left:17px;margin-left:8px}.timeline-item{position:relative;padding:2px 0 16px}.timeline-item:before{content:'';position:absolute;left:-24px;top:7px;width:11px;height:11px;border-radius:50%%;background:var(--g);border:2px solid #fff;box-shadow:0 0 0 1px var(--g)}
                    .cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:10px}.semantic-card{border:1px solid var(--border);border-radius:10px;padding:13px;background:var(--soft2)}.semantic-card .label{font-weight:750;color:var(--gd)}.semantic-card .value{margin-top:5px}.semantic-card .status{display:inline-block;margin-top:7px;background:#fff;border:1px solid var(--border);border-radius:999px;padding:3px 7px;font-size:10px;color:var(--gd)}
                    .checklist{display:grid;gap:7px}.check-item{display:flex;gap:9px;align-items:flex-start}.check{color:var(--g);font-weight:900;font-size:16px}.callout-grid{display:grid;gap:8px}.semantic-callout{background:var(--soft);border:1px solid var(--border);border-left:4px solid var(--g);padding:11px 13px;border-radius:8px}
                    @media(max-width:700px){.page{margin:0;border:0;border-radius:0}.content{padding:22px}.ff-title{font-size:23px}.flow{align-items:stretch}.flow-arrow{width:100%%}.flow-arrow-symbol{transform:rotate(90deg)}.semantic-table{font-size:11px}}
                  </style>
                </head>
                <body><main class="page"><div class="top-accent"></div>%s<div class="content">%s</div></main></body>
                </html>
                """.formatted(esc(title), emailHeader, body);
    }

    public String confluenceHtml(FormattedDocument document) {
        return confluencePortableHtml(document);
    }

    /**
     * Confluence Cloud copy/paste target. Confluence does not understand our
     * application CSS classes. Use only editor-friendly HTML elements whose
     * structure can survive clipboard sanitization: headings, paragraphs,
     * lists, tables, pre/code and blockquotes.
     */
    public String confluencePortableHtml(FormattedDocument document) {
        String html = hasSemantic(document)
                ? semanticPortableFragment(document, true)
                : portableBlocks(document.blocks());

        Safelist safe = Safelist.relaxed()
                .addTags("h1", "h2", "h3", "h4", "pre", "code", "blockquote",
                        "table", "thead", "tbody", "tr", "th", "td", "ul", "ol", "li",
                        "p", "strong", "em", "br")
                .preserveRelativeLinks(true);
        return Jsoup.clean(html, safe);
    }

    private String portableRichHtml(FormattedDocument document) {
        String html = hasSemantic(document)
                ? semanticPortableFragment(document, false)
                : portableBlocks(document.blocks());
        return Jsoup.clean(html, Safelist.relaxed()
                .addTags("h1", "h2", "h3", "h4", "pre", "code", "blockquote",
                        "table", "thead", "tbody", "tr", "th", "td", "ul", "ol", "li",
                        "p", "strong", "em", "br")
                .preserveRelativeLinks(true));
    }

    private String emailPortableHtml(FormattedDocument document) {
        String subject = document.emailSubject() == null ? "" : document.emailSubject();
        return "<p><strong>Subject:</strong> " + esc(subject) + "</p>"
                + portableRichHtml(document);
    }

    private String semanticPortableFragment(FormattedDocument document, boolean confluence) {
        Map<String, DocumentBlock> blocks = blockMap(document);
        StringBuilder html = new StringBuilder();

        for (SemanticSection section : document.semanticSections()) {
            SemanticLayoutType type = layout(section);
            String title = (type == SemanticLayoutType.TEXT || type == SemanticLayoutType.CODE_GROUP)
                    ? "" : semanticTitle(section);

            if (!title.isBlank()) {
                String symbol = iconCatalog.symbol(section.iconKey());
                html.append("<h2>")
                        .append(symbol.isBlank() ? "" : esc(symbol) + " ")
                        .append(esc(title))
                        .append("</h2>");
            }

            switch (type) {
                case TABLE, COMPARISON, STATUS, KPI -> html.append(portableTable(section));
                case WORKFLOW, ARCHITECTURE, HIERARCHY -> html.append(portableFlow(section));
                case TIMELINE -> html.append(portableTimeline(section));
                case CHECKLIST -> html.append(portableChecklist(section));
                case CALLOUT -> html.append(portableCallout(section));
                case TEXT, CODE_GROUP -> html.append(portableBlocks(referencedBlocks(section, blocks)));
            }
        }
        return html.toString();
    }

    private String portableTable(SemanticSection section) {
        if (safe(section.rows()).isEmpty() && !safe(section.items()).isEmpty()) {
            // defensive representation if a STATUS/KPI section reaches this renderer
            StringBuilder table = new StringBuilder("<table><thead><tr><th>Item</th><th>Details</th></tr></thead><tbody>");
            for (SemanticItem item : safe(section.items())) {
                String first = nonblank(item.label(), item.value(), item.status());
                String rest = remainingItem(item, first);
                table.append("<tr><td>").append(esc(first)).append("</td><td>").append(esc(rest)).append("</td></tr>");
            }
            return table.append("</tbody></table>").toString();
        }

        StringBuilder html = new StringBuilder("<table><thead><tr>");
        int maxCells = safe(section.rows()).stream().mapToInt(r -> safe(r.cells()).size()).max().orElse(2);
        List<String> columns = new ArrayList<>(safe(section.columns()));
        while (columns.size() < maxCells) columns.add(columns.isEmpty() ? "Item" : "Details");
        for (int i = 0; i < maxCells; i++) html.append("<th>").append(esc(columns.get(i))).append("</th>");
        html.append("</tr></thead><tbody>");
        for (SemanticRow row : safe(section.rows())) {
            html.append("<tr>");
            List<SemanticValue> cells = safe(row.cells());
            for (int i = 0; i < maxCells; i++) {
                html.append("<td>").append(i < cells.size() ? esc(cells.get(i).text()) : "").append("</td>");
            }
            html.append("</tr>");
        }
        return html.append("</tbody></table>").toString();
    }

    private String portableFlow(SemanticSection section) {
        List<SemanticNode> nodes = safe(section.nodes());
        if (nodes.isEmpty()) return "";
        StringBuilder html = new StringBuilder("<ol>");
        for (SemanticNode node : nodes) {
            String symbol = iconCatalog.symbol(node.iconKey());
            html.append("<li>")
                    .append(symbol.isBlank() ? "" : esc(symbol) + " ")
                    .append(esc(node.text()))
                    .append("</li>");
        }
        return html.append("</ol>").toString();
    }

    private String portableTimeline(SemanticSection section) {
        StringBuilder html = new StringBuilder("<ol>");
        for (SemanticItem item : safe(section.items())) {
            html.append("<li>").append(esc(joinItem(item))).append("</li>");
        }
        return html.append("</ol>").toString();
    }

    private String portableChecklist(SemanticSection section) {
        StringBuilder html = new StringBuilder("<ul>");
        for (SemanticItem item : safe(section.items())) {
            html.append("<li>✓ ").append(esc(joinItem(item))).append("</li>");
        }
        return html.append("</ul>").toString();
    }

    private String portableCallout(SemanticSection section) {
        StringBuilder html = new StringBuilder();
        for (SemanticItem item : safe(section.items())) {
            html.append("<blockquote>⚠ ").append(esc(joinItem(item))).append("</blockquote>");
        }
        return html.toString();
    }

    private String portableBlocks(List<DocumentBlock> blocks) {
        StringBuilder html = new StringBuilder();
        boolean listOpen = false;

        for (DocumentBlock block : blocks) {
            if (block.type() != BlockType.BULLET && listOpen) {
                html.append("</ul>");
                listOpen = false;
            }

            String icon = block.iconSymbol().isBlank() ? "" : esc(block.iconSymbol()) + " ";
            switch (block.type()) {
                case TITLE -> html.append("<h1>").append(icon).append(esc(block.text())).append("</h1>");
                case HEADING -> html.append("<h2>").append(icon).append(esc(block.text())).append("</h2>");
                case BULLET -> {
                    if (!listOpen) {
                        html.append("<ul>");
                        listOpen = true;
                    }
                    html.append("<li>✓ ").append(esc(stripBullet(block.text()))).append("</li>");
                }
                case CODE -> html.append("<pre><code>").append(esc(block.text())).append("</code></pre>");
                case CALLOUT, QUOTE -> html.append("<blockquote>").append(icon).append(esc(block.text())).append("</blockquote>");
                case SPACER -> html.append("<br>");
                default -> html.append("<p>").append(esc(block.text())).append("</p>");
            }
        }

        if (listOpen) html.append("</ul>");
        return html.toString();
    }

    public String markdown(FormattedDocument document) {
        if (!hasSemantic(document)) return markdownBlocks(document.blocks());
        Map<String, DocumentBlock> blocks = blockMap(document);
        StringBuilder out = new StringBuilder();
        for (SemanticSection section : document.semanticSections()) {
            SemanticLayoutType sectionLayout = layout(section);
            String title = (sectionLayout == SemanticLayoutType.TEXT || sectionLayout == SemanticLayoutType.CODE_GROUP) ? "" : semanticTitle(section);
            if (!title.isBlank()) {
                String symbol = iconCatalog.symbol(section.iconKey());
                out.append("## ").append(symbol.isBlank() ? "" : symbol + " ").append(title).append("\n\n");
            }
            switch (sectionLayout) {
                case TABLE, COMPARISON -> appendMarkdownTable(out, section);
                case WORKFLOW, ARCHITECTURE, HIERARCHY -> appendMarkdownFlow(out, section);
                case TIMELINE -> {
                    for (SemanticItem item : safe(section.items())) out.append("- ").append(joinItem(item)).append("\n");
                    out.append("\n");
                }
                case STATUS, KPI -> {
                    for (SemanticItem item : safe(section.items())) out.append("- **").append(nonblank(item.label(), item.value(), item.status())).append("**")
                            .append(restItem(item)).append("\n");
                    out.append("\n");
                }
                case CHECKLIST -> {
                    for (SemanticItem item : safe(section.items())) out.append("- [x] ").append(joinItem(item)).append("\n");
                    out.append("\n");
                }
                case CALLOUT -> {
                    for (SemanticItem item : safe(section.items())) out.append("> ").append(joinItem(item)).append("\n");
                    out.append("\n");
                }
                default -> appendMarkdownReferencedBlocks(out, section, blocks);
            }
        }
        return out.toString().stripTrailing() + "\n";
    }

    private String bodyFragment(FormattedDocument document) {
        return hasSemantic(document) ? semanticFragment(document, false) : blockFragment(document.blocks());
    }

    private boolean hasSemantic(FormattedDocument document) {
        return document.semanticSections() != null && !document.semanticSections().isEmpty();
    }

    private String semanticFragment(FormattedDocument document, boolean confluence) {
        Map<String, DocumentBlock> blocks = blockMap(document);
        StringBuilder html = new StringBuilder();
        for (SemanticSection section : document.semanticSections()) {
            SemanticLayoutType layout = layout(section);
            html.append("<section class=\"semantic-section\" data-layout=\"").append(layout.name()).append("\">");
            String title = (layout == SemanticLayoutType.TEXT || layout == SemanticLayoutType.CODE_GROUP) ? "" : semanticTitle(section);
            if (!title.isBlank()) {
                String symbol = iconCatalog.symbol(section.iconKey());
                html.append("<div class=\"semantic-title\">")
                        .append(symbol.isBlank() ? "" : "<span>" + esc(symbol) + "</span>")
                        .append("<span>").append(esc(title)).append("</span>");
                if (!confluence) html.append("<span class=\"layout-badge\">").append(layout.name()).append("</span>");
                html.append("</div>");
            }

            switch (layout) {
                case TABLE, COMPARISON -> html.append(tableHtml(section));
                case WORKFLOW, ARCHITECTURE, HIERARCHY -> html.append(flowHtml(section));
                case TIMELINE -> html.append(timelineHtml(section));
                case STATUS, KPI -> html.append(cardsHtml(section));
                case CHECKLIST -> html.append(checklistHtml(section));
                case CALLOUT -> html.append(calloutHtml(section));
                case TEXT, CODE_GROUP -> html.append(blockFragment(referencedBlocks(section, blocks)));
            }
            html.append("</section>");
        }
        return html.toString();
    }

    private String tableHtml(SemanticSection section) {
        StringBuilder html = new StringBuilder("<table class=\"semantic-table\"><thead><tr>");
        int maxCells = safe(section.rows()).stream().mapToInt(r -> safe(r.cells()).size()).max().orElse(2);
        List<String> columns = new ArrayList<>(safe(section.columns()));
        while (columns.size() < maxCells) columns.add(columns.size() == 0 ? "Item" : "Details");
        for (int i = 0; i < maxCells; i++) html.append("<th>").append(esc(columns.get(i))).append("</th>");
        html.append("</tr></thead><tbody>");
        for (SemanticRow row : safe(section.rows())) {
            html.append("<tr>");
            List<SemanticValue> cells = safe(row.cells());
            for (int i = 0; i < maxCells; i++) {
                String text = i < cells.size() ? cells.get(i).text() : "";
                html.append("<td>").append(esc(text)).append("</td>");
            }
            html.append("</tr>");
        }
        return html.append("</tbody></table>").toString();
    }

    private String flowHtml(SemanticSection section) {
        List<SemanticNode> nodes = safe(section.nodes());
        Map<String, SemanticEdge> edgeFrom = new LinkedHashMap<>();
        for (SemanticEdge edge : safe(section.edges())) edgeFrom.putIfAbsent(edge.from(), edge);
        StringBuilder html = new StringBuilder("<div class=\"flow\">");
        for (int i = 0; i < nodes.size(); i++) {
            SemanticNode node = nodes.get(i);
            String symbol = iconCatalog.symbol(node.iconKey());
            html.append("<div class=\"flow-node\">")
                    .append(symbol.isBlank() ? "" : esc(symbol) + " ")
                    .append(esc(node.text())).append("</div>");
            if (i < nodes.size() - 1) {
                SemanticEdge edge = edgeFrom.get(node.id());
                String label = edge == null ? "" : edge.label();
                html.append("<div class=\"flow-arrow\">")
                        .append(label == null || label.isBlank() ? "" : "<span class=\"flow-label\">" + esc(label) + "</span>")
                        .append("<span class=\"flow-arrow-symbol\">→</span></div>");
            }
        }
        return html.append("</div>").toString();
    }

    private String timelineHtml(SemanticSection section) {
        StringBuilder html = new StringBuilder("<div class=\"timeline\">");
        for (SemanticItem item : safe(section.items())) {
            html.append("<div class=\"timeline-item\"><strong>").append(esc(nonblank(item.value(), item.status(), item.label())))
                    .append("</strong>");
            String rest = remainingItem(item, nonblank(item.value(), item.status(), item.label()));
            if (!rest.isBlank()) html.append("<div>").append(esc(rest)).append("</div>");
            html.append("</div>");
        }
        return html.append("</div>").toString();
    }

    private String cardsHtml(SemanticSection section) {
        StringBuilder html = new StringBuilder("<div class=\"cards\">");
        for (SemanticItem item : safe(section.items())) {
            String symbol = iconCatalog.symbol(item.iconKey());
            html.append("<div class=\"semantic-card\">");
            String label = nonblank(item.label(), item.value(), item.status());
            html.append("<div class=\"label\">").append(symbol.isBlank() ? "" : esc(symbol) + " ").append(esc(label)).append("</div>");
            if (!item.value().isBlank() && !item.value().equals(label)) html.append("<div class=\"value\">").append(esc(item.value())).append("</div>");
            if (!item.status().isBlank() && !item.status().equals(label)) html.append("<div class=\"status\">").append(esc(item.status())).append("</div>");
            html.append("</div>");
        }
        return html.append("</div>").toString();
    }

    private String checklistHtml(SemanticSection section) {
        StringBuilder html = new StringBuilder("<div class=\"checklist\">");
        for (SemanticItem item : safe(section.items())) {
            html.append("<div class=\"check-item\"><span class=\"check\">✓</span><span>")
                    .append(esc(joinItem(item))).append("</span></div>");
        }
        return html.append("</div>").toString();
    }

    private String calloutHtml(SemanticSection section) {
        StringBuilder html = new StringBuilder("<div class=\"callout-grid\">");
        for (SemanticItem item : safe(section.items())) {
            String symbol = iconCatalog.symbol(item.iconKey());
            html.append("<div class=\"semantic-callout\">")
                    .append(symbol.isBlank() ? "" : esc(symbol) + " ")
                    .append(esc(joinItem(item))).append("</div>");
        }
        return html.append("</div>").toString();
    }

    private String blockFragment(List<DocumentBlock> blocks) {
        StringBuilder html = new StringBuilder();
        for (DocumentBlock block : blocks) {
            String emphasis = switch (safeUpper(block.emphasis())) {
                case "STRONG" -> " strong";
                case "MUTED" -> " muted";
                case "HIGHLIGHT" -> " highlight";
                default -> "";
            };
            String icon = block.iconSymbol().isBlank() ? "" : "<span class=\"icon\">" + esc(block.iconSymbol()) + "</span>";
            switch (block.type()) {
                case TITLE -> html.append("<div class=\"ff-title").append(emphasis).append("\">").append(icon).append(esc(block.text())).append("</div>");
                case HEADING -> html.append("<div class=\"ff-heading").append(emphasis).append("\">").append(icon).append(esc(block.text())).append("</div>");
                case BULLET -> html.append("<div class=\"ff-bullet").append(emphasis).append("\"><span class=\"bullet\">")
                        .append(bulletSymbol(block.bulletStyle())).append("</span><span>").append(esc(stripBullet(block.text()))).append("</span></div>");
                case CODE -> html.append("<div class=\"ff-code").append(emphasis).append("\">").append(esc(block.text())).append("</div>");
                case CALLOUT -> html.append("<div class=\"ff-callout").append(emphasis).append("\">").append(icon).append(esc(block.text())).append("</div>");
                case QUOTE -> html.append("<div class=\"ff-quote").append(emphasis).append("\">").append(esc(block.text())).append("</div>");
                case SPACER -> html.append("<div class=\"ff-spacer\"></div>");
                default -> html.append("<div class=\"ff-paragraph").append(emphasis).append("\">").append(esc(block.text())).append("</div>");
            }
        }
        return html.toString();
    }

    private String markdownBlocks(List<DocumentBlock> blocks) {
        StringBuilder out = new StringBuilder();
        for (DocumentBlock block : blocks) {
            String icon = block.iconSymbol().isBlank() ? "" : block.iconSymbol() + " ";
            switch (block.type()) {
                case TITLE -> out.append("# ").append(icon).append(block.text()).append("\n\n");
                case HEADING -> out.append("## ").append(icon).append(block.text()).append("\n\n");
                case BULLET -> out.append("- ✓ ").append(stripBullet(block.text())).append("\n");
                case CODE -> out.append("```\n").append(block.text()).append("\n```\n\n");
                case CALLOUT, QUOTE -> out.append("> ").append(block.text()).append("\n\n");
                case SPACER -> out.append("\n");
                default -> out.append(block.text()).append("\n\n");
            }
        }
        return out.toString().stripTrailing() + "\n";
    }

    private void appendMarkdownReferencedBlocks(StringBuilder out, SemanticSection section, Map<String, DocumentBlock> blocks) {
        out.append(markdownBlocks(referencedBlocks(section, blocks))).append("\n");
    }

    private void appendMarkdownTable(StringBuilder out, SemanticSection section) {
        int count = safe(section.rows()).stream().mapToInt(r -> safe(r.cells()).size()).max().orElse(2);
        List<String> columns = new ArrayList<>(safe(section.columns()));
        while (columns.size() < count) columns.add(columns.isEmpty() ? "Item" : "Details");
        out.append("| ").append(String.join(" | ", columns.subList(0, count))).append(" |\n");
        out.append("|").append(" --- |".repeat(count)).append("\n");
        for (SemanticRow row : safe(section.rows())) {
            List<String> cells = safe(row.cells()).stream().map(c -> c.text().replace("|", "\\|")).toList();
            List<String> padded = new ArrayList<>(cells);
            while (padded.size() < count) padded.add("");
            out.append("| ").append(String.join(" | ", padded.subList(0, count))).append(" |\n");
        }
        out.append("\n");
    }

    private void appendMarkdownFlow(StringBuilder out, SemanticSection section) {
        List<SemanticNode> nodes = safe(section.nodes());
        for (int i = 0; i < nodes.size(); i++) {
            if (i > 0) out.append(" → ");
            out.append(nodes.get(i).text());
        }
        out.append("\n\n");
    }

    private Map<String, DocumentBlock> blockMap(FormattedDocument document) {
        return document.blocks().stream().collect(Collectors.toMap(DocumentBlock::id, Function.identity(), (a, b) -> a, LinkedHashMap::new));
    }

    private List<DocumentBlock> referencedBlocks(SemanticSection section, Map<String, DocumentBlock> blocks) {
        List<DocumentBlock> result = new ArrayList<>();
        for (String id : safe(section.sourceIds())) {
            DocumentBlock block = blocks.get(id);
            if (block != null) result.add(block);
        }
        return result;
    }

    private String semanticTitle(SemanticSection section) {
        return section.title() == null ? "" : section.title();
    }

    private SemanticLayoutType layout(SemanticSection section) {
        try { return SemanticLayoutType.valueOf(safeUpper(section.layoutType())); }
        catch (Exception ex) { return SemanticLayoutType.TEXT; }
    }

    private String joinItem(SemanticItem item) {
        LinkedHashSet<String> parts = new LinkedHashSet<>();
        if (item.label() != null && !item.label().isBlank()) parts.add(item.label());
        if (item.value() != null && !item.value().isBlank()) parts.add(item.value());
        if (item.status() != null && !item.status().isBlank()) parts.add(item.status());
        return String.join(" — ", parts);
    }

    private String restItem(SemanticItem item) {
        String first = nonblank(item.label(), item.value(), item.status());
        return remainingItem(item, first);
    }

    private String remainingItem(SemanticItem item, String first) {
        LinkedHashSet<String> parts = new LinkedHashSet<>();
        if (item.label() != null && !item.label().isBlank() && !item.label().equals(first)) parts.add(item.label());
        if (item.value() != null && !item.value().isBlank() && !item.value().equals(first)) parts.add(item.value());
        if (item.status() != null && !item.status().isBlank() && !item.status().equals(first)) parts.add(item.status());
        return String.join(" — ", parts);
    }

    private String nonblank(String... values) {
        for (String value : values) if (value != null && !value.isBlank()) return value;
        return "";
    }

    private String bulletSymbol(String style) {
        return switch (safeUpper(style)) {
            case "ARROW" -> "→";
            case "DOT" -> "•";
            default -> "✓";
        };
    }

    private String stripBullet(String text) {
        if (text == null) return "";
        return text.replaceFirst("^\\s*(?:[-*•▪◦]|\\d+[.)])\\s+", "");
    }

    private BlockType safeType(String value) {
        try { return BlockType.valueOf(safeUpper(value)); }
        catch (Exception ex) { return BlockType.PARAGRAPH; }
    }

    private String safeUpper(String value) {
        return value == null ? "NONE" : value.trim().toUpperCase(Locale.ROOT);
    }

    private <T> List<T> safe(List<T> values) {
        return values == null ? List.of() : values;
    }

    private String esc(String value) {
        return HtmlUtils.htmlEscape(value == null ? "" : value);
    }
}
