package com.formatflow.ai.service;

import com.formatflow.ai.model.ImportModels.ImportResult;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.springframework.stereotype.Service;

import java.net.InetAddress;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.LinkedHashSet;
import java.util.Set;

@Service
public class UrlImportService {

    private static final int MAX_REDIRECTS = 3;
    private static final int MAX_BYTES = 5 * 1024 * 1024;

    private final HttpClient httpClient;
    private final ContentDiffService contentDiffService;

    public UrlImportService(HttpClient httpClient, ContentDiffService contentDiffService) {
        this.httpClient = httpClient;
        this.contentDiffService = contentDiffService;
    }

    public ImportResult importUrl(String url) {
        try {
            URI uri = URI.create(url.trim());
            byte[] bytes = null;
            String contentType = "";
            URI current = uri;

            for (int redirect = 0; redirect <= MAX_REDIRECTS; redirect++) {
                validatePublicHttpUri(current);

                HttpRequest request = HttpRequest.newBuilder(current)
                        .timeout(Duration.ofSeconds(25))
                        .header("User-Agent", "FormatFlowAI/1.0")
                        .header("Accept", "text/html,text/plain,application/xhtml+xml,*/*;q=0.5")
                        .GET()
                        .build();

                HttpResponse<byte[]> response = httpClient.send(request, HttpResponse.BodyHandlers.ofByteArray());

                if (response.statusCode() >= 300 && response.statusCode() < 400) {
                    String location = response.headers().firstValue("Location")
                            .orElseThrow(() -> new IllegalArgumentException("Redirect did not contain a Location header."));
                    current = current.resolve(location);
                    continue;
                }

                if (response.statusCode() < 200 || response.statusCode() >= 300) {
                    throw new IllegalArgumentException("URL returned HTTP " + response.statusCode() + ".");
                }

                bytes = response.body();
                if (bytes.length > MAX_BYTES) {
                    throw new IllegalArgumentException("URL content is larger than 5 MB.");
                }
                contentType = response.headers().firstValue("Content-Type").orElse("");
                break;
            }

            if (bytes == null) {
                throw new IllegalArgumentException("Too many redirects.");
            }

            String raw = new String(bytes, java.nio.charset.StandardCharsets.UTF_8);
            String content;

            if (contentType.contains("html") || raw.stripLeading().startsWith("<")) {
                content = extractHtml(raw, current.toString());
            } else {
                content = raw;
            }

            return new ImportResult(
                    current.toString(),
                    content,
                    contentDiffService.wordCount(content),
                    content.length()
            );
        } catch (IllegalArgumentException ex) {
            throw ex;
        } catch (Exception ex) {
            throw new IllegalArgumentException("Unable to import URL: " + ex.getMessage(), ex);
        }
    }

    private String extractHtml(String html, String baseUri) {
        Document doc = Jsoup.parse(html, baseUri);
        doc.select("script,style,noscript,nav,footer,aside,form,iframe,svg").remove();

        Set<String> blocks = new LinkedHashSet<>();
        for (Element element : doc.select("h1,h2,h3,h4,h5,h6,p,li,pre,blockquote,table")) {
            if (hasSelectedAncestor(element)) {
                continue;
            }
            String text = element.wholeText().trim();
            if (!text.isBlank()) {
                blocks.add(text);
            }
        }

        if (blocks.isEmpty() && doc.body() != null) {
            return doc.body().wholeText().trim();
        }
        return String.join("\n\n", blocks);
    }

    private boolean hasSelectedAncestor(Element element) {
        Element parent = element.parent();
        while (parent != null && !"body".equalsIgnoreCase(parent.tagName())) {
            String tag = parent.tagName();
            if (tag.matches("h[1-6]|p|li|pre|blockquote|table")) {
                return true;
            }
            parent = parent.parent();
        }
        return false;
    }

    private void validatePublicHttpUri(URI uri) throws Exception {
        String scheme = uri.getScheme();
        if (!"http".equalsIgnoreCase(scheme) && !"https".equalsIgnoreCase(scheme)) {
            throw new IllegalArgumentException("Only HTTP and HTTPS URLs are supported.");
        }

        String host = uri.getHost();
        if (host == null || host.isBlank()) {
            throw new IllegalArgumentException("URL host is missing.");
        }

        for (InetAddress address : InetAddress.getAllByName(host)) {
            if (address.isAnyLocalAddress()
                    || address.isLoopbackAddress()
                    || address.isLinkLocalAddress()
                    || address.isSiteLocalAddress()
                    || address.isMulticastAddress()) {
                throw new IllegalArgumentException("Private/local network URLs are blocked by default.");
            }
        }
    }
}
