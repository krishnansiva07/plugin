package com.formatflow.ai.service;

import org.springframework.stereotype.Component;

import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamConstants;
import javax.xml.stream.XMLStreamReader;
import java.io.InputStream;
import java.nio.file.Path;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/**
 * Low-memory DOCX body-text extractor.
 *
 * DOCX is a ZIP container. Instead of loading the complete package into
 * XWPFDocument, this extractor streams word/document.xml with StAX. That avoids
 * a second large in-memory Office object model for text-only formatting imports.
 */
@Component
public class DocxStreamingTextExtractor {

    public String extract(Path path) throws Exception {
        try (ZipFile zip = new ZipFile(path.toFile())) {
            ZipEntry document = zip.getEntry("word/document.xml");
            if (document == null) {
                throw new IllegalArgumentException("DOCX does not contain word/document.xml.");
            }
            try (InputStream input = zip.getInputStream(document)) {
                return parseDocumentXml(input);
            }
        }
    }

    private String parseDocumentXml(InputStream input) throws Exception {
        XMLInputFactory factory = XMLInputFactory.newFactory();
        trySet(factory, XMLInputFactory.SUPPORT_DTD, false);
        trySet(factory, "javax.xml.stream.isSupportingExternalEntities", false);
        trySet(factory, XMLInputFactory.IS_COALESCING, true);

        XMLStreamReader reader = factory.createXMLStreamReader(input);
        StringBuilder out = new StringBuilder();
        StringBuilder paragraph = new StringBuilder();
        StringBuilder cell = new StringBuilder();
        StringBuilder row = new StringBuilder();

        boolean inText = false;
        boolean inCell = false;

        try {
            while (reader.hasNext()) {
                int event = reader.next();
                if (event == XMLStreamConstants.START_ELEMENT) {
                    String local = reader.getLocalName();
                    switch (local) {
                        case "t" -> inText = true;
                        case "tc" -> {
                            inCell = true;
                            cell.setLength(0);
                        }
                        case "tr" -> row.setLength(0);
                        case "tab" -> paragraph.append('\t');
                        case "br", "cr" -> paragraph.append('\n');
                        default -> { }
                    }
                } else if (event == XMLStreamConstants.CHARACTERS || event == XMLStreamConstants.CDATA) {
                    if (inText) paragraph.append(reader.getText());
                } else if (event == XMLStreamConstants.END_ELEMENT) {
                    String local = reader.getLocalName();
                    switch (local) {
                        case "t" -> inText = false;
                        case "p" -> {
                            String value = paragraph.toString().trim();
                            if (!value.isBlank()) {
                                if (inCell) {
                                    if (!cell.isEmpty()) cell.append(' ');
                                    cell.append(value);
                                } else {
                                    appendBlock(out, value);
                                }
                            }
                            paragraph.setLength(0);
                        }
                        case "tc" -> {
                            if (!row.isEmpty()) row.append('\t');
                            row.append(cell.toString().trim());
                            cell.setLength(0);
                            inCell = false;
                        }
                        case "tr" -> {
                            String value = row.toString().trim();
                            if (!value.isBlank()) appendBlock(out, value);
                            row.setLength(0);
                        }
                        default -> { }
                    }
                }
            }
        } finally {
            reader.close();
        }
        return out.toString();
    }

    private void appendBlock(StringBuilder out, String value) {
        if (value == null || value.isBlank()) return;
        if (!out.isEmpty()) out.append("\n\n");
        out.append(value);
    }

    private void trySet(XMLInputFactory factory, String key, Object value) {
        try {
            factory.setProperty(key, value);
        } catch (IllegalArgumentException ignored) {
            // Some StAX implementations do not expose every optional property.
        }
    }
}
