package com.formatflow.ai.model;

import jakarta.validation.constraints.NotBlank;

public final class ImportModels {

    private ImportModels() {}

    public record UrlImportRequest(@NotBlank String url) {}

    public record ImportResult(
            String source,
            String content,
            int words,
            int characters
    ) {}
}
