package com.formatflow.ai.web;

import com.formatflow.ai.model.ImportModels.ImportResult;
import com.formatflow.ai.model.ImportModels.UrlImportRequest;
import com.formatflow.ai.service.DocumentExtractionService;
import com.formatflow.ai.service.UrlImportService;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@RestController
@RequestMapping("/api/import")
public class ImportController {

    private final UrlImportService urlImportService;
    private final DocumentExtractionService documentExtractionService;

    public ImportController(UrlImportService urlImportService,
                            DocumentExtractionService documentExtractionService) {
        this.urlImportService = urlImportService;
        this.documentExtractionService = documentExtractionService;
    }

    @PostMapping("/url")
    public ImportResult importUrl(@Valid @RequestBody UrlImportRequest request) {
        return urlImportService.importUrl(request.url());
    }

    @PostMapping("/file")
    public ImportResult importFile(@RequestParam("file") MultipartFile file) {
        return documentExtractionService.extract(file);
    }
}
