package com.formatflow.ai.service;

import com.formatflow.ai.model.FormatModels.*;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class FormattingService {

    private final SessionKeyService sessionKeyService;
    private final ContentParser contentParser;
    private final LlmOrchestrator llmOrchestrator;
    private final AdaptiveSemanticOrchestrator adaptiveSemanticOrchestrator;
    private final SemanticPresentationPolicy semanticPresentationPolicy;
    private final DocumentAssemblyService documentAssemblyService;
    private final DocumentRenderer renderer;
    private final ContentDiffService diffService;

    public FormattingService(SessionKeyService sessionKeyService,
                             ContentParser contentParser,
                             LlmOrchestrator llmOrchestrator,
                             AdaptiveSemanticOrchestrator adaptiveSemanticOrchestrator,
                             SemanticPresentationPolicy semanticPresentationPolicy,
                             DocumentAssemblyService documentAssemblyService,
                             DocumentRenderer renderer,
                             ContentDiffService diffService) {
        this.sessionKeyService = sessionKeyService;
        this.contentParser = contentParser;
        this.llmOrchestrator = llmOrchestrator;
        this.adaptiveSemanticOrchestrator = adaptiveSemanticOrchestrator;
        this.semanticPresentationPolicy = semanticPresentationPolicy;
        this.documentAssemblyService = documentAssemblyService;
        this.renderer = renderer;
        this.diffService = diffService;
    }

    public FormatResult format(FormatRequest request, HttpSession session) {
        String apiKey = sessionKeyService.require(session);
        Operation operation = parseOperation(request.operation());
        ContentMode mode = parseMode(request.mode());

        String original = request.content();
        String working = original;
        int llmCalls = 0;
        int contentChunks = 0;
        boolean enhanced = false;

        // Content-changing activities stay explicit and separate from formatting.
        if (operation == Operation.SUMMARIZE) {
            LlmOrchestrator.SummaryOutcome summary = llmOrchestrator.summarize(
                    apiKey,
                    original,
                    request.audience(),
                    request.purpose(),
                    request.summaryLength(),
                    request.format()
            );
            working = summary.content();
            llmCalls += summary.llmCalls();
            contentChunks = summary.chunks();
            enhanced = true;
        } else if (mode == ContentMode.ENHANCE) {
            List<SourceBlock> source = contentParser.parse(original);
            LlmOrchestrator.EnhancementOutcome outcome = llmOrchestrator.enhance(
                    apiKey,
                    source,
                    request.audience(),
                    request.purpose(),
                    request.format()
            );
            working = joinBlocks(outcome.blocks());
            llmCalls += outcome.llmCalls();
            contentChunks = outcome.chunks();
            enhanced = true;
        }

        List<SourceBlock> formattedSource = contentParser.parse(working);

        /*
         * ONE adaptive LLM pass per bounded chunk returns:
         *   1) line-level formatting metadata, and
         *   2) semantic layout metadata.
         *
         * Large documents do not get resent in full. Each chunk sees only its own
         * source plus a short previous-chunk continuity digest. Java then validates
         * exact excerpts and assembles every chunk into one final document.
         */
        AdaptiveSemanticOrchestrator.AnalysisOutcome analysis = adaptiveSemanticOrchestrator.analyze(
                apiKey,
                formattedSource,
                request.audience(),
                request.purpose(),
                request.format(),
                request.iconLevel(),
                request.smartLayout()
        );
        llmCalls += analysis.llmCalls();

        List<SemanticSection> semanticSections = List.of();
        if (request.smartLayout()) {
            semanticSections = semanticPresentationPolicy.normalize(
                    analysis.semanticSections(),
                    request.format()
            );
            semanticSections = documentAssemblyService.assemble(
                    semanticSections,
                    formattedSource
            );
        }

        List<String> detectedLayouts = semanticSections.stream()
                .map(SemanticSection::layoutType)
                .filter(type -> type != null && !"TEXT".equalsIgnoreCase(type))
                .distinct()
                .toList();

        String subject = request.emailSubject() == null ? "" : request.emailSubject().trim();
        if ("EMAIL".equalsIgnoreCase(request.format())
                && request.generateEmailSubject()
                && subject.isBlank()) {
            subject = llmOrchestrator.generateEmailSubject(
                    apiKey,
                    working,
                    request.audience(),
                    request.purpose()
            );
            llmCalls++;
        }

        FormattedDocument document = renderer.compose(
                formattedSource,
                analysis.plan(),
                semanticSections,
                working,
                request.audience(),
                request.purpose() == null || request.purpose().isBlank() ? "General" : request.purpose(),
                request.format(),
                operation.name(),
                enhanced,
                subject
        );

        ContentStats stats = diffService.compare(original, working);
        int maxChunks = Math.max(analysis.chunks(), contentChunks);
        String activity = operation == Operation.SUMMARIZE
                ? "Summarize + Adaptive Semantic Format"
                : (enhanced ? "Enhance + Adaptive Semantic Format" : "Adaptive Semantic Format");

        ProcessingInfo processing = new ProcessingInfo(
                formattedSource.size(),
                llmCalls,
                analysis.chunks(),
                maxChunks > 1,
                activity,
                semanticSections.size(),
                detectedLayouts,
                analysis.fallbackUsed()
        );

        return new FormatResult(
                working,
                renderer.previewHtml(document),
                renderer.copyHtml(document),
                renderer.copyText(document),
                stats,
                document,
                processing
        );
    }

    private String joinBlocks(List<SourceBlock> blocks) {
        StringBuilder out = new StringBuilder();
        for (int i = 0; i < blocks.size(); i++) {
            if (i > 0) out.append('\n');
            out.append(blocks.get(i).text());
        }
        return out.toString();
    }

    private Operation parseOperation(String value) {
        try {
            return Operation.valueOf(value.trim().toUpperCase());
        } catch (Exception ex) {
            throw new IllegalArgumentException("Unsupported operation: " + value);
        }
    }

    private ContentMode parseMode(String value) {
        try {
            return ContentMode.valueOf(value.trim().toUpperCase());
        } catch (Exception ex) {
            throw new IllegalArgumentException("Unsupported content mode: " + value);
        }
    }
}
