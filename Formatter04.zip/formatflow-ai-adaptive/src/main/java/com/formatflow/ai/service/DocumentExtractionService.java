package com.formatflow.ai.service;

import com.formatflow.ai.model.ImportModels.ImportResult;
import org.apache.pdfbox.Loader;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import org.apache.poi.xslf.usermodel.XMLSlideShow;
import org.apache.poi.xslf.usermodel.XSLFShape;
import org.apache.poi.xslf.usermodel.XSLFTextShape;
import org.jsoup.Jsoup;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Locale;

@Service
public class DocumentExtractionService {

    private final ContentDiffService contentDiffService;
    private final DocxStreamingTextExtractor docxStreamingTextExtractor;
    private final long maxUploadBytes;

    public DocumentExtractionService(ContentDiffService contentDiffService,
                                     DocxStreamingTextExtractor docxStreamingTextExtractor,
                                     @Value("${formatflow.upload.max-bytes:104857600}") long maxUploadBytes) {
        this.contentDiffService = contentDiffService;
        this.docxStreamingTextExtractor = docxStreamingTextExtractor;
        this.maxUploadBytes = maxUploadBytes;
    }

    public ImportResult extract(MultipartFile file) {
        if (file == null || file.isEmpty()) {
            throw new IllegalArgumentException("Select a file first.");
        }
        if (file.getSize() > maxUploadBytes) {
            throw new IllegalArgumentException("File is larger than the configured upload limit of "
                    + (maxUploadBytes / 1024 / 1024) + " MB.");
        }

        String name = file.getOriginalFilename() == null ? "upload" : file.getOriginalFilename();
        String extension = extension(name);
        Path temp = null;

        try {
            // Do not call file.getBytes() for large Office/PDF files. That doubles memory
            // pressure before POI/PDFBox even starts parsing.
            temp = Files.createTempFile("formatflow-upload-", "." + (extension.isBlank() ? "bin" : extension));
            file.transferTo(temp);

            String content = switch (extension) {
                case "txt", "md", "csv", "json", "xml", "properties", "java" ->
                        Files.readString(temp, StandardCharsets.UTF_8);
                case "html", "htm" ->
                        Jsoup.parse(temp.toFile(), StandardCharsets.UTF_8.name()).wholeText();
                case "docx" -> docxStreamingTextExtractor.extract(temp);
                case "pdf" -> extractPdf(temp);
                case "pptx" -> extractPptx(temp);
                default -> throw new IllegalArgumentException(
                        "Unsupported file type. Supported: TXT, MD, HTML, DOCX, PDF, PPTX, JSON, XML, properties and Java."
                );
            };

            return new ImportResult(
                    name,
                    content,
                    contentDiffService.wordCount(content),
                    content.length()
            );
        } catch (IllegalArgumentException ex) {
            throw ex;
        } catch (Exception ex) {
            throw new IllegalArgumentException("Unable to read " + name + ": " + safeMessage(ex), ex);
        } finally {
            if (temp != null) {
                try { Files.deleteIfExists(temp); } catch (Exception ignored) {}
            }
        }
    }

    private String extractPdf(Path path) throws Exception {
        try (PDDocument doc = Loader.loadPDF(path.toFile())) {
            return new PDFTextStripper().getText(doc).trim();
        }
    }

    private String extractPptx(Path path) throws Exception {
        StringBuilder out = new StringBuilder();
        try (InputStream in = Files.newInputStream(path);
             XMLSlideShow ppt = new XMLSlideShow(in)) {
            for (var slide : ppt.getSlides()) {
                for (XSLFShape shape : slide.getShapes()) {
                    if (shape instanceof XSLFTextShape textShape) {
                        appendBlock(out, textShape.getText());
                    }
                }
            }
        }
        return out.toString();
    }

    private void appendBlock(StringBuilder out, String value) {
        if (value == null || value.isBlank()) return;
        if (!out.isEmpty()) out.append("\n\n");
        out.append(value.trim());
    }

    private String extension(String name) {
        String lower = name.toLowerCase(Locale.ROOT);
        int dot = lower.lastIndexOf('.');
        return dot < 0 ? "" : lower.substring(dot + 1);
    }

    private String safeMessage(Exception ex) {
        String value = ex.getMessage();
        if (value == null || value.isBlank()) return ex.getClass().getSimpleName();
        return value.length() > 240 ? value.substring(0, 240) : value;
    }
}
