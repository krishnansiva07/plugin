package com.formatflow.ai.config;

import com.formatflow.ai.web.SessionGuardInterceptor;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class WebConfig implements WebMvcConfigurer {

    private final SessionGuardInterceptor sessionGuardInterceptor;

    public WebConfig(SessionGuardInterceptor sessionGuardInterceptor) {
        this.sessionGuardInterceptor = sessionGuardInterceptor;
    }

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(sessionGuardInterceptor)
                .addPathPatterns("/api/**")
                .excludePathPatterns("/api/session/**");
    }
}
