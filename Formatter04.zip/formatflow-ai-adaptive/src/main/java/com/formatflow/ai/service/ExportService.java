package com.formatflow.ai.service;

import com.formatflow.ai.model.FormatModels.*;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.font.PDFont;
import org.apache.poi.sl.usermodel.ShapeType;
import org.apache.poi.xslf.usermodel.*;
import org.apache.poi.xwpf.usermodel.*;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTShd;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.STShd;
import org.springframework.stereotype.Service;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.geom.Rectangle2D;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.List;
import java.util.function.Function;
import java.util.stream.Collectors;

@Service
public class ExportService {

    private static final String GREEN = "008542";
    private static final String GREEN_DARK = "006B36";
    private static final String GREEN_SOFT = "EEF8F2";

    private final DocumentRenderer renderer;
    private final IconCatalog iconCatalog;
    private final PdfFontResolver pdfFontResolver;

    public ExportService(DocumentRenderer renderer, IconCatalog iconCatalog, PdfFontResolver pdfFontResolver) {
        this.renderer = renderer;
        this.iconCatalog = iconCatalog;
        this.pdfFontResolver = pdfFontResolver;
    }

    public ExportedFile export(ExportRequest request) {
        String format = request.format().toUpperCase(Locale.ROOT);
        String baseName = sanitizeFilename(request.filename() == null || request.filename().isBlank()
                ? "formatflow-output" : request.filename());
        FormattedDocument document = request.document();

        try {
            return switch (format) {
                case "WORD" -> new ExportedFile(baseName + ".docx",
                        "application/vnd.openxmlformats-officedocument.wordprocessingml.document", word(document));
                case "POWERPOINT" -> new ExportedFile(baseName + ".pptx",
                        "application/vnd.openxmlformats-officedocument.presentationml.presentation", powerpoint(document));
                case "PDF" -> new ExportedFile(baseName + ".pdf", "application/pdf", pdf(document));
                case "CONFLUENCE" -> new ExportedFile(baseName + "-confluence.html", "text/html; charset=UTF-8",
                        renderer.confluenceHtml(document).getBytes(StandardCharsets.UTF_8));
                case "EMAIL" -> new ExportedFile(baseName + "-email.html", "text/html; charset=UTF-8",
                        renderer.standaloneHtml(document, true).getBytes(StandardCharsets.UTF_8));
                case "MARKDOWN" -> new ExportedFile(baseName + ".md", "text/markdown; charset=UTF-8",
                        renderer.markdown(document).getBytes(StandardCharsets.UTF_8));
                case "HTML" -> new ExportedFile(baseName + ".html", "text/html; charset=UTF-8",
                        renderer.standaloneHtml(document, false).getBytes(StandardCharsets.UTF_8));
                default -> throw new IllegalArgumentException("Unsupported export format: " + request.format());
            };
        } catch (Exception ex) {
            throw new IllegalStateException("Export failed for " + format + ": " + ex.getMessage(), ex);
        }
    }

    private byte[] word(FormattedDocument document) throws Exception {
        try (XWPFDocument doc = new XWPFDocument(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            addWordAccent(doc);
            Map<String, DocumentBlock> blocks = blockMap(document);

            if (hasSemantic(document)) {
                for (SemanticSection section : document.semanticSections()) {
                    SemanticLayoutType sectionLayout = layout(section);
                    if (sectionLayout != SemanticLayoutType.TEXT && sectionLayout != SemanticLayoutType.CODE_GROUP) addWordSectionTitle(doc, section);
                    switch (sectionLayout) {
                        case TABLE, COMPARISON -> addWordTable(doc, section);
                        case WORKFLOW, ARCHITECTURE, HIERARCHY -> addWordFlow(doc, section);
                        case TIMELINE -> addWordTimeline(doc, section);
                        case STATUS, KPI -> addWordCardsTable(doc, section);
                        case CHECKLIST -> addWordChecklist(doc, section);
                        case CALLOUT -> addWordCallouts(doc, section);
                        case TEXT, CODE_GROUP -> addWordBlocks(doc, referencedBlocks(section, blocks));
                    }
                }
            } else {
                addWordBlocks(doc, document.blocks());
            }

            doc.write(out);
            return out.toByteArray();
        }
    }

    private void addWordAccent(XWPFDocument doc) {
        XWPFParagraph accentP = doc.createParagraph();
        XWPFRun accent = accentP.createRun();
        accent.setText(" ");
        accent.setFontSize(4);
        CTShd shading = accent.getCTR().addNewRPr().addNewShd();
        shading.setVal(STShd.CLEAR);
        shading.setFill(GREEN);
    }

    private void addWordSectionTitle(XWPFDocument doc, SemanticSection section) {
        if (section.title() == null || section.title().isBlank()) return;
        XWPFParagraph p = doc.createParagraph();
        p.setSpacingBefore(160); p.setSpacingAfter(80);
        XWPFRun run = p.createRun();
        String icon = iconCatalog.symbol(section.iconKey());
        run.setText((icon.isBlank() ? "" : icon + "  ") + section.title());
        run.setBold(true); run.setColor(GREEN_DARK); run.setFontSize(14); run.setFontFamily("Arial");
    }

    private void addWordTable(XWPFDocument doc, SemanticSection section) {
        int cols = safe(section.rows()).stream().mapToInt(r -> safe(r.cells()).size()).max().orElse(2);
        List<String> headers = paddedColumns(section.columns(), cols);
        XWPFTable table = doc.createTable(Math.max(1, section.rows().size()) + 1, cols);
        for (int c = 0; c < cols; c++) {
            XWPFTableCell cell = table.getRow(0).getCell(c);
            cell.setColor(GREEN_DARK);
            setCellText(cell, headers.get(c), true, "FFFFFF");
        }
        for (int r = 0; r < section.rows().size(); r++) {
            List<SemanticValue> cells = safe(section.rows().get(r).cells());
            for (int c = 0; c < cols; c++) {
                String value = c < cells.size() ? cells.get(c).text() : "";
                XWPFTableCell cell = table.getRow(r + 1).getCell(c);
                if (r % 2 == 1) cell.setColor("F7FBF8");
                setCellText(cell, value, false, "1F2D25");
            }
        }
        doc.createParagraph().setSpacingAfter(80);
    }

    private void addWordFlow(XWPFDocument doc, SemanticSection section) {
        XWPFParagraph p = doc.createParagraph();
        p.setSpacingAfter(100);
        List<SemanticNode> nodes = safe(section.nodes());
        Map<String, SemanticEdge> edgeMap = section.edges().stream().collect(Collectors.toMap(SemanticEdge::from, Function.identity(), (a, b) -> a));
        for (int i = 0; i < nodes.size(); i++) {
            SemanticNode node = nodes.get(i);
            XWPFRun nodeRun = p.createRun();
            String icon = iconCatalog.symbol(node.iconKey());
            nodeRun.setText((icon.isBlank() ? "" : icon + " ") + node.text());
            nodeRun.setBold(true); nodeRun.setColor(GREEN_DARK); nodeRun.setFontFamily("Arial"); nodeRun.setFontSize(10);
            if (i < nodes.size() - 1) {
                SemanticEdge edge = edgeMap.get(node.id());
                XWPFRun arrow = p.createRun();
                String label = edge == null || edge.label() == null || edge.label().isBlank() ? "" : "  " + edge.label() + "  ";
                arrow.setText(label + "  →  ");
                arrow.setColor(GREEN); arrow.setBold(true);
            }
        }
    }

    private void addWordTimeline(XWPFDocument doc, SemanticSection section) {
        for (SemanticItem item : safe(section.items())) {
            XWPFParagraph p = doc.createParagraph();
            p.setIndentationLeft(220);
            XWPFRun marker = p.createRun(); marker.setText("●  "); marker.setColor(GREEN); marker.setBold(true);
            XWPFRun text = p.createRun(); text.setText(joinItem(item)); text.setFontFamily("Arial"); text.setFontSize(10);
        }
    }

    private void addWordCardsTable(XWPFDocument doc, SemanticSection section) {
        XWPFTable table = doc.createTable(Math.max(1, section.items().size()), 3);
        int r = 0;
        for (SemanticItem item : safe(section.items())) {
            setCellText(table.getRow(r).getCell(0), item.label(), true, GREEN_DARK);
            setCellText(table.getRow(r).getCell(1), item.value(), false, "1F2D25");
            setCellText(table.getRow(r).getCell(2), item.status(), true, GREEN);
            if (r % 2 == 1) {
                for (XWPFTableCell cell : table.getRow(r).getTableCells()) cell.setColor("F7FBF8");
            }
            r++;
        }
    }

    private void addWordChecklist(XWPFDocument doc, SemanticSection section) {
        for (SemanticItem item : safe(section.items())) {
            XWPFParagraph p = doc.createParagraph();
            p.setIndentationLeft(220);
            XWPFRun tick = p.createRun(); tick.setText("✓  "); tick.setColor(GREEN); tick.setBold(true);
            XWPFRun text = p.createRun(); text.setText(joinItem(item)); text.setFontFamily("Arial"); text.setFontSize(10);
        }
    }

    private void addWordCallouts(XWPFDocument doc, SemanticSection section) {
        for (SemanticItem item : safe(section.items())) {
            XWPFParagraph p = doc.createParagraph();
            applyParagraphShading(p, GREEN_SOFT);
            XWPFRun run = p.createRun();
            String icon = iconCatalog.symbol(item.iconKey());
            run.setText((icon.isBlank() ? "" : icon + "  ") + joinItem(item));
            run.setFontFamily("Arial"); run.setFontSize(10);
        }
    }

    private void addWordBlocks(XWPFDocument doc, List<DocumentBlock> blocks) {
        for (DocumentBlock block : blocks) {
            if (block.type() == BlockType.SPACER) { doc.createParagraph(); continue; }
            XWPFParagraph p = doc.createParagraph();
            XWPFRun run = p.createRun();
            String icon = block.iconSymbol().isBlank() ? "" : block.iconSymbol() + "  ";
            switch (block.type()) {
                case TITLE -> { run.setText(icon + block.text()); run.setBold(true); run.setColor(GREEN); run.setFontSize(20); p.setSpacingAfter(180); }
                case HEADING -> { run.setText(icon + block.text()); run.setBold(true); run.setColor(GREEN); run.setFontSize(14); p.setSpacingBefore(160); p.setSpacingAfter(80); }
                case BULLET -> {
                    XWPFRun tick = p.createRun(); tick.setText("✓  "); tick.setBold(true); tick.setColor(GREEN);
                    run.setText(stripBullet(block.text())); run.setFontFamily("Arial"); run.setFontSize(10); p.setIndentationLeft(240);
                }
                case CODE -> { run.setText(block.text()); run.setFontFamily("Consolas"); run.setFontSize(9); applyParagraphShading(p, "F3F6F4"); }
                case CALLOUT -> { run.setText(icon + block.text()); run.setFontFamily("Arial"); run.setFontSize(10); applyParagraphShading(p, GREEN_SOFT); }
                default -> { run.setText(block.text()); run.setFontFamily("Arial"); run.setFontSize(10); }
            }
            applyEmphasis(run, block.emphasis());
        }
    }

    private void setCellText(XWPFTableCell cell, String text, boolean bold, String color) {
        XWPFParagraph p = cell.getParagraphs().isEmpty() ? cell.addParagraph() : cell.getParagraphs().get(0);
        p.setSpacingAfter(0);
        XWPFRun run = p.createRun();
        run.setText(text == null ? "" : text);
        run.setBold(bold); run.setColor(color); run.setFontFamily("Arial"); run.setFontSize(9);
    }

    private byte[] powerpoint(FormattedDocument document) throws Exception {
        try (XMLSlideShow ppt = new XMLSlideShow(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            ppt.setPageSize(new Dimension(960, 540));
            Map<String, DocumentBlock> blocks = blockMap(document);

            if (hasSemantic(document)) {
                for (SemanticSection section : document.semanticSections()) {
                    switch (layout(section)) {
                        case TABLE, COMPARISON -> pptTableSlide(ppt, section);
                        case WORKFLOW, ARCHITECTURE, HIERARCHY -> pptFlowSlide(ppt, section);
                        case STATUS, KPI -> pptCardsSlide(ppt, section);
                        case TIMELINE -> pptTimelineSlide(ppt, section);
                        case CHECKLIST, CALLOUT -> pptItemsSlide(ppt, section);
                        case TEXT, CODE_GROUP -> pptTextSlides(ppt, referencedBlocks(section, blocks), "");
                    }
                }
            } else {
                pptTextSlides(ppt, document.blocks(), document.title());
            }

            if (ppt.getSlides().isEmpty()) pptTextSlides(ppt, document.blocks(), document.title());
            ppt.write(out);
            return out.toByteArray();
        }
    }

    private XSLFSlide newSlide(XMLSlideShow ppt, String title, String iconKey) {
        XSLFSlide slide = ppt.createSlide();
        XSLFAutoShape accent = slide.createAutoShape();
        accent.setShapeType(ShapeType.RECT);
        accent.setAnchor(new Rectangle2D.Double(0, 0, 960, 12));
        accent.setFillColor(new Color(0, 133, 66)); accent.setLineColor(new Color(0, 133, 66));
        if (title != null && !title.isBlank()) {
            String icon = iconCatalog.symbol(iconKey);
            addPptText(slide, 54, 32, 850, 42, (icon.isBlank() ? "" : icon + "  ") + title,
                    23, true, new Color(0, 107, 54), null);
        }
        return slide;
    }

    private void pptTableSlide(XMLSlideShow ppt, SemanticSection section) {
        XSLFSlide slide = newSlide(ppt, section.title(), section.iconKey());
        int cols = safe(section.rows()).stream().mapToInt(r -> safe(r.cells()).size()).max().orElse(2);
        List<String> headers = paddedColumns(section.columns(), cols);
        int rows = Math.min(10, section.rows().size());
        double left = 55, top = section.title().isBlank() ? 48 : 92, width = 850;
        double cellW = width / cols;
        double rowH = Math.min(42, 360.0 / Math.max(2, rows + 1));

        for (int c = 0; c < cols; c++) {
            addPptText(slide, left + c * cellW, top, cellW, rowH, headers.get(c), 12, true, Color.WHITE, new Color(0, 107, 54));
        }
        for (int r = 0; r < rows; r++) {
            List<SemanticValue> cells = safe(section.rows().get(r).cells());
            for (int c = 0; c < cols; c++) {
                String text = c < cells.size() ? cells.get(c).text() : "";
                addPptText(slide, left + c * cellW, top + (r + 1) * rowH, cellW, rowH, text,
                        11, false, new Color(31, 45, 37), r % 2 == 0 ? Color.WHITE : new Color(247, 251, 248));
            }
        }
    }

    private void pptFlowSlide(XMLSlideShow ppt, SemanticSection section) {
        XSLFSlide slide = newSlide(ppt, section.title(), section.iconKey());
        List<SemanticNode> nodes = safe(section.nodes());
        Map<String, SemanticEdge> edgeMap = section.edges().stream().collect(Collectors.toMap(SemanticEdge::from, Function.identity(), (a, b) -> a));
        int perRow = Math.min(4, Math.max(2, nodes.size()));
        double nodeW = 165, nodeH = 70, gapX = 45, startX = 60, startY = section.title().isBlank() ? 80 : 125;

        for (int i = 0; i < nodes.size(); i++) {
            int row = i / perRow, col = i % perRow;
            double x = startX + col * (nodeW + gapX);
            double y = startY + row * 140;
            SemanticNode node = nodes.get(i);
            String icon = iconCatalog.symbol(node.iconKey());
            addPptText(slide, x, y, nodeW, nodeH, (icon.isBlank() ? "" : icon + "  ") + node.text(),
                    12, true, new Color(0, 107, 54), new Color(238, 248, 242));
            if (i < nodes.size() - 1 && (i + 1) % perRow != 0) {
                SemanticEdge edge = edgeMap.get(node.id());
                String label = edge == null || edge.label() == null ? "" : edge.label();
                addPptText(slide, x + nodeW + 4, y + 14, gapX - 8, 42, (label.isBlank() ? "" : label + "\n") + "→",
                        12, true, new Color(0, 133, 66), null);
            }
        }
    }

    private void pptCardsSlide(XMLSlideShow ppt, SemanticSection section) {
        XSLFSlide slide = newSlide(ppt, section.title(), section.iconKey());
        List<SemanticItem> items = safe(section.items());
        int cols = 3;
        double cardW = 250, cardH = 105, gapX = 28, gapY = 22, startX = 62, startY = section.title().isBlank() ? 75 : 118;
        for (int i = 0; i < Math.min(items.size(), 9); i++) {
            int row = i / cols, col = i % cols;
            SemanticItem item = items.get(i);
            String icon = iconCatalog.symbol(item.iconKey());
            addPptText(slide, startX + col * (cardW + gapX), startY + row * (cardH + gapY), cardW, cardH,
                    (icon.isBlank() ? "" : icon + "  ") + joinItem(item), 12, i < 3, new Color(31, 45, 37), new Color(247, 251, 248));
        }
    }

    private void pptTimelineSlide(XMLSlideShow ppt, SemanticSection section) {
        XSLFSlide slide = newSlide(ppt, section.title(), section.iconKey());
        double x = 105, y = section.title().isBlank() ? 75 : 118;
        for (int i = 0; i < Math.min(section.items().size(), 8); i++) {
            SemanticItem item = section.items().get(i);
            addPptText(slide, x, y + i * 48, 40, 35, "●", 16, true, new Color(0, 133, 66), null);
            addPptText(slide, x + 46, y + i * 48, 730, 40, joinItem(item), 12, false, new Color(31, 45, 37), null);
        }
    }

    private void pptItemsSlide(XMLSlideShow ppt, SemanticSection section) {
        XSLFSlide slide = newSlide(ppt, section.title(), section.iconKey());
        double y = section.title().isBlank() ? 70 : 112;
        for (int i = 0; i < Math.min(section.items().size(), 10); i++) {
            SemanticItem item = section.items().get(i);
            String prefix = layout(section) == SemanticLayoutType.CHECKLIST ? "✓  " : iconCatalog.symbol(item.iconKey()) + "  ";
            addPptText(slide, 78, y + i * 38, 800, 34, prefix + joinItem(item), 12, false,
                    new Color(31, 45, 37), layout(section) == SemanticLayoutType.CALLOUT ? new Color(238, 248, 242) : null);
        }
    }

    private void pptTextSlides(XMLSlideShow ppt, List<DocumentBlock> blocks, String sectionTitle) {
        List<List<DocumentBlock>> chunks = slides(blocks);
        for (int index = 0; index < chunks.size(); index++) {
            XSLFSlide slide = newSlide(ppt, index == 0 ? sectionTitle : "", "DOCUMENT");
            XSLFTextBox box = slide.createTextBox();
            box.setAnchor(new Rectangle2D.Double(58, sectionTitle != null && !sectionTitle.isBlank() && index == 0 ? 92 : 45, 845, 420));
            box.setTopInset(0); box.setBottomInset(0); box.setLeftInset(0); box.setRightInset(0); box.clearText();
            for (DocumentBlock block : chunks.get(index)) {
                if (block.type() == BlockType.SPACER) continue;
                XSLFTextParagraph p = box.addNewTextParagraph(); p.setSpaceAfter(5d);
                XSLFTextRun run = p.addNewTextRun();
                String icon = block.iconSymbol().isBlank() ? "" : block.iconSymbol() + "  ";
                String text = switch (block.type()) {
                    case BULLET -> "✓  " + stripBullet(block.text());
                    case TITLE, HEADING, CALLOUT -> icon + block.text();
                    default -> block.text();
                };
                run.setText(text); run.setFontFamily(block.type() == BlockType.CODE ? "Consolas" : "Arial");
                if (block.type() == BlockType.TITLE || block.type() == BlockType.HEADING) {
                    run.setFontSize(block.type() == BlockType.TITLE ? 22d : 17d); run.setBold(true); run.setFontColor(new Color(0, 110, 55));
                } else {
                    run.setFontSize(block.type() == BlockType.CODE ? 10d : 12d); run.setFontColor(new Color(32, 45, 38));
                }
            }
        }
    }

    private XSLFTextBox addPptText(XSLFSlide slide, double x, double y, double w, double h, String text,
                                   double size, boolean bold, Color textColor, Color fill) {
        XSLFTextBox box = slide.createTextBox();
        box.setAnchor(new Rectangle2D.Double(x, y, w, h));
        box.setTopInset(6); box.setBottomInset(4); box.setLeftInset(7); box.setRightInset(7);
        if (fill != null) box.setFillColor(fill);
        XSLFTextParagraph p = box.addNewTextParagraph();
        XSLFTextRun run = p.addNewTextRun();
        run.setText(text == null ? "" : text); run.setFontFamily("Arial"); run.setFontSize(size); run.setBold(bold); run.setFontColor(textColor);
        return box;
    }

    private byte[] pdf(FormattedDocument document) throws Exception {
        try (PDDocument doc = new PDDocument(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            PdfFontResolver.FontPair fonts = pdfFontResolver.resolve(doc);
            PdfCanvas canvas = new PdfCanvas(doc, fonts.regular(), fonts.bold());
            Map<String, DocumentBlock> blocks = blockMap(document);

            if (hasSemantic(document)) {
                for (SemanticSection section : document.semanticSections()) {
                    SemanticLayoutType sectionLayout = layout(section);
                    if (sectionLayout != SemanticLayoutType.TEXT && sectionLayout != SemanticLayoutType.CODE_GROUP) canvas.sectionTitle(section.title(), section.iconKey());
                    switch (sectionLayout) {
                        case TABLE, COMPARISON -> canvas.table(section);
                        case WORKFLOW, ARCHITECTURE, HIERARCHY -> canvas.flow(section);
                        case STATUS, KPI, TIMELINE, CHECKLIST, CALLOUT -> canvas.items(section);
                        case TEXT, CODE_GROUP -> canvas.blocks(referencedBlocks(section, blocks));
                    }
                    canvas.gap(8);
                }
            } else {
                canvas.blocks(document.blocks());
            }
            canvas.close();
            doc.save(out);
            return out.toByteArray();
        }
    }

    private final class PdfCanvas {
        private final PDDocument doc;
        private final PDFont regular;
        private final PDFont bold;
        private PDPage page;
        private PDPageContentStream stream;
        private final float margin = 48;
        private float y;

        private PdfCanvas(PDDocument doc, PDFont regular, PDFont bold) throws Exception {
            this.doc = doc; this.regular = regular; this.bold = bold; newPage();
        }

        private void newPage() throws Exception {
            if (stream != null) stream.close();
            page = new PDPage(PDRectangle.A4); doc.addPage(page); stream = new PDPageContentStream(doc, page);
            y = page.getMediaBox().getHeight() - 48;
            stream.setNonStrokingColor(new Color(0, 133, 66)); stream.addRect(0, page.getMediaBox().getHeight() - 10, page.getMediaBox().getWidth(), 10); stream.fill();
        }

        private void ensure(float height) throws Exception { if (y - height < margin) newPage(); }
        private void gap(float value) { y -= value; }

        private void sectionTitle(String title, String iconKey) throws Exception {
            if (title == null || title.isBlank()) return;
            ensure(30);
            String icon = iconCatalog.pdfSymbol(iconKey);
            line((icon.isBlank() ? "" : icon + "  ") + title, bold, 13, true, margin, 18);
            gap(5);
        }

        private void table(SemanticSection section) throws Exception {
            int cols = safe(section.rows()).stream().mapToInt(r -> safe(r.cells()).size()).max().orElse(2);
            List<String> headers = paddedColumns(section.columns(), cols);
            float totalW = page.getMediaBox().getWidth() - 2 * margin;
            float cellW = totalW / cols;
            float rowH = 25;
            ensure(rowH * 2);
            drawTableRow(headers, cols, cellW, rowH, true);
            for (SemanticRow row : safe(section.rows())) {
                ensure(rowH);
                List<String> values = safe(row.cells()).stream().map(SemanticValue::text).toList();
                drawTableRow(values, cols, cellW, rowH, false);
            }
            gap(6);
        }

        private void drawTableRow(List<String> values, int cols, float cellW, float rowH, boolean header) throws Exception {
            for (int c = 0; c < cols; c++) {
                float x = margin + c * cellW;
                if (header) {
                    stream.setNonStrokingColor(new Color(0, 107, 54)); stream.addRect(x, y - rowH, cellW, rowH); stream.fill();
                }
                stream.setStrokingColor(new Color(207, 228, 215)); stream.addRect(x, y - rowH, cellW, rowH); stream.stroke();
                String value = c < values.size() ? values.get(c) : "";
                drawAt(fit(value, header ? bold : regular, 9, cellW - 10), header ? bold : regular, 9,
                        header ? Color.WHITE : new Color(31, 45, 37), x + 5, y - 16);
            }
            y -= rowH;
        }

        private void flow(SemanticSection section) throws Exception {
            List<SemanticNode> nodes = safe(section.nodes());
            for (int i = 0; i < nodes.size(); i++) {
                if (i > 0) line("↓", bold, 12, true, margin + 35, 16);
                ensure(38);
                stream.setNonStrokingColor(new Color(238, 248, 242)); stream.addRect(margin, y - 28, 260, 28); stream.fill();
                stream.setStrokingColor(new Color(0, 133, 66)); stream.addRect(margin, y - 28, 260, 28); stream.stroke();
                String icon = iconCatalog.pdfSymbol(nodes.get(i).iconKey());
                drawAt(fit((icon.isBlank() ? "" : icon + "  ") + nodes.get(i).text(), bold, 10, 248), bold, 10,
                        new Color(0, 107, 54), margin + 6, y - 18);
                y -= 32;
            }
        }

        private void items(SemanticSection section) throws Exception {
            SemanticLayoutType type = layout(section);
            for (SemanticItem item : safe(section.items())) {
                String prefix = switch (type) {
                    case CHECKLIST -> "✓  ";
                    case TIMELINE -> "●  ";
                    default -> {
                        String symbol = iconCatalog.pdfSymbol(item.iconKey());
                        yield symbol.isBlank() ? "•  " : symbol + "  ";
                    }
                };
                line(prefix + joinItem(item), regular, 10, false, margin, 14);
            }
        }

        private void blocks(List<DocumentBlock> blocks) throws Exception {
            for (DocumentBlock block : blocks) {
                if (block.type() == BlockType.SPACER) { gap(7); continue; }
                boolean heading = block.type() == BlockType.TITLE || block.type() == BlockType.HEADING;
                PDFont font = heading ? bold : regular;
                float size = block.type() == BlockType.TITLE ? 17 : (block.type() == BlockType.HEADING ? 12 : 9.5f);
                String prefix = switch (block.type()) {
                    case BULLET -> "✓  ";
                    case TITLE, HEADING, CALLOUT -> {
                        String symbol = iconCatalog.pdfSymbol(block.iconKey()); yield symbol.isBlank() ? "" : symbol + "  ";
                    }
                    default -> "";
                };
                line(prefix + (block.type() == BlockType.BULLET ? stripBullet(block.text()) : block.text()), font, size, heading, margin, heading ? 18 : 13);
                if (heading) gap(4);
            }
        }

        private void line(String text, PDFont font, float size, boolean green, float x, float leading) throws Exception {
            List<String> lines = wrap(text, font, size, page.getMediaBox().getWidth() - x - margin);
            for (String value : lines) {
                ensure(leading + 2);
                drawAt(value, font, size, green ? new Color(0, 107, 54) : new Color(31, 45, 37), x, y);
                y -= leading;
            }
        }

        private void drawAt(String text, PDFont font, float size, Color color, float x, float yPos) throws Exception {
            stream.beginText(); stream.setFont(font, size); stream.setNonStrokingColor(color); stream.newLineAtOffset(x, yPos); stream.showText(safeForFont(font, text)); stream.endText();
        }

        private String fit(String value, PDFont font, float size, float maxWidth) throws Exception {
            String safe = safeForFont(font, value == null ? "" : value);
            if (font.getStringWidth(safe) / 1000f * size <= maxWidth) return safe;
            String suffix = "...";
            while (!safe.isEmpty() && font.getStringWidth(safe + suffix) / 1000f * size > maxWidth) safe = safe.substring(0, safe.length() - 1);
            return safe + suffix;
        }

        private void close() throws Exception { if (stream != null) stream.close(); }
    }

    private List<String> wrap(String text, PDFont font, float size, float width) throws Exception {
        List<String> result = new ArrayList<>();
        if (text == null || text.isEmpty()) { result.add(""); return result; }
        for (String hardLine : text.split("\\R", -1)) {
            String[] words = hardLine.split("\\s+");
            StringBuilder line = new StringBuilder();
            for (String word : words) {
                String candidate = line.isEmpty() ? word : line + " " + word;
                float w = font.getStringWidth(safeForFont(font, candidate)) / 1000f * size;
                if (!line.isEmpty() && w > width) { result.add(line.toString()); line = new StringBuilder(word); }
                else line = new StringBuilder(candidate);
            }
            result.add(line.toString());
        }
        return result;
    }

    private String safeForFont(PDFont font, String text) {
        StringBuilder out = new StringBuilder();
        text.codePoints().forEach(cp -> {
            String s = new String(Character.toChars(cp));
            try { font.getStringWidth(s); out.append(s); }
            catch (Exception ex) { out.append('?'); }
        });
        return out.toString();
    }

    private List<List<DocumentBlock>> slides(List<DocumentBlock> blocks) {
        List<List<DocumentBlock>> slides = new ArrayList<>();
        List<DocumentBlock> current = new ArrayList<>();
        int weight = 0;
        for (DocumentBlock block : blocks) {
            int blockWeight = Math.max(1, (block.text().length() / 85) + 1);
            boolean headingBreak = (block.type() == BlockType.TITLE || block.type() == BlockType.HEADING) && !current.isEmpty() && weight >= 7;
            if (headingBreak || weight + blockWeight > 13) { slides.add(List.copyOf(current)); current.clear(); weight = 0; }
            current.add(block); weight += blockWeight;
        }
        if (!current.isEmpty()) slides.add(List.copyOf(current));
        if (slides.isEmpty()) slides.add(List.of());
        return slides;
    }

    private boolean hasSemantic(FormattedDocument document) {
        return document.semanticSections() != null && !document.semanticSections().isEmpty();
    }

    private SemanticLayoutType layout(SemanticSection section) {
        try { return SemanticLayoutType.valueOf(section.layoutType().toUpperCase(Locale.ROOT)); }
        catch (Exception ex) { return SemanticLayoutType.TEXT; }
    }

    private Map<String, DocumentBlock> blockMap(FormattedDocument document) {
        return document.blocks().stream().collect(Collectors.toMap(DocumentBlock::id, Function.identity(), (a, b) -> a, LinkedHashMap::new));
    }

    private List<DocumentBlock> referencedBlocks(SemanticSection section, Map<String, DocumentBlock> blocks) {
        List<DocumentBlock> result = new ArrayList<>();
        for (String id : safe(section.sourceIds())) if (blocks.containsKey(id)) result.add(blocks.get(id));
        return result;
    }

    private List<String> paddedColumns(List<String> columns, int count) {
        List<String> result = new ArrayList<>(safe(columns));
        while (result.size() < count) result.add(result.isEmpty() ? "Item" : "Details");
        return result.subList(0, count);
    }

    private String joinItem(SemanticItem item) {
        LinkedHashSet<String> parts = new LinkedHashSet<>();
        if (item.label() != null && !item.label().isBlank()) parts.add(item.label());
        if (item.value() != null && !item.value().isBlank()) parts.add(item.value());
        if (item.status() != null && !item.status().isBlank()) parts.add(item.status());
        return String.join(" — ", parts);
    }

    private <T> List<T> safe(List<T> values) { return values == null ? List.of() : values; }

    private void applyParagraphShading(XWPFParagraph p, String fill) {
        CTShd shd = p.getCTP().getPPr() == null ? p.getCTP().addNewPPr().addNewShd() : p.getCTP().getPPr().addNewShd();
        shd.setVal(STShd.CLEAR); shd.setFill(fill);
    }

    private void applyEmphasis(XWPFRun run, String emphasis) {
        if ("STRONG".equalsIgnoreCase(emphasis)) run.setBold(true);
        if ("MUTED".equalsIgnoreCase(emphasis)) run.setColor("6F7F76");
    }

    private String stripBullet(String text) {
        return text == null ? "" : text.replaceFirst("^\\s*(?:[-*•▪◦]|\\d+[.)])\\s+", "");
    }

    private String sanitizeFilename(String value) {
        String sanitized = value.replaceAll("[^A-Za-z0-9._-]+", "-").replaceAll("^-+|-+$", "");
        return sanitized.isBlank() ? "formatflow-output" : sanitized;
    }

    public record ExportedFile(String filename, String contentType, byte[] bytes) {}
}
