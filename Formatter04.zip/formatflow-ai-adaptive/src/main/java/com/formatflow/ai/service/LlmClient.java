package com.formatflow.ai.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.formatflow.ai.config.LlmProperties;
import org.springframework.stereotype.Service;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.List;
import java.util.Map;

@Service
public class LlmClient {

    private final HttpClient httpClient;
    private final ObjectMapper objectMapper;
    private final LlmProperties properties;

    public LlmClient(HttpClient httpClient, ObjectMapper objectMapper, LlmProperties properties) {
        this.httpClient = httpClient;
        this.objectMapper = objectMapper;
        this.properties = properties;
    }

    public ValidationResult validateKey(String apiKey) {
        try {
            String response = chat(apiKey, "Reply with exactly OK.", 16, 0.0);
            return response == null || response.isBlank()
                    ? new ValidationResult(false, "LLM returned an empty response.")
                    : new ValidationResult(true, "AI service connected.");
        } catch (LlmHttpException ex) {
            if (ex.statusCode == 401 || ex.statusCode == 403) {
                return new ValidationResult(false, "API key was rejected by the LLM service.");
            }
            return new ValidationResult(false, "LLM service returned HTTP " + ex.statusCode + ".");
        } catch (Exception ex) {
            return new ValidationResult(false, "Unable to connect to the configured LLM service: " + safeMessage(ex));
        }
    }

    public String chat(String apiKey, String prompt, int maxTokens, double temperature) {
        int attempts = 3;
        RuntimeException last = null;

        for (int attempt = 1; attempt <= attempts; attempt++) {
            try {
                return doChat(apiKey, prompt, maxTokens, temperature);
            } catch (LlmHttpException ex) {
                last = ex;
                if (!retryable(ex.statusCode) || attempt == attempts) throw ex;
                sleep(attempt);
            } catch (RuntimeException ex) {
                last = ex;
                if (attempt == attempts) throw ex;
                sleep(attempt);
            }
        }
        throw last == null ? new IllegalStateException("LLM request failed.") : last;
    }

    private String doChat(String apiKey, String prompt, int maxTokens, double temperature) {
        try {
            String body = objectMapper.writeValueAsString(Map.of(
                    "model", properties.getModel(),
                    "messages", List.of(Map.of("role", "user", "content", prompt)),
                    "temperature", temperature,
                    "max_tokens", maxTokens
            ));

            HttpRequest request = HttpRequest.newBuilder()
                    .uri(chatUri())
                    .timeout(Duration.ofSeconds(properties.getRequestTimeoutSeconds()))
                    .header("Content-Type", "application/json")
                    .header("Accept", "application/json")
                    .header(properties.getAuthHeader(), properties.getAuthPrefix() + apiKey)
                    .POST(HttpRequest.BodyPublishers.ofString(body))
                    .build();

            HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
            if (response.statusCode() < 200 || response.statusCode() >= 300) {
                throw new LlmHttpException(response.statusCode());
            }

            JsonNode json = objectMapper.readTree(response.body());
            JsonNode content = json.at("/choices/0/message/content");
            if (content.isMissingNode() || content.isNull()) {
                throw new IllegalStateException("LLM response does not contain choices[0].message.content.");
            }
            return content.asText();
        } catch (LlmHttpException ex) {
            throw ex;
        } catch (Exception ex) {
            throw new IllegalStateException("LLM request failed: " + safeMessage(ex), ex);
        }
    }

    private URI chatUri() {
        String base = properties.getBaseUrl();
        if (base == null || base.isBlank()) {
            throw new IllegalStateException("formatflow.llm.base-url is not configured.");
        }
        base = base.endsWith("/") ? base.substring(0, base.length() - 1) : base;
        String path = properties.getChatPath() == null ? "/chat/completions" : properties.getChatPath();
        path = path.startsWith("/") ? path : "/" + path;
        return URI.create(base + path);
    }

    private boolean retryable(int status) {
        return status == 408 || status == 429 || status == 500 || status == 502 || status == 503 || status == 504;
    }

    private void sleep(int attempt) {
        try {
            Thread.sleep(Math.min(4000L, 500L * (1L << (attempt - 1))));
        } catch (InterruptedException ex) {
            Thread.currentThread().interrupt();
            throw new IllegalStateException("LLM retry interrupted.", ex);
        }
    }

    private static String safeMessage(Exception ex) {
        String msg = ex.getMessage();
        if (msg == null || msg.isBlank()) return ex.getClass().getSimpleName();
        return msg.length() > 180 ? msg.substring(0, 180) : msg;
    }

    public record ValidationResult(boolean valid, String message) {}

    private static final class LlmHttpException extends RuntimeException {
        private final int statusCode;
        private LlmHttpException(int statusCode) {
            super("LLM HTTP " + statusCode);
            this.statusCode = statusCode;
        }
    }
}
