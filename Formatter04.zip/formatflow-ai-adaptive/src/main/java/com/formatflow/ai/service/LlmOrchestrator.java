package com.formatflow.ai.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.formatflow.ai.model.FormatModels.PlanItem;
import com.formatflow.ai.model.FormatModels.SourceBlock;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class LlmOrchestrator {

    private final LlmClient llmClient;
    private final PromptFactory promptFactory;
    private final ContentParser contentParser;
    private final ObjectMapper objectMapper;
    private final IconCatalog iconCatalog;
    private final int chunkCharacters;
    private final int chunkBlocks;

    public LlmOrchestrator(LlmClient llmClient,
                           PromptFactory promptFactory,
                           ContentParser contentParser,
                           ObjectMapper objectMapper,
                           IconCatalog iconCatalog,
                           @Value("${formatflow.llm.chunk-characters:9000}") int chunkCharacters,
                           @Value("${formatflow.llm.chunk-blocks:40}") int chunkBlocks) {
        this.llmClient = llmClient;
        this.promptFactory = promptFactory;
        this.contentParser = contentParser;
        this.objectMapper = objectMapper;
        this.iconCatalog = iconCatalog;
        this.chunkCharacters = chunkCharacters;
        this.chunkBlocks = chunkBlocks;
    }

    public PlanOutcome buildFormattingPlan(String apiKey,
                                             List<SourceBlock> blocks,
                                             String audience,
                                             String purpose,
                                             String outputFormat,
                                             String iconLevel) {
        List<List<SourceBlock>> chunks = contentParser.chunks(blocks, chunkCharacters, chunkBlocks);
        Map<String, PlanItem> planned = new LinkedHashMap<>();
        int calls = 0;

        for (List<SourceBlock> chunk : chunks) {
            String prompt = promptFactory.formattingPlan(chunk, audience, purpose, outputFormat, iconLevel);
            String response = llmClient.chat(apiKey, prompt, 2400, 0.0);
            calls++;
            List<PlanItem> parsed;
            try {
                parsed = parsePlan(response, chunk);
            } catch (RuntimeException invalidStructuredOutput) {
                response = llmClient.chat(
                        apiKey,
                        prompt + "\n\nREPAIR REQUEST: Return ONLY valid strict JSON matching the requested schema. Preserve every source block id exactly once. Do not return or rewrite source text.",
                        2400,
                        0.0
                );
                calls++;
                parsed = parsePlan(response, chunk);
            }
            Map<String, SourceBlock> sourceById = chunk.stream().collect(Collectors.toMap(SourceBlock::id, b -> b));
            for (PlanItem item : parsed) {
                String iconKey = item.iconKey();
                if ("NONE".equalsIgnoreCase(iconLevel)) {
                    iconKey = "NONE";
                } else if ("NONE".equalsIgnoreCase(iconKey)
                        && ("TITLE".equalsIgnoreCase(item.type()) || "HEADING".equalsIgnoreCase(item.type()))) {
                    SourceBlock source = sourceById.get(item.id());
                    iconKey = iconCatalog.inferKey(source == null ? "" : source.text());
                }
                PlanItem effective = new PlanItem(item.id(), item.type(), iconKey, item.emphasis(), item.bulletStyle());
                planned.put(effective.id(), effective);
            }
        }

        List<PlanItem> ordered = new ArrayList<>();
        for (SourceBlock block : blocks) {
            if (block.blank()) continue;
            PlanItem item = planned.get(block.id());
            if (item == null) {
                throw new IllegalStateException("LLM formatting plan omitted source block " + block.id() + ". No content was changed.");
            }
            ordered.add(item);
        }
        return new PlanOutcome(ordered, calls, chunks.size());
    }

    public EnhancementOutcome enhance(String apiKey,
                                      List<SourceBlock> blocks,
                                      String audience,
                                      String purpose,
                                      String outputFormat) {
        List<List<SourceBlock>> chunks = contentParser.chunks(blocks, chunkCharacters, chunkBlocks);
        Map<String, String> enhanced = new LinkedHashMap<>();
        int calls = 0;

        for (List<SourceBlock> chunk : chunks) {
            String response = llmClient.chat(
                    apiKey,
                    promptFactory.enhanceBlocks(chunk, audience, purpose, outputFormat),
                    4096,
                    0.1
            );
            calls++;
            JsonNode root = readJson(response);
            JsonNode items = root.path("items");
            if (!items.isArray()) throw new IllegalStateException("LLM enhancement response did not contain an items array.");

            Set<String> allowed = chunk.stream().map(SourceBlock::id).collect(Collectors.toSet());
            for (JsonNode item : items) {
                String id = item.path("id").asText("");
                String text = item.path("text").asText(null);
                if (!allowed.contains(id) || text == null) continue;
                enhanced.put(id, text);
            }
        }

        List<SourceBlock> result = new ArrayList<>();
        for (SourceBlock source : blocks) {
            if (source.blank()) {
                result.add(source);
            } else {
                String text = enhanced.get(source.id());
                if (text == null) {
                    throw new IllegalStateException("LLM enhancement omitted source block " + source.id() + ".");
                }
                if (source.codeLike() && !text.equals(source.text())) {
                    throw new IllegalStateException("LLM attempted to modify code/configuration block " + source.id() + ". Request stopped to protect technical content.");
                }
                result.add(new SourceBlock(source.id(), text, source.codeLike(), source.bulletLike(), false));
            }
        }
        return new EnhancementOutcome(result, calls, chunks.size());
    }

    public SummaryOutcome summarize(String apiKey,
                                    String content,
                                    String audience,
                                    String purpose,
                                    String summaryLength,
                                    String outputFormat) {
        List<String> chunks = chunkText(content, Math.max(chunkCharacters * 2, 14000));
        List<String> partials = new ArrayList<>();
        int calls = 0;

        for (int i = 0; i < chunks.size(); i++) {
            String partial = llmClient.chat(
                    apiKey,
                    promptFactory.summarizeChunk(chunks.get(i), audience, purpose, summaryLength, i + 1, chunks.size()),
                    1800,
                    0.15
            );
            calls++;
            partials.add(partial.trim());
        }

        if (partials.size() == 1) {
            return new SummaryOutcome(partials.get(0), calls, chunks.size());
        }

        // Hierarchical reduction prevents very large documents from overflowing the final synthesis prompt.
        List<String> reduced = partials;
        while (combinedLength(reduced) > 26000 && reduced.size() > 2) {
            List<List<String>> groups = groupSummaries(reduced, 18000);
            List<String> next = new ArrayList<>();
            for (List<String> group : groups) {
                String intermediate = llmClient.chat(
                        apiKey,
                        promptFactory.synthesizeSummary(group, audience, purpose, "Detailed", outputFormat),
                        2200,
                        0.1
                );
                calls++;
                next.add(intermediate.trim());
            }
            reduced = next;
        }

        String finalSummary = llmClient.chat(
                apiKey,
                promptFactory.synthesizeSummary(reduced, audience, purpose, summaryLength, outputFormat),
                2600,
                0.15
        );
        calls++;
        return new SummaryOutcome(finalSummary.trim(), calls, chunks.size());
    }

    public String generateEmailSubject(String apiKey, String content, String audience, String purpose) {
        String response = llmClient.chat(apiKey, promptFactory.emailSubject(content, audience, purpose), 64, 0.1);
        String subject = response.replace("\r", " ").replace("\n", " ").trim();
        if (subject.startsWith("\"") && subject.endsWith("\"") && subject.length() > 1) {
            subject = subject.substring(1, subject.length() - 1);
        }
        if (subject.length() > 160) subject = subject.substring(0, 160).trim();
        return subject;
    }

    private int combinedLength(List<String> values) {
        return values.stream().mapToInt(String::length).sum();
    }

    private List<List<String>> groupSummaries(List<String> summaries, int maxChars) {
        List<List<String>> groups = new ArrayList<>();
        List<String> current = new ArrayList<>();
        int chars = 0;
        for (String summary : summaries) {
            if (!current.isEmpty() && chars + summary.length() > maxChars) {
                groups.add(List.copyOf(current));
                current.clear();
                chars = 0;
            }
            current.add(summary);
            chars += summary.length();
        }
        if (!current.isEmpty()) groups.add(List.copyOf(current));
        return groups;
    }

    private List<PlanItem> parsePlan(String response, List<SourceBlock> chunk) {
        JsonNode root = readJson(response);
        JsonNode items = root.path("items");
        if (!items.isArray()) throw new IllegalStateException("LLM formatting response did not contain an items array.");

        Set<String> allowedIds = chunk.stream().map(SourceBlock::id).collect(Collectors.toSet());
        Set<String> seen = new HashSet<>();
        List<PlanItem> result = new ArrayList<>();

        for (JsonNode item : items) {
            String id = item.path("id").asText("");
            if (!allowedIds.contains(id) || !seen.add(id)) continue;
            String type = validType(item.path("type").asText("PARAGRAPH"));
            String icon = iconCatalog.normalize(item.path("iconKey").asText("NONE"));
            String emphasis = valid(item.path("emphasis").asText("NONE"), Set.of("NONE", "STRONG", "MUTED", "HIGHLIGHT"), "NONE");
            String bullet = valid(item.path("bulletStyle").asText("NONE"), Set.of("NONE", "CHECK", "ARROW", "DOT"), "NONE");
            result.add(new PlanItem(id, type, icon, emphasis, bullet));
        }
        return result;
    }

    private JsonNode readJson(String raw) {
        try {
            String cleaned = raw == null ? "" : raw.trim();
            if (cleaned.startsWith("```")) {
                cleaned = cleaned.replaceFirst("^```(?:json)?\\s*", "").replaceFirst("\\s*```$", "");
            }
            int first = cleaned.indexOf('{');
            int last = cleaned.lastIndexOf('}');
            if (first >= 0 && last > first) cleaned = cleaned.substring(first, last + 1);
            return objectMapper.readTree(cleaned);
        } catch (Exception ex) {
            throw new IllegalStateException("LLM returned invalid structured JSON. Try again or inspect the configured model compatibility.", ex);
        }
    }

    private String validType(String type) {
        return valid(type, Set.of("TITLE", "HEADING", "PARAGRAPH", "BULLET", "CODE", "CALLOUT", "QUOTE"), "PARAGRAPH");
    }

    private String valid(String value, Set<String> allowed, String fallback) {
        String normalized = value == null ? fallback : value.trim().toUpperCase(Locale.ROOT);
        return allowed.contains(normalized) ? normalized : fallback;
    }

    private List<String> chunkText(String content, int maxChars) {
        List<String> result = new ArrayList<>();
        String[] paragraphs = content.split("(?m)(?<=\\n)\\s*\\n");
        StringBuilder current = new StringBuilder();

        for (String paragraph : paragraphs) {
            if (!current.isEmpty() && current.length() + paragraph.length() + 2 > maxChars) {
                result.add(current.toString());
                current.setLength(0);
            }
            if (!current.isEmpty()) current.append("\n\n");
            current.append(paragraph);
        }
        if (!current.isEmpty()) result.add(current.toString());
        if (result.isEmpty()) result.add(content);
        return result;
    }

    public record PlanOutcome(List<PlanItem> items, int llmCalls, int chunks) {}
    public record EnhancementOutcome(List<SourceBlock> blocks, int llmCalls, int chunks) {}
    public record SummaryOutcome(String content, int llmCalls, int chunks) {}
}
