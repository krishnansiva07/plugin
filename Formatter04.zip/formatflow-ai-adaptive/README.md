# FormatFlow AI — Semantic Layout Edition

**One Content. Any Audience. Any Format.**

FormatFlow AI is a Java 17 + Spring Boot application that uses an OpenAI-compatible LLM for **document understanding and presentation planning**, while keeping content transformation permissions explicit.

## Core purpose

The tool is not just a text beautifier. It analyzes the meaning and relationships in supplied content and can select a richer representation when the source supports it:

- key/value facts → table
- sequential interactions → workflow
- dates/milestones → timeline
- option A vs B → comparison
- progress/state → native table or status list (cards only when genuinely appropriate)
- actions → checklist
- metrics → KPI only for true headline quantitative metrics
- parent/child relationships → hierarchy
- components/relationships → architecture flow
- code/configuration → protected code groups
- warnings/important items → callouts
- otherwise → professional text layout

## Content modes

### Format + Preserve

The original logical content string is never rewritten. The LLM is allowed to return only formatting metadata and semantic structures. Any visible value in a semantic table/workflow/timeline/card must be validated by Java as an **exact excerpt of the referenced source block**. If validation fails, FormatFlow falls back to normal text for that source instead of inventing content.

Semantic transformation may split an original sentence into exact excerpts for presentation. Example:

`Java version is 17.`

may be shown as:

| Property | Value |
|---|---|
| Java version | 17 |

The immutable source remains available in Original / Side-by-Side views and is retained as `plainContent` in the document model.

### Enhance + Format

The user explicitly permits grammar/clarity changes. Code/configuration blocks are still protected from LLM changes.

### Summarize + Format

The user explicitly permits summarization. Large documents are summarized hierarchically in bounded chunks and then semantically formatted for the selected stakeholder.

## LLM pipeline

Normal formatting now uses an **adaptive single-pass semantic pipeline**. The previous design made separate formatting and semantic-layout LLM calls for the same chunk. That duplicated tokens and could produce inconsistent decisions.

```text
Input
  ↓
Extraction / parsing
  ↓
Optional enhancement or stakeholder summarization
  ↓
Adaptive logical chunking (keeps blank-line sections together)
  ↓
ONE bounded LLM analysis call per chunk
  ├─ line formatting metadata
  ├─ table/workflow/checklist/etc. decision
  └─ <=450 character continuity digest
  ↓
Java exact-excerpt semantic validation
  ↓
Java cross-chunk document assembly
  ├─ preserve source order
  ├─ merge compatible table continuations
  └─ merge compatible list/timeline continuations
  ↓
ONE FormattedDocument
  ↓
Destination renderer
  ├─ Confluence
  ├─ Word
  ├─ PowerPoint
  ├─ PDF
  ├─ Email
  ├─ Markdown
  └─ HTML
```

For large content, **the complete document is never resent for semantic formatting**. Each call receives only its bounded source chunk plus a short non-rendered digest from the previous chunk. Java assembles the validated results into one document before Preview/Copy/Export.

Adaptive limits:

```properties
formatflow.llm.adaptive-chunk-characters=5500
formatflow.llm.adaptive-chunk-blocks=26
formatflow.llm.continuity-characters=700
```

The older `formatflow.llm.chunk-*` settings remain for explicit enhancement/summarization operations.

## Semantic document model

Important classes:

- `AdaptiveSemanticOrchestrator` — one bounded LLM call per chunk for formatting + semantic understanding
- `SemanticLayoutValidator` — rejects invented/non-source semantic values
- `DocumentAssemblyService` — joins independently analyzed chunks into one coherent semantic document
- `SemanticPresentationPolicy` — prevents repeated data from becoming walls of cards
- `PromptFactory` — activity/destination-specific prompts plus adaptive semantic analysis
- `DocumentRenderer` — HTML/Confluence/Markdown semantic renderer
- `ExportService` — Word/PPT/PDF semantic renderers
- `FormattingService` — end-to-end orchestration

Supported semantic section types:

```text
TEXT
TABLE
WORKFLOW
TIMELINE
COMPARISON
STATUS
CHECKLIST
KPI
HIERARCHY
ARCHITECTURE
CODE_GROUP
CALLOUT
```

## Stakeholder audiences

- General
- Co-worker
- Manager
- Management / Executive
- Business Analyst
- Product Owner
- Scrum Master
- Technical Team
- Client / Stakeholder

Audience selection influences hierarchy and visual emphasis. It does not permit rewriting in Preserve mode.

## Outputs

- Confluence-ready HTML
- Word `.docx`
- PowerPoint `.pptx`
- PDF
- Email HTML
- Markdown
- HTML

Semantic HTML includes actual tables, workflow nodes/arrows, timelines, cards, checklists and callouts. PowerPoint creates actual positioned node/card shapes for semantic sections rather than copying all content into one text box.

## LLM access

The first screen requires a valid LLM API key. The key is kept only in the server-side HTTP session.

The key is intentionally not stored in source code or `application.properties`.

Configure only the static endpoint/model:

```properties
formatflow.llm.base-url=https://your-openai-compatible-endpoint/api/v1
formatflow.llm.model=your-model
formatflow.llm.chat-path=/chat/completions
```

Bearer-token gateway:

```properties
formatflow.llm.auth-header=Authorization
formatflow.llm.auth-prefix=Bearer 
```

Header-key gateway:

```properties
formatflow.llm.auth-header=api-key
formatflow.llm.auth-prefix=
```

## Build and run

Requirements:

- Java 17+
- Maven 3.9+

```bash
mvn clean test
mvn clean package
java -jar target/formatflow-ai-0.0.1-SNAPSHOT.jar
```

Open:

```text
http://localhost:8090
```

## Semantic demo

Paste `samples/semantic-layout-demo.txt`, select:

```text
Audience: Technical Team
Activity: Format
Content Handling: Preserve Source Content
Smart Semantic Layout: ON
Symbols: Rich & Semantic
Format: HTML or PowerPoint
```

The configured LLM should identify the configuration facts, request workflow and delivery status as separate semantic structures when its analysis is valid. Exact layout selection remains model-driven; unsafe/invented values are rejected by the Java validator.

## Security controls

- API key is session-only
- prompt-injection boundary: imported content is treated as data
- structured semantic values must come from referenced source excerpts
- code/configuration blocks are protected in enhancement mode
- URL importer blocks private/local network targets by default
- uploaded content and API keys are not intentionally written to logs
- security response headers are included
- invalid semantic LLM output fails safely to text

## Validation included

Tests cover:

- preserve-mode logical content integrity
- semantic network symbols and tick bullets
- HTML full-document export
- semantic table rendering
- semantic exact-excerpt validation
- rejection of an invented semantic table value
- workflow excerpt validation
- code detection
- content-difference measurement

## Note about local build verification

This source tree has been syntax-checked for the newly added semantic classes and frontend JavaScript in the generation environment. The environment does not have Maven dependencies cached and cannot reach Maven Central, so the full Maven dependency build must be run in your normal development environment with `mvn clean test`.

## Confluence behavior

Confluence and Markdown are intentionally separate outputs.

- **Confluence / Copy for Confluence** puts portable rich HTML on the clipboard using only headings, paragraphs, lists, tables, code blocks and blockquotes. It does not copy FormatFlow CSS classes or dashboard-card markup.
- **Markdown** copies the exact generated Markdown text.
- Raw Markdown is not treated as the Confluence page format by this application.
- For guaranteed Confluence Cloud publishing, use the Confluence REST API with `storage` or `atlas_doc_format` representation. This build keeps copy/paste dependency-free and does not ask for Confluence credentials.
- Confluence Cloud also supports importing `.docx`; use the Word export if an import workflow is preferred.

## Large Word documents

The upload limit is now 100 MB by default. Office/PDF uploads are first streamed to a temporary file rather than duplicated using `MultipartFile.getBytes()`. DOCX body text is extracted directly from `word/document.xml` with a StAX stream (`DocxStreamingTextExtractor`) instead of building the full XWPF object model, which substantially reduces memory pressure for large text-heavy Word files. Tune:

```properties
spring.servlet.multipart.max-file-size=100MB
spring.servlet.multipart.max-request-size=100MB
formatflow.upload.max-bytes=104857600
```

Large documents are chunked into small logical groups before LLM analysis, and all validated chunk outputs are assembled into one final view/export.
