package com.llmart.llm.service;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Path;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class AgentRunServiceTest {

    @TempDir
    Path temp;

    private AgentRunService service(String name) {
        return new AgentRunService(temp.resolve(name));
    }

    @Test
    void tracksPlanMutationDiffAndVerificationRevision() {
        AgentRunService service = service("plan");
        AgentRunService.AgentRun run = service.start("conversation", "project");

        run.setPlan(List.of("Inspect", "Edit", "Verify"));
        assertTrue(run.hasPlan());
        assertTrue(run.hasOpenPlanItems());

        run.updatePlan(1, "completed", "inspected");
        run.updatePlan(2, "completed", "changed");
        run.markMutation();
        assertFalse(run.diffReviewedCurrentRevision());
        run.markDiffReview();
        assertTrue(run.diffReviewedCurrentRevision());

        run.markVerificationAttempt(true, "build passed");
        assertTrue(run.verifiedCurrentRevision());
        run.updatePlan(3, "completed", "passed");
        assertFalse(run.hasOpenPlanItems());
    }

    @Test
    void cancellationIsIdempotentAndFinishedRunCannotBeCancelled() {
        AgentRunService service = service("cancel");
        AgentRunService.AgentRun running = service.start("conversation", null);
        assertTrue(service.cancel(running.id()));
        assertFalse(service.cancel(running.id()));
        assertThrows(AgentCancelledException.class, running::checkCancelled);

        AgentRunService.AgentRun completed = service.start("conversation", null);
        completed.finish("completed");
        assertFalse(service.cancel(completed.id()));
        assertEquals("completed", completed.snapshot().get("status"));
    }
    @Test
    void tracksProviderAndCompactionTokenTelemetry() {
        AgentRunService service = service("tokens");
        AgentRunService.AgentRun run = service.start("conversation", "project");

        run.recordContextEstimate(42_000, 131_072);
        run.recordModelUsage(new OpenAiCompatibleClient.Usage(40_000, 1_500, 41_500, 20_000, 0, true), 42_000);
        run.recordCompaction(25_000, "Proactive checkpoint");
        run.markRepeatedCallPrevented();

        assertEquals(1, run.modelCalls());
        assertEquals(41_500, run.providerTotalTokens());
        assertEquals(20_000, run.cachedInputTokens());
        assertEquals(1, run.compactions());
        var usage = (java.util.Map<?,?>) run.snapshot().get("tokenUsage");
        assertEquals(42_000L, usage.get("currentContextTokens"));
        assertEquals(25_000L, usage.get("estimatedTokensSavedByCompaction"));
        assertEquals(1L, usage.get("repeatedCallsPrevented"));
    }

    @Test
    void progressIsMonotonicAndTerminalAnswerIsDurable() {
        AgentRunService service = service("progress");
        AgentRunService.AgentRun run = service.start("conversation", "project");

        run.updateProgress(35, "inspecting", "Reading files");
        run.updateProgress(10, "starting", "Older event");
        assertEquals(35, run.progressPercent(), "progress must never move backwards");
        assertEquals("inspecting", run.progressPhase(), "stale lower progress must not rewind the visible phase");

        run.markFinalAnswer("Completed requested change");
        run.finish("completed");
        assertTrue(run.finished());
        assertFalse(run.responsePersisted());
        assertEquals(98, run.progressPercent());

        run.markResponsePersisted("42", "Completed requested change");
        assertTrue(run.responsePersisted());
        assertEquals(100, run.progressPercent());
        assertEquals("completed", run.progressPhase());
        assertEquals("42", run.assistantMessageId());
        assertEquals("Completed requested change", run.snapshot().get("finalAnswer"));
    }

    @Test
    void planStatePersistsAcrossRunReload() {
        Path store = temp.resolve("plan-reload");
        AgentRunService first = new AgentRunService(store);
        AgentRunService.AgentRun run = first.start("conversation", "project");
        run.setPlan(List.of("Inspect", "Implement", "Verify"));
        run.markPlanStarted();
        run.recordPlanToolActivity("read");
        run.updatePlan(1, "completed", "inspected");
        run.updatePlan(2, "in_progress", "editing");

        AgentRunService reloaded = new AgentRunService(store);
        AgentRunService.AgentRun restored = reloaded.require(run.id());
        String plan = restored.planText();
        assertTrue(plan.contains("[completed] Inspect"));
        assertTrue(plan.contains("[in_progress] Implement"));
        assertTrue(plan.contains("[pending] Verify"));
    }

    @Test
    void reloadMarksInFlightRunInterruptedAndPreservesFinalState() {
        Path store = temp.resolve("restart");
        AgentRunService first = new AgentRunService(store);
        AgentRunService.AgentRun run = first.start("conversation", "project");
        run.updateProgress(54, "implementing", "Editing files");
        run.markMutation();

        AgentRunService reloaded = new AgentRunService(store);
        AgentRunService.AgentRun restored = reloaded.require(run.id());

        assertTrue(restored.finished());
        assertEquals("interrupted", restored.snapshot().get("status"));
        assertEquals(100, restored.progressPercent());
        assertTrue(restored.finalAnswer().toLowerCase().contains("restart"));
        assertEquals(1, restored.mutationRevision());
    }

    @Test
    void approvedPlanIsSequentialAndModelFailoverPreservesActiveStep() {
        AgentRunService service = service("sequential-failover");
        AgentRunService.AgentRun run = service.start("conversation", "project");
        run.configureModelPool(List.of("model-a", "model-b", "model-c", "model-b"));
        run.setPlan(List.of("Inspect", "Implement", "Verify"));
        run.markPlanStarted();

        assertEquals(1, run.activePlanIndex());
        assertThrows(IllegalStateException.class, () -> run.updatePlan(2, "in_progress", "jump"));
        assertThrows(IllegalStateException.class, () -> run.updatePlan(1, "completed", "no evidence"));

        run.recordPlanToolActivity("read");
        run.updatePlan(1, "completed", "inspected");
        assertEquals(2, run.activePlanIndex());

        run.recordPlanToolActivity("edit");
        run.markMutation(true);
        assertThrows(IllegalStateException.class, () -> run.updatePlan(2, "completed", "not verified"));
        run.markVerificationAttempt(true, "targeted test passed");
        run.updatePlan(2, "completed", "verified");
        assertEquals(3, run.activePlanIndex());

        assertTrue(run.switchToNextModel("primary unavailable"));
        assertEquals("model-b", run.activeModel());
        assertEquals(3, run.activePlanIndex());
        assertEquals(1, run.modelFailovers());
        assertEquals(List.of("model-a", "model-b", "model-c"), run.modelPool());
    }

}
