# Validation Report — Fixed GPT18

Date: 2026-09-08

## Scope

This package was validated after fixing the uploaded GPT18 source and implementing the requested OpenCode-inspired orchestration changes: plan-first execution, one-step-at-a-time approved plan execution, verification gates, multiple configured models, per-model recovery/failover, durable continuation state, and a modernized Agent UI for long runs.

## Fixed / implemented

- Fixed the Java source defect in `AgentService.httpVerificationSuccess()` that contained a duplicate local-variable declaration in the uploaded baseline.
- Added a configurable ordered model pool: primary model plus fallback models.
- Added configurable recovery attempts per model; default is 10 and the accepted range is 1–50.
- Explicit unavailable/unknown/unsupported model failures immediately switch to the next configured model instead of consuming all retries.
- Timeout/429/retryable server failures use the recovery budget for the active model before failover.
- Model failover preserves the same workspace, approved plan, active plan step, mutation/verification state, and persisted Agent run.
- Plan approval now starts a strict sequential plan gate. Exactly one step is active at a time.
- `todo_update` cannot complete an approved step without real non-todo tool activity.
- A code/config mutation cannot complete its plan step until the current workspace revision has successful verification evidence.
- Completing a step unlocks exactly the next step.
- Future plan steps cannot be updated/executed ahead of the active step.
- If one model response tries to complete the current plan step and also sends tools for the next step, later calls from that same response are deferred by the sequential plan gate.
- Subagents cannot independently advance the parent approved plan.
- A final answer is deferred while approved plan steps remain open.
- The Agent UI now includes primary-model selection, fallback-model configuration, recovery-attempt configuration, active-model/failover status, a live sequential plan board, and collapsed older events for long 180+ event runs.

## Validation passed in this environment

- `node --check src/main/resources/static/app.js`
- `node --check src/main/resources/static/markdown.js`
- `bash -n run.sh`
- `bash -n validate-local.sh`
- `pom.xml` XML parse
- `index.html` HTML parse
- `app.css` stylesheet parse
- UI DOM wiring check for the new model-pool/recovery controls
- Java 17 parser sweep across all main Java sources. The compiler reported only unresolved third-party Spring/JPA/Jackson dependencies because dependency resolution is unavailable in this environment; no Java syntax/language-structure diagnostics were found.
- Fresh executable Java 17 harness compiled directly from the modified `AgentRunService` and `ChatSettings` sources and passed all of these checks:
  - fallback-model de-duplication and ordering
  - first approved plan step is the only active step
  - todo-only completion is rejected
  - completion after real read/tool evidence unlocks only the next step
  - a mutation cannot unlock the next step before verification
  - successful verification permits the current step to complete
  - switching models preserves the active plan step
  - failover count and active model are persisted
  - reloading the Agent run preserves locked plan/model/failover orchestration state

Harness result:

```text
PASS sequential-plan + verification-gate + failover + persistence harness
```

## Maven/JUnit package-build limitation

A full dependency-backed Maven/Spring/JUnit build cannot be executed inside this validation environment because Maven is not installed locally and the included Maven wrapper must download Maven/dependencies from Maven Central. DNS/network access to `repo.maven.apache.org` is unavailable here.

The attempted Java parser sweep confirms there are no remaining Java syntax diagnostics; the unresolved compiler errors begin with missing external packages such as Spring Data JPA and Jakarta Persistence.

For the full dependency-backed acceptance check on a machine with Maven access, run:

Windows:

```bat
validate-local.bat
```

Linux/macOS:

```bash
./validate-local.sh
```

## Recommended acceptance flow

Configure at least two valid models, then run an Agent request with plan approval enabled.

Expected behavior:

```text
Task
  -> resolve workspace
  -> create plan
  -> show plan
  -> Approve & run step 1
  -> Step 1 real work
  -> verify if mutated
  -> unlock Step 2
  -> Step 2 real work
  -> ...
  -> final verification
  -> completion
```

If the active model becomes unavailable or exhausts its per-model recovery budget:

```text
same run + same workspace + same approved plan + same active step
  -> switch to next configured model
  -> continue current step
```
