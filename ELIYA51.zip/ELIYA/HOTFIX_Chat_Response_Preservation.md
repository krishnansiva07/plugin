# Eliya 48 — Chat response disappears after streaming (hotfix candidate)

## User-observed defect
Chat shows a long generated response while tokens stream, but sections or the entire response disappear immediately after generation finishes. A screenshot showed agent/skill definitions and phase prompts visible while the Chat response was being displayed.

## Source-level cause and scope
`src/main/resources/static/app.js` appended each SSE `token` to an in-memory assistant message, but on SSE `done` unconditionally replaced the in-memory assistant with the server's persisted DTO using `Object.assign`. Any shortened, blank, or divergent `content` in the final event could instantly replace the visible response. `ChatService.java` saved the model-returned `answer` without checking whether it matched the tokens already emitted to the browser, so a mismatch could also survive in Chat history. This code path is a concrete explanation for the observation, although the exact backend payload from the user's machine was not captured.

## Changes
1. **Backend: ChatAnswerIntegrity.java** provides a single canonical answer for streaming and persistence. If the model return has more text than the emitted stream and begins with that stream, it transmits the missing suffix before completion. Otherwise, it preserves the already-emitted text rather than silently replacing it with a shorter or divergent return. Divergences produce a server warning without exposing response text.
2. **Backend: ChatService.java** uses the reconciled answer when persisting the assistant message and sending the `done` DTO. Change is confined to Chat finalization, including MCP-backed Chat; Agent mode execution is not modified.
3. **Frontend: app.js** uses `applyCompletedChatMessage()` on Chat `done` events, retaining the visible response if the final DTO is empty, truncated or divergent. A clear in-message warning appears if the frontend must preserve a non-authoritative local draft. The same protection is used when recovering a Chat response after SSE interruption.
4. **Frontend: app.css** adds subtle styling for the rare mismatch warning.
5. **Regression tests**: `src/test/js/chat_completion_integrity.test.js` covers shorter, empty, divergent, longer, valid and missing done payloads, and checks that technical lists and fenced Markdown remain visible when streaming ends. `qa/chat-integrity-smoke/ChatAnswerIntegritySmoke.java` validates six backend reconciliation scenarios using only Java 17.

## Validation completed
- `node --check` passed for modified `app.js` and `markdown.js`.
- `node --test src/test/js/*.test.js`: **29 passing**, zero failed.
- `javac` and `java` standalone Java 17 integrity smoke: **6 scenarios passed**.
- No existing project source files removed. Only `ChatService.java`, `app.js`, `app.css` modified; one backend utility and two test files added.
- ZIP integrity checked.

## Not yet verified
- Maven/Spring application compile and the complete backend JUnit suite (Maven and dependencies unavailable in this environment).
- Browser visual run against the user's Windows Eliya runtime.
- True end-to-end performance, response history persistence after restart, and MCP live gateway behavior.

## Manual acceptance steps for user's environment
1. Keep the working Eliya 46 or current Eliya 48 build as a backup; build and launch this hotfix separately on Java 17.
2. In **Chat**, request a long technical response containing numbered sections, many file paths, tables, and a fenced code block; watch until generation finishes.
3. Confirm every section visible during streaming remains after completion, and Copy/Markdown still contains the same content.
4. Open a different Chat, then reopen the original Chat; verify the full response is loaded from persisted history. Restart Eliya and reopen again.
5. Repeat with **MCP-enabled Chat** using an explicit MCP prompt, and without MCP enabled; existing MCP opt-in gating must not change.
6. Run your existing successful analysis, development, migration, deletion approval, rollback, Prompt Factory, Confluence Composer and documentation workflows to ensure no regression.
7. If disappearance persists, capture the developer-tools Network response of `/api/chat/stream` (specifically the final `event: done`, with confidential text redacted) and `/api/conversations/{id}/messages` returned `content` length. This distinguishes UI reconciliation from persistence or rendering defects.

## No broader claims
This fix addresses one observed Chat finalization defect; it does not change retrieval accuracy, indexing speed, model token-generation throughput, or Agent completion logic. It must not be treated as a fully validated Windows release until the full build and application regression tests pass.
