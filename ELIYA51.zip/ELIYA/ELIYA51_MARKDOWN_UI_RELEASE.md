# ELIYA51 — Markdown visibility and UI reliability fix

Based on the user-provided **ELIYA50.zip**. This is a source release (not a compiled JAR).

## Fixed

1. **Responses disappearing after streaming:** Agent-mode SSE `done` previously assigned the final saved message directly over the message the user had already seen. Chat and Agent now share an integrity-preserving reconciliation rule, including the Agent watchdog completion path. Missing, shorter, or divergent final payloads cannot blank out the visible response. A mismatch warning is displayed rather than hiding text.
2. **Blank Chat responses for generated file blocks:** Structured `PROJECT_FILE_START` / `PROJECT_FILE_END` content was intentionally removed from the visible prose, but a response consisting entirely of file blocks then appeared empty. The UI now shows explicit file cards and provides Markdown previews for those proposed files. The user must explicitly apply a Chat proposal to write it to the local workspace.
3. **Agent-generated Markdown not openable in UI:** Completed Agent change reports now provide **Preview .md** for each new/modified Markdown file. Preview supports formatted display, raw Markdown, Copy contents, and Download .md.
4. **Actual empty files:** The viewer accurately identifies a zero-length/whitespace-only Markdown document and tells the user the file has no content instead of displaying a blank pane.
5. **Empty model answers:** Explicit empty-response feedback replaces an empty visual area.

## Safety and compatibility

- Existing Chat-to-Agent approval handoff is unchanged. Chat preview does **not** automatically write files.
- Actual Agent preview is **read-only**, restricted to `.md` files from the selected run's sealed file-change report, requires the file to be located inside that run's workspace, rejects symbolic links and path escape, and limits file reads to 1.5 MB of UTF-8 content.
- Preview reads the **current local file**, not a historical snapshot. If a file has since changed or been removed, its current state is shown or the user receives an error.
- No change was made to model/provider selection, MCP gating, workspace/reference roles, rollback, deletion permission, indexing, or Agent execution strategy.

## Usage

1. In **Agent mode**, complete a task that creates or modifies `.md` files.
2. Open the completed Agent run's **Detailed completion report**. Click **Preview .md** next to a changed Markdown file.
3. Use **Raw Markdown**, **Copy contents**, or **Download .md**. If the file is empty, the viewer says so.
4. In **Chat mode**, when the assistant produces structured file proposals, file cards appear even if no prose accompanied them. Preview the proposed Markdown; use **Review all proposed files** to download a patch or explicitly apply it.

## Validation performed

- `node --check src/main/resources/static/app.js` and `markdown.js`: passed.
- `node qa/markdown-ui-smoke/run.cjs`: passed (empty/truncated Agent and Chat completion; marker-only file proposals; nonblank fallback; UI controls).
- `bash qa/completion-report-smoke/run.sh`: passed (Java completion report / secure Markdown retrieval / empty-file detection / invalid index and file type / symlink rejection; UI contracts).
- `bash qa/chat-continuation-smoke.sh`: passed.
- `bash qa/offline-smoke/run.sh`: passed.
- `bash qa/native-agent-policy-smoke.sh`: passed.
- `bash qa/agent-reliability/run.sh`: passed Java 17 syntax parse and source contracts (not dependency/type resolution).
- `bash qa/plan-relevance/run.sh`: passed.
- `bash qa/workspace-planning/run.sh`: passed.
- `bash qa/workspace-boundaries/run.sh`: reported boundary assertions passed but the grouped validation command timed out before confirming overall script termination.

**Build limitation:** A real Maven `clean package` / full Spring Boot JAR build was not possible in this container because the Maven executable and dependencies are unavailable. Build in an environment with Maven/dependency access using `./mvnw -Pfull-tests clean package` (Windows: `mvnw.cmd -Pfull-tests clean package`). Then run normal end-to-end browser/Agent smoke tests against the actual provider and local workspace; those runtime checks were not conducted here.
