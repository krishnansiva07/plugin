const fs = require('node:fs');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const html = fs.readFileSync('src/main/resources/static/index.html', 'utf8');
const source = fs.readFileSync('src/main/resources/static/app.js', 'utf8');
const css = fs.readFileSync('src/main/resources/static/app.css', 'utf8');
for (const id of ['runMarkdownBackdrop','runMarkdownTitle','runMarkdownContent','runMarkdownStatus','runMarkdownToggle','runMarkdownCopy','runMarkdownDownload','runMarkdownClose']) {
  assert(html.includes(`id="${id}"`), `Missing Markdown preview: ${id}`);
}
assert(source.includes('data-preview-agent-md'), 'Agent Markdown preview trigger missing');
assert(source.includes('data-preview-proposed-md'), 'Chat Markdown proposal trigger missing');
assert(source.includes('applyCompletedChatMessage(assistant, saved)'), 'Both Chat and Agent should guard final response');
assert(!source.includes('MarkdownArtifactReader'), 'Backend reader must be isolated from browser JS');
assert(css.includes('.run-markdown-content'), 'Markdown preview CSS missing');
function extract(name) {
  const start = source.indexOf(`function ${name}(`);
  assert(start >= 0, `Missing ${name}`);
  const next = source.indexOf('\nfunction ', start + 10);
  const stop = next > 0 ? next : source.length;
  return source.slice(start, stop);
}
const context = {
  console,
  state: {messages: []},
  esc: x=>String(x).replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('"','&quot;'),
  MarkdownRenderer: {render: x=> `<p>${String(x)}</p>`},
  formatCompact: x=> String(x),
  agentStepsHtml: ()=>'',
  attachmentHtml: ()=>'',
  hasMarkdownTable: ()=>false,
  isExcelRequestedForAssistant: ()=>false
};
const code = ['applyCompletedChatMessage','stripProjectMarkers','extractProjectFileChanges','messageHtml'].map(extract).join('\n');
vm.runInNewContext(code, context);
const chat = {role:'assistant',mode:'chat',content:'# Heading\n- visible 1\n- visible 2',streaming:true};
context.applyCompletedChatMessage(chat, {content:''});
assert(chat.content.includes('visible 2') && !chat.streaming, 'Empty final payload erased Chat output');
const agent = {role:'assistant',mode:'agent',content:'# Generated document\nAll content',streaming:true};
context.applyCompletedChatMessage(agent, {content:'short'});
assert(agent.content.includes('All content'), 'Short final payload erased Agent output');
assert(agent.chatCompletionWarning, 'Divergence must warn');
const extended = {role:'assistant',mode:'chat',content:'Hello',streaming:true};
context.applyCompletedChatMessage(extended,{content:'Hello again'});
assert.equal(extended.content,'Hello again','Longer compatible completion should be kept');
const marker = '<!-- PROJECT_FILE_START:.skills/demo.skill.md -->\n```md\n# Actual generated skill\nBody text\n```\n<!-- PROJECT_FILE_END -->';
const changes = context.extractProjectFileChanges(marker);
assert.equal(changes.length,1,'Structured Markdown file should be available');
assert.equal(changes[0].content, '# Actual generated skill\nBody text');
assert.equal(context.stripProjectMarkers(marker),'','Entire file proposal intentionally leaves no prose');
context.state.messages=[{role:'assistant',mode:'chat',content:marker,streaming:false}];
const rendered = context.messageHtml(context.state.messages[0],0);
assert(rendered.includes('generated file proposal'), 'Marker-only answer should have visible file summary');
assert(rendered.includes('Preview .md') && rendered.includes('.skills/demo.skill.md'), 'Actual generated Markdown file should be previewable');
assert(rendered.includes('not yet saved to the workspace'), 'Chat proposal must not be misrepresented as a real file');
context.state.messages=[{role:'assistant',mode:'chat',content:'',streaming:false}];
assert(context.messageHtml(context.state.messages[0],0).includes('No visible response was returned'), 'Empty response must not render blank');
console.log('PASS: Markdown modal, safe persistence, marker-only file rendering, downloadable proposal affordance, explicit empty state');
