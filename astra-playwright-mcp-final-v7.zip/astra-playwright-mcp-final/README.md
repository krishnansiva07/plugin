# Astra AI Playwright MCP Final

## Run
1. Install Node.js 18+ and Maven/Java 17.
2. Update `src/main/resources/application.properties` with LLM key/base-url/model.
3. Run: `mvn clean spring-boot:run`
4. Open: `http://localhost:8090/index.html`

## Main capability
- Uses latest Playwright MCP via `npx -y @playwright/mcp@latest`.
- Opens browser live.
- LLM decides actions from MCP snapshot + scenario + test data.
- Does not intentionally guess test data; prompt asks to stop if data missing.
- Generates code in selected target framework.
- Validates Playwright TS/JS automatically using `npx playwright test`.

## API
POST `/api/astra/run`

## Important
For exact validation, create a Playwright project first:
`npm init playwright@latest`

Use its path in the UI Project Path field.
