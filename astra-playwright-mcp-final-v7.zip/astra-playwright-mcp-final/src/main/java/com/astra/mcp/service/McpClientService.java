package com.astra.mcp.service;
import com.fasterxml.jackson.databind.*;import org.springframework.beans.factory.annotation.Value;import org.springframework.stereotype.Service;import org.springframework.web.reactive.function.client.WebClient;import java.util.*;import java.util.concurrent.atomic.AtomicLong;
@Service public class McpClientService{private final WebClient web;private final ObjectMapper om=new ObjectMapper();private final AtomicLong id=new AtomicLong(1);@Value("${playwright.mcp.url}") String url;private String sessionId;
 public McpClientService(WebClient.Builder b){web=b.build();}
 public synchronized void reset(){sessionId=null;}
 public Map<String,Object> call(String method,Object params){Map<String,Object> body=new LinkedHashMap<>();body.put("jsonrpc","2.0");body.put("id",id.getAndIncrement());body.put("method",method);body.put("params",params==null?Map.of():params);WebClient.RequestBodySpec req=web.post().uri(url).header("Content-Type","application/json").header("Accept","application/json, text/event-stream");if(sessionId!=null)req.header("Mcp-Session-Id",sessionId);String raw=req.bodyValue(body).retrieve().toEntity(String.class).block().getBody();try{return om.readValue(extractJson(raw),Map.class);}catch(Exception e){return Map.of("error","MCP_PARSE_ERROR","raw",raw==null?"":raw);}}
 private String extractJson(String raw){if(raw==null)return "{}";int i=raw.indexOf('{');int j=raw.lastIndexOf('}');return i>=0&&j>i?raw.substring(i,j+1):raw;}
 public void initialize(){Map<String,Object> res=call("initialize",Map.of("protocolVersion","2024-11-05","capabilities",Map.of(),"clientInfo",Map.of("name","astra-java-client","version","1.0")));Object sid=res.get("sessionId");if(sid!=null)sessionId=sid.toString();call("notifications/initialized",Map.of());}
 public Map<String,Object> tools(){return call("tools/list",Map.of());}
 public Map<String,Object> tool(String name,Map<String,Object> args){return call("tools/call",Map.of("name",name,"arguments",args));}
 public String snapshot(){return String.valueOf(tool("browser_snapshot",Map.of()));}
}
