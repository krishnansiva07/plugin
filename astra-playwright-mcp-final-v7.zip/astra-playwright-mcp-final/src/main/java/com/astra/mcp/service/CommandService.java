package com.astra.mcp.service;
import org.springframework.stereotype.Service;import java.io.*;import java.nio.charset.StandardCharsets;import java.util.*;import java.util.concurrent.*;
@Service public class CommandService{
 public String run(List<String> cmd, File dir, int timeoutSec){StringBuilder out=new StringBuilder();try{ProcessBuilder pb=new ProcessBuilder(cmd);if(dir!=null)pb.directory(dir);pb.redirectErrorStream(true);Process p=pb.start();try(BufferedReader r=new BufferedReader(new InputStreamReader(p.getInputStream(),StandardCharsets.UTF_8))){String line;long end=System.currentTimeMillis()+timeoutSec*1000L;while(System.currentTimeMillis()<end && (line=r.readLine())!=null){out.append(line).append('\n');}}p.waitFor(3,TimeUnit.SECONDS);out.append("\nEXIT_CODE=").append(p.exitValue());}catch(Exception e){out.append("COMMAND_ERROR: ").append(e.getMessage());}return out.toString();}
}
