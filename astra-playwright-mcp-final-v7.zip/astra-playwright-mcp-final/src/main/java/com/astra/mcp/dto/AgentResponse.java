package com.astra.mcp.dto;
import java.util.*;
public class AgentResponse{public String status;public String validationStatus;public String message;public String generatedCode;public String savedFilePath;public String validationOutput;public List<Map<String,Object>> actionTrace=new ArrayList<>();public List<String> missingData=new ArrayList<>();public String finalSnapshot;public String rawLog;}
