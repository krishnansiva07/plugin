# FormatFlow AI

**One Content. Any Audience. Any Format.**

FormatFlow AI is a Java 17 + Spring Boot formatting application that keeps **content preservation** separate from **content enhancement**.

## Included in this build

- LLM API-key gate on application launch
- API key stored only in the server-side HTTP session
- Static LLM base URL and model in `application.properties`
- Paste text
- Upload/import TXT, Markdown, HTML, DOCX, PDF, PPTX, JSON, XML, `.properties`, and Java
- Public web-page import
- Audience:
  - General
  - Co-worker
  - Manager
  - Management / Executive
  - Business Analyst
  - Product Owner
  - Scrum Master
  - Technical Team
  - Client / Stakeholder
- Purpose selection
- Output:
  - Confluence HTML
  - Word DOCX
  - PowerPoint PPTX
  - PDF
  - Email HTML
  - Markdown
  - HTML
- Preserve Original Content mode
- Enhance Content for Audience mode
- Side-by-side preview
- Content integrity statistics
- Professional green/white UI

## Important preservation rule

### PRESERVE mode

The source content is returned **byte-for-byte as the final logical content string**. It is **not sent to the LLM**. The rendering/export layer may visually style headings, code, lists, spacing, etc., but it does not rewrite the source text.

### ENHANCE mode

The content is sent to the configured LLM with strict instructions not to invent facts. The application then measures word additions/removals and shows the result side by side.

## LLM configuration

The key is intentionally not present in the repository.

Edit only the static endpoint/model when required:

```properties
formatflow.llm.base-url=https://your-openai-compatible-endpoint/api/v1
formatflow.llm.model=your-model
formatflow.llm.chat-path=/chat/completions
```

For a normal OpenAI-compatible bearer token:

```properties
formatflow.llm.auth-header=Authorization
formatflow.llm.auth-prefix=Bearer 
```

If your enterprise gateway instead expects a header such as `api-key`, configure:

```properties
formatflow.llm.auth-header=api-key
formatflow.llm.auth-prefix=
```

## Run

Requirements:

- Java 17+
- Maven 3.9+

```bash
mvn clean test
mvn spring-boot:run
```

Open:

```text
http://localhost:8090
```

The first screen asks for the LLM API key. The workspace is available only after the LLM service accepts it.

## Build executable JAR

```bash
mvn clean package
java -jar target/formatflow-ai-0.0.1-SNAPSHOT.jar
```

## URL import security

The V1 URL importer accepts public HTTP/HTTPS pages and blocks IPs resolved as:

- localhost / loopback
- link-local
- site-local/private
- multicast

Redirects are validated again and limited.

This intentionally means private intranet URLs are not imported by the generic URL importer. Add authenticated Confluence/SharePoint connectors separately instead of weakening SSRF protection.

## Known V1 limitation

PDF export uses PDFBox's standard font set. Characters outside that font range are replaced in the generated PDF. Word, PowerPoint, HTML, Confluence and Email outputs retain the Java strings as Unicode.

For full multilingual/emoji PDF output, add an organization-approved Unicode font through a configurable font provider in a later iteration.

## Security

Do not commit API keys.

If a key was previously photographed, pasted into chat, committed to source, or otherwise exposed, rotate/revoke it before using this project.
