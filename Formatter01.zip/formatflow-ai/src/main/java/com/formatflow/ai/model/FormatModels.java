package com.formatflow.ai.model;

import jakarta.validation.constraints.NotBlank;

public final class FormatModels {

    private FormatModels() {}

    public enum FormatMode {
        PRESERVE,
        ENHANCE
    }

    public enum OutputFormat {
        CONFLUENCE,
        WORD,
        POWERPOINT,
        PDF,
        EMAIL,
        MARKDOWN,
        HTML
    }

    public record FormatRequest(
            @NotBlank String content,
            @NotBlank String audience,
            String purpose,
            @NotBlank String format,
            @NotBlank String mode,
            String visualStyle,
            String iconLevel,
            String emailSubject
    ) {}

    public record ContentStats(
            int originalWords,
            int formattedWords,
            int addedWords,
            int removedWords,
            boolean exactContentPreserved,
            int originalCharacters,
            int formattedCharacters
    ) {}

    public record FormatResult(
            String finalContent,
            String previewHtml,
            ContentStats stats,
            String format,
            boolean enhanced
    ) {}

    public record ExportRequest(
            @NotBlank String content,
            @NotBlank String format,
            String emailSubject,
            String filename
    ) {}
}
