package com.formatflow.ai.service;

import com.formatflow.ai.model.FormatModels.ExportRequest;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.apache.pdfbox.pdmodel.font.Standard14Fonts;
import org.apache.poi.sl.usermodel.ShapeType;
import org.apache.poi.xslf.usermodel.*;
import org.apache.poi.xwpf.usermodel.*;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTShd;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.STShd;
import org.springframework.stereotype.Service;

import java.awt.*;
import java.awt.geom.Rectangle2D;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

@Service
public class ExportService {

    private static final String GREEN = "008542";

    private final PreviewRenderer previewRenderer;

    public ExportService(PreviewRenderer previewRenderer) {
        this.previewRenderer = previewRenderer;
    }

    public ExportedFile export(ExportRequest request) {
        String format = request.format().toUpperCase(Locale.ROOT);
        String baseName = sanitizeFilename(
                request.filename() == null || request.filename().isBlank()
                        ? "formatflow-output"
                        : request.filename()
        );

        try {
            return switch (format) {
                case "WORD" -> new ExportedFile(
                        baseName + ".docx",
                        "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                        word(request.content())
                );
                case "POWERPOINT" -> new ExportedFile(
                        baseName + ".pptx",
                        "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                        powerpoint(request.content())
                );
                case "PDF" -> new ExportedFile(
                        baseName + ".pdf",
                        "application/pdf",
                        pdf(request.content())
                );
                case "CONFLUENCE" -> new ExportedFile(
                        baseName + "-confluence.html",
                        "text/html; charset=UTF-8",
                        previewRenderer.renderStandaloneHtml(request.content(), request.emailSubject())
                                .getBytes(StandardCharsets.UTF_8)
                );
                case "EMAIL" -> new ExportedFile(
                        baseName + "-email.html",
                        "text/html; charset=UTF-8",
                        emailHtml(request.content(), request.emailSubject()).getBytes(StandardCharsets.UTF_8)
                );
                case "MARKDOWN" -> new ExportedFile(
                        baseName + ".md",
                        "text/markdown; charset=UTF-8",
                        request.content().getBytes(StandardCharsets.UTF_8)
                );
                case "HTML" -> new ExportedFile(
                        baseName + ".html",
                        "text/html; charset=UTF-8",
                        previewRenderer.renderStandaloneHtml(request.content(), request.emailSubject())
                                .getBytes(StandardCharsets.UTF_8)
                );
                default -> throw new IllegalArgumentException("Unsupported export format: " + request.format());
            };
        } catch (Exception ex) {
            throw new IllegalStateException("Export failed: " + ex.getMessage(), ex);
        }
    }

    private byte[] word(String content) throws Exception {
        try (XWPFDocument doc = new XWPFDocument();
             ByteArrayOutputStream out = new ByteArrayOutputStream()) {

            XWPFParagraph top = doc.createParagraph();
            top.setSpacingAfter(80);
            XWPFRun bar = top.createRun();
            bar.setText(" ");
            bar.setFontSize(4);
            CTShd shading = bar.getCTR().addNewRPr().addNewShd();
            shading.setVal(STShd.CLEAR);
            shading.setFill(GREEN);

            for (String line : content.split("\\R", -1)) {
                XWPFParagraph p = doc.createParagraph();
                p.setSpacingAfter(70);

                XWPFRun run = p.createRun();
                run.setText(line);

                if (looksLikeHeading(line)) {
                    run.setBold(true);
                    run.setColor(GREEN);
                    run.setFontSize(14);
                    p.setSpacingBefore(140);
                } else if (looksLikeCode(line)) {
                    run.setFontFamily("Consolas");
                    run.setFontSize(9);
                } else {
                    run.setFontFamily("Arial");
                    run.setFontSize(10);
                }
            }

            doc.write(out);
            return out.toByteArray();
        }
    }

    private byte[] powerpoint(String content) throws Exception {
        try (XMLSlideShow ppt = new XMLSlideShow();
             ByteArrayOutputStream out = new ByteArrayOutputStream()) {

            ppt.setPageSize(new Dimension(960, 540));
            List<String> chunks = chunkLines(content, 13);

            for (String chunk : chunks) {
                XSLFSlide slide = ppt.createSlide();

                XSLFAutoShape accent = slide.createAutoShape();
                accent.setShapeType(ShapeType.RECT);
                accent.setAnchor(new Rectangle2D.Double(0, 0, 960, 14));
                accent.setFillColor(new Color(0, 133, 66));
                accent.setLineColor(new Color(0, 133, 66));

                XSLFTextBox box = slide.createTextBox();
                box.setAnchor(new Rectangle2D.Double(65, 52, 830, 420));
                box.setInsets(new Insets(0, 0, 0, 0));
                box.clearText();

                String[] lines = chunk.split("\\R", -1);
                for (int i = 0; i < lines.length; i++) {
                    XSLFTextParagraph p = box.addNewTextParagraph();
                    p.setSpaceAfter(5d);
                    XSLFTextRun run = p.addNewTextRun();
                    run.setText(lines[i]);
                    run.setFontFamily(looksLikeCode(lines[i]) ? "Consolas" : "Arial");

                    if (looksLikeHeading(lines[i])) {
                        run.setBold(true);
                        run.setFontColor(new Color(0, 120, 61));
                        run.setFontSize(22d);
                        p.setSpaceBefore(8d);
                        p.setSpaceAfter(10d);
                    } else {
                        run.setFontSize(14d);
                        run.setFontColor(new Color(32, 45, 38));
                    }
                }
            }

            ppt.write(out);
            return out.toByteArray();
        }
    }

    private byte[] pdf(String content) throws Exception {
        try (PDDocument doc = new PDDocument();
             ByteArrayOutputStream out = new ByteArrayOutputStream()) {

            PDType1Font normal = new PDType1Font(Standard14Fonts.FontName.HELVETICA);
            PDType1Font bold = new PDType1Font(Standard14Fonts.FontName.HELVETICA_BOLD);

            PDPage page = new PDPage(PDRectangle.A4);
            doc.addPage(page);
            PDPageContentStream stream = new PDPageContentStream(doc, page);

            float margin = 50;
            float y = page.getMediaBox().getHeight() - margin;

            stream.setNonStrokingColor(0, 133, 66);
            stream.addRect(0, page.getMediaBox().getHeight() - 12, page.getMediaBox().getWidth(), 12);
            stream.fill();

            for (String sourceLine : content.split("\\R", -1)) {
                List<String> wrapped = wrapForPdf(sourceLine, 88);
                if (wrapped.isEmpty()) wrapped = List.of("");

                for (String line : wrapped) {
                    if (y < margin + 20) {
                        stream.close();
                        page = new PDPage(PDRectangle.A4);
                        doc.addPage(page);
                        stream = new PDPageContentStream(doc, page);
                        y = page.getMediaBox().getHeight() - margin;
                    }

                    boolean heading = looksLikeHeading(sourceLine);
                    stream.beginText();
                    stream.setFont(heading ? bold : normal, heading ? 13 : 10);
                    stream.setNonStrokingColor(heading ? new Color(0, 110, 55) : new Color(30, 38, 34));
                    stream.newLineAtOffset(margin, y);
                    stream.showText(pdfSafe(line));
                    stream.endText();
                    y -= heading ? 19 : 14;
                }
                y -= 3;
            }

            stream.close();
            doc.save(out);
            return out.toByteArray();
        }
    }

    private String emailHtml(String content, String subject) {
        String safeSubject = subject == null || subject.isBlank() ? "" : escape(subject);
        return """
                <!doctype html>
                <html>
                <head>
                  <meta charset="UTF-8">
                  <style>
                    body{font-family:Arial,Helvetica,sans-serif;color:#243129;line-height:1.55}
                    .mail{max-width:820px;margin:30px auto;border:1px solid #d9e6de;border-radius:10px;overflow:hidden}
                    .head{padding:18px 22px;background:#eef8f2;border-bottom:1px solid #d9e6de}
                    .subject{color:#007b3f}
                    .body{padding:24px;white-space:pre-wrap}
                  </style>
                </head>
                <body>
                  <div class="mail">
                    <div class="head"><strong>Subject:</strong> <span class="subject">%s</span></div>
                    <div class="body">%s</div>
                  </div>
                </body>
                </html>
                """.formatted(safeSubject, escape(content));
    }

    private List<String> chunkLines(String content, int maxLines) {
        String[] lines = content.split("\\R", -1);
        List<String> chunks = new ArrayList<>();
        StringBuilder current = new StringBuilder();
        int count = 0;

        for (String line : lines) {
            if (count >= maxLines) {
                chunks.add(current.toString());
                current.setLength(0);
                count = 0;
            }
            if (!current.isEmpty()) current.append('\n');
            current.append(line);
            count++;
        }
        if (!current.isEmpty() || chunks.isEmpty()) chunks.add(current.toString());
        return chunks;
    }

    private List<String> wrapForPdf(String line, int width) {
        List<String> result = new ArrayList<>();
        if (line == null || line.isEmpty()) {
            result.add("");
            return result;
        }
        String remaining = line;
        while (remaining.length() > width) {
            int cut = remaining.lastIndexOf(' ', width);
            if (cut <= 0) cut = width;
            result.add(remaining.substring(0, cut));
            remaining = remaining.substring(cut).stripLeading();
        }
        result.add(remaining);
        return result;
    }

    private String pdfSafe(String value) {
        StringBuilder out = new StringBuilder();
        for (char ch : value.toCharArray()) {
            out.append(ch >= 32 && ch <= 255 ? ch : '?');
        }
        return out.toString();
    }

    private boolean looksLikeHeading(String line) {
        if (line == null) return false;
        String t = line.trim();
        return !t.isBlank()
                && t.length() <= 70
                && !t.endsWith(".")
                && !t.endsWith(";")
                && !t.contains("=")
                && (t.matches("^#{1,6}\\s+.*")
                    || t.endsWith(":")
                    || t.equals(t.toUpperCase())
                    || t.matches("^[A-Z][A-Za-z0-9 /&_-]{2,50}$"));
    }

    private boolean looksLikeCode(String line) {
        if (line == null) return false;
        String t = line.trim();
        return t.startsWith("package ")
                || t.startsWith("import ")
                || t.startsWith("@")
                || t.endsWith(";")
                || t.contains("=")
                || t.endsWith("{")
                || t.equals("}");
    }

    private String sanitizeFilename(String value) {
        return value.replaceAll("[^A-Za-z0-9._-]+", "-")
                .replaceAll("^-+|-+$", "");
    }

    private String escape(String value) {
        return value == null ? "" : value
                .replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;")
                .replace("\"", "&quot;");
    }

    public record ExportedFile(String filename, String contentType, byte[] bytes) {}
}
