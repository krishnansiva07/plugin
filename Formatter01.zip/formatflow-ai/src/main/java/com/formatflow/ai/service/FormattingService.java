package com.formatflow.ai.service;

import com.formatflow.ai.model.FormatModels.ContentStats;
import com.formatflow.ai.model.FormatModels.FormatRequest;
import com.formatflow.ai.model.FormatModels.FormatResult;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Service;

@Service
public class FormattingService {

    private final SessionKeyService sessionKeyService;
    private final LlmClient llmClient;
    private final PreviewRenderer previewRenderer;
    private final ContentDiffService contentDiffService;

    public FormattingService(SessionKeyService sessionKeyService,
                             LlmClient llmClient,
                             PreviewRenderer previewRenderer,
                             ContentDiffService contentDiffService) {
        this.sessionKeyService = sessionKeyService;
        this.llmClient = llmClient;
        this.previewRenderer = previewRenderer;
        this.contentDiffService = contentDiffService;
    }

    public FormatResult format(FormatRequest request, HttpSession session) {
        boolean enhance = "ENHANCE".equalsIgnoreCase(request.mode());

        String finalContent;
        if (enhance) {
            String apiKey = sessionKeyService.require(session);
            finalContent = llmClient.enhance(
                    apiKey,
                    request.content(),
                    request.audience(),
                    request.purpose(),
                    request.format()
            );
        } else {
            // The central guarantee of FormatFlow:
            // Preserve mode never sends content to the LLM and never rewrites it.
            finalContent = request.content();
        }

        ContentStats stats = contentDiffService.compare(request.content(), finalContent);
        String preview = previewRenderer.render(
                finalContent,
                request.format(),
                request.audience(),
                request.purpose(),
                request.emailSubject(),
                request.iconLevel()
        );

        return new FormatResult(
                finalContent,
                preview,
                stats,
                request.format(),
                enhance
        );
    }
}
