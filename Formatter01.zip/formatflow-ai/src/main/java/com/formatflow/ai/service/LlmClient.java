package com.formatflow.ai.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.formatflow.ai.config.LlmProperties;
import org.springframework.stereotype.Service;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.List;
import java.util.Map;

@Service
public class LlmClient {

    private final HttpClient httpClient;
    private final ObjectMapper objectMapper;
    private final LlmProperties properties;

    public LlmClient(HttpClient httpClient, ObjectMapper objectMapper, LlmProperties properties) {
        this.httpClient = httpClient;
        this.objectMapper = objectMapper;
        this.properties = properties;
    }

    public ValidationResult validateKey(String apiKey) {
        try {
            String response = chat(apiKey,
                    "Connection check. Reply with exactly: OK",
                    16,
                    0.0);
            if (response == null || response.isBlank()) {
                return new ValidationResult(false, "LLM returned an empty response.");
            }
            return new ValidationResult(true, "AI service connected.");
        } catch (LlmHttpException ex) {
            if (ex.statusCode == 401 || ex.statusCode == 403) {
                return new ValidationResult(false, "API key was rejected by the LLM service.");
            }
            return new ValidationResult(false, "LLM service returned HTTP " + ex.statusCode + ".");
        } catch (Exception ex) {
            return new ValidationResult(false, "Unable to connect to the configured LLM service: " + safeMessage(ex));
        }
    }

    public String enhance(String apiKey,
                          String content,
                          String audience,
                          String purpose,
                          String outputFormat) {
        String prompt = """
                You are the content enhancement stage of FormatFlow AI.

                The user has EXPLICITLY enabled content enhancement.

                Rules:
                1. Never invent facts, status, risks, dates, names, actions, decisions, numbers or technical details.
                2. Preserve code, configuration keys, URLs, identifiers and literal values exactly.
                3. Do not add claims that are not present in the source.
                4. You may improve grammar, clarity, organization and audience suitability.
                5. Keep the meaning faithful to the source.
                6. Return ONLY the enhanced content. Do not explain your work.

                Audience: %s
                Purpose: %s
                Output format: %s

                SOURCE CONTENT
                ----------------
                %s
                """.formatted(
                safe(audience),
                safe(purpose),
                safe(outputFormat),
                content
        );

        return chat(apiKey, prompt, 4096, 0.2);
    }

    public String chat(String apiKey, String prompt, int maxTokens, double temperature) {
        try {
            String body = objectMapper.writeValueAsString(Map.of(
                    "model", properties.getModel(),
                    "messages", List.of(Map.of(
                            "role", "user",
                            "content", prompt
                    )),
                    "temperature", temperature,
                    "max_tokens", maxTokens
            ));

            HttpRequest request = HttpRequest.newBuilder()
                    .uri(chatUri())
                    .timeout(Duration.ofSeconds(properties.getRequestTimeoutSeconds()))
                    .header("Content-Type", "application/json")
                    .header("Accept", "application/json")
                    .header(properties.getAuthHeader(), properties.getAuthPrefix() + apiKey)
                    .POST(HttpRequest.BodyPublishers.ofString(body))
                    .build();

            HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());

            if (response.statusCode() < 200 || response.statusCode() >= 300) {
                throw new LlmHttpException(response.statusCode());
            }

            JsonNode json = objectMapper.readTree(response.body());
            JsonNode content = json.at("/choices/0/message/content");
            if (content.isMissingNode() || content.isNull()) {
                throw new IllegalStateException("LLM response does not contain choices[0].message.content.");
            }
            return content.asText();
        } catch (LlmHttpException ex) {
            throw ex;
        } catch (Exception ex) {
            throw new IllegalStateException("LLM request failed: " + safeMessage(ex), ex);
        }
    }

    private URI chatUri() {
        String base = properties.getBaseUrl();
        if (base == null || base.isBlank()) {
            throw new IllegalStateException("formatflow.llm.base-url is not configured.");
        }
        base = base.endsWith("/") ? base.substring(0, base.length() - 1) : base;
        String path = properties.getChatPath() == null ? "/chat/completions" : properties.getChatPath();
        path = path.startsWith("/") ? path : "/" + path;
        return URI.create(base + path);
    }

    private static String safe(String value) {
        return value == null || value.isBlank() ? "General" : value;
    }

    private static String safeMessage(Exception ex) {
        String msg = ex.getMessage();
        if (msg == null || msg.isBlank()) {
            return ex.getClass().getSimpleName();
        }
        return msg.length() > 180 ? msg.substring(0, 180) : msg;
    }

    public record ValidationResult(boolean valid, String message) {}

    private static final class LlmHttpException extends RuntimeException {
        private final int statusCode;

        private LlmHttpException(int statusCode) {
            super("LLM HTTP " + statusCode);
            this.statusCode = statusCode;
        }
    }
}
