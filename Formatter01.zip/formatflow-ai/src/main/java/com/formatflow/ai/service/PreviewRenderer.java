package com.formatflow.ai.service;

import org.springframework.stereotype.Service;
import org.springframework.web.util.HtmlUtils;

import java.util.regex.Pattern;

@Service
public class PreviewRenderer {

    private static final Pattern PROPERTY = Pattern.compile("^[A-Za-z0-9_.-]+\\s*=.*$");
    private static final Pattern JAVAISH = Pattern.compile(
            "^\\s*(package\\s+|import\\s+|@\\w+|public\\s+|private\\s+|protected\\s+|class\\s+|interface\\s+|record\\s+|return\\s+|if\\s*\\(|for\\s*\\(|while\\s*\\(|try\\s*\\{|catch\\s*\\(|\\}|\\{).*"
    );

    public String render(String content,
                         String format,
                         String audience,
                         String purpose,
                         String emailSubject,
                         String iconLevel) {
        String body = renderBody(content, iconLevel);
        String tags = """
                <div class="preview-meta">
                  <span>%s</span>
                  <span>%s</span>
                  <span>%s</span>
                </div>
                """.formatted(
                esc(format),
                esc(audience),
                esc(purpose == null || purpose.isBlank() ? "General" : purpose)
        );

        if ("EMAIL".equalsIgnoreCase(format)) {
            String subject = emailSubject == null || emailSubject.isBlank()
                    ? "<span class=\"subject-placeholder\">Subject not added</span>"
                    : esc(emailSubject);

            return """
                    <section class="email-preview">
                      %s
                      <div class="email-header">
                        <div><strong>Subject:</strong> %s</div>
                      </div>
                      <div class="email-body">%s</div>
                    </section>
                    """.formatted(tags, subject, body);
        }

        return """
                <section class="document-preview">
                  %s
                  <div class="document-body">%s</div>
                </section>
                """.formatted(tags, body);
    }

    public String renderStandaloneHtml(String content, String title) {
        return """
                <!doctype html>
                <html>
                <head>
                  <meta charset="UTF-8">
                  <title>%s</title>
                  <style>
                    body{font-family:Arial,Helvetica,sans-serif;color:#1d2822;max-width:960px;margin:40px auto;line-height:1.55}
                    h1,h2,h3,h4{color:#007a3d}
                    pre,.code-line{font-family:Consolas,monospace;background:#f4f7f5;border-left:4px solid #00884a;padding:10px;white-space:pre-wrap}
                    .line{margin:7px 0}.blank{height:10px}
                  </style>
                </head>
                <body>%s</body>
                </html>
                """.formatted(esc(title == null ? "FormatFlow AI" : title), renderBody(content, "NONE"));
    }

    private String renderBody(String content, String iconLevel) {
        if (content == null || content.isEmpty()) {
            return "<div class=\"empty-content\">No content</div>";
        }

        StringBuilder html = new StringBuilder();
        boolean inFence = false;
        StringBuilder fenced = new StringBuilder();

        String[] lines = content.split("\\R", -1);
        for (String raw : lines) {
            String trimmed = raw.trim();

            if (trimmed.startsWith("```")) {
                if (inFence) {
                    html.append("<pre>").append(esc(fenced.toString())).append("</pre>");
                    fenced.setLength(0);
                    inFence = false;
                } else {
                    inFence = true;
                }
                continue;
            }

            if (inFence) {
                if (!fenced.isEmpty()) fenced.append('\n');
                fenced.append(raw);
                continue;
            }

            if (trimmed.isEmpty()) {
                html.append("<div class=\"blank\"></div>");
            } else if (trimmed.matches("^#{1,6}\\s+.*")) {
                int level = Math.min(4, countHashes(trimmed));
                String text = trimmed.substring(countHashes(trimmed)).trim();
                html.append("<h").append(level).append(">")
                        .append(iconFor(text, iconLevel))
                        .append(esc(text))
                        .append("</h").append(level).append(">");
            } else if (looksLikeHeading(trimmed)) {
                html.append("<h3>")
                        .append(iconFor(trimmed, iconLevel))
                        .append(esc(trimmed))
                        .append("</h3>");
            } else if (PROPERTY.matcher(trimmed).matches() || JAVAISH.matcher(trimmed).matches()) {
                html.append("<div class=\"code-line\">").append(esc(raw)).append("</div>");
            } else if (trimmed.startsWith("- ") || trimmed.startsWith("* ") || trimmed.matches("^\\d+[.)]\\s+.*")) {
                html.append("<div class=\"bullet-line\">").append(esc(raw)).append("</div>");
            } else {
                html.append("<div class=\"line\">").append(linkify(esc(raw))).append("</div>");
            }
        }

        if (inFence) {
            html.append("<pre>").append(esc(fenced.toString())).append("</pre>");
        }

        return html.toString();
    }

    private static boolean looksLikeHeading(String value) {
        return value.length() <= 70
                && !value.endsWith(".")
                && !value.endsWith(";")
                && !value.contains("=")
                && (
                    value.equals(value.toUpperCase())
                    || value.endsWith(":")
                    || value.matches("^[A-Z][A-Za-z0-9 /&_-]{2,50}$")
                );
    }

    private static int countHashes(String value) {
        int count = 0;
        while (count < value.length() && value.charAt(count) == '#') {
            count++;
        }
        return count;
    }

    private static String iconFor(String text, String iconLevel) {
        if (iconLevel == null || "NONE".equalsIgnoreCase(iconLevel)) {
            return "";
        }
        String lower = text.toLowerCase();
        String icon = "";
        if (lower.contains("risk") || lower.contains("warning") || lower.contains("block")) icon = "⚠ ";
        else if (lower.contains("complete") || lower.contains("success")) icon = "✓ ";
        else if (lower.contains("config")) icon = "⚙ ";
        else if (lower.contains("api") || lower.contains("url")) icon = "↗ ";
        else if (lower.contains("test")) icon = "◇ ";
        else if (lower.contains("security") || lower.contains("auth")) icon = "◆ ";
        else if (lower.contains("next") || lower.contains("action")) icon = "→ ";
        else if ("RICH".equalsIgnoreCase(iconLevel)) icon = "• ";
        return "<span class=\"smart-icon\">" + icon + "</span>";
    }

    private static String linkify(String escaped) {
        return escaped.replaceAll(
                "(https?://[A-Za-z0-9._~:/?#\\[\\]@!$&amp;'()*+,;=%-]+)",
                "<a href=\"$1\" target=\"_blank\" rel=\"noopener noreferrer\">$1</a>"
        );
    }

    private static String esc(String value) {
        return HtmlUtils.htmlEscape(value == null ? "" : value);
    }
}
