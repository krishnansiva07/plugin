const state = {
    format: "CONFLUENCE",
    originalContent: "",
    finalContent: "",
    previewHtml: "",
    currentPreview: "formatted"
};

const $ = id => document.getElementById(id);

document.addEventListener("DOMContentLoaded", async () => {
    bindEvents();
    updateCounts();
    await checkSession();
});

function bindEvents() {
    $("toggleKey").addEventListener("click", () => {
        $("apiKey").type = $("apiKey").type === "password" ? "text" : "password";
    });

    $("validateKeyBtn").addEventListener("click", validateKey);
    $("apiKey").addEventListener("keydown", e => {
        if (e.key === "Enter") validateKey();
    });

    $("disconnectBtn").addEventListener("click", disconnect);
    $("changeKeyBtn").addEventListener("click", () => {
        $("apiKey").value = "";
        showAuth();
    });

    document.querySelectorAll(".input-tabs .tab").forEach(button => {
        button.addEventListener("click", () => switchInputTab(button.dataset.tab));
    });

    $("contentInput").addEventListener("input", updateCounts);
    $("uploadBtn").addEventListener("click", uploadFile);
    $("urlImportBtn").addEventListener("click", importUrl);

    document.querySelectorAll(".format-card").forEach(card => {
        card.addEventListener("click", () => selectFormat(card));
    });

    document.querySelectorAll('input[name="mode"]').forEach(radio => {
        radio.addEventListener("change", updateModeCards);
    });

    $("previewBtn").addEventListener("click", preview);
    $("copyBtn").addEventListener("click", copyOutput);
    $("downloadBtn").addEventListener("click", downloadOutput);

    document.querySelectorAll(".mini-tab").forEach(button => {
        button.addEventListener("click", () => {
            state.currentPreview = button.dataset.preview;
            document.querySelectorAll(".mini-tab").forEach(x => x.classList.remove("active"));
            button.classList.add("active");
            renderPreviewMode();
        });
    });
}

async function checkSession() {
    try {
        const response = await fetch("/api/session/status");
        const data = await response.json();
        $("authEndpoint").textContent = `Model: ${data.model || "Not configured"} • Endpoint: ${data.baseUrl || "Not configured"}`;
        if (data.connected) showApp();
        else showAuth();
    } catch {
        showAuth();
        showMessage("authMessage", "Unable to reach FormatFlow server.", true);
    }
}

async function validateKey() {
    const apiKey = $("apiKey").value.trim();
    if (!apiKey) {
        showMessage("authMessage", "Enter the LLM API key.", true);
        return;
    }

    setButtonBusy("validateKeyBtn", true, "Validating...");
    showMessage("authMessage", "");

    try {
        const response = await fetch("/api/session/validate", {
            method: "POST",
            headers: {"Content-Type": "application/json"},
            body: JSON.stringify({apiKey})
        });
        const data = await response.json();
        if (!data.valid) {
            showMessage("authMessage", data.message || "API key validation failed.", true);
            return;
        }

        $("apiKey").value = "";
        showMessage("authMessage", "Connected.", false);
        showApp();
    } catch (e) {
        showMessage("authMessage", "Unable to validate the key.", true);
    } finally {
        setButtonBusy("validateKeyBtn", false, "Validate & Continue");
    }
}

async function disconnect() {
    try {
        await fetch("/api/session/disconnect", {method: "POST"});
    } finally {
        state.finalContent = "";
        state.previewHtml = "";
        showAuth();
    }
}

function showAuth() {
    $("authGate").classList.remove("hidden");
    $("appShell").classList.add("hidden");
}

function showApp() {
    $("authGate").classList.add("hidden");
    $("appShell").classList.remove("hidden");
}

function switchInputTab(name) {
    document.querySelectorAll(".input-tabs .tab").forEach(x =>
        x.classList.toggle("active", x.dataset.tab === name)
    );
    ["paste", "upload", "url"].forEach(tab => {
        $(tab + "Tab").classList.toggle("active", tab === name);
    });
}

function selectFormat(card) {
    state.format = card.dataset.format;
    document.querySelectorAll(".format-card").forEach(x => x.classList.remove("selected"));
    card.classList.add("selected");
    $("emailSubjectWrap").classList.toggle("hidden", state.format !== "EMAIL");
    $("downloadBtn").textContent = `Download ${displayFormat(state.format)}`;
}

function updateModeCards() {
    document.querySelectorAll(".mode-card").forEach(card => {
        const radio = card.querySelector("input");
        card.classList.toggle("selected", radio.checked);
    });
    const mode = selectedMode();
    $("topProtectionText").textContent = mode === "PRESERVE"
        ? "Formatting only • original content protected"
        : "Enhancement enabled • changes will be measured";
}

function selectedMode() {
    return document.querySelector('input[name="mode"]:checked').value;
}

function updateCounts() {
    const text = $("contentInput").value;
    $("wordCount").textContent = `${wordCount(text)} words`;
    $("charCount").textContent = `${text.length} characters`;
}

async function uploadFile() {
    const file = $("fileInput").files[0];
    if (!file) {
        showMessage("importMessage", "Choose a file first.", true);
        return;
    }

    const body = new FormData();
    body.append("file", file);
    showMessage("importMessage", "Importing...");

    try {
        const response = await fetch("/api/import/file", {method: "POST", body});
        const data = await jsonOrError(response);
        $("contentInput").value = data.content;
        updateCounts();
        switchInputTab("paste");
        showMessage("importMessage", `Imported ${data.words} words from ${data.source}.`, false);
    } catch (e) {
        handleApiError(e, "importMessage");
    }
}

async function importUrl() {
    const url = $("urlInput").value.trim();
    if (!url) {
        showMessage("importMessage", "Enter a URL.", true);
        return;
    }

    showMessage("importMessage", "Fetching public page...");
    setButtonBusy("urlImportBtn", true, "Importing...");

    try {
        const response = await fetch("/api/import/url", {
            method: "POST",
            headers: {"Content-Type": "application/json"},
            body: JSON.stringify({url})
        });
        const data = await jsonOrError(response);
        $("contentInput").value = data.content;
        updateCounts();
        switchInputTab("paste");
        showMessage("importMessage", `Imported ${data.words} words from ${data.source}.`, false);
    } catch (e) {
        handleApiError(e, "importMessage");
    } finally {
        setButtonBusy("urlImportBtn", false, "Import Content");
    }
}

async function preview() {
    const content = $("contentInput").value;
    if (!content.trim()) {
        showMessage("importMessage", "Add some content before formatting.", true);
        return;
    }

    const request = {
        content,
        audience: $("audience").value,
        purpose: $("purpose").value,
        format: state.format,
        mode: selectedMode(),
        visualStyle: $("visualStyle").value,
        iconLevel: $("iconLevel").value,
        emailSubject: $("emailSubject").value
    };

    setButtonBusy("previewBtn", true, selectedMode() === "ENHANCE" ? "Enhancing..." : "Formatting...");

    try {
        const response = await fetch("/api/format/preview", {
            method: "POST",
            headers: {"Content-Type": "application/json"},
            body: JSON.stringify(request)
        });
        const data = await jsonOrError(response);

        state.originalContent = content;
        state.finalContent = data.finalContent;
        state.previewHtml = data.previewHtml;

        renderPreviewMode();
        updateStats(data.stats);
        $("copyBtn").disabled = false;
        $("downloadBtn").disabled = false;
        $("downloadBtn").textContent = `Download ${displayFormat(state.format)}`;
    } catch (e) {
        if (e.status === 401) showAuth();
        else alert(e.message || "Formatting failed.");
    } finally {
        setButtonBusy("previewBtn", false, "✦ Format & Preview");
    }
}

function renderPreviewMode() {
    if (!state.finalContent && !state.previewHtml) return;

    if (state.currentPreview === "formatted") {
        $("previewArea").innerHTML = state.previewHtml;
    } else if (state.currentPreview === "original") {
        $("previewArea").innerHTML = `<div class="side-box"><h4>Original Content</h4><pre>${escapeHtml(state.originalContent)}</pre></div>`;
    } else {
        $("previewArea").innerHTML = `
            <div class="side-by-side">
              <div class="side-box"><h4>Original</h4><pre>${escapeHtml(state.originalContent)}</pre></div>
              <div class="side-box"><h4>Formatted / Enhanced</h4><pre>${escapeHtml(state.finalContent)}</pre></div>
            </div>`;
    }
}

function updateStats(stats) {
    $("statOriginal").textContent = stats.originalWords;
    $("statFormatted").textContent = stats.formattedWords;
    $("statAdded").textContent = stats.addedWords;
    $("statRemoved").textContent = stats.removedWords;
    $("statStatus").textContent = stats.exactContentPreserved ? "100% Preserved" : "Changed";
    $("statStatus").style.color = stats.exactContentPreserved ? "var(--green)" : "#996300";
}

async function copyOutput() {
    if (!state.finalContent) return;
    try {
        if (navigator.clipboard && window.ClipboardItem && state.currentPreview === "formatted") {
            const html = new Blob([state.previewHtml], {type: "text/html"});
            const text = new Blob([state.finalContent], {type: "text/plain"});
            await navigator.clipboard.write([new ClipboardItem({
                "text/html": html,
                "text/plain": text
            })]);
        } else {
            await navigator.clipboard.writeText(state.finalContent);
        }
        $("copyBtn").textContent = "Copied";
        setTimeout(() => $("copyBtn").textContent = "Copy", 1200);
    } catch {
        await navigator.clipboard.writeText(state.finalContent);
    }
}

async function downloadOutput() {
    if (!state.finalContent) return;

    const request = {
        content: state.finalContent,
        format: state.format,
        emailSubject: $("emailSubject").value,
        filename: "formatflow-output"
    };

    setButtonBusy("downloadBtn", true, "Preparing...");

    try {
        const response = await fetch("/api/export", {
            method: "POST",
            headers: {"Content-Type": "application/json"},
            body: JSON.stringify(request)
        });

        if (!response.ok) {
            const error = await response.json().catch(() => ({error: "Export failed."}));
            throw new Error(error.error || "Export failed.");
        }

        const blob = await response.blob();
        const disposition = response.headers.get("Content-Disposition") || "";
        const match = disposition.match(/filename="?([^";]+)"?/i);
        const filename = match ? decodeURIComponent(match[1]) : `formatflow-output.${extensionFor(state.format)}`;

        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        a.remove();
        URL.revokeObjectURL(url);
    } catch (e) {
        alert(e.message || "Export failed.");
    } finally {
        setButtonBusy("downloadBtn", false, `Download ${displayFormat(state.format)}`);
    }
}

async function jsonOrError(response) {
    const data = await response.json().catch(() => ({}));
    if (!response.ok) {
        const error = new Error(data.error || `Request failed (${response.status}).`);
        error.status = response.status;
        throw error;
    }
    return data;
}

function handleApiError(error, messageId) {
    if (error.status === 401) {
        showAuth();
        return;
    }
    showMessage(messageId, error.message || "Request failed.", true);
}

function showMessage(id, text, error = false) {
    const node = $(id);
    node.textContent = text || "";
    node.classList.toggle("error", !!text && error);
    node.classList.toggle("success", !!text && !error);
}

function setButtonBusy(id, busy, label) {
    const button = $(id);
    button.disabled = busy;
    button.textContent = label;
}

function wordCount(text) {
    const t = (text || "").trim();
    return t ? t.split(/\s+/).length : 0;
}

function escapeHtml(value) {
    return (value || "")
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;");
}

function displayFormat(format) {
    return ({
        CONFLUENCE: "Confluence",
        WORD: "Word",
        POWERPOINT: "PowerPoint",
        PDF: "PDF",
        EMAIL: "Email",
        MARKDOWN: "Markdown",
        HTML: "HTML"
    })[format] || format;
}

function extensionFor(format) {
    return ({
        CONFLUENCE: "html",
        WORD: "docx",
        POWERPOINT: "pptx",
        PDF: "pdf",
        EMAIL: "html",
        MARKDOWN: "md",
        HTML: "html"
    })[format] || "txt";
}
