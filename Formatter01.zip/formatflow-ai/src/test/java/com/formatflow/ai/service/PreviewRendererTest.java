package com.formatflow.ai.service;

import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

class PreviewRendererTest {

    private final PreviewRenderer renderer = new PreviewRenderer();

    @Test
    void escapesUnsafeHtml() {
        String html = renderer.render(
                "<script>alert('x')</script>",
                "HTML",
                "Technical Team",
                "General",
                "",
                "NONE"
        );

        assertThat(html).doesNotContain("<script>");
        assertThat(html).contains("&lt;script&gt;");
    }
}
