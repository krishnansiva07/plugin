package com.llmart.llm.service;

import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.file.*;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Resolves filesystem paths explicitly supplied by the user in a prompt.
 *
 * Prompt resource model:
 * - PRIMARY_WORKSPACE: active writable project/workspace;
 * - SECONDARY_WORKSPACE: another explicitly supplied writable project/directory;
 * - REFERENCE: read-only code/project used for comparison;
 * - INPUT: read-only source material such as requirements, recordings or data files;
 * - DIAGNOSTIC: read-only evidence such as logs, traces, screenshots or reports.
 *
 * Security model:
 * - only paths that actually exist are accepted;
 * - explicit user labels take precedence over project-root inference;
 * - INPUT/DIAGNOSTIC files stay exact read-only files even when their parent is another project;
 * - model-invented paths never become resources because tools address resolver-issued aliases.
 */
@Service
public class PromptResourceResolver {
    private static final Set<String> PROJECT_MARKERS = Set.of(
            "pom.xml", "build.gradle", "build.gradle.kts", "settings.gradle", "settings.gradle.kts",
            "package.json", "pyproject.toml", "setup.py", "requirements.txt", "go.mod", "cargo.toml",
            "cmakelists.txt", "makefile", "build.xml", "package.swift", "pubspec.yaml", "composer.json",
            "gemfile", "workspace", "workspace.bazel", "module.bazel", "build.sbt", "mix.exs",
            "project.clj", "build.zig", "stack.yaml", "cabal.project"
    );
    private static final Set<String> DIAGNOSTIC_EXTENSIONS = Set.of(
            "log", "out", "err", "png", "jpg", "jpeg", "gif", "webp", "bmp", "har", "trace", "dmp"
    );

    private static final Pattern BACKTICK = Pattern.compile("`([^`]+)`");
    private static final Pattern QUOTED = Pattern.compile("[\"']([^\"'\\r\\n]+)[\"']");
    private static final Pattern SMART_QUOTED = Pattern.compile("[“‘]([^”’\\r\\n]+)[”’]");
    private static final Pattern WINDOWS = Pattern.compile("(?i)([A-Z]:[\\\\/][^\\r\\n`\"<>|?*]+)");
    private static final Pattern UNC = Pattern.compile("(\\\\\\\\[^\\r\\n`\"<>|?*]+)");
    private static final Pattern POSIX = Pattern.compile("(?<![A-Za-z0-9:])(/(?:[^\\s`\"'<>|]+/?)+)");

    public Optional<Path> primaryProjectPath(String prompt) {
        Path best = null;
        int bestScore = Integer.MIN_VALUE;
        int order = 0;
        for (Path path : explicitExistingPaths(prompt)) {
            try {
                ResourceRole intent = explicitRole(prompt, path);
                // Reference/input/diagnostic material must never silently become the active workspace.
                if (intent == ResourceRole.REFERENCE || intent == ResourceRole.INPUT || intent == ResourceRole.DIAGNOSTIC) {
                    order++;
                    continue;
                }

                Path candidate = null;
                if (Files.isDirectory(path)) {
                    Path project = findProjectRoot(path);
                    candidate = project != null ? project : path.toRealPath();
                } else if (Files.isRegularFile(path) && !isStandaloneDiagnostic(path)) {
                    Path project = findProjectRoot(path.getParent());
                    if (project != null && isLikelyProjectFile(path)) candidate = project;
                }
                if (candidate == null) { order++; continue; }

                int score = primaryPreference(prompt, path) - order++;
                if (score > bestScore) {
                    best = candidate;
                    bestScore = score;
                }
            } catch (Exception ignored) { order++; }
        }
        return Optional.ofNullable(best);
    }

    public Resolution resolve(String prompt, Path primaryRoot) {
        LinkedHashMap<String, ResolvedResource> byKey = new LinkedHashMap<>();
        Path canonicalPrimary = canonical(primaryRoot);
        if (canonicalPrimary != null) {
            byKey.put("workspace", new ResolvedResource("workspace", canonicalPrimary, null,
                    ResourceKind.PROJECT, ResourceRole.PRIMARY_WORKSPACE, true, true, "active workspace"));
        }

        int sequence = 1;
        for (Path explicit : explicitExistingPaths(prompt)) {
            try {
                Path canonical = explicit.toRealPath();
                if (canonicalPrimary != null && canonical.startsWith(canonicalPrimary)) continue;

                ResourceRole intendedRole = explicitRole(prompt, canonical);

                if (Files.isDirectory(canonical)) {
                    boolean preserveExact = intendedRole == ResourceRole.INPUT || intendedRole == ResourceRole.DIAGNOSTIC;
                    Path projectRoot = preserveExact ? null : findProjectRoot(canonical);
                    Path root = projectRoot != null ? projectRoot : canonical;
                    if (canonicalPrimary != null && root.equals(canonicalPrimary)) continue;
                    String key = resourceIdentity(root, null);
                    if (byKey.values().stream().anyMatch(r -> resourceIdentity(r.root(), r.focus()).equals(key))) continue;
                    ResourceKind kind = projectRoot != null ? ResourceKind.PROJECT : ResourceKind.DIRECTORY;
                    ResourceRole role = intendedRole == null ? ResourceRole.SECONDARY_WORKSPACE : intendedRole;
                    boolean writable = role == ResourceRole.SECONDARY_WORKSPACE;
                    String alias = uniqueAlias(aliasBase(root, sequence++), byKey.keySet());
                    byKey.put(alias, new ResolvedResource(alias, root, null, kind, role, writable, false,
                            reasonFor(role, kind, false)));
                } else if (Files.isRegularFile(canonical)) {
                    // Explicit INPUT/DIAGNOSTIC intent wins over parent project inference.
                    if (intendedRole == ResourceRole.INPUT || intendedRole == ResourceRole.DIAGNOSTIC) {
                        String alias = uniqueAlias(aliasBase(canonical, sequence++), byKey.keySet());
                        byKey.put(alias, new ResolvedResource(alias, canonical, null,
                                ResourceKind.FILE, intendedRole, false, false, reasonFor(intendedRole, ResourceKind.FILE, true)));
                        continue;
                    }

                    Path projectRoot = findProjectRoot(canonical.getParent());
                    boolean promotable = projectRoot != null && !isStandaloneDiagnostic(canonical) && isLikelyProjectFile(canonical);
                    if (promotable) {
                        if (canonicalPrimary != null && projectRoot.equals(canonicalPrimary)) continue;
                        Path focus = projectRoot.relativize(canonical);
                        String existingAlias = findAliasForRoot(byKey, projectRoot);
                        ResourceRole role = intendedRole == ResourceRole.REFERENCE ? ResourceRole.REFERENCE : ResourceRole.SECONDARY_WORKSPACE;
                        boolean writable = role == ResourceRole.SECONDARY_WORKSPACE;
                        if (existingAlias != null) {
                            ResolvedResource old = byKey.get(existingAlias);
                            ResolvedResource upgraded = old.focus() == null ? old.withFocus(focus) : old;
                            if (role == ResourceRole.REFERENCE && upgraded.role() != ResourceRole.REFERENCE) {
                                upgraded = upgraded.withRole(ResourceRole.REFERENCE, false, "read-only reference project inferred from explicit file");
                            }
                            byKey.put(existingAlias, upgraded);
                        } else {
                            String alias = uniqueAlias(aliasBase(projectRoot, sequence++), byKey.keySet());
                            byKey.put(alias, new ResolvedResource(alias, projectRoot, focus,
                                    ResourceKind.PROJECT, role, writable, false,
                                    role == ResourceRole.REFERENCE
                                            ? "read-only reference project inferred from explicit file"
                                            : "project inferred from explicit file"));
                        }
                    } else {
                        ResourceRole role = intendedRole == ResourceRole.REFERENCE
                                ? ResourceRole.REFERENCE
                                : (isStandaloneDiagnostic(canonical) ? ResourceRole.DIAGNOSTIC : ResourceRole.INPUT);
                        String alias = uniqueAlias(aliasBase(canonical, sequence++), byKey.keySet());
                        byKey.put(alias, new ResolvedResource(alias, canonical, null,
                                ResourceKind.FILE, role, false, false, reasonFor(role, ResourceKind.FILE, true)));
                    }
                }
            } catch (Exception ignored) { }
        }
        return new Resolution(List.copyOf(byKey.values()));
    }

    public List<Path> explicitExistingPaths(String prompt) {
        if (prompt == null || prompt.isBlank()) return List.of();
        LinkedHashSet<String> candidates = new LinkedHashSet<>();

        collect(BACKTICK, prompt, candidates);
        collect(QUOTED, prompt, candidates);
        collect(SMART_QUOTED, prompt, candidates);

        for (String line : prompt.split("\\R")) {
            String trimmed = line.trim().replaceFirst("^[\\-*•]+\\s*", "");
            if (trimmed.isBlank()) continue;
            if (looksPathLike(trimmed)) candidates.add(trimmed);
            LabeledValue labeled = labeledValue(trimmed);
            if (labeled != null && looksPathLike(labeled.value())) candidates.add(labeled.value());
        }
        collect(WINDOWS, prompt, candidates);
        collect(UNC, prompt, candidates);
        collect(POSIX, prompt, candidates);

        LinkedHashSet<Path> found = new LinkedHashSet<>();
        for (String raw : candidates) {
            Path path = existingPathFromCandidate(raw);
            if (path != null) found.add(path);
        }
        return List.copyOf(found);
    }

    private int primaryPreference(String prompt, Path path) {
        String label = labelForPath(prompt, path).toLowerCase(Locale.ROOT);
        if (containsAny(label, "reference", "baseline", "known good", "known-good", "comparison source", "compare source")) return -1000;
        if (isInputLabel(label) || isDiagnosticLabel(label)) return -900;
        if (containsAny(label, "broken", "target", "primary", "main", "workspace", "project to fix", "application to fix", "project path")) return 500;
        if (containsAny(label, "project", "frontend", "backend", "service", "application", "app")) return 200;
        if (containsAny(label, "issue file", "source file", "file to fix")) return 100;
        return 0;
    }

    private ResourceRole explicitRole(String prompt, Path path) {
        String label = labelForPath(prompt, path).toLowerCase(Locale.ROOT);
        if (containsAny(label, "reference", "baseline", "known good", "known-good", "comparison source", "compare source")) return ResourceRole.REFERENCE;
        if (isDiagnosticLabel(label) || (Files.isRegularFile(path) && isStandaloneDiagnostic(path))) return ResourceRole.DIAGNOSTIC;
        if (isInputLabel(label)) return ResourceRole.INPUT;
        return null;
    }

    private boolean isDiagnosticLabel(String label) {
        return containsAny(label,
                "diagnostic", "diagnostics", "issue log", "error log", "failure log", "console log",
                "console output", "stack trace", "stacktrace", "crash dump", "trace file", "screenshot",
                "failure screenshot", "test report", "build report", "ci log", "jenkins log");
    }

    private boolean isInputLabel(String label) {
        return containsAny(label,
                "input", "input file", "input path", "recording", "recorded", "recorded flow", "flow file",
                "requirements", "requirement file", "specification", "spec file", "test data", "data file",
                "source material", "attachment", "document", "artifact file");
    }

    private String reasonFor(ResourceRole role, ResourceKind kind, boolean explicitFile) {
        return switch (role) {
            case PRIMARY_WORKSPACE -> "active workspace";
            case SECONDARY_WORKSPACE -> kind == ResourceKind.PROJECT ? "explicit secondary project path" : "explicit secondary workspace path";
            case REFERENCE -> kind == ResourceKind.PROJECT ? "explicit read-only reference project" : "explicit read-only reference resource";
            case INPUT -> explicitFile ? "explicit read-only input file" : "explicit read-only input resource";
            case DIAGNOSTIC -> explicitFile ? "explicit read-only diagnostic file" : "explicit read-only diagnostic resource";
        };
    }

    private String labelForPath(String prompt, Path target) {
        if (prompt == null || prompt.isBlank() || target == null) return "";
        Path canonicalTarget = canonical(target);
        for (String line : prompt.split("\\R")) {
            String trimmed = line.trim().replaceFirst("^[\\-*•]+\\s*", "");
            LabeledValue labeled = labeledValue(trimmed);
            if (labeled == null) continue;
            Path candidate = existingPathFromCandidate(labeled.value());
            Path canonicalCandidate = canonical(candidate);
            if (canonicalCandidate != null && canonicalCandidate.equals(canonicalTarget)) return labeled.label();
        }
        return "";
    }

    /** Supports common prompt forms such as "Project path: ...", "Project path = ...",
     * "Project path - ..." and "Project path is ..." without misreading a bare Windows drive prefix. */
    private LabeledValue labeledValue(String line) {
        if (line == null) return null;
        String value = line.trim();
        if (value.isBlank() || value.matches("(?i)^[A-Z]:[\\\\/].*")) return null;
        int split = -1;
        int width = 1;
        int colon = value.indexOf(':');
        if (colon > 1) split = colon;
        int equals = value.indexOf('=');
        if (equals > 0 && (split < 0 || equals < split)) split = equals;
        for (String separator : List.of(" is ", " - ", " -> ", " => ")) {
            int pos = value.toLowerCase(Locale.ROOT).indexOf(separator.trim().equals("is") ? " is " : separator);
            if (pos > 0 && (split < 0 || pos < split)) { split = pos; width = separator.length(); }
        }
        if (split <= 0 || split >= value.length() - width) return null;
        String label = value.substring(0, split).trim();
        String candidate = value.substring(split + width).trim();
        if (label.length() > 120 || candidate.isBlank()) return null;
        return new LabeledValue(label, candidate);
    }

    private record LabeledValue(String label, String value) { }

    private boolean containsAny(String value, String... needles) {
        for (String needle : needles) if (value.contains(needle)) return true;
        return false;
    }

    private void collect(Pattern pattern, String text, Set<String> out) {
        Matcher matcher = pattern.matcher(text);
        while (matcher.find()) out.add(matcher.group(1));
    }

    private boolean looksPathLike(String value) {
        if (value == null || value.isBlank()) return false;
        String v = stripWrapping(value.trim());
        if (v.matches("(?i)^[A-Z]:[\\\\/].+")) return true;
        if (v.startsWith("\\\\")) return true;
        return v.startsWith("/") || v.startsWith("~/") || v.startsWith("./") || v.startsWith("../");
    }

    private Path existingPathFromCandidate(String raw) {
        if (raw == null) return null;
        String candidate = stripWrapping(raw.trim());
        candidate = candidate.replaceFirst("[;,]+$", "").trim();
        if (candidate.isBlank() || candidate.startsWith("http://") || candidate.startsWith("https://")) return null;
        if (candidate.regionMatches(true, 0, "file:", 0, 5)) {
            try {
                Path p = Paths.get(java.net.URI.create(candidate));
                if (Files.exists(p, LinkOption.NOFOLLOW_LINKS)) return p.toRealPath();
            } catch (Exception ignored) { }
        }

        String current = candidate;
        for (int attempt = 0; attempt < 30 && !current.isBlank(); attempt++) {
            Path p = toPath(current);
            if (p != null && Files.exists(p, LinkOption.NOFOLLOW_LINKS)) {
                try { return p.toRealPath(); }
                catch (IOException ignored) { return p.toAbsolutePath().normalize(); }
            }
            int cut = lastDelimiter(current);
            if (cut <= 0) break;
            current = current.substring(0, cut).replaceFirst("[.,;:]+$", "").trim();
        }
        return null;
    }

    private Path toPath(String value) {
        try {
            String expanded = value;
            if (expanded.startsWith("~/") || expanded.startsWith("~\\")) {
                expanded = System.getProperty("user.home", "") + expanded.substring(1);
            }
            return Path.of(expanded).toAbsolutePath().normalize();
        } catch (Exception ignored) { return null; }
    }

    private int lastDelimiter(String value) {
        int space = Math.max(value.lastIndexOf(' '), value.lastIndexOf('\t'));
        int comma = value.lastIndexOf(',');
        int semi = value.lastIndexOf(';');
        return Math.max(space, Math.max(comma, semi));
    }

    private String stripWrapping(String value) {
        String v = value == null ? "" : value.trim();
        while (v.length() >= 2 && ((v.startsWith("`") && v.endsWith("`")) ||
                (v.startsWith("\"") && v.endsWith("\"")) || (v.startsWith("'") && v.endsWith("'")) ||
                (v.startsWith("“") && v.endsWith("”")) || (v.startsWith("‘") && v.endsWith("’")) ||
                (v.startsWith("(") && v.endsWith(")")) || (v.startsWith("[") && v.endsWith("]")))) {
            v = v.substring(1, v.length() - 1).trim();
        }
        return v;
    }

    private Path findProjectRoot(Path start) {
        Path current = canonical(start);
        int depth = 0;
        while (current != null && depth++ < 30) {
            if (looksLikeProjectRoot(current)) return current;
            current = current.getParent();
        }
        return null;
    }

    private boolean looksLikeProjectRoot(Path dir) {
        if (dir == null || !Files.isDirectory(dir)) return false;
        try (DirectoryStream<Path> stream = Files.newDirectoryStream(dir)) {
            for (Path p : stream) {
                String n = p.getFileName().toString().toLowerCase(Locale.ROOT);
                if (PROJECT_MARKERS.contains(n)) return true;
                if (n.equals(".git") && Files.isDirectory(p)) return true;
                if (Files.isRegularFile(p) && (n.endsWith(".sln") || n.endsWith(".csproj") || n.endsWith(".fsproj") || n.endsWith(".vbproj"))) return true;
            }
        } catch (Exception ignored) { }
        return false;
    }

    private boolean isStandaloneDiagnostic(Path file) {
        String name = file.getFileName().toString().toLowerCase(Locale.ROOT);
        int dot = name.lastIndexOf('.');
        return dot >= 0 && DIAGNOSTIC_EXTENSIONS.contains(name.substring(dot + 1));
    }

    private boolean isLikelyProjectFile(Path file) {
        String name = file.getFileName().toString().toLowerCase(Locale.ROOT);
        if (PROJECT_MARKERS.contains(name)) return true;
        int dot = name.lastIndexOf('.');
        if (dot < 0) return false;
        return Set.of("java","kt","kts","groovy","scala","js","jsx","ts","tsx","py","rb","php","go","rs","c","cc","cpp","cxx","h","hpp","cs","fs","swift","dart","vue","svelte","xml","json","yaml","yml","toml","properties","gradle","sql","graphql","proto","sh","ps1","bat","cmd","tf","hcl").contains(name.substring(dot + 1));
    }

    private Path canonical(Path path) {
        if (path == null) return null;
        try { return path.toRealPath(); }
        catch (Exception ignored) { return path.toAbsolutePath().normalize(); }
    }

    private String aliasBase(Path path, int fallback) {
        Path namePath = path.getFileName();
        String name = namePath == null ? "resource" + fallback : namePath.toString();
        int dot = name.lastIndexOf('.');
        if (!Files.isDirectory(path) && dot > 0) name = name.substring(0, dot);
        String alias = name.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9_-]+", "-").replaceAll("^-+|-+$", "");
        return alias.isBlank() ? "resource" + fallback : alias;
    }

    private String uniqueAlias(String base, Set<String> used) {
        String alias = base;
        int i = 2;
        while (used.contains(alias)) alias = base + "-" + i++;
        return alias;
    }

    private String findAliasForRoot(Map<String, ResolvedResource> resources, Path root) {
        for (Map.Entry<String, ResolvedResource> e : resources.entrySet()) {
            if (e.getValue().root().equals(root)) return e.getKey();
        }
        return null;
    }

    private String resourceIdentity(Path root, Path focus) {
        return root.toAbsolutePath().normalize() + "|" + (focus == null ? "" : focus.normalize());
    }

    public enum ResourceKind { PROJECT, DIRECTORY, FILE }
    public enum ResourceRole { PRIMARY_WORKSPACE, SECONDARY_WORKSPACE, REFERENCE, INPUT, DIAGNOSTIC }

    public record ResolvedResource(String alias, Path root, Path focus, ResourceKind kind, ResourceRole role,
                                   boolean writable, boolean primary, String reason) {
        public ResolvedResource withFocus(Path next) {
            return new ResolvedResource(alias, root, next, kind, role, writable, primary, reason);
        }
        public ResolvedResource withRole(ResourceRole nextRole, boolean nextWritable, String nextReason) {
            return new ResolvedResource(alias, root, focus, kind, nextRole, nextWritable, primary, nextReason);
        }
    }

    public record Resolution(List<ResolvedResource> resources) {
        public int externalCount() { return (int) resources.stream().filter(r -> !r.primary()).count(); }
        public String catalogText() {
            StringBuilder out = new StringBuilder();
            for (ResolvedResource r : resources) {
                out.append('@').append(r.alias()).append(" -> ").append(r.root());
                if (r.focus() != null) out.append(" (focus: ").append(r.focus().toString().replace('\\','/')).append(')');
                out.append(" [").append(r.kind().name().toLowerCase(Locale.ROOT)).append(", role=")
                        .append(r.role().name().toLowerCase(Locale.ROOT)).append(", ")
                        .append(r.writable() ? "read/write" : "read-only").append(']');
                if (!r.reason().isBlank()) out.append(" — ").append(r.reason());
                out.append('\n');
            }
            return out.toString().stripTrailing();
        }
    }
}
