package com.llmart.llm.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.llmart.llm.dto.ProjectPatchRequest;
import com.llmart.llm.entity.ProjectWorkspaceEntity;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.nio.file.attribute.PosixFilePermission;
import java.time.Duration;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Service
public class AgentWorkspaceService {
    private static final long MAX_FULL_TEXT_READ_BYTES = 256L * 1024L;
    private static final int DEFAULT_CHUNK_CHARS = 16_000;
    private static final int MAX_CHUNK_CHARS = 100_000;
    private static final Pattern STRUCTURED_KEY_PATTERN = Pattern.compile("\"([^\"]{1,120})\"\\s*:");
    private static final Set<String> SKIP_DIRS = Set.of(
            ".git", ".svn", ".hg", "node_modules", "target", "build", "dist", "out", ".gradle", ".idea", ".next",
            "coverage", ".advanced-ai-chat-backup", ".agent-build", ".agent-home", ".venv", "venv", "env", "vendor",
            ".terraform", ".dart_tool", ".tox", ".pytest_cache", "__pycache__", ".mypy_cache", ".ruff_cache", ".cache",
            "bin", "obj", "pods", "deriveddata", ".build"
    );
    private static final Set<String> CODE_EXTENSIONS = Set.of(
            "java","kt","kts","groovy","scala","js","jsx","ts","tsx","py","rb","php","go","rs","c","cc","cpp","cxx","h","hpp",
            "cs","fs","fsx","vb","swift","dart","r","lua","pl","pm","ex","exs","clj","cljs","sql","graphql","gql","proto","thrift",
            "vue","svelte","jsp","ftl","mustache","tf","hcl","bzl","sh","bash","zsh","ps1","bat","cmd",
            "sbt","zig","nim","jl","hs","lhs","erl","hrl","elm","sol"
    );
    private static final Set<String> TEXT_EXTENSIONS = Set.of(
            "java","kt","kts","groovy","scala","xml","html","htm","css","scss","sass","less","js","jsx","ts","tsx","mjs","cjs",
            "py","rb","php","go","rs","c","cc","cpp","cxx","h","hpp","cs","fs","fsx","vb","swift","dart","r","lua","pl","pm","ex","exs","clj","cljs",
            "sql","graphql","gql","proto","thrift","json","jsonl","yml","yaml","toml","ini","conf","config","properties","md","adoc","rst","txt","csv","tsv",
            "feature","robot","sh","bash","zsh","ps1","bat","cmd","gradle","mvn","jsp","ftl","mustache","vue","svelte","tf","tfvars","hcl","bzl",
            "sbt","zig","nim","jl","hs","lhs","erl","hrl","elm","sol","cabal","log"
    );

    private final ProjectService projects;
    private final ObjectMapper objectMapper;
    private final PromptResourceResolver resourceResolver;
    private final Map<String, ManagedProcess> managedProcesses = new ConcurrentHashMap<>();

    public AgentWorkspaceService(ProjectService projects, ObjectMapper objectMapper, PromptResourceResolver resourceResolver) {
        this.projects = projects;
        this.objectMapper = objectMapper;
        this.resourceResolver = resourceResolver;
    }

    /**
     * OpenCode-style direct workspace: the user-selected local directory is the live workspace.
     * There is no project mirror, staging directory, or delayed apply step. File tools mutate this
     * path directly after the configured permission checks.
     */
    public Workspace prepare(String projectId) throws IOException {
        return prepare(projectId, null);
    }

    public Workspace prepare(String projectId, String prompt) throws IOException {
        if (projectId == null || projectId.isBlank()) {
            throw new IllegalArgumentException("Agent mode requires an active local workspace path or an explicit project path in the prompt.");
        }
        ProjectWorkspaceEntity project = projects.require(projectId);
        if (!project.hasLocalPath()) {
            throw new IllegalArgumentException("Agent mode requires a local-path workspace. Browser-indexed folders are read-only context for Chat.");
        }
        Path root = Path.of(project.getLocalPath()).toAbsolutePath().normalize().toRealPath();
        if (!Files.isDirectory(root)) throw new IllegalArgumentException("Local workspace directory is unavailable: " + root);
        makeWrappersExecutable(root);
        PromptResourceResolver.Resolution resolution = resourceResolver.resolve(prompt, root);
        LinkedHashMap<String, PromptResourceResolver.ResolvedResource> resources = new LinkedHashMap<>();
        for (PromptResourceResolver.ResolvedResource resource : resolution.resources()) {
            resources.put(resource.alias(), resource);
            if (resource.writable() && resource.kind() == PromptResourceResolver.ResourceKind.PROJECT && Files.isDirectory(resource.root())) {
                makeWrappersExecutable(resource.root());
            }
        }
        return new Workspace(projectId, root, new LinkedHashMap<>(), new LinkedHashMap<>(), resources, createChangeJournal(root));
    }


    /**
     * Workspace-level instructions are discovered once at the beginning of each agent run. They are
     * treated as project guidance, not as a reason to copy/index the project into another directory.
     */
    public String projectInstructions(Workspace ws) {
        List<String> candidates = List.of(
                "AGENTS.md",
                ".opencode/instructions.md",
                "CLAUDE.md",
                ".github/copilot-instructions.md"
        );
        StringBuilder out = new StringBuilder();
        for (String candidate : candidates) {
            try {
                Path path = resolve(ws.root, candidate);
                if (!Files.isRegularFile(path)) continue;
                String text = Files.readString(path, StandardCharsets.UTF_8);
                if (text.isBlank()) continue;
                if (!out.isEmpty()) out.append("\n\n");
                out.append("PROJECT INSTRUCTIONS FROM ").append(candidate).append(":\n");
                out.append(text);
            } catch (Exception ignored) { }
        }
        return out.toString();
    }

    public String instructionCatalog(Workspace ws) {
        LinkedHashSet<String> found = new LinkedHashSet<>();
        try (Stream<Path> stream = Files.walk(ws.root, 10)) {
            stream.filter(Files::isRegularFile).filter(p -> !Files.isSymbolicLink(p)).forEach(path -> {
                String rel = ws.root.relativize(path).toString().replace('\\','/');
                String low = rel.toLowerCase(Locale.ROOT);
                String name = path.getFileName().toString().toLowerCase(Locale.ROOT);
                if (name.equals("agents.md") || name.equals("claude.md") || low.equals(".github/copilot-instructions.md") || low.equals(".opencode/instructions.md")) {
                    boolean skipped = false;
                    for (String part : rel.split("/")) if (SKIP_DIRS.contains(part.toLowerCase(Locale.ROOT))) { skipped = true; break; }
                    if (!skipped) found.add(rel);
                }
            });
        } catch (Exception ignored) { }
        return found.isEmpty() ? "[No project instruction files discovered]" : String.join("\n", found);
    }

    /** Load root and nested instructions applicable to the supplied path, similar to coding-agent directory scoping. */
    public String instructionsFor(Workspace ws, String rawPath) throws IOException {
        String relative = normalizeRelative(rawPath);
        Path target = resolve(ws.root, relative);
        Path dir = Files.isDirectory(target) ? target : target.getParent();
        if (dir == null) dir = ws.root;
        LinkedHashSet<Path> candidates = new LinkedHashSet<>();
        // Workspace-wide instruction sources.
        for (String rootFile : List.of("AGENTS.md", "CLAUDE.md", ".opencode/instructions.md", ".github/copilot-instructions.md")) {
            Path p = resolve(ws.root, rootFile); if (Files.isRegularFile(p) && !Files.isSymbolicLink(p)) candidates.add(p);
        }
        // Nested AGENTS.md/CLAUDE.md from root -> target directory. Later entries are more specific.
        Path cursor = ws.root;
        for (Path part : ws.root.relativize(dir)) {
            cursor = cursor.resolve(part);
            for (String name : List.of("AGENTS.md", "CLAUDE.md")) {
                Path p = cursor.resolve(name).normalize();
                if (p.startsWith(ws.root) && Files.isRegularFile(p) && !Files.isSymbolicLink(p)) candidates.add(p);
            }
        }
        if (candidates.isEmpty()) return "[No applicable project instructions for " + relative + "]";
        StringBuilder out = new StringBuilder();
        for (Path file : candidates) {
            if (!out.isEmpty()) out.append("\n\n");
            out.append("INSTRUCTIONS FROM ").append(ws.root.relativize(file).toString().replace('\\','/')).append(":\n");
            out.append(Files.readString(file, StandardCharsets.UTF_8));
        }
        return out.toString();
    }

    private List<Path> skillRoots(Workspace ws) {
        Path home = Path.of(System.getProperty("user.home", ".")).toAbsolutePath().normalize();
        return List.of(
                ws.root.resolve(".agents/skills").normalize(),
                ws.root.resolve(".opencode/skills").normalize(),
                ws.root.resolve(".claude/skills").normalize(),
                home.resolve(".agents/skills").normalize(),
                home.resolve(".config/opencode/skills").normalize(),
                home.resolve(".claude/skills").normalize()
        );
    }

    public String availableSkills(Workspace ws) {
        LinkedHashMap<String,String> found = new LinkedHashMap<>();
        for (Path skillRoot : skillRoots(ws)) {
            try {
                if (!Files.isDirectory(skillRoot) || Files.isSymbolicLink(skillRoot)) continue;
                try (Stream<Path> children = Files.list(skillRoot)) {
                    children.filter(Files::isDirectory).sorted().forEach(dir -> {
                        try {
                            Path skill = dir.resolve("SKILL.md");
                            if (!Files.isRegularFile(skill) || Files.isSymbolicLink(skill)) return;
                            String name = dir.getFileName().toString();
                            String text = Files.readString(skill, StandardCharsets.UTF_8);
                            String description = skillDescription(text);
                            found.putIfAbsent(name, skill.toString() + (description.isBlank() ? "" : " — " + description));
                        } catch (Exception ignored) { }
                    });
                }
            } catch (Exception ignored) { }
        }
        if (found.isEmpty()) return "[No skills discovered]";
        return found.entrySet().stream().map(e -> e.getKey() + " -> " + e.getValue()).collect(Collectors.joining("\n"));
    }

    public String loadSkill(Workspace ws, String rawName) throws IOException {
        String name = rawName == null ? "" : rawName.trim();
        if (!name.matches("[A-Za-z0-9._-]{1,120}")) throw new IllegalArgumentException("Invalid skill name");
        for (Path skillRoot : skillRoots(ws)) {
            Path candidate = skillRoot.resolve(name).resolve("SKILL.md").normalize();
            if (!candidate.startsWith(skillRoot) || !Files.isRegularFile(candidate) || Files.isSymbolicLink(candidate)) continue;
            String text = Files.readString(candidate, StandardCharsets.UTF_8);
            List<String> support = new ArrayList<>();
            Path base = candidate.getParent();
            try (Stream<Path> stream = Files.walk(base, 3)) {
                stream.filter(Files::isRegularFile).filter(p -> !p.equals(candidate)).limit(10)
                        .forEach(p -> support.add(base.relativize(p).toString().replace('\\','/')));
            } catch (Exception ignored) { }
            return "SKILL " + name + " FROM " + candidate + "\n\n" + text +
                    (support.isEmpty() ? "" : "\n\nSUPPORTING FILES (read with workspace tools when inside project, or follow the skill's own commands):\n- " + String.join("\n- ", support));
        }
        throw new IllegalArgumentException("Skill not found: " + name + ". Available skills:\n" + availableSkills(ws));
    }

    private String skillDescription(String text) {
        if (text == null || text.isBlank()) return "";
        String[] lines = text.replace("\r\n", "\n").split("\n");
        boolean frontmatter = lines.length > 0 && lines[0].trim().equals("---");
        if (frontmatter) {
            for (int i = 1; i < Math.min(lines.length, 80); i++) {
                String line = lines[i].trim();
                if (line.equals("---")) break;
                if (line.toLowerCase(Locale.ROOT).startsWith("description:")) {
                    String value = line.substring("description:".length()).trim().replaceAll("^[\"']|[\"']$", "");
                    return value.length() > 220 ? value.substring(0, 220) : value;
                }
            }
        }
        for (String line : lines) {
            String value = line.trim().replaceFirst("^#+\\s*", "");
            if (!value.isBlank() && !value.equals("---")) return value.length() > 220 ? value.substring(0, 220) : value;
        }
        return "";
    }

    public String inspectWorkspace(Workspace ws) throws IOException {
        List<String> paths = allPaths(ws);
        List<String> descriptors = paths.stream().filter(this::isDescriptor).toList();
        long textFiles = paths.stream().filter(this::isReadableTextPath).count();
        StringBuilder out = new StringBuilder();
        out.append("mode=direct-local-workspace\n");
        out.append("files=").append(paths.size()).append("; readableTextFiles=").append(textFiles).append('\n');
        if (descriptors.isEmpty()) out.append("descriptors=[none detected]\n");
        else {
            out.append("descriptors:\n");
            for (String descriptor : descriptors) out.append("- ").append(descriptor).append(" -> ").append(descriptorKind(descriptor)).append('\n');
        }
        String skills = availableSkills(ws);
        if (!skills.startsWith("[No ")) out.append("skills:\n").append(skills).append('\n');
        VerificationAdvice advice = verificationAdvice(ws);
        out.append("verificationRequired=").append(advice.required()).append("; reason=").append(advice.reason());
        return out.toString();
    }

    public String listFiles(Workspace ws, String prefix) throws IOException {
        String normalizedPrefix = prefix == null ? "" : prefix.replace('\\','/').replaceAll("^/+", "");
        List<String> paths = allPaths(ws).stream().filter(p -> normalizedPrefix.isBlank() || p.startsWith(normalizedPrefix)).toList();
        String body = String.join("\n", paths);
        return body.isBlank() ? "[No matching project files]" : body;
    }

    public String glob(Workspace ws, String pattern, int maxMatches) throws IOException {
        String value = pattern == null || pattern.isBlank() ? "**/*" : pattern.replace('\\','/');
        PathMatcher matcher = FileSystems.getDefault().getPathMatcher("glob:" + value);
        int cap = maxMatches <= 0 ? Integer.MAX_VALUE : maxMatches;
        List<String> result = new ArrayList<>();
        for (String path : allPaths(ws)) {
            if (matcher.matches(Path.of(path))) result.add(path);
            if (result.size() >= cap) break;
        }
        return result.isEmpty() ? "[No files match glob: " + value + "]" : String.join("\n", result);
    }

    public String fileInfo(Workspace ws, String rawPath) throws IOException {
        String relative = normalizeRelative(rawPath);
        Path file = resolve(ws.root, relative);
        if (!Files.exists(file)) return "path=" + relative + "; exists=false";
        if (Files.isDirectory(file)) return "path=" + relative + "; exists=true; type=directory";
        if (!Files.isRegularFile(file)) return "path=" + relative + "; exists=true; type=other";
        long size = Files.size(file);
        StringBuilder out = new StringBuilder("path=").append(relative)
                .append("; exists=true; type=file; sizeBytes=").append(size)
                .append("; readableText=").append(isReadableTextPath(relative));
        if (isReadableTextPath(relative) || ws.touched.contains(relative)) {
            try { out.append("; sha256=").append(sha256File(file)); }
            catch (Exception ignored) { }
        }
        return out.toString();
    }

    public String readFile(Workspace ws, String rawPath) throws IOException {
        return readFileRange(ws, rawPath, 1, Integer.MAX_VALUE);
    }

    public String readFileRange(Workspace ws, String rawPath, int startLine, int endLine) throws IOException {
        String relative = normalizeRelative(rawPath);
        Path file = resolve(ws.root, relative);
        if (!Files.exists(file) || !Files.isRegularFile(file)) throw new NoSuchFileException(relative);
        if (!isReadableTextPath(relative) && !ws.touched.contains(relative)) throw new IllegalArgumentException("File is not a supported text/source file: " + relative);

        int start = Math.max(1, startLine);
        int end = endLine <= 0 ? Integer.MAX_VALUE : Math.max(start, endLine);
        if (start == 1 && end == Integer.MAX_VALUE) {
            long size = Files.size(file);
            if (size > MAX_FULL_TEXT_READ_BYTES) return largeReadNotice(relative, size, false);
            String text = Files.readString(file, StandardCharsets.UTF_8);
            return "FILE: " + relative + "\n" + text;
        }

        List<String> lines = Files.readAllLines(file, StandardCharsets.UTF_8);
        if (start > lines.size()) return "FILE: " + relative + "\n[Requested range starts after end of file; lines=" + lines.size() + "]";
        int actualEnd = Math.min(lines.size(), end);
        StringBuilder out = new StringBuilder("FILE: ").append(relative).append(" (lines ").append(start).append('-').append(actualEnd).append(")\n");
        for (int i = start; i <= actualEnd; i++) {
            out.append(i).append(" | ").append(contextLine(lines.get(i - 1), 0)).append('\n');
        }
        return out.toString().stripTrailing();
    }

    public String readFiles(Workspace ws, List<String> paths) throws IOException {
        if (paths == null || paths.isEmpty()) throw new IllegalArgumentException("paths are required");
        StringBuilder out = new StringBuilder();
        for (String path : paths) {
            if (!out.isEmpty()) out.append("\n\n");
            out.append(readFile(ws, path));
        }
        return clip(out.toString());
    }

    public String search(Workspace ws, String query, int maxMatches) throws IOException {
        if (query == null || query.isBlank()) throw new IllegalArgumentException("search_project requires query");
        String needle = query.toLowerCase(Locale.ROOT);
        return searchInternal(ws, line -> line.toLowerCase(Locale.ROOT).contains(needle), maxMatches, "query: " + query);
    }

    public String regexSearch(Workspace ws, String regex, int maxMatches) throws IOException {
        if (regex == null || regex.isBlank()) throw new IllegalArgumentException("regex_search requires regex");
        Pattern pattern;
        try { pattern = Pattern.compile(regex); }
        catch (Exception e) { throw new IllegalArgumentException("Invalid regex: " + e.getMessage()); }
        return searchInternal(ws, line -> pattern.matcher(line).find(), maxMatches, "regex: " + regex);
    }

    private String searchInternal(Workspace ws, java.util.function.Predicate<String> matcher, int maxMatches, String label) throws IOException {
        int cap = maxMatches <= 0 ? Integer.MAX_VALUE : maxMatches;
        StringBuilder out = new StringBuilder();
        int matches = 0;
        for (String relative : textPaths(ws)) {
            Path file = resolve(ws.root, relative);
            List<String> lines;
            try { lines = Files.readAllLines(file, StandardCharsets.UTF_8); }
            catch (Exception ignored) { continue; }
            for (int i = 0; i < lines.size(); i++) {
                if (!matcher.test(lines.get(i))) continue;
                int start = Math.max(0, i - 2), end = Math.min(lines.size() - 1, i + 2);
                out.append("\n--- ").append(relative).append(':').append(i + 1).append(" ---\n");
                for (int n = start; n <= end; n++) out.append(n + 1).append(" | ").append(contextLine(lines.get(n), 0)).append('\n');
                matches++;
                if (matches >= cap) return clip(out.toString());
            }
        }
        return matches == 0 ? "[No matches for " + label + "]" : clip(out.toString());
    }

    public String resourceCatalog(Workspace ws) {
        if (ws.resources.isEmpty()) return "[No prompt resources resolved]";
        StringBuilder out = new StringBuilder("RESOURCE ALIASES\n");
        for (PromptResourceResolver.ResolvedResource resource : ws.resources.values()) {
            out.append('@').append(resource.alias()).append(" -> ").append(resource.root());
            if (resource.focus() != null) out.append(" (focus: ").append(resource.focus().toString().replace('\\','/')).append(')');
            out.append(" [").append(resource.kind().name().toLowerCase(Locale.ROOT)).append(", role=")
                    .append(resource.role().name().toLowerCase(Locale.ROOT)).append(", ")
                    .append(resource.writable() ? "read/write" : "read-only").append(']');
            if (!resource.reason().isBlank()) out.append(" — ").append(resource.reason());
            out.append('\n');
        }
        out.append("\nUse resource_* tools with the alias. Ordinary workspace tools continue to target @workspace.");
        return out.toString().stripTrailing();
    }

    public String resourceList(Workspace ws, String alias, String rawPath) throws IOException {
        PromptResourceResolver.ResolvedResource resource = requireResource(ws, alias, false);
        if (resource.kind() == PromptResourceResolver.ResourceKind.FILE) {
            return "@" + resource.alias() + " -> " + resource.root() + " [file, role=" + resource.role().name().toLowerCase(Locale.ROOT) + ", read-only]";
        }
        String relative = normalizeResourceRelative(rawPath);
        Path base = relative.isBlank() ? resource.root() : resolveResourcePath(resource, relative, false);
        if (!Files.exists(base)) throw new NoSuchFileException("@" + alias + "/" + relative);
        if (!Files.isDirectory(base)) return "@" + alias + "/" + relative;
        List<String> rows = new ArrayList<>();
        Files.walkFileTree(base, new SimpleFileVisitor<>() {
            @Override public FileVisitResult preVisitDirectory(Path dir, java.nio.file.attribute.BasicFileAttributes attrs) {
                if (!dir.equals(base)) {
                    String name = dir.getFileName() == null ? "" : dir.getFileName().toString().toLowerCase(Locale.ROOT);
                    if (SKIP_DIRS.contains(name)) return FileVisitResult.SKIP_SUBTREE;
                }
                return FileVisitResult.CONTINUE;
            }
            @Override public FileVisitResult visitFile(Path file, java.nio.file.attribute.BasicFileAttributes attrs) {
                if (!Files.isSymbolicLink(file)) {
                    String rel = resource.root().relativize(file).toString().replace('\\','/');
                    rows.add("@" + alias + "/" + rel);
                }
                return FileVisitResult.CONTINUE;
            }
        });
        rows.sort(String.CASE_INSENSITIVE_ORDER);
        return rows.isEmpty() ? "[No files under @" + alias + "]" : String.join("\n", rows);
    }

    public String resourceFileInfo(Workspace ws, String alias, String rawPath) throws IOException {
        PromptResourceResolver.ResolvedResource resource = requireResource(ws, alias, false);
        Path file;
        String shown;
        if (resource.kind() == PromptResourceResolver.ResourceKind.FILE) {
            file = resource.root(); shown = "@" + alias;
        } else {
            String relative = normalizeResourceRelative(rawPath);
            file = relative.isBlank() ? resource.root() : resolveResourcePath(resource, relative, false);
            shown = "@" + alias + (relative.isBlank() ? "" : "/" + relative);
        }
        if (!Files.exists(file)) return "path=" + shown + "; exists=false";
        if (Files.isDirectory(file)) return "path=" + shown + "; exists=true; type=directory; writable=" + resource.writable()
                + "; role=" + resource.role().name().toLowerCase(Locale.ROOT);
        long size = Files.size(file);
        return "path=" + shown + "; exists=true; type=file; sizeBytes=" + size + "; writable=" + resource.writable()
                + "; role=" + resource.role().name().toLowerCase(Locale.ROOT) + "; largeText=" + (size > MAX_FULL_TEXT_READ_BYTES);
    }

    public String resourceRead(Workspace ws, String alias, String rawPath, int startLine, int endLine) throws IOException {
        PromptResourceResolver.ResolvedResource resource = requireResource(ws, alias, false);
        Path file;
        String shown;
        if (resource.kind() == PromptResourceResolver.ResourceKind.FILE) {
            if (rawPath != null && !rawPath.isBlank()) throw new IllegalArgumentException("Standalone file resource @" + alias + " does not accept a child path");
            file = resource.root(); shown = "@" + alias;
        } else {
            String relative = normalizeResourceRelative(rawPath);
            if (relative.isBlank() && resource.focus() != null) relative = resource.focus().toString().replace('\\','/');
            if (relative.isBlank()) throw new IllegalArgumentException("path is required for directory/project resource @" + alias);
            file = resolveResourcePath(resource, relative, false);
            shown = "@" + alias + "/" + relative;
        }
        if (!Files.isRegularFile(file)) throw new NoSuchFileException(shown);
        if (!isReadableTextPath(file.getFileName().toString()) && !shown.toLowerCase(Locale.ROOT).endsWith(".log")) {
            throw new IllegalArgumentException("Resource is not readable as text: " + shown + ". Attach binary/image files in chat for document/vision extraction.");
        }
        int start = Math.max(1, startLine);
        int end = endLine <= 0 ? Integer.MAX_VALUE : Math.max(start, endLine);
        if (start == 1 && end == Integer.MAX_VALUE) {
            long size = Files.size(file);
            if (size > MAX_FULL_TEXT_READ_BYTES) return largeReadNotice(shown, size, true);
            return "FILE: " + shown + "\n" + Files.readString(file, StandardCharsets.UTF_8);
        }
        List<String> lines = Files.readAllLines(file, StandardCharsets.UTF_8);
        if (start > lines.size()) return "FILE: " + shown + "\n[Requested range starts after end of file; lines=" + lines.size() + "]";
        int actualEnd = Math.min(lines.size(), end);
        StringBuilder out = new StringBuilder("FILE: ").append(shown).append(" (lines ").append(start).append('-').append(actualEnd).append(")\n");
        for (int i = start; i <= actualEnd; i++) out.append(i).append(" | ").append(contextLine(lines.get(i - 1), 0)).append('\n');
        return out.toString().stripTrailing();
    }

    public String fileIndex(Workspace ws, String rawPath) throws IOException {
        String relative = normalizeRelative(rawPath);
        Path file = resolve(ws.root, relative);
        if (!Files.isRegularFile(file)) throw new NoSuchFileException(relative);
        if (!isReadableTextPath(relative) && !ws.touched.contains(relative)) throw new IllegalArgumentException("File is not a supported text/source file: " + relative);
        return textIndex(file, relative);
    }

    public String readFileChunk(Workspace ws, String rawPath, long offsetChars, int maxChars) throws IOException {
        String relative = normalizeRelative(rawPath);
        Path file = resolve(ws.root, relative);
        if (!Files.isRegularFile(file)) throw new NoSuchFileException(relative);
        if (!isReadableTextPath(relative) && !ws.touched.contains(relative)) throw new IllegalArgumentException("File is not a supported text/source file: " + relative);
        return readCharChunk(file, relative, offsetChars, maxChars);
    }

    public String resourceIndex(Workspace ws, String alias, String rawPath) throws IOException {
        PromptResourceResolver.ResolvedResource resource = requireResource(ws, alias, false);
        ResourceFile selected = selectResourceFile(resource, alias, rawPath);
        if (!isReadableTextPath(selected.file().getFileName().toString()) && !selected.shown().toLowerCase(Locale.ROOT).endsWith(".log")) {
            throw new IllegalArgumentException("Resource is not readable as text: " + selected.shown());
        }
        return textIndex(selected.file(), selected.shown()) + "\nrole=" + resource.role().name().toLowerCase(Locale.ROOT);
    }

    public String resourceReadChunk(Workspace ws, String alias, String rawPath, long offsetChars, int maxChars) throws IOException {
        PromptResourceResolver.ResolvedResource resource = requireResource(ws, alias, false);
        ResourceFile selected = selectResourceFile(resource, alias, rawPath);
        if (!isReadableTextPath(selected.file().getFileName().toString()) && !selected.shown().toLowerCase(Locale.ROOT).endsWith(".log")) {
            throw new IllegalArgumentException("Resource is not readable as text: " + selected.shown());
        }
        return readCharChunk(selected.file(), selected.shown(), offsetChars, maxChars);
    }

    private ResourceFile selectResourceFile(PromptResourceResolver.ResolvedResource resource, String alias, String rawPath) throws IOException {
        Path file;
        String shown;
        if (resource.kind() == PromptResourceResolver.ResourceKind.FILE) {
            if (rawPath != null && !rawPath.isBlank()) throw new IllegalArgumentException("Standalone file resource @" + alias + " does not accept a child path");
            file = resource.root();
            shown = "@" + alias;
        } else {
            String relative = normalizeResourceRelative(rawPath);
            if (relative.isBlank() && resource.focus() != null) relative = resource.focus().toString().replace('\\','/');
            if (relative.isBlank()) throw new IllegalArgumentException("path is required for directory/project resource @" + alias);
            file = resolveResourcePath(resource, relative, false);
            shown = "@" + alias + "/" + relative;
        }
        if (!Files.isRegularFile(file)) throw new NoSuchFileException(shown);
        return new ResourceFile(file, shown);
    }

    private String textIndex(Path file, String shown) throws IOException {
        long size = Files.size(file);
        long lines = 0;
        long nonBlank = 0;
        int maxLineChars = 0;
        String firstNonBlank = "";
        LinkedHashMap<String,Integer> keyCounts = new LinkedHashMap<>();
        boolean keyLimitReached = false;
        try (var reader = Files.newBufferedReader(file, StandardCharsets.UTF_8)) {
            String line;
            while ((line = reader.readLine()) != null) {
                lines++;
                if (!line.isBlank()) {
                    nonBlank++;
                    if (firstNonBlank.isBlank()) firstNonBlank = line.strip();
                }
                maxLineChars = Math.max(maxLineChars, line.length());
                var matcher = STRUCTURED_KEY_PATTERN.matcher(line);
                while (matcher.find()) {
                    String key = matcher.group(1);
                    if (keyCounts.containsKey(key)) keyCounts.put(key, keyCounts.get(key) + 1);
                    else if (keyCounts.size() < 2_000) keyCounts.put(key, 1);
                    else keyLimitReached = true;
                }
            }
        }
        List<Map.Entry<String,Integer>> top = keyCounts.entrySet().stream()
                .sorted((a,b) -> Integer.compare(b.getValue(), a.getValue())).limit(20).toList();
        String extension = extension(file.getFileName() == null ? shown : file.getFileName().toString());
        String shape = firstNonBlank.startsWith("[") ? "array-like" : firstNonBlank.startsWith("{") ? "object-like" : "text";
        StringBuilder out = new StringBuilder("TEXT INDEX: ").append(shown).append('\n');
        out.append("sizeBytes=").append(size).append("; lines=").append(lines).append("; nonBlankLines=").append(nonBlank)
                .append("; maxLineChars=").append(maxLineChars).append("; extension=").append(extension.isBlank() ? "[none]" : extension)
                .append("; shape=").append(shape).append("; largeText=").append(size > MAX_FULL_TEXT_READ_BYTES).append('\n');
        if (!top.isEmpty()) {
            out.append("frequentStructuredKeys:");
            for (var e : top) out.append(" ").append(e.getKey()).append('=').append(e.getValue());
            if (keyLimitReached) out.append(" [distinct-key scan capped]");
            out.append('\n');
        }
        if (size > MAX_FULL_TEXT_READ_BYTES) {
            out.append("recommendedAccess=targeted grep/read ranges; for minified or very long lines use character chunks (default ")
                    .append(DEFAULT_CHUNK_CHARS).append(" chars, max ").append(MAX_CHUNK_CHARS).append(")");
        } else {
            out.append("recommendedAccess=normal read or targeted grep/read ranges");
        }
        return out.toString();
    }

    private String readCharChunk(Path file, String shown, long offsetChars, int requestedMaxChars) throws IOException {
        long offset = Math.max(0L, offsetChars);
        int cap = requestedMaxChars <= 0 ? DEFAULT_CHUNK_CHARS : Math.min(MAX_CHUNK_CHARS, Math.max(1, requestedMaxChars));
        char[] buffer = new char[cap + 1];
        int total = 0;
        try (var reader = Files.newBufferedReader(file, StandardCharsets.UTF_8)) {
            long remaining = offset;
            while (remaining > 0) {
                long skipped = reader.skip(remaining);
                if (skipped <= 0) {
                    if (reader.read() < 0) break;
                    skipped = 1;
                }
                remaining -= skipped;
            }
            while (total < buffer.length) {
                int n = reader.read(buffer, total, buffer.length - total);
                if (n < 0) break;
                total += n;
            }
        }
        int shownChars = Math.min(total, cap);
        boolean hasMore = total > cap;
        String text = new String(buffer, 0, shownChars);
        return "CHUNK: " + shown + " (offsetChars=" + offset + ", chars=" + shownChars + ", hasMore=" + hasMore + ")\n" + text;
    }

    private String largeReadNotice(String shown, long size, boolean resource) {
        String prefix = resource ? "resource_index/resource_read/resource_chunk" : "file_index/read/read_chunk";
        return "FILE: " + shown + "\n[Large text resource: sizeBytes=" + size + ". Full read is intentionally guarded to protect model context. Use " + prefix + " with targeted ranges/search/chunks.]";
    }

    private String contextLine(String line, int focusIndex) {
        if (line == null) return "";
        int max = 4_000;
        if (line.length() <= max) return line;
        int focus = Math.max(0, Math.min(line.length() - 1, focusIndex));
        int start = Math.max(0, focus - max / 2);
        int end = Math.min(line.length(), start + max);
        if (end - start < max) start = Math.max(0, end - max);
        return (start > 0 ? "…[truncated " + start + " chars]…" : "")
                + line.substring(start, end)
                + (end < line.length() ? "…[truncated " + (line.length() - end) + " chars; use *_chunk for exact data]…" : "");
    }

    private String extension(String shown) {
        String name = shown == null ? "" : shown.toLowerCase(Locale.ROOT);
        int slash = Math.max(name.lastIndexOf('/'), name.lastIndexOf('\\'));
        int dot = name.lastIndexOf('.');
        return dot > slash ? name.substring(dot + 1) : "";
    }

    private record ResourceFile(Path file, String shown) { }

    public String resourceGrep(Workspace ws, String alias, String pattern, boolean regex, int maxMatches) throws IOException {
        if (pattern == null || pattern.isBlank()) throw new IllegalArgumentException("pattern is required");
        PromptResourceResolver.ResolvedResource resource = requireResource(ws, alias, false);
        Pattern compiled = regex ? Pattern.compile(pattern) : null;
        String literal = pattern.toLowerCase(Locale.ROOT);
        int cap = maxMatches <= 0 ? Integer.MAX_VALUE : maxMatches;
        List<Path> files = resourceTextFiles(resource);
        StringBuilder out = new StringBuilder();
        int matches = 0;
        for (Path file : files) {
            List<String> lines;
            try { lines = Files.readAllLines(file, StandardCharsets.UTF_8); } catch (Exception ignored) { continue; }
            for (int i = 0; i < lines.size(); i++) {
                String line = lines.get(i);
                int hitIndex;
                if (regex) {
                    var matcher = compiled.matcher(line);
                    if (!matcher.find()) continue;
                    hitIndex = matcher.start();
                } else {
                    hitIndex = line.toLowerCase(Locale.ROOT).indexOf(literal);
                    if (hitIndex < 0) continue;
                }
                String rel = resource.kind() == PromptResourceResolver.ResourceKind.FILE ? "" : resource.root().relativize(file).toString().replace('\\','/');
                out.append("\n--- @").append(alias).append(rel.isBlank() ? "" : "/" + rel).append(':').append(i + 1).append(" ---\n");
                int from = Math.max(0, i - 2), to = Math.min(lines.size() - 1, i + 2);
                for (int n = from; n <= to; n++) out.append(n + 1).append(" | ").append(contextLine(lines.get(n), n == i ? hitIndex : 0)).append('\n');
                if (++matches >= cap) return out.toString().stripTrailing();
            }
        }
        return matches == 0 ? "[No matches in @" + alias + " for " + pattern + "]" : out.toString().stripTrailing();
    }

    public String resourceWrite(Workspace ws, String alias, String rawPath, String content) throws IOException {
        PromptResourceResolver.ResolvedResource resource = requireResource(ws, alias, true);
        if (resource.kind() == PromptResourceResolver.ResourceKind.FILE) throw new SecurityException("Standalone prompt files are read-only resources");
        String relative = normalizeResourceRelativeRequired(rawPath);
        String key = resourceKey(alias, relative);
        Path file = resolveResourcePath(resource, relative, true);
        String value = content == null ? "" : content;
        if (Files.isRegularFile(file) && Objects.equals(Files.readString(file, StandardCharsets.UTF_8), value)) {
            return "workspaceChanged=false; No change to " + key + " (content already matches)";
        }
        captureBaseline(ws, key);
        Files.createDirectories(file.getParent());
        Files.writeString(file, value, StandardCharsets.UTF_8, StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
        ws.touched.add(key);
        return "workspaceChanged=true; Wrote " + key + " (" + value.length() + " chars)";
    }

    public String resourceEdit(Workspace ws, String alias, String rawPath, String oldText, String newText, boolean replaceAll) throws IOException {
        PromptResourceResolver.ResolvedResource resource = requireResource(ws, alias, true);
        String relative = normalizeResourceRelativeRequired(rawPath);
        Path file = resolveResourcePath(resource, relative, true);
        if (!Files.isRegularFile(file)) throw new NoSuchFileException(resourceKey(alias, relative));
        String current = Files.readString(file, StandardCharsets.UTF_8);
        if (oldText == null || oldText.isEmpty()) throw new IllegalArgumentException("oldText is required");
        String needle = compatibleLineEndings(current, oldText);
        int first = current.indexOf(needle);
        if (first < 0) throw new IllegalArgumentException(editNotFoundMessage(resourceKey(alias, relative), current, oldText));
        if (!replaceAll && current.indexOf(needle, first + needle.length()) >= 0) throw new IllegalArgumentException("oldText occurs more than once; provide more context or set replaceAll=true");
        String key = resourceKey(alias, relative);
        String replacement = compatibleLineEndings(current, newText == null ? "" : newText);
        String updated = replaceAll ? current.replace(needle, replacement) : current.substring(0, first) + replacement + current.substring(first + needle.length());
        if (Objects.equals(current, updated)) return "workspaceChanged=false; No change to " + key + " (replacement is identical)";
        captureBaseline(ws, key);
        Files.writeString(file, updated, StandardCharsets.UTF_8, StandardOpenOption.TRUNCATE_EXISTING);
        ws.touched.add(key);
        return "workspaceChanged=true; Edited " + key;
    }

    public String resourceDelete(Workspace ws, String alias, String rawPath) throws IOException {
        PromptResourceResolver.ResolvedResource resource = requireResource(ws, alias, true);
        String relative = normalizeResourceRelativeRequired(rawPath);
        Path file = resolveResourcePath(resource, relative, true);
        if (!Files.isRegularFile(file)) throw new NoSuchFileException(resourceKey(alias, relative));
        String key = resourceKey(alias, relative);
        captureBaseline(ws, key);
        Files.delete(file);
        ws.touched.add(key);
        return "workspaceChanged=true; Deleted " + key;
    }

    public String resourceCopy(Workspace ws, String fromAlias, String rawFromPath, String toAlias, String rawToPath, boolean overwrite) throws IOException {
        PromptResourceResolver.ResolvedResource source = requireResource(ws, fromAlias, false);
        PromptResourceResolver.ResolvedResource target = requireResource(ws, toAlias, true);
        Path sourceFile;
        String sourceShown;
        if (source.kind() == PromptResourceResolver.ResourceKind.FILE) {
            if (rawFromPath != null && !rawFromPath.isBlank()) throw new IllegalArgumentException("Standalone file resource @" + fromAlias + " does not accept fromPath");
            sourceFile = source.root();
            sourceShown = "@" + source.alias();
        } else {
            String fromPath = normalizeResourceRelativeRequired(rawFromPath);
            sourceFile = resolveResourcePath(source, fromPath, false);
            sourceShown = resourceKey(source.alias(), fromPath);
        }
        if (!Files.isRegularFile(sourceFile)) throw new NoSuchFileException(sourceShown);
        String toPath = normalizeResourceRelativeRequired(rawToPath);
        Path targetFile = resolveResourcePath(target, toPath, true);
        if (Files.exists(targetFile) && !overwrite) throw new FileAlreadyExistsException(resourceKey(target.alias(), toPath));
        String targetKey = resourceKey(target.alias(), toPath);
        if (Files.isRegularFile(targetFile) && overwrite && Files.mismatch(sourceFile, targetFile) == -1L) {
            return "workspaceChanged=false; No change to " + targetKey + " (target already matches source)";
        }
        captureBaseline(ws, targetKey);
        Files.createDirectories(targetFile.getParent());
        if (overwrite) Files.copy(sourceFile, targetFile, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.COPY_ATTRIBUTES);
        else Files.copy(sourceFile, targetFile, StandardCopyOption.COPY_ATTRIBUTES);
        ws.touched.add(targetKey);
        return "workspaceChanged=true; Copied " + sourceShown + " -> " + targetKey;
    }

    public String resourceMove(Workspace ws, String fromAlias, String rawFromPath, String toAlias, String rawToPath, boolean overwrite) throws IOException {
        PromptResourceResolver.ResolvedResource source = requireResource(ws, fromAlias, true);
        PromptResourceResolver.ResolvedResource target = requireResource(ws, toAlias, true);
        if (source.kind() == PromptResourceResolver.ResourceKind.FILE) throw new SecurityException("Standalone file resources are read-only and cannot be moved");
        String fromPath = normalizeResourceRelativeRequired(rawFromPath);
        String toPath = normalizeResourceRelativeRequired(rawToPath);
        Path sourceFile = resolveResourcePath(source, fromPath, true);
        Path targetFile = resolveResourcePath(target, toPath, true);
        if (!Files.isRegularFile(sourceFile)) throw new NoSuchFileException(resourceKey(source.alias(), fromPath));
        String sourceKey = resourceKey(source.alias(), fromPath);
        String targetKey = resourceKey(target.alias(), toPath);
        if (sourceFile.normalize().equals(targetFile.normalize())) return "workspaceChanged=false; Source and target are identical; no change made";
        if (Files.exists(targetFile) && !overwrite) throw new FileAlreadyExistsException(targetKey);
        captureBaseline(ws, sourceKey);
        captureBaseline(ws, targetKey);
        Files.createDirectories(targetFile.getParent());
        if (overwrite) Files.move(sourceFile, targetFile, StandardCopyOption.REPLACE_EXISTING);
        else Files.move(sourceFile, targetFile);
        ws.touched.add(sourceKey);
        ws.touched.add(targetKey);
        return "workspaceChanged=true; Moved " + sourceKey + " -> " + targetKey;
    }

    public CommandResult resourceBuild(Workspace ws, String alias, boolean allowed, AgentRunService.AgentRun run) throws Exception {
        Workspace scoped = scopedWorkspace(ws, requireResource(ws, alias, true));
        try { return runBuild(scoped, null, allowed, run); } finally { cleanup(scoped); }
    }

    public CommandResult resourceTests(Workspace ws, String alias, boolean allowed, AgentRunService.AgentRun run) throws Exception {
        Workspace scoped = scopedWorkspace(ws, requireResource(ws, alias, true));
        try { return runTests(scoped, null, allowed, run); } finally { cleanup(scoped); }
    }

    public CommandResult resourceCheck(Workspace ws, String alias, boolean allowed, AgentRunService.AgentRun run) throws Exception {
        Workspace scoped = scopedWorkspace(ws, requireResource(ws, alias, true));
        try { return runCheck(scoped, null, allowed, run); } finally { cleanup(scoped); }
    }

    public CommandResult resourceCommand(Workspace ws, String alias, String command, long timeoutSeconds, boolean allowed,
                                         Set<String> extraCommands, AgentRunService.AgentRun run) throws Exception {
        PromptResourceResolver.ResolvedResource resource = requireResource(ws, alias, true);
        Workspace scoped = scopedWorkspace(ws, resource);
        try {
            CommandResult result = runCommand(scoped, command, null, allowed, extraCommands, timeoutSeconds, run);
            List<String> changed = new ArrayList<>();
            for (String rel : scoped.touched) {
                String key = resourceKey(alias, rel);
                ws.baselineHashes.putIfAbsent(key, "UNKNOWN_BEFORE_SHELL");
                ws.baseline.putIfAbsent(key, null);
                ws.touched.add(key);
                changed.add(key);
            }
            if (!changed.isEmpty()) {
                result = new CommandResult(result.exitCode(), "resourceChanged=true; changedFiles=" + changed.size() + "\n" + String.join("\n", changed) + "\n" + result.output(), result.elapsed());
            }
            return result;
        } finally {
            cleanup(scoped);
        }
    }

    private Workspace scopedWorkspace(Workspace parent, PromptResourceResolver.ResolvedResource resource) {
        if (resource.kind() != PromptResourceResolver.ResourceKind.PROJECT && resource.kind() != PromptResourceResolver.ResourceKind.DIRECTORY) {
            throw new IllegalArgumentException("Resource @" + resource.alias() + " is not a runnable directory");
        }
        LinkedHashMap<String, PromptResourceResolver.ResolvedResource> one = new LinkedHashMap<>();
        one.put("workspace", new PromptResourceResolver.ResolvedResource("workspace", resource.root(), resource.focus(), resource.kind(), PromptResourceResolver.ResourceRole.PRIMARY_WORKSPACE, resource.writable(), true, resource.reason()));
        return new Workspace(parent.projectId, resource.root(), new LinkedHashMap<>(), new LinkedHashMap<>(), one, createChangeJournal(resource.root()));
    }

    private PromptResourceResolver.ResolvedResource requireResource(Workspace ws, String rawAlias, boolean write) {
        String alias = rawAlias == null ? "" : rawAlias.trim();
        if (alias.startsWith("@")) alias = alias.substring(1);
        PromptResourceResolver.ResolvedResource resource = ws.resources.get(alias);
        if (resource == null) throw new IllegalArgumentException("Unknown resource alias @" + alias + ". Use resource_catalog first.");
        if (write && !resource.writable()) throw new SecurityException("Resource @" + alias + " is read-only because it is contextual input, not an explicit project workspace");
        return resource;
    }

    private Path resolveResourcePath(PromptResourceResolver.ResolvedResource resource, String relative, boolean write) throws IOException {
        if (write && !resource.writable()) throw new SecurityException("Resource @" + resource.alias() + " is read-only");
        Path root = resource.root().toRealPath();
        Path target = root.resolve(relative).normalize();
        if (!target.startsWith(root)) throw new SecurityException("Path escapes resource @" + resource.alias() + ": " + relative);
        Path cursor = root;
        for (Path part : root.relativize(target)) {
            cursor = cursor.resolve(part);
            if (Files.exists(cursor, LinkOption.NOFOLLOW_LINKS) && Files.isSymbolicLink(cursor)) {
                throw new SecurityException("Resource path contains a symbolic link and is not allowed: @" + resource.alias() + "/" + relative);
            }
        }
        return target;
    }

    private Path resolveTracked(Workspace ws, String key, boolean write) throws IOException {
        if (key != null && key.startsWith("@")) {
            int slash = key.indexOf('/');
            String alias = slash < 0 ? key.substring(1) : key.substring(1, slash);
            String relative = slash < 0 ? "" : key.substring(slash + 1);
            PromptResourceResolver.ResolvedResource resource = requireResource(ws, alias, write);
            if (resource.kind() == PromptResourceResolver.ResourceKind.FILE) {
                if (!relative.isBlank()) throw new SecurityException("Standalone file resource has no child path: " + key);
                return resource.root();
            }
            if (relative.isBlank()) return resource.root();
            return resolveResourcePath(resource, relative, write);
        }
        return resolve(ws.root, key);
    }

    private String resourceKey(String alias, String relative) {
        return "@" + alias + (relative == null || relative.isBlank() ? "" : "/" + relative.replace('\\','/'));
    }

    private String normalizeResourceRelative(String raw) {
        if (raw == null || raw.isBlank() || ".".equals(raw.trim())) return "";
        String p = raw.replace('\\','/').replaceAll("^/+", "");
        while (p.contains("//")) p = p.replace("//", "/");
        if (p.startsWith("../") || p.contains("/../") || p.endsWith("/..") || p.contains("\u0000")) throw new SecurityException("Invalid resource path: " + raw);
        return p;
    }

    private String normalizeResourceRelativeRequired(String raw) {
        String value = normalizeResourceRelative(raw);
        if (value.isBlank()) throw new IllegalArgumentException("Relative resource path is required");
        return value;
    }

    private List<Path> resourceTextFiles(PromptResourceResolver.ResolvedResource resource) throws IOException {
        if (resource.kind() == PromptResourceResolver.ResourceKind.FILE) return List.of(resource.root());
        List<Path> files = new ArrayList<>();
        Files.walkFileTree(resource.root(), new SimpleFileVisitor<>() {
            @Override public FileVisitResult preVisitDirectory(Path dir, java.nio.file.attribute.BasicFileAttributes attrs) {
                if (!dir.equals(resource.root())) {
                    String name = dir.getFileName() == null ? "" : dir.getFileName().toString().toLowerCase(Locale.ROOT);
                    if (SKIP_DIRS.contains(name)) return FileVisitResult.SKIP_SUBTREE;
                }
                return FileVisitResult.CONTINUE;
            }
            @Override public FileVisitResult visitFile(Path file, java.nio.file.attribute.BasicFileAttributes attrs) {
                if (!Files.isSymbolicLink(file) && isReadableTextPath(file.getFileName().toString())) files.add(file);
                return FileVisitResult.CONTINUE;
            }
        });
        return files;
    }

    private Map<String,String> snapshotResourceHashes(PromptResourceResolver.ResolvedResource resource) throws IOException {
        Map<String,String> hashes = new LinkedHashMap<>();
        if (resource.kind() == PromptResourceResolver.ResourceKind.FILE) {
            try { hashes.put("", sha256File(resource.root())); } catch (Exception ignored) { }
            return hashes;
        }
        for (Path file : resourceTextFiles(resource)) {
            String rel = resource.root().relativize(file).toString().replace('\\','/');
            try { hashes.put(rel, sha256File(file)); } catch (Exception ignored) { }
        }
        return hashes;
    }

    public String writeFile(Workspace ws, String rawPath, String content) throws IOException {
        String relative = normalizeRelative(rawPath);
        String value = content == null ? "" : content;
        Path file = resolve(ws.root, relative);
        if (Files.isRegularFile(file) && Objects.equals(Files.readString(file, StandardCharsets.UTF_8), value)) {
            return "workspaceChanged=false; No change to " + relative + " (content already matches)";
        }
        captureBaseline(ws, relative);
        Files.createDirectories(file.getParent());
        Files.writeString(file, value, StandardCharsets.UTF_8, StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
        ws.touched.add(relative);
        if (isWrapper(relative)) makeExecutable(file);
        return "workspaceChanged=true; Wrote " + relative + " (" + value.length() + " chars)";
    }

    public String editFile(Workspace ws, String rawPath, String oldText, String newText, boolean replaceAll) throws IOException {
        String relative = normalizeRelative(rawPath);
        Path file = resolve(ws.root, relative);
        if (!Files.isRegularFile(file)) throw new NoSuchFileException(relative);
        String current = Files.readString(file, StandardCharsets.UTF_8);
        if (oldText == null || oldText.isEmpty()) throw new IllegalArgumentException("oldText is required");
        String needle = compatibleLineEndings(current, oldText);
        int first = current.indexOf(needle);
        if (first < 0) throw new IllegalArgumentException(editNotFoundMessage(relative, current, oldText));
        if (!replaceAll && current.indexOf(needle, first + needle.length()) >= 0) {
            throw new IllegalArgumentException("oldText occurs more than once; provide more surrounding context or set replaceAll=true");
        }
        String replacement = compatibleLineEndings(current, newText == null ? "" : newText);
        String updated = replaceAll ? current.replace(needle, replacement)
                : current.substring(0, first) + replacement + current.substring(first + needle.length());
        if (Objects.equals(current, updated)) return "workspaceChanged=false; No change to " + relative + " (replacement is identical)";
        captureBaseline(ws, relative);
        Files.writeString(file, updated, StandardCharsets.UTF_8, StandardOpenOption.TRUNCATE_EXISTING);
        ws.touched.add(relative);
        return "workspaceChanged=true; Edited " + relative + " (" + (replaceAll ? "all matching occurrences" : "1 occurrence") + ")";
    }

    public String deleteFile(Workspace ws, String rawPath) throws IOException {
        String relative = normalizeRelative(rawPath);
        Path file = resolve(ws.root, relative);
        if (!Files.exists(file)) throw new NoSuchFileException(relative);
        if (!Files.isRegularFile(file)) throw new IllegalArgumentException("delete_file only deletes files, not directories: " + relative);
        captureBaseline(ws, relative);
        Files.delete(file);
        ws.touched.add(relative);
        return "workspaceChanged=true; Deleted " + relative + " directly from the active workspace";
    }

    public String applyPatch(Workspace ws, JsonNode changes, String patchText) throws IOException {
        if (changes != null && changes.isArray() && !changes.isEmpty()) return applyPatch(ws, changes);
        if (patchText != null && !patchText.isBlank()) return applyPatch(ws, openAiPatchToChanges(ws, patchText));
        throw new IllegalArgumentException("apply_patch requires either a non-empty changes array or OpenAI-style patch text");
    }

    public String applyPatch(Workspace ws, JsonNode changes) throws IOException {
        if (changes == null || !changes.isArray() || changes.isEmpty()) {
            throw new IllegalArgumentException("apply_patch requires a non-empty changes array");
        }
        record Prepared(String path, String operation, String content, Path target) {}
        List<Prepared> prepared = new ArrayList<>();
        Set<String> unique = new HashSet<>();
        for (JsonNode change : changes) {
            String relative = normalizeRelative(change.path("path").asText(""));
            if (!unique.add(relative)) throw new IllegalArgumentException("Duplicate apply_patch path: " + relative);
            String operation = change.path("operation").asText("write").trim().toLowerCase(Locale.ROOT);
            if (!Set.of("write", "delete").contains(operation)) {
                throw new IllegalArgumentException("Unsupported apply_patch operation for " + relative + ": " + operation);
            }
            String content = change.path("content").asText("");
            Path target = resolve(ws.root, relative);
            if (Files.exists(target) && !Files.isRegularFile(target)) {
                throw new IllegalArgumentException("apply_patch only supports files: " + relative);
            }
            prepared.add(new Prepared(relative, operation, content, target));
        }

        List<Prepared> actual = new ArrayList<>();
        for (Prepared item : prepared) {
            if ("delete".equals(item.operation())) {
                if (Files.isRegularFile(item.target())) actual.add(item);
            } else if (!Files.isRegularFile(item.target()) || !Objects.equals(Files.readString(item.target(), StandardCharsets.UTF_8), item.content())) {
                actual.add(item);
            }
        }
        if (actual.isEmpty()) return "workspaceChanged=false; Structured patch made no changes; requested content already matches the workspace";

        // Capture every original before the first real mutation so the batch remains reviewable as one change set.
        for (Prepared item : actual) captureBaseline(ws, item.path());

        int writes = 0, deletes = 0;
        for (Prepared item : actual) {
            if ("delete".equals(item.operation())) {
                if (Files.deleteIfExists(item.target())) deletes++;
            } else {
                Files.createDirectories(item.target().getParent());
                Files.writeString(item.target(), item.content(), StandardCharsets.UTF_8,
                        StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
                if (isWrapper(item.path())) makeExecutable(item.target());
                writes++;
            }
            ws.touched.add(item.path());
        }
        return "workspaceChanged=true; Applied structured patch directly to the active workspace: " + writes + " write(s), " + deletes + " delete(s)";
    }

    private JsonNode openAiPatchToChanges(Workspace ws, String patchText) throws IOException {
        String normalized = patchText.replace("\r\n", "\n").replace('\r', '\n').trim();
        if (!normalized.contains("*** Begin Patch") || !normalized.contains("*** End Patch")) {
            throw new IllegalArgumentException("patch text must contain *** Begin Patch and *** End Patch");
        }
        List<String> lines = Arrays.asList(normalized.split("\n", -1));
        var changes = objectMapper.createArrayNode();
        int i = 0;
        while (i < lines.size()) {
            String line = lines.get(i);
            if (line.equals("*** Begin Patch") || line.isBlank()) { i++; continue; }
            if (line.equals("*** End Patch")) break;
            if (line.startsWith("*** Add File: ")) {
                String path = normalizeRelative(line.substring("*** Add File: ".length()).trim());
                i++;
                StringBuilder content = new StringBuilder();
                while (i < lines.size() && !lines.get(i).startsWith("*** ")) {
                    String l = lines.get(i++);
                    if (l.startsWith("+")) l = l.substring(1);
                    else if (l.startsWith("\\ No newline")) continue;
                    content.append(l);
                    if (i < lines.size() && !lines.get(i).startsWith("*** ")) content.append('\n');
                }
                var change = changes.addObject();
                change.put("path", path); change.put("operation", "write"); change.put("content", content.toString());
                continue;
            }
            if (line.startsWith("*** Delete File: ")) {
                String path = normalizeRelative(line.substring("*** Delete File: ".length()).trim());
                var change = changes.addObject();
                change.put("path", path); change.put("operation", "delete");
                i++;
                while (i < lines.size() && !lines.get(i).startsWith("*** ")) i++;
                continue;
            }
            if (line.startsWith("*** Update File: ")) {
                String path = normalizeRelative(line.substring("*** Update File: ".length()).trim());
                i++;
                List<String> section = new ArrayList<>();
                String moveTo = "";
                while (i < lines.size() && !lines.get(i).startsWith("*** Update File:") &&
                        !lines.get(i).startsWith("*** Add File:") && !lines.get(i).startsWith("*** Delete File:") &&
                        !lines.get(i).equals("*** End Patch")) {
                    String l = lines.get(i++);
                    if (l.startsWith("*** Move to: ")) moveTo = normalizeRelative(l.substring("*** Move to: ".length()).trim());
                    else section.add(l);
                }
                Path source = resolve(ws.root, path);
                if (!Files.isRegularFile(source)) throw new NoSuchFileException(path);
                String current = Files.readString(source, StandardCharsets.UTF_8);
                String updated = applyOpenAiUpdateHunks(path, current, section);
                String targetPath = moveTo.isBlank() ? path : moveTo;
                var write = changes.addObject();
                write.put("path", targetPath); write.put("operation", "write"); write.put("content", updated);
                if (!targetPath.equals(path)) {
                    var delete = changes.addObject(); delete.put("path", path); delete.put("operation", "delete");
                }
                continue;
            }
            throw new IllegalArgumentException("Unsupported patch directive: " + line);
        }
        if (changes.isEmpty()) throw new IllegalArgumentException("patch text did not contain any file changes");
        return changes;
    }

    private String applyOpenAiUpdateHunks(String path, String current, List<String> section) {
        String separator = current.contains("\r\n") ? "\r\n" : "\n";
        boolean trailingNewline = current.endsWith("\n") || current.endsWith("\r");
        String normalized = current.replace("\r\n", "\n").replace('\r', '\n');
        List<String> working = new ArrayList<>(Arrays.asList(normalized.split("\n", -1)));
        if (trailingNewline && !working.isEmpty() && working.get(working.size() - 1).isEmpty()) working.remove(working.size() - 1);

        List<List<String>> hunks = new ArrayList<>();
        List<String> active = new ArrayList<>();
        for (String line : section) {
            if (line.startsWith("@@")) {
                if (!active.isEmpty()) hunks.add(active);
                active = new ArrayList<>();
                continue;
            }
            if (line.startsWith("\\ No newline")) continue;
            active.add(line);
        }
        if (!active.isEmpty()) hunks.add(active);
        if (hunks.isEmpty()) throw new IllegalArgumentException("Update patch for " + path + " contains no hunks");

        int searchFrom = 0;
        for (List<String> hunk : hunks) {
            List<String> oldLines = new ArrayList<>();
            List<String> newLines = new ArrayList<>();
            for (String raw : hunk) {
                if (raw.isEmpty()) { oldLines.add(""); newLines.add(""); continue; }
                char prefix = raw.charAt(0);
                String value = (prefix == ' ' || prefix == '+' || prefix == '-') ? raw.substring(1) : raw;
                if (prefix != '+') oldLines.add(value);
                if (prefix != '-') newLines.add(value);
            }
            int at = findLineSequence(working, oldLines, searchFrom, false);
            if (at < 0) at = findLineSequence(working, oldLines, 0, true);
            if (at < 0) {
                String anchor = oldLines.stream().filter(v -> !v.isBlank()).findFirst().orElse("[empty hunk]");
                throw new IllegalArgumentException("Patch context was not found in " + path + ". Re-read the file and regenerate the patch around current text. First hunk anchor: " + clipHint(anchor));
            }
            for (int n = 0; n < oldLines.size(); n++) working.remove(at);
            working.addAll(at, newLines);
            searchFrom = at + newLines.size();
        }
        String joined = String.join(separator, working);
        return trailingNewline ? joined + separator : joined;
    }

    private int findLineSequence(List<String> haystack, List<String> needle, int from, boolean relaxedWhitespace) {
        if (needle.isEmpty()) return Math.max(0, Math.min(from, haystack.size()));
        List<Integer> hits = new ArrayList<>();
        for (int i = Math.max(0, from); i + needle.size() <= haystack.size(); i++) {
            boolean match = true;
            for (int j = 0; j < needle.size(); j++) {
                String a = haystack.get(i + j), b = needle.get(j);
                if (relaxedWhitespace) { a = a.strip(); b = b.strip(); }
                if (!Objects.equals(a, b)) { match = false; break; }
            }
            if (match) hits.add(i);
        }
        if (hits.size() == 1) return hits.get(0);
        return -1;
    }

    private String compatibleLineEndings(String current, String value) {
        if (value == null || value.isEmpty()) return value == null ? "" : value;
        if (current.contains("\r\n")) return value.replace("\r\n", "\n").replace("\n", "\r\n");
        return value.replace("\r\n", "\n").replace('\r', '\n');
    }

    private String editNotFoundMessage(String shown, String current, String oldText) {
        String firstUseful = Arrays.stream(oldText.replace("\r\n", "\n").split("\n"))
                .map(String::strip).filter(v -> !v.isBlank()).findFirst().orElse("");
        String hint = "";
        if (!firstUseful.isBlank()) {
            int at = current.indexOf(firstUseful);
            if (at >= 0) {
                int from = Math.max(0, current.lastIndexOf('\n', Math.max(0, at - 1)));
                int to = current.indexOf('\n', Math.min(current.length() - 1, at + firstUseful.length()));
                if (to < 0) to = Math.min(current.length(), at + firstUseful.length() + 300);
                from = Math.max(0, from - 250); to = Math.min(current.length(), to + 250);
                hint = " Closest current context: " + clipHint(current.substring(from, to).replace('\r', ' ').replace('\n', ' '));
            }
        }
        return "oldText was not found in " + shown + ". The file may have changed since the model last read it. Re-read the exact target lines, then retry edit with current text or use write/apply_patch." + hint;
    }

    private String clipHint(String value) {
        if (value == null) return "";
        String clean = value.replaceAll("\\s+", " ").strip();
        return clean.length() <= 500 ? clean : clean.substring(0, 500) + "…";
    }

    public String moveFile(Workspace ws, String rawSource, String rawTarget, boolean overwrite) throws IOException {
        String source = normalizeRelative(rawSource);
        String target = normalizeRelative(rawTarget);
        if (source.equals(target)) return "workspaceChanged=false; Source and target are identical; no change made";
        Path sourcePath = resolve(ws.root, source);
        Path targetPath = resolve(ws.root, target);
        if (!Files.isRegularFile(sourcePath)) throw new NoSuchFileException(source);
        if (Files.exists(targetPath) && !overwrite) throw new FileAlreadyExistsException(target);
        captureBaseline(ws, source);
        captureBaseline(ws, target);
        Files.createDirectories(targetPath.getParent());
        if (overwrite) Files.move(sourcePath, targetPath, StandardCopyOption.REPLACE_EXISTING);
        else Files.move(sourcePath, targetPath);
        ws.touched.add(source);
        ws.touched.add(target);
        if (isWrapper(target)) makeExecutable(targetPath);
        return "workspaceChanged=true; Moved " + source + " -> " + target;
    }

    public String copyFile(Workspace ws, String rawSource, String rawTarget, boolean overwrite) throws IOException {
        String source = normalizeRelative(rawSource);
        String target = normalizeRelative(rawTarget);
        if (source.equals(target)) return "workspaceChanged=false; Source and target are identical; no change made";
        Path sourcePath = resolve(ws.root, source);
        Path targetPath = resolve(ws.root, target);
        if (!Files.isRegularFile(sourcePath)) throw new NoSuchFileException(source);
        if (Files.exists(targetPath) && !overwrite) throw new FileAlreadyExistsException(target);
        if (Files.isRegularFile(targetPath) && overwrite && Files.mismatch(sourcePath, targetPath) == -1L) {
            return "workspaceChanged=false; No change to " + target + " (target already matches source)";
        }
        captureBaseline(ws, target);
        Files.createDirectories(targetPath.getParent());
        if (overwrite) Files.copy(sourcePath, targetPath, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.COPY_ATTRIBUTES);
        else Files.copy(sourcePath, targetPath, StandardCopyOption.COPY_ATTRIBUTES);
        ws.touched.add(target);
        return "workspaceChanged=true; Copied " + source + " -> " + target;
    }

    private void captureBaseline(Workspace ws, String relative) throws IOException {
        if (ws.baseline.containsKey(relative)) return;
        if (ws.baselineHashes.containsKey(relative)) {
            if (Hashing.ABSENT.equals(ws.baselineHashes.get(relative))) {
                ws.baseline.put(relative, null);
            } else {
                ws.baseline.put(relative, originalText(ws, relative));
            }
            return;
        }
        Path file = resolveTracked(ws, relative, false);
        if (Files.exists(file) && Files.isRegularFile(file)) {
            String content = Files.readString(file, StandardCharsets.UTF_8);
            ws.baseline.put(relative, content);
            ws.baselineHashes.put(relative, Hashing.sha256(content));
        } else {
            ws.baseline.put(relative, null);
            ws.baselineHashes.put(relative, Hashing.ABSENT);
        }
    }

    private void initializeBaselineHashes(Workspace ws) throws IOException {
        for (String relative : allPaths(ws)) {
            if (!isReadableTextPath(relative)) continue;
            Path file = resolve(ws.root, relative);
            try {
                ws.baselineHashes.put(relative, sha256File(file));
            } catch (Exception ignored) {
                // Unreadable/binary-like files are intentionally outside the staged text patch model.
            }
        }
    }

    private String originalText(Workspace ws, String relative) throws IOException {
        if (ws.baseline.containsKey(relative)) return ws.baseline.get(relative);
        if (Hashing.ABSENT.equals(ws.baselineHashes.get(relative))) return null;
        return ws.baseline.get(relative);
    }

    public String changedFiles(Workspace ws) throws IOException {
        List<ProjectPatchRequest.ProjectPatchFile> changes = changes(ws);
        if (changes.isEmpty()) return "[No files changed by this agent run]";
        return changes.stream().map(f -> f.safeOperation().toUpperCase(Locale.ROOT) + " " + f.path() +
                ("delete".equals(f.safeOperation()) ? "" : " (" + (f.content() == null ? 0 : f.content().length()) + " chars)"))
                .collect(Collectors.joining("\n"));
    }

    public String workspaceStatus(Workspace ws) throws IOException {
        List<ProjectPatchRequest.ProjectPatchFile> changes = changes(ws);
        if (changes.isEmpty()) return "workspace clean (no changes recorded by this agent run)";
        List<String> rows = new ArrayList<>();
        for (ProjectPatchRequest.ProjectPatchFile change : changes) {
            boolean existed = !Hashing.ABSENT.equals(change.baselineHash());
            if ("delete".equals(change.safeOperation())) rows.add("D  " + change.path());
            else if (!existed) rows.add("A  " + change.path());
            else rows.add("M  " + change.path());
        }
        return String.join("\n", rows);
    }

    public String workspaceDiff(Workspace ws, String requestedPath) throws IOException {
        List<String> targets = requestedPath == null || requestedPath.isBlank()
                ? new ArrayList<>(ws.touched)
                : List.of(normalizeRelative(requestedPath));
        if (targets.isEmpty()) return "[No recorded agent changes]";
        StringBuilder out = new StringBuilder();
        for (String relative : targets) {
            if (!ws.touched.contains(relative)) continue;
            Path file = resolveTracked(ws, relative, false);
            String before = ws.baseline.containsKey(relative) ? ws.baseline.get(relative) : originalText(ws, relative);
            boolean exists = Files.exists(file) && Files.isRegularFile(file);
            String after = exists ? Files.readString(file, StandardCharsets.UTF_8) : null;
            if (Objects.equals(before, after)) continue;
            out.append("--- a/").append(relative).append("\n+++ b/").append(relative).append("\n");
            String baselineHash = ws.baselineHashes.getOrDefault(relative, before == null ? Hashing.ABSENT : Hashing.sha256(before));
            if (before == null && !Hashing.ABSENT.equals(baselineHash)) {
                out.append("@@ original @@\n[original content not retained; file was changed by shell; original sha256=")
                        .append(baselineHash).append("]\n");
            } else {
                out.append("@@ original @@\n").append(before == null ? "[new file / absent]\n" : before);
            }
            out.append("\n@@ updated @@\n").append(after == null ? "[deleted]\n" : after).append('\n');
        }
        return out.isEmpty() ? "[No recorded agent changes]" : clip(out.toString());
    }

    public List<ProjectPatchRequest.ProjectPatchFile> changes(Workspace ws) throws IOException {
        List<ProjectPatchRequest.ProjectPatchFile> result = new ArrayList<>();
        for (String relative : ws.touched) {
            Path file = resolveTracked(ws, relative, false);
            String before = ws.baseline.containsKey(relative) ? ws.baseline.get(relative) : originalText(ws, relative);
            String baselineHash = ws.baselineHashes.getOrDefault(relative, before == null ? Hashing.ABSENT : Hashing.sha256(before));
            if (Files.exists(file) && Files.isRegularFile(file)) {
                String current = Files.readString(file, StandardCharsets.UTF_8);
                if (!Objects.equals(before, current)) {
                    result.add(new ProjectPatchRequest.ProjectPatchFile(relative, current, baselineHash, "write"));
                }
            } else if (before != null || !Hashing.ABSENT.equals(baselineHash)) {
                result.add(new ProjectPatchRequest.ProjectPatchFile(relative, null, baselineHash, "delete"));
            }
        }
        result.sort(Comparator.comparing(ProjectPatchRequest.ProjectPatchFile::path, String.CASE_INSENSITIVE_ORDER));
        return result;
    }

    public CommandResult runBuild(Workspace ws, String cwd, boolean allowed, AgentRunService.AgentRun run) throws Exception {
        requireCommands(allowed);
        Path dir = workingDirectory(ws, cwd);
        run.checkCancelled();
        if (Files.exists(dir.resolve("pom.xml"))) return runMaven(ws, dir, List.of("-q", "-DskipTests", "package"), Duration.ZERO, run);
        if (Files.exists(dir.resolve("build.gradle")) || Files.exists(dir.resolve("build.gradle.kts"))) return runGradle(ws, dir, List.of("build", "-x", "test"), Duration.ZERO, run);
        if (Files.exists(dir.resolve("package.json"))) return runNodeScript(ws, dir, "build", Duration.ZERO, run);
        if (Files.exists(dir.resolve("go.mod"))) return run(ws, dir, List.of("go", "build", "./..."), Duration.ZERO, run);
        if (Files.exists(dir.resolve("Cargo.toml"))) return run(ws, dir, List.of("cargo", "build"), Duration.ZERO, run);
        if (hasRootSuffix(dir, ".sln") || hasRootSuffix(dir, ".csproj")) return run(ws, dir, List.of("dotnet", "build"), Duration.ZERO, run);
        if (Files.exists(dir.resolve("CMakeLists.txt"))) {
            Path buildDir = dir.resolve(".agent-build");
            CommandResult configure = run(ws, dir, List.of("cmake", "-S", ".", "-B", buildDir.toString()), Duration.ZERO, run);
            if (configure.exitCode() != 0) return configure;
            CommandResult build = run(ws, dir, List.of("cmake", "--build", buildDir.toString()), Duration.ZERO, run);
            return combine(configure, build);
        }
        if (Files.exists(dir.resolve("Makefile")) || Files.exists(dir.resolve("makefile"))) return run(ws, dir, List.of("make"), Duration.ZERO, run);
        if (Files.exists(dir.resolve("build.xml"))) return run(ws, dir, List.of("ant"), Duration.ZERO, run);
        if (Files.exists(dir.resolve("Package.swift"))) return run(ws, dir, List.of("swift", "build"), Duration.ZERO, run);
        if (Files.exists(dir.resolve("pubspec.yaml"))) {
            CommandResult flutter = run(ws, dir, List.of("flutter", "analyze"), Duration.ZERO, run);
            if (!commandMissing(flutter)) return flutter;
            return run(ws, dir, List.of("dart", "analyze"), Duration.ZERO, run);
        }
        if (Files.exists(dir.resolve("WORKSPACE")) || Files.exists(dir.resolve("WORKSPACE.bazel")) || Files.exists(dir.resolve("MODULE.bazel"))) {
            return run(ws, dir, List.of("bazel", "build", "//..."), Duration.ZERO, run);
        }
        if (Files.exists(dir.resolve("composer.json"))) return run(ws, dir, List.of("composer", "validate", "--no-check-publish"), Duration.ZERO, run);
        if (Files.exists(dir.resolve("Gemfile"))) return run(ws, dir, List.of("bundle", "exec", "rake"), Duration.ZERO, run);
        if (Files.exists(dir.resolve("build.sbt"))) return run(ws, dir, List.of("sbt", "compile"), Duration.ZERO, run);
        if (Files.exists(dir.resolve("mix.exs"))) return run(ws, dir, List.of("mix", "compile"), Duration.ZERO, run);
        if (Files.exists(dir.resolve("project.clj"))) return run(ws, dir, List.of("lein", "check"), Duration.ZERO, run);
        if (Files.exists(dir.resolve("build.zig"))) return run(ws, dir, List.of("zig", "build"), Duration.ZERO, run);
        if (Files.exists(dir.resolve("stack.yaml"))) return run(ws, dir, List.of("stack", "build"), Duration.ZERO, run);
        if (Files.exists(dir.resolve("cabal.project")) || hasRootSuffix(dir, ".cabal")) return run(ws, dir, List.of("cabal", "build", "all"), Duration.ZERO, run);
        if (Files.exists(dir.resolve("pyproject.toml")) || Files.exists(dir.resolve("setup.py")) || Files.exists(dir.resolve("requirements.txt"))) {
            CommandResult system = run(ws, dir, List.of("python", "-m", "compileall", "."), Duration.ZERO, run);
            if (!commandMissing(system)) return system;
            return run(ws, dir, List.of("python3", "-m", "compileall", "."), Duration.ZERO, run);
        }
        return new CommandResult(-1, "No supported build descriptor found in " + displayCwd(ws, dir) + ". Use inspect_workspace and build with cwd for monorepos, or bash for a custom toolchain.", Duration.ZERO);
    }

    public CommandResult runTests(Workspace ws, String cwd, boolean allowed, AgentRunService.AgentRun run) throws Exception {
        requireCommands(allowed);
        Path dir = workingDirectory(ws, cwd);
        run.checkCancelled();
        if (Files.exists(dir.resolve("pom.xml"))) return runMaven(ws, dir, List.of("-q", "test"), Duration.ZERO, run);
        if (Files.exists(dir.resolve("build.gradle")) || Files.exists(dir.resolve("build.gradle.kts"))) return runGradle(ws, dir, List.of("test"), Duration.ZERO, run);
        if (Files.exists(dir.resolve("package.json"))) return runNodeScript(ws, dir, "test", Duration.ZERO, run);
        if (Files.exists(dir.resolve("go.mod"))) return run(ws, dir, List.of("go", "test", "./..."), Duration.ZERO, run);
        if (Files.exists(dir.resolve("Cargo.toml"))) return run(ws, dir, List.of("cargo", "test"), Duration.ZERO, run);
        if (hasRootSuffix(dir, ".sln") || hasRootSuffix(dir, ".csproj")) return run(ws, dir, List.of("dotnet", "test"), Duration.ZERO, run);
        if (Files.exists(dir.resolve("pyproject.toml")) || Files.exists(dir.resolve("pytest.ini")) || Files.exists(dir.resolve("tests"))) {
            CommandResult direct = run(ws, dir, List.of("pytest", "-q"), Duration.ZERO, run);
            if (!commandMissing(direct)) return direct;
            CommandResult system = run(ws, dir, List.of("python", "-m", "pytest", "-q"), Duration.ZERO, run);
            if (!commandMissing(system)) return system;
            return run(ws, dir, List.of("python3", "-m", "pytest", "-q"), Duration.ZERO, run);
        }
        if (Files.exists(dir.resolve("CMakeLists.txt"))) {
            Path buildDir = dir.resolve(".agent-build");
            if (!Files.isDirectory(buildDir)) {
                CommandResult configure = run(ws, dir, List.of("cmake", "-S", ".", "-B", buildDir.toString()), Duration.ZERO, run);
                if (configure.exitCode() != 0) return configure;
            }
            return run(ws, dir, List.of("ctest", "--test-dir", buildDir.toString(), "--output-on-failure"), Duration.ZERO, run);
        }
        if (Files.exists(dir.resolve("Makefile")) || Files.exists(dir.resolve("makefile"))) return run(ws, dir, List.of("make", "test"), Duration.ZERO, run);
        if (Files.exists(dir.resolve("build.xml"))) return run(ws, dir, List.of("ant", "test"), Duration.ZERO, run);
        if (Files.exists(dir.resolve("Package.swift"))) return run(ws, dir, List.of("swift", "test"), Duration.ZERO, run);
        if (Files.exists(dir.resolve("pubspec.yaml"))) {
            CommandResult flutter = run(ws, dir, List.of("flutter", "test"), Duration.ZERO, run);
            if (!commandMissing(flutter)) return flutter;
            return run(ws, dir, List.of("dart", "test"), Duration.ZERO, run);
        }
        if (Files.exists(dir.resolve("WORKSPACE")) || Files.exists(dir.resolve("WORKSPACE.bazel")) || Files.exists(dir.resolve("MODULE.bazel"))) {
            return run(ws, dir, List.of("bazel", "test", "//..."), Duration.ZERO, run);
        }
        if (Files.exists(dir.resolve("Gemfile"))) return run(ws, dir, List.of("bundle", "exec", "rake", "test"), Duration.ZERO, run);
        if (Files.exists(dir.resolve("build.sbt"))) return run(ws, dir, List.of("sbt", "test"), Duration.ZERO, run);
        if (Files.exists(dir.resolve("mix.exs"))) return run(ws, dir, List.of("mix", "test"), Duration.ZERO, run);
        if (Files.exists(dir.resolve("project.clj"))) return run(ws, dir, List.of("lein", "test"), Duration.ZERO, run);
        if (Files.exists(dir.resolve("build.zig"))) return run(ws, dir, List.of("zig", "build", "test"), Duration.ZERO, run);
        if (Files.exists(dir.resolve("stack.yaml"))) return run(ws, dir, List.of("stack", "test"), Duration.ZERO, run);
        if (Files.exists(dir.resolve("cabal.project")) || hasRootSuffix(dir, ".cabal")) return run(ws, dir, List.of("cabal", "test", "all"), Duration.ZERO, run);
        return new CommandResult(-1, "No supported test runner detected in " + displayCwd(ws, dir) + ". Use inspect_workspace and test with cwd for monorepos, or bash for a custom test tool.", Duration.ZERO);
    }

    public CommandResult runCheck(Workspace ws, String cwd, boolean allowed, AgentRunService.AgentRun run) throws Exception {
        requireCommands(allowed);
        Path dir = workingDirectory(ws, cwd);
        run.checkCancelled();
        if (Files.exists(dir.resolve("package.json"))) {
            for (String script : List.of("lint", "check", "typecheck")) {
                if (packageScriptExists(dir, script)) return runNodeScript(ws, dir, script, Duration.ZERO, run);
            }
            return new CommandResult(-1, "package.json defines no lint/check/typecheck script in " + displayCwd(ws, dir) + ".", Duration.ZERO);
        }
        if (Files.exists(dir.resolve("pom.xml"))) return runMaven(ws, dir, List.of("-q", "-DskipTests", "verify"), Duration.ZERO, run);
        if (Files.exists(dir.resolve("build.gradle")) || Files.exists(dir.resolve("build.gradle.kts"))) return runGradle(ws, dir, List.of("check"), Duration.ZERO, run);
        if (Files.exists(dir.resolve("pyproject.toml")) || Files.exists(dir.resolve("setup.py")) || Files.exists(dir.resolve("requirements.txt"))) {
            CommandResult system = run(ws, dir, List.of("python", "-m", "compileall", "."), Duration.ZERO, run);
            if (!commandMissing(system)) return system;
            return run(ws, dir, List.of("python3", "-m", "compileall", "."), Duration.ZERO, run);
        }
        if (Files.exists(dir.resolve("pubspec.yaml"))) {
            CommandResult flutter = run(ws, dir, List.of("flutter", "analyze"), Duration.ZERO, run);
            if (!commandMissing(flutter)) return flutter;
            return run(ws, dir, List.of("dart", "analyze"), Duration.ZERO, run);
        }
        if (containsTerraform(dir)) {
            CommandResult terraform = run(ws, dir, List.of("terraform", "fmt", "-check", "-recursive"), Duration.ZERO, run);
            if (!commandMissing(terraform)) return terraform;
            return run(ws, dir, List.of("tofu", "fmt", "-check", "-recursive"), Duration.ZERO, run);
        }
        if (Files.exists(dir.resolve("composer.json"))) return run(ws, dir, List.of("composer", "validate", "--no-check-publish"), Duration.ZERO, run);
        return new CommandResult(-1, "No generic check/lint command detected in " + displayCwd(ws, dir) + ".", Duration.ZERO);
    }

    public CommandResult runCommand(Workspace ws, String command, String cwd, boolean allowed, Set<String> extraCommands,
                                    long timeoutSeconds, AgentRunService.AgentRun run) throws Exception {
        requireCommands(allowed);
        if (command == null || command.isBlank()) throw new IllegalArgumentException("bash requires a command");
        if (command.contains("\u0000")) throw new SecurityException("Command contains an invalid NUL character");
        // Trusted local-agent model: shell commands, including Git, run with the user's normal local permissions.
        Path dir = workingDirectory(ws, cwd);
        Map<String,String> beforeHashes = null;
        if (ws.changeJournal != null) ws.changeJournal.beginCommand();
        else beforeHashes = snapshotTrackedHashes(ws); // compatibility fallback when OS watching is unavailable
        List<String> shell = isWindows()
                ? List.of("cmd.exe", "/d", "/s", "/c", command)
                : List.of("/bin/sh", "-lc", command);
        Duration timeout = timeoutSeconds <= 0 ? Duration.ZERO : Duration.ofSeconds(timeoutSeconds);
        CommandResult result = run(ws, dir, shell, timeout, run);
        List<String> changed = ws.changeJournal != null
                ? markExternalJournalChanges(ws, ws.changeJournal.finishCommand())
                : markExternalHashChanges(ws, beforeHashes == null ? Map.of() : beforeHashes);
        if (!changed.isEmpty()) {
            String metadata = "workspaceChanged=true; changedFiles=" + changed.size() + "\n" + String.join("\n", changed.stream().map(v -> "changed: " + v).toList());
            result = new CommandResult(result.exitCode(), metadata + "\n" + result.output(), result.elapsed());
        }
        return result;
    }

    public String startProcess(Workspace ws, String command, String cwd, boolean allowed, AgentRunService.AgentRun run) throws Exception {
        requireCommands(allowed);
        if (command == null || command.isBlank()) throw new IllegalArgumentException("process_start requires a command");
        if (command.contains("\u0000")) throw new SecurityException("Command contains an invalid NUL character");
        Path dir = workingDirectory(ws, cwd);
        List<String> shell = isWindows()
                ? List.of("cmd.exe", "/d", "/s", "/c", command)
                : List.of("/bin/sh", "-lc", command);
        Path log = Files.createTempFile("advanced-ai-agent-process-", ".log");
        ProcessBuilder builder = new ProcessBuilder(shell);
        builder.directory(dir.toFile());
        builder.redirectErrorStream(true);
        builder.redirectOutput(log.toFile());
        prepareEnvironment(builder.environment(), ws.root);
        Process process;
        try {
            process = builder.start();
        } catch (IOException e) {
            Files.deleteIfExists(log);
            throw new IOException("Unable to start background process: " + e.getMessage(), e);
        }
        String id = UUID.randomUUID().toString();
        managedProcesses.put(id, new ManagedProcess(id, run.id(), ws.projectId(), ws.root(), command, dir, process, log, System.nanoTime()));
        return "processId=" + id + "; pid=" + process.pid() + "; running=" + process.isAlive() + "; cwd=" + displayCwd(ws, dir);
    }

    public String processStatus(Workspace ws, String processId) {
        ManagedProcess item = requireManagedProcess(ws, processId);
        boolean running = item.process().isAlive();
        String exit = running ? "" : "; exitCode=" + safeExitValue(item.process());
        return "processId=" + item.id() + "; pid=" + item.process().pid() + "; running=" + running + exit +
                "; command=" + item.command();
    }

    public String processOutput(Workspace ws, String processId, long offset, int maxChars) throws IOException {
        ManagedProcess item = requireManagedProcess(ws, processId);
        String output;
        try { output = Files.exists(item.log()) ? Files.readString(item.log(), StandardCharsets.UTF_8) : ""; }
        catch (Exception e) { return "[Process output unavailable: " + e.getMessage() + "]"; }
        int start = (int) Math.min(Math.max(0L, offset), output.length());
        if (maxChars <= 0) return output.substring(start);
        int end = Math.min(output.length(), start + maxChars);
        String chunk = output.substring(start, end);
        if (end < output.length()) chunk += "\n[More output available; nextOffset=" + end + "]";
        return chunk;
    }

    public String httpRequest(String method, String url, List<String> headers, String body, long timeoutSeconds,
                              AgentRunService.AgentRun run) throws Exception {
        run.checkCancelled();
        String verb = method == null || method.isBlank() ? "GET" : method.trim().toUpperCase(Locale.ROOT);
        if (url == null || url.isBlank()) throw new IllegalArgumentException("http_request requires url");
        URI uri;
        try { uri = URI.create(url.trim()); }
        catch (Exception e) { throw new IllegalArgumentException("Invalid URL: " + url, e); }
        if (!Set.of("http", "https").contains(uri.getScheme() == null ? "" : uri.getScheme().toLowerCase(Locale.ROOT))) {
            throw new IllegalArgumentException("http_request supports only http:// and https:// URLs");
        }
        HttpRequest.BodyPublisher publisher = (body == null || body.isEmpty())
                ? HttpRequest.BodyPublishers.noBody()
                : HttpRequest.BodyPublishers.ofString(body, StandardCharsets.UTF_8);
        HttpRequest.Builder builder = HttpRequest.newBuilder(uri).method(verb, publisher);
        if (timeoutSeconds > 0) builder.timeout(Duration.ofSeconds(timeoutSeconds));
        if (headers != null) {
            for (String header : headers) {
                if (header == null || header.isBlank()) continue;
                int colon = header.indexOf(':');
                if (colon <= 0) throw new IllegalArgumentException("HTTP header must use 'Name: value': " + header);
                builder.header(header.substring(0, colon).trim(), header.substring(colon + 1).trim());
            }
        }
        HttpClient client = HttpClient.newBuilder().followRedirects(HttpClient.Redirect.NORMAL).build();
        long start = System.nanoTime();
        CompletableFuture<HttpResponse<String>> future = client.sendAsync(builder.build(), HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
        HttpResponse<String> response;
        while (true) {
            if (run.cancelled()) {
                future.cancel(true);
                throw new AgentCancelledException("Agent run was cancelled during HTTP request");
            }
            try { response = future.get(200, TimeUnit.MILLISECONDS); break; }
            catch (java.util.concurrent.TimeoutException ignored) { }
            catch (java.util.concurrent.ExecutionException e) {
                Throwable cause = e.getCause();
                if (cause instanceof Exception ex) throw ex;
                throw e;
            }
        }
        run.checkCancelled();
        long elapsedMs = Duration.ofNanos(System.nanoTime() - start).toMillis();
        StringBuilder out = new StringBuilder();
        out.append("statusCode=").append(response.statusCode()).append("; elapsedMs=").append(elapsedMs).append('\n');
        response.headers().map().forEach((name, values) -> out.append(name).append(": ").append(String.join(", ", values)).append('\n'));
        out.append("\n").append(response.body() == null ? "" : response.body());
        return out.toString();
    }

    public String stopProcess(Workspace ws, String processId) {
        ManagedProcess item = requireManagedProcess(ws, processId);
        terminateProcess(item.process());
        managedProcesses.remove(item.id());
        try { Files.deleteIfExists(item.log()); } catch (Exception ignored) { }
        return "processId=" + item.id() + "; stopped=true";
    }

    public void stopRunProcesses(String runId) {
        if (runId == null || runId.isBlank()) return;
        List<ManagedProcess> items = managedProcesses.values().stream()
                .filter(item -> runId.equals(item.runId()))
                .toList();
        for (ManagedProcess item : items) {
            terminateProcess(item.process());
            managedProcesses.remove(item.id());
            try { Files.deleteIfExists(item.log()); } catch (Exception ignored) { }
        }
    }

    private ManagedProcess requireManagedProcess(Workspace ws, String processId) {
        String id = processId == null ? "" : processId.trim();
        ManagedProcess item = managedProcesses.get(id);
        if (item == null) throw new IllegalArgumentException("Managed process not found: " + id);
        if (!Objects.equals(item.workspaceId(), ws.projectId()) || !Objects.equals(item.root(), ws.root())) {
            throw new SecurityException("Managed process belongs to a different workspace");
        }
        return item;
    }

    private int safeExitValue(Process process) {
        try { return process.exitValue(); } catch (IllegalThreadStateException e) { return Integer.MIN_VALUE; }
    }

    private CommandResult runMaven(Workspace ws, Path dir, List<String> args, Duration timeout, AgentRunService.AgentRun run) throws Exception {
        Path wrapper = findWrapper(dir, ws.root, isWindows() ? "mvnw.cmd" : "mvnw");
        if (wrapper != null) {
            String executable = isWindows() ? wrapper.toString() : wrapper.toString();
            if (!isWindows()) makeExecutable(wrapper);
            List<String> command = new ArrayList<>();
            command.add(executable);
            command.addAll(args);
            CommandResult result = run(ws, dir, command, timeout, run);
            if (!commandMissing(result)) return result;
        }
        List<String> command = new ArrayList<>();
        command.add("mvn");
        command.addAll(args);
        return run(ws, dir, command, timeout, run);
    }

    private CommandResult runGradle(Workspace ws, Path dir, List<String> args, Duration timeout, AgentRunService.AgentRun run) throws Exception {
        Path wrapper = findWrapper(dir, ws.root, isWindows() ? "gradlew.bat" : "gradlew");
        if (wrapper != null) {
            if (!isWindows()) makeExecutable(wrapper);
            List<String> command = new ArrayList<>();
            command.add(wrapper.toString());
            command.addAll(args);
            CommandResult result = run(ws, dir, command, timeout, run);
            if (!commandMissing(result)) return result;
        }
        List<String> command = new ArrayList<>();
        command.add("gradle");
        command.addAll(args);
        return run(ws, dir, command, timeout, run);
    }

    private CommandResult runNodeScript(Workspace ws, Path dir, String script, Duration timeout, AgentRunService.AgentRun run) throws Exception {
        if (!packageScriptExists(dir, script)) {
            return new CommandResult(-1, "package.json does not define a '" + script + "' script in " + displayCwd(ws, dir) + ".", Duration.ZERO);
        }
        List<String> command;
        if (Files.exists(dir.resolve("pnpm-lock.yaml"))) command = List.of("pnpm", "run", script);
        else if (Files.exists(dir.resolve("yarn.lock"))) command = List.of("yarn", "run", script);
        else if (Files.exists(dir.resolve("bun.lockb")) || Files.exists(dir.resolve("bun.lock"))) command = List.of("bun", "run", script);
        else command = List.of("npm", "run", script);
        return run(ws, dir, command, timeout, run);
    }

    private boolean packageScriptExists(Path dir, String script) {
        Path packageJson = dir.resolve("package.json");
        if (!Files.isRegularFile(packageJson)) return false;
        try {
            JsonNode root = objectMapper.readTree(Files.readString(packageJson, StandardCharsets.UTF_8));
            JsonNode scripts = root.path("scripts");
            return scripts.isObject() && scripts.has(script) && !scripts.path(script).asText("").isBlank();
        } catch (Exception ignored) {
            return false;
        }
    }

    private CommandResult combine(CommandResult first, CommandResult second) {
        return new CommandResult(second.exitCode(), first.output() + "\n\n" + second.output(), first.elapsed().plus(second.elapsed()));
    }

    private CommandResult run(Workspace ws, Path workingDir, List<String> command, Duration timeout,
                              AgentRunService.AgentRun run) throws Exception {
        run.checkCancelled();
        List<String> effective = new ArrayList<>(command);
        ProcessBuilder builder;
        String first = effective.get(0);
        if (isWindows() && (first.toLowerCase(Locale.ROOT).endsWith(".cmd") || first.toLowerCase(Locale.ROOT).endsWith(".bat") ||
                Set.of("mvn", "gradle", "npm", "npx", "pnpm", "yarn", "bun").contains(first.toLowerCase(Locale.ROOT)))) {
            List<String> cmd = new ArrayList<>();
            cmd.add("cmd.exe");
            cmd.add("/d");
            cmd.add("/c");
            cmd.addAll(effective);
            builder = new ProcessBuilder(cmd);
        } else {
            builder = new ProcessBuilder(effective);
        }
        builder.directory(workingDir.toFile());
        builder.redirectErrorStream(true);
        // Foreground command output must stay on a pipe instead of being redirected to a temporary file.
        // On Windows, redirecting to a freshly-created Temp file can intermittently fail with ERROR_SHARING_VIOLATION
        // ("The process cannot access the file because it is being used by another process"), which previously
        // prevented npm/npx/node/Maven commands from starting and trapped the agent in verification retries.
        prepareEnvironment(builder.environment(), ws.root);

        long start = System.nanoTime();
        Process process;
        try {
            process = builder.start();
        } catch (IOException e) {
            return new CommandResult(127, "Unable to start command: " + String.join(" ", command) + "\n" + safeMessage(e), Duration.ZERO);
        }

        StringBuffer captured = new StringBuffer();
        Thread outputPump = new Thread(() -> drainProcessOutput(process, captured), "agent-command-output");
        outputPump.setDaemon(true);
        outputPump.start();

        run.registerProcess(process);
        boolean completed = false;
        boolean unlimited = timeout == null || timeout.isZero() || timeout.isNegative();
        long deadline = unlimited ? Long.MAX_VALUE : System.nanoTime() + timeout.toNanos();
        try {
            while (unlimited || System.nanoTime() < deadline) {
                run.checkCancelled();
                if (process.waitFor(250, TimeUnit.MILLISECONDS)) {
                    completed = true;
                    break;
                }
            }
            run.checkCancelled();
            if (!completed && !unlimited) {
                terminateProcess(process);
                process.waitFor(5, TimeUnit.SECONDS);
            }
        } finally {
            run.unregisterProcess(process);
        }

        // The pipe is drained concurrently, so commands that produce large output cannot deadlock waiting for
        // the OS pipe buffer. Give the reader a short chance to consume the final bytes after process exit.
        try { outputPump.join(2_000L); } catch (InterruptedException interrupted) { Thread.currentThread().interrupt(); }

        int exit = completed ? process.exitValue() : 124;
        String output = captured.toString();
        Duration elapsed = Duration.ofNanos(System.nanoTime() - start);
        String shown = "$ " + String.join(" ", command) + "\n" + (completed ? "" : "[Timed out after " + timeout.toSeconds() + "s]\n") + output;
        return new CommandResult(exit, clip(shown), elapsed);
    }

    private void drainProcessOutput(Process process, StringBuffer target) {
        try (InputStreamReader reader = new InputStreamReader(process.getInputStream(), StandardCharsets.UTF_8)) {
            char[] buffer = new char[8192];
            int read;
            while ((read = reader.read(buffer)) >= 0) {
                if (read > 0) target.append(buffer, 0, read);
            }
        } catch (IOException e) {
            target.append("\n[Command output read error: ").append(safeMessage(e)).append("]");
        }
    }

    private String safeMessage(Throwable error) {
        if (error == null) return "unknown error";
        String message = error.getMessage();
        return message == null || message.isBlank() ? error.getClass().getSimpleName() : message;
    }

    private void prepareEnvironment(Map<String,String> env, Path root) {
        // Match a local coding agent: inherit the user's environment so Maven/Gradle/npm/Python and
        // private registries work exactly as they do in the user's terminal. Do not rewrite HOME.
        env.put("AGENT_WORKSPACE", root.toString());
        env.putIfAbsent("GIT_TERMINAL_PROMPT", "0");
        env.putIfAbsent("PIP_DISABLE_PIP_VERSION_CHECK", "1");
        env.putIfAbsent("NPM_CONFIG_UPDATE_NOTIFIER", "false");
        env.putIfAbsent("CI", "true");
    }

    private void terminateProcess(Process process) {
        if (process == null || !process.isAlive()) return;
        try { process.descendants().forEach(handle -> { try { handle.destroy(); } catch (Exception ignored) { } }); }
        catch (Exception ignored) { }
        try { process.destroy(); } catch (Exception ignored) { }
        if (process.isAlive()) {
            try { process.descendants().forEach(handle -> { try { handle.destroyForcibly(); } catch (Exception ignored) { } }); }
            catch (Exception ignored) { }
            try { process.destroyForcibly(); } catch (Exception ignored) { }
        }
    }

    public VerificationAdvice verificationAdvice(Workspace ws) throws IOException {
        List<ProjectPatchRequest.ProjectPatchFile> actualChanges = changes(ws);
        if (actualChanges.isEmpty()) return new VerificationAdvice(false, "No recorded agent changes");
        List<String> codeChanges = actualChanges.stream().map(ProjectPatchRequest.ProjectPatchFile::path).filter(this::isCodeLike).toList();
        if (codeChanges.isEmpty()) return new VerificationAdvice(false, "Only documentation/data/non-code text changes detected");
        for (String changed : codeChanges) {
            Path boundary = trackedBoundary(ws, changed);
            Path candidate = resolveTracked(ws, changed, false).getParent();
            while (candidate != null && candidate.startsWith(boundary)) {
                if (directoryHasVerifier(candidate)) {
                    return new VerificationAdvice(true, "Code/config changes have a detectable project verifier near " + trackedDisplay(ws, changed, candidate, boundary));
                }
                if (candidate.equals(boundary)) break;
                candidate = candidate.getParent();
            }
        }
        return new VerificationAdvice(false, "Code changed but no runnable built-in verifier was detected near the changed files; use bash with verification=true if the project has a custom verifier");
    }

    private Path trackedBoundary(Workspace ws, String key) {
        if (key != null && key.startsWith("@")) {
            int slash = key.indexOf('/');
            String alias = slash < 0 ? key.substring(1) : key.substring(1, slash);
            PromptResourceResolver.ResolvedResource resource = ws.resources.get(alias);
            if (resource != null) return resource.root();
        }
        return ws.root;
    }

    private String trackedDisplay(Workspace ws, String key, Path dir, Path boundary) {
        if (key != null && key.startsWith("@")) {
            int slash = key.indexOf('/');
            String alias = slash < 0 ? key.substring(1) : key.substring(1, slash);
            String rel = boundary.equals(dir) ? "" : boundary.relativize(dir).toString().replace('\\','/');
            return "@" + alias + (rel.isBlank() ? "" : "/" + rel);
        }
        return displayCwd(ws, dir);
    }

    private boolean directoryHasVerifier(Path dir) throws IOException {
        if (Files.exists(dir.resolve("pom.xml")) || Files.exists(dir.resolve("build.gradle")) || Files.exists(dir.resolve("build.gradle.kts")) ||
                Files.exists(dir.resolve("go.mod")) || Files.exists(dir.resolve("Cargo.toml")) || Files.exists(dir.resolve("CMakeLists.txt")) ||
                Files.exists(dir.resolve("Makefile")) || Files.exists(dir.resolve("makefile")) || Files.exists(dir.resolve("build.xml")) ||
                Files.exists(dir.resolve("Package.swift")) || Files.exists(dir.resolve("pubspec.yaml")) || Files.exists(dir.resolve("WORKSPACE")) ||
                Files.exists(dir.resolve("WORKSPACE.bazel")) || Files.exists(dir.resolve("MODULE.bazel")) || Files.exists(dir.resolve("composer.json")) ||
                Files.exists(dir.resolve("Gemfile")) || Files.exists(dir.resolve("build.sbt")) || Files.exists(dir.resolve("mix.exs")) ||
                Files.exists(dir.resolve("project.clj")) || Files.exists(dir.resolve("build.zig")) || Files.exists(dir.resolve("stack.yaml")) ||
                Files.exists(dir.resolve("cabal.project")) || Files.exists(dir.resolve("pyproject.toml")) || Files.exists(dir.resolve("setup.py")) ||
                Files.exists(dir.resolve("requirements.txt")) || hasRootSuffix(dir, ".sln") || hasRootSuffix(dir, ".csproj") ||
                hasRootSuffix(dir, ".fsproj") || hasRootSuffix(dir, ".vbproj") || hasRootSuffix(dir, ".cabal") || containsTerraform(dir)) return true;
        return Files.exists(dir.resolve("package.json")) &&
                (packageScriptExists(dir, "build") || packageScriptExists(dir, "test") || packageScriptExists(dir, "lint") || packageScriptExists(dir, "check") || packageScriptExists(dir, "typecheck"));
    }

    public void cleanup(Workspace ws) {
        // Direct workspace mode never deletes/rolls back user files; cleanup only releases runtime watchers.
        if (ws != null && ws.changeJournal != null) {
            try { ws.changeJournal.close(); } catch (Exception ignored) { }
        }
    }

    private Path workingDirectory(Workspace ws, String rawCwd) {
        if (rawCwd == null || rawCwd.isBlank() || ".".equals(rawCwd.trim())) return ws.root;
        String relative = normalizeRelative(rawCwd);
        Path dir = resolve(ws.root, relative);
        if (!Files.exists(dir) || !Files.isDirectory(dir)) throw new IllegalArgumentException("cwd is not a directory in the workspace: " + relative);
        return dir;
    }

    private String displayCwd(Workspace ws, Path dir) {
        if (dir.equals(ws.root)) return ".";
        return ws.root.relativize(dir).toString().replace('\\','/');
    }

    private Path findWrapper(Path start, Path root, String name) {
        Path current = start;
        while (current != null && current.startsWith(root)) {
            Path candidate = current.resolve(name);
            if (Files.isRegularFile(candidate)) return candidate;
            if (current.equals(root)) break;
            current = current.getParent();
        }
        return null;
    }

    private boolean hasRootSuffix(Path root, String suffix) throws IOException {
        try (Stream<Path> stream = Files.list(root)) {
            String low = suffix.toLowerCase(Locale.ROOT);
            return stream.filter(Files::isRegularFile)
                    .anyMatch(path -> path.getFileName().toString().toLowerCase(Locale.ROOT).endsWith(low));
        }
    }

    private boolean containsTerraform(Path dir) throws IOException {
        try (Stream<Path> stream = Files.list(dir)) {
            return stream.filter(Files::isRegularFile).anyMatch(path -> path.getFileName().toString().toLowerCase(Locale.ROOT).endsWith(".tf"));
        }
    }

    private ChangeJournal createChangeJournal(Path root) {
        try { return new ChangeJournal(root); }
        catch (Exception ignored) { return null; }
    }

    private List<String> markExternalJournalChanges(Workspace ws, Collection<String> changedPaths) {
        if (changedPaths == null || changedPaths.isEmpty()) return List.of();
        List<String> changed = new ArrayList<>();
        for (String relative : changedPaths) {
            if (relative == null || relative.isBlank() || isSkippedPath(relative)) continue;
            // A shell mutation is observed after the fact. Preserve that it existed/changed without forcing a full
            // pre-command repository hash scan; workspace_diff will explicitly say the original content was not retained.
            ws.baselineHashes.putIfAbsent(relative, "UNKNOWN_BEFORE_SHELL");
            ws.baseline.putIfAbsent(relative, null);
            ws.touched.add(relative);
            changed.add(relative);
        }
        changed.sort(String.CASE_INSENSITIVE_ORDER);
        return List.copyOf(changed);
    }

    private List<String> markExternalHashChanges(Workspace ws, Map<String,String> beforeHashes) throws IOException {
        Map<String,String> afterHashes = snapshotTrackedHashes(ws);
        LinkedHashSet<String> candidates = new LinkedHashSet<>();
        candidates.addAll(beforeHashes.keySet());
        candidates.addAll(afterHashes.keySet());
        List<String> changed = new ArrayList<>();
        for (String relative : candidates) {
            String beforeHash = beforeHashes.getOrDefault(relative, Hashing.ABSENT);
            String afterHash = afterHashes.getOrDefault(relative, Hashing.ABSENT);
            if (Objects.equals(beforeHash, afterHash)) continue;
            if (!ws.baselineHashes.containsKey(relative)) {
                ws.baselineHashes.put(relative, beforeHash);
                // A shell can mutate arbitrary files. Keep the original hash without cloning the whole workspace.
                // Explicit file tools still retain full original text for detailed workspace_diff output.
                ws.baseline.put(relative, null);
            }
            ws.touched.add(relative);
            changed.add(relative);
        }
        return changed;
    }

    private Map<String,String> snapshotTrackedHashes(Workspace ws) throws IOException {
        Map<String,String> hashes = new LinkedHashMap<>();
        for (String relative : allPaths(ws)) {
            if (!isReadableTextPath(relative) && !ws.touched.contains(relative)) continue;
            Path file = resolve(ws.root, relative);
            try {
                hashes.put(relative, sha256File(file));
            } catch (Exception ignored) { }
        }
        return hashes;
    }

    private boolean commandMissing(CommandResult result) {
        if (result == null) return true;
        if (result.exitCode() == 127 || result.exitCode() == 9009) return true;
        String text = result.output() == null ? "" : result.output().toLowerCase(Locale.ROOT);
        return text.contains("not recognized as an internal or external command") || text.contains("command not found") || text.contains("unable to start command") || text.contains("no such file or directory");
    }

    private void requireCommands(boolean allowed) {
        if (!allowed) throw new SecurityException("Agent command execution is disabled by permissions");
    }

    private String sha256File(Path file) throws IOException {
        try {
            java.security.MessageDigest digest = java.security.MessageDigest.getInstance("SHA-256");
            try (java.io.InputStream in = Files.newInputStream(file)) {
                byte[] buffer = new byte[64 * 1024];
                int read;
                while ((read = in.read(buffer)) >= 0) {
                    if (read > 0) digest.update(buffer, 0, read);
                }
            }
            return java.util.HexFormat.of().formatHex(digest.digest());
        } catch (java.security.NoSuchAlgorithmException e) {
            throw new IllegalStateException("SHA-256 is unavailable", e);
        }
    }

    private List<String> allPaths(Workspace ws) throws IOException {
        List<String> paths = new ArrayList<>();
        Files.walkFileTree(ws.root, new SimpleFileVisitor<>() {
            @Override public FileVisitResult preVisitDirectory(Path dir, java.nio.file.attribute.BasicFileAttributes attrs) {
                if (!dir.equals(ws.root)) {
                    String name = dir.getFileName() == null ? "" : dir.getFileName().toString().toLowerCase(Locale.ROOT);
                    if (SKIP_DIRS.contains(name)) return FileVisitResult.SKIP_SUBTREE;
                }
                return FileVisitResult.CONTINUE;
            }
            @Override public FileVisitResult visitFile(Path file, java.nio.file.attribute.BasicFileAttributes attrs) {
                if (!Files.isSymbolicLink(file) && Files.isRegularFile(file)) {
                    paths.add(ws.root.relativize(file).toString().replace('\\','/'));
                }
                return FileVisitResult.CONTINUE;
            }
        });
        paths.sort(String.CASE_INSENSITIVE_ORDER);
        return paths;
    }

    private List<String> textPaths(Workspace ws) throws IOException {
        return allPaths(ws).stream().filter(p -> isReadableTextPath(p) || ws.touched.contains(p)).toList();
    }

    private boolean isReadableTextPath(String relative) {
        String normalized = relative == null ? "" : relative.replace('\\','/');
        String name = Path.of(normalized.isBlank() ? "_" : normalized).getFileName().toString().toLowerCase(Locale.ROOT);
        if (name.startsWith(".env")) return true;
        if (Set.of("pom.xml","package.json","package-lock.json","yarn.lock","pnpm-lock.yaml","bun.lockb","gradlew","gradlew.bat",
                "mvnw","mvnw.cmd","dockerfile","makefile","cmakelists.txt","jenkinsfile","build.xml","package.swift","pubspec.yaml",
                "composer.json","gemfile","rakefile","workspace","workspace.bazel","module.bazel","build.bazel","build.sbt","mix.exs",
                "project.clj","build.zig","stack.yaml","cabal.project",".gitignore",".dockerignore",".editorconfig").contains(name)) return true;
        int dot = name.lastIndexOf('.');
        return dot > 0 && TEXT_EXTENSIONS.contains(name.substring(dot + 1));
    }

    private boolean isSkippedPath(String relative) {
        for (String part : relative.split("/")) if (SKIP_DIRS.contains(part.toLowerCase(Locale.ROOT))) return true;
        return false;
    }

    private boolean isDescriptor(String path) {
        String name = Path.of(path).getFileName().toString().toLowerCase(Locale.ROOT);
        return Set.of("pom.xml", "build.gradle", "build.gradle.kts", "package.json", "pyproject.toml", "setup.py", "requirements.txt",
                        "go.mod", "cargo.toml", "cmakelists.txt", "makefile", "build.xml", "composer.json", "gemfile", "package.swift", "pubspec.yaml",
                        "workspace", "workspace.bazel", "module.bazel", "build.sbt", "mix.exs", "project.clj", "build.zig", "stack.yaml", "cabal.project").contains(name)
                || name.endsWith(".sln") || name.endsWith(".csproj") || name.endsWith(".fsproj") || name.endsWith(".vbproj") || name.endsWith(".tf") || name.endsWith(".cabal");
    }

    private String descriptorKind(String path) {
        String name = Path.of(path).getFileName().toString().toLowerCase(Locale.ROOT);
        if (name.equals("pom.xml")) return "Maven/Java";
        if (name.startsWith("build.gradle")) return "Gradle/JVM";
        if (name.equals("package.json")) return "Node/JavaScript/TypeScript";
        if (Set.of("pyproject.toml", "setup.py", "requirements.txt").contains(name)) return "Python";
        if (name.equals("go.mod")) return "Go";
        if (name.equals("cargo.toml")) return "Rust/Cargo";
        if (name.endsWith(".sln") || name.endsWith(".csproj") || name.endsWith(".fsproj") || name.endsWith(".vbproj")) return ".NET";
        if (name.equals("cmakelists.txt")) return "CMake/C/C++";
        if (name.equals("makefile")) return "Make";
        if (name.equals("build.xml")) return "Ant/Java";
        if (name.equals("composer.json")) return "PHP/Composer";
        if (name.equals("gemfile")) return "Ruby/Bundler";
        if (name.equals("package.swift")) return "Swift Package Manager";
        if (name.equals("pubspec.yaml")) return "Dart/Flutter";
        if (Set.of("workspace", "workspace.bazel", "module.bazel").contains(name)) return "Bazel";
        if (name.equals("build.sbt")) return "Scala/sbt";
        if (name.equals("mix.exs")) return "Elixir/Mix";
        if (name.equals("project.clj")) return "Clojure/Leiningen";
        if (name.equals("build.zig")) return "Zig";
        if (name.equals("stack.yaml") || name.equals("cabal.project") || name.endsWith(".cabal")) return "Haskell";
        if (name.endsWith(".tf")) return "Terraform/OpenTofu configuration";
        return "project descriptor";
    }

    private boolean isCodeLike(String path) {
        String name = Path.of(path).getFileName().toString().toLowerCase(Locale.ROOT);
        if (isDescriptor(path)) return true;
        int dot = name.lastIndexOf('.');
        return dot >= 0 && CODE_EXTENSIONS.contains(name.substring(dot + 1));
    }

    private String normalizeRelative(String raw) {
        if (raw == null || raw.isBlank()) throw new IllegalArgumentException("Project path is required");
        String p = raw.replace('\\','/').replaceAll("^/+", "");
        while (p.contains("//")) p = p.replace("//", "/");
        if (p.isBlank() || p.equals(".") || p.startsWith("../") || p.contains("/../") || p.endsWith("/..") || p.contains("\u0000")) {
            throw new SecurityException("Invalid project path: " + raw);
        }
        if (p.length() > 1200) throw new IllegalArgumentException("Project path is too long");
        return p;
    }

    private Path resolve(Path root, String relative) {
        Path result = root.resolve(relative).normalize();
        if (!result.startsWith(root)) throw new SecurityException("Path escapes the active workspace: " + relative);
        // Lexical startsWith is not enough when an in-workspace path segment is a symlink to somewhere
        // outside the selected directory. Reject symlink traversal entirely for deterministic path scoping.
        Path cursor = root;
        try {
            for (Path part : root.relativize(result)) {
                cursor = cursor.resolve(part);
                if (Files.exists(cursor, LinkOption.NOFOLLOW_LINKS) && Files.isSymbolicLink(cursor)) {
                    throw new SecurityException("Workspace path contains a symbolic link and is not allowed: " + relative);
                }
            }
        } catch (InvalidPathException e) {
            throw new SecurityException("Invalid workspace path: " + relative);
        }
        return result;
    }

    private boolean isWindows() {
        return System.getProperty("os.name", "").toLowerCase(Locale.ROOT).contains("win");
    }

    private boolean isWrapper(String path) {
        String low = path.toLowerCase(Locale.ROOT);
        return low.endsWith("mvnw") || low.endsWith("gradlew") || low.endsWith("mvnw.cmd") || low.endsWith("gradlew.bat");
    }

    private void makeWrappersExecutable(Path root) {
        for (String name : List.of("mvnw", "gradlew")) {
            Path path = root.resolve(name);
            if (Files.exists(path)) makeExecutable(path);
        }
    }

    private void makeExecutable(Path path) {
        try {
            Set<PosixFilePermission> perms = Files.getPosixFilePermissions(path);
            perms.add(PosixFilePermission.OWNER_EXECUTE);
            Files.setPosixFilePermissions(path, perms);
        } catch (Exception ignored) {
            try { path.toFile().setExecutable(true, true); } catch (Exception ignoredAgain) { }
        }
    }

    private String clip(String text) {
        return text == null ? "" : text;
    }

    /**
     * Per-workspace incremental filesystem journal. It watches source/config directories once per Agent run and
     * records only paths that actually change, avoiding full repository hashing around every shell command.
     */
    private static final class ChangeJournal implements AutoCloseable {
        private final Path root;
        private final WatchService watcher;
        private final Map<WatchKey,Path> directories = new ConcurrentHashMap<>();
        private final Set<String> changed = ConcurrentHashMap.newKeySet();
        private final Thread thread;
        private volatile boolean running = true;

        ChangeJournal(Path root) throws IOException {
            this.root = root.toAbsolutePath().normalize().toRealPath();
            this.watcher = FileSystems.getDefault().newWatchService();
            registerRecursively(this.root);
            this.thread = new Thread(this::loop, "agent-workspace-watch-" + Integer.toHexString(this.root.hashCode()));
            this.thread.setDaemon(true);
            this.thread.start();
        }

        void beginCommand() { changed.clear(); }

        List<String> finishCommand() {
            // Most WatchService providers publish promptly but asynchronously. A short quiet window captures trailing
            // rename/write events without adding repository-size dependent work.
            int stable = -1;
            for (int i = 0; i < 5; i++) {
                try { Thread.sleep(30); } catch (InterruptedException e) { Thread.currentThread().interrupt(); break; }
                int size = changed.size();
                if (size == stable) break;
                stable = size;
            }
            ArrayList<String> out = new ArrayList<>(changed);
            changed.clear();
            out.sort(String.CASE_INSENSITIVE_ORDER);
            return List.copyOf(out);
        }

        private void registerRecursively(Path start) throws IOException {
            if (!Files.isDirectory(start, LinkOption.NOFOLLOW_LINKS) || Files.isSymbolicLink(start)) return;
            Files.walkFileTree(start, new SimpleFileVisitor<>() {
                @Override public FileVisitResult preVisitDirectory(Path dir, java.nio.file.attribute.BasicFileAttributes attrs) throws IOException {
                    if (!dir.equals(root)) {
                        String rel = root.relativize(dir).toString().replace('\\','/');
                        for (String part : rel.split("/")) if (SKIP_DIRS.contains(part.toLowerCase(Locale.ROOT))) return FileVisitResult.SKIP_SUBTREE;
                    }
                    WatchKey key = dir.register(watcher, StandardWatchEventKinds.ENTRY_CREATE, StandardWatchEventKinds.ENTRY_MODIFY, StandardWatchEventKinds.ENTRY_DELETE);
                    directories.put(key, dir);
                    return FileVisitResult.CONTINUE;
                }
            });
        }

        private void loop() {
            while (running) {
                WatchKey key;
                try { key = watcher.take(); }
                catch (InterruptedException e) { Thread.currentThread().interrupt(); break; }
                catch (ClosedWatchServiceException e) { break; }
                Path dir = directories.get(key);
                if (dir != null) {
                    for (WatchEvent<?> event : key.pollEvents()) {
                        if (event.kind() == StandardWatchEventKinds.OVERFLOW) continue;
                        Object context = event.context();
                        if (!(context instanceof Path name)) continue;
                        Path absolute = dir.resolve(name).normalize();
                        if (!absolute.startsWith(root)) continue;
                        String rel = root.relativize(absolute).toString().replace('\\','/');
                        boolean skipped = false;
                        for (String part : rel.split("/")) if (SKIP_DIRS.contains(part.toLowerCase(Locale.ROOT))) { skipped = true; break; }
                        if (skipped) continue;
                        changed.add(rel);
                        if (event.kind() == StandardWatchEventKinds.ENTRY_CREATE && Files.isDirectory(absolute, LinkOption.NOFOLLOW_LINKS) && !Files.isSymbolicLink(absolute)) {
                            try { registerRecursively(absolute); } catch (Exception ignored) { }
                        }
                    }
                }
                if (!key.reset()) directories.remove(key);
            }
        }

        @Override public void close() {
            running = false;
            try { watcher.close(); } catch (Exception ignored) { }
            thread.interrupt();
        }
    }

    public static final class Workspace {
        private final String projectId;
        private final Path root;
        private final Map<String,String> baseline;
        private final Map<String,String> baselineHashes;
        private final LinkedHashSet<String> touched = new LinkedHashSet<>();
        private final LinkedHashMap<String, PromptResourceResolver.ResolvedResource> resources;
        private final ChangeJournal changeJournal;

        private Workspace(String projectId, Path root, Map<String,String> baseline, Map<String,String> baselineHashes,
                          Map<String, PromptResourceResolver.ResolvedResource> resources, ChangeJournal changeJournal) {
            this.projectId = projectId;
            this.root = root;
            this.baseline = baseline;
            this.baselineHashes = baselineHashes;
            this.resources = new LinkedHashMap<>(resources == null ? Map.of() : resources);
            this.changeJournal = changeJournal;
        }

        public String projectId() { return projectId; }
        public Path root() { return root; }
        public boolean direct() { return true; }
        public Map<String, PromptResourceResolver.ResolvedResource> resources() { return Collections.unmodifiableMap(resources); }
    }

    private record ManagedProcess(String id, String runId, String workspaceId, Path root, String command,
                                  Path cwd, Process process, Path log, long startedNanos) {}

    public record CommandResult(int exitCode, String output, Duration elapsed) {
        public String asToolText() {
            return "exitCode=" + exitCode + "; elapsedMs=" + elapsed.toMillis() + "\n" + output;
        }
    }

    public record VerificationAdvice(boolean required, String reason) {}
}
