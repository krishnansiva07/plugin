package com.llmart.llm.service;

import com.llmart.llm.dto.ChatMode;
import com.llmart.llm.dto.ChatRequest;
import com.llmart.llm.dto.MessageDto;
import com.llmart.llm.entity.ConversationEntity;
import com.llmart.llm.entity.MessageEntity;
import jakarta.annotation.PreDestroy;
import org.springframework.stereotype.Service;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;

@Service
public class ChatService {
    private final ConversationService conversations;
    private final FileService files;
    private final ContextService contextService;
    private final ProjectService projects;
    private final OpenAiCompatibleClient llm;
    private final AgentService agentService;
    private final AgentRunService agentRuns;
    private final PromptResourceResolver resourceResolver;
    private final ExecutorService runExecutor = Executors.newFixedThreadPool(
            Math.max(2, Math.min(8, Runtime.getRuntime().availableProcessors())), r -> {
        Thread t = new Thread(r, "agent-run-executor"); t.setDaemon(true); return t;
    });

    public ChatService(ConversationService conversations, FileService files,
                       ContextService contextService, ProjectService projects,
                       OpenAiCompatibleClient llm, AgentService agentService, AgentRunService agentRuns,
                       PromptResourceResolver resourceResolver) {
        this.conversations = conversations;
        this.files = files;
        this.contextService = contextService;
        this.projects = projects;
        this.llm = llm;
        this.agentService = agentService;
        this.agentRuns = agentRuns;
        this.resourceResolver = resourceResolver;
    }

    public SseEmitter stream(String apiKey, ChatRequest request) {
        if (apiKey == null || apiKey.isBlank()) throw new IllegalArgumentException("API key is required");
        SseEmitter emitter = new SseEmitter(0L);
        AtomicReference<String> activeRunId = new AtomicReference<>();
        AtomicBoolean clientClosed = new AtomicBoolean(false);
        Runnable cancelActiveRun = () -> {
            clientClosed.set(true);
            String id = activeRunId.get();
            if (id != null) agentRuns.cancel(id);
        };
        emitter.onTimeout(cancelActiveRun);
        emitter.onError(error -> cancelActiveRun.run());
        emitter.onCompletion(cancelActiveRun);

        CompletableFuture.runAsync(() -> {
            try {
                ConversationEntity conversation = conversations.getOrCreate(request.conversationId());
                MessageEntity userMessage;

                if (request.isRegenerate()) {
                    userMessage = conversations.lastUserMessage(conversation.getId());
                    conversations.removeMessagesAfter(conversation.getId(), userMessage.getId());
                } else {
                    List<String> attachmentIds = request.attachmentIds() == null ? List.of() : request.attachmentIds();
                    files.requireForConversation(conversation.getId(), attachmentIds);
                    String userText = request.message();
                    if ((userText == null || userText.isBlank()) && attachmentIds.isEmpty()) {
                        throw new IllegalArgumentException("Message or attachment is required");
                    }
                    if (userText == null || userText.isBlank()) {
                        userText = "Please analyze the attached file(s).";
                    }
                    userMessage = conversations.addMessage(conversation.getId(), "user", userText.strip(), attachmentIds);
                }

                ChatMode mode = request.chatMode();
                String effectiveProjectId = request.projectId();
                boolean autoResolvedWorkspace = false;

                // Prompt paths are authoritative in Agent mode. This lets the user switch projects simply by
                // supplying a different existing project/file path, even when an older workspace is still active in
                // the browser. When no path is supplied, the existing project id remains available for follow-up turns.
                if (mode == ChatMode.AGENT) {
                    var inferred = resourceResolver.primaryProjectPath(userMessage.getContent());
                    if (inferred.isPresent()) {
                        var mapped = projects.createLocal(conversation.getId(), inferred.get().toString(), inferred.get().getFileName() == null ? "Prompt workspace" : inferred.get().getFileName().toString());
                        effectiveProjectId = mapped.id();
                        autoResolvedWorkspace = true;
                    } else if (effectiveProjectId != null && !effectiveProjectId.isBlank()) {
                        projects.requireConversation(effectiveProjectId, conversation.getId());
                    }
                } else if (effectiveProjectId != null && !effectiveProjectId.isBlank()) {
                    projects.requireConversation(effectiveProjectId, conversation.getId());
                }

                if (mode == ChatMode.AGENT) {
                    if (effectiveProjectId == null || effectiveProjectId.isBlank()) {
                        throw new IllegalArgumentException("Agent mode requires either an active local workspace or an explicit existing project/file path in the prompt.");
                    }
                    var activeWorkspace = projects.require(effectiveProjectId);
                    if (!activeWorkspace.hasLocalPath()) {
                        throw new IllegalArgumentException("Agent mode requires a local-path workspace because tools operate directly on that path.");
                    }
                }

                ChatRequest effectiveRequest = Objects.equals(effectiveProjectId, request.projectId()) ? request : new ChatRequest(
                        request.conversationId(), request.message(), request.attachmentIds(), effectiveProjectId, request.mode(), request.regenerate(), request.settings());

                List<Map<String, Object>> context = contextService.build(
                        conversation.getId(), userMessage, request.settings(), effectiveProjectId, apiKey, mode);

                AgentRunService.AgentRun agentRun = mode == ChatMode.AGENT
                        ? agentRuns.start(conversation.getId(), effectiveProjectId)
                        : null;
                if (agentRun != null) {
                    activeRunId.set(agentRun.id());
                    if (clientClosed.get()) agentRuns.cancel(agentRun.id());
                }
                Map<String,Object> meta = new LinkedHashMap<>();
                meta.put("conversationId", conversation.getId());
                meta.put("userMessageId", userMessage.getId());
                meta.put("mode", mode.wireName());
                if (agentRun != null) meta.put("agentRunId", agentRun.id());
                if (effectiveProjectId != null && !effectiveProjectId.isBlank()) meta.put("projectId", effectiveProjectId);
                if (autoResolvedWorkspace) meta.put("autoResolvedWorkspace", true);
                emitter.send(SseEmitter.event().name("meta").data(meta));

                String answer;
                if (mode == ChatMode.AGENT) {
                    AgentService.AgentResult result = agentService.run(agentRun.id(), apiKey, effectiveRequest, context, event -> {
                        try { emitter.send(SseEmitter.event().name("agent_step").data(event)); }
                        catch (Exception ignored) { /* run state is durable; the browser can recover through /api/agent/runs/{id} */ }
                    });
                    answer = result.answer();

                    // Persist the terminal result BEFORE relying on the SSE transport. If a proxy/browser keeps the
                    // stream open or drops the final event, the UI watchdog can recover this durable answer by run id.
                    MessageEntity assistant = conversations.addMessage(conversation.getId(), "assistant", answer, List.of());
                    MessageDto dto = conversations.messageDto(assistant);
                    agentRun.markResponsePersisted(String.valueOf(dto.id()), answer);
                    try {
                        emitter.send(SseEmitter.event().name("token").data(Map.of("text", visibleAgentAnswer(answer))));
                        if (!result.changes().isEmpty()) {
                            emitter.send(SseEmitter.event().name("agent_changes").data(Map.of(
                                    "count", result.changes().size(), "mode", "direct")));
                        }
                        emitter.send(SseEmitter.event().name("done").data(dto));
                    } catch (Exception ignored) { /* durable run status is the transport fallback */ }
                    emitter.complete();
                    return;
                }

                answer = llm.stream(apiKey, request.settings(), context, token -> {
                    try {
                        emitter.send(SseEmitter.event().name("token").data(Map.of("text", token)));
                    } catch (Exception e) {
                        throw new RuntimeException(e);
                    }
                });

                MessageEntity assistant = conversations.addMessage(conversation.getId(), "assistant", answer, List.of());
                MessageDto dto = conversations.messageDto(assistant);
                emitter.send(SseEmitter.event().name("done").data(dto));
                emitter.complete();
            } catch (Exception e) {
                try { emitter.send(SseEmitter.event().name("error").data(Map.of("message", safeMessage(e)))); }
                catch (Exception ignored) {}
                emitter.completeWithError(e);
            }
        }, runExecutor);
        return emitter;
    }

    @PreDestroy
    public void shutdownExecutor() { runExecutor.shutdownNow(); }

    private String visibleAgentAnswer(String value) {
        if (value == null) return "";
        return value.replaceAll("(?is)<!--\\s*PROJECT_FILE_START:[^>]+-->.*?<!--\\s*PROJECT_FILE_END\\s*-->", "").strip();
    }

    private String safeMessage(Exception e) {
        String m = e.getMessage();
        if (m == null || m.isBlank()) return e.getClass().getSimpleName();
        return m.length() > 1500 ? m.substring(0, 1500) : m;
    }
}
