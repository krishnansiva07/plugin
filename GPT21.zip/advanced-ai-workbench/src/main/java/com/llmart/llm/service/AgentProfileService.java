package com.llmart.llm.service;

import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.stream.Stream;

/** Discovers OpenCode/Claude-like reusable agent profiles from the selected workspace. */
@Service
public class AgentProfileService {
    public Map<String,AgentProfile> discover(AgentWorkspaceService.Workspace ws) {
        LinkedHashMap<String,AgentProfile> profiles = new LinkedHashMap<>();
        profiles.put("explore", new AgentProfile("explore", "Read-only project exploration and root-cause investigation", "subagent", "", """
                You are an Explore subagent. Investigate the requested question using read-only workspace evidence. Search broadly but return a compact, concrete report to the parent agent. Do not modify files or start long-running processes.
                """, Set.of("inspect_workspace","workspace_profile","list","glob","grep","file_info","read","read_many","attachment_list","attachment_read","attachment_search","skill","instruction_catalog","instructions_for","mcp_status","lsp_status","lsp")));
        profiles.put("general", new AgentProfile("general", "General-purpose delegated investigation and implementation", "subagent", "", """
                You are a General subagent. Complete the delegated task autonomously using the tools provided. Return evidence, files/locations inspected, actions taken, and blockers. Do not invoke another subagent.
                """, Set.of())); // empty => all parent tools except task
        for (String rootName : List.of(".agents/agents", ".opencode/agents", ".claude/agents")) {
            Path root = ws.root().resolve(rootName).normalize();
            if (!root.startsWith(ws.root()) || !Files.isDirectory(root)) continue;
            try (Stream<Path> files = Files.walk(root, 6)) {
                files.filter(Files::isRegularFile).filter(p -> p.getFileName().toString().toLowerCase(Locale.ROOT).endsWith(".md")).sorted().forEach(path -> {
                    try {
                        String rel = root.relativize(path).toString().replace('\\','/');
                        String id = rel.replaceFirst("(?i)\\.md$", "");
                        AgentProfile p = parse(id, Files.readString(path, StandardCharsets.UTF_8));
                        if (Set.of("subagent","all").contains(p.mode())) profiles.put(id, p);
                    } catch (Exception ignored) { }
                });
            } catch (IOException ignored) { }
        }
        return Map.copyOf(profiles);
    }

    public String catalogText(AgentWorkspaceService.Workspace ws) {
        Map<String,AgentProfile> profiles = discover(ws);
        if (profiles.isEmpty()) return "[No subagents available]";
        StringBuilder out = new StringBuilder();
        for (AgentProfile p : profiles.values()) out.append(p.id()).append(" — ").append(p.description()).append('\n');
        return out.toString().stripTrailing();
    }

    public AgentProfile require(AgentWorkspaceService.Workspace ws, String id) {
        AgentProfile p = discover(ws).get(id);
        if (p == null) throw new IllegalArgumentException("Unknown subagent '" + id + "'. Available:\n" + catalogText(ws));
        return p;
    }

    private AgentProfile parse(String id, String text) {
        String description = "Project-defined subagent";
        String mode = "subagent";
        // One-model runtime: project agent profiles may specialize instructions/tools, never the model.
        String model = "";
        LinkedHashSet<String> tools = new LinkedHashSet<>();
        String body = text == null ? "" : text;
        if (body.startsWith("---")) {
            int end = body.indexOf("\n---", 3);
            if (end >= 0) {
                String fm = body.substring(3, end);
                body = body.substring(end + 4).strip();
                for (String line : fm.split("\\R")) {
                    int colon = line.indexOf(':');
                    if (colon < 0) continue;
                    String key = line.substring(0,colon).trim().toLowerCase(Locale.ROOT);
                    String value = stripQuotes(line.substring(colon+1).trim());
                    if ("description".equals(key) && !value.isBlank()) description = value;
                    else if ("mode".equals(key) && !value.isBlank()) mode = value.toLowerCase(Locale.ROOT);
                    else if ("model".equals(key)) { /* intentionally ignored: all agents inherit the configured model */ }
                    else if ("tools".equals(key)) for (String t : value.replace("[","").replace("]","").split(",")) if (!t.isBlank()) tools.add(stripQuotes(t.trim()));
                }
            }
        }
        return new AgentProfile(id, description, mode, model, body, Set.copyOf(tools));
    }

    private String stripQuotes(String s) {
        if (s == null) return "";
        String v=s.trim();
        if (v.length()>=2 && ((v.startsWith("\"")&&v.endsWith("\""))||(v.startsWith("'")&&v.endsWith("'")))) return v.substring(1,v.length()-1);
        return v;
    }

    public record AgentProfile(String id, String description, String mode, String model, String systemPrompt,
                               Set<String> allowedTools) { }
}
