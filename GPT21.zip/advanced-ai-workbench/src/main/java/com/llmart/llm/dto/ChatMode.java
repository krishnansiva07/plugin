package com.llmart.llm.dto;

import java.util.Locale;

public enum ChatMode {
    CHAT,
    AGENT;

    public static ChatMode from(String raw) {
        if (raw == null || raw.isBlank()) return CHAT;
        String normalized = raw.trim().toUpperCase(Locale.ROOT);
        // Older browser state may still contain "analyze". Treat it as Chat so upgrades are seamless.
        if ("ANALYZE".equals(normalized) || "ANALYSE".equals(normalized)) return CHAT;
        try {
            return valueOf(normalized);
        } catch (IllegalArgumentException ignored) {
            return CHAT;
        }
    }

    public String wireName() {
        return name().toLowerCase(Locale.ROOT);
    }
}
