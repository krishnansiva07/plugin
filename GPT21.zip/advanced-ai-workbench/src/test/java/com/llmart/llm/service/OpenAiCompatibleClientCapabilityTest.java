package com.llmart.llm.service;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class OpenAiCompatibleClientCapabilityTest {
    @Test void genericBadRequestDoesNotDisableNativeTools() {
        assertFalse(OpenAiCompatibleClient.indicatesUnsupportedNativeTools(400, "invalid argument: messages[2]"));
        assertFalse(OpenAiCompatibleClient.indicatesUnsupportedNativeTools(422, "tool arguments failed schema validation"));
    }

    @Test void explicitUnsupportedToolCapabilityIsDetected() {
        assertTrue(OpenAiCompatibleClient.indicatesUnsupportedNativeTools(400, "This model does not support tools"));
        assertTrue(OpenAiCompatibleClient.indicatesUnsupportedNativeTools(422, "unknown parameter: tool_choice; function calling is unsupported"));
    }

    @Test void jsonFormatRequiresExplicitCapabilitySignal() {
        assertFalse(OpenAiCompatibleClient.indicatesUnsupportedJsonFormat(400, "invalid messages array"));
        assertTrue(OpenAiCompatibleClient.indicatesUnsupportedJsonFormat(400, "response_format is not supported by this model"));
    }
}
