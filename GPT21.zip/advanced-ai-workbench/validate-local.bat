@echo off
setlocal
cd /d "%~dp0"
echo [1/5] Java
java -version || exit /b 1
echo [2/5] Frontend syntax
where node >nul 2>nul
if %errorlevel%==0 (
  node --check src\main\resources\static\app.js || exit /b 1
  node --check src\main\resources\static\markdown.js || exit /b 1
) else (
  echo Node is not installed; skipping JavaScript syntax checks.
)
echo [3/5] Maven availability/bootstrap
call mvnw.cmd -version || exit /b 1
echo [4/5] Compile + release install ^(optional tests skipped by design^)
call mvnw.cmd clean install || exit /b 1
echo [5/5] Optional full test suite
if "%FULL_TESTS%"=="1" (
  call mvnw.cmd -Pfull-tests test || exit /b 1
) else (
  echo Skipped. Set FULL_TESTS=1 and rerun validate-local.bat, or run mvnw.cmd -Pfull-tests test.
)
echo Validation complete. JAR: target\advanced-ai-workbench.jar
