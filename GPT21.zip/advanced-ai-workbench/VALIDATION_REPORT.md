# Validation Report

## Completed in this package

- Frontend JavaScript syntax: PASS (`node --check` for `app.js` and `markdown.js`)
- Shell script syntax: PASS
- `pom.xml` XML parse: PASS
- HTML parser check: PASS
- Java 17 source syntax scan: PASS (no parser/syntax diagnostics; external dependency symbols are unavailable in this environment)
- Java 17 changed-core compile with lightweight external stubs: PASS
  - `ChatSettings`
  - `AgentRunService`
  - `ContextWindowManager`
  - `WorkspaceRetrievalIndexService`
- Executable token-management harness: PASS
  - adaptive 128k/200k compaction thresholds
  - durable objective/plan/touched-path persistence
  - single changing durable-state suffix
  - aggressive old-tool pruning without deleting real user messages
  - local lexical retrieval index ranking
- Executable sequential-agent harness: PASS
  - todo-only step completion rejected
  - verified mutation required before next step
  - exactly one next plan step unlocked
  - model failover preserves active step
- ZIP integrity test: performed after packaging

## Token-management changes validated

- Removed fixed 68% compaction threshold.
- Added provider-safe input limit + dynamic headroom algorithm.
- Added early deterministic/aggressive pruning before compaction.
- Added durable objective, plan, verification, model and touched-file state outside active transcript.
- Added local model-free workspace lexical retrieval index.
- Added pruning/cache/token-savings telemetry.
- Changed defaults to 8k recent context and 20k safety buffer.

## Maven note

The included Maven wrapper is valid, but this execution environment cannot resolve Maven Central, so dependency-backed Maven/Spring compilation cannot be run here. Normal release installation keeps optional tests skipped by design. Run `mvnw.cmd clean install` on Windows or `./mvnw clean install` on Linux/macOS. Use `-Pfull-tests test` only when you explicitly want the complete test suite.
