# Token Management Architecture

Agent mode now uses a layered context algorithm designed for long-running coding sessions.

## 1. Stable prefix

Static system instructions, project instructions and the original task remain at the front of the request. Changing runtime state is kept at the suffix so providers that support prompt caching can reuse the longest possible unchanged prefix.

## 2. Durable runtime state outside chat history

`AgentRunService` persists the objective, approved plan, active plan step, model/failover state, mutation revision, verification state and recently touched paths. Before each physical model call a single compact runtime-state suffix is regenerated from this durable state.

## 3. Local workspace retrieval index

`WorkspaceRetrievalIndexService` builds a bounded lexical index of source/config/instruction files. It uses the original objective plus the active plan step to rank likely-relevant files and injects a small hint set. It does not use embeddings and does not create another model call.

## 4. Deterministic pruning first

Old/oversized tool observations and superseded runtime steering are bounded before compaction. When the prompt approaches the adaptive high-water mark, pruning becomes more aggressive. Real user-authored messages are not removed by this stage.

## 5. Adaptive compaction threshold

The runtime first calculates the provider-safe input limit:

`inputLimit = contextWindow - max(outputAllowance, safetyBuffer)`

It then reserves dynamic input headroom for the next model/tool turn:

`headroom = clamp(contextWindow / 10, 8k, 24k)`

bounded to at most one quarter of the usable input limit.

Compaction begins when:

`estimatedInput > inputLimit - headroom`

This replaces the previous fixed 68% trigger.

Examples with the default 20k safety buffer and provider-managed output:

- 128k window -> input limit 108k -> adaptive threshold about 95.2k
- 200k window -> input limit 180k -> adaptive threshold about 160k

## 6. Rolling checkpoint + recent tail

Compaction replaces older chronology with a deterministic continuation checkpoint and keeps the recent tail (8k tokens by default). Periodically, or during forced overflow recovery, a small semantic summary call may improve that checkpoint. Compaction is never allowed to strand the run if the summarizer fails.

## 7. Telemetry

Agent progress now exposes provider tokens, current context, compaction count, pruned observation count, estimated active tokens saved, and provider cache-hit percentage when the provider reports cached input tokens.
