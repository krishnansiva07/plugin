# Advanced AI Workbench Agent

Java 17 local coding and workspace agent with two interaction modes: **Chat** and **Agent**.

## Primary flow

Agent mode is designed for direct prompt-driven work:

1. Put an existing project or file path in the prompt.
2. The runtime resolves that explicit path as the primary live workspace, even if a different workspace was previously active.
3. Before drafting a plan, the runtime performs a **read-only workspace analysis**: project profile, resolved resources, instructions, file index, key descriptors/build files, and focused searches derived from the task.
4. The model creates a **detailed draft plan from that evidence**, not by simply paraphrasing the prompt. The Agent console lets the user edit, reorder, add, remove, or unselect plan steps before execution.
5. By default execution waits for **Approve plan & run step 1**. Approval locks the edited plan. Exactly one plan step is active at a time: the agent performs real tool work for that step, verifies any code/config mutation, completes the step, and only then unlocks the next step. Routine implementation choices inside the active step remain autonomous.
6. The configured primary model handles the run first. Optional fallback models inherit the same workspace, approved plan, active step, and persisted run state when the current model is unavailable or exhausts its recovery budget.
7. The agent inspects targeted files, batches independent reads, edits the live workspace, executes the smallest useful build/test/check, repairs failures, and stops once the requested result is verified. Additional prompt paths are exposed as named resources with safe read/write roles.
8. A durable run record drives the progress bar and final completion state, so a stale SSE connection does not leave the UI waiting for a manual Stop click.

If a follow-up Agent prompt has no path, the current live workspace can be reused. If a new explicit path is supplied, that prompt path is authoritative and switches the active workspace.

## Long-running context management

The runtime uses a compact active context rather than resending the full historical transcript on every model call:

- proactive token estimation before each model call
- tool-schema tokens included in the estimate
- adaptive compaction based on usable input limit minus dynamic headroom; no fixed percentage trigger
- deterministic durable continuation checkpoints for most compactions
- periodic semantic checkpoint summarization (and forced-overflow summarization) instead of paying for a summary model call every time
- recent context tail retained after compaction
- only the two newest tool observations get the larger fresh-output allowance; older tool output is aggressively bounded
- superseded runtime recovery/verification/failover steering is removed instead of being resent for hundreds of turns
- Agent-mode conversation history is deliberately capped because the live workspace, approved plan, and run state are authoritative
- provider input/output/cache usage captured when returned
- context-overflow recovery with one forced compaction attempt
- configurable adaptive non-actionable recovery attempts **per model** (default 10)
- configurable transient provider retries **per model** (default 10) before moving to the next configured fallback
- immediate model failover for explicit unavailable/unknown/unsupported-model errors instead of wasting the retry budget
- model failover preserves the approved plan, current step, workspace revisions, and durable run state
- repeated identical no-progress tool/model outcomes suppressed and redirected to a materially different strategy

Defaults are configurable in Settings. The default recent-context target is 8k tokens, the safety buffer is 20k tokens, and older tool observations default to a 1,200-character active-context cap. A lightweight local lexical workspace index supplies relevant-file hints without an extra model/embedding call, while durable objective/plan/model/verification/touched-file state is stored outside the active transcript and re-injected as a small suffix.

## Speed and quality controls

The Agent protocol emphasizes high-signal work rather than activity for its own sake:

- independent read/search calls are batched in one model turn and executed in parallel when safe
- targeted grep/index/range reads are preferred over broad recursive file dumps
- unchanged files should not be re-read without a reason
- exploratory subagents can use fresh context for independent investigation
- edits are no-op aware, avoiding synthetic revisions when content already matches
- verification is revision-aware and only a real changed revision requires a new verifier
- the smallest verifier that proves the requested change is preferred before broader suites
- successful verification triggers a dedicated completion check instead of open-ended extra investigation
- transient provider retries are bounded and cancellable
- foreground commands use process pipes rather than temporary output files, avoiding Windows log-file sharing locks
- common provider tool-name/schema drift is repaired at the runtime boundary (`search`→`grep`, noisy `read/<channel>...` names, `query`→`pattern`, OpenAI-style patch text) instead of wasting retries
- stale exact-text edits explain that the file changed and direct the model to re-read current text before retrying

## Agent progress

The Agent console shows monotonic phase progress from startup through completion. Typical phases include planning, inspecting, editing, executing, verifying, reviewing, completion check, finalizing, completed, blocked, failed, or cancelled.

The percentage represents task phase progress, not an ETA. The terminal state becomes 100% only when the durable final response is available (or the run is terminally blocked/failed/cancelled).

## UI

The main UI intentionally contains only **Chat** and **Agent** modes. Workspace selection is not a sidebar workflow; supply filesystem paths in Agent prompts.

Settings include primary model selection, ordered fallback models, per-model recovery attempts, context/compaction controls, plan approval, permissions, MCP/subagent/LSP permissions, and optional additional shell commands. User-message editing now opens a substantially larger responsive editor for long prompts. In Agent mode the model strip shows the configured pool, active model, and fallback availability before execution.

## Build and run

Requirements:

- Java 17 or later
- Maven, or network access for the included Maven bootstrap script on first use

Windows:

```bat
validate-local.bat
run.bat
```

Linux/macOS:

```bash
./validate-local.sh
./run.sh
```

Normal `mvn install` / validation uses the release profile behavior and is **not blocked by optional environment-sensitive tests**. To run the complete test suite explicitly:

```bash
./mvnw -Pfull-tests test
```

On Windows use `mvnw.cmd -Pfull-tests test`.

The packaged JAR name is:

```text
target/advanced-ai-workbench.jar
```

## Example Agent prompts

```text
Project path: C:\work\payments-ui
Fix the failing login flow shown in the console error below. Inspect the project, implement the smallest correct fix, run the relevant tests, repair any failures, and stop as soon as the requested change is verified.
```

```text
Primary project: C:\work\new-playwright
Reference project: C:\work\old-selenium
Recorded flow: C:\work\recordings\payment.json
Use the Selenium project and recording as reference only. Implement the equivalent flow in the primary project, run it, fix failures, and verify the final result.
```

See `SAMPLE_PROMPTS.md` for more examples.
