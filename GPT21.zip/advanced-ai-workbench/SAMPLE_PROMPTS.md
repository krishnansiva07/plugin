# Sample prompts

## Chat

```text
Explain how this Java service handles authentication and list the main risks. Do not change files.
```

```text
Summarize the attached log and tell me the most likely root cause and next diagnostic step.
```

## Agent — fix and verify

```text
Project path: C:\work\application
The test command fails with the error pasted below. Inspect the relevant code, implement the smallest correct fix, run the targeted verifier, repair failures if necessary, and stop immediately when the requested change is verified.
```

## Agent — multiple paths

```text
Primary project: C:\work\playwright-framework
Reference project: C:\work\selenium-framework
Recorded JSON: C:\work\recordings\checkout.json
Use the Selenium project and JSON as reference inputs. Implement the equivalent checkout automation in the primary project, execute the relevant tests, fix failures, and verify the final flow. Do not modify the reference project or recording.
```

## Agent — add a feature

```text
Project: C:\work\service
Add request correlation IDs to inbound HTTP requests and logs. Follow the existing project conventions, add focused tests, run the relevant build/test checks, and finish once the requested behavior is verified.
```

## Agent — migrate while protecting the source

```text
Target: C:\work\new-framework
Source reference: C:\work\legacy-framework
Migrate the login and payment scenarios from the source reference into the target. Keep the source read-only, preserve business behavior and test data, run the target tests, fix failures, and verify the migration.
```
