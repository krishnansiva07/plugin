import { test, type Locator, type Page } from '@playwright/test';
import { envBoolean, envNumber } from '../../utils/Environment';
import { LlmClient } from '../../llm/LlmClient';

export interface SmartElement {
  description: string;
  primary: () => Locator;
  fallbacks?: Array<() => Locator>;
}

export interface FallbackContext {
  page: Page;
  description: string;
  originalError: Error;
}

export type CustomFallback = (context: FallbackContext) => Promise<void>;

export interface ActionOptions {
  fallback?: CustomFallback | CustomFallback[];
  validate?: (page: Page) => Promise<void>;
  allowLlmHealing?: boolean;
  allowForce?: boolean;
}

export class SmartActions {
  private readonly llm = new LlmClient();
  private readonly minimumConfidence = envNumber('LLM_MIN_CONFIDENCE', 0.90);
  private readonly forceGloballyAllowed = envBoolean('ALLOW_FORCE_ACTIONS', false);

  constructor(private readonly page: Page) {}

  async fill(element: SmartElement, value: string, options: ActionOptions = {}): Promise<boolean> {
    return this.execute(element, 'fill', async locator => locator.fill(value), options);
  }

  async click(element: SmartElement, options: ActionOptions = {}): Promise<boolean> {
    return this.execute(element, 'click', async locator => locator.click(), options);
  }

  async hover(element: SmartElement, options: ActionOptions = {}): Promise<boolean> {
    return this.execute(element, 'hover', async locator => locator.hover(), options);
  }

  private async execute(
    element: SmartElement,
    action: string,
    operation: (locator: Locator) => Promise<void>,
    options: ActionOptions
  ): Promise<boolean> {
    const errors: Error[] = [];
    const candidates = [element.primary, ...(element.fallbacks ?? [])];

    for (let index = 0; index < candidates.length; index += 1) {
      try {
        const locator = candidates[index]();
        if (!await this.isUsable(locator)) continue;
        await operation(locator);
        await options.validate?.(this.page);
        if (index > 0) this.annotate('deterministic-healing', `${element.description} fallback ${index}`);
        return index > 0;
      } catch (error) {
        errors.push(this.toError(error));
      }
    }

    const customFallbacks = options.fallback
      ? (Array.isArray(options.fallback) ? options.fallback : [options.fallback])
      : [];
    for (let index = 0; index < customFallbacks.length; index += 1) {
      try {
        await customFallbacks[index]({
          page: this.page,
          description: element.description,
          originalError: errors.at(-1) ?? new Error(`Unable to execute ${element.description}`)
        });
        await options.validate?.(this.page);
        this.annotate('custom-fallback', `${element.description} custom fallback ${index + 1}`);
        return true;
      } catch (error) {
        errors.push(this.toError(error));
      }
    }

    if (options.allowLlmHealing !== false && this.llm.enabled) {
      try {
        const maxLength = envNumber('LLM_DOM_MAX_LENGTH', 20000);
        const suggestion = await this.llm.suggestLocator({
          elementDescription: element.description,
          failedLocator: element.primary().toString(),
          action,
          error: errors.map(item => item.message).join(' | ') || `No unique visible locator found`,
          pageTitle: await this.page.title(),
          pageUrl: this.page.url(),
          relevantDom: (await this.page.locator('body').innerHTML()).slice(0, maxLength)
        });
        if (suggestion && suggestion.confidence >= this.minimumConfidence) {
          const healed = this.page.locator(suggestion.selector);
          if (!await this.isUsable(healed)) throw new Error(`LLM selector was not unique and visible: ${suggestion.selector}`);
          await operation(healed);
          await options.validate?.(this.page);
          console.log(`[LLM HEALING] SUCCESS selector=${suggestion.selector} confidence=${suggestion.confidence} reason=${suggestion.reason}`);
          this.annotate('llm-healing', `${element.description} -> ${suggestion.selector}`);
          return true;
        }
      } catch (error) {
        errors.push(this.toError(error));
      }
    }

    if (options.allowForce) {
      if (!this.forceGloballyAllowed) {
        errors.push(new Error('Force action requested but ALLOW_FORCE_ACTIONS=false'));
      } else {
        try {
          const forceCandidate = candidates[0]();
          if (action === 'click') await forceCandidate.click({ force: true });
          else throw new Error(`Force mode is supported only for click, not ${action}`);
          await options.validate?.(this.page);
          this.annotate('force-action', element.description);
          return true;
        } catch (error) {
          errors.push(this.toError(error));
        }
      }
    }

    throw new AggregateError(errors, `All strategies failed for ${element.description}`);
  }

  private async isUsable(locator: Locator): Promise<boolean> {
    try { return (await locator.count()) === 1 && await locator.isVisible(); }
    catch { return false; }
  }

  private annotate(type: string, description: string): void {
    console.log(`[${type.toUpperCase()}] ${description}`);
    try { test.info().annotations.push({ type, description }); } catch {}
  }

  private toError(error: unknown): Error {
    return error instanceof Error ? error : new Error(String(error));
  }
}
