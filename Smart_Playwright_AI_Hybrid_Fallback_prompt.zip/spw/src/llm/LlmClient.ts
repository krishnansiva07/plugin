import { ChatOpenAI } from '@langchain/openai';
import { HumanMessage, SystemMessage } from '@langchain/core/messages';
import { env, envBoolean, envNumber } from '../utils/Environment';

export type PromptAction =
  | 'navigate' | 'click' | 'fill' | 'select' | 'hover'
  | 'press' | 'verifyText' | 'verifyEquals';

export interface PromptPlan {
  action: PromptAction;
  target?: string;
  value?: string;
  url?: string;
  key?: string;
  confidence: number;
  reason: string;
}

export interface PromptRequest {
  instruction: string;
  pageTitle: string;
  pageUrl: string;
  pageContext: string;
}

export interface HealingRequest {
  elementDescription: string;
  failedLocator: string;
  action: string;
  error: string;
  pageTitle: string;
  pageUrl: string;
  relevantDom: string;
}
export interface HealingSuggestion { selector: string; confidence: number; reason: string; }

export class LlmClient {
  readonly enabled = envBoolean('LLM_ENABLED', false);
  private readonly model: ChatOpenAI | null;

  constructor() {
    if (!this.enabled) { this.model = null; return; }
    const apiKey = this.requireValue('LLM_API_KEY');
    const baseURL = this.requireValue('LLM_BASE_URL').replace(/\/+$/, '');
    const modelName = this.requireValue('LLM_MODEL_NAME');
    this.model = new ChatOpenAI({
      apiKey,
      model: modelName,
      temperature: envNumber('LLM_TEMPERATURE', 0),
      maxTokens: envNumber('LLM_MAX_TOKENS', 700),
      timeout: envNumber('LLM_TIMEOUT_MS', 30000),
      maxRetries: envNumber('LLM_MAX_RETRIES', 1),
      configuration: { baseURL }
    });
  }

  async interpretPrompt(request: PromptRequest): Promise<PromptPlan> {
    this.ensureEnabled('AI prompt execution');
    const system = `You translate a natural-language browser-testing instruction into one safe structured action.
Return strict JSON only with this schema:
{"action":"navigate|click|fill|select|hover|press|verifyText|verifyEquals","target":"optional","value":"optional","url":"optional","key":"optional","confidence":0.0,"reason":"short reason"}
Rules:
- Do not return JavaScript, selectors, XPath, CSS, markdown, or multiple actions.
- Use navigate for opening a URL/application. Use click for buttons, links, menus and items.
- Use fill for entering text. Use select for choosing a value from a field/dropdown.
- Use verifyText for visibility/text checks and verifyEquals for field/status equality.
- Preserve exact business values and labels from the instruction.
- If the instruction is ambiguous, return a low confidence score.`;
    const raw = await this.invokeJson(system, request, 'AI PROMPT');
    const parsed = JSON.parse(raw) as Partial<PromptPlan>;
    const allowed: PromptAction[] = ['navigate', 'click', 'fill', 'select', 'hover', 'press', 'verifyText', 'verifyEquals'];
    if (!parsed.action || !allowed.includes(parsed.action) || typeof parsed.confidence !== 'number' || !parsed.reason) {
      throw new Error(`Unexpected AI prompt response: ${raw}`);
    }
    return {
      action: parsed.action,
      target: parsed.target?.trim(),
      value: parsed.value?.trim(),
      url: parsed.url?.trim(),
      key: parsed.key?.trim(),
      confidence: parsed.confidence,
      reason: parsed.reason.trim()
    };
  }

  async suggestLocator(request: HealingRequest): Promise<HealingSuggestion | null> {
    if (!this.enabled || !this.model) return null;
    const system = `You are a Playwright locator-healing engine. Return strict JSON only: {"selector":"...","confidence":0.0,"reason":"..."}. Return one safe CSS selector. Prefer id, name, data-test, data-testid, aria-label or stable attributes. Never return XPath, JavaScript, markdown, or explanation outside JSON.`;
    const raw = await this.invokeJson(system, request, 'LLM HEALING');
    const parsed = JSON.parse(raw) as Partial<HealingSuggestion>;
    if (!parsed.selector || typeof parsed.confidence !== 'number' || !parsed.reason) {
      throw new Error(`Unexpected LLM healing response: ${raw}`);
    }
    if (parsed.confidence < 0 || parsed.confidence > 1) throw new Error(`Invalid confidence: ${parsed.confidence}`);
    return { selector: parsed.selector.trim(), confidence: parsed.confidence, reason: parsed.reason.trim() };
  }

  private async invokeJson(system: string, payload: unknown, label: string): Promise<string> {
    this.ensureEnabled(label);
    console.log(`[${label}] Calling LangChain`);
    try {
      const response = await this.model!.invoke([
        new SystemMessage(system),
        new HumanMessage(JSON.stringify(payload))
      ]);
      return this.text(response.content)
        .replace(/^```json\s*/i, '')
        .replace(/^```\s*/i, '')
        .replace(/\s*```$/i, '')
        .trim();
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error);
      throw new Error(`${label} request failed: ${message}`, { cause: error });
    }
  }

  private ensureEnabled(feature: string): void {
    if (!this.enabled || !this.model) {
      throw new Error(`${feature} requires LLM_ENABLED=true and valid LLM_API_KEY, LLM_BASE_URL and LLM_MODEL_NAME.`);
    }
  }

  private text(content: unknown): string {
    if (typeof content === 'string') return content;
    if (Array.isArray(content)) return content.map(item => typeof item === 'object' && item && 'text' in item ? String(item.text) : '').join('');
    return '';
  }
  private requireValue(name: string): string {
    const value = env(name);
    if (!value) throw new Error(`${name} must be supplied and non-blank`);
    return value;
  }
}
