import { expect, type Locator, type Page } from '@playwright/test';
import { SmartActions, type ActionOptions, type SmartElement } from '../core/actions/SmartActions';
import { LlmClient, type PromptPlan } from '../llm/LlmClient';
import { envNumber } from '../utils/Environment';

export type NativeStep = (page: Page) => Promise<void>;

export class AI {
  private readonly actions: SmartActions;
  private readonly llm = new LlmClient();
  private readonly promptMinimumConfidence = envNumber('LLM_PROMPT_MIN_CONFIDENCE', 0.80);

  private constructor(private readonly page: Page) {
    this.actions = new SmartActions(page);
  }

  static on(page: Page): AI { return new AI(page); }

  /** Always sends the instruction to the configured LLM. */
  async prompt(instruction: string, options: ActionOptions = {}): Promise<AI> {
    const maxLength = envNumber('LLM_DOM_MAX_LENGTH', 20000);
    const plan = await this.llm.interpretPrompt({
      instruction: instruction.trim(),
      pageTitle: await this.page.title().catch(() => ''),
      pageUrl: this.page.url(),
      pageContext: (await this.page.locator('body').innerHTML().catch(() => '')).slice(0, maxLength)
    });
    if (plan.confidence < this.promptMinimumConfidence) {
      throw new Error(`LLM prompt confidence ${plan.confidence} is below LLM_PROMPT_MIN_CONFIDENCE=${this.promptMinimumConfidence}. Reason: ${plan.reason}`);
    }
    console.log(`[AI PROMPT] action=${plan.action} target=${plan.target ?? ''} value=${plan.value ?? ''} confidence=${plan.confidence}`);
    await this.executePlan(plan, options);
    return this;
  }

  /** Backward-compatible alias. In AI mode this is an LLM prompt, not a hardcoded parser. */
  async step(instruction: string, options: ActionOptions = {}): Promise<AI> {
    return this.prompt(instruction, options);
  }

  async run(instructions: string[], options: ActionOptions = {}): Promise<AI> {
    for (const instruction of instructions) await this.prompt(instruction, options);
    return this;
  }

  async hybrid(steps: Array<string | NativeStep>): Promise<AI> {
    for (const step of steps) {
      if (typeof step === 'string') await this.prompt(step);
      else await this.native('Hybrid native Playwright step', step);
    }
    return this;
  }

  async native(name: string, operation: NativeStep): Promise<AI> {
    console.log(`[NATIVE PLAYWRIGHT] ${name}`);
    await operation(this.page);
    return this;
  }

  async click(target: string, options: ActionOptions = {}): Promise<AI> {
    await this.actions.click(this.element(target, 'click'), options);
    return this;
  }

  async fill(target: string, value: string, options: ActionOptions = {}): Promise<AI> {
    await this.actions.fill(this.element(target, 'fill'), value, options);
    return this;
  }

  async hover(target: string, options: ActionOptions = {}): Promise<AI> {
    await this.actions.hover(this.element(target, 'click'), options);
    return this;
  }

  async select(target: string, value: string, options: ActionOptions = {}): Promise<AI> {
    const field = this.semantic(target);
    try {
      if (await this.isNativeSelect(field)) {
        await field.selectOption({ label: value }).catch(async () => field.selectOption(value));
        await options.validate?.(this.page);
        return this;
      }
      await this.actions.click(this.element(target, 'click'), options);
      await this.actions.click(this.element(value, 'click', 'option'), options);
      return this;
    } catch (error) {
      const fallbacks = options.fallback ? (Array.isArray(options.fallback) ? options.fallback : [options.fallback]) : [];
      for (const fallback of fallbacks) {
        try {
          await fallback({ page: this.page, description: `select '${value}' from '${target}'`, originalError: error instanceof Error ? error : new Error(String(error)) });
          await options.validate?.(this.page);
          return this;
        } catch { /* continue */ }
      }
      throw error;
    }
  }

  async verifyText(text: string): Promise<AI> {
    await expect(this.page.getByText(text, { exact: false }).first()).toBeVisible();
    return this;
  }

  async verifyEquals(target: string, expected: string): Promise<AI> {
    const locator = this.semantic(target).first();
    await expect(locator).toContainText(expected, { ignoreCase: true });
    return this;
  }

  private async executePlan(plan: PromptPlan, options: ActionOptions): Promise<void> {
    switch (plan.action) {
      case 'navigate':
        await this.page.goto(plan.url || plan.target || '/');
        break;
      case 'click':
        this.require(plan.target, 'target', plan.action);
        await this.click(plan.target!, options);
        break;
      case 'fill':
        this.require(plan.target, 'target', plan.action);
        this.require(plan.value, 'value', plan.action);
        await this.fill(plan.target!, plan.value!, options);
        break;
      case 'select':
        this.require(plan.target, 'target', plan.action);
        this.require(plan.value, 'value', plan.action);
        await this.select(plan.target!, plan.value!, options);
        break;
      case 'hover':
        this.require(plan.target, 'target', plan.action);
        await this.hover(plan.target!, options);
        break;
      case 'press':
        await this.page.keyboard.press(plan.key || plan.value || 'Enter');
        break;
      case 'verifyText':
        await this.verifyText(plan.value || plan.target || '');
        break;
      case 'verifyEquals':
        this.require(plan.target, 'target', plan.action);
        this.require(plan.value, 'value', plan.action);
        await this.verifyEquals(plan.target!, plan.value!);
        break;
      default:
        throw new Error(`Unsupported LLM action: ${String(plan.action)}`);
    }
  }

  private element(target: string, action: 'click' | 'fill', preferredRole?: 'option'): SmartElement {
    const exact = target.trim();
    return {
      description: `${action} target '${exact}'`,
      primary: () => preferredRole
        ? this.page.getByRole(preferredRole, { name: exact, exact: true })
        : this.page.getByTestId(this.toTestId(exact)),
      fallbacks: [
        () => this.page.getByRole(action === 'fill' ? 'textbox' : 'button', { name: exact, exact: true }),
        () => this.page.getByRole('link', { name: exact, exact: true }),
        () => this.page.getByLabel(exact, { exact: true }),
        () => this.page.getByPlaceholder(exact, { exact: false }),
        () => this.page.getByText(exact, { exact: true }),
        () => this.page.locator(`[name="${this.cssEscape(exact)}"]`),
        () => this.page.locator(`[aria-label="${this.cssEscape(exact)}"]`)
      ]
    };
  }

  private semantic(target: string): Locator {
    return this.page.getByLabel(target, { exact: true })
      .or(this.page.getByRole('textbox', { name: target, exact: true }))
      .or(this.page.getByText(target, { exact: true }));
  }

  private async isNativeSelect(locator: Locator): Promise<boolean> {
    try { return await locator.first().evaluate(el => el.tagName.toLowerCase() === 'select'); }
    catch { return false; }
  }

  private toTestId(target: string): string {
    return target.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
  }

  private cssEscape(value: string): string { return value.replace(/["\\]/g, '\\$&'); }

  private require(value: string | undefined, field: string, action: string): void {
    if (!value) throw new Error(`LLM action '${action}' did not provide required ${field}`);
  }
}
