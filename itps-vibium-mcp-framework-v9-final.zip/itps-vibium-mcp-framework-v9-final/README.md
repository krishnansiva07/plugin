# ITPS VIBIUM Framework V9

Java Spring Boot test runner using Vibium MCP for browser execution.

## Run

```cmd
set VIBIUM_SKIP_BROWSER_DOWNLOAD=1
mvn clean spring-boot:run
```

Open `http://localhost:8090`.

## Vibium MCP configuration

Configure the portable Vibium command in `src/main/resources/application.properties`:

```properties
itps.vibium.mcp.command=C:\tools\vibium-portable\node_modules\.bin\vibium.cmd
itps.vibium.mcp.args=mcp
```

## V9 unified page model

V9 separates page understanding into two inventories instead of treating only clickable controls as page elements.

### Action inventory

Used for click, fill, type, select, check, hover and keyboard actions. It includes semantic controls, custom clickable containers, icons/SVG controls, role/tabindex/onclick controls, open shadow DOM and same-origin iframe controls.

### Validation inventory

Used for visible-text and UI-data validation. It includes headings, labels, spans, cards, status badges, paragraphs, table headers/cells, list items, read-only values, selected options, input values and other visible DOM text—even when the element is not interactive.

The unified page model stores:

- `actionElements`
- `contentElements`
- `formValues`
- `tables`
- `allVisibleText`
- element context, coordinates and generated CSS selectors

Natural-language action steps are planned using the action inventory. Validation steps such as `Verify LMIS status is Integrated` are evaluated directly against the validation inventory and do not depend on the LLM choosing a clickable element.

## Supported validation patterns

Examples:

```text
Verify Banking entity details is displayed
Verify banking entity code is AAAAFRAB
Verify BIC8 identifier is BK26020000009711
Verify LMIS status is Integrated
Verify Host identifier is FRH026020012385
Verify Branch Code identifier is BR26020000007361
Verify authorization status is Not authorized
Verify CAM tab is visible
```

Label/value assertions use element text, accessible names, parent context, nearby visible elements and form values.

## Diagnostics and reports

Each run writes:

```text
target/itps-vibium-runs/<run-id>/
```

- `report.html` — consolidated test results
- `logs.html` — searchable technical execution logs
- `report.xlsx`
- `report.json`
- `screenshots.zip`
- `elements/` — complete unified page model by test and step
- `mcp-transcript.json`
- `mcp-process.log`

## Browser limitations

Closed shadow roots, cross-origin iframe documents and canvas-only content cannot be fully inspected using normal DOM evaluation. V9 records the available frame/context evidence instead of silently choosing an unrelated element.


## V9 final enhancements
- 100% Vibium MCP browser execution; no Selenium or Playwright fallback.
- Full unified DOM/page model for actions and validations.
- LLM deep DOM self-healing after action or validation failure.
- User-configurable failure healing attempts (0-2 in UI).
- Confidence-gated healing to prevent unsafe guesses.
- PASS_HEALED status and complete healing evidence in HTML, JSON and Excel reports.
- Fresh DOM, screenshot, candidate ranking and failure context captured before every healing attempt.
