# Step 2 – Advanced AI Healing

## Added capabilities

- Multi-action workflow planning through `ai.workflow()`.
- Automatic workflow fallback when `ai.prompt()` returns confidence below `LLM_PROMPT_MIN_CONFIDENCE`.
- Conservative verification healing for `verifyText()` and `verifyEquals()`.
- DOM and accessibility context collection for every LLM recovery.
- Screenshot evidence captured on locator, workflow, and verification healing.
- Persistent healing cache stored under `test-results/healing-cache.json`.
- Cache validation before reuse; invalid cache entries are penalized and bypassed.
- JSONL healing audit under `test-results/healing-audit/healing-audit.jsonl`.
- Healing details attached to Playwright results and displayed by the custom HTML reporter.

## Execution order

```text
Normal Playwright action
→ deterministic locator fallbacks
→ user TypeScript fallbacks
→ validated healing-cache locator
→ LLM locator healing
→ optional force action
→ fail safely
```

For a complex prompt:

```text
ai.prompt()
→ single-action LLM interpretation
→ low confidence
→ workflow LLM planning
→ execute each validated action through the normal action/healing pipeline
```

## New examples

```bash
npm test -- --testid=TC_WORKFLOW_001
npm test -- --testid=TC_VERIFY_HEAL_001
npm test -- --testid=TC_CACHE_001
```

LLM examples require `LLM_ENABLED=true` and valid endpoint configuration.
