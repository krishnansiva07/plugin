import { ChatOpenAI } from '@langchain/openai';
import { HumanMessage, SystemMessage } from '@langchain/core/messages';
import { envBoolean, envNumber } from '../utils/Environment';

export type PromptAction =
  | 'navigate' | 'click' | 'fill' | 'select' | 'hover'
  | 'press' | 'verifyText' | 'verifyEquals';

export interface PromptPlan {
  action: PromptAction;
  target?: string;
  value?: string;
  url?: string;
  key?: string;
  confidence: number;
  reason: string;
}

export interface PromptRequest {
  instruction: string;
  pageTitle: string;
  pageUrl: string;
  pageContext: string;
}

export interface WorkflowRequest {
  instruction: string;
  maxSteps: number;
  pageTitle: string;
  pageUrl: string;
  accessibilityContext: string;
  relevantDom: string;
  screenshotPath?: string;
}

export interface WorkflowPlan {
  steps: PromptPlan[];
  confidence: number;
  reason: string;
}

export interface VerificationRequest {
  instruction: string;
  verificationType: 'text' | 'equals';
  target?: string;
  expected: string;
  originalError: string;
  pageTitle: string;
  pageUrl: string;
  accessibilityContext: string;
  relevantDom: string;
  screenshotPath?: string;
}

export interface VerificationSuggestion {
  strategy: 'equivalentText' | 'targetText';
  actualText?: string;
  target?: string;
  confidence: number;
  reason: string;
}

export type LocatorStrategy =
  | 'testId' | 'role' | 'label' | 'placeholder' | 'text'
  | 'css' | 'name' | 'ariaLabel';

export interface HealingRequest {
  instruction: string;
  action: string;
  target: string;
  value?: string;
  failedStrategies: string[];
  errors: string[];
  pageTitle: string;
  pageUrl: string;
  accessibilityContext: string;
  relevantDom: string;
}

export interface HealingSuggestion {
  strategy: LocatorStrategy;
  selector?: string;
  role?: string;
  name?: string;
  value?: string;
  exact?: boolean;
  confidence: number;
  reason: string;
}

export class LlmClient {
  readonly enabled = envBoolean('LLM_ENABLED', false);
  private readonly model: ChatOpenAI | null;

  constructor() {
    if (!this.enabled) {
      this.model = null;
      return;
    }

    this.model = new ChatOpenAI({
      apiKey: this.requireValue('LLM_API_KEY'),
      model: this.requireValue('LLM_MODEL_NAME'),
      temperature: envNumber('LLM_TEMPERATURE', 0),
      maxTokens: envNumber('LLM_MAX_TOKENS', 700),
      timeout: envNumber('LLM_TIMEOUT_MS', 30000),
      maxRetries: envNumber('LLM_MAX_RETRIES', 1),
      configuration: {
        baseURL: this.requireValue('LLM_BASE_URL').replace(/\/+$/, '')
      }
    });
  }

  async interpretPrompt(request: PromptRequest): Promise<PromptPlan> {
    this.ensureEnabled('AI prompt execution');

    const system = `You translate exactly one natural-language browser-test instruction into one safe structured action.
Return strict JSON only:
{"action":"navigate|click|fill|select|hover|press|verifyText|verifyEquals","target":"optional","value":"optional","url":"optional","key":"optional","confidence":0.0,"reason":"short reason"}
Rules:
- Never return JavaScript, TypeScript, XPath, CSS, markdown, or multiple actions.
- Preserve exact labels and business values from the instruction.
- navigate opens the application or a URL.
- click activates a button, link, menu, tab, option, row, or item.
- fill enters text into a field.
- select chooses a value from a dropdown or combobox.
- verifyText checks visible text; verifyEquals compares a field/status with a value.
- If the instruction contains multiple dependent actions, return low confidence instead of inventing a single action.`;

    const parsed = await this.invokeObject<Partial<PromptPlan>>(system, request, 'AI PROMPT');
    const allowed: PromptAction[] = ['navigate', 'click', 'fill', 'select', 'hover', 'press', 'verifyText', 'verifyEquals'];

    if (!parsed.action || !allowed.includes(parsed.action) || typeof parsed.confidence !== 'number' || !parsed.reason) {
      throw new Error(`Unexpected AI prompt response: ${JSON.stringify(parsed)}`);
    }
    this.validateConfidence(parsed.confidence);

    return {
      action: parsed.action,
      target: parsed.target?.trim(),
      value: parsed.value?.trim(),
      url: parsed.url?.trim(),
      key: parsed.key?.trim(),
      confidence: parsed.confidence,
      reason: parsed.reason.trim()
    };
  }


  async interpretWorkflow(request: WorkflowRequest): Promise<WorkflowPlan> {
    this.ensureEnabled('AI workflow planning');
    const system = `You convert one business-level browser instruction into a short, safe sequence of browser actions.
Return strict JSON only:
{"steps":[{"action":"navigate|click|fill|select|hover|press|verifyText|verifyEquals","target":"optional","value":"optional","url":"optional","key":"optional","confidence":0.0,"reason":"short reason"}],"confidence":0.0,"reason":"short overall reason"}
Rules:
- Return between 1 and maxSteps actions.
- Preserve exact labels and values.
- Do not return JavaScript, TypeScript, XPath, CSS, markdown, loops, conditions, or unsupported actions.
- Each step must be independently executable and ordered.
- Use low confidence when the page context does not support a safe plan.`;
    const parsed = await this.invokeObject<Partial<WorkflowPlan>>(system, request, 'LLM WORKFLOW');
    if (!Array.isArray(parsed.steps) || parsed.steps.length < 1 || parsed.steps.length > request.maxSteps || typeof parsed.confidence !== 'number' || !parsed.reason) {
      throw new Error(`Unexpected workflow response: ${JSON.stringify(parsed)}`);
    }
    const allowed: PromptAction[] = ['navigate', 'click', 'fill', 'select', 'hover', 'press', 'verifyText', 'verifyEquals'];
    for (const step of parsed.steps) {
      if (!step.action || !allowed.includes(step.action) || typeof step.confidence !== 'number' || !step.reason) {
        throw new Error(`Invalid workflow step: ${JSON.stringify(step)}`);
      }
      this.validateConfidence(step.confidence);
    }
    this.validateConfidence(parsed.confidence);
    return { steps: parsed.steps as PromptPlan[], confidence: parsed.confidence, reason: parsed.reason.trim() };
  }

  async suggestVerification(request: VerificationRequest): Promise<VerificationSuggestion> {
    this.ensureEnabled('verification healing');
    const system = `You are a conservative UI verification-healing engine.
Return strict JSON only:
{"strategy":"equivalentText|targetText","actualText":"visible text that exists in context","target":"optional field or status label","confidence":0.0,"reason":"short reason"}
Rules:
- Never claim semantic equivalence unless the visible text clearly expresses the same business outcome.
- Do not convert failure, warning, pending, or partial states into success.
- actualText must appear verbatim in the supplied page context.
- Prefer low confidence and fail when uncertain.
- Return no JavaScript, selector, XPath, CSS, or markdown.`;
    const parsed = await this.invokeObject<Partial<VerificationSuggestion>>(system, request, 'LLM VERIFICATION');
    if (!parsed.strategy || !['equivalentText', 'targetText'].includes(parsed.strategy) || typeof parsed.confidence !== 'number' || !parsed.reason) {
      throw new Error(`Unexpected verification healing response: ${JSON.stringify(parsed)}`);
    }
    this.validateConfidence(parsed.confidence);
    return { strategy: parsed.strategy as VerificationSuggestion['strategy'], actualText: parsed.actualText?.trim(), target: parsed.target?.trim(), confidence: parsed.confidence, reason: parsed.reason.trim() };
  }

  async suggestLocator(request: HealingRequest): Promise<HealingSuggestion | null> {
    if (!this.enabled || !this.model) return null;

    const system = `You are a safe Playwright locator-healing engine.
Return strict JSON only:
{"strategy":"testId|role|label|placeholder|text|css|name|ariaLabel","selector":"optional","role":"optional","name":"optional","value":"optional","exact":true,"confidence":0.0,"reason":"short reason"}
Rules:
- Return one locator recommendation only.
- Prefer testId, role+accessible name, label, placeholder, exact text, name, ariaLabel, then stable CSS.
- Do not return XPath, JavaScript, TypeScript, markdown, positional selectors, nth(), or broad selectors.
- The recommendation must match the requested target, not a visually nearby or similar element.
- Use exact=true whenever the requested target is an exact business label.
- If no safe unique locator is supported by the context, return low confidence.`;

    const parsed = await this.invokeObject<Partial<HealingSuggestion>>(system, request, 'LLM HEALING');
    const allowed: LocatorStrategy[] = ['testId', 'role', 'label', 'placeholder', 'text', 'css', 'name', 'ariaLabel'];

    if (!parsed.strategy || !allowed.includes(parsed.strategy) || typeof parsed.confidence !== 'number' || !parsed.reason) {
      throw new Error(`Unexpected LLM healing response: ${JSON.stringify(parsed)}`);
    }
    this.validateConfidence(parsed.confidence);

    return {
      strategy: parsed.strategy,
      selector: parsed.selector?.trim(),
      role: parsed.role?.trim(),
      name: parsed.name?.trim(),
      value: parsed.value?.trim(),
      exact: parsed.exact ?? true,
      confidence: parsed.confidence,
      reason: parsed.reason.trim()
    };
  }

  private async invokeObject<T>(system: string, payload: unknown, label: string): Promise<T> {
    this.ensureEnabled(label);
    console.log(`[${label}] Calling configured LangChain model`);

    const response = await this.model!.invoke([
      new SystemMessage(system),
      new HumanMessage(JSON.stringify(payload))
    ]);

    const text = typeof response.content === 'string'
      ? response.content
      : response.content.map(part => typeof part === 'string' ? part : JSON.stringify(part)).join('');

    const cleaned = text.trim().replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/, '');
    try {
      return JSON.parse(cleaned) as T;
    } catch (error) {
      throw new Error(`${label} returned invalid JSON: ${cleaned}`, { cause: error });
    }
  }

  private ensureEnabled(feature: string): void {
    if (!this.enabled || !this.model) {
      throw new Error(`${feature} requires LLM_ENABLED=true and valid LLM_API_KEY, LLM_BASE_URL and LLM_MODEL_NAME.`);
    }
  }

  private requireValue(name: string): string {
    const value = process.env[name]?.trim();
    if (!value) throw new Error(`${name} is required when LLM_ENABLED=true`);
    return value;
  }

  private validateConfidence(confidence: number): void {
    if (confidence < 0 || confidence > 1) throw new Error(`Invalid confidence: ${confidence}`);
  }
}
