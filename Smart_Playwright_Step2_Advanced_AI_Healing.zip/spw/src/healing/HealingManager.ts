import type { Page } from '@playwright/test';
import { LocatorHealingService } from './LocatorHealingService';
import { WorkflowHealingService } from './WorkflowHealingService';
import { VerificationHealingService } from './VerificationHealingService';

export class HealingManager {
  readonly locator: LocatorHealingService;
  readonly workflow: WorkflowHealingService;
  readonly verification: VerificationHealingService;

  constructor(page: Page) {
    this.locator = new LocatorHealingService(page);
    this.workflow = new WorkflowHealingService(page);
    this.verification = new VerificationHealingService(page);
  }
}
