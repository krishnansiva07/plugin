import fs from 'node:fs';
import path from 'node:path';
import { test } from '@playwright/test';
import type { HealingAuditEntry } from './HealingTypes';

export class HealingAuditLogger {
  private readonly root = path.resolve(process.env.HEALING_AUDIT_DIR || 'test-results/healing-audit');

  async record(entry: HealingAuditEntry): Promise<void> {
    fs.mkdirSync(this.root, { recursive: true });
    const line = `${JSON.stringify(entry)}\n`;
    fs.appendFileSync(path.join(this.root, 'healing-audit.jsonl'), line, 'utf8');
    console.log(`[HEALING AUDIT] ${entry.kind} ${entry.status} ${entry.instruction}`);
    try {
      test.info().annotations.push({
        type: entry.status === 'passed' || entry.status === 'cache-hit' ? 'healed' : `healing-${entry.status}`,
        description: `${entry.kind}: ${entry.strategy ?? ''} ${entry.reason ?? ''}`.trim()
      });
      await test.info().attach(`healing-${entry.kind}-${Date.now()}.json`, {
        body: Buffer.from(JSON.stringify(entry, null, 2)),
        contentType: 'application/json'
      });
    } catch {
      // Outside Playwright test context.
    }
  }
}
