import { expect, type Locator, type Page } from '@playwright/test';
import { envBoolean, envNumber } from '../utils/Environment';
import { LlmClient } from '../llm/LlmClient';
import { PageContextBuilder } from '../core/context/PageContextBuilder';
import { HealingAuditLogger } from './HealingAuditLogger';
import { ScreenshotHealingService } from './ScreenshotHealingService';

export class VerificationHealingService {
  readonly enabled = envBoolean('VERIFICATION_HEALING_ENABLED', true);
  private readonly minimum = envNumber('VERIFICATION_HEALING_MIN_CONFIDENCE', 0.92);
  private readonly llm = new LlmClient();
  private readonly context: PageContextBuilder;
  private readonly audit = new HealingAuditLogger();
  private readonly screenshot: ScreenshotHealingService;

  constructor(private readonly page: Page) {
    this.context = new PageContextBuilder(page);
    this.screenshot = new ScreenshotHealingService(page);
  }

  async verifyText(expected: string, originalError: Error): Promise<void> {
    await this.heal({ kind: 'text', expected, originalError });
  }

  async verifyEquals(target: string, expected: string, originalError: Error): Promise<void> {
    await this.heal({ kind: 'equals', target, expected, originalError });
  }

  private async heal(input: { kind: 'text' | 'equals'; target?: string; expected: string; originalError: Error }): Promise<void> {
    if (!this.enabled || !this.llm.enabled) throw input.originalError;
    const instruction = input.kind === 'text'
      ? `Verify visible text '${input.expected}'`
      : `Verify '${input.target}' equals '${input.expected}'`;
    const evidence = await this.screenshot.capture('verification-healing');
    const context = await this.context.build();
    const suggestion = await this.llm.suggestVerification({
      instruction,
      verificationType: input.kind,
      target: input.target,
      expected: input.expected,
      originalError: input.originalError.message,
      screenshotPath: evidence.path,
      ...context
    });
    if (suggestion.confidence < this.minimum) {
      throw new Error(`Verification healing confidence ${suggestion.confidence} is below ${this.minimum}`, { cause: input.originalError });
    }
    const locator = this.toLocator(suggestion.strategy, suggestion.actualText, suggestion.target);
    if (suggestion.strategy === 'equivalentText') {
      await expect(locator).toBeVisible();
    } else {
      await expect(locator).toContainText(suggestion.actualText || input.expected, { ignoreCase: true });
    }
    await this.audit.record({
      timestamp: new Date().toISOString(), kind: 'verification', instruction, status: 'passed',
      confidence: suggestion.confidence, strategy: suggestion.strategy, reason: suggestion.reason,
      details: { expected: input.expected, actualText: suggestion.actualText, target: suggestion.target }
    });
  }

  private toLocator(strategy: string, actualText?: string, target?: string): Locator {
    switch (strategy) {
      case 'equivalentText': return this.page.getByText(actualText || '', { exact: false }).first();
      case 'targetText': return this.page.getByLabel(target || '', { exact: false }).or(this.page.getByText(target || '', { exact: false })).first();
      default: throw new Error(`Unsupported verification healing strategy: ${strategy}`);
    }
  }
}
