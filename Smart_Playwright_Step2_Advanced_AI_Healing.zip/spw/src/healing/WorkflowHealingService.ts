import type { Page } from '@playwright/test';
import { envBoolean, envNumber } from '../utils/Environment';
import { LlmClient, type PromptPlan } from '../llm/LlmClient';
import { PageContextBuilder } from '../core/context/PageContextBuilder';
import { HealingAuditLogger } from './HealingAuditLogger';
import { ScreenshotHealingService } from './ScreenshotHealingService';

export class WorkflowHealingService {
  readonly enabled = envBoolean('WORKFLOW_HEALING_ENABLED', true);
  private readonly maxSteps = envNumber('WORKFLOW_HEALING_MAX_STEPS', 6);
  private readonly llm = new LlmClient();
  private readonly context: PageContextBuilder;
  private readonly audit = new HealingAuditLogger();
  private readonly screenshot: ScreenshotHealingService;

  constructor(private readonly page: Page) {
    this.context = new PageContextBuilder(page);
    this.screenshot = new ScreenshotHealingService(page);
  }

  async plan(instruction: string): Promise<PromptPlan[]> {
    if (!this.enabled) throw new Error('Workflow healing is disabled');
    const evidence = await this.screenshot.capture('workflow-plan');
    const context = await this.context.build();
    await this.audit.record({ timestamp: new Date().toISOString(), kind: 'workflow', instruction, status: 'started' });
    try {
      const result = await this.llm.interpretWorkflow({ instruction, maxSteps: this.maxSteps, screenshotPath: evidence.path, ...context });
      await this.audit.record({
        timestamp: new Date().toISOString(), kind: 'workflow', instruction, status: 'passed',
        confidence: result.confidence, strategy: `${result.steps.length}-step-plan`, reason: result.reason,
        details: { steps: result.steps }
      });
      return result.steps;
    } catch (error) {
      await this.audit.record({
        timestamp: new Date().toISOString(), kind: 'workflow', instruction, status: 'failed',
        reason: error instanceof Error ? error.message : String(error)
      });
      throw error;
    }
  }
}
