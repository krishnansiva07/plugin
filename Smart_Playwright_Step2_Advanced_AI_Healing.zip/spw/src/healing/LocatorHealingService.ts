import type { Locator, Page } from '@playwright/test';
type PlaywrightRole = Parameters<Page['getByRole']>[0];
import { LlmClient, type HealingSuggestion } from '../llm/LlmClient';
import { PageContextBuilder } from '../core/context/PageContextBuilder';
import { ConfidenceEngine } from './ConfidenceEngine';
import { HealingRepository } from './HealingRepository';
import { HealingAuditLogger } from './HealingAuditLogger';
import { ScreenshotHealingService } from './ScreenshotHealingService';
import { env } from '../utils/Environment';

export interface LocatorHealingInput {
  instruction: string;
  action: string;
  target: string;
  value?: string;
  failedStrategies: string[];
  errors: Error[];
}

export interface LocatorHealingResult {
  locator: Locator;
  suggestion: HealingSuggestion;
  source: 'cache' | 'llm';
}

export class LocatorHealingService {
  private readonly llm = new LlmClient();
  private readonly confidence = new ConfidenceEngine();
  private readonly contextBuilder: PageContextBuilder;
  private readonly repository = new HealingRepository();
  private readonly audit = new HealingAuditLogger();
  private readonly screenshot: ScreenshotHealingService;

  constructor(private readonly page: Page) {
    this.contextBuilder = new PageContextBuilder(page);
    this.screenshot = new ScreenshotHealingService(page);
  }

  get enabled(): boolean { return this.llm.enabled || this.repository.enabled; }

  async heal(input: LocatorHealingInput): Promise<LocatorHealingResult> {
    const context = await this.contextBuilder.build();
    const application = env('PROJECT_NAME', 'Smart Playwright Framework');
    const key = this.repository.buildKey({
      application,
      pageUrl: context.pageUrl,
      pageTitle: context.pageTitle,
      action: input.action,
      target: input.target
    });

    const cached = this.repository.find(key);
    if (cached) {
      try {
        const suggestion = HealingRepository.toSuggestion(cached);
        const locator = this.toLocator(suggestion);
        await this.confidence.validate(suggestion, locator);
        await this.audit.record({
          timestamp: new Date().toISOString(), kind: 'cache', instruction: input.instruction,
          status: 'cache-hit', confidence: suggestion.confidence, strategy: suggestion.strategy, reason: suggestion.reason
        });
        return { locator: locator.first(), suggestion, source: 'cache' };
      } catch {
        this.repository.markFailure(key);
      }
    }

    if (!this.llm.enabled) throw new Error('No valid healing cache entry and LLM healing is disabled');
    const evidence = await this.screenshot.capture('locator-healing');
    await this.audit.record({ timestamp: new Date().toISOString(), kind: 'locator', instruction: input.instruction, status: 'started' });
    try {
      const suggestion = await this.llm.suggestLocator({
        instruction: input.instruction,
        action: input.action,
        target: input.target,
        value: input.value,
        failedStrategies: input.failedStrategies,
        errors: input.errors.map(error => error.message),
        ...context
      });
      if (!suggestion) throw new Error('LLM healing returned no suggestion');
      const locator = this.toLocator(suggestion);
      await this.confidence.validate(suggestion, locator);
      this.repository.save({
        key,
        application,
        pageUrlPattern: context.pageUrl.replace(/[?#].*$/, ''),
        pageTitle: context.pageTitle,
        action: input.action,
        target: input.target,
        suggestion
      });
      await this.audit.record({
        timestamp: new Date().toISOString(), kind: 'locator', instruction: input.instruction,
        status: 'passed', confidence: suggestion.confidence, strategy: suggestion.strategy, reason: suggestion.reason,
        details: { screenshotPath: evidence.path, target: input.target, action: input.action }
      });
      return { locator: locator.first(), suggestion, source: 'llm' };
    } catch (error) {
      await this.audit.record({
        timestamp: new Date().toISOString(), kind: 'locator', instruction: input.instruction,
        status: 'failed', reason: error instanceof Error ? error.message : String(error)
      });
      throw error;
    }
  }

  private toLocator(suggestion: HealingSuggestion): Locator {
    const value = suggestion.value || suggestion.name || suggestion.selector;
    switch (suggestion.strategy) {
      case 'testId': return this.page.getByTestId(this.required(value, 'testId value'));
      case 'role': return this.page.getByRole(this.required(suggestion.role, 'role') as PlaywrightRole, { name: this.required(suggestion.name || suggestion.value, 'accessible name'), exact: suggestion.exact ?? true });
      case 'label': return this.page.getByLabel(this.required(value, 'label'), { exact: suggestion.exact ?? true });
      case 'placeholder': return this.page.getByPlaceholder(this.required(value, 'placeholder'), { exact: suggestion.exact ?? true });
      case 'text': return this.page.getByText(this.required(value, 'text'), { exact: suggestion.exact ?? true });
      case 'name': return this.page.locator(`[name="${this.escapeAttribute(this.required(value, 'name'))}"]`);
      case 'ariaLabel': return this.page.locator(`[aria-label="${this.escapeAttribute(this.required(value, 'aria-label'))}"]`);
      case 'css': return this.page.locator(this.safeCss(this.required(suggestion.selector, 'selector')));
      default: throw new Error(`Unsupported LLM locator strategy: ${String(suggestion.strategy)}`);
    }
  }

  private safeCss(selector: string): string {
    if (/xpath=|\/\/|:nth-|nth\(|script|javascript:/i.test(selector)) throw new Error(`Unsafe LLM CSS selector rejected: ${selector}`);
    return selector;
  }

  private required(value: string | undefined, field: string): string {
    if (!value?.trim()) throw new Error(`LLM healing response is missing ${field}`);
    return value.trim();
  }

  private escapeAttribute(value: string): string { return value.replace(/["\\]/g, '\\$&'); }
}
