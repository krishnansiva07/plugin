import path from 'node:path';
import fs from 'node:fs';
import { test, type Page } from '@playwright/test';
import { envBoolean } from '../utils/Environment';

export interface ScreenshotEvidence {
  path?: string;
  base64?: string;
}

export class ScreenshotHealingService {
  readonly enabled = envBoolean('SCREENSHOT_HEALING_ENABLED', true);

  constructor(private readonly page: Page) {}

  async capture(label: string): Promise<ScreenshotEvidence> {
    if (!this.enabled) return {};
    const safe = label.replace(/[^a-z0-9-]+/gi, '-').replace(/^-|-$/g, '').toLowerCase();
    const directory = path.resolve('test-results/healing-screenshots');
    fs.mkdirSync(directory, { recursive: true });
    const file = path.join(directory, `${Date.now()}-${safe || 'healing'}.png`);
    const buffer = await this.page.screenshot({ path: file, type: 'png', fullPage: false });
    try {
      await test.info().attach(`healing-${safe || 'screenshot'}`, { body: buffer, contentType: 'image/png' });
    } catch {
      // Outside test context.
    }
    return {
      path: file,
      base64: envBoolean('LLM_INCLUDE_SCREENSHOT_BASE64', false) ? buffer.toString('base64') : undefined
    };
  }
}
