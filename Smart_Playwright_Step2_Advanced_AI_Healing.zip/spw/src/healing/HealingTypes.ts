export type HealingKind = 'locator' | 'workflow' | 'verification' | 'screenshot' | 'cache';

export interface HealingAuditEntry {
  timestamp: string;
  kind: HealingKind;
  instruction: string;
  status: 'started' | 'passed' | 'failed' | 'cache-hit';
  confidence?: number;
  strategy?: string;
  reason?: string;
  details?: Record<string, unknown>;
}

export interface CachedLocator {
  key: string;
  application: string;
  pageUrlPattern: string;
  pageTitle: string;
  action: string;
  target: string;
  suggestion: {
    strategy: string;
    selector?: string;
    role?: string;
    name?: string;
    value?: string;
    exact?: boolean;
    confidence: number;
    reason: string;
  };
  successCount: number;
  failureCount: number;
  updatedAt: string;
}
