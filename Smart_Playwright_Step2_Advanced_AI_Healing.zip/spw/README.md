# Smart Playwright LangChain Framework v3.0

> Step 1 update: true LLM prompt execution, TypeScript DSL, native Playwright hybrid tests, multi-fallback healing, confidence validation, comma-separated filters, and the Windows empty-browser version-detection fix are documented in `STEP1_IMPLEMENTATION.md`.


A complete TypeScript Playwright framework using installed Chrome/Edge, headed UI mode, JSON test data, colourful HTML reporting, and LangChain-based LLM self-healing.

## 1. Prerequisites
- Node.js 20 LTS or 22 LTS
- npm
- Installed Chrome or Edge
- Corporate CA bundle when required by your office LLM/npm gateway

## 2. Put the CA file
Copy your CA bundle to:

`certificates/cacert`

The extension is optional. The file must be PEM text containing `-----BEGIN CERTIFICATE-----`.

## 3. First-time setup
Open PowerShell in the project root:

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\scripts\setup.ps1
Copy-Item .env.example .env -Force
```

The setup script uses the certificate for npm and runs `npm ci`.

## 4. Configure `.env`
For Chrome first, Edge fallback:

```env
BROWSER=auto
BROWSER_PRIORITY=chrome,edge
```

For LangChain healing:

```env
LLM_ENABLED=true
LLM_API_KEY=your-token
LLM_BASE_URL=https://your-company-llm-endpoint/v1
LLM_MODEL_NAME=your-model
```

Use the same API key, base URL and model name concept as the shared Java LangChain4j client. Do not append `/chat/completions` because LangChain adds it.

## 5. Run

```powershell
npm test
```

`npm test` automatically finds `certificates/cacert`, sets `NODE_EXTRA_CA_CERTS` in a fresh Node process, then starts Playwright.

## 6. Test data
Edit `test-data/login-tests.json`. Set `run` to `false` to skip a row.

## 7. Report
After execution open `reports/index.html`. It includes percentage summary and Serial No., Test ID, Test Name, Status.

## 8. Verify self-healing
In `src/pages/LoginPage.ts`, temporarily make username primary and both fallbacks invalid. Enable LLM. Run `npm test`. Expected terminal output contains `[LLM HEALING] SUCCESS`, and the HTML status becomes `PASSED – HEALED`.

## Troubleshooting
- `self-signed certificate in certificate chain`: confirm `certificates/cacert` is PEM text, then use `npm test` (not direct `npx playwright test`).
- Certificate ignored: Node reads `NODE_EXTRA_CA_CERTS` only at process start; the provided runner starts a fresh process.
- Binary certificate: convert to PEM using `certutil -encode input.cer certificates\cacert.pem`.

## 9. Command-line execution filters

All tests:

```powershell
npm test
```

By Test ID:

```powershell
npm test -- --testid=TC_LOGIN_001
```

By multiple Test IDs:

```powershell
npm test -- --testid=TC_LOGIN_001,TC_LOGIN_003
```

By tag:

```powershell
npm test -- --tag=smoke
npm test -- --tag=@regression
```

By test name:

```powershell
npm test -- --testname="Login with valid credentials"
```

By suite:

```powershell
npm test -- --suite="SauceDemo Login"
```

Combined filters use AND logic between filter types and OR logic for comma-separated values:

```powershell
npm test -- --suite="SauceDemo Login" --tag=regression --testid=TC_LOGIN_003,TC_LOGIN_004
```

Native Playwright arguments are passed through:

```powershell
npm test -- --testid=TC_LOGIN_001 --headed --workers=1
```

The standard npm separator is two normal hyphens: `npm test -- --testid=...`.
The runner also reads npm config-style input such as `npm test --testid=TC_LOGIN_001` where supported by the installed npm version.

Add optional `suite` and `tags` fields to each JSON test row:

```json
{
  "run": true,
  "testId": "TC_ORDER_001",
  "testName": "Create a new order",
  "suite": "Order Management",
  "tags": ["smoke", "order"]
}
```

## 10. Certificate folder

Copy your PEM certificate into `certificates/`. The file may have any name ending in `.pem`, `.crt`, or `.cer`. The runner validates that it contains a PEM certificate block and automatically sets `NODE_EXTRA_CA_CERTS` before Playwright starts.

## 11. Three supported authoring styles

The framework supports natural language, the framework DSL, and native Playwright. They may also be combined in one test.

### Natural language

```ts
const ai = AI.on(page);
await ai.run([
  'Open the application',
  'Enter standard_user into Username',
  'Enter secret_sauce into Password',
  'Click Login'
]);
```

### Framework DSL

```ts
const ai = AI.on(page);
await page.goto('/');
await ai.fill('Username', 'standard_user');
await ai.fill('Password', 'secret_sauce');
await ai.click('Login');
```

### Native Playwright

```ts
await page.goto('/');
await page.getByTestId('username').fill('standard_user');
await page.getByTestId('password').fill('secret_sauce');
await page.getByTestId('login-button').click();
```

### Hybrid test

See `tests/samples/hybrid.spec.ts`. It combines all three styles in one test.

## 12. Reliable comma-separated execution

Filters are now applied before test registration rather than only through Playwright grep. Therefore unmatched tests are not registered and do not create empty browser sessions.

```powershell
npm test -- --testid=TC_NL_001,TC_DSL_001,TC_HYBRID_001
npm test -- --tag=smoke,regression
npm test -- --testname="natural language,framework DSL"
npm test -- --suite="Execution Styles,SauceDemo Login"
```

Within one filter type comma-separated values use OR logic. Different filter types use AND logic.

## AI prompts, TypeScript DSL and native Playwright

The three styles use the same Playwright page and may be combined in one test:

```ts
const ai = AI.on(page);
await ai.prompt('Open the application');       // Always sent to the configured LLM
await ai.fill('Username', 'standard_user');    // Framework TypeScript DSL
await page.getByTestId('password').fill('secret_sauce'); // Native Playwright
await ai.prompt('Click the Login button');     // Always sent to the LLM
```

`ai.prompt()` and its alias `ai.step()` do not parse keywords with regular expressions. The complete instruction and current page context are sent to the LLM, which returns one structured action. `LLM_ENABLED=true` is mandatory for these APIs.

## TypeScript fallback strategies

Normal semantic locators run first. Custom fallbacks run only if normal resolution fails. LLM locator healing runs after custom fallbacks when enabled.

```ts
await ai.fill('Username', 'standard_user', {
  fallback: [
    async ({ page }) => page.locator('input[name="user-name"]').fill('standard_user'),
    async ({ page }) => page.locator('#user-name').fill('standard_user')
  ],
  validate: async page => expect(page.getByTestId('username')).toHaveValue('standard_user')
});

await ai.click('Login', {
  fallback: [
    async ({ page }) => page.getByRole('button', { name: 'Login', exact: true }).click(),
    async ({ page }) => page.locator('input[type="submit"]').click()
  ],
  validate: async page => expect(page.getByTestId('title')).toHaveText('Products'),
  allowLlmHealing: true,
  allowForce: false
});
```

Force actions are disabled globally by default. They require both `allowForce: true` on the action and `ALLOW_FORCE_ACTIONS=true` in `.env`.

## Browser launch control

The browser is created only when an actually registered test requests the Playwright `page` fixture. Sample specifications are not registered during a plain `npm test` unless `RUN_SAMPLE_TESTS=true`. They are still registered when selected through test ID, tag, name or suite filters.

Recommended local settings:

```env
WORKERS=1
RETRIES=0
RUN_SAMPLE_TESTS=false
HEADLESS=false
SLOW_MO=0
```

Use `HEADLESS=true` when no browser windows should be displayed. In headed mode, Playwright creates a fresh isolated browser context for each executing test; this is expected isolation, not an empty pre-launch. With `WORKERS=1`, tests run sequentially.

Run the individual samples:

```bash
npm test -- --testid=TC_AI_001
npm test -- --testid=TC_DSL_001
npm test -- --testid=TC_PW_001
npm test -- --testid=TC_HYBRID_001
npm test -- --testid=TC_TS_FALLBACK_001
```

Run comma-separated IDs:

```bash
npm test -- --testid=TC_DSL_001,TC_PW_001,TC_TS_FALLBACK_001
```

## Step 2 advanced AI healing

### Multi-action workflow prompt

```ts
const ai = AI.on(page);
await ai.workflow(
  'Enter standard_user in Username, enter secret_sauce in Password, then click Login'
);
```

`ai.prompt()` remains the preferred API for one action. When its single-action confidence is below the configured threshold and `PROMPT_WORKFLOW_FALLBACK_ENABLED=true`, it asks the LLM for a bounded multi-action workflow.

### Verification healing

```ts
await ai.verifyText('Order was successful');
await ai.verifyEquals('Order Status', 'SUCCESS');
```

A normal Playwright assertion runs first. Only after failure does the conservative LLM verification service inspect current visible content. It cannot execute code or invent selectors, and it must return a visible equivalent with confidence above `VERIFICATION_HEALING_MIN_CONFIDENCE`.

### Healing cache

A successful LLM locator is saved in `test-results/healing-cache.json`. On the next matching page/action/target, the cached locator is validated for uniqueness, visibility, enabled state and confidence before reuse. A stale cache entry is rejected and the LLM is called again.

### Audit evidence

Healing screenshots and JSON audit records are written under `test-results/`. The HTML report shows a healed status and the associated audit annotations.
