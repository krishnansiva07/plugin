import { test } from '@playwright/test';
import { AI } from '../../src/framework/AI';
import { shouldRunSampleTest } from '../../src/core/execution/ExecutionFilter';

const meta = {
  testId: 'TC_CACHE_001',
  testName: 'Reuse a successful healed locator from the local cache',
  suite: 'Advanced AI Healing',
  tags: ['ai', 'cache', 'step2']
};

if (shouldRunSampleTest(meta)) {
  test.describe(meta.suite, () => {
    test(`[${meta.testId}] ${meta.testName} @ai @cache @step2`, async ({ page }) => {
      const ai = AI.on(page);
      await page.setContent('<button aria-label="Continue order">Proceed</button>');
      await ai.click('Continue order', { allowLlmHealing: true });
    });
  });
}
