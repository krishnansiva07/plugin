import { test } from '@playwright/test';
import { AI } from '../../src/framework/AI';
import { shouldRunSampleTest } from '../../src/core/execution/ExecutionFilter';

const meta = {
  testId: 'TC_VERIFY_HEAL_001',
  testName: 'Conservative LLM verification healing example',
  suite: 'Advanced AI Healing',
  tags: ['ai', 'verification', 'step2']
};

if (shouldRunSampleTest(meta)) {
  test.describe(meta.suite, () => {
    test(`[${meta.testId}] ${meta.testName} @ai @verification @step2`, async ({ page }) => {
      const ai = AI.on(page);
      await page.setContent('<main><h1>Order completed successfully</h1><div>Status: Completed</div></main>');

      // The direct text check fails. When enabled, verification healing may accept only a
      // clearly equivalent visible business outcome with confidence above the threshold.
      await ai.verifyText('Order was successful');
    });
  });
}
