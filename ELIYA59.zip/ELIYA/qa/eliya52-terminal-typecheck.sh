#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
ROOT="$PWD/src/main/java/com/llmart/llm"
D=$(mktemp -d)
trap 'rm -rf "$D"' EXIT
mkdir -p "$D/src/org/springframework/beans/factory/annotation"
cat > "$D/src/org/springframework/beans/factory/annotation/Autowired.java" <<'EOF'
package org.springframework.beans.factory.annotation;public @interface Autowired {boolean required() default true;}
EOF
mkdir -p "$D/src/com/llmart/llm/service" "$D/src/com/llmart/llm/dto" "$D/src/com/llmart/llm/controller" "$D/src/org/springframework/stereotype" "$D/src/org/springframework/web/bind/annotation" "$D/src/com/fasterxml/jackson/databind" "$D/src/jakarta/validation" "$D/src/jakarta/annotation"
for file in service/TerminalSessionService.java service/AgentApprovalService.java service/AgentApprovalTimeoutException.java service/TerminalWorkspaceDiscoveryService.java controller/TerminalController.java; do cp "$ROOT/$file" "$D/src/com/llmart/llm/${file%/*}/"; done
cat > "$D/src/com/llmart/llm/service/ChatService.java" <<'EOF'
package com.llmart.llm.service;
import com.llmart.llm.dto.*;import java.util.concurrent.*;import java.util.concurrent.atomic.*;import java.util.function.*;
class ChatService {
 static final BlockingQueue<String> ENTERED = new LinkedBlockingQueue<>();
 static final ConcurrentHashMap<String,CountDownLatch> GATES = new ConcurrentHashMap<>();
 static final AtomicInteger ACTIVE = new AtomicInteger(), MAX_ACTIVE = new AtomicInteger();
 void runTerminal(String key, ChatRequest request, BiConsumer<String,Object> cb) {
   int n=ACTIVE.incrementAndGet(); MAX_ACTIVE.updateAndGet(previous -> Math.max(previous,n));
   try {
     CountDownLatch gate=GATES.computeIfAbsent(request.message(),name->new CountDownLatch(1));
     ENTERED.add(request.message());
     if (!gate.await(5,TimeUnit.SECONDS)) throw new IllegalStateException("test gate timeout: "+request.message());
     if(request.message().startsWith("FAIL"))cb.accept("error","Test failure");
     else cb.accept("done",new MessageDto("Finished "+request.message()));
   } catch(InterruptedException ex) {Thread.currentThread().interrupt();cb.accept("stopped",null);}
   finally {ACTIVE.decrementAndGet();}
 }
}
EOF
cat > "$D/src/com/llmart/llm/service/TerminalSkillStudioService.java" <<'EOF'
package com.llmart.llm.service;import java.util.*;import java.io.*;public class TerminalSkillStudioService {public record DefinitionRequest(String projectId,String repository,String format,String kind,String name,String description,String instructions){} public Map<String,Object> create(DefinitionRequest r)throws IOException{return Map.of();}}
EOF
cat > "$D/src/com/llmart/llm/service/FileService.java" <<'EOF'
package com.llmart.llm.service;import java.util.*;class FileService {List<String> copyForTerminal(String a,String b)throws Exception{return List.of();}}
EOF
cat > "$D/src/com/llmart/llm/service/ConversationService.java" <<'EOF'
package com.llmart.llm.service;class ConversationService {Conversation create(){return new Conversation();} static class Conversation {String getId(){return "00000000-0000-0000-0000-000000000000";}}}
EOF
cat > "$D/src/com/llmart/llm/service/AgentService.java" <<'EOF'
package com.llmart.llm.service;import java.util.*;class AgentService {void stageTransferredPlan(String id,List<String> plan){} void discardTransferredPlan(String id) {}}
EOF
cat > "$D/src/com/llmart/llm/service/AgentRunService.java" <<'EOF'
package com.llmart.llm.service;import java.util.*;class AgentRunService {boolean cancel(String s){return true;} Map<String,Object> status(String s){return Map.of();} AgentRun require(String id){return new AgentRun();} static class AgentRun {String conversationId(){return "c";}String projectId(){return "p";} boolean finished(){return false;}boolean planLocked(){return false;}long mutationRevision(){return 0;}Map<String,Object> snapshot(){return Map.of("plan",List.of(Map.of("text","Do requested step")),"objective","Do requested step");}void checkCancelled(){}}}
EOF
cat > "$D/src/com/llmart/llm/service/AgentQuestionService.java" <<'EOF'
package com.llmart.llm.service;import java.util.*;class AgentQuestionService {boolean answer(String a,String b,String c,String d){return false;} void enable(String id){}void disable(String id){}void cancel(String id){}Map<String,Object> pending(String id){return Map.of();}}
EOF
cat > "$D/src/com/llmart/llm/service/ProjectService.java" <<'EOF'
package com.llmart.llm.service;import com.llmart.llm.dto.*;import java.util.*;class ProjectService {ProjectWorkspace require(String s){return new ProjectWorkspace(s);}List<ProjectDto> mappedLocalWorkspaces(){return List.of();}}class ProjectWorkspace {String id;ProjectWorkspace(String s){id=s;}boolean hasLocalPath(){return true;}String getLocalPath(){return "/tmp/eliya-"+id;}}
EOF
cat > "$D/src/com/llmart/llm/service/TerminalGitService.java" <<'EOF'
package com.llmart.llm.service;import java.util.*;import java.io.*;public class TerminalGitService {public Map<String,Object> review(String a,String b)throws IOException{return Map.of();}public List<Map<String,Object>> repositories(String id)throws IOException{return List.of();}public Map<String,Object> createBranch(String a,String b,String c)throws IOException{return Map.of();} public Map<String,Object> createWorktree(String a,String b,String c,String d)throws IOException{return Map.of();}}
EOF
cat > "$D/src/com/llmart/llm/service/WorkspaceRootGuard.java" <<'EOF'
package com.llmart.llm.service;import java.nio.file.*;class WorkspaceRootGuard{static Path requireNarrow(Path p){return p;}}
EOF
cat > "$D/src/com/llmart/llm/dto/ProjectDto.java" <<'EOF'
package com.llmart.llm.dto;public record ProjectDto(){}
EOF
cat > "$D/src/com/llmart/llm/dto/ChatSettings.java" <<'EOF'
package com.llmart.llm.dto;public record ChatSettings(String model){}
EOF
cat > "$D/src/com/llmart/llm/dto/ChatRequest.java" <<'EOF'
package com.llmart.llm.dto;import java.util.*;public record ChatRequest(String conversationId,String message,List<String> attachmentIds,String projectId,String mode,Boolean regenerate,ChatSettings settings,List<String> referenceProjectIds,Map<String,String> referenceProjectNames, Boolean documentationTemplateSelected) {}
EOF
cat > "$D/src/com/llmart/llm/dto/MessageDto.java" <<'EOF'
package com.llmart.llm.dto;public record MessageDto(String content) {}
EOF
cat > "$D/src/com/fasterxml/jackson/databind/ObjectMapper.java" <<'EOF'
package com.fasterxml.jackson.databind;
import java.io.*;import java.util.*;import com.llmart.llm.dto.ChatSettings;
public class ObjectMapper {
 @SuppressWarnings("unchecked") public <T> T convertValue(Object obj, Class<T> type) {
   if (type==Map.class && obj instanceof ChatSettings settings) return (T) new HashMap<>(Map.of("model",settings.model()));
   if (type==ChatSettings.class && obj instanceof Map<?,?> map) return (T)new ChatSettings(String.valueOf(map.get("model")));
   return null;
 }
 public <T> T readValue(File f,Class<T> c){return null;}
 public void writeValue(File f,Object v) throws IOException{}
}
EOF
cat > "$D/src/org/springframework/stereotype/Service.java" <<'EOF'
package org.springframework.stereotype;public @interface Service {}
EOF
for name in RestController RequestMapping PostMapping GetMapping PatchMapping DeleteMapping PathVariable RequestParam RequestHeader RequestBody; do cat > "$D/src/org/springframework/web/bind/annotation/$name.java" <<EOF
package org.springframework.web.bind.annotation;public @interface $name {String value() default ""; boolean required() default true;}
EOF
done
cat > "$D/src/jakarta/validation/Valid.java" <<'EOF'
package jakarta.validation;public @interface Valid {}
EOF
cat > "$D/src/jakarta/annotation/PreDestroy.java" <<'EOF'
package jakarta.annotation;public @interface PreDestroy {}
EOF
cat > "$D/src/ApprovalTransferSmoke.java" <<'EOF'
import com.llmart.llm.service.AgentApprovalService;
public class ApprovalTransferSmoke {
 public static void main(String[] args)throws Exception {
   var service=new AgentApprovalService();
   var plan=service.create("run-1","plan_approval","plan",true);
   if(service.transferPlan(plan.id(),"run-2"))throw new AssertionError("Wrong run transferred");
   if(!service.transferPlan(plan.id(),"run-1"))throw new AssertionError("Plan transfer refused");
   if(service.resolve(plan.id(), AgentApprovalService.Decision.ONCE))throw new AssertionError("Transferred approval executed twice");
   if(service.await(plan.id(),java.time.Duration.ofSeconds(1))!=AgentApprovalService.Decision.TRANSFER)throw new AssertionError("Bad transfer decision");
   var delete=service.create("run-1","file_deletion","delete",false);
   if(service.transferPlan(delete.id(),"run-1"))throw new AssertionError("Deletion approval transferred as a plan");
   System.out.println("PASS: approval handoff rejects wrong run, disallows double approval, protects deletion policy");
 }
}
EOF
cat > "$D/src/com/llmart/llm/service/TerminalQueueSmoke.java" <<'EOF'
package com.llmart.llm.service;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.llmart.llm.dto.*;
import java.nio.file.*;import java.util.*;import java.util.concurrent.*;
public class TerminalQueueSmoke {
 static ChatRequest request(String msg) {return request(msg,"project-A");}
 static ChatRequest request(String msg,String project) {
   return new ChatRequest("source",msg,List.of(),project,"agent",false,new ChatSettings("model-a"),List.of(),Map.of(),false);
 }
 static void check(boolean value,String message){if(!value)throw new AssertionError(message);}
 static String waitStart() throws Exception {
   String value=ChatService.ENTERED.poll(4,TimeUnit.SECONDS);
   if(value==null)throw new AssertionError("Expected queued task to start");
   return value;
 }
 static void release(String value){ChatService.GATES.get(value).countDown();}
 static void waitUntil(java.util.function.BooleanSupplier check) throws Exception {
   for(int i=0;i<150;i++){if(check.getAsBoolean())return;Thread.sleep(12);}
   throw new AssertionError("Expected terminal state was not reached");
 }
 @SuppressWarnings("unchecked") static List<Map<String,Object>> queue(Map<String,Object> snapshot){return (List<Map<String,Object>>)snapshot.get("queue");}
 static void run() throws Exception {
   System.setProperty("eliya.terminal.store",Files.createTempDirectory("eliya-queue-smoke").toString());
   var service=new TerminalSessionService(new ChatService(),new AgentRunService(),new ObjectMapper(),
        new AgentQuestionService(),new ProjectService(),new AgentService(),new AgentApprovalService());
   try {
     String id=(String)service.launch("test-secret",request("A")).get("id");
     check("A".equals(waitStart()),"First task was not launched");
     service.message("test-secret",id,request("B"));
     var result=service.message("test-secret",id,request("C"));
     check((int)result.get("queueCount")==2,"Concurrent messages must enqueue");
     String first=(String)queue(result).get(0).get("id"), second=(String)queue(result).get(1).get("id");
     service.editQueued(id,first,"B-edited");
     service.moveQueued(id,second,"up");
     check("C".equals(queue(service.get(id)).get(0).get("prompt")),"Reordering changed FIFO incorrectly");
     release("A");check("C".equals(waitStart()),"Queue did not execute in selected order");
     check(ChatService.MAX_ACTIVE.get()<=1,"Overlapping file mutations occurred");
     release("C");check("B-edited".equals(waitStart()),"Edits to queued instruction were lost");
     release("B-edited");
     waitUntil(()->"completed".equals(service.get(id).get("status")) && ((Number)service.get(id).get("queueCount")).intValue()==0);
     String f=(String)service.message("test-secret",id,request("FAIL-A")).get("id");
     check("FAIL-A".equals(waitStart()),"Failed-run setup did not start");
     service.message("test-secret",f,request("After-failure"));
     release("FAIL-A");waitUntil(()->Boolean.TRUE.equals(service.get(f).get("queuePaused")));
     check(ChatService.ENTERED.poll(150,TimeUnit.MILLISECONDS)==null,"Queue executed despite failure");
     service.resumeQueued("test-secret",f,request("resume"));
     check("After-failure".equals(waitStart()),"Manual resume did not restart failed queue");
     release("After-failure");
     waitUntil(()->"completed".equals(service.get(id).get("status")));
     service.message("test-secret",id,request("STOP-A"));
     check("STOP-A".equals(waitStart()),"Stop scenario did not start");
     service.message("test-secret",id,request("After-stop"));
     service.cancel(id);release("STOP-A");
     waitUntil(()->"cancelled".equals(service.get(id).get("status")) && Boolean.TRUE.equals(service.get(id).get("queuePaused")));
     check(ChatService.ENTERED.poll(150,TimeUnit.MILLISECONDS)==null,"Stopped run executed pending work without user approval");
     service.resumeQueued("test-secret",id,request("resume"));
     check("After-stop".equals(waitStart()),"Paused queue did not resume");release("After-stop");
     waitUntil(()->"completed".equals(service.get(id).get("status")));
     service.message("test-secret",id,request("INTERRUPT-A"));
     check("INTERRUPT-A".equals(waitStart()),"Interrupt scenario setup failed");
     service.message("test-secret",id,request("After-interrupt"));
     service.interruptAndNext(id);release("INTERRUPT-A");
     check("After-interrupt".equals(waitStart()),"Explicit interrupt-next did not advance queue");
     release("After-interrupt");
     waitUntil(()->"completed".equals(service.get(id).get("status")));
     check(ChatService.MAX_ACTIVE.get()==1,"Tasks in the same workspace were executed simultaneously");
     String queued=(String)service.message("test-secret",id,request("Last")).get("id");
     check("Last".equals(waitStart()),"Last setup did not start");
     var queuedResult=service.message("test-secret",queued,request("Remove-me"));
     service.removeQueued(id,(String)queue(queuedResult).get(0).get("id"));
     release("Last");waitUntil(()->"completed".equals(service.get(id).get("status")));
     check(ChatService.ENTERED.poll(150,TimeUnit.MILLISECONDS)==null,"Deleted queue item executed");
     // A separate tab and unrelated writable root can progress concurrently.
     String parallelA=(String)service.launch("test-secret",request("PARALLEL-A","project-A")).get("id");
     check("PARALLEL-A".equals(waitStart()),"Parallel first root did not start");
     String parallelB=(String)service.launch("test-secret",request("PARALLEL-B","project-B")).get("id");
     check("PARALLEL-B".equals(waitStart()),"Independent root was unnecessarily blocked");
     check(ChatService.ACTIVE.get()==2,"Independent tabs should execute on different roots simultaneously");
     // A second tab aimed at the same root must wait until its prior owner finishes.
     String sameRoot=(String)service.launch("test-secret",request("SAME-ROOT","project-A")).get("id");
     waitUntil(()->"waiting_workspace".equals(service.get(sameRoot).get("status")));
     check(ChatService.ENTERED.poll(150,TimeUnit.MILLISECONDS)==null,"Overlapping workspace started concurrently");
     release("PARALLEL-A");check("SAME-ROOT".equals(waitStart()),"Same-root task was not released after first completed");
     release("SAME-ROOT");release("PARALLEL-B");
     waitUntil(()->"completed".equals(service.get(parallelA).get("status"))
                && "completed".equals(service.get(parallelB).get("status"))
                && "completed".equals(service.get(sameRoot).get("status")));
     System.out.println("PASS: FIFO, edits, reorder/remove, failure and stop pause, resume, interrupt, same-root serialization and separate-root concurrency");
   } finally {service.shutdown();}
 }
 public static void main(String[] args) throws Exception {run();}
}
EOF
mkdir -p "$D/classes"
javac --release 17 -d "$D/classes" $(find "$D/src" -name '*.java')
java -cp "$D/classes" ApprovalTransferSmoke
java -cp "$D/classes" com.llmart.llm.service.TerminalQueueSmoke
printf 'PASS: Terminal service, controller, workspace discovery and approval types compile under Java 17 stubs\n'
