package com.astraquiz.model;

public class Team {
    private String name;
    private int score;
    private int simpleAsked;
    private int mediumAsked;
    private int complexAsked;

    public Team() {}
    public Team(String name) { this.name = name; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public int getScore() { return score; }
    public void setScore(int score) { this.score = score; }
    public void addScore(int points) { this.score += points; }
    public int getSimpleAsked() { return simpleAsked; }
    public void setSimpleAsked(int simpleAsked) { this.simpleAsked = simpleAsked; }
    public int getMediumAsked() { return mediumAsked; }
    public void setMediumAsked(int mediumAsked) { this.mediumAsked = mediumAsked; }
    public int getComplexAsked() { return complexAsked; }
    public void setComplexAsked(int complexAsked) { this.complexAsked = complexAsked; }
    public void increment(Difficulty difficulty) {
        if (difficulty == Difficulty.SIMPLE) simpleAsked++;
        if (difficulty == Difficulty.MEDIUM) mediumAsked++;
        if (difficulty == Difficulty.COMPLEX) complexAsked++;
    }
    public void decrement(Difficulty difficulty) {
        if (difficulty == Difficulty.SIMPLE && simpleAsked > 0) simpleAsked--;
        if (difficulty == Difficulty.MEDIUM && mediumAsked > 0) mediumAsked--;
        if (difficulty == Difficulty.COMPLEX && complexAsked > 0) complexAsked--;
    }
}
