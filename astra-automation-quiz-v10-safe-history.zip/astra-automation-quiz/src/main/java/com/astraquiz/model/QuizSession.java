package com.astraquiz.model;

import java.time.LocalDateTime;
import java.util.*;

public class QuizSession {
    private String quizId;
    private String quizName;
    private List<Team> teams = new ArrayList<>();
    private List<String> technologies = new ArrayList<>();
    private String quizCategory = "Automation Testing";
    private String audience = "Automation testers";
    private int simplePerTeam;
    private int mediumPerTeam;
    private int complexPerTeam;
    private int simplePoints;
    private int mediumPoints;
    private int complexPoints;
    private int simpleSeconds = 30;
    private int mediumSeconds = 45;
    private int complexSeconds = 60;
    private int currentTeamIndex;
    private String status = "CREATED";
    private LocalDateTime createdAt = LocalDateTime.now();
    private List<QuizQuestion> questions = new ArrayList<>();
    private boolean manualMode;
    private List<QuizQuestion> manualQuestionBank = new ArrayList<>();
    private Set<String> usedManualQuestionIds = new HashSet<>();

    public String getQuizId() { return quizId; }
    public void setQuizId(String quizId) { this.quizId = quizId; }
    public String getQuizName() { return quizName; }
    public void setQuizName(String quizName) { this.quizName = quizName; }
    public List<Team> getTeams() { return teams; }
    public void setTeams(List<Team> teams) { this.teams = teams; }
    public List<String> getTechnologies() { return technologies; }
    public void setTechnologies(List<String> technologies) { this.technologies = technologies; }
    public String getQuizCategory() { return quizCategory; }
    public void setQuizCategory(String quizCategory) { this.quizCategory = quizCategory; }
    public String getAudience() { return audience; }
    public void setAudience(String audience) { this.audience = audience; }
    public int getSimplePerTeam() { return simplePerTeam; }
    public void setSimplePerTeam(int simplePerTeam) { this.simplePerTeam = simplePerTeam; }
    public int getMediumPerTeam() { return mediumPerTeam; }
    public void setMediumPerTeam(int mediumPerTeam) { this.mediumPerTeam = mediumPerTeam; }
    public int getComplexPerTeam() { return complexPerTeam; }
    public void setComplexPerTeam(int complexPerTeam) { this.complexPerTeam = complexPerTeam; }
    public int getSimplePoints() { return simplePoints; }
    public void setSimplePoints(int simplePoints) { this.simplePoints = simplePoints; }
    public int getMediumPoints() { return mediumPoints; }
    public void setMediumPoints(int mediumPoints) { this.mediumPoints = mediumPoints; }
    public int getComplexPoints() { return complexPoints; }
    public void setComplexPoints(int complexPoints) { this.complexPoints = complexPoints; }
    public int getSimpleSeconds() { return simpleSeconds; }
    public void setSimpleSeconds(int simpleSeconds) { this.simpleSeconds = simpleSeconds; }
    public int getMediumSeconds() { return mediumSeconds; }
    public void setMediumSeconds(int mediumSeconds) { this.mediumSeconds = mediumSeconds; }
    public int getComplexSeconds() { return complexSeconds; }
    public void setComplexSeconds(int complexSeconds) { this.complexSeconds = complexSeconds; }
    public int getCurrentTeamIndex() { return currentTeamIndex; }
    public void setCurrentTeamIndex(int currentTeamIndex) { this.currentTeamIndex = currentTeamIndex; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
    public List<QuizQuestion> getQuestions() { return questions; }
    public void setQuestions(List<QuizQuestion> questions) { this.questions = questions; }
    public boolean isManualMode() { return manualMode; }
    public void setManualMode(boolean manualMode) { this.manualMode = manualMode; }
    public List<QuizQuestion> getManualQuestionBank() { return manualQuestionBank; }
    public void setManualQuestionBank(List<QuizQuestion> manualQuestionBank) { this.manualQuestionBank = manualQuestionBank; }
    public Set<String> getUsedManualQuestionIds() { return usedManualQuestionIds; }
    public void setUsedManualQuestionIds(Set<String> usedManualQuestionIds) { this.usedManualQuestionIds = usedManualQuestionIds; }
}
