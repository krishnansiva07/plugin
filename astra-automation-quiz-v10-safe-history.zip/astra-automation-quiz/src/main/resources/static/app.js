let quizId = null;
let currentQuestion = null;
let currentQuiz = null;
let answerVisible = false;
let audienceAnswerVisible = false;
let quizMasterVisible = true;
let manualQuestions = [];
let timerInterval = null;
let remainingSeconds = 0;
let primarySubmitted = false;
let stealSubmitted = false;
let historyVisible = false;

const api = async (url, method='GET', body=null) => {
  const res = await fetch(url, {method, headers:{'Content-Type':'application/json'}, body: body ? JSON.stringify(body) : null});
  const data = await res.json();
  if(!res.ok) throw new Error(data.message || 'Request failed');
  return data;
};

function lines(id){ return document.getElementById(id).value.split('\n').map(x=>x.trim()).filter(Boolean); }
function toast(msg){ const t=document.getElementById('toast'); t.innerText=msg; t.style.display='block'; setTimeout(()=>t.style.display='none',3500); }
function esc(v){ return String(v ?? '').replace(/[&<>'"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c])); }

async function createQuiz(){
  try{
    const source = document.querySelector('input[name="questionSource"]:checked').value;
    if(source === 'manual' && (!manualQuestions || manualQuestions.length === 0)){
      return toast('Manual mode selected. Please upload a valid JSON question file first.');
    }
    const req = {
      manualMode: source === 'manual',
      manualQuestions: source === 'manual' ? manualQuestions : [],
      quizName: document.getElementById('quizName').value,
      quizCategory: document.getElementById('quizCategory').value,
      audience: document.getElementById('audience').value,
      teamNames: lines('teamNames'),
      technologies: lines('technologies'),
      simplePerTeam: +document.getElementById('simplePerTeam').value,
      mediumPerTeam: +document.getElementById('mediumPerTeam').value,
      complexPerTeam: +document.getElementById('complexPerTeam').value,
      simplePoints: +document.getElementById('simplePoints').value,
      mediumPoints: +document.getElementById('mediumPoints').value,
      complexPoints: +document.getElementById('complexPoints').value,
      simpleSeconds: +document.getElementById('simpleSeconds').value,
      mediumSeconds: +document.getElementById('mediumSeconds').value,
      complexSeconds: +document.getElementById('complexSeconds').value
    };
    currentQuiz = await api('/api/quiz/create','POST',req);
    quizId = currentQuiz.quizId;
    document.getElementById('setupPanel').classList.add('hidden');
    document.getElementById('quizPanel').classList.remove('hidden');
    document.getElementById('liveTitle').innerText = currentQuiz.quizName;
    renderMeta(); renderLeaderboard(currentQuiz.teams); fillStealTeams();
    toast('Quiz created: ' + quizId);
  }catch(e){ toast(e.message); }
}

function renderMeta(){
  const qCount = currentQuiz.teams.length * (currentQuiz.simplePerTeam + currentQuiz.mediumPerTeam + currentQuiz.complexPerTeam);
  const mode = currentQuiz.manualMode ? 'Manual JSON Mode' : 'LLM Mode';
  document.getElementById('modeBadge').innerText = mode;
  document.getElementById('quizMeta').innerHTML = `Quiz ID: <b>${esc(currentQuiz.quizId)}</b> | Mode: <b>${esc(mode)}</b> | Category: <b>${esc(currentQuiz.quizCategory || 'Custom')}</b> | Teams: ${currentQuiz.teams.length} | Total Questions: ${qCount} | Topics: ${currentQuiz.technologies.map(esc).join(', ')}`;
}

function secondsForDifficulty(difficulty){
  if(!currentQuiz) return 30;
  if(difficulty === 'MEDIUM') return currentQuiz.mediumSeconds || 45;
  if(difficulty === 'COMPLEX') return currentQuiz.complexSeconds || 60;
  return currentQuiz.simpleSeconds || 30;
}

function startTimer(seconds){
  clearInterval(timerInterval);
  remainingSeconds = seconds;
  renderTimer();
  timerInterval = setInterval(() => {
    remainingSeconds--;
    renderTimer();
    if(remainingSeconds <= 0){
      clearInterval(timerInterval);
      document.getElementById('timerBox').classList.add('expired');
      toast('Time up!');
    }
  }, 1000);
}
function stopTimer(){ clearInterval(timerInterval); timerInterval = null; }
function renderTimer(){
  const box = document.getElementById('timerBox');
  if(!box) return;
  box.classList.remove('expired');
  const mm = String(Math.floor(Math.max(0, remainingSeconds)/60)).padStart(2,'0');
  const ss = String(Math.max(0, remainingSeconds)%60).padStart(2,'0');
  box.innerHTML = `<span>⏱️</span><b>${mm}:${ss}</b>`;
}

async function nextQuestion(){
  try{
    audienceAnswerVisible = false;
    answerVisible = false;
    primarySubmitted = false;
    stealSubmitted = false;
    currentQuestion = await api(`/api/quiz/${quizId}/next-question`,'POST',{});
    renderQuestion(); fillStealTeams(); renderAnswerPanel(); populateAnswerControls();
    startTimer(secondsForDifficulty(currentQuestion.difficulty));
    toast('Question generated for ' + currentQuestion.assignedTeam);
  }catch(e){
    if(e.message && e.message.toLowerCase().includes('quiz completed')) showWinnerScreen(); else toast(e.message);
  }
}

function renderQuestion(){
  const q = currentQuestion;
  if(!q) return;
  document.getElementById('questionBox').classList.remove('empty');
  const optionsHtml = Object.entries(q.options || {}).map(([k,v])=>`<div class="option"><b>${esc(k)}.</b> ${esc(v)}</div>`).join('');
  document.getElementById('questionBox').innerHTML = `
    <div class="meta">
      <span class="pill">Turn: ${esc(q.assignedTeam)}</span>
      <span class="pill">${esc(q.difficulty)}</span>
      <span class="pill">${esc(q.technology)}</span>
      <span class="pill">${q.points} Points</span>
      <span class="pill status-pill">Status: ${esc(q.status)}</span>
    </div>
    <h2>${esc(q.questionText)}</h2>
    ${optionsHtml || '<div class="option error">Options not available. Use Skip Question.</div>'}
    ${audienceAnswerVisible ? `<div class="audienceAnswer"><b>Correct Answer: ${esc(q.correctOption)}</b><br>${esc(q.explanation)}</div>` : ''}
  `;
  document.getElementById('assignedTeamLabel').innerHTML = `<b>${esc(q.assignedTeam)}</b> should answer this question.`;
  updateActionState();
}

function updateActionState(){
  const status = currentQuestion?.status || '';
  const isActive = status === 'ACTIVE';
  const isPool = status === 'CENTRAL_POOL';
  const primaryBtn = document.getElementById('primarySubmitBtn');
  const stealBtn = document.getElementById('stealSubmitBtn');
  const regenerateBtn = document.getElementById('skipBtn');
  if(primaryBtn) primaryBtn.disabled = !isActive || primarySubmitted;
  if(stealBtn) stealBtn.disabled = !isPool || stealSubmitted;
  if(regenerateBtn) regenerateBtn.disabled = !(isActive || isPool);
}

function populateAnswerControls(){
  const opts = currentQuestion?.options || {};
  const primary = document.getElementById('primaryAnswerSelect');
  const steal = document.getElementById('stealAnswerSelect');
  const html = '<option value="">-- Select Answer --</option>' + Object.entries(opts).map(([k,v]) => `<option value="${esc(k)}">${esc(k)}. ${esc(v)}</option>`).join('');
  primary.innerHTML = html;
  steal.innerHTML = html;
  primary.value = '';
  steal.value = '';
  updateActionState();
}

function toggleQuizMasterMode(){
  quizMasterVisible = !quizMasterVisible;
  document.getElementById('quizMasterCard').classList.toggle('hidden', !quizMasterVisible);
  toast(quizMasterVisible ? 'Quiz Master Mode visible' : 'Quiz Master Mode hidden for audience view');
}
function toggleAnswer(){ answerVisible = !answerVisible; renderAnswerPanel(); }
function revealAudienceAnswer(){
  if(!currentQuestion) return toast('Generate a question first');
  audienceAnswerVisible = !audienceAnswerVisible;
  renderQuestion();
}
function renderAnswerPanel(){
  const panel=document.getElementById('answerPanel');
  if(!currentQuestion || !answerVisible){ panel.classList.add('hidden'); panel.innerHTML=''; return; }
  panel.classList.remove('hidden');
  panel.innerHTML = `<h3>Correct Answer: ${esc(currentQuestion.correctOption)}</h3><p>${esc(currentQuestion.explanation)}</p><p><b>Status:</b> ${esc(currentQuestion.status)}</p>`;
}

async function submitPrimary(answer){
  if(!currentQuestion) return toast('Generate a question first');
  if(primarySubmitted || currentQuestion.status !== 'ACTIVE') return toast('This question is already submitted/closed. Generate next question.');
  try{
    primarySubmitted = true;
    document.getElementById('primarySubmitBtn').disabled = true;
    updateActionState();
    stopTimer();
    const res = await api(`/api/quiz/${quizId}/submit-primary`,'POST',{teamName:currentQuestion.assignedTeam, answer});
    toast(res.message); refreshFromSnapshot(res.data);
  }catch(e){ primarySubmitted = false; updateActionState(); toast(e.message); }
}
function submitPrimaryFromSelect(){ submitPrimary(document.getElementById('primaryAnswerSelect').value); }

async function submitSteal(answer){
  if(!currentQuestion) return toast('Generate a question first');
  if(stealSubmitted || currentQuestion.status !== 'CENTRAL_POOL') return toast('Central pool is not open or already submitted.');
  const teamName=document.getElementById('stealTeam').value;
  if(!teamName) return toast('Select stealing team');
  try{
    stealSubmitted = true;
    document.getElementById('stealSubmitBtn').disabled = true;
    updateActionState();
    const res = await api(`/api/quiz/${quizId}/submit-steal`,'POST',{teamName, answer});
    toast(res.message); refreshFromSnapshot(res.data);
  }catch(e){ stealSubmitted = false; updateActionState(); toast(e.message); }
}
function submitStealFromSelect(){ submitSteal(document.getElementById('stealAnswerSelect').value); }

async function skipQuestion(){
  if(!currentQuestion) return toast('Generate a question first');
  if(!confirm('Regenerate this bad/incorrectly loaded question? The bad question will not consume quota. Replacement question will be asked to the same team for the same points.')) return;
  try{
    stopTimer();
    audienceAnswerVisible = false;
    answerVisible = false;
    primarySubmitted = false;
    stealSubmitted = false;
    currentQuestion = await api(`/api/quiz/${quizId}/regenerate-question`,'POST',{});
    // Pull the full session snapshot so history shows the bad question as skipped.
    const snapshot = await api(`/api/quiz/${quizId}`,'GET');
    currentQuiz = snapshot.quiz;
    renderLeaderboard(snapshot.leaderboard);
    renderHistory();
    renderQuestion();
    fillStealTeams();
    renderAnswerPanel();
    populateAnswerControls();
    startTimer(secondsForDifficulty(currentQuestion.difficulty));
    toast('Bad question replaced. New question generated for ' + currentQuestion.assignedTeam);
  }catch(e){
    primarySubmitted = false;
    stealSubmitted = false;
    updateActionState();
    toast(e.message);
  }
}

function refreshFromSnapshot(snapshot){
  currentQuiz = snapshot.quiz;
  currentQuestion = currentQuiz.questions[currentQuiz.questions.length-1];
  primarySubmitted = currentQuestion.status !== 'ACTIVE';
  stealSubmitted = currentQuestion.status !== 'CENTRAL_POOL';
  renderLeaderboard(snapshot.leaderboard);
  renderHistory();
  fillStealTeams();
  renderQuestion();
  populateAnswerControls();
  if(currentQuestion.status === 'CENTRAL_POOL'){
    answerVisible = false; audienceAnswerVisible = false; renderAnswerPanel();
  }
  updateActionState();
}
function renderLeaderboard(teams){
  const sorted=[...teams].sort((a,b)=>b.score-a.score);
  document.getElementById('leaderboard').innerHTML = sorted.map((t,i)=>`<li>${i===0?'🏆 ':''}<b>${esc(t.name)}</b> — ${t.score} pts</li>`).join('');
}
function toggleHistoryPanel(){
  historyVisible = !historyVisible;
  const sec = document.getElementById('historySection');
  if(sec) sec.classList.toggle('hidden', !historyVisible);
}

function renderHistory(){
  const el = document.getElementById('history');
  if(!el || !currentQuiz) return;
  el.innerHTML = currentQuiz.questions.slice().reverse().map((q,i)=>`
    <div class="historyItem ${q.status === 'SKIPPED' ? 'skipped' : ''}">
      <b>${currentQuiz.questions.length-i}. ${esc(q.assignedTeam)}</b> | ${esc(q.difficulty)} | ${q.points} pts<br>
      Status: ${esc(q.status)}${q.winnerTeam ? ' | Points awarded to: '+esc(q.winnerTeam) : ''}<br>
      ${q.status === 'SKIPPED' ? '<span class="muted">Bad question regenerated; quota restored.</span>' : '<span class="muted">Correct answer hidden for screen-share safety.</span>'}
    </div>`).join('');
}
function fillStealTeams(){
  const sel=document.getElementById('stealTeam');
  if(!currentQuiz) return;
  const assigned = currentQuestion ? currentQuestion.assignedTeam : '';
  sel.innerHTML = currentQuiz.teams.filter(t=>t.name!==assigned).map(t=>`<option>${esc(t.name)}</option>`).join('');
}
function showWinnerScreen(){
  if(!currentQuiz) return toast('Create quiz first');
  const sorted=[...currentQuiz.teams].sort((a,b)=>b.score-a.score);
  const winner=sorted[0];
  document.getElementById('winnerName').innerText = winner ? winner.name : 'No Winner';
  document.getElementById('winnerScore').innerText = winner ? `${winner.score} points` : '';
  document.getElementById('finalLeaderboard').innerHTML = sorted.map((t,i)=>`<div class="finalRow"><b>${i+1}. ${esc(t.name)}</b><span>${t.score} pts</span></div>`).join('');
  document.getElementById('winnerOverlay').classList.remove('hidden');
}
function hideWinnerScreen(){ document.getElementById('winnerOverlay').classList.add('hidden'); }

function toggleQuestionSource(){
  const source = document.querySelector('input[name="questionSource"]:checked').value;
  document.getElementById('manualUploadPanel').classList.toggle('hidden', source !== 'manual');
  document.getElementById('modeBadge').innerText = source === 'manual' ? 'Manual JSON Mode' : 'LLM Mode';
}

async function loadManualQuestionFile(event){
  try{
    const file = event.target.files[0];
    if(!file){ return; }
    const text = await file.text();
    const parsed = JSON.parse(text);
    const list = Array.isArray(parsed) ? parsed : (Array.isArray(parsed.questions) ? parsed.questions : []);
    manualQuestions = list.map(normalizeManualQuestion).filter(q => q.questionText && q.correctOption && q.options);
    const counts = manualQuestions.reduce((acc,q)=>{ acc[q.difficulty]=(acc[q.difficulty]||0)+1; return acc; },{});
    document.getElementById('manualQuestionSummary').innerHTML = `Loaded <b>${manualQuestions.length}</b> questions from <b>${esc(file.name)}</b><br>SIMPLE: ${counts.SIMPLE||0}, MEDIUM: ${counts.MEDIUM||0}, COMPLEX: ${counts.COMPLEX||0}`;
    toast('Manual JSON loaded successfully');
  }catch(e){
    manualQuestions = [];
    document.getElementById('manualQuestionSummary').innerText = 'Invalid JSON file. Please check format.';
    toast('Invalid JSON: ' + e.message);
  }
}

function normalizeManualQuestion(q){
  const options = q.options || {};
  return {
    technology: q.topic || q.domain || q.technology || 'Manual',
    difficulty: (q.difficulty || 'SIMPLE').toString().toUpperCase(),
    questionType: q.questionType || 'CHOOSE_BEST',
    points: Number(q.points || 0),
    questionText: q.questionText || q.question || '',
    options: {
      A: options.A || options.a || q.optionA || '',
      B: options.B || options.b || q.optionB || '',
      C: options.C || options.c || q.optionC || '',
      D: options.D || options.d || q.optionD || ''
    },
    correctOption: (q.correctOption || q.correctAnswer || q.answer || '').toString().trim().substring(0,1).toUpperCase(),
    explanation: q.explanation || 'No explanation provided.'
  };
}

function applyCategoryTemplate(){
  const category = document.getElementById('quizCategory').value;
  const topicBox = document.getElementById('technologies');
  const audience = document.getElementById('audience');
  const templates = {
    'Automation Testing': {audience:'Automation testers', topics:['Selenium Java','Cucumber','API Automation','TestNG','Framework Design']},
    'Banking Functional': {audience:'Banking application functional testers', topics:['Retail Banking','Payments','Fund Transfer','Cards','Loans','KYC','AML','Core Banking','Reconciliation','SWIFT / ISO 20022']},
    'Agile / Scrum': {audience:'Scrum team members', topics:['Scrum Events','Product Backlog','Sprint Planning','Definition of Done','Agile Metrics']},
    'DevOps': {audience:'Engineering teams', topics:['CI/CD','GitHub Actions','Jenkins','Release Management','Monitoring']},
    'Cloud': {audience:'Cloud engineers and testers', topics:['Azure','AWS Basics','Networking','Identity and Access','Monitoring']},
    'Security': {audience:'Technology teams', topics:['Authentication','Authorization','OWASP Basics','Secrets Management','Vulnerability Management']},
    'General Knowledge': {audience:'General participants', topics:['India','Science','Technology','Sports','Current Affairs']},
    'Custom': {audience:'Quiz participants', topics:['Custom Topic 1','Custom Topic 2','Custom Topic 3']}
  };
  const t = templates[category] || templates['Custom'];
  audience.value = t.audience;
  topicBox.value = t.topics.join('\n');
}

function downloadSampleJson(){
  const sample = { questions: [
    { topic:'Selenium Java', difficulty:'SIMPLE', questionType:'CHOOSE_BEST', questionText:'Which Selenium wait is best for waiting until a button becomes clickable?', options:{A:'Thread.sleep()',B:'WebDriverWait with elementToBeClickable',C:'driver.close()',D:'Implicit wait of 30 minutes'}, correctOption:'B', explanation:'WebDriverWait with elementToBeClickable waits for the actual condition and reduces flaky tests.' },
    { topic:'Fund Transfer', difficulty:'MEDIUM', questionType:'CHOOSE_BEST', questionText:'A customer initiates a fund transfer but the beneficiary account is closed. What is the best expected system behavior?', options:{A:'Debit the customer and mark transaction successful',B:'Reject before debit or reverse if already debited',C:'Keep the transaction pending forever',D:'Ignore beneficiary status'}, correctOption:'B', explanation:'A transfer to a closed beneficiary account should not complete; the system should reject or reverse safely.' },
    { topic:'Agile Scrum', difficulty:'COMPLEX', questionType:'CHOOSE_BEST', questionText:'During Sprint Planning, the team finds a story is too large and unclear. What is the best action?', options:{A:'Accept it as-is to save time',B:'Split/refine the story, clarify acceptance criteria, and estimate again',C:'Move it directly to Done',D:'Ignore risks until production'}, correctOption:'B', explanation:'Large unclear stories should be refined into testable pieces with clear acceptance criteria before commitment.' }
  ]};
  const blob = new Blob([JSON.stringify(sample, null, 2)], {type:'application/json'});
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = 'astra-sample-questions.json'; a.click();
  URL.revokeObjectURL(url);
}
