'use strict';

/**
 * Local TCP bridge for Vibium's stdio MCP server.
 *
 * Why it exists:
 * Vibium MCP uses JSON-RPC over stdio. A Java JAR cannot attach to the stdin/stdout
 * of a Vibium process that was started manually in another terminal. This bridge is
 * started manually and exposes a localhost TCP socket. For each Java connection it
 * starts one Vibium MCP child process and forwards JSON lines in both directions.
 */

const fs = require('fs');
const net = require('net');
const path = require('path');
const { spawn, spawnSync } = require('child_process');

const bridgeDir = __dirname;
const configPath = process.env.ITPS_MCP_BRIDGE_CONFIG
  ? path.resolve(process.env.ITPS_MCP_BRIDGE_CONFIG)
  : path.join(bridgeDir, 'local-mcp-config.json');

function fail(message) {
  console.error(`[ITPS MCP BRIDGE] ERROR: ${message}`);
  process.exit(1);
}

function loadConfig() {
  if (!fs.existsSync(configPath)) fail(`Configuration file not found: ${configPath}`);
  try {
    return JSON.parse(fs.readFileSync(configPath, 'utf8'));
  } catch (error) {
    fail(`Invalid JSON in ${configPath}: ${error.message}`);
  }
}

function resolveMaybeRelative(value, baseDir) {
  if (!value) return value;
  if (path.isAbsolute(value)) return value;
  // Bare commands such as vibium.cmd, vibium, node, or npx are resolved from PATH.
  if (!value.includes('/') && !value.includes('\\')) return value;
  return path.resolve(baseDir, value);
}

function commandExists(command) {
  if (!command) return false;
  if (path.isAbsolute(command) || command.includes('/') || command.includes('\\')) return fs.existsSync(command);
  const lookup = process.platform === 'win32' ? 'where' : 'which';
  return spawnSync(lookup, [command], { stdio: 'ignore', shell: process.platform === 'win32' }).status === 0;
}

const config = loadConfig();
const configDir = path.dirname(configPath);
const host = String(process.env.ITPS_MCP_HOST || config.host || '127.0.0.1');
const port = Number(process.env.ITPS_MCP_PORT || config.port || 8765);
const configuredCommand = process.env.VIBIUM_MCP_COMMAND
  || (process.platform === 'win32' ? config.windowsCommand : config.macCommand)
  || config.command;

function discoverCommand() {
  const names = process.platform === 'win32'
    ? ['vibium.cmd', 'vibe-check.cmd']
    : ['vibium', 'vibe-check'];
  const relativeCandidates = process.platform === 'win32'
    ? [
        '../vibium-portable/node_modules/.bin/vibium.cmd',
        '../vibium-portable/node_modules/.bin/vibe-check.cmd',
        '../node_modules/.bin/vibium.cmd',
        '../node_modules/.bin/vibe-check.cmd',
        '../vibium.cmd',
        '../vibe-check.cmd'
      ]
    : [
        '../vibium-portable/node_modules/.bin/vibium',
        '../vibium-portable/node_modules/.bin/vibe-check',
        '../node_modules/.bin/vibium',
        '../node_modules/.bin/vibe-check',
        '../vibium',
        '../vibe-check'
      ];
  const candidates = [];
  if (configuredCommand) candidates.push(resolveMaybeRelative(configuredCommand, configDir));
  relativeCandidates.forEach(value => candidates.push(resolveMaybeRelative(value, configDir)));
  names.forEach(value => candidates.push(value));
  return candidates.find(commandExists) || candidates[0];
}

const command = discoverCommand();
const baseArgs = Array.isArray(config.args) ? config.args.map(String) : ['mcp'];
const cwd = resolveMaybeRelative(config.workingDirectory || '.', configDir);
const skipBrowserDownload = config.skipBrowserDownload !== false;
const maxClients = Number(process.env.ITPS_MCP_MAX_CLIENTS || config.maxClients || 4);
const logDir = process.env.ITPS_MCP_LOG_DIR
  ? path.resolve(process.env.ITPS_MCP_LOG_DIR)
  : path.join(bridgeDir, 'logs');

if (!Number.isInteger(port) || port < 1 || port > 65535) fail(`Invalid port: ${port}`);
if (!Number.isInteger(maxClients) || maxClients < 1 || maxClients > 16) fail(`Invalid maxClients: ${maxClients}`);
if (!commandExists(command)) {
  fail(`Vibium command not found: ${command}\nRun the supplied install-vibium script, or edit ${configPath} and set windowsCommand/macCommand to the command that works manually.`);
}
fs.mkdirSync(logDir, { recursive: true });
fs.mkdirSync(path.join(cwd, 'mcp-screenshots'), { recursive: true });

const sessions = new Map();
let nextSessionId = 1;
let shuttingDown = false;

function timestamp() {
  return new Date().toISOString();
}

function appendLog(text) {
  const logFile = path.join(logDir, `local-mcp-${new Date().toISOString().slice(0, 10)}.log`);
  fs.appendFileSync(logFile, `${timestamp()} ${text}\n`, 'utf8');
}

function stopChild(child) {
  if (!child || child.killed) return;
  try {
    if (process.platform === 'win32' && child.pid) {
      spawnSync('taskkill', ['/PID', String(child.pid), '/T', '/F'], { stdio: 'ignore', windowsHide: true });
    } else if (child.pid) {
      child.kill('SIGTERM');
      setTimeout(() => {
        try { if (!child.killed) child.kill('SIGKILL'); } catch (_) { }
      }, 1500).unref();
    }
  } catch (_) { }
}

function sessionArgs(sessionId) {
  const args = [...baseArgs];
  const screenshotDir = path.join(cwd, 'mcp-screenshots', `session-${sessionId}`);
  fs.mkdirSync(screenshotDir, { recursive: true });
  const index = args.findIndex(value => String(value).toLowerCase() === '--screenshot-dir');
  if (index >= 0) {
    if (index + 1 < args.length) args[index + 1] = screenshotDir;
    else args.push(screenshotDir);
  } else {
    args.push('--screenshot-dir', screenshotDir);
  }
  return args;
}

const server = net.createServer((socket) => {
  const remote = `${socket.remoteAddress || 'local'}:${socket.remotePort || ''}`;
  if (sessions.size >= maxClients) {
    appendLog(`Rejected client ${remote}; active=${sessions.size}, maxClients=${maxClients}.`);
    socket.end(`ITPS_BRIDGE_BUSY: ${sessions.size} MCP clients are active; maximum is ${maxClients}\n`);
    return;
  }

  const sessionId = nextSessionId++;
  const args = sessionArgs(sessionId);

  const env = { ...process.env };
  if (skipBrowserDownload) env.VIBIUM_SKIP_BROWSER_DOWNLOAD = '1';

  console.log(`[ITPS MCP BRIDGE] Session ${sessionId} connected (${remote}). Starting Vibium MCP...`);
  appendLog(`Session ${sessionId} connected ${remote}; spawning ${command} ${args.join(' ')}`);

  const child = spawn(command, args, {
    cwd,
    env,
    stdio: ['pipe', 'pipe', 'pipe'],
    shell: process.platform === 'win32',
    windowsHide: false
  });
  sessions.set(socket, { sessionId, socket, child });

  socket.setKeepAlive(true);
  socket.setNoDelay(true);
  socket.pipe(child.stdin);
  child.stdout.pipe(socket);

  child.stderr.on('data', (chunk) => {
    const text = chunk.toString('utf8').replace(/\s+$/, '');
    if (!text) return;
    console.error(`[VIBIUM] ${text}`);
    appendLog(`[SESSION ${sessionId} VIBIUM STDERR] ${text}`);
  });

  child.on('error', (error) => {
    console.error(`[ITPS MCP BRIDGE] Unable to start Vibium MCP: ${error.message}`);
    appendLog(`Session ${sessionId} child process error: ${error.stack || error.message}`);
    socket.destroy(error);
  });

  child.on('exit', (code, signal) => {
    appendLog(`Session ${sessionId} Vibium MCP exited code=${code} signal=${signal || ''}`);
    if (!socket.destroyed) socket.end();
    sessions.delete(socket);
    console.log(`[ITPS MCP BRIDGE] Session ${sessionId} ended. Active sessions: ${sessions.size}/${maxClients}.`);
  });

  socket.on('error', (error) => appendLog(`Session ${sessionId} client socket error: ${error.message}`));
  socket.on('close', () => {
    appendLog(`Session ${sessionId} client disconnected ${remote}`);
    try { child.stdin.end(); } catch (_) { }
    stopChild(child);
    sessions.delete(socket);
  });
});

server.on('error', (error) => {
  if (error.code === 'EADDRINUSE') fail(`Port ${host}:${port} is already in use. Close the old bridge or change the port in local-mcp-config.json and application-local.properties.`);
  fail(error.stack || error.message);
});

server.listen(port, host, () => {
  console.log('============================================================');
  console.log(' ITPS LOCAL VIBIUM MCP BRIDGE');
  console.log('============================================================');
  console.log(` Listening : ${host}:${port}`);
  console.log(` Vibium    : ${command}`);
  console.log(` Arguments : ${baseArgs.join(' ')}`);
  console.log(` Max clients: ${maxClients}`);
  console.log(` Config    : ${configPath}`);
  console.log(' Status    : READY - keep this window open');
  console.log(' Next      : start the framework JAR, then click Run Tests');
  console.log('============================================================');
  appendLog(`Bridge listening on ${host}:${port}; command=${command}; args=${baseArgs.join(' ')}; maxClients=${maxClients}`);
});

function shutdown(signal) {
  if (shuttingDown) return;
  shuttingDown = true;
  console.log(`\n[ITPS MCP BRIDGE] ${signal} received. Closing...`);
  for (const session of sessions.values()) {
    try { session.socket.destroy(); } catch (_) { }
    stopChild(session.child);
  }
  sessions.clear();
  server.close(() => process.exit(0));
  setTimeout(() => process.exit(0), 2000).unref();
}

process.on('SIGINT', () => shutdown('SIGINT'));
process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('uncaughtException', (error) => {
  appendLog(`Uncaught exception: ${error.stack || error.message}`);
  console.error(error);
});
