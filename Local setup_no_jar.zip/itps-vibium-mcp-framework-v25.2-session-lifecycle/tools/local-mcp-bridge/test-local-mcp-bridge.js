'use strict';

/** Self-contained smoke test for isolated parallel bridge sessions. Uses only Node built-ins. */
const fs = require('fs');
const net = require('net');
const os = require('os');
const path = require('path');
const { spawn } = require('child_process');

const bridge = path.join(__dirname, 'local-mcp-bridge.js');
const temporary = fs.mkdtempSync(path.join(os.tmpdir(), 'itps-mcp-bridge-test-'));
let bridgeProcess;
const sockets = [];

function fail(message) {
  throw new Error(message);
}

function withTimeout(promise, milliseconds, label) {
  return Promise.race([
    promise,
    new Promise((_, reject) => setTimeout(() => reject(new Error(`${label} timed out`)), milliseconds))
  ]);
}

function freePort() {
  return new Promise((resolve, reject) => {
    const server = net.createServer();
    server.once('error', reject);
    server.listen(0, '127.0.0.1', () => {
      const port = server.address().port;
      server.close(error => error ? reject(error) : resolve(port));
    });
  });
}

function connect(port) {
  return new Promise((resolve, reject) => {
    const socket = net.createConnection({ host: '127.0.0.1', port });
    sockets.push(socket);
    socket.once('connect', () => resolve(socket));
    socket.once('error', reject);
  });
}

function nextData(socket) {
  return new Promise((resolve, reject) => {
    socket.once('data', chunk => resolve(chunk.toString('utf8')));
    socket.once('error', reject);
  });
}

async function main() {
  const port = await freePort();
  const fakeMcp = path.join(temporary, 'fake-mcp.js');
  const configPath = path.join(temporary, 'bridge-config.json');
  fs.writeFileSync(fakeMcp, "'use strict'; process.stdin.pipe(process.stdout);\n", 'utf8');
  fs.writeFileSync(configPath, JSON.stringify({
    host: '127.0.0.1',
    port,
    maxClients: 2,
    windowsCommand: process.execPath,
    macCommand: process.execPath,
    args: [fakeMcp],
    workingDirectory: temporary,
    skipBrowserDownload: true
  }, null, 2), 'utf8');

  bridgeProcess = spawn(process.execPath, [bridge], {
    env: {
      ...process.env,
      ITPS_MCP_BRIDGE_CONFIG: configPath,
      ITPS_MCP_LOG_DIR: path.join(temporary, 'logs')
    },
    stdio: ['ignore', 'pipe', 'pipe']
  });
  let startup = '';
  bridgeProcess.stdout.on('data', chunk => { startup += chunk.toString('utf8'); });
  bridgeProcess.stderr.on('data', chunk => { startup += chunk.toString('utf8'); });
  await withTimeout(new Promise((resolve, reject) => {
    const poll = setInterval(() => {
      if (startup.includes('READY - keep this window open')) {
        clearInterval(poll);
        resolve();
      } else if (bridgeProcess.exitCode !== null) {
        clearInterval(poll);
        reject(new Error(`Bridge exited during startup: ${startup}`));
      }
    }, 25);
  }), 5_000, 'bridge startup');

  const first = await withTimeout(connect(port), 2_000, 'first connection');
  const second = await withTimeout(connect(port), 2_000, 'second connection');
  const firstResponse = nextData(first);
  const secondResponse = nextData(second);
  first.write('worker-one\n');
  second.write('worker-two\n');
  if (!(await withTimeout(firstResponse, 2_000, 'first response')).includes('worker-one')) fail('First session did not echo independently.');
  if (!(await withTimeout(secondResponse, 2_000, 'second response')).includes('worker-two')) fail('Second session did not echo independently.');

  const third = await withTimeout(connect(port), 2_000, 'third connection');
  const busy = await withTimeout(nextData(third), 2_000, 'capacity response');
  if (!busy.includes('ITPS_BRIDGE_BUSY')) fail('Bridge did not enforce maxClients.');

  console.log('Parallel bridge smoke test passed: 2 isolated sessions and capacity enforcement verified.');
}

main().catch(error => {
  console.error(error.stack || error.message);
  process.exitCode = 1;
}).finally(() => {
  for (const socket of sockets) {
    try { socket.destroy(); } catch (_) { }
  }
  if (bridgeProcess && bridgeProcess.exitCode === null) bridgeProcess.kill('SIGTERM');
  fs.rmSync(temporary, { recursive: true, force: true });
});
