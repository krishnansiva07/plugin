# V25.1 External Local MCP Changes

- Added `external-tcp` MCP mode and made it the default.
- Added a manually started Node.js localhost bridge on `127.0.0.1:8765`.
- The bridge starts one Vibium stdio MCP child per Java connection and remains ready after the run.
- Updated normal test execution and UI recorder to use the external bridge.
- Preserved `process-stdio` as a fallback mode.
- Added Windows and macOS startup/build scripts.
- Added clear connection failure messages and MCP transport diagnostics.
- Added local bridge logs and single-client protection.
- No changes were made to test-step planning, locator priority, dropdown logic, LLM healing, reporting, multi-sheet selection, or browser actions.
