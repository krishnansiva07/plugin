# ITPS VIBIUM MCP Framework V25.2 — Windows and macOS Guide

This guide covers the Java UI, localhost MCP bridge, Vibium browser service, multi-sheet Excel/JSON execution, session lifecycle, parallel workers, reports and optional UI recorder.

## 1. Prerequisites

- Java 17 or later
- Node.js 20 or later with npm
- Maven 3.9 or later only for source builds
- Network access for installation and the configured LLM, or an approved offline Vibium/browser cache

Verify with `java -version`, `node -v`, `npm -v` and, when building, `mvn -version`.

## 2. Extract the framework

Recommended:

- Windows: `C:\itps\itps-vibium-mcp-framework-v25.2`
- macOS: `~/itps/itps-vibium-mcp-framework-v25.2`

Use a writable local folder. Do not run directly inside the ZIP.

## 3. Install Vibium once

Online Windows setup:

```text
install-vibium-windows.cmd
```

Online macOS setup:

```bash
chmod +x install-vibium-mac.sh
./install-vibium-mac.sh
```

The scripts install the pinned dependency from `tools/vibium-portable/package.json` and verify Managed Chrome for Testing.

For an offline environment, copy a known-working portable folder so one of these exists:

```text
tools\vibium-portable\node_modules\.bin\vibium.cmd
tools/vibium-portable/node_modules/.bin/vibium
```

Edit `tools/local-mcp-bridge/local-mcp-config.json` only if the command is elsewhere.

## 4. Start the local bridge

Windows:

```text
start-local-mcp-windows.cmd
```

macOS:

```bash
chmod +x start-local-mcp-mac.sh tools/local-mcp-bridge/start-local-mcp-mac.sh
./start-local-mcp-mac.sh
```

Keep this terminal/window open. It should show `READY` at `127.0.0.1:8765` with `Max clients: 4`.

## 5. Start the framework

The ZIP includes a built executable JAR under `target`.

Windows:

```text
start-framework-jar-windows.cmd
```

macOS, in a second terminal:

```bash
chmod +x start-framework-jar-mac.sh
./start-framework-jar-mac.sh
```

Open `http://localhost:8090`.

## 6. Build from source when needed

Windows:

```text
build-windows.cmd
```

macOS/Linux:

```bash
chmod +x build-mac.sh
./build-mac.sh
```

Or run directly from source after starting the bridge:

```text
mvn clean test
mvn spring-boot:run
```

## 7. Excel/JSON execution

1. Upload `.xlsx`, `.xls` or `.json`.
2. For a workbook, select one or more worksheets.
3. Enter LLM settings and token.
4. Select the browser and execution options.
5. Click **Run tests**.

Supported Excel columns:

| Column | Required | Purpose |
|---|---:|---|
| Run | No | `true`, `yes`, `y`, `1`, `run`, `execute` or `enabled` runs the row |
| Id | Recommended | Test ID |
| Name | Recommended | Test name |
| Url | No | Absolute or App-Base-relative URL |
| Steps | Yes | New-line or `|` separated instructions |
| Expected | No | Final expected result |
| TestDataJson / TestData / Data | No | JSON variables |
| data.&lt;key&gt; | No | Individual variables |

Selected sheets are combined. Duplicate IDs are made unique and the source worksheet is retained in reports.

## 8. One browser and one manual authentication

Use:

- **Sequential · one browser**
- headed mode
- **Return to Home after every passed or failed test**
- a Home URL plus reliable readiness selector/text
- enough manual authentication timeout

Click Run, then manually complete the Windows client-certificate and Smart Card PIN dialogs. The same browser is reused for the run. After every scenario, Home recovery occurs in a `finally`-style lifecycle even when the test failed.

## 9. HTTPS and popup options

- **Handle Chrome HTTPS warning** automates Chromium's invalid-certificate **Advanced → Proceed** interstitial.
- It cannot bypass an HSTS/policy page that has no Proceed link.
- **Auto-accept browser JS dialogs** handles page `alert`, `confirm` and `prompt` calls triggered after its page shim is installed.
- Explicit browser-dialog accept/dismiss steps use Vibium tools when available.
- Windows certificate and Smart Card/PIN windows remain manual because they are outside browser DOM automation.

## 10. Cookie value-only replacement

Enable the cookie option and enter an existing cookie name plus new value. The framework:

1. opens the application;
2. reads the existing applicable cookie;
3. replaces only the value;
4. verifies metadata is unchanged;
5. attempts rollback and stops if verification fails;
6. redacts cookie/JWT values from framework diagnostics.

A cookie must already exist. Current Vibium cannot safely recreate a normal HttpOnly cookie with all attributes, so the guard rejects that operation without modifying it.

## 11. Parallel execution

Choose 1–4 isolated browsers. Every worker owns an MCP process, browser and sequential scenario queue. Results are restored to input order.

Each worker may need its own certificate/PIN intervention. The bridge capacity must be at least the worker count; stop the recorder before using all four slots.

## 12. Reports

Every execution writes:

```text
target/itps-vibium-runs/<RUN-ID>/
```

Outputs include HTML, Excel and JSON reports; screenshots ZIP; element inventories; MCP tool manifest; redacted transcript/log; and per-worker diagnostics in parallel mode. Source sheet, worker and Home reset are included in reports.

## 13. Optional recorder

1. Enable **Record UI actions and generate Excel steps**.
2. Enter the complete application URL.
3. Select a headed browser.
4. Start recording and perform actions.
5. Stop, review/delete actions, then download Excel/JSON.

Stop the recorder before a test run when bridge capacity is needed. Recorder page-JavaScript boundaries still include cross-origin frames, closed shadow roots and OS-native windows.

## 14. Troubleshooting

### Bridge connection refused

Start the bridge first and match port `8765` in both configuration files.

### Vibium command not found

Run the install script or copy/configure the approved portable Vibium folder.

### Browser not installed

Run `install-vibium-windows.cmd` / `install-vibium-mac.sh`, or provide the approved browser cache. `skipBrowserDownload=true` assumes that cache already exists during normal runs.

### Bridge busy

Reduce parallel workers, stop the recorder/other run, or increase `maxClients` within the supported local limit.

### Home reset failure

Verify Home URL, selector/text and authentication timeout. Remaining tests are intentionally not executed on that unhealthy worker.

### Cookie replacement failure

Verify the cookie already exists and is unique for the current URL. If it is HttpOnly, use normal login or a Vibium build that exposes every required cookie attribute.

### Security warning has no Continue button

Trust/install the correct site certificate. HSTS and enterprise policy are intentionally not bypassed.

For configuration examples and exact folder layout, see `LOCAL_MCP_SETUP.md`. For all code-level changes and boundaries, see `V25_2_CHANGE_NOTES.md`.
