# ITPS VIBIUM Framework V25.2 — Session Lifecycle and Parallel Execution

## Delivered changes

### Single-browser sequential execution

- Sequential remains the default and uses one MCP connection and one browser for the complete run.
- The browser is not restarted between scenarios, so a manually completed Windows certificate or Smart Card PIN flow can be reused for the remaining tests.
- All new lifecycle options default to off. With those options off, V25.1 navigation and timeout behavior remains unchanged.

### Return Home after every test

- Optional **Return to Home** runs after every passed or failed scenario, including a scenario that throws unexpectedly.
- Home URL resolution order is: explicit Home URL, App Base URL, then the first absolute scenario URL assigned to the worker.
- Optional readiness checks support either a CSS selector or visible text. Without either, document readiness is checked.
- Extra tabs/pages can be closed before Home navigation.
- If Home recovery fails, that worker stops. Remaining scenarios assigned to it are marked `FAILED_INFRASTRUCTURE` instead of running against an unknown page state.
- Reset status and message are included in the UI, JSON, HTML and Excel reports.

### Cookie value-only replacement

- The UI accepts an existing cookie name and a new value.
- The framework navigates to the application first, finds exactly one applicable cookie, and replaces only its value.
- Domain, path, Secure, HttpOnly, SameSite, expiry, host-only state, Partitioned and Priority metadata are compared before and after the change.
- If verification fails, rollback to the original value is attempted and the run stops before test execution.
- Cookie reads/writes are marked sensitive. The supplied value, existing value and JWT-shaped values are redacted from MCP transcripts, process logs and lifecycle errors.
- A non-HttpOnly cookie is replaced in page context while reapplying its original attributes.
- An HttpOnly cookie is changed only when the installed Vibium `browser_set_cookie` schema can represent every original attribute. Otherwise the framework fails safely without weakening the cookie. Vibium 26.5.31 exposes only name, value, domain and path, so a typical HttpOnly session cookie is intentionally rejected by this guard.

### Browser and native popups

- Optional automatic acceptance is available for page JavaScript `alert`, `confirm` and `prompt` dialogs. It installs a pre-click page shim to avoid the known blocked-click/dialog ordering problem.
- Explicit steps such as `Accept browser dialog` and `Dismiss browser dialog` use Vibium's dedicated dialog tools when exposed.
- Windows certificate selection, Smart Card middleware and PIN dialogs are OS-native windows. They remain manual and must be completed by the operator.

### HTTPS security warning

- Optional **Handle Chrome HTTPS warning** checks for Chromium's invalid-certificate interstitial, opens **Advanced**, and selects **Continue/Proceed**.
- The framework first uses a browser-launch insecure-certificate capability if a future Vibium schema exposes one; otherwise it uses the interstitial DOM.
- HSTS-blocked pages with no Proceed link fail with a clear infrastructure error.
- This option does not automate the Windows certificate picker or Smart Card PIN window.

### Optional parallel execution

- `SEQUENTIAL` remains the compatibility default.
- `PARALLEL` supports 1–4 isolated workers. Each worker owns its own MCP process, browser, session lifecycle and scenario queue.
- Scenarios are distributed round-robin and displayed in original input order when the run finishes.
- Each worker still runs its assigned tests sequentially and performs Home recovery after each test.
- Screenshots, element inventories, MCP diagnostics and worker identifiers are collision-safe.
- Each parallel browser may require separate manual certificate/PIN intervention.

### Local MCP bridge

- The bridge now supports up to four simultaneous isolated MCP sessions instead of rejecting every second connection.
- Each bridge session has a separate Vibium child process and MCP screenshot directory.
- Capacity is controlled by `maxClients` in `local-mcp-config.json` or `ITPS_MCP_MAX_CLIENTS`.
- A self-contained bridge smoke test verifies two concurrent isolated sessions plus capacity enforcement.

### Multi-sheet and reporting

- Existing multi-sheet selection is preserved.
- Duplicate test IDs across selected sheets are made unique and source worksheet names remain attached to scenarios.
- UI, HTML, JSON and Excel outputs now include source sheet, worker and Home reset result.

### Setup and security

- The framework web server and MCP bridge bind to `127.0.0.1` by default.
- Vibium 26.5.31 is pinned under `tools/vibium-portable/package.json`.
- One-time Windows and macOS Vibium installation scripts are included.
- Start scripts discover the packaged V25.2 JAR under `target` without a hard-coded filename.

## Recommended UI configuration for one manual authentication

1. Select **Sequential · one browser**.
2. Keep **Headless** off.
3. Enable **Return to Home after every passed or failed test**.
4. Enter the application Home URL and, preferably, a Home readiness selector or text.
5. Set the manual authentication timeout long enough to select the certificate and enter the Smart Card PIN.
6. Enable **Handle Chrome HTTPS warning** only when the launch displays the Chromium Advanced/Proceed page.
7. Enable cookie replacement only when an existing cookie is already present at the Home URL.
8. Start the run and complete the native certificate/PIN prompts once in the launched browser.

## Validation commands

```text
mvn clean test
mvn clean package
node --check src/main/resources/static/app.js
node --check tools/local-mcp-bridge/local-mcp-bridge.js
node tools/local-mcp-bridge/test-local-mcp-bridge.js
```

Environment-specific end-to-end validation still requires the real application URL, certificate, Smart Card middleware, PIN and approved LLM endpoint. Those credentials are never included in this package.
