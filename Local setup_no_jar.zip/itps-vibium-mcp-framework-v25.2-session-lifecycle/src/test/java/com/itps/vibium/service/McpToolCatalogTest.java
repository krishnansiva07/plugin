package com.itps.vibium.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.itps.vibium.model.McpTool;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

class McpToolCatalogTest {
    private final ObjectMapper mapper = new ObjectMapper();

    @Test
    void startAndStopNeverMistakeTraceRecordingToolsForBrowserLifecycle() {
        McpToolCatalog catalog = new McpToolCatalog(List.of(
                tool("browser_record_start", "Start trace recording"),
                tool("browser_record_stop", "Stop trace recording"),
                tool("launch_browser", "Launch browser"),
                tool("close_browser", "Close browser")
        ));

        assertThat(catalog.startTool()).isPresent();
        assertThat(catalog.stopTool()).isPresent();
        assertThat(catalog.startTool().orElseThrow().getName()).isEqualTo("launch_browser");
        assertThat(catalog.stopTool().orElseThrow().getName()).isEqualTo("close_browser");
    }

    @Test
    void exactLifecycleToolsRemainFirstPriority() {
        McpToolCatalog catalog = new McpToolCatalog(List.of(
                tool("browser_record_start", "trace"),
                tool("browser_start", "real start"),
                tool("browser_stop", "real stop")
        ));

        assertThat(catalog.startTool().orElseThrow().getName()).isEqualTo("browser_start");
        assertThat(catalog.stopTool().orElseThrow().getName()).isEqualTo("browser_stop");
    }

    @Test
    void discoversSessionToolsAndUsesExactSchemaProperties() {
        McpTool setCookie = toolWithProperties("browser_set_cookie", "name", "value", "domain", "path");
        McpToolCatalog catalog = new McpToolCatalog(List.of(
                setCookie,
                tool("browser_get_cookies", "cookies"),
                tool("browser_dialog_accept", "dialog"),
                tool("browser_list_pages", "pages")
        ));

        assertThat(catalog.setCookieTool().orElseThrow()).isSameAs(setCookie);
        assertThat(catalog.getCookiesTool()).isPresent();
        assertThat(catalog.dialogAcceptTool()).isPresent();
        assertThat(catalog.listPagesTool()).isPresent();
        assertThat(catalog.hasInputProperty(setCookie, "domain")).isTrue();
        assertThat(catalog.hasInputProperty(setCookie, "secure")).isFalse();
        assertThat(catalog.firstInputProperty(setCookie, "url", "domain", "path")).contains("domain");
    }

    private McpTool tool(String name, String description) {
        return new McpTool(name, description, mapper.createObjectNode());
    }

    private McpTool toolWithProperties(String name, String... properties) {
        var schema = mapper.createObjectNode();
        var values = schema.putObject("properties");
        for (String property : properties) values.putObject(property).put("type", "string");
        return new McpTool(name, name, schema);
    }
}
