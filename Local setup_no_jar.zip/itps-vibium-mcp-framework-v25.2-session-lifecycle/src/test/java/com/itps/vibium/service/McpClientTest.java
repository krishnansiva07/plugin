package com.itps.vibium.service;

import org.junit.jupiter.api.Test;

import java.time.Duration;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

class McpClientTest {

    @Test
    void redactsRegisteredSecretsJwtAndAuthorizationValues() {
        McpClient client = new McpClient("unused", List.of(), Duration.ofSeconds(1), true);
        String registered = "registered-cookie-value";
        String jwt = "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJ1c2VyLTEyMzQ1In0.signature12345";
        client.registerSecret(registered);

        String redacted = client.redactText("cookie=" + registered
                + " token=" + jwt
                + " Authorization: Bearer opaque-access-token"
                + " JSON=\"token\":\"plain-token\"");

        assertThat(redacted)
                .doesNotContain(registered)
                .doesNotContain(jwt)
                .doesNotContain("opaque-access-token")
                .doesNotContain("plain-token")
                .contains("REDACTED");
    }
}
