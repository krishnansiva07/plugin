package com.itps.vibium.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.itps.vibium.model.RunConfig;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

class BrowserSessionLifecycleTest {
    private final ObjectMapper mapper = new ObjectMapper();
    private final BrowserSessionLifecycle lifecycle = new BrowserSessionLifecycle(mapper);

    @Test
    void keepsLegacyLifecycleInactiveByDefault() {
        RunConfig config = new RunConfig();
        assertThat(lifecycle.requiresBootstrap(config)).isFalse();

        config.setResetToHome(true);
        assertThat(lifecycle.requiresBootstrap(config)).isTrue();
    }

    @Test
    void cookieAssignmentChangesOnlyValueAndReappliesAttributes() {
        BrowserSessionLifecycle.CookieSnapshot cookie = new BrowserSessionLifecycle.CookieSnapshot(
                "SESSION", "old", ".example.test", "/app", true, false,
                "lax", 1_893_456_000L, false, true, "High");

        String assignment = lifecycle.cookieAssignment(cookie, "new-value", "https://example.test/app/home");

        assertThat(assignment)
                .startsWith("SESSION=new-value")
                .contains("; Path=/app")
                .contains("; Domain=.example.test")
                .contains("; Secure")
                .contains("; SameSite=Lax")
                .contains("; Expires=")
                .contains("; Partitioned")
                .contains("; Priority=High")
                .doesNotContain("old");
    }

    @Test
    void hostOnlyCookieNeverAddsDomainAttribute() {
        BrowserSessionLifecycle.CookieSnapshot cookie = new BrowserSessionLifecycle.CookieSnapshot(
                "SESSION", "old", "example.test", "/", true, false,
                "strict", null, true, false, "");

        assertThat(lifecycle.cookieAssignment(cookie, "new", "https://example.test/"))
                .doesNotContain("Domain=")
                .contains("Path=/", "Secure", "SameSite=Strict");
    }

    @Test
    void valueChangeDoesNotCountAsMetadataChange() {
        BrowserSessionLifecycle.CookieSnapshot before = new BrowserSessionLifecycle.CookieSnapshot(
                "SESSION", "old", "example.test", "/", true, false,
                "lax", null, true, false, "Medium");
        BrowserSessionLifecycle.CookieSnapshot after = new BrowserSessionLifecycle.CookieSnapshot(
                "SESSION", "new", "example.test", "/", true, false,
                "lax", null, true, false, "medium");

        assertThat(lifecycle.metadataDifferences(before, after)).isEmpty();

        BrowserSessionLifecycle.CookieSnapshot weakened = new BrowserSessionLifecycle.CookieSnapshot(
                "SESSION", "new", "example.test", "/", false, false,
                "lax", null, true, false, "medium");
        assertThat(lifecycle.metadataDifferences(before, weakened)).containsExactly("Secure");
    }

    @Test
    void parsesNestedCookieResultsAndHonorsCookiePathBoundary() throws Exception {
        var raw = mapper.readTree("""
                {"content":[{"type":"text","text":"[{\\"name\\":\\"SESSION\\",\\"value\\":\\"abc\\",\\"domain\\":\\"example.test\\",\\"path\\":\\"/app\\",\\"secure\\":true,\\"httpOnly\\":false,\\"sameSite\\":\\"lax\\",\\"hostOnly\\":true}]"}]}
                """);

        List<BrowserSessionLifecycle.CookieSnapshot> cookies = lifecycle.extractCookies(raw);

        assertThat(cookies).hasSize(1);
        assertThat(cookies.get(0).name()).isEqualTo("SESSION");
        assertThat(lifecycle.cookieAppliesTo(cookies.get(0), "https://example.test/app/home")).isTrue();
        assertThat(lifecycle.cookieAppliesTo(cookies.get(0), "https://example.test/application")).isFalse();
    }
}
