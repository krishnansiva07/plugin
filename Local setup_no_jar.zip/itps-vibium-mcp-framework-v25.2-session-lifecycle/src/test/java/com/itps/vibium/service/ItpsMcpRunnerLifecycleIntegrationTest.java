package com.itps.vibium.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.itps.vibium.model.RunConfig;
import com.itps.vibium.model.RunStatus;
import com.itps.vibium.model.TestScenario;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import static org.assertj.core.api.Assertions.assertThat;

class ItpsMcpRunnerLifecycleIntegrationTest {

    @Test
    void parallelWorkersRemainIsolatedAndResetHomeAfterEveryScenario(@TempDir Path output) throws Exception {
        try (FakeMcpServer mcp = new FakeMcpServer()) {
            ItpsMcpRunner runner = new ItpsMcpRunner(
                    new LlmClient(), new ReportService(), new RunStore(), output.toString(), 5, true);
            RunConfig config = new RunConfig();
            config.setRunId("RUN-PARALLEL-TEST");
            config.setMcpMode("external-tcp");
            config.setMcpHost("127.0.0.1");
            config.setMcpPort(mcp.port());
            config.setMcpConnectTimeoutSeconds(2);
            config.setExecutionMode("PARALLEL");
            config.setParallelBrowserCount(2);
            config.setResetToHome(true);
            config.setHomeUrl("https://example.test/home");
            config.setCloseExtraPagesOnReset(true);
            config.setManualAuthTimeoutSeconds(30);
            config.setRetryDelayMs(100);
            config.setScreenshotMode("NEVER");
            config.setUseLlm(false);

            List<TestScenario> scenarios = new ArrayList<>();
            for (int index = 1; index <= 4; index++) {
                TestScenario scenario = new TestScenario();
                scenario.setId("TC-" + index);
                scenario.setName("Scenario " + index);
                scenario.setUrl("https://example.test/test-" + index);
                scenario.setData(new LinkedHashMap<>(Map.of("sourceSheet", index <= 2 ? "Smoke" : "Regression")));
                scenarios.add(scenario);
            }
            RunStatus status = new RunStatus();
            status.setRunId(config.getRunId());

            runner.execute(scenarios, config, status);

            assertThat(status.getStatus()).isEqualTo("PASSED");
            assertThat(status.getPassed()).isEqualTo(4);
            assertThat(status.getFailed()).isZero();
            assertThat(status.getScenarios()).extracting(value -> value.getWorkerId())
                    .containsExactly("worker-01", "worker-02", "worker-01", "worker-02");
            assertThat(status.getScenarios()).extracting(value -> value.getHomeResetStatus())
                    .containsOnly("PASSED");
            assertThat(status.getScenarios()).extracting(value -> value.getSourceSheet())
                    .containsExactly("Smoke", "Smoke", "Regression", "Regression");

            assertThat(mcp.navigationHistories()).hasSize(2);
            assertThat(mcp.navigationHistories()).allSatisfy(history -> {
                assertThat(history).hasSize(5);
                assertThat(history.get(0)).isEqualTo("https://example.test/home");
                assertThat(history.get(2)).isEqualTo("https://example.test/home");
                assertThat(history.get(4)).isEqualTo("https://example.test/home");
            });
            assertThat(Files.exists(output.resolve(config.getRunId()).resolve("report.html"))).isTrue();
            assertThat(Files.exists(output.resolve(config.getRunId()).resolve("workers/worker-01/mcp-transcript.json"))).isTrue();
            assertThat(Files.exists(output.resolve(config.getRunId()).resolve("workers/worker-02/mcp-transcript.json"))).isTrue();
        }
    }

    private static final class FakeMcpServer implements AutoCloseable {
        private final ObjectMapper mapper = new ObjectMapper();
        private final ServerSocket server;
        private final ExecutorService executor = Executors.newCachedThreadPool();
        private final List<List<String>> navigationHistories = new CopyOnWriteArrayList<>();
        private volatile boolean closed;

        private FakeMcpServer() throws Exception {
            server = new ServerSocket(0, 20, InetAddress.getByName("127.0.0.1"));
            executor.submit(this::acceptLoop);
        }

        int port() { return server.getLocalPort(); }
        List<List<String>> navigationHistories() { return navigationHistories; }

        private void acceptLoop() {
            while (!closed) {
                try {
                    Socket socket = server.accept();
                    executor.submit(() -> handle(socket));
                } catch (Exception ignored) {
                    if (!closed) throw new IllegalStateException("Fake MCP accept failed");
                }
            }
        }

        private void handle(Socket socket) {
            List<String> history = new CopyOnWriteArrayList<>();
            navigationHistories.add(history);
            String[] currentUrl = {"about:blank"};
            try (socket;
                 BufferedReader reader = new BufferedReader(new InputStreamReader(socket.getInputStream(), StandardCharsets.UTF_8));
                 BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream(), StandardCharsets.UTF_8))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    JsonNode request = mapper.readTree(line);
                    if (!request.has("id")) continue;
                    long id = request.path("id").asLong();
                    String method = request.path("method").asText();
                    JsonNode result;
                    if ("initialize".equals(method)) {
                        result = mapper.createObjectNode()
                                .put("protocolVersion", "2024-11-05")
                                .set("capabilities", mapper.createObjectNode());
                    } else if ("tools/list".equals(method)) {
                        result = toolList();
                    } else if ("tools/call".equals(method)) {
                        String tool = request.path("params").path("name").asText();
                        JsonNode arguments = request.path("params").path("arguments");
                        result = call(tool, arguments, currentUrl, history);
                    } else {
                        result = textResult("ok");
                    }
                    ObjectNode response = mapper.createObjectNode();
                    response.put("jsonrpc", "2.0");
                    response.put("id", id);
                    response.set("result", result);
                    writer.write(mapper.writeValueAsString(response));
                    writer.newLine();
                    writer.flush();
                }
            } catch (Exception ignored) {
                // The framework closes each socket at worker shutdown.
            }
        }

        private JsonNode call(String tool, JsonNode arguments, String[] currentUrl, List<String> history) {
            if ("browser_navigate".equals(tool)) {
                currentUrl[0] = arguments.path("url").asText();
                history.add(currentUrl[0]);
                return textResult("navigated");
            }
            if ("browser_get_url".equals(tool)) return textResult(currentUrl[0]);
            if ("browser_get_title".equals(tool)) return textResult("Test page");
            if ("browser_get_text".equals(tool)) return textResult("Home ready");
            if ("browser_list_pages".equals(tool)) {
                return textResult("[{\"index\":0,\"url\":" + quote(currentUrl[0]) + "}]");
            }
            if ("browser_evaluate".equals(tool)) {
                return textResult("{\"counts\":{\"action\":0,\"content\":0,\"formValues\":0,\"tables\":0},"
                        + "\"actionElements\":[],\"contentElements\":[],\"formValues\":[],\"tables\":[],"
                        + "\"allVisibleText\":\"Home ready\"}");
            }
            return textResult("ok");
        }

        private ObjectNode toolList() {
            ObjectNode root = mapper.createObjectNode();
            ArrayNode tools = root.putArray("tools");
            addTool(tools, "browser_start", Map.of("headless", "boolean"));
            addTool(tools, "browser_navigate", Map.of("url", "string"));
            addTool(tools, "browser_get_url", Map.of());
            addTool(tools, "browser_get_title", Map.of());
            addTool(tools, "browser_get_text", Map.of());
            addTool(tools, "browser_evaluate", Map.of("expression", "string"));
            addTool(tools, "browser_wait_for_fn", Map.of("expression", "string", "timeout", "number"));
            addTool(tools, "browser_list_pages", Map.of());
            return root;
        }

        private void addTool(ArrayNode tools, String name, Map<String, String> properties) {
            ObjectNode tool = tools.addObject();
            tool.put("name", name);
            tool.put("description", name);
            ObjectNode schema = tool.putObject("inputSchema");
            schema.put("type", "object");
            ObjectNode values = schema.putObject("properties");
            properties.forEach((property, type) -> values.putObject(property).put("type", type));
        }

        private ObjectNode textResult(String text) {
            ObjectNode result = mapper.createObjectNode();
            ObjectNode content = result.putArray("content").addObject();
            content.put("type", "text");
            content.put("text", text);
            return result;
        }

        private String quote(String value) {
            try { return mapper.writeValueAsString(value); }
            catch (Exception error) { return "\"\""; }
        }

        @Override
        public void close() throws Exception {
            closed = true;
            server.close();
            executor.shutdownNow();
            executor.awaitTermination(3, TimeUnit.SECONDS);
        }
    }
}
