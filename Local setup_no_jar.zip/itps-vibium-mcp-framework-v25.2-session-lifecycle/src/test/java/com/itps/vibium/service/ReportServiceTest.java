package com.itps.vibium.service;

import com.itps.vibium.model.RunStatus;
import com.itps.vibium.model.ScenarioResult;
import com.itps.vibium.model.StepResult;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Instant;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

class ReportServiceTest {

    @Test
    void writesSheetWorkerAndHomeResetToEveryReport(@TempDir Path output) throws Exception {
        StepResult step = new StepResult();
        step.setStepNo(1);
        step.setInstruction("Verify Home");
        step.setStatus("PASSED");

        ScenarioResult scenario = new ScenarioResult();
        scenario.setId("TC-01");
        scenario.setName("Home test");
        scenario.setSourceSheet("Smoke");
        scenario.setWorkerId("worker-02");
        scenario.setHomeResetStatus("PASSED");
        scenario.setHomeResetMessage("Browser returned Home");
        scenario.setStatus("PASSED");
        scenario.setSteps(List.of(step));

        RunStatus status = new RunStatus();
        status.setRunId("RUN-TEST");
        status.setStartedAt(Instant.parse("2026-08-15T00:00:00Z"));
        status.setTotal(1);
        status.setPassed(1);
        status.setScenarios(List.of(scenario));

        new ReportService().writeReports(status, output);

        assertThat(Files.readString(output.resolve("report.html")))
                .contains("Smoke", "worker-02", "Home reset", "Browser returned Home");
        assertThat(Files.readString(output.resolve("logs.html")))
                .contains("Smoke", "worker-02", "Verify Home");
        assertThat(Files.readString(output.resolve("report.json")))
                .contains("\"sourceSheet\" : \"Smoke\"", "\"workerId\" : \"worker-02\"", "\"homeResetStatus\" : \"PASSED\"");

        try (var workbook = WorkbookFactory.create(output.resolve("report.xlsx").toFile())) {
            var results = workbook.getSheet("Results");
            assertThat(results.getRow(0).getCell(1).getStringCellValue()).isEqualTo("Source Sheet");
            assertThat(results.getRow(1).getCell(1).getStringCellValue()).isEqualTo("Smoke");
            assertThat(results.getRow(1).getCell(2).getStringCellValue()).isEqualTo("worker-02");
            assertThat(results.getRow(1).getCell(6).getStringCellValue()).isEqualTo("PASSED");
        }
    }
}
