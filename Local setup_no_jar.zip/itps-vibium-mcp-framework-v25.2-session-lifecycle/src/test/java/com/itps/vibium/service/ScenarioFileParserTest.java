package com.itps.vibium.service;

import com.itps.vibium.model.TestScenario;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.jupiter.api.Test;
import org.springframework.mock.web.MockMultipartFile;

import java.io.ByteArrayOutputStream;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

class ScenarioFileParserTest {

    @Test
    void combinesSelectedSheetsAndMakesDuplicateIdsUnique() throws Exception {
        MockMultipartFile workbook = workbookWithDuplicateIds();
        ScenarioFileParser parser = new ScenarioFileParser();

        List<TestScenario> scenarios = parser.parse(workbook, List.of("Smoke", "Regression"));

        assertThat(scenarios).hasSize(2);
        assertThat(scenarios).extracting(TestScenario::getId)
                .containsExactly("TC-01", "Regression-TC-01");
        assertThat(scenarios).extracting(value -> value.getData().get("sourceSheet"))
                .containsExactly("Smoke", "Regression");
        assertThat(scenarios.get(0).getSteps()).containsExactly("Click Login", "Verify Home");
    }

    private MockMultipartFile workbookWithDuplicateIds() throws Exception {
        try (XSSFWorkbook workbook = new XSSFWorkbook();
             ByteArrayOutputStream output = new ByteArrayOutputStream()) {
            addScenarioSheet(workbook.createSheet("Smoke"), "Smoke test");
            addScenarioSheet(workbook.createSheet("Regression"), "Regression test");
            workbook.write(output);
            return new MockMultipartFile(
                    "scenarioFile", "multi-sheet.xlsx",
                    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    output.toByteArray());
        }
    }

    private void addScenarioSheet(Sheet sheet, String name) {
        Row headers = sheet.createRow(0);
        headers.createCell(0).setCellValue("Run");
        headers.createCell(1).setCellValue("Id");
        headers.createCell(2).setCellValue("Name");
        headers.createCell(3).setCellValue("Steps");

        Row row = sheet.createRow(1);
        row.createCell(0).setCellValue("yes");
        row.createCell(1).setCellValue("TC-01");
        row.createCell(2).setCellValue(name);
        row.createCell(3).setCellValue("Click Login\nVerify Home");
    }
}
