package com.itps.vibium.service;

import com.itps.vibium.model.McpTool;

import java.util.*;
import java.util.stream.Collectors;

public class McpToolCatalog {
    private final List<McpTool> tools;

    public McpToolCatalog(List<McpTool> tools) { this.tools = tools == null ? List.of() : tools; }
    public List<McpTool> getTools() { return tools; }

    public Optional<McpTool> findByName(String name) {
        if (name == null) return Optional.empty();
        return tools.stream().filter(t -> t.getName().equalsIgnoreCase(name.trim())).findFirst();
    }

    public Optional<McpTool> findFirstContaining(String... keywords) {
        List<String> keys = Arrays.stream(keywords).filter(Objects::nonNull).map(String::toLowerCase).toList();
        return tools.stream().filter(t -> keys.stream().anyMatch(k -> normalize(t).contains(k))).findFirst();
    }

    public Optional<McpTool> startTool() {
        Optional<McpTool> exact = findByName("browser_start");
        if (exact.isPresent()) return exact;
        return tools.stream().filter(t -> {
            String value = normalize(t);
            return (value.contains("start") || value.contains("launch"))
                    && !value.contains("record") && !value.contains("trace");
        }).findFirst();
    }

    public Optional<McpTool> stopTool() {
        Optional<McpTool> exact = findByName("browser_stop");
        if (exact.isPresent()) return exact;
        return tools.stream().filter(t -> {
            String value = normalize(t);
            return (value.contains("stop") || value.contains("close") || value.contains("quit"))
                    && !value.contains("record") && !value.contains("trace");
        }).findFirst();
    }
    public Optional<McpTool> mapTool() { return exactOrContaining("browser_map", "map", "snapshot", "elements", "accessibility"); }
    public Optional<McpTool> screenshotTool() { return exactOrContaining("browser_screenshot", "screenshot", "capture"); }
    public Optional<McpTool> navigateTool() { return exactOrContaining("browser_navigate", "navigate", "goto", "go", "open"); }
    public Optional<McpTool> waitTool() { return exactOrContaining("browser_wait_for_load", "wait_for_load", "wait", "load"); }
    public Optional<McpTool> clickTool() { return exactOrContaining("browser_click", "click", "tap"); }
    public Optional<McpTool> fillTool() { return exactOrContaining("browser_fill", "fill", "type", "input", "write"); }
    public Optional<McpTool> pressTool() { return exactOrContaining("browser_press", "press", "key"); }
    public Optional<McpTool> selectTool() { return exactOrContaining("browser_select", "select", "option"); }
    public Optional<McpTool> uploadTool() { return exactOrContaining("browser_upload", "upload", "file"); }
    public Optional<McpTool> evaluateTool() { return exactOrContaining("browser_evaluate", "evaluate", "eval", "javascript"); }
    public Optional<McpTool> textTool() { return exactOrContaining("browser_get_text", "text", "get_text"); }
    public Optional<McpTool> urlTool() { return exactOrContaining("browser_get_url", "url", "get_url"); }
    public Optional<McpTool> titleTool() { return exactOrContaining("browser_get_title", "title", "get_title"); }
    public Optional<McpTool> diffTool() { return exactOrContaining("browser_diff", "diff"); }
    public Optional<McpTool> dialogAcceptTool() { return exactOrContaining("browser_dialog_accept", "dialog_accept", "accept dialog"); }
    public Optional<McpTool> dialogDismissTool() { return exactOrContaining("browser_dialog_dismiss", "dialog_dismiss", "dismiss dialog"); }
    public Optional<McpTool> getCookiesTool() { return exactOrContaining("browser_get_cookies", "get_cookies", "list cookies"); }
    public Optional<McpTool> setCookieTool() { return exactOrContaining("browser_set_cookie", "set_cookie", "set a cookie"); }
    public Optional<McpTool> listPagesTool() { return exactOrContaining("browser_list_pages", "browser_list_tabs", "list_pages", "list_tabs"); }
    public Optional<McpTool> switchPageTool() { return exactOrContaining("browser_switch_page", "browser_switch_tab", "switch_page", "switch_tab"); }
    public Optional<McpTool> closePageTool() { return exactOrContaining("browser_close_page", "browser_close_tab", "close_page", "close_tab"); }
    public Optional<McpTool> waitForTextTool() { return exactOrContaining("browser_wait_for_text", "wait_for_text"); }
    public Optional<McpTool> waitForFunctionTool() { return exactOrContaining("browser_wait_for_fn", "wait_for_fn", "wait_for_function"); }

    public boolean hasInputProperty(McpTool tool, String property) {
        if (tool == null || property == null || tool.getInputSchema() == null) return false;
        return tool.getInputSchema().path("properties").has(property);
    }

    public Optional<String> firstInputProperty(McpTool tool, String... candidates) {
        if (candidates == null) return Optional.empty();
        for (String candidate : candidates) if (hasInputProperty(tool, candidate)) return Optional.of(candidate);
        return Optional.empty();
    }

    private Optional<McpTool> exactOrContaining(String exact, String... keywords) {
        Optional<McpTool> exactMatch = findByName(exact);
        return exactMatch.isPresent() ? exactMatch : findFirstContaining(keywords);
    }

    public String toPromptText() {
        return tools.stream().map(t -> {
            String schema = t.getInputSchema() == null || t.getInputSchema().isMissingNode() ? "{}" : compact(t.getInputSchema().toString(), 1600);
            return "- name: " + t.getName() + "\n  description: " + nullSafe(t.getDescription()) + "\n  inputSchema: " + schema;
        }).collect(Collectors.joining("\n"));
    }

    private String normalize(McpTool t) {
        return (nullSafe(t.getName()) + " " + nullSafe(t.getDescription()) + " " + (t.getInputSchema() == null ? "" : t.getInputSchema().toString())).toLowerCase(Locale.ROOT);
    }
    private String nullSafe(String s) { return s == null ? "" : s; }
    private String compact(String s, int max) {
        if (s == null) return "";
        String oneLine = s.replaceAll("\\s+", " ").trim();
        return oneLine.length() <= max ? oneLine : oneLine.substring(0, max) + "...";
    }
}
