package com.itps.vibium.model;

public class RunConfig {
    private String runId;
    private String llmBaseUrl;
    private String llmApiKey;
    private String llmModel;
    private String appBaseUrl;
    private String mcpCommand;
    private String mcpArgs;
    private String mcpMode = "external-tcp";
    private String mcpHost = "127.0.0.1";
    private int mcpPort = 8765;
    private int mcpConnectTimeoutSeconds = 10;
    private String browserId = "vibium-managed-chrome";
    private String browserName = "Vibium Managed Chrome for Testing";
    private String browserExecutable;
    private boolean headless = false;
    private boolean useLlm = true;
    private boolean continueOnFailure = true;
    private boolean strictEvidence = true;
    private String screenshotMode = "ALL"; // ALL, FAILURE_ONLY, NONE
    private int stepTimeoutSeconds = 20;
    private int retryCount = 1;
    private int retryDelayMs = 800;
    private int maxAgentTurns = 3;
    private boolean enableSelfHealing = true;
    private double healingConfidenceThreshold = 0.75;
    private String executionMode = "SEQUENTIAL"; // SEQUENTIAL, PARALLEL
    private int parallelBrowserCount = 1;
    private boolean resetToHome = false;
    private String homeUrl;
    private String homeReadySelector;
    private String homeReadyText;
    private boolean closeExtraPagesOnReset = true;
    private int manualAuthTimeoutSeconds = 180;
    private boolean replaceCookieValue = false;
    private String cookieName;
    private String cookieValue;
    private boolean autoAcceptBrowserDialogs = false;
    private boolean handleHttpsSecurityWarning = false;

    public String getRunId() { return runId; }
    public void setRunId(String runId) { this.runId = runId; }
    public String getLlmBaseUrl() { return llmBaseUrl; }
    public void setLlmBaseUrl(String llmBaseUrl) { this.llmBaseUrl = llmBaseUrl; }
    public String getLlmApiKey() { return llmApiKey; }
    public void setLlmApiKey(String llmApiKey) { this.llmApiKey = llmApiKey; }
    public String getLlmModel() { return llmModel; }
    public void setLlmModel(String llmModel) { this.llmModel = llmModel; }
    public String getAppBaseUrl() { return appBaseUrl; }
    public void setAppBaseUrl(String appBaseUrl) { this.appBaseUrl = appBaseUrl; }
    public String getMcpCommand() { return mcpCommand; }
    public void setMcpCommand(String mcpCommand) { this.mcpCommand = mcpCommand; }
    public String getMcpArgs() { return mcpArgs; }
    public void setMcpArgs(String mcpArgs) { this.mcpArgs = mcpArgs; }
    public String getMcpMode() { return mcpMode; }
    public void setMcpMode(String mcpMode) { this.mcpMode = mcpMode; }
    public String getMcpHost() { return mcpHost; }
    public void setMcpHost(String mcpHost) { this.mcpHost = mcpHost; }
    public int getMcpPort() { return mcpPort; }
    public void setMcpPort(int mcpPort) { this.mcpPort = mcpPort; }
    public int getMcpConnectTimeoutSeconds() { return mcpConnectTimeoutSeconds; }
    public void setMcpConnectTimeoutSeconds(int mcpConnectTimeoutSeconds) { this.mcpConnectTimeoutSeconds = mcpConnectTimeoutSeconds; }
    public String getBrowserId() { return browserId; }
    public void setBrowserId(String browserId) { this.browserId = browserId; }
    public String getBrowserName() { return browserName; }
    public void setBrowserName(String browserName) { this.browserName = browserName; }
    public String getBrowserExecutable() { return browserExecutable; }
    public void setBrowserExecutable(String browserExecutable) { this.browserExecutable = browserExecutable; }
    public boolean isHeadless() { return headless; }
    public void setHeadless(boolean headless) { this.headless = headless; }
    public boolean isUseLlm() { return useLlm; }
    public void setUseLlm(boolean useLlm) { this.useLlm = useLlm; }
    public boolean isContinueOnFailure() { return continueOnFailure; }
    public void setContinueOnFailure(boolean continueOnFailure) { this.continueOnFailure = continueOnFailure; }
    public boolean isStrictEvidence() { return strictEvidence; }
    public void setStrictEvidence(boolean strictEvidence) { this.strictEvidence = strictEvidence; }
    public String getScreenshotMode() { return screenshotMode; }
    public void setScreenshotMode(String screenshotMode) { this.screenshotMode = screenshotMode; }
    public int getStepTimeoutSeconds() { return stepTimeoutSeconds; }
    public void setStepTimeoutSeconds(int stepTimeoutSeconds) { this.stepTimeoutSeconds = stepTimeoutSeconds; }
    public int getRetryCount() { return retryCount; }
    public void setRetryCount(int retryCount) { this.retryCount = retryCount; }
    public int getRetryDelayMs() { return retryDelayMs; }
    public void setRetryDelayMs(int retryDelayMs) { this.retryDelayMs = retryDelayMs; }
    public int getMaxAgentTurns() { return maxAgentTurns; }
    public void setMaxAgentTurns(int maxAgentTurns) { this.maxAgentTurns = maxAgentTurns; }
    public boolean isEnableSelfHealing() { return enableSelfHealing; }
    public void setEnableSelfHealing(boolean enableSelfHealing) { this.enableSelfHealing = enableSelfHealing; }
    public double getHealingConfidenceThreshold() { return healingConfidenceThreshold; }
    public void setHealingConfidenceThreshold(double healingConfidenceThreshold) { this.healingConfidenceThreshold = healingConfidenceThreshold; }
    public String getExecutionMode() { return executionMode; }
    public void setExecutionMode(String executionMode) { this.executionMode = executionMode; }
    public int getParallelBrowserCount() { return parallelBrowserCount; }
    public void setParallelBrowserCount(int parallelBrowserCount) { this.parallelBrowserCount = parallelBrowserCount; }
    public boolean isResetToHome() { return resetToHome; }
    public void setResetToHome(boolean resetToHome) { this.resetToHome = resetToHome; }
    public String getHomeUrl() { return homeUrl; }
    public void setHomeUrl(String homeUrl) { this.homeUrl = homeUrl; }
    public String getHomeReadySelector() { return homeReadySelector; }
    public void setHomeReadySelector(String homeReadySelector) { this.homeReadySelector = homeReadySelector; }
    public String getHomeReadyText() { return homeReadyText; }
    public void setHomeReadyText(String homeReadyText) { this.homeReadyText = homeReadyText; }
    public boolean isCloseExtraPagesOnReset() { return closeExtraPagesOnReset; }
    public void setCloseExtraPagesOnReset(boolean closeExtraPagesOnReset) { this.closeExtraPagesOnReset = closeExtraPagesOnReset; }
    public int getManualAuthTimeoutSeconds() { return manualAuthTimeoutSeconds; }
    public void setManualAuthTimeoutSeconds(int manualAuthTimeoutSeconds) { this.manualAuthTimeoutSeconds = manualAuthTimeoutSeconds; }
    public boolean isReplaceCookieValue() { return replaceCookieValue; }
    public void setReplaceCookieValue(boolean replaceCookieValue) { this.replaceCookieValue = replaceCookieValue; }
    public String getCookieName() { return cookieName; }
    public void setCookieName(String cookieName) { this.cookieName = cookieName; }
    public String getCookieValue() { return cookieValue; }
    public void setCookieValue(String cookieValue) { this.cookieValue = cookieValue; }
    public boolean isAutoAcceptBrowserDialogs() { return autoAcceptBrowserDialogs; }
    public void setAutoAcceptBrowserDialogs(boolean autoAcceptBrowserDialogs) { this.autoAcceptBrowserDialogs = autoAcceptBrowserDialogs; }
    public boolean isHandleHttpsSecurityWarning() { return handleHttpsSecurityWarning; }
    public void setHandleHttpsSecurityWarning(boolean handleHttpsSecurityWarning) { this.handleHttpsSecurityWarning = handleHttpsSecurityWarning; }
}
