package com.itps.vibium.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.itps.vibium.model.McpTool;
import com.itps.vibium.model.RunConfig;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Deterministic execution engine for user supplied XPath actions.
 *
 * <p>V24 deliberately separates DOM resolution from browser input:</p>
 * <ol>
 *   <li>Resolve the XPath against the current live DOM, including same-origin frames and open shadow roots.</li>
 *   <li>Promote non-actionable child nodes and hidden custom-control inputs to a visible action proxy.</li>
 *   <li>Attach a short-lived unique CSS marker.</li>
 *   <li>Use Vibium's native click/fill tool first so the browser receives trusted pointer/keyboard input.</li>
 *   <li>Re-read the live UI and require an observable postcondition; a successful tool response alone is not a pass.</li>
 * </ol>
 *
 * <p>A JavaScript interaction is retained only for frame/shadow contexts that the MCP selector tool cannot reach,
 * or when the current Vibium build does not expose the native action tool.</p>
 */
final class LiveXPathActionExecutor {
    private static final Pattern QUOTED = Pattern.compile("[\\\"']([^\\\"']+)[\\\"']");
    private final ObjectMapper mapper;

    LiveXPathActionExecutor(ObjectMapper mapper) {
        this.mapper = Objects.requireNonNull(mapper, "mapper");
    }


    boolean supportsVisibleText(String instruction) {
        String lower = normalizeSmartQuotes(instruction == null ? "" : instruction).toLowerCase(Locale.ROOT);
        return containsAny(lower, "using visible text", "by visible text", "using exact text", "by exact text",
                "from visible text", "visible option", "visible value");
    }

    Execution executeVisibleText(McpClient mcp, McpToolCatalog catalog, String instruction,
                                 RunConfig config) throws Exception {
        String normalized = normalizeSmartQuotes(instruction);
        Matcher matcher = QUOTED.matcher(normalized);
        String wanted = "";
        while (matcher.find()) wanted = matcher.group(1).trim();
        if (wanted.isBlank()) {
            Matcher plain = Pattern.compile("(?i)\\b(?:click|tap|select|choose|pick)\\s+(.+?)\\s+(?:using|by|from)\\s+(?:the\\s+)?(?:visible|exact)\\s+(?:text|option|value)").matcher(normalized);
            if (plain.find()) wanted = plain.group(1).replaceAll("^[\"']|[\"']$", "").trim();
        }
        if (wanted.isBlank()) throw new IllegalArgumentException("Unable to extract visible text from step: " + instruction);
        String literal = xpathLiteral(wanted);
        String xpath = "//*[normalize-space(.)=" + literal +
                " or normalize-space(@aria-label)=" + literal +
                " or normalize-space(@title)=" + literal + "]";
        Execution base = execute(mcp, catalog, "Click " + quoteForInstruction(wanted) + " using xpath=\"" + xpath.replace("\"", "\\\"") + "\"", xpath, config);
        ObjectNode audit = base.audit().deepCopy();
        audit.put("strategy", "EXACT_VISIBLE_TEXT_NATIVE_FIRST_V24");
        audit.put("requestedVisibleText", wanted);
        ObjectNode action = mapper.createObjectNode();
        action.put("type", "EXACT_VISIBLE_TEXT_ACTION");
        action.put("action", "click");
        action.put("text", wanted);
        action.put("generatedXPath", xpath);
        return new Execution("EXACT_VISIBLE_TEXT_NATIVE_FIRST_V24", action.toString(), base.toolName(),
                base.toolArguments(), base.mcpResult(),
                "Exact visible text '" + wanted + "' was resolved from the current live overlay/page and clicked using native browser input where reachable. " + base.evidence(),
                audit);
    }

    private String xpathLiteral(String value) {
        if (!value.contains("'")) return "'" + value + "'";
        if (!value.contains("\"")) return "\"" + value + "\"";
        String[] parts = value.split("'", -1);
        StringBuilder out = new StringBuilder("concat(");
        for (int i = 0; i < parts.length; i++) {
            if (i > 0) out.append(",\"'\",");
            out.append("'").append(parts[i]).append("'");
        }
        return out.append(')').toString();
    }

    private String quoteForInstruction(String value) {
        return "\"" + value.replace("\"", "\\\"") + "\"";
    }
    Execution execute(McpClient mcp, McpToolCatalog catalog, String instruction,
                      String suppliedXPath, RunConfig config) throws Exception {
        McpTool evaluate = catalog.evaluateTool().orElseThrow(() ->
                new IllegalStateException("User XPath execution requires Vibium browser_evaluate."));

        String normalizedInstruction = normalizeSmartQuotes(instruction);
        String xpath = normalizeSmartQuotes(suppliedXPath).trim();
        String english = removeXPathClause(normalizedInstruction);
        String action = classifyAction(english);
        String value = extractValue(english, action);
        int timeoutMs = Math.max(5_000, Math.max(1, config.getStepTimeoutSeconds()) * 1_000);
        int attempts = Math.max(2, Math.min(5, config.getRetryCount() + 2));
        String marker = "itps-xp-" + UUID.randomUUID().toString().replace("-", "");

        ObjectNode audit = mapper.createObjectNode();
        audit.put("strategy", "USER_XPATH_NATIVE_FIRST_V24");
        audit.put("xpath", xpath);
        audit.put("action", action);
        audit.put("value", value);
        audit.put("timeoutMs", timeoutMs);
        audit.put("attemptLimit", attempts);
        audit.put("llmUsed", false);
        audit.put("nativeBrowserInputPreferred", true);
        ArrayNode phases = audit.putArray("phases");

        List<String> toolNames = new ArrayList<>();
        List<Map<String, Object>> toolArguments = new ArrayList<>();
        List<String> rawResults = new ArrayList<>();

        try {
            if ("verify".equals(action)) {
                JsonNode resolution = resolveWithRetry(mcp, evaluate, xpath, action, marker, timeoutMs, phases);
                requireTrue(resolution.path("found").asBoolean(false),
                        "USER_XPATH_NOT_FOUND_OR_NOT_VISIBLE: " + compact(resolution.toString(), 4_000));
                phases.add(phase("VERIFY_XPATH", resolution));
                return buildExecution(action, xpath, value, evaluate.getName(),
                        List.of(Map.of("phase", "VERIFY_XPATH", "xpath", xpath)),
                        List.of(compact(resolution.toString(), 10_000)),
                        "User XPath resolved a visible live element. No LLM locator was used.", audit);
            }

            JsonNode finalResolution = mapper.createObjectNode();
            JsonNode finalConfirmation = mapper.createObjectNode();
            String interactionMode = "";
            Exception lastNativeError = null;

            for (int attempt = 1; attempt <= attempts; attempt++) {
                cleanupMarkerQuietly(mcp, evaluate, marker);
                JsonNode resolution = resolveWithRetry(mcp, evaluate, xpath, action, marker, timeoutMs, phases);
                finalResolution = resolution;
                ObjectNode resolvePhase = phase("RESOLVE_AND_MARK", resolution);
                resolvePhase.put("attempt", attempt);
                phases.add(resolvePhase);
                requireTrue(resolution.path("found").asBoolean(false),
                        "USER_XPATH_NOT_FOUND_OR_NOT_INTERACTABLE: " + compact(resolution.toString(), 5_000));

                String selector = "[data-itps-action-id=\"" + marker + "\"]";
                boolean nativeReachable = resolution.path("nativeReachable").asBoolean(false);

                try {
                    if ("fill".equals(action)) {
                        McpTool fill = catalog.fillTool().orElse(null);
                        if (nativeReachable && fill != null && acceptsSelector(fill)) {
                            Map<String, Object> args = fillArgs(fill, selector, value, timeoutMs);
                            JsonNode raw = mcp.callTool(fill.getName(), args);
                            assertToolSuccess(fill.getName(), raw);
                            toolNames.add(fill.getName());
                            toolArguments.add(args);
                            rawResults.add(compact(raw.toString(), 5_000));
                            interactionMode = "NATIVE_VIBIUM_FILL";
                        } else {
                            JsonNode raw = evaluateJson(mcp, evaluate, domFillScript(marker, value));
                            requireTrue(raw.path("performed").asBoolean(false),
                                    "DOM fill fallback failed: " + compact(raw.toString(), 3_000));
                            toolNames.add(evaluate.getName());
                            toolArguments.add(Map.of("phase", "DOM_FILL_FALLBACK", "marker", marker));
                            rawResults.add(compact(raw.toString(), 5_000));
                            interactionMode = "DOM_FILL_FALLBACK";
                        }
                    } else {
                        McpTool click = catalog.clickTool().orElse(null);
                        if (nativeReachable && click != null && acceptsSelector(click)) {
                            Map<String, Object> args = selectorArgs(click, selector, timeoutMs);
                            JsonNode raw = mcp.callTool(click.getName(), args);
                            assertToolSuccess(click.getName(), raw);
                            toolNames.add(click.getName());
                            toolArguments.add(args);
                            rawResults.add(compact(raw.toString(), 5_000));
                            interactionMode = "NATIVE_VIBIUM_POINTER";
                        } else {
                            JsonNode raw = evaluateJson(mcp, evaluate, domClickScript(marker));
                            requireTrue(raw.path("performed").asBoolean(false),
                                    "DOM click fallback failed: " + compact(raw.toString(), 3_000));
                            toolNames.add(evaluate.getName());
                            toolArguments.add(Map.of("phase", "DOM_CLICK_FALLBACK", "marker", marker));
                            rawResults.add(compact(raw.toString(), 5_000));
                            interactionMode = "DOM_CLICK_FALLBACK";
                        }
                    }
                } catch (Exception actionError) {
                    lastNativeError = actionError;
                    JsonNode probe = evaluateJson(mcp, evaluate,
                            confirmationScript(xpath, action, value, marker, resolution.path("before")));
                    ObjectNode failedAction = phase("ACTION_ERROR_STATE_PROBE", probe);
                    failedAction.put("attempt", attempt);
                    failedAction.put("error", compact(actionError.getMessage(), 2_000));
                    phases.add(failedAction);
                    if (probe.path("confirmed").asBoolean(false)) {
                        finalConfirmation = probe;
                        interactionMode = "ACTION_CONFIRMED_AFTER_TOOL_ERROR";
                        break;
                    }
                    if (attempt == attempts) throw actionError;
                    sleep(Math.max(150, config.getRetryDelayMs()));
                    continue;
                }

                waitForUiSettle(Math.max(180, config.getRetryDelayMs()));
                JsonNode confirmation = evaluateJson(mcp, evaluate,
                        confirmationScript(xpath, action, value, marker, resolution.path("before")));
                finalConfirmation = confirmation;
                ObjectNode confirmPhase = phase("VERIFY_POSTCONDITION", confirmation);
                confirmPhase.put("attempt", attempt);
                confirmPhase.put("interactionMode", interactionMode);
                phases.add(confirmPhase);

                if (confirmation.path("confirmed").asBoolean(false)) break;

                // Never double-click an option after the browser accepted the click. A missing confirmation
                // is reported rather than blindly clicking the same option again and potentially toggling it.
                if (resolution.path("optionLike").asBoolean(false)) break;
                if (attempt < attempts) sleep(Math.max(150, config.getRetryDelayMs()));
            }

            boolean confirmed = finalConfirmation.path("confirmed").asBoolean(false);
            if (!confirmed && config.isStrictEvidence()) {
                String nativeError = lastNativeError == null ? "" : "; lastToolError=" + compact(lastNativeError.getMessage(), 1_500);
                throw new IllegalStateException("USER_XPATH_ACTION_NOT_CONFIRMED: action=" + action +
                        ", xpath=" + xpath + nativeError + "; resolution=" +
                        compact(finalResolution.toString(), 3_000) + "; confirmation=" +
                        compact(finalConfirmation.toString(), 5_000));
            }

            audit.put("interactionMode", interactionMode);
            audit.set("finalResolution", finalResolution);
            audit.set("finalConfirmation", finalConfirmation);

            String evidence;
            if ("fill".equals(action)) {
                evidence = "User XPath was resolved against the live DOM. Vibium native fill was preferred and the final value was verified as '" +
                        finalConfirmation.path("finalValue").asText(value) + "'.";
            } else {
                evidence = "User XPath was resolved against the live DOM and executed with " + interactionMode +
                        ". Postcondition=" + finalConfirmation.path("strategy").asText("tool-success") + ".";
            }

            return buildExecution(action, xpath, value,
                    toolNames.isEmpty() ? evaluate.getName() : String.join(" → ", toolNames),
                    toolArguments, rawResults, evidence, audit);
        } finally {
            cleanupMarkerQuietly(mcp, evaluate, marker);
        }
    }

    private JsonNode resolveWithRetry(McpClient mcp, McpTool evaluate, String xpath, String action,
                                      String marker, int timeoutMs, ArrayNode phases) throws Exception {
        long deadline = System.currentTimeMillis() + timeoutMs;
        JsonNode last = mapper.createObjectNode();
        int poll = 0;
        while (System.currentTimeMillis() < deadline) {
            poll++;
            last = evaluateJson(mcp, evaluate, resolveAndMarkScript(xpath, action, marker));
            if (last.path("invalidXPath").asBoolean(false)) {
                throw new IllegalArgumentException("INVALID_XPATH: " + last.path("error").asText() + "; xpath=" + xpath);
            }
            if (last.path("found").asBoolean(false)) return last;
            if (poll == 1 || poll % 5 == 0) {
                ObjectNode wait = phase("WAIT_FOR_XPATH", last);
                wait.put("poll", poll);
                phases.add(wait);
            }
            sleep(120);
        }
        return last;
    }

    private String resolveAndMarkScript(String xpath, String action, String marker) {
        return """
                (() => {
                  const xpath=%s, action=%s, marker=%s;
                  const norm=v=>String(v??'').replace(/\\s+/g,' ').trim().toLowerCase();
                  const visible=e=>{
                    if(!e||!(e instanceof Element)||!e.isConnected)return false;
                    const r=e.getBoundingClientRect(),w=e.ownerDocument.defaultView,s=w.getComputedStyle(e);
                    return r.width>1&&r.height>1&&s.display!=='none'&&s.visibility!=='hidden'&&Number(s.opacity||1)>0;
                  };
                  const enabled=e=>!(e.disabled||e.getAttribute?.('aria-disabled')==='true'||e.classList?.contains('disabled'));
                  const docs=()=>{
                    const out=[document];
                    for(let i=0;i<out.length;i++)for(const f of out[i].querySelectorAll('iframe,frame')){
                      try{if(f.contentDocument&&!out.includes(f.contentDocument))out.push(f.contentDocument);}catch(ignore){}
                    }
                    return out;
                  };
                  const roots=d=>{
                    const out=[d];
                    for(let i=0;i<out.length;i++)for(const e of out[i].querySelectorAll?.('*')||[])if(e.shadowRoot)out.push(e.shadowRoot);
                    return out;
                  };
                  const xpathAll=()=>{
                    const out=[];
                    for(const d of docs())for(const root of roots(d)){
                      try{
                        const x=d.evaluate(xpath,root,null,XPathResult.ORDERED_NODE_SNAPSHOT_TYPE,null);
                        for(let i=0;i<x.snapshotLength;i++){
                          const n=x.snapshotItem(i),e=n instanceof Element?n:n?.parentElement;
                          if(e&&!out.includes(e))out.push(e);
                        }
                      }catch(err){return {nodes:out,error:err.message};}
                    }
                    return {nodes:out};
                  };
                  const optionSel='[role="option"],mat-option,.mat-mdc-option,.mat-option,.ng-option,.p-dropdown-item,.p-select-option,.p-autocomplete-option,.ant-select-item-option,.select2-results__option,li[role="option"],option';
                  const interactiveSel=optionSel+',button,a,[role="button"],[role="menuitem"],[role="tab"],[role="checkbox"],[role="radio"],label,summary,input:not([type="hidden"]),textarea,select,[contenteditable="true"],[tabindex]:not([tabindex="-1"])';
                  const controlProxySel='.ng-select-container,.mat-mdc-select-trigger,.mat-select-trigger,.p-dropdown,.p-select,.p-autocomplete,.ant-select-selector,.select2-selection,[role="combobox"],[aria-haspopup="listbox"],[aria-haspopup="menu"]';
                  const nearestVisible=(e,selector)=>{for(let c=e;c;c=c.parentElement){if(c.matches?.(selector)&&visible(c)&&enabled(c))return c;}return null;};
                  const promote=raw=>{
                    if(action==='fill'){
                      if(raw.matches?.('input:not([type="hidden"]),textarea,[contenteditable="true"]')&&visible(raw)&&enabled(raw))return {target:raw,reason:'DIRECT_FILL_TARGET'};
                      const editable=raw.querySelector?.('input:not([type="hidden"]),textarea,[contenteditable="true"]');
                      if(editable&&visible(editable)&&enabled(editable))return {target:editable,reason:'DESCENDANT_FILL_TARGET'};
                      return {target:raw,reason:'NON_STANDARD_FILL_TARGET'};
                    }
                    if(raw.matches?.(interactiveSel)&&visible(raw)&&enabled(raw))return {target:raw,reason:'DIRECT_INTERACTIVE'};
                    const option=nearestVisible(raw,optionSel);if(option)return {target:option,reason:'OPTION_ANCESTOR'};
                    const interactive=nearestVisible(raw,interactiveSel);if(interactive)return {target:interactive,reason:'INTERACTIVE_ANCESTOR'};
                    const proxy=nearestVisible(raw,controlProxySel);if(proxy)return {target:proxy,reason:'CUSTOM_CONTROL_PROXY'};
                    if(visible(raw)&&enabled(raw))return {target:raw,reason:'VISIBLE_RAW_NODE'};
                    const visibleParent=nearestVisible(raw,'datatable-body-cell,datatable-body-row,[role="gridcell"],[role="row"],td,tr,div,span');
                    return {target:visibleParent||raw,reason:visibleParent?'VISIBLE_STRUCTURAL_PARENT':'NO_VISIBLE_PROXY'};
                  };
                  const hit=e=>{
                    if(!visible(e))return {passed:false};
                    const r=e.getBoundingClientRect(),points=[[.5,.5],[.25,.5],[.75,.5],[.5,.25],[.5,.75]];
                    for(const [px,py] of points){
                      const x=Math.max(0,Math.min(e.ownerDocument.defaultView.innerWidth-1,r.left+r.width*px));
                      const y=Math.max(0,Math.min(e.ownerDocument.defaultView.innerHeight-1,r.top+r.height*py));
                      const top=e.ownerDocument.elementFromPoint(x,y);
                      if(top&&(top===e||e.contains(top)))return {passed:true,x,y,topTag:top.tagName};
                    }
                    return {passed:false};
                  };
                  const overlays=()=>[...document.querySelectorAll('[role="listbox"],[role="menu"],.cdk-overlay-pane,.ng-dropdown-panel,.p-dropdown-panel,.p-select-overlay,.p-autocomplete-panel,.ant-select-dropdown,.select2-dropdown,.dropdown-menu,.popover')].filter(visible);
                  const hash=s=>{let h=2166136261;for(let i=0;i<s.length;i++){h^=s.charCodeAt(i);h=Math.imul(h,16777619);}return (h>>>0).toString(16);};
                  const signature=()=>hash(String(location.href)+'|'+String(document.body?.innerText||'').slice(0,30000)+'|'+String(document.body?.innerHTML?.length||0)+'|'+overlays().length);
                  const describe=e=>e?{tag:e.tagName,id:e.id||'',role:e.getAttribute?.('role')||'',class:String(e.className||'').slice(0,180),text:(e.innerText||e.textContent||e.value||'').trim().slice(0,300),value:'value'in e?String(e.value||''):'',checked:!!e.checked,selected:e.getAttribute?.('aria-selected')||'',expanded:e.getAttribute?.('aria-expanded')||'',connected:e.isConnected}:null;
                  for(const d of docs())for(const root of roots(d))for(const old of root.querySelectorAll?.(`[data-itps-action-id="${marker}"]`)||[])old.removeAttribute('data-itps-action-id');
                  const x=xpathAll();
                  if(x.error)return JSON.stringify({found:false,invalidXPath:true,error:x.error,xpath,rawMatches:x.nodes.length});
                  const candidates=x.nodes.map(raw=>({raw,...promote(raw)})).filter(x=>x.target&&enabled(x.target));
                  candidates.sort((a,b)=>{
                    const av=visible(a.target)?0:1,bv=visible(b.target)?0:1;if(av!==bv)return av-bv;
                    const ah=hit(a.target).passed?0:1,bh=hit(b.target).passed?0:1;if(ah!==bh)return ah-bh;
                    const ao=a.target.matches?.(optionSel)?0:1,bo=b.target.matches?.(optionSel)?0:1;if(ao!==bo)return ao-bo;
                    const ar=a.target.getBoundingClientRect(),br=b.target.getBoundingClientRect();return ar.width*ar.height-br.width*br.height;
                  });
                  const chosen=candidates.find(x=>visible(x.target)&&enabled(x.target));
                  if(!chosen)return JSON.stringify({found:false,reason:'NO_VISIBLE_ENABLED_ACTION_TARGET',xpath,rawMatches:x.nodes.length,candidateCount:candidates.length,raw:x.nodes.slice(0,10).map(describe)});
                  let target=chosen.target,proxyReason=chosen.reason;
                  target.scrollIntoView({block:'center',inline:'nearest',behavior:'instant'});
                  let hitInfo=hit(target);
                  if(action==='click'&&hitInfo.passed){
                    const deep=target.ownerDocument.elementFromPoint(hitInfo.x,hitInfo.y);
                    if(deep&&deep!==target&&target.contains(deep)&&visible(deep)&&enabled(deep)){
                      const actionable=deep.closest?.(interactiveSel);
                      if(actionable&&target.contains(actionable)&&visible(actionable)&&enabled(actionable)){
                        target=actionable;proxyReason+='->HIT_INTERACTIVE_DESCENDANT';
                      }else{
                        target=deep;proxyReason+='->HIT_DESCENDANT';
                      }
                      hitInfo=hit(target);
                    }
                  }
                  if(action==='click'&&!hitInfo.passed)return JSON.stringify({found:false,reason:'HIT_TEST_FAILED',xpath,rawMatches:x.nodes.length,target:describe(target),proxyReason});
                  target.setAttribute('data-itps-action-id',marker);
                  const rawInput=chosen.raw?.matches?.('input,textarea,[contenteditable="true"]')?chosen.raw:null;
                  const before={url:String(location.href),signature:signature(),overlayCount:overlays().length,active:describe(target.ownerDocument.activeElement),target:describe(target),raw:describe(chosen.raw)};
                  return JSON.stringify({found:true,xpath,rawMatches:x.nodes.length,candidateCount:candidates.length,marker,proxyReason,nativeReachable:target.ownerDocument===document&&target.getRootNode()===document,optionLike:!!target.matches?.(optionSel)||!!target.closest?.(optionSel),rawInput:!!rawInput,target:describe(target),hit:hitInfo,before});
                })()
                """.formatted(js(xpath), js(action), js(marker));
    }

    private String confirmationScript(String xpath, String action, String value, String marker, JsonNode before) {
        return """
                (() => {
                  const xpath=%s,action=%s,value=%s,marker=%s,before=%s;
                  const norm=v=>String(v??'').replace(/\\s+/g,' ').trim().toLowerCase();
                  const visible=e=>{if(!e||!(e instanceof Element)||!e.isConnected)return false;const r=e.getBoundingClientRect(),s=e.ownerDocument.defaultView.getComputedStyle(e);return r.width>1&&r.height>1&&s.display!=='none'&&s.visibility!=='hidden'&&Number(s.opacity||1)>0;};
                  const docs=[document];for(let i=0;i<docs.length;i++)for(const f of docs[i].querySelectorAll('iframe,frame')){try{if(f.contentDocument&&!docs.includes(f.contentDocument))docs.push(f.contentDocument);}catch(ignore){}}
                  const roots=d=>{const out=[d];for(let i=0;i<out.length;i++)for(const e of out[i].querySelectorAll?.('*')||[])if(e.shadowRoot)out.push(e.shadowRoot);return out;};
                  const xpathAll=()=>{const out=[];for(const d of docs)for(const r of roots(d)){try{const x=d.evaluate(xpath,r,null,XPathResult.ORDERED_NODE_SNAPSHOT_TYPE,null);for(let i=0;i<x.snapshotLength;i++){const n=x.snapshotItem(i),e=n instanceof Element?n:n?.parentElement;if(e&&!out.includes(e))out.push(e);}}catch(ignore){}}return out;};
                  const findMarked=()=>{for(const d of docs)for(const r of roots(d)){const e=r.querySelector?.(`[data-itps-action-id="${marker}"]`);if(e)return e;}return null;};
                  const overlays=()=>[...document.querySelectorAll('[role="listbox"],[role="menu"],.cdk-overlay-pane,.ng-dropdown-panel,.p-dropdown-panel,.p-select-overlay,.p-autocomplete-panel,.ant-select-dropdown,.select2-dropdown,.dropdown-menu,.popover')].filter(visible);
                  const hash=s=>{let h=2166136261;for(let i=0;i<s.length;i++){h^=s.charCodeAt(i);h=Math.imul(h,16777619);}return (h>>>0).toString(16);};
                  const signature=()=>hash(String(location.href)+'|'+String(document.body?.innerText||'').slice(0,30000)+'|'+String(document.body?.innerHTML?.length||0)+'|'+overlays().length);
                  const describe=e=>e?{tag:e.tagName,id:e.id||'',role:e.getAttribute?.('role')||'',value:'value'in e?String(e.value||''):'',checked:!!e.checked,selected:e.getAttribute?.('aria-selected')||'',expanded:e.getAttribute?.('aria-expanded')||'',connected:e.isConnected,text:(e.innerText||e.textContent||'').trim().slice(0,180)}:null;
                  let marked=findMarked();
                  const raw=xpathAll();
                  const currentRaw=raw.find(e=>visible(e))||raw[0]||null;
                  if(action==='click'&&currentRaw?.matches?.('input,textarea,[contenteditable="true"]')){try{currentRaw.focus({preventScroll:true});}catch(ignore){}}
                  const current=marked||currentRaw;
                  const finalValue=currentRaw&&('value'in currentRaw)?String(currentRaw.value||''):current&&('value'in current)?String(current.value||''):'';
                  const after={url:String(location.href),signature:signature(),overlayCount:overlays().length,active:describe((current?.ownerDocument||document).activeElement),target:describe(current),raw:describe(currentRaw)};
                  if(action==='fill'){
                    const exact=norm(finalValue)===norm(value);
                    return JSON.stringify({confirmed:exact,strategy:exact?'EXACT_FINAL_VALUE':'VALUE_NOT_APPLIED',finalValue,expected:value,before,after});
                  }
                  const selected=!!current&&(current.getAttribute?.('aria-selected')==='true'||current.classList?.contains('selected')||current.classList?.contains('ng-option-selected')||current.classList?.contains('p-highlight')||current.classList?.contains('mat-mdc-option-active'));
                  const collapsed=(before?.target?.expanded==='true'&&after?.target?.expanded==='false')||(before?.raw?.expanded==='true'&&after?.raw?.expanded==='false');
                  const overlayChanged=Number(after.overlayCount)!==Number(before?.overlayCount);
                  const urlChanged=String(after.url)!==String(before?.url);
                  const signatureChanged=String(after.signature)!==String(before?.signature);
                  const focusChanged=JSON.stringify(after.active)!==JSON.stringify(before?.active)&&!!after.active;
                  const targetStateChanged=JSON.stringify(after.target)!==JSON.stringify(before?.target)||JSON.stringify(after.raw)!==JSON.stringify(before?.raw);
                  const optionLike=!!current?.matches?.('[role="option"],mat-option,.mat-mdc-option,.mat-option,.ng-option,.p-dropdown-item,.p-select-option,.p-autocomplete-option,.ant-select-item-option,.select2-results__option,li[role="option"],option')||!!current?.closest?.('[role="option"],mat-option,.ng-option');
                  const confirmed=optionLike?(selected||collapsed||overlayChanged):(urlChanged||overlayChanged||signatureChanged||focusChanged||targetStateChanged);
                  const strategy=selected?'OPTION_SELECTED_STATE':collapsed?'CONTROL_COLLAPSED':overlayChanged?'OVERLAY_STATE_CHANGED':urlChanged?'URL_CHANGED':signatureChanged?'DOM_TEXT_CHANGED':focusChanged?'FOCUS_CHANGED':targetStateChanged?'TARGET_STATE_CHANGED':'NO_OBSERVABLE_EFFECT';
                  return JSON.stringify({confirmed,strategy,optionLike,selected,collapsed,overlayChanged,urlChanged,signatureChanged,focusChanged,targetStateChanged,before,after});
                })()
                """.formatted(js(xpath), js(action), js(value), js(marker), before == null ? "{}" : before.toString());
    }

    private String domClickScript(String marker) {
        return """
                (()=>{
                  const marker=%s;
                  const docs=[document];for(let i=0;i<docs.length;i++)for(const f of docs[i].querySelectorAll('iframe,frame')){try{if(f.contentDocument&&!docs.includes(f.contentDocument))docs.push(f.contentDocument);}catch(ignore){}}
                  const roots=d=>{const out=[d];for(let i=0;i<out.length;i++)for(const e of out[i].querySelectorAll?.('*')||[])if(e.shadowRoot)out.push(e.shadowRoot);return out;};
                  let e=null;for(const d of docs){for(const r of roots(d)){e=r.querySelector?.(`[data-itps-action-id="${marker}"]`);if(e)break;}if(e)break;}
                  if(!e)return JSON.stringify({performed:false,reason:'MARKER_NOT_FOUND'});
                  e.scrollIntoView({block:'center',inline:'nearest',behavior:'instant'});
                  const r=e.getBoundingClientRect(),x=r.left+r.width/2,y=r.top+r.height/2,top=e.ownerDocument.elementFromPoint(x,y);
                  if(!top||!(top===e||e.contains(top)))return JSON.stringify({performed:false,reason:'HIT_TEST_FAILED',top:top?.tagName||''});
                  const target=top&&e.contains(top)?top:e;
                  target.focus?.({preventScroll:true});
                  const common={bubbles:true,cancelable:true,composed:true,view:e.ownerDocument.defaultView,clientX:x,clientY:y,button:0,buttons:1};
                  try{target.dispatchEvent(new PointerEvent('pointerdown',{...common,pointerId:1,pointerType:'mouse',isPrimary:true}));}catch(ignore){}
                  target.dispatchEvent(new MouseEvent('mousedown',common));
                  try{target.dispatchEvent(new PointerEvent('pointerup',{...common,buttons:0,pointerId:1,pointerType:'mouse',isPrimary:true}));}catch(ignore){}
                  target.dispatchEvent(new MouseEvent('mouseup',{...common,buttons:0}));
                  target.click();
                  return JSON.stringify({performed:true,mode:'DOM_SYNTHETIC_FALLBACK',tag:e.tagName});
                })()
                """.formatted(js(marker));
    }

    private String domFillScript(String marker, String value) {
        return """
                (()=>{
                  const marker=%s,value=%s;
                  const docs=[document];for(let i=0;i<docs.length;i++)for(const f of docs[i].querySelectorAll('iframe,frame')){try{if(f.contentDocument&&!docs.includes(f.contentDocument))docs.push(f.contentDocument);}catch(ignore){}}
                  const roots=d=>{const out=[d];for(let i=0;i<out.length;i++)for(const e of out[i].querySelectorAll?.('*')||[])if(e.shadowRoot)out.push(e.shadowRoot);return out;};
                  let e=null;for(const d of docs){for(const r of roots(d)){e=r.querySelector?.(`[data-itps-action-id="${marker}"]`);if(e)break;}if(e)break;}
                  if(!e)return JSON.stringify({performed:false,reason:'MARKER_NOT_FOUND'});
                  e.focus?.({preventScroll:true});
                  if(e.isContentEditable)e.textContent=value;
                  else if('value'in e){const proto=e instanceof HTMLTextAreaElement?HTMLTextAreaElement.prototype:HTMLInputElement.prototype;const setter=Object.getOwnPropertyDescriptor(proto,'value')?.set;if(setter)setter.call(e,value);else e.value=value;}
                  else e.textContent=value;
                  try{e.dispatchEvent(new InputEvent('input',{bubbles:true,composed:true,inputType:'insertText',data:value}));}catch(ignore){e.dispatchEvent(new Event('input',{bubbles:true,composed:true}));}
                  e.dispatchEvent(new Event('change',{bubbles:true,composed:true}));
                  return JSON.stringify({performed:true,mode:'DOM_VALUE_FALLBACK',finalValue:'value'in e?String(e.value||''):String(e.textContent||'')});
                })()
                """.formatted(js(marker), js(value));
    }

    private Execution buildExecution(String action, String xpath, String value, String toolName,
                                     List<Map<String, Object>> args, List<String> results,
                                     String evidence, ObjectNode audit) throws Exception {
        ObjectNode actionJson = mapper.createObjectNode();
        actionJson.put("type", "USER_XPATH_DETERMINISTIC_ACTION");
        actionJson.put("action", action);
        actionJson.put("xpath", xpath);
        actionJson.put("value", value);
        return new Execution("USER_XPATH_NATIVE_FIRST_V24", actionJson.toString(), toolName,
                mapper.writeValueAsString(args), String.join("\n---\n", results), evidence, audit);
    }

    private Map<String, Object> selectorArgs(McpTool tool, String selector, int timeoutMs) {
        Map<String, Object> args = new LinkedHashMap<>();
        if (schemaContains(tool, "selector")) args.put("selector", selector);
        else if (schemaContains(tool, "locator")) args.put("locator", selector);
        else args.put("target", selector);
        if (schemaContains(tool, "timeout")) args.put("timeout", timeoutMs);
        return args;
    }

    private Map<String, Object> fillArgs(McpTool tool, String selector, String value, int timeoutMs) {
        Map<String, Object> args = selectorArgs(tool, selector, timeoutMs);
        if (schemaContains(tool, "text")) args.put("text", value);
        else if (schemaContains(tool, "value")) args.put("value", value);
        else if (schemaContains(tool, "input")) args.put("input", value);
        else args.put("text", value);
        return args;
    }

    private Map<String, Object> evaluateArgs(McpTool evaluate, String script) {
        Map<String, Object> args = new LinkedHashMap<>();
        if (schemaContains(evaluate, "expression")) args.put("expression", script);
        else if (schemaContains(evaluate, "script")) args.put("script", script);
        else args.put("code", script);
        return args;
    }

    private JsonNode evaluateJson(McpClient mcp, McpTool evaluate, String script) throws Exception {
        Map<String, Object> args = evaluateArgs(evaluate, script);
        JsonNode raw = mcp.callTool(evaluate.getName(), args);
        assertToolSuccess(evaluate.getName(), raw);
        return unwrapJsonString(raw);
    }

    private void cleanupMarkerQuietly(McpClient mcp, McpTool evaluate, String marker) {
        try {
            evaluateJson(mcp, evaluate, """
                    (()=>{const marker=%s;const docs=[document];for(let i=0;i<docs.length;i++)for(const f of docs[i].querySelectorAll('iframe,frame')){try{if(f.contentDocument&&!docs.includes(f.contentDocument))docs.push(f.contentDocument);}catch(ignore){}}const roots=d=>{const out=[d];for(let i=0;i<out.length;i++)for(const e of out[i].querySelectorAll?.('*')||[])if(e.shadowRoot)out.push(e.shadowRoot);return out;};let n=0;for(const d of docs)for(const r of roots(d))for(const e of r.querySelectorAll?.(`[data-itps-action-id="${marker}"]`)||[]){e.removeAttribute('data-itps-action-id');n++;}return JSON.stringify({removed:n});})()
                    """.formatted(js(marker)));
        } catch (Exception ignored) { }
    }

    private ObjectNode phase(String name, JsonNode details) {
        ObjectNode phase = mapper.createObjectNode();
        phase.put("name", name);
        phase.set("details", details == null ? mapper.nullNode() : details);
        return phase;
    }

    private String classifyAction(String english) {
        String lower = english == null ? "" : english.toLowerCase(Locale.ROOT);
        if (containsAny(lower, "verify", "validate", "assert", "check", "ensure")) return "verify";
        if (containsAny(lower, "type", "enter", "fill", "input", "set value")) return "fill";
        return "click";
    }

    private String extractValue(String english, String action) {
        if (!"fill".equals(action) || english == null) return "";
        Matcher quoted = QUOTED.matcher(english);
        if (quoted.find()) return quoted.group(1).trim();
        Matcher plain = Pattern.compile("(?i)\\b(?:type|enter|fill|input)\\s+(.+?)(?:\\s+(?:in|into|using|following)\\b|$)").matcher(english.trim());
        return plain.find() ? plain.group(1).trim() : "";
    }

    private String removeXPathClause(String instruction) {
        if (instruction == null) return "";
        String text = normalizeSmartQuotes(instruction);
        String lower = text.toLowerCase(Locale.ROOT);
        int marker = -1;
        for (String token : List.of("[xpath=", "xpath=", "xpath:", "using xpath", "following xpath")) {
            int i = lower.indexOf(token);
            if (i >= 0 && (marker < 0 || i < marker)) marker = i;
        }
        return marker < 0 ? text.trim() : text.substring(0, marker).trim();
    }

    static String normalizeSmartQuotes(String value) {
        if (value == null) return "";
        return value.replace('\u2018', '\'').replace('\u2019', '\'')
                .replace('\u201A', '\'').replace('\u201B', '\'')
                .replace('\u201C', '"').replace('\u201D', '"')
                .replace('\u201E', '"').replace('\u201F', '"')
                .replace('\u00AB', '"').replace('\u00BB', '"');
    }

    private JsonNode unwrapJsonString(JsonNode raw) {
        if (raw == null) return mapper.createObjectNode().put("error", "empty result");
        List<String> texts = new ArrayList<>();
        collectText(raw, texts);
        texts.sort(Comparator.comparingInt(String::length).reversed());
        for (String text : texts) {
            String trimmed = text == null ? "" : text.trim();
            if (!(trimmed.startsWith("{") || trimmed.startsWith("["))) continue;
            try { return mapper.readTree(trimmed); } catch (Exception ignored) { }
        }
        return raw;
    }

    private void collectText(JsonNode node, List<String> output) {
        if (node == null) return;
        if (node.isTextual()) output.add(node.asText());
        else if (node.isArray()) for (JsonNode child : node) collectText(child, output);
        else if (node.isObject()) node.fields().forEachRemaining(e -> collectText(e.getValue(), output));
    }

    private void assertToolSuccess(String tool, JsonNode result) {
        if (result == null || result.isMissingNode()) return;
        if (result.path("isError").asBoolean(false))
            throw new IllegalStateException("MCP tool returned isError=true for " + tool + ": " + compact(result.toString(), 2_000));
        String text = extractText(result).toLowerCase(Locale.ROOT);
        for (String fatal : List.of("invalid selector", "timed out", "timeout", "element not found", "unable to click", "exception", "detached"))
            if (text.contains(fatal)) throw new IllegalStateException("MCP tool failed for " + tool + ": " + compact(text, 2_000));
    }

    private String extractText(JsonNode node) {
        if (node == null) return "";
        if (node.isValueNode()) return node.asText("");
        StringBuilder out = new StringBuilder();
        if (node.isArray()) for (JsonNode child : node) out.append(' ').append(extractText(child));
        else node.fields().forEachRemaining(e -> out.append(' ').append(extractText(e.getValue())));
        return out.toString();
    }

    private boolean acceptsSelector(McpTool tool) {
        return schemaContains(tool, "selector") || schemaContains(tool, "locator") || schemaContains(tool, "target");
    }

    private boolean schemaContains(McpTool tool, String term) {
        return tool != null && tool.getInputSchema() != null &&
                tool.getInputSchema().toString().toLowerCase(Locale.ROOT).contains(term.toLowerCase(Locale.ROOT));
    }

    private boolean containsAny(String text, String... terms) {
        String lower = text == null ? "" : text.toLowerCase(Locale.ROOT);
        for (String term : terms) if (lower.contains(term.toLowerCase(Locale.ROOT))) return true;
        return false;
    }

    private String js(String value) {
        try { return mapper.writeValueAsString(value == null ? "" : value); }
        catch (Exception e) { return "\"\""; }
    }

    private void requireTrue(boolean condition, String message) {
        if (!condition) throw new IllegalStateException(message);
    }

    private void sleep(long millis) {
        try { Thread.sleep(Math.max(1, millis)); } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new IllegalStateException("Interrupted while waiting for UI state", e);
        }
    }

    private void waitForUiSettle(long millis) { sleep(Math.min(1_200, Math.max(100, millis))); }

    private String compact(String text, int max) {
        if (text == null) return "";
        String compact = text.replaceAll("\\s+", " ").trim();
        return compact.length() <= max ? compact : compact.substring(0, max) + "...";
    }

    record Execution(String planSource, String actionJson, String toolName, String toolArguments,
                     String mcpResult, String evidence, JsonNode audit) { }
}
