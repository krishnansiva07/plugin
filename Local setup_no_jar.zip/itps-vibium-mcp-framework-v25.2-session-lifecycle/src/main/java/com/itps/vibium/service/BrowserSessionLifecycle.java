package com.itps.vibium.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.itps.vibium.model.McpTool;
import com.itps.vibium.model.RunConfig;

import java.net.URI;
import java.time.Instant;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.*;

/** Run-level browser lifecycle operations that are deliberately kept outside normal test steps. */
final class BrowserSessionLifecycle {
    private static final String REDACTED_COOKIE_ERROR =
            "Cookie value replacement failed. The cookie value was redacted; inspect the non-sensitive lifecycle message.";
    private final ObjectMapper mapper;

    BrowserSessionLifecycle(ObjectMapper mapper) {
        this.mapper = Objects.requireNonNull(mapper, "mapper");
    }

    void bootstrap(McpClient mcp, McpToolCatalog catalog, RunConfig config, String homeUrl) throws Exception {
        // Preserve the V25.1 lifecycle exactly when every new session option is disabled.
        if (!requiresBootstrap(config)) return;
        if (config.isReplaceCookieValue()) {
            mcp.registerSecret(config.getCookieValue());
            if (blank(homeUrl)) {
                throw new IllegalStateException("Cookie replacement requires a Home URL, App Base URL, or an absolute URL in the first scenario.");
            }
        }

        if (!blank(homeUrl)) {
            navigate(mcp, catalog, homeUrl);
            handleHttpsSecurityWarning(mcp, catalog, config);
        }

        if (config.isReplaceCookieValue()) {
            replaceCookieValue(mcp, catalog, config, homeUrl);
            // A new session cookie normally takes effect only after a fresh application request.
            navigate(mcp, catalog, homeUrl);
            handleHttpsSecurityWarning(mcp, catalog, config);
        }

        if (!blank(homeUrl)) waitUntilHomeReady(mcp, catalog, config);
        prepareAutomaticDialogs(mcp, catalog, config);
    }

    boolean requiresBootstrap(RunConfig config) {
        return config != null && (config.isResetToHome()
                || config.isReplaceCookieValue()
                || config.isAutoAcceptBrowserDialogs()
                || config.isHandleHttpsSecurityWarning());
    }

    ResetResult resetToHome(McpClient mcp, McpToolCatalog catalog, RunConfig config, String homeUrl) {
        if (!config.isResetToHome()) return new ResetResult("NOT_REQUESTED", "Home reset is disabled.");
        if (blank(homeUrl)) return new ResetResult("FAILED", "Home reset is enabled but no Home URL could be resolved.");
        try {
            acceptOpenDialogQuietly(mcp, catalog);
            if (config.isCloseExtraPagesOnReset()) closeExtraPagesQuietly(mcp, catalog);
            navigate(mcp, catalog, homeUrl);
            handleHttpsSecurityWarning(mcp, catalog, config);
            prepareAutomaticDialogs(mcp, catalog, config);
            waitUntilHomeReady(mcp, catalog, config);
            return new ResetResult("PASSED", "Browser returned to the configured Home page.");
        } catch (Exception e) {
            return new ResetResult("FAILED", compact(safeMessage(e), 700));
        }
    }

    void prepareAutomaticDialogs(McpClient mcp, McpToolCatalog catalog, RunConfig config) throws Exception {
        if (!config.isAutoAcceptBrowserDialogs()) return;
        McpTool evaluate = catalog.evaluateTool().orElseThrow(() ->
                new IllegalStateException("Automatic browser-dialog acceptance requires browser_evaluate."));
        String script = """
                (() => {
                  if (window.__itpsDialogAutoAcceptInstalled) {
                    return JSON.stringify({installed:true,reused:true});
                  }
                  const messages = [];
                  const remember = (kind, value) => {
                    messages.push({kind, message:String(value ?? '').slice(0,500), at:Date.now()});
                    if (messages.length > 20) messages.shift();
                  };
                  window.__itpsDialogMessages = messages;
                  window.alert = value => { remember('alert', value); };
                  window.confirm = value => { remember('confirm', value); return true; };
                  window.prompt = (value, defaultValue='') => { remember('prompt', value); return String(defaultValue ?? ''); };
                  window.__itpsDialogAutoAcceptInstalled = true;
                  return JSON.stringify({installed:true,reused:false});
                })()
                """;
        JsonNode result = mcp.callTool(evaluate.getName(), expressionArgs(catalog, evaluate, script));
        assertSuccess(evaluate.getName(), result, true);
    }

    void handleHttpsSecurityWarning(McpClient mcp, McpToolCatalog catalog, RunConfig config) throws Exception {
        if (!config.isHandleHttpsSecurityWarning()) return;
        McpTool evaluate = catalog.evaluateTool().orElseThrow(() ->
                new IllegalStateException("HTTPS warning handling requires browser_evaluate."));
        String script = """
                (() => {
                  const advanced = document.querySelector('#details-button');
                  const beforeProceed = document.querySelector('#proceed-link');
                  const wrapper = document.querySelector('#interstitial-wrapper,.interstitial-wrapper');
                  const privacyTitle = /privacy|certificate|secure|private/i.test(String(document.title || ''));
                  const present = Boolean(advanced || beforeProceed || wrapper || privacyTitle && document.querySelector('#main-message'));
                  if (!present) return JSON.stringify({state:'NOT_PRESENT'});
                  if (advanced) advanced.click();
                  const proceed = document.querySelector('#proceed-link');
                  if (!proceed) {
                    return JSON.stringify({state:'BLOCKED',reason:'No Proceed link is available. The site may enforce HSTS.'});
                  }
                  setTimeout(() => proceed.click(), 0);
                  return JSON.stringify({state:'PROCEED_SCHEDULED'});
                })()
                """;
        JsonNode raw;
        try {
            raw = mcp.callTool(evaluate.getName(), expressionArgs(catalog, evaluate, script));
            assertSuccess(evaluate.getName(), raw, true);
        } catch (Exception e) {
            throw new IllegalStateException("Unable to inspect or handle the Chrome HTTPS security-warning page.");
        }
        JsonNode parsed = unwrapJsonString(raw);
        String state = parsed.path("state").asText("NOT_PRESENT");
        if ("BLOCKED".equalsIgnoreCase(state)) {
            throw new IllegalStateException("Chrome displayed an HTTPS warning without a Proceed option, usually because HSTS blocks bypass.");
        }
        if ("PROCEED_SCHEDULED".equalsIgnoreCase(state)) sleep(1_200);
    }

    void waitUntilHomeReady(McpClient mcp, McpToolCatalog catalog, RunConfig config) throws Exception {
        int timeoutMs = Math.max(5_000, Math.min(config.getManualAuthTimeoutSeconds(), 900) * 1_000);
        String selector = trim(config.getHomeReadySelector());
        String text = trim(config.getHomeReadyText());

        if (!selector.isEmpty()) waitForSelector(mcp, catalog, selector, timeoutMs);
        if (!text.isEmpty()) waitForText(mcp, catalog, text, timeoutMs);
        if (selector.isEmpty() && text.isEmpty()) waitForDocumentReady(mcp, catalog, timeoutMs);
    }

    private void waitForSelector(McpClient mcp, McpToolCatalog catalog, String selector, int timeoutMs) throws Exception {
        Optional<McpTool> wait = catalog.waitTool().filter(t -> catalog.hasInputProperty(t, "selector"));
        if (wait.isPresent()) {
            Map<String, Object> args = new LinkedHashMap<>();
            args.put("selector", selector);
            if (catalog.hasInputProperty(wait.get(), "state")) args.put("state", "visible");
            putTimeout(catalog, wait.get(), args, timeoutMs);
            JsonNode result = mcp.callTool(wait.get().getName(), args);
            assertSuccess(wait.get().getName(), result, true);
            return;
        }
        pollExpression(mcp, catalog,
                "Boolean(document.querySelector(" + json(selector) + ") && document.querySelector(" + json(selector) + ").getClientRects().length)",
                timeoutMs, "Home readiness selector was not visible: " + selector);
    }

    private void waitForText(McpClient mcp, McpToolCatalog catalog, String expected, int timeoutMs) throws Exception {
        Optional<McpTool> wait = catalog.waitForTextTool().filter(t -> catalog.hasInputProperty(t, "text"));
        if (wait.isPresent()) {
            Map<String, Object> args = new LinkedHashMap<>();
            args.put("text", expected);
            putTimeout(catalog, wait.get(), args, timeoutMs);
            JsonNode result = mcp.callTool(wait.get().getName(), args);
            assertSuccess(wait.get().getName(), result, true);
            return;
        }
        pollExpression(mcp, catalog,
                "String(document.body?.innerText || '').includes(" + json(expected) + ")",
                timeoutMs, "Home readiness text was not displayed: " + expected);
    }

    private void waitForDocumentReady(McpClient mcp, McpToolCatalog catalog, int timeoutMs) throws Exception {
        pollExpression(mcp, catalog,
                "document.readyState === 'complete' || document.readyState === 'interactive'",
                timeoutMs, "Application page did not reach a ready state.");
    }

    private void pollExpression(McpClient mcp, McpToolCatalog catalog, String expression,
                                int timeoutMs, String failure) throws Exception {
        Optional<McpTool> wait = catalog.waitForFunctionTool().filter(t ->
                catalog.hasInputProperty(t, "expression") || catalog.hasInputProperty(t, "script"));
        if (wait.isPresent()) {
            Map<String, Object> args = new LinkedHashMap<>();
            String property = catalog.firstInputProperty(wait.get(), "expression", "script").orElse("expression");
            args.put(property, expression);
            putTimeout(catalog, wait.get(), args, timeoutMs);
            JsonNode result = mcp.callTool(wait.get().getName(), args);
            assertSuccess(wait.get().getName(), result, true);
            return;
        }

        McpTool evaluate = catalog.evaluateTool().orElseThrow(() -> new IllegalStateException(failure));
        long deadline = System.currentTimeMillis() + timeoutMs;
        while (System.currentTimeMillis() < deadline) {
            JsonNode result = mcp.callTool(evaluate.getName(), expressionArgs(catalog, evaluate,
                    "JSON.stringify({ready:Boolean(" + expression + ")})"));
            JsonNode parsed = unwrapJsonString(result);
            if (parsed.path("ready").asBoolean(false)) return;
            sleep(500);
        }
        throw new IllegalStateException(failure);
    }

    private void replaceCookieValue(McpClient mcp, McpToolCatalog catalog, RunConfig config, String currentUrl) throws Exception {
        String name = trim(config.getCookieName());
        String newValue = config.getCookieValue() == null ? "" : config.getCookieValue();
        validateCookieInput(name, newValue);
        mcp.registerSecret(newValue);

        CookieSnapshot before;
        try {
            before = readSingleCookie(mcp, catalog, name, currentUrl);
            mcp.registerSecret(before.value());
        } catch (Exception e) {
            throw new IllegalStateException(compact(safeMessage(e), 700));
        }

        boolean changed = false;
        try {
            if (before.httpOnly()) {
                setHttpOnlyCookie(mcp, catalog, before, newValue, currentUrl);
            } else {
                setScriptVisibleCookie(mcp, catalog, before, newValue, currentUrl);
            }
            changed = true;
            CookieSnapshot after = readSingleCookie(mcp, catalog, name, currentUrl);
            if (!Objects.equals(after.value(), newValue)) {
                throw new IllegalStateException("The cookie value was not replaced.");
            }
            List<String> differences = metadataDifferences(before, after);
            if (!differences.isEmpty()) {
                throw new IllegalStateException("Cookie attributes changed unexpectedly: " + String.join(", ", differences));
            }
        } catch (Exception e) {
            if (changed) rollbackCookieQuietly(mcp, catalog, before, currentUrl);
            String message = safeMessage(e);
            if (message.contains(newValue) || message.contains(before.value())) message = REDACTED_COOKIE_ERROR;
            throw new IllegalStateException(compact(message, 700));
        }
    }

    private CookieSnapshot readSingleCookie(McpClient mcp, McpToolCatalog catalog,
                                            String name, String currentUrl) throws Exception {
        McpTool get = catalog.getCookiesTool().orElseThrow(() ->
                new IllegalStateException("Installed Vibium does not expose browser_get_cookies."));
        JsonNode raw = mcp.callToolSensitive(get.getName(), Map.of());
        assertSuccess(get.getName(), raw, false);
        List<CookieSnapshot> matches = extractCookies(raw).stream()
                .filter(cookie -> name.equals(cookie.name()))
                .filter(cookie -> cookieAppliesTo(cookie, currentUrl))
                .toList();
        if (matches.isEmpty()) {
            throw new IllegalStateException("Cookie '" + name + "' was not found for the current application page. No cookie was created.");
        }
        if (matches.size() > 1) {
            throw new IllegalStateException("More than one applicable cookie named '" + name + "' exists. Specify a unique cookie name; no cookie was changed.");
        }
        return matches.get(0);
    }

    private void setScriptVisibleCookie(McpClient mcp, McpToolCatalog catalog, CookieSnapshot cookie,
                                        String value, String currentUrl) throws Exception {
        McpTool evaluate = catalog.evaluateTool().orElseThrow(() ->
                new IllegalStateException("Replacing a non-HttpOnly cookie safely requires browser_evaluate."));
        String assignment = cookieAssignment(cookie, value, currentUrl);
        String script = "(() => { document.cookie = " + json(assignment)
                + "; return JSON.stringify({updated:true}); })()";
        JsonNode raw = mcp.callToolSensitive(evaluate.getName(), expressionArgs(catalog, evaluate, script));
        assertSuccess(evaluate.getName(), raw, false);
    }

    private void setHttpOnlyCookie(McpClient mcp, McpToolCatalog catalog, CookieSnapshot cookie,
                                   String value, String currentUrl) throws Exception {
        McpTool set = catalog.setCookieTool().orElseThrow(() ->
                new IllegalStateException("Installed Vibium does not expose browser_set_cookie."));
        List<String> missing = new ArrayList<>();
        if (cookie.secure() && !catalog.hasInputProperty(set, "secure")) missing.add("secure");
        if (!catalog.hasInputProperty(set, "httpOnly") && !catalog.hasInputProperty(set, "http_only")) missing.add("httpOnly");
        if (!cookie.sameSite().isEmpty() && !catalog.hasInputProperty(set, "sameSite") && !catalog.hasInputProperty(set, "same_site")) missing.add("sameSite");
        if (cookie.expiryEpochSeconds() != null && !catalog.hasInputProperty(set, "expires") && !catalog.hasInputProperty(set, "expiry")) missing.add("expiry");
        if (cookie.hostOnly() && !catalog.hasInputProperty(set, "url")) missing.add("hostOnly");
        if (!cookie.hostOnly() && !catalog.hasInputProperty(set, "domain")) missing.add("domain");
        if (!"/".equals(cookie.path()) && !catalog.hasInputProperty(set, "path")) missing.add("path");
        if (cookie.partitioned() && !catalog.hasInputProperty(set, "partitioned")) missing.add("Partitioned");
        if (!cookie.priority().isEmpty() && !catalog.hasInputProperty(set, "priority")) missing.add("Priority");
        if (!missing.isEmpty()) {
            throw new IllegalStateException("Installed Vibium cannot safely replace this HttpOnly cookie while preserving "
                    + String.join(", ", missing) + ". The cookie was not changed.");
        }

        Map<String, Object> args = new LinkedHashMap<>();
        args.put("name", cookie.name());
        args.put("value", value);
        if (cookie.hostOnly() && catalog.hasInputProperty(set, "url")) args.put("url", currentUrl);
        else if (catalog.hasInputProperty(set, "domain")) args.put("domain", cookie.domain());
        if (catalog.hasInputProperty(set, "path")) args.put("path", cookie.path());
        putIfAccepted(catalog, set, args, cookie.secure(), "secure");
        putIfAccepted(catalog, set, args, cookie.httpOnly(), "httpOnly", "http_only");
        putIfAccepted(catalog, set, args, cookie.sameSite(), "sameSite", "same_site");
        putIfAccepted(catalog, set, args, cookie.expiryEpochSeconds(), "expires", "expiry");
        putIfAccepted(catalog, set, args, cookie.priority(), "priority");
        putIfAccepted(catalog, set, args, cookie.partitioned(), "partitioned");
        JsonNode raw = mcp.callToolSensitive(set.getName(), args);
        assertSuccess(set.getName(), raw, false);
    }

    private void rollbackCookieQuietly(McpClient mcp, McpToolCatalog catalog,
                                       CookieSnapshot original, String currentUrl) {
        try {
            if (original.httpOnly()) setHttpOnlyCookie(mcp, catalog, original, original.value(), currentUrl);
            else setScriptVisibleCookie(mcp, catalog, original, original.value(), currentUrl);
        } catch (Exception ignored) {
            // The original value is never exposed in the lifecycle error or diagnostic transcript.
        }
    }

    String cookieAssignment(CookieSnapshot cookie, String value, String currentUrl) {
        StringBuilder out = new StringBuilder(cookie.name()).append('=').append(value);
        out.append("; Path=").append(cookie.path());
        if (!cookie.hostOnly()) out.append("; Domain=").append(cookie.domain());
        if (cookie.secure()) out.append("; Secure");
        if (!cookie.sameSite().isEmpty()) out.append("; SameSite=").append(displaySameSite(cookie.sameSite()));
        if (cookie.expiryEpochSeconds() != null) {
            out.append("; Expires=").append(DateTimeFormatter.RFC_1123_DATE_TIME
                    .withZone(ZoneOffset.UTC).format(Instant.ofEpochSecond(cookie.expiryEpochSeconds())));
        }
        if (cookie.partitioned()) out.append("; Partitioned");
        if (!cookie.priority().isEmpty()) out.append("; Priority=").append(cookie.priority());
        return out.toString();
    }

    List<CookieSnapshot> extractCookies(JsonNode raw) {
        JsonNode parsed = unwrapJsonString(raw);
        List<JsonNode> nodes = new ArrayList<>();
        collectCookieNodes(parsed, nodes);
        List<CookieSnapshot> out = new ArrayList<>();
        Set<String> unique = new LinkedHashSet<>();
        for (JsonNode node : nodes) {
            CookieSnapshot cookie = cookieFrom(node);
            String key = cookie.name() + "\n" + cookie.domain() + "\n" + cookie.path() + "\n" + cookie.value();
            if (unique.add(key)) out.add(cookie);
        }
        return out;
    }

    private void collectCookieNodes(JsonNode node, List<JsonNode> out) {
        if (node == null || node.isNull() || node.isMissingNode()) return;
        if (node.isTextual()) {
            String text = node.asText().trim();
            if (text.startsWith("{") || text.startsWith("[")) {
                try { collectCookieNodes(mapper.readTree(text), out); } catch (Exception ignored) { }
            }
            return;
        }
        if (node.isObject()) {
            if (node.has("name") && node.has("value") && (node.has("domain") || node.has("path"))) out.add(node);
            node.fields().forEachRemaining(entry -> collectCookieNodes(entry.getValue(), out));
        } else if (node.isArray()) {
            for (JsonNode child : node) collectCookieNodes(child, out);
        }
    }

    private CookieSnapshot cookieFrom(JsonNode node) {
        String name = stringField(node, "name");
        String value = stringField(node, "value");
        String domain = stringField(node, "domain");
        String path = defaultIfBlank(stringField(node, "path"), "/");
        boolean secure = booleanField(node, "secure");
        boolean httpOnly = booleanField(node, "httpOnly", "http_only");
        String sameSite = normalizeSameSite(stringField(node, "sameSite", "same_site"));
        Long expiry = longField(node, "expiry", "expires", "expirationDate");
        if (expiry != null && expiry <= 0) expiry = null;
        if (expiry != null && expiry > 10_000_000_000L) expiry /= 1_000;
        boolean explicitHostOnly = node.has("hostOnly") || node.has("host_only");
        boolean hostOnly = explicitHostOnly ? booleanField(node, "hostOnly", "host_only") : !domain.startsWith(".");
        boolean partitioned = booleanField(node, "partitioned");
        String priority = stringField(node, "priority");
        return new CookieSnapshot(name, value, domain, path, secure, httpOnly, sameSite, expiry, hostOnly, partitioned, priority);
    }

    List<String> metadataDifferences(CookieSnapshot before, CookieSnapshot after) {
        List<String> differences = new ArrayList<>();
        if (!normalizeDomain(before.domain()).equals(normalizeDomain(after.domain()))) differences.add("domain");
        if (!Objects.equals(before.path(), after.path())) differences.add("path");
        if (before.secure() != after.secure()) differences.add("Secure");
        if (before.httpOnly() != after.httpOnly()) differences.add("HttpOnly");
        if (!Objects.equals(before.sameSite(), after.sameSite())) differences.add("SameSite");
        if (!expiryEqual(before.expiryEpochSeconds(), after.expiryEpochSeconds())) differences.add("expiry");
        if (before.hostOnly() != after.hostOnly()) differences.add("hostOnly");
        if (before.partitioned() != after.partitioned()) differences.add("Partitioned");
        if (!equalsIgnoreCase(before.priority(), after.priority())) differences.add("Priority");
        return differences;
    }

    boolean cookieAppliesTo(CookieSnapshot cookie, String currentUrl) {
        if (blank(currentUrl)) return true;
        try {
            URI uri = URI.create(currentUrl);
            String host = defaultIfBlank(uri.getHost(), "").toLowerCase(Locale.ROOT);
            String domain = normalizeDomain(cookie.domain());
            boolean domainMatch = cookie.hostOnly() ? host.equals(domain) : host.equals(domain) || host.endsWith("." + domain);
            String requestPath = defaultIfBlank(uri.getPath(), "/");
            String cookiePath = defaultIfBlank(cookie.path(), "/");
            boolean pathMatch = requestPath.equals(cookiePath)
                    || requestPath.startsWith(cookiePath.endsWith("/") ? cookiePath : cookiePath + "/");
            return domainMatch && pathMatch;
        } catch (Exception ignored) {
            return true;
        }
    }

    private void closeExtraPagesQuietly(McpClient mcp, McpToolCatalog catalog) {
        Optional<McpTool> listTool = catalog.listPagesTool();
        Optional<McpTool> closeTool = catalog.closePageTool();
        if (listTool.isEmpty() || closeTool.isEmpty()) return;
        try {
            JsonNode raw = mcp.callTool(listTool.get().getName(), Map.of());
            int count = pageCount(unwrapJsonString(raw));
            for (int index = count - 1; index >= 1; index--) {
                Map<String, Object> args = indexArgs(catalog, closeTool.get(), index);
                mcp.callTool(closeTool.get().getName(), args);
            }
            Optional<McpTool> switchTool = catalog.switchPageTool();
            if (switchTool.isPresent()) mcp.callTool(switchTool.get().getName(), indexArgs(catalog, switchTool.get(), 0));
        } catch (Exception ignored) {
            // Extra page cleanup is best effort; deterministic Home navigation remains authoritative.
        }
    }

    private int pageCount(JsonNode node) {
        if (node == null) return 1;
        if (node.isArray()) return Math.max(1, node.size());
        if (node.isObject()) {
            for (String key : List.of("pages", "tabs", "contexts")) if (node.path(key).isArray()) return Math.max(1, node.path(key).size());
            Iterator<JsonNode> children = node.elements();
            while (children.hasNext()) {
                int count = pageCount(children.next());
                if (count > 1) return count;
            }
        }
        return 1;
    }

    private void acceptOpenDialogQuietly(McpClient mcp, McpToolCatalog catalog) {
        catalog.dialogAcceptTool().ifPresent(tool -> {
            try { mcp.callTool(tool.getName(), Map.of()); } catch (Exception ignored) { }
        });
    }

    private void navigate(McpClient mcp, McpToolCatalog catalog, String url) throws Exception {
        McpTool tool = catalog.navigateTool().orElseThrow(() ->
                new IllegalStateException("Installed Vibium does not expose a navigation tool."));
        Map<String, Object> args = new LinkedHashMap<>();
        String property = catalog.firstInputProperty(tool, "url", "uri", "target").orElse("url");
        args.put(property, url);
        JsonNode result = mcp.callTool(tool.getName(), args);
        assertSuccess(tool.getName(), result, true);
    }

    private Map<String, Object> expressionArgs(McpToolCatalog catalog, McpTool tool, String script) {
        String property = catalog.firstInputProperty(tool, "expression", "script", "code").orElse("expression");
        return Map.of(property, script);
    }

    private Map<String, Object> indexArgs(McpToolCatalog catalog, McpTool tool, int index) {
        String property = catalog.firstInputProperty(tool, "index", "pageIndex", "tabIndex").orElse("index");
        return Map.of(property, index);
    }

    private void putTimeout(McpToolCatalog catalog, McpTool tool, Map<String, Object> args, int timeoutMs) {
        catalog.firstInputProperty(tool, "timeout", "timeoutMs").ifPresent(property -> args.put(property, timeoutMs));
    }

    private void putIfAccepted(McpToolCatalog catalog, McpTool tool, Map<String, Object> args,
                               Object value, String... candidates) {
        if (value == null || value instanceof String string && string.isBlank()) return;
        catalog.firstInputProperty(tool, candidates).ifPresent(property -> args.put(property, value));
    }

    private void assertSuccess(String toolName, JsonNode result, boolean includeDetails) {
        if (result == null || result.isMissingNode()) return;
        if (result.path("isError").asBoolean(false)) {
            throw new IllegalStateException(includeDetails
                    ? "MCP tool failed: " + toolName + ". " + compact(extractText(result), 700)
                    : REDACTED_COOKIE_ERROR);
        }
        String text = extractText(result).toLowerCase(Locale.ROOT);
        for (String fatal : List.of("timeout", "timed out", "failed", "error:", "exception", "unable to", "cannot")) {
            if (text.contains(fatal)) {
                throw new IllegalStateException(includeDetails
                        ? "MCP tool failed: " + toolName + ". " + compact(extractText(result), 700)
                        : REDACTED_COOKIE_ERROR);
            }
        }
    }

    private JsonNode unwrapJsonString(JsonNode raw) {
        if (raw == null) return mapper.createObjectNode();
        List<String> texts = new ArrayList<>();
        collectText(raw, texts);
        texts.sort(Comparator.comparingInt(String::length).reversed());
        for (String text : texts) {
            String trimmed = text.trim();
            if (!trimmed.startsWith("{") && !trimmed.startsWith("[")) continue;
            try { return mapper.readTree(trimmed); } catch (Exception ignored) { }
        }
        return raw;
    }

    private void collectText(JsonNode node, List<String> out) {
        if (node == null) return;
        if (node.isTextual()) out.add(node.asText());
        else if (node.isArray()) for (JsonNode child : node) collectText(child, out);
        else if (node.isObject()) node.fields().forEachRemaining(entry -> collectText(entry.getValue(), out));
    }

    private String extractText(JsonNode node) {
        if (node == null) return "";
        if (node.isValueNode()) return node.asText();
        StringBuilder out = new StringBuilder();
        if (node.isArray()) for (JsonNode child : node) out.append(' ').append(extractText(child));
        else if (node.isObject()) node.fields().forEachRemaining(entry -> out.append(' ').append(extractText(entry.getValue())));
        return out.toString();
    }

    private String stringField(JsonNode node, String... names) {
        for (String name : names) {
            JsonNode value = node.path(name);
            if (value.isTextual() || value.isNumber() || value.isBoolean()) return value.asText();
            JsonNode nested = value.path("value");
            if (nested.isTextual() || nested.isNumber() || nested.isBoolean()) return nested.asText();
        }
        return "";
    }

    private boolean booleanField(JsonNode node, String... names) {
        String value = stringField(node, names);
        return "true".equalsIgnoreCase(value) || "1".equals(value);
    }

    private Long longField(JsonNode node, String... names) {
        String value = stringField(node, names);
        if (value.isBlank()) return null;
        try { return Math.round(Double.parseDouble(value)); } catch (Exception ignored) { return null; }
    }

    private void validateCookieInput(String name, String value) {
        if (name.isBlank()) throw new IllegalArgumentException("Cookie name is required when cookie replacement is enabled.");
        if (!name.matches("^[!#$%&'*+\\-.^_`|~0-9A-Za-z]+$")) throw new IllegalArgumentException("Cookie name contains invalid characters.");
        if (value.isBlank()) throw new IllegalArgumentException("New cookie value is required when cookie replacement is enabled.");
        if (value.length() < 4) throw new IllegalArgumentException("New cookie value must contain at least 4 characters.");
        if (value.length() > 16_384) throw new IllegalArgumentException("Cookie value exceeds the supported 16 KB safety limit.");
        for (int index = 0; index < value.length(); index++) {
            char character = value.charAt(index);
            if (character <= 0x20 || character >= 0x7f
                    || character == '"' || character == ',' || character == ';' || character == '\\') {
                throw new IllegalArgumentException("Cookie value contains a character that is unsafe in a Set-Cookie value.");
            }
        }
    }

    private boolean expiryEqual(Long first, Long second) {
        if (first == null || second == null) return Objects.equals(first, second);
        return Math.abs(first - second) <= 2;
    }

    private String normalizeDomain(String value) {
        String domain = trim(value).toLowerCase(Locale.ROOT);
        return domain.startsWith(".") ? domain.substring(1) : domain;
    }

    private String normalizeSameSite(String value) {
        String sameSite = trim(value).toLowerCase(Locale.ROOT).replace('-', '_');
        if (Set.of("no_restriction", "none").contains(sameSite)) return "none";
        if (Set.of("lax", "strict").contains(sameSite)) return sameSite;
        return sameSite;
    }

    private String displaySameSite(String value) {
        if (value.isBlank()) return "";
        return Character.toUpperCase(value.charAt(0)) + value.substring(1).toLowerCase(Locale.ROOT);
    }

    private String json(String value) {
        try { return mapper.writeValueAsString(value); }
        catch (Exception e) { throw new IllegalArgumentException("Unable to encode browser lifecycle value."); }
    }

    private boolean equalsIgnoreCase(String first, String second) {
        return trim(first).equalsIgnoreCase(trim(second));
    }

    private String safeMessage(Exception error) {
        String message = error == null ? "Unknown browser lifecycle failure." : error.getMessage();
        return blank(message) ? error.getClass().getSimpleName() : message;
    }

    private String compact(String value, int max) {
        String text = value == null ? "" : value.replaceAll("\\s+", " ").trim();
        return text.length() <= max ? text : text.substring(0, max) + "...";
    }

    private String trim(String value) { return value == null ? "" : value.trim(); }
    private boolean blank(String value) { return value == null || value.isBlank(); }
    private String defaultIfBlank(String value, String fallback) { return blank(value) ? fallback : value; }
    private void sleep(long millis) {
        try { Thread.sleep(millis); }
        catch (InterruptedException e) { Thread.currentThread().interrupt(); }
    }

    record ResetResult(String status, String message) { }

    record CookieSnapshot(String name, String value, String domain, String path,
                          boolean secure, boolean httpOnly, String sameSite,
                          Long expiryEpochSeconds, boolean hostOnly,
                          boolean partitioned, String priority) { }
}
