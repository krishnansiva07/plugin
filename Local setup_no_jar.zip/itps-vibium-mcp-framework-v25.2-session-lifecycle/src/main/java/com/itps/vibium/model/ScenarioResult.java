package com.itps.vibium.model;

import java.util.ArrayList;
import java.util.List;

public class ScenarioResult {
    private String id;
    private String name;
    private String url;
    private String status;
    private long durationMs;
    private String errorMessage;
    private String sourceSheet;
    private String workerId;
    private String homeResetStatus;
    private String homeResetMessage;
    private List<StepResult> steps = new ArrayList<>();

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getUrl() { return url; }
    public void setUrl(String url) { this.url = url; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public long getDurationMs() { return durationMs; }
    public void setDurationMs(long durationMs) { this.durationMs = durationMs; }
    public String getErrorMessage() { return errorMessage; }
    public void setErrorMessage(String errorMessage) { this.errorMessage = errorMessage; }
    public String getSourceSheet() { return sourceSheet; }
    public void setSourceSheet(String sourceSheet) { this.sourceSheet = sourceSheet; }
    public String getWorkerId() { return workerId; }
    public void setWorkerId(String workerId) { this.workerId = workerId; }
    public String getHomeResetStatus() { return homeResetStatus; }
    public void setHomeResetStatus(String homeResetStatus) { this.homeResetStatus = homeResetStatus; }
    public String getHomeResetMessage() { return homeResetMessage; }
    public void setHomeResetMessage(String homeResetMessage) { this.homeResetMessage = homeResetMessage; }
    public List<StepResult> getSteps() { return steps; }
    public void setSteps(List<StepResult> steps) { this.steps = steps; }
}
