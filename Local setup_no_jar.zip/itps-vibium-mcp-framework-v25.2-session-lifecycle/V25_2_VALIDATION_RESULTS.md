# V25.2 Validation Results

Validation date: 2026-08-15

## Clean Java build

Command:

```text
mvn clean package
```

Result: PASS

- Tests: 30
- Failures: 0
- Errors: 0
- Executable JAR: `target/itps-vibium-mcp-framework-25.2.0-SESSION-LIFECYCLE.jar`
- JAR size: 39,199,759 bytes

Coverage includes the original deterministic executors and recorder tests plus new tests for:

- lifecycle default compatibility;
- cookie value-only attribute construction and verification;
- nested cookie-result parsing and path matching;
- MCP secret/JWT/authorization redaction;
- current lifecycle/dialog/cookie/page tool discovery;
- selected multi-sheet combination and duplicate-ID handling;
- source-sheet, worker and Home-reset HTML/JSON/Excel reporting;
- two parallel fake-MCP workers with isolated browser state and Home reset after every scenario.

## Local MCP bridge

Commands:

```text
node --check tools/local-mcp-bridge/local-mcp-bridge.js
node --check tools/local-mcp-bridge/test-local-mcp-bridge.js
node tools/local-mcp-bridge/test-local-mcp-bridge.js
```

Result: PASS

- Two simultaneous TCP clients received isolated child MCP sessions.
- The third client was rejected at the configured two-client test limit.
- Session cleanup completed successfully.

## UI and configuration

Result: PASS

- `app.js` syntax check passed.
- Bridge and portable-package JSON parsed successfully.
- All macOS/Linux shell scripts passed `bash -n`.
- The executable JAR started Spring Boot 3.2.6 on a temporary localhost port.
- HTTP `/` returned the V25.2 UI containing HTTPS warning, execution mode, Home reset and cookie fields.
- HTTP `/api/browsers` returned the browser-discovery JSON successfully.

## Environment-dependent validation boundary

The package cannot simulate the organization's real application, client certificate, Smart Card middleware/PIN, HSTS policy or LLM service. Final acceptance in that environment should confirm:

1. manual Windows certificate/PIN completion in headed sequential mode;
2. the chosen Home readiness selector/text;
3. whether the target cookie is HttpOnly and whether the installed Vibium schema can preserve it;
4. Chromium Advanced/Proceed availability for the specific certificate warning;
5. one manual authentication per parallel browser when parallel mode is used.

No certificate, PIN, production URL, JWT or LLM credential is included in this deliverable.
