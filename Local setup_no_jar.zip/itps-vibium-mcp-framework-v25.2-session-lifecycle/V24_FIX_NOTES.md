# V24 — Native-First Execution Engine

## Why both supplied cases failed

The failures were caused by execution-layer gaps rather than an LLM quality problem.

### Case 1 — datatable XPath click

The XPath itself is syntactically acceptable, but it points to a structural `datatable-body-cell`. V23 resolved the node and generated JavaScript pointer/mouse events. Complex Angular/datatable applications can ignore or behave differently for synthetic events, and a cell may contain a smaller real action surface. V24 now re-resolves the current node, performs a hit test, refines the target to the descendant actually under the click point, and uses Vibium's native click command.

### Case 2 — searchable Entity Code dropdown

Three independent gaps were present:

1. `//*[@id='entityCode']/div/div/div[2]/input` targets an internal `ng-select` input. That input can be hidden or zero-sized before the custom control is opened. V24 promotes it to the visible combobox/control proxy for click actions.
2. `Type "BCEF"` was a focus-dependent generic LLM action. V24 treats standalone typing as a deterministic focused-input action and verifies the final value.
3. `Click "BCEF" using visible text` was not recognised by the V23 dropdown phrase matcher. It fell through to generic planning and could choose a hidden duplicate. V24 resolves exact visible text from the live page/active overlay without LLM locator selection.

## New execution pipeline

```text
Fresh observation
  -> explicit XPath / exact visible text / active-input routing
  -> live DOM resolution
  -> hidden-child/custom-control proxy promotion
  -> scroll + multi-point hit test
  -> short-lived unique marker
  -> native Vibium click/fill
  -> fresh post-action read
  -> strict postcondition verification
  -> fresh re-resolution retry when required
```

## Key changes

- Explicit XPath has absolute priority over LLM locator generation.
- Native Vibium pointer/keyboard input is preferred over JavaScript `.click()` and direct value assignment.
- Same-origin frames and open shadow roots are searched during resolution and cleanup.
- Hidden internal inputs are promoted to visible `ng-select`, Material, PrimeNG, Ant, Select2, combobox, or popup proxies.
- Structural table/grid cells are refined to the hit-tested descendant at the actual click point.
- Exact-visible-text steps are deterministic and overlay-aware.
- Standalone type/enter/fill steps target the active or expanded combobox input.
- Every attempt receives a fresh DOM resolution; stale markers are removed.
- Dropdown options are not blindly double-clicked after an unconfirmed first action.
- A step passes only after final value, selected state, overlay change, URL change, focus/state change, or DOM change is observed.
- Technical reports record the strategy, interaction mode, resolution evidence, and confirmation evidence.

## Input review

Your original lines are accepted in V24. They are not fundamentally malformed. The main issue was that some of them are structurally brittle or rely on focus.

### Current datatable input

```text
Click on the white strip using xpath="//datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[1]/datatable-body-cell[1]"
```

Status: valid, but tied to the complete component hierarchy and the first row. V24 can execute it. The semantic form is more maintainable:

```text
Click the white action stripe in the first visible data row
```

### Current Entity Code input

```text
Click using xpath="//*[@id='entityCode']/div/div/div[2]/input"
```

Status: valid but overly brittle and points to an internal input. Prefer:

```text
Click using xpath="//*[@id='entityCode']"
```

or, when typing in the same step:

```text
Type "BCEF" using xpath="//*[@id='entityCode']//input"
```

### Current option input

```text
Click "BCEF" using visible text
```

Status: clear and correct. V23 did not route this phrase correctly; V24 does.

### Current clear input

```text
Click "Clear all" in sub entity using xpath="//*[@id='subEntityCode']//span[@title='Clear all']"
```

Status: valid, but the `span` may be decorative. V24 promotes it to a clickable ancestor. A less tag-dependent form is:

```text
Click "Clear all" in sub entity using xpath="//*[@id='subEntityCode']//*[@title='Clear all']"
```

## Honest boundary

No DOM automation framework can guarantee every application. Closed shadow roots, cross-origin iframe internals, canvas-only controls, native OS dialogs, CAPTCHA/anti-bot controls, and inaccessible remote browser content require application-specific support or a different integration route. V24 covers the normal difficult enterprise cases: dynamic Angular/React/Vue DOMs, virtualised overlays, custom comboboxes, same-origin frames, open shadow DOM, datatables, and stale re-rendering.
