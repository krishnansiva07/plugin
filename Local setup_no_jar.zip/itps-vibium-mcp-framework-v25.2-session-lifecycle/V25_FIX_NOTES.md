# V25 Fix Notes — Optional UI Action Recorder

## Goal

Add recording without changing the normal Excel execution flow. Recording is opt-in. The application URL is mandatory only after the recorder is enabled.

## UI changes

- Added **Record UI actions and generate Excel steps** toggle.
- Added mandatory recorder application URL.
- Reuses the existing installed-browser selection.
- Recorder always launches headed mode.
- Added Start, Stop, Copy Steps, Download Excel and Download JSON actions.
- Shows each generated step, primary locator, fallback locator and source page.
- Allows captured actions to be deleted before export.

## Recording engine

`UiRecorderService` starts a separate Vibium MCP browser session and injects `recorder-inject.js` with `browser_evaluate`.

The injected script:

- uses trusted capture-phase browser events;
- uses `event.composedPath()` to resolve the actionable node;
- preserves action order by flushing pending typing before click/change/key events;
- collapses browser click/click/double-click event sequences into one double-click step and avoids duplicate keyboard-generated clicks;
- captures click, double-click, type, select, check/uncheck, Enter/Tab/Escape and upload actions;
- scans same-origin iframe documents and open shadow roots;
- survives same-origin navigation by persisting undrained events in session storage;
- masks password, OTP, CVV, token/secret and card-number-like values;
- produces a primary CSS or XPath locator and a fallback locator.

## Locator priority

1. stable unique ID;
2. `data-testid`, `data-test`, `data-qa`, `data-cy` or automation ID;
3. unique name/ARIA/placeholder/title CSS;
4. role/text or exact visible-text XPath for options/buttons/links;
5. relative CSS path;
6. relative/absolute XPath fallback.

Dynamic Angular/Material classes and obviously generated IDs are avoided where possible.

## Generated step syntax

Examples:

```text
Click "Entity Code" using css="#entityCode"
Type "BCEF" in "Entity Code" using css="#entityCode input"
Click "BCEF" using xpath="//*[@role='option' and normalize-space(.)='BCEF']"
Check "Include archived" using css="input[name='includeArchived']"
Press "Enter" on "Entity Code" using css="#entityCode input"
Upload "${FILE_PATH}" in "Attachment" using css="input[type='file']"
```

## Excel export

The downloaded workbook has two sheets:

- `RecordedScenario`: directly compatible with the existing scenario parser.
- `RecordedActions`: full recording metadata for review and diagnostics.

A text, JSON and Excel copy is also written to `target/itps-vibium-recordings/<session-id>/` when recording stops.

## Execution-engine changes

- Added `LiveCssActionExecutor`.
- Explicit CSS now receives the same absolute priority as explicit XPath.
- Native Vibium selector actions are preferred for top-document elements.
- Same-origin iframe/open-shadow actions can use a DOM fallback when native selector context is unavailable.
- Fill/select/check/uncheck are verified against final state.
- Click/double-click/key actions require an observable URL, overlay, target, context or page-DOM change; MCP completion alone is insufficient.
- CSS failure enters the existing healing flow only after the supplied selector fails.
- Lifecycle tool discovery excludes trace tools such as `browser_record_start` and `browser_record_stop` from browser start/stop selection.

## Known boundaries

- Cross-origin iframe contents and closed shadow roots cannot be recorded by injected page JavaScript.
- Browser-native dialogs and operating-system file chooser interactions are not DOM events.
- Cross-origin navigation can prevent recovery of the final pre-navigation event because session storage is origin-scoped.
- File upload exports `${FILE_PATH}` and requires the user/test data to supply an actual local file path.
- Only one recorder session is active per application instance.
