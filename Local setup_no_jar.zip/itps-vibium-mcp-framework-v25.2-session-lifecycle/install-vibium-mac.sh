#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

command -v node >/dev/null 2>&1 || { echo "ERROR: Node.js is not available in PATH."; exit 1; }
command -v npm >/dev/null 2>&1 || { echo "ERROR: npm is not available in PATH."; exit 1; }

echo "Installing pinned Vibium into tools/vibium-portable..."
npm --prefix tools/vibium-portable install --omit=dev
[[ -x tools/vibium-portable/node_modules/.bin/vibium ]] || { echo "ERROR: Vibium command was not created."; exit 1; }

echo "Installing or verifying Vibium Managed Chrome for Testing..."
tools/vibium-portable/node_modules/.bin/vibium install
echo "Vibium setup completed."
echo "Next: ./start-local-mcp-mac.sh, then ./start-framework-jar-mac.sh"
