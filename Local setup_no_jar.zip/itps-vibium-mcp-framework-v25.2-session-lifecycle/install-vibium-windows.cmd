@echo off
setlocal
cd /d "%~dp0"

where node >nul 2>nul || (echo ERROR: Node.js is not available in PATH.& pause& exit /b 1)
where npm >nul 2>nul || (echo ERROR: npm is not available in PATH.& pause& exit /b 1)

echo Installing pinned Vibium into tools\vibium-portable...
pushd "tools\vibium-portable"
call npm install --omit=dev
if errorlevel 1 (popd& echo ERROR: Vibium npm installation failed.& pause& exit /b 1)

if not exist "node_modules\.bin\vibium.cmd" (
  popd
  echo ERROR: Vibium command was not created.
  pause
  exit /b 1
)

echo Installing or verifying Vibium Managed Chrome for Testing...
call "node_modules\.bin\vibium.cmd" install
if errorlevel 1 (
  echo WARNING: Browser installation failed. If an approved browser cache is supplied separately, copy it before running tests.
  popd
  pause
  exit /b 1
)
popd

echo Vibium setup completed.
echo Next: start-local-mcp-windows.cmd, then start-framework-jar-windows.cmd
pause
exit /b 0
