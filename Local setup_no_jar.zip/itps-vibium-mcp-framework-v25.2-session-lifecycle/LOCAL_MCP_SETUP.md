# ITPS VIBIUM Framework V25.2 — Local Setup and Startup

## Architecture

Vibium MCP communicates through JSON-RPC over standard input/output. The supplied localhost bridge lets the Java application connect to manually managed local Vibium processes without embedding a machine-specific executable path in the JAR.

```text
Framework worker -> TCP 127.0.0.1:8765 -> Local MCP bridge -> isolated Vibium MCP process -> browser
```

Sequential mode uses one worker and one browser for the whole run. Parallel mode opens up to four bridge sessions; each receives its own Vibium process and browser.

Both the Spring Boot server and bridge bind to `127.0.0.1` by default.

## Required software

- Java JDK or JRE 17 or later to run the packaged JAR
- Node.js with npm for the local bridge and Vibium installation
- Maven 3.9 or later only when rebuilding the JAR
- Network access for the one-time npm/browser installation, or a copied approved Vibium folder and browser cache
- Access to the configured LLM endpoint and an appropriate token

Verify:

```text
java -version
node -v
npm -v
mvn -version
```

## Folder structure

```text
itps-vibium-mcp-framework-v25.2/
├── target/
│   └── itps-vibium-mcp-framework-25.2.0-SESSION-LIFECYCLE.jar
├── config/
│   └── application-local.properties
├── tools/
│   ├── vibium-portable/
│   │   ├── package.json
│   │   └── node_modules/.bin/vibium(.cmd)   <- created by installation
│   └── local-mcp-bridge/
│       ├── local-mcp-bridge.js
│       ├── local-mcp-config.json
│       └── test-local-mcp-bridge.js
├── install-vibium-windows.cmd / install-vibium-mac.sh
├── start-local-mcp-windows.cmd / start-local-mcp-mac.sh
└── start-framework-jar-windows.cmd / start-framework-jar-mac.sh
```

## Windows setup

### 1. Extract locally

Use a writable local folder such as:

```text
C:\itps\itps-vibium-mcp-framework-v25.2
```

Avoid running from inside the ZIP, Downloads, OneDrive or a read-only network share.

### 2. Install or copy Vibium

For an online one-time setup, double-click:

```text
install-vibium-windows.cmd
```

This installs the pinned package in `tools\vibium-portable` and runs `vibium install` for Managed Chrome for Testing.

For an offline/approved setup, copy the known-working portable folder so this file exists:

```text
tools\vibium-portable\node_modules\.bin\vibium.cmd
```

When the executable is elsewhere, update `windowsCommand` in `tools\local-mcp-bridge\local-mcp-config.json`. Use doubled backslashes for an absolute Windows JSON path.

### 3. Start the bridge

Double-click and keep open:

```text
start-local-mcp-windows.cmd
```

Expected status:

```text
Listening  : 127.0.0.1:8765
Max clients: 4
Status     : READY - keep this window open
```

### 4. Start the application

Double-click:

```text
start-framework-jar-windows.cmd
```

Then open `http://localhost:8090`.

## macOS setup

Extract to a writable local folder and make scripts executable once:

```bash
chmod +x *.sh tools/local-mcp-bridge/*.sh
```

Install Vibium once, unless a working `tools/vibium-portable` folder was copied:

```bash
./install-vibium-mac.sh
```

Start the bridge and keep the terminal open:

```bash
./start-local-mcp-mac.sh
```

In a second terminal:

```bash
./start-framework-jar-mac.sh
```

Then open `http://localhost:8090`.

## Correct startup order

```text
1. Install/copy Vibium once
2. Start the local MCP bridge and keep it open
3. Start the framework JAR
4. Open the UI
5. Upload Excel/JSON and run
```

Do not separately start `vibium mcp`; the supplied bridge starts one Vibium MCP child for every framework worker and owns its stdio channel.

## Recommended secure-application run

For one manual certificate/Smart Card authentication:

1. Choose **Sequential · one browser**.
2. Keep **Headless** off.
3. Enable **Return to Home after every passed or failed test**.
4. Enter the Home URL and a reliable Home readiness selector or visible text.
5. Select a suitable manual authentication timeout.
6. If Chromium displays its invalid-certificate page, enable **Handle Chrome HTTPS warning**.
7. Click **Run tests**, select the Windows certificate and enter the Smart Card PIN manually.

The same browser remains open for all tests in that sequential run. Every completed or failed test is returned to Home. If Home recovery fails, remaining tests are stopped rather than executed in a contaminated browser state.

## Popup support matrix

| Popup | Handling |
|---|---|
| Chromium invalid-certificate page | Optional automatic Advanced → Proceed |
| Browser JavaScript alert/confirm/prompt | Optional auto-accept plus explicit accept/dismiss steps |
| Windows client-certificate selector | Manual |
| Smart Card middleware/PIN window | Manual |
| HSTS warning with no Proceed link | Cannot bypass; run fails clearly |

## Cookie value replacement

Enable **Replace an existing cookie value before the run**, then provide the cookie name and new value.

- The application page is opened first so the existing cookie can be found.
- Exactly one cookie with that name must apply to the current URL.
- Only the value is changed. Metadata is checked before and after.
- If metadata differs, rollback is attempted and execution stops.
- Cookie values and JWT-shaped strings are redacted from framework diagnostics.
- Current Vibium 26.5.31 cannot express every attribute of an HttpOnly cookie through `browser_set_cookie`. Such a cookie is rejected without modification rather than recreated with weaker attributes.

## Parallel execution

Choose **Parallel · isolated browsers** and 1–4 workers. Scenarios are distributed across workers; each worker executes sequentially inside its own browser.

Important:

- Each browser can show its own Windows certificate/PIN prompt.
- The bridge `maxClients` must be at least the selected worker count.
- Stop the UI recorder before a four-worker run so it does not consume a bridge slot.
- Reports retain original scenario order and include each worker ID.

Bridge capacity is configured in `tools/local-mcp-bridge/local-mcp-config.json`:

```json
{
  "host": "127.0.0.1",
  "port": 8765,
  "maxClients": 4
}
```

It can also be overridden with `ITPS_MCP_MAX_CLIENTS`.

## Multi-sheet execution

After uploading `.xlsx` or `.xls`, select one or more worksheet checkboxes. Enabled rows from every selected sheet are combined. Duplicate IDs are made unique, and source sheet is included in the UI and reports.

## Build the JAR

On a machine with Java 17+ and Maven:

Windows:

```text
build-windows.cmd
```

macOS/Linux:

```bash
./build-mac.sh
```

The executable JAR is written under `target`. Maven is not needed on the target machine when that JAR is present.

## Configuration

`config/application-local.properties` contains the application-side connection:

```properties
itps.vibium.mcp.mode=external-tcp
itps.vibium.mcp.host=127.0.0.1
itps.vibium.mcp.port=8765
itps.vibium.mcp.connect-timeout-seconds=10
itps.vibium.mcp.request-timeout-seconds=90
server.address=127.0.0.1
server.port=8090
```

The host/port must match `tools/local-mcp-bridge/local-mcp-config.json`.

Legacy child-process mode remains available:

```properties
itps.vibium.mcp.mode=process-stdio
itps.vibium.mcp.command=C:\\path\\to\\vibium.cmd
itps.vibium.mcp.args=mcp
```

## Validation

Run:

```text
mvn clean test
node --check src/main/resources/static/app.js
node --check tools/local-mcp-bridge/local-mcp-bridge.js
node tools/local-mcp-bridge/test-local-mcp-bridge.js
```

## Troubleshooting

### Cannot connect to `127.0.0.1:8765`

Start the bridge first. Confirm its port matches `application-local.properties`.

### Vibium command not found

Run the supplied install script, copy a known-working portable folder, or update `windowsCommand`/`macCommand` in `local-mcp-config.json`.

### Browser does not open

Read the bridge terminal and `tools/local-mcp-bridge/logs`. Verify the exact configured Vibium command manually and confirm a browser/cache is installed.

### Parallel worker reports bridge busy

Confirm `maxClients` is at least the requested browser count and stop any recorder or separate run using bridge sessions.

### Home reset fails

Check Home URL, selector/text and timeout. A failed reset marks that worker unhealthy and prevents later tests from using the wrong page.

### HTTPS warning cannot continue

If no Proceed link exists, Chromium is likely enforcing HSTS or policy. Install/trust the correct certificate; the framework does not bypass that control.

### Cookie replacement is rejected

Confirm the page already has exactly one applicable cookie of that name. For HttpOnly cookies, use a Vibium version whose set-cookie schema exposes every original attribute or use the normal authentication flow.

## Logs

Bridge:

```text
tools/local-mcp-bridge/logs/local-mcp-YYYY-MM-DD.log
```

Framework run:

```text
target/itps-vibium-runs/<RUN-ID>/
├── report.html / logs.html / report.xlsx / report.json
├── screenshots.zip
├── mcp-transcript.json / mcp-process.log / mcp-tools.json
└── workers/worker-XX/        (parallel diagnostics)
```
