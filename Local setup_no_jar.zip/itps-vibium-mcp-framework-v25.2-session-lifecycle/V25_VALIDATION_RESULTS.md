# V25 Validation Results

Validation performed in the build workspace on 2026-07-22.

## Passed static and targeted validation

- `recorder-inject.js` passed `node --check`.
- Updated UI `app.js` passed `node --check`.
- Recorder data models and `RecorderPromptFormatter` compiled with Java `--release 17`.
- Prompt smoke test produced the expected direct Excel syntax for CSS type and XPath click steps.
- `LiveCssActionExecutor` compiled against API-compatible temporary stubs, catching Java syntax/type-use errors in the new class.
- Java-generated resolve, DOM-action and confirmation scripts were extracted and each passed `node --check`.
- Escaped quote/backslash parsing in recorded values was exercised in the executor smoke test.
- All main Java sources were parsed by `javac`; no Java syntax/text-block errors were detected. The remaining compiler output was only expected missing third-party dependencies because Maven is unavailable in this environment.
- `pom.xml` parsed as valid XML.
- `index.html` parsed successfully as HTML.
- Recorder lifecycle lookup tests were added to prevent trace-recording tools from being selected as browser start/stop.
- Unit tests were added for prompt generation and generated Excel workbook structure.

## Not executed in this environment

- Full `mvn clean test` / Spring Boot packaging, because Maven and a populated dependency cache are not available in the execution container.
- Live Vibium MCP recording, because the user’s Windows Vibium portable installation and private Angular application are not accessible here.
- Cross-origin iframe or browser-extension-level recording.

## Required local acceptance run

1. Configure the working Vibium command in `application.properties`.
2. Run `mvn clean test`.
3. Run `mvn spring-boot:run`.
4. Record the Entity Code flow: open control, type BCEF, click BCEF.
5. Stop and download Excel.
6. Upload that Excel and execute it.
7. Confirm the report shows `USER_CSS_NATIVE_FIRST_V25` or `USER_XPATH_NATIVE_FIRST_V25`, and that a click without observable UI effect is failed rather than passed.
