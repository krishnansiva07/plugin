package com.llmart.llm.service;

import java.util.List;

/** ELIYA156: requirement-to-step coverage for migration, multi-module and phased requests. */
public class CoverageSmoke {
    static int passed;
    static void check(boolean condition, String message) { if (!condition) throw new AssertionError("FAIL: " + message); passed++; }

    public static void main(String[] args) {
        String migration = "Migrate the checkout tests from Selenium TestNG to Playwright TypeScript for modules cart, payment and shipping. " +
                "Keep src/test/resources/testng.xml as reference and write MIGRATION.md with the mapping.";
        List<AgentRequirementCoverage.Requirement> reqs = AgentRequirementCoverage.extract(migration);
        check(reqs.stream().anyMatch(r -> r.kind().equals("migration source") && r.text().toLowerCase().contains("selenium")), "migration source: " + reqs);
        check(reqs.stream().anyMatch(r -> r.kind().equals("migration target") && r.text().toLowerCase().contains("playwright")), "migration target: " + reqs);
        check(reqs.stream().filter(r -> r.kind().equals("module")).count() == 3, "three modules: " + reqs);
        check(reqs.stream().anyMatch(r -> r.kind().equals("file") && r.text().equals("MIGRATION.md")), "output file");
        check(reqs.stream().anyMatch(r -> r.kind().equals("file") && r.text().endsWith("testng.xml")), "named path");

        List<String> generic = List.of("Inspect the existing tests", "Rewrite the tests in the new framework", "Run the tests");
        List<AgentRequirementCoverage.Requirement> gaps = AgentRequirementCoverage.uncovered(migration, generic);
        check(gaps.size() >= 6, "generic plan misses source, target, modules and files: " + gaps.size());
        check(!AgentRequirementCoverage.gapSummary(migration, generic).isBlank(), "gap summary produced for refinement");

        List<String> specific = List.of(
                "Read src/test/resources/testng.xml and the Selenium TestNG classes for cart, payment and shipping",
                "Create Playwright TypeScript specs for cart and payment, porting page objects",
                "Create Playwright TypeScript specs for shipping",
                "Write MIGRATION.md mapping each TestNG class to its Playwright spec",
                "Run npx playwright test for the three modules and fix failures");
        check(AgentRequirementCoverage.uncovered(migration, specific).isEmpty(), "specific plan covers everything: " +
                AgentRequirementCoverage.uncovered(migration, specific));

        // Gaps that survive refinement become a quoted checklist on the final step; no step is added.
        List<String> partial = List.of("Read testng.xml and the Selenium suites", "Port cart tests to Playwright", "Run the Playwright suite");
        List<String> withChecklist = AgentRequirementCoverage.attachChecklist(migration, partial);
        check(withChecklist.size() == partial.size(), "no step invented");
        String last = withChecklist.get(withChecklist.size() - 1);
        check(last.contains("Requirement checklist") && last.contains("payment") && last.contains("shipping") && last.contains("MIGRATION.md"),
                "missing modules and file listed on final step: " + last);
        check(AgentRequirementCoverage.attachChecklist(migration, specific) == specific, "fully covered plan unchanged");

        // Explicit phases.
        String phased = "Step 1: Analyze the legacy order classes. Step 2: Build the Cucumber framework skeleton. " +
                "Step 3: Migrate order scenarios. Step 4: Run tests and report evidence.";
        List<String> phasePlan = List.of("Analyze legacy order classes in src/main/java/order", "Build the Cucumber framework skeleton under src/test",
                "Migrate the order scenarios to feature files", "Run the tests and report evidence");
        check(AgentRequirementCoverage.uncovered(phased, phasePlan).isEmpty(), "phase plan covered: " + AgentRequirementCoverage.uncovered(phased, phasePlan));
        List<String> skipsPhase = List.of(phasePlan.get(0), phasePlan.get(1), phasePlan.get(3));
        check(AgentRequirementCoverage.uncovered(phased, skipsPhase).stream().anyMatch(r -> r.text().toLowerCase().contains("migrate order")),
                "dropped phase detected");

        // No false requirements from plain requests.
        check(AgentRequirementCoverage.extract("Explain how the retry works").isEmpty(), "plain question has no structural requirements");
        check(AgentRequirementCoverage.extract("Upgrade from Java 11 to Java 17").size() == 2, "upgrade source/target");

        // Parser feeds gaps into the corrective round.
        AgentPlanParser.Draft draft = AgentPlanParser.judge("{\"plan\":[\"Read testng.xml and the Selenium suites\"," +
                "\"Port cart tests to Playwright TypeScript\",\"Write MIGRATION.md\",\"Run npx playwright test\"]}", migration, "## File index\nsrc/test/resources/testng.xml");
        check(draft.usable() && draft.problem().contains("does not cover") && draft.problem().contains("payment"),
                "coverage gaps trigger refinement: " + draft.problem());
        // Existing hard checks still apply first (missing requested Markdown deliverable).
        check(!AgentPlanParser.judge("{\"plan\":[\"Read testng.xml\",\"Port cart tests to Playwright\",\"Run tests\"]}", migration, "").usable(),
                "missing requested deliverable is a hard rejection");
        System.out.println("PASS: " + passed + " ELIYA156 requirement-coverage assertions");
    }
}
