#!/usr/bin/env bash
# ELIYA156: requirement-to-step coverage (migration source/target, modules, phases, files). JDK + Jackson only.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT
if [[ -n "${JACKSON_CP:-}" ]]; then
  CP="$JACKSON_CP"
else
  # Missing offline dependencies must have a visible actionable error, not a
  # silent shell exit through command-substitution / pipefail.
  JACKSON_DIR="${HOME}/.m2/repository/com/fasterxml/jackson/core"
  if [[ -d "$JACKSON_DIR" ]]; then
    CP="$(find "$JACKSON_DIR" -name 'jackson-*.jar' 2>/dev/null | grep -v sources | tr '\n' ':' || true)"
  else
    CP=""
  fi
fi
[[ -n "$CP" ]] || { echo "Jackson jars not found; set JACKSON_CP or run a Maven build once" >&2; exit 2; }
S="$ROOT/src/main/java/com/llmart/llm/service"
javac --release 17 -proc:none -encoding UTF-8 -cp "$CP" -d "$TMP" \
  "$S/AgentRequirementCoverage.java" "$S/MigrationIntent.java" "$S/AgentPlanRecovery.java" "$S/AgentPlanningTerms.java" "$S/AgentPlanParser.java" \
  "$S/AgentPlanSpecificity.java" "$S/AgentPlanJsonEnvelope.java" "$S/AgentPlanStructure.java" "$S/AgentConversationIntent.java" \
  "$S/AgentPlanRelevance.java" "$S/AgentReadOnlySearchPolicy.java" "$ROOT/qa/eliya156-coverage/CoverageSmoke.java"
java -cp "$TMP:$CP" com.llmart.llm.service.CoverageSmoke
