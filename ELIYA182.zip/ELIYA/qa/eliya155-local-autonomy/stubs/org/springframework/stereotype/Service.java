package org.springframework.stereotype;

/** Compile-only stand-in so the offline smoke can compile ChatSettings' dependency without Spring jars. */
@java.lang.annotation.Retention(java.lang.annotation.RetentionPolicy.RUNTIME)
public @interface Service { String value() default ""; }
