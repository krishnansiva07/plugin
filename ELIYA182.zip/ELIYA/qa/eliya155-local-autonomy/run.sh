#!/usr/bin/env bash
# ELIYA155: command policy, budgets, task inbox/schedule parsing, headless settings, git worktree isolation.
# Needs a JDK 17+, git, and Jackson (from ~/.m2 after one Maven build, or JACKSON_CP).
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT
CP="${JACKSON_CP:-}"
if [[ -z "$CP" ]]; then
  CP="$(find "${HOME}/.m2/repository/com/fasterxml/jackson/core" -name 'jackson-*.jar' 2>/dev/null | grep -v sources | tr '\n' ':')"
fi
[[ -n "$CP" ]] || { echo "Jackson jars not found; set JACKSON_CP or run a Maven build once" >&2; exit 2; }
M="$ROOT/src/main/java/com/llmart/llm"
javac --release 17 -proc:none -encoding UTF-8 -cp "$CP" -d "$TMP" \
  "$M/service/AgentCommandPolicy.java" "$M/service/AutonomousRunRegistry.java" "$M/service/ModelCapabilityRegistry.java" \
  "$M/dto/ChatSettings.java" "$M/autonomy/GitWorktreeManager.java" "$M/autonomy/LocalNotifier.java" \
  "$M/autonomy/AutonomousTaskFile.java" "$M/autonomy/AutonomousSchedule.java" "$M/autonomy/HeadlessSettings.java" \
  "$ROOT/qa/eliya155-local-autonomy/stubs/org/springframework/stereotype/Service.java" \
  "$ROOT/qa/eliya155-local-autonomy/Eliya155Smoke.java"
java -cp "$TMP:$CP" com.llmart.llm.autonomy.Eliya155Smoke
