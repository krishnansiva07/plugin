# Preflight for Windows source archives: fail before Maven if Java source files
# were omitted, incompletely extracted or moved to a different package.
$ErrorActionPreference = 'Stop'
$root = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$inventory = Join-Path $PSScriptRoot 'source-inventory.txt'
if (-not (Test-Path -LiteralPath $inventory -PathType Leaf)) {
    Write-Error 'Source inventory missing. Extract a complete ELIYA archive.'
    exit 2
}
$entries = @(Get-Content -LiteralPath $inventory -Encoding UTF8 | ForEach-Object { $_.Trim() } | Where-Object { $_ -and -not $_.StartsWith('#') })
$missing = @()
$invalid = @()
foreach ($entry in $entries) {
    $relative = $entry.Replace('/', [IO.Path]::DirectorySeparatorChar)
    $file = Join-Path $root $relative
    if (-not (Test-Path -LiteralPath $file -PathType Leaf)) {
        $missing += $entry
        continue
    }
    $expected = ([IO.Path]::GetDirectoryName($entry).Replace('\','/') -replace '^src/main/java/','').Replace('/','.')
    $head = (Get-Content -LiteralPath $file -TotalCount 30 -Encoding UTF8) -join "`n"
    if ($head -notmatch '(?m)^\s*package\s+([\w.]+)\s*;') {
        $invalid += "$entry (missing package declaration)"
    } elseif ($Matches[1] -ne $expected) {
        $invalid += "$entry (package '$($Matches[1])' does not match '$expected')"
    }
}
$actual = @(Get-ChildItem -Path (Join-Path $root 'src/main/java') -Filter '*.java' -Recurse -File -ErrorAction SilentlyContinue)
Write-Host "Source preflight: expected=$($entries.Count); present=$($actual.Count); missing=$($missing.Count); invalid=$($invalid.Count)"
if ($entries.Count -lt 234 -or $missing.Count -gt 0 -or $invalid.Count -gt 0) {
    foreach ($item in $missing) { Write-Host "MISSING: $item" -ForegroundColor Red }
    foreach ($item in $invalid) { Write-Host "INVALID: $item" -ForegroundColor Red }
    Write-Host 'Re-extract the new ZIP into a fresh empty folder. Do not copy over an older ELIYA directory.' -ForegroundColor Yellow
    exit 1
}
Write-Host 'Source preflight PASSED.' -ForegroundColor Green
exit 0
