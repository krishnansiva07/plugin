"""Drive the real full-screen Eliya chat inside a pseudo-terminal and check what a user would see.

A small VT100 screen model interprets the program's output (cursor moves, line clears, alternate screen),
so the checks look at the actual screen contents, not at internal state.
"""
import fcntl
import os
import select
import struct
import subprocess
import sys
import tempfile
import termios
import threading
import time
import unicodedata

ROWS, COLS = 30, 100
OUT = sys.argv[1]


class Screen:
    def __init__(self, rows, cols):
        self.rows, self.cols = rows, cols
        self.lock = threading.Lock()
        self.reset()
        self.alt = False
        self.raw = bytearray()
        self._pending = b""

    def reset(self):
        self.cells = [[" "] * self.cols for _ in range(self.rows)]
        self.r = self.c = 0

    def text(self):
        with self.lock:
            return "\n".join("".join(ch for ch in row if ch is not None).rstrip() for row in self.cells)

    def put(self, ch):
        w = 2 if unicodedata.east_asian_width(ch) in ("W", "F") else 1
        if self.c + w > self.cols:
            return  # the program clips lines itself; never auto-wrap
        self.cells[self.r][self.c] = ch
        if w == 2 and self.c + 1 < self.cols:
            self.cells[self.r][self.c + 1] = None
        self.c += w

    def feed(self, data):
        with self.lock:
            self.raw += data
            text = (self._pending + data)
            try:
                s = text.decode("utf-8")
                self._pending = b""
            except UnicodeDecodeError as e:
                s = text[: e.start].decode("utf-8")
                self._pending = text[e.start:]
            i = 0
            while i < len(s):
                ch = s[i]
                if ch == "\x1b":
                    if i + 1 >= len(s):
                        self._pending = s[i:].encode() + self._pending
                        break
                    nxt = s[i + 1]
                    if nxt == "[":
                        j = i + 2
                        while j < len(s) and not ("@" <= s[j] <= "~"):
                            j += 1
                        if j >= len(s):
                            self._pending = s[i:].encode() + self._pending
                            break
                        self.csi(s[i + 2: j], s[j])
                        i = j + 1
                        continue
                    if nxt == "]":
                        j = s.find("\x07", i)
                        if j < 0:
                            self._pending = s[i:].encode() + self._pending
                            break
                        i = j + 1
                        continue
                    i += 2
                    continue
                if ch == "\r":
                    self.c = 0
                elif ch == "\n":
                    if self.r < self.rows - 1:
                        self.r += 1
                    else:
                        self.cells.pop(0)
                        self.cells.append([" "] * self.cols)
                elif ch == "\b":
                    self.c = max(0, self.c - 1)
                elif ch >= " ":
                    self.put(ch)
                i += 1

    def csi(self, params, final):
        private = params.startswith("?")
        nums = [int(p) if p.isdigit() else 0 for p in params.lstrip("?").split(";")] if params.lstrip("?") else []
        if final in "Hf":
            r = (nums[0] if len(nums) > 0 and nums[0] else 1) - 1
            c = (nums[1] if len(nums) > 1 and nums[1] else 1) - 1
            self.r, self.c = min(r, self.rows - 1), min(c, self.cols - 1)
        elif final == "K":
            for k in range(self.c, self.cols):
                self.cells[self.r][k] = " "
        elif final == "J":
            if not nums or nums[0] in (2, 3):
                self.cells = [[" "] * self.cols for _ in range(self.rows)]
        elif final in "hl" and private and 1049 in nums:
            self.alt = final == "h"
            self.reset()


def set_size(fd):
    fcntl.ioctl(fd, termios.TIOCSWINSZ, struct.pack("HHHH", ROWS, COLS, 0, 0))


def main():
    log = tempfile.NamedTemporaryFile(prefix="eliya-tui-log", delete=False).name
    master, slave = os.openpty()
    set_size(slave)
    before = termios.tcgetattr(slave)

    def child_setup():
        os.setsid()
        fcntl.ioctl(0, termios.TIOCSCTTY, 0)

    env = dict(os.environ, TERM="xterm-256color", LANG="C.UTF-8")
    proc = subprocess.Popen(["java", "-Dfile.encoding=UTF-8", "-cp", OUT, "com.llmart.llm.cli.tui.FakeTuiMain", log],
                            stdin=slave, stdout=slave, stderr=slave, preexec_fn=child_setup, env=env, close_fds=True)
    screen = Screen(ROWS, COLS)
    stop = threading.Event()

    def reader():
        while not stop.is_set():
            ready, _, _ = select.select([master], [], [], 0.05)
            if ready:
                try:
                    data = os.read(master, 65536)
                except OSError:
                    return
                if not data:
                    return
                screen.feed(data)

    threading.Thread(target=reader, daemon=True).start()
    passed = [0]

    def send(data):
        os.write(master, data.encode("utf-8") if isinstance(data, str) else data)
        time.sleep(0.08)

    def logged():
        try:
            return open(log, encoding="utf-8").read().splitlines()
        except FileNotFoundError:
            return []

    def wait(cond, name, timeout=8.0):
        end = time.time() + timeout
        while time.time() < end:
            if cond():
                passed[0] += 1
                return
            time.sleep(0.05)
        print("---- screen ----\n" + screen.text() + "\n---- log ----\n" + "\n".join(logged()))
        raise AssertionError("FAILED: " + name)

    def dump(label):
        if os.environ.get("ELIYA_TUI_DUMP"):
            time.sleep(0.3)
            print("==== " + label + " ====\n" + screen.text())

    def on_screen(text):
        return lambda: text in screen.text()

    def in_log(line):
        return lambda: line in logged()

    try:
        wait(lambda: screen.alt, "enters the alternate screen")
        wait(on_screen("ELIYA"), "header shown")
        wait(lambda: "Analyse" in screen.text() and "● ready" in screen.text(), "mode and ready state in header")
        wait(on_screen("╭─"), "message box drawn")
        wait(on_screen("Ask about the project"), "placeholder in the box")
        wait(on_screen("test-chat-model"), "model in header")

        # Multi-line paste stays in the box until Enter.
        send("\x1b[200~first line\nsecond line\x1b[201~")
        wait(on_screen("│ second line"), "pasted text shown on two rows in the box")
        if any(l.startswith("run:") for l in logged()):
            raise AssertionError("FAILED: paste must not send the message")
        passed[0] += 1
        send("\r")
        wait(in_log("run:analyse:first line\\nsecond line"), "Enter sends the whole pasted message")
        wait(on_screen("END-OF-ANSWER"), "answer streamed and view follows the bottom")
        wait(on_screen("int answer = 42;"), "code block rendered")
        if "Line 1 of the answer" in screen.text():
            raise AssertionError("FAILED: long answer should be scrolled")
        passed[0] += 1
        send("\x1b[5~")
        send("\x1b[5~")
        wait(on_screen("more lines"), "PgUp scrolls back with an indicator")
        wait(on_screen("first line"), "PgUp reaches the user message")
        send("\x1b")
        wait(lambda: "more lines" not in screen.text() and "END-OF-ANSWER" in screen.text(), "Esc returns to the bottom")

        # Alt+Enter makes a new line; Ctrl+U clears.
        send("abc\x1b\rdef")
        wait(on_screen("│ def"), "Alt+Enter inserts a newline")
        send("\x15")
        wait(on_screen("Ask about the project"), "Ctrl+U clears the box")

        # Tab switches to Agent.
        send("\t")
        wait(in_log("mode:agent"), "Tab switches mode")
        wait(on_screen("Agent"), "Agent in header")

        # Approval with a single key.
        send("approve it\r")
        wait(on_screen("Approval needed"), "approval card shown")
        wait(on_screen("y = this action"), "approval keys explained")
        dump("approval")
        send("a")
        wait(in_log("approve:run"), "single key 'a' approves the run")
        wait(on_screen("All tests passed."), "answer after approval")
        wait(on_screen("Outcome:"), "Agent outcome shown")
        wait(on_screen("● ready"), "ready again")

        # While running: Enter adds to the task, Ctrl+Q queues, Ctrl+C stops (queue kept).
        send("long task\r")
        wait(in_log("run:agent:long task"), "long task started")
        wait(on_screen("Add to running task"), "box title changes while running")
        wait(on_screen("Ctrl+Q"), "running hints shown")
        send("use the new API\r")
        wait(in_log("input:run-l:use the new API"), "Enter adds input to the running task")
        wait(on_screen("Added to running task"), "added input shown in transcript")
        send("write release notes\x11")
        wait(on_screen("Queued next: write release notes"), "Ctrl+Q queues the next task")
        wait(on_screen("1 queued"), "queue count in status line")
        dump("running with queue")
        send("\x03")
        wait(in_log("cancel"), "Ctrl+C stops the task")
        wait(on_screen("Queued messages are kept"), "queue kept after stop")
        if "run:agent:write release notes" in logged():
            raise AssertionError("FAILED: queued task must not auto-run after a stop")
        passed[0] += 1

        # Slash command completion and exit.
        send("/hel\t")
        wait(on_screen("│ /help"), "Tab completes slash commands")
        send("\r")
        wait(on_screen("/queue <text>"), "/help shows commands")
        send("/exit\r")
        proc.wait(timeout=10)
        time.sleep(0.2)
        wait(lambda: not screen.alt, "leaves the alternate screen on exit")
        wait(lambda: b"TUI_EXITED_CLEANLY" in screen.raw, "process exits cleanly")
        after = termios.tcgetattr(slave)
        if before[3] != after[3] or before[0] != after[0]:
            raise AssertionError("FAILED: terminal mode not restored")
        passed[0] += 1
        if b"\x1b[?1000h" in screen.raw or b"\x1b[?1002h" in screen.raw or b"\x1b[?1006h" in screen.raw:
            raise AssertionError("FAILED: mouse capture would break native copy")
        passed[0] += 1
        if b"\x1b[?2004l" not in screen.raw:
            raise AssertionError("FAILED: bracketed paste not disabled on exit")
        passed[0] += 1
        print("ELIYA176 pseudo-terminal: %d checks passed" % passed[0])
    finally:
        stop.set()
        if proc.poll() is None:
            proc.kill()
        os.close(master)
        os.close(slave)
        os.unlink(log)


if __name__ == "__main__":
    main()
