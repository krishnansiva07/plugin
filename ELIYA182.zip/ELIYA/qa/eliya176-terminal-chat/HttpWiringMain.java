package com.llmart.llm.cli.tui;

import java.net.URI;
import java.net.http.HttpClient;
import java.nio.file.Files;

/** Drives the real HttpTuiBackend + TuiController against fake_bridge.py and prints the transcript. */
public final class HttpWiringMain {
    public static void main(String[] args) throws Exception {
        HttpTuiBackend backend = new HttpTuiBackend(HttpClient.newHttpClient(), URI.create("http://127.0.0.1:" + args[0]),
                "a".repeat(64), "sess-1", "");
        TuiController controller = new TuiController(backend, "agent", false, Files.createTempDirectory("wiring"));
        controller.attach(new TuiController.View() {
            public void changed() { }
            public void exit() { }
            public String copy(String text) { return ""; }
            public void openWeb(String url, boolean window) { }
        });
        controller.start();
        if (!"/srv/demo".equals(controller.workspace()) || !"m-agent".equals(controller.model())) throw new AssertionError("status not loaded");
        controller.submit("Run the tests");
        long deadline = System.currentTimeMillis() + 5000;
        while (controller.approval() == null && System.currentTimeMillis() < deadline) Thread.sleep(20);
        if (controller.approval() == null) throw new AssertionError("approval not received");
        controller.submit("keep going");          // ignored? no: approval pending -> must be y/a/n
        controller.submit("y");
        while (controller.running() && System.currentTimeMillis() < deadline) Thread.sleep(20);
        if (controller.running()) throw new AssertionError("run did not finish");
        Thread.sleep(200);
        for (TuiTranscript.Entry entry : controller.transcript().snapshot())
            System.out.println(entry.kind() + "|" + entry.title() + "|" + entry.status() + "|" + entry.text().replace("\n", " / "));
    }
}
