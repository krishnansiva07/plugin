package com.llmart.llm.cli.tui;

import com.llmart.llm.cli.EliyaUiLauncher;

import java.io.ByteArrayInputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.function.BooleanSupplier;

/** ELIYA176 terminal chat: text layout, key decoding, message box, chat routing and launcher choice. */
public final class TuiSmoke {
    private static int passed;

    static void check(boolean condition, String name) {
        if (!condition) throw new AssertionError("FAILED: " + name);
        passed++;
    }

    static void waitFor(BooleanSupplier condition, String name) throws InterruptedException {
        long deadline = System.currentTimeMillis() + 3000;
        while (!condition.getAsBoolean()) {
            if (System.currentTimeMillis() > deadline) throw new AssertionError("TIMEOUT: " + name);
            Thread.sleep(10);
        }
        passed++;
    }

    static List<TuiKeys.Key> keys(String raw) throws Exception {
        TuiKeys decoder = new TuiKeys(new ByteArrayInputStream(raw.getBytes(StandardCharsets.UTF_8)));
        List<TuiKeys.Key> out = new java.util.ArrayList<>();
        while (true) {
            TuiKeys.Key key = decoder.read();
            if (key.type() == TuiKeys.Type.EOF) return out;
            out.add(key);
        }
    }

    static final class RecordingView implements TuiController.View {
        volatile boolean exited;
        volatile String copied = "";
        volatile String web = "";
        @Override public void changed() { }
        @Override public void exit() { exited = true; }
        @Override public String copy(String text) { copied = text; return "copied"; }
        @Override public void openWeb(String url, boolean window) { web = url + (window ? "#window" : ""); }
    }

    public static void main(String[] args) throws Exception {
        text();
        keyDecoding();
        inputBox();
        routing();
        approvalsAndQuestions();
        stopKeepsQueue();
        commandsAndExport();
        launcherChoice();
        screen();
        lineChatGrouping();
        windowsHelper();
        System.out.println("ELIYA176 terminal chat: " + passed + " checks passed");
    }

    static void text() {
        check(TuiText.width('a') == 1 && TuiText.width(0x4e2d) == 2 && TuiText.width(0x0301) == 0, "cell widths");
        check(TuiText.visibleWidth(TuiText.RED + "abc" + TuiText.RESET) == 3, "ANSI ignored in width");
        List<String> wrapped = TuiText.wrap("one two three four five", 9);
        check(wrapped.equals(List.of("one two", "three", "four five")), "word wrap " + wrapped);
        check(TuiText.wrap("abcdefghijkl", 5).equals(List.of("abcde", "fghij", "kl")), "long word split");
        check(TuiText.wrap("a\n\nb", 10).equals(List.of("a", "", "b")), "hard newlines kept");
        check(TuiText.sanitize("x\u001b[2Jy\u0007").equals("x[2Jy"), "escape sequences cannot reach the screen");
        check(TuiText.fit("abcdefgh", 5).equals("abcd…"), "fit with ellipsis");
    }

    static void keyDecoding() throws Exception {
        List<TuiKeys.Key> k = keys("hi\r");
        check(k.size() == 3 && k.get(0).text().equals("h") && k.get(2).type() == TuiKeys.Type.ENTER, "chars and Enter");
        k = keys("\u001b\r\n");
        check(k.get(0).type() == TuiKeys.Type.NEWLINE && k.get(1).type() == TuiKeys.Type.NEWLINE, "Alt+Enter and Ctrl+J are newlines");
        k = keys("\u001b[200~line1\r\nline2\u001b[201~\r");
        check(k.get(0).type() == TuiKeys.Type.PASTE && k.get(0).text().equals("line1\nline2"), "bracketed paste is one block");
        check(k.get(1).type() == TuiKeys.Type.ENTER, "Enter after paste");
        k = keys("\u001b[200~a\u001b[20b\u001b[201~");
        check(k.get(0).text().equals("a\u001b[20b"), "partial end marker inside paste stays text");
        k = keys("\u001b[A\u001b[B\u001b[C\u001b[D\u001b[5~\u001b[6~\u001b[3~\u001bOH\u001b[F");
        check(k.stream().map(TuiKeys.Key::type).toList().equals(List.of(TuiKeys.Type.UP, TuiKeys.Type.DOWN, TuiKeys.Type.RIGHT,
                TuiKeys.Type.LEFT, TuiKeys.Type.PAGE_UP, TuiKeys.Type.PAGE_DOWN, TuiKeys.Type.DELETE, TuiKeys.Type.HOME, TuiKeys.Type.END)), "navigation keys");
        k = keys("\u0003\u0004\u0011\u007f\t");
        check(k.get(0).isCtrl('c') && k.get(1).isCtrl('d') && k.get(2).isCtrl('q') && k.get(3).type() == TuiKeys.Type.BACKSPACE
                && k.get(4).type() == TuiKeys.Type.TAB, "control keys");
        k = keys("é中🙂");
        check(k.size() == 3 && k.get(0).text().equals("é") && k.get(1).text().equals("中") && k.get(2).text().equals("🙂"), "UTF-8 characters");
        k = keys("\u001b[13;2u");
        check(k.get(0).type() == TuiKeys.Type.NEWLINE, "Shift+Enter (CSI u) is a newline");
    }

    static void inputBox() {
        TuiInputBox box = new TuiInputBox();
        box.insert("hello");
        box.left(); box.left();
        box.insert("X");
        check(box.text().equals("helXlo"), "insert at cursor");
        box.backspace();
        check(box.text().equals("hello"), "backspace");
        box.end(); box.insert("\nworld");
        check(box.up() && box.cursor() == 5, "up keeps column");
        check(!box.up(), "up on first line reports edge");
        check(box.down() && !box.down(), "down then edge");
        box.insert("\r\nthird\tline");
        check(box.text().equals("hello\nworld\nthird    line"), "paste normalises CRLF and tabs");
        TuiInputBox.Layout layout = box.layout(6);
        check(layout.rows().get(0).equals("hello") && layout.rows().size() >= 4, "layout wraps rows");
        String sent = box.take();
        check(sent.equals("hello\nworld\nthird    line") && box.isEmpty(), "take returns multi-line message");
        box.insert("draft");
        box.historyPrevious();
        check(box.text().equals(sent), "history previous");
        box.historyNext();
        check(box.text().equals("draft"), "history restores draft");
        box.clear(); box.insert("two words");
        box.deleteWordBefore();
        check(box.text().equals("two "), "delete word");
        box.clear(); box.insert("🙂a"); box.left(); box.left(); box.delete();
        check(box.text().equals("a"), "delete removes a whole emoji");
    }

    static TuiController controller(FakeBackend backend, String mode) throws Exception {
        TuiController controller = new TuiController(backend, mode, false, Files.createTempDirectory("eliya-tui"));
        controller.attach(new RecordingView());
        controller.start();
        return controller;
    }

    static long count(TuiController c, TuiTranscript.Kind kind) {
        return c.transcript().snapshot().stream().filter(e -> e.kind() == kind).count();
    }

    static void routing() throws Exception {
        FakeBackend backend = new FakeBackend();
        TuiController c = controller(backend, "agent");
        check(backend.calls.contains("mode:agent"), "start selects mode");
        check(c.model().equals("agent-model"), "agent model shown");
        c.submit("Add a health endpoint");
        waitFor(() -> backend.calls.contains("run:agent:Add a health endpoint"), "message starts an Agent run");
        check(c.running(), "running flag");
        backend.script.put(l -> l.runId("run-7"));
        waitFor(() -> "run-7".equals(c.runId()), "run id captured");
        c.submit("Also update the README");
        waitFor(() -> backend.calls.contains("input:run-7:Also update the README"), "Enter while running adds to the running task");
        c.queueNext("Then run the tests");
        check(c.queued().equals(List.of("Then run the tests")), "Ctrl+Q queues the next task");
        backend.script.put(l -> { l.token("Done "); l.token("adding."); });
        backend.script.put(l -> l.done("Done adding."));
        backend.script.put(FakeBackend.END);
        waitFor(() -> backend.calls.contains("run:agent:Then run the tests"), "queued task starts automatically after finish");
        check(backend.calls.indexOf("result") < backend.calls.indexOf("run:agent:Then run the tests"), "outcome fetched before next task");
        check(c.transcript().snapshot().stream().anyMatch(e -> e.kind() == TuiTranscript.Kind.ASSISTANT && e.text().equals("Done adding.")),
                "streamed answer not duplicated by done");
        check(c.transcript().snapshot().stream().anyMatch(e -> e.kind() == TuiTranscript.Kind.RESULT && e.text().startsWith("Status: completed")),
                "Agent outcome shown");
        backend.script.put(FakeBackend.END);
        waitFor(() -> !c.running(), "second task ends");

        // Input rejected because the run already finished: kept as the next task, not lost.
        backend.rejectInput = true;
        c.submit("Refactor");
        waitFor(() -> backend.calls.contains("run:agent:Refactor"), "third run");
        backend.script.put(l -> l.runId("run-9"));
        waitFor(() -> "run-9".equals(c.runId()), "run id 9");
        c.submit("late input");
        waitFor(() -> c.queued().contains("late input"), "rejected input is queued instead of lost");
        backend.rejectInput = false;
        backend.script.put(FakeBackend.END);
        waitFor(() -> backend.calls.contains("run:agent:late input"), "kept input runs next");
        backend.script.put(FakeBackend.END);
        waitFor(() -> !c.running(), "idle");

        // Analyse answers have no run id: typing while it streams queues the message.
        FakeBackend analyse = new FakeBackend();
        TuiController a = controller(analyse, "analyse");
        a.submit("Explain the build");
        waitFor(() -> a.running(), "analyse running");
        a.submit("And the tests?");
        check(a.queued().equals(List.of("And the tests?")), "analyse input queued (no run id)");
        analyse.script.put(l -> l.done("The build uses Maven."));
        analyse.script.put(FakeBackend.END);
        waitFor(() -> analyse.calls.contains("run:analyse:And the tests?"), "queued analyse question sent next");
        check(a.transcript().snapshot().stream().anyMatch(e -> e.kind() == TuiTranscript.Kind.ASSISTANT && e.text().equals("The build uses Maven.")),
                "done-only answer shown");
        check(!analyse.calls.contains("result"), "no Agent outcome for analyse");
        analyse.script.put(FakeBackend.END);
        waitFor(() -> !a.running(), "analyse idle");

        check(TuiController.isCommand("/agent fix it") && TuiController.isCommand("/help"), "slash commands");
        check(!TuiController.isCommand("/home/me/project/README.md is wrong") && !TuiController.isCommand("/"), "pasted paths are messages");
    }

    static void approvalsAndQuestions() throws Exception {
        FakeBackend backend = new FakeBackend();
        TuiController c = controller(backend, "agent");
        c.submit("Delete the old module");
        waitFor(() -> c.running(), "running");
        backend.script.put(l -> l.runId("r1"));
        backend.script.put(l -> l.step("run_command", "waiting", "mvn test", "", "ap-1", "command"));
        waitFor(() -> c.approval() != null, "approval pending");
        c.submit("maybe");
        check(c.approval() != null && !backend.calls.stream().anyMatch(s -> s.startsWith("approve")), "unclear approval answer is not guessed");
        c.submit("a");
        waitFor(() -> backend.calls.contains("approve:r1:ap-1:run"), "a approves the whole run");
        backend.script.put(l -> l.step("delete_file", "waiting", "src/Old.java", "", "ap-2", "file_deletion"));
        waitFor(() -> c.approval() != null, "deletion approval pending");
        check(!c.approval().allowRun(), "deletion cannot be approved for the whole run");
        c.submit("a");
        check(c.approval() != null, "a refused for deletion");
        c.submit("n");
        waitFor(() -> backend.calls.contains("approve:r1:ap-2:deny"), "n denies");
        backend.script.put(l -> l.question("q1", "Provider failed", List.of("Retry after fixing provider", "Stop")));
        waitFor(() -> c.question() != null, "question pending");
        c.submit("retry after fixing provider");
        waitFor(() -> backend.calls.contains("answer:r1:q1:Retry after fixing provider:"), "exact option text sent as that option");
        backend.script.put(l -> l.question("q2", "Which module?", List.of("api", "web")));
        waitFor(() -> c.question() != null, "second question");
        c.submit("2");
        waitFor(() -> backend.calls.contains("answer:r1:q2:web:"), "number selects option");
        backend.script.put(l -> l.question("q3", "Anything else?", List.of("No")));
        waitFor(() -> c.question() != null, "third question");
        c.submit("Use Java 17 records");
        waitFor(() -> backend.calls.contains("answer:r1:q3:Custom:Use Java 17 records"), "own words sent as custom answer");
        backend.script.put(FakeBackend.END);
        waitFor(() -> !c.running(), "ends");

        FakeBackend auto = new FakeBackend();
        TuiController y = new TuiController(auto, "agent", true, Files.createTempDirectory("eliya-tui"));
        y.attach(new RecordingView());
        y.start();
        y.submit("x");
        waitFor(() -> y.running(), "auto running");
        auto.script.put(l -> l.runId("r2"));
        auto.script.put(l -> l.step("write_file", "waiting", "a.txt", "", "ap-3", "edit"));
        waitFor(() -> auto.calls.contains("approve:r2:ap-3:run"), "--yes auto-approves ordinary actions");
        auto.script.put(l -> l.step("delete_file", "waiting", "b.txt", "", "ap-4", "file_deletion"));
        waitFor(() -> y.approval() != null, "--yes still asks for deletions");
        y.submit("y");
        waitFor(() -> auto.calls.contains("approve:r2:ap-4:once"), "deletion approved once");
        auto.script.put(FakeBackend.END);
        waitFor(() -> !y.running(), "auto ends");
    }

    static void stopKeepsQueue() throws Exception {
        FakeBackend backend = new FakeBackend();
        TuiController c = controller(backend, "agent");
        c.submit("Long task");
        waitFor(() -> c.running(), "running");
        c.queueNext("next one");
        c.stop();
        waitFor(() -> backend.calls.contains("cancel"), "stop cancels");
        waitFor(() -> !c.running(), "stopped");
        check(c.queued().equals(List.of("next one")) && !backend.calls.contains("run:agent:next one"), "queue kept, not auto-sent after a stop");
        check(c.transcript().snapshot().stream().anyMatch(e -> e.kind() == TuiTranscript.Kind.ERROR && e.text().contains("stopped")), "stop reported");
        backend.autoFinish = true;
        c.submit("/send");
        waitFor(() -> backend.calls.contains("run:agent:next one"), "/send runs queued message");
        waitFor(() -> !c.running(), "done");
    }

    static void commandsAndExport() throws Exception {
        FakeBackend backend = new FakeBackend();
        backend.autoFinish = true;
        Path dir = Files.createTempDirectory("eliya-tui-export");
        TuiController c = new TuiController(backend, "analyse", false, dir);
        RecordingView view = new RecordingView();
        c.attach(view);
        c.start();
        c.submit("/agent");
        check("agent".equals(c.mode()) && backend.calls.contains("mode:agent"), "/agent switches mode");
        c.toggleMode();
        check("analyse".equals(c.mode()), "Tab toggles back");
        c.submit("What is this project?");
        waitFor(() -> !c.running() && !c.transcript().lastAnswer().isBlank(), "answered");
        c.submit("/copy");
        check(view.copied.equals("Answer to: What is this project?"), "/copy copies the last answer");
        c.submit("/export");
        try (var files = Files.list(dir)) {
            Path file = files.findFirst().orElseThrow();
            String markdown = Files.readString(file);
            check(markdown.contains("## You\n\nWhat is this project?") && markdown.contains("## Eliya\n\nAnswer to: What is this project?"), "/export writes Markdown");
        }
        c.submit("/web");
        check(view.web.equals("http://localhost:8080/"), "/web opens the browser UI");
        c.submit("/window");
        check(view.web.endsWith("#window"), "/window opens an app window");
        c.submit("/new");
        check(backend.calls.contains("activate:/work/demo:true") && count(c, TuiTranscript.Kind.USER) == 0, "/new starts a fresh conversation");
        c.submit("/workspace /definitely/missing/dir");
        check(c.transcript().last().kind() == TuiTranscript.Kind.ERROR, "missing workspace rejected");
        Path folder = Files.createTempDirectory("eliya-ws");
        c.submit("/workspace " + folder);
        check(backend.calls.contains("activate:" + folder.toAbsolutePath().normalize() + ":false"), "/workspace activates folder");
        c.submit("/implement");
        waitFor(() -> backend.calls.contains("run:implement:"), "/implement runs implement");
        waitFor(() -> !c.running(), "implement done");
        c.submit("/bogus");
        check(c.transcript().last().kind() == TuiTranscript.Kind.ERROR, "unknown command reported");
        c.submit("/exit");
        check(view.exited, "/exit exits");
        check(TuiController.help().contains("/queue") && TuiController.help().contains("Ctrl+Q"), "help documents queue");
    }

    static void lineChatGrouping() throws Exception {
        java.io.PipedOutputStream writer = new java.io.PipedOutputStream();
        java.io.BufferedReader reader = new java.io.BufferedReader(new java.io.InputStreamReader(
                new java.io.PipedInputStream(writer, 65536), StandardCharsets.UTF_8));
        java.util.concurrent.LinkedBlockingQueue<String> messages = new java.util.concurrent.LinkedBlockingQueue<>();
        Thread thread = new Thread(() -> TuiLineChat.readMessages(reader, messages));
        thread.setDaemon(true);
        thread.start();
        writer.write("hello\n".getBytes(StandardCharsets.UTF_8)); writer.flush();
        check("hello".equals(messages.poll(2, java.util.concurrent.TimeUnit.SECONDS)), "typed line is one message");
        writer.write("pasted one\npasted two\npasted three\n".getBytes(StandardCharsets.UTF_8)); writer.flush();
        check("pasted one\npasted two\npasted three".equals(messages.poll(2, java.util.concurrent.TimeUnit.SECONDS)), "pasted lines stay together");
        writer.write("first \\\n".getBytes(StandardCharsets.UTF_8)); writer.flush();
        Thread.sleep(150);
        writer.write("second\n".getBytes(StandardCharsets.UTF_8)); writer.flush();
        check("first \nsecond".equals(messages.poll(2, java.util.concurrent.TimeUnit.SECONDS)), "backslash continues the message");
        writer.write("\"\"\"\n".getBytes(StandardCharsets.UTF_8)); writer.flush();
        Thread.sleep(150);
        writer.write("x\n".getBytes(StandardCharsets.UTF_8)); writer.flush();
        Thread.sleep(150);
        writer.write("y\n\"\"\"\n".getBytes(StandardCharsets.UTF_8)); writer.flush();
        check("x\ny".equals(messages.poll(2, java.util.concurrent.TimeUnit.SECONDS)), "triple-quote block");
        writer.close();
        check("\u0000EOF".equals(messages.poll(2, java.util.concurrent.TimeUnit.SECONDS)), "end of input signalled");
    }

    static void windowsHelper() throws Exception {
        String script = WindowsTuiTerminal.script(51234, "abc123");
        check(script.contains("$port = 51234") && script.contains("$token = 'abc123'") && !script.contains("__PORT__"), "helper script placeholders filled");
        check(script.contains("TreatControlCAsInput = $originalCtrlC") && script.contains("OutputEncoding = $originalEncoding"), "helper restores the console");
        check(script.contains("[Console]::KeyAvailable) { Send-Key \"`n\" }"), "multi-line paste becomes newlines");
        long open = script.chars().filter(ch -> ch == '{').count(), close = script.chars().filter(ch -> ch == '}').count();
        check(open == close, "helper braces balanced");
        String decoded = new String(java.util.Base64.getDecoder().decode(WindowsTuiTerminal.encoded("Write-Host é")), StandardCharsets.UTF_16LE);
        check(decoded.equals("Write-Host é"), "EncodedCommand is UTF-16LE Base64");
        check(java.util.Arrays.equals(WindowsTuiTerminal.parseSize("H 1 30 120"), new int[]{1, 30, 120}), "handshake parsed");
        check(java.util.Arrays.equals(WindowsTuiTerminal.parseSize("S 40 100"), new int[]{1, 40, 100}), "resize parsed");
        check(WindowsTuiTerminal.parseSize("K AAAA") == null && WindowsTuiTerminal.parseSize("H x 1 2") == null, "other lines ignored");
        check(TuiTerminal.openWindows() == null || System.getProperty("os.name").toLowerCase().contains("win"), "Windows helper only on Windows");
        List<TuiKeys.Key> k = keys("a\nb\r\u001b[13;2u\u007f");
        check(k.get(1).type() == TuiKeys.Type.NEWLINE && k.get(3).type() == TuiKeys.Type.ENTER && k.get(4).type() == TuiKeys.Type.NEWLINE
                && k.get(5).type() == TuiKeys.Type.BACKSPACE, "helper key encoding decodes like a Unix terminal");
    }

    static void launcherChoice() {
        BooleanSupplier raw = () -> true, noRaw = () -> false;
        String[] none = {};
        check(EliyaUiLauncher.chooseUi(none, List.of(), false, null, true, raw) == EliyaUiLauncher.UiChoice.CHAT, "eliya opens the chat");
        check(EliyaUiLauncher.chooseUi(none, List.of(), false, null, true, noRaw) == EliyaUiLauncher.UiChoice.LINE_CHAT, "no raw mode: line chat");
        check(EliyaUiLauncher.chooseUi(none, List.of(), false, null, false, raw) == EliyaUiLauncher.UiChoice.CLASSIC, "not a terminal: previous behaviour");
        check(EliyaUiLauncher.chooseUi(none, List.of("--no-browser"), true, null, true, raw) == EliyaUiLauncher.UiChoice.CLASSIC, "--no-browser keeps headless server");
        check(EliyaUiLauncher.chooseUi(new String[]{"web"}, List.of("web"), false, null, true, raw) == EliyaUiLauncher.UiChoice.CLASSIC, "eliya web = browser");
        check(EliyaUiLauncher.chooseUi(none, List.of("--browser"), false, null, true, raw) == EliyaUiLauncher.UiChoice.CLASSIC, "--browser");
        check(EliyaUiLauncher.chooseUi(none, List.of(), false, "classic", true, raw) == EliyaUiLauncher.UiChoice.CLASSIC, "ELIYA_UI=classic");
        check(EliyaUiLauncher.chooseUi(none, List.of(), false, "window", true, raw) == EliyaUiLauncher.UiChoice.WINDOW, "ELIYA_UI=window");
        check(EliyaUiLauncher.chooseUi(none, List.of("--window"), false, null, true, raw) == EliyaUiLauncher.UiChoice.WINDOW, "--window");
        check(EliyaUiLauncher.chooseUi(none, List.of("--new-terminal"), false, null, true, raw) == EliyaUiLauncher.UiChoice.NEW_TERMINAL, "--new-terminal");
        check(EliyaUiLauncher.chooseUi(new String[]{"agent"}, List.of("agent"), false, null, true, raw) == EliyaUiLauncher.UiChoice.CHAT, "eliya agent opens chat");
        check(EliyaUiLauncher.chooseUi(new String[]{"agent", "Add tests"}, List.of("agent", "Add tests"), false, null, true, raw) == EliyaUiLauncher.UiChoice.CLASSIC,
                "one-shot prompt unchanged");
        check(EliyaUiLauncher.chooseUi(new String[]{"run", "x"}, List.of("run", "x"), false, null, true, raw) == EliyaUiLauncher.UiChoice.CLASSIC, "eliya run unchanged");
        check(EliyaUiLauncher.chooseUi(new String[]{"chat"}, List.of("chat"), false, "classic", false, raw) == EliyaUiLauncher.UiChoice.CHAT, "explicit chat wins");
        check(EliyaUiLauncher.chooseUi(none, List.of("--line"), false, null, true, raw) == EliyaUiLauncher.UiChoice.LINE_CHAT, "--line");
        check(EliyaUiLauncher.chooseUi(none, List.of("--tui"), false, null, true, noRaw) == EliyaUiLauncher.UiChoice.CHAT, "--tui asks for full screen (Windows preview)");
        check(EliyaUiLauncher.chooseUi(none, List.of(), false, "tui", true, noRaw) == EliyaUiLauncher.UiChoice.CHAT, "ELIYA_UI=tui");
        check(EliyaUiLauncher.chatMode(new String[]{"chat", "agent"}).equals("agent") && EliyaUiLauncher.chatMode(new String[]{"agent"}).equals("agent")
                && EliyaUiLauncher.chatMode(new String[]{}).equals("analyse"), "chat mode");
    }

    static void screen() throws Exception {
        FakeBackend backend = new FakeBackend();
        backend.autoFinish = true;
        TuiController c = new TuiController(backend, "analyse", false, Files.createTempDirectory("eliya-tui"));
        c.attach(new RecordingView());
        c.start();
        c.submit("Show **me** the code");
        waitFor(() -> !c.running() && !c.transcript().lastAnswer().isBlank(), "answer for screen");
        List<String> rendered = EliyaTui.markdown("# Title\n- item one that is long enough to wrap around\n```java\nint x = 1;\n```", 20);
        check(rendered.get(0).contains("# Title") && rendered.stream().anyMatch(l -> l.contains("int x = 1;")), "markdown keeps text");
        check(EliyaTui.clip(TuiText.RED + "abcdef", 3).startsWith(TuiText.RED + "abc"), "clip keeps styles");
        check(EliyaTui.render(new TuiTranscript().add(TuiTranscript.Kind.ACTIVITY, "run_command", "success", "mvn -q test"), "mvn -q test", "success", 40)
                .get(0).contains("✓"), "activity icon");
    }
}
