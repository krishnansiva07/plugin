package com.llmart.llm.cli.tui;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

/** Runs the real full-screen chat against a scripted backend; every backend call is logged to args[0]. */
public final class FakeTuiMain {
    public static void main(String[] args) throws Exception {
        Path log = Path.of(args[0]);
        TuiBackend backend = new TuiBackend() {
            volatile String mode = "analyse";
            volatile CountDownLatch approved = new CountDownLatch(1);
            volatile CountDownLatch cancelled = new CountDownLatch(1);
            void record(String line) {
                try { Files.writeString(log, line + "\n", StandardCharsets.UTF_8, StandardOpenOption.CREATE, StandardOpenOption.APPEND); }
                catch (Exception ignored) { }
            }
            @Override public void run(String runMode, String prompt, Listener l) throws Exception {
                record("run:" + runMode + ":" + prompt.replace("\n", "\\n"));
                if (prompt.startsWith("approve")) {
                    approved = new CountDownLatch(1);
                    l.runId("run-a");
                    l.step("run_command", "waiting", "mvn test", "", "ap-1", "command");
                    approved.await(10, TimeUnit.SECONDS);
                    l.step("run_command", "success", "mvn test passed", "", "", "");
                    l.token("All tests passed.");
                    l.done("All tests passed.");
                } else if (prompt.startsWith("long")) {
                    cancelled = new CountDownLatch(1);
                    l.runId("run-l");
                    l.step("read_file", "running", "src/App.java", "", "", "");
                    if (cancelled.await(10, TimeUnit.SECONDS)) l.stopped("Run stopped by user");
                } else {
                    for (int i = 1; i <= 40; i++) { l.token("Line " + i + " of the answer\n"); }
                    l.token("```java\nint answer = 42;\n```\nEND-OF-ANSWER");
                    l.done("");
                }
            }
            @Override public void approve(String runId, String approvalId, String decision) { record("approve:" + decision); approved.countDown(); }
            @Override public void answer(String runId, String questionId, String choice, String detail) { record("answer:" + choice); }
            @Override public boolean cancel() { record("cancel"); cancelled.countDown(); return true; }
            @Override public String addInput(String runId, String text) { record("input:" + runId + ":" + text); return "i1"; }
            @Override public String mode(String next) { mode = next; record("mode:" + next); return "/work/demo"; }
            @Override public String activate(String workspace, boolean fresh) { record("activate"); return "/work/demo"; }
            @Override public Status status() { return new Status("/work/demo", mode, true, "test-model", "test-chat-model", "ready", "http://localhost:1/", "s"); }
            @Override public RunResult latestResult() { record("result"); return new RunResult("completed", "verified", "run-a"); }
            @Override public void refresh() { }
        };
        TuiTerminal terminal = TuiTerminal.open();
        if (terminal == null) { System.out.println("NO_RAW_TERMINAL"); System.exit(5); }
        TuiController controller = new TuiController(backend, "analyse", false, Files.createTempDirectory("tui-export"));
        new EliyaTui(terminal, controller).run();
        System.out.println("TUI_EXITED_CLEANLY");
    }
}
