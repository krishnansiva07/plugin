#!/bin/bash
# ELIYA176: full-screen terminal chat (like opencode). Compiles the REAL terminal-chat classes with a tiny
# bridge stub, runs the logic checks, then drives the real full-screen UI inside a pseudo-terminal.
set -euo pipefail
BASE="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
HERE="$BASE/qa/eliya176-terminal-chat"
CLI="$BASE/src/main/java/com/llmart/llm/cli"
OUT="$(mktemp -d)"; trap 'rm -rf "$OUT"' EXIT
SOURCES=$(ls "$CLI"/tui/*.java | grep -v HttpTuiBackend.java)
RES="$BASE/src/main/resources"
javac --release 17 -proc:none -encoding UTF-8 -d "$OUT" "$HERE/stubs/com/llmart/llm/cli/EliyaCliBridge.java" \
  "$CLI/EliyaUiLauncher.java" $SOURCES "$HERE/FakeBackend.java" "$HERE/TuiSmoke.java" "$HERE/FakeTuiMain.java" 2>&1 \
  | grep -v -E '^Note:|Picked up' || true
java -cp "$OUT:$RES" com.llmart.llm.cli.tui.TuiSmoke
if command -v python3 >/dev/null 2>&1 && [ -e /dev/ptmx ] && command -v stty >/dev/null 2>&1; then
  python3 -I "$HERE/pty_drive.py" "$OUT"
else
  echo "SKIP pseudo-terminal check (python3/pty/stty unavailable)"
fi
# HTTP wiring against a fake bridge (needs Jackson; CI has it in ~/.m2 after `mvn verify`).
JACKSON_CP="${ELIYA_JACKSON_CP:-}"
if [ -z "$JACKSON_CP" ] && [ -d "$HOME/.m2/repository/com/fasterxml/jackson/core" ]; then
  JACKSON_CP=$(find "$HOME/.m2/repository/com/fasterxml/jackson/core" -name 'jackson-*.jar' ! -name '*sources*' | sort | paste -sd: -)
fi
if [ -n "$JACKSON_CP" ] && command -v python3 >/dev/null 2>&1; then
  javac --release 17 -proc:none -encoding UTF-8 -cp "$JACKSON_CP:$OUT" -d "$OUT" "$CLI/tui/HttpTuiBackend.java" "$HERE/HttpWiringMain.java" 2>&1 | grep -v -E '^Note:|Picked up' || true
  python3 -I "$HERE/fake_bridge.py" > "$OUT/port" & BRIDGE=$!
  for i in $(seq 1 50); do [ -s "$OUT/port" ] && break; sleep 0.1; done
  PORT=$(head -1 "$OUT/port")
  java -cp "$JACKSON_CP:$OUT" com.llmart.llm.cli.tui.HttpWiringMain "$PORT" > "$OUT/transcript" 2>&1 || { cat "$OUT/transcript"; kill $BRIDGE; exit 1; }
  LOGJSON=$(python3 -I -c "import urllib.request,sys; r=urllib.request.Request('http://127.0.0.1:$PORT/__log', headers={'X-Eliya-CLI-Token':'a'*64,'X-Eliya-Session':'sess-1'}); print(urllib.request.urlopen(r).read().decode())")
  kill $BRIDGE
  python3 -I - "$OUT/transcript" "$LOGJSON" <<'PY'
import json, sys
transcript = open(sys.argv[1]).read()
log = json.loads(sys.argv[2])
def need(cond, name):
    if not cond:
        print(transcript); print("\n".join(log)); raise SystemExit("FAILED: " + name)
need(any(l.startswith('POST /api/cli/mode ') and '"mode": "agent"' in l and '"sessionId": "sess-1"' in l for l in log), "mode selected for this session")
need(any(l.startswith('POST /api/cli/run ') and '"prompt": "Run the tests"' in l and '"workspace": "/srv/demo"' in l for l in log), "run posted with prompt and workspace")
need(any(l.startswith('POST /api/cli/session/approval?sessionId=sess-1 ') and '"decision": "once"' in l and '"approvalId": "ap-1"' in l and '"runId": "run-1"' in l for l in log), "approval posted")
need(not any('keep going' in l for l in log), "text that is not y/a/n is not sent as an approval or input")
need('GET /api/cli/session/result?sessionId=sess-1' in log, "outcome fetched")
need('POST /api/cli/refresh {}' in log, "browser refreshed")
need('ASSISTANT|||Tests pass.' in transcript, "answer shown once")
need(transcript.count('Tests pass.') == 1, "answer not duplicated")
need('RESULT|Outcome|success|Status: completed' in transcript and 'mvn test passed' in transcript.split('RESULT|')[1], "outcome shown")
print("ELIYA176 HTTP wiring: 9 checks passed")
PY
else
  echo "SKIP HTTP wiring check (Jackson not found; set ELIYA_JACKSON_CP)"
fi
