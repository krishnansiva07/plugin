package com.llmart.llm.cli;

/** Test stub: only the DTOs and helpers the terminal chat uses (the real class needs Spring). */
public class EliyaCliBridge {
    public record ActivationRequest(String workspace, String sessionId, Boolean fresh) { }
    public record TerminalPrompt(String mode, String prompt, String workspace, String sessionId) { }
    public record ModeRequest(String mode, String workspace, String sessionId) { }
    public record ApprovalDecision(String runId, String approvalId, String decision) { }
    public record QuestionAnswer(String runId, String questionId, String choice, String detail) { }
    public record RunInput(String runId, String text) { }
    public static volatile String opened = "";
    public static void openBrowser(String baseUrl) { opened = baseUrl; }
}
