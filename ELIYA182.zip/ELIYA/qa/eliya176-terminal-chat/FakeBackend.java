package com.llmart.llm.cli.tui;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

/** Scripted backend: each run waits for steps pushed by the test, so tests control timing exactly. */
public final class FakeBackend implements TuiBackend {
    public final List<String> calls = Collections.synchronizedList(new ArrayList<>());
    public final LinkedBlockingQueue<java.util.function.Consumer<Listener>> script = new LinkedBlockingQueue<>();
    public volatile boolean autoFinish;        // runs answer immediately with a canned reply
    public volatile String resultStatus = "completed";
    public volatile boolean rejectInput;
    private volatile CountDownLatch cancelled = new CountDownLatch(1);
    private volatile String mode = "analyse";

    static final java.util.function.Consumer<Listener> END = listener -> { };

    @Override public void run(String runMode, String prompt, Listener listener) throws Exception {
        calls.add("run:" + runMode + ":" + prompt);
        if (autoFinish) {
            if (!"analyse".equals(runMode)) listener.runId("run-" + calls.size());
            for (String word : ("Answer to: " + prompt).split("(?<= )")) listener.token(word);
            listener.done("Answer to: " + prompt);
            return;
        }
        cancelled = new CountDownLatch(1);
        while (true) {
            java.util.function.Consumer<Listener> step = script.poll(50, TimeUnit.MILLISECONDS);
            if (cancelled.getCount() == 0) { listener.stopped("Run stopped by user"); return; }
            if (step == null) continue;
            if (step == END) return;
            step.accept(listener);
        }
    }
    @Override public void approve(String runId, String approvalId, String decision) { calls.add("approve:" + runId + ":" + approvalId + ":" + decision); }
    @Override public void answer(String runId, String questionId, String choice, String detail) { calls.add("answer:" + runId + ":" + questionId + ":" + choice + ":" + detail); }
    @Override public boolean cancel() { calls.add("cancel"); cancelled.countDown(); return true; }
    @Override public String addInput(String runId, String text) {
        calls.add("input:" + runId + ":" + text);
        if (rejectInput) throw new IllegalStateException("HTTP 409: run already finished");
        return "in-1";
    }
    @Override public String mode(String next) { mode = next; calls.add("mode:" + next); return "/work/demo"; }
    @Override public String activate(String workspace, boolean fresh) { calls.add("activate:" + workspace + ":" + fresh); return workspace == null ? "/work/demo" : workspace; }
    @Override public Status status() { return new Status("/work/demo", mode, true, "agent-model", "chat-model", "ready", "http://localhost:8080/", "s1"); }
    @Override public RunResult latestResult() { calls.add("result"); return new RunResult(resultStatus, "tests passed", "run-1"); }
    @Override public void refresh() { calls.add("refresh"); }
}
