"""Minimal stand-in for Eliya's /api/cli bridge: records requests and streams scripted SSE runs."""
import json
import sys
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs

TOKEN = "a" * 64
LOG = []
APPROVED = threading.Event()


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, *args):
        pass

    def reply(self, status, body):
        data = json.dumps(body).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def body(self):
        length = int(self.headers.get("Content-Length", "0"))
        return json.loads(self.rfile.read(length) or b"{}")

    def authorized(self):
        if self.headers.get("X-Eliya-CLI-Token") != TOKEN or self.headers.get("X-Eliya-Session") != "sess-1":
            self.reply(403, {"error": "bad token"})
            return False
        return True

    def do_GET(self):
        if not self.authorized():
            return
        url = urlparse(self.path)
        LOG.append("GET " + url.path + ("?" + url.query if url.query else ""))
        if url.path == "/api/cli/status":
            self.reply(200, {"selection": {"project": {"localPath": "/srv/demo"}, "mode": "agent"},
                             "modelConfigured": True, "model": "m-agent", "chatModel": "m-chat",
                             "configurationHint": "ready", "url": "http://localhost:1/"})
        elif url.path == "/api/cli/session/result":
            self.reply(200, {"id": "run-1", "status": "completed", "lastVerification": "mvn test passed"})
        elif url.path == "/__log":
            self.reply(200, LOG)
        else:
            self.reply(404, {"error": "no"})

    def do_POST(self):
        if not self.authorized():
            return
        url = urlparse(self.path)
        body = self.body()
        LOG.append("POST " + url.path + ("?" + url.query if url.query else "") + " " + json.dumps(body, sort_keys=True))
        if url.path == "/api/cli/mode":
            self.reply(200, {"project": {"localPath": "/srv/demo"}})
        elif url.path == "/api/cli/session/approval":
            APPROVED.set()
            self.reply(200, {"resolved": True})
        elif url.path == "/api/cli/session/input":
            self.reply(409 if body.get("text") == "too late" else 200,
                       {"error": "Run already finished"} if body.get("text") == "too late" else {"id": "in-1", "status": "pending"})
        elif url.path in ("/api/cli/session/question", "/api/cli/refresh"):
            self.reply(200, {"answered": True})
        elif url.path == "/api/cli/session/cancel":
            self.reply(200, {"cancellationRequested": True})
        elif url.path == "/api/cli/run":
            self.send_response(200)
            self.send_header("Content-Type", "text/event-stream")
            self.send_header("Connection", "close")
            self.end_headers()

            def event(name, data):
                self.wfile.write(("event: %s\ndata: %s\n\n" % (name, json.dumps(data))).encode())
                self.wfile.flush()
            event("meta", {"agentRunId": "run-1"})
            event("agent_step", {"tool": "run_command", "status": "waiting", "detail": "mvn test", "approvalId": "ap-1", "approvalType": "command"})
            APPROVED.wait(10)
            event("agent_step", {"tool": "run_command", "status": "success", "detail": "mvn test passed"})
            event("token", {"text": "Tests pass."})
            event("done", {"content": "Tests pass."})
            self.close_connection = True
        else:
            self.reply(404, {"error": "no"})


server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
print(server.server_address[1], flush=True)
server.serve_forever()
