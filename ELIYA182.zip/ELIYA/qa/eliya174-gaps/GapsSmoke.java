package com.llmart.llm.service;
import java.util.List;
public class GapsSmoke {
  static int fails;
  static void expect(boolean ok, String what) { System.out.println((ok ? "FIXED   " : "BROKEN  ") + what); if (!ok) fails++; }
  public static void main(String[] a) {
    String t1 = "Migrate the billing, orders and shipping modules from JUnit 4 to JUnit 5";
    List<String> p1 = List.of("Inspect test classes in the repository", "Rewrite tests with the new APIs", "Run mvn test");
    String g1 = AgentRequirementCoverage.gapSummary(t1, p1);
    expect(g1.contains("JUnit 4") && g1.contains("billing") && g1.contains("shipping"), "JUnit 4->5 + modules gap detected: " + g1);
    String t2 = "Migrate the checkout tests from Selenium to Playwright for modules cart, payment and shipping";
    List<String> p2 = List.of("Read the Selenium suites", "Port cart tests to Playwright", "Run npx playwright test");
    String g2 = AgentRequirementCoverage.gapSummary(t2, p2);
    expect(g2.contains("payment") && g2.contains("shipping"), "dropped modules detected: " + g2);
    expect(AgentRequirementCoverage.attachChecklist(t2, p2).get(2).contains("payment"), "dropped modules attached to final step");
    expect(!AgentPlanSpecificity.mismatch("Run the integration tests for checkout", List.of("Review truncated results", "Summarise the suite")).isBlank(),
        "'truncated' no longer counts as a run step");
    String brief = "Improve order retries:\n- Add exponential backoff to OrderClient.retry()\n- Add a unit test for the backoff\n- Update README with the new retry setting";
    String g3 = AgentRequirementCoverage.gapSummary(brief, List.of("Add backoff to OrderClient.retry()", "Run the tests"));
    expect(g3.contains("unit test") || g3.contains("README"), "multi-requirement brief bullets checked: " + g3);
    expect(AgentTestWorkflow.forObjective("Fix the failing OrderServiceTest") != null, "'Fix the failing OrderServiceTest' is a test request");
    expect(AgentTestWorkflow.forObjective("The tests are failing after the upgrade, fix them") != null, "'tests are failing' is a test request");
    AgentTestWorkflow wf = AgentTestWorkflow.forObjective("Run the unit tests");
    expect(wf.blockReason("bash", "mvn test -DskipTests", null) != null, "-DskipTests blocked");
    expect(wf.completionProblem(0) != null, "cannot finish before tests ran");
    expect(AgentRuntimeFailurePolicy.decide(new RuntimeException("401 invalid api key"), 1).action() == AgentRuntimeFailurePolicy.Action.ASK_USER, "credentials error -> decision");
    expect(AgentRuntimeFailurePolicy.decide(new IllegalArgumentException("maximum context length exceeded"), 1).action() == AgentRuntimeFailurePolicy.Action.COMPACT_AND_RETRY, "context overflow -> compact & retry");
    expect(AgentRuntimeFailurePolicy.decide(new java.nio.file.AccessDeniedException("pom.xml"), 1).action() == AgentRuntimeFailurePolicy.Action.ASK_USER, "file access -> decision");
    expect(AgentRuntimeFailurePolicy.decide(new IllegalStateException("Sequential plan gate: only active step 2"), 1).action() == AgentRuntimeFailurePolicy.Action.STEER_AND_CONTINUE, "plan-gate error -> fed back, run continues");
    expect(AgentQuestionAnswers.selects("User selected: Custom\nDetails: retry this step SAFELY", "Retry this step safely"), "typed option variant matches backend");
    System.out.println(fails == 0 ? "ALL GAPS CLOSED" : fails + " still broken"); if (fails > 0) System.exit(1);
  }
}
