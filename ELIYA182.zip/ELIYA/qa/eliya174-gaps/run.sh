#!/usr/bin/env bash
# ELIYA174: the scenarios that were still broken in ELIYA173 (coverage, test-request detection, runtime failure
# classification, answer matching), plus ELIYA173's JUnit test executed with a minimal stand-in runner.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT
CP="${JACKSON_CP:-$(find "${HOME}/.m2/repository/com/fasterxml/jackson/core" -name 'jackson-*.jar' 2>/dev/null | grep -v sources | tr '\n' ':')}"
[[ -n "$CP" ]] || { echo "Jackson jars not found; set JACKSON_CP or run a Maven build once" >&2; exit 2; }
S="$ROOT/src/main/java/com/llmart/llm/service"
DEPS=("$S/AgentRequirementCoverage.java" "$S/MigrationIntent.java" "$S/AgentPlanRecovery.java" "$S/AgentPlanningTerms.java" "$S/AgentPlanJsonEnvelope.java"
      "$S/AgentPlanSpecificity.java" "$S/AgentConversationIntent.java" "$S/AgentPlanRelevance.java" "$S/AgentReadOnlySearchPolicy.java"
      "$S/AgentTestWorkflow.java" "$S/AgentRuntimeFailurePolicy.java" "$S/AgentCancelledException.java" "$S/AgentQuestionAnswers.java")
javac --release 17 -proc:none -encoding UTF-8 -cp "$CP" -d "$TMP" "${DEPS[@]}" "$ROOT/qa/eliya174-gaps/GapsSmoke.java" \
  "$ROOT"/qa/eliya174-gaps/stubs/org/junit/jupiter/api/*.java "$ROOT/qa/eliya174-gaps/RunTests.java" \
  "$ROOT/src/test/java/com/llmart/llm/service/AgentRuntimeFlowRecoveryTest.java"
java -cp "$TMP:$CP" com.llmart.llm.service.GapsSmoke
java -cp "$TMP:$CP" RunTests com.llmart.llm.service.AgentRuntimeFlowRecoveryTest
