package org.junit.jupiter.api;
public final class Assertions {
  public static void assertTrue(boolean c) { if (!c) throw new AssertionError("expected true"); }
  public static void assertTrue(boolean c, String m) { if (!c) throw new AssertionError(m); }
  public static void assertFalse(boolean c) { if (c) throw new AssertionError("expected false"); }
  public static void assertEquals(Object e, Object a) { if (!java.util.Objects.equals(e, a)) throw new AssertionError("expected <" + e + "> but was <" + a + ">"); }
}
