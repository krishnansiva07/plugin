import java.lang.reflect.*;
public class RunTests { public static void main(String[] a) throws Exception {
  int ok=0, fail=0;
  for (String name : a) { Class<?> c = Class.forName(name); Constructor<?> k = c.getDeclaredConstructor(); k.setAccessible(true); Object o = k.newInstance();
    for (Method m : c.getDeclaredMethods()) if (m.isAnnotationPresent(org.junit.jupiter.api.Test.class)) {
      m.setAccessible(true);
      try { m.invoke(o); ok++; System.out.println("ok   " + m.getName()); }
      catch (InvocationTargetException e) { fail++; System.out.println("FAIL " + m.getName() + ": " + e.getCause()); } } }
  System.out.println("junit-like: " + ok + " passed, " + fail + " failed"); if (fail > 0) System.exit(1); } }
