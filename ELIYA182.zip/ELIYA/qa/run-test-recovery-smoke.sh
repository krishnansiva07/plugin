#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
TEMP="$(mktemp -d)"
trap 'rm -rf "$TEMP"' EXIT
javac --release 17 -d "$TEMP" \
 "$ROOT/src/main/java/com/llmart/llm/service/AgentTestDiscovery.java" \
 "$ROOT/qa/AgentTestDiscoverySmoke.java" \
 "$ROOT/qa/eliya145-java-stubs/org/springframework/stereotype/Service.java" \
 "$ROOT/qa/agent-question-stubs/com/llmart/llm/service/AgentRunService.java" \
 "$ROOT/src/main/java/com/llmart/llm/service/AgentQuestionService.java" \
 "$ROOT/src/main/java/com/llmart/llm/service/AgentQuestionAnswers.java" \
 "$ROOT/qa/agent-question-stubs/com/llmart/llm/service/AgentQuestionSmoke.java"
java -cp "$TEMP" com.llmart.llm.service.AgentTestDiscoverySmoke
java -cp "$TEMP" com.llmart.llm.service.AgentQuestionSmoke
node --check "$ROOT/src/main/resources/static/app.js"
node --test "$ROOT/qa/terminal-recovery-dialog.test.js"
