package com.llmart.llm.service;

import java.nio.file.Files;
import java.util.List;
import java.util.Map;

public final class RunInputSmoke {
    static int cases;
    static void ok(boolean condition, String message) { cases++; if (!condition) throw new AssertionError("FAIL: " + message); }

    public static void main(String[] args) throws Exception {
        AgentRunService service = new AgentRunService(Files.createTempDirectory("eliya175"));
        AgentRunService.AgentRun run = service.start("conv", "proj");
        run.setObjective("Add retry to OrderClient");
        run.setPlan(List.of("Read OrderClient.java", "Add retry with backoff", "Run mvn -q test"));
        run.markPlanStarted();

        AgentRunService.UserInput first = run.submitUserInput("  Also update README with the retry setting  ");
        AgentRunService.UserInput second = run.submitUserInput("Use max 5 attempts, not 3");
        ok("pending".equals(first.status()) && first.text().equals("Also update README with the retry setting"), "queued and trimmed");
        ok(run.withdrawUserInput(second.id()), "pending input can be withdrawn");
        ok(!run.withdrawUserInput(second.id()), "withdraw is idempotent");
        AgentRunService.UserInput third = run.submitUserInput("Keep the public API unchanged");

        List<AgentRunService.UserInput> delivered = run.takePendingUserInput();
        ok(delivered.size() == 2 && delivered.get(0).id().equals(first.id()) && delivered.get(1).id().equals(third.id()),
                "delivered in submission order, withdrawn one skipped");
        ok(delivered.stream().allMatch(u -> "delivered".equals(u.status()) && u.deliveredAt() != null), "marked delivered");
        ok(run.takePendingUserInput().isEmpty(), "each input delivered exactly once");
        ok(!run.withdrawUserInput(first.id()), "delivered input cannot be withdrawn");

        run.addObjectiveAddendum(first.text());
        ok(run.objective().contains("User addition during execution: Also update README"), "addition becomes part of the task contract");

        String prompt = AgentUserInputPrompt.render(delivered, run.activePlanIndex(), run.planLocked());
        ok(prompt.contains("[USER INPUT DURING EXECUTION]") && prompt.contains("1. Also update README") && prompt.contains("2. Keep the public API"), "ordered prompt");
        ok(prompt.contains("does NOT grant new permissions") && prompt.contains("do not restart"), "safe semantics stated");
        ok(prompt.contains("active step 1"), "anchored to the active step");

        try { run.submitUserInput("   "); ok(false, "blank rejected"); } catch (IllegalArgumentException expected) { ok(true, "blank rejected"); }
        try { run.submitUserInput("x".repeat(8_001)); ok(false, "too long rejected"); } catch (IllegalArgumentException expected) { ok(true, "length limit"); }
        for (int i = 0; i < AgentRunService.AgentRun.MAX_PENDING_USER_INPUT; i++) run.submitUserInput("note " + i);
        try { run.submitUserInput("one too many"); ok(false, "pending limit"); } catch (IllegalStateException expected) { ok(true, "pending limit enforced"); }

        // Input not yet picked up when the run ends is reported, not silently dropped.
        run.finish("blocked");
        long undelivered = run.userInputs().stream().filter(u -> "undelivered".equals(u.status())).count();
        ok(undelivered == AgentRunService.AgentRun.MAX_PENDING_USER_INPUT, "pending inputs become undelivered at finish: " + undelivered);
        try { run.submitUserInput("too late"); ok(false, "finished run rejects input"); }
        catch (IllegalStateException expected) { ok(expected.getMessage().contains("new task"), "finished run points to next task"); }

        Map<String,Object> snapshot = service.status(run.id());
        ok(snapshot.get("userInputs") instanceof List<?> list && !list.isEmpty(), "inputs visible in run snapshot");
        System.out.println("PASS: " + cases + " ELIYA175 run-input assertions");
    }
}
