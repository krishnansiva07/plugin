package com.llmart.llm.service;

import com.fasterxml.jackson.databind.ObjectMapper;

import java.net.http.HttpClient;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

/**
 * ELIYA178: fixing failing Playwright tests with Playwright MCP.
 * Part 1 (always): workflow and safety rules, with a recorded failing run and a fake MCP server.
 * Part 2 (when Playwright, @playwright/mcp and a browser are installed): the real loop without a model —
 * real failing test → real Playwright MCP (navigate, snapshot) → fix from the snapshot → real passing rerun.
 */
public final class PlaywrightMcpFixE2E {
    private static final ObjectMapper JSON = new ObjectMapper();
    private static int passed;
    /** Sandbox only: point Playwright MCP at an installed Chromium when its bundled revision is not downloaded. */
    private static String browserExecutable = "";

    static void check(boolean condition, String name) {
        if (!condition) throw new AssertionError("FAILED: " + name);
        passed++;
    }

    public static void main(String[] a) throws Exception {
        Path here = Path.of(a[0]);
        String fakeServer = a[1];
        String mcpCli = a.length > 2 ? a[2] : "";
        String playwrightCli = a.length > 3 ? a[3] : "";
        browserExecutable = a.length > 4 ? a[4] : "";
        workflow(Files.readString(here.resolve("failing-run.txt")));
        safety(fakeServer);
        if (!mcpCli.isBlank() && !playwrightCli.isBlank()) realLoop(here.resolve("sample"), mcpCli, playwrightCli);
        else System.out.println("SKIP real Playwright loop (Playwright, @playwright/mcp or browsers not installed)");
        System.out.println("ELIYA178 Playwright MCP test fixing: " + passed + " checks passed");
    }

    static void workflow(String failingRun) {
        String request = "Run the Playwright tests and fix the failures using Playwright MCP";
        AgentTestWorkflow wf = AgentTestWorkflow.forObjective(request);
        check(wf != null, "test-fix request recognised");
        check(AgentTestWorkflow.forObjective("fix the failing playwright tests with MCP") != null, "short form recognised");
        check(AgentTestWorkflow.failingTests(failingRun).equals(List.of("tests/login.spec.js#user can sign in")),
                "line reporter failure parsed: " + AgentTestWorkflow.failingTests(failingRun));
        wf.markPreflight();
        String noMcp = AgentTestWorkflow.forObjective(request).afterRun("npx playwright test --reporter=line", failingRun, true, 1);
        check(!noMcp.contains("Playwright MCP:"), "no MCP hint when browser tools are not loaded");
        wf.enableBrowserMcp();
        String diagnosis = wf.afterRun("npx playwright test --reporter=line", failingRun, true, 1);
        check(diagnosis.contains("tests/login.spec.js") && diagnosis.contains("npx playwright test tests/login.spec.js")
                && diagnosis.contains("Playwright MCP: before editing") && diagnosis.contains("browser_snapshot"), "diagnosis uses MCP: " + diagnosis);
        check(diagnosis.contains("TimeoutError: locator.click"), "first error shown");
        check(wf.completionProblem(1).contains("latest test run failed"), "cannot finish after a failure");
        check(wf.blockReason("edit", null, "test.skip('user can sign in')") != null, "skipping the test is blocked");
        String protocol = AgentTestWorkflow.browserMcpProtocol();
        check(protocol.contains("browser_navigate") && protocol.contains("process_start") && protocol.contains("getByRole")
                && protocol.contains("never proof that a test passes") && protocol.contains("application defect"), "workflow text");
        check(AgentTestWorkflow.browserMcpMissing(false).contains("master switch is off")
                && AgentTestWorkflow.browserMcpMissing(true).contains("configure Playwright MCP"), "missing-server guidance");
        wf.afterRun("npx playwright test tests/login.spec.js", "1 passed", false, 2);
        check(wf.completionProblem(2) == null, "passing rerun on the current revision completes");
        check(wf.completionProblem(3) != null, "a later change needs another run");
    }

    static void safety(String fakeServer) throws Exception {
        check(McpManager.isBrowserServer("npx", List.of("-y", "@playwright/mcp@latest")), "playwright identified by package");
        check(McpManager.isBrowserServer("node", List.of("/x/node_modules/@playwright/mcp/cli.js", "--headless")), "local install identified");
        check(McpManager.isBrowserServer("npx", List.of("-y", "chrome-devtools-mcp@latest")), "chrome devtools identified");
        check(!McpManager.isBrowserServer("python3", List.of("my_playwright_server.py")), "name alone is not enough");
        for (String tool : List.of("browser_navigate", "browser_click", "browser_type", "browser_snapshot", "browser_fill_form",
                "browser_console_messages", "browser_network_requests", "browser_wait_for", "navigate_page", "take_snapshot"))
            check(McpManager.isBrowserOnlyTool(tool), "browser-only: " + tool);
        for (String tool : List.of("browser_file_upload", "browser_run_code", "upload_file", "delete_file", "write_file"))
            check(!McpManager.isBrowserOnlyTool(tool), "not browser-only: " + tool);

        String home = System.getProperty("user.home");
        McpManager manager = new McpManager(JSON, HttpClient.newHttpClient());
        Files.createDirectories(manager.userServersFile().getParent());
        // Same fake tools twice: once started as "@playwright/mcp" (via the fake npx), once as an unrelated script.
        Files.writeString(manager.userServersFile(), "{\"mcp\":{" +
                "\"playwright\":{\"type\":\"local\",\"command\":\"npx\",\"args\":[\"-y\",\"@playwright/mcp@latest\"],\"timeout\":20000}," +
                "\"lookalike\":{\"type\":\"local\",\"command\":\"python3\",\"args\":[\"" + fakeServer + "\"],\"timeout\":20000}}}");
        manager.enableMasterSwitch();
        McpManager.Catalog catalog = manager.catalog(null);
        String click = function(catalog, "playwright", "browser_navigate");
        String lookalike = function(catalog, "lookalike", "browser_navigate");
        String upload = function(catalog, "playwright", "browser_file_upload");
        check(click != null && lookalike != null && upload != null, "catalog has both servers: " + catalog.byFunction().keySet());
        check(!manager.isReadOnly(catalog, click) && manager.isBrowserSafe(catalog, click), "Playwright navigate allowed under file protection");
        check(!manager.isBrowserSafe(catalog, lookalike), "look-alike server's tool still needs read-only annotation");
        check(!manager.isBrowserSafe(catalog, upload), "file upload still blocked");
        List<Map<String,Object>> preload = manager.browserToolDefinitions(catalog);
        check(preload.size() == 3 && preload.toString().contains(click) && !preload.toString().contains(upload)
                && !preload.toString().contains(lookalike), "preloaded browser tools: " + preload.size());
        manager.shutdown();
        Files.delete(manager.userServersFile());
        Files.deleteIfExists(Path.of(home, ".eliya", "mcp.json"));
    }

    static List<String> mcpArgs(String mcpCli) {
        List<String> args = new java.util.ArrayList<>(List.of(mcpCli, "--headless", "--browser", "chromium", "--isolated"));
        if (!browserExecutable.isBlank()) args.addAll(List.of("--executable-path", browserExecutable));
        return args;
    }

    static String function(McpManager.Catalog catalog, String server, String tool) {
        return catalog.byFunction().entrySet().stream()
                .filter(e -> e.getValue().server().equals(server) && e.getValue().tool().equals(tool))
                .map(Map.Entry::getKey).findFirst().orElse(null);
    }

    static String run(Path dir, List<String> command) throws Exception {
        Process process = new ProcessBuilder(command).directory(dir.toFile()).redirectErrorStream(true).start();
        byte[] out = process.getInputStream().readAllBytes();
        process.waitFor(180, TimeUnit.SECONDS);
        return "exitCode=" + process.exitValue() + ";\n" + new String(out, StandardCharsets.UTF_8);
    }

    static void realLoop(Path sampleSource, String mcpCli, String playwrightCli) throws Exception {
        Path project = Files.createTempDirectory("eliya178-sample");
        Files.createDirectories(project.resolve("tests"));
        for (String file : List.of("index.html", "playwright.config.js", "tests/login.spec.js"))
            Files.copy(sampleSource.resolve(file), project.resolve(file));
        List<String> runTests = List.of("node", playwrightCli, "test", "--reporter=line");

        // 1. The real test fails.
        String first = run(project, runTests);
        check(first.startsWith("exitCode=1") && first.contains("getByRole('button', { name: 'Sign in' })"), "real test fails: " + first.lines().limit(3).toList());
        AgentTestWorkflow wf = AgentTestWorkflow.forObjective("Run the Playwright tests and fix the failures using Playwright MCP");
        wf.markPreflight();
        wf.enableBrowserMcp();
        String diagnosis = wf.afterRun("npx playwright test --reporter=line", first, true, 1);
        check(diagnosis.contains("tests/login.spec.js") && diagnosis.contains("Playwright MCP: before editing"), "real failure diagnosed");

        // 2. Real Playwright MCP, configured the way Eliya does, inspects the live page.
        McpManager manager = new McpManager(JSON, HttpClient.newHttpClient());
        Files.createDirectories(manager.userServersFile().getParent());
        Files.writeString(manager.userServersFile(), JSON.writeValueAsString(Map.of("mcp", Map.of("playwright", Map.of(
                "type", "local", "command", "node", "args", mcpArgs(mcpCli),
                "timeout", 120000)))));
        manager.enableMasterSwitch();
        McpManager.ServerTest started = manager.testServer(project, "playwright");
        check(started.connected() && started.tools().contains("browser_navigate") && started.tools().contains("browser_snapshot"),
                "real Playwright MCP started: " + started);
        McpManager.Catalog catalog = manager.catalog(project);
        String navigate = function(catalog, "playwright", "browser_navigate");
        String snapshot = function(catalog, "playwright", "browser_snapshot");
        String clickTool = function(catalog, "playwright", "browser_click");
        check(manager.isBrowserSafe(catalog, navigate) && manager.isBrowserSafe(catalog, clickTool), "real tools allowed under file protection");
        Process web = new ProcessBuilder("python3", "-m", "http.server", "4179", "--bind", "127.0.0.1").directory(project.toFile())
                .redirectErrorStream(true).redirectOutput(ProcessBuilder.Redirect.DISCARD).start();
        try {
            Thread.sleep(800);
            String page = manager.call(project, catalog, navigate, JSON.readTree("{\"url\":\"http://127.0.0.1:4179/\"}"));
            check(!McpToolOutcomePolicy.failed(navigate, page) && page.contains("isError=false"), "navigate succeeded: " + page);
            String seen = manager.call(project, catalog, snapshot, JSON.createObjectNode());
            check(seen.contains("button \"Log in\"") && !seen.contains("Sign in"), "snapshot shows the real button text: Log in");
        } finally {
            web.destroy();
            manager.shutdown();
        }

        // 3. Fix from the snapshot evidence (what the Agent is instructed to do) and rerun the real test.
        Path spec = project.resolve("tests/login.spec.js");
        String fixed = Files.readString(spec).replace("{ name: 'Sign in' }", "{ name: 'Log in' }");
        check(wf.blockReason("edit", null, fixed) == null, "the fix is not a skip");
        Files.writeString(spec, fixed);
        String rerun = run(project, List.of("node", playwrightCli, "test", "tests/login.spec.js", "--reporter=line"));
        check(rerun.startsWith("exitCode=0") && rerun.contains("1 passed"), "fixed test passes: " + rerun.lines().filter(l -> l.contains("passed") || l.contains("failed")).toList());
        wf.afterRun("npx playwright test tests/login.spec.js", rerun, false, 2);
        check(wf.completionProblem(2) == null, "workflow satisfied by the real passing run");
    }
}
