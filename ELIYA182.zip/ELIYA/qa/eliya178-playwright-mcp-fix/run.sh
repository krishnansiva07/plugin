#!/bin/bash
# ELIYA178: fix failing Playwright tests with Playwright MCP. Always: workflow + safety checks (recorded failing run,
# fake MCP server). When Playwright, @playwright/mcp and a browser are installed: the real loop without a model.
set -euo pipefail
BASE="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
HERE="$BASE/qa/eliya178-playwright-mcp-fix"
FAKE="$BASE/qa/eliya177-mcp-configure/fake_mcp_server.py"
SRC="$BASE/src/main/java/com/llmart/llm/service"
JACKSON_CP="${ELIYA_JACKSON_CP:-}"
if [ -z "$JACKSON_CP" ] && [ -d "$HOME/.m2/repository/com/fasterxml/jackson/core" ]; then
  JACKSON_CP=$(find "$HOME/.m2/repository/com/fasterxml/jackson/core" -name 'jackson-*.jar' ! -name '*sources*' | sort | paste -sd: -)
fi
if [ -z "$JACKSON_CP" ] || ! command -v python3 >/dev/null 2>&1; then
  echo "SKIP ELIYA178 checks (Jackson or python3 not found; set ELIYA_JACKSON_CP)"; exit 0
fi
OUT="$(mktemp -d)"; trap 'rm -rf "$OUT"' EXIT
S="$OUT/stubs"
mkdir -p "$S/jakarta/annotation" "$S/org/springframework/stereotype" "$S/com/llmart/llm/dto" "$S/com/llmart/llm/service" "$OUT/classes" "$OUT/home" "$OUT/bin"
echo 'package jakarta.annotation; public @interface PreDestroy {}' > "$S/jakarta/annotation/PreDestroy.java"
echo 'package org.springframework.stereotype; public @interface Service {}' > "$S/org/springframework/stereotype/Service.java"
echo 'package com.llmart.llm.dto; public class ChatSettings {}' > "$S/com/llmart/llm/dto/ChatSettings.java"
echo 'package com.llmart.llm.service; public class AgentCancelledException extends RuntimeException { public AgentCancelledException(String m) { super(m); } }' > "$S/com/llmart/llm/service/AgentCancelledException.java"
printf 'package com.llmart.llm.service;\nimport java.util.List;\npublic class WorkspaceDocumentScanner { public record Visual(String locator, String mimeType, byte[] bytes, String context) { } public record Scan(String text, int detectedVisuals, List<Visual> visuals, List<String> warnings) { } }\n' > "$S/com/llmart/llm/service/WorkspaceDocumentScanner.java"
printf 'package com.llmart.llm.service;\nimport java.util.List;\npublic class VisionDocumentService { public record Analysis(String findings, int analysedImages, String status, List<String> warnings) {} public Analysis analyse(String a, com.llmart.llm.dto.ChatSettings s, WorkspaceDocumentScanner.Scan sc, String x, String o) { return new Analysis("", 0, "skipped", List.of()); } }\n' > "$S/com/llmart/llm/service/VisionDocumentService.java"
javac --release 17 -proc:none -encoding UTF-8 -cp "$JACKSON_CP" -d "$OUT/classes" $(find "$S" -name '*.java') \
  "$SRC/McpManager.java" "$SRC/McpPromptGate.java" "$SRC/McpToolOutcomePolicy.java" "$SRC/AgentTestWorkflow.java" \
  "$HERE/PlaywrightMcpFixE2E.java" 2>&1 | grep -v -E '^Note:|Picked up' || true
printf '#!/bin/sh\nexec python3 "%s" "$@"\n' "$FAKE" > "$OUT/bin/npx"; chmod +x "$OUT/bin/npx"
# The Agent's file-protection gate must use the browser-safe rule (source contract; AgentService needs Spring to run).
grep -q '!mcp.isReadOnly(mcpCatalog, tool) && !mcp.isBrowserSafe(mcpCatalog, tool)' "$SRC/AgentService.java" \
  || { echo "FAILED: AgentService file protection does not allow browser-safe MCP tools"; exit 1; }
grep -q 'AgentTestWorkflow.browserMcpProtocol()' "$SRC/AgentService.java" \
  || { echo "FAILED: AgentService does not inject the Playwright MCP workflow"; exit 1; }
# Optional real loop: local Playwright + @playwright/mcp + browsers.
MODULES="${ELIYA_NODE_MODULES:-$(npm root -g 2>/dev/null || true)}"
MCP_CLI=""; PW_CLI=""
if [ -n "$MODULES" ] && [ -f "$MODULES/@playwright/mcp/cli.js" ] && [ -f "$MODULES/playwright/cli.js" ] && command -v node >/dev/null 2>&1; then
  if [ -n "${PLAYWRIGHT_BROWSERS_PATH:-}" ] && ls "$PLAYWRIGHT_BROWSERS_PATH" 2>/dev/null | grep -q chromium || ls "$HOME/.cache/ms-playwright" 2>/dev/null | grep -q chromium; then
    MCP_CLI="$MODULES/@playwright/mcp/cli.js"; PW_CLI="$MODULES/playwright/cli.js"
  fi
fi
# Use an installed Chromium explicitly (the MCP package may bundle a newer Playwright than the downloaded browsers).
CHROME="${ELIYA_TEST_CHROME:-}"
if [ -z "$CHROME" ] && [ -n "${PLAYWRIGHT_BROWSERS_PATH:-}" ]; then
  CHROME=$(find "$PLAYWRIGHT_BROWSERS_PATH" -maxdepth 3 -type f -name chrome -path '*chromium-*' 2>/dev/null | sort | head -1)
fi
PATH="$OUT/bin:$PATH" NODE_PATH="$MODULES" FAKE_MCP_EXTRA_TOOLS=browser_file_upload java -Duser.home="$OUT/home" \
  -cp "$JACKSON_CP:$OUT/classes" com.llmart.llm.service.PlaywrightMcpFixE2E "$HERE" "$FAKE" "$MCP_CLI" "$PW_CLI" "$CHROME"
