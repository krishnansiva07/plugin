const { defineConfig } = require('playwright/test');
module.exports = defineConfig({
  testDir: './tests',
  use: { baseURL: 'http://127.0.0.1:4178' },
  webServer: { command: 'python3 -m http.server 4178 --bind 127.0.0.1', url: 'http://127.0.0.1:4178', reuseExistingServer: true },
});
