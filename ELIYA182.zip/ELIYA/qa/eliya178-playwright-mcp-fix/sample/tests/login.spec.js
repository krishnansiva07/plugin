const { test, expect } = require('playwright/test');
test('user can sign in', async ({ page }) => {
  await page.goto('/');
  await page.getByLabel('Username').fill('asha');
  await page.getByRole('button', { name: 'Sign in' }).click({ timeout: 3000 });
  await expect(page.locator('#msg')).toHaveText('Signed in as asha');
});
