#!/usr/bin/env bash
set -euo pipefail
BASE="$(cd "$(dirname "$0")/../.." && pwd)"
python3 - "$BASE/src/main/java/com/llmart/llm/service/AgentService.java" <<'PY'
from pathlib import Path
import sys
s=Path(sys.argv[1]).read_text()
stage=Path(sys.argv[1]).with_name('AgentPlanningStage.java').read_text()  # ELIYA154: planning moved here
a=stage[stage.index('    List<String> createExecutionPlan('):stage.index('    /** Separate read-only analysis role:')]
b=stage[stage.index('    List<String> generateExecutionPlan('):stage.index('    /** Read-only deterministic discovery')]
assert a.count('generateExecutionPlan(')==1, 'planner must make exactly one draft'
assert 'for (int attempt' not in a, 'plan retry loop still active'
assert 'validateExecutionPlan(' not in a, 'LLM validator still active'
assert 'AgentPlanRelevance.validate(' not in a, 'keyword-based plan rejection still active'
assert 'questions.ask(' not in a, 'planner clarification retry still active'
assert 'minSteps()' not in a and 'maxSteps()' not in a, 'step quotas still enforced'
prompt=Path(sys.argv[1]).with_name('AgentPlanPrompt.java').read_text()
assert 'AgentPlanPrompt.user(' in b and 'AgentPlanPrompt.system(' in b, 'planner prompt builder not used'
assert 'ORIGINAL USER REQUEST (highest priority)' in prompt, 'user task priority missing'
assert 'REQUEST TYPE HINT (not an instruction)' in prompt, 'profile must not override user prompt'
assert 'minimum' not in prompt.lower() or 'no minimum' in prompt.lower(), 'step quota must not be enforced'
assert 'FORBIDDEN placeholder' in prompt, 'placeholder steps must be rejected'
assert 'planApprovalRequired()' not in s, 'conversational Agent should not wait for redundant plan approval'
assert 'protectedSnapshots.begin(' in s, 'rollback protection must be retained'
assert 'File deletion protection is separate' in s, 'deletion safety must remain'
assert 'clipHeadTail(text, 32_000' in s, 'original prompt preservation regressed'
print('PASS: single user-prompt-first Agent plan (one bounded refinement); no semantic validator, quotas or clarification loops')
print('PASS: direct Agent has no general plan approval; rollback and protected deletion remain')
PY
