"""Tiny stdio MCP server standing in for npx @playwright/mcp in tests (no network)."""
import json
import os
import sys

log = os.environ.get("FAKE_MCP_LOG")
if log:
    with open(log, "a") as f:
        f.write("ARGS " + " ".join(sys.argv[1:]) + "\n")
if os.environ.get("FAKE_MCP_FAIL"):
    sys.stderr.write("npm ERR! code ENOTFOUND\nnpm ERR! network request to https://registry.npmjs.org/@playwright%2fmcp failed\n")
    sys.stderr.flush()
    sys.exit(1)

TOOLS = [
    {"name": "browser_navigate", "description": "Navigate to a URL", "inputSchema": {"type": "object", "properties": {"url": {"type": "string"}}}},
    {"name": "browser_snapshot", "description": "Accessibility snapshot", "inputSchema": {"type": "object", "properties": {}}, "annotations": {"readOnlyHint": True}},
    {"name": "browser_install", "description": "Install the browser", "inputSchema": {"type": "object", "properties": {}}},
]
for extra in filter(None, os.environ.get("FAKE_MCP_EXTRA_TOOLS", "").split(",")):
    TOOLS.append({"name": extra, "description": "extra " + extra, "inputSchema": {"type": "object", "properties": {}}})
for line in sys.stdin:
    try:
        msg = json.loads(line)
    except ValueError:
        continue
    if "id" not in msg:
        continue
    method = msg.get("method")
    if method == "initialize":
        result = {"protocolVersion": "2025-06-18", "capabilities": {"tools": {}}, "serverInfo": {"name": "fake-playwright", "version": "1"}}
    elif method == "tools/list":
        result = {"tools": TOOLS}
    elif method == "tools/call":
        name = msg["params"]["name"]
        if log:
            with open(log, "a") as f:
                f.write("CALL " + name + "\n")
        result = {"content": [{"type": "text", "text": "Browser installed" if name == "browser_install" else "ok " + name}], "isError": False}
    else:
        print(json.dumps({"jsonrpc": "2.0", "id": msg["id"], "error": {"code": -32601, "message": "unknown"}}), flush=True)
        continue
    print(json.dumps({"jsonrpc": "2.0", "id": msg["id"], "result": result}), flush=True)
