package com.llmart.llm.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.net.http.HttpClient;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Predicate;

/** ELIYA177: Eliya knows well-known MCP servers and configures them end to end (mcp_configure). */
public final class McpConfigureSmoke {
    private static final ObjectMapper JSON = new ObjectMapper();
    private static int passed;

    static void check(boolean condition, String name) {
        if (!condition) throw new AssertionError("FAILED: " + name);
        passed++;
    }

    static JsonNode args(String json) throws Exception { return JSON.readTree(json); }

    /** Records what the installer asked for. */
    static final class FakeServers implements McpServerInstaller.Servers {
        final Path file;
        boolean master;
        boolean enabledCalled;
        McpManager.ServerTest result = new McpManager.ServerTest(true, List.of("browser_navigate", "browser_snapshot", "browser_install"), "");
        final List<String> calls = new ArrayList<>();
        FakeServers(Path file) { this.file = file; }
        public Path userServersFile() { return file; }
        public boolean masterSwitchOn() { return master; }
        public void enableMasterSwitch() { master = true; enabledCalled = true; }
        public McpManager.ServerTest test(Path root, String name) { calls.add("test:" + name); return result; }
        public String callTool(Path root, String server, String tool) { calls.add("call:" + server + ":" + tool); return "mcpServer=" + server + "; tool=" + tool + "; isError=false\nBrowser installed"; }
    }

    static final class FakeCommands implements McpServerInstaller.Commands {
        String node = "v20.11.1";
        int nodeExit = 0;
        final List<List<String>> runs = new ArrayList<>();
        public McpServerInstaller.CommandResult run(List<String> command, Duration timeout) {
            runs.add(command);
            if (command.contains("--version") && command.get(0).startsWith("node")) return new McpServerInstaller.CommandResult(nodeExit, node);
            return new McpServerInstaller.CommandResult(0, "10.2.4");
        }
    }

    public static void main(String[] a) throws Exception {
        knowledge();
        installer();
        realManager(Path.of(a[0]));
        System.out.println("ELIYA177 MCP configure: " + passed + " checks passed");
    }

    static void knowledge() {
        check(McpKnownServers.byId("playwright").isPresent() && McpKnownServers.byId("Playwright MCP").isPresent()
                && McpKnownServers.byId("@playwright/mcp").isPresent() && McpKnownServers.byId("chrome devtools").isPresent(), "aliases resolve");
        check(McpKnownServers.byId("unknown-thing").isEmpty(), "unknown stays unknown");
        check(McpKnownServers.mentionedIn("configure playwright MCP").get(0).id().equals("playwright"), "mention found");
        check(McpKnownServers.mentionedIn("Set up the Chrome DevTools MCP server").get(0).id().equals("chrome-devtools"), "devtools mention");
        for (String request : List.of("configure playwright MCP", "Configure Playwright MCP", "set up playwright mcp server",
                "Please install the Playwright MCP", "add chrome devtools mcp", "connect playwright MCP to eliya"))
            check(McpKnownServers.isSetupRequest(request), "setup request: " + request);
        check(!McpKnownServers.isSetupRequest("what is playwright MCP?") && !McpKnownServers.isSetupRequest("configure playwright tests"),
                "not setup: question / no MCP word");
        String agent = McpKnownServers.knowledgeFor("configure playwright MCP", true);
        check(agent.contains("Microsoft's official Playwright MCP server") && agent.contains("npx -y @playwright/mcp@latest")
                && agent.contains("Node.js 18.0+") && agent.contains("call the mcp_configure tool (server=playwright)"), "agent knowledge");
        String analyse = McpKnownServers.knowledgeFor("configure playwright MCP", false);
        check(analyse.contains("Analyse mode") && analyse.contains("Agent mode") && !analyse.contains("call the mcp_configure"), "analyse knowledge");
        String question = McpKnownServers.knowledgeFor("what is playwright MCP?", false);
        check(question.contains("browser") && !question.contains("Analyse mode (read-only)"), "question gets facts only");
        check(McpKnownServers.knowledgeFor("migrate selenium tests to playwright", true).isEmpty(), "no MCP word: no knowledge");
        check(McpKnownServers.knowledgeFor("use the Jira MCP to read ABC-1", true).isEmpty(), "unrelated MCP request: nothing added");
        check(!McpKnownServers.nodeAtLeast("v20.11.1", "20.19") && McpKnownServers.nodeAtLeast("v22.1.0", "20.19")
                && McpKnownServers.nodeAtLeast("v18.0.0", "18.0") && !McpKnownServers.nodeAtLeast("v16.20.2", "18.0")
                && !McpKnownServers.nodeAtLeast("garbage", "18.0"), "node version comparison");
        check(McpKnownServers.catalogText().contains("playwright") && McpKnownServers.catalogText().contains("chrome-devtools"), "catalog");
    }

    static McpServerInstaller installer(FakeServers servers, FakeCommands commands, String os, Map<String,String> env, Predicate<Path> exists) {
        return new McpServerInstaller(servers, commands, os, env, exists);
    }

    static void installer() throws Exception {
        Path home = Files.createTempDirectory("eliya177-home");
        Path userFile = home.resolve(".eliya/mcp-servers.json");
        Path workspace = Files.createTempDirectory("eliya177-ws");

        // Node.js missing: blocked, nothing written, master switch untouched.
        FakeServers s = new FakeServers(userFile);
        FakeCommands c = new FakeCommands();
        c.nodeExit = 1; c.node = "node: not found";
        McpServerInstaller.Outcome o = installer(s, c, "Linux", Map.of(), p -> false).configure(workspace, args("{\"server\":\"playwright\"}"));
        check(!o.success() && o.text().startsWith("BLOCKED: Node.js is not installed") && o.text().contains("https://nodejs.org"), "node missing blocked");
        check(!Files.exists(userFile) && !s.enabledCalled && s.calls.isEmpty(), "nothing changed when node missing");

        // Node too old.
        c = new FakeCommands(); c.node = "v16.20.2";
        o = installer(s, c, "Linux", Map.of(), p -> false).configure(workspace, args("{\"server\":\"playwright\"}"));
        check(!o.success() && o.text().contains("too old") && o.text().contains("18.0"), "old node blocked");
        c = new FakeCommands(); c.node = "v20.11.1";
        o = installer(s, c, "Linux", Map.of(), p -> false).configure(workspace, args("{\"server\":\"chrome-devtools\"}"));
        check(!o.success() && o.text().contains("20.19"), "chrome-devtools needs node 20.19");

        // Success, all projects, Linux without display: headless, browser installed, existing entries kept.
        Files.createDirectories(userFile.getParent());
        Files.writeString(userFile, "{\"mcp\":{\"memory\":{\"type\":\"local\",\"command\":\"npx\",\"args\":[\"-y\",\"@modelcontextprotocol/server-memory\"]}}}");
        s = new FakeServers(userFile);
        c = new FakeCommands();
        o = installer(s, c, "Linux", Map.of(), p -> false).configure(workspace, args("{\"server\":\"Playwright MCP\"}"));
        check(o.success() && o.text().startsWith("MCP CONFIGURED AND VERIFIED: Playwright MCP (Microsoft)"), "configured and verified: " + o.text());
        JsonNode written = JSON.readTree(Files.readString(userFile));
        check(written.path("mcp").path("memory").path("args").get(1).asText().equals("@modelcontextprotocol/server-memory"), "other entry kept");
        JsonNode entry = written.path("mcp").path("playwright");
        check(entry.path("command").asText().equals("npx") && entry.path("args").toString().equals("[\"-y\",\"@playwright/mcp@latest\",\"--headless\"]")
                && entry.path("timeout").asLong() == 180000 && entry.path("type").asText().equals("local"), "entry written: " + entry);
        check(s.enabledCalled && o.text().contains("MCP master switch: turned on"), "master switch turned on");
        check(s.calls.equals(List.of("test:playwright", "call:playwright:browser_install")), "connection tested, browser installed: " + s.calls);
        check(o.text().contains("3 tools") && o.text().contains("How to use it") && o.text().contains("next Agent request"), "usage explained");
        check(c.runs.get(1).equals(List.of("npx", "--version")), "npx checked");

        // Again: entry updated in place, master already on, Chrome present → no install.
        s.master = true; s.enabledCalled = false; s.calls.clear();
        o = installer(s, new FakeCommands(), "Linux", Map.of("DISPLAY", ":0"), p -> p.toString().equals("/opt/google/chrome/chrome"))
                .configure(workspace, args("{\"server\":\"playwright\"}"));
        check(o.success() && o.text().contains("updated entry") && o.text().contains("already on") && !s.enabledCalled, "update in place");
        check(JSON.readTree(Files.readString(userFile)).path("mcp").path("playwright").path("args").size() == 2, "display present: not headless");
        check(s.calls.equals(List.of("test:playwright")) && o.text().contains("chrome found"), "chrome present: no install");

        // Windows: Edge used when Chrome is missing; npx checked through cmd.exe.
        s = new FakeServers(home.resolve("win.json"));
        c = new FakeCommands();
        Map<String,String> winEnv = Map.of("ProgramFiles(x86)", "C:\\PF86", "ProgramFiles", "C:\\PF");
        o = installer(s, c, "Windows 11", winEnv, p -> p.toString().contains("msedge.exe")).configure(null, args("{\"server\":\"playwright\"}"));
        check(o.success() && o.text().contains("Microsoft Edge (installed) is used"), "edge chosen on windows");
        check(JSON.readTree(Files.readString(home.resolve("win.json"))).path("mcp").path("playwright").path("args").toString()
                .equals("[\"-y\",\"@playwright/mcp@latest\",\"--browser=msedge\"]"), "windows args (no headless, msedge)");
        check(c.runs.get(0).get(0).equals("node.exe") && c.runs.get(1).equals(List.of("cmd.exe", "/c", "npx", "--version")), "windows checks");
        check(s.calls.equals(List.of("test:playwright")), "edge present: no browser install");

        // Project scope.
        s = new FakeServers(userFile);
        o = installer(s, new FakeCommands(), "Linux", Map.of(), p -> false).configure(workspace, args("{\"server\":\"playwright\",\"scope\":\"project\",\"headless\":false,\"installBrowser\":false}"));
        Path projectFile = workspace.resolve(".opencode/mcp.json");
        check(o.success() && Files.isRegularFile(projectFile) && !o.text().contains("every project"), "project scope");
        check(JSON.readTree(Files.readString(projectFile)).path("mcp").path("playwright").path("args").size() == 2 && s.calls.equals(List.of("test:playwright")),
                "explicit headless=false and installBrowser=false respected");
        o = installer(s, new FakeCommands(), "Linux", Map.of(), p -> false).configure(null, args("{\"server\":\"playwright\",\"scope\":\"project\"}"));
        check(!o.success() && o.text().contains("scope=project needs a project folder"), "project scope needs workspace");

        // Connection failure: config kept, concrete fix.
        s = new FakeServers(home.resolve("fail.json"));
        s.result = new McpManager.ServerTest(false, List.of(), "MCP process exited with code 1; server output: npm ERR! code ENOTFOUND registry.npmjs.org");
        o = installer(s, new FakeCommands(), "Linux", Map.of(), p -> false).configure(workspace, args("{\"server\":\"playwright\"}"));
        check(!o.success() && o.text().startsWith("MCP CONFIGURED BUT NOT CONNECTED") && o.text().contains("npm config set proxy")
                && o.text().contains("Do not report this task as completed") && Files.exists(home.resolve("fail.json")), "connection failure diagnosed");
        check(McpServerInstaller.diagnose("MCP request timed out: initialize", "X").contains("first npx download"), "timeout diagnosed");
        check(McpServerInstaller.diagnose("Cannot start MCP command 'npx': No such file", "X").contains("Install Node.js"), "missing npx diagnosed");

        // Unknown, custom package, remote URL, invalid input.
        o = installer(s, new FakeCommands(), "Linux", Map.of(), p -> false).configure(workspace, args("{\"server\":\"foobar\"}"));
        check(!o.success() && o.text().startsWith("UNKNOWN MCP SERVER") && o.text().contains("playwright"), "unknown lists catalog");
        s = new FakeServers(home.resolve("custom.json"));
        s.result = new McpManager.ServerTest(true, List.of("hello"), "");
        o = installer(s, new FakeCommands(), "Linux", Map.of(), p -> false).configure(workspace, args("{\"server\":\"acme\",\"package\":\"@acme/mcp-server\"}"));
        check(o.success() && JSON.readTree(Files.readString(home.resolve("custom.json"))).path("mcp").path("acme").path("args").toString()
                .equals("[\"-y\",\"@acme/mcp-server\"]"), "custom npm package");
        o = installer(s, new FakeCommands(), "Linux", Map.of(), p -> false).configure(workspace, args("{\"server\":\"x\",\"package\":\"rm -rf /\"}"));
        check(!o.success() && o.text().startsWith("INVALID PACKAGE NAME"), "package validated");
        FakeCommands none = new FakeCommands();
        o = installer(s, none, "Linux", Map.of(), p -> false).configure(workspace, args("{\"server\":\"docs\",\"url\":\"https://mcp.example.com/mcp\"}"));
        check(o.success() && none.runs.isEmpty() && JSON.readTree(Files.readString(home.resolve("custom.json"))).path("mcp").path("docs").path("type").asText().equals("remote"),
                "remote server: no node check");
        o = installer(s, new FakeCommands(), "Linux", Map.of(), p -> false).configure(workspace, args("{\"server\":\"playwright\",\"browser\":\"opera\"}"));
        check(!o.success() && o.text().startsWith("INVALID BROWSER"), "browser validated");

        // Existing files: other tools' sections kept; invalid JSON never overwritten.
        Path other = home.resolve("other.json");
        Files.writeString(other, "{\"mcpServers\":{\"x\":{\"command\":\"y\"}},\"theme\":\"dark\"}");
        McpServerInstaller.writeEntry(other, "playwright", JSON.createObjectNode().put("command", "npx"));
        JsonNode merged = JSON.readTree(Files.readString(other));
        check(merged.path("mcpServers").has("x") && merged.path("theme").asText().equals("dark") && merged.path("mcp").has("playwright"), "foreign sections kept");
        Path broken = home.resolve(".eliya/broken.json");
        Files.writeString(broken, "{not json");
        s = new FakeServers(broken);
        o = installer(s, new FakeCommands(), "Linux", Map.of(), p -> false).configure(workspace, args("{\"server\":\"playwright\"}"));
        check(!o.success() && o.text().contains("not valid JSON") && Files.readString(broken).equals("{not json") && !s.enabledCalled, "invalid JSON untouched");

        String detail = installer(new FakeServers(userFile), new FakeCommands(), "Linux", Map.of(), p -> false)
                .approvalDetail(args("{\"server\":\"playwright\"}"), null);
        check(detail.contains("Playwright MCP") && detail.contains(userFile.toString()) && detail.contains("npx -y @playwright/mcp@latest")
                && detail.contains("master switch"), "approval explains everything");
    }

    static void realManager(Path fakeServer) throws Exception {
        // Windows command wrapping.
        check(McpManager.launchCommand("npx", List.of("-y", "x"), true, f -> null).equals(List.of("cmd.exe", "/c", "npx", "-y", "x")), "npx wrapped on windows");
        check(McpManager.launchCommand("node", List.of("s.js"), true, f -> f.equals("node.exe") ? Path.of("C:/n/node.exe") : null).equals(List.of("node", "s.js")), "exe unchanged");
        check(McpManager.launchCommand("tool", List.of(), true, f -> f.equals("tool.cmd") ? Path.of("C:/t/tool.cmd") : null).get(0).equals("cmd.exe"), "cmd script wrapped");
        check(McpManager.launchCommand("npx", List.of("-y"), false, f -> null).equals(List.of("npx", "-y")), "unix unchanged");

        String home = System.getProperty("user.home");
        McpManager manager = new McpManager(JSON, HttpClient.newHttpClient());
        check(manager.userServersFile().equals(Path.of(home, ".eliya", "mcp-servers.json")), "user servers file under home");
        Path log = Path.of(home, "fake.log");
        String entry = "{\"mcp\":{\"playwright\":{\"type\":\"local\",\"command\":\"python3\",\"args\":[\"" + fakeServer + "\",\"--headless\"]," +
                "\"env\":{\"FAKE_MCP_LOG\":\"" + log + "\"},\"timeout\":20000}}}";
        Files.createDirectories(manager.userServersFile().getParent());
        Files.writeString(manager.userServersFile(), entry);
        check(!manager.testServer(null, "playwright").connected() && manager.testServer(null, "playwright").error().contains("master switch"), "master switch off blocks");
        manager.enableMasterSwitch();
        check(manager.globallyEnabled(), "master switch on");
        McpManager.ServerTest test = manager.testServer(null, "playwright");
        check(test.connected() && test.tools().equals(List.of("browser_navigate", "browser_snapshot", "browser_install")), "real stdio server connected: " + test);
        check(Files.readString(log).contains("ARGS --headless"), "server arguments passed");
        JsonNode installed = manager.callServerTool(null, "playwright", "browser_install", null);
        check(installed.toString().contains("Browser installed"), "tool call through session");
        check(manager.status(null).contains("playwright: connected; tools=3"), "status lists the server");
        check(manager.configuredServerNames(null).contains("playwright"), "configured names");

        // Settings save keeps the switch semantics and never touches Eliya-managed servers.
        manager.saveManualConfiguration("itg-devops", true, "", 100000L, Map.of());
        check(manager.globallyEnabled() && manager.testServer(null, "playwright").connected(), "settings save keeps managed servers");
        Files.writeString(Path.of(home, ".eliya", "mcp.json"), "{\"eliyaMcpEnabled\":false,\"mcp\":{\"itg\":{\"type\":\"remote\",\"url\":\"https://x.example\",\"headers\":{\"X-Token\":\"t\"}}}}");
        manager.enableMasterSwitch();
        JsonNode managed = JSON.readTree(Files.readString(Path.of(home, ".eliya", "mcp.json")));
        check(managed.path("eliyaMcpEnabled").asBoolean() && managed.path("mcp").path("itg").path("headers").path("X-Token").asText().equals("t"),
                "enabling keeps the manual server and its headers");

        // A failing server reports its own error output.
        Files.writeString(manager.userServersFile(), entry.replace("\"env\":{", "\"env\":{\"FAKE_MCP_FAIL\":\"1\","));
        manager.reloadConfiguration();
        McpManager.ServerTest failed = manager.testServer(null, "playwright");
        check(!failed.connected() && failed.error().contains("ENOTFOUND"), "stderr tail in error: " + failed.error());

        // End to end: installer + real manager + "npx" (a fake on PATH that starts the stdio server).
        Files.delete(manager.userServersFile());
        manager.reloadConfiguration();
        FakeCommands commands = new FakeCommands();
        McpServerInstaller real = new McpServerInstaller(new McpServerInstaller.Servers() {
            public Path userServersFile() { return manager.userServersFile(); }
            public boolean masterSwitchOn() { return manager.globallyEnabled(); }
            public void enableMasterSwitch() { manager.enableMasterSwitch(); }
            public McpManager.ServerTest test(Path root, String name) { return manager.testServer(root, name); }
            public String callTool(Path root, String server, String tool) throws Exception { return String.valueOf(manager.callServerTool(root, server, tool, null)); }
        }, commands, "Linux", new HashMap<>(), p -> false);
        Files.writeString(Path.of(home, ".eliya", "mcp.json"), "{\"eliyaMcpEnabled\":false,\"mcp\":{}}");
        McpServerInstaller.Outcome outcome = real.configure(null, args("{\"server\":\"playwright\"}"));
        check(outcome.success() && outcome.text().contains("3 tools") && outcome.text().contains("turned on"), "end to end: " + outcome.text());
        check(Files.readString(log).contains("ARGS -y @playwright/mcp@latest --headless") && Files.readString(log).contains("CALL browser_install"),
                "end to end: npx args and browser install");
        manager.shutdown();
    }
}
