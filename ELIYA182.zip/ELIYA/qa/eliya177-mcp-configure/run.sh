#!/bin/bash
# ELIYA177: built-in knowledge of well-known MCP servers + mcp_configure (Node check, config, master switch,
# connection test, Playwright browser). Compiles the REAL McpManager/McpServerInstaller/McpKnownServers with
# small stubs and drives a fake stdio MCP server (no network). Needs Jackson (CI: ~/.m2 after `mvn verify`).
set -euo pipefail
BASE="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
HERE="$BASE/qa/eliya177-mcp-configure"
SRC="$BASE/src/main/java/com/llmart/llm/service"
JACKSON_CP="${ELIYA_JACKSON_CP:-}"
if [ -z "$JACKSON_CP" ] && [ -d "$HOME/.m2/repository/com/fasterxml/jackson/core" ]; then
  JACKSON_CP=$(find "$HOME/.m2/repository/com/fasterxml/jackson/core" -name 'jackson-*.jar' ! -name '*sources*' | sort | paste -sd: -)
fi
if [ -z "$JACKSON_CP" ] || ! command -v python3 >/dev/null 2>&1; then
  echo "SKIP ELIYA177 MCP configure checks (Jackson or python3 not found; set ELIYA_JACKSON_CP)"; exit 0
fi
OUT="$(mktemp -d)"; trap 'rm -rf "$OUT"' EXIT
S="$OUT/stubs"
mkdir -p "$S/jakarta/annotation" "$S/org/springframework/stereotype" "$S/com/llmart/llm/dto" "$S/com/llmart/llm/service" "$OUT/classes" "$OUT/home" "$OUT/bin"
echo 'package jakarta.annotation; public @interface PreDestroy {}' > "$S/jakarta/annotation/PreDestroy.java"
echo 'package org.springframework.stereotype; public @interface Service {}' > "$S/org/springframework/stereotype/Service.java"
echo 'package com.llmart.llm.dto; public class ChatSettings {}' > "$S/com/llmart/llm/dto/ChatSettings.java"
echo 'package com.llmart.llm.service; public class AgentCancelledException extends RuntimeException { public AgentCancelledException(String m) { super(m); } }' > "$S/com/llmart/llm/service/AgentCancelledException.java"
cat > "$S/com/llmart/llm/service/WorkspaceDocumentScanner.java" <<'JAVA'
package com.llmart.llm.service;
import java.util.List;
public class WorkspaceDocumentScanner {
  public record Visual(String locator, String mimeType, byte[] bytes, String context) { }
  public record Scan(String text, int detectedVisuals, List<Visual> visuals, List<String> warnings) { }
}
JAVA
cat > "$S/com/llmart/llm/service/VisionDocumentService.java" <<'JAVA'
package com.llmart.llm.service;
import java.util.List;
public class VisionDocumentService {
  public record Analysis(String findings, int analysedImages, String status, List<String> warnings) {}
  public Analysis analyse(String apiKey, com.llmart.llm.dto.ChatSettings settings, WorkspaceDocumentScanner.Scan scan, String source, String objective) {
    return new Analysis("", 0, "skipped", List.of());
  }
}
JAVA
javac --release 17 -proc:none -encoding UTF-8 -cp "$JACKSON_CP" -d "$OUT/classes" $(find "$S" -name '*.java') \
  "$SRC/McpManager.java" "$SRC/McpPromptGate.java" "$SRC/McpKnownServers.java" "$SRC/McpServerInstaller.java" \
  "$HERE/McpConfigureSmoke.java" 2>&1 | grep -v -E '^Note:|Picked up' || true
printf '#!/bin/sh\nexec python3 "%s" "$@"\n' "$HERE/fake_mcp_server.py" > "$OUT/bin/npx"; chmod +x "$OUT/bin/npx"
PATH="$OUT/bin:$PATH" FAKE_MCP_LOG="$OUT/home/fake.log" java -Duser.home="$OUT/home" -cp "$JACKSON_CP:$OUT/classes" \
  com.llmart.llm.service.McpConfigureSmoke "$HERE/fake_mcp_server.py"
