package com.llmart.llm.service;

import java.io.IOException;
import java.nio.file.Files;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class AgentFlowHardeningSmoke {
    private static int checks;
    private static void check(boolean result, String why) {
        if (!result) throw new AssertionError(why);
        checks++;
    }
    public static void main(String[] args) throws Exception {
        // This model-turn retry never dispatches a filesystem command or edit.
        check(AgentRuntimeFailurePolicy.retryModelTurnWithoutApproval(new IOException("connection reset")), "transport retry");
        check(!AgentRuntimeFailurePolicy.retryModelTurnWithoutApproval(new SecurityException("denied")), "security failure not retried");
        check(!AgentRuntimeFailurePolicy.retryModelTurnWithoutApproval(new IllegalStateException("bug")), "unexpected code defect not silently retried");
        check(AgentRuntimeFailurePolicy.question("execution", "run integration tests", "timed out").contains("timed out"), "specific question");

        String original = "Migrate Selenium tests to Playwright TypeScript.\n" +
            "- Preserve Cucumber feature scenarios\n" +
            "- Run integration tests using existing runner\n" +
            "- Keep legacy reference read only";
        List<String> plan = AgentPlanRecovery.fromUserRequest(original, false);
        check(plan.size() >= 5, "fallback retains distinct requirements");
        check(plan.stream().anyMatch(step -> step.contains("Cucumber feature")), "Cucumber preserved");
        check(plan.stream().anyMatch(step -> step.contains("Run integration tests")), "test execution preserved");
        check(plan.stream().anyMatch(step -> step.contains("legacy reference read only")), "reference permissions preserved");
        check(!AgentPlanSpecificity.mismatch("Migrate Selenium to Playwright and run integration tests",
                List.of("Read Selenium tests", "Modify existing tests", "Verify result")).isBlank(), "omitted target rejected");
        check(AgentPlanSpecificity.mismatch("Migrate Selenium to Playwright and run integration tests",
                List.of("Inspect Selenium tests", "Migrate Selenium tests to Playwright TypeScript", "Run integration tests with configured runner")).isBlank(),
                "complete targeted plan accepted");

        var questions = new AgentQuestionService();
        var pool = Executors.newSingleThreadExecutor();
        questions.enable("run-one");
        try {
            var awaiting = pool.submit(() -> questions.ask("run-one", "Provider unavailable. Retry?",
                    List.of("Retry after fixing provider", "Stop and keep current work"), new AgentRunService.AgentRun()));
            Map<String,Object> question = Map.of();
            for (int i=0;i<100 && question.isEmpty();i++) {
                question = questions.pending("run-one");
                if (question.isEmpty()) Thread.sleep(10);
            }
            check(!question.isEmpty(), "real pending clarification");
            check(!questions.answer("run-one", "incorrect", "Retry after fixing provider", ""), "question id bound");
            check(questions.answer("run-one", question.get("id").toString(), "Retry after fixing provider", ""), "preset accepted");
            check("User selected: Retry after fixing provider".equals(awaiting.get(2, TimeUnit.SECONDS)), "exact answer preserved");
        } finally { questions.disable("run-one"); pool.shutdownNow(); }

        var temp = Files.createTempDirectory("eliya-test-discovery-");
        try {
            Files.writeString(temp.resolve("pom.xml"), "<project><properties><skipTests>true</skipTests></properties></project>");
            String discovered = AgentTestDiscovery.inspect(temp, "");
            check(discovered.contains("runner=Maven"), "Maven runner discovered");
            check(discovered.contains("risk=POM disables tests"), "test skip detected");
            check(discovered.contains("no tests executed"), "discovery cannot masquerade as execution");
        } finally { Files.deleteIfExists(temp.resolve("pom.xml")); Files.deleteIfExists(temp); }
        System.out.println("PASS: " + checks + " focused Java execution-flow assertions");
    }
}
