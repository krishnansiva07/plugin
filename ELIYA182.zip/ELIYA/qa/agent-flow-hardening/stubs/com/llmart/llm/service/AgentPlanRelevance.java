package com.llmart.llm.service;
public final class AgentPlanRelevance {
    public static boolean isExternalDocumentRequest(String prompt) { return false; }
    public static boolean isMarkdownOutputRequest(String prompt) { return false; }
}
