package com.llmart.llm.service;
public final class AgentConversationIntent {
    public static boolean isFastReadOnly(String prompt) { return false; }
}
