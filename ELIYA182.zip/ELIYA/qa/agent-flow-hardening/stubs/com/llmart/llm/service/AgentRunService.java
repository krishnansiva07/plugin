package com.llmart.llm.service;
public final class AgentRunService {
    public static final class AgentRun { public void checkCancelled() {} }
}
