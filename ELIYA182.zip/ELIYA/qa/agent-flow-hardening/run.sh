#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT
S="$ROOT/src/main/java/com/llmart/llm/service"
STUBS="$ROOT/qa/agent-flow-hardening/stubs"
javac --release 17 -proc:none -encoding UTF-8 -d "$TMP" \
  "$STUBS/org/springframework/stereotype/Service.java" \
  "$STUBS/com/llmart/llm/service/AgentRunService.java" \
  "$STUBS/com/llmart/llm/service/AgentConversationIntent.java" \
  "$STUBS/com/llmart/llm/service/AgentPlanRelevance.java" \
  "$S/AgentCancelledException.java" "$S/AgentPlanningTerms.java" \
  "$S/AgentPlanJsonEnvelope.java" "$S/AgentPlanRecovery.java" \
  "$S/AgentPlanSpecificity.java" "$S/MigrationIntent.java" "$S/AgentQuestionService.java" "$S/AgentQuestionAnswers.java" \
  "$S/AgentTestDiscovery.java" "$S/AgentRuntimeFailurePolicy.java" \
  "$ROOT/qa/agent-flow-hardening/AgentFlowHardeningSmoke.java"
java -cp "$TMP" com.llmart.llm.service.AgentFlowHardeningSmoke
