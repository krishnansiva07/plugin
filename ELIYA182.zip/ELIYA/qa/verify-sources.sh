#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
INVENTORY="$ROOT/qa/source-inventory.txt"
if [[ ! -f "$INVENTORY" ]]; then
  echo 'ERROR: source inventory missing' >&2; exit 2
fi
total=0; missing=0; invalid=0
while IFS= read -r entry || [[ -n "$entry" ]]; do
  [[ -z "$entry" || "$entry" == \#* ]] && continue
  total=$((total+1))
  if [[ ! -f "$ROOT/$entry" ]]; then
    echo "MISSING: $entry" >&2; missing=$((missing+1)); continue
  fi
  expected="${entry%/*}"; expected="${expected#src/main/java/}"; expected="${expected//\//.}"
  actual="$(sed -n 's/^[[:space:]]*package[[:space:]]\+\([a-zA-Z0-9_.]*\)[[:space:]]*;.*/\1/p' "$ROOT/$entry" | head -1)"
  if [[ "$expected" != "$actual" ]]; then
    echo "INVALID: $entry (expected $expected; found ${actual:-none})" >&2
    invalid=$((invalid+1))
  fi
done < "$INVENTORY"
count="$(find "$ROOT/src/main/java" -type f -name '*.java' | wc -l | tr -d ' ')"
echo "Source preflight: expected=$total; present=$count; missing=$missing; invalid=$invalid"
if (( total < 234 || missing > 0 || invalid > 0 )); then
  echo 'ERROR: Incomplete Java source tree; extract ZIP into a new empty directory.' >&2
  exit 1
fi
echo 'Source preflight PASSED.'
