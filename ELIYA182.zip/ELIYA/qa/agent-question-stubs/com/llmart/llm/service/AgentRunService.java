package com.llmart.llm.service;
public class AgentRunService { public static class AgentRun { public void checkCancelled() { } } }
