package com.llmart.llm.service;
import java.util.*;
import java.util.concurrent.*;
public class AgentQuestionSmoke {
 public static void main(String[] args) throws Exception {
  AgentQuestionService q=new AgentQuestionService();q.enable("r");
  ExecutorService pool=Executors.newSingleThreadExecutor();
  try {
   Future<String> f=pool.submit(()->q.ask("r","Which browser?", List.of("Chrome","Firefox"),new AgentRunService.AgentRun()));
   Map<String,Object> pending=Map.of();
   for(int i=0;i<200;i++) {pending=q.pending("r");if(!pending.isEmpty())break;Thread.sleep(5);}
   if(pending.isEmpty() || !pending.get("choices").toString().contains("Cancel")) throw new AssertionError("missing choice");
   if(!q.answer("r", (String)pending.get("id"),"Chrome", ""))throw new AssertionError("answer rejected");
   if(!f.get(3,TimeUnit.SECONDS).contains("Chrome"))throw new AssertionError("not resumed");
   Future<String> g=pool.submit(()->q.ask("r","Need a detail",List.of(),new AgentRunService.AgentRun()));
   Map<String,Object> more=Map.of();
   for(int i=0;i<200;i++){more=q.pending("r");if(!more.isEmpty())break;Thread.sleep(5);}
   if(more.isEmpty() || more.get("choices").toString().contains("OK"))throw new AssertionError("generic answer fallback");
   q.cancel("r");g.get(3,TimeUnit.SECONDS);
   System.out.println("AgentQuestionService smoke: PASS (pending, choices, answer, resume, fallback, cancel)");
  } finally {pool.shutdownNow();q.disable("r");}
 }
}
