package com.fasterxml.jackson.databind;

import java.util.Collections;
import java.util.Iterator;
import java.util.Map;

/** QA-only, minimal Jackson API simulator. NEVER packaged with the application. */
public class JsonNode implements Iterable<JsonNode> {
    protected Object value;
    public JsonNode(Object value) { this.value = value; }
    public JsonNode path(String key) { return value instanceof Map<?, ?> m && m.get(key) instanceof JsonNode n ? n : new JsonNode(null); }
    public boolean has(String key) { return value instanceof Map<?, ?> m && m.containsKey(key); }
    public boolean isArray() { return value instanceof java.util.List<?>; }
    public boolean isObject() { return value instanceof Map<?, ?>; }
    public boolean isTextual() { return value instanceof String; }
    public String asText() { return asText(""); }
    public String asText(String defaultValue) { return value == null ? defaultValue : value.toString(); }
    public boolean asBoolean() { return asBoolean(false); }
    public boolean asBoolean(boolean defaultValue) { return value == null ? defaultValue : Boolean.parseBoolean(value.toString()); }
    public int asInt() { return asInt(0); }
    public int asInt(int fallback) { try { return Integer.parseInt(asText()); } catch (Exception e) { return fallback; } }
    public long asLong() { try { return Long.parseLong(asText()); } catch (Exception e) { return 0; } }
    public int size() { return value instanceof Map<?, ?> m ? m.size() : value instanceof java.util.List<?> a ? a.size() : 0; }
    public boolean isEmpty() { return size() == 0; }
    @SuppressWarnings("unchecked")
    public Iterator<Map.Entry<String, JsonNode>> fields() {
        return value instanceof Map<?, ?> ? ((Map<String, JsonNode>)value).entrySet().iterator() : Collections.emptyIterator();
    }
    @SuppressWarnings("unchecked")
    public Iterator<JsonNode> iterator() {
        return value instanceof java.util.List<?> ? ((java.util.List<JsonNode>)value).iterator() : Collections.emptyIterator();
    }
    public Object raw() { return value; }
}
