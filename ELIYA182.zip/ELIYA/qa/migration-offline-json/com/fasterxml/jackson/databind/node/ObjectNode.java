package com.fasterxml.jackson.databind.node;
import com.fasterxml.jackson.databind.JsonNode;
import java.util.LinkedHashMap;
import java.util.Map;

/** QA-only stub, not product code. */
public final class ObjectNode extends JsonNode {
    @SuppressWarnings("unchecked") private Map<String, JsonNode> entries() { return (Map<String, JsonNode>)value; }
    public ObjectNode() { super(new LinkedHashMap<String, JsonNode>()); }
    public ObjectNode put(String key, String value) { entries().put(key, new JsonNode(value)); return this; }
    public ObjectNode put(String key, boolean value) { entries().put(key, new JsonNode(value)); return this; }
    public ObjectNode put(String key, int value) { entries().put(key, new JsonNode(value)); return this; }
    public ObjectNode put(String key, long value) { entries().put(key, new JsonNode(value)); return this; }
    public ArrayNode putArray(String key) { ArrayNode arr = new ArrayNode(); entries().put(key, arr); return arr; }
    public ObjectNode putObject(String key) { ObjectNode obj = new ObjectNode(); entries().put(key, obj); return obj; }
    public void set(String key, JsonNode node) { entries().put(key,node); }
}
