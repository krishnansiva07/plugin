package com.fasterxml.jackson.databind;

import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import java.io.IOException;
import java.util.Map;

/** QA-only JSON parser/serializer to run isolated Java migration tests offline; NOT product dependency. */
public final class ObjectMapper {
    public ObjectNode createObjectNode() { return new ObjectNode(); }
    public ObjectMapper writerWithDefaultPrettyPrinter() { return this; }
    public String writeValueAsString(Object node) { return serialize(node instanceof JsonNode j ? j.raw() : node); }
    @SuppressWarnings("unchecked")
    private String serialize(Object v) {
        if (v == null) return "null";
        if (v instanceof JsonNode j) return serialize(j.raw());
        if (v instanceof Map<?, ?> map) {
            StringBuilder out = new StringBuilder("{");
            for (var entry : map.entrySet()) {
                if (out.length() > 1) out.append(',');
                out.append(serialize(entry.getKey().toString())).append(':').append(serialize(entry.getValue()));
            }
            return out.append('}').toString();
        }
        if (v instanceof Iterable<?> arr) {
            StringBuilder out = new StringBuilder("[");
            for (Object item : arr) { if (out.length() > 1) out.append(','); out.append(serialize(item)); }
            return out.append(']').toString();
        }
        if (v instanceof Boolean || v instanceof Number) return v.toString();
        StringBuilder out = new StringBuilder("\"");
        for (int i = 0; i < v.toString().length(); i++) {
            char c = v.toString().charAt(i);
            switch (c) {
                case '"' -> out.append("\\\"");
                case '\\' -> out.append("\\\\");
                case '\n' -> out.append("\\n");
                case '\r' -> out.append("\\r");
                case '\t' -> out.append("\\t");
                default -> { if (c < 32) out.append(String.format("\\u%04x",(int)c)); else out.append(c); }
            }
        }
        return out.append('"').toString();
    }
    public JsonNode readTree(String text) throws IOException { return new Parser(text).parse(); }
    private static final class Parser {
        final String input;
        int i;
        Parser(String input) { this.input = input; }
        void ws() { while (i < input.length() && Character.isWhitespace(input.charAt(i))) i++; }
        JsonNode parse() throws IOException { JsonNode n = value(); ws(); if (i != input.length()) throw new IOException("Trailing JSON data"); return n; }
        JsonNode value() throws IOException {
            ws(); if (i >= input.length()) throw new IOException("Truncated JSON");
            char c = input.charAt(i);
            if (c == '{') {
                i++; ObjectNode obj = new ObjectNode(); ws(); if (take('}')) return obj;
                do { ws(); if (i>=input.length()||input.charAt(i)!='"') throw new IOException("Expected JSON key");
                    String key = string(); ws(); need(':'); obj.set(key,value()); ws(); if (take('}')) return obj;
                } while (take(',')); throw new IOException("Expected object delimiter");
            }
            if (c == '[') {
                i++; ArrayNode arr = new ArrayNode(); ws(); if (take(']')) return arr;
                do { JsonNode v = value();
                    // Replace with raw JsonNode insert: the parser stores every primitive as a JsonNode.
                    rawAdd(arr, v); ws(); if (take(']')) return arr;
                } while (take(',')); throw new IOException("Expected array delimiter");
            }
            if (c=='"') return new JsonNode(string());
            if (input.startsWith("true",i)) { i+=4; return new JsonNode(true); }
            if (input.startsWith("false",i)) { i+=5; return new JsonNode(false); }
            if (input.startsWith("null",i)) { i+=4; return new JsonNode(null); }
            int start=i; while(i<input.length() && "0123456789-.eE+".indexOf(input.charAt(i))>=0) i++;
            if (start==i) throw new IOException("Invalid JSON literal");
            String raw=input.substring(start,i);
            try { return new JsonNode((raw.contains(".")||raw.contains("e")||raw.contains("E")) ? (Object)Double.valueOf(raw) : Long.valueOf(raw)); }
            catch(NumberFormatException bad) { throw new IOException("Invalid JSON number", bad); }
        }
        @SuppressWarnings("unchecked") void rawAdd(ArrayNode a, JsonNode v) { ((java.util.List<JsonNode>)a.raw()).add(v); }
        boolean take(char c) { ws(); if(i<input.length() && input.charAt(i)==c){i++; return true;} return false; }
        void need(char c) throws IOException { if(!take(c)) throw new IOException("Expected '"+c+"' at "+i); }
        String string() throws IOException {
            need('"'); StringBuilder out=new StringBuilder();
            while(i<input.length()) {
                char c=input.charAt(i++); if(c=='"') return out.toString();
                if(c=='\\') { if(i>=input.length()) throw new IOException("Truncated JSON escape");
                    c=input.charAt(i++);
                    switch(c){case '"'->out.append('"'); case '\\'->out.append('\\'); case '/'->out.append('/');
                        case 'b'->out.append('\b'); case 'f'->out.append('\f'); case 'n'->out.append('\n');
                        case 'r'->out.append('\r'); case 't'->out.append('\t');
                        case 'u'->{if(i+4>input.length())throw new IOException("Truncated unicode");
                            try{out.append((char)Integer.parseInt(input.substring(i,i+4),16)); i+=4;}
                            catch(NumberFormatException bad){throw new IOException("Invalid unicode escape",bad);}}
                        default->throw new IOException("Invalid JSON escape");}
                } else out.append(c);
            }
            throw new IOException("Unterminated JSON string");
        }
    }
}
