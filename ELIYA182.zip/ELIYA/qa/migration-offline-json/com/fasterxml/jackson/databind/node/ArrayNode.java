package com.fasterxml.jackson.databind.node;
import com.fasterxml.jackson.databind.JsonNode;
import java.util.ArrayList;
import java.util.List;

/** QA-only stub, not product code. */
public final class ArrayNode extends JsonNode {
    @SuppressWarnings("unchecked") private List<JsonNode> entries() { return (List<JsonNode>)value; }
    public ArrayNode() { super(new ArrayList<JsonNode>()); }
    public ArrayNode add(String text) { entries().add(new JsonNode(text)); return this; }
    public ArrayNode add(int n) { entries().add(new JsonNode(n)); return this; }
    public ArrayNode add(boolean n) { entries().add(new JsonNode(n)); return this; }
    public ObjectNode addObject() { ObjectNode obj = new ObjectNode(); entries().add(obj); return obj; }
}
