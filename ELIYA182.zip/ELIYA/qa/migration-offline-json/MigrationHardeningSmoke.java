package com.llmart.llm.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.charset.StandardCharsets;
import java.nio.file.StandardOpenOption;
import java.io.RandomAccessFile;
import java.util.List;
import java.util.Locale;

/** Failure injection and a 125k-file migration inventory on real filesystem paths.
 * The test-command runner is intentionally simulated and is NOT a provider/Jackson E2E certification. */
public final class MigrationHardeningSmoke {
    static final ObjectMapper JSON = new ObjectMapper();
    static int checks;
    static void ok(boolean assertion, String reason) { checks++; if (!assertion) throw new AssertionError("FAILED " + reason); }
    static JsonNode args(String text) throws Exception { return JSON.readTree(text); }
    static MigrationEngine engine(String output) {
        return new MigrationEngine((root, cmd, timeout, cancel) -> new MigrationEngine.CommandResult(0, output, false));
    }
    static JsonNode initArgs() throws Exception {
        return args("{\"source\":\"LegacyClient\",\"target\":\"NewClient\",\"residuePatterns\":[\"LegacyClient\"],\"verifyCommand\":\"mvn test\"}");
    }
    static String id() { return MigrationEngine.slug("LegacyClient-to-NewClient"); }
    static Path ledger(Path root) { return root.resolve("migration").resolve(id()); }
    public static void main(String[] a) throws Exception {
        finalEvidence();
        zeroTestFailures();
        scopeAndUnknownFiles();
        baselineWithKnownFailures();
        comprehensive125k();
        System.out.println("MIGRATION HARDENING PASS: " + checks + " assertions including 125,001 discovered files and >5,000 work items");
    }
    static void finalEvidence() throws Exception {
        Path root = Files.createTempDirectory("eliya-harden-final");
        Path target = root.resolve("src/MyClient.java");
        Files.createDirectories(target.getParent());
        Files.writeString(target, "class MyClient { LegacyClient client; }\n");
        MigrationEngine engine = engine("Tests run: 2, Failures: 0");
        ok(!engine.init(root, initArgs(), "Migrate LegacyClient to NewClient").failed(), "init");
        ok(engine.completionProblem(root).unfinished(), "pending migration blocked from completion");
        ok(!engine.baseline(root, args("{}"), () -> false).failed(), "valid test baseline");
        Files.writeString(target, "class MyClient { NewClient client; }\n");
        ok(!engine.update(root, args("{\"items\":[\"src/MyClient.java\"],\"status\":\"migrated\"}")).failed(), "update");
        ok(!engine.verify(root, args("{}"), () -> false).failed(), "batch verify");
        ok(engine.completionProblem(root).unfinished(), "batch success not enough: final test required");
        ok(!engine.verify(root, args("{\"final\":true}"), () -> false).failed(), "full verification");
        ok(engine.completionProblem(root) == null, "full fingerprint and tests sealed");
        Files.writeString(target, "class MyClient { NewClient changed; }\n");
        MigrationEngine.Problem stale = engine.completionProblem(root);
        ok(stale != null && stale.text().contains("changed after final"), "changed content invalidates executed tests");
        ok(!engine.verify(root, args("{\"final\":true}"), () -> false).failed(), "rerun after edit");
        ok(engine.completionProblem(root) == null, "fresh evidence restores complete state");
        Files.writeString(root.resolve("new.java"), "class NewFile { LegacyClient old; }\n");
        MigrationEngine.Problem discovered = engine.completionProblem(root);
        ok(discovered != null && discovered.text().contains("Old-API residue"), "new untracked legacy API detected");
        Files.delete(root.resolve("new.java"));
        ok(!engine.verify(root, args("{\"final\":true}"), () -> false).failed(), "verify after removing stale source");
        ok(engine.completionProblem(root) == null, "finished after recheck");
        Files.writeString(ledger(root).resolve("items.csv"), "nonsense\n", StandardOpenOption.APPEND);
        MigrationEngine.Problem damaged = engine.completionProblem(root);
        ok(damaged != null && damaged.text().toLowerCase(Locale.ROOT).contains("checksum"), "corrupt ledger explicitly prevents completion");
        Files.delete(ledger(root).resolve("items.csv"));
        ok(engine.completionProblem(root) != null, "missing ledger prevents completion");
    }
    static void zeroTestFailures() throws Exception {
        Path root = Files.createTempDirectory("eliya-harden-zero-tests");
        Files.writeString(root.resolve("x.java"), "LegacyClient value;\n");
        MigrationEngine engine = engine("Tests run: 0, Failures: 0");
        ok(!engine.init(root, initArgs(), "Migrate LegacyClient to NewClient").failed(), "zero tests inventory okay");
        ok(engine.baseline(root, args("{}"), () -> false).failed(), "zero executed baseline tests rejected");
        Files.writeString(root.resolve("x.java"), "NewClient value;\n");
        engine.update(root, args("{\"items\":[\"x.java\"],\"status\":\"migrated\"}"));
        ok(engine.verify(root, args("{}"), () -> false).failed(), "zero executed verify rejected");
        ok(engine.completionProblem(root) != null, "zero tests never mark complete");
        MigrationEngine noTests = engine("");
        Path noTestRoot = Files.createTempDirectory("eliya-no-test-cmd");
        Files.writeString(noTestRoot.resolve("x.java"), "LegacyClient value;");
        ok(!noTests.init(noTestRoot, args("{\"source\":\"LegacyClient\",\"target\":\"NewClient\",\"residuePatterns\":[\"LegacyClient\"]}"), "Migrate LegacyClient to NewClient").failed(), "inventory possible without test runner");
        ok(noTests.baseline(noTestRoot, args("{}"), () -> false).failed(), "no test command does not count as baseline");
    }
    static void scopeAndUnknownFiles() throws Exception {
        Path root = Files.createTempDirectory("eliya-harden-scope");
        Files.writeString(root.resolve("safe.java"), "LegacyClient old;");
        MigrationEngine engine = engine("Tests run: 2, Failures: 0");
        ok(engine.init(root, args("{\"source\":\"LegacyClient\",\"target\":\"NewClient\",\"scope\":[\"missing-module\"],\"residuePatterns\":[\"LegacyClient\"]}"), "Migrate missing module").failed(),
                "invalid requested scope rejects whole-workspace fallback");
        Path bad = root.resolve("huge.java");
        try(RandomAccessFile file = new RandomAccessFile(bad.toFile(), "rw")){ file.setLength(33L * 1024 * 1024); }
        var result = engine.init(root, initArgs(), "Migrate LegacyClient to NewClient");
        ok(result.failed() && result.text().contains("SCAN INCOMPLETE"), "oversized source is unknown, not zero residue");
        ok(!JSON.readTree(Files.readString(ledger(root).resolve("inventory.json"))).path("coverageComplete").asBoolean(), "manifest marks incomplete coverage");
        Files.delete(bad);
        ok(!engine.init(root, args("{\"source\":\"LegacyClient\",\"target\":\"NewClient\",\"residuePatterns\":[\"LegacyClient\"],\"verifyCommand\":\"mvn test\",\"restart\":true}"), "Migrate LegacyClient to NewClient").failed(),
                "explicit rescan restores safe inventory");
    }
    static void baselineWithKnownFailures() throws Exception {
        Path root = Files.createTempDirectory("eliya-harden-baseline");
        Files.writeString(root.resolve("x.java"), "LegacyClient old;");
        String prior = "Tests run: 2, Failures: 1\n[ERROR] com.example.PaymentTest.expectedCase";
        MigrationEngine preexistingFailure = new MigrationEngine((dir, cmd, timeout, cancel) ->
                new MigrationEngine.CommandResult(1, prior, false));
        ok(!preexistingFailure.init(root, initArgs(), "Migrate LegacyClient to NewClient").failed(), "failed baseline fixture inventory");
        ok(!preexistingFailure.baseline(root, args("{}"), () -> false).failed(),
                "existing named test failure is captured as baseline, not confused with test skip");
        Files.writeString(root.resolve("x.java"), "NewClient value;");
        preexistingFailure.update(root, args("{\"items\":[\"x.java\"],\"status\":\"migrated\"}"));
        ok(!preexistingFailure.verify(root, args("{\"final\":true}"), () -> false).failed(),
                "same pre-existing named test failure does not become a new regression");
        ok(preexistingFailure.completionProblem(root) == null, "no new failure plus complete scan passes migration contract");
        Path timeoutRoot = Files.createTempDirectory("eliya-baseline-timeout");
        Files.writeString(timeoutRoot.resolve("x.java"), "LegacyClient old;");
        MigrationEngine timedOut = new MigrationEngine((dir, cmd, timeout, cancel) ->
                new MigrationEngine.CommandResult(0, "Tests run: 2, Failures: 0", true));
        timedOut.init(timeoutRoot, initArgs(), "Migrate LegacyClient to NewClient");
        ok(timedOut.baseline(timeoutRoot, args("{}"), () -> false).failed(), "timed-out baseline is never accepted");
    }

    static void comprehensive125k() throws Exception {
        Path root = Files.createTempDirectory("eliya-harden-125k");
        int files = 125_001;
        int matches = 6_003;
        for (int i = 0; i < files; i++) {
            if (i % 500 == 0) Files.createDirectories(root.resolve(String.format("part%03d", i / 500)));
            Path file = root.resolve(String.format("part%03d", i / 500)).resolve("source" + i + ".java");
            Files.writeString(file, "class Example { " + (i < matches || i == files - 1 ? "LegacyClient old;" : "int good;") + " }\n", StandardCharsets.UTF_8);
        }
        MigrationEngine engine = engine("Tests run: 1, Failures: 0");
        var start = System.nanoTime();
        MigrationEngine.Outcome outcome = engine.init(root, initArgs(), "Migrate LegacyClient to NewClient");
        long elapsed = (System.nanoTime()-start)/1_000_000;
        ok(!outcome.failed(), "125k-file discovery successful: " + outcome.text());
        JsonNode inventory = JSON.readTree(Files.readString(ledger(root).resolve("inventory.json")));
        ok(inventory.path("visited").asLong() == files, "all 125001 eligible visited " + inventory.path("visited").asLong());
        ok(inventory.path("coverageComplete").asBoolean(), "coverageComplete true only when complete");
        List<MigrationEngine.Item> items = MigrationEngine.readItems(ledger(root));
        ok(items.size() == matches + 1, "all >5k residue files tracked, found " + items.size());
        ok(items.stream().anyMatch(i -> i.path.endsWith("source125000.java")), "final file found, not truncated by 60k visited cap");
        ok(engine.completionProblem(root).unfinished(), "125k incomplete migration not falsely finished");
        System.out.println("MIGRATION INVENTORY: " + files + " files in " + elapsed + " ms, " + items.size() + " ledger items");
    }
}
