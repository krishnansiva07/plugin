#!/usr/bin/env bash
# Isolated migration-engine regression with a QA-only JSON adapter (no Jackson or Maven required).
# This cannot replace the separate mandatory production/Jackson/Maven acceptance suite.
set -euo pipefail
BASE="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
S="$BASE/src/main/java/com/llmart/llm/service"
HERE="$BASE/qa/migration-offline-json"
OUT="$(mktemp -d)"; trap 'rm -rf "$OUT"' EXIT
javac --release 17 -proc:none -encoding UTF-8 -d "$OUT" \
  $(find "$HERE/com" -name '*.java') \
  "$S/AgentVerificationPolicy.java" "$S/MigrationIntent.java" "$S/MigrationPacks.java" "$S/MigrationEngine.java" "$S/AgentTestWorkflow.java" "$S/AgentCancelledException.java" \
  "$S/AgentPlanSpecificity.java" "$S/AgentPlanningTerms.java" "$S/AgentConversationIntent.java" "$S/AgentPlanRelevance.java" \
  "$S/AgentReadOnlySearchPolicy.java" "$S/AgentRequirementCoverage.java" "$S/AgentToolPalettePolicy.java" "$S/AgentPlanRecovery.java" "$S/AgentPlanJsonEnvelope.java" \
  "$BASE/qa/eliya179-migration-engine/MigrationE2E.java" \
  "$HERE/MigrationHardeningSmoke.java"
java -cp "$OUT" com.llmart.llm.service.MigrationE2E "$BASE/qa/eliya179-migration-engine/samples"
java -Xmx1200m -cp "$OUT" com.llmart.llm.service.MigrationHardeningSmoke
