#!/usr/bin/env bash
# ELIYA156: runtime failure classification and the enforced test workflow. JDK only.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT
S="$ROOT/src/main/java/com/llmart/llm/service"
javac --release 17 -proc:none -encoding UTF-8 -d "$TMP" "$S/AgentRuntimeFailurePolicy.java" "$S/AgentCancelledException.java" "$S/AgentTestWorkflow.java" \
  "$ROOT/qa/eliya156-runtime/RuntimeSmoke.java"
java -cp "$TMP" com.llmart.llm.service.RuntimeSmoke
