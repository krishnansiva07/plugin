package com.llmart.llm.service;

import java.net.ConnectException;
import java.net.SocketTimeoutException;
import java.nio.file.AccessDeniedException;
import java.util.List;

/** ELIYA156: runtime failure classification and the enforced test workflow. JDK only. */
public class RuntimeSmoke {
    static int passed;
    static void check(boolean c, String m) { if (!c) throw new AssertionError("FAIL: " + m); passed++; }

    public static void main(String[] args) {
        failures();
        testWorkflow();
        System.out.println("PASS: " + passed + " ELIYA156 runtime-failure and test-workflow assertions");
    }

    static void failures() {
        var transient1 = AgentRuntimeFailurePolicy.decide(new SocketTimeoutException("Read timed out"), 1);
        check(transient1.action() == AgentRuntimeFailurePolicy.Action.RETRY && transient1.backoffMs() == 2000, "timeout retried with backoff");
        check(AgentRuntimeFailurePolicy.decide(new ConnectException("refused"), 3).backoffMs() == 8000, "exponential backoff");
        check(AgentRuntimeFailurePolicy.decide(new ConnectException("refused"), 4).action() == AgentRuntimeFailurePolicy.Action.ASK_USER,
                "after 3 retries the user decides");
        check(AgentRuntimeFailurePolicy.decide(new RuntimeException("HTTP 429 rate limit"), 1).action() == AgentRuntimeFailurePolicy.Action.RETRY,
                "rate limit is transient");
        var overflow = AgentRuntimeFailurePolicy.decide(new IllegalArgumentException("This model's maximum context length is 128000 tokens"), 1);
        check(overflow.action() == AgentRuntimeFailurePolicy.Action.COMPACT_AND_RETRY, "context overflow compacts");
        check(AgentRuntimeFailurePolicy.decide(new IllegalArgumentException("maximum context length exceeded"), 3).action()
                == AgentRuntimeFailurePolicy.Action.ASK_USER, "overflow after compaction asks");
        var creds = AgentRuntimeFailurePolicy.decide(new RuntimeException("401 Unauthorized: invalid api key"), 1);
        check(creds.action() == AgentRuntimeFailurePolicy.Action.ASK_USER && creds.choices().contains(creds.retryChoice()), "credentials ask with retry option");
        var gate = AgentRuntimeFailurePolicy.decide(new IllegalStateException("Sequential plan gate: only active step 2 can be updated"), 1);
        check(gate.action() == AgentRuntimeFailurePolicy.Action.STEER_AND_CONTINUE, "plan gate error fed back to executor");
        var access = AgentRuntimeFailurePolicy.decide(new AccessDeniedException("C:\\\\proj\\\\pom.xml"), 1);
        check(access.action() == AgentRuntimeFailurePolicy.Action.ASK_USER && access.question().contains("could not be accessed"), "workspace access asks");
        var safety = AgentRuntimeFailurePolicy.decide(new SecurityException("Path escapes project: ../../etc"), 1);
        check(safety.action() == AgentRuntimeFailurePolicy.Action.STOP, "safety violations stop");
        var npe1 = AgentRuntimeFailurePolicy.decide(new NullPointerException("x is null"), 1);
        var npe2 = AgentRuntimeFailurePolicy.decide(new NullPointerException("x is null"), 2);
        check(npe1.action() == AgentRuntimeFailurePolicy.Action.STEER_AND_CONTINUE && npe2.action() == AgentRuntimeFailurePolicy.Action.ASK_USER,
                "unexpected errors: one safe attempt, then a user decision");
        check(AgentRuntimeFailurePolicy.fingerprint(new RuntimeException("step 12 failed")).equals(
                AgentRuntimeFailurePolicy.fingerprint(new RuntimeException("step 13 failed"))), "fingerprint ignores numbers");
        check(AgentRuntimeFailurePolicy.decide(new RuntimeException("wrapper", new SocketTimeoutException("t")), 1).kind()
                == AgentRuntimeFailurePolicy.Kind.TRANSIENT, "cause chain classified");
        check(AgentRuntimeFailurePolicy.status(new ConnectException("x")).equals("blocked") &&
                AgentRuntimeFailurePolicy.status(new NullPointerException()).equals("failed"), "terminal status by kind");
        check(AgentRuntimeFailurePolicy.terminalOutcome(new RuntimeException("401")).contains("API key"), "actionable terminal outcome");
    }

    static void testWorkflow() {
        check(AgentTestWorkflow.forObjective("Explain the order service") == null, "not applicable to non-test requests");
        check(AgentTestWorkflow.forObjective("Run the integration tests for checkout") != null, "run tests applies");
        check(AgentTestWorkflow.forObjective("Fix the failing OrderServiceTest") != null, "fix failing tests applies");
        check(AgentTestWorkflow.forObjective("The tests are failing after the upgrade, please sort it out") != null, "tests are failing applies");

        AgentTestWorkflow wf = AgentTestWorkflow.forObjective("Fix the failing tests in the order module");
        check(AgentTestWorkflow.isRunner("bash", "./mvnw -q test") && AgentTestWorkflow.isRunner("test", "") &&
                AgentTestWorkflow.isRunner("bash", "npx playwright test") && !AgentTestWorkflow.isRunner("bash", "ls -la"), "runner detection");
        check(wf.completionProblem(0).contains("No test runner"), "cannot finish without running tests");
        check(wf.blockReason("bash", "mvn package -DskipTests", null) != null, "-DskipTests blocked");
        check(wf.blockReason("bash", "gradle build -x test", null) != null, "gradle -x test blocked");
        check(wf.blockReason("edit", "", "{\"newText\":\"@Disabled\\n@Test void retries()\"}") != null, "@Disabled edit blocked");
        check(wf.blockReason("write", "", "{\"content\":\"test.skip('checkout', ...)\"}") != null, ".skip blocked");
        check(wf.blockReason("bash", "mvn -q test", null) == null, "normal test run allowed");
        check(AgentTestWorkflow.forObjective("Run the test suite but skip the flaky payment tests").blockReason("bash", "mvn test -DskipTests", null) == null,
                "user-requested skipping allowed");

        String surefire = "[INFO] Running com.shop.OrderServiceTest\n" +
                "[ERROR] Tests run: 5, Failures: 2, Errors: 0, Skipped: 0\n" +
                "[ERROR] Failures: \n" +
                "[ERROR]   OrderServiceTest.retriesThreeTimes:42 expected: <3> but was: <1>\n" +
                "[ERROR]   OrderServiceTest.backoffGrows:57 AssertionError\n" +
                "\tat com.shop.OrderServiceTest.retriesThreeTimes(OrderServiceTest.java:42)\n";
        String diagnosis = wf.afterRun("./mvnw -q test", surefire, true, 0);
        check(diagnosis.contains("OrderServiceTest#retriesThreeTimes") && diagnosis.contains("OrderServiceTest#backoffGrows"), "failing tests extracted: " + diagnosis);
        check(diagnosis.contains("mvn -q test -Dtest=OrderServiceTest#retriesThreeTimes,OrderServiceTest#backoffGrows"), "targeted maven command: " + diagnosis);
        check(diagnosis.contains("expected: <3> but was: <1>"), "first errors included");
        check(diagnosis.contains("Do not skip, disable or delete tests"), "no-shortcut rule stated");
        check(wf.completionProblem(1).contains("latest test run failed"), "cannot finish after failure");
        wf.afterRun("./mvnw -q test -Dtest=OrderServiceTest", "[INFO] Tests run: 5, Failures: 0, Errors: 0, Skipped: 0\nBUILD SUCCESS", false, 2);
        check(wf.completionProblem(2) == null, "satisfied after passing run on current revision");
        check(wf.completionProblem(3).contains("Files changed after the last passing"), "re-verification required after new edits");
        check(wf.allowGateReentry() && wf.allowGateReentry() && wf.allowGateReentry() && !wf.allowGateReentry(), "gate re-entry bounded to 3");

        check(AgentTestWorkflow.failingTests("FAILED tests/test_cart.py::test_total - assert 3 == 4").contains("tests/test_cart.py::test_total"), "pytest parsed");
        List<String> pw = AgentTestWorkflow.failingTests("  ✘  1 [chromium] › tests/checkout.spec.ts:12:5 › applies coupon (2.1s)");
        check(pw.size() == 1 && pw.get(0).startsWith("tests/checkout.spec.ts"), "playwright parsed: " + pw);
        check(AgentTestWorkflow.targetedCommand(AgentTestWorkflow.Runner.PLAYWRIGHT, pw).equals("npx playwright test tests/checkout.spec.ts"), "playwright targeted");
        check(AgentTestWorkflow.failingTests("FAILED: placeOrder\n").contains("placeOrder"), "testng parsed");
        check(AgentTestWorkflow.failingTests("OrderServiceTest > retries() FAILED").contains("OrderServiceTest#retries"), "gradle parsed");
    }
}
