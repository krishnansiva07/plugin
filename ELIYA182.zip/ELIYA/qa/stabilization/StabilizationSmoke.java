package com.llmart.llm.service;
import java.nio.file.*;
import java.io.*;
import java.util.*;
public class StabilizationSmoke {
  static void verify(boolean value,String problem) { if(!value) throw new AssertionError(problem); }
  public static void main(String[] args) throws Exception {
    System.setProperty("app.data-dir",args[0]);
    Path home=Path.of(args[0]);
    Path root=home.resolve("synthetic-workspace");
    Files.createDirectories(root);
    int count=12_050;
    long create=System.nanoTime();
    for(int i=0;i<count;i++) {
      Path folder=root.resolve("module"+(i/100));
      if(i%100==0) Files.createDirectories(folder);
      Files.writeString(folder.resolve("source"+i+".ts"),
        "export const symbol"+i+" = 'module"+(i/100)+"';\n");
    }
    Path target=root.resolve("module120/target-auth.ts");
    Files.writeString(target,"export class SpecialAuthenticationGateway {}\n");
    WorkspaceRetrievalIndexService service=new WorkspaceRetrievalIndexService(new OpenAiCompatibleClient());
    long index=System.nanoTime();
    var stats=service.warmRoot("synthetic",root);
    long indexMs=(System.nanoTime()-index)/1_000_000;
    verify(!stats.scanIncomplete(),"12k+ workspace truncated");
    verify(stats.indexedFiles()==count+1,"Indexed count "+stats.indexedFiles());
    long search=System.nanoTime();
    String result=service.retrieveCachedRoot("synthetic",root,"SpecialAuthenticationGateway",5,4000);
    long retrieveMs=(System.nanoTime()-search)/1_000_000;
    verify(result.contains("target-auth.ts"),"Cannot retrieve unique source at end of 12k+ workspace");
    verify(!WorkspaceRetrievalIndexService.localEmbeddingEndpoint("https://example.com"),"External endpoint erroneously allows no API key");
    verify(WorkspaceRetrievalIndexService.localEmbeddingEndpoint("http://localhost:11434/v1"),"Local embedding provider disabled");
    Files.delete(target);
    String deleted=service.retrieveCachedRoot("synthetic",root,"SpecialAuthenticationGateway",5,4000);
    verify(!deleted.contains("target-auth.ts"),"Deleted source still appears as live evidence");
    service.refreshPaths(AgentWorkspaceService.Workspace.forIndex("synthetic",root),List.of("module120/target-auth.ts"));
    verify(service.cachedStats("synthetic",root).indexedFiles()==count,"Incremental deletion did not update index");
    WorkspaceRetrievalIndexService restored=new WorkspaceRetrievalIndexService(new OpenAiCompatibleClient());
    var restat=restored.warmRoot("synthetic",root);
    verify(restat.indexedFiles()==count,"Index checkpoint reload/rescan inconsistent");
    // Verify durable run states, including previously misclassified queued/cancelling states.
    Path runStore=home.resolve("agent-history");
    AgentRunService runs=new AgentRunService(runStore);
    AgentRunService.AgentRun workingRun=runs.start("conversation-1","synthetic");
    workingRun.setObjective("Migrate all mapped Selenium tests and verify Playwright parity");
    workingRun.initializeWorkItems(List.of("Configure Playwright", "Migrate features", "Verify runtime"),10);
    workingRun.recordExecutionFailure("Failed verification: missing helper class");
    String runId=workingRun.id();
    verify(runs.activeExecutionRuns().size()==1,"New agent run not counted as active");
    AgentRunService reboot=new AgentRunService(runStore);
    verify("interrupted".equals(reboot.require(runId).status()),"Running state survived real object restart");
    verify(reboot.require(runId).originalTaskContract().contains("Selenium"), "Original task contract was lost");
    verify(reboot.require(runId).largeTaskMode(), "Durable large task mode was lost");
    verify(Integer.valueOf(3).equals(reboot.require(runId).workItemSummary().get("total")), "Durable work item ledger was lost");
    verify(reboot.activeExecutionRuns().isEmpty(),"Interrupted run erroneously active");
    AgentRunService.AgentRun resumed=reboot.start("conversation-1","synthetic",true);
    resumed.setObjective("Continue and complete");
    verify(resumed.originalTaskContract().contains("Selenium"),
      "Continuation overwrote the immutable original task contract");
    verify(Integer.valueOf(3).equals(resumed.workItemSummary().get("total")),"Interrupted work-item ledger not inherited");
    // The exact failed stage and its reason must survive durable run restoration;
    // a terminal status alone must never be interpreted as a Plan-stage failure.
    AgentRunService.AgentRun blockedRun=runs.start("conversation-blocked","synthetic");
    blockedRun.updateProgress(64,"verifying","Checking browser test execution");
    blockedRun.finish("blocked");
    verify("verifying".equals(blockedRun.snapshot().get("failureStage")),"Blocked run lost its actual failed stage");
    AgentRunService recoveredBlocked=new AgentRunService(runStore);
    verify("verifying".equals(recoveredBlocked.require(blockedRun.id()).snapshot().get("failureStage")),
      "Failed stage not durable after restart");
    String queuedId=runs.start("conversation-2","synthetic").id();
    Path properties=runStore.resolve(queuedId+".properties");
    Properties saved=new Properties();
    try(InputStream in=Files.newInputStream(properties)){saved.load(in);}
    saved.setProperty("status","queued");
    try(OutputStream out=Files.newOutputStream(properties)){saved.store(out,"simulate queued before restart");}
    AgentRunService queuedReboot=new AgentRunService(runStore);
    verify("interrupted".equals(queuedReboot.require(queuedId).status()),"Queued run survived restart as active");
    System.out.println("STABILIZATION PASS: indexed="+stats.indexedFiles()+" files; indexMs="+indexMs+
      "; retrievalMs="+retrieveMs+"; generatedMs="+((index-create)/1_000_000)+
      "; incremental deletion, persisted refresh, live-filesystem filtering, and running/queued restart recovery verified");
  }
}
