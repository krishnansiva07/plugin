#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT
javac --release 17 -encoding UTF-8 -d "$TMP" \
  "$ROOT/src/main/java/com/llmart/llm/service/AgentPlanJsonEnvelope.java" \
  "$ROOT/src/main/java/com/llmart/llm/service/AgentPlanRecovery.java" \
  "$ROOT/src/main/java/com/llmart/llm/service/AgentPlanningTerms.java" \
  "$ROOT/qa/eliya84-planner-resilience/PlannerResilienceSmoke.java"
java -cp "$TMP" com.llmart.llm.service.PlannerResilienceSmoke
python3 - "$ROOT/src/main/java/com/llmart/llm/service/AgentPlanningStage.java" "$ROOT/src/main/java/com/llmart/llm/service/AgentService.java" <<'PY'
import sys
s=open(sys.argv[1]).read()
service=open(sys.argv[2]).read()
# ELIYA154: one draft plus at most ONE corrective refinement call; then deterministic fallback.
start=s.index('    OpenAiCompatibleClient.AgentCompletion planningCall(')
end=s.index('    /** Read-only deterministic discovery',start)
segment=s[start:end]
assert segment.count('runtime.completeRoleText(')==1, 'planner calls must go through the single planningCall helper'
gen=segment[segment.index('    PlanProposal generatePlanProposal('):]
assert gen.count('planningCall(')==2, 'planner must make one draft and at most one refinement call'
assert 'AgentPlanningSettings.correctiveRoundEnabled()' in gen, 'refinement must be switchable'
assert 'AgentPlanRecovery.fromUserRequest' in segment, 'original-request fallback missing'
assert 'run.updateActivity("planning_recovery"' in segment, 'recovery progress missing'
assert 'Planner returned incomplete or malformed JSON' not in segment, 'old failure path retained'
assert 'run.recordModelUsage' in segment, 'token usage must be counted'
assert 'AgentPlanRecovery.refusal' in segment, 'provider safety refusal lost'
assert 'protectedSnapshots.begin(' in service, 'mutation safety lost'
print('PASS: planner draft + bounded refinement, fallback, telemetry and rollback invariants')
PY
