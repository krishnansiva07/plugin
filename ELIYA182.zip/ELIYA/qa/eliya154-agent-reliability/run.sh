#!/usr/bin/env bash
# ELIYA154: planning specificity, step classification, execution budgets, terminal config.
# Needs only a JDK 17+ and Jackson (from ~/.m2 after one Maven build, or JACKSON_CP).
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT
CP="${JACKSON_CP:-}"
if [[ -z "$CP" ]]; then
  CP="$(find "${HOME}/.m2/repository/com/fasterxml/jackson/core" -name 'jackson-*.jar' 2>/dev/null | grep -v sources | tr '\n' ':')"
fi
[[ -n "$CP" ]] || { echo "Jackson jars not found; set JACKSON_CP or run a Maven build once" >&2; exit 2; }
S="$ROOT/src/main/java/com/llmart/llm/service"
C="$ROOT/src/main/java/com/llmart/llm/cli"
javac --release 17 -proc:none -encoding UTF-8 -cp "$CP" -d "$TMP" \
  "$S/AgentPlanStepClassifier.java" "$S/AgentPlanningTerms.java" "$S/AgentPlanParser.java" \
  "$S/AgentPlanRecovery.java" "$S/AgentPlanSpecificity.java" "$S/MigrationIntent.java" "$S/AgentPlanJsonEnvelope.java" \
  "$S/AgentPlanStructure.java" "$S/AgentConversationIntent.java" "$S/AgentPlanRelevance.java" \
  "$S/AgentReadOnlySearchPolicy.java" "$S/AgentExecutionBudget.java" "$S/AgentPlanningSettings.java" \
  "$S/AgentPlanPrompt.java" "$S/McpKnownServers.java" "$S/AgentRequirementCoverage.java" "$C/EliyaCliModelConfig.java" "$C/TerminalConversationStore.java" \
  "$ROOT/qa/eliya154-agent-reliability/Eliya154Smoke.java"
java -cp "$TMP:$CP" com.llmart.llm.service.Eliya154Smoke
