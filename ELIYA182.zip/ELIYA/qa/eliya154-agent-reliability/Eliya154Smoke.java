package com.llmart.llm.service;

import com.llmart.llm.cli.EliyaCliModelConfig;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Map;

/**
 * ELIYA154 offline checks: plan specificity, step classification, planning evidence terms,
 * execution budgets and terminal model configuration. JDK + Jackson only; no Spring.
 */
public class Eliya154Smoke {
    private static int passed = 0;

    private static void check(boolean condition, String message) {
        if (!condition) throw new AssertionError("FAIL: " + message);
        passed++;
    }

    public static void main(String[] args) throws Exception {
        stepClassification();
        planningTerms();
        planJudging();
        recoveryFallback();
        budgets();
        terminalConfig();
        System.out.println("PASS: " + passed + " ELIYA154 agent-reliability assertions");
    }

    static void stepClassification() {
        // The old fallback step was misread as implementation because of "changes" in the excerpt.
        String fallbackStep = "Locate and read the files, classes and configuration involved in the request. Start by searching for: OrderService\n" +
                "Scope: fix the retry and update the timeout changes\nValidate: Name the exact files.";
        check(AgentPlanStepClassifier.isReadOnly(fallbackStep), "fallback investigation step must be read-only");
        check(!AgentPlanStepClassifier.isImplementation(fallbackStep), "read-only step must not get the exploration budget");
        // A user excerpt after ':' must not change the step's own classification.
        check(AgentPlanStepClassifier.isReadOnly("Inspect the payment module to understand: please fix and update the refund flow and add tests"),
                "quoted user excerpt must not turn an inspection into implementation");
        check(AgentPlanStepClassifier.isImplementation("Update `OrderService.retry()` to use exponential backoff"), "edit step is implementation");
        check(AgentPlanStepClassifier.isVerification("Run `mvn -q test -Dtest=OrderServiceTest` and confirm green"), "run test is verification");
        check(AgentPlanStepClassifier.isFinalVerification("Run the full test suite against the latest workspace revision"), "final verification detected");
        // Whole-word matching: 'latest' must not count as 'test', 'address' not as 'add'.
        check(!AgentPlanStepClassifier.isVerification("Review the latest address handling"), "substring 'test' in 'latest' is not verification");
        check(AgentPlanStepClassifier.isReadOnly("Review the latest address handling"), "review step stays read-only");
        check(!AgentPlanStepClassifier.isReadOnly("Fix the NPE in CartController"), "fix step is not read-only");
        check(AgentPlanStepClassifier.headline("2. Fix the bug\nValidate: tests pass").equals("fix the bug"), "headline strips numbering and validation");
    }

    static void planningTerms() {
        List<String> terms = AgentPlanningTerms.extract(
                "Eliya analyse why OrderService retry fails in src/main/java/com/shop/OrderService.java and check max_retries", 6);
        check(!terms.isEmpty() && !terms.contains("eliya") && !terms.contains("analyse"), "filler words are not search terms: " + terms);
        check(terms.contains("src/main/java/com/shop/OrderService.java"), "file path is a primary term: " + terms);
        check(terms.contains("OrderService"), "CamelCase identifier extracted: " + terms);
        check(terms.contains("max_retries"), "snake_case identifier extracted: " + terms);
        check(terms.indexOf("retry") < 0 || terms.indexOf("retry") > terms.indexOf("OrderService"), "anchors rank before words: " + terms);
        check(AgentPlanningTerms.extract("add caching to the product search endpoint", 4).contains("caching"), "domain word kept");
        check(!AgentPlanningTerms.extract("upgrade to version 3.5.16", 5).contains("3.5.16"), "version numbers are not anchors");
        check(AgentPlanningTerms.hasConcreteAnchor("Edit `pom.xml` dependencies"), "backtick/file anchor recognised");
        check(!AgentPlanningTerms.hasConcreteAnchor("Implement the requested changes"), "placeholder has no anchor");
    }

    static void planJudging() {
        String task = "Add exponential backoff to OrderService retry and cover it with a unit test";
        String evidence = "## File index\nsrc/main/java/com/shop/OrderService.java\nsrc/test/java/com/shop/OrderServiceTest.java";
        AgentPlanParser.Draft generic = AgentPlanParser.judge(
                "{\"plan\":[\"Analyse the requirements\",\"Implement the requested changes\",\"Test the changes\"]}", task, evidence);
        check(!generic.usable() && generic.hard(), "all-placeholder plan is rejected: " + generic.problem());

        AgentPlanParser.Draft vague = AgentPlanParser.judge(
                "{\"plan\":[\"Look at how retries currently work\",\"Change the retry logic to back off\",\"Add a unit test for the new behaviour\"]}",
                task, evidence);
        check(vague.usable() && !vague.problem().isBlank(), "anchor-free plan is usable but flagged for one refinement: " + vague.problem());

        AgentPlanParser.Draft specific = AgentPlanParser.judge(
                "```json\n{\"plan\":[\"Read `OrderService.retry()` in src/main/java/com/shop/OrderService.java\"," +
                "\"Replace the fixed sleep in OrderService.retry() with exponential backoff (base 200ms, max 5 tries)\"," +
                "\"Add OrderServiceTest#retryBacksOffExponentially and run `mvn -q test -Dtest=OrderServiceTest`\"]}\n```",
                task, evidence);
        check(specific.usable() && specific.problem().isBlank(), "specific plan accepted without refinement: " + specific.problem());
        check(specific.steps().size() == 3, "fenced JSON parsed into 3 steps");

        AgentPlanParser.Draft truncated = AgentPlanParser.judge("{\"plan\":[\"Read OrderService.java\",\"Upd", task, evidence);
        check(!truncated.usable() && truncated.hard(), "truncated JSON is never accepted as a partial plan");
        check(!AgentPlanParser.judge("", task, evidence).usable(), "empty response unusable");
        check(AgentPlanParser.judge("1. Read OrderService.java retry()\n2. Update OrderService.retry() backoff\n3. Run OrderServiceTest", task, evidence).usable(),
                "numbered plain-text plan accepted");
        // Read-only questions are never forced to name files.
        check(AgentPlanSpecificity.lacksConcreteAnchors("Explain how checkout works", List.of("Trace the checkout flow", "Summarise the findings"), evidence).isBlank(),
                "read-only questions are not refined for anchors");
    }

    static void recoveryFallback() {
        List<String> plan = AgentPlanRecovery.fromUserRequest("Fix the NPE in CartController when the cart is empty", false);
        check(plan.size() == 3, "fallback has locate, change, verify steps");
        check(AgentPlanStepClassifier.isReadOnly(plan.get(0)), "fallback step 1 is classified read-only");
        check(plan.get(0).contains("CartController"), "fallback seeds the search with request anchors");
        check(AgentPlanStepClassifier.isVerification(plan.get(2)), "fallback last step is verification");
        check(AgentPlanRecovery.fromUserRequest("Explain architecture", true).size() == 1, "read-only fallback unchanged");
        check(AgentPlanRecovery.fromUserRequest("Step 1: Analyze legacy. Step 2: Build framework. Step 3: Run tests", false).size() == 4,
                "explicit user phases still preserved");
    }

    static void budgets() {
        check(AgentExecutionBudget.explorationSteerTurns() == 8, "default steer turns");
        check(AgentExecutionBudget.explorationLimitTurns() == 16, "default exploration limit");
        System.setProperty("eliya.agent.explorationLimitTurns", "5");
        check(AgentExecutionBudget.explorationLimitTurns() >= AgentExecutionBudget.explorationSteerTurns() + 2, "limit stays above steer");
        System.clearProperty("eliya.agent.explorationLimitTurns");
        System.setProperty("eliya.agent.explorationSteerTurns", "nonsense");
        check(AgentExecutionBudget.explorationSteerTurns() == 8, "invalid property falls back");
        System.clearProperty("eliya.agent.explorationSteerTurns");
        check(AgentExecutionBudget.acceptVerifiedOutcomeOnMissingEvidence(), "verified-outcome acceptance on by default");
        check(AgentPlanningSettings.correctiveRoundEnabled(), "corrective planning round on by default");
        check(AgentPlanningSettings.analysisStageEnabled("complex", false) && !AgentPlanningSettings.analysisStageEnabled("focused", false),
                "analysis stage only for multi-concern work");
        check(AgentPlanPrompt.system(false).contains("FORBIDDEN placeholder"), "planner prompt forbids placeholders");
        check(AgentPlanPrompt.user("T", "E", "A", "normal", false).contains("ORIGINAL USER REQUEST (highest priority)"), "user request stays first");
    }

    static void terminalConfig() throws Exception {
        Path dir = Files.createTempDirectory("eliya154");
        Path file = dir.resolve("config.properties");
        EliyaCliModelConfig.write(file, Map.of("base.url", "http://localhost:11434/v1", "model", "qwen2.5-coder",
                "api.key", "file-key", "max.tokens", "4096", "setting.agentShellPermission", "ask"));
        EliyaCliModelConfig.Resolved fromFile = EliyaCliModelConfig.load(Map.of(), file);
        check(fromFile.complete(), "config file alone is enough for terminal use");
        check(Integer.valueOf(4096).equals(fromFile.settings().get("maxTokens")), "numeric settings parsed");
        check("ask".equals(fromFile.settings().get("agentShellPermission")), "raw setting.* passthrough");
        check("qwen2.5-coder".equals(fromFile.settings().get("chatModel")), "analyse model defaults to agent model");
        EliyaCliModelConfig.Resolved withEnv = EliyaCliModelConfig.load(Map.of("ELIYA_MODEL", "gpt-x", "ELIYA_API_KEY", "env-key"), file);
        check("gpt-x".equals(withEnv.model()) && "env-key".equals(withEnv.apiKey()), "environment overrides file");
        check(withEnv.source().startsWith("environment"), "source reported");
        check(!EliyaCliModelConfig.load(Map.of("ELIYA_MODEL", "m"), dir.resolve("missing")).complete(), "incomplete config is not ready");
        try {
            var perms = Files.getPosixFilePermissions(file);
            check(perms.size() == 2, "config file is owner read/write only: " + perms);
        } catch (UnsupportedOperationException windows) { passed++; }
    }
}
