package com.llmart.llm.service;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Map;

public final class RecoverySmoke {
    static int cases;
    static void ok(boolean condition, String message) { cases++; if (!condition) throw new AssertionError("FAIL: " + message); }

    public static void main(String[] args) throws Exception {
        configuredStorage();
        recovery();
        durabilityFailure();
        answers();
        System.out.println("PASS: " + cases + " ELIYA156 recovery and popup-answer assertions");
    }

    static void configuredStorage() throws Exception {
        Path home = Files.createTempDirectory("eliya-recovery-home");
        System.setProperty("advanced.ai.home", home.toString());
        com.llmart.llm.config.AppPathResolver.initializeSystemProperties(RecoverySmoke.class);
        Path recovered = Path.of(System.getProperty("advanced.ai.agentRecoveryStore"));
        ok(recovered.equals(home.resolve("data/agent-recovery")), "recovery lives in durable app data, not a transient working directory");
        ok(Files.isDirectory(recovered), "recovery store is created during application startup");
    }

    static AgentRunService.AgentRun failedRun(AgentRunService service, int completedSteps, String status) {
        AgentRunService.AgentRun run = service.start("conv-1", "proj-1");
        run.setObjective("Migrate the payment module to the new client and keep tests green");
        run.setPlan(List.of("Locate PaymentClient usages under src/main/java/pay", "Replace LegacyClient with NewClient in PaymentService.java",
                "Update PaymentServiceTest for NewClient", "Run mvn -q test -Dtest=PaymentServiceTest on the latest revision"));
        run.markPlanStarted();
        for (int i = 1; i <= completedSteps; i++) {
            run.recordPlanToolActivity("read", "evidence for step " + i);
            run.updatePlan(i, "completed", "done step " + i);
        }
        run.finish(status);
        return run;
    }

    static void recovery() throws Exception {
        Path root = Files.createTempDirectory("eliya156-recovery");
        AgentRunService service = new AgentRunService(root);
        AgentRecoveryStore store = new AgentRecoveryStore(root.resolve("recovery-seeds"));

        AgentRunService.AgentRun prior = failedRun(service, 2, "failed");
        AgentRunService.RecoverySeed seed = store.stage(prior);
        ok(seed.restorableCompletedSteps() == 2, "two completed steps restorable");
        ok(seed.plan().size() == 4, "whole plan captured");
        ok(seed.evidence().get(1) != null && seed.evidence().get(1).get(0).contains("evidence for step 1"), "step evidence captured");

        ok(store.consume("other-conv", "other-proj") == null, "no seed for unrelated conversation/workspace");
        // Persistence can survive a JVM restart before the user chooses to continue.
        store = new AgentRecoveryStore(root.resolve("recovery-seeds"));
        AgentRunService.RecoverySeed consumed = store.consume("conv-1", "proj-1");
        ok(consumed != null && consumed.priorRunId().equals(prior.id()), "seed consumed by conversation");
        ok(store.consume("conv-1", "proj-1") == null, "seed is single-use");
        ok(new AgentRecoveryStore(root.resolve("recovery-seeds")).consume("conv-1", "proj-1") == null,
                "consumed recovery seed stays consumed after restart");

        AgentRunService.AgentRun next = service.start("conv-1", "proj-1");
        next.setObjective("Continue and finish the SAME previously requested task ... (long recovery text)");
        next.setPlan(consumed.planTexts());
        int kept = next.restoreFromRecovery(consumed);
        next.markPlanStarted();
        ok(kept == 2, "kept 2 steps");
        ok(next.activePlanIndex() == 3, "execution resumes at step 3, not step 1 (got " + next.activePlanIndex() + ")");
        List<Map<String,Object>> plan = next.planSnapshot();
        ok("completed".equals(plan.get(0).get("status")) && "completed".equals(plan.get(1).get("status")), "completed steps kept");
        ok(String.valueOf(plan.get(0).get("note")).startsWith("Restored from run " + prior.id()), "restored note links prior run");
        ok(!((List<?>) plan.get(1).get("evidence")).isEmpty(), "evidence restored for completed step");
        ok("in_progress".equals(plan.get(2).get("status")) && "pending".equals(plan.get(3).get("status")), "remaining steps open");
        ok(next.objective().startsWith("Migrate the payment module"), "original objective restored, not the recovery prompt");
        ok(next.recoveredFromRunId().equals(prior.id()), "recovery link recorded");
        ok(!next.lastVerificationSuccessful(), "verification is not inherited");

        // A run that failed at the final review: everything completed, but the final step must re-verify.
        AgentRunService.AgentRun allDone = failedRun(service, 4, "blocked");
        AgentRunService.RecoverySeed allSeed = store.stage(allDone);
        ok(allSeed.restorableCompletedSteps() == 3, "final step is always reopened");
        AgentRunService.AgentRun verifyAgain = service.start("conv-1", "proj-1");
        verifyAgain.setPlan(store.consume("conv-1", null).planTexts());
        verifyAgain.restoreFromRecovery(allSeed);
        verifyAgain.markPlanStarted();
        ok(verifyAgain.activePlanIndex() == 4, "resumes at final verification step");

        // Workspace fallback when the follow-up uses another conversation.
        store.stage(failedRun(service, 1, "interrupted"));
        ok(store.consume("new-conversation", "proj-1") != null, "seed found by workspace fallback");

        // Only terminated runs.
        AgentRunService.AgentRun completed = failedRun(service, 4, "completed");
        ok("completed".equals(completed.status()), "fixture: genuinely completed run");
        try { store.stage(completed); ok(false, "completed run must not be recoverable"); }
        catch (IllegalStateException expected) { ok(expected.getMessage().contains("completed"), "clear refusal for completed run"); }

        String prompt = AgentRecoveryContext.prompt(seed, 2);
        ok(prompt.contains("ALREADY COMPLETED") && prompt.contains("Locate PaymentClient"), "context lists completed steps");
        ok(prompt.contains("ORIGINAL TASK") || prompt.contains("Migrate the payment module") || seed.originalTaskContract().isBlank(), "original task included when recorded");
        ok(prompt.contains("must verify the CURRENT workspace"), "fresh verification required");

        // Restart durability: the link survives a reload of the run store.
        AgentRunService reloaded = new AgentRunService(root);
        ok(reloaded.status(next.id()) != null, "recovered run persisted");
    }

    static void durabilityFailure() throws Exception {
        Path root = Files.createTempDirectory("eliya156-unwritable-store");
        Path occupiedFile = root.resolve("store-is-file");
        Files.writeString(occupiedFile, "cannot-create-child-directory");
        AgentRunService inaccessible = new AgentRunService(occupiedFile.resolve("child"));
        AgentRunService.AgentRun run = inaccessible.start("durability-conv", "durability-project");
        ok(!run.durabilityProblem().isBlank(), "checkpoint failures are visible, never silently swallowed");
        run.finish("completed");
        ok("blocked".equals(run.status()), "cannot claim completed if final checkpoint is not durable");
        ok(String.valueOf(run.snapshot().get("durabilityProblem")).contains("checkpoint"),
                "final run API exposes actionable persistence failure");
        ok(Boolean.FALSE.equals(run.snapshot().get("durabilityHealthy")), "run snapshot signals durability failure");
    }

    static void answers() {
        List<String> options = List.of("Retry after fixing provider", "Stop and keep current work", "Cancel");
        ok(AgentQuestionAnswers.matchOption("  retry after fixing PROVIDER. ", options).orElse("").equals("Retry after fixing provider"), "typed option matched");
        ok(AgentQuestionAnswers.matchOption("please retry later", options).isEmpty(), "free text not matched");
        ok(AgentQuestionAnswers.selects("User selected: Retry after fixing provider", "Retry after fixing provider"), "exact choice selects");
        ok(AgentQuestionAnswers.selects("User selected: Custom\nDetails: Retry after fixing provider", "Retry after fixing provider"),
                "the reported bug: Custom + option text now selects the option");
        ok(!AgentQuestionAnswers.selects("User selected: Stop and keep current work", "Retry after fixing provider"), "other option does not select");
        ok(!AgentQuestionAnswers.selects("User selected: Custom\nDetails: retry when you can, and also delete the cache", "Retry after fixing provider"),
                "instructions embedded in free text are not consent");
        ok(AgentQuestionAnswers.shortConsent("User selected: Custom\nDetails: retry"), "short typed consent");
        ok(!AgentQuestionAnswers.shortConsent("User selected: Cancel"), "cancel is not consent");
    }
}
