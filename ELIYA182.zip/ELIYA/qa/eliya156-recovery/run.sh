#!/bin/bash
# ELIYA156: linked recovery restores the plan, completed steps, evidence and task contract of a terminated run;
# popup answers are matched to their exact option. Compiles the REAL AgentRunService with tiny stubs.
set -euo pipefail
BASE="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
SRC="$BASE/src/main/java/com/llmart/llm/service"
OUT="$(mktemp -d)"; trap 'rm -rf "$OUT"' EXIT
mkdir -p "$OUT/src/org/springframework/stereotype" "$OUT/src/com/llmart/llm/service" "$OUT/classes"
cat > "$OUT/src/org/springframework/stereotype/Service.java" <<'EOF'
package org.springframework.stereotype;
public @interface Service {}
EOF
cat > "$OUT/src/com/llmart/llm/service/ProtectedRunSnapshotService.java" <<'EOF'
package com.llmart.llm.service;
public class ProtectedRunSnapshotService { public void discard(String id) {} }
EOF
cat > "$OUT/src/com/llmart/llm/service/OpenAiCompatibleClient.java" <<'EOF'
package com.llmart.llm.service;
public class OpenAiCompatibleClient {
 public record Usage(long inputTokens, long outputTokens, long totalTokens, long cachedInputTokens, long cacheWriteTokens, boolean providerReported) {}
}
EOF
cp "$BASE/qa/eliya156-recovery/RecoverySmoke.java" "$OUT/src/com/llmart/llm/service/"
javac --release 17 -proc:none -encoding UTF-8 -d "$OUT/classes" $(find "$OUT/src" -name '*.java') \
  "$SRC/AgentCancelledException.java" "$SRC/AgentStageMetrics.java" "$SRC/TokenActivityLedger.java" \
  "$SRC/AgentRunService.java" "$SRC/AgentRecoveryStore.java" "$SRC/AgentRecoveryContext.java" "$SRC/AgentQuestionAnswers.java" \
  "$BASE/src/main/java/com/llmart/llm/config/AppPathResolver.java"
java -cp "$OUT/classes" com.llmart.llm.service.RecoverySmoke
