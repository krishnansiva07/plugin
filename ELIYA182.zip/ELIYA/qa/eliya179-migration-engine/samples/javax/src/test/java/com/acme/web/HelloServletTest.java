package com.acme.web;

import javax.servlet.http.HttpServletRequest;

public class HelloServletTest {
    public static void main(String[] args) {
        HttpServletRequest request = name -> "asha";
        String greeting = new HelloServlet().greet(request);
        if (!greeting.equals("Hello asha")) throw new AssertionError("greet: " + greeting);
        if (!new HelloServlet().serve("/x").equals("ok:/x")) throw new AssertionError("serve");
        System.out.println("HelloServletTest: 2 passed");
    }
}
