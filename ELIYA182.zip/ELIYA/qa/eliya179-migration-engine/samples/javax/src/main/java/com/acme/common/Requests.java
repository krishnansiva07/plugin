package com.acme.common;

import javax.servlet.http.HttpServletRequest;

public final class Requests {
    private Requests() { }
    public static String name(HttpServletRequest request) {
        String value = request.getParameter("name");
        return value == null ? "world" : value;
    }
}
