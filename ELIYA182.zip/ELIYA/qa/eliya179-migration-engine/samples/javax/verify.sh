#!/bin/sh
# Compile against the servlet API declared in pom.xml (stub jars), then run the test.
set -e
API=javax; grep -q 'jakarta.servlet-api' pom.xml && API=jakarta
OUT=$(mktemp -d); trap 'rm -rf "$OUT"' EXIT
javac -d "$OUT" $(find stubs/$API -name '*.java') $(find src -name '*.java')
java -cp "$OUT" com.acme.web.HelloServletTest
