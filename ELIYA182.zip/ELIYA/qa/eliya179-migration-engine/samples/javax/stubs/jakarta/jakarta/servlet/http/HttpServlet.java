package jakarta.servlet.http;
public abstract class HttpServlet { public String serve(String path) { return "ok:" + path; } }
