const { format } = require('../lib/oldfmt');
exports.number = (date, n) => format(date, 'YYYYMM') + '-' + n;
