const oldfmt = require('../lib/oldfmt');
exports.title = (date) => 'Report ' + oldfmt.format(date, 'YYYY-MM');
