const test = require('node:test');
const assert = require('node:assert');
const report = require('../src/report');
const invoice = require('../src/invoice');
const d = new Date(Date.UTC(2026, 10, 21));
test('report title', () => assert.strictEqual(report.title(d), 'Report 2026-11'));
test('invoice number', () => assert.strictEqual(invoice.number(d, 7), '202611-7'));
