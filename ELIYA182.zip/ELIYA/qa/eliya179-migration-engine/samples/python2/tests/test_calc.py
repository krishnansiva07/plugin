import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import calc  # noqa: E402
import report  # noqa: E402


class CalcTest(unittest.TestCase):
    def test_totals(self):
        self.assertEqual(calc.totals({"a": 2}), {"a": 4})

    def test_count_up(self):
        self.assertEqual(calc.count_up(3), [0, 1, 2])

    def test_safe_div(self):
        self.assertIsNone(calc.safe_div(1, 0))
        self.assertEqual(calc.safe_div(6, 3), 2)

    def test_label(self):
        self.assertEqual(report.label("ab"), "AB")


if __name__ == "__main__":
    unittest.main()
