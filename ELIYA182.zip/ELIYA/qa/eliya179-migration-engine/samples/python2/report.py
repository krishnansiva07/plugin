def label(name):
    if isinstance(name, basestring):
        return unicode(name).upper()
    return str(name)
