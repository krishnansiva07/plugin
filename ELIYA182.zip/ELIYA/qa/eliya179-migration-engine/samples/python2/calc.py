import ConfigParser


def totals(prices):
    result = {}
    for name, value in prices.iteritems():
        result[name] = value * 2
    return result


def count_up(n):
    out = []
    for i in xrange(n):
        out.append(i)
    return out


def safe_div(a, b):
    try:
        return a / b
    except ZeroDivisionError, e:
        print "division by zero"
        return None
