#!/bin/bash
# ELIYA179: generic migration engine. Understands any migration request, discovers work items, records a test
# baseline, verifies batches (old API gone + no NEW failures), keeps a resumable ledger — proven on three real
# sample migrations (Python 2→3, javax→jakarta with javac/java, a JavaScript library swap with no pack).
set -euo pipefail
BASE="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
HERE="$BASE/qa/eliya179-migration-engine"
S="$BASE/src/main/java/com/llmart/llm/service"
JACKSON_CP="${ELIYA_JACKSON_CP:-}"
if [ -z "$JACKSON_CP" ] && [ -d "$HOME/.m2/repository/com/fasterxml/jackson/core" ]; then
  JACKSON_CP=$(find "$HOME/.m2/repository/com/fasterxml/jackson/core" -name 'jackson-*.jar' ! -name '*sources*' | sort | paste -sd: -)
fi
if [ -z "$JACKSON_CP" ]; then echo "FAIL ELIYA migration acceptance: Jackson not found; set ELIYA_JACKSON_CP"; exit 2; fi
for tool in python3 node npm javac java; do
  command -v "$tool" >/dev/null 2>&1 || { echo "FAIL ELIYA migration acceptance: $tool not installed"; exit 2; }
done
OUT="$(mktemp -d)"; trap 'rm -rf "$OUT"' EXIT
javac --release 17 -proc:none -encoding UTF-8 -cp "$JACKSON_CP" -d "$OUT" \
  "$S/AgentVerificationPolicy.java" "$S/MigrationIntent.java" "$S/MigrationPacks.java" "$S/MigrationEngine.java" "$S/AgentTestWorkflow.java" "$S/AgentCancelledException.java" \
  "$S/AgentPlanSpecificity.java" "$S/AgentPlanningTerms.java" "$S/AgentConversationIntent.java" "$S/AgentPlanRelevance.java" \
  "$S/AgentReadOnlySearchPolicy.java" "$S/AgentRequirementCoverage.java" "$S/AgentToolPalettePolicy.java" "$S/AgentPlanRecovery.java" "$S/AgentPlanJsonEnvelope.java" \
  "$HERE/MigrationE2E.java"
java -cp "$JACKSON_CP:$OUT" com.llmart.llm.service.MigrationE2E "$HERE/samples" 2>&1 | grep -v 'Picked up'
