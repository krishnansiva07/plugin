package com.llmart.llm.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Set;
import java.util.stream.Stream;

/**
 * ELIYA179: generic migration engine, proven on three different REAL migrations (real python3, javac/java, node):
 * Python 2 → 3 (pack), javax → jakarta (pack, Java), and a JavaScript library swap with no pack (generic discovery).
 * The Agent's edits are applied by this harness exactly where the engine points; everything else is the real engine.
 */
public final class MigrationE2E {
    private static final ObjectMapper JSON = new ObjectMapper();
    private static int passed;

    static void check(boolean condition, String name) {
        if (!condition) throw new AssertionError("FAILED: " + name);
        passed++;
    }

    static JsonNode args(String json) throws Exception { return JSON.readTree(json); }

    public static void main(String[] a) throws Exception {
        Path samples = Path.of(a[0]);
        intent();
        packsAndPlanning();
        python(copy(samples.resolve("python2")));
        javax(copy(samples.resolve("javax")));
        jsLibrary(copy(samples.resolve("jslib")));
        System.out.println("ELIYA179 migration engine: " + passed + " checks passed");
    }

    static Path copy(Path source) throws Exception {
        Path target = Files.createTempDirectory("eliya179-" + source.getFileName());
        try (Stream<Path> walk = Files.walk(source)) {
            for (Path p : walk.toList()) {
                Path dest = target.resolve(source.relativize(p).toString());
                if (Files.isDirectory(p)) Files.createDirectories(dest);
                else { Files.copy(p, dest); dest.toFile().setExecutable(p.toFile().canExecute()); }
            }
        }
        return target;
    }

    static void edit(Path root, String file, String from, String to) throws Exception {
        Path path = root.resolve(file);
        String text = Files.readString(path);
        check(text.contains(from), "edit target present in " + file + ": " + from);
        Files.writeString(path, text.replace(from, to));
    }

    // ------------------------------------------------------------------------------------------------ intent

    static void intent() {
        record Case(String request, String source, String target) { }
        for (Case c : List.of(
                new Case("Migrate the billing and orders modules from Spring Boot 2.7 to Spring Boot 3.2", "Spring Boot 2.7", "Spring Boot 3.2"),
                new Case("Upgrade Spring Boot from 2.7 to 3.2 across all modules", "Spring Boot 2.7", "Spring Boot 3.2"),
                new Case("Convert our JUnit 4 tests to JUnit 5", "JUnit 4", "JUnit 5"),
                new Case("Replace moment with dayjs in the frontend", "moment", "dayjs"),
                new Case("Port the Python 2 scripts to Python 3 and run the tests", "Python 2", "Python 3"),
                new Case("switch from Jest to Vitest", "Jest", "Vitest"),
                new Case("Move the app from AngularJS to React", "AngularJS", "React"),
                new Case("javax to jakarta migration in services/api", "javax", "jakarta"),
                new Case("Java 8 → 17 upgrade for the payments service", "Java 8", "Java 17"),
                new Case("Upgrade Angular from 14 to 17 and run the e2e tests", "Angular 14", "Angular 17"),
                new Case("We need to move from log4j 1.x to Log4j 2 in all modules", "log4j 1.x", "Log4j 2"),
                new Case("Rewrite the build from Maven to Gradle and verify with gradle test", "Maven", "Gradle"),
                new Case("upgrade the project to Java 21", "", "Java 21"),
                new Case("Replace the oldfmt library with newfmt across the project", "oldfmt", "newfmt"))) {
            MigrationIntent.Spec spec = MigrationIntent.parse(c.request()).orElse(null);
            check(spec != null && spec.source().equals(c.source()) && spec.target().equals(c.target()),
                    "understood: " + c.request() + " → " + (spec == null ? "-" : spec.summary()));
            check(MigrationIntent.isMigration(c.request()), "is migration: " + c.request());
        }
        check(MigrationIntent.parse("Migrate the billing and orders modules from Spring Boot 2.7 to Spring Boot 3.2").get().scope().equals(List.of("billing", "orders")), "scope modules");
        check(MigrationIntent.parse("Migrate from Selenium to Playwright for the com.acme.tests.login package").get().scope().equals(List.of("com.acme.tests.login")), "scope package");
        check(MigrationIntent.parse("Rewrite the build from Maven to Gradle and verify with gradle test").get().verify().equals("gradle test"), "verify hint");
        for (String notMigration : List.of("move the button to the header", "Convert the README to Markdown", "convert the dates to UTC",
                "Fix the login bug", "Refactor the payment service", "switch the tab to the second page", "Create a Flyway migration for the orders table",
                "add a database migration script", "run pending migrations"))
            check(!MigrationIntent.isMigration(notMigration), "not a migration: " + notMigration);
        check(MigrationIntent.isMigration("Continue the migration") && MigrationIntent.parse("Continue the migration").isEmpty(), "resume request");
    }

    static void packsAndPlanning() {
        check(MigrationPacks.match("Spring Boot 2.7", "Spring Boot 3.2").get().id().equals("spring-boot-3"), "pack spring boot 3");
        check(MigrationPacks.match("javax", "jakarta").get().id().equals("javax-to-jakarta"), "pack jakarta");
        check(MigrationPacks.match("Java 8", "Java 17").get().id().equals("java-version"), "pack java");
        check(MigrationPacks.match("", "Java 21").get().id().equals("java-version"), "pack java target-only");
        check(MigrationPacks.recipeFor(MigrationPacks.match("Java 11", "Java 21").get(), "Java 21").contains("UpgradeToJava21"), "java 21 recipe");
        check(MigrationPacks.match("JUnit 4", "JUnit 5").get().id().equals("junit4-to-junit5"), "pack junit");
        check(MigrationPacks.match("selenium", "playwright").get().id().equals("selenium-to-playwright"), "pack selenium");
        check(MigrationPacks.match("Python 2", "Python 3").get().id().equals("python2-to-python3"), "pack python");
        check(MigrationPacks.match("oldfmt", "newfmt").isEmpty() && !MigrationPacks.generic("oldfmt").isEmpty(), "no pack: generic residue");
        // Planning rules are generic now (not only Selenium → Playwright).
        String boot = "Migrate the billing module from Spring Boot 2.7 to Spring Boot 3.2";
        check(!AgentPlanSpecificity.mismatch(boot, List.of("Inspect billing", "Update dependencies", "Run tests")).isBlank(), "plan without target rejected");
        check(AgentPlanSpecificity.mismatch(boot, List.of("Inventory billing usages of Spring Boot 2.7 APIs with migration_init",
                "Upgrade billing to Spring Boot 3.2 and jakarta imports", "Run migration_verify for billing")).isBlank(), "specific plan accepted: " + AgentPlanSpecificity.mismatch(boot, List.of("Inventory billing usages of Spring Boot 2.7 APIs with migration_init", "Upgrade billing to Spring Boot 3.2 and jakarta imports", "Run migration_verify for billing")));
        check(!AgentPlanSpecificity.mismatch("migrate selenium tests to playwright",
                List.of("Inspect Selenium modules", "Modify Selenium test classes", "Verify changes")).isBlank(), "selenium case still rejected");
        check(AgentRequirementCoverage.extract("Replace the oldfmt library with newfmt across the project").stream()
                .anyMatch(r -> r.kind().equals("migration target") && r.text().equals("newfmt")), "coverage uses generic intent");
        Set<String> palette = AgentToolPalettePolicy.select("Upgrade the payments service from Java 8 to Java 17 and fix compile errors", false,
                Set.of("read", "edit", "bash", "tool_search", "migration_init", "migration_verify", "migration_status", "migration_update", "migration_baseline"));
        check(palette.containsAll(AgentToolPalettePolicy.MIGRATION), "migration tools advertised: " + palette);
    }

    // ------------------------------------------------------------------------------------------------ Python

    static void python(Path root) throws Exception {
        MigrationEngine engine = MigrationEngine.standard();
        String request = "Port the Python 2 code to Python 3 and run the tests";
        MigrationEngine.Outcome init = engine.init(root, args("{\"verifyCommand\":\"python3 -m unittest discover -s tests -v\"}"), request);
        check(!init.failed() && init.text().contains("Python 2 → Python 3") && init.text().contains("Knowledge pack: Python 2 → Python 3"), "py init: " + init.text());
        check(init.text().contains("Work items: 2 files"), "py items: calc.py + report.py");
        Path dir = root.resolve("migration/python-2-to-python-3");
        check(Files.isRegularFile(dir.resolve("items.csv")) && Files.readString(dir.resolve("MAPPING.md")).contains("print(x)"), "py ledger + mapping");
        MigrationEngine.Outcome baseline = engine.baseline(root, args("{}"), () -> false);
        check(baseline.text().contains("already failing before the migration") && baseline.testFailed(), "py baseline fails before: " + baseline.text());

        // Batch 1: calc.py fully, report.py only half (unicode left behind).
        edit(root, "calc.py", "import ConfigParser", "import configparser");
        edit(root, "calc.py", "prices.iteritems()", "prices.items()");
        edit(root, "calc.py", "xrange(n)", "range(n)");
        edit(root, "calc.py", "except ZeroDivisionError, e:\n        print \"division by zero\"", "except ZeroDivisionError as e:\n        print(\"division by zero\")");
        edit(root, "calc.py", "return a / b", "return a // b if a % b == 0 else a / b");
        edit(root, "report.py", "basestring", "str");
        check(!engine.update(root, args("{\"items\":[\"calc.py\",\"report.py\"],\"status\":\"migrated\"}")).failed(), "py mark migrated");
        MigrationEngine.Outcome first = engine.verify(root, args("{}"), () -> false);
        check(first.failed() && first.text().contains("unicode") && first.text().contains("report.py"), "py leftover residue found: " + first.text());
        check(first.text().contains("NEW failures") && first.text().contains("test_label"), "py new failure named");
        check(engine.completionProblem(root).unfinished(), "py not finished");
        // Fix and verify again.
        edit(root, "report.py", "unicode(name)", "str(name)");
        MigrationEngine.Outcome second = engine.verify(root, args("{}"), () -> false);
        check(!second.failed() && second.text().startsWith("MIGRATION BATCH VERIFIED: 2 verified") && second.text().contains("passing"), "py verified: " + second.text());
        check(engine.completionProblem(root) != null, "py final verification required");
        MigrationEngine.Outcome pyFinal = engine.verify(root, args("{\"final\":true}"), () -> false);
        check(!pyFinal.failed() && engine.completionProblem(root) == null && engine.report(root).contains("2 verified"), "py complete: " + pyFinal.text());
        // Resume keeps the ledger.
        MigrationEngine.Outcome again = engine.init(root, args("{}"), request);
        check(again.text().startsWith("MIGRATION RESUMED") && again.text().contains("2 verified"), "py resume keeps progress");
    }

    // ------------------------------------------------------------------------------------------------ Java

    static void javax(Path root) throws Exception {
        MigrationEngine engine = MigrationEngine.standard();
        String request = "Migrate the web app from javax to jakarta";
        MigrationEngine.Outcome init = engine.init(root, args("{\"verifyCommand\":\"sh verify.sh\",\"exclude\":[\"stubs/\"]}"), request);
        check(!init.failed() && init.text().contains("javax → jakarta") && init.text().contains("Java EE javax.* → Jakarta EE"), "java init: " + init.text());
        check(init.text().contains("Automatic rewrite available") && init.text().contains("JavaxMigrationToJakarta"), "openrewrite recipe offered");
        List<MigrationEngine.Item> items = MigrationEngine.readItems(root.resolve("migration/javax-to-jakarta"));
        check(items.stream().map(i -> i.path).toList().equals(List.of("pom.xml", "src/main/java/com/acme/common/Requests.java",
                "src/main/java/com/acme/web/HelloServlet.java", "src/test/java/com/acme/web/HelloServletTest.java")), "dependency order: " +
                items.stream().map(i -> i.path).toList());
        check(items.get(2).residue == 2, "javax.crypto (JDK) not counted");
        MigrationEngine.Outcome baseline = engine.baseline(root, args("{}"), () -> false);
        check(baseline.text().contains("exit 0") && !baseline.testFailed(), "java baseline passes");

        // Batch 1: build file + shared code only → the rest no longer compiles → not verified.
        edit(root, "pom.xml", "<groupId>javax.servlet</groupId><artifactId>javax.servlet-api</artifactId><version>4.0.1</version>",
                "<groupId>jakarta.servlet</groupId><artifactId>jakarta.servlet-api</artifactId><version>6.0.0</version>");
        edit(root, "src/main/java/com/acme/common/Requests.java", "import javax.servlet", "import jakarta.servlet");
        engine.update(root, args("{\"items\":[\"M0001\",\"M0002\"],\"status\":\"migrated\"}"));
        MigrationEngine.Outcome first = engine.verify(root, args("{}"), () -> false);
        check(first.failed() && first.text().contains("command failed") && first.testFailed(), "compile break detected: " + first.text());
        check(engine.status(root).text().contains("Next batch") && engine.status(root).text().contains("[failed"), "failed items come first in the next batch");
        // Batch 2: the rest.
        edit(root, "src/main/java/com/acme/web/HelloServlet.java", "import javax.servlet.http.HttpServlet;\nimport javax.servlet.http.HttpServletRequest;",
                "import jakarta.servlet.http.HttpServlet;\nimport jakarta.servlet.http.HttpServletRequest;");
        edit(root, "src/test/java/com/acme/web/HelloServletTest.java", "import javax.servlet", "import jakarta.servlet");
        engine.update(root, args("{\"items\":[\"M0003\",\"M0004\"],\"status\":\"migrated\"}"));
        MigrationEngine.Outcome second = engine.verify(root, args("{}"), () -> false);
        check(!second.failed() && second.text().contains("4 verified") && second.text().contains("exit 0"), "java verified: " + second.text());
        check(Files.readString(root.resolve("src/main/java/com/acme/web/HelloServlet.java")).contains("javax.crypto.Cipher"), "JDK javax kept");
        check(engine.completionProblem(root) != null, "java final verification required");
        MigrationEngine.Outcome javaFinal = engine.verify(root, args("{\"final\":true}"), () -> false);
        check(!javaFinal.failed() && engine.completionProblem(root) == null, "java complete: " + javaFinal.text());
        check(MigrationEngine.facts(root).get("build").equals("maven"), "facts read from pom");
    }

    // -------------------------------------------------------------------------------- JS library swap, no pack

    static void jsLibrary(Path root) throws Exception {
        MigrationEngine engine = MigrationEngine.standard();
        String request = "Replace the oldfmt library with newfmt across the project";
        check(MigrationEngine.detectVerifyCommand(root, "").equals("npm test"), "verify command detected from package.json");
        MigrationEngine.Outcome init = engine.init(root, args("{}"), request);
        check(!init.failed() && init.text().contains("oldfmt → newfmt") && init.text().contains("Knowledge pack: none (generic discovery"), "js init: " + init.text());
        List<MigrationEngine.Item> items = MigrationEngine.readItems(root.resolve("migration/oldfmt-to-newfmt"));
        check(items.stream().map(i -> i.path).toList().equals(List.of("src/invoice.js", "src/report.js")), "generic discovery found both users: " +
                items.stream().map(i -> i.path).toList());
        MigrationEngine.Outcome baseline = engine.baseline(root, args("{}"), () -> false);
        check(baseline.text().contains("npm test") && !baseline.testFailed(), "js baseline passes: " + baseline.text());

        // report.js migrated; invoice.js blocked (needs a decision) → run ends blocked with the reason.
        edit(root, "src/report.js", "const oldfmt = require('../lib/oldfmt');\nexports.title = (date) => 'Report ' + oldfmt.format(date, 'YYYY-MM');",
                "const newfmt = require('../lib/newfmt');\nexports.title = (date) => 'Report ' + newfmt(date).as('YYYY-MM');");
        engine.update(root, args("{\"items\":[\"src/report.js\"],\"status\":\"migrated\"}"));
        check(engine.update(root, args("{\"items\":[\"src/invoice.js\"],\"status\":\"blocked\"}")).failed(), "blocked needs a reason");
        engine.update(root, args("{\"items\":[\"src/invoice.js\"],\"status\":\"blocked\",\"note\":\"invoice numbers are printed on legal documents; confirm the format\"}"));
        check(engine.update(root, args("{\"items\":[\"src/report.js\"],\"status\":\"verified\"}")).failed(), "cannot self-mark verified");
        MigrationEngine.Outcome verified = engine.verify(root, args("{}"), () -> false);
        check(!verified.failed() && verified.text().contains("1 verified"), "js report verified: " + verified.text());
        MigrationEngine.Problem problem = engine.completionProblem(root);
        check(problem != null && !problem.unfinished() && problem.text().contains("legal documents"), "blocked item ends the run with the reason");
        // User decides: migrate it too.
        edit(root, "src/invoice.js", "const { format } = require('../lib/oldfmt');\nexports.number = (date, n) => format(date, 'YYYYMM') + '-' + n;",
                "const newfmt = require('../lib/newfmt');\nexports.number = (date, n) => newfmt(date).as('YYYYMM') + '-' + n;");
        engine.update(root, args("{\"items\":[\"src/invoice.js\"],\"status\":\"migrated\"}"));
        MigrationEngine.Outcome done = engine.verify(root, args("{}"), () -> false);
        check(!done.failed() && engine.completionProblem(root) != null, "js must run final verification");
        MigrationEngine.Outcome jsFinal = engine.verify(root, args("{\"final\":true}"), () -> false);
        check(!jsFinal.failed() && engine.completionProblem(root) == null && engine.report(root).contains("2 verified"), "js complete: " + jsFinal.text());
        // Safety: unknown target, no workspace, bad patterns.
        check(engine.init(root, args("{\"restart\":true}"), "migrate the database schema").failed(), "no target: nothing created");
        check(engine.init(null, args("{}"), request).failed(), "needs a workspace");
        check(engine.init(root, args("{\"target\":\"x\",\"residuePatterns\":[\"(unclosed\"]}"), "").failed(), "invalid regex rejected");
        check(MigrationEngine.protocol(request).contains("migration_baseline") && MigrationEngine.analyseGuidance(request).contains("Agent mode"), "guidance text");
    }
}
