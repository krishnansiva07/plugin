package com.llmart.llm.cli.tui;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.LinkedBlockingQueue;

/**
 * Chat for terminals without raw-mode support (Windows consoles, IDE consoles, pipes). Same commands and routing
 * as the full-screen chat; multi-line paste is kept together as one message, and you can type while a task runs.
 */
public final class TuiLineChat implements TuiController.View {
    private final TuiController controller;
    private final PrintStream out;
    private final boolean color;
    private final boolean unicode;
    private final java.nio.charset.Charset inputCharset;
    private volatile boolean exit;
    private final Object printLock = new Object();
    private TuiTranscript.Entry streaming;

    public TuiLineChat(TuiController controller, PrintStream out, boolean color) {
        this(controller, out, color, true, StandardCharsets.UTF_8);
    }

    /** {@code unicode=false} uses ASCII symbols for consoles whose code page cannot show them (e.g. cp437). */
    public TuiLineChat(TuiController controller, PrintStream out, boolean color, boolean unicode, java.nio.charset.Charset inputCharset) {
        this.controller = controller; this.out = out; this.color = color; this.unicode = unicode;
        this.inputCharset = inputCharset == null ? StandardCharsets.UTF_8 : inputCharset;
    }

    private String c(String style) { return color ? style : ""; }

    /** Symbol with an ASCII fallback. */
    private String s(String symbol) {
        if (unicode) return symbol;
        return switch (symbol) {
            case "◆" -> "*"; case "✓" -> "ok"; case "✗" -> "x"; case "⚠" -> "!"; case "⏳" -> "..."; case "◌" -> "~";
            case "·" -> "-"; case "›" -> ">"; case "↳" -> "->"; case "■" -> "#"; case "—" -> "-";
            default -> symbol;
        };
    }

    private String ascii(String text) {
        if (unicode) return text;
        StringBuilder out = new StringBuilder(text.length());
        text.codePoints().forEach(cp -> {
            if (cp < 128) out.appendCodePoint(cp);
            else if (cp == '·' || cp == '—' || cp == '–') out.append('-');
            else if (cp == '…') out.append("...");
            else if (cp == '‘' || cp == '’') out.append('\'');
            else if (cp == '“' || cp == '”') out.append('"');
            else if (cp == '↑') out.append("Up"); else if (cp == '↓') out.append("Down");
            else out.appendCodePoint(cp);
        });
        return out.toString();
    }

    public void run() throws Exception {
        controller.attach(this);
        controller.transcript().observe(new TuiTranscript.Observer() {
            @Override public void added(TuiTranscript.Entry entry) { print(entry); }
            @Override public void appended(TuiTranscript.Entry entry, String delta) {
                synchronized (printLock) {
                    if (streaming != entry) { print(entry); return; }
                    out.print(ascii(TuiText.sanitize(delta))); out.flush();
                }
            }
            @Override public void updated(TuiTranscript.Entry entry) {
                if (entry.kind() == TuiTranscript.Kind.ACTIVITY && !"running".equals(entry.status())) print(entry);
            }
        });
        out.println(c(TuiText.BOLD) + "ELIYA chat" + c(TuiText.RESET) + c(TuiText.GRAY) + " " + s("—") +
                " paste freely; a line ending with \\ continues; \"\"\" starts/ends a block; /help; /exit" + c(TuiText.RESET));
        controller.welcomeHint("Enter sends " + s("·") + " /agent or /analyse switches mode " + s("·") +
                " while a task runs: type to add to it, /q <text> queues next, /stop stops");
        controller.start();
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in, inputCharset));
        LinkedBlockingQueue<String> messages = new LinkedBlockingQueue<>();
        Thread readerThread = new Thread(() -> readMessages(reader, messages), "eliya-line-input");
        readerThread.setDaemon(true);
        readerThread.start();
        prompt();
        try {
            while (!exit) {
                String message = messages.take();
                if (message == null || message.equals("\u0000EOF")) break;
                if (controller.running() && controller.approval() == null && controller.question() == null
                        && message.toLowerCase().startsWith("/q ") ) { controller.queueNext(message.substring(3)); continue; }
                boolean wasRunning = controller.running();
                controller.submit(message);
                if (exit) break;
                if (!wasRunning && controller.running()) watchRunEnd();
                else prompt();
            }
        } finally {
            if (controller.running()) { try { controller.stop(); Thread.sleep(300); } catch (Exception ignored) { } }
            controller.shutdown();
        }
    }

    /** Show the prompt again when the task finishes (the answer streams in between). */
    private void watchRunEnd() {
        Thread watcher = new Thread(() -> {
            try {
                while (controller.running()) Thread.sleep(100);
                Thread.sleep(50);
            } catch (InterruptedException interrupted) { return; }
            if (!exit && !controller.running()) prompt();
            else if (controller.running()) watchRunEnd(); // a queued task started
        }, "eliya-line-prompt");
        watcher.setDaemon(true);
        watcher.start();
    }

    /** Group lines into messages: pasted lines arriving together, "\"-continued lines and """ blocks. */
    static void readMessages(BufferedReader reader, LinkedBlockingQueue<String> messages) {
        try {
            String line;
            while ((line = reader.readLine()) != null) {
                StringBuilder message = new StringBuilder(line);
                if (line.strip().equals("\"\"\"")) {
                    message.setLength(0);
                    String next;
                    while ((next = reader.readLine()) != null && !next.strip().equals("\"\"\"")) {
                        if (message.length() > 0) message.append('\n');
                        message.append(next);
                    }
                } else {
                    while (true) {
                        if (endsWithContinuation(message)) {
                            message.setLength(message.length() - 1);
                            String next = reader.readLine();
                            if (next == null) break;
                            message.append('\n').append(next);
                            continue;
                        }
                        if (!pasteContinues(reader)) break;
                        String next = reader.readLine();
                        if (next == null) break;
                        message.append('\n').append(next);
                    }
                }
                messages.put(message.toString());
            }
        } catch (Exception ignored) { }
        messages.offer("\u0000EOF");
    }

    private static boolean endsWithContinuation(StringBuilder message) {
        int length = message.length();
        return length > 0 && message.charAt(length - 1) == '\\' && (length < 2 || message.charAt(length - 2) != '\\');
    }

    /** More input already waiting right after a line means it was pasted together. */
    private static boolean pasteContinues(BufferedReader reader) throws Exception {
        for (int i = 0; i < 4; i++) {
            if (reader.ready()) return true;
            Thread.sleep(10);
        }
        return reader.ready();
    }

    private void prompt() {
        if (exit) return;
        synchronized (printLock) {
            String label;
            if (controller.approval() != null) label = "approve y/a/n";
            else if (controller.question() != null) label = "answer";
            else if (controller.running()) label = controller.runId().isBlank() ? "queued next" : "add to task (/q text = queue next)";
            else label = TuiController.label(controller.mode()).toLowerCase();
            out.print("\n" + c("agent".equals(controller.mode()) ? TuiText.MAGENTA : TuiText.CYAN) + "eliya " + label + " " + s("›") + " " + c(TuiText.RESET));
            out.flush();
        }
    }

    private void print(TuiTranscript.Entry entry) {
        synchronized (printLock) {
            if (streaming != null && !streaming.text().endsWith("\n")) out.println();
            streaming = null;
            String text = ascii(TuiText.sanitize(entry.text()));
            switch (entry.kind()) {
                case USER -> { if (!entry.title().isBlank()) out.println(c(TuiText.CYAN) + "  " + s("↳") + " " + entry.title() + c(TuiText.RESET)); }
                case ASSISTANT -> { out.print("\n" + c(TuiText.MAGENTA + TuiText.BOLD) + s("◆") + " Eliya" + c(TuiText.RESET) + "\n" + text); streaming = entry; }
                case ACTIVITY -> out.println("\n  " + icon(entry.status()) + " " + c(TuiText.BOLD) + entry.title() + c(TuiText.RESET) + " " + c(TuiText.GRAY) + text.replace('\n', ' ') + c(TuiText.RESET));
                case INFO -> out.println("\n" + c(TuiText.GRAY) + text + c(TuiText.RESET));
                case ERROR -> out.println("\n" + c(TuiText.RED) + s("✗") + " " + (entry.title().isBlank() ? "" : entry.title() + ": ") + text + c(TuiText.RESET));
                case APPROVAL -> { out.println("\n" + c(TuiText.YELLOW + TuiText.BOLD) + s("⚠") + " " + entry.title() + c(TuiText.RESET) + "\n" + text); promptLater(); }
                case QUESTION -> { out.println("\n" + c(TuiText.BLUE + TuiText.BOLD) + "? " + entry.title() + c(TuiText.RESET) + "\n" + text); promptLater(); }
                case RESULT -> { out.println("\n" + c("success".equals(entry.status()) ? TuiText.GREEN : TuiText.YELLOW) + s("■") + " " + entry.title() + ": " + text + c(TuiText.RESET)); }
                case QUEUED -> out.println("\n" + c(TuiText.GRAY) + s("⏳") + " " + entry.title() + ": " + text + c(TuiText.RESET));
            }
            out.flush();
        }
    }

    private void promptLater() {
        Thread thread = new Thread(() -> { try { Thread.sleep(50); } catch (InterruptedException ignored) { } prompt(); });
        thread.setDaemon(true);
        thread.start();
    }

    private String icon(String status) {
        return switch (status) {
            case "success", "completed", "done" -> c(TuiText.GREEN) + s("✓") + c(TuiText.RESET);
            case "error", "failed", "denied", "blocked" -> c(TuiText.RED) + s("✗") + c(TuiText.RESET);
            case "warning" -> c(TuiText.YELLOW) + "!" + c(TuiText.RESET);
            case "running", "started" -> c(TuiText.YELLOW) + s("◌") + c(TuiText.RESET);
            default -> s("·");
        };
    }

    @Override public void changed() { }

    @Override public void exit() { exit = true; }

    @Override public String copy(String text) {
        String command = TuiClipboard.copyNative(text);
        if (command == null) { out.print(TuiClipboard.osc52(text)); out.flush(); }
        return "Copied the last answer" + (command == null ? " via the terminal clipboard" : " with " + command) + ".";
    }

    @Override public void openWeb(String url, boolean window) {
        if (window) com.llmart.llm.cli.EliyaUiLauncher.openAppWindow(url);
        else com.llmart.llm.cli.EliyaCliBridge.openBrowser(url);
    }
}
