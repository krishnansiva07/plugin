package com.llmart.llm.cli.tui;

import java.util.List;

/** What the terminal chat needs from a running Eliya server. The HTTP implementation talks to the CLI bridge. */
public interface TuiBackend {

    /** Streamed events of one Analyse/Agent run, in arrival order. Called from the run thread. */
    interface Listener {
        void token(String text);
        void runId(String runId);
        void step(String tool, String status, String detail, String step, String approvalId, String approvalType);
        void question(String id, String reason, List<String> choices);
        void changes(String count);
        void status(String phase, String detail);
        void error(String message);
        void stopped(String message);
        void done(String content);
    }

    record Status(String workspace, String mode, boolean modelConfigured, String model, String chatModel,
                  String hint, String url, String sessionId) { }

    record RunResult(String status, String verification, String runId) { }

    /** Blocks until the run's stream ends. */
    void run(String mode, String prompt, Listener listener) throws Exception;

    void approve(String runId, String approvalId, String decision) throws Exception;

    void answer(String runId, String questionId, String choice, String detail) throws Exception;

    /** Returns true when a run was actually asked to stop. */
    boolean cancel() throws Exception;

    /** Add text to the running Agent task (delivered after its current action). Returns the input id. */
    String addInput(String runId, String text) throws Exception;

    /** Select Analyse/Agent; returns the workspace the server uses for this session. */
    String mode(String mode) throws Exception;

    /** Map a project folder; {@code fresh} starts a new conversation. Returns the selected workspace. */
    String activate(String workspace, boolean fresh) throws Exception;

    Status status() throws Exception;

    RunResult latestResult() throws Exception;

    /** Tell open browser tabs that the conversation changed. */
    void refresh();
}
