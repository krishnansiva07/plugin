#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
bash qa/verify-sources.sh
# Use system Maven if present, otherwise the bundled Maven bootstrap.
if command -v mvn >/dev/null 2>&1; then
  MAVEN=(mvn)
else
  MAVEN=(./mvnw)
fi
"${MAVEN[@]}" -Pfull-tests -Dmaven.test.skip=false clean verify
if [[ ! -s target/eliya.jar ]]; then
  echo 'ERROR: Verification did not produce an executable target/eliya.jar' >&2
  exit 1
fi
# Capture the archive list to avoid a SIGPIPE false failure under pipefail.
ARCHIVE_LIST="$(mktemp)"
trap 'rm -f "$ARCHIVE_LIST"' EXIT
jar tf target/eliya.jar > "$ARCHIVE_LIST"
if ! grep -q 'BOOT-INF/classes/' "$ARCHIVE_LIST"; then
  echo 'ERROR: JAR is not a Spring Boot executable archive' >&2
  exit 1
fi
printf 'Verified Maven build and JAR: %s/target/eliya.jar\n' "$PWD"
