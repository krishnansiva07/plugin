@echo off
setlocal
cd /d "%~dp0"
rem Fail early if files are missing or extracted into the wrong package.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0qa\verify-sources.ps1"
if errorlevel 1 (
  echo ERROR: Source archive is incomplete. No Maven compilation attempted.
  exit /b 1
)
where mvn >nul 2>nul
if errorlevel 1 (
  call mvnw.cmd -Pfull-tests -Dmaven.test.skip=false clean verify
) else (
  call mvn -Pfull-tests -Dmaven.test.skip=false clean verify
)
if errorlevel 1 (
  echo ERROR: Maven test or build verification failed. No certified JAR.
  exit /b 1
)
if not exist "target\eliya.jar" (
  echo ERROR: target\eliya.jar missing.
  exit /b 1
)
jar tf target\eliya.jar | findstr /C:"BOOT-INF/classes/" >nul
if errorlevel 1 (
  echo ERROR: JAR lacks Spring Boot executable classes.
  exit /b 1
)
echo Verified Maven build and JAR: %CD%\target\eliya.jar
endlocal
