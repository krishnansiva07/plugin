# Astra UI Recorder - Phase 2

A loadable Chrome Extension that records UI actions with smart locator context, lets testers attach validation comments, and produces an optimized LLM-ready JSON/prompt.

## What Phase 2 Adds

Phase 1 recorded raw compact actions. Phase 2 adds an optimizer layer:

- Removes duplicate/noisy actions.
- Merges consecutive input events on the same element.
- Keeps only compact action + locator + validation context.
- Selects best locator and marks confidence as high/medium/low.
- Generates page object hints and suggested method names.
- Converts validation comments into assertion hints.
- Shows raw vs optimized action count.
- Estimates approximate JSON/token size.
- Allows export of:
  - Raw JSON
  - Optimized JSON
  - LLM Prompt + Optimized JSON

## Install

1. Open Chrome.
2. Go to `chrome://extensions`.
3. Enable **Developer mode**.
4. Click **Load unpacked**.
5. Select the `astra-ui-recorder-phase2` folder.
6. Open the target application.
7. Click the extension icon.
8. The side panel opens.
9. Click **Start** and perform the UI flow.

## Recommended Usage

1. Enter a flow name, for example `Login with valid user`.
2. Click **Start**.
3. Perform the UI actions.
4. For important steps, select the step and add validation/comment.
5. Use validation type when possible:
   - Assert visible
   - Assert text
   - Assert URL
   - Assert count
   - Dynamic value / do not hardcode
6. Copy **LLM Prompt + JSON** and send it to your Spring Boot LLM automation engine.

## Output Modes

### Raw JSON

Close to the original recorded data. Useful for debugging locator extraction.

### Optimized JSON

Best option for LLM input. It reduces size and adds automation hints.

### LLM Prompt + JSON

Ready-to-send text prompt that tells the LLM to reuse existing page objects, step definitions, utilities, and locators before generating new code.

## Phase 2 Optimized JSON Example

```json
{
  "schemaVersion": "astra-ui-recorder.phase2.optimized.v1",
  "recordingMode": "optimized-compact",
  "testName": "Login flow",
  "optimization": {
    "rawActionCount": 6,
    "optimizedActionCount": 4,
    "removedNoiseCount": 2
  },
  "actions": [
    {
      "step": 1,
      "action": "input",
      "intent": "Enter value in Username",
      "page": {
        "url": "https://example.com/login",
        "title": "Login",
        "pageObjectHint": "LoginPage"
      },
      "element": {
        "tag": "input",
        "role": "textbox",
        "label": "Username",
        "name": "username"
      },
      "bestLocator": {
        "type": "playwright",
        "value": "getByLabel('Username')",
        "score": 90,
        "confidence": "high"
      },
      "automationHints": {
        "pageObject": "LoginPage",
        "suggestedMethodName": "enterUsername",
        "gherkinStep": "When I enter value in Username",
        "confidence": "high",
        "needsManualReview": false
      }
    }
  ]
}
```

## Current Limitations

- This phase does not call the LLM API directly.
- It does not modify your Playwright/Selenium framework yet.
- Cross-origin iframes are not recorded in this version.
- Very dynamic web apps may still produce some low-confidence locators; those are shown as warnings.

## Suggested Phase 3

Phase 3 should connect this extension to your Java Spring Boot LLM API:

1. Send optimized JSON to Spring Boot.
2. Spring Boot scans existing Playwright/Selenium project.
3. LLM receives project summary + optimized recording.
4. Engine reuses existing feature files, step definitions, page objects, and utilities.
5. Engine writes only missing code.
6. Response comes back to side panel with generated files and review summary.
