# Astra UI Recorder - Phase 1

A Chrome Extension that records compact UI actions with smart locator candidates, parent-child element context, and tester validation comments for LLM automation generation.

## What Phase 1 Supports

- Start / stop recording from Chrome Side Panel
- Capture meaningful actions only:
  - click
  - input
  - select
  - checkbox/radio
  - upload field change
  - Enter / Tab keyboard action
- Extract compact locator context:
  - data-testid / data-test / data-qa / data-cy
  - role + accessible name
  - label
  - placeholder
  - name / id
  - stable CSS
  - XPath fallback
- Capture parent context up to 3 meaningful levels
- Add validation comments per recorded step
- Export compact JSON for LLM input
- Mask obvious sensitive/dynamic values such as password/email/tel/long numeric values

## How to Install Locally

1. Open Chrome.
2. Go to `chrome://extensions`.
3. Enable **Developer mode**.
4. Click **Load unpacked**.
5. Select the `astra-ui-recorder-phase1` folder.
6. Pin the extension if needed.
7. Click the extension icon to open the side panel.

## How to Use

1. Open your target web application.
2. Open **Astra UI Recorder** from the Chrome extension icon.
3. Enter a flow name, for example `Login flow`.
4. Click **Start**.
5. Perform UI actions on the application.
6. For each captured step, select the step and add validation/comment.
7. Click **Attach Comment**.
8. Click **Copy Compact JSON** or **Download JSON**.

## Recommended LLM Usage

Send the exported JSON to your Spring Boot LLM automation engine along with:

- existing framework scan summary
- target framework type: Playwright TypeScript / Java Selenium
- coding standard
- reusable page object and step definition inventory

## Notes

- The extension does not record full DOM.
- It records only interacted elements and compact nearby context.
- It does not run on Chrome internal pages such as `chrome://extensions`.
- This is Phase 1 and intentionally avoids direct LLM API calls. Phase 2 can add LLM optimizer and Phase 3 can integrate with your Spring Boot generator.
