// Astra UI Recorder - Phase 2 Optimizer
// Pure browser-side optimizer. No network calls. Keeps LLM payload compact.
(function () {
  const INPUT_ACTIONS = new Set(['input', 'select', 'check', 'radio', 'upload']);

  function buildOptimizedPayload(rawPayload, options = {}) {
    const maxActions = Number(options.maxActions || 250);
    const rawActions = Array.isArray(rawPayload?.actions) ? rawPayload.actions : [];
    const cleaned = removeNoiseAndMerge(rawActions).slice(0, maxActions);
    const optimizedActions = cleaned.map((action, index) => optimizeAction(action, index + 1));
    const pages = buildPagesSummary(optimizedActions);
    const validations = optimizedActions.filter(a => a.validation?.required || a.comment).map(a => ({
      step: a.step,
      type: a.validation?.type || 'comment',
      expected: a.validation?.expected || a.comment || '',
      target: a.bestLocator?.value || a.element?.name || a.element?.label || ''
    }));
    const warnings = buildWarnings(optimizedActions, rawActions.length, cleaned.length);
    const flowSummary = buildFlowSummary(optimizedActions, pages);

    const payload = compactObject({
      schemaVersion: 'astra-ui-recorder.phase2.optimized.v1',
      target: 'llm-automation-generation',
      recordingMode: 'optimized-compact',
      optimization: {
        rawActionCount: rawActions.length,
        optimizedActionCount: optimizedActions.length,
        removedNoiseCount: Math.max(0, rawActions.length - cleaned.length),
        strategy: [
          'merge consecutive inputs on same element',
          'remove duplicate clicks/keyboard noise',
          'keep only best locators and small context',
          'classify action and validation intent',
          'generate page object and method hints'
        ]
      },
      testName: rawPayload?.testName || 'Recorded UI Flow',
      startedAt: rawPayload?.startedAt,
      exportedAt: new Date().toISOString(),
      startUrl: rawPayload?.startUrl || optimizedActions[0]?.page?.url || '',
      pages,
      flowSummary,
      validations,
      warnings,
      llmGuidance: {
        primaryGoal: 'Generate or update automation framework code by reusing existing project structure wherever possible.',
        locatorPreference: ['playwright getByRole/getByLabel/getByPlaceholder', 'data-testid/data-test/data-qa', 'stable css', 'xpath only as fallback'],
        codeGenerationRules: [
          'Do not hardcode masked or dynamic values.',
          'Reuse existing page objects, steps, utility methods and assertions before creating new ones.',
          'Create missing methods only when no equivalent method exists.',
          'Keep validation comments as assertion requirements.',
          'Avoid brittle nth-child and long xpath unless no stable locator exists.'
        ]
      },
      actions: optimizedActions,
      contextEstimate: estimateContextSize(optimizedActions)
    });

    payload.contextEstimate.totalJsonChars = JSON.stringify(payload).length;
    payload.contextEstimate.estimatedTokens = Math.ceil(payload.contextEstimate.totalJsonChars / 4);
    return payload;
  }

  function buildLlmPrompt(optimizedPayload) {
    return [
      'You are a senior Test Automation Architect.',
      'Use the following optimized UI recording to generate automation code.',
      '',
      'Rules:',
      '1. Reuse existing framework structure, page objects, step definitions and utility methods wherever possible.',
      '2. Prefer stable Playwright locators: getByRole, getByLabel, getByPlaceholder and data-testid.',
      '3. Treat comments and validationType fields as assertion requirements.',
      '4. Do not hardcode masked, OTP, password, email, phone or dynamic values.',
      '5. Generate only missing code. Do not duplicate existing reusable methods.',
      '6. Keep xpath as last fallback only.',
      '',
      'Optimized recording JSON:',
      JSON.stringify(optimizedPayload, null, 2)
    ].join('\n');
  }

  function removeNoiseAndMerge(actions) {
    const result = [];
    for (const action of actions) {
      const normalized = { ...action };
      const key = actionKey(normalized);
      const prev = result[result.length - 1];
      const prevKey = prev ? actionKey(prev) : '';

      if (shouldDropAction(normalized)) continue;

      if (prev && key === prevKey) {
        if (INPUT_ACTIONS.has(normalized.action)) {
          result[result.length - 1] = mergeActions(prev, normalized);
          continue;
        }
        if (isNearDuplicate(prev, normalized)) continue;
      }

      if (prev && prev.action === 'click' && normalized.action === 'keyboard' && normalized.key === 'Tab' && key === prevKey) {
        continue;
      }

      result.push(normalized);
    }
    return result.map((a, idx) => ({ ...a, step: idx + 1 }));
  }

  function optimizeAction(action, step) {
    const bestLocator = selectBestLocator(action.locatorCandidates || []);
    const element = compactElement(action.element || {});
    const validation = classifyValidation(action.validationType, action.comment, action);
    const pageObjectHint = inferPageObjectHint(action);
    const methodHint = inferMethodHint(action, element, validation);
    const gherkinHint = inferGherkinHint(action, element, validation);

    return compactObject({
      step,
      action: action.action,
      intent: normalize(action.intent || inferIntent(action, element)).slice(0, 140),
      page: compactObject({
        url: action.page?.url,
        title: action.page?.title,
        pageObjectHint
      }),
      element,
      bestLocator,
      alternateLocators: compactLocators(action.locatorCandidates || [], bestLocator).slice(0, 3),
      valueHint: sanitizeValue(action.valueHint),
      checked: action.checked,
      key: action.key,
      validation,
      comment: normalize(action.comment || ''),
      automationHints: compactObject({
        pageObject: pageObjectHint,
        suggestedMethodName: methodHint,
        gherkinStep: gherkinHint,
        confidence: bestLocator?.confidence || 'low',
        needsManualReview: !bestLocator || bestLocator.score < 70 || isBrittleLocator(bestLocator.value)
      })
    });
  }

  function compactElement(el) {
    return compactObject({
      tag: el.tag,
      role: el.role,
      type: el.type,
      label: normalize(el.label).slice(0, 90),
      text: normalize(el.text).slice(0, 90),
      placeholder: normalize(el.placeholder).slice(0, 90),
      ariaLabel: normalize(el.ariaLabel).slice(0, 90),
      name: normalize(el.name).slice(0, 90),
      id: isStableToken(el.id) ? el.id : undefined,
      testId: el.testId,
      context: buildCompactContext(el)
    });
  }

  function buildCompactContext(el) {
    const parts = [];
    ['label', 'placeholder', 'ariaLabel', 'text', 'name', 'id'].forEach(k => {
      if (el[k]) parts.push(`${k}:${normalize(el[k]).slice(0, 50)}`);
    });
    return parts.length ? parts.slice(0, 3).join(' | ') : undefined;
  }

  function selectBestLocator(candidates) {
    const filtered = (candidates || [])
      .filter(c => c?.value)
      .map(c => ({ ...c, score: Number(c.score || 0) - locatorPenalty(c.value) }))
      .sort((a, b) => b.score - a.score);
    const best = filtered[0];
    if (!best) return undefined;
    return {
      type: best.type,
      value: best.value,
      score: Math.max(0, Math.min(100, Math.round(best.score))),
      confidence: best.score >= 90 ? 'high' : best.score >= 70 ? 'medium' : 'low'
    };
  }

  function compactLocators(candidates, bestLocator) {
    return (candidates || [])
      .filter(c => c?.value && c.value !== bestLocator?.value)
      .map(c => ({ type: c.type, value: c.value, score: c.score }))
      .sort((a, b) => Number(b.score || 0) - Number(a.score || 0));
  }

  function classifyValidation(validationType, comment, action) {
    const text = normalize(comment || '').toLowerCase();
    const type = validationType || 'comment';
    let assertion = type;
    if (type === 'comment') {
      if (/url|page|redirect|land/.test(text)) assertion = 'assert-url-or-page';
      else if (/visible|display|shown|see/.test(text)) assertion = 'assert-visible';
      else if (/text|message|label|toast|error/.test(text)) assertion = 'assert-text';
      else if (/count|number|row|record|list/.test(text)) assertion = 'assert-count';
      else if (/skip|dynamic|otp|do not hardcode|dont hardcode/.test(text)) assertion = 'skip-hardcoded';
      else assertion = 'comment';
    }
    return compactObject({
      required: Boolean(comment || type !== 'comment'),
      type: assertion,
      expected: normalize(comment || ''),
      targetLocator: action.locatorCandidates?.[0]?.value
    });
  }

  function inferPageObjectHint(action) {
    const title = normalize(action.page?.title || '');
    const url = action.page?.url || '';
    const path = safeUrlPath(url);
    const fromTitle = title.split(/[|\-–—]/)[0].trim();
    const source = fromTitle || path.split('/').filter(Boolean).pop() || 'Page';
    return toPascalCase(source || 'Page') + 'Page';
  }

  function inferMethodHint(action, element, validation) {
    if (validation?.type && validation.type !== 'comment' && validation.type !== 'skip-hardcoded') {
      return 'verify' + toPascalCase(validation.expected || element.label || element.text || 'ExpectedResult');
    }
    const name = element.label || element.text || element.placeholder || element.name || element.id || element.tag || 'Element';
    const prefix = action.action === 'click' ? 'click' : action.action === 'input' ? 'enter' : action.action === 'select' ? 'select' : action.action;
    return prefix + toPascalCase(name);
  }

  function inferGherkinHint(action, element, validation) {
    const name = element.label || element.text || element.placeholder || element.name || element.tag || 'element';
    if (validation?.required && validation.type !== 'skip-hardcoded') {
      return `Then verify ${validation.expected || name}`;
    }
    if (action.action === 'click') return `When I click ${name}`;
    if (action.action === 'input') return `When I enter value in ${name}`;
    if (action.action === 'select') return `When I select value from ${name}`;
    if (action.action === 'check') return `When I check ${name}`;
    return `When I perform ${action.action} on ${name}`;
  }

  function buildPagesSummary(actions) {
    const map = new Map();
    for (const a of actions) {
      const key = a.page?.url || a.page?.title || 'unknown';
      if (!map.has(key)) map.set(key, { url: a.page?.url, title: a.page?.title, pageObjectHint: a.page?.pageObjectHint, actionCount: 0 });
      map.get(key).actionCount++;
    }
    return Array.from(map.values()).slice(0, 20);
  }

  function buildFlowSummary(actions, pages) {
    const verbs = actions.map(a => `${a.action}:${a.element?.label || a.element?.text || a.element?.name || a.element?.tag}`).slice(0, 30);
    return {
      pageCount: pages.length,
      actionCount: actions.length,
      primaryPageObject: pages[0]?.pageObjectHint,
      flow: verbs.join(' → ')
    };
  }

  function buildWarnings(actions, rawCount, cleanedCount) {
    const warnings = [];
    if (rawCount !== cleanedCount) warnings.push(`${rawCount - cleanedCount} noisy/duplicate actions were removed.`);
    actions.filter(a => a.automationHints?.needsManualReview).slice(0, 10).forEach(a => {
      warnings.push(`Step ${a.step} locator may need review: ${a.bestLocator?.value || 'no locator'}`);
    });
    if (actions.length > 200) warnings.push('Recording has more than 200 actions. Consider splitting into multiple test flows.');
    return warnings;
  }

  function estimateContextSize(actions) {
    const actionChars = JSON.stringify(actions).length;
    return {
      actionJsonChars: actionChars,
      actionEstimatedTokens: Math.ceil(actionChars / 4),
      recommendation: actionChars > 50000 ? 'Split flow before sending to LLM.' : 'Safe for most LLM context windows.'
    };
  }

  function shouldDropAction(action) {
    const tag = action.element?.tag;
    const text = normalize(action.element?.text || action.element?.label || '');
    if (action.action === 'click' && tag === 'body') return true;
    if (action.action === 'keyboard' && !['Enter', 'Tab'].includes(action.key)) return true;
    if (/astra recording/i.test(text)) return true;
    return false;
  }

  function mergeActions(prev, next) {
    return {
      ...prev,
      ...next,
      step: prev.step,
      comment: next.comment || prev.comment || '',
      validationType: next.validationType || prev.validationType || 'comment'
    };
  }

  function isNearDuplicate(prev, next) {
    const p = Date.parse(prev.capturedAt || '') || 0;
    const n = Date.parse(next.capturedAt || '') || 0;
    return !p || !n || Math.abs(n - p) < 1200;
  }

  function actionKey(action) {
    const locator = action.locatorCandidates?.[0]?.value || action.element?.testId || action.element?.id || action.element?.name || action.element?.label || action.element?.text || '';
    return `${action.action}:${locator}`;
  }

  function locatorPenalty(value) {
    let penalty = 0;
    if (/:nth-of-type|nth-child/.test(value)) penalty += 15;
    if (/\/html\/body/.test(value)) penalty += 20;
    if (value.length > 140) penalty += 10;
    return penalty;
  }

  function isBrittleLocator(value) {
    return !value || /nth-of-type|nth-child|\/html\/body/.test(value) || value.length > 160;
  }

  function sanitizeValue(value) {
    const v = normalize(value || '');
    if (!v) return undefined;
    if (/^<.*>$/.test(v)) return v;
    if (/\d{4,}/.test(v)) return '<masked-dynamic-value>';
    if (/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(v)) return '<email>';
    return v.slice(0, 80);
  }

  function inferIntent(action, element) {
    const name = element.label || element.text || element.placeholder || element.name || element.tag || 'element';
    if (action.action === 'click') return `Click ${name}`;
    if (action.action === 'input') return `Enter value in ${name}`;
    return `${action.action} on ${name}`;
  }

  function safeUrlPath(url) {
    try { return new URL(url).pathname || ''; } catch { return ''; }
  }

  function toPascalCase(value) {
    return normalize(value || 'Page')
      .replace(/[^a-zA-Z0-9]+/g, ' ')
      .split(' ')
      .filter(Boolean)
      .slice(0, 6)
      .map(w => w.charAt(0).toUpperCase() + w.slice(1))
      .join('') || 'Page';
  }

  function isStableToken(token) {
    if (!token || token.length > 60) return false;
    if (/^[a-f0-9]{8,}$/i.test(token)) return false;
    if (/\d{5,}/.test(token)) return false;
    return true;
  }

  function normalize(value) {
    return String(value || '').replace(/\s+/g, ' ').trim();
  }

  function compactObject(obj) {
    return Object.fromEntries(Object.entries(obj).filter(([, v]) => v !== undefined && v !== null && v !== '' && !(Array.isArray(v) && v.length === 0) && !(typeof v === 'object' && !Array.isArray(v) && Object.keys(v).length === 0)));
  }

  window.ASTRA_OPTIMIZER = {
    buildOptimizedPayload,
    buildLlmPrompt
  };
})();
