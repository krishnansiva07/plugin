(() => {
  const ASTRA_ATTRS = ['data-testid', 'data-test', 'data-qa', 'data-cy', 'aria-label', 'name', 'id', 'placeholder', 'type', 'role', 'title'];
  let recording = false;
  let lastInputTimer = null;
  let lastInputPayload = null;

  chrome.storage.local.get(['astraRecording']).then(state => {
    recording = Boolean(state.astraRecording);
    drawRecordingBadge(recording);
  });

  chrome.runtime.onMessage.addListener((message) => {
    if (message?.type === 'ASTRA_RECORDING_STATUS') {
      recording = Boolean(message.recording);
      drawRecordingBadge(recording);
    }
  });

  document.addEventListener('click', event => {
    if (!recording) return;
    const target = getActionableElement(event.target);
    if (!target || shouldIgnore(target)) return;

    captureAction('click', target, {
      mouse: { x: event.clientX, y: event.clientY }
    });
  }, true);

  document.addEventListener('change', event => {
    if (!recording) return;
    const target = event.target;
    if (!target || shouldIgnore(target)) return;

    if (target.matches('select,input[type="checkbox"],input[type="radio"],input[type="file"]')) {
      captureAction(resolveInputAction(target), target, {
        valueHint: getSafeValueHint(target),
        checked: target.checked === undefined ? undefined : Boolean(target.checked)
      });
    }
  }, true);

  document.addEventListener('input', event => {
    if (!recording) return;
    const target = event.target;
    if (!target || shouldIgnore(target)) return;
    if (!target.matches('input,textarea,[contenteditable="true"]')) return;

    lastInputPayload = { action: resolveInputAction(target), target };
    clearTimeout(lastInputTimer);
    lastInputTimer = setTimeout(() => {
      if (!lastInputPayload) return;
      captureAction(lastInputPayload.action, lastInputPayload.target, {
        valueHint: getSafeValueHint(lastInputPayload.target)
      });
      lastInputPayload = null;
    }, 700);
  }, true);

  document.addEventListener('keydown', event => {
    if (!recording) return;
    if (!['Enter', 'Tab'].includes(event.key)) return;
    const target = getActionableElement(event.target);
    if (!target || shouldIgnore(target)) return;
    captureAction('keyboard', target, { key: event.key });
  }, true);

  function captureAction(action, element, extra = {}) {
    const payload = buildPayload(action, element, extra);
    chrome.runtime.sendMessage({ type: 'ASTRA_ACTION_CAPTURED', payload }).catch(() => undefined);
  }

  function buildPayload(action, element, extra) {
    return {
      action,
      page: {
        url: location.href,
        title: document.title
      },
      intent: inferIntent(action, element),
      element: describeElement(element),
      parentContext: getParentContext(element),
      nearbyContext: getNearbyContext(element),
      locatorCandidates: buildLocatorCandidates(element),
      ...extra
    };
  }

  function describeElement(el) {
    const rect = el.getBoundingClientRect();
    return compactObject({
      tag: el.tagName?.toLowerCase(),
      role: el.getAttribute('role') || inferRole(el),
      type: el.getAttribute('type'),
      text: normalizeText(getElementText(el)).slice(0, 120),
      label: getAssociatedLabel(el),
      placeholder: el.getAttribute('placeholder'),
      ariaLabel: el.getAttribute('aria-label'),
      name: el.getAttribute('name'),
      id: el.id || undefined,
      testId: getFirstAttr(el, ['data-testid', 'data-test', 'data-qa', 'data-cy']),
      cssPath: buildCssPath(el),
      xpath: buildXPath(el),
      visible: isVisible(el),
      bounds: {
        x: Math.round(rect.x),
        y: Math.round(rect.y),
        w: Math.round(rect.width),
        h: Math.round(rect.height)
      }
    });
  }

  function getParentContext(el) {
    const parents = [];
    let current = el.parentElement;
    let depth = 0;
    while (current && current !== document.body && depth < 3) {
      if (isMeaningfulContainer(current)) {
        parents.push(compactObject({
          tag: current.tagName.toLowerCase(),
          role: current.getAttribute('role'),
          id: current.id || undefined,
          classHint: stableClassHint(current),
          textHint: normalizeText(current.innerText || current.textContent || '').slice(0, 180),
          locatorHint: buildBestCssHint(current)
        }));
        depth++;
      }
      current = current.parentElement;
    }
    return parents;
  }

  function getNearbyContext(el) {
    const parent = el.parentElement;
    if (!parent) return {};
    const labels = Array.from(parent.querySelectorAll('label,span,p,div,strong'))
      .filter(n => n !== el && isVisible(n))
      .map(n => normalizeText(n.innerText || n.textContent || ''))
      .filter(Boolean)
      .filter(t => t.length <= 120)
      .slice(0, 5);

    return compactObject({
      labels,
      formTitle: findClosestHeading(el)
    });
  }

  function buildLocatorCandidates(el) {
    const candidates = [];
    const testId = getFirstAttr(el, ['data-testid', 'data-test', 'data-qa', 'data-cy']);
    if (testId) candidates.push({ type: 'playwright', value: `locator('[data-testid="${escapeQuotes(testId)}"]')`, score: 100 });

    const role = el.getAttribute('role') || inferRole(el);
    const name = getAccessibleName(el);
    if (role && name) candidates.push({ type: 'playwright', value: `getByRole('${role}', { name: '${escapeQuotes(name)}' })`, score: 95 });

    const label = getAssociatedLabel(el);
    if (label) candidates.push({ type: 'playwright', value: `getByLabel('${escapeQuotes(label)}')`, score: 90 });

    const placeholder = el.getAttribute('placeholder');
    if (placeholder) candidates.push({ type: 'playwright', value: `getByPlaceholder('${escapeQuotes(placeholder)}')`, score: 85 });

    const text = normalizeText(getElementText(el));
    if (text && text.length <= 60 && ['button', 'a'].includes(el.tagName.toLowerCase())) {
      candidates.push({ type: 'playwright', value: `getByText('${escapeQuotes(text)}')`, score: 80 });
    }

    const nameAttr = el.getAttribute('name');
    if (nameAttr) candidates.push({ type: 'css', value: `${el.tagName.toLowerCase()}[name="${cssEscape(nameAttr)}"]`, score: 75 });

    if (el.id && isStableToken(el.id)) candidates.push({ type: 'css', value: `#${cssEscape(el.id)}`, score: 70 });

    const cssPath = buildCssPath(el);
    if (cssPath) candidates.push({ type: 'css', value: cssPath, score: 55 });

    const xpath = buildXPath(el);
    if (xpath) candidates.push({ type: 'xpath', value: xpath, score: 40 });

    return dedupe(candidates).slice(0, 6);
  }

  function getActionableElement(node) {
    if (!node || node.nodeType !== Node.ELEMENT_NODE) return null;
    return node.closest('button,a,input,textarea,select,[role="button"],[role="link"],[contenteditable="true"],label,[onclick]') || node;
  }

  function shouldIgnore(el) {
    if (!el || !isVisible(el)) return true;
    if (el.closest('#astra-ui-recorder-badge')) return true;
    if (location.protocol === 'chrome:') return true;
    return false;
  }

  function resolveInputAction(el) {
    const tag = el.tagName.toLowerCase();
    const type = (el.getAttribute('type') || '').toLowerCase();
    if (tag === 'select') return 'select';
    if (type === 'checkbox') return 'check';
    if (type === 'radio') return 'radio';
    if (type === 'file') return 'upload';
    return 'input';
  }

  function getSafeValueHint(el) {
    const type = (el.getAttribute('type') || '').toLowerCase();
    const value = el.value || el.innerText || '';
    if (['password', 'email', 'tel'].includes(type)) return `<${type}>`;
    if (value.length > 40) return `${value.slice(0, 20)}...`;
    if (/\d{4,}/.test(value)) return '<masked-dynamic-value>';
    return value;
  }

  function getAssociatedLabel(el) {
    if (el.id) {
      const label = document.querySelector(`label[for="${cssEscape(el.id)}"]`);
      if (label) return normalizeText(label.innerText || label.textContent || '');
    }
    const wrapped = el.closest('label');
    if (wrapped) return normalizeText(wrapped.innerText || wrapped.textContent || '');
    const aria = el.getAttribute('aria-label');
    if (aria) return normalizeText(aria);
    const labelledBy = el.getAttribute('aria-labelledby');
    if (labelledBy) {
      return labelledBy.split(/\s+/).map(id => document.getElementById(id)?.innerText || '').join(' ').trim();
    }
    return undefined;
  }

  function getAccessibleName(el) {
    return getAssociatedLabel(el) || el.getAttribute('title') || el.getAttribute('placeholder') || normalizeText(getElementText(el));
  }

  function inferRole(el) {
    const tag = el.tagName.toLowerCase();
    const type = (el.getAttribute('type') || '').toLowerCase();
    if (tag === 'button' || type === 'button' || type === 'submit') return 'button';
    if (tag === 'a') return 'link';
    if (tag === 'select') return 'combobox';
    if (tag === 'textarea') return 'textbox';
    if (tag === 'input') {
      if (['checkbox'].includes(type)) return 'checkbox';
      if (['radio'].includes(type)) return 'radio';
      return 'textbox';
    }
    return undefined;
  }

  function inferIntent(action, el) {
    const name = getAccessibleName(el) || getElementText(el) || el.tagName.toLowerCase();
    if (action === 'click') return `Click ${name}`.slice(0, 120);
    if (action === 'input') return `Enter value in ${name}`.slice(0, 120);
    if (action === 'select') return `Select option in ${name}`.slice(0, 120);
    return `${action} on ${name}`.slice(0, 120);
  }

  function isMeaningfulContainer(el) {
    const tag = el.tagName.toLowerCase();
    return ['form', 'section', 'article', 'main', 'dialog', 'fieldset', 'table'].includes(tag) ||
      ['dialog', 'form', 'region', 'table', 'grid'].includes(el.getAttribute('role')) ||
      Boolean(el.id) || Boolean(getFirstAttr(el, ['data-testid', 'data-test', 'data-qa']));
  }

  function buildCssPath(el) {
    if (!el || el.nodeType !== Node.ELEMENT_NODE) return '';
    if (el.id && isStableToken(el.id)) return `#${cssEscape(el.id)}`;
    const parts = [];
    let current = el;
    while (current && current !== document.body && parts.length < 5) {
      let part = current.tagName.toLowerCase();
      const testId = getFirstAttr(current, ['data-testid', 'data-test', 'data-qa', 'data-cy']);
      if (testId) {
        part += `[data-testid="${cssEscape(testId)}"]`;
        parts.unshift(part);
        break;
      }
      const name = current.getAttribute('name');
      if (name) part += `[name="${cssEscape(name)}"]`;
      else {
        const cls = stableClassHint(current);
        if (cls) part += `.${cssEscape(cls)}`;
        const siblings = Array.from(current.parentElement?.children || []).filter(s => s.tagName === current.tagName);
        if (siblings.length > 1) part += `:nth-of-type(${siblings.indexOf(current) + 1})`;
      }
      parts.unshift(part);
      current = current.parentElement;
    }
    return parts.join(' > ');
  }

  function buildBestCssHint(el) {
    const testId = getFirstAttr(el, ['data-testid', 'data-test', 'data-qa', 'data-cy']);
    if (testId) return `[data-testid="${cssEscape(testId)}"]`;
    if (el.id && isStableToken(el.id)) return `#${cssEscape(el.id)}`;
    const cls = stableClassHint(el);
    return cls ? `${el.tagName.toLowerCase()}.${cssEscape(cls)}` : el.tagName.toLowerCase();
  }

  function buildXPath(el) {
    if (el.id && isStableToken(el.id)) return `//*[@id="${escapeQuotes(el.id)}"]`;
    const parts = [];
    let current = el;
    while (current && current.nodeType === Node.ELEMENT_NODE && current !== document.body) {
      const tag = current.tagName.toLowerCase();
      const siblings = Array.from(current.parentElement?.children || []).filter(s => s.tagName === current.tagName);
      const index = siblings.length > 1 ? `[${siblings.indexOf(current) + 1}]` : '';
      parts.unshift(`${tag}${index}`);
      current = current.parentElement;
    }
    return `/html/body/${parts.join('/')}`;
  }

  function findClosestHeading(el) {
    let current = el.parentElement;
    for (let i = 0; current && i < 4; i++, current = current.parentElement) {
      const heading = current.querySelector('h1,h2,h3,h4,legend,[role="heading"]');
      if (heading) return normalizeText(heading.innerText || heading.textContent || '').slice(0, 120);
    }
    return undefined;
  }

  function getElementText(el) {
    if (el.matches('input,textarea,select')) return '';
    return el.innerText || el.textContent || '';
  }

  function getFirstAttr(el, attrs) {
    for (const attr of attrs) {
      const value = el.getAttribute(attr);
      if (value) return value;
    }
    return undefined;
  }

  function stableClassHint(el) {
    return Array.from(el.classList || []).find(isStableToken);
  }

  function isStableToken(token) {
    if (!token || token.length > 60) return false;
    if (/^[a-f0-9]{8,}$/i.test(token)) return false;
    if (/\d{5,}/.test(token)) return false;
    return true;
  }

  function isVisible(el) {
    const style = window.getComputedStyle(el);
    const rect = el.getBoundingClientRect();
    return style && style.display !== 'none' && style.visibility !== 'hidden' && rect.width > 0 && rect.height > 0;
  }

  function normalizeText(text) {
    return String(text || '').replace(/\s+/g, ' ').trim();
  }

  function compactObject(obj) {
    return Object.fromEntries(Object.entries(obj).filter(([, v]) => v !== undefined && v !== null && v !== '' && !(Array.isArray(v) && v.length === 0)));
  }

  function dedupe(items) {
    const seen = new Set();
    return items.filter(item => {
      const key = `${item.type}:${item.value}`;
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    });
  }

  function cssEscape(value) {
    if (window.CSS?.escape) return CSS.escape(value);
    return String(value).replace(/([ #;?%&,.+*~':"!^$[\]()=>|/@])/g, '\\$1');
  }

  function escapeQuotes(value) {
    return String(value || '').replace(/\\/g, '\\\\').replace(/'/g, "\\'").replace(/"/g, '\\"');
  }

  function drawRecordingBadge(show) {
    let badge = document.getElementById('astra-ui-recorder-badge');
    if (!show) {
      badge?.remove();
      return;
    }
    if (badge) return;
    badge = document.createElement('div');
    badge.id = 'astra-ui-recorder-badge';
    badge.textContent = '● Astra Recording';
    badge.style.cssText = [
      'position:fixed', 'z-index:2147483647', 'right:16px', 'bottom:16px',
      'background:#111827', 'color:#fff', 'font:12px Arial,sans-serif',
      'padding:8px 10px', 'border-radius:999px', 'box-shadow:0 4px 12px rgba(0,0,0,.25)',
      'pointer-events:none'
    ].join(';');
    document.documentElement.appendChild(badge);
  }
})();
