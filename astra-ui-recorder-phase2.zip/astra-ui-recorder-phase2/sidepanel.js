let selectedStep = null;
let currentState = { astraRecording: false, astraActions: [], astraSession: null };

const els = {
  statusPill: document.getElementById('statusPill'),
  testName: document.getElementById('testName'),
  startBtn: document.getElementById('startBtn'),
  stopBtn: document.getElementById('stopBtn'),
  clearBtn: document.getElementById('clearBtn'),
  lastAction: document.getElementById('lastAction'),
  validationType: document.getElementById('validationType'),
  commentBox: document.getElementById('commentBox'),
  saveCommentBtn: document.getElementById('saveCommentBtn'),
  steps: document.getElementById('steps'),
  stepCount: document.getElementById('stepCount'),
  copyBtn: document.getElementById('copyBtn'),
  downloadBtn: document.getElementById('downloadBtn'),
  copyPromptBtn: document.getElementById('copyPromptBtn'),
  jsonPreview: document.getElementById('jsonPreview'),
  optimizerStats: document.getElementById('optimizerStats'),
  warnings: document.getElementById('warnings')
};

init();

function init() {
  bindEvents();
  refresh();
  chrome.runtime.onMessage.addListener((message) => {
    if (message?.type === 'ASTRA_REFRESH_PANEL') refresh();
  });
}

function bindEvents() {
  els.startBtn.addEventListener('click', async () => {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    const testName = els.testName.value.trim() || 'Recorded UI Flow';
    await chrome.runtime.sendMessage({ type: 'ASTRA_START', startUrl: tab?.url || '', testName });
    await refresh();
  });

  els.stopBtn.addEventListener('click', async () => {
    await chrome.runtime.sendMessage({ type: 'ASTRA_STOP' });
    await refresh();
  });

  els.clearBtn.addEventListener('click', async () => {
    if (!confirm('Clear current recording?')) return;
    await chrome.runtime.sendMessage({ type: 'ASTRA_CLEAR' });
    selectedStep = null;
    els.commentBox.value = '';
    await refresh();
  });

  els.saveCommentBtn.addEventListener('click', async () => {
    if (!selectedStep) return alert('Select a recorded step first.');
    await chrome.runtime.sendMessage({
      type: 'ASTRA_UPDATE_COMMENT',
      step: selectedStep,
      comment: els.commentBox.value.trim(),
      validationType: els.validationType.value
    });
    await refresh();
  });

  els.copyBtn.addEventListener('click', async () => {
    const json = JSON.stringify(getSelectedExportPayload(), null, 2);
    await navigator.clipboard.writeText(json);
    toast('Copied selected JSON');
  });

  els.downloadBtn.addEventListener('click', () => {
    const json = JSON.stringify(getSelectedExportPayload(), null, 2);
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    const mode = getExportMode();
    a.href = url;
    a.download = `${slugify(currentState.astraSession?.testName || 'astra-recording')}-${mode}.json`;
    a.click();
    URL.revokeObjectURL(url);
  });

  els.copyPromptBtn.addEventListener('click', async () => {
    const optimized = buildOptimizedExportPayload();
    const prompt = window.ASTRA_OPTIMIZER.buildLlmPrompt(optimized);
    await navigator.clipboard.writeText(prompt);
    toast('Copied LLM prompt + optimized JSON');
  });

  document.querySelectorAll('input[name="exportMode"]').forEach(radio => radio.addEventListener('change', render));
}

async function refresh() {
  const response = await chrome.runtime.sendMessage({ type: 'ASTRA_GET_STATE' });
  currentState = response?.state || currentState;
  render();
}

function render() {
  const recording = Boolean(currentState.astraRecording);
  const actions = currentState.astraActions || [];

  els.statusPill.textContent = recording ? 'Recording' : 'Idle';
  els.statusPill.className = `pill ${recording ? 'recording' : 'idle'}`;
  els.stepCount.textContent = String(actions.length);

  if (currentState.astraSession?.testName && !els.testName.value) {
    els.testName.value = currentState.astraSession.testName;
  }

  const last = actions[actions.length - 1];
  if (last) {
    selectedStep = selectedStep || last.step;
    els.lastAction.className = '';
    els.lastAction.innerHTML = renderActionCard(last, true);
  } else {
    els.lastAction.className = 'empty';
    els.lastAction.textContent = 'No action captured yet.';
  }

  els.steps.innerHTML = actions.length
    ? actions.map(action => renderStep(action)).join('')
    : '<div class="empty">Start recording and interact with the page.</div>';

  document.querySelectorAll('.step').forEach(node => {
    node.addEventListener('click', () => {
      selectedStep = Number(node.dataset.step);
      const action = actions.find(a => a.step === selectedStep);
      els.commentBox.value = action?.comment || '';
      els.validationType.value = action?.validationType || 'comment';
      render();
    });
  });

  const selected = actions.find(a => a.step === selectedStep);
  if (selected && document.activeElement !== els.commentBox) {
    els.commentBox.value = selected.comment || '';
    els.validationType.value = selected.validationType || 'comment';
  }

  renderOptimizerStats();
  els.jsonPreview.textContent = JSON.stringify(getSelectedExportPayload(), null, 2);
}

function renderStep(action) {
  const selected = action.step === selectedStep ? 'selected' : '';
  const comment = action.comment ? `<div class="comment">💬 ${escapeHtml(action.comment)}</div>` : '';
  return `
    <div class="step ${selected}" data-step="${action.step}">
      ${renderActionCard(action)}
      ${comment}
    </div>
  `;
}

function renderActionCard(action, large = false) {
  const best = action.locatorCandidates?.[0]?.value || action.element?.cssPath || '';
  const label = action.element?.label || action.element?.text || action.element?.placeholder || action.element?.ariaLabel || action.element?.name || action.element?.tag || 'element';
  return `
    <div class="action-card ${large ? 'large' : ''}">
      <div class="action-title"><b>#${action.step || ''}</b> ${escapeHtml(action.action)} → ${escapeHtml(label)}</div>
      <div class="muted">${escapeHtml(action.intent || '')}</div>
      <code>${escapeHtml(best)}</code>
    </div>
  `;
}

function buildExportPayload() {
  const actions = currentState.astraActions || [];
  return {
    schemaVersion: 'astra-ui-recorder.phase2.raw.v1',
    recordingMode: 'raw-compact',
    target: 'llm-automation-generation',
    testName: els.testName.value.trim() || currentState.astraSession?.testName || 'Recorded UI Flow',
    startedAt: currentState.astraSession?.startedAt,
    exportedAt: new Date().toISOString(),
    startUrl: currentState.astraSession?.startUrl || actions[0]?.page?.url || '',
    actionCount: actions.length,
    locatorStrategy: [
      'data-testid/data-test/data-qa',
      'role + accessible name',
      'label',
      'placeholder',
      'name/id',
      'stable css',
      'xpath fallback'
    ],
    actions: actions.map(a => ({
      step: a.step,
      action: a.action,
      intent: a.intent,
      page: a.page,
      valueHint: a.valueHint,
      key: a.key,
      checked: a.checked,
      element: a.element,
      parentContext: a.parentContext,
      nearbyContext: a.nearbyContext,
      locatorCandidates: a.locatorCandidates,
      capturedAt: a.capturedAt,
      validationType: a.validationType || 'comment',
      comment: a.comment || ''
    }))
  };
}

function buildOptimizedExportPayload() {
  return window.ASTRA_OPTIMIZER.buildOptimizedPayload(buildExportPayload(), { maxActions: 250 });
}

function getExportMode() {
  return document.querySelector('input[name="exportMode"]:checked')?.value || 'optimized';
}

function getSelectedExportPayload() {
  return getExportMode() === 'raw' ? buildExportPayload() : buildOptimizedExportPayload();
}

function renderOptimizerStats() {
  const optimized = buildOptimizedExportPayload();
  const rawCount = optimized.optimization?.rawActionCount || 0;
  const optCount = optimized.optimization?.optimizedActionCount || 0;
  const removed = optimized.optimization?.removedNoiseCount || 0;
  const tokens = optimized.contextEstimate?.estimatedTokens || 0;
  els.optimizerStats.innerHTML = `
    <div><b>${rawCount}</b><span>Raw</span></div>
    <div><b>${optCount}</b><span>Optimized</span></div>
    <div><b>${removed}</b><span>Removed</span></div>
    <div><b>${tokens}</b><span>Tokens</span></div>
  `;
  const warnings = optimized.warnings || [];
  if (!warnings.length) {
    els.warnings.className = 'warnings empty';
    els.warnings.textContent = 'No warnings yet.';
  } else {
    els.warnings.className = 'warnings';
    els.warnings.innerHTML = warnings.slice(0, 4).map(w => `<div>⚠ ${escapeHtml(w)}</div>`).join('');
  }
}

function escapeHtml(value) {
  return String(value || '').replace(/[&<>'"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' }[c]));
}

function slugify(value) {
  return String(value || 'recording').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '').slice(0, 80);
}

function toast(message) {
  const div = document.createElement('div');
  div.className = 'toast';
  div.textContent = message;
  document.body.appendChild(div);
  setTimeout(() => div.remove(), 1600);
}
