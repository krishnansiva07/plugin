chrome.runtime.onInstalled.addListener(async () => {
  await chrome.storage.local.set({
    astraRecording: false,
    astraActions: [],
    astraSession: null
  });

  if (chrome.sidePanel?.setPanelBehavior) {
    await chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true });
  }
});

chrome.action.onClicked.addListener(async (tab) => {
  try {
    if (chrome.sidePanel?.open && tab?.windowId) {
      await chrome.sidePanel.open({ windowId: tab.windowId });
    }
  } catch (err) {
    console.warn('Unable to open side panel:', err);
  }
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  (async () => {
    if (!message || !message.type) return sendResponse({ ok: false, error: 'Invalid message' });

    if (message.type === 'ASTRA_ACTION_CAPTURED') {
      const state = await chrome.storage.local.get(['astraRecording', 'astraActions']);
      if (!state.astraRecording) return sendResponse({ ok: true, skipped: true });

      const actions = Array.isArray(state.astraActions) ? state.astraActions : [];
      const nextAction = {
        ...message.payload,
        step: actions.length + 1,
        capturedAt: new Date().toISOString(),
        tab: {
          id: sender?.tab?.id,
          title: sender?.tab?.title,
          url: sender?.tab?.url
        },
        comment: ''
      };

      actions.push(nextAction);
      await chrome.storage.local.set({ astraActions: actions, astraLastAction: nextAction });
      await chrome.runtime.sendMessage({ type: 'ASTRA_REFRESH_PANEL' }).catch(() => undefined);
      return sendResponse({ ok: true, action: nextAction });
    }

    if (message.type === 'ASTRA_GET_STATE') {
      const state = await chrome.storage.local.get(['astraRecording', 'astraActions', 'astraSession', 'astraLastAction']);
      return sendResponse({ ok: true, state });
    }

    if (message.type === 'ASTRA_START') {
      const session = {
        id: `astra-${Date.now()}`,
        startedAt: new Date().toISOString(),
        startUrl: message.startUrl || '',
        testName: message.testName || 'Recorded UI Flow'
      };
      await chrome.storage.local.set({ astraRecording: true, astraActions: [], astraSession: session, astraLastAction: null });
      await broadcastToTabs({ type: 'ASTRA_RECORDING_STATUS', recording: true });
      return sendResponse({ ok: true, session });
    }

    if (message.type === 'ASTRA_STOP') {
      await chrome.storage.local.set({ astraRecording: false });
      await broadcastToTabs({ type: 'ASTRA_RECORDING_STATUS', recording: false });
      return sendResponse({ ok: true });
    }

    if (message.type === 'ASTRA_UPDATE_COMMENT') {
      const { step, comment, validationType } = message;
      const state = await chrome.storage.local.get(['astraActions']);
      const actions = Array.isArray(state.astraActions) ? state.astraActions : [];
      const idx = actions.findIndex(a => a.step === Number(step));
      if (idx >= 0) {
        actions[idx].comment = comment || '';
        actions[idx].validationType = validationType || 'comment';
        await chrome.storage.local.set({ astraActions: actions, astraLastAction: actions[idx] });
      }
      return sendResponse({ ok: true, actions });
    }

    if (message.type === 'ASTRA_CLEAR') {
      await chrome.storage.local.set({ astraActions: [], astraLastAction: null, astraRecording: false, astraSession: null });
      await broadcastToTabs({ type: 'ASTRA_RECORDING_STATUS', recording: false });
      return sendResponse({ ok: true });
    }

    return sendResponse({ ok: false, error: `Unknown message type: ${message.type}` });
  })();

  return true;
});

async function broadcastToTabs(payload) {
  const tabs = await chrome.tabs.query({});
  await Promise.allSettled(
    tabs
      .filter(t => t.id && t.url && /^https?:\/\//.test(t.url))
      .map(t => chrome.tabs.sendMessage(t.id, payload))
  );
}
