# ELIYA 52 — RC3 Hardening Source (Java 17)

Eliya is a local Java/Spring Boot workspace assistant for Chat, planned Agent execution, Terminal Agent sessions, code migration, testing, documentation and evidence-backed analysis. It works with a selected writable local workspace plus up to five separately named read-only references. The terminal reuses the **existing Agent planner, tool loop and verification** but skips **plan approval**. Ordinary Agent mode retains the original plan approval flow.

> **Release state:** tested source release candidate, **not production certified**. This package does not include a rebuilt JAR. The available Java 17 source-parser/offline smoke tests and JavaScript tests are documented below; a full Spring Boot Maven build, provider-connected execution, actual Windows terminal behavior, and browser end-to-end verification have **not** been completed in the build environment. Test first on disposable repositories.

## Requirements and installation

- Java **17** (project target), network or pre-provisioned Maven 3.9+ and Maven Central dependencies, modern Chrome for browser workflows.
- For restricted corporate machines, pre-populate the Maven dependency cache or build the JAR on an approved build machine. The included `mvnw` / `mvnw.cmd` bootstraps Maven when available; it is **not** an offline dependency bundle.
- Set application/provider settings through Eliya's Settings UI, and select/map a local workspace. Never embed API keys in a workspace prompt or Git branch name.

```bash
# Linux/macOS — from project root
./mvnw -Pfull-tests clean verify
java -jar target/eliya.jar

# Frontend tests, independent of Maven
node --check src/main/resources/static/app.js
node --test src/test/js/*.test.js
bash qa/eliya52-terminal-typecheck.sh
bash qa/eliya52-hardening/run.sh
# Optional Chromium smoke test with mocked APIs (Python Playwright + installed Chromium required):
python qa/eliya52-browser-ui-smoke.py

# Additional offline Java/safety/UI smoke suites
bash qa/offline-smoke/run.sh
bash qa/workspace-boundaries/run.sh
bash qa/agent-reliability/run.sh
bash qa/completion-report-smoke/run.sh
bash qa/plan-relevance/run.sh
bash qa/confluence-smoke/run.sh
bash qa/intelligence-smoke/run.sh
```

Windows: run `mvnw.cmd -Pfull-tests clean verify`, then `java -jar target\\eliya.jar`. Check `src/main/resources/application.properties` for environment-specific persistence and server configuration. This source package does not assert that it was tested with live Windows/PowerShell processes.

## Work modes

| Mode | Behavior |
| --- | --- |
| Chat | Fast analysis, MCP-backed research when explicitly requested, requirement comparisons, prompt and plan drafting. Chat does not automatically apply changes. |
| Agent | Existing planner, validation, user-reviewed plan approval, tool execution and verification. |
| Terminal | Separate agentic sessions, **same existing planner and tools**, auto-execution after planning without **plan approval**, live progress/output, stop, history, interactive clarification and planning-failure recovery. |

### Independent Terminal workspaces, tabs and models

**Launch Terminal** offers a separate local-workspace dropdown, per-session read-only references (up to five), and a model choice. Workspaces are discovered from previously mapped local projects; selecting one in Terminal does not change Chat's workspace. Each started session captures those identifiers and runs in a separate conversation.

**New tab** opens a fresh, unstarted task configuration. **Duplicate tab** copies the source session's workspace, references and model into a fresh *draft*; the new execution starts only when the user enters an instruction and clicks Launch. The running task, tool history and pending questions are **not copied**. **Fork context** additionally inserts a bounded summary of the previous request and answer for review/editing; this is **not** an exact model/tool checkpoint. Duplicating a browser tab is not the same action and does not duplicate a running Terminal.

Generated Chat instructions include **Execute in Terminal**. On the ordinary Agent plan-approval screen, **Execute in Terminal** saves any edited plan, then uses a distinct server-side `TRANSFER` decision to relinquish the original pending Agent approval before starting a separate Terminal. The destination consumes the exact transferred step texts without generating a second plan. It never resolves the original plan approval as `ONCE` or `RUN`. Workspace and reference selection are preserved from the current source Agent UI; authorized source-conversation uploads are copied to the destination conversation with new IDs and independent storage (limits: 30 files / 100 MB total / 25 MB per file). If that transfer fails, the Terminal reports a failure instead of silently ignoring the evidence.

Terminal uses a bounded worker pool (up to twelve active sessions). Tasks in the same **or overlapping parent/child canonical workspace paths** are serialized; separate nonoverlapping workspaces may execute concurrently. Pending runs are admitted asynchronously and do not occupy worker threads while waiting. Separate Git worktrees provide stronger file isolation. The in-process overlap scheduler prevents simultaneously active Terminal writers in parent/child roots. It is not a cross-process or external-editor filesystem lock; use Git worktrees for reliable isolation. The application uses the existing planner and Agent verification tools; it does not waive deletion approvals or filesystem permissions.


### Token usage for each Agent or Terminal activity

Eliya now shows a **Token usage by activity** table at the end of completed, failed or stopped
Agent and Terminal executions. The same information is stored with the run and available
again from its history. It groups model calls by planning, validation, recovery, execution
turn/step, subagent reviews and context compaction, with **input, output and total tokens**,
call counts, and a run-wide total. Model context estimates and compaction savings are not
represented as actual billed tokens.

The client reads provider-reported token usage from supported OpenAI-compatible completion
responses. Some providers do not return usage metrics. Eliya marks those calls **Not reported**;
reported totals are then lower bounds, *not* assertions that missing calls consumed zero tokens.
Cached tokens are a subset of reported input tokens, not an amount to add to the total.
Shell, Git and test tool invocations use no model tokens by themselves, although the model
may use tokens when preparing commands and interpreting their output. The per-activity ledger
survives application restart, subject to the normal run-history retention policy.

Verification: `bash qa/token-usage-smoke/run.sh` and `node --test src/test/js/token-usage.test.js`.
This release does not yet expose authoritative token metrics for plain Chat streaming or
arbitrary external MCP provider/model calls when those APIs omit usage details.

### Global live execution monitor

The header's **Execution Monitor** remains available from other Eliya screens, even if the Terminal dock is hidden. It displays active counts, waiting-input notifications, per-session status, planner phase, and verified-step counts/progress when available. Clicking an entry opens the session's detailed events/output. The monitor also notifies on transitions to completion/failure. Progress is **step accounting**, not an estimate of remaining wall-clock time. The Java application must remain running for background work; after restart, interrupted processes are reported as interrupted instead of falsely resumed.

### Multi-repository Git support

1. Map a workspace containing one or more local Git repositories (for example `workspace/frontend`, `workspace/backend`, `workspace/qa`).
2. Select **Terminal → Git repositories**. Eliya scans Git roots under the workspace, while pruning `.git`, dependency and build trees.
3. Choose the exact repository, enter a new branch name, then choose **Create branch** or **Create isolated worktree**.
4. **Create branch** creates the branch without changing the existing checkout; it does not automatically switch an active terminal or overwrite files. **Create isolated worktree** creates a fresh branch and checkout in `./data/terminal-worktrees` (customizable with `-Deliya.terminal.worktrees=...`) and maps it to a separate local project for the **next** Terminal launch. The original current checkout stays untouched.
5. Different worktree project IDs can execute concurrently. Agents targeting the exact same resolved root share a fair execution lane. Reference projects remain read-only.

Git is executed through `ProcessBuilder` with separate arguments, never by interpolating user-provided branch names into a shell command. Repository selection uses resolved paths and exact `git rev-parse --show-toplevel` verification. Invalid names, traversal, symbolic-link escapes and duplicate local branches are rejected. An already-existing branch must be selected or managed outside the create-branch flow. Git worktree integration requires the selected repository to have an initial commit and Git installed on the host. Cleanup/merge/rebase of completed worktrees is currently manual.

### Clarification during Terminal execution

When an Agent encounters a genuine unresolved requirement, it can call the `ask_user` tool with a question and meaningful options. Only the corresponding session waits. The Terminal UI displays the question, offers the model's choices (for example OK / Continue / Cancel) and allows optional details. The response is returned to the Agent's tool loop. **Cancel** cancels the affected run. The UI also shows an explicit correction/retry path if a plan fails validation before recorded workspace modifications; choosing Continue starts a linked new run, not an unsafe fake continuation of the old process.

**Plan approval is skipped only for Terminal**. Existing deletion protections, workspace boundaries and dedicated risky-operation safeguards are separate policies and are not bypassed by Terminal mode. A shell process runs under the local OS user's account; selecting a workspace is not equivalent to secure process sandboxing.

### RC3 reliability and usability additions

- **Immutable structured Chat artifact vault:** whenever an assistant message with `PROJECT_FILE_START`/`PROJECT_FILE_END` proposals is saved, copies are archived under `./data/assistant-artifacts` using an independent message-ID index and random storage names. **Saved files** restores previews even if the current UI content becomes unavailable. Preview is script-disabled for HTML and remains read-only; proposals never auto-write into a workspace. Bounds: 64 proposals / 1.5 MB each / 12 MB total per response.
- **Reliable conversation identity:** each Terminal reserves its actual database conversation ID before staging a transferred plan or copying uploads; the previous random-ID mismatch could prevent document-dependent execution from starting.
- **Nonblocking overlapping-root scheduling:** parent/child workspace paths share a single writer lane. Queued same-workspace sessions do not occupy all worker threads, leaving unrelated workspaces responsive. This protects only Eliya Terminal sessions within one Java process, not external editors or another Eliya JVM.
- **Agent/Skill Studio (initial implementation):** explicitly create compatible `.agents`, `.opencode` or `.claude` agent and skill definitions, in a selected workspace or nested repository. Names and paths are validated; existing definitions are never overwritten. Creation is not automatic execution. Advanced test/evaluation, version management and automatic delegation are pending.
- **Git review:** the selected repository can display `git status`, working diff statistics and staged diff statistics. This is read-only; merge/rebase/conflict resolution remains a separate action.
- **Cross-platform CI:** a Java 17 compilation/test matrix for Windows and macOS has been added to the GitHub Actions workflow (runs only in connected CI, not in this environment).

### Agents, skills and related conventions

Agent instructions and skills are discovered from compatible Eliya, OpenCode and Claude locations such as `AGENTS.md`, `CLAUDE.md`, `.agents/agents`, `.agents/skills`, `.opencode/agent(s)`, `.opencode/skill(s)`, `.claude/agents`, `.claude/skills` and related command/rule folders. Detection is **inventory / compatible format discovery**, not guaranteed CLI interoperability. Untrusted project instructions are not automatically granted permissions. Creating a code reviewer skill remains available through Agent or Terminal instructions and the existing file tools.

Eliya also contains the existing workspace indexing, hybrid retrieval, source-impact tracing, partial LSP integration, file rollback/checkpoints, saved task progress, large-task ledgers, subagent tools, Prompt Factory, Confluence Composer and artifact preview. HTML is previewed in a script-disabled sandboxed iframe. Files are not silently created solely because Chat displayed a proposed artifact: distinguish a generated proposal from an actual saved workspace file.

## Security and operations

- Agent write operations must respect the selected workspace and explicitly writable resources. Selected references are read-only. Workspace paths must be narrow project folders, not entire drives, home directories or operating-system roots.
- MCP activation is explicit; a user must enable MCP and request MCP access in their prompt. Existing MCP permission checks remain authoritative.
- Do not use untrusted project prompts to request shell execution in privileged environments. Git commands and shell tools execute with the privileges of the local application process.
- Terminal session history, including session model identifiers (but not the model API key), is persisted under `./data/terminal-sessions`, agent runs under `./data/agent-runs` (override with documented Java properties where supported). Source snapshots/checkpoints and generated artifacts may use additional data subdirectories. Protect this local data and keep it out of your Git repositories.
- Concurrent sessions modifying **different repository worktrees** are safe from direct same-file overwrites by directory isolation. There is no cross-process global filesystem lock or transactional Git merge in this release.
- The model/provider API key is not included in saved Terminal session snapshots; sensitive data can still appear in user prompts or tool output, so handle session logs appropriately.

## Validation and release gates

| Gate | Result in this environment |
| --- | --- |
| `node --check` JavaScript source | Passed |
| JavaScript regression tests | **46 passed, zero failed** |
| Java 17 compiler parser of all 111 main source files | Passed **syntax only** |
| Java 17 standalone integration: multi-repository Git, branch/worktree/review, Studio definitions, artifact archive and security rejection | Passed with real disposable Git repositories and minimal external dependency stubs |
| Java 17 `--release 17` typecheck for Terminal Controller/Session/Discovery/Approval | Passed with dependency-compatible stubs; not a full project build |
| Approval handoff smoke: correct plan-only decision, wrong-run rejection, double-execution prevention | Passed |
| Chromium Browser UI: workspace, references, launch, duplicate, fork, monitor, Studio, Git review, saved artifacts and Agent handoff | Passed with **mocked backend APIs**; does not establish live Spring Boot integration |
| Existing offline, workspace boundaries, agent reliability, completion report, plan relevance, Confluence, intelligence smoke | Passed |
| Full Maven compile and JUnit execution | **Not verified**; dependencies unavailable in this environment |
| Live Java 17 Spring Boot runtime, provider/model tool calls, multi-hour execution, actual Windows terminal | **Not verified** |
| Penetration testing, concurrent multi-process isolation and production certification | **Not performed** |

To release to production: run `mvnw.cmd -Pfull-tests clean verify` (or Unix equivalent) on a dependency-enabled Java 17 machine; start the JAR; verify Chat/Agent/Terminal on Chrome and Windows PowerShell; exercise deletion approvals and timeout/rollback; confirm multiple terminals with separate Git worktrees, prompt handoff, clarification and cancellation, and saved artifact previews; inspect the output; do not put unvalidated builds against production code.

## Features not yet certified or incomplete

- Full production certification still requires building **the actual Java/Spring Boot application**, Windows Java 17/Chrome/browser testing and real provider execution. Tests with stubs and mocked HTTP responses cannot replace these gates.
- A globally non-blocking Chat view while the original Agent SSE stream is awaiting or finishing its approval handoff; Terminal itself is background-managed, but the original Chat composer may remain temporarily busy until that stream closes.
- True PTY/ConPTY interactive shell emulation (the existing `bash`/`process_*` tools are command/process-oriented, not a full TTY).
- Unattended recovery of previously running OS processes after application restart and exact idempotent replay of arbitrary steps.
- Complete OpenCode/Claude command/hook compatibility, advanced Skill Studio evaluation/versioning, coordinated multi-agent teams, configurable lifecycle hooks and requirements evidence dashboard. Studio creation/discovery alone is not complete feature parity.
- Automatic Git worktree cleanup, safe conflict-resolution UI and Git merges into the original branch.
- Full capture of every possible free-form/generated attachment remains incomplete: immutable structured PROJECT_FILE Chat proposals are now archived server-side per saved assistant message, with a Saved files/Preview UI. Proposals without structured markers continue using persisted conversation text, not the standalone artifact archive.
- Formal production load/security certification and comparable benchmarks against OpenCode/Claude Code.

These areas remain explicit roadmap requirements; this README avoids describing them as validated or finished.


## RC3 token-report compilation correction (24 October 2026)

The subagent token accounting call in `AgentService.runSubagent` now passes the
existing `parentStep` parameter instead of the undeclared `step` variable.
Read-only completion-critic usage is classified as `Execution review` rather
than `Subagent execution`. Run `bash qa/token-usage-smoke/run.sh` to check both
accounting semantics and the regression guard, and use `./mvnw clean package`
for the full dependency-resolved build on a machine with Maven Central access.
Offline test passes do not substitute for a complete Spring Boot compilation.
