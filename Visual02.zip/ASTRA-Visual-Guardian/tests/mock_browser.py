#!/usr/bin/env python3
"""Test-only CDP fixture. Does not emulate Chromium rendering or security policy."""
import sys,json,os,io,base64,re,urllib.request,urllib.parse,threading
from pathlib import Path
from http import HTTPStatus
from websockets.sync.server import serve
from PIL import Image,ImageDraw
profile=Path(next(x.split('=',1)[1] for x in sys.argv if x.startswith('--user-data-dir=')))
url='about:blank';body='';panel=False;view=False;width=800;height=600;closed=False;port=0;stale_once=True

def goto(u):
    global url,body,panel,view
    url=u;panel=False;view=False
    if u=='about:blank':body='';return
    try:body=urllib.request.urlopen(u,timeout=3).read().decode()
    except Exception:body=''
def dom():
    title=re.search('<title>(.*?)</title>',body)
    title=title.group(1) if title else ''
    heads=re.findall('<h1>(.*?)</h1>',body)
    if panel:heads.append('Filter panel')
    if view:heads.append('Report preview')
    def elem(tag,label,css,href='',role=None):return dict(tag=tag,type='',role=role or tag,label=label,css=css,href=href,external=False,query=False,target='',disabled=False,form=False,expanded='',selected='',options=[])
    els=[]
    for i,(href,label) in enumerate(re.findall('<a href="([^"]+)">([^<]+)</a>',body)):
        els.append(elem('a',label,f'main > a:nth-of-type({i+1})',href))
    for id,label in re.findall('<button id="([^"]+)"[^>]*>([^<]+)</button>',body):els.append(elem('button',label,'#'+id))
    return dict(title=title,headings=heads,elements=els,dialogs=[],frames=0,canvas=0,truncated=False)
def screenshot():
    im=Image.new('RGB',(width,height),'white');d=ImageDraw.Draw(im);d.rectangle((24,24,min(740,width-1),min(260,height-1)),fill='#e1ebfd' if '#e1ebfd' in body else '#f2f4f8');d.text((45,40),dom()['title'],fill='black');y=72
    for h in dom()['headings']:d.text((45,y),h,fill='black');y+=20
    for e in dom()['elements']:d.text((45,y),e['label'],fill='black');y+=20
    out=io.BytesIO();im.save(out,format='PNG');return base64.b64encode(out.getvalue()).decode()
def http(conn,request):
    if request.path=='/json/list':return conn.respond(HTTPStatus.OK,json.dumps([{'type':'page','webSocketDebuggerUrl':f'ws://127.0.0.1:{port}/devtools/page/mock'}]))
    if request.path.startswith('/mock/home?'):
        goto(urllib.parse.parse_qs(urllib.parse.urlparse(request.path).query)['url'][0]);return conn.respond(HTTPStatus.OK,'OK')
    return None
def handler(ws):
    global width,height,panel,view,stale_once
    for raw in ws:
        m=json.loads(raw);method=m['method'];p=m.get('params',{});result={}
        if method=='Page.navigate':goto(p['url']);result={'frameId':'main'}
        elif method=='Emulation.setDeviceMetricsOverride':width,height=p['width'],p['height']
        elif method=='Page.captureScreenshot':result={'data':screenshot()}
        elif method=='Runtime.evaluate':
            js=p['expression'];v=True
            if js=='document.readyState':v='complete'
            elif js=='location.href':v=url
            elif 'let inputs=' in js:v=dict(url=url,title=dom()['title'],auth='type="password"' in body and 'Sign in' in body,error=False,ready=bool(body))
            elif 'const masks=' in js:v=dom()
            elif 'const a=' in js and 'const valid=' in js:
                action=json.JSONDecoder().raw_decode(js.split('const a=',1)[1])[0];css=action['css']
                target=next((x for x in dom()['elements'] if x['css']==css),None);v=bool(target)
                if target and css=='#filter' and stale_once:
                    stale_once=False;target=None;v=False
                if target:
                    if css=='#filter':panel=not panel
                    elif css=='#view':view=True
                    elif target['href']:goto(urllib.parse.urljoin(url,target['href']))
            result={'result':{'value':v}}
        elif method=='Browser.close':ws.send(json.dumps({'id':m['id'],'result':{}}));os._exit(0)
        ws.send(json.dumps({'id':m['id'],'result':result}))
with serve(handler,'127.0.0.1',0,process_request=http,max_size=32*1024*1024) as server:
    port=server.socket.getsockname()[1];(profile/'DevToolsActivePort').write_text(str(port)+'\n/devtools/browser/mock\n');server.serve_forever()
