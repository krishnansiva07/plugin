# Eliya UI Recorder — v3.0 (Java 17)

A standalone local UI recorder for an automation engineer using Selenium Java or Playwright. **The normal export is a concise automation flow, not a DOM dump.**

## Requirements

- Java 17 or later (JDK 17 for building)
- Installed Chrome or Edge; the recorder does not download a browser
- Maven is optional; `build-with-jdk.bat` (Windows) or `build-with-jdk.sh` (macOS/Linux) builds using the installed JDK

## Build / Run

```bash
# Maven if available
mvn clean package
# OR, no Maven:
sh build-with-jdk.sh
# Windows: build-with-jdk.bat

java -jar target/eliya-ui-recorder-3.0.0.jar
```

The recorder opens a local dashboard at 127.0.0.1. Enter the application URL, select Chrome/Edge, select Launch, interact with the application, Stop, and Export JSON, Excel, or both as ZIP. The browser must support the DevTools protocol; if installed Chrome and Edge are not discoverable, the UI reports an error. No LLM is involved.

## Export design

- JSON: `schemaVersion`, `applicationUrl`, `browser`, `summary`, `steps`, `elements`
- `steps`: only `navigate`, `click`, `fill`, `select`, `check`, `doubleClick`, Enter/Escape, and other purposeful actions; input values and checkbox states when applicable. Each interaction references an element ID, plus a best XPath for convenience.
- `elements`: each unique interacted element once, up to **three validated XPath alternatives** and **two CSS alternatives** when available, key target attributes, immediate parent, and at most three children. Unlike v2, this is not repeated for every step.
- Excel contains only three worksheets: **Test Steps**, **Element Locators**, and **Page Flow**. Each step exposes XPath 1/2/3 in separate columns.
- Duplicate navigation notifications and repeated text-entry bursts are merged; ordinary scroll, pointer movement and focus noise is excluded by default.
- Raw debug export is optional and separate. Local session journaling remains available for troubleshooting.

## Locator policy

Candidate XPath expressions are generated and checked against the exact DOM target at recording time:

1. Stable data-test/test-id attributes and stable ID/name/ARIA/placeholder.
2. Target visible text on supported controls.
3. Parent-anchored XPath when a stable parent exists.
4. Useful class/href alternatives.
5. Absolute/structural XPath **only as a fallback**, because it is fragile.

`unique: true` means exactly one match was verified at the time of capture and that match is the interacted element. Locator alternatives are best-effort. If the application has no stable attribute, fewer than three meaningful XPath alternatives may be returned. Revalidate locators when executing the test.

XPath does not pierce Shadow DOM. A shadow-root target uses a shadow-aware CSS path; use Selenium `getShadowRoot()` or a corresponding Playwright shadow locator. Iframes require switching to the correct frame. Browser-level downloads/native dialogues cannot always be recorded through JavaScript listeners. Dynamic content, SPA routes, cross-origin frames, and security restrictions can limit capture.

## Security

Passwords, hidden inputs and attributes whose names suggest credentials are redacted. Exports can still contain entered business data, so review before sharing. The dashboard binds only to localhost.

## Local smoke test

Using only the JDK:

```bash
mkdir -p target/test-classes
javac --release 17 -cp target/classes -d target/test-classes src/test/java/com/eliya/recorder/ExportSmokeTest.java
java -cp target/classes:target/test-classes com.eliya.recorder.ExportSmokeTest .
```

The included fixture simulates navigation across three pages with 318 low- and high-level events, verifies filtering and locators, and generates JSON/XLSX examples. It is not a real application recording.
