package com.eliya.recorder;
import java.nio.file.*;
import java.util.*;
/** Compile and run using only Java 17 (no Maven/JUnit required). */
public class ExportSmokeTest {
  private static Map<String,Object> candidate(String strategy,String value,boolean unique) {
    return Json.map("strategy",strategy,"value",value,"unique",unique,"reason","verified against target");
  }
  private static Map<String,Object> target(String kind,String page,String id,String testid,String value) {
    String xp="//input[@data-testid='"+testid+"']";
    String parent="//form[@id='form1']";
    Map<String,Object> el=Json.map("type",kind,"pageUrl",page,"tabId","tab1","tag","input","inputType","text",
      "attributes",Json.map("id",id,"data-testid",testid,"name",id,"type","text"),
      "locators",Json.map("xpaths",List.of(candidate("xpath",xp,true),
        candidate("xpath","//*[@id='"+id+"']",true),
        candidate("xpath",parent+"//input[@name='"+id+"']",true)),
        "css",List.of(candidate("css","[data-testid=\""+testid+"\"]",true))),
      "context",Json.map("parent",Json.map("tag","form","attributes",Json.map("id","form1"),"xpath",parent),
        "children",List.of()),"value",value);
    return el;
  }
  private static void verify(boolean okay,String message){if(!okay)throw new IllegalStateException(message);}
  public static void main(String[] args) throws Exception {
    List<Map<String,Object>> raw=new ArrayList<>();
    Map<String,Object> session=Json.map("applicationUrl","https://example.test/start","browser","Edge");
    for(int page=1;page<=3;page++) {
      String url="https://example.test/page"+page;
      raw.add(Json.map("type","navigate","tabId","tab1","pageUrl",url));
      raw.add(Json.map("type","navigate","tabId","tab1","pageUrl",url));
      for(int n=0;n<100;n++)raw.add(Json.map("type","scroll","tabId","tab1","pageUrl",url,"scrollY",n));
      Map<String,Object> click=target("click",url,"user"+page,"user-"+page,"");
      raw.add(click);
      raw.add(target("fill",url,"user"+page,"user-"+page,"Alice"+page));
      raw.add(target("fill",url,"user"+page,"user-"+page,"Alice Example "+page));
      Map<String,Object> button=target("click",url,"submit"+page,"submit-"+page,"");
      button.put("tag","button");button.put("text","Continue");button.remove("value");
      raw.add(button);
    }
    Map<String,Object> flow=AutomationExport.build(session,raw);
    List<Object> steps=Json.array(flow.get("steps"));
    List<Object> elements=Json.array(flow.get("elements"));
    verify(steps.size()==9,"Expected exactly 9 steps, got "+steps.size());
    verify(elements.size()==6,"Expected 6 distinct elements, got "+elements.size());
    verify(steps.stream().noneMatch(it->"scroll".equals(Json.object(it).get("action"))),"Scroll noise survived");
    verify(elements.stream().allMatch(it->Json.array(Json.object(Json.object(it).get("locators")).get("xpaths")).size()>=3),"XPaths missing");
    String json=Json.pretty(flow)+"\n";
    byte[] xlsx=XlsxWriter.write(flow);
    verify(json.lines().count()<1000,"JSON too verbose: "+json.lines().count());
    verify(xlsx.length>1500,"Workbook too small");
    Path out=Path.of(args.length>0?args[0]:"/mnt/data");
    Files.createDirectories(out);
    Files.writeString(out.resolve("Recorder_v3_Sample_Export.json"),json);
    Files.write(out.resolve("Recorder_v3_Sample_Export.xlsx"),xlsx);
    System.out.println("PASS: raw="+raw.size()+", steps="+steps.size()+", elements="+elements.size()+
      ", jsonLines="+json.lines().count()+", jsonBytes="+json.length()+", xlsxBytes="+xlsx.length);
  }
}
