/* Eliya UI Recorder v3.0: injected into each Chromium document via DevTools.
   No external libraries and no modification of the tested application's requests. */
(() => {
  'use strict';
  if (window.__eliyaRecorderInit) return;
  Object.defineProperty(window, '__eliyaRecorderInit', {value: true, configurable: false});

  const options = Object.assign({domMaxNodes: 0, domMaxDepth: 0, domMaxSiblings: 0,
    maxAttributeChars: 160, maxTextChars: 120, captureMotion: false, captureDiagnostics: false}, window.__eliyaRecorderSettings || {});
  const clamp = (value, min, max) => Math.min(max, Math.max(min, Number(value) || min));
  options.domMaxNodes = clamp(options.domMaxNodes, 1, 10000);
  options.domMaxDepth = clamp(options.domMaxDepth, 1, 80);
  options.domMaxSiblings = clamp(options.domMaxSiblings, 0, 100);
  options.maxAttributeChars = clamp(options.maxAttributeChars, 64, 12000);
  options.maxTextChars = clamp(options.maxTextChars, 0, 4000);

  const REDACTED = '[REDACTED]';
  const secretName = /pass(?:word|wd)?|secret|token|auth(?:oriz|enticat)?|api[_-]?key|session|cookie|bearer|credit.?card|card.?number|cvv|cvc|pin.?code|one.?time.?pass|otp|ssn|social.?security|private.?key|access[_-]?key|csrf/i;
  const sensitive = el => {
    if (!(el instanceof Element)) return false;
    if (el.matches('input[type="hidden"],input[type="password"]')) return true;
    const source = [el.getAttribute('type'), el.getAttribute('id'), el.getAttribute('name'),
      el.getAttribute('autocomplete'), el.getAttribute('aria-label'), el.getAttribute('placeholder')].join(' ');
    if (secretName.test(source)) return true;
    return !!el.closest('[data-sensitive="true"],[data-private="true"],[data-recorder-redact="true"]');
  };
  const text = (x, max = options.maxTextChars) => String(x ?? '').slice(0, max);
  const safeUrl = value => {
    try {
      const url = new URL(String(value), document.baseURI);
      if (!['http:', 'https:'].includes(url.protocol)) return url.protocol + '[OMITTED]';
      url.username = ''; url.password = '';
      for (const key of [...url.searchParams.keys()]) {
        if (secretName.test(key)) url.searchParams.set(key, REDACTED);
      }
      return text(url.href, 4096);
    } catch (_) { return text(value, 2048); }
  };
  const redactValue = (name, value, el) => {
    if (secretName.test(name) || sensitive(el)) return REDACTED;
    if (/^(href|src|action|formaction|cite|poster)$/i.test(name)) return safeUrl(value);
    return text(value, options.maxAttributeChars);
  };
  // A tiny, purposeful attribute set: enough to identify a control, not a DOM dump.
  const usefulAttribute = name => /^(id|name|type|role|aria-label|aria-labelledby|placeholder|title|href|for|value|data-testid|data-test|data-qa|data-cy|class)$/i.test(name);
  const attributes = el => {
    const result = {};
    for (const a of [...el.attributes]) {
      if (!usefulAttribute(a.name) || Object.keys(result).length >= 12) continue;
      const v = redactValue(a.name, a.value, el);
      if (!v || (a.name === 'class' && /(?:^|\s)[a-z0-9_-]{28,}(?:\s|$)/i.test(v))) continue;
      result[a.name] = text(v, a.name === 'href' ? 160 : 100);
    }
    return result;
  };
  const isVisible = el => {
    try {
      const css = getComputedStyle(el);
      const rect = el.getBoundingClientRect();
      return css.display !== 'none' && css.visibility !== 'hidden' && css.visibility !== 'collapse' &&
        Number(css.opacity) > 0 && (rect.width > 0 || rect.height > 0);
    } catch (_) { return null; }
  };
  const rectOf = el => {
    try {
      const r = el.getBoundingClientRect();
      return {x: Math.round(r.x), y: Math.round(r.y), width: Math.round(r.width),
        height: Math.round(r.height), top: Math.round(r.top), left: Math.round(r.left),
        bottom: Math.round(r.bottom), right: Math.round(r.right)};
    } catch (_) { return null; }
  };
  const propsOf = el => {
    const x = {id: text(el.id, 256), className: typeof el.className === 'string' ? text(el.className, 1000) : '',
      visible: isVisible(el), boundingBox: rectOf(el),
      disabled: !!el.disabled, readOnly: !!el.readOnly, required: !!el.required,
      checked: typeof el.checked === 'boolean' ? !!el.checked : null,
      selected: typeof el.selected === 'boolean' ? !!el.selected : null,
      multiple: !!el.multiple, contentEditable: !!el.isContentEditable,
      tabIndex: typeof el.tabIndex === 'number' ? el.tabIndex : null,
      scrollLeft: el.scrollLeft || 0, scrollTop: el.scrollTop || 0};
    if (el instanceof HTMLInputElement || el instanceof HTMLTextAreaElement || el instanceof HTMLSelectElement) {
      x.value = sensitive(el) ? REDACTED : (el.type === 'file' ? '[FILE_INPUT]' : text(el.value, 3000));
      if (el instanceof HTMLSelectElement) x.selectedIndex = el.selectedIndex;
    }
    return x;
  };
  const containsSensitive = el => sensitive(el) || !!el.querySelector?.(
    'input[type="password"],[data-sensitive="true"],[data-private="true"],[data-recorder-redact="true"]');
  const safeText = el => {
    if (containsSensitive(el)) return REDACTED;
    // Only direct text nodes: descendant text is captured in the children tree.
    return text([...el.childNodes].filter(n => n.nodeType === Node.TEXT_NODE)
      .map(n => n.textContent).join(' ').replace(/\s+/g, ' ').trim());
  };
  const summary = el => ({tag: el.localName, id: text(el.id, 256),
    role: text(el.getAttribute('role'), 128), testId: text(el.getAttribute('data-testid'), 256),
    attributes: attributes(el)});

  const escapeCss = value => (window.CSS?.escape ? CSS.escape(String(value)) : String(value).replace(/[^\w-]/g, x => '\\' + x));
  const selectorAttr = (name, value) => '[' + name + '="' + String(value).replaceAll('\\', '\\\\').replaceAll('"', '\\"') + '"]';
  const unique = (root, s) => { try { return root.querySelectorAll(s).length === 1; } catch (_) { return false; } };
  const localCss = (el, root) => {
    for (const name of ['data-testid', 'data-test', 'data-qa', 'data-cy']) {
      const val = el.getAttribute(name);
      if (val && !secretName.test(name) && !secretName.test(val)) {
        const s = selectorAttr(name, val); if (unique(root, s)) return s;
      }
    }
    if (el.id && !secretName.test(el.id)) { const s = '#' + escapeCss(el.id); if (unique(root, s)) return s; }
    const tag = el.localName;
    for (const name of ['name', 'aria-label', 'placeholder']) {
      const val = el.getAttribute(name);
      if (val && !secretName.test(name) && !secretName.test(val)) {
        const s = tag + selectorAttr(name, val); if (unique(root, s)) return s;
      }
    }
    const parts = [];
    let current = el;
    for (let n = 0; n < 50 && current instanceof Element; n++) {
      const name = current.localName;
      const parent = current.parentElement;
      if (current.id && !secretName.test(current.id)) { parts.unshift('#' + escapeCss(current.id)); break; }
      let piece = name;
      if (parent) {
        const siblings = [...parent.children].filter(x => x.localName === name);
        if (siblings.length > 1) piece += ':nth-of-type(' + (siblings.indexOf(current) + 1) + ')';
      }
      parts.unshift(piece);
      if (unique(root, parts.join(' > '))) break;
      current = parent;
    }
    return parts.join(' > ');
  };
  const cssPath = el => {
    const parts = [];
    let current = el;
    for (let n = 0; n < 20; n++) {
      const root = current.getRootNode();
      parts.unshift(localCss(current, root));
      if (!(root instanceof ShadowRoot)) break;
      current = root.host;
    }
    return parts;
  };
  const xpLiteral = value => {
    const v = String(value);
    if (!v.includes("'")) return "'" + v + "'";
    if (!v.includes('"')) return '"' + v + '"';
    return 'concat(' + v.split("'").map(x => "'" + x + "'").join(',"\'",') + ')';
  };
  const xpath = el => {
    if (el.getRootNode() instanceof ShadowRoot) return null;
    const parts = [];
    for (let curr = el, i = 0; curr && curr.nodeType === 1 && i < 60; curr = curr.parentElement, i++) {
      if (curr.id && !dynamicId(curr.id) && !secretName.test(curr.id)) {
        parts.unshift('//*[@id=' + xpLiteral(curr.id) + ']'); break;
      }
      const siblings = curr.parentElement ? [...curr.parentElement.children].filter(x => x.localName === curr.localName) : [];
      parts.unshift(curr.localName + '[' + (Math.max(0, siblings.indexOf(curr)) + 1) + ']');
    }
    return parts[0]?.startsWith('//') ? parts.join('/') : '/' + parts.join('/');
  };
  const frameContext = () => {
    const path = [];
    try {
      let win = window;
      while (win !== win.parent && path.length < 16) {
        const frame = win.frameElement;
        if (!(frame instanceof Element)) break;
        path.unshift({tag: frame.localName, id: text(frame.id, 200),
          name: text(frame.getAttribute('name'), 200), src: safeUrl(frame.getAttribute('src') || win.location.href)});
        win = win.parent;
      }
    } catch (_) { /* Cross-origin boundaries are not directly traversable. */ }
    return {isIframe: window !== window.top, framePath: path, frameUrl: safeUrl(location.href)};
  };
  // Locator quality is judged within the target document or open shadow root, NEVER across frames.
  const dynamicId = value => /(?:[0-9a-f]{8}-[0-9a-f]{4}|^[0-9]{5,}$|_[0-9]{5,}|:[rR][0-9]+:|^ember[0-9]+$|^react-select-[0-9]+)/i.test(value);
  const quoted = value => JSON.stringify(String(value));
  const matchCss = (root, selector) => {
    try { return root.querySelectorAll(selector).length; } catch (_) { return null; }
  };
  const matchXPath = selector => {
    try { return document.evaluate('count(' + selector + ')', document, null, XPathResult.NUMBER_TYPE, null).numberValue; }
    catch (_) { return null; }
  };
  const adjacentContext = (el, event) => {
    const parent = el.parentElement;
    const parentSummary = parent ? {tag: parent.localName, attributes:attributes(parent),
      xpath: xpath(parent), text:safeText(parent).slice(0,60)} : null;
    const children = [];
    for (const child of [...el.children].slice(0, 3)) {
      children.push({tag:child.localName, attributes:attributes(child), xpath:xpath(child),
        text:safeText(child).slice(0,60)});
    }
    const actual = getElement(event);
    return {parent:parentSummary, children,
      eventTarget: actual && actual !== el ? {tag:actual.localName, attributes:attributes(actual)} : null};
  };
  const locators = el => {
    const root = el.getRootNode();
    const shadow = root instanceof ShadowRoot;
    const tag = el.localName;
    const candidates = [];
    const add = (strategy, value, baseScore, count, reason) => {
      if (!value || value.includes(REDACTED) || value.length > 400) return;
      if (count === null || count === 0) return;
      candidates.push({strategy, value, score: count === 1 ? baseScore : Math.max(5,baseScore-45),
        unique:count===1, reason});
    };
    const addCss = (selector, score, reason) => {
      const count = matchCss(root, selector);
      if (count !== null) add('css',selector,score,count,reason);
    };
    const addXp = (selector, score, reason) => {
      if (shadow || !selector) return;
      const count = matchXPath(selector);
      if (!count || count > 100) return;
      try {
        const iterator = document.evaluate(selector, document, null, XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null);
        let matchesTarget = false;
        for (let i=0; i < Math.min(iterator.snapshotLength,20); i++)
          if (iterator.snapshotItem(i) === el) {matchesTarget = true; break;}
        if (matchesTarget) add('xpath',selector,score,count,reason);
      } catch (_) { /* invalid or unsupported XPath */ }
    };
    const primaryAttrs = [['data-testid',99],['data-test',97],['data-qa',96],['data-cy',95],
      ['id',94],['name',89],['aria-label',87],['placeholder',77],['title',70]];
    for (const [name,score] of primaryAttrs) {
      const value = el.getAttribute(name);
      if (!value || value.length > 100 || secretName.test(value) || dynamicId(value) || sensitive(el)) continue;
      const selector = (name === 'id' ? '#' + escapeCss(value) : tag + selectorAttr(name,value));
      addCss(selector,score,name+' attribute');
      const xp = '//' + tag + '[@' + name + '=' + xpLiteral(value) + ']';
      addXp(xp,score,name+' attribute');
    }
    // Stable class token and href are useful alternatives when no test-id/ID exists.
    const stableClasses = (el.getAttribute('class') || '').split(/\s+/).filter(x =>
      /^[a-z][\w-]{2,35}$/i.test(x) && !/^(active|selected|hover|focus|disabled|ng-|css-|sc-)/i.test(x));
    if (!sensitive(el) && stableClasses.length) {
      const cls = stableClasses[0];
      addXp('//' + tag + '[contains(concat(" ",normalize-space(@class)," "),' + xpLiteral(' '+cls+' ') + ')]',65,'Stable CSS class token');
    }
    const href = el.getAttribute('href');
    if (tag==='a' && href && href.length<=100 && !href.includes('?') && !secretName.test(href))
      addXp('//a[@href='+xpLiteral(href)+']',75,'Link href');
    const controlText = containsSensitive(el) ? '' : text((el.innerText || '').replace(/\s+/g,' ').trim(),80);
    if (controlText && controlText.length <= 65 && ['button','a','label','span','summary'].includes(tag)) {
      addXp('//' + tag + '[normalize-space(.)=' + xpLiteral(controlText) + ']',85,'Visible text');
    }
    const parent = el.parentElement;
    if (parent) {
      const anchor = [['data-testid',92],['id',90],['data-qa',88],['name',84]].find(([key]) => {
        const v=parent.getAttribute(key); return v && v.length<90 && !dynamicId(v) && !secretName.test(v);
      });
      if (anchor) {
        const [key, score] = anchor;
        const pv = parent.getAttribute(key);
        let suffix = tag;
        for (const k of ['data-testid','name','aria-label','placeholder']) {
          const v=el.getAttribute(k);
          if (v && v.length<90 && !secretName.test(v)) {suffix += '[@'+k+'='+xpLiteral(v)+']'; break;}
        }
        addXp('//' + parent.localName + '[@'+key+'='+xpLiteral(pv)+']//' + suffix, score-10, 'Anchored to parent');
      }
    }
    const css = cssPath(el).join(' >>> ');
    if (!shadow) {addCss(css,35,'Structural CSS fallback'); addXp(xpath(el),25,'Structural XPath fallback');}
    else if (css) candidates.push({strategy:'shadow-css',value:css,score:45,unique:null,reason:'Open shadow root; traverse hosts first'});
    candidates.sort((a,b) => b.score - a.score || (b.unique===true)-(a.unique===true));
    // Prioritize a usable XPath along with CSS. These are all validated on the real target at capture time.
    const xpaths=candidates.filter(x=>x.strategy==='xpath').slice(0,3);
    const csses=candidates.filter(x=>x.strategy==='css').slice(0,2);
    return {recommended: candidates.find(x=>x.unique) || candidates[0] || null,
      xpaths, css:csses, shadowPath:shadow ? cssPath(el) : []};
  };
  const details = (el, event) => {
    if (!(el instanceof Element)) return {};
    const locator=locators(el);
    return {tag:el.localName, inputType:text(el.type,20), selector:locator.css[0]?.value||'',
      locators:locator, text:containsSensitive(el)?REDACTED:text((el.innerText||'').replace(/\s+/g,' ').trim(),80),
      attributes:attributes(el), context:adjacentContext(el,event), sensitive:sensitive(el)};
  };
  const getElement = event => event?.composedPath?.().find(node => node instanceof Element) ||
    (event?.target instanceof Element ? event.target : null);
  const actionEl = event => {
    const el = getElement(event);
    if (!el) return null;
    return el.closest('button,a,input,textarea,select,summary,option,label,[role],[contenteditable],[onclick]') || el;
  };
  const eventDetails = (e, el) => {
    if (!e) return null;
    const x = {name: e.type, isTrusted: !!e.isTrusted, bubbles: !!e.bubbles,
      cancelable: !!e.cancelable, composed: !!e.composed, timeStamp: Math.round(e.timeStamp),
      targetTag: getElement(e)?.localName || null, currentTargetTag: e.currentTarget?.localName || null};
    if (e instanceof MouseEvent) Object.assign(x, {button: e.button, buttons: e.buttons,
      clientX: e.clientX, clientY: e.clientY, ctrlKey: e.ctrlKey, altKey: e.altKey,
      shiftKey: e.shiftKey, metaKey: e.metaKey, detail: e.detail});
    if (window.PointerEvent && e instanceof PointerEvent) Object.assign(x, {pointerId: e.pointerId,
      pointerType: e.pointerType, pressure: e.pressure, tiltX: e.tiltX, tiltY: e.tiltY,
      isPrimary: e.isPrimary});
    if (e instanceof KeyboardEvent) Object.assign(x, {key: sensitive(el) ? REDACTED : text(e.key, 60),
      code: sensitive(el) ? REDACTED : text(e.code, 60), repeat: e.repeat, location: e.location,
      ctrlKey: e.ctrlKey, altKey: e.altKey, shiftKey: e.shiftKey, metaKey: e.metaKey});
    if (e instanceof InputEvent) Object.assign(x, {inputType: e.inputType,
      data: sensitive(el) ? REDACTED : text(e.data, 150), isComposing: e.isComposing});
    if (e instanceof WheelEvent) Object.assign(x, {deltaX: e.deltaX, deltaY: e.deltaY, deltaMode: e.deltaMode});
    if (e instanceof DragEvent) Object.assign(x, {dataTransferTypes: [...(e.dataTransfer?.types || [])]});
    if (e instanceof FocusEvent) x.relatedTarget = e.relatedTarget instanceof Element ? summary(e.relatedTarget) : null;
    return x;
  };
  const send = (type, properties = {}) => {
    try {
      if (typeof window.__eliyaRecorderSend !== 'function') return;
      window.__eliyaRecorderSend(JSON.stringify({type, timestamp: new Date().toISOString(),
        pageUrl: safeUrl(location.href), title: text(document.title, 300),
        frame: frameContext(), ...properties}));
    } catch (_) { /* Never break user application interaction. */ }
  };
  const emit = (type, event, includeTree = true, extra = {}) => {
    const el = actionEl(event);
    const target = el ? details(el, event) : {};
    send(type, {event: eventDetails(event, el), ...target, ...extra});
  };
  const timeouts = new Map();
  const lastValue = new WeakMap();
  const inputEl = e => {
    const el = getElement(e);
    return el?.matches?.('input,textarea,select,[contenteditable=""],[contenteditable="true"],[role="textbox"]') ? el : null;
  };
  const saveInput = (el, event) => {
    if (!el) return;
    let type = 'fill';
    const values = {};
    if (el.type === 'checkbox' || el.type === 'radio') { type = 'check'; values.checked = !!el.checked; }
    else if (el.tagName === 'SELECT') {
      type = 'select'; values.value = sensitive(el) ? REDACTED : text(el.value, 3000);
      values.selectedOptions = [...el.selectedOptions].map(o => ({
        value: sensitive(el) ? REDACTED : text(o.value, 1000),
        text: sensitive(el) ? REDACTED : text(o.textContent, 200)
      }));
      if (el.multiple) values.selected = values.selectedOptions.map(o => o.value);
    } else if (el.type === 'file') {
      type = 'fileSelected'; values.files = [...(el.files || [])].map(f => text(f.name, 200));
    } else values.value = sensitive(el) ? REDACTED : text(el.isContentEditable ? el.innerText : el.value, 3000);
    const signature = JSON.stringify({type, values});
    if (lastValue.get(el) === signature) return;
    lastValue.set(el, signature);
    send(type, {event: eventDetails(event, el), ...details(el, event), ...values});
  };
  const flushOne = el => {
    const item = timeouts.get(el);
    if (item) {clearTimeout(item.timer); timeouts.delete(el); saveInput(el, item.event);}
  };
  const flushAll = () => {
    for (const el of [...timeouts.keys()]) flushOne(el);
    if (inputEl({target: document.activeElement})) saveInput(document.activeElement, null);
  };
  window.__eliyaRecorderFlush = flushAll;
  window.addEventListener('blur', flushAll);
  document.addEventListener('input', e => {
    const el = inputEl(e);
    if (!el) return;
    const old = timeouts.get(el);
    if (old) clearTimeout(old.timer);
    timeouts.set(el, {event: e, timer: setTimeout(() => flushOne(el), 400)});
  }, true);
  document.addEventListener('change', e => {
    const el = inputEl(e);
    if (el) { flushOne(el); saveInput(el, e); }
    else emit('change', e);
  }, true);
  document.addEventListener('focusout', e => flushOne(inputEl(e)), true);

  // Only capture purposeful actions with their DOM tree. Low-level telemetry is optional,
  // because pointer/focus/move/wheel events drown useful tester actions in huge JSON files.
  const full = ['click','dblclick','auxclick','contextmenu','submit','drop','reset'];
  const importantKey = e => ['Enter','Escape','Tab','F2','F4','ArrowDown','ArrowUp','ArrowLeft','ArrowRight','Delete','Backspace','Home','End','PageUp','PageDown',' ','Spacebar'].includes(e.key) ||
    ((e.ctrlKey || e.metaKey) && ['a','s','f'].includes(e.key.toLowerCase()));
  const diagnostics = ['pointerdown','pointerup','pointercancel','mousedown','mouseup',
    'keyup','touchstart','touchend','touchcancel','focusin','focusout','mouseover','mouseout',
    'pointerover','pointerout','dragstart','dragenter','dragleave','dragover','dragend',
    'copy','cut','paste','compositionstart','compositionend','select','wheel'];
  const throttled = new Map();
  const captureEvent = (e, tree) => {
    const mapped = ({dblclick:'doubleClick',contextmenu:'rightClick',keydown:'keyDown',keyup:'keyUp'})[e.type] || e.type;
    emit(mapped, e, tree);
  };
  for (const name of full) document.addEventListener(name, e => captureEvent(e, true), true);
  document.addEventListener('keydown', e => {
    if (importantKey(e) || options.captureDiagnostics) captureEvent(e, false);
  }, true);
  if (options.captureDiagnostics) {
    for (const name of diagnostics) document.addEventListener(name, e => {
      const el = actionEl(e);
      const key = name + ':' + (el ? cssPath(el).join('>>>') : 'document');
      const now = Date.now();
      if (now - (throttled.get(key) || 0) < 400) return;
      throttled.set(key, now);
      if (throttled.size > 3000) throttled.clear();
      captureEvent(e, false);
    }, {capture:true, passive: name === 'wheel'});
  }
  if (options.captureMotion) {
    for (const name of ['mousemove','pointermove','touchmove']) document.addEventListener(name, e => {
      const now = Date.now();
      if (now - (throttled.get(name) || 0) < 350) return;
      throttled.set(name, now);
      captureEvent(e, false);
    }, {capture:true, passive:true});
  }
  if (options.captureDiagnostics) document.addEventListener('scroll', e => {
    const now = Date.now(), el = e.target instanceof Element ? e.target : document.scrollingElement;
    if (!el) return;
    const key = 'scroll:' + cssPath(el).join('>>>');
    if (now - (throttled.get(key) || 0) < 350) return;
    throttled.set(key, now);
    send('scroll', {event: eventDetails(e, el), ...details(el, e),
      scrollX: el.scrollLeft, scrollY: el.scrollTop});
  }, {capture:true, passive:true});
  if (options.captureDiagnostics) document.addEventListener('selectionchange', e => {
    const now = Date.now();
    if (now - (throttled.get('selection') || 0) < 500) return;
    throttled.set('selection', now);
    const selected = window.getSelection();
    // Text selections might include secrets: save only selection length.
    send('selectionchange', {event: eventDetails(e, null), selectionLength: selected ? selected.toString().length : 0});
  }, true);

  let lastNavigation = '';
  const navigation = source => { const url = safeUrl(location.href); if (url !== lastNavigation) {lastNavigation=url; send('navigate', {url});} };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', () => navigation('DOMContentLoaded'), {once:true});
  else navigation('existingDocument');
  window.addEventListener('popstate', () => navigation('popstate'));
  window.addEventListener('hashchange', () => navigation('hashchange'));
  for (const name of ['pushState', 'replaceState']) {
    try {
      const original = history[name];
      history[name] = function(...args) {const result = original.apply(this, args); navigation(name); return result;};
    } catch (_) { /* Some environments disallow patching. */ }
  }
})();
