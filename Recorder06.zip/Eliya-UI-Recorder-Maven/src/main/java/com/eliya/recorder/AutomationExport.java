package com.eliya.recorder;

import java.util.*;

/** Automation-grade, deliberately small workflow rather than raw DOM telemetry. */
final class AutomationExport {
    private static final Set<String> ACTIONS = Set.of("navigate", "click", "doubleClick",
        "rightClick", "fill", "select", "check", "fileSelected", "drop", "keyDown", "submit");
    private AutomationExport() {}

    static boolean isMeaningful(Map<String,Object> action) {
        String type = str(action,"type");
        if (!ACTIONS.contains(type)) return false;
        if ("keyDown".equals(type)) {
            String key = str(Json.object(action.get("event")),"key");
            return Set.of("Enter","Escape","F2","F4").contains(key);
        }
        return true;
    }

    static Map<String,Object> build(Map<String,Object> session, List<Map<String,Object>> raw) {
        List<Map<String,Object>> steps = new ArrayList<>();
        LinkedHashMap<String,Map<String,Object>> elements = new LinkedHashMap<>();
        LinkedHashMap<String,String> pageByTab = new LinkedHashMap<>();
        int ignored = 0;
        for (int i=0;i<raw.size();i++) {
            Map<String,Object> item=raw.get(i);
            String action=str(item,"type"), tab=str(item,"tabId");
            if (!isMeaningful(item)) {ignored++;continue;}
            String page=str(item,"pageUrl");
            if ("navigate".equals(action)) {
                if (page.isBlank()) page=str(item,"url");
                if (page.isBlank() || Objects.equals(pageByTab.get(tab),page)) {ignored++;continue;}
                pageByTab.put(tab,page);
                steps.add(Json.map("step",0,"action","navigate","url",page));
                continue;
            }
            if ("submit".equals(action)) {
                if (!steps.isEmpty() && Set.of("click","keyDown").contains(str(steps.get(steps.size()-1),"action"))) {
                    ignored++; continue; // DOM submit is a consequence, not an extra test action.
                }
            }
            String key=identity(item);
            Map<String,Object> element=elements.get(key);
            if (element==null) {
                element=elementDetails(item,"E"+String.format(Locale.ROOT,"%03d",elements.size()+1));
                elements.put(key,element);
            }
            String id=str(element,"id");
            if ("click".equals(action) && superseded(raw,i,item)) {ignored++;continue;}
            if (!steps.isEmpty() && Set.of("fill","select","check","fileSelected").contains(action)) {
                Map<String,Object> previous=steps.get(steps.size()-1);
                if ("click".equals(str(previous,"action")) && id.equals(str(previous,"element"))) {
                    steps.remove(steps.size()-1); ignored++;
                }
                if (!steps.isEmpty()) {
                    previous=steps.get(steps.size()-1);
                    if ("fill".equals(action) && "fill".equals(str(previous,"action")) && id.equals(str(previous,"element"))) {
                        steps.remove(steps.size()-1); ignored++;
                    }
                }
            }
            if ("doubleClick".equals(action)) {
                for (int n=0;n<2 && !steps.isEmpty();n++) {
                    Map<String,Object> previous=steps.get(steps.size()-1);
                    if ("click".equals(str(previous,"action")) && id.equals(str(previous,"element"))) {
                        steps.remove(steps.size()-1); ignored++;
                    } else break;
                }
            }
            Map<String,Object> step=Json.map("step",0,"action",action,"page",page,
                "element",id,"description",describe(action,item));
            if (item.containsKey("value")) step.put("value",item.get("value"));
            if (item.containsKey("checked")) step.put("checked",item.get("checked"));
            if (item.containsKey("selectedOptions")) step.put("selectedOptions",compactOptions(item.get("selectedOptions")));
            if (item.containsKey("files")) step.put("files",item.get("files"));
            if ("keyDown".equals(action)) step.put("key",str(Json.object(item.get("event")),"key"));
            Map<String,Object> frame=Json.object(item.get("frame"));
            if (Boolean.TRUE.equals(frame.get("isIframe"))) {
                Map<String,Object> info=new LinkedHashMap<>();
                if (!str(frame,"frameUrl").isEmpty()) info.put("url",frame.get("frameUrl"));
                if (!Json.array(frame.get("framePath")).isEmpty()) info.put("path",frame.get("framePath"));
                step.put("frame",info);
            }
            // Easy for a Selenium engineer to consume directly; all alternatives in elements[].
            Map<String,Object> loc=Json.object(element.get("locators"));
            List<Object> xp=Json.array(loc.get("xpaths"));
            if (!xp.isEmpty()) step.put("xpath",Json.object(xp.get(0)).get("value"));
            else if (!Json.array(loc.get("css")).isEmpty())
                step.put("css",Json.object(Json.array(loc.get("css")).get(0)).get("value"));
            steps.add(step);
        }
        for (int i=0;i<steps.size();i++) steps.get(i).put("step",i+1);
        Set<String> used=new HashSet<>();
        for (Map<String,Object> st:steps) if (st.containsKey("element")) used.add(str(st,"element"));
        elements.values().removeIf(el -> !used.contains(str(el,"id")));
        for (Map<String,Object> el:elements.values()) {
            List<Integer> indices=new ArrayList<>();
            for (Map<String,Object> st:steps)
                if (Objects.equals(st.get("element"),el.get("id"))) indices.add(((Number)st.get("step")).intValue());
            el.put("usedInSteps",indices);
        }
        List<Object> pageFlow=new ArrayList<>();
        for (Map<String,Object> st:steps) if ("navigate".equals(st.get("action")))
            pageFlow.add(Json.map("step",st.get("step"),"url",st.get("url")));
        Map<String,Object> flow=new LinkedHashMap<>();
        flow.put("schemaVersion","3.0");
        flow.put("applicationUrl",session.get("applicationUrl"));
        flow.put("browser",session.get("browser"));
        flow.put("summary",Json.map("steps",steps.size(),"elements",elements.size(),
            "pages",pageFlow.size(),"filteredEvents",ignored));
        flow.put("steps",steps);
        flow.put("elements",new ArrayList<>(elements.values()));
        return flow;
    }

    private static List<Object> compactOptions(Object obj) {
        List<Object> out=new ArrayList<>();
        for (Object val:Json.array(obj)) {
            Map<String,Object> option=Json.object(val);
            out.add(Json.map("value",option.get("value"),"text",option.get("text")));
            if (out.size()>=10) break;
        }
        return out;
    }
    private static String identity(Map<String,Object> raw) {
        Map<String,Object> loc=Json.object(raw.get("locators"));
        Map<String,Object> attrs=Json.object(raw.get("attributes"));
        String selector=str(attrs,"data-testid");
        if (selector.isBlank()) selector=str(attrs,"id");
        if (selector.isBlank()) selector=str(attrs,"name");
        if (selector.isBlank()) selector=str(raw,"selector");
        if (selector.isBlank()) selector=str(raw,"tag") + ":"+ str(raw,"text");
        String page=str(raw,"pageUrl");
        // Avoid conflating identical field names on unrelated routes.
        return str(raw,"tabId")+"|"+page+"|"+Json.stringify(raw.get("frame"))+"|"+selector;
    }
    private static Map<String,Object> elementDetails(Map<String,Object> action, String id) {
        Map<String,Object> sourceLoc=Json.object(action.get("locators"));
        List<Object> xpath=new ArrayList<>(), css=new ArrayList<>();
        for (Object ob:Json.array(sourceLoc.get("xpaths"))) {
            Map<String,Object> loc=Json.object(ob);
            if (xpath.size()<3) xpath.add(cleanLocator(loc));
        }
        for (Object ob:Json.array(sourceLoc.get("css"))) {
            Map<String,Object> loc=Json.object(ob);
            if (css.size()<2) css.add(cleanLocator(loc));
        }
        // Legacy recordings without XPath lists: expose supplied absolute XPath when present.
        if (xpath.isEmpty() && !str(sourceLoc,"xpath").isBlank())
            xpath.add(Json.map("value",sourceLoc.get("xpath"),"unique",null,"reason","Legacy structural XPath; verify"));
        if (css.isEmpty() && !str(sourceLoc,"css").isBlank())
            css.add(Json.map("value",sourceLoc.get("css"),"unique",null,"reason","Legacy CSS; verify"));
        Map<String,Object> loc=Json.map("xpaths",xpath,"css",css);
        Map<String,Object> best=Json.object(sourceLoc.get("recommended"));
        if (!best.isEmpty()) loc.put("recommended",cleanLocator(best));
        else if (!xpath.isEmpty()) loc.put("recommended",xpath.get(0));
        Map<String,Object> el=Json.map("id",id,"tag",action.get("tag"));
        if (!str(action,"inputType").isBlank()) el.put("type",action.get("inputType"));
        if (!str(action,"text").isBlank()) el.put("text",trim(str(action,"text"),80));
        el.put("attributes",usefulAttributes(Json.object(action.get("attributes"))));
        el.put("locators",loc);
        Map<String,Object> context=Json.object(action.get("context"));
        Map<String,Object> parent=contextNode(Json.object(context.get("parent")));
        if (!parent.isEmpty()) el.put("parent",parent);
        List<Object> children=new ArrayList<>();
        for (Object ob:Json.array(context.get("children"))) {
            if (children.size()>=3) break;
            Map<String,Object> child=contextNode(Json.object(ob));
            if (!child.isEmpty()) children.add(child);
        }
        if (!children.isEmpty()) el.put("children",children);
        return el;
    }
    private static Map<String,Object> cleanLocator(Map<String,Object> loc) {
        Map<String,Object> out=new LinkedHashMap<>();
        if (loc.containsKey("strategy")) out.put("strategy",loc.get("strategy"));
        if (loc.containsKey("value")) out.put("value",loc.get("value"));
        if (loc.containsKey("unique")) out.put("unique",loc.get("unique"));
        if (loc.containsKey("reason")) out.put("reason",loc.get("reason"));
        return out;
    }
    private static Map<String,Object> contextNode(Map<String,Object> item) {
        if (item.isEmpty()) return Map.of();
        Map<String,Object> out=Json.map("tag",item.get("tag"));
        Map<String,Object> attrs=usefulAttributes(Json.object(item.get("attributes")));
        if (!attrs.isEmpty()) out.put("attributes",attrs);
        if (!str(item,"text").isBlank()) out.put("text",trim(str(item,"text"),60));
        if (!str(item,"xpath").isBlank()) out.put("xpath",item.get("xpath"));
        return out;
    }
    private static Map<String,Object> usefulAttributes(Map<String,Object> attrs) {
        Map<String,Object> out=new LinkedHashMap<>();
        for (String name:List.of("data-testid","data-test","data-qa","data-cy","id","name",
            "type","role","aria-label","aria-labelledby","placeholder","title","for","href","class")) {
            Object v=attrs.get(name);
            if (v!=null && !Json.str(v).isBlank()) out.put(name,trim(Json.str(v),100));
            if (out.size()>=10) break;
        }
        return out;
    }
    private static String trim(String val, int size) {return val.length()>size?val.substring(0,size):val;}
    private static String describe(String kind, Map<String,Object> item) {
        Map<String,Object> attrs=Json.object(item.get("attributes"));
        String label="";
        for (String key:List.of("aria-label","data-testid","name","placeholder","id","title")) {
            label=str(attrs,key); if (!label.isBlank()) break;
        }
        if (label.isBlank()) label=trim(str(item,"text"),50);
        if (label.isBlank()) label=str(item,"tag");
        String prefix=switch(kind) {
            case "fill" -> "Type into "; case "select" -> "Select from "; case "check" -> "Set checkbox ";
            case "fileSelected" -> "Upload into "; case "doubleClick" -> "Double-click ";
            case "rightClick" -> "Right-click "; case "keyDown" -> "Press key on ";
            case "submit" -> "Submit "; default -> "Click ";
        };
        return prefix+label;
    }
    private static boolean superseded(List<Map<String,Object>> raw, int i,Map<String,Object> item) {
        String id=identity(item);
        for (int j=i+1;j<Math.min(raw.size(),i+12);j++) {
            Map<String,Object> next=raw.get(j);
            if ("navigate".equals(str(next,"type"))) break;
            if (Set.of("fill","select","check","doubleClick","fileSelected").contains(str(next,"type")) &&
                id.equals(identity(next))) return true;
            if ("click".equals(str(next,"type"))) break;
        }
        return false;
    }
    private static String str(Map<String,Object> m,String k) {return Json.str(m.get(k));}
}
