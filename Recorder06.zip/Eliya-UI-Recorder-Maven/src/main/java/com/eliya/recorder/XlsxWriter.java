package com.eliya.recorder;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.zip.*;

/** Small XLSX writer with just the three worksheets useful to a QA automation engineer. */
final class XlsxWriter {
    private XlsxWriter() {}
    static byte[] write(Map<String,Object> flow) throws IOException {
        Sheet steps=new Sheet("Test Steps", "Step","Action","Description","Input / State", "Page URL",
            "Element ID","XPath 1","XPath 2","XPath 3","CSS","Tag","Target Attributes","Parent","Children","Frame");
        Sheet locators=new Sheet("Element Locators", "Element ID","Used Steps","Tag","Text","ID","Name","Test ID",
            "Role","Placeholder","XPath 1","XPath 2","XPath 3","XPath Valid?","CSS 1","CSS 2","Parent","Children");
        Sheet pages=new Sheet("Page Flow", "Step","Action","Page URL","Description","Element ID","XPath");
        Map<String,Map<String,Object>> byId=new LinkedHashMap<>();
        for (Object obj:Json.array(flow.get("elements"))) {
            Map<String,Object> el=Json.object(obj);
            byId.put(Json.str(el.get("id")),el);
            Map<String,Object> attr=Json.object(el.get("attributes"));
            Map<String,Object> ls=Json.object(el.get("locators"));
            locators.add(el.get("id"), joinSteps(el.get("usedInSteps")),el.get("tag"),el.get("text"),attr.get("id"),
                attr.get("name"),attr.getOrDefault("data-testid",attr.getOrDefault("data-qa",attr.get("data-test"))),
                attr.get("role"),attr.get("placeholder"),xpath(ls,0),xpath(ls,1),xpath(ls,2),
                xpathUnique(ls,0),css(ls,0),css(ls,1),node(Json.object(el.get("parent"))),children(el));
        }
        for (Object obj:Json.array(flow.get("steps"))) {
            Map<String,Object> st=Json.object(obj);
            Map<String,Object> el=byId.getOrDefault(Json.str(st.get("element")),Map.of());
            Map<String,Object> ls=Json.object(el.get("locators"));
            String page=Json.str(st.getOrDefault("page",st.get("url")));
            String state=state(st);
            steps.add(st.get("step"),st.get("action"),st.get("description"),state,page,st.get("element"),
                xpath(ls,0),xpath(ls,1),xpath(ls,2),css(ls,0),el.get("tag"),attrText(Json.object(el.get("attributes"))),
                node(Json.object(el.get("parent"))),children(el),
                Json.object(st.get("frame")).get("url"));
            if ("navigate".equals(st.get("action"))) pages.add(st.get("step"),"navigate",page,"Open / navigate",null,null);
            else pages.add(st.get("step"),st.get("action"),page,st.get("description"),st.get("element"),xpath(ls,0));
        }
        return encode(List.of(steps,locators,pages));
    }
    private static String state(Map<String,Object> st) {
        if (st.containsKey("value")) return Json.str(st.get("value"));
        if (st.containsKey("checked")) return "checked="+st.get("checked");
        if (st.containsKey("selectedOptions")) return Json.stringify(st.get("selectedOptions"));
        if (st.containsKey("files")) return Json.stringify(st.get("files"));
        if (st.containsKey("key")) return "key="+Json.str(st.get("key"));
        return "";
    }
    private static Object xpath(Map<String,Object> loc,int index) { return val(loc,"xpaths",index); }
    private static Object css(Map<String,Object> loc,int index) { return val(loc,"css",index); }
    private static Object val(Map<String,Object> loc,String type,int index) {
        List<Object> arr=Json.array(loc.get(type));
        return arr.size()>index ? Json.object(arr.get(index)).get("value") : null;
    }
    private static Object xpathUnique(Map<String,Object> loc,int index) {
        List<Object> arr=Json.array(loc.get("xpaths"));
        return arr.size()>index ? Json.object(arr.get(index)).get("unique") : null;
    }
    private static String attrText(Map<String,Object> a) {
        List<String> out=new ArrayList<>();
        for (var entry:a.entrySet()) out.add(entry.getKey()+"="+entry.getValue());
        return String.join("; ",out);
    }
    private static String node(Map<String,Object> n) {
        if (n.isEmpty()) return "";
        String output=Json.str(n.get("tag"));
        Map<String,Object> a=Json.object(n.get("attributes"));
        if (a.containsKey("id")) output+="#"+a.get("id");
        if (a.containsKey("data-testid")) output+=" [data-testid="+a.get("data-testid")+"]";
        if (a.containsKey("class")) output+=" ."+a.get("class");
        if (n.containsKey("xpath")) output+=" | "+Json.str(n.get("xpath"));
        return output;
    }
    private static String children(Map<String,Object> el) {
        List<String> out=new ArrayList<>();
        for (Object c:Json.array(el.get("children"))) out.add(node(Json.object(c)));
        return String.join("; ",out);
    }
    private static String joinSteps(Object list) {
        List<String> out=new ArrayList<>();for(Object v:Json.array(list))out.add(String.valueOf(v));
        return String.join(", ",out);
    }
    private record Sheet(String name, List<List<Object>> rows) {
        Sheet(String name,String... header) {this(name,new ArrayList<>());add((Object[])header);}
        void add(Object... values) {rows.add(Arrays.asList(values));}
    }
    private static byte[] encode(List<Sheet> sheets) throws IOException {
        ByteArrayOutputStream buf=new ByteArrayOutputStream();
        try (ZipOutputStream zip=new ZipOutputStream(buf,StandardCharsets.UTF_8)) {
            put(zip,"[Content_Types].xml",types(sheets.size()));
            put(zip,"_rels/.rels","<?xml version=\"1.0\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"xl/workbook.xml\"/></Relationships>");
            StringBuilder book=new StringBuilder("<?xml version=\"1.0\"?><workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\"><sheets>");
            StringBuilder rels=new StringBuilder("<?xml version=\"1.0\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">");
            for (int i=0;i<sheets.size();i++) {
                book.append("<sheet name=\"").append(esc(sheets.get(i).name)).append("\" sheetId=\"").append(i+1).append("\" r:id=\"rId").append(i+1).append("\"/>");
                rels.append("<Relationship Id=\"rId").append(i+1).append("\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet").append(i+1).append(".xml\"/>");
                put(zip,"xl/worksheets/sheet"+(i+1)+".xml",sheetXml(sheets.get(i)));
            }
            book.append("</sheets></workbook>");
            rels.append("<Relationship Id=\"rId").append(sheets.size()+1).append("\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles\" Target=\"styles.xml\"/></Relationships>");
            put(zip,"xl/workbook.xml",book.toString());put(zip,"xl/_rels/workbook.xml.rels",rels.toString());
            put(zip,"xl/styles.xml","<?xml version=\"1.0\"?><styleSheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"><fonts count=\"2\"><font><sz val=\"10\"/><name val=\"Aptos\"/></font><font><b/><color rgb=\"FFFFFFFF\"/><sz val=\"10\"/><name val=\"Aptos\"/></font></fonts><fills count=\"3\"><fill><patternFill patternType=\"none\"/></fill><fill><patternFill patternType=\"gray125\"/></fill><fill><patternFill patternType=\"solid\"><fgColor rgb=\"FF17486B\"/></patternFill></fill></fills><borders count=\"1\"><border><left/><right/><top/><bottom/><diagonal/></border></borders><cellStyleXfs count=\"1\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\"/></cellStyleXfs><cellXfs count=\"2\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\"/><xf numFmtId=\"0\" fontId=\"1\" fillId=\"2\" borderId=\"0\" xfId=\"0\" applyFill=\"1\" applyFont=\"1\"/></cellXfs></styleSheet>");
        }
        return buf.toByteArray();
    }
    private static String types(int n) {
        StringBuilder sb=new StringBuilder("<?xml version=\"1.0\"?><Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\"><Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/><Default Extension=\"xml\" ContentType=\"application/xml\"/><Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/><Override PartName=\"/xl/styles.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml\"/>");
        for (int i=0;i<n;i++)sb.append("<Override PartName=\"/xl/worksheets/sheet").append(i+1).append(".xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>");
        return sb.append("</Types>").toString();
    }
    private static String sheetXml(Sheet sheet) {
        StringBuilder s=new StringBuilder(8192);
        s.append("<?xml version=\"1.0\"?><worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"><sheetViews><sheetView workbookViewId=\"0\"><pane ySplit=\"1\" topLeftCell=\"A2\" activePane=\"bottomLeft\" state=\"frozen\"/></sheetView></sheetViews><cols>");
        int width=sheet.rows.get(0).size();
        for(int i=1;i<=width;i++)s.append("<col min=\"").append(i).append("\" max=\"").append(i).append("\" width=\"").append(i==3||i==7||i==8||i==9||i==10?44:25).append("\" customWidth=\"1\"/>");
        s.append("</cols><sheetData>");
        for(int r=0;r<sheet.rows.size();r++) {
            s.append("<row r=\"").append(r+1).append("\" ht=\"").append(r==0?27:19).append("\" customHeight=\"1\">");
            List<Object> values=sheet.rows.get(r);
            for(int c=0;c<values.size();c++) {
                Object value=values.get(c);if(value==null)continue;
                String coord=column(c+1)+(r+1);
                if(value instanceof Number n) s.append("<c r=\"").append(coord).append("\"><v>").append(n).append("</v></c>");
                else if(value instanceof Boolean b) s.append("<c r=\"").append(coord).append("\" t=\"b\"><v>").append(b?1:0).append("</v></c>");
                else {String val=String.valueOf(value);if(val.length()>32767)val=val.substring(0,32767);
                    s.append("<c r=\"").append(coord).append("\" s=\"").append(r==0?1:0).append("\" t=\"inlineStr\"><is><t xml:space=\"preserve\">").append(esc(val)).append("</t></is></c>");}
            }
            s.append("</row>");
        }
        s.append("</sheetData><autoFilter ref=\"A1:").append(column(width)).append(Math.max(1,sheet.rows.size())).append("\"/></worksheet>");
        return s.toString();
    }
    private static String column(int n) {StringBuilder b=new StringBuilder();while(n>0){n--;b.insert(0,(char)('A'+n%26));n/=26;}return b.toString();}
    private static String esc(String str) {StringBuilder b=new StringBuilder();for(int i=0;i<str.length();i++){char c=str.charAt(i);if(c=='&')b.append("&amp;");else if(c=='<')b.append("&lt;");else if(c=='>')b.append("&gt;");else if(c=='\"')b.append("&quot;");else if(c=='\'')b.append("&apos;");else if(c==9||c==10||c==13||c>=32&&!(c>=0xD800&&c<=0xDFFF))b.append(c);else if(Character.isHighSurrogate(c)&&i+1<str.length()&&Character.isLowSurrogate(str.charAt(i+1)))b.append(c).append(str.charAt(++i));}return b.toString();}
    private static void put(ZipOutputStream z,String name,String val)throws IOException {z.putNextEntry(new ZipEntry(name));z.write(val.getBytes(StandardCharsets.UTF_8));z.closeEntry();}
}
