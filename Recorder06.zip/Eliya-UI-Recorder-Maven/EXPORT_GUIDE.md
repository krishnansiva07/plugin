# Automation export v3 — quick reference

### JSON

`steps` describes what to do in order. `elements` is the reusable locator repository. A step's `element` is an ID, not a duplicated DOM tree. For a step with a `value`, use `sendKeys` or `fill` as appropriate. Look up the ID in `elements[]` for alternative XPaths and CSS.

Example:

```json
{
  "steps": [
    {"step":1,"action":"navigate","url":"https://example.test/login"},
    {"step":2,"action":"fill","page":"https://example.test/login","element":"E001","description":"Type into username","value":"demo","xpath":"//input[@name='username']"}
  ],
  "elements": [
    {"id":"E001","tag":"input","attributes":{"name":"username"},
      "locators":{"xpaths":[{"strategy":"xpath","value":"//input[@name='username']","unique":true}],"css":[]}}
  ]
}
```

The example above is illustrative; the actual export also contains summary and optional parent/child information.

### Excel

- **Test Steps**: human-readable workflow with XPath 1/2/3, primary CSS, input/state and page URL.
- **Element Locators**: one row per unique element with all locator alternatives, ID/name/testid, parent and children.
- **Page Flow**: navigation and actions in a chronological list.

### Usage with Selenium Java

```java
By locator = By.xpath("//input[@name='username']");
driver.findElement(locator).sendKeys("demo");
```

If XPath 1 is missing or unstable, use XPath 2/3 from Excel or the `elements[].locators.xpaths` array. In a shadow root, use shadow-aware locators instead of XPath. Always check uniqueness and visibility at test runtime.
