# ELIYA64 — Fast Interactive Terminal & Agent Context Release Candidate

> **Release type:** source ZIP for Java 17 / Spring Boot. Not a prebuilt JAR and **not production certified**. A full Maven build, provider-connected Agent run, real Windows/macOS execution, and quantitative OpenCode comparison remain **unverified** because this build container cannot resolve Maven Central. Use disposable workspaces first.

## Scope implemented from the eight-phase plan

| Phase | Changes in this source release | Verification |
|---|---|---|
| 1. Real-time Terminal | `GET /api/terminal/sessions/{id}/events` emits independent SSE updates for the selected Terminal. Bounded viewer count (8), bounded per-viewer event buffer (256), heartbeats, reconnect and snapshot reconciliation. Backend Agent workers do not wait for a slow browser. | Java 17 isolated service/controller compile, browser SSE-frame parse smoke. **Live Spring transport not verified.** |
| 2. Incremental UI rendering | Text fragments append directly to one text node; unchanged conversation/tool nodes remain mounted. Only structural updates rebuild the transcript. Streaming output is readable plain text, formatted as Markdown after completion. Periodic poll reduced from 1.6 s to 8 s as fallback. | Mock Chromium DOM preservation, rapid-token loop, existing Terminal browser suites. |
| 3. Clarifications at bottom | Fixed, scroll-independent question dock immediately above composer. Suggested options, custom typed answer, Enter-to-answer and Shift+Enter newline. The normal Terminal input answers the active clarification rather than putting it in the instruction queue. Agent UI adds a typed custom-answer option and Enter handling. | Browser three-answer paths; Java 17 question service smoke. |
| 4. Agent speed | Reuses existing direct read-only Git status routing, cached symbol/evidence retrieval, bounded parallel tools and workspace locks. Removal of Terminal-wide repaint overhead and redundant prompt evidence improves responsiveness, **but no broad Agent wall-clock improvement has been established.** | Existing planning, indexing and multi-root safety suites pass. |
| 5. Event persistence | Streaming events use bounded nonblocking queues; JSON checkpoints retain the newest 80 action events while the redacted paginated `.actions.jsonl` journal stores older actions. During token-only runs, disk checkpoints are throttled to at most one every ~2 seconds (plus completion). | Isolated Terminal queue/service smoke and action-history browser smoke. |
| 6. Token/context optimization | Prunes *exact, long, repeated outputs from the same tool* while retaining the most recent full result, unique results and every user message. Existing model-aware reserves, compaction, cache reuse and provider-reported token ledger remain unchanged. **No per-task token quotas.** | New Java 17 compaction smoke, existing token ledger and context suite. |
| 7. Recovery/reliability | Clarification event is sent immediately on `ask_user` instead of waiting for status polling; typed Git repository choices are matched only to discovered roots. Typed recovery/plan guidance in Terminal continues the existing task as a linked authorized turn. Queue/rollback/approval gates remain in effect. | Java 17 question/safety smokes; browser option/custom/recovery routes. |
| 8. Regression verification | Existing 60 JS tests, Java 17 isolated typecheck and queue lifecycle, six Chromium mock suites, workspace/indexing, plan relevance, role contracts and safety checks were exercised. | See matrix below and run the Maven commands locally. |

### Recommended smoke checklist (Windows / Mac)

1. Extract the ZIP to a fresh directory. Install **Java 17** and Maven 3.9+ or allow the included Maven wrapper to download its distribution and dependencies.
2. Windows: `mvnw.cmd clean verify -Pfull-tests` (or `mvnw.cmd clean package` for the normal release build). macOS/Linux: `./mvnw clean verify -Pfull-tests`. These commands must succeed on your machine before use on important codebases.
3. Launch `run.bat` (Windows) or `./run.sh` (macOS/Linux). Confirm the UI binds to **127.0.0.1:8090** and not a public interface.
4. Start an Agent Terminal with a disposable Git repo. Confirm actions and partial text appear without 1.6-second bursts. Expand a tool output and verify it remains open while new events arrive.
5. Create two Git repos inside one workspace and ask `git status`. Select one with the listed button; repeat using its exact absolute path typed in the bottom question field, then using the main composer. Check that no other repo is modified.
6. Send instructions while a task is running, reorder/remove pending work, stop and resume. Confirm overlapping workspace modifications never execute concurrently.
7. Disconnect/reconnect the browser while the Agent runs. Verify existing action history and answer are restored without lost/duplicated visible text. Repeat minimize/restore, tab close/reopen, and Agent UI plan handoff.
8. Use Chat, Agent and Terminal against the same 3,000-file test workspace; verify response quality and token ledger. Compare with ELIYA63 on an identical workspace/model; **do not claim a speedup without live A/B evidence**.

### Offline checks performed for this package

- `node --test src/test/js/*.test.js` — **60/60 passed**.
- `bash qa/eliya52-terminal-typecheck.sh` — **passed** isolated Java 17 Terminal backend/controller compile, FIFO queue, interruption, per-workspace serialization, concurrency, action archive and approval handoff.
- `bash qa/eliya64-context-question-smoke.sh` — **passed** exact tool-result dedup, user evidence protection, idempotence, custom clarification, immediate question notification and stale-answer rejection.
- `python qa/eliya64-fast-terminal-browser.py` — **passed** SSE CRLF frame parsing, uninterrupted token append, DOM preservation, live action display, pinned question UI, option/typed/Enter/composer replies; in mocked headless Chromium, **500 synthetic token deltas took 61–76 ms**. This is an isolated local UI benchmark, **not** provider output speed, network latency or comparison against OpenCode.
- Existing mocked Chromium suites passed: `qa/eliya52-browser-ui-smoke.py`, `qa/eliya58-terminal-queue-browser.py`, `qa/eliya59-terminal-ui-browser.py`, `qa/eliya61-clarification-ui-browser.py`, `qa/eliya62-terminal-actions-browser.py`.
- Existing offline suites passed: `qa/eliya52-hardening/run.sh`, `qa/offline-smoke/run.sh`, `qa/agent-reliability/run.sh` (113 Java source files parsed; syntax only), `qa/plan-relevance/run.sh`, `qa/workspace-boundaries/run.sh`, `qa/workspace-planning/run.sh`, `qa/token-usage-smoke/run.sh`, `qa/context-v35-smoke/run.sh`, `qa/completion-report-smoke/run.sh`, `qa/intelligence-smoke/run.sh`, `qa/confluence-smoke/run.sh`, `qa/native-agent-policy-smoke.sh`, `qa/chat-continuation-smoke.sh`, `qa/markdown-ui-smoke/run.cjs`.
- Full Maven package: **FAILED TO START** due to absent Maven and DNS failure for `repo.maven.apache.org`. This environment did not compile the complete dependency graph, run JUnit under Maven or connect to a live model provider. **No rebuilt JAR is included.**

### Design details and known limits

- The Terminal updates streamed **Agent actions** in real time. The current Agent backend still produces its full *final prose answer* after completing Agent execution, rather than token-by-token model deltas inside the planning/executor calls. This release cannot make a slow model generate content faster; it eliminates UI refresh lag and exposes tool progress.
- Long sessions retain the current last-400-event in-memory live ring, with durable action pagination stored separately (64 MiB per session maximum). Tool detail contents are capped and credential fields are redacted. If the journal is full, the Terminal warns rather than inventing lost events. The persistence snapshot now retains the last 80 action events to avoid serializing full histories on each checkpoint.
- SSE event viewers are capped; when unavailable, the UI falls back to an 8-second status poll. A dropped/overflowed stream triggers resynchronization from the authoritative session snapshot. Stale event sequence IDs are ignored. Only one stream is maintained for the visible selected tab.
- Old action history still requires clicking **Load earlier actions**; activity prior to the event-journal implementation is not reconstructible.
- `ask_user` custom answers are **guidance**, not deletion approvals or blanket permission for new writes. All existing deletion/rollback and workspace boundary controls remain authoritative.
- No additional Markdown documentation files were introduced. Historical release notes are retained below in this sole `README.md`.

---

# ELIYA63 — Maven compilation fix for AgentService

**Root cause:** ELIYA62 added two consecutive `@Autowired` annotations to the
`wireTerminalQuestions(AgentQuestionService)` setter in `AgentService.java`
(around lines 129–131). Spring's `@Autowired` is not repeatable. Maven therefore
stopped during Java compilation with `Autowired is not a repeatable annotation type`.

**Fix:** Keep one `@org.springframework.beans.factory.annotation.Autowired(required = false)`
annotation and the existing fallback `AgentQuestionService`. No Terminal behavior,
UI or queue logic was changed.

**Regression guard:** `qa/agent-reliability/source-contracts.py` now asserts that
`wireTerminalQuestions` is optionally injected exactly once and scans source
files for adjacent duplicate `@Autowired` declarations. This catches the issue
that a syntax-only Java parse did not catch.

**Validation:** Java 17 syntax parse (113 files), Spring stub compile of the
corrected declaration (and an expected failure with the old duplicate),
60/60 JavaScript tests, Terminal Java 17 typechecks, agent-hardening, plan
relevance, and workspace-boundary suites passed. Full `mvn -DskipTests clean package` must still run on a computer
with Java 17 and working Maven dependencies; it could not be verified here
because the environment has no Maven installation/dependency cache.

---

# ELIYA62 — OpenCode-style visible Agent execution (source release)

ELIYA62 extends ELIYA61 without removing the queue, approvals, multi-repository
workspace selection, model switching, recovery prompts or the dark Terminal.

**Problem fixed:** ELIYA61 placed just the latest 70 action events inside a
collapsed “Live tool activity” panel. Repainting during a live poll also closed
expanded details, and Terminal status retained only a 400-event in-memory window
which was cleared on the next instruction. This made real Agent actions appear hidden.

### What a Terminal user sees

- An **always-visible chronological Agent actions feed** between the conversation
  and the streaming answer. The feed updates during execution (1.6-second polling)
  and remains available after success, failure, or tab reopening.
- Individual steps for workspace indexing, plan preparation, searches, file reads,
  file edits, command executions, MCP tool calls (only when previously enabled and
  explicitly requested), approval requests, validation, retries, and failures.
  Every forwarded Agent tool event shows its actual tool name, description, plan
  step, status (running/success/error/approval), and its event sequence number.
- **Expand a specific tool action** to inspect its arguments and returned output;
  this expansion stays open when the page polls for fresh status. Expanded output
  scrolls without overrunning the whole Terminal. Untrusted tool text is escaped.
- **Load earlier actions** pages backward through the action journal, including
  earlier instructions within the same Terminal tab. Closing and reopening a tab
  does not delete its action history. Java stores activity in a sibling
  `<session-id>.actions.jsonl` file beside existing Terminal session JSON. New
  `GET /api/terminal/sessions/{id}/activity?limit=150&before=<seq>` supports
  server-side cursor pagination. The latest events still appear in the normal
  session payload; no extra provider/model calls are required to show events.
- **Safety:** sensitive names such as `apiKey`, `Authorization`, `password`,
  `token` credentials, and common bearer/API-key literals are redacted in the
  new action journal and session-event display. Agent execution permissions,
  delete approvals, root locks, and rollback rules are unchanged.

The journal is intentionally bounded at approximately **64 MiB per session**;
individual argument/output strings are capped at **24,000 characters** in the
activity view. A warning appears if the bound is reached or a disk write fails.
The trace contains *actual events emitted by AgentService*; it does not pretend
unemitted provider-internal reasoning or OS subprocess activity is observable.
Sessions recorded before this release cannot retroactively reconstruct actions
that the old server already discarded. Their surviving in-memory events still
render. No raw secrets should be pasted into tool commands or prompts.

### Validation and user acceptance scenarios

1. Start an Agent task in Terminal; `Agent actions` appears automatically with no
   collapsed global tool-activity section.
2. Call `read`, `grep`, `bash`, or `edit` and observe start/result events and status.
3. Expand a command to see its actual input and returned stdout/stderr; open
   expansion remains open while later events arrive.
4. Observe planning, model retry, approval and failure events without losing them
   after the final answer displays.
5. Execute a follow-up in the same tab; older events can be loaded from the
   journal by sequence; another tab has a separate journal.
6. Reopen a persisted tab and use `Load earlier actions` to inspect an old task.
7. Place hostile HTML in a mocked provider error; verify it prints as text, not
   injected markup.
8. Check field-name redaction, size-bound warnings, and that event history does
   not hold API keys or provider credentials.
9. Queue/stop/resume, workspace serialization, clarification, and approvals still
   behave exactly as in ELIYA61.
10. Run a live agent, long workspace analysis and Maven/OS execution on a real
    configured Windows or macOS machine (**not validated here**).

Offline checks executed: `node --test src/test/js/*.test.js` (60/60),
`python qa/eliya62-terminal-actions-browser.py` (mocked Chromium),
`python qa/eliya59-terminal-ui-browser.py`,
`python qa/eliya61-clarification-ui-browser.py`,
`python qa/eliya58-terminal-queue-browser.py`,
`bash qa/eliya52-terminal-typecheck.sh` (Java 17 stub typecheck and lifecycle),
`bash qa/agent-reliability/run.sh` (113 source files syntax parsed),
`bash qa/eliya52-hardening/run.sh`, `bash qa/plan-relevance/run.sh`, and
`bash qa/workspace-boundaries/run.sh`.

**Build status:** Updated source only. This environment cannot complete a
Maven dependency-resolving package build or a live model-connected Java
Spring Boot end-to-end run. On your configured development machine run
`mvn clean test package` with Java 17 and complete the live scenarios above
before production use.

---


## ELIYA61 — Terminal readability, repository questions, and recoverable Agent planning

This is the updated ELIYA60 **source** tree, not a new compiled Java JAR. It retains
one README file: this file. No unrelated Git/Skill panels were reintroduced.

### Corrections

- **Dark Terminal Markdown:** readable inline code, code fences, and tables even when
  Chat uses a light theme. The former pale/blank inline code bars were CSS inheritance.
- **Error text:** the Terminal extracts the actual `message` from error payloads rather
  than presenting a Java map such as `{message=...}`.
- **Read-only Git status:** simple `git status` requests use a deterministic read-only
  plan. They no longer have to satisfy a multi-step code-implementation planner.
- **Scoped repository selection:** inspect a bounded number of local folders for `.git`
  directories or worktree `.git` files. Ask which repository to use when there are
  several. When none is discovered, ask for a valid repository path **inside** the
  selected workspace; otherwise suggest switching workspace. Avoid implicit Git
  operations in a guessed repository, and never write to reference workspaces.
- **Clarifications in both modes:** normal Agent UI and Terminal share pending-question
  delivery and response endpoints. Questions distinguish user guidance from approval
  or shell permission. Cancel stops the run. A rejected plan pauses for user guidance
  and allows one additional bounded, validated retry without workspace modifications.
- **Recovery after a failed execution:** the Terminal keeps the tab open and presents
  the failure with choices to provide guidance, retry the original request, or close
  the task. A user-authorized retry opens a linked turn in the SAME Terminal tab,
  only after the previous worker releases its lock. Pending queued edits remain
  paused for review. Ordinary UI Agent shows a guided recovery composer for
  preparing the next Agent instruction, never executing it without Send.
- **No blind fallback:** a guided plan that still fails deterministic validation does
  not automatically become executable. The user can revise the request in the same
  conversation or review the run report.

### Local verification / acceptance

1. Terminal renders `Bearer`, `Authorization`, and `X-API-Key` as visible inline code.
2. Terminal renders ordinary code fences and Markdown tables with readable contrast.
3. Bare `git status` is classified as read-only; `git reset --hard` is not.
4. One Git root (including a linked worktree) is selected without guessing elsewhere.
5. Multiple Git roots trigger an interactive choice in the same Terminal or Agent UI.
6. A workspace without Git asks for a repository path rather than fabricating results.
7. A provided path outside the selected root is refused.
8. A plan-invalid rejection asks for retry/guidance without performing file changes.
9. Clarification response remains associated with the active Agent run, not a sibling tab.
10. A failed Terminal instruction shows recovery choices and does not discard the tab.
11. A correction from a failed Terminal instruction continues in the same tab, not a
    new session or indefinitely paused queue.
12. A failed ordinary Agent run offers a recovery draft that needs explicit Send.
13. The Terminal queue, stop/resume, rollback, approval and workspace locks remain intact.

Executed offline: `qa/agent-reliability/AgentGitScopeSmoke.java` (javac 17),
`qa/eliya61-clarification-ui-browser.py` (mocked Chromium),
`qa/eliya59-terminal-ui-browser.py`, `qa/eliya58-terminal-queue-browser.py`,
`qa/eliya52-terminal-typecheck.sh`, `qa/agent-reliability/run.sh`,
`qa/plan-relevance/run.sh`, `qa/offline-smoke/run.sh`.

**Validation limits:** no complete Maven dependency resolution, no rebuilt JAR,
no live model provider or Git execution from Windows/macOS; those need testing in the
actual runtime. The plan-correction question is bounded and a failed real tool/provider
operation may still require the user to submit a follow-up run rather than resuming
inside a suspended Java call. No claim of arbitrary failure auto-recovery is made.


# ELIYA60 — Persistent Terminal Conversation Fix (Java 17)

**Package:** updated ELIYA59 source, not a prebuilt JAR. There is **exactly one README.md** in this distribution. Version 58's session queue, same-root workspace locks, stop/interrupt safeguards, and Agent plan handoff remain part of this release.

## Fixed in ELIYA60 — “Terminal must have a new conversation”

**Root cause:** a Terminal session owns an independent persistent conversation. When queued or resumed instructions reused that conversation, the execution worker unnecessarily called `FileService.copyForTerminal(source, destination)` even when both IDs were the same. That API correctly prohibits self-copying and threw the error, causing a valid follow-up instruction to fail before the Agent started. The frontend also sent the active *Chat* conversation ID when submitting later Terminal turns.

**Fix:** source Chat attachments transfer **once** when creating an independent Terminal session, never again on a follow-up, queued, edited, resumed, or same-conversation turn. Terminal continuation requests use the tab's `conversationId`. The original self-copy protection remains intact; no change to workspace boundaries, deletion permissions, or queue serialization. The first Terminal turn still transfers Chat evidence when required.

**Regression scenarios verified:** (1) initial Chat → Terminal attachment transfer is invoked once; (2) immediate follow-up in the existing Terminal conversation runs; (3) queued turns execute using the same conversation ID; (4) failed/stopped and resumed queued turns continue without self-copy; (5) independent Terminal tabs still have unique conversations and transfer their own Chat evidence once; (6) multiple roots and same-root synchronization work as before. Tested with the Java 17 stub lifecycle harness, 60 JavaScript assertions and 25 mocked Chromium UI assertions. Live Spring Boot/provider/OS execution remains unverified because the Maven build cannot run here.

## The OpenCode-style Terminal experience

The dedicated Terminal is a dark, keyboard-first Agent workspace. It is not a raw operating-system shell: normal-language instructions call Eliya's Agent planning, file, testing and command tools, subject to the existing workspace and permission policy. For example, ask “analyse this workspace”, “create a Git branch in the frontend repo”, “run the tests”, “compare with Reference [LegacySelenium]”, or “fix the failure and verify”. Git actions, agent definitions and other work are requested in Terminal as tasks rather than through separate Git and Skill Studio panels. **Git and skill endpoints are retained in the backend**, but the corresponding Terminal form panels are removed. Existing tool gating and approvals remain in effect.

- **Enter** sends the instruction; **Shift+Enter** inserts a newline. The normal Send button and automatic instruction queue remain available. The queue runs sequentially within the same tab; overlapping workspaces still observe global locks.
- **New tab** creates an independent conversation. Every persisted tab has its own × close control. Closing a tab hides it from this browser; it **does not cancel a running Agent or delete its history**. Use **Reopen closed tabs** to restore hidden tabs, or **Stop task** to stop an executing task.
- The header always exposes **Minimize**, **Maximize/Restore**, and **Close**. Minimize uses the floating Restore control; Close hides the dock and Home's Terminal button opens it again.
- **Session setup** is collapsed when a Home workspace is already available. The workspace is displayed as a path field; enter a Windows/macOS/Linux absolute directory and use **Use path**, or type `/workspace <absolute path>` in Terminal. There is no visible “Workspace for next session” select dropdown. The current executing turn is never redirected mid-run.
- **References** are checkboxes labeled with the same read-only aliases as Home; **Add reference path and alias** opens Home's existing folder path dialog (max five references). A tab's pending instruction captures its selected references.
- **Terminal model** is an editable field backed by the existing model library (pick or type a custom model ID). No Duplicate tab or Fork context actions are shown.
- The transcript, plan details, token usage, clarification responses, queue editing/reordering/removal and tool activity remain inside the Terminal. The main Home Chat/Agent UI and independent session monitor continue to work.

## Chat/Agent models — four distinct editable choices

Settings now has a proper **dropdown + editable custom ID** for **Chat**, **Agentic**, **Chat Vision** and **Agent Vision**, rather than exposing a long comma-delimited Chat model string. In Chat mode, the compact bar displays **Chat model** and **Vision (optional)**; in Agent mode it displays **Agent model** and **Vision (optional)**.

A Chat Vision model is optional. If selected with an image attachment, the backend's existing dedicated vision-document analyser first extracts grounded image evidence using the Chat Vision model; the **Chat text model then writes the final response**. If Chat Vision is disabled, an image-capable Chat model can still receive image attachments directly. When image extraction fails outright, Chat reports the failure rather than claiming the content was read. Agent continues to use its **separate Agent Vision** model. Vision endpoint/API key overrides still apply; credentials are never embedded in persisted terminal queue JSON.

**Agent mode still shows its user-reviewed plan and the “Execute in Terminal” action at plan approval.** That handoff retains the plan, workspace and reference constraints. Terminal runs the approved handoff using its existing detached Agent pathway; this release does not remove Agent approval from ordinary Agent mode.

## Validated acceptance scenarios

| # | Scenario | Result in this environment |
|---|---|---|
| 1 | Open dark Terminal from Home | Chromium mocked pass |
| 2 | Minimize and use Restore | Chromium mocked pass |
| 3 | Maximize and restore normal size | Chromium mocked pass |
| 4 | Close dock and reopen from Home | Chromium mocked pass |
| 5 | Use Enter to send | Chromium mocked pass |
| 6 | Use Shift+Enter for multiline input | Chromium mocked pass |
| 7 | Queue a follow-up while Agent is active | Chromium mocked pass |
| 8 | Edit/reorder/remove queued tasks | Previous Chromium and Java stub suite pass |
| 9 | Interrupt and resume paused queue | Previous Chromium and Java stub suite pass |
| 10 | Create new independent session tab | Chromium mocked pass |
| 11 | Close one tab without removing the execution | Chromium UI + code path pass; live provider pending |
| 12 | Reopen closed session tabs | Chromium mocked pass |
| 13 | Remove Git and Agent/Skill Studio panels | Chromium DOM assertions pass |
| 14 | Remove Duplicate/Fork buttons | Chromium DOM assertions pass |
| 15 | Remove visible “workspace for next session” selector | Chromium DOM visibility pass |
| 16 | Preserve path-based workspace switching | UI/path code review; real filesystem pending |
| 17 | Display/select reference aliases | Chromium payload assertions pass |
| 18 | Type a custom Terminal model | Chromium payload assertions pass |
| 19 | Use settings dropdown plus custom model ID | Chromium mocked pass |
| 20 | Separate Chat text and Chat Vision models in request | Chromium request-payload pass |
| 21 | Extract attached image with Chat Vision before text completion | Backend code-path review and Java syntax parser pass; live provider pending |
| 22 | Preserve Agent plan approval → Terminal transfer | Chromium mocked pass |
| 23 | Preview persisted HTML artifacts | Previous Chromium mocked pass |
| 24 | Java 17 Terminal queue lifecycle and workspace locks | Java stub typecheck/FIFO suites pass |
| 25 | Deletion approval, rollback and workspace isolation | Offline Java security suites pass |

**Offline checks executed:** Browser: `python qa/eliya59-terminal-ui-browser.py`, `python qa/eliya52-browser-ui-smoke.py`, and `python qa/eliya58-terminal-queue-browser.py`. JavaScript: `node qa/markdown-ui-smoke/run.cjs` and `node qa/completion-report-smoke/ui.cjs`. Java 17/source checks: `bash qa/eliya52-terminal-typecheck.sh`, `bash qa/agent-reliability/run.sh`, `bash qa/eliya52-hardening/run.sh`, `bash qa/offline-smoke/run.sh`, `bash qa/native-agent-policy-smoke.sh`, `bash qa/chat-continuation-smoke.sh`, `bash qa/workspace-boundaries/run.sh`, `bash qa/token-usage-smoke/run.sh`, and `bash qa/plan-relevance/run.sh`.

**Not validated:** a full Maven dependency-resolving build, a provider-connected image extraction, real Git/OS shell execution on Windows or macOS, and multi-hour real-world terminal execution. This environment has Java 17 but no usable Maven distribution/dependency resolution. The parser accepted Java sources; that is **not** equivalent to a complete Spring Boot compile. Avoid treating this ZIP as a certified production build.

To build on a configured Windows/Mac machine with Java 17 and Maven connectivity: `mvn -DskipTests package` from the `ELIYA` directory. The existing Maven wrapper may also work if its download endpoints are reachable. Exercise the acceptance scenarios on a disposable workspace before pointing the Agent at production repositories.

---

## Previous release reference (ELIYA58)

Eliya is a local Java/Spring Boot workspace assistant for Chat, planned Agent execution, Terminal Agent sessions, code migration, testing, documentation and evidence-backed analysis. It works with a selected writable local workspace plus up to five separately named read-only references. The terminal reuses the **existing Agent planner, tool loop and verification** but skips **plan approval**. Ordinary Agent mode retains the original plan approval flow.

> **Release state:** tested source release candidate, **not production certified**. This package does not include a rebuilt JAR. The available Java 17 source-parser/offline smoke tests and JavaScript tests are documented below; a full Spring Boot Maven build, provider-connected execution, actual Windows terminal behavior, and browser end-to-end verification have **not** been completed in the build environment. Test first on disposable repositories.

## New in ELIYA58 — interactive queued instructions

**Send instructions while a Terminal Agent is still running.** Additional messages in the same tab enter a bounded **FIFO queue** (up to 25 per tab, 100 total), not a concurrent Agent run. Messages are displayed under **Pending instructions**, with **Edit**, **Move up/down**, and **Remove** controls. After the running turn succeeds, Eliya automatically starts the next instruction in the *same archived conversation*. Each queued item captures its own primary workspace, read-only references, chosen model and exact prompt; changing the UI workspace does not redirect an already queued item.

- **Clarification priority:** Respond using the Agent's clarification choice buttons and response field, which go directly to the active run. New independent instructions in the composer are queued, never mistaken for a clarification answer.
- **Stop:** Stops/cancels the current instruction and **pauses** its remaining queue. A failure, blocked plan or interruption also pauses pending instructions; there is **no unattended cascade after an unsuccessful task**. **Resume pending instructions** explicitly restarts the queue after the user reviews the situation.
- **Interrupt → next:** With a pending instruction, explicitly cancel the current work and proceed to the next queued item **only after the current worker releases the session lock**. This does not forcibly terminate unrelated OS processes, guarantee transactional rollback or bypass existing file-deletion approvals.
- **Workspace safety:** Existing canonical parent/child directory locks still serialize overlapping roots, including across tabs. Nonoverlapping roots in independent tabs can operate concurrently. Do not use a workspace switch to sidestep a safety lock.
- **Restart behavior:** Queue **metadata and text** are persisted with terminal history. **API keys and provider configurations are not persisted in queue JSON**. After Java restarts the queue is paused, and the user must explicitly press **Resume** with their current model configuration. The previous running process is never silently resumed.
- **Visibility:** Queue counts appear in the terminal tab, execution monitor and in-tab panel. A queue item can be removed until it is dequeued for execution; after that, use Stop/Interrupt instead.

**Validation performed**: 59 JavaScript regression tests passed; the Java 17 stub-based Terminal/Controller typecheck and deterministic FIFO lifecycle test passed (edit, reorder, remove, failure pause, Stop, Resume, Interrupt → next and no in-session overlap); mocked Chromium queue interaction passed. This is **source plus offline/mock evidence**, not a claim of live provider execution or a rebuilt application JAR.

Queue acceptance scenarios, with the same distinction between mocked/offline and live validation:

| # | Scenario | Expected result | Verified here |
| --- | --- | --- | --- |
| 1 | Send B and C while A is executing | B/C remain queued; no parallel mutation in the same tab | Java stub workflow + Chromium mock |
| 2 | Edit B, move C above B | Run C, then edited B | Java stub workflow + Chromium mock |
| 3 | Remove a queued item | Removed item never runs | Java stub workflow + Chromium mock |
| 4 | Switch workspace while A runs, then queue D | A uses its original root; D records the newly selected root | Chromium payload mock + backend metadata checks |
| 5 | Answer an active Agent clarification | Answer sent to active Agent; existing queue unaffected | Existing clarification path and Java typecheck; provider integration pending |
| 6 | A fails / produces blocked plan | Queue pauses without auto-run | Java stub workflow (failure); real blocked-plan flow pending |
| 7 | Stop A with pending B | B stays paused until user resumes | Java stub workflow |
| 8 | Interrupt A and proceed to B | B waits for current worker to end | Java stub workflow + Chromium mock |
| 9 | Resume paused queue | Prompts execute in saved order with new provider configuration | Java stub workflow + Chromium mock |
| 10 | Two tabs on overlapping roots | Existing global workspace scheduler serializes writes | Existing scheduler + Java stub typecheck; real multi-tab run pending |
| 11 | Two tabs on isolated roots | Independent concurrency allowed | Existing scheduler tests; real multi-tab run pending |
| 12 | Restart server with queued tasks | History retained and queue paused; resume requires current credentials | Code-level validation; actual restart integration pending |
| 13 | Send near completion | No overlap while preceding worker releases workspace | Lock inspection + Java stub lifecycle; provider timing stress pending |
| 14 | Queue input while Terminal minimized | Backend continues independently; restored UI shows current queue | Existing detached sessions/monitor contracts; OS/browser reload pending |
| 15 | Windows/macOS with live configured model | Compile, execute, edit/queue/interrupt, verify files | **Not validated here** |

Run queue-specific checks:

```bash
node --test src/test/js/*.test.js
bash qa/eliya52-terminal-typecheck.sh
python qa/eliya58-terminal-queue-browser.py
python qa/eliya52-browser-ui-smoke.py
```

## Requirements and installation

- Java **17** (project target), network or pre-provisioned Maven 3.9+ and Maven Central dependencies, modern Chrome for browser workflows.
- For restricted corporate machines, pre-populate the Maven dependency cache or build the JAR on an approved build machine. The included `mvnw` / `mvnw.cmd` bootstraps Maven when available; it is **not** an offline dependency bundle.
- Set application/provider settings through Eliya's Settings UI, and select/map a local workspace. Never embed API keys in a workspace prompt or Git branch name.

```bash
# Linux/macOS — from project root
./mvnw -Pfull-tests clean verify
java -jar target/eliya.jar

# Frontend tests, independent of Maven
node --check src/main/resources/static/app.js
node --test src/test/js/*.test.js
bash qa/eliya52-terminal-typecheck.sh
bash qa/eliya52-hardening/run.sh
# Optional Chromium smoke test with mocked APIs (Python Playwright + installed Chromium required):
python qa/eliya52-browser-ui-smoke.py

# Additional offline Java/safety/UI smoke suites
bash qa/offline-smoke/run.sh
bash qa/workspace-boundaries/run.sh
bash qa/agent-reliability/run.sh
bash qa/completion-report-smoke/run.sh
bash qa/plan-relevance/run.sh
bash qa/confluence-smoke/run.sh
bash qa/intelligence-smoke/run.sh
```

Windows: run `mvnw.cmd -Pfull-tests clean verify`, then `java -jar target\\eliya.jar`. Check `src/main/resources/application.properties` for environment-specific persistence and server configuration. This source package does not assert that it was tested with live Windows/PowerShell processes.

## Work modes

| Mode | Behavior |
| --- | --- |
| Chat | Fast analysis, MCP-backed research when explicitly requested, requirement comparisons, prompt and plan drafting. Chat does not automatically apply changes. |
| Agent | Existing planner, validation, user-reviewed plan approval, tool execution and verification. |
| Terminal | Separate agentic sessions, **same existing planner and tools**, auto-execution after planning without **plan approval**, live progress/output, stop, history, interactive clarification and planning-failure recovery. |

### Independent Terminal workspaces, tabs and models

**Launch Terminal** offers a separate local-workspace dropdown, per-session read-only references (up to five), and a model choice. Workspaces are discovered from previously mapped local projects; selecting one in Terminal does not change Chat's workspace. Each started session captures those identifiers and runs in a separate conversation.

**New tab** opens a fresh, independent Terminal conversation and workspace configuration. The standalone Duplicate tab and Fork context controls were removed in ELIYA59; use New tab instead. Existing tabs retain their own conversation histories, queued instructions and safety boundaries.

Generated Chat instructions include **Execute in Terminal**. On the ordinary Agent plan-approval screen, **Execute in Terminal** saves any edited plan, then uses a distinct server-side `TRANSFER` decision to relinquish the original pending Agent approval before starting a separate Terminal. The destination consumes the exact transferred step texts without generating a second plan. It never resolves the original plan approval as `ONCE` or `RUN`. Workspace and reference selection are preserved from the current source Agent UI; authorized source-conversation uploads are copied to the destination conversation with new IDs and independent storage (limits: 30 files / 100 MB total / 25 MB per file). If that transfer fails, the Terminal reports a failure instead of silently ignoring the evidence.

Terminal uses a bounded worker pool (up to twelve active sessions). Tasks in the same **or overlapping parent/child canonical workspace paths** are serialized; separate nonoverlapping workspaces may execute concurrently. Pending runs are admitted asynchronously and do not occupy worker threads while waiting. Separate Git worktrees provide stronger file isolation. The in-process overlap scheduler prevents simultaneously active Terminal writers in parent/child roots. It is not a cross-process or external-editor filesystem lock; use Git worktrees for reliable isolation. The application uses the existing planner and Agent verification tools; it does not waive deletion approvals or filesystem permissions.


### Token usage for each Agent or Terminal activity

Eliya now shows a **Token usage by activity** table at the end of completed, failed or stopped
Agent and Terminal executions. The same information is stored with the run and available
again from its history. It groups model calls by planning, validation, recovery, execution
turn/step, subagent reviews and context compaction, with **input, output and total tokens**,
call counts, and a run-wide total. Model context estimates and compaction savings are not
represented as actual billed tokens.

The client reads provider-reported token usage from supported OpenAI-compatible completion
responses. Some providers do not return usage metrics. Eliya marks those calls **Not reported**;
reported totals are then lower bounds, *not* assertions that missing calls consumed zero tokens.
Cached tokens are a subset of reported input tokens, not an amount to add to the total.
Shell, Git and test tool invocations use no model tokens by themselves, although the model
may use tokens when preparing commands and interpreting their output. The per-activity ledger
survives application restart, subject to the normal run-history retention policy.

Verification: `bash qa/token-usage-smoke/run.sh` and `node --test src/test/js/token-usage.test.js`.
This release does not yet expose authoritative token metrics for plain Chat streaming or
arbitrary external MCP provider/model calls when those APIs omit usage details.

### Global live execution monitor

The header's **Execution Monitor** remains available from other Eliya screens, even if the Terminal dock is hidden. It displays active counts, waiting-input notifications, per-session status, planner phase, and verified-step counts/progress when available. Clicking an entry opens the session's detailed events/output. The monitor also notifies on transitions to completion/failure. Progress is **step accounting**, not an estimate of remaining wall-clock time. The Java application must remain running for background work; after restart, interrupted processes are reported as interrupted instead of falsely resumed.

### Multi-repository Git support

1. Map a workspace containing one or more local Git repositories (for example `workspace/frontend`, `workspace/backend`, `workspace/qa`).
2. Select **Terminal → Git repositories**. Eliya scans Git roots under the workspace, while pruning `.git`, dependency and build trees.
3. Choose the exact repository, enter a new branch name, then choose **Create branch** or **Create isolated worktree**.
4. **Create branch** creates the branch without changing the existing checkout; it does not automatically switch an active terminal or overwrite files. **Create isolated worktree** creates a fresh branch and checkout in `./data/terminal-worktrees` (customizable with `-Deliya.terminal.worktrees=...`) and maps it to a separate local project for the **next** Terminal launch. The original current checkout stays untouched.
5. Different worktree project IDs can execute concurrently. Agents targeting the exact same resolved root share a fair execution lane. Reference projects remain read-only.

Git is executed through `ProcessBuilder` with separate arguments, never by interpolating user-provided branch names into a shell command. Repository selection uses resolved paths and exact `git rev-parse --show-toplevel` verification. Invalid names, traversal, symbolic-link escapes and duplicate local branches are rejected. An already-existing branch must be selected or managed outside the create-branch flow. Git worktree integration requires the selected repository to have an initial commit and Git installed on the host. Cleanup/merge/rebase of completed worktrees is currently manual.

### Clarification during Terminal execution

When an Agent encounters a genuine unresolved requirement, it can call the `ask_user` tool with a question and meaningful options. Only the corresponding session waits. The Terminal UI displays the question, offers the model's choices (for example OK / Continue / Cancel) and allows optional details. The response is returned to the Agent's tool loop. **Cancel** cancels the affected run. The UI also shows an explicit correction/retry path if a plan fails validation before recorded workspace modifications; choosing Continue starts a linked new run, not an unsafe fake continuation of the old process.

**Plan approval is skipped only for Terminal**. Existing deletion protections, workspace boundaries and dedicated risky-operation safeguards are separate policies and are not bypassed by Terminal mode. A shell process runs under the local OS user's account; selecting a workspace is not equivalent to secure process sandboxing.

### RC3 reliability and usability additions

- **Immutable structured Chat artifact vault:** whenever an assistant message with `PROJECT_FILE_START`/`PROJECT_FILE_END` proposals is saved, copies are archived under `./data/assistant-artifacts` using an independent message-ID index and random storage names. **Saved files** restores previews even if the current UI content becomes unavailable. Preview is script-disabled for HTML and remains read-only; proposals never auto-write into a workspace. Bounds: 64 proposals / 1.5 MB each / 12 MB total per response.
- **Reliable conversation identity:** each Terminal reserves its actual database conversation ID before staging a transferred plan or copying uploads; the previous random-ID mismatch could prevent document-dependent execution from starting.
- **Nonblocking overlapping-root scheduling:** parent/child workspace paths share a single writer lane. Queued same-workspace sessions do not occupy all worker threads, leaving unrelated workspaces responsive. This protects only Eliya Terminal sessions within one Java process, not external editors or another Eliya JVM.
- **Agent/Skill definitions (backend):** compatible `.agents`, `.opencode` or `.claude` definition creation remains implemented with path and name validation. The standalone Skill Studio panel was removed from Terminal in ELIYA59; use agent instructions and permitted backend capabilities. Advanced test/evaluation and versioning remain pending.
- **Git review:** the selected repository can display `git status`, working diff statistics and staged diff statistics. This is read-only; merge/rebase/conflict resolution remains a separate action.
- **Cross-platform CI:** a Java 17 compilation/test matrix for Windows and macOS has been added to the GitHub Actions workflow (runs only in connected CI, not in this environment).

### Agents, skills and related conventions

Agent instructions and skills are discovered from compatible Eliya, OpenCode and Claude locations such as `AGENTS.md`, `CLAUDE.md`, `.agents/agents`, `.agents/skills`, `.opencode/agent(s)`, `.opencode/skill(s)`, `.claude/agents`, `.claude/skills` and related command/rule folders. Detection is **inventory / compatible format discovery**, not guaranteed CLI interoperability. Untrusted project instructions are not automatically granted permissions. Creating a code reviewer skill remains available through Agent or Terminal instructions and the existing file tools.

Eliya also contains the existing workspace indexing, hybrid retrieval, source-impact tracing, partial LSP integration, file rollback/checkpoints, saved task progress, large-task ledgers, subagent tools, Prompt Factory, Confluence Composer and artifact preview. HTML is previewed in a script-disabled sandboxed iframe. Files are not silently created solely because Chat displayed a proposed artifact: distinguish a generated proposal from an actual saved workspace file.

## Security and operations

- Agent write operations must respect the selected workspace and explicitly writable resources. Selected references are read-only. Workspace paths must be narrow project folders, not entire drives, home directories or operating-system roots.
- MCP activation is explicit; a user must enable MCP and request MCP access in their prompt. Existing MCP permission checks remain authoritative.
- Do not use untrusted project prompts to request shell execution in privileged environments. Git commands and shell tools execute with the privileges of the local application process.
- Terminal session history, including session model identifiers (but not the model API key), is persisted under `./data/terminal-sessions`, agent runs under `./data/agent-runs` (override with documented Java properties where supported). Source snapshots/checkpoints and generated artifacts may use additional data subdirectories. Protect this local data and keep it out of your Git repositories.
- Concurrent sessions modifying **different repository worktrees** are safe from direct same-file overwrites by directory isolation. There is no cross-process global filesystem lock or transactional Git merge in this release.
- The model/provider API key is not included in saved Terminal session snapshots; sensitive data can still appear in user prompts or tool output, so handle session logs appropriately.

## Validation and release gates

| Gate | Result in this environment |
| --- | --- |
| `node --check` JavaScript source | Passed |
| JavaScript regression tests | **55 passed, zero failed** |
| Java 17 compiler parser of all 111 main source files | Passed **syntax only** |
| Java 17 standalone integration: multi-repository Git, branch/worktree/review, Studio definitions, artifact archive and security rejection | Passed with real disposable Git repositories and minimal external dependency stubs |
| Java 17 `--release 17` typecheck for Terminal Controller/Session/Discovery/Approval | Passed with dependency-compatible stubs; not a full project build |
| Approval handoff smoke: correct plan-only decision, wrong-run rejection, double-execution prevention | Passed |
| Chromium Browser UI: workspace, references, launch, tabs, monitor, saved artifacts and Agent handoff | Passed with **mocked backend APIs**; does not establish live Spring Boot integration |
| New UI walkthrough: maximize, minimize, restore, independent tab, multi-turn view and HTML iframe source/sandbox | Passed with browser-mocked state and JavaScript; live provider and Java server not involved |
| Existing offline, workspace boundaries, agent reliability, completion report, plan relevance, Confluence, intelligence smoke | Passed |
| Full Maven compile and JUnit execution | **Not verified**; dependencies unavailable in this environment |
| Live Java 17 Spring Boot runtime, provider/model tool calls, multi-hour execution, actual Windows terminal | **Not verified** |
| Penetration testing, concurrent multi-process isolation and production certification | **Not performed** |

To release to production: run `mvnw.cmd -Pfull-tests clean verify` (or Unix equivalent) on a dependency-enabled Java 17 machine; start the JAR; verify Chat/Agent/Terminal on Chrome and Windows PowerShell; exercise deletion approvals and timeout/rollback; confirm multiple terminals with separate Git worktrees, prompt handoff, clarification and cancellation, and saved artifact previews; inspect the output; do not put unvalidated builds against production code.

## Features not yet certified or incomplete

- Full production certification still requires building **the actual Java/Spring Boot application**, Windows Java 17/Chrome/browser testing and real provider execution. Tests with stubs and mocked HTTP responses cannot replace these gates.
- A globally non-blocking Chat view while the original Agent SSE stream is awaiting or finishing its approval handoff; Terminal itself is background-managed, but the original Chat composer may remain temporarily busy until that stream closes.
- True PTY/ConPTY interactive shell emulation (the existing `bash`/`process_*` tools are command/process-oriented, not a full TTY).
- Unattended recovery of previously running OS processes after application restart and exact idempotent replay of arbitrary steps.
- Complete OpenCode/Claude command/hook compatibility, advanced Skill Studio evaluation/versioning, coordinated multi-agent teams, configurable lifecycle hooks and requirements evidence dashboard. Studio creation/discovery alone is not complete feature parity.
- Automatic Git worktree cleanup, safe conflict-resolution UI and Git merges into the original branch.
- Full capture of every possible free-form/generated attachment remains incomplete: immutable structured PROJECT_FILE Chat proposals are now archived server-side per saved assistant message, with a Saved files/Preview UI. Proposals without structured markers continue using persisted conversation text, not the standalone artifact archive.
- Formal production load/security certification and comparable benchmarks against OpenCode/Claude Code.

These areas remain explicit roadmap requirements; this README avoids describing them as validated or finished.


## RC3 token-report compilation correction (24 October 2026)

The subagent token accounting call in `AgentService.runSubagent` now passes the
existing `parentStep` parameter instead of the undeclared `step` variable.
Read-only completion-critic usage is classified as `Execution review` rather
than `Subagent execution`. Run `bash qa/token-usage-smoke/run.sh` to check both
accounting semantics and the regression guard, and use `./mvnw clean package`
for the full dependency-resolved build on a machine with Maven Central access.
Offline test passes do not substitute for a complete Spring Boot compilation.

## ELIYA57 terminal and UI changes (24 October 2026)

### Terminal Agent conversation, tabs and workspace switching

- The Terminal is a **conversational Agent UI**, not just a one-shot output log. After an Agent task finishes, enter a follow-up instruction in the same tab to launch a new run in the **same archived Terminal conversation**. Each turn stores an instruction and response in a bounded, persistent tab transcript; the run plan, tool activity, token accounting and cancellation remain those of the most recent run.
- New tab launches an **independent** conversation; there are no Duplicate or Fork buttons. Different root workspaces can run in parallel. Shared/overlapping workspace roots are serialized for mutation safety.
- The Terminal has **minimize, restore and maximize** controls. Minimizing or closing the panel does **not** stop server-side tasks. The global execution monitor remains active and can reopen a session. The output uses message cards, an accessible session indicator, readable Markdown, live step progress, expandable tool events and the Agent's clarification choices.
- Set a mapped primary workspace using **Session setup**, enter an **absolute path** in its path field and click **Use path**, or type `/workspace C:\Projects\MyRepo`, `/workspace /Users/me/project`, `cd /absolute/path` or `switch workspace to /absolute/path` into the Terminal composer. The path must exist **on the computer hosting the Java server**, not just in the device running the browser. Existing workspace mapping, canonicalization, home/system-root checks and indexing guards remain in force. Mapping a new path changes **the next instruction only** in that Terminal tab; it never redirects a running task. Other tabs' workspaces are unchanged.
- When no Chat conversation has been opened, path registration creates a separate registration conversation without changing Chat selection. Terminal follow-up runs use their session-specific archival conversation rather than sharing the main Chat history. Follow-ups are accepted into the visible per-tab queue while a task runs or is awaiting clarification. Answer active clarifications using their direct response controls; queued work does not bypass a pending question.
- **Chat → Terminal:** the Chat response's Execute in Terminal action captures the Chat workspace before launching, and guides workspace selection if none is mapped. The pending Agent plan transfer checks source conversation, workspace, approval state and a mapped local root before consuming the approval. The `waiting_workspace` state is now described as a **workspace lock / execution queue**, not as a missing workspace. For safety, mapped-workspace operations remain separate from the Chat main workspace.

### Chat, HTML preview and prompt readability

- For prompt-drafting responses that contain fenced sections, Chat defaults to a **single uninterrupted prompt panel**, with an explicit **Formatted Markdown** toggle. The original response bytes are unchanged. Other Chat responses have a **Continuous view** control showing their complete text in one scrollable reading modal.
- An HTML code fence with a full HTML document can be inspected using **Preview HTML** without downloading the code. Files proposed in Chat (including `.html`) and saved conversation artifacts have Preview actions; the Agent's verified created/changed HTML file also has a Preview action in its completion report.
- HTML presentations preview in a **sandboxed iframe with an opaque origin**. Inline slideshow navigation scripts are allowed inside the frame, but application access, form submissions, external script loading and network/API access are restricted using an iframe sandbox and Content-Security-Policy. **Self-contained HTML/CSS/JS presentations preview best**; a presentation dependent on CDN scripts or resources in separate files may be incomplete. Raw-source view, Copy and Download remain available. Do not disable the sandbox for generated HTML.

### Repeatable user acceptance scenarios

Use disposable workspaces and valid provider credentials for the full test matrix. A **verified offline/mock** scenario means its UI/logic contract was checked here; it is **not** a complete Java server or provider verification.

| # | User action and expected behavior | Verification |
| --- | --- | --- |
| 1 | Open the Terminal from Chat; independent panel appears and main Chat remains usable | Chromium mocked UI passed |
| 2 | Maximize, minimize and restore; current draft/tab remains available | Chromium mocked UI passed |
| 3 | Create a new Terminal tab; configure a separate model and workspace | Chromium mocked UI and JS tests passed |
| 4 | Open a new tab without inheriting running execution | Chromium mocked UI passed |
| 5 | Close and reopen a tab without cancelling the execution | Chromium mocked UI passed |
| 6 | Map an absolute Windows path, then a macOS/Linux path; invalid/broad roots rejected | Path parsing tests and existing backend workspace-guard smoke passed; OS-level run pending |
| 7 | Use `/workspace PATH` or `cd /absolute/path`; selection changes only for next task | Parser tests passed; live mapping on host pending |
| 8 | Start a task from Chat with a valid mapped workspace; execution begins without second plan approval | Existing handoff Chromium mock + offline approval typecheck passed; live provider pending |
| 9 | Transfer an Agent approval to Terminal; original run is not accidentally also approved | Approval handoff standalone test passed; provider end-to-end pending |
| 10 | Two tabs use different unrelated roots; run in parallel | Existing queue/root-lock source and standalone test passed; high-load test pending |
| 11 | Two tabs request the same root; later task queues with a descriptive reason | Backend source/queue logic and lock tests passed; live concurrency pending |
| 12 | Reply to the Agent's clarification, cancel or stop an unsafe task | Existing question/stop code and safety regression tests passed; live provider pending |
| 13 | After completion, send another prompt in the same tab; prior turns remain visible and conversation ID is reused | Java 17 stub typecheck, JS source assertions and mocked transcript rendering passed; database integration pending |
| 14 | Send another turn while a previous run is busy; new turn queues safely | Java 17 FIFO smoke + Chromium queue mock passed |
| 15 | Review streamed progress, expanded tool steps, stop action, restored scroll/clarification draft | Browser UI/state smoke and regression checks passed; live long-run pending |
| 16 | Ask Agent to select a specific repo and create a branch/worktree; standalone Git selector is intentionally hidden | Backend contract checks passed; live Git execution pending |
| 17 | Generate a very long prompt with multiple code fences; read it as one panel and switch formatting | UI source tests passed; real long model response pending |
| 18 | Generate `presentation.html` as Chat content, preview it, toggle source and download | HTML extractor tests and iframe-source browser smoke passed; browser slide navigation end-to-end not established |
| 19 | Generate a structured Chat HTML proposal and reopen the archived file preview | Existing artifact vault smoke and Chromium mocked tests passed |
| 20 | Preview an Agent-created HTML document from the completion report | Existing run-artifact backend and JavaScript contract checks passed; live Agent write pending |
| 21 | Examine token usage by execution stage after a Terminal run | Offline token-accounting smoke passed; provider usage verification pending |
| 22 | Restart Java during a running task: history is retained and task shows interrupted, not incorrectly resumed | Existing persistence and recovery source contracts passed; actual restart pending |
| 23 | Refresh Chat while Terminal executes; restored Terminal tab/status independent of Chat | Detached-worker code and UI source contracts passed; server reload integration pending |
| 24 | Run in both Windows Java 17 Chrome and macOS Java 17 Chrome | **Not tested in this environment** |

### Build verification for this revision

- `node --check` for the modified frontend succeeded.
- For ELIYA57: `node --test src/test/js/*.test.js`: **55/55 passed**; ELIYA58: **59/59 passed**.
- `bash qa/eliya52-terminal-typecheck.sh`: **passed** Java 17 stub-based Terminal Controller/Service/Discovery/Approval typecheck, approval handoff and ELIYA58 queue lifecycle smoke.
- `python qa/eliya58-terminal-queue-browser.py`: **passed** mocked Chromium instruction queue interaction (send while busy, edit, reorder, remove, scoped workspace switch, interrupt, resume).
- `python qa/eliya52-browser-ui-smoke.py`: **passed** existing end-to-end **mocked browser** workflow (including Chat-to-Terminal transfer, saved HTML proposal, Git and monitoring).
- Supplemental Chromium UI simulation: **passed** maximize, minimize/restore, multi-turn message rendering, HTML iframe source and sandbox assertions; browser blocked frame navigation so actual slideshow button functionality **not** certified here.
- Offline smoke suites passed: `qa/eliya52-hardening`, `qa/offline-smoke`, `qa/workspace-boundaries`, `qa/agent-reliability` (parses **112 main Java files**), `qa/plan-relevance`, `qa/token-usage-smoke`, `qa/completion-report-smoke`.
- `./mvnw -q -DskipTests package` was **attempted, failed** because Maven was not installed and this sandbox cannot resolve `repo.maven.apache.org`. Accordingly, **no newly compiled JAR is bundled**, and real Spring Boot/package/provider/Windows/macOS end-to-end assertions are intentionally not made.

All authored documentation is kept in this sole `README.md`. Existing Java source, web assets, tests and QA scripts remain in their original folders.
