package com.itps.vibium.service;

import java.util.*;
import java.util.regex.*;

/** Parses a natural-language Excel step and builds a self-validating Playwright action. */
final class PlaywrightSemanticAction {
    private static final Pattern QUOTED = Pattern.compile("[\\\"']([^\\\"']+)[\\\"']");

    enum Kind { CLICK, DOUBLE_CLICK, HOVER, FILL, SELECT, CHECK, UNCHECK, PRESS }
    record Spec(Kind kind, String target, String value, String hint) {}

    static Spec parse(String instruction) {
        String text = Objects.requireNonNullElse(instruction, "").trim();
        String lower = text.toLowerCase(Locale.ROOT);
        List<String> q = new ArrayList<>();
        Matcher m = QUOTED.matcher(text); while (m.find()) q.add(m.group(1).trim());

        Kind kind;
        if (lower.startsWith("double-click") || lower.startsWith("double click")) kind = Kind.DOUBLE_CLICK;
        else if (lower.startsWith("hover")) kind = Kind.HOVER;
        else if (lower.startsWith("type ") || lower.startsWith("fill ") || lower.startsWith("enter ") || lower.startsWith("set ")) kind = Kind.FILL;
        else if (lower.startsWith("select ") || lower.startsWith("choose ")) kind = Kind.SELECT;
        else if (lower.startsWith("uncheck ")) kind = Kind.UNCHECK;
        else if (lower.startsWith("check ")) kind = Kind.CHECK;
        else if (lower.startsWith("press ")) kind = Kind.PRESS;
        else kind = Kind.CLICK;

        String target = "", value = "";
        if (kind == Kind.FILL) {
            value = q.isEmpty() ? "" : q.get(0);
            target = q.size() > 1 ? q.get(1) : inferField(text, value);
        } else if (kind == Kind.SELECT) {
            value = q.isEmpty() ? stripVerb(text) : q.get(0);
            target = q.size() > 1 ? q.get(1) : inferSelectField(text, value);
            if (target.isBlank()) target = value; // custom dropdown option selection
        } else if (kind == Kind.PRESS) {
            value = q.isEmpty() ? stripVerb(text) : q.get(0);
            target = q.size() > 1 ? q.get(1) : "focused element";
        } else {
            target = q.isEmpty() ? inferActionTarget(text) : q.get(0);
        }
        String hint = inferHint(lower);
        return new Spec(kind, target.trim(), value.trim(), hint);
    }

    static String buildScript(Spec s) {
        String target = js(s.target());
        String value = js(s.value());
        String hint = js(s.hint());
        String kind = js(s.kind().name());
        return "async (page) => {" +
            "const wanted="+target+", val="+value+", hint="+hint+", kind="+kind+";" +
            "const picked=await page.evaluate(({wanted,hint,kind})=>{" +
            "const norm=x=>String(x||'').normalize('NFKC').replace(/\s+/g,' ').trim().toLowerCase();" +
            "const visible=e=>{if(!e)return false;const s=getComputedStyle(e),r=e.getBoundingClientRect();return s.visibility!=='hidden'&&s.display!=='none'&&Number(s.opacity||1)>0&&r.width>0&&r.height>0};" +
            "const role=e=>e.getAttribute('role')||({BUTTON:'button',A:'link',INPUT:(e.type==='checkbox'?'checkbox':e.type==='radio'?'radio':'textbox'),SELECT:'combobox',TEXTAREA:'textbox',OPTION:'option'}[e.tagName]||'generic');" +
            "const directText=e=>[...e.childNodes].filter(n=>n.nodeType===Node.TEXT_NODE).map(n=>n.textContent).join(' ').replace(/\s+/g,' ').trim();" +
            "const ownName=e=>String(e.getAttribute('aria-label')||e.getAttribute('title')||e.getAttribute('alt')||e.getAttribute('data-testid')||e.value||e.getAttribute('placeholder')||directText(e)||e.innerText||e.textContent||'').replace(/\s+/g,' ').trim();" +
            "const interactive=e=>['BUTTON','A','INPUT','SELECT','OPTION','TEXTAREA'].includes(e.tagName)||['button','link','menuitem','option','tab','radio','checkbox','combobox','textbox','row'].includes(role(e))||e.hasAttribute('tabindex')||e.onclick||getComputedStyle(e).cursor==='pointer';" +
            "const nearestInteractive=e=>{let n=e;for(let i=0;n&&i<8;i++,n=n.parentElement){if(visible(n)&&interactive(n))return n;}return e;};" +
            "document.querySelectorAll('[data-itps-selected-target]').forEach(e=>e.removeAttribute('data-itps-selected-target'));" +
            "const all=[...document.querySelectorAll('body *')].filter(visible);" +
            "const exact=all.filter(e=>norm(e.getAttribute('aria-label'))===norm(wanted)||norm(e.getAttribute('title'))===norm(wanted)||norm(e.value)===norm(wanted)||norm(directText(e))===norm(wanted)||norm(e.innerText)===norm(wanted));" +
            "if(!exact.length)throw new Error('No exact visible element for target: '+wanted);" +
            "const roots=[...new Set(exact.map(nearestInteractive))];" +
            "const score=e=>{let x=0,r=role(e),c=String(e.className||'').toLowerCase(),n=norm(ownName(e));if(interactive(e))x+=200;if(n===norm(wanted))x+=120;if(hint&&c.includes(hint))x+=40;if(hint==='capsule'&&['tab','button','radio'].includes(r))x+=80;if(hint==='menu'&&r==='menuitem')x+=100;if(hint==='button'&&r==='button')x+=80;if(hint==='link'&&r==='link')x+=80;if(kind==='FILL'&&['textbox','combobox'].includes(r))x+=120;if(kind==='SELECT'&&['option','combobox'].includes(r))x+=100;if((kind==='CHECK'||kind==='UNCHECK')&&['checkbox','radio'].includes(r))x+=100;const b=e.getBoundingClientRect();x-=Math.min(40,(b.width*b.height)/20000);return x};" +
            "const ranked=roots.map(e=>({e,s:score(e),n:ownName(e),r:role(e)})).sort((a,b)=>b.s-a.s);" +
            "if(!ranked.length)throw new Error('No actionable element for exact target: '+wanted);" +
            "if(ranked.length>1&&Math.abs(ranked[0].s-ranked[1].s)<0.001&&ranked[0].e!==ranked[1].e)throw new Error('Ambiguous exact target '+wanted+': '+ranked.slice(0,5).map(x=>x.r+':'+x.n).join(' | '));" +
            "const hit=ranked[0];hit.e.setAttribute('data-itps-selected-target','true');return {chosenName:hit.n,role:hit.r,score:hit.s,matchedText:wanted};" +
            "},{wanted,hint,kind});" +
            "const loc=page.locator('[data-itps-selected-target=true]');if(await loc.count()!==1)throw new Error('Validated target is not unique');" +
            "if(!await loc.isVisible())throw new Error('Validated target is not visible');" +
            actionBody(s.kind()) +
            "return {requested:wanted,chosenName:picked.chosenName,matchedText:picked.matchedText,role:picked.role,score:picked.score,action:kind,value:val};" +
            "}";
    }

    private static String actionBody(Kind k) {
        return switch (k) {
            case FILL -> "await loc.fill(val);const actual=await loc.inputValue();if(actual!==val)throw new Error('Fill verification failed: '+actual);";
            case HOVER -> "await loc.hover();";
            case DOUBLE_CLICK -> "await loc.dblclick();";
            case SELECT -> "if((await loc.evaluate(e=>e.tagName))==='SELECT'){await loc.selectOption({label:val});const txt=(await loc.locator('option:checked').textContent()||'').trim();if(txt.toLowerCase()!==val.trim().toLowerCase())throw new Error('Select verification failed: '+txt);}else{await loc.click();}";
            case CHECK -> "if(['checkbox','radio'].includes(role(el))){await loc.check();if(!await loc.isChecked())throw new Error('Check verification failed');}else await loc.click();";
            case UNCHECK -> "await loc.uncheck();if(await loc.isChecked())throw new Error('Uncheck verification failed');";
            case PRESS -> "await loc.press(val);";
            default -> "await loc.click();";
        };
    }

    private static String inferActionTarget(String text) {
        String stripped = stripVerb(text).trim();
        // Natural-language forms used by the Excel suite:
        // Click the capsule or card named NEW-IP / Click Menu Item New search / Click Search Icon.
        Matcher named = Pattern.compile("(?i)\\b(?:named|labelled|labeled|called|text)\\s+['\"]?(.+?)['\"]?(?:\\s+to be visible)?$").matcher(stripped);
        if (named.find()) return cleanTarget(named.group(1));
        Matcher typed = Pattern.compile("(?i)^(?:the\\s+)?(?:menu\\s+item|menuitem|capsule|card|tab|button|link|icon|option|checkbox|radio|dropdown|field|textbox)\\s+['\"]?(.+?)['\"]?(?:\\s+to be visible)?$").matcher(stripped);
        if (typed.find()) return cleanTarget(typed.group(1));
        Matcher suffix = Pattern.compile("(?i)^['\"]?(.+?)['\"]?\\s+(?:menu\\s+item|menuitem|capsule|card|tab|button|link|icon|option)$").matcher(stripped);
        if (suffix.find()) return cleanTarget(suffix.group(1));
        return cleanTarget(stripped);
    }
    private static String cleanTarget(String value) {
        return Objects.requireNonNullElse(value, "").replaceAll("(?i)^(?:the\s+)", "")
                .replaceAll("(?i)\s+(?:to be visible|from the visible text)$", "")
                .replaceAll("^[\"']|[\"']$", "").trim();
    }

    private static String stripVerb(String s) { return s.replaceFirst("(?i)^(double[- ]click|click)(?: on)?\\s+|^hover(?: over)?\\s+|^(check|uncheck|press|select|choose)\\s+", "").trim(); }
    private static String inferField(String text, String value) {
        String t=text.replace(value,"").replaceAll("(?i)^(type|fill|enter|set)\\s+","");
        Matcher m=Pattern.compile("(?i)(?:into|in|to)\\s+(?:the\\s+)?(.+?)(?:\\s+(?:field|textbox|input))?$" ).matcher(t);
        return m.find()?m.group(1).replaceAll("[\\\"']","").trim():"";
    }
    private static String inferSelectField(String text, String value) {
        Matcher m=Pattern.compile("(?i)(?:from|in)\\s+(?:the\\s+)?(.+?)(?:\\s+dropdown)?$").matcher(text.replace(value,""));
        return m.find()?m.group(1).replaceAll("[\\\"']","").trim():"";
    }
    private static String inferHint(String lower) {
        for(String h:List.of("capsule","tab","button","link","menu","option","checkbox","radio","dropdown","field","textbox")) if(lower.contains(h)) return h;
        return "";
    }
    private static String js(String s) { return "'"+Objects.requireNonNullElse(s,"").replace("\\","\\\\").replace("'","\\'").replace("\r","\\r").replace("\n","\\n")+"'"; }
}
