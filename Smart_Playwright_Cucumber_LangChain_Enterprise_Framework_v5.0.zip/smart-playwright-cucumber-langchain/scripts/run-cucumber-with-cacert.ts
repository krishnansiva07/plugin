import { existsSync, mkdirSync } from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import 'dotenv/config';

const root = process.cwd();
mkdirSync(path.join(root, 'cucumber-report'), { recursive: true });
const configured = process.env.CACERT_PATH || 'certificates/generated-ca-bundle.pem';
const certificate = path.resolve(root, configured);
const cli = path.resolve(root, 'node_modules', '@cucumber', 'cucumber', 'bin', 'cucumber.js');
const env = { ...process.env };
if (existsSync(certificate)) {
  env.NODE_EXTRA_CA_CERTS = certificate;
  console.log(`[CERTIFICATE] ${certificate}`);
} else {
  console.warn(`[CERTIFICATE] Not found: ${certificate}. Continuing without NODE_EXTRA_CA_CERTS.`);
}
const result = spawnSync(process.execPath, [cli, ...process.argv.slice(2)], { cwd: root, stdio: 'inherit', env });
const report = spawnSync(process.execPath, [path.resolve(root, 'scripts', 'generate-smart-cucumber-report.cjs')], { cwd: root, stdio: 'inherit', env });
process.exit(result.status ?? report.status ?? 1);
