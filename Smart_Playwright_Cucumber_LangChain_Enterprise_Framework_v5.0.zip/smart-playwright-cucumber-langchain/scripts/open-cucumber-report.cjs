const { execFile }=require('child_process'); const path=require('path'); const f=path.resolve('reports/index.html');
const cmd=process.platform==='win32'?'cmd':process.platform==='darwin'?'open':'xdg-open'; const args=process.platform==='win32'?['/c','start','',f]:[f]; execFile(cmd,args);
