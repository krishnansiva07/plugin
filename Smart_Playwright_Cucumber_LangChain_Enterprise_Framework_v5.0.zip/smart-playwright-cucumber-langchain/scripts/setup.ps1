$ErrorActionPreference='Stop'
Write-Host 'Installing Smart Playwright Cucumber framework dependencies...'
npm ci
if (!(Test-Path '.env')) { Copy-Item '.env.example' '.env' }
npm run typecheck
Write-Host 'Setup completed. Configure .env and run npm test.'
