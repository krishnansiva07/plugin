# Complete Framework Guide

## Architecture

```mermaid
flowchart LR
  G[Feature files] --> S[Step definitions]
  S --> W[Cucumber World and Hooks]
  W --> P[Page Objects]
  P --> A[Smart Actions]
  A --> R[Saved locator repository]
  A --> D[Primary and deterministic fallbacks]
  A --> L[LangChain LLM healer]
  W --> B[Installed Chrome / Edge / Custom Chromium]
  W --> C[Cucumber JSON HTML JUnit]
  C --> H[Colourful consolidated HTML]
```

## Execution flow

1. `npm test` starts the certificate-aware runner.
2. The runner resolves `CACERT_PATH` and sets `NODE_EXTRA_CA_CERTS` before Cucumber starts.
3. Cucumber loads feature files, support hooks and step definitions.
4. Before each scenario, the framework detects the configured installed browser without launching it during detection.
5. Playwright launches one headed browser and creates an isolated context and page.
6. Steps load JSON data and call page-object business methods.
7. SmartActions resolves saved, primary, fallback and LLM-generated locators in that order.
8. After each scenario, failures receive screenshots and healing data is attached.
9. Cucumber generates HTML, JSON and JUnit outputs.
10. The runner creates `reports/index.html` with summary percentages and Serial No., Test ID, Test Name and Status.

## Browser configuration

```env
BROWSER=auto
BROWSER_PRIORITY=chrome,edge
```

Force Chrome: `BROWSER=chrome`. Force Edge: `BROWSER=edge`. Custom Chromium:

```env
BROWSER=custom
BROWSER_EXECUTABLE_PATH=C:\Tools\Chromium\chrome.exe
```

The framework always launches in headed/UI mode.

## Certificate

Copy the converted PEM bundle to `certificates/generated-ca-bundle.pem`, or change:

```env
CACERT_PATH=certificates/generated-ca-bundle.pem
```

## LLM configuration

```env
LLM_ENABLED=true
LLM_API_KEY=token
LLM_BASE_URL=https://corporate-endpoint/v1
LLM_MODEL_NAME=model-name
HEALING_MODE=persist
USE_SAVED_HEALED_LOCATORS=true
SAVE_HEALED_LOCATORS=true
LLM_MIN_CONFIDENCE=0.85
```

`runtime` uses a locator once, `persist` saves validated locators, and `suggest` reports a suggestion without using it.

## Adding a feature

Create `features/order.feature`, add reusable steps in `features/step-definitions/order.steps.ts`, and create page/component objects under `src/pages` or `src/components`. Keep browser APIs out of feature files.

## Running

```powershell
npm test
npm run test:smoke
npm run test:login
npm run report:open
npm run healing:list
npm run healing:clear
```

Use normal Cucumber arguments after the runner, for example:

```powershell
npm test -- --tags "@smoke and not @wip"
```

## Reports

Cucumber is the test runner in this package, so its native HTML report replaces Playwright Test's built-in HTML report. Playwright screenshots and Cucumber attachments remain available. The management report is `reports/index.html` and Jenkins consumes `cucumber-report/cucumber-junit.xml`.

## Jenkins

Run `npm ci` followed by `npm test`; publish the JUnit XML and archive `reports/**`, `cucumber-report/**`, `test-results/**`, and `healing-data/**`. A Windows headed execution requires an interactive logged-in Jenkins agent session.
