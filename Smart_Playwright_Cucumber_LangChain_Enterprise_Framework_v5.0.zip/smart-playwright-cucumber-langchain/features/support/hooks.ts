import { After, Before, Status, setDefaultTimeout } from '@cucumber/cucumber';
import { chromium } from '@playwright/test';
import { CustomWorld } from './world';
import { resolveConfiguredBrowser } from '../../src/core/browser/ConfiguredBrowser';
import { LoginPage } from '../../src/pages/LoginPage';
import { envNumber } from '../../src/utils/Environment';

setDefaultTimeout(envNumber('DEFAULT_TIMEOUT_MS', 30000));

Before(async function (this: CustomWorld, scenario) {
  this.pickle = scenario.pickle;
  const selected = resolveConfiguredBrowser();
  console.log(`[BROWSER] ${selected.displayName} | ${selected.executablePath} | Headed/UI`);
  this.browser = await chromium.launch({
    headless: false,
    executablePath: selected.executablePath,
    slowMo: envNumber('SLOW_MO', 0),
    args: ['--start-maximized']
  });
  this.context = await this.browser.newContext({ viewport: null, ignoreHTTPSErrors: true });
  this.page = await this.context.newPage();
  this.loginPage = new LoginPage(this.page, this.recordHealing);
});

After(async function (this: CustomWorld, scenario) {
  if (scenario.result?.status === Status.FAILED && this.page) {
    const image = await this.page.screenshot({ fullPage: true });
    await this.attach(image, 'image/png');
  }
  if (this.healingEvents.length) {
    await this.attach(JSON.stringify(this.healingEvents, null, 2), 'application/json');
  }
  await this.context?.close();
  await this.browser?.close();
});
