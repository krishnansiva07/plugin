import { setWorldConstructor, World, type IWorldOptions, type Pickle } from '@cucumber/cucumber';
import type { Browser, BrowserContext, Page } from '@playwright/test';
import type { LoginPage } from '../../src/pages/LoginPage';

export interface LoginTestData {
  run: boolean;
  testId: string;
  testName: string;
  username: string;
  password: string;
  expectedType: 'products' | 'error';
  expectedValue: string;
}

export interface HealingEvent {
  elementKey: string;
  elementDescription: string;
  action: string;
  source: string;
  originalLocator: string;
  healedLocator: string;
  confidence: number;
  reason: string;
  persisted: boolean;
}

export class CustomWorld extends World {
  browser?: Browser;
  context?: BrowserContext;
  page?: Page;
  loginPage?: LoginPage;
  testData?: LoginTestData;
  healingEvents: HealingEvent[] = [];
  pickle?: Pickle;

  constructor(options: IWorldOptions) { super(options); }

  recordHealing = (event: HealingEvent): void => {
    this.healingEvents.push(event);
    console.log(`[SELF-HEALING] ${event.source} | ${event.elementKey} | ${event.healedLocator} | confidence=${event.confidence}`);
  };
}

setWorldConstructor(CustomWorld);
