@login @smoke
Feature: SauceDemo login
  As an automation user
  I want to validate SauceDemo login behavior
  So that the framework demonstrates Playwright, Cucumber and smart healing

  Scenario Outline: Execute SauceDemo login test <testId>
    Given I load login test data for "<testId>"
    When I open the SauceDemo login page
    And I login using the configured credentials
    Then the configured login result should be displayed

    Examples:
      | testId       |
      | TC_LOGIN_001 |
      | TC_LOGIN_002 |
      | TC_LOGIN_003 |
