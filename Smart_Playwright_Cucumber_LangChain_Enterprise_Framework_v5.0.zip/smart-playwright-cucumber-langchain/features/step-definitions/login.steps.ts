import { Given, Then, When } from '@cucumber/cucumber';
import { expect } from '@playwright/test';
import { CustomWorld, type LoginTestData } from '../support/world';
import { readJsonArray } from '../../src/utils/JsonData';
import { env } from '../../src/utils/Environment';

Given('I load login test data for {string}', function (this: CustomWorld, testId: string) {
  const rows = readJsonArray<LoginTestData>('test-data/login-tests.json');
  const row = rows.find(item => item.testId === testId && item.run);
  if (!row) throw new Error(`Enabled test data not found for ${testId}`);
  this.testData = row;
});

When('I open the SauceDemo login page', async function (this: CustomWorld) {
  await this.loginPage!.open(env('BASE_URL', 'https://www.saucedemo.com/'));
});

When('I login using the configured credentials', async function (this: CustomWorld) {
  await this.loginPage!.login(this.testData!.username, this.testData!.password);
});

Then('the configured login result should be displayed', async function (this: CustomWorld) {
  if (this.testData!.expectedType === 'products') {
    await expect(this.page!.locator('.title')).toHaveText(this.testData!.expectedValue);
  } else {
    await expect(this.page!.locator('[data-test="error"]')).toContainText(this.testData!.expectedValue, { ignoreCase: true });
  }
});
