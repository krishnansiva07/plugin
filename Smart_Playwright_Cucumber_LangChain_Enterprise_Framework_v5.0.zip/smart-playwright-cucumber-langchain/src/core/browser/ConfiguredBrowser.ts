import { env } from '../../utils/Environment';
import { resolveBrowser, type BrowserPreference } from './BrowserResolver';

export function resolveConfiguredBrowser() {
  const preference = env('BROWSER', 'auto').toLowerCase() as BrowserPreference;
  const priority = env('BROWSER_PRIORITY', 'chrome,edge')
    .split(',').map(value => value.trim()).filter((value): value is 'chrome' | 'edge' => value === 'chrome' || value === 'edge');
  return resolveBrowser(preference, priority.length ? priority : ['chrome', 'edge'], env('BROWSER_EXECUTABLE_PATH', ''));
}
