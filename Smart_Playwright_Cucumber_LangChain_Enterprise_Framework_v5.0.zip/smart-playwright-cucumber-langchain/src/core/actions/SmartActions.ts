import type { Locator, Page } from '@playwright/test';
import { env, envBoolean, envNumber } from '../../utils/Environment';
import { LlmClient } from '../../llm/LlmClient';
import { HealingRepository, type HealingSource } from '../healing/HealingRepository';

export interface SmartElement {
  key: string;
  description: string;
  primary: () => Locator;
  fallbacks?: Array<() => Locator>;
}

interface HealingEvent {
  elementKey: string;
  elementDescription: string;
  action: string;
  source: HealingSource;
  originalLocator: string;
  healedLocator: string;
  confidence: number;
  reason: string;
  persisted: boolean;
}

interface Resolution {
  locator: Locator;
  healed: boolean;
  event?: HealingEvent;
}

export class SmartActions {
  private readonly llm = new LlmClient();
  private readonly repository = new HealingRepository();
  private readonly minimumConfidence = envNumber('LLM_MIN_CONFIDENCE', 0.85);
  private readonly mode = env('HEALING_MODE', 'runtime').toLowerCase();
  private readonly useSaved = envBoolean('USE_SAVED_HEALED_LOCATORS', true);
  private readonly saveHealed = envBoolean('SAVE_HEALED_LOCATORS', true);

  constructor(private readonly page: Page, private readonly healingRecorder?: (event: HealingEvent) => void) {}

  async fill(element: SmartElement, value: string): Promise<boolean> {
    const resolution = await this.resolve(element, 'fill');
    await resolution.locator.fill(value);
    this.record(resolution.event);
    return resolution.healed;
  }

  async click(element: SmartElement): Promise<boolean> {
    const resolution = await this.resolve(element, 'click');
    await resolution.locator.click();
    this.record(resolution.event);
    return resolution.healed;
  }

  private async isUsable(locator: Locator): Promise<boolean> {
    try {
      return (await locator.count()) === 1 && await locator.isVisible();
    } catch {
      return false;
    }
  }

  private async resolve(element: SmartElement, action: string): Promise<Resolution> {
    if (this.useSaved) {
      const saved = this.repository.get(element.key);
      if (saved) {
        const locator = this.page.locator(saved.selector);
        if (await this.isUsable(locator)) {
          this.repository.markValidated(element.key);
          return {
            locator,
            healed: true,
            event: {
              elementKey: element.key,
              elementDescription: element.description,
              action,
              source: 'SAVED',
              originalLocator: element.primary().toString(),
              healedLocator: saved.selector,
              confidence: saved.confidence,
              reason: 'Reused a previously validated locator from the healing repository.',
              persisted: true
            }
          };
        }
        this.repository.remove(element.key);
      }
    }

    const candidates = [element.primary, ...(element.fallbacks ?? [])];
    for (let index = 0; index < candidates.length; index += 1) {
      const locator = candidates[index]();
      if (await this.isUsable(locator)) {
        if (index === 0) return { locator, healed: false };
        return {
          locator,
          healed: true,
          event: {
            elementKey: element.key,
            elementDescription: element.description,
            action,
            source: 'DETERMINISTIC',
            originalLocator: element.primary().toString(),
            healedLocator: locator.toString(),
            confidence: 1,
            reason: `Recovered using deterministic fallback ${index}.`,
            persisted: false
          }
        };
      }
    }

    const error = `Unable to find one visible element for ${element.description}`;
    const maxLength = envNumber('LLM_DOM_MAX_LENGTH', 20000);
    const suggestion = await this.llm.suggestLocator({
      elementDescription: element.description,
      failedLocator: element.primary().toString(),
      action,
      error,
      pageTitle: await this.page.title(),
      pageUrl: this.page.url(),
      relevantDom: (await this.page.locator('body').innerHTML()).slice(0, maxLength)
    });

    if (!suggestion || suggestion.confidence < this.minimumConfidence) throw new Error(error);
    const healed = this.page.locator(suggestion.selector);
    if (!(await this.isUsable(healed))) {
      throw new Error(`${error}. LLM suggestion did not resolve to one visible element.`);
    }

    if (this.mode === 'suggest') {
      this.record({
        elementKey: element.key,
        elementDescription: element.description,
        action,
        source: 'LLM',
        originalLocator: element.primary().toString(),
        healedLocator: suggestion.selector,
        confidence: suggestion.confidence,
        reason: `${suggestion.reason} Suggest mode does not execute the locator.`,
        persisted: false
      });
      throw new Error(`${error}. Valid LLM suggestion generated in suggest mode: ${suggestion.selector}`);
    }

    const persist = this.mode === 'persist' && this.saveHealed;
    if (persist) {
      this.repository.save({
        key: element.key,
        selector: suggestion.selector,
        confidence: suggestion.confidence,
        reason: suggestion.reason
      });
    }

    return {
      locator: healed,
      healed: true,
      event: {
        elementKey: element.key,
        elementDescription: element.description,
        action,
        source: 'LLM',
        originalLocator: element.primary().toString(),
        healedLocator: suggestion.selector,
        confidence: suggestion.confidence,
        reason: suggestion.reason,
        persisted: persist
      }
    };
  }

  private record(event?: HealingEvent): void {
    if (!event) return;
    console.log(`[SELF-HEALING] ${event.source} | ${event.elementKey} | ${event.healedLocator} | confidence=${event.confidence}`);
    this.healingRecorder?.(event);
  }
}
