# Smart Playwright Cucumber LangChain Framework v5.0

Enterprise TypeScript BDD framework using Cucumber-JS as the runner and Playwright for browser automation. It uses installed Chrome/Edge or a custom Chromium executable, runs headed, reads JSON test data, supports deterministic and LangChain LLM self-healing, persists validated locators, and creates Cucumber HTML/JSON/JUnit plus a colourful consolidated report.

## Quick start

```powershell
npm ci
Copy-Item .env.example .env
# Copy generated-ca-bundle.pem to certificates\ when required
npm test
```

Reports:
- `reports/index.html` – colourful consolidated report
- `cucumber-report/cucumber-default.html` – default Cucumber HTML report
- `cucumber-report/cucumber.json` – raw report
- `cucumber-report/cucumber-junit.xml` – Jenkins JUnit report

Read `docs/COMPLETE_GUIDE.md` for architecture, configuration, execution flow, self-healing and Jenkins usage.
