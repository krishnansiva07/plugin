export default {
  default: {
    paths: ['features/**/*.feature'],
    import: ['features/support/**/*.ts', 'features/step-definitions/**/*.ts'],
    loader: ['tsx'],
    format: [
      'progress-bar',
      'json:cucumber-report/cucumber.json',
      'html:cucumber-report/cucumber-default.html',
      'junit:cucumber-report/cucumber-junit.xml'
    ],
    formatOptions: { snippetInterface: 'async-await' },
    parallel: 1,
    retry: 0,
    publishQuiet: true
  }
};
