# Parallel test hang/performance fix

## Root cause
`ItpsMcpRunnerParallelTest` uses stub/fake MCP transports with no real browser. The browser zoom hook was still executing Windows-native PowerShell focus/zoom attempts after navigation. Because native UI operations are serialized for parallel safety and can wait/retry, the test suite could take minutes or appear hung.

## Fix
- Skip browser zoom entirely when zoom is 100% (default).
- Run native zoom only for MCP sessions where `browser_start` completed successfully.
- Cache unsuccessful zoom attempts per browser/page/zoom so a step-finally block does not immediately repeat the expensive native operation.
- Clear zoom/session tracking when the MCP client closes.
- Add a 60-second JUnit timeout guard to `ItpsMcpRunnerParallelTest` so future regressions fail clearly instead of hanging indefinitely.

Maximize behavior is unchanged.
