package com.itps.vibium.service;

import java.util.Locale;
import java.util.Optional;
import java.util.concurrent.TimeUnit;

/**
 * Detects whether the optional native browser-zoom implementation can be used safely.
 * Detection is cached so normal test startup does not repeatedly spawn capability probes.
 */
final class BrowserZoomSupport {
    private static volatile boolean probed;
    private static volatile String powerShellExecutable;

    private BrowserZoomSupport() { }

    static boolean isWindowsNativeZoomSupported() {
        return powerShellExecutable().isPresent();
    }

    static Optional<String> powerShellExecutable() {
        String os = System.getProperty("os.name", "").toLowerCase(Locale.ROOT);
        if (!os.contains("win")) return Optional.empty();

        if (probed) return Optional.ofNullable(powerShellExecutable);
        synchronized (BrowserZoomSupport.class) {
            if (!probed) {
                powerShellExecutable = probe("powershell.exe") ? "powershell.exe"
                        : probe("pwsh.exe") ? "pwsh.exe" : null;
                probed = true;
            }
        }
        return Optional.ofNullable(powerShellExecutable);
    }

    private static boolean probe(String executable) {
        Process process = null;
        try {
            process = new ProcessBuilder(
                    executable, "-NoProfile", "-NonInteractive",
                    "-Command", "$ErrorActionPreference='Stop';$null=New-Object -ComObject WScript.Shell;exit 0")
                    .redirectErrorStream(true)
                    .start();
            if (!process.waitFor(2, TimeUnit.SECONDS)) {
                process.destroyForcibly();
                return false;
            }
            return process.exitValue() == 0;
        } catch (Exception ignored) {
            if (process != null) process.destroyForcibly();
            return false;
        }
    }
}
