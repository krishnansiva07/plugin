package com.itps.vibium.model;

import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

class BrowserZoomConfigTest {
    @Test
    void customZoomIsOptionalAndDisabledByDefault() {
        RunConfig runConfig = new RunConfig();
        RecorderStartRequest recorderRequest = new RecorderStartRequest();

        assertThat(runConfig.isBrowserZoomEnabled()).isFalse();
        assertThat(runConfig.getBrowserZoomPercent()).isEqualTo(100);
        assertThat(recorderRequest.isBrowserZoomEnabled()).isFalse();
        assertThat(recorderRequest.getBrowserZoomPercent()).isEqualTo(100);
    }

    @Test
    void userCanEnableASelectedZoomWithoutChangingTheDefaultFallback() {
        RunConfig runConfig = new RunConfig();
        runConfig.setBrowserZoomEnabled(true);
        runConfig.setBrowserZoomPercent(75);

        assertThat(runConfig.isBrowserZoomEnabled()).isTrue();
        assertThat(runConfig.getBrowserZoomPercent()).isEqualTo(75);
    }
}
