# Optional Browser Zoom

- Custom browser zoom is now opt-in and disabled by default.
- When disabled, no zoom capability probe or native zoom operation is executed; browser remains at 100%.
- On Windows, custom zoom is attempted only when PowerShell and WScript.Shell are available.
- If capability detection or the actual zoom operation fails, test execution continues without failure at the normal browser zoom.
- The selected zoom and enabled flag are preserved for reruns.
- UI recorder follows the same optional behavior.
- Parallel/unit test paths do not incur zoom overhead unless custom zoom is explicitly enabled and a real browser session was started.
