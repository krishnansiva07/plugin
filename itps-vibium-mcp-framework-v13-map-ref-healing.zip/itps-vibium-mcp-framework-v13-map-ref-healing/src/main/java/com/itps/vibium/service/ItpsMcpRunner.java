package com.itps.vibium.service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.itps.vibium.model.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.time.Duration;
import java.time.Instant;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Service
public class ItpsMcpRunner {
    private final LlmClient llmClient;
    private final ReportService reportService;
    private final RunStore runStore;
    private final ObjectMapper mapper = new ObjectMapper();
    private final Path outputRoot;
    private final int requestTimeoutSeconds;
    private final boolean skipBrowserDownload;

    public ItpsMcpRunner(LlmClient llmClient,
                         ReportService reportService,
                         RunStore runStore,
                         @Value("${runner.output-dir:target/itps-vibium-runs}") String outputDir,
                         @Value("${itps.vibium.mcp.request-timeout-seconds:90}") int requestTimeoutSeconds,
                         @Value("${itps.vibium.skip-browser-download:true}") boolean skipBrowserDownload) {
        this.llmClient = llmClient;
        this.reportService = reportService;
        this.runStore = runStore;
        this.outputRoot = Path.of(outputDir);
        this.requestTimeoutSeconds = requestTimeoutSeconds;
        this.skipBrowserDownload = skipBrowserDownload;
    }

    public void execute(List<TestScenario> scenarios, RunConfig config, RunStatus status) {
        Instant runStart = Instant.now();
        status.setStatus("RUNNING");
        status.setStartedAt(runStart);
        Path runDir = outputRoot.resolve(config.getRunId());
        Path screenshotDir = runDir.resolve("screenshots");
        McpClient mcp = null;
        try {
            Files.createDirectories(screenshotDir);
            List<String> args = mcpArgsWithScreenshotDir(config.getMcpArgs(), screenshotDir);
            mcp = new McpClient(config.getMcpCommand(), args, Duration.ofSeconds(requestTimeoutSeconds), skipBrowserDownload);
            mcp.start();
            List<McpTool> tools = mcp.initializeAndListTools();
            McpToolCatalog catalog = new McpToolCatalog(tools);
            writeToolsManifest(runDir, tools);
            startBrowserOnce(mcp, catalog, config);

            List<ScenarioResult> results = new ArrayList<>();
            for (TestScenario scenario : scenarios) {
                results.add(executeScenario(mcp, catalog, scenario, config, screenshotDir));
            }

            status.setScenarios(results);
            status.setTotal(results.size());
            int passed = (int) results.stream().filter(s -> s.getStatus() != null && s.getStatus().startsWith("PASSED")).count();
            status.setPassed(passed);
            status.setFailed(results.size() - passed);
            status.setStatus(status.getFailed() == 0 ? "PASSED" : "COMPLETED_WITH_FAILURES");
            status.setMessage("");
        } catch (Exception e) {
            status.setStatus("FAILED");
            status.setMessage("Vibium MCP execution failed: " + e.getMessage());
        } finally {
            if (mcp != null) {
                mcp.writeDiagnostics(runDir);
                try { mcp.close(); } catch (Exception ignored) {}
            }
            status.setFinishedAt(Instant.now());
            try { reportService.writeReports(status, runDir); }
            catch (Exception reportError) {
                status.setMessage((status.getMessage() == null ? "" : status.getMessage() + " | ") + "Report generation failed: " + reportError.getMessage());
                try { reportService.writeFallbackHtml(status, runDir, reportError); } catch (Exception ignored) {}
            }
        }
    }

    private List<String> mcpArgsWithScreenshotDir(String rawArgs, Path screenshotDir) {
        List<String> args = new ArrayList<>(splitArgs(rawArgs));
        boolean hasScreenshotDir = args.stream().anyMatch(a -> a.equalsIgnoreCase("--screenshot-dir"));
        if (!hasScreenshotDir) {
            args.add("--screenshot-dir");
            args.add(screenshotDir.toAbsolutePath().toString());
        }
        return args;
    }

    private void startBrowserOnce(McpClient mcp, McpToolCatalog catalog, RunConfig config) throws Exception {
        Optional<McpTool> start = catalog.startTool();
        if (start.isEmpty()) return;
        Map<String, Object> args = new LinkedHashMap<>();
        if (schemaContains(start.get(), "headless")) args.put("headless", config.isHeadless());
        if (config.getBrowserId() != null && !"vibium-managed-chrome".equalsIgnoreCase(config.getBrowserId())) {
            String executable = config.getBrowserExecutable();
            boolean applied = false;
            for (String key : List.of("executablePath", "browserExecutable", "browserPath", "binary", "executable")) {
                if (schemaContains(start.get(), key) && executable != null && !executable.isBlank()) { args.put(key, executable); applied = true; break; }
            }
            if (!applied) {
                for (String key : List.of("browser", "channel", "browserName")) {
                    if (schemaContains(start.get(), key)) { args.put(key, config.getBrowserId()); applied = true; break; }
                }
            }
            if (!applied) throw new IllegalStateException("Selected browser '" + config.getBrowserName() + "' is installed, but this Vibium MCP version does not expose browser/channel/executablePath in browser_start. Select Vibium Managed Chrome for Testing.");
        }
        JsonNode result = mcp.callTool(start.get().getName(), args);
        assertMcpToolSuccess(start.get().getName(), result);
    }

    private ScenarioResult executeScenario(McpClient mcp, McpToolCatalog catalog, TestScenario scenario, RunConfig config, Path screenshotDir) {
        long scenarioStart = System.currentTimeMillis();
        ScenarioResult out = new ScenarioResult();
        out.setId(scenario.getId());
        out.setName(scenario.getName());
        out.setUrl(resolveUrl(scenario.getUrl(), config.getAppBaseUrl()));
        out.setStatus("RUNNING");

        List<String> steps = new ArrayList<>();
        if (notBlank(out.getUrl())) steps.add("Navigate to " + out.getUrl());
        steps.addAll(scenario.getSteps());
        if (notBlank(scenario.getExpected())) steps.add("Verify " + applyData(scenario.getExpected(), scenario.getData()) + " is displayed");

        boolean failed = false;
        boolean dependencyFailed = false;
        int stepNo = 1;
        for (String raw : steps) {
            if (dependencyFailed) {
                StepResult skipped = new StepResult();
                skipped.setStepNo(stepNo);
                skipped.setInstruction(applyData(raw, scenario.getData()));
                skipped.setStatus("SKIPPED_DEPENDENCY_FAILURE");
                skipped.setErrorMessage("Skipped because a previous UI step failed and the browser state is no longer reliable.");
                skipped.setEvidence("Not executed. Fix the first failed step before evaluating downstream validations.");
                out.getSteps().add(skipped);
                stepNo++;
                continue;
            }
            StepResult sr = executeStep(mcp, catalog, scenario, config, raw, stepNo, screenshotDir);
            out.getSteps().add(sr);
            if (sr.getStatus() == null || !sr.getStatus().startsWith("PASSED")) {
                failed = true;
                dependencyFailed = true;
                out.setErrorMessage(sr.getErrorMessage());
                if (!config.isContinueOnFailure()) break;
            }
            stepNo++;
        }
        boolean healed = out.getSteps().stream().anyMatch(StepResult::isHealed);
        out.setStatus(failed ? "FAILED" : (healed ? "PASSED_HEALED" : "PASSED"));
        out.setDurationMs(System.currentTimeMillis() - scenarioStart);
        return out;
    }

    private StepResult executeStep(McpClient mcp, McpToolCatalog catalog, TestScenario scenario, RunConfig config, String rawStep, int stepNo, Path screenshotDir) {
        StepResult sr = new StepResult();
        long start = System.currentTimeMillis();
        String instruction = applyData(rawStep, scenario.getData());
        sr.setStepNo(stepNo);
        sr.setInstruction(instruction);
        String beforeFingerprint = "";
        String beforeShot = "";
        List<String> healingHistory = new ArrayList<>();
        try {
            beforeFingerprint = pageFingerprint(mcp, catalog);
            if (requiresPostEvidence(expectedIntent(instruction))) {
                beforeShot = captureScreenshotQuietly(mcp, catalog, screenshotDir, scenario.getId(), stepNo + "_before");
            }
            PlannedStep plan = planStep(mcp, catalog, instruction, scenario, config, null);
            applyPlanToStep(sr, plan, screenshotDir.getParent(), scenario.getId(), stepNo);
            executeValidatedPlan(mcp, catalog, plan.plan(), sr, instruction, config, plan.observation(), beforeFingerprint, beforeShot, screenshotDir, scenario.getId(), stepNo);
            sr.setStatus("PASSED");
        } catch (Exception first) {
            Exception finalError = first;
            int maxHealing = config.isEnableSelfHealing() ? Math.max(0, config.getRetryCount()) : 0;
            for (int attempt = 1; attempt <= maxHealing; attempt++) {
                try {
                    String failedShot = captureScreenshotQuietly(mcp, catalog, screenshotDir, scenario.getId(), stepNo + "_failed_" + attempt);
                    Thread.sleep(Math.max(200, config.getRetryDelayMs()));
                    PlannedStep healedPlan = healStep(mcp, catalog, instruction, scenario, config, finalError.getMessage(), sr.getActionJson(), attempt, failedShot);
                    applyPlanToStep(sr, healedPlan, screenshotDir.getParent(), scenario.getId(), stepNo);
                    executeValidatedPlan(mcp, catalog, healedPlan.plan(), sr, instruction, config, healedPlan.observation(), beforeFingerprint, beforeShot, screenshotDir, scenario.getId(), stepNo);
                    healingHistory.add("Attempt " + attempt + " succeeded. Strategy=" + healedPlan.source() + "; previousError=" + compact(finalError.getMessage(), 1200));
                    sr.setHealed(true);
                    sr.setHealingAttempts(attempt);
                    sr.setStatus("PASSED_HEALED");
                    finalError = null;
                    break;
                } catch (Exception healingError) {
                    healingHistory.add("Attempt " + attempt + " failed: " + compact(healingError.getMessage(), 1600));
                    finalError = healingError;
                }
            }
            if (finalError != null) {
                sr.setStatus("FAILED");
                sr.setErrorMessage(finalError.getMessage());
                if (shouldScreenshot(config, false)) sr.setScreenshot(captureScreenshotQuietly(mcp, catalog, screenshotDir, scenario.getId(), String.valueOf(stepNo)));
            }
        } finally {
            if (!healingHistory.isEmpty()) sr.setHealingHistory(String.join("\n", healingHistory));
            if (shouldScreenshot(config, true) && (sr.getScreenshot() == null || sr.getScreenshot().isBlank()) && sr.getStatus() != null && sr.getStatus().startsWith("PASSED")) {
                sr.setScreenshot(captureScreenshotQuietly(mcp, catalog, screenshotDir, scenario.getId(), String.valueOf(stepNo)));
            }
            sr.setDurationMs(System.currentTimeMillis() - start);
        }
        return sr;
    }

    private void applyPlanToStep(StepResult sr, PlannedStep plan, Path runDir, String scenarioId, int stepNo) {
        sr.setPlanSource(plan.source());
        sr.setActionJson(plan.plan().toString());
        sr.setPageInventory(plan.observation() == null ? "" : compact(plan.observation().toString(), 60000));
        writeElementInventory(runDir, scenarioId, stepNo, plan.observation());
    }

    private PlannedStep healStep(McpClient mcp, McpToolCatalog catalog, String instruction, TestScenario scenario, RunConfig config,
                                 String failure, String previousPlan, int attempt, String failedScreenshot) throws Exception {
        if (!config.isUseLlm() || !llmClient.isConfigured(config)) {
            throw new IllegalStateException("Self-healing requires configured LLM. Original failure: " + failure);
        }
        JsonNode observation = observePage(mcp, catalog);
        if (observation instanceof ObjectNode objectObservation) {
            objectObservation.set("rankedCandidates", rankCandidates(observation, instruction, 150));
            objectObservation.put("healingAttempt", attempt);
            objectObservation.put("failedScreenshot", failedScreenshot == null ? "" : failedScreenshot);
        }
        String prompt = buildHealingPrompt(instruction, scenario, catalog, observation, failure, previousPlan, attempt);
        JsonNode root = mapper.readTree(llmClient.healMcpCall(prompt, config));
        double confidence = root.path("confidence").asDouble(0.0);
        if (confidence < config.getHealingConfidenceThreshold()) {
            throw new IllegalStateException("LLM healing confidence " + confidence + " is below threshold " + config.getHealingConfidenceThreshold() + ". Reason=" + root.path("why").asText());
        }
        JsonNode normalized = normalizePlan(root);
        return new PlannedStep("LLM_SELF_HEALING_" + attempt + "_" + root.path("strategy").asText("REPLAN"), normalized, observation);
    }

    private String buildHealingPrompt(String instruction, TestScenario scenario, McpToolCatalog catalog, JsonNode observation,
                                      String failure, String previousPlan, int attempt) throws Exception {
        return "Instruction: " + instruction + "\n" +
                "Scenario: " + scenario.getId() + " - " + scenario.getName() + "\n" +
                "Test data: " + mapper.writeValueAsString(scenario.getData()) + "\n" +
                "Healing attempt: " + attempt + "\n" +
                "Previous plan: " + compact(previousPlan, 12000) + "\n" +
                "Failure: " + compact(failure, 6000) + "\n" +
                "Rules: use a different strategy; inspect clickable ancestor, exact occurrence, section context, labels, SVG metadata, frame/shadow context, visibility and hit-test. " +
                "For validation failure, prove the expected label/value relationship using contentElements, formValues, tables and allVisibleText. " +
                "Never repeat the same failed selector. Never return browser_start. Return at least one executable Vibium MCP call.\n" +
                "Available tools:\n" + catalog.toPromptText() + "\n" +
                "Fresh deep page observation:\n" + compact(observation.toString(), 90000);
    }

    private PlannedStep planStep(McpClient mcp, McpToolCatalog catalog, String instruction, TestScenario scenario, RunConfig config, String failure) throws Exception {
        JsonNode direct = parseDirectJson(instruction);
        if (direct != null) return new PlannedStep("EXPLICIT_JSON", normalizePlan(direct), null);
        if (isNavigate(instruction)) return new PlannedStep("DIRECT_NAVIGATE", directNavigatePlan(catalog, instruction), null);
        if (isWait(instruction)) return new PlannedStep("DIRECT_WAIT", directWaitPlan(catalog), null);
        if (isAssert(expectedIntent(instruction))) {
            JsonNode observation = observePage(mcp, catalog);
            return new PlannedStep("DIRECT_UNIFIED_VALIDATION", directAssertPlan(catalog), observation);
        }

        if (!config.isUseLlm()) {
            throw new IllegalStateException("Natural-language action step requires LLM planning in V8 MCP mode. Enable Use LLM or provide explicit JSON MCP calls. Step: " + instruction);
        }
        if (!llmClient.isConfigured(config)) {
            throw new IllegalStateException("LLM Base URL/token/model are required for natural-language UI action planning. Step: " + instruction);
        }

        JsonNode observation = observePage(mcp, catalog);
        if (observation instanceof ObjectNode objectObservation) {
            objectObservation.set("rankedCandidates", rankCandidates(observation, instruction, 80));
        }
        String prompt = buildAgentPrompt(instruction, scenario, catalog, observation, failure);
        JsonNode planned = mapper.readTree(llmClient.planMcpCall(prompt, config));
        return new PlannedStep("LLM_MAP_DOM_CLOSED_LOOP", normalizePlan(planned), observation);
    }

    private JsonNode observePage(McpClient mcp, McpToolCatalog catalog) {
        ObjectNode out = mapper.createObjectNode();
        out.set("url", safeToolResult(mcp, catalog.urlTool(), Map.of()));
        out.set("title", safeToolResult(mcp, catalog.titleTool(), Map.of()));
        out.set("text", safeToolResult(mcp, catalog.textTool(), Map.of()));
        out.set("map", safeMap(mcp, catalog));
        out.set("pageModel", safeDomProbe(mcp, catalog));
        return out;
    }

    private void executeValidatedPlan(McpClient mcp, McpToolCatalog catalog, JsonNode originalPlan, StepResult sr,
                                      String instruction, RunConfig config, JsonNode observation, String beforeFingerprint,
                                      String beforeScreenshot, Path screenshotDir, String scenarioId, int stepNo) throws Exception {
        JsonNode plan = removeNoOpStart(originalPlan);
        if (plan == null || flattenCalls(plan).isEmpty()) throw new IllegalStateException("No executable MCP tool calls returned. Plan=" + originalPlan);
        String expectedIntent = expectedIntent(instruction);
        if (requiresRealAction(expectedIntent) && !containsRealAction(plan, expectedIntent)) {
            throw new IllegalStateException("Planner did not return a real MCP action for instruction='" + instruction + "'. Plan=" + originalPlan);
        }

        List<String> tools = new ArrayList<>();
        List<Map<String, Object>> argsList = new ArrayList<>();
        List<String> results = new ArrayList<>();
        boolean executedAction = false;

        for (JsonNode call : flattenCalls(plan)) {
            String toolName = firstText(call, "tool", "name", "mcpTool", "toolName");
            if (isBrowserStart(toolName)) continue;
            McpTool tool = catalog.findByName(toolName).orElseThrow(() -> new IllegalArgumentException("MCP tool not found: " + toolName));
            Map<String, Object> args = normalizeArgsForTool(tool, call.path("arguments"));
            if (isActionTool(tool.getName())) validateSelectorUniqueness(mcp, catalog, tool.getName(), args);
            JsonNode result = callToolRobustly(mcp, catalog, tool, args, config, instruction);
            assertMcpToolSuccess(tool.getName(), result);
            tools.add(tool.getName());
            argsList.add(args);
            results.add(compact(result.toString(), 4000));
            if (!isNoOpTool(tool.getName())) executedAction = true;
            if (isActionTool(tool.getName())) {
                sleep(250);
            }
        }

        sr.setToolName(String.join(" → ", tools));
        sr.setToolArguments(mapper.writeValueAsString(argsList));
        sr.setMcpResult(String.join("\n---\n", results));

        String afterScreenshot = (requiresPostEvidence(expectedIntent) || shouldScreenshot(config, true)) ? captureScreenshotQuietly(mcp, catalog, screenshotDir, scenarioId, String.valueOf(stepNo)) : "";
        if (notBlank(afterScreenshot)) sr.setScreenshot(afterScreenshot);

        JsonNode afterObservation = observePage(mcp, catalog);
        if (isAssert(expectedIntent)) {
            assertInstruction(instruction, sr.getMcpResult(), afterObservation);
            sr.setEvidence("Assertion validated against Vibium map/text/DOM probe.");
        } else if (executedAction && requiresPostEvidence(expectedIntent)) {
            String afterFingerprint = pageFingerprint(mcp, catalog);
            boolean changed = !Objects.equals(beforeFingerprint, afterFingerprint);
            boolean screenshotChanged = screenshotsDifferent(screenshotDir, beforeScreenshot, afterScreenshot);
            if (!changed && !screenshotChanged) {
                throw new IllegalStateException("MCP tool returned success but no DOM/text/URL/screenshot evidence changed. This prevents fake pass. Step='" + instruction + "'. Tools=" + tools + ". Try a more descriptive step or check mcp-transcript.json and screenshots.");
            }
            sr.setEvidence("Closed-loop evidence passed: " + (changed ? "DOM/text/url changed" : "visual screenshot changed") + ".");
        } else if (requiresPostEvidence(expectedIntent)) {
            throw new IllegalStateException("Action step produced no executable state-changing MCP action. Step='" + instruction + "'. Tools=" + tools);
        } else {
            sr.setEvidence("Non-action MCP step completed without error.");
        }
    }

    private JsonNode callToolRobustly(McpClient mcp, McpToolCatalog catalog, McpTool tool,
                                      Map<String, Object> args, RunConfig config, String instruction) throws Exception {
        String toolName = tool.getName();
        if (!containsAny(toolName, "click", "tap", "press")) {
            return mcp.callTool(toolName, args);
        }

        Object rawSelector = args.get("selector");
        if (rawSelector == null) rawSelector = args.get("text");
        if (rawSelector == null) rawSelector = args.get("name");
        if (rawSelector == null) rawSelector = args.get("label");
        if (rawSelector == null) rawSelector = args.get("target");
        String selector = rawSelector == null ? "" : String.valueOf(rawSelector).trim();
        String semanticTarget = extractSemanticClickTarget(instruction, selector);
        int attempts = Math.max(4, Math.min(7, config.getRetryCount() + 4));
        Exception last = null;
        for (int attempt = 1; attempt <= attempts; attempt++) {
            try {
                if (!selector.isBlank() && !selector.startsWith("@")) {
                    prepareElementForClick(mcp, catalog, selector, config.getStepTimeoutSeconds());
                }
                JsonNode result = mcp.callTool(toolName, args);
                assertMcpToolSuccess(toolName, result);
                return result;
            } catch (Exception e) {
                last = e;
                String message = String.valueOf(e.getMessage()).toLowerCase(Locale.ROOT);
                boolean obstruction = message.contains("obscured") || message.contains("intercept") ||
                        message.contains("not clickable") || message.contains("receives events") ||
                        message.contains("covered") || message.contains("detached") || message.contains("timeout");
                if (!obstruction) break;

                // Recover immediately while transient hover menus are still open. This is especially
                // important for menu items such as "New search", where the physical pointer click can
                // be intercepted by a child span, badge, animation layer, or transparent container.
                if (!selector.isBlank() || !semanticTarget.isBlank()) {
                    JsonNode recovered = safeDomClick(mcp, catalog, semanticTarget.isBlank() ? selector : semanticTarget);
                    if (recovered.path("clicked").asBoolean(false)) {
                        ObjectNode synthetic = mapper.createObjectNode();
                        synthetic.put("content", "Semantic click recovery executed after Vibium pointer click was intercepted");
                        synthetic.put("recoveryAttempt", attempt);
                        synthetic.set("details", recovered);
                        return synthetic;
                    }
                }
                if (attempt == attempts) break;
                sleep(Math.max(350, config.getRetryDelayMs()));
            }
        }

        if (!selector.isBlank() && last != null) {
            String failure = String.valueOf(last.getMessage()).toLowerCase(Locale.ROOT);
            if (failure.contains("obscured") || failure.contains("intercept") ||
                    failure.contains("not clickable") || failure.contains("receives events") ||
                    failure.contains("covered") || failure.contains("timeout")) {
                JsonNode fallback = safeDomClick(mcp, catalog, semanticTarget.isBlank() ? selector : semanticTarget);
                if (fallback.path("clicked").asBoolean(false)) {
                    ObjectNode synthetic = mapper.createObjectNode();
                    synthetic.put("content", "Enterprise DOM click fallback executed after Vibium pointer click failed");
                    synthetic.set("details", fallback);
                    return synthetic;
                }
            }
        }
        throw last == null ? new IllegalStateException("Click failed without a diagnostic") : last;
    }

    private String extractSemanticClickTarget(String instruction, String selector) {
        String text = instruction == null ? "" : instruction.trim();
        java.util.regex.Matcher quoted = java.util.regex.Pattern.compile("[\"']([^\"']{2,120})[\"']").matcher(text);
        String lastQuoted = "";
        while (quoted.find()) lastQuoted = quoted.group(1).trim();
        if (!lastQuoted.isBlank()) return lastQuoted;

        // Vibium map references such as @e13 identify the mapped node, but the node may be a child SPAN.
        // Recover the human target from the step and use exact semantic matching against the live DOM.
        if (selector != null && selector.startsWith("@")) {
            String cleaned = text.replaceAll("(?i)\\b(click|tap|press|select|choose|find|open|menu|item|icon|button|the|a|an)\\b", " ")
                    .replaceAll("\\s+", " ").trim();
            if (!cleaned.isBlank()) return cleaned;
        }
        return selector == null ? "" : selector;
    }

    private void prepareElementForClick(McpClient mcp, McpToolCatalog catalog, String selector, int timeoutSeconds) {
        Optional<McpTool> eval = catalog.evaluateTool();
        if (eval.isEmpty()) return;
        try {
            String encoded = Base64.getEncoder().encodeToString(selector.getBytes(StandardCharsets.UTF_8));
            String script = """
                (() => {
                  const selector = atob('%s');
                  let element;
                  try { element = document.querySelector(selector); } catch (e) { return JSON.stringify({ready:false,error:e.message}); }
                  if (!element) return JSON.stringify({ready:false,error:'not-found'});
                  element.scrollIntoView({block:'center', inline:'center', behavior:'instant'});
                  const inspect = () => {
                    const r = element.getBoundingClientRect();
                    const style = getComputedStyle(element);
                    const x = Math.max(0, Math.min(innerWidth - 1, r.left + r.width / 2));
                    const y = Math.max(0, Math.min(innerHeight - 1, r.top + r.height / 2));
                    const top = document.elementFromPoint(x, y);
                    const receives = !!top && (top === element || element.contains(top) || top.contains(element));
                    return {ready:r.width>1&&r.height>1&&style.visibility!=='hidden'&&style.display!=='none'&&receives,
                            top:top ? (top.tagName + '#' + (top.id||'') + '.' + [...top.classList].slice(0,3).join('.')) : '',
                            disabled:!!element.disabled};
                  };
                  return JSON.stringify(inspect());
                })()
                """.formatted(encoded);
            Map<String,Object> evalArgs = new LinkedHashMap<>();
            if (schemaContains(eval.get(), "expression")) evalArgs.put("expression", script);
            else if (schemaContains(eval.get(), "script")) evalArgs.put("script", script);
            else evalArgs.put("code", script);
            mcp.callTool(eval.get().getName(), evalArgs);
        } catch (Exception ignored) { }
    }

    private JsonNode safeDomClick(McpClient mcp, McpToolCatalog catalog, String selector) {
        Optional<McpTool> eval = catalog.evaluateTool();
        if (eval.isEmpty()) return mapper.createObjectNode().put("clicked", false).put("reason", "evaluate-tool-unavailable");
        try {
            String encoded = Base64.getEncoder().encodeToString(selector.getBytes(StandardCharsets.UTF_8));
            String script = """
                (() => {
                  const raw = atob('%s').trim();
                  const norm = value => String(value || '').replace(/\\s+/g, ' ').trim();
                  const visible = element => {
                    if (!element || !(element instanceof Element)) return false;
                    const r = element.getBoundingClientRect();
                    const c = getComputedStyle(element);
                    return r.width > 2 && r.height > 2 && c.display !== 'none' &&
                           c.visibility !== 'hidden' && Number(c.opacity || 1) > 0;
                  };
                  const clickableAncestor = element => {
                    let current = element;
                    for (let depth = 0; current && depth < 7; depth++, current = current.parentElement) {
                      const tag = (current.tagName || '').toLowerCase();
                      const role = (current.getAttribute?.('role') || '').toLowerCase();
                      if (['button','a','input','summary','option','li'].includes(tag) ||
                          ['button','menuitem','option','link','tab'].includes(role) ||
                          current.hasAttribute?.('onclick') || current.tabIndex >= 0) return current;
                    }
                    return element;
                  };
                  const exactText = (() => {
                    let value = raw;
                    const textMatch = raw.match(/^(?:text|has-text)\\s*=\\s*['"]?(.*?)['"]?$/i);
                    if (textMatch) value = textMatch[1];
                    const roleName = raw.match(/name\\s*=\\s*['"](.*?)['"]/i);
                    if (roleName) value = roleName[1];
                    return norm(value.replace(/^['"]|['"]$/g, ''));
                  })();

                  let candidates = [];
                  try {
                    if (raw.startsWith('//')) {
                      const result = document.evaluate(raw, document, null, XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null);
                      for (let i = 0; i < result.snapshotLength; i++) candidates.push(result.snapshotItem(i));
                    } else if (!raw.startsWith('@') && !/^(text|role|has-text)\\s*=/i.test(raw)) {
                      candidates = [...document.querySelectorAll(raw)];
                    }
                  } catch (ignore) { }

                  if (!candidates.some(visible) && exactText) {
                    const all = [...document.querySelectorAll('button,a,[role="menuitem"],[role="option"],[role="button"],li,div,span')];
                    candidates = all.filter(element => {
                      if (!visible(element)) return false;
                      const values = [element.innerText, element.textContent, element.getAttribute('aria-label'),
                                      element.getAttribute('title'), element.getAttribute('data-testid')].map(norm);
                      return values.some(value => value === exactText);
                    });
                    if (!candidates.length) {
                      candidates = all.filter(element => visible(element) &&
                        [element.innerText, element.textContent, element.getAttribute('aria-label'), element.getAttribute('title')]
                          .map(norm).some(value => value && value.toLowerCase().includes(exactText.toLowerCase())));
                    }
                  }

                  candidates = candidates.filter(visible).map(clickableAncestor).filter(visible);
                  candidates = [...new Set(candidates)].sort((a,b) => {
                    const ar=a.getBoundingClientRect(), br=b.getBoundingClientRect();
                    const aExact = norm(a.innerText || a.textContent || a.getAttribute('aria-label')) === exactText ? 0 : 1;
                    const bExact = norm(b.innerText || b.textContent || b.getAttribute('aria-label')) === exactText ? 0 : 1;
                    return aExact-bExact || (ar.width*ar.height)-(br.width*br.height);
                  });
                  let element = candidates[0];
                  if (!element) return JSON.stringify({clicked:false,reason:'no-visible-semantic-match',selector:raw,text:exactText});
                  if (element.disabled || element.getAttribute('aria-disabled') === 'true')
                    return JSON.stringify({clicked:false,reason:'disabled'});

                  // Prefer the menu row/container over a nested text span. Many enterprise apps use delegated click handlers on LI.
                  const nestedTextNode = element.matches?.('span,small,strong,em,b') ? element : null;
                  if (nestedTextNode) {
                    const row = nestedTextNode.closest('li,[role="menuitem"],[role="option"],a,button');
                    if (row && visible(row)) element = row;
                  }
                  element.scrollIntoView({block:'center', inline:'center', behavior:'instant'});
                  element.focus?.({preventScroll:true});
                  const r = element.getBoundingClientRect();
                  const points = [[.5,.5],[.25,.5],[.75,.5],[.5,.25],[.5,.75]];
                  let hit = null;
                  for (const [px,py] of points) {
                    const x = Math.max(0, Math.min(innerWidth-1, r.left+r.width*px));
                    const y = Math.max(0, Math.min(innerHeight-1, r.top+r.height*py));
                    const top = document.elementFromPoint(x,y);
                    if (top && (top===element || element.contains(top))) { hit={x,y,top}; break; }
                  }

                  const options = {bubbles:true,cancelable:true,composed:true,view:window,
                                   clientX:hit?.x ?? r.left+r.width/2, clientY:hit?.y ?? r.top+r.height/2,
                                   button:0,buttons:1,pointerId:1,pointerType:'mouse',isPrimary:true};
                  const dispatchTarget = hit?.top && element.contains(hit.top) ? hit.top : element;
                  for (const type of ['pointerover','mouseover','mouseenter','pointermove','mousemove','pointerdown','mousedown','pointerup','mouseup']) {
                    try { dispatchTarget.dispatchEvent(type.startsWith('pointer') ? new PointerEvent(type,options) : new MouseEvent(type,options)); } catch(ignore) { }
                  }
                  // First use the actual hit node, then the semantic menu container. This supports both direct and delegated handlers.
                  try { dispatchTarget.click?.(); } catch(ignore) { }
                  if (dispatchTarget !== element) { try { element.click?.(); } catch(ignore) { } }
                  try { element.dispatchEvent(new MouseEvent('click',options)); } catch(ignore) { }
                  return JSON.stringify({clicked:true,selector:raw,matchedText:norm(element.innerText || element.textContent || element.getAttribute('aria-label')).slice(0,160),
                    tag:element.tagName,role:element.getAttribute('role') || '',hitTestPassed:!!hit,candidateCount:candidates.length});
                })()
                """.formatted(encoded);
            Map<String,Object> evalArgs = new LinkedHashMap<>();
            if (schemaContains(eval.get(), "expression")) evalArgs.put("expression", script);
            else if (schemaContains(eval.get(), "script")) evalArgs.put("script", script);
            else evalArgs.put("code", script);
            return unwrapJsonString(mcp.callTool(eval.get().getName(), evalArgs));
        } catch (Exception e) {
            return mapper.createObjectNode().put("clicked", false).put("reason", e.getMessage());
        }
    }

    private void validateSelectorUniqueness(McpClient mcp, McpToolCatalog catalog, String toolName, Map<String, Object> args) {
        Object raw = args.get("selector");
        if (raw == null) return;
        String selector = String.valueOf(raw).trim();
        if (selector.isBlank() || selector.startsWith("@") || selector.startsWith("text=") || selector.startsWith("role=")) return;
        Optional<McpTool> eval = catalog.evaluateTool();
        if (eval.isEmpty()) return;
        try {
            String encoded = Base64.getEncoder().encodeToString(selector.getBytes(StandardCharsets.UTF_8));
            String script = "(() => {const s=atob('" + encoded + "');let all=[];try{if(s.startsWith('//')){const x=document.evaluate(s,document,null,XPathResult.ORDERED_NODE_SNAPSHOT_TYPE,null);for(let i=0;i<x.snapshotLength;i++)all.push(x.snapshotItem(i));}else all=[...document.querySelectorAll(s)];}catch(e){return JSON.stringify({selector:s,error:e.message,count:0,visible:0});}const vis=all.filter(e=>{try{const r=e.getBoundingClientRect(),c=getComputedStyle(e);return r.width>1&&r.height>1&&c.display!=='none'&&c.visibility!=='hidden'}catch(x){return false}});return JSON.stringify({selector:s,count:all.length,visible:vis.length,tags:vis.slice(0,10).map(e=>({tag:e.tagName,id:e.id||'',text:(e.innerText||e.value||e.getAttribute?.('aria-label')||'').trim().slice(0,80)}))});})()";
            Map<String,Object> evalArgs=new LinkedHashMap<>();
            if(schemaContains(eval.get(),"expression"))evalArgs.put("expression",script);else if(schemaContains(eval.get(),"script"))evalArgs.put("script",script);else evalArgs.put("code",script);
            JsonNode inspected=unwrapJsonString(mcp.callTool(eval.get().getName(),evalArgs));
            int count=inspected.path("count").asInt(-1), visible=inspected.path("visible").asInt(-1);
            if(count==0) throw new IllegalStateException("Selector matched no elements before " + toolName + ": " + selector);
            if(visible==0) throw new IllegalStateException("Selector matched only hidden elements before " + toolName + ": " + selector);
            if(visible>1) throw new IllegalStateException("Ambiguous selector matched " + visible + " visible elements before " + toolName + ": " + selector + ". Candidate evidence=" + compact(inspected.toString(),1200));
        } catch (IllegalStateException e) { throw e; }
        catch (Exception ignored) { }
    }

    private Map<String, Object> normalizeArgsForTool(McpTool tool, JsonNode argsNode) {
        Map<String, Object> args = toMap(argsNode);
        if (args.containsKey("selector") && args.get("selector") instanceof Collection<?> c && !c.isEmpty()) {
            args.put("selector", String.valueOf(c.iterator().next()));
        }
        if (!args.containsKey("selector")) {
            for (String k : List.of("ref", "target", "locator")) {
                if (args.containsKey(k) && schemaContains(tool, "selector")) {
                    args.put("selector", args.get(k));
                    break;
                }
            }
        }
        if (schemaContains(tool, "timeout")) {
            Object timeout = args.get("timeout");
            long value = 0L;
            if (timeout instanceof Number n) value = n.longValue();
            else if (timeout != null) {
                try { value = Long.parseLong(String.valueOf(timeout)); } catch (Exception ignored) { value = 0L; }
            }
            if (value < 1000L) args.put("timeout", 15000);
        }
        return args;
    }

    private String buildAgentPrompt(String instruction, TestScenario scenario, McpToolCatalog catalog, JsonNode observation, String failure) throws Exception {
        StringBuilder sb = new StringBuilder();
        sb.append("You are the execution brain for ITPS VIBIUM Framework V10 Responsible. Plan browser actions using Vibium MCP only.\n");
        sb.append("The browser is already started. Never call browser_start.\n");
        sb.append("Instruction: ").append(instruction).append("\n");
        sb.append("Scenario: ").append(scenario.getId()).append(" - ").append(scenario.getName()).append("\n");
        sb.append("Test data: ").append(mapper.writeValueAsString(scenario.getData())).append("\n");
        sb.append("Selection policy:\n");
        sb.append("- Composite instructions such as hover-and-click MUST be returned as ordered calls: hover/open trigger, wait or fresh observation when available, then click the exact visible menu item. Do not collapse 'New Search' to 'New'.\n");
        sb.append("- A tool call completing is not proof of success. Choose actions that create an observable postcondition in URL, DOM, visible text, form value, menu state, or screenshot.\n");
        sb.append("- Use rankedCandidates first. Each candidate contains a stable candidateId, accessibleName, context, interactiveReason and a unique cssSelector.\n");
        sb.append("- Prefer Vibium @e refs when the map exposes the exact intended element. Otherwise use the candidate cssSelector.\n");
        sb.append("- Never reduce an icon instruction to visible text. Search/filter/calendar/menu icons must be identified by accessibleName, aria, title, test id, SVG metadata, surrounding context or unique position inside the correct container.\n");
        sb.append("- Never choose the first matching element when multiple candidates exist. Use containerContext, selectedValues, nearby text and occurrence evidence.\n");
        sb.append("- For repeated controls, select the element inside the container described by the instruction. Example: the Perimeter control containing BCEF and Monaco, not the first Perimeter control.\n");
        sb.append("- Do not use a generic selector that matches multiple elements. Return a unique selector or a precise @e ref.\n");
        sb.append("- For custom dropdowns, click the correct container/input, then type/fill, wait for options, re-map if required, and click the exact option.\n");
        sb.append("- For click/fill/select, return at least one real action tool. browser_map/browser_wait_for_load alone is not an action.\n");
        sb.append("- Return only minified JSON: {\"calls\":[{\"tool\":\"browser_click\",\"arguments\":{\"selector\":\"#unique-selector\"}}],\"why\":\"candidateId and evidence used\"}.\n");
        sb.append("Available MCP tools:\n").append(catalog.toPromptText()).append("\n");
        sb.append("Current unified page observation. pageModel.actionElements is for actions; pageModel.contentElements/formValues/tables/allVisibleText are for validation and context. rankedCandidates is intent-specific:\n")
                .append(compact(observation == null ? "" : observation.toString(), 60000)).append("\n");
        if (failure != null) sb.append("Previous attempt failed: ").append(failure).append("\nReturn a corrected plan using different evidence.\n");
        return sb.toString();
    }

    private JsonNode safeDomProbe(McpClient mcp, McpToolCatalog catalog) {
        Optional<McpTool> eval = catalog.evaluateTool();
        if (eval.isEmpty()) return mapper.createObjectNode().put("note", "No browser_evaluate/eval MCP tool available");
        String script = """
            (() => {
              const norm = value => (value ?? '').toString().replace(/\\s+/g, ' ').trim();
              const visible = element => {
                try {
                  const rect = element.getBoundingClientRect();
                  const style = getComputedStyle(element);
                  return rect.width > 0 && rect.height > 0 && style.display !== 'none' &&
                         style.visibility !== 'hidden' && style.opacity !== '0' &&
                         rect.bottom >= 0 && rect.right >= 0;
                } catch (_) { return false; }
              };
              const css = element => {
                try {
                  if (element.id) return '#' + CSS.escape(element.id);
                  for (const attr of ['data-testid','data-test','data-cy','name','aria-label']) {
                    const value = element.getAttribute?.(attr);
                    if (value) {
                      const selector = '[' + attr + '=\\"' + CSS.escape(value) + '\\"]';
                      if (document.querySelectorAll(selector).length === 1) return selector;
                    }
                  }
                  const path = [];
                  for (let node = element; node && node.nodeType === 1 && path.length < 10; node = node.parentElement) {
                    let part = node.tagName.toLowerCase();
                    const stableClasses = [...node.classList]
                      .filter(c => c && !/[0-9a-f]{8,}/i.test(c) && c.length < 60).slice(0, 2);
                    if (stableClasses.length) part += '.' + stableClasses.map(CSS.escape).join('.');
                    const siblings = node.parentElement ? [...node.parentElement.children].filter(x => x.tagName === node.tagName) : [];
                    if (siblings.length > 1) part += ':nth-of-type(' + (siblings.indexOf(node) + 1) + ')';
                    path.unshift(part);
                    const candidate = path.join(' > ');
                    try { if (document.querySelectorAll(candidate).length === 1) return candidate; } catch (_) {}
                  }
                  return path.join(' > ');
                } catch (_) { return ''; }
              };
              const accessibleName = element => {
                try {
                  const aria = norm(element.getAttribute?.('aria-label'));
                  if (aria) return aria;
                  const labelledBy = norm(element.getAttribute?.('aria-labelledby'));
                  if (labelledBy) {
                    const value = labelledBy.split(/\\s+/).map(id => {
                      const label = document.getElementById(id);
                      return norm(label?.innerText || label?.textContent);
                    }).filter(Boolean).join(' ');
                    if (value) return value;
                  }
                  if (element.labels?.length) {
                    const value = [...element.labels].map(x => norm(x.innerText || x.textContent)).filter(Boolean).join(' ');
                    if (value) return value;
                  }
                  if (element.id) {
                    const label = document.querySelector('label[for=\\"' + CSS.escape(element.id) + '\\"]');
                    const value = norm(label?.innerText || label?.textContent);
                    if (value) return value;
                  }
                  const wrappingLabel = element.closest?.('label');
                  if (wrappingLabel) return norm(wrappingLabel.innerText || wrappingLabel.textContent);
                  return norm(element.getAttribute?.('alt') || element.getAttribute?.('title') ||
                              element.getAttribute?.('placeholder') || element.value || '');
                } catch (_) { return ''; }
              };
              const directText = element => {
                try {
                  const parts = [];
                  for (const node of element.childNodes || []) {
                    if (node.nodeType === Node.TEXT_NODE) parts.push(node.textContent || '');
                  }
                  return norm(parts.join(' '));
                } catch (_) { return ''; }
              };
              const context = element => {
                const values = [];
                try {
                  let node = element;
                  for (let level = 0; node && level < 5; level++, node = node.parentElement) {
                    const heading = node.querySelector?.(':scope > label,:scope > legend,:scope > h1,:scope > h2,:scope > h3,:scope > h4,:scope > h5,:scope > [class*=label],:scope > [class*=title],:scope > [class*=header]');
                    const headingText = norm(heading?.innerText || heading?.textContent);
                    if (headingText && headingText.length < 220) values.push(headingText);
                    const own = norm(node.getAttribute?.('aria-label') || node.getAttribute?.('title'));
                    if (own) values.push(own);
                  }
                } catch (_) {}
                return [...new Set(values)].slice(0, 8).join(' | ');
              };
              const isInteractive = element => {
                const tag = (element.tagName || '').toLowerCase();
                const role = norm(element.getAttribute?.('role')).toLowerCase();
                let cursor = '';
                try { cursor = getComputedStyle(element).cursor; } catch (_) {}
                return ['button','input','select','textarea','a','summary','option'].includes(tag) ||
                  ['button','link','tab','menuitem','checkbox','radio','combobox','option','switch','textbox','searchbox','slider'].includes(role) ||
                  element.hasAttribute?.('onclick') || element.tabIndex >= 0 || element.isContentEditable ||
                  cursor === 'pointer' || element.hasAttribute?.('data-testid') || element.hasAttribute?.('data-test') ||
                  element.hasAttribute?.('aria-label');
              };
              const interactiveReason = element => {
                const values = [];
                const tag = (element.tagName || '').toLowerCase();
                const role = norm(element.getAttribute?.('role'));
                if (['button','input','select','textarea','a','summary','option'].includes(tag)) values.push(tag);
                if (role) values.push('role=' + role);
                if (element.hasAttribute?.('onclick')) values.push('onclick');
                if (element.tabIndex >= 0) values.push('tabindex');
                try { if (getComputedStyle(element).cursor === 'pointer') values.push('cursor:pointer'); } catch (_) {}
                if (element.isContentEditable) values.push('contenteditable');
                if (tag === 'svg' || tag === 'path' || element.closest?.('svg')) values.push('icon/svg');
                return values.join(',');
              };
              const selectedValues = element => {
                try {
                  const values = [];
                  if (element.tagName === 'SELECT') {
                    values.push(...[...element.selectedOptions].map(x => norm(x.textContent || x.value)));
                  }
                  values.push(...[...element.querySelectorAll?.('[class*=chip],[class*=tag],[class*=token],[role=option][aria-selected=true],[aria-checked=true]') || []]
                    .map(x => norm(x.innerText || x.textContent || x.getAttribute?.('aria-label'))));
                  return [...new Set(values.filter(Boolean))].slice(0, 50);
                } catch (_) { return []; }
              };
              const actionElements = [];
              const contentElements = [];
              const formValues = [];
              const tables = [];
              const frames = [];
              const seenAction = new Set();
              const seenContent = new Set();
              let actionSeq = 0, contentSeq = 0;

              const baseRecord = (element, scope) => {
                const rect = element.getBoundingClientRect();
                const tag = (element.tagName || '').toLowerCase();
                const text = norm(element.innerText || element.textContent).slice(0, 1200);
                const ownText = directText(element).slice(0, 500);
                const value = norm(element.value).slice(0, 500);
                return {
                  scope, tag, role: norm(element.getAttribute?.('role')), type: norm(element.getAttribute?.('type')),
                  accessibleName: accessibleName(element).slice(0, 500), text, ownText,
                  context: context(element), id: element.id || '', name: norm(element.getAttribute?.('name')),
                  placeholder: norm(element.getAttribute?.('placeholder')), ariaLabel: norm(element.getAttribute?.('aria-label')),
                  title: norm(element.getAttribute?.('title')),
                  testId: norm(element.getAttribute?.('data-testid') || element.getAttribute?.('data-test') || element.getAttribute?.('data-cy')),
                  value, selectedValues: selectedValues(element), checked: !!element.checked, disabled: !!element.disabled,
                  cssSelector: css(element), rect: {x: Math.round(rect.x), y: Math.round(rect.y), w: Math.round(rect.width), h: Math.round(rect.height)},
                  viewport: {w: innerWidth, h: innerHeight}
                };
              };

              const addAction = (element, scope) => {
                if (!visible(element) || !isInteractive(element) || seenAction.has(element)) return;
                seenAction.add(element);
                const record = baseRecord(element, scope);
                record.candidateId = 'action-' + (++actionSeq);
                record.kind = 'ACTION';
                record.interactiveReason = interactiveReason(element);
                actionElements.push(record);
              };

              const addContent = (element, scope) => {
                if (!visible(element) || seenContent.has(element)) return;
                const tag = (element.tagName || '').toLowerCase();
                if (['script','style','noscript','template','meta','link','path'].includes(tag)) return;
                const record = baseRecord(element, scope);
                const meaningful = record.ownText || record.accessibleName || record.value || record.selectedValues.length;
                const semantic = ['h1','h2','h3','h4','h5','h6','p','span','label','legend','li','td','th','dt','dd','strong','small','em','b','output','option','caption','div'].includes(tag);
                const childVisibleTextElements = [...(element.children || [])].filter(child => visible(child) && norm(child.innerText || child.textContent));
                const leafLike = childVisibleTextElements.length === 0 || !!record.ownText || ['td','th','label','option','output'].includes(tag);
                if (!meaningful || (!semantic && !leafLike)) return;
                if (!leafLike && record.text.length > 600) return; // avoid giant page containers
                seenContent.add(element);
                record.contentId = 'content-' + (++contentSeq);
                record.kind = 'CONTENT';
                record.text = (record.ownText || record.text).slice(0, 600);
                contentElements.push(record);
              };

              const addFormValue = (element, scope) => {
                const tag = (element.tagName || '').toLowerCase();
                if (!visible(element) || !['input','select','textarea','output'].includes(tag)) return;
                const record = baseRecord(element, scope);
                record.kind = 'FORM_VALUE';
                formValues.push(record);
              };

              const addTable = (table, scope) => {
                if (!visible(table)) return;
                try {
                  const rows = [...table.querySelectorAll('tr')].slice(0, 300).map(row =>
                    [...row.querySelectorAll(':scope > th,:scope > td')].map(cell => norm(cell.innerText || cell.textContent))
                  ).filter(row => row.some(Boolean));
                  tables.push({scope, selector: css(table), caption: norm(table.caption?.innerText || table.caption?.textContent), rows});
                } catch (_) {}
              };

              const walk = (root, scope) => {
                let elements = [];
                try { elements = [...root.querySelectorAll('*')]; } catch (_) {}
                for (const element of elements) {
                  addAction(element, scope);
                  addContent(element, scope);
                  addFormValue(element, scope);
                  if (element.tagName === 'TABLE') addTable(element, scope);
                  if (element.shadowRoot) walk(element.shadowRoot, scope + ' > shadow(' + (element.id || element.tagName || 'host') + ')');
                  if (element.tagName === 'IFRAME') {
                    try {
                      if (element.contentDocument) walk(element.contentDocument, scope + ' > iframe(' + (element.name || element.id || 'same-origin') + ')');
                    } catch (_) {
                      frames.push({scope, selector: css(element), type: 'cross-origin'});
                    }
                  }
                }
              };

              walk(document, 'document');
              const allVisibleText = [...new Set(contentElements.map(x => x.text).filter(Boolean))].join(' \\n ').slice(0, 250000);
              return JSON.stringify({
                version: 3,
                counts: {action: actionElements.length, content: contentElements.length, formValues: formValues.length, tables: tables.length},
                actionElements: actionElements.slice(0, 6000),
                contentElements: contentElements.slice(0, 12000),
                formValues: formValues.slice(0, 4000),
                tables: tables.slice(0, 500),
                frames,
                allVisibleText,
                truncated: actionElements.length > 6000 || contentElements.length > 12000
              });
            })()
            """;
        Map<String, Object> args = new LinkedHashMap<>();
        if (schemaContains(eval.get(), "expression")) args.put("expression", script);
        else if (schemaContains(eval.get(), "script")) args.put("script", script);
        else args.put("code", script);
        JsonNode raw = safeToolResult(mcp, eval, args);
        return unwrapJsonString(raw);
    }

    private JsonNode unwrapJsonString(JsonNode raw) {
        if (raw == null) return mapper.createObjectNode().put("error", "empty DOM probe result");
        List<String> texts = new ArrayList<>();
        collectTextValues(raw, texts);
        texts.sort(Comparator.comparingInt(String::length).reversed());
        for (String text : texts) {
            String t = text == null ? "" : text.trim();
            if (!(t.startsWith("{") || t.startsWith("["))) continue;
            try { return mapper.readTree(t); } catch (Exception ignored) {}
        }
        return raw;
    }

    private void collectTextValues(JsonNode node, List<String> out) {
        if (node == null) return;
        if (node.isTextual()) { out.add(node.asText()); return; }
        if (node.isArray()) for (JsonNode c : node) collectTextValues(c, out);
        else if (node.isObject()) node.fields().forEachRemaining(e -> collectTextValues(e.getValue(), out));
    }

    private ArrayNode rankCandidates(JsonNode observation, String instruction, int limit) {
        ArrayNode ranked = mapper.createArrayNode();
        String intent = expectedIntent(instruction);
        List<JsonNode> elements = collectCandidateElements(observation, intent);
        Set<String> tokens = instructionTokens(instruction);
        List<Map.Entry<Integer, JsonNode>> scored = new ArrayList<>();
        for (JsonNode element : elements) {
            int score = candidateScore(element, tokens, instruction);
            if (score > 0) scored.add(Map.entry(score, element));
        }
        scored.sort((a, b) -> Integer.compare(b.getKey(), a.getKey()));
        for (int i = 0; i < Math.min(limit, scored.size()); i++) {
            ObjectNode copy = scored.get(i).getValue().deepCopy();
            copy.put("matchScore", scored.get(i).getKey());
            ranked.add(copy);
        }
        return ranked;
    }

    private List<JsonNode> collectCandidateElements(JsonNode observation, String intent) {
        List<JsonNode> out = new ArrayList<>();
        JsonNode model = observation == null ? null : observation.path("pageModel");
        if (model == null || model.isMissingNode()) return out;
        if ("ASSERT".equals(intent)) {
            appendArray(out, model.path("contentElements"));
            appendArray(out, model.path("formValues"));
            // Action elements may also expose status text through accessible names.
            appendArray(out, model.path("actionElements"));
        } else {
            appendArray(out, model.path("actionElements"));
            // Content elements provide parent/nearby context for unlabeled controls.
            appendArray(out, model.path("contentElements"));
        }
        return out;
    }

    private void appendArray(List<JsonNode> target, JsonNode array) {
        if (array != null && array.isArray()) array.forEach(target::add);
    }

    private Set<String> instructionTokens(String instruction) {
        Set<String> stop = Set.of("click","select","type","enter","fill","the","a","an","in","on","from","to","and","button","icon","field","dropdown","element","with","of","is","that","same");
        Set<String> out = new LinkedHashSet<>();
        for (String t : (instruction == null ? "" : instruction.toLowerCase(Locale.ROOT)).split("[^a-z0-9_-]+")) if (t.length()>1 && !stop.contains(t)) out.add(t);
        return out;
    }

    private int candidateScore(JsonNode element, Set<String> tokens, String instruction) {
        String name = element.path("accessibleName").asText("").toLowerCase(Locale.ROOT);
        String text = element.path("text").asText("").toLowerCase(Locale.ROOT);
        String ownText = element.path("ownText").asText("").toLowerCase(Locale.ROOT);
        String context = element.path("context").asText("").toLowerCase(Locale.ROOT);
        String attrs = (element.path("id").asText("") + " " + element.path("name").asText("") + " " +
                element.path("ariaLabel").asText("") + " " + element.path("title").asText("") + " " +
                element.path("testId").asText("") + " " + element.path("placeholder").asText("") + " " +
                element.path("value").asText("")).toLowerCase(Locale.ROOT);
        String lower = instruction == null ? "" : instruction.toLowerCase(Locale.ROOT);
        String intent = expectedIntent(instruction);
        int score = 0;
        for (String token : tokens) {
            if (name.equals(token)) score += 55; else if (name.contains(token)) score += 28;
            if (ownText.equals(token)) score += 60; else if (ownText.contains(token)) score += 32;
            if (attrs.contains(token)) score += 24;
            if (text.equals(token)) score += 50; else if (text.contains(token)) score += 18;
            if (context.contains(token)) score += 20;
            if (element.path("selectedValues").toString().toLowerCase(Locale.ROOT).contains(token)) score += 35;
        }
        String kind = element.path("kind").asText("");
        if ("ASSERT".equals(intent)) {
            if ("CONTENT".equals(kind) || "FORM_VALUE".equals(kind)) score += 30;
            if (!text.isBlank() && lower.contains(text)) score += 45;
        } else if ("ACTION".equals(kind)) {
            score += 22;
        }
        String reason = element.path("interactiveReason").asText("").toLowerCase(Locale.ROOT);
        if (lower.contains("icon") && reason.contains("icon")) score += 25;
        if ((lower.contains("dropdown") || lower.contains("drop down")) &&
                (reason.contains("select") || "combobox".equalsIgnoreCase(element.path("role").asText()))) score += 25;
        if (lower.contains("status") && (context.contains("status") || text.contains("status"))) score += 18;
        if (element.path("disabled").asBoolean(false) && !"ASSERT".equals(intent)) score -= 100;
        return score;
    }

    private void writeElementInventory(Path runDir, String scenarioId, int stepNo, JsonNode observation) {
        if (observation == null) return;
        try {
            Path dir = runDir.resolve("elements");
            Files.createDirectories(dir);
            String safe = (scenarioId == null ? "scenario" : scenarioId).replaceAll("[^a-zA-Z0-9._-]", "_");
            mapper.writerWithDefaultPrettyPrinter().writeValue(dir.resolve(safe + "_step_" + stepNo + "_elements.json").toFile(), observation);
        } catch (Exception ignored) {}
    }

    private JsonNode safeMap(McpClient mcp, McpToolCatalog catalog) {
        Optional<McpTool> mapTool = catalog.mapTool();
        if (mapTool.isEmpty()) return mapper.createObjectNode().put("note", "No browser_map/snapshot tool available");
        Map<String, Object> args = new LinkedHashMap<>();
        if (schemaContains(mapTool.get(), "selector")) args.put("selector", "body");
        return safeToolResult(mcp, mapTool, args);
    }

    private JsonNode safeToolResult(McpClient mcp, Optional<McpTool> tool, Map<String, Object> args) {
        try {
            if (tool.isEmpty()) return mapper.createObjectNode().put("note", "tool not available");
            return mcp.callTool(tool.get().getName(), args == null ? Map.of() : args);
        } catch (Exception e) {
            return mapper.createObjectNode().put("error", e.getMessage());
        }
    }

    private String pageFingerprint(McpClient mcp, McpToolCatalog catalog) {
        JsonNode obs = observePage(mcp, catalog);
        String text = compact(extractText(obs), 50000);
        return Integer.toHexString(Objects.hash(text));
    }

    private boolean screenshotsDifferent(Path screenshotDir, String before, String after) {
        if (!notBlank(before) || !notBlank(after)) return false;
        try {
            Path b = screenshotDir.resolve(before);
            Path a = screenshotDir.resolve(after);
            if (!Files.exists(b) || !Files.exists(a)) return false;
            byte[] bb = Files.readAllBytes(b);
            byte[] aa = Files.readAllBytes(a);
            return !Arrays.equals(bb, aa);
        } catch (Exception e) { return false; }
    }

    private void assertInstruction(String instruction, String mcpResult, JsonNode observation) {
        String normalizedInstruction = instruction == null ? "" : instruction.trim();
        String expected = normalizedInstruction.replaceFirst("(?i)^(verify|assert|check)\\s+", "").trim();
        boolean negative = expected.matches("(?i).*(is not|not displayed|not visible|not present|does not contain|should not).*?");
        expected = expected.replaceFirst("(?i)\\s+(is|should be)\\s+(displayed|visible|present).*$", "").trim();
        if (expected.isBlank()) return;

        JsonNode model = observation == null ? null : observation.path("pageModel");
        List<JsonNode> content = new ArrayList<>();
        if (model != null && !model.isMissingNode()) {
            appendArray(content, model.path("contentElements"));
            appendArray(content, model.path("formValues"));
            appendArray(content, model.path("actionElements"));
        }

        String expectedLower = expected.toLowerCase(Locale.ROOT);
        String allVisible = model == null ? "" : model.path("allVisibleText").asText("").toLowerCase(Locale.ROOT);
        boolean found = allVisible.contains(expectedLower);
        JsonNode matched = null;

        // Label/value validation: "Verify Host identifier is FRH..."
        Matcher pair = Pattern.compile("(?i)^(.+?)\\s+(?:is|equals|=|should be)\\s+(.+)$").matcher(expected);
        if (pair.matches()) {
            String label = pair.group(1).trim().toLowerCase(Locale.ROOT);
            String value = pair.group(2).trim().toLowerCase(Locale.ROOT);
            found = false;
            for (JsonNode element : content) {
                String text = searchableElementText(element);
                String context = element.path("context").asText("").toLowerCase(Locale.ROOT);
                String name = element.path("accessibleName").asText("").toLowerCase(Locale.ROOT);
                if ((text.contains(value) || element.path("value").asText("").toLowerCase(Locale.ROOT).contains(value)) &&
                        (text.contains(label) || context.contains(label) || name.contains(label))) {
                    found = true;
                    matched = element;
                    break;
                }
            }
            // Handle separate adjacent label and value elements in the same container/region.
            if (!found) {
                for (JsonNode labelElement : content) {
                    String labelText = searchableElementText(labelElement);
                    if (!labelText.contains(label)) continue;
                    int lx = labelElement.path("rect").path("x").asInt();
                    int ly = labelElement.path("rect").path("y").asInt();
                    String labelContext = labelElement.path("context").asText("");
                    for (JsonNode valueElement : content) {
                        String valueText = searchableElementText(valueElement);
                        if (!valueText.contains(value)) continue;
                        int vx = valueElement.path("rect").path("x").asInt();
                        int vy = valueElement.path("rect").path("y").asInt();
                        boolean near = Math.abs(vy - ly) <= 140 && Math.abs(vx - lx) <= 900;
                        boolean sameContext = !labelContext.isBlank() && labelContext.equals(valueElement.path("context").asText(""));
                        if (near || sameContext) {
                            found = true;
                            matched = valueElement;
                            break;
                        }
                    }
                    if (found) break;
                }
            }
        } else if (!found) {
            for (JsonNode element : content) {
                if (searchableElementText(element).contains(expectedLower)) {
                    found = true;
                    matched = element;
                    break;
                }
            }
        }

        if (negative ? found : !found) {
            throw new IllegalStateException("Assertion failed. Expected " + (negative ? "absence of: " : "visible UI content: ") + expected +
                    ". Unified page model counts=" + (model == null ? "unavailable" : model.path("counts").toString()));
        }
    }

    private String searchableElementText(JsonNode element) {
        return (element.path("accessibleName").asText("") + " " + element.path("text").asText("") + " " +
                element.path("ownText").asText("") + " " + element.path("value").asText("") + " " +
                element.path("context").asText("") + " " + element.path("selectedValues").toString())
                .toLowerCase(Locale.ROOT).replaceAll("\\s+", " ").trim();
    }

    private void assertMcpToolSuccess(String toolName, JsonNode result) {
        if (result == null || result.isMissingNode()) return;
        if (result.path("isError").asBoolean(false)) throw new IllegalStateException("MCP tool returned isError=true for " + toolName + ": " + compact(result.toString(), 2000));
        String text = extractText(result).toLowerCase(Locale.ROOT);
        String[] fatal = {"element not found", "not found", "timeout", "timed out", "failed", "error:", "exception", "unable to", "cannot", "invalid selector"};
        for (String f : fatal) if (text.contains(f)) throw new IllegalStateException("MCP tool result indicates failure for " + toolName + ": " + compact(text, 2000));
    }

    private JsonNode directAssertPlan(McpToolCatalog catalog) {
        ObjectNode plan = mapper.createObjectNode();
        ArrayNode calls = plan.putArray("calls");
        Optional<McpTool> tool = catalog.textTool().or(catalog::mapTool).or(catalog::titleTool);
        tool.ifPresent(value -> calls.add(simpleCall(value.getName(), Map.of())));
        return plan;
    }

    private JsonNode directNavigatePlan(McpToolCatalog catalog, String step) throws Exception {
        McpTool navigate = catalog.navigateTool().orElseThrow(() -> new IllegalArgumentException("No navigation MCP tool found"));
        String url = step.replaceFirst("(?i)^navigate\\s+to\\s+", "").trim();
        ArrayNode calls = mapper.createArrayNode();
        calls.add(simpleCall(navigate.getName(), argBySchema(navigate, "url", url, "href")));
        catalog.waitTool().ifPresent(wait -> calls.add(simpleCall(wait.getName(), Map.of())));
        ObjectNode plan = mapper.createObjectNode();
        plan.set("calls", calls);
        return plan;
    }

    private JsonNode directWaitPlan(McpToolCatalog catalog) {
        ObjectNode plan = mapper.createObjectNode();
        ArrayNode calls = plan.putArray("calls");
        catalog.waitTool().ifPresent(tool -> calls.add(simpleCall(tool.getName(), Map.of())));
        return plan;
    }

    private JsonNode removeNoOpStart(JsonNode plan) {
        ObjectNode out = mapper.createObjectNode();
        ArrayNode calls = mapper.createArrayNode();
        for (JsonNode c : flattenCalls(plan)) {
            String tool = firstText(c, "tool", "name", "mcpTool", "toolName");
            if (!isBrowserStart(tool)) calls.add(c);
        }
        out.set("calls", calls);
        return out;
    }

    private List<JsonNode> flattenCalls(JsonNode plan) {
        List<JsonNode> out = new ArrayList<>();
        if (plan == null || plan.isMissingNode() || plan.isNull()) return out;
        if (plan.has("calls") && plan.path("calls").isArray()) plan.path("calls").forEach(out::add);
        else out.add(plan);
        return out;
    }

    private boolean containsRealAction(JsonNode plan, String intent) {
        for (JsonNode c : flattenCalls(plan)) {
            String t = Optional.ofNullable(firstText(c, "tool", "name", "mcpTool", "toolName")).orElse("").toLowerCase(Locale.ROOT);
            if (isNoOpTool(t)) continue;
            if ("NAVIGATE".equals(intent) && containsAny(t, "navigate", "goto", "go", "open")) return true;
            if ("CLICK".equals(intent) && containsAny(t, "click", "tap", "press", "hover", "mouse", "evaluate")) return true;
            if ("HOVER".equals(intent) && containsAny(t, "hover", "mouse", "move", "evaluate")) return true;
            if ("COMPOSITE".equals(intent) && containsAny(t, "click", "tap", "press", "hover", "mouse", "move", "evaluate")) return true;
            if ("FILL".equals(intent) && containsAny(t, "fill", "type", "input", "write", "press", "evaluate")) return true;
            if ("SELECT".equals(intent) && containsAny(t, "select", "click", "press", "fill", "type", "evaluate")) return true;
            if ("ASSERT".equals(intent) && containsAny(t, "map", "snapshot", "text", "assert", "evaluate")) return true;
            if ("OTHER".equals(intent)) return true;
        }
        return false;
    }

    private boolean requiresRealAction(String intent) { return Set.of("NAVIGATE", "CLICK", "HOVER", "COMPOSITE", "FILL", "SELECT", "ASSERT", "OTHER").contains(intent); }
    private boolean requiresPostEvidence(String intent) { return Set.of("CLICK", "HOVER", "COMPOSITE", "SELECT", "FILL", "OTHER").contains(intent); }
    private boolean isActionTool(String tool) { return containsAny(tool, "click", "hover", "mouse", "move", "fill", "type", "select", "press", "navigate", "evaluate"); }
    private boolean isNoOpTool(String tool) { return containsAny(tool, "start", "map", "snapshot", "screenshot", "wait", "text", "title", "url") && !containsAny(tool, "click", "fill", "type", "navigate", "select", "press", "evaluate"); }
    private boolean isBrowserStart(String tool) { return tool != null && tool.toLowerCase(Locale.ROOT).contains("start"); }

    private String expectedIntent(String step) {
        String l = step == null ? "" : step.toLowerCase(Locale.ROOT).trim();
        if (isNavigate(step)) return "NAVIGATE";
        if (l.startsWith("verify") || l.startsWith("assert") || l.startsWith("check")) return "ASSERT";
        if (l.startsWith("wait")) return "WAIT";

        boolean hasHover = containsAny(l, "hover", "mouse over", "mouseover", "move mouse");
        boolean hasClick = containsAny(l, "click", "tap", "open", "choose");
        boolean hasFill = containsAny(l, "enter", "type", "fill", "search for");
        boolean hasSelect = containsAny(l, "select", "drop down", "dropdown");

        if ((hasHover && hasClick) || (hasClick && hasSelect) || (hasClick && hasFill)) return "COMPOSITE";
        if (hasHover) return "HOVER";
        if (hasClick) return "CLICK";
        if (hasFill) return "FILL";
        if (hasSelect) return "SELECT";
        return "OTHER";
    }

    private boolean isAssert(String intent) { return "ASSERT".equals(intent); }
    private boolean isNavigate(String step) { return step != null && step.trim().toLowerCase(Locale.ROOT).startsWith("navigate to "); }
    private boolean isWait(String step) { return step != null && step.trim().toLowerCase(Locale.ROOT).startsWith("wait"); }

    private String captureScreenshot(McpClient mcp, McpToolCatalog catalog, Path screenshotDir, String scenarioId, String stepNo) throws Exception {
        Optional<McpTool> tool = catalog.screenshotTool();
        if (tool.isEmpty()) return "";
        Files.createDirectories(screenshotDir);
        String safeScenario = scenarioId == null ? "scenario" : scenarioId.replaceAll("[^a-zA-Z0-9._-]", "_");
        String safeStep = stepNo == null ? "step" : stepNo.replaceAll("[^a-zA-Z0-9._-]", "_");
        String fileName = safeScenario + "_step_" + safeStep + ".png";
        Path out = screenshotDir.resolve(fileName).toAbsolutePath();
        long before = System.currentTimeMillis();
        Map<String, Object> args = new LinkedHashMap<>();
        if (schemaContains(tool.get(), "path")) args.put("path", out.toString());
        else if (schemaContains(tool.get(), "file")) args.put("file", out.toString());
        else if (schemaContains(tool.get(), "output")) args.put("output", out.toString());
        if (schemaContains(tool.get(), "annotate")) args.put("annotate", true);
        JsonNode result = mcp.callTool(tool.get().getName(), args);
        assertMcpToolSuccess(tool.get().getName(), result);
        if (Files.exists(out) && Files.size(out) > 0) return fileName;
        Optional<byte[]> png = findImageBytes(result);
        if (png.isPresent()) { Files.write(out, png.get()); return fileName; }
        Optional<Path> pathFromResult = findPngPath(result);
        if (pathFromResult.isPresent() && Files.exists(pathFromResult.get())) { Files.copy(pathFromResult.get(), out, StandardCopyOption.REPLACE_EXISTING); return fileName; }
        Optional<Path> newest = newestPng(screenshotDir, before - 1000);
        if (newest.isPresent()) { Files.copy(newest.get(), out, StandardCopyOption.REPLACE_EXISTING); return fileName; }
        return "";
    }

    private String captureScreenshotQuietly(McpClient mcp, McpToolCatalog catalog, Path screenshotDir, String scenarioId, String stepNo) {
        try { return captureScreenshot(mcp, catalog, screenshotDir, scenarioId, stepNo); }
        catch (Exception ignored) { return ""; }
    }

    private Optional<Path> newestPng(Path dir, long afterMs) {
        try (var stream = Files.list(dir)) {
            return stream.filter(p -> p.getFileName().toString().toLowerCase(Locale.ROOT).endsWith(".png"))
                    .filter(p -> {
                        try { return Files.getLastModifiedTime(p).toMillis() >= afterMs; } catch (Exception e) { return false; }
                    })
                    .max(Comparator.comparingLong(p -> {
                        try { return Files.getLastModifiedTime(p).toMillis(); } catch (Exception e) { return 0L; }
                    }));
        } catch (Exception e) { return Optional.empty(); }
    }

    private Optional<byte[]> findImageBytes(JsonNode node) {
        if (node == null || node.isNull() || node.isMissingNode()) return Optional.empty();
        if (node.isObject()) {
            String type = node.path("type").asText("");
            String mime = node.path("mimeType").asText("");
            String data = node.path("data").asText("");
            if ((("image".equalsIgnoreCase(type)) || mime.toLowerCase(Locale.ROOT).contains("png")) && notBlank(data)) {
                try { return Optional.of(Base64.getDecoder().decode(cleanBase64(data))); } catch (Exception ignored) {}
            }
            Iterator<Map.Entry<String, JsonNode>> it = node.fields();
            while (it.hasNext()) { Optional<byte[]> found = findImageBytes(it.next().getValue()); if (found.isPresent()) return found; }
        } else if (node.isArray()) {
            for (JsonNode c : node) { Optional<byte[]> found = findImageBytes(c); if (found.isPresent()) return found; }
        } else if (node.isTextual()) {
            String text = node.asText();
            if (text.startsWith("data:image/png;base64,")) text = text.substring("data:image/png;base64,".length());
            if (text.length() > 1000 && text.matches("^[A-Za-z0-9+/=\\r\\n]+$")) {
                try { return Optional.of(Base64.getDecoder().decode(cleanBase64(text))); } catch (Exception ignored) {}
            }
        }
        return Optional.empty();
    }

    private Optional<Path> findPngPath(JsonNode node) {
        String text = extractText(node);
        Matcher m = Pattern.compile("([A-Za-z]:\\\\[^\\n\"']+?\\.png)").matcher(text);
        if (m.find()) return Optional.of(Path.of(m.group(1)));
        m = Pattern.compile("(/[^\\n\"']+?\\.png)").matcher(text);
        if (m.find()) return Optional.of(Path.of(m.group(1)));
        return Optional.empty();
    }

    private String cleanBase64(String s) { return s == null ? "" : s.replace("data:image/png;base64,", "").replaceAll("\\s+", ""); }

    private Map<String, Object> toMap(JsonNode n) {
        if (n == null || n.isMissingNode() || n.isNull()) return new LinkedHashMap<>();
        return mapper.convertValue(n, new TypeReference<Map<String, Object>>() {});
    }

    private Map<String, Object> argBySchema(McpTool tool, String primary, String value, String fallback) {
        Map<String, Object> args = new LinkedHashMap<>();
        args.put(schemaContains(tool, primary) ? primary : fallback, value);
        return args;
    }

    private ObjectNode simpleCall(String tool, Map<String, Object> args) {
        ObjectNode c = mapper.createObjectNode();
        c.put("tool", tool);
        c.set("arguments", mapper.valueToTree(args == null ? Map.of() : args));
        return c;
    }

    private JsonNode normalizePlan(JsonNode plan) {
        if (plan == null) return mapper.createObjectNode();
        if (plan.isArray()) { ObjectNode p = mapper.createObjectNode(); p.set("calls", plan); return p; }
        if (plan.has("tool") || plan.has("calls") || plan.has("name") || plan.has("mcpTool")) return plan;
        return plan;
    }

    private JsonNode parseDirectJson(String step) throws Exception {
        String t = step == null ? "" : step.trim();
        if (!t.startsWith("{") && !t.startsWith("[")) return null;
        return mapper.readTree(t);
    }

    private String applyData(String input, Map<String, Object> data) {
        if (input == null || data == null) return input;
        String out = input;
        for (Map.Entry<String, Object> e : data.entrySet()) {
            String value = e.getValue() == null ? "" : String.valueOf(e.getValue());
            out = out.replace("{{" + e.getKey() + "}}", value);
            out = out.replace("${" + e.getKey() + "}", value);
        }
        return out;
    }

    private List<String> splitArgs(String args) {
        if (args == null || args.isBlank()) return List.of();
        List<String> out = new ArrayList<>();
        Matcher m = Pattern.compile("([^\\s\"]+)|\"([^\"]*)\"").matcher(args);
        while (m.find()) out.add(m.group(1) != null ? m.group(1) : m.group(2));
        return out;
    }

    private String resolveUrl(String url, String base) {
        if (!notBlank(url)) return "";
        String t = url.trim();
        if (t.startsWith("http://") || t.startsWith("https://")) return t;
        if (!notBlank(base)) return t;
        if (base.endsWith("/") && t.startsWith("/")) return base.substring(0, base.length() - 1) + t;
        if (!base.endsWith("/") && !t.startsWith("/")) return base + "/" + t;
        return base + t;
    }

    private boolean shouldScreenshot(RunConfig config, boolean pass) {
        String mode = config.getScreenshotMode() == null ? "ALL" : config.getScreenshotMode();
        if ("NONE".equalsIgnoreCase(mode)) return false;
        if ("ALL".equalsIgnoreCase(mode)) return true;
        return !pass;
    }

    private String firstText(JsonNode node, String... fields) {
        if (node == null) return null;
        for (String f : fields) {
            JsonNode v = node.path(f);
            if (v.isTextual() && !v.asText().isBlank()) return v.asText();
        }
        return null;
    }

    private boolean schemaContains(McpTool tool, String term) {
        return tool != null && tool.getInputSchema() != null && tool.getInputSchema().toString().toLowerCase(Locale.ROOT).contains(term.toLowerCase(Locale.ROOT));
    }

    private boolean containsAny(String text, String... terms) {
        if (text == null) return false;
        String l = text.toLowerCase(Locale.ROOT);
        for (String t : terms) if (l.contains(t.toLowerCase(Locale.ROOT))) return true;
        return false;
    }

    private boolean notBlank(String value) { return value != null && !value.trim().isEmpty(); }

    private String compact(String text, int max) {
        if (text == null) return "";
        String s = text.replaceAll("\\s+", " ").trim();
        return s.length() <= max ? s : s.substring(0, max) + "...";
    }

    private String extractText(JsonNode node) {
        if (node == null) return "";
        if (node.isTextual()) return node.asText();
        if (node.isNumber() || node.isBoolean()) return node.asText();
        StringBuilder sb = new StringBuilder();
        if (node.isObject()) node.fields().forEachRemaining(e -> sb.append(' ').append(e.getKey()).append(' ').append(extractText(e.getValue())));
        else if (node.isArray()) for (JsonNode c : node) sb.append(' ').append(extractText(c));
        return sb.toString();
    }

    private void sleep(long ms) { try { Thread.sleep(ms); } catch (InterruptedException e) { Thread.currentThread().interrupt(); } }

    private void writeToolsManifest(Path runDir, List<McpTool> tools) {
        try {
            Files.createDirectories(runDir);
            Files.writeString(runDir.resolve("mcp-tools.json"), mapper.writerWithDefaultPrettyPrinter().writeValueAsString(tools), StandardCharsets.UTF_8);
        } catch (Exception ignored) {}
    }

    private record PlannedStep(String source, JsonNode plan, JsonNode observation) {}
}
