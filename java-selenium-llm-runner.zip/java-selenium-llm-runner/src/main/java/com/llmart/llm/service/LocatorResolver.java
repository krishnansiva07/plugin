package com.llmart.llm.service;

import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

@Service
public class LocatorResolver {

    public WebElement findClickable(WebDriver driver, String target) {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));
        List<By> locators = clickableLocators(target);
        RuntimeException last = null;
        for (By by : locators) {
            try {
                return wait.until(ExpectedConditions.elementToBeClickable(by));
            } catch (RuntimeException e) {
                last = e;
            }
        }
        throw new NoSuchElementException("Unable to find clickable element for target: " + target + ". Last error: " + (last == null ? "" : last.getMessage()));
    }

    public WebElement findInput(WebDriver driver, String target) {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));
        List<By> locators = inputLocators(target);
        RuntimeException last = null;
        for (By by : locators) {
            try {
                WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(by));
                if (element.isEnabled()) {
                    return element;
                }
            } catch (RuntimeException e) {
                last = e;
            }
        }
        throw new NoSuchElementException("Unable to find input element for target: " + target + ". Last error: " + (last == null ? "" : last.getMessage()));
    }

    public WebElement findAny(WebDriver driver, String target) {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));
        List<By> locators = genericLocators(target);
        RuntimeException last = null;
        for (By by : locators) {
            try {
                return wait.until(ExpectedConditions.visibilityOfElementLocated(by));
            } catch (RuntimeException e) {
                last = e;
            }
        }
        throw new NoSuchElementException("Unable to find element for target: " + target + ". Last error: " + (last == null ? "" : last.getMessage()));
    }

    private List<By> clickableLocators(String target) {
        String clean = clean(target);
        String x = xpathLiteral(clean.toLowerCase(Locale.ROOT));
        List<By> locators = baseLocators(clean);
        locators.add(By.xpath("//*[self::button or self::a or @role='button' or @type='button' or @type='submit'][contains(translate(normalize-space(.),'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz')," + x + ")]"));
        locators.add(By.xpath("//*[self::button or self::a or @role='button' or @type='button' or @type='submit'][contains(translate(@aria-label,'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz')," + x + ")]"));
        locators.add(By.xpath("//*[self::button or self::a or @role='button' or @type='button' or @type='submit'][contains(translate(@value,'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz')," + x + ")]"));
        locators.add(By.xpath("//*[contains(translate(normalize-space(.),'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz')," + x + ") and (self::span or self::div)][ancestor-or-self::*[@role='button' or self::button or self::a]]"));
        return locators;
    }

    private List<By> inputLocators(String target) {
        String clean = clean(target)
                .replaceAll("(?i)field$", "")
                .replaceAll("(?i)textbox$", "")
                .trim();
        String lower = clean.toLowerCase(Locale.ROOT);
        String x = xpathLiteral(lower);
        List<By> locators = baseLocators(clean);
        locators.add(By.xpath("//input[contains(translate(@placeholder,'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz')," + x + ") or contains(translate(@name,'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz')," + x + ") or contains(translate(@id,'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz')," + x + ") or contains(translate(@aria-label,'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz')," + x + ")]"));
        locators.add(By.xpath("//textarea[contains(translate(@placeholder,'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz')," + x + ") or contains(translate(@name,'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz')," + x + ") or contains(translate(@id,'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz')," + x + ") or contains(translate(@aria-label,'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz')," + x + ")]"));
        locators.add(By.xpath("//label[contains(translate(normalize-space(.),'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz')," + x + ")]/following::input[1]"));
        locators.add(By.xpath("//*[contains(translate(normalize-space(.),'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz')," + x + ")]/following::input[1]"));
        locators.add(By.xpath("//*[contains(translate(normalize-space(.),'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz')," + x + ")]/following::textarea[1]"));
        return locators;
    }

    private List<By> genericLocators(String target) {
        String clean = clean(target);
        String x = xpathLiteral(clean.toLowerCase(Locale.ROOT));
        List<By> locators = baseLocators(clean);
        locators.add(By.xpath("//*[contains(translate(normalize-space(.),'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz')," + x + ")]"));
        locators.add(By.xpath("//*[@aria-label and contains(translate(@aria-label,'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz')," + x + ")]"));
        locators.add(By.xpath("//*[@title and contains(translate(@title,'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz')," + x + ")]"));
        return locators;
    }

    private List<By> baseLocators(String target) {
        List<By> locators = new ArrayList<>();
        if (target == null || target.isBlank()) {
            return locators;
        }
        String clean = clean(target);
        if (clean.startsWith("xpath=")) {
            locators.add(By.xpath(clean.substring("xpath=".length())));
            return locators;
        }
        if (clean.startsWith("css=")) {
            locators.add(By.cssSelector(clean.substring("css=".length())));
            return locators;
        }
        if (clean.startsWith("id=")) {
            locators.add(By.id(clean.substring("id=".length())));
            return locators;
        }
        if (clean.startsWith("name=")) {
            locators.add(By.name(clean.substring("name=".length())));
            return locators;
        }
        locators.add(By.id(clean));
        locators.add(By.name(clean));
        if (looksLikeCss(clean)) {
            locators.add(By.cssSelector(clean));
        }
        return locators;
    }

    private boolean looksLikeCss(String target) {
        return target.startsWith("#") || target.startsWith(".") || target.contains("[") || target.contains(">");
    }

    private String clean(String target) {
        if (target == null) return "";
        return target.trim().replaceAll("^['\"]|['\"]$", "");
    }

    private String xpathLiteral(String value) {
        if (!value.contains("'")) {
            return "'" + value + "'";
        }
        if (!value.contains("\"")) {
            return "\"" + value + "\"";
        }
        String[] parts = value.split("'");
        StringBuilder builder = new StringBuilder("concat(");
        for (int i = 0; i < parts.length; i++) {
            if (i > 0) builder.append(", \"'\", ");
            builder.append("'").append(parts[i]).append("'");
        }
        builder.append(")");
        return builder.toString();
    }
}
