package com.llmart.llm.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.llmart.llm.model.AgentAction;
import com.llmart.llm.model.RunConfig;
import com.llmart.llm.model.TestScenario;
import org.springframework.stereotype.Service;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

@Service
public class LlmClient {
    private final ObjectMapper objectMapper = new ObjectMapper();
    private final HttpClient httpClient = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(30))
            .build();

    public AgentAction planAction(RunConfig config,
                                  TestScenario scenario,
                                  String step,
                                  String currentUrl,
                                  String pageContext) throws Exception {
        String prompt = buildPlannerPrompt(scenario, step, currentUrl, pageContext);
        String response = callOpenAiCompatible(config, prompt);
        String json = extractJson(response);
        AgentAction action = objectMapper.readValue(json, AgentAction.class);
        if (action.getAction() != null) {
            action.setAction(action.getAction().trim().toUpperCase(Locale.ROOT));
        }
        return action;
    }

    private String callOpenAiCompatible(RunConfig config, String prompt) throws Exception {
        String endpoint = normalizeEndpoint(config.getLlmBaseUrl());

        Map<String, Object> system = new LinkedHashMap<>();
        system.put("role", "system");
        system.put("content", "You are a strict Selenium action planner. Return only valid JSON. No markdown.");

        Map<String, Object> user = new LinkedHashMap<>();
        user.put("role", "user");
        user.put("content", prompt);

        Map<String, Object> body = new LinkedHashMap<>();
        body.put("model", config.getLlmModel());
        body.put("messages", List.of(system, user));
        body.put("temperature", 0.0);
        body.put("max_tokens", 512);

        String requestJson = objectMapper.writeValueAsString(body);
        HttpRequest.Builder builder = HttpRequest.newBuilder()
                .uri(URI.create(endpoint))
                .timeout(Duration.ofSeconds(90))
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(requestJson));

        if (config.getLlmApiKey() != null && !config.getLlmApiKey().isBlank()) {
            String key = config.getLlmApiKey().trim();
            builder.header("Authorization", key.toLowerCase(Locale.ROOT).startsWith("bearer ") ? key : "Bearer " + key);
        }

        HttpResponse<String> response = httpClient.send(builder.build(), HttpResponse.BodyHandlers.ofString());
        if (response.statusCode() < 200 || response.statusCode() >= 300) {
            throw new IllegalStateException("LLM call failed. HTTP " + response.statusCode() + ": " + response.body());
        }

        JsonNode root = objectMapper.readTree(response.body());
        JsonNode choices = root.path("choices");
        if (choices.isArray() && choices.size() > 0) {
            JsonNode messageContent = choices.get(0).path("message").path("content");
            if (!messageContent.isMissingNode() && !messageContent.asText().isBlank()) {
                return messageContent.asText();
            }
            JsonNode text = choices.get(0).path("text");
            if (!text.isMissingNode()) {
                return text.asText();
            }
        }
        throw new IllegalStateException("Unable to read LLM response content: " + response.body());
    }

    private String normalizeEndpoint(String baseUrl) {
        if (baseUrl == null || baseUrl.isBlank()) {
            throw new IllegalArgumentException("LLM base URL is required");
        }
        String url = baseUrl.trim();
        if (url.endsWith("/chat/completions") || url.endsWith("/completions")) {
            return url;
        }
        while (url.endsWith("/")) {
            url = url.substring(0, url.length() - 1);
        }
        return url + "/chat/completions";
    }

    private String extractJson(String content) {
        String trimmed = content.trim();
        if (trimmed.startsWith("```")) {
            trimmed = trimmed.replace("```json", "").replace("```", "").trim();
        }
        int first = trimmed.indexOf('{');
        int last = trimmed.lastIndexOf('}');
        if (first >= 0 && last > first) {
            return trimmed.substring(first, last + 1);
        }
        throw new IllegalArgumentException("LLM did not return JSON: " + content);
    }

    private String buildPlannerPrompt(TestScenario scenario, String step, String currentUrl, String pageContext) throws Exception {
        String dataJson = objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(scenario.getData());
        String safePageContext = pageContext == null ? "" : pageContext;
        if (safePageContext.length() > 6000) {
            safePageContext = safePageContext.substring(0, 6000);
        }

        return """
                Convert the given test step into exactly one Selenium action JSON.

                Allowed JSON format:
                {"action":"NAVIGATE|CLICK|TYPE|ASSERT_TEXT|WAIT|SELECT|PRESS_ENTER|SCREENSHOT","target":"semantic target or locator","value":"value if needed","seconds":2}

                Rules:
                - Return only one JSON object.
                - For CLICK, target must be the visible button/link/control name.
                - For TYPE, target must be the input label/placeholder/name and value must come from test data when possible.
                - For ASSERT_TEXT, value must be the expected text to verify.
                - For NAVIGATE, value must be URL if mentioned. If no URL is mentioned, value can be empty.
                - Use test data placeholders like username, password, mobileNumber, orderId where relevant.
                - Never invent credentials. Use only provided test data.

                Scenario ID: %s
                Scenario Name: %s
                Scenario URL: %s
                Current URL: %s
                Test Data JSON:
                %s

                Current Page Context:
                %s

                Test Step:
                %s
                """.formatted(nullToBlank(scenario.getId()), nullToBlank(scenario.getName()),
                nullToBlank(scenario.getUrl()), nullToBlank(currentUrl), dataJson, safePageContext, step);
    }

    private String nullToBlank(String value) {
        return value == null ? "" : value;
    }
}
