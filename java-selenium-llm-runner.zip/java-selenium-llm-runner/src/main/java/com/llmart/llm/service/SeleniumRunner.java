package com.llmart.llm.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.llmart.llm.model.*;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeDriverService;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.Select;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Locale;

@Service
public class SeleniumRunner {
    private final ActionPlanner actionPlanner;
    private final LocatorResolver locatorResolver;
    private final ObjectMapper objectMapper = new ObjectMapper();

    @Value("${runner.output-dir:target/llm-test-runs}")
    private String outputDir;

    public SeleniumRunner(ActionPlanner actionPlanner, LocatorResolver locatorResolver) {
        this.actionPlanner = actionPlanner;
        this.locatorResolver = locatorResolver;
    }

    public void run(RunStatus status, RunConfig config, List<TestScenario> scenarios) {
        status.setStatus("RUNNING");
        status.setStartedAt(LocalDateTime.now());
        status.setTotal(scenarios.size());

        Path runDir = Path.of(outputDir, status.getRunId());
        Path screenshotDir = runDir.resolve("screenshots");
        try {
            Files.createDirectories(screenshotDir);
        } catch (Exception e) {
            status.setStatus("FAILED");
            status.setMessage("Unable to create output directory: " + e.getMessage());
            status.setFinishedAt(LocalDateTime.now());
            return;
        }

        WebDriver driver = null;
        try {
            driver = createDriver(config);
            driver.manage().window().maximize();

            int index = 0;
            for (TestScenario scenario : scenarios) {
                index++;
                status.setRunningIndex(index);
                ScenarioResult scenarioResult = runScenario(driver, config, scenario, screenshotDir);
                status.getResults().add(scenarioResult);
                if ("PASSED".equals(scenarioResult.getStatus())) {
                    status.setPassed(status.getPassed() + 1);
                } else {
                    status.setFailed(status.getFailed() + 1);
                }
                writeReport(status, runDir);
            }
            status.setStatus(status.getFailed() == 0 ? "PASSED" : "COMPLETED_WITH_FAILURES");
            status.setMessage("Run completed. Passed: " + status.getPassed() + ", Failed: " + status.getFailed());
        } catch (Exception e) {
            status.setStatus("FAILED");
            status.setMessage(e.getMessage());
        } finally {
            if (driver != null) {
                try { driver.quit(); } catch (Exception ignored) {}
            }
            status.setFinishedAt(LocalDateTime.now());
            writeReport(status, runDir);
        }
    }

    private ScenarioResult runScenario(WebDriver driver, RunConfig config, TestScenario scenario, Path screenshotDir) {
        ScenarioResult result = new ScenarioResult();
        result.setId(scenario.getId());
        result.setName(scenario.getName());
        long scenarioStart = System.currentTimeMillis();

        try {
            if (scenario.getUrl() != null && !scenario.getUrl().isBlank()) {
                driver.get(resolveUrl(config, scenario.getUrl()));
            }

            int stepNo = 0;
            for (String step : scenario.getSteps()) {
                stepNo++;
                StepResult stepResult = executeStep(driver, config, scenario, step, stepNo, screenshotDir);
                result.getSteps().add(stepResult);
                if (!"PASSED".equals(stepResult.getStatus())) {
                    result.setStatus("FAILED");
                    result.setMessage("Failed at step " + stepNo + ": " + stepResult.getMessage());
                    result.setDurationMs(System.currentTimeMillis() - scenarioStart);
                    return result;
                }
            }

            if (scenario.getExpected() != null && !scenario.getExpected().isBlank()) {
                StepResult assertResult = assertText(driver, scenario.getExpected(), scenario.getSteps().size() + 1, screenshotDir, scenario);
                result.getSteps().add(assertResult);
                if (!"PASSED".equals(assertResult.getStatus())) {
                    result.setStatus("FAILED");
                    result.setMessage(assertResult.getMessage());
                    result.setDurationMs(System.currentTimeMillis() - scenarioStart);
                    return result;
                }
            }

            result.setStatus("PASSED");
            result.setMessage("Scenario passed");
        } catch (Exception e) {
            result.setStatus("FAILED");
            result.setMessage(e.getMessage());
        }
        result.setDurationMs(System.currentTimeMillis() - scenarioStart);
        return result;
    }

    private StepResult executeStep(WebDriver driver,
                                   RunConfig config,
                                   TestScenario scenario,
                                   String step,
                                   int stepNo,
                                   Path screenshotDir) {
        StepResult result = new StepResult();
        result.setStepNumber(stepNo);
        result.setStep(step);
        long start = System.currentTimeMillis();
        try {
            String pageContext = pageContext(driver);
            String currentUrl = safeCurrentUrl(driver);
            AgentAction action = actionPlanner.plan(config, scenario, step, currentUrl, pageContext);
            result.setAction(objectMapper.writeValueAsString(action));
            executeAction(driver, config, scenario, action);
            result.setStatus("PASSED");
            result.setMessage("OK");
            result.setScreenshot(takeScreenshot(driver, screenshotDir, scenario, stepNo, "passed"));
        } catch (Exception e) {
            result.setStatus("FAILED");
            result.setMessage(e.getMessage());
            try { result.setScreenshot(takeScreenshot(driver, screenshotDir, scenario, stepNo, "failed")); } catch (Exception ignored) {}
        }
        result.setDurationMs(System.currentTimeMillis() - start);
        return result;
    }

    private void executeAction(WebDriver driver, RunConfig config, TestScenario scenario, AgentAction action) throws Exception {
        String type = action.getAction() == null ? "" : action.getAction().toUpperCase(Locale.ROOT);
        switch (type) {
            case "NAVIGATE" -> {
                String url = firstNonBlank(action.getValue(), scenario.getUrl(), config.getAppBaseUrl());
                driver.get(resolveUrl(config, url));
            }
            case "CLICK" -> locatorResolver.findClickable(driver, action.getTarget()).click();
            case "TYPE" -> {
                WebElement input = locatorResolver.findInput(driver, action.getTarget());
                input.clear();
                input.sendKeys(action.getValue() == null ? "" : action.getValue());
            }
            case "ASSERT_TEXT" -> {
                String expected = firstNonBlank(action.getValue(), action.getTarget());
                assertPageContains(driver, expected);
            }
            case "WAIT" -> Thread.sleep(Math.max(1, action.getSeconds() == null ? 2 : action.getSeconds()) * 1000L);
            case "SELECT" -> {
                WebElement selectElement = locatorResolver.findInput(driver, action.getTarget());
                new Select(selectElement).selectByVisibleText(action.getValue());
            }
            case "PRESS_ENTER" -> {
                if (action.getTarget() != null && !action.getTarget().isBlank()) {
                    locatorResolver.findAny(driver, action.getTarget()).sendKeys(Keys.ENTER);
                } else {
                    driver.switchTo().activeElement().sendKeys(Keys.ENTER);
                }
            }
            case "SCREENSHOT" -> {
                // Screenshot is taken after every step already.
            }
            default -> throw new IllegalArgumentException("Unsupported action from planner: " + type);
        }
    }

    private StepResult assertText(WebDriver driver, String expected, int stepNo, Path screenshotDir, TestScenario scenario) {
        StepResult result = new StepResult();
        result.setStepNumber(stepNo);
        result.setStep("Expected text validation: " + expected);
        long start = System.currentTimeMillis();
        try {
            assertPageContains(driver, expected);
            result.setStatus("PASSED");
            result.setMessage("Expected text found");
            result.setScreenshot(takeScreenshot(driver, screenshotDir, scenario, stepNo, "passed"));
        } catch (Exception e) {
            result.setStatus("FAILED");
            result.setMessage(e.getMessage());
            try { result.setScreenshot(takeScreenshot(driver, screenshotDir, scenario, stepNo, "failed")); } catch (Exception ignored) {}
        }
        result.setDurationMs(System.currentTimeMillis() - start);
        return result;
    }

    private void assertPageContains(WebDriver driver, String expected) {
        String expectedText = expected == null ? "" : expected.trim();
        if (expectedText.isBlank()) {
            throw new AssertionError("Expected text is blank");
        }
        String bodyText = driver.findElement(By.tagName("body")).getText();
        if (!bodyText.toLowerCase(Locale.ROOT).contains(expectedText.toLowerCase(Locale.ROOT))) {
            throw new AssertionError("Expected text not found on page: " + expectedText);
        }
    }

    private WebDriver createDriver(RunConfig config) {
        if (config.getChromeDriverPath() == null || config.getChromeDriverPath().isBlank()) {
            throw new IllegalArgumentException("ChromeDriver path is required. Download the driver that matches your Chromium version and select/paste the path.");
        }
        File driverFile = new File(config.getChromeDriverPath());
        if (!driverFile.exists()) {
            throw new IllegalArgumentException("ChromeDriver not found: " + config.getChromeDriverPath());
        }
        driverFile.setExecutable(true);

        ChromeOptions options = new ChromeOptions();
        if (config.getChromeBinaryPath() != null && !config.getChromeBinaryPath().isBlank()) {
            File binary = new File(config.getChromeBinaryPath());
            if (!binary.exists()) {
                throw new IllegalArgumentException("Chromium/Chrome binary not found: " + config.getChromeBinaryPath());
            }
            options.setBinary(binary);
        }
        options.addArguments("--remote-allow-origins=*");
        options.addArguments("--disable-notifications");
        options.addArguments("--start-maximized");
        if (config.isHeadless()) {
            options.addArguments("--headless=new");
            options.addArguments("--disable-gpu");
            options.addArguments("--window-size=1920,1080");
        }

        ChromeDriverService service = new ChromeDriverService.Builder()
                .usingDriverExecutable(driverFile)
                .build();
        return new ChromeDriver(service, options);
    }

    private String resolveUrl(RunConfig config, String url) {
        if (url == null || url.isBlank()) return config.getAppBaseUrl();
        String trimmed = url.trim();
        if (trimmed.startsWith("http://") || trimmed.startsWith("https://") || trimmed.startsWith("file://")) {
            return trimmed;
        }
        String base = config.getAppBaseUrl() == null ? "" : config.getAppBaseUrl().trim();
        if (base.endsWith("/") && trimmed.startsWith("/")) return base.substring(0, base.length() - 1) + trimmed;
        if (!base.endsWith("/") && !trimmed.startsWith("/")) return base + "/" + trimmed;
        return base + trimmed;
    }

    private String pageContext(WebDriver driver) {
        try {
            JavascriptExecutor js = (JavascriptExecutor) driver;
            Object result = js.executeScript("""
                    const elementText = (e) => {
                      const tag = (e.tagName || '').toLowerCase();
                      const text = (e.innerText || e.value || e.placeholder || e.getAttribute('aria-label') || '').trim().replace(/\s+/g, ' ');
                      const id = e.id ? '#'+e.id : '';
                      const name = e.name ? '[name='+e.name+']' : '';
                      const type = e.type ? '[type='+e.type+']' : '';
                      const ph = e.placeholder ? '[placeholder='+e.placeholder+']' : '';
                      return tag + id + name + type + ph + ' => ' + text;
                    };
                    const controls = Array.from(document.querySelectorAll('input,textarea,select,button,a,label,[role=button]'))
                      .slice(0, 120).map(elementText).join('\n');
                    const body = (document.body ? document.body.innerText : '').trim().replace(/\s+/g, ' ').slice(0, 3000);
                    return 'TITLE: ' + document.title + '\nCONTROLS:\n' + controls + '\nBODY:\n' + body;
                    """);
            return String.valueOf(result);
        } catch (Exception e) {
            return "";
        }
    }

    private String safeCurrentUrl(WebDriver driver) {
        try { return driver.getCurrentUrl(); } catch (Exception e) { return ""; }
    }

    private String takeScreenshot(WebDriver driver, Path screenshotDir, TestScenario scenario, int stepNo, String status) throws Exception {
        Files.createDirectories(screenshotDir);
        String fileName = sanitize(scenario.getId()) + "_step_" + stepNo + "_" + status + ".png";
        Path target = screenshotDir.resolve(fileName);
        File source = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
        Files.copy(source.toPath(), target, StandardCopyOption.REPLACE_EXISTING);
        return "screenshots/" + fileName;
    }

    private String sanitize(String input) {
        String text = input == null || input.isBlank() ? "scenario" : input;
        return text.replaceAll("[^a-zA-Z0-9._-]", "_");
    }

    private String firstNonBlank(String... values) {
        if (values == null) return "";
        for (String value : values) {
            if (value != null && !value.isBlank()) return value;
        }
        return "";
    }

    private void writeReport(RunStatus status, Path runDir) {
        try {
            Files.createDirectories(runDir);
            objectMapper.writerWithDefaultPrettyPrinter().writeValue(runDir.resolve("report.json").toFile(), status);
        } catch (Exception ignored) {
        }
    }
}
