package com.llmart.llm.service;

import com.llmart.llm.model.AgentAction;
import com.llmart.llm.model.RunConfig;
import com.llmart.llm.model.TestScenario;
import org.springframework.stereotype.Service;

import java.util.Locale;
import java.util.Map;

@Service
public class ActionPlanner {
    private final LlmClient llmClient;

    public ActionPlanner(LlmClient llmClient) {
        this.llmClient = llmClient;
    }

    public AgentAction plan(RunConfig config,
                            TestScenario scenario,
                            String step,
                            String currentUrl,
                            String pageContext) throws Exception {
        String expanded = replaceDataPlaceholders(step, scenario.getData());
        if (config.isUseLlm()) {
            try {
                AgentAction action = llmClient.planAction(config, scenario, expanded, currentUrl, pageContext);
                normalize(action);
                return action;
            } catch (Exception e) {
                // Fall back to deterministic action parsing so the run can continue for simple steps.
                return simplePlan(expanded, scenario);
            }
        }
        return simplePlan(expanded, scenario);
    }

    private AgentAction simplePlan(String step, TestScenario scenario) {
        String s = step == null ? "" : step.trim();
        String lower = s.toLowerCase(Locale.ROOT);

        if (lower.startsWith("open ") || lower.startsWith("launch ") || lower.startsWith("navigate")) {
            String value = scenario.getUrl();
            int httpIndex = lower.indexOf("http");
            if (httpIndex >= 0) value = s.substring(httpIndex).trim();
            return new AgentAction("NAVIGATE", "", value, null);
        }

        if (lower.startsWith("click ") || lower.contains(" click ") || lower.startsWith("tap ")) {
            String target = s.replaceFirst("(?i)^(click|tap)\\s+", "")
                    .replaceFirst("(?i)^on\\s+", "")
                    .replaceAll("(?i)button$", "")
                    .trim();
            return new AgentAction("CLICK", target, null, null);
        }

        if (lower.startsWith("type ") || lower.startsWith("enter ") || lower.contains(" enter ")) {
            return parseTypeAction(s, scenario);
        }

        if (lower.startsWith("verify ") || lower.startsWith("assert ") || lower.startsWith("validate ") || lower.contains(" should ")) {
            String value = s.replaceFirst("(?i)^(verify|assert|validate)\\s+", "").trim();
            return new AgentAction("ASSERT_TEXT", "", value, null);
        }

        if (lower.startsWith("wait")) {
            return new AgentAction("WAIT", "", null, 2);
        }

        if (lower.contains("press enter")) {
            return new AgentAction("PRESS_ENTER", "", null, null);
        }

        return new AgentAction("CLICK", s, null, null);
    }

    private AgentAction parseTypeAction(String step, TestScenario scenario) {
        String raw = step.replaceFirst("(?i)^(type|enter)\\s+", "").trim();
        String lower = raw.toLowerCase(Locale.ROOT);

        // Common patterns: "username in username field", "username into Username", "siva@example.com in Email"
        String[] separators = {" into ", " in ", " to "};
        for (String separator : separators) {
            int index = lower.indexOf(separator);
            if (index > 0) {
                String valuePart = raw.substring(0, index).trim();
                String targetPart = raw.substring(index + separator.length()).trim();
                String resolvedValue = resolveDataValue(valuePart, scenario);
                return new AgentAction("TYPE", targetPart, resolvedValue, null);
            }
        }

        // If step mentions a data key, type that value into the key-matching field.
        for (String key : scenario.getData().keySet()) {
            if (lower.contains(key.toLowerCase(Locale.ROOT))) {
                return new AgentAction("TYPE", key, String.valueOf(scenario.getData().get(key)), null);
            }
        }
        return new AgentAction("TYPE", raw, raw, null);
    }

    private String resolveDataValue(String valuePart, TestScenario scenario) {
        String normalized = valuePart.replace("{{", "").replace("}}", "").trim();
        for (Map.Entry<String, Object> entry : scenario.getData().entrySet()) {
            if (entry.getKey().equalsIgnoreCase(normalized) || normalized.toLowerCase(Locale.ROOT).contains(entry.getKey().toLowerCase(Locale.ROOT))) {
                return String.valueOf(entry.getValue());
            }
        }
        return valuePart;
    }

    private String replaceDataPlaceholders(String step, Map<String, Object> data) {
        String result = step == null ? "" : step;
        for (Map.Entry<String, Object> entry : data.entrySet()) {
            result = result.replace("{{" + entry.getKey() + "}}", String.valueOf(entry.getValue()));
        }
        return result;
    }

    private void normalize(AgentAction action) {
        if (action.getAction() != null) {
            action.setAction(action.getAction().trim().toUpperCase(Locale.ROOT));
        }
    }
}
