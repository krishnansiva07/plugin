package com.llmart.llm.model;

public class RunConfig {
    private String llmBaseUrl;
    private String llmApiKey;
    private String llmModel;
    private String appBaseUrl;
    private String chromeBinaryPath;
    private String chromeDriverPath;
    private boolean headless;
    private boolean useLlm = true;

    public String getLlmBaseUrl() { return llmBaseUrl; }
    public void setLlmBaseUrl(String llmBaseUrl) { this.llmBaseUrl = llmBaseUrl; }

    public String getLlmApiKey() { return llmApiKey; }
    public void setLlmApiKey(String llmApiKey) { this.llmApiKey = llmApiKey; }

    public String getLlmModel() { return llmModel; }
    public void setLlmModel(String llmModel) { this.llmModel = llmModel; }

    public String getAppBaseUrl() { return appBaseUrl; }
    public void setAppBaseUrl(String appBaseUrl) { this.appBaseUrl = appBaseUrl; }

    public String getChromeBinaryPath() { return chromeBinaryPath; }
    public void setChromeBinaryPath(String chromeBinaryPath) { this.chromeBinaryPath = chromeBinaryPath; }

    public String getChromeDriverPath() { return chromeDriverPath; }
    public void setChromeDriverPath(String chromeDriverPath) { this.chromeDriverPath = chromeDriverPath; }

    public boolean isHeadless() { return headless; }
    public void setHeadless(boolean headless) { this.headless = headless; }

    public boolean isUseLlm() { return useLlm; }
    public void setUseLlm(boolean useLlm) { this.useLlm = useLlm; }
}
