package com.llmart.llm.controller;

import com.llmart.llm.model.RunConfig;
import com.llmart.llm.model.RunStatus;
import com.llmart.llm.model.TestScenario;
import com.llmart.llm.service.RunStore;
import com.llmart.llm.service.ScenarioFileParser;
import com.llmart.llm.service.TestRunService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.FileSystemResource;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/runs")
public class RunController {
    private final ScenarioFileParser parser;
    private final TestRunService testRunService;
    private final RunStore runStore;

    @Value("${runner.output-dir:target/llm-test-runs}")
    private String outputDir;

    public RunController(ScenarioFileParser parser, TestRunService testRunService, RunStore runStore) {
        this.parser = parser;
        this.testRunService = testRunService;
        this.runStore = runStore;
    }

    @PostMapping(consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<?> startRun(@RequestParam("scenarioFile") MultipartFile scenarioFile,
                                      @RequestParam(value = "driverFile", required = false) MultipartFile driverFile,
                                      @RequestParam(value = "llmBaseUrl", required = false) String llmBaseUrl,
                                      @RequestParam(value = "llmApiKey", required = false) String llmApiKey,
                                      @RequestParam(value = "llmModel", required = false) String llmModel,
                                      @RequestParam(value = "appBaseUrl", required = false) String appBaseUrl,
                                      @RequestParam(value = "chromeBinaryPath", required = false) String chromeBinaryPath,
                                      @RequestParam(value = "chromeDriverPath", required = false) String chromeDriverPath,
                                      @RequestParam(value = "headless", defaultValue = "false") boolean headless,
                                      @RequestParam(value = "useLlm", defaultValue = "true") boolean useLlm) {
        try {
            List<TestScenario> scenarios = parser.parse(scenarioFile);
            if (scenarios.isEmpty()) {
                return ResponseEntity.badRequest().body(Map.of("message", "No scenarios found in uploaded file"));
            }

            RunConfig config = new RunConfig();
            config.setLlmBaseUrl(llmBaseUrl);
            config.setLlmApiKey(llmApiKey);
            config.setLlmModel(llmModel);
            config.setAppBaseUrl(appBaseUrl);
            config.setChromeBinaryPath(chromeBinaryPath);
            config.setChromeDriverPath(chromeDriverPath);
            config.setHeadless(headless);
            config.setUseLlm(useLlm);

            if (driverFile != null && !driverFile.isEmpty()) {
                Path uploadedDriver = saveUploadedDriver(driverFile);
                config.setChromeDriverPath(uploadedDriver.toAbsolutePath().toString());
            }

            RunStatus status = testRunService.start(config, scenarios);
            return ResponseEntity.ok(status);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of("message", e.getMessage()));
        }
    }

    @GetMapping("/{runId}")
    public ResponseEntity<?> getRun(@PathVariable String runId) {
        return runStore.get(runId)
                .<ResponseEntity<?>>map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @GetMapping(value = "/{runId}/screenshots/{fileName:.+}", produces = MediaType.IMAGE_PNG_VALUE)
    public ResponseEntity<?> getScreenshot(@PathVariable String runId, @PathVariable String fileName) {
        try {
            Path file = Path.of(outputDir, runId, "screenshots", fileName).normalize();
            Path allowedRoot = Path.of(outputDir, runId, "screenshots").normalize().toAbsolutePath();
            Path absoluteFile = file.toAbsolutePath();
            if (!absoluteFile.startsWith(allowedRoot) || !Files.exists(absoluteFile)) {
                return ResponseEntity.notFound().build();
            }
            return ResponseEntity.ok(new FileSystemResource(absoluteFile));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of("message", e.getMessage()));
        }
    }

    private Path saveUploadedDriver(MultipartFile driverFile) throws Exception {
        String original = driverFile.getOriginalFilename() == null ? "chromedriver.exe" : driverFile.getOriginalFilename();
        String safeName = original.replaceAll("[^a-zA-Z0-9._-]", "_");
        Path driverDir = Path.of(outputDir, "uploaded-drivers");
        Files.createDirectories(driverDir);
        Path target = driverDir.resolve(System.currentTimeMillis() + "_" + safeName);
        Files.copy(driverFile.getInputStream(), target, StandardCopyOption.REPLACE_EXISTING);
        target.toFile().setExecutable(true);
        return target;
    }
}
