package com.llmart.llm.service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.llmart.llm.model.TestScenario;
import org.apache.poi.ss.usermodel.*;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.InputStream;
import java.util.*;

@Service
public class ScenarioFileParser {
    private final ObjectMapper objectMapper = new ObjectMapper();

    public List<TestScenario> parse(MultipartFile file) throws Exception {
        String name = Optional.ofNullable(file.getOriginalFilename()).orElse("").toLowerCase(Locale.ROOT);
        if (name.endsWith(".json")) {
            return parseJson(file.getInputStream());
        }
        if (name.endsWith(".xlsx") || name.endsWith(".xls")) {
            return parseExcel(file.getInputStream());
        }
        throw new IllegalArgumentException("Unsupported file type. Please upload .json, .xlsx, or .xls");
    }

    private List<TestScenario> parseJson(InputStream inputStream) throws Exception {
        JsonNode root = objectMapper.readTree(inputStream);
        if (root.isArray()) {
            return objectMapper.convertValue(root, new TypeReference<List<TestScenario>>() {});
        }
        if (root.has("scenarios") && root.get("scenarios").isArray()) {
            return objectMapper.convertValue(root.get("scenarios"), new TypeReference<List<TestScenario>>() {});
        }
        throw new IllegalArgumentException("JSON must be an array or an object with a scenarios array");
    }

    private List<TestScenario> parseExcel(InputStream inputStream) throws Exception {
        List<TestScenario> scenarios = new ArrayList<>();
        try (Workbook workbook = WorkbookFactory.create(inputStream)) {
            Sheet sheet = workbook.getSheetAt(0);
            if (sheet.getPhysicalNumberOfRows() < 2) {
                return scenarios;
            }

            Row header = sheet.getRow(0);
            Map<String, Integer> columns = new LinkedHashMap<>();
            for (Cell cell : header) {
                columns.put(cellText(cell).trim().toLowerCase(Locale.ROOT), cell.getColumnIndex());
            }

            for (int r = 1; r <= sheet.getLastRowNum(); r++) {
                Row row = sheet.getRow(r);
                if (row == null) continue;

                TestScenario scenario = new TestScenario();
                scenario.setId(get(row, columns, "id"));
                scenario.setName(get(row, columns, "name"));
                scenario.setUrl(get(row, columns, "url"));
                scenario.setExpected(get(row, columns, "expected"));

                String stepsText = get(row, columns, "steps");
                scenario.setSteps(splitSteps(stepsText));

                Map<String, Object> data = new LinkedHashMap<>();
                String testDataJson = get(row, columns, "testdatajson");
                if (testDataJson == null || testDataJson.isBlank()) {
                    testDataJson = get(row, columns, "data");
                }
                if (testDataJson != null && !testDataJson.isBlank() && testDataJson.trim().startsWith("{")) {
                    data.putAll(objectMapper.readValue(testDataJson, new TypeReference<Map<String, Object>>() {}));
                }

                for (Map.Entry<String, Integer> entry : columns.entrySet()) {
                    if (entry.getKey().startsWith("data.")) {
                        String dataKey = entry.getKey().substring("data.".length());
                        String value = cellText(row.getCell(entry.getValue()));
                        if (value != null && !value.isBlank()) {
                            data.put(dataKey, value);
                        }
                    }
                }
                scenario.setData(data);

                if ((scenario.getId() == null || scenario.getId().isBlank()) &&
                        (scenario.getName() == null || scenario.getName().isBlank()) &&
                        scenario.getSteps().isEmpty()) {
                    continue;
                }
                if (scenario.getId() == null || scenario.getId().isBlank()) {
                    scenario.setId("ROW-" + (r + 1));
                }
                if (scenario.getName() == null || scenario.getName().isBlank()) {
                    scenario.setName(scenario.getId());
                }
                scenarios.add(scenario);
            }
        }
        return scenarios;
    }

    private String get(Row row, Map<String, Integer> columns, String columnName) {
        Integer index = columns.get(columnName.toLowerCase(Locale.ROOT));
        if (index == null) return null;
        return cellText(row.getCell(index));
    }

    private String cellText(Cell cell) {
        if (cell == null) return "";
        DataFormatter formatter = new DataFormatter();
        return formatter.formatCellValue(cell);
    }

    private List<String> splitSteps(String stepsText) {
        if (stepsText == null || stepsText.isBlank()) return new ArrayList<>();
        String normalized = stepsText.replace("\r\n", "\n").replace("|", "\n");
        List<String> steps = new ArrayList<>();
        for (String step : normalized.split("\n")) {
            String trimmed = step.trim();
            if (!trimmed.isBlank()) {
                steps.add(trimmed);
            }
        }
        return steps;
    }
}
