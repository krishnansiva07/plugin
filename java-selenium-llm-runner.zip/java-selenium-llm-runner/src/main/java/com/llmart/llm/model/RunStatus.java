package com.llmart.llm.model;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class RunStatus {
    private String runId;
    private String status = "QUEUED";
    private String message;
    private LocalDateTime startedAt;
    private LocalDateTime finishedAt;
    private int total;
    private int passed;
    private int failed;
    private int runningIndex;
    private List<ScenarioResult> results = new ArrayList<>();

    public String getRunId() { return runId; }
    public void setRunId(String runId) { this.runId = runId; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }

    public LocalDateTime getStartedAt() { return startedAt; }
    public void setStartedAt(LocalDateTime startedAt) { this.startedAt = startedAt; }

    public LocalDateTime getFinishedAt() { return finishedAt; }
    public void setFinishedAt(LocalDateTime finishedAt) { this.finishedAt = finishedAt; }

    public int getTotal() { return total; }
    public void setTotal(int total) { this.total = total; }

    public int getPassed() { return passed; }
    public void setPassed(int passed) { this.passed = passed; }

    public int getFailed() { return failed; }
    public void setFailed(int failed) { this.failed = failed; }

    public int getRunningIndex() { return runningIndex; }
    public void setRunningIndex(int runningIndex) { this.runningIndex = runningIndex; }

    public List<ScenarioResult> getResults() { return results; }
    public void setResults(List<ScenarioResult> results) { this.results = results; }
}
