package com.llmart.llm.service;

import com.llmart.llm.model.RunConfig;
import com.llmart.llm.model.RunStatus;
import com.llmart.llm.model.TestScenario;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;

@Service
public class TestRunService {
    private final RunStore runStore;
    private final SeleniumRunner seleniumRunner;

    public TestRunService(RunStore runStore, SeleniumRunner seleniumRunner) {
        this.runStore = runStore;
        this.seleniumRunner = seleniumRunner;
    }

    public RunStatus start(RunConfig config, List<TestScenario> scenarios) {
        RunStatus status = new RunStatus();
        status.setRunId(UUID.randomUUID().toString());
        status.setStatus("QUEUED");
        status.setTotal(scenarios.size());
        status.setMessage("Run queued with " + scenarios.size() + " scenario(s)");
        runStore.put(status);

        CompletableFuture.runAsync(() -> seleniumRunner.run(status, config, scenarios));
        return status;
    }
}
