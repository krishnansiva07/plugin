package com.llmart.llm.model;

public class AgentAction {
    private String action;
    private String target;
    private String value;
    private Integer seconds;

    public AgentAction() {}

    public AgentAction(String action, String target, String value, Integer seconds) {
        this.action = action;
        this.target = target;
        this.value = value;
        this.seconds = seconds;
    }

    public String getAction() { return action; }
    public void setAction(String action) { this.action = action; }

    public String getTarget() { return target; }
    public void setTarget(String target) { this.target = target; }

    public String getValue() { return value; }
    public void setValue(String value) { this.value = value; }

    public Integer getSeconds() { return seconds; }
    public void setSeconds(Integer seconds) { this.seconds = seconds; }
}
