let currentRunId = null;
let pollTimer = null;

const form = document.getElementById('runForm');
const runBtn = document.getElementById('runBtn');
const formMessage = document.getElementById('formMessage');
const runSummary = document.getElementById('runSummary');
const results = document.getElementById('results');

form.addEventListener('submit', async (e) => {
    e.preventDefault();
    runBtn.disabled = true;
    formMessage.textContent = 'Uploading and starting run...';
    results.innerHTML = '';

    const data = new FormData(form);
    data.set('headless', form.headless.checked ? 'true' : 'false');
    data.set('useLlm', form.useLlm.checked ? 'true' : 'false');

    try {
        const response = await fetch('/api/runs', { method: 'POST', body: data });
        const body = await response.json();
        if (!response.ok) throw new Error(body.message || 'Unable to start run');
        currentRunId = body.runId;
        formMessage.textContent = `Run started: ${currentRunId}`;
        pollRun();
        if (pollTimer) clearInterval(pollTimer);
        pollTimer = setInterval(pollRun, 2500);
    } catch (err) {
        formMessage.textContent = err.message;
        runBtn.disabled = false;
    }
});

async function pollRun() {
    if (!currentRunId) return;
    const response = await fetch(`/api/runs/${currentRunId}`);
    if (!response.ok) return;
    const run = await response.json();
    renderRun(run);
    if (['PASSED', 'FAILED', 'COMPLETED_WITH_FAILURES'].includes(run.status)) {
        clearInterval(pollTimer);
        runBtn.disabled = false;
    }
}

function renderRun(run) {
    runSummary.innerHTML = `
        <strong>Status:</strong> <span class="badge ${run.status}">${run.status}</span>
        &nbsp; <strong>Total:</strong> ${run.total}
        &nbsp; <strong>Passed:</strong> ${run.passed}
        &nbsp; <strong>Failed:</strong> ${run.failed}
        &nbsp; <strong>Message:</strong> ${escapeHtml(run.message || '')}
    `;

    results.innerHTML = (run.results || []).map(s => `
        <div class="scenario">
            <div class="scenario-header">
                <span>${escapeHtml(s.id || '')} - ${escapeHtml(s.name || '')}</span>
                <span class="badge ${s.status}">${s.status}</span>
            </div>
            <div class="steps">
                ${(s.steps || []).map(st => renderStep(run.runId, st)).join('')}
            </div>
        </div>
    `).join('');
}

function renderStep(runId, st) {
    let screenshot = '';
    if (st.screenshot) {
        const fileName = st.screenshot.split('/').pop();
        screenshot = `<a href="/api/runs/${runId}/screenshots/${encodeURIComponent(fileName)}" target="_blank">Open screenshot</a>`;
    }
    return `
        <div class="step">
            <div><strong>Step ${st.stepNumber}:</strong> ${escapeHtml(st.step || '')}</div>
            <div><strong>Status:</strong> <span class="badge ${st.status}">${st.status}</span> <strong>Duration:</strong> ${st.durationMs} ms</div>
            <div><strong>Action:</strong> <code>${escapeHtml(st.action || '')}</code></div>
            <div><strong>Message:</strong> ${escapeHtml(st.message || '')} ${screenshot}</div>
        </div>
    `;
}

function escapeHtml(value) {
    return String(value)
        .replaceAll('&', '&amp;')
        .replaceAll('<', '&lt;')
        .replaceAll('>', '&gt;')
        .replaceAll('"', '&quot;')
        .replaceAll("'", '&#039;');
}
