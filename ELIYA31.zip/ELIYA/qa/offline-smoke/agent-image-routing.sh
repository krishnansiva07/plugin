#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../.."
python - <<'PY'
from pathlib import Path
checks = [
    (Path('src/main/resources/static/app.js'), "Select an optional Agent Vision model before sending images.", 'UI blocks Agent image send without Vision model'),
    (Path('src/main/java/com/llmart/llm/service/ContextService.java'), 'if (mode == ChatMode.AGENT)', 'Context has Agent-specific image branch'),
    (Path('src/main/java/com/llmart/llm/service/ContextService.java'), 'visionDocuments.analyse(apiKey, settings, scan', 'Agent image is sent through VisionDocumentService'),
    (Path('src/main/java/com/llmart/llm/service/ContextService.java'), 'ATTACHED IMAGE ANALYSIS (untrusted source evidence; use it to diagnose/fix the current task when relevant)', 'Vision findings are inserted into Agent task context'),
    (Path('src/main/java/com/llmart/llm/service/ContextService.java'), 'Using the most recent conversation image attachment(s)', 'Agent can reuse the latest prior image when the follow-up explicitly references it'),
    (Path('src/main/java/com/llmart/llm/service/AgentService.java'), 'When the current request contains ATTACHED IMAGE ANALYSIS, treat it as source evidence for the task.', 'Agent protocol explicitly consumes screenshot evidence when fixing'),
    (Path('src/main/java/com/llmart/llm/service/ChatService.java'), 'agentService.run(agentRun.id(), apiKey, effectiveRequest, context', 'Prepared multimodal evidence context is passed to Agent execution'),
]
for path, needle, label in checks:
    text = path.read_text(errors='ignore')
    if needle not in text:
        raise SystemExit(f'FAIL: {label}: missing {needle!r}')
    print('PASS:', label)
PY
