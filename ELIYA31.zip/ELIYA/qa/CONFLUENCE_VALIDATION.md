# ELIYA28 Confluence Composer validation

## Verified locally (offline)
- Java 17 syntax parser: 81 main Java sources, 0 parser errors.
- Standalone Java 17 compiler + focused Confluence Composer harness: 12 assertions passed (Markdown and plain-text formatting, exact source preservation, headings/tables/code, HTTP(S) links, script escaping, malformed table values, input limits and themes).
- Node JavaScript UI tests: 15 passed, 0 failed (existing tests plus three Confluence UI/integration contracts).
- `node --check`: app.js, prompt-catalog.js, confluence-composer.js passed.
- Existing offline suites: deletion/rollback, vision, Jira JQL, MCP routing, UI/API source contracts (11 checks), and Spring constructor-contract check all passed.
- ZIP validation: run `unzip -t` on the delivered ZIP (separately reported at package time).

## Not verified in this environment
- Full Maven compile/test and executable Spring Boot JAR (no Maven/dependency resolution in the current runtime).
- Real connected provider + Agent execution over a large workspace (requires the user's model, workspace and runtime configuration).
- Actual rich clipboard paste into a live Confluence Cloud/Data Center editor (requires a browser with clipboard permissions and a Confluence editor). Markdown generated from extracted document images still requires configured vision model and evidence review.

## Production gate
On your Windows/macOS/Linux Java 17+ host: `mvn -Pfull-tests clean test`, `mvn -DskipTests package`, launch `eliya.jar`, exercise the direct Compose endpoint and a representative workspace Agent plan, then paste a rich-copy table and code block into your organization's Confluence editor. Review its resulting CSS/line wrapping. Do not treat offline tests as proof of full runtime compatibility.
