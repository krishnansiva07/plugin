#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../.."
node --check src/main/resources/static/app.js
python3 qa/offline-smoke/ui-contract.py
DIR=$(mktemp -d); trap 'rm -rf "$DIR"' EXIT
PKG="$DIR/src/com/llmart/llm/service"; mkdir -p "$PKG" "$DIR/src/org/springframework/stereotype" "$DIR/classes"
cat > "$DIR/src/org/springframework/stereotype/Service.java" <<'JAVA'
package org.springframework.stereotype; public @interface Service {}
JAVA
cat > "$PKG/AgentWorkspaceService.java" <<'JAVA'
package com.llmart.llm.service;
import java.nio.file.Path; import java.util.Map;
class AgentWorkspaceService {
    record Workspace(Path root, Map<String,PromptResourceResolver.ResolvedResource> resources) {
        static Workspace forIndex(String id, Path root) {return new Workspace(root, Map.of());}
    }
}
JAVA
cat > "$PKG/PromptResourceResolver.java" <<'JAVA'
package com.llmart.llm.service;
import java.nio.file.Path;
class PromptResourceResolver {record ResolvedResource(Path root, boolean writable) {}}
JAVA
cat > "$PKG/OpenAiCompatibleClient.java" <<'JAVA'
package com.llmart.llm.service;
class OpenAiCompatibleClient {
    record Usage(long inputTokens, long outputTokens, long totalTokens, long cachedInputTokens, long cacheWriteTokens) {}
}
JAVA
cat > "$PKG/WorkspaceRetrievalIndexService.java" <<'JAVA'
package com.llmart.llm.service;
import java.util.Collection;
class WorkspaceRetrievalIndexService {void refreshPaths(AgentWorkspaceService.Workspace workspace, Collection<String> paths) {}}
JAVA
cat > "$PKG/CompletionSmoke.java" <<'JAVA'
package com.llmart.llm.service;
import java.io.*; import java.nio.file.*; import java.util.*;
public class CompletionSmoke {
    static void require(boolean yes, String why) {if (!yes) throw new AssertionError(why);}
    static Map<String,Object> matching(List<Map<String,Object>> files, String name) {
        return files.stream().filter(file -> name.equals(file.get("name"))).findFirst().orElseThrow();
    }
    @SuppressWarnings("unchecked")
    public static void main(String[] args) throws Exception {
        Path home = Files.createTempDirectory("eliya-report-smoke");
        try {
            Path root = Files.createDirectories(home.resolve("workspace"));
            Path existing = root.resolve("src/Service.java"); Files.createDirectories(existing.getParent());
            Files.writeString(existing, "first\\nold\\n".replace("\\n", "\n"));
            Files.writeString(root.resolve("remove.txt"), "removed\n");
            Files.write(root.resolve("payload.bin"), new byte[]{0, 1, 2});
            Path build = root.resolve("target/generated.txt"); Files.createDirectories(build.getParent()); Files.writeString(build, "build artifact");
            var history = new AgentRunService(home.resolve("runs"));
            var baseline = new ProtectedRunSnapshotService(home.resolve("snapshots"));
            var rollback = new AgentTaskRollbackService(baseline, new WorkspaceRetrievalIndexService(), history);
            var workspace = new AgentWorkspaceService.Workspace(root, Map.of());
            var run = history.start("conversation", "project");
            baseline.begin(run.id(), workspace);
            Files.writeString(existing, "first\nnew\n");
            Files.delete(root.resolve("remove.txt"));
            Files.write(root.resolve("payload.bin"), new byte[]{0, 2, 3});
            Path created = root.resolve("docs/guide.md"); Files.createDirectories(created.getParent()); Files.writeString(created, "new file\n");
            Files.writeString(build, "changed build artifact");
            require(rollback.seal(run.id()) == 4, "Only 4 tracked files must be reported; build excluded");
            run.finish("completed");
            var report = rollback.completionReport(run.id());
            require(Boolean.TRUE.equals(report.get("filesVerified")), "Sealed report not verified");
            require(Integer.valueOf(1).equals(report.get("created")), "Created count");
            require(Integer.valueOf(2).equals(report.get("modified")), "Modified count");
            require(Integer.valueOf(1).equals(report.get("deleted")), "Deleted count");
            var files = (List<Map<String,Object>>) report.get("files");
            require(files.size() == 4, "Missing reported filenames");
            var service = matching(files, "Service.java");
            require("modified".equals(service.get("action")), "Incorrect file action");
            require(String.valueOf(service.get("excerpt")).contains("- old"), "Missing removed preview");
            require(String.valueOf(service.get("excerpt")).contains("+ new"), "Missing added preview");
            require(String.valueOf(matching(files, "payload.bin").get("detail")).contains("binary"), "Missing binary note");
            require("created".equals(matching(files, "guide.md").get("action")), "Missing created file");
            require("deleted".equals(matching(files, "remove.txt").get("action")), "Missing deleted file");
            require(files.stream().noneMatch(file -> String.valueOf(file.get("path")).contains("target")), "Build artifact reported");
            Files.writeString(existing, "manual edit\n");
            require(String.valueOf(matching((List<Map<String,Object>>) rollback.completionReport(run.id()).get("files"), "Service.java").get("excerpt")).contains("+ new"), "Historical report was modified by later editing");
            try {rollback.rollback(run.id(), "conversation", "project");throw new AssertionError("Rollback overwrote newer manual edit");}
            catch (IOException expected) {require(Files.readString(existing).contains("manual"), "Manual edit lost");}
            var run2 = history.start("conversation", "project");
            baseline.begin(run2.id(), workspace);
            Files.writeString(existing, "second task\n");
            require(rollback.seal(run2.id()) == 1, "Second run count");
            run2.finish("completed");
            rollback.rollback(run2.id(), "conversation", "project");
            require(Boolean.TRUE.equals(rollback.completionReport(run2.id()).get("rolledBack")), "Report must indicate undo");
            System.out.println("PASS: 4 action/file counts, historical previews, binary handling, excluded files, later edits, rollback conflict, rollback state");
        } finally {
            try (var paths = Files.walk(home)) {for (var path : paths.sorted(Comparator.reverseOrder()).toList()) Files.deleteIfExists(path);}
        }
    }
}
JAVA
javac --release 17 -d "$DIR/classes" $(find "$DIR/src" -name '*.java') \
    src/main/java/com/llmart/llm/service/AgentCancelledException.java \
    src/main/java/com/llmart/llm/service/AgentRunService.java \
    src/main/java/com/llmart/llm/service/ProtectedRunSnapshotService.java \
    src/main/java/com/llmart/llm/service/AgentTaskRollbackService.java
java -cp "$DIR/classes" com.llmart.llm.service.CompletionSmoke
node qa/completion-report-smoke/ui.cjs
