package com.llmart.llm.service;
import com.llmart.llm.dto.ChatSettings;
import java.util.*;
public final class IntegrationContracts {
 public static void main(String[] args) {
  ChatSettings settings = new ChatSettings(
       "http://localhost/v1", "qwen3.8-27b", null, "mistral-small-4-ITG", "", "", "", "", "qwen3-embedding-8b", false, true,
       0.1, 0, 0, 0, null, "qwen3-embedding-8b=embedding", true, 8000, 20000, 1200, null, true, 0, true,
       "allow", "allow", "allow", true, "", "allow", "allow", "allow", true, true,
       "", 3, true, null, null);
  if (!settings.semanticRetrievalEnabled() || !settings.embeddingModelName().equals("qwen3-embedding-8b"))
   throw new AssertionError("Semantic settings opt-in failed");
  AgentToolRegistry registry = new AgentToolRegistry();
  boolean impact = registry.builtInDefinitions().stream().anyMatch(tool -> {
     Object function = tool.get("function");
     return function instanceof Map<?,?> m && "code_impact".equals(m.get("name"));
  });
  if (!impact || !registry.isParallelReadOnly("code_impact"))
   throw new AssertionError("code_impact tool registration or read-only classification failed");
  System.out.println("PASS: actual ChatSettings semantic opt-in and actual AgentToolRegistry code_impact contract");
 }
}
