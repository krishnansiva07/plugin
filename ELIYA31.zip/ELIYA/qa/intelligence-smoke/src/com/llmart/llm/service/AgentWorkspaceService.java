package com.llmart.llm.service;
import java.nio.file.Path;
public class AgentWorkspaceService { public record Workspace(String projectId, Path root) {
    public static Workspace forIndex(String id, Path root) { return new Workspace(id, root.toAbsolutePath().normalize()); }
} }
