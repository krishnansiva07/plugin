package com.llmart.llm.dto;
public record ChatSettings(String baseUrl, String embeddingModel, boolean semanticRetrievalEnabled) {
 public String embeddingModelName() { return embeddingModel; }
}
