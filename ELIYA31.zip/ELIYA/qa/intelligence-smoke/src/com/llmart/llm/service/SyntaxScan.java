package com.llmart.llm.service;

import com.sun.source.util.JavacTask;
import javax.tools.*;
import java.nio.file.*;
import java.util.*;

/** Parse all production sources without resolving unavailable Maven dependencies. */
public final class SyntaxScan {
  public static void main(String[] args) throws Exception {
    JavaCompiler compiler = ToolProvider.getSystemJavaCompiler();
    DiagnosticCollector<JavaFileObject> diagnostics = new DiagnosticCollector<>();
    try (StandardJavaFileManager manager = compiler.getStandardFileManager(diagnostics, Locale.ROOT, null);
         var sourcePaths = Files.walk(Path.of(args[0]))) {
      List<Path> paths = sourcePaths.filter(p -> p.toString().endsWith(".java")).toList();
      var units = manager.getJavaFileObjectsFromPaths(paths);
      var task = (JavacTask) compiler.getTask(null, manager, diagnostics, List.of("-proc:none"), null, units);
      int count = 0;
      for (var unit : task.parse()) count++;
      var errors = diagnostics.getDiagnostics().stream().filter(d -> d.getKind() == Diagnostic.Kind.ERROR).toList();
      for (var error : errors) System.err.println(error);
      if (!errors.isEmpty()) throw new AssertionError("Java parse errors: " + errors.size());
      System.out.println("PASS: parsed " + count + " Java production sources (syntax only; Maven dependencies not resolved)");
    }
  }
}
