package org.apache.tika;
import java.io.*;
import java.nio.charset.StandardCharsets;
public final class Tika { public void setMaxStringLength(int limit) {} public String parseToString(InputStream in) throws IOException { return new String(in.readAllBytes(), StandardCharsets.UTF_8); } }
