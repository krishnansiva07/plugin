#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../.."
DIR=$(mktemp -d); trap 'rm -rf "$DIR"' EXIT
javac --release 17 -d "$DIR" \
 qa/confluence-smoke/src/org/springframework/stereotype/Service.java \
 src/main/java/com/llmart/llm/service/ConfluenceComposerService.java \
 qa/confluence-smoke/src/com/llmart/llm/service/ComposerSmoke.java
java -cp "$DIR" com.llmart.llm.service.ComposerSmoke
