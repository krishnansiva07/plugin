package com.llmart.llm.service;
public class ComposerSmoke {
    static int assertions;
    static void check(boolean actual,String label) { assertions++; if (!actual) throw new AssertionError(label); }
    public static void main(String[] args) {
        var composer = new ConfluenceComposerService();
        String markdown = "# Design\nThis is **verified**.\n- Java 17\n- Selenium\n| Key | Value |\n| --- | --- |\n| Total | 150 |\n```java\nif (a < b) return;\n```\n[Ref](https://example.com?a=1&b=2)";
        var r=composer.format(markdown,"bnp-green");
        check(markdown.equals(r.plainText()),"wording changed");
        check(r.sections()==1 && r.tables()==1 && r.codeBlocks()==1,"lost structure");
        check(r.html().contains("<table>") && r.html().contains("<strong>verified</strong>"),"formatting absent");
        check(r.html().contains("&lt; b"),"code HTML not escaped");
        check(r.html().contains("href=\"https://example.com?a=1&amp;b=2\""),"link not encoded");
        var plain = composer.format("API test execution summary\nTotal cases: 150\nPassed: 145\nFailed: 5", "corporate-blue");
        check(plain.sections()==1 && plain.tables()==1,"plain-text auto structure");
        check(plain.html().contains("Passed:") && plain.html().contains("145"),"plain-text metric changed");
        var attack = composer.format("<script>alert(1)</script>\n[bad](javascript:alert(1))", "minimal");
        check(!attack.html().contains("<script") && !attack.html().contains("href=\"javascript"),"XSS");
        check(attack.html().contains("&lt;script&gt;"),"source not preserved safely");
        var malformed = composer.format("| A | B |\n| --- | --- |\n| 1 | 2 | 3 |",null);
        check(malformed.html().contains("<td>3</td>"),"extra table value lost");
        boolean failed=false;try{composer.format("x".repeat(300001),"bnp-green");}catch(IllegalArgumentException e){failed=true;}
        check(failed,"maximum size not enforced");
        failed=false;try{composer.format("x","danger");}catch(IllegalArgumentException e){failed=true;}
        check(failed,"theme not bounded");
        System.out.println("PASS: " + assertions + " focused Java assertions (formatting, text preservation, code, safe links, XSS, tables, size/theme bounds)");
    }
}
