package com.llmart.llm.service;

import java.time.Duration;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Short-lived complete MCP result store for Chat. Large Confluence/Jira responses are retained here instead of being
 * destructively clipped before the model can inspect them. The model receives a compact preview plus evidence tools
 * that can search/read exact chunks on demand. Nothing is persisted to disk.
 */
public class McpEvidenceStore {
    private static final long TTL_NANOS = Duration.ofMinutes(10).toNanos();
    private static final int MAX_ITEMS = 96;
    private static final int CHUNK_CHARS = 7_000;
    private static final int OVERLAP_CHARS = 350;

    private final Map<String, Evidence> evidence = new ConcurrentHashMap<>();
    private final Map<String, String> cacheKeys = new ConcurrentHashMap<>();
    private final AtomicLong ids = new AtomicLong();

    public Stored store(String source, String content) {
        return store(source, content, null);
    }

    public Stored store(String source, String content, String cacheKey) {
        prune();
        String safe = content == null ? "" : content;
        String id = "mcp-ev-" + Long.toString(System.currentTimeMillis(), 36) + "-" + Long.toString(ids.incrementAndGet(), 36);
        List<String> chunks = chunk(safe);
        Evidence item = new Evidence(id, source == null ? "MCP" : source, safe, chunks, System.nanoTime());
        if (evidence.size() >= MAX_ITEMS) evictOldest();
        evidence.put(id, item);
        if (cacheKey != null && !cacheKey.isBlank()) cacheKeys.put(cacheKey, id);
        return new Stored(id, item.source(), safe.length(), chunks.size());
    }

    public Optional<String> cachedPreview(String cacheKey, String query, boolean broad) {
        prune();
        if (cacheKey == null || cacheKey.isBlank()) return Optional.empty();
        String id = cacheKeys.get(cacheKey);
        if (id == null) return Optional.empty();
        Evidence item = evidence.get(id);
        if (item == null || expired(item)) { cacheKeys.remove(cacheKey, id); return Optional.empty(); }
        return Optional.of(preview(new Stored(item.id(), item.source(), item.content().length(), item.chunks().size()), query, broad) +
                "\n[MCP evidence cache hit: external page was not fetched again.] ");
    }

    public String search(String id, String query, int limit) {
        Evidence item = require(id);
        int wanted = Math.max(1, Math.min(limit <= 0 ? 4 : limit, 8));
        Set<String> terms = terms(query);
        List<Integer> indexes = new ArrayList<>();
        for (int i = 0; i < item.chunks().size(); i++) indexes.add(i);
        indexes.sort((a, b) -> Integer.compare(score(item.chunks().get(b), terms), score(item.chunks().get(a), terms)));
        if (terms.isEmpty()) indexes.sort(Integer::compareTo);
        StringBuilder out = new StringBuilder(manifest(item));
        int used = 0;
        for (Integer index : indexes) {
            if (used++ >= wanted) break;
            out.append("\n\n--- EVIDENCE CHUNK ").append(index + 1).append('/').append(item.chunks().size()).append(" ---\n")
                    .append(item.chunks().get(index));
        }
        return out.toString();
    }

    public String read(String id, int startChunk, int count) {
        Evidence item = require(id);
        int start = Math.max(1, startChunk <= 0 ? 1 : startChunk);
        int wanted = Math.max(1, Math.min(count <= 0 ? 2 : count, 10));
        if (start > item.chunks().size()) throw new IllegalArgumentException("Evidence chunk starts after available content: " + start + "/" + item.chunks().size());
        StringBuilder out = new StringBuilder(manifest(item));
        for (int i = start - 1; i < item.chunks().size() && i < start - 1 + wanted; i++) {
            out.append("\n\n--- EVIDENCE CHUNK ").append(i + 1).append('/').append(item.chunks().size()).append(" ---\n")
                    .append(item.chunks().get(i));
        }
        return out.toString();
    }

    public String preview(Stored stored, String query, boolean broad) {
        Evidence item = require(stored.id());
        if (item.content().length() <= 24_000) return manifest(item) + "\n\n" + item.content();
        String preview;
        if (broad && item.chunks().size() <= 6) {
            // Complete/full-page requests should not lose sections merely because the content is larger than the old
            // 32k Chat clip. Up to six bounded chunks are returned sequentially; larger pages remain searchable/readable.
            preview = read(stored.id(), 1, item.chunks().size());
        } else {
            preview = search(stored.id(), query, broad ? 6 : 4);
        }
        return preview +
                "\n\n[Complete MCP result retained in the short-lived evidence store. Use eliya_mcp_evidence_search/read if another section is needed; do not assume omitted chunks are absent.]";
    }

    public boolean contains(String id) {
        if (id == null || id.isBlank()) return false;
        Evidence item = evidence.get(id);
        return item != null && !expired(item);
    }

    private Evidence require(String id) {
        prune();
        Evidence item = evidence.get(id);
        if (item == null) throw new IllegalArgumentException("MCP evidence expired or not found: " + id);
        return item;
    }

    private String manifest(Evidence item) {
        return "MCP_EVIDENCE id=" + item.id() + "; source=" + item.source() + "; chars=" + item.content().length() +
                "; chunks=" + item.chunks().size() + "; retained=complete";
    }

    private List<String> chunk(String value) {
        if (value == null || value.isBlank()) return List.of("");
        List<String> out = new ArrayList<>();
        int start = 0;
        while (start < value.length()) {
            int maxEnd = Math.min(value.length(), start + CHUNK_CHARS);
            int end = maxEnd;
            if (maxEnd < value.length()) {
                int newline = value.lastIndexOf('\n', maxEnd);
                if (newline > start + CHUNK_CHARS / 2) end = newline + 1;
            }
            out.add(value.substring(start, end));
            if (end >= value.length()) break;
            start = Math.max(start + 1, end - OVERLAP_CHARS);
        }
        return List.copyOf(out);
    }

    private Set<String> terms(String query) {
        LinkedHashSet<String> out = new LinkedHashSet<>();
        if (query == null) return out;
        for (String part : query.toLowerCase(Locale.ROOT).split("[^a-z0-9_-]+")) {
            if (part.length() >= 3 && !Set.of("the","and","for","with","from","this","that","what","which","how","all","page","confluence","details").contains(part)) out.add(part);
        }
        return out;
    }

    private int score(String chunk, Set<String> terms) {
        String low = chunk.toLowerCase(Locale.ROOT);
        int score = 0;
        for (String term : terms) {
            int at = low.indexOf(term);
            if (at >= 0) score += 4;
            int next = at < 0 ? -1 : low.indexOf(term, at + term.length());
            if (next >= 0) score += 2;
        }
        return score;
    }

    private void prune() {
        Set<String> expiredIds = new HashSet<>();
        evidence.entrySet().removeIf(entry -> {
            boolean expired = expired(entry.getValue());
            if (expired) expiredIds.add(entry.getKey());
            return expired;
        });
        if (!expiredIds.isEmpty()) cacheKeys.entrySet().removeIf(entry -> expiredIds.contains(entry.getValue()));
    }

    private boolean expired(Evidence item) {
        long age = System.nanoTime() - item.createdAtNanos();
        return age < 0 || age > TTL_NANOS;
    }

    private void evictOldest() {
        evidence.values().stream().min(Comparator.comparingLong(Evidence::createdAtNanos)).ifPresent(old -> {
            evidence.remove(old.id());
            cacheKeys.entrySet().removeIf(entry -> old.id().equals(entry.getValue()));
        });
    }

    public record Stored(String id, String source, int chars, int chunks) {}
    private record Evidence(String id, String source, String content, List<String> chunks, long createdAtNanos) {}
}
