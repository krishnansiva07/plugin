package com.llmart.llm.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.poi.sl.usermodel.PaintStyle;
import org.apache.poi.xslf.usermodel.*;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.rendering.PDFRenderer;

import javax.imageio.ImageIO;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.Dimension;
import java.awt.image.BufferedImage;
import java.awt.geom.Rectangle2D;
import java.io.IOException;
import java.nio.file.*;
import java.time.Duration;
import java.util.*;
import java.util.concurrent.TimeUnit;

/**
 * Additive, deterministic, editable PPTX tools. Template slides are cloned *within the source
 * package* so masters, theme, layouts, images and relationships remain available. The LLM
 * chooses a layout and supplies factual content; this class owns file safety and QA.
 */
public final class PresentationIntelligenceService {
    private static final int MAX_SLIDES = 60;
    private final ObjectMapper json = new ObjectMapper();

    public String inspect(Path reference) throws IOException {
        pptx(reference);
        try (XMLSlideShow deck = new XMLSlideShow(Files.newInputStream(reference))) {
            Dimension size = deck.getPageSize();
            List<Map<String,Object>> slides = new ArrayList<>();
            int n = 0;
            for (XSLFSlide slide : deck.getSlides()) {
                if (++n > 80) break;
                List<Map<String,Object>> frames = new ArrayList<>();
                int images=0, tables=0, groups=0, charts=0;
                for (XSLFShape shape : slide.getShapes()) {
                    if (shape instanceof XSLFPictureShape) images++;
                    if (shape instanceof XSLFTable) tables++;
                    if (shape instanceof XSLFGroupShape) groups++;
                    if (shape instanceof XSLFGraphicFrame && !(shape instanceof XSLFTable)) charts++;
                    if (shape instanceof XSLFTextShape text && !text.getText().isBlank() && frames.size() < 25) {
                        Rectangle2D b=shape.getAnchor();
                        frames.add(Map.of("text",text.getText().substring(0,Math.min(160,text.getText().length())),
                                "x",Math.round(b.getX()),"y",Math.round(b.getY()),
                                "width",Math.round(b.getWidth()),"height",Math.round(b.getHeight())));
                    }
                }
                slides.add(Map.of("slide",n,"textFrames",frames,"pictures",images,"tables",tables,
                        "groups",groups,"charts",charts,"shapes",slide.getShapes().size()));
            }
            return pretty(Map.of("reference",reference.toString(),"widthPt",size.width,"heightPt",size.height,
                    "slideCount",deck.getSlides().size(),"slides",slides,
                    "guidance","Select templateSlide (1-based). Reference charts/tables are removed to avoid copying stale data. Supply chart, table or diagram data for a native editable replacement. Embedded SmartArt is not reconstructed as SmartArt."));
        }
    }

    /** Build into a temporary file. The caller decides when to atomically publish it. */
    public String generate(Path reference, Path temporaryOutput, JsonNode specifications) throws IOException {
        pptx(reference);
        if (specifications==null || !specifications.isArray() || specifications.isEmpty() || specifications.size()>MAX_SLIDES)
            throw new IllegalArgumentException("slides must be an array with 1-"+MAX_SLIDES+" slide objects");
        List<SlideSpec> slides=new ArrayList<>();
        for (JsonNode node:specifications) {
            String title=node.path("title").asText("").strip();
            if (title.isBlank() || title.length()>135) throw new IllegalArgumentException("Each slide needs a title of at most 135 characters");
            List<String> bullets=new ArrayList<>();
            if (node.has("bullets") && !node.get("bullets").isArray()) throw new IllegalArgumentException("bullets must be an array");
            if (node.has("bullets")) for(JsonNode bullet:node.get("bullets")) {
                String value=bullet.asText("").strip();
                if (!value.isBlank()) bullets.add(value);
            }
            if (bullets.size()>9 || bullets.stream().anyMatch(b -> b.length()>320))
                throw new IllegalArgumentException("Too much text on '"+title+"'. Use at most 9 bullets, each <=320 characters; split the slide for readability");
            PresentationComponents.check(node);
            slides.add(new SlideSpec(title,List.copyOf(bullets),node.path("templateSlide").asInt(0),node));
        }
        ArrayList<String> warnings=new ArrayList<>();
        try (XMLSlideShow deck = new XMLSlideShow(Files.newInputStream(reference))) {
            List<XSLFSlide> originals=List.copyOf(deck.getSlides());
            if (originals.isEmpty()) throw new IllegalArgumentException("Reference presentation contains no slides");
            Dimension size=deck.getPageSize();
            for (int i=0;i<slides.size();i++) {
                SlideSpec spec=slides.get(i);
                int chosen=spec.templateSlide()>0 ? spec.templateSlide()-1 : Math.min(i,originals.size()-1);
                if (chosen<0 || chosen>=originals.size()) throw new IllegalArgumentException("Invalid templateSlide " + spec.templateSlide() + " for '"+spec.title()+"'");
                XSLFSlide sample=originals.get(chosen);
                long pictures = sample.getShapes().stream().filter(s->s instanceof XSLFPictureShape).count();
                if (pictures>1 || sample.getShapes().stream().filter(s->s instanceof XSLFPictureShape)
                        .anyMatch(s->s.getAnchor().getWidth()*s.getAnchor().getHeight()>size.width*size.height*.22))
                    warnings.add("Slide "+(i+1)+": "+pictures+" reference image(s) reused; confirm they are branding/decorative or relevant to the new content");
                XSLFSlide generated=sample.getSlideLayout()==null ? deck.createSlide() : deck.createSlide(sample.getSlideLayout());
                generated.importContent(sample);
                // Imported native charts/tables can hold OLD facts. Never retain their source data.
                // Text-bearing SmartArt/grouped drawings are also removed, since replacing only
                // nearby text would silently leave obsolete labels inside the group.
                for (XSLFShape shape:List.copyOf(generated.getShapes())) {
                    if(shape instanceof XSLFGraphicFrame) {
                        generated.removeShape(shape);
                        warnings.add("Slide "+(i+1)+": old embedded chart/table/graphic frame removed; data-linked charts and SmartArt are not reused");
                    } else if (shape instanceof XSLFGroupShape group && containsNarrative(group)) {
                        generated.removeShape(shape);
                        warnings.add("Slide "+(i+1)+": old text-bearing group replaced/removed; diagrams are rebuilt as editable shapes only when diagram data is supplied");
                    }
                }
                populate(generated,spec,size,warnings,i+1);
            }
            // Remove only the original slides. Newly generated slides retain this deck's masters/theme.
            for(int i=0;i<originals.size();i++) deck.removeSlide(0);
            Files.createDirectories(temporaryOutput.toAbsolutePath().getParent());
            try (var out=Files.newOutputStream(temporaryOutput,StandardOpenOption.CREATE,StandardOpenOption.TRUNCATE_EXISTING)) { deck.write(out); }
        }
        Map<String,Object> qa=quality(temporaryOutput,slides);
        @SuppressWarnings("unchecked") List<String> issues=(List<String>)qa.get("issues");
        @SuppressWarnings("unchecked") List<String> advisories=(List<String>)qa.get("warnings");
        advisories.addAll(warnings);
        if (!issues.isEmpty()) throw new IllegalStateException("Presentation did not pass verification: "+String.join("; ",issues));
        qa.put("reference",reference.toString());
        qa.put("editable","Editable PowerPoint titles, paragraphs, tables and shape-based bar/column/line charts and diagrams; inherited reference images remain raster/vector images. Not Excel-data-linked charts or native SmartArt.");
        qa.put("visualReview","NOT VERIFIED: presentation_preview performs automated raster checks if a renderer is installed, but slide appearance still needs review");
        return pretty(qa);
    }

    private static boolean containsNarrative(XSLFGroupShape group) {
        for(XSLFShape child:group.getShapes()) {
            if(child instanceof XSLFTextShape text && !text.getText().isBlank())return true;
            if(child instanceof XSLFGroupShape nested && containsNarrative(nested))return true;
            if(child instanceof XSLFGraphicFrame)return true;
        }
        return false;
    }

    /** Structural/content QA is not represented as visual review. */
    public String validate(Path path) throws IOException { return pretty(quality(path,null)); }

    private Map<String,Object> quality(Path path,List<SlideSpec> expected) throws IOException {
        pptx(path);
        List<String> issues=new ArrayList<>(), warnings=new ArrayList<>();
        int count=0;
        try (XMLSlideShow deck=new XMLSlideShow(Files.newInputStream(path))) {
            Dimension dimensions=deck.getPageSize();
            if(deck.getSlides().isEmpty()) issues.add("Presentation contains no slides");
            for (XSLFSlide slide:deck.getSlides()) {
                count++;
                List<String> texts=new ArrayList<>();
                List<XSLFTextShape> frames=new ArrayList<>();
                for (XSLFShape shape:slide.getShapes()) {
                    if (shape instanceof XSLFTable table) {
                        for(XSLFTableRow row:table.getRows())for(XSLFTableCell cell:row.getCells())
                            if(!cell.getText().isBlank()) texts.add(cell.getText());
                    }
                    if (!(shape instanceof XSLFTextShape frame) || frame.getText().isBlank()) continue;
                    texts.add(frame.getText());frames.add(frame);
                    Rectangle2D b=frame.getAnchor();
                    if (b.getX() < -1 || b.getY() < -1 || b.getMaxX()>dimensions.width+1 || b.getMaxY()>dimensions.height+1)
                        issues.add("Slide "+count+": text outside slide bounds: " + shortText(frame.getText()));
                    double font=font(frame,frame.getText().length()<135?28:18);
                    int lineCapacity=Math.max(1,(int)(b.getWidth()/Math.max(1,font*.53)));
                    int estimatedLines=0;
                    for(String para:frame.getText().split("\\R",-1)) estimatedLines+=Math.max(1,(int)Math.ceil((double)para.length()/lineCapacity));
                    if (estimatedLines*font*1.18>b.getHeight()+Math.max(10,font*0.5))
                        warnings.add("Slide "+count+": potential text overflow: "+shortText(frame.getText()));
                }
                if (texts.isEmpty()) warnings.add("Slide "+count+": no editable text found");
                if (expected!=null && count<=expected.size()) {
                    SlideSpec spec=expected.get(count-1);
                    String all=String.join("\n",texts);
                    if (!all.contains(spec.title())) issues.add("Slide "+count+": missing expected title");
                    for (String bullet:spec.bullets()) if(!all.contains(bullet)) issues.add("Slide "+count+": missing content: "+shortText(bullet));
                    JsonNode content=spec.payload();
                    if(content.hasNonNull("table")) {
                        if (slide.getShapes().stream().noneMatch(sh -> sh instanceof XSLFTable))issues.add("Slide "+count+": missing native table");
                        JsonNode t=content.get("table");
                        for(JsonNode h:t.get("headers"))if(!all.contains(h.asText()))issues.add("Slide "+count+": missing table header: "+shortText(h.asText()));
                        for(JsonNode r:t.get("rows"))for(JsonNode cell:r)if(!cell.asText().isBlank()&&!all.contains(cell.asText()))
                            issues.add("Slide "+count+": missing table value: "+shortText(cell.asText()));
                    }
                    if(content.hasNonNull("chart")) {
                        JsonNode chart=content.get("chart");
                        for(JsonNode label:chart.get("labels"))if(!all.contains(label.asText()))issues.add("Slide "+count+": missing chart label "+shortText(label.asText()));
                        for(JsonNode series:chart.get("series"))if(!all.contains(series.path("name").asText()))
                            issues.add("Slide "+count+": missing series label "+shortText(series.path("name").asText()));
                    }
                    if(content.hasNonNull("diagram")) for(JsonNode node:content.get("diagram").get("nodes"))
                        if(!all.contains(node.asText()))issues.add("Slide "+count+": missing diagram node "+shortText(node.asText()));
                }
                // Detect only obvious peer-level overlaps, not intentional text within coloured shapes/images.
                for (int i=0;i<frames.size();i++) for(int j=i+1;j<frames.size();j++) {
                    Rectangle2D a=frames.get(i).getAnchor(), b=frames.get(j).getAnchor();
                    Rectangle2D overlap=a.createIntersection(b);
                    if(overlap.getWidth()>8 && overlap.getHeight()>8 &&
                            overlap.getWidth()*overlap.getHeight()>Math.min(a.getWidth()*a.getHeight(),b.getWidth()*b.getHeight())*.25)
                        warnings.add("Slide "+count+": overlapping text frames (review rendered preview)");
                }
            }
            if(expected!=null && count!=expected.size()) issues.add("Expected "+expected.size()+" slides; found "+count);
        }
        Map<String,Object> result=new LinkedHashMap<>();
        result.put("status",issues.isEmpty()?"STRUCTURAL_PASS":"FAIL");result.put("slides",count);
        result.put("issues",issues);result.put("warnings",warnings);
        result.put("visualReview","Not performed by structural validator; run presentation_preview and inspect images");
        return result;
    }

    /** Raster QA is automated, but aesthetic/brand/factual review remains explicitly required. */
    public String preview(Path pptx, Path previewDir) throws IOException {
        pptx(pptx);
        String executable=executable();
        if(executable==null) return previewWithPoi(pptx,previewDir);
        Files.createDirectories(previewDir);
        Path pdf=previewDir.resolve(pptx.getFileName().toString().replaceFirst("(?i)\\.pptx$",".pdf"));
        Files.deleteIfExists(pdf); // never approve a stale PDF from a previous attempt
        Process p = new ProcessBuilder(executable,"-env:UserInstallation="+previewDir.resolve("lo-profile").toUri(),
                "--headless","--convert-to","pdf","--outdir",previewDir.toString(),pptx.toString())
                .redirectErrorStream(true).start();
        try {
            if(!p.waitFor(100,TimeUnit.SECONDS)) {p.destroyForcibly();return pretty(Map.of("status","FAIL","reason","Preview conversion timed out"));}
        } catch(InterruptedException e){Thread.currentThread().interrupt();p.destroyForcibly();throw new IOException("Preview rendering interrupted",e);}
        if(p.exitValue()!=0 || !Files.isRegularFile(pdf)) return pretty(Map.of("status","FAIL","reason","PowerPoint-to-PDF conversion failed, exit="+p.exitValue()));
        List<String> frames=new ArrayList<>(), warnings=new ArrayList<>(), issues=new ArrayList<>();
        int expected;
        try(XMLSlideShow show=new XMLSlideShow(Files.newInputStream(pptx))) {expected=show.getSlides().size();}
        try (PDDocument document=PDDocument.load(pdf.toFile())) {
            if(document.getNumberOfPages()!=expected)issues.add("Preview page count differs from PowerPoint slide count: "+document.getNumberOfPages()+" vs "+expected);
            PDFRenderer renderer=new PDFRenderer(document);
            for(int i=0;i<document.getNumberOfPages();i++) {
                String name="slide-"+String.format(Locale.ROOT,"%02d",i+1)+".png";
                Path file=previewDir.resolve(name);
                Files.deleteIfExists(file);
                BufferedImage rendered=renderer.renderImageWithDPI(i,120);
                if(!ImageIO.write(rendered,"png",file.toFile()))issues.add("Slide "+(i+1)+": PNG writer unavailable");
                frames.add(file.toString());
                inspectRaster(rendered,i+1,warnings);
            }
        }
        Map<String,Object> result=new LinkedHashMap<>();
        result.put("status",issues.isEmpty()?"AUTO_CHECK_PASS_REVIEW_REQUIRED":"FAIL");
        result.put("slideImages",frames);result.put("pdf",pdf.toString());
        result.put("issues",issues);result.put("warnings",warnings);
        result.put("checks",List.of("PDF render completed","slide count compared","PNG images saved","uniform/blank slide heuristic"));
        result.put("visualReview","REVIEW REQUIRED: rendering/pixel heuristics cannot prove legibility, branding accuracy, diagram semantics or visual fidelity; inspect every image");
        return pretty(result);
    }

    /** Java 17 fallback for Windows/macOS/Linux where LibreOffice is not installed.
     * POI's rendering can differ from PowerPoint (notably embedded fonts and SmartArt).
     */
    private String previewWithPoi(Path pptx, Path previewDir) throws IOException {
        List<String> frames=new ArrayList<>(), warnings=new ArrayList<>();
        try (XMLSlideShow show=new XMLSlideShow(Files.newInputStream(pptx))) {
            Files.createDirectories(previewDir);
            Dimension size=show.getPageSize();
            double scale=1.5;
            for(int i=0;i<show.getSlides().size();i++) {
                BufferedImage rendered=new BufferedImage(Math.max(1,(int)(size.width*scale)),Math.max(1,(int)(size.height*scale)),BufferedImage.TYPE_INT_RGB);
                Graphics2D gfx=rendered.createGraphics();
                try {
                    gfx.setColor(Color.WHITE);gfx.fillRect(0,0,rendered.getWidth(),rendered.getHeight());
                    gfx.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
                    gfx.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING,RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
                    gfx.scale(scale,scale);
                    show.getSlides().get(i).draw(gfx);
                } finally {gfx.dispose();}
                Path image=previewDir.resolve("slide-"+String.format(Locale.ROOT,"%02d",i+1)+".png");
                Files.deleteIfExists(image);
                if(!ImageIO.write(rendered,"png",image.toFile()))throw new IOException("No PNG writer available");
                frames.add(image.toString());inspectRaster(rendered,i+1,warnings);
            }
        } catch (RuntimeException | LinkageError e) {
            return pretty(Map.of("status","UNAVAILABLE","reason","LibreOffice missing; Java preview failed: "+e.getClass().getSimpleName(),
                    "visualReview","Open each slide in PowerPoint/Keynote; rendering was not verified"));
        }
        Map<String,Object> result=new LinkedHashMap<>();
        result.put("status","JAVA_RENDER_REVIEW_REQUIRED");result.put("slideImages",frames);
        result.put("warnings",warnings);
        result.put("checks",List.of("PNG renders created with Apache POI","near-blank raster heuristic"));
        result.put("visualReview","REVIEW REQUIRED: Java renderer may differ from Microsoft PowerPoint. No PDF produced; confirm fonts, SmartArt, appearance and branding in PowerPoint");
        return pretty(result);
    }

    private static void inspectRaster(BufferedImage image,int slide,List<String> warnings) {
        Set<Integer> bins=new HashSet<>();
        int step=Math.max(2,Math.min(image.getWidth(),image.getHeight())/85);
        for(int y=0;y<image.getHeight();y+=step)for(int x=0;x<image.getWidth();x+=step) {
            int rgb=image.getRGB(x,y);
            bins.add(((rgb>>20)&15)<<8 | ((rgb>>12)&15)<<4 | ((rgb>>4)&15));
        }
        if(bins.size()<=2)warnings.add("Slide "+slide+": visually uniform/possibly blank preview; inspect manually");
    }

    private static String executable() {
        String[] names=System.getProperty("os.name","").toLowerCase(Locale.ROOT).contains("win")
                ? new String[]{"soffice.exe","C:\\Program Files\\LibreOffice\\program\\soffice.exe"}
                : new String[]{"soffice","libreoffice","/Applications/LibreOffice.app/Contents/MacOS/soffice"};
        for(String name:names) try {
            Process p=new ProcessBuilder(name,"--version").redirectErrorStream(true).start();
            if(p.waitFor(4,TimeUnit.SECONDS)&&p.exitValue()==0)return name;
            p.destroyForcibly();
        }catch(Exception ignored){ }
        return null;
    }

    /** Fill cloned template with content, then bound deterministic layout repairs. */
    private static void populate(XSLFSlide slide,SlideSpec spec,Dimension size,List<String> warnings,int index) {
        List<XSLFTextShape> shapes=new ArrayList<>();
        for(XSLFShape shape:slide.getShapes())if(shape instanceof XSLFTextShape text && !text.getText().isBlank())shapes.add(text);
        shapes.sort(Comparator.comparingDouble(a->a.getAnchor().getY()));
        XSLFTextShape title=shapes.stream().filter(s->s.getAnchor().getY()<size.height*.45 && s.getText().length()<160)
                .max(Comparator.comparingDouble(s->font(s,18))).orElse(null);
        final XSLFTextShape templateTitle=title;
        XSLFTextShape body=shapes.stream().filter(s->s!=templateTitle && s.getAnchor().getY()<size.height*.82)
                .max(Comparator.comparingDouble(s->s.getAnchor().getWidth()*s.getAnchor().getHeight())).orElse(null);
        TextStyle titleStyle=style(title,new TextStyle(30,"Aptos Display",new Color(19,43,74),true));
        TextStyle bodyStyle=style(body,new TextStyle(19,"Aptos",new Color(47,58,73),false));
        for(XSLFTextShape s:shapes)if(s!=title && s!=body && !looksLikeStaticBrand(s,size))s.clearText();
        if(title==null) {
            title=slide.createTextBox();title.setAnchor(new Rectangle2D.Double(size.width*.08,size.height*.065,size.width*.84,size.height*.16));
        }
        Rectangle2D head=title.getAnchor();
        if(head.getWidth()<size.width*.42 || head.getX()<0 || head.getMaxX()>size.width)
            title.setAnchor(new Rectangle2D.Double(size.width*.08,Math.max(8,head.getY()),size.width*.84,Math.max(55,head.getHeight())));
        int titlePt=Math.max(20,Math.min(36,titleStyle.pt()));
        while(titlePt>20 && estimatedHeight(spec.title(),title.getAnchor().getWidth()-6,titlePt)>title.getAnchor().getHeight()-5)titlePt--;
        if(estimatedHeight(spec.title(),title.getAnchor().getWidth()-6,titlePt)>title.getAnchor().getHeight()-5) {
            double required=estimatedHeight(spec.title(),title.getAnchor().getWidth()-6,titlePt)+10;
            if(title.getAnchor().getY()+required>size.height*.29)
                throw new IllegalArgumentException("Slide "+index+": title cannot fit the reference heading area; shorten the title");
            title.setAnchor(new Rectangle2D.Double(title.getAnchor().getX(),title.getAnchor().getY(),title.getAnchor().getWidth(),required));
            warnings.add("Slide "+index+": title box enlarged to avoid clipping");
        }
        apply(title,spec.title(),titleStyle,titlePt);
        if(titlePt<Math.min(36,titleStyle.pt()))warnings.add("Slide "+index+": title font auto-fitted to "+titlePt+"pt");
        double top=Math.max(size.height*.25,title.getAnchor().getMaxY()+14);
        double bottom=Math.max(45,size.height*.88-top);
        boolean visual=PresentationComponents.hasVisual(spec.payload());
        Rectangle2D content;
        if(visual) {
            content=new Rectangle2D.Double(size.width*.085,top,size.width*.83,bottom);
            if(!spec.bullets().isEmpty()) {
                double left=Math.min(size.width*.28,content.getWidth()*.34);
                content=new Rectangle2D.Double(size.width*.085+left+14,top,size.width*.83-left-14,bottom);
            }
        } else content=null;
        if(spec.bullets().isEmpty()) {if(body!=null)body.clearText();}
        else {
            if(body==null)body=slide.createTextBox();
            Rectangle2D current=body.getAnchor();
            if(visual) body.setAnchor(new Rectangle2D.Double(size.width*.085,top,content.getX()-size.width*.085-14,bottom));
            else if(current.getWidth()<size.width*.40 || current.getY()<top-4 || current.getMaxY()>size.height*.91
                    || current.getMaxX()>size.width*.94) {
                body.setAnchor(new Rectangle2D.Double(size.width*.09,top,size.width*.82,bottom));
                warnings.add("Slide "+index+": content region repositioned to prevent title/content overlap");
            }
            Rectangle2D box=body.getAnchor();
            String value=String.join("\n",spec.bullets().stream().map(b->"• "+b).toList());
            int pt=Math.min(22,Math.max(17,bodyStyle.pt()));
            while(pt>=14 && estimatedHeight(value,box.getWidth()-10,pt)>box.getHeight()-10)pt--;
            if(pt<14)throw new IllegalArgumentException("Slide "+index+": content will overflow even after fitting. Split the slide or select a roomier templateSlide");
            apply(body,value,bodyStyle,pt);body.setWordWrap(true);
            if(pt<17)warnings.add("Slide "+index+": dense content auto-fitted to "+pt+"pt; consider splitting");
        }
        if(visual) PresentationComponents.add(slide,spec.payload(),content,titleStyle.color(),bodyStyle.family());
    }

    private static boolean looksLikeStaticBrand(XSLFTextShape s,Dimension d){
        String text=s.getText().strip().toLowerCase(Locale.ROOT);
        return s.getAnchor().getY()>d.height*.82 && text.length()<80 &&
                (text.matches("\\d{1,3}") || text.contains("confidential") || text.contains("©") || text.contains("copyright"));
    }
    private static double estimatedHeight(String text,double width,int pt){
        double chars=Math.max(1,width/(pt*.53));double lines=0;
        for(String line:text.split("\\n",-1))lines+=Math.max(1,Math.ceil(line.length()/chars));
        return lines*pt*1.30;
    }
    private static TextStyle style(XSLFTextShape shape,TextStyle fallback){
        if(shape==null)return fallback;
        for(XSLFTextParagraph p:shape.getTextParagraphs())for(XSLFTextRun r:p.getTextRuns()) {
            Double sz=r.getFontSize();
            String family=r.getFontFamily();
            Color color=fallback.color();
            if(r.getFontColor() instanceof PaintStyle.SolidPaint paint && paint.getSolidColor().getColor()!=null)
                color=paint.getSolidColor().getColor();
            return new TextStyle(sz==null?fallback.pt():Math.max(12,Math.min(42,sz.intValue())),
                    family==null?fallback.family():family,color,r.isBold());
        }
        return fallback;
    }
    private static double font(XSLFTextShape shape,double fallback){
        for(XSLFTextParagraph p:shape.getTextParagraphs())for(XSLFTextRun r:p.getTextRuns())if(r.getFontSize()!=null)return r.getFontSize();
        return fallback;
    }
    private static void apply(XSLFTextShape shape,String text,TextStyle style,int pt){
        shape.clearText();shape.setText(text);shape.setWordWrap(true);
        for(XSLFTextParagraph p:shape.getTextParagraphs())for(XSLFTextRun r:p.getTextRuns()){
            r.setFontSize((double)pt);r.setFontFamily(style.family());r.setBold(style.bold());r.setFontColor(style.color());
        }
    }
    private static void pptx(Path file) throws IOException {
        if(!file.getFileName().toString().toLowerCase(Locale.ROOT).endsWith(".pptx"))throw new IllegalArgumentException("Only editable .pptx files are supported");
        if(!Files.isRegularFile(file))throw new NoSuchFileException(file.toString());
        if(Files.size(file)>70*1024*1024)throw new IllegalArgumentException("PPTX exceeds 70 MB safety limit");
    }
    private static String shortText(String s){return s.length()>65?s.substring(0,65)+"…":s;}
    private String pretty(Object obj) throws IOException{return json.writerWithDefaultPrettyPrinter().writeValueAsString(obj);}
    private record SlideSpec(String title,List<String> bullets,int templateSlide,JsonNode payload) { }
    private record TextStyle(int pt,String family,Color color,boolean bold) { }
}
