package com.llmart.llm.service;

import com.fasterxml.jackson.databind.JsonNode;
import org.apache.poi.xslf.usermodel.*;

import java.awt.Color;
import java.awt.geom.Rectangle2D;
import java.util.*;

/** Native, editable PowerPoint alternatives to static chart/diagram screenshots. */
final class PresentationComponents {
    private static final Color[] PALETTE = {
            new Color(22, 90, 117), new Color(20, 142, 132), new Color(231, 163, 73),
            new Color(106, 90, 156), new Color(88, 151, 197), new Color(189, 98, 94)
    };
    private static final Color INK = new Color(33, 51, 70);
    private PresentationComponents() {}

    static void check(JsonNode spec) {
        int count = (spec.hasNonNull("chart") ? 1 : 0) + (spec.hasNonNull("table") ? 1 : 0)
                + (spec.hasNonNull("diagram") ? 1 : 0);
        if (count > 1) throw new IllegalArgumentException("One visual (chart, table or diagram) per slide; split complex slides");
        if (spec.hasNonNull("chart")) checkChart(spec.get("chart"));
        if (spec.hasNonNull("table")) checkTable(spec.get("table"));
        if (spec.hasNonNull("diagram")) checkDiagram(spec.get("diagram"));
    }

    static boolean hasVisual(JsonNode spec) {
        return spec.hasNonNull("chart") || spec.hasNonNull("table") || spec.hasNonNull("diagram");
    }

    static void add(XSLFSlide slide, JsonNode spec, Rectangle2D area, Color accent, String family) {
        if (spec.hasNonNull("chart")) chart(slide, spec.get("chart"), area, accent, family);
        else if (spec.hasNonNull("table")) table(slide, spec.get("table"), area, accent, family);
        else if (spec.hasNonNull("diagram")) diagram(slide, spec.get("diagram"), area, accent, family);
    }

    private static void checkChart(JsonNode chart) {
        String type = chart.path("type").asText("column").toLowerCase(Locale.ROOT);
        if (!Set.of("column", "bar", "line", "stacked_column", "stacked_bar").contains(type))
            throw new IllegalArgumentException("Supported editable chart types: column, bar, line, stacked_column, stacked_bar. Pie/donut/3D need a different renderer.");
        JsonNode labels = chart.path("labels"), series = chart.path("series");
        if (!labels.isArray() || labels.isEmpty() || labels.size()>7 || !series.isArray() || series.isEmpty() || series.size()>4)
            throw new IllegalArgumentException("Charts require 1-7 labels and 1-4 data series");
        for (JsonNode label : labels) if (label.asText("").isBlank() || label.asText("").length()>18)
            throw new IllegalArgumentException("Chart labels need 1-18 characters");
        for (JsonNode item : series) {
            JsonNode values=item.path("values");
            if (item.path("name").asText("").isBlank() || item.path("name").asText("").length()>24 || !values.isArray() || values.size()!=labels.size())
                throw new IllegalArgumentException("Each chart series needs a name and exactly one value per label");
            for (JsonNode value:values) if (!value.isNumber() || !Double.isFinite(value.asDouble()) || value.asDouble()<0 || value.asDouble()>1e10)
                throw new IllegalArgumentException("Chart values must be nonnegative finite numbers <=10 billion");
        }
    }

    private static void checkTable(JsonNode table) {
        JsonNode headers=table.path("headers"), rows=table.path("rows");
        if (!headers.isArray() || headers.isEmpty() || headers.size()>7 || !rows.isArray() || rows.isEmpty() || rows.size()>9)
            throw new IllegalArgumentException("Tables require 1-7 headers and 1-9 rows");
        for (JsonNode cell:headers) if (cell.asText("").length()>60) throw new IllegalArgumentException("Table headers must be <=60 characters");
        for (JsonNode row:rows) {
            if (!row.isArray() || row.size()!=headers.size())throw new IllegalArgumentException("Table row width does not match headers");
            for(JsonNode cell:row) if(cell.asText("").length()>140)throw new IllegalArgumentException("Table cell exceeds 140 characters; split your slide");
        }
    }

    private static void checkDiagram(JsonNode diagram) {
        String type=diagram.path("type").asText("flow").toLowerCase(Locale.ROOT);
        if (!Set.of("flow","timeline","cycle").contains(type))
            throw new IllegalArgumentException("Supported diagram types: flow, timeline, cycle");
        JsonNode nodes=diagram.path("nodes");
        if(!nodes.isArray() || nodes.size()<2 || nodes.size()>6)
            throw new IllegalArgumentException("Diagrams require 2-6 nodes");
        for(JsonNode node:nodes) if(node.asText("").isBlank() || node.asText("").length()>30)
            throw new IllegalArgumentException("Diagram nodes need 1-30 characters");
    }

    private static void chart(XSLFSlide slide, JsonNode chart, Rectangle2D area, Color accent, String family) {
        String type=chart.path("type").asText("column").toLowerCase(Locale.ROOT);
        boolean horizontal=type.endsWith("bar"), stacked=type.startsWith("stacked"), line=type.equals("line");
        JsonNode labels=chart.get("labels"), series=chart.get("series");
        int categories=labels.size(), n=series.size();
        Color[] colors = palette(accent);
        double plotX=area.getX()+ (horizontal ? Math.min(104,area.getWidth()*.24) : 34);
        double plotY=area.getY()+12, plotW=area.getMaxX()-plotX-14;
        double plotH=area.getHeight()- (horizontal ? 30 : 58);
        if(plotW<100 || plotH<100)throw new IllegalArgumentException("Chart layout too small; use a slide with a larger content area");
        double max=0;
        for(int c=0;c<categories;c++) {
            double sum=0;
            for(JsonNode item:series) {
                double value=item.get("values").get(c).asDouble();
                sum+=value;max=Math.max(max,value);
            }
            if(stacked) max=Math.max(max,sum);
        }
        if(max<=0)max=1;
        line(slide,plotX,plotY+plotH,plotX+plotW,plotY+plotH,new Color(155,165,176));
        if(!horizontal)line(slide,plotX,plotY,plotX,plotY+plotH,new Color(155,165,176));
        for(int c=0;c<categories;c++) {
            if (horizontal) {
                double rowH=plotH/categories, y=plotY+c*rowH+rowH*.13;
                text(slide,labels.get(c).asText(),area.getX(),y,plotX-area.getX()-5,rowH*.72,12,INK,family,false);
                double used=0;
                for(int s=0;s<n;s++) {
                    double value=series.get(s).get("values").get(c).asDouble();
                    double width=(plotW-35)*value/max;
                    double h=stacked?rowH*.64:rowH*.65/n;
                    double barY=stacked?y:y+s*h;
                    double barX=plotX+(stacked?used:0);
                    block(slide,barX,barY,width,h,colors[s%colors.length]);
                    if(stacked)used+=width;
                }
            } else {
                double slot=plotW/categories, center=plotX+(c+.5)*slot;
                text(slide,labels.get(c).asText(),plotX+c*slot,plotY+plotH+5,slot,26,11,INK,family,false);
                if(line) {
                    for(int s=0;s<n;s++) {
                        double value=series.get(s).get("values").get(c).asDouble();
                        double y=plotY+plotH-(plotH-10)*value/max;
                        block(slide,center-3,y-3,6,6,colors[s%colors.length]);
                        if(c>0) {
                            double last=series.get(s).get("values").get(c-1).asDouble();
                            double lastY=plotY+plotH-(plotH-10)*last/max;
                            line(slide,center-slot,lastY,center,y,colors[s%colors.length]);
                        }
                    }
                } else {
                    double bw=slot*.72/(stacked?1:n), shift=slot*.36;
                    double used=0;
                    for(int s=0;s<n;s++) {
                        double value=series.get(s).get("values").get(c).asDouble();
                        double h=(plotH-10)*value/max;
                        double x=plotX+c*slot+slot*.14+(stacked?0:s*bw);
                        double y=plotY+plotH-h-(stacked?used:0);
                        block(slide,x,y,bw*.90,h,colors[s%colors.length]);
                        if(stacked)used+=h;
                    }
                }
            }
        }
        double legendY=area.getMaxY()-14;
        for(int s=0;s<n;s++) {
            double x=area.getX()+s*(area.getWidth()/n);
            block(slide,x,legendY,9,9,colors[s%colors.length]);
            text(slide,series.get(s).get("name").asText(),x+12,legendY-3,Math.max(35,area.getWidth()/n-12),16,10,INK,family,false);
        }
    }

    private static void table(XSLFSlide slide, JsonNode spec, Rectangle2D area, Color accent, String family) {
        JsonNode headers=spec.get("headers"), rows=spec.get("rows");
        int n=rows.size()+1, columns=headers.size();
        double height=area.getHeight()/n;
        int pt=n>7?10:12;
        int maxChars=Math.max(5,(int)((area.getWidth()/columns-10)/(pt*.62)))
                *Math.max(1,(int)((height-8)/(pt*1.30)));
        for(JsonNode cell:headers)if(cell.asText().length()>maxChars)
            throw new IllegalArgumentException("Table heading too long for selected layout; choose fewer columns or shorten text: "+cell.asText());
        for(JsonNode row:rows)for(JsonNode cell:row)if(cell.asText().length()>maxChars)
            throw new IllegalArgumentException("Table cell too long for selected layout; split slide or shorten: "+cell.asText());
        XSLFTable table=slide.createTable();
        for(int r=0;r<n;r++) {
            XSLFTableRow row=table.addRow();row.setHeight(height);
            for(int c=0;c<columns;c++) {
                XSLFTableCell cell=row.addCell();
                cell.setText(r==0?headers.get(c).asText():rows.get(r-1).get(c).asText());
                cell.setFillColor(r==0?accent:(r%2==0?new Color(236,242,246):Color.WHITE));
                cell.setWordWrap(true);
                for(XSLFTextParagraph p:cell.getTextParagraphs())for(XSLFTextRun run:p.getTextRuns()) {
                    run.setFontFamily(family);run.setFontSize((double)(n>7?10:12));
                    run.setBold(r==0);run.setFontColor(r==0?Color.WHITE:INK);
                }
            }
        }
        for(int c=0;c<columns;c++)table.setColumnWidth(c,area.getWidth()/columns);
        table.setAnchor(area);
    }

    private static void diagram(XSLFSlide slide, JsonNode diagram, Rectangle2D area, Color accent, String family) {
        JsonNode nodes=diagram.get("nodes");
        String type=diagram.path("type").asText("flow").toLowerCase(Locale.ROOT);
        int n=nodes.size();
        Color[] colors=palette(accent);
        if(type.equals("cycle")) {
            double w=Math.min(146,area.getWidth()*.31),h=Math.min(63,area.getHeight()*.22);
            double cx=area.getCenterX(),cy=area.getCenterY();
            double rx=Math.max(20,area.getWidth()*.40-w/2),ry=Math.max(20,area.getHeight()*.37-h/2);
            for(int i=0;i<n;i++) {
                double theta=-Math.PI/2+2*Math.PI*i/n;
                double x=cx+rx*Math.cos(theta)-w/2, y=cy+ry*Math.sin(theta)-h/2;
                block(slide,x,y,w,h,colors[i%colors.length]);
                text(slide,nodes.get(i).asText(),x+5,y+8,w-10,h-12,14,Color.WHITE,family,true);
            }
        } else if(type.equals("timeline")) {
            double slot=area.getWidth()/n,y=area.getY()+area.getHeight()*.36;
            line(slide,area.getX()+slot*.5,y,area.getMaxX()-slot*.5,y,accent);
            for(int i=0;i<n;i++) {
                double x=area.getX()+i*slot+slot*.08;
                block(slide,x+slot*.35,y-5,10,10,colors[i%colors.length]);
                text(slide,nodes.get(i).asText(),x,y+17,slot*.86,Math.max(40,area.getHeight()*.42),13,INK,family,true);
            }
        } else {
            double gap=16, w=(area.getWidth()-gap*(n-1))/n,h=Math.min(100,area.getHeight()*.58);
            if(w<60)throw new IllegalArgumentException("Flow diagram is too dense; use fewer nodes or a wider reference slide");
            double y=area.getCenterY()-h/2;
            for(int i=0;i<n;i++) {
                double x=area.getX()+i*(w+gap);
                block(slide,x,y,w,h,colors[i%colors.length]);
                text(slide,nodes.get(i).asText(),x+4,y+8,w-8,h-12,Math.min(15,Math.max(11,w/8)),Color.WHITE,family,true);
                if(i<n-1) {
                    line(slide,x+w+1,y+h/2,x+w+gap-2,y+h/2,accent);
                    text(slide,"›",x+w,y+h/2-12,gap,20,18,accent,family,true);
                }
            }
        }
    }

    private static Color[] palette(Color accent) {
        Color[] colors=PALETTE.clone();
        colors[0]=accent;
        return colors;
    }
    private static void block(XSLFSlide slide,double x,double y,double w,double h,Color color) {
        if(w<=0 || h<=0)return;
        XSLFAutoShape shape=slide.createAutoShape();
        shape.setAnchor(new Rectangle2D.Double(x,y,w,h));shape.setFillColor(color);shape.setLineColor(color);
    }
    private static void line(XSLFSlide slide,double x1,double y1,double x2,double y2,Color color) {
        XSLFConnectorShape shape=slide.createConnector();
        shape.setAnchor(new Rectangle2D.Double(Math.min(x1,x2),Math.min(y1,y2),Math.max(1,Math.abs(x2-x1)),Math.max(1,Math.abs(y2-y1))));
        shape.setLineColor(color);shape.setLineWidth(1.3);
        if(y2<y1)shape.setFlipVertical(true);
    }
    private static void text(XSLFSlide slide,String value,double x,double y,double w,double h,double pt,Color color,String family,boolean bold) {
        if(w<1 || h<1 || !Double.isFinite(w) || !Double.isFinite(h))
            throw new IllegalArgumentException("Visual text area is invalid");
        double charsPerLine=Math.max(1,(w-4)/(pt*.57));
        double lines=Math.ceil(value.length()/charsPerLine);
        if(lines*pt*1.20>h-3 && pt>=12 && bold)
            throw new IllegalArgumentException("Visual label too long for layout: "+value+"; shorten the label or use fewer nodes");
        XSLFTextBox text=slide.createTextBox();text.setAnchor(new Rectangle2D.Double(x,y,w,h));
        text.setText(value);text.setWordWrap(true);
        for(XSLFTextParagraph p:text.getTextParagraphs())for(XSLFTextRun run:p.getTextRuns()) {
            run.setFontFamily(family);run.setFontSize(pt);run.setFontColor(color);run.setBold(bold);
        }
    }
}
