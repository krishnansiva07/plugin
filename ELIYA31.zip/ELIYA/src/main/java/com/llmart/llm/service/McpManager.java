package com.llmart.llm.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import jakarta.annotation.PreDestroy;
import org.springframework.stereotype.Service;

import java.io.*;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.nio.file.attribute.PosixFilePermission;
import java.time.Duration;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicLong;
import java.util.function.BooleanSupplier;

/**
 * Generic Model Context Protocol client/registry.  The agent core does not know Playwright,
 * Vibium, databases, browsers, or any other MCP-specific semantics.  Enabled servers describe
 * their tools through tools/list and those schemas are surfaced to the model dynamically.
 *
 * Supported transports:
 *  - stdio (the common local MCP transport used by Playwright/Vibium and many developer servers)
 *  - Streamable HTTP for ordinary JSON or SSE responses
 *
 * Configuration is merged from ~/.agents/mcp.json, ELIYA's user-level ~/.eliya/mcp.json,
 * and workspace-local .agents/.opencode MCP files. ELIYA's manual configuration therefore
 * becomes available to the existing agent/tool flow without changing the agent architecture.
 */
@Service
public class McpManager {
    private static final String PROTOCOL_VERSION = "2025-06-18";
    private final ObjectMapper mapper;
    private final HttpClient http;
    private final Map<String, McpSession> sessions = new ConcurrentHashMap<>();
    // Chat tool discovery is cached per workspace root so workspace-local MCP files never leak across projects.
    private final Map<String, CachedChatCatalog> chatCatalogs = new ConcurrentHashMap<>();
    private final Map<String, CompletableFuture<Catalog>> chatCatalogRefreshes = new ConcurrentHashMap<>();
    private final ExecutorService chatDiscoveryExecutor = Executors.newSingleThreadExecutor(task -> {
        Thread thread = new Thread(task, "eliya-mcp-chat-discovery");
        thread.setDaemon(true);
        return thread;
    });
    private record CachedChatCatalog(Catalog catalog, long createdAtNanos) {}

    /** Reuse cached tool discovery, with a bounded wait for slow/unavailable remote servers. */
    public Catalog catalogCachedForChat() { return catalogCachedForChat(null); }

    public Catalog catalogCachedForChat(Path workspaceRoot) {
        if (!globallyEnabled()) return new Catalog(List.of(), Map.of(), List.of("MCP is disabled by the ELIYA master switch"));
        String key = chatCatalogKey(workspaceRoot);
        long now = System.nanoTime();
        CachedChatCatalog cached = chatCatalogs.get(key);
        long ttl = cached != null && cached.catalog().diagnostics().stream().anyMatch(d -> d.contains("unavailable"))
                ? TimeUnit.SECONDS.toNanos(15) : TimeUnit.MINUTES.toNanos(15);
        if (cached != null && now - cached.createdAtNanos() >= 0 && now - cached.createdAtNanos() < ttl)
            return cached.catalog();
        CompletableFuture<Catalog> pending = chatCatalogRefreshes.computeIfAbsent(key, ignored ->
                CompletableFuture.supplyAsync(() -> catalog(workspaceRoot), chatDiscoveryExecutor));
        try {
            Catalog ready = pending.get(Math.max(2_000L, Math.min(60_000L,
                    Long.getLong("eliya.chat.mcp.discoveryTimeoutMillis", 15_000L))), TimeUnit.MILLISECONDS);
            chatCatalogs.put(key, new CachedChatCatalog(ready, System.nanoTime()));
            chatCatalogRefreshes.remove(key, pending);
            return ready;
        } catch (TimeoutException timeout) {
            // Keep the discovery task running: a later request can reuse its result without spawning a new one.
            return new Catalog(List.of(), Map.of(), List.of("MCP discovery is still running. Please retry shortly or check server connectivity."));
        } catch (InterruptedException interrupted) {
            Thread.currentThread().interrupt();
            throw new IllegalStateException("MCP discovery interrupted", interrupted);
        } catch (ExecutionException failed) {
            chatCatalogRefreshes.remove(key, pending);
            return new Catalog(List.of(), Map.of(), List.of("MCP discovery failed: " + safe(failed.getCause() == null ? failed.getMessage() : failed.getCause().getMessage())));
        }
    }

    /** Warm Chat MCP discovery in parallel with other context work, but only when MCP is globally enabled. */
    public void prefetchChatCatalog() { prefetchChatCatalog(null); }

    public void prefetchChatCatalog(Path workspaceRoot) {
        if (!globallyEnabled()) return;
        String key = chatCatalogKey(workspaceRoot);
        CachedChatCatalog cached = chatCatalogs.get(key);
        if (cached != null && System.nanoTime() - cached.createdAtNanos() < TimeUnit.MINUTES.toNanos(15)) return;
        chatCatalogRefreshes.computeIfAbsent(key, ignored ->
                CompletableFuture.supplyAsync(() -> catalog(workspaceRoot), chatDiscoveryExecutor));
    }

    private String chatCatalogKey(Path workspaceRoot) {
        return contextRoot(workspaceRoot).toString();
    }

    public McpManager(ObjectMapper mapper, HttpClient http) {
        this.mapper = mapper;
        this.http = http;
    }

    /**
     * Agent-side lazy discovery. Reading local MCP config files is cheap; connecting/listing tools is deferred until
     * the user's task actually names MCP, a configured server/capability, or a common external integration.
     */
    public Catalog catalogForAgentIfRelevant(Path workspaceRoot, String prompt) {
        if (!globallyEnabled() || prompt == null || prompt.isBlank()) return Catalog.empty();
        List<String> names = configuredServerNames(workspaceRoot);
        if (names.isEmpty()) return Catalog.empty();
        String low = prompt.toLowerCase(Locale.ROOT);
        boolean relevant = low.matches("(?s).*(?:\\bmcp\\b|jira|confluence|gitlab|sonarqube|sonar|atlassian|servicenow|browser automation|browser mcp|browser|website|playwright mcp|playwright|vibium|external tool|external system).*" )
                || low.matches("(?s).*\\b[a-z][a-z0-9]{1,15}-\\d+\\b.*");
        if (!relevant) {
            for (String name : names) {
                String server = name == null ? "" : name.toLowerCase(Locale.ROOT).replace('_',' ').replace('-',' ');
                if (!server.isBlank() && low.contains(server)) { relevant = true; break; }
            }
        }
        return relevant ? catalog(workspaceRoot) : Catalog.empty();
    }

    public Catalog catalog(Path workspaceRoot) {
        if (!globallyEnabled()) return new Catalog(List.of(), Map.of(), List.of("MCP is disabled by the ELIYA master switch"));
        Path root = contextRoot(workspaceRoot);
        LinkedHashMap<String, ServerConfig> configs = discoverConfigs(root);
        List<Map<String,Object>> definitions = new ArrayList<>();
        Map<String, ToolRef> byFunction = new LinkedHashMap<>();
        List<String> diagnostics = new ArrayList<>();
        for (ServerConfig cfg : configs.values()) {
            if (!globallyEnabled()) return new Catalog(List.of(), Map.of(), List.of("MCP was disabled while discovery was running"));
            if (!cfg.enabled()) continue;
            try {
                McpSession session = sessions.computeIfAbsent(sessionKey(root, cfg), k -> createSession(root, cfg));
                if (!globallyEnabled()) { try { session.close(); } catch (Exception ignored) { } return new Catalog(List.of(), Map.of(), List.of("MCP was disabled while discovery was running")); }
                List<McpTool> tools = session.listTools();
                if (!globallyEnabled()) { try { session.close(); } catch (Exception ignored) { } return new Catalog(List.of(), Map.of(), List.of("MCP was disabled while discovery was running")); }
                for (McpTool tool : tools) {
                    String function = uniqueFunctionName(cfg.name(), tool.name(), byFunction.keySet());
                    Map<String,Object> schema = normalizeSchema(tool.inputSchema());
                    String description = "MCP " + cfg.name() + " / " + tool.name() + ": " +
                            (tool.description() == null || tool.description().isBlank() ? "External MCP tool" : tool.description());
                    definitions.add(Map.of("type", "function", "function", Map.of(
                            "name", function,
                            "description", description,
                            "parameters", schema
                    )));
                    byFunction.put(function, new ToolRef(cfg.name(), tool.name(), tool.readOnlyHint()));
                }
                diagnostics.add(cfg.name() + ": connected; tools=" + tools.size());
            } catch (Exception e) {
                diagnostics.add(cfg.name() + ": unavailable: " + safe(e.getMessage()));
            }
        }
        return new Catalog(List.copyOf(definitions), Map.copyOf(byFunction), List.copyOf(diagnostics));
    }

    public String call(Path workspaceRoot, Catalog catalog, String functionName, JsonNode arguments) throws Exception {
        return call(workspaceRoot, catalog, functionName, arguments, () -> false);
    }

    public String call(Path workspaceRoot, Catalog catalog, String functionName, JsonNode arguments, BooleanSupplier cancelled) throws Exception {
        RawCall call = callRaw(workspaceRoot, catalog, functionName, arguments, cancelled);
        return renderToolResult(call.ref(), call.result());
    }

    /**
     * Preserve native MCP image content for the optional Agent Vision model. Base64 payloads never enter
     * Agent text context: only source-tagged visual findings and explicit coverage status are returned.
     * Applicable to any enabled MCP server, including Jira and Confluence, that emits MCP image blocks.
     */
    public String callWithVisualEvidence(Path workspaceRoot, Catalog catalog, String functionName,
                                         JsonNode arguments, BooleanSupplier cancelled,
                                         VisionDocumentService vision, String apiKey,
                                         com.llmart.llm.dto.ChatSettings settings, String objective) throws Exception {
        RawCall call = callRaw(workspaceRoot, catalog, functionName, arguments, cancelled);
        String text = renderToolResult(call.ref(), call.result());
        JsonNode blocks = call.result().path("result").path("content");
        if (!blocks.isArray()) return text;
        int found = 0;
        List<WorkspaceDocumentScanner.Visual> visuals = new ArrayList<>();
        List<String> warnings = new ArrayList<>();
        for (JsonNode part : blocks) {
            if (!"image".equals(part.path("type").asText(""))) continue;
            found++;
            String encoded = part.path("data").asText("");
            // Reject oversized JSON base64 without decoding it first.
            if (encoded.isBlank() || encoded.length() > 14_000_000) {
                warnings.add("MCP image " + found + " unavailable or exceeds 10MB"); continue;
            }
            if (visuals.size() >= 60) { warnings.add("MCP image count exceeds the per-request limit of 60"); continue; }
            try {
                byte[] bytes = Base64.getDecoder().decode(encoded);
                if (bytes.length > 10_000_000) throw new IllegalArgumentException("Exceeds image limit");
                visuals.add(new WorkspaceDocumentScanner.Visual(functionName + ":image-" + found,
                        part.path("mimeType").asText("image/png"), bytes,
                        "Image " + found + " returned by " + call.ref().server() + "/" + call.ref().tool()));
            } catch (Exception failure) { warnings.add("MCP image " + found + ": unreadable image encoding"); }
        }
        if (found == 0) return text;
        WorkspaceDocumentScanner.Scan scan = new WorkspaceDocumentScanner.Scan(text, found, visuals, warnings);
        VisionDocumentService.Analysis analysed = vision.analyse(apiKey, settings, scan,
                "MCP " + call.ref().server() + "/" + call.ref().tool(), objective);
        return text + "\n\nMCP VISUAL EVIDENCE: " + analysed.analysedImages() + "/" + found +
                " images analysed; status=" + analysed.status() + "\n" + analysed.findings() +
                (analysed.warnings().isEmpty() ? "" : "\nIMAGE COVERAGE WARNINGS: " + analysed.warnings());
    }

    private RawCall callRaw(Path workspaceRoot, Catalog catalog, String functionName,
                            JsonNode arguments, BooleanSupplier cancelled) throws Exception {
        if (!globallyEnabled()) throw new IllegalStateException("MCP is disabled in ELIYA Settings");
        Path root = contextRoot(workspaceRoot);
        ToolRef ref = catalog.byFunction().get(functionName);
        if (ref == null) throw new IllegalArgumentException("Unknown MCP tool: " + functionName);
        ServerConfig cfg = discoverConfigs(root).get(ref.server());
        if (cfg == null || !cfg.enabled()) throw new IllegalStateException("MCP server is no longer enabled: " + ref.server());
        McpSession session = sessions.computeIfAbsent(sessionKey(root, cfg), k -> createSession(root, cfg));
        JsonNode result = session.callTool(ref.tool(), arguments == null || !arguments.isObject() ? mapper.createObjectNode() : arguments, cancelled == null ? () -> false : cancelled);
        return new RawCall(ref, result);
    }
    private record RawCall(ToolRef ref, JsonNode result) { }

    public String status(Path workspaceRoot) {
        Catalog catalog = catalog(workspaceRoot);
        if (catalog.diagnostics().isEmpty()) return "[No MCP servers configured]";
        StringBuilder out = new StringBuilder(String.join("\n", catalog.diagnostics()));
        if (!catalog.definitions().isEmpty()) {
            out.append("\nAvailable MCP functions:");
            for (Map<String,Object> def : catalog.definitions()) {
                Object f = def.get("function");
                if (f instanceof Map<?,?> fn) {
                    out.append("\n- ").append(fn.get("name")).append(": ").append(fn.get("description"));
                    Object params = fn.get("parameters");
                    if (params != null) out.append("; parameters=").append(params);
                }
            }
        }
        return out.toString();
    }

    public boolean isMcpTool(Catalog catalog, String name) {
        return catalog != null && catalog.byFunction().containsKey(name);
    }

    public boolean isReadOnly(Catalog catalog, String name) {
        ToolRef ref = catalog == null ? null : catalog.byFunction().get(name);
        return ref != null && ref.readOnlyHint();
    }

    public List<String> configuredServerNames(Path workspaceRoot) {
        if (!globallyEnabled()) return List.of();
        return discoverConfigs(contextRoot(workspaceRoot)).values().stream().filter(ServerConfig::enabled).map(ServerConfig::name).toList();
    }

    /** Global MCP kill switch. When false no config discovery, connection, status ping, tool listing or tool call is allowed. */
    public boolean globallyEnabled() {
        Path file = managedConfigPath();
        if (!Files.isRegularFile(file) || Files.isSymbolicLink(file)) return false;
        try {
            JsonNode root = mapper.readTree(Files.readString(file, StandardCharsets.UTF_8));
            if (root.has("eliyaMcpEnabled")) return root.path("eliyaMcpEnabled").asBoolean(false);
            // Backward compatibility with ELIYA29: the managed server's enabled flag acted as the UI checkbox.
            ServerConfig cfg = readManagedConfig();
            return cfg != null && cfg.enabled();
        } catch (Exception ignored) {
            return false;
        }
    }

    /**
     * Chat mode is intentionally read/analysis oriented. Prefer the MCP annotation when present and
     * conservatively infer common read-only verbs for internal servers that omit annotations.
     */
    public boolean isChatReadOnly(Catalog catalog, String functionName) {
        ToolRef ref = catalog == null ? null : catalog.byFunction().get(functionName);
        return ref != null && isSafeChatTool(ref.tool(), ref.readOnlyHint());
    }

    private boolean isSafeChatTool(String toolName, boolean readOnlyHint) {
        String name = toolName == null ? "" : toolName.trim().toLowerCase(Locale.ROOT);
        if (name.isBlank()) return false;
        // A mislabeled readOnlyHint must never expose an obviously mutating operation in Chat.
        if (name.matches(".*(?:create|update|edit|delete|remove|add_|add-|comment|transition|upload|write|set_|set-|assign|move|close|merge|approve|reject|resolve|execute|trigger).*")) return false;
        if (readOnlyHint) return true;
        return name.matches("^(?:get|list|search|read|find|fetch|query|lookup|view|describe|download|browse|inspect|status|whoami)(?:[_-].*|$)")
                || name.contains("_get_") || name.contains("_list_") || name.contains("_search_")
                || name.contains("_read_") || name.contains("_find_") || name.contains("_fetch_")
                || name.contains("_query_") || name.contains("_lookup_")
                || name.matches(".*(?:[_-](?:get|list|search|read|find|fetch|query|lookup|view|describe|download|browse|inspect|status|whoami))$");
    }

    /**
     * Returns the ELIYA-managed global remote MCP configuration without ever returning secret
     * header values to the browser.  The browser only needs to know which headers are already
     * configured so blank password fields can safely mean "keep existing value".
     */
    public ManualConfigView manualConfiguration() {
        ServerConfig cfg = readManagedConfig();
        boolean master = globallyEnabled();
        if (cfg == null) {
            return new ManualConfigView("itg-devops", master, "remote", "", 100000L, List.of());
        }
        List<String> configured = cfg.headers().entrySet().stream()
                .filter(e -> e.getValue() != null && !e.getValue().isBlank())
                .map(Map.Entry::getKey).sorted(String.CASE_INSENSITIVE_ORDER).toList();
        return new ManualConfigView(cfg.name(), master, "http".equals(cfg.type()) ? "remote" : cfg.type(),
                cfg.url(), cfg.timeoutMillis(), configured);
    }

    /**
     * Saves one user-level remote MCP server. Non-blank incoming headers replace matching values;
     * blank values preserve any already configured secret so opening Settings never erases tokens.
     */
    public synchronized ManualConfigView saveManualConfiguration(String rawName, boolean enabled, String rawUrl,
                                                                   long timeoutMillis, Map<String,String> incomingHeaders) {
        String name = sanitizeId(rawName == null || rawName.isBlank() ? "itg-devops" : rawName);
        if (name.isBlank()) throw new IllegalArgumentException("MCP connection name is required");
        String url = rawUrl == null ? "" : rawUrl.trim();
        if (!url.isBlank()) {
            URI uri;
            try { uri = URI.create(url); } catch (Exception e) { throw new IllegalArgumentException("Invalid MCP server URL"); }
            String scheme = uri.getScheme() == null ? "" : uri.getScheme().toLowerCase(Locale.ROOT);
            if (!Set.of("http", "https").contains(scheme) || uri.getHost() == null)
                throw new IllegalArgumentException("MCP server URL must be an absolute http/https URL");
        }
        long timeout = timeoutMillis <= 0 ? 100000L : Math.min(timeoutMillis, TimeUnit.MINUTES.toMillis(30));

        ServerConfig existing = readManagedConfig();
        boolean hasIncomingHeaders = incomingHeaders != null && incomingHeaders.values().stream()
                .anyMatch(v -> v != null && !v.trim().isBlank());
        if (!enabled && url.isBlank() && !hasIncomingHeaders && existing == null && !Files.isRegularFile(managedConfigPath()))
            return manualConfiguration();

        LinkedHashMap<String,String> headers = new LinkedHashMap<>();
        if (existing != null) headers.putAll(existing.headers());
        if (incomingHeaders != null) {
            incomingHeaders.forEach((key, value) -> {
                String k = normalizeHeaderName(key);
                String v = value == null ? "" : value.trim();
                if (!k.isBlank() && !v.isBlank()) headers.put(k, v);
            });
        }

        ObjectNode root = mapper.createObjectNode();
        root.put("eliyaMcpEnabled", enabled);
        ObjectNode mcp = root.putObject("mcp");
        // The master switch is independent from the saved server configuration. This lets users turn
        // all MCP activity off without losing endpoint/tokens and also allows workspace-only MCP configs.
        if (!url.isBlank() || existing != null || hasIncomingHeaders) {
            ObjectNode node = mcp.putObject(name);
            node.put("type", "remote");
            node.put("url", url.isBlank() && existing != null ? existing.url() : url);
            node.put("enabled", true);
            node.put("timeout", timeout);
            ObjectNode headerNode = node.putObject("headers");
            headers.forEach(headerNode::put);
        }
        writeManagedConfig(root);
        resetSessions();
        return manualConfiguration();
    }

    public synchronized void clearManualConfiguration() {
        Path file = managedConfigPath();
        try { Files.deleteIfExists(file); }
        catch (IOException e) { throw new IllegalStateException("Unable to remove MCP configuration: " + safe(e.getMessage()), e); }
        resetSessions();
    }

    public ConnectionTest testManualConfiguration() {
        if (!globallyEnabled()) return new ConnectionTest(false, "", 0, List.of(), 0, List.of(), "MCP is disabled by the ELIYA master switch");
        ServerConfig cfg = readManagedConfig();
        if (cfg == null) return new ConnectionTest(false, "", 0, List.of(), 0, List.of(),
                "MCP is enabled, but no manual remote server is saved. Workspace/user MCP files can still be used during Chat or Agent requests.");
        McpSession session = null;
        try {
            session = createSession(Path.of(System.getProperty("user.home", ".")).toAbsolutePath().normalize(), cfg);
            List<McpTool> tools = session.listTools();
            List<String> names = tools.stream().map(McpTool::name).filter(n -> n != null && !n.isBlank()).sorted().toList();
            List<String> chatReadTools = tools.stream().filter(t -> isSafeChatTool(t.name(), t.readOnlyHint()))
                    .map(McpTool::name).sorted().toList();
            return new ConnectionTest(true, cfg.name(), names.size(), names, chatReadTools.size(), chatReadTools,
                    chatReadTools.isEmpty() ? "Server connected, but it exposes no safe read/search tools to Chat"
                            : "Connected; Chat read/search tools discovered");
        } catch (Exception e) {
            return new ConnectionTest(false, cfg.name(), 0, List.of(), 0, List.of(), safe(redactSecrets(e.getMessage(), cfg.headers())));
        } finally {
            if (session != null) try { session.close(); } catch (Exception ignored) { }
        }
    }

    private void resetSessions() {
        chatCatalogs.clear();
        chatCatalogRefreshes.values().forEach(future -> future.cancel(true));
        chatCatalogRefreshes.clear();
        for (McpSession session : sessions.values()) {
            try { session.close(); } catch (Exception ignored) { }
        }
        sessions.clear();
    }

    private Path managedConfigPath() {
        Path home = Path.of(System.getProperty("user.home", ".")).toAbsolutePath().normalize();
        return home.resolve(".eliya").resolve("mcp.json");
    }

    private ServerConfig readManagedConfig() {
        Path file = managedConfigPath();
        if (!Files.isRegularFile(file) || Files.isSymbolicLink(file)) return null;
        try {
            JsonNode root = mapper.readTree(Files.readString(file, StandardCharsets.UTF_8));
            JsonNode servers = root.path("mcp");
            if (!servers.isObject()) servers = root.path("servers");
            if (!servers.isObject()) return null;
            Iterator<Map.Entry<String,JsonNode>> fields = servers.fields();
            if (!fields.hasNext()) return null;
            Map.Entry<String,JsonNode> entry = fields.next();
            return parseConfig(entry.getKey(), entry.getValue());
        } catch (Exception e) {
            throw new IllegalStateException("Unable to read ELIYA MCP configuration: " + safe(e.getMessage()), e);
        }
    }

    private void writeManagedConfig(JsonNode root) {
        Path file = managedConfigPath();
        Path dir = file.getParent();
        try {
            Files.createDirectories(dir);
            Path temp = Files.createTempFile(dir, "mcp-", ".json.tmp");
            Files.writeString(temp, mapper.writerWithDefaultPrettyPrinter().writeValueAsString(root) + System.lineSeparator(),
                    StandardCharsets.UTF_8, StandardOpenOption.WRITE, StandardOpenOption.TRUNCATE_EXISTING);
            try {
                Files.setPosixFilePermissions(temp, EnumSet.of(PosixFilePermission.OWNER_READ, PosixFilePermission.OWNER_WRITE));
            } catch (UnsupportedOperationException ignored) { }
            try {
                Files.move(temp, file, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (AtomicMoveNotSupportedException e) {
                Files.move(temp, file, StandardCopyOption.REPLACE_EXISTING);
            }
            try {
                Files.setPosixFilePermissions(file, EnumSet.of(PosixFilePermission.OWNER_READ, PosixFilePermission.OWNER_WRITE));
            } catch (UnsupportedOperationException ignored) { }
        } catch (IOException e) {
            throw new IllegalStateException("Unable to save MCP configuration: " + safe(e.getMessage()), e);
        }
    }

    @PreDestroy
    public void shutdown() {
        chatDiscoveryExecutor.shutdownNow();
        chatCatalogRefreshes.values().forEach(future -> future.cancel(true));
        chatCatalogRefreshes.clear();
        chatCatalogs.clear();
        for (McpSession session : sessions.values()) {
            try { session.close(); } catch (Exception ignored) { }
        }
        sessions.clear();
    }

    private McpSession createSession(Path root, ServerConfig cfg) {
        try {
            return switch (cfg.type()) {
                case "http", "streamable-http", "streamable_http" -> new HttpMcpSession(cfg);
                default -> new StdioMcpSession(root, cfg);
            };
        } catch (Exception e) {
            throw new IllegalStateException("Unable to start MCP server " + cfg.name() + ": " + safe(e.getMessage()), e);
        }
    }

    private Path contextRoot(Path workspaceRoot) {
        if (workspaceRoot != null) return workspaceRoot.toAbsolutePath().normalize();
        return Path.of(System.getProperty("user.home", ".")).toAbsolutePath().normalize();
    }

    private LinkedHashMap<String, ServerConfig> discoverConfigs(Path workspaceRoot) {
        LinkedHashMap<String, ServerConfig> merged = new LinkedHashMap<>();
        if (!globallyEnabled()) return merged;
        Path home = Path.of(System.getProperty("user.home", ".")).toAbsolutePath().normalize();
        for (Path file : List.of(home.resolve(".agents/mcp.json"), home.resolve(".eliya/mcp.json"), workspaceRoot.resolve(".agents/mcp.json"), workspaceRoot.resolve(".opencode/mcp.json"))) {
            if (!Files.isRegularFile(file) || Files.isSymbolicLink(file)) continue;
            try {
                JsonNode root = mapper.readTree(Files.readString(file, StandardCharsets.UTF_8));
                JsonNode servers = root.path("servers");
                if (!servers.isObject()) servers = root.path("mcp");
                if (!servers.isObject()) continue;
                Iterator<Map.Entry<String,JsonNode>> fields = servers.fields();
                while (fields.hasNext()) {
                    Map.Entry<String,JsonNode> entry = fields.next();
                    ServerConfig cfg = parseConfig(entry.getKey(), entry.getValue());
                    if (cfg != null) merged.put(cfg.name(), cfg);
                }
            } catch (Exception ignored) { }
        }
        return merged;
    }

    private ServerConfig parseConfig(String rawName, JsonNode node) {
        String name = sanitizeId(rawName);
        if (name.isBlank() || node == null || !node.isObject()) return null;
        boolean enabled = !node.has("enabled") || node.path("enabled").asBoolean(true);
        String type = node.path("type").asText("stdio").trim().toLowerCase(Locale.ROOT);
        if ("local".equals(type)) type = "stdio";
        if ("remote".equals(type)) type = "http";
        String command = node.path("command").isTextual() ? node.path("command").asText("") : "";
        List<String> args = new ArrayList<>();
        if (node.path("command").isArray()) {
            JsonNode arr = node.path("command");
            if (!arr.isEmpty()) command = arr.get(0).asText("");
            for (int i=1;i<arr.size();i++) args.add(arr.get(i).asText(""));
        }
        if (node.path("args").isArray()) for (JsonNode a : node.path("args")) args.add(a.asText(""));
        Map<String,String> env = new LinkedHashMap<>();
        if (node.path("env").isObject()) node.path("env").fields().forEachRemaining(e -> env.put(e.getKey(), e.getValue().asText("")));
        Map<String,String> headers = new LinkedHashMap<>();
        if (node.path("headers").isObject()) node.path("headers").fields().forEachRemaining(e -> {
            String key = normalizeHeaderName(e.getKey());
            String value = e.getValue().asText("").trim();
            if (!key.isBlank() && !value.isBlank()) headers.put(key, value);
        });
        String url = node.path("url").asText("").trim();
        String cwd = node.path("cwd").asText("").trim();
        long timeoutMillis;
        if (node.has("timeout")) timeoutMillis = Math.max(0L, node.path("timeout").asLong(0L));
        else if (node.has("timeoutMillis")) timeoutMillis = Math.max(0L, node.path("timeoutMillis").asLong(0L));
        else timeoutMillis = TimeUnit.SECONDS.toMillis(Math.max(0L, node.path("timeoutSeconds").asLong(0L)));
        return new ServerConfig(name, enabled, type, command, List.copyOf(args), Map.copyOf(env), Map.copyOf(headers), url, cwd, timeoutMillis);
    }

    private Map<String,Object> normalizeSchema(JsonNode inputSchema) {
        try {
            JsonNode schema = inputSchema == null || !inputSchema.isObject() ? mapper.readTree("{\"type\":\"object\",\"properties\":{}}") : inputSchema;
            @SuppressWarnings("unchecked") Map<String,Object> map = mapper.convertValue(schema, Map.class);
            LinkedHashMap<String,Object> result = new LinkedHashMap<>(map == null ? Map.of() : map);
            result.putIfAbsent("type", "object");
            result.putIfAbsent("properties", Map.of());
            return result;
        } catch (Exception e) {
            return Map.of("type","object","properties",Map.of());
        }
    }

    private String renderToolResult(ToolRef ref, JsonNode response) {
        if (response == null || response.isNull()) return "MCP " + ref.server() + "/" + ref.tool() + " returned no content";
        JsonNode result = response.path("result");
        if (response.has("error")) return "MCP PROTOCOL ERROR " + ref.server() + "/" + ref.tool() + ": " + response.path("error").toString();
        boolean isError = result.path("isError").asBoolean(false);
        StringBuilder out = new StringBuilder();
        out.append("mcpServer=").append(ref.server()).append("; tool=").append(ref.tool()).append("; isError=").append(isError).append('\n');
        JsonNode content = result.path("content");
        if (content.isArray()) {
            for (JsonNode item : content) {
                String type = item.path("type").asText("");
                if ("text".equals(type)) out.append(item.path("text").asText("")).append('\n');
                else if ("image".equals(type)) out.append("[MCP image content: " )
                        .append(item.path("mimeType").asText("image/unknown"))
                        .append("; base64 data withheld from text context]\n");
                else {
                    String raw = item.toString();
                    if (raw.length() > 1_000_000) raw = raw.substring(0, 1_000_000) +
                            " [MCP CONTENT BLOCK EXCEEDED 1,000,000 CHAR SAFETY CEILING]";
                    out.append(raw).append('\n');
                }
            }
        }
        if (result.has("structuredContent")) {
            // Preserve complete structured content for Chat's short-lived MCP evidence store. The previous 20k hard
            // clip silently discarded middle sections of large Confluence pages before Chat could inspect them. Keep
            // a high defensive ceiling only for pathological provider responses; ordinary large pages remain intact.
            String structured = result.path("structuredContent").toString();
            if (structured.length() > 1_000_000) structured = structured.substring(0, 1_000_000) +
                    " [MCP STRUCTURED CONTENT EXCEEDED 1,000,000 CHAR SAFETY CEILING]";
            out.append("structuredContent=").append(structured).append('\n');
        }
        if (out.toString().trim().equals("mcpServer=" + ref.server() + "; tool=" + ref.tool() + "; isError=" + isError)) out.append(result.toString());
        return out.toString().stripTrailing();
    }

    private String sessionKey(Path root, ServerConfig cfg) {
        return root.toAbsolutePath().normalize() + "|" + cfg.name() + "|" + cfg.type() + "|" + cfg.command() + "|" + cfg.url() + "|" + cfg.timeoutMillis() + "|" + Integer.toHexString(cfg.headers().hashCode());
    }

    private String uniqueFunctionName(String server, String tool, Set<String> used) {
        String base = "mcp__" + sanitizeFunction(server) + "__" + sanitizeFunction(tool);
        if (base.length() > 60) base = base.substring(0, 48) + "__" + Integer.toHexString(base.hashCode());
        String value = base;
        int i = 2;
        while (used.contains(value)) value = (base.length() > 56 ? base.substring(0,56) : base) + "_" + i++;
        return value;
    }

    private String sanitizeFunction(String value) {
        String s = value == null ? "tool" : value.replaceAll("[^A-Za-z0-9_-]", "_");
        return s.isBlank() ? "tool" : s;
    }

    private String sanitizeId(String value) {
        String s = value == null ? "" : value.trim().replaceAll("[^A-Za-z0-9._-]", "_");
        return s.length() > 100 ? s.substring(0,100) : s;
    }

    private String normalizeHeaderName(String value) {
        String s = value == null ? "" : value.trim();
        if (!s.matches("[!#$%&'*+.^_`|~0-9A-Za-z-]{1,128}")) return "";
        return s;
    }

    private String redactSecrets(String value, Map<String,String> headers) {
        String out = value == null ? "" : value;
        if (headers != null) {
            for (String secret : headers.values()) {
                if (secret != null && !secret.isBlank()) out = out.replace(secret, "***");
            }
        }
        return out;
    }

    private String safe(String value) {
        if (value == null || value.isBlank()) return "unknown error";
        String s = value.replace('\n',' ').replace('\r',' ').replaceAll("\\s+", " ").trim();
        return s.length() > 800 ? s.substring(0,800) : s;
    }

    public record Catalog(List<Map<String,Object>> definitions, Map<String,ToolRef> byFunction, List<String> diagnostics) {
        public static Catalog empty() { return new Catalog(List.of(), Map.of(), List.of()); }
    }
    public record ToolRef(String server, String tool, boolean readOnlyHint) {}
    public record ManualConfigView(String name, boolean enabled, String type, String url, long timeoutMillis,
                                   List<String> configuredHeaders) {}
    public record ConnectionTest(boolean connected, String name, int toolCount, List<String> tools,
                                 int chatReadToolCount, List<String> chatReadTools, String message) {}
    private record McpTool(String name, String description, JsonNode inputSchema, boolean readOnlyHint) {}
    private record ServerConfig(String name, boolean enabled, String type, String command, List<String> args,
                                Map<String,String> env, Map<String,String> headers, String url, String cwd, long timeoutMillis) {}

    private interface McpSession extends AutoCloseable {
        List<McpTool> listTools() throws Exception;
        JsonNode callTool(String name, JsonNode arguments, BooleanSupplier cancelled) throws Exception;
        @Override void close();
    }

    private final class StdioMcpSession implements McpSession {
        private final ServerConfig cfg;
        private final Process process;
        private final BufferedWriter stdin;
        private final AtomicLong ids = new AtomicLong(1);
        private final Map<Long, CompletableFuture<JsonNode>> pending = new ConcurrentHashMap<>();
        private volatile List<McpTool> cachedTools;

        StdioMcpSession(Path workspaceRoot, ServerConfig cfg) throws Exception {
            this.cfg = cfg;
            if (cfg.command() == null || cfg.command().isBlank()) throw new IllegalArgumentException("stdio MCP command is required");
            List<String> command = new ArrayList<>(); command.add(cfg.command()); command.addAll(cfg.args());
            ProcessBuilder pb = new ProcessBuilder(command);
            Path cwd = cfg.cwd().isBlank() ? workspaceRoot : workspaceRoot.resolve(cfg.cwd()).normalize();
            if (!cwd.startsWith(workspaceRoot) || !Files.isDirectory(cwd)) throw new SecurityException("Invalid MCP cwd: " + cfg.cwd());
            pb.directory(cwd.toFile());
            pb.environment().putAll(cfg.env());
            process = pb.start();
            stdin = new BufferedWriter(new OutputStreamWriter(process.getOutputStream(), StandardCharsets.UTF_8));
            Thread stdoutThread = new Thread(() -> readStdout(process.getInputStream()), "mcp-stdout-" + cfg.name());
            stdoutThread.setDaemon(true);
            stdoutThread.start();
            Thread stderrThread = new Thread(() -> drain(process.getErrorStream()), "mcp-stderr-" + cfg.name());
            stderrThread.setDaemon(true);
            stderrThread.start();
            initialize();
        }

        private void initialize() throws Exception {
            ObjectNode params = mapper.createObjectNode();
            params.put("protocolVersion", PROTOCOL_VERSION);
            params.set("capabilities", mapper.createObjectNode());
            params.set("clientInfo", mapper.valueToTree(Map.of("name","advanced-ai-workbench","version","rolling")));
            request("initialize", params);
            notify("notifications/initialized", mapper.createObjectNode());
        }

        @Override public List<McpTool> listTools() throws Exception {
            if (cachedTools != null) return cachedTools;
            List<McpTool> all = new ArrayList<>();
            String cursor = null;
            do {
                ObjectNode params = mapper.createObjectNode(); if (cursor != null) params.put("cursor", cursor);
                JsonNode response = request("tools/list", params);
                JsonNode result = response.path("result");
                for (JsonNode t : result.path("tools")) all.add(parseTool(t));
                cursor = result.path("nextCursor").asText("").trim(); if (cursor.isBlank()) cursor = null;
            } while (cursor != null);
            cachedTools = List.copyOf(all);
            return cachedTools;
        }

        @Override public JsonNode callTool(String name, JsonNode arguments, BooleanSupplier cancelled) throws Exception {
            ObjectNode params = mapper.createObjectNode(); params.put("name", name); params.set("arguments", arguments);
            return request("tools/call", params, cancelled);
        }

        private JsonNode request(String method, JsonNode params) throws Exception {
            return request(method, params, () -> false);
        }

        private JsonNode request(String method, JsonNode params, BooleanSupplier cancelled) throws Exception {
            if (!process.isAlive()) throw new IllegalStateException("MCP process exited with code " + process.exitValue());
            long id = ids.getAndIncrement();
            CompletableFuture<JsonNode> future = new CompletableFuture<>(); pending.put(id, future);
            ObjectNode msg = mapper.createObjectNode(); msg.put("jsonrpc","2.0"); msg.put("id",id); msg.put("method",method); msg.set("params",params);
            send(msg);
            long deadline = cfg.timeoutMillis() > 0 ? System.nanoTime() + TimeUnit.MILLISECONDS.toNanos(cfg.timeoutMillis()) : Long.MAX_VALUE;
            try {
                while (true) {
                    if (cancelled != null && cancelled.getAsBoolean()) {
                        future.cancel(true);
                        throw new AgentCancelledException("Agent run was cancelled during MCP operation");
                    }
                    if (!process.isAlive()) throw new IllegalStateException("MCP process exited with code " + process.exitValue());
                    if (System.nanoTime() >= deadline) throw new TimeoutException("MCP request timed out: " + method);
                    try { return future.get(200, TimeUnit.MILLISECONDS); } catch (TimeoutException ignored) { }
                }
            } finally { pending.remove(id); }
        }

        private void notify(String method, JsonNode params) throws Exception {
            ObjectNode msg = mapper.createObjectNode(); msg.put("jsonrpc","2.0"); msg.put("method",method); msg.set("params",params); send(msg);
        }

        private synchronized void send(JsonNode node) throws Exception { stdin.write(mapper.writeValueAsString(node)); stdin.newLine(); stdin.flush(); }

        private void readStdout(InputStream in) {
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    try {
                        JsonNode json = mapper.readTree(line);
                        if (json.has("id")) {
                            long id = json.path("id").asLong(Long.MIN_VALUE);
                            CompletableFuture<JsonNode> future = pending.get(id);
                            if (future != null) future.complete(json);
                        } else if ("notifications/tools/list_changed".equals(json.path("method").asText(""))) {
                            cachedTools = null;
                            chatCatalogs.clear();
                            chatCatalogRefreshes.clear();
                        }
                    } catch (Exception ignored) { }
                }
            } catch (Exception ignored) { }
            IllegalStateException failure = new IllegalStateException("MCP server stopped: " + cfg.name());
            pending.values().forEach(f -> f.completeExceptionally(failure));
        }

        private void drain(InputStream in) { try { in.transferTo(OutputStream.nullOutputStream()); } catch (Exception ignored) { } }

        @Override public void close() {
            try { stdin.close(); } catch (Exception ignored) { }
            if (process.isAlive()) { process.destroy(); if (process.isAlive()) process.destroyForcibly(); }
        }
    }

    private final class HttpMcpSession implements McpSession {
        private final ServerConfig cfg;
        private String sessionId;
        private volatile List<McpTool> cachedTools;
        private final AtomicLong ids = new AtomicLong(1);
        HttpMcpSession(ServerConfig cfg) throws Exception {
            this.cfg = cfg;
            if (cfg.url() == null || cfg.url().isBlank()) throw new IllegalArgumentException("HTTP MCP url is required");
            ObjectNode params = mapper.createObjectNode(); params.put("protocolVersion", PROTOCOL_VERSION);
            params.set("capabilities", mapper.createObjectNode());
            params.set("clientInfo", mapper.valueToTree(Map.of("name","advanced-ai-workbench","version","rolling")));
            post(requestNode("initialize", params, ids.getAndIncrement()), "initialize");
            post(notificationNode("notifications/initialized", mapper.createObjectNode()), "notifications/initialized");
        }
        @Override public List<McpTool> listTools() throws Exception {
            if (cachedTools != null) return cachedTools;
            List<McpTool> all = new ArrayList<>(); String cursor = null;
            do {
                ObjectNode p = mapper.createObjectNode(); if (cursor != null) p.put("cursor", cursor);
                JsonNode response = post(requestNode("tools/list", p, ids.getAndIncrement()), "tools/list");
                JsonNode result = response.path("result");
                for (JsonNode t : result.path("tools")) all.add(parseTool(t));
                cursor = result.path("nextCursor").asText("").trim(); if (cursor.isBlank()) cursor = null;
            } while (cursor != null);
            cachedTools = List.copyOf(all); return cachedTools;
        }
        @Override public JsonNode callTool(String name, JsonNode arguments, BooleanSupplier cancelled) throws Exception {
            ObjectNode p = mapper.createObjectNode(); p.put("name",name); p.set("arguments",arguments);
            return post(requestNode("tools/call",p,ids.getAndIncrement()), "tools/call", cancelled);
        }
        private JsonNode post(JsonNode body, String method) throws Exception {
            return post(body, method, () -> false);
        }
        private JsonNode post(JsonNode body, String method, BooleanSupplier cancelled) throws Exception {
            HttpRequest.Builder b = HttpRequest.newBuilder(URI.create(cfg.url())).header("Content-Type","application/json").header("Accept","application/json, text/event-stream").header("MCP-Protocol-Version",PROTOCOL_VERSION).header("Mcp-Method", method);
            Set<String> reserved = Set.of("content-type", "accept", "mcp-protocol-version", "mcp-session-id", "mcp-method");
            for (Map.Entry<String,String> entry : cfg.headers().entrySet()) {
                if (!reserved.contains(entry.getKey().toLowerCase(Locale.ROOT))) b.header(entry.getKey(), entry.getValue());
            }
            if (sessionId != null && !sessionId.isBlank()) b.header("Mcp-Session-Id", sessionId);
            if (cfg.timeoutMillis() > 0) b.timeout(Duration.ofMillis(cfg.timeoutMillis()));
            CompletableFuture<HttpResponse<String>> future = http.sendAsync(b.POST(HttpRequest.BodyPublishers.ofString(mapper.writeValueAsString(body))).build(), HttpResponse.BodyHandlers.ofString());
            HttpResponse<String> response;
            while (true) {
                if (cancelled != null && cancelled.getAsBoolean()) { future.cancel(true); throw new AgentCancelledException("Agent run was cancelled during MCP HTTP operation"); }
                try { response = future.get(200, TimeUnit.MILLISECONDS); break; }
                catch (TimeoutException ignored) { }
                catch (ExecutionException e) { Throwable cause=e.getCause(); if(cause instanceof Exception ex) throw ex; throw e; }
            }
            response.headers().firstValue("Mcp-Session-Id").ifPresent(v -> sessionId = v);
            if (response.statusCode() == 202 || response.statusCode() == 204) return mapper.createObjectNode();
            if (response.statusCode() < 200 || response.statusCode() >= 300) throw new IllegalStateException("HTTP MCP " + response.statusCode() + ": " + safe(redactSecrets(response.body(), cfg.headers())));
            String text = response.body() == null ? "" : response.body().trim();
            if (text.startsWith("data:" ) || text.contains("\ndata:")) {
                for (String line : text.split("\\R")) if (line.startsWith("data:")) { String data=line.substring(5).trim(); if (!data.isBlank()) return mapper.readTree(data); }
            }
            return text.isBlank() ? mapper.createObjectNode() : mapper.readTree(text);
        }
        @Override public void close() { }
    }

    private McpTool parseTool(JsonNode t) {
        String name = t.path("name").asText("").trim();
        String description = t.path("description").asText("");
        JsonNode schema = t.path("inputSchema");
        boolean readOnly = t.path("annotations").path("readOnlyHint").asBoolean(false);
        return new McpTool(name, description, schema, readOnly);
    }

    private ObjectNode requestNode(String method, JsonNode params, long id) {
        ObjectNode n=mapper.createObjectNode(); n.put("jsonrpc","2.0"); n.put("id",id); n.put("method",method); n.set("params",params); return n;
    }
    private ObjectNode notificationNode(String method, JsonNode params) {
        ObjectNode n=mapper.createObjectNode(); n.put("jsonrpc","2.0"); n.put("method",method); n.set("params",params); return n;
    }
}
