package com.llmart.llm.service;

import com.sun.source.tree.*;
import com.sun.source.util.JavacTask;
import com.sun.source.util.TreePathScanner;
import javax.tools.*;
import java.io.IOException;
import java.net.URI;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Bounded read-only structural discovery. Java uses the JDK compiler's real syntax tree;
 * JavaScript/TypeScript and Gherkin use conservative declarations/import extractors.
 * No code is compiled, executed or written to the user's workspace.
 */
final class WorkspaceCodeIntelligence {
    private static final int MAX_SYMBOLS = 240, MAX_REFERENCES = 180;
    private static final Pattern DECLARATION = Pattern.compile(
            "(?m)^\\s*(?:(?:export|default|declare|async|abstract|public|private|protected|static|readonly)\\s+)*" +
            "(class|interface|type|enum|function|const|let|var|describe|test|it)\\s*" +
            "(?:\\(\\s*['\\\"]([^'\\\"]+)['\\\"]|([A-Za-z_$][\\w$]*))");
    private static final Pattern TS_METHOD = Pattern.compile("(?m)^\\s*(?:(?:public|private|protected|static|async|override|readonly|get|set)\\s+)*([A-Za-z_$][\\w$]*)\\s*\\([^\\n)]{0,350}\\)\\s*(?::[^\\n{=]+)?\\s*[{]");
    private static final Pattern TS_IMPORT = Pattern.compile(
            "(?m)\\b(?:import\\s+(?:type\\s+)?(?:[^;\\n]*?\\s+from\\s+)?|require\\s*\\()\\s*['\\\"]([^'\\\"]+)['\\\"]");
    private static final Pattern JAVA_FALLBACK = Pattern.compile(
            "(?m)\\b(class|interface|enum|record)\\s+([A-Za-z_$][\\w$]*)|" +
            "\\b(?:public|private|protected)\\s+(?:static\\s+)?[\\w<>\\[\\], ?]+\\s+([a-zA-Z_$][\\w$]*)\\s*\\(");
    private static final Pattern STEP = Pattern.compile("(?mi)^\\s*(Given|When|Then|And|But)\\s+(.+)$");
    private static final Pattern STEP_ANNOTATION = Pattern.compile("@(?:Given|When|Then|And|But)\\s*\\(\\s*\"([^\"]+)\"");
    private WorkspaceCodeIntelligence() { }

    record Structure(Map<String,Integer> symbols, Set<String> references, Set<String> steps) {
        static final Structure EMPTY = new Structure(Map.of(), Set.of(), Set.of());
        Structure {
            symbols = Map.copyOf(symbols);
            references = Set.copyOf(references);
            steps = Set.copyOf(steps);
        }
    }

    static Structure analyse(String path, String source) {
        if (source == null || source.isBlank() || path == null) return Structure.EMPTY;
        String lower = path.toLowerCase(Locale.ROOT);
        if (lower.endsWith(".java")) {
            try { return javaAst(path, source); }
            catch (Throwable unavailable) { return javaFallback(source); }
        }
        if (lower.endsWith(".ts") || lower.endsWith(".tsx") || lower.endsWith(".js") || lower.endsWith(".jsx") ||
                lower.endsWith(".mjs") || lower.endsWith(".cjs")) return javascript(source);
        if (lower.endsWith(".feature")) {
            LinkedHashSet<String> steps = new LinkedHashSet<>();
            Matcher match = STEP.matcher(source);
            while (match.find() && steps.size() < MAX_REFERENCES)
                steps.add(normalizeStep(match.group(2)));
            return new Structure(Map.of(), Set.of(), steps);
        }
        return Structure.EMPTY;
    }

    private static Structure javaAst(String path, String source) throws IOException {
        JavaCompiler compiler = ToolProvider.getSystemJavaCompiler();
        if (compiler == null) return javaFallback(source);
        JavaFileObject unit = new SimpleJavaFileObject(URI.create("string:///" + safeName(path) + ".java"), JavaFileObject.Kind.SOURCE) {
            @Override public CharSequence getCharContent(boolean ignoreEncodingErrors) { return source; }
        };
        LinkedHashMap<String,Integer> symbols = new LinkedHashMap<>();
        LinkedHashSet<String> refs = new LinkedHashSet<>(), steps = new LinkedHashSet<>();
        try (StandardJavaFileManager manager = compiler.getStandardFileManager(null, Locale.ROOT, null)) {
            JavacTask task = (JavacTask) compiler.getTask(null, manager, diagnostic -> { },
                    List.of("-proc:none"), null, List.of(unit));
            for (CompilationUnitTree compilation : task.parse()) {
                compilation.getImports().forEach(imp -> add(refs, imp.getQualifiedIdentifier().toString()));
                new TreePathScanner<Void,Void>() {
                    private void symbol(String name, String kind, Tree tree) {
                        if (name == null || name.isBlank() || symbols.size() >= MAX_SYMBOLS) return;
                        long location = taskLine(compilation, tree, task);
                        symbols.putIfAbsent(kind + ":" + name, (int) location);
                    }
                    @Override public Void visitClass(ClassTree node, Void ignored) {
                        symbol(node.getSimpleName().toString(), node.getKind().name().toLowerCase(Locale.ROOT), node);
                        if (node.getExtendsClause() != null) add(refs, node.getExtendsClause().toString());
                        for (Tree impl : node.getImplementsClause()) add(refs, impl.toString());
                        return super.visitClass(node, ignored);
                    }
                    @Override public Void visitMethod(MethodTree node, Void ignored) {
                        symbol(node.getName().toString(), "method", node);
                        for (AnnotationTree annotation : node.getModifiers().getAnnotations()) {
                            String name = annotation.getAnnotationType().toString().replaceAll("^.*\\.", "");
                            if (Set.of("Given","When","Then","And","But").contains(name)) {
                                String literal = annotation.getArguments().isEmpty() ? "" : annotation.getArguments().get(0).toString();
                                if (!literal.isBlank()) add(steps, normalizeStep(literal.replaceAll("^\"|\"$", "")));
                            }
                        }
                        return super.visitMethod(node, ignored);
                    }
                    @Override public Void visitMethodInvocation(MethodInvocationTree node, Void ignored) {
                        if (node.getMethodSelect() instanceof MemberSelectTree sel) add(refs, sel.getExpression().toString());
                        return super.visitMethodInvocation(node, ignored);
                    }
                    @Override public Void visitNewClass(NewClassTree node, Void ignored) {
                        add(refs, node.getIdentifier().toString());
                        return super.visitNewClass(node, ignored);
                    }
                }.scan(compilation, null);
            }
        }
        if (symbols.isEmpty()) return javaFallback(source);
        return new Structure(symbols, refs, steps);
    }

    private static long taskLine(CompilationUnitTree cu, Tree tree, JavacTask task) {
        try {
            long offset = com.sun.source.util.Trees.instance(task).getSourcePositions().getStartPosition(cu, tree);
            return offset < 0 || cu.getLineMap() == null ? 0 : cu.getLineMap().getLineNumber(offset);
        } catch (Exception ignored) { return 0; }
    }

    private static Structure javaFallback(String source) {
        LinkedHashMap<String,Integer> symbols = new LinkedHashMap<>();
        Matcher match = JAVA_FALLBACK.matcher(source);
        while (match.find() && symbols.size() < MAX_SYMBOLS)
            symbols.putIfAbsent((match.group(1) == null ? "method:" + match.group(3) :
                    match.group(1) + ":" + match.group(2)), line(source, match.start()));
        LinkedHashSet<String> refs = new LinkedHashSet<>(), steps = new LinkedHashSet<>();
        Matcher imports = Pattern.compile("(?m)^\\s*import\\s+(?:static\\s+)?([\\w.*]+)\\s*;").matcher(source);
        while (imports.find() && refs.size() < MAX_REFERENCES) add(refs, imports.group(1));
        Matcher annotations = STEP_ANNOTATION.matcher(source);
        while (annotations.find() && steps.size() < MAX_REFERENCES) add(steps, normalizeStep(annotations.group(1)));
        return new Structure(symbols, refs, steps);
    }

    private static Structure javascript(String source) {
        LinkedHashMap<String,Integer> symbols = new LinkedHashMap<>();
        LinkedHashSet<String> refs = new LinkedHashSet<>();
        Matcher declared = DECLARATION.matcher(source);
        while (declared.find() && symbols.size() < MAX_SYMBOLS) {
            String name = declared.group(3) == null ? declared.group(2) : declared.group(3);
            if (name != null) symbols.putIfAbsent(declared.group(1) + ":" + name, line(source, declared.start()));
        }
        Matcher methods = TS_METHOD.matcher(source);
        while (methods.find() && symbols.size() < MAX_SYMBOLS) {
            String name = methods.group(1);
            if (!Set.of("if","for","while","switch","catch","test","describe","function").contains(name))
                symbols.putIfAbsent("method:" + name, line(source, methods.start()));
        }
        Matcher imports = TS_IMPORT.matcher(source);
        while (imports.find() && refs.size() < MAX_REFERENCES) add(refs, imports.group(1));
        return new Structure(symbols, refs, Set.of());
    }

    private static String normalizeStep(String value) {
        return value.strip().toLowerCase(Locale.ROOT).replaceAll("[\\\"'{}]", "").replaceAll("\\s+", " ");
    }
    private static int line(String text, int offset) {
        int lines = 1;
        for (int i = 0; i < offset && i < text.length(); i++) if (text.charAt(i) == '\n') lines++;
        return lines;
    }
    private static String safeName(String path) { return path.replaceAll("[^a-zA-Z0-9_$]", "_"); }
    private static void add(Set<String> values, String value) {
        if (value != null && !value.isBlank() && values.size() < MAX_REFERENCES && value.length() < 240)
            values.add(value.strip());
    }
}
