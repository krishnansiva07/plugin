package com.llmart.llm.service;

import org.springframework.stereotype.Service;

import java.net.URI;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Confluence-portable formatting adapted from Formatter19's safe semantic clipboard approach.
 * Deterministic on purpose: unlike documentation authoring, formatting never invents or rewrites facts.
 * All untrusted input is escaped; only our own small native-HTML vocabulary is emitted.
 */
@Service
public class ConfluenceComposerService {
    public static final int MAX_CONTENT_CHARS = 300_000;
    private static final Pattern BULLET = Pattern.compile("^\\s*[-*+•]\\s+(.+)$");
    private static final Pattern NUMBERED = Pattern.compile("^\\s*\\d+[.)]\\s+(.+)$");
    private static final Pattern FIELD = Pattern.compile("^([\\p{L}][\\p{L}0-9 /_().-]{0,44}):\\s*(\\S.*)$");
    private static final Pattern TITLE = Pattern.compile("^(#{1,4})\\s+(.+?)\\s*$");
    private static final Pattern HR = Pattern.compile("^\\s*(?:---+|\\*\\*\\*+)\\s*$");
    private static final Pattern TABLE_SEPARATOR = Pattern.compile("^\\s*\\|?\\s*:?-{3,}:?\\s*(?:\\|\\s*:?-{3,}:?\\s*)+\\|?$");
    private static final Set<String> THEMES = Set.of("bnp-green", "corporate-blue", "minimal");

    public record Result(String html, String plainText, String theme, int sections,
                         int tables, int codeBlocks, List<String> warnings) { }

    public Result format(String source, String chosenTheme) {
        if (source == null || source.isBlank()) throw new IllegalArgumentException("Paste content or provide a Markdown document to format");
        if (source.length() > MAX_CONTENT_CHARS) throw new IllegalArgumentException("Content exceeds 300,000 characters. Split it into Confluence pages/sections.");
        String theme = chosenTheme == null || chosenTheme.isBlank() ? "bnp-green" : chosenTheme.trim().toLowerCase(Locale.ROOT);
        if (!THEMES.contains(theme)) throw new IllegalArgumentException("Invalid Confluence theme: " + theme);
        String accent = "bnp-green".equals(theme) ? "#006b3b" : "corporate-blue".equals(theme) ? "#205b9f" : "#333333";
        String[] lines = source.replace("\r\n", "\n").replace('\r', '\n').split("\n", -1);
        StringBuilder body = new StringBuilder(Math.min(MAX_CONTENT_CHARS * 2, source.length() * 2));
        int firstContent = 0;
        while (firstContent < lines.length && lines[firstContent].isBlank()) firstContent++;
        List<String> warnings = new ArrayList<>();
        int sections = 0, tables = 0, codeBlocks = 0;
        boolean fenced = false, inList = false;
        String listKind = "";
        StringBuilder code = new StringBuilder();
        for (int i = 0; i < lines.length; i++) {
            String line = lines[i];
            String trimmed = line.trim();
            if (trimmed.startsWith("```")) {
                if (!fenced) {
                    if (inList) { body.append("</").append(listKind).append('>'); inList = false; }
                    fenced = true; code.setLength(0);
                } else {
                    body.append("<pre><code>").append(escape(code.toString())).append("</code></pre>");
                    codeBlocks++; fenced = false;
                }
                continue;
            }
            if (fenced) { if (!code.isEmpty()) code.append('\n'); code.append(line); continue; }
            if (trimmed.isEmpty()) {
                if (inList) { body.append("</").append(listKind).append('>'); inList = false; }
                continue;
            }
            Matcher title = TITLE.matcher(trimmed);
            Matcher bullet = BULLET.matcher(line);
            Matcher numbered = NUMBERED.matcher(line);
            boolean list = bullet.matches() || numbered.matches();
            if (list) {
                String requestedKind = bullet.matches() ? "ul" : "ol";
                if (!inList || !listKind.equals(requestedKind)) {
                    if (inList) body.append("</").append(listKind).append('>');
                    listKind = requestedKind; body.append('<').append(listKind).append('>'); inList = true;
                }
                body.append("<li>").append(inline(bullet.matches() ? bullet.group(1) : numbered.group(1))).append("</li>");
                continue;
            }
            if (inList) { body.append("</").append(listKind).append('>'); inList = false; }
            if (title.matches()) {
                int n = title.group(1).length();
                body.append("<h").append(n).append(" style=\"color:").append(accent).append("\">")
                    .append(inline(title.group(2))).append("</h").append(n).append('>');
                sections++; continue;
            }
            // Unstructured pasted reports: recognize an opening title without changing its words.
            if (i == firstContent && trimmed.length() <= 90 && !trimmed.contains(":") &&
                    !trimmed.contains("<") && !trimmed.startsWith("|") && !trimmed.endsWith(".") &&
                    !trimmed.startsWith("[") && !trimmed.startsWith("-") && i + 1 < lines.length) {
                body.append("<h1 style=\"color:").append(accent).append("\">").append(inline(trimmed)).append("</h1>");
                sections++; continue;
            }
            // A group of key:value lines becomes an editable native Confluence table.
            Matcher firstField = FIELD.matcher(trimmed);
            if (firstField.matches() && i + 1 < lines.length && FIELD.matcher(lines[i+1].trim()).matches()) {
                body.append("<table><tbody>");
                do {
                    Matcher field = FIELD.matcher(lines[i].trim());
                    if (!field.matches()) break;
                    body.append("<tr><td><strong>").append(inline(field.group(1))).append(":</strong></td><td>")
                            .append(inline(field.group(2))).append("</td></tr>");
                    i++;
                } while (i < lines.length && FIELD.matcher(lines[i].trim()).matches());
                i--; body.append("</tbody></table>"); tables++; continue;
            }
            if (trimmed.endsWith(":") && trimmed.length() <= 70 && !trimmed.contains("<")) {
                body.append("<h2 style=\"color:").append(accent).append("\">").append(inline(trimmed)).append("</h2>");
                sections++; continue;
            }
            if (HR.matcher(trimmed).matches()) { body.append("<hr>"); continue; }
            if (trimmed.startsWith("> ")) {
                body.append("<blockquote>").append(inline(trimmed.substring(2))).append("</blockquote>"); continue;
            }
            if (isTableRow(trimmed) && i + 1 < lines.length && TABLE_SEPARATOR.matcher(lines[i + 1]).matches()) {
                List<String> headers = cells(trimmed);
                if (headers.size() >= 2 && headers.size() <= 30) {
                    body.append("<table><thead><tr>");
                    for (String h : headers) body.append("<th style=\"background-color:").append(accent)
                            .append(";color:#ffffff\">").append(inline(h)).append("</th>");
                    body.append("</tr></thead><tbody>"); i++; tables++;
                    while (i + 1 < lines.length && isTableRow(lines[i + 1]) && !TABLE_SEPARATOR.matcher(lines[i + 1]).matches()) {
                        List<String> values = cells(lines[++i]); body.append("<tr>");
                        for (int j = 0; j < Math.max(headers.size(), values.size()); j++) body.append("<td>")
                                .append(inline(j < values.size() ? values.get(j) : "")).append("</td>");
                        body.append("</tr>");
                        if (values.size() > headers.size()) warnings.add("Table row has more columns than header; extra cells retained without corresponding header");
                    }
                    body.append("</tbody></table>"); continue;
                }
            }
            // Preserve explicit source line boundaries; never paraphrase or silently combine unrelated lines.
            body.append("<p>").append(inline(line)).append("</p>");
        }
        if (inList) body.append("</").append(listKind).append('>');
        if (fenced) {
            body.append("<pre><code>").append(escape(code.toString())).append("</code></pre>");
            warnings.add("Unclosed fenced code block was rendered as code"); codeBlocks++;
        }
        if (source.contains("<")) warnings.add("Raw HTML was treated as text (not executed); copy-safe output uses supported native Confluence structures");
        return new Result(body.toString(), source, theme, sections, tables, codeBlocks, List.copyOf(warnings));
    }

    private static boolean isTableRow(String s) {
        // Require a | separator, including header rows with optional outer pipes.
        return s != null && s.indexOf('|') >= 0 && cells(s).size() >= 2;
    }

    private static List<String> cells(String line) {
        String input = line.trim();
        if (input.startsWith("|")) input = input.substring(1);
        if (input.endsWith("|")) input = input.substring(0, input.length()-1);
        return Arrays.stream(input.split("(?<!\\\\)\\|", -1)).map(s -> s.trim().replace("\\\\|", "|")).toList();
    }

    /** Minimal inline Markdown subset; all literal text, including HTML-like text, is escaped. */
    private static String inline(String s) {
        if (s == null) return "";
        StringBuilder out = new StringBuilder();
        for (int i = 0; i < s.length();) {
            if (s.charAt(i) == '`') {
                int end = s.indexOf('`', i + 1);
                if (end > i + 1) {
                    out.append("<code>").append(escape(s.substring(i+1,end))).append("</code>"); i = end+1; continue;
                }
            }
            if (s.startsWith("**",i)) {
                int end = s.indexOf("**", i+2);
                if (end > i+2) { out.append("<strong>").append(inline(s.substring(i+2,end))).append("</strong>"); i = end+2; continue; }
            }
            if (s.charAt(i) == '*' && !s.startsWith("**",i)) {
                int end = s.indexOf('*',i+1);
                if (end > i+1) { out.append("<em>").append(inline(s.substring(i+1,end))).append("</em>"); i = end+1; continue; }
            }
            if (s.charAt(i) == '[') {
                int bracket = s.indexOf("](",i+1);
                int end = bracket < 0 ? -1 : s.indexOf(')',bracket+2);
                if (bracket > i+1 && end > bracket+2) {
                    String url = s.substring(bracket+2,end).trim();
                    if (safeLink(url)) {
                        out.append("<a href=\"").append(escape(url)).append("\">")
                           .append(inline(s.substring(i+1,bracket))).append("</a>"); i=end+1; continue;
                    }
                }
            }
            out.append(escape(String.valueOf(s.charAt(i++))));
        }
        return out.toString();
    }

    private static boolean safeLink(String url) {
        try {
            URI uri = URI.create(url);
            return ("https".equalsIgnoreCase(uri.getScheme()) || "http".equalsIgnoreCase(uri.getScheme()))
                    && uri.getHost() != null && !url.contains("\r") && !url.contains("\n");
        } catch (IllegalArgumentException ex) { return false; }
    }
    private static String escape(String s) {
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
                .replace("\"", "&quot;").replace("'", "&#39;");
    }
}
