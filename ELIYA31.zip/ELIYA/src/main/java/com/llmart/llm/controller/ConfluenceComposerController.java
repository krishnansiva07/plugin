package com.llmart.llm.controller;

import com.llmart.llm.service.ConfluenceComposerService;
import com.llmart.llm.service.ProjectService;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.Locale;

/** Pure formatting and explicit read-only Markdown import. No MCP/Confluence publication. */
@RestController
@RequestMapping("/api/confluence")
public class ConfluenceComposerController {
    public record FormatRequest(String content, String theme) { }
    private final ConfluenceComposerService composer;
    private final ProjectService projects;

    public ConfluenceComposerController(ConfluenceComposerService composer, ProjectService projects) {
        this.composer = composer; this.projects = projects;
    }

    @PostMapping("/format")
    public ConfluenceComposerService.Result format(@RequestBody FormatRequest request) {
        if (request == null) throw new IllegalArgumentException("Request body required");
        return composer.format(request.content(), request.theme());
    }

    @GetMapping("/workspace-source")
    public FormatRequest workspaceSource(@RequestParam String projectId, @RequestParam String path) throws IOException {
        var project = projects.require(projectId);
        if (!project.hasLocalPath()) throw new IllegalArgumentException("Select a local workspace first");
        if (path == null || path.isBlank() || path.length() > 1200) throw new IllegalArgumentException("Relative Markdown path required");
        Path relative = Path.of(path);
        if (relative.isAbsolute() || path.contains(":") || path.contains("\\")) throw new SecurityException("Use a relative workspace file path");
        String ext = path.toLowerCase(Locale.ROOT);
        if (!(ext.endsWith(".md") || ext.endsWith(".txt"))) throw new IllegalArgumentException("Only .md and .txt can be loaded into the Composer");
        Path root = Path.of(project.getLocalPath()).toRealPath();
        Path file = root.resolve(relative).normalize();
        if (!file.startsWith(root)) throw new SecurityException("Path escapes active workspace");
        Path cursor = root;
        for (Path part : root.relativize(file)) {
            cursor = cursor.resolve(part);
            if (Files.isSymbolicLink(cursor)) throw new SecurityException("Symbolic links are not permitted");
        }
        if (!Files.isRegularFile(file, LinkOption.NOFOLLOW_LINKS)) throw new NoSuchFileException(path);
        if (Files.size(file) > ConfluenceComposerService.MAX_CONTENT_CHARS * 3L) throw new IllegalArgumentException("Document too large; split it first");
        return new FormatRequest(Files.readString(file, StandardCharsets.UTF_8), "bnp-green");
    }
}
