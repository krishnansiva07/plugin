package com.llmart.llm.service;

import org.springframework.stereotype.Service;

import java.io.*;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.*;

/**
 * Run-start transactional baseline for managed local workspaces. Exact byte copies (including binary files)
 * are stored OUTSIDE the project before execution. An approval refusal/timeout restores this baseline.
 * External MCP operations, uncontrolled processes and other writers to the same workspace cannot be made
 * transactional by Java alone; do not describe this as OS-enforced sandboxing.
 */
@Service
public class ProtectedRunSnapshotService {
    private static final long MAX_BYTES = Long.getLong("eliya.rollback.maxBytes", 2L * 1024 * 1024 * 1024);
    private static final long MAX_FILES = Long.getLong("eliya.rollback.maxFiles", 100_000L);
    private static final Set<String> SKIP = Set.of(".git", ".svn", "node_modules", "target", "build", "dist", "out",
            ".gradle", ".idea", ".next", "coverage", ".venv", "venv", ".cache", "vendor", "bin", "obj");
    private final Path home;
    public ProtectedRunSnapshotService() {
        this(Path.of(System.getProperty("app.data-dir", "./data"), "protection-snapshots"));
    }
    ProtectedRunSnapshotService(Path home) { this.home = home.toAbsolutePath().normalize(); }

    public String begin(String runId, AgentWorkspaceService.Workspace workspace) throws IOException {
        if (workspace == null) return "No local workspace";
        Path location = directory(runId);
        if (Files.exists(location)) throw new IOException("A protected snapshot already exists for this run");
        LinkedHashSet<Path> roots = new LinkedHashSet<>();
        roots.add(workspace.root().toRealPath());
        for (PromptResourceResolver.ResolvedResource resource : workspace.resources().values()) {
            if (!resource.writable()) continue;
            Path path = resource.root().toRealPath();
            if (Files.isDirectory(path) && roots.stream().noneMatch(existing -> path.startsWith(existing))) roots.add(path);
        }
        // Never let the protected snapshot sit INSIDE any writable workspace. Otherwise the
        // workspace walk can recursively snapshot its own snapshot, or rollback can erase its
        // sole recovery baseline. Resolve symlinks before checking this invariant.
        Files.createDirectories(home);
        Path realSnapshotHome = home.toRealPath();
        for (Path root : roots) {
            if (realSnapshotHome.startsWith(root))
                throw new IOException("Protected snapshot storage is inside a writable workspace (" + root +
                        "). Set app.data-dir to an independent directory outside all writable roots.");
        }
        // A snapshot stored inside the selected workspace would recursively snapshot itself.
        // Fail closed before creating anything rather than risk an incomplete rollback baseline.
        for (Path root : roots) if (home.startsWith(root) || root.startsWith(home))
            throw new IOException("Protected snapshot storage and workspace may not overlap: " + root);
        Files.createDirectories(location);
        Properties props = new Properties();
        long[] totals = {0, 0};
        int scope = 0;
        try {
            for (Path root : roots) {
                final int idx = scope++;
                final Path data = location.resolve("root-" + idx);
                props.setProperty("root." + idx, root.toString());
                Files.createDirectories(data);
                Files.walkFileTree(root, new SimpleFileVisitor<>() {
                    @Override public FileVisitResult preVisitDirectory(Path dir, BasicFileAttributes attrs) throws IOException {
                        if (!dir.equals(root) && SKIP.contains(dir.getFileName().toString().toLowerCase(Locale.ROOT)))
                            return FileVisitResult.SKIP_SUBTREE;
                        if (Files.isSymbolicLink(dir)) return FileVisitResult.SKIP_SUBTREE;
                        Files.createDirectories(data.resolve(root.relativize(dir)));
                        return FileVisitResult.CONTINUE;
                    }
                    @Override public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) throws IOException {
                        if (!Files.isRegularFile(file) || Files.isSymbolicLink(file)) return FileVisitResult.CONTINUE;
                        totals[0]++; totals[1] += attrs.size();
                        if (totals[0] > MAX_FILES || totals[1] > MAX_BYTES)
                            throw new IOException("Protected snapshot exceeds limit of " + MAX_FILES +
                                    " files / " + MAX_BYTES + " bytes. Narrow the workspace or configure eliya.rollback.maxBytes/maxFiles.");
                        Path copy = data.resolve(root.relativize(file));
                        Files.createDirectories(copy.getParent());
                        Files.copy(file, copy, StandardCopyOption.COPY_ATTRIBUTES);
                        return FileVisitResult.CONTINUE;
                    }
                });
            }
            props.setProperty("scopeCount", Integer.toString(scope));
            props.setProperty("fileCount", Long.toString(totals[0]));
            props.setProperty("totalBytes", Long.toString(totals[1]));
            try (OutputStream out = Files.newOutputStream(location.resolve("manifest.properties"),
                    StandardOpenOption.CREATE_NEW)) { props.store(out, "ELIYA protected-run snapshot"); }
            return "Protected baseline prepared before execution (files=" + totals[0] + ", bytes=" + totals[1] + ")";
        } catch (Exception failure) {
            destroy(location);
            if (failure instanceof IOException io) throw io;
            throw new IOException("Protected snapshot preparation failed", failure);
        }
    }

    /** Restore tracked source files exactly, remove files added under protected source paths and delete empty dirs. */
    public String rollback(String runId) throws IOException {
        Path location = directory(runId);
        Properties props = new Properties();
        try (InputStream in = Files.newInputStream(location.resolve("manifest.properties"))) { props.load(in); }
        int roots = Integer.parseInt(props.getProperty("scopeCount", "0"));
        int[] restored = {0}, removed = {0};
        List<String> errors = new ArrayList<>();
        for (int i = 0; i < roots; i++) {
            Path root = Path.of(props.getProperty("root." + i));
            Path backup = location.resolve("root-" + i);
            if (!Files.isDirectory(root) || Files.isSymbolicLink(root) || !Files.isDirectory(backup)) {
                errors.add("Missing root or snapshot " + i); continue;
            }
            Set<String> captured = new HashSet<>();
            try (var all = Files.walk(backup)) {
                for (Path stored : all.filter(Files::isRegularFile).toList())
                    captured.add(backup.relativize(stored).toString());
            }
            try {
                Files.walkFileTree(root, new SimpleFileVisitor<>() {
                    @Override public FileVisitResult preVisitDirectory(Path dir, BasicFileAttributes attrs) {
                        if (!dir.equals(root) && SKIP.contains(dir.getFileName().toString().toLowerCase(Locale.ROOT)))
                            return FileVisitResult.SKIP_SUBTREE;
                        return Files.isSymbolicLink(dir) ? FileVisitResult.SKIP_SUBTREE : FileVisitResult.CONTINUE;
                    }
                    @Override public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) throws IOException {
                        if (!Files.isRegularFile(file) || Files.isSymbolicLink(file)) return FileVisitResult.CONTINUE;
                        if (!captured.contains(root.relativize(file).toString())) {
                            Files.delete(file); removed[0]++;
                        }
                        return FileVisitResult.CONTINUE;
                    }
                    @Override public FileVisitResult postVisitDirectory(Path dir, IOException exc) throws IOException {
                        if (!dir.equals(root) && !SKIP.contains(dir.getFileName().toString().toLowerCase(Locale.ROOT))) {
                            try (var contents = Files.list(dir)) {
                                if (contents.findAny().isEmpty()) Files.delete(dir);
                            }
                        }
                        return FileVisitResult.CONTINUE;
                    }
                });
            } catch (Exception failure) { errors.add("Unable to remove generated files from " + root + ": " + failure.getMessage()); }
            try (var all = Files.walk(backup)) {
                for (Path stored : all.filter(Files::isRegularFile).toList()) {
                    try {
                        Path target = root.resolve(backup.relativize(stored)).normalize();
                        if (!target.startsWith(root) || Files.isSymbolicLink(target) ||
                                hasSymlinkAncestor(root, target.getParent())) throw new IOException("Unsafe restore target or symlink ancestor");
                        Files.createDirectories(target.getParent());
                        Files.copy(stored, target, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.COPY_ATTRIBUTES);
                        restored[0]++;
                    } catch (Exception failure) { errors.add("Failed to restore " + stored + ": " + failure.getMessage()); }
                }
            }
        }
        if (!errors.isEmpty()) throw new IOException("INCOMPLETE ROLLBACK; snapshot retained for manual recovery: " +
                String.join(" | ", errors.stream().limit(5).toList()));
        destroy(location);
        return "Rollback completed: restored " + restored[0] + " files; removed " + removed[0] + " new files";
    }

    private static boolean hasSymlinkAncestor(Path root, Path parent) {
        if (!parent.startsWith(root) || Files.isSymbolicLink(root)) return true;
        Path current = root;
        for (Path segment : root.relativize(parent)) {
            current = current.resolve(segment);
            if (Files.isSymbolicLink(current)) return true;
        }
        return false;
    }

    /** Successful runs can dispose of their run-start snapshot; failed rollbacks retain it for recovery. */
    public void discard(String runId) throws IOException { destroy(directory(runId)); }

    Path snapshotDirectory(String runId) { return directory(runId); }

    private Path directory(String runId) {
        if (runId == null || !runId.matches("[A-Za-z0-9_-]{1,100}"))
            throw new IllegalArgumentException("Invalid protected run identifier");
        return home.resolve(runId).normalize();
    }
    private static void destroy(Path folder) throws IOException {
        if (!Files.exists(folder)) return;
        try (var files = Files.walk(folder)) {
            for (Path path : files.sorted(Comparator.reverseOrder()).toList()) Files.deleteIfExists(path);
        }
    }
}
