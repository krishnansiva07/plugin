package com.llmart.llm.service;

import org.springframework.stereotype.Service;

import java.io.*;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.security.MessageDigest;
import java.time.Instant;
import java.util.*;

/**
 * Durable, task-scoped undo. The run-start baseline lives outside the workspace. On successful
 * completion we seal only the differences from that baseline, along with each file's final hash.
 * Rollback validates ALL files before writing any of them; subsequent edits are never overwritten.
 * External MCP effects and locations excluded from the baseline are outside this transaction.
 */
@Service
public class AgentTaskRollbackService {
    private static final String MISSING = "<absent>";
    private static final Set<String> SKIP = Set.of(".git", ".svn", "node_modules", "target", "build", "dist", "out",
            ".gradle", ".idea", ".next", "coverage", ".venv", "venv", ".cache", "vendor", "bin", "obj");
    private final ProtectedRunSnapshotService snapshots;
    private final WorkspaceRetrievalIndexService index;
    private final AgentRunService runs;

    public AgentTaskRollbackService(ProtectedRunSnapshotService snapshots, WorkspaceRetrievalIndexService index,
                                    AgentRunService runs) {
        this.snapshots = snapshots;
        this.index = index;
        this.runs = runs;
    }

    /** Store the exact task diff, not an instruction to the LLM to reconstruct old content. */
    public synchronized int seal(String runId) throws IOException {
        Path folder = snapshots.snapshotDirectory(runId);
        Properties baseline = properties(folder.resolve("manifest.properties"));
        if (Files.exists(folder.resolve("changes.properties"))) throw new IOException("Run is already sealed");
        Properties changes = new Properties();
        int count = 0;
        for (int i = 0; i < Integer.parseInt(baseline.getProperty("scopeCount", "0")); i++) {
            Path root = Path.of(baseline.getProperty("root." + i)).toAbsolutePath().normalize();
            Path copy = folder.resolve("root-" + i);
            if (!Files.isDirectory(root) || !Files.isDirectory(copy) || Files.isSymbolicLink(root))
                throw new IOException("Workspace root is unavailable; cannot seal rollback: " + root);
            Set<Path> paths = new TreeSet<>();
            collect(copy, paths);
            collect(root, paths);
            // collect() puts relative filenames into the same set, across both trees.
            for (Path relative : paths) {
                Path original = copy.resolve(relative);
                Path current = root.resolve(relative);
                String before = hash(original);
                String after = hash(current);
                if (Objects.equals(before, after)) continue;
                changes.setProperty("change." + count + ".root", Integer.toString(i));
                changes.setProperty("change." + count + ".path", relative.toString());
                changes.setProperty("change." + count + ".before", before);
                changes.setProperty("change." + count + ".after", after);
                // Capture readable, bounded details at seal time. The historical report must not
                // change if a developer subsequently edits or rolls back this workspace.
                try { describeChange(changes, "change." + count + ".", original, current, before, after); }
                catch (Exception ignored) { changes.setProperty("change." + count + ".detail", "Content changed; line-level preview unavailable"); }
                count++;
            }
        }
        changes.setProperty("count", Integer.toString(count));
        changes.setProperty("sealedAt", Instant.now().toString());
        atomicProperties(folder.resolve("changes.properties"), changes);
        pruneOldSnapshots(folder);
        return count;
    }

    private static final long MAX_REPORT_TEXT_BYTES = 256 * 1024L;

    private static void describeChange(Properties props, String prefix, Path original, Path current,
                                       String before, String after) throws IOException {
        String action = MISSING.equals(before) ? "created" : MISSING.equals(after) ? "deleted" : "modified";
        long oldSize = MISSING.equals(before) ? 0 : Files.size(original);
        long newSize = MISSING.equals(after) ? 0 : Files.size(current);
        props.setProperty(prefix + "beforeBytes", Long.toString(oldSize));
        props.setProperty(prefix + "afterBytes", Long.toString(newSize));
        if (oldSize > MAX_REPORT_TEXT_BYTES || newSize > MAX_REPORT_TEXT_BYTES) {
            props.setProperty(prefix + "detail", "Changed " + action + " file (" + oldSize + " → " + newSize + " bytes); too large for inline diff");
            return;
        }
        String oldText = MISSING.equals(before) ? "" : reportText(original);
        String newText = MISSING.equals(after) ? "" : reportText(current);
        if (oldText == null || newText == null) {
            props.setProperty(prefix + "detail", "Changed " + action + " binary/non-UTF-8 file (" + oldSize + " → " + newSize + " bytes)");
            return;
        }
        String[] oldLines = oldText.lines().toArray(String[]::new);
        String[] newLines = newText.lines().toArray(String[]::new);
        int head = 0;
        while (head < oldLines.length && head < newLines.length && oldLines[head].equals(newLines[head])) head++;
        int oldEnd = oldLines.length, newEnd = newLines.length;
        while (oldEnd > head && newEnd > head && oldLines[oldEnd - 1].equals(newLines[newEnd - 1])) { oldEnd--; newEnd--; }
        int oldSpan = oldEnd - head, newSpan = newEnd - head;
        List<String> removedPreview = new ArrayList<>(), addedPreview = new ArrayList<>();
        int removed = 0, added = 0;
        boolean exact = (long) oldSpan * newSpan <= 120_000;
        if (exact) {
            // Exact line counts for ordinary edits: unchanged lines between two changes
            // must not be incorrectly reported as deleted and re-added.
            int[][] lcs = new int[oldSpan + 1][newSpan + 1];
            for (int i = oldSpan - 1; i >= 0; i--) for (int j = newSpan - 1; j >= 0; j--)
                lcs[i][j] = oldLines[head + i].equals(newLines[head + j])
                        ? 1 + lcs[i + 1][j + 1] : Math.max(lcs[i + 1][j], lcs[i][j + 1]);
            int i = 0, j = 0;
            while (i < oldSpan || j < newSpan) {
                if (i < oldSpan && j < newSpan && oldLines[head + i].equals(newLines[head + j])) { i++; j++; }
                else if (j < newSpan && (i >= oldSpan || lcs[i][j + 1] >= lcs[i + 1][j])) {
                    if (addedPreview.size() < 7) addedPreview.add("+ " + clipReportLine(newLines[head + j]));
                    added++; j++;
                } else {
                    if (removedPreview.size() < 7) removedPreview.add("- " + clipReportLine(oldLines[head + i]));
                    removed++; i++;
                }
            }
        } else {
            // Bound quadratic work on big files to avoid slowing down task finalization.
            removed = oldSpan; added = newSpan;
            for (int i = head; i < Math.min(oldEnd, head + 7); i++) removedPreview.add("- " + clipReportLine(oldLines[i]));
            for (int i = head; i < Math.min(newEnd, head + 7); i++) addedPreview.add("+ " + clipReportLine(newLines[i]));
        }
        props.setProperty(prefix + "addedLines", Integer.toString(added));
        props.setProperty(prefix + "removedLines", Integer.toString(removed));
        props.setProperty(prefix + "detail", action + (exact ? " · +" : " · changed region +") + added + "/-" + removed +
                " lines · " + oldSize + " → " + newSize + " bytes");
        StringBuilder excerpt = new StringBuilder();
        for (String line : removedPreview) excerpt.append(line).append('\n');
        if (removed > removedPreview.size()) excerpt.append("… ").append(removed - removedPreview.size()).append(" additional removed/span lines\n");
        for (String line : addedPreview) excerpt.append(line).append('\n');
        if (added > addedPreview.size()) excerpt.append("… ").append(added - addedPreview.size()).append(" additional added/span lines\n");
        props.setProperty(prefix + "excerpt", excerpt.toString().stripTrailing());
    }

    private static String clipReportLine(String line) {
        return line.length() <= 240 ? line : line.substring(0, 240) + "…";
    }

    private static String reportText(Path path) throws IOException {
        byte[] bytes = Files.readAllBytes(path);
        for (byte value : bytes) if (value == 0) return null;
        try {
            return java.nio.charset.StandardCharsets.UTF_8.newDecoder()
                    .onMalformedInput(java.nio.charset.CodingErrorAction.REPORT)
                    .onUnmappableCharacter(java.nio.charset.CodingErrorAction.REPORT)
                    .decode(java.nio.ByteBuffer.wrap(bytes)).toString();
        } catch (java.nio.charset.CharacterCodingException notText) { return null; }
    }

    /** A historical report sourced from the run journal and sealed workspace differences. */
    public synchronized Map<String, Object> completionReport(String runId) {
        AgentRunService.AgentRun run = runs.require(runId);
        Map<String,Object> snapshot = run.snapshot();
        Map<String,Object> report = new LinkedHashMap<>();
        report.put("runId", runId);
        report.put("status", snapshot.get("status"));
        report.put("objective", snapshot.get("objective"));
        report.put("createdAt", snapshot.get("createdAt"));
        report.put("finishedAt", snapshot.getOrDefault("finishedAt", ""));
        report.put("steps", snapshot.get("plan"));
        report.put("verification", snapshot.getOrDefault("lastVerification", ""));
        report.put("verificationPassed", snapshot.getOrDefault("lastVerificationSuccessful", false));
        report.put("rolledBack", false);
        report.put("filesVerified", false);
        report.put("files", List.of());
        report.put("created", 0);
        report.put("modified", 0);
        report.put("deleted", 0);
        try {
            Path folder = snapshots.snapshotDirectory(runId);
            Path manifestFile = folder.resolve("changes.properties");
            if (Files.isRegularFile(manifestFile)) {
                Properties manifest = properties(manifestFile);
                Properties baseline = properties(folder.resolve("manifest.properties"));
                List<Map<String,Object>> files = new ArrayList<>();
                int created = 0, modified = 0, deleted = 0;
                int count = Math.max(0, Math.min(200_000, Integer.parseInt(manifest.getProperty("count", "0"))));
                for (int i = 0; i < count; i++) {
                    String prefix = "change." + i + ".";
                    int scope = Integer.parseInt(manifest.getProperty(prefix + "root", "-1"));
                    if (scope < 0 || scope >= Integer.parseInt(baseline.getProperty("scopeCount", "0"))) continue;
                    Path root = Path.of(baseline.getProperty("root." + scope)).toAbsolutePath().normalize();
                    Path relative = Path.of(manifest.getProperty(prefix + "path", "")).normalize();
                    if (relative.isAbsolute() || relative.toString().isBlank() || relative.startsWith("..")) continue;
                    String before = manifest.getProperty(prefix + "before", MISSING);
                    String after = manifest.getProperty(prefix + "after", MISSING);
                    String action = MISSING.equals(before) ? "created" : MISSING.equals(after) ? "deleted" : "modified";
                    switch (action) { case "created" -> created++; case "deleted" -> deleted++; default -> modified++; }
                    Map<String,Object> entry = new LinkedHashMap<>();
                    entry.put("name", relative.getFileName().toString());
                    entry.put("relativePath", relative.toString());
                    entry.put("path", root.resolve(relative).toString());
                    entry.put("action", action);
                    entry.put("detail", manifest.getProperty(prefix + "detail", "File content changed (older run; inline diff unavailable)"));
                    entry.put("excerpt", manifest.getProperty(prefix + "excerpt", ""));
                    files.add(entry);
                }
                report.put("files", files);
                report.put("created", created);
                report.put("modified", modified);
                report.put("deleted", deleted);
                report.put("filesVerified", true);
                report.put("rolledBack", Files.exists(folder.resolve("rolled-back.properties")));
            }
        } catch (Exception e) {
            report.put("fileReportWarning", "Saved file details are unavailable: " + e.getMessage());
        }
        if (!Boolean.TRUE.equals(report.get("filesVerified")) && !"completed".equals(snapshot.get("status"))) {
            report.put("fileReportWarning", "This run did not finish successfully; file changes are not a verified task diff.");
        } else if (!Boolean.TRUE.equals(report.get("filesVerified"))) {
            report.put("fileReportWarning", "A sealed local workspace change record is unavailable for this run (or no local workspace was used).");
        }
        return report;
    }

    public boolean available(String runId) {
        try {
            Path folder = snapshots.snapshotDirectory(runId);
            return Files.isRegularFile(folder.resolve("changes.properties")) &&
                    !Files.exists(folder.resolve("rolled-back.properties"));
        } catch (Exception e) { return false; }
    }

    public synchronized Map<String, Object> preview(String runId) throws IOException {
        Changes state = load(runId);
        int created = 0, modified = 0, deleted = 0;
        List<String> conflicts = new ArrayList<>();
        List<Map<String,String>> items = new ArrayList<>();
        for (ChangedFile file : state.files()) {
            String action = MISSING.equals(file.before()) ? "created" : MISSING.equals(file.after()) ? "deleted" : "modified";
            if (action.equals("created")) created++;
            else if (action.equals("deleted")) deleted++;
            else modified++;
            String conflict = validate(file);
            if (conflict != null) conflicts.add(conflict);
            items.add(Map.of("path", file.root().resolve(file.relative()).toString(), "action", action));
        }
        Map<String,Object> result = new LinkedHashMap<>();
        result.put("runId", runId); result.put("available", !Files.exists(state.folder().resolve("rolled-back.properties")));
        result.put("created", created); result.put("modified", modified); result.put("deleted", deleted);
        result.put("conflicts", conflicts); result.put("files", items);
        return result;
    }

    public synchronized Map<String,Object> rollback(String runId, String conversationId, String projectId) throws IOException {
        AgentRunService.AgentRun target = runs.require(runId);
        if (!Objects.equals(conversationId, target.conversationId()) ||
                !Objects.equals(projectId, target.projectId()) || !"completed".equals(target.snapshot().get("status")))
            throw new IOException("Rollback is only available for a completed task in the current conversation and workspace");
        Changes state = load(runId);
        if (Files.exists(state.folder().resolve("rolled-back.properties")))
            throw new IOException("This operation has already been rolled back");
        List<String> conflicts = new ArrayList<>();
        for (ChangedFile file : state.files()) {
            String conflict = validate(file);
            if (conflict != null) conflicts.add(conflict);
        }
        if (!conflicts.isEmpty()) throw new IOException("Rollback refused because files changed after the task: " +
                String.join("; ", conflicts.stream().limit(8).toList()));
        // Validate all inputs before the first write and keep the original task baseline after undo.
        // Backup each affected current file to make a failed midway restore recoverable.
        Path safety = state.folder().resolve("rollback-safety");
        for (ChangedFile file : state.files()) {
            Path current = file.root().resolve(file.relative());
            if (!Files.isRegularFile(current, LinkOption.NOFOLLOW_LINKS)) continue;
            Path copy = safety.resolve(file.backup().getFileName()).resolve(file.relative());
            Files.createDirectories(copy.getParent());
            Files.copy(current, copy, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.COPY_ATTRIBUTES);
        }
        int restored = 0, removed = 0;
        List<ChangedFile> processed = new ArrayList<>();
        try {
            for (ChangedFile file : state.files()) {
                Path current = file.root().resolve(file.relative()).normalize();
                Path original = file.backup().resolve(file.relative()).normalize();
                processed.add(file);
                if (MISSING.equals(file.before())) {
                    Files.deleteIfExists(current);
                    removeEmptyParents(current.getParent(), file.root());
                    removed++;
                } else {
                    Files.createDirectories(current.getParent());
                    Files.copy(original, current, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.COPY_ATTRIBUTES);
                    restored++;
                }
            }
        } catch (IOException restoreFailure) {
            Collections.reverse(processed);
            for (ChangedFile file : processed) {
                Path current = file.root().resolve(file.relative());
                Path saved = safety.resolve(file.backup().getFileName()).resolve(file.relative());
                try {
                    if (Files.isRegularFile(saved)) {
                        Files.createDirectories(current.getParent());
                        Files.copy(saved, current, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.COPY_ATTRIBUTES);
                    } else {
                        Files.deleteIfExists(current);
                        removeEmptyParents(current.getParent(), file.root());
                    }
                } catch (IOException recoveryFailure) { restoreFailure.addSuppressed(recoveryFailure); }
            }
            throw new IOException("Rollback could not finish. The safety copy is retained for recovery.", restoreFailure);
        }
        Properties completed = new Properties();
        completed.setProperty("at", Instant.now().toString());
        completed.setProperty("restored", Integer.toString(restored));
        completed.setProperty("removed", Integer.toString(removed));
        atomicProperties(state.folder().resolve("rolled-back.properties"), completed);
        // Rebuild in the background via the normal explicit rescan workflow if index is not warm.
        if (index != null) {
            Set<Path> roots = new LinkedHashSet<>();
            for (ChangedFile file : state.files()) roots.add(file.root());
            for (Path root : roots) {
                List<String> paths = state.files().stream().filter(f -> f.root().equals(root))
                        .map(f -> f.relative().toString()).toList();
                index.refreshPaths(AgentWorkspaceService.Workspace.forIndex(projectId, root), paths);
            }
        }
        return Map.of("runId", runId, "restored", restored, "removed", removed,
                "message", "Rolled back the entire task: restored " + restored + " original files and removed " + removed + " task-created files.");
    }

    public Optional<String> latestAvailable(String conversationId, String projectId, String exceptRunId) {
        // Never jump backwards over an already-undone task on a repeated "undo last" request.
        return runs.forConversation(conversationId).stream()
                .sorted(Comparator.comparing((Map<String,Object> r) -> String.valueOf(r.get("createdAt"))).reversed())
                .filter(snapshot -> "completed".equals(snapshot.get("status")))
                .filter(snapshot -> Objects.equals(projectId, snapshot.get("projectId")))
                .map(snapshot -> String.valueOf(snapshot.get("id")))
                .filter(id -> !id.equals(exceptRunId) && hasTaskRecord(id))
                .findFirst().filter(this::available);
    }

    private boolean hasTaskRecord(String runId) {
        try { return Files.isRegularFile(snapshots.snapshotDirectory(runId).resolve("changes.properties")); }
        catch (Exception badId) { return false; }
    }

    private void pruneOldSnapshots(Path newest) {
        int retain = Math.max(1, Integer.getInteger("eliya.rollback.retainedTasks", 10));
        try (var directories = Files.list(newest.getParent())) {
            List<Path> sealed = directories.filter(Files::isDirectory)
                    .filter(dir -> Files.isRegularFile(dir.resolve("changes.properties")))
                    .sorted(Comparator.comparingLong((Path dir) -> {
                        try { return Files.getLastModifiedTime(dir.resolve("changes.properties")).toMillis(); }
                        catch (IOException ignored) { return 0L; }
                    }).reversed()).toList();
            for (int i = retain; i < sealed.size(); i++)
                try { snapshots.discard(sealed.get(i).getFileName().toString()); }
                catch (IOException ignored) { /* Do not fail the completed task on maintenance errors. */ }
        } catch (IOException ignored) { }
    }

    private Changes load(String runId) throws IOException {
        Path folder = snapshots.snapshotDirectory(runId);
        Properties baseline = properties(folder.resolve("manifest.properties"));
        Properties manifest = properties(folder.resolve("changes.properties"));
        int count = Integer.parseInt(manifest.getProperty("count", "0"));
        if (count < 0 || count > 200_000) throw new IOException("Invalid rollback manifest count");
        List<ChangedFile> files = new ArrayList<>();
        for (int i = 0; i < count; i++) {
            String prefix = "change." + i + ".";
            int scope = Integer.parseInt(manifest.getProperty(prefix + "root", "-1"));
            if (scope < 0 || scope >= Integer.parseInt(baseline.getProperty("scopeCount", "0")))
                throw new IOException("Invalid rollback scope");
            Path root = Path.of(baseline.getProperty("root." + scope)).toAbsolutePath().normalize();
            Path relative = Path.of(manifest.getProperty(prefix + "path", "")).normalize();
            if (relative.isAbsolute() || relative.toString().isBlank() || relative.startsWith(".."))
                throw new IOException("Invalid rollback path");
            files.add(new ChangedFile(root, folder.resolve("root-" + scope), relative,
                    manifest.getProperty(prefix + "before", MISSING), manifest.getProperty(prefix + "after", MISSING)));
        }
        return new Changes(folder, List.copyOf(files));
    }

    private String validate(ChangedFile file) throws IOException {
        Path current = file.root().resolve(file.relative()).normalize();
        if (!current.startsWith(file.root()) || Files.isSymbolicLink(file.root())) return "Unsafe root/path: " + current;
        Path cursor = file.root();
        for (Path part : file.relative()) {
            cursor = cursor.resolve(part);
            if (Files.isSymbolicLink(cursor)) return "Symlink found: " + cursor;
        }
        if (!Objects.equals(hash(current), file.after())) return "File changed since task completed: " + current;
        if (!Objects.equals(hash(file.backup().resolve(file.relative())), file.before()))
            return "Original recovery copy is damaged: " + current;
        return null;
    }

    private static void collect(Path root, Set<Path> paths) throws IOException {
        Files.walkFileTree(root, new SimpleFileVisitor<>() {
            @Override public FileVisitResult preVisitDirectory(Path dir, BasicFileAttributes attrs) {
                if (Files.isSymbolicLink(dir) || (!dir.equals(root) && SKIP.contains(dir.getFileName().toString().toLowerCase(Locale.ROOT))))
                    return FileVisitResult.SKIP_SUBTREE;
                return FileVisitResult.CONTINUE;
            }
            @Override public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) {
                if (attrs.isRegularFile() && !Files.isSymbolicLink(file)) paths.add(root.relativize(file));
                return FileVisitResult.CONTINUE;
            }
        });
    }
    private static String hash(Path file) throws IOException {
        if (!Files.isRegularFile(file, LinkOption.NOFOLLOW_LINKS)) return MISSING;
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            try (InputStream stream = Files.newInputStream(file)) {
                byte[] buf = new byte[64 * 1024]; int length;
                while ((length = stream.read(buf)) != -1) md.update(buf, 0, length);
            }
            return HexFormat.of().formatHex(md.digest());
        } catch (java.security.NoSuchAlgorithmException impossible) { throw new IOException(impossible); }
    }
    private static Properties properties(Path path) throws IOException {
        Properties result = new Properties();
        try (InputStream stream = Files.newInputStream(path)) { result.load(stream); }
        return result;
    }
    private static void atomicProperties(Path path, Properties p) throws IOException {
        Path temp = path.resolveSibling(path.getFileName() + ".tmp");
        try (OutputStream out = Files.newOutputStream(temp)) { p.store(out, "ELIYA task rollback"); }
        try { Files.move(temp, path, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING); }
        catch (AtomicMoveNotSupportedException ignored) { Files.move(temp, path, StandardCopyOption.REPLACE_EXISTING); }
    }
    private static void removeEmptyParents(Path parent, Path root) throws IOException {
        while (parent != null && !parent.equals(root) && parent.startsWith(root)) {
            try (var contents = Files.list(parent)) { if (contents.findAny().isPresent()) break; }
            Files.delete(parent); parent = parent.getParent();
        }
    }
    private record ChangedFile(Path root, Path backup, Path relative, String before, String after) { }
    private record Changes(Path folder, List<ChangedFile> files) { }
}
