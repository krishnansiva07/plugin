// Curated, task-specific additions to the original Eliya prompt library.
const ELIYA_PROMPT_CATALOG = [
  {
    "title": "Map Repository Architecture and Module Responsibilities",
    "category": "Workspace & architecture",
    "mode": "Chat",
    "purpose": "Identify the actual high-level architecture from files, not assumptions.",
    "prompt": "Workspace [workspace]: use the folder configured with Enter path; do not require me to repeat its absolute path.\nScope: <whole repository or module>\n\nTask: Identify the actual high-level architecture from files, not assumptions.\nInspect entry points, packages, configuration, dependencies and core call paths. Distinguish verified relationships from hypotheses.\n\nDeliverable: Module map, data flow, dependencies and source-file evidence.\n\nChat rules: answer from accessible files, attachments and enabled MCP sources; cite filenames, requirement sections or source identifiers where possible. Do not edit or delete workspace files."
  },
  {
    "title": "Trace a Request from UI to Database",
    "category": "Workspace & architecture",
    "mode": "Chat",
    "purpose": "Follow one user action or API request through the code.",
    "prompt": "Workspace [workspace]: use the folder configured with Enter path; do not require me to repeat its absolute path.\nRequest or action: <name>\n\nTask: Follow one user action or API request through the code.\nFollow routes, controllers, services, integrations, persistence, exceptions and return paths. Name files and symbols where available.\n\nDeliverable: Ordered sequence, diagram-friendly flow and known failure points.\n\nChat rules: answer from accessible files, attachments and enabled MCP sources; cite filenames, requirement sections or source identifiers where possible. Do not edit or delete workspace files."
  },
  {
    "title": "Identify API Endpoints and Their Consumers",
    "category": "Workspace & architecture",
    "mode": "Chat",
    "purpose": "Produce a current API inventory.",
    "prompt": "Workspace [workspace]: use the folder configured with Enter path; do not require me to repeat its absolute path.\nScope: <module or entire service>\n\nTask: Produce a current API inventory.\nInspect controller mappings, HTTP methods, DTOs, validation, callers, authentication, responses and error mapping.\n\nDeliverable: Endpoint table, payloads, consumers and uncovered contracts.\n\nChat rules: answer from accessible files, attachments and enabled MCP sources; cite filenames, requirement sections or source identifiers where possible. Do not edit or delete workspace files."
  },
  {
    "title": "Explain Configuration and Startup Sequence",
    "category": "Workspace & architecture",
    "mode": "Chat",
    "purpose": "Show exactly how the application boots and resolves configuration.",
    "prompt": "Workspace [workspace]: use the folder configured with Enter path; do not require me to repeat its absolute path.\nEnvironment: <local, CI or production>\n\nTask: Show exactly how the application boots and resolves configuration.\nInspect bootstrap, property sources, profiles, environment variables, dependency wiring, database and scheduled jobs. Never reveal secrets.\n\nDeliverable: Startup order, required settings and environment differences.\n\nChat rules: answer from accessible files, attachments and enabled MCP sources; cite filenames, requirement sections or source identifiers where possible. Do not edit or delete workspace files."
  },
  {
    "title": "Analyse Dependency and Module Coupling",
    "category": "Workspace & architecture",
    "mode": "Chat",
    "purpose": "Discover where modules are tightly coupled.",
    "prompt": "Workspace [workspace]: use the folder configured with Enter path; do not require me to repeat its absolute path.\nScope: <modules>\n\nTask: Discover where modules are tightly coupled.\nTrace imports, injected services, shared mutable state, cyclic dependencies and build dependencies. Separate observed dependencies from potential risks.\n\nDeliverable: Dependency map and candidate boundaries, with evidence.\n\nChat rules: answer from accessible files, attachments and enabled MCP sources; cite filenames, requirement sections or source identifiers where possible. Do not edit or delete workspace files."
  },
  {
    "title": "Locate Business Rules and Validation",
    "category": "Workspace & architecture",
    "mode": "Chat",
    "purpose": "Find where a stated business rule is enforced.",
    "prompt": "Workspace [workspace]: use the folder configured with Enter path; do not require me to repeat its absolute path.\nRule: <business rule>\n\nTask: Find where a stated business rule is enforced.\nSearch controllers, validators, domain services, database constraints and tests. Compare duplicate or inconsistent implementations.\n\nDeliverable: Rule-to-file mapping, condition matrix and unverified gaps.\n\nChat rules: answer from accessible files, attachments and enabled MCP sources; cite filenames, requirement sections or source identifiers where possible. Do not edit or delete workspace files."
  },
  {
    "title": "Compare Current Code with Reference Architecture",
    "category": "Workspace & architecture",
    "mode": "Chat",
    "purpose": "Identify architectural differences without modifying the reference.",
    "prompt": "Workspace [workspace]: use the folder configured with Enter path; do not require me to repeat its absolute path.\nReference alias: <alias>; comparison scope: <module>\n\nTask: Identify architectural differences without modifying the reference.\nUse Workspace [workspace] as the target and Reference [<alias>] as read-only. Compare design, interfaces, configuration and tests; do not assume reference is universally preferable.\n\nDeliverable: Differences, risks, transferable patterns and affected target files.\n\nChat rules: answer from accessible files, attachments and enabled MCP sources; cite filenames, requirement sections or source identifiers where possible. Do not edit or delete workspace files."
  },
  {
    "title": "Generate an Evidence-Based Technical Design",
    "category": "Workspace & architecture",
    "mode": "Chat",
    "purpose": "Document implementation design from current repository.",
    "prompt": "Workspace [workspace]: use the folder configured with Enter path; do not require me to repeat its absolute path.\nComponent: <name>\n\nTask: Document implementation design from current repository.\nInspect classes, interfaces, entry points, message exchange, dependencies, concurrency and persistence. Mark unknown or external boundaries.\n\nDeliverable: Design overview, components, sequence and references to code.\n\nChat rules: answer from accessible files, attachments and enabled MCP sources; cite filenames, requirement sections or source identifiers where possible. Do not edit or delete workspace files."
  },
  {
    "title": "Find Dead Code and Unused Configuration",
    "category": "Workspace & architecture",
    "mode": "Chat",
    "purpose": "Locate candidates for safe cleanup.",
    "prompt": "Workspace [workspace]: use the folder configured with Enter path; do not require me to repeat its absolute path.\nScope: <module>\n\nTask: Locate candidates for safe cleanup.\nCheck usages, reflection, external API exposure, test-only access, feature flags and configuration references before classifying anything as unused.\n\nDeliverable: Candidates, evidence, confidence caveats and a safe removal plan.\n\nChat rules: answer from accessible files, attachments and enabled MCP sources; cite filenames, requirement sections or source identifiers where possible. Do not edit or delete workspace files."
  },
  {
    "title": "Generate Functional Test Cases from Word Section Including Images",
    "category": "Documents & test design",
    "mode": "Chat",
    "purpose": "Create cases from textual and visual requirements.",
    "prompt": "Workspace [workspace]: use the folder configured with Enter path; do not require me to repeat its absolute path.\nDocument: <attached Word document or indexed file>; section: <section number>\n\nTask: Create cases from textual and visual requirements.\nRead the requested section, tables, captions, screenshots and embedded diagrams. If a vision-capable model is unavailable or images cannot be read, flag missing coverage instead of guessing.\n\nDeliverable: Test IDs, scenario, preconditions, steps, data, expected result, priority and evidence references; request an Excel export when needed.\n\nChat rules: answer from accessible files, attachments and enabled MCP sources; cite filenames, requirement sections or source identifiers where possible. Do not edit or delete workspace files."
  },
  {
    "title": "Generate Test Cases from PDF with Diagrams",
    "category": "Documents & test design",
    "mode": "Chat",
    "purpose": "Turn a PDF specification into test coverage.",
    "prompt": "Workspace [workspace]: use the folder configured with Enter path; do not require me to repeat its absolute path.\nDocument: <attached PDF>; pages: <page range>\n\nTask: Turn a PDF specification into test coverage.\nAnalyse text, tables, workflows and visually meaningful pages when supported. Trace each case to a page or requirement; disclose unreadable diagrams.\n\nDeliverable: Positive, negative, boundary and visual cases with traceability.\n\nChat rules: answer from accessible files, attachments and enabled MCP sources; cite filenames, requirement sections or source identifiers where possible. Do not edit or delete workspace files."
  },
  {
    "title": "Create Requirement-to-Test Traceability Matrix",
    "category": "Documents & test design",
    "mode": "Chat",
    "purpose": "Link acceptance criteria to existing and missing tests.",
    "prompt": "Workspace [workspace]: use the folder configured with Enter path; do not require me to repeat its absolute path.\nRequirements: <file, Jira keys or pasted criteria>\n\nTask: Link acceptance criteria to existing and missing tests.\nExtract unique requirements, inspect existing cases in Workspace [workspace] if available and identify missing or obsolete coverage.\n\nDeliverable: Requirement ID, test ID, coverage status, risk and source evidence.\n\nChat rules: answer from accessible files, attachments and enabled MCP sources; cite filenames, requirement sections or source identifiers where possible. Do not edit or delete workspace files."
  },
  {
    "title": "Review Specification for Ambiguity and Missing Rules",
    "category": "Documents & test design",
    "mode": "Chat",
    "purpose": "Find unclear requirements before test design.",
    "prompt": "Workspace [workspace]: use the folder configured with Enter path; do not require me to repeat its absolute path.\nRequirement source: <document or Jira issue>\n\nTask: Find unclear requirements before test design.\nCheck roles, state transitions, values, limits, error paths, nonfunctional criteria and contradictory statements. Do not invent requirements.\n\nDeliverable: Clarification questions grouped by severity and suggested acceptance criteria.\n\nChat rules: answer from accessible files, attachments and enabled MCP sources; cite filenames, requirement sections or source identifiers where possible. Do not edit or delete workspace files."
  },
  {
    "title": "Generate Boundary-Value and Equivalence Tests",
    "category": "Documents & test design",
    "mode": "Chat",
    "purpose": "Derive systematic test values from a rule.",
    "prompt": "Workspace [workspace]: use the folder configured with Enter path; do not require me to repeat its absolute path.\nFields and constraints: <paste rules>\n\nTask: Derive systematic test values from a rule.\nIdentify valid partitions, invalid partitions, min/max, empty/null, cross-field constraints and format combinations. Explain assumptions.\n\nDeliverable: Boundary matrix and prioritized test scenarios.\n\nChat rules: answer from accessible files, attachments and enabled MCP sources; cite filenames, requirement sections or source identifiers where possible. Do not edit or delete workspace files."
  },
  {
    "title": "Design Negative and Security-Oriented Functional Cases",
    "category": "Documents & test design",
    "mode": "Chat",
    "purpose": "Identify misuse and rejection paths for a feature.",
    "prompt": "Workspace [workspace]: use the folder configured with Enter path; do not require me to repeat its absolute path.\nFeature: <name>; roles: <users>\n\nTask: Identify misuse and rejection paths for a feature.\nCover malformed data, unauthorised roles, duplicates, expired state, invalid transitions and safe error handling; do not include exploit instructions.\n\nDeliverable: Case IDs, test data, expected rejection and audit checks.\n\nChat rules: answer from accessible files, attachments and enabled MCP sources; cite filenames, requirement sections or source identifiers where possible. Do not edit or delete workspace files."
  },
  {
    "title": "Create End-to-End Scenarios Across Services",
    "category": "Documents & test design",
    "mode": "Chat",
    "purpose": "Test a business process crossing application boundaries.",
    "prompt": "Workspace [workspace]: use the folder configured with Enter path; do not require me to repeat its absolute path.\nBusiness journey: <name>\n\nTask: Test a business process crossing application boundaries.\nMap producers, queues, processors, APIs, UI and dependencies from available specs or workspace evidence. Include failure, retry and reconciliation paths.\n\nDeliverable: End-to-end cases and observability checkpoints.\n\nChat rules: answer from accessible files, attachments and enabled MCP sources; cite filenames, requirement sections or source identifiers where possible. Do not edit or delete workspace files."
  },
  {
    "title": "Compare Two Requirement Versions for Test Impact",
    "category": "Documents & test design",
    "mode": "Chat",
    "purpose": "Discover changes and affected coverage.",
    "prompt": "Workspace [workspace]: use the folder configured with Enter path; do not require me to repeat its absolute path.\nOld document: <file>; new document: <file>\n\nTask: Discover changes and affected coverage.\nCompare semantics, fields, behavior, workflow and UI images when readable. Do not mistake formatting changes for requirement changes.\n\nDeliverable: Change matrix, impacted tests and new or removed cases.\n\nChat rules: answer from accessible files, attachments and enabled MCP sources; cite filenames, requirement sections or source identifiers where possible. Do not edit or delete workspace files."
  },
  {
    "title": "Generate Test Data and a Coverage Matrix",
    "category": "Documents & test design",
    "mode": "Chat",
    "purpose": "Prepare traceable input combinations.",
    "prompt": "Workspace [workspace]: use the folder configured with Enter path; do not require me to repeat its absolute path.\nFeature and fields: <details>\n\nTask: Prepare traceable input combinations.\nDefine representative normal, edge, malformed and conflicting values, privacy-safe sample data and expected outcomes. Limit combinatorial explosion using justified pairwise coverage where useful.\n\nDeliverable: Test-data table and coverage matrix.\n\nChat rules: answer from accessible files, attachments and enabled MCP sources; cite filenames, requirement sections or source identifiers where possible. Do not edit or delete workspace files."
  },
  {
    "title": "Add JUnit 5 Tests for a Java Service",
    "category": "Java & API testing",
    "mode": "Agent",
    "purpose": "Expand focused Java unit test coverage.",
    "prompt": "Workspace [workspace]: use the folder configured with Enter path; do not require me to repeat its absolute path.\nTarget class: <fully qualified class>\n\nTask: Expand focused Java unit test coverage.\nInspect nearby tests and existing dependencies first. Cover success, exception, null, boundary and mocked collaborators using repository conventions.\n\nDeliverable: JUnit tests, fixture changes, targeted test results and remaining gaps.\n\nAgent rules: inspect AGENTS.md and relevant skills where present; preserve existing architecture, keep reference folders read-only, and follow configured plan/tool/deletion approvals. Validate only what the current environment actually supports and report results honestly."
  },
  {
    "title": "Create TestNG Data-Driven Tests from Excel",
    "category": "Java & API testing",
    "mode": "Agent",
    "purpose": "Implement parameterized scenarios using existing spreadsheet helpers.",
    "prompt": "Workspace [workspace]: use the folder configured with Enter path; do not require me to repeat its absolute path.\nTest scenario: <name>; Excel sheet: <sheet>\n\nTask: Implement parameterized scenarios using existing spreadsheet helpers.\nReuse existing TestNG DataProvider, Apache POI and test data patterns; avoid parallel frameworks and hard-coded secrets.\n\nDeliverable: Runnable tests, sheet schema and verification result.\n\nAgent rules: inspect AGENTS.md and relevant skills where present; preserve existing architecture, keep reference folders read-only, and follow configured plan/tool/deletion approvals. Validate only what the current environment actually supports and report results honestly."
  },
  {
    "title": "Build Rest Assured API Contract Tests",
    "category": "Java & API testing",
    "mode": "Agent",
    "purpose": "Cover request and response contracts for a specified endpoint.",
    "prompt": "Workspace [workspace]: use the folder configured with Enter path; do not require me to repeat its absolute path.\nEndpoint: <method and path>; contract: <details>\n\nTask: Cover request and response contracts for a specified endpoint.\nReuse base URI, auth setup and test infrastructure; assert status, headers, schema and meaningful field values, including negative cases.\n\nDeliverable: Focused API tests and reproducible execution command.\n\nAgent rules: inspect AGENTS.md and relevant skills where present; preserve existing architecture, keep reference folders read-only, and follow configured plan/tool/deletion approvals. Validate only what the current environment actually supports and report results honestly."
  },
  {
    "title": "Create API Error and Validation Tests",
    "category": "Java & API testing",
    "mode": "Agent",
    "purpose": "Test invalid requests and consistent error semantics.",
    "prompt": "Workspace [workspace]: use the folder configured with Enter path; do not require me to repeat its absolute path.\nAPI: <endpoint>; input constraints: <rules>\n\nTask: Test invalid requests and consistent error semantics.\nInspect validators, exception mappers and documented codes. Cover missing, malformed, out-of-range, duplicate and unauthorised inputs.\n\nDeliverable: Negative tests, expected responses and gaps in contracts.\n\nAgent rules: inspect AGENTS.md and relevant skills where present; preserve existing architecture, keep reference folders read-only, and follow configured plan/tool/deletion approvals. Validate only what the current environment actually supports and report results honestly."
  },
  {
    "title": "Add Database Integration Tests",
    "category": "Java & API testing",
    "mode": "Agent",
    "purpose": "Verify persistence behavior and transactional boundaries.",
    "prompt": "Workspace [workspace]: use the folder configured with Enter path; do not require me to repeat its absolute path.\nRepository or operation: <name>\n\nTask: Verify persistence behavior and transactional boundaries.\nUse the project's existing test database and migration strategy. Cover persistence, rollback, unique constraints and query boundaries; isolate test state.\n\nDeliverable: Integration tests, test setup and verified results.\n\nAgent rules: inspect AGENTS.md and relevant skills where present; preserve existing architecture, keep reference folders read-only, and follow configured plan/tool/deletion approvals. Validate only what the current environment actually supports and report results honestly."
  },
  {
    "title": "Create Kafka Event Ingestion Tests",
    "category": "Java & API testing",
    "mode": "Agent",
    "purpose": "Validate event contract and downstream processing.",
    "prompt": "Workspace [workspace]: use the folder configured with Enter path; do not require me to repeat its absolute path.\nTopic and event schema: <details>\n\nTask: Validate event contract and downstream processing.\nInspect producers, serializers, consumers, idempotency, retries and failure handling; use existing embedded infrastructure or mocks.\n\nDeliverable: Test cases/code, event fixtures and delivery assumptions.\n\nAgent rules: inspect AGENTS.md and relevant skills where present; preserve existing architecture, keep reference folders read-only, and follow configured plan/tool/deletion approvals. Validate only what the current environment actually supports and report results honestly."
  },
  {
    "title": "Write SQL Data Validation Tests",
    "category": "Java & API testing",
    "mode": "Agent",
    "purpose": "Check source-to-target transformation rules.",
    "prompt": "Workspace [workspace]: use the folder configured with Enter path; do not require me to repeat its absolute path.\nTables and mappings: <details>\n\nTask: Check source-to-target transformation rules.\nInspect available schema and transformations. Cover row counts, key uniqueness, null handling, type precision, reconciliation and known edge cases.\n\nDeliverable: SQL assertions, test data and expected outcomes.\n\nAgent rules: inspect AGENTS.md and relevant skills where present; preserve existing architecture, keep reference folders read-only, and follow configured plan/tool/deletion approvals. Validate only what the current environment actually supports and report results honestly."
  },
  {
    "title": "Validate Authentication and JWT API Flows",
    "category": "Java & API testing",
    "mode": "Agent",
    "purpose": "Add checks for valid and invalid authentication flows.",
    "prompt": "Workspace [workspace]: use the folder configured with Enter path; do not require me to repeat its absolute path.\nAPI flow: <login, refresh or protected endpoint>\n\nTask: Add checks for valid and invalid authentication flows.\nInspect security configuration, signing/verification and existing auth tests. Use dummy credentials and do not expose real keys.\n\nDeliverable: Test scenarios for roles, expired/invalid tokens and expected statuses.\n\nAgent rules: inspect AGENTS.md and relevant skills where present; preserve existing architecture, keep reference folders read-only, and follow configured plan/tool/deletion approvals. Validate only what the current environment actually supports and report results honestly."
  },
  {
    "title": "Build Reusable Java Test Fixtures Without Duplication",
    "category": "Java & API testing",
    "mode": "Agent",
    "purpose": "Simplify repetitive test data and setup.",
    "prompt": "Workspace [workspace]: use the folder configured with Enter path; do not require me to repeat its absolute path.\nTests or package: <scope>\n\nTask: Simplify repetitive test data and setup.\nIdentify repeated setup, fixture leakage and unsafe shared state; add the smallest reusable helpers following current Java and test framework style.\n\nDeliverable: Refactored fixtures, unchanged test intent and regression results.\n\nAgent rules: inspect AGENTS.md and relevant skills where present; preserve existing architecture, keep reference folders read-only, and follow configured plan/tool/deletion approvals. Validate only what the current environment actually supports and report results honestly."
  },
  {
    "title": "Generate Cucumber Feature Scenarios from Acceptance Criteria",
    "category": "Selenium & Cucumber",
    "mode": "Agent",
    "purpose": "Produce readable Gherkin matched to existing steps.",
    "prompt": "Workspace [workspace]: use the folder configured with Enter path; do not require me to repeat its absolute path.\nFeature and acceptance criteria: <details>\n\nTask: Produce readable Gherkin matched to existing steps.\nInspect feature naming, existing steps, tags, Background use and business terms. Avoid duplicate step definitions and overly implementation-specific scenarios.\n\nDeliverable: Feature scenarios, reused/new steps and coverage mapping.\n\nAgent rules: inspect AGENTS.md and relevant skills where present; preserve existing architecture, keep reference folders read-only, and follow configured plan/tool/deletion approvals. Validate only what the current environment actually supports and report results honestly."
  },
  {
    "title": "Implement Selenium Page Object for a UI Page",
    "category": "Selenium & Cucumber",
    "mode": "Agent",
    "purpose": "Add or repair one page object in the existing framework.",
    "prompt": "Workspace [workspace]: use the folder configured with Enter path; do not require me to repeat its absolute path.\nPage: <name>; actions and assertions: <details>\n\nTask: Add or repair one page object in the existing framework.\nInspect page factory/locator conventions, wait utilities and component reuse. Use stable locators and avoid duplicate waits.\n\nDeliverable: Page object implementation, affected tests and validation.\n\nAgent rules: inspect AGENTS.md and relevant skills where present; preserve existing architecture, keep reference folders read-only, and follow configured plan/tool/deletion approvals. Validate only what the current environment actually supports and report results honestly."
  },
  {
    "title": "Investigate a Selenium Locator Failure",
    "category": "Selenium & Cucumber",
    "mode": "Agent",
    "purpose": "Find a stable fix for a broken locator.",
    "prompt": "Workspace [workspace]: use the folder configured with Enter path; do not require me to repeat its absolute path.\nPage and element: <details>; error: <stack trace>\n\nTask: Find a stable fix for a broken locator.\nCheck DOM changes, frames, shadow DOM, overlays and dynamic attributes using available evidence or configured browser MCP. Do not weaken assertions.\n\nDeliverable: Root cause, locator fix and focused rerun.\n\nAgent rules: inspect AGENTS.md and relevant skills where present; preserve existing architecture, keep reference folders read-only, and follow configured plan/tool/deletion approvals. Validate only what the current environment actually supports and report results honestly."
  },
  {
    "title": "Fix StaleElementReferenceException",
    "category": "Selenium & Cucumber",
    "mode": "Agent",
    "purpose": "Stabilize interactions around refreshed DOM nodes.",
    "prompt": "Workspace [workspace]: use the folder configured with Enter path; do not require me to repeat its absolute path.\nFailing action: <description>\n\nTask: Stabilize interactions around refreshed DOM nodes.\nTrace rerenders, cached elements, iteration and framework waits. Refind target elements after state changes where warranted.\n\nDeliverable: Minimal fix, targeted regression and rationale.\n\nAgent rules: inspect AGENTS.md and relevant skills where present; preserve existing architecture, keep reference folders read-only, and follow configured plan/tool/deletion approvals. Validate only what the current environment actually supports and report results honestly."
  },
  {
    "title": "Fix Selenium Grid Node-Specific Failure",
    "category": "Selenium & Cucumber",
    "mode": "Agent",
    "purpose": "Compare behavior across machines and nodes.",
    "prompt": "Workspace [workspace]: use the folder configured with Enter path; do not require me to repeat its absolute path.\nGrid URL, node IDs and error: <redacted details>\n\nTask: Compare behavior across machines and nodes.\nExamine browser/driver versions, capabilities, network, session logs, popups and timing. Avoid assuming a local-only fix works remotely.\n\nDeliverable: Evidence-based diagnosis and configuration/code changes.\n\nAgent rules: inspect AGENTS.md and relevant skills where present; preserve existing architecture, keep reference folders read-only, and follow configured plan/tool/deletion approvals. Validate only what the current environment actually supports and report results honestly."
  },
  {
    "title": "Review TestNG and Cucumber Tag Execution",
    "category": "Selenium & Cucumber",
    "mode": "Agent",
    "purpose": "Explain which scenarios a runner executes.",
    "prompt": "Workspace [workspace]: use the folder configured with Enter path; do not require me to repeat its absolute path.\nRunner class and target tags: <details>\n\nTask: Explain which scenarios a runner executes.\nTrace runner options, system properties, plugin config, Maven profiles and CI overrides. Check AND/OR/NOT semantics.\n\nDeliverable: Resolved tag expression, selected scope and command.\n\nAgent rules: inspect AGENTS.md and relevant skills where present; preserve existing architecture, keep reference folders read-only, and follow configured plan/tool/deletion approvals. Validate only what the current environment actually supports and report results honestly."
  },
  {
    "title": "Remove Fragile Sleeps from Selenium Tests",
    "category": "Selenium & Cucumber",
    "mode": "Agent",
    "purpose": "Replace arbitrary waits with meaningful synchronization.",
    "prompt": "Workspace [workspace]: use the folder configured with Enter path; do not require me to repeat its absolute path.\nFlaky tests or package: <scope>\n\nTask: Replace arbitrary waits with meaningful synchronization.\nIdentify the condition each sleep was masking, then use existing explicit waits and state-based expectations.\n\nDeliverable: Wait refactor and repeat-run verification.\n\nAgent rules: inspect AGENTS.md and relevant skills where present; preserve existing architecture, keep reference folders read-only, and follow configured plan/tool/deletion approvals. Validate only what the current environment actually supports and report results honestly."
  },
  {
    "title": "Improve Selenium Screenshot and Failure Reporting",
    "category": "Selenium & Cucumber",
    "mode": "Agent",
    "purpose": "Capture actionable evidence on test failures.",
    "prompt": "Workspace [workspace]: use the folder configured with Enter path; do not require me to repeat its absolute path.\nRunner/reporter: <details>\n\nTask: Capture actionable evidence on test failures.\nInspect hooks, listeners, screenshot utilities, parallel scope and reporting. Avoid logging secrets or massive unbounded artifacts.\n\nDeliverable: Focused reporting improvements and sample failure evidence.\n\nAgent rules: inspect AGENTS.md and relevant skills where present; preserve existing architecture, keep reference folders read-only, and follow configured plan/tool/deletion approvals. Validate only what the current environment actually supports and report results honestly."
  },
  {
    "title": "Make Parallel Selenium Tests Data-Isolated",
    "category": "Selenium & Cucumber",
    "mode": "Agent",
    "purpose": "Remove cross-test interference in concurrent runs.",
    "prompt": "Workspace [workspace]: use the folder configured with Enter path; do not require me to repeat its absolute path.\nAffected suite: <scope>\n\nTask: Remove cross-test interference in concurrent runs.\nTrace static drivers, ThreadLocal lifecycle, shared accounts, files and test-data collisions. Align with current infrastructure.\n\nDeliverable: Isolation changes, cleanup hooks and parallel verification.\n\nAgent rules: inspect AGENTS.md and relevant skills where present; preserve existing architecture, keep reference folders read-only, and follow configured plan/tool/deletion approvals. Validate only what the current environment actually supports and report results honestly."
  },
  {
    "title": "Migrate One Cucumber Feature to Playwright TypeScript",
    "category": "Playwright & migration",
    "mode": "Agent",
    "purpose": "Port behavior, not Selenium line-by-line syntax.",
    "prompt": "Workspace [workspace]: use the folder configured with Enter path; do not require me to repeat its absolute path.\nReference alias: <alias>; feature: <name>\n\nTask: Port behavior, not Selenium line-by-line syntax.\nUse Reference [<alias>] as read-only Selenium source and Workspace [workspace] as Playwright target. Map scenarios, steps, data and assertions to fixtures and resilient locators.\n\nDeliverable: Migrated tests, source-to-target mapping and validation.\n\nAgent rules: inspect AGENTS.md and relevant skills where present; preserve existing architecture, keep reference folders read-only, and follow configured plan/tool/deletion approvals. Validate only what the current environment actually supports and report results honestly."
  },
  {
    "title": "Convert Selenium Page Object to Playwright Page Object",
    "category": "Playwright & migration",
    "mode": "Agent",
    "purpose": "Create a Playwright-native equivalent for one page.",
    "prompt": "Workspace [workspace]: use the folder configured with Enter path; do not require me to repeat its absolute path.\nReference alias: <alias>; page: <name>\n\nTask: Create a Playwright-native equivalent for one page.\nRead Reference [<alias>] and current target patterns. Replace WebDriver waits with locators and Playwright auto-waiting; preserve business semantics.\n\nDeliverable: Target page object, associated tests and migration notes.\n\nAgent rules: inspect AGENTS.md and relevant skills where present; preserve existing architecture, keep reference folders read-only, and follow configured plan/tool/deletion approvals. Validate only what the current environment actually supports and report results honestly."
  },
  {
    "title": "Migrate Excel-Driven Tests to Playwright Fixtures",
    "category": "Playwright & migration",
    "mode": "Agent",
    "purpose": "Preserve data-driven behavior during migration.",
    "prompt": "Workspace [workspace]: use the folder configured with Enter path; do not require me to repeat its absolute path.\nReference alias: <alias>; Excel sheet: <name>\n\nTask: Preserve data-driven behavior during migration.\nInspect source parsing, data selection and target test fixtures. Use existing target package conventions and keep source read-only.\n\nDeliverable: Data loader/fixtures, migrated cases and sample run.\n\nAgent rules: inspect AGENTS.md and relevant skills where present; preserve existing architecture, keep reference folders read-only, and follow configured plan/tool/deletion approvals. Validate only what the current environment actually supports and report results honestly."
  },
  {
    "title": "Build Playwright Authentication Setup",
    "category": "Playwright & migration",
    "mode": "Agent",
    "purpose": "Implement reusable login/state without unsafe global sharing.",
    "prompt": "Workspace [workspace]: use the folder configured with Enter path; do not require me to repeat its absolute path.\nAuthentication flow: <details>\n\nTask: Implement reusable login/state without unsafe global sharing.\nInspect existing config, storage state handling and manual PIN/OTP steps. Keep headed/manual interaction where required; do not bypass authentication.\n\nDeliverable: Fixture/setup pattern, security caveats and targeted test.\n\nAgent rules: inspect AGENTS.md and relevant skills where present; preserve existing architecture, keep reference folders read-only, and follow configured plan/tool/deletion approvals. Validate only what the current environment actually supports and report results honestly."
  },
  {
    "title": "Investigate Playwright Test Failure",
    "category": "Playwright & migration",
    "mode": "Agent",
    "purpose": "Diagnose timeout, locator or assertion errors.",
    "prompt": "Workspace [workspace]: use the folder configured with Enter path; do not require me to repeat its absolute path.\nTest and trace/error: <details>\n\nTask: Diagnose timeout, locator or assertion errors.\nUse available trace, screenshots, DOM and config. Determine if product, locator, state, environment or timeout caused the failure.\n\nDeliverable: Smallest fix and reproducible verification.\n\nAgent rules: inspect AGENTS.md and relevant skills where present; preserve existing architecture, keep reference folders read-only, and follow configured plan/tool/deletion approvals. Validate only what the current environment actually supports and report results honestly."
  },
  {
    "title": "Improve Playwright Locator Strategy",
    "category": "Playwright & migration",
    "mode": "Agent",
    "purpose": "Make tests resilient without hiding UI defects.",
    "prompt": "Workspace [workspace]: use the folder configured with Enter path; do not require me to repeat its absolute path.\nPage or scope: <name>\n\nTask: Make tests resilient without hiding UI defects.\nPrioritize role, label, test ID and scoped locators; inspect ambiguity, frames and dynamic content. Avoid broad first() workarounds.\n\nDeliverable: Updated locators and evidence for stability.\n\nAgent rules: inspect AGENTS.md and relevant skills where present; preserve existing architecture, keep reference folders read-only, and follow configured plan/tool/deletion approvals. Validate only what the current environment actually supports and report results honestly."
  },
  {
    "title": "Configure Playwright Headed Execution for Manual PIN",
    "category": "Playwright & migration",
    "mode": "Agent",
    "purpose": "Support workflows that require human input.",
    "prompt": "Workspace [workspace]: use the folder configured with Enter path; do not require me to repeat its absolute path.\nTest scope: <workflow>\n\nTask: Support workflows that require human input.\nInspect current browser context and CI limitations. Configure headed runs and meaningful manual checkpoints without attempting to automate restricted PIN challenges.\n\nDeliverable: Execution configuration and operator instructions.\n\nAgent rules: inspect AGENTS.md and relevant skills where present; preserve existing architecture, keep reference folders read-only, and follow configured plan/tool/deletion approvals. Validate only what the current environment actually supports and report results honestly."
  },
  {
    "title": "Create Playwright Test Tag and Test-ID Runner",
    "category": "Playwright & migration",
    "mode": "Agent",
    "purpose": "Enable focused execution for features and individual cases.",
    "prompt": "Workspace [workspace]: use the folder configured with Enter path; do not require me to repeat its absolute path.\nExisting test IDs and tag scheme: <details>\n\nTask: Enable focused execution for features and individual cases.\nReuse project scripts/config. Design predictable grep/tag or metadata mapping, clear failure reports and safe defaults.\n\nDeliverable: Runner commands and example usage.\n\nAgent rules: inspect AGENTS.md and relevant skills where present; preserve existing architecture, keep reference folders read-only, and follow configured plan/tool/deletion approvals. Validate only what the current environment actually supports and report results honestly."
  },
  {
    "title": "Compare Migrated Playwright Coverage with Selenium Source",
    "category": "Playwright & migration",
    "mode": "Agent",
    "purpose": "Find dropped scenarios and assertions.",
    "prompt": "Workspace [workspace]: use the folder configured with Enter path; do not require me to repeat its absolute path.\nReference alias: <alias>; feature: <scope>\n\nTask: Find dropped scenarios and assertions.\nMatch source test intent from Reference [<alias>] to target coverage in Workspace [workspace], including data variants, auth and negative paths.\n\nDeliverable: Missing/partial/complete mapping and migration backlog.\n\nAgent rules: inspect AGENTS.md and relevant skills where present; preserve existing architecture, keep reference folders read-only, and follow configured plan/tool/deletion approvals. Validate only what the current environment actually supports and report results honestly."
  },
  {
    "title": "Diagnose Java Compilation Errors",
    "category": "Debugging & reliability",
    "mode": "Agent",
    "purpose": "Fix current compile errors without architecture rewrites.",
    "prompt": "Workspace [workspace]: use the folder configured with Enter path; do not require me to repeat its absolute path.\nCompiler output: <paste error>\n\nTask: Fix current compile errors without architecture rewrites.\nLocate exact symbols/imports/types and nearest related edits. Repair root causes and compile the affected module on Java 17.\n\nDeliverable: Files changed, error-to-fix map and compile result.\n\nAgent rules: inspect AGENTS.md and relevant skills where present; preserve existing architecture, keep reference folders read-only, and follow configured plan/tool/deletion approvals. Validate only what the current environment actually supports and report results honestly."
  },
  {
    "title": "Resolve Spring Boot Startup Failure",
    "category": "Debugging & reliability",
    "mode": "Agent",
    "purpose": "Investigate bean, configuration or environment problems.",
    "prompt": "Workspace [workspace]: use the folder configured with Enter path; do not require me to repeat its absolute path.\nStartup logs: <redacted stack trace>\n\nTask: Investigate bean, configuration or environment problems.\nIdentify first caused-by error, profiles, dependency injection and portable filesystem/database configuration. Avoid environment-specific hardcoding.\n\nDeliverable: Fix and verified startup instructions.\n\nAgent rules: inspect AGENTS.md and relevant skills where present; preserve existing architecture, keep reference folders read-only, and follow configured plan/tool/deletion approvals. Validate only what the current environment actually supports and report results honestly."
  },
  {
    "title": "Diagnose H2 Database Cross-OS Path Issues",
    "category": "Debugging & reliability",
    "mode": "Agent",
    "purpose": "Remove environment-dependent H2 startup failures.",
    "prompt": "Workspace [workspace]: use the folder configured with Enter path; do not require me to repeat its absolute path.\nOperating systems and error: <details>\n\nTask: Remove environment-dependent H2 startup failures.\nInspect JDBC URL, home/config path resolver, permissions, file locking and schema migration. Do not assume data may be deleted.\n\nDeliverable: Portable configuration and verification plan.\n\nAgent rules: inspect AGENTS.md and relevant skills where present; preserve existing architecture, keep reference folders read-only, and follow configured plan/tool/deletion approvals. Validate only what the current environment actually supports and report results honestly."
  },
  {
    "title": "Investigate Agent Tool Protocol Failure",
    "category": "Debugging & reliability",
    "mode": "Agent",
    "purpose": "Trace malformed or interrupted tool-call execution.",
    "prompt": "Workspace [workspace]: use the folder configured with Enter path; do not require me to repeat its absolute path.\nError and run step: <details>\n\nTask: Trace malformed or interrupted tool-call execution.\nInspect tool schema, response mapping, context limits, retries and failure propagation. Preserve diagnostic evidence and avoid infinite recovery loops.\n\nDeliverable: Root cause, specific fix and regression checks.\n\nAgent rules: inspect AGENTS.md and relevant skills where present; preserve existing architecture, keep reference folders read-only, and follow configured plan/tool/deletion approvals. Validate only what the current environment actually supports and report results honestly."
  },
  {
    "title": "Diagnose Long-Running Agent Execution",
    "category": "Debugging & reliability",
    "mode": "Agent",
    "purpose": "Explain why an approved run stalls.",
    "prompt": "Workspace [workspace]: use the folder configured with Enter path; do not require me to repeat its absolute path.\nRun ID, last action and logs: <details>\n\nTask: Explain why an approved run stalls.\nTrace planning, step state, model streaming, network timeout, tool execution, checkpoint and UI polling. Distinguish slow work from deadlock.\n\nDeliverable: Timeline, bottleneck and bounded recovery approach.\n\nAgent rules: inspect AGENTS.md and relevant skills where present; preserve existing architecture, keep reference folders read-only, and follow configured plan/tool/deletion approvals. Validate only what the current environment actually supports and report results honestly."
  },
  {
    "title": "Fix Model Connection or Proxy Errors",
    "category": "Debugging & reliability",
    "mode": "Agent",
    "purpose": "Resolve transport failures for the configured provider.",
    "prompt": "Workspace [workspace]: use the folder configured with Enter path; do not require me to repeat its absolute path.\nEndpoint type and redacted error: <details>\n\nTask: Resolve transport failures for the configured provider.\nInspect URL normalization, proxy routing, request/response formats, timeouts and TLS. Never print API keys.\n\nDeliverable: Config/code fix and connection verification.\n\nAgent rules: inspect AGENTS.md and relevant skills where present; preserve existing architecture, keep reference folders read-only, and follow configured plan/tool/deletion approvals. Validate only what the current environment actually supports and report results honestly."
  },
  {
    "title": "Investigate MCP-Enabled Chat Slowness",
    "category": "Debugging & reliability",
    "mode": "Agent",
    "purpose": "Identify the impact of MCP calls on response latency.",
    "prompt": "Workspace [workspace]: use the folder configured with Enter path; do not require me to repeat its absolute path.\nMCP name and observed timing: <details>\n\nTask: Identify the impact of MCP calls on response latency.\nTrace discovery, context search, call timeouts, parallelism and stream-start blocking. Compare equivalent prompts with MCP off/on.\n\nDeliverable: Call-by-call latency breakdown and targeted optimization.\n\nAgent rules: inspect AGENTS.md and relevant skills where present; preserve existing architecture, keep reference folders read-only, and follow configured plan/tool/deletion approvals. Validate only what the current environment actually supports and report results honestly."
  },
  {
    "title": "Diagnose Missing Indexed Project Files",
    "category": "Debugging & reliability",
    "mode": "Agent",
    "purpose": "Explain a mismatch between directory size and indexed count.",
    "prompt": "Workspace [workspace]: use the folder configured with Enter path; do not require me to repeat its absolute path.\nExpected and actual file counts: <numbers>\n\nTask: Explain a mismatch between directory size and indexed count.\nInspect depth limits, ignore rules, supported types, file size, read errors, scan completion and indexing job status. Do not assume all files are readable.\n\nDeliverable: Count reconciliation, exclusions and actionable fixes.\n\nAgent rules: inspect AGENTS.md and relevant skills where present; preserve existing architecture, keep reference folders read-only, and follow configured plan/tool/deletion approvals. Validate only what the current environment actually supports and report results honestly."
  },
  {
    "title": "Diagnose Context Window or Compaction Failures",
    "category": "Debugging & reliability",
    "mode": "Agent",
    "purpose": "Stop context overflow without losing essential task state.",
    "prompt": "Workspace [workspace]: use the folder configured with Enter path; do not require me to repeat its absolute path.\nModel limit and error: <details>\n\nTask: Stop context overflow without losing essential task state.\nInspect prompt size, tool-output truncation, checkpoint summaries, retrieval scope and fallback behavior. Preserve constraints and unresolved work.\n\nDeliverable: Measured bottleneck and safe context management changes.\n\nAgent rules: inspect AGENTS.md and relevant skills where present; preserve existing architecture, keep reference folders read-only, and follow configured plan/tool/deletion approvals. Validate only what the current environment actually supports and report results honestly."
  },
  {
    "title": "Perform Read-Only Pull Request Code Review",
    "category": "Code quality & security",
    "mode": "Agent",
    "purpose": "Find actionable defects without changing files.",
    "prompt": "Workspace [workspace]: use the folder configured with Enter path; do not require me to repeat its absolute path.\nChanged files or commit range: <scope>\n\nTask: Find actionable defects without changing files.\nInspect surrounding code, tests, compatibility and security. Report only evidence-backed findings with file/line references and concrete impact.\n\nDeliverable: Findings by severity, suggested fixes and test gaps.\n\nAgent rules: inspect AGENTS.md and relevant skills where present; preserve existing architecture, keep reference folders read-only, and follow configured plan/tool/deletion approvals. Validate only what the current environment actually supports and report results honestly."
  },
  {
    "title": "Refactor a Java Service Using SRP and DRY",
    "category": "Code quality & security",
    "mode": "Agent",
    "purpose": "Improve structure while preserving behavior.",
    "prompt": "Workspace [workspace]: use the folder configured with Enter path; do not require me to repeat its absolute path.\nTarget service: <name>\n\nTask: Improve structure while preserving behavior.\nIdentify mixed responsibilities and duplicated logic, keep public contracts stable and use focused extraction instead of a broad rewrite.\n\nDeliverable: Refactored code, behavior tests and design rationale.\n\nAgent rules: inspect AGENTS.md and relevant skills where present; preserve existing architecture, keep reference folders read-only, and follow configured plan/tool/deletion approvals. Validate only what the current environment actually supports and report results honestly."
  },
  {
    "title": "Remove Duplicate Test Framework Utilities",
    "category": "Code quality & security",
    "mode": "Agent",
    "purpose": "Consolidate redundant helpers carefully.",
    "prompt": "Workspace [workspace]: use the folder configured with Enter path; do not require me to repeat its absolute path.\nUtility classes: <scope>\n\nTask: Consolidate redundant helpers carefully.\nFind callers and semantic differences before merging, preserve compatibility and minimize changed imports.\n\nDeliverable: Canonical utility and migrated usages, with tests.\n\nAgent rules: inspect AGENTS.md and relevant skills where present; preserve existing architecture, keep reference folders read-only, and follow configured plan/tool/deletion approvals. Validate only what the current environment actually supports and report results honestly."
  },
  {
    "title": "Review Sensitive Data Logging",
    "category": "Code quality & security",
    "mode": "Agent",
    "purpose": "Prevent secrets from appearing in logs and reports.",
    "prompt": "Workspace [workspace]: use the folder configured with Enter path; do not require me to repeat its absolute path.\nScope: <services>\n\nTask: Prevent secrets from appearing in logs and reports.\nSearch request/response logging, exceptions, tracing and test fixtures for credentials, tokens, PII and key material.\n\nDeliverable: Risk locations, redaction changes and verification.\n\nAgent rules: inspect AGENTS.md and relevant skills where present; preserve existing architecture, keep reference folders read-only, and follow configured plan/tool/deletion approvals. Validate only what the current environment actually supports and report results honestly."
  },
  {
    "title": "Audit Destructive File Operations",
    "category": "Code quality & security",
    "mode": "Agent",
    "purpose": "Identify unsafe deletion and overwrite paths.",
    "prompt": "Workspace [workspace]: use the folder configured with Enter path; do not require me to repeat its absolute path.\nScope: <tools, scripts or services>\n\nTask: Identify unsafe deletion and overwrite paths.\nInspect Java file APIs, shell commands, process launches and external MCP actions. Distinguish guarded operations from paths that need OS-level sandboxing.\n\nDeliverable: Risk inventory, safeguards and remaining limitations.\n\nAgent rules: inspect AGENTS.md and relevant skills where present; preserve existing architecture, keep reference folders read-only, and follow configured plan/tool/deletion approvals. Validate only what the current environment actually supports and report results honestly."
  },
  {
    "title": "Review Dependency and Configuration Risks",
    "category": "Code quality & security",
    "mode": "Agent",
    "purpose": "Find outdated assumptions and unsafe defaults without speculative CVEs.",
    "prompt": "Workspace [workspace]: use the folder configured with Enter path; do not require me to repeat its absolute path.\nModules and config: <scope>\n\nTask: Find outdated assumptions and unsafe defaults without speculative CVEs.\nInspect actual build versions, pinned dependencies, repository rules, credentials and feature flags. Flag what needs external advisory verification.\n\nDeliverable: Evidence-backed remediation plan and verification commands.\n\nAgent rules: inspect AGENTS.md and relevant skills where present; preserve existing architecture, keep reference folders read-only, and follow configured plan/tool/deletion approvals. Validate only what the current environment actually supports and report results honestly."
  },
  {
    "title": "Add Regression Tests Before Refactoring",
    "category": "Code quality & security",
    "mode": "Agent",
    "purpose": "Protect critical behavior prior to edits.",
    "prompt": "Workspace [workspace]: use the folder configured with Enter path; do not require me to repeat its absolute path.\nComponent and expected behavior: <details>\n\nTask: Protect critical behavior prior to edits.\nCharacterize existing behavior, add small deterministic tests and verify baseline before making requested refactoring changes.\n\nDeliverable: Baseline tests, refactoring steps and final comparison.\n\nAgent rules: inspect AGENTS.md and relevant skills where present; preserve existing architecture, keep reference folders read-only, and follow configured plan/tool/deletion approvals. Validate only what the current environment actually supports and report results honestly."
  },
  {
    "title": "Improve Error Handling and User Messages",
    "category": "Code quality & security",
    "mode": "Agent",
    "purpose": "Make failures actionable without leaking internals.",
    "prompt": "Workspace [workspace]: use the folder configured with Enter path; do not require me to repeat its absolute path.\nFeature: <name>\n\nTask: Make failures actionable without leaking internals.\nTrace thrown errors to HTTP/UI, inspect current codes and recovery logic. Keep actionable user messages and logged diagnostic correlation.\n\nDeliverable: Updated error mapping and tested success/failure flows.\n\nAgent rules: inspect AGENTS.md and relevant skills where present; preserve existing architecture, keep reference folders read-only, and follow configured plan/tool/deletion approvals. Validate only what the current environment actually supports and report results honestly."
  },
  {
    "title": "Evaluate Cross-Platform Filesystem Portability",
    "category": "Code quality & security",
    "mode": "Agent",
    "purpose": "Ensure path and file handling is not OS-specific.",
    "prompt": "Workspace [workspace]: use the folder configured with Enter path; do not require me to repeat its absolute path.\nTargets: Windows, Linux and macOS\n\nTask: Ensure path and file handling is not OS-specific.\nInspect separators, case rules, symlinks, home directories, UTF-8, locks and executable assumptions. Avoid unverified 100% compatibility claims.\n\nDeliverable: Portable fixes and OS-specific test matrix.\n\nAgent rules: inspect AGENTS.md and relevant skills where present; preserve existing architecture, keep reference folders read-only, and follow configured plan/tool/deletion approvals. Validate only what the current environment actually supports and report results honestly."
  },
  {
    "title": "Summarise a Jira Epic and Its Linked Stories",
    "category": "MCP, Jira & Confluence",
    "mode": "Chat",
    "purpose": "Produce a scope summary using live MCP when configured.",
    "prompt": "Workspace [workspace]: use the folder configured with Enter path; do not require me to repeat its absolute path.\nJira epic: <key>\n\nTask: Produce a scope summary using live MCP when configured.\nFetch accessible story descriptions, status, acceptance criteria and dependencies. If MCP is unavailable, identify missing evidence instead of inventing Jira content.\n\nDeliverable: Scope summary, story map, blockers and linked keys.\n\nChat rules: answer from accessible files, attachments and enabled MCP sources; cite filenames, requirement sections or source identifiers where possible. Do not edit or delete workspace files."
  },
  {
    "title": "Compare Jira Acceptance Criteria with Implementation",
    "category": "MCP, Jira & Confluence",
    "mode": "Chat",
    "purpose": "Spot code gaps relative to an accessible Jira issue.",
    "prompt": "Workspace [workspace]: use the folder configured with Enter path; do not require me to repeat its absolute path.\nJira issue: <key>; module: <name>\n\nTask: Spot code gaps relative to an accessible Jira issue.\nRead Jira through configured MCP and inspect Workspace [workspace] code. Separate verified implemented behavior from inferred or missing coverage.\n\nDeliverable: Criteria-to-code traceability and concrete gaps.\n\nChat rules: answer from accessible files, attachments and enabled MCP sources; cite filenames, requirement sections or source identifiers where possible. Do not edit or delete workspace files."
  },
  {
    "title": "Generate Test Scenarios from Jira Stories",
    "category": "MCP, Jira & Confluence",
    "mode": "Chat",
    "purpose": "Turn accessible acceptance criteria into structured QA coverage.",
    "prompt": "Workspace [workspace]: use the folder configured with Enter path; do not require me to repeat its absolute path.\nJira keys: <keys>\n\nTask: Turn accessible acceptance criteria into structured QA coverage.\nRead descriptions and attachments available through MCP. Cover success, negative, boundary, permissions and transitions; call out image content that cannot be read.\n\nDeliverable: Requirement-linked test cases and unanswered questions.\n\nChat rules: answer from accessible files, attachments and enabled MCP sources; cite filenames, requirement sections or source identifiers where possible. Do not edit or delete workspace files."
  },
  {
    "title": "Summarise Confluence Design Documentation",
    "category": "MCP, Jira & Confluence",
    "mode": "Chat",
    "purpose": "Create a concise technical summary from an accessible page.",
    "prompt": "Workspace [workspace]: use the folder configured with Enter path; do not require me to repeat its absolute path.\nConfluence page or search phrase: <title/link>\n\nTask: Create a concise technical summary from an accessible page.\nUse configured MCP to retrieve relevant pages, preserve source links and distinguish document intent from verified code behavior.\n\nDeliverable: Architecture, interfaces, dependencies and decisions.\n\nChat rules: answer from accessible files, attachments and enabled MCP sources; cite filenames, requirement sections or source identifiers where possible. Do not edit or delete workspace files."
  },
  {
    "title": "Compare Confluence Design with Current Repository",
    "category": "MCP, Jira & Confluence",
    "mode": "Chat",
    "purpose": "Identify documentation drift.",
    "prompt": "Workspace [workspace]: use the folder configured with Enter path; do not require me to repeat its absolute path.\nConfluence design: <page>; code scope: <module>\n\nTask: Identify documentation drift.\nRead accessible Confluence content through MCP and inspect Workspace [workspace]. Highlight discrepancies supported by exact page and file evidence.\n\nDeliverable: Difference table and proposed corrections.\n\nChat rules: answer from accessible files, attachments and enabled MCP sources; cite filenames, requirement sections or source identifiers where possible. Do not edit or delete workspace files."
  },
  {
    "title": "Cross-Reference Jira and Confluence Requirements",
    "category": "MCP, Jira & Confluence",
    "mode": "Chat",
    "purpose": "Consolidate business and technical intent across systems.",
    "prompt": "Workspace [workspace]: use the folder configured with Enter path; do not require me to repeat its absolute path.\nJira keys and Confluence pages: <references>\n\nTask: Consolidate business and technical intent across systems.\nFetch available sources, map features and acceptance criteria and identify contradictions, missing links and unknowns.\n\nDeliverable: Unified requirements, traceability and clarification list.\n\nChat rules: answer from accessible files, attachments and enabled MCP sources; cite filenames, requirement sections or source identifiers where possible. Do not edit or delete workspace files."
  },
  {
    "title": "Prepare Release Test Scope from Jira",
    "category": "MCP, Jira & Confluence",
    "mode": "Chat",
    "purpose": "Define testing based on current issue status and changes.",
    "prompt": "Workspace [workspace]: use the folder configured with Enter path; do not require me to repeat its absolute path.\nFix version or sprint: <name>\n\nTask: Define testing based on current issue status and changes.\nRetrieve accessible stories/bugs and available code context. Prioritize by changed behavior and dependency risk without claiming unsupported release readiness.\n\nDeliverable: Test scope, regression areas and blockers.\n\nChat rules: answer from accessible files, attachments and enabled MCP sources; cite filenames, requirement sections or source identifiers where possible. Do not edit or delete workspace files."
  },
  {
    "title": "Investigate a Jira Bug Using Workspace Evidence",
    "category": "MCP, Jira & Confluence",
    "mode": "Chat",
    "purpose": "Connect a bug report to relevant code paths.",
    "prompt": "Workspace [workspace]: use the folder configured with Enter path; do not require me to repeat its absolute path.\nJira bug: <key>\n\nTask: Connect a bug report to relevant code paths.\nRead accessible steps/logs via MCP; trace code and existing tests in Workspace [workspace]. Do not modify files in Chat mode.\n\nDeliverable: Likely causes with evidence, reproduction and test recommendations.\n\nChat rules: answer from accessible files, attachments and enabled MCP sources; cite filenames, requirement sections or source identifiers where possible. Do not edit or delete workspace files."
  },
  {
    "title": "Create a Source-Cited Analysis Across MCP and Documents",
    "category": "MCP, Jira & Confluence",
    "mode": "Chat",
    "purpose": "Merge evidence from Jira, Confluence and uploaded specifications.",
    "prompt": "Workspace [workspace]: use the folder configured with Enter path; do not require me to repeat its absolute path.\nSources: <keys, pages, attached files>\n\nTask: Merge evidence from Jira, Confluence and uploaded specifications.\nRead accessible resources, compare claims, mark conflicts and missing permissions. Never invent unavailable sources.\n\nDeliverable: Source-linked analysis report with findings and open questions.\n\nChat rules: answer from accessible files, attachments and enabled MCP sources; cite filenames, requirement sections or source identifiers where possible. Do not edit or delete workspace files."
  },
  {
    "title": "Create an Editable Execution Plan Before Coding",
    "category": "Agent planning & operations",
    "mode": "Agent",
    "purpose": "Break a multi-step task into approvable work.",
    "prompt": "Workspace [workspace]: use the folder configured with Enter path; do not require me to repeat its absolute path.\nGoal: <deliverable>\n\nTask: Break a multi-step task into approvable work.\nExplore Workspace [workspace] and relevant read-only references. Propose file-level steps, risks, tests and completion criteria; wait for plan approval if enabled.\n\nDeliverable: Concise plan with expected changes and verification steps.\n\nAgent rules: inspect AGENTS.md and relevant skills where present; preserve existing architecture, keep reference folders read-only, and follow configured plan/tool/deletion approvals. Validate only what the current environment actually supports and report results honestly."
  },
  {
    "title": "Implement an Approved Plan Step by Step",
    "category": "Agent planning & operations",
    "mode": "Agent",
    "purpose": "Execute a scoped task without uncontrolled changes.",
    "prompt": "Workspace [workspace]: use the folder configured with Enter path; do not require me to repeat its absolute path.\nGoal and approved steps: <details>\n\nTask: Execute a scoped task without uncontrolled changes.\nStay within the approved plan and permissions, use only necessary tools, checkpoint progress and stop on blocked destructive operations.\n\nDeliverable: Changed files, step outcomes and final verification.\n\nAgent rules: inspect AGENTS.md and relevant skills where present; preserve existing architecture, keep reference folders read-only, and follow configured plan/tool/deletion approvals. Validate only what the current environment actually supports and report results honestly."
  },
  {
    "title": "Resume a Partially Completed Task Safely",
    "category": "Agent planning & operations",
    "mode": "Agent",
    "purpose": "Continue from verified work rather than restart blindly.",
    "prompt": "Workspace [workspace]: use the folder configured with Enter path; do not require me to repeat its absolute path.\nPrevious run or unfinished goal: <details>\n\nTask: Continue from verified work rather than restart blindly.\nInspect current repository state and available checkpoints, distinguish completed and pending steps and review uncommitted changes before continuing.\n\nDeliverable: Resume plan, completed remainder and verification.\n\nAgent rules: inspect AGENTS.md and relevant skills where present; preserve existing architecture, keep reference folders read-only, and follow configured plan/tool/deletion approvals. Validate only what the current environment actually supports and report results honestly."
  },
  {
    "title": "Rerun Only Failed Test Scopes",
    "category": "Agent planning & operations",
    "mode": "Agent",
    "purpose": "Avoid rerunning the entire suite unnecessarily.",
    "prompt": "Workspace [workspace]: use the folder configured with Enter path; do not require me to repeat its absolute path.\nFailed test IDs, tags or report: <details>\n\nTask: Avoid rerunning the entire suite unnecessarily.\nMap failures to current test names and framework runner, rerun only supported failed scopes, then verify original aggregate status.\n\nDeliverable: Rerun commands, passing/failing IDs and final summary.\n\nAgent rules: inspect AGENTS.md and relevant skills where present; preserve existing architecture, keep reference folders read-only, and follow configured plan/tool/deletion approvals. Validate only what the current environment actually supports and report results honestly."
  },
  {
    "title": "Analyse a Workspace Without Editing Files",
    "category": "Agent planning & operations",
    "mode": "Agent",
    "purpose": "Perform exploration with no writes.",
    "prompt": "Workspace [workspace]: use the folder configured with Enter path; do not require me to repeat its absolute path.\nQuestions: <architecture, quality or behavior>\n\nTask: Perform exploration with no writes.\nRead indexed code and source as available; use read-only tools and flag coverage limits. Do not modify, delete or generate repository files.\n\nDeliverable: Evidence-backed report with file references.\n\nAgent rules: inspect AGENTS.md and relevant skills where present; preserve existing architecture, keep reference folders read-only, and follow configured plan/tool/deletion approvals. Validate only what the current environment actually supports and report results honestly."
  },
  {
    "title": "Write Code Changes Only After Plan Approval",
    "category": "Agent planning & operations",
    "mode": "Agent",
    "purpose": "Make execution approval explicit.",
    "prompt": "Workspace [workspace]: use the folder configured with Enter path; do not require me to repeat its absolute path.\nChange request: <details>\n\nTask: Make execution approval explicit.\nPropose and present a bounded file-level plan. Do not start edits or command execution before approval; respect separate deletion confirmation.\n\nDeliverable: Plan, approved implementation and tested results.\n\nAgent rules: inspect AGENTS.md and relevant skills where present; preserve existing architecture, keep reference folders read-only, and follow configured plan/tool/deletion approvals. Validate only what the current environment actually supports and report results honestly."
  },
  {
    "title": "Request Safe File Cleanup with Explicit Approval",
    "category": "Agent planning & operations",
    "mode": "Agent",
    "purpose": "Find candidates but never delete silently.",
    "prompt": "Workspace [workspace]: use the folder configured with Enter path; do not require me to repeat its absolute path.\nCleanup target: <paths or patterns>\n\nTask: Find candidates but never delete silently.\nEnumerate exact paths and reasons, explain downstream impact and prepare a rollback. Require individual deletion approval when enabled.\n\nDeliverable: Reviewable delete list and verified post-approval result.\n\nAgent rules: inspect AGENTS.md and relevant skills where present; preserve existing architecture, keep reference folders read-only, and follow configured plan/tool/deletion approvals. Validate only what the current environment actually supports and report results honestly."
  },
  {
    "title": "Perform Final Build and Focused Verification",
    "category": "Agent planning & operations",
    "mode": "Agent",
    "purpose": "Validate a coherent batch of edits once ready.",
    "prompt": "Workspace [workspace]: use the folder configured with Enter path; do not require me to repeat its absolute path.\nChanged module and tests: <details>\n\nTask: Validate a coherent batch of edits once ready.\nInspect diff, run relevant compile/lint/test commands supported by environment, fix introduced failures and rerun affected checks.\n\nDeliverable: Pass/fail evidence, remaining blockers and final diff summary.\n\nAgent rules: inspect AGENTS.md and relevant skills where present; preserve existing architecture, keep reference folders read-only, and follow configured plan/tool/deletion approvals. Validate only what the current environment actually supports and report results honestly."
  },
  {
    "title": "Review Changes and Produce an Agent Handoff",
    "category": "Agent planning & operations",
    "mode": "Agent",
    "purpose": "Provide a usable record for the next developer.",
    "prompt": "Workspace [workspace]: use the folder configured with Enter path; do not require me to repeat its absolute path.\nTask or run: <details>\n\nTask: Provide a usable record for the next developer.\nInspect actual modifications and execution evidence. Distinguish verified outcomes, partial work, skipped tests and external blockers.\n\nDeliverable: Handoff with files, decisions, tests and next steps.\n\nAgent rules: inspect AGENTS.md and relevant skills where present; preserve existing architecture, keep reference folders read-only, and follow configured plan/tool/deletion approvals. Validate only what the current environment actually supports and report results honestly."
  },
  {
    "title": "Diagnose Jenkins Pipeline Test Failures",
    "category": "CI, performance & test data",
    "mode": "Agent",
    "purpose": "Isolate pipeline, infrastructure and test causes.",
    "prompt": "Workspace [workspace]: use the folder configured with Enter path; do not require me to repeat its absolute path.\nJob and redacted logs: <details>\n\nTask: Isolate pipeline, infrastructure and test causes.\nInspect Jenkinsfile, Maven/Node options, agents, secrets references, test reports and network endpoints. Avoid treating local success as CI proof.\n\nDeliverable: Root-cause evidence and validated pipeline changes.\n\nAgent rules: inspect AGENTS.md and relevant skills where present; preserve existing architecture, keep reference folders read-only, and follow configured plan/tool/deletion approvals. Validate only what the current environment actually supports and report results honestly."
  },
  {
    "title": "Validate Selenium Grid Connectivity from Jenkins",
    "category": "CI, performance & test data",
    "mode": "Agent",
    "purpose": "Check network and Grid prerequisites.",
    "prompt": "Workspace [workspace]: use the folder configured with Enter path; do not require me to repeat its absolute path.\nGrid URL and Jenkins agent: <details>\n\nTask: Check network and Grid prerequisites.\nTrace DNS, routing, HTTP status, node registration, browser versions and CDP compatibility using accessible diagnostics.\n\nDeliverable: Connectivity checklist and failure classification.\n\nAgent rules: inspect AGENTS.md and relevant skills where present; preserve existing architecture, keep reference folders read-only, and follow configured plan/tool/deletion approvals. Validate only what the current environment actually supports and report results honestly."
  },
  {
    "title": "Design a Java API Load-Test Scenario",
    "category": "CI, performance & test data",
    "mode": "Agent",
    "purpose": "Plan reproducible API performance coverage.",
    "prompt": "Workspace [workspace]: use the folder configured with Enter path; do not require me to repeat its absolute path.\nEndpoint, users and target rate: <details>\n\nTask: Plan reproducible API performance coverage.\nDefine realistic workload, pacing, data isolation, latency percentiles, error thresholds and environment limits. Use existing approved tooling.\n\nDeliverable: Load-test design, execution plan and metrics.\n\nAgent rules: inspect AGENTS.md and relevant skills where present; preserve existing architecture, keep reference folders read-only, and follow configured plan/tool/deletion approvals. Validate only what the current environment actually supports and report results honestly."
  },
  {
    "title": "Create a Million-Event Kafka Ingestion Test Plan",
    "category": "CI, performance & test data",
    "mode": "Agent",
    "purpose": "Measure throughput and end-to-end integrity.",
    "prompt": "Workspace [workspace]: use the folder configured with Enter path; do not require me to repeat its absolute path.\nEvent schema and target volume: <details>\n\nTask: Measure throughput and end-to-end integrity.\nDefine generation rate, unique IDs, producer acknowledgements, downstream counts, lag, dead letters and reconciliation.\n\nDeliverable: Workload parameters, metrics and pass/fail criteria.\n\nAgent rules: inspect AGENTS.md and relevant skills where present; preserve existing architecture, keep reference folders read-only, and follow configured plan/tool/deletion approvals. Validate only what the current environment actually supports and report results honestly."
  },
  {
    "title": "Generate Parameterized JSON Test Events",
    "category": "CI, performance & test data",
    "mode": "Agent",
    "purpose": "Produce safe, unique event payloads from templates.",
    "prompt": "Workspace [workspace]: use the folder configured with Enter path; do not require me to repeat its absolute path.\nTemplate files and fields: <details>\n\nTask: Produce safe, unique event payloads from templates.\nInspect existing schema and data generator, derive deterministic unique IDs, legal edge values and invalid variants without real customer data.\n\nDeliverable: Generator updates or fixture set and schema checks.\n\nAgent rules: inspect AGENTS.md and relevant skills where present; preserve existing architecture, keep reference folders read-only, and follow configured plan/tool/deletion approvals. Validate only what the current environment actually supports and report results honestly."
  },
  {
    "title": "Check Data Consistency Across Kafka, Flink and Elasticsearch",
    "category": "CI, performance & test data",
    "mode": "Agent",
    "purpose": "Design end-to-end reconciliation checks.",
    "prompt": "Workspace [workspace]: use the folder configured with Enter path; do not require me to repeat its absolute path.\nEvent IDs and time window: <details>\n\nTask: Design end-to-end reconciliation checks.\nInspect actual pipeline, ingestion delays, transforms, deduplication, counts and search refresh behavior. Avoid assuming immediate consistency.\n\nDeliverable: Reconciliation checks and discrepancy taxonomy.\n\nAgent rules: inspect AGENTS.md and relevant skills where present; preserve existing architecture, keep reference folders read-only, and follow configured plan/tool/deletion approvals. Validate only what the current environment actually supports and report results honestly."
  },
  {
    "title": "Optimise Slow Test Execution Without Losing Coverage",
    "category": "CI, performance & test data",
    "mode": "Agent",
    "purpose": "Find reliable runtime reductions.",
    "prompt": "Workspace [workspace]: use the folder configured with Enter path; do not require me to repeat its absolute path.\nSuite and baseline timings: <details>\n\nTask: Find reliable runtime reductions.\nIdentify duplicate setup, serial bottlenecks, environment waits, flaky retries and expensive fixtures. Preserve assertion and scenario coverage.\n\nDeliverable: Prioritized optimization changes and comparable timings.\n\nAgent rules: inspect AGENTS.md and relevant skills where present; preserve existing architecture, keep reference folders read-only, and follow configured plan/tool/deletion approvals. Validate only what the current environment actually supports and report results honestly."
  },
  {
    "title": "Build a Cross-Platform CI Validation Matrix",
    "category": "CI, performance & test data",
    "mode": "Agent",
    "purpose": "Plan reproducible checks across environments.",
    "prompt": "Workspace [workspace]: use the folder configured with Enter path; do not require me to repeat its absolute path.\nPlatforms: <Windows, Linux and macOS>\n\nTask: Plan reproducible checks across environments.\nInspect Java version, scripts, shell assumptions, file paths, ports, permissions and workflow triggers. Report what can and cannot be executed here.\n\nDeliverable: CI matrix and verified environment-specific steps.\n\nAgent rules: inspect AGENTS.md and relevant skills where present; preserve existing architecture, keep reference folders read-only, and follow configured plan/tool/deletion approvals. Validate only what the current environment actually supports and report results honestly."
  },
  {
    "title": "Create Test Report with Failure Grouping",
    "category": "CI, performance & test data",
    "mode": "Agent",
    "purpose": "Turn machine test output into actionable diagnosis.",
    "prompt": "Workspace [workspace]: use the folder configured with Enter path; do not require me to repeat its absolute path.\nJUnit/TestNG/Playwright report: <file>\n\nTask: Turn machine test output into actionable diagnosis.\nParse genuine run results, group by root cause versus symptom and identify flaky/repeated failures. Do not fabricate absent logs.\n\nDeliverable: Counts, grouped failures and rerun recommendations.\n\nAgent rules: inspect AGENTS.md and relevant skills where present; preserve existing architecture, keep reference folders read-only, and follow configured plan/tool/deletion approvals. Validate only what the current environment actually supports and report results honestly."
  },
  {
    "title": "Create Functional Documentation for an Existing Application",
    "category": "Documentation & reporting",
    "mode": "Chat",
    "purpose": "Document what the product actually does.",
    "prompt": "Workspace [workspace]: use the folder configured with Enter path; do not require me to repeat its absolute path.\nTarget modules and audience: <details>\n\nTask: Document what the product actually does.\nTrace real user journeys, roles, business rules, error states and data dependencies in Workspace [workspace]. Separate documented behavior from code assumptions.\n\nDeliverable: Structured functional guide and source references.\n\nChat rules: answer from accessible files, attachments and enabled MCP sources; cite filenames, requirement sections or source identifiers where possible. Do not edit or delete workspace files."
  },
  {
    "title": "Create Detailed Technical Documentation from Code",
    "category": "Documentation & reporting",
    "mode": "Chat",
    "purpose": "Produce a maintainable codebase guide.",
    "prompt": "Workspace [workspace]: use the folder configured with Enter path; do not require me to repeat its absolute path.\nScope: <repository or module>\n\nTask: Produce a maintainable codebase guide.\nInspect build, entry points, components, APIs, persistence, integrations, jobs, observability and deployment. Flag inferred behavior.\n\nDeliverable: Technical guide with component inventory and architecture flows.\n\nChat rules: answer from accessible files, attachments and enabled MCP sources; cite filenames, requirement sections or source identifiers where possible. Do not edit or delete workspace files."
  },
  {
    "title": "Document Class Responsibilities and Call Graph",
    "category": "Documentation & reporting",
    "mode": "Chat",
    "purpose": "Explain an unfamiliar module to developers.",
    "prompt": "Workspace [workspace]: use the folder configured with Enter path; do not require me to repeat its absolute path.\nPackage or class: <name>\n\nTask: Explain an unfamiliar module to developers.\nTrace actual methods, injected dependencies, callers, state and exceptions, not merely package names.\n\nDeliverable: Class inventory, responsibility map and key call paths.\n\nChat rules: answer from accessible files, attachments and enabled MCP sources; cite filenames, requirement sections or source identifiers where possible. Do not edit or delete workspace files."
  },
  {
    "title": "Draft README for Java 17 Project",
    "category": "Documentation & reporting",
    "mode": "Chat",
    "purpose": "Create a practical onboarding document.",
    "prompt": "Workspace [workspace]: use the folder configured with Enter path; do not require me to repeat its absolute path.\nProject and target audience: <details>\n\nTask: Create a practical onboarding document.\nRead actual pom.xml, application properties, run scripts, ports, environment requirements and tests. Do not invent setup commands.\n\nDeliverable: Single structured README with tested or explicitly unverified commands.\n\nChat rules: answer from accessible files, attachments and enabled MCP sources; cite filenames, requirement sections or source identifiers where possible. Do not edit or delete workspace files."
  },
  {
    "title": "Write Chat and Agent User Guide",
    "category": "Documentation & reporting",
    "mode": "Chat",
    "purpose": "Explain how to operate the current Eliya build.",
    "prompt": "Workspace [workspace]: use the folder configured with Enter path; do not require me to repeat its absolute path.\nFocus: <all modes or named features>\n\nTask: Explain how to operate the current Eliya build.\nDescribe settings, manual folder paths, aliases, prompts, uploads, indexing, plan approval, fallback and deletion protection based on actual UI behavior.\n\nDeliverable: Task-oriented walkthrough and troubleshooting notes.\n\nChat rules: answer from accessible files, attachments and enabled MCP sources; cite filenames, requirement sections or source identifiers where possible. Do not edit or delete workspace files."
  },
  {
    "title": "Document APIs with Example Requests and Responses",
    "category": "Documentation & reporting",
    "mode": "Chat",
    "purpose": "Create an evidence-based API reference.",
    "prompt": "Workspace [workspace]: use the folder configured with Enter path; do not require me to repeat its absolute path.\nControllers or endpoints: <scope>\n\nTask: Create an evidence-based API reference.\nInspect DTOs, validation, HTTP methods and exception mapping. Use synthetic data and redact any secrets.\n\nDeliverable: Endpoint reference, samples and error cases.\n\nChat rules: answer from accessible files, attachments and enabled MCP sources; cite filenames, requirement sections or source identifiers where possible. Do not edit or delete workspace files."
  },
  {
    "title": "Build an Incident Root Cause Analysis Report",
    "category": "Documentation & reporting",
    "mode": "Chat",
    "purpose": "Convert a reproducible failure into an actionable RCA.",
    "prompt": "Workspace [workspace]: use the folder configured with Enter path; do not require me to repeat its absolute path.\nIncident window, logs and observed impact: <details>\n\nTask: Convert a reproducible failure into an actionable RCA.\nUse timestamps and code/log evidence; distinguish root cause, trigger, contributing factors and unverified assumptions.\n\nDeliverable: Timeline, impact, cause, remediation and prevention.\n\nChat rules: answer from accessible files, attachments and enabled MCP sources; cite filenames, requirement sections or source identifiers where possible. Do not edit or delete workspace files."
  },
  {
    "title": "Create a Change Impact and Regression Scope Report",
    "category": "Documentation & reporting",
    "mode": "Chat",
    "purpose": "Assess risk from a proposed or completed change.",
    "prompt": "Workspace [workspace]: use the folder configured with Enter path; do not require me to repeat its absolute path.\nChange request or diff: <details>\n\nTask: Assess risk from a proposed or completed change.\nTrace affected dependencies, APIs, data transformations, UI and existing tests. Separate direct impact from plausible downstream impact.\n\nDeliverable: Impact map, regression priorities and assumptions.\n\nChat rules: answer from accessible files, attachments and enabled MCP sources; cite filenames, requirement sections or source identifiers where possible. Do not edit or delete workspace files."
  },
  {
    "title": "Summarise Agent Work into an Executive Status Update",
    "category": "Documentation & reporting",
    "mode": "Chat",
    "purpose": "Report progress without overstating completion.",
    "prompt": "Workspace [workspace]: use the folder configured with Enter path; do not require me to repeat its absolute path.\nRun ID, plan or change set: <details>\n\nTask: Report progress without overstating completion.\nUse actual steps, files changed, build logs and unresolved blocks. Distinguish completed, failed and unverified work.\n\nDeliverable: Short summary, evidence, remaining risks and next actions.\n\nChat rules: answer from accessible files, attachments and enabled MCP sources; cite filenames, requirement sections or source identifiers where possible. Do not edit or delete workspace files."
  }
];

// Practical workflows; use these directly from Prompt Factory.
const ELIYA_REAL_WORLD_PROMPTS = [
  {
    "title": "Playwright TS — Generate Tests for an Existing Feature",
    "category": "Playwright · create & migrate",
    "mode": "Agent",
    "purpose": "Add maintainable test coverage to an existing Playwright TypeScript project.",
    "prompt": "Workspace [workspace]: use the configured writable project. Reference paths, if explicitly named, are read-only.\nFeature / file: <feature or test path>\nScenarios: <acceptance criteria>\n\nTask: Inspect package.json, playwright.config, fixtures, page objects and comparable specs; add positive, negative and boundary scenarios, stable locators and assertions.\n\nWorkflow: Inspect project instructions and existing conventions first; use real paths and available tools, never invent results. Use current framework style; reuse fixtures/data. Run only the changed spec after edits. Do not run a full suite unless requested.\n\nDeliverable: Changed spec/page-object files, case-to-requirement mapping and passing targeted run.\n\nSafety: Make only changes needed for this task; preserve existing behaviour elsewhere. Report exact commands, results and environment blockers."
  },
  {
    "title": "Playwright TS — Add a Single Test Case to Existing Spec",
    "category": "Playwright · create & migrate",
    "mode": "Agent",
    "purpose": "Add one real scenario without duplicating coverage.",
    "prompt": "Workspace [workspace]: use the configured writable project. Reference paths, if explicitly named, are read-only.\nSpec: <tests/login.spec.ts>\nScenario: <test name and steps>\nExpected: <outcome>\n\nTask: Read the named spec and its fixtures; insert one test in the correct describe block, using existing login/session and POM helpers.\n\nWorkflow: Inspect project instructions and existing conventions first; use real paths and available tools, never invent results. Avoid unrelated refactoring and avoid creating new helpers unless existing abstractions cannot express the scenario.\n\nDeliverable: One focused test addition, precise path and targeted execution results.\n\nSafety: Make only changes needed for this task; preserve existing behaviour elsewhere. Report exact commands, results and environment blockers."
  },
  {
    "title": "Playwright TS — Create Page Object for a Screen",
    "category": "Playwright · create & migrate",
    "mode": "Agent",
    "purpose": "Introduce a reusable page object matched to the project structure.",
    "prompt": "Workspace [workspace]: use the configured writable project. Reference paths, if explicitly named, are read-only.\nScreen: <screen name>\nExisting spec(s): <file paths>\n\nTask: Inspect current locator strategy and page objects; add an idiomatic typed page object with accessible/testId locators and reusable methods, update only affected specs.\n\nWorkflow: Inspect project instructions and existing conventions first; use real paths and available tools, never invent results. Prefer getByRole/getByLabel/getByTestId over unstable CSS. Avoid hardcoded waits and unnecessary wrappers.\n\nDeliverable: Page object and updated tests with a passing targeted check.\n\nSafety: Make only changes needed for this task; preserve existing behaviour elsewhere. Report exact commands, results and environment blockers."
  },
  {
    "title": "Playwright TS — Generate Data-Driven Tests from Excel",
    "category": "Playwright · create & migrate",
    "mode": "Agent",
    "purpose": "Preserve Excel-driven functional scenarios during automation.",
    "prompt": "Workspace [workspace]: use the configured writable project. Reference paths, if explicitly named, are read-only.\nExcel source: <relative file>\nSheet / columns: <sheet and mappings>\nFeature: <feature>\n\nTask: Inspect existing Excel readers and test data handling; implement or reuse a typed reader, isolate test data by case, and create parameterized scenarios.\n\nWorkflow: Inspect project instructions and existing conventions first; use real paths and available tools, never invent results. Do not mutate the source Excel; avoid logging personal/test secrets; do not multiply worker-shared state.\n\nDeliverable: Reusable reader only if needed, mapped test rows, scenario specs and sample targeted run.\n\nSafety: Make only changes needed for this task; preserve existing behaviour elsewhere. Report exact commands, results and environment blockers."
  },
  {
    "title": "Playwright TS — Migrate One Selenium Java Feature",
    "category": "Playwright · create & migrate",
    "mode": "Agent",
    "purpose": "Migrate a feature from a named read-only Java Selenium reference.",
    "prompt": "Workspace [workspace]: use the configured writable project. Reference paths, if explicitly named, are read-only.\nReference [LegacySelenium]: read-only source project\nSource feature: <feature/class>\nTarget module: <module>\n\nTask: Use resource_catalog to resolve LegacySelenium. Inspect Java test steps, Cucumber scenario outlines, TestNG config, POMs and test data, then map to existing Playwright TypeScript conventions.\n\nWorkflow: Inspect project instructions and existing conventions first; use real paths and available tools, never invent results. Preserve business assertions, headed/MFA interactions and data semantics. Do not copy Java waits or overwrite existing target tests.\n\nDeliverable: Coverage matrix, migrated spec/POM/data changes, explicit unmatched cases and targeted results.\n\nSafety: Make only changes needed for this task; preserve existing behaviour elsewhere. Report exact commands, results and environment blockers."
  },
  {
    "title": "Playwright TS — Migrate Multiple Selenium Features in Batches",
    "category": "Playwright · create & migrate",
    "mode": "Agent",
    "purpose": "Manage large Java Selenium migrations feature by feature.",
    "prompt": "Workspace [workspace]: use the configured writable project. Reference paths, if explicitly named, are read-only.\nReference [LegacySelenium]: read-only legacy project\nFeature list: <comma-separated modules>\nOutput location: <path>\n\nTask: Inventory source cases and target equivalents; create a case-level work ledger, migrate one bounded feature batch at a time using target fixtures and shared POMs, and record created/failed/skipped coverage.\n\nWorkflow: Inspect project instructions and existing conventions first; use real paths and available tools, never invent results. Never claim complete if source cases remain unmapped; rerun failed subsets after fixes, not every test after each edit.\n\nDeliverable: Migration coverage per feature, file paths, failed work queue and verified final tests.\n\nSafety: Make only changes needed for this task; preserve existing behaviour elsewhere. Report exact commands, results and environment blockers."
  },
  {
    "title": "Playwright TS — Convert Cucumber Feature to Test Specs",
    "category": "Playwright · create & migrate",
    "mode": "Agent",
    "purpose": "Convert Gherkin scenarios and outlines into native Playwright tests.",
    "prompt": "Workspace [workspace]: use the configured writable project. Reference paths, if explicitly named, are read-only.\nReference [LegacySelenium]: read-only features/step definitions\nFeature: <feature file>\n\nTask: Read actual Scenario/Outline/Examples/Background and step definitions; preserve scenario tags and input rows where useful; implement Playwright test.describe/test cases and fixtures.\n\nWorkflow: Inspect project instructions and existing conventions first; use real paths and available tools, never invent results. Retain acceptance criteria; report unsupported pending steps and manual CAPTCHA/MFA needs instead of bypassing them.\n\nDeliverable: Gherkin-to-test matrix, created spec(s), mapped data and targeted test result.\n\nSafety: Make only changes needed for this task; preserve existing behaviour elsewhere. Report exact commands, results and environment blockers."
  },
  {
    "title": "Playwright TS — Generate API Tests Using Request Context",
    "category": "Playwright · create & migrate",
    "mode": "Agent",
    "purpose": "Add Playwright APIRequestContext tests using configured base URL.",
    "prompt": "Workspace [workspace]: use the configured writable project. Reference paths, if explicitly named, are read-only.\nEndpoint / method: <route and HTTP verb>\nContract: <request/response expectations>\n\nTask: Inspect existing API fixtures, headers and auth setup; add response schema and status checks plus validation/error cases.\n\nWorkflow: Inspect project instructions and existing conventions first; use real paths and available tools, never invent results. Reuse credentials via environment configuration; do not embed tokens in code or output.\n\nDeliverable: API spec path, data setup, assertions and targeted execution.\n\nSafety: Make only changes needed for this task; preserve existing behaviour elsewhere. Report exact commands, results and environment blockers."
  },
  {
    "title": "Playwright TS — Add Visual Regression Test",
    "category": "Playwright · create & migrate",
    "mode": "Agent",
    "purpose": "Add a visual check that is stable across CI environments.",
    "prompt": "Workspace [workspace]: use the configured writable project. Reference paths, if explicitly named, are read-only.\nPage/component: <name>\nViewport / browser: <details>\n\nTask: Inspect existing screenshots and configuration; implement locator/page screenshot assertion with stable ready conditions, controlled animations and repeatable fixture data.\n\nWorkflow: Inspect project instructions and existing conventions first; use real paths and available tools, never invent results. Do not blindly overwrite established baselines; identify dynamic fields requiring masking.\n\nDeliverable: Visual spec and documented baseline update command, with actual check result.\n\nSafety: Make only changes needed for this task; preserve existing behaviour elsewhere. Report exact commands, results and environment blockers."
  },
  {
    "title": "Playwright TS — Add Authentication and Reusable Login Fixture",
    "category": "Playwright · framework",
    "mode": "Agent",
    "purpose": "Reduce login duplication without bypassing OTP or PIN.",
    "prompt": "Workspace [workspace]: use the configured writable project. Reference paths, if explicitly named, are read-only.\nLogin flow: <path or test>\nEnvironment: <local or CI>\n\nTask: Inspect existing setup and secrets mechanism; add a scoped auth fixture or storageState setup as appropriate, and preserve headed/manual approval where needed.\n\nWorkflow: Inspect project instructions and existing conventions first; use real paths and available tools, never invent results. Do not attempt to bypass MFA/CAPTCHA; redact credentials and never commit storageState secrets.\n\nDeliverable: Reusable login implementation, affected specs and validation result.\n\nSafety: Make only changes needed for this task; preserve existing behaviour elsewhere. Report exact commands, results and environment blockers."
  },
  {
    "title": "Playwright TS — Run One Spec File",
    "category": "Playwright · run & fix",
    "mode": "Agent",
    "purpose": "Run only a named Playwright spec and report real test results.",
    "prompt": "Workspace [workspace]: use the configured writable project. Reference paths, if explicitly named, are read-only.\nSpec file: <tests/login.spec.ts>\nProject / browser: <chromium or configured project>\n\nTask: Inspect package.json and playwright.config, choose the installed project’s test command and run only the requested spec.\n\nWorkflow: Inspect project instructions and existing conventions first; use real paths and available tools, never invent results. Use the project’s configured runner, browser and base URL; do not edit production/test code unless explicitly requested.\n\nDeliverable: Executed command, passed/failed/skipped counts and failing steps with trace/report paths when available.\n\nSafety: Make only changes needed for this task; preserve existing behaviour elsewhere. Report exact commands, results and environment blockers."
  },
  {
    "title": "Playwright TS — Run One Named Test Using -g",
    "category": "Playwright · run & fix",
    "mode": "Agent",
    "purpose": "Run a single test title inside a spec without full-suite execution.",
    "prompt": "Workspace [workspace]: use the configured writable project. Reference paths, if explicitly named, are read-only.\nSpec: <tests/login.spec.ts>\nTest title or regex: <exact test name>\nBrowser: <project>\n\nTask: Confirm the exact test title, inspect configured scripts and use an appropriate npx playwright test <spec> -g <title> invocation.\n\nWorkflow: Inspect project instructions and existing conventions first; use real paths and available tools, never invent results. Quote shell arguments correctly on the host OS; do not run other specs or silently change code.\n\nDeliverable: Exact CLI invocation, matching test count, result and failure detail.\n\nSafety: Make only changes needed for this task; preserve existing behaviour elsewhere. Report exact commands, results and environment blockers."
  },
  {
    "title": "Playwright TS — Run Tests by @Tag",
    "category": "Playwright · run & fix",
    "mode": "Agent",
    "purpose": "Execute a tagged smoke, sanity or regression subset.",
    "prompt": "Workspace [workspace]: use the configured writable project. Reference paths, if explicitly named, are read-only.\nTag: <@smoke or @login>\nScope: <folder or feature>\n\nTask: Inspect how tests encode tags in this project, then use the supported grep/tag filter and project configuration.\n\nWorkflow: Inspect project instructions and existing conventions first; use real paths and available tools, never invent results. List matching test names first when tag conventions are ambiguous; do not accidentally invoke the entire suite.\n\nDeliverable: Command, selected scenarios and outcome with traces for failures.\n\nSafety: Make only changes needed for this task; preserve existing behaviour elsewhere. Report exact commands, results and environment blockers."
  },
  {
    "title": "Playwright TS — Run a Single Test in Headed Mode",
    "category": "Playwright · run & fix",
    "mode": "Agent",
    "purpose": "Preserve visible browser steps for manual PIN, OK and MFA.",
    "prompt": "Workspace [workspace]: use the configured writable project. Reference paths, if explicitly named, are read-only.\nSpec / test: <path and title>\nBrowser: <project>\n\nTask: Inspect Playwright config; run the selected test with --headed or the repository’s configured headed script and give the user time to complete the manual interaction.\n\nWorkflow: Inspect project instructions and existing conventions first; use real paths and available tools, never invent results. Do not switch to headless when manual input is needed; never bypass authentication challenges.\n\nDeliverable: Command, actual results and any required manual step.\n\nSafety: Make only changes needed for this task; preserve existing behaviour elsewhere. Report exact commands, results and environment blockers."
  },
  {
    "title": "Playwright TS — Debug Failing Test with Trace and Screenshot",
    "category": "Playwright · run & fix",
    "mode": "Agent",
    "purpose": "Locate the actual cause of one failing Playwright test.",
    "prompt": "Workspace [workspace]: use the configured writable project. Reference paths, if explicitly named, are read-only.\nFailing spec/title: <path and test>\nFailure log: <paste log or link to local trace>\n\nTask: Inspect the failure, snapshots, attachments, trace/trace.zip and the test/page object. Reproduce in a focused headed or trace-enabled run.\n\nWorkflow: Inspect project instructions and existing conventions first; use real paths and available tools, never invent results. Distinguish app defects from automation/environment failures; avoid blind retry as a fix.\n\nDeliverable: Root-cause evidence, minimal fix if explicitly requested, and before/after run results.\n\nSafety: Make only changes needed for this task; preserve existing behaviour elsewhere. Report exact commands, results and environment blockers."
  },
  {
    "title": "Playwright TS — Fix a Failing Locator",
    "category": "Playwright · run & fix",
    "mode": "Agent",
    "purpose": "Repair a broken locator with stable user-facing selectors.",
    "prompt": "Workspace [workspace]: use the configured writable project. Reference paths, if explicitly named, are read-only.\nSpec: <path>\nLocator / error: <locator or timeout>\n\nTask: Inspect current DOM/trace where available, page objects and the intended element. Replace the fragile selector with a unique role, label or data-testid strategy.\n\nWorkflow: Inspect project instructions and existing conventions first; use real paths and available tools, never invent results. Do not weaken the expectation or add arbitrary waits to hide a real application defect.\n\nDeliverable: Minimal locator change, reason, assertion of uniqueness and targeted rerun.\n\nSafety: Make only changes needed for this task; preserve existing behaviour elsewhere. Report exact commands, results and environment blockers."
  },
  {
    "title": "Playwright TS — Fix Timeout or Race Condition",
    "category": "Playwright · run & fix",
    "mode": "Agent",
    "purpose": "Diagnose a timeout rather than raising default limits blindly.",
    "prompt": "Workspace [workspace]: use the configured writable project. Reference paths, if explicitly named, are read-only.\nSpec / stack trace: <path and failure>\nEnvironment: <local or CI>\n\nTask: Inspect expected navigation, network readiness and element state; replace time-based sleeps with locator assertions, navigation or response waits only when supported by evidence.\n\nWorkflow: Inspect project instructions and existing conventions first; use real paths and available tools, never invent results. Only increase timeouts with a measured reason; preserve functional assertions.\n\nDeliverable: Specific root cause, narrow fix and repeated focused run result.\n\nSafety: Make only changes needed for this task; preserve existing behaviour elsewhere. Report exact commands, results and environment blockers."
  },
  {
    "title": "Playwright TS — Fix a Flaky Test and Validate Repeats",
    "category": "Playwright · run & fix",
    "mode": "Agent",
    "purpose": "Investigate nondeterministic test behavior reproducibly.",
    "prompt": "Workspace [workspace]: use the configured writable project. Reference paths, if explicitly named, are read-only.\nSpec/title: <path and test>\nFlakiness symptoms: <logs or behavior>\n\nTask: Investigate shared data, parallel workers, unstable locators, async state and setup/teardown; fix the actual race and run focused repetitions with repeat-each where supported.\n\nWorkflow: Inspect project instructions and existing conventions first; use real paths and available tools, never invent results. Do not turn on broad retries to disguise instability; do not loosen assertions.\n\nDeliverable: Root cause, minimal diff, repeated-run counts and remaining risks.\n\nSafety: Make only changes needed for this task; preserve existing behaviour elsewhere. Report exact commands, results and environment blockers."
  },
  {
    "title": "Playwright TS — Run Failed Tests Only and Repair",
    "category": "Playwright · run & fix",
    "mode": "Agent",
    "purpose": "Use the saved failing scope for a focused repair cycle.",
    "prompt": "Workspace [workspace]: use the configured writable project. Reference paths, if explicitly named, are read-only.\nPrevious failing scope or report: <path>\nBrowser / CI: <project>\n\nTask: Identify exact failed tests from the latest report; use --last-failed if the installed Playwright version supports it, otherwise rerun explicitly named tests; inspect and fix each proven failure.\n\nWorkflow: Inspect project instructions and existing conventions first; use real paths and available tools, never invent results. If there is no reliable previous-failure list, ask for/report the missing artifact rather than guessing test names.\n\nDeliverable: Failed-to-passed mapping, edits and targeted rerun commands/results.\n\nSafety: Make only changes needed for this task; preserve existing behaviour elsewhere. Report exact commands, results and environment blockers."
  },
  {
    "title": "Playwright TS — Fix Browser or Dependency Installation",
    "category": "Playwright · run & fix",
    "mode": "Agent",
    "purpose": "Resolve Playwright browser/dependency failures without rewriting tests.",
    "prompt": "Workspace [workspace]: use the configured writable project. Reference paths, if explicitly named, are read-only.\nError log: <paste log>\nOS: <Windows, Linux or macOS>\n\nTask: Inspect package version, Node installation, browser binaries, cache and required system libraries; use project-compatible installation commands and rerun a focused spec.\n\nWorkflow: Inspect project instructions and existing conventions first; use real paths and available tools, never invent results. Avoid unrelated version upgrades and global system changes without approval.\n\nDeliverable: Cause, explicit commands and validation result.\n\nSafety: Make only changes needed for this task; preserve existing behaviour elsewhere. Report exact commands, results and environment blockers."
  },
  {
    "title": "Playwright TS — Fix CI vs Local Browser Failures",
    "category": "Playwright · run & fix",
    "mode": "Agent",
    "purpose": "Identify environment-dependent headless/CI differences.",
    "prompt": "Workspace [workspace]: use the configured writable project. Reference paths, if explicitly named, are read-only.\nCI: <Jenkins or GitHub Actions>\nError and spec: <details>\n\nTask: Compare Node/Playwright versions, browser dependencies, environment variables, network access, test data, screenshots/traces and headed constraints.\n\nWorkflow: Inspect project instructions and existing conventions first; use real paths and available tools, never invent results. Do not store secrets, disable TLS verification or silently hide failing tests.\n\nDeliverable: Reproducible cause, minimal config/test fix and CI validation plan or actual result.\n\nSafety: Make only changes needed for this task; preserve existing behaviour elsewhere. Report exact commands, results and environment blockers."
  },
  {
    "title": "Playwright TS — Improve Fixtures and Page Object Framework",
    "category": "Playwright · framework",
    "mode": "Agent",
    "purpose": "Reduce duplication and improve maintainability without mass rewrites.",
    "prompt": "Workspace [workspace]: use the configured writable project. Reference paths, if explicitly named, are read-only.\nScope: <fixtures/pages/tests>\n\nTask: Inventory duplicated setup, inconsistent locator helpers, unsafe global state and repetitive assertions; implement small reusable typed fixtures and POM methods.\n\nWorkflow: Inspect project instructions and existing conventions first; use real paths and available tools, never invent results. Preserve current test IDs, tags and report formats; avoid introducing new dependencies unnecessarily.\n\nDeliverable: Impact map, focused code changes and relevant spec runs.\n\nSafety: Make only changes needed for this task; preserve existing behaviour elsewhere. Report exact commands, results and environment blockers."
  },
  {
    "title": "Playwright TS — Configure Parallelism, Retries and Reporting",
    "category": "Playwright · framework",
    "mode": "Agent",
    "purpose": "Make CI throughput and diagnostics predictable.",
    "prompt": "Workspace [workspace]: use the configured writable project. Reference paths, if explicitly named, are read-only.\nEnvironment: <CI/local>\nCurrent problem: <slow or flaky runs>\n\nTask: Inspect playwright.config, per-worker test data and current reporter outputs; set project-appropriate workers/retries/timeouts and trace-on-first-retry when justified.\n\nWorkflow: Inspect project instructions and existing conventions first; use real paths and available tools, never invent results. Do not use retries to conceal failures and avoid changing all environments when only CI needs tuning.\n\nDeliverable: Config diff, measured test duration, report location and trade-offs.\n\nSafety: Make only changes needed for this task; preserve existing behaviour elsewhere. Report exact commands, results and environment blockers."
  },
  {
    "title": "Playwright TS — Map Excel Test IDs to Playwright Specs",
    "category": "Playwright · framework",
    "mode": "Chat",
    "purpose": "Find exactly which business tests have automation coverage.",
    "prompt": "Workspace [workspace]: use the configured writable project. Reference paths, if explicitly named, are read-only.\nSource data: <Excel sheet or test list>\nTest path: <folder>\n\nTask: Read case IDs and existing test titles/tags, match using evidence and group duplicates/uncertain cases.\n\nWorkflow: Inspect project instructions and existing conventions first; use real paths and available tools, never invent results. Do not edit files; distinguish code existence from verified passing execution.\n\nDeliverable: Coverage table: case ID, Playwright spec/title, status and missing tests.\n\nSafety: Make only changes needed for this task; preserve existing behaviour elsewhere. Report exact commands, results and environment blockers."
  },
  {
    "title": "Playwright TS — Review PR for Locator, Assertion and Fixture Risks",
    "category": "Playwright · framework",
    "mode": "Chat",
    "purpose": "Review a Playwright change set before merging.",
    "prompt": "Workspace [workspace]: use the configured writable project. Reference paths, if explicitly named, are read-only.\nChanged files / diff: <paths or pasted patch>\n\nTask: Review new locators, waits, assertions, test isolation, retry behavior, fixture lifetimes and secrets based on actual changed code.\n\nWorkflow: Inspect project instructions and existing conventions first; use real paths and available tools, never invent results. Do not speculate about unseen files; separate proven defects from suggestions.\n\nDeliverable: Findings by severity with file/line evidence and specific corrections.\n\nSafety: Make only changes needed for this task; preserve existing behaviour elsewhere. Report exact commands, results and environment blockers."
  },
  {
    "title": "Java Selenium — Fix a TestNG or Cucumber Failure",
    "category": "Java / API / CI",
    "mode": "Agent",
    "purpose": "Fix existing Selenium failures with targeted validation.",
    "prompt": "Workspace [workspace]: use the configured writable project. Reference paths, if explicitly named, are read-only.\nTest class / feature: <path>\nFailure: <stack trace>\n\nTask: Trace step definitions, runner/testng.xml, POM, driver lifecycle and test data to a concrete cause.\n\nWorkflow: Inspect project instructions and existing conventions first; use real paths and available tools, never invent results. Preserve test coverage; do not use blanket sleeps or change unrelated framework behavior.\n\nDeliverable: Smallest fix and exact Maven/TestNG/Cucumber rerun command/result.\n\nSafety: Make only changes needed for this task; preserve existing behaviour elsewhere. Report exact commands, results and environment blockers."
  },
  {
    "title": "API Testing — Add Rest Assured Contract Tests",
    "category": "Java / API / CI",
    "mode": "Agent",
    "purpose": "Extend Java API tests for one endpoint and contract.",
    "prompt": "Workspace [workspace]: use the configured writable project. Reference paths, if explicitly named, are read-only.\nEndpoint: <method and URL>\nAcceptance criteria: <criteria>\n\nTask: Inspect auth/config, existing base request specs and DTOs; add status, schema, positive/negative and boundary assertions using existing patterns.\n\nWorkflow: Inspect project instructions and existing conventions first; use real paths and available tools, never invent results. Never embed credentials, production customer data or environment secrets.\n\nDeliverable: Updated Java test(s), safe fixture data and targeted Maven execution result.\n\nSafety: Make only changes needed for this task; preserve existing behaviour elsewhere. Report exact commands, results and environment blockers."
  },
  {
    "title": "CI — Fix One Failing Jenkins Test Job",
    "category": "Java / API / CI",
    "mode": "Agent",
    "purpose": "Diagnose one job from logs and repository configuration.",
    "prompt": "Workspace [workspace]: use the configured writable project. Reference paths, if explicitly named, are read-only.\nJenkins job / stage: <name>\nConsole log: <attach or paste>\n\nTask: Trace Maven/npm commands, Grid/Playwright connectivity, network access, browser/driver versions and workspace artifacts.\n\nWorkflow: Inspect project instructions and existing conventions first; use real paths and available tools, never invent results. Do not change shared Jenkins infrastructure or secret credentials without permission.\n\nDeliverable: Root cause, minimal pipeline or test fix, evidence and reproducible validation.\n\nSafety: Make only changes needed for this task; preserve existing behaviour elsewhere. Report exact commands, results and environment blockers."
  },
  {
    "title": "Agent — Rollback All Files Changed by Last Operation",
    "category": "Agent operations",
    "mode": "Agent",
    "purpose": "Restore the entire most recently completed Agent task.",
    "prompt": "Workspace [workspace]: use the configured writable project. Reference paths, if explicitly named, are read-only.\nTarget: most recent completed operation in this conversation and workspace.\n\nTask: Rollback the last operation. Restore every tracked original file, recover deleted files and remove files created by that operation.\n\nWorkflow: Inspect project instructions and existing conventions first; use real paths and available tools, never invent results. Do not overwrite manual or later Agent changes; stop with exact conflicts if the current version differs from the last task result.\n\nDeliverable: Restored/removed file counts and any conflicts.\n\nSafety: Make only changes needed for this task; preserve existing behaviour elsewhere. Report exact commands, results and environment blockers."
  },
  {
    "title": "Agent — Inspect Changed Files Before Committing",
    "category": "Agent operations",
    "mode": "Agent",
    "purpose": "Review scope and unintended edits before a handoff.",
    "prompt": "Workspace [workspace]: use the configured writable project. Reference paths, if explicitly named, are read-only.\nExecution: <current task>\nScope: <files or feature>\n\nTask: List files created, modified and deleted; inspect diff, run targeted verification and flag unrelated changes.\n\nWorkflow: Inspect project instructions and existing conventions first; use real paths and available tools, never invent results. Never discard changes from outside this operation.\n\nDeliverable: File-by-file change summary, checks performed, failures and follow-up actions.\n\nSafety: Make only changes needed for this task; preserve existing behaviour elsewhere. Report exact commands, results and environment blockers."
  },
  {
    "title": "Agent — Improve Workspace Index Coverage and Retrieval",
    "category": "Agent operations",
    "mode": "Agent",
    "purpose": "Find why an indexed codebase query misses specific files.",
    "prompt": "Workspace [workspace]: use the configured writable project. Reference paths, if explicitly named, are read-only.\nQuery and expected file: <query + path>\nFolder: <module or workspace>\n\nTask: Inspect index status and skip limits, rescan if necessary, compare query terms against target symbols and determine why the target was not retrieved.\n\nWorkflow: Inspect project instructions and existing conventions first; use real paths and available tools, never invent results. Do not conflate file discovery with visual/document comprehension; preserve ignored credentials.\n\nDeliverable: Measured file coverage, skipped reasons and a minimal indexing or query improvement.\n\nSafety: Make only changes needed for this task; preserve existing behaviour elsewhere. Report exact commands, results and environment blockers."
  }
];
