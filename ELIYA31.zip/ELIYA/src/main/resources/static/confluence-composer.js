'use strict';
/* Confluence Composer. Optional and isolated; safe HTML is produced by the local Java formatter. */
(() => {
  const el = id => document.getElementById(id);
  let formatted = null;
  let preparedSource = '';
  let preparedTheme = '';
  function markStale() {
    formatted = null;
    el('confluenceCopy').disabled = true;
    el('confluenceDownload').disabled = true;
    el('confluenceSections').replaceChildren();
    el('confluencePreview').replaceChildren();
  }
  function status(text) { el('confluenceStatus').textContent = text; }
  function open(source) {
    if (typeof source === 'string') el('confluenceInput').value = source;
    markStale();
    el('confluenceBackdrop').classList.remove('hidden');
    el('confluenceInput').focus();
  }
  function close() { el('confluenceBackdrop').classList.add('hidden'); }
  async function format() {
    const content = el('confluenceInput').value;
    const theme = el('confluenceTheme').value;
    if (!content.trim()) { status('Paste content, choose a Chat answer or load Agent Markdown.'); return; }
    markStale();
    const button = el('confluenceFormat');
    button.disabled = true; status('Formatting source content…');
    try {
      const response = await fetch('/api/confluence/format', {
        method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({content,theme})
      });
      if (!response.ok) { let body = await response.json().catch(()=>({})); throw new Error(body.message || `HTTP ${response.status}`); }
      const result = await response.json();
      // The API emits HTML using an allowlisted vocabulary and escapes all user-provided source text.
      el('confluencePreview').innerHTML = result.html;
      formatted = result; preparedSource = content; preparedTheme = theme;
      el('confluenceCopy').disabled = false;
      el('confluenceDownload').disabled = false;
      const summary = `${result.sections} heading(s), ${result.tables} table(s), ${result.codeBlocks} code block(s).`;
      status(summary + (result.warnings?.length ? ` Check: ${result.warnings.join('; ')}` : ' Ready to copy.'));
      buildSections();
    } catch (error) { status(`Formatting failed: ${error.message}`); }
    finally { button.disabled = false; }
  }
  function buildSections() {
    const preview = el('confluencePreview');
    const children = [...preview.children];
    const headings = children.map((node,index)=>({node,index})).filter(item=>/H[1-4]/.test(item.node.tagName));
    if (!headings.length) return;
    for (let i = 0; i < headings.length; i++) {
      const start = headings[i].index, end = i+1 < headings.length ? headings[i+1].index : children.length;
      const button = document.createElement('button'); button.type = 'button';
      button.className = 'secondary-btn'; button.textContent = `Copy: ${headings[i].node.textContent.slice(0,60)}`;
      button.addEventListener('click', async () => {
        if (!isReady()) { status('Source changed; format again before copying.'); return; }
        const html = children.slice(start,end).map(node=>node.outerHTML).join('');
        const text = children.slice(start,end).map(node=>node.textContent).join('\n');
        await richCopy(html,text);
      });
      el('confluenceSections').appendChild(button);
    }
  }
  function isReady() {
    return formatted !== null && preparedSource === el('confluenceInput').value && preparedTheme === el('confluenceTheme').value;
  }
  async function richCopy(html,text) {
    try {
      if (!navigator.clipboard?.write || typeof ClipboardItem === 'undefined') throw new Error('Rich clipboard not supported');
      await navigator.clipboard.write([new ClipboardItem({
        'text/html':new Blob([html],{type:'text/html'}),
        'text/plain':new Blob([text],{type:'text/plain'})
      })]);
      status('Copied rich HTML. Paste directly in the Confluence editor and review its formatting.');
    } catch (_) {
      // Failure is made explicit; never claim HTML was copied when only plaintext was available.
      try {
        if (navigator.clipboard?.writeText) await navigator.clipboard.writeText(text);
        else {
          const temp = document.createElement('textarea');temp.value=text;
          document.body.appendChild(temp);temp.select();
          if (!document.execCommand('copy')) throw new Error('Browser blocked copy');
          temp.remove();
        }
        status('Rich clipboard unavailable. Plain text copied; use Download HTML to retain formatting.');
      } catch (error) { status(`Clipboard blocked: ${error.message}. Select and copy from the preview manually.`); }
    }
  }
  el('confluenceComposerBtn').addEventListener('click',()=>open());
  el('confluenceClose').addEventListener('click',close);
  el('confluenceBackdrop').addEventListener('click',e=>{if(e.target === el('confluenceBackdrop'))close();});
  el('confluenceInput').addEventListener('input',markStale);
  el('confluenceTheme').addEventListener('change',markStale);
  el('confluenceFormat').addEventListener('click',format);
  el('confluenceCopy').addEventListener('click',async()=>{
    if (!isReady()) { status('Source changed; format again before copying.');return; }
    await richCopy(formatted.html,formatted.plainText);
  });
  el('confluenceDownload').addEventListener('click',()=>{
    if (!isReady()) { status('Source changed; format again before downloading.');return; }
    downloadText('confluence-ready.html',formatted.html,'text/html;charset=utf-8');
  });
  el('confluenceLastAnswer').addEventListener('click',()=>{
    const answer = [...state.messages].reverse().find(message=>message.role === 'assistant' && !message.streaming);
    if (!answer) { status('No completed Chat/Agent response available.');return; }
    el('confluenceInput').value = stripProjectMarkers(answer.content || '');markStale();status('Latest answer loaded. Click Format & preview.');
  });
  el('confluenceLoadPath').addEventListener('click',async()=>{
    const path = el('confluenceSourcePath').value.trim();
    if (!state.project?.id || !state.project?.localWorkspace) {status('Select the active local workspace before loading an Agent document.');return;}
    if (!path) {status('Enter a relative .md or .txt path inside the active workspace.');return;}
    try {
      const url = `/api/confluence/workspace-source?projectId=${encodeURIComponent(state.project.id)}&path=${encodeURIComponent(path)}`;
      const response = await fetch(url);
      if (!response.ok) {const body=await response.json().catch(()=>({}));throw new Error(body.message || `HTTP ${response.status}`);}
      const doc = await response.json();
      el('confluenceInput').value=doc.content;
      markStale();status(`Loaded ${path}. Click Format & preview.`);
    } catch(error) {status(`Import failed: ${error.message}`);}
  });
  window.EliyaConfluence={open};
})();
