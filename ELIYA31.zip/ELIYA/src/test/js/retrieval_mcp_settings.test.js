const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');

const app = fs.readFileSync('src/main/resources/static/app.js', 'utf8');
const html = fs.readFileSync('src/main/resources/static/index.html', 'utf8');

test('semantic retrieval defaults to qwen embedding and is user-testable', () => {
  assert.match(app, /storedSetting\('llm\.embeddingModel', 'qwen3-embedding-8b'\)/);
  assert.match(app, /semanticRetrieval: storageGet\('local', 'llm\.semanticRetrieval'\) !== 'false'/);
  assert.match(html, /id="testEmbeddingModel"/);
  assert.match(html, /semantic retrieval automatically/i);
});

test('MCP UI clearly exposes a master switch and explicit-action Chat behavior', () => {
  assert.match(html, /Enable MCP access \(master switch\)/);
  assert.match(app, /no MCP config discovery, connection, tool listing or action is allowed/i);
  assert.match(app, /original user request explicitly asks for that external action/i);
});
