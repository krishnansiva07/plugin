'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const ui = fs.readFileSync('src/main/resources/static/index.html','utf8');
const app = fs.readFileSync('src/main/resources/static/app.js','utf8');
const catalog = fs.readFileSync('src/main/resources/static/prompt-catalog.js','utf8');
const help = fs.readFileSync('src/main/resources/static/how-to-use-eliya.html','utf8');
const ctx = {};
vm.createContext(ctx);
vm.runInContext(catalog + '\nthis.newPrompts=ELIYA_PROMPT_CATALOG; this.realWorld=ELIYA_REAL_WORLD_PROMPTS;',ctx);
const old = app.slice(app.indexOf('const EXISTING_PROMPT_LIBRARY ='),app.indexOf('// Stable prompt names'));
vm.runInContext(old + '\nthis.totalPrompts=PROMPT_LIBRARY;',ctx);
test('focused real-world prompts with distinct Playwright scenarios and deliverables',() => {
  assert.equal(ctx.newPrompts.length,99);
  assert.equal(ctx.realWorld.length,31);
  assert.equal(ctx.totalPrompts.length,56);
  assert.equal(new Set(ctx.totalPrompts.map(x=>x.title)).size,56);
  for (const item of ctx.realWorld) {
    assert.ok(item.title.length > 20 && item.purpose);
    assert.match(item.prompt,/Workspace \[workspace\]/);
    assert.match(item.prompt,/Deliverable:/);
  }
  for (const title of ['Playwright TS — Run One Named Test Using -g',
                       'Playwright TS — Fix a Failing Locator',
                       'Playwright TS — Run Failed Tests Only and Repair',
                       'Agent — Rollback All Files Changed by Last Operation'])
    assert.ok(ctx.totalPrompts.some(item => item.title === title), title);
  for(const item of ctx.newPrompts){
    assert.ok(item.title.length>15,item.title);
    assert.ok(item.purpose && item.mode && item.category);
    assert.match(item.prompt,/Deliverable:/);
    assert.match(item.prompt,/Workspace \[workspace\]/);
  }
});
test('folder chooser removed and clear manual path guide retained',() => {
  assert.doesNotMatch(ui,/id="browse(?:Project|Reference)Btn"/);
  assert.match(ui,/id="enterProjectBtn"/);
  assert.match(ui,/id="enterReferenceBtn"/);
  assert.match(ui,/id="folderPathForm"/);
  assert.match(ui,/id="folderAliasInput"/);
  assert.match(ui,/how-to-use-eliya\.html/);
  assert.doesNotMatch(app,/window\.prompt\(/);
});
test('prompt library filtering and use/copy controls are wired',() => {
  for(const id of ['promptLibrarySearch','promptLibraryCategory','promptLibraryCount','promptLibraryList'])
    assert.match(ui,new RegExp('id="'+id+'"'));
  assert.match(app,/data-copy-prompt/);
  assert.match(app,/data-use-prompt/);
  assert.match(app,/item\.mode === 'Chat' \? 'chat' : 'agent'/);
});
test('standalone HTML guide documents aliases, scope, approvals and modes',() => {
  for(const word of ['Workspace [workspace]','Reference [LegacySelenium]','60 seconds','Chat','Agent','MCP'])
    assert.ok(help.includes(word),word);
});
