'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const html=fs.readFileSync('src/main/resources/static/index.html','utf8');
const app=fs.readFileSync('src/main/resources/static/app.js','utf8');
const js=fs.readFileSync('src/main/resources/static/confluence-composer.js','utf8');
const agent=fs.readFileSync('src/main/java/com/llmart/llm/service/AgentService.java','utf8');
const ws=fs.readFileSync('src/main/java/com/llmart/llm/service/AgentWorkspaceService.java','utf8');
const routes=fs.readFileSync('src/main/java/com/llmart/llm/controller/ConfluenceComposerController.java','utf8');
test('Composer is opt-in and available from sidebar and assistant actions',()=>{
  for(const id of ['confluenceComposerBtn','confluenceBackdrop','confluenceInput','confluencePreview',
    'confluenceCopy','confluenceDownload','confluenceSourcePath','confluenceLoadPath','confluenceTheme'])
    assert.ok(html.includes(`id="${id}"`),id);
  assert.match(app,/data-confluence-msg/);
  assert.match(js,/window.EliyaConfluence=\{open\}/);
});
test('clipboard writes both mime types and identifies plaintext-only fallback',()=>{
  assert.match(js,/new ClipboardItem\(/);
  assert.match(js,/'text\/html'/);
  assert.match(js,/'text\/plain'/);
  assert.match(js,/Plain text copied/);
  assert.match(js,/preparedSource === el\('confluenceInput'\)\.value/);
});
test('workspace Agent tool participates in permission, mutation and validation',()=>{
  for(const name of ['confluence_compose','confluence_validate'])assert.ok(agent.includes(name),name);
  assert.match(ws,/captureBaseline\(ws, relative\)/); // existing safe write implementation
  assert.match(ws,/confluenceCompose\(/);
  assert.match(ws,/confluenceValidate\(/);
  assert.match(routes,/Files\.isSymbolicLink\(cursor\)/);
  assert.match(routes,/\.md"\) \|\| ext\.endsWith\("\.txt"/);
});
