package com.llmart.llm.service;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class McpEvidenceStoreTest {
    @Test
    void retainsLargeResultsAndSupportsSearchReadAndCache() {
        McpEvidenceStore store = new McpEvidenceStore();
        StringBuilder content = new StringBuilder();
        for (int i = 0; i < 1500; i++) {
            content.append("Section ").append(i).append(" payment retry and failure handling details\n");
        }
        var stored = store.store("getConfluenceContent", content.toString(), "page-123");
        assertTrue(stored.chunks() > 1);
        assertTrue(store.contains(stored.id()));
        assertTrue(store.search(stored.id(), "retry failure", 3).contains("MCP_EVIDENCE"));
        assertTrue(store.read(stored.id(), 2, 2).contains("EVIDENCE CHUNK 2/"));
        String cached = store.cachedPreview("page-123", "retry", false).orElseThrow();
        assertTrue(cached.contains("cache hit"));
        assertTrue(cached.contains("retained=complete"));
    }
}
