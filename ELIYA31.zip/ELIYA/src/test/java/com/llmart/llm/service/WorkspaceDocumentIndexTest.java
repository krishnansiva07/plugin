package com.llmart.llm.service;

import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;

import static org.junit.jupiter.api.Assertions.*;

class WorkspaceDocumentIndexTest {
    @TempDir Path workspace;

    private void word(String name, String text) throws Exception {
        try (XWPFDocument doc = new XWPFDocument()) {
            doc.createParagraph().createRun().setText(text);
            try (OutputStream out = Files.newOutputStream(workspace.resolve(name))) { doc.write(out); }
        }
    }

    @Test
    void wordOnlyWorkspaceIsIndexedAndRetrievableByChat() throws Exception {
        word("ManagementRule.docx", "Cashpooling management rules define settlement eligibility.");
        word("UserNav.docx", "User navigation defines workflow roles and access permissions.");
        WorkspaceRetrievalIndexService index = new WorkspaceRetrievalIndexService(null);
        var stats = index.warmRoot("cashpooling", workspace);
        assertEquals(2, stats.indexedFiles(), "Both Word documents should be counted");
        assertEquals(2, stats.visitedFiles());
        assertTrue(stats.indexedCharacters() > 0, "Extracted Word text should be available for Chat");
        var matched = index.retrieveCachedRoot("cashpooling", workspace, "workflow roles", 8, 8_000);
        assertTrue(matched.contains("UserNav.docx"), matched);
        assertTrue(matched.contains("workflow roles"), matched);
        assertFalse(matched.contains("PK" + (char) 3 + (char) 4), "Raw ZIP bytes must not reach the model");
        var overview = index.retrieveCachedRoot("cashpooling", workspace,
                "Explain the project overview", 8, 8_000);
        assertTrue(overview.contains("UserNav.docx"));
        assertTrue(overview.contains("ManagementRule.docx"));
    }

    @Test
    void documentsRemainIndexedAfterAnIncrementalEdit() throws Exception {
        word("UserNav.docx", "First version of user navigation");
        WorkspaceRetrievalIndexService index = new WorkspaceRetrievalIndexService(null);
        index.warmRoot("cashpooling", workspace);
        word("UserNav.docx", "Second version with new eligibility criteria");
        index.refreshPaths(AgentWorkspaceService.Workspace.forIndex("cashpooling", workspace),
                java.util.List.of("UserNav.docx"));
        var matched = index.retrieveCachedRoot("cashpooling", workspace, "eligibility criteria", 8, 8_000);
        assertTrue(matched.contains("Second version"), matched);
    }
}
