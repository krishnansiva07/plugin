package com.llmart.llm.service;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ContextServiceWorkspaceRoutingTest {
    @Test
    void normalChatSkipsRepositoryRetrievalButImplementationQuestionsUseIt() {
        ContextService service = new ContextService(null, null, null, null, null, null, null, null, null);
        assertFalse(service.shouldRetrieveWorkspace("Hi"));
        assertFalse(service.shouldRetrieveWorkspace("Explain Java inheritance with an example"));
        assertFalse(service.shouldRetrieveWorkspace("What is the capital of France?"));
        assertFalse(service.shouldRetrieveWorkspace("How does photosynthesis work?"));
        assertFalse(service.shouldRetrieveWorkspace("What is microservice architecture?"));
        assertTrue(service.shouldRetrieveWorkspace("Where is authentication implemented in our project?"));
        assertTrue(service.shouldRetrieveWorkspace("Compare this implementation with the reference project"));
        assertTrue(service.shouldRetrieveWorkspace("Why does src/main/java/LoginService.java fail?"));
    }
}
