package com.llmart.llm.service;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

/** Completed-task rollback must be exact and must never overwrite later manual edits. */
class AgentTaskRollbackServiceTest {
    @TempDir Path temporary;

    private AgentWorkspaceService.Workspace workspace(Path root) {
        AgentWorkspaceService.Workspace workspace = mock(AgentWorkspaceService.Workspace.class);
        when(workspace.root()).thenReturn(root);
        when(workspace.resources()).thenReturn(Map.of());
        return workspace;
    }

    @Test void completedTaskRollbackRestoresAllTrackedFilesAndPreventsSecondUndo() throws Exception {
        Path root = Files.createDirectories(temporary.resolve("project"));
        Path original = root.resolve("src/Test.java");
        Files.createDirectories(original.getParent());
        Files.writeString(original, "original");
        Path removed = root.resolve("old.bin");
        byte[] oldBytes = {0, -1, 42};
        Files.write(removed, oldBytes);
        var history = new AgentRunService(temporary.resolve("history"));
        var run = history.start("conversation", "project-id");
        var snapshots = new ProtectedRunSnapshotService(temporary.resolve("snapshots"));
        var index = mock(WorkspaceRetrievalIndexService.class);
        var undo = new AgentTaskRollbackService(snapshots, index, history);
        snapshots.begin(run.id(), workspace(root));
        Files.writeString(original, "modified");
        Files.delete(removed);
        Path created = root.resolve("new/spec.ts");
        Files.createDirectories(created.getParent());
        Files.writeString(created, "created");
        assertEquals(3, undo.seal(run.id()));
        run.finish("completed");
        assertEquals(run.id(), undo.latestAvailable("conversation", "project-id", "").orElseThrow());
        assertTrue(((java.util.List<?>) undo.preview(run.id()).get("conflicts")).isEmpty());
        Map<String,Object> result = undo.rollback(run.id(), "conversation", "project-id");
        assertEquals(2, result.get("restored"));
        assertEquals(1, result.get("removed"));
        assertEquals("original", Files.readString(original));
        assertArrayEquals(oldBytes, Files.readAllBytes(removed));
        assertFalse(Files.exists(created));
        assertFalse(undo.available(run.id()));
        assertTrue(undo.latestAvailable("conversation", "project-id", "").isEmpty());
        verify(index, atLeastOnce()).refreshPaths(any(AgentWorkspaceService.Workspace.class), anyCollection());
    }

    @Test void refusesRollbackIfFileChangedAfterCompletedTask() throws Exception {
        Path root = Files.createDirectories(temporary.resolve("workspace"));
        Path file = root.resolve("LoginPage.java");
        Files.writeString(file, "before");
        var history = new AgentRunService(temporary.resolve("runs"));
        var run = history.start("chat", "project");
        var snapshots = new ProtectedRunSnapshotService(temporary.resolve("snapshots"));
        var undo = new AgentTaskRollbackService(snapshots, mock(WorkspaceRetrievalIndexService.class), history);
        snapshots.begin(run.id(), workspace(root));
        Files.writeString(file, "agent-version");
        undo.seal(run.id());
        run.finish("completed");
        Files.writeString(file, "user-version");
        assertFalse(((java.util.List<?>) undo.preview(run.id()).get("conflicts")).isEmpty());
        assertThrows(java.io.IOException.class, () -> undo.rollback(run.id(), "chat", "project"));
        assertEquals("user-version", Files.readString(file));
    }
}
