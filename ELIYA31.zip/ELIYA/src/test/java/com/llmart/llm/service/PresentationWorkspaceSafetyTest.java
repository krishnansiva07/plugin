package com.llmart.llm.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.llmart.llm.entity.ProjectWorkspaceEntity;
import org.apache.poi.xslf.usermodel.*;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.awt.geom.Rectangle2D;
import java.nio.file.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class PresentationWorkspaceSafetyTest {
    @TempDir Path temp;

    @Test void outputStaysInWorkspaceAndNeverOverwritesReferenceOrExistingOutputImplicitly() throws Exception {
        Path workspace=Files.createDirectory(temp.resolve("output"));
        Path refdir=Files.createDirectory(temp.resolve("reference"));
        Path reference=refdir.resolve("corporate.pptx");
        try(XMLSlideShow ppt=new XMLSlideShow()){
            XSLFTextBox text=ppt.createSlide().createTextBox();
            text.setAnchor(new Rectangle2D.Double(40,40,520,90));text.setText("Old Heading");
            try(var output=Files.newOutputStream(reference)){ppt.write(output);}
        }
        byte[] original=Files.readAllBytes(reference);
        ProjectService projects=mock(ProjectService.class);
        ProjectWorkspaceEntity project=mock(ProjectWorkspaceEntity.class);
        when(projects.require("project")).thenReturn(project);
        when(project.hasLocalPath()).thenReturn(true);
        when(project.getLocalPath()).thenReturn(workspace.toString());
        AgentWorkspaceService service=new AgentWorkspaceService(projects,new ObjectMapper(),new PromptResourceResolver());
        AgentWorkspaceService.Workspace ws=service.prepare("project","Reference [Corporate] (read-only): \""+refdir+"\"");
        // Relative reference path is constrained to the designated read-only alias.
        assertThrows(SecurityException.class,()->service.presentationInspect(ws,"corporate","../output/file.pptx"));
        var spec=new ObjectMapper().readTree("[{\"title\":\"New Heading\",\"bullets\":[]}] ");
        String result=service.presentationCreate(ws,"corporate","corporate.pptx","deck.pptx",spec,false);
        assertTrue(result.contains("workspaceChanged=true"));
        assertTrue(Files.isRegularFile(workspace.resolve("deck.pptx")));
        assertTrue(Files.isRegularFile(workspace.resolve("deck.pptx.quality.json")));
        assertArrayEquals(original,Files.readAllBytes(reference));
        assertThrows(FileAlreadyExistsException.class,()->service.presentationCreate(ws,"corporate","corporate.pptx","deck.pptx",spec,false));
        assertThrows(SecurityException.class,()->service.presentationCreate(ws,"corporate","corporate.pptx","../escape.pptx",spec,false));
    }
}
