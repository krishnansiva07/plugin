package com.llmart.llm.service;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class ConfluenceComposerServiceTest {
    private final ConfluenceComposerService formatter = new ConfluenceComposerService();

    @Test void formatsNativeConfluenceStructuresWithoutRewritingSource() {
        String source = """
                # Framework Overview
                Status: **145 passed**, 5 failed.
                - Java 17
                - Selenium
                | Metric | Count |
                | --- | --- |
                | Passed | 145 |
                | Failed | 5 |
                ```java
                if (count < 5) return;
                ```
                [Design](https://example.com/design?a=1&b=2)
                """;
        var result = formatter.format(source, "bnp-green");
        assertEquals(source,result.plainText());
        assertEquals(1,result.sections());
        assertEquals(1,result.tables());
        assertEquals(1,result.codeBlocks());
        assertTrue(result.html().contains("<h1"));
        assertTrue(result.html().contains("<strong>145 passed</strong>"));
        assertTrue(result.html().contains("<table>"));
        assertTrue(result.html().contains("<pre><code>if (count &lt; 5) return;</code></pre>"));
        assertTrue(result.html().contains("href=\"https://example.com/design?a=1&amp;b=2\""));
    }

    @Test void structuresPlainReportsWithoutChangingWording() {
        String report="API Testing Summary\nTotal test cases: 150\nPassed: 145\nFailed: 5";
        var result=formatter.format(report,"bnp-green");
        assertEquals(report,result.plainText());
        assertEquals(1,result.sections());
        assertEquals(1,result.tables());
        assertTrue(result.html().contains("Passed:"));
        assertTrue(result.html().contains(">145</td>"));
    }

    @Test void escapesMaliciousHtmlAndUnsafeLinks() {
        var result = formatter.format("<img src=x onerror=alert(1)>\n[click](javascript:alert(1))\n<script>alert(2)</script>", "minimal");
        assertFalse(result.html().contains("<img"));
        assertFalse(result.html().contains("<script"));
        assertFalse(result.html().contains("href=\"javascript:"));
        assertTrue(result.html().contains("&lt;script&gt;"));
        assertEquals(1,result.warnings().size());
    }

    @Test void preservesMalformedTableValuesAndRejectsOversize() {
        var result = formatter.format("| A | B |\n| --- | --- |\n| 1 | 2 | 3 |",null);
        assertTrue(result.html().contains("<td>3</td>"));
        assertEquals(1,result.warnings().size());
        assertThrows(IllegalArgumentException.class,()->formatter.format("x".repeat(300001),"bnp-green"));
        assertThrows(IllegalArgumentException.class,()->formatter.format("value","javascript"));
        assertThrows(IllegalArgumentException.class,()->formatter.format(" ",null));
    }
}
