package com.llmart.llm.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.poi.xslf.usermodel.*;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.awt.Color;
import java.awt.geom.Rectangle2D;
import java.nio.file.*;

import static org.junit.jupiter.api.Assertions.*;

class PresentationIntelligenceServiceTest {
    @TempDir Path temp;
    private final PresentationIntelligenceService engine = new PresentationIntelligenceService();
    private final ObjectMapper json = new ObjectMapper();

    private Path reference() throws Exception {
        Path file = temp.resolve("model.pptx");
        try (XMLSlideShow show = new XMLSlideShow()) {
            XSLFSlide slide = show.createSlide();
            XSLFTextBox heading = slide.createTextBox();
            heading.setAnchor(new Rectangle2D.Double(40, 30, 600, 65));
            heading.setText("OLD TITLE");
            heading.getTextParagraphs().get(0).getTextRuns().get(0).setFontSize(30.0);
            heading.getTextParagraphs().get(0).getTextRuns().get(0).setFontColor(Color.BLUE);
            XSLFTextBox content = slide.createTextBox();
            content.setAnchor(new Rectangle2D.Double(40, 110, 600, 330));
            content.setText("OLD SOURCE FACTS");
            content.getTextParagraphs().get(0).getTextRuns().get(0).setFontSize(18.0);
            try(var out=Files.newOutputStream(file)){show.write(out);}
        }
        return file;
    }

    @Test void inspectAndGenerateEditablePowerPointWithoutOldFacts() throws Exception {
        Path model=reference();Path generated=temp.resolve("new.pptx");
        assertTrue(engine.inspect(model).contains("OLD TITLE"));
        String report=engine.generate(model,generated,json.readTree("""
                [{"title":"New Architecture","bullets":["Kafka ingestion","Flink processing"],"templateSlide":1},
                 {"title":"Testing Approach","bullets":["Smoke tests","Regression tests"],"templateSlide":1}]
                """));
        assertTrue(report.contains("STRUCTURAL_PASS"),report);
        try(XMLSlideShow output=new XMLSlideShow(Files.newInputStream(generated))) {
            assertEquals(2,output.getSlides().size());
            assertEquals("New Architecture",((XSLFTextShape)output.getSlides().get(0).getShapes().get(0)).getText());
            String slide=output.getSlides().get(0).getShapes().stream()
                    .filter(s->s instanceof XSLFTextShape).map(s->((XSLFTextShape)s).getText()).reduce("",String::concat);
            assertTrue(slide.contains("Kafka ingestion"));
            assertFalse(slide.contains("OLD SOURCE FACTS"));
            assertEquals(2,output.getSlides().get(0).getShapes().stream().filter(s->s instanceof XSLFTextShape).count());
        }
        assertTrue(engine.validate(generated).contains("STRUCTURAL_PASS"));
        assertTrue(Files.size(model)>100); // source reference remains untouched
    }

    @Test void blocksInvalidSourceAndOverlyDenseSlides() throws Exception {
        Path model=reference();
        assertThrows(IllegalArgumentException.class,()->engine.generate(model,temp.resolve("bad.pptx"),
                json.readTree("[{\"title\":\"x\",\"templateSlide\":15}]")));
        assertThrows(IllegalArgumentException.class,()->engine.generate(model,temp.resolve("bad.pptx"),
                json.readTree("[{\"title\":\"x\",\"bullets\":[\""+"x".repeat(800)+"\"]}]")));
        assertFalse(Files.exists(temp.resolve("bad.pptx")));
    }

    @Test void generatesEditableChartsTablesAndDiagramsWithoutStaleReferenceFacts() throws Exception {
        Path model=reference();Path output=temp.resolve("visual.pptx");
        String report=engine.generate(model,output,json.readTree("""
                [
                  {"title":"Monthly processing", "templateSlide":1,
                   "chart":{"type":"stacked_column","labels":["Jan","Feb","Mar"],
                     "series":[{"name":"Kafka","values":[15,22,18]},{"name":"Flink","values":[9,12,19]}]}},
                  {"title":"Coverage matrix", "templateSlide":1,
                   "table":{"headers":["Layer","Cases"],"rows":[["API","100"],["UI","45"]]}},
                  {"title":"Ingestion pipeline", "templateSlide":1,
                   "diagram":{"type":"flow","nodes":["Kafka","Flink","Elasticsearch"]}}
                ]
                """));
        assertTrue(report.contains("STRUCTURAL_PASS"),report);
        try(XMLSlideShow deck=new XMLSlideShow(Files.newInputStream(output))) {
            assertEquals(3,deck.getSlides().size());
            assertTrue(deck.getSlides().get(0).getShapes().stream().anyMatch(sh -> sh instanceof XSLFAutoShape));
            assertTrue(deck.getSlides().get(1).getShapes().stream().anyMatch(sh -> sh instanceof XSLFTable));
            assertTrue(deck.getSlides().get(2).getShapes().stream().anyMatch(sh -> sh instanceof XSLFConnectorShape));
            for(XSLFSlide slide:deck.getSlides())for(XSLFShape sh:slide.getShapes())
                if(sh instanceof XSLFTextShape text)assertFalse(text.getText().contains("OLD SOURCE FACTS"));
        }
    }

    @Test void removesOldDataBearingReferenceTableAndAvoidsFakeVisualSuccess() throws Exception {
        Path model=temp.resolve("tabular-model.pptx");
        try(XMLSlideShow show=new XMLSlideShow()) {
            XSLFSlide slide=show.createSlide();
            var title=slide.createTextBox();
            title.setAnchor(new Rectangle2D.Double(40,30,600,65));title.setText("Old title");
            XSLFTable old=slide.createTable();
            XSLFTableRow row=old.addRow();row.setHeight(35);
            row.addCell().setText("STALE PRIVATE DATA");
            old.setColumnWidth(0,300);old.setAnchor(new Rectangle2D.Double(40,110,300,35));
            try(var out=Files.newOutputStream(model)){show.write(out);}
        }
        String result=engine.generate(model,temp.resolve("clean.pptx"),json.readTree("""
                [{"title":"Updated","table":{"headers":["Metric"],"rows":[["No stale data"]]}}]
                """));
        assertTrue(result.contains("STRUCTURAL_PASS"),result);
        assertTrue(result.contains("old embedded chart/table/graphic frame removed"),result);
        try(XMLSlideShow deck=new XMLSlideShow(Files.newInputStream(temp.resolve("clean.pptx")))) {
            XSLFTable newTable=(XSLFTable)deck.getSlides().get(0).getShapes().stream()
                    .filter(s -> s instanceof XSLFTable).findFirst().orElseThrow();
            assertEquals("No stale data",newTable.getRows().get(1).getCells().get(0).getText());
        }
    }

    @Test void rejectsUnsupportedGraphicsAndInvalidVisualDataBeforeWriting() throws Exception {
        Path model=reference();Path target=temp.resolve("invalid.pptx");
        assertThrows(IllegalArgumentException.class,()->engine.generate(model,target,json.readTree("""
                [{"title":"Invalid chart","chart":{"type":"pie","labels":["A"],"series":[{"name":"X","values":[1]}]}}]
                """)));
        assertThrows(IllegalArgumentException.class,()->engine.generate(model,target,json.readTree("""
                [{"title":"Invalid data","table":{"headers":["A","B"],"rows":[["only one"]]}}]
                """)));
        assertFalse(Files.exists(target));
    }
}
