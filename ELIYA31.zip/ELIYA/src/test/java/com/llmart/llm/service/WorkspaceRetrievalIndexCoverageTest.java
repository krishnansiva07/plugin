package com.llmart.llm.service;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Files;
import java.nio.file.Path;

import static org.junit.jupiter.api.Assertions.*;

/** Guards against losing large/deep Selenium/Cucumber projects in the fast local index. */
class WorkspaceRetrievalIndexCoverageTest {
    @TempDir Path workspace;

    @Test
    void indexes1099SupportedFilesAndRetrievesMethodBeyondTheOldExcerpt() throws Exception {
        for (int i = 0; i < 1000; i++) {
            Files.writeString(workspace.resolve("scenario" + i + ".feature"),
                    "Feature: payments\nScenario: credit transfer " + i + "\n");
        }
        Path deep = workspace;
        for (int i = 0; i < 15; i++) deep = Files.createDirectories(deep.resolve("level" + i));
        for (int i = 0; i < 99; i++) {
            Files.writeString(deep.resolve("Component" + i + ".java"),
                    "class Component" + i + " { void executeFlow" + i + "() {} }\n");
        }
        Files.writeString(deep.resolve("Component1.java"), "class Component1 {\n" +
                "/* ordinary boilerplate */\n".repeat(9000) +
                "void userAuthorizationPolicyCheck() { /* source evidence */ }\n}");
        Files.writeString(workspace.resolve(".env"), "PRIVATE_API_KEY=do-not-index");
        Files.writeString(workspace.resolve("binary.exe"), "not source");
        Files.writeString(workspace.resolve("oversized.java"), "x".repeat(1_600_000));
        Files.writeString(Files.createDirectories(workspace.resolve("target")).resolve("ignored.java"),
                "class Ignored {}");

        var index = new WorkspaceRetrievalIndexService(null);
        var stats = index.warmRoot("large-project", workspace);
        assertEquals(1099, stats.indexedFiles());
        assertEquals(1, stats.skippedTooLarge());
        assertEquals(2, stats.skippedUnsupported());
        assertEquals(1, stats.skippedDirectories());
        assertFalse(stats.scanIncomplete());
        String late = index.retrieveCachedRoot("large-project", workspace,
                "Where is userAuthorizationPolicyCheck implemented?", 16, 36_000);
        assertTrue(late.contains("Component1.java"));
        assertTrue(late.contains("userAuthorizationPolicyCheck"));
        assertTrue(index.retrieveCachedRoot("large-project", workspace,
                "credit transfer scenario999", 16, 36_000).contains("scenario999.feature"));
    }
}
