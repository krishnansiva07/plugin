# Java Vibium LLM Runner

Java Spring Boot UI for running JSON/Excel test scenarios through **real Vibium Java client** with LLM action planning. This build uses Vibium Java `26.5.31`.

## Why this version was updated

The earlier build passed `chrome.exe` and `chromedriver.exe` fields, but Vibium Java does **not** use ChromeDriver like Selenium. Vibium Java starts the Vibium binary. The Vibium binary then manages Chrome for Testing by default.

On office/corporate networks, Vibium's default Chrome-for-Testing download can fail with errors like:

```text
Downloading Chrome for Testing...
Failed to fetch version info: Get "https://googlechromelabs.github.io/...": dial tcp: lookup googlechromelabs.github.io: no such host
```

This is a network/DNS/proxy issue. The new version adds **Local Browser Connect** mode:

1. The app launches your installed `chrome.exe`, `chromium.exe`, or `msedge.exe` using `--remote-debugging-port`.
2. It reads the real DevTools `webSocketDebuggerUrl` from `/json/version`.
3. It starts Vibium Java with `StartOptions.connectURL(...)`.
4. Because this is a remote connection, Vibium does not run the Chrome-for-Testing downloader.

## Run locally

```bash
mvn clean spring-boot:run
```

Open:

```text
http://localhost:8090
```

## Recommended setup for your office laptop

Use this UI option:

```text
Browser launch mode = Local Browser Connect - use my chrome.exe / chromium.exe
```

Then provide your browser executable path, for example:

```text
C:\Program Files\Google\Chrome\Application\chrome.exe
```

or Chromium:

```text
C:\Users\<user>\AppData\Local\Chromium\Application\chrome.exe
```

ChromeDriver is intentionally not used in pure Vibium mode.

## Browser modes

| Mode | Use case | Internet needed for Chrome-for-Testing? |
|---|---|---|
| Local Browser Connect | Recommended for corporate network. Uses your installed browser path. | No |
| Vibium Managed Chrome | Vibium downloads/uses Chrome for Testing. | Yes, first run |
| Remote Browser Connect | You already launched Chrome manually and provide `http://127.0.0.1:9222` or a `ws://.../devtools/browser/...` URL. | No |

## Manual browser launch alternative

If you want to launch Chrome yourself, run:

```cmd
"C:\Program Files\Google\Chrome\Application\chrome.exe" --remote-debugging-port=9222 --user-data-dir="C:\temp\vibium-profile" --no-first-run --no-default-browser-check about:blank
```

Then in UI:

```text
Browser launch mode = Remote Browser Connect
Remote browser URL = http://127.0.0.1:9222
```

The app will read:

```text
http://127.0.0.1:9222/json/version
```

and pass the `webSocketDebuggerUrl` to Vibium.

## Scenario Excel columns

The first sheet can contain any number of test rows.

| Column | Required | Example |
|---|---:|---|
| id | Yes | TC001 |
| name | Yes | Valid login |
| url | Optional | /login or full URL |
| steps | Yes | Open login page \| Enter username \| Click Login |
| expected | Optional | Dashboard |
| data.username | Optional | user1 |
| data.password | Optional | pass1 |
| testDataJson | Optional | {"otp":"123456"} |

Steps can be split by `|` or by new line.

## Output after run

```text
target/vibium-test-runs/<run-id>/
  report.json
  report.xlsx
  screenshots.zip
  screenshots/
```

The UI also shows scenario-wise and step-wise results with screenshots.

## Notes

- This project does not include Selenium.
- ChromeDriver path/upload fields are kept only for migration/diagnostics and are not used by Vibium.
- If you use Vibium Managed Chrome mode behind office VPN/firewall, allow these domains or use Local Browser Connect mode:
  - googlechromelabs.github.io
  - storage.googleapis.com
  - github.com
  - repo.maven.apache.org
