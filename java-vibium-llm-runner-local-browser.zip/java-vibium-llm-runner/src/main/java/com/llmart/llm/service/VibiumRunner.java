package com.llmart.llm.service;

import com.llmart.llm.model.*;
import com.vibium.Browser;
import com.vibium.Element;
import com.vibium.Page;
import com.vibium.Vibium;
import com.vibium.types.SelectorOptions;
import com.vibium.types.StartOptions;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.net.URI;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.time.Instant;
import java.util.Locale;

@Service
public class VibiumRunner {
    private final ActionPlanner actionPlanner;
    private final ReportService reportService;
    private final Path outputRoot;

    public VibiumRunner(ActionPlanner actionPlanner,
                        ReportService reportService,
                        @Value("${runner.output-dir:target/vibium-test-runs}") String outputDir) {
        this.actionPlanner = actionPlanner;
        this.reportService = reportService;
        this.outputRoot = Path.of(outputDir);
    }

    public RunStatus execute(java.util.List<TestScenario> scenarios, RunConfig config, RunStatus status) {
        status.setStatus("RUNNING");
        status.setStartedAt(Instant.now());
        status.setTotal(scenarios.size());

        Browser browser = null;
        LocalBrowserManager localBrowser = null;
        Path runDir = outputRoot.resolve(config.getRunId());
        Path screenshotsDir = runDir.resolve("screenshots");

        try {
            Files.createDirectories(screenshotsDir);

            StartOptions options = new StartOptions().headless(config.isHeadless());
            // Important: Vibium Java StartOptions.executablePath points to the Vibium binary,
            // not to chromedriver.exe and not to chrome.exe.
            if (config.getVibiumBinaryPath() != null && !config.getVibiumBinaryPath().isBlank()) {
                options.executablePath(config.getVibiumBinaryPath().trim());
            }

            String browserMode = config.getBrowserMode() == null ? "" : config.getBrowserMode().trim();
            boolean useLocalConnect = "LOCAL_BROWSER_CONNECT".equalsIgnoreCase(browserMode)
                    || (config.getChromeBinaryPath() != null && !config.getChromeBinaryPath().isBlank())
                    || (config.getRemoteDebugUrl() != null && !config.getRemoteDebugUrl().isBlank());

            if (useLocalConnect) {
                localBrowser = LocalBrowserManager.fromConfig(config, runDir);
                options.connectURL(localBrowser.getConnectUrl());
                status.setMessage("Using local browser connect mode. Vibium Chrome-for-Testing download is bypassed. Connect URL: " + localBrowser.getConnectUrl());
            }

            browser = Vibium.start(options);
            Page page = browser.page();

            for (TestScenario scenario : scenarios) {
                ScenarioResult scenarioResult = runScenario(page, scenario, config, screenshotsDir);
                status.getScenarios().add(scenarioResult);
                if ("PASSED".equals(scenarioResult.getStatus())) {
                    status.setPassed(status.getPassed() + 1);
                } else {
                    status.setFailed(status.getFailed() + 1);
                    if (!config.isContinueOnFailure()) {
                        break;
                    }
                }
            }
            status.setStatus(status.getFailed() == 0 ? "PASSED" : "COMPLETED_WITH_FAILURES");
        } catch (Exception e) {
            status.setStatus("FAILED");
            status.setMessage(e.getMessage());
        } finally {
            if (browser != null) {
                try { browser.stop(); } catch (Exception ignored) { }
            }
            if (localBrowser != null) {
                try { localBrowser.close(); } catch (Exception ignored) { }
            }
            status.setFinishedAt(Instant.now());
            try {
                reportService.writeAll(status, runDir);
            } catch (Exception e) {
                status.setMessage((status.getMessage() == null ? "" : status.getMessage() + " | ") +
                        "Report write failed: " + e.getMessage());
            }
        }
        return status;
    }

    private ScenarioResult runScenario(Page page, TestScenario scenario, RunConfig config, Path screenshotsDir) {
        Instant started = Instant.now();
        ScenarioResult result = new ScenarioResult();
        result.setId(scenario.getId());
        result.setName(scenario.getName());
        result.setUrl(resolveUrl(scenario.getUrl(), config.getAppBaseUrl()));
        result.setStatus("RUNNING");

        try {
            if (result.getUrl() != null && !result.getUrl().isBlank()) {
                page.go(result.getUrl());
                safeWaitForLoad(page);
            }
            int stepNo = 1;
            for (String step : scenario.getSteps()) {
                StepResult stepResult = runStep(page, scenario, stepNo, step, config, screenshotsDir);
                result.getSteps().add(stepResult);
                if (!"PASSED".equals(stepResult.getStatus())) {
                    result.setStatus("FAILED");
                    result.setErrorMessage(stepResult.getErrorMessage());
                    if (!config.isContinueOnFailure()) break;
                }
                stepNo++;
            }
            if (!"FAILED".equals(result.getStatus())) {
                if (scenario.getExpected() != null && !scenario.getExpected().isBlank()) {
                    String text = pageText(page);
                    if (!text.toLowerCase(Locale.ROOT).contains(scenario.getExpected().toLowerCase(Locale.ROOT))) {
                        result.setStatus("FAILED");
                        result.setErrorMessage("Expected text not found: " + scenario.getExpected());
                    } else {
                        result.setStatus("PASSED");
                    }
                } else {
                    result.setStatus("PASSED");
                }
            }
        } catch (Exception e) {
            result.setStatus("FAILED");
            result.setErrorMessage(e.getMessage());
        } finally {
            result.setDurationMs(Duration.between(started, Instant.now()).toMillis());
        }
        return result;
    }

    private StepResult runStep(Page page, TestScenario scenario, int stepNo, String step, RunConfig config, Path screenshotsDir) {
        Instant started = Instant.now();
        StepResult result = new StepResult();
        result.setStepNo(stepNo);
        result.setInstruction(step);
        try {
            AgentAction action = actionPlanner.plan(scenario, stepNo, step, safeUrl(page), safeTitle(page), config);
            result.setActionJson(actionPlanner.toJson(action));
            executeAction(page, scenario, action, config);
            result.setStatus("PASSED");
        } catch (Exception e) {
            result.setStatus("FAILED");
            result.setErrorMessage(e.getMessage());
        } finally {
            result.setDurationMs(Duration.between(started, Instant.now()).toMillis());
            result.setScreenshot(captureScreenshot(page, screenshotsDir, scenario.getId(), stepNo, result.getStatus()));
        }
        return result;
    }

    private void executeAction(Page page, TestScenario scenario, AgentAction action, RunConfig config) throws Exception {
        String name = action.getAction() == null ? "" : action.getAction().trim().toUpperCase(Locale.ROOT);
        switch (name) {
            case "NAVIGATE" -> {
                String target = firstNonBlank(action.getTarget(), scenario.getUrl(), config.getAppBaseUrl());
                page.go(resolveUrl(target, config.getAppBaseUrl()));
                safeWaitForLoad(page);
            }
            case "CLICK" -> findElement(page, action).click();
            case "FILL" -> findElement(page, action).fill(nullToEmpty(action.getValue()));
            case "TYPE" -> findElement(page, action).type(nullToEmpty(action.getValue()));
            case "PRESS" -> {
                if (action.getTarget() != null && !action.getTarget().isBlank()) {
                    findElement(page, action).press(firstNonBlank(action.getKey(), action.getValue(), "Enter"));
                } else {
                    page.keyboard().press(firstNonBlank(action.getKey(), action.getValue(), "Enter"));
                }
            }
            case "SELECT" -> findElement(page, action).selectOption(nullToEmpty(action.getValue()));
            case "CHECK" -> findElement(page, action).check();
            case "UNCHECK" -> findElement(page, action).uncheck();
            case "ASSERT_TEXT" -> {
                String expected = firstNonBlank(action.getValue(), action.getTarget(), scenario.getExpected());
                String text = pageText(page);
                if (!text.toLowerCase(Locale.ROOT).contains(expected.toLowerCase(Locale.ROOT))) {
                    throw new IllegalStateException("Text not found on page: " + expected);
                }
            }
            case "WAIT" -> page.sleep(((action.getSeconds() == null ? 2 : action.getSeconds()) * 1000L));
            default -> throw new IllegalArgumentException("Unsupported action: " + action.getAction());
        }
    }

    private Element findElement(Page page, AgentAction action) {
        String selectorType = action.getSelectorType() == null ? "text" : action.getSelectorType().trim().toLowerCase(Locale.ROOT);
        String target = action.getTarget() == null ? "" : action.getTarget().trim();
        long timeoutMs = 10_000L;
        if (selectorType.equals("css")) return page.find(target);

        SelectorOptions options = new SelectorOptions().timeout(timeoutMs);
        switch (selectorType) {
            case "label" -> options.label(target);
            case "placeholder" -> options.placeholder(target);
            case "role" -> applyRole(options, target);
            case "title" -> options.title(target);
            case "testid", "data-testid" -> options.testid(target);
            case "xpath" -> options.xpath(target);
            case "text" -> options.text(target);
            default -> options.text(target);
        }
        return page.find(options);
    }

    private void applyRole(SelectorOptions options, String target) {
        if (target.contains(":")) {
            String[] parts = target.split(":", 2);
            options.role(parts[0].trim());
            if (!parts[1].trim().isBlank()) options.text(parts[1].trim());
        } else {
            options.role(target);
        }
    }

    private String captureScreenshot(Page page, Path screenshotsDir, String scenarioId, int stepNo, String status) {
        try {
            String filename = sanitize(scenarioId) + "_step_" + stepNo + "_" + status.toLowerCase(Locale.ROOT) + ".png";
            Path path = screenshotsDir.resolve(filename);
            Files.write(path, page.screenshot());
            return "screenshots/" + filename;
        } catch (Exception ignored) {
            return null;
        }
    }

    private String pageText(Page page) {
        try {
            Object value = page.evaluate("document.body ? document.body.innerText : ''");
            return value == null ? "" : String.valueOf(value);
        } catch (Exception e) {
            return page.content();
        }
    }

    private void safeWaitForLoad(Page page) {
        try { page.waitForLoad(); } catch (Exception ignored) { }
    }

    private String safeUrl(Page page) {
        try { return page.url(); } catch (Exception e) { return ""; }
    }

    private String safeTitle(Page page) {
        try { return page.title(); } catch (Exception e) { return ""; }
    }

    private String resolveUrl(String url, String baseUrl) {
        if (url == null || url.isBlank()) return firstNonBlank(baseUrl, "about:blank");
        String trimmed = url.trim();
        if (trimmed.startsWith("http://") || trimmed.startsWith("https://") || trimmed.startsWith("about:")) {
            return trimmed;
        }
        if (baseUrl == null || baseUrl.isBlank()) return trimmed;
        return URI.create(baseUrl.endsWith("/") ? baseUrl : baseUrl + "/").resolve(trimmed).toString();
    }

    private String firstNonBlank(String... values) {
        for (String value : values) {
            if (value != null && !value.isBlank()) return value;
        }
        return "";
    }

    private String nullToEmpty(String value) {
        return value == null ? "" : value;
    }

    private String sanitize(String value) {
        if (value == null || value.isBlank()) return "scenario";
        return value.replaceAll("[^a-zA-Z0-9._-]", "_");
    }
}
