package com.llmart.llm.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.llmart.llm.model.RunConfig;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Launches an already-installed Chrome/Chromium/Edge with remote debugging and returns
 * the real DevTools WebSocket URL. Vibium Java can then connect to this browser through
 * StartOptions.connectURL(...), which bypasses Vibium's Chrome-for-Testing downloader.
 */
public class LocalBrowserManager implements AutoCloseable {
    private final Process process;
    private final Path userDataDir;
    private final String connectUrl;

    private LocalBrowserManager(Process process, Path userDataDir, String connectUrl) {
        this.process = process;
        this.userDataDir = userDataDir;
        this.connectUrl = connectUrl;
    }

    public String getConnectUrl() {
        return connectUrl;
    }

    public static LocalBrowserManager fromConfig(RunConfig config, Path runDir) throws Exception {
        String browserPath = blankToNull(config.getChromeBinaryPath());
        String remoteDebugUrl = blankToNull(config.getRemoteDebugUrl());

        if (remoteDebugUrl != null) {
            String wsUrl = resolveWebSocketUrl(remoteDebugUrl);
            return new LocalBrowserManager(null, null, wsUrl);
        }

        if (browserPath == null) {
            throw new IllegalArgumentException("Chrome/Chromium/Edge executable path is required for Local Browser Connect mode");
        }

        Path executable = Path.of(browserPath);
        if (!Files.exists(executable)) {
            throw new IllegalArgumentException("Browser executable not found: " + browserPath);
        }

        int port = config.getRemoteDebugPort() != null && config.getRemoteDebugPort() > 0
                ? config.getRemoteDebugPort()
                : findFreePort();

        Path profileDir = runDir.resolve("remote-browser-profile");
        Files.createDirectories(profileDir);

        List<String> command = new ArrayList<>();
        command.add(executable.toAbsolutePath().toString());
        command.add("--remote-debugging-port=" + port);
        command.add("--remote-debugging-address=127.0.0.1");
        command.add("--user-data-dir=" + profileDir.toAbsolutePath());
        command.add("--no-first-run");
        command.add("--no-default-browser-check");
        command.add("--disable-popup-blocking");
        command.add("--disable-extensions");
        if (config.isHeadless()) {
            command.add("--headless=new");
            command.add("--disable-gpu");
        }
        command.add("about:blank");

        ProcessBuilder pb = new ProcessBuilder(command);
        pb.redirectErrorStream(true);
        Process process = pb.start();

        String wsUrl;
        try {
            wsUrl = waitForWebSocketUrl("http://127.0.0.1:" + port + "/json/version", process);
        } catch (Exception e) {
            process.destroyForcibly();
            throw e;
        }

        return new LocalBrowserManager(process, profileDir, wsUrl);
    }

    private static String resolveWebSocketUrl(String input) throws Exception {
        String value = input.trim();
        String lower = value.toLowerCase(Locale.ROOT);
        if (lower.startsWith("ws://") || lower.startsWith("wss://")) {
            return value;
        }
        String versionUrl = value;
        if (!lower.endsWith("/json/version")) {
            versionUrl = value.endsWith("/") ? value + "json/version" : value + "/json/version";
        }
        return waitForWebSocketUrl(versionUrl, null);
    }

    private static String waitForWebSocketUrl(String versionUrl, Process process) throws Exception {
        HttpClient client = HttpClient.newBuilder()
                .connectTimeout(Duration.ofSeconds(2))
                .build();
        ObjectMapper mapper = new ObjectMapper();
        Exception last = null;
        long end = System.currentTimeMillis() + 30_000;

        while (System.currentTimeMillis() < end) {
            if (process != null && !process.isAlive()) {
                throw new IllegalStateException("Browser process exited before remote debugging became ready. Check the chrome.exe/msedge.exe path and corporate browser policy.");
            }
            try {
                HttpRequest request = HttpRequest.newBuilder(URI.create(versionUrl))
                        .timeout(Duration.ofSeconds(2))
                        .GET()
                        .build();
                HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
                if (response.statusCode() >= 200 && response.statusCode() < 300) {
                    JsonNode root = mapper.readTree(response.body());
                    String ws = root.path("webSocketDebuggerUrl").asText(null);
                    if (ws != null && !ws.isBlank()) {
                        return ws;
                    }
                    throw new IllegalStateException("Remote debugging endpoint responded but webSocketDebuggerUrl was missing: " + versionUrl);
                }
            } catch (Exception e) {
                last = e;
            }
            Thread.sleep(500);
        }
        throw new IllegalStateException("Timed out waiting for browser remote debugging endpoint: " + versionUrl +
                (last == null ? "" : " | Last error: " + last.getMessage()), last);
    }

    private static int findFreePort() throws IOException {
        try (ServerSocket socket = new ServerSocket(0)) {
            socket.setReuseAddress(true);
            return socket.getLocalPort();
        }
    }

    private static String blankToNull(String value) {
        return value == null || value.trim().isBlank() ? null : value.trim();
    }

    @Override
    public void close() {
        if (process != null && process.isAlive()) {
            process.destroy();
            try {
                if (!process.waitFor(3, java.util.concurrent.TimeUnit.SECONDS)) {
                    process.destroyForcibly();
                }
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                process.destroyForcibly();
            }
        }
    }
}
