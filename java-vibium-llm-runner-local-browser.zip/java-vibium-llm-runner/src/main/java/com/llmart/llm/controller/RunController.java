package com.llmart.llm.controller;

import com.llmart.llm.model.RunConfig;
import com.llmart.llm.model.RunStatus;
import com.llmart.llm.model.TestScenario;
import com.llmart.llm.service.RunStore;
import com.llmart.llm.service.ScenarioFileParser;
import com.llmart.llm.service.TestRunService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/runs")
public class RunController {
    private final ScenarioFileParser parser;
    private final TestRunService testRunService;
    private final RunStore runStore;
    private final Path outputRoot;

    public RunController(ScenarioFileParser parser,
                         TestRunService testRunService,
                         RunStore runStore,
                         @Value("${runner.output-dir:target/vibium-test-runs}") String outputDir) {
        this.parser = parser;
        this.testRunService = testRunService;
        this.runStore = runStore;
        this.outputRoot = Path.of(outputDir);
    }

    @PostMapping(consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<?> startRun(
            @RequestParam("scenarioFile") MultipartFile scenarioFile,
            @RequestParam(required = false) MultipartFile vibiumBinaryFile,
            @RequestParam(required = false) MultipartFile driverFile,
            @RequestParam(required = false) String llmBaseUrl,
            @RequestParam(required = false) String llmApiKey,
            @RequestParam(required = false) String llmModel,
            @RequestParam(required = false) String appBaseUrl,
            @RequestParam(required = false) String vibiumBinaryPath,
            @RequestParam(required = false) String chromeBinaryPath,
            @RequestParam(required = false) String chromeDriverPath,
            @RequestParam(required = false, defaultValue = "LOCAL_BROWSER_CONNECT") String browserMode,
            @RequestParam(required = false) String remoteDebugUrl,
            @RequestParam(required = false) Integer remoteDebugPort,
            @RequestParam(defaultValue = "false") boolean headless,
            @RequestParam(defaultValue = "true") boolean useLlm,
            @RequestParam(defaultValue = "true") boolean continueOnFailure
    ) {
        try {
            List<TestScenario> scenarios = parser.parse(scenarioFile);
            if (scenarios.isEmpty()) {
                return ResponseEntity.badRequest().body(Map.of("error", "No scenarios found in uploaded file"));
            }

            RunConfig config = new RunConfig();
            config.setLlmBaseUrl(llmBaseUrl);
            config.setLlmApiKey(llmApiKey);
            config.setLlmModel(llmModel);
            config.setAppBaseUrl(appBaseUrl);
            config.setVibiumBinaryPath(firstNonBlank(vibiumBinaryPath, saveUpload(vibiumBinaryFile, "uploaded-vibium-binaries")));
            config.setChromeBinaryPath(chromeBinaryPath);
            config.setChromeDriverPath(firstNonBlank(chromeDriverPath, saveUpload(driverFile, "uploaded-drivers")));
            config.setBrowserMode(browserMode);
            config.setRemoteDebugUrl(remoteDebugUrl);
            config.setRemoteDebugPort(remoteDebugPort);
            config.setHeadless(headless);
            config.setUseLlm(useLlm);
            config.setContinueOnFailure(continueOnFailure);

            RunStatus status = testRunService.start(scenarios, config);
            return ResponseEntity.ok(status);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    @GetMapping("/{runId}")
    public ResponseEntity<?> getRun(@PathVariable String runId) {
        return runStore.get(runId)
                .<ResponseEntity<?>>map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.status(404).body(Map.of("error", "Run not found")));
    }

    @GetMapping("/{runId}/report.json")
    public ResponseEntity<?> downloadJson(@PathVariable String runId) {
        return download(runId, "report.json", MediaType.APPLICATION_JSON_VALUE);
    }

    @GetMapping("/{runId}/report.xlsx")
    public ResponseEntity<?> downloadExcel(@PathVariable String runId) {
        return download(runId, "report.xlsx", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
    }

    @GetMapping("/{runId}/screenshots.zip")
    public ResponseEntity<?> downloadScreenshots(@PathVariable String runId) {
        return download(runId, "screenshots.zip", "application/zip");
    }

    @GetMapping("/{runId}/screenshots/{filename:.+}")
    public ResponseEntity<?> screenshot(@PathVariable String runId, @PathVariable String filename) {
        return download(runId, "screenshots/" + filename, MediaType.IMAGE_PNG_VALUE);
    }

    private ResponseEntity<?> download(String runId, String relativeFile, String contentType) {
        try {
            Path path = outputRoot.resolve(runId).resolve(relativeFile).normalize();
            Path runDir = outputRoot.resolve(runId).normalize();
            if (!path.startsWith(runDir) || !Files.exists(path)) {
                return ResponseEntity.status(404).body(Map.of("error", "File not found"));
            }
            ByteArrayResource resource = new ByteArrayResource(Files.readAllBytes(path));
            String fileName = path.getFileName().toString();
            return ResponseEntity.ok()
                    .contentType(MediaType.parseMediaType(contentType))
                    .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + fileName + "\"")
                    .body(resource);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    private String saveUpload(MultipartFile file, String folder) throws Exception {
        if (file == null || file.isEmpty()) return "";
        String originalName = file.getOriginalFilename() == null ? "upload.bin" : file.getOriginalFilename();
        String safeName = originalName.replaceAll("[^a-zA-Z0-9._-]", "_");
        Path dir = outputRoot.resolve(folder);
        Files.createDirectories(dir);
        Path target = dir.resolve(System.currentTimeMillis() + "_" + safeName);
        file.transferTo(target);
        target.toFile().setExecutable(true);
        return target.toAbsolutePath().toString();
    }

    private String firstNonBlank(String... values) {
        for (String value : values) {
            if (value != null && !value.isBlank()) return value;
        }
        return "";
    }
}
