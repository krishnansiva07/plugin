# V25.2 — Internal HTTPS Certificate Navigation Fix

## Problem fixed

The UI recorder and normal Excel execution could launch Chrome but fail while opening an internal HTTPS application that uses a private or self-signed certificate. Chrome displayed **Your connection is not private**, while Vibium returned a generic WebDriver BiDi navigation failure such as:

```text
Failed to navigate: BiDi error: unknown error - unknown error
```

## Root cause

The current Vibium MCP `browser_start` schema exposes `headless`, but it does not expose the WebDriver `acceptInsecureCerts` capability or custom Chrome launch arguments. The framework therefore could not enable certificate acceptance during browser creation.

## Framework fix

V25.2 adds controlled certificate-interstitial recovery for approved internal test environments:

1. Try normal `browser_navigate`.
2. If HTTPS navigation fails and **Allow self-signed/internal HTTPS certificates** is enabled:
   - detect Chrome's privacy interstitial;
   - click **Advanced**;
   - click **Proceed**;
   - use DOM evaluation or Chrome's interstitial bypass sequence as fallback;
   - wait for navigation;
   - retry and verify the target application page.
3. Record recovery evidence in the MCP result/error diagnostics.

The recovery is used by both:

- Optional UI action recorder
- Normal Excel/JSON test execution

## UI change

A checked option is available in both recorder and execution sections:

```text
Allow self-signed/internal HTTPS certificates
```

Disable it when testing normal public websites or when certificate failures must remain blocking.

## Security boundary

This option is intended only for authorized non-production/internal QA environments. The preferred long-term solution remains installing the organization's trusted root/intermediate CA certificate on the machine or fixing the application certificate chain.
