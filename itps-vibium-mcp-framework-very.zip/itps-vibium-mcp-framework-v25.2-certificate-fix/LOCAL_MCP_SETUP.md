# ITPS Vibium Framework V25.1 — Manually Started Local MCP

## What changed

The old JAR attempted to start Vibium directly with `ProcessBuilder`. That works only when the configured command and all environment variables are identical on the target machine. It fails when the JAR contains a machine-specific path such as `C:\tools\...`.

Vibium MCP communicates through **JSON-RPC over stdio**. A Vibium MCP process started manually in one Command Prompt cannot be attached directly by a Java process in another Command Prompt. Therefore, this release includes a small localhost bridge:

```text
Framework JAR  <-- TCP 127.0.0.1:8765 -->  Local MCP Bridge  <-- stdio -->  Vibium MCP  --> Chrome
```

The bridge is started manually and remains open. For every framework execution, it launches the same Vibium command that works from the tools folder and forwards MCP messages. The JAR never launches Vibium directly in the default mode.

## Required software

- Java 17 or later for the framework JAR
- Node.js available in `PATH` for the local bridge
- The existing working Vibium portable folder and browser cache
- Maven only on the machine used to build the JAR; Maven is not required on your friend's machine after the JAR is built

## Recommended folder structure

```text
itps-vibium-mcp-framework-v25.1/
├── target/
│   └── itps-vibium-mcp-framework-25.1.0-EXTERNAL-MCP.jar
├── config/
│   └── application-local.properties
├── tools/
│   ├── vibium-portable/
│   │   └── node_modules/.bin/vibium.cmd
│   └── local-mcp-bridge/
│       ├── local-mcp-bridge.js
│       ├── local-mcp-config.json
│       └── start-local-mcp-windows.cmd
├── start-local-mcp-windows.cmd
└── start-framework-jar-windows.cmd
```

## Windows setup

### 1. Confirm Java and Node

Open Command Prompt:

```bat
java -version
node -v
```

Java must be 17 or later. Both commands must return a version.

### 2. Place the working Vibium folder

Copy the known-working Vibium folder to:

```text
tools\vibium-portable
```

The default bridge configuration expects:

```text
tools\vibium-portable\node_modules\.bin\vibium.cmd
```

When the working command is stored elsewhere, edit:

```text
tools\local-mcp-bridge\local-mcp-config.json
```

Example:

```json
{
  "host": "127.0.0.1",
  "port": 8765,
  "windowsCommand": "C:\\my-tools\\vibium-portable\\node_modules\\.bin\\vibium.cmd",
  "macCommand": "../vibium-portable/node_modules/.bin/vibium",
  "args": ["mcp", "--screenshot-dir", "./mcp-screenshots"],
  "workingDirectory": ".",
  "skipBrowserDownload": true
}
```

Use double backslashes in a Windows JSON path.

### 3. Start the local MCP bridge first

Double-click:

```text
start-local-mcp-windows.cmd
```

Keep the window open. It must display:

```text
Listening : 127.0.0.1:8765
Status    : READY - keep this window open
```

The bridge validates the Vibium command during startup. When the JAR starts a test, the bridge window displays `Java client connected` and then starts Vibium MCP.

### 4. Start the framework JAR

Double-click:

```text
start-framework-jar-windows.cmd
```

Open:

```text
http://localhost:8090
```

Upload the Excel/JSON file, select the required sheets, and click **Run Tests**.

### 5. Correct startup order

```text
1. start-local-mcp-windows.cmd
2. start-framework-jar-windows.cmd
3. Open the UI
4. Click Run Tests
```

Do not run `vibium.cmd mcp` manually in a separate window. Run the supplied local bridge, because the framework requires the TCP-to-stdio forwarding layer.

## macOS setup

Make scripts executable once:

```bash
chmod +x start-local-mcp-mac.sh start-framework-jar-mac.sh
chmod +x tools/local-mcp-bridge/start-local-mcp-mac.sh
```

Confirm Java and Node:

```bash
java -version
node -v
```

Start in this order:

```bash
./start-local-mcp-mac.sh
```

Keep that terminal open, then use another terminal:

```bash
./start-framework-jar-mac.sh
```

The default macOS command is:

```text
tools/vibium-portable/node_modules/.bin/vibium
```

Change `macCommand` in `tools/local-mcp-bridge/local-mcp-config.json` when required.

## Build the updated JAR

On a development machine with Java 17+ and Maven:

Windows:

```bat
build-windows.cmd
```

macOS/Linux:

```bash
./build-mac.sh
```

The packaged JAR is generated under `target`. Copy the complete framework folder, including `config` and `tools/local-mcp-bridge`, to the target machine.

## Configuration

The JAR reads:

```properties
itps.vibium.mcp.mode=external-tcp
itps.vibium.mcp.host=127.0.0.1
itps.vibium.mcp.port=8765
itps.vibium.mcp.connect-timeout-seconds=10
itps.vibium.mcp.request-timeout-seconds=90
```

These values are in:

```text
config/application-local.properties
```

The bridge host and port must match `local-mcp-config.json`.

## Legacy mode

To restore the previous behavior where the JAR launches Vibium directly, change:

```properties
itps.vibium.mcp.mode=process-stdio
```

Then configure:

```properties
itps.vibium.mcp.command=C:\\tools\\vibium-portable\\node_modules\\.bin\\vibium.cmd
itps.vibium.mcp.args=mcp
```

External mode is recommended for your friend's machine because the working Vibium command is maintained outside the JAR.

## Troubleshooting

### `Cannot connect to local Vibium MCP bridge at 127.0.0.1:8765`

The bridge is not running, the bridge window was closed, or the port values do not match. Start `start-local-mcp-windows.cmd` first.

### `Vibium command not found`

Edit `tools/local-mcp-bridge/local-mcp-config.json` and enter the exact command that works manually. On Windows, use double backslashes.

### `MCP timeout ... initialize`

Look at the bridge terminal and `tools/local-mcp-bridge/logs`. Common causes are an incorrect `args` value, a blocked browser executable, or a Vibium command that prints an error and exits.

### Bridge shows `Java client connected`, but browser does not open

Read the lines prefixed with `[VIBIUM]` in the bridge terminal. Run the exact configured command manually to confirm the portable browser/cache is available. Keep `skipBrowserDownload` set to `true` only when the browser cache is already copied.

### Port already in use

Close an older bridge process, or change port `8765` in both:

- `tools/local-mcp-bridge/local-mcp-config.json`
- `config/application-local.properties`

### Recorder and test execution at the same time

The bridge intentionally allows one active MCP client. Stop the recorder before starting tests, and wait for the current test execution to finish before starting another one.

## Logs

Bridge logs:

```text
tools/local-mcp-bridge/logs/local-mcp-YYYY-MM-DD.log
```

Framework MCP diagnostics for each run:

```text
target/itps-vibium-runs/<RUN-ID>/mcp-transcript.json
target/itps-vibium-runs/<RUN-ID>/mcp-process.log
```

## V25.2 internal HTTPS certificate handling

For approved QA environments that use private or self-signed certificates, keep **Allow self-signed/internal HTTPS certificates** selected. If Chrome displays **Your connection is not private**, the framework opens **Advanced**, proceeds to the internal site, retries navigation, and verifies the target page before recording or executing steps.

For production/public websites, disable this option. Installing the organisation's trusted CA certificate remains the preferred long-term solution.
