# V25.2 Certificate Fix - Validation Results

## Root cause verified

The current Vibium MCP `browser_start` tool accepts `headless` only. It does not expose a caller-supplied `acceptInsecureCerts` capability or arbitrary Chrome launch arguments. For an internal site with a private/self-signed certificate, Chrome can therefore display its privacy interstitial while `browser_navigate` returns a generic BiDi navigation error.

## Fix implemented

- Added controlled Chrome certificate-interstitial recovery for UI recording and normal Excel execution.
- Added per-session/per-run UI controls; enabled by default.
- Recovery attempts `Advanced` and `Proceed`, then uses DOM and keyboard fallbacks, retries navigation, and verifies the final URL/page state.
- Recovery is attempted only for HTTPS URLs and only when the option is enabled.
- Original failure and recovery evidence are included when recovery cannot complete.

## Static checks completed

- JavaScript syntax: PASS (`node --check`)
- JSON configuration parsing: PASS
- Maven POM XML parsing: PASS
- Java parser-level compilation scan: PASS (no Java syntax/parser errors found)
- ZIP structure and startup scripts: PASS

## Not executed in this environment

A full Maven build and end-to-end browser run were not possible because Maven/dependency artifacts and the user's internal HTTPS application are not available in this runtime. Build the project on the development machine with `build-windows.cmd`, then test against the internal URL.

## Recommended production correction

The long-term enterprise correction is to install/trust the organisation's internal root/intermediate CA on the test machine. The automatic bypass is intended for approved QA/internal environments, not public production websites.
