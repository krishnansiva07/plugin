# V25.1 startup change

This release defaults to a manually started local MCP bridge. Start `start-local-mcp-windows.cmd` or `start-local-mcp-mac.sh` before starting the framework JAR. See [LOCAL_MCP_SETUP.md](LOCAL_MCP_SETUP.md).

# ITPS VIBIUM Framework V25 — Optional UI Recorder

Java Spring Boot test runner using Vibium MCP for browser execution.


V25 adds an optional manual UI action recorder to the existing Excel-driven Vibium MCP runner. Normal test execution is unchanged. When recording is enabled, the application URL is mandatory, a headed selected browser is launched, and the user’s clicks, typing, selections, checkboxes, keyboard actions and uploads are converted into the same executable step syntax already accepted by the framework.

## V25 recorder quick start

1. Start the Spring Boot application and open `http://localhost:8090`.
2. Enable **Record UI actions and generate Excel steps**.
3. Enter the mandatory complete application URL.
4. Select the installed browser in the existing Browser section.
5. Click **Start recording** and perform the scenario in the launched headed browser.
6. Click **Stop recording**.
7. Review/delete generated actions, copy the steps, or download the generated Excel/JSON.

Example generated steps:

```text
Click "Entity Code" using css="#entityCode"
Type "BCEF" in "Entity Code" using css="#entityCode input"
Click "BCEF" using xpath="//*[@role='option' and normalize-space(.)='BCEF']"
```

The Excel download contains:

- `RecordedScenario`: one directly executable scenario row using the existing `Run, Id, Name, Url, Steps, Expected` layout.
- `RecordedActions`: technical metadata including the selected locator, fallback locator, frame path, shadow DOM flag, page URL and masked-sensitive flag.

Recorder outputs are also written under:

```text
target/itps-vibium-recordings/<session-id>/
```

### Recorder execution policy

Recorded XPath/CSS is absolute first priority during playback:

```text
explicit XPath or CSS -> fresh live DOM resolution -> native Vibium action -> observable confirmation -> self-healing only after failure
```

The V25 CSS executor does not mark clicks as passed merely because `browser_click` returned successfully. It checks URL, overlays, target state, target context and DOM changes. Fill/select/check actions are verified against the final value/state.

### Sensitive data

Password, OTP, CVV, secret/token and card-number-like inputs are masked as variables such as `${PASSWORD}`, `${OTP}` and `${SECRET}`. Replace/provide these values through the test-data mechanism instead of storing real secrets in the recording.

### Recorder boundaries

The injected recorder supports normal DOM, Angular/SPA overlays, same-origin iframes and open shadow roots. Browser-native dialogs, closed shadow roots and cross-origin iframe documents cannot be inspected by page JavaScript. A cross-origin full navigation may also prevent the last pre-navigation event from being recovered because browser storage is origin-scoped. These cases require a browser-extension/CDP-level recorder enhancement in a future version.

Only one recording session is allowed at a time in this local framework instance.

## Run

```cmd
set VIBIUM_SKIP_BROWSER_DOWNLOAD=1
mvn clean spring-boot:run
```

Open `http://localhost:8090`.

## Vibium MCP configuration

Configure the portable Vibium command in `src/main/resources/application.properties`:

```properties
itps.vibium.mcp.command=C:\tools\vibium-portable\node_modules\.bin\vibium.cmd
itps.vibium.mcp.args=mcp
```

## V11 Responsible unified page model

V11 Responsible separates page understanding into two inventories instead of treating only clickable controls as page elements.

### Action inventory

Used for click, fill, type, select, check, hover and keyboard actions. It includes semantic controls, custom clickable containers, icons/SVG controls, role/tabindex/onclick controls, open shadow DOM and same-origin iframe controls.

### Validation inventory

Used for visible-text and UI-data validation. It includes headings, labels, spans, cards, status badges, paragraphs, table headers/cells, list items, read-only values, selected options, input values and other visible DOM text—even when the element is not interactive.

The unified page model stores:

- `actionElements`
- `contentElements`
- `formValues`
- `tables`
- `allVisibleText`
- element context, coordinates and generated CSS selectors

Natural-language action steps are planned using the action inventory. Validation steps such as `Verify LMIS status is Integrated` are evaluated directly against the validation inventory and do not depend on the LLM choosing a clickable element.

## Supported validation patterns

Examples:

```text
Verify Banking entity details is displayed
Verify banking entity code is AAAAFRAB
Verify BIC8 identifier is BK26020000009711
Verify LMIS status is Integrated
Verify Host identifier is FRH026020012385
Verify Branch Code identifier is BR26020000007361
Verify authorization status is Not authorized
Verify CAM tab is visible
```

Label/value assertions use element text, accessible names, parent context, nearby visible elements and form values.

## Diagnostics and reports

Each run writes:

```text
target/itps-vibium-runs/<run-id>/
```

- `report.html` — consolidated test results
- `logs.html` — searchable technical execution logs
- `report.xlsx`
- `report.json`
- `screenshots.zip`
- `elements/` — complete unified page model by test and step
- `mcp-transcript.json`
- `mcp-process.log`

## Browser limitations

Closed shadow roots, cross-origin iframe documents and canvas-only content cannot be fully inspected using normal DOM evaluation. V11 Responsible records the available frame/context evidence instead of silently choosing an unrelated element.


## V11 Responsible final enhancements
- 100% Vibium MCP browser execution; no Selenium or Playwright fallback.
- Full unified DOM/page model for actions and validations.
- LLM deep DOM self-healing after action or validation failure.
- User-configurable failure healing attempts (0-2 in UI).
- Confidence-gated healing to prevent unsafe guesses.
- PASS_HEALED status and complete healing evidence in HTML, JSON and Excel reports.
- Fresh DOM, screenshot, candidate ranking and failure context captured before every healing attempt.


## V11 Responsible execution guarantees
- Hover, click, and composite menu actions require observable post-action evidence.
- MCP completion alone can never produce a pass for an action step.
- Zero or invalid MCP timeouts are normalized to 15 seconds.
- Composite instructions are planned as ordered hover/open, wait/re-observe, and exact-menu-item click calls.
- After the first failed UI step, remaining dependent steps are marked `SKIPPED_DEPENDENCY_FAILURE` rather than producing cascading false failures.

## V17 deterministic custom controls

Use exact business-oriented steps; XPath is not required:

```text
Select "BCEF" from Perimeter dropdown
Click the white action stripe in the first visible data row
Click menu item "See Track & Trace"
```

The framework resolves Angular `ng-select` controls by label and resolves the row menu trigger by its DOM behavior/hit-test rather than by colour alone.

## V19 XPath override behavior

Plain English remains the default. When a step includes `using xpath`, `following xpath`, `xpath=`, `xpath:`, or `[xpath=...]`, the supplied XPath is attempted first. The first visible match is used. Failure automatically enters the existing healing flow. For select steps the XPath points to the field/control, while the requested option is inferred from the English instruction.


## V21
See `V21_FIX_NOTES.md` for fresh DOM per-action behavior and execution-date reporting.


## V22 enterprise Angular and dynamic dropdown execution

V22 executes dropdown selection as a strict transaction instead of treating it as one generic click:

```text
Resolve trigger -> native Vibium click once -> fresh live DOM -> active overlay/listbox ->
exact option -> native Vibium click once -> exact selected-value verification
```

Supported component families include native `select`, Angular Material/CDK overlays, `ng-select`, PrimeNG, Ant Design, Select2, Bootstrap-style menus, autocomplete panels, lazy option loading and virtual-scroll viewports. Open shadow roots and same-origin iframe documents are inspected; when a native top-document selector cannot reach those contexts, a hit-tested single-click fallback is used.

Recommended semantic format:

```text
Select BCEF from MF dropdown
Set MF to BCEF
Click BCEF from the visible options
```

XPath remains optional. A single supplied option XPath is now recognised as an option rather than incorrectly treated as the trigger:

```text
Select BCEF from MF dropdown using xpath=//div[@role='option' and normalize-space(.)='BCEF']
```

For maximum control, use separate locators in one Excel step:

```text
Select "BCEF" from "MF" dropdown 
triggerXPath=//*[@id='mf-trigger'] 
optionXPath=//*[@role='option' and normalize-space(.)='BCEF'] 
verifyXPath=//*[@id='mf-selected-value']
```

`triggerXPath`, `optionXPath`, and `verifyXPath` are optional. When supplied, V22 waits for each locator in the correct UI phase. The step passes only when the final field value is exactly verified.

Other XPath actions now prefer Vibium's native click/fill tools. JavaScript click recovery is hit-tested and emits exactly one click, preventing Angular controls from opening and immediately closing because of duplicate events. Composite action plans are no longer stopped after their first state-changing sub-action.

See `V22_FIX_NOTES.md` for implementation details and supported test cases.


## V23 explicit XPath priority and Angular search-result fix

V23 treats a user-supplied XPath as an executable instruction, not as a hint for the LLM.
For ordinary click, fill and verification steps, the priority is:

```text
User XPath -> user CSS/structured locator -> deterministic DOM locator -> visible text -> LLM -> recovery
```

The XPath is re-evaluated against the current live DOM and the action is performed in the same
`browser_evaluate` operation. This prevents Angular from replacing a search-result node between
locator resolution and the click.

The following formats are accepted, including Microsoft Excel/Word smart quotation marks:

```text
Click the element using following Xpath “//*[text()=‘BCEF’]”
Click element using xpath="//*[@role='option' and normalize-space(.)='BCEF']"
Type "BCEF" using xpath="//input[@aria-autocomplete='list']"
```

For XPath clicks, V23:

- bypasses LLM locator generation;
- waits for a visible, enabled live match;
- promotes a child text node such as `<span>BCEF</span>` to its clickable option ancestor;
- waits through two Angular render frames and resolves the node again;
- performs one hit-tested click only;
- verifies dropdown-option interaction through selected state, combobox collapse, or active-overlay closure;
- does not treat element detachment alone as success;
- records `USER_XPATH_LIVE_PRIORITY` in technical reports.

The Angular dropdown transaction also resolves and clicks the option in one browser operation,
excludes the general `.cdk-overlay-container` from active-panel selection, and cleans temporary
markers in a `finally` block.

See `V23_FIX_NOTES.md` and `samples/angular-live-xpath-v23-examples.json`.


## V24 native-first deterministic execution

V24 fixes the two execution gaps shown in the supplied Excel scenarios:

1. An explicit XPath is now used only to resolve the **current live element**. The resolved element is marked and then acted on with Vibium's native `browser_click` or `browser_fill` command whenever the tool accepts selectors. JavaScript pointer/value events are only a compatibility fallback for same-origin frame/open-shadow contexts that the native top-document selector cannot reach.
2. `Click "BCEF" using visible text` is now a first-class deterministic action. It no longer falls through to LLM planning.
3. A standalone `Type "BCEF"` after opening a combobox now resolves the current active/expanded combobox input and uses native fill, with retries and final-value verification.
4. Hidden internal inputs from `ng-select` and similar controls are promoted to a visible combobox/control proxy for click actions.
5. Structural XPath matches such as a datatable cell are refined to the hit-tested descendant under the real click point.
6. Every XPath action is re-resolved on retry and must produce an observable postcondition. A tool response alone cannot mark a step as passed.

Accepted examples:

```text
Click on the white strip using xpath="//datatable-body/datatable-selection/datatable-scroller/datatable-row-wrapper[1]/datatable-body-row/div[1]/datatable-body-cell[1]"
Click using xpath="//*[@id='entityCode']//input"
Type "BCEF"
Click "BCEF" using visible text
Click "Clear all" in sub entity using xpath="//*[@id='subEntityCode']//*[@title='Clear all']"
```

For the most deterministic searchable dropdown flow, keep the type and locator together:

```text
Click using xpath="//*[@id='entityCode']"
Type "BCEF" using xpath="//*[@id='entityCode']//input"
Click "BCEF" using visible text
```

See `V24_FIX_NOTES.md`, `V24_VALIDATION_RESULTS.md`, and `samples/angular-xpath-v24-corrected-examples.json`.

## V26 multi-sheet execution and cross-platform setup

After uploading an Excel workbook, the UI displays a checkbox for every worksheet. Select any combination of sheets, or use **Select all** / **Clear all**, then run them together in one execution. Enabled rows from the selected sheets are combined, duplicate test IDs are made unique, and each scenario records its `sourceSheet`.

Complete Windows and macOS installation, configuration, JAR execution and troubleshooting instructions are available in [`SETUP_GUIDE_WINDOWS_MAC.md`](SETUP_GUIDE_WINDOWS_MAC.md).

## V25.2 internal HTTPS certificate handling

For approved QA environments that use private or self-signed certificates, keep **Allow self-signed/internal HTTPS certificates** selected. If Chrome displays **Your connection is not private**, the framework opens **Advanced**, proceeds to the internal site, retries navigation, and verifies the target page before recording or executing steps.

For production/public websites, disable this option. Installing the organisation's trusted CA certificate remains the preferred long-term solution.
