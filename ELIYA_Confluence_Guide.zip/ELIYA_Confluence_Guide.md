# ELIYA — AI-Powered Engineering Assistant

> **Functional overview and quick-start guide**  
> **Version:** ELIYA117  
> **Audience:** Developers, QA engineers, automation engineers, technical leads, architects and functional teams  
> **Updated:** 02 November 2026  
> **Purpose:** Introduce ELIYA, explain its main capabilities and help users get started.

---

## 1. What is ELIYA?

**ELIYA is an AI-powered engineering assistant** that helps teams understand existing projects, analyse requirements, generate tests and documentation, and implement software changes through natural-language conversations.

ELIYA brings **workspace knowledge, AI analysis, and agentic execution** into a single interface. Users can investigate a problem, review a recommended approach and ask ELIYA to implement it—without starting the task from scratch.

**Example interaction**

> **User:** Analyse my Java Selenium automation framework and identify improvement areas.  
> **ELIYA:** Reviews available workspace evidence and recommends improvements.  
> **User:** Implement the recommended exception-handling changes.  
> **ELIYA:** Passes the relevant analysis into the selected execution engine, makes permitted changes and reports the outcome.

### Why teams use ELIYA

- **Faster understanding:** Explore unfamiliar repositories, dependencies and application behavior.
- **Less repetitive work:** Assist with test generation, code changes, migrations and documentation.
- **Context continuity:** Carry relevant findings from analysis into execution in the same conversation.
- **Enterprise alignment:** Work with existing project structures and configured external systems.
- **Execution visibility:** Review tool activity, changed files, validation results and reported model usage.

## 2. Core capabilities

| Capability | What it enables |
| --- | --- |
| **Unified conversation** | Ask questions, analyse requirements and request implementation in one workflow. |
| **Workspace intelligence** | Retrieve relevant project files, code structure and dependencies from an index. |
| **Analyse and Execute** | Investigate first, then implement requested changes with context preserved. |
| **Native ELIYA and OpenCode engines** | Choose a built-in agent or optional compatible OpenCode installation; Auto selects an eligible engine. |
| **Automatic workspace synchronization** | Detect file additions, edits, renames and deletions; incrementally refresh indexed information. |
| **Reference projects** | Compare the primary workspace with up to five reference projects for reuse or migration. |
| **Document and test-case workflows** | Analyse supported requirements documents and produce structured test scenarios. |
| **MCP connectivity** | Use configured Jira, Confluence, GitLab, SonarQube and other tools when explicitly requested. |
| **Execution monitoring** | Display available activity, duration, clarifications, outcomes and provider-reported token consumption. |
| **Documentation tools** | Prepare technical or functional content using the Confluence Composer. |

**Note:** Capabilities that require external tools, model support or permissions depend on the user's environment and configuration.

## 3. How ELIYA works

**High-level flow**

**User request → Intent and context analysis → Workspace / document / MCP retrieval → AI analysis or agent execution → Verification → Response**

1. **Ask:** The user describes a task in plain language.
2. **Understand:** ELIYA identifies whether it is an analysis request or a request to perform changes.
3. **Retrieve:** ELIYA uses relevant conversation history, current workspace content, documents and explicitly requested MCP sources.
4. **Act:** For read-only questions, it returns findings. For implementation tasks, it invokes the configured agent engine and permitted tools.
5. **Verify and report:** It reports what was changed, what was checked, any errors and available token-usage information.

### Analyse vs Execute

| Analyse | Execute |
| --- | --- |
| Understand code, requirements, dependencies and impact. | Create or modify code, run permitted commands and perform validation. |
| Produces explanations, comparisons and recommendations. | Produces implementation changes and an execution report. |
| Intended to avoid project modification. | Requires an authorized writable workspace and applicable permissions. |

**Conversation example:** “Compare this Jira story using Jira MCP with my workspace” → review the gap analysis → “Implement the missing validations.”

## 4. Getting started — setup

### Prerequisites

- **Java 17 or newer** and access to the approved **ELIYA executable JAR**.
- A reachable **AI model endpoint** and an API key if the provider requires one.
- A project directory accessible from the machine running ELIYA.
- **Optional:** Compatible **OpenCode 2.2+** if users want OpenCode execution; ELIYA's native engine is available without it.
- **Only for source builds:** Maven and the project's build prerequisites.

### Step 1 — Start the application

If an approved executable JAR is available, run it from a terminal:

```bash
java -jar eliya.jar
```

Open the local user interface at the address shown by the application.

**If building from source:** On Windows, extract the source and run `build-jar-windows.cmd`; after a successful build, launch the generated JAR (for example, `java -jar target/eliya.jar`). A source ZIP alone is not an executable application.

### Step 2 — Configure the AI connection

Open **Settings** and enter the approved provider details:

| Setting | What to enter |
| --- | --- |
| **Base URL** | Organization-approved model API endpoint. |
| **API key** | Provider credential, if required. |
| **Chat model** | Model for conversation and analysis. |
| **Agent model** | Model for code implementation and agentic execution. |

Save the configuration and confirm a simple prompt receives a response. Optional vision, embedding, permission and MCP settings may be configured as needed. **Do not paste credentials into task prompts.**

### Step 3 — Add a workspace

1. Select **Enter path** or the equivalent workspace control.
2. Provide the absolute path to the primary project (for example, `C:\Automation\MyFramework`).
3. Allow initial indexing to run; confirm the workspace/index status.
4. Optionally add named **Reference paths** for comparison or migration. Reference projects are intended to be read-only.

From ELIYA116 onward, the application includes automatic incremental synchronization after eligible filesystem changes. **Rescan** remains available if an update is not reflected.

### Step 4 — Select the execution engine

| Option | When to select |
| --- | --- |
| **Auto** | Preferred general-purpose choice; selects an eligible configured backend. |
| **OpenCode** | Use a supported, locally available OpenCode engine. |
| **ELIYA** | Use ELIYA's native agent implementation. |

Check that the selected engine is available before requesting implementation. OpenCode is optional.

### Step 5 — Run a first task

Try a read-only prompt:

> Analyse the selected workspace. Summarize the framework architecture, key components and improvement opportunities.

Then request a **small, scoped implementation** and review the execution report and changed files before moving to larger tasks.

## 5. Common usage scenarios

| Scenario | Example prompt |
| --- | --- |
| Understand a codebase | “Explain the architecture of my current automation framework.” |
| Requirement gap analysis | “Retrieve BMSA-1234 using Jira MCP and compare it with the workspace.” |
| Generate test cases | “Generate positive, negative and boundary test scenarios from the attached specification.” |
| Improve automation | “Analyse flaky Selenium waits and recommend stable fixes.” |
| Implement changes | “Implement the approved retry-handling improvements and run relevant tests.” |
| Compare projects | “Compare the reference framework with the primary workspace and identify missing features.” |
| Prepare documentation | “Create a high-level technical overview suitable for Confluence.” |

**Best practice:** State the objective, relevant module, constraints and expected output. For external systems, explicitly request the configured **MCP** integration.

## 6. Workspace freshness and execution transparency

**Workspace accuracy:** ELIYA indexes project content and watches for supported file changes. New, modified, renamed or deleted files can trigger incremental updates; periodic reconciliation helps recover missed events. Changes are **eventually consistent**, not instantaneous. An earlier chat mention does not prove a deleted file still exists.

**Progress and completion:** Execution views can show available model/tool activity, pending clarifications, elapsed time, affected files and validation outcomes. Check the actual result rather than assuming an estimated percentage means the task is complete.

**Token usage:** ELIYA117 adds OpenCode live-usage reporting and reconciliation paths. Counts are based on data reported by the execution provider. **“Not reported” is different from zero tokens**; some counters arrive only after a model step finishes.

**Safety:** Agent file changes and commands remain subject to configured permissions. Use version control and verify important changes. Rollback is available for eligible operations but may not reverse every external or destructive effect.

## 7. Quick troubleshooting

| Symptom | First checks |
| --- | --- |
| Application does not launch | Java version, JAR path, startup output. |
| AI model not responding | Base URL, model ID, credentials, proxy and network reachability. |
| Workspace files missing or outdated | Workspace path, index status, ignored file types and **Rescan**. |
| OpenCode execution unavailable | OpenCode installation, compatibility and engine selection; use native ELIYA if needed. |
| Execution appears stuck | Latest actual tool/model activity, outstanding questions, permissions and errors. |
| Token count missing | Provider reporting status; do not interpret an empty value as zero. |
| MCP retrieval fails | MCP enabled, correct credentials, server connectivity and explicit MCP request. |

## 8. Key takeaways

**ELIYA connects the full engineering workflow:**

**Understand → Analyse → Recommend → Implement → Validate → Improve**

It is designed to help technical and functional teams use existing project context to make informed changes more efficiently. AI-assisted results must still be reviewed, tested and approved according to normal engineering practices.

---

### Publishing this page in Confluence

1. Save or download this file as **`ELIYA_High_Level_Confluence_Guide.md`**.
2. In **ELIYA → Confluence Composer**, import the Markdown file (or paste its contents).
3. Select **Format & Preview**, then **Copy for Confluence**.
4. Paste into your Confluence page and check headings, tables and code blocks before publishing.

> **Release note:** This is a high-level functional guide based on the ELIYA117 documentation. Full installation and OpenCode model-gateway behavior should be confirmed in the target deployment environment.
