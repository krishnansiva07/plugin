import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { envBoolean, envNumber } from '../utils/Environment';
import type { CachedLocator } from './HealingTypes';
import type { HealingSuggestion } from '../llm/LlmClient';

export class HealingRepository {
  readonly enabled = envBoolean('HEALING_CACHE_ENABLED', true);
  private readonly maxEntries = envNumber('HEALING_CACHE_MAX_ENTRIES', 500);
  private readonly file = path.resolve(process.env.HEALING_CACHE_FILE || 'test-results/healing-cache.json');

  buildKey(input: { application: string; pageUrl: string; pageTitle: string; action: string; target: string }): string {
    const normalizedUrl = input.pageUrl.replace(/[?#].*$/, '').replace(/\/[0-9a-f-]{8,}/gi, '/:id');
    return crypto.createHash('sha256').update([
      this.normalize(input.application), normalizedUrl.toLowerCase(), this.normalize(input.pageTitle),
      this.normalize(input.action), this.normalize(input.target)
    ].join('|')).digest('hex');
  }

  find(key: string): CachedLocator | undefined {
    if (!this.enabled) return undefined;
    return this.read().find(item => item.key === key && item.successCount >= item.failureCount);
  }

  save(input: Omit<CachedLocator, 'successCount' | 'failureCount' | 'updatedAt'>): void {
    if (!this.enabled) return;
    const items = this.read();
    const existing = items.find(item => item.key === input.key);
    if (existing) {
      Object.assign(existing, input, { successCount: existing.successCount + 1, updatedAt: new Date().toISOString() });
    } else {
      items.push({ ...input, successCount: 1, failureCount: 0, updatedAt: new Date().toISOString() });
    }
    this.write(items.slice(-this.maxEntries));
  }

  markFailure(key: string): void {
    if (!this.enabled) return;
    const items = this.read();
    const existing = items.find(item => item.key === key);
    if (existing) {
      existing.failureCount += 1;
      existing.updatedAt = new Date().toISOString();
      this.write(items);
    }
  }

  static toSuggestion(cached: CachedLocator): HealingSuggestion {
    return cached.suggestion as HealingSuggestion;
  }

  private normalize(value: unknown): string { return typeof value === 'string' ? value.trim().toLowerCase() : ''; }

  private read(): CachedLocator[] {
    try {
      if (!fs.existsSync(this.file)) return [];
      const parsed = JSON.parse(fs.readFileSync(this.file, 'utf8')) as unknown;
      return Array.isArray(parsed) ? parsed as CachedLocator[] : [];
    } catch {
      return [];
    }
  }

  private write(items: CachedLocator[]): void {
    fs.mkdirSync(path.dirname(this.file), { recursive: true });
    const temp = `${this.file}.tmp`;
    fs.writeFileSync(temp, JSON.stringify(items, null, 2), 'utf8');
    if (fs.existsSync(this.file)) fs.unlinkSync(this.file);
    fs.renameSync(temp, this.file);
  }
}
