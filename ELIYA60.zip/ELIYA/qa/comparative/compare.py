#!/usr/bin/env python3
"""Evidence-first paired benchmark across Eliya, OpenCode and optionally Claude Code.

Never infer token counts from elapsed time, model context estimates or run cost. Each
provider-reported token total must be supplied for the SAME objective/model/run trial.
"""
import csv
import statistics
import sys
from collections import defaultdict
from pathlib import Path

REQUIRED = {'task_id', 'run', 'agent', 'model', 'passed', 'accuracy', 'elapsed_ms', 'unauthorized_writes'}
AGENTS = {'eliya', 'opencode', 'claude'}


def main(path):
    with Path(path).open(newline='', encoding='utf-8') as fh:
        reader = csv.DictReader(fh)
        if not reader.fieldnames or not REQUIRED.issubset(reader.fieldnames):
            raise ValueError(f'Missing columns: {sorted(REQUIRED - set(reader.fieldnames or []))}')
        rows = list(reader)
    if not rows:
        raise ValueError('No benchmark data. Run equivalent tasks before comparing.')
    grouped = defaultdict(dict)
    for row in rows:
        agent = row['agent'].strip().lower()
        if agent not in AGENTS:
            raise ValueError('agent must be eliya, opencode or claude')
        key = (row['task_id'].strip(), row['run'].strip(), row['model'].strip())
        if not all(key):
            raise ValueError('task_id, run and model are required')
        if agent in grouped[key]:
            raise ValueError(f'Duplicate agent result: {key}, {agent}')
        if row['passed'].lower() not in {'true', 'false'}:
            raise ValueError('passed must be true or false')
        score = float(row['accuracy'])
        if not 0 <= score <= 1:
            raise ValueError('accuracy must be between 0 and 1')
        elapsed, writes = int(row['elapsed_ms']), int(row['unauthorized_writes'])
        if elapsed <= 0 or writes < 0:
            raise ValueError('elapsed_ms must be >0 and unauthorized_writes >=0')
        # Optional token counters MUST be measured by the provider and must be
        # present for every compared agent before producing a token comparison.
        token_fields = {}
        for column in ('total_tokens', 'input_tokens', 'output_tokens', 'cached_input_tokens'):
            raw = row.get(column, '').strip() if row.get(column) is not None else ''
            token_fields[column] = None if not raw else int(raw)
            if token_fields[column] is not None and token_fields[column] < 0:
                raise ValueError(f'{column} must be >= 0')
        total = token_fields['total_tokens']
        inp, out = token_fields['input_tokens'], token_fields['output_tokens']
        cached = token_fields['cached_input_tokens']
        if total is not None and inp is not None and out is not None and total < inp + out:
            raise ValueError('total_tokens cannot be less than input_tokens + output_tokens')
        if cached is not None and inp is not None and cached > inp:
            raise ValueError('cached_input_tokens is a subset of input_tokens')
        grouped[key][agent] = {
            'passed': row['passed'].lower() == 'true', 'accuracy': score,
            'elapsed_ms': elapsed, 'unauthorized_writes': writes, **token_fields,
        }

    # Separate pairwise trials remain valid when Claude Code cannot run a
    # provider-supported model used in an Eliya/OpenCode comparison.
    compared = False
    for competitor in ('opencode', 'claude'):
        pairs = [trial for trial in grouped.values() if {'eliya', competitor} <= trial.keys()]
        if not pairs:
            continue
        compared = True
        print(f'\nEliya vs {competitor}: {len(pairs)} paired same-task/same-model trials')
        for agent in ('eliya', competitor):
            records = [pair[agent] for pair in pairs]
            success = sum(p['passed'] for p in records)
            security = sum(p['unauthorized_writes'] for p in records)
            print(f'{agent}: passed={success}/{len(records)}; accuracy={statistics.mean(p["accuracy"] for p in records):.3f}; '
                  f'average_ms={statistics.mean(p["elapsed_ms"] for p in records):.0f}; unauthorized_writes={security}')
        token_pairs = [pair for pair in pairs if all(pair[a]['total_tokens'] is not None for a in ('eliya', competitor))]
        if token_pairs:
            for agent in ('eliya', competitor):
                print(f'{agent}: mean_provider_tokens={statistics.mean(p[agent]["total_tokens"] for p in token_pairs):.0f} '
                      f'({len(token_pairs)} verified token pairs)')
            wins = sum(pair['eliya']['total_tokens'] <= pair[competitor]['total_tokens'] for pair in token_pairs)
            e_pass = sum(pair['eliya']['passed'] for pair in token_pairs)
            c_pass = sum(pair[competitor]['passed'] for pair in token_pairs)
            print(f'Eliya used <= tokens on {wins}/{len(token_pairs)} pairs; passed {e_pass}/{len(token_pairs)} '
                  f'vs {c_pass}/{len(token_pairs)}. Only claim an optimization if quality and safety hold.')
        else:
            print('Token comparison unavailable: supply provider-reported total_tokens for BOTH agents; estimates are not comparable.')
        if len(pairs) < 3:
            print('NOTE: fewer than 3 paired runs; not evidence of general superiority.')
    if not compared:
        raise ValueError('No equivalent task_id/run/model pairs including Eliya and another agent')


if __name__ == '__main__':
    if len(sys.argv) != 2:
        sys.exit('Usage: python3 compare.py results.csv')
    try:
        main(sys.argv[1])
    except (ValueError, OSError) as error:
        sys.exit('BENCHMARK INCOMPLETE: ' + str(error))
