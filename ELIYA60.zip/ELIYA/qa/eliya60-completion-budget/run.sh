#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../.."
TMP=$(mktemp -d); trap 'rm -rf "$TMP"' EXIT
mkdir -p "$TMP/src/com/llmart/llm/service" "$TMP/src/org/springframework/stereotype" "$TMP/classes"
cat > "$TMP/src/org/springframework/stereotype/Service.java" <<'JAVA'
package org.springframework.stereotype; public @interface Service {}
JAVA
cat > "$TMP/src/com/llmart/llm/service/OpenAiCompatibleClient.java" <<'JAVA'
package com.llmart.llm.service; class OpenAiCompatibleClient {
 record Usage(long inputTokens,long outputTokens,long totalTokens,long cachedInputTokens,long cacheWriteTokens) {}
}
JAVA
cat > "$TMP/src/com/llmart/llm/service/ProtectedRunSnapshotService.java" <<'JAVA'
package com.llmart.llm.service; class ProtectedRunSnapshotService {void discard(String id) {}}
JAVA
cat > "$TMP/src/com/llmart/llm/service/AgentCancelledException.java" <<'JAVA'
package com.llmart.llm.service; class AgentCancelledException extends RuntimeException {AgentCancelledException(String s){super(s);}}
JAVA
cat > "$TMP/src/com/llmart/llm/service/CompletionBudgetSmoke.java" <<'JAVA'
package com.llmart.llm.service;
import java.nio.file.*;import java.util.*;
public class CompletionBudgetSmoke {
 static void ok(boolean value,String message){if(!value)throw new AssertionError(message);}
 public static void main(String[] args)throws Exception {
  Path dir=Files.createTempDirectory("eliya60-run-");
  var store=new AgentRunService(dir);
  var run=store.start("success", "workspace");
  run.setObjective("Create one .md artifact and verify it");
  run.setPlan(List.of("Create requested markdown file", "Read and validate generated markdown file"));
  ok(!run.allPlanStepsCompleted(),"Plan not yet started must not count as complete");
  run.markPlanStarted();
  run.recordPlanToolActivity("write", "Created .opencode/agents/code-reviewer.md");
  run.markMutation();
  run.updatePlan(1,"completed", "Saved markdown file");
  ok(!run.allPlanStepsCompleted(),"Final verification step is pending");
  ok(!run.verifiedCurrentRevision(),"Workspace mutation invalidates verifier");
  run.recordPlanToolActivity("bash", "Read-only markdown validation passed");
  run.markVerificationAttempt(true,"Structure and contents checked");
  run.updatePlan(2,"completed", "Verified generated markdown");
  ok(run.allPlanStepsCompleted() && run.verifiedCurrentRevision(),"Verified complete plan must close");
  run.finish("completed");
  ok("completed".equals(run.snapshot().get("status")),"Verified run must finish successfully");
  var blocked=store.start("blocked", "workspace");
  blocked.setPlan(List.of("Review uncertain requirement"));blocked.markPlanStarted();
  blocked.recordPlanToolActivity("read", "Missing requirement");
  blocked.updatePlan(1,"blocked","Genuine missing prerequisite");
  ok(!blocked.allPlanStepsCompleted(),"Blocked step is not successful completion");
  blocked.finish("completed");
  ok("blocked".equals(blocked.snapshot().get("status")),"Blocked plan cannot be finished successfully");
  System.out.println("PASS: pending vs complete, mutation invalidation, final verifier, blocked-step fail-closed");
 }
}
JAVA
javac --release 17 -d "$TMP/classes" $(find "$TMP/src" -name '*.java') \
 src/main/java/com/llmart/llm/service/TokenActivityLedger.java \
 src/main/java/com/llmart/llm/service/AgentRunService.java
java -cp "$TMP/classes" com.llmart.llm.service.CompletionBudgetSmoke
python3 - <<'PY'
from pathlib import Path
s=Path('src/main/java/com/llmart/llm/service/AgentService.java').read_text()
r=Path('src/main/java/com/llmart/llm/service/ContextWindowManager.java').read_text()
t=Path('src/main/java/com/llmart/llm/service/TerminalSessionService.java').read_text()
assert 'if (approvedPlanCompleteAndVerified(run))' in s
assert 'run.allPlanStepsCompleted()' in s
assert 'StepCompletionDecision lastStep = activeStepCompletionGate(' in s
assert 'if (lastStep.satisfied())' in s
assert 'coreToolNames = scopedExecutorTools(coreToolNames, request.message())' in s
assert 'tool -> tool.startsWith("documentation_")' in s
assert 'tool -> tool.startsWith("presentation_")' in s
assert 'tool -> tool.startsWith("confluence_")' in s
assert 'if (s.startsWith("[RUNTIME_STEERING:active-step-contract]"))' in r
assert 'if (s.startsWith("[RUNTIME_STEERING:exploration-budget]"))' in r
assert 'genuineClarificationRequired(text(args, "question"), run)' in s
assert '!agentRuns.require(s.runId).finished()' in t
print('PASS: runtime verified-plan shortcut, bounded final semantic review, scoped schemas, steering and stale-question guards')
PY
python3 - <<'PY'
import csv, subprocess, tempfile
from pathlib import Path
header='task_id,run,agent,model,passed,accuracy,elapsed_ms,input_tokens,output_tokens,total_tokens,cached_input_tokens,unauthorized_writes,notes\n'
data='t1,1,eliya,shared,true,1,200,80,20,100,10,0,\nt1,1,opencode,shared,true,1,250,100,40,140,40,0,\nt1,1,claude,shared,true,1,230,95,25,120,20,0,\n'
with tempfile.TemporaryDirectory() as d:
 p=Path(d)/'benchmark.csv';p.write_text(header+data)
 result=subprocess.run(['python3','qa/comparative/compare.py',str(p)],capture_output=True,text=True,check=True)
 assert 'Eliya vs opencode' in result.stdout and 'Eliya vs claude' in result.stdout
 assert 'Eliya used <= tokens on 1/1 pairs' in result.stdout
 print('PASS: paired OpenCode/Claude provider token benchmark; no fabricated totals')
PY
