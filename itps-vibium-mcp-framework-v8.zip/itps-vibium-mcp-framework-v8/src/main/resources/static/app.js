const $ = id => document.getElementById(id);
let pollHandle;
let browsers = [];
let currentRunId = '';

async function loadBrowsers(){
  try{
    const response = await fetch('/api/browsers');
    if(!response.ok) throw new Error(`HTTP ${response.status}`);
    browsers = await response.json();
    const available = browsers.filter(b => b.detected || b.id === 'vibium-managed-chrome');
    $('browserId').innerHTML = available.map(b => `<option value="${esc(b.id)}">${esc(b.name)}</option>`).join('');
    updateBrowserSelection();
  }catch(error){
    $('browserNote').textContent = `Browser discovery failed: ${error.message}`;
  }
}

function updateBrowserSelection(){
  const selected = browsers.find(b => b.id === $('browserId').value);
  if(!selected) return;
  $('browserName').value = selected.name || '';
  $('browserExecutable').value = selected.executable || '';
  $('browserNote').textContent = selected.executable || selected.note || '';
}

$('browserId').addEventListener('change', updateBrowserSelection);
$('scenarioFile').addEventListener('change', () => {
  const file = $('scenarioFile').files[0];
  $('fileName').textContent = file ? `${file.name} · ${Math.max(1,Math.round(file.size/1024))} KB` : 'No file selected';
});

document.querySelectorAll('[data-artifact]').forEach(button => {
  button.addEventListener('click', () => openArtifact(button.dataset.artifact, button.hasAttribute('data-download')));
});

$('runBtn').addEventListener('click', async () => {
  const file = $('scenarioFile').files[0];
  if(!file){ setStatus('Choose a scenario file.'); return; }
  if(!$('llmApiKey').value.trim()){ setStatus('Enter the LLM token.'); return; }

  const form = new FormData();
  form.append('scenarioFile', file);
  ['llmBaseUrl','llmApiKey','llmModel','appBaseUrl','browserId','browserName','browserExecutable','screenshotMode','stepTimeoutSeconds','retryCount']
    .forEach(id => form.append(id, $(id).value || ''));
  ['useLlm','headless','continueOnFailure','strictEvidence']
    .forEach(id => form.append(id, $(id).checked));

  $('runBtn').disabled = true;
  setArtifactButtons(false);
  setStatus('Starting execution...');
  try{
    const response = await fetch('/api/runs',{method:'POST',body:form});
    const data = await response.json();
    if(!response.ok) throw new Error(data.error || 'Unable to start execution');
    renderRun(data);
    poll(data.runId);
  }catch(error){
    setStatus(error.message);
    $('runBtn').disabled = false;
  }
});

function poll(runId){
  clearInterval(pollHandle);
  pollHandle = setInterval(async () => {
    try{
      const response = await fetch(`/api/runs/${encodeURIComponent(runId)}`,{cache:'no-store'});
      const data = await response.json();
      if(!response.ok) throw new Error(data.error || `HTTP ${response.status}`);
      renderRun(data);
      if(!['QUEUED','RUNNING'].includes(data.status)){
        clearInterval(pollHandle);
        $('runBtn').disabled = false;
        setArtifactButtons(true);
        setStatus('Execution completed.');
      }
    }catch(error){
      clearInterval(pollHandle);
      $('runBtn').disabled = false;
      setStatus(`Unable to read run status: ${error.message}`);
    }
  },1500);
}

function renderRun(run){
  currentRunId = run.runId || currentRunId;
  $('resultPanel').classList.remove('hidden');
  const status = shortStatus(run);
  $('runTitle').textContent = `${run.runId} · ${status}`;
  $('runMessage').textContent = concise(run.message || '');
  $('total').textContent = run.total ?? 0;
  $('passed').textContent = run.passed ?? 0;
  $('failed').textContent = run.failed ?? 0;
  $('status').textContent = status;
  $('scenarioResults').innerHTML = (run.scenarios || []).map(s => {
    const scenarioStatus = String(s.status || '').toUpperCase() === 'PASSED' ? 'PASSED' : 'FAILED';
    return `<tr>
      <td>${esc(s.id)}</td>
      <td>${esc(s.name)}</td>
      <td><span class="pill ${scenarioStatus==='PASSED'?'pass':'fail'}">${scenarioStatus}</span></td>
      <td>${formatDuration(s.durationMs)}</td>
      <td class="err" title="${escAttr(s.errorMessage || '')}">${esc(concise(s.errorMessage || ''))}</td>
    </tr>`;
  }).join('');
}

async function openArtifact(name, download){
  if(!currentRunId){ setStatus('No completed run is available.'); return; }
  const url = `/api/runs/${encodeURIComponent(currentRunId)}/${name}`;
  try{
    if(!download){
      const tab = window.open(url,'_blank','noopener');
      if(!tab) window.location.href = url;
      return;
    }
    setStatus(`Preparing ${name}...`);
    const response = await fetch(url,{cache:'no-store'});
    if(!response.ok){
      let message = `HTTP ${response.status}`;
      try{ const body = await response.json(); message = body.error || message; }catch(ignore){}
      throw new Error(message);
    }
    const blob = await response.blob();
    const objectUrl = URL.createObjectURL(blob);
    const anchor = document.createElement('a');
    anchor.href = objectUrl;
    anchor.download = name;
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
    setTimeout(() => URL.revokeObjectURL(objectUrl),1000);
    setStatus(`${name} downloaded.`);
  }catch(error){
    setStatus(`Unable to open ${name}: ${error.message}`);
  }
}

function setArtifactButtons(enabled){
  document.querySelectorAll('[data-artifact]').forEach(button => button.disabled = !enabled);
}
function shortStatus(run){
  if(['QUEUED','RUNNING'].includes(run.status)) return run.status;
  if((run.failed ?? 0) > 0) return 'FAILED';
  if((run.passed ?? 0) === (run.total ?? -1) && (run.total ?? 0) > 0) return 'PASSED';
  return 'COMPLETED';
}
function concise(value){
  const text = String(value || '').replace(/\s+/g,' ').trim();
  return text.length > 180 ? `${text.slice(0,177)}...` : text;
}
function formatDuration(ms){
  const value = Number(ms || 0);
  if(value < 1000) return `${value} ms`;
  return `${(value/1000).toFixed(1)} s`;
}
function setStatus(text){ $('statusLine').textContent = text; }
function esc(value){ return String(value ?? '').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m])); }
function escAttr(value){ return esc(value).replace(/`/g,'&#96;'); }

setArtifactButtons(false);
loadBrowsers();
