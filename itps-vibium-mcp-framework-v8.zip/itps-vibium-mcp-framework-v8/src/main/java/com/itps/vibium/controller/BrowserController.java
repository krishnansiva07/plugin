package com.itps.vibium.controller;

import com.itps.vibium.service.BrowserDiscoveryService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/browsers")
public class BrowserController {
    private final BrowserDiscoveryService service;
    public BrowserController(BrowserDiscoveryService service) { this.service = service; }
    @GetMapping public Object list() { return service.discover(); }
}
