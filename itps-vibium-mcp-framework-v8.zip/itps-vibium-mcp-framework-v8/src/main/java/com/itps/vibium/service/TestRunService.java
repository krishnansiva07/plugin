package com.itps.vibium.service;

import com.itps.vibium.model.RunConfig;
import com.itps.vibium.model.RunStatus;
import com.itps.vibium.model.TestScenario;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;

@Service
public class TestRunService {
    private final ItpsMcpRunner runner;
    private final RunStore runStore;

    public TestRunService(ItpsMcpRunner runner, RunStore runStore) {
        this.runner = runner;
        this.runStore = runStore;
    }

    public RunStatus start(List<TestScenario> scenarios, RunConfig config) {
        String runId = "RUN-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();
        config.setRunId(runId);
        RunStatus status = new RunStatus();
        status.setRunId(runId);
        status.setStatus("QUEUED");
        status.setTotal(scenarios.size());
        runStore.put(status);
        CompletableFuture.runAsync(() -> {
            runner.execute(scenarios, config, status);
            runStore.put(status);
        });
        return status;
    }
}
