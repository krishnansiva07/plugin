package com.itps.vibium.service;

import com.itps.vibium.model.BrowserOption;
import org.springframework.stereotype.Service;

import java.nio.file.*;
import java.util.*;

@Service
public class BrowserDiscoveryService {
    public List<BrowserOption> discover() {
        List<BrowserOption> out = new ArrayList<>();
        String local = env("LOCALAPPDATA");
        String pf = env("PROGRAMFILES");
        String pf86 = env("PROGRAMFILES(X86)");
        out.add(new BrowserOption("vibium-managed-chrome", "Vibium Managed Chrome for Testing", findVibiumChrome(local), true, true,
                "Recommended. Uses the Chrome for Testing installation managed by Vibium."));
        add(out, "google-chrome", "Google Chrome", candidates(pf+"/Google/Chrome/Application/chrome.exe", pf86+"/Google/Chrome/Application/chrome.exe", local+"/Google/Chrome/Application/chrome.exe"));
        add(out, "microsoft-edge", "Microsoft Edge", candidates(pf86+"/Microsoft/Edge/Application/msedge.exe", pf+"/Microsoft/Edge/Application/msedge.exe", local+"/Microsoft/Edge/Application/msedge.exe"));
        add(out, "chromium", "Chromium", candidates(local+"/Chromium/Application/chrome.exe", pf+"/Chromium/Application/chrome.exe"));
        return out;
    }

    public Optional<BrowserOption> find(String id) { return discover().stream().filter(b -> b.id().equalsIgnoreCase(id)).findFirst(); }

    private void add(List<BrowserOption> out, String id, String name, List<String> candidates) {
        String found = candidates.stream().filter(this::exists).findFirst().orElse("");
        out.add(new BrowserOption(id, name, found, !found.isBlank(), false,
                found.isBlank() ? "Not detected." : "Detected, but usable only if the installed Vibium MCP browser_start schema exposes executablePath/browser/channel. The framework validates this instead of silently falling back."));
    }
    private List<String> candidates(String... values) { return Arrays.stream(values).filter(v -> v != null && !v.startsWith("null/")).toList(); }
    private String findVibiumChrome(String local) {
        if (local == null) return "";
        Path base = Path.of(local, "vibium", "chrome-for-testing");
        if (!Files.isDirectory(base)) return "";
        try (var walk = Files.walk(base, 4)) { return walk.filter(p -> p.getFileName().toString().equalsIgnoreCase("chrome.exe")).findFirst().map(Path::toString).orElse(""); }
        catch (Exception e) { return ""; }
    }
    private boolean exists(String s) { try { return s != null && Files.isRegularFile(Path.of(s)); } catch (Exception e) { return false; } }
    private String env(String key) { return System.getenv(key); }
}
