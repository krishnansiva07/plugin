package com.itps.vibium.model;

public record BrowserOption(String id, String name, String executable, boolean detected, boolean directlySupported, String note) {}
