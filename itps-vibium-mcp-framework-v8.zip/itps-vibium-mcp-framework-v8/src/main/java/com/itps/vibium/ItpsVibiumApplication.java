package com.itps.vibium;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ItpsVibiumApplication {
    public static void main(String[] args) {
        SpringApplication.run(ItpsVibiumApplication.class, args);
    }
}
