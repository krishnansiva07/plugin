const fs = require('fs');
const assert = require('assert');
const html=fs.readFileSync('src/main/resources/static/index.html','utf8');
const app=fs.readFileSync('src/main/resources/static/app.js','utf8');
const chat=fs.readFileSync('src/main/java/com/llmart/llm/controller/ChatController.java','utf8');
const terminal=fs.readFileSync('src/main/java/com/llmart/llm/controller/TerminalController.java','utf8');
assert(html.includes('id="eliyaExecutionEngine"') && html.includes('value="legacy"') && html.includes('value="opencode"') && html.includes('value="auto"'));
assert(app.includes('llm.executionEngineByTab92') && app.includes("'X-ELIYA-Execution-Engine': currentExecutionEngine()"));
assert(chat.includes('"legacy".equals(preference)') && chat.includes('openCodeBridge.availableForAuto()') && chat.includes('chatService.stream(key, request)'));
assert(terminal.includes('"legacy".equalsIgnoreCase(engineChoice)') && terminal.includes('sessions.launch(key, request)'));
assert(html.includes('/app.js?v=95') && html.includes('/app.css?v=95'));
console.log('PASS: per-tab engine selector, Auto/Legacy backend routing, source resource versions');

assert(html.includes('id="terminalExecutionEngine"'));
assert(app.includes('function terminalExecutionChoice()'));
assert(app.includes("'X-ELIYA-Execution-Engine':choice"));
assert(terminal.includes('openCode.availableForAuto()'));
