package com.llmart.llm.service;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.security.MessageDigest;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/** Sparse, bounded, model-scoped local vector cache. Populated only when semantic retrieval is explicitly enabled. */
final class WorkspaceEmbeddingStore {
    private static final int FORMAT = 1, MAX_VECTORS = 1_500, MAX_DIMENSION = 8_192;
    private final Path home;
    private final Map<String, Bucket> buckets = new ConcurrentHashMap<>();

    WorkspaceEmbeddingStore(Path indexHome) { this.home = indexHome.resolve("embeddings"); }

    synchronized double[] get(String scope, String path, String fingerprint) {
        Entry entry = bucket(scope).vectors.get(path);
        return entry == null || !entry.fingerprint.equals(fingerprint) ? null : entry.vector.clone();
    }

    synchronized void putAll(String scope, Map<String, Entry> values) {
        if (values == null || values.isEmpty()) return;
        Bucket bucket = bucket(scope);
        for (var kv : values.entrySet()) {
            Entry entry = kv.getValue();
            if (entry != null && entry.valid()) bucket.vectors.put(kv.getKey(), entry);
        }
        while (bucket.vectors.size() > MAX_VECTORS) bucket.vectors.remove(bucket.vectors.keySet().iterator().next());
        write(bucket);
    }

    synchronized void invalidate(String scope, Collection<String> paths) {
        Bucket bucket = bucket(scope);
        boolean dirty = false;
        for (String path : paths) dirty |= bucket.vectors.remove(path) != null;
        if (dirty) write(bucket);
    }

    synchronized Map<String,Entry> snapshot(String scope) {
        return Map.copyOf(bucket(scope).vectors);
    }

    static Entry entry(String fingerprint, double[] vector) { return new Entry(fingerprint, vector.clone()); }
    static String fingerprint(String sample, long size, long modified) {
        return hex((size + ":" + modified + ":" + sample).getBytes(StandardCharsets.UTF_8));
    }
    static String scope(String root, String endpoint, String model) { return hex((root + "|" + endpoint + "|" + model).getBytes(StandardCharsets.UTF_8)); }
    private Bucket bucket(String scope) { return buckets.computeIfAbsent(scope, this::read); }
    private Path path(String scope) { return home.resolve(scope + ".vec"); }

    private Bucket read(String scope) {
        Bucket bucket = new Bucket(scope);
        if (!Files.isRegularFile(path(scope))) return bucket;
        try (DataInputStream in = new DataInputStream(new BufferedInputStream(Files.newInputStream(path(scope))))) {
            if (in.readInt() != FORMAT) return bucket;
            int count = in.readInt();
            if (count < 0 || count > MAX_VECTORS) return bucket;
            for (int i = 0; i < count; i++) {
                String name = in.readUTF(), fingerprint = in.readUTF();
                int dims = in.readInt();
                if (dims <= 0 || dims > MAX_DIMENSION) return new Bucket(scope);
                double[] vector = new double[dims];
                for (int j = 0; j < dims; j++) vector[j] = in.readDouble();
                Entry entry = new Entry(fingerprint, vector);
                if (entry.valid()) bucket.vectors.put(name, entry);
            }
        } catch (IOException ignored) { return new Bucket(scope); }
        return bucket;
    }

    private void write(Bucket bucket) {
        try {
            Files.createDirectories(home);
            Path target = path(bucket.scope), temp = target.resolveSibling(target.getFileName() + ".tmp");
            try (DataOutputStream out = new DataOutputStream(new BufferedOutputStream(Files.newOutputStream(temp)))) {
                out.writeInt(FORMAT); out.writeInt(bucket.vectors.size());
                for (var entry : bucket.vectors.entrySet()) {
                    out.writeUTF(entry.getKey()); out.writeUTF(entry.getValue().fingerprint);
                    out.writeInt(entry.getValue().vector.length);
                    for (double component : entry.getValue().vector) out.writeDouble(component);
                }
            }
            try { Files.move(temp, target, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (AtomicMoveNotSupportedException unsupported) { Files.move(temp, target, StandardCopyOption.REPLACE_EXISTING); }
        } catch (IOException ignored) { /* Optional acceleration: a failed cache must not block the Agent. */ }
    }

    private static String hex(byte[] input) {
        try { return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(input)); }
        catch (Exception unavailable) { throw new IllegalStateException(unavailable); }
    }
    record Entry(String fingerprint, double[] vector) {
        boolean valid() {
            if (fingerprint == null || fingerprint.length() > 128 || vector == null || vector.length == 0 || vector.length > MAX_DIMENSION) return false;
            for (double value : vector) if (!Double.isFinite(value)) return false;
            return true;
        }
    }
    private static final class Bucket {
        final String scope;
        final LinkedHashMap<String, Entry> vectors = new LinkedHashMap<>();
        Bucket(String scope) { this.scope = scope; }
    }
}
