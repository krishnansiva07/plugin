# ELIYA151 — large workspace, complete migration prompts, live running counter

## Scope

This is an updated **source distribution**, derived from the uploaded `ELIYA150.zip` (which contained the folder named `ELIYA149`). It is NOT a rebuilt or runtime-verified JAR.

### 1. Workspace indexing with 10,000+ files

- Raised default supported-file budget from 40,000 to 100,000 (`-Deliya.index.maxFiles=100000`, configurable up to 200,000) and scanned-entry budget from 150,000 to 300,000 (`-Deliya.index.maxScannedFiles=300000`, configurable up to 500,000).
- When more than 6,000 eligible files are detected, a bounded metadata-only preflight enables **compact indexing**. It preserves the supported-file manifest but reduces per-file cached terms and excerpts; source files remain available through live filesystem tools.
- Compact Java symbol detection uses lightweight syntax matching rather than initializing a full Java compiler task for each file. Targeted source analysis still reads live files.
- Index checkpoints have version 4; oversized legacy checkpoints are rebuilt rather than loaded wholesale.
- Added `WorkspaceRetrievalIndexTenThousandFilesTest` with 10,050 `.feature` files and last-file retrieval assertion.

This is an index scalability change, **not** permission to bypass configured skips, file-size limits, symlink safeguards, model context windows, or excluded directories. Compact caches give less middle-of-file lexical coverage; use `grep`, filename discovery, and targeted live reads to inspect full files.

### 2. Migration prompt stops near 994 lines / cannot send to Agent

- Prompt-generating Chat turns now request a document-completion marker and automatically continue model output until complete or a bounded retry limit is hit, even if a gateway incorrectly signals an ordinary stop before the prompt is complete.
- An incomplete output is clearly marked and blocked from direct Agent handoff, instead of claiming a partial file is executable.
- Generated single-prompt and numbered multi-prompt Markdown extraction removes the internal completion marker while retaining all substantive lines.
- For selected prompts above 72,000 characters, the Agent handoff passes an **exact persisted message offset/length reference** instead of failing with a length error. The Agent must fetch the whole selected range via `conversation_handoff_read` in chunks before modifying files; missing data fails closed.
- The original source message is never truncated for copy or download. The UI preview can be shorter by design but identifies that clearly.

Continuation cannot manufacture requirements or guarantee semantic completeness. For very long prompts, prefer short phase plans with complete requirements saved as files, and use Agent evidence to verify completion.

### 3. Top bar incorrectly says `0 running`

- Added `GET /api/agent/runs/active` for browser Agent runs.
- The top bar now polls active browser Agent runs independently of the Terminal monitor drawer and merges them with Terminal sessions.
- De-duplicates paired Terminal/Agent records by run ID. Clicking a browser Agent entry navigates to its conversation.
- Added a JUnit test for active-to-finished transitions and JavaScript polling contracts.

### 4. Existing test compilation issue

- Fixed three preexisting malformed inline Java text blocks in `OpenCodeConfigImportServiceTest.java` so the test source parses on Java 17.

## Local checks completed in this environment

- Node.js UI regression tests: **134 passed / 0 failed**.
- Java 17 source syntax parser: **173 production Java files; 0 syntax errors**.
- Java 17 test syntax parser: **51 test Java files; 0 syntax errors**.
- Compiled and ran standalone pure-Java smoke checks for prompt completion detection and scoped handoff: **passed**.
- **Not performed:** dependency-resolved Maven compile, JUnit integration suite, actual 10,050-file indexing run, live LLM continuation, browser end-to-end test, packaged JAR or Windows environment check. Maven and dependency downloads were unavailable in the sandbox. These remain mandatory acceptance gates.

## Build and acceptance commands

Requires JDK 17+, Maven with access to required dependencies, and Node.js.

```bash
node --test src/test/js/*.test.js
mvn -B -Pfull-tests -Dmaven.test.skip=false clean verify
java -jar target/eliya.jar
```

On Windows, `build-jar-windows.cmd` packages with `-DskipTests`; **run full tests first** using the command above before deploying. The GitHub Actions workflow `.github/workflows/verify-eliya.yml` can compile and verify the JAR when the repository is pushed.

## Manual end-to-end acceptance

1. Map a workspace containing at least 10,050 eligible code/feature files. Rescan. Verify `indexedFiles` exceeds 10,000 and `scanIncomplete=false`, then ask for evidence from a file at the end of the repository.
2. In Analyse, ask for a complete 1,500+ line Java Selenium → Playwright TypeScript migration prompt. Confirm continuation completes or shows a clear incomplete error. Copy/download and compare the full source; select the complete prompt to send to Agent.
3. Start an Agent run from the browser without opening the Terminal monitor. Check top bar shows `1 running`, open the run details, then verify it returns to 0 after completion. Repeat with concurrent Terminal and browser runs.
4. For prompts above 72,000 characters, verify Agent retrieves exact referenced message range in chunks and refuses to execute incomplete or edited scope.

## Runtime tuning

Suggested defaults for repositories above 10,000 eligible files:

```text
-Deliya.index.maxFiles=100000
-Deliya.index.maxScannedFiles=300000
-Deliya.index.compactThreshold=6000
-Deliya.index.compactTerms=128
-Deliya.index.compactExcerptChars=2400
-Deliya.chat.autoContinue.enabled=true
-Deliya.chat.autoContinue.maxParts=8
```

Do not lower `compactThreshold` expecting higher semantic quality; it trades some cached term coverage for reduced memory. Existing tool and provider limits still apply.
