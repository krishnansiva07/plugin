import { test } from '@playwright/test';
import { LoginPage } from '../src/pages/LoginPage';
import { readJsonFile } from '../src/utils/JsonData';

interface LoginTestData {
  run: boolean;
  testId: string;
  testName: string;
  suite?: string;
  tags?: string[];
  username: string;
  password: string;
  expectedType: 'products' | 'error';
  expectedValue: string;
}

const testData = readJsonFile<LoginTestData[]>('test-data/login-tests.json').filter(row => row.run);
const suites = new Map<string, LoginTestData[]>();

for (const row of testData) {
  const suite = row.suite?.trim() || 'SauceDemo Login';
  const rows = suites.get(suite) ?? [];
  rows.push(row);
  suites.set(suite, rows);
}

for (const [suiteName, rows] of suites) {
  test.describe(suiteName, () => {
    for (const row of rows) {
      const normalizedTags = (row.tags ?? []).map(tag => tag.startsWith('@') ? tag : `@${tag}`);
      const tagText = normalizedTags.join(' ');
      const title = `[${row.testId}] ${row.testName}${tagText ? ` ${tagText}` : ''}`;

      test(title, async ({ page }, testInfo) => {
        testInfo.annotations.push({ type: 'testId', description: row.testId });
        testInfo.annotations.push({ type: 'suite', description: suiteName });
        for (const tag of normalizedTags) {
          testInfo.annotations.push({ type: 'tag', description: tag });
        }

        const loginPage = new LoginPage(page);
        await loginPage.open();
        await loginPage.login(row.username, row.password);
        if (row.expectedType === 'products') {
          await loginPage.verifyProductsPage(row.expectedValue);
        } else {
          await loginPage.verifyError(row.expectedValue);
        }
      });
    }
  });
}
