import { existsSync, readFileSync, readdirSync } from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';

const root = path.resolve(__dirname, '..');
const certificateDir = path.join(root, 'certificates');
const preferredCertificateNames = [
  'cacert', 'cacert.pem', 'cacerts', 'corporate-ca.pem', 'corporate-ca.crt', 'corporate-ca.cer'
];

function resolveCertificate(): string | undefined {
  for (const name of preferredCertificateNames) {
    const candidate = path.join(certificateDir, name);
    if (existsSync(candidate)) return candidate;
  }

  if (!existsSync(certificateDir)) return undefined;
  const discovered = readdirSync(certificateDir)
    .filter(name => /\.(pem|crt|cer)$/i.test(name))
    .sort((a, b) => a.localeCompare(b));
  return discovered.length ? path.join(certificateDir, discovered[0]) : undefined;
}

function escapeRegex(value: string): string {
  return value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

function readOption(args: string[], names: string[], npmConfigName?: string): string | undefined {
  for (let index = 0; index < args.length; index += 1) {
    const current = args[index];
    for (const name of names) {
      if (current === `--${name}` && args[index + 1]) return args[index + 1];
      if (current.startsWith(`--${name}=`)) return current.slice(name.length + 3);
    }
  }
  return npmConfigName ? process.env[`npm_config_${npmConfigName}`] : undefined;
}

function removeFrameworkOptions(args: string[]): string[] {
  const supported = new Set([
    'testid', 'test-id', 'tag', 'tags', 'testname', 'test-name', 'suite', 'suite-name'
  ]);
  const result: string[] = [];
  for (let index = 0; index < args.length; index += 1) {
    const current = args[index];
    if (!current.startsWith('--')) {
      result.push(current);
      continue;
    }
    const optionName = current.slice(2).split('=')[0];
    if (!supported.has(optionName)) {
      result.push(current);
      continue;
    }
    if (!current.includes('=') && args[index + 1] && !args[index + 1].startsWith('--')) index += 1;
  }
  return result;
}

function splitValues(value?: string): string[] {
  return (value ?? '').split(',').map(item => item.trim()).filter(Boolean);
}

function buildGrep(args: string[]): string | undefined {
  const testIds = splitValues(readOption(args, ['testid', 'test-id'], 'testid'));
  const tags = splitValues(readOption(args, ['tag', 'tags'], 'tag')).map(tag => tag.startsWith('@') ? tag : `@${tag}`);
  const testNames = splitValues(readOption(args, ['testname', 'test-name'], 'testname'));
  const suites = splitValues(readOption(args, ['suite', 'suite-name'], 'suite'));

  const groups = [testIds, tags, testNames, suites].filter(group => group.length > 0);
  if (!groups.length) return undefined;

  return groups
    .map(group => `(?=.*(?:${group.map(escapeRegex).join('|')}))`)
    .join('') + '.*';
}

const certificate = resolveCertificate();
const mode = process.argv[2] ?? 'test';
const incomingArgs = process.argv.slice(3);
const env = { ...process.env };

if (certificate) {
  const content = readFileSync(certificate, 'utf8');
  if (!content.includes('-----BEGIN CERTIFICATE-----')) {
    console.error(`[CERTIFICATE] ${certificate} is not PEM text. It must contain -----BEGIN CERTIFICATE-----.`);
    process.exit(2);
  }
  env.NODE_EXTRA_CA_CERTS = certificate;
  console.log(`[CERTIFICATE] Using corporate CA: ${certificate}`);
} else {
  console.log('[CERTIFICATE] No PEM/CRT/CER file found in certificates/. Continuing with the default Node trust store.');
}

const playwrightCli = path.join(root, 'node_modules', '@playwright', 'test', 'cli.js');
const preflight = path.join(root, 'scripts', 'preflight.ts');
let command: string;
let args: string[];

if (mode === 'preflight') {
  command = process.execPath;
  args = [path.join(root, 'node_modules', 'tsx', 'dist', 'cli.mjs'), preflight];
} else {
  command = process.execPath;
  args = [playwrightCli, 'test'];
  if (mode === 'debug') args.push('--debug');

  const grep = buildGrep(incomingArgs);
  if (grep) {
    args.push('--grep', grep);
    console.log(`[FILTER] ${grep}`);
  }
  args.push(...removeFrameworkOptions(incomingArgs));
}

const result = spawnSync(command, args, { cwd: root, env, stdio: 'inherit', windowsHide: false });
if (result.error) {
  console.error(result.error);
  process.exit(1);
}
process.exit(result.status ?? 1);
