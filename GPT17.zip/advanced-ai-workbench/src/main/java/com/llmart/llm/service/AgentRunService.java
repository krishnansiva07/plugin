package com.llmart.llm.service;

import org.springframework.stereotype.Service;

import java.time.Instant;
import java.nio.file.*;
import java.io.*;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Consumer;

@Service
public class AgentRunService {
    private static final int MAX_RETAINED_RUNS = 100;
    private final Map<String, AgentRun> runs = new ConcurrentHashMap<>();
    private final Path storeDir;

    public AgentRunService() {
        this(Path.of(System.getProperty("advanced.ai.agentRunStore", "./data/agent-runs")));
    }

    AgentRunService(Path storeDir) {
        this.storeDir = storeDir.toAbsolutePath().normalize();
        try { Files.createDirectories(this.storeDir); } catch (Exception ignored) { }
        loadPersistedRuns();
    }

    public AgentRun start(String conversationId, String projectId) {
        prune();
        AgentRun run = new AgentRun(UUID.randomUUID().toString(), conversationId, projectId, Instant.now(), this::persistQuietly);
        runs.put(run.id(), run);
        persistQuietly(run);
        return run;
    }

    public AgentRun require(String id) {
        AgentRun run = runs.get(id);
        if (run == null) throw new NoSuchElementException("Agent run not found");
        return run;
    }

    public boolean cancel(String id) {
        AgentRun run = runs.get(id);
        return run != null && run.cancel();
    }

    public Map<String, Object> status(String id) {
        return require(id).snapshot();
    }

    private void prune() {
        if (runs.size() < MAX_RETAINED_RUNS) return;
        runs.values().stream()
                .filter(AgentRun::finished)
                .sorted(Comparator.comparing(AgentRun::createdAt))
                .limit(Math.max(1, runs.size() - MAX_RETAINED_RUNS + 20L))
                .map(AgentRun::id)
                .toList()
                .forEach(id -> { runs.remove(id); try { Files.deleteIfExists(storeDir.resolve(id + ".properties")); } catch (Exception ignored) { } });
    }

    private void persistQuietly(AgentRun run) {
        if (run == null) return;
        try {
            Files.createDirectories(storeDir);
            Properties p = run.toProperties();
            Path tmp = storeDir.resolve(run.id() + ".properties.tmp");
            Path target = storeDir.resolve(run.id() + ".properties");
            try (OutputStream out = Files.newOutputStream(tmp, StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING)) {
                p.store(out, "Advanced AI Workbench agent run");
            }
            try { Files.move(tmp, target, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (AtomicMoveNotSupportedException e) { Files.move(tmp, target, StandardCopyOption.REPLACE_EXISTING); }
        } catch (Exception ignored) { }
    }

    private void loadPersistedRuns() {
        if (!Files.isDirectory(storeDir)) return;
        try (var stream = Files.list(storeDir)) {
            stream.filter(p -> p.getFileName().toString().endsWith(".properties")).sorted().forEach(path -> {
                try (InputStream in = Files.newInputStream(path)) {
                    Properties props = new Properties(); props.load(in);
                    AgentRun run = AgentRun.fromProperties(props, this::persistQuietly);
                    if (run != null) {
                        // A JVM restart cannot safely resume an in-flight tool call. Preserve the run and mark it
                        // interrupted so the UI/user can see exactly where it stopped instead of losing the state.
                        if (!run.finished() && "running".equals(run.status)) {
                            run.markInterruptedByRestart();
                        } else if (!run.finished()) {
                            // A persisted non-running state (for example cancelled/failed) is terminal after restart.
                            run.finishedAt = Instant.now();
                            run.persist();
                        }
                        runs.put(run.id(), run);
                    }
                } catch (Exception ignored) { }
            });
        } catch (Exception ignored) { }
        prune();
    }

    public static final class AgentRun {
        private final String id;
        private final String conversationId;
        private final String projectId;
        private final Instant createdAt;
        private final AtomicBoolean cancelled = new AtomicBoolean(false);
        private final AtomicReference<Process> activeProcess = new AtomicReference<>();
        private final AtomicLong mutationRevision = new AtomicLong(0);
        private final AtomicLong lastVerificationAttemptRevision = new AtomicLong(-1);
        private final AtomicLong verificationRequiredRevision = new AtomicLong(-1);
        private final AtomicLong lastSuccessfulVerificationRevision = new AtomicLong(-1);
        private final AtomicLong lastDiffRevision = new AtomicLong(-1);
        private final AtomicBoolean lastVerificationSuccessful = new AtomicBoolean(false);
        private final AtomicLong modelCalls = new AtomicLong(0);
        private final AtomicLong providerInputTokens = new AtomicLong(0);
        private final AtomicLong providerOutputTokens = new AtomicLong(0);
        private final AtomicLong providerTotalTokens = new AtomicLong(0);
        private final AtomicLong cachedInputTokens = new AtomicLong(0);
        private final AtomicLong cacheWriteTokens = new AtomicLong(0);
        private final AtomicLong estimatedInputTokens = new AtomicLong(0);
        private final AtomicLong currentContextTokens = new AtomicLong(0);
        private final AtomicLong contextWindowTokens = new AtomicLong(0);
        private final AtomicLong compactions = new AtomicLong(0);
        private final AtomicLong estimatedTokensSavedByCompaction = new AtomicLong(0);
        private final AtomicLong repeatedCallsPrevented = new AtomicLong(0);
        private final AtomicLong progressPercent = new AtomicLong(2);
        private final AtomicBoolean responsePersisted = new AtomicBoolean(false);
        private volatile String progressPhase = "starting";
        private volatile String progressDetail = "Preparing agent run";
        private volatile String finalAnswer = "";
        private volatile String assistantMessageId = "";
        private volatile String lastCheckpointReason = "";
        private volatile String loopBlockReason = "";
        private final List<PlanItem> plan = new ArrayList<>();
        private final Set<String> approvedToolsForRun = ConcurrentHashMap.newKeySet();
        private volatile String status = "running";
        private volatile String lastVerification = "";
        private volatile Instant finishedAt;
        private final Consumer<AgentRun> persistHook;

        private AgentRun(String id, String conversationId, String projectId, Instant createdAt, Consumer<AgentRun> persistHook) {
            this.id = id;
            this.conversationId = conversationId;
            this.projectId = projectId;
            this.createdAt = createdAt;
            this.persistHook = persistHook == null ? ignored -> { } : persistHook;
        }

        private void persist() { persistHook.accept(this); }

        public String id() { return id; }
        public String conversationId() { return conversationId; }
        public String projectId() { return projectId; }
        public Instant createdAt() { return createdAt; }
        public boolean cancelled() { return cancelled.get(); }
        public boolean finished() { return finishedAt != null; }
        public long mutationRevision() { return mutationRevision.get(); }
        public long lastVerificationAttemptRevision() { return lastVerificationAttemptRevision.get(); }
        public long verificationRequiredRevision() { return verificationRequiredRevision.get(); }
        public long lastSuccessfulVerificationRevision() { return lastSuccessfulVerificationRevision.get(); }
        public long lastDiffRevision() { return lastDiffRevision.get(); }
        public String lastVerification() { return lastVerification; }
        public boolean lastVerificationSuccessful() { return lastVerificationSuccessful.get(); }
        public long modelCalls() { return modelCalls.get(); }
        public long providerInputTokens() { return providerInputTokens.get(); }
        public long providerOutputTokens() { return providerOutputTokens.get(); }
        public long providerTotalTokens() { return providerTotalTokens.get(); }
        public long cachedInputTokens() { return cachedInputTokens.get(); }
        public long compactions() { return compactions.get(); }
        public long currentContextTokens() { return currentContextTokens.get(); }
        public long contextWindowTokens() { return contextWindowTokens.get(); }
        public int progressPercent() { return (int) progressPercent.get(); }
        public String progressPhase() { return progressPhase == null ? "" : progressPhase; }
        public String progressDetail() { return progressDetail == null ? "" : progressDetail; }
        public boolean responsePersisted() { return responsePersisted.get(); }
        public String finalAnswer() { return finalAnswer == null ? "" : finalAnswer; }
        public String assistantMessageId() { return assistantMessageId == null ? "" : assistantMessageId; }
        public boolean loopBlocked() { return loopBlockReason != null && !loopBlockReason.isBlank(); }
        public String loopBlockReason() { return loopBlockReason == null ? "" : loopBlockReason; }
        public void markLoopBlocked(String reason) { loopBlockReason = reason == null ? "Repeated no-progress loop" : reason; persist(); }
        public boolean isToolApprovedForRun(String tool) { return tool != null && approvedToolsForRun.contains(tool); }
        public void approveToolForRun(String tool) { if (tool != null && !tool.isBlank()) { approvedToolsForRun.add(tool); persist(); } }

        public void checkCancelled() {
            if (cancelled()) throw new AgentCancelledException("Agent run was cancelled");
        }

        public boolean cancel() {
            if (finished()) return false;
            if (!cancelled.compareAndSet(false, true)) return false;
            status = "cancelled";
            terminate(activeProcess.get());
            persist();
            return true;
        }

        public void registerProcess(Process process) {
            checkCancelled();
            activeProcess.set(process);
            if (cancelled()) terminate(process);
        }

        public void unregisterProcess(Process process) {
            activeProcess.compareAndSet(process, null);
        }

        public long markMutation() {
            return markMutation(true);
        }

        public long markMutation(boolean verificationRequired) {
            long revision = mutationRevision.incrementAndGet();
            if (verificationRequired) verificationRequiredRevision.set(revision);
            persist();
            return revision;
        }

        public void recordContextEstimate(long currentTokens, long windowTokens) {
            currentContextTokens.set(Math.max(0, currentTokens));
            contextWindowTokens.set(Math.max(0, windowTokens));
            persist();
        }

        public void recordModelUsage(OpenAiCompatibleClient.Usage usage, long estimatedInputForCall) {
            modelCalls.incrementAndGet();
            estimatedInputTokens.addAndGet(Math.max(0, estimatedInputForCall));
            if (usage == null) { persist(); return; }
            providerInputTokens.addAndGet(Math.max(0, usage.inputTokens()));
            providerOutputTokens.addAndGet(Math.max(0, usage.outputTokens()));
            providerTotalTokens.addAndGet(Math.max(0, usage.totalTokens()));
            cachedInputTokens.addAndGet(Math.max(0, usage.cachedInputTokens()));
            cacheWriteTokens.addAndGet(Math.max(0, usage.cacheWriteTokens()));
            persist();
        }

        public void recordCompaction(long estimatedTokensSaved, String reason) {
            compactions.incrementAndGet();
            estimatedTokensSavedByCompaction.addAndGet(Math.max(0, estimatedTokensSaved));
            lastCheckpointReason = reason == null ? "" : reason;
            persist();
        }

        public void markRepeatedCallPrevented() { repeatedCallsPrevented.incrementAndGet(); persist(); }

        /** Monotonic best-effort task progress. This is phase progress, not a fake ETA. */
        public void updateProgress(int percent, String phase, String detail) {
            int bounded = Math.max(0, Math.min(99, percent));
            long before = progressPercent.getAndAccumulate(bounded, Math::max);
            // Ignore stale lower-phase updates so the percentage and phase never appear to move backwards.
            if (bounded >= before) {
                if (phase != null && !phase.isBlank()) progressPhase = phase.strip();
                if (detail != null && !detail.isBlank()) progressDetail = detail.strip();
            }
            persist();
        }

        public void markFinalAnswer(String answer) {
            finalAnswer = answer == null ? "" : answer;
            updateProgress(97, "finalizing", "Preparing final response");
        }

        public void markResponsePersisted(String messageId, String answer) {
            if (answer != null && !answer.isBlank()) finalAnswer = answer;
            assistantMessageId = messageId == null ? "" : messageId;
            responsePersisted.set(true);
            progressPercent.set(100);
            if ("completed".equals(status)) {
                progressPhase = "completed";
                progressDetail = "Task completed";
            } else {
                progressPhase = status;
                if (progressDetail == null || progressDetail.isBlank() || "Persisting final response".equals(progressDetail)) {
                    progressDetail = "blocked".equals(status) ? "Task blocked" : "Task " + status;
                }
            }
            persist();
        }

        public void markVerificationAttempt(boolean successful, String summary) {
            long rev = mutationRevision.get();
            lastVerificationAttemptRevision.set(rev);
            if (successful) lastSuccessfulVerificationRevision.set(rev);
            lastVerificationSuccessful.set(successful);
            lastVerification = summary == null ? "" : summary;
            persist();
        }

        public boolean verifiedCurrentRevision() {
            long required = verificationRequiredRevision.get();
            if (required < 0) return true;
            if (lastVerificationAttemptRevision.get() >= required && !lastVerificationSuccessful.get()) return false;
            return lastSuccessfulVerificationRevision.get() >= required;
        }

        public boolean verificationRequired() {
            return !verifiedCurrentRevision();
        }

        public void markDiffReview() {
            lastDiffRevision.set(mutationRevision.get());
            persist();
        }

        public boolean diffReviewedCurrentRevision() {
            return lastDiffRevision.get() >= mutationRevision.get();
        }

        public synchronized void setPlan(List<String> items) {
            plan.clear();
            int i = 1;
            for (String item : items == null ? List.<String>of() : items) {
                if (item == null || item.isBlank()) continue;
                plan.add(new PlanItem(i++, item.strip(), "pending", ""));
            }
            recalculatePlanProgress();
            persist();
        }

        public synchronized void updatePlan(int index, String newStatus, String note) {
            if (index < 1 || index > plan.size()) throw new IllegalArgumentException("Plan index is out of range");
            String status = normalizePlanStatus(newStatus);
            PlanItem old = plan.get(index - 1);
            plan.set(index - 1, new PlanItem(old.index(), old.text(), status, note == null ? "" : note.strip()));
            recalculatePlanProgress();
            persist();
        }

        public synchronized String planText() {
            if (plan.isEmpty()) return "[No plan set]";
            StringBuilder out = new StringBuilder();
            for (PlanItem item : plan) {
                out.append(item.index()).append(". [").append(item.status()).append("] ").append(item.text());
                if (!item.note().isBlank()) out.append(" — ").append(item.note());
                out.append('\n');
            }
            return out.toString().stripTrailing();
        }

        public synchronized boolean hasPlan() { return !plan.isEmpty(); }

        public synchronized boolean hasOpenPlanItems() {
            return plan.stream().anyMatch(item -> "pending".equals(item.status()) || "in_progress".equals(item.status()));
        }

        public void finish(String finalStatus) {
            if (!"cancelled".equals(status)) status = finalStatus == null || finalStatus.isBlank() ? "completed" : finalStatus;
            if ("completed".equals(status)) {
                progressPercent.accumulateAndGet(98, Math::max);
                progressPhase = "finalizing";
                progressDetail = "Persisting final response";
            } else if ("blocked".equals(status)) {
                progressPercent.set(100);
                progressPhase = "blocked";
                progressDetail = loopBlocked() ? loopBlockReason() : "Task blocked";
            } else if ("cancelled".equals(status)) {
                progressPercent.set(100);
                progressPhase = "cancelled";
                progressDetail = "Task cancelled";
            } else if ("failed".equals(status)) {
                progressPercent.set(100);
                progressPhase = "failed";
                progressDetail = "Task failed";
            }
            finishedAt = Instant.now();
            terminate(activeProcess.getAndSet(null));
            persist();
        }

        private synchronized void recalculatePlanProgress() {
            if (plan.isEmpty()) return;
            double done = 0.0;
            for (PlanItem item : plan) {
                done += switch (item.status()) { case "completed", "skipped" -> 1.0; case "in_progress" -> 0.5; default -> 0.0; };
            }
            int taskPercent = 12 + (int)Math.round((done / plan.size()) * 76.0);
            progressPercent.accumulateAndGet(Math.min(88, taskPercent), Math::max);
            progressPhase = hasOpenPlanItems() ? "working" : "tasks_complete";
            progressDetail = Math.round(done * 2) / 2.0 + "/" + plan.size() + " task units complete";
        }

        private void markInterruptedByRestart() {
            status = "interrupted";
            progressPercent.set(100);
            progressPhase = "interrupted";
            progressDetail = "Agent run was interrupted by application restart";
            if (finalAnswer == null || finalAnswer.isBlank()) finalAnswer = "Agent run was interrupted by application restart before completion.";
            finishedAt = Instant.now();
            persist();
        }

        private Properties toProperties() {
            Properties p = new Properties();
            p.setProperty("id", id);
            p.setProperty("conversationId", conversationId == null ? "" : conversationId);
            p.setProperty("projectId", projectId == null ? "" : projectId);
            p.setProperty("createdAt", createdAt.toString());
            p.setProperty("status", status == null ? "running" : status);
            p.setProperty("cancelled", Boolean.toString(cancelled()));
            p.setProperty("mutationRevision", Long.toString(mutationRevision()));
            p.setProperty("verificationRequiredRevision", Long.toString(verificationRequiredRevision()));
            p.setProperty("lastVerificationAttemptRevision", Long.toString(lastVerificationAttemptRevision()));
            p.setProperty("lastSuccessfulVerificationRevision", Long.toString(lastSuccessfulVerificationRevision()));
            p.setProperty("lastDiffRevision", Long.toString(lastDiffRevision()));
            p.setProperty("lastVerificationSuccessful", Boolean.toString(lastVerificationSuccessful()));
            p.setProperty("lastVerification", lastVerification == null ? "" : lastVerification);
            p.setProperty("progressPercent", Integer.toString(progressPercent()));
            p.setProperty("progressPhase", progressPhase());
            p.setProperty("progressDetail", progressDetail());
            p.setProperty("responsePersisted", Boolean.toString(responsePersisted()));
            p.setProperty("finalAnswer", finalAnswer());
            p.setProperty("assistantMessageId", assistantMessageId());
            p.setProperty("modelCalls", Long.toString(modelCalls.get()));
            p.setProperty("providerInputTokens", Long.toString(providerInputTokens.get()));
            p.setProperty("providerOutputTokens", Long.toString(providerOutputTokens.get()));
            p.setProperty("providerTotalTokens", Long.toString(providerTotalTokens.get()));
            p.setProperty("cachedInputTokens", Long.toString(cachedInputTokens.get()));
            p.setProperty("cacheWriteTokens", Long.toString(cacheWriteTokens.get()));
            p.setProperty("estimatedInputTokens", Long.toString(estimatedInputTokens.get()));
            p.setProperty("currentContextTokens", Long.toString(currentContextTokens.get()));
            p.setProperty("contextWindowTokens", Long.toString(contextWindowTokens.get()));
            p.setProperty("compactions", Long.toString(compactions.get()));
            p.setProperty("estimatedTokensSavedByCompaction", Long.toString(estimatedTokensSavedByCompaction.get()));
            p.setProperty("repeatedCallsPrevented", Long.toString(repeatedCallsPrevented.get()));
            p.setProperty("lastCheckpointReason", lastCheckpointReason == null ? "" : lastCheckpointReason);
            p.setProperty("loopBlockReason", loopBlockReason == null ? "" : loopBlockReason);
            if (finishedAt != null) p.setProperty("finishedAt", finishedAt.toString());
            return p;
        }

        private static AgentRun fromProperties(Properties p, Consumer<AgentRun> persistHook) {
            String id = p.getProperty("id", "").trim();
            if (id.isBlank()) return null;
            Instant created; try { created = Instant.parse(p.getProperty("createdAt")); } catch (Exception e) { created = Instant.now(); }
            AgentRun run = new AgentRun(id, emptyToNull(p.getProperty("conversationId")), emptyToNull(p.getProperty("projectId")), created, persistHook);
            run.status = p.getProperty("status", "running");
            run.cancelled.set(Boolean.parseBoolean(p.getProperty("cancelled", "false")));
            setLong(run.mutationRevision, p, "mutationRevision", 0);
            setLong(run.verificationRequiredRevision, p, "verificationRequiredRevision", -1);
            setLong(run.lastVerificationAttemptRevision, p, "lastVerificationAttemptRevision", -1);
            setLong(run.lastSuccessfulVerificationRevision, p, "lastSuccessfulVerificationRevision", -1);
            setLong(run.lastDiffRevision, p, "lastDiffRevision", -1);
            run.lastVerificationSuccessful.set(Boolean.parseBoolean(p.getProperty("lastVerificationSuccessful", "false")));
            run.lastVerification = p.getProperty("lastVerification", "");
            setLong(run.progressPercent, p, "progressPercent", 2);
            run.progressPhase = p.getProperty("progressPhase", "starting");
            run.progressDetail = p.getProperty("progressDetail", "Preparing agent run");
            run.responsePersisted.set(Boolean.parseBoolean(p.getProperty("responsePersisted", "false")));
            run.finalAnswer = p.getProperty("finalAnswer", "");
            run.assistantMessageId = p.getProperty("assistantMessageId", "");
            setLong(run.modelCalls, p, "modelCalls", 0); setLong(run.providerInputTokens, p, "providerInputTokens", 0);
            setLong(run.providerOutputTokens, p, "providerOutputTokens", 0); setLong(run.providerTotalTokens, p, "providerTotalTokens", 0);
            setLong(run.cachedInputTokens, p, "cachedInputTokens", 0); setLong(run.cacheWriteTokens, p, "cacheWriteTokens", 0);
            setLong(run.estimatedInputTokens, p, "estimatedInputTokens", 0); setLong(run.currentContextTokens, p, "currentContextTokens", 0);
            setLong(run.contextWindowTokens, p, "contextWindowTokens", 0); setLong(run.compactions, p, "compactions", 0);
            setLong(run.estimatedTokensSavedByCompaction, p, "estimatedTokensSavedByCompaction", 0); setLong(run.repeatedCallsPrevented, p, "repeatedCallsPrevented", 0);
            run.lastCheckpointReason = p.getProperty("lastCheckpointReason", "");
            run.loopBlockReason = p.getProperty("loopBlockReason", "");
            String finished = p.getProperty("finishedAt", "");
            if (!finished.isBlank()) try { run.finishedAt = Instant.parse(finished); } catch (Exception ignored) { }
            return run;
        }

        private static void setLong(AtomicLong target, Properties p, String key, long fallback) {
            try { target.set(Long.parseLong(p.getProperty(key, Long.toString(fallback)))); } catch (Exception e) { target.set(fallback); }
        }
        private static String emptyToNull(String value) { return value == null || value.isBlank() ? null : value; }

        public Map<String, Object> snapshot() {
            Map<String, Object> map = new LinkedHashMap<>();
            map.put("id", id);
            map.put("conversationId", conversationId == null ? "" : conversationId);
            map.put("projectId", projectId == null ? "" : projectId);
            map.put("status", status);
            map.put("cancelled", cancelled());
            map.put("createdAt", createdAt.toString());
            if (finishedAt != null) map.put("finishedAt", finishedAt.toString());
            map.put("mutationRevision", mutationRevision());
            map.put("lastVerificationAttemptRevision", lastVerificationAttemptRevision());
            map.put("verificationRequiredRevision", verificationRequiredRevision());
            map.put("lastSuccessfulVerificationRevision", lastSuccessfulVerificationRevision());
            map.put("lastDiffRevision", lastDiffRevision());
            map.put("lastVerification", lastVerification);
            map.put("lastVerificationSuccessful", lastVerificationSuccessful());
            map.put("progressPercent", progressPercent());
            map.put("progressPhase", progressPhase());
            map.put("progressDetail", progressDetail());
            map.put("responsePersisted", responsePersisted());
            if (finished() && !finalAnswer().isBlank()) map.put("finalAnswer", finalAnswer());
            if (!assistantMessageId().isBlank()) map.put("assistantMessageId", assistantMessageId());
            Map<String,Object> usage = new LinkedHashMap<>();
            usage.put("modelCalls", modelCalls.get());
            usage.put("providerInputTokens", providerInputTokens.get());
            usage.put("providerOutputTokens", providerOutputTokens.get());
            usage.put("providerTotalTokens", providerTotalTokens.get());
            usage.put("cachedInputTokens", cachedInputTokens.get());
            usage.put("cacheWriteTokens", cacheWriteTokens.get());
            usage.put("estimatedInputTokens", estimatedInputTokens.get());
            usage.put("currentContextTokens", currentContextTokens.get());
            usage.put("contextWindowTokens", contextWindowTokens.get());
            usage.put("compactions", compactions.get());
            usage.put("estimatedTokensSavedByCompaction", estimatedTokensSavedByCompaction.get());
            usage.put("repeatedCallsPrevented", repeatedCallsPrevented.get());
            usage.put("lastCheckpointReason", lastCheckpointReason);
            usage.put("loopBlockReason", loopBlockReason);
            map.put("tokenUsage", usage);
            map.put("approvedToolsForRun", List.copyOf(approvedToolsForRun));
            synchronized (this) {
                map.put("plan", List.copyOf(plan));
            }
            return map;
        }

        private static String normalizePlanStatus(String value) {
            String status = value == null ? "pending" : value.trim().toLowerCase(Locale.ROOT);
            return switch (status) {
                case "pending", "in_progress", "completed", "blocked", "skipped" -> status;
                default -> throw new IllegalArgumentException("Unsupported plan status: " + value);
            };
        }

        private static void terminate(Process process) {
            if (process == null || !process.isAlive()) return;
            try {
                process.descendants().forEach(handle -> {
                    try { handle.destroy(); } catch (Exception ignored) { }
                });
                process.destroy();
                if (process.isAlive()) {
                    process.descendants().forEach(handle -> {
                        try { handle.destroyForcibly(); } catch (Exception ignored) { }
                    });
                    process.destroyForcibly();
                }
            } catch (Exception ignored) { }
        }
    }

    public record PlanItem(int index, String text, String status, String note) {}
}
