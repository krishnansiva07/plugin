# Validation Report

## Scope

Final validation focused on the agent execution loop, token/context management, prompt-driven workspace resolution, durable completion handling, progress reporting, and the simplified Chat/Agent interface.

## Passed checks

- JavaScript syntax: `app.js` and `markdown.js` pass `node --check`.
- Shell syntax: `run.sh` and `validate-local.sh` pass `bash -n`.
- Maven project descriptor parses as valid XML.
- UI exposes exactly two modes: **Chat** and **Agent**.
- Analyze mode, Open workspace UI, and starter shortcuts such as Fix an issue / Review code / Work with files / Build a feature are absent from the interface.
- Agent progress UI is present and driven by durable backend run state.
- Agent terminal answer is persisted before the browser is expected to receive the final SSE event.
- The browser watchdog can recover a persisted terminal answer and close a stale stream instead of leaving the Stop button active indefinitely.
- Legacy numbered application-version labels and obsolete release-note/config files are absent from the packaged source/documentation surface.
- Core Java harness passes for monotonic progress, mutation/verification state, durable response persistence, token accounting, proactive context compaction, and checkpoint preservation of user constraints.
- Context harness result: active estimated context reduced from **13,656** to **3,659** tokens after compaction while retaining old constraints needed for continuation.
- Prompt-resource Java harness passes: an explicit primary project path becomes the writable workspace while explicit reference projects and input files remain read-only resources.
- Full Java source was parsed by `javac --release 17 -proc:none`; no Java syntax/language-structure errors were detected. Compilation cannot finish in the validation container because Spring/Jackson dependencies are not locally available.

## Maven-suite environment limitation

A full Maven test run was attempted with `./mvnw test`. Maven is not installed in the validation container, so the wrapper attempted to bootstrap Maven. The container cannot resolve `repo.maven.apache.org`, therefore dependency-backed Maven tests cannot run here. This is an environment/network limitation, not a reported passing test.

Run the included `validate-local.bat` (Windows) or `validate-local.sh` (Linux/macOS) in an environment with Maven or Maven Central access for the complete dependency-backed Maven test/package validation.

## Final behavior targeted

The agent can continue productive work without an application step ceiling, while proactive compaction, bounded tool history, no-progress detection, verification-aware completion, finite provider retries/timeouts, and durable terminal-state recovery prevent the runaway token/retry and post-completion waiting patterns observed during earlier testing.
