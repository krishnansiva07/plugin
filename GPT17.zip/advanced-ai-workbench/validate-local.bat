@echo off
setlocal
cd /d "%~dp0"

echo [1/5] Java
java -version || exit /b 1

echo [2/5] Frontend syntax
where node >nul 2>nul
if not errorlevel 1 (
  node --check src\main\resources\static\app.js || exit /b 1
  node --check src\main\resources\static\markdown.js || exit /b 1
) else (
  echo Node is not installed; skipping JavaScript syntax checks.
)

echo [3/5] Maven availability/bootstrap
call mvnw.cmd -version || exit /b 1

echo [4/5] Maven tests
call mvnw.cmd clean test || exit /b 1

echo [5/5] Package
call mvnw.cmd package -DskipTests || exit /b 1

echo Validation complete. JAR: target\advanced-ai-workbench.jar
