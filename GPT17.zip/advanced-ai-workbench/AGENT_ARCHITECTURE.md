# Agent architecture

## Runtime path

```text
User prompt
   |
   +-- Chat ------------------------------------------------> normal model response
   |
   +-- Agent
        |
        +-- resolve explicit filesystem paths
        +-- choose primary live workspace
        +-- expose additional resources with roles
        +-- load project instructions / skills / MCP / LSP catalog
        +-- build compact active context
        +-- model turn
             |
             +-- multiple independent tool calls -> parallel safe execution
             +-- dependent calls -> ordered execution
             +-- edit/write/patch -> live workspace revision
             +-- build/test/check -> verifier evidence
             +-- process_start -> long-running process handle
             +-- subagent -> fresh-context delegated investigation
        |
        +-- revision-aware completion gate
        +-- durable final result
        +-- SSE completion or status-watch fallback
        +-- UI reaches terminal state without manual Stop
```

## Context lifecycle

Durable session history is retained separately from the active prompt sent to the model. Before a model request, the runtime estimates messages plus tool definitions. When the input is approaching the usable context limit, older history is replaced with a structured checkpoint and a recent tail is retained.

The checkpoint preserves objective, important details, binding user constraints, completed work, active work, blockers, next actions, relevant files, exact paths, verifier state, and key decisions. If semantic summarization fails, a deterministic fallback checkpoint is created so context maintenance cannot strand the run.

## Progress and completion

Run state is independent of the HTTP streaming transport. The backend persists the final assistant message first and then marks the run response as durable. The browser polls the run status while SSE is active. If the durable terminal response exists but SSE remains open, the browser closes only the stale transport and immediately returns the composer to Send state.

This separates **task completion** from **stream connection closure**, which is the important safeguard against a completed task waiting indefinitely.

## No-progress protection

Productive work is not restricted by a fixed step ceiling. Instead, guards are tied to actual progress:

- same tool + same args + same normalized result + same workspace revision -> warning, then block
- repeated verifier outcome without a new revision -> change strategy or stop as blocked
- repeated non-actionable model output without tool/workspace progress -> stop
- no-op edits do not create a new workspace revision
- process polling is allowed a small extra repeat window because process output can legitimately remain unchanged briefly

## Workspace authority

An explicit primary path in the current Agent prompt overrides an older active workspace. If the current prompt contains no path, the active workspace may be reused for follow-up work. Additional paths remain separate resources so reference inputs are not accidentally treated as writable primary projects.
