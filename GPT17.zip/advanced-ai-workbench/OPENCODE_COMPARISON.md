# Coding-agent flow alignment

The runtime follows the same core engineering principles used by modern coding agents such as OpenCode while keeping several safeguards tailored to this application.

| Area | Implemented behavior |
|---|---|
| Prompt-driven workspace | Explicit current-prompt path is authoritative |
| Multiple resources | Primary workspace plus separately role-scoped additional paths |
| Parallelism | Independent read/search calls can run concurrently |
| Subagents | Fresh-context delegated investigation |
| Tool context | Large observations are bounded and old outputs are pruned |
| Compaction | Proactive estimate -> semantic checkpoint -> recent tail |
| Constraint retention | Binding user constraints are explicitly preserved in checkpoints |
| Verification | Workspace-revision-aware build/test/check evidence |
| No-op edits | Do not create synthetic mutation revisions |
| Loop control | Result-aware repeated-call and non-actionable-turn guards |
| Completion | Verified revision -> one completion decision -> durable final response |
| Transport resilience | Final result is recoverable even if SSE does not close |
| Work budget | No fixed ceiling on productive tool actions |

The goal is not to copy another agent line-for-line. The design keeps the useful flow patterns while preventing the specific token, verification, Windows process-output, and stale-stream failure modes observed during testing.
