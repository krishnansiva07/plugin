# Rendering and UI fixes

## Root cause: code indentation was being damaged

Old browser logic:

```javascript
data.push(line.slice(5).trimStart());
```

`trimStart()` was unsafe for streamed LLM tokens because a token can legitimately be `"    "`, `" public"` or contain leading indentation.

New transport:

```text
event: token
data: {"text":"    public static void main..."}
```

The browser JSON-decodes `text`, so model whitespace survives exactly.

## Root cause: code was recognized only after the closing fence

The old regular expression required a complete pair of triple backticks. An unfinished streaming response therefore looked like prose until the final fence arrived.

The new line-oriented fenced-block scanner treats an open fence as code immediately and marks it as streaming until the close fence arrives.

## Root cause: incomplete Markdown support

The old renderer implemented only headings, simple lists, blockquotes, bold and inline code. Tables, task lists, horizontal rules, links, H1 semantics and several common response patterns were missing.

The new renderer supports those structures and keeps raw HTML escaped.

## Root cause: full chat DOM was rebuilt every ~55 ms

The old streaming path called `renderMessages()` repeatedly, replacing every message element while tokens arrived. That caused visual jumping and made selecting/copying content unreliable.

The new path updates only the current assistant message during streaming and performs a full render after completion.

## Root cause: all attachments used multimodal message arrays

Some text-only OpenAI-compatible endpoints reject array-form `content`, even when the array only contains text. The new backend uses ordinary string content for text documents and switches to multimodal array content only when at least one image is attached.
