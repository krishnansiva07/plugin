# GPT08 changes

This build focuses on three requested corrections.

## 1. Dedicated test-case generation removed

- Removed the Generate test cases starter action.
- Removed test-case-specific prompt rules and spreadsheet naming behavior.
- Removed recorded-flow/test-generation sample prompts and comparison references.
- General code editing, test execution, and ordinary spreadsheet output remain available as normal agent capabilities.

## 2. Word upload/read/analyze fixed

- DOCX files are now read directly from WordprocessingML in Java before falling back to Apache Tika.
- Body text, tables, headers, footers, footnotes, endnotes and comments are included when present.
- Tika extraction size is raised to the application's document-context limit.
- Files attached to the current message receive priority over older uploads in context selection.
- The UI confirms how many text characters were extracted from a Word file and warns when extraction produced no readable text.

## 3. Local workspace mapping is persistent

- A user-selected local path becomes the active workspace.
- The same local workspace is reused across subsequent agent actions, new chats and page reloads.
- Local workspaces can be used across conversations in this localhost-only single-user application.
- Deleting a chat no longer deletes the active local-path workspace record.
- Clicking the workspace close button explicitly disconnects it and clears the saved active workspace.
