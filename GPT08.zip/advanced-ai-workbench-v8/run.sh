#!/usr/bin/env bash
set -e
if [ ! -f target/advanced-ai-chat-1.6.0-SNAPSHOT.jar ]; then
  mvn clean package
fi
java -jar target/advanced-ai-chat-1.6.0-SNAPSHOT.jar
