# Agent Validation Notes

## Validation performed in this build environment

- `node --check src/main/resources/static/app.js` — PASS
- `node --check src/main/resources/static/markdown.js` — PASS
- `pom.xml` XML parse — PASS
- `run.sh` syntax (`bash -n`) — PASS
- `AgentToolRegistry` compiled under `javac --release 17` with only the Spring `@Service` annotation stubbed — PASS
- `OpenAiCompatibleClient` compiled under `javac --release 17` using minimal external-library stubs — PASS
- `AgentService` compiled under `javac --release 17` using minimal dependency stubs — PASS
- `AgentWorkspaceService` compiled under `javac --release 17` using minimal dependency stubs — PASS
- full Java source parse check found no Java syntax errors; expected missing Spring/Jackson/JPA dependencies are the only classpath failures in this environment — PASS for syntax
- tool-registry runtime smoke: 26 tools exposed; `workspace_diff=true`; `git_diff=false` — PASS

## Protocol failure addressed

The old runtime required the model to print a text JSON envelope and stopped after repeated malformed/prose responses. The new runtime uses:

1. native OpenAI-compatible tool/function calling,
2. automatic JSON response-format fallback,
3. strict compatibility recovery when both capabilities are unavailable,
4. automatic safe workspace inspection on the first prose-only agent response,
5. completion guards preventing a prose-only response from ending Agent mode before a real model-selected workspace tool has been invoked.

The previous hard-stop message **"model repeatedly failed to return the required agent tool protocol"** has been removed from the runtime.

## Additional fixes validated statically

- Agent tool registry exposes `apply_patch`, `workspace_status`, `workspace_diff` and `finish`.
- Git tools are not exposed by the registry or command allowlist.
- command-generated deletions now preserve their original baseline and are included in staged changes.
- local Apply resolves the selected root canonically and rejects symbolic-link path segments.
- application binds to `127.0.0.1` by default.

## Environment limitation

Maven is not installed in this execution environment and external DNS/package download is unavailable. Therefore `mvn clean test` and `mvn clean package` could not be run here. The source was Java-17 syntax/type-smoke compiled with dependency stubs as described above. Run the normal Maven suite on a machine with Maven/dependency access before production deployment.
