# OpenCode-style comparison

This project intentionally excludes Git operations. The comparison below focuses on local workspace-agent behavior.

| Capability | Current build |
|---|---|
| Chat sessions/history | Yes |
| Chat / read-only analysis / general workspace agent modes | Yes |
| Native OpenAI-compatible tool/function calling | Yes, primary transport |
| Automatic fallback when native tools are unavailable | Yes — JSON mode, then strict compatibility recovery |
| Read/list/glob/grep-like project tools | Yes |
| Exact file edit and full file write | Yes |
| Copy / move / delete files | Yes |
| Structured multi-file `apply_patch` | Yes |
| Workspace status/diff (non-Git) | Yes |
| Build/test/allowlisted command execution | Yes |
| Allow / Ask / Deny permissions | Yes |
| Live approval during agent run | Yes |
| Agent activity / tool console | Yes |
| Context compaction for tool runs | Yes |
| Local user-selected workspace mirror | Yes |
| Review patch before touching original | Yes |
| Automatic backup before apply | Yes |
| Baseline conflict detection | Yes |
| Symlink-safe local apply | Yes |
| General project/file analysis | Yes |
| Screenshot/vision analysis | Yes, when a vision-capable model is configured |
| Generic Excel export + test-case generation | Yes |
| Git operations | No — explicitly out of scope |
| Full arbitrary shell / PTY | Not yet — current `run_command` remains restricted |
| LSP protocol integration | Not yet |
| MCP servers/custom tool marketplace | Not yet |
| Skills discovery | Not yet |
| Multi-subagent delegation | Not yet |
| Web search/fetch as agent tools | Not yet |
| IDE extension/TUI | Not yet |
