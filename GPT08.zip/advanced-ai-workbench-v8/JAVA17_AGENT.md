# Java 17 General-Purpose Agent

This build turns Advanced AI Workbench into a Java 17 workspace-agent platform rather than a test-automation-specific generator.

## What the agent can do

The agent can work against an existing mapped project or start with an empty scratch workspace. It can inspect repository structure, search and regex-search source, read complete files or line ranges, create and edit files, copy/move/delete files, review staged workspace status/diffs, run detected build/test/check workflows, run explicitly allowlisted project-local commands, recover from command failures, and return staged changes for review/download/apply.

Supported automatic project detection includes Maven, Gradle, Node/npm/pnpm/yarn/Bun, Python/pytest, Go, Rust/Cargo, .NET, CMake, Make, Ant, Swift Package Manager, Dart/Flutter, PHP/Composer, Ruby/Rake, Bazel and Terraform-style configuration. Other toolchains can be enabled per-user through **Settings → Extra project commands** while keeping Shell permission on **Ask**.

The indexed-text layer understands common JVM, JavaScript/TypeScript, Python, Ruby, PHP, Go, Rust, C/C++, .NET, Swift, Dart, R, Lua, Perl, Elixir, Clojure, SQL, GraphQL, protobuf, config, Markdown/AsciiDoc, shell/PowerShell, Vue/Svelte, Terraform/HCL and Bazel files.

## Agent lifecycle

```text
User request
   ↓
Create AgentRun (run id + cancellation + plan + revision state)
   ↓
Create isolated mirror or scratch workspace
   ↓
LLM decides next tool (native function calling preferred)
   ↓
Inspect / read / search / edit / execute
   ↓
Real tool result returned to LLM
   ↓
Failure? → diagnose → change strategy/fix → rerun
   ↓
Completion guard
   ├─ plan still open?      → continue
   ├─ latest workspace diff missing?  → continue
   ├─ verification missing? → continue
   └─ latest verification failed? → fix or BLOCKED
   ↓
Staged patch + baseline hashes
   ↓
Review / ZIP / conflict-aware Apply
```

## Agent transport

Agent mode no longer depends on the model literally printing a hand-written JSON tool envelope. The runtime now tries native OpenAI-compatible `tools` first. If the provider/model rejects native tools, it automatically falls back to `response_format: json_object`; if that is also unavailable, strict compatibility recovery is used. A prose response no longer immediately terminates the agent run.

The Agent Console reports the active transport so provider/model compatibility is visible during execution.

## Reliability safeguards

- A run owns its active process, so Cancel terminates build/test/command processes and releases approval waits.
- Multi-step plans are persistent run state, not only text in the LLM transcript.
- File mutations advance a revision counter.
- Diff review is tied to the current mutation revision.
- Verification is tied to the current mutation revision and the **latest** verifier result. A successful build followed by failed tests is not treated as verified.
- A completion guard prevents a normal `completed` response while plan items are unfinished, the latest diff has not been reviewed, or required verification has not passed.
- Repeated identical tool calls are stopped by a loop guard.
- Previous hidden patch payloads are removed before old assistant messages are reused as LLM context.
- Apply performs SHA-256 optimistic concurrency checks before modifying a real workspace.
- Existing local files are backed up under `.advanced-ai-chat-backup/<timestamp>/` before writes/deletes.
- Patch ZIPs include `_AGENT_PATCH_MANIFEST.json` describing staged writes and deletions.

## Execution safety

The agent runs commands in a temporary workspace, strips likely secret environment variables, redirects HOME/USERPROFILE to an agent-local directory, disallows shell chaining/redirection and restricts generic commands to an allowlist plus user-approved extra commands.

**Important:** this is process hardening, not an OS/container security boundary. Maven/Gradle/npm and other project code can execute arbitrary program logic. For untrusted projects keep **Shell / build / tests = Ask**. Strong OS isolation would require an optional Docker/Podman/Windows Sandbox/other platform sandbox outside the Java process.

## Java baseline

The application remains Java 17 compatible (`<java.version>17</java.version>`). No Java 21-only language/API requirement was introduced by the agent changes.
