package com.llmart.llm.controller;

import com.llmart.llm.dto.FileDto;
import com.llmart.llm.entity.FileEntity;
import com.llmart.llm.service.FileService;
import org.springframework.core.io.Resource;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@RestController
@RequestMapping("/api/files")
public class FileController {
    private final FileService service;

    public FileController(FileService service) { this.service = service; }

    @PostMapping(consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public FileDto upload(@RequestParam String conversationId, @RequestPart("file") MultipartFile file) throws Exception {
        return service.save(conversationId, file);
    }

    @GetMapping
    public List<FileDto> list(@RequestParam String conversationId) {
        return service.listForConversation(conversationId);
    }


    @GetMapping("/{id}/view")
    public ResponseEntity<Resource> view(@PathVariable String id) {
        FileEntity f = service.require(id);
        Resource resource = service.resource(id);
        MediaType type;
        try { type = MediaType.parseMediaType(f.getMimeType()); }
        catch (Exception e) { type = MediaType.APPLICATION_OCTET_STREAM; }
        return ResponseEntity.ok()
                .contentType(type)
                .header(HttpHeaders.CONTENT_DISPOSITION, "inline; filename=\"" + f.getOriginalName().replace("\"", "_") + "\"")
                .body(resource);
    }

    @GetMapping("/{id}/download")
    public ResponseEntity<Resource> download(@PathVariable String id) {
        FileEntity f = service.require(id);
        Resource resource = service.resource(id);
        MediaType type;
        try { type = MediaType.parseMediaType(f.getMimeType()); }
        catch (Exception e) { type = MediaType.APPLICATION_OCTET_STREAM; }
        return ResponseEntity.ok()
                .contentType(type)
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + f.getOriginalName().replace("\"", "_") + "\"")
                .body(resource);
    }
}
