package com.llmart.llm.repository;

import com.llmart.llm.entity.ProjectWorkspaceEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface ProjectWorkspaceRepository extends JpaRepository<ProjectWorkspaceEntity, String> {
    List<ProjectWorkspaceEntity> findByConversationIdOrderByUpdatedAtDesc(String conversationId);
}
