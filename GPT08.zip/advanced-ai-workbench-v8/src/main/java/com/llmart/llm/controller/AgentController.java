package com.llmart.llm.controller;

import com.llmart.llm.service.AgentApprovalService;
import com.llmart.llm.service.AgentRunService;
import org.springframework.web.bind.annotation.*;

import java.util.LinkedHashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/agent")
public class AgentController {
    private final AgentApprovalService approvals;
    private final AgentRunService runs;

    public AgentController(AgentApprovalService approvals, AgentRunService runs) {
        this.approvals = approvals;
        this.runs = runs;
    }

    @PostMapping("/approvals/{id}")
    public Map<String, Object> resolve(@PathVariable String id, @RequestBody Map<String, Object> body) {
        boolean approved = Boolean.TRUE.equals(body.get("approved"));
        boolean resolved = approvals.resolve(id, approved);
        return Map.of("resolved", resolved, "approved", approved);
    }

    @PostMapping("/runs/{id}/cancel")
    public Map<String, Object> cancel(@PathVariable String id) {
        boolean cancelled = runs.cancel(id);
        int approvalsReleased = approvals.cancelRun(id);
        Map<String,Object> result = new LinkedHashMap<>();
        result.put("cancelled", cancelled);
        result.put("approvalsReleased", approvalsReleased);
        return result;
    }

    @GetMapping("/runs/{id}")
    public Map<String, Object> status(@PathVariable String id) {
        return runs.status(id);
    }
}
