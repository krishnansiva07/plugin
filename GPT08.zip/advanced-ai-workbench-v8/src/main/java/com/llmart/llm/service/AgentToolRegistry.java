package com.llmart.llm.service;

import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class AgentToolRegistry {
    private final List<Map<String, Object>> nativeDefinitions;
    private final Set<String> names;

    public AgentToolRegistry() {
        List<Map<String, Object>> tools = new ArrayList<>();
        tools.add(tool("set_plan", "Create the execution plan before non-trivial mutations or commands.", objectSchema(
                prop("items", arrayOf(stringSchema("A concise plan item"))), required("items"))));
        tools.add(tool("update_plan", "Update one plan item as work progresses.", objectSchema(
                prop("index", integerSchema("1-based plan item index")),
                prop("status", enumSchema("pending", "in_progress", "completed", "blocked", "skipped")),
                prop("note", stringSchema("Optional short note")), required("index", "status"))));
        tools.add(tool("get_plan", "Read the current execution plan.", emptyObject()));
        tools.add(tool("inspect_workspace", "Inspect workspace structure, project descriptors and likely toolchains.", emptyObject()));
        tools.add(tool("list_project", "List files under an optional relative path.", objectSchema(prop("prefix", stringSchema("Optional relative path prefix")))));
        tools.add(tool("glob_project", "Find files using a glob pattern.", objectSchema(
                prop("pattern", stringSchema("Glob such as src/**/*.java")), prop("maxMatches", integerSchema("Maximum matches")), required("pattern"))));
        tools.add(tool("file_info", "Return metadata for a workspace file.", objectSchema(prop("path", stringSchema("Relative file path")), required("path"))));
        tools.add(tool("search_project", "Search workspace text for a literal string.", objectSchema(
                prop("query", stringSchema("Text to search for")), prop("maxMatches", integerSchema("Maximum matches")), required("query"))));
        tools.add(tool("regex_search", "Search workspace text using a Java regular expression.", objectSchema(
                prop("regex", stringSchema("Regular expression")), prop("maxMatches", integerSchema("Maximum matches")), required("regex"))));
        tools.add(tool("read_file", "Read a complete text file.", objectSchema(prop("path", stringSchema("Relative file path")), required("path"))));
        tools.add(tool("read_file_range", "Read a selected line range from a text file.", objectSchema(
                prop("path", stringSchema("Relative file path")), prop("startLine", integerSchema("First line, 1-based")),
                prop("endLine", integerSchema("Last line, inclusive")), required("path"))));
        tools.add(tool("read_files", "Read up to eight text files in one call.", objectSchema(
                prop("paths", arrayOf(stringSchema("Relative file path"))), required("paths"))));

        tools.add(tool("edit_file", "Replace exact text in an existing file. Prefer this for small targeted edits.", objectSchema(
                prop("path", stringSchema("Relative file path")), prop("oldText", stringSchema("Exact existing text")),
                prop("newText", stringSchema("Replacement text")), prop("replaceAll", booleanSchema("Replace every exact occurrence")),
                required("path", "oldText", "newText"))));
        tools.add(tool("write_file", "Create or replace a text file with complete final content.", objectSchema(
                prop("path", stringSchema("Relative file path")), prop("content", stringSchema("Complete final file content")), required("path", "content"))));
        tools.add(tool("copy_file", "Copy one workspace file to another relative path.", objectSchema(
                prop("from", stringSchema("Source relative path")), prop("to", stringSchema("Destination relative path")),
                prop("overwrite", booleanSchema("Allow replacing an existing destination")), required("from", "to"))));
        tools.add(tool("move_file", "Move or rename a workspace file.", objectSchema(
                prop("from", stringSchema("Source relative path")), prop("to", stringSchema("Destination relative path")),
                prop("overwrite", booleanSchema("Allow replacing an existing destination")), required("from", "to"))));
        tools.add(tool("delete_file", "Delete a workspace file.", objectSchema(prop("path", stringSchema("Relative file path")), required("path"))));
        tools.add(tool("apply_patch", "Apply multiple structured file writes/deletions atomically inside the isolated workspace.", objectSchema(
                prop("changes", arrayOf(objectSchema(
                        prop("path", stringSchema("Relative file path")),
                        prop("operation", enumSchema("write", "delete")),
                        prop("content", stringSchema("Required for write; ignored for delete")),
                        required("path", "operation")
                ))), required("changes"))));

        tools.add(tool("changed_files", "List files changed in the isolated workspace.", emptyObject()));
        tools.add(tool("workspace_status", "Show added, modified and deleted workspace files. This is not Git.", emptyObject()));
        tools.add(tool("workspace_diff", "Review staged workspace changes relative to the original local files. This is not Git.", objectSchema(
                prop("path", stringSchema("Optional relative file path")))));
        tools.add(tool("run_build", "Run the detected project build in the workspace or a module cwd.", objectSchema(prop("cwd", stringSchema("Optional relative module directory")))));
        tools.add(tool("run_tests", "Run the detected project tests in the workspace or a module cwd.", objectSchema(prop("cwd", stringSchema("Optional relative module directory")))));
        tools.add(tool("run_check", "Run detected validation, lint, typecheck or verification commands.", objectSchema(prop("cwd", stringSchema("Optional relative module directory")))));
        tools.add(tool("run_command", "Run one approved project-local command in the isolated workspace.", objectSchema(
                prop("command", stringSchema("Command line")), prop("cwd", stringSchema("Optional relative module directory")), required("command"))));
        tools.add(tool("finish", "Finish the agent run only after the task is complete or genuinely blocked.", objectSchema(
                prop("status", enumSchema("completed", "blocked")), prop("message", stringSchema("Concise Markdown summary for the user")),
                required("status", "message"))));

        nativeDefinitions = List.copyOf(tools);
        LinkedHashSet<String> found = new LinkedHashSet<>();
        for (Map<String, Object> item : nativeDefinitions) {
            Object function = item.get("function");
            if (function instanceof Map<?, ?> map) found.add(String.valueOf(map.get("name")));
        }
        names = Set.copyOf(found);
    }

    public List<Map<String, Object>> nativeDefinitions() { return nativeDefinitions; }
    public boolean isKnown(String tool) { return tool != null && names.contains(tool); }
    public Set<String> names() { return names; }

    private static Map<String, Object> tool(String name, String description, Map<String, Object> parameters) {
        return Map.of("type", "function", "function", Map.of(
                "name", name,
                "description", description,
                "parameters", parameters
        ));
    }

    @SafeVarargs
    private static Map<String, Object> objectSchema(Map.Entry<String, Object>... entries) {
        LinkedHashMap<String, Object> properties = new LinkedHashMap<>();
        List<String> required = new ArrayList<>();
        for (Map.Entry<String, Object> entry : entries) {
            if ("__required__".equals(entry.getKey())) {
                Object value = entry.getValue();
                if (value instanceof Collection<?> collection) {
                    for (Object item : collection) required.add(String.valueOf(item));
                }
            } else properties.put(entry.getKey(), entry.getValue());
        }
        LinkedHashMap<String, Object> schema = new LinkedHashMap<>();
        schema.put("type", "object");
        schema.put("properties", properties);
        schema.put("additionalProperties", false);
        if (!required.isEmpty()) schema.put("required", required);
        return schema;
    }

    private static Map<String, Object> emptyObject() {
        return Map.of("type", "object", "properties", Map.of(), "additionalProperties", false);
    }

    private static Map.Entry<String, Object> prop(String name, Object schema) {
        return Map.entry(name, schema);
    }

    private static Map.Entry<String, Object> required(String... names) {
        return Map.entry("__required__", List.of(names));
    }

    private static Map<String, Object> stringSchema(String description) {
        return Map.of("type", "string", "description", description);
    }

    private static Map<String, Object> integerSchema(String description) {
        return Map.of("type", "integer", "description", description);
    }

    private static Map<String, Object> booleanSchema(String description) {
        return Map.of("type", "boolean", "description", description);
    }

    private static Map<String, Object> enumSchema(String... values) {
        return Map.of("type", "string", "enum", List.of(values));
    }

    private static Map<String, Object> arrayOf(Object itemSchema) {
        return Map.of("type", "array", "items", itemSchema);
    }
}
