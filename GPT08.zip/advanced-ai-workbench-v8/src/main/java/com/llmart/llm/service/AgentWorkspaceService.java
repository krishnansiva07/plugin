package com.llmart.llm.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.llmart.llm.dto.ProjectPatchRequest;
import com.llmart.llm.entity.ProjectFileEntity;
import com.llmart.llm.entity.ProjectWorkspaceEntity;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.nio.file.attribute.PosixFilePermission;
import java.time.Duration;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Service
public class AgentWorkspaceService {
    private static final int MAX_READ_CHARS = 300_000;
    private static final int MAX_WRITE_CHARS = 2_000_000;
    private static final int MAX_TOOL_OUTPUT = 55_000;
    private static final long MAX_LOCAL_COPY_BYTES = 700L * 1024 * 1024;
    private static final int MAX_LOCAL_COPY_FILES = 20_000;
    private static final Pattern TOKEN_PATTERN = Pattern.compile("\\\"([^\\\"]*)\\\"|'([^']*)'|([^\\s]+)");
    private static final Set<String> BASE_COMMAND_ALLOWLIST = Set.of(
            "mvn", "mvnw", "./mvnw", "mvnw.cmd", "javac",
            "gradle", "gradlew", "./gradlew", "gradlew.bat",
            "npm", "npm.cmd", "pnpm", "pnpm.cmd", "yarn", "yarn.cmd", "bun", "bun.exe", "deno",
            "pytest", "go", "cargo", "dotnet", "make", "cmake", "ctest", "ninja",
            "ant", "php", "composer", "ruby", "bundle", "rake", "swift", "dart", "flutter", "bazel",
            "sbt", "mill", "lein", "clojure", "mix", "rebar3", "stack", "cabal", "zig", "nim", "julia",
            "terraform", "tofu"
    );
    private static final Set<String> SKIP_DIRS = Set.of(
            ".git", ".svn", ".hg", "node_modules", "target", "build", "dist", "out", ".gradle", ".idea", ".next",
            "coverage", ".advanced-ai-chat-backup", ".agent-build", ".agent-home", ".venv", "venv", "env", "vendor",
            ".terraform", ".dart_tool", ".tox", ".pytest_cache", "__pycache__", ".mypy_cache", ".ruff_cache", ".cache",
            "bin", "obj", "pods", "deriveddata", ".build"
    );
    private static final Set<String> CODE_EXTENSIONS = Set.of(
            "java","kt","kts","groovy","scala","js","jsx","ts","tsx","py","rb","php","go","rs","c","cc","cpp","cxx","h","hpp",
            "cs","fs","fsx","vb","swift","dart","r","lua","pl","pm","ex","exs","clj","cljs","sql","graphql","gql","proto","thrift",
            "vue","svelte","jsp","ftl","mustache","tf","hcl","bzl","sh","bash","zsh","ps1","bat","cmd",
            "sbt","zig","nim","jl","hs","lhs","erl","hrl","elm","sol"
    );

    private final ProjectService projects;
    private final ObjectMapper objectMapper;
    private final Path workspaceRoot;

    public AgentWorkspaceService(ProjectService projects, ObjectMapper objectMapper,
                                 @Value("${app.agent-workspace-dir:./data/agent-workspaces}") String workspaceDir) {
        this.projects = projects;
        this.objectMapper = objectMapper;
        this.workspaceRoot = Path.of(workspaceDir).toAbsolutePath().normalize();
    }

    public Workspace prepare(String projectId) throws IOException {
        Files.createDirectories(workspaceRoot);
        if (projectId == null || projectId.isBlank()) return prepareScratch();

        ProjectWorkspaceEntity project = projects.require(projectId);
        Path root = newWorkspaceRoot(projectId);
        Map<String,String> baseline = new LinkedHashMap<>();
        Map<String,String> baselineHashes = new LinkedHashMap<>();

        if (project.hasLocalPath()) {
            Path source = Path.of(project.getLocalPath()).toAbsolutePath().normalize();
            copyLocalTree(source, root);
        } else {
            for (ProjectFileEntity file : projects.fileEntities(projectId)) {
                String relative = normalizeRelative(file.getRelativePath());
                String content = file.getTextContent() == null ? "" : file.getTextContent();
                baseline.put(relative, content);
                baselineHashes.put(relative, Hashing.sha256(content));
                Path target = resolve(root, relative);
                Files.createDirectories(target.getParent());
                Files.writeString(target, content, StandardCharsets.UTF_8, StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
            }
        }
        makeWrappersExecutable(root);
        Workspace ws = new Workspace(projectId, root, baseline, baselineHashes, project.hasLocalPath(), false);
        if (project.hasLocalPath()) initializeBaselineHashes(ws);
        return ws;
    }

    private Workspace prepareScratch() throws IOException {
        Path root = newWorkspaceRoot("_scratch");
        return new Workspace(null, root, new LinkedHashMap<>(), new LinkedHashMap<>(), false, true);
    }

    private Path newWorkspaceRoot(String bucket) throws IOException {
        Path parent = workspaceRoot.resolve(bucket).normalize();
        Path root = parent.resolve(UUID.randomUUID().toString()).normalize();
        if (!root.startsWith(workspaceRoot)) throw new SecurityException("Invalid agent workspace path");
        Files.createDirectories(root);
        return root;
    }

    private void copyLocalTree(Path source, Path destination) throws IOException {
        if (!Files.isDirectory(source)) throw new IllegalArgumentException("Local project directory is unavailable: " + source);
        final long[] bytes = {0};
        final int[] count = {0};
        Files.walkFileTree(source, EnumSet.noneOf(FileVisitOption.class), Integer.MAX_VALUE, new SimpleFileVisitor<>() {
            @Override public FileVisitResult preVisitDirectory(Path dir, BasicFileAttributes attrs) throws IOException {
                if (!dir.equals(source)) {
                    String name = dir.getFileName() == null ? "" : dir.getFileName().toString().toLowerCase(Locale.ROOT);
                    if (SKIP_DIRS.contains(name)) return FileVisitResult.SKIP_SUBTREE;
                }
                Path rel = source.relativize(dir);
                Files.createDirectories(destination.resolve(rel));
                return FileVisitResult.CONTINUE;
            }

            @Override public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) throws IOException {
                if (Files.isSymbolicLink(file)) return FileVisitResult.CONTINUE;
                if (count[0] >= MAX_LOCAL_COPY_FILES || bytes[0] >= MAX_LOCAL_COPY_BYTES) return FileVisitResult.TERMINATE;
                long size = attrs.size();
                if (bytes[0] + size > MAX_LOCAL_COPY_BYTES) return FileVisitResult.CONTINUE;
                Path rel = source.relativize(file);
                Path target = destination.resolve(rel).normalize();
                if (!target.startsWith(destination)) throw new SecurityException("Invalid copied project path");
                Files.createDirectories(target.getParent());
                Files.copy(file, target, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.COPY_ATTRIBUTES);
                bytes[0] += size;
                count[0]++;
                return FileVisitResult.CONTINUE;
            }
        });
    }

    public String inspectWorkspace(Workspace ws) throws IOException {
        List<String> paths = allPaths(ws);
        List<String> descriptors = paths.stream().filter(this::isDescriptor).limit(200).toList();
        long textFiles = paths.stream().filter(this::isReadableTextPath).count();
        StringBuilder out = new StringBuilder();
        out.append("mode=").append(ws.scratch ? "scratch" : ws.localMirror ? "local-mirror" : "indexed-mirror").append('\n');
        out.append("files=").append(paths.size()).append("; readableTextFiles=").append(textFiles).append('\n');
        if (descriptors.isEmpty()) out.append("descriptors=[none detected]\n");
        else {
            out.append("descriptors:\n");
            for (String descriptor : descriptors) out.append("- ").append(descriptor).append(" -> ").append(descriptorKind(descriptor)).append('\n');
        }
        VerificationAdvice advice = verificationAdvice(ws);
        out.append("verificationRequired=").append(advice.required()).append("; reason=").append(advice.reason());
        return out.toString();
    }

    public String listFiles(Workspace ws, String prefix) throws IOException {
        String normalizedPrefix = prefix == null ? "" : prefix.replace('\\','/').replaceAll("^/+", "");
        List<String> paths = allPaths(ws).stream().filter(p -> normalizedPrefix.isBlank() || p.startsWith(normalizedPrefix)).limit(1500).toList();
        String body = String.join("\n", paths);
        if (paths.size() >= 1500) body += "\n... [file list truncated]";
        return body.isBlank() ? "[No matching project files]" : body;
    }

    public String glob(Workspace ws, String pattern, int maxMatches) throws IOException {
        String value = pattern == null || pattern.isBlank() ? "**/*" : pattern.replace('\\','/');
        PathMatcher matcher = FileSystems.getDefault().getPathMatcher("glob:" + value);
        int cap = Math.max(1, Math.min(1000, maxMatches));
        List<String> result = new ArrayList<>();
        for (String path : allPaths(ws)) {
            if (matcher.matches(Path.of(path))) result.add(path);
            if (result.size() >= cap) break;
        }
        return result.isEmpty() ? "[No files match glob: " + value + "]" : String.join("\n", result);
    }

    public String fileInfo(Workspace ws, String rawPath) throws IOException {
        String relative = normalizeRelative(rawPath);
        Path file = resolve(ws.root, relative);
        if (!Files.exists(file)) return "path=" + relative + "; exists=false";
        if (Files.isDirectory(file)) return "path=" + relative + "; exists=true; type=directory";
        if (!Files.isRegularFile(file)) return "path=" + relative + "; exists=true; type=other";
        long size = Files.size(file);
        StringBuilder out = new StringBuilder("path=").append(relative)
                .append("; exists=true; type=file; sizeBytes=").append(size)
                .append("; readableText=").append(isReadableTextPath(relative));
        if (size <= MAX_READ_CHARS * 4L) {
            try {
                String text = Files.readString(file, StandardCharsets.UTF_8);
                out.append("; sha256=").append(Hashing.sha256(text));
            } catch (Exception ignored) { }
        }
        return out.toString();
    }

    public String readFile(Workspace ws, String rawPath) throws IOException {
        return readFileRange(ws, rawPath, 1, Integer.MAX_VALUE);
    }

    public String readFileRange(Workspace ws, String rawPath, int startLine, int endLine) throws IOException {
        String relative = normalizeRelative(rawPath);
        Path file = resolve(ws.root, relative);
        if (!Files.exists(file) || !Files.isRegularFile(file)) throw new NoSuchFileException(relative);
        if (!isReadableTextPath(relative) && !ws.touched.contains(relative)) throw new IllegalArgumentException("File is not a supported text/source file: " + relative);

        int start = Math.max(1, startLine);
        int end = endLine <= 0 ? Integer.MAX_VALUE : Math.max(start, endLine);
        if (start == 1 && end == Integer.MAX_VALUE) {
            String text = Files.readString(file, StandardCharsets.UTF_8);
            if (text.length() > MAX_READ_CHARS) text = text.substring(0, MAX_READ_CHARS) + "\n[... file truncated by agent tool ...]";
            return "FILE: " + relative + "\n" + text;
        }

        List<String> lines = Files.readAllLines(file, StandardCharsets.UTF_8);
        if (start > lines.size()) return "FILE: " + relative + "\n[Requested range starts after end of file; lines=" + lines.size() + "]";
        int actualEnd = Math.min(lines.size(), end);
        StringBuilder out = new StringBuilder("FILE: ").append(relative).append(" (lines ").append(start).append('-').append(actualEnd).append(")\n");
        for (int i = start; i <= actualEnd; i++) {
            out.append(i).append(" | ").append(lines.get(i - 1)).append('\n');
            if (out.length() >= MAX_READ_CHARS) {
                out.append("[... range truncated by agent tool ...]");
                break;
            }
        }
        return out.toString().stripTrailing();
    }

    public String readFiles(Workspace ws, List<String> paths) throws IOException {
        if (paths == null || paths.isEmpty()) throw new IllegalArgumentException("paths are required");
        StringBuilder out = new StringBuilder();
        for (String path : paths.stream().limit(12).toList()) {
            if (!out.isEmpty()) out.append("\n\n");
            out.append(readFile(ws, path));
            if (out.length() > MAX_TOOL_OUTPUT) break;
        }
        return clip(out.toString());
    }

    public String search(Workspace ws, String query, int maxMatches) throws IOException {
        if (query == null || query.isBlank()) throw new IllegalArgumentException("search_project requires query");
        String needle = query.toLowerCase(Locale.ROOT);
        return searchInternal(ws, line -> line.toLowerCase(Locale.ROOT).contains(needle), maxMatches, "query: " + query);
    }

    public String regexSearch(Workspace ws, String regex, int maxMatches) throws IOException {
        if (regex == null || regex.isBlank()) throw new IllegalArgumentException("regex_search requires regex");
        Pattern pattern;
        try { pattern = Pattern.compile(regex); }
        catch (Exception e) { throw new IllegalArgumentException("Invalid regex: " + e.getMessage()); }
        return searchInternal(ws, line -> pattern.matcher(line).find(), maxMatches, "regex: " + regex);
    }

    private String searchInternal(Workspace ws, java.util.function.Predicate<String> matcher, int maxMatches, String label) throws IOException {
        int cap = Math.max(1, Math.min(200, maxMatches));
        StringBuilder out = new StringBuilder();
        int matches = 0;
        for (String relative : textPaths(ws)) {
            Path file = resolve(ws.root, relative);
            List<String> lines;
            try { lines = Files.readAllLines(file, StandardCharsets.UTF_8); }
            catch (Exception ignored) { continue; }
            for (int i = 0; i < lines.size(); i++) {
                if (!matcher.test(lines.get(i))) continue;
                int start = Math.max(0, i - 2), end = Math.min(lines.size() - 1, i + 2);
                out.append("\n--- ").append(relative).append(':').append(i + 1).append(" ---\n");
                for (int n = start; n <= end; n++) out.append(n + 1).append(" | ").append(lines.get(n)).append('\n');
                matches++;
                if (matches >= cap || out.length() >= MAX_TOOL_OUTPUT) return clip(out.toString());
            }
        }
        return matches == 0 ? "[No matches for " + label + "]" : clip(out.toString());
    }

    public String writeFile(Workspace ws, String rawPath, String content) throws IOException {
        String relative = normalizeRelative(rawPath);
        String value = content == null ? "" : content;
        if (value.length() > MAX_WRITE_CHARS) throw new IllegalArgumentException("Agent file is too large to write: " + relative);
        captureBaseline(ws, relative);
        Path file = resolve(ws.root, relative);
        Files.createDirectories(file.getParent());
        Files.writeString(file, value, StandardCharsets.UTF_8, StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
        ws.touched.add(relative);
        if (isWrapper(relative)) makeExecutable(file);
        return "Wrote " + relative + " (" + value.length() + " chars)";
    }

    public String editFile(Workspace ws, String rawPath, String oldText, String newText, boolean replaceAll) throws IOException {
        String relative = normalizeRelative(rawPath);
        Path file = resolve(ws.root, relative);
        if (!Files.isRegularFile(file)) throw new NoSuchFileException(relative);
        String current = Files.readString(file, StandardCharsets.UTF_8);
        if (oldText == null || oldText.isEmpty()) throw new IllegalArgumentException("oldText is required");
        int first = current.indexOf(oldText);
        if (first < 0) throw new IllegalArgumentException("oldText was not found in " + relative);
        if (!replaceAll && current.indexOf(oldText, first + oldText.length()) >= 0) {
            throw new IllegalArgumentException("oldText occurs more than once; provide more surrounding context or set replaceAll=true");
        }
        captureBaseline(ws, relative);
        String replacement = newText == null ? "" : newText;
        String updated = replaceAll ? current.replace(oldText, replacement)
                : current.substring(0, first) + replacement + current.substring(first + oldText.length());
        Files.writeString(file, updated, StandardCharsets.UTF_8, StandardOpenOption.TRUNCATE_EXISTING);
        ws.touched.add(relative);
        return "Edited " + relative + " (" + (replaceAll ? "all matching occurrences" : "1 occurrence") + ")";
    }

    public String deleteFile(Workspace ws, String rawPath) throws IOException {
        String relative = normalizeRelative(rawPath);
        Path file = resolve(ws.root, relative);
        if (!Files.exists(file)) throw new NoSuchFileException(relative);
        if (!Files.isRegularFile(file)) throw new IllegalArgumentException("delete_file only deletes files, not directories: " + relative);
        captureBaseline(ws, relative);
        Files.delete(file);
        ws.touched.add(relative);
        return "Deleted " + relative + " in the isolated workspace";
    }

    public String applyPatch(Workspace ws, JsonNode changes) throws IOException {
        if (changes == null || !changes.isArray() || changes.isEmpty()) {
            throw new IllegalArgumentException("apply_patch requires a non-empty changes array");
        }
        if (changes.size() > 50) throw new IllegalArgumentException("apply_patch supports at most 50 file changes");

        record Prepared(String path, String operation, String content, Path target) {}
        List<Prepared> prepared = new ArrayList<>();
        Set<String> unique = new HashSet<>();
        for (JsonNode change : changes) {
            String relative = normalizeRelative(change.path("path").asText(""));
            if (!unique.add(relative)) throw new IllegalArgumentException("Duplicate apply_patch path: " + relative);
            String operation = change.path("operation").asText("write").trim().toLowerCase(Locale.ROOT);
            if (!Set.of("write", "delete").contains(operation)) {
                throw new IllegalArgumentException("Unsupported apply_patch operation for " + relative + ": " + operation);
            }
            String content = change.path("content").asText("");
            if ("write".equals(operation) && content.length() > MAX_WRITE_CHARS) {
                throw new IllegalArgumentException("Agent file is too large to write: " + relative);
            }
            Path target = resolve(ws.root, relative);
            if (Files.exists(target) && !Files.isRegularFile(target)) {
                throw new IllegalArgumentException("apply_patch only supports files: " + relative);
            }
            prepared.add(new Prepared(relative, operation, content, target));
        }

        // Capture every original before the first mutation so the batch remains reviewable as one staged change set.
        for (Prepared item : prepared) captureBaseline(ws, item.path());

        int writes = 0, deletes = 0;
        for (Prepared item : prepared) {
            if ("delete".equals(item.operation())) {
                if (Files.deleteIfExists(item.target())) deletes++;
            } else {
                Files.createDirectories(item.target().getParent());
                Files.writeString(item.target(), item.content(), StandardCharsets.UTF_8,
                        StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
                if (isWrapper(item.path())) makeExecutable(item.target());
                writes++;
            }
            ws.touched.add(item.path());
        }
        return "Applied structured workspace patch: " + writes + " write(s), " + deletes + " delete(s)";
    }

    public String moveFile(Workspace ws, String rawSource, String rawTarget, boolean overwrite) throws IOException {
        String source = normalizeRelative(rawSource);
        String target = normalizeRelative(rawTarget);
        if (source.equals(target)) return "Source and target are identical; no change made";
        Path sourcePath = resolve(ws.root, source);
        Path targetPath = resolve(ws.root, target);
        if (!Files.isRegularFile(sourcePath)) throw new NoSuchFileException(source);
        if (Files.exists(targetPath) && !overwrite) throw new FileAlreadyExistsException(target);
        captureBaseline(ws, source);
        captureBaseline(ws, target);
        Files.createDirectories(targetPath.getParent());
        if (overwrite) Files.move(sourcePath, targetPath, StandardCopyOption.REPLACE_EXISTING);
        else Files.move(sourcePath, targetPath);
        ws.touched.add(source);
        ws.touched.add(target);
        if (isWrapper(target)) makeExecutable(targetPath);
        return "Moved " + source + " -> " + target;
    }

    public String copyFile(Workspace ws, String rawSource, String rawTarget, boolean overwrite) throws IOException {
        String source = normalizeRelative(rawSource);
        String target = normalizeRelative(rawTarget);
        Path sourcePath = resolve(ws.root, source);
        Path targetPath = resolve(ws.root, target);
        if (!Files.isRegularFile(sourcePath)) throw new NoSuchFileException(source);
        if (Files.exists(targetPath) && !overwrite) throw new FileAlreadyExistsException(target);
        captureBaseline(ws, target);
        Files.createDirectories(targetPath.getParent());
        if (overwrite) Files.copy(sourcePath, targetPath, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.COPY_ATTRIBUTES);
        else Files.copy(sourcePath, targetPath, StandardCopyOption.COPY_ATTRIBUTES);
        ws.touched.add(target);
        return "Copied " + source + " -> " + target;
    }

    private void captureBaseline(Workspace ws, String relative) throws IOException {
        if (ws.baseline.containsKey(relative)) return;
        if (ws.baselineHashes.containsKey(relative)) {
            if (Hashing.ABSENT.equals(ws.baselineHashes.get(relative))) {
                ws.baseline.put(relative, null);
            } else {
                ws.baseline.put(relative, originalText(ws, relative));
            }
            return;
        }
        Path file = resolve(ws.root, relative);
        if (Files.exists(file) && Files.isRegularFile(file)) {
            String content = Files.readString(file, StandardCharsets.UTF_8);
            ws.baseline.put(relative, content);
            ws.baselineHashes.put(relative, Hashing.sha256(content));
        } else {
            ws.baseline.put(relative, null);
            ws.baselineHashes.put(relative, Hashing.ABSENT);
        }
    }

    private void initializeBaselineHashes(Workspace ws) throws IOException {
        for (String relative : allPaths(ws)) {
            if (!isReadableTextPath(relative)) continue;
            Path file = resolve(ws.root, relative);
            try {
                if (Files.size(file) > MAX_WRITE_CHARS * 4L) continue;
                String text = Files.readString(file, StandardCharsets.UTF_8);
                ws.baselineHashes.put(relative, Hashing.sha256(text));
            } catch (Exception ignored) {
                // Unreadable/binary-like files are intentionally outside the staged text patch model.
            }
        }
    }

    private String originalText(Workspace ws, String relative) throws IOException {
        if (ws.baseline.containsKey(relative)) return ws.baseline.get(relative);
        if (ws.scratch || Hashing.ABSENT.equals(ws.baselineHashes.get(relative))) return null;
        if (ws.localMirror && ws.projectId != null && !ws.projectId.isBlank()) {
            ProjectWorkspaceEntity project = projects.require(ws.projectId);
            if (project.hasLocalPath()) {
                Path sourceRoot = Path.of(project.getLocalPath()).toAbsolutePath().normalize();
                Path source = sourceRoot.resolve(relative).normalize();
                if (!source.startsWith(sourceRoot)) throw new SecurityException("Baseline path escapes project: " + relative);
                if (Files.isRegularFile(source)) return Files.readString(source, StandardCharsets.UTF_8);
                return null;
            }
        }
        return ws.baseline.get(relative);
    }

    public String changedFiles(Workspace ws) throws IOException {
        List<ProjectPatchRequest.ProjectPatchFile> changes = changes(ws);
        if (changes.isEmpty()) return "[No source files changed in the isolated workspace]";
        return changes.stream().map(f -> f.safeOperation().toUpperCase(Locale.ROOT) + " " + f.path() +
                ("delete".equals(f.safeOperation()) ? "" : " (" + (f.content() == null ? 0 : f.content().length()) + " chars)"))
                .collect(Collectors.joining("\n"));
    }

    public String workspaceStatus(Workspace ws) throws IOException {
        List<ProjectPatchRequest.ProjectPatchFile> changes = changes(ws);
        if (changes.isEmpty()) return "workspace clean (no staged agent changes)";
        List<String> rows = new ArrayList<>();
        for (ProjectPatchRequest.ProjectPatchFile change : changes) {
            boolean existed = !Hashing.ABSENT.equals(change.baselineHash());
            if ("delete".equals(change.safeOperation())) rows.add("D  " + change.path());
            else if (!existed) rows.add("A  " + change.path());
            else rows.add("M  " + change.path());
        }
        return String.join("\n", rows);
    }

    public String workspaceDiff(Workspace ws, String requestedPath) throws IOException {
        List<String> targets = requestedPath == null || requestedPath.isBlank()
                ? new ArrayList<>(ws.touched)
                : List.of(normalizeRelative(requestedPath));
        if (targets.isEmpty()) return "[No staged changes]";
        StringBuilder out = new StringBuilder();
        for (String relative : targets) {
            if (!ws.touched.contains(relative)) continue;
            Path file = resolve(ws.root, relative);
            String before = ws.baseline.containsKey(relative) ? ws.baseline.get(relative) : originalText(ws, relative);
            boolean exists = Files.exists(file) && Files.isRegularFile(file);
            String after = exists ? Files.readString(file, StandardCharsets.UTF_8) : null;
            if (Objects.equals(before, after)) continue;
            out.append("--- a/").append(relative).append("\n+++ b/").append(relative).append("\n");
            out.append("@@ original @@\n").append(before == null ? "[new file / absent]\n" : before);
            out.append("\n@@ updated @@\n").append(after == null ? "[deleted]\n" : after).append('\n');
            if (out.length() > MAX_TOOL_OUTPUT) break;
        }
        return out.isEmpty() ? "[No staged changes]" : clip(out.toString());
    }

    public List<ProjectPatchRequest.ProjectPatchFile> changes(Workspace ws) throws IOException {
        List<ProjectPatchRequest.ProjectPatchFile> result = new ArrayList<>();
        for (String relative : ws.touched) {
            Path file = resolve(ws.root, relative);
            String before = ws.baseline.containsKey(relative) ? ws.baseline.get(relative) : originalText(ws, relative);
            String baselineHash = ws.baselineHashes.getOrDefault(relative, before == null ? Hashing.ABSENT : Hashing.sha256(before));
            if (Files.exists(file) && Files.isRegularFile(file)) {
                String current = Files.readString(file, StandardCharsets.UTF_8);
                if (!Objects.equals(before, current)) {
                    result.add(new ProjectPatchRequest.ProjectPatchFile(relative, current, baselineHash, "write"));
                }
            } else if (before != null) {
                result.add(new ProjectPatchRequest.ProjectPatchFile(relative, null, baselineHash, "delete"));
            }
        }
        result.sort(Comparator.comparing(ProjectPatchRequest.ProjectPatchFile::path, String.CASE_INSENSITIVE_ORDER));
        return result;
    }

    public CommandResult runBuild(Workspace ws, String cwd, boolean allowed, AgentRunService.AgentRun run) throws Exception {
        requireCommands(allowed);
        Path dir = workingDirectory(ws, cwd);
        run.checkCancelled();
        if (Files.exists(dir.resolve("pom.xml"))) return runMaven(ws, dir, List.of("-q", "-DskipTests", "package"), Duration.ofMinutes(6), run);
        if (Files.exists(dir.resolve("build.gradle")) || Files.exists(dir.resolve("build.gradle.kts"))) return runGradle(ws, dir, List.of("build", "-x", "test"), Duration.ofMinutes(6), run);
        if (Files.exists(dir.resolve("package.json"))) return runNodeScript(ws, dir, "build", Duration.ofMinutes(6), run);
        if (Files.exists(dir.resolve("go.mod"))) return run(ws, dir, List.of("go", "build", "./..."), Duration.ofMinutes(6), run);
        if (Files.exists(dir.resolve("Cargo.toml"))) return run(ws, dir, List.of("cargo", "build"), Duration.ofMinutes(8), run);
        if (hasRootSuffix(dir, ".sln") || hasRootSuffix(dir, ".csproj")) return run(ws, dir, List.of("dotnet", "build"), Duration.ofMinutes(8), run);
        if (Files.exists(dir.resolve("CMakeLists.txt"))) {
            Path buildDir = dir.resolve(".agent-build");
            CommandResult configure = run(ws, dir, List.of("cmake", "-S", ".", "-B", buildDir.toString()), Duration.ofMinutes(5), run);
            if (configure.exitCode() != 0) return configure;
            CommandResult build = run(ws, dir, List.of("cmake", "--build", buildDir.toString()), Duration.ofMinutes(8), run);
            return combine(configure, build);
        }
        if (Files.exists(dir.resolve("Makefile")) || Files.exists(dir.resolve("makefile"))) return run(ws, dir, List.of("make"), Duration.ofMinutes(8), run);
        if (Files.exists(dir.resolve("build.xml"))) return run(ws, dir, List.of("ant"), Duration.ofMinutes(8), run);
        if (Files.exists(dir.resolve("Package.swift"))) return run(ws, dir, List.of("swift", "build"), Duration.ofMinutes(8), run);
        if (Files.exists(dir.resolve("pubspec.yaml"))) {
            CommandResult flutter = run(ws, dir, List.of("flutter", "analyze"), Duration.ofMinutes(8), run);
            if (!commandMissing(flutter)) return flutter;
            return run(ws, dir, List.of("dart", "analyze"), Duration.ofMinutes(6), run);
        }
        if (Files.exists(dir.resolve("WORKSPACE")) || Files.exists(dir.resolve("WORKSPACE.bazel")) || Files.exists(dir.resolve("MODULE.bazel"))) {
            return run(ws, dir, List.of("bazel", "build", "//..."), Duration.ofMinutes(10), run);
        }
        if (Files.exists(dir.resolve("composer.json"))) return run(ws, dir, List.of("composer", "validate", "--no-check-publish"), Duration.ofMinutes(5), run);
        if (Files.exists(dir.resolve("Gemfile"))) return run(ws, dir, List.of("bundle", "exec", "rake"), Duration.ofMinutes(6), run);
        if (Files.exists(dir.resolve("build.sbt"))) return run(ws, dir, List.of("sbt", "compile"), Duration.ofMinutes(10), run);
        if (Files.exists(dir.resolve("mix.exs"))) return run(ws, dir, List.of("mix", "compile"), Duration.ofMinutes(8), run);
        if (Files.exists(dir.resolve("project.clj"))) return run(ws, dir, List.of("lein", "check"), Duration.ofMinutes(8), run);
        if (Files.exists(dir.resolve("build.zig"))) return run(ws, dir, List.of("zig", "build"), Duration.ofMinutes(8), run);
        if (Files.exists(dir.resolve("stack.yaml"))) return run(ws, dir, List.of("stack", "build"), Duration.ofMinutes(10), run);
        if (Files.exists(dir.resolve("cabal.project")) || hasRootSuffix(dir, ".cabal")) return run(ws, dir, List.of("cabal", "build", "all"), Duration.ofMinutes(10), run);
        if (Files.exists(dir.resolve("pyproject.toml")) || Files.exists(dir.resolve("setup.py")) || Files.exists(dir.resolve("requirements.txt"))) {
            CommandResult system = run(ws, dir, List.of("python", "-m", "compileall", "."), Duration.ofMinutes(5), run);
            if (!commandMissing(system)) return system;
            return run(ws, dir, List.of("python3", "-m", "compileall", "."), Duration.ofMinutes(5), run);
        }
        return new CommandResult(-1, "No supported build descriptor found in " + displayCwd(ws, dir) + ". Use inspect_workspace and run_build with cwd for monorepos, or an approved run_command for a custom toolchain.", Duration.ZERO);
    }

    public CommandResult runTests(Workspace ws, String cwd, boolean allowed, AgentRunService.AgentRun run) throws Exception {
        requireCommands(allowed);
        Path dir = workingDirectory(ws, cwd);
        run.checkCancelled();
        if (Files.exists(dir.resolve("pom.xml"))) return runMaven(ws, dir, List.of("-q", "test"), Duration.ofMinutes(8), run);
        if (Files.exists(dir.resolve("build.gradle")) || Files.exists(dir.resolve("build.gradle.kts"))) return runGradle(ws, dir, List.of("test"), Duration.ofMinutes(8), run);
        if (Files.exists(dir.resolve("package.json"))) return runNodeScript(ws, dir, "test", Duration.ofMinutes(8), run);
        if (Files.exists(dir.resolve("go.mod"))) return run(ws, dir, List.of("go", "test", "./..."), Duration.ofMinutes(8), run);
        if (Files.exists(dir.resolve("Cargo.toml"))) return run(ws, dir, List.of("cargo", "test"), Duration.ofMinutes(10), run);
        if (hasRootSuffix(dir, ".sln") || hasRootSuffix(dir, ".csproj")) return run(ws, dir, List.of("dotnet", "test"), Duration.ofMinutes(10), run);
        if (Files.exists(dir.resolve("pyproject.toml")) || Files.exists(dir.resolve("pytest.ini")) || Files.exists(dir.resolve("tests"))) {
            CommandResult direct = run(ws, dir, List.of("pytest", "-q"), Duration.ofMinutes(8), run);
            if (!commandMissing(direct)) return direct;
            CommandResult system = run(ws, dir, List.of("python", "-m", "pytest", "-q"), Duration.ofMinutes(8), run);
            if (!commandMissing(system)) return system;
            return run(ws, dir, List.of("python3", "-m", "pytest", "-q"), Duration.ofMinutes(8), run);
        }
        if (Files.exists(dir.resolve("CMakeLists.txt"))) {
            Path buildDir = dir.resolve(".agent-build");
            if (!Files.isDirectory(buildDir)) {
                CommandResult configure = run(ws, dir, List.of("cmake", "-S", ".", "-B", buildDir.toString()), Duration.ofMinutes(5), run);
                if (configure.exitCode() != 0) return configure;
            }
            return run(ws, dir, List.of("ctest", "--test-dir", buildDir.toString(), "--output-on-failure"), Duration.ofMinutes(8), run);
        }
        if (Files.exists(dir.resolve("Makefile")) || Files.exists(dir.resolve("makefile"))) return run(ws, dir, List.of("make", "test"), Duration.ofMinutes(8), run);
        if (Files.exists(dir.resolve("build.xml"))) return run(ws, dir, List.of("ant", "test"), Duration.ofMinutes(8), run);
        if (Files.exists(dir.resolve("Package.swift"))) return run(ws, dir, List.of("swift", "test"), Duration.ofMinutes(10), run);
        if (Files.exists(dir.resolve("pubspec.yaml"))) {
            CommandResult flutter = run(ws, dir, List.of("flutter", "test"), Duration.ofMinutes(10), run);
            if (!commandMissing(flutter)) return flutter;
            return run(ws, dir, List.of("dart", "test"), Duration.ofMinutes(8), run);
        }
        if (Files.exists(dir.resolve("WORKSPACE")) || Files.exists(dir.resolve("WORKSPACE.bazel")) || Files.exists(dir.resolve("MODULE.bazel"))) {
            return run(ws, dir, List.of("bazel", "test", "//..."), Duration.ofMinutes(12), run);
        }
        if (Files.exists(dir.resolve("Gemfile"))) return run(ws, dir, List.of("bundle", "exec", "rake", "test"), Duration.ofMinutes(8), run);
        if (Files.exists(dir.resolve("build.sbt"))) return run(ws, dir, List.of("sbt", "test"), Duration.ofMinutes(12), run);
        if (Files.exists(dir.resolve("mix.exs"))) return run(ws, dir, List.of("mix", "test"), Duration.ofMinutes(10), run);
        if (Files.exists(dir.resolve("project.clj"))) return run(ws, dir, List.of("lein", "test"), Duration.ofMinutes(10), run);
        if (Files.exists(dir.resolve("build.zig"))) return run(ws, dir, List.of("zig", "build", "test"), Duration.ofMinutes(10), run);
        if (Files.exists(dir.resolve("stack.yaml"))) return run(ws, dir, List.of("stack", "test"), Duration.ofMinutes(12), run);
        if (Files.exists(dir.resolve("cabal.project")) || hasRootSuffix(dir, ".cabal")) return run(ws, dir, List.of("cabal", "test", "all"), Duration.ofMinutes(12), run);
        return new CommandResult(-1, "No supported test runner detected in " + displayCwd(ws, dir) + ". Use inspect_workspace and run_tests with cwd for monorepos, or an approved run_command for a custom test tool.", Duration.ZERO);
    }

    public CommandResult runCheck(Workspace ws, String cwd, boolean allowed, AgentRunService.AgentRun run) throws Exception {
        requireCommands(allowed);
        Path dir = workingDirectory(ws, cwd);
        run.checkCancelled();
        if (Files.exists(dir.resolve("package.json"))) {
            for (String script : List.of("lint", "check", "typecheck")) {
                if (packageScriptExists(dir, script)) return runNodeScript(ws, dir, script, Duration.ofMinutes(6), run);
            }
            return new CommandResult(-1, "package.json defines no lint/check/typecheck script in " + displayCwd(ws, dir) + ".", Duration.ZERO);
        }
        if (Files.exists(dir.resolve("pom.xml"))) return runMaven(ws, dir, List.of("-q", "-DskipTests", "verify"), Duration.ofMinutes(8), run);
        if (Files.exists(dir.resolve("build.gradle")) || Files.exists(dir.resolve("build.gradle.kts"))) return runGradle(ws, dir, List.of("check"), Duration.ofMinutes(8), run);
        if (Files.exists(dir.resolve("pyproject.toml")) || Files.exists(dir.resolve("setup.py")) || Files.exists(dir.resolve("requirements.txt"))) {
            CommandResult system = run(ws, dir, List.of("python", "-m", "compileall", "."), Duration.ofMinutes(5), run);
            if (!commandMissing(system)) return system;
            return run(ws, dir, List.of("python3", "-m", "compileall", "."), Duration.ofMinutes(5), run);
        }
        if (Files.exists(dir.resolve("pubspec.yaml"))) {
            CommandResult flutter = run(ws, dir, List.of("flutter", "analyze"), Duration.ofMinutes(8), run);
            if (!commandMissing(flutter)) return flutter;
            return run(ws, dir, List.of("dart", "analyze"), Duration.ofMinutes(6), run);
        }
        if (containsTerraform(dir)) {
            CommandResult terraform = run(ws, dir, List.of("terraform", "fmt", "-check", "-recursive"), Duration.ofMinutes(5), run);
            if (!commandMissing(terraform)) return terraform;
            return run(ws, dir, List.of("tofu", "fmt", "-check", "-recursive"), Duration.ofMinutes(5), run);
        }
        if (Files.exists(dir.resolve("composer.json"))) return run(ws, dir, List.of("composer", "validate", "--no-check-publish"), Duration.ofMinutes(5), run);
        return new CommandResult(-1, "No generic check/lint command detected in " + displayCwd(ws, dir) + ".", Duration.ZERO);
    }

    public CommandResult runCommand(Workspace ws, String command, String cwd, boolean allowed, Set<String> extraCommands,
                                    AgentRunService.AgentRun run) throws Exception {
        requireCommands(allowed);
        if (command == null || command.isBlank()) throw new IllegalArgumentException("run_command requires command");
        if (command.contains("\n") || command.contains("\r") || command.matches(".*[;&|><`].*")) {
            throw new SecurityException("Shell operators, redirects and command chaining are not allowed");
        }
        if (command.contains("http://") || command.contains("https://")) {
            throw new SecurityException("Network URLs are not accepted by run_command. Use project-local commands only.");
        }
        List<String> parts = splitCommand(command);
        if (parts.isEmpty()) throw new IllegalArgumentException("Command is empty");
        String executable = normalizeExecutable(parts.get(0));
        if ("git".equals(executable) || "git.exe".equals(executable)) {
            throw new SecurityException("Git operations are out of scope for this local workspace agent");
        }
        Set<String> allowedCommands = new HashSet<>(BASE_COMMAND_ALLOWLIST);
        if (extraCommands != null) allowedCommands.addAll(extraCommands.stream().map(String::toLowerCase).toList());
        if (!allowedCommands.contains(executable)) throw new SecurityException("Command is not allowlisted: " + parts.get(0));
        rejectEscapingArguments(parts);
        validateCommandSpecific(executable, parts);
        Path dir = workingDirectory(ws, cwd);
        return run(ws, dir, parts, Duration.ofMinutes(6), run);
    }

    private CommandResult runMaven(Workspace ws, Path dir, List<String> args, Duration timeout, AgentRunService.AgentRun run) throws Exception {
        Path wrapper = findWrapper(dir, ws.root, isWindows() ? "mvnw.cmd" : "mvnw");
        if (wrapper != null) {
            String executable = isWindows() ? wrapper.toString() : wrapper.toString();
            if (!isWindows()) makeExecutable(wrapper);
            List<String> command = new ArrayList<>();
            command.add(executable);
            command.addAll(args);
            CommandResult result = run(ws, dir, command, timeout, run);
            if (!commandMissing(result)) return result;
        }
        List<String> command = new ArrayList<>();
        command.add("mvn");
        command.addAll(args);
        return run(ws, dir, command, timeout, run);
    }

    private CommandResult runGradle(Workspace ws, Path dir, List<String> args, Duration timeout, AgentRunService.AgentRun run) throws Exception {
        Path wrapper = findWrapper(dir, ws.root, isWindows() ? "gradlew.bat" : "gradlew");
        if (wrapper != null) {
            if (!isWindows()) makeExecutable(wrapper);
            List<String> command = new ArrayList<>();
            command.add(wrapper.toString());
            command.addAll(args);
            CommandResult result = run(ws, dir, command, timeout, run);
            if (!commandMissing(result)) return result;
        }
        List<String> command = new ArrayList<>();
        command.add("gradle");
        command.addAll(args);
        return run(ws, dir, command, timeout, run);
    }

    private CommandResult runNodeScript(Workspace ws, Path dir, String script, Duration timeout, AgentRunService.AgentRun run) throws Exception {
        if (!packageScriptExists(dir, script)) {
            return new CommandResult(-1, "package.json does not define a '" + script + "' script in " + displayCwd(ws, dir) + ".", Duration.ZERO);
        }
        List<String> command;
        if (Files.exists(dir.resolve("pnpm-lock.yaml"))) command = List.of("pnpm", "run", script);
        else if (Files.exists(dir.resolve("yarn.lock"))) command = List.of("yarn", "run", script);
        else if (Files.exists(dir.resolve("bun.lockb")) || Files.exists(dir.resolve("bun.lock"))) command = List.of("bun", "run", script);
        else command = List.of("npm", "run", script);
        return run(ws, dir, command, timeout, run);
    }

    private boolean packageScriptExists(Path dir, String script) {
        Path packageJson = dir.resolve("package.json");
        if (!Files.isRegularFile(packageJson)) return false;
        try {
            JsonNode root = objectMapper.readTree(Files.readString(packageJson, StandardCharsets.UTF_8));
            JsonNode scripts = root.path("scripts");
            return scripts.isObject() && scripts.has(script) && !scripts.path(script).asText("").isBlank();
        } catch (Exception ignored) {
            return false;
        }
    }

    private CommandResult combine(CommandResult first, CommandResult second) {
        return new CommandResult(second.exitCode(), first.output() + "\n\n" + second.output(), first.elapsed().plus(second.elapsed()));
    }

    private CommandResult run(Workspace ws, Path workingDir, List<String> command, Duration timeout,
                              AgentRunService.AgentRun run) throws Exception {
        run.checkCancelled();
        Map<String,String> beforeFiles = snapshotTrackedHashes(ws);
        List<String> effective = new ArrayList<>(command);
        Path log = Files.createTempFile(ws.root, ".agent-command-", ".log");
        ProcessBuilder builder;
        String first = effective.get(0);
        if (isWindows() && (first.toLowerCase(Locale.ROOT).endsWith(".cmd") || first.toLowerCase(Locale.ROOT).endsWith(".bat") ||
                Set.of("mvn", "gradle", "npm", "npx", "pnpm", "yarn", "bun").contains(first.toLowerCase(Locale.ROOT)))) {
            List<String> cmd = new ArrayList<>();
            cmd.add("cmd.exe");
            cmd.add("/d");
            cmd.add("/c");
            cmd.addAll(effective);
            builder = new ProcessBuilder(cmd);
        } else {
            builder = new ProcessBuilder(effective);
        }
        builder.directory(workingDir.toFile());
        builder.redirectErrorStream(true);
        builder.redirectOutput(log.toFile());
        Path agentHome = ws.root.resolve(".agent-home");
        Files.createDirectories(agentHome);
        sanitizeEnvironment(builder.environment(), ws.root, agentHome);

        long start = System.nanoTime();
        Process process;
        try {
            process = builder.start();
        } catch (IOException e) {
            Files.deleteIfExists(log);
            return new CommandResult(127, "Unable to start command: " + String.join(" ", command) + "\n" + e.getMessage(), Duration.ZERO);
        }

        run.registerProcess(process);
        boolean completed = false;
        long deadline = System.nanoTime() + timeout.toNanos();
        try {
            while (System.nanoTime() < deadline) {
                run.checkCancelled();
                if (process.waitFor(250, TimeUnit.MILLISECONDS)) {
                    completed = true;
                    break;
                }
            }
            run.checkCancelled();
            if (!completed) {
                terminateProcess(process);
                process.waitFor(5, TimeUnit.SECONDS);
            }
        } finally {
            run.unregisterProcess(process);
        }

        int exit = completed ? process.exitValue() : 124;
        String output;
        try { output = Files.readString(log, StandardCharsets.UTF_8); }
        catch (Exception e) { output = "[Command output unavailable: " + e.getMessage() + "]"; }
        Files.deleteIfExists(log);
        if (markExternalChanges(ws, beforeFiles)) run.markMutation();
        Duration elapsed = Duration.ofNanos(System.nanoTime() - start);
        String shown = "$ " + String.join(" ", command) + "\n" + (completed ? "" : "[Timed out after " + timeout.toSeconds() + "s]\n") + output;
        return new CommandResult(exit, clip(shown), elapsed);
    }

    private void sanitizeEnvironment(Map<String,String> env, Path root, Path agentHome) {
        env.keySet().removeIf(key -> key.matches("(?i).*(TOKEN|SECRET|PASSWORD|PASSWD|API[_-]?KEY|PRIVATE[_-]?KEY|CLIENT[_-]?SECRET|SESSION[_-]?TOKEN).*") ||
                key.matches("(?i)^(AWS_PROFILE|AWS_ACCESS_KEY_ID|AWS_SECRET_ACCESS_KEY|AZURE_CLIENT_SECRET|GITHUB_TOKEN|GITLAB_TOKEN)$"));
        env.put("AGENT_WORKSPACE", root.toString());
        env.put("HOME", agentHome.toString());
        env.put("USERPROFILE", agentHome.toString());
        env.put("GIT_TERMINAL_PROMPT", "0");
        env.put("GIT_CONFIG_NOSYSTEM", "1");
        env.put("AWS_EC2_METADATA_DISABLED", "true");
        env.put("PIP_DISABLE_PIP_VERSION_CHECK", "1");
        env.put("NPM_CONFIG_UPDATE_NOTIFIER", "false");
        env.put("CI", "true");
    }

    private void terminateProcess(Process process) {
        if (process == null || !process.isAlive()) return;
        try { process.descendants().forEach(handle -> { try { handle.destroy(); } catch (Exception ignored) { } }); }
        catch (Exception ignored) { }
        try { process.destroy(); } catch (Exception ignored) { }
        if (process.isAlive()) {
            try { process.descendants().forEach(handle -> { try { handle.destroyForcibly(); } catch (Exception ignored) { } }); }
            catch (Exception ignored) { }
            try { process.destroyForcibly(); } catch (Exception ignored) { }
        }
    }

    public VerificationAdvice verificationAdvice(Workspace ws) throws IOException {
        List<ProjectPatchRequest.ProjectPatchFile> actualChanges = changes(ws);
        if (actualChanges.isEmpty()) return new VerificationAdvice(false, "No staged file changes");
        List<String> codeChanges = actualChanges.stream().map(ProjectPatchRequest.ProjectPatchFile::path).filter(this::isCodeLike).toList();
        if (codeChanges.isEmpty()) return new VerificationAdvice(false, "Only documentation/data/non-code text changes detected");
        for (String changed : codeChanges) {
            Path candidate = resolve(ws.root, changed).getParent();
            while (candidate != null && candidate.startsWith(ws.root)) {
                if (directoryHasVerifier(candidate)) {
                    return new VerificationAdvice(true, "Code/config changes have a detectable project verifier near " + displayCwd(ws, candidate));
                }
                if (candidate.equals(ws.root)) break;
                candidate = candidate.getParent();
            }
        }
        return new VerificationAdvice(false, "Code changed but no runnable built-in verifier was detected near the changed files; use an approved run_command if the project has a custom verifier");
    }

    private boolean directoryHasVerifier(Path dir) throws IOException {
        if (Files.exists(dir.resolve("pom.xml")) || Files.exists(dir.resolve("build.gradle")) || Files.exists(dir.resolve("build.gradle.kts")) ||
                Files.exists(dir.resolve("go.mod")) || Files.exists(dir.resolve("Cargo.toml")) || Files.exists(dir.resolve("CMakeLists.txt")) ||
                Files.exists(dir.resolve("Makefile")) || Files.exists(dir.resolve("makefile")) || Files.exists(dir.resolve("build.xml")) ||
                Files.exists(dir.resolve("Package.swift")) || Files.exists(dir.resolve("pubspec.yaml")) || Files.exists(dir.resolve("WORKSPACE")) ||
                Files.exists(dir.resolve("WORKSPACE.bazel")) || Files.exists(dir.resolve("MODULE.bazel")) || Files.exists(dir.resolve("composer.json")) ||
                Files.exists(dir.resolve("Gemfile")) || Files.exists(dir.resolve("build.sbt")) || Files.exists(dir.resolve("mix.exs")) ||
                Files.exists(dir.resolve("project.clj")) || Files.exists(dir.resolve("build.zig")) || Files.exists(dir.resolve("stack.yaml")) ||
                Files.exists(dir.resolve("cabal.project")) || Files.exists(dir.resolve("pyproject.toml")) || Files.exists(dir.resolve("setup.py")) ||
                Files.exists(dir.resolve("requirements.txt")) || hasRootSuffix(dir, ".sln") || hasRootSuffix(dir, ".csproj") ||
                hasRootSuffix(dir, ".fsproj") || hasRootSuffix(dir, ".vbproj") || hasRootSuffix(dir, ".cabal") || containsTerraform(dir)) return true;
        return Files.exists(dir.resolve("package.json")) &&
                (packageScriptExists(dir, "build") || packageScriptExists(dir, "test") || packageScriptExists(dir, "lint") || packageScriptExists(dir, "check") || packageScriptExists(dir, "typecheck"));
    }

    public void cleanup(Workspace ws) {
        if (ws == null) return;
        try (Stream<Path> stream = Files.walk(ws.root)) {
            stream.sorted(Comparator.reverseOrder()).forEach(path -> {
                try { Files.deleteIfExists(path); } catch (Exception ignored) { }
            });
        } catch (Exception ignored) { }
    }

    private Path workingDirectory(Workspace ws, String rawCwd) {
        if (rawCwd == null || rawCwd.isBlank() || ".".equals(rawCwd.trim())) return ws.root;
        String relative = normalizeRelative(rawCwd);
        Path dir = resolve(ws.root, relative);
        if (!Files.exists(dir) || !Files.isDirectory(dir)) throw new IllegalArgumentException("cwd is not a directory in the workspace: " + relative);
        return dir;
    }

    private String displayCwd(Workspace ws, Path dir) {
        if (dir.equals(ws.root)) return ".";
        return ws.root.relativize(dir).toString().replace('\\','/');
    }

    private Path findWrapper(Path start, Path root, String name) {
        Path current = start;
        while (current != null && current.startsWith(root)) {
            Path candidate = current.resolve(name);
            if (Files.isRegularFile(candidate)) return candidate;
            if (current.equals(root)) break;
            current = current.getParent();
        }
        return null;
    }

    private boolean hasRootSuffix(Path root, String suffix) throws IOException {
        try (Stream<Path> stream = Files.list(root)) {
            String low = suffix.toLowerCase(Locale.ROOT);
            return stream.filter(Files::isRegularFile)
                    .anyMatch(path -> path.getFileName().toString().toLowerCase(Locale.ROOT).endsWith(low));
        }
    }

    private boolean containsTerraform(Path dir) throws IOException {
        try (Stream<Path> stream = Files.list(dir)) {
            return stream.filter(Files::isRegularFile).anyMatch(path -> path.getFileName().toString().toLowerCase(Locale.ROOT).endsWith(".tf"));
        }
    }

    private Map<String,String> snapshotTrackedHashes(Workspace ws) throws IOException {
        Map<String,String> hashes = new LinkedHashMap<>();
        for (String relative : allPaths(ws)) {
            if (!isReadableTextPath(relative) && !ws.touched.contains(relative)) continue;
            Path file = resolve(ws.root, relative);
            try {
                if (Files.size(file) > MAX_WRITE_CHARS * 4L) continue;
                hashes.put(relative, Hashing.sha256(Files.readString(file, StandardCharsets.UTF_8)));
            } catch (Exception ignored) { }
        }
        return hashes;
    }

    private boolean markExternalChanges(Workspace ws, Map<String,String> before) throws IOException {
        Map<String,String> after = snapshotTrackedHashes(ws);
        LinkedHashSet<String> candidates = new LinkedHashSet<>();
        candidates.addAll(before.keySet());
        candidates.addAll(after.keySet());
        boolean changed = false;
        for (String relative : candidates) {
            if (Objects.equals(before.get(relative), after.get(relative))) continue;
            // Commands may create, modify or delete files. Preserve the original state before
            // marking the path touched so both creations and deletions are represented correctly.
            if (!before.containsKey(relative) && after.containsKey(relative)) {
                ws.baseline.putIfAbsent(relative, null);
                ws.baselineHashes.putIfAbsent(relative, Hashing.ABSENT);
            } else {
                captureBaseline(ws, relative);
            }
            ws.touched.add(relative);
            changed = true;
        }
        return changed;
    }

    private void validateCommandSpecific(String executable, List<String> parts) {
        if (Set.of("terraform", "tofu").contains(executable)) {
            if (parts.size() < 2 || !Set.of("fmt", "validate", "version", "providers").contains(parts.get(1).toLowerCase(Locale.ROOT))) {
                throw new SecurityException("run_command permits only non-deploying Terraform/OpenTofu commands: fmt, validate, version, providers");
            }
        }
        if (Set.of("npm", "npm.cmd", "pnpm", "pnpm.cmd", "yarn", "yarn.cmd", "bun", "bun.exe").contains(executable)) {
            String joined = String.join(" ", parts).toLowerCase(Locale.ROOT);
            if (joined.matches(".*\\b(publish|login|logout)\\b.*")) throw new SecurityException("Package publishing/login commands are not allowed from the agent");
        }
        if ("cargo".equals(executable) && parts.size() > 1 && Set.of("publish", "login", "owner", "yank").contains(parts.get(1).toLowerCase(Locale.ROOT))) {
            throw new SecurityException("Cargo registry mutation commands are not allowed from the agent");
        }
        if ("dotnet".equals(executable) && parts.size() > 2 && "nuget".equalsIgnoreCase(parts.get(1)) && "push".equalsIgnoreCase(parts.get(2))) {
            throw new SecurityException("NuGet publishing is not allowed from the agent");
        }
        if (Set.of("php", "ruby", "swift", "julia").contains(executable)) {
            if (parts.stream().skip(1).anyMatch(arg -> Set.of("-r", "-e", "--eval").contains(arg.toLowerCase(Locale.ROOT)))) {
                throw new SecurityException("Inline interpreter evaluation is not allowed from run_command");
            }
        }
        if ("deno".equals(executable) && parts.size() > 1 && "eval".equalsIgnoreCase(parts.get(1))) {
            throw new SecurityException("deno eval is not allowed from run_command");
        }
    }

    private boolean commandMissing(CommandResult result) {
        if (result == null) return true;
        if (result.exitCode() == 127 || result.exitCode() == 9009) return true;
        String text = result.output() == null ? "" : result.output().toLowerCase(Locale.ROOT);
        return text.contains("not recognized as an internal or external command") || text.contains("command not found") || text.contains("unable to start command") || text.contains("no such file or directory");
    }

    private void requireCommands(boolean allowed) {
        if (!allowed) throw new SecurityException("Agent command execution is disabled by permissions");
    }

    private List<String> splitCommand(String command) {
        List<String> result = new ArrayList<>();
        Matcher matcher = TOKEN_PATTERN.matcher(command.trim());
        while (matcher.find()) {
            String token = matcher.group(1) != null ? matcher.group(1) : matcher.group(2) != null ? matcher.group(2) : matcher.group(3);
            if (token != null && !token.isBlank()) result.add(token);
        }
        return result;
    }

    private String normalizeExecutable(String raw) {
        String value = raw.replace('\\','/');
        int slash = value.lastIndexOf('/');
        if (slash >= 0) value = value.substring(slash + 1);
        return value.toLowerCase(Locale.ROOT);
    }

    private void rejectEscapingArguments(List<String> parts) {
        for (int i = 1; i < parts.size(); i++) {
            String arg = parts.get(i);
            String normalized = arg.replace('\\','/');
            if (normalized.equals("..") || normalized.startsWith("../") || normalized.contains("/../") || normalized.endsWith("/..")) {
                throw new SecurityException("Command argument may not escape the workspace: " + arg);
            }
            try {
                if (!arg.startsWith("-") && Path.of(arg).isAbsolute()) throw new SecurityException("Absolute paths are not allowed in run_command: " + arg);
            } catch (InvalidPathException ignored) { }
        }
    }


    private List<String> allPaths(Workspace ws) throws IOException {
        try (Stream<Path> stream = Files.walk(ws.root)) {
            return stream.filter(Files::isRegularFile)
                    .filter(path -> !Files.isSymbolicLink(path))
                    .map(ws.root::relativize)
                    .map(Path::toString)
                    .map(p -> p.replace('\\','/'))
                    .filter(p -> !isSkippedPath(p))
                    .sorted(String.CASE_INSENSITIVE_ORDER)
                    .toList();
        }
    }

    private List<String> textPaths(Workspace ws) throws IOException {
        return allPaths(ws).stream().filter(p -> isReadableTextPath(p) || ws.touched.contains(p)).toList();
    }

    private boolean isReadableTextPath(String relative) {
        return projects.eligibleTextPath(relative);
    }

    private boolean isSkippedPath(String relative) {
        for (String part : relative.split("/")) if (SKIP_DIRS.contains(part.toLowerCase(Locale.ROOT))) return true;
        return false;
    }

    private boolean isDescriptor(String path) {
        String name = Path.of(path).getFileName().toString().toLowerCase(Locale.ROOT);
        return Set.of("pom.xml", "build.gradle", "build.gradle.kts", "package.json", "pyproject.toml", "setup.py", "requirements.txt",
                        "go.mod", "cargo.toml", "cmakelists.txt", "makefile", "build.xml", "composer.json", "gemfile", "package.swift", "pubspec.yaml",
                        "workspace", "workspace.bazel", "module.bazel", "build.sbt", "mix.exs", "project.clj", "build.zig", "stack.yaml", "cabal.project").contains(name)
                || name.endsWith(".sln") || name.endsWith(".csproj") || name.endsWith(".fsproj") || name.endsWith(".vbproj") || name.endsWith(".tf") || name.endsWith(".cabal");
    }

    private String descriptorKind(String path) {
        String name = Path.of(path).getFileName().toString().toLowerCase(Locale.ROOT);
        if (name.equals("pom.xml")) return "Maven/Java";
        if (name.startsWith("build.gradle")) return "Gradle/JVM";
        if (name.equals("package.json")) return "Node/JavaScript/TypeScript";
        if (Set.of("pyproject.toml", "setup.py", "requirements.txt").contains(name)) return "Python";
        if (name.equals("go.mod")) return "Go";
        if (name.equals("cargo.toml")) return "Rust/Cargo";
        if (name.endsWith(".sln") || name.endsWith(".csproj") || name.endsWith(".fsproj") || name.endsWith(".vbproj")) return ".NET";
        if (name.equals("cmakelists.txt")) return "CMake/C/C++";
        if (name.equals("makefile")) return "Make";
        if (name.equals("build.xml")) return "Ant/Java";
        if (name.equals("composer.json")) return "PHP/Composer";
        if (name.equals("gemfile")) return "Ruby/Bundler";
        if (name.equals("package.swift")) return "Swift Package Manager";
        if (name.equals("pubspec.yaml")) return "Dart/Flutter";
        if (Set.of("workspace", "workspace.bazel", "module.bazel").contains(name)) return "Bazel";
        if (name.equals("build.sbt")) return "Scala/sbt";
        if (name.equals("mix.exs")) return "Elixir/Mix";
        if (name.equals("project.clj")) return "Clojure/Leiningen";
        if (name.equals("build.zig")) return "Zig";
        if (name.equals("stack.yaml") || name.equals("cabal.project") || name.endsWith(".cabal")) return "Haskell";
        if (name.endsWith(".tf")) return "Terraform/OpenTofu configuration";
        return "project descriptor";
    }

    private boolean isCodeLike(String path) {
        String name = Path.of(path).getFileName().toString().toLowerCase(Locale.ROOT);
        if (isDescriptor(path)) return true;
        int dot = name.lastIndexOf('.');
        return dot >= 0 && CODE_EXTENSIONS.contains(name.substring(dot + 1));
    }

    private String normalizeRelative(String raw) {
        if (raw == null || raw.isBlank()) throw new IllegalArgumentException("Project path is required");
        String p = raw.replace('\\','/').replaceAll("^/+", "");
        while (p.contains("//")) p = p.replace("//", "/");
        if (p.isBlank() || p.equals(".") || p.startsWith("../") || p.contains("/../") || p.endsWith("/..") || p.contains("\u0000")) {
            throw new SecurityException("Invalid project path: " + raw);
        }
        if (p.length() > 1200) throw new IllegalArgumentException("Project path is too long");
        return p;
    }

    private Path resolve(Path root, String relative) {
        Path result = root.resolve(relative).normalize();
        if (!result.startsWith(root)) throw new SecurityException("Path escapes the isolated project workspace: " + relative);
        return result;
    }

    private boolean isWindows() {
        return System.getProperty("os.name", "").toLowerCase(Locale.ROOT).contains("win");
    }

    private boolean isWrapper(String path) {
        String low = path.toLowerCase(Locale.ROOT);
        return low.endsWith("mvnw") || low.endsWith("gradlew") || low.endsWith("mvnw.cmd") || low.endsWith("gradlew.bat");
    }

    private void makeWrappersExecutable(Path root) {
        for (String name : List.of("mvnw", "gradlew")) {
            Path path = root.resolve(name);
            if (Files.exists(path)) makeExecutable(path);
        }
    }

    private void makeExecutable(Path path) {
        try {
            Set<PosixFilePermission> perms = Files.getPosixFilePermissions(path);
            perms.add(PosixFilePermission.OWNER_EXECUTE);
            Files.setPosixFilePermissions(path, perms);
        } catch (Exception ignored) {
            try { path.toFile().setExecutable(true, true); } catch (Exception ignoredAgain) { }
        }
    }

    private String clip(String text) {
        if (text == null) return "";
        if (text.length() <= MAX_TOOL_OUTPUT) return text;
        int head = MAX_TOOL_OUTPUT * 2 / 3;
        int tail = MAX_TOOL_OUTPUT - head - 80;
        return text.substring(0, head) + "\n... [tool output clipped] ...\n" + text.substring(Math.max(head, text.length() - tail));
    }

    public static final class Workspace {
        private final String projectId;
        private final Path root;
        private final Map<String,String> baseline;
        private final Map<String,String> baselineHashes;
        private final LinkedHashSet<String> touched = new LinkedHashSet<>();
        private final boolean localMirror;
        private final boolean scratch;

        private Workspace(String projectId, Path root, Map<String,String> baseline, Map<String,String> baselineHashes,
                          boolean localMirror, boolean scratch) {
            this.projectId = projectId;
            this.root = root;
            this.baseline = baseline;
            this.baselineHashes = baselineHashes;
            this.localMirror = localMirror;
            this.scratch = scratch;
        }

        public String projectId() { return projectId; }
        public Path root() { return root; }
        public boolean localMirror() { return localMirror; }
        public boolean scratch() { return scratch; }
    }

    public record CommandResult(int exitCode, String output, Duration elapsed) {
        public String asToolText() {
            return "exitCode=" + exitCode + "; elapsedMs=" + elapsed.toMillis() + "\n" + output;
        }
    }

    public record VerificationAdvice(boolean required, String reason) {}
}
