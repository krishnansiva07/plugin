package com.llmart.llm.service;

import org.springframework.stereotype.Service;

import java.time.Duration;
import java.time.Instant;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.*;

@Service
public class AgentApprovalService {
    private final Map<String, PendingApproval> pending = new ConcurrentHashMap<>();

    public Approval create(String runId, String tool, String detail) {
        String id = UUID.randomUUID().toString();
        PendingApproval item = new PendingApproval(new CompletableFuture<>(), Instant.now(), runId, tool, detail);
        pending.put(id, item);
        return new Approval(id, runId, tool, detail);
    }

    public boolean await(String id, Duration timeout, AgentRunService.AgentRun run) throws Exception {
        PendingApproval item = pending.get(id);
        if (item == null) throw new IllegalStateException("Approval request no longer exists");
        long deadline = System.nanoTime() + timeout.toNanos();
        try {
            while (System.nanoTime() < deadline) {
                run.checkCancelled();
                try {
                    return item.future().get(500, TimeUnit.MILLISECONDS);
                } catch (TimeoutException ignored) {
                    // Poll so cancellation can interrupt a pending approval promptly.
                }
            }
            throw new IllegalStateException("Approval timed out");
        } finally {
            pending.remove(id);
        }
    }

    public boolean await(String id, Duration timeout) throws Exception {
        PendingApproval item = pending.get(id);
        if (item == null) throw new IllegalStateException("Approval request no longer exists");
        try {
            return item.future().get(timeout.toMillis(), TimeUnit.MILLISECONDS);
        } catch (TimeoutException e) {
            throw new IllegalStateException("Approval timed out");
        } finally {
            pending.remove(id);
        }
    }

    public boolean resolve(String id, boolean approved) {
        PendingApproval item = pending.get(id);
        if (item == null) return false;
        return item.future().complete(approved);
    }

    public int cancelRun(String runId) {
        if (runId == null || runId.isBlank()) return 0;
        int count = 0;
        for (Map.Entry<String, PendingApproval> entry : pending.entrySet()) {
            PendingApproval item = entry.getValue();
            if (!runId.equals(item.runId())) continue;
            if (item.future().complete(false)) count++;
        }
        return count;
    }

    public record Approval(String id, String runId, String tool, String detail) {}
    private record PendingApproval(CompletableFuture<Boolean> future, Instant createdAt, String runId, String tool, String detail) {}
}
