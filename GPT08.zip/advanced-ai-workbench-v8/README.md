# Advanced AI Workbench Agent

A **Java 17 general-purpose AI workspace agent** with Chat, Analyze and Agent modes for application development, APIs, data/SQL, scripts, configuration, documentation, DevOps/IaC, code review, debugging and greenfield project creation. Dedicated test-case generation UI/prompts are intentionally not part of this build.

## Modes

- **Chat** — normal assistant experience with files, images, history, Markdown/code and downloadable artifacts.
- **Analyze** — deep read-only analysis of source, documents, screenshots, logs, JSON/CSV, SQL, requirements and mapped workspaces.
- **Agent** — iterative tool loop: plan → inspect/search/read → edit/create/copy/move/delete → build/test/check → diagnose → fix → workspace diff → review/apply.

Agent mode also works **without a mapped project**. In that case it receives an empty scratch workspace and can create a new project or set of files from the user's prompt; the result can be downloaded as a patch ZIP.

## Agent runtime

Each Agent request has a first-class `AgentRun` containing:

- run id and status
- cancellation state and active process ownership
- persistent plan items and statuses
- mutation revision
- last diff revision
- latest verification attempt/success state

The LLM chooses the next tool from actual observations. Java enforces completion guards so a normal `completed` response cannot bypass unfinished plan items, required diff review, or required verification of the current revision.

## Workspace tools

Planning/inspection:

`set_plan`, `update_plan`, `get_plan`, `inspect_workspace`, `list_project`, `glob_project`, `file_info`, `search_project`, `regex_search`, `read_file`, `read_file_range`, `read_files`

Mutation:

`edit_file`, `write_file`, `copy_file`, `move_file`, `delete_file`, `apply_patch`

Review/execution:

`changed_files`, `workspace_status`, `workspace_diff`, `run_build`, `run_tests`, `run_check`, `run_command`, `finish`

Agent transport is provider-compatible and resilient:

1. **Native OpenAI-compatible function/tool calling** is used first.
2. If the provider/model rejects native tools, the runtime automatically switches to **JSON response mode**.
3. If JSON response mode is also unsupported, the runtime uses a strict compatibility prompt plus automatic recovery.
4. A one-off prose response no longer terminates the run with a protocol error; the runtime retries and can bootstrap a safe workspace inspection.

The UI reports which transport is active in the Agent Console.

## Project and language coverage

Automatic build/test/check support covers common Maven/Gradle JVM projects, Node/npm/pnpm/yarn/Bun, Python/pytest, Go, Rust/Cargo, .NET, CMake, Make, Ant, Swift Package Manager, Dart/Flutter, PHP/Composer, Ruby/Rake, Bazel and Terraform-style checks. Monorepo tools accept a `cwd` so the agent can verify the relevant module instead of assuming the repository root is buildable.

The text workspace/index recognizes common Java, Kotlin, Groovy, Scala, JavaScript/TypeScript, Python, Ruby, PHP, Go, Rust, C/C++, C#/.NET, Swift, Dart, R, Lua, Perl, Elixir, Clojure, SQL, GraphQL, protobuf, HTML/CSS, config, Markdown/AsciiDoc, shell/PowerShell, Vue/Svelte, Terraform/HCL and Bazel files.

For niche toolchains, add trusted executable names under **Settings → Extra project commands**. Keep Shell permission on **Ask** unless you fully trust the project and command.

## Opening a workspace

### Local workspace path — recommended

Use **Open project → Local workspace path** and enter a trusted local folder, for example:

```text
C:\work\customer-portal
```

or:

```text
/home/me/customer-portal
```

The backend indexes the project and copies it into a temporary run mirror. Agent edits and command execution happen there first. The original project is modified only when you explicitly apply reviewed changes.

A mapped **local workspace remains active across actions, new chats and page reloads**. You do not need to enter the same path again. Use the workspace close button only when you intentionally want to disconnect it.

### Browser folder picker

The browser folder picker indexes supported text/source files without exposing an absolute path to Spring Boot. Read/analysis and staged edits work well; build/test fidelity may be lower because unindexed binary resources are not in the backend mirror.

## Safe review and apply

- File edit, shell/build/test/check, and workspace review permissions are independently **Allow / Ask / Deny**.
- Ask pauses the same run for Approve/Deny.
- Stop calls the backend cancellation endpoint and terminates an active build/test/command process.
- Agent patches include a baseline SHA-256 hash.
- Apply performs optimistic-concurrency checks before modifying the real workspace.
- If a real file changed after the agent captured it, Apply returns a conflict instead of overwriting it.
- Existing files are backed up under `.advanced-ai-chat-backup/<timestamp>/` before write/delete.
- Patch ZIPs preserve writes/deletes through the structured `_AGENT_PATCH_MANIFEST.json` manifest.
- Old hidden patch bodies are removed before previous assistant messages are reused as model context.
- A loop guard blocks repeated identical tool calls.

### Command isolation note

Commands run in a temporary workspace with secret-like environment variables removed, HOME/USERPROFILE redirected to an agent-local directory, shell chaining/redirection blocked and a command allowlist enforced. Git itself is not an agent operation.

This is **process hardening, not an OS security sandbox**. Project build scripts can execute arbitrary program logic. For untrusted repositories use an external Docker/Podman/VM/Windows Sandbox boundary and keep shell execution on Ask.

## Files, images and artifacts

Uploads support common Office documents, PDFs, images, JSON/CSV, source code and configuration files. DOCX text is extracted directly from WordprocessingML first, with Tika as fallback, and documents attached to the current message are prioritized in model context so requests such as “analyze this Word document” use the actual uploaded content. A separate vision model can analyze screenshots/images when the main model is text-only. Markdown tables can be exported to real `.xlsx` files for general spreadsheet output.

## Build and run

Requirements: **Java 17+ and Maven**.

```bash
mvn clean test
mvn clean package
java -jar target/advanced-ai-chat-1.6.0-SNAPSHOT.jar
```

Or use `run.bat` / `run.sh`.

Open:

```text
http://localhost:8090
```

The embedded server binds to `127.0.0.1` by default because this application can operate on user-selected local paths.

See `JAVA17_AGENT.md` for the runtime design and `VALIDATION_AGENT.md` for validation notes.
