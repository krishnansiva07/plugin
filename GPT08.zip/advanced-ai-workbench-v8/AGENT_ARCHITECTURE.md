# Java 17 agent architecture

```text
Browser UI
 ├─ Chat / Analyze / Agent
 ├─ API key / Base URL / Model / Vision model
 ├─ Uploaded screenshots / documents
 ├─ Browser-indexed project OR Local workspace path
 └─ Agent console + Approve/Deny
                  │
                  ▼
             Spring Boot
                  │
       ┌──────────┴──────────┐
       │ Conversations / H2  │
       │ File extraction     │
       │ Project index       │
       │ Context retrieval   │
       │ Permission engine   │
       │ Approval service    │
       └──────────┬──────────┘
                  │
             mode router
        ┌─────────┼────────────┐
        ▼         ▼            ▼
      Chat     Analyze       Agent loop
                              │
                       temporary mirror
                              │
                ┌─────────────┴─────────────┐
                │ set_plan / list / glob    │
                │ search / read / read-many │
                │ edit / write              │
                │ status / diff             │
                │ build / tests / command   │
                └─────────────┬─────────────┘
                              │
                   Allow / Ask / Deny
                              │
                    Ask → UI approval
                              │
                    tool observation
                              │
                    model chooses next step
                              │
                           final
                              │
                     staged file changes
                              │
             Review → ZIP or Apply + backup
```

## Agent state machine

```text
START
 ↓
Build bounded conversation + file + project context
 ↓
Create temporary workspace mirror
 ↓
MODEL DECISION
 ├─ plan/list/glob/search/read ─────────────┐
 ├─ edit/write ─ permission check ─────────┤
 ├─ build/test/command ─ permission check ─┤
 ├─ status/diff ─ permission check ────────┤
 └─ final                                  │
        ▲                                  │
        └──────── tool observation ◄────────┘
 ↓
Compact older tool observations when needed
 ↓
Compare touched files with baseline
 ↓
Save response + hidden structured patch markers
 ↓
Review / Download ZIP / Apply + backup
 ↓
END
```

## Permission state

For a permission-controlled tool:

```text
permission = deny  → return denied observation to agent
permission = allow → execute immediately
permission = ask   → create approval id → send SSE approval event → wait
                                      ↑
                             browser Approve/Deny
```

The approval wait occurs in the asynchronous agent request, so the user can approve from a second HTTP request while the SSE stream remains open.

## Why use a local mirror?

A browser directory picker exposes file handles to JavaScript but does not provide a normal absolute filesystem path to the Spring Boot backend. A full coding agent needs resources, build descriptors and commands. The application supports an explicitly entered **Local workspace path** and also an empty scratch workspace for greenfield work. The backend copies that trusted workspace into a temporary run directory and executes tools there.

The original workspace is touched only after explicit review/apply.

## Provider model

The agent loop is implemented in Java and communicates with an OpenAI-compatible `/chat/completions` endpoint. Native function calling is optional because tool requests are represented as strict JSON envelopes.

## Not yet implemented

The agent is OpenCode-style but is not a clone. Future additions could include:

- true LSP diagnostics/navigation
- MCP servers and custom tool registry
- interactive PTY terminal
- subagent delegation tree
- IDE extension
- resumable/forkable agent sessions independent of chat history
