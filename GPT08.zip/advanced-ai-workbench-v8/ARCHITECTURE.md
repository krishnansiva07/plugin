# Architecture

The application is a single Java 17 / Spring Boot service with a browser UI, H2 persistence, provider-neutral OpenAI-compatible model access, uploaded-file extraction, project indexing, artifact export and an iterative workspace agent.

The authoritative agent design is documented in `JAVA17_AGENT.md`. `AGENT_ARCHITECTURE.md` contains the detailed tool/permission flow.
