package com.llmart.llm.service;

import java.util.Locale;
import java.util.regex.Pattern;

/**
 * Cheap, local routing for unambiguous conversational Agent instructions.
 * Unclassified instructions execute normally; no separate intent-model call is needed.
 * The original user text always remains the authoritative scope.
 */
final class AgentConversationIntent {
    enum Kind { PLAN_PREVIEW, CONTINUE_PLAN, DIRECT }

    private static final Pattern CONTINUATION = Pattern.compile(
            "^(?:ok(?:ay)?|yes|yes please|please continue|continue|go ahead|proceed|" +
            "please proceed|carry on|keep going|continue with (?:it|the plan|implementation)|resume (?:it|the task|the plan)|start execution|start implementation|execute (?:it|the plan)|" +
            "implement (?:it|the plan)|do it|looks good(?:,? (?:proceed|continue))?|" +
            "approved|i approve|sounds good,? (?:go ahead|proceed)|yes,? (?:go ahead|proceed|implement it|execute it))\\s*[!.]*$",
            Pattern.CASE_INSENSITIVE);
    private static final Pattern PREVIEW_REQUEST = Pattern.compile(
            "\\b(?:create|generate|write|prepare|draft|give|provide|show|share|suggest|review|" +
            "improve|outline|propose|design)\\b.{0,90}\\b(?:prompt|implementation plan|" +
            "execution plan|action plan|proposed plan|plan for (?:implementation|execution))\\b",
            Pattern.CASE_INSENSITIVE | Pattern.DOTALL);
    private static final Pattern PLAN_HEADER = Pattern.compile(
            "^(?:(?:here is|here's|this is) (?:my |the )?(?:execution |implementation )?plan|" +
            "(?:my |the )?(?:execution |implementation )?plan\\s*[:\\-]|" +
            "review (?:my|this|the) plan\\b|i (?:will|want to) share (?:my|the) plan\\b)", Pattern.CASE_INSENSITIVE | Pattern.DOTALL);
    private static final Pattern DIRECT_ARTIFACT = Pattern.compile(
            "\\b(?:save|write|create|generate|produce)\\b.{0,100}\\b[\\w.-]+\\.(?:md|txt|docx|xlsx|pptx|pdf|json|java|ts|py)\\b|" +
            "\\b(?:review|check) (?:my |this |the )?plan\\b.{0,60}\\b(?:and )?(?:implement|fix|apply|execute|make changes|create files)\\b",
            Pattern.CASE_INSENSITIVE | Pattern.DOTALL);
    private static final Pattern EXECUTE_NOW = Pattern.compile(
            "\\b(?:execute|apply|implement|start implementing|run|fix|code|make the changes)\\b.{0,35}" +
            "\\b(?:now|directly|immediately|this plan|following plan|these steps)\\b|" +
            "\\b(?:execute|implement|apply) (?:it|this|my|the|following) plan\\b|" +
            "\\b(?:execute|implement|apply) it\\b",
            Pattern.CASE_INSENSITIVE | Pattern.DOTALL);

    // An explicit human approval boundary takes precedence over later implementation
    // instructions in the SAME multiline prompt (e.g. PREPARE PLAN, STOP, then IMPLEMENT APPROVED BATCH).
    // An ordinary direct task must not become a preview merely because it mentions "approval".
    private static final Pattern HUMAN_PLAN_GATE = Pattern.compile(
            "(?is)\\b(?:stop|pause|halt|wait|await)\\b.{0,110}\\b(?:explicit |human |user )?(?:approval|sign.off|confirmation)\\b" +
            "|\\b(?:before|prior to)\\b.{0,80}\\b(?:any |all )?(?:implementation|workbook edits|code changes)\\b.{0,90}\\b(?:approval|approved)\\b" +
            "|\\b(?:plan review|approval stage|present (?:the )?(?:complete |full )?(?:package |execution )?plan)\\b.{0,140}\\b(?:stop|await|approval)\\b");
    private static final Pattern NEGATED_PLAN_GATE = Pattern.compile(
            "(?i)\\b(?:do not|don't|never|no need to)\\s+(?:stop|pause|halt|wait|await)\\b");

    // Prompt generation is a DELIVERABLE, never a proposal to generate the prompt later.
    // Distinguish it from instructions to execute or review an EXISTING prompt.
    private static final Pattern PROMPT_OUTPUT = Pattern.compile(
            "(?is)\\b(?:generate|create|write|draft|prepare|produce|provide|give|share|deliver|make|develop)\\b" +
            ".{0,320}?\\bprompts?\\b");
    private static final Pattern PROMPT_OUTPUT_LOCATION = Pattern.compile(
            "(?is)\\bprompts?\\b.{0,120}\\b(?:in|into|inside|under|to|within)\\s+" +
            "(?:the\\s+)?(?:selected\\s+|current\\s+|mapped\\s+)?" +
            "(?:workspace|repository|repo|project|folder|directory|playwright\\s+folder)\\b" +
            "|\\bprompts?\\b.{0,80}\\b(?:as|into)\\s+(?:\\d+\\s+)?(?:separate\\s+)?(?:markdown|md)\\s+files?\\b" +
            "|\\b(?:save|write|export|deliver|create)\\b.{0,90}\\bprompts?\\b.{0,90}\\b(?:files?|\\.md)\\b");

    static boolean isPromptGenerationRequest(String text) {
        if (text == null || text.isBlank() || text.contains("--- BEGIN SELECTED PROMPT")) return false;
        java.util.regex.Matcher match = PROMPT_OUTPUT.matcher(text);
        while (match.find()) {
            String between = text.substring(match.start(), match.end());
            // 'generate code based on this prompt' uses the prompt as INPUT.
            if (!Pattern.compile("(?i)\\b(?:based on|using|according to|from the following|with the following)\\b")
                    .matcher(between).find()) return true;
        }
        return false;
    }

    static boolean promptFilesRequested(String text) {
        return isPromptGenerationRequest(text) && PROMPT_OUTPUT_LOCATION.matcher(text).find();
    }

    static boolean mixedOneTimeReusablePrompts(String text) {
        if (text == null) return false;
        return Pattern.compile("(?i)\\b(?:one[- ]time|task[- ]specific)\\b.{0,250}\\bprompts?\\b|\\bprompts?\\b.{0,250}\\b(?:one[- ]time|task[- ]specific)\\b")
                .matcher(text).find() && Pattern.compile("(?i)\\b(?:one|single|1)\\s+reusable\\s+prompt\\b|\\bone\\s+reusable\\b")
                .matcher(text).find();
    }

    static int requestedPromptCount(String text) {
        if (!isPromptGenerationRequest(text)) return 0;
        String low = text.toLowerCase(Locale.ROOT);
        boolean mixed = mixedOneTimeReusablePrompts(low);
        // A requested reusable prompt is ADDITIONAL to the unspecified one-time set.
        // Do not turn "some one-time prompts and one reusable prompt" into just one output.
        if (mixed && !Pattern.compile("\\b(?:\\d{1,2}|two|three|four|five|six|seven|eight|nine|ten)\\s+(?:one[- ]time\\s+)?prompts\\b").matcher(low).find())
            return 0;
        if (Pattern.compile("\\b(?:one|single|1|all.in.one)\\s+(?:complete\\s+|full\\s+|detailed\\s+)?prompt\\b")
                .matcher(low).find() && !Pattern.compile("\\b(?:[2-9]|10|two|three|four|five|six|seven|eight|nine|ten)\\s+\\w*\\s*prompts\\b")
                .matcher(low).find()) return 1;
        java.util.regex.Matcher number = Pattern.compile(
                "\\b(\\d{1,2}|one|two|three|four|five|six|seven|eight|nine|ten)\\s+" +
                "(?:(?:separate|different|distinct|individual|independent|standalone|one[- ]time|task[- ]specific|complete|full|detailed|markdown|md|reusable|migration|implementation|numbered)[\\s,;/-]+){0,5}prompts?\\b")
                .matcher(low);
        if (number.find()) {
            String value = number.group(1);
            int count;
            try { count = Integer.parseInt(value); }
            catch (NumberFormatException ignored) {
                count = java.util.List.of("one","two","three","four","five","six","seven","eight","nine","ten")
                        .indexOf(value) + 1;
            }
            if (count >= 1 && count <= 20) return mixed ? count + 1 : count;
        }
        java.util.regex.Matcher numbered = Pattern.compile("\\bprompt\\s*#?\\s*(\\d{1,2})\\b").matcher(low);
        int max = 0;
        while (numbered.find()) max = Math.max(max, Integer.parseInt(numbered.group(1)));
        if (max > 0 && max <= 20) return max;
        // Plural without a numeric cardinality delegates decomposition to the Agent.
        // Singular ("generate a prompt") retains the one-prompt contract.
        return Pattern.compile("(?i)\\b(?:some|several|multiple|various|different|separate)\\s+(?:[a-z-]+\\s+){0,3}prompts\\b|\\bprompts\\b")
                .matcher(low).find() ? 0 : 1;
    }

    private AgentConversationIntent() { }

    static Kind classify(String text) {
        String prompt = text == null ? "" : text.strip();
        if (CONTINUATION.matcher(prompt).matches()) return Kind.CONTINUE_PLAN;
        if (HUMAN_PLAN_GATE.matcher(prompt).find() && !NEGATED_PLAN_GATE.matcher(prompt).find())
            return Kind.PLAN_PREVIEW;
        if (isPromptGenerationRequest(prompt)) return Kind.DIRECT;
        if (EXECUTE_NOW.matcher(prompt).find() || DIRECT_ARTIFACT.matcher(prompt).find()) return Kind.DIRECT;
        if (PREVIEW_REQUEST.matcher(prompt).find() || PLAN_HEADER.matcher(prompt).find()) return Kind.PLAN_PREVIEW;
        return Kind.DIRECT;
    }

    /** Distinguish an answer to a pending question from a fresh explicit instruction. */
    static boolean looksLikeIndependentInstruction(String text) {
        if (text == null || text.isBlank()) return false;
        String low = text.strip().toLowerCase(Locale.ROOT);
        return Pattern.compile("^(?:please\\s+)?(?:fix|implement|execute|create|generate|" +
                "run|delete|remove|write|migrate|refactor|explain|analy[sz]e|investigate|" +
                "summari[sz]e|review|cancel|stop|new task)\\b", Pattern.CASE_INSENSITIVE)
                .matcher(low).find();
    }

    /** Explicit downloadable artifacts need Agent write/verification tools, even for analysis. */
    private static final Pattern REQUESTED_OUTPUT_FILE = Pattern.compile(
            "(?i)\\b(?:as|into|in)\\s+(?:an?\\s+)?(?:downloadable\\s+|editable\\s+)?(?:markdown|md|pdf|docx|word|xlsx|excel|pptx|powerpoint|html|json)\\s*(?:file|document|report)?\\b|" +
            "\\b(?:create|save|write|generate|produce|provide|export|deliver|prepare|send|give me)\\b.{0,60}\\b(?:markdown|md|pdf|word|excel|json|html)\\s+(?:file|document|artifact|download)\\b|" +
            "\\b(?:save|create|write|generate|produce|export|deliver|prepare|update|overwrite|output)\\s+(?:(?:a|an|the|new|final|updated|file|named|as|to)\\s+){0,4}[\\w./-]+\\.(?:md|txt|docx|xlsx|pptx|pdf|json|html)\\b");

    /** A simple read-only question can skip the planning model entirely. */
    static boolean isFastReadOnly(String text) {
        if (text == null || text.isBlank()) return false;
        String low = text.strip().toLowerCase(Locale.ROOT);
        // A tutorial question mentioning a PDF/JSON file is still read-only.
        boolean tutorial = Pattern.compile("^(?:how (?:do|does|to|can|should)\\b|explain (?:how|what)\\b|what (?:is|are)\\b)")
                .matcher(low).find();
        if (isPromptGenerationRequest(text)) return !promptFilesRequested(text);
        if (!tutorial && REQUESTED_OUTPUT_FILE.matcher(text).find()) return false;
        if (classify(text) != Kind.DIRECT) return false;
        // Descriptive "how to create" is not an instruction to create. An explicit
        // second clause ("and create/fix/apply it") *is* authorization to act.
        boolean explanationQuestion = Pattern.compile(
                "^(?:(?:please|can you|could you|would you)\\s+)*(?:explain|describe|tell me|show me|how\\b|why\\b|what\\b|which\\b|is there|are there|i need (?:the |an? )?(?:architecture|overview|explanation))",
                Pattern.CASE_INSENSITIVE).matcher(low).find();
        boolean explicitActionClause = Pattern.compile(
                "\\b(?:and|then|also)\\s+(?:please\\s+)?(?:implement|fix|change|modify|create|generate|write|delete|update|execute|apply|deploy|build|save|run|migrate)\\b|" +
                "\\b(?:go ahead and|please do|make the changes|implement it|execute it)\\b",
                Pattern.CASE_INSENSITIVE).matcher(low).find();
        if (explanationQuestion && !explicitActionClause &&
                (low.startsWith("how ") || low.startsWith("why ") || low.startsWith("what ") ||
                 low.contains("explain") || low.contains("tell me") || low.contains("describe") ||
                 low.contains("overview") || low.contains("show me"))) return true;
        // Output requests for an explanation are not instructions to write files.
        boolean requestedExplanation = Pattern.compile(
                "^(?:i (?:need|want)|please provide|give me)\\s+(?:(?:an?|the|full|complete|detailed|deep|e2e|end.to.end)\\s+)*(?:architecture|overview|explanation|analysis|working principle|flow|technical report)\\b",
                Pattern.CASE_INSENSITIVE).matcher(low).find();
        if (requestedExplanation && !explicitActionClause &&
                !Pattern.compile("\\b(?:save|write|create|generate|export)\\b", Pattern.CASE_INSENSITIVE).matcher(low).find()) return true;
        // "Run the verification greps and report missing matches" is an evidence audit,
        // not a request to modify code. Real build/test/repair requests remain Agent execution.
        if (AgentReadOnlySearchPolicy.isAudit(text)) return true;
        if (AgentPlanRelevance.isReadOnlyAnalysisRequest(text)) return true;
        // Natural workspace inspection questions, including "read ARCHITECTURE.md"
        // and "show me what's in this repository", are not execution tasks.
        boolean observation = Pattern.compile("\\b(?:read|show|display|list|inspect|check|browse|explore|summari[sz]e|what.s in|what is in|what exists|can you tell)\\b",
                Pattern.CASE_INSENSITIVE).matcher(low).find();
        boolean mutation = Pattern.compile("\\b(?:implement|fix|modify|edit|delete|remove|create|generate|build|save|write|update|migrate|refactor|execute|run|deploy|commit|push)\\b",
                Pattern.CASE_INSENSITIVE).matcher(low).find();
        if (observation && !mutation) return true;
        if ((low.startsWith("how ") || low.startsWith("why ") || low.startsWith("tell me ") ||
                low.startsWith("can you explain ") || low.startsWith("can you tell ")) &&
                !Pattern.compile("\\b(?:implement|fix|modify|edit|delete|migrate|refactor|execute|run|" +
                        "generate|build|save|write|update|change)\\b", Pattern.CASE_INSENSITIVE).matcher(low).find())
            return true;
        return false;
    }
}
