package com.llmart.llm.service;

import com.llmart.llm.dto.ProjectPatchRequest;
import java.util.List;
import java.util.Map;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** A grounded conversational completion is part of the deliverable, not a tool-status label.
 * No new model call or fabricated action is required. The next step is explicit and resumable.
 */
final class AgentCompletionNarrator {
    private static final Pattern SUGGESTION = Pattern.compile(
            "(?m)^\\*\\*Suggested next step:\\*\\*\\s+(.{8,220})\\s*$");
    private static final Pattern ACCEPT = Pattern.compile(
            "(?is)^(?:yes|yes please|sure|ok|okay|go ahead|proceed|do it|please do|sounds good)" +
            "(?:[,.! ]+(?:and|also|but|only|except|please)\\s+(.{1,400}))?[.! ]*$");
    private AgentCompletionNarrator() { }

    static String suggestedAction(String answer) {
        if (answer == null) return "";
        Matcher m = SUGGESTION.matcher(answer);
        return m.find() ? m.group(1).strip() : "";
    }

    static String acceptedNextInstruction(String userReply, String assistantAnswer) {
        String suggestion = suggestedAction(assistantAnswer);
        if (suggestion.isBlank() || userReply == null) return "";
        Matcher accepted = ACCEPT.matcher(userReply.strip());
        if (!accepted.matches()) return "";
        String addition = accepted.group(1) == null ? "" : accepted.group(1).strip();
        return "Continue the SAME completed task in the currently mapped workspace. " +
               "The user explicitly accepted this exact suggested follow-up: " + suggestion + ". " +
               "Carry out only this action, inspect the current workspace first, run relevant verification, " +
               "and explain the actual result and files changed. " +
               (addition.isBlank() ? "" : "User's additional constraint: " + addition + ". ") +
               "Do not repeat or overwrite the previously completed task unnecessarily.";
    }

    static String complete(String prior, String objective,
                           List<ProjectPatchRequest.ProjectPatchFile> changes,
                           int totalChanged, String verification, boolean verified,
                           String status) {
        return complete(prior, objective, changes, totalChanged, verification, verified, status, List.of());
    }

    static String complete(String prior, String objective,
                           List<ProjectPatchRequest.ProjectPatchFile> changes,
                           int totalChanged, String verification, boolean verified,
                           String status, List<Map<String,Object>> plan) {
        // Answers to questions belong in the conversation. Plan completion, tool
        // counters and verification transcripts already exist in the activity UI.
        // Even an incomplete investigation should return its grounded findings first.
        if (AgentResultPresentation.isAnswerFirstQuery(objective, totalChanged)) {
            return AgentResultPresentation.answerFirst(prior, status, verification);
        }
        // Failure, cancellation, and partial progress deserve a real conversation
        // outcome too. A useful pre-existing explanation is retained as evidence;
        // the file/plan/verification ledger is added even when the LLM said nothing.
        if (!"completed".equals(status)) {
            String explanation = prior == null ? "" : prior.strip();
            String state = status == null || status.isBlank() ? "unknown" : status;
            List<ProjectPatchRequest.ProjectPatchFile> files = changes == null ? List.of() : changes;
            StringBuilder result = new StringBuilder("## Outcome: ").append(state)
                .append(" — not verified complete\n\n");
            if (!explanation.isBlank() && !explanation.matches("(?is)^(?:task (?:blocked|failed|completed)|agent run (?:blocked|failed|completed)|done[.!]?|completed successfully)[.! ]*$")) {
                result.append("### Execution findings\n\n").append(explanation).append("\n\n");
            }
            result.append("### What was completed (plan steps reported complete; not proof of acceptance)\n\n");
            List<String> finishedSteps = plan == null ? List.of() : plan.stream()
                .filter(row -> "completed".equals(String.valueOf(row.get("status"))))
                .map(row -> safeLine(String.valueOf(row.getOrDefault("text", "")), 180))
                .filter(text -> !text.isBlank()).limit(8).toList();
            if (finishedSteps.isEmpty()) result.append("No completed plan steps were confirmed in this run.\n\n");
            else {
                for (String item : finishedSteps) result.append("- ").append(item).append('\n');
                result.append('\n');
            }
            if (totalChanged > 0) {
                result.append("**Tracked workspace changes:** ").append(totalChanged).append(".\n");
                for (int i = 0; i < Math.min(files.size(), 12); i++) {
                    ProjectPatchRequest.ProjectPatchFile file = files.get(i);
                    if (file != null && file.path() != null)
                        result.append("- `").append(file.path().replace("`", "")).append("`\n");
                }
                if (files.isEmpty()) result.append("File inventory unavailable; see execution history for details.\n");
                result.append("\nChanges are preserved, but their existence does not prove the task passed verification.\n\n");
            } else result.append("No tracked workspace changes were confirmed.\n\n");
            List<String> unfinished = plan == null ? List.of() : plan.stream()
                .filter(row -> !"completed".equals(String.valueOf(row.get("status"))))
                .map(row -> safeLine(String.valueOf(row.getOrDefault("text", "")), 180))
                .filter(text -> !text.isBlank()).limit(6).toList();
            result.append("### What remains\n\n");
            if (!unfinished.isEmpty()) {
                for (String item : unfinished) result.append("- ").append(item).append('\n');
                result.append('\n');
            } else result.append("The final completion/verification gate was not satisfied; inspect the failing execution event.\n\n");
            result.append("### Verification\n\n");
            result.append(verified ? "A recorded check passed, but the overall task is still not complete."
                : "The latest task outcome was not verified successful.");
            if (verification != null && !verification.isBlank())
                result.append(" Recorded evidence: ").append(safeLine(verification, 350));
            result.append("\n\n### Improvement opportunities\n\n");
            if (objective != null && objective.toLowerCase(java.util.Locale.ROOT).contains("headed"))
                result.append("Check whether the test host has an available graphical browser session; " +
                    "capture the test-run command, exit code, test counts, and failure diagnostics before treating a headed run as successful.\n\n");
            else if (!verified)
                result.append("Improve the missing or failing verification evidence before making further changes. " +
                    "No particular code improvement has been established by this incomplete run.\n\n");
            else result.append("Review the unresolved completion gate before proposing new changes.\n\n");
            result.append("### Suggested next step\n\n");
            if (!unfinished.isEmpty())
                result.append("Resume the first unfinished step (`").append(unfinished.get(0).replace("`", "'"))
                    .append("`) after resolving its blocker, then run the relevant verification before marking the task complete.");
            else result.append("Inspect the last failed action and verification report, resolve the blocker, " +
                    "then rerun the missing checks. Do not repeat work already verified.");
            return result.toString().strip();
        }
        String answer = prior == null ? "" : prior.strip().replaceAll(
                "(?is)\\s*Do you want to add anything\\?\\s*$", "");
        List<ProjectPatchRequest.ProjectPatchFile> files = changes == null ? List.of() : changes;
        boolean wrote = totalChanged > 0;
        boolean meaningful = AgentResultPresentation.hasSubstantiveAnswer(answer);
        StringBuilder result = new StringBuilder();
        if (wrote) {
            // A saved prompt set is source content, not a user-facing analysis.
            // Report actual written paths rather than copying the entire prompt
            // document back into the completion message as though it were findings.
            boolean filePrompt = AgentConversationIntent.promptFilesRequested(objective);
            if (meaningful && !(filePrompt && java.util.regex.Pattern.compile(
                    "(?im)^\\s*#{1,6}\\s*prompt\\s*#?\\d+\\b").matcher(answer).find()))
                result.append(answer).append("\n\n---\n\n");
            result.append("### What I completed\n\n");
            result.append("I made ").append(totalChanged).append(totalChanged == 1 ? " tracked workspace file change" : " tracked workspace file changes");
            String task = oneLineObjective(objective);
            if (!task.isBlank()) result.append(" for your request: ").append(task);
            result.append(".\n\n");
            if (plan != null && !plan.isEmpty()) {
                List<String> completedSteps = plan.stream().filter(row -> "completed".equals(row.get("status")))
                    .map(row -> safeLine(String.valueOf(row.getOrDefault("text", "")), 175))
                    .filter(text -> !text.isBlank()).limit(5).toList();
                if (!completedSteps.isEmpty()) {
                    result.append("**Completed work**\n\n");
                    for (String item : completedSteps) result.append("- ").append(item).append("\n");
                    result.append("\n");
                }
            }
            if (!files.isEmpty()) {
                result.append("**Files created or changed**\n\n");
                for (int i=0; i<Math.min(files.size(), 30); i++) {
                    ProjectPatchRequest.ProjectPatchFile f = files.get(i);
                    if (f == null || f.path() == null) continue;
                    String action = "delete".equalsIgnoreCase(f.operation()) ? "Deleted" :
                        Hashing.ABSENT.equals(f.baselineHash()) ? "Created" : "Updated";
                    result.append("- ").append(action).append(" `")
                          .append(f.path().replace("`", "")).append("`\n");
                }
                if (totalChanged > Math.min(files.size(), 30)) result.append("- Plus ")
                    .append(totalChanged - Math.min(files.size(), 30)).append(" other tracked change(s)\n");
                result.append("\n");
            } else result.append("The file-change inventory could not be loaded; inspect the detailed execution report for paths.\n\n");
        } else {
            if (meaningful) result.append(answer).append("\n\n");
            else if (!answer.isBlank()) result.append(answer).append("\n\n");
            // Don't claim that implementation happened when no actual change was observed.
            if (!meaningful) result.append("**Files:** No tracked local workspace changes were recorded.\n\n");
            if (verification != null && !verification.isBlank()) result.append("**Verification evidence:** ")
                    .append(safeLine(verification, 350)).append("\n\n");
            // Read-only analysis is itself a deliverable. Preserve the full explanation and
            // offer only a recommendation explicitly present in that explanation.
            if (meaningful && AgentAnalysisOutcome.isAnalysis(objective)) {
                String proposed = AgentAnalysisOutcome.recommendedAction(objective, answer);
                if (!proposed.isBlank()) result.append("**Suggested next step:** ").append(proposed);
            }
        }
        if (wrote) {
            result.append("**Verification:** ");
            if (verified) result.append("The latest workspace revision passed the recorded check");
            else result.append("No successful verification of the latest workspace revision was recorded");
            if (verification != null && !verification.isBlank()) result.append(" — ").append(safeLine(verification, 280));
            result.append(".\n\n");
        }
        // A completed task must still explain the practical follow-up. Preserve
        // specific model recommendations rather than replacing them with boilerplate.
        String existing = result.toString();
        if (!existing.matches("(?is).*\\b(?:suggested next step|next steps?|recommendations|improvements)\\b.*")) {
            result.append("\n\n### Improvements and next step\n\n");
            if (wrote && !verified) result.append("Complete the missing verification for the latest workspace changes " +
                    "before relying on them. Review the recorded results for defects or missing coverage.");
            else if (wrote) result.append("Review the changed artifacts and recorded checks. " +
                    "Any further improvement should be based on gaps found in that review.");
            else if (AgentAnalysisOutcome.isAnalysis(objective)) result.append("Use the evidence above to choose " +
                    "a specific change or check; no workspace edit was performed by this analysis.");
            else result.append("No additional changes are required by the verified scope. " +
                    "Review the recorded result before requesting further enhancements.");
        }
        return result.toString().strip();
    }

    private static String safeLine(String value, int length) {
        String safe = value.replace('\n', ' ').replace('\r', ' ').replace('`', '\'').strip();
        return safe.length() <= length ? safe : safe.substring(0, length) + "…";
    }
    private static String oneLineObjective(String value) {
        if (value == null) return "";
        String first = value.split("[\\r\\n]", 2)[0].replace('`','\'').strip();
        if (first.length() > 170) first = first.substring(0, 167) + "…";
        return first;
    }
}
