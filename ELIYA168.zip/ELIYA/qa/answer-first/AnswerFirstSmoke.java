package com.llmart.llm.service;

import java.util.List;
import java.util.Map;

/** Regression for answer-first finalization and truthful partial analysis. */
public final class AnswerFirstSmoke {
    static int count;
    static void check(boolean value, String explanation) {
        count++;
        if (!value) throw new AssertionError(explanation);
    }
    public static void main(String[] args) {
        String audit = "Run the verification greps in Migration/prompt-*.md and report missing matches";
        check(AgentResultPresentation.isAnswerFirstQuery(audit, 0), "grep audit should produce a direct answer");
        check(AgentResultPresentation.isAnswerFirstQuery("Why is the API failing?", 0), "why question");
        check(AgentResultPresentation.isAnswerFirstQuery("Analyse workspace architecture", 0), "analysis query");
        check(AgentResultPresentation.isAnswerFirstQuery("Check whether the migration is complete", 0), "verification question");
        check(!AgentResultPresentation.isAnswerFirstQuery("Run integration tests and report failures", 0), "tests are execution, not read-only");
        check(!AgentResultPresentation.isAnswerFirstQuery("Fix the framework then explain", 0), "mutating request must not be silently treated as analysis");
        check(!AgentResultPresentation.isAnswerFirstQuery("Analyse and write report.md", 0), "requested artifact must retain artifact report");
        check(!AgentResultPresentation.isAnswerFirstQuery("Why does the service fail?", 1), "changed files must retain change summary");
        String details = "## Verification findings\n\nMigration/prompt-1.md has the required grep. Migration/prompt-3.md has no matching command. " +
                "The first search was successful; the third has zero matches. No files were edited.";
        String success = AgentCompletionNarrator.complete(details, audit, List.of(), 0, "", false,
                "completed", List.of(Map.of("text","Plan steps complete", "status","completed")));
        check(success.equals(details), "completed answer must be exactly findings, not plan bookkeeping");
        String blocked = AgentCompletionNarrator.complete(details, audit, List.of(), 0, "grep coverage not complete", false,
                "blocked", List.of(Map.of("text","Plan steps complete", "status","completed")));
        check(blocked.startsWith(details), "blocked analysis retains findings first");
        check(blocked.contains("Coverage limitation"), "partial analysis must disclose coverage limits");
        check(!blocked.contains("What was completed"), "plan steps belong in activity not answer");
        check(!blocked.contains("Outcome: blocked"), "do not replace findings with failure heading");
        String shortAnswer = AgentCompletionNarrator.complete("No matches found in `prompt-3.md`.", audit,
                List.of(), 0, "", true, "completed");
        check(shortAnswer.equals("No matches found in `prompt-3.md`."), "short grounded answer is valid");
        String missing = AgentCompletionNarrator.complete("Agent run completed", "Analyse the workspace", List.of(), 0,
                "No source files were inspected", false, "blocked");
        check(missing.contains("Answer not established"), "must not invent analysis from a generic success label");
        check(missing.contains("No source files were inspected"), "show actual missing-evidence reason");
        String failed = AgentCompletionNarrator.complete(details, "Analyse the workspace", List.of(), 0,
                "Read permission denied for the remaining module", false, "failed");
        check(failed.startsWith(details), "actual findings survive tool failure");
        check(failed.contains("Read permission denied"), "unverified portion disclosed");
        String unverified = AgentResultPresentation.answerFirst(details + "\n\n**Coverage limitation:** partial coverage", "blocked", "");
        check(unverified.indexOf("Coverage limitation") == unverified.lastIndexOf("Coverage limitation"), "no duplicate limit warnings");
        System.out.println("ELIYA answer-first: " + count + " assertions passed");
    }
}
