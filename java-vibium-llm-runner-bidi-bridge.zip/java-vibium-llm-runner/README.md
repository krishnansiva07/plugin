# Java Vibium LLM Runner - Local Chrome/Chromium Safe Build

This is a Spring Boot + Java Vibium based test runner.

It is designed for corporate networks where Vibium cannot download Chrome for Testing from `googlechromelabs.github.io`.

## What was fixed

The earlier local browser build launched Chrome with `--remote-debugging-port` and passed the Chrome DevTools websocket to Vibium. That fails with:

```text
BiDi error: session.new wasn't found
Failed to send ready signal: pipe closed
```

Reason: Chrome `/json/version` returns a **CDP** websocket. Vibium expects a **WebDriver BiDi** websocket.

This version starts your provided `chromedriver.exe` or `msedgedriver.exe`, creates a WebDriver BiDi session with `webSocketUrl=true`, reads the returned `webSocketUrl`, then passes it to Vibium using `StartOptions.connectURL(...)`.

ChromeDriver/EdgeDriver is used only as a local BiDi bridge. Selenium is not used.

## Features

- Upload test scenarios from JSON or Excel.
- Scenario test data in the same file.
- LLM token/base URL/model from the UI.
- Chrome/Chromium executable path from the UI.
- ChromeDriver/EdgeDriver path or upload from the UI.
- Headed/headless execution.
- Vibium Java actions: navigate, find, fill, click, press, select, check, assert text.
- Post-run JSON report, Excel report, and screenshot ZIP.

## Recommended browser mode

Use:

```text
Driver BiDi Bridge - use my browser exe + matching driver
```

Required fields:

```text
Chrome / Chromium executable path = C:\Program Files\Google\Chrome\Application\chrome.exe
ChromeDriver path = C:\drivers\chromedriver.exe
```

For Chromium:

```text
Chrome / Chromium executable path = C:\path\to\chromium.exe
ChromeDriver path = C:\path\to\matching\chromedriver.exe
```

Chrome/Chromium and ChromeDriver versions must match. For Edge use msedgedriver.exe matching Edge. Prefer browser/driver 115+.

## Run

```bash
mvn clean spring-boot:run
```

Open:

```text
http://localhost:8090
```

## Reports

After execution:

```text
target/vibium-test-runs/<run-id>/
  report.json
  report.xlsx
  screenshots.zip
  screenshots/
  chromedriver-bidi.log
```

## Excel columns

```text
id | name | url | steps | expected | data.username | data.password | testDataJson
```

`steps` can be separated by `|` or new lines.

Example:

```text
Open login page | Enter username | Enter password | Click Login | Verify dashboard
```

## JSON format

```json
[
  {
    "id": "TC001",
    "name": "Login success",
    "url": "https://example.com/login",
    "steps": ["Enter username", "Enter password", "Click Login", "Verify dashboard"],
    "data": {"username": "standard_user", "password": "secret_sauce"},
    "expected": "Dashboard"
  }
]
```

## Troubleshooting

### `BiDi error: session.new wasn't found`

You are connecting Vibium to a CDP websocket, normally from `/json/version` or `/devtools/browser/...`. Use the new **ChromeDriver BiDi Bridge** mode instead.

### `webSocketUrl was missing`

ChromeDriver created a normal session but did not expose WebDriver BiDi. Usually this means ChromeDriver is too old or mismatched with Chrome/Chromium.

### `Driver could not create browser session`

Check:

- `chromedriver.exe` exists and can run.
- `chrome.exe`/`chromium.exe` path is correct.
- Driver version matches browser version.
- Corporate policy is not blocking Chrome launch.

