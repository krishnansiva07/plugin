let actions = [];
let recording = false;

const els = {
  statusBadge: document.getElementById('statusBadge'),
  startBtn: document.getElementById('startBtn'),
  stopBtn: document.getElementById('stopBtn'),
  clearBtn: document.getElementById('clearBtn'),
  testName: document.getElementById('testName'),
  rawCount: document.getElementById('rawCount'),
  strongCount: document.getElementById('strongCount'),
  warningCount: document.getElementById('warningCount'),
  lastAction: document.getElementById('lastAction'),
  lastSummary: document.getElementById('lastSummary'),
  commentBox: document.getElementById('commentBox'),
  attachCommentBtn: document.getElementById('attachCommentBtn'),
  steps: document.getElementById('steps'),
  copyGenericBtn: document.getElementById('copyGenericBtn'),
  downloadGenericBtn: document.getElementById('downloadGenericBtn'),
  copyRawBtn: document.getElementById('copyRawBtn')
};

async function init() {
  const data = await chrome.storage.local.get(['astraRecording', 'astraActions', 'astraSession']);
  recording = !!data.astraRecording;
  actions = Array.isArray(data.astraActions) ? data.astraActions : [];
  if (data.astraSession?.testName) els.testName.value = data.astraSession.testName;
  render();
}

function cleanStepForExport(a, index) {
  return {
    step: index + 1,
    action: a.action,
    eventType: a.eventType,
    page: a.page,
    elementIdentity: a.element,
    recommendedLocator: a.recommendedLocator,
    rankedLocators: (a.rankedLocators || []).slice(0, 8).map(l => ({
      strategy: l.strategy,
      value: l.value,
      score: l.score,
      unique: l.unique,
      matchCount: l.matchCount,
      recommended: !!l.recommended,
      reason: l.reason,
      dynamicRisk: !!l.dynamicRisk
    })),
    relationshipContext: a.relationshipContext,
    domContext: {
      nearestHeading: a.domContext?.nearestHeading || null,
      nearestForm: a.domContext?.nearestForm || null,
      nearestDialogOrModal: a.domContext?.nearestDialogOrModal || null,
      tableContext: a.domContext?.tableContext || null,
      frameContext: a.domContext?.frameContext || null,
      shadowDomContext: a.domContext?.shadowDomContext || null,
      parentContext: (a.domContext?.parentContext || []).slice(0, 3).map(p => ({
        level: p.level,
        tag: p.tag,
        role: p.role,
        id: p.id,
        dataAttribute: p.dataAttribute,
        classHint: p.classHint,
        textSummary: p.textSummary
      }))
    },
    valuePolicy: a.valuePolicy || null,
    state: a.state || null,
    key: a.key || null,
    selectedText: a.selectedText || null,
    locatorWarnings: a.locatorWarnings || [],
    validationComment: a.validationComment || '',
    capturedAt: a.capturedAt
  };
}

function signature(a) {
  const loc = a.recommendedLocator;
  return [a.action, loc?.strategy, loc?.value, a.element?.accessibleName, a.page?.url].join('|');
}

function optimizedActions() {
  const out = [];
  for (const a of actions) {
    const last = out[out.length - 1];
    if (last && a.action === 'input' && signature(last) === signature(a)) {
      out[out.length - 1] = { ...last, ...a, validationComment: a.validationComment || last.validationComment };
      continue;
    }
    if (last && signature(last) === signature(a) && ['click','keyboard'].includes(a.action)) continue;
    out.push(a);
  }
  return out.map(cleanStepForExport);
}

function buildGenericJson() {
  const opts = optimizedActions();
  return {
    schemaVersion: 'astra-ai-ui-recorder.generic-locator.v2.1',
    recorderName: 'Astra-Ai UI Recorder',
    purpose: 'Generic UI automation recording with framework-neutral element locator intelligence',
    recordingMode: 'compact-element-intelligence',
    testName: els.testName.value || 'Untitled UI flow',
    createdAt: new Date().toISOString(),
    summary: {
      rawActionCount: actions.length,
      optimizedActionCount: opts.length,
      strongLocatorCount: opts.filter(a => (a.recommendedLocator?.score || 0) >= 85).length,
      warningCount: opts.reduce((sum, a) => sum + (a.locatorWarnings?.length || 0), 0)
    },
    locatorStrategyNote: 'Framework neutral. Convert strategies into Selenium, Playwright, Cypress, WebdriverIO, Robot Framework, or any UI automation framework downstream.',
    actions: opts
  };
}

function scoreClass(score) {
  if (score >= 85) return 'good';
  if (score >= 65) return 'warn';
  return 'bad';
}

function short(s, n = 80) {
  s = String(s || '');
  return s.length > n ? s.slice(0, n - 1) + '…' : s;
}

function render() {
  els.statusBadge.textContent = recording ? 'Recording' : 'Stopped';
  els.statusBadge.className = 'badge ' + (recording ? 'on' : 'off');
  els.rawCount.textContent = actions.length;
  const strong = actions.filter(a => (a.recommendedLocator?.score || 0) >= 85).length;
  const warnings = actions.reduce((s,a) => s + (a.locatorWarnings?.length || 0), 0);
  els.strongCount.textContent = strong;
  els.warningCount.textContent = warnings;

  const last = actions[actions.length - 1];
  if (last) {
    els.lastAction.classList.remove('hidden');
    const loc = last.recommendedLocator;
    els.lastSummary.innerHTML = `
      <b>${last.action.toUpperCase()}</b> ${short(last.element?.accessibleName || last.element?.visibleText || last.element?.tag || 'element', 70)}
      <div class="locator">${loc ? `${loc.strategy}: ${escapeHtml(loc.value)}` : 'No locator'}</div>
      ${loc ? `<div class="small">Score: <span class="score ${scoreClass(loc.score)}">${loc.score}</span> · ${escapeHtml(loc.reason || '')}</div>` : ''}
    `;
    els.commentBox.value = last.validationComment || '';
  } else {
    els.lastAction.classList.add('hidden');
  }

  els.steps.innerHTML = actions.map((a, i) => {
    const loc = a.recommendedLocator || {};
    const warningsHtml = (a.locatorWarnings || []).length ? `<div class="warnbox">⚠ ${a.locatorWarnings.map(escapeHtml).join('<br>⚠ ')}</div>` : '';
    return `<div class="step">
      <div class="step-title"><span>#${i+1} ${escapeHtml(short(a.element?.accessibleName || a.element?.visibleText || a.element?.tag || 'element', 55))}</span><span class="action-pill">${a.action}</span></div>
      <div class="locator">${escapeHtml(loc.strategy || 'locator')}: ${escapeHtml(loc.value || 'not available')}</div>
      <div class="small">Score: <span class="score ${scoreClass(loc.score || 0)}">${loc.score || 0}</span> · Unique: ${loc.unique === null ? 'n/a' : loc.unique}</div>
      <div class="small">Context: ${escapeHtml(short(a.relationshipContext?.nearestHeading || a.relationshipContext?.nearestForm || a.domContext?.nearestDialogOrModal || '', 110))}</div>
      ${warningsHtml}
      ${a.validationComment ? `<div class="comment">${escapeHtml(a.validationComment)}</div>` : ''}
    </div>`;
  }).join('') || '<p>No steps captured yet.</p>';
}

function escapeHtml(s) {
  return String(s || '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));
}

async function setRecording(value) {
  recording = value;
  if (value && actions.length === 0) {
    await chrome.storage.local.set({ astraSession: { testName: els.testName.value || 'Untitled UI flow', startedAt: new Date().toISOString() } });
  }
  await chrome.storage.local.set({ astraRecording: value });
  render();
}

els.startBtn.addEventListener('click', () => setRecording(true));
els.stopBtn.addEventListener('click', () => setRecording(false));
els.clearBtn.addEventListener('click', async () => {
  actions = [];
  await chrome.storage.local.set({ astraActions: [], astraSession: null });
  render();
});
els.testName.addEventListener('change', async () => {
  const data = await chrome.storage.local.get(['astraSession']);
  await chrome.storage.local.set({ astraSession: { ...(data.astraSession || {}), testName: els.testName.value } });
});
els.attachCommentBtn.addEventListener('click', async () => {
  if (!actions.length) return;
  actions[actions.length - 1].validationComment = els.commentBox.value.trim();
  await chrome.storage.local.set({ astraActions: actions });
  render();
});

els.copyGenericBtn.addEventListener('click', async () => {
  await navigator.clipboard.writeText(JSON.stringify(buildGenericJson(), null, 2));
  flash(els.copyGenericBtn, 'Copied');
});
els.copyRawBtn.addEventListener('click', async () => {
  await navigator.clipboard.writeText(JSON.stringify(actions, null, 2));
  flash(els.copyRawBtn, 'Copied');
});
els.downloadGenericBtn.addEventListener('click', () => {
  const blob = new Blob([JSON.stringify(buildGenericJson(), null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `astra-ai-ui-recording-${new Date().toISOString().replace(/[:.]/g,'-')}.json`;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
});

function flash(button, text) {
  const old = button.textContent;
  button.textContent = text;
  setTimeout(() => button.textContent = old, 1200);
}

chrome.runtime.onMessage.addListener((msg) => {
  if (msg.type === 'ASTRA_ACTION_ADDED') {
    actions.push(msg.payload);
    render();
  }
});

chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== 'local') return;
  if (changes.astraActions) {
    actions = Array.isArray(changes.astraActions.newValue) ? changes.astraActions.newValue : [];
    render();
  }
  if (changes.astraRecording) {
    recording = !!changes.astraRecording.newValue;
    render();
  }
});

init();
