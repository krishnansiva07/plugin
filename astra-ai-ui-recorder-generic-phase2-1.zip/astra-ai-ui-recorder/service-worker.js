chrome.runtime.onInstalled.addListener(async () => {
  await chrome.storage.local.set({
    astraRecording: false,
    astraActions: [],
    astraSession: null
  });
});

chrome.action.onClicked.addListener(async (tab) => {
  if (chrome.sidePanel && chrome.sidePanel.open) {
    await chrome.sidePanel.open({ tabId: tab.id });
  }
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message || !message.type) return;

  if (message.type === 'ASTRA_ACTION_CAPTURED') {
    chrome.storage.local.get(['astraRecording', 'astraActions', 'astraSession']).then(async (data) => {
      if (!data.astraRecording) return;
      const actions = Array.isArray(data.astraActions) ? data.astraActions : [];
      const enriched = {
        ...message.payload,
        step: actions.length + 1,
        capturedAt: new Date().toISOString(),
        tab: {
          id: sender.tab?.id,
          url: sender.tab?.url,
          title: sender.tab?.title,
          frameId: sender.frameId
        }
      };
      actions.push(enriched);
      await chrome.storage.local.set({ astraActions: actions });
      chrome.runtime.sendMessage({ type: 'ASTRA_ACTION_ADDED', payload: enriched }).catch(() => {});
    });
    sendResponse({ ok: true });
    return true;
  }
});
