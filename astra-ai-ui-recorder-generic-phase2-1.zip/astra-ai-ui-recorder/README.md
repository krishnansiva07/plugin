# Astra-Ai UI Recorder

Astra-Ai UI Recorder is a framework-neutral Chrome Extension for recording UI automation actions with advanced element locator intelligence.

This version focuses only on high-quality generic UI recording. It does not integrate with any LLM, Playwright, Selenium, or backend tool.

## Features

- Chrome Side Panel UI
- Start / Stop / Clear recording
- Captures meaningful actions only:
  - click
  - input
  - select
  - checkbox/radio
  - file input change
  - Enter / Tab key
- Generic locator intelligence, not tied to Playwright or Selenium
- Ranked locator candidates with confidence score
- Locator uniqueness check
- Dynamic ID/class/hash warning detection
- Parent context capture
- Label, heading, form, modal/dialog context
- Table row/column context
- iframe context detection
- Shadow DOM context detection
- Sensitive value masking
- Validation/comment attachment per step
- Compact Generic JSON export
- Raw JSON export for debugging

## Install

1. Extract this folder.
2. Open Chrome.
3. Go to `chrome://extensions`.
4. Enable `Developer mode`.
5. Click `Load unpacked`.
6. Select the `astra-ai-ui-recorder` folder.
7. Open your application.
8. Click the extension icon.
9. Side panel opens.
10. Click `Start` and perform UI actions.

## Output Design

The exported JSON is framework-neutral. It records locator evidence such as:

- data-testid / data-test / data-qa / data-cy
- id
- name
- css
- xpath
- text
- label
- role + accessible name
- placeholder
- aria-label
- parent section context
- table/modal/frame/shadow DOM context

Any downstream tool can convert this JSON into:

- Java Selenium
- Python Selenium
- C# Selenium
- TypeScript Playwright
- Java Playwright
- Cypress
- WebdriverIO
- Robot Framework

## Notes

- The recorder intentionally avoids storing full DOM HTML.
- It records compact element intelligence only.
- It masks sensitive values like passwords, OTP, emails, phone, token, account-like fields, and long text values.
- Absolute XPath is included only as a last-resort fallback and is scored low.
