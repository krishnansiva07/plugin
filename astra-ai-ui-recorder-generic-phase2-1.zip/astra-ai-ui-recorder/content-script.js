(() => {
  if (window.__astraAiRecorderLoaded) return;
  window.__astraAiRecorderLoaded = true;

  let recording = false;
  let lastInputTimer = null;
  let lastInputSignature = null;
  const RECENT_EVENT_MS = 400;
  let lastEventKey = '';
  let lastEventAt = 0;

  chrome.storage.local.get(['astraRecording']).then(data => {
    recording = !!data.astraRecording;
  });

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && changes.astraRecording) {
      recording = !!changes.astraRecording.newValue;
    }
  });

  function isElementNode(node) { return node && node.nodeType === Node.ELEMENT_NODE; }

  function cleanText(text, max = 120) {
    return (text || '')
      .replace(/\s+/g, ' ')
      .replace(/[\u200B-\u200D\uFEFF]/g, '')
      .trim()
      .slice(0, max);
  }

  function cssEscape(value) {
    if (window.CSS && CSS.escape) return CSS.escape(value);
    return String(value).replace(/[^a-zA-Z0-9_-]/g, '\\$&');
  }

  function quoteXPath(value) {
    if (!value.includes("'")) return `'${value}'`;
    if (!value.includes('"')) return `"${value}"`;
    return "concat('" + value.split("'").join("', \"'\", '") + "')";
  }

  function getVisibleText(el) {
    if (!isElementNode(el)) return '';
    const tag = el.tagName.toLowerCase();
    if (['input', 'textarea', 'select'].includes(tag)) return '';
    return cleanText(el.innerText || el.textContent || '', 160);
  }

  function getOwnText(el) {
    if (!isElementNode(el)) return '';
    const clone = el.cloneNode(true);
    Array.from(clone.children || []).forEach(c => c.remove());
    return cleanText(clone.textContent || '', 100);
  }

  function isVisible(el) {
    if (!isElementNode(el)) return false;
    const style = window.getComputedStyle(el);
    const rect = el.getBoundingClientRect();
    return style && style.visibility !== 'hidden' && style.display !== 'none' && rect.width > 0 && rect.height > 0;
  }

  function isInteractive(el) {
    if (!isElementNode(el)) return false;
    const tag = el.tagName.toLowerCase();
    const role = el.getAttribute('role');
    return ['a','button','input','textarea','select','option','summary'].includes(tag) ||
      ['button','link','textbox','checkbox','radio','combobox','menuitem','tab','switch','option'].includes(role || '') ||
      el.hasAttribute('contenteditable') ||
      el.onclick || el.getAttribute('tabindex') !== null;
  }

  function findActionElement(target) {
    let el = target;
    let depth = 0;
    while (isElementNode(el) && depth < 6) {
      if (isInteractive(el)) return el;
      el = el.parentElement;
      depth++;
    }
    return isElementNode(target) ? target : null;
  }

  function getRole(el) {
    const explicit = el.getAttribute('role');
    if (explicit) return explicit;
    const tag = el.tagName.toLowerCase();
    const type = (el.getAttribute('type') || '').toLowerCase();
    if (tag === 'button') return 'button';
    if (tag === 'a' && el.hasAttribute('href')) return 'link';
    if (tag === 'textarea') return 'textbox';
    if (tag === 'select') return 'combobox';
    if (tag === 'input') {
      if (['button','submit','reset'].includes(type)) return 'button';
      if (type === 'checkbox') return 'checkbox';
      if (type === 'radio') return 'radio';
      if (type === 'range') return 'slider';
      return 'textbox';
    }
    return null;
  }

  function findLabel(el) {
    if (!isElementNode(el)) return '';
    const ariaLabel = cleanText(el.getAttribute('aria-label'));
    if (ariaLabel) return ariaLabel;

    const labelledBy = el.getAttribute('aria-labelledby');
    if (labelledBy) {
      const txt = labelledBy.split(/\s+/).map(id => document.getElementById(id)).filter(Boolean).map(x => cleanText(x.innerText || x.textContent)).join(' ');
      if (cleanText(txt)) return cleanText(txt);
    }

    if (el.id) {
      const label = document.querySelector(`label[for="${cssEscape(el.id)}"]`);
      if (label) return cleanText(label.innerText || label.textContent);
    }

    const wrapped = el.closest('label');
    if (wrapped) return cleanText(wrapped.innerText || wrapped.textContent);

    const parent = el.parentElement;
    if (parent) {
      const before = Array.from(parent.childNodes)
        .slice(0, Array.from(parent.childNodes).indexOf(el))
        .map(n => cleanText(n.innerText || n.textContent || ''))
        .filter(Boolean)
        .slice(-2)
        .join(' ');
      if (before) return before.slice(0, 100);
    }

    return '';
  }

  function accessibleName(el) {
    return cleanText(
      el.getAttribute('aria-label') ||
      findLabel(el) ||
      el.getAttribute('title') ||
      el.getAttribute('placeholder') ||
      getOwnText(el) ||
      getVisibleText(el) ||
      el.getAttribute('value') ||
      ''
    );
  }

  function stableAttributes(el) {
    const attrs = {};
    const allowed = ['id','name','type','placeholder','title','alt','role','aria-label','aria-labelledby','aria-describedby'];
    for (const a of allowed) {
      const v = cleanText(el.getAttribute(a), 160);
      if (v) attrs[a] = v;
    }
    const dataAttrs = {};
    for (const attr of Array.from(el.attributes || [])) {
      const n = attr.name;
      if (n.startsWith('data-')) dataAttrs[n] = cleanText(attr.value, 160);
    }
    if (Object.keys(dataAttrs).length) attrs.dataAttributes = dataAttrs;
    return attrs;
  }

  function isLikelyDynamic(value) {
    if (!value) return false;
    const v = String(value);
    return /[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}/i.test(v) ||
      /\d{4,}/.test(v) ||
      /^(ember|ext-gen|react-select|mat-input|mui-|radix-|headlessui-|rc_|auto-|generated-)/i.test(v) ||
      /[a-z]{1,4}[-_]?\d{3,}$/i.test(v) ||
      v.length > 70;
  }

  function isLikelyHashClass(cls) {
    if (!cls) return false;
    return /(^|\s)(css|sc|jss|makeStyles|module|__[a-z0-9]{5,}|[a-zA-Z0-9_-]*__[a-zA-Z0-9_-]*___[a-zA-Z0-9_-]+)(\s|$)/.test(cls) || /[a-f0-9]{6,}/i.test(cls);
  }

  function uniqueCount(selector) {
    try { return document.querySelectorAll(selector).length; } catch { return -1; }
  }

  function xpathCount(xpath) {
    try {
      const result = document.evaluate(xpath, document, null, XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null);
      return result.snapshotLength;
    } catch { return -1; }
  }

  function absoluteXPath(el) {
    const parts = [];
    let node = el;
    while (node && node.nodeType === Node.ELEMENT_NODE && node !== document.documentElement) {
      let index = 1;
      let sibling = node.previousElementSibling;
      while (sibling) {
        if (sibling.tagName === node.tagName) index++;
        sibling = sibling.previousElementSibling;
      }
      parts.unshift(`${node.tagName.toLowerCase()}[${index}]`);
      node = node.parentElement;
    }
    return '/html/' + parts.join('/');
  }

  function buildCssPath(el) {
    const parts = [];
    let node = el;
    let depth = 0;
    while (node && node.nodeType === Node.ELEMENT_NODE && depth < 5) {
      const tag = node.tagName.toLowerCase();
      if (node.id && !isLikelyDynamic(node.id) && uniqueCount(`#${cssEscape(node.id)}`) === 1) {
        parts.unshift(`${tag}#${cssEscape(node.id)}`);
        break;
      }
      let part = tag;
      const name = node.getAttribute('name');
      const data = firstDataAttribute(node);
      if (data) part += `[${data.name}="${cssEscape(data.value)}"]`;
      else if (name && !isLikelyDynamic(name)) part += `[name="${cssEscape(name)}"]`;
      else {
        const classes = Array.from(node.classList || []).filter(c => !isLikelyDynamic(c) && !isLikelyHashClass(c)).slice(0,2);
        if (classes.length) part += '.' + classes.map(cssEscape).join('.');
      }
      parts.unshift(part);
      const selector = parts.join(' > ');
      if (uniqueCount(selector) === 1) break;
      node = node.parentElement;
      depth++;
    }
    return parts.join(' > ');
  }

  function firstDataAttribute(el) {
    const preferred = ['data-testid','data-test','data-qa','data-cy','data-automation','data-automation-id','data-test-id'];
    for (const name of preferred) {
      const value = el.getAttribute(name);
      if (value && !isLikelyDynamic(value)) return { name, value };
    }
    for (const attr of Array.from(el.attributes || [])) {
      if (attr.name.startsWith('data-') && attr.value && !isLikelyDynamic(attr.value)) return { name: attr.name, value: attr.value };
    }
    return null;
  }

  function addLocator(list, strategy, value, baseScore, reason, meta = {}) {
    if (!value) return;
    const normalizedValue = String(value).trim();
    if (!normalizedValue) return;
    const key = strategy + '|' + normalizedValue;
    if (list.some(x => x.key === key)) return;
    list.push({ key, strategy, value: normalizedValue, baseScore, reason, ...meta });
  }

  function rankLocators(el) {
    const list = [];
    const tag = el.tagName.toLowerCase();
    const text = getOwnText(el) || getVisibleText(el);
    const label = findLabel(el);
    const role = getRole(el);
    const name = el.getAttribute('name');
    const id = el.id;
    const placeholder = el.getAttribute('placeholder');
    const aria = el.getAttribute('aria-label');
    const title = el.getAttribute('title');
    const data = firstDataAttribute(el);

    if (data) addLocator(list, data.name, `[${data.name}="${data.value}"]`, 98, 'Stable data attribute normally intended for automation');
    if (id && !isLikelyDynamic(id)) addLocator(list, 'id', `#${id}`, 92, 'Readable non-dynamic id');
    if (name && !isLikelyDynamic(name)) addLocator(list, 'name', `${tag}[name="${name}"]`, 88, 'Readable name attribute');
    if (aria) addLocator(list, 'aria-label', `//*[@aria-label=${quoteXPath(aria)}]`, 86, 'Accessible aria-label');
    if (label) addLocator(list, 'label', label, 85, 'Human visible/accessible label');
    if (placeholder) addLocator(list, 'placeholder', placeholder, 78, 'Placeholder can identify input but may change');
    if (role && accessibleName(el)) addLocator(list, 'role+name', `${role} | ${accessibleName(el)}`, 82, 'Semantic role with accessible name');
    if (text && text.length <= 80) addLocator(list, 'text', text, 72, 'Visible text; useful but language/content dependent');
    if (title) addLocator(list, 'title', `[title="${title}"]`, 70, 'Title attribute');

    const css = buildCssPath(el);
    if (css) addLocator(list, 'css', css, 68, 'Generated compact CSS selector');

    if (text && text.length <= 100) {
      addLocator(list, 'xpath-text', `//${tag}[normalize-space()=${quoteXPath(text)}]`, 66, 'XPath using exact visible text');
    }
    if (id && !isLikelyDynamic(id)) addLocator(list, 'xpath-id', `//*[@id=${quoteXPath(id)}]`, 75, 'XPath using id');
    if (name && !isLikelyDynamic(name)) addLocator(list, 'xpath-name', `//${tag}[@name=${quoteXPath(name)}]`, 72, 'XPath using name');

    addLocator(list, 'absolute-xpath', absoluteXPath(el), 35, 'Last-resort absolute XPath; brittle and index-based');

    const ranked = list.map(item => {
      let unique = null;
      let matchCount = null;
      let dynamicRisk = false;
      let score = item.baseScore;
      if (item.value.startsWith('//') || item.value.startsWith('/html')) {
        matchCount = xpathCount(item.value);
      } else if (item.strategy !== 'label' && item.strategy !== 'placeholder' && item.strategy !== 'text' && item.strategy !== 'role+name') {
        matchCount = uniqueCount(item.value);
      }
      if (matchCount !== null && matchCount >= 0) {
        unique = matchCount === 1;
        if (unique) score += 4; else score -= Math.min(20, matchCount * 2);
      }
      if (isLikelyDynamic(item.value)) { dynamicRisk = true; score -= 25; }
      if (item.strategy === 'absolute-xpath') score -= 10;
      score = Math.max(1, Math.min(100, score));
      const { key, baseScore, ...rest } = item;
      return { ...rest, score, unique, matchCount, dynamicRisk, recommended: false };
    }).sort((a,b) => b.score - a.score);

    if (ranked[0]) ranked[0].recommended = true;
    return ranked;
  }

  function nearestTextBySelector(el, selector, max = 100) {
    const found = el.closest(selector);
    if (!found) return null;
    return cleanText(found.getAttribute('aria-label') || found.getAttribute('title') || found.innerText || found.textContent, max);
  }

  function parentContext(el) {
    const ctx = [];
    let node = el.parentElement;
    let level = 1;
    while (node && level <= 4 && node !== document.body) {
      const rect = node.getBoundingClientRect();
      const data = firstDataAttribute(node);
      ctx.push({
        level,
        tag: node.tagName.toLowerCase(),
        role: node.getAttribute('role') || null,
        id: node.id && !isLikelyDynamic(node.id) ? node.id : null,
        dataAttribute: data || null,
        classHint: Array.from(node.classList || []).filter(c => !isLikelyDynamic(c) && !isLikelyHashClass(c)).slice(0, 3).join(' ') || null,
        textSummary: cleanText(node.innerText || node.textContent, 180),
        size: { width: Math.round(rect.width), height: Math.round(rect.height) }
      });
      node = node.parentElement;
      level++;
    }
    return ctx;
  }

  function siblingContext(el) {
    const parent = el.parentElement;
    if (!parent) return {};
    const children = Array.from(parent.children);
    const idx = children.indexOf(el);
    const prev = children.slice(Math.max(0, idx - 2), idx).map(x => cleanText(x.innerText || x.textContent, 80)).filter(Boolean);
    const next = children.slice(idx + 1, idx + 3).map(x => cleanText(x.innerText || x.textContent, 80)).filter(Boolean);
    return { previousText: prev, nextText: next };
  }

  function tableContext(el) {
    const cell = el.closest('td,th');
    const row = el.closest('tr');
    const table = el.closest('table');
    if (!table || !row) return null;
    const rows = Array.from(table.querySelectorAll('tr'));
    const cells = Array.from(row.children);
    const cellIndex = cell ? cells.indexOf(cell) : -1;
    const headerRows = Array.from(table.querySelectorAll('thead tr, tr')).slice(0, 3);
    let columnName = null;
    for (const hr of headerRows) {
      const hs = Array.from(hr.children);
      if (hs[cellIndex]) {
        const t = cleanText(hs[cellIndex].innerText || hs[cellIndex].textContent, 80);
        if (t) { columnName = t; break; }
      }
    }
    const related = {};
    const headers = Array.from(table.querySelectorAll('thead th')).map(h => cleanText(h.innerText || h.textContent, 60));
    if (headers.length) {
      cells.forEach((c, i) => { if (headers[i]) related[headers[i]] = cleanText(c.innerText || c.textContent, 100); });
    }
    return {
      rowIndex: rows.indexOf(row),
      columnIndex: cellIndex,
      columnName,
      rowText: cleanText(row.innerText || row.textContent, 220),
      relatedCellValues: related
    };
  }

  function frameContext() {
    return {
      isInsideIframe: window.self !== window.top,
      frameUrl: location.href,
      frameName: window.name || null
    };
  }

  function shadowContext(el) {
    const root = el.getRootNode && el.getRootNode();
    if (root && root.host) {
      const host = root.host;
      return {
        isInsideShadowRoot: true,
        hostTag: host.tagName.toLowerCase(),
        hostId: host.id || null,
        hostDataAttribute: firstDataAttribute(host),
        hostCss: buildCssPath(host)
      };
    }
    return { isInsideShadowRoot: false };
  }

  function warningsFor(el, ranked) {
    const warnings = [];
    if (el.id && isLikelyDynamic(el.id)) warnings.push(`ID appears dynamic: ${el.id}`);
    const badClasses = Array.from(el.classList || []).filter(c => isLikelyDynamic(c) || isLikelyHashClass(c)).slice(0,3);
    if (badClasses.length) warnings.push(`Class appears generated/dynamic: ${badClasses.join(', ')}`);
    if (!ranked.some(r => r.score >= 85)) warnings.push('No high-confidence stable locator found');
    if (ranked[0]?.strategy === 'absolute-xpath') warnings.push('Best locator is absolute XPath; this is brittle');
    if (!accessibleName(el) && !getVisibleText(el) && !findLabel(el)) warnings.push('Element has weak human-readable identity');
    return warnings;
  }

  function maskValue(el, value) {
    const tag = el.tagName.toLowerCase();
    const type = (el.getAttribute('type') || '').toLowerCase();
    const name = `${el.getAttribute('name') || ''} ${el.id || ''} ${findLabel(el) || ''}`.toLowerCase();
    const raw = String(value || '');
    const sensitive = type === 'password' || /(password|pwd|token|otp|secret|pin|ssn|pan|aadhaar|account|email|phone|mobile)/i.test(name) || raw.length > 80;
    if (sensitive) {
      return { captured: false, value: null, valueHint: name.split(/\s+/).filter(Boolean).slice(0,3).join('-') || type || tag, reason: 'Sensitive/dynamic value masked' };
    }
    return { captured: true, value: raw, valueHint: type || tag, reason: 'Non-sensitive short value captured' };
  }

  function elementSnapshot(el) {
    const ranked = rankLocators(el);
    const rect = el.getBoundingClientRect();
    const element = {
      tag: el.tagName.toLowerCase(),
      elementType: (el.getAttribute('type') || el.tagName.toLowerCase()).toLowerCase(),
      role: getRole(el),
      visible: isVisible(el),
      visibleText: getVisibleText(el),
      ownText: getOwnText(el),
      accessibleName: accessibleName(el),
      label: findLabel(el),
      placeholder: cleanText(el.getAttribute('placeholder')) || null,
      stableAttributes: stableAttributes(el),
      boundingBox: { x: Math.round(rect.x), y: Math.round(rect.y), width: Math.round(rect.width), height: Math.round(rect.height) }
    };
    return {
      element,
      rankedLocators: ranked,
      recommendedLocator: ranked.find(x => x.recommended) || ranked[0] || null,
      domContext: {
        nearestHeading: nearestTextBySelector(el, 'h1,h2,h3,h4,h5,h6,[role="heading"]', 120),
        nearestForm: nearestTextBySelector(el, 'form', 180),
        nearestDialogOrModal: nearestTextBySelector(el, '[role="dialog"],[aria-modal="true"],.modal,.dialog', 180),
        parentContext: parentContext(el),
        siblingContext: siblingContext(el),
        tableContext: tableContext(el),
        frameContext: frameContext(),
        shadowDomContext: shadowContext(el)
      },
      locatorWarnings: warningsFor(el, ranked)
    };
  }

  function inferAction(el, eventType) {
    const tag = el.tagName.toLowerCase();
    const type = (el.getAttribute('type') || '').toLowerCase();
    if (eventType === 'keydown') return 'keyboard';
    if (tag === 'select') return 'select';
    if (tag === 'input' && ['checkbox','radio'].includes(type)) return type === 'checkbox' ? 'checkbox' : 'radio';
    if (['input','textarea'].includes(tag) || el.hasAttribute('contenteditable')) return 'input';
    return 'click';
  }

  function sendAction(action) {
    const now = Date.now();
    const key = `${action.action}|${action.element?.accessibleName}|${action.recommendedLocator?.strategy}|${action.recommendedLocator?.value}`;
    if (key === lastEventKey && now - lastEventAt < RECENT_EVENT_MS) return;
    lastEventKey = key;
    lastEventAt = now;
    chrome.runtime.sendMessage({ type: 'ASTRA_ACTION_CAPTURED', payload: action }).catch(() => {});
  }

  function capture(el, eventType, extra = {}) {
    if (!recording || !el) return;
    const snapshot = elementSnapshot(el);
    const action = inferAction(el, eventType);
    const payload = {
      action,
      eventType,
      page: { url: location.href, title: document.title },
      ...snapshot,
      relationshipContext: {
        nearestLabel: findLabel(el) || null,
        nearestHeading: snapshot.domContext.nearestHeading,
        nearestForm: snapshot.domContext.nearestForm,
        leftText: snapshot.domContext.siblingContext.previousText?.join(' | ') || null,
        rightText: snapshot.domContext.siblingContext.nextText?.join(' | ') || null
      },
      validationComment: '',
      note: '',
      ...extra
    };
    sendAction(payload);
  }

  document.addEventListener('click', (e) => {
    const el = findActionElement(e.target);
    if (!el) return;
    const tag = el.tagName.toLowerCase();
    const type = (el.getAttribute('type') || '').toLowerCase();
    if (['input','textarea','select'].includes(tag) && !['checkbox','radio','button','submit','reset','file'].includes(type)) return;
    capture(el, 'click', { state: ['checkbox','radio'].includes(type) ? { checked: el.checked } : undefined });
  }, true);

  document.addEventListener('input', (e) => {
    const el = findActionElement(e.target);
    if (!el) return;
    const sig = buildCssPath(el) || absoluteXPath(el);
    lastInputSignature = sig;
    clearTimeout(lastInputTimer);
    lastInputTimer = setTimeout(() => {
      if (!recording || lastInputSignature !== sig) return;
      capture(el, 'input', { valuePolicy: maskValue(el, el.value || el.textContent || '') });
    }, 450);
  }, true);

  document.addEventListener('change', (e) => {
    const el = findActionElement(e.target);
    if (!el) return;
    const tag = el.tagName.toLowerCase();
    const type = (el.getAttribute('type') || '').toLowerCase();
    if (tag === 'select') capture(el, 'change', { selectedText: cleanText(el.options?.[el.selectedIndex]?.text || ''), valuePolicy: maskValue(el, el.value) });
    else if (['checkbox','radio','file'].includes(type)) capture(el, 'change', { state: { checked: el.checked, files: type === 'file' ? Array.from(el.files || []).map(f => ({ name: f.name, size: f.size, type: f.type })) : undefined } });
  }, true);

  document.addEventListener('keydown', (e) => {
    if (!recording) return;
    if (!['Enter','Tab'].includes(e.key)) return;
    const el = findActionElement(e.target);
    if (!el) return;
    capture(el, 'keydown', { key: e.key });
  }, true);
})();
