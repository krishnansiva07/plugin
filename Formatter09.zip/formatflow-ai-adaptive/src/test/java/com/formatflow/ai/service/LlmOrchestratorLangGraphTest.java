package com.formatflow.ai.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

class LlmOrchestratorLangGraphTest {

    @Test
    void langGraphFinalizesAfterAnalyzeCreateAndPassingReview() {
        LlmClient client = mock(LlmClient.class);
        ObjectMapper mapper = new ObjectMapper();
        IconCatalog icons = new IconCatalog();
        PromptFactory prompts = new PromptFactory(mapper, icons);
        LlmOrchestrator orchestrator = new LlmOrchestrator(
                client, prompts, new ContentParser(), mapper, icons,
                9000, 40, 1, 80, 18000, 28000
        );

        when(client.chat(anyString(), anyString(), anyInt(), anyDouble()))
                .thenReturn("- Use one clear overview section\n- Preserve employee capabilities")
                .thenReturn("<h2>About me</h2><p>Employee self-service overview.</p><ul><li>Maintain profiles</li><li>Access appraisal reviews</li></ul>")
                .thenReturn("{\"pass\":true,\"score\":94,\"issues\":[],\"repairInstruction\":\"\"}");

        LlmOrchestrator.FreeformOutcome result = orchestrator.freeform(
                "key",
                "About me application lets employees maintain profiles and access appraisal reviews.",
                "Co-worker",
                "New joiner onboarding",
                "CONFLUENCE",
                "FORMAT",
                "Short"
        );

        assertThat(result.html()).contains("<h2>About me</h2>", "Maintain profiles");
        assertThat(result.llmCalls()).isEqualTo(3);
        assertThat(result.chunks()).isEqualTo(1);
        assertThat(result.workflowActivity()).contains("Analyze", "Create", "Review").doesNotContain("Repair");
        verify(client, times(3)).chat(anyString(), anyString(), anyInt(), anyDouble());
    }

    @Test
    void langGraphRunsOneBoundedRepairPassWhenReviewFails() {
        LlmClient client = mock(LlmClient.class);
        ObjectMapper mapper = new ObjectMapper();
        IconCatalog icons = new IconCatalog();
        PromptFactory prompts = new PromptFactory(mapper, icons);
        LlmOrchestrator orchestrator = new LlmOrchestrator(
                client, prompts, new ContentParser(), mapper, icons,
                9000, 40, 1, 80, 18000, 28000
        );

        when(client.chat(anyString(), anyString(), anyInt(), anyDouble()))
                .thenReturn("- Merge repeated ideas\n- Keep the page easy to scan")
                .thenReturn("<h2>About me</h2><p>Overview.</p><h2>About me</h2><p>Repeated overview.</p>")
                .thenReturn("{\"pass\":false,\"score\":62,\"issues\":[\"Duplicate heading\"],\"repairInstruction\":\"Merge the repeated About me section.\"}")
                .thenReturn("<h2>About me</h2><p>Overview.</p><ul><li>Maintain profiles</li></ul>")
                .thenReturn("{\"pass\":true,\"score\":93,\"issues\":[],\"repairInstruction\":\"\"}");

        LlmOrchestrator.FreeformOutcome result = orchestrator.freeform(
                "key",
                "About me application lets employees maintain profiles.",
                "Co-worker",
                "Inform",
                "CONFLUENCE",
                "FORMAT",
                "Short"
        );

        assertThat(result.html()).contains("<h2>About me</h2>").doesNotContain("Repeated overview");
        assertThat(result.llmCalls()).isEqualTo(5);
        assertThat(result.workflowActivity()).contains("Repair");
        verify(client, times(5)).chat(anyString(), anyString(), anyInt(), anyDouble());
    }
}
